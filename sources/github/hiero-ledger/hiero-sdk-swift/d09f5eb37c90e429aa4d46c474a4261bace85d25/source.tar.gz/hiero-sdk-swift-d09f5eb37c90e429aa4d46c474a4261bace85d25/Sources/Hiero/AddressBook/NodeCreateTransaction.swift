// SPDX-License-Identifier: Apache-2.0

import Foundation
import GRPC
import HieroProtobufs
import SwiftProtobuf

/// A transaction body to add a new consensus node to the network address book.
///
/// This transaction body SHALL be considered a "privileged transaction".
///
/// This message supports a transaction to create a new node in the network
/// address book. The transaction, once complete, enables a new consensus node
/// to join the network, and requires governing council authorization.
///
/// - A `NodeCreateTransactionBody` MUST be signed by the governing council.
/// - A `NodeCreateTransactionBody` MUST be signed by the `Key` assigned to the
///   `admin_key` field.
/// - The newly created node information SHALL be added to the network address
///   book information in the network state.
/// - The new entry SHALL be created in "state" but SHALL NOT participate in
///   network consensus and SHALL NOT be present in network "configuration"
///   until the next "upgrade" transaction (as noted below).
/// - All new address book entries SHALL be added to the active network
///   configuration during the next `freeze` transaction with the field
///   `freeze_type` set to `PREPARE_UPGRADE`.
///
public final class NodeCreateTransaction: Transaction {
    public init(
        accountId: AccountId? = nil,
        description: String = "",
        gossipEndpoints: [Endpoint] = [],
        serviceEndpoints: [Endpoint] = [],
        gossipCaCertificate: Data? = nil,
        grpcCertificateHash: Data? = nil,
        adminKey: Key? = nil,
        grpcWebProxyEndpoint: Endpoint? = nil,
        declineRewards: Bool? = nil,
        associatedRegisteredNodes: [UInt64] = []
    ) {
        self.accountId = accountId
        self.description = description
        self.gossipEndpoints = gossipEndpoints
        self.serviceEndpoints = serviceEndpoints
        self.grpcWebProxyEndpoint = grpcWebProxyEndpoint
        self.gossipCaCertificate = gossipCaCertificate
        self.grpcCertificateHash = grpcCertificateHash
        self.adminKey = adminKey
        self.grpcWebProxyEndpoint = grpcWebProxyEndpoint
        self.declineRewards = declineRewards
        self.associatedRegisteredNodes = associatedRegisteredNodes

        super.init()
    }

    internal init(
        protobuf proto: Proto_TransactionBody, _ data: Com_Hedera_Hapi_Node_Addressbook_NodeCreateTransactionBody
    ) throws {
        self.accountId = data.hasAccountID ? try .fromProtobuf(data.accountID) : nil
        self.description = data.description_p
        self.gossipEndpoints = try data.gossipEndpoint.map(Endpoint.init)
        self.serviceEndpoints = try data.serviceEndpoint.map(Endpoint.init)
        self.gossipCaCertificate = data.gossipCaCertificate
        self.grpcCertificateHash = data.grpcCertificateHash
        self.adminKey = data.hasAdminKey ? try .fromProtobuf(data.adminKey) : nil
        self.grpcWebProxyEndpoint = data.hasGrpcProxyEndpoint ? try Endpoint(protobuf: data.grpcProxyEndpoint) : nil
        self.declineRewards = data.declineReward
        self.associatedRegisteredNodes = data.associatedRegisteredNode

        try super.init(protobuf: proto)
    }

    /// Node account ID.
    public var accountId: AccountId? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the node account
    @discardableResult
    public func accountId(_ accountId: AccountId?) -> Self {
        self.accountId = accountId

        return self
    }

    /// Returns the nodes description.
    public var description: String {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the node's description.
    @discardableResult
    public func description(_ description: String) -> Self {
        self.description = description

        return self
    }

    /// A list of service endpoints for gossip.
    public var gossipEndpoints: [Endpoint] {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Assign the list of service endpoints for gossip.
    @discardableResult
    public func gossipEndpoints(_ gossipEndpoints: [Endpoint]) -> Self {
        self.gossipEndpoints = gossipEndpoints

        return self
    }

    /// Add an endpoint for gossip to the list of service endpoints for gossip.
    @discardableResult
    public func addGossipEndpoint(_ gossipEndpoint: Endpoint) -> Self {
        self.gossipEndpoints.append(gossipEndpoint)

        return self
    }

    /// Extract the list of service endpoints for gRPC calls.
    public var serviceEndpoints: [Endpoint] {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Assign the list of service endpoints for gRPC calls.
    @discardableResult
    public func serviceEndpoints(_ serviceEndpoints: [Endpoint]) -> Self {
        self.serviceEndpoints = serviceEndpoints

        return self
    }

    /// Add an endpoint for gRPC calls to the list of service endpoints for gRPC calls.
    @discardableResult
    public func addServiceEndpoint(_ serviceEndpoint: Endpoint) -> Self {
        self.serviceEndpoints.append(serviceEndpoint)

        return self
    }

    /// Extract the gRPC web proxy endpoint.
    public var grpcWebProxyEndpoint: Endpoint? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the gRPC web proxy endpoint.
    @discardableResult
    public func grpcWebProxyEndpoint(_ grpcWebProxyEndpoint: Endpoint) -> Self {
        self.grpcWebProxyEndpoint = grpcWebProxyEndpoint

        return self
    }

    /// Extract the certificate used to sign gossip events.
    public var gossipCaCertificate: Data? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the certificate used to sign gossip events.
    @discardableResult
    public func gossipCaCertificate(_ gossipCaCertificate: Data) -> Self {
        self.gossipCaCertificate = gossipCaCertificate

        return self
    }

    /// Extract the hash of the node gRPC TLS certificate.
    public var grpcCertificateHash: Data? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the hash of the node gRPC TLS certificate.
    @discardableResult
    public func grpcCertificateHash(_ grpcCertificateHash: Data) -> Self {
        self.grpcCertificateHash = grpcCertificateHash

        return self
    }

    /// Get an administrative key controlled by the node operator.
    public var adminKey: Key? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets an administrative key controlled by the node operator.
    @discardableResult
    public func adminKey(_ adminKey: Key) -> Self {
        self.adminKey = adminKey

        return self
    }

    /// Should this node decline staking rewards?
    public var declineRewards: Bool? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the staking rewards policy for the node.
    @discardableResult
    public func declineRewards(_ declineRewards: Bool) -> Self {
        self.declineRewards = declineRewards

        return self
    }

    /// A list of registered node IDs operated by the same entity as this consensus node.
    public var associatedRegisteredNodes: [UInt64] {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Sets the list of associated registered node IDs.
    @discardableResult
    public func associatedRegisteredNodes(_ associatedRegisteredNodes: [UInt64]) -> Self {
        self.associatedRegisteredNodes = associatedRegisteredNodes

        return self
    }

    /// Add an associated registered node ID.
    @discardableResult
    public func addAssociatedRegisteredNode(_ registeredNodeId: UInt64) -> Self {
        self.associatedRegisteredNodes.append(registeredNodeId)

        return self
    }

    internal override func validateChecksums(on ledgerId: LedgerId) throws {
        try accountId?.validateChecksums(on: ledgerId)
        try super.validateChecksums(on: ledgerId)
    }

    internal override func transactionExecute(
        _ channel: GRPCChannel, _ request: Proto_Transaction, _ deadline: TimeInterval
    ) async throws
        -> Proto_TransactionResponse
    {
        try await Proto_AddressBookServiceAsyncClient(channel: channel).createNode(
            request, callOptions: applyGrpcHeader(deadline: deadline))
    }

    internal override func toTransactionDataProtobuf(_ chunkInfo: ChunkInfo) -> Proto_TransactionBody.OneOf_Data {
        _ = chunkInfo.assertSingleTransaction()

        return .nodeCreate(toProtobuf())
    }
}

extension NodeCreateTransaction: ToProtobuf {
    internal typealias Protobuf = Com_Hedera_Hapi_Node_Addressbook_NodeCreateTransactionBody

    internal func toProtobuf() -> Protobuf {
        .with { proto in
            accountId?.toProtobufInto(&proto.accountID)
            proto.description_p = description
            proto.gossipEndpoint = gossipEndpoints.map { $0.toProtobuf() }
            proto.serviceEndpoint = serviceEndpoints.map { $0.toProtobuf() }
            proto.gossipCaCertificate = gossipCaCertificate ?? Data()
            proto.grpcCertificateHash = grpcCertificateHash ?? Data()
            if let adminKey = adminKey {
                proto.adminKey = adminKey.toProtobuf()
            }
            if let grpcWebProxyEndpoint = grpcWebProxyEndpoint {
                proto.grpcProxyEndpoint = grpcWebProxyEndpoint.toProtobuf()
            }
            if let declineRewards = declineRewards {
                proto.declineReward = declineRewards
            }
            proto.associatedRegisteredNode = associatedRegisteredNodes
        }
    }
}

extension NodeCreateTransaction {
    internal func toSchedulableTransactionData() -> Proto_SchedulableTransactionBody.OneOf_Data {
        .nodeCreate(toProtobuf())
    }
}
