// SPDX-License-Identifier: Apache-2.0

import Foundation
import GRPC
import HieroProtobufs
import SwiftProtobuf

/// Transfers cryptocurrency among two or more accounts by making the desired adjustments to their
/// balances.
///
/// Each transfer list can specify up to 10 adjustments. Each negative amount is withdrawn
/// from the corresponding account (a sender), and each positive one is added to the corresponding
/// account (a receiver). The amounts list must sum to zero.
///
///
/// All transfers are in the lowest denomination, for `Hbar` that is tinybars (although `Hbar` handles this itself).
///
/// As an example:
/// For a fungible token with `3` decimals (and let's say the symbol is `ƒ`), transferring `1` _always_ transfers `0.001 ƒ`.
public final class TransferTransaction: AbstractTokenTransferTransaction {
    /// Create a new `TransferTransaction`.
    public override init() {
        super.init()
    }

    internal init(protobuf proto: Proto_TransactionBody, _ data: Proto_CryptoTransferTransactionBody) throws {
        try super.init(protobuf: proto)

        // init fields
        transfers = try .fromProtobuf(data.transfers.accountAmounts)
        tokenTransfersInner = try .fromProtobuf(data.tokenTransfers)
    }

    public var hbarTransfers: [AccountId: Hbar] {
        Dictionary(
            transfers.lazy.map { ($0.accountId, .fromTinybars($0.amount)) },
            uniquingKeysWith: { (first, second) in first })
    }

    /// Add a non-approved hbar transfer to the transaction.
    @discardableResult
    public func hbarTransfer(_ accountId: AccountId, _ amount: Hbar) -> Self {
        doHbarTransfer(accountId, amount.toTinybars(), false)
    }

    /// Add a non-approved hbar transfer to the transaction.
    @discardableResult
    public func hbarTransfer(_ evmAddress: EvmAddress, _ amount: Hbar) -> Self {
        doHbarTransfer(AccountId.fromEvmAddress(evmAddress), amount.toTinybars(), false)
    }

    /// Add an approved hbar transfer to the transaction.
    @discardableResult
    public func approvedHbarTransfer(_ accountId: AccountId, _ amount: Hbar) -> Self {
        doHbarTransfer(accountId, amount.toTinybars(), true)
    }

    private func doHbarTransfer(
        _ accountId: AccountId,
        _ amount: Int64,
        _ approved: Bool,
        hookCall: FungibleHookCall? = nil
    ) -> Self {
        for (index, transfer) in transfers.enumerated()
        where transfer.accountId == accountId && transfer.isApproval == approved {
            let newTinybars = transfer.amount + amount
            if newTinybars == 0 {
                transfers.remove(at: index)
            } else {
                transfers[index].amount = newTinybars
                if let hookCall = hookCall {
                    transfers[index].hookCall = hookCall
                }
            }

            return self
        }

        transfers.append(
            Transfer(accountId: accountId, amount: amount, isApproval: approved, hookCall: hookCall))

        return self
    }

    /// Adds an HBAR transfer with an account allowance hook to this transaction.
    ///
    /// The hook referenced by `hookCall` must be an `ACCOUNT_ALLOWANCE_HOOK` installed on
    /// the account identified by `accountId`. The hook will be invoked as part of the
    /// `CryptoTransfer` execution to authorize the transfer.
    ///
    /// - Parameters:
    ///   - accountId: The account to transfer HBAR from/to.
    ///   - amount: The amount of HBAR to transfer.
    ///   - hookCall: The fungible hook call specifying the hook ID, EVM call details, and hook type.
    @discardableResult
    public func addHbarTransferWithHook(_ accountId: AccountId, _ amount: Hbar, _ hookCall: FungibleHookCall) -> Self {
        doHbarTransfer(accountId, amount.toTinybars(), false, hookCall: hookCall)
    }

    internal override func validateChecksums(on ledgerId: LedgerId) throws {
        try transfers.validateChecksums(on: ledgerId)
        try tokenTransfersInner.validateChecksums(on: ledgerId)
        try super.validateChecksums(on: ledgerId)
    }

    internal override func transactionExecute(
        _ channel: GRPCChannel, _ request: Proto_Transaction, _ deadline: TimeInterval
    ) async throws
        -> Proto_TransactionResponse
    {
        try await Proto_CryptoServiceAsyncClient(channel: channel).cryptoTransfer(
            request, callOptions: applyGrpcHeader(deadline: deadline))
    }

    internal override func toTransactionDataProtobuf(_ chunkInfo: ChunkInfo) -> Proto_TransactionBody.OneOf_Data {
        _ = chunkInfo.assertSingleTransaction()

        return .cryptoTransfer(toProtobuf())
    }
}

extension TransferTransaction {
    internal func toSchedulableTransactionData() -> Proto_SchedulableTransactionBody.OneOf_Data {
        .cryptoTransfer(toProtobuf())
    }
}

extension TransferTransaction: ToProtobuf {
    internal typealias Protobuf = Proto_CryptoTransferTransactionBody

    internal func toProtobuf() -> Protobuf {
        .with { proto in
            proto.transfers = .with { $0.accountAmounts = transfers.toProtobuf() }
            proto.tokenTransfers = tokenTransfersInner.toProtobuf()
        }
    }
}
