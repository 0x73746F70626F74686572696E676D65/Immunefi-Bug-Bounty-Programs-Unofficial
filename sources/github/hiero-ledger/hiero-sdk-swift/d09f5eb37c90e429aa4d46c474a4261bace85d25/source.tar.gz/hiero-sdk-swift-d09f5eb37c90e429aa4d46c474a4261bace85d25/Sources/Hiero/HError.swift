// SPDX-License-Identifier: Apache-2.0

import Foundation

/// Represents any possible error from a fallible function in the Hiero SDK.
public struct HError: Error, CustomStringConvertible {
    // https://developer.apple.com/documentation/swift/error#2845903
    public enum ErrorKind: Equatable {
        case timedOut
        case grpcStatus(status: Int32)
        case fromProtobuf
        case transactionPreCheckStatus(status: Status, transactionId: TransactionId)
        case queryPreCheckStatus(status: Status, transactionId: TransactionId)
        case queryPaymentPreCheckStatus(status: Status, transactionId: TransactionId)
        case queryNoPaymentPreCheckStatus(status: Status)
        case basicParse
        case keyParse
        case keyDerive
        case noPayerAccountOrTransactionId
        case maxQueryPaymentExceeded(queryCost: Hbar, maxQueryPayment: Hbar)
        case nodeAccountUnknown
        case responseStatusUnrecognized
        case receiptStatus(status: Status, transactionId: TransactionId?)
        case mnemonicParse(reason: MnemonicParse, mnemonic: Mnemonic)
        case mnemonicEntropy(MnemonicEntropy)
        case signatureVerify
        /// An entity ID had an invalid checksum
        case badEntityId(BadEntityId)
        case cannotCreateChecksum
        case freezeUnsetNodeAccountIds
        case uninitialized
        case illegalState
    }

    public let description: String
    public let kind: ErrorKind

    internal init(kind: ErrorKind, description: String) {
        self.kind = kind
        self.description = description
    }

    internal static func fromProtobuf(_ description: String) -> Self {
        Self(kind: .fromProtobuf, description: description)
    }

    internal static func mnemonicParse(_ error: MnemonicParse, _ mnemonic: Mnemonic) -> Self {
        Self(
            kind: .mnemonicParse(reason: error, mnemonic: mnemonic),
            description: String(describing: error)
        )
    }

    internal static func mnemonicEntropy(_ error: MnemonicEntropy) -> Self {
        Self(
            kind: .mnemonicEntropy(error),
            description: String(describing: error)
        )
    }

    internal static func badEntityId(
        shard: UInt64, realm: UInt64, num: UInt64, presentChecksum: Checksum, expectedChecksum: Checksum
    ) -> Self {
        let err = BadEntityId(
            shard: shard, realm: realm, num: num, presentChecksum: presentChecksum, expectedChecksum: expectedChecksum)
        return Self(kind: .badEntityId(err), description: err.description)
    }

    internal static func basicParse(_ description: String) -> Self {
        Self(kind: .basicParse, description: description)
    }

    internal static func keyParse(_ description: String) -> Self {
        Self(kind: .keyParse, description: "failed to parse a key: \(description)")
    }

    internal static let cannotCreateChecksum: Self = Self(
        kind: .cannotCreateChecksum,
        description: "an entity ID with an alias or evmAddress cannot have a checksum"
    )

    internal static let noPayerAccountOrTransactionId: Self = Self(
        kind: .noPayerAccountOrTransactionId,
        description:
            "client must be configured with a payer account or requests must be given an explicit transaction id"
    )

    internal static func maxQueryPaymentExceeded(queryCost: Hbar, maxQueryPayment: Hbar) -> Self {
        let kind = ErrorKind.maxQueryPaymentExceeded(queryCost: queryCost, maxQueryPayment: maxQueryPayment)

        let description =
            "cost of (queryCost) without explicit payment is greater than the maximum allowed payment of \(maxQueryPayment)"

        return Self(kind: kind, description: description)
    }

    internal static func timedOut(_ description: String) -> Self {
        Self(
            kind: .timedOut,
            description:
                "Failed to complete request within the maximum time allowed; most recent attempt failed with: \(description)"
        )
    }

    internal static func unitialized(_ description: String) -> Self {
        Self(kind: .uninitialized, description: description)
    }

    internal static func illegalState(_ description: String) -> Self {
        Self(kind: .illegalState, description: description)
    }
}

extension HError: LocalizedError {
    public var errorDescription: String? {
        description
    }
}

extension HError {
    /// An entity ID had an invalid checksum
    public struct BadEntityId: Equatable, CustomStringConvertible {
        /// The entity ID's shard.
        public let shard: UInt64
        /// The entity ID's realm.
        public let realm: UInt64
        /// The entity ID's num.
        public let num: UInt64
        /// The (invalid) checksum that was present on the entity ID.
        public let presentChecksum: Checksum
        /// The checksum that should've been present on the entity ID.
        public let expectedChecksum: Checksum

        public var description: String {
            "entity ID \(shard).\(realm).\(num)-\(presentChecksum) was incorrect"
        }
    }
}

extension HError {
    public enum MnemonicParse: Equatable, CustomStringConvertible {
        /// The mnemonic has an unexpected length.
        case badLength(Int)
        /// The mnemonic contains words that are not in the wordlist.
        case unknownWords([Int])
        /// The checksum for the mnemonic isn't as expected
        case checksumMismatch(expected: UInt8, actual: UInt8)

        public var description: String {
            switch self {
            case .badLength(let length):
                return "bad length: expected `12` or `24` words, found `\(length)`"
            case .unknownWords(let words):
                return "unknown words at indecies: `\(words)`"
            case .checksumMismatch(let expected, let actual):
                return
                    "checksum mismatch: expected `0x\(String(expected, radix: 16))`, found `0x\(String(actual, radix: 16))`"
            }
        }
    }

    public enum MnemonicEntropy: Equatable, CustomStringConvertible {
        case badLength(expected: Int, actual: Int)
        case checksumMismatch(expected: UInt8, actual: UInt8)
        case legacyWithPassphrase

        public var description: String {
            switch self {
            case .badLength(let expected, let actual):
                return "bad length: expected `\(expected)` words, found \(actual) words"
            case .checksumMismatch(let expected, let actual):
                return
                    "checksum mismatch: expected `0x\(String(expected, radix: 16))`, found `0x\(String(actual, radix: 16))`"
            case .legacyWithPassphrase:
                return "used a passphrase with a legacy mnemonic"
            }
        }
    }
}

extension HError.ErrorKind: Sendable {}
extension HError.MnemonicEntropy: Sendable {}
extension HError.MnemonicParse: Sendable {}
extension HError.BadEntityId: Sendable {}
