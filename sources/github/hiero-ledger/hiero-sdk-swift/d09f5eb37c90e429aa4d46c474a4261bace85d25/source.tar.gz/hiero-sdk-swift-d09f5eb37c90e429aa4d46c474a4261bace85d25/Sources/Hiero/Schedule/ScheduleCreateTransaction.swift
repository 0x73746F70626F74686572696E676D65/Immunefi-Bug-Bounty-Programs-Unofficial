// SPDX-License-Identifier: Apache-2.0

import Foundation
import GRPC
import HieroProtobufs

/// Create a new schedule entity (or simply, schedule) in the network's action queue.
///
/// Upon `SUCCESS`, the receipt contains the `ScheduleId` of the created schedule. A schedule
/// entity includes a `scheduled_transaction_body` to be executed.
///
/// When the schedule has collected enough signing keys to satisfy the schedule's signing
/// requirements, the schedule can be executed.
///
public final class ScheduleCreateTransaction: Transaction {
    /// Create a new `ScheduleCreateTransaction`.
    public init(
        expirationTime: Timestamp? = nil,
        isWaitForExpiry: Bool = false,
        payerAccountId: AccountId? = nil,
        scheduledTransaction: Transaction? = nil,
        adminKey: Key? = nil,
        scheduleMemo: String = ""
    ) {
        self.expirationTime = expirationTime
        self.isWaitForExpiry = isWaitForExpiry
        self.payerAccountId = payerAccountId
        self.scheduledTransactionInner = scheduledTransaction.map(AnySchedulableTransaction.init(upcasting:))
        self.adminKey = adminKey
        self.scheduleMemo = scheduleMemo

        super.init()
    }

    internal init(protobuf proto: Proto_TransactionBody, _ data: Proto_ScheduleCreateTransactionBody) throws {
        expirationTime = data.hasExpirationTime ? .fromProtobuf(data.expirationTime) : nil
        isWaitForExpiry = data.waitForExpiry
        scheduleMemo = data.memo
        payerAccountId = data.hasPayerAccountID ? try .fromProtobuf(data.payerAccountID) : nil
        adminKey = data.hasAdminKey ? try .fromProtobuf(data.adminKey) : nil

        try super.init(protobuf: proto)
    }

    internal override var defaultMaxTransactionFee: Hbar { 5 }

    /// The timestamp for when the transaction should be evaluated for execution and then expire.
    public var expirationTime: Timestamp? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Set the timestamp for when the transaction should be evaluated for execution and then expire.
    @discardableResult
    public func expirationTime(_ expirationTime: Timestamp?) -> Self {
        self.expirationTime = expirationTime

        return self
    }

    /// If true, the transaction will be evaluated for execution at expiration_time instead
    /// of when all required signatures are received.
    public var isWaitForExpiry: Bool {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Set if the transaction will be evaluated for execution at expiration_time instead
    /// of when all required signatures are received.
    @discardableResult
    public func isWaitForExpiry(_ isWaitForExpiry: Bool) -> Self {
        self.isWaitForExpiry = isWaitForExpiry

        return self
    }

    /// The id of the account to be charged the service fee for the scheduled transaction at
    /// the consensus time that it executes (if ever).
    public var payerAccountId: AccountId? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Set the id of the account to be charged the service fee for the scheduled transaction at
    /// the consensus time that it executes (if ever).
    @discardableResult
    public func payerAccountId(_ payerAccountId: AccountId?) -> Self {
        self.payerAccountId = payerAccountId

        return self
    }

    private var scheduledTransactionClientMaxTransactionFee: Hbar?

    private var scheduledTransactionInner: AnySchedulableTransaction? {
        willSet {
            ensureNotFrozen()
        }
    }

    @discardableResult
    public override func freezeWith(_ client: Client?) throws -> Self {
        scheduledTransactionClientMaxTransactionFee = client?.maxTransactionFee

        return try super.freezeWith(client)
    }

    /// The scheduled transaction.
    public var scheduledTransaction: Transaction? {
        get { scheduledTransactionInner?.transaction }
        set(value) {
            scheduledTransactionInner = value.map(AnySchedulableTransaction.init(upcasting:))
        }
    }

    /// Set the scheduled transaction.
    @discardableResult
    public func scheduledTransaction(_ scheduledTransaction: Transaction?) -> Self {
        self.scheduledTransaction = scheduledTransaction

        return self
    }

    /// The Hedera key which can be used to sign a ScheduleDelete and remove the schedule.
    public var adminKey: Key? {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Set the Hedera key which can be used to sign a ScheduleDelete and remove the schedule.
    @discardableResult
    public func adminKey(_ adminKey: Key?) -> Self {
        self.adminKey = adminKey

        return self
    }

    /// The memo for the schedule entity.
    public var scheduleMemo: String {
        willSet {
            ensureNotFrozen()
        }
    }

    /// Set the memo for the schedule entity.
    @discardableResult
    public func scheduleMemo(_ scheduleMemo: String) -> Self {
        self.scheduleMemo = scheduleMemo

        return self
    }

    internal override func validateChecksums(on ledgerId: LedgerId) throws {
        try payerAccountId?.validateChecksums(on: ledgerId)
        try scheduledTransaction?.validateChecksums(on: ledgerId)
        try super.validateChecksums(on: ledgerId)
    }

    internal override func transactionExecute(
        _ channel: GRPCChannel, _ request: Proto_Transaction, _ deadline: TimeInterval
    ) async throws
        -> Proto_TransactionResponse
    {
        try await Proto_ScheduleServiceAsyncClient(channel: channel).createSchedule(
            request, callOptions: applyGrpcHeader(deadline: deadline))
    }

    internal override func toTransactionDataProtobuf(_ chunkInfo: ChunkInfo) -> Proto_TransactionBody.OneOf_Data {
        _ = chunkInfo.assertSingleTransaction()

        return .scheduleCreate(toProtobuf())
    }
}

extension ScheduleCreateTransaction: ToProtobuf {
    internal typealias Protobuf = Proto_ScheduleCreateTransactionBody

    internal func toProtobuf() -> Protobuf {
        let body = self.scheduledTransactionInner.map { scheduledTransaction in
            Proto_SchedulableTransactionBody.with { proto in
                proto.data = scheduledTransaction.toSchedulableTransactionData()
                proto.memo = scheduledTransaction.transaction.transactionMemo
                proto.maxCustomFees = scheduledTransaction.transaction.customFeeLimits.compactMap { $0.toProtobuf() }

                let transactionFee =
                    scheduledTransaction.transaction.maxTransactionFee
                    ?? self.scheduledTransactionClientMaxTransactionFee
                    ?? scheduledTransaction.transaction.defaultMaxTransactionFee

                proto.transactionFee = UInt64(transactionFee.toTinybars())
            }
        }

        return
            .with { proto in
                if let body = body {
                    proto.scheduledTransactionBody = body
                }

                proto.memo = self.scheduleMemo

                if let adminKey = adminKey?.toProtobuf() {
                    proto.adminKey = adminKey
                }

                if let payerAccountId = payerAccountId?.toProtobuf() {
                    proto.payerAccountID = payerAccountId
                }

                if let expirationTime = expirationTime?.toProtobuf() {
                    proto.expirationTime = expirationTime
                }

                if isWaitForExpiry {
                    proto.waitForExpiry = true
                }
            }
    }
}
