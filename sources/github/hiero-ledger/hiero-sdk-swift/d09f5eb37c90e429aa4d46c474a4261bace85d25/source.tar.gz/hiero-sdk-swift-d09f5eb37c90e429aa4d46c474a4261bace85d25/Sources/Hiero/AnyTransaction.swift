// SPDX-License-Identifier: Apache-2.0

import HieroProtobufs

// exists for the same reason as rust and still sucks :/\
internal enum ServicesTransactionDataList {
    case accountCreate([Proto_CryptoCreateTransactionBody])
    case accountUpdate([Proto_CryptoUpdateTransactionBody])
    case accountDelete([Proto_CryptoDeleteTransactionBody])
    case accountAllowanceApprove([Proto_CryptoApproveAllowanceTransactionBody])
    case accountAllowanceDelete([Proto_CryptoDeleteAllowanceTransactionBody])
    case contractCreate([Proto_ContractCreateTransactionBody])
    case contractUpdate([Proto_ContractUpdateTransactionBody])
    case contractDelete([Proto_ContractDeleteTransactionBody])
    case contractExecute([Proto_ContractCallTransactionBody])
    case transfer([Proto_CryptoTransferTransactionBody])
    case topicCreate([Proto_ConsensusCreateTopicTransactionBody])
    case topicUpdate([Proto_ConsensusUpdateTopicTransactionBody])
    case topicDelete([Proto_ConsensusDeleteTopicTransactionBody])
    case topicMessageSubmit([Proto_ConsensusSubmitMessageTransactionBody])
    case fileAppend([Proto_FileAppendTransactionBody])
    case fileCreate([Proto_FileCreateTransactionBody])
    case fileUpdate([Proto_FileUpdateTransactionBody])
    case fileDelete([Proto_FileDeleteTransactionBody])
    case tokenAssociate([Proto_TokenAssociateTransactionBody])
    case tokenBurn([Proto_TokenBurnTransactionBody])
    case tokenCreate([Proto_TokenCreateTransactionBody])
    case tokenDelete([Proto_TokenDeleteTransactionBody])
    case tokenDissociate([Proto_TokenDissociateTransactionBody])
    case tokenFeeScheduleUpdate([Proto_TokenFeeScheduleUpdateTransactionBody])
    case tokenFreeze([Proto_TokenFreezeAccountTransactionBody])
    case tokenGrantKyc([Proto_TokenGrantKycTransactionBody])
    case tokenMint([Proto_TokenMintTransactionBody])
    case tokenPause([Proto_TokenPauseTransactionBody])
    case tokenRevokeKyc([Proto_TokenRevokeKycTransactionBody])
    case tokenReject([Proto_TokenRejectTransactionBody])
    case tokenUnfreeze([Proto_TokenUnfreezeAccountTransactionBody])
    case tokenUnpause([Proto_TokenUnpauseTransactionBody])
    case tokenUpdate([Proto_TokenUpdateTransactionBody])
    case tokenWipe([Proto_TokenWipeAccountTransactionBody])
    case systemDelete([Proto_SystemDeleteTransactionBody])
    case systemUndelete([Proto_SystemUndeleteTransactionBody])
    case freeze([Proto_FreezeTransactionBody])
    case scheduleCreate([Proto_ScheduleCreateTransactionBody])
    case scheduleSign([Proto_ScheduleSignTransactionBody])
    case scheduleDelete([Proto_ScheduleDeleteTransactionBody])
    case ethereum([Proto_EthereumTransactionBody])
    case prng([Proto_UtilPrngTransactionBody])
    case tokenUpdateNfts([Proto_TokenUpdateNftsTransactionBody])
    case nodeCreate([Com_Hedera_Hapi_Node_Addressbook_NodeCreateTransactionBody])
    case nodeUpdate([Com_Hedera_Hapi_Node_Addressbook_NodeUpdateTransactionBody])
    case nodeDelete([Com_Hedera_Hapi_Node_Addressbook_NodeDeleteTransactionBody])
    case tokenAirdrop([Proto_TokenAirdropTransactionBody])
    case tokenClaimAirdrop([Proto_TokenClaimAirdropTransactionBody])
    case tokenCancelAirdrop([Proto_TokenCancelAirdropTransactionBody])
    case stateSignatureTransaction([Com_Hedera_Hapi_Platform_Event_StateSignatureTransaction])
    case historyProofSignature([Com_Hedera_Hapi_Services_Auxiliary_History_HistoryProofSignatureTransactionBody])
    case historyProofKeyPublication(
        [Com_Hedera_Hapi_Services_Auxiliary_History_HistoryProofKeyPublicationTransactionBody])
    case historyProofVote([Com_Hedera_Hapi_Services_Auxiliary_History_HistoryProofVoteTransactionBody])
    case hintsPreprocessingVote([Com_Hedera_Hapi_Services_Auxiliary_Hints_HintsPreprocessingVoteTransactionBody])
    case hintsKeyPublication([Com_Hedera_Hapi_Services_Auxiliary_Hints_HintsKeyPublicationTransactionBody])
    case hintsPartialSignature([Com_Hedera_Hapi_Services_Auxiliary_Hints_HintsPartialSignatureTransactionBody])
    case crsPublication([Com_Hedera_Hapi_Services_Auxiliary_Hints_CrsPublicationTransactionBody])
    case registeredNodeCreate([Com_Hedera_Hapi_Node_Addressbook_RegisteredNodeCreateTransactionBody])
    case registeredNodeUpdate([Com_Hedera_Hapi_Node_Addressbook_RegisteredNodeUpdateTransactionBody])
    case registeredNodeDelete([Com_Hedera_Hapi_Node_Addressbook_RegisteredNodeDeleteTransactionBody])
    case atomicBatch([Proto_AtomicBatchTransactionBody])
    case hookDispatch([Com_Hedera_Hapi_Node_Hooks_HookDispatchTransactionBody])
    case hookStore([Com_Hedera_Hapi_Node_Hooks_HookStoreTransactionBody])
    case ledgerIdPublication([Com_Hedera_Hapi_Node_Tss_LedgerIdPublicationTransactionBody])

    internal mutating func append(_ transaction: Proto_TransactionBody.OneOf_Data) throws {
        switch (self, transaction) {
        case (.accountCreate(var array), .cryptoCreateAccount(let data)):
            array.append(data)
            self = .accountCreate(array)

        case (.accountUpdate(var array), .cryptoUpdateAccount(let data)):
            array.append(data)
            self = .accountUpdate(array)

        case (.accountDelete(var array), .cryptoDelete(let data)):
            array.append(data)
            self = .accountDelete(array)

        case (.accountAllowanceApprove(var array), .cryptoApproveAllowance(let data)):
            array.append(data)
            self = .accountAllowanceApprove(array)

        case (.accountAllowanceDelete(var array), .cryptoDeleteAllowance(let data)):
            array.append(data)
            self = .accountAllowanceDelete(array)

        case (.contractCreate(var array), .contractCreateInstance(let data)):
            array.append(data)
            self = .contractCreate(array)

        case (.contractUpdate(var array), .contractUpdateInstance(let data)):
            array.append(data)
            self = .contractUpdate(array)

        case (.contractDelete(var array), .contractDeleteInstance(let data)):
            array.append(data)
            self = .contractDelete(array)

        case (.contractExecute(var array), .contractCall(let data)):
            array.append(data)
            self = .contractExecute(array)

        case (.transfer(var array), .cryptoTransfer(let data)):
            array.append(data)
            self = .transfer(array)

        case (.topicCreate(var array), .consensusCreateTopic(let data)):
            array.append(data)
            self = .topicCreate(array)

        case (.topicUpdate(var array), .consensusUpdateTopic(let data)):
            array.append(data)
            self = .topicUpdate(array)

        case (.topicDelete(var array), .consensusDeleteTopic(let data)):
            array.append(data)
            self = .topicDelete(array)

        case (.topicMessageSubmit(var array), .consensusSubmitMessage(let data)):
            array.append(data)
            self = .topicMessageSubmit(array)

        case (.fileAppend(var array), .fileAppend(let data)):
            array.append(data)
            self = .fileAppend(array)

        case (.fileCreate(var array), .fileCreate(let data)):
            array.append(data)
            self = .fileCreate(array)

        case (.fileUpdate(var array), .fileUpdate(let data)):
            array.append(data)
            self = .fileUpdate(array)

        case (.fileDelete(var array), .fileDelete(let data)):
            array.append(data)
            self = .fileDelete(array)

        case (.tokenAssociate(var array), .tokenAssociate(let data)):
            array.append(data)
            self = .tokenAssociate(array)

        case (.tokenBurn(var array), .tokenBurn(let data)):
            array.append(data)
            self = .tokenBurn(array)

        case (.tokenCreate(var array), .tokenCreation(let data)):
            array.append(data)
            self = .tokenCreate(array)

        case (.tokenDelete(var array), .tokenDeletion(let data)):
            array.append(data)
            self = .tokenDelete(array)

        case (.tokenDissociate(var array), .tokenDissociate(let data)):
            array.append(data)
            self = .tokenDissociate(array)

        case (.tokenFeeScheduleUpdate(var array), .tokenFeeScheduleUpdate(let data)):
            array.append(data)
            self = .tokenFeeScheduleUpdate(array)

        case (.tokenFreeze(var array), .tokenFreeze(let data)):
            array.append(data)
            self = .tokenFreeze(array)

        case (.tokenGrantKyc(var array), .tokenGrantKyc(let data)):
            array.append(data)
            self = .tokenGrantKyc(array)

        case (.tokenMint(var array), .tokenMint(let data)):
            array.append(data)
            self = .tokenMint(array)

        case (.tokenPause(var array), .tokenPause(let data)):
            array.append(data)
            self = .tokenPause(array)

        case (.tokenRevokeKyc(var array), .tokenRevokeKyc(let data)):
            array.append(data)
            self = .tokenRevokeKyc(array)

        case (.tokenUnfreeze(var array), .tokenUnfreeze(let data)):
            array.append(data)
            self = .tokenUnfreeze(array)

        case (.tokenUnpause(var array), .tokenUnpause(let data)):
            array.append(data)
            self = .tokenUnpause(array)

        case (.tokenUpdate(var array), .tokenUpdate(let data)):
            array.append(data)
            self = .tokenUpdate(array)

        case (.tokenWipe(var array), .tokenWipe(let data)):
            array.append(data)
            self = .tokenWipe(array)

        case (.systemDelete(var array), .systemDelete(let data)):
            array.append(data)
            self = .systemDelete(array)

        case (.systemUndelete(var array), .systemUndelete(let data)):
            array.append(data)
            self = .systemUndelete(array)

        case (.freeze(var array), .freeze(let data)):
            array.append(data)
            self = .freeze(array)

        case (.scheduleCreate(var array), .scheduleCreate(let data)):
            array.append(data)
            self = .scheduleCreate(array)

        case (.scheduleSign(var array), .scheduleSign(let data)):
            array.append(data)
            self = .scheduleSign(array)

        case (.scheduleDelete(var array), .scheduleDelete(let data)):
            array.append(data)
            self = .scheduleDelete(array)

        case (.ethereum(var array), .ethereumTransaction(let data)):
            array.append(data)
            self = .ethereum(array)

        case (.prng(var array), .utilPrng(let data)):
            array.append(data)
            self = .prng(array)

        case (.tokenUpdateNfts(var array), .tokenUpdateNfts(let data)):
            array.append(data)
            self = .tokenUpdateNfts(array)

        case (.tokenReject(var array), .tokenReject(let data)):
            array.append(data)
            self = .tokenReject(array)

        case (.nodeCreate(var array), .nodeCreate(let data)):
            array.append(data)
            self = .nodeCreate(array)

        case (.nodeUpdate(var array), .nodeUpdate(let data)):
            array.append(data)
            self = .nodeUpdate(array)

        case (.nodeDelete(var array), .nodeDelete(let data)):
            array.append(data)
            self = .nodeDelete(array)

        case (.tokenAirdrop(var array), .tokenAirdrop(let data)):
            array.append(data)
            self = .tokenAirdrop(array)

        case (.tokenClaimAirdrop(var array), .tokenClaimAirdrop(let data)):
            array.append(data)
            self = .tokenClaimAirdrop(array)

        case (.tokenCancelAirdrop(var array), .tokenCancelAirdrop(let data)):
            array.append(data)
            self = .tokenCancelAirdrop(array)

        case (.stateSignatureTransaction(var array), .stateSignatureTransaction(let data)):
            array.append(data)
            self = .stateSignatureTransaction(array)

        case (.historyProofSignature(var array), .historyProofSignature(let data)):
            array.append(data)
            self = .historyProofSignature(array)

        case (.historyProofKeyPublication(var array), .historyProofKeyPublication(let data)):
            array.append(data)
            self = .historyProofKeyPublication(array)

        case (.historyProofVote(var array), .historyProofVote(let data)):
            array.append(data)
            self = .historyProofVote(array)

        case (.hintsPreprocessingVote(var array), .hintsPreprocessingVote(let data)):
            array.append(data)
            self = .hintsPreprocessingVote(array)

        case (.hintsKeyPublication(var array), .hintsKeyPublication(let data)):
            array.append(data)
            self = .hintsKeyPublication(array)

        case (.hintsPartialSignature(var array), .hintsPartialSignature(let data)):
            array.append(data)
            self = .hintsPartialSignature(array)

        case (.crsPublication(var array), .crsPublication(let data)):
            array.append(data)
            self = .crsPublication(array)

        case (.registeredNodeCreate(var array), .registeredNodeCreate(let data)):
            array.append(data)
            self = .registeredNodeCreate(array)

        case (.registeredNodeUpdate(var array), .registeredNodeUpdate(let data)):
            array.append(data)
            self = .registeredNodeUpdate(array)

        case (.registeredNodeDelete(var array), .registeredNodeDelete(let data)):
            array.append(data)
            self = .registeredNodeDelete(array)

        case (.atomicBatch(var array), .atomicBatch(let data)):
            array.append(data)
            self = .atomicBatch(array)

        case (.hookDispatch(var array), .hookDispatch(let data)):
            array.append(data)
            self = .hookDispatch(array)

        case (.hookStore(var array), .hookStore(let data)):
            array.append(data)
            self = .hookStore(array)

        case (.ledgerIdPublication(var array), .ledgerIDPublication(let data)):
            array.append(data)
            self = .ledgerIdPublication(array)

        default:
            throw HError.fromProtobuf("mismatched transaction types")
        }
    }
}

extension ServicesTransactionDataList: TryFromProtobuf {
    internal typealias Protobuf = [Proto_TransactionBody.OneOf_Data]

    // swiftlint:disable:next function_body_length
    internal init(protobuf proto: Protobuf) throws {
        var iter = proto.makeIterator()

        let first = iter.next()!

        var value: Self

        switch first {
        case .contractCall(let data): value = .contractExecute([data])
        case .contractCreateInstance(let data): value = .contractCreate([data])
        case .contractUpdateInstance(let data): value = .contractUpdate([data])
        case .contractDeleteInstance(let data): value = .contractDelete([data])
        case .ethereumTransaction(let data): value = .ethereum([data])
        case .cryptoApproveAllowance(let data): value = .accountAllowanceApprove([data])
        case .cryptoDeleteAllowance(let data): value = .accountAllowanceDelete([data])
        case .cryptoCreateAccount(let data): value = .accountCreate([data])
        case .cryptoDelete(let data): value = .accountDelete([data])
        case .cryptoTransfer(let data): value = .transfer([data])
        case .cryptoUpdateAccount(let data): value = .accountUpdate([data])
        case .fileAppend(let data): value = .fileAppend([data])
        case .fileCreate(let data): value = .fileCreate([data])
        case .fileDelete(let data): value = .fileDelete([data])
        case .fileUpdate(let data): value = .fileUpdate([data])
        case .systemDelete(let data): value = .systemDelete([data])
        case .systemUndelete(let data): value = .systemUndelete([data])
        case .freeze(let data): value = .freeze([data])
        case .consensusCreateTopic(let data): value = .topicCreate([data])
        case .consensusUpdateTopic(let data): value = .topicUpdate([data])
        case .consensusDeleteTopic(let data): value = .topicDelete([data])
        case .consensusSubmitMessage(let data): value = .topicMessageSubmit([data])
        case .tokenCreation(let data): value = .tokenCreate([data])
        case .tokenFreeze(let data): value = .tokenFreeze([data])
        case .tokenUnfreeze(let data): value = .tokenUnfreeze([data])
        case .tokenGrantKyc(let data): value = .tokenGrantKyc([data])
        case .tokenRevokeKyc(let data): value = .tokenRevokeKyc([data])
        case .tokenDeletion(let data): value = .tokenDelete([data])
        case .tokenUpdate(let data): value = .tokenUpdate([data])
        case .tokenMint(let data): value = .tokenMint([data])
        case .tokenBurn(let data): value = .tokenBurn([data])
        case .tokenWipe(let data): value = .tokenWipe([data])
        case .tokenAssociate(let data): value = .tokenAssociate([data])
        case .tokenDissociate(let data): value = .tokenDissociate([data])
        case .tokenFeeScheduleUpdate(let data): value = .tokenFeeScheduleUpdate([data])
        case .tokenPause(let data): value = .tokenPause([data])
        case .tokenUnpause(let data): value = .tokenUnpause([data])
        case .scheduleCreate(let data): value = .scheduleCreate([data])
        case .scheduleDelete(let data): value = .scheduleDelete([data])
        case .scheduleSign(let data): value = .scheduleSign([data])
        case .utilPrng(let data): value = .prng([data])
        case .tokenUpdateNfts(let data): value = .tokenUpdateNfts([data])
        case .cryptoAddLiveHash: throw HError.fromProtobuf("Unsupported transaction `AddLiveHashTransaction`")
        case .cryptoDeleteLiveHash: throw HError.fromProtobuf("Unsupported transaction `DeleteLiveHashTransaction`")
        case .uncheckedSubmit: throw HError.fromProtobuf("Unsupported transaction `UncheckedSubmitTransaction`")
        case .nodeStakeUpdate: throw HError.fromProtobuf("Unsupported transaction `NodeStakeUpdateTransaction`")
        case .nodeCreate(let data): value = .nodeCreate([data])
        case .nodeUpdate(let data): value = .nodeUpdate([data])
        case .nodeDelete(let data): value = .nodeDelete([data])
        case .tokenReject(let data): value = .tokenReject([data])
        case .tokenAirdrop(let data): value = .tokenAirdrop([data])
        case .tokenCancelAirdrop(let data): value = .tokenCancelAirdrop([data])
        case .tokenClaimAirdrop(let data): value = .tokenClaimAirdrop([data])
        case .registeredNodeCreate(let data): value = .registeredNodeCreate([data])
        case .registeredNodeUpdate(let data): value = .registeredNodeUpdate([data])
        case .registeredNodeDelete(let data): value = .registeredNodeDelete([data])
        case .atomicBatch(let data): value = .atomicBatch([data])
        case .hookDispatch(let data): value = .hookDispatch([data])
        case .hookStore(let data): value = .hookStore([data])
        case .ledgerIDPublication(let data): value = .ledgerIdPublication([data])
        case .stateSignatureTransaction:
            throw HError.fromProtobuf("Unsupported transaction `StateSignatureTransaction`")
        case .hintsPreprocessingVote:
            throw HError.fromProtobuf("Unsupported transaction `HintsPreprocessingVoteTransaction`")
        case .hintsKeyPublication:
            throw HError.fromProtobuf("Unsupported transaction `HintsKeyPublicationTransaction`")
        case .hintsPartialSignature:
            throw HError.fromProtobuf("Unsupported transaction `HintsPartialSignatureTransaction`")
        case .historyProofSignature:
            throw HError.fromProtobuf("Unsupported transaction `HistoryProofSignatureTransaction`")
        case .historyProofKeyPublication:
            throw HError.fromProtobuf("Unsupported transaction `HistoryProofKeyPublicationTransaction`")
        case .historyProofVote:
            throw HError.fromProtobuf("Unsupported transaction `HistoryProofVoteTransaction`")
        case .crsPublication:
            throw HError.fromProtobuf("Unsupported transaction `CrsPublicationTransaction`")
        case .migrationRootHashVote:
            throw HError.fromProtobuf("Unsupported transaction `MigrationRootHashVoteTransaction`")
        }

        for transaction in iter {
            try value.append(transaction)
        }

        self = value
    }
}
