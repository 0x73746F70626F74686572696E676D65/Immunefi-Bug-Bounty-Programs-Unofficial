module github.com/google/docsy-example

go 1.12

require github.com/google/docsy v0.14.3

// cSpell:ignore github docsy
