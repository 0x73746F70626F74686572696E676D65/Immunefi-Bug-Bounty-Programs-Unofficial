// SPDX-License-Identifier: Apache-2.0
pragma solidity >=0.5.0 <0.9.0;

import {HederaResponseCodes} from '../../common/HederaResponseCodes.sol';
import {HederaTokenService} from '../../token-service/HederaTokenService.sol';
import {IHederaTokenService} from '../../token-service/IHederaTokenService.sol';
pragma experimental ABIEncoderV2;

/// @title Token Reject Contract
/// @notice Facilitates rejection of both fungible and non-fungible tokens on the Hedera network
/// @dev Implements token rejection functionality by building NFT structs and calling the rejectTokens system contract
///
/// Allows accounts to reject:
/// - Multiple fungible tokens in a single transaction
/// - Multiple NFTs in a single transaction
/// - Both fungible and non-fungible tokens together
contract TokenReject is HederaTokenService {
  /// @notice Rejects multiple fungible and non-fungible tokens for an account
  /// @dev Builds NFT ID structs and submits rejectTokens system contract call
  /// @param rejectingAddress The address rejecting the tokens
  /// @param ftAddresses Array of fungible token addresses to reject
  /// @param nftAddresses Array of NFT token addresses to reject
  /// @param serials Array of serial numbers corresponding to each NFT in nftAddresses
  /// @return responseCode The response code from the reject operation (22 = success)
  function rejectTokens(
    address rejectingAddress,
    address[] memory ftAddresses,
    address[] memory nftAddresses,
    int64[] memory serials
  ) public returns (int64 responseCode) {
    IHederaTokenService.NftID[] memory nftIDs = new IHederaTokenService.NftID[](
      nftAddresses.length
    );
    for (uint i; i < nftAddresses.length; i++) {
      IHederaTokenService.NftID memory nftId;
      nftId.nft = nftAddresses[i];
      nftId.serial = serials[i];
      nftIDs[i] = nftId;
    }
    responseCode = rejectTokens(rejectingAddress, ftAddresses, nftIDs);
    if (responseCode != HederaResponseCodes.SUCCESS) {
      revert();
    }
    return responseCode;
  }
}
