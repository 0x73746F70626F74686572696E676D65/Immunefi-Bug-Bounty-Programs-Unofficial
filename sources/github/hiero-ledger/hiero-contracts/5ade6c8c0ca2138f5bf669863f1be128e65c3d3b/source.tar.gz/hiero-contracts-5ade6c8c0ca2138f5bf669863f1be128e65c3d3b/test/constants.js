// SPDX-License-Identifier: Apache-2.0
import { network } from 'hardhat';
const { ethers } = await network.connect();
const Events = {
  Success: 'success',
  ResponseCode: 'ResponseCode',
  AllowanceValue: 'AllowanceValue',
  ApprovedAddress: 'ApprovedAddress',
  Approved: 'Approved',
  Frozen: 'Frozen',
  KycGranted: 'KycGranted',
  TokenCustomFees: 'TokenCustomFees',
  TokenDefaultFreezeStatus: 'TokenDefaultFreezeStatus',
  TokenDefaultKycStatus: 'TokenDefaultKycStatus',
  TokenExpiryInfo: 'TokenExpiryInfo',
  FungibleTokenInfo: 'FungibleTokenInfo',
  TokenInfo: 'TokenInfo',
  TokenKey: 'TokenKey',
  NonFungibleTokenInfo: 'NonFungibleTokenInfo',
  IsToken: 'IsToken',
  TokenType: 'TokenType',
  Approval: 'Approval',
  ApprovalForAll: 'ApprovalForAll',
  TokenCreated: 'TokenCreated',
  TokenCreatedEvent: 'tokenCreatedEvent',
  TokenInfoEvent: 'TokenInfoEvent',
  FungibleTokenInfoEvent: 'FungibleTokenInfoEvent',
  NftMinted: 'NftMinted',
  PausedToken: 'PausedToken',
  UnpausedToken: 'UnpausedToken',
  CreatedToken: 'CreatedToken',
  TransferToken: 'TransferToken',
  MintedToken: 'MintedToken',
  CallResponseEvent: 'CallResponseEvent',
  GetTokenInfo: 'GetTokenInfo',
  MintedNft: 'MintedNft',
  GetFungibleTokenInfo: 'GetFungibleTokenInfo',
  GetNonFungibleTokenInfo: 'GetNonFungibleTokenInfo',
  TinyBars: 'TinyBars',
  TinyCents: 'TinyCents',
  PseudoRandomSeed: 'PseudoRandomSeed',
  CryptoAllowance: 'CryptoAllowance',
  IsAssociated: 'IsAssociated',
};

const Contract = {
  ERC20Mock: 'ERC20Mock',
  ERC20Contract: 'ERC20Contract',
  ERC721Mock: 'ERC721Mock',
  ERC721ProxyMock: 'ERC721ProxyMock',
  TokenCreateContract: 'TokenCreateContract',
  ERC1155Mock: 'ERC1155Mock',
  ERC721Contract: 'ERC721Contract',
  TokenCreateCustomContract: 'TokenCreateCustomContract',
  TokenManagementContract: 'TokenManagementContract',
  TokenQueryContract: 'TokenQueryContract',
  TokenTransferContract: 'TokenTransferContract',
  HRC719Contract: 'HRC719Contract',
  ExchangeRateMock: 'ExchangeRateMock',
  PrngSystemContract: 'PrngSystemContract',
  CryptoAllowance: 'CryptoAllowance',
  CryptoOwner: 'CryptoOwner',
  Airdrop: 'Airdrop',
  ClaimAirdrop: 'ClaimAirdrop',
  TokenReject: 'TokenReject',
  AliasAccountUtility: 'AliasAccountUtility',
  CancelAirdrop: 'CancelAirdrop',
  InternalCallee: 'InternalCallee',
  Sample: 'contracts/mocks/Sample.sol:Sample',
};

const CALL_EXCEPTION = 'CALL_EXCEPTION';
const CONTRACT_REVERT_EXECUTED_CODE = 3;
const GAS_LIMIT_1_000_000 = { gasLimit: 1_000_000 };
const GAS_LIMIT_2_000_000 = { gasLimit: 2_000_000 };
const GAS_LIMIT_5_000_000 = { gasLimit: 5_000_000 };
const GAS_LIMIT_10_000_000 = { gasLimit: 10_000_000 };
const GAS_LIMIT_800000 = { gasLimit: 800000 };
const GAS_LIMIT_8000000 = { gasLimit: 8000000 };
const ONE_HBAR = ethers.parseEther('1');
const TOKEN_NAME = 'tokenName';
const TOKEN_SYMBOL = 'tokenSymbol';
const TOKEN_URL = 'tokenUrl';
const TX_SUCCESS_CODE = 22;
const SECOND = (ethers.WEI = 1);
const MINUTE = 60 * SECOND;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;
const WEEK = 7 * DAY;
const HTS_SYSTEM_CONTRACT_ID = '0.0.359';
const HAS_SYSTEM_CONTRACT_ID = '0.0.362';
const HTS_SYSTEM_CONTRACT_ADDRESS =
  '0x0000000000000000000000000000000000000167';
const HAS_SYSTEM_CONTRACT_ADDRESS =
  '0x000000000000000000000000000000000000016a';

export default {
  Events,
  Contract,
  CALL_EXCEPTION,
  CONTRACT_REVERT_EXECUTED_CODE,
  GAS_LIMIT_1_000_000,
  GAS_LIMIT_2_000_000,
  GAS_LIMIT_5_000_000,
  GAS_LIMIT_10_000_000,
  GAS_LIMIT_800000,
  GAS_LIMIT_8000000,
  ONE_HBAR,
  TOKEN_URL,
  TOKEN_NAME,
  TOKEN_SYMBOL,
  TX_SUCCESS_CODE,
  SECOND,
  MINUTE,
  HOUR,
  DAY,
  WEEK,
  WEI: ethers.WEI,
  GWEI: ethers.GWEI,
  HTS_SYSTEM_CONTRACT_ID,
  HAS_SYSTEM_CONTRACT_ID,
  HTS_SYSTEM_CONTRACT_ADDRESS,
  HAS_SYSTEM_CONTRACT_ADDRESS,
};
