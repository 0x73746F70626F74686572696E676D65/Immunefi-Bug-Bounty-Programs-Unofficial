// SPDX-License-Identifier: Apache-2.0

import { expect } from 'chai';
import { network } from 'hardhat';
const { ethers } = await network.connect();
import Constants from '../../constants';
import { pollForNewERC20Balance } from '../../helpers';
import hapi from '../hapi';
import utils from '../utils';

describe('TokenManagmentContract Test Suite', function () {
  const TX_SUCCESS_CODE = 22;
  const CUSTOM_SCHEDULE_ALREADY_HAS_NO_FEES = '244';
  const TOKEN_HAS_NO_FEE_SCHEDULE_KEY = '240';
  const CUSTOM_FEE_MUST_BE_POSITIVE = '239';
  const FRACTION_DIVIDES_BY_ZERO = '230';
  const CUSTOM_FEES_LIST_TOO_LONG = '232';
  const INVALID_CUSTOM_FEE_COLLECTOR = '233';
  const INVALID_TOKEN_ID_IN_CUSTOM_FEES = '234';
  const TOKEN_NOT_ASSOCIATED_TO_FEE_COLLECTOR = '235';

  let tokenCreateContract;
  let tokenQueryContract;
  let tokenManagmentContract;
  let tokenTransferContract;
  let tokenCreateCustomContract;
  let erc20Contract;
  let tokenAddress;
  let nftTokenAddress;
  let mintedTokenSerialNumber;
  let signers;
  let tokenInfoBefore;
  let keys;
  let holderA;
  let holderB;
  let holderC;
  let holderT;
  let holderS;
  let tokenCreateCustomContractAddress;
  let tokenCreateContractAddress;
  let tokenTransferContractAddress;
  let tokenQueryContractAddress;
  let tokenManagementContractAddress;

  /**
   * Asserts that a Hedera Token Service (HTS) transaction reverts and matches a specific HTS error string.
   *
   * @param {import('ethers').TransactionResponse} transaction - Tx object returned by a contract call.
   * @param {string} expectedError - ASCII HTS error identifier to match.
   * @param {string} expectedResponseCode - String containing response code string.
   * @returns {Promise<void>} Resolves when the assertion is completed.
   */
  const expectHTSError = async (
    transaction,
    expectedError,
    expectedResponseCode,
  ) => {
    await expect(transaction.wait()).to.eventually.be.rejected;

    const encodedResponse = await utils.getHTSResponseCode(transaction.hash);
    const responseCode = utils.hexToASCII(BigInt(encodedResponse).toString(16));
    expect(responseCode).to.equal(expectedError);

    const revertReason = await utils.getRevertReasonFromReceipt(
      transaction.hash,
    );
    const decodeRevertReason = utils.decodeErrorMessage(revertReason);

    // @todo Remove the code below once the consensus node issue is resolved.
    // See referenced task: https://github.com/hiero-ledger/hiero-consensus-node/issues/2377
    //
    // The response code from `contracts/results/{txId}` (`error_message`, via getRevertReasonFromReceipt)
    // should match the error from `contracts/results/{txId}/actions` (`revert_reason`, via getHTSResponseCode).
    // Currently, this is not the case for the revert reason `CUSTOM_FEES_LIST_TOO_LONG`.
    // Instead of the expected 232, we are receiving 21.
    // Code below allows both values as a temporary workaround and ensures the test
    // passes immediately once the consensus node issue is resolved, even before this logic is removed.
    if (expectedResponseCode === CUSTOM_FEES_LIST_TOO_LONG) {
      expect(decodeRevertReason).to.be.oneOf([expectedResponseCode, '21']);
      return;
    }

    expect(decodeRevertReason).to.be.equal(expectedResponseCode);
  };

  before(async function () {
    signers = await ethers.getSigners();
    tokenCreateContract = await utils.deployTokenCreateContract();
    tokenQueryContract = await utils.deployTokenQueryContract();
    tokenManagmentContract = await utils.deployTokenManagementContract();
    tokenTransferContract = await utils.deployTokenTransferContract();
    tokenCreateCustomContract = await utils.deployTokenCreateCustomContract();

    tokenCreateContractAddress = await tokenCreateContract.getAddress();
    tokenTransferContractAddress = await tokenTransferContract.getAddress();
    tokenQueryContractAddress = await tokenQueryContract.getAddress();
    tokenManagementContractAddress = await tokenManagmentContract.getAddress();
    tokenCreateCustomContractAddress =
      await tokenCreateCustomContract.getAddress();

    const contractKeys = [
      tokenCreateContractAddress,
      tokenTransferContractAddress,
      tokenManagementContractAddress,
      tokenQueryContractAddress,
      tokenCreateCustomContractAddress,
    ];
    holderA = ethers.getAddress(
      (await hapi.createAccountWithContractIdKey(contractKeys, 2000)).address,
    );
    holderB = ethers.getAddress(
      (await hapi.createAccountWithContractIdKey(contractKeys, 2000)).address,
    );
    holderC = ethers.getAddress(
      (await hapi.createAccountWithContractIdKey(contractKeys, 2000)).address,
    );
    holderT = ethers.getAddress(
      (await hapi.createAccountWithContractIdKey(contractKeys, 2000)).address,
    );
    holderS = ethers.getAddress(
      (await hapi.createAccountWithContractIdKey(contractKeys, 2000)).address,
    );
    erc20Contract = await utils.deployERC20Contract();
    tokenAddress = await utils.createFungibleTokenWithSECP256K1AdminKey(
      tokenCreateContract,
      holderS,
      utils.getSignerCompressedPublicKey(),
    );
    await hapi.updateTokenKeys(tokenAddress, [
      await tokenCreateContract.getAddress(),
      await tokenTransferContract.getAddress(),
      await tokenManagmentContract.getAddress(),
      await tokenQueryContract.getAddress(),
    ]);
    nftTokenAddress = await utils.createNonFungibleTokenWithSECP256K1AdminKey(
      tokenCreateContract,
      holderS,
      utils.getSignerCompressedPublicKey(),
    );
    await hapi.updateTokenKeys(nftTokenAddress, [
      await tokenCreateContract.getAddress(),
      await tokenTransferContract.getAddress(),
      await tokenManagmentContract.getAddress(),
      await tokenQueryContract.getAddress(),
    ]);
    await utils.associateToken(tokenCreateContract, tokenAddress);
    await utils.grantTokenKyc(tokenCreateContract, tokenAddress);
    await utils.associateToken(tokenCreateContract, nftTokenAddress);
    await utils.grantTokenKyc(tokenCreateContract, nftTokenAddress);
    mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );

    await utils.associateAndGrantKyc(tokenCreateContract, tokenAddress, [
      holderA,
      holderB,
      holderC,
    ]);
    await utils.associateAndGrantKyc(tokenCreateContract, nftTokenAddress, [
      holderA,
      holderB,
      holderC,
    ]);
  });

  after(function () {
    hapi.client.close();
  });

  it('should be able to delete token', async function () {
    const newTokenAddress =
      await utils.createFungibleTokenWithSECP256K1AdminKey(
        tokenCreateContract,
        holderS,
        utils.getSignerCompressedPublicKey(),
      );
    await hapi.updateTokenKeys(newTokenAddress, [
      await tokenCreateContract.getAddress(),
      await tokenManagmentContract.getAddress(),
      await tokenQueryContract.getAddress(),
    ]);
    const txBefore =
      await tokenQueryContract.getTokenInfoPublic(newTokenAddress);
    const tokenInfoBefore = (await txBefore.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenInfo,
    )[0].args.tokenInfo;

    const tx = await tokenManagmentContract.deleteTokenPublic(newTokenAddress);
    await tx.wait();

    const txAfter = await tokenQueryContract.getTokenInfoPublic(
      newTokenAddress,
      Constants.GAS_LIMIT_1_000_000,
    );
    const tokenInfoAfter = (await txAfter.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenInfo,
    )[0].args.tokenInfo;

    expect(tokenInfoBefore.deleted).to.equal(false);
    expect(tokenInfoAfter.deleted).to.equal(true);
  });

  it('should be able to freeze and unfreeze token', async function () {
    const freezeTx = await tokenManagmentContract.freezeTokenPublic(
      tokenAddress,
      await tokenCreateContract.getAddress(),
    );
    const isFrozenTx = await tokenQueryContract.isFrozenPublic(
      tokenAddress,
      await tokenCreateContract.getAddress(),
      Constants.GAS_LIMIT_1_000_000,
    );
    const responseCodeFreeze = (await freezeTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;
    const responseCodeisFrozen = (await isFrozenTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;
    const isFrozen = (await isFrozenTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.Frozen,
    )[0].args.frozen;

    expect(responseCodeFreeze).to.equal(TX_SUCCESS_CODE);
    expect(responseCodeisFrozen).to.equal(TX_SUCCESS_CODE);
    expect(isFrozen).to.equal(true);

    const unfreezeTx = await tokenManagmentContract.unfreezeTokenPublic(
      tokenAddress,
      await tokenCreateContract.getAddress(),
    );
    const isStillFrozenTx = await tokenQueryContract.isFrozenPublic(
      tokenAddress,
      await tokenCreateContract.getAddress(),
      Constants.GAS_LIMIT_1_000_000,
    );
    const responseCodeUnfreeze = (await unfreezeTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;
    const responseCodeisStillFrozen = (
      await isStillFrozenTx.wait()
    ).logs.filter((e) => e.fragment.name === Constants.Events.ResponseCode)[0]
      .args.responseCode;
    const isStillFrozen = (await isStillFrozenTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.Frozen,
    )[0].args.frozen;

    expect(responseCodeUnfreeze).to.equal(TX_SUCCESS_CODE);
    expect(responseCodeisStillFrozen).to.equal(TX_SUCCESS_CODE);
    expect(isStillFrozen).to.equal(false);
  });

  it('should be able to wipe token', async function () {
    const wipeAmount = 3;

    await tokenTransferContract.transferTokensPublic(
      tokenAddress,
      [holderS, holderA],
      [-wipeAmount, wipeAmount],
    );

    const balanceBefore = await pollForNewERC20Balance(
      erc20Contract,
      tokenAddress,
      holderA,
      0n,
    );

    const tx = await tokenManagmentContract.wipeTokenAccountPublic(
      tokenAddress,
      holderA,
      wipeAmount,
    );

    const responseCode = (await tx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    const balanceAfter = await pollForNewERC20Balance(
      erc20Contract,
      tokenAddress,
      holderA,
      balanceBefore,
    );

    expect(responseCode).to.equal(TX_SUCCESS_CODE);
    expect(Number(balanceAfter.toString())).to.equal(
      Number(balanceBefore.toString()) - wipeAmount,
    );
  });

  it('should be able to remove token kyc', async function () {
    const revokeKycTx = await tokenManagmentContract.revokeTokenKycPublic(
      tokenAddress,
      await tokenCreateContract.getAddress(),
    );
    const isKycTx = await tokenQueryContract.isKycPublic(
      tokenAddress,
      await tokenCreateContract.getAddress(),
      Constants.GAS_LIMIT_1_000_000,
    );
    const revokeKycResponseCode = (await revokeKycTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;
    const isKycResponseCode = (await isKycTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;
    const isKyc = (await isKycTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.KycGranted,
    )[0].args.kycGranted;

    expect(revokeKycResponseCode).to.equal(TX_SUCCESS_CODE);
    expect(isKycResponseCode).to.equal(TX_SUCCESS_CODE);
    expect(isKyc).to.equal(false);

    await utils.grantTokenKyc(tokenCreateContract, tokenAddress);
  });

  it('should be able to pause and unpause token', async function () {
    const pauseTokenTx =
      await tokenManagmentContract.pauseTokenPublic(tokenAddress);
    const pauseTokenResponseCode = (await pauseTokenTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    expect(pauseTokenResponseCode).to.equal(TX_SUCCESS_CODE);

    const unpauseTokenTx =
      await tokenManagmentContract.unpauseTokenPublic(tokenAddress);
    const uppauseTokenResponseCode = (await unpauseTokenTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    expect(uppauseTokenResponseCode).to.equal(TX_SUCCESS_CODE);
  });

  it('should be able to wipe token account NFT', async function () {
    await tokenTransferContract.transferNFTPublic(
      nftTokenAddress,
      holderS,
      holderA,
      mintedTokenSerialNumber,
    );
    const tx = await tokenManagmentContract.wipeTokenAccountNFTPublic(
      nftTokenAddress,
      holderA,
      [mintedTokenSerialNumber],
    );
    const responseCode = (await tx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    expect(responseCode).to.equal(TX_SUCCESS_CODE);
  });

  it('should be able to update token info', async function () {
    const TOKEN_UPDATE_NAME = 'tokenUpdateName';
    const TOKEN_UPDATE_SYMBOL = 'tokenUpdateSymbol';
    const TOKEN_UPDATE_MEMO = 'tokenUpdateMemo';

    const txBeforeInfo =
      await tokenQueryContract.getTokenInfoPublic(tokenAddress);
    const tokenInfoBefore = (await txBeforeInfo.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenInfo,
    )[0].args.tokenInfo[0];
    const responseCodeTokenInfoBefore = (await txBeforeInfo.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    const token = {
      name: TOKEN_UPDATE_NAME,
      symbol: TOKEN_UPDATE_SYMBOL,
      memo: TOKEN_UPDATE_MEMO,
      treasury: holderS, // must be an account the contract may act for
      tokenSupplyType: tokenInfoBefore.tokenSupplyType,
      maxSupply: tokenInfoBefore.maxSupply,
      freezeDefault: tokenInfoBefore.freezeDefault,
      tokenKeys: [],
      expiry: {
        second: 0,
        autoRenewAccount: tokenInfoBefore.expiry[1],
        autoRenewPeriod: 0,
      },
    };

    const txUpdate = await tokenManagmentContract.updateTokenInfoPublic(
      tokenAddress,
      token,
      Constants.GAS_LIMIT_1_000_000,
    );

    expect(
      (await txUpdate.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode,
    ).to.be.equal(TX_SUCCESS_CODE);

    const txAfterInfo =
      await tokenQueryContract.getTokenInfoPublic(tokenAddress);

    const tokenInfoAfter = (await txAfterInfo.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenInfo,
    )[0].args.tokenInfo[0];
    const responseCodeTokenInfoAfter = (await txAfterInfo.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    expect(responseCodeTokenInfoBefore).to.equal(TX_SUCCESS_CODE);
    expect(responseCodeTokenInfoAfter).to.equal(TX_SUCCESS_CODE);
    expect(tokenInfoAfter.name).to.equal(TOKEN_UPDATE_NAME);
    expect(tokenInfoAfter.symbol).to.equal(TOKEN_UPDATE_SYMBOL);
    expect(tokenInfoAfter.memo).to.equal(TOKEN_UPDATE_MEMO);
  });

  it('should be able to update token expiry info', async function () {
    const AUTO_RENEW_PERIOD = 8000000;
    const NEW_AUTO_RENEW_PERIOD = 7999900;
    const AUTO_RENEW_SECOND = 0;
    const epoch = parseInt(
      (Date.now() / 1000 + NEW_AUTO_RENEW_PERIOD).toFixed(0),
    );

    const getTokenExpiryInfoTxBefore =
      await tokenQueryContract.getTokenExpiryInfoPublic(
        tokenAddress,
        Constants.GAS_LIMIT_1_000_000,
      );
    const responseCode = (await getTokenExpiryInfoTxBefore.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;
    const tokenExpiryInfoBefore = (
      await getTokenExpiryInfoTxBefore.wait()
    ).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenExpiryInfo,
    )[0].args.expiryInfo;

    expect(responseCode).to.equal(TX_SUCCESS_CODE);
    expect(tokenExpiryInfoBefore.autoRenewPeriod).to.equal(AUTO_RENEW_PERIOD);

    const expiryInfo = {
      second: AUTO_RENEW_SECOND,
      autoRenewAccount: `${holderS}`,
      autoRenewPeriod: NEW_AUTO_RENEW_PERIOD,
    };

    const updateTokenExpiryInfoTx =
      await tokenManagmentContract.updateTokenExpiryInfoPublic(
        tokenAddress,
        expiryInfo,
        Constants.GAS_LIMIT_1_000_000,
      );
    const updateExpiryInfoResponseCode = (
      await updateTokenExpiryInfoTx.wait()
    ).logs.filter((e) => e.fragment.name === Constants.Events.ResponseCode)[0]
      .args.responseCode;

    // get updated expiryInfo
    const getTokenExpiryInfoTxAfter =
      await tokenQueryContract.getTokenExpiryInfoPublic(
        tokenAddress,
        Constants.GAS_LIMIT_1_000_000,
      );
    const getExpiryInfoResponseCode = (
      await getTokenExpiryInfoTxAfter.wait()
    ).logs.filter((e) => e.fragment.name === Constants.Events.ResponseCode)[0]
      .args.responseCode;
    const tokenExpiryInfoAfter = (
      await getTokenExpiryInfoTxAfter.wait()
    ).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenExpiryInfo,
    )[0].args.expiryInfo;

    expect(updateExpiryInfoResponseCode).to.equal(TX_SUCCESS_CODE);
    expect(getExpiryInfoResponseCode).to.equal(TX_SUCCESS_CODE);
    expect(tokenExpiryInfoAfter.autoRenewPeriod).to.equal(
      expiryInfo.autoRenewPeriod,
    );
    expect(tokenExpiryInfoAfter.second).to.be.closeTo(epoch, 300);
  });

  it('should be able to update token keys', async function () {
    const getKeyTx = await tokenQueryContract.getTokenKeyPublic(
      tokenAddress,
      2,
      Constants.GAS_LIMIT_1_000_000,
    );
    const originalKey = (await getKeyTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenKey,
    )[0].args.key;
    const updateKey = [
      false,
      '0x0000000000000000000000000000000000000000',
      '0x',
      '0x03dfcc94dfd843649cc594ada5ac6627031454602aa190223f996de25a05828f36',
      '0x0000000000000000000000000000000000000000',
    ];

    const updateTx = await tokenManagmentContract.updateTokenKeysPublic(
      tokenAddress,
      [[2, updateKey]],
    );
    const updateResponseCode = (await updateTx.wait()).logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args.responseCode;

    // Assert updated key
    const tx = await tokenQueryContract.getTokenKeyPublic(
      tokenAddress,
      2,
      Constants.GAS_LIMIT_1_000_000,
    );
    const result = await tx.wait();
    const { responseCode } = result.logs.filter(
      (e) => e.fragment.name === Constants.Events.ResponseCode,
    )[0].args;
    const updatedKey = result.logs.filter(
      (e) => e.fragment.name === Constants.Events.TokenKey,
    )[0].args.key;

    expect(responseCode).to.equal(TX_SUCCESS_CODE);
    expect(updateResponseCode).to.equal(TX_SUCCESS_CODE);

    expect(updatedKey).to.exist;
    expect(updatedKey.inheritAccountKey).to.eq(updateKey[0]);
    expect(updatedKey.contractId).to.eq(updateKey[1]);
    expect(updatedKey.ed25519).to.eq(updateKey[2]);
    expect(updatedKey.ECDSA_secp256k1).to.eq(updateKey[3]);
    expect(updatedKey.delegatableContractId).to.eq(updateKey[4]);
    expect(updatedKey.ECDSA_secp256k1).to.not.eq(originalKey.ECDSA_secp256k1);
  });

  it('should be able to burn token', async function () {
    const amount = BigInt(111);
    const totalSupplyBefore = await erc20Contract.totalSupply(tokenAddress);
    const balanceBefore = await erc20Contract.balanceOf(tokenAddress, holderS);
    await tokenManagmentContract.burnTokenPublic(tokenAddress, amount, []);

    const balanceAfter = await pollForNewERC20Balance(
      erc20Contract,
      tokenAddress,
      holderS,
      balanceBefore,
    );
    const totalSupplyAfter = await erc20Contract.totalSupply(tokenAddress);

    expect(totalSupplyAfter).to.equal(totalSupplyBefore - amount);
    expect(balanceAfter).to.equal(balanceBefore - amount);
  });

  it('should be able to dissociate tokens', async function () {
    const signers = await ethers.getSigners();
    const tokenCreateContractWallet2 = tokenCreateContract.connect(signers[1]);
    const tokenManagmentContractWallet2 = tokenManagmentContract.connect(
      signers[1],
    );

    const txDisassociate =
      await tokenManagmentContractWallet2.dissociateTokensPublic(
        holderC,
        [tokenAddress],
        Constants.GAS_LIMIT_1_000_000,
      );
    const receiptDisassociate = await txDisassociate.wait();
    expect(
      receiptDisassociate.logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode,
    ).to.equal(22);

    const txAssociate = await tokenCreateContractWallet2.associateTokensPublic(
      holderC,
      [tokenAddress],
      Constants.GAS_LIMIT_1_000_000,
    );
    const receiptAssociate = await txAssociate.wait();
    expect(
      receiptAssociate.logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode,
    ).to.equal(22);
  });

  it('should be able to dissociate token', async function () {
    const signers = await ethers.getSigners();
    const tokenCreateContractWallet2 = tokenCreateContract.connect(signers[1]);
    const tokenManagmentContractWallet2 = tokenManagmentContract.connect(
      signers[1],
    );

    const txDisassociate =
      await tokenManagmentContractWallet2.dissociateTokenPublic(
        holderC,
        tokenAddress,
        Constants.GAS_LIMIT_1_000_000,
      );
    const receiptDisassociate = await txDisassociate.wait();
    expect(
      receiptDisassociate.logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode,
    ).to.equal(22);

    const txAssociate = await tokenCreateContractWallet2.associateTokenPublic(
      holderC,
      tokenAddress,
      Constants.GAS_LIMIT_1_000_000,
    );
    const receiptAssociate = await txAssociate.wait();
    expect(
      receiptAssociate.logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode,
    ).to.equal(22);
  });

  describe('Extended update token info and keys test suite', function () {
    async function getTokenInfo(contract, token) {
      const txBeforeInfo = await contract.getTokenInfoPublic(token);
      const tokenInfo = (await txBeforeInfo.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo[0];
      expect(
        (await txBeforeInfo.wait()).logs.filter(
          (e) => e.fragment.name === Constants.Events.ResponseCode,
        )[0].args.responseCode,
      ).to.eq(TX_SUCCESS_CODE);
      return tokenInfo;
    }

    async function updateTokenInfo(contract, token, updateInfo) {
      const txUpdate = await contract.updateTokenInfoPublic(
        token,
        updateInfo,
        Constants.GAS_LIMIT_1_000_000,
      );
      expect(
        (await txUpdate.wait()).logs.filter(
          (e) => e.fragment.name === Constants.Events.ResponseCode,
        )[0].args.responseCode,
      ).to.be.equal(TX_SUCCESS_CODE);
    }

    function updateTokenInfoValues(keyValueType, key) {
      const updatedKey = [
        false,
        '0x0000000000000000000000000000000000000000',
        '0x',
        '0x',
        '0x0000000000000000000000000000000000000000',
      ];

      switch (keyValueType) {
        case utils.KeyValueType.CONTRACT_ID:
          updatedKey[1] = key;
          break;
        case utils.KeyValueType.SECP256K1:
          updatedKey[3] = key;
          break;
        case utils.KeyValueType.DELEGETABLE_CONTRACT_ID:
          updatedKey[4] = key;
          break;
        default:
          break;
      }

      return updatedKey;
    }

    describe('Admin key set to ECDSA_secp256k', function () {
      before(async function () {
        tokenAddress = await utils.createFungibleTokenWithSECP256K1AdminKey(
          tokenCreateContract,
          holderS,
          utils.getSignerCompressedPublicKey(),
        );
        await hapi.updateTokenKeys(tokenAddress, [
          await tokenCreateContract.getAddress(),
          await tokenTransferContract.getAddress(),
          await tokenManagmentContract.getAddress(),
          await tokenQueryContract.getAddress(),
        ]);
        tokenInfoBefore = await getTokenInfo(tokenQueryContract, tokenAddress);

        await utils.associateToken(tokenCreateContract, tokenAddress);
        await utils.grantTokenKyc(tokenCreateContract, tokenAddress);
        await utils.associateAndGrantKyc(tokenCreateContract, tokenAddress, [
          holderA,
          holderB,
        ]);
      });

      it('should be able to change PAUSE key to contractId and pause the token with same contract', async function () {
        //Update token info
        {
          const contractId = await tokenManagmentContract.getAddress();
          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            contractId,
          );

          const token = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.PAUSE, updatedKey]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          await updateTokenInfo(tokenManagmentContract, tokenAddress, token);
        }

        //Pause and unpause token
        {
          const pauseTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .pauseTokenPublic(tokenAddress);

          await pauseTokenTx.wait();

          const unpauseTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .unpauseTokenPublic(tokenAddress);

          await unpauseTokenTx.wait();

          expect(
            (await pauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.PausedToken,
            )[0].args.paused,
          ).to.eq(true);
          expect(
            (await unpauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.UnpausedToken,
            )[0].args.unpaused,
          ).to.eq(true);
          expect(
            (await pauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
          expect(
            (await unpauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        }

        //Revert previous update token info
        {
          const updatedKeyAfter = updateTokenInfoValues(
            utils.KeyValueType.SECP256K1,
            utils.getSignerCompressedPublicKey(),
          );

          const tokenAfter = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.PAUSE, updatedKeyAfter]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          tokenAfter.treasury = holderS;
          await updateTokenInfo(
            tokenManagmentContract,
            tokenAddress,
            tokenAfter,
          );
        }
      });

      it('should not be able to pause the token with different PAUSE key', async function () {
        const pauseTokenTx = await tokenManagmentContract
          .connect(signers[1])
          .pauseTokenPublic(tokenAddress);
        const unpauseTokenTx = await tokenManagmentContract
          .connect(signers[1])
          .unpauseTokenPublic(tokenAddress);

        await utils.expectToFail(pauseTokenTx, Constants.CALL_EXCEPTION);
        await utils.expectToFail(unpauseTokenTx, Constants.CALL_EXCEPTION);
      });

      it('should be able to change WIPE key to contractId and wipe the token with same contract', async function () {
        //Update token info
        {
          const contractId = await tokenManagmentContract.getAddress();
          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            contractId,
          );

          const token = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.WIPE, updatedKey]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          await updateTokenInfo(tokenManagmentContract, tokenAddress, token);
        }

        //Wipe token
        {
          const wipeAmount = BigInt(3);
          await tokenTransferContract.transferTokensPublic(
            tokenAddress,
            [holderS, holderA],
            [-wipeAmount, wipeAmount],
          );

          const balanceBefore = await pollForNewERC20Balance(
            erc20Contract,
            tokenAddress,
            holderA,
            0n,
          );

          const tx = await tokenManagmentContract
            .connect(signers[1])
            .wipeTokenAccountPublic(tokenAddress, holderA, wipeAmount);

          const balanceAfter = await pollForNewERC20Balance(
            erc20Contract,
            tokenAddress,
            holderA,
            balanceBefore,
          );

          expect(balanceAfter).to.eq(balanceBefore - wipeAmount);
          expect(
            (await tx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        }

        //Revert previous update token info
        {
          const updatedKeyAfter = updateTokenInfoValues(
            utils.KeyValueType.SECP256K1,
            utils.getSignerCompressedPublicKey(),
          );

          const tokenAfter = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.WIPE, updatedKeyAfter]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          tokenAfter.treasury = holderS;
          await updateTokenInfo(
            tokenManagmentContract,
            tokenAddress,
            tokenAfter,
          );
        }
      });

      it('should not be able to wipe the token with different WIPE key', async function () {
        const wipeAmount = 3;
        await tokenTransferContract.transferTokensPublic(
          tokenAddress,
          [holderS, holderA],
          [-wipeAmount, wipeAmount],
        );

        // await until the new balance is settled for signers[1]
        await pollForNewERC20Balance(erc20Contract, tokenAddress, holderA, 0n);

        const wipeTokenTx = await tokenManagmentContract
          .connect(signers[1])
          .wipeTokenAccountPublic(tokenAddress, holderA, wipeAmount);
        await utils.expectToFail(wipeTokenTx, Constants.CALL_EXCEPTION);
      });

      it('should be able to change FREEZE key to contractId and freeze the token with same contract', async function () {
        //Update token info
        {
          const contractId = await tokenManagmentContract.getAddress();
          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            contractId,
          );

          const token = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.FREEZE, updatedKey]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          token.treasury = holderS;

          await updateTokenInfo(tokenManagmentContract, tokenAddress, token);
        }

        //Freeze and unfreeze token
        {
          const freezeTx = await tokenManagmentContract
            .connect(signers[1])
            .freezeTokenPublic(
              tokenAddress,
              await tokenCreateContract.getAddress(),
            );
          const isFrozenTxBefore = await tokenQueryContract.isFrozenPublic(
            tokenAddress,
            await tokenCreateContract.getAddress(),
            Constants.GAS_LIMIT_1_000_000,
          );

          const unfreezeTx = await tokenManagmentContract
            .connect(signers[1])
            .unfreezeTokenPublic(
              tokenAddress,
              await tokenCreateContract.getAddress(),
            );
          const isFrozenTxAfter = await tokenQueryContract.isFrozenPublic(
            tokenAddress,
            await tokenCreateContract.getAddress(),
            Constants.GAS_LIMIT_1_000_000,
          );

          expect(
            (await isFrozenTxBefore.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.Frozen,
            )[0].args.frozen,
          ).to.eq(true);
          expect(
            (await isFrozenTxAfter.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.Frozen,
            )[0].args.frozen,
          ).to.eq(false);

          expect(
            (await freezeTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
          expect(
            (await unfreezeTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        }

        //Revert previous update token info
        {
          const updatedKeyAfter = updateTokenInfoValues(
            utils.KeyValueType.SECP256K1,
            utils.getSignerCompressedPublicKey(),
          );

          const tokenAfter = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.FREEZE, updatedKeyAfter]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          tokenAfter.treasury = holderS;
          await updateTokenInfo(
            tokenManagmentContract,
            tokenAddress,
            tokenAfter,
          );
        }
      });

      it('should not be able to freeze the token with different FREEZE key', async function () {
        const freezeTokenTx = await tokenManagmentContract
          .connect(signers[1])
          .freezeTokenPublic(
            tokenAddress,
            await tokenCreateContract.getAddress(),
          );
        const unfreezeTokenTx = await tokenManagmentContract
          .connect(signers[1])
          .unfreezeTokenPublic(
            tokenAddress,
            await tokenCreateContract.getAddress(),
            Constants.GAS_LIMIT_1_000_000,
          );

        await utils.expectToFail(freezeTokenTx, Constants.CALL_EXCEPTION);
        await utils.expectToFail(unfreezeTokenTx, Constants.CALL_EXCEPTION);
      });

      it('should be able to change ADMIN key to contractId and perform admin action with same contract', async function () {
        //Update token info
        {
          const contractId = await tokenManagmentContract.getAddress();

          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            contractId,
          );

          const token = {
            name: tokenInfoBefore.name,
            symbol: tokenInfoBefore.symbol,
            memo: tokenInfoBefore.memo,
            treasury: holderS, // must be an account the contract may act for
            tokenSupplyType: tokenInfoBefore.tokenSupplyType,
            maxSupply: tokenInfoBefore.maxSupply,
            freezeDefault: tokenInfoBefore.freezeDefault,
            tokenKeys: [[utils.KeyType.ADMIN, updatedKey]],
            expiry: {
              second: 0,
              autoRenewAccount: tokenInfoBefore.expiry[1],
              autoRenewPeriod: 0,
            },
          };

          token.treasury = holderS;

          await updateTokenInfo(tokenManagmentContract, tokenAddress, token);
        }

        //Change supply key with admin contract
        {
          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            await tokenTransferContract.getAddress(),
          );

          const keyTxBefore = await tokenQueryContract.getTokenKeyPublic(
            tokenAddress,
            utils.KeyType.SUPPLY,
            Constants.GAS_LIMIT_1_000_000,
          );
          const keyBefore = (await keyTxBefore.wait()).logs.filter(
            (e) => e.fragment.name === Constants.Events.TokenKey,
          )[0].args.key;

          const updateTokenKeyTx = await tokenManagmentContract
            .connect(signers[1])
            .updateTokenKeysPublic(tokenAddress, [
              [utils.KeyType.SUPPLY, updatedKey],
            ]);

          const keyTxAfter = await tokenQueryContract.getTokenKeyPublic(
            tokenAddress,
            utils.KeyType.SUPPLY,
            Constants.GAS_LIMIT_1_000_000,
          );
          const keyAfter = (await keyTxAfter.wait()).logs.filter(
            (e) => e.fragment.name === Constants.Events.TokenKey,
          )[0].args.key;

          expect(keyBefore[1]).to.not.eq(keyAfter[1]);
          expect(
            (await updateTokenKeyTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        }
      });

      it('should be able to perform admin action with TokenManagementContract as ADMIN key', async function () {
        const updatedKey = updateTokenInfoValues(
          utils.KeyValueType.CONTRACT_ID,
          await tokenTransferContract.getAddress(),
        );
        const updateTokenKeyTx = await tokenManagmentContract
          .connect(signers[1])
          .updateTokenKeysPublic(tokenAddress, [
            [utils.KeyType.SUPPLY, updatedKey],
          ]);

        expect(
          (await updateTokenKeyTx.wait()).logs.filter(
            (e) => e.fragment.name === Constants.Events.ResponseCode,
          )[0].args.responseCode,
        ).to.eq(TX_SUCCESS_CODE);
      });
    });

    describe('Admin key set to contractId', function () {
      before(async function () {
        tokenAddress = await utils.createFungibleTokenWithSECP256K1AdminKey(
          tokenCreateContract,
          holderS,
          utils.getSignerCompressedPublicKey(),
        );

        await hapi.updateTokenKeys(tokenAddress, [
          await tokenCreateContract.getAddress(),
          await tokenTransferContract.getAddress(),
          await tokenManagmentContract.getAddress(),
          await tokenQueryContract.getAddress(),
        ]);

        tokenInfoBefore = await getTokenInfo(tokenQueryContract, tokenAddress);

        await utils.associateToken(tokenCreateContract, tokenAddress);

        await utils.grantTokenKyc(tokenCreateContract, tokenAddress);
        await utils.associateAndGrantKyc(tokenCreateContract, tokenAddress, [
          holderA,
          holderB,
        ]);
      });
      describe('Positive', function () {
        it('should be able to change PAUSE key to ECDSA_secp256k and pause the token with the same account', async function () {
          await hapi.updateTokenKeys(
            tokenAddress,
            [await tokenManagmentContract.getAddress()],
            false,
            true,
            false,
            false,
            false,
            false,
          );

          const pauseTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .pauseTokenPublic(tokenAddress);
          const unpauseTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .unpauseTokenPublic(tokenAddress);

          expect(
            (await pauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.PausedToken,
            )[0].args.paused,
          ).to.eq(true);
          expect(
            (await unpauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.UnpausedToken,
            )[0].args.unpaused,
          ).to.eq(true);
          expect(
            (await pauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
          expect(
            (await unpauseTokenTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        });

        it('should be able to change WIPE key to ECDSA_secp256k and wipe the token with the same account', async function () {
          await hapi.updateTokenKeys(
            tokenAddress,
            [await tokenManagmentContract.getAddress()],
            false,
            false,
            false,
            false,
            false,
            true,
          );
          const wipeAmount = 3;
          await tokenTransferContract.transferTokensPublic(
            tokenAddress,
            [holderS, holderA],
            [-wipeAmount, wipeAmount],
            Constants.GAS_LIMIT_1_000_000,
          );

          const balanceBefore = await pollForNewERC20Balance(
            erc20Contract,
            tokenAddress,
            holderA,
            0n,
          );

          const tx = await tokenManagmentContract
            .connect(signers[1])
            .wipeTokenAccountPublic(tokenAddress, holderA, wipeAmount);

          const balanceAfter = await pollForNewERC20Balance(
            erc20Contract,
            tokenAddress,
            holderA,
            balanceBefore,
          );

          expect(balanceAfter).to.eq(balanceBefore - BigInt(wipeAmount));
          expect(
            (await tx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        });

        it('should be able to change FREEZE key to ECDSA_secp256k and freeze the token with the same account', async function () {
          await hapi.updateTokenKeys(
            tokenAddress,
            [await tokenManagmentContract.getAddress()],
            false,
            false,
            false,
            true,
            false,
            false,
          );
          const freezeTx = await tokenManagmentContract
            .connect(signers[1])
            .freezeTokenPublic(
              tokenAddress,
              await tokenCreateContract.getAddress(),
              Constants.GAS_LIMIT_1_000_000,
            );
          const isFrozenTxBefore = await tokenQueryContract.isFrozenPublic(
            tokenAddress,
            await tokenCreateContract.getAddress(),
            Constants.GAS_LIMIT_1_000_000,
          );

          const unfreezeTx = await tokenManagmentContract
            .connect(signers[1])
            .unfreezeTokenPublic(
              tokenAddress,
              await tokenCreateContract.getAddress(),
              Constants.GAS_LIMIT_1_000_000,
            );
          const isFrozenTxAfter = await tokenQueryContract.isFrozenPublic(
            tokenAddress,
            await tokenCreateContract.getAddress(),
            Constants.GAS_LIMIT_1_000_000,
          );

          expect(
            (await isFrozenTxBefore.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.Frozen,
            )[0].args.frozen,
          ).to.eq(true);
          expect(
            (await isFrozenTxAfter.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.Frozen,
            )[0].args.frozen,
          ).to.eq(false);

          expect(
            (await freezeTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
          expect(
            (await unfreezeTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        });

        it('should be able to change ADMIN key to ECDSA_secp256k and perform admin action with same contract', async function () {
          await hapi.updateTokenKeys(
            tokenAddress,
            [await tokenManagmentContract.getAddress()],
            true,
            false,
            false,
            false,
            false,
            false,
          );
          const keyTxBefore = await tokenQueryContract.getTokenKeyPublic(
            tokenAddress,
            utils.KeyType.SUPPLY,
            Constants.GAS_LIMIT_1_000_000,
          );
          const keyBefore = (await keyTxBefore.wait()).logs.filter(
            (e) => e.fragment.name === Constants.Events.TokenKey,
          )[0].args.key;
          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            await tokenTransferContract.getAddress(),
          );
          const updateTokenKeyTx = await tokenManagmentContract
            .connect(signers[0])
            .updateTokenKeysPublic(tokenAddress, [
              [utils.KeyType.SUPPLY, updatedKey],
            ]);
          const keyTxAfter = await tokenQueryContract.getTokenKeyPublic(
            tokenAddress,
            utils.KeyType.SUPPLY,
            Constants.GAS_LIMIT_1_000_000,
          );
          const keyAfter = (await keyTxAfter.wait()).logs.filter(
            (e) => e.fragment.name === Constants.Events.TokenKey,
          )[0].args.key;

          expect(keyBefore[1]).to.not.eq(keyAfter[1]);
          expect(
            (await updateTokenKeyTx.wait()).logs.filter(
              (e) => e.fragment.name === Constants.Events.ResponseCode,
            )[0].args.responseCode,
          ).to.eq(TX_SUCCESS_CODE);
        });
      });
      describe('Negative', function () {
        before(async function () {
          tokenAddress = await utils.createFungibleTokenWithSECP256K1AdminKey(
            tokenCreateContract,
            holderS,
            utils.getSignerCompressedPublicKey(),
          );
        });
        it('should not be able to pause the token with different PAUSE key', async function () {
          const pauseTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .pauseTokenPublic(tokenAddress);
          const unpauseTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .unpauseTokenPublic(tokenAddress);

          await utils.expectToFail(pauseTokenTx, Constants.CALL_EXCEPTION);
          await utils.expectToFail(unpauseTokenTx, Constants.CALL_EXCEPTION);
        });

        it('should not be able to wipe the token with different WIPE key', async function () {
          const wipeAmount = 3;

          await hapi.updateTokenKeys(tokenAddress, [
            await tokenCreateContract.getAddress(),
          ]);

          await utils.associateToken(tokenCreateContract, tokenAddress);
          await utils.grantTokenKyc(tokenCreateContract, tokenAddress);
          await utils.associateAndGrantKyc(tokenCreateContract, tokenAddress, [
            holderA,
            holderB,
          ]);

          await tokenTransferContract.transferTokensPublic(
            tokenAddress,
            [holderS, holderA],
            [-wipeAmount, wipeAmount],
            Constants.GAS_LIMIT_1_000_000,
          );

          // await until the new balance is settled for signers[1]
          await pollForNewERC20Balance(
            erc20Contract,
            tokenAddress,
            holderA,
            0n,
          );

          const wipeTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .wipeTokenAccountPublic(tokenAddress, holderA, wipeAmount);
          await utils.expectToFail(wipeTokenTx, Constants.CALL_EXCEPTION);
        });

        it('should not be able to freeze the token with different FREEZE key', async function () {
          const freezeTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .freezeTokenPublic(
              tokenAddress,
              await tokenCreateContract.getAddress(),
            );
          const unfreezeTokenTx = await tokenManagmentContract
            .connect(signers[1])
            .unfreezeTokenPublic(
              tokenAddress,
              await tokenCreateContract.getAddress(),
            );

          await utils.expectToFail(freezeTokenTx, Constants.CALL_EXCEPTION);
          await utils.expectToFail(unfreezeTokenTx, Constants.CALL_EXCEPTION);
        });

        it('should not be able to perform admin action with different ADMIN key', async function () {
          const updatedKey = updateTokenInfoValues(
            utils.KeyValueType.CONTRACT_ID,
            await tokenTransferContract.getAddress(),
          );
          const updateTokenKeyTx = await tokenManagmentContract
            .connect(signers[1])
            .updateTokenKeysPublic(tokenAddress, [
              [utils.KeyType.SUPPLY, updatedKey],
            ]);
          await utils.expectToFail(updateTokenKeyTx, Constants.CALL_EXCEPTION);
        });
      });
    });
  });

  describe('Update fees', function () {
    let feeToken;
    let tokenWithFees;
    let tenHbars;
    let twentyHbars;
    let tokenFeeAmount;
    let initialSupply;
    let maxSupply;
    let decimals;

    before(async function () {
      // The owner of the fee token is the tokenCreateContract
      const adminKey = utils.constructIHederaTokenKey(
        'ADMIN',
        'SECP256K1',
        utils.getSignerCompressedPublicKey(0),
      );
      const kycKey = utils.constructIHederaTokenKey(
        'KYC',
        'CONTRACT_ID',
        await tokenCreateCustomContract.getAddress(),
      );
      const freezeKey = utils.constructIHederaTokenKey(
        'FREEZE',
        'CONTRACT_ID',
        await tokenCreateCustomContract.getAddress(),
      );
      const wipeKey = utils.constructIHederaTokenKey(
        'WIPE',
        'CONTRACT_ID',
        await tokenCreateCustomContract.getAddress(),
      );
      const supplyKey = utils.constructIHederaTokenKey(
        'SUPPLY',
        'CONTRACT_ID',
        await tokenCreateCustomContract.getAddress(),
      );
      const feeKey = utils.constructIHederaTokenKey(
        'FEE',
        'CONTRACT_ID',
        await tokenCreateCustomContract.getAddress(),
      );
      const pauseKey = utils.constructIHederaTokenKey(
        'PAUSE',
        'CONTRACT_ID',
        await tokenCreateCustomContract.getAddress(),
      );

      keys = [
        adminKey,
        kycKey,
        freezeKey,
        wipeKey,
        supplyKey,
        feeKey,
        pauseKey,
      ];
    });

    beforeEach(async function () {
      tenHbars = 10 * utils.tinybarToHbarCoef;
      twentyHbars = 20 * utils.tinybarToHbarCoef;
      tokenFeeAmount = 50;
      initialSupply = 1000000000;
      maxSupply = 2000000000;
      decimals = 0;
      feeToken = await utils.createFungibleTokenWithPresetKeysPublic(
        tokenCreateCustomContract,
        'FeeToken',
        'FT',
        'FeeToken',
        1000000000,
        2000000000,
        0,
        false,
        tokenCreateCustomContractAddress,
      );
    });

    it('should be able to update fixed fee in HTS token', async function () {
      //need to associate the fee collector account of the token that will have fees
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
        holderT,
      ]);

      const fixedFee = [
        {
          amount: tokenFeeAmount,
          tokenId: feeToken,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];
      tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
        tokenCreateCustomContract,
        holderT,
        fixedFee,
        [],
        keys,
      );
      await hapi.updateTokenKeys(tokenWithFees, [
        tokenManagementContractAddress,
        tokenTransferContractAddress,
        tokenCreateContractAddress,
        tokenCreateCustomContractAddress,
      ]);

      // ------------------ Associate and grantKyc to accounts tranfering tokenWithFees ------------------
      //TODO: error handling
      await utils.associateAndGrantKyc(tokenCreateContract, tokenWithFees, [
        holderA,
        holderB,
      ]);
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
        holderA,
      ]);

      const grantKycTx = await tokenCreateCustomContract.grantTokenKycPublic(
        feeToken,
        tokenCreateCustomContractAddress,
      );
      await grantKycTx.wait();

      const transferTx = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderT, holderA],
        [-500, 500],
      );
      await transferTx.wait();

      const approveTx = await tokenCreateCustomContract.approvePublic(
        feeToken,
        tokenTransferContract,
        1000,
        Constants.GAS_LIMIT_1_000_000,
      );
      await approveTx.wait();

      const transferFeeTokenToSigner1 =
        await tokenTransferContract.transferTokensPublic(
          feeToken,
          [tokenCreateCustomContractAddress, holderA],
          [-150, 150],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferFeeTokenToSigner1.wait();

      const updatedTokenFeeAmount = tokenFeeAmount + 15;
      const updatedFixedFee = [
        {
          amount: updatedTokenFeeAmount,
          tokenId: feeToken,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];
      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFees,
          updatedFixedFee,
          [],
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;

      const balanceBeforeTransferTokenWithFees1 = await hapi.getTokenBalance(
        holderA,
        tokenWithFees,
      );
      const balanceBeforeTransferTokenWithFees2 = await hapi.getTokenBalance(
        holderB,
        tokenWithFees,
      );
      const balanceBeforeTransferFeeToken1 = await hapi.getTokenBalance(
        holderA,
        feeToken,
      );

      const transferBeforeFeeUpdate =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFees,
          [holderA, holderB],
          [-50, 50],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferBeforeFeeUpdate.wait();

      const balanceAfterTransferTokenWithFees1 = await hapi.getTokenBalance(
        holderA,
        tokenWithFees,
      );
      const balanceAfterTransferTokenWithFees2 = await hapi.getTokenBalance(
        holderB,
        tokenWithFees,
      );
      const balanceAfterTransferFeeToken1 = await hapi.getTokenBalance(
        holderA,
        feeToken,
      );

      expect(balanceAfterTransferTokenWithFees1).to.be.equal(
        balanceBeforeTransferTokenWithFees1 - 50,
      );
      expect(balanceAfterTransferTokenWithFees2).to.be.equal(
        balanceBeforeTransferTokenWithFees2 + 50,
      );
      expect(balanceAfterTransferFeeToken1).to.be.equal(
        balanceBeforeTransferFeeToken1 - updatedTokenFeeAmount,
      );

      const tokenInfoTx =
        await tokenQueryContract.getTokenInfoPublic(tokenWithFees);
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      expect(tokenInfoResponse[5].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[5][0][2]).to.equal(false);
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);
    });

    it('should be able to update fixed fee for HBARs', async function () {
      const fixedFee = [
        {
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];
      const tokenWithFixedHbarFee =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          fixedFee,
          [],
          keys,
        );
      await hapi.updateTokenKeys(tokenWithFixedHbarFee, [
        tokenManagementContractAddress,
        tokenCreateContractAddress,
      ]);
      // ------------------ Associate and grantKyc to accounts transfering tokenWithFixedHbarFee ------------------
      await utils.associateAndGrantKyc(
        tokenCreateContract,
        tokenWithFixedHbarFee,
        [holderA, holderB],
      );

      const transferFromContract =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedHbarFee,
          [holderT, holderA],
          [-500, 500],
        );
      await transferFromContract.wait();

      const balanceBeforeTransfer0 = await hapi.getHbarBalance(holderA);
      await hapi.getHbarBalance(holderB);

      const transferBeforeFeeUpdate =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedHbarFee,
          [holderA, holderB],
          [-50, 50],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferBeforeFeeUpdate.wait();

      const balanceAfterTransfer = await hapi.getHbarBalance(holderA);
      await hapi.getHbarBalance(holderB);

      expect(parseFloat(balanceAfterTransfer)).to.be.equal(
        parseFloat(balanceBeforeTransfer0) -
          parseFloat(tenHbars / utils.tinybarToHbarCoef),
      );
      const updatedFixedFee = [
        {
          amount: twentyHbars,
          tokenId: '0x0000000000000000000000000000000000000000',
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];

      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFixedHbarFee,
          updatedFixedFee,
          [],
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;

      const transferAfterFeeUpdate =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedHbarFee,
          [holderA, holderB],
          [-50, 50],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferAfterFeeUpdate.wait();
      const balanceAfterUpdate = await hapi.getHbarBalance(holderA);
      await hapi.getHbarBalance(holderB);

      expect(parseFloat(balanceAfterUpdate)).to.be.equal(
        parseFloat(balanceAfterTransfer) -
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
      const tokenInfoTx = await tokenQueryContract.getTokenInfoPublic(
        tokenWithFixedHbarFee,
      );

      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      expect(tokenInfoResponse[5].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[5][0][2]).to.equal(true);
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);
    });

    it('should be able to update fixed fee in the same token', async function () {
      const fixedFeeSameToken = [
        {
          amount: tokenFeeAmount,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: true,
          feeCollector: holderC,
        },
      ];
      const tokenWithFixedFeeInSameToken =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          fixedFeeSameToken,
          [],
          keys,
        );

      await hapi.updateTokenKeys(tokenWithFixedFeeInSameToken, [
        tokenManagementContractAddress,
        tokenTransferContractAddress,
        tokenCreateContractAddress,
      ]);

      await utils.associateAndGrantKyc(
        tokenCreateContract,
        tokenWithFixedFeeInSameToken,
        [holderA],
      );

      const transferTokenFromTreasury =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedFeeInSameToken,
          [holderT, holderA],
          [-500, 500],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferTokenFromTreasury.wait();

      const newFeeTokenAmount = tokenFeeAmount + 100;
      const fixedFeeSameTokenUpdated = [
        {
          amount: newFeeTokenAmount,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: true,
          feeCollector: holderC,
        },
      ];
      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFixedFeeInSameToken,
          fixedFeeSameTokenUpdated,
          [],
        );
      await updateFeeTx.wait();

      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;
      const tokenInfoTx = await tokenQueryContract.getTokenInfoPublic(
        tokenWithFixedFeeInSameToken,
      );

      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      expect(tokenInfoResponse[5].length).to.be.greaterThan(0);
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);
    });

    it('should be able to update multiple fixed fees in HTS token', async function () {
      const feeToken2 = await utils.createFungibleTokenWithPresetKeysPublic(
        tokenCreateCustomContract,
        'FeeToken2',
        'FT2',
        'FeeToken2',
        initialSupply,
        maxSupply,
        decimals,
        false,
        holderC,
      );
      //need to associate the fee collector account of the token that will have fees
      // with the fee token, since otherwise the collector won't be able to receive this token
      const associateTx = await tokenCreateCustomContract.associateTokenPublic(
        holderT,
        feeToken2,
        Constants.GAS_LIMIT_1_000_000,
      );
      await associateTx.wait();
      const associateTx2 = await tokenCreateCustomContract.associateTokenPublic(
        holderT,
        feeToken,
        Constants.GAS_LIMIT_1_000_000,
      );
      await associateTx2.wait();

      const fixedFee = {
        amount: tokenFeeAmount,
        tokenId: feeToken,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const fixedFee2 = {
        amount: tokenFeeAmount + 20,
        tokenId: feeToken2,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };

      const tokenWithFees =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [fixedFee, fixedFee2],
          [],
          keys,
        );
      expect(await hapi.getTokenBalance(holderT, tokenWithFees)).to.be.equal(
        utils.initialSupply,
      );
      await hapi.updateTokenKeys(tokenWithFees, [
        tokenManagementContractAddress,
        tokenTransferContractAddress,
        tokenCreateContractAddress,
        tokenCreateCustomContractAddress,
      ]);

      const associateTx3 = await tokenCreateCustomContract.associateTokenPublic(
        holderB,
        feeToken2,
        Constants.GAS_LIMIT_1_000_000,
      );
      await associateTx3.wait();

      const newTokenAmount = tokenFeeAmount + 25;
      const updatedFixedFee = {
        amount: newTokenAmount,
        tokenId: feeToken,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const updatedFixedFee2 = {
        amount: tokenFeeAmount + 18,
        tokenId: feeToken2,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderB,
      };
      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFees,
          [updatedFixedFee, updatedFixedFee2],
          [],
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;
      const tokenInfoTx =
        await tokenQueryContract.getTokenInfoPublic(tokenWithFees);
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      expect(tokenInfoResponse[5].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[5][0][0]).to.equal(BigInt(newTokenAmount));
      expect(tokenInfoResponse[5][0][2]).to.equal(false);
      expect(tokenInfoResponse[5][0][3]).to.equal(false);
      expect(tokenInfoResponse[5][1][0]).to.equal(BigInt(tokenFeeAmount + 18));
      expect(tokenInfoResponse[5][1][2]).to.equal(false);
      expect(tokenInfoResponse[5][1][3]).to.equal(false);
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);

      //TODO: Add transfer and test if the fee is collected
    });

    it('should be able to update multiple fixed fees in HBARs', async function () {
      const thirtyHbars = 30 * utils.tinybarToHbarCoef;
      const fixedFee = {
        amount: tenHbars,
        tokenId: ethers.ZeroAddress,
        useHbarsForPayment: true,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const fixedFee2 = {
        amount: thirtyHbars,
        tokenId: ethers.ZeroAddress,
        useHbarsForPayment: true,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const tokenWithFixedHbarFee =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [fixedFee, fixedFee2],
          [],
          keys,
        );
      await hapi.updateTokenKeys(tokenWithFixedHbarFee, [
        tokenManagementContractAddress,
        tokenCreateContractAddress,
      ]);
      // ------------------ Associate and grantKyc to accounts transfering tokenWithFixedHbarFee ------------------
      await utils.associateAndGrantKyc(
        tokenCreateContract,
        tokenWithFixedHbarFee,
        [holderA, holderB],
      );

      const transferFromContract =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedHbarFee,
          [holderT, holderA],
          [-500, 500],
        );
      await transferFromContract.wait();

      const balanceBeforeTransfer0 = await hapi.getHbarBalance(holderA);

      const transferBeforeFeeUpdate =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedHbarFee,
          [holderA, holderB],
          [-50, 50],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferBeforeFeeUpdate.wait();

      const balanceAfterTransfer = await hapi.getHbarBalance(holderA);

      expect(parseFloat(balanceAfterTransfer)).to.be.equal(
        parseFloat(balanceBeforeTransfer0) -
          parseFloat((tenHbars + thirtyHbars) / utils.tinybarToHbarCoef),
      );
      const updatedFixedFee = {
        amount: twentyHbars,
        tokenId: ethers.ZeroAddress,
        useHbarsForPayment: true,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const updatedFixedFee2 = {
        amount: twentyHbars,
        tokenId: ethers.ZeroAddress,
        useHbarsForPayment: true,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFixedHbarFee,
          [updatedFixedFee, updatedFixedFee2],
          [],
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;

      const transferAfterFeeUpdate =
        await tokenTransferContract.transferTokensPublic(
          tokenWithFixedHbarFee,
          [holderA, holderB],
          [-50, 50],
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferAfterFeeUpdate.wait();
      const balanceAfterUpdate = await hapi.getHbarBalance(holderA);

      expect(parseFloat(balanceAfterUpdate)).to.be.equal(
        parseFloat(balanceAfterTransfer) -
          parseFloat((twentyHbars * 2) / utils.tinybarToHbarCoef),
      );

      const tokenInfoTx = await tokenQueryContract.getTokenInfoPublic(
        tokenWithFixedHbarFee,
      );
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      expect(tokenInfoResponse[5].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[5][0][2]).to.equal(true);
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);
    });

    it('should be able to update fractional fee with net of transfer false in HTS token', async function () {
      const fractionalFeeNumerator = 30;
      const fractionalFeeDenominator = 100;
      const feeToken2 = await utils.createFungibleTokenWithPresetKeysPublic(
        tokenCreateCustomContract,
        'FeeToken2',
        'FT2',
        'FeeToken2',
        initialSupply,
        maxSupply,
        decimals,
        false,
        holderC,
      );
      await utils.associateToken(tokenCreateCustomContract, feeToken2);
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken2, [
        holderT,
      ]);

      const fractionalFee = {
        numerator: fractionalFeeNumerator,
        denominator: fractionalFeeDenominator,
        minimumAmount: 0,
        maximumAmount: 0,
        netOfTransfers: false,
        feeCollector: holderT,
      };
      const fixedFee2 = {
        amount: tokenFeeAmount + 50,
        tokenId: feeToken2,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const tokenWithFees =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [fixedFee2],
          [fractionalFee],
          keys,
        );

      await hapi.updateTokenKeys(tokenWithFees, [
        tokenManagementContractAddress,
        tokenTransferContractAddress,
        tokenCreateContractAddress,
        tokenCreateCustomContractAddress,
      ]);

      const updatedFractionalFeeNumerator = fractionalFeeNumerator + 5;
      const updatedFractionalFee = [
        {
          numerator: updatedFractionalFeeNumerator,
          denominator: fractionalFeeDenominator,
          minimumAmount: 100,
          maximumAmount: 1000,
          netOfTransfers: false,
          feeCollector: holderT,
        },
      ];

      // make a transfer and ensure that the fee is collected
      //apparently first you need to associate and then gran token kyc
      await utils.associateAndGrantKyc(tokenCreateContract, tokenWithFees, [
        holderA,
        holderB,
      ]);
      const transferTx = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderT, holderA],
        [-500, 500],
      );
      await transferTx.wait();

      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFees,
          [],
          updatedFractionalFee,
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;
      const tokenInfoTx =
        await tokenQueryContract.getTokenInfoPublic(tokenWithFees);
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      // fractional fee is at position 7 in the tokenInfo array
      expect(tokenInfoResponse[6].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[6][0][0]).to.equal(BigInt(35));
      expect(tokenInfoResponse[6][0][2]).to.equal(BigInt(100));
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);

      const feeCollectorBalanceBeforeTransfer = await hapi.getTokenBalance(
        holderT,
        tokenWithFees,
      );
      const senderBalanceBeforeTransfer = await hapi.getTokenBalance(
        holderA,
        tokenWithFees,
      );
      const feeToBeCharged = Math.floor(
        (400 * updatedFractionalFeeNumerator) / fractionalFeeDenominator,
      );
      const transferTx1 = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderA, holderB],
        [-400, 400],
        Constants.GAS_LIMIT_1_000_000,
      );
      await transferTx1.wait();

      //ensure the fee has been updated and collected
      expect(await hapi.getTokenBalance(holderT, tokenWithFees)).to.be.equal(
        feeCollectorBalanceBeforeTransfer + feeToBeCharged,
      );
      expect(await hapi.getTokenBalance(holderA, tokenWithFees)).to.be.equal(
        senderBalanceBeforeTransfer - 400,
      );
      expect(await hapi.getTokenBalance(holderB, tokenWithFees)).to.be.equal(
        400 - feeToBeCharged,
      );
    });

    it('should be able to update fractional fee with net of transfer true in HTS token', async function () {
      const fractionalFeeNumerator = 30;
      const fractionalFeeDenominator = 100;
      const feeToken2 = await utils.createFungibleTokenWithPresetKeysPublic(
        tokenCreateCustomContract,
        'FeeToken2',
        'FT2',
        'FeeToken2',
        initialSupply,
        maxSupply,
        decimals,
        false,
        holderC,
      );
      await utils.associateToken(tokenCreateCustomContract, feeToken2);
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken2, [
        holderT,
      ]);

      const fractionalFee = {
        numerator: fractionalFeeNumerator,
        denominator: fractionalFeeDenominator,
        minimumAmount: 0,
        maximumAmount: 0,
        netOfTransfers: false,
        feeCollector: holderT,
      };
      const fixedFee2 = {
        amount: tokenFeeAmount + 50,
        tokenId: feeToken2,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const tokenWithFees =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [fixedFee2],
          [fractionalFee],
          keys,
        );

      await hapi.updateTokenKeys(tokenWithFees, [
        tokenManagementContractAddress,
        tokenTransferContractAddress,
        tokenCreateContractAddress,
        tokenCreateCustomContractAddress,
      ]);

      const updatedFractionalFeeNumerator = fractionalFeeNumerator + 5;
      const updatedFractionalFee = [
        {
          numerator: updatedFractionalFeeNumerator,
          denominator: fractionalFeeDenominator,
          minimumAmount: 100,
          maximumAmount: 1000,
          netOfTransfers: true,
          feeCollector: holderT,
        },
      ];

      // make a transfer and ensure that the fee is collected
      //apparently first you need to associate and then gran token kyc

      await utils.associateAndGrantKyc(tokenCreateContract, tokenWithFees, [
        holderA,
        holderB,
      ]);

      const transferTx = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderT, holderA],
        [-1000, 1000],
      );
      await transferTx.wait();

      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFees,
          [],
          updatedFractionalFee,
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;
      const tokenInfoTx =
        await tokenQueryContract.getTokenInfoPublic(tokenWithFees);
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      // fractional fee is at position 7 in the tokenInfo array
      expect(tokenInfoResponse[6].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[6][0][0]).to.equal(BigInt(35));
      expect(tokenInfoResponse[6][0][2]).to.equal(BigInt(100));
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);

      const feeCollectorBalanceBeforeTransfer = await hapi.getTokenBalance(
        holderT,
        tokenWithFees,
      );
      const senderBalanceBeforeTransfer = await hapi.getTokenBalance(
        holderA,
        tokenWithFees,
      );
      const feeToBeCharged = Math.floor(
        (400 * updatedFractionalFeeNumerator) / fractionalFeeDenominator,
      );
      const transferTx1 = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderA, holderB],
        [-400, 400],
        Constants.GAS_LIMIT_1_000_000,
      );
      await transferTx1.wait();

      //ensure the fee has been updated and collected
      expect(await hapi.getTokenBalance(holderT, tokenWithFees)).to.be.equal(
        feeCollectorBalanceBeforeTransfer + feeToBeCharged,
      );
      expect(await hapi.getTokenBalance(holderA, tokenWithFees)).to.be.equal(
        senderBalanceBeforeTransfer - 400 - feeToBeCharged,
      );
      expect(await hapi.getTokenBalance(holderB, tokenWithFees)).to.be.equal(
        400,
      );
    });

    it('should be able to update multiple fractional fees in HTS token', async function () {
      const fractionalFeeNumerator = 30;
      const fractionalFeeDenominator = 100;
      const fractionalFeeNumerator2 = 10;
      console.log('Creating token');
      const feeToken2 = await utils.createFungibleTokenWithPresetKeysPublic(
        tokenCreateCustomContract,
        'FeeToken2',
        'FT2',
        'FeeToken2',
        initialSupply,
        maxSupply,
        decimals,
        false,
        holderC,
      );
      await utils.associateToken(tokenCreateCustomContract, feeToken2);
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken2, [
        holderT,
      ]);

      const fixedFeeAmount = tokenFeeAmount + 50;
      const fractionalFee = {
        numerator: fractionalFeeNumerator,
        denominator: fractionalFeeDenominator,
        minimumAmount: 0,
        maximumAmount: 0,
        netOfTransfers: false,
        feeCollector: holderT,
      };
      const fractionalFee2 = {
        numerator: fractionalFeeNumerator2,
        denominator: fractionalFeeDenominator,
        minimumAmount: 0,
        maximumAmount: 0,
        netOfTransfers: false,
        feeCollector: holderT,
      };
      const fixedFee2 = {
        amount: fixedFeeAmount,
        tokenId: feeToken2,
        useHbarsForPayment: false,
        useCurrentTokenForPayment: false,
        feeCollector: holderT,
      };
      const tokenWithFees =
        await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [fixedFee2],
          [fractionalFee, fractionalFee2],
          keys,
        );

      await hapi.updateTokenKeys(tokenWithFees, [
        tokenManagementContractAddress,
        tokenTransferContractAddress,
        tokenCreateContractAddress,
        tokenCreateCustomContractAddress,
      ]);

      const updatedFractionalFeeNumerator = fractionalFeeNumerator + 5;
      const updatedFractionalFeeNumerator2 = fractionalFeeNumerator2 - 5;
      const updatedFractionalFee = [
        {
          numerator: updatedFractionalFeeNumerator,
          denominator: fractionalFeeDenominator,
          minimumAmount: 100,
          maximumAmount: 1000,
          netOfTransfers: false,
          feeCollector: holderT,
        },
        {
          numerator: updatedFractionalFeeNumerator2,
          denominator: fractionalFeeDenominator,
          minimumAmount: 1,
          maximumAmount: 1000,
          netOfTransfers: false,
          feeCollector: holderT,
        },
      ];

      // make a transfer and ensure that the fee is collected
      //apparently first you need to associate and then gran token kyc
      await utils.associateAndGrantKyc(
        tokenCreateCustomContract,
        tokenWithFees,
        [holderA, holderB],
      );
      const transferTx = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderT, holderA],
        [-500, 500],
      );
      await transferTx.wait();

      const updateFeeTx =
        await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
          tokenWithFees,
          [],
          updatedFractionalFee,
        );
      const updateFeeResponseCode = (await updateFeeTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.ResponseCode,
      )[0].args.responseCode;
      const tokenInfoTx =
        await tokenQueryContract.getTokenInfoPublic(tokenWithFees);
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.TokenInfo,
      )[0].args.tokenInfo;

      // fractional fee is at position 7 in the tokenInfo array
      expect(tokenInfoResponse[6].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[6][0][0]).to.equal(BigInt(35));
      expect(tokenInfoResponse[6][0][2]).to.equal(BigInt(100));
      expect(tokenInfoResponse[6][1][0]).to.equal(BigInt(5));
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);

      const feeCollectorBalanceBeforeTransfer = await hapi.getTokenBalance(
        holderT,
        tokenWithFees,
      );
      const senderBalanceBeforeTransfer = await hapi.getTokenBalance(
        holderA,
        tokenWithFees,
      );
      const feeToBeCharged = Math.floor(
        400 *
          ((updatedFractionalFeeNumerator + updatedFractionalFeeNumerator2) /
            fractionalFeeDenominator),
      );

      const transferTx1 = await tokenTransferContract.transferTokensPublic(
        tokenWithFees,
        [holderA, holderB],
        [-400, 400],
        Constants.GAS_LIMIT_1_000_000,
      );
      await transferTx1.wait();

      const signer2BalanceAfterTransfer = await hapi.getTokenBalance(
        holderB,
        tokenWithFees,
      );

      //ensure the fee has been updated and collected
      expect(await hapi.getTokenBalance(holderT, tokenWithFees)).to.be.equal(
        feeCollectorBalanceBeforeTransfer + feeToBeCharged,
      );
      expect(await hapi.getTokenBalance(holderA, tokenWithFees)).to.be.equal(
        senderBalanceBeforeTransfer - 400,
      );
      expect(signer2BalanceAfterTransfer).to.be.equal(400 - feeToBeCharged);
    });

    it('should be able to update royalty fee in HBARs for NFT', async function () {
      const fixedFees = [];
      const royaltyFees = [
        {
          numerator: 10,
          denominator: 100,
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
      ];
      const nft = await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
        tokenCreateCustomContract,
        holderT,
        fixedFees,
        royaltyFees,
        keys,
      );
      const nftTx = await utils.mintNFT(tokenCreateCustomContract, nft);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, nft, [
        holderA,
        holderC,
      ]);

      const transferNft = await tokenTransferContract.transferNFTPublic(
        nft,
        holderT,
        holderA,
        nftTx,
      );
      await transferNft.wait();

      await hapi.updateTokenKeys(nft, [
        tokenManagementContractAddress,
        tokenCreateCustomContractAddress,
      ]);
      const updatedRoyaltyFee = [
        {
          numerator: 10,
          denominator: 100,
          amount: twentyHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
      ];
      const updateRoyaltyFeeTx =
        await tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
          nft,
          [],
          updatedRoyaltyFee,
        );
      await updateRoyaltyFeeTx.wait();

      const beforeNftTransferHbars2 = await hapi.getHbarBalance(holderB);
      const beforeNftTransferHbars3 = await hapi.getHbarBalance(holderC);

      const transferNftToSigner3 =
        await tokenTransferContract.transferNFTPublic(
          nft,
          holderA,
          holderC,
          nftTx,
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferNftToSigner3.wait();

      expect(await hapi.getTokenBalance(holderC, nft)).to.equal(1);
      expect(parseFloat(await hapi.getHbarBalance(holderB))).to.equal(
        beforeNftTransferHbars2 +
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
      expect(parseFloat(await hapi.getHbarBalance(holderC))).to.equal(
        beforeNftTransferHbars3 -
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
    });

    it('should be able to update multiple royalty fees in HBARs for NFT', async function () {
      const fixedFees = [];
      const royaltyFees = [
        {
          numerator: 10,
          denominator: 100,
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
      ];
      const nft = await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
        tokenCreateCustomContract,
        holderT,
        fixedFees,
        royaltyFees,
        keys,
      );
      const nftTx = await utils.mintNFT(tokenCreateCustomContract, nft);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, nft, [
        holderA,
        holderC,
      ]);

      const transferNft = await tokenTransferContract.transferNFTPublic(
        nft,
        holderT,
        holderA,
        nftTx,
      );
      await transferNft.wait();

      await hapi.updateTokenKeys(nft, [
        tokenManagementContractAddress,
        tokenCreateCustomContractAddress,
      ]);
      const updatedRoyaltyFee = [
        {
          numerator: 10,
          denominator: 100,
          amount: twentyHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
        {
          numerator: 10,
          denominator: 100,
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
      ];
      const updateRoyaltyFeeTx =
        await tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
          nft,
          [],
          updatedRoyaltyFee,
        );
      await updateRoyaltyFeeTx.wait();

      const beforeNftTransferHbars2 = await hapi.getHbarBalance(holderB);
      const beforeNftTransferHbars3 = await hapi.getHbarBalance(holderC);

      const transferNftToSigner3 =
        await tokenTransferContract.transferNFTPublic(
          nft,
          holderA,
          holderC,
          nftTx,
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferNftToSigner3.wait();

      expect(await hapi.getTokenBalance(holderC, nft)).to.equal(1);
      expect(parseFloat(await hapi.getHbarBalance(holderB))).to.equal(
        beforeNftTransferHbars2 +
          parseFloat((twentyHbars + tenHbars) / utils.tinybarToHbarCoef),
      );
      expect(parseFloat(await hapi.getHbarBalance(holderC))).to.equal(
        beforeNftTransferHbars3 -
          parseFloat((twentyHbars + tenHbars) / utils.tinybarToHbarCoef),
      );
    });

    it('should be able to update fixed fee in HBARs for NFT', async function () {
      const fixedFees = [
        {
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderB,
        },
      ];
      const royaltyFees = [];
      const nft = await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
        tokenCreateCustomContract,
        holderT,
        fixedFees,
        royaltyFees,
        keys,
      );
      const nftTx = await utils.mintNFT(tokenCreateCustomContract, nft);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, nft, [
        holderA,
        holderC,
      ]);

      const transferNft = await tokenTransferContract.transferNFTPublic(
        nft,
        holderT,
        holderA,
        nftTx,
      );
      await transferNft.wait();

      await hapi.updateTokenKeys(nft, [
        tokenManagementContractAddress,
        tokenCreateCustomContractAddress,
      ]);
      const updatedfixedFees = [
        {
          amount: twentyHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderB,
        },
      ];
      const updateRoyaltyFeeTx =
        await tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
          nft,
          updatedfixedFees,
          [],
        );
      await updateRoyaltyFeeTx.wait();

      const beforeNftTransferHbars2 = await hapi.getHbarBalance(holderB);
      const beforeNftTransferHbars1 = await hapi.getHbarBalance(holderA);

      const transferNftToSigner3 =
        await tokenTransferContract.transferNFTPublic(
          nft,
          holderA,
          holderC,
          nftTx,
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferNftToSigner3.wait();

      expect(await hapi.getTokenBalance(holderC, nft)).to.equal(1);
      expect(parseFloat(await hapi.getHbarBalance(holderB))).to.equal(
        beforeNftTransferHbars2 +
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
      expect(parseFloat(await hapi.getHbarBalance(holderA))).to.equal(
        beforeNftTransferHbars1 -
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
    });

    it('should be able to update fixed HTS fee for NFT', async function () {
      await utils.associateToken(tokenCreateCustomContract, feeToken);
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
        holderT,
      ]);
      //we need to grant kyc and associate token with the fee collector, which is signer[0]
      const grantKycFeeCollectorFeeToken =
        await tokenCreateCustomContract.grantTokenKycPublic(feeToken, holderT);
      await grantKycFeeCollectorFeeToken.wait();

      const fixedFees = [
        {
          amount: tokenFeeAmount,
          tokenId: feeToken,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];
      const royaltyFees = [];
      const nft = await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
        tokenCreateCustomContract,
        holderT,
        fixedFees,
        royaltyFees,
        keys,
      );
      const nftTx = await utils.mintNFT(tokenCreateCustomContract, nft);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, nft, [
        holderA,
        holderC,
      ]);
      const transferNft = await tokenTransferContract.transferNFTPublic(
        nft,
        holderT,
        holderA,
        nftTx,
      );
      await transferNft.wait();

      await hapi.updateTokenKeys(nft, [
        tokenManagementContractAddress,
        tokenCreateCustomContractAddress,
      ]);
      const updatedfixedFees = [
        {
          amount: tokenFeeAmount + 13,
          tokenId: feeToken,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];

      const updateRoyaltyFeeTx =
        await tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
          nft,
          updatedfixedFees,
          [],
        );
      await updateRoyaltyFeeTx.wait();

      await hapi.getHbarBalance(holderB);
      await hapi.getHbarBalance(holderA);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
        holderA,
      ]);

      // ---------- send fee token to signer 1 ------------

      //prerequisite: signer 1 has to be associated
      // approve the tokenTransfer to spend feeTokens
      const approveTx = await tokenCreateCustomContract.approvePublic(
        feeToken,
        tokenTransferContract,
        1000,
        Constants.GAS_LIMIT_1_000_000,
      );
      await approveTx.wait();
      const transferFeeToken = await tokenTransferContract.transferTokensPublic(
        feeToken,
        [tokenCreateCustomContractAddress, holderA],
        [-500, 500],
      );
      await transferFeeToken.wait();

      const balanceBeforeFeeCollector = await hapi.getTokenBalance(
        holderT,
        feeToken,
      );
      const balanceBeforeSigner1 = await hapi.getTokenBalance(
        holderA,
        feeToken,
      );
      const transferNftToSigner3 =
        await tokenTransferContract.transferNFTPublic(
          nft,
          holderA,
          holderC,
          nftTx,
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferNftToSigner3.wait();
      expect(await hapi.getTokenBalance(holderA, feeToken)).to.equal(
        balanceBeforeSigner1 - (tokenFeeAmount + 13),
      );
      expect(await hapi.getTokenBalance(holderT, feeToken)).to.equal(
        balanceBeforeFeeCollector + (tokenFeeAmount + 13),
      );
      expect(await hapi.getTokenBalance(holderC, nft)).to.equal(1);
    });

    it('should be able to update fixed HTS fee and royalty fee in NFT', async function () {
      await utils.associateToken(tokenCreateCustomContract, feeToken);
      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
        holderT,
      ]);
      //we need to grant kyc and associate token with the fee collector, which is signer[0]
      const grantKycFeeCollectorFeeToken =
        await tokenCreateCustomContract.grantTokenKycPublic(feeToken, holderT);
      await grantKycFeeCollectorFeeToken.wait();

      const fixedFees = [
        {
          amount: tokenFeeAmount,
          tokenId: feeToken,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];
      const royaltyFees = [
        {
          numerator: 10,
          denominator: 100,
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
      ];
      const nft = await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
        tokenCreateCustomContract,
        holderT,
        fixedFees,
        royaltyFees,
        keys,
      );
      const nftTx = await utils.mintNFT(tokenCreateCustomContract, nft);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, nft, [
        holderA,
        holderC,
      ]);
      const transferNft = await tokenTransferContract.transferNFTPublic(
        nft,
        holderT,
        holderA,
        nftTx,
      );
      await transferNft.wait();

      await hapi.updateTokenKeys(nft, [
        tokenManagementContractAddress,
        tokenCreateCustomContractAddress,
      ]);
      const updatedfixedFees = [
        {
          amount: tokenFeeAmount + 13,
          tokenId: feeToken,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        },
      ];
      const updatedRoyaltyFee = [
        {
          numerator: 10,
          denominator: 100,
          amount: twentyHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          feeCollector: holderB,
        },
      ];

      const updateRoyaltyFeeTx =
        await tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
          nft,
          updatedfixedFees,
          updatedRoyaltyFee,
        );
      await updateRoyaltyFeeTx.wait();

      const updateFeeResponseCode = (
        await updateRoyaltyFeeTx.wait()
      ).logs.filter((e) => e.fragment.name === Constants.Events.ResponseCode)[0]
        .args.responseCode;
      const tokenInfoTx =
        await tokenQueryContract.getNonFungibleTokenInfoPublic(nft, nftTx);
      const tokenInfoResponse = (await tokenInfoTx.wait()).logs.filter(
        (e) => e.fragment.name === Constants.Events.NonFungibleTokenInfo,
      )[0].args.tokenInfo;

      // fractional fee is at position 7 in the tokenInfo array
      expect(tokenInfoResponse[0][5].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[0][7].length).to.be.greaterThan(0);
      expect(tokenInfoResponse[0][5][0][0]).to.equal(63);
      expect(tokenInfoResponse[0][5][0][1]).to.equal(feeToken);
      expect(tokenInfoResponse[0][7][0][2]).to.equal(twentyHbars);
      expect(tokenInfoResponse[0][7][0][4]).to.equal(true);
      expect(updateFeeResponseCode).to.equal(TX_SUCCESS_CODE);

      await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
        holderA,
      ]);

      // ---------- send fee token to signer 1 ------------

      //prerequisite: signer 1 has to be associated
      // approve the tokenTransfer to spend feeTokens
      const approveTx = await tokenCreateCustomContract.approvePublic(
        feeToken,
        tokenTransferContract,
        1000,
        Constants.GAS_LIMIT_1_000_000,
      );
      await approveTx.wait();

      const transferFeeToken = await tokenTransferContract.transferTokensPublic(
        feeToken,
        [tokenCreateCustomContractAddress, holderA],
        [-500, 500],
      );
      await transferFeeToken.wait();

      const balanceBeforeFeeCollector = await hapi.getTokenBalance(
        holderT,
        feeToken,
      );
      const balanceBeforeSigner1 = await hapi.getTokenBalance(
        holderA,
        feeToken,
      );
      const beforeNftTransferHbars2 = await hapi.getHbarBalance(holderB);
      const beforeNftTransferHbars3 = await hapi.getHbarBalance(holderC);
      const transferNftToSigner3 =
        await tokenTransferContract.transferNFTPublic(
          nft,
          holderA,
          holderC,
          nftTx,
          Constants.GAS_LIMIT_1_000_000,
        );
      await transferNftToSigner3.wait();

      expect(await hapi.getTokenBalance(holderA, feeToken)).to.equal(
        balanceBeforeSigner1 - (tokenFeeAmount + 13),
      );
      expect(await hapi.getTokenBalance(holderT, feeToken)).to.equal(
        balanceBeforeFeeCollector + (tokenFeeAmount + 13),
      );
      expect(await hapi.getTokenBalance(holderC, nft)).to.equal(1);
      expect(parseFloat(await hapi.getHbarBalance(holderB))).to.equal(
        beforeNftTransferHbars2 +
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
      expect(parseFloat(await hapi.getHbarBalance(holderC))).to.equal(
        beforeNftTransferHbars3 -
          parseFloat(twentyHbars / utils.tinybarToHbarCoef),
      );
    });

    describe('Update fees negative cases', async function () {
      it('should fail when updating fungible token non-existing fixed fee', async function () {
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
          tokenTransferContractAddress,
          tokenCreateContractAddress,
          tokenCreateCustomContractAddress,
        ]);
        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            [],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(CUSTOM_SCHEDULE_ALREADY_HAS_NO_FEES),
        );
      });

      it('should fail when updating non fungible token non-existing fixed fee', async function () {
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [],
            [],
            keys,
          );
        await hapi.updateTokenKeys(nft, [
          tokenManagementContractAddress,
          tokenTransferContractAddress,
          tokenCreateContractAddress,
          tokenCreateCustomContractAddress,
        ]);

        await expect(
          tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            [],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(CUSTOM_SCHEDULE_ALREADY_HAS_NO_FEES),
        );
      });

      it('should fail when trying to update fees of fungible token with no fee schedule key', async function () {
        const keysWithoutFeeSchedule = keys.slice();
        keysWithoutFeeSchedule.splice(5, 1);
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [],
          keysWithoutFeeSchedule,
        );

        await hapi.updateTokenKeys(
          tokenWithFees,
          [
            tokenManagementContractAddress,
            tokenTransferContractAddress,
            tokenCreateContractAddress,
            tokenCreateCustomContractAddress,
          ],
          false,
        );
        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            [],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(TOKEN_HAS_NO_FEE_SCHEDULE_KEY),
        );
      });

      it('should fail when trying to update fees of non fungible token with no fee schedule key', async function () {
        const keysWithoutFeeSchedule = keys.slice();
        keysWithoutFeeSchedule.splice(5, 1);
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [],
            [],
            keysWithoutFeeSchedule,
          );
        await hapi.updateTokenKeys(nft, [
          tokenManagementContractAddress,
          tokenTransferContractAddress,
          tokenCreateContractAddress,
          tokenCreateCustomContractAddress,
        ]);
        await expect(
          tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            [],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(TOKEN_HAS_NO_FEE_SCHEDULE_KEY),
        );
      });

      it('should fail when fee has negative values', async function () {
        const negativeHbars = -10 * utils.tinybarToHbarCoef;
        const fixedFee = {
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: true,
          feeCollector: holderT,
        };
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [fixedFee],
          [],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
        ]);
        const updatedFixedFee = {
          amount: negativeHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        };
        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            [updatedFixedFee],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(CUSTOM_FEE_MUST_BE_POSITIVE),
        );
      });

      it('should fail when fee has negative values for non fungible token', async function () {
        const negativeHbars = -10 * utils.tinybarToHbarCoef;
        const fixedFee = {
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        };
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [fixedFee],
            [],
            keys,
          );
        await hapi.updateTokenKeys(nft, [tokenManagementContractAddress]);

        const updatedFixedFee = {
          amount: negativeHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        };
        await expect(
          tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            [updatedFixedFee],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(CUSTOM_FEE_MUST_BE_POSITIVE),
        );
      });

      it('should fail when fractional fee has denominator zero', async function () {
        const fractionalFee = {
          numerator: 10,
          denominator: 100,
          minimumAmount: 0,
          maximumAmount: 0,
          netOfTransfers: false,
          feeCollector: holderT,
        };
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [fractionalFee],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
        ]);
        const updatedFractionalFee = {
          numerator: 10,
          denominator: 0,
          minimumAmount: 0,
          maximumAmount: 0,
          netOfTransfers: false,
          feeCollector: holderT,
        };
        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            [],
            [updatedFractionalFee],
          ),
        ).to.eventually.be.rejectedWith(new RegExp(FRACTION_DIVIDES_BY_ZERO));
      });

      it('should fail when updating fungible token fees to more than 10', async function () {
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
        ]);

        const fees = [];
        for (let i = 0; i < 11; i++) {
          fees.push({
            amount: tokenFeeAmount + i,
            tokenId: ethers.ZeroAddress,
            useHbarsForPayment: true,
            useCurrentTokenForPayment: false,
            feeCollector: holderT,
          });
        }
        const updateFeeTx =
          await tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            fees,
            [],
            Constants.GAS_LIMIT_5_000_000,
          );
        await expectHTSError(
          updateFeeTx,
          'CUSTOM_FEES_LIST_TOO_LONG',
          CUSTOM_FEES_LIST_TOO_LONG,
        );
      });

      it('should fail when updating NFT token fees to more than 10', async function () {
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [],
            [],
            keys,
          );
        await hapi.updateTokenKeys(nft, [tokenManagementContractAddress]);
        const fees = [];
        for (let i = 0; i < 11; i++) {
          fees.push({
            amount: tokenFeeAmount + i,
            tokenId: ethers.ZeroAddress,
            useHbarsForPayment: true,
            useCurrentTokenForPayment: false,
            feeCollector: holderT,
          });
        }
        const updateFeeTx =
          await tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            fees,
            [],
            Constants.GAS_LIMIT_5_000_000,
          );
        await expectHTSError(
          updateFeeTx,
          'CUSTOM_FEES_LIST_TOO_LONG',
          CUSTOM_FEES_LIST_TOO_LONG,
        );
      });

      it('should fail when the provided fee collector is invalid', async function () {
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
        ]);
        const fixedFee = {
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: feeToken,
        };
        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            [fixedFee],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(INVALID_CUSTOM_FEE_COLLECTOR),
        );
      });

      it('should fail when the provided fee collector is invalid for NFT', async function () {
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [],
            [],
            keys,
          );
        await hapi.updateTokenKeys(nft, [tokenManagementContractAddress]);
        const fixedFee = {
          amount: tenHbars,
          tokenId: ethers.ZeroAddress,
          useHbarsForPayment: true,
          useCurrentTokenForPayment: false,
          feeCollector: feeToken,
        };
        await expect(
          tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            [fixedFee],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(INVALID_CUSTOM_FEE_COLLECTOR),
        );
      });

      it('should fail when the provided token id is invalid', async function () {
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
        ]);

        const fixedFee = {
          amount: 10,
          tokenId: holderA,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        };

        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            [fixedFee],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(INVALID_TOKEN_ID_IN_CUSTOM_FEES),
        );
      });

      it('should fail when the provided token id is invalid for NFT', async function () {
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [],
            [],
            keys,
          );
        await hapi.updateTokenKeys(nft, [tokenManagementContractAddress]);
        const fixedFee = {
          amount: 10,
          tokenId: holderA,
          useHbarsForPayment: false,
          useCurrentTokenForPayment: false,
          feeCollector: holderT,
        };
        await expect(
          tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            [fixedFee],
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(INVALID_TOKEN_ID_IN_CUSTOM_FEES),
        );
      });

      it('should fail for updateFungibleTokenCustomFees when token is not associated to fee collector', async function () {
        //need to associate the fee collector account of the token that will have fees
        tokenWithFees = await utils.createFungibleTokenWithCustomFeesAndKeys(
          tokenCreateCustomContract,
          holderT,
          [],
          [],
          keys,
        );
        await hapi.updateTokenKeys(tokenWithFees, [
          tokenManagementContractAddress,
          tokenTransferContractAddress,
          tokenCreateContractAddress,
          tokenCreateCustomContractAddress,
        ]);

        // ------------------ Associate and grantKyc to accounts tranfering tokenWithFees ------------------
        //TODO: error handling
        await utils.associateAndGrantKyc(tokenCreateContract, tokenWithFees, [
          holderA,
          holderB,
        ]);
        await utils.associateAndGrantKyc(tokenCreateCustomContract, feeToken, [
          holderA,
        ]);

        const grantKycTx = await tokenCreateCustomContract.grantTokenKycPublic(
          feeToken,
          tokenCreateCustomContractAddress,
        );
        await grantKycTx.wait();

        const transferTx = await tokenTransferContract.transferTokensPublic(
          tokenWithFees,
          [holderT, holderA],
          [-500, 500],
        );
        await transferTx.wait();

        const approveTx = await tokenCreateCustomContract.approvePublic(
          feeToken,
          tokenTransferContract,
          1000,
          Constants.GAS_LIMIT_1_000_000,
        );
        await approveTx.wait();

        const transferFeeTokenToSigner1 =
          await tokenTransferContract.transferTokensPublic(
            feeToken,
            [tokenCreateCustomContractAddress, holderA],
            [-150, 150],
            Constants.GAS_LIMIT_1_000_000,
          );
        await transferFeeTokenToSigner1.wait();

        const updatedTokenFeeAmount = tokenFeeAmount + 15;
        const updatedFixedFee = [
          {
            amount: updatedTokenFeeAmount,
            tokenId: feeToken,
            useHbarsForPayment: false,
            useCurrentTokenForPayment: false,
            feeCollector: holderT,
          },
        ];
        await expect(
          tokenManagmentContract.updateFungibleTokenCustomFeesPublic(
            tokenWithFees,
            updatedFixedFee,
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(TOKEN_NOT_ASSOCIATED_TO_FEE_COLLECTOR),
        );
      });

      it('should fail for updateNonFungibleTokenCustomFees when token is not associated to fee collector', async function () {
        //we need to grant kyc and associate token with the fee collector, which is signer[0]
        const nft =
          await utils.createNonFungibleTokenWithCustomRoyaltyFeeAndKeys(
            tokenCreateCustomContract,
            holderT,
            [],
            [],
            keys,
          );
        const nftTx = await utils.mintNFT(tokenCreateCustomContract, nft);

        await utils.associateAndGrantKyc(tokenCreateCustomContract, nft, [
          holderA,
          holderC,
        ]);
        const transferNft = await tokenTransferContract.transferNFTPublic(
          nft,
          holderT,
          holderA,
          nftTx,
        );
        await transferNft.wait();

        await hapi.updateTokenKeys(nft, [
          tokenManagementContractAddress,
          tokenCreateCustomContractAddress,
        ]);
        const updatedfixedFees = [
          {
            amount: tokenFeeAmount + 13,
            tokenId: feeToken,
            useHbarsForPayment: false,
            useCurrentTokenForPayment: false,
            feeCollector: holderT,
          },
        ];

        await expect(
          tokenManagmentContract.updateNonFungibleTokenCustomFeesPublic(
            nft,
            updatedfixedFees,
            [],
          ),
        ).to.eventually.be.rejectedWith(
          new RegExp(TOKEN_NOT_ASSOCIATED_TO_FEE_COLLECTOR),
        );
      });
    });
  });
});
