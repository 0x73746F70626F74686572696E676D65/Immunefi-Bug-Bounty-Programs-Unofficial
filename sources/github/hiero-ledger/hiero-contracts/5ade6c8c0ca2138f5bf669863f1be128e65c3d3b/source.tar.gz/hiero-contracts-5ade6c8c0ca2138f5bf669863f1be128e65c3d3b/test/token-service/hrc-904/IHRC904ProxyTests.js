// SPDX-License-Identifier: Apache-2.0

import { expect } from 'chai';
import hre from 'hardhat';
const { ethers } = await hre.network.connect();
import { Contract } from 'ethers';

import Constants from '../../constants';
import hapi from '../hapi';
import utils from '../utils';

describe('HIP904Batch2 IHRC904Facade Contract Test Suite', function () {
  let airdropContract;
  let tokenAddress;
  let nftTokenAddress;
  let tokenCreateContract;
  let signers;
  let owner;
  let receiver;
  let receiverPrivateKey;
  const invalidAddress = '0x000000000000000000000000000000000000dead';
  let walletIHRC904TokenFacadeSender;
  let walletIHRC904AccountFacade;
  let walletIHRC904NftFacadeSender;
  let walletIHRC904TokenFacadeReceiver;
  let walletIHRC904NftFacadeReceiver;
  let erc20Contract;
  let erc721Contract;
  let contractAddresses;

  before(async function () {
    signers = await ethers.getSigners();
    airdropContract = await utils.deployContract(Constants.Contract.Airdrop);
    tokenCreateContract = await utils.deployContract(
      Constants.Contract.TokenCreateContract,
    );
    owner = signers[0].address;
    receiverPrivateKey = ethers.hexlify(ethers.randomBytes(32));
    receiver = new ethers.Wallet(receiverPrivateKey).connect(ethers.provider);

    // Send some HBAR to activate the account
    await signers[0].sendTransaction({
      to: receiver.address,
      value: ethers.parseEther('100'),
    });

    erc20Contract = await utils.deployContract(
      Constants.Contract.ERC20Contract,
    );
    erc721Contract = await utils.deployContract(
      Constants.Contract.ERC721Contract,
    );

    contractAddresses = [
      await airdropContract.getAddress(),
      await tokenCreateContract.getAddress(),
    ];

    tokenAddress = await utils.setupToken(
      tokenCreateContract,
      owner,
      contractAddresses,
      hapi,
    );
    nftTokenAddress = await utils.setupNft(
      tokenCreateContract,
      owner,
      contractAddresses,
      hapi,
    );

    const IHRC904AccountFacade = new ethers.Interface(
      (await hre.artifacts.readArtifact('IHRC904AccountFacade')).abi,
    );

    walletIHRC904AccountFacade = new Contract(
      receiver.address,
      IHRC904AccountFacade,
      receiver,
    );

    const IHRC904TokenFacade = new ethers.Interface(
      (await hre.artifacts.readArtifact('IHRC904TokenFacade')).abi,
    );

    walletIHRC904TokenFacadeSender = new Contract(
      tokenAddress,
      IHRC904TokenFacade,
      signers[0],
    );

    walletIHRC904NftFacadeSender = new Contract(
      nftTokenAddress,
      IHRC904TokenFacade,
      signers[0],
    );

    walletIHRC904TokenFacadeReceiver = new Contract(
      tokenAddress,
      IHRC904TokenFacade,
      receiver,
    );

    walletIHRC904NftFacadeReceiver = new Contract(
      nftTokenAddress,
      IHRC904TokenFacade,
      receiver,
    );

    // Disabling automatic associations for receiver so all airdrops will be pending
    const disableAutoAssociations =
      await walletIHRC904AccountFacade.setUnlimitedAutomaticAssociations(
        false,
        {
          gasLimit: 2_000_000,
        },
      );
    await disableAutoAssociations.wait();
  });

  after(function () {
    hapi.client.close();
  });

  // Positive tests
  it('should cancel a pending airdrop for a fungible token (FT)', async function () {
    const initialBalance = await erc20Contract.balanceOf(
      tokenAddress,
      receiver.address,
    );

    await hapi.airdropFromSigner(0, receiver.address, {
      tokens: [{ token: tokenAddress, amount: 1 }],
    });
    const tx = await walletIHRC904TokenFacadeSender.cancelAirdropFT(
      receiver.address,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');

    const finalBalance = await erc20Contract.balanceOf(
      tokenAddress,
      receiver.address,
    );
    expect(finalBalance).to.equal(initialBalance);
  });

  it('should cancel a pending airdrop for a non-fungible token (NFT)', async function () {
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );

    await hapi.airdropFromSigner(0, receiver.address, {
      nfts: [{ token: nftTokenAddress, serials: [mintedTokenSerialNumber] }],
    });

    const tx = await walletIHRC904NftFacadeSender.cancelAirdropNFT(
      receiver.address,
      mintedTokenSerialNumber,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');

    const finalOwner = await erc721Contract.ownerOf(
      nftTokenAddress,
      mintedTokenSerialNumber,
    );
    expect(finalOwner).to.not.equal(receiver.address);
  });

  it('should enable unlimited automatic associations for an account', async function () {
    const tx =
      await walletIHRC904AccountFacade.setUnlimitedAutomaticAssociations(true, {
        gasLimit: 2_000_000,
      });
    const responseCode = await utils.getHASResponseCode(tx.hash);
    expect(responseCode).to.eq('22');

    const maxAssociations = await utils.getMaxAutomaticTokenAssociations(
      receiver.address,
    );
    expect(maxAssociations).to.eq(-1);
  });

  it('should disable unlimited automatic associations for an account', async function () {
    const tx =
      await walletIHRC904AccountFacade.setUnlimitedAutomaticAssociations(
        false,
        {
          gasLimit: 2_000_000,
        },
      );
    const responseCode = await utils.getHASResponseCode(tx.hash);
    expect(responseCode).to.eq('22');

    const maxAssociations = await utils.getMaxAutomaticTokenAssociations(
      receiver.address,
    );
    expect(maxAssociations).to.eq(0);
  });

  it('should claim a pending airdrop for a fungible token (FT)', async function () {
    const initialBalance = await erc20Contract.balanceOf(
      tokenAddress,
      receiver.address,
    );
    const amount = BigInt(1);

    await hapi.airdropFromSigner(0, receiver.address, {
      tokens: [{ token: tokenAddress, amount }],
    });
    await hapi.associateWithSigner(receiverPrivateKey, tokenAddress);

    const tx = await walletIHRC904TokenFacadeReceiver.claimAirdropFT(owner);
    await tx.wait();

    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');

    const finalBalance = await erc20Contract.balanceOf(
      tokenAddress,
      receiver.address,
    );
    expect(finalBalance).to.equal(initialBalance + amount);
  });

  it('should claim a pending airdrop for a non-fungible token (NFT)', async function () {
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );
    await hapi.airdropFromSigner(0, receiver.address, {
      nfts: [{ token: nftTokenAddress, serials: [mintedTokenSerialNumber] }],
    });

    const tx = await walletIHRC904NftFacadeReceiver.claimAirdropNFT(
      owner,
      mintedTokenSerialNumber,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');

    const finalOwner = await erc721Contract.ownerOf(
      nftTokenAddress,
      mintedTokenSerialNumber,
    );
    expect(finalOwner).to.equal(receiver.address);
  });

  it('should reject tokens for a given account (FT)', async function () {
    await hapi.airdropFromSigner(0, receiver.address, {
      tokens: [{ token: tokenAddress, amount: 1 }],
    });
    const tx = await walletIHRC904TokenFacadeReceiver.rejectTokenFT();
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');
  });

  it('should reject tokens for a given account and serial number (NFT)', async function () {
    const nftTokenAddress = await utils.setupNft(
      tokenCreateContract,
      owner,
      contractAddresses,
      hapi,
    );
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );
    await hapi.airdropFromSigner(0, signers[1].address, {
      nfts: [{ token: nftTokenAddress, serials: [mintedTokenSerialNumber] }],
    });

    const IHRC904TokenFacade = new ethers.Interface(
      (await hre.artifacts.readArtifact('IHRC904TokenFacade')).abi,
    );
    const walletIHRC904NftFacadeReceiver = new Contract(
      nftTokenAddress,
      IHRC904TokenFacade,
      signers[1],
    );

    await walletIHRC904NftFacadeReceiver.claimAirdropNFT(
      owner,
      mintedTokenSerialNumber,
    );

    const tx = await walletIHRC904NftFacadeReceiver.rejectTokenNFTs([
      mintedTokenSerialNumber,
    ]);

    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');
  });

  it('should reject 10 tokens for a given account and serial number (NFT)', async function () {
    const nftTokenAddress = await utils.setupNft(
      tokenCreateContract,
      owner,
      contractAddresses,
      hapi,
    );
    let serialNumbers = [];
    for (let i = 0; i < 10; i++) {
      serialNumbers.push(
        await utils.mintNFT(tokenCreateContract, nftTokenAddress),
      );
    }
    serialNumbers = serialNumbers.map(BigInt);

    await hapi.airdropFromSigner(0, signers[1].address, {
      nfts: [{ token: nftTokenAddress, serials: serialNumbers }],
    });

    const IHRC904TokenFacade = new ethers.Interface(
      (await hre.artifacts.readArtifact('IHRC904TokenFacade')).abi,
    );
    const walletIHRC904NftFacadeReceiver = new Contract(
      nftTokenAddress,
      IHRC904TokenFacade,
      signers[1],
    );

    for (const serialNumber of serialNumbers) {
      await walletIHRC904NftFacadeReceiver.claimAirdropNFT(owner, serialNumber);
    }

    const tx =
      await walletIHRC904NftFacadeReceiver.rejectTokenNFTs(serialNumbers);
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('22');
  });

  // Negative tests
  it('should fail to cancel a pending airdrop for FT when sender has no pending airdrops', async function () {
    const tx = await walletIHRC904TokenFacadeSender.cancelAirdropFT(
      receiver.address,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to cancel a pending airdrop for FT when receiver has no valid account', async function () {
    const tx =
      await walletIHRC904TokenFacadeSender.cancelAirdropFT(invalidAddress);
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to cancel a pending airdrop for NFT when sender has no pending airdrops', async function () {
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );
    const tx = await walletIHRC904NftFacadeSender.cancelAirdropNFT(
      signers[2].address,
      mintedTokenSerialNumber,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to cancel a pending airdrop for NFT when receiver has no valid account', async function () {
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );
    const tx = await walletIHRC904NftFacadeSender.cancelAirdropNFT(
      invalidAddress,
      mintedTokenSerialNumber,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to claim FT airdrop with no pending airdrops', async function () {
    const tx = await walletIHRC904TokenFacadeReceiver.claimAirdropFT(owner);
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to claim FT airdrop with an invalid account', async function () {
    const tx =
      await walletIHRC904TokenFacadeReceiver.claimAirdropFT(invalidAddress);
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to claim NFT airdrop with no pending airdrops', async function () {
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );
    const tx = await walletIHRC904NftFacadeReceiver.claimAirdropNFT(
      owner,
      mintedTokenSerialNumber,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to claim NFT airdrop with an invalid account', async function () {
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );
    const tx = await walletIHRC904NftFacadeReceiver.claimAirdropNFT(
      invalidAddress,
      mintedTokenSerialNumber,
    );
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('367'); // INVALID_PENDING_AIRDROP_ID code
  });

  it('should fail to reject FT tokens with no tokens', async function () {
    const tx = await walletIHRC904TokenFacadeReceiver.rejectTokenFT();
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('178'); // INSUFFICIENT_TOKEN_BALANCE code
  });

  it('should fail to reject FT tokens with an invalid account', async function () {
    // Trying to reject FT tokens with the treasury account
    const tx = await walletIHRC904TokenFacadeSender.rejectTokenFT();
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('196'); // ACCOUNT_IS_TREASURY code
  });

  it('should fail to reject NFT tokens with no tokens', async function () {
    const nftTokenAddress = await utils.setupNft(
      tokenCreateContract,
      owner,
      contractAddresses,
      hapi,
    );
    const mintedTokenSerialNumber = await utils.mintNFT(
      tokenCreateContract,
      nftTokenAddress,
    );

    const IHRC904TokenFacade = new ethers.Interface(
      (await hre.artifacts.readArtifact('IHRC904TokenFacade')).abi,
    );
    const walletIHRC904NftFacadeReceiver = new Contract(
      nftTokenAddress,
      IHRC904TokenFacade,
      signers[1],
    );

    const tx = await walletIHRC904NftFacadeReceiver.rejectTokenNFTs([
      mintedTokenSerialNumber,
    ]);
    const responseCode = await utils.getHTSResponseCode(tx.hash);
    expect(responseCode).to.eq('354'); // INVALID_OWNER_ID code
  });

  it('should revert when trying to reject NFT tokens when 11 or more serials are provided', async function () {
    const serialNumbers = [];
    for (let i = 0; i < 11; i++) {
      serialNumbers.push(
        await utils.mintNFT(tokenCreateContract, nftTokenAddress),
      );
    }

    await expect(walletIHRC904NftFacadeReceiver.rejectTokenNFTs(serialNumbers))
      .to.eventually.be.rejected;
  });
});
