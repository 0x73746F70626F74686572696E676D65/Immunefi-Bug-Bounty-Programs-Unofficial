
# Hiero @ Github

Welcome to Hiero, the Open Source Distributed Ledger Technology of the [Linux Foundation Decentralized Trust](https://www.lfdecentralizedtrust.org).
Hiero is an open-source, vendor-neutral distributed ledger technology. Hiero is used to build the [Hedera](https://hedera.com) public ledger.
You can find more information at our [website](https://hiero.org).

![repository-open-graph-template-2](https://github.com/user-attachments/assets/c0a1df9c-2a13-42ec-82ba-5e0df044750e)

## Resources

The following documents will help you to understand our vision, workflows and community. More documents will be added in the near future.

- Our [Code of Conduct](https://www.lfdecentralizedtrust.org/code-of-conduct).
- Our [CONTRIBUTING.md](https://github.com/hiero-ledger/.github/blob/main/CONTRIBUTING.md) is a good starting point if you want to contribute to Hiero.
- All global maintainers of the GitHub can be found at [GLOBAL-MAINTAINERS.md](https://github.com/hiero-ledger/.github/blob/main/GLOBAL-MAINTAINERS.md).
- For security related issues, please refer to our [SECURITY Policy](https://github.com/hiero-ledger/.github/blob/main/SECURITY.md). Do not post security related content, issues or discussions publicly in any repository.
- All our projects are licensed under the [Apache 2.0 license](https://github.com/hiero-ledger/.github/blob/main/LICENSE.md).
- Our [technical charter](https://github.com/hiero-ledger/governance/blob/main/hiero-technical-charter.md) gives an overview about our official workflows, processes and the work of the technical steering committee (TSC).
- Our [project roles and groups](https://github.com/hiero-ledger/governance/blob/main/roles/roles-and-groups.md) gives an overview of responsibilities and roles within any given project.
- We provide a [transfer document](https://github.com/hiero-ledger/governance/blob/main/processes/hedera-repo-transition-status.md) that shows the current state of the transition of Hedera projects to Hiero.
- We track a [transfer document for community driven projects](https://github.com/hiero-ledger/governance/blob/main/processes/community-repo-transition-status.md) that shows the current state of the transition of community projects to Hiero.
- Our [public calendar](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week) contains the open TSC and community meetings.

## Discord communication channels

Discord is a popular, free communication platform used by many communities, including open-source projects.

### How to Join and Find the Hiero Python SDK Channel

Follow these essential steps:

1.  **Join the Linux Foundation Decentralized Trust (LFDT) Server:**
    * Click the official invite link: **[LFDT Discord](https://discord.gg/hyperledger)**
    * If you're new to Discord, create a free account when prompted.
    * Follow Discord's instructions to enter the server.

2.  **Agree to Server Rules:**
    * Upon joining, you will likely land in a `#welcome` or `#rules` channel.
    * Read the server rules carefully. You **must agree** to these rules (usually via a button or emoji reaction ✅ at the bottom) to gain full access to the server channels.
    * Once you agree, other channels should become visible.

3.  **Access any of our available channels:**
   
| Channel Name / Join Link                                                                           | Channel Purpose                                                                                                                        |
| -------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| **[#hiero-announcements](https://discord.com/channels/905194001349627914/1283487046484234270)**  | Announcements on agenda, meetings happening, blog posts, events and participation opportunities.                                      |
| **[#hiero-consensus-node](https://discord.com/channels/905194001349627914/1380936805897080862)** | Conversations/questions/issues/updates in [hiero-consensus-node](https://github.com/hiero-ledger/hiero-consensus-node).               |
| **[#hiero-did-sdk-js](https://discord.com/channels/905194001349627914/1403132892007366806)**     | Conversations/questions/issues/updates in https://github.com/hiero-ledger/hiero-did-sdk-js.                                           |
| **[#hiero-did-sdk-python](https://discord.com/channels/905194001349627914/1339549374782378027)** | Conversations/questions/issues/updates in https://github.com/hiero-ledger/hiero-did-sdk-python.                                       |
| **[#hiero-enterprise-java](https://discord.com/channels/905194001349627914/1370373361942663178)**| Conversations on future transfer of [hiero-enterprise-java](https://github.com/OpenElements/hiero-enterprise-java/issues/172).        |
| **[#hiero-general](https://discord.com/channels/905194001349627914/1289954446712770600)**        | General questions, conversations and discussions not necesarily related to a specific component.                                       |
| **[#hiero-hips](https://discord.com/channels/905194001349627914/1354514446898430032)**           | Conversations/questions/issues/updates in [hiero-improvement-proposals](https://github.com/hiero-ledger/hiero-improvement-proposals). |
| **[#hiero-maintainers](https://discord.com/channels/905194001349627914/1283487103006543952)**    | Conversations, taskforce events, issues and related topic for maintainers.                                                             |
| **[#hiero-mirror-node](https://discord.com/channels/905194001349627914/1374414879334596739)**    | Conversations/questions/issues/updates in [hiero-mirror-node](https://github.com/hiero-ledger/hiero-mirror-node).                     |
| **[#hiero-sdk-cpp](https://discord.com/channels/905194001349627914/1337424839761465364)**        | Conversations/questions/issues/updates in [hiero-sdk-cpp](https://github.com/hiero-ledger/hiero-sdk-cpp).                             |
| **[#hiero-sdk-go](https://discord.com/channels/905194001349627914/1337424630289404015)**         | Conversations/questions/issues/updates in [hiero-sdk-go](https://github.com/hiero-ledger/hiero-sdk-go).                               |
| **[#hiero-sdk-java](https://discord.com/channels/905194001349627914/1337424581652381696)**       | Conversations/questions/issues/updates in [hiero-sdk-java](https://github.com/hiero-ledger/hiero-sdk-java).                           |
| **[#hiero-sdk-js](https://discord.com/channels/905194001349627914/1337424656138899537)**         | Conversations/questions/issues/updates in [hiero-sdk-js](https://github.com/hiero-ledger/hiero-sdk-js).                               |
| **[#hiero-sdk-python](https://discord.com/channels/905194001349627914/1336494517544681563)**     | Conversations/questions/issues/updates in [hiero-sdk-python](https://github.com/hiero-ledger/hiero-sdk-python).                       |
| **[#hiero-sdk-rust](https://discord.com/channels/905194001349627914/1400196736244518982)**       | Conversations/questions/issues/updates in [hiero-sdk-rust](https://github.com/hiero-ledger/hiero-sdk-rust).                           |
| **[#hiero-sdk-swift](https://discord.com/channels/905194001349627914/1337424716238946344)**      | Conversations/questions/issues/updates in [hiero-sdk-swift](https://github.com/hiero-ledger/hiero-sdk-swift).                         |
| **[#hiero-sdk-tck](https://discord.com/channels/905194001349627914/1336034637310464031)**        | Conversations/questions/issues/updates in [hiero-sdk-tck](https://github.com/hiero-ledger/hiero-sdk-tck).                             |
| **[#hiero-solo-action](https://discord.com/channels/905194001349627914/1337046798472052776)**    | Conversations/questions/issues/updates in [hiero-solo-action](https://github.com/hiero-ledger/hiero-solo-action).                     |
| **[#solo](https://discord.com/channels/905194001349627914/1364886813017247775)**                 | Conversations/questions/issues/updates in [solo](https://github.com/hiero-ledger/solo).                                                |

You can also select specific channels under the "hiero" category so these channels will appear in your left navigation panel

## Open Community Meetings and TSC schedules

| Community Meeting     | Meeting occurrence link                                                                                           | Registration link                                                                                                                       |
| --------------------- | ----------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| Community Call              | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1758207600) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/97122675754?password=7eaa865a-2f17-4a7c-97b0-aff51933991c&invite=true) |
| Community Management        | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1776173400) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/98394707679?password=47f9cfb9-3704-4396-b5b3-6cfe76e510d2&invite=true) |
| Good First Issue            | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1776348000) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/99434549287?password=6e659f58-1b9e-4205-ac7d-7f352f3bd340&invite=true) |
| Block Stream Community Group | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1763053200) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/94618152832?password=3b037576-2aab-4f7e-ab24-acf9ca2c3734&invite=true) |
| Hiero/Hedera Identity       | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1763049600) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/99097542854?password=3ee2d9c9-32de-4758-8a23-417c751bd7ab&invite=true) |
| Monthly Maintainers         | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1761750000) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/99574473075?password=deff3fc9-0e80-4877-80de-91499b5480e9&invite=true) |
| Python SDK                  | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1758117600) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/92041330205?password=2f345bee-0c14-4dd5-9883-06fbc9c60581&invite=true) |
| SDK                         | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1757340000) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/94709702244?password=bcba4892-928c-47e0-9a21-e1abca95f7d3&invite=true) |
| Solo                        | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1757433600) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/94695703550?password=e8819002-3f6e-4905-9916-b049f501e866&invite=true) |
| Solo Action                 | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1757944800) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/92576669768?password=8dab94bb-7315-4d37-a944-b1fa0e924741&invite=true) |
| TSC meeting                 | [LFX Calendar link](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week&occurrence=1758031200) | [Register](https://zoom-lfx.platform.linuxfoundation.org/meeting/95775743341?password=c07443bf-b0e6-4a68-93f1-5c7ce9bb49ab&invite=true) |
## Meeting Recordings

There are two ways to access past meeting recordings:

1. Via [LFX Individual Dashboard](https://openprofile.dev/) - Create and complete your profile. Look for past meeting recordings under [My Meetings](https://openprofile.dev/my-meetings) section.
   Recordings of meetings you are registered to will appear in the list. If you need to be registered to a specific meeting series, register using the button above or let LF Staff know via [Discord](https://discord.lfdecentralizedtrust.org/).
2. Via [Hiero Calendar](https://zoom-lfx.platform.linuxfoundation.org/meetings/hiero?view=week) - Browse meeting recordings in the calendar. Recordings appear aprox an hour after the meeting has ended.    

## LFX Tooling

LFX is Linux Foundation’s comprehensive, free-to-use open source project collaboration platform designed to help developers, maintainers, organizations, and contributors streamline and scale open source initiatives.
Linux Foundation hosted projects gain valuable support from these tools for streamlined project monitoring and administration.
[Learn more about LFX](https://lfx.linuxfoundation.org/).

- [LFX Individual Dashboard](https://openprofile.dev/) - Is a self-service hub for all of your open source activity and great tool to easily access past meeting recordings. [Read More](https://docs.linuxfoundation.org/lfx/my-profile).
- [LFX Insights](https://insights.linuxfoundation.org/) - This tool helps developers and their organizations make smarter decisions about the open source projects by tracking their project's health.[Read More](https://insights.linuxfoundation.org/docs/introduction/what-is-insights/) [Contribute!](https://github.com/linuxfoundation/insights).
- [LFX Mentorship](https://mentorship.lfx.linuxfoundation.org/#projects_all) - This tool contains all available mentorship programs where mentors can participate to present a specific program to registered mentees. [Read More](https://docs.linuxfoundation.org/lfx/mentorship).
