#!/usr/bin/env bash
CUR_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "${CUR_DIR}/env.sh"

KCTL="$(command -v kubectl)"

EX_OK=0
EX_ERR=1
MAX_ATTEMPTS=60
HGCAPP_DIR="/opt/hgcapp"
NMT_DIR="${HGCAPP_DIR}/node-mgmt-tools"
HAPI_PATH="${HGCAPP_DIR}/services-hedera/HapiApp2.0"
HEDERA_HOME_DIR="/home/hedera"
RELEASE_NAME="${RELEASE_NAME:-solo}"

NMT_VERSION="${NMT_VERSION:-v1.3.4}"
NMT_RELEASE_URL="https://api.github.com/repos/hashgraph/node-management-tools/releases/tags/${NMT_VERSION}"
NMT_INSTALLER="node-mgmt-tools-installer-${NMT_VERSION}.run"
NMT_INSTALLER_DIR="${SCRIPT_DIR}/../resources/nmt"
NMT_INSTALLER_PATH="${NMT_INSTALLER_DIR}/${NMT_INSTALLER}"
NMT_PROFILE="jrs" # we only allow jrs profile

PLATFORM_VERSION="${PLATFORM_VERSION:-v0.71.0}"
PLATFORM_INSTALLER="build-${PLATFORM_VERSION}.zip"
PLATFORM_INSTALLER_DIR="${SCRIPT_DIR}/../resources/platform"
PLATFORM_INSTALLER_PATH="${PLATFORM_INSTALLER_DIR}/${PLATFORM_INSTALLER}"
PLATFORM_INSTALLER_URL=$(prepare_platform_software_URL "${PLATFORM_VERSION}")

OPENJDK_VERSION="${OPENJDK_VERSION:-21.0.1}"

function log_time() {
  local end_time duration execution_time

  local func_name=$1

  end_time=$(date +%s)
  duration=$((end_time - start_time))
  execution_time=$(printf "%.2f seconds" "${duration}")
  echo "-----------------------------------------------------------------------------------------------------"
  echo "<<< ${func_name} execution took: ${execution_time} >>>"
  echo "-----------------------------------------------------------------------------------------------------"
}

# Fetch NMT release
function fetch_nmt() {
  echo ""
  echo "Fetching NMT ${NMT_VERSION}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [[ -f "${NMT_INSTALLER_PATH}" ]]; then
    echo "Found NMT installer: ${NMT_INSTALLER_PATH}"
    return "${EX_OK}"
  fi

  mkdir -p "${NMT_INSTALLER_DIR}"

  # fetch nmt version.properties file to find the actual release file name
  local release_dir=$(parse_release_dir "${NMT_VERSION}")
  local nmt_version_url="https://builds.hedera.com/node/mgmt-tools/${release_dir}/version.properties"
  echo "NMT version.properties URL: ${nmt_version_url}"
  curl -L "${nmt_version_url}" -o "${NMT_INSTALLER_DIR}/version.properties" || return "${EX_ERR}"
  cat "${NMT_INSTALLER_DIR}/version.properties"

  # parse version.properties file to determine the actual URL
  local nmt_release_file=$(grep "^${NMT_VERSION}" "${NMT_INSTALLER_DIR}/version.properties"|cut -d'=' -f2)
  local nmt_release_url="https://builds.hedera.com/node/mgmt-tools/${release_dir}/${nmt_release_file}"
  echo "NMT release URL: ${nmt_release_url}"
  curl -L "${nmt_release_url}" -o "${NMT_INSTALLER_PATH}" || return "${EX_ERR}"
  ls -la "${NMT_INSTALLER_DIR}"

  return "${EX_OK}"
}

# Fetch platform build.zip file
function fetch_platform_build() {
  echo ""
  echo "Fetching Platform ${PLATFORM_VERSION}: ${PLATFORM_INSTALLER_URL}"
  echo "Local path: ${PLATFORM_INSTALLER_PATH}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [[ -f "${PLATFORM_INSTALLER_PATH}" ]]; then
    echo "Found Platform installer: ${PLATFORM_INSTALLER_PATH}"
    return "${EX_OK}"
  fi

  mkdir -p "${PLATFORM_INSTALLER_DIR}"
  curl -L "${PLATFORM_INSTALLER_URL}" -o "${PLATFORM_INSTALLER_PATH}" || return "${EX_ERR}"
  return "${EX_OK}"
}

function reset_node() {
  local pod="${1}"

  echo ""
  echo "Resetting node ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'reset_nmt' - pod name is required"
    return "${EX_ERR}"
  fi

  # best effort clean up of docker env
  "${KCTL}" exec "${pod}" -c root-container -- bash -c "docker stop \$(docker ps -aq)" || true
  "${KCTL}" exec "${pod}" -c root-container -- bash -c "docker rm -f \$(docker ps -aq)" || true
  "${KCTL}" exec "${pod}" -c root-container -- bash -c "docker rmi -f \$(docker images -aq)" || true

  "${KCTL}" exec "${pod}" -c root-container -- rm -rf "${NMT_DIR}" || true
  "${KCTL}" exec "${pod}" -c root-container -- rm -rf "${HAPI_PATH}" || true

  ls_path "${pod}" "${HGCAPP_DIR}"
  set_permission "${pod}" "${HGCAPP_DIR}"

  return "${EX_OK}"
}

# Copy NMT into root-container
function copy_nmt() {
  local pod="${1}"

  echo ""
  echo "Copying NMT to ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'copy_nmt' - pod name is required"
    return "${EX_ERR}"
  fi

  echo "Copying ${NMT_INSTALLER_PATH} -> ${pod}:${HEDERA_HOME_DIR}"
  "${KCTL}" cp "${NMT_INSTALLER_PATH}" "${pod}":"${HEDERA_HOME_DIR}" -c root-container || return "${EX_ERR}"

  return "${EX_OK}"
}

function set_permission() {
  local pod="${1}"
  local path="${2}"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'set_permission' - pod name is required"
    return "${EX_ERR}"
  fi

  if [ -z "${path}" ]; then
    echo "ERROR: 'set_permission' - path is required"
    return "${EX_ERR}"
  fi

  local mode=0755

  echo "Changing ownership of ${pod}:${path}"
  "${KCTL}" exec "${pod}" -c root-container -- chown -R hedera:hedera "${path}" || return "${EX_ERR}"

  echo "Changing permission to ${mode} of ${pod}:${path}"
  "${KCTL}" exec "${pod}" -c root-container -- chmod -R "${mode}" "${path}" || return "${EX_ERR}"

  echo ""
  ls_path "${pod}" "${path}"

  return "${EX_OK}"
}

# Copy platform installer into root-container
function copy_platform() {
  local pod="${1}"

  echo ""
  echo "Copying Platform to ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'copy_platform' - pod name is required"
    return "${EX_ERR}"
  fi

  echo "Copying ${PLATFORM_INSTALLER_PATH} -> ${pod}:${HEDERA_HOME_DIR}"
  "${KCTL}" cp "${PLATFORM_INSTALLER_PATH}" "${pod}":"${HEDERA_HOME_DIR}" -c root-container || return "${EX_ERR}"

  return "${EX_OK}"
}

# copy files and set ownership to hedera:hedera
function copy_files() {
  local pod="${1}"
  local srcDir="${2}"
  local file="${3}"
  local dstDir="${4}"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'copy_files' - pod name is required"
    return "${EX_ERR}"
  fi
  if [ -z "${srcDir}" ]; then
    echo "ERROR: 'copy_files' - src path is required"
    return "${EX_ERR}"
  fi

  if [ -z "${file}" ]; then
    echo "ERROR: 'copy_files' - file path is required"
    return "${EX_ERR}"
  fi

  if [ -z "${dstDir}" ]; then
    echo "ERROR: 'copy_files' - dstDir path is required"
    return "${EX_ERR}"
  fi

  echo ""
  echo "Copying ${srcDir}/${file} -> ${pod}:${dstDir}/"
  "${KCTL}" cp "$srcDir/${file}" "${pod}:${dstDir}/" -c root-container || return "${EX_ERR}"

  set_permission "${pod}" "${dstDir}/${file}"

  return "${EX_OK}"
}

# Copy hedera keys
function copy_hedera_keys() {
  local pod="${1}"

  echo ""
  echo "Copy hedera TLS keys to ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'copy_hedera_keys' - pod name is required"
    return "${EX_ERR}"
  fi

  local srcDir="${SCRIPT_DIR}/../local-node"
  local dstDir="${HAPI_PATH}"
  local files=(
    "hedera.key"
    "hedera.crt"
  )

  for file in "${files[@]}"; do
    copy_files "${pod}" "${srcDir}" "${file}" "${dstDir}" || return "${EX_ERR}"
  done

  return "${EX_OK}"
}

# Copy config files
function copy_config_files() {
  local node="${1}"
  local pod="${2}"

  echo ""
  echo "Copy config to ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${node}" ]; then
    echo "ERROR: 'copy_config_files' - node name is required"
    return "${EX_ERR}"
  fi

  if [ -z "${pod}" ]; then
    echo "ERROR: 'copy_config_files' - pod name is required"
    return "${EX_ERR}"
  fi

  # copy the correct log42j file locally before copying into the container
  local srcDir="${TMP_DIR}"
  local dstDir="${HAPI_PATH}"
  cp -f "${SCRIPT_DIR}/../local-node/log4j2-${NMT_PROFILE}.xml" "${TMP_DIR}/log4j2.xml" || return "${EX_ERR}"
  local files=(
    "log4j2.xml"
  )
  for file in "${files[@]}"; do
    copy_files "${pod}" "${srcDir}" "${file}" "${dstDir}" || return "${EX_ERR}"
  done

  # copy files into the containers
  local srcDir="${SCRIPT_DIR}/../local-node"
  local files=(
    "settings.txt"
  )
  for file in "${files[@]}"; do
    copy_files "${pod}" "${srcDir}" "${file}" "${dstDir}" || return "${EX_ERR}"
  done

  # copy config properties files
  local srcDir="${SCRIPT_DIR}/../local-node/data/config"
  local dstDir="${HAPI_PATH}/data/config"
  local files=(
    "api-permission.properties"
    "application.properties"
    "bootstrap.properties"
  )

  for file in "${files[@]}"; do
    copy_files "${pod}" "${srcDir}" "${file}" "${dstDir}" || return "${EX_ERR}"
  done

  # create gc.log file since otherwise node doesn't start when using older NMT releases (e.g. v1.2.2)
  "${KCTL}" exec  "${pod}" -c root-container -- touch "${HAPI_PATH}/gc.log" || return "${EX_ERR}"
  set_permission "${pod}" "${HAPI_PATH}/gc.log"



  return "${EX_OK}"
}

function ls_path() {
  local pod="${1}"
  local path="${2}"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'ls_path' - pod name is required"
    return "${EX_ERR}"
  fi

  if [ -z "${path}" ]; then
    echo "ERROR: 'ls_path' - path is required"
    return "${EX_ERR}"
  fi

  echo ""
  echo "Displaying contents of ${path} from ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  echo "Running: "${KCTL}" exec ${pod} -c root-container -- ls -al ${path}"
  "${KCTL}" exec "${pod}" -c root-container -- ls -al "${path}"
}

function cleanup_path() {
  local pod="${1}"
  local path="${2}"

  echo ""
  echo "Cleanup pod directory ${HGCAPP_DIR} in ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'cleanup_path' - pod name is required"
    return "${EX_ERR}"
  fi

  if [ -z "${path}" ]; then
    echo "ERROR: 'ls_path' - path is required"
    return "${EX_ERR}"
  fi

  "${KCTL}" exec "${pod}" -c root-container -- bash -c "rm -rf ${path}" || return "${EX_ERR}"
  return "${EX_OK}"
}

function install_nmt() {
  local pod="${1}"

  echo ""
  echo "Install NMT to ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'install_nmt' - pod name is required"
    return "${EX_ERR}"
  fi

  # do not call rm directoires for nmt install
  # cleanup_path "${pod}" "${HGCAPP_DIR}/*" || return "${EX_ERR}"
  "${KCTL}" exec "${pod}" -c root-container -- chmod +x "${HEDERA_HOME_DIR}/${NMT_INSTALLER}" || return "${EX_ERR}"
  "${KCTL}" exec "${pod}" -c root-container -- sudo "${HEDERA_HOME_DIR}/${NMT_INSTALLER}" --accept -- -fg || return "${EX_ERR}"

  return "${EX_OK}"
}

function nmt_preflight() {
  local pod="${1}"

  echo ""
  echo "Run Preflight in ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'nmt_preflight' - pod name is required"
    return "${EX_ERR}"
  fi

  "${KCTL}" exec "${pod}" -c root-container -- \
    node-mgmt-tool -VV preflight -j "${OPENJDK_VERSION}" -df -i "${NMT_PROFILE}" -k 256m -m 512m || return "${EX_ERR}"

  return "${EX_OK}"
}

function nmt_install() {
  local pod="${1}"

  echo ""
  echo "Run Install in ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'nmt_install' - pod name is required"
    return "${EX_ERR}"
  fi

  "${KCTL}" exec "${pod}" -c root-container -- \
    node-mgmt-tool -VV install \
    -p "${HEDERA_HOME_DIR}/${PLATFORM_INSTALLER}" \
    -n "${node_name}" \
    -x "${PLATFORM_VERSION}" ||
    return "${EX_ERR}"

  "${KCTL}" exec "${pod}" -c root-container -- \
    docker images && docker ps -a

  return "${EX_OK}"
}

function nmt_start() {
  local pod="${1}"

  echo ""
  echo "Starting platform node in ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'nmt_start' - pod name is required"
    return "${EX_ERR}"
  fi

  # remove old logs
  "${KCTL}" exec "${pod}" -c root-container -- bash -c "rm -f ${HAPI_PATH}/logs/*" || true

  "${KCTL}" exec "${pod}" -c root-container -- node-mgmt-tool -VV start || return "${EX_ERR}"

  local attempts=0
  local max_attempts=$MAX_ATTEMPTS
  local status=$("${KCTL}" exec "${pod}" -c root-container -- docker ps -q)
  while [[ "${attempts}" -lt "${max_attempts}" && "${status}" = "" ]]; do
    echo ">> Waiting 5s to let the containers start ${pod}: Attempt# ${attempts}/${max_attempts} ..."
    sleep 5

    "${KCTL}" exec "${pod}" -c root-container -- docker ps || return "${EX_ERR}"

    status=$("${KCTL}" exec "${pod}" -c root-container -- docker ps -q)
    attempts=$((attempts + 1))
  done

  if [[ -z "${status}" ]]; then
    echo "ERROR: Containers didn't start"
    return "${EX_ERR}"
  fi

  sleep 20
  echo "Containers started..."
  "${KCTL}" exec "${pod}" -c root-container -- docker ps -a || return "${EX_ERR}"
  sleep 10

  local podState podStateErr
  podState="$("${KCTL}" exec "${pod}" -c root-container -- docker ps -a -f 'name=swirlds-node' --format '{{.State}}')"
  podStateErr="${?}"

  if [[ "${podStateErr}" -ne 0 || -z "${podState}" || "${podState}" != "running" ]]; then
    echo "ERROR: 'nmt_start' - swirlds-node container is not running"
    return "${EX_ERR}"
  fi

  echo "Fetching logs from swirlds-haveged..."

  "${KCTL}" exec "${pod}" -c root-container -- docker logs --tail 10 swirlds-haveged || return "${EX_ERR}"

  echo "Fetching logs from swirlds-node..."
  "${KCTL}" exec "${pod}" -c root-container -- docker logs --tail 10 swirlds-node  || return "${EX_ERR}"

  return "${EX_OK}"
}

function nmt_stop() {
  local pod="${1}"

  echo ""
  echo "Stopping platform node in ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  if [ -z "${pod}" ]; then
    echo "ERROR: 'nmt_stop' - pod name is required"
    return "${EX_ERR}"
  fi

  "${KCTL}" exec "${pod}" -c root-container -- node-mgmt-tool -VV stop || return "${EX_ERR}"

  # cleanup
  echo "Waiting 15s to let the containers stop..."
  sleep 15
  "${KCTL}" exec "${pod}" -c root-container -- docker ps -a || return "${EX_ERR}"
  echo "Removing containers..."
  #  "${KCTL}" exec "${pod}" -c root-container -- bash -c "docker stop \$(docker ps -aq)" || true
  "${KCTL}" exec "${pod}" -c root-container -- bash -c "docker rm -f \$(docker ps -aq)" || true
  "${KCTL}" exec "${pod}" -c root-container -- docker ps -a || return "${EX_ERR}"

  return "${EX_OK}"
}

function verify_network_state() {
  local pod="${1}"
  local max_attempts="${2}"

  echo ""
  echo "Checking network status in ${pod}"
  echo "-----------------------------------------------------------------------------------------------------"

  local attempts=0
  local status=""

  local LOG_PATH="${HAPI_PATH}/logs/hgcaa.log"
  local status_pattern="ACTIVE"

  while [[ "${attempts}" -lt "${max_attempts}" && "${status}" != *"${status_pattern}"* ]]; do
    sleep 5

    attempts=$((attempts + 1))

    echo "====================== ${pod}: Attempt# ${attempts}/${max_attempts} ==================================="

    set +e
    status="$("${KCTL}" exec "${pod}" -c root-container -- cat "${LOG_PATH}" | grep "${status_pattern}")"
    set -e

    if [[ "${status}" != *"${status_pattern}"* ]]; then
      "${KCTL}" exec "${pod}" -c root-container -- ls -la "${HAPI_PATH}/logs"

      # show swirlds.log to see what node is doing
      "${KCTL}" exec "${pod}" -c root-container -- tail -n 5 "${HAPI_PATH}/logs/swirlds.log"
    else
      echo "${status}"
    fi
  done

  if [[ "${status}" != *"${status_pattern}"* ]]; then
    # capture the docker log in a local file for investigation
    "${KCTL}" exec "${pod}" -c root-container -- docker logs swirlds-node >"${TMP_DIR}/${pod}-swirlds-node.log"

    echo "ERROR: <<< The network is not operational in ${pod}. >>>"
    return "${EX_ERR}"
  fi

  echo "====================== ${pod}: Status check complete ==================================="
  return "$EX_OK"
}

function verify_haproxy() {
  # iterate over each haprox pod check if READY is 1/1
  local pods=$("${KCTL}" get pods -l solo.hedera.com/type=haproxy -o jsonpath='{.items[*].metadata.name}')
  for pod in ${pods}; do
    local status=$("${KCTL}" get pod "${pod}" -o 'jsonpath={..status.conditions[?(@.type=="Ready")].status}')
    if [[ "${status}" != "True" ]]; then
      echo "ERROR: <<< HAProxy pod ${pod} is not ready. >>>"
      return "${EX_ERR}"
    fi
    echo "HAProxy pod ${pod} is ready"
  done
  return "${EX_OK}"
}

function verify_node_all() {
  if [[ "${#NODE_NAMES[*]}" -le 0 ]]; then
    echo "ERROR: Node list is empty. Set NODE_NAMES env variable with a list of nodes"
    return "${EX_ERR}"
  fi
  echo ""
  echo "Verifying node status ${NODE_NAMES[*]} ${#NODE_NAMES[@]}"
  echo "-----------------------------------------------------------------------------------------------------"

  local node_name
  for node_name in "${NODE_NAMES[@]}"; do
    local pod="network-${node_name}-0" # pod name
    verify_network_state "${pod}" "${MAX_ATTEMPTS}" || return "${EX_ERR}"
    log_time "verify_network_state"
  done

  return "${EX_OK}"
}

# copy all node keys
function replace_keys_all() {
  if [[ "${#NODE_NAMES[*]}" -le 0 ]]; then
    echo "ERROR: Node list is empty. Set NODE_NAMES env variable with a list of nodes"
    return "${EX_ERR}"
  fi
  echo ""
  echo "Processing nodes ${NODE_NAMES[*]} ${#NODE_NAMES[@]}"
  echo "-----------------------------------------------------------------------------------------------------"

  local node_name
  for node_name in "${NODE_NAMES[@]}"; do
    local pod="network-${node_name}-0" # pod name
    copy_hedera_keys "${pod}" || return "${EX_ERR}"
    log_time "replace_keys"
  done

  return "${EX_OK}"
}

function reset_node_all() {
  if [[ "${#NODE_NAMES[*]}" -le 0 ]]; then
    echo "ERROR: Node list is empty. Set NODE_NAMES env variable with a list of nodes"
    return "${EX_ERR}"
  fi
  echo ""
  echo "Processing nodes ${NODE_NAMES[*]} ${#NODE_NAMES[@]}"
  echo "-----------------------------------------------------------------------------------------------------"

  local node_name
  for node_name in "${NODE_NAMES[@]}"; do
    local pod="network-${node_name}-0" # pod name
    reset_node "${pod}" || return "${EX_ERR}"
    log_time "reset_node"
  done

  return "${EX_OK}"
}
