# @hiero-did-sdk/hcs

## 0.2.1

### Patch Changes

- 6c6bce5: Fix multi-page Mirror Node REST API queries
- Updated dependencies [6c6bce5]
  - @hiero-did-sdk/zstd@0.2.1
  - @hiero-did-sdk/cache@0.2.1
  - @hiero-did-sdk/client@0.2.1
  - @hiero-did-sdk/core@0.2.1
  - @hiero-did-sdk/crypto@0.2.1

## 0.2.0

### Minor Changes

- 5366367: Migrate to new Hiero SDK JS package namespace + security fixes

### Patch Changes

- Updated dependencies [5366367]
  - @hiero-did-sdk/client@0.2.0
  - @hiero-did-sdk/crypto@0.2.0
  - @hiero-did-sdk/cache@0.2.0
  - @hiero-did-sdk/core@0.2.0
  - @hiero-did-sdk/zstd@0.2.0

## 0.1.8

### Patch Changes

- 0008e01: Use Hiero Solo for integration tests + security updates
- Updated dependencies [0008e01]
  - @hiero-did-sdk/client@0.1.8
  - @hiero-did-sdk/core@0.1.8
  - @hiero-did-sdk/cache@0.1.8
  - @hiero-did-sdk/crypto@0.1.8
  - @hiero-did-sdk/zstd@0.1.8

## 0.1.7

### Patch Changes

- 1544666: Allow multibase key prefix in DID identifier
- Updated dependencies [1544666]
  - @hiero-did-sdk/core@0.1.7
  - @hiero-did-sdk/cache@0.1.7
  - @hiero-did-sdk/client@0.1.7
  - @hiero-did-sdk/crypto@0.1.7
  - @hiero-did-sdk/zstd@0.1.7

## 0.1.6

### Patch Changes

- 532336c: Use 'v1' version in AnonCreds identifiers + update dependencies
- 9554e93: ESM compatibility fixes
- Updated dependencies [532336c]
- Updated dependencies [9554e93]
  - @hiero-did-sdk/client@0.1.6
  - @hiero-did-sdk/core@0.1.6
  - @hiero-did-sdk/cache@0.1.6
  - @hiero-did-sdk/crypto@0.1.6
  - @hiero-did-sdk/zstd@0.1.6

## 0.1.5

### Patch Changes

- Use CJS for React Native + split optional dependencies loading
- Updated dependencies
  - @hiero-did-sdk/client@0.1.5
  - @hiero-did-sdk/crypto@0.1.5
  - @hiero-did-sdk/cache@0.1.5
  - @hiero-did-sdk/core@0.1.5
  - @hiero-did-sdk/zstd@0.1.5

## 0.1.4

### Patch Changes

- Use Signer in HCS and AnonCreds packages API
- Updated dependencies
  - @hiero-did-sdk/cache@0.1.4
  - @hiero-did-sdk/core@0.1.4
  - @hiero-did-sdk/client@0.1.4
  - @hiero-did-sdk/crypto@0.1.4
  - @hiero-did-sdk/zstd@0.1.4

## 0.1.3

### Patch Changes

- f95ba48: Support Ed25519VerificationMethod2020 multicodec prefix
- bb5b2bf: Fixed an issue where multiple actions to update and deactivate a document's DID could not be performed when using a Client instance
- Updated dependencies [f95ba48]
- Updated dependencies [bb5b2bf]
  - @hiero-did-sdk/client@0.1.3
  - @hiero-did-sdk/core@0.1.3
  - @hiero-did-sdk/cache@0.1.3
  - @hiero-did-sdk/crypto@0.1.3
  - @hiero-did-sdk/zstd@0.1.3

## 0.1.2

### Patch Changes

- @hiero-did-sdk/cache@0.1.2
- @hiero-did-sdk/client@0.1.2
- @hiero-did-sdk/core@0.1.2
- @hiero-did-sdk/crypto@0.1.2
- @hiero-did-sdk/zstd@0.1.2

## 0.1.1

### Patch Changes

- 8f91471: Fixed issue with publishing files in HCS-1 standard
- Updated dependencies [8f91471]
  - @hiero-did-sdk/cache@0.1.1
  - @hiero-did-sdk/client@0.1.1
  - @hiero-did-sdk/core@0.1.1
  - @hiero-did-sdk/crypto@0.1.1
  - @hiero-did-sdk/zstd@0.1.1
