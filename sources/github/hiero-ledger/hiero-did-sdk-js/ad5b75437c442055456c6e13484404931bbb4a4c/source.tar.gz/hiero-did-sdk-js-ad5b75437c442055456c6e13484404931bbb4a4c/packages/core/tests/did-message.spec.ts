import { TestDIDMessage, TestVerifier } from './helpers';
import { Buffer } from 'buffer';
import { Signer } from '@hiero-did-sdk/core';

const mockSignature = new Uint8Array([1, 2, 3, 4]);

const mockSigner = {
  publicKey: vi.fn(),
  sign: vi.fn().mockResolvedValue(mockSignature),
  verify: vi.fn().mockResolvedValue(true),
} as unknown as Signer;

describe('DID Message', () => {
  let message: TestDIDMessage;

  beforeEach(() => {
    message = new TestDIDMessage();
  });

  it('should return message as a JSON string in bytes', () => {
    const messagePayload = {
      foo: 'bar',
    };

    message.messageMock.mockReturnValue(messagePayload);
    const messageBytes = message.messageBytes;

    expect(messageBytes).toBeInstanceOf(Uint8Array);
    expect(messageBytes).toEqual(new TextEncoder().encode(JSON.stringify(messagePayload)));
  });

  it('should return proper payload of the message', async () => {
    const messagePayload = {
      foo: 'bar',
    };
    const verifier = new TestVerifier();
    verifier.verifyMock.mockReturnValue(true);

    message.messageMock.mockReturnValue(messagePayload);
    await message.setSignature(mockSignature, verifier);

    const payload = message.payload;

    expect(typeof payload).toBe('string');
    expect(JSON.parse(payload)).toMatchObject({
      message: messagePayload,
      signature: Buffer.from(mockSignature).toString('base64'),
    });
  });

  it('should throw an error if signature is missing in payload', () => {
    const messagePayload = {
      foo: 'bar',
    };

    message.messageMock.mockReturnValue(messagePayload);

    expect(() => message.payload).toThrow(
      'DID message is missing a signature. Signature is required to construct a DID message payload.'
    );
  });

  it('should set the valid signature of the message', async () => {
    const signature = new Uint8Array([1, 2, 3, 4]);
    const verifier = new TestVerifier();
    verifier.verifyMock.mockReturnValue(true);

    await message.setSignature(signature, verifier);

    expect(message.signature).toEqual(signature);
  });

  it('should throw an error when invalid signature', async () => {
    const signature = new Uint8Array([1, 2, 3, 4]);
    const verifier = new TestVerifier();
    verifier.verifyMock.mockReturnValue(false);

    await expect(() => message.setSignature(signature, verifier)).rejects.toThrow('The signature is invalid');

    expect(message.signature).toBeUndefined();
  });

  it('should sign the message with the given signer', async () => {
    const verifier = {
      publicKey: vi.fn(),
      verify: vi.fn().mockResolvedValue(true),
    };

    await message.signWith(mockSigner, verifier);

    expect(mockSigner.sign).toHaveBeenCalledWith(message.messageBytes);
    expect(message.signature).toEqual(mockSignature);
  });

  it('should throw an error if the signer is invalid', async () => {
    const verifier = {
      publicKey: vi.fn(),
      verify: vi.fn().mockResolvedValue(false),
    };

    await expect(() => message.signWith(mockSigner, verifier)).rejects.toThrow(
      'The signature is invalid. Provided signer does not match the DID signer.'
    );

    expect(message.signature).toBeUndefined();
  });
});
