import {
  LifecycleRunner,
  RunnerState,
} from '@hiero-did-sdk/lifecycle';
import { Publisher } from '@hiero-did-sdk/core';
import { TopicMessageSubmitTransaction } from '@hiero-ledger/sdk';
import {
  DIDDeactivateMessage,
  DIDDeactivateMessageHederaCSMLifeCycle,
} from '../../../src';
import { SIGNATURE, TestVerifier, VALID_DID } from '../helpers';


describe('Client mode DIDDeactivateMessage Lifecycle', () => {
  describe('when processing a valid DIDDeactivateMessage', () => {
    const verifier = new TestVerifier();
    let publishMock: vi.Mock;
    let message: DIDDeactivateMessage;
    let result: RunnerState<DIDDeactivateMessage>;

    beforeEach(async () => {
      message = new DIDDeactivateMessage({
        did: VALID_DID,
      });

      publishMock = vi.fn();

      const publisher: Publisher = {
        network: vi.fn(),
        publicKey: vi.fn(),
        publish: publishMock,
      };

      const runner = new LifecycleRunner(
        DIDDeactivateMessageHederaCSMLifeCycle,
      );
      const pauseStep = await runner.process(message, {
        publisher: {
          network: vi.fn(),
          publicKey: vi.fn(),
          publish: publishMock,
        },
      });

      expect(pauseStep.status).toBe('pause');

      verifier.verifyMock.mockReturnValue(true);

      result = await runner.resume(pauseStep, {
        publisher,
        args: {
          signature: SIGNATURE,
          verifier,
        },
      });
    });

    describe('when resuming the lifecycle', () => {
      beforeEach(async () => {
        const runner = new LifecycleRunner(
          DIDDeactivateMessageHederaCSMLifeCycle,
        );
        result = await runner.resume(result, {
          publisher: {
            network: vi.fn(),
            publicKey: vi.fn(),
            publish: publishMock,
          },
        });
      });

      it('should publish the message to the topic', () => {
        expect(publishMock).toHaveBeenCalledWith(
          expect.any(TopicMessageSubmitTransaction),
        );
      });
    });

    it('should set the given signature', () => {
      expect(result.message.signature).toBe(SIGNATURE);
    });

  });
});
