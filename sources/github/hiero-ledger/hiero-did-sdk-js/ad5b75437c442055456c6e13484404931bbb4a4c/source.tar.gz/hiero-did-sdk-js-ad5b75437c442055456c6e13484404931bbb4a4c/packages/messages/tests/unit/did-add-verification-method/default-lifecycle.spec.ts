import { LifecycleRunner, RunnerState } from '@hiero-did-sdk/lifecycle';
import { TopicMessageSubmitTransaction } from '@hiero-ledger/sdk';
import { DIDAddVerificationMethodMessage, DIDAddVerificationMethodMessageHederaDefaultLifeCycle } from '../../../src';
import { PUBLIC_KEY_MULTIBASE, SIGNATURE, TestVerifier, VALID_DID, VALID_DID_TOPIC_ID } from '../helpers';
import { Signer } from '@hiero-did-sdk/core';

const mockSigner = new (class extends Signer {
  publicKey = vi.fn();
  sign = vi.fn().mockReturnValue(SIGNATURE);
  verify = vi.fn().mockReturnValue(true);
})();

const mockPublisher = {
  network: vi.fn(),
  publicKey: vi.fn(),
  publish: vi.fn().mockResolvedValue({
    topicId: VALID_DID_TOPIC_ID,
  }),
};

describe('Default DIDAddVerificationMethodMessage Lifecycle', () => {
  describe('when processing a valid DIDAddVerificationMethodMessage', () => {
    let message: DIDAddVerificationMethodMessage;
    let result: RunnerState<DIDAddVerificationMethodMessage>;

    beforeEach(async () => {
      const verifier = new TestVerifier();
      message = new DIDAddVerificationMethodMessage({
        publicKeyMultibase: PUBLIC_KEY_MULTIBASE,
        controller: VALID_DID,
        property: 'verificationMethod',
        id: '#key-1',
        did: VALID_DID,
      });

      verifier.verifyMock.mockResolvedValue(true);

      const runner = new LifecycleRunner(DIDAddVerificationMethodMessageHederaDefaultLifeCycle);
      result = await runner.process(message, {
        signer: mockSigner,
        publisher: mockPublisher,
        args: {
          verifier,
        },
      });
    });

    it('should sign with given signer', () => {
      expect(mockSigner.sign).toHaveBeenCalledTimes(1);
      expect(result.message.signature).toBe(SIGNATURE);
    });

    it('should have a paused state', () => {
      expect(result.status).toBe('pause');
    });

    describe('when resuming the lifecycle', () => {
      beforeEach(async () => {
        const runner = new LifecycleRunner(DIDAddVerificationMethodMessageHederaDefaultLifeCycle);
        result = await runner.resume(result, {
          signer: mockSigner,
          publisher: mockPublisher,
        });
      });

      it('should publish the message to the topic', () => {
        expect(mockPublisher.publish).toHaveBeenCalledWith(expect.any(TopicMessageSubmitTransaction));
      });
    });
  });
});
