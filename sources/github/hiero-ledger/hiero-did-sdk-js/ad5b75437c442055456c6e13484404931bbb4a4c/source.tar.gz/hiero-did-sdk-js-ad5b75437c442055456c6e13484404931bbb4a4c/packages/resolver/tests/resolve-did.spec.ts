import { CborCodec, DIDError } from '@hiero-did-sdk/core';
import { resolveDID } from '../src';
import { getAddVerificationMethodMessage, getDIDOwnerMessage } from './helpers';

const { fetchAllToDateMock, topicReaderConstructorMock } = vi.hoisted(() => ({
  fetchAllToDateMock: vi.fn(),
  topicReaderConstructorMock: vi.fn(),
}));

vi.mock('../src/topic-readers/topic-reader-hedera-client.ts', () => {
  return {
    TopicReaderHederaClient: vi.fn().mockImplementation(function() {
      topicReaderConstructorMock();
      return {
        fetchAllToDate: fetchAllToDateMock,
      };
    }),
  };
});

describe('DID Resolver', () => {
  let messages: string[] = [];
  let did: string;
  let didOwnerPublicKey: string;
  let vmPublicKey: string;

  beforeEach(async () => {
    const didOwnerMessage = await getDIDOwnerMessage();
    const verificationMethod = await getAddVerificationMethodMessage({
      privateKey: didOwnerMessage.privateKey,
      property: 'verificationMethod',
      did: didOwnerMessage.did,
      keyId: 'key-1',
    });

    did = didOwnerMessage.did;

    didOwnerPublicKey = didOwnerMessage.publicKeyMultibase;
    vmPublicKey = verificationMethod.publicKeyMultibase;

    messages = [didOwnerMessage.message, verificationMethod.message];
  });

  it('should resolve a did document to json-ld format', async () => {
    fetchAllToDateMock.mockResolvedValue(messages);

    const didDocument = await resolveDID(did);

    const controllerVerificationMethodId = `${did}#did-root-key`;

    expect(didDocument).toBeDefined();
    expect(didDocument).toStrictEqual({
      '@context': expect.arrayContaining([expect.any(String)]),
      id: did,
      controller: did,
      verificationMethod: [
        {
          id: controllerVerificationMethodId,
          type: 'Ed25519VerificationKey2020',
          controller: did,
          publicKeyMultibase: didOwnerPublicKey,
        },
        {
          id: `${did}#key-1`,
          type: 'Ed25519VerificationKey2020',
          controller: did,
          publicKeyMultibase: vmPublicKey,
        },
      ],
      authentication: [controllerVerificationMethodId],
      assertionMethod: [controllerVerificationMethodId],
    });
  });

  it('should resolve a did document to json format', async () => {
    fetchAllToDateMock.mockResolvedValue(messages);

    const didDocument = await resolveDID(did, 'application/did+json');

    const controllerVerificationMethodId = `${did}#did-root-key`;

    expect(didDocument).toBeDefined();
    expect(didDocument).toStrictEqual({
      id: did,
      controller: did,
      verificationMethod: [
        {
          id: controllerVerificationMethodId,
          type: 'Ed25519VerificationKey2020',
          controller: did,
          publicKeyMultibase: didOwnerPublicKey,
        },
        {
          id: `${did}#key-1`,
          type: 'Ed25519VerificationKey2020',
          controller: did,
          publicKeyMultibase: vmPublicKey,
        },
      ],
      authentication: [controllerVerificationMethodId],
      assertionMethod: [controllerVerificationMethodId],
    });
  });

  it('should resolve a did document to full resolution format', async () => {
    fetchAllToDateMock.mockResolvedValue(messages);

    const didDocument = await resolveDID(did, 'application/ld+json;profile="https://w3id.org/did-resolution"');

    const controllerVerificationMethodId = `${did}#did-root-key`;

    expect(didDocument).toBeDefined();
    expect(didDocument).toStrictEqual({
      didDocumentMetadata: {
        created: expect.any(String),
        updated: expect.any(String),
        deactivated: false,
      },
      didResolutionMetadata: {
        contentType: 'application/ld+json;profile="https://w3id.org/did-resolution"',
      },
      didDocument: {
        '@context': expect.arrayContaining([expect.any(String)]),
        id: did,
        controller: did,
        verificationMethod: [
          {
            id: controllerVerificationMethodId,
            type: 'Ed25519VerificationKey2020',
            controller: did,
            publicKeyMultibase: didOwnerPublicKey,
          },
          {
            id: `${did}#key-1`,
            type: 'Ed25519VerificationKey2020',
            controller: did,
            publicKeyMultibase: vmPublicKey,
          },
        ],
        authentication: [controllerVerificationMethodId],
        assertionMethod: [controllerVerificationMethodId],
      },
    });
  });

  it('should resolve a did document to CBOR format', async () => {
    fetchAllToDateMock.mockResolvedValue(messages);

    const didDocument = await resolveDID(did, 'application/did+cbor');

    const controllerVerificationMethodId = `${did}#did-root-key`;

    expect(didDocument).toBeDefined();
    expect(didDocument).toStrictEqual(
      CborCodec.encode({
        id: did,
        controller: did,
        verificationMethod: [
          {
            id: controllerVerificationMethodId,
            controller: did,
            type: 'Ed25519VerificationKey2020',
            publicKeyMultibase: didOwnerPublicKey,
          },
          {
            id: `${did}#key-1`,
            type: 'Ed25519VerificationKey2020',
            controller: did,
            publicKeyMultibase: vmPublicKey,
          },
        ],
        authentication: [controllerVerificationMethodId],
        assertionMethod: [controllerVerificationMethodId],
      })
    );
  });

  it('should throw an error for invalid accept option', async () => {
    fetchAllToDateMock.mockResolvedValue(messages);

    await expect(resolveDID(did, 'invalid' as never)).rejects.toThrow('Unsupported representation format');
  });

  it('should throw an error for invalid did', async () => {
    fetchAllToDateMock.mockResolvedValue(messages);

    await expect(resolveDID('did:hedera:testnet:zguayisd')).rejects.toThrow('Unsupported DID method or invalid DID');
  });

  it('should throw an error when did not found', async () => {
    fetchAllToDateMock.mockResolvedValue([]);

    await expect(resolveDID(did)).rejects.toThrow(new DIDError('notFound', 'The DID document was not found'));
  });

});
