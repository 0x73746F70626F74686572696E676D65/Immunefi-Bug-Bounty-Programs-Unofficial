# @hiero-did-sdk/zstd

## 0.2.1

### Patch Changes

- 6c6bce5: Fix multi-page Mirror Node REST API queries

## 0.2.0

### Minor Changes

- 5366367: Migrate to new Hiero SDK JS package namespace + security fixes

## 0.1.8

### Patch Changes

- 0008e01: Use Hiero Solo for integration tests + security updates

## 0.1.7

### Patch Changes

- 1544666: Allow multibase key prefix in DID identifier

## 0.1.6

### Patch Changes

- 9554e93: ESM compatibility fixes

## 0.1.5

### Patch Changes

- Use CJS for React Native + split optional dependencies loading

## 0.1.4

### Patch Changes

- Use Signer in HCS and AnonCreds packages API

## 0.1.3

### Patch Changes

- bb5b2bf: Fixed an issue where multiple actions to update and deactivate a document's DID could not be performed when using a Client instance

## 0.1.2

## 0.1.1

### Patch Changes

- 8f91471: Fixed issue with publishing files in HCS-1 standard
