import { HcsFileService, ChunkMessage } from '../../src';
import { Client, PrivateKey, PublicKey } from '@hiero-ledger/sdk';
import { Crypto } from '@hiero-did-sdk/crypto';
import { Zstd } from '@hiero-did-sdk/zstd';
import { Buffer } from 'buffer';
import { Signer } from '@hiero-did-sdk/signer-internal';

const testPayload = Buffer.from('test payload');

const {
  mockTopicId,
  mockHash,
  mockHcsTopicMemo,
  mockSubmitMessage,
  mockGetTopicMessages,
  mockCreateTopic,
  mockGetTopicInfo,
  mockSetTopicFile,
  mockGetTopicFile,
  mockCryptoSha256,
  mockZstdCompress,
  mockZstdDecompress,
} = vi.hoisted(() => {
  const mockTopicId = 'mockTopicId';
  const mockHash = '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08';
  const mockHcsTopicMemo = `${mockHash}:zstd:base64`;

  return {
    mockTopicId,
    mockHash,
    mockHcsTopicMemo,
    mockSubmitMessage: vi.fn().mockResolvedValue(undefined),
    mockGetTopicMessages: vi.fn().mockResolvedValue([]),
    mockCreateTopic: vi.fn().mockResolvedValue(mockTopicId),
    mockGetTopicInfo: vi.fn().mockResolvedValue({
      topicId: mockTopicId,
      topicMemo: mockHcsTopicMemo,
    }),
    mockSetTopicFile: vi.fn(),
    mockGetTopicFile: vi.fn().mockResolvedValue(undefined),
    mockCryptoSha256: vi.fn().mockReturnValue(mockHash),
    mockZstdCompress: vi.fn((data: Buffer) => Buffer.from(`compressed-${data.toString()}`)),
    mockZstdDecompress: vi.fn((data: Buffer) => Buffer.from(data.toString().replace('compressed-', ''))),
  };
});

// Mock dependencies
vi.mock('@hiero-did-sdk/crypto', () => ({
  Crypto: {
    sha256: mockCryptoSha256,
  },
}));

vi.mock('@hiero-did-sdk/zstd', () => ({
  Zstd: {
    compress: mockZstdCompress,
    decompress: mockZstdDecompress,
  },
}));

vi.mock('../../src/hcs/hcs-message-service', () => ({
  HcsMessageService: vi.fn(function () {
    return {
      submitMessage: mockSubmitMessage,
      getTopicMessages: mockGetTopicMessages,
    };
  }),
}));

vi.mock('../../src/hcs/hcs-topic-service', () => ({
  HcsTopicService: vi.fn(function () {
    return {
      createTopic: mockCreateTopic,
      getTopicInfo: mockGetTopicInfo,
    };
  }),
}));

vi.mock('../../src/cache/hcs-cache-service', () => ({
  HcsCacheService: vi.fn(function () {
    return {
      getTopicFile: mockGetTopicFile,
      setTopicFile: mockSetTopicFile,
    };
  }),
}));

describe('HcsFileService', () => {
  const mockClient = {} as Client;

  let service: HcsFileService;

  beforeEach(() => {
    service = new HcsFileService(mockClient, { maxSize: 10 });
  });

  describe('constructor', () => {
    it('should initialize without cache', () => {
      const serviceWithoutCache = new HcsFileService(mockClient);
      expect(serviceWithoutCache).toBeDefined();
    });

    it('should initialize with cache', () => {
      const serviceWithCache = new HcsFileService(mockClient, { maxSize: 10 });
      expect(serviceWithCache).toBeDefined();
    });
  });

  describe('submitFile', () => {
    it('should submit a file successfully', async () => {
      const submitKey = PrivateKey.generateED25519();
      const result = await service.submitFile({ payload: testPayload, submitKeySigner: new Signer(submitKey) });

      expect(Crypto.sha256).toHaveBeenCalledWith(testPayload);
      expect(Zstd.compress).toHaveBeenCalledWith(testPayload);

      expect(mockCreateTopic).toHaveBeenCalledWith({
        topicMemo: mockHcsTopicMemo,
        // Workaround for Hiero SDK internal format inconsistency between PrivateKey.publicKey and "independent" PublicKey instance
        submitKey: PublicKey.fromString(submitKey.publicKey.toStringDer()),
      });

      expect(mockSubmitMessage).toHaveBeenCalled();
      expect(result).toBe(mockTopicId);
    });

    it('should wait for changes visibility', async () => {
      // Mock message service to return chunks
      mockGetTopicMessages.mockResolvedValueOnce([
        {
          contents: Buffer.from(
            JSON.stringify({ o: 0, c: 'data:application/json;base64,Y29tcHJlc3NlZC10ZXN0IHBheWxvYWQ=' })
          ),
        },
      ]);

      await service.submitFile({
        payload: testPayload,
        submitKeySigner: new Signer(PrivateKey.generate()),
        waitForChangesVisibility: true,
      });

      expect(mockGetTopicMessages).toHaveBeenCalledWith({ topicId: mockTopicId });
    });

    it('should wait for changes visibility and fail if timeout is exceeded', async () => {
      await expect(
        service.submitFile({
          payload: testPayload,
          submitKeySigner: new Signer(PrivateKey.generate()),
          waitForChangesVisibility: true,
          waitForChangesVisibilityTimeoutMs: 1000,
        })
      ).rejects.toThrow('Timeout of 1000ms exceeded while waiting for changes visibility');
    });
  });

  describe('resolveFile', () => {
    it('should return cached file if available', async () => {
      const cachedFile = Buffer.from('cached file');

      mockGetTopicFile.mockResolvedValueOnce(cachedFile);

      const result = await service.resolveFile({ topicId: mockTopicId });

      expect(mockGetTopicFile).toHaveBeenCalledWith(mockClient, mockTopicId);
      expect(result).toBe(cachedFile);
    });

    it('should resolve file from HCS when not cached', async () => {
      mockGetTopicFile.mockResolvedValueOnce(null);

      // Mock message service to return chunks
      mockGetTopicMessages.mockResolvedValueOnce([
        {
          contents: Buffer.from(
            JSON.stringify({ o: 0, c: 'data:application/json;base64,Y29tcHJlc3NlZC10ZXN0IHBheWxvYWQ=' })
          ),
        },
      ]);

      // Mock Crypto.sha256 for validation
      (Crypto.sha256 as vi.Mock).mockReturnValueOnce(mockHash);

      const result = await service.resolveFile({ topicId: mockTopicId });

      expect(mockSetTopicFile).toHaveBeenCalledWith(mockClient, mockTopicId, testPayload);

      expect(mockGetTopicInfo).toHaveBeenCalledWith({ topicId: mockTopicId });
      expect(mockGetTopicMessages).toHaveBeenCalledWith({ topicId: mockTopicId });

      expect(mockSetTopicFile).toHaveBeenCalledWith(mockClient, mockTopicId, result);

      // The result should be the decompressed payload
      expect(result.toString()).toBe('test payload');
    });

    it('should throw error if topic memo is invalid', async () => {
      mockGetTopicFile.mockResolvedValueOnce(null);

      mockGetTopicInfo.mockResolvedValueOnce({
        topicId: mockTopicId,
        topicMemo: 'invalidMemo',
      });

      await expect(service.resolveFile({ topicId: mockTopicId })).rejects.toThrow(
        `HCS file Topic ${mockTopicId} is invalid - must contain memo compliant with HCS-1 standard`
      );
    });

    it('should throw error if topic has adminKey', async () => {
      mockGetTopicFile.mockResolvedValueOnce(null);

      mockGetTopicInfo.mockResolvedValueOnce({
        topicId: mockTopicId,
        topicMemo: mockHcsTopicMemo,
        adminKey: 'someKey',
      });

      await expect(service.resolveFile({ topicId: mockTopicId })).rejects.toThrow(
        `HCS file topic ${mockTopicId} contains adminKey`
      );
    });

    it('should throw error if resolved payload checksum is invalid', async () => {
      mockGetTopicFile.mockResolvedValueOnce(null);

      mockGetTopicMessages.mockResolvedValueOnce([
        {
          contents: Buffer.from(
            JSON.stringify({ o: 0, c: 'data:application/json;base64,Y29tcHJlc3NlZC10ZXN0IHBheWxvYWQ=' })
          ),
        },
      ]);

      // Mock Crypto.sha256 to return a different hash for validation
      (Crypto.sha256 as vi.Mock).mockReturnValueOnce('differentHash');

      await expect(service.resolveFile({ topicId: mockTopicId })).rejects.toThrow(
        'Resolved HCS file payload is invalid'
      );
    });
  });

  describe('buildFileFromChunkMessages', () => {
    it('should build file from chunk messages in correct order', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        buildFileFromChunkMessages(chunkMessages: ChunkMessage[]): Buffer;
      };
      const buildFileFromChunkMessages = (service as unknown as PrivateHcsFileService).buildFileFromChunkMessages.bind(
        service
      );

      const chunkMessages: ChunkMessage[] = [
        { o: 1, c: 'second' },
        { o: 0, c: 'data:application/json;base64,' },
        { o: 2, c: 'third' },
      ];

      // Mock Zstd.decompress for this test

      (Zstd.decompress as vi.Mock).mockReturnValueOnce('decompressed content');

      const result = buildFileFromChunkMessages(chunkMessages);

      expect(result.toString()).toBe('decompressed content');
    });

    it('should throw error if building file fails', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        buildFileFromChunkMessages(chunkMessages: ChunkMessage[]): Buffer;
      };
      const buildFileFromChunkMessages = (service as unknown as PrivateHcsFileService).buildFileFromChunkMessages.bind(
        service
      );

      // Mock Zstd.decompress to throw an error

      (Zstd.decompress as vi.Mock).mockImplementationOnce(() => {
        throw new Error('Decompression failed');
      });

      expect(() => buildFileFromChunkMessages([{ o: 0, c: 'data:application/json;base64,invalid' }])).toThrow(
        'Error on building HCS-1 file payload from chunk messages: Decompression failed'
      );
    });
  });

  describe('buildChunkMessagesFromFile', () => {
    it('should split large payload into chunks', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        buildChunkMessagesFromFile(payload: Buffer): Array<{ orderIndex: number; content: string }>;
      };
      const buildChunkMessagesFromFile = (service as unknown as PrivateHcsFileService).buildChunkMessagesFromFile.bind(
        service
      );

      // Create a large payload that will be split into multiple chunks
      const largePayload = Buffer.from('a'.repeat(2000));
      const result = buildChunkMessagesFromFile(largePayload);
      expect(result.length).toBeGreaterThan(1);
      expect(result[0].orderIndex).toBe(0);
      expect(result[1].orderIndex).toBe(1);
    });

    it('should throw error if building chunks fails', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        buildChunkMessagesFromFile(payload: Buffer): Array<{ orderIndex: number; content: string }>;
      };
      const buildChunkMessagesFromFile = (service as unknown as PrivateHcsFileService).buildChunkMessagesFromFile.bind(
        service
      );

      // Mock Zstd.compress to throw an error

      (Zstd.compress as vi.Mock).mockImplementationOnce(() => {
        throw new Error('Compression failed');
      });
      expect(() => buildChunkMessagesFromFile(testPayload)).toThrow(
        'Error on getting chunk messages for HCS-1 file: Error: Compression failed'
      );
    });
  });

  describe('createHCS1Memo', () => {
    it('should create a valid HCS-1 memo', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        createHCS1Memo(hash: string): string;
      };
      const createHCS1Memo = (service as unknown as PrivateHcsFileService).createHCS1Memo.bind(service);
      const result = createHCS1Memo('testHash');
      expect(result).toBe('testHash:zstd:base64');
    });
  });

  describe('isValidHCS1Memo', () => {
    it('should validate a correct HCS-1 memo', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        isValidHCS1Memo(memo: string): boolean;
      };
      const isValidHCS1Memo = (service as unknown as PrivateHcsFileService).isValidHCS1Memo.bind(service);

      const validMemo = '1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef:zstd:base64';
      expect(isValidHCS1Memo(validMemo)).toBe(true);
    });

    it('should reject an invalid HCS-1 memo', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        isValidHCS1Memo(memo: string): boolean;
      };
      const isValidHCS1Memo = (service as unknown as PrivateHcsFileService).isValidHCS1Memo.bind(service);

      const invalidMemos = [
        '',
        'invalid',
        '123:zstd:base64', // Too short hash
        'abcdefg:wrong:base64',
        'abcdefg:zstd:wrong',
      ];

      invalidMemos.forEach((memo) => {
        expect(isValidHCS1Memo(memo)).toBe(false);
      });
    });
  });

  describe('isValidHCS1Checksum', () => {
    it('should validate matching checksums', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        isValidHCS1Checksum(memo: string, checksum: string): boolean;
      };
      const isValidHCS1Checksum = (service as unknown as PrivateHcsFileService).isValidHCS1Checksum.bind(service);

      const memo = 'checksum123:zstd:base64';
      const checksum = 'checksum123';
      expect(isValidHCS1Checksum(memo, checksum)).toBe(true);
    });

    it('should reject non-matching checksums', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        isValidHCS1Checksum(memo: string, checksum: string): boolean;
      };
      const isValidHCS1Checksum = (service as unknown as PrivateHcsFileService).isValidHCS1Checksum.bind(service);

      const memo = 'checksum123:zstd:base64';
      const checksum = 'differentChecksum';
      expect(isValidHCS1Checksum(memo, checksum)).toBe(false);
    });

    it('should throw error if memo is empty', () => {
      // Create a private method accessor using type assertion
      type PrivateHcsFileService = {
        isValidHCS1Checksum(memo: string, checksum: string): boolean;
      };
      const isValidHCS1Checksum = (service as unknown as PrivateHcsFileService).isValidHCS1Checksum.bind(service);
      expect(() => isValidHCS1Checksum('', 'checksum')).toThrow('Memo is required');
    });
  });
});
