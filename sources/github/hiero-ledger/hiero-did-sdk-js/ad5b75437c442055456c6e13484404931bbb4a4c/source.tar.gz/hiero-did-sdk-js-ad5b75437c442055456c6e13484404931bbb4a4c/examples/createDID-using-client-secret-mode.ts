/* 
  This example demonstrates how to create a DID in Client Managed Secret Mode.
  This mode is useful when you want to manage the secret key yourself.
*/
import { Client, PrivateKey } from '@hiero-ledger/sdk';
import { generateCreateDIDRequest, submitCreateDIDRequest } from '@hiero-did-sdk/registrar';
import { KeysUtility } from '@hiero-did-sdk/core';

const accountId = process.env.HEDERA_TESTNET_OPERATOR_ID;
const operatorPrivateKey = process.env.HEDERA_TESTNET_OPERATOR_KEY;

const client = Client.forTestnet();
client.setOperator(accountId, operatorPrivateKey);

async function main() {
  try {
    const rootKey = PrivateKey.fromStringED25519(operatorPrivateKey);
    const publicMultibaseRootKey = KeysUtility.fromPublicKey(rootKey.publicKey).toMultibase();

    const { state, signingRequest } = await generateCreateDIDRequest(
      {
        multibasePublicKey: publicMultibaseRootKey,
      },
      {
        client,
      }
    );

    const signature = rootKey.sign(signingRequest.serializedPayload);

    const { did, didDocument } = await submitCreateDIDRequest(
      { state, signature },
      {
        client,
      }
    );

    console.log(`DID: ${did}`);
    console.log(`DID Document: ${JSON.stringify(didDocument, null, 2)}`);
  } catch (error) {
    console.error('Error creating DID:', error);
  }
}

main().finally(() => client.close());
