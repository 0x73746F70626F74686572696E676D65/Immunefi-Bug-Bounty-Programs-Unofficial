/*
 * This example demonstrates how to delete an HCS topic using the `deleteTopic` method.
 * It shows signing the delete transaction with the current admin key and optionally
 * waiting for deletion confirmation on the mirror node.
 */
import { HcsTopicService } from '@hiero-did-sdk/hcs';
import { PrivateKey } from '@hiero-ledger/sdk';
import { HederaClientConfiguration, HederaClientService } from '@hiero-did-sdk/client';
import { Signer } from '@hiero-did-sdk/signer-internal';

const operatorId = process.env.HEDERA_TESTNET_OPERATOR_ID;
const operatorKey = process.env.HEDERA_TESTNET_OPERATOR_KEY;

const config: HederaClientConfiguration = {
  networks: [
    {
      network: 'testnet',
      operatorId,
      operatorKey,
    },
  ],
};

async function main() {
  const clientService = new HederaClientService(config);
  const client = clientService.getClient('testnet');

  const topicService = new HcsTopicService(client, { maxSize: 100 });

  const adminKey = PrivateKey.fromStringDer(operatorKey);
  const adminKeySigner = new Signer(adminKey);

  try {
    // Create topic
    console.log(`Topic creating...`);
    const topicId = await topicService.createTopic({
      topicMemo: 'Example Topic Memo',
      adminKeySigner,
    });
    console.log(`Topic created (topicId = ${topicId})`);

    // Update topic
    console.log(`Topic deleting...`);
    await topicService.deleteTopic({
      topicId,
      adminKeySigner,
      waitForChangesVisibility: true,
    });
    console.log('Topic deleted successfully');
  } catch (error) {
    console.error('Error deleting topic:', error);
  }
}

main().catch(console.error);
