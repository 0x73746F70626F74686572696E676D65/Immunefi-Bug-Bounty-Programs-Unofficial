// SPDX-License-Identifier: Apache-2.0
#include "Client.h"
#include "AccountId.h"
#include "AccountInfoQuery.h"
#include "AddressBookQuery.h"
#include "Defaults.h"
#include "FileId.h"
#include "Hbar.h"
#include "Logger.h"
#include "NodeAddressBook.h"
#include "PrivateKey.h"
#include "PublicKey.h"
#include "SubscriptionHandle.h"
#include "exceptions/UninitializedException.h"
#include "impl/BaseNodeAddress.h"
#include "impl/MirrorNetwork.h"
#include "impl/Network.h"
#include "impl/TLSBehavior.h"

#include <condition_variable>
#include <fstream>
#include <stdexcept>
#include <thread>

namespace Hiero
{
//-----
struct Client::ClientImpl
{
  // Pointer to the network object that contains all processing for
  // sending/receiving information to/from a Hiero network.
  std::shared_ptr<internal::Network> mNetwork = nullptr;

  // Pointer to the MirrorNetwork object that contains the mirror nodes for
  // sending/receiving information to/from a Hiero mirror node.
  std::shared_ptr<internal::MirrorNetwork> mMirrorNetwork = nullptr;

  // The Logger used by this Client.
  Logger mLogger = Logger(Logger::LoggingLevel::SILENT);

  // Subscriptions this Client is tracking.
  std::vector<std::shared_ptr<SubscriptionHandle>> mSubscriptions;

  // The ID of the account that will pay for requests using this Client.
  std::optional<AccountId> mOperatorAccountId;

  // Pointer to the private key this Client should use to sign transactions.
  std::shared_ptr<PrivateKey> mOperatorPrivateKey = nullptr;

  // Pointer to the public key associated with the private key that this Client
  // should use to sign transactions.
  std::shared_ptr<PublicKey> mOperatorPublicKey = nullptr;

  // The signing function this Client should use to sign transactions.
  std::optional<std::function<std::vector<std::byte>(const std::vector<std::byte>&)>> mOperatorSigner;

  // The maximum fee this Client is willing to pay for transactions.
  std::optional<Hbar> mMaxTransactionFee;

  // The maximum payment this Client is willing to make for queries.
  std::optional<Hbar> mMaxQueryPayment;

  // The transaction ID regeneration policy to utilize when transactions
  // submitted by this Client receive a TRANSACTION_EXPIRED response from the
  // network.
  std::optional<bool> mTransactionIdRegenerationPolicy;

  // The maximum length of time this Client should wait to get a response after
  // sending a request to the network.
  std::chrono::system_clock::duration mRequestTimeout = DEFAULT_REQUEST_TIMEOUT;

  // The maximum number of attempts a request sent by this Client will attempt
  // to send a request. A manually-set maximum number of attempts in the request
  // will override this.
  std::optional<unsigned int> mMaxAttempts;

  // The minimum length of time a request sent to a Node by this Client will
  // wait before attempting to send a request again after a failure to the same
  // Node. A manually-set minimum backoff in the request will override this.
  std::optional<std::chrono::system_clock::duration> mMinBackoff;

  // The maximum length of time a request sent to a Node by this Client will
  // wait before attempting to send a request again after a failure to the same
  // Node. A manually-set maximum backoff in the request will override this.
  std::optional<std::chrono::system_clock::duration> mMaxBackoff;

  // The maximum amount of time this Client should spend trying to execute a
  // request before giving up on that request attempt. A manually-set gRPC
  // deadline in the request will override this.
  std::optional<std::chrono::system_clock::duration> mGrpcDeadline;

  // The period of time to wait between network updates.
  std::chrono::system_clock::duration mNetworkUpdatePeriod = DEFAULT_NETWORK_UPDATE_PERIOD;

  // Should this Client automatically validate entity checksums?
  bool mAutoValidateChecksums = false;

  // Should this Client allow receipt/record queries to fail over to other nodes when the submitting
  // node is unavailable? When true, queries start with the submitting node and advance to others on
  // failure. Defaults to false (strict single-node pinning).
  bool mAllowReceiptNodeFailover = false;

  // Has this Client made its initial network update? This is utilized in case
  // the user updates the network update period before the initial update is
  // made, as it prevents the update period from being overwritten.
  bool mMadeInitialNetworkUpdate = false;

  // Is this Client trying to cancel its network update? Used to signal to the
  // network update thread that it should shut down.
  bool mCancelUpdate = false;

  // The time at which this Client started waiting to update. This is needed in
  // case Clients get moved.
  std::chrono::system_clock::time_point mStartNetworkUpdateWaitTime;

  // The mutex for updating this Client.
  std::mutex mMutex;

  // The condition variable for the network update.
  std::condition_variable mConditionVariable;

  // The thread that handles the network updates.
  std::unique_ptr<std::thread> mNetworkUpdateThread = nullptr;
};

//-----
Client::Client()
  : mImpl(std::make_unique<ClientImpl>())
{
  // Start the network update thread.
  startNetworkUpdateThread(DEFAULT_NETWORK_UPDATE_INITIAL_DELAY);
}

//-----
Client::~Client()
{
  close();
}

//-----
Client::Client(Client&& other) noexcept
  : mImpl(std::make_unique<ClientImpl>())
{
  moveClient(std::move(other));

  // Leave moved-from object in a valid state
  other.mImpl = std::make_unique<ClientImpl>(); // NOLINT
}

//-----
Client& Client::operator=(Client&& other) noexcept
{
  if (this != &other)
  {
    moveClient(std::move(other));

    // Leave moved-from object in a valid state
    other.mImpl = std::make_unique<ClientImpl>(); // NOLINT
  }

  return *this;
}

//-----
Client Client::forNetwork(const std::unordered_map<std::string, AccountId>& networkMap)
{
  Client client;
  client.mImpl->mNetwork = std::make_shared<internal::Network>(internal::Network::forNetwork(networkMap));
  return client;
}

//-----
Client Client::forMirrorNetwork(const std::vector<std::string>& mirrorNetwork, int64_t realm, int64_t shard)
{
  Client client;
  client.setMirrorNetwork(mirrorNetwork);
  client.mImpl->mNetwork =
    std::make_shared<internal::Network>(internal::Network::forNetwork(internal::Network::getNetworkFromAddressBook(
      AddressBookQuery().setFileId(FileId::getAddressBookFileIdFor(realm, shard)).execute(client),
      internal::BaseNodeAddress::PORT_NODE_PLAIN)));

  return client;
}

//-----
Client Client::forName(std::string_view name)
{
  // clang-format off
  if      (name == "mainnet")    return Client::forMainnet();
  else if (name == "testnet")    return Client::forTestnet();
  else if (name == "previewnet") return Client::forPreviewnet();
  else throw std::invalid_argument("Unknown Client name");
  // clang-format on
}

//-----
Client Client::forMainnet()
{
  Client client;
  client.mImpl->mNetwork = std::make_shared<internal::Network>(internal::Network::forMainnet());
  client.mImpl->mMirrorNetwork = std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forMainnet());
  return client;
}

//-----
Client Client::forTestnet()
{
  Client client;
  client.mImpl->mNetwork = std::make_shared<internal::Network>(internal::Network::forTestnet());
  client.mImpl->mMirrorNetwork = std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forTestnet());
  return client;
}

//-----
Client Client::forPreviewnet()
{
  Client client;
  client.mImpl->mNetwork = std::make_shared<internal::Network>(internal::Network::forPreviewnet());
  client.mImpl->mMirrorNetwork = std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forPreviewnet());
  return client;
}

//-----
Client Client::fromConfig(std::string_view json)
{
  // Make sure the input string is valid JSON.
  nlohmann::json jsonObj;
  try
  {
    jsonObj = nlohmann::json::parse(json);
  }
  catch (const std::exception& ex)
  {
    throw std::invalid_argument(std::string("Cannot parse JSON: ") + ex.what());
  }

  return fromConfig(jsonObj);
}

//-----
Client Client::fromConfig(const nlohmann::json& json)
{
  Client client;

  // A "network" tag should always be specified.
  if (!json.contains("network"))
  {
    throw std::invalid_argument("Network tag is not set in JSON");
  }

  // If the network tags specifies a dictionary of nodes, parse each one.
  if (const nlohmann::json& jsonNetwork = json["network"]; jsonNetwork.is_object())
  {
    std::unordered_map<std::string, AccountId> networkMap;
    for (const auto& [accountId, url] : jsonNetwork.items())
    {
      networkMap.try_emplace(url, AccountId::fromString(accountId));
    }

    client = Client::forNetwork(networkMap);

    // If a network name is provided, set the ledger ID based on it.
    if (json.contains("networkName"))
    {
      try
      {
        client.setLedgerId(LedgerId::fromString(jsonNetwork["networkName"].get<std::string_view>()));
      }
      catch (const std::exception&)
      {
        throw std::invalid_argument(
          R"(Invalid argument for network name. Should be one of "mainnet", "testnet", or "previewnet")");
      }
    }
  }

  // If the network tag specifies a name, get the Client for that name.
  else if (jsonNetwork.is_string())
  {
    try
    {
      client = Client::forName(jsonNetwork.get<std::string_view>());
    }
    catch (const std::exception&)
    {
      throw std::invalid_argument("Invalid argument for network tag");
    }
  }

  // If the network tag type is unclear, throw.
  else
  {
    throw std::invalid_argument("Invalid argument for network tag");
  }

  // Check if there's an operator configured.
  if (json.contains("operator"))
  {
    const nlohmann::json& jsonOperator = json["operator"];

    if (!jsonOperator.is_object())
    {
      throw std::invalid_argument("Invalid argument for operator");
    }

    // If an operator is configured, an AccountId and PrivateKey must also be
    // configured.
    if (!jsonOperator.contains("accountId") || !jsonOperator.contains("privateKey"))
    {
      throw std::invalid_argument("An operator must have an accountId and privateKey");
    }

    // Verify the account ID is valid.
    AccountId operatorAccountId;
    try
    {
      operatorAccountId = AccountId::fromString(jsonOperator["accountId"].get<std::string_view>());
    }
    catch (const std::exception&)
    {
      throw std::invalid_argument("Invalid argument for operator accountId");
    }

    // Verify the private key is valid.
    std::shared_ptr<PrivateKey> operatorPrivateKey;
    try
    {
      operatorPrivateKey = PrivateKey::fromStringDer(jsonOperator["privateKey"].get<std::string_view>());
    }
    catch (const std::exception&)
    {
      throw std::invalid_argument("Invalid argument for operator privateKey");
    }

    // Set the operator.
    client.setOperator(operatorAccountId, operatorPrivateKey);
  }

  // Check if there's a mirror network configured.
  if (json.contains("mirrorNetwork"))
  {
    // If the mirror network tags specifies a list of nodes, parse each one.
    if (const nlohmann::json& jsonMirrorNetwork = json["mirrorNetwork"]; jsonMirrorNetwork.is_array())
    {
      std::vector<std::string> mirrorNetwork;
      for (const auto& url : jsonMirrorNetwork)
      {
        mirrorNetwork.push_back(url);
      }

      client.setMirrorNetwork(mirrorNetwork);
    }

    // If the mirror network tag specifies a name, get the mirror network for
    // that name.
    else if (jsonMirrorNetwork.is_string())
    {
      try
      {
        const std::string_view mirrorNetworkName = jsonMirrorNetwork.get<std::string_view>();
        if (mirrorNetworkName == "mainnet")
        {
          client.mImpl->mMirrorNetwork =
            std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forMainnet());
        }
        else if (mirrorNetworkName == "testnet")
        {
          client.mImpl->mMirrorNetwork =
            std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forTestnet());
        }
        else if (mirrorNetworkName == "previewnet")
        {
          client.mImpl->mMirrorNetwork =
            std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forPreviewnet());
        }
        else
        {
          throw std::invalid_argument("Invalid argument for mirrorNetwork tag");
        }
      }
      catch (const std::exception&)
      {
        throw std::invalid_argument("Invalid argument for mirrorNetwork tag");
      }
    }

    // If the mirrorNetwork tag type is unclear, throw.
    else
    {
      throw std::invalid_argument("Invalid argument for mirrorNetwork tag");
    }
  }

  return client;
}

//-----
Client Client::fromConfigFile(std::string_view path)
{
  std::ifstream infile(path.data());
  if (!infile.is_open())
  {
    throw std::invalid_argument(std::string("File cannot be found at ") + path.data());
  }

  // Make sure the input file is valid JSON.
  nlohmann::json jsonObj;
  try
  {
    jsonObj = nlohmann::json::parse(infile);
  }
  catch (const std::exception& ex)
  {
    throw std::invalid_argument(std::string("Cannot parse JSON: ") + ex.what());
  }

  return fromConfig(jsonObj);
}

//-----
void Client::ping(const AccountId& nodeAccountId) const
{
  return ping(nodeAccountId, mImpl->mRequestTimeout);
}

//-----
void Client::ping(const AccountId& nodeAccountId, const std::chrono::system_clock::duration& timeout) const
{
  // A Query with node account IDs pinned skips the network check in Query::onExecute(), so do it here.
  if (!mImpl->mNetwork)
  {
    throw UninitializedException("Client has not been initialized with a valid network");
  }

  // Probe the node with a COST_ANSWER getAccountInfo query for account 0.0.2. The node answers with the query fee
  // without executing the query, so nothing is charged and no operator is needed. A cost response is success; a gRPC
  // failure or a non-OK precheck throws, as the executed AccountBalanceQuery probe did before consensus node 0.77
  // removed the CryptoGetAccountBalance throttle bucket.
  AccountInfoQuery query;
  query.setAccountId(AccountId(0ULL, 0ULL, 2ULL)).setNodeAccountIds({ nodeAccountId });
  static_cast<void>(query.getCost(*this, timeout));
}

//-----
std::future<void> Client::pingAsync(const AccountId& nodeAccountId) const
{
  return pingAsync(nodeAccountId, mImpl->mRequestTimeout);
}

//-----
std::future<void> Client::pingAsync(const AccountId& nodeAccountId,
                                    const std::chrono::system_clock::duration& timeout) const
{
  return std::async(std::launch::async, [this, &nodeAccountId, &timeout]() { this->ping(nodeAccountId, timeout); });
}

//-----
void Client::pingAsync(const AccountId& nodeAccountId, const std::function<void(const std::exception&)>& callback) const
{
  return pingAsync(nodeAccountId, mImpl->mRequestTimeout, callback);
}

//-----
void Client::pingAsync(const AccountId& nodeAccountId,
                       const std::chrono::system_clock::duration& timeout,
                       const std::function<void(const std::exception&)>& callback) const
{
  std::future<void> future = pingAsync(nodeAccountId, timeout);

  try
  {
    future.get();
  }
  catch (const std::exception& exception)
  {
    callback(exception);
  }
}

//-----
void Client::pingAll() const
{
  pingAll(mImpl->mRequestTimeout);
}

//-----
void Client::pingAll(const std::chrono::system_clock::duration& timeout) const
{
  if (mImpl->mNetwork)
  {
    const std::unordered_map<std::string, AccountId> networkMap = mImpl->mNetwork->getNetwork();
    std::for_each(
      networkMap.cbegin(), networkMap.cend(), [this, &timeout](const auto& node) { this->ping(node.second, timeout); });
  }
}

//-----
std::future<void> Client::pingAllAsync() const
{
  return pingAllAsync(mImpl->mRequestTimeout);
}

//-----
std::future<void> Client::pingAllAsync(const std::chrono::system_clock::duration& timeout) const
{
  return std::async(std::launch::async,
                    [this, &timeout]()
                    {
                      const std::unordered_map<std::string, AccountId> networkMap = mImpl->mNetwork->getNetwork();
                      std::vector<std::future<void>> futures;
                      std::for_each(networkMap.cbegin(),
                                    networkMap.cend(),
                                    [this, &timeout, &futures](const auto& node)
                                    { futures.push_back(this->pingAsync(node.second, timeout)); });

                      std::for_each(
                        futures.begin(), futures.end(), [&futures](std::future<void>& future) { future.get(); });
                    });
}

//-----
void Client::pingAllAsync(const std::function<void(const std::exception&)>& callback) const
{
  return pingAllAsync(mImpl->mRequestTimeout, callback);
}

//-----
void Client::pingAllAsync(const std::chrono::system_clock::duration& timeout,
                          const std::function<void(const std::exception&)>& callback) const
{
  std::future<void> future = pingAllAsync(timeout);

  try
  {
    future.get();
  }
  catch (const std::exception& exception)
  {
    callback(exception);
  }
}

//-----
Client& Client::setOperator(const AccountId& accountId, const std::shared_ptr<PrivateKey>& privateKey)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork && mImpl->mNetwork->getLedgerId().isKnownNetwork())
  {
    accountId.validateChecksum(*this);
  }

  mImpl->mOperatorAccountId = accountId;
  mImpl->mOperatorPrivateKey = privateKey;

  return *this;
}

//-----
Client& Client::setOperatorWith(const AccountId& accountId,
                                const std::shared_ptr<PublicKey>& publicKey,
                                const std::function<std::vector<std::byte>(const std::vector<std::byte>&)>& signer)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork && mImpl->mNetwork->getLedgerId().isKnownNetwork())
  {
    accountId.validateChecksum(*this);
  }

  mImpl->mOperatorAccountId = accountId;
  mImpl->mOperatorPublicKey = publicKey;
  mImpl->mOperatorSigner = signer;

  return *this;
}

//-----
std::optional<AccountId> Client::getOperatorAccountId() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mOperatorAccountId;
}

//-----
std::shared_ptr<PublicKey> Client::getOperatorPublicKey() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mOperatorPublicKey || !mImpl->mOperatorPrivateKey ? mImpl->mOperatorPublicKey
                                                                  : mImpl->mOperatorPrivateKey->getPublicKey();
}

//-----
std::optional<std::function<std::vector<std::byte>(const std::vector<std::byte>&)>> Client::getOperatorSigner() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mOperatorSigner.has_value() || !mImpl->mOperatorPrivateKey ? mImpl->mOperatorSigner
                                                                           : [this](const std::vector<std::byte>& bytes)
  { return this->mImpl->mOperatorPrivateKey->sign(bytes); };
}

void Client::close()
{
  // Cancel the network update thread first WITHOUT holding the mutex.
  // cancelScheduledNetworkUpdate() calls join() on the background thread,
  // and that thread needs mMutex — holding the mutex here would deadlock.
  cancelScheduledNetworkUpdate();

  std::unique_lock lock(mImpl->mMutex);

  std::for_each(mImpl->mSubscriptions.begin(),
                mImpl->mSubscriptions.end(),
                [](const std::shared_ptr<SubscriptionHandle>& handle) { handle->unsubscribe(); });

  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->close();
  }

  if (mImpl->mMirrorNetwork)
  {
    mImpl->mMirrorNetwork->close();
  }
}

//-----
Client& Client::setMaxTransactionFee(const Hbar& fee)
{
  std::unique_lock lock(mImpl->mMutex);
  if (fee.toTinybars() < 0)
  {
    throw std::invalid_argument("Transaction fee cannot be negative");
  }

  mImpl->mMaxTransactionFee = fee;
  return *this;
}

//-----
std::optional<Hbar> Client::getMaxTransactionFee() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMaxTransactionFee;
}

//-----
Client& Client::setMaxQueryPayment(const Hbar& payment)
{
  std::unique_lock lock(mImpl->mMutex);
  if (payment.toTinybars() < 0)
  {
    throw std::invalid_argument("Query payment cannot be negative");
  }

  mImpl->mMaxQueryPayment = payment;
  return *this;
}

//-----
std::optional<Hbar> Client::getMaxQueryPayment() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMaxQueryPayment;
}

//-----
Client& Client::setTransactionIdRegenerationPolicy(bool regenerate)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mTransactionIdRegenerationPolicy = regenerate;
  return *this;
}

//-----
std::optional<bool> Client::getTransactionIdRegenerationPolicy() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mTransactionIdRegenerationPolicy;
}

//-----
Client& Client::setAutoValidateChecksums(bool validate)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mAutoValidateChecksums = validate;
  return *this;
}

//-----
bool Client::isAutoValidateChecksumsEnabled() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mAutoValidateChecksums;
}

//-----
Client& Client::setAllowReceiptNodeFailover(bool allow)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mAllowReceiptNodeFailover = allow;
  return *this;
}

//-----
bool Client::getAllowReceiptNodeFailover() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mAllowReceiptNodeFailover;
}

//-----
Client& Client::setNetworkFromAddressBook(const NodeAddressBook& addressBook)
{
  std::unique_lock lock(mImpl->mMutex);
  setNetworkFromAddressBookInternal(addressBook);
  return *this;
}

//-----
void Client::updateAddressBook()
{
  try
  {
    mImpl->mLogger.trace("Updating address book after INVALID_NODE_ACCOUNT response");

    // Get the address book - do NOT hold the mutex during query execution
    // as execute() will call other Client methods that also need the mutex
    const NodeAddressBook addressBook = AddressBookQuery().setFileId(FileId::ADDRESS_BOOK).execute(*this);

    // Only acquire the mutex for the actual update
    std::unique_lock lock(mImpl->mMutex);
    setNetworkFromAddressBookInternal(addressBook);

    mImpl->mLogger.trace("Address book successfully updated");
  }
  catch (const std::exception& exception)
  {
    mImpl->mLogger.warn(std::string("Failed to update address book: ") + exception.what());
    throw;
  }
}

//-----
Client& Client::setNetwork(const std::unordered_map<std::string, AccountId>& networkMap)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mNetwork = std::make_shared<internal::Network>(internal::Network::forNetwork(networkMap));
  return *this;
}

//-----
std::unordered_map<std::string, AccountId> Client::getNetwork() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getNetwork() : std::unordered_map<std::string, AccountId>();
}

//-----
Client& Client::setMirrorNetwork(const std::vector<std::string>& network)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mMirrorNetwork = std::make_shared<internal::MirrorNetwork>(internal::MirrorNetwork::forNetwork(network));
  return *this;
}

//-----
std::vector<std::string> Client::getMirrorNetwork() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMirrorNetwork ? mImpl->mMirrorNetwork->getNetwork() : std::vector<std::string>();
}

//-----
Client& Client::setLogger(const Logger& logger)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mLogger = logger;
  return *this;
}

//-----
Logger Client::getLogger() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mLogger;
}

//-----
Client& Client::setNetworkUpdatePeriod(const std::chrono::system_clock::duration& update)
{
  // Cancel any previous network updates WITHOUT holding the mutex.
  // cancelScheduledNetworkUpdate() calls join() on the background thread,
  // and that thread needs mMutex — holding the mutex here would deadlock.
  cancelScheduledNetworkUpdate();

  std::unique_lock lock(mImpl->mMutex);

  // Update the network update period.
  mImpl->mNetworkUpdatePeriod = update;

  // If this was called before the initial network update was made, the initial
  // update should be skipped.
  mImpl->mMadeInitialNetworkUpdate = true;

  // Start the thread with the new network update period.
  startNetworkUpdateThread(mImpl->mNetworkUpdatePeriod);
  return *this;
}

//-----
std::chrono::system_clock::duration Client::getNetworkUpdatePeriod() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetworkUpdatePeriod;
}

//-----
Client& Client::setLedgerId(const LedgerId& ledgerId)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setLedgerId(ledgerId);
  }

  return *this;
}

//-----
LedgerId Client::getLedgerId() const
{
  std::unique_lock lock(mImpl->mMutex);
  if (!mImpl->mNetwork)
  {
    throw UninitializedException("Client does not have a Network from which to grab the ledger ID");
  }

  return mImpl->mNetwork->getLedgerId();
}

//-----
Client& Client::setTransportSecurity(bool enable)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setTransportSecurity(enable ? internal::TLSBehavior::REQUIRE : internal::TLSBehavior::DISABLE);
  }

  return *this;
}

//-----
bool Client::isTransportSecurity() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork && mImpl->mNetwork->isTransportSecurity() == internal::TLSBehavior::REQUIRE;
}

//-----
Client& Client::setVerifyCertificates(bool verify)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setVerifyCertificates(verify);
  }

  return *this;
}

//-----
bool Client::isVerifyCertificates() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork && mImpl->mNetwork->isVerifyCertificates();
}

//-----
Client& Client::setRequestTimeout(const std::chrono::system_clock::duration& timeout)
{
  std::unique_lock lock(mImpl->mMutex);

  // Validate that requestTimeout >= grpcDeadline
  const std::chrono::system_clock::duration currentGrpcDeadline =
    mImpl->mGrpcDeadline.has_value() ? mImpl->mGrpcDeadline.value() : DEFAULT_GRPC_DEADLINE;

  if (timeout < currentGrpcDeadline)
  {
    throw std::invalid_argument(
      "Request timeout (" + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(timeout).count()) +
      " ms) must be greater than or equal to gRPC deadline (" +
      std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(currentGrpcDeadline).count()) + " ms)");
  }

  mImpl->mRequestTimeout = timeout;
  return *this;
}

//-----
std::chrono::system_clock::duration Client::getRequestTimeout() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mRequestTimeout;
}

//-----
Client& Client::setMaxAttempts(uint32_t attempts)
{
  std::unique_lock lock(mImpl->mMutex);
  mImpl->mMaxAttempts = attempts;
  return *this;
}

//-----
std::optional<uint32_t> Client::getMaxAttempts() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMaxAttempts;
}

//-----
Client& Client::setMinBackoff(const std::chrono::system_clock::duration& backoff)
{
  std::unique_lock lock(mImpl->mMutex);
  if ((mImpl->mMaxBackoff && backoff > *mImpl->mMaxBackoff) || (!mImpl->mMaxBackoff && backoff > DEFAULT_MAX_BACKOFF) ||
      (!mImpl->mMaxBackoff && backoff < std::chrono::milliseconds(0)))
  {
    throw std::invalid_argument("Minimum backoff would be larger than maximum backoff");
  }

  mImpl->mMinBackoff = backoff;
  return *this;
}

//-----
std::optional<std::chrono::system_clock::duration> Client::getMinBackoff() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMinBackoff;
}

//-----
Client& Client::setMaxBackoff(const std::chrono::system_clock::duration& backoff)
{
  std::unique_lock lock(mImpl->mMutex);
  if ((mImpl->mMinBackoff && backoff < *mImpl->mMinBackoff) || (!mImpl->mMinBackoff && backoff < DEFAULT_MIN_BACKOFF) ||
      (!mImpl->mMinBackoff && backoff > DEFAULT_MAX_BACKOFF))
  {
    throw std::invalid_argument("Maximum backoff would be smaller than minimum backoff");
  }

  mImpl->mMaxBackoff = backoff;
  return *this;
}

//-----
std::optional<std::chrono::system_clock::duration> Client::getMaxBackoff() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMaxBackoff;
}

//-----
Client& Client::setGrpcDeadline(const std::chrono::system_clock::duration& deadline)
{
  std::unique_lock lock(mImpl->mMutex);

  // Validate that grpcDeadline <= requestTimeout
  if (deadline > mImpl->mRequestTimeout)
  {
    throw std::invalid_argument(
      "gRPC deadline (" + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(deadline).count()) +
      " ms) must be less than or equal to request timeout (" +
      std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(mImpl->mRequestTimeout).count()) + " ms)");
  }

  mImpl->mGrpcDeadline = deadline;
  return *this;
}

//-----
std::optional<std::chrono::system_clock::duration> Client::getGrpcDeadline() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mGrpcDeadline;
}

//-----
Client& Client::setMaxNodeAttempts(unsigned int attempts)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setMaxNodeAttempts(attempts);
  }

  return *this;
}

//-----
unsigned int Client::getMaxNodeAttempts() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getMaxNodeAttempts() : 0U;
}

//-----
Client& Client::setNodeMinBackoff(const std::chrono::system_clock::duration& backoff)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setMinNodeBackoff(backoff);
  }

  return *this;
}

//-----
std::chrono::system_clock::duration Client::getNodeMinBackoff() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getMinNodeBackoff() : std::chrono::system_clock::duration();
}

//-----
Client& Client::setNodeMaxBackoff(const std::chrono::system_clock::duration& backoff)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setMaxNodeBackoff(backoff);
  }

  return *this;
}

//-----
std::chrono::system_clock::duration Client::getNodeMaxBackoff() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getMaxNodeBackoff() : std::chrono::system_clock::duration();
}

//-----
Client& Client::setMinNodeReadmitTime(const std::chrono::system_clock::duration& time)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setMinNodeReadmitTime(time);
  }

  return *this;
}

//-----
std::chrono::system_clock::duration Client::getMinNodeReadmitTime() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getMinNodeReadmitTime() : std::chrono::system_clock::duration();
}

//-----
Client& Client::setMaxNodeReadmitTime(const std::chrono::system_clock::duration& time)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setMaxNodeReadmitTime(time);
  }

  return *this;
}

//-----
std::chrono::system_clock::duration Client::getMaxNodeReadmitTime() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getMaxNodeReadmitTime() : std::chrono::system_clock::duration();
}

//-----
Client& Client::setMaxNodesPerTransaction(unsigned int maxNodes)
{
  std::unique_lock lock(mImpl->mMutex);
  if (mImpl->mNetwork)
  {
    mImpl->mNetwork->setMaxNodesPerRequest(maxNodes);
  }

  return *this;
}

//-----
unsigned int Client::getMaxNodesPerTransaction() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork ? mImpl->mNetwork->getMaxNodeAttempts() : 0U;
}

//-----
void Client::trackSubscription(const std::shared_ptr<SubscriptionHandle>& subscription) const
{
  mImpl->mSubscriptions.push_back(subscription);
}

//-----
void Client::untrackSubscription(const std::shared_ptr<SubscriptionHandle>& subscription) const
{
  for (auto iter = mImpl->mSubscriptions.cbegin(); iter != mImpl->mSubscriptions.cend(); ++iter)
  {
    if (subscription == *iter)
    {
      mImpl->mSubscriptions.erase(iter);
      return;
    }
  }
}

//-----
std::shared_ptr<internal::Network> Client::getClientNetwork() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mNetwork;
}

//-----
std::shared_ptr<internal::MirrorNetwork> Client::getClientMirrorNetwork() const
{
  std::unique_lock lock(mImpl->mMutex);
  return mImpl->mMirrorNetwork;
}

//-----
void Client::setNetworkFromAddressBookInternal(const NodeAddressBook& addressBook)
{
  // First try the port based on TLS setting
  unsigned int preferredPort = mImpl->mNetwork->isTransportSecurity() == internal::TLSBehavior::REQUIRE
                                 ? internal::BaseNodeAddress::PORT_NODE_TLS
                                 : internal::BaseNodeAddress::PORT_NODE_PLAIN;

  // Try to update node account IDs without closing connections
  mImpl->mNetwork->updateNodeAccountIds(addressBook, preferredPort);

  // If that didn't find any matches, try the other port
  // (This handles the case where the TLS setting doesn't match the actual ports)
  auto networkMap = internal::Network::getNetworkFromAddressBook(addressBook, preferredPort);

  if (networkMap.empty())
  {
    unsigned int alternatePort = (preferredPort == internal::BaseNodeAddress::PORT_NODE_TLS)
                                   ? internal::BaseNodeAddress::PORT_NODE_PLAIN
                                   : internal::BaseNodeAddress::PORT_NODE_TLS;

    mImpl->mNetwork->updateNodeAccountIds(addressBook, alternatePort);
  }
}

//-----
void Client::startNetworkUpdateThread(const std::chrono::system_clock::duration& period)
{
  mImpl->mStartNetworkUpdateWaitTime = std::chrono::system_clock::now();
  mImpl->mNetworkUpdatePeriod = period;
  mImpl->mNetworkUpdateThread = std::make_unique<std::thread>(&Client::scheduleNetworkUpdate, this);
}

//-----
void Client::scheduleNetworkUpdate()
{
  // Network updates should keep occurring until they're cancelled.
  while (true)
  {
    // wait_for returns true  if the predicate fired (cancelled) --> should NOT update
    // wait_for returns false if the timeout expired             --> should update
    // Negate so that shouldUpdate == true means "run the update".
    bool shouldUpdate = false;
    {
      std::unique_lock lock(mImpl->mMutex);
      shouldUpdate = !mImpl->mConditionVariable.wait_for(
        lock, mImpl->mNetworkUpdatePeriod, [this]() { return mImpl->mCancelUpdate; });
    }
    // Lock is released here.

    if (!shouldUpdate)
    {
      // The network update was cancelled, stop looping.
      break;
    }

    // Skip the update if no mirror network or consensus network is configured.
    // AddressBookQuery requires a mirror network endpoint, and
    // setNetworkFromAddressBookInternal requires a consensus network.
    // Calling execute() without a mirror network would dereference a nullptr.
    if (!getClientMirrorNetwork() || !getClientNetwork())
    {
      continue;
    }

    try
    {
      // Execute the address book query WITHOUT holding mMutex.
      // AddressBookQuery::execute() calls back into Client getters
      // (getRequestTimeout, getClientMirrorNetwork, etc.) which all
      // acquire mMutex. Holding mMutex here would cause a self-deadlock
      // on the same thread since std::mutex is non-recursive.
      const NodeAddressBook addressBook = AddressBookQuery().setFileId(FileId::ADDRESS_BOOK).execute(*this);

      // Re-acquire the lock to update internal state.
      std::unique_lock lock(mImpl->mMutex);

      // Check if we were cancelled while the query was executing.
      if (mImpl->mCancelUpdate)
      {
        break;
      }

      // Update the network from the fetched address book.
      setNetworkFromAddressBookInternal(addressBook);

      // Adjust the network update period if this is the initial update.
      if (!mImpl->mMadeInitialNetworkUpdate)
      {
        mImpl->mNetworkUpdatePeriod = DEFAULT_NETWORK_UPDATE_PERIOD;
        mImpl->mMadeInitialNetworkUpdate = true;
      }

      // Schedule the next network update.
      mImpl->mStartNetworkUpdateWaitTime = std::chrono::system_clock::now();
    }
    catch (const std::exception& exception)
    {
      std::unique_lock lock(mImpl->mMutex);
      mImpl->mLogger.warn(std::string("Failed to update address book via mirror node query ") + exception.what());
      break;
    }
  }
}

//-----
void Client::cancelScheduledNetworkUpdate()
{
  // Only cancel if there's a network update scheduled.
  if (!mImpl->mNetworkUpdateThread)
  {
    return;
  }

  // Signal the thread to stop. Must hold the mutex when modifying
  // mCancelUpdate and notifying, since the background thread checks
  // the flag under the same mutex in its condition_variable predicate.
  {
    std::unique_lock lock(mImpl->mMutex);
    mImpl->mCancelUpdate = true;
    mImpl->mConditionVariable.notify_all();
  }
  // Lock released before join() — the background thread needs mMutex
  // to complete its current wait_for or to re-acquire after query execution.

  if (mImpl->mNetworkUpdateThread->joinable())
  {
    mImpl->mNetworkUpdateThread->join();
  }

  // The thread is finished executing, so it's safe to reset the network update
  // thread.
  mImpl->mNetworkUpdateThread = nullptr;

  // The update thread is closed at this point, reset mCancelUpdate.
  mImpl->mCancelUpdate = false;
}

//-----
void Client::moveClient(Client&& other)
{
  // Cancel this Client's network update if one exists.
  // This is called without holding mMutex, which is correct since
  // cancelScheduledNetworkUpdate() calls join() on the background thread.
  cancelScheduledNetworkUpdate();

  // If there's a network update thread running in the moved-from Client, it
  // can't be simply moved. Since it still holds a reference to the moved-from
  // Client, the thread must be stopped and restarted in this Client with the
  // remaining time so that the Client reference can be updated to this Client
  // and no longer be pointing to a moved-from Client.
  if (other.mImpl->mNetworkUpdateThread)
  {
    // Cancel the update.
    other.cancelScheduledNetworkUpdate();

    // Move the implementation to this Client.
    mImpl = std::move(other.mImpl);

    // Start the network update thread with the remaining time.
    startNetworkUpdateThread(mImpl->mStartNetworkUpdateWaitTime + mImpl->mNetworkUpdatePeriod -
                             std::chrono::system_clock::now());
  }
  else
  {
    // If there was no update thread running, simply move the implementation.
    mImpl = std::move(other.mImpl);
  }
}

} // namespace Hiero
