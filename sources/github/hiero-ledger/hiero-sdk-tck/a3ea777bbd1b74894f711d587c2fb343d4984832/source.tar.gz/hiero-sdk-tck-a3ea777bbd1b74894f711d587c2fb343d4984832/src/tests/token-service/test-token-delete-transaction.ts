import { assert } from "chai";

import { JSONRPCRequest } from "@services/Client";

import { setOperator } from "@helpers/setup-tests";
import {
  verifyTokenIsDeleted,
  getNewFungibleTokenId,
  createFtToken,
} from "@helpers/token";
import { retryOnError } from "@helpers/retry-on-error";
import { generateEd25519PrivateKey } from "@helpers/key";

/**
 * Tests for TokenDeleteTransaction
 */
describe("TokenDeleteTransaction", function () {
  // Tests should not take longer than 30 seconds to fully execute.
  this.timeout(30000);

  // Each test should first establish the network to use, and then teardown the network when complete.
  before(async function () {
    await setOperator(
      this,
      process.env.OPERATOR_ACCOUNT_ID as string,
      process.env.OPERATOR_ACCOUNT_PRIVATE_KEY as string,
    );
  });
  after(async function () {
    await JSONRPCRequest(this, "reset", {
      sessionId: this.sessionId,
    });
  });

  describe("Token ID", () => {
    it("(#1) Deletes an immutable token", async function () {
      const tokenId = await createFtToken(this);

      try {
        await JSONRPCRequest(this, "deleteToken", {
          tokenId,
          commonTransactionParams: {
            signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
          },
        });
      } catch (err: any) {
        assert.equal(err.data.status, "TOKEN_IS_IMMUTABLE");
        return;
      }

      // The test failed, no error was thrown.
      assert.fail("Should throw an error");
    });

    it("(#2) Deletes a mutable token", async function () {
      const tokenId = await getNewFungibleTokenId(this);

      await JSONRPCRequest(this, "deleteToken", {
        tokenId,
        commonTransactionParams: {
          signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
        },
      });

      await retryOnError(async function () {
        verifyTokenIsDeleted(tokenId);
      });
    });

    it("(#3) Deletes a token that doesn't exist", async function () {
      try {
        await JSONRPCRequest(this, "deleteToken", {
          tokenId: "123.456.789",
          commonTransactionParams: {
            signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
          },
        });
      } catch (err: any) {
        assert.equal(err.data.status, "INVALID_TOKEN_ID");
        return;
      }

      // The test failed, no error was thrown.
      assert.fail("Should throw an error");
    });

    it("(#4) Deletes a token with no token ID", async function () {
      try {
        await JSONRPCRequest(this, "deleteToken", {
          tokenId: "",
          commonTransactionParams: {
            signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
          },
        });
      } catch (err: any) {
        assert.equal(err.message, "Internal error");
        return;
      }

      // The test failed, no error was thrown.
      assert.fail("Should throw an error");
    });

    it("(#5) Deletes a token that was already deleted", async function () {
      try {
        const tokenId = await getNewFungibleTokenId(this);

        await JSONRPCRequest(this, "deleteToken", {
          tokenId: tokenId,
          commonTransactionParams: {
            signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
          },
        });

        // Trying to delete a token once again
        await JSONRPCRequest(this, "deleteToken", {
          tokenId: tokenId,
          commonTransactionParams: {
            signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
          },
        });
      } catch (err: any) {
        assert.equal(err.data.status, "TOKEN_WAS_DELETED");
        return;
      }

      // The test failed, no error was thrown.
      assert.fail("Should throw an error");
    });

    it("(#6) Deletes a token without signing with the token's admin key", async function () {
      try {
        // Passing other admin key in order to throw an error
        const privateKey = await generateEd25519PrivateKey(this);
        const tokenId = await getNewFungibleTokenId(this, privateKey);

        await JSONRPCRequest(this, "deleteToken", {
          tokenId: tokenId,
        });
      } catch (err: any) {
        assert.equal(err.data.status, "INVALID_SIGNATURE");
        return;
      }

      // The test failed, no error was thrown.
      assert.fail("Should throw an error");
    });

    it("(#7) Deletes a token but signs with an incorrect private key", async function () {
      try {
        const privateKey = await generateEd25519PrivateKey(this);

        // Creating an account to use its accountId for creating the token
        // and after that signing it with different private key
        const createdAccount = await JSONRPCRequest(this, "createAccount", {
          key: privateKey,
        });

        const tokenId = await getNewFungibleTokenId(
          this,
          process.env.OPERATOR_ACCOUNT_PRIVATE_KEY,
          createdAccount.accountId,
        );

        // Trying to delete a token once again
        await JSONRPCRequest(this, "deleteToken", {
          tokenId: tokenId,
          commonTransactionParams: {
            signers: [process.env.OPERATOR_ACCOUNT_PRIVATE_KEY],
          },
        });
      } catch (err: any) {
        assert.equal(err.data.status, "INVALID_SIGNATURE");
        return;
      }

      // The test failed, no error was thrown.
      assert.fail("Should throw an error");
    });
  });

  return Promise.resolve();
});
