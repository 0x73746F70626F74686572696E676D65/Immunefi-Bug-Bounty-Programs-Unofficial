# TSC Eligibility Check

<!---
The following links are references to the sites where the project is being processed for statistics and/or tracked for progress.
For an example on how to add these links and format them, use: https://github.com/hyperledger/fabric/blob/main/README.md
Having this accessible can help reducing time looking for these sites.
-->
[![CII Best Practices](https://bestpractices.coreinfrastructure.org/projects/10697/badge)](https://bestpractices.coreinfrastructure.org/projects/10697)
[![License](https://img.shields.io/badge/license-apache2-blue.svg)](LICENSE)
<!---
Releases link can be oomitted for non-code repos
-->

## Useful References

 - [Helios Voting Site](https://vote.heliosvoting.org/)
 - [Eligibility Site](https://hiero-ledger.github.io/tsc-eligibility-check/) 
   
<!---
About Project information needs to be comprehensive and useful for new members to be able to understand it's goals. 
-->
## About Project
- This repository is used to host the configuration for the site that allows users to verify their voting status.

<!---
Getting Started information needs to offer guidance on how to get familiarized with the project and any information on how to set up your local environment (when applicable).
-->

## Contribute

- To contribute, please refer to the **[Hiero-Ledger's contribution guidelines](https://github.com/hiero-ledger/.github/blob/main/CONTRIBUTING.md)**

<!---
Help and Community includes discord channels, meeting information or references where new members can ask questions. 
Links to issues and discussions.
-->

## About Users and Maintainers

- Users and Maintainers guidelines are located in **[Hiero-Ledger's CONTRIBUTING.md file](https://github.com/hiero-ledger/.github/blob/main/CONTRIBUTING.md#about-users-and-maintainers)** under the "About-Users-and-Maintainers" section.

<!---
Recognition to past contributors or mentions of collaborating companies.
-->

## License

- Hiero's source code is available under the **Apache License, Version 2.0 (Apache-2.0)**
