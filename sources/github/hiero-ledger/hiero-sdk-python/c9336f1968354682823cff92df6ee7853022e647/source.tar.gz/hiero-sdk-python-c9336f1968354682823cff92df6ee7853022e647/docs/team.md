# Hiero Python SDK Team

The team at the Python SDK includes: triage, committer and maintainer members.

The Hiero Python SDK Team is responsible for the development, quality, and long-term maintenance of the Python SDK. The team is organized into three roles, each with increasing levels of responsibility and access.

GitHub IDs and names are provided as listed on GitHub.

## Triage Members

**Triage members** have read but not write access. Their responsibilities include: mentoring new starters, providing a preliminary review of pull requests, creating and labeling issues, and actively contributing code for the benefit of the Python SDK.


| Name | GitHub ID |
| :--- | :--- |
| Sophie Bulloch | @exploreriii |
| Manish Dait | @manishdait |
| cheese-cakee | @cheese-cakee |
| prajeeta15 | @prajeeta15 |
| Priyanshu | @tech0priyanshu |

## Committer Members

**Committer members** have write access. Their responsibilities include: creating and laddering issues to incrementally train developers, reviewing pull requests to ensure they meet project standards, and actively contributing code for the benefit of the Python SDK.

| Name | GitHub ID |
| :--- | :--- |
| Sophie Bulloch | @exploreriii |
| Manish Dait | @manishdait |
| aceppaluni | @aceppaluni |
| Adityarya11 | @Adityarya11 |
| Akshat | @Akshat8510 |
| AntonioCeppellini | @AntonioCeppellini |
| Dosi Kolev | @Dosik13 |
| parvninama | @parvninama |
| Daniel Ntege | @danielmarv |
| Mounil2005 | @Mounil2005 |

## Maintainer Members

**Maintainer members** have special write access. Their responsibilities include: provide technical leadership for the SDK, provide leadership on the overall health and direction of the project to ensure it satisfies various scaling and stakeholder needs. They also ensure a welcoming and nourishing environment for all developers and community members, laddering issues, reviewing pull requests and actively contributing code for the benefit of the Python SDK.

| Name | GitHub ID |
| :--- | :--- |
| Sophie Bulloch | @exploreriii |
| Manish Dait | @manishdait |
| MonaaEid | @MonaaEid |

Read more at [MAINTAINERS.md](https://github.com/hiero-ledger/hiero-sdk-python/blob/main/MAINTAINERS.md)
