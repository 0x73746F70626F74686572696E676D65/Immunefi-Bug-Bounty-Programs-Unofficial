"""TCK response models for account endpoints."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CreateAccountResponse:
    """Response payload for createAccount."""

    accountId: str | None = None
    status: str | None = None
    transactionId: str | None = None


@dataclass
class UpdateAccountResponse:
    """Response payload for updateAccount."""

    status: str | None = None


@dataclass
class DeleteAccountResponse:
    """Response payload for deleteAccount."""

    status: str | None = None


@dataclass
class StakingInfoResponse:
    """Nested staking fields in the getAccountInfo response."""

    declineStakingReward: bool | None = None
    stakePeriodStart: str | None = field(metadata={"nullable": True}, default=None)
    pendingReward: str | None = None
    stakedToMe: str | None = None
    stakedAccountId: str | None = field(metadata={"nullable": True}, default=None)
    stakedNodeId: str | None = field(metadata={"nullable": True}, default=None)


@dataclass
class TokenRelationshipResponse:
    """Nested token relationship details for getAccountInfo."""

    tokenId: str | None = None
    symbol: str | None = None
    balance: str | None = None
    kycStatus: str | None = None
    freezeStatus: str | None = None
    decimals: str | None = None
    automaticAssociation: bool | None = None


@dataclass
class GetAccountInfoResponse:
    """Response payload for getAccountInfo."""

    accountId: str | None = None
    contractAccountId: str | None = None
    isDeleted: bool | None = None
    proxyAccountId: str | None = None
    proxyReceived: str | None = None
    key: str | None = None
    balance: str | None = None
    sendRecordThreshold: str | None = None
    receiveRecordThreshold: str | None = None
    isReceiverSignatureRequired: bool | None = None
    expirationTime: str | None = None
    autoRenewPeriod: str | None = None
    liveHashes: list[dict] = field(default_factory=list)
    tokenRelationships: dict[str, TokenRelationshipResponse] = field(default_factory=dict)
    accountMemo: str | None = None
    ownedNfts: str | None = None
    maxAutomaticTokenAssociations: str | None = None
    aliasKey: str | None = None
    ledgerId: str | None = None
    ethereumNonce: str | None = None
    hbarAllowances: list[dict] = field(default_factory=list)
    tokenAllowances: list[dict] = field(default_factory=list)
    nftAllowances: list[dict] = field(default_factory=list)
    stakingInfo: StakingInfoResponse | None = None


@dataclass
class GetAccountBalanceResponse:
    """Response payload for getAccountBalance."""

    hbars: str | None = None
    tokenBalances: dict[str, int] = field(default_factory=dict)
    tokenDecimals: dict[str, int] = field(default_factory=dict)


@dataclass
class ExchangeRateResponse:
    """Exchange rate details included in a transaction receipt."""

    hbars: int | None = None
    cents: int | None = None
    expirationTime: str | None = None


@dataclass
class GetTransactionReceiptResponse:
    """Response payload for getTransactionReceipt."""

    status: str | None = None
    accountId: str | None = None
    fileId: str | None = None
    contractId: str | None = None
    topicId: str | None = None
    tokenId: str | None = None
    scheduleId: str | None = None
    exchangeRate: ExchangeRateResponse | None = None
    topicSequenceNumber: str | None = None
    topicRunningHash: str | None = None
    totalSupply: str | None = None
    scheduledTransactionId: str | None = None
    serials: list[str] = field(default_factory=list)
    duplicates: list[GetTransactionReceiptResponse] = field(default_factory=list)
    children: list[GetTransactionReceiptResponse] = field(default_factory=list)
    nodeId: str | None = None
