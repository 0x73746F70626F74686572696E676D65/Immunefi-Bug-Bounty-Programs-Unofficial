// Script to trigger CodeRabbit plan for all difficulty-labeled issues (including GFI)

const CODERABBIT_MARKER = '<!-- CodeRabbit Plan Trigger -->';
const { DIFFICULTY_LABELS } = require('../labels.js');

async function triggerCodeRabbitPlan(github, owner, repo, issue, marker = CODERABBIT_MARKER) {
  const comment = `${marker} @coderabbitai plan`;

  try {
    await github.rest.issues.createComment({
      owner,
      repo,
      issue_number: issue.number,
      body: comment,
    });
    console.log(`Triggered CodeRabbit plan for issue #${issue.number}`);
    return true;
  } catch (commentErr) {
    console.log('Failed to trigger CodeRabbit plan:', {
      message: commentErr?.message,
      status: commentErr?.status,
      owner,
      repo,
      issueNumber: issue?.number,
    });
    return false;
  }
}

function hasDifficultyLabel(issue, label) {
  // All difficulty labels now qualify — CodeRabbit plan is delivered on
  // approval for every difficulty tier, including Good First Issue.
  const allowed = new Set(DIFFICULTY_LABELS.map(d => d.toLowerCase()));

  const hasAllowedLabel = issue.labels?.some(l => allowed.has(l?.name?.toLowerCase()));

  // Also check if newly added label is a difficulty label
  const isNewLabelAllowed = allowed.has(label?.name?.toLowerCase());

  return hasAllowedLabel || isNewLabelAllowed;
}

async function hasExistingCodeRabbitPlan(github, owner, repo, issueNumber) {
  // Check for existing CodeRabbit plan comment (limited to first 500 comments)
  // Uses marker-based detection to avoid false positives from quoted text
  try {
    const comments = [];
    const iterator = github.paginate.iterator(github.rest.issues.listComments, {
      owner,
      repo,
      issue_number: issueNumber,
      per_page: 100,
    });

    let count = 0;
    for await (const { data: page } of iterator) {
      comments.push(...page);
      count += page.length;
      if (count >= 500) break; // Hard upper bound to prevent unbounded pagination
    }

    // Check for marker-based comment OR @coderabbitai plan text
    return comments.some(c =>
      typeof c?.body === 'string' &&
      (c.body.includes(CODERABBIT_MARKER) || c.body.includes('@coderabbitai plan'))
    );
  } catch (error) {
    console.log('Failed to check existing CodeRabbit plan comments:', {
      message: error?.message,
      status: error?.status,
      owner,
      repo,
      issueNumber,
    });
    // Return false to allow plan trigger attempt (fail-open for better UX)
    return null;
  }
}

async function getLatestIssue(github, owner, repo, issue) {
  if (!issue?.number) return issue;

  try {
    const { data } = await github.rest.issues.get({
      owner,
      repo,
      issue_number: issue.number,
    });

    return data || issue;
  } catch (error) {
    console.log('Failed to refresh issue state; falling back to event payload:', {
      message: error?.message,
      status: error?.status,
      owner,
      repo,
      issueNumber: issue?.number,
    });

    return issue;
  }
}

function logSummary(owner, repo, issue) {
  console.log('=== Summary ===');
  console.log(`Repository: ${owner}/${repo}`);
  console.log(`Issue Number: ${issue.number}`);
  console.log(`Issue Title: ${issue.title || '(no title)'}`);
  console.log(`Labels: ${issue.labels?.map(l => l.name).join(', ') || 'none'}`);
}

// Main workflow handler (default export for workflow usage)
async function triggerCodeRabbitPlanForIssue({ github, context }) {
  try {
    const { owner, repo } = context.repo;

    const payload = context?.payload;

    if (!payload) {
      console.log('No event payload');
      return;
    }

    const { issue: eventIssue, label } = payload;

    // Validations
    if (!eventIssue?.number) return console.log('No issue in payload');

    // Refresh issue state to avoid stale payload fields (e.g., locked status)
    // when this script is invoked after earlier workflow steps mutate the issue.
    const issue = await getLatestIssue(github, owner, repo, eventIssue);

    if (issue.locked) {
      return console.log(`Issue #${issue.number} is locked. CodeRabbit plan trigger will be deferred until the issue is approved and unlocked.`);
    }

    if (!hasDifficultyLabel(issue, label)) {
      return console.log('Issue does not have a difficulty label');
    }

    if (await hasExistingCodeRabbitPlan(github, owner, repo, issue.number)) {
      return console.log(`CodeRabbit plan already triggered for #${issue.number}`);
    }

    // Post CodeRabbit plan trigger
    await triggerCodeRabbitPlan(github, owner, repo, issue, CODERABBIT_MARKER);

    logSummary(owner, repo, issue);
  } catch (err) {
    console.log('❌ Error:', {
      message: err?.message,
      status: err?.status,
      owner: context?.repo?.owner,
      repo: context?.repo?.repo,
      issueNumber: context?.payload?.issue?.number,
    });
  }
}

module.exports = {
  triggerCodeRabbitPlan,
  hasExistingCodeRabbitPlan,
  CODERABBIT_MARKER,
  triggerCodeRabbitPlanForIssue,
};
