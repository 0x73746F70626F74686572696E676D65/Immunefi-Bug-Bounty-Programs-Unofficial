// __tests__/jest/test-utils.js
//
// Shared Jest test utilities
//
// Provides:
//   - createMockGithub()  — mock GitHub API factory with call tracking

// =============================================================================
// MOCK GITHUB FACTORY
// =============================================================================

/**
 * Creates a mock GitHub API object for review-sync tests.
 * Tracks labels, permission checks, and review fetches via the returned calls object.
 *
 * @param {object} options
 * @param {Record<string, { role_name?: string, permission?: string }>} options.roles
 *   Map of username → permission data returned by getCollaboratorPermissionLevel
 * @param {Array} options.reviews
 *   Array of review objects returned by pulls.listReviews
 * @param {Record<string, boolean>} options.existingLabels
 *   Map of label name → true (label exists in repo)
 * @param {string[]} options.removeLabelNotFound
 *   Label names for which removeLabel() should throw a 404, simulating a
 *   label that's already gone (race condition or manual removal)
 * @param {string[]} options.removeLabelServerError
 *   Label names for which removeLabel() should throw a 500, simulating an
 *   unexpected API failure that should NOT be swallowed
 * @param {object|null} options.prData
 *   Single PR object returned by pulls.get(). Defaults to a 404, simulating
 *   a PR number that doesn't exist.
 * @param {Array} options.prList
 *   Array of PR objects returned by pulls.list() (and therefore paginate()),
 *   simulating the open-PR listing the review-sync cron job fetches.
 * @returns {{ calls: object, rest: object, paginate: function }}
 */
function createMockGithub(options = {}) {
  const {
    roles = {},
    reviews = [],
    existingLabels = {},
    checkRuns = [],
    removeLabelNotFound = [],
    removeLabelServerError = [],
    prData = null,
    prList = [],
  } = options;

  const calls = {
    labelsAdded: [],
    labelsRemoved: [],
    labelsCreated: [],
    labelsChecked: [],
    permissionsChecked: [],
    pullsFetched: [],
  };

  const mock = {
    calls,
    rest: {
      repos: {
        getCollaboratorPermissionLevel: async ({ username }) => {
          calls.permissionsChecked.push(username);
          const role = roles[username];
          if (!role) {
            throw Object.assign(new Error('Not found'), { status: 404 });
          }
          return { data: role };
        },
      },
      pulls: {
        listReviews: async () => ({ data: reviews }),
        list: async () => ({ data: prList }),
        get: async ({ pull_number }) => {
          calls.pullsFetched.push(pull_number);
          if (!prData) {
            throw Object.assign(new Error('Not found'), { status: 404 });
          }
          return { data: prData };
        },
      },
      checks: {
        listForRef: async () => ({ data: { check_runs: checkRuns } }),
      },
      issues: {
        getLabel: async ({ name }) => {
          calls.labelsChecked.push(name);
          if (!existingLabels[name]) {
            throw Object.assign(new Error('Not found'), { status: 404 });
          }
          return { data: { name } };
        },
        createLabel: async ({ name, color, description }) => {
          calls.labelsCreated.push({ name, color, description });
          return {};
        },
        addLabels: async ({ labels }) => {
          calls.labelsAdded.push(...labels);
          return {};
        },
        removeLabel: async ({ name }) => {
          if (removeLabelNotFound.includes(name)) {
            throw Object.assign(new Error('Not found'), { status: 404 });
          }
          if (removeLabelServerError.includes(name)) {
            throw Object.assign(new Error('Internal server error'), { status: 500 });
          }
          calls.labelsRemoved.push(name);
          return {};
        },
      },
      rateLimit: {
        get: async () => ({
          data: { resources: { core: { remaining: 5000 } } },
        }),
      },
    },
    paginate: async (fn, opts) => {
      const result = await fn(opts);
      if (result.data && result.data.check_runs) return result.data.check_runs;
      return result.data || result || [];
    },
  };

  return mock;
}

module.exports = { createMockGithub };
