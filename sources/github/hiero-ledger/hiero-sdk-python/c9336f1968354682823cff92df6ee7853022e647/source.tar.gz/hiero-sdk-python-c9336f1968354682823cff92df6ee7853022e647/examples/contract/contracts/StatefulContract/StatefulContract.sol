pragma solidity ^0.8.2;

contract StatefulContract {
    bytes32 private message;

    address public owner;

    constructor(bytes32 _msg) payable {
        message = _msg;
        owner = msg.sender;
    }

    function getMessage() external view returns (bytes32) {
        return message;
    }

    function setMessage(bytes32 _msg) external {
        message = _msg;
    }

    function getMessageAndOwner() external view returns (bytes32, address) {
        return (message, owner);
    }

    function setMessageAndPay(bytes32 _msg) external payable {
        require(msg.sender == owner, "Only the owner can update the message.");
        message = _msg;
    }

    function withdrawFunds() external {
        require(msg.sender == owner, "Only the owner can withdraw funds.");
        uint256 amount = address(this).balance;
        payable(owner).transfer(amount);
    }

    function consumeLargeData(bytes calldata data) external {
        // Do nothing
    }

    receive() external payable {}
}
