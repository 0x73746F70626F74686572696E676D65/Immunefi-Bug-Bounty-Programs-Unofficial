// SPDX-License-Identifier: Apache-2.0

import { type Logger } from 'pino';

import { ConfigService } from '../../../../../config-service/services';
import { numberTo0x, parseNumericEnvVar } from '../../../../formatters';
import { type MirrorNodeClient } from '../../../clients';
import type { ICacheClient } from '../../../clients/cache/ICacheClient';
import constants from '../../../constants';
import { type JsonRpcError, predefined } from '../../../errors/JsonRpcError';
import type { RequestDetails } from '../../../types';
import {
  type IMirrorNodeTransactionRecord,
  type ITransfer,
  type LatestBlockNumberTimestamp,
  type MirrorNodeBlock,
} from '../../../types/mirrorNode';
import type { IPendingPoolStatusInfo } from '../../../types/transactionPool';
import { type TransactionPoolService } from '../../transactionPoolService/transactionPoolService';
import { WorkersPool } from '../../workersService/WorkersPool';
import { type ICommonService } from '../ethCommonService/ICommonService';
import { type IAccountService } from './IAccountService';

/**
 * Result of resolving a block identifier for balance retrieval.
 *
 * Discriminated on `isLatest` so callers can route without having to re-inspect the
 * resolved block tag:
 *  - `isLatest: true`  → the request targets the chain tip; read the live balance (the caller
 *    already has everything it needs, so no extra fields are carried).
 *  - `isLatest: false` → the request targets a historical (archival) block; read the balance as of
 *    that block. `latestBlock` carries the finality timestamp the historical calculation needs; the
 *    block identifier itself is still the one the caller passed in, so it is not echoed back.
 */
type BalanceBlockResolution = { isLatest: true } | { isLatest: false; latestBlock: LatestBlockNumberTimestamp };

export class AccountService implements IAccountService {
  /**
   * The service used for caching items from requests.
   *
   * @private
   */
  private readonly cacheService: ICacheClient;

  /**
   * The Common Service implementation that contains logic shared by other services.
   *
   * @private
   */
  private readonly common: ICommonService;

  /**
   * @private
   */
  private readonly ethBlockNumberCacheTtlMs = parseNumericEnvVar(
    'ETH_BLOCK_NUMBER_CACHE_TTL_MS',
    'ETH_BLOCK_NUMBER_CACHE_TTL_MS_DEFAULT',
  );

  /**
   * @private
   */
  private readonly ethGetBalanceCacheTtlMs = parseNumericEnvVar(
    'ETH_GET_BALANCE_CACHE_TTL_MS',
    'ETH_GET_BALANCE_CACHE_TTL_MS_DEFAULT',
  );

  /**
   * @private
   */
  private readonly ethGetTransactionCountCacheTtl = parseNumericEnvVar(
    'ETH_GET_TRANSACTION_COUNT_CACHE_TTL',
    'ETH_GET_TRANSACTION_COUNT_CACHE_TTL',
  );

  /**
   * The logger used for logging all output from this class.
   *
   * @private
   */
  private readonly logger: Logger;

  /**
   * @private
   */
  private readonly maxBlockRange = parseNumericEnvVar('MAX_BLOCK_RANGE', 'MAX_BLOCK_RANGE');

  /**
   * The interface through which we interact with the mirror node.
   *
   * @private
   */
  private readonly mirrorNodeClient: MirrorNodeClient;

  /**
   * The interface through which we interact with the transaction pool.
   * @private
   */
  private readonly transactionPoolService: TransactionPoolService;

  /**
   * @constructor
   * @param cacheService
   * @param common
   * @param logger
   * @param mirrorNodeClient
   */
  constructor(
    cacheService: ICacheClient,
    common: ICommonService,
    logger: Logger,
    mirrorNodeClient: MirrorNodeClient,
    transactionPoolService: TransactionPoolService,
  ) {
    this.cacheService = cacheService;
    this.common = common;
    this.logger = logger;
    this.mirrorNodeClient = mirrorNodeClient;
    this.transactionPoolService = transactionPoolService;
  }

  /**
   * Gets the balance of an account as of the given block from the mirror node.
   *
   * @param {string} account The account to get the balance from
   * @param {string} blockNumberOrTagOrHash The block number or tag or hash to get the balance from
   * @param {RequestDetails} requestDetails The request details for logging and tracking
   */
  public async getBalance(
    account: string,
    blockNumberOrTagOrHash: string,
    requestDetails: RequestDetails,
  ): Promise<string> {
    return WorkersPool.run(
      {
        type: 'getBalance',
        account,
        blockNumberOrTagOrHash,
        requestDetails,
      },
      this.mirrorNodeClient,
      this.cacheService,
    );
  }

  /**
   * Resolves whether a block identifier refers to the chain tip ("latest") or a historical
   * (archival) block, returning a discriminated union so callers can route without re-parsing
   * the block tag.
   *
   * The flow is:
   *  1. Resolve the latest block (from cache or the mirror node).
   *  2. Resolve the requested block identifier (hash or number) to a block number.
   *  3. If that block is within `LATEST_BLOCK_TOLERANCE` of the latest block, treat it as the tip
   *     and return `{ isLatest: true }`.
   *  4. Otherwise return `{ isLatest: false }`, ensuring the latest block timestamp is populated for
   *     the downstream historical balance calculation.
   *
   * @param blockNumberOrTagOrHash the block number or hash to resolve (never `latest`/`pending`;
   *   callers must short-circuit those tags before calling this method)
   * @param requestDetails the request details for logging and tracking
   */
  public async extractBlockNumberAndTimestamp(
    blockNumberOrTagOrHash: string,
    requestDetails: RequestDetails,
  ): Promise<BalanceBlockResolution> {
    let latestBlock = await this.getLatestBlockFromCacheOrMirror(requestDetails);

    const isHash = blockNumberOrTagOrHash.length > 32;
    const requestedBlockNumber = isHash
      ? Number((await this.mirrorNodeClient.getBlock(blockNumberOrTagOrHash, requestDetails)).number)
      : Number(blockNumberOrTagOrHash);

    const blockDiff = Number(latestBlock.blockNumber) - requestedBlockNumber;
    if (blockDiff <= constants.LATEST_BLOCK_TOLERANCE) {
      return { isLatest: true };
    }

    // The request targets an archival block. If the latest block came from cache it only carries the
    // block number (timeStampTo === '0'); fetch the full block so the historical balance calculation
    // has the finality timestamp. This should rarely happen.
    if (latestBlock.timeStampTo === '0') {
      latestBlock = await this.blockNumberTimestamp(constants.ETH_GET_BALANCE, requestDetails);
    }

    return { isLatest: false, latestBlock };
  }

  /**
   * Returns the latest block, preferring the cached block number when available. A cache hit yields
   * only the block number (with `timeStampTo` set to '0' as a sentinel for "not yet fetched");
   * callers that need the timestamp must fetch the full block separately.
   *
   * @param requestDetails the request details for logging and tracking
   * @private
   */
  private async getLatestBlockFromCacheOrMirror(requestDetails: RequestDetails): Promise<LatestBlockNumberTimestamp> {
    const cacheKey = `${constants.CACHE_KEY.ETH_BLOCK_NUMBER}`;
    const blockNumberCached = await this.cacheService.getAsync<string>(cacheKey, constants.ETH_GET_BALANCE);

    if (blockNumberCached) {
      if (this.logger.isLevelEnabled('trace')) {
        this.logger.trace(`returning cached value %s:%s`, cacheKey, JSON.stringify(blockNumberCached));
      }
      return { blockNumber: blockNumberCached, timeStampTo: '0' };
    }

    return this.blockNumberTimestamp(constants.ETH_GET_BALANCE, requestDetails);
  }

  /**
   * @param nextPage
   * @param block
   * @param requestDetails
   * @private
   */
  private async getPagedTransactions(
    nextPage: string,
    block: MirrorNodeBlock,
    requestDetails: RequestDetails,
  ): Promise<IMirrorNodeTransactionRecord[]> {
    let pagedTransactions: IMirrorNodeTransactionRecord[] = [];
    // if we have a pagination link that falls within the block.timestamp.to, we need to paginate to get the transactions for the block.timestamp.to
    const nextPageParams = new URLSearchParams(nextPage.split('?')[1]);
    const nextPageTimeMarker = nextPageParams.get('timestamp');
    // if nextPageTimeMarker is greater than the block.timestamp.to, then we need to paginate to get the transactions for the block.timestamp.to
    if (nextPageTimeMarker && nextPageTimeMarker?.split(':')[1] >= block.timestamp.to) {
      pagedTransactions = await this.mirrorNodeClient.getAccountPaginated(nextPage, requestDetails, block.timestamp.to);
    }
    // if nextPageTimeMarker is less than the block.timestamp.to, then just run the getBalanceAtBlockTimestamp function in this case as well.

    return pagedTransactions;
  }

  /**
   * @param account
   * @param block
   * @param latestBlock
   * @param requestDetails
   */
  async getBalanceAtBlockNumber(
    account: string,
    block: MirrorNodeBlock,
    latestBlock: LatestBlockNumberTimestamp,
    requestDetails: RequestDetails,
  ): Promise<{ balanceFound: boolean; weibars: bigint }> {
    let balanceFound = false;
    let weibars = BigInt(0);
    let mirrorAccount;

    const latestTimestamp = Number(latestBlock.timeStampTo.split('.')[0]);
    const blockTimestamp = Number(block.timestamp.from.split('.')[0]);
    const timeDiff = latestTimestamp - blockTimestamp;
    // The block is NOT from the last 15 minutes, use /balances rest API
    if (timeDiff > constants.BALANCES_UPDATE_INTERVAL) {
      const balance = await this.mirrorNodeClient.getBalanceAtTimestamp(account, requestDetails, block.timestamp.from);
      balanceFound = true;
      if (balance?.balances?.length) {
        weibars = BigInt(balance.balances[0].balance) * BigInt(constants.TINYBAR_TO_WEIBAR_COEF);
      }
    }
    // The block is from the last 15 minutes, therefore the historical balance hasn't been imported in the Mirror Node yet
    else {
      let currentBalance = 0;
      let balanceFromTxs: number;
      mirrorAccount = await this.mirrorNodeClient.getAccount(account, requestDetails, {
        limit: ConfigService.get('MIRROR_NODE_LIMIT_PARAM'),
        transactions: true,
      });
      if (mirrorAccount) {
        if (mirrorAccount.balance) {
          currentBalance = mirrorAccount.balance.balance;
        }

        // The balance in the account is real time, so we simply subtract the transactions to the block.timestamp.to to get a block relevant balance.
        // needs to be updated below.
        const nextPage = mirrorAccount.links?.next;
        if (nextPage) {
          mirrorAccount.transactions = (mirrorAccount.transactions ?? []).concat(
            await this.getPagedTransactions(nextPage, block, requestDetails),
          );
        }

        balanceFromTxs = this.getBalanceAtBlockTimestamp(
          mirrorAccount.account,
          mirrorAccount.transactions ?? [],
          block.timestamp.to,
        );

        balanceFound = true;
        const tinybars = currentBalance - balanceFromTxs;
        if (tinybars < 0) {
          this.logger.warn(
            `Reconstructed a negative balance for account %s at block %s (current: %s, rewound: %s), returning 0`,
            account,
            block.number,
            currentBalance,
            balanceFromTxs,
          );
        }
        weibars = BigInt(Math.max(tinybars, 0)) * BigInt(constants.TINYBAR_TO_WEIBAR_COEF);
      }
    }

    return { balanceFound, weibars };
  }

  /**
   * Get transaction counts associated with an account.
   *
   * @param {string} address The account address
   * @param {RequestDetails} requestDetails The request details for logging and tracking
   */
  public async getTransactionCounts(address: string, requestDetails: RequestDetails): Promise<IPendingPoolStatusInfo> {
    const [confirmedCount, pendingCount] = await Promise.all([
      this.transactionPoolService.getConfirmedCount(address),
      this.transactionPoolService.getPendingCount(address),
    ]);
    if (confirmedCount != null) return { pendingCount, confirmedCount, mirrorNodeArtifact: null };
    const accountData = await this.mirrorNodeClient.getAccount(address, requestDetails);
    const toResult = (confirmedCount: number): IPendingPoolStatusInfo => ({
      pendingCount,
      confirmedCount,
      mirrorNodeArtifact: accountData,
    });

    if (!accountData) return toResult(0);
    if (accountData.ethereum_nonce == null) return toResult(1);
    return toResult(Number(accountData.ethereum_nonce));
  }

  /**
   * Gets the number of transactions that have been executed for the given address.
   * This goes to the consensus nodes to determine the ethereumNonce.
   *
   * Queries mirror node for best effort and falls back to consensus node for contracts until HIP 729 is implemented.
   *
   * @param {string} address The account address
   * @param {string} blockNumOrTag Possible values are earliest/pending/latest or hex
   * @param {RequestDetails} requestDetails The request details for logging and tracking
   */
  public async getTransactionCount(
    address: string,
    blockNumOrTag: string,
    requestDetails: RequestDetails,
  ): Promise<string | JsonRpcError> {
    const blockNum = Number(blockNumOrTag);
    if (blockNum === 0 || blockNum === 1) {
      // previewnet and testnet bug have a genesis blockNumber of 1 but non system account were yet to be created
      return constants.ZERO_HEX;
    } else if (this.common.blockTagIsLatestOrPending(blockNumOrTag)) {
      const { confirmedCount, pendingCount } = await this.getTransactionCounts(address, requestDetails);
      return numberTo0x(blockNumOrTag === constants.BLOCK_PENDING ? confirmedCount + pendingCount : confirmedCount);
    } else if (blockNumOrTag === constants.BLOCK_EARLIEST) {
      return await this.getAccountNonceForEarliestBlock(requestDetails);
    } else if (!isNaN(blockNum) && blockNumOrTag.length !== constants.BLOCK_HASH_LENGTH && blockNum > 0) {
      return await this.getAccountNonceForHistoricBlock(address, blockNum, requestDetails);
    } else if (blockNumOrTag.length === constants.BLOCK_HASH_LENGTH && blockNumOrTag.startsWith(constants.EMPTY_HEX)) {
      return await this.getAccountNonceForHistoricBlock(address, blockNumOrTag, requestDetails);
    }

    // return a '-39001: Unknown block' error per api-spec
    throw predefined.UNKNOWN_BLOCK();
  }

  /**
   * Gets the most recent block number and timestamp.to which represents the block finality.
   */
  private async blockNumberTimestamp(
    caller: string,
    requestDetails: RequestDetails,
  ): Promise<LatestBlockNumberTimestamp> {
    const cacheKey = `${constants.CACHE_KEY.ETH_BLOCK_NUMBER}`;

    const blocksResponse = await this.mirrorNodeClient.getLatestBlock(requestDetails);
    const blocks = blocksResponse !== null ? blocksResponse.blocks : null;
    if (Array.isArray(blocks) && blocks.length > 0) {
      const currentBlock = numberTo0x(blocks[0].number);
      const timestamp = blocks[0].timestamp.to;
      const blockTimeStamp: LatestBlockNumberTimestamp = { blockNumber: currentBlock, timeStampTo: timestamp };
      // save the latest block number in cache
      await this.cacheService.set(cacheKey, currentBlock, caller, this.ethBlockNumberCacheTtlMs);

      return blockTimeStamp;
    }

    throw predefined.COULD_NOT_RETRIEVE_LATEST_BLOCK;
  }

  /**
   * Returns the difference between the balance of the account and the transactions summed up to the block number queried.
   * @param account
   * @param transactions
   * @param blockTimestamp
   * @private
   */
  private getBalanceAtBlockTimestamp(
    account: string,
    transactions: IMirrorNodeTransactionRecord[],
    blockTimestamp: string,
  ): number {
    return transactions
      .filter((transaction) => {
        return transaction.consensus_timestamp > blockTimestamp;
      })
      .flatMap((transaction) => {
        return transaction.transfers.filter((transfer: ITransfer) => {
          return transfer.account === account;
        });
      })
      .map((transfer) => {
        return transfer.amount;
      })
      .reduce((total, amount) => {
        return total + amount;
      }, 0);
  }

  /**
   * Get nonce for historical block
   * @param address
   * @param blockNumOrHash
   * @param requestDetails
   * @private
   */
  private async getAccountNonceForHistoricBlock(
    address: string,
    blockNumOrHash: number | string,
    requestDetails: RequestDetails,
  ): Promise<string> {
    const isParamBlockNum = typeof blockNumOrHash === 'number';

    if (isParamBlockNum && (blockNumOrHash as number) < 0) {
      throw predefined.UNKNOWN_BLOCK();
    }

    let blockNum: number;
    if (isParamBlockNum) {
      blockNum = blockNumOrHash;
    } else {
      const block = await this.mirrorNodeClient.getBlock(blockNumOrHash, requestDetails);
      if (!block) {
        throw predefined.UNKNOWN_BLOCK();
      }
      blockNum = block.number;
    }

    // check if on latest block, if so get latest ethereumNonce from mirror node account API
    const blockResponse = await this.mirrorNodeClient.getLatestBlock(requestDetails); // consider caching error responses
    if (blockResponse == null || blockResponse.blocks.length === 0) {
      throw predefined.UNKNOWN_BLOCK();
    }

    if (blockResponse.blocks[0].number - blockNum <= this.maxBlockRange) {
      return this.getAccountLatestEthereumNonce(address, requestDetails);
    }

    // if valid block number, get block timestamp
    return await this.getAccountNonceFromContractResult(address, blockNum, requestDetails);
  }

  private async getAccountLatestEthereumNonce(address: string, requestDetails: RequestDetails): Promise<string> {
    const accountData = await this.mirrorNodeClient.getAccount(address, requestDetails);
    if (accountData) {
      // with HIP 729 ethereum_nonce should always be 0+ and null. Historical contracts may have a null value as the nonce was not tracked, return default EVM compliant 0x1 in this case
      return accountData.ethereum_nonce != null ? numberTo0x(accountData.ethereum_nonce) : constants.ONE_HEX;
    }

    return constants.ZERO_HEX;
  }

  /**
   * Returns the number of transactions sent from an address by searching for the ethereum transaction involving the address
   * Remove when https://github.com/hashgraph/hedera-mirror-node/issues/5862 is implemented
   *
   * @param {string} address The account address
   * @param {string | number} blockNumOrHash The block number or hash
   * @param {RequestDetails} requestDetails The request details for logging and tracking
   * @returns {Promise<string>} The number of transactions sent from the address
   */
  private async getAccountNonceFromContractResult(
    address: string,
    blockNumOrHash: string | number,
    requestDetails: RequestDetails,
  ): Promise<string> {
    // get block timestamp for blockNum
    const block = await this.mirrorNodeClient.getBlock(blockNumOrHash, requestDetails); // consider caching error responses
    if (block == null) {
      throw predefined.UNKNOWN_BLOCK();
    }

    // get the latest 2 ethereum transactions for the account
    const ethereumTransactions = await this.mirrorNodeClient.getAccountLatestEthereumTransactionsByTimestamp(
      address,
      block.timestamp.to,
      requestDetails,
      2,
    );
    if (ethereumTransactions == null || ethereumTransactions.transactions!.length === 0) {
      return constants.ZERO_HEX;
    }

    // if only 1 transaction is returned when asking for 2, then the account has only sent 1 transaction
    // minor optimization to save a call to getContractResult as many accounts serve a single use
    if (ethereumTransactions.transactions!.length === 1) {
      return constants.ONE_HEX;
    }

    // get the transaction result for the latest transaction
    const transactionResult = await this.mirrorNodeClient.getContractResult(
      ethereumTransactions.transactions![0].transaction_id,
      requestDetails,
    );
    if (transactionResult == null) {
      throw predefined.RESOURCE_NOT_FOUND(
        `Failed to retrieve contract results for transaction ${ethereumTransactions.transactions![0].transaction_id}`,
      );
    }

    const accountResult = await this.mirrorNodeClient.getAccount(transactionResult.from, requestDetails);

    if (accountResult!.evm_address !== address.toLowerCase()) {
      this.logger.warn(
        `eth_transactionCount for a historical block was requested where address: %s was not sender: %s, returning latest value as best effort.`,
        address,
        transactionResult.address,
      );
      return await this.getAccountLatestEthereumNonce(address, requestDetails);
    }

    return numberTo0x((transactionResult.nonce ?? 0) + 1); // nonce is 0 indexed
  }

  /**
   * Get nonce for earliest block
   * @param requestDetails
   * @private
   */
  private async getAccountNonceForEarliestBlock(requestDetails: RequestDetails): Promise<string> {
    const block = await this.mirrorNodeClient.getEarliestBlock(requestDetails);
    if (block == null) {
      throw predefined.INTERNAL_ERROR('No network blocks found');
    }

    if (block.number <= 1) {
      // if the earliest block is the genesis block or 1 , then the nonce is 0 as only system accounts are present
      return constants.ZERO_HEX;
    }

    // note the mirror node may be a partial one, in which case there may be a valid block with number greater 1.
    throw predefined.INTERNAL_ERROR(`Partial mirror node encountered, earliest block number is ${block.number}`);
  }
}
