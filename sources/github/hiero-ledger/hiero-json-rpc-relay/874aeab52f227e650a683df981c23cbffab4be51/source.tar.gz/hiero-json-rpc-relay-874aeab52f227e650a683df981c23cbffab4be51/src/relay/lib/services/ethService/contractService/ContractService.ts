// SPDX-License-Identifier: Apache-2.0

import { type Logger } from 'pino';

import { ConfigService } from '../../../../../config-service/services';
import {
  isValidEthereumAddress,
  numberTo0x,
  parseNumericEnvVar,
  prepend0x,
  strip0x,
  trimPrecedingZeros,
  weibarHexToTinyBarInt,
  weibarToTinyBar,
} from '../../../../formatters';
import type { MirrorNodeClient } from '../../../clients';
import type { ICacheClient } from '../../../clients/cache/ICacheClient';
import constants from '../../../constants';
import { JsonRpcError, predefined } from '../../../errors/JsonRpcError';
import { MirrorNodeClientError } from '../../../errors/MirrorNodeClientError';
import { type Log } from '../../../model';
import {
  type AccountStorage,
  type IContractCallRequest,
  type IContractCallResponse,
  type IGetLogsParams,
  type IStateOverride,
  type IStorageEntry,
  type RequestDetails,
  type StateOverrideSet,
} from '../../../types';
import { isRequestAbortedError } from '../../../utils/requestAbort';
import { CommonService } from '../../ethService/ethCommonService/CommonService';
import type { ICommonService } from '../../ethService/ethCommonService/ICommonService';
import type HAPIService from '../../hapiService/hapiService';
import type { IContractService } from './IContractService';

/**
 * Service responsible for handling contract-related operations.
 */
export class ContractService implements IContractService {
  /**
   * The cache service used for caching responses.
   * @private
   * @readonly
   */
  private readonly cacheService: ICacheClient;

  /**
   * The common service used for all common methods.
   * @private
   * @readonly
   */
  private readonly common: ICommonService;

  /**
   * The default gas value for transactions.
   * @private
   * @readonly
   */
  private readonly defaultGas = numberTo0x(parseNumericEnvVar('TX_DEFAULT_GAS', 'TX_DEFAULT_GAS_DEFAULT'));

  /**
   * The interface for HAPI service to interact with consensus nodes.
   * @private
   * @readonly
   */
  private readonly hapiService: HAPIService;

  /**
   * The logger used for logging all output from this class.
   * @private
   * @readonly
   */
  private readonly logger: Logger;

  /**
   * The interface through which we interact with the mirror node.
   * @private
   * @readonly
   */
  private readonly mirrorNodeClient: MirrorNodeClient;

  /**
   * Creates a new instance of the ContractService
   *
   * @param {ICacheClient} cacheService - The cache service for caching responses
   * @param {CommonService} common - The common service for shared functionality
   * @param {HAPIService} hapiService - The HAPI service for consensus node interaction
   * @param {Logger} logger - The logger for logging
   * @param {MirrorNodeClient} mirrorNodeClient - The mirror node client
   */
  constructor(
    cacheService: ICacheClient,
    common: ICommonService,
    hapiService: HAPIService,
    logger: Logger,
    mirrorNodeClient: MirrorNodeClient,
  ) {
    this.cacheService = cacheService;
    this.common = common;
    this.hapiService = hapiService;
    this.logger = logger;
    this.mirrorNodeClient = mirrorNodeClient;
  }

  /**
   * Returns an array of addresses owned by client.
   * Always returns an empty array for Hedera.
   *
   * @returns An empty array of addresses
   */
  public accounts(): [] {
    return [];
  }

  /**
   * Executes a new message call immediately without creating a transaction on the blockchain.
   *
   * @param {IContractCallRequest} call - The transaction object with call data
   * @param {string | object | null} blockParam - Block number, tag, or object with blockHash/blockNumber
   * @param {RequestDetails} requestDetails - The request details for logging and tracking
   * @param {StateOverrideSet} [stateOverride] - Account state to replace for the duration of the call
   * @returns {Promise<string>} The return value of the executed contract call
   */
  public async call(
    call: IContractCallRequest,
    blockParam: string | object | null,
    requestDetails: RequestDetails,
    stateOverride?: StateOverrideSet,
  ): Promise<string> {
    try {
      if (call.to && !isValidEthereumAddress(call.to)) {
        throw predefined.INVALID_CONTRACT_ADDRESS(call.to);
      }

      const blockNumberOrTag = this.extractBlockParam(blockParam);
      const gas = this.getCappedBlockGasLimit(call.gas?.toString());
      await this.contractCallFormat(call, requestDetails);

      this.applyStateOverrides(call, stateOverride);

      const result = await this.callMirrorNode(call, gas, call.value, blockNumberOrTag, requestDetails);
      if (this.logger.isLevelEnabled('debug')) {
        this.logger.debug(`eth_call response: %s`, JSON.stringify(result));
      }

      return result;
    } catch (e) {
      if (e instanceof JsonRpcError || isRequestAbortedError(e)) throw e;
      if (e instanceof MirrorNodeClientError) await this.handleMirrorNodeClientError(e);

      this.logger.error(e, 'Failed to successfully submit eth_call');
      throw predefined.INTERNAL_ERROR((e as Error).message.toString());
    }
  }

  /**
   * Estimates the amount of gas required to execute a contract call.
   *
   * @param {IContractCallRequest} transaction - The transaction data for the contract call.
   * @param {string | null} blockParam - Optional block parameter to specify the block to estimate gas for.
   * @param {RequestDetails} requestDetails - The details of the request for logging and tracking.
   * @param {StateOverrideSet} [stateOverride] - Account state to replace for the duration of the estimate
   * @returns {Promise<string>} A promise that resolves to the estimated gas in hexadecimal format or a JsonRpcError.
   */
  public async estimateGas(
    transaction: IContractCallRequest,
    blockParam: string | null,
    requestDetails: RequestDetails,
    stateOverride?: StateOverrideSet,
  ): Promise<string> {
    try {
      const response = await this.estimateGasFromMirrorNode(transaction, requestDetails, stateOverride);

      if (!response?.result) {
        if (this.logger.isLevelEnabled('debug')) {
          this.logger.debug(`No gas estimate returned from mirror-node: ${JSON.stringify(response)}`);
        }
        throw predefined.INTERNAL_ERROR('Fail to retrieve gas estimate');
      }

      return prepend0x(trimPrecedingZeros(response.result) ?? '0');
    } catch (e) {
      if (e instanceof JsonRpcError || isRequestAbortedError(e)) throw e;
      if (e instanceof MirrorNodeClientError) await this.handleMirrorNodeClientError(e);

      this.logger.error(e, 'Failed to successfully estimate gas');
      throw predefined.INTERNAL_ERROR((e as Error).message.toString());
    }
  }

  /**
   * Returns the compiled smart contract code at a given address.
   *
   * @param {string} address - The address to get code from
   * @param {string | null} blockNumber - Block number or tag
   * @param {RequestDetails} requestDetails - The request details for logging and tracking
   * @returns {Promise<string>} The code at the given address
   */
  public async getCode(address: string, blockNumber: string | null, requestDetails: RequestDetails): Promise<string> {
    if (!this.common.isBlockParamValid(blockNumber)) {
      throw predefined.UNKNOWN_BLOCK(
        `The value passed is not a valid blockHash/blockNumber/blockTag value: ${blockNumber}`,
      );
    }

    // check for static precompile cases first before consulting nodes
    // this also accounts for environments where system entities were not yet exposed to the mirror node
    if (address === constants.HTS_ADDRESS || address === constants.HSS_ADDRESS) {
      this.logger.trace(`System contract %s, return %s for byte code`, address, constants.INVALID_EVM_INSTRUCTION);
      return constants.INVALID_EVM_INSTRUCTION;
    }

    try {
      const result = await this.mirrorNodeClient.resolveEntityType(address, constants.ETH_GET_CODE, requestDetails, [
        constants.TYPE_CONTRACT,
        constants.TYPE_TOKEN,
        constants.TYPE_ACCOUNT,
        constants.TYPE_SCHEDULE,
      ]);
      if (result) {
        const blockInfo = await this.common.getHistoricalBlockResponse(requestDetails, blockNumber, true);
        const entityCreatedTimestamp = result.entity?.created_timestamp ?? result.entity?.consensus_timestamp;
        if (!blockInfo || parseFloat(entityCreatedTimestamp as string) > parseFloat(blockInfo.timestamp.to)) {
          return constants.EMPTY_HEX;
        }
        if (result.type === constants.TYPE_TOKEN) {
          this.logger.trace(
            `Token facade case, return delegation designator pointing to HTS (%s)`,
            constants.HTS_ADDRESS,
          );
          return CommonService.getDelegationDesignator(constants.HTS_ADDRESS);
        } else if (result.type === constants.TYPE_SCHEDULE) {
          this.logger.trace(
            `Schedule facade case, return delegation designator pointing to HSS (%s)`,
            constants.HSS_ADDRESS,
          );
          return CommonService.getDelegationDesignator(constants.HSS_ADDRESS);
        } else if (result.type === constants.TYPE_CONTRACT) {
          if (result.entity.runtime_bytecode !== constants.EMPTY_HEX) {
            return result.entity.runtime_bytecode!;
          }
        } else if (result.type === constants.TYPE_ACCOUNT) {
          const delegatedHex = ContractService.delegationAddressFromMirrorAccount(result.entity);
          if (delegatedHex) {
            this.logger.trace('EIP-7702 / HIP-1340 delegated EOA, return delegation designator');
            return `${constants.EOA_DELEGATION_DESIGNATOR_PREFIX}${delegatedHex}`;
          }
        }
      }

      this.logger.debug(
        `Address %s is not a contract, HTS token, HSS schedule, or delegated EOA, returning empty hex`,
        address,
      );

      return constants.EMPTY_HEX;
    } catch (error) {
      if (isRequestAbortedError(error)) throw error;

      this.logger.error(
        `Error raised during getCode: address=%s, blockNumber=%s, error=%s`,
        address,
        blockNumber,
        (error as Error).message,
      );
      throw error;
    }
  }

  /**
   * Returns an array of all logs matching the given filter criteria.
   *
   * @param {IGetLogsParams} params - The filter criteria
   * @param {RequestDetails} requestDetails - The request details for logging and tracking
   * @returns {Promise<Log[]>} An array of log objects
   */
  public async getLogs(params: IGetLogsParams, requestDetails: RequestDetails): Promise<Log[]> {
    return this.common.getLogs(
      params.blockHash,
      params.fromBlock,
      params.toBlock,
      params.address,
      params.topics,
      requestDetails,
    );
  }

  /**
   * Returns the value from a storage position at a given address.
   *
   * @param {string} address - The address of the storage
   * @param {string} slot - The slot index (hex string)
   * @param {string} blockNumberOrTagOrHash - Block number, tag, or hash
   * @param {RequestDetails} requestDetails - The request details for logging and tracking
   * @returns {Promise<string>} The value at the given storage position
   */
  public async getStorageAt(
    address: string,
    slot: string,
    blockNumberOrTagOrHash: string,
    requestDetails: RequestDetails,
  ): Promise<string> {
    let result = constants.ZERO_HEX_32_BYTE; // if contract or slot not found then return 32 byte 0

    const blockResponse = await this.common.getHistoricalBlockResponse(requestDetails, blockNumberOrTagOrHash, false);
    // To save a request to the mirror node for `latest` and `pending` blocks, we directly return null from `getHistoricalBlockResponse`
    // But if a block number or `earliest` tag is passed and the mirror node returns `null`, we should throw an error.
    if (!this.common.blockTagIsLatestOrPending(blockNumberOrTagOrHash) && blockResponse == null) {
      throw predefined.RESOURCE_NOT_FOUND(`block '${blockNumberOrTagOrHash}'.`);
    }

    const blockEndTimestamp = blockResponse?.timestamp?.to;

    await this.mirrorNodeClient
      .getContractStateByAddressAndSlot(address, slot, requestDetails, blockEndTimestamp)
      .then((response) => {
        if (response !== null && response.state.length > 0) {
          result = response.state[0].value;
        }
      })
      .catch((error: unknown) => {
        throw this.common.genericErrorHandler(
          error,
          `Failed to retrieve current contract state for address ${address} at slot=${slot}`,
        );
      });

    return result;
  }

  /**
   * Makes a contract call via the Mirror Node.
   *
   * @param {IContractCallRequest} call - The call data
   * @param {number | null} gas - The gas limit
   * @param {number | string | null | undefined} value - The value to send
   * @param {string | null} block - The block number or tag
   * @param {RequestDetails} requestDetails - The request details for logging and tracking
   * @returns {Promise<string>} The call result
   */
  private async callMirrorNode(
    call: IContractCallRequest,
    gas: number | null,
    value: number | string | null | undefined,
    block: string | null,
    requestDetails: RequestDetails,
  ): Promise<string> {
    this.logger.debug(
      `Making eth_call on contract %s with gas %s and call data "%s" from "%s" at blockBlockNumberOrTag: "%s" using mirror-node.`,
      call.to,
      gas,
      call.data,
      call.from,
      block,
    );
    const callData = this.prepareMirrorNodeCallData(call, gas, value, block);
    return await this.executeMirrorNodeCall(callData, requestDetails);
  }

  /**
   * Perform value format precheck before making contract call towards the mirror node
   * @param {IContractCallRequest} transaction the transaction object
   * @param {RequestDetails} requestDetails the request details for logging and tracking
   */
  public async contractCallFormat(transaction: IContractCallRequest, requestDetails: RequestDetails): Promise<void> {
    if (transaction.value) {
      transaction.value = weibarHexToTinyBarInt(transaction.value);
    }
    transaction.gasPrice = parseInt(transaction.gasPrice?.toString() || '0');

    // MirrorNode checks the payer balance on its side.
    // By not submitting `gasPrice`, we avoid this check, and a `gasPrice` of 0 would make this check fail anyway.
    if (transaction.gasPrice === 0) {
      delete transaction.gasPrice;
    }
    if (transaction.gas) {
      transaction.gas = parseInt(transaction.gas.toString());
    }
    if (!transaction.from && transaction.value && (transaction.value as number) > 0) {
      if (ConfigService.get('OPERATOR_KEY_FORMAT') === 'HEX_ECDSA') {
        transaction.from = this.hapiService.getOperatorPublicKey()?.toEvmAddress();
      } else {
        const operatorId = this.hapiService.getOperatorAccountId()!.toString();
        const operatorAccount = await this.common.getAccount(operatorId, requestDetails);
        transaction.from = operatorAccount?.evm_address;
      }
    }

    // Support either data or input. https://ethereum.github.io/execution-apis/api-documentation/ lists input but many EVM tools still use data.
    // We chose in the mirror node to use data field as the correct one, however for us to be able to support all tools,
    // we have to modify transaction object, so that it complies with the mirror node.
    // That means that, if input field is passed, but data is not, we have to copy value of input to the data to comply with mirror node.
    // The second scenario occurs when both the data and input fields are present but hold different values.
    // In this case, the value in the input field should be the one used for consensus based on this resource https://github.com/ethereum/execution-apis/blob/main/tests/eth_call/call-contract.io
    // Eventually, for optimization purposes, we can rid of the input property or replace it with empty string.
    if ((transaction.input && transaction.data === undefined) || (transaction.input && transaction.data)) {
      transaction.data = transaction.input;
      delete transaction.input;
    }
  }

  /**
   * Translates an Ethereum state override set into the mirror node's `state_overrides` format.
   *
   * The two differ in shape, naming and units: Ethereum keys overrides by address and holds storage
   * as a map, while the mirror node expects an array of entries carrying their own address,
   * snake_case fields and storage as key/value pairs.
   *
   * @param {StateOverrideSet} stateOverrides - The override set as received from the caller.
   * @returns {IStateOverride[]} The equivalent mirror node overrides, empty when nothing is left to send.
   */
  public formatStateOverrides(stateOverrides: StateOverrideSet): IStateOverride[] {
    const formatted: IStateOverride[] = [];

    for (const [address, override] of Object.entries(stateOverrides)) {
      const entry: IStateOverride = { address: address.toLowerCase() };

      if (override.balance !== undefined) {
        entry.balance = this.toTinybarBalance(override.balance, address);
      }

      if (override.nonce !== undefined) {
        entry.nonce = numberTo0x(BigInt(override.nonce));
      }

      if (override.code !== undefined) {
        entry.code = override.code;
      }

      if (override.state !== undefined) {
        const slots = ContractService.toStorageEntries(override.state);
        // An empty `state` means "replace all storage with nothing". The mirror node ignores an
        // empty list and reads real storage instead, so a single zero slot forces full replacement.
        entry.state =
          slots.length > 0 ? slots : [{ key: constants.ZERO_HEX_32_BYTE, value: constants.ZERO_HEX_32_BYTE }];
      }

      if (override.stateDiff !== undefined) {
        entry.state_diff = ContractService.toStorageEntries(override.stateDiff);
      }

      const hasOverrides = Object.keys(entry).length > 1;
      if (hasOverrides) {
        formatted.push(entry);
      }
    }

    return formatted;
  }

  /**
   * Attaches a translated override set to a mirror node request, in place.
   *
   * @param {IContractCallRequest} call - The request being prepared for the mirror node
   * @param {StateOverrideSet} [stateOverride] - Account state to replace, as received from the caller
   */
  private applyStateOverrides(call: IContractCallRequest, stateOverride?: StateOverrideSet): void {
    const overrides = stateOverride ? this.formatStateOverrides(stateOverride) : [];
    if (overrides.length > 0) {
      call.state_overrides = overrides;
    }
  }

  /**
   * Converts a weibar balance override to tinybars, capped at what the network can hold.
   */
  private toTinybarBalance(balance: string, address: string): string {
    const tinybars = weibarToTinyBar(balance);
    const totalSupply = BigInt(constants.TOTAL_SUPPLY_TINYBARS);

    if (tinybars > totalSupply) {
      this.logger.warn('Balance override for %s exceeds the total supply and was capped', address);
      return numberTo0x(totalSupply);
    }

    return numberTo0x(tinybars);
  }

  private static toStorageEntries(storage: AccountStorage): IStorageEntry[] {
    return Object.entries(storage).map(([key, value]) => ({ key, value }));
  }

  /**
   * Executes an estimate contract call gas request in the mirror node.
   *
   * @param {IContractCallRequest} transaction The transaction data for the contract call.
   * @param {RequestDetails} requestDetails The request details for logging and tracking.
   * @returns {Promise<IContractCallResponse>} the response from the mirror node
   */
  private async estimateGasFromMirrorNode(
    transaction: IContractCallRequest,
    requestDetails: RequestDetails,
    stateOverride?: StateOverrideSet,
  ): Promise<IContractCallResponse | null> {
    await this.contractCallFormat(transaction, requestDetails);
    this.applyStateOverrides(transaction, stateOverride);
    const callData = { ...transaction, estimate: true };
    return this.mirrorNodeClient.postContractCall(callData, requestDetails);
  }

  /**
   * Executes the mirror node call and formats the response.
   *
   * @param {IContractCallRequest} callData - The prepared call data
   * @param {RequestDetails} requestDetails - The request details
   * @returns {Promise<string>} The formatted call response
   * @private
   */
  private async executeMirrorNodeCall(callData: IContractCallRequest, requestDetails: RequestDetails): Promise<string> {
    const contractCallResponse = await this.mirrorNodeClient.postContractCall(callData, requestDetails);
    return contractCallResponse?.result ? prepend0x(contractCallResponse.result) : constants.EMPTY_HEX;
  }

  /**
   * Extracts the block number, hash or tag from a block parameter.
   * according to EIP-1898 (https://eips.ethereum.org/EIPS/eip-1898) block param can either be a string (blockNumber or Block Tag) or an object (blockHash or blockNumber)
   *
   * @param {string | object | null} blockParam - The block parameter (string, object, or null)
   * @returns {string | null} The extracted block number, hash or tag, or null if not provided
   * @private
   */
  private extractBlockParam(blockParam: string | object | null): string | null {
    if (!blockParam) {
      return null;
    }

    // is an object
    if (typeof blockParam === 'object') {
      // object has property blockNumber, example: { "blockNumber": "0x0" }
      const { blockNumber, blockHash } = blockParam as { blockNumber?: string; blockHash?: string };

      if (blockNumber != null) {
        return blockNumber;
      }

      if (blockHash != null) {
        return blockHash;
      }

      // if is an object but doesn't have blockNumber or blockHash, then it's an invalid blockParam
      throw predefined.INVALID_ARGUMENTS('neither block nor hash specified');
    }

    // if blockParam is a string, could be a blockNumber or blockTag or blockHash
    if (blockParam.length > 0) {
      return blockParam;
    }

    return null;
  }

  /**
   * Caps the block gas limit to a reasonable value.
   *
   * @param {string | undefined} gasString - The gas limit as a string
   * @returns {number | null} The capped gas limit as a number, or null if no valid gas limit could be determined
   * @private
   */
  private getCappedBlockGasLimit(gasString: string | undefined): number | null {
    if (!gasString) {
      // Return null and don't include in the mirror node call, as mirror is doing this estimation on the go.
      return null;
    }

    // Requests above the network's per-transaction gas limit fail with BUSY, so cap them instead.
    const maxTransactionGasLimit = ConfigService.get('MAX_TRANSACTION_GAS_LIMIT');
    const gas = Number.parseInt(gasString);
    if (gas > maxTransactionGasLimit) {
      this.logger.trace(
        `eth_call gas amount (%s) exceeds network limit, capping gas to %s`,
        gas,
        maxTransactionGasLimit,
      );
      return maxTransactionGasLimit;
    }

    return gas;
  }

  /**
   * Handles specific mirror node client errors.
   *
   * @param {MirrorNodeClientError} e - The mirror node client error
   * @returns {Promise<never>}
   * @private
   */
  private async handleMirrorNodeClientError(e: MirrorNodeClientError): Promise<never> {
    if (e.isContractRevert()) throw predefined.CONTRACT_REVERT(e.revertReason, e.data);
    if (e.isFailInvalid()) throw predefined.CONTRACT_REVERT(e.message, e.data);

    // For 400, treat it as an expected "could not simulate transaction" case and do not store additional logs.
    // For any other error or Mirror Node upstream server errors (429, 500, 502, 503, 504, etc.),
    // log the original error and throw COULD_NOT_SIMULATE_TRANSACTION to the upper layer for further handling logic
    if (e.statusCode !== 400) this.logger.error(e, 'Could not simulate transaction in the MirrorNode.');
    throw predefined.COULD_NOT_SIMULATE_TRANSACTION(e.detail || e.message);
  }

  /**
   * Prepares the call data for mirror node request.
   *
   * @param {IContractCallRequest} call - The original call request
   * @param {number | null} gas - The gas limit
   * @param {number | string | null | undefined} value - The value to send
   * @param {string | null} block - The block number or tag
   * @returns {IContractCallRequest} The prepared call data
   * @private
   */
  private prepareMirrorNodeCallData(
    call: IContractCallRequest,
    gas: number | null,
    value: number | string | null | undefined,
    block: string | null,
  ): IContractCallRequest {
    return {
      ...call,
      ...(gas !== null ? { gas } : {}),
      ...(value !== null ? { value } : {}),
      estimate: false,
      ...(block !== null ? { block } : {}),
    };
  }

  /**
   * Mirror REST account field for EIP-7702 code delegation (HIP-1340).
   * Returns 40 hex chars (no 0x) or null if missing/invalid.
   */
  private static delegationAddressFromMirrorAccount(entity: { delegation_address?: string } | null): string | null {
    const raw = entity?.delegation_address;
    if (typeof raw !== 'string' || raw === '' || !isValidEthereumAddress(raw)) {
      return null;
    }

    return strip0x(raw.toLowerCase());
  }
}
