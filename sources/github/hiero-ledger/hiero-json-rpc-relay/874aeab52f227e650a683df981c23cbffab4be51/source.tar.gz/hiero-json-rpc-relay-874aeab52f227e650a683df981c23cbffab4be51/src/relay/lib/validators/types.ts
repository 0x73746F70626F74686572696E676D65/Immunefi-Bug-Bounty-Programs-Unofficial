// SPDX-License-Identifier: Apache-2.0

import { ConfigService } from '../../../config-service/services';
import mainConstants from '../constants';
import { predefined } from '../errors/JsonRpcError';
import {
  type ICallTracerConfig,
  type IOpcodeLoggerConfig,
  type ITracerConfig,
  type ITracerConfigWrapper,
} from '../types';
import { type AuthorizationListTypes, validateAuthorizationList } from './authorizationList';
import * as Constants from './constants';
import { OBJECTS_VALIDATIONS, validateSchema, validateTracerConfigWrapper } from './objectTypes';
import { validateStateOverrideSet } from './stateOverride';
import { validateArray } from './utils';

export const TYPES = {
  address: {
    test: (param: unknown): boolean => new RegExp(Constants.BASE_HEX_REGEX + '{40}$').test(param as string),
    error: Constants.ADDRESS_ERROR,
  },
  addressFilter: {
    test: (param: unknown): boolean => {
      return Array.isArray(param)
        ? validateArray(param.flat(), 'address')
        : new RegExp(Constants.ADDRESS_REGEX).test(param as string);
    },
    error: `${Constants.ADDRESS_ERROR} or an array of addresses`,
  },
  array: {
    test: (param: unknown, innerType?: string): boolean => {
      return Array.isArray(param) ? validateArray(param, innerType) : false;
    },
    error: 'Expected Array',
  },
  blockHash: {
    test: (param: unknown): boolean => new RegExp(Constants.BASE_HEX_REGEX + '{64}$').test(param as string),
    error: Constants.BLOCK_HASH_ERROR,
  },
  blockNumber: {
    test: (param: unknown): boolean =>
      (/^0[xX]([1-9A-Fa-f][0-9A-Fa-f]{0,13}|0)$/.test(param as string) && Number.MAX_SAFE_INTEGER >= Number(param)) ||
      ['earliest', 'latest', 'pending', 'finalized', 'safe'].includes(param as string),
    error: Constants.BLOCK_NUMBER_ERROR,
  },
  boolean: {
    test: (param: unknown): boolean => param === true || param === false,
    error: 'Expected boolean type',
  },
  blockParams: {
    test: (param: unknown): boolean => {
      if (Object.prototype.toString.call(param) === '[object Object]') {
        if (Object.prototype.hasOwnProperty.call(param, 'blockHash')) {
          return validateSchema(OBJECTS_VALIDATIONS.blockHashObject, param);
        }
        return validateSchema(OBJECTS_VALIDATIONS.blockNumberObject, param);
      }
      return (
        (/^0[xX]([1-9A-Fa-f]+[0-9A-Fa-f]{0,13}|0)$/.test(param as string) &&
          Number.MAX_SAFE_INTEGER >= Number(param)) ||
        ['earliest', 'latest', 'pending', 'finalized', 'safe'].includes(param as string) ||
        new RegExp(Constants.BASE_HEX_REGEX + '{64}$').test(param as string)
      );
    },
    error: Constants.BLOCK_PARAMS_ERROR,
  },
  filter: {
    test: (param: unknown): boolean => {
      if (Object.prototype.toString.call(param) === '[object Object]') {
        const filter = param as { blockHash?: unknown; toBlock?: unknown; fromBlock?: unknown };
        if (filter.blockHash && (filter.toBlock || filter.fromBlock)) {
          throw predefined.INVALID_PARAMETER(0, "Can't use both blockHash and toBlock/fromBlock");
        }
        return validateSchema(OBJECTS_VALIDATIONS.filter, param);
      }

      return false;
    },
    error: `Expected FilterObject`,
  },
  hex: {
    test: (param: unknown): boolean => new RegExp(Constants.BASE_HEX_REGEX + '*$').test(param as string),
    error: Constants.DEFAULT_HEX_ERROR,
  },
  hexEvenLength: {
    test: (param: unknown): boolean =>
      new RegExp(Constants.BASE_HEX_REGEX + '*$').test(param as string) && !((param as string).length % 2),
    error: Constants.EVEN_HEX_ERROR,
  },
  hex64: {
    test: (param: unknown): boolean => new RegExp(Constants.BASE_HEX_REGEX + '{1,64}$').test(param as string),
    error: Constants.HASH_ERROR,
  },
  topicHash: {
    test: (param: unknown): boolean =>
      new RegExp(Constants.BASE_HEX_REGEX + '{64}$').test(param as string) || param === null,
    error: Constants.TOPIC_HASH_ERROR,
  },
  rewardPercentiles: {
    test: (param: unknown): boolean =>
      Array.isArray(param) &&
      param.length <= mainConstants.FEE_HISTORY_REWARD_PERCENTILES_MAX_SIZE &&
      param.every(
        (element) => typeof element === 'number' && Number.isFinite(element) && element >= 0 && element <= 100,
      ),
    error: Constants.REWARD_PERCENTILES_ERROR,
  },
  topics: {
    test: (param: unknown): boolean => {
      if (!Array.isArray(param) || param.length > mainConstants.LOG_TOPICS_MAX_POSITIONS) return false;
      const maxSubTopics = ConfigService.get('ETH_GET_LOGS_SUB_TOPICS_LIMIT');
      if (param.some((position) => Array.isArray(position) && position.length > maxSubTopics)) {
        return false;
      }
      return validateArray(param.flat(), 'topicHash');
    },
    get error(): string {
      return Constants.topicsError(ConfigService.get('ETH_GET_LOGS_SUB_TOPICS_LIMIT'));
    },
  },
  transaction: {
    test: (param: unknown): boolean => {
      if (Object.prototype.toString.call(param) === '[object Object]') {
        if (!validateSchema(OBJECTS_VALIDATIONS.transaction, param)) return false;
        // Apply the EIP-7702 business rules only when the caller sets an explicit transaction type.
        // A Transaction Object (e.g. eth_call/eth_estimateGas params) often omits `type`; its
        // authorizationList is still structurally validated by the schema above, and the type is
        // resolved downstream, so the type-vs-list consistency check must not fire here.
        const tx = param as { type?: unknown; authorizationList?: AuthorizationListTypes | null };
        if (tx.type != null) {
          validateAuthorizationList(Number(tx.type), tx.authorizationList);
        }
        return true;
      }

      return false;
    },
    error: 'Expected TransactionObject',
  },
  transactionHash: {
    test: (param: unknown): boolean => new RegExp(Constants.BASE_HEX_REGEX + '{64}$').test(param as string),
    error: Constants.TRANSACTION_HASH_ERROR,
  },
  tracerType: {
    test: (param: unknown): param is Constants.TracerType =>
      typeof param === 'string' &&
      Object.values(Constants.TracerType)
        .map((tracerType) => tracerType.toString())
        .includes(param),
    error: 'Expected TracerType',
  },
  callTracerConfig: {
    test: (param: unknown): param is ICallTracerConfig => {
      if (param && typeof param === 'object') {
        return validateSchema(OBJECTS_VALIDATIONS.callTracerConfig, param);
      }
      return false;
    },
    error: 'Expected CallTracerConfig',
  },
  opcodeLoggerConfig: {
    test: (param: unknown): param is IOpcodeLoggerConfig => {
      if (param && typeof param === 'object') {
        return validateSchema(OBJECTS_VALIDATIONS.opcodeLoggerConfig, param);
      }
      return false;
    },
    error: 'Expected OpcodeLoggerConfig',
  },
  tracerConfig: {
    test: (param: unknown): param is ITracerConfig => {
      if (param && typeof param === 'object') {
        const isEmptyObject = Object.keys(param).length === 0;
        const isValidCallTracerConfig = TYPES.callTracerConfig.test(param);
        const isValidOpcodeLoggerConfig = TYPES.opcodeLoggerConfig.test(param);
        return isEmptyObject || isValidCallTracerConfig || isValidOpcodeLoggerConfig;
      }
      return false;
    },
    error: 'Expected TracerConfig',
  },
  tracerConfigWrapper: {
    test: (param: unknown): param is ITracerConfigWrapper => {
      if (param && typeof param === 'object') {
        return validateTracerConfigWrapper(param);
      }
      return false;
    },
    error: 'Expected TracerConfigWrapper which contains a valid TracerType and/or TracerConfig',
  },
  blockOverride: {
    // Accepted by geth, but the mirror node's contracts/call API has no equivalent, so a request
    // relying on it would silently execute against the real block context.
    test: (): boolean => false,
    error: 'Block overrides are not supported',
  },
  stateOverride: {
    test: (param: unknown): boolean => {
      validateStateOverrideSet(param);
      return true;
    },
    error: 'Expected StateOverride object keyed by address',
  },
  yParityHex: {
    test: (param: unknown): boolean => /^0x([0-9a-fA-F]?){1,2}$/.test(param as string),
    error: 'Expected 0x-prefixed yParity value (0 for even, 1 for odd)',
  },
  authorizationListEntry: {
    test: (param: unknown): boolean => {
      if (param && typeof param === 'object') {
        return validateSchema(OBJECTS_VALIDATIONS.authorizationListEntry, param);
      }
      return false;
    },
    error: 'Expected valid AuthorizationListEntry object',
  },
} satisfies {
  [paramTypeName: string]: {
    test: (param: unknown) => boolean;
    error: string;
  };
};
