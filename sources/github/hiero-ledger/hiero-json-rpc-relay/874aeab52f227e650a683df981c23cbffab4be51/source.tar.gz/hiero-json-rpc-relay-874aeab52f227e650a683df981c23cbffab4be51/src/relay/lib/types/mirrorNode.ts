// SPDX-License-Identifier: Apache-2.0

import type { BigNumber } from '@hiero-ledger/sdk/lib/Transfer';

import type { AccessListEntry, AuthorizationListEntry } from '../model';

export interface IAccountInfo {
  /**
   * Account ID string in the form `shard.realm.num`
   */
  account: string;
  /**
   * RFC4648 no-padding base32 encoded string of the account's alias.
   */
  alias: string | null;
  balance?: IAccountBalance;
  created_timestamp?: string;
  deleted?: boolean;
  ethereum_nonce?: number;
  evm_address?: string;
  memo?: string;
  receiver_sig_required?: boolean;
  transactions?: IMirrorNodeTransactionRecord[];
  links?: IMirrorNodeLinks;
}

export interface IAccountBalance {
  balance: number;
  timestamp?: string;
  tokens?: { token_id: string; balance: number }[];
}

/** A single mirror node query parameter value; arrays are serialized as repeated `key=value` pairs. */
export type QueryParamValue = string | number | boolean | string[] | null | undefined;

/** Mutable bag of mirror node query parameters, serialized by `MirrorNodeClient.getQueryParams`. */
export type QueryParamObject = Record<string, QueryParamValue>;

export interface ILimitOrderParams {
  limit?: number;
  order?: string;
}

export interface IAccountRequestParams {
  timestamp?: string;
  transactions?: boolean;
  [key: string]: string | boolean | number | undefined; // Allow dynamic params
}

export interface IContractResultsParams {
  blockHash?: string;
  blockNumber?: number;
  from?: string;
  internal?: boolean;
  timestamp?: string | string[];
  transactionIndex?: number;
}

export interface IContractLogsResultsParams {
  'transaction.hash'?: string;
  index?: number;
  timestamp?: string | string[];
  topic0?: string | string[];
  topic1?: string | string[];
  topic2?: string | string[];
  topic3?: string | string[];
}

/** A single storage slot on the mirror node's `state`/`state_diff` arrays. */
export interface IStorageEntry {
  key: string;
  value: string;
}

/**
 * Per-address override in the mirror node's wire format: an array entry carrying its own
 * `address`, snake_case field names, and storage as key/value pairs rather than a map.
 */
export interface IStateOverride {
  address: string;
  balance?: string;
  code?: string;
  nonce?: string;
  state?: IStorageEntry[];
  state_diff?: IStorageEntry[];
}

export interface IContractCallRequest {
  block?: string;
  estimate?: boolean;
  from?: string;
  to?: string | null;
  gas?: number | string;
  gasPrice?: number | string;
  value?: number | string | null;
  data?: string | null;
  input?: string;
  accessList?: AccessListEntry[];
  authorizationList?: AuthorizationListEntry[];
  state_overrides?: IStateOverride[];
}

export interface IContractCallResponse {
  result?: string;
  errorMessage?: string;
  statusCode?: number;
  _status?: {
    messages: Array<{ message: string; detail?: string; data?: string }>;
  };
}

export interface IAssessedCustomFee {
  amount: number;
  collector_account_id: string;
  effective_payer_account_ids: string[];
  token_id: string;
}

export interface INftTransfer {
  is_approval: boolean;
  receiver_account_id: string;
  sender_account_id: string;
  serial_number: number;
  token_id: string;
}

export interface IStakingRewardTransfer {
  account: number;
  amount: number;
}

export interface ITokenTransfer {
  token_id: string;
  account: string;
  amount: number;
  is_approval: boolean;
}

export interface ITransfer {
  account: string;
  amount: number;
  is_approval: boolean;
}

export interface IMirrorNodeTransactionRecord {
  assessed_custom_fees: IAssessedCustomFee[];
  bytes: string | null;
  charged_tx_fee: number;
  consensus_timestamp: string;
  entity_id: string | null;
  max_fee: string;
  memo_base64: string | null;
  name: string;
  nft_transfers: INftTransfer[];
  node: string;
  nonce: number;
  parent_consensus_timestamp: string | null;
  result: string;
  scheduled: boolean;
  staking_reward_transfers: IStakingRewardTransfer[];
  transaction_hash: string;
  transaction_id: string;
  token_transfers: ITokenTransfer[];
  transfers: ITransfer[];
  valid_duration_seconds: string | null;
  valid_start_timestamp: string;
}

export interface ITimestamp {
  from: string;
  to: string;
}

export interface IExchangeRate {
  cent_equivalent: number;
  expiration_time: number;
  hbar_equivalent: number;
}

export interface INetworkExchangeRate {
  current_rate: IExchangeRate;
  next_rate: IExchangeRate;
  timestamp: string;
}

export interface INetworkFee {
  gas: number;
  transaction_type: string;
}

export interface INetworkFees {
  fees: INetworkFee[];
  timestamp: string;
}

export interface IMirrorNodeLinks {
  next: string | null;
}

export interface MirrorNodeBlocksPage {
  blocks: MirrorNodeBlock[];
  links?: IMirrorNodeLinks;
}

export interface IAccountBalancesPage {
  timestamp: string | null;
  balances: { account: string; balance: number; tokens?: { token_id: string; balance: number }[] }[];
  links?: IMirrorNodeLinks;
}

export interface ITransactionsPage {
  transactions: IMirrorNodeTransactionRecord[];
  links?: IMirrorNodeLinks;
}

export interface IContractStateEntry {
  address: string;
  contract_id: string;
  timestamp: string;
  slot: string;
  value: string;
}

export interface IContractStatePage {
  state: IContractStateEntry[];
  links?: IMirrorNodeLinks;
}

export interface IMirrorNodeContract {
  contract_id: string;
  evm_address: string;
  created_timestamp?: string;
  runtime_bytecode?: string;
  bytecode?: string;
  timestamp?: ITimestamp;
  nonce?: number;
}
export interface IMirrorNodeEntity {
  evm_address?: string;
  contract_id?: string;
  created_timestamp?: string;
  consensus_timestamp?: string;
  delegation_address?: string;
  runtime_bytecode?: string;
  nonce?: number;
  balance?: IAccountBalance;
  ethereum_nonce?: number;
}

export interface LatestBlockNumberTimestamp {
  blockNumber: string | null;
  timeStampTo: string;
}

export interface MirrorNodeBlock {
  count: number;
  gas_used?: number;
  hapi_version: string;
  hash: string;
  logs_bloom: string;
  name: string;
  number: number;
  previous_hash: string;
  size: number;
  timestamp: ITimestamp;
}

export class MirrorNodeTransactionRecord {
  public readonly assessed_custom_fees: IAssessedCustomFee[];
  public readonly bytes: string | null;
  public readonly charged_tx_fee: number;
  public readonly consensus_timestamp: string;
  public readonly entity_id: string | null;
  public readonly max_fee: string;
  public readonly memo_base64: string | null;
  public readonly name: string;
  public readonly nft_transfers: INftTransfer[];
  public readonly node: string;
  public readonly nonce: number;
  public readonly parent_consensus_timestamp: string | null;
  public readonly result: string;
  public readonly scheduled: boolean;
  public readonly staking_reward_transfers: IStakingRewardTransfer[];
  public readonly transaction_hash: string;
  public readonly transaction_id: string;
  public readonly token_transfers: ITokenTransfer[];
  public readonly transfers: ITransfer[];
  public readonly valid_duration_seconds: string | null;
  public readonly valid_start_timestamp: string;

  constructor(transactionRecord: IMirrorNodeTransactionRecord) {
    this.assessed_custom_fees = transactionRecord.assessed_custom_fees;
    this.bytes = transactionRecord.bytes;
    this.charged_tx_fee = transactionRecord.charged_tx_fee;
    this.consensus_timestamp = transactionRecord.consensus_timestamp;
    this.entity_id = transactionRecord.entity_id;
    this.max_fee = transactionRecord.max_fee;
    this.memo_base64 = transactionRecord.memo_base64;
    this.name = transactionRecord.name;
    this.nft_transfers = transactionRecord.nft_transfers;
    this.node = transactionRecord.node;
    this.nonce = transactionRecord.nonce;
    this.parent_consensus_timestamp = transactionRecord.parent_consensus_timestamp;
    this.result = transactionRecord.result;
    this.scheduled = transactionRecord.scheduled;
    this.staking_reward_transfers = transactionRecord.staking_reward_transfers;
    this.transaction_hash = transactionRecord.transaction_hash;
    this.transaction_id = transactionRecord.transaction_id;
    this.token_transfers = transactionRecord.token_transfers;
    this.transfers = transactionRecord.transfers;
    this.valid_duration_seconds = transactionRecord.valid_duration_seconds;
    this.valid_start_timestamp = transactionRecord.valid_start_timestamp;
  }
}

/**
 * Common contract-result fields shared by every mirror node contract-result response, and the exact
 * shape returned by the `/contracts/{contractIdOrAddress}/results` (per-contract list) endpoint.
 */
export interface MirrorNodeContractResultBase {
  /** The address involved in the contract call. */
  address: string | null;
  /** The amount of hbars or tokens transferred. */
  amount: string | number | BigNumber | null;
  /** Authorization list for EIP-7702 transactions. */
  authorization_list?: AuthorizationListEntry[] | null;
  /** The bloom filter for the logs generated by the contract execution. */
  bloom: string;
  /** The raw result of the contract call. */
  call_result: string;
  /** The unique identifier of the contract. */
  contract_id: string;
  /** List of contract IDs created during the transaction. */
  created_contract_ids: string[];
  /** The error message if the contract execution failed, otherwise null. */
  error_message: string | null;
  /** The address that initiated the contract call. */
  from: string;
  /** The input parameters for the contract function call, encoded as a hex string. */
  function_parameters: string;
  /** The total amount of gas consumed during execution. */
  gas_consumed: number;
  /** The maximum amount of gas allowed for the transaction. */
  gas_limit: number | null;
  /** The actual amount of gas used by the transaction. */
  gas_used: number | null;
  /** The consensus timestamp of the transaction. */
  timestamp: string;
  /** The address of the contract being called. */
  to: string | null;
  /** The transaction hash. */
  hash: string;
}

/**
 * Represents a contract result as returned by the Hedera Mirror Node `/contracts/results` endpoint.
 */
export interface MirrorNodeContractResult extends MirrorNodeContractResultBase {
  /** The hash of the block containing the transaction. */
  block_hash: string;
  /** The block number containing the transaction. */
  block_number: number | null;
  /** The result of the contract execution, typically as a hex string. */
  result: string;
  /** The index of the transaction within the block. */
  transaction_index: number | null;
  /** The status of the transaction (e.g., "SUCCESS", "FAIL"). */
  status: string;
  /** The failed contract init code, if applicable, otherwise null. */
  failed_initcode: string | null;
  /** The access list for EIP-2930 transactions. MirrorNode v0.156+ returns this as an array of objects. */
  access_list: { address: string; storage_keys: string[] }[] | null;
  /** The total gas used in the block. */
  block_gas_used: number;
  /** The chain ID of the network. */
  chain_id: string | null;
  /** The gas price used for the transaction. */
  gas_price: string | null;
  /** The maximum fee per gas for EIP-1559 transactions. */
  max_fee_per_gas: string | null;
  /** The maximum priority fee per gas for EIP-1559 transactions. */
  max_priority_fee_per_gas: string | null;
  /** The ECDSA signature r value. */
  r: string | null;
  /** The ECDSA signature s value. */
  s: string | null;
  /** The transaction type (e.g., 0 for legacy, 2 for EIP-1559). */
  type: number | null;
  /** The ECDSA signature recovery id. */
  v: number | null;
  /** The account nonce for the transaction. */
  nonce: number;
  /** Authorization list for EIP-7702 transactions. */
  authorization_list?: AuthorizationListEntry[] | null;
}

/**
 * Represents a log emitted by a contract execution as returned by the Hedera Mirror Node.
 */
export interface MirrorNodeContractLog {
  /** The address of the contract that emitted the log. */
  address: string;
  /** The bloom filter for the log. */
  bloom: string;
  /** The unique identifier of the contract. */
  contract_id: string;
  /** The data emitted with the log. */
  data: string;
  /** The index of the log within the transaction. */
  index: number;
  /** The topics associated with the log. */
  topics: string[];
  /** The hash of the block containing the log. */
  block_hash: string;
  /** The block number containing the log. */
  block_number: number;
  /** The consensus timestamp of the log. */
  timestamp: string;
  /** The transaction hash. */
  transaction_hash: string;
  /** The index of the transaction within the block. */
  transaction_index: number;
}

/**
 * Represents a single contract state change as returned by the Hedera Mirror Node on a detailed
 * contract result (`/contracts/results/{transactionIdOrHash}`).
 */
export interface MirrorNodeContractResultStateChange {
  /** The address of the contract whose state changed. */
  address: string;
  /** The unique identifier of the contract. */
  contract_id: string;
  /** The storage slot that changed. */
  slot: string;
  /** The value read from the slot. */
  value_read: string | null;
  /** The value written to the slot. */
  value_written: string | null;
}

/**
 * Represents a log nested in a detailed contract result returned by the Hedera Mirror Node
 * `/contracts/results/{transactionIdOrHash}` endpoint.
 */
export interface MirrorNodeContractResultLog {
  /** The address of the contract that emitted the log. */
  address: string;
  /** The bloom filter for the log. */
  bloom: string;
  /** The unique identifier of the contract. */
  contract_id: string;
  /** The data emitted with the log. */
  data: string;
  /** The index of the log within the transaction. */
  index: number;
  /** The topics associated with the log. */
  topics: string[];
}

/**
 * Represents a contract result as returned by the Hedera Mirror Node `/contracts/results/{transactionIdOrHash}` endpoint.
 */
export interface MirrorNodeContractResultDetails extends MirrorNodeContractResult {
  /** The logs emitted during the contract execution. */
  logs: MirrorNodeContractResultLog[];
  /** The contract state changes produced by the execution. */
  state_changes: MirrorNodeContractResultStateChange[];
}

/**
 * A contract result as consumed by the transaction-receipt builders: a {@link MirrorNodeContractResult}
 * plus an optional legacy `root` field.
 */
export interface MirrorNodeContractResultReceipt extends MirrorNodeContractResult {
  /**
   * Legacy (pre-Byzantium) receipt state root. The Hedera Mirror Node does not return this field; the
   * receipt builders read it defensively and fall back to a default, so it is optional.
   */
  root?: string;
}

/**
 * A paginated page of contract results as returned by the Hedera Mirror Node
 * `/contracts/{contractIdOrAddress}/results` endpoint.
 */
export interface MirrorNodeContractResultsPage {
  /** The contract results on this page. */
  results: MirrorNodeContractResultBase[];
  /** Pagination links; `next` is the path to the next page, or null when there are no more pages. */
  links: { next: string | null };
}

/**
 * Represents an action performed by a contract on the Hedera Mirror Node.
 */
export interface ContractAction {
  /** The depth of the call in the call stack. */
  call_depth: number;
  /** The type of operation performed (e.g., 'CALL'). */
  call_operation_type: 'CALL' | string;
  /** The type of call (e.g., 'CALL'). */
  call_type: 'CALL' | string;
  /** The Hedera account or contract ID of the caller (e.g., '0.0.2661815'). */
  caller: string;
  /** The type of the caller, either 'ACCOUNT', 'CONTRACT', or another string. */
  caller_type: 'ACCOUNT' | 'CONTRACT' | string;
  /** The hexadecimal address of the sender. */
  from: string;
  /** The amount of gas provided for the call. */
  gas: number;
  /** The amount of gas actually used during the call. */
  gas_used: number;
  /** The index of the action within the transaction. */
  index: number;
  /** The hex-encoded input data for the call. */
  input: string;
  /** The Hedera account or contract ID of the recipient (e.g., '0.0.5950145'). */
  recipient: string;
  /** The type of the recipient, either 'ACCOUNT', 'CONTRACT', or another string. */
  recipient_type: 'ACCOUNT' | 'CONTRACT' | string;
  /** The result data of the call, typically hex-encoded. */
  result_data: string;
  /** The type of result data (e.g., 'OUTPUT'). */
  result_data_type: 'OUTPUT' | string;
  /** The timestamp of the action, as a string. */
  timestamp: string;
  /** The hexadecimal address of the recipient. */
  to: string;
  /** The value transferred in the call. */
  value: number;
}
