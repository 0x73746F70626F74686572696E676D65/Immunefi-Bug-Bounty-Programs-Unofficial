// SPDX-License-Identifier: Apache-2.0

import type { Logger } from 'pino';
import type { RedisClientType } from 'redis';

import { ConfigService } from '../../../../../config-service/services';
import { Utils } from '../../../../utils';
import type { ICacheClient } from '../ICacheClient';

/**
 * A class that provides caching functionality using Redis.
 */
export class RedisCache implements ICacheClient {
  /**
   * Prefix used to namespace all keys managed by this cache.
   *
   * @remarks
   * Using a prefix allows efficient scanning and cleanup of related keys
   * without interfering with keys from other services (e.g., pending:, hbar-limit:).
   */
  private static readonly CACHE_KEY_PREFIX = 'cache:';

  /**
   * Configurable options used when initializing the cache.
   *
   * @private
   */
  private readonly options = {
    // Max time to live in ms, for items before they are considered stale.
    ttl: ConfigService.get('CACHE_TTL'),
  };

  /**
   * The logger used for logging all output from this class.
   * @private
   */
  protected readonly logger: Logger;

  /**
   * The Redis client.
   * @private
   */
  private readonly client: RedisClientType;

  /**
   * Creates an instance of `RedisCache`.
   *
   * @param {Logger} logger - The logger instance.
   * @param {RedisClientType} client
   */
  public constructor(logger: Logger, client: RedisClientType) {
    this.logger = logger;
    this.client = client;
  }

  /**
   * Adds the cache prefix to a key.
   *
   * @param key - The key to prefix.
   * @returns The prefixed key.
   * @private
   */
  private prefixKey(key: string): string {
    return `${RedisCache.CACHE_KEY_PREFIX}${key}`;
  }

  /**
   * Alias for the `get` method.
   *
   * @param key - The key associated with the cached value.
   * @param callingMethod - The name of the method calling the cache.
   * @returns The cached value if found, otherwise null.
   *
   * @deprecated use `get` instead.
   */
  public getAsync<T = unknown>(key: string, callingMethod: string): Promise<T | null> {
    return this.get<T>(key, callingMethod);
  }

  /**
   * Retrieves a value from the cache.
   *
   * @param key - The cache key.
   * @param callingMethod - The name of the calling method.
   * @returns The cached value or null if not found.
   */
  async get<T = unknown>(key: string, callingMethod: string): Promise<T | null> {
    const prefixedKey = this.prefixKey(key);
    const result = await this.client.get(prefixedKey);
    if (result) {
      if (this.logger.isLevelEnabled('trace')) {
        const censoredKey = key.replace(Utils.IP_ADDRESS_REGEX, '<REDACTED>');
        const censoredValue = result.replace(/"ipAddress":"[^"]+"/, '"ipAddress":"<REDACTED>"');
        this.logger.trace(`Returning cached value %s:%s on %s call`, censoredKey, censoredValue, callingMethod);
      }
      // TODO: add metrics
      return JSON.parse(result) as T;
    }
    return null;
  }

  /**
   * Stores a value in the cache.
   *
   * @param key - The cache key.
   * @param value - The value to be cached.
   * @param callingMethod - The name of the calling method.
   * @param ttl - The time-to-live (expiration) of the cache item in milliseconds.
   * @returns A Promise that resolves when the value is cached.
   */
  async set(key: string, value: unknown, callingMethod: string, ttl?: number): Promise<void> {
    const prefixedKey = this.prefixKey(key);
    const serializedValue = JSON.stringify(value);
    const resolvedTtl = ttl ?? this.options.ttl; // in milliseconds
    if (resolvedTtl > 0) {
      await this.client.set(prefixedKey, serializedValue, { PX: resolvedTtl });
    } else {
      await this.client.set(prefixedKey, serializedValue);
    }

    if (this.logger.isLevelEnabled('trace')) {
      const censoredKey = key.replace(Utils.IP_ADDRESS_REGEX, '<REDACTED>');
      const censoredValue = serializedValue.replace(/"ipAddress":"[^"]+"/, '"ipAddress":"<REDACTED>"');
      const message = `Caching ${censoredKey}:${censoredValue} on ${callingMethod} for ${
        resolvedTtl > 0 ? `${resolvedTtl} ms` : 'indefinite time'
      }`;
      this.logger.trace(`%s`, message);
    }
    // TODO: add metrics
  }

  /**
   * Deletes a value from the cache.
   *
   * @param key - The cache key.
   * @param callingMethod - The name of the calling method.
   * @returns A Promise that resolves when the value is deleted from the cache.
   */
  async delete(key: string, callingMethod: string): Promise<void> {
    const prefixedKey = this.prefixKey(key);
    await this.client.del(prefixedKey);
    this.logger.trace(`delete cache for %s on %s call`, key, callingMethod);
    // TODO: add metrics
  }

  /**
   * Increments a value in the cache.
   *
   * @param key The key to increment
   * @param amount The amount to increment by
   * @param callingMethod The name of the calling method
   * @returns The value of the key after incrementing
   */
  async incrBy(key: string, amount: number, callingMethod: string): Promise<number> {
    const prefixedKey = this.prefixKey(key);
    const result = await this.client.incrBy(prefixedKey, amount);
    this.logger.trace(`incrementing %s by %s on %s call`, key, amount, callingMethod);
    return result;
  }

  /**
   * Retrieves a range of elements from a list in the cache.
   *
   * @param key The key of the list
   * @param start The start index
   * @param end The end index
   * @param callingMethod The name of the calling method
   * @returns The list of elements in the range
   */
  async lRange<T = unknown>(key: string, start: number, end: number, callingMethod: string): Promise<T[]> {
    const prefixedKey = this.prefixKey(key);
    const result = await this.client.lRange(prefixedKey, start, end);
    this.logger.trace(`retrieving range [%s:%s] from %s on %s call`, start, end, key, callingMethod);
    return result.map((item) => JSON.parse(item) as T);
  }

  /**
   * Pushes a value to the end of a list in the cache.
   *
   * @param key The key of the list
   * @param value The value to push
   * @param callingMethod The name of the calling method
   * @returns The length of the list after pushing
   */
  async rPush(key: string, value: unknown, callingMethod: string): Promise<number> {
    const prefixedKey = this.prefixKey(key);
    const serializedValue = JSON.stringify(value);
    const result = await this.client.rPush(prefixedKey, serializedValue);
    this.logger.trace(`pushing %s to %s on %s call`, serializedValue, key, callingMethod);

    return result;
  }

  /**
   * Retrieves all keys matching a pattern.
   * @param pattern The pattern to match
   * @param callingMethod The name of the calling method
   * @returns The list of keys matching the pattern (without the cache prefix)
   */
  async keys(pattern: string, callingMethod: string): Promise<string[]> {
    const prefixedPattern = this.prefixKey(pattern);
    const result = await this.client.keys(prefixedPattern);
    this.logger.trace(`retrieving keys matching %s on %s call`, pattern, callingMethod);
    // Remove the prefix from the returned keys
    return result.map((key) => key.substring(RedisCache.CACHE_KEY_PREFIX.length));
  }

  /**
   * Clears only the cache keys (those with cache: prefix).
   * Uses pipelining for efficient bulk deletion with UNLINK (non-blocking).
   *
   * @returns {Promise<void>} A Promise that resolves when the cache is cleared.
   */
  async clear(): Promise<void> {
    const keysToDelete = await this.client.keys(`${RedisCache.CACHE_KEY_PREFIX}*`);

    if (keysToDelete.length > 0) {
      // Use pipeline for efficient bulk deletion
      const pipeline = this.client.multi();

      for (const key of keysToDelete) {
        pipeline.unlink(key); // UNLINK is non-blocking version of DEL
      }

      await pipeline.exec();

      this.logger.trace(`Cleared %s cache keys`, keysToDelete.length);
    }
  }
}
