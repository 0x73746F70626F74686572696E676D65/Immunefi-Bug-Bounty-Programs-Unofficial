// SPDX-License-Identifier: Apache-2.0

import parse from 'co-body';
import Koa from 'koa';
import { type Logger } from 'pino';
import { type Histogram, type Registry } from 'prom-client';

import { ConfigService } from '../../config-service/services';
import { METRICS, MetricsFactory } from '../../metrics';
import { JsonRpcError, predefined, type Relay } from '../../relay';
import { methodConfiguration } from '../../relay/lib/config/methodConfiguration';
import { IPRateLimiterService } from '../../relay/lib/services';
import { type MethodRateLimitConfiguration, type RateLimitStore } from '../../relay/lib/types';
import { RequestDetails } from '../../relay/lib/types';
import { countBatchAddresses, HTTP_BATCH_ADDRESS_METHODS } from '../../relay/lib/utils/addressLimit';
import { isRequestAbortedError, requestAbortReason } from '../../relay/lib/utils/requestAbort';
import { translateRpcErrorToHttpStatus } from './lib/httpErrorMapper';
import { type IJsonRpcRequest } from './lib/IJsonRpcRequest';
import { spec } from './lib/RpcError';
import { type IJsonRpcResponse, jsonRespError, jsonRespResult } from './lib/RpcResponse';
import {
  getBatchRequestsEnabled,
  getBatchRequestsMaxSize,
  getDefaultRateLimit,
  getRequestIdIsOptional,
} from './lib/utils';

const INVALID_REQUEST = 'INVALID REQUEST';
const REQUEST_ID_HEADER_NAME = 'X-Request-Id';
const responseSuccessStatusCode = '200';
const BATCH_REQUEST_METHOD_NAME = 'batch_request';
const RPC_HTTP_API = new Set(ConfigService.get('RPC_HTTP_API'));
const CLIENT_DISCONNECTED_ABORT_REASON = 'The client closed the connection before the response was written';
const CLIENT_DISCONNECTED = 'CLIENT DISCONNECTED';

export default class KoaJsonRpc {
  private readonly methodConfig: MethodRateLimitConfiguration;
  private readonly defaultRateLimit: number = getDefaultRateLimit();
  private readonly limit: string;
  private readonly rateLimiter: IPRateLimiterService;
  private readonly koaApp: Koa<Koa.DefaultState, Koa.DefaultContext>;
  private readonly requestIdIsOptional: boolean = getRequestIdIsOptional(); // default to false
  private readonly batchRequestsMaxSize: number = getBatchRequestsMaxSize(); // default to 100
  private readonly methodResponseHistogram: Histogram;
  private readonly relay: Relay;
  private readonly logger: Logger;

  constructor(
    logger: Logger,
    register: Registry,
    relay: Relay,
    rateLimitStore: RateLimitStore,
    opts?: { limit: string | null },
  ) {
    this.koaApp = new Koa();
    this.logger = logger;
    this.methodConfig = methodConfiguration;
    this.limit = opts?.limit ?? '1mb';
    this.rateLimiter = new IPRateLimiterService(rateLimitStore, register);
    this.relay = relay;

    this.methodResponseHistogram = new MetricsFactory(register).histogram(METRICS.server.methodResult);
  }

  rpcApp(): (ctx: Koa.ParameterizedContext) => Promise<void> {
    return async (ctx: Koa.ParameterizedContext) => {
      const requestId = ctx.state.reqId;
      ctx.set(REQUEST_ID_HEADER_NAME, requestId);

      if (ctx.request.method !== 'POST') {
        ctx.body = jsonRespError(null, spec.InvalidRequest, requestId);
        ctx.status = 400;
        ctx.state.status = `${ctx.status} (${INVALID_REQUEST})`;
        return;
      }

      const { signal: abortSignal, release: releaseAbortSignal } = this.createRequestAbortSignal(ctx);
      try {
        let body: unknown | unknown[];
        try {
          body = await parse.json(ctx, { limit: this.limit });
        } catch {
          ctx.body = jsonRespError(null, spec.ParseError, requestId);
          ctx.status = 400;
          return;
        }
        if (Array.isArray(body)) {
          await this.handleBatchRequest(ctx, body, requestId, abortSignal);
        } else {
          await this.handleSingleRequest(ctx, body, requestId, abortSignal);
        }
      } catch (error) {
        if (!isRequestAbortedError(error)) {
          throw error;
        }

        this.logger.debug(`Request abandoned by the client: requestId=%s, method=%s`, requestId, ctx.state.methodName);
        ctx.respond = false;
        ctx.state.status = CLIENT_DISCONNECTED;
        ctx.state.clientDisconnected = true;
      } finally {
        releaseAbortSignal();
      }
    };
  }

  /**
   * Creates the request-scoped {@link AbortSignal} that is aborted when the client disconnects before the
   * response has been written.
   *
   * @param ctx - The Koa context of the request being served.
   * @returns The signal passed to the relay for this request, and a `release` callback.
   */
  private createRequestAbortSignal(ctx: Koa.ParameterizedContext): { signal: AbortSignal; release: () => void } {
    const abortController = new AbortController();

    const onResponseClose = (): void => {
      if (!ctx.res.writableFinished) {
        abortController.abort(requestAbortReason(CLIENT_DISCONNECTED_ABORT_REASON));
      }
    };
    ctx.res.once('close', onResponseClose);

    return { signal: abortController.signal, release: () => ctx.res.off('close', onResponseClose) };
  }

  private async handleSingleRequest(
    ctx: Koa.ParameterizedContext,
    body: unknown,
    requestId: string,
    abortSignal: AbortSignal,
  ): Promise<void> {
    let response: IJsonRpcResponse;
    if (!this.hasValidJsonRpcId(body)) {
      response = jsonRespError(null, spec.InvalidRequest, requestId);
    } else if (!this.isValidJsonRpcRequest(body)) {
      response = jsonRespError(body.id, spec.InvalidRequest, requestId);
    } else {
      ctx.state.methodName = body.method;
      response = await this.getRequestResult(body, ctx.ip, requestId, abortSignal);
    }

    ctx.body = response;

    if ('error' in response) {
      const { statusErrorCode, statusErrorMessage } = translateRpcErrorToHttpStatus(response.error);

      ctx.status = statusErrorCode;
      ctx.state.status = `${ctx.status} (${statusErrorMessage})`;
    }
  }

  private async handleBatchRequest(
    ctx: Koa.ParameterizedContext,
    body: unknown[],
    requestId: string,
    abortSignal: AbortSignal,
  ): Promise<void> {
    // verify that batch requests are enabled
    if (!getBatchRequestsEnabled()) {
      ctx.body = jsonRespError(null, predefined.BATCH_REQUESTS_DISABLED, requestId);
      ctx.status = 400;
      ctx.state.status = `${ctx.status} (${INVALID_REQUEST})`;
      return;
    }

    // verify max batch size
    if (body.length > this.batchRequestsMaxSize) {
      const responseBody = jsonRespError(
        null,
        predefined.BATCH_REQUESTS_AMOUNT_MAX_EXCEEDED(body.length, this.batchRequestsMaxSize),
        requestId,
      );
      ctx.body = Array(body.length).fill(responseBody); // The response object is intentionally shared by reference!
      ctx.status = 200;
      ctx.state.status = `${ctx.status} (${INVALID_REQUEST})`;
      return;
    }

    // reject the whole batch when the caller-supplied address total across all entries exceeds the shared cap
    const maxAddressesPerRequest = ConfigService.get('MAX_ADDRESSES_PER_REQUEST');
    const addressTotal = countBatchAddresses(body, HTTP_BATCH_ADDRESS_METHODS);
    if (addressTotal > maxAddressesPerRequest) {
      const responseBody = jsonRespError(
        null,
        predefined.BATCH_REQUESTS_ADDRESS_TOTAL_EXCEEDED(addressTotal, maxAddressesPerRequest),
        requestId,
      );
      ctx.body = Array(body.length).fill(responseBody); // The response object is intentionally shared by reference!
      ctx.status = 200;
      ctx.state.status = `${ctx.status} (${INVALID_REQUEST})`;
      return;
    }

    ctx.state.methodName = BATCH_REQUEST_METHOD_NAME;

    // we do the requests in parallel to save time, but we need to keep track of the order of the responses (since the id might be optional)
    const promises: Promise<IJsonRpcResponse>[] = body.map(async (item) => {
      if (!this.hasValidJsonRpcId(item)) return jsonRespError(null, spec.InvalidRequest, requestId);
      if (!this.isValidJsonRpcRequest(item)) return jsonRespError(item.id, spec.InvalidRequest, requestId);

      if (ConfigService.get('BATCH_REQUESTS_DISALLOWED_METHODS').includes(item.method))
        return jsonRespError(item.id, spec.BatchRequestsMethodNotPermitted(item.method), requestId);

      const startTime = Date.now();
      return this.getRequestResult(item, ctx.ip, requestId, abortSignal).then((res) => {
        const ms = Date.now() - startTime;
        const code = 'error' in res ? res.error.code : 200;
        this.methodResponseHistogram?.labels(item.method, `${code}`, 'true').observe(ms);
        return res;
      });
    });
    const results = await Promise.all(promises);

    // for batch requests, always return 200 http status, this is standard for JSON-RPC 2.0 batch requests
    ctx.body = results;
    ctx.status = 200;
    ctx.state.status = responseSuccessStatusCode;
  }

  async getRequestResult(
    request: IJsonRpcRequest,
    ipAddress: string,
    requestId: string,
    abortSignal?: AbortSignal,
  ): Promise<IJsonRpcResponse> {
    const subdomain = request.method.split('_')[0] ?? null;
    if (!RPC_HTTP_API.has(subdomain)) {
      return jsonRespError(request.id, spec.SubdomainDisabled(request.method), requestId);
    }

    abortSignal?.throwIfAborted();

    try {
      const requestDetails = new RequestDetails({ requestId, ipAddress, abortSignal });
      // check rate limit for method and ip
      const methodTotalLimit = this.methodConfig[request.method]?.total ?? this.defaultRateLimit;
      if (await this.rateLimiter.shouldRateLimit(ipAddress, request.method, methodTotalLimit, requestDetails)) {
        return jsonRespError(request.id, spec.IPRateLimitExceeded(request.method), requestId);
      }

      // call the public API entry point on the Relay package to execute the RPC method
      const result = await this.relay.executeRpcMethod(request.method, request.params, requestDetails);

      return result instanceof JsonRpcError
        ? jsonRespError(request.id, result, requestId)
        : jsonRespResult(request.id, result);
    } catch (err) {
      if (isRequestAbortedError(err)) {
        throw err;
      }

      /* istanbul ignore next: this catch block covers programmatic errors and should not happen */
      return jsonRespError(request.id, spec.InternalError(err), requestId);
    }
  }

  isValidJsonRpcRequest(body: Pick<IJsonRpcRequest, 'id'>): body is IJsonRpcRequest {
    // validate it has the correct jsonrpc version, method, and id
    const candidate = body as Partial<IJsonRpcRequest>;
    if (candidate.jsonrpc !== '2.0' || typeof candidate.method !== 'string') return false;

    // the relay only supports positional params, so anything present other than an array is an invalid request
    return candidate.params === undefined || Array.isArray(candidate.params);
  }

  getKoaApp(): Koa<Koa.DefaultState, Koa.DefaultContext> {
    return this.koaApp;
  }

  hasValidJsonRpcId(body: unknown): body is Pick<IJsonRpcRequest, 'id'> {
    if (typeof body !== 'object' || body === null) return false;

    if (Object.prototype.hasOwnProperty.call(body, 'id')) {
      const { id } = body as { id: unknown };
      return typeof id === 'string' || typeof id === 'number' || id === null;
    }

    if (this.requestIdIsOptional) {
      // If the request is invalid, we still want to return a valid JSON-RPC response, default id to 0
      (body as Pick<IJsonRpcRequest, 'id'>).id = '0';
      return true;
    }
    return false;
  }
}
