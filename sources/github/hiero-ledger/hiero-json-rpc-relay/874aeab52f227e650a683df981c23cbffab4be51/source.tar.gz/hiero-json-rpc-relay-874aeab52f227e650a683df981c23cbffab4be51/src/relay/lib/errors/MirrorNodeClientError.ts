// SPDX-License-Identifier: Apache-2.0

import { Status } from '@hiero-ledger/sdk';

interface MirrorNodeErrorDetail {
  message: string;
  detail?: string;
  data?: string;
}

/** Shape read off the raw error passed to the constructor. */
interface MirrorNodeErrorLike {
  message?: string;
  response?: { data?: { _status?: { messages?: MirrorNodeErrorDetail[] } } };
}

export class MirrorNodeClientError extends Error {
  public statusCode: number;
  public data?: string;
  public detail?: string;
  private children: { message: string; detail?: string; data?: string }[];

  static readonly ErrorCodes = {
    ECONNABORTED: 504,
    ECONNREFUSED: 567,
    NOT_SUPPORTED: 501,
  } as const;

  static statusCodes = {
    NOT_FOUND: 404,
    TOO_MANY_REQUESTS: 429,
    NO_CONTENT: 204,
    BAD_GATEWAY: 502,
    SERVICE_UNAVAILABLE: 503,
    GATEWAY_TIMEOUT: 504,
  };

  static messages = {
    INVALID_HEX: 'data field invalid hexadecimal string',
    CONTRACT_REVERT_EXECUTED: Status.ContractRevertExecuted.toString(),
  };

  constructor(error: unknown, statusCode: number) {
    const err = error as MirrorNodeErrorLike;
    // mirror node web3 module sends errors in this format, this is why we need a check to distinguish
    if (err.response?.data?._status?.messages?.length) {
      const [msg, ...children] = err.response.data._status.messages;
      const { message, detail, data } = msg;
      super(message);

      this.detail = detail;
      this.data = data;
      this.children = children || [];
    } else {
      super(err.message);

      this.children = [];
    }

    this.statusCode = statusCode;
    Object.setPrototypeOf(this, MirrorNodeClientError.prototype);
  }

  get revertReason(): string {
    const reasons = this.children.map((child) => child.detail || child.message).filter(Boolean);
    return [this.detail || this.message, ...reasons].join(', ');
  }

  public isTimeout(): boolean {
    return this.statusCode === MirrorNodeClientError.ErrorCodes.ECONNABORTED;
  }

  /**
   * Returns true for transient conditions that are safe to retry during Mirror Node startup:
   * ECONNREFUSED, connection timeout, 502 (Bad Gateway), 503 (Service Unavailable), 504 (Gateway Timeout).
   */
  public isNetworkUnavailable(): boolean {
    return (
      this.statusCode === MirrorNodeClientError.ErrorCodes.ECONNREFUSED ||
      this.isTimeout() ||
      this.statusCode === MirrorNodeClientError.statusCodes.BAD_GATEWAY ||
      this.statusCode === MirrorNodeClientError.statusCodes.SERVICE_UNAVAILABLE ||
      this.statusCode === MirrorNodeClientError.statusCodes.GATEWAY_TIMEOUT
    );
  }

  public isContractRevert(): boolean {
    return this.message === MirrorNodeClientError.messages.CONTRACT_REVERT_EXECUTED;
  }

  public isNotFound(): boolean {
    return this.statusCode === MirrorNodeClientError.statusCodes.NOT_FOUND;
  }

  public isNotSupported(): boolean {
    return this.statusCode === MirrorNodeClientError.ErrorCodes.NOT_SUPPORTED;
  }

  public isEmpty(): boolean {
    return this.statusCode === MirrorNodeClientError.statusCodes.NO_CONTENT;
  }

  public isRateLimit(): boolean {
    return this.statusCode === MirrorNodeClientError.statusCodes.TOO_MANY_REQUESTS;
  }

  public isNotSupportedSystemContractOperaton(): boolean {
    return this.message === 'Precompile not supported';
  }

  isFailInvalid(): boolean {
    return this.message === 'FAIL_INVALID';
  }

  isInvalidTransaction(): boolean {
    return this.message === 'INVALID_TRANSACTION';
  }

  public toJSON(): {
    statusCode: number;
    data: string | unknown;
    detail: string | unknown;
    message: string;
    name: string;
  } {
    return {
      statusCode: this.statusCode,
      data: this.data,
      detail: this.detail,
      message: this.message,
      name: MirrorNodeClientError.name,
    };
  }

  public static fromJSON(statusCode: number, message: string, data?: string, detail?: string): MirrorNodeClientError {
    const err: MirrorNodeClientError = new MirrorNodeClientError({}, statusCode);
    err.data = data;
    err.detail = detail;
    err.message = message;

    return err;
  }
}
