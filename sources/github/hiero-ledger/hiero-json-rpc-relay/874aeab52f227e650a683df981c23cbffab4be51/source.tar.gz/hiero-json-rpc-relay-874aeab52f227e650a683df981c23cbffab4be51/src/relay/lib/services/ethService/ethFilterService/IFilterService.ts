// SPDX-License-Identifier: Apache-2.0

import { type JsonRpcError } from '../../../errors/JsonRpcError';
import { type Log } from '../../../model';
import { type RequestDetails } from '../../../types';
import { type INewFilterParams } from '../../../types/requestParams';
export interface IFilterService {
  newFilter(params: INewFilterParams, requestDetails: RequestDetails): Promise<string | JsonRpcError>;

  newBlockFilter(requestDetails: RequestDetails): Promise<string | JsonRpcError>;

  uninstallFilter(filterId: string, requestDetails: RequestDetails): Promise<boolean>;

  getFilterLogs(filterId: string, requestDetails: RequestDetails): Promise<Log[]>;

  getFilterChanges(filterId: string, requestDetails: RequestDetails): Promise<string[] | Log[] | JsonRpcError>;
}
