// SPDX-License-Identifier: Apache-2.0

import type MockAdapter from 'axios-mock-adapter';
import { expect, use } from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { AbiCoder, keccak256, type Transaction } from 'ethers';
import { createStubInstance, type SinonStub, type SinonStubbedInstance, stub } from 'sinon';
import { v4 as uuid } from 'uuid';

import { type Eth, JsonRpcError } from '../../../../src/relay';
import { numberTo0x } from '../../../../src/relay/formatters';
import { SDKClient } from '../../../../src/relay/lib/clients';
import constants from '../../../../src/relay/lib/constants';
import { predefined } from '../../../../src/relay/lib/errors/JsonRpcError';
import { EthImpl } from '../../../../src/relay/lib/eth';
import { Precheck } from '../../../../src/relay/lib/precheck';
import {
  type ContractService,
  LocalPendingTransactionStorage,
  LockService,
  TransactionPoolService,
  TransactionTracingService,
} from '../../../../src/relay/lib/services';
import {
  type IContractCallRequest,
  type IContractCallResponse,
  type LockStrategy,
  RequestDetails,
  type StateOverrideSet,
} from '../../../../src/relay/lib/types';
import {
  type IParamValidation,
  RPC_PARAM_VALIDATION_RULES_KEY,
  validateParams,
} from '../../../../src/relay/lib/validators';
import { Utils } from '../../../../src/relay/utils';
import { mockData, overrideEnvsInMochaDescribe, withOverriddenEnvsInMochaTest } from '../../helpers';
import {
  ACCOUNT_ADDRESS_1,
  DEFAULT_NETWORK_FEES,
  NO_TRANSACTIONS,
  ONE_TINYBAR_IN_WEI_HEX,
  RECEIVER_ADDRESS,
} from './eth-config';
import { asSdkClientProvider, generateEthTestEnv } from './eth-helpers';

use(chaiAsPromised);

let sdkClientStub: SinonStubbedInstance<SDKClient>;
let getSdkClientStub: SinonStub<[], SDKClient>;
let ethImplOverridden: Eth;
const gasTxBaseCost = numberTo0x(constants.TX_BASE_COST);

describe('@ethEstimateGas Estimate Gas spec', async function () {
  this.timeout(10000);
  const { restMock, web3Mock, hapiServiceInstance, ethImpl, cacheService, mirrorNodeInstance, logger, registry } =
    generateEthTestEnv();

  const contractService = ethImpl['contractService'] as ContractService;
  const requestDetails = new RequestDetails({ requestId: 'eth_estimateGasTest', ipAddress: '0.0.0.0' });
  async function mockContractCall(
    callData: IContractCallRequest,
    estimate: boolean,
    statusCode: number,
    result: IContractCallResponse,
    requestDetails: RequestDetails,
  ): Promise<MockAdapter> {
    const formattedData = { ...callData, estimate };
    await contractService['contractCallFormat'](formattedData, requestDetails);
    return web3Mock.onPost('contracts/call', formattedData).reply(statusCode, JSON.stringify(result));
  }

  function mockGetAccount(idOrAliasOrEvmAddress: string, statusCode: number, result: unknown): MockAdapter {
    return restMock
      .onGet(`accounts/${idOrAliasOrEvmAddress}?transactions=false`)
      .reply(statusCode, JSON.stringify(result));
  }

  const transaction = {
    from: '0x05fba803be258049a27b820088bab1cad2058871',
    data: '0x60806040523480156200001157600080fd5b50604051620019f4380380620019f48339818101604052810190620000379190620001fa565b818181600390816200004a9190620004ca565b5080600490816200005c9190620004ca565b5050505050620005b1565b6000604051905090565b600080fd5b600080fd5b600080fd5b600080fd5b6000601f19601f8301169050919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b620000d08262000085565b810181811067ffffffffffffffff82111715620000f257620000f162000096565b5b80604052505',
  };
  const id = uuid();
  const defaultGasOverride = constants.TX_DEFAULT_GAS_DEFAULT + 1;
  const simulationFailErrorMessage = 'Error occurred during transaction simulation';

  overrideEnvsInMochaDescribe({
    ETH_GET_TRANSACTION_COUNT_MAX_BLOCK_RANGE: 1,
    TX_DEFAULT_GAS: defaultGasOverride.toString(),
  });

  this.beforeEach(async () => {
    // reset cache and mocks
    await cacheService.clear();
    restMock.reset();
    web3Mock.reset();
    sdkClientStub = createStubInstance(SDKClient);

    getSdkClientStub = stub(asSdkClientProvider(hapiServiceInstance), 'getSDKClient').returns(sdkClientStub);
    const storage = new LocalPendingTransactionStorage();
    const lockService = new LockService({
      acquireLock: async () => undefined,
      releaseLock: async () => {},
    } as unknown as LockStrategy);
    const transactionPoolService = new TransactionPoolService(storage, logger, registry);
    ethImplOverridden = new EthImpl(
      hapiServiceInstance,
      mirrorNodeInstance,
      logger,
      '0x12a',
      cacheService,
      transactionPoolService,
      lockService,
      registry,
      new TransactionTracingService(logger),
    );
    restMock.onGet('network/fees').reply(200, JSON.stringify(DEFAULT_NETWORK_FEES));
    restMock.onGet(`accounts/undefined${NO_TRANSACTIONS}`).reply(404);
    mockGetAccount(hapiServiceInstance.getOperatorAccountId()!.toString(), 200, {
      evm_address: ACCOUNT_ADDRESS_1,
    });
  });

  this.afterEach(() => {
    getSdkClientStub.restore();
    restMock.resetHandlers();
    web3Mock.resetHandlers();
  });

  describe('eth_estimateGas with contract call', async function () {});

  it('should map FAIL_INVALID to JSON-RPC error code 3 for eth_estimateGas', async function () {
    const callData: IContractCallRequest = {
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      to: RECEIVER_ADDRESS,
      data: '0x01',
    };

    await mockContractCall(callData, true, 400, mockData.failInvalid, requestDetails);

    await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails))
      .to.be.rejectedWith(JsonRpcError)
      .and.to.eventually.include({
        code: 3,
        message: 'execution reverted: FAIL_INVALID',
      });
  });

  it('should eth_estimateGas with transaction.data null throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {
      from: '0x05fba803be258049a27b820088bab1cad2058871',
      value: '0x0',
      gasPrice: '0x0',
      data: null,
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);

    await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas to mirror node for contract call returns 400 throws COULD_NOT_SIMULATE_TRANSACTION error', async function () {
    const callData: IContractCallRequest = {
      data: '0x608060405234801561001057600080fd5b506040516107893803806107898339818101604052810190610032919061015a565b806000908051906020019061004892919061004f565b50506102f6565b82805461005b90610224565b90600052602060002090601f01602090048101928261007d57600085556100c4565b82601f1061009657805160ff19168380011785556100c4565b828001600101855582156100c4579182015b828111156100c35782518255916020019190600101906100a8565b5b5090506100d191906100d5565b5090565b5b808211156100ee5760008160009055506001016100d6565b5090565b6000610105610100846101c0565b61019b565b90508281526020810184848401111561011d57600080fd5b6101288482856101f1565b509392505050565b600082601f83011261014157600080fd5b81516101518482602086016100f2565b91505092915050565b60006020828403121561016c57600080fd5b600082015167ffffffffffffffff81111561018657600080fd5b61019284828501610130565b91505092915050565b60006101a56101b6565b90506101b18282610256565b919050565b6000604051905090565b600067ffffffffffffffff8211156101db576101da6102b6565b5b6101e4826102e5565b9050602081019050919050565b60005b8381101561020f5780820151818401526020810190506101f4565b8381111561021e576000848401525b50505050565b6000600282049050600182168061023c57607f821691505b602082108114156102505761024f610287565b5b50919050565b61025f826102e5565b810181811067ffffffffffffffff8211171561027e5761027d6102b6565b5b80604052505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000601f19601f8301169050919050565b610484806103056000396000f3fe608060405234801561001057600080fd5b50600436106100365760003560e01c8063a41368621461003b578063cfae321714610057575b600080fd5b6100556004803603810190610050919061022c565b610075565b005b61005f61008f565b60405161006c91906102a6565b60405180910390f35b806000908051906020019061008b929190610121565b5050565b60606000805461009e9061037c565b80601f01602080910402602001604051908101604052809291908181526020018280546100ca9061037c565b80156101175780601f106100ec57610100808354040283529160200191610117565b820191906000526020600020905b8154815290600101906020018083116100fa57829003601f168201915b5050505050905090565b82805461012d9061037c565b90600052602060002090601f01602090048101928261014f5760008555610196565b82601f1061016857805160ff1916838001178555610196565b82800160010185558215610196579182015b8281111561019557825182559160200191906001019061017a565b5b5090506101a391906101a7565b5090565b5b808211156101c05760008160009055506001016101a8565b5090565b60006101d76101d2846102ed565b6102c8565b9050828152602081018484840111156101ef57600080fd5b6101fa84828561033a565b509392505050565b600082601f83011261021357600080fd5b81356102238482602086016101c4565b91505092915050565b60006020828403121561023e57600080fd5b600082013567ffffffffffffffff81111561025857600080fd5b61026484828501610202565b91505092915050565b60006102788261031e565b6102828185610329565b9350610292818560208601610349565b61029b8161043d565b840191505092915050565b600060208201905081810360008301526102c0818461026d565b905092915050565b60006102d26102e3565b90506102de82826103ae565b919050565b6000604051905090565b600067ffffffffffffffff8211156103085761030761040e565b5b6103118261043d565b9050602081019050919050565b600081519050919050565b600082825260208201905092915050565b82818337600083830152505050565b60005b8381101561036757808201518184015260208101905061034c565b83811115610376576000848401525b50505050565b6000600282049050600182168061039457607f821691505b602082108114156103a8576103a76103df565b5b50919050565b6103b78261043d565b810181811067ffffffffffffffff821117156103d6576103d561040e565b5b80604052505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000601f19601f830116905091905056fea264697066735822122070d157c4efbb3fba4a1bde43cbba5b92b69f2fc455a650c0dfb61e9ed3d4bd6364736f6c634300080400330000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b696e697469616c5f6d7367000000000000000000000000000000000000000000',
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      to: RECEIVER_ADDRESS,
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);

    await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas contract call returns workaround response from mirror-node', async function () {
    const callData: IContractCallRequest = {
      data: '0x608060405234801561001057600080fd5b506040516107893803806107898339818101604052810190610032919061015a565b806000908051906020019061004892919061004f565b50506102f6565b82805461005b90610224565b90600052602060002090601f01602090048101928261007d57600085556100c4565b82601f1061009657805160ff19168380011785556100c4565b828001600101855582156100c4579182015b828111156100c35782518255916020019190600101906100a8565b5b5090506100d191906100d5565b5090565b5b808211156100ee5760008160009055506001016100d6565b5090565b6000610105610100846101c0565b61019b565b90508281526020810184848401111561011d57600080fd5b6101288482856101f1565b509392505050565b600082601f83011261014157600080fd5b81516101518482602086016100f2565b91505092915050565b60006020828403121561016c57600080fd5b600082015167ffffffffffffffff81111561018657600080fd5b61019284828501610130565b91505092915050565b60006101a56101b6565b90506101b18282610256565b919050565b6000604051905090565b600067ffffffffffffffff8211156101db576101da6102b6565b5b6101e4826102e5565b9050602081019050919050565b60005b8381101561020f5780820151818401526020810190506101f4565b8381111561021e576000848401525b50505050565b6000600282049050600182168061023c57607f821691505b602082108114156102505761024f610287565b5b50919050565b61025f826102e5565b810181811067ffffffffffffffff8211171561027e5761027d6102b6565b5b80604052505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000601f19601f8301169050919050565b610484806103056000396000f3fe608060405234801561001057600080fd5b50600436106100365760003560e01c8063a41368621461003b578063cfae321714610057575b600080fd5b6100556004803603810190610050919061022c565b610075565b005b61005f61008f565b60405161006c91906102a6565b60405180910390f35b806000908051906020019061008b929190610121565b5050565b60606000805461009e9061037c565b80601f01602080910402602001604051908101604052809291908181526020018280546100ca9061037c565b80156101175780601f106100ec57610100808354040283529160200191610117565b820191906000526020600020905b8154815290600101906020018083116100fa57829003601f168201915b5050505050905090565b82805461012d9061037c565b90600052602060002090601f01602090048101928261014f5760008555610196565b82601f1061016857805160ff1916838001178555610196565b82800160010185558215610196579182015b8281111561019557825182559160200191906001019061017a565b5b5090506101a391906101a7565b5090565b5b808211156101c05760008160009055506001016101a8565b5090565b60006101d76101d2846102ed565b6102c8565b9050828152602081018484840111156101ef57600080fd5b6101fa84828561033a565b509392505050565b600082601f83011261021357600080fd5b81356102238482602086016101c4565b91505092915050565b60006020828403121561023e57600080fd5b600082013567ffffffffffffffff81111561025857600080fd5b61026484828501610202565b91505092915050565b60006102788261031e565b6102828185610329565b9350610292818560208601610349565b61029b8161043d565b840191505092915050565b600060208201905081810360008301526102c0818461026d565b905092915050565b60006102d26102e3565b90506102de82826103ae565b919050565b6000604051905090565b600067ffffffffffffffff8211156103085761030761040e565b5b6103118261043d565b9050602081019050919050565b600081519050919050565b600082825260208201905092915050565b82818337600083830152505050565b60005b8381101561036757808201518184015260208101905061034c565b83811115610376576000848401525b50505050565b6000600282049050600182168061039457607f821691505b602082108114156103a8576103a76103df565b5b50919050565b6103b78261043d565b810181811067ffffffffffffffff821117156103d6576103d561040e565b5b80604052505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000601f19601f830116905091905056fea264697066735822122070d157c4efbb3fba4a1bde43cbba5b92b69f2fc455a650c0dfb61e9ed3d4bd6364736f6c634300080400330000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b696e697469616c5f6d7367000000000000000000000000000000000000000000',
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
    };
    await mockContractCall(callData, true, 200, { result: `0x61A80` }, requestDetails);

    const gas = await ethImpl.estimateGas(callData, null, undefined, requestDetails);
    expect((gas as string).toLowerCase()).to.equal(numberTo0x(constants.TX_DEFAULT_GAS_DEFAULT).toLowerCase());
  });

  it('should eth_estimateGas contract call with value is converted to tinybars before it is sent to mirror node', async function () {
    const callData: IContractCallRequest = {
      data: '0x608060405234801561001057600080fd5b506040516107893803806107898339818101604052810190610032919061015a565b806000908051906020019061004892919061004f565b50506102f6565b82805461005b90610224565b90600052602060002090601f01602090048101928261007d57600085556100c4565b82601f1061009657805160ff19168380011785556100c4565b828001600101855582156100c4579182015b828111156100c35782518255916020019190600101906100a8565b5b5090506100d191906100d5565b5090565b5b808211156100ee5760008160009055506001016100d6565b5090565b6000610105610100846101c0565b61019b565b90508281526020810184848401111561011d57600080fd5b6101288482856101f1565b509392505050565b600082601f83011261014157600080fd5b81516101518482602086016100f2565b91505092915050565b60006020828403121561016c57600080fd5b600082015167ffffffffffffffff81111561018657600080fd5b61019284828501610130565b91505092915050565b60006101a56101b6565b90506101b18282610256565b919050565b6000604051905090565b600067ffffffffffffffff8211156101db576101da6102b6565b5b6101e4826102e5565b9050602081019050919050565b60005b8381101561020f5780820151818401526020810190506101f4565b8381111561021e576000848401525b50505050565b6000600282049050600182168061023c57607f821691505b602082108114156102505761024f610287565b5b50919050565b61025f826102e5565b810181811067ffffffffffffffff8211171561027e5761027d6102b6565b5b80604052505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000601f19601f8301169050919050565b610484806103056000396000f3fe608060405234801561001057600080fd5b50600436106100365760003560e01c8063a41368621461003b578063cfae321714610057575b600080fd5b6100556004803603810190610050919061022c565b610075565b005b61005f61008f565b60405161006c91906102a6565b60405180910390f35b806000908051906020019061008b929190610121565b5050565b60606000805461009e9061037c565b80601f01602080910402602001604051908101604052809291908181526020018280546100ca9061037c565b80156101175780601f106100ec57610100808354040283529160200191610117565b820191906000526020600020905b8154815290600101906020018083116100fa57829003601f168201915b5050505050905090565b82805461012d9061037c565b90600052602060002090601f01602090048101928261014f5760008555610196565b82601f1061016857805160ff1916838001178555610196565b82800160010185558215610196579182015b8281111561019557825182559160200191906001019061017a565b5b5090506101a391906101a7565b5090565b5b808211156101c05760008160009055506001016101a8565b5090565b60006101d76101d2846102ed565b6102c8565b9050828152602081018484840111156101ef57600080fd5b6101fa84828561033a565b509392505050565b600082601f83011261021357600080fd5b81356102238482602086016101c4565b91505092915050565b60006020828403121561023e57600080fd5b600082013567ffffffffffffffff81111561025857600080fd5b61026484828501610202565b91505092915050565b60006102788261031e565b6102828185610329565b9350610292818560208601610349565b61029b8161043d565b840191505092915050565b600060208201905081810360008301526102c0818461026d565b905092915050565b60006102d26102e3565b90506102de82826103ae565b919050565b6000604051905090565b600067ffffffffffffffff8211156103085761030761040e565b5b6103118261043d565b9050602081019050919050565b600081519050919050565b600082825260208201905092915050565b82818337600083830152505050565b60005b8381101561036757808201518184015260208101905061034c565b83811115610376576000848401525b50505050565b6000600282049050600182168061039457607f821691505b602082108114156103a8576103a76103df565b5b50919050565b6103b78261043d565b810181811067ffffffffffffffff821117156103d6576103d561040e565b5b80604052505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000601f19601f830116905091905056fea264697066735822122070d157c4efbb3fba4a1bde43cbba5b92b69f2fc455a650c0dfb61e9ed3d4bd6364736f6c634300080400330000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b696e697469616c5f6d7367000000000000000000000000000000000000000000',
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      value: 1,
    };
    await mockContractCall(callData, true, 200, { result: `0x61A80` }, requestDetails);

    const gas = await ethImpl.estimateGas(
      { ...callData, value: ONE_TINYBAR_IN_WEI_HEX },
      null,
      undefined,
      requestDetails,
    );
    expect((gas as string).toLowerCase()).to.equal(numberTo0x(constants.TX_DEFAULT_GAS_DEFAULT).toLowerCase());
  });

  it('should eth_estimateGas with non-empty authorizationList passes list to mirror node', async () => {
    const authEntry = {
      chainId: '0x12a',
      nonce: '0x5',
      address: RECEIVER_ADDRESS,
      yParity: '0x0',
      r: '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
      s: '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',
    };
    const callData: IContractCallRequest = {
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      to: RECEIVER_ADDRESS,
      data: '0x01',
      authorizationList: [authEntry],
    };
    await mockContractCall(callData, true, 200, { result: '0x5208' }, requestDetails);

    web3Mock.resetHistory();
    const gas = await ethImpl.estimateGas(callData, null, undefined, requestDetails);

    expect(gas).to.be.a('string');
    expect((gas as string).startsWith('0x')).to.be.true;
    expect(web3Mock.history.post.length).to.gte(1);
    const sentBody = JSON.parse(web3Mock.history.post[0].data);
    expect(sentBody.authorizationList).to.be.an('array').with.lengthOf(1);
    expect(sentBody.authorizationList[0]).to.deep.equal(authEntry);
  });

  it('should eth_estimateGas for contract deploy throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {
      data: '0x01',
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);

    await expect(ethImpl.estimateGas({ data: '0x01' }, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas to mirror node for transfer throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      to: RECEIVER_ADDRESS,
      value: '0x2540BE400',
      // data: '0x',
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);
    restMock
      .onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`)
      .reply(200, JSON.stringify({ address: RECEIVER_ADDRESS }));

    await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas to mirror node for transfer without value throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      to: RECEIVER_ADDRESS,
      // data: '0x',
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);
    restMock.onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`).reply(200, { address: RECEIVER_ADDRESS });

    await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas transfer to existing account returns gas estimate', async function () {
    const callData: IContractCallRequest = {
      to: RECEIVER_ADDRESS,
      value: 100_000_000_000, // 10^11 wei = 10 tinybars after conversion
      from: ACCOUNT_ADDRESS_1,
    };
    await mockContractCall(callData, true, 200, { result: gasTxBaseCost }, requestDetails);
    restMock
      .onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`)
      .reply(200, JSON.stringify({ address: RECEIVER_ADDRESS }));

    const gas = await ethImpl.estimateGas(
      {
        to: RECEIVER_ADDRESS,
        value: 100_000_000_000,
      },
      null,
      undefined,
      requestDetails,
    );
    expect(gas).to.equal(gasTxBaseCost);
  });

  it('should eth_estimateGas transfer to existing cached account returns gas estimate', async function () {
    const callData: IContractCallRequest = {
      to: RECEIVER_ADDRESS,
      value: 100_000_000_000, // 10^11 wei = 10 tinybars after conversion
      from: ACCOUNT_ADDRESS_1,
    };
    await mockContractCall(callData, true, 200, { result: gasTxBaseCost }, requestDetails);
    restMock
      .onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`)
      .reply(200, JSON.stringify({ address: RECEIVER_ADDRESS }));

    const gasBeforeCache = await ethImpl.estimateGas(
      {
        to: RECEIVER_ADDRESS,
        value: 100_000_000_000,
      },
      null,
      undefined,
      requestDetails,
    );

    restMock.onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`).reply(404);
    const gasAfterCache = await ethImpl.estimateGas(
      {
        to: RECEIVER_ADDRESS,
        value: 100_000_000_000,
      },
      null,
      undefined,
      requestDetails,
    );

    expect(gasBeforeCache).to.equal(gasTxBaseCost);
    expect(gasAfterCache).to.equal(gasTxBaseCost);
  });

  it('should eth_estimateGas transfer to non existing account returns gas estimate for hollow account creation', async function () {
    const minGasTxHollowAccountCreation = numberTo0x(constants.MIN_TX_HOLLOW_ACCOUNT_CREATION_GAS);
    const callData: IContractCallRequest = {
      to: RECEIVER_ADDRESS,
      value: 100_000_000_000, // 10^11 wei = 10 tinybars after conversion
      from: ACCOUNT_ADDRESS_1,
    };
    await mockContractCall(callData, true, 200, { result: minGasTxHollowAccountCreation }, requestDetails);
    restMock.onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`).reply(404);

    const hollowAccountGasCreation = await ethImpl.estimateGas(
      {
        to: RECEIVER_ADDRESS,
        value: 100_000_000_000,
      },
      null,
      undefined,
      requestDetails,
    );
    expect(Number(hollowAccountGasCreation)).to.be.greaterThanOrEqual(Number(minGasTxHollowAccountCreation));
  });

  it('should eth_estimateGas transfer with 0 value returns gas estimate', async function () {
    const callData: IContractCallRequest = {
      to: RECEIVER_ADDRESS,
      value: 0, //in tinybars
    };
    await mockContractCall(callData, true, 200, { result: gasTxBaseCost }, requestDetails);
    restMock
      .onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`)
      .reply(200, JSON.stringify({ address: RECEIVER_ADDRESS }));
    const gas = await ethImpl.estimateGas(
      {
        to: RECEIVER_ADDRESS,
        value: 0,
      },
      null,
      undefined,
      requestDetails,
    );

    expect(gas).to.equal(gasTxBaseCost);
  });

  it('should eth_estimateGas for contract create with input field and absent data field', async () => {
    const gasEstimation = 1357410;

    const callData: IContractCallRequest = {
      from: '0x81cb089c285e5ee3a7353704fb114955037443af',
      to: null,
      value: '0x0',
      input:
        '0x81cb089c285e5ee3a7353704fb114955037443af85e5ee3a7353704fb114955037443af85e5ee3a7353704fb114955037443af85e5ee3a7353704fb114955037443af',
    };
    await mockContractCall(callData, true, 200, { result: `0x14b662` }, requestDetails);

    const gas = await ethImpl.estimateGas(callData, null, undefined, requestDetails);

    expect((gas as string).toLowerCase()).to.equal(numberTo0x(gasEstimation).toLowerCase());
  });

  it('should eth_estimateGas transfer with invalid value throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {
      to: RECEIVER_ADDRESS,
      value: -100_000_000_000, //in tinybars
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);
    restMock
      .onGet(`accounts/${RECEIVER_ADDRESS}${NO_TRANSACTIONS}`)
      .reply(200, JSON.stringify({ address: RECEIVER_ADDRESS }));

    await expect(
      ethImpl.estimateGas(
        {
          to: RECEIVER_ADDRESS,
          value: -100_000_000_000,
        },
        null,
        undefined,
        requestDetails,
      ),
    ).to.be.rejectedWith(JsonRpcError, simulationFailErrorMessage);
  });

  it('should eth_estimateGas empty call throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {};
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);

    await expect(ethImpl.estimateGas({}, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas empty call returns transfer cost with overridden default gas', async function () {
    const callData: IContractCallRequest = {};
    await mockContractCall(callData, true, 200, { result: numberTo0x(defaultGasOverride) }, requestDetails);

    const gas = await ethImplOverridden.estimateGas({}, null, undefined, requestDetails);
    expect(gas).to.equal(numberTo0x(defaultGasOverride));
  });

  it('should eth_estimateGas empty input throws COULD_NOT_SIMULATE_TRANSACTION error on 400', async function () {
    const callData: IContractCallRequest = {
      data: '',
      estimate: true,
    };
    const contractsCallResponse: IContractCallResponse = { errorMessage: '', statusCode: 400 };

    await mockContractCall(callData, true, 400, contractsCallResponse, requestDetails);

    await expect(ethImpl.estimateGas({ data: '' }, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas empty input throws COULD_NOT_SIMULATE_TRANSACTION error on 400 with overridden default gas', async function () {
    const callData: IContractCallRequest = {
      data: '',
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);

    await expect(ethImplOverridden.estimateGas({ data: '' }, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas with empty data and value returns gas estimate when successful', async function () {
    // Test transfer with value and empty data - simplified for current behavior
    const callData: IContractCallRequest = {
      to: RECEIVER_ADDRESS,
      value: '0x2540BE400', // 10 billion wei = 1 tinybar after conversion
      from: ACCOUNT_ADDRESS_1,
    };
    await mockContractCall(callData, true, 200, { result: gasTxBaseCost }, requestDetails);
    mockGetAccount(RECEIVER_ADDRESS, 200, { account: '0.0.1234', evm_address: RECEIVER_ADDRESS });

    const gas = await ethImpl.estimateGas(
      {
        to: RECEIVER_ADDRESS,
        value: '0x2540BE400', // 10 billion wei = 1 tinybar
      },
      null,
      undefined,
      requestDetails,
    );
    expect(gas).to.equal(gasTxBaseCost);
  });

  it('should eth_estimateGas zero input throws COULD_NOT_SIMULATE_TRANSACTION error on 400 with overridden default gas', async function () {
    const callData: IContractCallRequest = {
      gas: '0x0',
    };
    await mockContractCall(callData, true, 400, { errorMessage: '', statusCode: 400 }, requestDetails);

    await expect(ethImplOverridden.estimateGas(callData, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas with contract revert and message does not equal executionReverted throws error', async function () {
    const contractCallResult: IContractCallResponse = {
      _status: {
        messages: [
          {
            message: 'data field invalid hexadecimal string',
            detail: '',
            data: '',
          },
        ],
      },
    };
    await mockContractCall(transaction, true, 400, contractCallResult, requestDetails);

    await expect(ethImpl.estimateGas(transaction, id, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should eth_estimateGas with contract revert and message equals "execution reverted: Invalid number of recipients" throws CONTRACT_REVERT error', async function () {
    await mockContractCall(
      transaction,
      true,
      400,
      {
        _status: {
          messages: [
            {
              data: '0x08c379a00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001c496e76616c6964206e756d626572206f6620726563697069656e747300000000',
              detail: 'Invalid number of recipients',
              message: 'CONTRACT_REVERT_EXECUTED',
            },
          ],
        },
      },
      requestDetails,
    );

    await expect(ethImpl.estimateGas(transaction, id, undefined, requestDetails))
      .to.be.rejectedWith(JsonRpcError)
      .and.eventually.satisfy((error: JsonRpcError) => {
        expect(error.data).to.equal(
          '0x08c379a00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001c496e76616c6964206e756d626572206f6620726563697069656e747300000000',
        );
        expect(error.message).to.equal('execution reverted: Invalid number of recipients');
        return true;
      });
  });

  withOverriddenEnvsInMochaTest({ ESTIMATE_GAS_THROWS: 'false' }, () => {
    it('should eth_estimateGas with contract revert and message does not equal executionReverted and ESTIMATE_GAS_THROWS is set to false', async () => {
      const originalEstimateGas = contractService.estimateGas;
      contractService.estimateGas = async (): Promise<string> => {
        return numberTo0x(Precheck.transactionIntrinsicGasCost(transaction as Transaction));
      };

      const result = await ethImpl.estimateGas(transaction, id, undefined, requestDetails);

      expect(result).to.equal(numberTo0x(Precheck.transactionIntrinsicGasCost(transaction as Transaction)));

      contractService.estimateGas = originalEstimateGas;
    });
  });

  it('should eth_estimateGas with contract revert and message equals "execution reverted: Invalid number of recipients"', async () => {
    await mockContractCall(
      transaction,
      true,
      400,
      {
        _status: {
          messages: [
            {
              data: '0x08c379a00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001c496e76616c6964206e756d626572206f6620726563697069656e747300000000',
              detail: 'Invalid number of recipients',
              message: 'CONTRACT_REVERT_EXECUTED',
            },
          ],
        },
      },
      requestDetails,
    );

    await expect(ethImpl.estimateGas(transaction, id, undefined, requestDetails))
      .to.be.rejectedWith(JsonRpcError)
      .and.eventually.satisfy((error: JsonRpcError) => {
        expect(error.data).to.equal(
          '0x08c379a00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001c496e76616c6964206e756d626572206f6620726563697069656e747300000000',
        );
        expect(error.message).to.equal('execution reverted: Invalid number of recipients');
        return true;
      });
  });

  it('should eth_estimateGas with contract revert for contract call and custom contract error throws CONTRACT_REVERT error', async function () {
    const decodedMessage = 'Some error message';
    const customErrorSignature = keccak256(Buffer.from('CustomError(string)')).slice(0, 10); // 0x8d6ea8be
    const encodedMessage = new AbiCoder().encode(['string'], [decodedMessage]).replace('0x', '');
    const encodedCustomError = customErrorSignature + encodedMessage;

    await mockContractCall(
      transaction,
      true,
      400,
      {
        _status: {
          messages: [
            {
              message: 'CONTRACT_REVERT_EXECUTED',
              detail: decodedMessage,
              data: encodedCustomError,
            },
          ],
        },
      },
      requestDetails,
    );

    await expect(ethImpl.estimateGas(transaction, id, undefined, requestDetails))
      .to.be.rejectedWith(JsonRpcError)
      .and.eventually.satisfy((error: JsonRpcError) => {
        expect(error.data).to.equal(encodedCustomError);
        expect(error.message).to.equal(`execution reverted: ${decodedMessage}`);
        return true;
      });
  });

  it('should eth_estimateGas with contract revert with detailed in internal transactions', async function () {
    await mockContractCall(
      transaction,
      true,
      400,
      {
        _status: {
          messages: [
            {
              message: 'CONTRACT_REVERT_EXECUTED',
              detail: '',
              data: '0x',
            },
            {
              message: 'TOKEN_NOT_ASSOCIATED_TO_ACCOUNT',
              detail: '',
              data: '',
            },
          ],
        },
      },
      requestDetails,
    );

    await expect(ethImpl.estimateGas(transaction, id, undefined, requestDetails))
      .to.be.rejectedWith(JsonRpcError)
      .and.eventually.satisfy((error: JsonRpcError) => {
        expect(error.message).to.equal('execution reverted: CONTRACT_REVERT_EXECUTED, TOKEN_NOT_ASSOCIATED_TO_ACCOUNT');
        return true;
      });
  });

  it('should eth_estimateGas with contract revert for contract call and generic revert error throws CONTRACT_REVERT error', async function () {
    const decodedMessage = 'Some error message';
    const defaultErrorSignature = keccak256(Buffer.from('Error(string)')).slice(0, 10); // 0x08c379a0
    const encodedMessage = new AbiCoder().encode(['string'], [decodedMessage]).replace('0x', '');
    const encodedGenericError = defaultErrorSignature + encodedMessage;

    await mockContractCall(
      transaction,
      true,
      400,
      {
        _status: {
          messages: [
            {
              message: 'CONTRACT_REVERT_EXECUTED',
              detail: decodedMessage,
              data: encodedGenericError,
            },
          ],
        },
      },
      requestDetails,
    );

    await expect(ethImpl.estimateGas(transaction, id, undefined, requestDetails))
      .to.be.rejectedWith(JsonRpcError)
      .and.eventually.satisfy((error: JsonRpcError) => {
        expect(error.data).to.equal(encodedGenericError);
        expect(error.message).to.equal(`execution reverted: ${decodedMessage}`);
        return true;
      });
  });

  it('should eth_estimateGas handles a 400 response from the mirror node correctly by throwing COULD_NOT_SIMULATE_TRANSACTION error', async function () {
    const callData: IContractCallRequest = {
      from: '0x05fba803be258049a27b820088bab1cad2058871',
      value: '0x1',
      gasPrice: '0x0',
    };
    await mockContractCall(
      callData,
      true,
      400,
      {
        _status: {
          messages: [
            {
              message: 'Auto account creation is not supported.',
              detail: '',
              data: '',
            },
          ],
        },
      },
      requestDetails,
    );

    await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails)).to.be.rejectedWith(
      JsonRpcError,
      simulationFailErrorMessage,
    );
  });

  it('should should perform estimateGas precheck', async function () {
    const transaction = {
      from: '0x05fba803be258049a27b820088bab1cad2058871',
      data: '0x',
      value: '0xA186B8E9800',
      gasPrice: '0xF4240',
      gas: '0xd97010',
    };

    await contractService['contractCallFormat'](transaction, requestDetails);
    expect(transaction.value).to.eq(1110);
    expect(transaction.gasPrice).to.eq(1000000);
    expect(transaction.gas).to.eq(14250000);
  });

  it('should handle estimateGas error and return INTERNAL_ERROR', async function () {
    const originalEstimateGas = contractService.estimateGas;
    // @ts-ignore
    contractService.estimateGas = async (): Promise<JsonRpcError> => {
      return predefined.INTERNAL_ERROR('Test error for estimateGas');
    };

    const result = await ethImpl.estimateGas(transaction, null, undefined, requestDetails);

    expect(result).to.be.an('error');
    // @ts-ignore
    expect((result as JsonRpcError).code).to.equal(-32603);
    // @ts-ignore
    expect((result as JsonRpcError).message).to.contain('Test error for estimateGas');

    contractService.estimateGas = originalEstimateGas;
  });

  it('should accepts both input and data fields but copy value of input field to data field', async () => {
    const inputValue = 'input value';
    const dataValue = 'data value';
    const transaction = {
      from: '0x05fba803be258049a27b820088bab1cad2058871',
      input: inputValue,
      data: dataValue,
      value: '0xA186B8E9800',
      gasPrice: '0xF4240',
      gas: '0xd97010',
    };

    await contractService['contractCallFormat'](transaction, requestDetails);
    expect(transaction.data).to.eq(inputValue);
    expect(transaction.data).to.not.eq(dataValue);
    expect(transaction.input).to.be.undefined;
    expect(transaction.value).to.eq(1110);
    expect(transaction.gasPrice).to.eq(1000000);
    expect(transaction.gas).to.eq(14250000);
  });

  it('should keep the received accessList and not lose it before submitting to the MirrorNode', async () => {
    const transaction = {
      from: '0x05fba803be258049a27b820088bab1cad2058871',
      value: '0xA186B8E9800',
      gasPrice: '0xF4240',
      gas: '0xd97010',
      accessList: [
        {
          address: '0x05fba803be258049a27b820088bab1cad2058871',
          storageKeys: ['0x0000000000000000000000000000000000000000000000000000000000000000'],
        },
      ],
    };

    await contractService['contractCallFormat'](transaction, requestDetails);
    expect(transaction.accessList).to.have.lengthOf(1);
    expect(transaction.accessList[0].address).to.be.eq('0x05fba803be258049a27b820088bab1cad2058871');
    expect(transaction.accessList[0].storageKeys).to.have.lengthOf(1);
    expect(transaction.accessList[0].storageKeys[0]).to.be.eq(
      '0x0000000000000000000000000000000000000000000000000000000000000000',
    );
  });

  describe('eth_estimateGas with mirror node 5xx server errors', function () {
    const serverErrorStatusCodes = [429, 500, 501, 502, 503, 504];

    serverErrorStatusCodes.forEach((statusCode) => {
      it(`should throw COULD_NOT_SIMULATE_TRANSACTION when mirror node returns ${statusCode} status code`, async function () {
        const callData: IContractCallRequest = {
          from: '0x05fba803be258049a27b820088bab1cad2058871',
          to: RECEIVER_ADDRESS,
        };

        await mockContractCall(
          callData,
          true,
          statusCode,
          { errorMessage: `Server error ${statusCode}`, statusCode },
          requestDetails,
        );

        const expectedError = predefined.COULD_NOT_SIMULATE_TRANSACTION(
          `Request failed with status code ${statusCode}`,
        );
        await expect(ethImpl.estimateGas(callData, null, undefined, requestDetails))
          .to.be.rejectedWith(JsonRpcError, expectedError.message)
          .and.eventually.have.property('code', expectedError.code);
      });
    });
  });

  describe('state overrides', () => {
    const OVERRIDE_ADDRESS = `0x${'ab'.repeat(20)}`;
    const callObject = { to: OVERRIDE_ADDRESS, data: '0x01' };

    const dispatch = async (params: unknown[]): Promise<void> => {
      const args = Utils.arrangeRpcParams(
        ethImpl.estimateGas as Parameters<typeof Utils.arrangeRpcParams>[0],
        params,
        requestDetails,
      );
      await (ethImpl.estimateGas as (...methodArgs: unknown[]) => Promise<string>).apply(ethImpl, args);
    };

    describe('parameter binding', () => {
      let estimateStub: SinonStub;

      beforeEach(() => {
        estimateStub = stub(contractService, 'estimateGas').resolves('0x5208');
      });

      afterEach(() => {
        estimateStub.restore();
      });

      it('keeps requestDetails in its own argument when a state override is sent', async () => {
        const stateOverride = { [OVERRIDE_ADDRESS]: { balance: '0x1' } };
        await dispatch([callObject, 'latest', stateOverride]);

        expect(estimateStub.firstCall.args[2]).to.equal(requestDetails);
        expect(estimateStub.firstCall.args[3]).to.deep.equal(stateOverride);
      });

      it('passes no state override when the caller sends two parameters', async () => {
        await dispatch([callObject, 'latest']);

        expect(estimateStub.firstCall.args[2]).to.equal(requestDetails);
        expect(estimateStub.firstCall.args[3]).to.be.undefined;
      });
    });

    describe('error paths', () => {
      const withOverride = (): Promise<string> =>
        contractService.estimateGas({ ...callObject }, null, requestDetails, {
          [OVERRIDE_ADDRESS]: { balance: '0x1' },
        });

      it('surfaces the mirror node feature-disabled 400 without calling it a revert', async () => {
        web3Mock.onPost('contracts/call').replyOnce(400, JSON.stringify(mockData.stateOverridesNotSupported));

        const error = await withOverride().catch((e: JsonRpcError) => e);

        expect(error).to.be.instanceOf(JsonRpcError);
        expect((error as JsonRpcError).code).to.equal(predefined.COULD_NOT_SIMULATE_TRANSACTION('').code);
        expect((error as JsonRpcError).message).to.contain('State overrides are not supported.');
      });

      it('maps a mirror node 500 to COULD_NOT_SIMULATE_TRANSACTION', async () => {
        web3Mock.onPost('contracts/call').replyOnce(500, JSON.stringify(mockData.internalServerError));

        const error = await withOverride().catch((e: JsonRpcError) => e);

        expect((error as JsonRpcError).code).to.equal(predefined.COULD_NOT_SIMULATE_TRANSACTION('').code);
      });
    });

    describe('parameter rules', () => {
      const rules = (ethImpl.estimateGas as unknown as Record<string, unknown>)[
        RPC_PARAM_VALIDATION_RULES_KEY
      ] as Record<number, IParamValidation>;

      it('declares a rule for the state override parameter', () => {
        expect(rules[2]).to.deep.equal({ type: 'stateOverride', required: false });
      });

      it('rejects null, which geth accepts as "no overrides"', () => {
        expect(() => validateParams([callObject, 'latest', null], rules)).to.throw(
          'The value passed is not valid: null',
        );
      });

      it('rejects movePrecompileToAddress', () => {
        expect(() =>
          validateParams(
            [callObject, 'latest', { [OVERRIDE_ADDRESS]: { movePrecompileToAddress: OVERRIDE_ADDRESS } }],
            rules,
          ),
        ).to.throw("'movePrecompileToAddress' is not supported");
      });

      it('rejects a block override in the fourth parameter', () => {
        expect(() => validateParams([callObject, 'latest', {}, { number: '0x1' }], rules)).to.throw(
          'Block overrides are not supported',
        );
      });

      it('accepts the method being called without any override', () => {
        expect(() => validateParams([callObject, 'latest'], rules)).not.to.throw();
      });
    });

    describe('mirror node request', () => {
      const postedBody = async (stateOverride?: StateOverrideSet): Promise<IContractCallRequest> => {
        web3Mock.onPost('contracts/call').replyOnce(200, JSON.stringify({ result: '0x5208' }));
        web3Mock.resetHistory();

        await contractService.estimateGas({ ...callObject }, null, requestDetails, stateOverride);

        return JSON.parse(web3Mock.history.post[0].data);
      };

      it('sends the translated override set as state_overrides', async () => {
        const body = await postedBody({ [OVERRIDE_ADDRESS]: { balance: '0x2540be400' } });

        expect(body.state_overrides).to.deep.equal([{ address: OVERRIDE_ADDRESS, balance: '0x1' }]);
        expect(body.estimate).to.be.true;
      });

      it('omits state_overrides when no override is passed', async () => {
        const body = await postedBody();

        expect(body).to.not.have.property('state_overrides');
      });
    });
  });
});
