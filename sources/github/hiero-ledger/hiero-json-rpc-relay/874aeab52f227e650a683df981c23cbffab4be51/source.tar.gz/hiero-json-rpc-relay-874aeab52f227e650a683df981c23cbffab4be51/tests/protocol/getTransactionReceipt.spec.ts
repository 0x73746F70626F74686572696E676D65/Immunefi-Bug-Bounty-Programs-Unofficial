// SPDX-License-Identifier: Apache-2.0

import { ContractId } from '@hiero-ledger/sdk';
import { expect } from 'chai';
import { ethers } from 'ethers';

import { ConfigService } from '../../src/config-service/services';
import { predefined } from '../../src/relay';
import { numberTo0x } from '../../src/relay/formatters';
import { ONE_TINYBAR_IN_WEI_HEX } from '../relay/lib/eth/eth-config';
import type MirrorClient from '../server/clients/mirrorClient';
import type RelayClient from '../server/clients/relayClient';
import type ServicesClient from '../server/clients/servicesClient';
import basicContractJson from '../server/contracts/Basic.json';
import ERC20MockJson from '../server/contracts/ERC20Mock.json';
import parentContractJson from '../server/contracts/Parent.json';
import Assertions, {
  computeExpectedCumulativeGasUsed,
  type MirrorReceiptLike,
  type MirrorTransactionLike,
  type ReceiptResponseLike,
  type TransactionResponseLike,
} from '../server/helpers/assertions';
import Address from '../server/helpers/constants';
import { Utils } from '../server/helpers/utils';
import { type AliasAccount } from '../server/types/AliasAccount';
import { ALL_PROTOCOL_CLIENTS } from './helpers/protocolClient';

describe('@release @protocol-acceptance @protocol-acceptance-transaction-service eth_getTransactionReceipt', async function () {
  this.timeout(240 * 1000);
  const METHOD_NAME = 'eth_getTransactionReceipt';
  const CHAIN_ID = ConfigService.get('CHAIN_ID');
  const gasPriceDeviation = ConfigService.get('TEST_GAS_PRICE_DEVIATION');

  const FAKE_TX_HASH = `0x${'00'.repeat(20)}`;
  interface TransactionReceiptResponse extends ReceiptResponseLike {
    contractAddress: string | null;
  }

  interface MirrorReceiptResult {
    hash: string;
    address: string;
    block_hash: string;
    transaction_index: number;
  }

  const INVALID_PARAMS: unknown[][] = [
    [],
    [''],
    [39],
    [63],
    [true],
    ['abc'],
    [false],
    ['0xhbar'],
    ['0xHedera'],
    [FAKE_TX_HASH, 'hbar'],
    [FAKE_TX_HASH, 'rpc', 'invalid'],
  ];

  // @ts-ignore
  const {
    mirrorNode,
    relay,
    servicesNode,
    initialBalance,
  }: { mirrorNode: MirrorClient; relay: RelayClient; servicesNode: ServicesClient; initialBalance: string } = global;

  const accounts: AliasAccount[] = [];
  let txHash: string;
  let expectedTxReceipt: MirrorReceiptResult;
  let parentContractAddress: string;
  let htsAddress: string;
  let accountToAccountTxHash: string;
  let relayContractTransferTxHash: string;
  let relayContractTransferTo: string;
  let htsTransferTxHash: string;

  const defaultGasPrice = numberTo0x(Assertions.defaultGasPrice);
  const defaultGasLimit = numberTo0x(3_000_000);

  const default155TransactionData = {
    value: ONE_TINYBAR_IN_WEI_HEX,
    gasPrice: defaultGasPrice,
    gasLimit: defaultGasLimit,
    chainId: Number(CHAIN_ID),
  };

  const defaultLondonTransactionData = {
    value: ONE_TINYBAR_IN_WEI_HEX,
    chainId: Number(CHAIN_ID),
    maxPriorityFeePerGas: defaultGasPrice,
    maxFeePerGas: defaultGasPrice,
    gasLimit: defaultGasLimit,
    type: 2,
  };

  const defaultLegacy2930TransactionData = {
    value: ONE_TINYBAR_IN_WEI_HEX,
    chainId: Number(CHAIN_ID),
    gasPrice: defaultGasPrice,
    gasLimit: defaultGasLimit,
    type: 1,
  };

  async function getGasWithDeviation(): Promise<number> {
    const gasPrice = await relay.gasPrice();
    return gasPrice * (1 + gasPriceDeviation);
  }

  before(async () => {
    accounts.push(...(await Utils.createMultipleAliasAccounts(mirrorNode, global.accounts[0], 3, initialBalance)));
    global.accounts.push(...accounts);

    const [parentContract, tokenId] = await Promise.all([
      Utils.deployContract(parentContractJson.abi, parentContractJson.bytecode, accounts[0].wallet),
      servicesNode.createToken(1000),
    ]);
    parentContractAddress = parentContract.target as string;
    htsAddress = Utils.idToEvmAddress(tokenId.toString());

    await Promise.all([accounts[0].client.associateToken(tokenId), accounts[1].client.associateToken(tokenId)]);
    await Promise.all([
      servicesNode.transferToken(tokenId, accounts[0].accountId, 10),
      servicesNode.transferToken(tokenId, accounts[1].accountId, 10),
    ]);

    // Pre-send a simple transfer for the happy-path receipt assertions
    const tx = {
      value: ONE_TINYBAR_IN_WEI_HEX,
      gasLimit: numberTo0x(30000),
      chainId: Number(CHAIN_ID),
      to: accounts[1].address,
      nonce: await relay.getAccountNonce(accounts[0].address),
      maxFeePerGas: await relay.gasPrice(),
    };
    const signedTx = await accounts[0].wallet.signTransaction(tx);
    txHash = await relay.sendRawTransaction(signedTx);
    expectedTxReceipt = await mirrorNode.get(`/contracts/results/${txHash}`);

    const accountToAccountTx = await accounts[0].wallet.sendTransaction({
      to: accounts[1].wallet,
      value: ethers.parseEther('1'),
    });
    await accountToAccountTx.wait();
    accountToAccountTxHash = accountToAccountTx.hash;

    const relayContract = await Utils.deployContractWithEthers([], basicContractJson, accounts[0].wallet, relay);
    const relayContractTransferTx = await accounts[0].wallet.sendTransaction({
      to: relayContract.target,
      value: ethers.parseEther('1'),
    });
    await relayContractTransferTx.wait();
    relayContractTransferTxHash = relayContractTransferTx.hash;
    relayContractTransferTo = relayContract.target as string;

    const tokenAsERC20 = new ethers.Contract(htsAddress, ERC20MockJson.abi, accounts[0].wallet);
    const htsTransferTx = await tokenAsERC20.transfer(accounts[1].wallet.address, 1, await Utils.gasOptions());
    await htsTransferTx.wait();
    htsTransferTxHash = htsTransferTx.hash;
  });

  after(async () => {
    if (global?.socketServer) {
      expect(global.socketServer._connections).to.eq(0);
    }
  });

  for (const client of ALL_PROTOCOL_CLIENTS) {
    describe(client.label, () => {
      const getTxData = async (
        hash: string,
      ): Promise<{
        txByHash: TransactionResponseLike & { to: string };
        receipt: ReceiptResponseLike;
        mirrorResult: MirrorTransactionLike & MirrorReceiptLike;
      }> => {
        const [txByHash, receipt, mirrorResult] = await Promise.all([
          client.call('eth_getTransactionByHash', [hash]),
          client.call(METHOD_NAME, [hash]),
          mirrorNode.get(`/contracts/results/${hash}`),
        ]);

        return {
          txByHash: txByHash as TransactionResponseLike & { to: string },
          receipt: receipt as ReceiptResponseLike,
          mirrorResult,
        };
      };

      it('@release Should execute eth_getTransactionReceipt and handle valid requests correctly', async () => {
        const txReceipt = (await client.call(METHOD_NAME, [txHash])) as TransactionReceiptResponse;
        expect(txReceipt.to).to.be.eq(accounts[1].address.toLowerCase());
        expect(txReceipt.from).to.be.eq(accounts[0].address.toLowerCase());
        expect(txReceipt.transactionHash).to.be.eq(expectedTxReceipt.hash);
        expect(txReceipt.contractAddress).to.be.null;
        expect(txReceipt.blockHash).to.be.eq(expectedTxReceipt.block_hash.slice(0, 66));
        expect(Number(txReceipt.transactionIndex)).to.be.eq(expectedTxReceipt.transaction_index);
      });

      it('from/to Addresses in transaction between accounts are in evm format', async function () {
        const { txByHash, receipt, mirrorResult } = await getTxData(accountToAccountTxHash);
        mirrorResult.from = accounts[0].wallet.address;
        mirrorResult.to = accounts[1].wallet.address;

        const currentPrice = await relay.gasPrice();
        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);
        Assertions.transaction(txByHash, mirrorResult);
        Assertions.transactionReceipt(receipt, mirrorResult, currentPrice, expectedCumulativeGasUsed);

        Assertions.evmAddress(txByHash.from);
        Assertions.evmAddress(txByHash.to);
        Assertions.evmAddress(receipt.from);
        Assertions.evmAddress(receipt.to);
      });

      it('from/to Addresses in transaction to a contract (deployed through the relay) are in evm and long-zero format', async function () {
        const { txByHash, receipt, mirrorResult } = await getTxData(relayContractTransferTxHash);
        mirrorResult.from = accounts[0].wallet.address;
        mirrorResult.to = relayContractTransferTo;

        const currentPrice = await relay.gasPrice();
        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);
        Assertions.transaction(txByHash, mirrorResult);
        Assertions.transactionReceipt(receipt, mirrorResult, currentPrice, expectedCumulativeGasUsed);

        Assertions.evmAddress(txByHash.from);
        Assertions.evmAddress(txByHash.to);
        Assertions.evmAddress(receipt.from);
        Assertions.evmAddress(receipt.to);
      });

      // Should be revised or deleted https://github.com/hiero-ledger/hiero-json-rpc-relay/pull/1726/files#r1320363677
      xit('from/to Addresses in transaction to a contract (deployed through HAPI tx) are in evm and long-zero format', async function () {
        const mirrorNodeContractRes = await mirrorNode.get(`/contracts/${parentContractAddress}`);
        const parentContractId = ContractId.fromString(mirrorNodeContractRes.contract_id);
        const parentContractLongZeroAddress = `0x${parentContractId.toEvmAddress()}`;

        const tx = await accounts[0].wallet.sendTransaction({
          to: parentContractLongZeroAddress,
          value: ethers.parseEther('1'),
        });

        await tx.wait();

        const { txByHash, receipt, mirrorResult } = await getTxData(tx.hash);

        mirrorResult.from = accounts[0].wallet.address;
        mirrorResult.to = parentContractLongZeroAddress;
        const currentPrice = await relay.gasPrice();
        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);

        Assertions.transaction(txByHash, mirrorResult);
        Assertions.transactionReceipt(receipt, mirrorResult, currentPrice, expectedCumulativeGasUsed);

        Assertions.evmAddress(txByHash.from);
        Assertions.longZeroAddress(txByHash.to);
        Assertions.evmAddress(receipt.from);
        Assertions.longZeroAddress(receipt.to);
      });

      it('from/to Addresses when transferring HTS tokens to the tokenAddress are in evm and long-zero format', async function () {
        const { txByHash, receipt, mirrorResult } = await getTxData(htsTransferTxHash);
        mirrorResult.from = accounts[0].wallet.address;
        receipt.logs = [];
        mirrorResult.logs = [];

        const currentPrice = await relay.gasPrice();
        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);
        Assertions.transaction(txByHash, mirrorResult);
        Assertions.transactionReceipt(receipt, mirrorResult, currentPrice, expectedCumulativeGasUsed);

        Assertions.evmAddress(txByHash.from);
        Assertions.longZeroAddress(txByHash.to);
        Assertions.evmAddress(receipt.from);
        Assertions.longZeroAddress(receipt.to);
      });

      it('@release-light, @release should execute "eth_getTransactionReceipt" for hash of legacy transaction', async () => {
        const gasPriceWithDeviation = await getGasWithDeviation();
        const transaction = {
          ...default155TransactionData,
          to: parentContractAddress,
          nonce: await relay.getAccountNonce(accounts[2].address),
          gasPrice: gasPriceWithDeviation,
          type: 0,
        };

        const signedTx = await accounts[2].wallet.signTransaction(transaction);
        const legacyTxHash = await relay.sendRawTransaction(signedTx);
        const mirrorResult = await mirrorNode.get(`/contracts/results/${legacyTxHash}`);
        mirrorResult.from = accounts[2].wallet.address;
        mirrorResult.to = parentContractAddress;

        const res = (await client.call(METHOD_NAME, [legacyTxHash])) as TransactionReceiptResponse;
        const currentPrice = await relay.gasPrice();
        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);

        Assertions.transactionReceipt(res, mirrorResult, currentPrice, expectedCumulativeGasUsed);
      });

      it('@release-light, @release should execute "eth_getTransactionReceipt" for hash of London transaction', async () => {
        const gasPriceWithDeviation = await getGasWithDeviation();
        const transaction = {
          ...defaultLondonTransactionData,
          to: parentContractAddress,
          nonce: await relay.getAccountNonce(accounts[2].address),
          maxFeePerGas: gasPriceWithDeviation,
          maxPriorityFeePerGas: gasPriceWithDeviation,
        };

        const signedTx = await accounts[2].wallet.signTransaction(transaction);
        const transactionHash = await relay.sendRawTransaction(signedTx);
        const mirrorResult = await mirrorNode.get(`/contracts/results/${transactionHash}`);
        mirrorResult.from = accounts[2].wallet.address;
        mirrorResult.to = parentContractAddress;

        const res = (await client.call(METHOD_NAME, [transactionHash])) as TransactionReceiptResponse;
        const currentPrice = await relay.gasPrice();
        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);

        Assertions.transactionReceipt(res, mirrorResult, currentPrice, expectedCumulativeGasUsed);
      });

      it('@release-light, @release should execute "eth_getTransactionReceipt" for hash of 2930 transaction', async () => {
        const gasPriceWithDeviation = await getGasWithDeviation();

        // Use all 3 accounts so companion transactions have independent nonces and can be sent
        // simultaneously without ordering constraints. accounts[2] sends the test transaction.
        const signers = [accounts[0], accounts[1], accounts[2]];
        const nonces = await Promise.all(signers.map((a) => relay.getAccountNonce(a.address)));

        const signedTxs = await Promise.all(
          signers.map((signer, i) =>
            signer.wallet.signTransaction({
              ...defaultLegacy2930TransactionData,
              to: parentContractAddress,
              nonce: nonces[i],
              gasPrice: gasPriceWithDeviation,
            }),
          ),
        );

        const allHashes = await Promise.all(signedTxs.map((signed) => relay.sendRawTransaction(signed)));
        const transactionHash = allHashes[2]; // accounts[2] is the test subject

        await Promise.all(allHashes.map((h) => relay.pollForValidTransactionReceipt(h)));

        const mirrorResult = await mirrorNode.get(`/contracts/results/${transactionHash}`);
        mirrorResult.from = accounts[2].wallet.address;
        mirrorResult.to = parentContractAddress;

        const expectedCumulativeGasUsed = await computeExpectedCumulativeGasUsed(mirrorNode, mirrorResult);

        const res = (await client.call(METHOD_NAME, [transactionHash])) as TransactionReceiptResponse;
        const currentPrice = await relay.gasPrice();

        Assertions.transactionReceipt(res, mirrorResult, currentPrice, expectedCumulativeGasUsed);
      });

      it('should execute "eth_getTransactionReceipt" for non-existing hash', async () => {
        const res = await client.call(METHOD_NAME, [Address.NON_EXISTING_TX_HASH]);
        expect(res).to.be.null;
      });

      it('should execute "eth_getTransactionReceipt" and set "to" field to null for direct contract deployment', async () => {
        const basicContract = await Utils.deployContract(
          basicContractJson.abi,
          basicContractJson.bytecode,
          accounts[0].wallet,
        );

        const contractDeploymentTx = basicContract.deploymentTransaction();
        if (!contractDeploymentTx) {
          throw new Error('Deployment transaction is null');
        }
        await relay.pollForValidTransactionReceipt(contractDeploymentTx.hash);

        const contractDeploymentReceipt = (await client.call(METHOD_NAME, [
          contractDeploymentTx.hash,
        ])) as TransactionReceiptResponse;
        expect(contractDeploymentReceipt).to.exist;
        expect(contractDeploymentReceipt.contractAddress).to.not.be.null;
        expect(contractDeploymentReceipt.to).to.be.null;
      });

      it('should execute "eth_getTransactionReceipt" and set "contractAddress" to null for a call to a contract', async () => {
        const receipt = (await client.call(METHOD_NAME, [relayContractTransferTxHash])) as TransactionReceiptResponse;

        expect(receipt).to.exist;
        expect(receipt.to.toLowerCase()).to.equal(relayContractTransferTo.toLowerCase());
        expect(receipt.contractAddress).to.be.null;
      });

      it('@release should fail to execute "eth_getTransactionReceipt" for hash of London transaction', async () => {
        const gasPrice = await relay.gasPrice();
        const transaction = {
          ...defaultLondonTransactionData,
          to: parentContractAddress,
          nonce: await relay.getAccountNonce(accounts[2].address),
          maxFeePerGas: gasPrice,
          maxPriorityFeePerGas: gasPrice,
        };

        const signedTx = await accounts[2].wallet.signTransaction(transaction);
        const response = await client.callRaw('eth_sendRawTransaction', [signedTx + '11']);
        expect(response.error).to.exist;
        expect(response.error!.code).to.equal(predefined.INVALID_ARGUMENTS('unexpected junk after rlp payload').code);
      });

      for (const params of INVALID_PARAMS) {
        it(`Should fail eth_getTransactionReceipt and throw INVALID_PARAMETERS if the request's params variable is invalid. params=[${params}]`, async () => {
          const response = await client.callRaw(METHOD_NAME, params);
          expect(response.error).to.exist;
          expect(response.error!.code).to.be.oneOf([-32000, -32602, -32603]);
        });
      }
    });
  }
});
