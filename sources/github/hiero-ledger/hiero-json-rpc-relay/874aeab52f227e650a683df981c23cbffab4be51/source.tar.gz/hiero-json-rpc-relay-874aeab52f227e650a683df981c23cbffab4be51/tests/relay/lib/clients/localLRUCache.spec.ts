// SPDX-License-Identifier: Apache-2.0

import chai, { expect } from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { Registry } from 'prom-client';
import sinon from 'sinon';

import { LocalLRUCache } from '../../../../src/relay/lib/clients';
import { overrideEnvsInMochaDescribe, withOverriddenEnvsInMochaTest } from '../../helpers';

chai.use(chaiAsPromised);

describe('LocalLRUCache Test Suite', async function () {
  this.timeout(10000);
  const logger = {
    child: sinon.stub().returnsThis(),
    trace: sinon.stub(),
    isLevelEnabled: sinon.stub().returns(true),
  };
  const registry = new Registry();
  const callingMethod = 'localLRUCacheTest';

  let localLRUCache: LocalLRUCache;

  this.beforeAll(() => {
    localLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry);
  });

  this.beforeEach(() => {
    localLRUCache.clear();
  });

  describe('verify simple cache', async function () {
    it('get on empty cache return null', async function () {
      const cacheValue = await localLRUCache.get('test', callingMethod);
      expect(cacheValue).to.be.null;
    });

    it('get on valid string cache returns non null', async function () {
      const key = 'key';
      const expectedValue = 'value';
      await localLRUCache.set(key, expectedValue, callingMethod);
      const cacheValue = await localLRUCache.get(key, callingMethod);
      expect(cacheValue).to.be.equal(expectedValue);
    });

    it('get on valid int cache returns non null', async function () {
      const key = 'key';
      const expectedValue = 1;
      await localLRUCache.set(key, expectedValue, callingMethod);
      const cacheValue = await localLRUCache.get(key, callingMethod);
      expect(cacheValue).to.be.equal(expectedValue);
    });

    it('get on valid false boolean cache returns non null', async function () {
      const key = 'key';
      const expectedValue = false;
      await localLRUCache.set(key, expectedValue, callingMethod);
      const cacheValue = await localLRUCache.get(key, callingMethod);
      expect(cacheValue).to.be.equal(expectedValue);
    });

    it('get on valid true boolean cache returns non null', async function () {
      const key = 'key';
      const expectedValue = true;
      await localLRUCache.set(key, expectedValue, callingMethod);
      const cacheValue = await localLRUCache.get(key, callingMethod);
      expect(cacheValue).to.be.equal(expectedValue);
    });

    it('get on valid object cache returns non null', async function () {
      const key = 'key';
      const expectedValue = { key: 'value' };
      await localLRUCache.set(key, expectedValue, callingMethod);
      const cacheValue = await localLRUCache.get(key, callingMethod);
      expect(cacheValue).to.be.equal(expectedValue);
    });

    it('delete a valid object', async function () {
      const key = 'key';
      const expectedValue = { key: 'value' };
      await localLRUCache.set(key, expectedValue, callingMethod);
      const cacheValueBeforeDelete = await localLRUCache.get(key, callingMethod);
      await localLRUCache.delete(key, callingMethod);

      const cacheValueAfterDelete = await localLRUCache.get(key, callingMethod);
      expect(cacheValueBeforeDelete).to.not.be.null;
      expect(cacheValueAfterDelete).to.be.null;
    });

    it('purge stale entries from the cache', async function () {
      expect(localLRUCache.purgeStale()).to.not.throw;
    });
  });

  describe('verify cache management', async function () {
    overrideEnvsInMochaDescribe({ CACHE_MAX: 2 });

    it('verify cache size', async function () {
      const customLocalLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry);
      const keyValuePairs = {
        key1: 'value1',
        key2: 'value2',
        key3: 'value3',
      };

      Object.entries(keyValuePairs).forEach(([key, value]) => {
        customLocalLRUCache.set(key, value, callingMethod);
      });

      const key1 = await customLocalLRUCache.get('key1', callingMethod);
      const key2 = await customLocalLRUCache.get('key2', callingMethod);
      const key3 = await customLocalLRUCache.get('key3', callingMethod);
      // expect cache to have capped at max size
      expect(key1).to.be.null; // key1 should have been evicted
      expect(key2).to.be.equal(keyValuePairs.key2);
      expect(key3).to.be.equal(keyValuePairs.key3);
    });

    it('should size an instance by its maxEntries override without affecting CACHE_MAX consumers', async function () {
      const sizedCache = new LocalLRUCache(logger.child({ name: `cache` }), registry, undefined, 4);
      const sharedCache = new LocalLRUCache(logger.child({ name: `cache` }), registry);
      const keys = ['key1', 'key2', 'key3', 'key4'];

      for (const key of keys) {
        await sizedCache.set(key, key, callingMethod);
        await sharedCache.set(key, key, callingMethod);
      }

      for (const key of keys) {
        expect(await sizedCache.get(key, callingMethod), `${key} should be retained`).to.be.equal(key);
      }

      // the instance without an override is still capped at CACHE_MAX = 2
      expect(await sharedCache.get('key1', callingMethod)).to.be.null;
      expect(await sharedCache.get('key2', callingMethod)).to.be.null;
      expect(await sharedCache.get('key3', callingMethod)).to.be.equal('key3');
      expect(await sharedCache.get('key4', callingMethod)).to.be.equal('key4');
    });

    it('should fall back to CACHE_MAX when the maxEntries override is not positive', async function () {
      const customLocalLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry, undefined, 0);

      for (const key of ['key1', 'key2', 'key3']) {
        await customLocalLRUCache.set(key, key, callingMethod);
      }

      expect(await customLocalLRUCache.get('key1', callingMethod)).to.be.null;
      expect(await customLocalLRUCache.get('key2', callingMethod)).to.be.equal('key2');
      expect(await customLocalLRUCache.get('key3', callingMethod)).to.be.equal('key3');
    });

    it('should not evict reserved keys from the cache on reaching the max cache size limit', async function () {
      const reservedKeys = ['key1', 'key2'];
      const customLocalLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry, new Set(reservedKeys));
      const keyValuePairs = {
        key1: 'value1',
        key2: 'value2',
        key3: 'value3',
        key4: 'value4',
        key5: 'value5',
      };

      for (const [key, value] of Object.entries(keyValuePairs)) {
        await customLocalLRUCache.set(key, value, callingMethod);
      }

      const key1 = await customLocalLRUCache.get('key1', callingMethod);
      const key2 = await customLocalLRUCache.get('key2', callingMethod);
      const key3 = await customLocalLRUCache.get('key3', callingMethod);
      const key4 = await customLocalLRUCache.get('key4', callingMethod);
      const key5 = await customLocalLRUCache.get('key5', callingMethod);
      // expect cache to have capped at max size
      expect(key1).to.be.equal(keyValuePairs.key1); // key1 should not have been evicted, as it is a reserved key
      expect(key2).to.be.equal(keyValuePairs.key2); // key2 should not have been evicted, as it is a reserved key
      expect(key3).to.be.null; // key3 should have been evicted
      expect(key4).to.be.equal(keyValuePairs.key4);
      expect(key5).to.be.equal(keyValuePairs.key5);

      const allKeys = await customLocalLRUCache.keys('*', callingMethod);
      expect(allKeys).to.have.members(['key1', 'key2', 'key4', 'key5']);
    });

    it('verify cache LRU nature', async function () {
      const customLocalLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry);
      const key = 'key';
      let valueCount = 0; // keep track of values sets
      await customLocalLRUCache.set(key, ++valueCount, callingMethod);
      await customLocalLRUCache.set(key, ++valueCount, callingMethod);
      await customLocalLRUCache.set(key, ++valueCount, callingMethod);
      const cacheValue = await customLocalLRUCache.get(key, callingMethod);
      // expect cache to have the latest value for key
      expect(cacheValue).to.be.equal(valueCount);
    });

    it('verify cache ttl nature', async function () {
      const customLocalLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry);
      const key = 'key';
      const ttl = 100; // set ttl to 100ms
      await customLocalLRUCache.set(key, 'value', callingMethod, ttl);
      await new Promise((r) => setTimeout(r, ttl + 100)); // wait for ttl to expire
      const cacheValue = await customLocalLRUCache.get(key, callingMethod);
      expect(cacheValue).to.be.null;
    });

    // set default cache ttl to 100ms to test the default ttl will be overridden by the ttl passed in set method
    withOverriddenEnvsInMochaTest({ CACHE_TTL: 100 }, async () => {
      it('it should set without TTL if -1 is passed for TTL', async () => {
        const customLocalLRUCache = new LocalLRUCache(logger.child({ name: `cache` }), registry);
        const lruCacheSpy = sinon.spy(customLocalLRUCache['cache']);

        const key = 'key';
        const value = { intField: 1, stringField: 'string', boolField: true, arrField: [1, 2, 3] };
        const ttl = -1;

        await customLocalLRUCache.set(key, value, callingMethod, ttl);

        sinon.assert.calledOnceWithMatch(lruCacheSpy.set, `cache:${key}`, value, sinon.match({ ttl: 0 }));

        const cachedValue = await customLocalLRUCache.get(key, callingMethod);
        expect(cachedValue).equal(value);

        await new Promise((resolve) => setTimeout(resolve, customLocalLRUCache['options'].ttl + 100));

        const cachedValueAfterTTL = await customLocalLRUCache.get(key, callingMethod);
        expect(cachedValueAfterTTL).equal(value);
      });
    });
  });

  describe('KEYS Test Suite', async function () {
    it('should retrieve keys matching a glob-style pattern with *', async function () {
      const keys = ['hello', 'hallo', 'hxllo'];
      for (let i = 0; i < keys.length; i++) {
        await localLRUCache.set(keys[i], `value${i}`, callingMethod);
      }
      await expect(localLRUCache.keys('h*llo', callingMethod)).to.eventually.have.members(keys);
    });

    it('should retrieve keys matching a glob-style pattern with ?', async function () {
      const keys = ['hello', 'hallo', 'hxllo'];
      for (let i = 0; i < keys.length; i++) {
        await localLRUCache.set(keys[i], `value${i}`, callingMethod);
      }
      await expect(localLRUCache.keys('h?llo', callingMethod)).to.eventually.have.members(keys);
    });

    it('should retrieve keys matching a glob-style pattern with []', async function () {
      const key1 = 'hello';
      const key2 = 'hallo';
      const pattern = 'h[ae]llo';

      await localLRUCache.set(key1, 'value1', callingMethod);
      await localLRUCache.set(key2, 'value2', callingMethod);

      const keys = await localLRUCache.keys(pattern, callingMethod);
      expect(keys).to.include.members([key1, key2]);
    });

    it('should retrieve keys matching a glob-style pattern with [^]', async function () {
      const key1 = 'hallo';
      const key2 = 'hbllo';
      const pattern = 'h[^e]llo';

      await localLRUCache.set(key1, 'value1', callingMethod);
      await localLRUCache.set(key2, 'value2', callingMethod);

      const keys = await localLRUCache.keys(pattern, callingMethod);
      expect(keys).to.include.members([key1, key2]);
    });

    it('should retrieve keys matching a glob-style pattern with [a-b]', async function () {
      const key1 = 'hallo';
      const key2 = 'hbllo';
      const pattern = 'h[a-b]llo';

      await localLRUCache.set(key1, 'value1', callingMethod);
      await localLRUCache.set(key2, 'value2', callingMethod);

      const keys = await localLRUCache.keys(pattern, callingMethod);
      expect(keys).to.include.members([key1, key2]);
    });

    it('should retrieve keys matching a pattern with escaped special characters', async function () {
      const keys = ['h*llo', 'h?llo', 'h[llo', 'h]llo'];
      for (let i = 0; i < keys.length; i++) {
        await localLRUCache.set(keys[i], `value${i}`, callingMethod);
      }
      for (const key of keys) {
        await expect(localLRUCache.keys(key.replace(/([*?[\]])/g, '\\$1'), callingMethod)).eventually.has.members([
          key,
        ]);
      }
    });

    it('should retrieve all keys with * pattern', async function () {
      const key1 = 'firstname';
      const key2 = 'lastname';
      const key3 = 'age';
      const pattern = '*';

      await localLRUCache.set(key1, 'Jack', callingMethod);
      await localLRUCache.set(key2, 'Stuntman', callingMethod);
      await localLRUCache.set(key3, '35', callingMethod);

      const keys = await localLRUCache.keys(pattern, callingMethod);
      expect(keys).to.include.members([key1, key2, key3]);
    });
  });

  describe('incrBy', function () {
    it('increments an existing integer value', async function () {
      const key = 'counter';
      await localLRUCache.set(key, 5, callingMethod);
      const newValue = await localLRUCache.incrBy(key, 3, callingMethod);
      expect(newValue).to.equal(8);

      const stored = await localLRUCache.get(key, callingMethod);
      expect(stored).to.equal(8);
    });

    it('increments when value is zero', async function () {
      const key = 'counter';
      await localLRUCache.set(key, 0, callingMethod);
      const newValue = await localLRUCache.incrBy(key, 10, callingMethod);
      expect(newValue).to.equal(10);
    });

    it('increments when key does not exist', async function () {
      await localLRUCache.clear();
      const key = 'missing';
      const newValue = await localLRUCache.incrBy(key, 5, callingMethod);
      expect(newValue).to.equal(5);
    });
  });

  describe('lRange', function () {
    it('returns the correct range for a valid array', async function () {
      const key = 'list';
      const value = [10, 20, 30, 40];
      await localLRUCache.set(key, value, callingMethod);

      const result = await localLRUCache.lRange(key, 1, 2, callingMethod);
      expect(result).to.deep.equal([20, 30]);
    });

    it('supports negative end index', async function () {
      const key = 'list';
      const value = [10, 20, 30, 40];
      await localLRUCache.set(key, value, callingMethod);

      const result = await localLRUCache.lRange(key, 1, -1, callingMethod);
      expect(result).to.deep.equal([20, 30, 40]);
    });

    it('returns empty array when key does not exist', async function () {
      const key = 'missing';
      const result = await localLRUCache.lRange(key, 0, 10, callingMethod);
      expect(result).to.deep.equal([]);
    });

    it('throws when the value is not an array', async function () {
      const key = 'notList';
      await localLRUCache.set(key, 123, callingMethod);

      await expect(localLRUCache.lRange(key, 0, 1, callingMethod)).to.be.rejectedWith(
        `Value at key ${key} is not an array`,
      );
    });
  });

  describe('rPush', function () {
    it('pushes value to end of an existing list', async function () {
      const key = 'list';
      const initial = [1, 2];
      await localLRUCache.set(key, initial, callingMethod);

      const length = await localLRUCache.rPush(key, 3, callingMethod);
      expect(length).to.equal(3);

      const stored = await localLRUCache.get(key, callingMethod);
      expect(stored).to.deep.equal([1, 2, 3]);
    });

    it('initializes a new list when key does not exist', async function () {
      const key = 'missing';

      const length = await localLRUCache.rPush(key, 'a', callingMethod);
      expect(length).to.equal(1);

      const stored = await localLRUCache.get(key, callingMethod);
      expect(stored).to.deep.equal(['a']);
    });

    it('throws when existing value is not an array', async function () {
      const key = 'wrongType';
      await localLRUCache.set(key, 999, callingMethod);

      await expect(localLRUCache.rPush(key, 'x', callingMethod)).to.be.rejectedWith(
        `Value at key ${key} is not an array`,
      );
    });
  });
});
