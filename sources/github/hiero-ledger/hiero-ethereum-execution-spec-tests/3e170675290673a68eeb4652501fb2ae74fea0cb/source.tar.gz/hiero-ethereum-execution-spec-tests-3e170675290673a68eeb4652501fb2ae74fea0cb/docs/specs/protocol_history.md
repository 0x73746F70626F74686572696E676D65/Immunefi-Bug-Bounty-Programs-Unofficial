# Protocol History

The table below lists every mainnet Ethereum hardfork, its activation point, the EIPs it introduced, a link to its fork manifest in EELS, and the Ethereum Foundation announcement blog post.

## Mainnet hardforks

| Version and Code Name | Block No. | Released | Incl EIPs | Fork Specifications | Blog |
|-----------------------|-----------|----------|-----------|-------|-------|
| Osaka | 23935694 | 2025-12-03 | [EIP-7594] <br> [EIP-7642] <br> [EIP-7823] <br> [EIP-7825] <br> [EIP-7883] <br> [EIP-7892] <br> [EIP-7910] <br> [EIP-7917] <br> [EIP-7918] <br> [EIP-7934] <br> [EIP-7935] <br> [EIP-7939] <br> [EIP-7951] | [Hardfork Meta EIP-7607](https://eips.ethereum.org/EIPS/eip-7607) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/osaka/__init__.py) | [Blog](https://blog.ethereum.org/2025/11/06/fusaka-mainnet-announcement) |
| Prague | 22431084 | 2025-05-07 | [EIP-2537] <br> [EIP-2935] <br> [EIP-6110] <br> [EIP-7002] <br> [EIP-7251] <br> [EIP-7549] <br> [EIP-7623] <br> [EIP-7685] <br> [EIP-7691] <br> [EIP-7702] | [Hardfork Meta EIP-7600](https://eips.ethereum.org/EIPS/eip-7600) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/prague/__init__.py) | [Blog](https://blog.ethereum.org/2025/04/23/pectra-mainnet) |
| Cancun | 19426587 | 2024-03-13<br />(1710338135) | [EIP-1153](https://eips.ethereum.org/EIPS/eip-1153) </br> [EIP-4788](https://eips.ethereum.org/EIPS/eip-4788)</br> [EIP-4844](https://eips.ethereum.org/EIPS/eip-4844)</br> [EIP-5656](https://eips.ethereum.org/EIPS/eip-5656)</br> [EIP-6780](https://eips.ethereum.org/EIPS/eip-6780) </br> [EIP-7044](https://eips.ethereum.org/EIPS/eip-7044) </br> [EIP-7045](https://eips.ethereum.org/EIPS/eip-7045) </br> [EIP-7514](https://eips.ethereum.org/EIPS/eip-7514) </br> [EIP-7516](https://eips.ethereum.org/EIPS/eip-7516)| [Hardfork Meta EIP-7569](https://eips.ethereum.org/EIPS/eip-7569) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/cancun/__init__.py) | [Blog](https://blog.ethereum.org/2024/02/27/dencun-mainnet-announcement) |
| Shanghai | 17034870 | 2023-04-12<br/>(1681338455) | [EIP-3651](https://eips.ethereum.org/EIPS/eip-3651) <br/> [EIP-3855](https://eips.ethereum.org/EIPS/eip-3855) <br/> [EIP-3860](https://eips.ethereum.org/EIPS/eip-3860) <br/> [EIP-4895](https://eips.ethereum.org/EIPS/eip-4895) | [(Backfill) Meta EIP-7568](https://eips.ethereum.org/EIPS/eip-7568) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/shanghai/__init__.py) | [Blog](https://blog.ethereum.org/2023/03/28/shapella-mainnet-announcement) |
| Paris | 15537394 | 2022-09-15 | [EIP-3675](https://eips.ethereum.org/EIPS/eip-3675) <br/> [EIP-4399](https://eips.ethereum.org/EIPS/eip-4399) | [(Backfill) Meta EIP-7568](https://eips.ethereum.org/EIPS/eip-7568) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/paris/__init__.py) | [Blog](https://blog.ethereum.org/2022/08/24/mainnet-merge-announcement) |
| Gray Glacier | 15050000 | 2022-06-30 | [EIP-5133](https://eips.ethereum.org/EIPS/eip-5133) | [(Backfill) Meta EIP-7568](https://eips.ethereum.org/EIPS/eip-7568) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/gray_glacier/__init__.py) | [Blog](https://blog.ethereum.org/2022/06/16/gray-glacier-announcement/) |
| Arrow Glacier | 13773000 | 2021-12-09 | [EIP-4345](https://eips.ethereum.org/EIPS/eip-4345) | [(Backfill) Meta EIP-7568](https://eips.ethereum.org/EIPS/eip-7568) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/arrow_glacier/__init__.py) | [Blog](https://blog.ethereum.org/2021/11/10/arrow-glacier-announcement/) |
| London | 12965000 |  2021-08-05 | [EIP-1559](https://eips.ethereum.org/EIPS/eip-1559) <br> [EIP-3198](https://eips.ethereum.org/EIPS/eip-3198) <br/> [EIP-3529](https://eips.ethereum.org/EIPS/eip-3529) <br/> [EIP-3541](https://eips.ethereum.org/EIPS/eip-3541) <br> [EIP-3554](https://eips.ethereum.org/EIPS/eip-3554)| [(Backfill) Meta EIP-7568](https://eips.ethereum.org/EIPS/eip-7568) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/london/__init__.py) | [Blog](https://blog.ethereum.org/2021/07/15/london-mainnet-announcement/) |
| Berlin | 12244000 | 2021-04-15 | [EIP-2565](https://eips.ethereum.org/EIPS/eip-2565) <br/> [EIP-2929](https://eips.ethereum.org/EIPS/eip-2929) <br/> [EIP-2718](https://eips.ethereum.org/EIPS/eip-2718) <br/> [EIP-2930](https://eips.ethereum.org/EIPS/eip-2930) | ~[Hardfork Meta EIP-2070](https://eips.ethereum.org/EIPS/eip-2070)~ <br/> [(Backfill) Meta EIP-7568](https://eips.ethereum.org/EIPS/eip-7568) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/berlin/__init__.py) | [Blog](https://blog.ethereum.org/2021/03/08/ethereum-berlin-upgrade-announcement/) |
| Muir Glacier | 9200000 | 2020-01-02 | [EIP-2384](https://eips.ethereum.org/EIPS/eip-2384) | [Hardfork Meta EIP-2387](https://eips.ethereum.org/EIPS/eip-2387) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/muir_glacier/__init__.py) | [Blog](https://blog.ethereum.org/2019/12/23/ethereum-muir-glacier-upgrade-announcement/) |
| Istanbul | 9069000 | 2019-12-07 | [EIP-152](https://eips.ethereum.org/EIPS/eip-152) <br/> [EIP-1108](https://eips.ethereum.org/EIPS/eip-1108) <br/> [EIP-1344](https://eips.ethereum.org/EIPS/eip-1344) <br/> [EIP-1884](https://eips.ethereum.org/EIPS/eip-1884) <br/> [EIP-2028](https://eips.ethereum.org/EIPS/eip-2028) <br/> [EIP-2200](https://eips.ethereum.org/EIPS/eip-2200) | [Hardfork Meta EIP-1679](https://eips.ethereum.org/EIPS/eip-1679) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/istanbul/__init__.py) | [Blog](https://blog.ethereum.org/2019/11/20/ethereum-istanbul-upgrade-announcement/) |
| Petersburg | 7280000 | 2019-02-28 | [EIP-145](https://eips.ethereum.org/EIPS/eip-145) <br/> [EIP-1014](https://eips.ethereum.org/EIPS/eip-1014) <br/> [EIP-1052](https://eips.ethereum.org/EIPS/eip-1052) <br/> [EIP-1234](https://eips.ethereum.org/EIPS/eip-1234) | [Hardfork Meta EIP-1716](https://eips.ethereum.org/EIPS/eip-1716) | [Blog](https://blog.ethereum.org/2019/02/22/ethereum-constantinople-st-petersburg-upgrade-announcement/) |
| Constantinople | 7280000 | 2019-02-28 | [EIP-145](https://eips.ethereum.org/EIPS/eip-145) <br/> [EIP-1014](https://eips.ethereum.org/EIPS/eip-1014) <br/> [EIP-1052](https://eips.ethereum.org/EIPS/eip-1052) <br/> [EIP-1234](https://eips.ethereum.org/EIPS/eip-1234) <br/> [EIP-1283](https://eips.ethereum.org/EIPS/eip-1283) | [Hardfork Meta EIP-1013](https://eips.ethereum.org/EIPS/eip-1013) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/constantinople/__init__.py) | [Blog](https://blog.ethereum.org/2019/02/22/ethereum-constantinople-st-petersburg-upgrade-announcement/) |
| Byzantium | 4370000 | 2017-10-16 | [EIP-100](https://eips.ethereum.org/EIPS/eip-100) <br/> [EIP-140](https://eips.ethereum.org/EIPS/eip-140) <br/> [EIP-196](https://eips.ethereum.org/EIPS/eip-196) <br/> [EIP-197](https://eips.ethereum.org/EIPS/eip-197) <br/> [EIP-198](https://eips.ethereum.org/EIPS/eip-198) <br/> [EIP-211](https://eips.ethereum.org/EIPS/eip-211) <br/> [EIP-214](https://eips.ethereum.org/EIPS/eip-214) <br/> [EIP-649](https://eips.ethereum.org/EIPS/eip-649) <br/> [EIP-658](https://eips.ethereum.org/EIPS/eip-658) | [Hardfork Meta EIP-609](https://eips.ethereum.org/EIPS/eip-609) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/byzantium/__init__.py) | [Blog](https://blog.ethereum.org/2017/10/12/byzantium-hf-announcement/) |
| Spurious Dragon | 2675000 | 2016-11-22 | [EIP-155](https://eips.ethereum.org/EIPS/eip-155) <br/> [EIP-160](https://eips.ethereum.org/EIPS/eip-160) <br/> [EIP-161](https://eips.ethereum.org/EIPS/eip-161) <br/> [EIP-170](https://eips.ethereum.org/EIPS/eip-170) | [Hardfork Meta EIP-607](https://eips.ethereum.org/EIPS/eip-607) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/spurious_dragon/__init__.py) | [Blog](https://blog.ethereum.org/2016/11/18/hard-fork-no-4-spurious-dragon/) |
| Tangerine Whistle | 2463000 | 2016-10-18 | [EIP-150](https://eips.ethereum.org/EIPS/eip-150) | [Hardfork Meta EIP-608](https://eips.ethereum.org/EIPS/eip-608) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/tangerine_whistle/__init__.py) | [Blog](https://blog.ethereum.org/2016/10/13/announcement-imminent-hard-fork-eip150-gas-cost-changes/) |
| DAO Fork | 1920000 | 2016-07-20 |  | [Hardfork Meta EIP-779](https://eips.ethereum.org/EIPS/eip-779) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/dao_fork/__init__.py) | [Blog](https://blog.ethereum.org/2016/07/15/to-fork-or-not-to-fork/) |
| DAO Wars | aborted | aborted |  |  | [Blog](https://blog.ethereum.org/2016/06/24/dao-wars-youre-voice-soft-fork-dilemma/) |
| Homestead | 1150000 | 2016-03-14 | [EIP-2](https://eips.ethereum.org/EIPS/eip-2) <br/> [EIP-7](https://eips.ethereum.org/EIPS/eip-7) <br/> [EIP-8](https://eips.ethereum.org/EIPS/eip-8) | [Hardfork Meta EIP-606](https://eips.ethereum.org/EIPS/eip-606) <br/> [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/homestead/__init__.py) | [Blog](https://blog.ethereum.org/2016/02/29/homestead-release/) |
| Frontier Thawing | 200000 | 2015-09-07 | | | [Blog](https://blog.ethereum.org/2015/08/04/the-thawing-frontier/) |
| Frontier | 1 | 2015-07-30 | | [Fork Manifest](https://github.com/ethereum/execution-specs/blob/forks/amsterdam/src/ethereum/forks/frontier/__init__.py) | [Blog](https://blog.ethereum.org/2015/07/22/frontier-is-coming-what-to-expect-and-how-to-prepare/) |

!!! note "Activation mechanism"
    Starting with Paris, updates are no longer rolled out based on block numbers. Paris was enabled once proof-of-work Total Difficulty reached `58750000000000000000000`. As of Shanghai (at `1681338455`), upgrade activation is based on timestamps.

[EIP-2537]: https://eips.ethereum.org/EIPS/eip-2537
[EIP-2935]: https://eips.ethereum.org/EIPS/eip-2935
[EIP-6110]: https://eips.ethereum.org/EIPS/eip-6110
[EIP-7002]: https://eips.ethereum.org/EIPS/eip-7002
[EIP-7251]: https://eips.ethereum.org/EIPS/eip-7251
[EIP-7549]: https://eips.ethereum.org/EIPS/eip-7549
[EIP-7623]: https://eips.ethereum.org/EIPS/eip-7623
[EIP-7685]: https://eips.ethereum.org/EIPS/eip-7685
[EIP-7691]: https://eips.ethereum.org/EIPS/eip-7691
[EIP-7702]: https://eips.ethereum.org/EIPS/eip-7702
[EIP-7594]: https://eips.ethereum.org/EIPS/eip-7594
[EIP-7642]: https://eips.ethereum.org/EIPS/eip-7642
[EIP-7823]: https://eips.ethereum.org/EIPS/eip-7823
[EIP-7825]: https://eips.ethereum.org/EIPS/eip-7825
[EIP-7883]: https://eips.ethereum.org/EIPS/eip-7883
[EIP-7892]: https://eips.ethereum.org/EIPS/eip-7892
[EIP-7910]: https://eips.ethereum.org/EIPS/eip-7910
[EIP-7917]: https://eips.ethereum.org/EIPS/eip-7917
[EIP-7918]: https://eips.ethereum.org/EIPS/eip-7918
[EIP-7934]: https://eips.ethereum.org/EIPS/eip-7934
[EIP-7935]: https://eips.ethereum.org/EIPS/eip-7935
[EIP-7939]: https://eips.ethereum.org/EIPS/eip-7939
[EIP-7951]: https://eips.ethereum.org/EIPS/eip-7951

## Clarifications without a protocol release

Some clarifications were enabled without protocol releases:

| EIP | Block No. |
|-----|-----------|
| [EIP-2681](https://eips.ethereum.org/EIPS/eip-2681) | 0 |
| [EIP-3607](https://eips.ethereum.org/EIPS/eip-3607) | 0 |
| [EIP-7523](https://eips.ethereum.org/EIPS/eip-7523) | 15537394 |
