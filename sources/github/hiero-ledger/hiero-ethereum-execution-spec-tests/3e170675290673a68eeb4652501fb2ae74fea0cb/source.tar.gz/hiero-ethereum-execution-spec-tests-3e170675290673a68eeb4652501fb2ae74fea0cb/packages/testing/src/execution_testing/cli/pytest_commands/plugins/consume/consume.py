"""
A pytest plugin providing common functionality for consuming test fixtures.
"""

import re
import sys
import tarfile
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any, List, Optional, Sequence, Tuple, cast
from urllib.parse import urlparse

import platformdirs
import pytest
import requests
import rich

from execution_testing.cli.gen_index import (
    generate_fixtures_index,
)
from execution_testing.cli.pytest_commands.plugins.consume.simulators.helpers.test_tracker import (  # noqa: E501
    make_group_identifier,
)
from execution_testing.fixtures import (
    BaseFixture,
    BlockchainEngineXFixture,
    FixtureFormat,
)
from execution_testing.fixtures.consume import (
    IndexFile,
    TestCaseBase,
    TestCaseIndexFile,
    TestCases,
)
from execution_testing.forks import (
    get_forks,
    get_relative_fork_markers,
    get_transition_forks,
)
from execution_testing.tools.utility.versioning import (
    get_current_commit_hash_or_tag,
)

from .releases import (
    ReleaseTag,
    is_release_url,
    is_url,
    resolve_release,
)

CACHED_DOWNLOADS_DIRECTORY = (
    Path(platformdirs.user_cache_dir("ethereum-execution-spec-tests"))
    / "cached_downloads"
)


def default_input() -> str:
    """
    Directory (default) to consume generated test fixtures from. Defined as a
    function to allow for easier testing.
    """
    return "./fixtures"


def default_html_report_file_path() -> str:
    """
    Filepath (default) to store the generated HTML test report. Defined as a
    function to allow for easier testing.
    """
    return ".meta/report_consume.html"


class FixtureDownloader:
    """Handles downloading and extracting fixture archives."""

    def __init__(self, url: str, destination_folder: Path):  # noqa: D107
        self.url = url
        self.destination_folder = destination_folder
        self.parsed_url = urlparse(url)
        self.archive_name = self.strip_archive_extension(
            Path(self.parsed_url.path).name
        )

    def download_and_extract(self) -> Tuple[bool, Path]:
        """
        Download the URL and extract it locally if it hasn't already been
        downloaded.
        """
        if self.destination_folder.exists():
            return True, self.detect_extracted_directory()

        return False, self.fetch_and_extract()

    @staticmethod
    def strip_archive_extension(filename: str) -> str:
        """Remove .tar.gz or .tgz extensions from filename."""
        return filename.removesuffix(".tar.gz").removesuffix(".tgz")

    @staticmethod
    def get_cache_path(url: str, cache_folder: Path) -> Path:
        """Get the appropriate cache path for a given URL."""
        parsed_url = urlparse(url)
        archive_name = FixtureDownloader.strip_archive_extension(
            Path(parsed_url.path).name
        )

        if is_release_url(url):
            version = Path(parsed_url.path).parts[-2]
            parts = parsed_url.path.strip("/").split("/")
            org_repo = (
                f"{parts[0]}/{parts[1]}"
                if parsed_url.netloc == "github.com" and len(parts) >= 2
                else "other"
            )
            return cache_folder / org_repo / version / archive_name
        return cache_folder / "other" / archive_name

    def fetch_and_extract(self) -> Path:
        """Download and extract an archive from the given URL."""
        self.destination_folder.mkdir(parents=True, exist_ok=True)
        response = requests.get(self.url)
        response.raise_for_status()

        with tarfile.open(
            fileobj=BytesIO(response.content), mode="r:gz"
        ) as tar:
            tar.extractall(path=self.destination_folder)

        return self.detect_extracted_directory()

    def detect_extracted_directory(self) -> Path:
        """
        Detect a single top-level dir within the extracted archive, otherwise
        return destination_folder.
        """  # noqa: D200
        extracted_dirs = [
            d
            for d in self.destination_folder.iterdir()
            if d.is_dir() and d.name != ".meta"
        ]
        return (
            extracted_dirs[0]
            if len(extracted_dirs) == 1
            else self.destination_folder
        )


@dataclass
class FixturesSource:
    """Represents the source of test fixtures."""

    input_option: str
    path: Path
    url: str = ""
    release_page: str = ""
    is_local: bool = True
    is_stdin: bool = False
    was_cached: bool = False
    extract_to_local_path: bool = False

    @classmethod
    def from_input(
        cls,
        input_source: str,
        cache_folder: Optional[Path] = None,
        extract_to: Optional[Path] = None,
    ) -> "FixturesSource":
        """Determine the fixture source type and return an instance."""
        if cache_folder is None:
            cache_folder = CACHED_DOWNLOADS_DIRECTORY
        if input_source == "stdin":
            return cls(
                input_option=input_source,
                path=Path(),
                is_local=False,
                is_stdin=True,
            )
        if is_release_url(input_source):
            return cls.from_release_url(input_source, cache_folder, extract_to)
        if is_url(input_source):
            return cls.from_url(input_source, cache_folder, extract_to)
        if ReleaseTag.is_release_string(input_source):
            return cls.from_release_spec(
                input_source, cache_folder, extract_to
            )
        return cls.validate_local_path(Path(input_source))

    @classmethod
    def from_release_url(
        cls,
        url: str,
        cache_folder: Optional[Path] = None,
        extract_to: Optional[Path] = None,
    ) -> "FixturesSource":
        """Create a fixture source from a supported github repo release URL."""
        if cache_folder is None:
            cache_folder = CACHED_DOWNLOADS_DIRECTORY

        destination_folder = extract_to or FixtureDownloader.get_cache_path(
            url, cache_folder
        )
        downloader = FixtureDownloader(url, destination_folder)

        # Skip cache check for extract_to (always download fresh)
        if extract_to is not None:
            was_cached = False
            path = downloader.fetch_and_extract()
        else:
            was_cached, path = downloader.download_and_extract()

        return cls(
            input_option=url,
            path=path,
            url=url,
            release_page="",
            is_local=False,
            was_cached=was_cached,
            extract_to_local_path=extract_to is not None,
        )

    @classmethod
    def from_url(
        cls,
        url: str,
        cache_folder: Optional[Path] = None,
        extract_to: Optional[Path] = None,
    ) -> "FixturesSource":
        """Create a fixture source from a direct URL."""
        if cache_folder is None:
            cache_folder = CACHED_DOWNLOADS_DIRECTORY

        destination_folder = extract_to or FixtureDownloader.get_cache_path(
            url, cache_folder
        )
        downloader = FixtureDownloader(url, destination_folder)

        # Skip cache check for extract_to (always download fresh)
        if extract_to is not None:
            was_cached = False
            path = downloader.fetch_and_extract()
        else:
            was_cached, path = downloader.download_and_extract()

        return cls(
            input_option=url,
            path=path,
            url=url,
            release_page="",
            is_local=False,
            was_cached=was_cached,
            extract_to_local_path=extract_to is not None,
        )

    @classmethod
    def from_release_spec(
        cls,
        spec: str,
        cache_folder: Optional[Path] = None,
        extract_to: Optional[Path] = None,
    ) -> "FixturesSource":
        """
        Create a fixture source from a release spec (e.g., tests@latest).
        """
        if cache_folder is None:
            cache_folder = CACHED_DOWNLOADS_DIRECTORY
        # Resolve the spec once; the download URL and the release page
        # both derive from the same release information.
        release = resolve_release(spec)
        url = release.get_asset(ReleaseTag.from_string(spec)).url
        release_page = release.url

        destination_folder = extract_to or FixtureDownloader.get_cache_path(
            url, cache_folder
        )
        downloader = FixtureDownloader(url, destination_folder)

        # Skip cache check for extract_to (always download fresh)
        if extract_to is not None:
            was_cached = False
            path = downloader.fetch_and_extract()
        else:
            was_cached, path = downloader.download_and_extract()

        return cls(
            input_option=spec,
            path=path,
            url=url,
            release_page=release_page,
            is_local=False,
            was_cached=was_cached,
            extract_to_local_path=extract_to is not None,
        )

    @staticmethod
    def validate_local_path(path: Path) -> "FixturesSource":
        """
        Validate that a local fixture path exists and contains JSON files.
        """
        if not path.exists():
            pytest.exit(
                f"Specified fixture directory '{path}' does not exist."
            )
        if not any(path.glob("**/*.json")):
            pytest.exit(
                f"Specified fixture directory '{path}' does not contain "
                "any JSON files."
            )
        return FixturesSource(input_option=str(path), path=path)


class SimLimitBehavior:
    """Represents options derived from the `--sim.limit` argument."""

    def __init__(self, pattern: str, collectonly: bool = False):  # noqa: D107
        self.pattern = pattern
        self.collectonly = collectonly

    @staticmethod
    def _escape_id(pattern: str) -> str:
        """
        Escape regex char in the pattern; prepend and append '.*' (for `fill`
        IDs).

        The `pattern` is prefixed and suffixed with a wildcard match to allow
        `fill` test case IDs to be specified, otherwise the full `consume` test
        ID must be specified.
        """
        return f".*{re.escape(pattern)}.*"

    @classmethod
    def from_string(cls, pattern: str) -> "SimLimitBehavior":
        """
        Parse the `--sim.limit` argument and return a `SimLimitBehavior`
        instance.

        If `pattern`:
          - Is "collectonly", enable collection mode without filtering.
          - Starts with "collectonly:", enable collection mode and use the
            rest as a regex pattern.
          - Starts with "id:", treat the rest as a literal test ID and escape
            special regex chars.
          - Starts with "collectonly:id:", enable collection mode with a
            literal test ID.
        """
        if pattern == "collectonly":
            return cls(pattern=".*", collectonly=True)

        if pattern.startswith("collectonly:id:"):
            literal_id = pattern.removeprefix("collectonly:id:")
            if not literal_id:
                raise ValueError("Empty literal ID provided.")
            return cls(pattern=cls._escape_id(literal_id), collectonly=True)

        if pattern.startswith("collectonly:"):
            return cls(
                pattern=pattern.removeprefix("collectonly:"), collectonly=True
            )

        if pattern.startswith("id:"):
            literal_id = pattern.removeprefix("id:")
            if not literal_id:
                raise ValueError("Empty literal ID provided.")
            return cls(pattern=cls._escape_id(literal_id))

        return cls(pattern=pattern)


def pytest_addoption(parser: pytest.Parser) -> None:  # noqa: D103
    consume_group = parser.getgroup(
        "consume", "Arguments related to consuming fixtures via a client"
    )
    consume_group.addoption(
        "--input",
        action="store",
        dest="fixtures_source",
        default=None,
        help=(
            "Specify the JSON test fixtures source. Can be a local "
            "directory, a URL pointing to a fixtures.tar.gz archive, a "
            "release name and version in the form of `NAME@v1.2.3` "
            "(e.g. `tests@v20.0.0` or `bal-devnet@v7.0.0`, with or "
            "without the `tests-` tag prefix, and `latest` is a valid "
            "version), a bare `latest` or `vX.Y.Z` which resolves the "
            "mainnet `tests` release, or the special keyword 'stdin'. "
            f"Defaults to the following local directory: '{default_input()}'."
        ),
    )
    consume_group.addoption(
        "--cache-folder",
        action="store",
        dest="fixture_cache_folder",
        default=CACHED_DOWNLOADS_DIRECTORY,
        help=(
            "Specify the path where the downloaded fixtures are cached. "
            "Defaults to the following directory: "
            f"'{CACHED_DOWNLOADS_DIRECTORY}'."
        ),
    )
    consume_group.addoption(
        "--extract-to",
        action="store",
        dest="extract_to_folder",
        default=None,
        help=(
            "Extract downloaded fixtures to the specified directory. Only "
            "valid with 'cache' command. When used, fixtures are extracted "
            "directly to this path instead of the user's execution-spec-"
            "tests cache directory."
        ),
    )
    if "cache" in sys.argv:
        return
    consume_group.addoption(
        "--no-html",
        action="store_true",
        dest="disable_html",
        default=False,
        help=(
            "Don't generate an HTML test report (in the output directory). "
            "The --html flag can be used to specify a different path."
        ),
    )
    consume_group.addoption(
        "--sim.limit",
        action="store",
        dest="sim_limit",
        type=SimLimitBehavior.from_string,
        default=SimLimitBehavior(".*"),
        help=(
            "Filter tests by either a regex pattern or a literal test case "
            "ID. To match a test case by its exact ID, prefix the ID with "
            "`id:`. The string following `id:` will be automatically escaped "
            "so that all special regex characters are treated as literals. "
            "Without the `id:` prefix, the argument is interpreted as a "
            "Python regex pattern. To see which test cases are matched, "
            "without executing them, prefix with `collectonly:`, e.g. "
            '`--sim.limit "collectonly:.*eip4788.*fork_Prague.*"`. '
            "To list all available test case IDs, set the value to "
            "`collectonly`."
        ),
    )


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config: pytest.Config) -> None:  # noqa: D103
    """
    Pytest hook called after command line options have been parsed and before
    test collection begins.

    `@pytest.hookimpl(tryfirst=True)` is applied to ensure that this hook is
    called before the pytest-html plugin's pytest_configure to ensure that it
    uses the modified `htmlpath` option.
    """
    # Validate --extract-to usage
    if config.option.extract_to_folder is not None and "cache" not in sys.argv:
        pytest.exit(
            "The --extract-to flag is only valid with the 'cache' command."
        )
    fixtures_source: FixturesSource
    if config.option.fixtures_source is None:
        # NOTE: Setting the default value here is necessary for correct
        # stdin/piping behavior.
        fixtures_source = FixturesSource(
            input_option=default_input(), path=Path(default_input())
        )
    else:
        # NOTE: Setting `type=FixturesSource.from_input` in pytest_addoption()
        # causes the option to be evaluated twice which breaks the result of
        # `was_cached`; the work-around is to call it manually here.
        fixtures_source = FixturesSource.from_input(
            config.option.fixtures_source,
            Path(config.option.fixture_cache_folder),
            Path(config.option.extract_to_folder)
            if config.option.extract_to_folder is not None
            else None,
        )
    config.fixtures_source = fixtures_source  # type: ignore[attr-defined]
    config.fixture_source_flags = ["--input", fixtures_source.input_option]  # type: ignore[attr-defined]

    if "cache" in sys.argv and not fixtures_source:
        pytest.exit(
            "The --input flag is required when using the cache command."
        )

    if "cache" in sys.argv:
        reason = ""
        if fixtures_source.extract_to_local_path:
            reason += (
                "Fixtures downloaded and extracted to specified directory."
            )
        elif fixtures_source.was_cached:
            reason += "Fixtures already cached."
        elif not fixtures_source.is_local:
            reason += "Fixtures downloaded and cached."
        reason += f"\nPath: {fixtures_source.path}"
        reason += f"\nInput: {fixtures_source.url or fixtures_source.path}"
        if fixtures_source.release_page:
            reason += f"\nRelease page: {fixtures_source.release_page}"
        pytest.exit(
            returncode=0,
            reason=reason,
        )

    if fixtures_source.is_stdin:
        config.test_cases = TestCases.from_stream(sys.stdin)  # type: ignore[attr-defined]
        return
    index_file = fixtures_source.path / ".meta" / "index.json"
    index_file.parent.mkdir(parents=True, exist_ok=True)
    if not index_file.exists():
        rich.print(f"Generating index file [bold cyan]{index_file}[/]...")
        generate_fixtures_index(
            fixtures_source.path,
            quiet_mode=False,
            force_flag=False,
        )

    index = IndexFile.model_validate_json(index_file.read_text())
    config.test_cases = index.test_cases  # type: ignore[attr-defined]

    for fixture_format in BaseFixture.formats.values():
        config.addinivalue_line(
            "markers",
            f"{fixture_format.format_name}: "
            f"Tests in `{fixture_format.format_name}` format ",
        )

    # All forked defined within EEST
    all_forks = {
        fork
        for fork in set(get_forks()) | get_transition_forks()
        if not fork.ignore()
    }
    # Append all forks within the index file (compatibility with
    # `ethereum/tests`)
    all_forks.update(getattr(index, "forks", []))
    for fork in all_forks:
        config.addinivalue_line(
            "markers", f"{fork}: Tests for the {fork} fork"
        )

    if config.option.sim_limit:
        if config.option.dest_regex != ".*":
            pytest.exit(
                "Both the --sim.limit (via env var?) and the --regex flags "
                "are set. Please only set one of them."
            )
        config.option.dest_regex = config.option.sim_limit.pattern
        if config.option.sim_limit.collectonly:
            config.option.collectonly = True
            config.option.verbose = -1  # equivalent to -q; only print test ids

    if config.option.collectonly or config.option.markers:
        return
    if (
        not config.getoption("disable_html")
        and config.getoption("htmlpath") is None
    ):
        # generate an html report by default, unless explicitly disabled
        config.option.htmlpath = (
            config.fixtures_source.path  # type: ignore[attr-defined]
            / default_html_report_file_path()
        )


def pytest_html_report_title(report: Any) -> None:
    """Set the HTML report title (pytest-html plugin)."""
    report.title = "Consume Test Report"


def pytest_report_header(config: pytest.Config) -> List[str]:
    """Add the consume version and fixtures source to the report header."""
    source = config.fixtures_source  # type: ignore[attr-defined]
    lines = [
        f"consume ref: {get_current_commit_hash_or_tag()}",
        f"fixtures: {source.path}",
    ]
    if not source.is_local and not source.is_stdin:
        lines.append(f"fixtures url: {source.url}")
        lines.append(f"fixtures release: {source.release_page}")
    return lines


@pytest.fixture(scope="session")
def fixture_source_flags(request: pytest.FixtureRequest) -> List[str]:
    """Return the input flags used to specify the JSON test fixtures source."""
    return request.config.fixture_source_flags  # type: ignore[attr-defined]


@pytest.fixture(scope="session")
def fixtures_source(request: pytest.FixtureRequest) -> FixturesSource:  # noqa: D103
    return request.config.fixtures_source  # type: ignore[attr-defined]


def group_test_cases_by_fixture_file(
    test_cases: Sequence[TestCaseBase],
) -> Sequence[TestCaseBase]:
    """
    Return the test cases ordered so that the cases of one fixture file are
    contiguous.

    A fixture file can hold several test cases interleaved with other files
    in the index. Grouping improves cache reuse when pytest-xdist assigns
    contiguous chunks of the collection, but does not guarantee that all
    tests from a file run on one worker.

    Preserve the order within each file. For release paths, sorting groups
    cases by format and fork directory in collection order; workers can
    still execute different forks concurrently. Test cases read from stdin
    have no file and are returned unchanged.
    """
    index_cases = [
        tc for tc in test_cases if isinstance(tc, TestCaseIndexFile)
    ]
    if len(index_cases) != len(test_cases):
        return test_cases
    return sorted(index_cases, key=lambda tc: str(tc.json_path))


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    """
    Generate test cases for every test fixture in all the JSON fixture files
    within the specified fixtures directory, or read from stdin if the
    directory is 'stdin'.
    """
    if "cache" in sys.argv:
        return

    test_cases = metafunc.config.test_cases  # type: ignore[attr-defined]
    supported_fixture_formats: List[FixtureFormat] = getattr(
        metafunc.config, "supported_fixture_formats", []
    )
    is_enginex = BlockchainEngineXFixture in supported_fixture_formats
    if not is_enginex:
        # EngineX orders its collection by pre-alloc group instead, see
        # `pytest_collection_modifyitems` in the enginex plugin.
        test_cases = group_test_cases_by_fixture_file(test_cases)
    param_list = []
    for test_case in test_cases:
        if test_case.format not in supported_fixture_formats:
            continue
        fork_markers = get_relative_fork_markers(
            test_case.fork, strict_mode=False
        )

        # Build base marks (fork and format)
        marks = [getattr(pytest.mark, m) for m in fork_markers] + [
            getattr(pytest.mark, test_case.format.format_name)
        ]

        param = pytest.param(
            test_case,
            id=test_case.id,
            marks=marks,
        )
        param_list.append(param)

    if "client_type" not in metafunc.fixturenames:
        metafunc.parametrize("test_case", param_list)
        return

    clients = metafunc.config.hive_execution_clients  # type: ignore[attr-defined]
    combined = []
    for param in param_list:
        tc = cast(TestCaseBase, param.values[0])
        for ct in clients:
            marks = list(param.marks)
            if is_enginex:
                assert tc.pre_hash is not None
                marks.append(
                    pytest.mark.xdist_group(
                        name=make_group_identifier(tc.pre_hash, ct.name)
                    )
                )
            combined.append(
                pytest.param(
                    tc,
                    ct,
                    id=f"{tc.id}-{ct.name}",
                    marks=marks,
                )
            )
    metafunc.parametrize("test_case,client_type", combined)
