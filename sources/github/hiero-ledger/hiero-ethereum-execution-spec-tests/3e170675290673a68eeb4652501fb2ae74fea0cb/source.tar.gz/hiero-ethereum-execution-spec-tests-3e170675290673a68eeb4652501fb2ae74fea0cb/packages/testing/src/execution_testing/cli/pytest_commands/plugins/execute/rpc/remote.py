"""Pytest plugin to run the execute in remote-rpc-mode."""

from pathlib import Path

import pytest

from execution_testing.forks import Fork, TransitionFork
from execution_testing.rpc import EngineRPC, EthRPC
from execution_testing.test_types.chain_config_types import (
    ChainConfigDefaults,
)

from ...shared.helpers import get_rpc_endpoint, is_help_or_collectonly_mode
from .chain_builder_eth_rpc import ChainBuilderEthRPC, TestingRPC


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add command-line options to pytest."""
    remote_rpc_group = parser.getgroup(
        "remote_rpc", "Arguments defining remote RPC configuration"
    )
    remote_rpc_group.addoption(
        "--rpc-endpoint",
        required=False,
        action="store",
        dest="rpc_endpoint",
        default=None,
        help="RPC endpoint to an execution client.",
    )
    remote_rpc_group.addoption(
        "--tx-wait-timeout",
        action="store",
        dest="tx_wait_timeout",
        type=int,
        default=60,
        help=(
            "Maximum time in seconds to wait for a transaction to be "
            "included in a block"
        ),
    )

    engine_rpc_group = parser.getgroup(
        "engine_rpc", "Arguments defining engine RPC configuration"
    )
    engine_rpc_group.addoption(
        "--engine-endpoint",
        required=False,
        action="store",
        default=None,
        dest="engine_endpoint",
        help=(
            "Engine endpoint to an execution client, which implies that the "
            "execute command will be used to drive the chain. If not "
            "provided, it's assumed that the execution client is connected "
            "to a beacon node and the chain progresses automatically. If "
            "provided, the JWT secret must be provided as well."
        ),
    )
    engine_rpc_group.addoption(
        "--engine-jwt-secret",
        required=False,
        action="store",
        default=None,
        dest="engine_jwt_secret",
        help=(
            "JWT secret to be used to authenticate with the engine endpoint. "
            "Provided string will be converted to bytes using the UTF-8 "
            "encoding."
        ),
    )
    engine_rpc_group.addoption(
        "--engine-jwt-secret-file",
        required=False,
        action="store",
        default=None,
        dest="engine_jwt_secret_file",
        help=(
            "Path to a file containing the JWT secret to be used to "
            "authenticate with the engine endpoint. The file must contain "
            "only the JWT secret as a hex string."
        ),
    )
    engine_rpc_group.addoption(
        "--session-sync-folder",
        required=False,
        action="store",
        default=None,
        dest="session_sync_folder",
        help=(
            "Folder used to sync multiple instances of the execute command."
        ),
    )


def pytest_configure(config: pytest.Config) -> None:
    """Check if a chain ID configuration is provided."""
    if is_help_or_collectonly_mode(config):
        return

    # Verify chain ID config is consistent with the remote RPC endpoint
    rpc_endpoint = get_rpc_endpoint(config)
    if rpc_endpoint is None:
        pytest.fail(
            "RPC endpoint must be provided with the --rpc-endpoint flag or "
            "the RPC_ENDPOINT environment variable."
        )
    eth_rpc = EthRPC(rpc_endpoint)
    remote_chain_id = eth_rpc.chain_id()
    configured_chain_id = ChainConfigDefaults.chain_id
    if remote_chain_id != configured_chain_id:
        pytest.exit(
            f"Chain ID obtained from the remote RPC endpoint "
            f"({remote_chain_id}) does not match the configured chain ID "
            f"({configured_chain_id}). Please check if the chain ID is "
            "correctly configured with the --chain-id flag."
        )
    engine_endpoint = config.getoption("engine_endpoint")
    engine_rpc = None
    if engine_endpoint is not None:
        jwt_secret = config.getoption("engine_jwt_secret")
        jwt_secret_file = config.getoption("engine_jwt_secret_file")
        if jwt_secret is None and jwt_secret_file is None:
            pytest.exit(
                "JWT secret must be provided if engine endpoint is provided. "
                "Please check if the JWT secret is correctly configured "
                "with the --engine-jwt-secret or --engine-jwt-secret-file "
                "flag."
            )
        elif jwt_secret_file is not None:
            with open(jwt_secret_file, "r") as f:
                jwt_secret = f.read().strip()
            if jwt_secret.startswith("0x"):
                jwt_secret = jwt_secret[2:]
            try:
                jwt_secret = bytes.fromhex(jwt_secret)
            except ValueError:
                pytest.exit(
                    "JWT secret must be a hex string if provided as a file. "
                    "Please check if the JWT secret is correctly configured "
                    "with the --engine-jwt-secret-file flag."
                )
        if isinstance(jwt_secret, str):
            jwt_secret = jwt_secret.encode("utf-8")
        assert isinstance(jwt_secret, bytes), (
            f"JWT secret must be a bytes object, got {type(jwt_secret)}"
        )
        engine_rpc = EngineRPC(engine_endpoint, jwt_secret=jwt_secret)
        # TODO: Perform a request to the engine endpoint to verify that the JWT
        # secret is valid. Potentially could be `engine_getClientVersionV1` but
        # need to implement this in rpc.py.
    config.engine_rpc = engine_rpc  # type: ignore


@pytest.fixture(scope="session")
def engine_rpc(request: pytest.FixtureRequest) -> EngineRPC | None:
    """Execute remote command does not have access to the engine RPC."""
    return request.config.engine_rpc  # type: ignore


@pytest.fixture(autouse=True, scope="session")
def rpc_endpoint(request: pytest.FixtureRequest) -> str:
    """
    Return remote RPC endpoint to be used to make requests to the execution
    client.
    """
    rpc_endpoint = get_rpc_endpoint(request.config)
    assert rpc_endpoint is not None
    return rpc_endpoint


@pytest.fixture(autouse=True, scope="session")
def eth_rpc(
    request: pytest.FixtureRequest,
    rpc_endpoint: str,
    engine_rpc: EngineRPC | None,
    session_fork: Fork | TransitionFork,
    session_temp_folder: Path,
    max_batch_size: int | None,
    use_testing_build_block: bool,
) -> EthRPC:
    """Initialize ethereum RPC client for the execution client under test."""
    tx_wait_timeout = request.config.getoption("tx_wait_timeout")
    if engine_rpc is None:
        if use_testing_build_block:
            raise pytest.UsageError(
                "--use-testing-build-block requires "
                "--engine-endpoint to be set"
            )
        return EthRPC(
            rpc_endpoint,
            transaction_wait_timeout=tx_wait_timeout,
            max_batch_size=max_batch_size,
        )
    get_payload_wait_time = request.config.getoption("get_payload_wait_time")
    testing_rpc = None
    if use_testing_build_block:
        testing_rpc = TestingRPC(rpc_endpoint)
    session_sync_folder = request.config.getoption("session_sync_folder")
    return ChainBuilderEthRPC(
        rpc_endpoint=rpc_endpoint,
        fork=session_fork,
        engine_rpc=engine_rpc,
        session_temp_folder=Path(session_sync_folder)
        if session_sync_folder is not None
        else session_temp_folder,
        get_payload_wait_time=get_payload_wait_time,
        transaction_wait_timeout=tx_wait_timeout,
        max_batch_size=max_batch_size,
        testing_rpc=testing_rpc,
    )
