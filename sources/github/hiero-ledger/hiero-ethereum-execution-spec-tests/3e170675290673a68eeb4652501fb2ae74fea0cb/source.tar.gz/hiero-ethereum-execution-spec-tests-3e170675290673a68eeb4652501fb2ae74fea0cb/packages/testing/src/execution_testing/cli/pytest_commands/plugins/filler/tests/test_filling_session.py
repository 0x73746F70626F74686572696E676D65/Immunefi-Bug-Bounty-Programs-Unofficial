"""Unit tests for the FillingSession class."""

from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from execution_testing.base_types import Alloc
from execution_testing.fixtures import (
    FixtureFillingPhase,
    PreAllocGroupBuilder,
    PreAllocGroupBuilders,
    PreAllocGroups,
)
from execution_testing.forks import Prague
from execution_testing.test_types import AllocGroupHash, Environment

from ..filler import FillingSession


class MockConfig:
    """Mock pytest config for testing."""

    def __init__(self, **options: Any) -> None:
        """Initialize with option values."""
        self._options = options
        self.op_mode = "fill"  # Default operation mode

    def getoption(self, name: str, default: Any = None) -> Any:
        """Mock getoption method."""
        return self._options.get(name, default)


class MockFixtureOutput:
    """Mock fixture output for testing."""

    def __init__(self, pre_alloc_folder_exists: bool = True) -> None:
        """Initialize with test conditions."""
        self._folder_exists = pre_alloc_folder_exists
        self.pre_alloc_groups_folder_path = Path("/tmp/test_pre_alloc")

    @classmethod
    def from_config(cls, config: Any) -> "MockFixtureOutput":
        """Mock factory method."""
        del config
        return cls()


class TestFillingSession:
    """Test cases for FillingSession class."""

    def test_init_normal_fill(self) -> None:
        """Test initialization for normal single-phase fill."""
        config = MockConfig()

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            session = FillingSession.from_config(config)  # type: ignore[arg-type]

        assert session.filling_phase == FixtureFillingPhase.FILL
        assert session.pre_alloc_group_builders is None

    def test_init_pre_alloc_generation(self) -> None:
        """Test initialization for pre-alloc generation phase."""
        config = MockConfig(generate_pre_alloc_groups=True)

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            session = FillingSession.from_config(config)  # type: ignore[arg-type]

        assert (
            session.filling_phase == FixtureFillingPhase.PRE_ALLOC_GENERATION
        )
        assert session.pre_alloc_group_builders is not None
        assert len(session.pre_alloc_group_builders.root) == 0

    def test_init_use_pre_alloc(self) -> None:
        """Test initialization for phase 2 (using pre-alloc groups)."""
        config = MockConfig(use_pre_alloc_groups=True)

        # Mock the file system operations
        group_hash = AllocGroupHash.from_preimage("test_hash")
        test_group_builder = PreAllocGroupBuilder(
            pre=Alloc().model_dump(mode="json"),
            environment=Environment()
            .set_fork_requirements(Prague)
            .model_dump(mode="json", exclude={"parent_hash"}),
            fork=Prague.name(),
            group_hash=group_hash,
        )
        test_group = test_group_builder.build()
        mock_groups = PreAllocGroups(root={group_hash: test_group})

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            with patch.object(Path, "exists", return_value=True):
                with patch.object(
                    PreAllocGroups,
                    "from_folder",
                    return_value=mock_groups,
                ):
                    session = FillingSession.from_config(config)  # type: ignore[arg-type]

        assert (
            session.filling_phase
            == FixtureFillingPhase.FILL_AFTER_PRE_ALLOC_GENERATION
        )
        assert session.pre_alloc_groups is mock_groups

    def test_init_use_pre_alloc_missing_folder(self) -> None:
        """Test initialization fails when pre-alloc folder is missing."""
        config = MockConfig(use_pre_alloc_groups=True)

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            with patch.object(Path, "exists", return_value=False):
                with pytest.raises(
                    FileNotFoundError,
                    match="Pre-allocation groups folder not found",
                ):
                    FillingSession.from_config(config)  # type: ignore[arg-type]

    def test_should_generate_format(self) -> None:
        """Test format generation decision."""
        config = MockConfig()

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            session = FillingSession.from_config(config)  # type: ignore[arg-type]

        # Mock fixture format
        class MockFormat:
            format_phases = {
                FixtureFillingPhase.FILL,
                FixtureFillingPhase.FILL_AFTER_PRE_ALLOC_GENERATION,
            }

        assert session.should_generate_format(MockFormat())  # type: ignore[arg-type]

    def test_should_generate_format_with_generate_all(self) -> None:
        """Test format generation with generate_all_formats flag."""
        config = MockConfig(
            generate_all_formats=True, use_pre_alloc_groups=True
        )

        mock_groups = PreAllocGroups()

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            with patch.object(Path, "exists", return_value=True):
                with patch.object(
                    PreAllocGroups, "from_folder", return_value=mock_groups
                ):
                    session = FillingSession.from_config(config)  # type: ignore[arg-type]

        # Mock fixture format that normally wouldn't generate in phase 2
        class MockFormat:
            format_phases = {
                FixtureFillingPhase.FILL,
                FixtureFillingPhase.FILL_AFTER_PRE_ALLOC_GENERATION,
            }

        # Should generate because generate_all=True
        assert session.should_generate_format(MockFormat())  # type: ignore[arg-type]

    def test_get_pre_alloc_group(self) -> None:
        """Test getting a pre-alloc group by hash."""
        config = MockConfig(use_pre_alloc_groups=True)

        group_hash = AllocGroupHash.from_preimage("test_hash")
        test_group_builder = PreAllocGroupBuilder(
            pre=Alloc().model_dump(mode="json"),
            environment=Environment()
            .set_fork_requirements(Prague)
            .model_dump(mode="json", exclude={"parent_hash"}),
            fork=Prague.name(),
            group_hash=group_hash,
        )
        test_group = test_group_builder.build()
        mock_groups = PreAllocGroups(root={group_hash: test_group})

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            with patch.object(Path, "exists", return_value=True):
                with patch.object(
                    PreAllocGroups, "from_folder", return_value=mock_groups
                ):
                    session = FillingSession.from_config(config)  # type: ignore[arg-type]

        assert (
            session.get_pre_alloc_group(
                AllocGroupHash.from_preimage("test_hash")
            )
            is test_group
        )

    def test_get_pre_alloc_group_not_found(self) -> None:
        """Test getting a non-existent pre-alloc group."""
        config = MockConfig(use_pre_alloc_groups=True)

        mock_groups = PreAllocGroups()

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            with patch.object(Path, "exists", return_value=True):
                with patch.object(
                    PreAllocGroups, "from_folder", return_value=mock_groups
                ):
                    session = FillingSession.from_config(config)  # type: ignore[arg-type]

        with pytest.raises(
            ValueError, match="Pre-allocation hash .* not found"
        ):
            session.get_pre_alloc_group(
                AllocGroupHash.from_preimage("missing_hash")
            )

    def test_get_pre_alloc_group_not_initialized(self) -> None:
        """Test getting pre-alloc group when not initialized."""
        config = MockConfig()  # Normal fill, no pre-alloc groups

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            session = FillingSession.from_config(config)  # type: ignore[arg-type]

        with pytest.raises(
            ValueError, match="Pre-allocation groups not initialized"
        ):
            session.get_pre_alloc_group(
                AllocGroupHash.from_preimage("any_hash")
            )

    def test_save_pre_alloc_groups(self) -> None:
        """Test saving pre-alloc groups to disk."""
        config = MockConfig(generate_pre_alloc_groups=True)

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            session = FillingSession.from_config(config)  # type: ignore[arg-type]

        # Seed a single group directly — production seeds via
        # PreAllocGroupBuilders.add_test_pre from the per-test fill hook;
        # here we only need a non-empty mapping for save_pre_alloc_groups
        # to exercise its mkdir/to_folder path.
        assert session.pre_alloc_group_builders is not None
        group_hash = AllocGroupHash.from_preimage("test_hash")
        session.pre_alloc_group_builders.root[group_hash] = (
            PreAllocGroupBuilder(
                pre=Alloc().model_dump(mode="json"),
                environment=Environment()
                .set_fork_requirements(Prague)
                .model_dump(mode="json", exclude={"parent_hash"}),
                fork=Prague.name(),
                group_hash=group_hash,
            )
        )

        with patch.object(Path, "mkdir") as mock_mkdir:
            with patch.object(
                PreAllocGroupBuilders, "to_folder"
            ) as mock_to_folder:
                session.save_pre_alloc_groups()

        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
        mock_to_folder.assert_called_once()

    def test_save_pre_alloc_groups_none(self) -> None:
        """Test saving when no pre-alloc groups exist."""
        config = MockConfig()  # Normal fill

        with patch(
            "execution_testing.cli.pytest_commands.plugins.filler.filler.FixtureOutput",
            MockFixtureOutput,
        ):
            session = FillingSession.from_config(config)  # type: ignore[arg-type]

        # Should not raise, just return
        session.save_pre_alloc_groups()
