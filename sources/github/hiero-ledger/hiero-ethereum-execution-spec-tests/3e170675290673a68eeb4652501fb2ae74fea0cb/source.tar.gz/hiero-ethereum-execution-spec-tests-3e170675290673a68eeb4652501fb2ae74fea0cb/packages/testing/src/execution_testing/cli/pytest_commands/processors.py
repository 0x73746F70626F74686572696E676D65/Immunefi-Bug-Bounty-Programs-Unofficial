"""Argument processors for different pytest command types."""

import os
import sys
import warnings
from typing import List

import click

from .base import ArgumentProcessor


class HelpFlagsProcessor(ArgumentProcessor):
    """Processes help-related flags to provide cleaner help output."""

    def __init__(
        self, command_type: str, required_args: List[str] | None = None
    ):
        """
        Initialize the help processor.

        Args:
          command_type: The type of command (e.g., "fill", "consume",
                        "execute")
          required_args: The arguments that are required for the command to run

        """
        self.command_type = command_type
        self.required_args = required_args or []

    def process_args(self, args: List[str]) -> List[str]:
        """
        Modify help arguments to provide cleaner help output.

        This makes `--help` more useful because `pytest --help` is extremely
        verbose and lists all flags from pytest and pytest plugins.
        """
        ctx = click.get_current_context()

        if ctx.params.get("help_flag"):
            # And also add the required arguments to the help output
            return [f"--{self.command_type}-help"] + self.required_args
        elif ctx.params.get("pytest_help_flag"):
            return ["--help"]

        return args


class StdoutFlagsProcessor(ArgumentProcessor):
    """Processes stdout-related flags for the fill command."""

    def process_args(self, args: List[str]) -> List[str]:
        """
        If the user has requested to write to stdout, add pytest arguments to
        suppress pytest's test session header and summary output.
        """
        if not self._is_writing_to_stdout(args):
            return args

        # Check for incompatible xdist plugin
        if any(arg == "-n" or arg.startswith("-n=") for arg in args):
            sys.exit(
                "error: xdist-plugin not supported with --output=stdout "
                "(remove -n args)."
            )

        # Add flags to suppress pytest output when writing to stdout
        return args + ["-qq", "-s", "--no-html"]

    def _is_writing_to_stdout(self, args: List[str]) -> bool:
        """Check if the command is configured to write to stdout."""
        if any(arg == "--output=stdout" for arg in args):
            return True

        if "--output" in args:
            output_index = args.index("--output")
            if (
                output_index + 1 < len(args)
                and args[output_index + 1] == "stdout"
            ):
                return True

        return False


class HiveEnvironmentProcessor(ArgumentProcessor):
    """Processes Hive environment variables for consume commands."""

    def __init__(self, command_name: str):
        """Initialize the processor with command name to determine plugin."""
        self.command_name = command_name

    def process_args(self, args: List[str]) -> List[str]:
        """Convert hive environment variables into pytest flags."""
        modified_args = args[:]

        hive_test_pattern = os.getenv("HIVE_TEST_PATTERN")
        if hive_test_pattern and not self._has_regex_or_sim_limit(args):
            modified_args.extend(["--sim.limit", hive_test_pattern])

        hive_parallelism = os.getenv("HIVE_PARALLELISM")
        if hive_parallelism not in [
            None,
            "",
            "1",
        ] and not self._has_parallelism_flag(args):
            modified_args.extend(["-n", str(hive_parallelism)])

        # For enginex: ensure xdist uses loadgroup distribution so tests with
        # the same xdist_group marker (pre-alloc group) run on the same worker
        if self.command_name == "enginex":
            modified_args = self._ensure_loadgroup_dist(modified_args)

        if os.getenv("HIVE_RANDOM_SEED") is not None:
            warnings.warn(
                "HIVE_RANDOM_SEED is not yet supported.", stacklevel=2
            )

        if os.getenv("HIVE_LOGLEVEL") is not None:
            warnings.warn("HIVE_LOG_LEVEL is not yet supported.", stacklevel=2)

        simulator_commands = {
            "engine",
            "enginex",
            "sync",
            "rlp",
            "build_block",
        }
        if self.command_name in simulator_commands:
            modified_args.extend(
                [
                    "-p",
                    f"execution_testing.cli.pytest_commands.plugins.consume.simulators.{self.command_name}.conftest",
                ]
            )
        else:
            raise ValueError(f"Unknown command name: {self.command_name}")
        return modified_args

    def _has_regex_or_sim_limit(self, args: List[str]) -> bool:
        """Check if args already contain --regex or --sim.limit."""
        return "--regex" in args or "--sim.limit" in args

    def _has_parallelism_flag(self, args: List[str]) -> bool:
        """Check if args already contain parallelism flag."""
        return any(
            arg.startswith("-n")
            or arg == "--numprocesses"
            or arg.startswith("--numprocesses=")
            for arg in args
        )

    def _ensure_loadgroup_dist(self, args: List[str]) -> List[str]:
        """
        Ensure EngineX xdist runs keep pre-alloc groups on one worker.

        EngineX client cleanup depends on each worker seeing every test in a
        group. Any xdist distribution mode other than loadgroup can split a
        pre-alloc group across workers, causing each worker to start its own
        group client and defer cleanup until session teardown.

        `--dist=loadgroup` is inert when xdist is not active (no `-n`), so
        it is safe to ensure unconditionally.
        """
        if any("no:xdist" in arg for arg in args):
            # Without xdist, `--dist` is an unknown argument.
            return args[:]
        modified_args = args[:]
        found_dist = False
        changed_dist = False
        index = 0

        while index < len(modified_args):
            arg = modified_args[index]
            if arg == "--dist":
                found_dist = True
                if index + 1 < len(modified_args):
                    value = modified_args[index + 1]
                    if value.startswith("-"):
                        # Malformed `--dist <flag>`: leave it for
                        # argparse to reject with a clear error.
                        index += 1
                        continue
                    if value != "loadgroup":
                        modified_args[index + 1] = "loadgroup"
                        changed_dist = True
                    index += 2
                    continue
                modified_args.append("loadgroup")
                changed_dist = True
            elif arg.startswith("--dist="):
                found_dist = True
                if arg != "--dist=loadgroup":
                    modified_args[index] = "--dist=loadgroup"
                    changed_dist = True
            elif arg == "-d":
                # xdist's shorthand for `--dist=load`; it clobbers any
                # `--dist` value during pytest-xdist's cmdline hook, so
                # it must be removed rather than overridden.
                del modified_args[index]
                changed_dist = True
                continue
            index += 1

        if not found_dist:
            modified_args.extend(["--dist", "loadgroup"])
        if changed_dist:
            warnings.warn(
                "`consume enginex` requires `--dist=loadgroup`; overriding "
                "the provided xdist distribution mode.",
                stacklevel=2,
            )

        return modified_args


class WatchFlagsProcessor(ArgumentProcessor):
    """
    Processes --watch and --watcherfall flags
    for file watching functionality.
    """

    def process_args(self, args: List[str]) -> List[str]:
        """
        Remove --watch and --watcherfall
        flags from args passed to pytest.
        """
        return [arg for arg in args if arg not in ["--watch", "--watcherfall"]]


class ConsumeCommandProcessor(ArgumentProcessor):
    """Processes consume-specific command arguments."""

    def __init__(self, is_hive: bool = False):
        """
        Initialize the consume processor.

        Args:
          is_hive: Whether this is a hive-based consume command

        """
        self.is_hive = is_hive

    def process_args(self, args: List[str]) -> List[str]:
        """Process consume-specific arguments."""
        if self.is_hive:
            return self._handle_timing_data_stdout(args)
        return args

    def _handle_timing_data_stdout(self, args: List[str]) -> List[str]:
        """Ensure stdout is captured when timing data is enabled."""
        if "--timing-data" in args and "-s" not in args:
            return args + ["-s"]
        return args
