"""Nimbus Transition tool interface."""

import re
import subprocess
from pathlib import Path
from typing import ClassVar, Dict, Optional

from execution_testing.exceptions import (
    BlockException,
    ExceptionBase,
    ExceptionMapper,
    TransactionException,
)
from execution_testing.forks import Fork

from ..transition_tool import TransitionTool


class NimbusTransitionTool(TransitionTool):
    """Nimbus `evm` Transition tool interface wrapper class."""

    default_binary = Path("t8n")
    detect_binary_pattern = re.compile(r"^Nimbus-t8n\b")
    version_flag: str = "--version"

    binary: Path
    cached_version: Optional[str] = None
    trace: bool

    def __init__(
        self,
        *,
        binary: Optional[Path] = None,
        trace: bool = False,
    ):
        """Initialize the Nimbus Transition tool interface."""
        super().__init__(
            exception_mapper=NimbusExceptionMapper(),
            binary=binary,
            trace=trace,
        )
        args = [str(self.binary), "--help"]
        try:
            result = subprocess.run(args, capture_output=True, text=True)
        except subprocess.CalledProcessError as e:
            raise Exception(
                f"evm process unexpectedly returned "
                f"a non-zero status code: {e}."
            ) from e
        except Exception as e:
            raise Exception(
                f"Unexpected exception calling evm tool: {e}."
            ) from e
        self.help_string = result.stdout

    def version(self) -> str:
        """Get `evm` binary version."""
        if self.cached_version is None:
            self.cached_version = re.sub(
                r"\x1b\[0m", "", super().version()
            ).strip()

        return self.cached_version

    def is_fork_supported(self, fork: Fork) -> bool:
        """
        Return True if the fork is supported by the tool.

        If the fork is a transition fork, we want to check the fork it
        transitions to.
        """
        return fork.transition_tool_name() in self.help_string


class NimbusExceptionMapper(ExceptionMapper):
    """
    Translate between EEST exceptions and error strings returned by Nimbus.
    """

    mapping_substring: ClassVar[Dict[ExceptionBase, str]] = {
        TransactionException.TYPE_4_TX_CONTRACT_CREATION: (
            "set code transaction must not be a create transaction"
        ),
        TransactionException.TYPE_3_TX_MAX_BLOB_GAS_ALLOWANCE_EXCEEDED: (
            "would exceed maximum allowance"
        ),
        TransactionException.INSUFFICIENT_MAX_FEE_PER_BLOB_GAS: (
            "max fee per blob gas less than block blob gas fee"
        ),
        TransactionException.INSUFFICIENT_MAX_FEE_PER_GAS: (
            "max fee per gas less than block base fee"
        ),
        TransactionException.TYPE_3_TX_PRE_FORK: (
            "blob tx used but field env.ExcessBlobGas missing"
        ),
        TransactionException.TYPE_3_TX_INVALID_BLOB_VERSIONED_HASH: (
            "invalid tx: one of blobVersionedHash has invalid version"
        ),
        # TODO: temp solution until mapper for nimbus is fixed
        TransactionException.GAS_LIMIT_EXCEEDS_MAXIMUM: (
            "zero gasUsed but transactions present"
        ),
        # This message is the same as TYPE_3_TX_MAX_BLOB_GAS_ALLOWANCE_EXCEEDED
        TransactionException.TYPE_3_TX_BLOB_COUNT_EXCEEDED: (
            "exceeds maximum allowance"
        ),
        TransactionException.TYPE_3_TX_ZERO_BLOBS: (
            "blob transaction missing blob hashes"
        ),
        TransactionException.INTRINSIC_GAS_TOO_LOW: (
            "zero gasUsed but transactions present"
        ),
        TransactionException.INTRINSIC_GAS_BELOW_FLOOR_GAS_COST: (
            "intrinsic gas too low"
        ),
        TransactionException.INITCODE_SIZE_EXCEEDED: (
            "max initcode size exceeded"
        ),
        BlockException.RLP_BLOCK_LIMIT_EXCEEDED: (
            # TODO:
            "ExceededBlockSizeLimit: Exceeded block size limit"
        ),
        BlockException.INVALID_BASEFEE_PER_GAS: "invalid baseFee",
        BlockException.INVALID_BLOCK_NUMBER: (
            "Blocks must be numbered consecutively"
        ),
        BlockException.INVALID_BLOCK_TIMESTAMP_OLDER_THAN_PARENT: (
            "Invalid timestamp"
        ),
        BlockException.INVALID_GASLIMIT: "invalid gas limit",
        BlockException.INVALID_GAS_USED_ABOVE_LIMIT: (
            "gasUsed should be non negative and smaller or equal gasLimit"
        ),
        BlockException.INVALID_BLOCK_HASH: "blockhash mismatch",
        BlockException.INVALID_STATE_ROOT: "stateRoot mismatch",
        BlockException.INVALID_RECEIPTS_ROOT: "receiptRoot mismatch",
        BlockException.INVALID_LOG_BLOOM: "bloom mismatch",
    }
    mapping_regex: ClassVar[Dict[ExceptionBase, str]] = {
        TransactionException.INSUFFICIENT_ACCOUNT_FUNDS: (
            r"not enough cash to send|not enough cash for gas"
        ),
        # The message carries both nonces but never says which way the
        # comparison went, so it stands for either direction.
        TransactionException.NONCE_MISMATCH_TOO_LOW: (
            r"account nonce mismatch\. txNonce=\d+, accNonce=\d+"
        ),
        TransactionException.NONCE_MISMATCH_TOO_HIGH: (
            r"account nonce mismatch\. txNonce=\d+, accNonce=\d+"
        ),
        TransactionException.GAS_ALLOWANCE_EXCEEDED: (
            r"execution gas used exceeds limit, want: \d+, available: \d+"
        ),
        BlockException.GAS_USED_OVERFLOW: (
            r"execution gas used exceeds limit, want: \d+, available: \d+"
        ),
        BlockException.INVALID_BLOCK_ACCESS_LIST: (
            r"blockAccessListHash mismatch|"
            r"Computed block access list hash does not match|"
            r"should be unique and sorted|"
            r"A slot should not be in both changes and reads|"
            r"Each slot in storage changes must have at least"
        ),
        BlockException.INCORRECT_BLOCK_FORMAT: (
            r"should be unique and sorted"
        ),
        BlockException.BLOCK_ACCESS_LIST_GAS_LIMIT_EXCEEDED: (
            r"BAL exceeds max items cap"
        ),
    }
