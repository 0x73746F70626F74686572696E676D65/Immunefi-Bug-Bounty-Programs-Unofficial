"""Methods to work with the filesystem and json."""

import os
import stat
from json import dump
from pathlib import Path
from typing import Any, Dict

from pydantic import BaseModel, RootModel

from execution_testing.client_clis.cli_types import (
    LazyAlloc,
    TransitionToolInput,
)


def dump_files_to_directory(output_path: Path, files: Dict[str, Any]) -> None:
    """Dump the files to the given directory."""
    output_path.mkdir(parents=True, exist_ok=True)
    for file_rel_path_flags, file_contents in files.items():
        file_rel_path, flags = (
            file_rel_path_flags.split("+")
            if "+" in file_rel_path_flags
            else (file_rel_path_flags, "")
        )
        rel_path = os.path.dirname(file_rel_path)
        if rel_path:
            os.makedirs(output_path / rel_path, exist_ok=True)
        file_path = output_path / file_rel_path
        if isinstance(file_contents, LazyAlloc):
            file_contents.serialize_to_file(
                file_path, indent=4, exclude_none=True, by_alias=True
            )
        else:
            with open(file_path, "w") as f:
                if isinstance(
                    file_contents, (BaseModel, RootModel, TransitionToolInput)
                ):
                    f.write(
                        file_contents.model_dump_json(
                            indent=4,
                            exclude_none=True,
                            by_alias=True,
                        )
                    )
                elif isinstance(file_contents, str):
                    f.write(file_contents)
                else:
                    dump(file_contents, f, ensure_ascii=True, indent=4)
        if flags:
            file_mode = os.stat(file_path).st_mode
            if "x" in flags:
                file_mode |= stat.S_IEXEC
            os.chmod(file_path, file_mode)
