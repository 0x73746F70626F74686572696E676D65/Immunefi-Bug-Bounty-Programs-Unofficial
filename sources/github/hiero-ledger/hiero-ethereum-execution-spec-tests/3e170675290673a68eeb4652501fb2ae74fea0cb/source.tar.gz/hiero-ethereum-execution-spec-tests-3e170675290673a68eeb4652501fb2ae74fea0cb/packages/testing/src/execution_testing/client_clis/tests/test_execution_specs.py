"""Additional tests for the EELS t8n tool."""

import json
import os
import sysconfig
from os.path import realpath
from pathlib import Path
from shutil import which
from typing import Dict, List, Type

import pytest
from pydantic import TypeAdapter

from execution_testing.base_types import StateCommitment, to_json
from execution_testing.client_clis import (
    ExecutionSpecsTransitionTool,
    TransitionTool,
)
from execution_testing.forks import Berlin
from execution_testing.test_types import Alloc, Environment, Transaction

CURRENT_FOLDER = Path(realpath(__file__)).parent
FIXTURES_ROOT = CURRENT_FOLDER / "fixtures"
DEFAULT_EVM_T8N_BINARY_NAME = "ethereum-spec-evm-resolver"


@pytest.fixture(autouse=True)
def monkeypatch_path_for_entry_points(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """
    Monkeypatch the PATH to add the "bin" directory where entrypoints are
    installed.

    This would typically be in the venv in which pytest is running these tests
    and fill, which, with uv, is `./.venv/bin`.

    This is required in order for fill to locate the ethereum-spec-evm-resolver
    "binary" (entrypoint) when being executed using pytester.
    """
    bin_dir = sysconfig.get_path("scripts")
    monkeypatch.setenv("PATH", f"{bin_dir}:{os.environ['PATH']}")


@pytest.mark.parametrize(
    "alloc,expected_hash",
    [
        (
            {
                "0x1000000000000000000000000000000000000000": {
                    "balance": "0x0BA1A9CE0BA1A9CE",
                    "code": "0x",
                    "nonce": "0",
                    "storage": {},
                },
            },
            bytes.fromhex("51e7c7508e76dca0"),
        ),
        (
            {
                "0x1000000000000000000000000000000000000000": {
                    "balance": "0x0BA1A9CE0BA1A9CE",
                },
            },
            bytes.fromhex("51e7c7508e76dca0"),
        ),
        (
            {
                "0x1000000000000000000000000000000000000000": {
                    "balance": "0x0BA1A9CE0BA1A9CE",
                    "code": "0x",
                    "nonce": "1",
                    "storage": {},
                },
            },
            bytes.fromhex("37c2dedbdea6b3af"),
        ),
        (
            {
                "0x1000000000000000000000000000000000000000": {
                    "balance": "0",
                    "storage": {
                        "0x01": "0x01",
                    },
                },
            },
            bytes.fromhex("096122e88929baec"),
        ),
    ],
)
def test_calc_state_root(
    alloc: Dict,
    expected_hash: bytes,
) -> None:
    """Test calculation of the state root against expected hash."""
    test_alloc = Alloc(alloc)
    test_alloc.migrate_state_commitment(StateCommitment.MPT)
    assert test_alloc.state_root().startswith(expected_hash)


@pytest.mark.parametrize("evm_tool", [ExecutionSpecsTransitionTool])
@pytest.mark.parametrize(
    "binary_arg", ["no_binary_arg", "path_type", "str_type"]
)
@pytest.mark.skip(
    reason="ExecutionSpecsTransitionTool through binary path is not supported"
)
def test_evm_tool_binary_arg(
    evm_tool: Type[ExecutionSpecsTransitionTool], binary_arg: str
) -> None:
    """Test the `evm_tool` binary argument."""
    if binary_arg == "no_binary_arg":
        evm_tool().version()
        return
    elif binary_arg == "path_type":
        evm_bin = which(DEFAULT_EVM_T8N_BINARY_NAME)
        if not evm_bin:
            # typing: Path can not take None; but if None, we may
            # as well fail explicitly.
            raise Exception(
                f"Failed to find `{DEFAULT_EVM_T8N_BINARY_NAME}` "
                "in the PATH via which"
            )
        evm_tool(binary=Path(evm_bin)).version()
        return
    elif binary_arg == "str_type":
        evm_bin_str = which(DEFAULT_EVM_T8N_BINARY_NAME)
        if evm_bin_str:
            evm_tool(binary=Path(evm_bin_str)).version()
        return
    raise Exception("unknown test parameter")


transaction_type_adapter = TypeAdapter(List[Transaction])


@pytest.fixture
def alloc(test_dir: str) -> Alloc:
    """Fixture for the `alloc.json` file."""
    alloc_path = Path(FIXTURES_ROOT, test_dir, "alloc.json")
    with open(alloc_path, "r") as f:
        return Alloc.model_validate_json(f.read())


@pytest.fixture
def txs(test_dir: str) -> List[Transaction]:
    """Fixture for the `txs.json` file."""
    txs_path = Path(FIXTURES_ROOT, test_dir, "txs.json")
    with open(txs_path, "r") as f:
        return transaction_type_adapter.validate_json(f.read())


@pytest.fixture
def env(test_dir: str) -> Environment:
    """Fixture for the `env.json` file."""
    env_path = Path(FIXTURES_ROOT, test_dir, "env.json")
    with open(env_path, "r") as f:
        return Environment.model_validate_json(f.read())


@pytest.mark.parametrize("test_dir", os.listdir(path=FIXTURES_ROOT))
def test_evm_t8n(
    default_t8n: TransitionTool,
    alloc: Alloc,
    txs: List[Transaction],
    env: Environment,
    test_dir: str,
) -> None:
    """
    Test the `evaluate` method of the `ExecutionSpecsTransitionTool` class.
    """
    expected_path = Path(FIXTURES_ROOT, test_dir, "exp.json")

    with open(expected_path, "r") as exp:
        expected = json.load(exp)

        t8n_output = default_t8n.evaluate(
            transition_tool_data=TransitionTool.TransitionToolData(
                alloc=alloc,
                txs=txs,
                env=env,
                fork=Berlin,
                chain_id=1,
                reward=0,
                blob_schedule=Berlin.blob_schedule(),
            ),
        )
        assert to_json(t8n_output.alloc.materialize()) == expected.get("alloc")
        t8n_result = to_json(t8n_output.result)
        if isinstance(default_t8n, ExecutionSpecsTransitionTool):
            # The expected output was generated with geth, instead of deleting
            # any info from this expected output, the fields not returned by
            # eels are handled here.
            missing_receipt_fields = [
                "root",
                "contractAddress",
                "blockHash",
                "transactionIndex",
            ]
            for key in missing_receipt_fields:
                for i, _ in enumerate(expected.get("result")["receipts"]):
                    del expected.get("result")["receipts"][i][key]

            for i, _ in enumerate(expected.get("result")["rejected"]):
                del expected.get("result")["rejected"][i]["error"]
                del t8n_result["rejected"][i]["error"]

            if "opcodeCount" in t8n_result:
                t8n_result.pop("opcodeCount")

        assert t8n_result == expected.get("result")
