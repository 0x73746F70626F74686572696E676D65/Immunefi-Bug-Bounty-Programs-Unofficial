"""Helpers for pytest plugins."""

import os
from typing import Any, Dict, Tuple, Type

import pytest

from execution_testing.specs import BaseTest


def option_was_explicitly_set(config: pytest.Config, option_name: str) -> bool:
    """Return whether a long CLI option was passed explicitly."""
    normalized_option = option_name.strip()
    if not normalized_option.startswith("--"):
        normalized_option = f"--{normalized_option}"

    for arg in config.invocation_params.args:
        if arg == normalized_option or arg.startswith(f"{normalized_option}="):
            return True
    return False


def is_help_or_collectonly_mode(config: pytest.Config) -> bool:
    """Check if pytest is running in a help or collectonly mode."""
    # Command-specific help flags registered by the `help` plugin; each one
    # triggers a ``show_specific_help`` exit in that plugin's own
    # ``pytest_configure``. If any are set, skip heavy setup here because
    # this invocation is help-only.
    show_help_flags = (
        "show_fill_help",
        "show_fill_stateful_help",
        "show_consume_help",
        "show_execute_help",
        "show_execute_hive_help",
        "show_execute_recover_help",
        "show_execute_eth_config_help",
        "show_check_eip_versions_help",
    )
    return (
        config.getoption("markers", default=False)
        or config.getoption("collectonly", default=False)
        or config.getoption("show_ported_from", default=False)
        or config.getoption("links_as_filled", default=False)
        or config.getoption("help", default=False)
        or any(
            config.getoption(flag, default=False) for flag in show_help_flags
        )
        or config.pluginmanager.has_plugin(
            "execution_testing.cli.pytest_commands.plugins.filler.eip_checklist"
        )
        or config.pluginmanager.has_plugin(
            "execution_testing.cli.pytest_commands.plugins.filler.gen_test_doc.gen_test_doc"
        )
    )


def get_rpc_endpoint(config: pytest.Config) -> str | None:
    """Return the configured RPC endpoint or fall back to `RPC_ENDPOINT`."""
    return config.getoption("rpc_endpoint", None) or os.environ.get(
        "RPC_ENDPOINT"
    )


def get_spec_format_for_item(
    params: Dict[str, Any],
) -> Tuple[Type[BaseTest], Any]:
    """Return the spec type and execute format for the given test item."""
    for spec_type in BaseTest.spec_types.values():
        if spec_type.pytest_parameter_name() in params:
            return spec_type, params[spec_type.pytest_parameter_name()]
    raise ValueError("No spec type format found in the test item.")
