"""Sender mutex class that allows sending transactions one at a time."""

import json
import time
from pathlib import Path
from typing import Generator, Iterator, List

import pytest
from filelock import FileLock
from pytest_metadata.plugin import metadata_key

from execution_testing.base_types import Account, Address, Number, Wei
from execution_testing.forks import Fork, TransitionFork
from execution_testing.logging import get_logger
from execution_testing.recipient_type import RecipientType
from execution_testing.rpc import EthRPC
from execution_testing.rpc.rpc_types import JSONRPCError
from execution_testing.test_types import (
    EOA,
    Transaction,
    TransactionTestMetadata,
)

logger = get_logger(__name__)


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add command-line options to pytest."""
    sender_group = parser.getgroup(
        "sender",
        "Arguments for the sender key fixtures",
    )

    sender_group.addoption(
        "--seed-account-sweep-amount",
        action="store",
        dest="seed_account_sweep_amount",
        type=Wei,
        default=None,
        help="Amount of wei to sweep from the seed account to the sender account. "  # noqa: E501
        "Default=None (Entire balance)",
    )

    sender_group.addoption(
        "--sender-funding-txs-gas-price",
        action="store",
        dest="sender_funding_transactions_gas_price",
        type=Wei,
        default=None,
        help=(
            "Gas price set for the funding transactions of each worker's "
            "sender key. Default=None (1.5x current network gas price)"
        ),
    )

    sender_group.addoption(
        "--sender-fund-refund-gas-limit",
        action="store",
        dest="sender_fund_refund_gas_limit",
        type=Wei,
        default=None,
        help=(
            "Gas limit set for the funding transactions of each worker's "
            "sender key. Default=None (derived from the fork's cost of a "
            "value transfer that creates the recipient account)."
        ),
    )

    sender_group.addoption(
        "--worker-funding-timeout",
        action="store",
        dest="worker_funding_timeout",
        type=int,
        default=120,
        help=(
            "Timeout in seconds for workers waiting to be funded. Default=120"
        ),
    )


@pytest.fixture(scope="session")
def sender_funding_transactions_gas_price(
    request: pytest.FixtureRequest,
    eth_rpc: EthRPC,
) -> int:
    """Get the gas price for the funding transactions."""
    gas_price: int | None = (
        request.config.option.sender_funding_transactions_gas_price
    )
    if gas_price is None:
        network_gas_price = eth_rpc.gas_price()
        gas_price = int(network_gas_price * 1.5)
        logger.info(
            f"Using calculated gas price: {gas_price / 10**9:.9f} Gwei "
            f"(1.5x network gas price: {network_gas_price / 10**9:.9f} Gwei)"
        )
    else:
        logger.info(f"Using specified gas price: {gas_price / 10**9:.9f} Gwei")
    assert gas_price > 0, "Gas price must be greater than 0"
    return gas_price


@pytest.fixture(scope="session")
def sender_fund_refund_gas_limit(
    request: pytest.FixtureRequest,
    session_fork: Fork | TransitionFork,
) -> int:
    """
    Get the gas limit of the funding and refund transactions.

    A funding transaction creates the recipient account, which is charged
    account-creation state gas on top of the intrinsic cost, so the default
    is derived from the fork instead of being a fixed value.
    """
    gas_limit: int | None = request.config.option.sender_fund_refund_gas_limit
    if gas_limit is None:
        fork = session_fork.transitions_to()
        gas_limit = fork.transaction_intrinsic_cost_calculator()(
            sends_value=True,
            recipient_type=RecipientType.EMPTY_ACCOUNT,
        ) + fork.transaction_top_frame_state_gas(
            sends_value=True,
            recipient_type=RecipientType.EMPTY_ACCOUNT,
        )
    logger.info(f"Using gas limit for funding transactions: {gas_limit}")
    return gas_limit


@pytest.fixture(scope="session")
def seed_account_sweep_amount(request: pytest.FixtureRequest) -> int | None:
    """Get the seed account sweep amount."""
    sweep_amount = request.config.option.seed_account_sweep_amount
    if sweep_amount is not None:
        sweep_eth = sweep_amount / 10**18
        logger.info(
            f"Using specified seed account sweep amount: {sweep_eth:.18f} ETH"
        )
    else:
        logger.info(
            "No seed account sweep amount specified, will sweep entire balance"
        )
    return sweep_amount


@pytest.fixture(scope="session")
def worker_key_funding_amount(
    seed_key: EOA,
    eth_rpc: EthRPC,
    session_temp_folder: Path,
    worker_count: int,
    sender_funding_transactions_gas_price: int,
    sender_fund_refund_gas_limit: int,
    seed_account_sweep_amount: int | None,
) -> int | None:
    """
    Calculate the initial balance of each worker key.

    The way to do this is to fetch the seed key balance and divide it by the
    number of workers. This way we can ensure that each worker key has the same
    initial balance.

    We also only do this once per session, because if we try to fetch the
    balance again, it could be that another worker has already sent a
    transaction and the balance is different.

    It's not really possible to calculate the transaction costs of each test
    that each worker is going to run, so we can't really calculate the initial
    balance of each sender key based on that.

    If we are not running tests in parallel, this method is skipped since
    all tests will run from the seed account.
    """
    if worker_count <= 1:
        return None

    base_name = "worker_key_funding_amount"
    base_file = session_temp_folder / base_name
    base_lock_file = session_temp_folder / f"{base_name}.lock"

    with FileLock(base_lock_file):
        if base_file.exists():
            # Some other worker already did this for us, use that value.
            cached_amount = int(base_file.read_text())
            cached_eth = cached_amount / 10**18
            logger.info(
                f"Using cached worker key funding amount: "
                f"{cached_eth:.18f} ETH"
            )
            return cached_amount

        logger.info("Calculating worker key funding amount")
        available_amount = (
            seed_account_sweep_amount
            if seed_account_sweep_amount is not None
            # No sweep amount specified, sweep the entire balance.
            else eth_rpc.get_balance(seed_key)
        )
        amount_source = (
            "Specified sweep amount"
            if seed_account_sweep_amount is not None
            else "Seed account balance"
        )
        logger.info(
            f"{amount_source}: {available_amount / 10**18:.18f} ETH, "
            f"distributing across {worker_count} workers"
        )
        seed_sender_balance_per_worker = available_amount // worker_count
        # Calculate the cost of the transaction to send the amount.
        funding_tx_cost = (
            sender_fund_refund_gas_limit
            * sender_funding_transactions_gas_price
        )
        tx_cost_eth = funding_tx_cost / 10**18
        gas_gwei = sender_funding_transactions_gas_price / 10**9
        logger.info(
            f"Funding transaction cost: {tx_cost_eth:.18f} ETH "
            f"(gas_limit={sender_fund_refund_gas_limit}, "
            f"gas_price={gas_gwei:.9f} Gwei)"
        )
        # Subtract the cost of the transaction that is going to be sent to
        # the seed sender
        worker_key_funding_amount = (
            seed_sender_balance_per_worker - funding_tx_cost
        )
        if worker_key_funding_amount <= 0:
            avail_eth = available_amount / 10**18
            fund_cost_eth = funding_tx_cost / 10**18
            logger.error(
                f"{amount_source} is too low to distribute to "
                f"{worker_count} workers. Available: {avail_eth:.6f} ETH, "
                f"Funding cost: {fund_cost_eth:.6f} ETH"
            )
            raise AssertionError(
                f"""
                {amount_source} is too low to distribute to the
                specified number of workers ({worker_count}).
                {available_amount / 10**18:.6f} ETH,
                when distributed across all workers, and subtracting the
                funding transaction cost
                ({funding_tx_cost / 10**18:.6f} ETH), results in a zero or
                negative value.
                """
            )
        wk_fund_eth = worker_key_funding_amount / 10**18
        per_worker_eth = seed_sender_balance_per_worker / 10**18
        tx_cost_eth = funding_tx_cost / 10**18
        logger.info(
            f"Calculated worker key funding amount: {wk_fund_eth:.18f} ETH "
            f"({per_worker_eth:.18f} ETH per worker - "
            f"{tx_cost_eth:.18f} ETH transaction cost)"
        )
        # Write the value to the file for the rest of the workers to use.
        base_file.write_text(str(worker_key_funding_amount))
        return worker_key_funding_amount


@pytest.fixture(scope="session")
def session_worker_key(
    request: pytest.FixtureRequest,
    seed_key: EOA,
    worker_count: int,
    worker_key_funding_amount: int | None,
    eoa_iterator: Iterator[EOA],
    eth_rpc: EthRPC,
    session_temp_folder: Path,
    sender_funding_transactions_gas_price: int,
    sender_fund_refund_gas_limit: int,
    dry_run: bool,
) -> Generator[EOA, None, None]:
    """
    Get the key for this worker in this session that will be the account
    that funds all EOAs and contracts in the tests that this worker executes.

    Each worker will have a different key, but coordination is required
    because all worker keys come from the same seed key.

    If we are not running tests in parallel, this method simply returns the
    seed account directly.
    """
    if worker_count <= 1:
        logger.info("Not running tests in parallel, using seed key directly")
        starting_balance = eth_rpc.get_balance(seed_key)
        yield seed_key

        remaining_balance = eth_rpc.get_balance(seed_key)
        used_balance = starting_balance - remaining_balance
        logger.info(
            f"Seed {seed_key} used balance: {used_balance / 10**18:.18f} ETH "
            f"(remaining: {remaining_balance / 10**18:.18f} ETH)"
        )
        request.config.stash[metadata_key]["Senders"][str(seed_key)] = (
            f"Used balance={used_balance / 10**18:.18f}"
        )
        return None

    assert worker_key_funding_amount is not None, (
        "`worker_key_funding_amount` is None"
    )
    worker_keys_file_name = "worker_keys.json"
    worker_keys_lock_file_name = f"{worker_keys_file_name}.lock"
    worker_keys_file = session_temp_folder / worker_keys_file_name
    worker_keys_lock_file = session_temp_folder / worker_keys_lock_file_name
    worker_funded_file = session_temp_folder / "worker_keys_funded"

    worker_key = next(eoa_iterator)
    logger.info(f"Allocated worker key: {worker_key}")

    # Each worker registers its key. The last worker to register builds
    # and sends all funding transactions as a single batch.
    is_last_worker = False
    with FileLock(worker_keys_lock_file):
        if worker_keys_file.exists():
            registered_keys = json.loads(worker_keys_file.read_text())
        else:
            registered_keys = []
        registered_keys.append(str(worker_key))
        worker_keys_file.write_text(json.dumps(registered_keys))

        if len(registered_keys) == worker_count:
            is_last_worker = True
            fund_txs: List[Transaction] = []
            for i, key_str in enumerate(registered_keys):
                fund_tx = Transaction(
                    sender=seed_key,
                    to=Address(key_str),
                    gas_limit=sender_fund_refund_gas_limit,
                    gas_price=sender_funding_transactions_gas_price,
                    value=worker_key_funding_amount,
                    metadata=TransactionTestMetadata(
                        test_id="global",
                        phase="setup",
                        action="fund_eoa",
                        target="Session Worker Key",
                        tx_index=i,
                    ),
                ).with_signature_and_sender()
                fund_txs.append(fund_tx)

            if not dry_run:
                eth_rpc.send_wait_transactions(fund_txs)
                logger.info("All worker funding transactions confirmed")
            else:
                logger.info("Dry run: skipping funding transaction send")
            worker_funded_file.touch()

    if not is_last_worker:
        funding_timeout = request.config.option.worker_funding_timeout
        logger.info(
            "Waiting for all workers to be funded "
            f"(timeout={funding_timeout}s)..."
        )
        deadline = time.monotonic() + funding_timeout
        while not worker_funded_file.exists():
            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"Timed out after {funding_timeout}s waiting "
                    "for all workers to be funded"
                )
            time.sleep(0.1)
        logger.info("All workers funded, proceeding")

    # Run all tests for this worker.
    yield worker_key

    # All tests for this worker have completed, refund seed key.
    logger.info(
        f"All tests completed for worker {worker_key}, preparing refund"
    )
    worker_account = eth_rpc.get_account(worker_key, skip_code=True)
    remaining_balance = worker_account.balance
    used_balance = worker_key_funding_amount - remaining_balance
    logger.info(
        f"Worker {worker_key} used balance: {used_balance / 10**18:.18f} ETH "
        f"(remaining: {remaining_balance / 10**18:.18f} ETH)"
    )
    request.config.stash[metadata_key]["Senders"][str(worker_key)] = (
        f"Used balance={used_balance / 10**18:.18f}"
    )

    refund_gas_limit = sender_fund_refund_gas_limit
    # double the gas price to ensure the transaction is included and overwrites
    # any other transaction that might have been sent by the sender.
    refund_gas_price = sender_funding_transactions_gas_price * 2
    tx_cost = refund_gas_limit * refund_gas_price
    tx_cost_eth = tx_cost / 10**18
    gas_gwei = refund_gas_price / 10**9
    logger.debug(
        f"Refund transaction cost: {tx_cost_eth:.18f} ETH "
        f"(gas_limit={refund_gas_limit}, gas_price={gas_gwei:.9f} Gwei)"
    )

    if (remaining_balance - 1) < tx_cost:
        rem_eth = remaining_balance / 10**18
        logger.warning(
            f"Insufficient balance for refund: {rem_eth:.18f} ETH < "
            f"{tx_cost_eth:.18f} ETH (transaction cost). Skipping refund."
        )
        return

    # Update the nonce of the sender in case one of the pre-alloc transactions
    # failed
    worker_key.nonce = worker_account.nonce
    refund_value = remaining_balance - tx_cost - 1
    logger.info(
        f"Preparing refund transaction: {refund_value / 10**18:.18f} ETH "
        f"from {worker_key} to {seed_key} (nonce={worker_key.nonce})"
    )

    refund_tx = Transaction(
        sender=worker_key,
        to=seed_key,
        gas_limit=refund_gas_limit,
        gas_price=refund_gas_price,
        value=refund_value,
        metadata=TransactionTestMetadata(
            test_id="global",
            phase="cleanup",
            action="fund_eoa",
            target="Session Worker Key Refund",
            tx_index=worker_key.nonce,
        ),
    ).with_signature_and_sender()

    logger.info(
        f"Sending and waiting for refund transaction: {refund_tx.hash}"
    )
    eth_rpc.send_wait_transactions([refund_tx])
    logger.info(f"Refund transaction confirmed: {refund_tx.hash}")


def sync_worker_key_nonce(eth_rpc: EthRPC, session_worker_key: EOA) -> Account:
    """
    Synchronize the worker key nonce with the on-chain nonce.

    Fetch the account state and update the local nonce if it differs
    from the RPC nonce. This handles both nonce increases (normal
    progression) and decreases (chain reverts).

    Return the fetched account for further use.
    """
    try:
        session_worker_account = eth_rpc.get_account(
            session_worker_key, block_number="latest", skip_code=True
        )
    except JSONRPCError:
        logger.debug("Latest state not available, falling back to pending")
        session_worker_account = eth_rpc.get_account(
            session_worker_key, block_number="pending", skip_code=True
        )
    rpc_nonce = Number(session_worker_account.nonce)
    if rpc_nonce != session_worker_key.nonce:
        wk_nonce = session_worker_key.nonce
        logger.info(f"Worker key nonce mismatch: {wk_nonce} != {rpc_nonce}")
        logger.info(f"Updating worker key nonce to {rpc_nonce}")
        session_worker_key.nonce = rpc_nonce
    return session_worker_account


@pytest.fixture(scope="function")
def worker_key(
    eth_rpc: EthRPC, session_worker_key: EOA
) -> Generator[EOA, None, None]:
    """Prepare the worker key for the current test."""
    logger.debug(f"Preparing worker key {session_worker_key} for test")
    session_worker_account = sync_worker_key_nonce(eth_rpc, session_worker_key)

    # Record the start balance of the worker key
    worker_key_start_balance = session_worker_account.balance
    start_eth = worker_key_start_balance / 10**18
    logger.debug(f"Worker key start balance: {start_eth:.18f} ETH")

    yield session_worker_key

    logger.debug(
        f"Test completed, checking worker key {session_worker_key} balance"
    )
    final_balance = eth_rpc.get_balance(session_worker_key)
    used_balance = worker_key_start_balance - final_balance
    used_eth = used_balance / 10**18
    start_eth = worker_key_start_balance / 10**18
    final_eth = final_balance / 10**18
    logger.info(
        f"Worker key {session_worker_key} used balance: {used_eth:.18f} ETH "
        f"(start: {start_eth:.18f} ETH, final: {final_eth:.18f} ETH)"
    )


def pytest_sessionstart(session: pytest.Session) -> None:
    """Reset the sender info before the session starts."""
    session.config.stash[metadata_key]["Senders"] = {}
