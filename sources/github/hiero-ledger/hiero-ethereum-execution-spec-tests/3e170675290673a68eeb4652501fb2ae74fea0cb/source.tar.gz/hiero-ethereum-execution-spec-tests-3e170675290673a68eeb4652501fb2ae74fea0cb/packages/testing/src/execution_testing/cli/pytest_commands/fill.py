"""CLI entry point for the `fill` pytest-based command."""

from typing import Any, List

import click
import pytest

from .base import PytestCommand, PytestExecution, common_pytest_options
from .processors import (
    HelpFlagsProcessor,
    StdoutFlagsProcessor,
    WatchFlagsProcessor,
)
from .watcher import FileWatcher


class FillCommand(PytestCommand):
    """Pytest command for the fill operation."""

    def __init__(self, **kwargs: Any) -> None:
        """Initialize fill command with processors."""
        super().__init__(
            config_file="pytest-fill.ini",
            argument_processors=[
                HelpFlagsProcessor("fill"),
                StdoutFlagsProcessor(),
                WatchFlagsProcessor(),
            ],
            **kwargs,
        )

    def create_executions(
        self, pytest_args: List[str]
    ) -> List[PytestExecution]:
        """
        Create execution plan supporting two-phase pre-allocation group
        generation.

        Returns:
        - Phase-1-only execution when `--generate-pre-alloc-groups` is
          set without `--generate-all-formats`.
        - Single-phase execution when `--use-pre-alloc-groups` is set,
          regardless of `--generate-all-formats` (pre-alloc groups
          already exist on disk from a previous run).
        - Two-phase execution when `--generate-all-formats` is set.
        - Normal single-phase execution otherwise.

        """
        processed_args = self.process_arguments(pytest_args)
        processed_args = self._add_default_ignores(processed_args)
        self._validate_flag_combinations(processed_args)

        if "--use-pre-alloc-groups" in processed_args:
            # Pre-alloc groups already exist: single-phase fill only.
            return self._create_single_phase_with_pre_alloc_groups(
                processed_args
            )

        has_phase_1_flag = "--generate-pre-alloc-groups" in processed_args
        has_phase_2_flag = "--generate-all-formats" in processed_args

        if has_phase_2_flag:
            # --generate-all-formats always regenerates pre-alloc as phase 1.
            return self._create_two_phase_executions(processed_args)
        if has_phase_1_flag:
            # Phase 1 only: generate pre-alloc groups without filling.
            return [self._create_phase1_only_execution(processed_args)]

        # Normal single-phase execution.
        return [
            PytestExecution(
                config_file=self.config_path,
                args=processed_args,
                allowed_exit_codes=self.allowed_exit_codes,
            )
        ]

    def _validate_flag_combinations(self, args: List[str]) -> None:
        """
        Reject contradictory flag combinations up front so phase 2 never
        runs against a missing pre-alloc folder.
        """
        if "--use-pre-alloc-groups" not in args:
            return
        if "--generate-pre-alloc-groups" in args:
            raise click.UsageError(
                "--use-pre-alloc-groups and --generate-pre-alloc-groups "
                "are mutually exclusive: the first asserts the groups "
                "already exist on disk, the second regenerates them."
            )
        if "--clean" in args:
            raise click.UsageError(
                "--use-pre-alloc-groups cannot be combined with --clean: "
                "--clean wipes the output directory that holds the "
                "pre-alloc groups."
            )

    def _create_phase1_only_execution(
        self, args: List[str]
    ) -> PytestExecution:
        """Create a phase-1 execution that generates pre-allocation groups."""
        return PytestExecution(
            config_file=self.config_path,
            args=self._create_phase1_args(args),
            description="generating pre-allocation groups",
            allowed_exit_codes=[
                *self.allowed_exit_codes,
                pytest.ExitCode.NO_TESTS_COLLECTED,
            ],
        )

    def _create_two_phase_executions(
        self, args: List[str]
    ) -> List[PytestExecution]:
        """
        Create two-phase execution: pre-allocation group generation + fixture
        filling.
        """
        return [
            self._create_phase1_only_execution(args),
            PytestExecution(
                config_file=self.config_path,
                args=self._create_phase2_args(args),
                description="filling test fixtures",
            ),
        ]

    def _create_single_phase_with_pre_alloc_groups(
        self, args: List[str]
    ) -> List[PytestExecution]:
        """Create single execution using existing pre-allocation groups."""
        return [
            PytestExecution(
                config_file=self.config_path,
                args=args,
            )
        ]

    def _add_default_ignores(self, args: List[str]) -> List[str]:
        """Add default ignore paths for directories not used by fill."""
        # Directories to ignore by default
        default_ignores = [
            "tests/spec_tools",
            "tests/json_loader",
            "tests/fixtures",
        ]

        # Add ignore flags for each directory
        ignore_args = []
        for ignore_path in default_ignores:
            ignore_args.extend(["--ignore", ignore_path])

        return args + ignore_args

    def _create_phase1_args(self, args: List[str]) -> List[str]:
        """Create arguments for phase 1 (pre-allocation group generation)."""
        # Start with all args, then remove what we don't want for phase 1
        filtered_args = self._remove_unwanted_phase1_args(args)

        # Add required phase 1 flags (with quiet output by default)
        phase1_args = [
            "--generate-pre-alloc-groups",
            "-qq",  # Quiet pytest output by default (user -v/-vv/-vvv can
            # override)
        ] + filtered_args

        return phase1_args

    def _create_phase2_args(self, args: List[str]) -> List[str]:
        """Create arguments for phase 2 (fixture filling)."""
        # Remove --generate-pre-alloc-groups and --clean, then add --use-pre-
        # alloc-groups
        phase2_args = self._remove_generate_pre_alloc_groups_flag(args)
        phase2_args = self._remove_clean_flag(phase2_args)
        phase2_args = self._add_use_pre_alloc_groups_flag(phase2_args)
        return phase2_args

    def _remove_unwanted_phase1_args(self, args: List[str]) -> List[str]:
        """Remove arguments we don't want in phase 1 (pre-state generation)."""
        unwanted_flags = {
            # Output format flags
            "--html",
            # Report flags (we'll add our own -qq)
            "-q",
            "--quiet",
            "-qq",
            "--tb",
            # Pre-allocation group flags (we'll add our own)
            "--generate-pre-alloc-groups",
            "--use-pre-alloc-groups",
            "--generate-all-formats",
        }

        filtered_args = []
        i = 0
        while i < len(args):
            arg = args[i]

            # Skip unwanted flags
            if arg in unwanted_flags:
                # Skip flag and its value if it takes one
                if arg in ["--html", "--tb", "-n"] and i + 1 < len(args):
                    i += 2  # Skip flag and value
                else:
                    i += 1  # Skip just the flag
            # Skip unwanted flags with = format
            elif any(arg.startswith(f"{flag}=") for flag in unwanted_flags):
                i += 1
            else:
                filtered_args.append(arg)
                i += 1

        return filtered_args

    def _remove_generate_pre_alloc_groups_flag(
        self, args: List[str]
    ) -> List[str]:
        """
        Remove --generate-pre-alloc-groups flag but keep --generate-all-formats
        for phase 2.
        """
        return [arg for arg in args if arg != "--generate-pre-alloc-groups"]

    def _remove_clean_flag(self, args: List[str]) -> List[str]:
        """Remove --clean flag from argument list."""
        return [arg for arg in args if arg != "--clean"]

    def _add_use_pre_alloc_groups_flag(self, args: List[str]) -> List[str]:
        """Add --use-pre-alloc-groups flag to argument list."""
        return args + ["--use-pre-alloc-groups"]

    def _is_watch_mode(self, args: List[str]) -> bool:
        """Check if any watch flag is present in arguments."""
        return any(flag in args for flag in ["--watch", "--watcherfall"])

    def _is_verbose_watch_mode(self, args: List[str]) -> bool:
        """
        Check if verbose watch flag (--watcherfall)
        is present in arguments.
        """
        return "--watcherfall" in args

    def execute(self, pytest_args: List[str]) -> None:
        """Execute the command with optional watch mode support."""
        if self._is_watch_mode(pytest_args):
            self._execute_with_watch(pytest_args)
        else:
            super().execute(pytest_args)

    def _execute_with_watch(self, pytest_args: List[str]) -> None:
        """Execute fill command in watch mode."""
        verbose = self._is_verbose_watch_mode(pytest_args)
        watcher = FileWatcher(console=self.runner.console, verbose=verbose)
        watcher.run_with_watch(pytest_args)


class PhilCommand(FillCommand):
    """Friendly fill command with emoji reporting."""

    def create_executions(
        self, pytest_args: List[str]
    ) -> List[PytestExecution]:
        """Create execution with emoji report options."""
        processed_args = self.process_arguments(pytest_args)

        emoji_args = processed_args + [
            "-o",
            "report_passed=🦄",
            "-o",
            "report_xpassed=🌈",
            "-o",
            "report_failed=👾",
            "-o",
            "report_xfailed=🦺",
            "-o",
            "report_skipped=🦘",
            "-o",
            "report_error=🚨",
        ]

        return [
            PytestExecution(
                config_file=self.config_path,
                args=emoji_args,
                allowed_exit_codes=self.allowed_exit_codes,
            )
        ]


@click.command(
    context_settings={
        "ignore_unknown_options": True,
    }
)
@common_pytest_options
def fill(pytest_args: List[str], **kwargs: Any) -> None:
    """Entry point for the fill command."""
    del kwargs

    command = FillCommand()
    command.execute(list(pytest_args))


@click.command(
    context_settings={
        "ignore_unknown_options": True,
    }
)
@common_pytest_options
def phil(pytest_args: List[str], **kwargs: Any) -> None:
    """Friendly alias for the fill command."""
    del kwargs

    command = PhilCommand()
    command.execute(list(pytest_args))


if __name__ == "__main__":
    # to allow debugging in vscode: in launch config, set "module":
    # "cli.pytest_commands.fill"
    fill(prog_name="fill")
