#!/usr/bin/env python
"""
CLI tool to extract client configuration files (chainspec/genesis.json) from
Ethereum clients.

This tool spawns an Ethereum client using Hive and extracts the generated
configuration files such as /chainspec/test.json, /configs/test.cfg, or
/genesis.json from the Docker container.
"""

import io
import json
import subprocess
import sys
from pathlib import Path
from typing import Dict, Optional, Self

import click
from hive.simulation import Simulation
from hive.testing import HiveTestResult
from pydantic import (
    BaseModel,
    Field,
    SerializerFunctionWrapHandler,
    ValidationError,
    model_serializer,
)

from execution_testing.base_types import Alloc
from execution_testing.cli.pytest_commands.plugins.consume.simulators.helpers.ruleset import (  # noqa: E501
    ruleset,
)
from execution_testing.fixtures import (
    BlockchainEngineFixture,
    BlockchainFixtureCommon,
)
from execution_testing.fixtures.blockchain import FixtureHeader
from execution_testing.fixtures.file import Fixtures
from execution_testing.fixtures.pre_alloc_groups import PreAllocGroup
from execution_testing.forks import Fork


def get_docker_containers() -> set[str]:
    """Get the current list of Docker container IDs."""
    result = subprocess.run(
        ["docker", "ps", "-q"], capture_output=True, text=True, check=True
    )
    return (
        set(result.stdout.strip().split("\n"))
        if result.stdout.strip()
        else set()
    )


def extract_client_files(
    container_id: str,
    output_dir: Path,
    fixture_name: str,
    client_name: str,
) -> Dict[str, Path]:
    """
    Extract configuration files from a running client container.

    Returns a dictionary mapping file type to extracted file path.
    """
    extracted_files = {}

    # List of files to try to extract
    files_to_extract = [
        ("/chainspec/test.json", "chainspec.json"),
        ("/configs/test.cfg", "config.cfg"),
        ("/genesis.json", "genesis.json"),
    ]

    for container_path, output_filename in files_to_extract:
        try:
            # Use docker exec to read the file from the container
            # First check if file exists
            check_cmd = [
                "docker",
                "exec",
                container_id,
                "test",
                "-f",
                container_path,
            ]
            check_result = subprocess.run(check_cmd, capture_output=True)

            if check_result.returncode == 0:
                # File exists, now read it
                read_cmd = [
                    "docker",
                    "exec",
                    container_id,
                    "cat",
                    container_path,
                ]
                result = subprocess.run(
                    read_cmd, capture_output=True, text=True
                )

                if result.returncode == 0 and result.stdout:
                    output_folder = output_dir / fixture_name / client_name
                    if not output_folder.exists():
                        output_folder.mkdir(parents=True)
                    output_path = output_folder / output_filename
                    output = result.stdout
                    if output_filename == "genesis.json":
                        # Indent the json
                        output = json.dumps(json.loads(output), indent=4)
                    output_path.write_text(output)
                    extracted_files[container_path] = output_path
                    click.echo(
                        f"✓ Extracted {container_path} to {output_path}"
                    )
                else:
                    click.echo(
                        f"✗ Failed to read {container_path}: {result.stderr}",
                        err=True,
                    )
            else:
                click.echo(
                    f"- File {container_path} does not exist in container"
                )

        except Exception as e:
            click.echo(f"✗ Error extracting {container_path}: {e}", err=True)

    return extracted_files


class GenesisState(BaseModel):
    """Model representing genesis state for configuration extraction."""

    header: FixtureHeader
    alloc: Alloc
    chain_id: int = Field(exclude=True)
    fork: Fork = Field(exclude=True)

    @model_serializer(mode="wrap")
    def serialize_model(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, object]:
        """Serialize the genesis state model to a dictionary."""
        serialized = handler(self)
        output = serialized["header"]
        output["alloc"] = {
            k.replace("0x", ""): v for k, v in serialized["alloc"].items()
        }
        return output

    @classmethod
    def from_fixture(cls, fixture_path: Path) -> Self:
        """Create a client genesis state from a fixture file."""
        fixture_bytes = fixture_path.read_bytes()

        try:
            # Try to load the fixture
            fixtures = Fixtures.model_validate_json(fixture_bytes)
            # Go through the fixtures contained to try to get an usable fixture
            for _, base_fixture in fixtures.items():
                if isinstance(
                    base_fixture,
                    (BlockchainFixtureCommon, BlockchainEngineFixture),
                ):
                    return cls(
                        header=base_fixture.genesis,
                        alloc=base_fixture.pre,
                        chain_id=int(base_fixture.config.chain_id),
                        fork=base_fixture.config.fork,
                    )
            raise ValueError(
                f"Fixture {fixture_path} does not contain a genesis"
            )
        except ValidationError:
            pass

        try:
            # Load as builder format and compute genesis on-demand
            pre_alloc_group = PreAllocGroup.model_validate_json(fixture_bytes)
            return cls(
                header=pre_alloc_group.genesis,
                alloc=pre_alloc_group.pre,
                chain_id=pre_alloc_group.chain_id,
                fork=pre_alloc_group.fork,
            )
        except ValidationError:
            pass

        raise ValueError(
            f"File {fixture_path} does not have a recognizable format."
        )

    def get_client_environment(self) -> dict:
        """Get the env vars to start a client with a fixture."""
        if self.fork not in ruleset:
            raise ValueError(f"Fork '{self.fork}' not found in hive ruleset")

        return {
            "HIVE_CHAIN_ID": str(self.chain_id),
            "HIVE_FORK_DAO_VOTE": "1",
            "HIVE_NODETYPE": "full",
            # Using RPC port for liveness check
            "HIVE_CHECK_LIVE_PORT": "8545",
            **{k: f"{v:d}" for k, v in ruleset[self.fork].items()},
        }


@click.command()
@click.option(
    "--client",
    "-c",
    required=False,
    default=None,
    help="Client name (e.g., go-ethereum, besu, nethermind)",
)
@click.option(
    "--fixture",
    "-f",
    type=click.Path(exists=True, path_type=Path),
    help="Path to a fixture JSON file to use for genesis",
    default=None,
)
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    default="./extracted_configs",
    help="Output directory for extracted files",
)
@click.option(
    "--hive-url",
    default="http://127.0.0.1:3000",
    help="Hive server URL",
)
@click.option(
    "--list-files",
    "-l",
    is_flag=True,
    help="List files in the container root before extraction",
)
def extract_config(
    client: str,
    fixture: Optional[Path],
    output: Path,
    hive_url: str,
    list_files: bool,
) -> None:
    """
    Extract client configuration files from Ethereum clients.

    This tool spawns an Ethereum client using Hive and extracts the generated
    configuration files such as /chainspec/test.json, /configs/test.cfg, or
    /genesis.json from the Docker container.
    """
    if not fixture:
        raise click.UsageError(
            "No fixture provided, use --fixture to specify a fixture"
        )

    if fixture.is_dir():
        fixture_files = list(fixture.glob("*.json"))
    elif fixture.is_file():
        fixture_files = [fixture]
    else:
        raise click.UsageError(f"Invalid fixture path: {fixture}")

    # Create output directory
    output.mkdir(parents=True, exist_ok=True)

    # Initialize Hive test
    simulation = Simulation(url=hive_url)
    suite = simulation.start_suite(
        name="extract-config",
        description="Extract client configuration files",
    )
    hive_test = suite.start_test(
        name="extract-config",
        description="Extract client configuration files",
    )

    client_types = []
    for client_type in simulation.client_types():
        if client and client not in client_type.name:
            continue
        client_types.append(client_type)

    if not client_types:
        raise click.UsageError(f"No client types found for {client}")

    for fixture_path in fixture_files:
        # Prepare client files and environment

        click.echo(f"Using fixture: {fixture_path}")

        # Load fixture and create genesis
        genesis = GenesisState.from_fixture(fixture_path)
        client_environment = genesis.get_client_environment()
        genesis_bytes = genesis.model_dump_json(
            by_alias=True, exclude_none=True
        ).encode("utf-8")

        for client_type in client_types:
            client_files = {
                "/genesis.json": io.BufferedReader(io.BytesIO(genesis_bytes))
            }
            # Get containers before starting client
            containers_before = get_docker_containers()

            # Start the client
            click.echo(f"Starting client: {client_type.name}")
            client_instance = hive_test.start_client(
                client_type=client_type,
                environment=client_environment,
                files=client_files,
            )

            if not client_instance:
                click.echo("Failed to start client", err=True)
                sys.exit(1)

            try:
                # Get containers after starting client
                containers_after = get_docker_containers()
                new_containers = containers_after - containers_before

                if len(new_containers) != 1:
                    click.echo(
                        f"Expected exactly 1 new container, found "
                        f"{len(new_containers)}",
                        err=True,
                    )
                    sys.exit(1)

                container_id = new_containers.pop()
                click.echo(
                    f"Client started successfully "
                    f"(Container ID: {container_id})"
                )

                # Optionally list files in container
                if list_files:
                    click.echo("\nListing files in container root:")
                    list_cmd = [
                        "docker",
                        "exec",
                        container_id,
                        "ls",
                        "-la",
                        "/",
                    ]
                    result = subprocess.run(
                        list_cmd, capture_output=True, text=True
                    )
                    if result.returncode == 0:
                        click.echo(result.stdout)
                    else:
                        click.echo(
                            f"Failed to list files: {result.stderr}", err=True
                        )

                # Extract files
                click.echo("\nExtracting configuration files...")
                extract_client_files(
                    container_id, output, fixture_path.stem, client_type.name
                )

            except Exception as e:
                click.echo(f"Error: {e}", err=True)
                import traceback

                traceback.print_exc()
                sys.exit(1)
            finally:
                # Clean up
                click.echo("\nStopping client...")
                client_instance.stop()

            click.echo()

    hive_test.end(result=HiveTestResult(test_pass=True, details=""))
    suite.end()


if __name__ == "__main__":
    extract_config()
