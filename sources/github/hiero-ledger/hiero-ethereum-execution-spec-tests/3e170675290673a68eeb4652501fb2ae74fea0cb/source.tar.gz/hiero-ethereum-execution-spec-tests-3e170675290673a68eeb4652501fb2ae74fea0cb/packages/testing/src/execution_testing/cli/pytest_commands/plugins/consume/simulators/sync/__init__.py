"""Consume Sync test functions."""
