"""BlockchainTest types."""

from functools import cached_property
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Self,
    Sequence,
    Set,
    Tuple,
    Type,
    Union,
    cast,
    get_args,
    get_type_hints,
)

import ethereum_rlp as eth_rlp
import pytest
from ethereum_types.numeric import Uint
from pydantic import (
    AliasChoices,
    ConfigDict,
    Field,
    PlainSerializer,
    computed_field,
    model_serializer,
    model_validator,
)
from pydantic_core import PydanticUndefined

from execution_testing.base_types import (
    Address,
    Alloc,
    Bloom,
    Bytes,
    CamelModel,
    EmptyOmmersRoot,
    EmptyTrieRoot,
    Hash,
    HeaderNonce,
    HexNumber,
    KnownEncodedSize,
    Number,
    ZeroPaddedHexNumber,
    encoded_size,
    ssz,
    unwrap_annotation,
)
from execution_testing.base_types.ssz import (
    SSZForkSchema,
    SSZModel,
    Uint64,
    Uint256,
    byte_list,
    ssz_list,
)
from execution_testing.exceptions import (
    EngineAPIError,
    ExceptionInstanceOrList,
)
from execution_testing.forks import (
    Amsterdam,
    Cancun,
    Fork,
    Paris,
    Requests,
    Shanghai,
    TransitionFork,
    ssz_schema_fork_key,
)
from execution_testing.test_types import (
    AllocGroupHash,
    BlockAccessList,
    Environment,
    Removable,
    TestPhase,
    Transaction,
    Withdrawal,
)
from execution_testing.test_types.block_types import WithdrawalGeneric
from execution_testing.test_types.transaction_types import (
    TransactionFixtureConverter,
    TransactionGeneric,
)

from .base import BaseFixture, FixtureFillingPhase
from .common import (
    FixtureAuthorizationTuple,
    FixtureBlobSchedule,
    FixtureTransactionReceipt,
)

if TYPE_CHECKING:
    from execution_testing.rpc.rpc_types import PayloadAttributes


def post_state_validator(
    alternate_field: str | None = None, mode: str = "after"
) -> Any:
    """
    Create a validator to ensure exactly one post-state field is provided.

    Args: alternate_field: Alternative field name to post_state_hash (e.g.,
    'post_state_diff'). mode: Pydantic validation mode.
    """

    def decorator(cls: Type[Any]) -> Type[Any]:
        @model_validator(mode=mode)  # type: ignore
        def validate_post_state_fields(self: Any) -> Any:
            """Ensure exactly one post-state field is provided."""
            if mode == "after":
                # Determine which fields to check
                if alternate_field:
                    # For engine x fixtures: check post_state vs
                    # post_state_diff
                    field1_name, field2_name = "post_state", alternate_field
                else:
                    # For standard fixtures: check post_state vs
                    # post_state_hash
                    field1_name, field2_name = "post_state", "post_state_hash"

                field1_value = getattr(self, field1_name, None)
                field2_value = getattr(self, field2_name, None)

                if field1_value is None and field2_value is None:
                    raise ValueError(
                        f"Either {field1_name} or {field2_name} "
                        "must be provided."
                    )
                if field1_value is not None and field2_value is not None:
                    raise ValueError(
                        f"Only one of {field1_name} or {field2_name} "
                        "must be provided."
                    )
            return self

        # Apply the validator to the class
        return cls

    return decorator


class HeaderForkRequirement(str):
    """
    Fork requirement class that specifies the name of the method that should be
    called to check if the field is required.
    """

    def __new__(cls, value: str) -> "HeaderForkRequirement":
        """Create a new instance of the class."""
        return super().__new__(cls, value)

    def required(self, fork: Fork) -> bool:
        """Check if the field is required for the given fork."""
        return getattr(fork, f"header_{self}_required")()

    @classmethod
    def get_from_annotation(cls, field_hints: Any) -> Self | None:
        """Find the annotation in the field args."""
        if isinstance(field_hints, cls):
            return field_hints
        for hint in get_args(field_hints):
            if res := cls.get_from_annotation(hint):
                return res
        return None


class FixtureHeader(CamelModel):
    """
    Representation of an Ethereum header within a test Fixture.

    We combine the `Environment` and `Result` contents to create this model.
    """

    # Allow extra fields: FixtureHeader is constructed from merged Result
    # and Environment data via model_dump(), which has extra fields.
    model_config = CamelModel.model_config | {"extra": "ignore"}

    parent_hash: Hash = Hash(0)
    ommers_hash: Hash = Field(Hash(EmptyOmmersRoot), alias="uncleHash")
    fee_recipient: Address = Field(
        ...,
        alias="coinbase",
        validation_alias=AliasChoices("coinbase", "miner"),
    )
    state_root: Hash
    transactions_trie: Hash = Field(
        Hash(EmptyTrieRoot),
        validation_alias=AliasChoices("transactionsTrie", "transactionsRoot"),
    )
    receipts_root: Hash = Field(
        Hash(EmptyTrieRoot),
        alias="receiptTrie",
        validation_alias=AliasChoices("receiptTrie", "receiptsRoot"),
    )
    logs_bloom: Bloom = Field(
        Bloom(0),
        alias="bloom",
        validation_alias=AliasChoices("bloom", "logsBloom"),
    )
    difficulty: ZeroPaddedHexNumber = ZeroPaddedHexNumber(0)
    number: ZeroPaddedHexNumber
    gas_limit: ZeroPaddedHexNumber
    gas_used: ZeroPaddedHexNumber = ZeroPaddedHexNumber(0)
    timestamp: ZeroPaddedHexNumber
    extra_data: Bytes
    prev_randao: Hash = Field(Hash(0), alias="mixHash")
    nonce: HeaderNonce = Field(HeaderNonce(0), validate_default=True)
    base_fee_per_gas: (
        Annotated[
            ZeroPaddedHexNumber,
            HeaderForkRequirement("base_fee"),
        ]
        | None
    ) = Field(None)
    withdrawals_root: (
        Annotated[Hash, HeaderForkRequirement("withdrawals")] | None
    ) = Field(None)
    blob_gas_used: (
        Annotated[ZeroPaddedHexNumber, HeaderForkRequirement("blob_gas_used")]
        | None
    ) = Field(None)
    excess_blob_gas: (
        Annotated[
            ZeroPaddedHexNumber, HeaderForkRequirement("excess_blob_gas")
        ]
        | None
    ) = Field(None)
    parent_beacon_block_root: (
        Annotated[Hash, HeaderForkRequirement("beacon_root")] | None
    ) = Field(None)
    requests_hash: (
        Annotated[Hash, HeaderForkRequirement("requests")] | None
    ) = Field(None)
    block_access_list_hash: (
        Annotated[Hash, HeaderForkRequirement("bal_hash")] | None
    ) = Field(None, alias="blockAccessListHash")
    slot_number: (
        Annotated[ZeroPaddedHexNumber, HeaderForkRequirement("slot_number")]
        | None
    ) = Field(None)

    fork: Fork | None = Field(None, exclude=True)

    def model_post_init(self, __context: Any) -> None:
        """
        Model post init method used to check for required fields of a given
        fork.
        """
        super().model_post_init(__context)

        if self.fork is None:
            # No validation done when we are importing the fixture from file
            return

        # For each field, check if any of the annotations are of type
        # HeaderForkRequirement and if so, check if the field is required for
        # the given fork.
        annotated_hints = get_type_hints(type(self), include_extras=True)

        for field in self.__class__.model_fields:
            if field == "fork":
                continue

            header_fork_requirement = (
                HeaderForkRequirement.get_from_annotation(
                    annotated_hints[field]
                )
            )
            if header_fork_requirement is not None:
                if (
                    header_fork_requirement.required(self.fork)
                    and getattr(self, field) is None
                ):
                    raise ValueError(
                        f"Field {field} is required for fork {self.fork}"
                    )

    @cached_property
    def rlp_encode_list(self) -> List:
        """Compute the RLP of the header."""
        header_list = []
        for field in self.__class__.model_fields:
            if field == "fork":
                continue
            value = getattr(self, field)
            if value is not None:
                header_list.append(
                    value if isinstance(value, bytes) else Uint(value)
                )
        return header_list

    @cached_property
    def rlp(self) -> Bytes:
        """Compute the RLP of the header."""
        return Bytes(eth_rlp.encode(self.rlp_encode_list))

    @computed_field(alias="hash")  # type: ignore[prop-decorator]
    @cached_property
    def block_hash(self) -> Hash:
        """Compute the RLP of the header."""
        return self.rlp.keccak256()

    @classmethod
    def get_default_from_annotation(
        cls,
        fork: Fork,
        field_name: str,
        field_hint: Any,
    ) -> Any:
        """
        Get default value for a header field based on its type hint.

        This method handles:
        1. Fork requirement checking - only returns a default if the fork
           requires the field
        2. Model-defined defaults - uses the field's default value if available
        3. Type-based defaults - constructs defaults based on the field type

        Args:
            fork: Fork to check requirements against
            field_name: Name of the field
            field_hint: Type annotation of the field

        Returns:
            Default value appropriate for the field type, or None if
            the field is not required by the fork

        Raises:
            TypeError: If the field type is not supported and no default
                value is defined in the model. This indicates that support
                for the type needs to be added or an explicit default must
                be provided.

        """
        # Check if this field has a HeaderForkRequirement annotation
        header_fork_requirement = HeaderForkRequirement.get_from_annotation(
            field_hint
        )
        if header_fork_requirement is not None:
            # Only provide a default if the fork requires this field
            if not header_fork_requirement.required(fork):
                return None

        # Check if the field has a default value defined in the model
        if field_name in cls.model_fields:
            field_info = cls.model_fields[field_name]
            if (
                field_info.default is not None
                and field_info.default is not PydanticUndefined
            ):
                return field_info.default
            if field_info.default_factory is not None:
                return field_info.default_factory()  # type: ignore[call-arg]

        # Unwrap type annotations to get the actual type
        actual_type = unwrap_annotation(field_hint)

        # Construct default based on type
        if actual_type == ZeroPaddedHexNumber:
            return ZeroPaddedHexNumber(0)
        elif actual_type == Hash:
            return Hash(0)
        elif actual_type == Address:
            return Address(0)
        elif actual_type == Bytes:
            return Bytes(b"")
        else:
            # Unsupported type - raise error to catch this during development
            raise TypeError(
                f"Cannot generate default value for field '{field_name}' "
                f"with unsupported type '{actual_type}'. "
                "Add support for this type or provide a default explicitly."
            )

    @classmethod
    def genesis(cls, fork: Fork, env: Environment, state_root: Hash) -> Self:
        """Get the genesis header for the given fork."""
        environment_values = env.model_dump(
            exclude_none=True, exclude={"withdrawals", "slot_number"}
        )
        if env.withdrawals is not None:
            environment_values["withdrawals_root"] = Withdrawal.list_root(
                env.withdrawals
            )
        environment_values["extra_data"] = env.extra_data
        extras: Dict[str, Any] = {
            "state_root": state_root,
            "fork": fork,
        }
        if fork.header_requests_required():
            extras["requests_hash"] = Requests()
        if fork.header_bal_hash_required():
            extras["block_access_list_hash"] = BlockAccessList().rlp_hash
        if fork.header_slot_number_required():
            extras["slot_number"] = (
                int(env.slot_number) if env.slot_number is not None else 0
            )
        return cls(**environment_values, **extras)


MAX_EXTRA_DATA_BYTES = 2**5
"""Maximum ``extra_data`` length in the SSZ execution payload."""

MAX_BYTES_PER_TRANSACTION = 2**30
"""Maximum encoded size of a single transaction."""

MAX_TRANSACTIONS_PER_PAYLOAD = 2**20
"""Maximum transaction count per payload."""

MAX_WITHDRAWALS_PER_PAYLOAD = 2**4
"""Maximum withdrawal count per payload."""

# TODO: EIP-8146 defines this as 2**23 for RLP-encoded block access
# lists; revisit once the value is finalized and verified.
MAX_BLOCK_ACCESS_LIST_BYTES = 2**23
"""Placeholder cap for the RLP-encoded block access list byte list."""


class ForkScopedSSZModel(SSZModel):
    """SSZ model whose methods resolve ``Fork`` classes to schema keys."""

    @classmethod
    def ssz_fork_key(cls, fork: Fork) -> Fork:
        """Return this model's SSZ schema key for ``fork``."""
        schema = cls.__ssz_schema__
        if schema is None:
            raise TypeError(
                f"{cls.__name__} does not declare an SSZ fork schema"
            )
        return ssz_schema_fork_key(schema, fork)

    def ssz_encode(self, fork: Fork) -> Bytes:
        """Return the SSZ encoding of this model at ``fork``."""
        return Bytes(ssz.encode(self, self.ssz_fork_key(fork)))

    def ssz_hash_tree_root(self, fork: Fork) -> Hash:
        """Return the SSZ hash tree root of this model at ``fork``."""
        return Hash(ssz.hash_tree_root(self, self.ssz_fork_key(fork)))

    @classmethod
    def ssz_decode(cls, data: bytes, fork: Fork) -> Self:
        """Decode an SSZ-encoded instance of this model at ``fork``."""
        return ssz.decode(cls, data, cls.ssz_fork_key(fork))


class FixtureExecutionPayload(ForkScopedSSZModel):
    """
    Representation of an Ethereum execution payload within a test Fixture.
    """

    # Allow extra fields: FixtureExecutionPayload is constructed from
    # FixtureHeader via model_dump(), which includes fields not in this model.
    model_config = CamelModel.model_config | {"extra": "ignore"}

    parent_hash: Hash
    fee_recipient: Address
    state_root: Hash

    receipts_root: Hash
    logs_bloom: Bloom

    number: Uint64 = Field(..., alias="blockNumber")
    gas_limit: Uint64
    gas_used: Uint64
    timestamp: Uint64
    extra_data: Annotated[Bytes, byte_list(MAX_EXTRA_DATA_BYTES)]
    prev_randao: Hash

    base_fee_per_gas: Uint256
    blob_gas_used: Uint64 | None = Field(None)
    excess_blob_gas: Uint64 | None = Field(None)

    block_hash: Hash

    transactions: Annotated[
        List[Annotated[Bytes, byte_list(MAX_BYTES_PER_TRANSACTION)]],
        ssz_list(MAX_TRANSACTIONS_PER_PAYLOAD),
    ]
    withdrawals: (
        Annotated[List[Withdrawal], ssz_list(MAX_WITHDRAWALS_PER_PAYLOAD)]
        | None
    ) = None

    block_access_list: (
        Annotated[Bytes, byte_list(MAX_BLOCK_ACCESS_LIST_BYTES)] | None
    ) = Field(None, description="RLP-serialized EIP-7928 Block Access List")
    slot_number: Uint64 | None = Field(None)

    __ssz_schema__ = SSZForkSchema(
        base_fork=Paris,
        base=(
            "parent_hash",
            "fee_recipient",
            "state_root",
            "receipts_root",
            "logs_bloom",
            "prev_randao",
            "number",
            "gas_limit",
            "gas_used",
            "timestamp",
            "extra_data",
            "base_fee_per_gas",
            "block_hash",
            "transactions",
        ),
        appended={
            Shanghai: ("withdrawals",),
            Cancun: ("blob_gas_used", "excess_blob_gas"),
            Amsterdam: ("block_access_list", "slot_number"),
        },
    )

    @classmethod
    def from_fixture_header(
        cls,
        header: FixtureHeader,
        transactions: List[Transaction],
        withdrawals: List[Withdrawal] | None,
        block_access_list: Bytes | None = None,
    ) -> Self:
        """
        Return FixtureExecutionPayload from a FixtureHeader, a list of
        transactions, a list of withdrawals, and an optional block access list.
        """
        return cls(
            **header.model_dump(exclude_none=True),
            transactions=[tx.rlp() for tx in transactions],
            withdrawals=withdrawals,
            block_access_list=block_access_list,
        )


class FixtureExecutionPayloadModifier(CamelModel):
    """
    Modifier for ``FixtureExecutionPayload`` fields, used to construct
    intentionally invalid ``engine_newPayload`` requests in negative tests.

    Each field defaults to ``None`` (no override). Set a field to a concrete
    value to override it on the payload, or to ``REMOVE_FIELD`` (sentinel) to
    omit it from the payload entirely. This mirrors ``Header``'s mechanism
    but targets ``FixtureExecutionPayload`` instead of ``FixtureHeader``.
    """

    model_config = ConfigDict(
        **CamelModel.model_config,
        arbitrary_types_allowed=True,
    )

    block_access_list: Removable | Bytes | None = None
    slot_number: Removable | HexNumber | None = None

    REMOVE_FIELD: ClassVar[Removable] = Removable()
    """Sentinel to specify that a payload field should be removed."""

    @model_serializer(mode="wrap", when_used="json")
    def _serialize_model(self, serializer: Any, info: Any) -> Dict[str, Any]:
        """Exclude Removable fields from serialization."""
        del info
        data = serializer(self)
        return {k: v for k, v in data.items() if not isinstance(v, Removable)}

    def apply(
        self, target: "FixtureExecutionPayload"
    ) -> "FixtureExecutionPayload":
        """Return a copy of ``target`` with this modifier's overrides."""
        overrides: Dict[str, Any] = {}
        for field_name in self.__class__.model_fields:
            value = getattr(self, field_name)
            if value is None:
                continue
            overrides[field_name] = (
                None if isinstance(value, Removable) else value
            )
        return target.model_copy(update=overrides)


EngineNewPayloadV1Parameters = Tuple[FixtureExecutionPayload]
EngineNewPayloadV3Parameters = Tuple[FixtureExecutionPayload, List[Hash], Hash]
EngineNewPayloadV4Parameters = Tuple[
    FixtureExecutionPayload,
    List[Hash],
    Hash,
    List[Bytes],
]
EngineNewPayloadV5Parameters = EngineNewPayloadV4Parameters

# Important: We check EngineNewPayloadV3Parameters first as it has more fields,
# and pydantic has a weird behavior when the smaller tuple is checked first.
EngineNewPayloadParameters = Union[
    EngineNewPayloadV5Parameters,
    EngineNewPayloadV4Parameters,
    EngineNewPayloadV3Parameters,
    EngineNewPayloadV1Parameters,
]


class FixtureEngineNewPayload(CamelModel):
    """
    Representation of the `engine_newPayloadVX` information to be sent using
    the block information.
    """

    params: EngineNewPayloadParameters
    new_payload_version: Number
    forkchoice_updated_version: Number
    validation_error: ExceptionInstanceOrList | None = None
    error_code: (
        Annotated[
            EngineAPIError,
            PlainSerializer(
                lambda x: str(x.value),
                return_type=str,
            ),
        ]
        | None
    ) = None
    phase: TestPhase | None = Field(
        None,
        description=(
            "Test phase the payload belongs to (setup / execution / "
            "cleanup). Set at fill time from the transactions' "
            "TestPhaseManager context; consumers use it to partition "
            "payloads (e.g. BlockchainEngineStatefulFixture "
            "setupEngineNewPayloads vs engineNewPayloads) without "
            "re-inferring from tx metadata."
        ),
    )

    def valid(self) -> bool:
        """Return whether the payload is valid."""
        return self.validation_error is None

    def get_payload_attributes(self) -> "PayloadAttributes":
        """Return the ``PayloadAttributes`` corresponding to this payload."""
        from execution_testing.rpc.rpc_types import PayloadAttributes

        execution_payload = self.params[0]
        # parent_beacon_block_root exists from V3 onwards. The length check
        # is for mypy narrowing; the version check captures the actual rule.
        parent_beacon_block_root = (
            self.params[2]
            if self.forkchoice_updated_version >= 3 and len(self.params) >= 3
            else None
        )
        return PayloadAttributes(
            timestamp=execution_payload.timestamp,
            prev_randao=execution_payload.prev_randao,
            suggested_fee_recipient=execution_payload.fee_recipient,
            withdrawals=execution_payload.withdrawals,
            parent_beacon_block_root=parent_beacon_block_root,
            slot_number=execution_payload.slot_number,
            # targetGasLimit exists from V4 onwards; earlier versions must
            # not carry the field even though every payload has a gas limit.
            target_gas_limit=(
                execution_payload.gas_limit
                if self.forkchoice_updated_version >= 4
                else None
            ),
        )

    @staticmethod
    def derive_phase(transactions: Sequence[Any]) -> TestPhase | None:
        """
        Derive block phase from transactions.

        Reads ``test_phase`` (set by ``TestPhaseManager`` context managers at
        construction time), falling back to ``metadata.phase`` (set explicitly
        by pre_alloc helpers). A block with any ``SETUP`` transaction is
        considered part of setup; otherwise the single shared phase is used,
        or ``None`` if the block has no phase-tagged transactions.
        """
        if not transactions:
            return None

        phases: set[TestPhase] = set()
        for tx in transactions:
            phase = getattr(tx, "test_phase", None)
            if phase is None:
                meta = getattr(tx, "metadata", None)
                if meta is not None:
                    phase = getattr(meta, "phase", None)
            if phase is not None:
                phases.add(phase)

        if not phases:
            return None
        if len(phases) == 1:
            return next(iter(phases))
        if TestPhase.SETUP in phases:
            return TestPhase.SETUP
        return None

    @classmethod
    def from_fixture_header(
        cls,
        fork: Fork,
        header: FixtureHeader,
        transactions: List[Transaction],
        withdrawals: List[Withdrawal] | None,
        requests: List[Bytes] | None,
        block_access_list: Bytes | None = None,
        execution_payload_modifier: (
            "FixtureExecutionPayloadModifier | None"
        ) = None,
        **kwargs: Any,
    ) -> Self:
        """Create `FixtureEngineNewPayload` from a `FixtureHeader`."""
        new_payload_version = fork.engine_new_payload_version()
        forkchoice_updated_version = fork.engine_forkchoice_updated_version()

        assert new_payload_version is not None, (
            "Invalid header for engine_newPayload"
        )

        # An ``execution_payload_modifier`` that touches ``block_access_list``
        # (either overriding or removing it) replaces the fork's default body,
        # so the fork-required check is skipped in that case.
        modifier_overrides_bal = (
            execution_payload_modifier is not None
            and execution_payload_modifier.block_access_list is not None
        )
        if (
            fork.engine_execution_payload_block_access_list()
            and not modifier_overrides_bal
        ):
            if block_access_list is None:
                raise ValueError(
                    "`block_access_list` is required in engine "
                    f"`ExecutionPayload` for >={fork}."
                )

        execution_payload = FixtureExecutionPayload.from_fixture_header(
            header=header,
            transactions=transactions,
            withdrawals=withdrawals,
            block_access_list=block_access_list,
        )
        if execution_payload_modifier is not None:
            execution_payload = execution_payload_modifier.apply(
                execution_payload
            )

        params: List[Any] = [execution_payload]
        if fork.engine_new_payload_blob_hashes():
            blob_hashes = Transaction.list_blob_versioned_hashes(transactions)
            if blob_hashes is None:
                raise ValueError(f"Blob hashes are required for ${fork}.")
            params.append(blob_hashes)

        if fork.engine_new_payload_beacon_root():
            parent_beacon_block_root = header.parent_beacon_block_root
            if parent_beacon_block_root is None:
                raise ValueError(
                    f"Parent beacon block root is required for ${fork}."
                )
            params.append(parent_beacon_block_root)

        if fork.engine_new_payload_requests():
            if requests is None:
                raise ValueError(f"Requests are required for ${fork}.")
            params.append(requests)

        payload_params: EngineNewPayloadParameters = cast(
            EngineNewPayloadParameters,
            tuple(params),
        )
        # Auto-derive phase from transactions if the caller did not pass one.
        kwargs.setdefault("phase", cls.derive_phase(transactions))
        new_payload = cls(
            params=payload_params,
            new_payload_version=new_payload_version,
            forkchoice_updated_version=forkchoice_updated_version,
            **kwargs,
        )

        return new_payload


class FixtureTransaction(
    TransactionFixtureConverter, TransactionGeneric[ZeroPaddedHexNumber]
):
    """Representation of an Ethereum transaction within a test Fixture."""

    # Allow extra fields: FixtureTransaction is constructed from
    # Transaction via model_dump(), which includes fields not in this model.
    model_config = CamelModel.model_config | {"extra": "ignore"}

    authorization_list: List[FixtureAuthorizationTuple] | None = None
    initcodes: List[Bytes] | None = None

    @classmethod
    def from_transaction(cls, tx: Transaction) -> Self:
        """Return FixtureTransaction from a Transaction."""
        return cls(**tx.model_dump())


class FixtureWithdrawal(WithdrawalGeneric[ZeroPaddedHexNumber]):
    """
    Structure to represent a single withdrawal of a validator's balance from
    the beacon chain in the output fixture.
    """

    @classmethod
    def from_withdrawal(cls, w: WithdrawalGeneric) -> Self:
        """Return FixtureWithdrawal from a Withdrawal."""
        return cls(**w.model_dump())


def block_rlp_encode_list(
    header: FixtureHeader,
    serialized_txs: List[Any],
    ommers: List[FixtureHeader],
    withdrawals: List[FixtureWithdrawal] | None,
) -> List[Any]:
    """Return the RLP-serializable list that makes up a block."""
    block: List[Any] = [
        header.rlp_encode_list,
        serialized_txs,
        ommers,
    ]

    if withdrawals is not None:
        block.append([w.to_serializable_list() for w in withdrawals])

    return block


def block_rlp_size(
    header: FixtureHeader,
    txs: List[Transaction],
    ommers: List[FixtureHeader],
    withdrawals: List[FixtureWithdrawal] | None,
) -> int:
    """
    Return the encoded size of the block, without encoding it.

    Each transaction enters `block_rlp_encode_list` as a placeholder carrying
    its `Transaction.serializable_size`, so the transaction bytes are never
    built.
    """
    return encoded_size(
        block_rlp_encode_list(
            header,
            [KnownEncodedSize(tx.serializable_size) for tx in txs],
            ommers,
            withdrawals,
        )
    )


class FixtureBlockBase(CamelModel):
    """
    Representation of an Ethereum block within a test Fixture without RLP
    bytes.
    """

    @model_validator(mode="before")
    @classmethod
    def strip_block_number_computed_field(cls, data: Any) -> Any:
        """
        Strip the block_number computed field included in model_dump().

        This field is not a valid input field.
        """
        if isinstance(data, dict):
            data.pop("blocknumber", None)
            data.pop("block_number", None)
        return data

    header: FixtureHeader = Field(..., alias="blockHeader")
    txs: List[FixtureTransaction] = Field(
        default_factory=list, alias="transactions"
    )
    ommers: List[FixtureHeader] = Field(
        default_factory=list, alias="uncleHeaders"
    )
    withdrawals: List[FixtureWithdrawal] | None = None
    receipts: List[FixtureTransactionReceipt] | None = None
    block_access_list: BlockAccessList | None = Field(
        None, description="EIP-7928 Block Access List"
    )
    fork: Fork | None = Field(None, exclude=True)

    @computed_field(alias="blocknumber")  # type: ignore[prop-decorator]
    @cached_property
    def block_number(self) -> Number:
        """Get the block number from the header."""
        return Number(self.header.number)

    def with_rlp(self, txs: List[Transaction]) -> "FixtureBlock":
        """Return FixtureBlock with the RLP bytes set."""
        return FixtureBlock(
            **self.model_dump(),
            rlp=eth_rlp.encode(
                block_rlp_encode_list(
                    self.header,
                    [tx.serializable_list for tx in txs],
                    self.ommers,
                    self.withdrawals,
                )
            ),
        )


class FixtureBlock(FixtureBlockBase):
    """Representation of an Ethereum block within a test Fixture."""

    rlp: Bytes

    def without_rlp(self) -> FixtureBlockBase:
        """Return FixtureBlockBase without the RLP bytes set."""
        return FixtureBlockBase(
            **self.model_dump(exclude={"rlp"}),
        )


class FixtureConfig(CamelModel):
    """Chain configuration for a fixture."""

    fork: Fork | TransitionFork = Field(..., alias="network")
    chain_id: ZeroPaddedHexNumber = Field(
        ZeroPaddedHexNumber(1), alias="chainid"
    )
    blob_schedule: FixtureBlobSchedule | None = None


class InvalidFixtureBlock(CamelModel):
    """Representation of an invalid Ethereum block within a test Fixture."""

    rlp: Bytes
    expect_exception: ExceptionInstanceOrList
    rlp_decoded: FixtureBlockBase | None = Field(None, alias="rlp_decoded")


@post_state_validator()
class BlockchainFixtureCommon(BaseFixture):
    """Base blockchain test fixture model."""

    fork: Fork | TransitionFork = Field(..., alias="network")
    genesis: FixtureHeader = Field(..., alias="genesisBlockHeader")
    pre: Alloc
    post_state: Alloc | None = Field(None)
    post_state_hash: Hash | None = Field(None)
    # FIXME: lastBlockHash
    last_block_hash: Hash = Field(..., alias="lastblockhash")
    config: FixtureConfig

    @model_validator(mode="before")
    @classmethod
    def config_defaults_for_backwards_compatibility(cls, data: Any) -> Any:
        """
        Check if the config field is populated, otherwise use the root-level
        field values for backwards compatibility.
        """
        if isinstance(data, dict):
            if "config" not in data:
                data["config"] = {}
            if isinstance(data["config"], dict):
                if "network" not in data["config"]:
                    data["config"]["network"] = data["network"]
                if "chainid" not in data["config"]:
                    data["config"]["chainid"] = "0x01"
        return data

    def get_fork(self) -> Fork | TransitionFork | None:
        """Return fork of the fixture as a string."""
        return self.fork


class BlockchainFixture(BlockchainFixtureCommon):
    """Cross-client specific blockchain test model use in JSON fixtures."""

    format_name: ClassVar[str] = "blockchain_test"
    description: ClassVar[str] = (
        "Tests that generate a blockchain test fixture."
    )

    genesis_rlp: Bytes = Field(..., alias="genesisRLP")
    blocks: List[FixtureBlock | InvalidFixtureBlock]
    seal_engine: Literal["NoProof"] = Field("NoProof")
    transition_tool_cache_key: ClassVar[str] = "blockchain_test"


@post_state_validator()
class BlockchainEngineFixtureCommon(BaseFixture):
    """
    Base blockchain test fixture model for Engine API based execution.

    Similar to BlockchainFixtureCommon but excludes the 'pre' field to avoid
    duplicating large pre-allocations.
    """

    fork: Fork | TransitionFork = Field(..., alias="network")
    post_state_hash: Hash | None = Field(None)
    # FIXME: lastBlockHash
    last_block_hash: Hash = Field(..., alias="lastblockhash")
    config: FixtureConfig

    def get_fork(self) -> Fork | TransitionFork | None:
        """Return fixture's `Fork`."""
        return self.fork

    @classmethod
    def supports_fork(cls, fork: Fork | TransitionFork) -> bool:
        """
        Return whether the fixture can be generated for the given fork.

        The Engine API is available only on Paris and afterwards.
        """
        return fork.fork_at(block_number=0, timestamp=0) >= Paris


class BlockchainEngineFixture(BlockchainEngineFixtureCommon):
    """Engine specific test fixture information."""

    format_name: ClassVar[str] = "blockchain_test_engine"
    description: ClassVar[str] = (
        "Tests that generate a blockchain test fixture in Engine API format."
    )
    pre: Alloc
    genesis: FixtureHeader = Field(..., alias="genesisBlockHeader")
    post_state: Alloc | None = Field(None)
    payloads: List[FixtureEngineNewPayload] = Field(
        ..., alias="engineNewPayloads"
    )
    transition_tool_cache_key: ClassVar[str] = "blockchain_test"


@post_state_validator(alternate_field="post_state_diff")
class BlockchainEngineXFixture(BlockchainEngineFixtureCommon):
    """
    Engine X specific test fixture information.

    Uses pre-allocation groups (and a single client instance) for efficient
    test execution without client restarts.
    """

    # Allow extra fields: BlockchainEngineXFixture is constructed from shared
    # fixture_data that has fields for other fixture formats (e.g. genesis).
    model_config = CamelModel.model_config | {"extra": "ignore"}

    format_name: ClassVar[str] = "blockchain_test_engine_x"
    description: ClassVar[str] = (
        "Tests that generate a Blockchain Test Engine X fixture."
    )
    format_phases: ClassVar[Set[FixtureFillingPhase]] = {
        FixtureFillingPhase.FILL_AFTER_PRE_ALLOC_GENERATION,
        FixtureFillingPhase.PRE_ALLOC_GENERATION,
    }
    transition_tool_cache_key: ClassVar[str] = ""

    pre_hash: AllocGroupHash
    """Hash of the pre-allocation group this test belongs to."""

    post_state_diff: Alloc
    """
    State difference from genesis after test execution (efficiency
    optimization).
    """

    payloads: List[FixtureEngineNewPayload] = Field(
        ..., alias="engineNewPayloads"
    )
    """Engine API payloads for blockchain execution."""


class BlockchainEngineStatefulFixture(BlockchainEngineFixtureCommon):
    """
    Engine fixture for snapshot-based stateful testing.

    Instead of embedding pre-allocation or referencing a computed group,
    this fixture references an external snapshot that the consumer must
    pre-load. Setup payloads deploy contracts and seed accounts on top
    of the snapshot before the actual test payloads execute.
    """

    model_config = CamelModel.model_config | {"extra": "ignore"}

    format_name: ClassVar[str] = "blockchain_test_stateful_engine"
    description: ClassVar[str] = (
        "Tests that generate a Blockchain Test fixture for "
        "snapshot-based stateful Engine API testing."
    )
    format_phases: ClassVar[Set[FixtureFillingPhase]] = {
        FixtureFillingPhase.FILL_STATEFUL,
    }

    snapshot_block_number: HexNumber
    snapshot_block_hash: Hash
    start_block_number: HexNumber
    start_block_hash: Hash

    setup_payloads: List[FixtureEngineNewPayload] = Field(
        default_factory=list,
        alias="setupEngineNewPayloads",
        description=(
            "Per-test setup-phase payloads applied on top of "
            "``start_block_hash`` before the test's execution payloads."
        ),
    )
    payloads: List[FixtureEngineNewPayload] = Field(
        ..., alias="engineNewPayloads"
    )
    benchmark_gas_used: HexNumber | None = Field(
        None,
        alias="benchmarkGasUsed",
        description=(
            "Total gas consumed by the execution payloads when this fixture "
            "was filled, as reported by the live client. Populated for "
            "``BENCHMARKING`` operation mode; ``None`` otherwise. Lets "
            "consumers compare expected vs. observed gas without replay."
        ),
    )


class StatefulPreRunFixture(CamelModel):
    """
    Pre-run payloads for stateful benchmark fixtures.

    Contains session-scoped blocks (e.g. deterministic factory deploy,
    seed funding via CL withdrawal) that must be replayed once before
    any per-test fixtures land.

    This is a deliberately smaller sibling of
    :class:`BlockchainEngineStatefulFixture` — they share the snapshot/
    start anchor fields and the ``engineNewPayloads`` payload list, but
    pre-run carries no per-test fields (``last_block_hash``, ``config``,
    ``setupEngineNewPayloads``) because there is no test execution
    attached to it. Consumers (benchmarkoor) route by directory:
    ``pre_run/*.json`` parse as ``StatefulPreRunFixture`` and apply
    once per session; ``for_<fork>_at_<gas>/.../*.json`` parse as
    ``BlockchainEngineStatefulFixture`` and apply per test.
    """

    network: str
    snapshot_block_number: HexNumber
    snapshot_block_hash: Hash
    start_block_number: HexNumber | None = None
    start_block_hash: Hash | None = None
    payloads: List[FixtureEngineNewPayload] = Field(
        ..., alias="engineNewPayloads"
    )


class BlockchainEngineSyncFixture(BlockchainEngineFixture):
    """
    Engine Sync specific test fixture information.

    This fixture format is specifically designed for sync testing where:
    - The client under test receives all payloads
    - A sync client attempts to sync from the client under test
    - Both client types are parametrized from hive client config
    """

    format_name: ClassVar[str] = "blockchain_test_sync"
    description: ClassVar[str] = (
        "Tests that generate a blockchain test fixture for Engine API "
        "testing with client sync."
    )
    transition_tool_cache_key: ClassVar[str] = ""
    sync_payload: FixtureEngineNewPayload | None = None

    @classmethod
    def discard_fixture_format_by_marks(
        cls,
        fork: Fork | TransitionFork,
        markers: List[pytest.Mark],
    ) -> bool:
        """Discard the fixture format based on the provided markers."""
        del fork
        marker_names = [m.name for m in markers]
        return "verify_sync" not in marker_names
