"""Test the help plugin."""

from typing import Any

import pytest

FILL_TEST_ARGS = (
    "--evm-bin",
    "--traces",
    "--filler-path",
    "--output",
    "--forks",
    "--fork",
    "--from",
    "--until",
    "--address-stubs",
    "--help",
)


@pytest.mark.parametrize("help_flag", ["--fill-help"])
def test_local_arguments_present_in_fill_help(
    pytester: Any, help_flag: str
) -> None:
    """
    Test that locally defined command-line flags appear in the help if our
    custom help flag is used.
    """
    pytester.copy_example(
        name="src/execution_testing/cli/pytest_commands/pytest_ini_files/pytest-fill.ini"
    )
    result = pytester.runpytest("-c", "pytest-fill.ini", help_flag)
    for test_arg in FILL_TEST_ARGS:
        assert test_arg in "\n".join(result.stdout.lines)


CHECK_EIP_VERSIONS_TEST_ARGS = (
    "--github-token",
    "<test-path>",
    "--help",
)


@pytest.mark.parametrize("help_flag", ["--check-eip-versions-help"])
def test_local_arguments_present_in_check_eip_versions_help(
    pytester: Any, help_flag: str
) -> None:
    """
    Test that locally defined command-line flags and the test path argument
    appear in the check_eip_versions help.
    """
    pytester.copy_example(
        name="src/execution_testing/cli/pytest_commands/pytest_ini_files/pytest-check-eip-versions.ini"
    )
    result = pytester.runpytest(
        "-c", "pytest-check-eip-versions.ini", help_flag
    )
    for test_arg in CHECK_EIP_VERSIONS_TEST_ARGS:
        assert test_arg in "\n".join(result.stdout.lines)


CONSUME_TEST_ARGS = (
    "--input",
    "--no-html",
    "--help",
)


@pytest.mark.parametrize(
    "command, help_flag",
    [
        ("direct", "--consume-help"),
        ("rlp", "--consume-help"),
        ("engine", "--consume-help"),
    ],
)
def test_local_arguments_present_in_base_consume_help(
    pytester: Any, help_flag: str, command: str
) -> None:
    """
    Test that locally defined command-line flags appear in the help for consume
    subcommands.
    """
    pytester.copy_example(
        name="src/execution_testing/cli/pytest_commands/pytest_ini_files/pytest-consume.ini"
    )
    result = pytester.runpytest("-c", "pytest-consume.ini", command, help_flag)
    for test_arg in CONSUME_TEST_ARGS:
        assert test_arg in "\n".join(result.stdout.lines)
