"""
A pytest plugin that generates test case documentation for use in mkdocs.

It generates the top-level "Test Case Reference" section in EEST's mkdocs site.

Note:
----
- No output directory is specified for the generated output; file IO
occurs via the `mkdocs-gen-files` plugin. `mkdocs serve` writes intermediate
files to our local `docs/` directory and then copies it to the site directory.
We modify `docs/navigation.md` and write all other output underneath
`docs/tests`. If mkdocs is interrupted, these intermediate artifacts are left
in `docs/`.

Usage:
------

!!! note "Ensuring a clean build"

In case mkdocs has polluted the `docs/` directory with intermediate files, run:

```console
git restore docs/navigation.md  # Careful if you have local modifications!
rm -rf docs/tests docs/docs site
```

To test doc generation, run the plugin without mkdocs:

```console
uv run fill -p pytest_plugins.filler.gen_test_doc.gen_test_doc --gen-docs \
    --fork=<fork> tests
```

Or to build and view the site:

```console
uv run mkdocs serve
```

"""

import glob
import logging
import os
import re
import sys
import textwrap
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple, cast

import mkdocs_gen_files  # type: ignore[unused-ignore, import-not-found]
import pytest
from jinja2 import Environment, FileSystemLoader, StrictUndefined
from pytest import Item

from execution_testing.forks import ALL_TRANSITION_FORKS, get_forks
from execution_testing.specs import BaseTest
from execution_testing.tools.utility.versioning import (
    generate_github_url,
    get_current_commit_hash_or_tag,
)

from .page_props import (
    DirectoryPageProps,
    FunctionPageProps,
    FunctionPagePropsLookup,
    MarkdownPageProps,
    ModulePageProps,
    ModulePagePropsLookup,
    PageProps,
    PagePropsLookup,
    TestCase,
    TestFunction,
    sanitize_string_title,
)

logger = logging.getLogger("mkdocs")

docstring_test_function_history: Dict[str, str] = {}


def pytest_addoption(parser: pytest.Parser) -> None:  # noqa: D103
    gen_docs = parser.getgroup(
        "gen_docs", "Arguments related to generating test case documentation"
    )
    gen_docs.addoption(
        "--gen-docs",
        action="store_true",
        dest="gen_docs",
        default=False,
        help=(
            "Generate documentation for all collected tests for use in mkdocs"
        ),
    )
    gen_docs.addoption(
        "--gen-docs-target-fork",
        action="store",
        dest="gen_docs_target_fork",
        default=None,
        help=(
            "The default fork to use generated in generated doc pages. "
            "Should be the name of the next upcoming fork."
        ),
    )


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config: pytest.Config) -> None:  # noqa: D103
    if config.getoption("gen_docs"):
        config.option.disable_html = True
        config.pluginmanager.register(
            TestDocsGenerator(config), "test-case-doc-generator"
        )


def get_test_function_id(item: Item) -> str:
    """Get the test function's ID from the item."""
    return item.nodeid.split("[")[0]


def get_test_function_name(item: Item) -> str:
    """Get the test function's name from the item."""
    return item.name.split("[")[0]


def get_test_case_id(item: Item) -> str:
    """Get the test case's ID from the item."""
    return item.nodeid.split("[")[-1].rstrip("]")


def get_test_function_import_path(item: pytest.Item) -> str:
    """
    Retrieve the fully qualified import path for an item's test function.

    This is used in jinja2 templates to get the test function, respectively the
    test function's class, documentation with mkdocstrings.
    """
    item = cast(pytest.Function, item)  # help mypy infer type
    module_name = item.module.__name__
    if hasattr(item.obj, "__self__"):
        # it's a method bound to a class
        test_class = item.obj.__self__.__class__.__name__
        test_function = item.obj.__name__
        full_path = f"{module_name}.{test_class}"
    else:
        # it's a standalone function, no class
        test_function = item.obj.__name__
        full_path = f"{module_name}.{test_function}"
    return full_path


def get_import_path(path: Path) -> str:
    """
    Get the import path for a given path.

    - For modules, strip the file extension.
    - For directories (i.e., packages such as `tests.berlin`),
      `with_suffix()` is ignored.

    To do:
    ------

    - This should be combined with `get_test_function_import_path`.
    """
    return str(path.with_suffix("")).replace("/", ".")


def create_github_issue_url(title: str) -> str:
    """Create a GitHub issue URL for the given title."""
    url_base = "https://github.com/ethereum/execution-spec-tests/issues/new?"
    title = title.replace(" ", "%20")
    labels = "scope:docs,type:bug"
    return f"{url_base}title={title}&labels={labels}"


def get_docstring_one_liner(item: pytest.Item) -> str:
    """
    Extract either the first 100 characters or the first line of the docstring
    from the function associated with the given pytest.Item.
    """
    item = cast(pytest.Function, item)  # help mypy infer type
    func_obj = item.obj
    docstring = func_obj.__doc__
    test_function_name = get_test_function_name(item)

    if not docstring:
        github_issue_url = create_github_issue_url(
            f"docs(bug): No docstring available for `{test_function_name}`"
        )
        logger.warning(f"No docstring available for `{test_function_name}`.")
        return f"[📖🐛 No docstring available]({github_issue_url})"
    docstring = docstring.strip()
    test_function_id = get_test_function_id(item)
    if (
        docstring in docstring_test_function_history
        and docstring_test_function_history[docstring] != test_function_id
    ):
        history_id = docstring_test_function_history[docstring]
        logger.info(
            f"Duplicate docstring for {test_function_id}: "
            f"{history_id} and {test_function_id}"
        )
    else:
        docstring_test_function_history[docstring] = test_function_id
    lines = docstring.splitlines()

    bad_oneliner_issue_url = create_github_issue_url(
        f"docs(bug): Bad docstring oneliner for `{test_function_name}`"
    )
    report_bad_oneliner_link = f"([📖🐛?]({bad_oneliner_issue_url}))"
    if lines:
        first_line = lines[0].strip()
        if len(first_line) <= 100:
            return (
                first_line
                if not first_line.endswith(":")
                else first_line + report_bad_oneliner_link
            )
        else:
            return first_line[:100] + f"... {report_bad_oneliner_link}"
    else:
        return docstring[:100] + f"... {report_bad_oneliner_link}"


def get_test_function_test_type(item: pytest.Item) -> str:
    """Get the test type for the test function based on its fixtures."""
    test_types: List[str] = [
        spec_type.pytest_parameter_name()
        for spec_type in BaseTest.spec_types.values()
    ]
    item = cast(pytest.Function, item)  # help mypy infer type
    fixture_names = item.fixturenames
    for test_type in test_types:
        if test_type in fixture_names:
            return test_type
    logger.warning(
        f"Could not determine the test function type for {item.nodeid}"
    )
    issue_title = "docs(bug): unknown test function type"
    issue_url = create_github_issue_url(issue_title)
    return f"unknown ([📖🐛]({issue_url}))"


class TestDocsGenerator:
    """Pytest plugin class for generating test case documentation."""

    def __init__(self, config: pytest.Config) -> None:
        """Initialize the plugin with the given pytest config."""
        self.config = config
        self.target_fork: str = config.getoption("gen_docs_target_fork")
        self.deployed_forks = [
            fork.name() for fork in get_forks() if fork.is_deployed()
        ]
        # Map each transition fork's name to the base fork it ends at so that
        # cases parametrized as a transition fork (e.g.
        # `BPO2ToAmsterdamAtTime15k`) count toward the fork they transition
        # into (`Amsterdam`).
        self._transition_to_base: Dict[str, str] = {
            fork.name(): fork.transitions_to().name()
            for fork in ALL_TRANSITION_FORKS
        }
        self._fork_newness: Dict[str, int] = {
            fork.name(): i for i, fork in enumerate(get_forks())
        }
        self._setup_logger()
        self.jinja2_env = Environment(
            loader=FileSystemLoader("docs/templates"),
            trim_blocks=True,
            undefined=StrictUndefined,
        )
        self.source_dir = Path("tests")
        self.ref = get_current_commit_hash_or_tag()
        self.top_level_nav_entry = "Test Case Reference"
        # intermediate collected pages and their properties
        self.function_page_props: FunctionPagePropsLookup = {}
        self.module_page_props: ModulePagePropsLookup = {}
        # the complete set of pages and their properties
        self.page_props: PagePropsLookup = {}

    def _base_fork(self, fork_name: str) -> str:
        """Return the base fork name, resolving transition forks."""
        return self._transition_to_base.get(fork_name, fork_name)

    @pytest.hookimpl(hookwrapper=True, trylast=True)
    def pytest_collection_modifyitems(
        self, config: pytest.Config, items: List[pytest.Item]
    ) -> object:
        """Generate html doc for each test item that pytest has collected."""
        yield

        self.add_global_page_props_to_env()

        functions = defaultdict(list)
        for item in items:  # group test case by test function
            functions[get_test_function_id(item)].append(item)

        if hasattr(config, "checklist_props"):
            checklist_props = config.checklist_props
            self.page_props = {**self.page_props, **checklist_props}

        # the heavy work
        self.create_function_page_props(functions)
        self.create_module_page_props()
        # add the pages to the page_props dict
        self.page_props = {
            **self.page_props,
            **self.function_page_props,
            **self.module_page_props,
        }
        # this adds pages for the intermediate directory structure (tests,
        # tests/berlin)
        self.add_directory_page_props()
        # add other interesting pages
        self.add_spec_page_props()
        self.add_markdown_page_props()
        # write pages and navigation menu
        self.write_pages()
        self.update_mkdocs_nav()

    @pytest.hookimpl(tryfirst=True)
    def pytest_runtestloop(self, session: pytest.Session) -> bool:
        """Skip test execution, only generate docs."""
        session.testscollected = 0
        return True

    def pytest_terminal_summary(
        self,
        terminalreporter: Any,
        exitstatus: int,
        config: pytest.Config,
    ) -> None:
        """Add a summary line for the docs."""
        del exitstatus, config
        terminalreporter.write_sep(
            "=", f"{len(self.page_props)} doc pages generated", bold=True
        )

    def _setup_logger(self) -> None:
        """
        Configure the mkdocs logger and adds a StreamHandler if outside mkdocs.

        We use the mkdocs logger to report warnings if conditions are invalid -
        this will inform the user and fail the build with `mkdocs build
        --strict`.
        """
        if not logger.hasHandlers() or logger.level == logging.NOTSET:
            stream_handler = logging.StreamHandler(sys.stdout)
            stream_handler.setLevel(logging.INFO)
            logger.addHandler(stream_handler)
            logger.setLevel(logging.INFO)

    def get_doc_site_base_url(self) -> str:
        """
        Return site's base in its URL for inclusion of local files.

        This is required in order to include docs/javascripts/site.js, for
        example, in the standalone html pages.

        Github pages deploys to a sub-directory "execution-spec-tests" and mike
        deploys a version of the site underneath a sub-directory named after
        the version, e.g.:

        - https://eest.ethereum.org/main/
        - https://eest.ethereum.org/v4.1.0/

        We need to be able to include the javascript available at:

        - https://eest.ethereum.org/main/javascripts/site.js
        """
        ci = os.getenv("CI", None)
        github_ref_name = os.getenv("GITHUB_REF_NAME", None)
        doc_version = os.getenv("GEN_TEST_DOC_VERSION", None)
        if ci and github_ref_name:
            return f"/execution-spec-tests/{github_ref_name}/"
        if ci and not github_ref_name:
            raise Exception(
                "Failed to determine target doc version "
                "(no GITHUB_REF_NAME env?)."
            )
        if (
            "--strict" in sys.argv or "deploy" in sys.argv
        ) and not doc_version:
            # assume we're trying to deploy manually via mike (locally)
            raise Exception(
                "Failed to determine target doc version during strict build "
                "(set GEN_TEST_DOC_VERSION env var)."
            )
        # local test build, e.g. via `uv run mkdocs serve`
        return "/execution-spec-tests/"

    def add_global_page_props_to_env(self) -> None:
        """Populate global page properties used in j2 templates."""
        global_page_props = {
            "target_fork": self.target_fork,
            "base_url": self.get_doc_site_base_url(),
            "deployed_forks": self.deployed_forks,
            "short_git_ref": get_current_commit_hash_or_tag(shorten_hash=True),
        }

        self.jinja2_env.globals.update(global_page_props)

    def create_function_page_props(
        self, test_functions: Dict["str", List[Item]]
    ) -> None:
        """
        Traverse all test items and create a lookup of doc pages & required
        props.

        To do: Needs refactor.
        """
        skip_params = ["fork"] + [
            spec_type.pytest_parameter_name()
            for spec_type in BaseTest.spec_types.values()
        ]
        for function_id, function_items in test_functions.items():
            assert all(
                isinstance(item, pytest.Function) for item in function_items
            )
            # help mypy infer type
            items = cast(List[pytest.Function], function_items)

            # extract parametrized test cases for each test function
            test_cases = []
            if getattr(items[0], "callspec", None):
                for item in items:
                    param_set = item.callspec.params
                    # Don't show skipped parameters as columns in the test case
                    # table
                    keys = [
                        key
                        for key in param_set.keys()
                        if key not in skip_params
                    ]
                    values = [param_set[key] for key in keys]
                    # TODO: This formatting of bytes objects should be moved
                    # elsewhere
                    values = [
                        (
                            " ".join(
                                f"<code>{chunk}</code>"
                                for chunk in textwrap.wrap(value.hex(), 32)
                            )
                            if isinstance(value, bytes)
                            else str(value)
                        )
                        for value in values
                    ]
                    fork = item.callspec.params.get("fork").name()  # type: ignore
                    test_type = get_test_function_test_type(item)
                    test_type_value = item.callspec.params.get(test_type)
                    fixture_type = test_type_value.format_name  # type: ignore
                    test_cases.append(
                        TestCase(
                            full_id=item.nodeid,
                            abbreviated_id=item.nodeid.split("[")[-1].rstrip(
                                "]"
                            ),
                            fork=fork,
                            fixture_type=fixture_type,
                            params=dict(zip(keys, values, strict=False)),
                        )
                    )

            module_relative_path = Path(items[0].module.__file__).relative_to(
                Path.cwd()
            )
            source_url = generate_github_url(
                str(module_relative_path),
                branch_or_commit_or_tag=self.ref,
                line_number=items[0].function.__code__.co_firstlineno,
            )
            valid_from_marker = items[0].get_closest_marker("valid_from")
            if not valid_from_marker:
                valid_from_fork = "Frontier"
            else:
                # valid_from marker, separated by a comma. Take the last.
                valid_from_fork = valid_from_marker.args[0].split(",")[-1]

            benchmark_dir = (
                Path(items[0].config.rootpath) / "tests" / "benchmark"
            )
            is_benchmark = benchmark_dir in Path(items[0].fspath).parents
            test_type = get_test_function_test_type(items[0])

            # Pick the displayed fork from the collected cases: the latest
            # base fork any case is parametrized for, with transition forks
            # resolved to the fork they transition into. Fall back to
            # `valid_from_fork` when nothing was collected.
            base_forks = {self._base_fork(case.fork) for case in test_cases}
            if base_forks:
                target_or_valid_fork = max(
                    base_forks,
                    key=lambda f: self._fork_newness.get(f, -1),
                )
            else:
                target_or_valid_fork = valid_from_fork

            # Count unique parametrizations at the displayed fork.
            # `case.params` already excludes `fork` and the fixture-type key
            # (see `skip_params` above), so a parametrization that produces
            # several fixture formats (e.g. benchmark -> `blockchain_test`
            # and `blockchain_test_engine`) collapses to a single case.
            unique_params = {
                tuple(sorted(case.params.items()))
                for case in test_cases
                if self._base_fork(case.fork) == target_or_valid_fork
            }
            test_case_count = len(unique_params)

            self.function_page_props[function_id] = FunctionPageProps(
                title=get_test_function_name(items[0]),
                source_code_url=source_url,
                target_or_valid_fork=target_or_valid_fork,
                path=module_relative_path,
                pytest_node_id=function_id,
                package_name=get_test_function_import_path(items[0]),
                test_case_count=test_case_count,
                cases=test_cases,
                fixture_formats=sorted(
                    {case.fixture_type for case in test_cases}
                ),
                test_type=test_type,
                docstring_one_liner=get_docstring_one_liner(items[0]),
                html_static_page_target=f"./{get_test_function_name(items[0])}.html",
                mkdocs_function_page_target=f"./{get_test_function_name(items[0])}/",
                is_benchmark=is_benchmark,
            )

    def create_module_page_props(self) -> None:
        """Discover the test module doc pages and extract their properties."""
        for _function_id, function_page in self.function_page_props.items():
            if str(function_page.path) not in self.module_page_props:
                module_path = function_page.path
                self.module_page_props[str(function_page.path)] = (
                    ModulePageProps(
                        title=sanitize_string_title(function_page.path.stem),
                        source_code_url=function_page.source_code_url,
                        target_or_valid_fork=function_page.target_or_valid_fork,
                        path=module_path,
                        pytest_node_id=str(module_path),
                        package_name=get_import_path(module_path),
                        is_benchmark=function_page.is_benchmark,
                        test_functions=[
                            TestFunction(
                                name=function_page.title,
                                test_type=function_page.test_type,
                                test_case_count=function_page.test_case_count,
                                docstring_one_liner=function_page.docstring_one_liner,
                            )
                        ],
                    )
                )
            else:
                existing_module_page = self.module_page_props[
                    str(function_page.path)
                ]
                if function_page.is_benchmark:
                    existing_module_page.is_benchmark = True
                existing_module_page.test_functions.append(
                    TestFunction(
                        name=function_page.title,
                        test_type=function_page.test_type,
                        test_case_count=function_page.test_case_count,
                        docstring_one_liner=function_page.docstring_one_liner,
                    )
                )

    def add_directory_page_props(self) -> None:
        """
        Discover the intermediate directory pages and extract their properties.

        These directories may not have any test modules within them, e.g.,
        tests/berlin/.
        """
        sub_paths: Set[Path] = set()
        for module_page in self.module_page_props.values():
            module_path_parts = module_page.path.parent.parts
            sub_paths.update(
                Path(*module_path_parts[: i + 1])
                for i in range(len(module_path_parts))
            )
        benchmark_root = self.source_dir / "benchmark"
        for directory in sub_paths:
            is_benchmark = (
                directory == benchmark_root
                or benchmark_root in directory.parents
            )
            directory_fork_name = (
                directory.relative_to(self.source_dir).parts[0].capitalize()
                if directory != self.source_dir
                else self.target_fork
            )
            if directory_fork_name in self.deployed_forks:
                fork = self.target_fork
            else:
                fork = directory_fork_name
            self.page_props[str(directory)] = DirectoryPageProps(
                title=sanitize_string_title(str(directory.name)),
                path=directory,
                pytest_node_id=str(directory),
                source_code_url=generate_github_url(
                    str(directory), branch_or_commit_or_tag=self.ref
                ),
                # TODO: This won't work in all cases; should be from the
                # development fork
                target_or_valid_fork=fork.capitalize() if fork else "Unknown",
                # init.py will be used for docstrings
                package_name=get_import_path(directory),
                is_benchmark=is_benchmark,
            )

    def find_files_within_collection_scope(
        self, file_pattern: str
    ) -> List[Path]:
        """
        Find all files that match the scope of the collected test modules.

        This to avoid adding matching files in uncollected test directories.

        Note: could be optimized!
        """
        files = []
        for module_page in self.module_page_props.values():
            # all files found in and under the modules' directory
            files += glob.glob(
                f"{module_page.path.parent}/**/{file_pattern}", recursive=True
            )
            for parent in module_page.path.parent.parents:
                if parent == self.source_dir:
                    break
                # add files in a module's parent directory
                files += glob.glob(f"{parent}/{file_pattern}")
        return [Path(file) for file in set(files)]

    def add_spec_page_props(self) -> None:
        """
        Add page path properties for spec files discovered in the collection
        scope.
        """
        for spec_path in self.find_files_within_collection_scope("spec.py"):
            self.page_props[str(spec_path)] = ModulePageProps(
                title="Spec",
                path=spec_path,
                source_code_url=generate_github_url(
                    str(spec_path), branch_or_commit_or_tag=self.ref
                ),
                pytest_node_id=str(spec_path),
                package_name=get_import_path(spec_path),
                target_or_valid_fork="",
                test_functions=[],
            )

    def add_markdown_page_props(self) -> None:
        """
        Add page path properties for markdown files discovered in the
        collection scope.
        """
        for md_path in self.find_files_within_collection_scope("*.md"):
            self.page_props[str(md_path)] = MarkdownPageProps(
                title=md_path.stem,
                path=md_path,
                source_code_url=generate_github_url(
                    str(md_path), branch_or_commit_or_tag=self.ref
                ),
                # abuse: not a test, but used in source code link
                pytest_node_id=str(md_path),
                target_or_valid_fork="",
                package_name="",
            )

    def update_mkdocs_nav(self) -> None:
        """
        Add the generated 'Test Case Reference' entries to the mkdocs
        navigation menu.
        """

        # Fork directories on disk are snake_case (e.g. `tangerine_whistle`)
        # but `fork.name()` is CamelCase (`TangerineWhistle`).
        def _dir_name(fork_name: str) -> str:
            s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", fork_name)
            return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

        fork_order = {
            _dir_name(fork.name()): i
            for i, fork in enumerate(reversed(get_forks()))
        }
        # Benchmark entries sort above all fork entries.
        fork_order["benchmark"] = -1

        def sort_by_fork_deployment_and_path(x: PageProps) -> Tuple[Any, ...]:
            """
            Key function used to sort navigation menu entries for test case ref
            docs.

            Nav entries / output files contain special cases such as:

            - ("Test Case Reference",) -> tests/index.md
            - ("Test Case Reference", "Berlin") -> tests/berlin/index.md
            - ("Test Case Reference", "Shanghai", "EIP-3855 PUSH0", "Spec") ->
            tests/shanghai/eip3855_push0/spec.py

            This function provides and ordering to sort nav men entries as
            follows:

            1. Forks are listed in the chronological order that they were
            deployed.
            2. Special files listed first (before test pages): "*.md"
            and `Spec.py`,
            3. The page's corresponding file path under
            `./tests/`.
            """
            length = len(x.path.parts)
            if length > 1:
                # the fork folder from the relative path
                fork = str(x.path.parts[1]).lower()
                # unscheduled features added to the end
                if fork not in fork_order:
                    return (999, str(x.path))
            if length == 1:
                return (0,)
            elif length == 2:
                return (1, fork_order[fork])
            elif x.path.name == "spec.py":
                return (2, fork_order[fork], length, 0, x.path)
            elif x.path.suffix == ".md":
                return (2, fork_order[fork], length, 1, x.path)
            else:
                return (2, fork_order[fork], length, 2, x.path)

        nav = mkdocs_gen_files.Nav()
        for page in sorted(
            self.page_props.values(), key=sort_by_fork_deployment_and_path
        ):
            nav[page.nav_entry(self.top_level_nav_entry)] = str(
                page.target_output_file
            )
        with mkdocs_gen_files.open("navigation.md", "a") as nav_file:
            nav_file.writelines(nav.build_literate_nav())

    def write_pages(self) -> None:
        """Write all pages to the target directory."""
        for page in self.page_props.values():
            page.write_page(mkdocs_gen_files, self.jinja2_env)  # type: ignore[arg-type, unused-ignore]
