"""
Pytest plugin for generating EIP test completion checklists.

This plugin collects checklist markers from tests and generates a filled
checklist for each EIP based on the template at
docs/writing_tests/checklist_templates/eip_testing_checklist_template.md
"""

import logging
import os
import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import ClassVar, Dict, List, Set, Tuple, Type

import pytest

from .gen_test_doc.page_props import EipChecklistPageProps

logger = logging.getLogger("mkdocs")


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add command-line options for checklist generation."""
    group = parser.getgroup("checklist", "EIP checklist generation options")
    group.addoption(
        "--checklist-output",
        action="store",
        dest="checklist_output",
        type=Path,
        default=Path("./checklists"),
        help="Directory to output the generated checklists",
    )
    group.addoption(
        "--checklist-eip",
        action="append",
        dest="checklist_eips",
        type=int,
        default=[],
        help="Generate checklist only for specific EIP(s)",
    )
    group.addoption(
        "--checklist-doc-gen",
        action="store_true",
        dest="checklist_doc_gen",
        default=False,
        help="Generate checklists for documentation (uses mkdocs_gen_files)",
    )


TITLE_LINE = "# EIP Execution Layer Testing Checklist Template"
PERCENTAGE_LINE = (
    "| TOTAL_CHECKLIST_ITEMS | COVERED_CHECKLIST_ITEMS | PERCENTAGE |"
)

TEMPLATE_PATH = (
    Path(__file__).parents[8]
    / "docs"
    / "writing_tests"
    / "checklist_templates"
    / "eip_testing_checklist_template.md"
)
TEMPLATE_CONTENT = TEMPLATE_PATH.read_text()
EXTERNAL_COVERAGE_FILE_NAME = "eip_checklist_external_coverage.txt"
NOT_APPLICABLE_FILE_NAME = "eip_checklist_not_applicable.txt"
WARNINGS_LINE = "<!-- WARNINGS LINE -->"


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config: pytest.Config) -> None:  # noqa: D103
    config.pluginmanager.register(
        EIPChecklistCollector(), "eip-checklist-collector"
    )


@dataclass(kw_only=True)
class EIPItem:
    """Represents an EIP checklist item."""

    id: str
    line_number: int
    description: str
    tests: Set[str]
    not_applicable_reason: str = ""
    external_coverage_reason: str = ""

    @classmethod
    def from_checklist_line(
        cls, *, line: str, line_number: int
    ) -> "EIPItem | None":
        """Create an EIP item from a checklist line."""
        match = re.match(r"\|\s*`([^`]+)`\s*\|\s*([^|]+)\s*\|", line)
        if not match:
            return None
        return cls(
            id=match.group(1),
            line_number=line_number,
            description=match.group(2),
            tests=set(),
        )

    @property
    def covered(self) -> bool:
        """Return True if the item is covered by at least one test."""
        return len(self.tests) > 0 or self.external_coverage

    @property
    def external_coverage(self) -> bool:
        """Return True if the item is covered by an external test/procedure."""
        return self.external_coverage_reason != ""

    @property
    def not_applicable(self) -> bool:
        """Return True if the item is not applicable."""
        return self.not_applicable_reason != ""

    def __str__(self) -> str:
        """Return a string representation of the EIP item."""
        status = " "
        tests = ""
        if self.external_coverage:
            status = "✅"
            tests = self.external_coverage_reason
        elif self.covered:
            if self.not_applicable:
                status = "❓"
            else:
                status = "✅"
            tests = ", ".join(sorted(self.tests))
        elif self.not_applicable:
            status = "N/A"
            tests = self.not_applicable_reason

        return f"| `{self.id}` | {self.description} | {status} | {tests} |"


TEMPLATE_ITEMS: Dict[str, EIPItem] = {}
# Parse the template to extract checklist item IDs and descriptions
for i, line in enumerate(TEMPLATE_CONTENT.splitlines()):
    # Match lines that contain checklist items with IDs in backticks
    if item := EIPItem.from_checklist_line(line=line, line_number=i + 1):
        TEMPLATE_ITEMS[item.id] = item


def template_items() -> Dict[str, EIPItem]:
    """Return a copy of the template items."""
    new_items = {}
    for test_id, item in TEMPLATE_ITEMS.items():
        new_items[test_id] = EIPItem(
            id=item.id,
            line_number=item.line_number,
            description=item.description,
            tests=set(),
        )
    return new_items


ALL_IDS = set(TEMPLATE_ITEMS.keys())


def resolve_id(item_id: str) -> Set[str]:
    """Resolve an item ID to a set of checklist IDs."""
    covered_ids = {
        checklist_id
        for checklist_id in ALL_IDS
        if checklist_id == item_id or checklist_id.startswith(item_id + "/")
    }
    return covered_ids


ALL_CHECKLIST_WARNINGS: Dict[str, Type["ChecklistWarning"]] = {}


@dataclass(kw_only=True)
class ChecklistWarning:
    """Represents an EIP checklist warning."""

    title: ClassVar[str] = ""
    details: List[str]

    def __init_subclass__(cls) -> None:
        """Register the checklist warning subclass."""
        super().__init_subclass__()
        assert cls.title, "Title must be set"
        if cls.title in ALL_CHECKLIST_WARNINGS:
            raise ValueError(f"Duplicate checklist warning class: {cls}")
        ALL_CHECKLIST_WARNINGS[cls.title] = cls

    def lines(self) -> List[str]:
        """Return the lines of the checklist warning."""
        return ["", f"### {self.title}", ""] + self.details + [""]

    @classmethod
    def from_items(
        cls, all_items: Dict[str, EIPItem]
    ) -> "ChecklistWarning | None":
        """Generate a checklist warning from a list of items."""
        raise NotImplementedError(f"from_items not implemented for {cls}")


class ConflictingChecklistItemsWarning(ChecklistWarning):
    """Represents a conflicting checklist items warning."""

    title: ClassVar[str] = "Conflicting Checklist Items"

    @classmethod
    def from_items(
        cls, all_items: Dict[str, EIPItem]
    ) -> ChecklistWarning | None:
        """
        Generate a conflicting checklist items warning from a list of items.
        """
        conflicting_items = [
            item
            for item in all_items.values()
            if item.not_applicable and item.covered
        ]
        if not conflicting_items:
            return None

        details = [
            "The following checklist items were marked both "
            "as not applicable and covered:",
            "",
            "| ID | Description | Not Applicable | Tests |",
            "|---|---|---|---|",
        ]
        for item in conflicting_items:
            tests_str = ", ".join(sorted(item.tests))
            details.append(
                f"| {item.id} | {item.description} | "
                f"{item.not_applicable_reason} | {tests_str} |"
            )

        return cls(details=details)


@dataclass(kw_only=True)
class EIP:
    """Represents an EIP and its checklist."""

    number: int
    items: Dict[str, EIPItem] = field(default_factory=template_items)
    path: Path | None = None

    def add_covered_test(self, checklist_id: str, node_id: str) -> None:
        """Add a covered test to the EIP."""
        self.items[checklist_id].tests.add(node_id)

    @property
    def covered_items(self) -> int:
        """Return the number of covered items."""
        return sum(
            1
            for item in self.items.values()
            if item.covered and not item.not_applicable
        )

    @property
    def total_items(self) -> int:
        """Return the number of total items."""
        return sum(
            1 for item in self.items.values() if not item.not_applicable
        )

    @property
    def percentage(self) -> float:
        """Return the percentage of covered items."""
        return (
            self.covered_items / self.total_items * 100
            if self.total_items
            else 0
        )

    @property
    def completeness_emoji(self) -> str:
        """Return the completeness emoji."""
        return (
            "🟢"
            if self.percentage == 100
            else "🟡"
            if self.percentage > 50
            else "🔴"
        )

    @property
    def warnings(self) -> List[ChecklistWarning]:
        """Return the detected inconsistencies in the checklist."""
        warnings = []
        for warning_cls in ALL_CHECKLIST_WARNINGS.values():
            if warning := warning_cls.from_items(self.items):
                warnings.append(warning)
        return warnings

    def mark_not_applicable(self) -> None:
        """Read the not-applicable items from the EIP."""
        if self.path is None:
            return
        not_applicable_path = self.path / NOT_APPLICABLE_FILE_NAME
        if not not_applicable_path.exists():
            return
        with not_applicable_path.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                assert "=" in line
                item_id, reason = line.split("=", 1)
                item_id = item_id.strip()
                reason = reason.strip()
                assert reason, f"Reason is empty for {line}"
                assert item_id, f"Item ID is empty for {line}"
                ids = resolve_id(item_id)
                if not ids:
                    logger.warning(
                        f"Item ID {item_id} not found in checklist template "
                        f"for EIP {self.number}"
                    )
                    continue
                for id_covered in ids:
                    self.items[id_covered].not_applicable_reason = reason

    def mark_external_coverage(self) -> None:
        """Read the externally covered items from the EIP."""
        if self.path is None:
            return
        external_coverage_path = self.path / EXTERNAL_COVERAGE_FILE_NAME
        if not external_coverage_path.exists():
            return
        with external_coverage_path.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                assert "=" in line
                item_id, reason = line.split("=", 1)
                item_id = item_id.strip()
                reason = reason.strip()
                assert item_id, f"Item ID is empty for {line}"
                assert reason, f"Reason is empty for {line}"
                ids = resolve_id(item_id)
                if not ids:
                    logger.warning(
                        f"Item ID {item_id} not found in checklist template "
                        f"for EIP {self.number}"
                    )
                    continue
                for id_covered in ids:
                    self.items[id_covered].external_coverage_reason = reason

    def generate_filled_checklist_lines(self) -> List[str]:
        """Generate the filled checklist lines for a specific EIP."""
        # Create a copy of the template content
        lines = TEMPLATE_CONTENT.splitlines()

        self.mark_not_applicable()
        self.mark_external_coverage()

        for index, line in enumerate(lines):
            if template_item := EIPItem.from_checklist_line(
                line=line, line_number=index + 1
            ):
                # An ID can describe several outcomes on separate rows.
                # Share its coverage while preserving each description.
                lines[index] = str(
                    replace(
                        self.items[template_item.id],
                        description=template_item.description,
                    )
                )

        emoji = self.completeness_emoji
        pct = f"{self.percentage:.2f}%"
        lines[lines.index(PERCENTAGE_LINE)] = (
            f"| {self.total_items} | {self.covered_items} | {emoji} {pct} |"
        )

        # Replace the title line with the EIP number
        lines[lines.index(TITLE_LINE)] = f"# EIP-{self.number} Test Checklist"

        # Last, add the warnings if there are any, this must be the last thing
        # we do to avoid shifting the lines below the percentage line
        if self.warnings:
            warnings_line_idx = lines.index(WARNINGS_LINE)
            warnings_lines = ["", "## ⚠️ Checklist Warnings ⚠️", ""]
            for warning in self.warnings:
                warnings_lines.extend(warning.lines())
            lines[warnings_line_idx:warnings_line_idx] = warnings_lines

        return lines

    def generate_filled_checklist(self, output_dir: Path) -> Path:
        """Generate a filled checklist for a specific EIP."""
        lines = self.generate_filled_checklist_lines()

        output_dir = output_dir / f"eip{self.number}_checklist.md"

        # Write the filled checklist
        output_dir.parent.mkdir(exist_ok=True, parents=True)
        output_dir.write_text("\n".join(lines))

        return output_dir


def _find_eip_dir(tests_root: Path, eip_number: int) -> Path | None:
    """
    Return the first `eip<N>_*` directory under `tests_root`, if any.

    Used as a fallback when an EIP is referenced from a test outside its
    own `eipNNNN/` directory via the `eip=[N]` kwarg of `eip_checklist`,
    so the checklist doc can still be attached to the EIP's canonical
    location even when none of its primary tests were collected.
    """
    for match in tests_root.rglob(f"eip{eip_number}_*"):
        if match.is_dir():
            return match
    return None


class EIPChecklistCollector:
    """Collects and manages EIP checklist items from test markers."""

    def __init__(self: "EIPChecklistCollector") -> None:
        """Initialize the EIP checklist collector."""
        self.eips: Dict[int, EIP] = {}

    def extract_eip_from_path(
        self, test_path: Path
    ) -> Tuple[int | None, Path | None]:
        """Extract EIP number from test file path."""
        # Look for patterns like eip1234_ or eip1234/ in the path
        for part_idx, part in enumerate(test_path.parts):
            match = re.match(r"eip(\d+)", part)
            if match:
                eip = int(match.group(1))
                eip_path = test_path.parents[
                    len(test_path.parents) - part_idx - 2
                ]
                return eip, eip_path
        return None, None

    def get_eip_from_item(self, item: pytest.Item) -> EIP | None:
        """Get the EIP for a test item."""
        # The collected module, not `item.location`, which for a test built
        # by a generator points at the module that defines the wrapper.
        # `os.path.relpath` rather than `Path.relative_to`, which raises for
        # a test collected from outside the rootpath.
        test_path = Path(os.path.relpath(item.path, item.config.rootpath))
        for part_idx, part in enumerate(test_path.parts):
            match = re.match(r"eip(\d+)", part)
            if match:
                eip = int(match.group(1))
                if eip not in self.eips:
                    self.eips[eip] = EIP(
                        number=eip,
                        path=test_path.parents[
                            len(test_path.parents) - part_idx - 2
                        ],
                    )
                else:
                    if self.eips[eip].path is None:
                        self.eips[eip].path = test_path.parents[
                            len(test_path.parents) - part_idx - 2
                        ]
                return self.eips[eip]
        return None

    def get_eip(self, eip: int) -> EIP:
        """Get the EIP for a given EIP number."""
        if eip not in self.eips:
            self.eips[eip] = EIP(number=eip, path=None)
        return self.eips[eip]

    def collect_from_item(
        self, item: pytest.Item, primary_eip: EIP | None
    ) -> None:
        """Collect checklist markers from a test item."""
        for marker in item.iter_markers("eip_checklist"):
            if not marker.args:
                pytest.fail(
                    f"eip_checklist marker on {item.nodeid} must have "
                    "at least one argument (item_id)"
                )
            additional_eips = marker.kwargs.get("eip", [])
            if not isinstance(additional_eips, list):
                additional_eips = [additional_eips]

            eips: List[EIP] = [primary_eip] if primary_eip else []

            if additional_eips:
                if any(not isinstance(eip, int) for eip in additional_eips):
                    pytest.fail(
                        "EIP numbers must be integers. Found non-integer "
                        f"EIPs in {item.nodeid}: {additional_eips}"
                    )
                eips += [self.get_eip(eip) for eip in additional_eips]

            for item_id in marker.args:
                item_id = str(item_id)
                covered_ids = resolve_id(item_id.strip())
                if marker.kwargs.get("exact", False):
                    covered_ids &= {item_id.strip()}
                if not covered_ids:
                    logger.warning(
                        f"Item ID {item_id} not found in checklist template "
                        f"for test {item.nodeid}"
                    )
                    continue
                for id_covered in covered_ids:
                    for eip in eips:
                        eip.add_covered_test(id_covered, item.nodeid)

    @pytest.hookimpl(tryfirst=True)
    def pytest_runtestloop(self, session: pytest.Session) -> bool:
        """Skip test execution, only generate checklists."""
        session.testscollected = 0
        return True

    def pytest_collection_modifyitems(
        self, config: pytest.Config, items: List[pytest.Item]
    ) -> None:
        """Collect checklist markers during test collection."""
        for item in items:
            eip = self.get_eip_from_item(item)
            if not item.get_closest_marker(
                "primary_format"
            ) or item.get_closest_marker("skip"):
                continue
            self.collect_from_item(item, eip)

        # Back-fill the canonical `eipNNNN_*` directory for any EIP added
        # via the `eip=[N]` kwarg of `eip_checklist` whose primary tests
        # weren't collected (e.g. because of a `-m` filter or `--until`).
        tests_root = Path(config.rootpath) / "tests"
        for eip in self.eips.values():
            if eip.path is None:
                eip.path = _find_eip_dir(tests_root, eip.number)

        # Check which mode we are in
        checklist_doc_gen = config.getoption("checklist_doc_gen", False)
        checklist_output = config.getoption(
            "checklist_output", Path("checklists")
        )
        checklist_eips = config.getoption("checklist_eips", [])

        checklist_props = {}
        # Generate a checklist for each EIP
        for eip in self.eips.values():
            # Skip if specific EIPs were requested and this isn't one of them
            if checklist_eips and eip.number not in checklist_eips:
                continue

            if checklist_doc_gen:
                if eip.path is None:
                    logger.warning(
                        f"EIP-{eip.number} was referenced via the `eip` "
                        "kwarg of `eip_checklist` but no `eip"
                        f"{eip.number}_*` directory was found under "
                        "tests/; skipping checklist doc generation for it."
                    )
                    continue
                checklist_path = eip.path / "checklist.md"
                checklist_props[checklist_path] = EipChecklistPageProps(
                    title=f"EIP-{eip.number} Test Checklist",
                    source_code_url="",
                    target_or_valid_fork="mainnet",
                    path=checklist_path,
                    pytest_node_id="",
                    package_name="checklist",
                    eip=eip.number,
                    lines=eip.generate_filled_checklist_lines(),
                )
            else:
                checklist_path = eip.generate_filled_checklist(
                    checklist_output
                )
                print(
                    f"\nGenerated EIP-{eip.number} checklist: {checklist_path}"
                )

        if checklist_doc_gen:
            config.checklist_props = checklist_props  # type: ignore
