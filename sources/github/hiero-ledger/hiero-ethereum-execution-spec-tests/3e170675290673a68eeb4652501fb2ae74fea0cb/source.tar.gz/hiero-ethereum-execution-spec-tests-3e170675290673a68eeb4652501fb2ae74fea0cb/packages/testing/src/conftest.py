"""Local pytest configuration used on multiple framework tests."""

import os
from typing import Dict, Generator

import pytest

from execution_testing.client_clis import (
    BesuTransitionTool,
    ExecutionSpecsTransitionTool,
    GethTransitionTool,
    TransitionTool,
)

DEFAULT_TRANSITION_TOOL_FOR_UNIT_TESTS = ExecutionSpecsTransitionTool

INSTALLED_TRANSITION_TOOLS = [
    transition_tool
    for transition_tool in TransitionTool.registered_tools
    if (
        transition_tool.is_installed()
        # Currently, Besu has the same `default_binary` as Geth, so we can't
        # use `is_installed`.
        and transition_tool != BesuTransitionTool
    )
]


@pytest.fixture(scope="session")
def installed_transition_tool_instances() -> Generator[
    Dict[str, TransitionTool | Exception], None, None
]:
    """Return all instantiated transition tools."""
    instances: Dict[str, TransitionTool | Exception] = {}
    for transition_tool_class in INSTALLED_TRANSITION_TOOLS:
        try:
            transition_tool_instance = transition_tool_class()
            transition_tool_instance.start_server()
            instances[transition_tool_class.__name__] = (
                transition_tool_instance
            )
        except Exception as e:
            # Record the exception in order to provide context when failing the
            # appropriate test
            instances[transition_tool_class.__name__] = e
    yield instances
    for instance in instances.values():
        if isinstance(instance, TransitionTool):
            instance.shutdown()


@pytest.fixture(
    params=[
        pytest.param(
            transition_tool,
            marks=[pytest.mark.xfail(reason="Geth t8n needs update")]
            if transition_tool == GethTransitionTool
            else [],
            id=transition_tool.__name__,
        )
        for transition_tool in INSTALLED_TRANSITION_TOOLS
    ]
)
def installed_t8n(
    request: pytest.FixtureRequest,
    installed_transition_tool_instances: Dict[str, TransitionTool | Exception],
) -> TransitionTool:
    """
    Return an instantiated transition tool.

    Tests using this fixture will be automatically parameterized with all
    installed transition tools.
    """
    transition_tool_class = request.param
    assert issubclass(transition_tool_class, TransitionTool)
    assert (
        transition_tool_class.__name__ in installed_transition_tool_instances
    ), f"{transition_tool_class.__name__} not instantiated"
    instance_or_error = installed_transition_tool_instances[
        transition_tool_class.__name__
    ]
    if isinstance(instance_or_error, Exception):
        raise Exception(
            f"Failed to instantiate {transition_tool_class.__name__}"
        ) from instance_or_error
    return instance_or_error


@pytest.fixture
def default_t8n(
    installed_transition_tool_instances: Dict[str, TransitionTool | Exception],
) -> TransitionTool:
    """Fixture to provide a default t8n instance."""
    instance = installed_transition_tool_instances.get(
        DEFAULT_TRANSITION_TOOL_FOR_UNIT_TESTS.__name__
    )
    if instance is None:
        tool_name = DEFAULT_TRANSITION_TOOL_FOR_UNIT_TESTS.__name__
        raise Exception(f"Failed to instantiate {tool_name}")
    if isinstance(instance, Exception):
        tool_name = DEFAULT_TRANSITION_TOOL_FOR_UNIT_TESTS.__name__
        raise Exception(f"Failed to instantiate {tool_name}") from instance
    return instance


@pytest.fixture(scope="session")
def running_in_ci() -> bool:
    """Return whether the test is running in a CI environment."""
    return "CI" in os.environ
