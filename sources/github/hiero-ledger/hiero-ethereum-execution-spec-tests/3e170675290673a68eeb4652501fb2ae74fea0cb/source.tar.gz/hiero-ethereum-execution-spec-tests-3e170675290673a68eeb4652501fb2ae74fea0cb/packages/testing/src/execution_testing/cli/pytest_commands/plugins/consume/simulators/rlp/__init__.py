"""Consume RLP test functions."""
