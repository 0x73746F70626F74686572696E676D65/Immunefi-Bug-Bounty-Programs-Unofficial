"""
A small pytest plugin that shows a concise help string that only contains
the options defined by the plugins defined in execution-spec-tests.
"""

import argparse
from pathlib import Path

import pytest


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add command-line options to pytest for specific help commands."""
    help_group = parser.getgroup(
        "help_options", "Help options for different commands"
    )
    help_group.addoption(
        "--check-eip-versions-help",
        action="store_true",
        dest="show_check_eip_versions_help",
        default=False,
        help=(
            "Show help options only for the check_eip_versions command "
            "and exit."
        ),
    )
    help_group.addoption(
        "--fill-help",
        action="store_true",
        dest="show_fill_help",
        default=False,
        help="Show help options only for the fill command and exit.",
    )
    help_group.addoption(
        "--fill-stateful-help",
        action="store_true",
        dest="show_fill_stateful_help",
        default=False,
        help=(
            "Show help options only for the fill-stateful command and exit."
        ),
    )
    help_group.addoption(
        "--consume-help",
        action="store_true",
        dest="show_consume_help",
        default=False,
        help="Show help options specific to the consume command and exit.",
    )
    help_group.addoption(
        "--execute-remote-help",
        action="store_true",
        dest="show_execute_help",
        default=False,
        help=(
            "Show help options specific to the execute remote command "
            "and exit."
        ),
    )
    help_group.addoption(
        "--execute-hive-help",
        action="store_true",
        dest="show_execute_hive_help",
        default=False,
        help=(
            "Show help options specific to the execute hive command and exit."
        ),
    )
    help_group.addoption(
        "--execute-recover-help",
        action="store_true",
        dest="show_execute_recover_help",
        default=False,
        help=(
            "Show help options specific to the execute recover command "
            "and exit."
        ),
    )
    help_group.addoption(
        "--execute-eth-config-help",
        action="store_true",
        dest="show_execute_eth_config_help",
        default=False,
        help=(
            "Show help options specific to the execute eth_config command "
            "and exit."
        ),
    )


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config: pytest.Config) -> None:
    """
    Handle specific help flags by displaying the corresponding help message.
    """
    if config.getoption("show_check_eip_versions_help"):
        show_specific_help(
            config,
            "pytest-check-eip-versions.ini",
            [
                "spec_version_checker",
                "EIP spec version",
            ],
            show_test_paths=True,
        )
    elif config.getoption("show_fill_help"):
        show_specific_help(
            config,
            "pytest-fill.ini",
            [
                "evm",
                "fork range",
                "filler location",
                "defining debug",
                "pre-allocation behavior during test filling",
                "ported",
                "benchmark",
            ],
        )
    elif config.getoption("show_fill_stateful_help"):
        show_specific_help(
            config,
            "pytest-fill-stateful.ini",
            [
                "fill_stateful",
                "stateful fixture",
                "remote RPC configuration",
                "filler location",
                "benchmark",
            ],
        )
    elif config.getoption("show_consume_help"):
        show_specific_help(
            config,
            "pytest-consume.ini",
            [
                "consuming",
            ],
        )
    elif config.getoption("show_execute_help"):
        show_specific_help(
            config,
            "pytest-execute.ini",
            [
                "execute",
                "remote RPC configuration",
                "pre-allocation behavior during test execution",
                "sender key fixtures",
                "remote seed sender",
                "chain configuration",
                "benchmark",
            ],
        )
    elif config.getoption("show_execute_hive_help"):
        show_specific_help(
            config,
            "pytest-execute-hive.ini",
            [
                "execute",
                "hive RPC client",
                "pre-allocation behavior during test execution",
                "sender key fixtures",
                "remote seed sender",
                "chain configuration",
                "benchmark",
            ],
        )
    elif config.getoption("show_execute_recover_help"):
        show_specific_help(
            config,
            "pytest-execute-recover.ini",
            [
                "fund recovery",
                "remote RPC configuration",
                "remote seed sender",
                "chain configuration",
            ],
        )
    elif config.getoption("show_execute_eth_config_help"):
        show_specific_help(
            config,
            "pytest-execute-eth-config.ini",
            [
                "eth_config",
                "chain configuration",
            ],
        )


def show_specific_help(
    config: pytest.Config,
    expected_ini: str,
    substrings: list[str],
    show_test_paths: bool = False,
) -> None:
    """
    Print help options filtered by specific substrings from the given
    configuration.
    """
    pytest_ini = Path(config.inifile)  # type: ignore
    if pytest_ini.name != expected_ini:
        raise ValueError(
            f"Unexpected {expected_ini}!={pytest_ini.name} file option "
            "generating help."
        )

    test_parser = argparse.ArgumentParser()
    for group in config._parser.optparser._action_groups:
        title: str | None = group.title
        if title and any(substring in title for substring in substrings):
            new_group = test_parser.add_argument_group(
                group.title, group.description
            )
            for action in group._group_actions:
                kwargs = {
                    "default": action.default,
                    "help": action.help,
                    "required": action.required,
                }
                if isinstance(action, argparse._StoreTrueAction):
                    kwargs["action"] = "store_true"
                else:
                    kwargs["type"] = action.type
                if action.nargs:
                    kwargs["nargs"] = action.nargs
                new_group.add_argument(*action.option_strings, **kwargs)

    if show_test_paths:
        test_parser.add_argument(
            "test_path",
            nargs="*",
            metavar="<test-path>",
            help=(
                "Limit collection to the given test paths, e.g. "
                "`tests/amsterdam` or a single test module. The whole test "
                "tree is collected if no path is given."
            ),
        )

    print(test_parser.format_help())
    pytest.exit("After displaying help.", returncode=pytest.ExitCode.OK)
