"""Transition tool abstract class."""

import contextlib
import cProfile
import json
import os
import shutil
import subprocess
import tempfile
import textwrap
import time
from abc import abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import (
    Any,
    ClassVar,
    ContextManager,
    Dict,
    Generator,
    List,
    LiteralString,
    Mapping,
    Optional,
    Type,
)
from urllib.parse import urlencode

from requests import Response
from requests.exceptions import ConnectionError as RequestsConnectionError
from requests.exceptions import ReadTimeout
from requests_unixsocket import Session

from execution_testing.base_types import BlobSchedule
from execution_testing.base_types.composite_types import (
    ForkBlobSchedule,
)
from execution_testing.exceptions import ExceptionMapper
from execution_testing.forks import Fork
from execution_testing.forks.helpers import (
    get_development_forks,
    get_forks,
)
from execution_testing.test_types import Alloc, Environment, Transaction

from .cli_types import (
    LazyAlloc,
    LazyAllocFile,
    OpcodeCount,
    Traces,
    TransactionReceipt,
    TransactionTraces,
    TransitionToolContext,
    TransitionToolInput,
    TransitionToolOutput,
    TransitionToolRequest,
)
from .ethereum_cli import EthereumCLI
from .file_utils import dump_files_to_directory

model_dump_config: Mapping = {"by_alias": True, "exclude_none": True}

# TODO: reduce NORMAL_SERVER_TIMEOUT back down to 20 once BLS timeout issue is
# resolved: https://github.com/ethereum/execution-spec-tests/issues/1894
NORMAL_SERVER_TIMEOUT = 600
SLOW_REQUEST_TIMEOUT = 600


class Profiler:
    """
    Small helper to manage optional profiling and pausing.
    """

    def __init__(
        self,
        enabled: bool = False,
        filename: Optional[Path] = None,
    ) -> None:
        """Initialize the profiler."""
        self.enabled = enabled
        self.filename = filename
        self._prof: Optional[cProfile.Profile] = (
            cProfile.Profile() if enabled else None
        )

    def __enter__(self) -> "Profiler":
        """Enter the profiler context manager."""
        if self._prof:
            self._prof.enable()
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """
        Exit the profiler context manager, and dump the stats if enabled.
        """
        if self._prof:
            self._prof.disable()
            if self.filename:
                self._prof.dump_stats(str(self.filename))

    def pause(self) -> ContextManager[None]:
        """Context manager that temporarily disables profiling, if enabled."""
        prof = self._prof
        if prof is None:
            return contextlib.nullcontext()

        @contextlib.contextmanager
        def _paused() -> Generator[None, None, None]:
            prof.disable()
            try:
                yield
            finally:
                prof.enable()

        return _paused()


def get_valid_transition_tool_names() -> set[str]:
    """
    Get all valid transition tool names from deployed and development forks.
    """
    all_available_forks = get_forks() + get_development_forks()
    return {fork.transition_tool_name() for fork in all_available_forks}


class OutputCache:
    """
    Single-key cache for t8n outputs.

    Stores results for one test at a time. When the key changes, the previous
    cache is cleared. Works with xdist loadgroup which ensures related fixture
    formats run on the same worker.
    """

    def __init__(self) -> None:
        """Initialize the cache."""
        self._cache: Dict[int, TransitionToolOutput] = {}
        self.key: str | None = None
        self.hits = 0
        self.misses = 0

    def set_key(self, key: str) -> bool:
        """
        Set the current key, returning True if it was already cached.

        Clears the cache when the key changes.
        """
        if key == self.key:
            return True
        # New key - clear cache and start fresh
        self._cache.clear()
        self.key = key
        return False

    def get(self, subkey: int) -> TransitionToolOutput | None:
        """Get a value from the cache for the current key."""
        if subkey in self._cache:
            self.hits += 1
            return self._cache[subkey]
        self.misses += 1
        return None

    def set(self, subkey: int, value: TransitionToolOutput) -> None:
        """Set a value in the cache for the current key."""
        alloc = getattr(value, "alloc", None)
        if isinstance(alloc, LazyAllocFile):
            # Materialize the streamed alloc before caching so the producing
            # `TemporaryDirectory` (pinned via `_keepalive`) can be released.
            # Without this, every cached subcall would retain its own
            # `output/alloc.json` on disk for the test's lifetime - O(N) for
            # an N-block chained test.
            alloc.materialize()
            alloc._keepalive = None
        self._cache[subkey] = value

    def clear(self) -> None:
        """Clear the cache and reset the key."""
        self._cache.clear()
        self.key = None


class TransitionTool(EthereumCLI):
    """
    Transition tool abstract base class which should be inherited by all
    transition tool implementations.
    """

    traces: List[Traces] | None = None

    registered_tools: List[Type["TransitionTool"]] = []
    default_tool: Optional[Type["TransitionTool"]] = None

    exception_mapper: ExceptionMapper

    subcommand: Optional[str] = None
    cached_version: Optional[str] = None
    t8n_use_stream: bool = False
    t8n_use_server: bool = False
    server_url: str | None = None
    process: Optional[subprocess.Popen] = None
    output_cache: OutputCache | None = None
    debug_dump_dir: Path | None = None
    call_counter: int = 0
    opcode_count: OpcodeCount | None = None
    opcode_count_per_block: List[OpcodeCount] | None = None

    supports_opcode_count: ClassVar[bool] = False
    supports_xdist: ClassVar[bool] = True
    supports_blob_params: ClassVar[bool] = False
    attests_block_access_list_hash: ClassVar[bool] = True
    fork_name_map: ClassVar[Dict[str, str]] = {}

    @abstractmethod
    def __init__(
        self,
        *,
        exception_mapper: Optional[ExceptionMapper] = None,
        binary: Optional[Path] = None,
        trace: bool = False,
    ):
        """
        Abstract initialization method that all subclasses must implement.
        """
        assert exception_mapper is not None
        self.exception_mapper = exception_mapper
        super().__init__(binary=binary)
        self.trace = trace
        self._info_metadata: Optional[Dict[str, Any]] = {}

    def __init_subclass__(cls) -> None:
        """Register all subclasses of TransitionTool as possible tools."""
        TransitionTool.register_tool(cls)

    @abstractmethod
    def is_fork_supported(self, fork: Fork) -> bool:
        """Return True if the fork is supported by the tool."""
        pass

    def start_server(self) -> None:
        """
        Start the t8n-server process, extract the port, and leave it
        running for future reuse.
        """
        pass

    def shutdown(self) -> None:
        """Perform any cleanup tasks related to the tested tool."""
        pass

    def reset_traces(self) -> None:
        """Reset the internal trace storage for a new test to begin."""
        self.traces = []

    def append_traces(self, new_traces: Traces) -> None:
        """
        Append a list of traces of a state transition to the current
        list.
        """
        assert self.traces is not None
        self.traces.append(new_traces)

    def get_traces(self) -> List[Traces] | None:
        """Return the accumulated traces."""
        return self.traces

    def collect_traces(
        self,
        receipts: List[TransactionReceipt],
        temp_dir: tempfile.TemporaryDirectory,
        debug_output_path: Path | None,
    ) -> Traces:
        """
        Collect the traces from the t8n tool output and store them in the
        traces list.
        """
        traces: Traces = Traces(root=[])
        temp_dir_path = Path(temp_dir.name)
        for i, r in enumerate(receipts):
            trace_file_name = f"trace-{i}-{r.transaction_hash}.jsonl"
            trace_file_path = temp_dir_path / trace_file_name
            if not trace_file_path.exists():
                # Transaction was rejected mid-processing (e.g. EIP-3607
                # collision): the receipt exists but the tracer's
                # TransactionEnd event never fired, so no trace file was
                # written. Record an empty trace for this tx.
                traces.append(TransactionTraces(traces=[]))
                continue
            if debug_output_path:
                shutil.copy(
                    trace_file_path,
                    Path(debug_output_path) / trace_file_name,
                )
            traces.append(TransactionTraces.from_file(trace_file_path))
        self.append_traces(traces)
        return traces

    def set_cache(self, *, key: str) -> bool:
        """
        Set the current cache key.

        Creates the cache on first call, then reuses it for single-key
        eviction.
        Returns True if the key was already in the cache (hit).
        """
        if self.output_cache is None:
            self.output_cache = OutputCache()
        return self.output_cache.set_key(key)

    def remove_cache(self) -> None:
        """Clear the cache (test doesn't use caching)."""
        if self.output_cache is not None:
            self.output_cache.clear()

    def reset_opcode_count(self) -> None:
        """
        Reset the opcode count to zero.
        """
        self.opcode_count = OpcodeCount({})
        self.opcode_count_per_block = []

    @dataclass
    class TransitionToolData:
        """Transition tool files and data to pass between methods."""

        alloc: Alloc | LazyAlloc
        txs: List[Transaction]
        env: Environment
        fork: Fork
        chain_id: int
        reward: int
        blob_schedule: BlobSchedule | None
        state_test: bool = False

        @property
        def fork_name(self) -> str:
            """Return the fork name."""
            return self.fork.transition_tool_name()

        @property
        def fork_name_if_supports_blob_params(self) -> str:
            """Return the fork name."""
            fork = self.fork()

            # For tools that support blob_params, return base fork for BPO
            # forks.
            if fork.bpo_fork():
                return fork.non_bpo_ancestor().transition_tool_name()
            else:
                return self.fork.transition_tool_name()

        @property
        def blob_params(self) -> ForkBlobSchedule | None:
            """Return the blob parameters for the current fork."""
            if self.blob_schedule:
                fork_name = self.fork.name()
                # Only return blob params if this fork has them
                if fork_name in self.blob_schedule.root:
                    return self.blob_schedule[fork_name]
            return None

        def __post_init__(self) -> None:
            """Modify the reward if the environment number is 0."""
            if self.env.number == 0:
                self.reward = -1

        def to_input(self) -> TransitionToolInput:
            """Convert the data to a TransactionToolInput object."""
            return TransitionToolInput(
                alloc=self.alloc,
                txs=self.txs,
                env=self.env,
                blob_params=self.blob_params,
            )

        def get_request_data(self) -> TransitionToolRequest:
            """Convert the data to a TransitionToolRequest object."""
            return TransitionToolRequest(
                state=TransitionToolContext(
                    fork=self.fork_name,
                    chain_id=self.chain_id,
                    reward=self.reward,
                ),
                input=self.to_input(),
            )

    def _evaluate_filesystem(
        self,
        *,
        t8n_data: TransitionToolData,
        debug_output_path: Path | None,
        profiler: Profiler,
    ) -> TransitionToolOutput:
        """
        Execute a transition tool using the filesystem for its inputs and
        outputs.
        """
        temp_dir = tempfile.TemporaryDirectory()
        temp_dir_path = Path(temp_dir.name)
        os.mkdir(os.path.join(temp_dir.name, "input"))
        os.mkdir(os.path.join(temp_dir.name, "output"))

        input_paths = t8n_data.to_input().to_files(
            temp_dir_path / "input", **model_dump_config
        )

        output_paths = {
            output: os.path.join("output", f"{output}.json")
            for output in ["alloc", "result"]
        }
        output_paths["body"] = os.path.join("output", "txs.rlp")

        # Get fork name and apply any tool-specific mapping
        fork_name = (
            t8n_data.fork_name_if_supports_blob_params
            if self.supports_blob_params
            else t8n_data.fork_name
        )
        fork_name = self.fork_name_map.get(fork_name, fork_name)

        # Prepend the binary and its t8n subcommand if it uses one (e.g.
        # evmone's `t8n`), as construct_args_stream does, then the t8n flags.
        args = [str(self.binary)]
        if self.subcommand:
            args.append(self.subcommand)
        args += [
            "--state.fork",
            fork_name,
            "--input.alloc",
            input_paths["alloc"],
            "--input.env",
            input_paths["env"],
            "--input.txs",
            input_paths["txs"],
            "--output.basedir",
            temp_dir.name,
            "--output.result",
            output_paths["result"],
            "--output.alloc",
            output_paths["alloc"],
            "--output.body",
            output_paths["body"],
            "--state.reward",
            str(t8n_data.reward),
            "--state.chainid",
            str(t8n_data.chain_id),
        ]
        if self.supports_opcode_count and self.opcode_count is not None:
            args.extend(
                [
                    "--opcode.count",
                    "opcodes.json",
                ]
            )
        if self.supports_blob_params and input_paths.get("blobParams"):
            args.extend(
                [
                    "--input.blobParams",
                    input_paths["blobParams"],
                ]
            )

        if self.trace:
            args.append("--trace")

        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        if debug_output_path:
            with profiler.pause():
                if os.path.exists(debug_output_path):
                    shutil.rmtree(debug_output_path)
                shutil.copytree(temp_dir.name, debug_output_path)
                t8n_output_base_dir = os.path.join(
                    debug_output_path, "t8n.sh.out"
                )
                t8n_call = " ".join(args)
                for file_path in input_paths.values():  # update input paths
                    t8n_call = t8n_call.replace(
                        os.path.dirname(file_path),
                        os.path.join(debug_output_path, "input"),
                    )
                # use a new output path for basedir and outputs
                t8n_call = t8n_call.replace(
                    temp_dir.name,
                    t8n_output_base_dir,
                )
                t8n_script = textwrap.dedent(
                    f"""\
                    #!/bin/bash
                    # hard-coded to avoid surprises
                    rm -rf {debug_output_path}/t8n.sh.out
                    mkdir -p {debug_output_path}/t8n.sh.out/output
                    {t8n_call}
                    """
                )
                dump_files_to_directory(
                    debug_output_path,
                    {
                        "args.py": args,
                        "returncode.txt": result.returncode,
                        "stdout.txt": result.stdout.decode(),
                        "stderr.txt": result.stderr.decode(),
                        "t8n.sh+x": t8n_script,
                    },
                )

        if result.returncode != 0:
            raise Exception("failed to evaluate: " + result.stderr.decode())

        output = TransitionToolOutput.model_validate_files(
            temp_dir_path / "output",
            context={"exception_mapper": self.exception_mapper},
        )
        if self.supports_opcode_count and self.opcode_count is not None:
            opcode_count_file_path = Path(temp_dir.name) / "opcodes.json"
            if opcode_count_file_path.exists():
                opcode_count = OpcodeCount.model_validate_json(
                    opcode_count_file_path.read_text()
                )
                output.result.opcode_count = opcode_count

                if debug_output_path:
                    with profiler.pause():
                        dump_files_to_directory(
                            debug_output_path,
                            {
                                "opcodes.json": opcode_count.model_dump(),
                            },
                        )

        if self.trace:
            output.result.traces = self.collect_traces(
                output.result.receipts, temp_dir, debug_output_path
            )

        # Pin temp_dir to the output alloc so the on-disk alloc.json
        # survives until the next chained-block t8n call (or this
        # LazyAllocFile is dropped) — lets the next call read the alloc
        # via copyfile rather than re-serializing through Python.
        if isinstance(output.alloc, LazyAllocFile):
            output.alloc._keepalive = temp_dir

        return output

    def _restart_server(self) -> None:
        """Check if server is still responsive and restart if needed."""
        self.shutdown()
        time.sleep(0.1)
        self.start_server()

    def _server_post(
        self,
        data: Dict[str, Any],
        timeout: int,
        url_args: Optional[Dict[str, List[str] | str]] = None,
        retries: int = 5,
    ) -> Response:
        """Send a POST request to the t8n-server and return the response."""
        if url_args is None:
            url_args = {}
        post_delay = 0.1

        while True:
            try:
                response = Session().post(
                    f"{self.server_url}?{urlencode(url_args, doseq=True)}",
                    json=data,
                    timeout=timeout,
                )
                break
            except (RequestsConnectionError, ReadTimeout) as e:
                self._restart_server()
                retries -= 1
                if retries == 0:
                    raise e
                time.sleep(post_delay)
                post_delay *= 2
        response.raise_for_status()
        if response.status_code != 200:
            raise Exception(
                f"t8n-server returned status code {response.status_code}, "
                f"response: {response.text}"
            )
        return response

    def _generate_post_args(
        self, t8n_data: TransitionToolData
    ) -> Dict[str, List[str] | str]:
        """Generate the arguments for the POST request to the t8n-server."""
        del t8n_data
        return {}

    def _evaluate_server(
        self,
        *,
        t8n_data: TransitionToolData,
        debug_output_path: Path | None,
        timeout: int,
        profiler: Profiler,
    ) -> TransitionToolOutput:
        """
        Execute the transition tool sending inputs and outputs via a server.
        """
        request_data = t8n_data.get_request_data()
        request_data_json = request_data.model_dump(
            mode="json", **model_dump_config
        )

        temp_dir = tempfile.TemporaryDirectory()
        request_data_json["trace"] = self.trace
        if self.trace:
            request_data_json["output-basedir"] = temp_dir.name

        if debug_output_path:
            with profiler.pause():
                request_data_str = json.dumps(request_data_json, indent=2)
                request_info = (
                    f"Server URL: {self.server_url}\n\n"
                    f"Request Data:\n{request_data_str}\n"
                )
                dump_files_to_directory(
                    debug_output_path,
                    {
                        "input/alloc.json": request_data.input.alloc.raw
                        if isinstance(request_data.input.alloc, LazyAlloc)
                        else request_data.input.alloc.model_dump(
                            mode="json", **model_dump_config
                        ),
                        "input/env.json": request_data.input.env,
                        "input/txs.json": [
                            tx.model_dump(mode="json", **model_dump_config)
                            for tx in request_data.input.txs
                        ],
                        "input/blob_params.json": (
                            request_data.input.blob_params
                        ),
                        "request_info.txt": request_info,
                    },
                )

        response = self._server_post(
            data=request_data_json,
            url_args=self._generate_post_args(t8n_data),
            timeout=timeout,
        )
        response_json = response.json()

        # pop optional test ``_info`` metadata from response, if present
        self._info_metadata = response_json.pop("_info_metadata", {})

        output: TransitionToolOutput = TransitionToolOutput.model_validate(
            response_json, context={"exception_mapper": self.exception_mapper}
        )

        if self.trace:
            output.result.traces = self.collect_traces(
                output.result.receipts, temp_dir, debug_output_path
            )
        temp_dir.cleanup()

        if debug_output_path:
            with profiler.pause():
                headers_str = json.dumps(dict(response.headers), indent=2)
                response_info = (
                    f"Status Code: {response.status_code}\n\n"
                    f"Headers:\n{headers_str}\n\n"
                    f"Content:\n{response.text}\n"
                )
                dump_files_to_directory(
                    debug_output_path,
                    {
                        "output/alloc.json": output.alloc,
                        "output/result.json": output.result,
                        "output/txs.rlp": str(output.body),
                        "response_info.txt": response_info,
                    },
                )

        return output

    def _evaluate_stream(
        self,
        *,
        t8n_data: TransitionToolData,
        debug_output_path: Path | None,
        profiler: Profiler,
    ) -> TransitionToolOutput:
        """
        Execute a transition tool using stdin for inputs and files for
        outputs.

        The t8n writes `alloc.json`/`result.json`/`txs.rlp` into an
        `output/` subdirectory of a temp dir; Python then parses `result.json`
        eagerly and references `alloc.json` via `LazyAllocFile`, which
        streams the file on demand. Avoids holding the full alloc JSON
        (multi-GB for large benchmarks) in the stdout buffer alongside the
        validated `Alloc` object graph.
        """
        temp_dir = tempfile.TemporaryDirectory()
        output_dir = Path(temp_dir.name) / "output"
        output_dir.mkdir()

        # Chained-block handoff: when the input alloc is a `LazyAllocFile`
        # whose backing file is still on disk (pinned via the producing
        # call's keepalive), point the t8n at it directly via
        # `--input.alloc=<path>` and omit alloc from the stdin bundle, so
        # Python never builds a multi-GB JSON string for the next call.
        alloc_path: Path | None = None
        if (
            isinstance(t8n_data.alloc, LazyAllocFile)
            and Path(t8n_data.alloc.raw).exists()
        ):
            alloc_path = Path(t8n_data.alloc.raw)

        args = self.construct_args_stream(
            t8n_data, temp_dir, alloc_path=alloc_path
        )

        stdin = t8n_data.to_input()

        process_input = stdin.model_dump_json(
            exclude_alloc=alloc_path is not None, **model_dump_config
        )
        encoded_process_input = process_input.encode()

        result = subprocess.run(
            args,
            input=encoded_process_input,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        if debug_output_path:
            with profiler.pause():
                self.dump_debug_stream(
                    debug_output_path, temp_dir, stdin, args, result
                )

        if result.returncode != 0:
            raise Exception("failed to evaluate: " + result.stderr.decode())

        output: TransitionToolOutput = (
            TransitionToolOutput.model_validate_files(
                output_dir,
                context={"exception_mapper": self.exception_mapper},
            )
        )

        if debug_output_path:
            with profiler.pause():
                debug_output_dir = Path(debug_output_path) / "output"
                debug_output_dir.mkdir(parents=True, exist_ok=True)
                for name in ("alloc.json", "result.json", "txs.rlp"):
                    src = output_dir / name
                    if src.exists():
                        shutil.copyfile(src, debug_output_dir / name)

        if self.supports_opcode_count:
            opcode_count_file_path = Path(temp_dir.name) / "opcodes.json"
            if opcode_count_file_path.exists():
                opcode_count = OpcodeCount.model_validate_json(
                    opcode_count_file_path.read_text()
                )
                output.result.opcode_count = opcode_count

                if debug_output_path:
                    with profiler.pause():
                        dump_files_to_directory(
                            debug_output_path,
                            {
                                "opcodes.json": opcode_count.model_dump(),
                            },
                        )

        if self.trace:
            output.result.traces = self.collect_traces(
                output.result.receipts, temp_dir, debug_output_path
            )

        # Pin temp_dir to the output alloc so the on-disk alloc.json
        # survives until the next chained-block t8n call (or this
        # LazyAllocFile is dropped) — lets the next call read the alloc
        # via copyfile / `--input.alloc=<path>` rather than re-serializing
        # through Python.
        if isinstance(output.alloc, LazyAllocFile):
            output.alloc._keepalive = temp_dir

        return output

    def safe_t8n_args(
        self,
        fork_name: str,
        chain_id: int,
        reward: int,
        temp_dir: tempfile.TemporaryDirectory,
        *,
        alloc_path: Optional[Path] = None,
    ) -> List[str]:
        """
        Safely construct t8n arguments with validated inputs.

        When ``alloc_path`` is provided (chained-block handoff), the alloc is
        read from that file rather than from the stdin bundle.
        """
        # Validate fork name against actual transition tool names from all
        # available forks
        valid_forks = get_valid_transition_tool_names()
        if fork_name not in valid_forks:
            raise ValueError(f"Invalid fork name: {fork_name}")

        # Validate chain ID (should be positive integer)
        if not isinstance(chain_id, int) or chain_id <= 0:
            raise ValueError(f"Invalid chain ID: {chain_id}")

        # Validate reward (should be non-negative integer)
        if not isinstance(reward, int) or reward < 0:
            raise ValueError(f"Invalid reward: {reward}")

        if temp_dir is None:
            raise ValueError(
                "safe_t8n_args requires a temp_dir for file-based outputs"
            )

        # env/txs still come through stdin; alloc is either bundled on stdin
        # (initial block) or streamed from a path (chained-block handoff).
        # Outputs always go to files in the existing temp dir so Python can
        # stream-read the post-state alloc rather than buffering stdout.
        input_alloc = (
            f"--input.alloc={alloc_path}"
            if alloc_path is not None
            else "--input.alloc=stdin"
        )
        input_txs: LiteralString = "--input.txs=stdin"
        input_env: LiteralString = "--input.env=stdin"
        output_result: LiteralString = "--output.result=output/result.json"
        output_alloc: LiteralString = "--output.alloc=output/alloc.json"
        output_body: LiteralString = "--output.body=output/txs.rlp"
        trace_flag: LiteralString = "--trace"

        args = [
            input_alloc,
            input_txs,
            input_env,
            output_result,
            output_alloc,
            output_body,
            f"--state.fork={fork_name}",
            f"--state.chainid={chain_id}",
            f"--state.reward={reward}",
            f"--output.basedir={temp_dir.name}",
        ]

        if self.trace:
            args.append(trace_flag)
        if self.supports_opcode_count:
            args.extend(["--opcode.count", "opcodes.json"])

        return args

    def construct_args_stream(
        self,
        t8n_data: TransitionToolData,
        temp_dir: tempfile.TemporaryDirectory,
        *,
        alloc_path: Optional[Path] = None,
    ) -> List[str]:
        """Construct arguments for t8n interaction via streams."""
        command: list[str] = [str(self.binary)]
        if self.subcommand:
            command.append(self.subcommand)

        safe_args = self.safe_t8n_args(
            t8n_data.fork_name,
            t8n_data.chain_id,
            t8n_data.reward,
            temp_dir,
            alloc_path=alloc_path,
        )
        return command + safe_args

    def dump_debug_stream(
        self,
        debug_output_path: Path,
        temp_dir: tempfile.TemporaryDirectory,
        stdin: TransitionToolInput,
        args: List[str],
        result: subprocess.CompletedProcess,
    ) -> None:
        """
        Export debug files if requested when interacting with t8n via streams.
        """
        t8n_call = " ".join(args)
        t8n_output_base_dir = os.path.join(debug_output_path, "t8n.sh.out")
        t8n_call = t8n_call.replace(temp_dir.name, t8n_output_base_dir)
        t8n_script = textwrap.dedent(
            f"""\
            #!/bin/bash
            # hard-coded to avoid surprises
            rm -rf {debug_output_path}/t8n.sh.out

            mkdir -p {debug_output_path}/t8n.sh.out/output
            {t8n_call} < {debug_output_path}/stdin.txt
            """
        )
        dump_files_to_directory(
            debug_output_path,
            {
                "args.py": args,
                "input/alloc.json": stdin.alloc,
                "input/env.json": stdin.env,
                "input/txs.json": [
                    tx.model_dump(mode="json", **model_dump_config)
                    for tx in stdin.txs
                ],
                "returncode.txt": result.returncode,
                "stdin.txt": stdin,
                "stdout.txt": result.stdout.decode(),
                "stderr.txt": result.stderr.decode(),
                "t8n.sh+x": t8n_script,
            },
        )

    def _evaluate(
        self,
        *,
        transition_tool_data: TransitionToolData,
        debug_output_path: Path | None,
        slow_request: bool,
        profiler: Profiler,
    ) -> TransitionToolOutput:
        """
        Execute the relevant evaluate method as required by the `t8n` tool.

        If a client's `t8n` tool varies from the default behavior, this method
        can be overridden.
        """
        if self.t8n_use_server:
            if not self.server_url:
                self.start_server()
            return self._evaluate_server(
                t8n_data=transition_tool_data,
                debug_output_path=debug_output_path,
                timeout=SLOW_REQUEST_TIMEOUT
                if slow_request
                else NORMAL_SERVER_TIMEOUT,
                profiler=profiler,
            )

        elif self.t8n_use_stream:
            return self._evaluate_stream(
                t8n_data=transition_tool_data,
                debug_output_path=debug_output_path,
                profiler=profiler,
            )
        else:
            return self._evaluate_filesystem(
                t8n_data=transition_tool_data,
                debug_output_path=debug_output_path,
                profiler=profiler,
            )

    def get_next_transition_tool_output_path(
        self, call_id: int
    ) -> Path | None:
        """Return path to the next transition tool output file."""
        debug_dump_dir = self.debug_dump_dir
        if debug_dump_dir is None:
            return None
        return debug_dump_dir / str(call_id)

    def increment_call_counter(self) -> int:
        """Increment the call counter by one and return the previous value."""
        previous_value = self.call_counter
        self.call_counter += 1
        return previous_value

    def process_result(
        self, result: TransitionToolOutput
    ) -> TransitionToolOutput:
        """
        Process the result of the transition tool evaluation performing the
        following operations:
        - Add opcode count to the result if available.
        """
        if (
            result.result.opcode_count is not None
            and self.opcode_count is not None
        ):
            self.opcode_count += result.result.opcode_count
            if self.opcode_count_per_block is not None:
                self.opcode_count_per_block.append(result.result.opcode_count)
        return result

    def evaluate(
        self,
        *,
        transition_tool_data: TransitionToolData,
        slow_request: bool = False,
    ) -> TransitionToolOutput:
        """
        Execute the relevant evaluate method as required by the `t8n` tool.

        If a client's `t8n` tool varies from the default behavior, this method
        can be overridden.
        """
        current_call_id = self.increment_call_counter()
        if self.output_cache is not None:
            cached_result = self.output_cache.get(current_call_id)
            if cached_result is not None:
                if self.trace and cached_result.result.traces is not None:
                    self.append_traces(cached_result.result.traces)
                return self.process_result(cached_result)
        debug_output_path = self.get_next_transition_tool_output_path(
            current_call_id
        )
        with Profiler(
            enabled=debug_output_path is not None,
            filename=debug_output_path / "profile.out"
            if debug_output_path
            else None,
        ) as profiler:
            result = self._evaluate(
                transition_tool_data=transition_tool_data,
                debug_output_path=debug_output_path,
                slow_request=slow_request,
                profiler=profiler,
            )
        if self.output_cache is not None:
            self.output_cache.set(current_call_id, result)
        return self.process_result(result)
