"""
Test the correct error is produced with bad/invalid validity markers.
"""

import pytest

invalid_merge_marker = "Marge"  # codespell:ignore marge

invalid_validity_marker_test_cases = (
    (
        "too_many_valid_until_markers",
        (
            """
            import pytest
            @pytest.mark.valid_until("Paris")
            @pytest.mark.valid_until("Paris")
            def test_case(state_test):
                assert 0
            """,
            "Too many 'valid_until' markers applied to test",
        ),
    ),
    (
        "too_many_valid_at_transition_to_markers",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to("Paris")
            @pytest.mark.valid_at_transition_to("Paris")
            def test_case(state_test):
                assert 0
            """,
            "Too many 'valid_at_transition_to' markers applied to test",
        ),
    ),
    (
        "valid_from_no_args",
        (
            """
            import pytest
            @pytest.mark.valid_from()
            def test_case(state_test):
                assert 0
            """,
            "Missing fork argument with 'valid_from' marker",
        ),
    ),
    (
        "valid_until_no_args",
        (
            """
            import pytest
            @pytest.mark.valid_until()
            def test_case(state_test):
                assert 0
            """,
            "Missing fork argument with 'valid_until' marker",
        ),
    ),
    (
        "valid_at_transition_to_no_args",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to()
            def test_case(state_test):
                assert 0
            """,
            "Missing fork argument with 'valid_at_transition_to' marker",
        ),
    ),
    (
        "valid_from_duplicate_arg",
        (
            """
            import pytest
            @pytest.mark.valid_from("Paris", "Paris")
            def test_case(state_test):
                assert 0
            """,
            "Duplicate argument specified in 'valid_from'",
        ),
    ),
    (
        "valid_until_duplicate_arg",
        (
            """
            import pytest
            @pytest.mark.valid_until("Paris", "Paris")
            def test_case(state_test):
                assert 0
            """,
            "Duplicate argument specified in 'valid_until'",
        ),
    ),
    (
        "valid_at_transition_duplicate_arg",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to("Paris", "Paris")
            def test_case(state_test):
                assert 0
            """,
            "Duplicate argument specified in 'valid_at_transition_to'",
        ),
    ),
    (
        "valid_from_nonexistent_fork",
        (
            f"""
            import pytest
            @pytest.mark.valid_from("{invalid_merge_marker}")
            def test_case(state_test):
                assert 0
            """,
            f"Invalid fork '{invalid_merge_marker}'",
        ),
    ),
    (
        "valid_until_nonexistent_fork",
        (
            """
            import pytest
            @pytest.mark.valid_until("Shangbye")
            def test_case(state_test):
                assert 0
            """,
            "Invalid fork 'Shangbye'",
        ),
    ),
    (
        "valid_at_transition_to_nonexistent_fork",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to("Cantcun")
            def test_case(state_test):
                assert 0
            """,
            "Invalid fork 'Cantcun'",
        ),
    ),
    (
        "valid_at_transition_to_until_nonexistent_fork",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to("Shanghai", until="Cantcun")
            def test_case(state_test):
                assert 0
            """,
            "Invalid fork 'Cantcun'",
        ),
    ),
    (
        "valid_at_transition_to_and_valid_from",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to("Cancun")
            @pytest.mark.valid_from("Paris")
            def test_case(state_test):
                assert 0
            """,
            (
                "The markers 'valid_from' and 'valid_at_transition_to' "
                "can't be combined"
            ),
        ),
    ),
    (
        "valid_at_transition_to_and_valid_until",
        (
            """
            import pytest
            @pytest.mark.valid_at_transition_to("Shanghai")
            @pytest.mark.valid_until("Cancun")
            def test_case(state_test):
                assert 0
            """,
            (
                "The markers 'valid_until' and 'valid_at_transition_to' "
                "can't be combined"
            ),
        ),
    ),
    (
        "invalid_validity_range",
        (
            """
            import pytest
            @pytest.mark.valid_from("Paris")
            @pytest.mark.valid_until("Frontier")
            def test_case(state_test):
                assert 0
            """,
            "fork validity markers generate an empty fork range",
        ),
    ),
)


@pytest.mark.parametrize(
    "test_function, error_string",
    [test_case for _, test_case in invalid_validity_marker_test_cases],
    ids=[test_id for test_id, _ in invalid_validity_marker_test_cases],
)
def test_invalid_validity_markers(
    pytester: pytest.Pytester, error_string: str, test_function: str
) -> None:
    """
    Test that a test with invalid marker combinations:
    - Creates an outcome with exactly one error.
    - Triggers the expected error string in pytest's console output.

    Each invalid marker/marker combination is tested with one test in its own
    test session.
    """
    pytester.makepyfile(test_function)
    pytester.copy_example(
        name="src/execution_testing/cli/pytest_commands/pytest_ini_files/pytest-fill.ini"
    )
    result = pytester.runpytest("-c", "pytest-fill.ini")
    result.assert_outcomes(
        passed=0,
        failed=0,
        skipped=0,
        errors=1,
    )
    assert error_string in "\n".join(result.stdout.lines)


# --- Tests for param-level marker errors --- #


param_level_marker_error_test_cases = (
    (
        "param_level_valid_until_with_function_level_valid_until",
        (
            """
            import pytest
            @pytest.mark.parametrize(
                "value",
                [
                    pytest.param(True, marks=pytest.mark.valid_until("Cancun")),
                ],
            )
            @pytest.mark.valid_until("Prague")
            def test_case(state_test, value):
                assert 1
            """,  # noqa: E501
            "Too many 'valid_until' markers applied to test",
        ),
    ),
)


@pytest.mark.parametrize(
    "test_function, error_string",
    [test_case for _, test_case in param_level_marker_error_test_cases],
    ids=[test_id for test_id, _ in param_level_marker_error_test_cases],
)
def test_param_level_marker_errors(
    pytester: pytest.Pytester, error_string: str, test_function: str
) -> None:
    """
    Test that combining function-level and param-level validity markers
    of the same type produces an error.

    Unlike function-level errors (caught during test generation), param-level
    errors are caught during collection and cause pytest to exit immediately.
    """
    pytester.makepyfile(test_function)
    pytester.copy_example(
        name="src/execution_testing/cli/pytest_commands/pytest_ini_files/pytest-fill.ini"
    )
    result = pytester.runpytest("-c", "pytest-fill.ini")

    # pytest.exit() causes the run to terminate with no test outcomes
    assert result.ret != 0, "Expected non-zero exit code"
    stdout = "\n".join(result.stdout.lines)
    assert error_string in stdout, f"Expected '{error_string}' in output"
