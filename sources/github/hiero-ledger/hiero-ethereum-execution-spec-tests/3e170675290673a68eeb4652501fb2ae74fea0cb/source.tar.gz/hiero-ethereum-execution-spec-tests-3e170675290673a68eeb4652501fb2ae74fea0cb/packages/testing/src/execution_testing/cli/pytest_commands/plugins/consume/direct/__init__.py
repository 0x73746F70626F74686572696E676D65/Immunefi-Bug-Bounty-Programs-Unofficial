"""Consume direct test functions."""
