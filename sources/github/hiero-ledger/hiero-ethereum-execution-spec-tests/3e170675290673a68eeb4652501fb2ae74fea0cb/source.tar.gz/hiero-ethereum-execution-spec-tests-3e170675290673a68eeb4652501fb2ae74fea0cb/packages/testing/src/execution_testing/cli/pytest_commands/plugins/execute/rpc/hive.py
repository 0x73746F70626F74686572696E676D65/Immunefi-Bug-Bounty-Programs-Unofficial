"""Pytest plugin to run the test-execute in hive-mode."""

import io
import json
from dataclasses import asdict, replace
from pathlib import Path
from random import randint
from typing import Generator, Mapping, Tuple, cast

import pytest
from filelock import FileLock
from hive.client import Client, ClientType
from hive.simulation import Simulation
from hive.testing import HiveTest, HiveTestResult, HiveTestSuite

from execution_testing.base_types import (
    Account,
    EmptyOmmersRoot,
    EmptyTrieRoot,
    Hash,
    to_json,
)
from execution_testing.fixtures.blockchain import FixtureHeader
from execution_testing.forks import Fork, Requests, TransitionFork
from execution_testing.rpc import EngineRPC, EthRPC
from execution_testing.test_types import (
    DETERMINISTIC_FACTORY_ADDRESS,
    DETERMINISTIC_FACTORY_BYTECODE,
    EOA,
    Alloc,
    BlockAccessList,
    ChainConfig,
    Environment,
    Withdrawal,
)

from ...consume.simulators.helpers.ruleset import ruleset
from .chain_builder_eth_rpc import ChainBuilderEthRPC, TestingRPC


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add command-line options to pytest."""
    hive_rpc_group = parser.getgroup(
        "hive_rpc",
        "Arguments defining the hive RPC client properties for the test.",
    )
    hive_rpc_group.addoption(
        "--seed-key-initial-balance",
        action="store",
        dest="seed_key_initial_balance",
        type=int,
        default=10**26,
        help=(
            "Initial balance of the seed key. This balance will be "
            "distributed equally between each pytest worker (`-n` option)."
        ),
    )
    hive_rpc_group.addoption(
        "--tx-wait-timeout",
        action="store",
        dest="tx_wait_timeout",
        type=int,
        # Lowered from Remote RPC because of consistent block production
        default=10,
        help=(
            "Maximum time in seconds to wait for a transaction to be "
            "included in a block"
        ),
    )


@pytest.hookimpl(trylast=True)
def pytest_configure(config: pytest.Config) -> None:  # noqa: D103
    config.test_suite_scope = "session"  # type: ignore
    config.engine_rpc_supported = True  # type: ignore


@pytest.fixture(scope="session")
def seed_key(session_temp_folder: Path) -> EOA:
    """
    Determine the seed account, which is used to fund all worker accounts,
    and place it in the client's genesis.
    """
    base_name = "seed_key"
    base_file = session_temp_folder / base_name
    base_lock_file = session_temp_folder / f"{base_name}.lock"

    with FileLock(base_lock_file):
        if base_file.exists():
            with base_file.open("r") as f:
                seed_sender_key = Hash(f.read())
            seed_key = EOA(key=seed_sender_key)
        else:
            seed_key = EOA(key=randint(0, 2**256))
            with base_file.open("w") as f:
                f.write(str(seed_key.key))
    return seed_key


@pytest.fixture(scope="session")
def base_pre(
    request: pytest.FixtureRequest,
    seed_key: EOA,
) -> Alloc:
    """Pre-allocation for the client's genesis."""
    seed_key_initial_balance = request.config.getoption(
        "seed_key_initial_balance"
    )
    return Alloc(
        {
            seed_key: Account(balance=seed_key_initial_balance),
            # Pre-deploy the deterministic factory to avoid needing unprotected
            # transactions (geth rejects unprotected txs by default)
            DETERMINISTIC_FACTORY_ADDRESS: Account(
                nonce=1, code=DETERMINISTIC_FACTORY_BYTECODE
            ),
        }
    )


def build_genesis_header(
    session_fork: Fork | TransitionFork,
    base_pre: Alloc | None = None,
) -> Tuple[Alloc, FixtureHeader]:
    """
    Build a hive genesis ``(pre_alloc, FixtureHeader)`` for ``session_fork``.

    ``base_pre`` is merged on top of the fork's required system contracts;
    callers that fund accounts post-genesis (e.g. fill-stateful via CL
    withdrawals) can pass ``None`` for an empty extra allocation.
    """
    block_number = 0
    timestamp = 1
    genesis_fork = session_fork.fork_at(
        block_number=block_number, timestamp=timestamp
    )
    env = Environment().set_fork_requirements(genesis_fork)
    assert env.withdrawals is None or len(env.withdrawals) == 0, (
        "withdrawals must be empty at genesis"
    )
    assert (
        env.parent_beacon_block_root is None
        or env.parent_beacon_block_root == Hash(0)
    ), "parent_beacon_block_root must be empty at genesis"

    pre_alloc = Alloc.model_validate(
        session_fork.transitions_to().pre_allocation_blockchain()
    )
    if base_pre is not None:
        pre_alloc = Alloc.merge(pre_alloc, base_pre)
    if empty_accounts := pre_alloc.empty_accounts():
        raise Exception(f"Empty accounts in pre state: {empty_accounts}")
    pre_alloc.migrate_state_commitment(
        session_fork.transitions_from().state_commitment()
    )
    state_root = pre_alloc.state_root()
    genesis = FixtureHeader(
        parent_hash=0,
        ommers_hash=EmptyOmmersRoot,
        fee_recipient=0,
        state_root=state_root,
        transactions_trie=EmptyTrieRoot,
        receipts_root=EmptyTrieRoot,
        logs_bloom=0,
        difficulty=0x20000 if env.difficulty is None else env.difficulty,
        number=block_number,
        gas_limit=env.gas_limit,
        gas_used=0,
        timestamp=timestamp,
        extra_data=b"\x00",
        prev_randao=0,
        nonce=0,
        base_fee_per_gas=env.base_fee_per_gas,
        blob_gas_used=env.blob_gas_used,
        excess_blob_gas=env.excess_blob_gas,
        withdrawals_root=(
            Withdrawal.list_root(env.withdrawals)
            if env.withdrawals is not None
            else None
        ),
        parent_beacon_block_root=env.parent_beacon_block_root,
        requests_hash=Requests()
        if genesis_fork.header_requests_required()
        else None,
        block_access_list_hash=BlockAccessList().rlp_hash
        if genesis_fork.header_bal_hash_required()
        else None,
        slot_number=0 if genesis_fork.header_slot_number_required() else None,
    )

    return (pre_alloc, genesis)


def build_client_genesis_dict(
    pre_alloc: Alloc,
    genesis_header: FixtureHeader,
) -> dict:
    """
    Convert ``(pre_alloc, FixtureHeader)`` into the JSON-compatible dict
    that hive writes to ``/genesis.json``.
    """
    # NOTE: to_json() excludes None values.
    genesis = to_json(genesis_header)
    alloc = to_json(pre_alloc)
    # NOTE: nethermind requires account keys without '0x' prefix.
    genesis["alloc"] = {k.replace("0x", ""): v for k, v in alloc.items()}
    return genesis


def build_client_files(
    client_genesis_dict: dict,
) -> Mapping[str, io.BufferedReader]:
    """Wrap ``client_genesis_dict`` in the BufferedReader hive expects."""
    genesis_bytes = json.dumps(client_genesis_dict).encode("utf-8")
    buffered: io.BufferedReader = io.BufferedReader(
        cast(io.RawIOBase, io.BytesIO(genesis_bytes))
    )
    files: dict = {"/genesis.json": buffered}
    return files


def build_hive_environment(
    session_fork: Fork | TransitionFork,
    chain_id: int,
) -> dict:
    """Build the hive client environment from the fork's ruleset."""
    assert session_fork in ruleset, (
        f"fork '{session_fork}' missing in hive ruleset"
    )
    return {
        "HIVE_CHAIN_ID": str(chain_id),
        "HIVE_FORK_DAO_VOTE": "1",
        "HIVE_NODETYPE": "full",
        **{k: f"{v:d}" for k, v in ruleset[session_fork].items()},
    }


@pytest.fixture(scope="session")
def base_pre_genesis(
    session_fork: Fork | TransitionFork,
    base_pre: Alloc,
) -> Tuple[Alloc, FixtureHeader]:
    """Create a genesis block from the blockchain test definition."""
    return build_genesis_header(session_fork, base_pre)


@pytest.fixture(scope="session")
def client_genesis(base_pre_genesis: Tuple[Alloc, FixtureHeader]) -> dict:
    """
    Convert the fixture's genesis block header and pre-state to a client
    genesis state.
    """
    return build_client_genesis_dict(*base_pre_genesis)


@pytest.fixture(scope="session")
def client_files(
    client_genesis: dict,
) -> Mapping[str, io.BufferedReader]:
    """
    Define the files that hive will start the client with.

    For this type of test, only the genesis is passed
    """
    return build_client_files(client_genesis)


@pytest.fixture(scope="session")
def environment(session_fork: Fork, chain_config: ChainConfig) -> dict:
    """
    Define the environment that hive will start the client with using the fork
    rules specific for the simulator.
    """
    return build_hive_environment(session_fork, chain_config.chain_id)


@pytest.fixture(scope="session")
def test_suite_name() -> str:
    """The name of the hive test suite used in this simulator."""
    return "eels/execute, hive mode"


@pytest.fixture(scope="session")
def test_suite_description() -> str:
    """The description of the hive test suite used in this simulator."""
    return "Execute EEST tests using hive endpoint."


@pytest.fixture(scope="function")
def test_case_description(request: pytest.FixtureRequest) -> str:
    """Return the test docstring as the hive test-case description."""
    description = getattr(request.node.function, "__doc__", None)
    return description or ""


@pytest.fixture(autouse=True)
def per_test_hive_test(client: Client, hive_test: HiveTest) -> None:
    """
    Report each pytest test as an individual hive test case.

    The client runs under the session-scoped base hive test; register
    it with each per-test entry so hive attaches the client and its
    log segment to the individual test case and marks the base test
    as the multi-test lifecycle owner.
    """
    hive_test.register_multi_test_client(client)


@pytest.fixture(autouse=True, scope="session")
def base_hive_test(
    test_suite: HiveTestSuite,
    session_temp_folder: Path,
) -> Generator[HiveTest, None, None]:
    """
    Test (base) used to deploy the main client to be used throughout all tests.
    """
    base_name = "base_hive_test"
    base_file = session_temp_folder / base_name
    base_lock_file = session_temp_folder / f"{base_name}.lock"
    with FileLock(base_lock_file):
        if base_file.exists():
            with open(base_file, "r") as f:
                test = HiveTest(**json.load(f))
        else:
            test = test_suite.start_test(
                name="Base Hive Test",
                description=(
                    "Base test used to deploy the main client to be used "
                    "throughout all tests."
                ),
            )
            with open(base_file, "w") as f:
                json.dump(asdict(test), f)

    users_file_name = f"{base_name}_users"
    users_file = session_temp_folder / users_file_name
    users_lock_file = session_temp_folder / f"{users_file_name}.lock"
    with FileLock(users_lock_file):
        if users_file.exists():
            with open(users_file, "r") as f:
                users = json.load(f)
        else:
            users = 0
        users += 1
        with open(users_file, "w") as f:
            json.dump(users, f)

    yield test

    # Individual results are reported by the per-test hive test cases,
    # and hive marks this test as the multi-test lifecycle owner, so it
    # always passes unless the client failed to start (the client
    # fixture leaves its error file behind on startup failure).
    client_error_file = session_temp_folder / "hive_client.err"
    if client_error_file.exists():
        test_pass = False
        test_details = "Failed to start the client."
    else:
        test_pass = True
        test_details = "Multi-test client context completed."

    with FileLock(users_lock_file):
        with open(users_file, "r") as f:
            users = json.load(f)
        users -= 1
        with open(users_file, "w") as f:
            json.dump(users, f)
        if users == 0:
            test.end(
                result=HiveTestResult(
                    test_pass=test_pass, details=test_details
                )
            )
            base_file.unlink()
            users_file.unlink()


@pytest.fixture(scope="session")
def client_type(simulator: Simulation) -> ClientType:
    """Type of client to be used in the test."""
    return simulator.client_types()[0]


@pytest.fixture(autouse=True, scope="session")
def client(
    base_hive_test: HiveTest,
    client_files: dict,
    environment: dict,
    client_type: ClientType,
    session_temp_folder: Path,
) -> Generator[Client, None, None]:
    """
    Initialize the client with the appropriate files and environment variables.
    """
    base_name = "hive_client"
    base_file = session_temp_folder / base_name
    base_error_file = session_temp_folder / f"{base_name}.err"
    base_lock_file = session_temp_folder / f"{base_name}.lock"
    client: Client | None = None
    with FileLock(base_lock_file):
        if not base_error_file.exists():
            if base_file.exists():
                with open(base_file, "r") as f:
                    client = Client(**json.load(f))
            else:
                base_error_file.touch()  # Assume error
                client = base_hive_test.start_client(
                    client_type=client_type,
                    environment=environment,
                    files=client_files,
                )
                if client is not None:
                    base_error_file.unlink()  # Success
                    with open(base_file, "w") as f:
                        json.dump(
                            asdict(replace(client, config=None)),  # type: ignore
                            f,
                        )

    error_message = (
        f"Unable to connect to the client container ({client_type.name}) "
        "via Hive during test setup. Check the client or Hive server logs "
        "for more information."
    )
    assert client is not None, error_message

    users_file_name = f"{base_name}_users"
    users_file = session_temp_folder / users_file_name
    users_lock_file = session_temp_folder / f"{users_file_name}.lock"
    with FileLock(users_lock_file):
        if users_file.exists():
            with open(users_file, "r") as f:
                users = json.load(f)
        else:
            users = 0
        users += 1
        with open(users_file, "w") as f:
            json.dump(users, f)

    # Set on every worker (the client object is shared across xdist
    # workers via JSON serialization) so that per-test hive test cases
    # can register with the client.
    client.multi_test = True

    yield client

    with FileLock(users_lock_file):
        with open(users_file, "r") as f:
            users = json.load(f)
        users -= 1
        with open(users_file, "w") as f:
            json.dump(users, f)
        if users == 0:
            client.stop()
            base_file.unlink()
            users_file.unlink()


@pytest.fixture(scope="session")
def engine_rpc(client: Client) -> EngineRPC | None:
    """Return the engine RPC client."""
    return EngineRPC(f"http://{client.ip}:8551")


@pytest.fixture(autouse=True, scope="session")
def eth_rpc(
    request: pytest.FixtureRequest,
    client: Client,
    engine_rpc: EngineRPC,
    session_fork: Fork | TransitionFork,
    session_temp_folder: Path,
    max_batch_size: int | None,
    use_testing_build_block: bool,
    base_pre_genesis: Tuple[Alloc, FixtureHeader],
) -> EthRPC:
    """Initialize ethereum RPC client for the execution client under test."""
    get_payload_wait_time = request.config.getoption("get_payload_wait_time")
    tx_wait_timeout = request.config.getoption("tx_wait_timeout")
    testing_rpc = None
    if use_testing_build_block:
        testing_rpc = TestingRPC(f"http://{client.ip}:8545")
    return ChainBuilderEthRPC(
        rpc_endpoint=f"http://{client.ip}:8545",
        fork=session_fork,
        engine_rpc=engine_rpc,
        session_temp_folder=session_temp_folder,
        get_payload_wait_time=get_payload_wait_time,
        transaction_wait_timeout=tx_wait_timeout,
        max_batch_size=max_batch_size,
        testing_rpc=testing_rpc,
        expected_genesis_header=base_pre_genesis[1],
    )
