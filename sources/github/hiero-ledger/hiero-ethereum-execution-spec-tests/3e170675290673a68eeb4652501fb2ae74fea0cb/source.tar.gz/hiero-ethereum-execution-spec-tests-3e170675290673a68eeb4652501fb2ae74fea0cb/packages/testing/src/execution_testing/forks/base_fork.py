"""Abstract base class for Ethereum forks."""

import re
from abc import ABCMeta, abstractmethod
from enum import Enum, auto
from functools import lru_cache
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    ClassVar,
    Dict,
    List,
    Mapping,
    Optional,
    Protocol,
    Sequence,
    Set,
    Sized,
    Tuple,
    Type,
    cast,
)

if TYPE_CHECKING:
    from execution_testing.fixtures.blockchain import FixtureHeader

from execution_testing.base_types import (
    AccessList,
    Address,
    BlobSchedule,
    StateCommitment,
)
from execution_testing.base_types.conversions import BytesConvertible
from execution_testing.vm import (
    ForkOpcodeInterface,
    OpcodeBase,
    Opcodes,
)

from ..recipient_type import RecipientType
from .gas_costs import GasCosts
from .requests import SystemContractRequest


class MemoryExpansionGasCalculator(Protocol):
    """
    A protocol to calculate the gas cost of memory expansion at a given fork.
    """

    def __call__(self, *, new_bytes: int, previous_bytes: int = 0) -> int:
        """Return gas cost of expanding the memory by the given length."""
        pass


class CalldataGasCalculator(Protocol):
    """
    A protocol to calculate the transaction gas cost of calldata at a given
    fork.
    """

    def __call__(self, *, data: BytesConvertible, floor: bool = False) -> int:
        """Return the transaction gas cost of calldata given its contents."""
        pass


class TransactionDataFloorCostCalculator(Protocol):
    """
    Calculate the transaction floor cost due to its calldata for a given fork.
    """

    def __call__(
        self,
        *,
        data: BytesConvertible,
        access_list: List[AccessList] | None = None,
        contract_creation: bool = False,
        sends_value: bool = False,
        recipient_type: RecipientType = RecipientType.CONTRACT,
    ) -> int:
        """
        Return transaction gas cost of calldata given its contents.

        The defaults model a zero-value call to another account. Forks
        that anchor the floor on the transaction's intrinsic base
        (EIP-2780) add gas for these arguments, so create, value-bearing,
        and self-transfer transactions must pass them explicitly.
        """
        pass


class BaseFeePerGasCalculator(Protocol):
    """A protocol to calculate the base fee per gas at a given fork."""

    def __call__(
        self,
        *,
        parent_base_fee_per_gas: int,
        parent_gas_used: int,
        parent_gas_limit: int,
    ) -> int:
        """Return the base fee per gas at a given fork."""
        pass


class BaseFeeChangeCalculator(Protocol):
    """
    A protocol to calculate the gas that needs to be used to change the base
    fee.
    """

    def __call__(
        self,
        *,
        parent_base_fee_per_gas: int,
        parent_gas_limit: int,
        required_base_fee_per_gas: int,
    ) -> int:
        """Return the gas that needs to be used to change the base fee."""
        pass


class TransactionIntrinsicCostCalculator(Protocol):
    """
    A protocol to calculate the intrinsic gas cost of a transaction at a given
    fork.
    """

    def __call__(
        self,
        *,
        calldata: BytesConvertible = b"",
        contract_creation: bool = False,
        access_list: List[AccessList] | None = None,
        authorization_list_or_count: Sized | int | None = None,
        return_cost_deducted_prior_execution: bool = False,
        sends_value: bool = False,
        recipient_type: RecipientType = RecipientType.CONTRACT,
    ) -> int:
        """
        Return the intrinsic gas cost of a transaction given its properties.

        Args:
          calldata: The data of the transaction.
          contract_creation: Whether the transaction creates a contract.
          access_list: The list of access lists for the transaction.
          authorization_list_or_count: The list of authorizations or the count
                                       of authorizations for the transaction.
          return_cost_deducted_prior_execution: If set to False, the returned
                                                value is equal to the minimum
                                                gas required for the
                                                transaction to be valid. If
                                                set to True, the returned
                                                value is equal to the cost
                                                that is deducted from the gas
                                                limit before the transaction
                                                starts execution.
          sends_value: Whether the transaction transfers a non-zero value.
                       Forks that itemize the value-transfer charge in
                       intrinsic gas use this flag; ignored by older forks.
          recipient_type: Category of the transaction recipient. Forks
                          that vary intrinsic gas by recipient kind use this;
                          ignored by older forks.

        Returns: Gas cost of a transaction

        """
        pass


class AuthorizationGasInfo(Protocol):
    """
    Structural view of an EIP-7702 authorization's effect on the
    pre-state, used to compute its top-frame gas. The test
    ``AuthorizationTuple`` satisfies it via its ``creates_account``,
    ``writes_delegation``, and ``first_write`` fields.
    """

    creates_account: bool
    writes_delegation: bool
    first_write: bool


class TopFrameGasCalculator(Protocol):
    """
    Calculate total execution and state gas charged at the top-level frame,
    after intrinsic gas is deducted and before EVM execution begins.

    Use ``transaction_top_frame_execution_gas`` and
    ``transaction_top_frame_state_gas`` when accounting for each dimension
    separately. Return zero for forks without top-frame preparation.
    """

    def __call__(
        self,
        *,
        contract_creation: bool = False,
        sends_value: bool = False,
        recipient_type: RecipientType = RecipientType.CONTRACT,
        delegation_warm: bool = False,
        authorizations: Sequence[AuthorizationGasInfo] = (),
    ) -> int:
        """
        Return the total gas consumed by top-frame preparation for a
        transaction at this fork.

        Args:
          contract_creation: Whether the transaction creates a contract.
                             Account creation may consume top-frame
                             state gas.
          sends_value: Whether the transaction transfers a non-zero
                       value.
          recipient_type: Category of the transaction recipient.
                          Drives the conditional charges.
          delegation_warm: Whether a delegated recipient's delegation
                           target is already warm, charging warm rather
                           than cold access.
          authorizations: The transaction's EIP-7702 authorizations;
                          each contributes its top-frame execution gas.

        Returns: Execution gas added by top-frame preparation.

        """
        pass


class BlobGasPriceCalculator(Protocol):
    """
    A protocol to calculate the blob gas price given the excess blob gas at a
    given fork.
    """

    def __call__(self, *, excess_blob_gas: int) -> int:
        """Return the blob gas price given the excess blob gas."""
        pass


class ExcessBlobGasCalculator(Protocol):
    """
    A protocol to calculate the excess blob gas for a block at a given fork.
    """

    def __call__(
        self,
        *,
        parent_excess_blob_gas: int | None = None,
        parent_excess_blobs: int | None = None,
        parent_blob_gas_used: int | None = None,
        parent_blob_count: int | None = None,
        parent_base_fee_per_gas: int,
    ) -> int:
        """
        Return the excess blob gas given the parent's excess blob gas and blob
        gas used.
        """
        pass


class RefundTypes(Enum):
    """Enum used to describe all refund types a fork can have."""

    STORAGE_CLEAR = auto()
    AUTHORIZATION_EXISTING_AUTHORITY = auto()


class SystemCallPhase(Enum):
    """When a block calls a system contract, if at all."""

    NONE = "none"
    BEFORE_TRANSACTIONS = "before_transactions"
    AFTER_TRANSACTIONS = "after_transactions"


class BaseForkMeta(ABCMeta):
    """Metaclass for BaseFork."""

    MEMOIZED_FORK_METHODS = ("gas_costs",)
    """fork ``classmethod``s that are memoized per fork."""

    def __new__(
        mcs,
        name: str,
        bases: Tuple[type, ...],
        namespace: Dict[str, Any],
        **kwargs: Any,
    ) -> "BaseForkMeta":
        """
        Create the fork class, memoizing `MEMOIZED_FORK_METHODS`.

        Wrapping every override here, rather than at each definition site,
        means the most-derived one caches, keyed on the fork it was called
        with, so the ``super()`` chain runs once per fork.
        """
        for method_name in mcs.MEMOIZED_FORK_METHODS:
            method = namespace.get(method_name)
            if not isinstance(method, classmethod):
                continue
            function = method.__func__
            if getattr(function, "__isabstractmethod__", False):
                # Leave `BaseFork`'s declarations visible to `abc`.
                continue
            # typeshed models `lru_cache` as returning an
            # `_lru_cache_wrapper`, not a plain function, so `classmethod`
            # cannot infer the descriptor signature from it.
            cached = cast(
                Callable[..., Any], lru_cache(maxsize=None)(function)
            )
            namespace[method_name] = classmethod(cached)
        return super().__new__(mcs, name, bases, namespace, **kwargs)

    @abstractmethod
    def name(cls) -> str:
        """
        Return the name of the fork (e.g., Berlin), must be implemented by
        subclasses.
        """
        pass

    def __repr__(cls) -> str:
        """Print the name of the fork, instead of the class."""
        return cls.name()

    @staticmethod
    def _maybe_transitioned(fork_cls: "BaseForkMeta") -> "BaseForkMeta":
        """
        Return the transitioned fork, if a transition fork, otherwise return
        `fork_cls`.
        """
        return (
            fork_cls.transitions_to()
            if hasattr(fork_cls, "transitions_to")
            else fork_cls
        )

    @staticmethod
    def _is_subclass_of(a: "BaseForkMeta", b: "BaseForkMeta") -> bool:
        """
        Check if `a` is a subclass of `b`, taking fork transitions into
        account.
        """
        a = BaseForkMeta._maybe_transitioned(a)
        b = BaseForkMeta._maybe_transitioned(b)
        return issubclass(a, b)

    def __gt__(cls, other: "BaseForkMeta") -> bool:
        """Compare if a fork is newer than some other fork (cls > other)."""
        return cls is not other and BaseForkMeta._is_subclass_of(cls, other)

    def __ge__(cls, other: "BaseForkMeta") -> bool:
        """
        Compare if a fork is newer than or equal to some other fork (cls >=
        other).
        """
        return cls is other or BaseForkMeta._is_subclass_of(cls, other)

    def __lt__(cls, other: "BaseForkMeta") -> bool:
        """Compare if a fork is older than some other fork (cls < other)."""
        # "Older" means other is a subclass of cls, but not the same.
        return cls is not other and BaseForkMeta._is_subclass_of(other, cls)

    def __le__(cls, other: "BaseForkMeta") -> bool:
        """
        Compare if a fork is older than or equal to some other fork (cls <=
        other).
        """
        return cls is other or BaseForkMeta._is_subclass_of(other, cls)


class BaseFork(ForkOpcodeInterface, metaclass=BaseForkMeta):
    """
    An abstract class representing an Ethereum fork.

    Must contain all the methods used by every fork.
    """

    is_transition_fork: ClassVar[bool] = False

    _transition_tool_name: ClassVar[Optional[str]] = None
    _ignore: ClassVar[bool] = False
    _bpo_fork: ClassVar[bool] = False
    _children: ClassVar[Set[Type["BaseFork"]]] = set()
    _ruleset_name: ClassVar[Optional[str]] = None
    _fork_by_timestamp: ClassVar[bool] = False
    _blob_constants: ClassVar[Dict[str, int]] = {}
    _deployed: ClassVar[bool] = True
    _enabled_eips: ClassVar[Set[int]] = set()
    _enabling_forks: ClassVar[Set[Type["BaseFork"]]] = set()

    # Method version bumps
    _engine_new_payload_version_bump: ClassVar[bool] = False
    _engine_forkchoice_updated_version_bump: ClassVar[bool] = False
    _engine_get_payload_version_bump: ClassVar[bool] = False
    _engine_get_blobs_version_bump: ClassVar[bool] = False

    def __init_subclass__(
        cls,
        *,
        transition_tool_name: Optional[str] = None,
        ignore: bool = False,
        bpo_fork: bool = False,
        ruleset_name: Optional[str] = None,
        fork_by_timestamp: Optional[bool] = None,
        deployed: Optional[bool] = None,
        update_blob_constants: Optional[Dict[str, int]] = None,
        engine_new_payload_version_bump: Optional[bool] = None,
        engine_forkchoice_updated_version_bump: Optional[bool] = None,
        engine_get_payload_version_bump: Optional[bool] = None,
        engine_get_blobs_version_bump: Optional[bool] = None,
    ) -> None:
        """
        Initialize new fork with values that don't carry over to subclass
        forks.
        """
        cls._transition_tool_name = transition_tool_name
        cls._ignore = ignore
        cls._bpo_fork = bpo_fork
        cls._ruleset_name = ruleset_name
        cls._children = set()
        if fork_by_timestamp is None:
            parent = cls.parent()
            cls._fork_by_timestamp = (
                parent._fork_by_timestamp if parent is not None else False
            )
        else:
            cls._fork_by_timestamp = fork_by_timestamp
        base_fork_class = None
        for base_class in cls.__bases__:
            if issubclass(base_class, BaseFork) and not base_class.is_eip():
                base_fork_class = base_class
                break
        assert base_fork_class is not None
        cls._enabled_eips = set()
        if base_fork_class != BaseFork:
            base_fork_class._children.add(cls)
            cls._enabled_eips |= base_fork_class._enabled_eips
        eip_bases = [
            base_class
            for base_class in cls.__bases__
            if issubclass(base_class, BaseFork) and base_class.is_eip()
        ]
        cls._enabling_forks = set()
        for eip_base in eip_bases:
            cls._enabled_eips.add(eip_base.eip())
            eip_base._enabling_forks.add(cls)
        # Bump the versions if any of the EIPs bump the version
        if engine_new_payload_version_bump is not None:
            cls._engine_new_payload_version_bump = (
                engine_new_payload_version_bump
            )
        else:
            cls._engine_new_payload_version_bump = any(
                eip_base._engine_new_payload_version_bump
                for eip_base in eip_bases
            )

        if engine_forkchoice_updated_version_bump is not None:
            cls._engine_forkchoice_updated_version_bump = (
                engine_forkchoice_updated_version_bump
            )
        else:
            cls._engine_forkchoice_updated_version_bump = any(
                eip_base._engine_forkchoice_updated_version_bump
                for eip_base in eip_bases
            )

        if engine_get_payload_version_bump is not None:
            cls._engine_get_payload_version_bump = (
                engine_get_payload_version_bump
            )
        else:
            cls._engine_get_payload_version_bump = any(
                eip_base._engine_get_payload_version_bump
                for eip_base in eip_bases
            )

        if engine_get_blobs_version_bump is not None:
            cls._engine_get_blobs_version_bump = engine_get_blobs_version_bump
        else:
            cls._engine_get_blobs_version_bump = any(
                eip_base._engine_get_blobs_version_bump
                for eip_base in eip_bases
            )

        # Calculate blob constants
        cls._blob_constants = base_fork_class._blob_constants.copy()
        if update_blob_constants is not None:
            cls._blob_constants |= update_blob_constants
        else:
            for eip_base in eip_bases:
                cls._blob_constants |= eip_base._blob_constants

        # Determine fork deployment status
        if deployed is not None:
            cls._deployed = deployed
        else:
            if base_fork_class is not BaseFork:
                cls._deployed = base_fork_class._deployed

    @classmethod
    def state_commitment(cls) -> StateCommitment:
        """Return the state-commitment scheme for the state root."""
        return StateCommitment.MPT

    # Header information abstract methods
    @classmethod
    @abstractmethod
    def header_base_fee_required(cls) -> bool:
        """Return true if the header must contain base fee."""
        pass

    @classmethod
    @abstractmethod
    def header_prev_randao_required(cls) -> bool:
        """Return true if the header must contain Prev Randao value."""
        pass

    @classmethod
    @abstractmethod
    def header_zero_difficulty_required(cls) -> bool:
        """Return true if the header must have difficulty zero."""
        pass

    @classmethod
    @abstractmethod
    def header_withdrawals_required(cls) -> bool:
        """Return true if the header must contain withdrawals."""
        pass

    @classmethod
    @abstractmethod
    def header_excess_blob_gas_required(cls) -> bool:
        """Return true if the header must contain excess blob gas."""
        pass

    @classmethod
    @abstractmethod
    def header_blob_gas_used_required(cls) -> bool:
        """Return true if the header must contain blob gas used."""
        pass

    @classmethod
    @abstractmethod
    def header_beacon_root_required(cls) -> bool:
        """Return true if the header must contain parent beacon block root."""
        pass

    @classmethod
    @abstractmethod
    def header_requests_required(cls) -> bool:
        """Return true if the header must contain beacon chain requests."""
        pass

    @classmethod
    @abstractmethod
    def header_bal_hash_required(cls) -> bool:
        """Return true if the header must contain block access list hash."""
        pass

    @classmethod
    @abstractmethod
    def empty_block_bal_item_count(cls) -> int:
        """
        Return the number of BAL items produced by an empty block.

        Each system contract address counts as 1 item, and each unique
        storage key it touches (reads or writes) counts as 1 item.
        """
        pass

    @classmethod
    @abstractmethod
    def header_slot_number_required(cls) -> bool:
        """Return true if the header must contain slot number (EIP-7843)."""
        pass

    # Gas related abstract methods

    @classmethod
    @abstractmethod
    def gas_costs(cls) -> GasCosts:
        """Return dataclass with the gas costs constants for the fork."""
        pass

    @classmethod
    @abstractmethod
    def minimum_block_gas_limit(cls) -> int:
        """Return the minimum block gas limit for it to be considered valid."""
        pass

    @classmethod
    @abstractmethod
    def opcode_gas_map(
        cls,
    ) -> Dict[OpcodeBase, int | Callable[[OpcodeBase], int]]:
        """
        Return a mapping of opcodes to either int or callable.

        The values of the mapping can be as follow:
        - Constants (int): Direct gas cost values from gas_costs()
        - Callables: Functions that take the opcode instance with metadata and
                     return gas cost
        """
        pass

    @classmethod
    @abstractmethod
    def opcode_state_map(
        cls,
    ) -> Dict[OpcodeBase, int | Callable[[OpcodeBase], int]]:
        """
        Return a mapping of opcodes to their state gas costs.

        An int value is a multiplier of `cost_per_state_byte`. A
        callable takes the opcode instance with metadata and returns
        the full state gas cost.
        """
        pass

    @classmethod
    @abstractmethod
    def opcode_refund_map(
        cls,
    ) -> Dict[OpcodeBase, int | Callable[[OpcodeBase], int]]:
        """
        Return a mapping of opcodes to their gas refunds.

        An int value is a direct gas refund. A callable takes the
        opcode instance with metadata and returns the gas refund.
        """
        pass

    @classmethod
    @abstractmethod
    def opcode_state_refund_map(
        cls,
    ) -> Dict[OpcodeBase, int | Callable[[OpcodeBase], int]]:
        """
        Return a mapping of opcodes to their state refunds.

        An int value is a multiplier of `cost_per_state_byte`. A
        callable takes the opcode instance with metadata and returns
        the state refund.
        """
        pass

    # Gas calculation helpers
    @classmethod
    @abstractmethod
    def _calculate_sstore_refund(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """Calculate SSTORE gas refund based on metadata."""
        pass

    @classmethod
    @abstractmethod
    def _calculate_sstore_gas(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """Calculate SSTORE gas cost based on metadata."""
        pass

    @classmethod
    @abstractmethod
    def _calculate_call_gas(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """
        Calculate CALL/DELEGATECALL/STATICCALL gas cost based on metadata.
        """
        pass

    @classmethod
    @abstractmethod
    def _calculate_create_gas(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """CREATE gas is constant at Frontier."""
        pass

    @classmethod
    @abstractmethod
    def _calculate_create2_gas(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """
        Calculate CREATE2 gas cost including initcode cost.
        """
        pass

    @classmethod
    @abstractmethod
    def _calculate_return_gas(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """Calculate RETURN gas cost based on metadata."""
        pass

    @classmethod
    @abstractmethod
    def _calculate_selfdestruct_gas(
        cls, opcode: OpcodeBase, gas_costs: GasCosts
    ) -> int:
        """Calculate SELFDESTRUCT gas cost based on metadata."""
        pass

    @classmethod
    @abstractmethod
    def _with_memory_expansion(
        cls,
        base_gas: int | Callable[[OpcodeBase], int],
        memory_expansion_gas_calculator: MemoryExpansionGasCalculator,
    ) -> Callable[[OpcodeBase], int]:
        """Wrap a gas cost calculator to include memory expansion cost."""
        pass

    @classmethod
    @abstractmethod
    def _with_account_access(
        cls,
        base_gas: int | Callable[[OpcodeBase], int],
        gas_costs: "GasCosts",
    ) -> Callable[[OpcodeBase], int]:
        """Wrap a gas cost calculator to include account access cost."""
        pass

    @classmethod
    @abstractmethod
    def _with_data_copy(
        cls,
        base_gas: int | Callable[[OpcodeBase], int],
        gas_costs: "GasCosts",
    ) -> Callable[[OpcodeBase], int]:
        """Wrap a gas cost calculator to include data copy cost."""
        pass

    # Gas calculators
    @classmethod
    @abstractmethod
    def memory_expansion_gas_calculator(cls) -> MemoryExpansionGasCalculator:
        """
        Return a callable that calculates the gas cost of memory expansion for
        the fork.
        """
        pass

    @classmethod
    @abstractmethod
    def calldata_gas_calculator(cls) -> CalldataGasCalculator:
        """
        Return callable that calculates the transaction gas cost for its
        calldata depending on its contents.
        """
        pass

    @classmethod
    @abstractmethod
    def base_fee_per_gas_calculator(cls) -> BaseFeePerGasCalculator:
        """
        Return a callable that calculates the base fee per gas at a given fork.
        """
        pass

    @classmethod
    @abstractmethod
    def base_fee_change_calculator(cls) -> BaseFeeChangeCalculator:
        """
        Return a callable that calculates the gas that needs to be used to
        change the base fee.
        """
        pass

    @classmethod
    @abstractmethod
    def cost_per_state_byte(cls) -> int:
        """
        Return the cost per state byte for this fork.
        """
        pass

    # Fee helpers
    @classmethod
    @abstractmethod
    def base_fee_max_change_denominator(cls) -> int:
        """Return the base fee max change denominator at a given fork."""
        pass

    @classmethod
    @abstractmethod
    def base_fee_elasticity_multiplier(cls) -> int:
        """Return the base fee elasticity multiplier at a given fork."""
        pass

    @classmethod
    @abstractmethod
    def max_refund_quotient(cls) -> int:
        """Return the max refund quotient at a given fork."""
        pass

    # Transaction cost calculators
    @classmethod
    @abstractmethod
    def transaction_data_floor_cost_calculator(
        cls,
    ) -> TransactionDataFloorCostCalculator:
        """
        Return a callable that calculates the transaction floor cost due to its
        calldata.
        """
        pass

    @classmethod
    @abstractmethod
    def transaction_intrinsic_cost_calculator(
        cls,
    ) -> TransactionIntrinsicCostCalculator:
        """
        Return callable that calculates the intrinsic gas cost of a transaction
        for the fork.
        """
        pass

    @classmethod
    def transaction_top_frame_gas_calculator(
        cls,
    ) -> TopFrameGasCalculator:
        """Return a calculator for total execution and state top-frame gas."""

        def fn(
            *,
            contract_creation: bool = False,
            sends_value: bool = False,
            recipient_type: RecipientType = RecipientType.CONTRACT,
            delegation_warm: bool = False,
            authorizations: Sequence[AuthorizationGasInfo] = (),
        ) -> int:
            return cls.transaction_top_frame_execution_gas(
                contract_creation=contract_creation,
                sends_value=sends_value,
                recipient_type=recipient_type,
                delegation_warm=delegation_warm,
                authorizations=authorizations,
            ) + cls.transaction_top_frame_state_gas(
                contract_creation=contract_creation,
                sends_value=sends_value,
                recipient_type=recipient_type,
                authorizations=authorizations,
            )

        return fn

    @classmethod
    def transaction_top_frame_execution_gas(
        cls,
        *,
        contract_creation: bool = False,
        sends_value: bool = False,
        recipient_type: RecipientType = RecipientType.CONTRACT,
        delegation_warm: bool = False,
        authorizations: Sequence[AuthorizationGasInfo] = (),
    ) -> int:
        """
        Return the additional execution gas charged at the top-level
        transaction frame, after intrinsic gas is deducted but before
        EVM execution begins.

        Defaults to returning 0 for forks that do not perform such
        post-intrinsic preparation.
        """
        del contract_creation, sends_value, recipient_type
        del delegation_warm, authorizations
        return 0

    @classmethod
    def transaction_top_frame_state_gas(
        cls,
        *,
        contract_creation: bool = False,
        sends_value: bool = False,
        recipient_type: RecipientType = RecipientType.CONTRACT,
        authorizations: Sequence[AuthorizationGasInfo] = (),
    ) -> int:
        """
        Return the state gas charged at the top-level transaction
        frame, after intrinsic gas is deducted but before EVM execution
        begins. Companion to ``transaction_top_frame_execution_gas``;
        tests targeting the spillover boundary feed this through
        ``oog_budget_lift`` to get the equivalent execution-gas budget.

        Defaults to 0 for forks that do not perform such
        post-intrinsic preparation.
        """
        del contract_creation, sends_value, recipient_type, authorizations
        return 0

    @classmethod
    def call_value_stipend(cls) -> int:
        """
        Return the gas stipend forwarded to the callee of a value-bearing
        CALL/CALLCODE.

        The stipend is added to the child frame's gas and returned to the
        caller when the callee does not consume it, so tests that pin
        value-call gas at an exact boundary subtract it from the charged
        total. Exposed as a named accessor so tests need not read
        ``gas_costs().CALL_STIPEND`` directly.
        """
        return cls.gas_costs().CALL_STIPEND

    @classmethod
    def system_call_gas_limit(cls) -> int:
        """
        Return the total gas budget the system transaction grants the
        target contract.
        """
        return 0

    @classmethod
    @abstractmethod
    def blob_gas_price_calculator(cls) -> BlobGasPriceCalculator:
        """
        Return a callable that calculates the blob gas price at a given fork.
        """
        pass

    @classmethod
    @abstractmethod
    def excess_blob_gas_calculator(cls) -> ExcessBlobGasCalculator:
        """
        Return a callable that calculates the excess blob gas for a block at a
        given fork.
        """
        pass

    # Blob constants methods
    @classmethod
    @abstractmethod
    def supports_blobs(cls) -> bool:
        """Return whether the given fork supports blobs or not."""
        pass

    @classmethod
    def get_blob_constant(cls, name: str) -> int:
        """Return blob constant if it exists."""
        assert cls.supports_blobs(), (
            "Requested a blob constant in a fork that does not support blobs"
        )
        retrieved_constant = cls._blob_constants.get(name)
        assert retrieved_constant is not None, (
            f"You tried to retrieve the blob constant {name} but it does "
            "not exist!"
        )
        return retrieved_constant

    @classmethod
    def min_base_fee_per_blob_gas(cls) -> int:
        """Return the minimum base fee per blob gas at a given fork."""
        return cls.get_blob_constant("MIN_BASE_FEE_PER_BLOB_GAS")

    @classmethod
    def blob_gas_per_blob(cls) -> int:
        """Return the amount of blob gas used per blob at a given fork."""
        return cls.get_blob_constant("BLOB_GAS_PER_BLOB")

    @classmethod
    def blob_base_fee_update_fraction(cls) -> int:
        """Return the blob base fee update fraction at a given fork."""
        return cls.get_blob_constant("BLOB_BASE_FEE_UPDATE_FRACTION")

    @classmethod
    def target_blobs_per_block(cls) -> int:
        """Return the target blobs per block at a given fork."""
        return cls.get_blob_constant("TARGET_BLOBS_PER_BLOCK")

    @classmethod
    def max_blobs_per_tx(cls) -> int:
        """Return the max blobs per transaction at a given fork."""
        if "MAX_BLOBS_PER_TX" in cls._blob_constants:
            return cls._blob_constants["MAX_BLOBS_PER_TX"]
        return cls.get_blob_constant("MAX_BLOBS_PER_BLOCK")

    @classmethod
    def max_blobs_per_block(cls) -> int:
        """Return the max blobs per block at a given fork."""
        return cls.get_blob_constant("MAX_BLOBS_PER_BLOCK")

    @classmethod
    def blob_base_cost(cls) -> int:
        """Return the base cost of a blob at a given fork."""
        return cls.get_blob_constant("BLOB_BASE_COST")

    @classmethod
    @abstractmethod
    def blob_reserve_price_active(cls) -> bool:
        """
        Return whether the fork uses a reserve price mechanism for blobs or
        not.
        """
        pass

    @classmethod
    @abstractmethod
    def full_blob_tx_wrapper_version(cls) -> int | None:
        """
        Return the version of the full blob transaction wrapper at a given
        fork.
        """
        pass

    @classmethod
    @abstractmethod
    def blob_schedule(cls) -> BlobSchedule | None:
        """Return the blob schedule up until the given fork."""
        pass

    @classmethod
    @abstractmethod
    def get_reward(cls) -> int:
        """Return expected reward amount in wei of a given fork."""
        pass

    # Transaction related abstract methods

    @classmethod
    @abstractmethod
    def supports_protected_txs(cls) -> bool:
        """Return whether the fork implements EIP-155 protection."""
        pass

    @classmethod
    @abstractmethod
    def tx_types(cls) -> List[int]:
        """Return list of the transaction types supported by the fork."""
        pass

    @classmethod
    @abstractmethod
    def contract_creating_tx_types(cls) -> List[int]:
        """
        Return list of the transaction types supported by the fork that can
        create contracts.
        """
        pass

    @classmethod
    @abstractmethod
    def transaction_gas_limit_cap(cls) -> int | None:
        """
        Return the transaction gas limit cap, or None if no limit is imposed.
        """
        pass

    @classmethod
    @abstractmethod
    def transaction_total_gas_limit_cap(cls) -> int | None:
        """
        Return the cap on a transaction's total gas limit, or None if no
        such cap is imposed.

        Where `transaction_gas_limit_cap` bounds only execution gas (from
        EIP-8037 onwards), this cap bounds `tx.gas` as a whole, including
        any state gas reservoir.
        """
        pass

    @classmethod
    @abstractmethod
    def state_gas_reservoir_enabled(cls) -> bool:
        """
        Return True if the fork enables a state gas reservoir.
        """
        pass

    @classmethod
    @abstractmethod
    def code_deposit_state_gas(cls, *, code_size: int) -> int:
        """Return state gas for code deposit of the given size."""
        pass

    @classmethod
    @abstractmethod
    def create_state_gas(cls, *, code_size: int = 0) -> int:
        """Return total state gas for CREATE."""
        pass

    @classmethod
    def oog_budget_lift(
        cls,
        *,
        sstores_before_oog: int = 0,
        creates_before_oog: int = 0,
        deploy_code_size: int = 0,
    ) -> int:
        """
        Return the extra execution gas an out of gas budget needs to
        stop at the same point on this fork: the state gas EIP-8037
        spills into execution gas for the given SSTOREs, CREATEs, and
        deployed bytes. Zero before EIP-8037, so no fork guard needed.
        """
        return (
            sstores_before_oog * Opcodes.SSTORE(new_value=1).state_cost(cls)
            + creates_before_oog * cls.create_state_gas()
            + cls.code_deposit_state_gas(code_size=deploy_code_size)
        )

    @classmethod
    @abstractmethod
    def block_rlp_size_limit(cls) -> int | None:
        """
        Return the maximum RLP size of a block in bytes, or None if no limit is
        imposed.
        """
        pass

    @classmethod
    @abstractmethod
    def precompiles(cls) -> List[Address]:
        """Return list of precompiles supported by the fork."""
        pass

    @classmethod
    @abstractmethod
    def system_contracts(cls) -> List[Address]:
        """Return list of system contracts supported by the fork."""
        pass

    @classmethod
    @abstractmethod
    def system_contract_call_phases(cls) -> Mapping[Address, SystemCallPhase]:
        """Return when the block calls each of its system contracts."""
        pass

    @classmethod
    @abstractmethod
    def system_contract_request_types(
        cls,
    ) -> List[Type[SystemContractRequest]]:
        """Return the request classes triggered through a system contract."""
        pass

    @classmethod
    @abstractmethod
    def deterministic_factory_contract_address(cls) -> Address | None:
        """
        Return the address of the deterministic factory contract at a
        given fork. Return `None` if the fork does not support deterministic
        deployment.
        """
        pass

    @classmethod
    @abstractmethod
    def pre_allocation(cls) -> Mapping:
        """
        Return required pre-allocation of accounts for any kind of test.

        This method must always call the `fork_to` method when transitioning,
        because the allocation can only be set at genesis, and thus cannot be
        changed at transition time.
        """
        pass

    @classmethod
    @abstractmethod
    def pre_allocation_blockchain(cls) -> Mapping:
        """
        Return required pre-allocation of accounts for any blockchain tests.

        This method must always call the `fork_to` method when transitioning,
        because the allocation can only be set at genesis, and thus cannot be
        changed at transition time.
        """
        pass

    # Engine API information abstract methods
    @classmethod
    @abstractmethod
    def engine_new_payload_blob_hashes(cls) -> bool:
        """
        Return true if the engine api version requires new payload calls to
        include blob hashes.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_new_payload_beacon_root(cls) -> bool:
        """
        Return true if the engine api version requires new payload calls to
        include a parent beacon block root.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_new_payload_requests(cls) -> bool:
        """
        Return true if the engine api version requires new payload calls to
        include requests.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_new_payload_target_blobs_per_block(cls) -> bool:
        """
        Return true if the engine api version requires new payload calls to
        include target blobs per block.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_execution_payload_block_access_list(cls) -> bool:
        """
        Return `True` if the engine api version requires execution payload to
        include a `block_access_list`.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_payload_attribute_target_blobs_per_block(cls) -> bool:
        """
        Return true if the payload attributes include the target blobs per
        block.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_payload_attribute_max_blobs_per_block(cls) -> bool:
        """
        Return true if the payload attributes include the max blobs per block.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_payload_attribute_slot_number(cls) -> bool:
        """
        Return true if the payload attributes include the slot number.
        """
        pass

    @classmethod
    @abstractmethod
    def engine_payload_attribute_target_gas_limit(cls) -> bool:
        """
        Return true if the payload attributes include the target gas limit.
        """
        pass

    # Engine API method versions
    @classmethod
    def engine_new_payload_version(cls) -> Optional[int]:
        """
        Return `None` if this fork's payloads cannot be sent over the engine
        API, or the payload version if it can.
        """
        current_version = 0
        current_cls: Type["BaseFork"] | None = cls
        while current_cls is not None:
            if current_cls._engine_new_payload_version_bump:
                current_version += 1
            current_cls = current_cls.parent()
        return current_version if current_version > 0 else None

    @classmethod
    def engine_forkchoice_updated_version(cls) -> Optional[int]:
        """
        Return `None` if the forks canonical chain cannot be set using the
        forkchoice method.
        """
        current_version = 0
        current_cls: Type["BaseFork"] | None = cls
        while current_cls is not None:
            if current_cls._engine_forkchoice_updated_version_bump:
                current_version += 1
            current_cls = current_cls.parent()
        return current_version if current_version > 0 else None

    @classmethod
    def engine_get_payload_version(cls) -> Optional[int]:
        """
        Return `None` if the forks canonical chain cannot build a payload using
        the engine API.
        """
        current_version = 0
        current_cls: Type["BaseFork"] | None = cls
        while current_cls is not None:
            if current_cls._engine_get_payload_version_bump:
                current_version += 1
            current_cls = current_cls.parent()
        return current_version if current_version > 0 else None

    @classmethod
    def engine_get_blobs_version(cls) -> Optional[int]:
        """
        Return `None` if the fork does not support the engine get blobs
        version.
        """
        current_version = 0
        current_cls: Type["BaseFork"] | None = cls
        while current_cls is not None:
            if current_cls._engine_get_blobs_version_bump:
                current_version += 1
            current_cls = current_cls.parent()
        return current_version if current_version > 0 else None

    # EVM information abstract methods
    @classmethod
    @abstractmethod
    def max_code_size(cls) -> int:
        """
        Return the maximum code size allowed to be deployed in a contract
        creation.
        """
        pass

    @classmethod
    @abstractmethod
    def max_stack_height(cls) -> int:
        """Return the maximum stack height allowed in the EVM stack."""
        pass

    @classmethod
    @abstractmethod
    def max_initcode_size(cls) -> int:
        """
        Return the maximum initcode size allowed to be used in a contract
        creation.
        """
        pass

    @classmethod
    @abstractmethod
    def call_opcodes(cls) -> List[Opcodes]:
        """Return list of call opcodes supported by the fork."""
        pass

    @classmethod
    @abstractmethod
    def valid_opcodes(cls) -> List[Opcodes]:
        """Return list of Opcodes that are valid to work on this fork."""
        pass

    @classmethod
    @abstractmethod
    def create_opcodes(cls) -> List[Opcodes]:
        """Return list of create opcodes supported by the fork."""
        pass

    @classmethod
    @abstractmethod
    def max_request_type(cls) -> int:
        """Return max request type supported by the fork."""
        pass

    @classmethod
    @abstractmethod
    def refund_types(cls) -> List[RefundTypes]:
        """
        Return the list of refund types that are possible given current
        fork logic.
        """
        pass

    # Meta information about the fork
    @classmethod
    def name(cls) -> str:
        """Return name of the fork."""
        return cls.__name__

    @classmethod
    def fork_at(
        cls, *, block_number: int = 0, timestamp: int = 0
    ) -> Type["BaseFork"]:
        """
        Return fork at the given block number and timestamp. Useful only for
        transition forks, and it's a no-op for normal forks.
        """
        del block_number, timestamp
        return cls

    @classmethod
    def transitions_to(cls) -> Type["BaseFork"]:
        """
        Return fork where the transition ends. Useful only for
        transition forks, and it's a no-op for normal forks.
        """
        return cls

    @classmethod
    def transitions_from(cls) -> Type["BaseFork"]:
        """
        Return fork where the transition starts. Useful only for
        transition forks, and it's a no-op for normal forks.
        """
        return cls

    @classmethod
    @abstractmethod
    def transition_tool_name(cls) -> str:
        """
        Return fork name as it's meant to be passed to the transition tool for
        execution.
        """
        pass

    @classmethod
    def is_deployed(cls) -> bool:
        """
        Return whether the fork has been deployed to mainnet, or not.
        """
        return cls._deployed

    @classmethod
    def ignore(cls) -> bool:
        """Return whether the fork should be ignored during test generation."""
        return cls._ignore

    @classmethod
    def bpo_fork(cls) -> bool:
        """Return whether the fork is a BPO fork."""
        return cls._bpo_fork

    @classmethod
    def is_eip(cls) -> bool:
        """Return whether this class is an EIP."""
        return cls.__name__.startswith("EIP") and cls.__name__[-1].isdigit()

    @classmethod
    def eip(cls) -> int:
        """Return the number of this EIP class."""
        if not cls.is_eip():
            raise Exception(f"Class {cls.__name__} is not an EIP.")
        return int(cls.__name__[3:])

    @classmethod
    def is_eip_enabled(cls, *eip_numbers: int) -> bool:
        """Return whether this class has all specified EIPs enabled."""
        return all(
            eip_number in cls._enabled_eips for eip_number in eip_numbers
        )

    @classmethod
    def enabling_forks(cls) -> Set[Type["BaseFork"]]:
        """Return the forks that enable this EIP."""
        if not cls.is_eip():
            raise Exception(f"Class {cls.__name__} is not an EIP.")
        return cls._enabling_forks

    @classmethod
    def parent(cls) -> Type["BaseFork"] | None:
        """Return the parent fork."""
        base_fork_class = None
        for base_class in cls.__bases__:
            if issubclass(base_class, BaseFork) and not base_class.is_eip():
                base_fork_class = base_class
                break
        assert base_fork_class is not None
        if base_fork_class == BaseFork:
            return None
        return base_fork_class

    @classmethod
    def parent_or_fail(cls) -> Type["BaseFork"]:
        """Return the parent fork or raise if the class has no parent."""
        parent = cls.parent()
        if parent is None:
            raise Exception(
                f"Expected class {cls.__name__} to have a parent fork."
            )
        return parent

    @classmethod
    def non_bpo_ancestor(cls) -> Type["BaseFork"]:
        """Return the nearest non-BPO ancestor fork."""
        ancestor = cls
        while ancestor.bpo_fork():
            parent = ancestor.parent()
            if parent is None:
                break
            ancestor = parent
        return ancestor

    @classmethod
    def children(cls) -> Set[Type["BaseFork"]]:
        """Return the children forks."""
        return set(cls._children)

    @classmethod
    @abstractmethod
    def build_default_block_header(
        cls, *, block_number: int = 0, timestamp: int = 0
    ) -> "FixtureHeader":
        """
        Build a default block header for this fork with the given attributes.
        """
        pass

    @classmethod
    def ruleset_name(cls) -> str | None:
        """
        Return the hive ruleset name for this fork, or None.
        """
        assert cls is not BaseFork
        if cls._ruleset_name is not None:
            if cls._ruleset_name == "":
                return None
            ruleset_name = cls._ruleset_name
        else:
            if cls.__name__.startswith("BPO"):
                ruleset_name = cls.__name__
            else:
                ruleset_name = re.sub(
                    r"(?<!^)(?=[A-Z])", "_", cls.__name__
                ).upper()
        return ruleset_name

    @classmethod
    def ruleset(cls, value: int = 0) -> Dict[str, int]:
        """
        Return the hive ruleset for this fork.
        """
        assert cls is not BaseFork
        parent = cls.parent()
        if parent is None:
            return {}
        entries: Dict[str, int] = {}
        entries |= parent.ruleset()
        ruleset_name = cls.ruleset_name()
        if ruleset_name:
            if cls._fork_by_timestamp:
                hive_ruleset_name = f"HIVE_{ruleset_name}_TIMESTAMP"
            else:
                hive_ruleset_name = f"HIVE_FORK_{ruleset_name}"
            entries[hive_ruleset_name] = value
            if cls.supports_blobs():
                entries[f"HIVE_{ruleset_name}_BLOB_TARGET"] = (
                    cls.target_blobs_per_block()
                )
                entries[f"HIVE_{ruleset_name}_BLOB_MAX"] = (
                    cls.max_blobs_per_block()
                )
                entries[
                    f"HIVE_{ruleset_name}_BLOB_BASE_FEE_UPDATE_FRACTION"
                ] = cls.blob_base_fee_update_fraction()
        return entries
