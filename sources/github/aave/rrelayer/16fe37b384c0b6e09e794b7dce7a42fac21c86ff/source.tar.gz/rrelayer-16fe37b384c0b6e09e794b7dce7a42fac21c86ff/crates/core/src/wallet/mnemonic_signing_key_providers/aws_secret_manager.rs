use aws_config::{BehaviorVersion, Region};
use aws_sdk_secretsmanager::Client;

use crate::wallet::WalletError;
use crate::yaml::AwsSecretManagerProviderConfig;

pub async fn get_aws_secret(
    config: &AwsSecretManagerProviderConfig,
) -> Result<String, WalletError> {
    let aws_config = aws_config::defaults(BehaviorVersion::latest())
        .region(Region::new(config.region.clone()))
        .load()
        .await;

    let client = Client::new(&aws_config);

    let resp =
        client.get_secret_value().secret_id(config.id.clone()).send().await.map_err(|e| {
            let service_error = e.into_service_error();
            WalletError::ApiError {
                message: format!(
                    "AWS Secrets Manager error: {} (Secret: '{}')",
                    service_error, config.id
                ),
            }
        })?;

    let secret_string = resp.secret_string().ok_or(WalletError::ApiError {
        message: format!("Secret '{}' does not contain a string value", config.id),
    })?;

    let secret_json: serde_json::Value =
        serde_json::from_str(secret_string).map_err(|e| WalletError::ApiError {
            message: format!("Failed to parse secret '{}' as JSON: {}", config.id, e),
        })?;

    let key_value = secret_json.get(&config.key).and_then(|v| v.as_str()).ok_or(
        WalletError::ConfigurationError {
            message: format!(
                "Key '{}' not found in secret '{}' or is not a string. Available keys: {:?}",
                config.key,
                config.id,
                secret_json
                    .as_object()
                    .map(|obj| obj.keys().collect::<Vec<_>>())
                    .unwrap_or_default()
            ),
        },
    )?;

    Ok(key_value.to_string())
}
