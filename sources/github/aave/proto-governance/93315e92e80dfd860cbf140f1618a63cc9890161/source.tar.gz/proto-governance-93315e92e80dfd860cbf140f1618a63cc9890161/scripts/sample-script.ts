// We require the Buidler Runtime Environment explicitly here. This is optional
// when running the script with `buidler run <script>`: you'll find the Buidler
// Runtime Environment's members available as global variable in that case.
import env  from "@nomiclabs/buidler";

async function main() {
  // console.log(await env.ethers.signers())
  // console.log(env.network)
  // You can run Buidler tasks from a script.
  // For example, we make sure everything is compiled by running "compile"
  // await env.run("compile");

  // We require the artifacts once our contracts are compiled
  // const Greeter = artifacts.require("Greeter");
  // const greeter = await Greeter.new("Hello, world!");

  // console.log("Greeter address:", greeter.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
