# @aave/cli

## 4.3.7

### Patch Changes

- Updated dependencies [41678e8]
- Updated dependencies [03a23d7]
  - @aave/client@6.6.0

## 4.3.6

### Patch Changes

- Updated dependencies [97aaf27]
- Updated dependencies [bd2bdf3]
- Updated dependencies [1f0c2fd]
  - @aave/client@6.5.0

## 4.3.5

### Patch Changes

- Updated dependencies [9164edd]
  - @aave/client@6.4.0

## 4.3.4

### Patch Changes

- Updated dependencies [3850316]
  - @aave/client@6.3.1

## 4.3.3

### Patch Changes

- Updated dependencies [2dde326]
  - @aave/client@6.3.0

## 4.3.2

### Patch Changes

- @aave/client@6.2.1

## 4.3.1

### Patch Changes

- Updated dependencies [a76557e]
- Updated dependencies [f353446]
- Updated dependencies [db2bc7b]
- Updated dependencies [1b6ee19]
- Updated dependencies [d39f1e2]
- Updated dependencies [ff75357]
  - @aave/client@6.2.0

## 4.3.0

### Minor Changes

- e35158c: **feat:** add rewards commands to the CLI

### Patch Changes

- Updated dependencies [0ebdca4]
- Updated dependencies [1d8269d]
  - @aave/client@6.1.0

## 4.2.4

### Patch Changes

- Updated dependencies [68eb092]
  - @aave/client@6.0.0

## 4.2.3

### Patch Changes

- Updated dependencies [8fc4e62]
  - @aave/client@5.0.0

## 4.2.2

### Patch Changes

- Updated dependencies [cfceb7e]
- Updated dependencies [7e21fc6]
- Updated dependencies [c4dc4b1]
  - @aave/client@4.2.0

## 4.2.1

### Patch Changes

- Updated dependencies [5eb65e6]
- Updated dependencies [a5eb3c1]
  - @aave/client@4.1.1

## 4.2.0

### Minor Changes

- cdb2f23: **feat:** add `reserveHolders` query, `ReserveHoldersFilter` enum, `useReserveHolders` hook, and `reserves holders` CLI command
- 46893ab: **feat:** add market token swap command
- 37c1fe3: feat: add user summary cli command
- cb7ec01: **feat:** add reserve lookup command and move user queries under "user" command

### Patch Changes

- e0b9968: **feat:** add 'user balance' command
- Updated dependencies [cdb2f23]
  - @aave/client@4.1.0

## 4.1.4

### Patch Changes

- b8f65dd: **feat:** add `balance` field to `UserSupplyItem` fragment
- 5277e51: **feat:** add supply action command to CLI
- ad3e905: **feat:** add repay/withdraw command actions
- b504b5c: **feat:** add borrow action command
- f064787: Add PositionSwapSetCollateralApproval support for V4 adapter refactor

  - Add PositionSwapSetCollateralApproval fragment and union variant to graphql package
  - Add setCollateralSignature field to PreparePositionSwapRequest
  - Handle new approval type in signApprovals helper (spec) and processApprovals (react)
  - Update schema from backend with new V4 adapter types

- Updated dependencies [b8f65dd]
- Updated dependencies [f064787]
  - @aave/client@4.0.4

## 4.1.3

### Patch Changes

- Updated dependencies [0e2969e]
  - @aave/client@4.0.3

## 4.1.2

### Patch Changes

- Updated dependencies [571ae62]
  - @aave/client@4.0.2

## 4.1.1

### Patch Changes

- cc2dc64: Support smart contract wallet (Safe) token swaps via presign flow. Adds SwapByTransactionWithApprovalRequired handling for SC wallets that need ERC20 approval before the presign transaction.
- Updated dependencies [4736e30]
- Updated dependencies [cc2dc64]
  - @aave/client@4.0.1

## 4.1.0

- Aave V4.
