import type { UnexpectedError } from '@aave/core';
import {
  type ChainDetails,
  ChainQuery,
  type ChainRequest,
  ChainsQuery,
  type ChainsRequest,
  type ExchangeAmount,
  ExchangeRateQuery,
  type ExchangeRateRequest,
  HasProcessedKnownTransactionQuery,
  type HasProcessedKnownTransactionRequest,
} from '@aave/graphql';
import type { ResultAsync } from '@aave/types';
import type { AaveClient } from '../AaveClient';
import {
  type BatchOptions,
  DEFAULT_QUERY_OPTIONS,
  type RequestPolicyOptions,
} from '../options';

/**
 * Fetches a specific chain by chain ID.
 *
 * ```ts
 * const result = await chain(client, {
 *   chainId: chainId(1),
 * });
 * ```
 *
 * @param client - Aave client.
 * @param request - The chain request parameters.
 * @param options - The query options.
 * @returns The chain data, or null if not found. `ChainDetails` carries the
 * wrapper's own `TokenInfo`, which the chain embedded in a token does not.
 */
export function chain(
  client: AaveClient,
  request: ChainRequest,
  {
    batch = DEFAULT_QUERY_OPTIONS.batch,
    requestPolicy = DEFAULT_QUERY_OPTIONS.requestPolicy,
  }: BatchOptions & RequestPolicyOptions = DEFAULT_QUERY_OPTIONS,
): ResultAsync<ChainDetails | null, UnexpectedError> {
  return client.query(ChainQuery, { request }, { batch, requestPolicy });
}

/**
 * Fetches the list of supported chains.
 *
 * ```ts
 * const chains = await chains(client, {
 *   query: { filter: ChainsFilter.ALL }
 * });
 * ```
 *
 * ```ts
 * const chains = await chains(client, {
 *   query: { chainIds: [chainId(1), chainId(137)] }
 * });
 * ```
 *
 * @param client - Aave client.
 * @param request - The chains request parameters.
 * @returns Array of supported chains.
 */
export function chains(
  client: AaveClient,
  request: ChainsRequest,
): ResultAsync<ChainDetails[], UnexpectedError> {
  return client.query(ChainsQuery, { request });
}

/**
 * Check if a transaction has been processed by the Aave API.
 *
 * @param client - Aave client.
 * @param request - The request containing transaction hash and operations to check.
 * @returns True if the transaction has been processed, false otherwise.
 */
export function hasProcessedKnownTransaction(
  client: AaveClient,
  request: HasProcessedKnownTransactionRequest,
): ResultAsync<boolean, UnexpectedError> {
  return client.query(
    HasProcessedKnownTransactionQuery,
    { request },
    {
      requestPolicy: 'network-only', // alwats hit the network
      batch: false, // never batch, always run ASAP
    },
  );
}

/**
 * Fetches the exchange rate between tokens and fiat currencies.
 *
 * ```ts
 * const result = await exchangeRate(client, {
 *   from: { erc20: { chainId: chainId(1), address: evmAddress('0xA0b86a33E6...') } },
 *   to: Currency.Usd,
 * });
 * ```
 *
 * @param client - Aave client.
 * @param request - The exchange rate request parameters.
 * @param options - The query options.
 * @returns The exchange rate information as a fiat amount.
 */
export function exchangeRate(
  client: AaveClient,
  request: ExchangeRateRequest,
  {
    requestPolicy = DEFAULT_QUERY_OPTIONS.requestPolicy,
  }: RequestPolicyOptions = DEFAULT_QUERY_OPTIONS,
): ResultAsync<ExchangeAmount, UnexpectedError> {
  return client.query(ExchangeRateQuery, { request }, { requestPolicy });
}
