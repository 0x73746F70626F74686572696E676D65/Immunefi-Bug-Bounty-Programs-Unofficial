import { type StandardData, UnexpectedError } from '@aave/client';
import { extractDocumentName } from '@aave/core';
import {
  type AnyVariables,
  invariant,
  type NullishDeep,
  ok,
  type Prettify,
  type Result,
} from '@aave/types';
import { useEffect, useMemo, useRef, useState } from 'react';
import { createRequest, type TypedDocumentNode, useQuery } from 'urql';
import {
  type PausableReadResult,
  type PausableSuspenseResult,
  type QueryMetadata,
  ReadResult,
  type SuspendableResult,
  type SuspenseResult,
} from './results';

export type Selector<ResponseValue, SelectorData, SelectorError> = (
  data: ResponseValue,
) => Result<SelectorData, SelectorError>;

export type Pausable<T, WhenPaused = NullishDeep<T>> = Prettify<
  WhenPaused & {
    /**
     * Prevents the hook from automatically executing GraphQL query operations.
     *
     * @experimental This is an experimental feature and may change in the future.
     *
     * @remarks
     * `pause` may be set to `true` to stop the query operation from executing
     * automatically. The hook will stop receiving updates and won't execute the query
     * operation until it's set to `false`.
     */
    pause: boolean;
  }
>;

export type Suspendable = { suspense: true };

/**
 * @internal
 */
export type UseSuspendableQueryArgs<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables extends AnyVariables,
  Suspense extends boolean,
  Pause extends boolean = never,
> = {
  document: TypedDocumentNode<StandardData<ResponseValue>, Variables>;
  variables?: Pause extends boolean ? NullishDeep<Variables> : Variables;
  suspense: Suspense;
  selector?: Selector<ResponseValue, SelectorData, SelectorError>;
  pollInterval?: number;
  batch?: boolean;
  pause?: Pause;
};

/**
 * @internal
 */
export function useSuspendableQuery<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables extends AnyVariables,
  Pausable extends boolean = never,
>({
  document,
  variables,
  suspense,
  pause,
}: UseSuspendableQueryArgs<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables,
  false,
  Pausable
>):
  | ReadResult<SelectorData, SelectorError | UnexpectedError>
  | PausableReadResult<SelectorData, SelectorError | UnexpectedError>;
/**
 * @internal
 */
export function useSuspendableQuery<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables extends AnyVariables,
  Pausable extends boolean = never,
>({
  document,
  variables,
  suspense,
  pause,
}: UseSuspendableQueryArgs<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables,
  true,
  Pausable
>): SuspenseResult<SelectorData> | PausableSuspenseResult<SelectorData>;
/**
 * @internal
 */
export function useSuspendableQuery<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables extends AnyVariables,
  Pausable extends boolean = never,
>({
  document,
  variables,
  suspense,
  pause,
}: UseSuspendableQueryArgs<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables,
  boolean,
  Pausable
>): SuspendableResult<SelectorData, SelectorError | UnexpectedError>;
/**
 * Implementation.
 */
export function useSuspendableQuery<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables extends AnyVariables,
>({
  document,
  variables,
  suspense,
  pause,
  selector = ok as Selector<ResponseValue, SelectorData, SelectorError>,
  pollInterval = 0,
  batch = true,
}: UseSuspendableQueryArgs<
  ResponseValue,
  SelectorData,
  SelectorError,
  Variables,
  boolean,
  boolean
>): SuspendableResult<SelectorData, SelectorError | UnexpectedError> {
  const [metadata, setMetadata] = useState<QueryMetadata>({
    operationKey: 0,
    resultOperationKey: undefined,
  });
  const [loading, setLoading] = useState(true);
  // urql keeps the previous `data` while a re-execution is in flight but drops
  // the previous `error` on the way (the closing operation's end marker merges
  // as an error-free update). Kept here so the previous error can be presented
  // during the refetch, the way data is.
  const lastError = useRef<UnexpectedError | undefined>(undefined);
  const operationId = useMemo(
    () => createRequest(document, variables as Variables).key,
    [document, variables],
  );
  const [{ fetching, data, error, stale, operation }, executeQuery] = useQuery({
    query: document,
    variables: variables as Variables,
    pause,
    context: useMemo(
      () => ({
        batch,
        suspense,
      }),
      [batch, suspense],
    ),
  });

  useEffect(() => {
    setMetadata((current) => ({
      ...current,
      operationKey: operationId,
    }));
  }, [operationId]);

  useEffect(() => {
    if (pause) return;

    if (!fetching) {
      setLoading(false);
    }
  }, [fetching, pause]);

  useEffect(() => {
    if (pause || fetching) {
      return;
    }

    setMetadata((current) => ({
      ...current,
      resultOperationKey:
        data && !stale ? current.operationKey : current.resultOperationKey,
    }));
  }, [pause, fetching, data, stale]);

  useEffect(() => {
    if (pollInterval <= 0 || fetching || pause) return undefined;

    const timerId = setTimeout(() => {
      executeQuery({
        requestPolicy: 'network-only',
        batch: false, // never batch, run now!
      });
    }, pollInterval);

    return () => clearTimeout(timerId);
  }, [fetching, executeQuery, pollInterval, pause]);

  if (pause) {
    const unexpectedError = error ? UnexpectedError.from(error) : undefined;

    if (!data) {
      return ReadResult.Paused<SelectorData, SelectorError | UnexpectedError>(
        undefined,
        unexpectedError,
        metadata,
      );
    }

    const selected = selector(data.value);

    if (selected.isErr()) {
      return ReadResult.Paused<SelectorData, SelectorError>(
        undefined,
        selected.error,
        metadata,
      );
    }

    return ReadResult.Paused<SelectorData, UnexpectedError>(
      selected.value,
      unexpectedError,
      metadata,
    );
  }

  if (!suspense && loading) {
    return ReadResult.Loading(metadata);
  }

  // stale indicates that the useQuery is fetching new data because the variables changed
  // !loading && fetching indicates that a re-fetch is happening as consequence of calling executeQuery (e.g., polling)
  const reloading = stale || (!loading && fetching);

  if (error) {
    const unexpected = UnexpectedError.from(error);
    lastError.current = unexpected;
    if (suspense) {
      throw unexpected;
    }

    return ReadResult.Failure(unexpected, metadata, reloading);
  }

  invariant(
    data !== undefined,
    `Unexpected empty response from the API for '${extractDocumentName(document) ?? 'unknown'}' query`,
  );

  // A rejected request leaves `data: null`; while its re-execution is in
  // flight that null is carried over with no `error` attached (see
  // `lastError`). Keep presenting the previous error until a settled result
  // replaces it, so selectors never receive a null that is not an API answer.
  if (fetching && data === null && lastError.current) {
    const unexpected = lastError.current;
    if (suspense) {
      throw unexpected;
    }
    return ReadResult.Failure(unexpected, metadata, true);
  }

  if (!fetching) {
    lastError.current = undefined;
  }

  // A cache-only miss is synthesised by the cache layer as `{ data: null }`
  // with no `error`, and urql delivers it to every active subscriber of the
  // same operation key. These hooks never issue cache-only operations, so such
  // a result is not an API answer and must not reach the selector.
  if (data === null && operation?.context.requestPolicy === 'cache-only') {
    const unexpected = UnexpectedError.from(
      `Cache miss for '${extractDocumentName(document) ?? 'unknown'}' query`,
    );
    if (suspense) {
      throw unexpected;
    }
    return ReadResult.Failure(unexpected, metadata, reloading);
  }

  // GraphQL responses can have `{ "data": null }` but urql types don't reflect this
  const responseValue = data === null ? null : data.value;
  const selected = selector(responseValue as ResponseValue);

  if (selected.isErr()) {
    if (suspense) {
      throw selected.error;
    }
    return ReadResult.Failure(selected.error, metadata, reloading);
  }

  return ReadResult.Success(selected.value, metadata, reloading);
}
