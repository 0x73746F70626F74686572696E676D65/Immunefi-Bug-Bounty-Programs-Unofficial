import { errAsync, InvariantError, okAsync } from '@aave/types';
import { act, renderHook, waitFor } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  type AsyncTaskError,
  type AsyncTaskIdle,
  type AsyncTaskLoading,
  type AsyncTaskSuccess,
  useAsyncTask,
} from './tasks';

describe(`Given the '${useAsyncTask.name}' hook`, () => {
  describe('When rendered for the first time', () => {
    it('Then it should return state in line with type of `AsyncTaskIdle`', async () => {
      const { result } = renderHook(() =>
        useAsyncTask((input: string) => okAsync(input), []),
      );

      const expectation: AsyncTaskIdle = {
        called: false,
        loading: false,
        data: undefined,
        error: undefined,
      };

      expect(result.current[1]).toMatchObject(expectation);
    });
  });

  describe('And the hook is executed for the first time', () => {
    describe('When the task is in progress', () => {
      it('Then it should return the state in line with type of `AsyncTaskLoading`', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => okAsync(input), []),
        );

        act(() => {
          void result.current[0]('test');
        });

        const expectation: AsyncTaskLoading<unknown> = {
          called: true,
          loading: true,
          data: undefined,
          error: undefined,
        };

        expect(result.current[1]).toMatchObject(expectation);
      });

      it('Then it should throw an InvariantError if another task execution is attempted', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => okAsync(input), []),
        );

        await act(async () => {
          await expect(async () => {
            result.current[0]('test');
            result.current[0]('test');
          }).rejects.toThrow(InvariantError);
        });
      });
    });

    describe('When the tasks succeeds', () => {
      it('Then it should return the state in line with type of `AsyncTaskSuccess`', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => okAsync(input), []),
        );

        await act(async () => {
          await result.current[0]('test');
        });

        const expectation: AsyncTaskSuccess<string> = {
          called: true,
          loading: false,
          data: 'test',
          error: undefined,
        };

        expect(result.current[1]).toMatchObject(expectation);
      });

      it('Then it should keep the callback stable', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => okAsync(input), []),
        );
        const callback = result.current[0];

        await act(async () => {
          await callback('test');
        });

        expect(result.current[0]).toBe(callback);
      });

      it('Then it should support void as success data', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((_: string) => okAsync(void 0), []),
        );

        await act(async () => {
          await result.current[0]('test');
        });

        const expectation: AsyncTaskSuccess<void> = {
          called: true,
          loading: false,
          data: undefined,
          error: undefined,
        };

        expect(result.current[1]).toMatchObject(expectation);
      });
    });

    describe('When the task throws an error synchronously', () => {
      it('Then it should revert to the previous state and rethrow the error', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((_: string) => {
            throw new Error('test error');
          }, []),
        );
        const state = result.current[1];

        await act(async () => {
          await expect(async () => {
            await result.current[0]('test');
          }).rejects.toThrow(Error);
        });

        expect(result.current[1]).toMatchObject(state);
      });
    });

    describe('When the task fails', () => {
      it('Then it should return the state in line with type of `AsyncTaskError`', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((_: string) => errAsync(new Error('test error')), []),
        );

        await act(async () => {
          await result.current[0]('test');
        });

        const expectation: AsyncTaskError<Error> = {
          called: true,
          loading: false,
          data: undefined,
          error: new Error('test error'),
        };

        expect(result.current[1]).toMatchObject(expectation);
      });

      it('Then it should keep the callback stable', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((_: string) => errAsync(new Error('test error')), []),
        );
        const callback = result.current[0];

        await act(async () => {
          await callback('test');
        });

        expect(result.current[0]).toBe(callback);
      });
    });
  });

  describe('And a previous execution failed', () => {
    describe('When the hook is executed again', () => {
      it('Then it should return the state in line with type of `AsyncTaskLoading`', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => {
            if (result.current[1].called) return okAsync(input);
            return errAsync(new Error('test error'));
          }, []),
        );

        await act(async () => {
          await result.current[0]('one');
        });

        act(() => {
          void result.current[0]('two');
        });

        const expectation: AsyncTaskLoading<string> = {
          called: true,
          loading: true,
          data: undefined,
          error: undefined,
        };
        expect(result.current[1]).toMatchObject(expectation);
      });
    });
  });

  describe('And the hook is executed again', () => {
    describe('When the task is in progress', () => {
      it('Then it should return the state in line with type of `AsyncTaskLoading`', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => okAsync(input), []),
        );

        await act(async () => {
          await result.current[0]('one');
        });

        await waitFor(() => result.current[1].loading === false);

        act(() => {
          void result.current[0]('two');
        });

        const expectation: AsyncTaskLoading<string> = {
          called: true,
          loading: true,
          data: 'one',
          error: undefined,
        };

        expect(result.current[1]).toMatchObject(expectation);
      });
    });

    describe('When the task succeeds', () => {
      it('Then it should return the state in line with type of `AsyncTaskSuccess` with updated data', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => okAsync(input), []),
        );

        await act(async () => {
          await result.current[0]('one');
        });

        await waitFor(() => result.current[1].loading === false);

        await act(async () => {
          await result.current[0]('two');
        });

        const expectation: AsyncTaskSuccess<string> = {
          called: true,
          loading: false,
          data: 'two',
          error: undefined,
        };

        expect(result.current[1]).toMatchObject(expectation);
      });
    });

    describe('When the task fails', () => {
      it('Then it should return the state in line with type of `AsyncTaskError`', async () => {
        const { result } = renderHook(() =>
          useAsyncTask((input: string) => {
            if (input === 'one') return okAsync(input);
            return errAsync(new Error('test error'));
          }, []),
        );

        await act(async () => {
          await result.current[0]('one');
        });

        await waitFor(() => result.current[1].loading === false);

        await act(async () => {
          await result.current[0]('two');
        });

        const expectation: AsyncTaskError<Error> = {
          called: true,
          loading: false,
          data: undefined,
          error: new Error('test error'),
        };

        expect(result.current[1]).toMatchObject(expectation);
      });
    });
  });
});
