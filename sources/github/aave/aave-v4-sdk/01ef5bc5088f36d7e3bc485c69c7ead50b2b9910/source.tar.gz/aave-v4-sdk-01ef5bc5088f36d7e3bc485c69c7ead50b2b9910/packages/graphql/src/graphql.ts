import type {
  AnySelectionSet,
  AnyVariables,
  BigDecimal,
  BlockchainData,
  ChainId,
  Cursor,
  EvmAddress,
  JsonObject,
  Signature,
  TxHash,
  TypedSelectionSet,
  Void,
} from '@aave/types';
import {
  type DocumentDecoration,
  initGraphQLTada,
  type TadaDocumentNode,
} from 'gql.tada';
import type {
  ActivityType,
  ApyMetric,
  BorrowSwapKind,
  ChainsFilter,
  CollateralMetric,
  Currency,
  OperationType,
  OrderClass,
  OrderDirection,
  OrderStatusFilter,
  PageSize,
  QuoteAccuracy,
  RepayWithSupplyKind,
  ReserveHoldersFilter,
  ReservesRequestFilter,
  StableVaultClaimStatus,
  SupplySwapKind,
  SwapActivityStatus,
  SwapOrderClass,
  SwapStatusFilter,
  TimeWindow,
  TokenCategory,
  TokenMovementStatus,
  TokenSwapKind,
  UserPositionConditionsUpdate,
  WithdrawSwapKind,
} from './enums';
import type { introspection } from './graphql-env';
import type {
  AssetId,
  BoostedRateId,
  HubAssetId,
  HubId,
  ID,
  OnChainHubAssetId,
  OnChainReserveId,
  OrderId,
  OrderQuoteId,
  ReserveId,
  RewardId,
  SpokeId,
  StableVaultId,
  StableVaultUserPositionId,
  StableVaultWithdrawClaimId,
  SwapId,
  SwapQuoteId,
  TokenInfoId,
  TokenMovementId,
  UserBalanceId,
  UserBorrowItemId,
  UserPositionId,
  UserSupplyItemId,
} from './id';

export type { FragmentOf, ResultOf, VariablesOf } from 'gql.tada';

export const graphql = initGraphQLTada<{
  disableMasking: true;
  introspection: introspection;
  scalars: {
    ActivityType: ActivityType;
    AlwaysTrue: true;
    ApyMetric: ApyMetric;
    AssetId: AssetId;
    BigDecimal: BigDecimal;
    BigInt: bigint;
    BlockchainData: BlockchainData;
    Boolean: boolean;
    BoostedRateId: BoostedRateId;
    BorrowSwapKind: BorrowSwapKind;
    ChainId: ChainId;
    ChainsFilter: ChainsFilter;
    CollateralMetric: CollateralMetric;
    Currency: Currency;
    RepayWithSupplyKind: RepayWithSupplyKind;
    Cursor: Cursor;
    DateTime: Date;
    EvmAddress: EvmAddress;
    Float: number;
    HealthFactor: BigDecimal;
    HubAssetId: HubAssetId;
    HubId: HubId;
    ID: ID;
    Int: number;
    JSON: JsonObject;
    OnChainHubAssetId: OnChainHubAssetId;
    OnChainReserveId: OnChainReserveId;
    OperationType: OperationType;
    OrderClass: OrderClass;
    OrderDirection: OrderDirection;
    OrderId: OrderId;
    OrderQuoteId: OrderQuoteId;
    OrderStatusFilter: OrderStatusFilter;
    PageSize: PageSize;
    QuoteAccuracy: QuoteAccuracy;
    ReserveHoldersFilter: ReserveHoldersFilter;
    ReserveId: ReserveId;
    ReservesRequestFilter: ReservesRequestFilter;
    RewardId: RewardId;
    Signature: Signature;
    SpokeId: SpokeId;
    String: string;
    SupplySwapKind: SupplySwapKind;
    StableVaultClaimStatus: StableVaultClaimStatus;
    StableVaultId: StableVaultId;
    StableVaultUserPositionId: StableVaultUserPositionId;
    StableVaultWithdrawClaimId: StableVaultWithdrawClaimId;
    SwapActivityStatus: SwapActivityStatus;
    SwapId: SwapId;
    SwapOrderClass: SwapOrderClass;
    SwapQuoteId: SwapQuoteId;
    SwapStatusFilter: SwapStatusFilter;
    TimeWindow: TimeWindow;
    TokenCategory: TokenCategory;
    TokenInfoId: TokenInfoId;
    TokenMovementId: TokenMovementId;
    TokenMovementStatus: TokenMovementStatus;
    TokenSwapKind: TokenSwapKind;
    TxHash: TxHash;
    UserBalanceId: UserBalanceId;
    UserBorrowItemId: UserBorrowItemId;
    UserPositionConditionsUpdate: UserPositionConditionsUpdate;
    UserPositionId: UserPositionId;
    UserSupplyItemId: UserSupplyItemId;
    Void: Void;
    WithdrawSwapKind: WithdrawSwapKind;
  };
}>();

/**
 * @internal
 */
export type RequestOf<Document> = Document extends DocumentDecoration<
  unknown,
  infer Variables
>
  ? Variables extends { request: infer Request }
    ? Request
    : never
  : never;

/**
 * @internal
 */
export type FragmentDocumentFor<
  TGqlNode extends AnySelectionSet,
  TTypename extends string = TGqlNode extends TypedSelectionSet<infer TTypename>
    ? TTypename
    : never,
  TFragmentName extends string = TTypename,
> = TadaDocumentNode<
  TGqlNode,
  AnyVariables,
  {
    fragment: TFragmentName;
    on: TTypename;
    masked: false;
  }
>;
