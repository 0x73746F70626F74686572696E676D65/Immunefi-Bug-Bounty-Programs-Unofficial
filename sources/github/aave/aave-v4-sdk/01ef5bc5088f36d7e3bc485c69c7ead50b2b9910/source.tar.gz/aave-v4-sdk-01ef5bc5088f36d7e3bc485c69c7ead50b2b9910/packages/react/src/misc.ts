import type { CurrencyQueryOptions } from '@aave/client';
import { exchangeRate, chain as fetchChain } from '@aave/client/actions';
import type { UnexpectedError } from '@aave/core';
import type {
  ChainDetails,
  ExchangeAmount,
  ExchangeRateRequest,
} from '@aave/graphql';
import {
  type ActivityItem,
  ChainQuery,
  type ChainRequest,
  ChainsFilter,
  ChainsQuery,
  type ChainsRequest,
  ExchangeRateQuery,
  type NativeAmount,
  type PreviewAction,
} from '@aave/graphql';
import type { NullishDeep, Prettify } from '@aave/types';
import { useAaveClient } from './context';
import {
  type Pausable,
  type PausableReadResult,
  type PausableSuspenseResult,
  type ReadResult,
  type Suspendable,
  type SuspendableResult,
  type SuspenseResult,
  useSuspendableQuery,
} from './helpers';
import { type UseAsyncTask, useAsyncTask } from './helpers/tasks';

export type UseChainArgs = ChainRequest;

/**
 * Fetch a specific chain by chain ID.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useChain({
 *   chainId: chainId(1),
 *   suspense: true,
 * });
 * // data will be ChainDetails | null
 * ```
 */
export function useChain(
  args: UseChainArgs & Suspendable,
): SuspenseResult<ChainDetails | null>;
/**
 * Fetch a specific chain by chain ID.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useChain({
 *   chainId: chainId(1),
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useChain(
  args: Pausable<UseChainArgs> & Suspendable,
): PausableSuspenseResult<ChainDetails | null>;
/**
 * Fetch a specific chain by chain ID.
 *
 * ```tsx
 * const { data, error, loading } = useChain({
 *   chainId: chainId(1),
 * });
 * // data will be ChainDetails | null
 * ```
 */
export function useChain(args: UseChainArgs): ReadResult<ChainDetails | null>;
/**
 * Fetch a specific chain by chain ID.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useChain({
 *   chainId: chainId(1),
 *   pause: true,
 * });
 * ```
 */
export function useChain(
  args: Pausable<UseChainArgs>,
): PausableReadResult<ChainDetails | null>;

export function useChain({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseChainArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<ChainDetails | null, UnexpectedError> {
  return useSuspendableQuery({
    document: ChainQuery,
    variables: {
      request,
    },
    suspense,
    pause,
  });
}

/**
 * Low-level hook to execute a {@link chain} action directly.
 *
 * @experimental This hook is experimental and may be subject to breaking changes.
 * @remarks
 * This hook **does not** actively watch for updated data on the chain.
 * Use this hook to retrieve data on demand as part of a larger workflow
 * (e.g., in an event handler in order to move to the next step).
 *
 * ```ts
 * const [execute, { called, data, error, loading }] = useChainAction();
 *
 * // …
 *
 * const result = await execute({
 *   chainId: chainId(1),
 * });
 *
 * if (result.isOk()) {
 *   console.log(result.value); // ChainDetails | null
 * } else {
 *   console.error(result.error);
 * }
 * ```
 */
export function useChainAction(): UseAsyncTask<
  ChainRequest,
  ChainDetails | null,
  UnexpectedError
> {
  const client = useAaveClient();

  return useAsyncTask(
    (request: ChainRequest) =>
      fetchChain(client, request, {
        batch: false,
        requestPolicy: 'cache-first',
      }),
    [client],
  );
}

export type UseChainsArgs = ChainsRequest;
/**
 * Fetches the list of supported chains.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useChains({
 *   query: { filter: ChainsFilter.ALL },
 *   suspense: true,
 * });
 * ```
 */
export function useChains(
  args: UseChainsArgs & Suspendable,
): SuspenseResult<ChainDetails[]>;
/**
 * Fetches the list of supported chains.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useChains({
 *   query: { filter: ChainsFilter.ALL },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useChains(
  args: Pausable<UseChainsArgs> & Suspendable,
): PausableSuspenseResult<ChainDetails[]>;
/**
 * Fetches the list of supported chains.
 *
 * ```tsx
 * const { data, error, loading } = useChains({
 *   query: { filter: ChainsFilter.ALL },
 * });
 * ```
 */
export function useChains(args?: UseChainsArgs): ReadResult<ChainDetails[]>;
/**
 * Fetches the list of supported chains.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useChains({
 *   query: { filter: ChainsFilter.ALL },
 *   pause: true,
 * });
 * ```
 */
export function useChains(
  args?: Pausable<UseChainsArgs>,
): PausableReadResult<ChainDetails[]>;

export function useChains(
  {
    suspense = false,
    pause = false,
    ...request
  }: NullishDeep<UseChainsArgs> & {
    suspense?: boolean;
    pause?: boolean;
  } = { query: { filter: ChainsFilter.ALL } },
): SuspendableResult<ChainDetails[], UnexpectedError> {
  return useSuspendableQuery({
    document: ChainsQuery,
    variables: { request },
    suspense,
    pause,
  });
}

/**
 * Fetches exchange rates between tokens and fiat currencies.
 *
 * ```tsx
 * const [getExchangeRate, gettingRate] = useExchangeRateAction();
 *
 * const loading = gettingRate.loading;
 * const error = gettingRate.error;
 *
 * // …
 *
 * const result = await getExchangeRate({
 *   from: { erc20: { chainId: chainId(1), address: evmAddress('0xA0b86a33E6...') } },
 *   to: Currency.Usd,
 * });
 *
 * if (result.isErr()) {
 *   console.error(result.error);
 *   return;
 * }
 *
 * console.log('Exchange rate:', result.value);
 * ```
 */
export function useExchangeRateAction(): UseAsyncTask<
  ExchangeRateRequest,
  ExchangeAmount,
  UnexpectedError
> {
  const client = useAaveClient();

  return useAsyncTask(
    (request: ExchangeRateRequest) =>
      exchangeRate(client, request, { requestPolicy: 'network-only' }),
    [client],
  );
}

export type UseExchangeRateArgs = ExchangeRateRequest;

/**
 * Fetches exchange rates between tokens and fiat currencies with automatic polling.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useExchangeRate({
 *   from: {
 *     erc20: {
 *       chainId: chainId(1),
 *       address: evmAddress('0xA0b86a33E6...')
 *     }
 *   },
 *   to: Currency.Usd,
 *   suspense: true,
 * });
 * ```
 */
export function useExchangeRate(
  args: UseExchangeRateArgs & Suspendable,
): SuspenseResult<ExchangeAmount>;
/**
 * Fetches exchange rates between tokens and fiat currencies with automatic polling.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useExchangeRate({
 *   from: {
 *     erc20: {
 *       chainId: chainId(1),
 *       address: evmAddress('0xA0b86a33E6...')
 *     }
 *   },
 *   to: Currency.Usd,
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useExchangeRate(
  args: Pausable<UseExchangeRateArgs> & Suspendable,
): PausableSuspenseResult<ExchangeAmount>;
/**
 * Fetches exchange rates between tokens and fiat currencies with automatic polling.
 *
 * ```tsx
 * const { data, error, loading } = useExchangeRate({
 *   from: {
 *     erc20: {
 *       chainId: chainId(1),
 *       address: evmAddress('0xA0b86a33E6...')
 *     }
 *   },
 *   to: Currency.Usd,
 * });
 *
 * <Component value={somewhere} fxRate={data} />
 * ```
 */
export function useExchangeRate(
  args: UseExchangeRateArgs,
): ReadResult<ExchangeAmount>;
/**
 * Fetches exchange rates between tokens and fiat currencies with automatic polling.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useExchangeRate({
 *   from: {
 *     erc20: {
 *       chainId: chainId(1),
 *       address: evmAddress('0xA0b86a33E6...')
 *     }
 *   },
 *   to: Currency.Usd,
 *   pause: true,
 * });
 * ```
 */
export function useExchangeRate(
  args: Pausable<UseExchangeRateArgs>,
): PausableReadResult<ExchangeAmount>;

export function useExchangeRate({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseExchangeRateArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<ExchangeAmount, UnexpectedError> {
  const client = useAaveClient();

  return useSuspendableQuery({
    document: ExchangeRateQuery,
    variables: { request },
    suspense,
    pause,
    pollInterval: request.at
      ? 0
      : client.context.environment.exchangeRateInterval,
  });
}

export type UseNetworkFeeRequestQuery =
  | {
      activity: ActivityItem;
    }
  | {
      estimate: PreviewAction;
    };

export type UseNetworkFeeArgs = Prettify<
  {
    query: UseNetworkFeeRequestQuery;
  } & CurrencyQueryOptions
>;

type PausableUseNetworkFeeArgs = Partial<
  {
    query: Partial<UseNetworkFeeRequestQuery>;
  } & CurrencyQueryOptions
>;

/**
 * Fetch the network fee for an ActivityItem.
 *
 * @experimental This hook is experimental and may be subject to breaking changes.
 */
export type UseNetworkFee<T extends NativeAmount = NativeAmount> =
  /**
   * Fetches the network fee for a past ActivityItem.
   *
   * This signature supports React Suspense:
   *
   * ```tsx
   * const { data } = useNetworkFee({
   *   query: { activity },
   *   suspense: true,
   * });
   *
   * data: NativeAmount
   * ```
   */
  ((args: UseNetworkFeeArgs & Suspendable) => SuspenseResult<T>) &
    /**
     * Fetches the network fee for a past ActivityItem.
     *
     * Pausable suspense mode.
     *
     * ```tsx
     * const { data, paused } = useNetworkFee({
     *   query: { activity },
     *   suspense: true,
     *   pause: true,
     * });
     *
     * data: NativeAmount | undefined
     * ```
     */
    ((
      args: Pausable<UseNetworkFeeArgs, PausableUseNetworkFeeArgs> &
        Suspendable,
    ) => PausableSuspenseResult<T>) &
    /**
     * Fetches the network fee for a past ActivityItem.
     *
     * ```tsx
     * const { data, error, loading } = useNetworkFee({
     *   query: { activity },
     * });
     * ```
     */
    ((args: UseNetworkFeeArgs) => ReadResult<T>) &
    /**
     * Fetches the network fee for a past ActivityItem.
     *
     * Pausable loading state mode.
     *
     * ```tsx
     * const { data, error, loading, paused } = useNetworkFee({
     *   query: { activity },
     *   pause: true,
     * });
     *
     * data: NativeAmount | undefined
     * ```
     */
    ((
      args: Pausable<UseNetworkFeeArgs, PausableUseNetworkFeeArgs>,
    ) => PausableReadResult<T>);
