import {
  type CurrencyQueryOptions,
  DEFAULT_QUERY_OPTIONS,
  type TimeWindowQueryOptions,
  type UnexpectedError,
} from '@aave/client';
import {
  type Asset,
  AssetBorrowHistoryQuery,
  type AssetBorrowHistoryRequest,
  type AssetBorrowSample,
  AssetPriceHistoryQuery,
  type AssetPriceHistoryRequest,
  type AssetPriceSample,
  AssetQuery,
  type AssetRequest,
  AssetSupplyHistoryQuery,
  type AssetSupplyHistoryRequest,
  type AssetSupplySample,
  type MultichainAsset,
  MultichainAssetQuery,
  type MultichainAssetRequest,
  ProtocolHistoryQuery,
  type ProtocolHistoryRequest,
  type ProtocolHistorySample,
} from '@aave/graphql';
import type { NullishDeep, Prettify } from '@aave/types';
import {
  type Pausable,
  type PausableReadResult,
  type PausableSuspenseResult,
  type ReadResult,
  type Suspendable,
  type SuspendableResult,
  type SuspenseResult,
  useSuspendableQuery,
} from './helpers';

export type UseAssetArgs = Prettify<
  AssetRequest & CurrencyQueryOptions & TimeWindowQueryOptions
>;

/**
 * Fetch information about a specific asset (ERC20 token) in the protocol by ID or by token.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useAsset({
 *   query: { assetId: assetId('SGVsbG8h') },
 *   suspense: true,
 * });
 * // data will be Asset | null
 * ```
 */
export function useAsset(
  args: UseAssetArgs & Suspendable,
): SuspenseResult<Asset | null>;
/**
 * Fetch information about a specific asset (ERC20 token) in the protocol by ID or by token.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useAsset({
 *   query: { assetId: assetId('SGVsbG8h') },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useAsset(
  args: Pausable<UseAssetArgs> & Suspendable,
): PausableSuspenseResult<Asset | null>;
/**
 * Fetch information about a specific asset (ERC20 token) in the protocol by ID or by token.
 *
 * ```tsx
 * const { data, error, loading } = useAsset({
 *   query: { assetId: assetId('SGVsbG8h') },
 * });
 * // data will be Asset | null
 * ```
 */
export function useAsset(args: UseAssetArgs): ReadResult<Asset | null>;
/**
 * Fetch information about a specific asset (ERC20 token) in the protocol by ID or by token.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useAsset({
 *   query: { assetId: assetId('SGVsbG8h') },
 *   pause: true,
 * });
 * ```
 */
export function useAsset(
  args: Pausable<UseAssetArgs>,
): PausableReadResult<Asset | null>;

export function useAsset({
  suspense = false,
  pause = false,
  currency = DEFAULT_QUERY_OPTIONS.currency,
  timeWindow = DEFAULT_QUERY_OPTIONS.timeWindow,
  ...request
}: NullishDeep<UseAssetArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<Asset | null, UnexpectedError> {
  return useSuspendableQuery({
    document: AssetQuery,
    variables: {
      request,
      currency,
      timeWindow,
    },
    suspense,
    pause,
  });
}

export type UseMultichainAssetArgs = Prettify<
  MultichainAssetRequest & CurrencyQueryOptions & TimeWindowQueryOptions
>;

/**
 * Fetch information about an asset (ERC20 token) aggregated across multiple chains,
 * matched by its token info ID or symbol.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useMultichainAsset({
 *   query: { symbol: 'USDC' },
 *   suspense: true,
 * });
 * // data will be MultichainAsset
 * ```
 */
export function useMultichainAsset(
  args: UseMultichainAssetArgs & Suspendable,
): SuspenseResult<MultichainAsset>;
/**
 * Fetch information about an asset (ERC20 token) aggregated across multiple chains,
 * matched by its token info ID or symbol.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useMultichainAsset({
 *   query: { symbol: 'USDC' },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useMultichainAsset(
  args: Pausable<UseMultichainAssetArgs> & Suspendable,
): PausableSuspenseResult<MultichainAsset>;
/**
 * Fetch information about an asset (ERC20 token) aggregated across multiple chains,
 * matched by its token info ID or symbol.
 *
 * ```tsx
 * const { data, error, loading } = useMultichainAsset({
 *   query: { symbol: 'USDC' },
 * });
 * // data will be MultichainAsset
 * ```
 */
export function useMultichainAsset(
  args: UseMultichainAssetArgs,
): ReadResult<MultichainAsset>;
/**
 * Fetch information about an asset (ERC20 token) aggregated across multiple chains,
 * matched by its token info ID or symbol.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useMultichainAsset({
 *   query: { symbol: 'USDC' },
 *   pause: true,
 * });
 * ```
 */
export function useMultichainAsset(
  args: Pausable<UseMultichainAssetArgs>,
): PausableReadResult<MultichainAsset>;

export function useMultichainAsset({
  suspense = false,
  pause = false,
  currency = DEFAULT_QUERY_OPTIONS.currency,
  timeWindow = DEFAULT_QUERY_OPTIONS.timeWindow,
  ...request
}: NullishDeep<UseMultichainAssetArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<MultichainAsset, UnexpectedError> {
  return useSuspendableQuery({
    document: MultichainAssetQuery,
    variables: {
      request,
      currency,
      timeWindow,
    },
    suspense,
    pause,
  });
}

export type UseAssetPriceHistoryArgs = AssetPriceHistoryRequest;

/**
 * Fetch historical price data for a specific asset.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useAssetPriceHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 *   suspense: true,
 * });
 * ```
 */
export function useAssetPriceHistory(
  args: UseAssetPriceHistoryArgs & Suspendable,
): SuspenseResult<AssetPriceSample[]>;
/**
 * Fetch historical price data for a specific asset.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useAssetPriceHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useAssetPriceHistory(
  args: Pausable<UseAssetPriceHistoryArgs> & Suspendable,
): PausableSuspenseResult<AssetPriceSample[]>;
/**
 * Fetch historical price data for a specific asset.
 *
 * ```tsx
 * const { data, error, loading } = useAssetPriceHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 * });
 * ```
 */
export function useAssetPriceHistory(
  args: UseAssetPriceHistoryArgs,
): ReadResult<AssetPriceSample[]>;
/**
 * Fetch historical price data for a specific asset.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useAssetPriceHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   pause: true,
 * });
 * ```
 */
export function useAssetPriceHistory(
  args: Pausable<UseAssetPriceHistoryArgs>,
): PausableReadResult<AssetPriceSample[]>;

export function useAssetPriceHistory({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseAssetPriceHistoryArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<AssetPriceSample[], UnexpectedError> {
  return useSuspendableQuery({
    document: AssetPriceHistoryQuery,
    variables: {
      request,
    },
    suspense,
    pause,
    batch: false, // Do not batch this since it's a slower than average query
  });
}

export type UseAssetSupplyHistoryArgs = Prettify<
  AssetSupplyHistoryRequest & CurrencyQueryOptions & TimeWindowQueryOptions
>;

/**
 * Fetch historical supply data for a specific asset.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useAssetSupplyHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   window: TimeWindow.LastWeek,
 *   suspense: true,
 * });
 * ```
 */
export function useAssetSupplyHistory(
  args: UseAssetSupplyHistoryArgs & Suspendable,
): SuspenseResult<AssetSupplySample[]>;
/**
 * Fetch historical supply data for a specific asset.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useAssetSupplyHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useAssetSupplyHistory(
  args: Pausable<UseAssetSupplyHistoryArgs> & Suspendable,
): PausableSuspenseResult<AssetSupplySample[]>;
/**
 * Fetch historical supply data for a specific asset.
 *
 * ```tsx
 * const { data, error, loading } = useAssetSupplyHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   window: TimeWindow.LastWeek,
 * });
 * ```
 */
export function useAssetSupplyHistory(
  args: UseAssetSupplyHistoryArgs,
): ReadResult<AssetSupplySample[]>;
/**
 * Fetch historical supply data for a specific asset.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useAssetSupplyHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   pause: true,
 * });
 * ```
 */
export function useAssetSupplyHistory(
  args: Pausable<UseAssetSupplyHistoryArgs>,
): PausableReadResult<AssetSupplySample[]>;

export function useAssetSupplyHistory({
  suspense = false,
  pause = false,
  currency = DEFAULT_QUERY_OPTIONS.currency,
  timeWindow = DEFAULT_QUERY_OPTIONS.timeWindow,
  ...request
}: NullishDeep<UseAssetSupplyHistoryArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<AssetSupplySample[], UnexpectedError> {
  return useSuspendableQuery({
    document: AssetSupplyHistoryQuery,
    variables: {
      request,
      currency,
      timeWindow,
    },
    suspense,
    pause,
    batch: false, // Do not batch this since it's a slower than average query
  });
}

export type UseAssetBorrowHistoryArgs = Prettify<
  AssetBorrowHistoryRequest & CurrencyQueryOptions & TimeWindowQueryOptions
>;

/**
 * Fetch historical borrow data for a specific asset.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useAssetBorrowHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   window: TimeWindow.LastWeek,
 *   suspense: true,
 * });
 * ```
 */
export function useAssetBorrowHistory(
  args: UseAssetBorrowHistoryArgs & Suspendable,
): SuspenseResult<AssetBorrowSample[]>;
/**
 * Fetch historical borrow data for a specific asset.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useAssetBorrowHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useAssetBorrowHistory(
  args: Pausable<UseAssetBorrowHistoryArgs> & Suspendable,
): PausableSuspenseResult<AssetBorrowSample[]>;
/**
 * Fetch historical borrow data for a specific asset.
 *
 * ```tsx
 * const { data, error, loading } = useAssetBorrowHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   window: TimeWindow.LastWeek,
 * });
 * ```
 */
export function useAssetBorrowHistory(
  args: UseAssetBorrowHistoryArgs,
): ReadResult<AssetBorrowSample[]>;
/**
 * Fetch historical borrow data for a specific asset.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useAssetBorrowHistory({
 *   token: { chainId: chainId(1), address: evmAddress('0x123...') },
 *   pause: true,
 * });
 * ```
 */
export function useAssetBorrowHistory(
  args: Pausable<UseAssetBorrowHistoryArgs>,
): PausableReadResult<AssetBorrowSample[]>;

export function useAssetBorrowHistory({
  suspense = false,
  pause = false,
  currency = DEFAULT_QUERY_OPTIONS.currency,
  timeWindow = DEFAULT_QUERY_OPTIONS.timeWindow,
  ...request
}: NullishDeep<UseAssetBorrowHistoryArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<AssetBorrowSample[], UnexpectedError> {
  return useSuspendableQuery({
    document: AssetBorrowHistoryQuery,
    variables: {
      request,
      currency,
      timeWindow,
    },
    suspense,
    pause,
    batch: false, // Do not batch this since it's a slower than average query
  });
}

export type UseProtocolHistoryArgs = ProtocolHistoryRequest;

/**
 * Fetch historical protocol-wide data (deposits, borrows, earnings).
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useProtocolHistory({
 *   chainIds: [chainId(1), chainId(137)],
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 *   suspense: true,
 * });
 * ```
 */
export function useProtocolHistory(
  args: UseProtocolHistoryArgs & Suspendable,
): SuspenseResult<ProtocolHistorySample[]>;
/**
 * Fetch historical protocol-wide data (deposits, borrows, earnings).
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useProtocolHistory({
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useProtocolHistory(
  args: Pausable<UseProtocolHistoryArgs> & Suspendable,
): PausableSuspenseResult<ProtocolHistorySample[]>;
/**
 * Fetch historical protocol-wide data (deposits, borrows, earnings).
 *
 * ```tsx
 * const { data, error, loading } = useProtocolHistory({
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 * });
 * ```
 */
export function useProtocolHistory(
  args: UseProtocolHistoryArgs,
): ReadResult<ProtocolHistorySample[]>;
/**
 * Fetch historical protocol-wide data (deposits, borrows, earnings).
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useProtocolHistory({
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 *   pause: true,
 * });
 * ```
 */
export function useProtocolHistory(
  args: Pausable<UseProtocolHistoryArgs>,
): PausableReadResult<ProtocolHistorySample[]>;

export function useProtocolHistory({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseProtocolHistoryArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<ProtocolHistorySample[], UnexpectedError> {
  return useSuspendableQuery({
    document: ProtocolHistoryQuery,
    variables: {
      request,
    },
    suspense,
    pause,
    batch: false, // Do not batch this since it's a slower than average query
  });
}
