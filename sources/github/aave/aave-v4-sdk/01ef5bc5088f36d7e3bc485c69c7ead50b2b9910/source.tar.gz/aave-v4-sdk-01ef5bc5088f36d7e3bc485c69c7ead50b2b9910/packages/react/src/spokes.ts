import {
  type CurrencyQueryOptions,
  DEFAULT_QUERY_OPTIONS,
  type TimeWindowQueryOptions,
  type UnexpectedError,
} from '@aave/client';
import {
  type PaginatedSpokePositionManagerResult,
  type PaginatedSpokeUserPositionManagerResult,
  type Spoke,
  SpokePositionManagersQuery,
  type SpokePositionManagersRequest,
  SpokeQuery,
  type SpokeRequest,
  SpokeSummaryHistoryQuery,
  type SpokeSummaryHistoryRequest,
  type SpokeSummarySample,
  SpokesQuery,
  type SpokesRequest,
  SpokeUserPositionManagersQuery,
  type SpokeUserPositionManagersRequest,
} from '@aave/graphql';
import type { NullishDeep, Prettify } from '@aave/types';
import {
  type Pausable,
  type PausableReadResult,
  type PausableSuspenseResult,
  type ReadResult,
  type Suspendable,
  type SuspendableResult,
  type SuspenseResult,
  useSuspendableQuery,
} from './helpers';

export type UseSpokeArgs = Prettify<
  SpokeRequest & CurrencyQueryOptions & TimeWindowQueryOptions
>;

/**
 * Fetch a specific spoke.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useSpoke({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   suspense: true,
 * });
 * // data will be Spoke | null
 * ```
 */
export function useSpoke(
  args: UseSpokeArgs & Suspendable,
): SuspenseResult<Spoke | null>;
/**
 * Fetch a specific spoke.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useSpoke({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useSpoke(
  args: Pausable<UseSpokeArgs> & Suspendable,
): PausableSuspenseResult<Spoke | null>;
/**
 * Fetch a specific spoke.
 *
 * ```tsx
 * const { data, error, loading } = useSpoke({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 * });
 * // data will be Spoke | null
 * ```
 */
export function useSpoke(args: UseSpokeArgs): ReadResult<Spoke | null>;
/**
 * Fetch a specific spoke.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useSpoke({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   pause: true,
 * });
 * ```
 */
export function useSpoke(
  args: Pausable<UseSpokeArgs>,
): PausableReadResult<Spoke | null>;

export function useSpoke({
  suspense = false,
  pause = false,
  currency = DEFAULT_QUERY_OPTIONS.currency,
  timeWindow = DEFAULT_QUERY_OPTIONS.timeWindow,
  ...request
}: NullishDeep<UseSpokeArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<Spoke | null, UnexpectedError> {
  return useSuspendableQuery({
    document: SpokeQuery,
    variables: {
      request,
      currency,
      timeWindow,
    },
    suspense,
    pause,
  });
}

export type UseSpokesArgs = Prettify<
  SpokesRequest & CurrencyQueryOptions & TimeWindowQueryOptions
>;

/**
 * Fetch spokes based on specified criteria.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useSpokes({
 *   query: { chainIds: [chainId(1)] },
 *   suspense: true,
 * });
 * ```
 */
export function useSpokes(
  args: UseSpokesArgs & Suspendable,
): SuspenseResult<Spoke[]>;
/**
 * Fetch spokes based on specified criteria.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useSpokes({
 *   query: { chainIds: [chainId(1)] },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useSpokes(
  args: Pausable<UseSpokesArgs> & Suspendable,
): PausableSuspenseResult<Spoke[]>;
/**
 * Fetch spokes based on specified criteria.
 *
 * ```tsx
 * const { data, error, loading } = useSpokes({
 *   query: { chainIds: [chainId(1)] },
 * });
 * ```
 */
export function useSpokes(args: UseSpokesArgs): ReadResult<Spoke[]>;
/**
 * Fetch spokes based on specified criteria.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useSpokes({
 *   query: { chainIds: [chainId(1)] },
 *   pause: true,
 * });
 * ```
 */
export function useSpokes(
  args: Pausable<UseSpokesArgs>,
): PausableReadResult<Spoke[]>;

export function useSpokes({
  suspense = false,
  pause = false,
  currency = DEFAULT_QUERY_OPTIONS.currency,
  timeWindow = DEFAULT_QUERY_OPTIONS.timeWindow,
  ...request
}: NullishDeep<UseSpokesArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<Spoke[], UnexpectedError> {
  return useSuspendableQuery({
    document: SpokesQuery,
    variables: {
      request,
      currency,
      timeWindow,
    },
    suspense,
    pause,
  });
}

export type UseSpokePositionManagersArgs = SpokePositionManagersRequest;

/**
 * Fetches all the positions manager for a specific spoke.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useSpokePositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   suspense: true,
 * });
 * ```
 */
export function useSpokePositionManagers(
  args: UseSpokePositionManagersArgs & Suspendable,
): SuspenseResult<PaginatedSpokePositionManagerResult>;
/**
 * Fetches all the positions manager for a specific spoke.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useSpokePositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useSpokePositionManagers(
  args: Pausable<UseSpokePositionManagersArgs> & Suspendable,
): PausableSuspenseResult<PaginatedSpokePositionManagerResult>;
/**
 * Fetches all the positions manager for a specific spoke.
 *
 * ```tsx
 * const { data, error, loading } = useSpokePositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 * });
 * ```
 */
export function useSpokePositionManagers(
  args: UseSpokePositionManagersArgs,
): ReadResult<PaginatedSpokePositionManagerResult>;
/**
 * Fetches all the positions manager for a specific spoke.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useSpokePositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   pause: true,
 * });
 * ```
 */
export function useSpokePositionManagers(
  args: Pausable<UseSpokePositionManagersArgs>,
): PausableReadResult<PaginatedSpokePositionManagerResult>;

export function useSpokePositionManagers({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseSpokePositionManagersArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<PaginatedSpokePositionManagerResult, UnexpectedError> {
  return useSuspendableQuery({
    document: SpokePositionManagersQuery,
    variables: {
      request,
    },
    suspense,
    pause,
  });
}

export type UseSpokeSummaryHistoryArgs = SpokeSummaryHistoryRequest;

/**
 * Fetch historical summary data for a specific spoke.
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useSpokeSummaryHistory({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 *   suspense: true,
 * });
 * ```
 */
export function useSpokeSummaryHistory(
  args: UseSpokeSummaryHistoryArgs & Suspendable,
): SuspenseResult<SpokeSummarySample[]>;
/**
 * Fetch historical summary data for a specific spoke.
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useSpokeSummaryHistory({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useSpokeSummaryHistory(
  args: Pausable<UseSpokeSummaryHistoryArgs> & Suspendable,
): PausableSuspenseResult<SpokeSummarySample[]>;
/**
 * Fetch historical summary data for a specific spoke.
 *
 * ```tsx
 * const { data, error, loading } = useSpokeSummaryHistory({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   currency: Currency.Usd,
 *   window: TimeWindow.LastWeek,
 * });
 * ```
 */
export function useSpokeSummaryHistory(
  args: UseSpokeSummaryHistoryArgs,
): ReadResult<SpokeSummarySample[]>;
/**
 * Fetch historical summary data for a specific spoke.
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useSpokeSummaryHistory({
 *   query: { spokeId: spokeId('SGVsbG8h') },
 *   pause: true,
 * });
 * ```
 */
export function useSpokeSummaryHistory(
  args: Pausable<UseSpokeSummaryHistoryArgs>,
): PausableReadResult<SpokeSummarySample[]>;

export function useSpokeSummaryHistory({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseSpokeSummaryHistoryArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<SpokeSummarySample[], UnexpectedError> {
  return useSuspendableQuery({
    document: SpokeSummaryHistoryQuery,
    variables: {
      request,
    },
    suspense,
    pause,
    batch: false, // Do not batch this since it's a slower than average query
  });
}

export type UseSpokeUserPositionManagersArgs = SpokeUserPositionManagersRequest;

/**
 * Fetches all the position managers of a user for a specific spoke
 *
 * This signature supports React Suspense:
 *
 * ```tsx
 * const { data } = useSpokeUserPositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   user: evmAddress('0x123...'),
 *   suspense: true,
 * });
 * ```
 */
export function useSpokeUserPositionManagers(
  args: UseSpokeUserPositionManagersArgs & Suspendable,
): SuspenseResult<PaginatedSpokeUserPositionManagerResult>;
/**
 * Fetches all the position managers of a user for a specific spoke
 *
 * Pausable suspense mode.
 *
 * ```tsx
 * const { data } = useSpokeUserPositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   user: evmAddress('0x123...'),
 *   suspense: true,
 *   pause: true,
 * });
 * ```
 */
export function useSpokeUserPositionManagers(
  args: Pausable<UseSpokeUserPositionManagersArgs> & Suspendable,
): PausableSuspenseResult<PaginatedSpokeUserPositionManagerResult>;
/**
 * Fetches all the position managers of a user for a specific spoke
 *
 * ```tsx
 * const { data, error, loading } = useSpokeUserPositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   user: evmAddress('0x123...'),
 * });
 * ```
 */
export function useSpokeUserPositionManagers(
  args: UseSpokeUserPositionManagersArgs,
): ReadResult<PaginatedSpokeUserPositionManagerResult>;
/**
 * Fetches all the position managers of a user for a specific spoke
 *
 * Pausable loading state mode.
 *
 * ```tsx
 * const { data, error, loading, paused } = useSpokeUserPositionManagers({
 *   spoke: spokeId('SGVsbG8h'),
 *   user: evmAddress('0x123...'),
 *   pause: true,
 * });
 * ```
 */
export function useSpokeUserPositionManagers(
  args: Pausable<UseSpokeUserPositionManagersArgs>,
): PausableReadResult<PaginatedSpokeUserPositionManagerResult>;

export function useSpokeUserPositionManagers({
  suspense = false,
  pause = false,
  ...request
}: NullishDeep<UseSpokeUserPositionManagersArgs> & {
  suspense?: boolean;
  pause?: boolean;
}): SuspendableResult<
  PaginatedSpokeUserPositionManagerResult,
  UnexpectedError
> {
  return useSuspendableQuery({
    document: SpokeUserPositionManagersQuery,
    variables: {
      request,
    },
    suspense,
    pause,
  });
}
