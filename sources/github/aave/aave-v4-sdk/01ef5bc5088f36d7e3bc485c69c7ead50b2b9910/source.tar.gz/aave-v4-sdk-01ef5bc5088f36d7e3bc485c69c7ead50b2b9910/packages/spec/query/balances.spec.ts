import {
  assertOk,
  bigDecimal,
  evmAddress,
  OrderDirection,
  ResultAsync,
} from '@aave/client';
import { userBalances, userPositions } from '@aave/client/actions';
import {
  client,
  createNewWallet,
  ETHEREUM_1INCH_ADDRESS,
  ETHEREUM_AAVE_ADDRESS,
  ETHEREUM_FORK_ID,
  ETHEREUM_HUB_CORE_ADDRESS,
  ETHEREUM_SPOKE_CORE_ADDRESS,
  ETHEREUM_SPOKE_CORE_ID,
  ETHEREUM_USDC_ADDRESS,
  ETHEREUM_USDT_ADDRESS,
  fundErc20Address,
} from '@aave/client/testing';
import { beforeAll, describe, expect, it } from 'vitest';
import { findReserveAndSupply } from '../helpers/supplyBorrow';
import { assertNonEmptyArray } from '../test-utils';

const user = await createNewWallet(
  '0x0f935f2b7b5a50afff829d59fd42b0e38f84ccb761b84bf510841695853bfe1e',
);

// Get the user balances for the protocol. This will only return assets that can be used on the protocol
describe('Given a user with one supply position and multiple tokens to use on the protocol', () => {
  beforeAll(async () => {
    // NOTE: Remember the wallet also has ETH
    const balances = await userBalances(client, {
      user: evmAddress(user.account.address),
      filter: {
        chains: {
          chainIds: [ETHEREUM_FORK_ID],
        },
      },
      includeZeroBalances: false,
    });
    assertOk(balances);
    if (balances.value.length < 3) {
      const result = await ResultAsync.combine([
        fundErc20Address(evmAddress(user.account.address), {
          address: ETHEREUM_USDC_ADDRESS,
          amount: bigDecimal('100'),
          decimals: 6,
        }),
        fundErc20Address(evmAddress(user.account.address), {
          address: ETHEREUM_1INCH_ADDRESS,
          amount: bigDecimal('100'),
          decimals: 18,
        }),
        fundErc20Address(evmAddress(user.account.address), {
          address: ETHEREUM_USDT_ADDRESS,
          amount: bigDecimal('100'),
          decimals: 6,
        }),
      ]);
      assertOk(result);
      const resultSupply = await findReserveAndSupply(client, user, {
        spoke: ETHEREUM_SPOKE_CORE_ID,
        token: ETHEREUM_AAVE_ADDRESS,
        amount: bigDecimal('1'),
      });
      assertOk(resultSupply);
    }
  }, 60_000);

  describe('When the user queries balances by chain ID', () => {
    it('Then the balances of assets that can be used on the chain are returned', async () => {
      const balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          chains: {
            chainIds: [ETHEREUM_FORK_ID],
          },
        },
      });
      assertOk(balances);
      expect(balances.value.length).toBe(3);
    });
  });

  describe('When the user queries balances by hub', () => {
    it('Then the balances of assets that can be used on the hub are returned', async () => {
      const balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          hub: {
            address: ETHEREUM_HUB_CORE_ADDRESS,
            chainId: ETHEREUM_FORK_ID,
          },
        },
      });
      assertOk(balances);
      // NOTE: One less because 1INCH is not supported on the hub
      expect(balances.value.length).toBe(3);
    });
  });

  describe('When the user queries balances by spoke', () => {
    it('Then the balances of assets that can be used on the spoke are returned', async () => {
      const balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          spoke: {
            address: ETHEREUM_SPOKE_CORE_ADDRESS,
            chainId: ETHEREUM_FORK_ID,
          },
        },
      });
      assertOk(balances);
      // NOTE: One less because 1INCH is not supported on the spoke
      expect(balances.value.length).toBe(3);
    });
  });

  describe('When the user queries balances by tokens', () => {
    it('Then only the balances of the tokens are returned', async () => {
      const balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          tokens: {
            chainTokens: [
              {
                chainId: ETHEREUM_FORK_ID,
                token: {
                  erc20: ETHEREUM_USDC_ADDRESS,
                },
              },
              {
                chainId: ETHEREUM_FORK_ID,
                token: {
                  erc20: ETHEREUM_USDT_ADDRESS,
                },
              },
            ],
          },
        },
      });
      assertOk(balances);
      assertNonEmptyArray(balances.value);
      expect(balances.value.length).toBe(2);
      const symbols = balances.value.map((elem) => elem.info.symbol);
      expect(symbols).toContain('USDC');
      expect(symbols).toContain('USDT');
    });
  });

  describe('When the user queries balances by swappable tokens on a specific chainId', () => {
    it('Then the balances of assets that can be swapped are returned', async () => {
      const balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          swappable: {
            tokens: [
              {
                chainId: ETHEREUM_FORK_ID,
                address: ETHEREUM_USDC_ADDRESS,
              },
              {
                chainId: ETHEREUM_FORK_ID,
                address: ETHEREUM_USDT_ADDRESS,
              },
            ],
          },
        },
      });
      assertOk(balances);
      expect(balances.value.length).toBe(2);
      const symbols = balances.value.map((elem) => elem.info.symbol);
      expect(symbols).toContain('USDC');
      expect(symbols).toContain('USDT');
    });
  });

  describe('When the user queries balances by user position ID', () => {
    it('Then the balances of assets that can be used on the user position are returned', async () => {
      const positions = await userPositions(client, {
        user: evmAddress(user.account.address),
        filter: {
          chainIds: [ETHEREUM_FORK_ID],
        },
      });
      assertOk(positions);
      assertNonEmptyArray(positions.value);
      const balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          userPosition: {
            userPositionId: positions.value[0].id,
          },
        },
      });
      assertOk(balances);
      expect(balances.value.length).toBe(3);
    });
  });

  describe('When the user fetches balances ordered by token name', () => {
    it('Then the balances are returned in order of token name', async () => {
      let balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          chains: {
            chainIds: [ETHEREUM_FORK_ID],
          },
        },
        orderBy: { name: OrderDirection.Desc },
      });
      assertOk(balances);
      let listOrderName = balances.value.map((elem) => elem.info.name);
      expect(listOrderName).toBeSortedAlphabetically('desc');

      balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          chains: {
            chainIds: [ETHEREUM_FORK_ID],
          },
        },
        orderBy: { name: OrderDirection.Asc },
      });
      assertOk(balances);
      listOrderName = balances.value.map((elem) => elem.info.name);
      expect(listOrderName).toBeSortedAlphabetically('asc');
    });
  });

  describe('When the user fetches balances ordered by balance amount', () => {
    it('Then the balances are returned in order of balance amount', async () => {
      let balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          chains: {
            chainIds: [ETHEREUM_FORK_ID],
          },
        },
        orderBy: { balance: OrderDirection.Desc },
      });
      assertOk(balances);
      let listOrderBalance = balances.value.map((elem) =>
        elem.balances.reduce(
          (sum, balance) => sum.plus(balance.exchange.value),
          bigDecimal('0'),
        ),
      );
      expect(listOrderBalance).toBeSortedNumerically('desc');

      balances = await userBalances(client, {
        user: evmAddress(user.account.address),
        filter: {
          chains: {
            chainIds: [ETHEREUM_FORK_ID],
          },
        },
        orderBy: { balance: OrderDirection.Asc },
      });
      assertOk(balances);
      listOrderBalance = balances.value.map((elem) =>
        elem.balances.reduce(
          (sum, balance) => sum.plus(balance.exchange.value),
          bigDecimal('0'),
        ),
      );
      expect(listOrderBalance).toBeSortedNumerically('asc');
    });
  });
});
