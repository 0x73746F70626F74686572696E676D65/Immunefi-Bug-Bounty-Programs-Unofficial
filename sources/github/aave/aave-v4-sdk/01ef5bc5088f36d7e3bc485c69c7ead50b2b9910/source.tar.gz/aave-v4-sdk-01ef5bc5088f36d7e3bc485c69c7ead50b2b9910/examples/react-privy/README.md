# Aave React SDK + Privy Wallet

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/aave/aave-v4-sdk/tree/main/examples/react-privy)
