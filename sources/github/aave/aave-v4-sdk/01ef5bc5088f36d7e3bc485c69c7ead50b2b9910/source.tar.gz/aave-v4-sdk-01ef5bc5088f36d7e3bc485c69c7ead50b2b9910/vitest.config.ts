import { resolve } from 'node:path';
import { loadEnv } from 'vite';
import { defineConfig } from 'vitest/config';

const isCI = process.env.CI === 'true' || process.env.GITHUB_ACTIONS === 'true';

export default defineConfig({
  root: './',
  resolve: {
    tsconfigPaths: true,
  },
  test: {
    fileParallelism: false,
    setupFiles: [resolve(__dirname, './vitest.setup.ts')],
    env: loadEnv('', process.cwd(), ''),
    testTimeout: 30_000,
    hookTimeout: 30_000,
    reporters: isCI
      ? ['json', 'junit', 'default', 'html']
      : ['default', 'html'],
    outputFile: {
      json: 'reports/test-results.json',
      html: 'reports/index.html',
      junit: 'reports/test-results.xml',
    },
    projects: [
      {
        extends: true,
        test: {
          name: 'spec',
          include: ['packages/spec/**/*.spec.ts'],
          environment: 'node',
        },
      },
      {
        extends: true,
        test: {
          name: 'react',
          environment: 'happy-dom',
          environmentOptions: {
            happyDOM: {
              settings: {
                fetch: {
                  disableSameOriginPolicy: true,
                },
              },
            },
          },
          setupFiles: [resolve(__dirname, './packages/react/vitest.setup.ts')],
          include: ['packages/react/**/*.test.{ts,tsx}'],
          typecheck: {
            enabled: true,
            include: ['packages/react/**/*.test-d.ts'],
            tsconfig: 'packages/react/tsconfig.json',
          },
        },
      },
      {
        extends: true,
        test: {
          name: 'cli',
          include: ['packages/cli/**/*.test.ts'],
          environment: 'node',
          disableConsoleIntercept: true, // for oclif tests
          setupFiles: ['tsx/esm'],
        },
      },
      {
        extends: true,
        test: {
          name: 'client',
          include: ['packages/client/**/*.test.ts'],
          environment: 'node',
        },
      },
      {
        extends: true,
        test: {
          name: 'core',
          include: ['packages/core/**/*.test.ts'],
          environment: 'node',
        },
      },
      {
        extends: true,
        test: {
          name: 'types',
          include: ['packages/types/**/*.test.ts'],
          environment: 'node',
          typecheck: {
            enabled: true,
            include: ['packages/types/**/*.test-d.ts'],
            tsconfig: 'packages/types/tsconfig.build.json',
          },
        },
      },
    ],
  },
});
