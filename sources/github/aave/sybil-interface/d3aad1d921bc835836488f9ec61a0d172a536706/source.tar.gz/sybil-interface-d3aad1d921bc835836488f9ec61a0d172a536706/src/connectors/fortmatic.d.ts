declare module 'formatic'
