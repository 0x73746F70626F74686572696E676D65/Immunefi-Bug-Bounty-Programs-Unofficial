# @aave/react

## 0.10.0

### Minor Changes

- b9220ee: Sync GraphQL schema with V3 backend and add the `kind` discriminator on points incentives.

  - `SupplyPointsIncentive` / `BorrowPointsIncentive` now expose `kind: PointsProgramKind!` (`CAMPAIGN` for Merkl-backed programs, `LOYALTY` for fixed-multiplier partner programs like Ethena, Ether.fi). For `LOYALTY`, `dailyPoints` / `pointsPerThousandUsd` are always null.
  - New fragments: `MerklSupplyIncentive`, `MerklBorrowIncentive`, `SupplyPointsIncentive`, `BorrowPointsIncentive`, `IncentiveCriteria`, `PointsProgram`, plus extended Merit fragments (`actionKey`, `rewardTokenAddress`, `rewardTokenSymbol`, `customMessage`, `customForumLink`, `selfApr`).
  - New canonical `userRewards` query (supersedes `userMeritRewards`).
  - `RewardId` scalar mapped to a branded string in `@aave/types`.

- 0384b0f: Add stkGHO migration action support

### Patch Changes

- Updated dependencies [b9220ee]
- Updated dependencies [0384b0f]
  - @aave/graphql@0.13.0
  - @aave/client@0.12.0
  - @aave/types@0.3.0

## 0.9.1

### Patch Changes

- Updated dependencies [4a60cfa]
  - @aave/client@0.11.0

## 0.9.0

### Minor Changes

- dd16c47: **feat:** add sGHO (staked GHO) vault support with GraphQL fragments, client actions, and React hooks

### Patch Changes

- e3b8087: **fix:** polynomial regular expression used on uncontrolled data
- Updated dependencies [dd16c47]
- Updated dependencies [a9ab96f]
- Updated dependencies [e3b8087]
  - @aave/graphql@0.12.0
  - @aave/client@0.10.0

## 0.8.2

### Patch Changes

- Updated dependencies [6135af6]
  - @aave/graphql@0.11.0
  - @aave/client@0.9.2

## 0.8.1

### Patch Changes

- Updated dependencies [c8300e3]
  - @aave/graphql@0.10.0
  - @aave/client@0.9.1

## 0.8.0

### Minor Changes

- d231b4b: exposed unbacked field on the backend and updated the sdk's schema

### Patch Changes

- Updated dependencies [d231b4b]
  - @aave/graphql@0.9.0
  - @aave/client@0.9.0

## 0.7.1

### Patch Changes

- Updated dependencies [75fd88e]
  - @aave/graphql@0.8.0
  - @aave/client@0.8.0

## 0.7.0

### Minor Changes

- 67ee5ad: **chore:** extract core logic into internal @aave/core package

### Patch Changes

- Updated dependencies [67ee5ad]
- Updated dependencies [65cb5b6]
- Updated dependencies [df44eb5]
  - @aave/graphql@0.7.0
  - @aave/client@0.7.0
  - @aave/types@0.2.0

## 0.6.1

### Patch Changes

- 9fbf4bd: **fix:** republish due to CI issue with previous release
- Updated dependencies [9fbf4bd]
  - @aave/client@0.6.1
  - @aave/graphql@0.6.1
  - @aave/types@0.1.1

## 0.6.0

### Minor Changes

- fb93351: **fix:** support for meritClaimRewards query
- 3eef682: **feat:** Add withdraw/deposit/balance sGHO support

### Patch Changes

- 9b756ab: **fix:** error handling in read hooks with suspense enabled
- 3bcb8b2: **fix:** modify sGHO withdraws to support execution plan
- 4365c76: **fix:** avoids invariant error with React hooks that involves not indexed tx
- Updated dependencies [fb93351]
- Updated dependencies [be59081]
- Updated dependencies [3bcb8b2]
- Updated dependencies [4365c76]
- Updated dependencies [3eef682]
  - @aave/graphql@0.6.0
  - @aave/client@0.6.0

## 0.5.0

### Minor Changes

- **feat:** support for vaultUserActivity query

### Patch Changes

- Updated dependencies
  - @aave/graphql@0.5.0
  - @aave/client@0.5.0

## 0.4.0

### Minor Changes

- **feat:** Support new fields for deposit/withdraw in vaults

### Patch Changes

- Updated dependencies
  - @aave/graphql@0.4.0
  - @aave/client@0.4.0

## 0.3.1

### Patch Changes

- Updated dependencies
  - @aave/graphql@0.3.1
  - @aave/client@0.3.1

## 0.3.0

### Minor Changes

- **feat:** support for healthFactorPreview query

### Patch Changes

- Updated dependencies
  - @aave/graphql@0.3.0
  - @aave/client@0.3.0

## 0.2.0

### Minor Changes

- 0e36ce5: **feat:** supports for borrow credit delegation

### Patch Changes

- Updated dependencies [0e36ce5]
  - @aave/graphql@0.2.0
  - @aave/client@0.2.0

## 0.1.0

### Minor Changes

- fb26904: **feat:** first release

### Patch Changes

- Updated dependencies [fb26904]
  - @aave/client@0.1.0
  - @aave/graphql@0.1.0
  - @aave/types@0.1.0
