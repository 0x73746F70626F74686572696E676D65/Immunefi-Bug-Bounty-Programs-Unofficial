// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.0;

import 'tests/Base.t.sol';

contract UnitPriceFeedTest is Base {
  using SafeCast for uint256;

  UnitPriceFeed public unitPriceFeed;

  uint8 private constant _decimals = 8;
  string private constant _description = 'Unit Price Feed (8 decimals)';

  function setUp() public override {
    super.setUp();
    unitPriceFeed = new UnitPriceFeed(_decimals, _description);
  }

  function test_decimals() public view {
    assertEq(unitPriceFeed.decimals(), _decimals);
  }

  function test_description() public view {
    assertEq(unitPriceFeed.description(), _description);
  }

  function test_version() public view {
    assertEq(unitPriceFeed.version(), 1);
  }

  function test_getRoundData() public {
    uint80 _roundId = uint80(vm.randomUint());
    (
      uint80 roundId,
      int256 answer,
      uint256 startedAt,
      uint256 updatedAt,
      uint80 answeredInRound
    ) = unitPriceFeed.getRoundData(_roundId);
    assertEq(roundId, _roundId);
    assertEq(answer, int256(10 ** _decimals));
    assertEq(startedAt, roundId);
    assertEq(updatedAt, roundId);
    assertEq(answeredInRound, roundId);
  }

  function test_fuzz_latestRoundData(uint80 blockTimestamp) public {
    vm.warp(blockTimestamp);
    (
      uint80 roundId,
      int256 answer,
      uint256 startedAt,
      uint256 updatedAt,
      uint80 answeredInRound
    ) = unitPriceFeed.latestRoundData();
    assertEq(roundId, blockTimestamp);
    assertEq(answer, int256(10 ** _decimals));
    assertEq(startedAt, blockTimestamp);
    assertEq(updatedAt, blockTimestamp);
    assertEq(answeredInRound, blockTimestamp);
  }

  function test_fuzz_latestRoundData_DifferentDecimals(uint8 decimals) public {
    decimals = bound(decimals, 0, 18).toUint8();
    unitPriceFeed = new UnitPriceFeed(decimals, _description);
    (, int256 answer, , , ) = unitPriceFeed.latestRoundData();
    assertEq(answer, int256(10 ** decimals));
  }
}
