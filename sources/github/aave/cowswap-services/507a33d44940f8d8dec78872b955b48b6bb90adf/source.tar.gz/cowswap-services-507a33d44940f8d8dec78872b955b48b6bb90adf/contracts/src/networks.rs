pub const MAINNET: u64 = 1;
/// Local anvil fork of mainnet (aave fork). Uses the same deployment addresses
/// as mainnet since it is a fork of it.
pub const MAINNET_FORK: u64 = 123456789;
pub const GNOSIS: u64 = 100;
pub const SEPOLIA: u64 = 11155111;
pub const ARBITRUM_ONE: u64 = 42161;
pub const BASE: u64 = 8453;
pub const POLYGON: u64 = 137;
pub const AVALANCHE: u64 = 43114;
pub const BNB: u64 = 56;
pub const OPTIMISM: u64 = 10;
pub const LINEA: u64 = 59144;
pub const PLASMA: u64 = 9745;
pub const INK: u64 = 57073;
