use {
    crate::{
        boundary,
        domain::blockchain::TxStatus,
        infra::{blockchain::gas::GasPriceParameters, config::file::GasEstimatorType},
    },
    account_balances::{BalanceSimulator, SimulationError},
    alloy::{
        eips::eip1559::Eip1559Estimation,
        network::TransactionBuilder,
        providers::Provider,
        rpc::types::{TransactionReceipt, TransactionRequest},
        transports::TransportErrorKind,
    },
    balance_overrides::{StateOverrides, StateOverriding},
    chain::Chain,
    eth_domain_types as eth,
    ethrpc::{Web3, alloy::ProviderLabelingExt, block_stream::CurrentBlockWatcher},
    gas_price_estimation::{Eip1559EstimationExt, GasPriceEstimating},
    shared::web3,
    std::{fmt, sync::Arc},
    thiserror::Error,
    tracing::{Level, instrument},
    url::Url,
};

pub mod contracts;
pub mod gas;
pub mod token;
pub use self::{contracts::Contracts, gas::GasPriceEstimator};

/// An Ethereum RPC connection.
#[derive(Clone)]
pub struct Rpc {
    web3: Web3,
    chain: Chain,
    args: RpcArgs,
}

#[derive(Clone)]
pub struct RpcArgs {
    pub url: Url,
    pub max_batch_size: usize,
    pub max_concurrent_requests: usize,
}

impl Rpc {
    /// Instantiate an RPC client to an Ethereum (or Ethereum-compatible) node
    /// at the specifed URL.
    pub async fn try_new(args: RpcArgs) -> Result<Self, RpcError> {
        let web3 = web3::web3(
            &web3::Arguments {
                ethrpc_max_batch_size: args.max_batch_size,
                ethrpc_max_concurrent_requests: args.max_concurrent_requests,
                ethrpc_batch_delay: Default::default(),
            },
            &args.url,
            "base",
        );
        let chain = Chain::try_from(web3.provider.get_chain_id().await?)?;

        Ok(Self { web3, chain, args })
    }

    /// Returns the chain for the RPC connection.
    pub fn chain(&self) -> Chain {
        self.chain
    }

    /// Returns a reference to the underlying web3 client.
    pub fn web3(&self) -> &Web3 {
        &self.web3
    }
}

#[derive(Debug, Error)]
pub enum RpcError {
    #[error("alloy transport error: {0:?}")]
    Alloy(#[from] alloy::transports::TransportError),
    #[error("unsupported chain")]
    UnsupportedChain(#[from] chain::ChainIdNotSupported),
}

/// The Ethereum blockchain.
#[derive(Clone)]
pub struct Ethereum {
    web3: Web3,
    inner: Arc<Inner>,
}

struct Inner {
    chain: Chain,
    contracts: Contracts,
    gas: Arc<GasPriceEstimator>,
    current_block: CurrentBlockWatcher,
    balance_simulator: BalanceSimulator,
    state_overrider: Arc<dyn StateOverriding>,
    tx_gas_limit: eth::Gas,
}

impl Ethereum {
    /// Access the Ethereum blockchain through an RPC API.
    ///
    /// # Panics
    ///
    /// Since this type is essential for the program this method will panic on
    /// any initialization error.
    pub async fn new(
        rpc: Rpc,
        addresses: contracts::Addresses,
        current_block_args: &shared::current_block::Arguments,
        tx_gas_limit: eth::Gas,
        gas_estimator_type: &GasEstimatorType,
        gas_adjustments: GasPriceParameters,
    ) -> Self {
        let Rpc { web3, chain, args } = rpc;
        let current_block_stream = current_block_args
            .stream(args.url.clone(), web3.provider.clone())
            .await
            .expect("couldn't initialize current block stream");

        let gas = Arc::new(
            GasPriceEstimator::new(
                &web3.provider,
                &current_block_stream,
                gas_estimator_type,
                gas_adjustments,
            )
            .await
            .expect("initialize gas price estimator"),
        );

        let contracts = Contracts::new(&web3, chain, addresses)
            .await
            .expect("could not initialize important smart contracts");
        let state_overrider = Arc::new(StateOverrides::new(web3.clone()));
        let balance_simulator = BalanceSimulator::new(
            contracts.settlement().clone(),
            contracts.balance_helper().clone(),
            *contracts.vault_relayer(),
            state_overrider.clone(),
        );

        Self {
            inner: Arc::new(Inner {
                current_block: current_block_stream,
                chain,
                contracts,
                gas,
                balance_simulator,
                state_overrider,
                tx_gas_limit,
            }),
            web3,
        }
    }

    pub fn chain(&self) -> Chain {
        self.inner.chain
    }

    pub fn balance_simulator(&self) -> &BalanceSimulator {
        &self.inner.balance_simulator
    }

    pub fn state_overrider(&self) -> Arc<dyn StateOverriding> {
        Arc::clone(&self.inner.state_overrider)
    }

    /// Clones self and returns an instance that captures metrics extended with
    /// the provided label.
    pub fn with_metric_label(&self, label: String) -> Self {
        Self {
            web3: self.web3.labeled(label),
            ..self.clone()
        }
    }

    /// Onchain smart contract bindings.
    pub fn contracts(&self) -> &Contracts {
        &self.inner.contracts
    }

    /// Check if a smart contract is deployed to the given address.
    pub async fn is_contract(&self, address: eth::Address) -> Result<bool, Error> {
        let code = self.web3.provider.get_code_at(address).await?;
        Ok(!code.is_empty())
    }

    /// Returns a type that monitors the block chain to inform about the current
    /// block.
    pub fn current_block(&self) -> &CurrentBlockWatcher {
        &self.inner.current_block
    }

    /// The gas price is determined based on the deadline by which the
    /// transaction must be included on-chain. A shorter deadline requires a
    /// higher gas price to increase the likelihood of timely inclusion.
    pub async fn gas_price(&self) -> Result<Eip1559Estimation, Error> {
        self.inner.gas.estimate().await
    }

    pub fn gas_estimator(&self) -> Arc<dyn GasPriceEstimating> {
        Arc::clone(&self.inner.gas) as _
    }

    pub fn block_gas_limit(&self) -> eth::Gas {
        self.inner.current_block.borrow().gas_limit.into()
    }

    /// Per-transaction gas limit configured for this driver. Operators set
    /// this per chain (e.g. EIP-7825's 16,777,215 cap on Fusaka chains).
    pub fn tx_gas_limit(&self) -> eth::Gas {
        self.inner.tx_gas_limit
    }

    /// Returns the current [`eth::Ether`] balance of the specified account.
    pub async fn balance(&self, address: eth::Address) -> Result<eth::Ether, Error> {
        self.web3
            .provider
            .get_balance(address)
            .await
            .map(Into::into)
            .map_err(Into::into)
    }

    /// Returns a [`token::Erc20`] for the specified address.
    pub fn erc20(&self, address: eth::TokenAddress) -> token::Erc20 {
        token::Erc20::new(self, address)
    }

    /// Estimate gas used by a transaction.
    pub async fn estimate_gas(&self, tx: eth::Tx) -> Result<eth::Gas, Error> {
        // Cap the search at the per-tx gas limit so a rogue solution can't force
        // the node to binary-search up to the block gas limit while we re-check
        // the settlement on every block during submission.
        let gas_limit = u64::try_from(self.inner.tx_gas_limit.0).map_err(|err| {
            Error::GasPrice(anyhow::anyhow!(
                "failed to convert gas_limit to u64: {err:?}"
            ))
        })?;
        let tx = TransactionRequest::default()
            .from(tx.from)
            .to(tx.to)
            .value(tx.value.0)
            .input(tx.input.into())
            .access_list(tx.access_list.into())
            .with_gas_limit(gas_limit);

        let tx = match self.simulation_gas_price().await {
            Some(gas_price) => tx.with_gas_price(gas_price),
            _ => tx,
        };

        let estimated_gas = self
            .web3
            .provider
            .estimate_gas(tx)
            .pending()
            .await
            .map_err(Error::Rpc)?
            .into();

        Ok(estimated_gas)
    }

    /// Returns the transaction's on-chain inclusion status.
    pub async fn transaction_status(&self, tx_hash: &eth::TxId) -> Result<TxStatus, Error> {
        self.web3
            .provider
            .get_transaction_receipt(tx_hash.0)
            .await
            .map(|result| {
                let Some(
                    receipt @ TransactionReceipt {
                        block_number: Some(block_number),
                        ..
                    },
                ) = result
                else {
                    return TxStatus::Pending;
                };

                if receipt.status() {
                    TxStatus::Executed {
                        block_number: eth::BlockNo(block_number),
                    }
                } else {
                    TxStatus::Reverted {
                        block_number: eth::BlockNo(block_number),
                    }
                }
            })
            .map_err(Into::into)
    }

    /// The block our successful `Settlement` event for `tx_hash` landed in,
    /// searching `[from_block, to_block]` inclusive, or `None` if it is not in
    /// that range. Only a successful settle emits the event, and `eth_getLogs`
    /// reads block logs even while the receipt-by-hash lookup still lags, so
    /// this sees a freshly mined settlement that `eth_getTransactionReceipt`
    /// would still miss. Scanning a range rather than a single block means a
    /// block the (coalescing) block stream skipped on a fast chain is still
    /// covered.
    pub async fn successful_settlement_block(
        &self,
        tx_hash: eth::TxId,
        from_block: u64,
    ) -> Result<Option<eth::BlockNo>, Error> {
        let logs = self
            .contracts()
            .settlement()
            .event_filter::<::contracts::GPv2Settlement::GPv2Settlement::Settlement>()
            .from_block(alloy::eips::BlockNumberOrTag::Number(from_block))
            // `Latest` rather than the stream's head: the node may already be a block
            // or two ahead, and querying up to its real tip narrows the race window.
            .to_block(alloy::eips::BlockNumberOrTag::Latest)
            .query()
            .await?;
        Ok(logs
            .into_iter()
            .find(|(_, log)| log.transaction_hash == Some(tx_hash.0))
            .and_then(|(_, log)| log.block_number)
            .map(eth::BlockNo))
    }

    /// The signer's transaction count including the mempool (the `pending`
    /// tag). A count above the nonce we submitted with means our tx is
    /// still queued in the mempool or has already mined (the count stays at
    /// `nonce + 1` once it mines). A count equal to that nonce means the tx
    /// left the mempool without mining.
    pub async fn pending_transaction_count(&self, address: eth::Address) -> Result<u64, Error> {
        self.web3
            .provider
            .get_transaction_count(address)
            .pending()
            .await
            .map_err(Into::into)
    }

    #[instrument(skip(self), ret(level = Level::DEBUG))]
    pub(super) async fn simulation_gas_price(&self) -> Option<u128> {
        let base_fee = self.current_block().borrow().base_fee;
        // Some nodes don't pick a reasonable default value when you don't specify a gas
        // price and default to 0. Additionally some sneaky tokens have special code
        // paths that detect that case to try to behave differently during simulations
        // than they normally would. To not rely on the node picking a reasonable
        // default value we estimate the current gas price upfront. But because it's
        // extremely rare that tokens behave that way we are fine with falling back to
        // the node specific fallback value instead of failing the whole call.
        Some(self.inner.gas.estimate().await.ok()?.effective(base_fee))
    }

    pub fn web3(&self) -> &Web3 {
        &self.web3
    }
}

impl fmt::Debug for Ethereum {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.debug_struct("Ethereum")
            .field("web3", &self.web3)
            .field("chain", &self.inner.chain)
            .field("contracts", &self.inner.contracts)
            .field("gas", &"Arc<NativeGasEstimator>")
            .finish()
    }
}

#[derive(Debug, Error)]
pub enum Error {
    #[error("method error: {0:?}")]
    ContractRpc(#[from] alloy::contract::Error),
    #[error("alloy rpc error: {0:?}")]
    Rpc(#[from] alloy::transports::RpcError<TransportErrorKind>),
    #[error("gas price estimation error: {0}")]
    GasPrice(boundary::Error),
    #[error("access list estimation error: {0:?}")]
    AccessList(String),
}

impl Error {
    /// Returns whether the error indicates that the original transaction
    /// reverted.
    pub fn is_revert(&self) -> bool {
        // This behavior is node dependent
        match self {
            Error::GasPrice(_) => false,
            Error::AccessList(_) => true,
            Error::ContractRpc(_) => true,
            Error::Rpc(err) => {
                let is_revert = err.is_error_resp();
                tracing::trace!(is_revert, ?err, "classified error");
                is_revert
            }
        }
    }
}

impl From<SimulationError> for Error {
    fn from(err: SimulationError) -> Self {
        match err {
            SimulationError::Method(err) => Self::ContractRpc(err),
        }
    }
}
