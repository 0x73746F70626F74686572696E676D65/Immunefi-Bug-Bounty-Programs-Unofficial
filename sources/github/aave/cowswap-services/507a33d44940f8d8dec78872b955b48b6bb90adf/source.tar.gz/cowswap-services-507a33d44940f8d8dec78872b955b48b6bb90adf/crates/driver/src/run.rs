use {
    crate::{
        domain::{
            Mempools,
            competition::{order::app_data::AppDataRetriever, risk_detector},
        },
        infra::{
            self,
            Api,
            blockchain::{self, Ethereum, RpcError, gas},
            cli,
            config,
            liquidity,
            notify,
            solver::Solver,
        },
    },
    clap::Parser,
    futures::future::join_all,
    http_client::HttpClientFactory,
    shared::arguments::tracing_config,
    simulator::{self, Simulator},
    std::{net::SocketAddr, time::Duration},
    tokio::sync::oneshot,
};

/// The driver entry-point. This function exists in order to be able to run the
/// driver from multiple binaries.
pub async fn start(args: impl Iterator<Item = String>) {
    observe::panic_hook::install();
    let args = cli::Args::parse_from(args);
    run_with(args, None).await
}

/// This function exists to enable running the driver for testing. The
/// `addr_sender` parameter is used so that the testing framework can get the
/// address of the server and connect to it. Outside the test suite, the
/// `addr_sender` parameter is unused. The `now` parameter allows the current
/// time to be faked for testing purposes.
pub async fn run(
    args: impl Iterator<Item = String>,
    addr_sender: Option<oneshot::Sender<SocketAddr>>,
) {
    let args = cli::Args::parse_from(args);
    run_with(args, addr_sender).await;
}

/// Run the driver. This function exists to avoid multiple monomorphizations of
/// the `run` code, which bloats the binaries and increases compile times.
async fn run_with(args: cli::Args, addr_sender: Option<oneshot::Sender<SocketAddr>>) {
    let ethrpc_res = ethrpc(&args).await;
    let chain_name = ethrpc_res
        .as_ref()
        .map(|ethrpc| ethrpc.chain().name())
        .unwrap_or("unknown");

    infra::observe::init(observe::Config::new(
        &args.log,
        args.stderr_threshold,
        args.use_json_logs,
        tracing_config(&args.tracing, format!("driver-{chain_name}")),
    ));

    let ethrpc = ethrpc_res.expect("connect ethereum RPC");
    let config = config::file::load(ethrpc.chain(), &args.config).await;

    let version = observe::version::git_version();

    tracing::info!(%version, "running driver with {config:#?}");

    let (shutdown_sender, shutdown_receiver) = tokio::sync::oneshot::channel();
    let eth = Ethereum::new(
        ethrpc.clone(),
        config.contracts.clone(),
        &args.current_block,
        config.tx_gas_limit.into(),
        &config.gas_estimator,
        gas::adjustments(&config.mempools),
    )
    .await;

    let simulator_eth = simulator::Ethereum::new(
        ethrpc.web3().clone(),
        ethrpc.chain(),
        configs::simulator::Addresses {
            settlement: config.contracts.settlement.map(|address| *address),
            weth: config.contracts.weth.map(|address| *address),
        },
        eth.gas_estimator(),
        eth.current_block().clone(),
        config.tx_gas_limit,
    );
    let app_data_retriever = match &config.app_data_fetching {
        config::file::AppDataFetching::Enabled {
            orderbook_url,
            cache_size,
        } => Some(AppDataRetriever::new(orderbook_url.clone(), *cache_size)),
        config::file::AppDataFetching::Disabled => None,
    };
    let solvers = solvers(&config, &eth).await;
    let http_factory = HttpClientFactory::new(&config.http);
    // Set up EIP-7702 delegate deployment and solver delegation for solvers
    // with parallel submission accounts. Must happen before the HTTP server
    // starts accepting /settle requests.
    infra::solver::eip7702::setup(&solvers, &eth)
        .await
        .expect("EIP-7702 setup failed");

    let serve = Api {
        solvers,
        liquidity: liquidity(&config, &eth).await,
        liquidity_sources_notifier: liquidity_sources_notifier(&config, &eth),
        simulator: simulator(&config, simulator_eth, &http_factory),
        mempools: Mempools::try_new(
            config
                .mempools
                .iter()
                .map(|mempool| {
                    crate::infra::mempool::Mempool::new(
                        mempool.to_owned(),
                        config
                            .solvers
                            .iter()
                            .flat_map(|config| {
                                std::iter::once(config.account.clone())
                                    .chain(config.submission_accounts.iter().cloned())
                            })
                            .collect(),
                    )
                })
                .collect(),
            eth.clone(),
        )
        .unwrap(),
        bad_token_detector: risk_detector::bad_tokens::Detector::new(
            config.simulation_bad_token_max_age,
            &eth,
        ),
        eth,
        addr: args.addr,
        addr_sender,
    }
    .serve(
        async {
            let _ = shutdown_receiver.await;
        },
        config.order_priority_strategies,
        app_data_retriever,
    );

    futures::pin_mut!(serve);
    tokio::select! {
        result = &mut serve => panic!("serve task exited: {result:?}"),
        _ = shutdown_signal() => {
            tracing::info!("Gracefully shutting down API");
            shutdown_sender.send(()).expect("failed to send shutdown signal");
            // Shutdown timeout needs to be larger than the auction deadline
            match tokio::time::timeout(Duration::from_secs(20), serve).await {
                Ok(inner) => inner.expect("API failed during shutdown"),
                Err(_) => panic!("API shutdown exceeded timeout"),
            }
        }
    };
}

fn simulator(
    config: &infra::Config,
    eth: simulator::Ethereum,
    http_factory: &HttpClientFactory,
) -> Simulator {
    let block_stream = eth.current_block().clone();
    let mut simulator = match &config.simulator {
        configs::simulator::Config {
            kind: configs::simulator::SimulatorKind::Tenderly(config),
            ..
        } => Simulator::tenderly(config, eth, http_factory),
        configs::simulator::Config {
            kind: configs::simulator::SimulatorKind::Ethereum,
            ..
        } => Simulator::ethereum(eth),
    };

    if config.disable_access_list_simulation {
        simulator.disable_access_lists();
    }
    if let Some(gas) = config.disable_gas_simulation {
        simulator.disable_gas(gas);
    }
    if let Some(cfg) = &config.simulator.state_override_stream {
        simulator
            .set_simulation_overrides(simulator::state_override_stream::spawn(cfg, block_stream));
    }

    simulator
}

async fn ethrpc(args: &cli::Args) -> Result<blockchain::Rpc, RpcError> {
    let args = blockchain::RpcArgs {
        url: args.ethrpc.clone(),
        max_batch_size: args.ethrpc_max_batch_size,
        max_concurrent_requests: args.ethrpc_max_concurrent_requests,
    };
    blockchain::Rpc::try_new(args).await
}

async fn solvers(config: &config::Config, eth: &Ethereum) -> Vec<Solver> {
    join_all(
        config
            .solvers
            .iter()
            .map(
                |config| async move { Solver::try_new(config.clone(), eth.clone()).await.unwrap() },
            )
            .collect::<Vec<_>>(),
    )
    .await
}

async fn liquidity(config: &config::Config, eth: &Ethereum) -> liquidity::Fetcher {
    liquidity::Fetcher::try_new(eth, &config.liquidity)
        .await
        .expect("initialize liquidity fetcher")
}

fn liquidity_sources_notifier(
    config: &config::Config,
    eth: &Ethereum,
) -> notify::liquidity_sources::Notifier {
    let notifier_config = config
        .liquidity_sources_notifier
        .as_ref()
        .unwrap_or(&notify::liquidity_sources::config::Config { liquorice: None });
    notify::liquidity_sources::Notifier::try_new(notifier_config, eth.chain())
        .expect("initialize notify sources notifier")
}

#[cfg(unix)]
async fn shutdown_signal() {
    // Intercept signals for graceful shutdown. Kubernetes sends sigterm, Ctrl-C
    // sends sigint.
    let sigterm = async {
        tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .unwrap()
            .recv()
            .await
    };
    let sigint = async {
        tokio::signal::unix::signal(tokio::signal::unix::SignalKind::interrupt())
            .unwrap()
            .recv()
            .await;
    };
    futures::pin_mut!(sigint);
    futures::pin_mut!(sigterm);
    futures::future::select(sigterm, sigint).await;
}

#[cfg(windows)]
async fn shutdown_signal() {
    // No support for signal handling on Windows.
    std::future::pending().await
}
