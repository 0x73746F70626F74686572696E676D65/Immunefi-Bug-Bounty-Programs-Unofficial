use {
    alloy_primitives::{Address, U256},
    alloy_rpc_types::state::StateOverride,
    alloy_sol_types::{SolCall, SolType, sol_data},
    balance_overrides::{BalanceOverrideRequest, StateOverriding},
    contracts::{GPv2Settlement, support::Balances},
    ethrpc::{Web3, block_stream::CurrentBlockWatcher},
    model::{
        interaction::InteractionData,
        order::{Order, SellTokenSource},
    },
    std::sync::{Arc, LazyLock},
};

mod cached;
mod simulation;

#[derive(Clone, Debug, Hash, PartialEq, Eq)]
pub struct Query {
    pub owner: Address,
    pub token: Address,
    pub source: SellTokenSource,
    pub interactions: Vec<InteractionData>,
    pub balance_override: Option<BalanceOverrideRequest>,
}

impl Query {
    pub fn from_order(o: &Order) -> Self {
        Self {
            owner: o.metadata.owner,
            token: o.data.sell_token,
            source: o.data.sell_token_balance,
            interactions: o.interactions.pre.clone(),
            // TODO eventually delete together with the balance
            // checks in the autopilot
            balance_override: None,
        }
    }
}

#[derive(Debug)]
pub enum TransferSimulationError {
    InsufficientAllowance,
    InsufficientBalance,
    TransferFailed(Vec<u8>),
    Other(anyhow::Error),
}

impl From<anyhow::Error> for TransferSimulationError {
    fn from(err: anyhow::Error) -> Self {
        Self::Other(err)
    }
}

#[cfg_attr(any(test, feature = "test-util"), mockall::automock)]
#[async_trait::async_trait]
pub trait BalanceFetching: Send + Sync {
    // Returns the balance available to the allowance manager for the given owner
    // and token taking both balance as well as "allowance" into account.
    async fn get_balances(&self, queries: &[Query]) -> Vec<anyhow::Result<U256>>;

    // Check that the settlement contract can make use of this user's token balance.
    // This check could fail if the user does not have enough balance, has not
    // given the allowance to the allowance manager or if the token does not
    // allow freely transferring amounts around for example if it is paused
    // or takes a fee on transfer. If the node supports the trace_callMany we
    // can perform more extensive tests.
    async fn can_transfer(
        &self,
        query: &Query,
        amount: U256,
    ) -> Result<(), TransferSimulationError>;

    /// Returns the owner's current on-chain allowance available to the protocol
    /// for the given sell token and source. This does **not** apply any order
    /// pre-interactions or other actions that might affect the allowance at
    /// settlement time.
    async fn allowance(
        &self,
        owner: Address,
        token: Address,
        source: SellTokenSource,
    ) -> anyhow::Result<U256>;
}

/// Create the default [`BalanceFetching`] instance.
pub fn fetcher(web3: &Web3, balance_simulator: BalanceSimulator) -> Arc<dyn BalanceFetching> {
    Arc::new(simulation::Balances::new(web3, balance_simulator))
}

/// Create a cached [`BalanceFetching`] instance.
pub fn cached(
    web3: &Web3,
    balance_simulator: BalanceSimulator,
    blocks: CurrentBlockWatcher,
) -> Arc<dyn BalanceFetching> {
    let cached = Arc::new(cached::Balances::new(fetcher(web3, balance_simulator)));
    cached.spawn_background_task(blocks);
    cached
}

#[derive(Clone)]
pub struct BalanceSimulator {
    settlement: GPv2Settlement::Instance,
    balances: Balances::Instance,
    vault_relayer: Address,
    balance_overrider: Arc<dyn StateOverriding>,
}

impl BalanceSimulator {
    pub fn new(
        settlement: GPv2Settlement::Instance,
        balances: Balances::Instance,
        vault_relayer: Address,
        balance_overrider: Arc<dyn StateOverriding>,
    ) -> Self {
        Self {
            settlement,
            vault_relayer,
            balances,
            balance_overrider,
        }
    }

    pub fn vault_relayer(&self) -> Address {
        self.vault_relayer
    }

    pub async fn simulate(
        &self,
        owner: Address,
        token: Address,
        source: SellTokenSource,
        interactions: &[InteractionData],
        amount: Option<U256>,
        balance_override: Option<BalanceOverrideRequest>,
    ) -> Result<Simulation, SimulationError> {
        let overrides: StateOverride = match balance_override {
            Some(overrides) => self
                .balance_overrider
                .balance_override(overrides)
                .await
                .into_iter()
                .collect(),
            None => Default::default(),
        };
        // We simulate the balances from the Settlement contract's context. This
        // allows us to check:
        // 1. How the pre-interactions would behave as part of the settlement
        // 2. Simulate the actual VaultRelayer transfers that would happen as part of a
        //    settlement
        //
        // This allows us to end up with very accurate balance simulations.
        let balance_call = Balances::Balances::balanceCall {
            contracts: Balances::Balances::Contracts {
                settlement: *self.settlement.address(),
                vaultRelayer: self.vault_relayer,
                // The Balancer Vault is only used by the deprecated External/Internal
                // sell-token sources, which are rejected at order creation.
                vault: Address::ZERO,
            },
            trader: owner,
            token,
            amount: amount.unwrap_or_default(),
            source: source.as_bytes().into(),
            interactions: interactions
                .iter()
                .map(|i| Balances::Balances::Interaction {
                    target: i.target,
                    value: i.value,
                    callData: i.call_data.clone().into(),
                })
                .collect(),
        };

        let response = self
            .settlement
            .simulateDelegatecall(*self.balances.address(), balance_call.abi_encode().into())
            .with_cloned_provider()
            .state(overrides)
            .from(*SIMULATION_ACCOUNT)
            .call()
            .await?;

        let (token_balance, allowance, effective_balance, can_transfer, transfer_revert_reason) =
            <(
                sol_data::Uint<256>,
                sol_data::Uint<256>,
                sol_data::Uint<256>,
                sol_data::Bool,
                sol_data::Bytes,
            )>::abi_decode_params(&response.0)
            .map_err(|err| {
                tracing::error!(?err, "failed to decode balance response");
                alloy_contract::Error::AbiError(alloy_dyn_abi::Error::SolTypes(err))
            })?;

        let simulation = Simulation {
            token_balance: U256::from_le_slice(&token_balance.as_le_bytes()),
            allowance: U256::from_le_slice(&allowance.as_le_bytes()),
            effective_balance: U256::from_le_slice(&effective_balance.as_le_bytes()),
            can_transfer,
            transfer_revert_reason: transfer_revert_reason.to_vec(),
        };

        tracing::trace!(
            ?owner,
            ?token,
            ?source,
            ?amount,
            ?interactions,
            ?simulation,
            "simulated balances"
        );
        Ok(simulation)
    }
}

#[derive(Debug)]
pub struct Simulation {
    pub token_balance: U256,
    pub allowance: U256,
    pub effective_balance: U256,
    pub can_transfer: bool,
    pub transfer_revert_reason: Vec<u8>,
}

#[derive(Debug)]
pub enum SimulationError {
    Method(alloy_contract::Error),
}

impl std::fmt::Display for SimulationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Method(err) => write!(f, "method error: {err:?}"),
        }
    }
}

impl std::error::Error for SimulationError {}

impl From<alloy_contract::Error> for SimulationError {
    fn from(err: alloy_contract::Error) -> Self {
        Self::Method(err)
    }
}

// ZKSync-based chains don't use the default 0x0 account when `tx.from` is not
// specified, so we need to use a random account when sending a simulation tx.
static SIMULATION_ACCOUNT: LazyLock<Address> = LazyLock::new(|| Address::random());
