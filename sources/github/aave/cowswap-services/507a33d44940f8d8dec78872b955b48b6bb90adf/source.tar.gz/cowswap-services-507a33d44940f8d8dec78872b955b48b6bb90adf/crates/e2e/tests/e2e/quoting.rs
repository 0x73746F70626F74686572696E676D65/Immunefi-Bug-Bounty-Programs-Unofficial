use {
    configs::{
        autopilot::Configuration,
        fee_factor::FeeFactor,
        order_quoting::{ExternalSolver, OrderQuoting},
        test_util::TestDefault,
    },
    e2e::setup::{colocation::SolverEngine, mock::Mock, *},
    eth_domain_types::Address,
    ethrpc::alloy::CallBuilderExt,
    futures::FutureExt,
    model::{
        order::{OrderCreation, OrderCreationAppData, OrderKind},
        quote::{
            OrderQuoteRequest,
            OrderQuoteResponse,
            OrderQuoteSide,
            QuoteSigningScheme,
            SellAmount,
        },
        signature::EcdsaSigningScheme,
    },
    number::{nonzero::NonZeroU256, units::EthUnit},
    reqwest::StatusCode,
    serde_json::json,
    shared::web3::Web3,
    solvers_dto::solution::{SolverError, SolverErrorCode, SolverResponse},
    std::{
        ops::DerefMut,
        sync::Arc,
        time::{Duration, Instant},
    },
};

#[tokio::test]
#[ignore]
async fn local_node_test() {
    run_test(test).await;
}

#[tokio::test]
#[ignore]
async fn local_node_uses_stale_liquidity() {
    run_test(uses_stale_liquidity).await;
}

#[tokio::test]
#[ignore]
async fn local_node_quote_timeout() {
    run_test(quote_timeout).await;
}

#[tokio::test]
#[ignore]
async fn local_node_volume_fee() {
    run_test(volume_fee).await;
}

#[tokio::test]
#[ignore]
async fn local_node_quote_custom_solver_errors() {
    run_test(quote_custom_solver_errors).await;
}

#[tokio::test]
#[ignore]
async fn local_node_native_price_custom_solver_errors() {
    run_test(native_price_custom_solver_errors).await;
}

#[tokio::test]
#[ignore]
async fn local_node_quote_custom_solver_errors_prioritized() {
    run_test(quote_custom_solver_errors_prioritized).await;
}

#[tokio::test]
#[ignore]
async fn local_node_quote_stream_smoke() {
    run_test(quote_stream_smoke).await;
}

// Test that quoting works as expected, specifically, that we can quote for a
// token pair and additional gas from ERC-1271 and hooks are included in the
// quoted fee amount.
async fn test(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(10u64.eth()).await;
    let [token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    onchain
        .contracts()
        .weth
        .approve(onchain.contracts().allowance, 3u64.eth())
        .from(trader.address())
        .send_and_watch()
        .await
        .unwrap();
    onchain
        .contracts()
        .weth
        .deposit()
        .from(trader.address())
        .value(3u64.eth())
        .send_and_watch()
        .await
        .unwrap();

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;
    // Start API with 0.02% (2 bps) volume fee
    services
        .start_protocol_with_args(
            Configuration::test("test_solver", solver.address()),
            configs::orderbook::Configuration {
                volume_fee: Some(configs::orderbook::VolumeFeeConfig {
                    factor: Some(FeeFactor::new(0.0002)),
                    // Set a far future effective timestamp to ensure the fee is not applied
                    effective_from_timestamp: Some("2099-01-01T10:00:00Z".parse().unwrap()),
                }),
                ..configs::orderbook::Configuration::test_default()
            },
            solver,
        )
        .await;

    tracing::info!("Quoting order");
    let request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    let with_eip1271 = services
        .submit_quote(&OrderQuoteRequest {
            signing_scheme: QuoteSigningScheme::Eip1271 {
                onchain_order: false,
                verification_gas_limit: 50_000,
            },
            ..request.clone()
        })
        .await
        .unwrap();

    let with_hooks = services
        .submit_quote(&OrderQuoteRequest {
            app_data: OrderCreationAppData::Full {
                full: serde_json::to_string(&json!({
                    "metadata": {
                        "hooks": {
                            "pre": [
                                {
                                    "target": "0x0000000000000000000000000000000000000000",
                                    "callData": "0x",
                                    "gasLimit": "5000",
                                },
                            ],
                            "post": [
                                {
                                    "target": "0x0000000000000000000000000000000000000000",
                                    "callData": "0x",
                                    "gasLimit": "5000",
                                },
                            ],
                        },
                    },
                }))
                .unwrap(),
            },
            ..request.clone()
        })
        .await
        .unwrap();

    let with_both = services
        .submit_quote(&OrderQuoteRequest {
            signing_scheme: QuoteSigningScheme::Eip1271 {
                onchain_order: false,
                verification_gas_limit: 50_000,
            },
            app_data: OrderCreationAppData::Full {
                full: serde_json::to_string(&json!({
                    "metadata": {
                        "hooks": {
                            "pre": [
                                {
                                    "target": "0x0000000000000000000000000000000000000000",
                                    "callData": "0x",
                                    "gasLimit": "5000",
                                },
                            ],
                            "post": [
                                {
                                    "target": "0x0000000000000000000000000000000000000000",
                                    "callData": "0x",
                                    "gasLimit": "5000",
                                },
                            ],
                        },
                    },
                }))
                .unwrap(),
            },
            ..request.clone()
        })
        .await
        .unwrap();

    let base = services.submit_quote(&request).await.unwrap();

    tracing::debug!(
        ?with_eip1271,
        ?with_hooks,
        ?with_both,
        ?base,
        "Computed quotes."
    );

    assert!(base.quote.fee_amount < with_eip1271.quote.fee_amount);
    assert!(base.quote.fee_amount < with_hooks.quote.fee_amount);

    assert!(with_both.quote.fee_amount > with_eip1271.quote.fee_amount);
    assert!(with_both.quote.fee_amount > with_hooks.quote.fee_amount);

    // TODO: test verified quotes, requires state overrides support.
}

async fn uses_stale_liquidity(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3.clone()).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(2u64.eth()).await;
    let [token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    onchain
        .contracts()
        .weth
        .approve(onchain.contracts().allowance, 1u64.eth())
        .from(trader.address())
        .send_and_watch()
        .await
        .unwrap();
    onchain
        .contracts()
        .weth
        .deposit()
        .from(trader.address())
        .value(1u64.eth())
        .send_and_watch()
        .await
        .unwrap();

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;
    services.start_protocol(solver).await;

    let quote = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::AfterFee {
                value: NonZeroU256::new(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    tracing::info!("performining initial quote");
    let first = services.submit_quote(&quote).await.unwrap();

    // Now, we want to manually unbalance the pools and assert that the quote
    // doesn't change (as the price estimation will use stale pricing data).
    onchain
        .mint_token_to_weth_uni_v2_pool(&token, 1_000u64.eth())
        .await;

    tracing::info!("performining second quote, which should match first");
    let second = services.submit_quote(&quote).await.unwrap();
    assert_eq!(first.quote.buy_amount, second.quote.buy_amount);

    tracing::info!("waiting for liquidity state to update");
    wait_for_condition(TIMEOUT, || async {
        // Mint blocks until we evict the cached liquidty and fetch the new state.
        onchain.mint_block().await;
        let Ok(next) = services.submit_quote(&quote).await else {
            return false;
        };
        next.quote.buy_amount != first.quote.buy_amount
    })
    .await
    .unwrap();
}

/// Tests that the user can provide a timeout with their quote
/// which gets respected.
async fn quote_timeout(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3.clone()).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(2u64.eth()).await;
    let [sell_token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;

    let mock_solver = Mock::new().await;

    // Start system
    colocation::start_driver(
        onchain.contracts(),
        vec![
            SolverEngine {
                name: "test_solver".into(),
                account: solver.clone(),
                endpoint: mock_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
            SolverEngine {
                name: "test_quoter".into(),
                account: solver.clone(),
                endpoint: mock_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
        ],
        colocation::LiquidityProvider::UniswapV2,
        false,
    );

    /// The default quote timeout used when the user does not override it.
    const DEFAULT_QUOTE_TIMEOUT_MS: u64 = 500;

    /// The maximum quote timeout the user is allowed to configure.
    const MAX_QUOTE_TIMEOUT_MS: u64 = 1000;

    services
        .start_api(configs::orderbook::Configuration {
            order_quoting: OrderQuoting::test_with_drivers(vec![ExternalSolver::new(
                "test_quoter",
                "http://localhost:11088/test_quoter",
            )]),
            native_price_estimation: configs::orderbook::native_price::NativePriceConfig {
                estimators: configs::native_price_estimators::NativePriceEstimators::new(vec![
                    vec![
                        configs::native_price_estimators::NativePriceEstimator::driver(
                            "test_quoter".to_string(),
                            "http://localhost:11088/test_solver".parse().unwrap(),
                        ),
                    ],
                ]),
                ..configs::orderbook::native_price::NativePriceConfig::test_default()
            },
            price_estimation: configs::price_estimation::PriceEstimation {
                quote_timeout: Duration::from_millis(DEFAULT_QUOTE_TIMEOUT_MS),
                max_quote_timeout: Duration::from_millis(MAX_QUOTE_TIMEOUT_MS),
                ..configs::orderbook::Configuration::test_default().price_estimation
            },
            ..configs::orderbook::Configuration::test_default()
        })
        .await;

    mock_solver.configure_solution_async(Arc::new(|| {
        async {
            // make the solver always exceed the max quote timeout
            tokio::time::sleep(Duration::from_millis(MAX_QUOTE_TIMEOUT_MS + 100)).await;
            // we only care about timeout management so no need to return
            // a working solution
            None
        }
        .boxed()
    }));

    let quote_request = |timeout| OrderQuoteRequest {
        from: trader.address(),
        // use random address to avoid tokens getting cached as unquotable
        // due to repeated quoting errors
        sell_token: Address::random(),
        buy_token: Address::random(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        timeout,
        ..Default::default()
    };

    let assert_within_variance = |start_timestamp: Instant, target| {
        const VARIANCE: u64 = 100; // small buffer to allow for variance in the test
        const HTTP_BUFFER: u64 = 100;
        let min = target - HTTP_BUFFER;
        let max = min + VARIANCE;
        let elapsed = start_timestamp.elapsed().as_millis() as u64;
        tracing::debug!(target, actual = ?elapsed, "finished request");
        assert!((min..max).contains(&elapsed));
    };

    // native token price requests use the default timeout
    let start = std::time::Instant::now();
    let res = services.get_native_price(&Address::random()).await;
    assert!(res.unwrap_err().1.contains("NoLiquidity"));
    assert_within_variance(start, DEFAULT_QUOTE_TIMEOUT_MS);

    // not providing a quote timeout uses the backend's default timeout (500ms)
    let start = std::time::Instant::now();
    let res = services.submit_quote(&quote_request(None)).await;
    assert!(res.unwrap_err().1.contains("NoLiquidity"));
    assert_within_variance(start, DEFAULT_QUOTE_TIMEOUT_MS);

    // timeouts below the default timeout get enforced correctly
    let start = std::time::Instant::now();
    let res = services
        .submit_quote(&quote_request(Some(Duration::from_millis(300))))
        .await;
    assert!(res.unwrap_err().1.contains("NoLiquidity"));
    assert_within_variance(start, 300);

    // timeouts between default and max value get enforced correctly
    let start = std::time::Instant::now();
    let res = services
        .submit_quote(&quote_request(Some(Duration::from_millis(700))))
        .await;
    assert!(res.unwrap_err().1.contains("NoLiquidity"));
    assert_within_variance(start, 700);

    // user provided timeouts get capped at the backend's max timeout (1000ms)
    let start = std::time::Instant::now();
    let res = services
        .submit_quote(&quote_request(Some(Duration::from_millis(
            MAX_QUOTE_TIMEOUT_MS * 2,
        ))))
        .await;
    assert!(res.unwrap_err().1.contains("NoLiquidity"));
    assert_within_variance(start, MAX_QUOTE_TIMEOUT_MS);

    // set up trader to pass balance checks during order creation
    sell_token.mint(trader.address(), 1u64.eth()).await;

    sell_token
        .approve(onchain.contracts().allowance, 1u64.eth())
        .from(trader.address())
        .send_and_watch()
        .await
        .unwrap();

    let order = OrderCreation {
        sell_token: *sell_token.address(),
        sell_amount: 1u64.eth(),
        buy_token: Default::default(),
        buy_amount: 1u64.eth(),
        valid_to: model::time::now_in_epoch_seconds() + 300,
        kind: OrderKind::Sell,
        partially_fillable: true,
        ..Default::default()
    }
    .sign(
        EcdsaSigningScheme::Eip712,
        &onchain.contracts().domain_separator,
        &trader.signer,
    );

    // order creation requests always use the default quote time
    // to maximize the chance for the request to succeed because
    // we return an error if we can't get a quote
    let start = std::time::Instant::now();
    let res = services.create_order(&order).await;
    assert!(res.unwrap_err().1.contains("NoLiquidity"));
    assert_within_variance(start, DEFAULT_QUOTE_TIMEOUT_MS);
}

async fn quote_custom_solver_errors(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3.clone()).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(2u64.eth()).await;
    let [sell_token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;

    let mock_solver = Mock::new().await;

    colocation::start_driver(
        onchain.contracts(),
        vec![
            SolverEngine {
                name: "test_solver".into(),
                account: solver.clone(),
                endpoint: mock_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
            SolverEngine {
                name: "test_quoter".into(),
                account: solver.clone(),
                endpoint: mock_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
        ],
        colocation::LiquidityProvider::UniswapV2,
        false,
    );

    services
        .start_api(configs::orderbook::Configuration {
            order_quoting: OrderQuoting::test_with_drivers(vec![ExternalSolver::new(
                "test_quoter",
                "http://localhost:11088/test_quoter",
            )]),
            native_price_estimation: configs::orderbook::native_price::NativePriceConfig {
                estimators: configs::native_price_estimators::NativePriceEstimators::new(vec![
                    vec![
                        configs::native_price_estimators::NativePriceEstimator::driver(
                            "test_quoter".to_string(),
                            "http://localhost:11088/test_quoter".parse().unwrap(),
                        ),
                    ],
                ]),
                ..configs::orderbook::native_price::NativePriceConfig::test_default()
            },
            ..configs::orderbook::Configuration::test_default()
        })
        .await;

    let quote_request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *sell_token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    let cases = vec![
        (
            SolverErrorCode::TradingOutsideAllowedWindow,
            "TradingOutsideAllowedWindow",
            None,
            "Token can only be traded during specific time windows",
        ),
        (
            SolverErrorCode::TokenTemporarilySuspended,
            "TokenTemporarilySuspended",
            Some("token is suspended"),
            "token is suspended",
        ),
        (
            SolverErrorCode::InsufficientLiquidity,
            "InsufficientLiquidity",
            Some("not enough liquidity"),
            "not enough liquidity",
        ),
        (
            SolverErrorCode::Other,
            "CustomSolverError",
            Some("some solver specific error"),
            "some solver specific error",
        ),
    ];

    for (code, expected_kind, sent_message, expected_message) in cases {
        mock_solver.configure_response(SolverResponse::Error {
            error: SolverError {
                code,
                message: sent_message.map(str::to_string),
            },
        });

        let (status, body) = services.submit_quote(&quote_request).await.unwrap_err();
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(
            body.contains(expected_kind),
            "response should include error kind {expected_kind}, got {body}"
        );
        assert!(
            body.contains(expected_message),
            "response should include error message {expected_message}, got {body}"
        );
    }
}

async fn native_price_custom_solver_errors(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3.clone()).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [_trader] = onchain.make_accounts(2u64.eth()).await;
    let [sell_token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;

    let mock_solver = Mock::new().await;

    colocation::start_driver(
        onchain.contracts(),
        vec![
            SolverEngine {
                name: "test_solver".into(),
                account: solver.clone(),
                endpoint: mock_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
            SolverEngine {
                name: "test_quoter".into(),
                account: solver.clone(),
                endpoint: mock_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
        ],
        colocation::LiquidityProvider::UniswapV2,
        false,
    );

    services
        .start_api(configs::orderbook::Configuration {
            order_quoting: OrderQuoting::test_with_drivers(vec![ExternalSolver::new(
                "test_quoter",
                "http://localhost:11088/test_quoter",
            )]),
            native_price_estimation: configs::orderbook::native_price::NativePriceConfig {
                estimators: configs::native_price_estimators::NativePriceEstimators::new(vec![
                    vec![
                        configs::native_price_estimators::NativePriceEstimator::driver(
                            "test_quoter".to_string(),
                            "http://localhost:11088/test_quoter".parse().unwrap(),
                        ),
                    ],
                ]),
                ..configs::orderbook::native_price::NativePriceConfig::test_default()
            },
            ..configs::orderbook::Configuration::test_default()
        })
        .await;

    let cases = vec![
        (
            SolverErrorCode::TradingOutsideAllowedWindow,
            "TradingOutsideAllowedWindow",
            "native window closed",
        ),
        (
            SolverErrorCode::TokenTemporarilySuspended,
            "TokenTemporarilySuspended",
            "native token suspended",
        ),
        (
            SolverErrorCode::InsufficientLiquidity,
            "InsufficientLiquidity",
            "native not enough liquidity",
        ),
        (
            SolverErrorCode::Other,
            "CustomSolverError",
            "native custom solver reason",
        ),
    ];

    for (code, expected_kind, message) in cases {
        mock_solver.configure_response(SolverResponse::Error {
            error: SolverError {
                code,
                message: Some(message.to_string()),
            },
        });

        let (status, body) = services
            .get_native_price(sell_token.address())
            .await
            .unwrap_err();
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(
            body.contains(expected_kind),
            "response should include error kind {expected_kind}, got {body}"
        );
        assert!(
            body.contains(message),
            "response should include error message {message}, got {body}"
        );
    }
}

async fn quote_custom_solver_errors_prioritized(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3.clone()).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(2u64.eth()).await;
    let [sell_token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;

    let custom_error_solver = Mock::new().await;
    let no_liquidity_solver = Mock::new().await;

    colocation::start_driver(
        onchain.contracts(),
        vec![
            SolverEngine {
                name: "custom_solver".into(),
                account: solver.clone(),
                endpoint: custom_error_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
            SolverEngine {
                name: "no_liquidity_solver".into(),
                account: solver.clone(),
                endpoint: no_liquidity_solver.url.clone(),
                base_tokens: vec![*sell_token.address()],
                merge_solutions: true,
                haircut_bps: 0,
                submission_keys: vec![],
            },
        ],
        colocation::LiquidityProvider::UniswapV2,
        false,
    );

    services
        .start_api(configs::orderbook::Configuration {
            order_quoting: OrderQuoting::test_with_drivers(vec![
                ExternalSolver::new("custom_solver", "http://localhost:11088/custom_solver"),
                ExternalSolver::new(
                    "no_liquidity_solver",
                    "http://localhost:11088/no_liquidity_solver",
                ),
            ]),
            native_price_estimation: configs::orderbook::native_price::NativePriceConfig {
                estimators: configs::native_price_estimators::NativePriceEstimators::new(vec![
                    vec![
                        configs::native_price_estimators::NativePriceEstimator::driver(
                            "custom_solver".to_string(),
                            "http://localhost:11088/custom_solver".parse().unwrap(),
                        ),
                        configs::native_price_estimators::NativePriceEstimator::driver(
                            "no_liquidity_solver".to_string(),
                            "http://localhost:11088/no_liquidity_solver"
                                .parse()
                                .unwrap(),
                        ),
                    ],
                ]),
                ..configs::orderbook::native_price::NativePriceConfig::test_default()
            },
            ..configs::orderbook::Configuration::test_default()
        })
        .await;

    custom_error_solver.configure_response(SolverResponse::Error {
        error: SolverError {
            code: SolverErrorCode::Other,
            message: Some("priority custom solver error".to_string()),
        },
    });
    no_liquidity_solver.configure_response(SolverResponse::Solutions {
        solutions: Vec::new(),
    });

    let quote_request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *sell_token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    let (status, body) = services.submit_quote(&quote_request).await.unwrap_err();
    assert_eq!(status, StatusCode::BAD_REQUEST);
    assert!(
        body.contains("CustomSolverError"),
        "response should include custom solver error, got {body}"
    );
    assert!(
        body.contains("priority custom solver error"),
        "response should include prioritized custom error message, got {body}"
    );
}

/// Test that volume fees are correctly applied to quotes.
async fn volume_fee(web3: Web3) {
    let mut onchain = OnchainComponents::deploy(web3).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(10u64.eth()).await;
    let [token, override_token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    onchain
        .contracts()
        .weth
        .approve(onchain.contracts().allowance, 3u64.eth())
        .from(trader.address())
        .send_and_watch()
        .await
        .unwrap();
    onchain
        .contracts()
        .weth
        .deposit()
        .from(trader.address())
        .value(3u64.eth())
        .send_and_watch()
        .await
        .unwrap();

    tracing::info!("Starting services with volume fee.");
    let services = Services::new(&onchain).await;
    // Start API with 0.02% (2 bps) default volume fee
    // Bucket override: WETH<->override_token pair gets 5 bps (both tokens must be
    // in bucket)
    services
        .start_protocol_with_args(
            Configuration::test("test_solver", solver.address()),
            configs::orderbook::Configuration {
                shared: configs::shared::SharedConfig {
                    volume_fee_bucket_overrides: vec![configs::shared::TokenBucketFeeOverride {
                        tokens: [
                            *onchain.contracts().weth.address(),
                            *override_token.address(),
                        ]
                        .into_iter()
                        .collect(),
                        factor: FeeFactor::new(0.0005),
                    }],
                    ..Default::default()
                },
                volume_fee: Some(configs::orderbook::VolumeFeeConfig {
                    factor: Some(FeeFactor::new(0.0002)),
                    // Set a past effective timestamp to ensure the fee is applied
                    effective_from_timestamp: Some("2000-01-01T10:00:00Z".parse().unwrap()),
                }),
                ..configs::orderbook::Configuration::test_default()
            },
            solver,
        )
        .await;

    tracing::info!("Testing SELL quote with volume fee");
    let sell_request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    let sell_quote = services.submit_quote(&sell_request).await.unwrap();

    // Verify protocol fee fields are present
    assert!(sell_quote.protocol_fee_bps.is_some());
    assert_eq!(sell_quote.protocol_fee_bps.as_ref().unwrap(), "2");

    tracing::info!("Testing BUY quote with volume fee");
    let buy_request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *token.address(),
        side: OrderQuoteSide::Buy {
            buy_amount_after_fee: NonZeroU256::try_from(1u64.eth()).unwrap(),
        },
        ..Default::default()
    };

    let buy_quote = services.submit_quote(&buy_request).await.unwrap();

    // Verify protocol fee fields are present
    assert!(buy_quote.protocol_fee_bps.is_some());
    assert_eq!(buy_quote.protocol_fee_bps.as_ref().unwrap(), "2");

    // Test bucket override: override_token should get 5 bps instead of 2 bps
    tracing::info!("Testing quote with bucket override (5 bps)");
    let override_request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *override_token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    let override_quote = services.submit_quote(&override_request).await.unwrap();

    // Verify override token gets 5 bps (from bucket override) instead of 2 bps
    // (default)
    assert!(override_quote.protocol_fee_bps.is_some());
    assert_eq!(
        override_quote.protocol_fee_bps.as_ref().unwrap(),
        "5",
        "Bucket override should apply 5 bps, not default 2 bps"
    );
}

// Smoke test for the SSE streaming quote endpoint. Posts a quote request to
// /api/v1/quote/stream and asserts that at least one SSE data line parses as
// a valid OrderQuoteResponse carrying a persisted quote id.
async fn quote_stream_smoke(web3: Web3) {
    tracing::info!("Setting up chain state.");
    let mut onchain = OnchainComponents::deploy(web3).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(10u64.eth()).await;
    let [token] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    // Wrap and approve WETH so the trader can later place an order referencing
    // one of the streamed quotes.
    onchain
        .contracts()
        .weth
        .approve(onchain.contracts().allowance, 2u64.eth())
        .from(trader.address())
        .send_and_watch()
        .await
        .unwrap();
    onchain
        .contracts()
        .weth
        .deposit()
        .from(trader.address())
        .value(2u64.eth())
        .send_and_watch()
        .await
        .unwrap();

    tracing::info!("Starting services.");
    let services = Services::new(&onchain).await;
    services.start_protocol(solver).await;

    let request = OrderQuoteRequest {
        from: trader.address(),
        sell_token: *onchain.contracts().weth.address(),
        buy_token: *token.address(),
        side: OrderQuoteSide::Sell {
            sell_amount: SellAmount::BeforeFee {
                value: NonZeroU256::try_from(1u64.eth()).unwrap(),
            },
        },
        ..Default::default()
    };

    tracing::info!("Sending streaming quote request.");
    let stream_url = format!("{API_HOST}{QUOTING_ENDPOINT}/stream");
    let response = reqwest::Client::new()
        .post(&stream_url)
        .json(&request)
        .send()
        .await
        .expect("streaming quote request failed");

    assert_eq!(
        response.status(),
        reqwest::StatusCode::OK,
        "expected 200 from /api/v1/quote/stream"
    );

    let content_type = response
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or_default()
        .to_string();
    assert!(
        content_type.starts_with("text/event-stream"),
        "expected text/event-stream, got {content_type:?}"
    );

    let body = response.text().await.expect("failed to read SSE body");
    tracing::info!(%body, "SSE response body");

    // SSE lines look like: "data: <json>\n"
    let parsed: Vec<OrderQuoteResponse> = body
        .lines()
        .filter(|line| line.starts_with("data:"))
        .filter_map(|line| {
            let json = line.trim_start_matches("data:").trim();
            serde_json::from_str(json).ok()
        })
        .collect();

    assert!(
        !parsed.is_empty(),
        "expected at least one valid OrderQuoteResponse in SSE stream, body was: {body}"
    );

    let weth = *onchain.contracts().weth.address();
    let buy_token = *token.address();
    for response in &parsed {
        assert!(
            response.id.is_some(),
            "streaming quotes should be persisted and carry an id, got {:?}",
            response.id
        );
        assert_eq!(response.from, trader.address());
        assert_eq!(response.quote.sell_token, weth);
        assert_eq!(response.quote.buy_token, buy_token);
        assert!(
            !response.quote.buy_amount.is_zero(),
            "streamed quote should have a non-zero buy amount, got {response:?}"
        );
    }

    // Prove that placing an order with a streamed quote id reuses the persisted
    // quote instead of re-quoting: the quote attached to the order must be the
    // exact one we stored while streaming (same metadata).
    let streamed = parsed
        .iter()
        .find(|response| response.id.is_some())
        .expect("at least one streamed quote should carry an id");
    let quote_id = streamed.id.unwrap();
    let (streamed_metadata,) = crate::database::quote_metadata(services.db(), quote_id)
        .await
        .expect("streamed quote should be persisted");

    tracing::info!("Placing order referencing a streamed quote id.");
    let order = OrderCreation {
        quote_id: Some(quote_id),
        sell_token: weth,
        sell_amount: 1u64.eth(),
        buy_token,
        buy_amount: streamed.quote.buy_amount,
        valid_to: model::time::now_in_epoch_seconds() + 300,
        kind: OrderKind::Sell,
        ..Default::default()
    }
    .sign(
        EcdsaSigningScheme::Eip712,
        &onchain.contracts().domain_separator,
        &trader.signer,
    );
    let order_uid = services.create_order(&order).await.unwrap();

    let order_quote = database::orders::read_quote(
        services.db().acquire().await.unwrap().deref_mut(),
        &database::byte_array::ByteArray(order_uid.0),
    )
    .await
    .unwrap()
    .expect("order should reference a stored quote");
    assert_eq!(
        streamed_metadata, order_quote.metadata,
        "order should reuse the streamed quote, not trigger a re-quote"
    );
}
