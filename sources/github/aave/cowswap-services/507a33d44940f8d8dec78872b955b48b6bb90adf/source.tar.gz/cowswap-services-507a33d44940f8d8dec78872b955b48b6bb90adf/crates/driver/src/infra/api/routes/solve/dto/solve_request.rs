use {
    crate::{
        domain::{
            self,
            competition::{
                self,
                auction,
                order::{
                    self,
                    app_data::{AppData, AppDataHash},
                },
            },
        },
        infra::{Ethereum, tokens},
    },
    eth_domain_types as eth,
    serde::Deserialize,
    serde_with::serde_as,
    std::{
        collections::{HashMap, HashSet},
        sync::Arc,
    },
    tracing::instrument,
};

impl SolveRequest {
    // Deprecated External/Internal arms are retained in case a new
    // order is placed between now and the PR blocking them going live.
    #[allow(deprecated)]
    #[instrument(skip_all)]
    pub async fn into_domain(
        self,
        eth: &Ethereum,
        tokens: &tokens::Fetcher,
        app_data: HashMap<Arc<AppDataHash>, Arc<app_data::ValidatedAppData>>,
    ) -> Result<competition::Auction, Error> {
        let token_addresses: Vec<_> = self
            .tokens
            .iter()
            .map(|token| token.address.into())
            .collect();
        let token_infos = tokens.get(&token_addresses).await;

        // register all tokens where internal buffer trading is allowed
        // for continuous balance monitoring
        tokens.keep_track_of_balances(
            self.tokens
                .iter()
                .filter_map(|t| t.trusted.then_some(&t.address)),
        );

        competition::Auction::new(
            Some(self.id.try_into()?),
            self.orders
                .into_iter()
                .map(|order| {
                    let app_data = match app_data.get(&AppDataHash::from(order.app_data)) {
                        Some(data) => AppData::Full(data.clone()),
                        None => AppData::Hash(AppDataHash::from(order.app_data)),
                    };
                    let partial = if order.partially_fillable {
                        competition::order::Partial::Yes {
                            available: match order.kind {
                                Kind::Sell => {
                                    order.sell_amount.saturating_sub(order.executed).into()
                                }
                                Kind::Buy => order.buy_amount.saturating_sub(order.executed).into(),
                            },
                        }
                    } else {
                        competition::order::Partial::No
                    };
                    competition::Order {
                        data: Arc::new(competition::order::OrderData {
                            uid: order.uid.into(),
                            receiver: order.receiver,
                            created: order.created.into(),
                            valid_to: order.valid_to.into(),
                            buy: eth::Asset {
                                amount: order.buy_amount.into(),
                                token: order.buy_token.into(),
                            },
                            sell: eth::Asset {
                                amount: order.sell_amount.into(),
                                token: order.sell_token.into(),
                            },
                            side: match order.kind {
                                Kind::Sell => competition::order::Side::Sell,
                                Kind::Buy => competition::order::Side::Buy,
                            },
                            kind: match order.class {
                                Class::Market => competition::order::Kind::Market,
                                Class::Limit => competition::order::Kind::Limit,
                            },
                            pre_interactions: order
                                .pre_interactions
                                .into_iter()
                                .map(|interaction| domain::Interaction {
                                    target: interaction.target,
                                    value: interaction.value.into(),
                                    call_data: interaction.call_data.into(),
                                })
                                .collect(),
                            post_interactions: order
                                .post_interactions
                                .into_iter()
                                .map(|interaction| domain::Interaction {
                                    target: interaction.target,
                                    value: interaction.value.into(),
                                    call_data: interaction.call_data.into(),
                                })
                                .collect(),
                            sell_token_balance: match order.sell_token_balance {
                                SellTokenBalance::Erc20 => {
                                    competition::order::SellTokenBalance::Erc20
                                }
                                SellTokenBalance::Internal => {
                                    competition::order::SellTokenBalance::Internal
                                }
                                SellTokenBalance::External => {
                                    competition::order::SellTokenBalance::External
                                }
                            },
                            buy_token_balance: match order.buy_token_balance {
                                BuyTokenBalance::Erc20 => {
                                    competition::order::BuyTokenBalance::Erc20
                                }
                                BuyTokenBalance::Internal => {
                                    competition::order::BuyTokenBalance::Internal
                                }
                            },
                            signature: competition::order::Signature {
                                scheme: match order.signing_scheme {
                                    SigningScheme::Eip712 => {
                                        competition::order::signature::Scheme::Eip712
                                    }
                                    SigningScheme::EthSign => {
                                        competition::order::signature::Scheme::EthSign
                                    }
                                    SigningScheme::PreSign => {
                                        competition::order::signature::Scheme::PreSign
                                    }
                                    SigningScheme::Eip1271 => {
                                        competition::order::signature::Scheme::Eip1271
                                    }
                                },
                                data: order.signature.into(),
                                signer: order.owner,
                            },
                            protocol_fees: order
                                .protocol_fees
                                .into_iter()
                                .map(|policy| match policy {
                                    FeePolicy::Surplus {
                                        factor,
                                        max_volume_factor,
                                    } => competition::order::FeePolicy::Surplus {
                                        factor,
                                        max_volume_factor,
                                    },
                                    FeePolicy::PriceImprovement {
                                        factor,
                                        max_volume_factor,
                                        quote,
                                    } => competition::order::FeePolicy::PriceImprovement {
                                        factor,
                                        max_volume_factor,
                                        quote: quote.into_domain(order.sell_token, order.buy_token),
                                    },
                                    FeePolicy::Volume { factor } => {
                                        competition::order::FeePolicy::Volume { factor }
                                    }
                                })
                                .collect(),
                            quote: order
                                .quote
                                .map(|q| q.into_domain(order.sell_token, order.buy_token)),
                        }),
                        app_data,
                        partial,
                    }
                })
                .collect(),
            self.tokens.into_iter().map(|token| {
                let info = token_infos.get(&token.address.into());
                competition::auction::Token {
                    decimals: info.and_then(|i| i.decimals),
                    symbol: info.and_then(|i| i.symbol.clone()),
                    address: token.address.into(),
                    price: token.price.map(Into::into),
                    available_balance: info.map(|i| i.balance).unwrap_or(0.into()).into(),
                    trusted: token.trusted,
                }
            }),
            self.deadline,
            eth,
            self.surplus_capturing_jit_order_owners
                .into_iter()
                .collect::<HashSet<_>>(),
        )
        .await
        .map_err(Into::into)
    }
}

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("invalid auction ID")]
    InvalidAuctionId,
    #[error("surplus fee is missing for limit order")]
    MissingSurplusFee,
    #[error("invalid tokens in auction")]
    InvalidTokens,
    #[error("invalid order amounts in auction")]
    InvalidAmounts,
    #[error("blockchain error: {0:?}")]
    Blockchain(#[source] crate::infra::blockchain::Error),
}

impl From<auction::InvalidId> for Error {
    fn from(_value: auction::InvalidId) -> Self {
        Self::InvalidAuctionId
    }
}

impl From<auction::Error> for Error {
    fn from(value: auction::Error) -> Self {
        match value {
            auction::Error::Blockchain(err) => Self::Blockchain(err),
        }
    }
}

#[serde_as]
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SolveRequest {
    #[serde_as(as = "serde_with::DisplayFromStr")]
    id: i64,
    tokens: Vec<Token>,
    orders: Vec<Order>,
    deadline: chrono::DateTime<chrono::Utc>,
    #[serde(default)]
    surplus_capturing_jit_order_owners: Vec<eth::Address>,
}

impl SolveRequest {
    pub fn id(&self) -> i64 {
        self.id
    }
}

#[serde_as]
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Token {
    pub address: eth::Address,
    #[serde_as(as = "Option<serde_ext::U256>")]
    pub price: Option<eth::U256>,
    pub trusted: bool,
}

#[serde_as]
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Order {
    #[serde_as(as = "serde_ext::Hex")]
    uid: [u8; order::UID_LEN],
    sell_token: eth::Address,
    buy_token: eth::Address,
    #[serde_as(as = "serde_ext::U256")]
    sell_amount: eth::U256,
    #[serde_as(as = "serde_ext::U256")]
    buy_amount: eth::U256,
    protocol_fees: Vec<FeePolicy>,
    created: u32,
    valid_to: u32,
    kind: Kind,
    receiver: Option<eth::Address>,
    owner: eth::Address,
    partially_fillable: bool,
    /// Always zero if the order is not partially fillable.
    #[serde_as(as = "serde_ext::U256")]
    executed: eth::U256,
    pre_interactions: Vec<Interaction>,
    post_interactions: Vec<Interaction>,
    #[serde(default)]
    sell_token_balance: SellTokenBalance,
    #[serde(default)]
    buy_token_balance: BuyTokenBalance,
    class: Class,
    #[serde_as(as = "serde_ext::Hex")]
    app_data: [u8; order::app_data::APP_DATA_LEN],
    signing_scheme: SigningScheme,
    #[serde_as(as = "serde_ext::Hex")]
    signature: Vec<u8>,
    quote: Option<Quote>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
enum Kind {
    Sell,
    Buy,
}

#[serde_as]
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Interaction {
    target: eth::Address,
    #[serde_as(as = "serde_ext::U256")]
    value: eth::U256,
    #[serde_as(as = "serde_ext::Hex")]
    call_data: Vec<u8>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(rename_all = "camelCase")]
enum SellTokenBalance {
    #[default]
    Erc20,
    #[deprecated(
        note = "Balancer Vault token sources are deprecated and no longer appear in auctions; \
                only erc20 is used"
    )]
    Internal,
    #[deprecated(
        note = "Balancer Vault token sources are deprecated and no longer appear in auctions; \
                only erc20 is used"
    )]
    External,
}

#[derive(Debug, Default, Deserialize)]
#[serde(rename_all = "camelCase")]
enum BuyTokenBalance {
    #[default]
    Erc20,
    #[deprecated(
        note = "Balancer Vault token sources are deprecated and no longer appear in auctions; \
                only erc20 is used"
    )]
    Internal,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "lowercase")]
enum SigningScheme {
    Eip712,
    EthSign,
    PreSign,
    Eip1271,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
enum Class {
    Market,
    Limit,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
enum FeePolicy {
    #[serde(rename_all = "camelCase")]
    Surplus { factor: f64, max_volume_factor: f64 },
    #[serde(rename_all = "camelCase")]
    PriceImprovement {
        factor: f64,
        max_volume_factor: f64,
        quote: Quote,
    },
    #[serde(rename_all = "camelCase")]
    Volume { factor: f64 },
}

#[serde_as]
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Quote {
    #[serde_as(as = "serde_ext::U256")]
    pub sell_amount: eth::U256,
    #[serde_as(as = "serde_ext::U256")]
    pub buy_amount: eth::U256,
    #[serde_as(as = "serde_ext::U256")]
    pub fee: eth::U256,
    pub solver: eth::Address,
}

impl Quote {
    fn into_domain(
        self,
        sell_token: eth::Address,
        buy_token: eth::Address,
    ) -> competition::order::Quote {
        competition::order::Quote {
            sell: eth::Asset {
                amount: self.sell_amount.into(),
                token: sell_token.into(),
            },
            buy: eth::Asset {
                amount: self.buy_amount.into(),
                token: buy_token.into(),
            },
            fee: eth::Asset {
                amount: self.fee.into(),
                token: sell_token.into(),
            },
            solver: self.solver,
        }
    }
}
