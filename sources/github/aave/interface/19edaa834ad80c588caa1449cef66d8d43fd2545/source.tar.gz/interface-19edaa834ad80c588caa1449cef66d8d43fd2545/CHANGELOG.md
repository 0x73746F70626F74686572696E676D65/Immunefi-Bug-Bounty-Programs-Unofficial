# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).



## [3.0.1] - 2025-12-03

### Added
- Migrate reserve-overview page to use the latest v3 sdk


## [3.0.0] - 2025-11-13

### Added
- Update WBTC logo

