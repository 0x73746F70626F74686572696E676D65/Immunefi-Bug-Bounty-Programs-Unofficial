import { Trans } from '@lingui/macro';
import { Box, BoxProps, Button, Paper, PaperProps } from '@mui/material';
import { ReactNode, useState } from 'react';
import { MinusIcon } from 'src/components/icons/MinusIcon';
import { useRootStore } from 'src/store/root';
import { CARD_HEADING_HEIGHT, cardHeaderBandSx, cardHeaderTitleSx } from 'src/utils/cardStyles';
import { DASHBOARD } from 'src/utils/events';

import { toggleLocalStorageClick } from '../../helpers/toggle-local-storage-click';

interface ListWrapperProps {
  titleComponent: ReactNode;
  localStorageName?: string;
  subTitleComponent?: ReactNode;
  subChildrenComponent?: ReactNode;
  /**
   * Second header row. Must render NOTHING at all when it has no content (return null / a falsy
   * branch) — not an empty wrapper element — or its divider will be drawn above blank space, since
   * the row hides itself via `:empty`.
   */
  topInfo?: ReactNode;
  children: ReactNode;
  withTopMargin?: boolean;
  noData?: boolean;
  wrapperSx?: BoxProps['sx'];
  tooltipOpen?: boolean;
  paperSx?: PaperProps['sx'];
  onCollapseChange?: (collapsed: boolean) => void;
}

export const ListWrapper = ({
  children,
  localStorageName,
  titleComponent,
  subTitleComponent,
  subChildrenComponent,
  topInfo,
  withTopMargin,
  noData,
  wrapperSx,
  tooltipOpen,
  paperSx,
  onCollapseChange,
}: ListWrapperProps) => {
  const [isCollapse, setIsCollapse] = useState(
    localStorageName ? localStorage.getItem(localStorageName) === 'true' : false
  );
  const trackEvent = useRootStore((store) => store.trackEvent);

  const handleTrackingEvents = () => {
    if (!isCollapse) {
      switch (localStorageName as string | boolean) {
        case 'borrowAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, {
            visibility: 'Hidden',
            type: 'Available Borrow Assets',
          });
          break;
        case 'borrowedAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, { visibility: 'Hidden', type: 'Borrowed Assets' });
          break;
        case 'supplyAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, {
            visibility: 'Hidden',
            type: 'Available Supply Assets',
          });
          break;
        case 'suppliedAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, { visibility: 'Hidden', type: 'Supplied Assets' });
        default:
          return null;
      }
    } else {
      switch (localStorageName as string | boolean) {
        case 'borrowAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, {
            visibility: 'Show',
            type: 'Available Borrow Assets',
          });
          break;
        case 'borrowedAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, { visibility: 'Show', type: 'Borrowed Assets' });
          break;
        case 'supplyAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, {
            visibility: 'Show',
            type: 'Available Supply Assets',
          });
          break;
        case 'suppliedAssetsDashboardTableCollapse':
          trackEvent(DASHBOARD.TILE_VISBILITY, { visibility: 'Show', type: 'Supplied Assets' });
        default:
          return null;
      }
    }
  };

  const collapsed = isCollapse && !noData;
  const showCollapseButton = !!localStorageName && !noData;

  const collapseText = collapsed ? <Trans>Show</Trans> : <Trans>Hide</Trans>;

  // When nothing renders below it, the band is the card's last visible element: round its bottom
  // corners to the Paper's radius and drop the hairline that would otherwise dangle over nothing.
  const bandIsCardTail = {
    boxShadow: 'none',
    borderBottomLeftRadius: 'inherit',
    borderBottomRightRadius: 'inherit',
  };

  return (
    <>
      <Paper
        variant="table"
        sx={[
          { mt: withTopMargin ? '2rem' : 0 },
          ...(paperSx ? (Array.isArray(paperSx) ? paperSx : [paperSx]) : []),
        ]}
      >
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: '1.25rem',
            ...cardHeaderBandSx,
            pl: { xs: '1rem', xsm: '1.25rem' },
            pr: '1rem',
            borderTopLeftRadius: 'inherit',
            borderTopRightRadius: 'inherit',
            // Empty list: the children box is present but renders nothing.
            '&:has(+ div:empty)': bandIsCardTail,
            // Collapsed: the children box is `display: none`, so it is not `:empty`.
            ...(collapsed ? bandIsCardTail : {}),
            ...wrapperSx,
          }}
        >
          <Box
            sx={{
              display: 'flex',
              flexWrap: 'wrap',
              alignItems: 'center',
              minHeight: CARD_HEADING_HEIGHT,
              // Title type (H4) — scoped to this row, NOT the whole band, or it would flatten the
              // second row's stat typography too. Consumers pass their own heading variant, so
              // neutralise those; control typography (search, selects) keeps its own smaller type.
              ...cardHeaderTitleSx,
              '& .MuiTypography-h1, & .MuiTypography-h2, & .MuiTypography-h3, & .MuiTypography-h4':
                {
                  font: 'inherit',
                  letterSpacing: 'inherit',
                  textTransform: 'capitalize',
                },
            }}
          >
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                minWidth: 0,
                // A card without a subtitle wants the title to span, so its own controls can
                // right-align inside it. One with a subtitle leaves room for it alongside.
                ...(subTitleComponent ? {} : { flex: 1 }),
              }}
            >
              {titleComponent}
            </Box>

            {subTitleComponent && (
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  ...(showCollapseButton && {
                    // Below xsm the Hide button takes the first row, so the subtitle sorts after
                    // it and claims a full line of its own.
                    order: { xs: 1, xsm: 0 },
                    flexBasis: { xs: '100%', xsm: 'auto' },
                    justifyContent: 'flex-end',
                    mt: { xs: '1rem', xsm: 0 },
                  }),
                }}
              >
                {subTitleComponent}
              </Box>
            )}

            {showCollapseButton && (
              <Button
                variant="tertiary"
                size="medium"
                sx={{
                  ml: 'auto',
                  flexShrink: 0,
                  '& .MuiButton-endIcon': { display: { xs: 'none', xsm: 'inline-flex' } },
                }}
                onClick={() => {
                  handleTrackingEvents();

                  if (localStorageName && !noData) {
                    const nextIsCollapse = !isCollapse;
                    toggleLocalStorageClick(isCollapse, setIsCollapse, localStorageName);
                    onCollapseChange?.(nextIsCollapse);
                  }
                }}
                endIcon={
                  // − when expanded; a rotated copy fades in to form a + when collapsed.
                  <Box sx={{ position: 'relative', display: 'inline-flex', color: 'fg-3' }}>
                    <MinusIcon sx={{ fontSize: 18 }} />
                    <MinusIcon
                      sx={{
                        fontSize: 18,
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        transform: 'rotate(90deg)',
                        opacity: collapsed ? 1 : 0,
                        transition: 'opacity 0.2s ease',
                      }}
                    />
                  </Box>
                }
              >
                {collapseText}
              </Button>
            )}
          </Box>

          {/* Second header row. Its divider is drawn as this row's own top border rather than a
              sibling <Divider>, so an empty row takes the rule with it — consumers pass topInfo as
              a fragment that can render nothing (e.g. "Your borrows" with nothing borrowed), which
              is truthy here but produces no DOM. Being a child of the padded band, the rule insets
              to the band's left/right padding instead of running edge to edge like the bottom
              hairline. */}
          {topInfo && (
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                // Matches the stat spacing on the page header (PageHeader.tsx).
                gap: '2.5rem',
                borderTop: '1px solid',
                borderColor: 'border-0',
                pt: '1.25rem',
                '&:empty': { display: 'none' },
                overflowX: tooltipOpen ? 'hidden' : 'auto',
              }}
            >
              {topInfo}
            </Box>
          )}
        </Box>

        <Box sx={{ display: collapsed ? 'none' : 'block' }}>{children}</Box>
      </Paper>

      {/* Filters (e.g. "Show assets with 0 balance") sit below the card, outside it. */}
      {subChildrenComponent && !collapsed && <Box sx={{ mt: '1rem' }}>{subChildrenComponent}</Box>}
    </>
  );
};
