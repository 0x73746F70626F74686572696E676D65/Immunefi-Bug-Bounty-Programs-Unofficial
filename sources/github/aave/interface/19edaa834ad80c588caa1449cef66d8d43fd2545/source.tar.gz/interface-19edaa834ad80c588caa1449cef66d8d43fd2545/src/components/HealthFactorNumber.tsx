import { valueToBigNumber } from '@aave/math-utils';
import { Trans } from '@lingui/macro';
import { Box, Button, Typography, useTheme } from '@mui/material';
import { TypographyProps } from '@mui/material/Typography';
import { BigNumber } from 'bignumber.js';

import { FormattedNumber } from './primitives/FormattedNumber';

interface HealthFactorNumberProps extends TypographyProps {
  value: string;
  onInfoClick?: () => void;
}

export const HealthFactorNumber = ({ value, onInfoClick, ...rest }: HealthFactorNumberProps) => {
  const theme = useTheme();

  const formattedHealthFactor = Number(valueToBigNumber(value).toFixed(2, BigNumber.ROUND_DOWN));
  let healthFactorColor = '';
  if (formattedHealthFactor >= 3) {
    healthFactorColor = theme.vars.palette.success.main;
  } else if (formattedHealthFactor < 1.1) {
    healthFactorColor = theme.vars.palette.error.main;
  } else {
    healthFactorColor = theme.vars.palette.warning.main;
  }

  return (
    <Box sx={{ display: 'inline-flex', alignItems: 'center' }} data-cy={'HealthFactorTopPannel'}>
      {value === '-1' ? (
        <Typography variant="h5" color="success.main">
          ∞
        </Typography>
      ) : (
        <FormattedNumber
          value={formattedHealthFactor}
          sx={{ color: healthFactorColor, ...rest.sx }}
          visibleDecimals={2}
          compact
          {...rest}
        />
      )}

      {onInfoClick && (
        <Button
          onClick={onInfoClick}
          variant="tertiary"
          size="small"
          sx={{ minWidth: 'unset', ml: 2 }}
        >
          <Trans>Risk details</Trans>
        </Button>
      )}
    </Box>
  );
};
