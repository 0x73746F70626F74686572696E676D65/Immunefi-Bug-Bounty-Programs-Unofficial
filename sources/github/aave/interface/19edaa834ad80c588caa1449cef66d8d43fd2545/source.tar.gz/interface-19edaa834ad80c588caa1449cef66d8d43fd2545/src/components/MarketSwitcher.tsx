import { SearchIcon } from '@heroicons/react/outline';
import { t, Trans } from '@lingui/macro';
import {
  Box,
  BoxProps,
  FormControlLabel,
  IconButton,
  InputBase,
  Popover,
  SvgIcon,
  SwipeableDrawer,
  Switch,
  Tooltip,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import React, { useMemo, useRef, useState } from 'react';
import { ArrowUpRightIcon } from 'src/components/icons/ArrowUpRightIcon';
import { ChevronUpDownIcon } from 'src/components/icons/ChevronUpDownIcon';
import { FAVOURITE_STAR_COLOR, StarIcon } from 'src/components/icons/StarIcon';
import { ShimmerText } from 'src/components/ShimmerText';
import { useRootStore } from 'src/store/root';
import { BaseNetworkConfig } from 'src/ui-config/networksConfig';
import { DASHBOARD } from 'src/utils/events';
import { figVars, onAccent } from 'src/utils/figmaColors';
import { insetHighlightActive, insetHighlightBase } from 'src/utils/insetHighlight';
import { motion } from 'src/utils/motion';
import { darkScheme } from 'src/utils/theme';
import { useShallow } from 'zustand/shallow';

import {
  availableMarkets,
  CustomMarket,
  MarketDataType,
  marketsData,
  networkConfigs,
} from '../utils/marketsAndNetworksConfig';

const HOVER_FADE = `${motion.duration.hoverSlow}ms ${motion.easing.standard}`;

const MARKET_TITLE_SX = { fontSize: '1.875rem', mr: '0.5rem' };

export const getMarketInfoById = (marketId: CustomMarket) => {
  const market: MarketDataType = marketsData[marketId as CustomMarket];
  const network: BaseNetworkConfig = networkConfigs[market.chainId];
  const logo = market.logo || network.networkLogoPath;

  return { market, logo };
};

export const getMarketHelpData = (marketName: string) => {
  const testChains = [
    'Görli',
    'Ropsten',
    'Mumbai',
    'Sepolia',
    'Fuji',
    'Testnet',
    'Kovan',
    'Rinkeby',
  ];
  const arrayName = marketName.split(' ');
  const testChainName = arrayName.filter((el) => testChains.indexOf(el) > -1);
  const marketTitle = arrayName.filter((el) => !testChainName.includes(el)).join(' ');

  return {
    name: marketTitle,
    testChainName: testChainName[0],
  };
};

export type Market = {
  marketTitle: string;
  networkName: string;
  networkLogo: string;
  selected?: boolean;
};

type MarketLogoProps = {
  size: number;
  logo: string;
  testChainName?: string;
  sx?: BoxProps;
  className?: string;
};

export const MarketLogo = ({ size, logo, testChainName, sx, className }: MarketLogoProps) => {
  return (
    <Box
      className={className}
      sx={{ mr: 2, width: size, height: size, position: 'relative', ...sx }}
    >
      <img
        src={logo}
        alt=""
        width="100%"
        height="100%"
        style={{ display: 'block', objectFit: 'contain', objectPosition: 'center center' }}
      />

      {testChainName && (
        <Tooltip title={testChainName} arrow>
          <Box
            sx={{
              bgcolor: '#29B6F6',
              width: '16px',
              height: '16px',
              borderRadius: '50%',
              color: onAccent,
              fontSize: '12px',
              lineHeight: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'absolute',
              right: '-2px',
              bottom: '-2px',
            }}
          >
            {testChainName.split('')[0]}
          </Box>
        </Tooltip>
      )}
    </Box>
  );
};

type MarketCategory = 'ethereum' | 'l2' | 'other' | 'legacy';

const MARKET_CATEGORY: Record<string, MarketCategory> = {
  // Ethereum mainnet instances
  Core: 'ethereum',
  Prime: 'ethereum',
  'Aave Horizon': 'ethereum',
  // L2 networks
  Base: 'l2',
  Arbitrum: 'l2',
  OP: 'l2',
  Mantle: 'l2',
  Linea: 'l2',
  Polygon: 'l2',
  Ink: 'l2',
  'X Layer': 'l2',
  Celo: 'l2',
  MegaETH: 'l2',
  // Other L1 chains
  Plasma: 'other',
  Avalanche: 'other',
  'BNB Chain': 'other',
  Aptos: 'other',
  // Legacy markets
  EtherFi: 'legacy',
  ZKsync: 'legacy',
  Soneium: 'legacy',
  Metis: 'legacy',
  Scroll: 'legacy',
  Gnosis: 'legacy',
  Sonic: 'legacy',
};

const getMarketCategory = (marketId: CustomMarket): MarketCategory => {
  const { market } = getMarketInfoById(marketId);
  return MARKET_CATEGORY[market.marketTitle] ?? 'other';
};

// Custom market order requested by BD - TODO: move logic to the backend based on TVL
const MARKET_ORDER_BY_TITLE: { [title: string]: number } = {
  Core: 0,
  Prime: 1,
  Plasma: 2,
  Base: 3,
  Arbitrum: 4,
  Mantle: 5,
  Ink: 6,
  Avalanche: 7,
  'Aave Horizon': 8,
  'BNB Chain': 9,
  'X Layer': 10,
  Polygon: 11,
  Aptos: 12,
  Linea: 13,
  OP: 14,
  MegaETH: 15,
  Celo: 16,
  Scroll: 17,
  ZKsync: 18,
  Soneium: 19,
  Metis: 20,
  EtherFi: 21,
  Gnosis: 22,
  Sonic: 23,
};

const getMarketOrder = (marketId: CustomMarket): number => {
  const { market } = getMarketInfoById(marketId);
  return MARKET_ORDER_BY_TITLE[market.marketTitle] ?? 999;
};

/**
 * The line under the market name. Every single-market network says the same thing, so they share
 * one translatable string that takes the network's name; the Ethereum instances sit side by side
 * and have to distinguish themselves, so those are written out.
 *
 * Keyed by market id rather than title, because titles collide — `Avalanche` and `Polygon` each
 * name both a v2 and a v3 market.
 */
const onNetwork = (network: string) => <Trans>Supply and borrow core assets on {network}.</Trans>;

const MARKET_DESCRIPTIONS: Partial<Record<CustomMarket, React.ReactNode>> = {
  [CustomMarket.proto_mainnet_v3]: (
    <Trans>Supply and borrow the widest range of assets in Aave&apos;s deepest market.</Trans>
  ),
  [CustomMarket.proto_lido_v3]: (
    <Trans>Supply and borrow ETH-correlated and blue-chip assets.</Trans>
  ),
  [CustomMarket.proto_horizon_v3]: (
    <Trans>Supply and borrow stablecoins against tokenized real-world assets.</Trans>
  ),
  [CustomMarket.proto_arbitrum_v3]: onNetwork('Arbitrum'),
  [CustomMarket.proto_avalanche_v3]: onNetwork('Avalanche'),
  [CustomMarket.proto_base_v3]: onNetwork('Base'),
  [CustomMarket.proto_bnb_v3]: onNetwork('BNB Chain'),
  [CustomMarket.proto_celo_v3]: onNetwork('Celo'),
  [CustomMarket.proto_gnosis_v3]: onNetwork('Gnosis'),
  [CustomMarket.proto_ink_v3]: onNetwork('Ink'),
  [CustomMarket.proto_linea_v3]: onNetwork('Linea'),
  [CustomMarket.proto_mantle_v3]: onNetwork('Mantle'),
  [CustomMarket.proto_megaeth_v3]: onNetwork('MegaETH'),
  [CustomMarket.proto_metis_v3]: onNetwork('Metis'),
  [CustomMarket.proto_monad_v3]: onNetwork('Monad'),
  [CustomMarket.proto_optimism_v3]: onNetwork('Optimism'),
  [CustomMarket.proto_plasma_v3]: onNetwork('Plasma'),
  [CustomMarket.proto_polygon_v3]: onNetwork('Polygon'),
  [CustomMarket.proto_scroll_v3]: onNetwork('Scroll'),
  [CustomMarket.proto_soneium_v3]: onNetwork('Soneium'),
  [CustomMarket.proto_sonic_v3]: onNetwork('Sonic'),
  [CustomMarket.proto_xlayer_v3]: onNetwork('X Layer'),
  [CustomMarket.proto_zksync_v3]: onNetwork('ZKsync Era'),
  [CustomMarket.proto_aptos_v3]: onNetwork('Aptos'),
};

// Trailing "this leaves the app" marker, shared by the external-market rows and the V4 links.
const EXTERNAL_LINK_ICON = (
  <ArrowUpRightIcon sx={{ fontSize: '16px', color: 'fg-3', ml: 0.5, flexShrink: 0 }} />
);

export const AAVE_PRO_URL = 'https://pro.aave.com/';

type V4Link = {
  id: string;
  label: string;
  logo: string;
  url: string;
  section: Extract<MarketCategory, 'ethereum' | 'other'>;
};

// External links to V4 instances, rendered alongside the V3 markets of the same section.
const V4_LINKS: V4Link[] = [
  {
    id: 'aave_pro_v4',
    label: 'Aave Pro',
    logo: '/icons/markets/aave-pro.png',
    url: AAVE_PRO_URL,
    section: 'ethereum',
  },
  {
    id: 'aave_pro_avalanche_v4',
    label: 'Avalanche',
    logo: '/icons/networks/avalanche.svg',
    url: AAVE_PRO_URL,
    section: 'other',
  },
  {
    id: 'aave_pro_arc_v4',
    label: 'Arc',
    logo: '/icons/networks/arc.svg',
    url: AAVE_PRO_URL,
    section: 'other',
  },
];

interface MarketSwitcherProps {
  /**
   * Drops the current market's blurb from under the trigger. For pages whose header needs that
   * line to describe the page rather than the market — the copy then belongs in the page header's
   * own description slot, outside this button.
   */
  hideDescription?: boolean;
}

export const MarketSwitcher = ({ hideDescription }: MarketSwitcherProps) => {
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showLegacy, setShowLegacy] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const triggerRowRef = useRef<HTMLDivElement>(null);

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [trackEvent, currentMarket, setCurrentMarket] = useRootStore(
    useShallow((store) => [store.trackEvent, store.currentMarket, store.setCurrentMarket])
  );
  const isFavoriteMarket = useRootStore((store) => store.isFavoriteMarket);
  const toggleFavoriteMarket = useRootStore((store) => store.toggleFavoriteMarket);
  const favoriteMarkets = useRootStore((store) => store.favoriteMarkets);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSearchQuery('');
  };

  const handleSelectMarket = (marketId: CustomMarket) => {
    const market = marketsData[marketId];
    trackEvent(DASHBOARD.CHANGE_MARKET, { market: marketId });

    if (market.externalUrl) {
      window.open(market.externalUrl, '_blank');
      return;
    }

    setCurrentMarket(marketId);
    handleClose();
  };

  const handleStarClick = (e: React.MouseEvent, marketId: CustomMarket) => {
    e.stopPropagation();
    toggleFavoriteMarket(marketId);
  };

  // Filter to V3 markets only
  const v3Markets = useMemo(() => availableMarkets.filter((id) => marketsData[id].v3), []);

  const { pinned, ethereum, l2, other, legacy, v4Ethereum, v4Other } = useMemo(() => {
    const query = searchQuery.toLowerCase();
    const filtered = v3Markets.filter((id) => {
      const { market } = getMarketInfoById(id);
      return market.marketTitle.toLowerCase().includes(query);
    });

    const sorted = filtered.slice().sort((a, b) => getMarketOrder(a) - getMarketOrder(b));
    const pinned = sorted.filter((id) => isFavoriteMarket(id));
    const pinnedSet = new Set(pinned);
    const unpinned = sorted.filter((id) => !pinnedSet.has(id));

    const v4Links = V4_LINKS.filter((link) => link.label.toLowerCase().includes(query));

    return {
      pinned,
      ethereum: unpinned.filter((id) => getMarketCategory(id) === 'ethereum'),
      l2: unpinned.filter((id) => getMarketCategory(id) === 'l2'),
      other: unpinned.filter((id) => getMarketCategory(id) === 'other'),
      legacy: unpinned.filter((id) => getMarketCategory(id) === 'legacy'),
      v4Ethereum: v4Links.filter((link) => link.section === 'ethereum'),
      v4Other: v4Links.filter((link) => link.section === 'other'),
    };
  }, [v3Markets, searchQuery, favoriteMarkets, isFavoriteMarket]);

  // --- Render helpers ---

  const renderRowLogo = (src: string) => (
    <Box sx={{ width: '1.5rem', height: '1.5rem', mr: '0.75rem', flexShrink: 0 }}>
      <img
        src={src}
        alt=""
        width="100%"
        height="100%"
        style={{ display: 'block', objectFit: 'contain' }}
      />
    </Box>
  );

  const renderGridItem = (marketId: CustomMarket, isMobile?: boolean, width = '33.33%') => {
    const { market, logo } = getMarketInfoById(marketId);
    const marketNaming = getMarketHelpData(market.marketTitle);
    const isFavorite = isFavoriteMarket(marketId);
    const isSelected = marketId === currentMarket;
    return (
      <Box
        key={marketId}
        role="button"
        tabIndex={0}
        data-cy={`marketSelector_${marketId}`}
        onClick={() => handleSelectMarket(marketId)}
        onKeyDown={(e: React.KeyboardEvent) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleSelectMarket(marketId);
          }
        }}
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: '2.5rem',
          py: '0.5rem',
          px: '0.75rem',
          width: isMobile ? '50%' : width,
          boxSizing: 'border-box',
          borderRadius: '8px',
          cursor: 'pointer',
          // Hover/selected highlight on an inset pseudo-element so adjacent options keep a gap
          // (shared recipe with the dropdown menu items — see insetHighlight.ts). The current
          // market holds the fill via restFill; others take the same fill on hover.
          ...insetHighlightBase({
            theme,
            radius: '8px',
            inset: '1px',
            restFill: isSelected ? figVars['selected'] : undefined,
          }),
          ...(isSelected
            ? {}
            : {
                // Row highlight on hover AND on keyboard focus — of the row itself or its star
                // button (`:focus-within`) — so tabbing through always shows where you are.
                '&:hover::before, &:focus-within::before': insetHighlightActive(
                  figVars['selected']
                ),
              }),
          // Star: always visible on mobile, hover-reveal on desktop; also reveal it whenever the
          // row or the star button is focused, so keyboard users can see the favourite toggle.
          '& .grid-fav-btn': {
            opacity: isMobile || isFavorite ? 1 : 0,
            transition: `opacity ${HOVER_FADE}`,
          },
          '&:hover .grid-fav-btn, &:focus-within .grid-fav-btn': {
            opacity: 1,
          },
          // Keyboard focus lands on the star itself: ring it with an outline so it reads as focused
          // (global ripple is disabled — add our own affordance).
          '& .grid-fav-btn:focus-visible': {
            opacity: 1,
            // Same focus ring the buttons use (MuiButton root in theme.tsx).
            outline: `2px solid ${figVars['fg-1']}`,
            outlineOffset: '2px',
          },
          // The empty (non-favourited) star fills a step stronger (fg-4 → fg-3) on hover / focus.
          ...(isFavorite
            ? {}
            : {
                '&:hover .grid-fav-btn .MuiSvgIcon-root, & .grid-fav-btn:focus-visible .MuiSvgIcon-root':
                  {
                    color: figVars['fg-3'],
                  },
              }),
        }}
      >
        {renderRowLogo(logo)}
        <Typography
          noWrap
          variant="h5"
          color="fg-1"
          sx={{
            flex: '1 1 0',
            minWidth: 0,
          }}
        >
          {marketNaming.name} {market.isFork ? 'Fork' : ''}
        </Typography>
        {market.externalUrl && EXTERNAL_LINK_ICON}
        <IconButton
          className="grid-fav-btn"
          size="small"
          onClick={(e) => handleStarClick(e, marketId)}
          sx={{ padding: '1px', ml: 0.5, flexShrink: 0 }}
        >
          <StarIcon
            sx={{
              fontSize: '16px',
              color: isFavorite ? FAVOURITE_STAR_COLOR : 'fg-4',
            }}
          />
        </IconButton>
      </Box>
    );
  };

  const handleSelectV4Link = (link: V4Link) => {
    trackEvent(DASHBOARD.CHANGE_MARKET, { market: link.id });
    window.open(link.url, '_blank');
  };

  const renderLinkRow = (
    {
      id,
      logo,
      label,
      href,
      badge,
      onSelect,
    }: {
      id?: string;
      logo: string;
      label: React.ReactNode;
      href: string;
      badge?: React.ReactNode;
      onSelect?: () => void;
    },
    isMobile?: boolean,
    width = '33.33%'
  ) => {
    const select = onSelect ?? (() => window.open(href, '_blank'));
    return (
      <Box
        key={id ?? href}
        role="button"
        tabIndex={0}
        data-cy={id ? `marketSelector_${id}` : undefined}
        onClick={select}
        onKeyDown={(e: React.KeyboardEvent) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            select();
          }
        }}
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: '2.5rem',
          py: '0.5rem',
          px: '0.75rem',
          width: isMobile ? '50%' : width,
          boxSizing: 'border-box',
          borderRadius: '8px',
          cursor: 'pointer',
          // Hover highlight on an inset pseudo-element, matching the market rows (insetHighlight.ts).
          ...insetHighlightBase({ theme, radius: '8px', inset: '1px' }),
          '&:hover::before': insetHighlightActive(figVars['selected']),
        }}
      >
        {renderRowLogo(logo)}
        {badge ? (
          <Box
            sx={{ flex: '1 1 0', minWidth: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <Typography noWrap variant="h5" color="fg-1" sx={{ minWidth: 0 }}>
              {label}
            </Typography>
            {badge}
          </Box>
        ) : (
          <Typography noWrap variant="h5" color="fg-1" sx={{ flex: '1 1 0', minWidth: 0 }}>
            {label}
          </Typography>
        )}
        {EXTERNAL_LINK_ICON}
      </Box>
    );
  };

  const renderV4Link = (link: V4Link, isMobile?: boolean, width = '33.33%') =>
    renderLinkRow(
      {
        id: link.id,
        logo: link.logo,
        label: link.label,
        href: link.url,
        badge: (
          <Box
            component="span"
            sx={{
              width: 26,
              height: 16,
              borderRadius: '50px',
              bgcolor: 'rgba(151, 142, 255, 0.1)',
              color: '#978eff',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              fontSize: '10px',
              fontWeight: 700,
              lineHeight: 1,
              letterSpacing: 0,
            }}
          >
            V4
          </Box>
        ),
        onSelect: () => handleSelectV4Link(link),
      },
      isMobile,
      width
    );

  const sectionHeader = (label: React.ReactNode) => (
    <Typography
      sx={{
        color: 'fg-3',
        fontSize: '0.6875rem',
        fontWeight: 600,
        lineHeight: '120%',
        letterSpacing: '0.00063rem',
        textTransform: 'uppercase',
        fontFeatureSettings: "'cv11' on",
      }}
    >
      {label}
    </Typography>
  );

  const renderSection = (title: React.ReactNode, children: React.ReactNode) => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
      {sectionHeader(title)}
      <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>{children}</Box>
    </Box>
  );

  const noResults =
    pinned.length === 0 &&
    ethereum.length === 0 &&
    l2.length === 0 &&
    other.length === 0 &&
    v4Ethereum.length === 0 &&
    v4Other.length === 0;

  const renderSelectorContent = (mobile: boolean) => (
    <>
      {/* Search — flush to the top edge; the desktop popover keeps a 1px ring, the mobile sheet
          drops it so it doesn't read as two stray rules across the full-bleed width. */}
      <Box
        sx={{
          height: '3.23rem',
          px: '1rem',
          boxShadow: mobile ? 'none' : `0 0 0 1px ${figVars['border-1']}`,
          display: 'flex',
          alignItems: 'center',
          flexShrink: 0,
        }}
      >
        <InputBase
          inputRef={searchRef}
          placeholder={t`Search markets...`}
          inputProps={{ 'aria-label': t`Search markets` }}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          startAdornment={
            <SvgIcon sx={{ fontSize: 18, color: 'fg-4', mr: '0.5rem' }}>
              <SearchIcon />
            </SvgIcon>
          }
          sx={{
            flex: 1,
            color: 'fg-1',
            fontSize: '0.875rem',
            // Safari zooms a focused input under 16px; keyed on pointer, not width, so tablets count.
            '@media (pointer: coarse)': { fontSize: '1rem' },
            fontWeight: 400,
            lineHeight: 1,
            '& input::placeholder': {
              color: 'fg-4',
              opacity: 1,
            },
          }}
        />
      </Box>

      {/* Contents box — 1rem padding all sides, 1.5rem between sections */}
      <Box
        sx={{
          p: '1rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.5rem',
          ...(mobile && { overflowY: 'auto', flex: 1 }),
        }}
      >
        {/* Favourites */}
        {pinned.length > 0 &&
          renderSection(
            <Trans>Favourites</Trans>,
            pinned.map((id) => renderGridItem(id, mobile))
          )}

        {/* Ethereum + V4 links */}
        {(ethereum.length > 0 || v4Ethereum.length > 0) &&
          renderSection(
            <Trans>Ethereum</Trans>,
            <>
              {ethereum.map((id) => renderGridItem(id, mobile))}
              {v4Ethereum.map((link) => renderV4Link(link, mobile))}
            </>
          )}

        {/* L1 Networks */}
        {(other.length > 0 || v4Other.length > 0) &&
          renderSection(
            <Trans>L1 Networks</Trans>,
            <>
              {other.map((id) => renderGridItem(id, mobile))}
              {v4Other.map((link) => renderV4Link(link, mobile))}
            </>
          )}

        {/* L2 Networks */}
        {l2.length > 0 &&
          renderSection(
            <Trans>L2 Networks</Trans>,
            l2.map((id) => renderGridItem(id, mobile))
          )}

        {/* Legacy */}
        {showLegacy &&
          renderSection(
            <Trans>Legacy</Trans>,
            legacy.map((id) => renderGridItem(id, mobile))
          )}

        {/* No results */}
        {noResults && (
          <Box sx={{ px: 4, py: 3, textAlign: 'center' }}>
            <Typography variant="description" color="fg-2">
              <Trans>No markets found</Trans>
            </Typography>
          </Box>
        )}

        {/* Show legacy markets — label + switch as a single control */}
        <FormControlLabel
          labelPlacement="start"
          control={
            <Switch
              checked={showLegacy}
              onChange={(e) => setShowLegacy(e.target.checked)}
              inputProps={{ 'aria-label': t`Show legacy markets` }}
            />
          }
          label={<Trans>Show legacy markets</Trans>}
          sx={{
            m: 0,
            alignSelf: 'flex-start',
            '& .MuiFormControlLabel-label': {
              color: 'fg-2',
              fontSize: '0.875rem',
              fontWeight: 400,
              lineHeight: '100%',
            },
          }}
        />
      </Box>
    </>
  );

  // --- Current market display (trigger) ---

  const { market: currentMarketData, logo: currentLogo } = getMarketInfoById(currentMarket);
  const currentMarketNaming = getMarketHelpData(currentMarketData.marketTitle);

  return (
    <>
      {/* Trigger */}
      <Box
        role="button"
        tabIndex={0}
        onClick={handleOpen}
        onKeyDown={(e: React.KeyboardEvent) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleOpen();
          }
        }}
        aria-haspopup="true"
        aria-expanded={open}
        aria-label={t`Select market`}
        data-cy="marketSelector"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onFocus={(e: React.FocusEvent<HTMLElement>) =>
          setFocused(e.target.matches(':focus-visible'))
        }
        onBlur={() => setFocused(false)}
        sx={{
          mr: 2,
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          color: 'fg-1',
        }}
      >
        <Box ref={triggerRowRef} sx={{ display: 'flex', alignItems: 'center' }}>
          <MarketLogo
            size={28}
            logo={currentLogo}
            testChainName={currentMarketNaming.testChainName}
            sx={{ width: '1.75rem', height: '1.75rem', mr: '0.75rem' }}
          />
          <ShimmerText
            variant="h2"
            sx={MARKET_TITLE_SX}
            active={hovered || focused || open}
            text={`${currentMarketNaming.name}${currentMarketData.isFork ? ' Fork' : ''}`}
          />
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              height: '1.5rem',
              px: '0.625rem',
              borderRadius: '1.5rem',
              mt: '0.3125rem',
              background: 'rgba(147, 145, 254, 0.16)',
              '@supports (color: color(display-p3 0 0 0))': {
                background: 'color(display-p3 0.5765 0.5686 0.9686 / 0.16)',
              },
            }}
          >
            <Typography
              sx={{
                color: '#8374FF',
                fontSize: '1rem',
                fontWeight: 600,
                lineHeight: '1.125rem',
                '@supports (color: color(display-p3 0 0 0))': {
                  color: 'color(display-p3 0.5033 0.4581 1)',
                },
              }}
            >
              {currentMarketData.v3 ? 'V3' : 'V2'}
            </Typography>
          </Box>
          <ChevronUpDownIcon sx={{ ml: 1, color: 'fg-3', mt: '0.3125rem' }} />
        </Box>

        {!hideDescription && MARKET_DESCRIPTIONS[currentMarket] && (
          <Typography
            variant="description"
            sx={{
              color: 'fg-3',
              mt: '1rem',
              wordWrap: 'break-word',
              whiteSpace: 'normal',
              maxWidth: '100%',
            }}
          >
            {MARKET_DESCRIPTIONS[currentMarket]}
          </Typography>
        )}
      </Box>

      {/* Market selector content (shared between Popover and Drawer) */}
      {isMobile ? (
        <SwipeableDrawer
          anchor="bottom"
          open={open}
          onClose={handleClose}
          onOpen={handleOpen}
          disableSwipeToOpen
          PaperProps={{
            sx: {
              bgcolor: 'bg-3',
              borderTopLeftRadius: '16px',
              borderTopRightRadius: '16px',
              maxHeight: '85vh',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
            },
          }}
        >
          {/* Drag handle */}
          <Box sx={{ display: 'flex', justifyContent: 'center', pt: 1.5, pb: 0.5 }}>
            <Box
              sx={{
                width: 36,
                height: 4,
                borderRadius: '2px',
                bgcolor: 'border-2',
              }}
            />
          </Box>
          {renderSelectorContent(true)}
        </SwipeableDrawer>
      ) : (
        <Popover
          open={open}
          anchorEl={triggerRowRef.current}
          onClose={handleClose}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
          transformOrigin={{ vertical: 'top', horizontal: 'left' }}
          TransitionProps={{
            onEntered: () => searchRef.current?.focus(),
          }}
          slotProps={{
            paper: {
              variant: 'modal',
              elevation: 0,
              sx: {
                width: '34rem',
                bgcolor: 'bg-3',
                ...darkScheme({ backgroundColor: figVars['bg-3'] }),
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                mt: '1.25rem',
                // Offset the panel 1rem to the left of the trigger's left edge.
                ml: '-1rem',
              },
            },
          }}
        >
          {renderSelectorContent(false)}
        </Popover>
      )}
    </>
  );
};
