import { Box, Divider, Skeleton, Typography } from '@mui/material';
import { ReactNode } from 'react';
import { IsolatedEnabledBadge } from 'src/components/isolationMode/IsolatedBadge';
import { useAssetCaps } from 'src/hooks/useAssetCaps';
import { CustomMarket } from 'src/ui-config/marketsConfig';

import { Link, ROUTES } from '../primitives/Link';
import { TokenIcon } from '../primitives/TokenIcon';

interface ListMobileItemProps {
  warningComponent?: ReactNode;
  children: ReactNode;
  symbol?: string;
  iconSymbol?: string;
  name?: string;
  underlyingAsset?: string;
  loading?: boolean;
  currentMarket?: CustomMarket;
  showSupplyCapTooltips?: boolean;
  showBorrowCapTooltips?: boolean;
  showDebtCeilingTooltips?: boolean;
  isIsolated: boolean;
  onIconError?: () => void;
}

export const ListMobileItem = ({
  children,
  warningComponent,
  symbol,
  iconSymbol,
  name,
  underlyingAsset,
  loading,
  currentMarket,
  showSupplyCapTooltips = false,
  showBorrowCapTooltips = false,
  showDebtCeilingTooltips = false,
  isIsolated,
  onIconError,
}: ListMobileItemProps) => {
  const { supplyCap, borrowCap, debtCeiling } = useAssetCaps();
  return (
    <Box sx={{ '&:first-of-type > hr': { display: 'none' } }}>
      <Divider />
      <Box
        sx={{
          px: 4,
          pt: 4,
          pb: 6,
          '& .row-caption': {
            color: 'fg-3',
            '& .MuiSvgIcon-root': { color: 'fg-4' },
            '& .MuiSvgIcon-root:hover': { color: 'fg-2' },
          },
        }}
      >
        {/* Cards that bring their own heading (the staking list) render nothing here, and an empty
            header still contributed its `mb`, leaving twice the padding above the card's first row
            as below its last one. */}
        <Box
          sx={{
            mb: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            '&:empty': { display: 'none' },
          }}
        >
          {loading ? (
            <Box sx={{ display: 'inline-flex', alignItems: 'center' }}>
              <Skeleton variant="circular" width={40} height={40} />
              <Box sx={{ ml: 2 }}>
                <Skeleton width={100} height={24} />
              </Box>
            </Box>
          ) : (
            symbol &&
            underlyingAsset &&
            name &&
            currentMarket &&
            iconSymbol && (
              <Link
                href={ROUTES.reserveOverview(underlyingAsset, currentMarket)}
                sx={{ display: 'inline-flex', alignItems: 'center' }}
              >
                <TokenIcon symbol={iconSymbol} fontSize="large" onError={onIconError} />
                <Box sx={{ ml: 2 }}>
                  <Typography variant="h4">{name}</Typography>
                  <Box display="flex" alignItems="center">
                    <Typography variant="subheader2" color="fg-3">
                      {symbol}
                    </Typography>
                    {isIsolated && (
                      <span style={{ marginLeft: '8px' }}>
                        <IsolatedEnabledBadge />
                      </span>
                    )}
                  </Box>
                </Box>
                {showSupplyCapTooltips && supplyCap.displayMaxedTooltip({ supplyCap })}
                {showBorrowCapTooltips && borrowCap.displayMaxedTooltip({ borrowCap })}
                {showDebtCeilingTooltips && debtCeiling.displayMaxedTooltip({ debtCeiling })}
              </Link>
            )
          )}
          {warningComponent}
        </Box>
        {children}
      </Box>
    </Box>
  );
};
