import { calculateHealthFactorFromBalancesBigUnits, valueToBigNumber } from '@aave/math-utils';
import { Trans } from '@lingui/macro';
import { Alert, AlertTitle, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import {
  ExtendedFormattedUser,
  useAppDataContext,
} from 'src/hooks/app-data-provider/useAppDataProvider';
import { useAssetCaps } from 'src/hooks/useAssetCaps';
import { useModalContext } from 'src/hooks/useModal';
import { useZeroLTVBlockingWithdraw } from 'src/hooks/useZeroLTVBlockingWithdraw';
import { hasNonZeroEffectiveLtv } from 'src/utils/hfUtils';

import { GasEstimationError } from '../FlowCommons/GasEstimationError';
import { ModalWrapperProps } from '../FlowCommons/ModalWrapper';
import { TxSuccessView } from '../FlowCommons/Success';
import { DetailsHFLine, DetailsNumberLine, TxModalDetails } from '../FlowCommons/TxModalDetails';
import { CollateralOptionsSelector } from '../Supply/CollateralOptionsSelector';
import { IsolationModeWarning } from '../Warnings/IsolationModeWarning';
import { CollateralChangeActions } from './CollateralChangeActions';

export type CollateralChangeModalContentProps = {
  underlyingAsset: string;
};

export enum ErrorType {
  DO_NOT_HAVE_SUPPLIES_IN_THIS_CURRENCY,
  CAN_NOT_USE_THIS_CURRENCY_AS_COLLATERAL,
  CAN_NOT_SWITCH_USAGE_AS_COLLATERAL_MODE,
  ZERO_LTV_WITHDRAW_BLOCKED,
  ZERO_LTV_ENABLE_EMODE_FIRST,
}

export const CollateralChangeModalContent = ({
  poolReserve,
  userReserve,
  isWrongNetwork,
  symbol,
  user,
}: ModalWrapperProps & { user: ExtendedFormattedUser }) => {
  const { gasLimit, mainTxState: collateralChangeTxState, txError } = useModalContext();
  const { debtCeiling } = useAssetCaps();
  const { reserves, eModes, poolSupportsMulticall } = useAppDataContext();

  const [collateralEnabled, setCollateralEnabled] = useState(
    userReserve.usageAsCollateralEnabledOnUser
  );
  const [selectedEmodeId, setSelectedEmodeId] = useState<number>(user.userEmodeCategoryId);

  // Check if asset has non-zero LTV (base or in user's active e-mode)
  const userEMode = poolReserve.eModes?.find((e) => e.id === user?.userEmodeCategoryId);
  const hasNonZeroLtv = hasNonZeroEffectiveLtv({
    baseLTVasCollateral: poolReserve.baseLTVasCollateral,
    isInEmode: !!user?.isInEmode,
    emodeEntry: userEMode,
    isEModeIsolated: !!eModes[user.userEmodeCategoryId]?.isolated,
  });

  // Find e-mode categories where this asset can be used as collateral with non-zero LTV
  const collateralEmodeCategories =
    poolReserve.eModes?.filter((e) => e.collateralEnabled && !e.ltvzeroEnabled) ?? [];

  // Health factor calculations
  const usageAsCollateralModeAfterSwitch = !userReserve.usageAsCollateralEnabledOnUser;
  const currenttotalCollateralMarketReferenceCurrency = valueToBigNumber(
    user.totalCollateralMarketReferenceCurrency
  );

  // Messages
  const showEnableIsolationModeMsg = !poolReserve.isIsolated && usageAsCollateralModeAfterSwitch;
  const showDisableIsolationModeMsg = !poolReserve.isIsolated && !usageAsCollateralModeAfterSwitch;
  const showEnterIsolationModeMsg = poolReserve.isIsolated && usageAsCollateralModeAfterSwitch;
  const showExitIsolationModeMsg = poolReserve.isIsolated && !usageAsCollateralModeAfterSwitch;

  const totalCollateralAfterSwitchETH = currenttotalCollateralMarketReferenceCurrency[
    usageAsCollateralModeAfterSwitch ? 'plus' : 'minus'
  ](userReserve.underlyingBalanceMarketReferenceCurrency);

  const healthFactorAfterSwitch = calculateHealthFactorFromBalancesBigUnits({
    collateralBalanceMarketReferenceCurrency: totalCollateralAfterSwitchETH,
    borrowBalanceMarketReferenceCurrency: user.totalBorrowsMarketReferenceCurrency,
    currentLiquidationThreshold: user.currentLiquidationThreshold,
  });

  const assetsBlockingWithdraw = useZeroLTVBlockingWithdraw();

  // error handling
  let blockingError: ErrorType | undefined = undefined;
  if (assetsBlockingWithdraw.length > 0 && !assetsBlockingWithdraw.includes(poolReserve.symbol)) {
    blockingError = ErrorType.ZERO_LTV_WITHDRAW_BLOCKED;
  } else if (valueToBigNumber(userReserve.underlyingBalance).eq(0)) {
    blockingError = ErrorType.DO_NOT_HAVE_SUPPLIES_IN_THIS_CURRENCY;
  } else if (
    !userReserve.usageAsCollateralEnabledOnUser &&
    !hasNonZeroLtv &&
    collateralEmodeCategories.length > 0 &&
    // Enabling collateral on a 0 LTV asset only works if the e-mode switch
    // lands first, which needs Pool.multicall. Without it, fall through to the
    // plain "can not use as collateral" block, as before bundling existed.
    poolSupportsMulticall
  ) {
    blockingError = ErrorType.ZERO_LTV_ENABLE_EMODE_FIRST;
  } else if (!userReserve.usageAsCollateralEnabledOnUser && !hasNonZeroLtv) {
    blockingError = ErrorType.CAN_NOT_USE_THIS_CURRENCY_AS_COLLATERAL;
  } else if (
    userReserve.usageAsCollateralEnabledOnUser &&
    user.totalBorrowsMarketReferenceCurrency !== '0' &&
    healthFactorAfterSwitch.lte('1')
  ) {
    blockingError = ErrorType.CAN_NOT_SWITCH_USAGE_AS_COLLATERAL_MODE;
  }

  // error render handling
  const BlockingError: React.FC = () => {
    switch (blockingError) {
      case ErrorType.DO_NOT_HAVE_SUPPLIES_IN_THIS_CURRENCY:
        return <Trans>You do not have supplies in this currency</Trans>;
      case ErrorType.CAN_NOT_USE_THIS_CURRENCY_AS_COLLATERAL:
        return <Trans>You can not use this currency as collateral</Trans>;
      case ErrorType.CAN_NOT_SWITCH_USAGE_AS_COLLATERAL_MODE:
        return (
          <Trans>
            You can not switch usage as collateral mode for this currency, because it will cause
            collateral call
          </Trans>
        );
      case ErrorType.ZERO_LTV_ENABLE_EMODE_FIRST:
        return null;
      case ErrorType.ZERO_LTV_WITHDRAW_BLOCKED:
        return (
          <Trans>
            Assets with zero LTV ({assetsBlockingWithdraw.join(', ')}) must be withdrawn or disabled
            as collateral to perform this action
          </Trans>
        );
      default:
        return null;
    }
  };

  // Effect to handle changes in collateral mode after switch as polling is fetching reserve state different after successful tx
  useEffect(() => {
    if (collateralChangeTxState.success) {
      setCollateralEnabled(usageAsCollateralModeAfterSwitch);
    }
  }, [collateralChangeTxState.success, collateralEnabled]);

  if (collateralChangeTxState.success)
    return <TxSuccessView collateral={collateralEnabled} symbol={poolReserve.symbol} />;

  return (
    <>
      {showEnableIsolationModeMsg && (
        <Alert severity="warning" data-size="small" sx={{ width: '100%', mb: 3 }}>
          <Trans>
            Enabling this asset as collateral increases your borrowing power and Health Factor.
            However, it can get liquidated if your health factor drops below 1.
          </Trans>
        </Alert>
      )}

      {showDisableIsolationModeMsg && (
        <Alert severity="warning" data-size="small" sx={{ width: '100%', mb: 3 }}>
          <Trans>
            Disabling this asset as collateral affects your borrowing power and Health Factor.
          </Trans>
        </Alert>
      )}

      {showEnterIsolationModeMsg && <IsolationModeWarning asset={poolReserve.symbol} />}

      {showExitIsolationModeMsg && (
        <Alert severity="info" data-size="small" sx={{ width: '100%', mb: 3 }}>
          <Trans>You will exit isolation mode and other tokens can now be used as collateral</Trans>
        </Alert>
      )}

      {poolReserve.isIsolated && debtCeiling.determineWarningDisplay({ debtCeiling })}

      <TxModalDetails gasLimit={gasLimit}>
        <DetailsNumberLine
          symbol={poolReserve.symbol}
          iconSymbol={poolReserve.iconSymbol}
          description={<Trans>Supply balance</Trans>}
          value={userReserve.underlyingBalance}
        />
        <DetailsHFLine
          visibleHfChange={true}
          healthFactor={user.healthFactor}
          futureHealthFactor={healthFactorAfterSwitch.toString(10)}
        />
      </TxModalDetails>

      {blockingError === ErrorType.ZERO_LTV_ENABLE_EMODE_FIRST && (
        <>
          <Alert severity="info" sx={{ mb: 6, width: '100%', mt: 4 }}>
            <AlertTitle>
              <Trans>E-Mode required</Trans>
            </AlertTitle>
            <Trans>
              This asset has 0 LTV and cannot be used as collateral. Enable an E-Mode to use{' '}
              {symbol} as collateral.
            </Trans>
          </Alert>
          <CollateralOptionsSelector
            poolReserve={poolReserve}
            eModes={eModes}
            user={user}
            reserves={reserves}
            selectedEmodeId={selectedEmodeId}
            onSelect={setSelectedEmodeId}
          />
        </>
      )}
      {blockingError !== undefined && blockingError !== ErrorType.ZERO_LTV_ENABLE_EMODE_FIRST && (
        <Typography variant="helperText" color="error.main">
          <BlockingError />
        </Typography>
      )}

      {txError && <GasEstimationError txError={txError} />}

      <CollateralChangeActions
        symbol={symbol}
        poolReserve={poolReserve}
        usageAsCollateral={usageAsCollateralModeAfterSwitch}
        isWrongNetwork={isWrongNetwork}
        blocked={
          blockingError !== undefined &&
          !(
            blockingError === ErrorType.ZERO_LTV_ENABLE_EMODE_FIRST &&
            selectedEmodeId !== user.userEmodeCategoryId
          )
        }
        selectedEmodeId={
          blockingError === ErrorType.ZERO_LTV_ENABLE_EMODE_FIRST &&
          selectedEmodeId !== user.userEmodeCategoryId
            ? selectedEmodeId
            : undefined
        }
      />
    </>
  );
};
