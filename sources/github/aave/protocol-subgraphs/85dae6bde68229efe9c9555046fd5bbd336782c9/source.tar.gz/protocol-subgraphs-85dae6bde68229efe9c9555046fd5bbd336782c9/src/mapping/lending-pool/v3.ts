import { BigInt, log } from '@graphprotocol/graph-ts';
import {
  Borrow,
  Supply,
  FlashLoan,
  LiquidationCall,
  RebalanceStableBorrowRate,
  Withdraw,
  Repay,
  ReserveUsedAsCollateralDisabled,
  ReserveUsedAsCollateralEnabled,
  SwapBorrowRateMode,
  ReserveDataUpdated,
  MintUnbacked,
  BackUnbacked,
  UserEModeSet,
  MintedToTreasury,
  IsolationModeTotalDebtUpdated,
} from '../../../generated/templates/Pool/Pool';
import {
  getOrInitReferrer,
  getOrInitReserve,
  getOrInitUser,
  getOrInitUserReserve,
  getPoolByContract,
  getPriceOracleAsset,
} from '../../helpers/v3/initializers';
import {
  Borrow as BorrowAction,
  Supply as SupplyAction,
  FlashLoan as FlashLoanAction,
  LiquidationCall as LiquidationCallAction,
  RebalanceStableBorrowRate as RebalanceStableBorrowRateAction,
  RedeemUnderlying as RedeemUnderlyingAction,
  Repay as RepayAction,
  SwapBorrowRate as SwapBorrowRateAction,
  UsageAsCollateral as UsageAsCollateralAction,
  MintUnbacked as MintUnbackedAction,
  BackUnbacked as BackUnbackedAction,
  UserEModeSet as UserEModeSetAction,
  MintedToTreasury as MintedToTreasuryAction,
  IsolationModeTotalDebtUpdated as IsolationModeTotalDebtUpdatedAction,
  Pool,
} from '../../../generated/schema';
import { getHistoryEntityId } from '../../utils/id-generation';
import { calculateGrowth } from '../../helpers/math';
import { USD_PRECISION } from '../../utils/constants';

export function handleSupply(event: Supply): void {
  let caller = event.params.user;
  let user = event.params.onBehalfOf;

  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let userReserve = getOrInitUserReserve(user, event.params.reserve, event);
  let amount = event.params.amount;

  let id = getHistoryEntityId(event);
  if (SupplyAction.load(id)) {
    id = id + '0';
  }

  let supply = new SupplyAction(id);
  supply.txHash = event.transaction.hash;
  supply.action = 'Supply';
  supply.pool = poolReserve.pool;
  supply.user = userReserve.user;
  supply.caller = getOrInitUser(caller).id;
  supply.userReserve = userReserve.id;
  supply.reserve = poolReserve.id;
  supply.amount = amount;
  supply.timestamp = event.block.timestamp.toI32();
  let priceOracleAsset = getPriceOracleAsset(poolReserve.price);
  supply.assetPriceUSD = priceOracleAsset.priceInEth.divDecimal(USD_PRECISION);
  if (event.params.referralCode) {
    let referrer = getOrInitReferrer(event.params.referralCode);
    supply.referrer = referrer.id;
  }
  supply.save();
}

export function handleWithdraw(event: Withdraw): void {
  let toUser = getOrInitUser(event.params.to);
  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let userReserve = getOrInitUserReserve(event.params.user, event.params.reserve, event);
  let redeemedAmount = event.params.amount;

  // The case for when withdrawing ETH is not possible to know which user has triggered it
  // as the event emitted will contain user and to equal to WethGateway address

  let redeemUnderlying = new RedeemUnderlyingAction(getHistoryEntityId(event));
  redeemUnderlying.txHash = event.transaction.hash;
  redeemUnderlying.action = 'RedeemUnderlying';
  redeemUnderlying.pool = poolReserve.pool;
  redeemUnderlying.user = userReserve.user;
  redeemUnderlying.to = toUser.id;
  redeemUnderlying.userReserve = userReserve.id;
  redeemUnderlying.reserve = poolReserve.id;
  redeemUnderlying.amount = redeemedAmount;
  redeemUnderlying.timestamp = event.block.timestamp.toI32();
  let priceOracleAsset = getPriceOracleAsset(poolReserve.price);
  redeemUnderlying.assetPriceUSD = priceOracleAsset.priceInEth.divDecimal(USD_PRECISION);
  redeemUnderlying.save();
}

export function handleBorrow(event: Borrow): void {
  let user = event.params.onBehalfOf;
  let caller = event.params.user;
  let userReserve = getOrInitUserReserve(user, event.params.reserve, event);
  let poolReserve = getOrInitReserve(event.params.reserve, event);

  let borrow = new BorrowAction(getHistoryEntityId(event));
  borrow.txHash = event.transaction.hash;
  borrow.action = 'Borrow';
  borrow.pool = poolReserve.pool;
  borrow.user = userReserve.user;
  borrow.caller = getOrInitUser(caller).id;
  borrow.userReserve = userReserve.id;
  borrow.reserve = poolReserve.id;
  borrow.amount = event.params.amount;
  borrow.stableTokenDebt = userReserve.principalStableDebt;
  borrow.variableTokenDebt = userReserve.scaledVariableDebt;
  borrow.borrowRate = event.params.borrowRate;
  borrow.borrowRateMode = event.params.interestRateMode;
  borrow.timestamp = event.block.timestamp.toI32();
  if (event.params.referralCode) {
    let referrer = getOrInitReferrer(event.params.referralCode);
    borrow.referrer = referrer.id;
  }
  let priceOracleAsset = getPriceOracleAsset(poolReserve.price);
  borrow.assetPriceUSD = priceOracleAsset.priceInEth.divDecimal(USD_PRECISION);
  borrow.save();
}

export function handleSwapBorrowRateMode(event: SwapBorrowRateMode): void {
  let userReserve = getOrInitUserReserve(event.params.user, event.params.reserve, event);
  let poolReserve = getOrInitReserve(event.params.reserve, event);

  let swapHistoryItem = new SwapBorrowRateAction(getHistoryEntityId(event));
  swapHistoryItem.txHash = event.transaction.hash;
  swapHistoryItem.action = 'SwapBorrowRate';
  swapHistoryItem.pool = poolReserve.pool;
  swapHistoryItem.borrowRateModeFrom = event.params.interestRateMode;
  if (swapHistoryItem.borrowRateModeFrom === 1) {
    swapHistoryItem.borrowRateModeTo = 2;
  } else {
    swapHistoryItem.borrowRateModeTo = 1;
  }

  swapHistoryItem.variableBorrowRate = poolReserve.variableBorrowRate;
  swapHistoryItem.stableBorrowRate = poolReserve.stableBorrowRate;
  swapHistoryItem.user = userReserve.user;
  swapHistoryItem.userReserve = userReserve.id;
  swapHistoryItem.reserve = poolReserve.id;
  swapHistoryItem.timestamp = event.block.timestamp.toI32();
  swapHistoryItem.save();
}

export function handleRebalanceStableBorrowRate(event: RebalanceStableBorrowRate): void {
  let userReserve = getOrInitUserReserve(event.params.user, event.params.reserve, event);
  let poolReserve = getOrInitReserve(event.params.reserve, event);

  let rebalance = new RebalanceStableBorrowRateAction(getHistoryEntityId(event));
  rebalance.txHash = event.transaction.hash;
  rebalance.action = 'RebalanceStableBorrowRate';
  rebalance.userReserve = userReserve.id;
  rebalance.borrowRateFrom = userReserve.oldStableBorrowRate;
  rebalance.borrowRateTo = userReserve.stableBorrowRate;
  rebalance.pool = poolReserve.pool;
  rebalance.reserve = poolReserve.id;
  rebalance.user = event.params.user.toHexString();
  rebalance.timestamp = event.block.timestamp.toI32();
  rebalance.save();
}

export function handleRepay(event: Repay): void {
  let repayer = event.params.repayer;
  let user = event.params.user;
  let userReserve = getOrInitUserReserve(user, event.params.reserve, event);
  let poolReserve = getOrInitReserve(event.params.reserve, event);

  poolReserve.save();

  let repay = new RepayAction(getHistoryEntityId(event));
  repay.txHash = event.transaction.hash;
  repay.action = 'Repay';
  repay.pool = poolReserve.pool;
  repay.user = userReserve.user;
  repay.repayer = getOrInitUser(repayer).id;
  repay.userReserve = userReserve.id;
  repay.reserve = poolReserve.id;
  repay.amount = event.params.amount;
  repay.timestamp = event.block.timestamp.toI32();
  repay.useATokens = event.params.useATokens;
  let priceOracleAsset = getPriceOracleAsset(poolReserve.price);
  repay.assetPriceUSD = priceOracleAsset.priceInEth.divDecimal(USD_PRECISION);
  repay.save();
}

export function handleLiquidationCall(event: LiquidationCall): void {
  let user = getOrInitUser(event.params.user);

  let collateralPoolReserve = getOrInitReserve(event.params.collateralAsset, event);
  let collateralUserReserve = getOrInitUserReserve(
    event.params.user,
    event.params.collateralAsset,
    event
  );
  let liquidatedCollateralAmount = event.params.liquidatedCollateralAmount;

  collateralPoolReserve.lifetimeLiquidated = collateralPoolReserve.lifetimeLiquidated.plus(
    liquidatedCollateralAmount
  );

  collateralPoolReserve.save();

  let principalUserReserve = getOrInitUserReserve(event.params.user, event.params.debtAsset, event);
  let principalPoolReserve = getOrInitReserve(event.params.debtAsset, event);

  principalPoolReserve.save();

  let liquidationCall = new LiquidationCallAction(getHistoryEntityId(event));
  liquidationCall.txHash = event.transaction.hash;
  liquidationCall.action = 'LiquidationCall';
  liquidationCall.pool = collateralPoolReserve.pool;
  liquidationCall.user = user.id;
  liquidationCall.collateralReserve = collateralPoolReserve.id;
  liquidationCall.collateralUserReserve = collateralUserReserve.id;
  liquidationCall.collateralAmount = liquidatedCollateralAmount;
  liquidationCall.principalReserve = principalPoolReserve.id;
  liquidationCall.principalUserReserve = principalUserReserve.id;
  liquidationCall.principalAmount = event.params.debtToCover;
  liquidationCall.liquidator = event.params.liquidator;
  liquidationCall.timestamp = event.block.timestamp.toI32();
  let collateralPriceOracleAsset = getPriceOracleAsset(collateralPoolReserve.price);
  let borrowPriceOracleAsset = getPriceOracleAsset(principalPoolReserve.price);
  liquidationCall.collateralAssetPriceUSD = collateralPriceOracleAsset.priceInEth.divDecimal(
    USD_PRECISION
  );
  liquidationCall.borrowAssetPriceUSD = borrowPriceOracleAsset.priceInEth.divDecimal(USD_PRECISION);
  liquidationCall.save();
}

export function handleFlashLoan(event: FlashLoan): void {
  let initiator = getOrInitUser(event.params.initiator);
  let poolReserve = getOrInitReserve(event.params.asset, event);
  let poolId = getPoolByContract(event);
  let pool = Pool.load(poolId) as Pool;

  let premium = event.params.premium;
  // The event to update the flashloanPremiumToProtocol was deprecated in v3.4, and now always returns a default value of 10000
  let flashloanPremiumToProtocol = pool.flashloanPremiumToProtocol || BigInt.fromI32(10000);
  let premiumToProtocol = premium
    .times(flashloanPremiumToProtocol as BigInt)
    .plus(BigInt.fromI32(5000))
    .div(BigInt.fromI32(10000));
  let premiumToLP = premium.minus(premiumToProtocol);
  log.error('premium {},{},{}', [
    premium.toString(),
    premiumToProtocol.toString(),
    premiumToLP.toString(),
  ]);
  poolReserve.availableLiquidity = poolReserve.availableLiquidity.plus(premium);

  poolReserve.lifetimeFlashLoans = poolReserve.lifetimeFlashLoans.plus(event.params.amount);
  poolReserve.lifetimeFlashLoanPremium = poolReserve.lifetimeFlashLoanPremium.plus(premium);
  poolReserve.lifetimeFlashLoanLPPremium = poolReserve.lifetimeFlashLoanLPPremium.plus(premiumToLP);
  poolReserve.lifetimeFlashLoanProtocolPremium = poolReserve.lifetimeFlashLoanProtocolPremium.plus(
    premiumToProtocol
  );
  poolReserve.totalATokenSupply = poolReserve.totalATokenSupply.plus(premium);

  poolReserve.save();

  let flashLoan = new FlashLoanAction(getHistoryEntityId(event));
  flashLoan.pool = poolReserve.pool;
  flashLoan.reserve = poolReserve.id;
  flashLoan.target = event.params.target;
  flashLoan.initiator = initiator.id;
  flashLoan.totalFee = premium;
  flashLoan.lpFee = premiumToLP;
  flashLoan.protocolFee = premiumToProtocol;
  flashLoan.amount = event.params.amount;
  flashLoan.timestamp = event.block.timestamp.toI32();
  let priceOracleAsset = getPriceOracleAsset(poolReserve.price);
  flashLoan.assetPriceUSD = priceOracleAsset.priceInEth.divDecimal(USD_PRECISION);
  flashLoan.save();
}

export function handleReserveUsedAsCollateralEnabled(event: ReserveUsedAsCollateralEnabled): void {
  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let userReserve = getOrInitUserReserve(event.params.user, event.params.reserve, event);
  let timestamp = event.block.timestamp.toI32();

  let usageAsCollateral = new UsageAsCollateralAction(getHistoryEntityId(event));
  usageAsCollateral.txHash = event.transaction.hash;
  usageAsCollateral.action = 'UsageAsCollateral';
  usageAsCollateral.pool = poolReserve.pool;
  usageAsCollateral.fromState = userReserve.usageAsCollateralEnabledOnUser;
  usageAsCollateral.toState = true;
  usageAsCollateral.user = userReserve.user;
  usageAsCollateral.userReserve = userReserve.id;
  usageAsCollateral.reserve = poolReserve.id;
  usageAsCollateral.timestamp = timestamp;
  usageAsCollateral.save();

  userReserve.lastUpdateTimestamp = timestamp;
  userReserve.usageAsCollateralEnabledOnUser = true;
  userReserve.save();
}

export function handleReserveUsedAsCollateralDisabled(
  event: ReserveUsedAsCollateralDisabled
): void {
  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let userReserve = getOrInitUserReserve(event.params.user, event.params.reserve, event);
  let timestamp = event.block.timestamp.toI32();

  let usageAsCollateral = new UsageAsCollateralAction(getHistoryEntityId(event));
  usageAsCollateral.txHash = event.transaction.hash;
  usageAsCollateral.action = 'UsageAsCollateral';
  usageAsCollateral.pool = poolReserve.pool;
  usageAsCollateral.fromState = userReserve.usageAsCollateralEnabledOnUser;
  usageAsCollateral.toState = false;
  usageAsCollateral.user = userReserve.user;
  usageAsCollateral.userReserve = userReserve.id;
  usageAsCollateral.reserve = poolReserve.id;
  usageAsCollateral.timestamp = timestamp;
  usageAsCollateral.save();

  userReserve.lastUpdateTimestamp = timestamp;
  userReserve.usageAsCollateralEnabledOnUser = false;
  userReserve.save();
}

export function handleReserveDataUpdated(event: ReserveDataUpdated): void {
  let reserve = getOrInitReserve(event.params.reserve, event);
  reserve.stableBorrowRate = event.params.stableBorrowRate;
  reserve.variableBorrowRate = event.params.variableBorrowRate;
  reserve.variableBorrowIndex = event.params.variableBorrowIndex;
  let timestamp = event.block.timestamp;
  let prevTimestamp = BigInt.fromI32(reserve.lastUpdateTimestamp);
  if (timestamp.gt(prevTimestamp)) {
    let growth = calculateGrowth(
      reserve.totalATokenSupply,
      reserve.liquidityRate,
      prevTimestamp,
      timestamp
    );
    reserve.totalATokenSupply = reserve.totalATokenSupply.plus(growth);
    reserve.lifetimeSuppliersInterestEarned = reserve.lifetimeSuppliersInterestEarned.plus(growth);
  }
  reserve.liquidityRate = event.params.liquidityRate;
  reserve.liquidityIndex = event.params.liquidityIndex;
  reserve.lastUpdateTimestamp = event.block.timestamp.toI32();

  reserve.save();
}

export function handleMintUnbacked(event: MintUnbacked): void {
  let caller = event.params.user;
  let user = event.params.onBehalfOf;
  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let userReserve = getOrInitUserReserve(user, event.params.reserve, event);
  let amount = event.params.amount;

  let mintUnbacked = new MintUnbackedAction(getHistoryEntityId(event));
  mintUnbacked.pool = poolReserve.pool;
  mintUnbacked.user = userReserve.user;
  mintUnbacked.userReserve = userReserve.id;
  mintUnbacked.caller = getOrInitUser(caller).id;
  mintUnbacked.reserve = poolReserve.id;
  mintUnbacked.amount = amount;
  mintUnbacked.timestamp = event.block.timestamp.toI32();
  mintUnbacked.referral = event.params.referralCode;

  mintUnbacked.save();
}

export function handleBackUnbacked(event: BackUnbacked): void {
  let backer = event.params.backer;
  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let userReserve = getOrInitUserReserve(backer, event.params.reserve, event);
  let amount = event.params.amount;

  let poolId = getPoolByContract(event);
  let pool = Pool.load(poolId) as Pool;

  let premium = event.params.fee;
  let premiumToProtocol = premium
    .times(pool.bridgeProtocolFee as BigInt)
    .plus(BigInt.fromI32(5000))
    .div(BigInt.fromI32(10000));
  let premiumToLP = premium.minus(premiumToProtocol);
  poolReserve.lifetimePortalLPFee = poolReserve.lifetimePortalLPFee.plus(premiumToLP);
  poolReserve.lifetimePortalProtocolFee = poolReserve.lifetimePortalProtocolFee.plus(
    premiumToProtocol
  );
  poolReserve.save();

  let backUnbacked = new BackUnbackedAction(getHistoryEntityId(event));
  backUnbacked.pool = poolReserve.pool;
  backUnbacked.backer = userReserve.user;
  backUnbacked.userReserve = userReserve.id;
  backUnbacked.reserve = poolReserve.id;
  backUnbacked.amount = amount;
  backUnbacked.timestamp = event.block.timestamp.toI32();
  backUnbacked.fee = event.params.fee;
  backUnbacked.lpFee = premiumToLP;
  backUnbacked.protocolFee = premiumToProtocol;

  backUnbacked.save();
}

export function handleUserEModeSet(event: UserEModeSet): void {
  let user = getOrInitUser(event.params.user);

  user.eModeCategoryId = BigInt.fromI32(event.params.categoryId).toString();
  user.save();

  let userEModeSet = new UserEModeSetAction(getHistoryEntityId(event));
  userEModeSet.action = 'UserEModeSet'
  userEModeSet.txHash = event.transaction.hash;
  userEModeSet.user = user.id;
  userEModeSet.categoryId = event.params.categoryId;
  userEModeSet.timestamp = event.block.timestamp.toI32();

  userEModeSet.save();
}

export function handleMintedToTreasury(event: MintedToTreasury): void {
  let poolReserve = getOrInitReserve(event.params.reserve, event);
  let amount = event.params.amountMinted;

  let mintedToTreasury = new MintedToTreasuryAction(getHistoryEntityId(event));
  mintedToTreasury.pool = poolReserve.pool;
  mintedToTreasury.reserve = poolReserve.id;
  mintedToTreasury.amount = amount;
  mintedToTreasury.timestamp = event.block.timestamp.toI32();

  mintedToTreasury.save();
}

export function handleIsolationModeTotalDebtUpdated(event: IsolationModeTotalDebtUpdated): void {
  let poolReserve = getOrInitReserve(event.params.asset, event);

  let isolationDebt = new IsolationModeTotalDebtUpdatedAction(getHistoryEntityId(event));
  isolationDebt.pool = poolReserve.pool;
  isolationDebt.reserve = poolReserve.id;
  isolationDebt.isolatedDebt = event.params.totalDebt;
  isolationDebt.timestamp = event.block.timestamp.toI32();

  isolationDebt.save();
}
