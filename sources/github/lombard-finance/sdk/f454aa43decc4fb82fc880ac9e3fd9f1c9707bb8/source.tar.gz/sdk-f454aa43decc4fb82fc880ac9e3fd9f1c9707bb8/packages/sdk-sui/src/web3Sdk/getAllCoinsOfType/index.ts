export * from './getAllCoinsOfType';
