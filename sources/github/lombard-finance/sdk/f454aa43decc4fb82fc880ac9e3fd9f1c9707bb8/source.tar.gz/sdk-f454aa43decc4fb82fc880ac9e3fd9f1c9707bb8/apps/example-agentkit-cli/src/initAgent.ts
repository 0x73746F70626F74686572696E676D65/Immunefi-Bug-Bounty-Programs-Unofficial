import {
  AgentKit,
  ViemWalletProvider,
  walletActionProvider,
} from "@coinbase/agentkit";
import { tool } from "@langchain/core/tools";
import { createWalletClient, http } from "viem";
import { privateKeyToAccount } from "viem/accounts";

import {
  lombardActionProvider,
  type LombardActionProviderOptions,
} from "@lombard.finance/sdk-agentkit";

import { CHAINS } from "./config.js";

export async function initAgent(
  networkId: string,
  // How writes get approved. The provider signs nothing without one of
  // `confirmWrite` or `autoApproveWrites`, since a tool call is the
  // transaction and the model calling it reads text it did not write.
  writePolicy: LombardActionProviderOptions,
) {
  const chain = CHAINS[networkId];
  if (!chain) {
    throw new Error(`Unsupported network: ${networkId}. Use one of: ${Object.keys(CHAINS).join(", ")}`);
  }

  const account = privateKeyToAccount(process.env.WALLET_PRIVATE_KEY as `0x${string}`);
  const walletClient = createWalletClient({
    account,
    chain,
    transport: http(process.env.RPC_URL),
  });

  // Dual viem versions (workspace root vs local) cause type mismatch
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const walletProvider = new ViemWalletProvider(walletClient as any);

  const agentkit = await AgentKit.from({
    walletProvider,
    actionProviders: [
      walletActionProvider(),
      lombardActionProvider(writePolicy),
    ],
  });

  // One LangChain tool per AgentKit action.
  const tools = agentkit.getActions().map((action) =>
    tool(async (arg) => action.invoke(arg), {
      name: action.name,
      description: action.description,
      schema: action.schema,
    }),
  );

  return { walletProvider, tools };
}
