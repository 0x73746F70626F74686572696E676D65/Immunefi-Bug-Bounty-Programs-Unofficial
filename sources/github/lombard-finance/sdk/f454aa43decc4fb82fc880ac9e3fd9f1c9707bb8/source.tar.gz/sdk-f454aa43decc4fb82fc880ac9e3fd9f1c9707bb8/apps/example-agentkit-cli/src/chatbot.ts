import "dotenv/config";

import { ChatAnthropic } from "@langchain/anthropic";
import { type BaseMessage, HumanMessage } from "@langchain/core/messages";
import { MemorySaver } from "@langchain/langgraph";
import { createReactAgent } from "@langchain/langgraph/prebuilt";
import * as readline from "readline";

import type { LombardActionProviderOptions } from "@lombard.finance/sdk-agentkit";

import { initAgent } from "./initAgent.js";

const SYSTEM_PROMPT = `You are an AI agent specialized in Bitcoin staking via the Lombard protocol.
You can help users:
- Stake BTC.b to receive LBTC (yield-bearing Bitcoin)
- Unstake LBTC back to BTC or BTC.b
- Deploy LBTC into DeFi vaults for additional yield
- Check balances, exchange rates, and deposit/unstake statuses
- Claim notarized deposits

Always confirm with the user before executing transactions.
When checking balances, show the token symbol and chain.
If a user asks about yield or APY, explain that base LBTC yield comes from Babylon staking,
but higher yields are available by deploying LBTC into DeFi vaults via the deploy_to_defi action.`;

/**
 * Puts a pending write to the operator and waits for a yes.
 *
 * The system prompt above also asks the model to confirm before transacting,
 * which is worth having and is not this. A prompt is a request to the model;
 * this is a gate the model cannot talk its way past, and injected text
 * reaching the model is exactly the case where the two differ.
 */
function confirmInTerminal(
  request: Parameters<NonNullable<LombardActionProviderOptions["confirmWrite"]>>[0],
): Promise<boolean> {
  const lines = [
    `\n  action:    ${request.action}`,
    `  chain:     ${request.chainId}`,
    `  account:   ${request.account}`,
    ...(request.amount ? [`  amount:    ${request.amount}`] : []),
    ...(request.assetIn ? [`  from:      ${request.assetIn}`] : []),
    ...(request.assetOut ? [`  to:        ${request.assetOut}`] : []),
    ...(request.recipient ? [`  recipient: ${request.recipient}`] : []),
  ];
  console.log(`\nThis will move funds:${lines.join("\n")}`);

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    rl.question("\nApprove? (yes/no): ", (answer) => {
      rl.close();
      resolve(answer.trim().toLowerCase() === "yes");
    });
  });
}

async function initializeAgent() {
  const networkId = process.env.NETWORK_ID || "ethereum-sepolia";
  const { walletProvider, tools } = await initAgent(networkId, {
    confirmWrite: confirmInTerminal,
  });

  const llm = new ChatAnthropic({
    model: "claude-sonnet-4-20250514",
    temperature: 0,
  });

  const memory = new MemorySaver();
  const agent = createReactAgent({
    llm,
    tools,
    checkpointSaver: memory,
    messageModifier: SYSTEM_PROMPT,
  });

  const address = walletProvider.getAddress();
  console.log(`\nAgent wallet: ${address}`);
  console.log(`Network: ${networkId}`);

  const lombardTools = tools.filter(t =>
    t.name.includes("lbtc") || t.name.includes("btc") ||
    t.name.includes("deploy") || t.name.includes("claim") ||
    t.name.includes("deposit") || t.name.includes("unstake") ||
    t.name.includes("stake"),
  );
  console.log(`Lombard actions: ${lombardTools.map(t => t.name).join(", ")}`);

  return { agent, address };
}

async function main() {
  console.log("Lombard AgentKit Chatbot");
  console.log("========================\n");

  const required = ["ANTHROPIC_API_KEY", "WALLET_PRIVATE_KEY"];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    console.error(`Missing env vars: ${missing.join(", ")}`);
    console.error("Copy .env.example to .env and fill in the values.");
    process.exit(1);
  }

  const { agent } = await initializeAgent();
  const threadId = `lombard-${Date.now()}`;

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const prompt = () => {
    rl.question("\nYou: ", async (input) => {
      const trimmed = input.trim();

      if (!trimmed || trimmed === "exit" || trimmed === "quit") {
        console.log("Goodbye!");
        rl.close();
        return;
      }

      try {
        const config = { configurable: { thread_id: threadId } };
        const stream = await agent.stream(
          { messages: [new HumanMessage(trimmed)] },
          config,
        );

        let response = "";
        for await (const chunk of stream) {
          if ("agent" in chunk) {
            for (const msg of (chunk.agent.messages ?? []) as BaseMessage[]) {
              if (typeof msg.content === "string" && msg.content.length > 0) {
                response = msg.content;
              }
            }
          }
          if ("tools" in chunk) {
            for (const msg of (chunk.tools.messages ?? []) as BaseMessage[]) {
              console.log(`  [tool: ${msg.name}] ${String(msg.content).slice(0, 200)}`);
            }
          }
        }

        console.log(`\nAgent: ${response}`);
      } catch (error) {
        console.error("Error:", error instanceof Error ? error.message : error);
      }

      prompt();
    });
  };

  console.log('Type "exit" to quit.\n');
  prompt();
}

main().catch(console.error);
