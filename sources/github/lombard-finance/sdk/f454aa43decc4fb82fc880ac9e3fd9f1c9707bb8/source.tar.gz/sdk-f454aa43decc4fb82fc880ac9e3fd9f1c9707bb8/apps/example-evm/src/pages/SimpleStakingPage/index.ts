export { SimpleStakingPage } from './SimpleStakingPage';
