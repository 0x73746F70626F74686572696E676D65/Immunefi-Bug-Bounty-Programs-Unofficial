export { StarknetStakePage } from './StarknetStakePage';
