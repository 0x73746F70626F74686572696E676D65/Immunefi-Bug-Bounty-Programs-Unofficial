/**
 * Autonomous mode: the agent runs a predefined set of read-only Lombard
 * operations without user interaction. Useful for validating the action
 * provider end-to-end.
 */
import "dotenv/config";

import { ChatAnthropic } from "@langchain/anthropic";
import { type BaseMessage, HumanMessage } from "@langchain/core/messages";
import { MemorySaver } from "@langchain/langgraph";
import { createReactAgent } from "@langchain/langgraph/prebuilt";

import { initAgent } from "./initAgent.js";

const TASKS = [
  "What is the current LBTC/BTC exchange rate?",
  "Check my LBTC balance on this chain.",
  "Check my BTC.b balance on this chain.",
  "Check if I have any pending deposits.",
  "Check if I have any pending unstakes.",
];

const TASK_TIMEOUT_MS = Number(process.env.TASK_TIMEOUT_MS) || 60_000;

async function main() {
  console.log("Lombard AgentKit - Autonomous Validation");
  console.log("==========================================\n");

  const required = ["ANTHROPIC_API_KEY", "WALLET_PRIVATE_KEY"];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    console.error(`Missing env vars: ${missing.join(", ")}`);
    process.exit(1);
  }

  const networkId = process.env.NETWORK_ID || "ethereum-sepolia";
  // Nobody is at the terminal here, so writes run unapproved. That is only
  // safe because this runs a fixed task list on a testnet key: the wallet can
  // move whatever it holds, and the tasks reach the model as text.
  const { walletProvider, tools } = await initAgent(networkId, {
    autoApproveWrites: true,
  });

  console.log(`Available tools (${tools.length}):`);
  for (const tool of tools) {
    console.log(`  - ${tool.name}: ${tool.description.slice(0, 80)}...`);
  }

  const llm = new ChatAnthropic({
    model: "claude-sonnet-4-20250514",
    temperature: 0,
  });

  const memory = new MemorySaver();
  const agent = createReactAgent({
    llm,
    tools,
    checkpointSaver: memory,
    messageModifier:
      "You are a Bitcoin staking agent using the Lombard protocol. " +
      "Execute the requested operations and report results clearly. " +
      "For read-only operations, proceed without confirmation.",
  });

  const address = walletProvider.getAddress();
  console.log(`\nWallet: ${address}`);
  console.log(`Network: ${networkId}\n`);

  const config = { configurable: { thread_id: `auto-${Date.now()}` } };
  let passed = 0;
  let failed = 0;

  for (const task of TASKS) {
    console.log(`\n--- Task: ${task}`);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TASK_TIMEOUT_MS);
    try {
      const stream = await agent.stream(
        { messages: [new HumanMessage(task)] },
        { ...config, signal: controller.signal },
      );

      for await (const chunk of stream) {
        if ("agent" in chunk) {
          for (const msg of (chunk.agent.messages ?? []) as BaseMessage[]) {
            if (typeof msg.content === "string" && msg.content.length > 0) {
              console.log(`  Agent: ${msg.content.slice(0, 300)}`);
            }
          }
        }
        if ("tools" in chunk) {
          for (const msg of (chunk.tools.messages ?? []) as BaseMessage[]) {
            console.log(`  [${msg.name}] ${String(msg.content).slice(0, 200)}`);
          }
        }
      }

      passed++;
      console.log("  PASS");
    } catch (error) {
      failed++;
      const msg =
        controller.signal.aborted
          ? `timed out after ${TASK_TIMEOUT_MS}ms`
          : error instanceof Error
            ? error.message
            : String(error);
      console.error(`  FAIL: ${msg}`);
    } finally {
      clearTimeout(timeout);
    }
  }

  console.log(`\n==========================================`);
  console.log(`Results: ${passed} passed, ${failed} failed out of ${TASKS.length}`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Fatal:", err);
  process.exit(1);
});
