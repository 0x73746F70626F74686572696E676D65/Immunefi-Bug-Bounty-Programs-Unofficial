#!/usr/bin/env sh

# check this is being run from the right location
if [[ "$PWD" != *"/multisig-scripts" ]]; then
    echo "Please run this from ./multisig-scripts"
    exit 0
fi

# check dependencies are available
for dep in sui; do
    if ! command -V "${dep}" 2>/dev/null; then
        echo "Please install lib ${dep}"
        exit 1
    fi
done

# Process command-line arguments
KEYFILE=
THRESHOLD=

while [ $# -gt 0 ]; do
    case "$1" in
    --keyfile=*)
        KEYFILE="${1#*=}"
        ;;
    --threshold=*)
        THRESHOLD="${1#*=}"
        ;;
    *)
        echo "Unknown arg $1"
        exit 1
    esac #end case
    shift
done

if [ -z "$KEYFILE" ] || [ -z "$THRESHOLD" ]; then
    echo "Error: missing arguments! Need keyfile and threshold."
    exit 1
fi

# Take public keys and weights from selected file
pks=()
weights=()

while IFS=',' read -r first second || [ -n "$first" ]; do
    # Skip blank lines
    [ -z "$first" ] && continue
    if [ -z "$second" ]; then
        echo "Error: each line in $KEYFILE must be '<public_key>,<weight>'" >&2
        echo "Missing weight on line: $first" >&2
        exit 1
    fi
    pks+=("$first")
    weights+=("$second")
done < "$KEYFILE"

if [ ${#pks[@]} -lt 2 ]; then
    echo "Error: need at least two public keys in $KEYFILE" >&2
    exit 1
fi

if ! admin_multisig_info=$(sui keytool multi-sig-address --pks "${pks[@]}" --weights "${weights[@]}" --threshold "$THRESHOLD" --json 2>&1); then
    echo "Failed to create multisig address:" >&2
    echo "$admin_multisig_info" >&2
    exit 1
fi

echo "Multisig address: $(echo "$admin_multisig_info" | jq -r '.multisigAddress')"
echo "$admin_multisig_info" > admin_multisig_info

# Add threshold information
jq --arg key "threshold" --arg value "$THRESHOLD" '. + {($key): ($value | tonumber)}' admin_multisig_info > updated_info
mv updated_info admin_multisig_info
