# AGENTS.md

This file provides guidance to AI Agent when working with code in this repository.

## Overview

This repo holds the Sui Move smart contracts for **LBTC** (Lombard Staked BTC), a regulated, cross-chain Bitcoin-backed coin, plus the TypeScript tooling and bash scripts used to deploy and operate them via multisig.

## Layout

- `move/` — the Move packages (see Architecture). Each is an independent Sui package with its own `Move.toml`.
- `setup/` — TypeScript integration/operation scripts (`pnpm`-based) that build PTBs against deployed packages. Each `pnpm test*` script targets one on-chain action.
- `scripts/` — bash publishing scripts (`publish.sh` etc.) for the full deploy flow.
- `multisig-scripts/` — bash scripts for the multisig contract lifecycle (build/sign/execute tx bytes). See `multisig-scripts/README.md` for the coordinator workflow.
- `mainnet.json` / `staging.json` / `gastald.json` — deployed package IDs and shared object IDs per environment. `mainnet.json` tracks current + deprecated LBTC package versions.
- `docs/flowcharts/` — mermaid diagrams for auth, minting, publishing, and the role matrix.

## Build & Test

Each Move package is built/tested independently from its own directory:

```bash
cd move/lbtc && sui move build          # build a package
cd move/lbtc && sui move test           # run all tests in a package
cd move/lbtc && sui move test <filter>  # run tests matching a substring (e.g. a test fn name)
```

Packages depend on the Sui framework pinned at the `testnet` git rev (see each `Move.toml`). `bridge_vault` and `lbtc` have local path dependencies (`lbtc` → `consortium`, `bascule`; `bridge_vault` → `lbtc`, `Bridge`), so build those dependencies are resolved automatically by their `[addresses]` entries (`0x0` until published).

TypeScript operational scripts (require a populated `.env`, see `setup/README.md`):

```bash
cd setup && pnpm install
pnpm generateTypes            # regenerate TypeMove bindings from on-chain ABI
pnpm testAddMinter            # example: run one operation script (see package.json scripts)
```

## Architecture

Five Move packages, dependency order `consortium`/`bascule` → `lbtc` → `bridge_vault`; `timelock_policy` is standalone.

### `lbtc` — the coin and its treasury (core package)

- `lbtc.move`: `init` creates the regulated `LBTC` coin via `create_regulated_currency_v2` (8 decimals, global pause allowed), freezes metadata, and wraps the `TreasuryCap` + `DenyCapV2` in a shared `ControlledTreasury`. **Publishing is expected to happen from a multisig address**, which becomes the initial `AdminCap` holder.
- `treasury.move` (largest module, ~1250 lines): the heart of the system. `ControlledTreasury<T>` holds the caps and stores **roles in a `Bag` keyed by `RoleKey<Cap>{owner}`** (dynamic fields). Capabilities: `AdminCap` (manage roles + most config setters), `MinterCap` (per-epoch mint limit, auto-resets each epoch), `PauserCap` (global pause), `OperatorCap` (set max fee), `ClaimerCap`. There is also a **witness-based minter** (`WitnessRoleKey` keyed by a type name) for programmatic minting by another contract.
- Minting paths (note `_v2` are current; non-`v2` `mint`/`mint_with_fee`/global-pause fns are `#[deprecated]` and `abort`):
  - `mint_and_transfer`: direct mint by a `MinterCap` holder; requires sender to be the authorized multisig and checks the per-epoch limit.
  - `mint_v2` / `mint_with_fee_v2`: mint from a signed BTC-deposit `payload`, validated by the `Consortium` (`consortium::validate_payload`) and optionally cross-checked against the `Bascule`. Payloads are decoded by `payload_decoder` and recorded in a `used_payloads` table to prevent replay.
  - `mint_with_witness`: another contract mints by presenting its witness type (used by `bridge_vault`).
- `redeem`: burns LBTC to request a BTC withdrawal; deducts a burn commission to the treasury address and enforces a Bitcoin dust limit via `bitcoin_utils`.
- `bitcoin_utils.move`: decodes BTC `script_pubkey` output types and computes dust limits. `multisig.move`: derives/validates Sui multisig addresses from pks+weights+threshold. `pk_util` (in `verify.move`): public-key/signature schema validation.
- **Deprecated in-package modules**: `lbtc::consortium`, `lbtc::bascule`, `lbtc::payload_decoder` are old copies kept only for type compatibility — the live logic lives in the separate `consortium`/`bascule` packages. Don't add to the deprecated ones.

### `consortium` — validator-set signature verification

`consortium.move` holds the notary/validator set per epoch (`ValidatorSet` of pks + weights + threshold, max 102 validators) and verifies threshold ECDSA (`ecdsa_k1`) signatures over payloads. `validate_payload` is the gate the treasury uses before payload-based mints. Valset rotation is itself authorized by a signed valset payload.

### `bascule` — independent deposit-validation oracle

A second on-chain check that withdrawals/mints correspond to reported deposits. Roles: `BasculeOwnerCap`, `BasculePauserCap`, `BasculeReporterCap`. Deliberately has no guardian role (PTBs make the two-step EVM pattern unnecessary). The treasury can toggle whether the Bascule check is enforced.

### `bridge_vault` — native↔wrapped bridging

`Vault<WT, T>` stores wrapped-token balance and bridges to Sui's native `Bridge`. Uses a witness to mint LBTC through the treasury's witness-minter path. Has its own `AdminCap`/`PauserCap` role bag.

### `timelock_policy` — upgrade delay enforcement

`TimelockCap` wraps an `UpgradeCap` and enforces a fixed 24h or 48h delay between authorized upgrades.

## Conventions & Gotchas

- **`_v2` suffix means "current"**: when adding or calling treasury logic, prefer the `_v2` functions; the un-suffixed `mint`/`mint_with_fee`/`enable_global_pause`/`disable_global_pause` are deprecated stubs that `abort EDeprecated`.
- **Roles are dynamic fields in a `Bag`**, not separate owned objects. Granting/revoking goes through `add_capability`/`remove_capability` (and the witness variants). Auth checks use `has_cap<T, Cap>(owner)`.
- Most state-changing ops require the caller to be the **authorized multisig address** (verified via `multisig::is_sender_multisig`) in addition to holding the relevant cap.
- Mint limits are **per-epoch** and silently reset at the start of a new Sui epoch.
- Move packages pin the Sui framework at the `testnet` rev — keep new packages consistent or builds across packages will diverge.
- When upgrading a contract, the package's `Move.toml` must add a `published-at` field pointing at the prior deployment (see `multisig-scripts/README.md`).
- `Move.lock`, `build/`, `.env`, and `.publish.res.json` are gitignored — do not commit them.
