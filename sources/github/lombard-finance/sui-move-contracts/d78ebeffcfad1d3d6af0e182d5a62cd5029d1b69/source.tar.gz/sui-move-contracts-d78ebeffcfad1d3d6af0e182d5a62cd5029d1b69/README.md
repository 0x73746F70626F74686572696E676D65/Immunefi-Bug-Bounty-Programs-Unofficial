# Lombard Finance Move smart-contracts

[Website](https://www.lombard.finance/) | [Docs](https://docs.lombard.finance/)

## Overview

LBTC is liquid Bitcoin; it's yield-bearing, cross-chain, and 1:1 backed by BTC. LBTC enables yield-bearing BTC to move cross-chain without fragmenting liquidity, and is designed to seamlessly integrate Bitcoin into the decentralized finance (DeFi) ecosystem while maintaining the security and integrity of the underlying asset.

### Packages

| Coin Type                                                                      | Current Package ID                                                 |
| ------------------------------------------------------------------------------ | ------------------------------------------------------------------ |
| 0x3e8e9423d80e1774a7ca128fccd8bf5f1f7753be658c5e645929037f7c819040::lbtc::LBTC | 0x124477c9cffb667be781e867fd29579d3498a47e6b69d06155841ca85bcb02d0 |

## Setup

### Skill

Install `sui-move` skill (https://skills.suimate.ai/)

```bash
gh skill install https://github.com/EasonC13-agent/sui-skills sui-move --scope project
cd <skill-folder> # e.g. .agents/skills/sui-move
mkdir -p references && cd references
git clone --depth 1 https://github.com/MystenLabs/move-book.git
git clone --depth 1 https://github.com/MystenLabs/awesome-move.git
git clone --depth 1 --filter=blob:none --sparse https://github.com/MystenLabs/sui.git
cd sui && git sparse-checkout set docs
```
