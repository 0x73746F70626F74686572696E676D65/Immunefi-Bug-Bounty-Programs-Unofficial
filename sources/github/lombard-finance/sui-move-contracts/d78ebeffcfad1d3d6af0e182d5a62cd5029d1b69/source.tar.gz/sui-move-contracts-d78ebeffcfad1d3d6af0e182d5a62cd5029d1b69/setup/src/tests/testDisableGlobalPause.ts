import {
  SHARED_CONTROLLED_TREASURY,
  suiClient,
  LBTC_COIN_TYPE,
  DENYLIST,
} from "../config";
import {
  executeMultisigTransaction,
  generateMultiSigPublicKey,
  createMultisigSigner,
} from "../helpers/multisigHelper";
import { Transaction } from "@mysten/sui/transactions";
import { treasury } from "../types/0x3048a09b0fe21d9e4c2a861b7cf453e34ef0689af08508b8a354591efa850c64";
import { getMultisigConfig, getTestMultisigConfig } from "../helpers/getMultisigConfig";

async function testDisableGlobalPause() {
  try {
    // Retrieve the multisig configuration
    const multisigConfig = getTestMultisigConfig();

    // Generate MultiSigPublicKey
    const multiSigPublicKey = generateMultiSigPublicKey(
      multisigConfig.users.map(({ keypair, weight }) => ({
        publicKey: keypair.getPublicKey(),
        weight,
      })),
      multisigConfig.threshold
    );

    // Create a MultiSigSigner
    const signer = createMultisigSigner(
      multiSigPublicKey,
      multisigConfig.users.map(({ keypair }) => keypair)
    );

    // Extract public keys and weights for the global pause configuration
    const publicKeys = multisigConfig.users.map(({ keypair }) =>
      Array.from(keypair.getPublicKey().toSuiBytes())
    );
    const weights = multisigConfig.users.map(({ weight }) => weight);

    // Prepare the transaction to disable global pause
    const tx = new Transaction();

    treasury.builder.disableGlobalPause(
      tx,
      [
        tx.object(SHARED_CONTROLLED_TREASURY), // Controlled Treasury object
        tx.object(DENYLIST), // Denylist global object
        tx.pure.vector("vector<u8>", publicKeys), // Public keys
        tx.pure.vector("u8", weights), // Weights
        tx.pure.u16(multisigConfig.threshold), // Threshold
      ],
      [LBTC_COIN_TYPE]
    );

    // Execute the transaction using the multisig signer
    const result = await executeMultisigTransaction(suiClient, tx, signer);

    console.log("Transaction result:", result);
  } catch (error) {
    console.error("Error in testDisableGlobalPause:", error);
  }
}

testDisableGlobalPause();
