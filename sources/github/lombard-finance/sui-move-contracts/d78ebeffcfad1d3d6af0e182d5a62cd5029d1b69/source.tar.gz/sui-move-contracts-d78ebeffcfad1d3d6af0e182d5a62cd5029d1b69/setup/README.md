## Smart Contract Integration Code

This folder contains TypeScript code designed for smart contract integration. Follow the steps below to set up and use the project.

### Instructions

1. ****Set up dependencies:****
   ```bash
   cd setup
   pnpm install
   ```

2. ****Navigate to the** `scripts` **folder and prepare the script:****
   ```bash
   cd ../scripts
   chmod +x ./publish.sh
   ```

3. ****Publish to the testnet:****
   ```bash
   ./publish.sh --env=testnet
   ```

4. ****Update package IDs:****
   - Copy the `PACKAGE_ID` from the .env and replace the `package_id` in `package.json`.
   - Copy the `SHARED_CONSORTIUM` from the .env and replace the `consortium_package_id` in `package.json`.

5. ****Navigate to the** `setup` **folder and generate the types:****
   ```bash
   cd ../setup
   pnpm generateTypes
   ```

6. ****Update imports:****
   - Modify all imports in `tests` and `utils` to reflect the new `types` file structure.

### Recommended Starting Point

- Begin with the `testAddMinter` script to grant your address minter capabilities.
