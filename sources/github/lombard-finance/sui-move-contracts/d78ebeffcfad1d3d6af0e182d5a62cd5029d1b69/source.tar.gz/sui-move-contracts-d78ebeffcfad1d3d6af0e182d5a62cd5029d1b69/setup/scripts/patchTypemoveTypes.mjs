#!/usr/bin/env node
/**
 * Post-process TypeMove-generated types to work around known limitations:
 * - enums (bitcoin_utils.OutputType, bascule.DepositState) are not exported
 * - .js import extensions break ts-node resolution
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const typesDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "../src/types");

const DEPOSIT_STATE_STUB = `  // TypeMove currently does not support the export of enums.
  export type DepositState = { Reported: true } | { Withdrawn: true };

`;

function patchFile(filePath) {
  let content = fs.readFileSync(filePath, "utf8");
  const original = content;

  // Fix local .js imports for ts-node
  content = content.replace(/from "\.\/([^"]+)\.js"/g, 'from "./$1"');

  // Stub bascule.DepositState enum
  if (
    content.includes("export namespace bascule {") &&
    content.includes("bascule.DepositState") &&
    !content.includes("export type DepositState")
  ) {
    content = content.replace(
      "export namespace bascule {\n",
      `export namespace bascule {\n${DEPOSIT_STATE_STUB}`,
    );
  }

  // Comment out bitcoin_utils namespace (enum export bug)
  if (
    content.includes("export namespace bitcoin_utils {") &&
    !content.includes("//export namespace bitcoin_utils {")
  ) {
    const lines = content.split("\n");
    const start = lines.findIndex((l) => l === "export namespace bitcoin_utils {");
    if (start !== -1) {
      let end = -1;
      for (let i = start + 1; i < lines.length; i++) {
        if (lines[i] === "}" && lines[i + 1]?.trim() === "") {
          const j = i + 2;
          if (j < lines.length && lines[j].startsWith("export namespace ")) {
            end = i;
            break;
          }
        }
      }
      if (end !== -1) {
        const commented = [
          "// TypeMove currently does not support the export of enums.",
          ...lines.slice(start, end + 1).map((l) => (l.trim() ? `//${l}` : l)),
        ];
        lines.splice(start, end - start + 1, ...commented);
        content = lines.join("\n");
      }
    }
  }

  if (content !== original) {
    fs.writeFileSync(filePath, content);
    console.log(`patched ${path.basename(filePath)}`);
  }
}

for (const entry of fs.readdirSync(typesDir)) {
  if (!entry.endsWith(".ts") || entry === "index.ts") continue;
  patchFile(path.join(typesDir, entry));
}

// index.ts re-exports use .js extensions too
const indexPath = path.join(typesDir, "index.ts");
let indexContent = fs.readFileSync(indexPath, "utf8");
const patchedIndex = indexContent.replace(/from '\.\/([^']+)\.js'/g, "from './$1'");
if (patchedIndex !== indexContent) {
  fs.writeFileSync(indexPath, patchedIndex);
  console.log("patched index.ts");
}
