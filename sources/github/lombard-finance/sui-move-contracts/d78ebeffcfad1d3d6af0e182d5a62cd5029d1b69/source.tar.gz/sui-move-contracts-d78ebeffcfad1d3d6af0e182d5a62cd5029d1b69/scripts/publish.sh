#!/usr/bin/env sh

# This script publishes the LBTC Move packages using multisig functionality.
# It sets up addresses for user1 and user2, creates a multisig address, requests
# tokens, and publishes consortium, bascule, and lbtc in separate transactions.
#
# Packages are published one-by-one because lbtc still contains deprecated stub
# modules (lbtc::consortium, lbtc::bascule, lbtc::payload_decoder) for upgrade
# compatibility. Publishing everything with --with-unpublished-dependencies
# collides those stubs with the real consortium/bascule packages at compile time.

# check this is being run from the right location
if [[ "$PWD" != *"/scripts" ]]; then
    echo "Please run this from ./scripts"
    exit 0
fi

# check dependencies are available
for dep in jq curl sui; do
    if ! command -V "${dep}" 2>/dev/null; then
        echo "Please install lib ${dep}"
        exit 1
    fi
done

# Process command-line arguments
ENV=
LBTC_ONLY=false

while [ $# -gt 0 ]; do
    case "$1" in
    --env=*)
        ENV="${1#*=}"
        case ${ENV} in
        "testnet") ;;
        "devnet") ;;
        "local") ;;
        *) echo "unknown env {$ENV}"
            exit 1
        esac #end inner case
        ;;
    --lbtc-only)
        LBTC_ONLY=true
        ;;
    *)
        echo "Unknown arg $1"
        exit 1
    esac #end case
    shift
done

# Set up network variables
NETWORK=
FULLNODE_URL=

case "$ENV" in
"testnet")
    NETWORK="testnet"
    FULLNODE_URL="https://fullnode.testnet.sui.io:443"
    ;;
*)
    echo "Unknown environment $ENV"
    exit 1
    ;;
esac

multisig_publish() {
    package_path=$1
    package_label=$2
    publish_stderr=$(mktemp)

    echo "Publishing ${package_label} from ${package_path}..." >&2

    gas_coin=$(sui client gas "$admin_multisig_address" --json | jq -r '.[0].gasCoinId')
    if [ -z "$gas_coin" ] || [ "$gas_coin" = "null" ]; then
        echo "No gas coin available for ${admin_multisig_address}" >&2
        rm -f "$publish_stderr"
        exit 1
    fi

    # Compiler diagnostics go to stderr; only stdout is the base64 tx bytes.
    if ! publish_res_bytes=$(sui client publish \
        --skip-dependency-verification \
        --gas "$gas_coin" \
        --gas-budget 500000000 \
        --serialize-unsigned-transaction \
        "$package_path" 2>"$publish_stderr"); then
        cat "$publish_stderr" >&2
        rm -f "$publish_stderr"
        exit 1
    fi
    rm -f "$publish_stderr"
    if ! is_valid_tx_bytes "$publish_res_bytes"; then
        echo "Failed to build publish transaction for ${package_label}" >&2
        exit 1
    fi

    user1_sig=$(sui keytool sign --address "$user1_address" --data "$publish_res_bytes" --json | jq -r '.suiSignature')
    user2_sig=$(sui keytool sign --address "$user2_address" --data "$publish_res_bytes" --json | jq -r '.suiSignature')

    admin_multi_sig=$(sui keytool multi-sig-combine-partial-sig \
        --pks "$user1_pk" "$user2_pk" \
        --weights 1 1 \
        --threshold 2 \
        --sigs "$user1_sig" "$user2_sig" \
        --json \
        | jq -r '.multisigSerialized')

    publish_result=$(sui client execute-signed-tx --tx-bytes "$publish_res_bytes" --signatures "$admin_multi_sig" --json 2>/dev/null)
    tx_status=$(echo "$publish_result" | jq -r '.effects.status.status // empty')
    if [ -z "$publish_result" ] || [ "$tx_status" != "success" ]; then
        echo "Failed to execute publish transaction for ${package_label}" >&2
        if [ -n "$publish_result" ]; then
            echo "$publish_result" | jq '.' >&2
        fi
        exit 1
    fi
    echo "$publish_result"
}

extract_package_id() {
    echo "$1" | jq -r '
        (.objectChanges[]? | select(.type == "published") | .packageId),
        (.effects.created[]?
            | select(.owner == "Immutable" or (.owner | type == "object" and has("Immutable")))
            | select((.reference.version | tostring) == "1")
            | .reference.objectId)
    ' | head -1
}

extract_created_object() {
  echo "$1" | jq -r --arg pattern "$2" '
    .objectChanges[]?
    | select(.type == "created" and (.objectType | endswith($pattern)))
    | .objectId
  ' | head -1
}

package_is_published() {
    package_dir=$1
    env_name=$2
    [ -f "${package_dir}/Published.toml" ] && grep -q "\\[published.${env_name}\\]" "${package_dir}/Published.toml"
}

read_published_package_id() {
    package_dir=$1
    env_name=$2
    sed -n "/\\[published.${env_name}\\]/,/^\\[/p" "${package_dir}/Published.toml" \
        | sed -n 's/^published-at = "\(.*\)"/\1/p' | head -1
}

publish_dependency() {
    package_path=$1
    package_label=$2
    shared_object_suffix=$3

    if package_is_published "$package_path" "$NETWORK"; then
        echo "Skipping ${package_label} publish (already recorded in Published.toml)" >&2
        package_id=$(read_published_package_id "$package_path" "$NETWORK")
        if [ -z "$package_id" ]; then
            echo "Failed to read published package ID for ${package_label}" >&2
            exit 1
        fi
        shared_object=""
        if [ -f .publish.state.json ]; then
            case "$package_label" in
            consortium) shared_object=$(jq -r '.shared_consortium // empty' .publish.state.json) ;;
            bascule) shared_object=$(jq -r '.shared_bascule // empty' .publish.state.json) ;;
            esac
        fi
        echo "${package_id}|${shared_object}"
        return 0
    fi

    publish_result=$(multisig_publish "$package_path" "$package_label")
    record_publication "$package_path" "$publish_result" "$NETWORK"
    package_id=$(extract_package_id "$publish_result")
    shared_object=$(extract_created_object "$publish_result" "$shared_object_suffix")
    if [ -z "$package_id" ] || [ "$package_id" = "null" ]; then
        echo "Failed to publish ${package_label}: missing package ID in transaction result" >&2
        exit 1
    fi
    echo "${package_id}|${shared_object}"
}

is_valid_tx_bytes() {
    case "$1" in
    ""|*[!A-Za-z0-9+/=]*)
        return 1
        ;;
    esac
    return 0
}

record_publication() {
    package_dir=$1
    publish_result=$2
    env_name=$3

    package_id=$(extract_package_id "$publish_result")
    upgrade_cap=$(extract_created_object "$publish_result" "package::UpgradeCap")
    chain_id=$(sui client chain-identifier)
    toolchain=$(sui --version 2>/dev/null | awk '{print $2}')

    if [ -z "$package_id" ] || [ "$package_id" = "null" ]; then
        echo "Failed to record publication for ${package_dir}: missing package ID" >&2
        exit 1
    fi
    if [ -z "$upgrade_cap" ] || [ "$upgrade_cap" = "null" ]; then
        echo "Failed to record publication for ${package_dir}: missing upgrade cap" >&2
        exit 1
    fi

    cat > "${package_dir}/Published.toml" <<EOF
# generated by publish.sh
[published.${env_name}]
chain-id = "${chain_id}"
original-id = "${package_id}"
published-at = "${package_id}"
version = 1
toolchain-version = "${toolchain}"
build-config = { flavor = "sui", edition = "2024.beta" }
upgrade-capability = "${upgrade_cap}"
EOF
}

# Switch to the selected environment
echo "Switching to environment: {$ENV}"
sui client switch --env $ENV

# Set up multisig addresses
addresses=$(sui client addresses --json)

# Define the roles
vals=("user1" "user2")

# Loop through each role in the vals array
for role in "${vals[@]}"; do
    echo "Checking if $role address is available"

    # Check if the address exists
    has_role=$(echo "$addresses" | jq -r --arg role "$role" '.addresses | map(contains([$role])) | any')

    # If the address does not exist, create one and request tokens
    if [ "$has_role" = "false" ]; then
        echo "Did not find '$role' in the addresses. Creating one and requesting tokens."
        sui client new-address ed25519 "$role"
    fi
done

# Export keys and addresses for each role
user1=$(sui keytool export --key-identity user1 --json)
user1_pk=$(echo $user1 | jq -r '.key.publicBase64Key')
user1_pk_hex=$(echo $user1_pk | base64 -d | xxd -p | tr -d '\n')
user1_address=$(echo $user1 | jq -r '.key.suiAddress')
user1_sk=$(echo $user1 | jq -r '.exportedPrivateKey')
echo "user1 Address: $user1_address"

user2=$(sui keytool export --key-identity user2 --json)
user2_pk=$(echo $user2 | jq -r '.key.publicBase64Key')
user2_pk_hex=$(echo $user2_pk | base64 -d | xxd -p | tr -d '\n')
user2_address=$(echo $user2 | jq -r '.key.suiAddress')
user2_sk=$(echo $user2 | jq -r '.exportedPrivateKey')
echo "user2 Address: $user2_address"

# Create multisig addresses
admin_multisig_address=$(sui keytool multi-sig-address --pks "$user1_pk" "$user2_pk" --weights 1 1 --threshold 2 --json | jq -r '.multisigAddress')
echo "Admin Multisig Address: $admin_multisig_address"

# Request tokens for multisig address
sui client faucet --address $admin_multisig_address

consortium_package_id=
sharedConsortium=
bascule_package_id=
sharedBascule=

if [ "$LBTC_ONLY" = "false" ]; then
    consortium_info=$(publish_dependency "../move/consortium" "consortium" "consortium::Consortium")
    consortium_package_id=${consortium_info%%|*}
    sharedConsortium=${consortium_info#*|}
    echo "Consortium package ID: $consortium_package_id"
    echo "Shared consortium object: $sharedConsortium"

    bascule_info=$(publish_dependency "../move/bascule" "bascule" "bascule::Bascule")
    bascule_package_id=${bascule_info%%|*}
    sharedBascule=${bascule_info#*|}
    echo "Bascule package ID: $bascule_package_id"
    echo "Shared bascule object: $sharedBascule"

    cat > .publish.state.json <<EOF
{
  "consortium_package_id": "$consortium_package_id",
  "bascule_package_id": "$bascule_package_id",
  "shared_consortium": "$sharedConsortium",
  "shared_bascule": "$sharedBascule"
}
EOF
else
    if [ ! -f .publish.state.json ]; then
        echo "Missing .publish.state.json. Run without --lbtc-only first." >&2
        exit 1
    fi
    consortium_package_id=$(jq -r '.consortium_package_id' .publish.state.json)
    bascule_package_id=$(jq -r '.bascule_package_id' .publish.state.json)
    sharedConsortium=$(jq -r '.shared_consortium' .publish.state.json)
    sharedBascule=$(jq -r '.shared_bascule' .publish.state.json)
    echo "Skipping consortium/bascule publish (--lbtc-only)"
    echo "Consortium package ID: $consortium_package_id"
    echo "Bascule package ID: $bascule_package_id"
fi

publish_res=$(multisig_publish "../move/lbtc" "lbtc")
echo "$publish_res" > .publish.res.json

packageId=$(extract_package_id "$publish_res")
sharedControlledTreasury=$(extract_created_object "$publish_res" "treasury::ControlledTreasury")
upgradeCap=$(extract_created_object "$publish_res" "package::UpgradeCap")
txDigest=$(echo "$publish_res" | jq -r '.effects.transactionDigest')

if [ -z "$packageId" ] || [ "$packageId" = "null" ]; then
    echo "LBTC publish failed: package ID not found in transaction effects"
    exit 1
fi

echo "Package ID: $packageId"

# Generate the .env file with the necessary variables
cat >../setup/.env<<-ENV
SUI_NETWORK=$FULLNODE_URL
SUI_ENV=$NETWORK
TX_DIGEST=$txDigest
UPGRADE_CAP=$upgradeCap
PACKAGE_ID=$packageId
CONSORTIUM_PACKAGE_ID=$consortium_package_id
BASCULE_PACKAGE_ID=$bascule_package_id
SHARED_CONSORTIUM=$sharedConsortium
SHARED_CONTROLLED_TREASURY=$sharedControlledTreasury
SHARED_BASCULE=$sharedBascule
MULTISIG_ADDRESS=$admin_multisig_address
USER_1_ADDRESS=$user1_address
USER_2_ADDRESS=$user2_address
USER_1_PK=$user1_pk
USER_2_PK=$user2_pk
USER_1_SK=$user1_sk
USER_2_SK=$user2_sk
ENV

echo "Environment variables have been set in .env file."
echo "Publishing completed successfully with multisig."
