import "dotenv/config";
import * as anchor from "@coral-xyz/anchor";
import { BN, Program } from "@coral-xyz/anchor";
import { Keypair, LAMPORTS_PER_SOL, PublicKey, SystemProgram } from "@solana/web3.js";
import * as spl from "@solana/spl-token";
import { Lbtc } from "../target/types/lbtc";
import { sha256 } from "js-sha256";
import bs58 from "bs58";
import nacl from "tweetnacl";
import chai from "chai";
import chaiAsPromised from "chai-as-promised";
import { ConsortiumUtility, signatureToBytes } from "./utils/consortium_utilities";
import { withBlockhashRetry } from "./utils/utils";

chai.use(chaiAsPromised);
const expect = chai.expect;

declare module "@coral-xyz/anchor" {
  interface BN {
    toBigInt(): bigint;
  }
}

BN.prototype.toBigInt = function (): bigint {
  return BigInt(this.toString(10));
};

class MintPayload {
  prefix: string;
  chainId: string;
  destinationAddress: string;
  amount: string;
  txId: string;
  vout: string;

  constructor(hex: string) {
    this.prefix = hex.slice(0, 8);
    this.chainId = hex.slice(8, 72);
    this.destinationAddress = hex.slice(72, 136);
    this.amount = hex.slice(136, 200);
    this.txId = hex.slice(200, 264);
    this.vout = hex.slice(264);
  }

  hex(): string {
    return this.prefix + this.chainId + this.destinationAddress + this.amount + this.txId + this.vout;
  }

  bytes(): Buffer {
    return Buffer.from(this.hex(), "hex");
  }

  hash(): string {
    return sha256(this.bytes());
  }

  hashAsBytes(): Buffer {
    return Buffer.from(this.hash(), "hex");
  }

  recipientPubKey(): PublicKey {
    let address = bs58.encode(Buffer.from(this.destinationAddress, "hex"));
    return new PublicKey(address);
  }

  amountBigInt(): bigint {
    return BigInt("0x" + this.amount);
  }
}

class FeePermit {
  prefix: string;
  chainId: string;
  programId: string;
  maxFees: string;
  expire: string;

  constructor(programId: string, maxFees: number) {
    this.prefix = "04acbbb2";
    this.chainId = "0259db5080fc2c6d3bcf7ca90712d3c2e5e6c28f27f0dfbb9953bdb0894c03ab";
    this.programId = programId;
    this.maxFees = maxFees.toString(16).padStart(64, "0");
    // Hardcode end of unix epoch so tests always pass
    this.expire = "00000000000000000000000000000000000000000000000000000000ffffffff";
  }

  hex(): string {
    return this.prefix + this.chainId + this.programId + this.maxFees + this.expire;
  }

  bytes(): Buffer {
    return Buffer.from(this.hex(), "hex");
  }

  signature(secretKey: Uint8Array): Buffer {
    return Buffer.from(nacl.sign.detached(this.bytes(), secretKey));
  }

  maxFeesBigInt(): bigint {
    return BigInt("0x" + this.maxFees);
  }
}

describe("LBTC", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.Lbtc as Program<Lbtc>;

  let payer: Keypair;
  let user: Keypair;
  let admin: Keypair;
  let operator: Keypair;
  let pauser: Keypair;
  let minter: Keypair;
  let claimer: Keypair;
  let configPDA: PublicKey;
  let treasury: PublicKey;
  const mintKeys = Keypair.fromSeed(Uint8Array.from(Array(32).fill(5)));
  let mint: PublicKey;
  let recipient: Keypair;
  let recipientTA: PublicKey;
  const tokenAuth = PublicKey.findProgramAddressSync(
    [Buffer.from("token_authority")],
    program.programId
  )[0] as PublicKey;
  let metadata_seed = new Uint8Array(32);
  for (let i = 0; i < metadata_seed.length; i++) {
    metadata_seed[i] = 1;
  }

  // Utility function for airdrops
  async function fundWallet(account, amount) {
    const publicKey = account.publicKey ? account.publicKey : account;

    const tx = await provider.connection.requestAirdrop(publicKey, amount);
    const lastBlockHash = await provider.connection.getLatestBlockhash();

    await provider.connection.confirmTransaction({
      blockhash: lastBlockHash.blockhash,
      lastValidBlockHeight: lastBlockHash.lastValidBlockHeight,
      signature: tx,
      nonceAccountPubkey: publicKey
    });
  }

  payer = Keypair.generate();
  user = Keypair.generate();
  admin = Keypair.generate();
  operator = Keypair.generate();
  pauser = Keypair.generate();
  minter = Keypair.generate();
  claimer = Keypair.generate();
  const t = Keypair.generate();
  recipient = Keypair.fromSeed(Uint8Array.from(Array(32).fill(4)));

  let consortiumUtility: ConsortiumUtility;

  before(async () => {
    await fundWallet(payer, 25 * LAMPORTS_PER_SOL);
    await fundWallet(user, 25 * LAMPORTS_PER_SOL);
    await fundWallet(admin, 25 * LAMPORTS_PER_SOL);
    await fundWallet(operator, 25 * LAMPORTS_PER_SOL);
    await fundWallet(pauser, 25 * LAMPORTS_PER_SOL);
    await fundWallet(minter, 25 * LAMPORTS_PER_SOL);
    await fundWallet(claimer, 25 * LAMPORTS_PER_SOL);

    await fundWallet(t, 25 * LAMPORTS_PER_SOL);
    await fundWallet(recipient, 25 * LAMPORTS_PER_SOL);

    mint = await spl.createMint(provider.connection, admin, tokenAuth, admin.publicKey, 8, mintKeys);

    [configPDA] = PublicKey.findProgramAddressSync([Buffer.from("lbtc_config")], program.programId);

    treasury = await spl.createAssociatedTokenAccount(provider.connection, t, mint, t.publicKey);

    recipientTA = await spl.createAssociatedTokenAccount(provider.connection, recipient, mint, recipient.publicKey);

    consortiumUtility = new ConsortiumUtility(null, []);
    consortiumUtility.generateAndAddKeypairs(6);
  });

  describe("Initialize and set roles", function () {
    it("initialize: fails when payer is not deployer", async () => {
      const burnCommission = new BN(1);
      const dustFeeRate = new BN(1000);
      const mintFee = new BN(1);
      const programData = PublicKey.findProgramAddressSync(
        [program.programId.toBuffer()],
        new PublicKey("BPFLoaderUpgradeab1e11111111111111111111111")
      )[0];
      await expect(
          withBlockhashRetry(() =>
            program.methods
          .initialize(admin.publicKey, burnCommission, dustFeeRate, mintFee)
          .accounts({
            deployer: payer.publicKey,
            programData,
            mint,
            treasury,
            config: configPDA,
            systemProgram: SystemProgram.programId
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
          )
        ).to.be.rejectedWith("A raw constraint was violated.");
    });

    it("initialize: successful", async () => {
      const burnCommission = new BN(1);
      const dustFeeRate = new BN(1000);
      const mintFee = new BN(1);
      const programData = PublicKey.findProgramAddressSync(
        [program.programId.toBuffer()],
        new PublicKey("BPFLoaderUpgradeab1e11111111111111111111111")
      )[0];
      await withBlockhashRetry(() =>
        program.methods
        .initialize(admin.publicKey, burnCommission, dustFeeRate, mintFee)
        .accounts({
          deployer: provider.wallet.publicKey,
          programData,
          mint,
          treasury,
          config: configPDA,
          systemProgram: SystemProgram.programId
        })
        .signers([Keypair.fromSecretKey(provider.wallet.payer.secretKey)])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.admin.toBase58()).to.be.eq(admin.publicKey.toBase58());
    });

    //Operator is a role which can set mint fee for autoclaim
    it("setOperator: successful by admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .setOperator(operator.publicKey)
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.operator.toBase58() == operator.publicKey.toBase58());
    });

    //Treasury is an account that collects fees for autoclaim and redeem
    it("setTreasury: successful by admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .setTreasury()
        .accounts({ payer: admin.publicKey, config: configPDA, treasury })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.treasury.toBase58() == treasury.toBase58());
    });

    //Claimer is a role which can perform autoclaim
    it("addClaimer: successful by admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .addClaimer(claimer.publicKey)
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.claimers[0].toBase58() == claimer.publicKey.toBase58());
    });

    //Claimer is a role which can perform autoclaim
    it("addClaimer: adding twice should not increase claimers", async () => {
      await expect(
          withBlockhashRetry(() =>
            program.methods
          .addClaimer(claimer.publicKey)
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
          )
        ).to.be.rejectedWith("ClaimerExists");
    });

    //Pauser is a role that can only set contracts on pause
    it("addPauser: successful by admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .addPauser(pauser.publicKey)
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.pausers[0].toBase58() == pauser.publicKey.toBase58());
    });

    //Pauser is a role that can only set contracts on pause
    it("addPauser: adding twice should not increase pausers", async () => {
      await expect(
          withBlockhashRetry(() =>
            program.methods
          .addPauser(pauser.publicKey)
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
          )
        ).to.be.rejectedWith("PauserExists");
    });

    //MintFee is a fee that charged for autoclaim and transfered to treasury
    it("setMintFee: successful by operator", async () => {
      const mintFee = new BN(10);
      const tx2 = await withBlockhashRetry(() =>
        program.methods
        .setMintFee(mintFee)
        .accounts({ payer: operator.publicKey, config: configPDA })
        .signers([operator])
        .rpc({ commitment: "confirmed" })
      );

      let cfg = await program.account.config.fetch(configPDA);
      expect(cfg.mintFee.toBigInt()).to.be.eq(mintFee.toBigInt());
    });

    //BurnCommission is a fee that charged at redeem
    it("setBurnCommission: successful by admin", async () => {
      const burnCommission = new BN(10);
      await withBlockhashRetry(() =>
        program.methods
        .setBurnCommission(burnCommission)
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.burnCommission.eq(burnCommission));
    });

    it("setDustFeeRate: successful by admin", async () => {
      const dustFeeRate = new BN(3000);
      await withBlockhashRetry(() =>
        program.methods
        .setDustFeeRate(dustFeeRate)
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.dustFeeRate.eq(dustFeeRate));
    });

    it("transferOwnership: failure from unauthorized party", async () => {
      await expect(
          withBlockhashRetry(() =>
            program.methods
          .transferOwnership(payer.publicKey)
          .accounts({ payer: payer.publicKey, config: configPDA })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
          )
        ).to.be.rejectedWith("An address constraint was violated");
    });

    it("transferOwnership: successful by admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .transferOwnership(payer.publicKey)
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.admin.toBase58()).to.be.equal(admin.publicKey.toBase58());
      expect(cfg.pendingAdmin.toBase58()).to.be.equal(payer.publicKey.toBase58());
    });

    it("acceptOwnership: failure from unauthorized party", async () => {
      await expect(
          withBlockhashRetry(() =>
            program.methods
          .acceptOwnership()
          .accounts({ payer: user.publicKey, config: configPDA })
          .signers([user])
          .rpc({ commitment: "confirmed" })
          )
        ).to.be.rejectedWith("An address constraint was violated");
    });

    it("acceptOwnership: successful by pending admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .acceptOwnership()
        .accounts({ payer: payer.publicKey, config: configPDA })
        .signers([payer])
        .rpc({ commitment: "confirmed" })
      );

      const cfg = await program.account.config.fetch(configPDA);
      expect(cfg.admin.toBase58()).to.be.equal(payer.publicKey.toBase58());

      // Reverse it for remainder of test.
      const tx2 = await withBlockhashRetry(() =>
        program.methods
        .transferOwnership(admin.publicKey)
        .accounts({ payer: payer.publicKey, config: configPDA })
        .signers([payer])
        .rpc({ commitment: "confirmed" })
      );

      const tx3 = await withBlockhashRetry(() =>
        program.methods
        .acceptOwnership()
        .accounts({ payer: admin.publicKey, config: configPDA })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const cfg2 = await program.account.config.fetch(configPDA);
      expect(cfg2.admin.toBase58()).to.be.equal(admin.publicKey.toBase58());
    });

    it("changeMintAuth: successful when called by admin", async () => {
      await withBlockhashRetry(() =>
        program.methods
        .changeMintAuth(payer.publicKey)
        .accounts({
          payer: admin.publicKey,
          config: configPDA,
          mint,
          currentAuth: tokenAuth,
          tokenProgram: spl.TOKEN_PROGRAM_ID,
          tokenAuthority: tokenAuth
        })
        .signers([admin])
        .rpc({ commitment: "confirmed" })
      );

      const info = await spl.getMint(provider.connection, mint);
      expect(info.mintAuthority.toBase58()).to.be.equal(payer.publicKey.toBase58());

      // Revert to tokenauth to facilitate further testing
      const tx2 = await spl.setAuthority(
        provider.connection,
        payer,
        mint,
        payer,
        spl.AuthorityType.MintTokens,
        tokenAuth
      );

      const info2 = await spl.getMint(provider.connection, mint);
      expect(info2.mintAuthority.toBase58()).to.be.equal(tokenAuth.toBase58());
    });
  });

  describe("Setters and getters", () => {
    describe("Pause", function () {
      it("pause: rejects when called by not a pauser", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .pause()
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Unauthorized function call");
      });

      it("pause: successful by pauser", async () => {
        const tx2 = await withBlockhashRetry(() =>
          program.methods
          .pause()
          .accounts({ payer: pauser.publicKey, config: configPDA })
          .signers([pauser])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.paused == true);
      });

      it("createMintPayload: rejects when paused", async () => {
        const mintPayload = new MintPayload(
          "f2e73f7c0259db5080fc2c6d3bcf7ca90712d3c2e5e6c28f27f0dfbb9953bdb0894c03abd55cad4b145c9fa6f0c634827d2d3a889bcd4e6e6a9527a89b2f8259bfcbc8f80000000000000000000000000000000000000000000000000000000000004e2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        );

        const mintPayloadPDA = PublicKey.findProgramAddressSync(
          [mintPayload.hashAsBytes()],
          program.programId
        )[0] as PublicKey;

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .createMintPayload(mintPayload.hashAsBytes(), mintPayload.bytes())
            .accounts({
              payer: payer.publicKey,
              config: configPDA,
              payload: mintPayloadPDA
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("LBTC contract is paused");
      });

      it("unpause: rejects when called by admin", async () => {
        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.paused == true);
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .unpause()
            .accounts({ payer: admin.publicKey, config: configPDA })
            .signers([admin])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith(
          "Error Code: Unauthorized. Error Number: 6000. Error Message: Unauthorized function call."
        );
      });

      it("unpause: successful by pauser", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .unpause()
          .accounts({ payer: pauser.publicKey, config: configPDA })
          .signers([pauser])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.paused == false);
      });

      it("unpause: rejects when not paused", async () => {
        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.paused == true);
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .unpause()
            .accounts({ payer: pauser.publicKey, config: configPDA })
            .signers([pauser])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("LBTC contract is not paused");
      });

      it("disableWithdrawals: successful by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .disableWithdrawals()
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.withdrawalsEnabled).to.be.false;
      });

      it("enableWithdrawals: successful by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .enableWithdrawals()
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg2 = await program.account.config.fetch(configPDA);
        expect(cfg2.withdrawalsEnabled).to.be.true;
      });

      it("enableWithdrawals: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .enableWithdrawals()
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("disableWithdrawals: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .disableWithdrawals()
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });
    });

    //Not implemented yet
    describe("Bascule", function () {
      it("enableBascule: successful by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .enableBascule()
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.basculeEnabled).to.be.true;
      });

      it("disableBascule: successful by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .disableBascule()
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.basculeEnabled).to.be.false;
      });

      it("enableBascule: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .enableBascule()
            .accounts({
              payer: payer.publicKey,
              config: configPDA
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("disableBascule: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .disableBascule()
            .accounts({
              payer: payer.publicKey,
              config: configPDA
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });
    });

    describe("Setters negative cases", function () {
      it("setOperator: rejects when called by not an admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setOperator(payer.publicKey)
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("setMintFee: rejects when called by not an operator", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setMintFee(new BN(10))
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("setBurnCommission: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setBurnCommission(new BN(10))
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("setDustFeeRate: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setDustFeeRate(new BN(3000))
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("setTreasury: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setTreasury()
            .accounts({ payer: payer.publicKey, config: configPDA, treasury })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("addClaimer: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .addClaimer(payer.publicKey)
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("addPauser: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .addPauser(payer.publicKey)
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("changeMintAuth: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .changeMintAuth(payer.publicKey)
            .accounts({
              payer: payer.publicKey,
              config: configPDA,
              mint,
              currentAuth: tokenAuth,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              tokenAuthority: tokenAuth
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });
    });

    describe("Remove roles", function () {
      let newClaimer, newPauser;

      before(async function () {
        newClaimer = Keypair.generate();
        await withBlockhashRetry(() =>
          program.methods
          .addClaimer(newClaimer.publicKey)
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        newPauser = Keypair.generate();
        await withBlockhashRetry(() =>
          program.methods
          .addPauser(newPauser.publicKey)
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.claimers[1].toBase58() == newClaimer.publicKey.toBase58());
        expect(cfg.pausers[1].toBase58() == newPauser.publicKey.toBase58());
      });

      it("removeClaimer: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .removeClaimer(newClaimer.publicKey)
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("removeClaimer: successfully by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .removeClaimer(newClaimer.publicKey)
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.claimers).to.has.length(1);
      });

      it("removePauser: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .removePauser(newPauser.publicKey)
            .accounts({ payer: payer.publicKey, config: configPDA })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("removePauser: successfully by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .removePauser(newPauser.publicKey)
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.pausers).to.has.length(1);
      });
    });
  });

  describe("Consortium actions", () => {
    //Only admin can set initial valset
    describe("Initial valset by admin", function () {
      let initialValset: Buffer;
      let initialValsetHash: string;
      let initialValidators: Uint8Array[] = [];
      const initialWeights = [new BN(1), new BN(1)];
      const initialThreshold = new BN(2);
      let metadataPDAPayer: PublicKey;
      let payloadPDAPayer: PublicKey;
      let metadataPDA: PublicKey;
      let payloadPDA: PublicKey;
      before(async () => {
        const keypairs = consortiumUtility.getKeypairs();
        initialValset = consortiumUtility.createValSetPayload(1, 2, 1, [keypairs[0], keypairs[1]]);
        initialValsetHash = sha256(initialValset);
        const validatorPubkeys = consortiumUtility.getPublicKeysAsBytes();
        initialValidators.push(validatorPubkeys[0]);
        initialValidators.push(validatorPubkeys[1]);

        metadataPDAPayer = PublicKey.findProgramAddressSync(
          [Buffer.from(initialValsetHash, "hex"), metadata_seed, payer.publicKey.toBuffer()],
          program.programId
        )[0];
        payloadPDAPayer = PublicKey.findProgramAddressSync(
          [Buffer.from(initialValsetHash, "hex"), payer.publicKey.toBuffer()],
          program.programId
        )[0];

        metadataPDA = PublicKey.findProgramAddressSync(
          [Buffer.from(initialValsetHash, "hex"), metadata_seed, admin.publicKey.toBuffer()],
          program.programId
        )[0];
        payloadPDA = PublicKey.findProgramAddressSync(
          [Buffer.from(initialValsetHash, "hex"), admin.publicKey.toBuffer()],
          program.programId
        )[0];
      });

      it("createMetadataForValsetPayload: anyone can create", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createMetadataForValsetPayload(Buffer.from(initialValsetHash, "hex"))
          .accounts({
            payer: payer.publicKey,
            metadata: metadataPDAPayer
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );
      });

      it("postMetadataForValsetPayload: rejects when posted by not the creator", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .postMetadataForValsetPayload(initialValidators, initialWeights)
            .accounts({
              payer: admin.publicKey,
              metadata: metadataPDAPayer
            })
            .signers([admin])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("A seeds constraint was violated");
      });

      it("postMetadataForValsetPayload: successful by creator", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postMetadataForValsetPayload(initialValidators, initialWeights)
          .accounts({
            payer: payer.publicKey,
            metadata: metadataPDAPayer
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );
      });

      it("createValsetPayload: rejects when called by not the creator", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .createValsetPayload(new BN(1), new BN(1), new BN(1))
            .accounts({
              payer: admin.publicKey,
              config: configPDA,
              metadata: metadataPDAPayer,
              payload: payloadPDAPayer
            })
            .signers([admin])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("A seeds constraint was violated");
      });

      it("createValsetPayload: successful by the creator", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createValsetPayload(new BN(1), initialThreshold, new BN(1))
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            metadata: metadataPDAPayer,
            payload: payloadPDAPayer
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );
      });

      it("setInitialValset: rejects when called by not admin", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setInitialValset()
            .accounts({
              payer: payer.publicKey,
              config: configPDA,
              metadata: metadataPDAPayer,
              payload: payloadPDAPayer
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("setInitialValset: successful by admin", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createMetadataForValsetPayload(Buffer.from(initialValsetHash, "hex"))
          .accounts({
            payer: admin.publicKey,
            metadata: metadataPDA
          })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .postMetadataForValsetPayload(initialValidators, initialWeights)
          .accounts({
            payer: admin.publicKey,
            metadata: metadataPDA
          })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .createValsetPayload(new BN(1), initialThreshold, new BN(1))
          .accounts({
            payer: admin.publicKey,
            config: configPDA,
            metadata: metadataPDA,
            payload: payloadPDA
          })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .setInitialValset()
          .accounts({ payer: admin.publicKey, config: configPDA, metadata: metadataPDA, payload: payloadPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.epoch.toBigInt()).to.be.eq(1n);
        expect(cfg.weights.map(n => n.toBigInt())).to.have.deep.members([1n, 1n]);
        expect(cfg.weightThreshold.toBigInt()).to.be.eq(initialThreshold.toBigInt());
        expect(cfg.validators.map(v => Buffer.from(v))).to.have.deep.members(initialValidators);
      });
    });

    //Any other account can set next valset with valid signatures
    describe("Next valset by anyone with valid signatures", function () {
      let nextValset: Buffer;
      let nextValsetHash: string;
      let nextValidators: Uint8Array[] = [];
      const nextWeights = [new BN(1), new BN(1), new BN(1)];
      let sigs: Uint8Array[] = [];
      let metadataPDA2: PublicKey;
      let payloadPDA2: PublicKey;

      before(async () => {
        const keypairs = consortiumUtility.getKeypairs();
        nextValset = consortiumUtility.createValSetPayload(2, 2, 2, [keypairs[0], keypairs[1], keypairs[2]]);
        nextValsetHash = sha256(nextValset);
        const validatorPubkeys = consortiumUtility.getPublicKeysAsBytes();
        nextValidators.push(validatorPubkeys[0]);
        nextValidators.push(validatorPubkeys[1]);
        nextValidators.push(validatorPubkeys[2]);
        const signatures = consortiumUtility.signPayloadWithIndices(nextValset, [0, 1]);
        sigs.push(signatureToBytes(signatures[0]));
        sigs.push(signatureToBytes(signatures[1]));

        metadataPDA2 = PublicKey.findProgramAddressSync(
          [Buffer.from(nextValsetHash, "hex"), metadata_seed, payer.publicKey.toBuffer()],
          program.programId
        )[0];

        payloadPDA2 = PublicKey.findProgramAddressSync(
          [Buffer.from(nextValsetHash, "hex"), payer.publicKey.toBuffer()],
          program.programId
        )[0];
      });

      it("user loaded invalid metadata and cant create payload", async () => {
        const metadataPDA2 = PublicKey.findProgramAddressSync(
          [Buffer.from(nextValsetHash, "hex"), metadata_seed, user.publicKey.toBuffer()],
          program.programId
        )[0];

        const payloadPDA2 = PublicKey.findProgramAddressSync(
          [Buffer.from(nextValsetHash, "hex"), user.publicKey.toBuffer()],
          program.programId
        )[0];

        await withBlockhashRetry(() =>
          program.methods
          .createMetadataForValsetPayload(Buffer.from(nextValsetHash, "hex"))
          .accounts({
            payer: user.publicKey,
            metadata: metadataPDA2
          })
          .signers([user])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .postMetadataForValsetPayload(nextValidators, nextWeights)
          .accounts({
            payer: user.publicKey,
            metadata: metadataPDA2
          })
          .signers([user])
          .rpc({ commitment: "confirmed" })
        );

        const validatorPubkeys = consortiumUtility.getPublicKeysAsBytes();
        await withBlockhashRetry(() =>
          program.methods
          .postMetadataForValsetPayload([validatorPubkeys[3]], [new BN(1)])
          .accounts({
            payer: user.publicKey,
            metadata: metadataPDA2
          })
          .signers([user])
          .rpc({ commitment: "confirmed" })
        );

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .createValsetPayload(new BN(2), new BN(2), new BN(2))
            .accounts({
              payer: user.publicKey,
              config: configPDA,
              metadata: metadataPDA2,
              payload: payloadPDA2
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Passed valset payload hash does not match computed hash");
      });

      it("setInitialValset: rejects for nextValset", async () => {
        const metadataPDA2 = PublicKey.findProgramAddressSync(
          [Buffer.from(nextValsetHash, "hex"), metadata_seed, admin.publicKey.toBuffer()],
          program.programId
        )[0];
        const payloadPDA2 = PublicKey.findProgramAddressSync(
          [Buffer.from(nextValsetHash, "hex"), admin.publicKey.toBuffer()],
          program.programId
        )[0];

        await withBlockhashRetry(() =>
          program.methods
          .createMetadataForValsetPayload(Buffer.from(nextValsetHash, "hex"))
          .accounts({
            payer: admin.publicKey,
            metadata: metadataPDA2
          })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .postMetadataForValsetPayload(nextValidators, nextWeights)
          .accounts({
            payer: admin.publicKey,
            metadata: metadataPDA2
          })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .createValsetPayload(new BN(2), new BN(2), new BN(2))
          .accounts({
            payer: admin.publicKey,
            config: configPDA,
            metadata: metadataPDA2,
            payload: payloadPDA2
          })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setInitialValset()
            .accounts({ payer: admin.publicKey, config: configPDA, metadata: metadataPDA2, payload: payloadPDA2 })
            .signers([admin])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Validator set already set");
      });

      it("postMetadataForValsetPayload: post valid metadata", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createMetadataForValsetPayload(Buffer.from(nextValsetHash, "hex"))
          .accounts({
            payer: payer.publicKey,
            metadata: metadataPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .postMetadataForValsetPayload(nextValidators, nextWeights)
          .accounts({
            payer: payer.publicKey,
            metadata: metadataPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );
      });

      it("createValsetPayload: post valid payload", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createValsetPayload(new BN(2), new BN(2), new BN(2))
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            metadata: metadataPDA2,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );
      });

      it("setNextValset: rejects when not enough signatures", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postValsetSignatures([sigs[0]], [new BN(0)])
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const payload2 = await program.account.valsetPayload.fetch(payloadPDA2);
        expect(payload2.weight.toBigInt()).to.be.eq(1n);

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .setNextValset()
            .accounts({
              payer: payer.publicKey,
              config: configPDA,
              metadata: metadataPDA2,
              payload: payloadPDA2
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Not enough valid signatures");
      });

      it("postMetadataForValsetPayload: append unknown validator 2", async () => {
        const validatorPubkeys = consortiumUtility.getPublicKeysAsBytes();
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .postMetadataForValsetPayload([validatorPubkeys[4]], [new BN(1)])
            .accounts({
              payer: payer.publicKey,
              metadata: metadataPDA2
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Metadata finalized already");
      });

      it("postValsetSignatures: ignores invalid signatures", async () => {
        const wrongSigs = [
          Buffer.from(
            "ad9cbefb2570d94d82095766a142e7f3eb115313f364db7c0fa01ac246aca5ff3654b5f6dbcdbfe086c86e5e7ae8e5178986944dafb077303a99e2bd75663c86",
            "hex"
          ),
          Buffer.from(
            "a474df436d805d9bce1ae640e7802c88e655496f008f428fd953f623a054d7782841f70a5c4ffa6da53ea661762967eb628b81ad6a8d6321f83fb66884855e3a",
            "hex"
          )
        ];

        await withBlockhashRetry(() =>
          program.methods
          .postValsetSignatures(wrongSigs, [new BN(0), new BN(1)])
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const payload2 = await program.account.valsetPayload.fetch(payloadPDA2);
        expect(payload2.weight.toBigInt()).to.be.eq(1n);
      });

      it("postValsetSignatures: ignores duplicates", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postValsetSignatures([sigs[0], sigs[0]], [new BN(0), new BN(0)])
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const payload = await program.account.valsetPayload.fetch(payloadPDA2);
        expect(payload.weight.toBigInt()).to.be.eq(1n);

        await withBlockhashRetry(() =>
          program.methods
          .postValsetSignatures([sigs[0]], [new BN(0)])
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const payload2 = await program.account.valsetPayload.fetch(payloadPDA2);
        expect(payload2.weight.toBigInt()).to.be.eq(1n);
      });

      it("postValsetSignatures: post enough valid signatures", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postValsetSignatures([sigs[1]], [new BN(1)])
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const payload2 = await program.account.valsetPayload.fetch(payloadPDA2);
        expect(payload2.weight.toBigInt()).to.be.eq(2n);
      });

      it("postMetadataForValsetPayload: append unknown validator 2", async () => {
        const validatorPubkeys = consortiumUtility.getPublicKeysAsBytes();
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .postMetadataForValsetPayload([validatorPubkeys[5]], [new BN(1)])
            .accounts({
              payer: payer.publicKey,
              metadata: metadataPDA2
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Metadata finalized already");
      });

      it("setNextValset: successful", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .setNextValset()
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            metadata: metadataPDA2,
            payload: payloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.validators.map(v => Buffer.from(v).toString("hex"))).to.have.deep.members(
          nextValidators.map(v => Buffer.from(v).toString("hex"))
        );
        expect(cfg.epoch.toBigInt()).to.be.eq(2n);
        expect(cfg.weights.map(n => n.toBigInt())).to.have.deep.members([1n, 1n, 1n]);
        expect(cfg.weightThreshold.toBigInt()).to.be.eq(2n);
      });
    });
  });

  describe("Minting and redeeming", () => {
    let userTA: PublicKey;
    let minterTA: PublicKey;

    const scriptPubkey = [0, 20, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2];

    const mintPayload = new MintPayload(
      "f2e73f7c0259db5080fc2c6d3bcf7ca90712d3c2e5e6c28f27f0dfbb9953bdb0894c03abd55cad4b145c9fa6f0c634827d2d3a889bcd4e6e6a9527a89b2f8259bfcbc8f8000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
    );
    const mintPayload2 = new MintPayload(
      "f2e73f7c0259db5080fc2c6d3bcf7ca90712d3c2e5e6c28f27f0dfbb9953bdb0894c03abd55cad4b145c9fa6f0c634827d2d3a889bcd4e6e6a9527a89b2f8259bfcbc8f80000000000000000000000000000000000000000000000000000000000004e2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
    );

    let mintSigs: Uint8Array[];
    let mintSigs2: Uint8Array[];

    const mintPayloadPDA = PublicKey.findProgramAddressSync(
      [mintPayload.hashAsBytes()],
      program.programId
    )[0] as PublicKey;
    const mintPayloadPDA2 = PublicKey.findProgramAddressSync(
      [mintPayload2.hashAsBytes()],
      program.programId
    )[0] as PublicKey;

    const feePermit = new FeePermit(program.programId.toBuffer().toString("hex"), 3);

    const events = [];

    before(async () => {
      userTA = await spl.createAssociatedTokenAccount(provider.connection, user, mint, user.publicKey);
      minterTA = await spl.createAssociatedTokenAccount(provider.connection, minter, mint, minter.publicKey);

      //Subscribe for events
      program.addEventListener("mintProofConsumed", (event, slot, signature) => {
        events.push(event);
      });

      mintSigs = consortiumUtility.signPayloadWithIndices(mintPayload.bytes(), [0, 2]).map(s => signatureToBytes(s));
      mintSigs2 = consortiumUtility.signPayloadWithIndices(mintPayload2.bytes(), [0, 2]).map(s => signatureToBytes(s));
    });

    beforeEach(async () => {
      events.length = 0;
    });

    //Any account can create mint payload
    describe("Create mint payload", function () {
      const invalid_payloads = [
        {
          name: "Invalid prefix",
          modifier: (payload: MintPayload): [Buffer, Buffer] => {
            payload.prefix = "f2e73f7d";
            return [payload.bytes(), payload.hashAsBytes()];
          },
          error: "Invalid action bytes"
        },
        {
          name: "Invalid chain id",
          modifier: (payload: MintPayload): [Buffer, Buffer] => {
            payload.chainId = "d55cad4b145c9fa6f0c634827d2d3a889bcd4e6e6a9527a89b2f8259bfcbc8f9";
            return [payload.bytes(), payload.hashAsBytes()];
          },
          error: "Invalid chain ID"
        },
        {
          name: "Hash does not match payload",
          modifier: (payload: MintPayload): [Buffer, Buffer] => {
            payload.vout = "0000000000000000000000000000000000000000000000000000000000000001";
            return [payload.bytes(), mintPayload.hashAsBytes()];
          },
          error: "Passed mint payload hash does not match computed hash"
        },
        {
          name: "Payload is too long",
          modifier: (payload: MintPayload): [Buffer, Buffer] => {
            payload.vout += "aa";
            return [payload.bytes(), payload.hashAsBytes()];
          },
          error: "Passed mint payload hash does not match computed hash"
        },
        {
          name: "Payload is too short",
          modifier: (payload: MintPayload): [Buffer, Buffer] => {
            payload.vout = "aa";
            return [payload.bytes(), payload.hashAsBytes()];
          },
          error: "The program could not deserialize the given instruction"
        }
      ];

      invalid_payloads.forEach(function (arg) {
        it(`createMintPayload: rejects when ${arg.name}`, async () => {
          const [payload, hash] = arg.modifier(
            new MintPayload(
              "f2e73f7c0259db5080fc2c6d3bcf7ca90712d3c2e5e6c28f27f0dfbb9953bdb0894c03abd55cad4b145c9fa6f0c634827d2d3a889bcd4e6e6a9527a89b2f8259bfcbc8f8000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            )
          );
          const pda = PublicKey.findProgramAddressSync([hash], program.programId)[0];
          await expect(
              withBlockhashRetry(() =>
                program.methods
              .createMintPayload(hash, payload)
              .accounts({
                payer: payer.publicKey,
                config: configPDA,
                payload: pda
              })
              .signers([payer])
              .rpc({ commitment: "confirmed" })
              )
            ).to.be.rejectedWith(arg.error);
        });
      });

      it("createMintPayload: successful", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createMintPayload(mintPayload.hashAsBytes(), mintPayload.bytes())
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: mintPayloadPDA
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        const payload = await program.account.mintPayload.fetch(mintPayloadPDA);
        expect(payload.payload.map(num => num.toString(16).padStart(2, "0")).join("")).to.be.eq(mintPayload.hex());
        expect(payload.signed).to.have.members([false, false, false]);
        expect(payload.weight.toBigInt()).to.be.eq(0n);
        expect(payload.minted).to.be.false;
      });

      it("createMintPayload: rejects when payload already submitted", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .createMintPayload(mintPayload.hashAsBytes(), mintPayload.bytes())
            .accounts({
              payer: payer.publicKey,
              config: configPDA,
              payload: mintPayloadPDA
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith(
          "Transaction simulation failed: Error processing Instruction 0: custom program error: 0x0"
        );
      });
    });

    /*
    To mint with payload account have to:
    1. Create mint payload
    2. Post sufficient number of signatures
    3. Mint
     */
    describe("Add signatures and mint with payload", function () {
      it("mintFromPayload: rejects when there are no signatures", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintFromPayload(mintPayload.hashAsBytes())
            .accounts({
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipient: recipientTA,
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              payload: mintPayloadPDA,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("NotEnoughSignatures");
      });

      // Any account can add mint signatures
      it("postMintSignatures: successful", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postMintSignatures(mintPayload.hashAsBytes(), [mintSigs[0]], [new BN(0)])
          .accounts({ config: configPDA, payload: mintPayloadPDA })
          .rpc({ commitment: "confirmed" })
        );

        const payload = await program.account.mintPayload.fetch(mintPayloadPDA);
        expect(payload.payload.map(num => num.toString(16).padStart(2, "0")).join("")).to.be.eq(mintPayload.hex());
        expect(payload.signed).to.have.members([true, false, false]);
        expect(payload.weight.toBigInt()).to.be.eq(1n);
        expect(payload.minted).to.be.false;
      });

      it("mintFromPayload: rejects when not enough signatures", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintFromPayload(mintPayload.hashAsBytes())
            .accounts({
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipient: recipientTA,
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              payload: mintPayloadPDA,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("NotEnoughSignatures");
      });

      const rejected_signatures = [
        {
          name: "array lengths do not match",
          payload: mintPayload,
          signatures: () => [mintSigs[0]],
          indices: [],
          payloadPDA: mintPayloadPDA,
          error: "Mismatch between signatures and indices length"
        },
        {
          name: "unknown validator id",
          payload: mintPayload,
          signatures: () => [mintSigs[0]],
          indices: [new BN(4)],
          payloadPDA: mintPayloadPDA,
          error: "Transaction simulation failed: Error processing Instruction 0: Program failed to complete"
        }
      ];

      rejected_signatures.forEach(function (arg) {
        it(`postMintSignatures: rejects when ${arg.name}`, async () => {
          await expect(
              withBlockhashRetry(() =>
                program.methods
              .postMintSignatures(arg.payload.hashAsBytes(), arg.signatures(), arg.indices)
              .accounts({ config: configPDA, payload: arg.payloadPDA })
              .rpc({ commitment: "confirmed" })
              )
            ).to.be.rejectedWith(arg.error);
        });
      });

      const ignored_signatures = [
        {
          name: "arrays are empty",
          payload: mintPayload,
          signatures: () => [],
          indices: [],
          payloadPDA: mintPayloadPDA
        },
        {
          name: "signatures are invalid",
          payload: mintPayload,
          signatures: () => [mintSigs[0]],
          indices: [new BN(1)],
          payloadPDA: mintPayloadPDA
        },
        {
          name: "one of the signatures is invalid",
          payload: mintPayload,
          signatures: () => [mintSigs[0], mintSigs[1]],
          indices: [new BN(0), new BN(0)],
          payloadPDA: mintPayloadPDA
        },
        {
          name: "arrays contain duplicates",
          payload: mintPayload,
          signatures: () => [mintSigs[0], mintSigs[0]],
          indices: [new BN(0), new BN(0)],
          payloadPDA: mintPayloadPDA
        }
      ];

      ignored_signatures.forEach(function (arg) {
        it(`postMintSignatures: ignores when ${arg.name}`, async () => {
          await withBlockhashRetry(() =>
            program.methods
            .postMintSignatures(arg.payload.hashAsBytes(), arg.signatures(), arg.indices)
            .accounts({ config: configPDA, payload: arg.payloadPDA })
            .rpc({ commitment: "confirmed" })
          );

          const payload = await program.account.mintPayload.fetch(arg.payloadPDA);
          expect(payload.weight.toBigInt()).to.be.eq(1n);
        });
      });

      it("postMintSignatures: can add missing signatures to payload", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postMintSignatures(mintPayload.hashAsBytes(), mintSigs, [new BN(0), new BN(2)])
          .accounts({ config: configPDA, payload: mintPayloadPDA, payer: payer.publicKey })
          .rpc({ commitment: "confirmed" })
        );

        const payload = await program.account.mintPayload.fetch(mintPayloadPDA);
        expect(payload.payload.map(num => num.toString(16).padStart(2, "0")).join("")).to.be.eq(mintPayload.hex());
        expect(payload.signed).to.have.members([true, false, true]);
        expect(payload.weight.toBigInt()).to.be.eq(2n);
        expect(payload.minted).to.be.false;
      });

      it("mintFromPayload: rejects when recipient does not match address in payload", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintFromPayload(mintPayload.hashAsBytes())
            .accounts({
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipient: minterTA,
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              payload: mintPayloadPDA,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Mismatch between mint payload and passed account");
      });

      it("mintFromPayload: rejects when mint authority is wrong", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintFromPayload(mintPayload.hashAsBytes())
            .accounts({
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipient: mintPayload.recipientPubKey(),
              mint: mint,
              mintAuthority: payer.publicKey,
              tokenAuthority: tokenAuth,
              payload: mintPayloadPDA,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("owner does not match");
      });

      it("mintFromPayload: successful", async () => {
        const balanceBefore = await spl.getAccount(provider.connection, mintPayload.recipientPubKey());

        await withBlockhashRetry(() =>
          program.methods
          .mintFromPayload(mintPayload.hashAsBytes())
          .accounts({
            config: configPDA,
            tokenProgram: spl.TOKEN_PROGRAM_ID,
            recipient: mintPayload.recipientPubKey(),
            mint: mint,
            mintAuthority: tokenAuth,
            tokenAuthority: tokenAuth,
            payload: mintPayloadPDA,
            bascule: null,
            basculeData: null,
            deposit: null,
            systemProgram: null
          })
          .rpc({ commitment: "confirmed" })
        );

        const payload = await program.account.mintPayload.fetch(mintPayloadPDA);
        expect(payload.payload.map(num => num.toString(16).padStart(2, "0")).join("")).to.be.eq(mintPayload.hex());
        expect(payload.signed).to.have.members([true, false, true]);
        expect(payload.weight.toBigInt()).to.be.eq(2n);
        expect(payload.minted).to.be.true;

        const balanceAfter = await spl.getAccount(provider.connection, mintPayload.recipientPubKey());

        expect(balanceAfter.amount - balanceBefore.amount).to.be.eq(mintPayload.amountBigInt());

        //Event
        expect(events).to.be.not.empty;
        expect(events[0].recipient).to.be.deep.eq(mintPayload.recipientPubKey());
        expect(Buffer.from(events[0].payloadHash)).to.be.deep.eq(mintPayload.hashAsBytes());
      });

      it("mintFromPayload: rejects when already minted", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintFromPayload(mintPayload.hashAsBytes())
            .accounts({
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipient: mintPayload.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              payload: mintPayloadPDA,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Mint payload already used");
      });

      it("postMintSignatures: after mint does not change the status", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postMintSignatures(mintPayload.hashAsBytes(), mintSigs, [new BN(0), new BN(2)])
          .accounts({ config: configPDA, payload: mintPayloadPDA, payer: payer.publicKey })
          .rpc({ commitment: "confirmed" })
        );

        const payload = await program.account.mintPayload.fetch(mintPayloadPDA);
        expect(payload.payload.map(num => num.toString(16).padStart(2, "0")).join("")).to.be.eq(mintPayload.hex());
        expect(payload.signed).to.have.members([true, false, true]);
        expect(payload.weight.toBigInt()).to.be.eq(2n);
        expect(payload.minted).to.be.true;
      });
    });

    //Only claimer role can mint with fee
    describe("Mint with fee by claimer", async () => {
      before(async () => {
        await withBlockhashRetry(() =>
          program.methods
          .createMintPayload(mintPayload2.hashAsBytes(), mintPayload2.bytes())
          .accounts({
            payer: payer.publicKey,
            config: configPDA,
            payload: mintPayloadPDA2
          })
          .signers([payer])
          .rpc({ commitment: "confirmed" })
        );

        await withBlockhashRetry(() =>
          program.methods
          .postMintSignatures(mintPayload2.hashAsBytes(), [mintSigs2[0]], [new BN(0)])
          .accounts({ config: configPDA, payload: mintPayloadPDA2 })
          .rpc({ commitment: "confirmed" })
        );
      });

      it("mintWithFee: rejects when not enough signatures", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Not enough valid signatures");
      });

      it("mintWithFee: rejects when called by not a claimer", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .postMintSignatures(mintPayload2.hashAsBytes(), mintSigs2, [new BN(0), new BN(2)])
          .accounts({ config: configPDA, payload: mintPayloadPDA2 })
          .rpc({ commitment: "confirmed" })
        );

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: payer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([payer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Unauthorized function call");
      });

      it("mintWithFee: rejects when treasury is invalid", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: payer.publicKey,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("The given account is owned by a different program than expected");
      });

      it("mintWithFee: rejects when recipient does not match address in payload", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: user.publicKey,
              recipient: userTA,
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Mismatch between mint payload and passed account");
      });

      it("mintWithFee: rejects when mint authority is wrong", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: recipient.publicKey,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("owner does not match");
      });

      it("mintWithFee: rejects when amount < fee", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .setMintFee(new BN(100_000))
          .accounts({ payer: operator.publicKey, config: configPDA })
          .signers([operator])
          .rpc({ commitment: "confirmed" })
        );

        const feePermit = new FeePermit(program.programId.toBuffer().toString("hex"), 3);
        feePermit.maxFees = "0000000000000000000000000000000000000000000000000000000000989680";

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Fee is greater than or equal to amount");
      });

      const invalid_permits = [
        {
          name: "permit prefix is invalid",
          modifier: (permit: FeePermit): [Buffer, Buffer] => {
            permit.prefix = "04acbbb3";
            return [permit.bytes(), permit.signature(recipient.secretKey)];
          },
          error: "Invalid action bytes"
        },
        {
          name: "permit chainId is invalid",
          modifier: (permit: FeePermit): [Buffer, Buffer] => {
            permit.chainId = "0259db5080fc2c6d3bcf7ca90712d3c2e5e6c28f27f0dfbb9953bdb0894c03ac";
            return [permit.bytes(), permit.signature(recipient.secretKey)];
          },
          error: "Invalid chain ID"
        },
        {
          name: "permit programId is invalid",
          modifier: (permit: FeePermit): [Buffer, Buffer] => {
            permit.programId = "42ed4c495cbedc8a5d4b213fe18ba748ebe91264b9a64bea611054af21ad0a8e";
            return [permit.bytes(), permit.signature(recipient.secretKey)];
          },
          error: "Invalid verifying contract"
        },
        {
          name: "permit is expired",
          modifier: (permit: FeePermit): [Buffer, Buffer] => {
            permit.expire = "000000000000000000000000000000000000000000000000000000000000000f";
            return [permit.bytes(), permit.signature(recipient.secretKey)];
          },
          error: "Fee approval expired"
        },
        {
          name: "permit signature is invalid",
          modifier: (permit: FeePermit): [Buffer, Buffer] => {
            return [permit.bytes(), feePermit.signature(user.secretKey)];
          },
          error: "Fee signature invalid"
        },
        {
          name: "permit length is invalid",
          modifier: (permit: FeePermit): [Buffer, Buffer] => {
            permit.expire += "000000000000000000000000000000000000000000000000000000000000000f";
            return [permit.bytes(), permit.signature(recipient.secretKey)];
          },
          error: "Fee signature invalid"
        }
      ];

      invalid_permits.forEach(function (arg) {
        it(`mintWithFee: rejects when ${arg.name}`, async () => {
          const feePermit = new FeePermit(program.programId.toBuffer().toString("hex"), 3);
          const [permit, signature] = arg.modifier(feePermit);

          await expect(
              withBlockhashRetry(() =>
                program.methods
              .mintWithFee(mintPayload2.hashAsBytes(), permit, signature)
              .accounts({
                payer: claimer.publicKey,
                config: configPDA,
                tokenProgram: spl.TOKEN_PROGRAM_ID,
                recipientAuth: recipient.publicKey,
                recipient: mintPayload2.recipientPubKey(),
                mint: mint,
                mintAuthority: tokenAuth,
                tokenAuthority: tokenAuth,
                treasury: treasury,
                payload: mintPayloadPDA2,
                bascule: null,
                basculeData: null,
                deposit: null,
                systemProgram: null
              })
              .signers([claimer])
              .rpc({ commitment: "confirmed" })
              )
            ).to.be.rejectedWith(arg.error);
        });
      });

      it("mintWithFee: successful", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .setMintFee(new BN(10))
          .accounts({ payer: operator.publicKey, config: configPDA })
          .signers([operator])
          .rpc({ commitment: "confirmed" })
        );

        const recipientBalanceBefore = await spl.getAccount(provider.connection, mintPayload2.recipientPubKey());
        const treasuryBalanceBefore = await spl.getAccount(provider.connection, treasury);

        await withBlockhashRetry(() =>
          program.methods
          .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
          .accounts({
            payer: claimer.publicKey,
            config: configPDA,
            tokenProgram: spl.TOKEN_PROGRAM_ID,
            recipientAuth: recipient.publicKey,
            recipient: mintPayload2.recipientPubKey(),
            mint: mint,
            mintAuthority: tokenAuth,
            tokenAuthority: tokenAuth,
            treasury: treasury,
            payload: mintPayloadPDA2,
            bascule: null,
            basculeData: null,
            deposit: null,
            systemProgram: null
          })
          .signers([claimer])
          .rpc({ commitment: "confirmed" })
        );

        const recipientBalanceAfter = await spl.getAccount(provider.connection, mintPayload2.recipientPubKey());
        const treasuryBalanceAfter = await spl.getAccount(provider.connection, treasury);

        // Asserting balance after the mint
        let cfg = await program.account.config.fetch(configPDA);
        // Going to take the least fee value from permit and config
        const finalFees =
          cfg.mintFee.toBigInt() < feePermit.maxFeesBigInt() ? cfg.mintFee.toBigInt() : feePermit.maxFeesBigInt();
        expect(recipientBalanceAfter.amount - recipientBalanceBefore.amount).to.be.eq(
          mintPayload2.amountBigInt() - finalFees
        );
        // Treasury received fees
        expect(treasuryBalanceAfter.amount - treasuryBalanceBefore.amount).to.be.eq(finalFees);

        //Event
        expect(events).to.be.not.empty;
        expect(events[0].recipient).to.be.deep.eq(mintPayload2.recipientPubKey());
        expect(Buffer.from(events[0].payloadHash)).to.be.deep.eq(mintPayload2.hashAsBytes());
      });

      it("mintWithFee: rejects when already minted", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Mint payload already used");
      });
    });

    //Mint and redeem do not work when pause is enabled
    describe("Pause", () => {
      before(async () => {
        const tx2 = await withBlockhashRetry(() =>
          program.methods
          .pause()
          .accounts({ payer: pauser.publicKey, config: configPDA })
          .signers([pauser])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.paused == true);
      });

      after(async () => {
        await withBlockhashRetry(() =>
          program.methods
          .unpause()
          .accounts({ payer: pauser.publicKey, config: configPDA })
          .signers([pauser])
          .rpc({ commitment: "confirmed" })
        );

        const cfg = await program.account.config.fetch(configPDA);
        expect(cfg.paused == false);
      });

      it("postMintSignatures: rejects when paused", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .postMintSignatures(mintPayload2.hashAsBytes(), [mintSigs[0]], [new BN(0)])
            .accounts({ config: configPDA, payload: mintPayloadPDA2 })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("LBTC contract is paused");
      });

      it("mintFromPayload: rejects when paused", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintFromPayload(mintPayload2.hashAsBytes())
            .accounts({
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("LBTC contract is paused");
      });

      it("mintWithFee: rejects when paused", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .mintWithFee(mintPayload2.hashAsBytes(), feePermit.bytes(), feePermit.signature(recipient.secretKey))
            .accounts({
              payer: claimer.publicKey,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              recipientAuth: recipient.publicKey,
              recipient: mintPayload2.recipientPubKey(),
              mint: mint,
              mintAuthority: tokenAuth,
              tokenAuthority: tokenAuth,
              treasury: treasury,
              payload: mintPayloadPDA2,
              bascule: null,
              basculeData: null,
              deposit: null,
              systemProgram: null
            })
            .signers([claimer])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("LBTC contract is paused");
      });

      it("redeem: rejects when paused", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from(scriptPubkey), new BN(1000))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: treasury
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("LBTC contract is paused");
      });
    });

    describe("Redeem", function () {
      it("redeem: rejects when withdrawals are disabled", async () => {
        await withBlockhashRetry(() =>
          program.methods
          .disableWithdrawals()
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );

        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from(scriptPubkey), new BN(1000))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: treasury
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Withdrawals are disabled");

        await withBlockhashRetry(() =>
          program.methods
          .enableWithdrawals()
          .accounts({ payer: admin.publicKey, config: configPDA })
          .signers([admin])
          .rpc({ commitment: "confirmed" })
        );
      });

      it("redeem: rejects when insufficient funds", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from(scriptPubkey), new BN(2000))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: treasury
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("insufficient funds");
      });

      it("redeem: rejects when amount < burn fee", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from(scriptPubkey), new BN(10))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: treasury
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Fee is greater than or equal to amount");
      });

      it("redeem: rejects when amount < dust limit", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from(scriptPubkey), new BN(304))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: treasury
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Redeemed amount is below the BTC dust limit");
      });

      it("redeem: rejects when script pubkey is invalid", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from([0, 1, 2]), new BN(1000))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: treasury
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("Script pubkey is unsupported");
      });

      it("redeem: rejects when treasury is invalid", async () => {
        await expect(
            withBlockhashRetry(() =>
              program.methods
            .redeem(Buffer.from(scriptPubkey), new BN(1000))
            .accounts({
              payer: user.publicKey,
              holder: userTA,
              config: configPDA,
              tokenProgram: spl.TOKEN_PROGRAM_ID,
              mint: mint,
              treasury: userTA
            })
            .signers([user])
            .rpc({ commitment: "confirmed" })
            )
          ).to.be.rejectedWith("An address constraint was violated");
      });

      it("redeem: successful", async () => {
        const amount = new BN(1000);
        const userBalanceBefore = await spl.getAccount(provider.connection, recipientTA);
        const treasuryBalanceBefore = await spl.getAccount(provider.connection, treasury);
        await withBlockhashRetry(() =>
          program.methods
          .redeem(Buffer.from(scriptPubkey), amount)
          .accounts({
            payer: recipient.publicKey,
            holder: recipientTA,
            config: configPDA,
            tokenProgram: spl.TOKEN_PROGRAM_ID,
            mint: mint,
            treasury: treasury
          })
          .signers([recipient])
          .rpc({ commitment: "confirmed" })
        );

        const userBalanceAfter = await spl.getAccount(provider.connection, recipientTA);
        const treasuryBalanceAfter = await spl.getAccount(provider.connection, treasury);
        const cfg = await program.account.config.fetch(configPDA);

        expect(userBalanceBefore.amount - userBalanceAfter.amount).to.be.eq(amount.toBigInt());
        expect(treasuryBalanceAfter.amount - treasuryBalanceBefore.amount).to.be.eq(cfg.burnCommission.toBigInt());
        expect(cfg.unstakeCounter.toBigInt()).to.be.eq(1n);

        const unstakeInfoPDA = PublicKey.findProgramAddressSync(
          [new BN(cfg.unstakeCounter - 1).toArrayLike(Buffer, "le", 8)],
          program.programId
        )[0];
        const unstakeInfo = await program.account.unstakeInfo.fetch(unstakeInfoPDA);
        expect(unstakeInfo.from == recipient.publicKey);
        expect(unstakeInfo.scriptPubkey == scriptPubkey);
        expect(unstakeInfo.amount == amount - cfg.burnCommission);
      });
    });
  });
});
