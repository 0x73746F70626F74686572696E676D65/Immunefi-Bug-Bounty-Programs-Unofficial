import * as anchor from "@coral-xyz/anchor";
import { PublicKey } from "@solana/web3.js";
import { getBase58EncodedTxBytes } from "../utils";
import { RatioOracle } from "../../target/types/ratio_oracle";
import { RATIO_ORACLE_CONFIG_SEED } from "./constants";

// Provide instructions.
if (process.argv.indexOf("--help") > -1) {
  console.log(`Usage: PROGRAM_ID=<asset_router_program_id> ANCHOR_PROVIDER_URL=<rpc_url> ANCHOR_WALLET=<wallet_path> yarn gmp_ratioOracleTransferOwnership <new_admin> [--populate]

    Updates the native mint authority through asset_router::change_mint_auth.
    WARNING: This can break minting functionality if misconfigured.`);
  process.exit(0);
}

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);

// Check for program ID match.
if (!process.env.PROGRAM_ID) {
  console.error("no program Id set");
  process.exit(1);
}
const programId = new PublicKey(process.env.PROGRAM_ID);
const program = new anchor.Program(require("../../target/idl/ratio_oracle.json"), provider) as anchor.Program<RatioOracle>;

if (!program.programId.equals(programId)) {
  console.error("the program id in the idl does not match the program id passed as env variable");
  process.exit(1);
}

// If we have a populate flag at the end of the call, we return the bytes.
let populate = process.argv.at(-1) === "--populate";

const newAdmin = new PublicKey(process.argv[2]);

(async () => {
  try {
    const payer = provider.wallet.publicKey;
    const configPDA = PublicKey.findProgramAddressSync([RATIO_ORACLE_CONFIG_SEED], programId)[0];

    console.log("Using config PDA:", configPDA.toBase58());

    const tx = await program.methods.transferOwnership(newAdmin).accounts({
      payer,
      config: configPDA
    });

    if (populate) {
      console.log("Transaction bytes:", await getBase58EncodedTxBytes(await tx.instruction(), provider.connection));
    } else {
      console.log("Transaction Signature:", await tx.rpc());
    }
  } catch (err) {
    console.error("Error changing asset router mint authority:", err);
    process.exit(1);
  }
})();
