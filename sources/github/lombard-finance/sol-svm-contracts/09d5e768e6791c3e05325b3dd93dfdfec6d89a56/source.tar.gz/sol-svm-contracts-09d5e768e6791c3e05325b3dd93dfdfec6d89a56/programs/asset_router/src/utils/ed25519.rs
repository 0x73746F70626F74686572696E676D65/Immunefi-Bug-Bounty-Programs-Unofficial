use crate::errors::AssetRouterError;
use anchor_lang::prelude::*;
use anchor_lang::solana_program::sysvar::instructions::{
    load_current_index_checked, load_instruction_at_checked,
};

pub fn verify_ed25519_instruction(
    instruction_sysvar: &AccountInfo,
    expected_public_key: &[u8],
    message: &[u8],
    signature: &[u8],
) -> Result<()> {
    let current_index = load_current_index_checked(instruction_sysvar)?;
    if current_index == 0 {
        return Err(AssetRouterError::MissingEd25519Instruction.into());
    }

    let ed25519_instruction =
        load_instruction_at_checked((current_index - 1) as usize, instruction_sysvar)?;

    // Check instruction program ID
    if ed25519_instruction.program_id != anchor_lang::solana_program::ed25519_program::ID {
        return Err(AssetRouterError::InvalidEd25519Instruction.into());
    }

    // Verify the content of the Ed25519 instruction
    let instruction_data = ed25519_instruction.data;
    if instruction_data.len() < 2 {
        return Err(AssetRouterError::InvalidEd25519Instruction.into());
    }

    let num_signatures = instruction_data[0];
    if num_signatures != 1 {
        return Err(AssetRouterError::InvalidEd25519Instruction.into());
    }

    // Parse Ed25519SignatureOffsets
    let offsets: Ed25519SignatureOffsets =
        Ed25519SignatureOffsets::try_from_slice(&instruction_data[2..16])?;

    // Verify public key
    if offsets.public_key_instruction_index != u16::MAX {
        return Err(AssetRouterError::InvalidEd25519Instruction.into());
    }
    let pubkey_start = offsets.public_key_offset as usize;
    let pubkey_end = pubkey_start + 32;
    if &instruction_data[pubkey_start..pubkey_end] != expected_public_key {
        return Err(AssetRouterError::InvalidPublicKey.into());
    }

    // Verify message
    if offsets.message_instruction_index != u16::MAX {
        return Err(AssetRouterError::InvalidEd25519Instruction.into());
    }
    let msg_start = offsets.message_data_offset as usize;
    let msg_end = msg_start + offsets.message_data_size as usize;
    if &instruction_data[msg_start..msg_end] != message {
        return Err(AssetRouterError::InvalidMessage.into());
    }

    // Verify signature
    if offsets.signature_instruction_index != u16::MAX {
        return Err(AssetRouterError::InvalidEd25519Instruction.into());
    }
    let sig_start = offsets.signature_offset as usize;
    let sig_end = sig_start + 64;
    if &instruction_data[sig_start..sig_end] != signature {
        return Err(AssetRouterError::InvalidSignature.into());
    }

    Ok(())
}

#[derive(AnchorSerialize, AnchorDeserialize)]
struct Ed25519SignatureOffsets {
    signature_offset: u16,
    signature_instruction_index: u16,
    public_key_offset: u16,
    public_key_instruction_index: u16,
    message_data_offset: u16,
    message_data_size: u16,
    message_instruction_index: u16,
}
