# Audits

This folder consists of the audit reports performed on the Starkware Utils library.

| Audit Purpose | Commit | Report | Firm | Date |
|---------------|--------|--------|------|------------|
|    Release    |[9630630a11d055e621d5b18e7351b034311fc518](https://github.com/starkware-libs/sn-lbtc/tree/9630630a11d055e621d5b18e7351b034311fc518)|[StarkWare_LBTC_Zenith_Audit_Report](https://github.com/starkware-libs/sn-lbtc/raw/refs/heads/dev/docs/audit/StarkWare_LBTC_Zenith_Audit_Report.pdf)|[Zenith](https://www.zenith.security/)|15.05.2025|
|    Release    |[0eaa3bcf17c60033bf6eb759ffd47a4be2656032](https://github.com/starkware-libs/sn-lbtc/tree/0eaa3bcf17c60033bf6eb759ffd47a4be2656032)|[StarkWare_LBTC_Sherlock_Audit_Report.pdf](https://github.com/starkware-libs/sn-lbtc/raw/refs/heads/dev/docs/audit/StarkWare_LBTC_Sherlock_Audit_Report.pdf)|[Sherlock](https://sherlock.xyz/)|16.06.2025|
