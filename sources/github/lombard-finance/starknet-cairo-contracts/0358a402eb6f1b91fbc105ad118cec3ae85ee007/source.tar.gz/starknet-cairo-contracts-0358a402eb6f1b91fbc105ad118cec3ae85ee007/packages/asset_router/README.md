# Bridge

## Overview

This package contains the `bridge` contract.
It is one of the permitted contracts to mint and burn `LBTC` tokens.