# Bascule drawbridge

This repo is a Bascule drawbridge designed to prevent bridge hacks before they
hit the chain. It has an off-chain component and an on-chain component. The
off-chain component watches chains to which a system bridges. Whenever it sees a
deposit on one chain, it notifies the on-chain contract that the deposit has
happened.  Then, when a user tries to withdraw funds from a bridge contract,
that bridge contract can first check with the bascule contract. If the contract
validates the withdrawal, it's safe: a deposit corresponding to the withdrawal
already happened on the other chain. If not, the withdrawal is either early or
malicious. The next sections outline considerations for both the off-chain and
on-chain code.

## Off-chain code

The off-chain code invokes the `report_deposits` function
with a report-id `report_id: u256` (useful for tracking which reports
succeeded, but not security critical) , with a list `deposit_ids: Span<u256>`.  In
order for the bascule to be secure, two things must be true of this invocation:

1. The off-chain code must only invoke *one* instance of the bascule contract.
If the bascule is deployed on multiple chains and there's a bug in the bridge,
violating this invariant could allow an attacker to mint on many chains for the
same deposit.

1. Each `deposit_id` must be a unique identifier that includes (e.g., by hashing)
all relevant fields of the on-chain deposit.  For example, if the hash does not
include the amount of the deposit, a bridge bug could allow an attacker to
deposit a small amount on one chain and redeem a much larger amount on a
different chain.

To keep the off-chain simple, the `deposit_id` should, in general, be a hash of
source-chain data (i.e., the deposit transaction details) and the
destination-chain data (e.g., the destination chain-id, bridge contract address,
withdrawal address). In other words the depositID should be unique to a deposit
and globally meaningful, across chains. This makes it extremely easy to enforce
the first invariant.

## On-chain code

The on-chain code includes functionality for reporting deposits and validating
withdrawals. In order for the bascule to be secure and usable, the following
conditions must be met:

1. The bridge contract must hold a reference to the bascule, and any admin keys
the allow an upgrade must be kept extremely safe.

2. The bridge contract should do all internal vetting BEFORE calling
`validate_withdrawal`. Deposits that are withdrawn cannot be withdrawn again.

3. The withdrawal amount to `validate_withdrawal` MUST be correct if the
validation threshold is not `0` (i.e., if the bascule is configured to only
validate withdrawals greater than or equal to a threshold amount).

> NOTE: A validation guardian can raise the validation threshold from `0` (i.e., validate all withdrawals) with `update_validation_threshold`; the contract allows all withdrawals below the configured threshold. This makes additional assumptions about the `validate_withdrawal` callee, namely, that the supplied amount MUST be correct (otherwise, e.g., the callee could report 0 for all amounts and bypass validation entirely). Thus, the threshold should be adjusted only with extreme caution.
