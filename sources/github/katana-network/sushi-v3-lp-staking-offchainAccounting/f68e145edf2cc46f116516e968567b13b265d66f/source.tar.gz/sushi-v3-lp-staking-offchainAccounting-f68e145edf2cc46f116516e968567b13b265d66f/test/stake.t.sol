// SPDX-License-Identifier: MIT
pragma solidity 0.8.33;

import { SushiStaker } from "../src/SushiStaker.sol";
import { MockERC20 } from "./utils/MockERC20.sol";
import { SushiStakerTestBase } from "./utils/SushiStakerTestBase.sol";

/**
 * @title StakeTest
 * @notice Tests for the stake() function
 */
contract StakeTest is SushiStakerTestBase {
    /**
     * @notice Test successful staking via stake()
     */
    function test_stakeSuccess() public {
        uint256 tokenId = _mintNft(alice);

        vm.startPrank(alice);
        mockNft.approve(address(staker), tokenId);
        staker.stake(tokenId);
        vm.stopPrank();

        // Verify staking state
        assertEq(staker.isStaked(tokenId), true);
        assertEq(staker.getStaker(tokenId), alice);
        assertEq(staker.getStakeTimestamp(tokenId), block.timestamp);
        assertEq(mockNft.ownerOf(tokenId), address(staker));
    }

    /**
     * @notice Test TokenStaked event is emitted with correct data
     */
    function test_stakeEmitsEvent() public {
        uint256 tokenId = _mintNft(alice);

        vm.startPrank(alice);
        mockNft.approve(address(staker), tokenId);

        vm.expectEmit(true, true, false, true);
        emit SushiStaker.TokenStaked(
            alice,
            tokenId,
            address(mockPool),
            TICK_LOWER,
            TICK_UPPER,
            LIQUIDITY,
            1_000_000, // mockSecondsPerLiquidity
            block.timestamp
        );

        staker.stake(tokenId);
        vm.stopPrank();
    }

    /**
     * @notice Test pre-stake fees are collected and sent to staker
     */
    function test_stakeCollectsPreStakeFees() public {
        uint256 tokenId = _mintNft(alice);

        // Add pending fees before staking
        uint256 preFee0 = 100 ether;
        uint256 preFee1 = 50 ether;
        mockNft.addPendingFees(tokenId, preFee0, preFee1);

        uint256 aliceBalance0Before = MockERC20(token0).balanceOf(alice);
        uint256 aliceBalance1Before = MockERC20(token1).balanceOf(alice);

        vm.startPrank(alice);
        mockNft.approve(address(staker), tokenId);
        staker.stake(tokenId);
        vm.stopPrank();

        // Verify alice received the pre-stake fees
        assertEq(MockERC20(token0).balanceOf(alice), aliceBalance0Before + preFee0);
        assertEq(MockERC20(token1).balanceOf(alice), aliceBalance1Before + preFee1);
    }

    /**
     * @notice Test revert when caller doesn't own the NFT
     */
    function test_revertWhen_stakeNotTokenOwner() public {
        uint256 tokenId = _mintNft(alice);

        // Bob tries to stake Alice's token
        vm.prank(bob);
        vm.expectRevert(SushiStaker.SushiStakerNotTokenOwner.selector);
        staker.stake(tokenId);
    }

    /**
     * @notice Test revert when position has zero liquidity
     */
    function test_revertWhen_stakeZeroLiquidity() public {
        uint256 tokenId = _mintNft(alice, 0);

        vm.startPrank(alice);
        mockNft.approve(address(staker), tokenId);

        vm.expectRevert(SushiStaker.SushiStakerZeroLiquidity.selector);
        staker.stake(tokenId);
        vm.stopPrank();
    }

    /**
     * @notice Test FeesCollected event is emitted with correct data on stake
     */
    function test_stakeEmitsFeesCollectedEvent() public {
        uint256 tokenId = _mintNft(alice);

        mockNft.addPendingFees(tokenId, 100 ether, 50 ether);

        vm.startPrank(alice);
        mockNft.approve(address(staker), tokenId);

        // Expect FeesCollected event on stake (epochId = 1 from mock)
        vm.expectEmit();
        emit SushiStaker.FeesCollected(tokenId, alice, 1, address(mockPool), token0, token1, 100 ether, 50 ether);

        staker.stake(tokenId);
        vm.stopPrank();
    }

    /**
     * @notice Test unstaking after staking via stake()
     */
    function test_unstakeAfterStake() public {
        uint256 tokenId = _mintNft(alice);

        // Stake
        vm.startPrank(alice);
        mockNft.approve(address(staker), tokenId);
        staker.stake(tokenId);

        // Unstake
        staker.unstake(tokenId);
        vm.stopPrank();

        // Verify state
        assertEq(staker.isStaked(tokenId), false);
        assertEq(staker.getStaker(tokenId), address(0));
        assertEq(mockNft.ownerOf(tokenId), alice);
    }
}
