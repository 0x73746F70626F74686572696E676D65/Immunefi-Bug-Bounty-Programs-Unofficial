#!/usr/bin/env bash

log() {
  local level="$1"
  shift
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  printf '%s [%s] %s\n' "$ts" "$level" "$*"
}

info()  { log INFO  "$@"; }
warn()  { log WARN  "$@"; }
error() { log ERROR "$@" >&2; }

die() {
  error "$@"
  exit 1
}

__PHASE_START=0
phase_start() {
  __PHASE_START=$SECONDS
  info "==> $1"
}
phase_end() {
  local name="$1"
  local elapsed=$(( SECONDS - __PHASE_START ))
  info "<== $name done in $(format_duration "$elapsed")"
}

format_duration() {
  local total="$1"
  printf '%dm%02ds' $(( total / 60 )) $(( total % 60 ))
}

human_bytes() {
  local bytes="$1"
  local units=(B KiB MiB GiB TiB PiB)
  local i=0
  local val="$bytes"
  while (( val >= 1024 && i < ${#units[@]} - 1 )); do
    val=$(( val / 1024 ))
    (( ++i ))
  done
  printf '%d %s' "$val" "${units[$i]}"
}

require_cmd() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1 || die "required command not found: $cmd"
}

acquire_lock() {
  local lockfile="$1"
  exec 200>"$lockfile" || die "cannot open lock file: $lockfile"
  if ! flock -n 200; then
    die "another snapshot run holds the lock ($lockfile); aborting"
  fi
  echo "$$" >&200
}

load_config() {
  local candidates=(
    "${CONFIG_FILE:-}"
    "/etc/node-snapshotter/config.env"
    "${REPO_ROOT}/config.env"
  )
  local f
  for f in "${candidates[@]}"; do
    [ -n "$f" ] || continue
    if [ -f "$f" ]; then
      info "loading config from $f"
      # shellcheck disable=SC1090
      set -a; source "$f"; set +a
      LOADED_CONFIG_FILE="$f"
      return 0
    fi
  done
  warn "no config.env found; relying on environment variables and defaults"
  return 0
}

expand_tilde() {
  local p="$1"
  case "$p" in
    "~") printf '%s' "$HOME" ;;
    "~/"*) printf '%s/%s' "$HOME" "${p#\~/}" ;;
    *) printf '%s' "$p" ;;
  esac
}
