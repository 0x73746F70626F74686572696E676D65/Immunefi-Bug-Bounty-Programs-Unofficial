# Google Cloud Storage setup

Minimal setup: **your node uploads snapshots**, **anyone can download** them via a public URL.

## Why a service account?

Google needs to know *who* is writing to the bucket. A **service account** is a robot identity for your server — you download one JSON key, put it on the node, and the snapshot script uses it. There is no simpler way to do unattended uploads.

Public downloads do **not** need credentials — we make the bucket world-readable.

## 1. Create a project

1. [Cloud Console](https://console.cloud.google.com/) → project picker → **New project**.
2. [Enable Cloud Storage API](https://console.cloud.google.com/apis/library/storage.googleapis.com) → **Enable**.

## 2. Create a bucket

1. [Cloud Storage → Buckets](https://console.cloud.google.com/storage/browser) → **Create**.
2. Settings:

   | Field | Value |
   | --- | --- |
   | **Name** | e.g. `katana-opreth-snapshots` → your `GCS_BUCKET` |
   | **Location** | **Region** closest to your node, e.g. `us-central1` |
   | **Storage class** | **Standard** |
   | **Public access prevention** | **Off** (required for public downloads) |
   | **Uniform bucket-level access** | **On** |

3. **Create**.

Note the **region** — it must match `location` in `rclone.conf`.

## 3. Allow public downloads

1. Open your bucket → **Permissions** → **Grant access**.
2. **New principals**: `allUsers`
3. **Role**: **Storage Object Viewer**
4. Confirm the warning → **Save**.

Anyone can now read objects. Only authenticated identities (your service account) can write.

### Public download URLs

Replace `YOUR_BUCKET`:

| File | URL |
| --- | --- |
| Snapshot | `https://storage.googleapis.com/YOUR_BUCKET/katana-opreth/latest/rethdata.tar` |
| Manifest | `https://storage.googleapis.com/YOUR_BUCKET/katana-opreth/latest/manifest.json` |

Test after first upload:

```bash
curl -I https://storage.googleapis.com/YOUR_BUCKET/katana-opreth/latest/manifest.json
# expect HTTP 200 (or 404 before first snapshot)
```

## 4. Create an uploader identity (service account)

One service account, one role, one key.

1. [Service accounts](https://console.cloud.google.com/iam-admin/serviceaccounts) → **Create service account**.
2. **Name**: `node-snapshotter` → **Create and continue** → **Done** (skip project-level roles).
3. Open your bucket → **Permissions** → **Grant access**.
4. **New principals**: `node-snapshotter@YOUR_PROJECT_ID.iam.gserviceaccount.com`
5. **Role**: **Storage Object Admin** (upload, overwrite, list, delete — needed by the snapshot script)
6. **Save**.
7. Back to [Service accounts](https://console.cloud.google.com/iam-admin/serviceaccounts) → `node-snapshotter` → **Keys** → **Add key** → **JSON** → **Create**.

Keep the downloaded JSON file secret — it is the upload password.

## 5. Install on the node

Assumes the repo is cloned at `~/node-snapshotter` (see [README.md](README.md)).

```bash
cd ~/node-snapshotter
cp /path/to/YOUR_KEY.json gcs-service-account.json
chmod 600 gcs-service-account.json

cp config.env.example config.env
cp rclone.conf.example rclone.conf
# edit config.env: set GCS_BUCKET
# edit rclone.conf: set location to your bucket region (e.g. us-central1)
# bucket_policy_only = true is required when uniform bucket-level access is on
```

`config.env` paths (already set in `config.env.example`):

```bash
GCS_BUCKET="YOUR_BUCKET"
GCS_SERVICE_ACCOUNT_FILE="~/node-snapshotter/gcs-service-account.json"
RCLONE_CONFIG="~/node-snapshotter/rclone.conf"
```

## 6. Verify

```bash
cd ~/node-snapshotter
export GOOGLE_APPLICATION_CREDENTIALS="$HOME/node-snapshotter/gcs-service-account.json"
rclone --config "$HOME/node-snapshotter/rclone.conf" lsf gcs:YOUR_BUCKET/
bin/snapshot.sh dry-run
```

After a successful `run`, confirm public access:

```bash
curl -I https://storage.googleapis.com/YOUR_BUCKET/katana-opreth/latest/manifest.json
```

## Summary

| Who | How | Can do |
| --- | --- | --- |
| Your node | Service account JSON key | Upload, overwrite, purge snapshots |
| Everyone | Public bucket (`allUsers` → Object Viewer) | Download via HTTPS URL |

Two bucket permissions total — that's the minimum for upload + public download.

## Security notes

- Never commit the JSON key to git.
- `allUsers` makes every object in the bucket downloadable. Use a **dedicated bucket** for snapshots only.
- If the key leaks, delete it in the console and create a new one.
