import 'hardhat/types/config'

interface OftAdapterConfig {
    tokenAddress: string
}

interface ChainDescriptor {
    name: string
    blockExplorers: {
        etherscan: {
            name: string
            url: string
            apiUrl: string
        }
    }
}

declare module 'hardhat/types/config' {
    interface HardhatNetworkUserConfig {
        oftAdapter?: never
    }

    interface HardhatNetworkConfig {
        oftAdapter?: never
    }

    interface HttpNetworkUserConfig {
        oftAdapter?: OftAdapterConfig
    }

    interface HttpNetworkConfig {
        oftAdapter?: OftAdapterConfig
    }

    interface HardhatUserConfig {
        chainDescriptors?: Record<number, ChainDescriptor>
        etherscan?: {
            apiKey: string | Record<string, string>
            customChains?: Array<{
                network: string
                chainId: number
                urls: {
                    apiURL: string
                    browserURL: string
                }
            }>
        }
    }
}
