import { DeployFunction } from 'hardhat-deploy/types'

import { deployImplementation } from '@layerzerolabs/devtools-evm-hardhat'
import { EndpointId, endpointIdToNetwork } from '@layerzerolabs/lz-definitions'
import { getDeploymentAddressAndAbi } from '@layerzerolabs/lz-evm-sdk-v2'

/// @dev Upgrade from KATCustomOFTUpgradeable to KATOFTUpgradeable
const oldContractName = 'KATCustomOFTUpgradeable'
const newContractName = 'KATOFTUpgradeable'

const deploy: DeployFunction = async (hre) => {
    const { getNamedAccounts, deployments, ethers } = hre
    const { deployer } = await getNamedAccounts()

    console.log(`Upgrading ${oldContractName} to ${newContractName} on network: ${hre.network.name}`)

    // Get the existing proxy address
    const oldDeployment = await deployments.get(oldContractName)
    if (!oldDeployment) {
        throw new Error(`${oldContractName} deployment not found`)
    }
    const proxyAddress = oldDeployment.address
    console.log(`Found existing proxy at: ${proxyAddress}`)

    // Get the ProxyAdmin address
    // Try different possible deployment names
    let proxyAdminDeployment
    try {
        proxyAdminDeployment = await deployments.get(`${oldContractName}_ProxyAdmin`)
    } catch {
        try {
            proxyAdminDeployment = await deployments.get(`ProxyAdmin_${oldContractName}`)
        } catch {
            throw new Error(
                `ProxyAdmin for ${oldContractName} not found. Tried: ${oldContractName}_ProxyAdmin and ProxyAdmin_${oldContractName}`
            )
        }
    }
    const proxyAdminAddress = proxyAdminDeployment.address
    console.log(`Found ProxyAdmin at: ${proxyAdminAddress}`)

    // Get constructor arguments
    const eid = hre.network.config.eid as EndpointId
    const lzNetworkName = endpointIdToNetwork(eid)
    const { address: endpointAddress } = getDeploymentAddressAndAbi(lzNetworkName, 'EndpointV2')

    // Deploy the new implementation
    const { address: newImplementationAddress } = await deployImplementation({
        hre,
        deployOptions: {
            from: deployer,
            args: [endpointAddress],
            skipIfAlreadyDeployed: false,
            contract: newContractName,
        },
        deploymentName: `${newContractName}_Implementation`,
    })
    console.log(`Deployed new implementation at: ${newImplementationAddress}`)

    // Upgrade the proxy using ProxyAdmin
    // ProxyAdmin interface: upgrade(address proxy, address implementation)
    const proxyAdmin = await ethers.getContractAt('ProxyAdmin', proxyAdminAddress)

    const upgradeTx = await proxyAdmin.upgrade(proxyAddress, newImplementationAddress)
    await upgradeTx.wait()
    console.log(`Upgraded proxy ${proxyAddress} to new implementation ${newImplementationAddress}`)
    console.log(`Transaction hash: ${upgradeTx.hash}`)

    // Verify the upgrade
    const currentImplementation = await proxyAdmin.getProxyImplementation(proxyAddress)
    if (currentImplementation.toLowerCase() !== newImplementationAddress.toLowerCase()) {
        throw new Error('Upgrade verification failed: implementation address mismatch')
    }
    console.log('Upgrade verified successfully')
}

deploy.tags = ['upgradeCustomToStandardOFT']
deploy.dependencies = [oldContractName]

export default deploy
