import { DeployFunction } from 'hardhat-deploy/types'

import {
    deployImplementation,
    deployProxy,
    deployProxyAdmin,
    saveCombinedDeployment,
} from '@layerzerolabs/devtools-evm-hardhat'
import { EndpointId, endpointIdToNetwork } from '@layerzerolabs/lz-definitions'
import { getDeploymentAddressAndAbi } from '@layerzerolabs/lz-evm-sdk-v2'

/// @dev Deploy KATOFTUpgradeable on any EVM chain.
/// Deployer is the initial ProxyAdmin owner and OApp delegate.
/// Ownership should be transferred to the Safe multisig after wiring is verified.
const contractName = 'KATOFTUpgradeable'

const deploy: DeployFunction = async (hre) => {
    const { getNamedAccounts } = hre
    const { deployer } = await getNamedAccounts()

    console.log(`Deploying ${contractName} on network: ${hre.network.name} with deployer: ${deployer}`)

    const eid = hre.network.config.eid as EndpointId
    const lzNetworkName = endpointIdToNetwork(eid)
    const { address: endpointAddress } = getDeploymentAddressAndAbi(lzNetworkName, 'EndpointV2')

    console.log(`LZ EndpointV2: ${endpointAddress}`)

    // Deployer is the initial owner — transfer to Safe after wiring is verified
    const { address: proxyAdminAddress } = await deployProxyAdmin({
        hre,
        deployOptions: {
            from: deployer,
            args: [deployer],
            skipIfAlreadyDeployed: true,
        },
        deploymentName: contractName,
    })

    console.log(`ProxyAdmin deployed at: ${proxyAdminAddress}`)

    const { address: implementationAddress } = await deployImplementation({
        hre,
        deployOptions: {
            from: deployer,
            args: [endpointAddress],
            skipIfAlreadyDeployed: true,
            contract: contractName,
        },
        deploymentName: contractName,
    })

    console.log(`Implementation deployed at: ${implementationAddress}`)

    const initializeInterface = new hre.ethers.utils.Interface([
        'function initialize(string memory name, string memory symbol, address delegate)',
    ])
    // Deployer is the initial delegate — transfer ownership to Safe after wiring is verified
    const initializeData = initializeInterface.encodeFunctionData('initialize', ['Katana', 'KAT', deployer])

    const { address: proxyAddress } = await deployProxy({
        hre,
        deployOptions: {
            from: deployer,
            args: [implementationAddress, proxyAdminAddress, initializeData],
            skipIfAlreadyDeployed: true,
        },
        deploymentName: contractName,
    })

    console.log(`Proxy deployed at: ${proxyAddress}`)
    console.log(`\nDeployment summary:`)
    console.log(`  ProxyAdmin:     ${proxyAdminAddress}`)
    console.log(`  Implementation: ${implementationAddress}`)
    console.log(`  Proxy:          ${proxyAddress}`)
    console.log(`\nRemember to transfer ownership to the Safe after wiring is verified:`)
    console.log(`  OFT proxy owner (delegate):   transferOwnership(safeAddress)`)
    console.log(`  ProxyAdmin owner:              transferOwnership(safeAddress)`)

    await saveCombinedDeployment({ hre, deploymentName: contractName })
}

deploy.tags = [contractName]

export default deploy
