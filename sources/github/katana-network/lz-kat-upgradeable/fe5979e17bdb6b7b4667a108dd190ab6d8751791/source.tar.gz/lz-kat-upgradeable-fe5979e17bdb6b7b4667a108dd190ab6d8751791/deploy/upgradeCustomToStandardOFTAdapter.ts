import { DeployFunction } from 'hardhat-deploy/types'

import { deployImplementation } from '@layerzerolabs/devtools-evm-hardhat'
import { EndpointId, endpointIdToNetwork } from '@layerzerolabs/lz-definitions'
import { getDeploymentAddressAndAbi } from '@layerzerolabs/lz-evm-sdk-v2'

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS — verify these before running
// ─────────────────────────────────────────────────────────────────────────────

/// Address of the existing TransparentUpgradeableProxy (KATCustomOFTAdapterUpgradeable)
const PROXY_ADDRESS = '0x8f051ca72a3440d83b18e71c3e59676203ab8f91'

/// Underlying KAT token address on Katana
const KAT_TOKEN_ADDRESS = '0x7f1f4b4b29f5058fa32cc7a97141b8d7e5abdc2d'

// ─────────────────────────────────────────────────────────────────────────────
// EIP-1967 admin slot — keccak256("eip1967.proxy.admin") - 1
// ProxyAdmin address is read from this slot at runtime; no manual constant needed.
const EIP1967_ADMIN_SLOT = '0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103'
// ─────────────────────────────────────────────────────────────────────────────

/// @dev Step 1: Deploys the new KATOFTAdapterUpgradeable implementation (deployer signs).
/// Step 2: Prints the ProxyAdmin.upgradeAndCall() calldata to paste into Safe.
///
/// The deployer only needs to sign the implementation deployment.
/// The actual upgrade (pointing the proxy at the new implementation) must be
/// submitted through the Safe that owns the ProxyAdmin.
const newContractName = 'KATOFTAdapterUpgradeable'

const deploy: DeployFunction = async (hre) => {
    const { getNamedAccounts, ethers } = hre
    const { deployer } = await getNamedAccounts()

    // Read ProxyAdmin address from the EIP-1967 admin slot of the proxy
    const adminSlotValue = await ethers.provider.getStorageAt(PROXY_ADDRESS, EIP1967_ADMIN_SLOT)
    const PROXY_ADMIN_ADDRESS = ethers.utils.getAddress('0x' + adminSlotValue.slice(-40))

    console.log(`\nUpgrading proxy → ${newContractName} on ${hre.network.name}`)
    console.log(`  Proxy:       ${PROXY_ADDRESS}`)
    console.log(`  ProxyAdmin:  ${PROXY_ADMIN_ADDRESS}  (read from EIP-1967 admin slot)`)
    console.log(`  Deployer:    ${deployer}\n`)

    // ── Resolve LZ endpoint ──────────────────────────────────────────────────
    const eid = hre.network.config.eid as EndpointId
    const lzNetworkName = endpointIdToNetwork(eid)
    const { address: endpointAddress } = getDeploymentAddressAndAbi(lzNetworkName, 'EndpointV2')
    console.log(`LZ EndpointV2: ${endpointAddress}`)

    // ── Deploy new implementation (deployer signs this) ──────────────────────
    const { address: newImplAddress } = await deployImplementation({
        hre,
        deployOptions: {
            from: deployer,
            args: [KAT_TOKEN_ADDRESS, endpointAddress],
            skipIfAlreadyDeployed: false,
            contract: newContractName,
        },
        deploymentName: `${newContractName}_Implementation`,
    })
    console.log(`\nNew implementation deployed at: ${newImplAddress}`)

    // ── Encode ProxyAdmin upgrade calldata for Safe ──────────────────────────
    //
    // ProxyAdmin.upgradeAndCall(address proxy, address implementation, bytes data)
    // Works for both OZ v4 and v5 ProxyAdmin.
    // Passing empty data ("0x") because the proxy is already initialised —
    // no re-initialisation is needed on upgrade.
    //
    const proxyAdminAbi = [
        'function upgradeAndCall(address proxy, address implementation, bytes calldata data) payable',
        'function upgrade(address proxy, address implementation)',
    ]
    const proxyAdminInterface = new ethers.utils.Interface(proxyAdminAbi)

    const upgradeAndCallData = proxyAdminInterface.encodeFunctionData('upgradeAndCall', [
        PROXY_ADDRESS,
        newImplAddress,
        '0x',
    ])

    // Also encode plain upgrade() for OZ v4 ProxyAdmin (no-data variant)
    const upgradeData = proxyAdminInterface.encodeFunctionData('upgrade', [PROXY_ADDRESS, newImplAddress])

    console.log('\n═══════════════════════════════════════════════════════════════')
    console.log('  Safe Transaction — ProxyAdmin Upgrade')
    console.log('═══════════════════════════════════════════════════════════════')
    console.log(`  To (ProxyAdmin):      ${PROXY_ADMIN_ADDRESS}`)
    console.log(`  Value:                0`)
    console.log()
    console.log('  ── If ProxyAdmin is OZ v5 (upgradeAndCall) ──')
    console.log(`  Calldata: ${upgradeAndCallData}`)
    console.log()
    console.log('  ── If ProxyAdmin is OZ v4 (upgrade) ──')
    console.log(`  Calldata: ${upgradeData}`)
    console.log('═══════════════════════════════════════════════════════════════')
    console.log()
    console.log('  Deployment summary:')
    console.log(`    Proxy (unchanged):   ${PROXY_ADDRESS}`)
    console.log(`    ProxyAdmin:          ${PROXY_ADMIN_ADDRESS}`)
    console.log(`    New implementation:  ${newImplAddress}`)
    console.log()
    console.log('  After the Safe tx executes, verify the upgrade:')
    console.log(
        `    cast call ${PROXY_ADMIN_ADDRESS} "getProxyImplementation(address)(address)" ${PROXY_ADDRESS} --rpc-url <KATANA_RPC>`
    )
    console.log('═══════════════════════════════════════════════════════════════\n')
}

deploy.tags = ['upgradeCustomToStandardOFTAdapter']

export default deploy
