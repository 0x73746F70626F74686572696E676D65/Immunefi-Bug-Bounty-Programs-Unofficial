import path from 'path'

import { BigNumber } from 'ethers'
import { parseUnits } from 'ethers/lib/utils'
import { task, types } from 'hardhat/config'
import { HardhatRuntimeEnvironment } from 'hardhat/types'

import { OmniPointHardhat, createGetHreByEid } from '@layerzerolabs/devtools-evm-hardhat'
import { Options, addressToBytes32 } from '@layerzerolabs/lz-v2-utilities'

/**
 * lz:oft:encode-safe-send
 *
 * Quotes the native fee and prints all parameters needed to submit an OFT send
 * from a Safe wallet (or any multi-sig) without signing anything on-chain.
 *
 * For OFT Adapters (e.g. Katana) it also prints the ERC-20 approve calldata
 * that must be submitted as a separate transaction BEFORE the send.
 *
 * Usage:
 *   pnpm hardhat lz:oft:encode-safe-send \
 *     --network katana-mainnet \
 *     --src-eid 30375 \
 *     --dst-eid 30102 \
 *     --amount 999 \
 *     --to 0xRecipientAddress \
 *     --safe-address 0xYourSafeAddress
 */
task('lz:oft:encode-safe-send', 'Quotes fee and encodes OFT send calldata for Safe wallet submission')
    .addParam('srcEid', 'Source endpoint ID', undefined, types.int)
    .addParam('dstEid', 'Destination endpoint ID', undefined, types.int)
    .addParam('amount', 'Amount to send (human readable, e.g. "999")', undefined, types.string)
    .addParam('to', 'Recipient address on destination chain', undefined, types.string)
    .addParam('safeAddress', 'The Safe wallet address that will submit the transaction (used as refund address)', undefined, types.string)
    .addOptionalParam('oappConfig', 'Path to the LayerZero config file', 'layerzero.config.ts', types.string)
    .addOptionalParam('oftAddress', 'Override OFT contract address', undefined, types.string)
    .setAction(async (args, hre: HardhatRuntimeEnvironment) => {
        const { srcEid, dstEid, amount, to, safeAddress, oappConfig, oftAddress } = args

        const getHreByEid = createGetHreByEid(hre)
        const srcHre = await getHreByEid(srcEid)

        // Resolve OFT contract address
        let wrapperAddress: string
        if (oftAddress) {
            wrapperAddress = oftAddress
        } else {
            const layerZeroConfig = (await import(path.resolve('./', oappConfig))).default
            const { contracts } = typeof layerZeroConfig === 'function' ? await layerZeroConfig() : layerZeroConfig
            const wrapper = contracts.find((c: { contract: OmniPointHardhat }) => c.contract.eid === srcEid)
            if (!wrapper) throw new Error(`No config entry found for EID ${srcEid}`)
            // Prefer hardcoded address; fall back to deployments lookup by contractName
        wrapperAddress = wrapper.contract.address
            || (wrapper.contract.contractName
                ? (await srcHre.deployments.get(wrapper.contract.contractName)).address
                : '')
        }

        const ioftArtifact = await srcHre.artifacts.readArtifact('IOFT')
        const erc20Artifact = await srcHre.artifacts.readArtifact('ERC20')
        const provider = srcHre.ethers.provider

        // Use Contract directly — all calls are read-only, no signer needed
        const oft = new srcHre.ethers.Contract(wrapperAddress, ioftArtifact.abi, provider)

        // Fetch decimals from the underlying token
        const underlying: string = await oft.token()
        const erc20 = new srcHre.ethers.Contract(underlying, erc20Artifact.abi, provider)
        const decimals: number = await erc20.decimals()
        const amountUnits: BigNumber = parseUnits(amount, decimals)

        // Build sendParam (mirrors sendEvm.ts exactly)
        const toBytes = addressToBytes32(to)
        const extraOptions = Options.newOptions().toHex() // no extra options; enforced options applied on-chain
        const sendParam = {
            dstEid,
            to: toBytes,
            amountLD: amountUnits.toString(),
            minAmountLD: amountUnits.toString(),
            extraOptions,
            composeMsg: '0x',
            oftCmd: '0x',
        }

        // Quote native fee (read-only)
        const msgFee: { nativeFee: BigNumber; lzTokenFee: BigNumber } = await oft.quoteSend(sendParam, false)

        // Encode send() calldata
        const sendCalldata = oft.interface.encodeFunctionData('send', [sendParam, msgFee, safeAddress])

        // Check if ERC-20 approval is needed (OFT Adapter)
        let approvalRequired = false
        try {
            approvalRequired = await oft.approvalRequired()
        } catch {
            // regular OFT — no approval needed
        }

        console.log('\n========== Safe Transaction Parameters ==========\n')

        if (approvalRequired) {
            const approveCalldata = erc20.interface.encodeFunctionData('approve', [wrapperAddress, amountUnits])
            console.log('⚠️  OFT Adapter detected — submit Transaction 1 (approve) BEFORE Transaction 2 (send)\n')
            console.log('--- Transaction 1: ERC-20 Approve ---')
            console.log(`  Contract (token):  ${underlying}`)
            console.log(`  Value (ETH):       0`)
            console.log(`  Calldata:          ${approveCalldata}`)
            console.log()
        }

        const txLabel = approvalRequired ? 'Transaction 2: OFT Send' : 'Transaction: OFT Send'
        console.log(`--- ${txLabel} ---`)
        console.log(`  Contract (OFT):    ${wrapperAddress}`)
        console.log(`  Value (wei):       ${msgFee.nativeFee.toString()}`)
        console.log(`  Value (ETH):       ${srcHre.ethers.utils.formatEther(msgFee.nativeFee)} ETH`)
        console.log(`  Calldata:          ${sendCalldata}`)
        console.log()
        console.log('--- sendParam breakdown (for reference) ---')
        console.log(`  dstEid:            ${dstEid}`)
        console.log(`  to (bytes32):      ${toBytes}`)
        console.log(`  amountLD (wei):    ${amountUnits.toString()}  (${amount} tokens, ${decimals} decimals)`)
        console.log(`  minAmountLD:       ${amountUnits.toString()}`)
        console.log(`  extraOptions:      ${extraOptions}`)
        console.log(`  composeMsg:        0x`)
        console.log(`  oftCmd:            0x`)
        console.log()
        console.log('--- MessagingFee ---')
        console.log(`  nativeFee (wei):   ${msgFee.nativeFee.toString()}`)
        console.log(`  lzTokenFee:        ${msgFee.lzTokenFee.toString()}`)
        console.log()
        console.log(`  refundAddress:     ${safeAddress}`)
        console.log('\n=================================================\n')
    })
