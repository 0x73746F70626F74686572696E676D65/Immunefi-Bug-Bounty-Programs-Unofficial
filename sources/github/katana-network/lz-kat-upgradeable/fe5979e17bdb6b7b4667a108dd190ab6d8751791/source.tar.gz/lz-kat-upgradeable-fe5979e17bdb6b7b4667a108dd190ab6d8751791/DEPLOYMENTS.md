# Mainnet Deployments

## Katana

| Contract | Address |
|---|---|
| KAT Token | `0x7f1f4b4b29f5058fa32cc7a97141b8d7e5abdc2d` |
| Locked KAT Vault | `0x89063623F00238106C9a60032fAe2Ab702b8A1fB` |
| ProxyAdmin for Adapter | `0xeb8f9227f5e6012fd4e0d52461a6cd0226a0275f` |
| KATCustomOFTAdapterUpgradeable_Proxy | `0x8f051ca72a3440d83b18e71c3e59676203ab8f91` |

## Ethereum

| Contract | Address |
|---|---|
| Proxy (main address) | `0x8F051Ca72a3440d83B18E71C3E59676203aB8f91` |
| ProxyAdmin | `0xEB8F9227F5E6012fD4E0d52461a6cD0226A0275F` |

## Base

| Contract | Address |
|---|---|
| Proxy (main address) | `0xD5390300c5DB71F80d46f0fA9983Fc72D4d1e3da` |
| ProxyAdmin | `0x89063623F00238106C9a60032fAe2Ab702b8A1fB` |

---

**LZ Config Checker:** [View live pathway configuration](https://lz-config-checker.vercel.app/?c=MHanAnXodZWPBRynKjRA2DsY5xw-WWdiA6uPkQ&sh=1)
