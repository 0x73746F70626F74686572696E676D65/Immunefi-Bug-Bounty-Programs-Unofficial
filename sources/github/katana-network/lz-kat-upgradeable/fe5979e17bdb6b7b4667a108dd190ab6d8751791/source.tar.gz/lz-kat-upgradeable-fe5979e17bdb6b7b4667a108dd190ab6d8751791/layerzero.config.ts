import { EndpointId } from '@layerzerolabs/lz-definitions'
import { ExecutorOptionType } from '@layerzerolabs/lz-v2-utilities'
import { TwoWayConfig, generateConnectionsConfig } from '@layerzerolabs/metadata-tools'
import { OAppEnforcedOption } from '@layerzerolabs/toolbox-hardhat'

import type { OmniPointHardhat } from '@layerzerolabs/toolbox-hardhat'

const katanaContract: OmniPointHardhat = {
    eid: EndpointId.KATANA_V2_MAINNET,
    contractName: 'KATCustomOFTAdapterUpgradeable',
    address: '0x8f051ca72a3440d83b18e71c3e59676203ab8f91',
}

const bscContract: OmniPointHardhat = {
    eid: EndpointId.BSC_V2_MAINNET,
    contractName: 'KATCustomOFTUpgradeable',
    address: '0xd5390300c5db71f80d46f0fa9983fc72d4d1e3da',
}

const ethereumContract: OmniPointHardhat = {
    eid: EndpointId.ETHEREUM_V2_MAINNET,
    contractName: 'KATOFTUpgradeable',
    address: '0x8F051Ca72a3440d83B18E71C3E59676203aB8f91',
}

const baseContract: OmniPointHardhat = {
    eid: EndpointId.BASE_V2_MAINNET,
    contractName: 'KATOFTUpgradeable',
    address: '0xD5390300c5DB71F80d46f0fA9983Fc72D4d1e3da',
}

const arbitrumContract: OmniPointHardhat = {
    eid: EndpointId.ARBITRUM_V2_MAINNET,
    contractName: 'KATOFTUpgradeable',
    address: '0xD5390300c5DB71F80d46f0fA9983Fc72D4d1e3da',
}

const polygonContract: OmniPointHardhat = {
    eid: EndpointId.POLYGON_V2_MAINNET,
    contractName: 'KATOFTUpgradeable',
    address: '0xD5390300c5DB71F80d46f0fA9983Fc72D4d1e3da',
}
// Pathways:

// For this example's simplicity, we will use the same enforced options values for sending to all chains
// For production, you should ensure `gas` is set to the correct value through profiling the gas usage of calling OFT._lzReceive(...) on the destination chain
// To learn more, read https://docs.layerzero.network/v2/concepts/applications/oapp-standard#execution-options-and-enforced-settings
const EVM_ENFORCED_OPTIONS: OAppEnforcedOption[] = [
    {
        msgType: 1,
        optionType: ExecutorOptionType.LZ_RECEIVE,
        gas: 80000,
        value: 0,
    },
]

const DVN_CONFIG: TwoWayConfig[2] = [
    ['Nethermind', 'Deutsche Telekom'],
    [['LayerZero Labs', 'Frax', 'Horizen', 'Canary'], 3],
]
// With the config generator, pathways declared are automatically bidirectional
// i.e. if you declare A,B there's no need to declare B,A
const pathways: TwoWayConfig[] = [
    // [
    //     katanaContract, // Chain A contract
    //     bscContract, // Chain B contract
    //     [['LayerZero Labs'], [['Nethermind', 'Deutsche Telekom', 'Frax'], 1]], // [ requiredDVN[], [ optionalDVN[], threshold ] ]
    //     [240, 20], // [A to B confirmations, B to A confirmations]
    //     [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    // ],
    [
        katanaContract, // Chain A contract
        ethereumContract, // Chain B contract
        DVN_CONFIG,
        [240, 20], // [A to B confirmations, B to A confirmations]
        [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    ],
    [
        katanaContract,
        baseContract,
        DVN_CONFIG,
        [240, 240], // [A to B confirmations, B to A confirmations]
        [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    ],
    [
        ethereumContract, // Chain A contract
        baseContract, // Chain B contract
        DVN_CONFIG,
        [20, 240], // [A to B confirmations, B to A confirmations]
        [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    ],
    // [
    //     katanaContract, // Chain A contract
    //     arbitrumContract, // Chain B contract
    //     [['LayerZero Labs'], [['Nethermind', 'Deutsche Telekom', 'Frax'], 1]], // [ requiredDVN[], [ optionalDVN[], threshold ] ]
    //     [240, 20], // [A to B confirmations, B to A confirmations]
    //     [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    // ],
    // [
    //     katanaContract, // Chain A contract
    //     polygonContract, // Chain B contract
    //     [['LayerZero Labs'], [['Nethermind', 'Deutsche Telekom', 'Frax'], 1]], // [ requiredDVN[], [ optionalDVN[], threshold ] ]
    //     [240, 20], // [A to B confirmations, B to A confirmations]
    //     [EVM_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    // ],
]
// Note: you should not use the values 1, 1 for confirmations. Choose the right number of confirmations based on the finalization that you require from the source/destination chains.

export default async function () {
    // Generate the connections config based on the pathways
    const connections = await generateConnectionsConfig(pathways)
    return {
        contracts: [
            { contract: katanaContract },
            { contract: bscContract },
            { contract: ethereumContract },
            { contract: baseContract },
            { contract: arbitrumContract },
            { contract: polygonContract },
        ],
        connections,
    }
}
