import { SignerWithAddress } from '@nomiclabs/hardhat-ethers/signers'
import { expect } from 'chai'
import { Contract, ContractFactory } from 'ethers'
import lzDevTool from '@layerzerolabs/test-devtools-evm-hardhat'
import {
    deployImplementation,
    deployProxy,
    deployProxyAdmin,
} from '@layerzerolabs/devtools-evm-hardhat'
import { existsSync, rmSync } from 'node:fs'

/// In this test case, we make sure that the `KATCustomOFTUpgradeable` contract can be depoyed, upgraded and downgraded
/// using the LZ toolchain, like in the deployment scripts
describe('KATCustomOFTUpgradeable Test with LZ toolchain', () => {
    const contractName = 'KATCustomOFTUpgradeable'
    const hre = lzDevTool.getTestHre({network: 'hardhat', config: 'hardhat.config.ts'});
    const {deployments, ethers} = hre;
    // Constant representing a mock Endpoint ID for testing purposes
    const eidA = 1
    // Declaration of variables to be used in the test suite
    let KATCustomOFTUpgradeable: ContractFactory
    let KATOFTUpgradeable: ContractFactory
    let owner: SignerWithAddress
    let deployer: SignerWithAddress
    let endpointOwner: SignerWithAddress
    let mockEndpointV2: Contract

    before(async function () {
        // Fetching the first three signers (accounts) from Hardhat's local Ethereum network
        const signers = await ethers.getSigners();
        
        [owner, deployer, endpointOwner] = signers;
        KATCustomOFTUpgradeable = await ethers.getContractFactory('KATCustomOFTUpgradeable');
        KATOFTUpgradeable = await ethers.getContractFactory('KATOFTUpgradeable');

        // The EndpointV2Mock contract comes from @layerzerolabs/test-devtools-evm-hardhat package
        // and its artifacts are connected as external artifacts to this project
        //
        // Unfortunately, hardhat itself does not yet provide a way of connecting external artifacts,
        // so we rely on hardhat-deploy to create a ContractFactory for EndpointV2Mock
        //
        // See https://github.com/NomicFoundation/hardhat/issues/1040
        const EndpointV2MockArtifact = await deployments.getArtifact('EndpointV2Mock')
        const EndpointV2Mock = new ContractFactory(EndpointV2MockArtifact.abi, EndpointV2MockArtifact.bytecode, endpointOwner)

        // Deploying a mock LZEndpoint with the given Endpoint ID
        mockEndpointV2 = await EndpointV2Mock.deploy(eidA)
    })

    after(function() {
        // clean auto-generated deployment files
        existsSync('.deployments-test') && rmSync('.deployments-test', {recursive: true});
    })

    it('should upgrade', async () => {
        // Deploy proxy admin
        const { address: proxyAdminAddress } = await deployProxyAdmin({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [owner.address], // owner
                skipIfAlreadyDeployed: true,
            },
        })

        // Deploying the upgradeable contract
        const { address: implementationAddress } = await deployImplementation({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [mockEndpointV2.address],
                contract: contractName,
                skipIfAlreadyDeployed: true
            },
        })
        
        const initializeInterface = new ethers.utils.Interface(['function initialize(string memory,string memory,address)'])
        const initializeData = initializeInterface.encodeFunctionData('initialize', ['Test', 'TEST', owner.address])
    
        const deployment = await deployProxy({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [implementationAddress, proxyAdminAddress, initializeData],
                skipIfAlreadyDeployed: true
            },
            deploymentName: contractName
        })
        const customOFT = KATCustomOFTUpgradeable.attach(deployment.address);

        // Make sure we can interact with the contract and that it's been properly initialized
        const [tokenName] = await customOFT.functions.name();
        expect(tokenName).to.equal('Test');
        const [tokenSymbol] = await customOFT.functions.symbol();
        expect(tokenSymbol).to.equal('TEST');

        // Deploy the new implementation
        const { address: newImplementationAddress } = await deployImplementation({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [mockEndpointV2.address],
                skipIfAlreadyDeployed: true,
                contract: 'KATOFTUpgradeable',
            },
        })
        // Upgrade the contract to the standard contract 
        const proxyAdmin = await ethers.getContractAt('ProxyAdmin', proxyAdminAddress)
        await proxyAdmin.upgrade(customOFT.address, newImplementationAddress);
        const oft = KATOFTUpgradeable.attach(deployment.address);

        // Ensure the implementation address are not the same
        expect(implementationAddress).to.not.equal(newImplementationAddress)
        // Ensure we cannot pause anymore
        await expect(customOFT.functions.pause()).to.reverted;

        
        // Downgrade the contract to the custom adapter again
        await proxyAdmin.upgrade(oft.address, implementationAddress);
        // Ensure we can pause again
        await expect(customOFT.functions.pause()).to.not.reverted;
    })
})
