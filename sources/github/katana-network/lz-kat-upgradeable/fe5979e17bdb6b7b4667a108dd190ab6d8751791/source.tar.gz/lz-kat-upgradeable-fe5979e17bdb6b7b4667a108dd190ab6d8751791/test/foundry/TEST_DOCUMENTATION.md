# Test Suite Documentation

## Test Results Summary

```
╭────────────────────────────────────┬────────┬────────┬─────────╮
│ Test Suite                         │ Passed │ Failed │ Skipped │
├════════════════════════════════════════════════════════════════┤
│ KATCustomOFTAdapterUpgradeableTest │ 12     │ 0      │ 0       │
│ KATOFTAdapterUpgradeableTest       │ 4      │ 0      │ 0       │
│ KATCustomOFTUpgradeableTest        │ 16     │ 0      │ 0       │
│ KATOFTUpgradeableTest              │ 1      │ 0      │ 0       │
│ KATStorageLayoutTest               │ 5      │ 0      │ 0       │
│ KATBridgeIntegrationTest           │ 12     │ 0      │ 0       │
╰────────────────────────────────────┴────────┴────────┴─────────╯

Total: 50/50 tests passing (100%)

---

## 1. KATCustomOFTAdapterUpgradeable.t.sol

**Test Count:** 12 tests
**Purpose:** Unit tests for custom OFT Adapter with BRIDGE_USER role and vault integration

### Test Cases

#### ✅ `test_grantBridgeUser()`
- **Purpose:** Verify admin can grant BRIDGE_USER role
- **What it tests:**
  - Admin calls `grantBridgeUser()`
  - User receives BRIDGE_USER role
  - `isBridgeUser()` returns true

#### ✅ `test_revertWhen_grantBridgeUserFromNonAdmin()`
- **Purpose:** Verify only admin can grant BRIDGE_USER role
- **What it tests:**
  - Non-admin attempts to grant role
  - Reverts with `AccessControlUnauthorizedAccount`

#### ✅ `test_revokeBridgeUser()`
- **Purpose:** Verify admin can revoke BRIDGE_USER role
- **What it tests:**
  - Admin calls `revokeBridgeUser()`
  - User loses BRIDGE_USER role

#### ✅ `test_revertWhen_revokeBridgeUserFromNonAdmin()`
- **Purpose:** Verify only admin can revoke BRIDGE_USER role
- **What it tests:**
  - Non-admin attempts to revoke role
  - Reverts with `AccessControlUnauthorizedAccount`

#### ✅ `test_debit()`
- **Purpose:** Verify BRIDGE_USER can successfully send tokens
- **What it tests:**
  - BRIDGE_USER calls `send()` with valid parameters
  - Vault's `transferKat()` is called
  - `BridgeInitiated` event is emitted

#### ✅ `test_revertWhen_debitFromNonBridgeUser()`
- **Purpose:** Verify only BRIDGE_USER can send tokens
- **What it tests:**
  - Non-BRIDGE_USER attempts to call `send()`
  - Reverts with `AccessControlUnauthorizedAccount`

#### ✅ `test_setVault()`
- **Purpose:** Verify owner can update the vault address
- **What it tests:**
  - Owner calls `setVault()` with new address
  - Vault address is updated
  - `VaultUpdated` event is emitted

#### ✅ `test_revertWhen_setVaultWithAddress0()`
- **Purpose:** Verify vault cannot be set to zero address
- **What it tests:**
  - Owner attempts to set vault to address(0)
  - Reverts with "KATCustomOFTAdapter: vault is zero address"

#### ✅ `test_revertWhen_setVaultFromNonOwnerAddress()`
- **Purpose:** Verify only owner can set vault address
- **What it tests:**
  - Non-owner attempts to call `setVault()`
  - Reverts with `OwnableUnauthorizedAccount`

#### ✅ `test_initialize()`
- **Purpose:** Verify contract initializes correctly via proxy
- **What it tests:**
  - Proxy deployed without initialization
  - Initial state: no admin role, owner is zero
  - After calling `initialize()`:
    - DEFAULT_ADMIN_ROLE granted
    - Owner set correctly
    - Endpoint delegate set
    - `Initialized` event emitted

#### ✅ `test_revertWhen_initializeTwice()`
- **Purpose:** Verify contract cannot be initialized twice
- **What it tests:**
  - Contract already initialized in setUp
  - Second initialization attempt reverts
  - Reverts with `InvalidInitialization` error

#### ✅ `test_initializated_disableOnImplementationContract()`
- **Purpose:** Verify implementation contract cannot be initialized
- **What it tests:**
  - Retrieves implementation address from proxy storage slot
  - Attempts to initialize implementation contract
  - Reverts with `InvalidInitialization`
  - Confirms proxy has delegate set, implementation doesn't

---

## 2. KATOFTAdapterUpgradeable.t.sol

**Test Count:** 4 tests
**Purpose:** Unit tests for standard OFT Adapter (without custom features)

### Test Cases

#### ✅ `test_debit()`
- **Purpose:** Verify tokens can be sent through the adapter
- **What it tests:**
  - User approves tokens to adapter
  - User calls `send()` with valid parameters
  - Tokens are transferred from user to adapter
  - LayerZero message is sent

#### ✅ `test_initialize()`
- **Purpose:** Verify contract initializes correctly via proxy
- **What it tests:**
  - Proxy deployed without initialization
  - Initial state: no admin role, owner is zero
  - After calling `initialize()`:
    - Owner set correctly
    - Endpoint delegate set
    - `Initialized` event emitted
  - Note: Unlike custom adapter, standard adapter doesn't grant DEFAULT_ADMIN_ROLE

#### ✅ `test_revertWhen_initializeTwice()`
- **Purpose:** Verify contract cannot be initialized twice
- **What it tests:**
  - Contract already initialized in setUp
  - Second initialization attempt reverts
  - Reverts with `InvalidInitialization` error

#### ✅ `test_initializated_disableOnImplementationContract()`
- **Purpose:** Verify implementation contract cannot be initialized
- **What it tests:**
  - Retrieves implementation address from proxy storage slot
  - Attempts to initialize implementation contract
  - Reverts with `InvalidInitialization`
  - Confirms proxy has delegate set, implementation doesn't

---

## 3. KATCustomOFTUpgradeable.t.sol

**Test Count:** 16 tests  
**Purpose:** Unit tests for custom OFT with pausable functionality

### Test Cases

#### ✅ `test_initialization()`
- **Purpose:** Verify contract initializes correctly
- **What it tests:**
  - Token name/symbol set correctly
  - Owner is set to deployer
  - Contract starts unpaused

#### ✅ `test_revertWhen_initializeTwice()`
- **Purpose:** Verify contract cannot be initialized twice
- **What it tests:**
  - Second initialization attempt reverts with `InvalidInitialization`

#### ✅ `test_implementation_initialization_disabled()`
- **Purpose:** Verify implementation contract cannot be initialized
- **What it tests:**
  - Implementation initialization reverts with `InvalidInitialization`

#### ✅ `test_pause()`
- **Purpose:** Verify owner can pause the contract
- **What it tests:**
  - Owner calls `pause()`
  - Contract state changes to paused

#### ✅ `test_unpause()`
- **Purpose:** Verify owner can unpause the contract
- **What it tests:**
  - Owner calls `unpause()`
  - Contract state changes to unpaused

#### ✅ `test_revertWhen_pauseFromNonOwner()`
- **Purpose:** Verify only owner can pause
- **What it tests:**
  - Non-owner attempts to pause
  - Reverts with `OwnableUnauthorizedAccount`

#### ✅ `test_revertWhen_unpauseFromNonOwner()`
- **Purpose:** Verify only owner can unpause
- **What it tests:**
  - Non-owner attempts to unpause
  - Reverts with `OwnableUnauthorizedAccount`

#### ✅ `test_multiplePauseCycles()`
- **Purpose:** Verify pause/unpause can be called multiple times
- **What it tests:**
  - Multiple pause → unpause cycles work correctly

#### ✅ `test_send_whenNotPaused()`
- **Purpose:** Verify sending works when not paused
- **What it tests:**
  - User calls `send()` with valid parameters
  - Tokens are debited, LayerZero message sent

#### ✅ `test_revertWhen_sendWhenPaused()`
- **Purpose:** Verify sending fails when paused
- **What it tests:**
  - Contract is paused
  - User attempts to send tokens
  - Reverts with `EnforcedPause`

#### ✅ `test_transferWhilePaused()`
- **Purpose:** Verify ERC20 transfers work while paused
- **What it tests:**
  - Contract is paused
  - User transfers tokens to another address
  - Transfer succeeds (pause only affects bridging)

#### ✅ `test_transferOwnership()`
- **Purpose:** Verify ownership can be transferred
- **What it tests:**
  - Current owner transfers ownership
  - New owner is set correctly

#### ✅ `test_pauseByNewOwner()`
- **Purpose:** Verify new owner has pause privileges
- **What it tests:**
  - Ownership is transferred
  - New owner can call `pause()`

#### ✅ `test_revertWhen_oldOwnerTriesToPause()`
- **Purpose:** Verify old owner loses privileges after transfer
- **What it tests:**
  - Ownership is transferred
  - Old owner cannot pause
  - Reverts with `OwnableUnauthorizedAccount`

#### ✅ `test_statePersistence_duringPauseCycle()`
- **Purpose:** Verify balances persist through pause cycles
- **What it tests:**
  - Pause and unpause contract
  - Balance remains unchanged

#### ✅ `test_fuzz_sendAmounts(uint256)`
- **Purpose:** Test sending with random amounts
- **What it tests:**
  - 256 random amounts tested
  - Transactions succeed or revert appropriately

---

## 4. KATOFTUpgradeableTest.t.sol

**Test Count:** 1 test
**Purpose:** Verify standard OFT contract cannot be initialized at implementation level

### Test Cases

#### ✅ `test_oft_implementation_initialization_disabled()`
- **Purpose:** Verify OFT implementation is protected
- **What it tests:**
  - Implementation initialization reverts with `InvalidInitialization`

---

## 5. KATStorageLayout.t.sol

**Test Count:** 5 tests  
**Purpose:** Tests for EIP-7201 storage layout implementation and upgrade safety

### Test Cases

#### ✅ `test_storageSlotCalculation()`
- **Purpose:** Verify the EIP-7201 storage slot calculation is correct
- **What it tests:**
  - Calculates storage slot using EIP-7201 formula:
    - `keccak256(abi.encode(uint256(keccak256(bytes("kat.oft.adapter"))) - 1)) & ~bytes32(uint256(0xff))`
  - Compares calculated slot with `OFT_ADAPTER_STORAGE_LOCATION` constant
  - Ensures storage slot matches specification

#### ✅ `test_vaultStoragePersistsAfterUpgrade()`
- **Purpose:** Verify vault storage persists after upgrading from Custom to Standard adapter
- **What it tests:**
  - Deploys custom adapter with vault set
  - Simulates upgrade to standard adapter (no vault functionality)
  - Verifies vault address remains in EIP-7201 storage slot after upgrade
  - Confirms implementation address changed
  - Demonstrates storage independence from contract logic

#### ✅ `test_vaultStorageCanBeUpdated()`
- **Purpose:** Verify vault address can be updated correctly
- **What it tests:**
  - Sets initial vault address
  - Updates to new vault address
  - `VaultUpdated` event emitted
  - New vault address readable via `getVault()`
  - Storage slot contains new vault address

#### ✅ `test_vaultStorageIndependence()`
- **Purpose:** Verify vault storage is independent from other contract state
- **What it tests:**
  - Sets vault address
  - Performs operations that modify other storage (grant/revoke roles)
  - Confirms vault address unchanged after role operations
  - Demonstrates no storage collision with AccessControl storage

#### ✅ `test_uninitializedVaultStorage()`
- **Purpose:** Verify default storage state for uninitialized vault
- **What it tests:**
  - Deploys adapter without setting vault
  - `getVault()` returns zero address
  - EIP-7201 storage slot contains zero address
  - Confirms proper default state

### Key Features Tested
- **EIP-7201 Compliance:** Storage slot calculation matches standard
- **Upgrade Safety:** Storage persists across implementation upgrades
- **Storage Isolation:** No collisions with parent contract storage
- **State Management:** Vault can be initialized, updated, and queried correctly

---

## 6. KATBridgeIntegration.t.sol

**Test Count:** 12 tests  
**Purpose:** Integration tests for Katana ↔ BSC bridge with full cross-chain packet verification

### Test Cases

#### ✅ `test_integration_deployment()`
- **Purpose:** Verify complete bridge infrastructure deploys correctly
- **What it tests:**
  - KAT token, vault, adapter, OFT deployed
  - Peers configured with `addressToBytes32()`
  - Roles granted (BRIDGE_USER, LZ_BRIDGE_ROLE)

#### ✅ `test_integration_bridgeKatanaToBSC()`
- **Purpose:** Test bridging from Katana to BSC with packet verification
- **What it tests:**
  - Tokens locked in vault
  - `verifyPackets()` delivers message
  - Tokens minted on BSC

#### ✅ `test_integration_bridgeBSCToKatana()`
- **Purpose:** Test bridging from BSC to Katana with packet verification
- **What it tests:**
  - OFT tokens burned on BSC
  - `verifyPackets()` delivers message
  - Adapter releases tokens on Katana

#### ✅ `test_integration_roundTripBridge()`
- **Purpose:** Test complete bidirectional flow: Katana → BSC → Katana
- **What it tests:**
  - Bridge 100 tokens Katana → BSC
  - Return 30 tokens BSC → Katana
  - Token conservation: Adapter balance = OFT supply

#### ✅ `test_integration_revertWhen_nonBridgeUserTriesToBridge()`
- **Purpose:** Verify only BRIDGE_USER can bridge tokens
- **What it tests:**
  - Non-BRIDGE_USER attempts to bridge
  - Reverts with `AccessControlUnauthorizedAccount`

#### ✅ `test_integration_pauseVaultAndOFT()`
- **Purpose:** Verify OFT can be paused to halt bridging
- **What it tests:**
  - OFT is paused
  - Sending from BSC fails

#### ✅ `test_integration_unpauseAndResumeBridging()`
- **Purpose:** Verify bridging resumes after unpause
- **What it tests:**
  - OFT paused then unpaused
  - Bridging works after unpause

#### ✅ `test_integration_upgradeAdapterToStandard()`
- **Purpose:** Test upgrading adapter from custom to standard implementation
- **What it tests:**
  - ProxyAdmin.upgradeAndCall() successfully upgrades implementation
  - State preserved: owner, peers (OZ 5.0 creates ProxyAdmin internally)
  - Implementation address changes to standard adapter
  - **Note:** OZ 5.0 `TransparentUpgradeableProxy` takes owner address (not ProxyAdmin), creates ProxyAdmin internally

#### ✅ `test_integration_upgradeOFTToStandard()`
- **Purpose:** Test upgrading OFT from custom to standard implementation
- **What it tests:**
  - ProxyAdmin.upgradeAndCall() successfully upgrades implementation
  - State preserved: owner, name, symbol, peers
  - Implementation address changes to standard OFT
  - **Note:** Hardhat uses older OZ artifacts with separate `upgrade()` function

#### ✅ `test_integration_multipleSequentialBridges()`
- **Purpose:** Test multiple bridge transactions in sequence
- **What it tests:**
  - Bridge 10, 20, 30 ether sequentially
  - `verifyPackets()` after each
  - Cumulative balances verified

#### ✅ `test_integration_revertWhen_bridgingZeroAmount()`
- **Purpose:** Test handling of zero amount bridges
- **What it tests:**
  - Attempt to bridge 0 tokens
  - Reverts with appropriate error

#### ✅ `test_integration_totalSupplyConsistency()`
- **Purpose:** Verify supply consistency across chains
- **What it tests:**
  - Vault locked amount = OFT supply on BSC
  - Perfect supply consistency

---

## Test Execution Commands

### Run All Tests
```bash
forge test
```

### Run Specific Test Suite
```bash
# Unit tests
forge test --match-contract KATCustomOFTAdapterUpgradeableTest
forge test --match-contract KATOFTAdapterUpgradeableTest
forge test --match-contract KATCustomOFTUpgradeableTest
forge test --match-contract KATOFTUpgradeableTest

# Storage layout tests
forge test --match-contract KATStorageLayoutTest

# Integration tests
forge test --match-path "test/foundry/integration/*.sol"
```

### Run Specific Test
```bash
forge test --match-test test_integration_deployment
forge test --match-test test_pause
forge test --match-test test_grantBridgeUser
```

### Run with Verbosity
```bash
forge test -vv                                               # Show logs
forge test --match-test test_integration_bridgeKatanaToBSC -vvvv  # Full traces
```

### Check Coverage
```bash
forge coverage --ir-minimum
```

### Run with Gas Report
```bash
forge test --gas-report
```

---

## Test Coverage Summary

**Unit Tests (33 tests):**
- Access Control: 4 tests
- Pause/Unpause: 8 tests
- Initialization: 7 tests
- Bridging: 4 tests
- Vault Management: 3 tests
- Ownership: 3 tests
- State Persistence: 1 test
- Fuzz Testing: 1 test
- Implementation Protection: 4 tests

**Storage Layout Tests (5 tests):**
- EIP-7201 Compliance: 1 test
- Upgrade Safety: 1 test
- Storage Operations: 3 tests

**Integration Tests (12 tests):**
- Deployment: 1 test
- Bi-directional Bridging: 2 tests
- Round-Trip Bridging: 1 test
- Access Control: 1 test
- Pause/Unpause: 2 tests
- Upgrades: 2 tests
- Edge Cases: 3 tests

**Coverage:**
- ✅ Contract deployment and initialization
- ✅ Proxy pattern implementation
- ✅ Role-based access control
- ✅ Pause/unpause functionality
- ✅ Token locking and burning
- ✅ Full cross-chain packet verification
- ✅ Token conservation across chains
- ✅ EIP-7201 storage layout compliance
- ✅ Storage collision prevention
- ✅ Upgrade safety and storage persistence
- ✅ Upgrade readiness

**Note:** Post-upgrade bridging requires testnet deployment (OZ 5.x transparent proxy limitation).

---

## Helper Functions

### IntegrationHelpers.sol

**Modular helper functions for clean, reusable test code:**

- `deployCompleteBridge()` - Deploy complete bridge infrastructure
- `createSendParam()` - Create SendParam struct
- `bridgeAndVerify()` - Bridge + verify packets (one-line E2E)
- `bridgeFromOFTAndVerify()` - OFT bridge + verify packets
- `upgradeAdapterToStandard()` - Upgrade adapter
- `upgradeOFTToStandard()` - Upgrade OFT

**Key Technical Detail:**
- Uses `addressToBytes32()` for peer configuration (RIGHT-padded format)
- Required for LayerZero TestHelper packet verification
