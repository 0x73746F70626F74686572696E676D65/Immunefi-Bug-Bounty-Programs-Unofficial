import { SignerWithAddress } from '@nomiclabs/hardhat-ethers/signers'
import { expect } from 'chai'
import { Contract, ContractFactory } from 'ethers'
import lzDevTool from '@layerzerolabs/test-devtools-evm-hardhat'
import {
    deployImplementation,
    deployProxy,
    deployProxyAdmin,
} from '@layerzerolabs/devtools-evm-hardhat'
import { existsSync, rmSync } from 'node:fs'

/// In this test case, we make sure that the `KATCustomOFTAdapterUpgradeable` contract can be depoyed, upgraded and downgraded
/// using the LZ toolchain, like in the deployment scripts
describe('KATCustomOFTAdapterUpgradeable Tests with LZ toolchain', () => {
    const contractName = 'KATCustomOFTAdapterUpgradeable'
    const hre = lzDevTool.getTestHre({network: 'hardhat', config: 'hardhat.config.ts'});
    const {deployments, ethers} = hre;
    let owner: SignerWithAddress
    let deployer: SignerWithAddress
    let KATCustomOFTAdapterUpgradeable: ContractFactory
    let KATOFTAdapterUpgradeable: ContractFactory
    let token: Contract
    let endpoint: Contract

    before(async function () {
        const EndpointV2MockArtifact = await deployments.getArtifact('EndpointV2Mock')
        // Fetching the first signer from Hardhat's local Ethereum network
        const signers = await ethers.getSigners();
        [owner, deployer] = signers;

        KATCustomOFTAdapterUpgradeable = await ethers.getContractFactory('KATCustomOFTAdapterUpgradeable');
        KATOFTAdapterUpgradeable = await ethers.getContractFactory('KATOFTAdapterUpgradeable');
        const MyERC20Mock = await ethers.getContractFactory('MyERC20Mock');
        token = await MyERC20Mock.deploy('Test', 'TEST');
        const EndpointV2Mock = new ContractFactory(EndpointV2MockArtifact.abi, EndpointV2MockArtifact.bytecode, owner)
        endpoint = await EndpointV2Mock.deploy(1);
    })

    after(function() {
        // clean auto-generated deployment files
        existsSync('.deployments-test') && rmSync('.deployments-test', {recursive: true});
    })

    it('should upgrade', async () => {
        // Deploy proxy admin
        const { address: proxyAdminAddress } = await deployProxyAdmin({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [owner.address], // owner
                skipIfAlreadyDeployed: true,
            },
        })

        // Deploying the upgradeable contract
        const { address: implementationAddress } = await deployImplementation({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [token.address, endpoint.address],
                contract: contractName,
                skipIfAlreadyDeployed: true
            },
        })
        
        const initializeInterface = new ethers.utils.Interface(['function initialize(address delegate)'])
        const initializeData = initializeInterface.encodeFunctionData('initialize', [owner.address])
    
        const deployment = await deployProxy({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [implementationAddress, proxyAdminAddress, initializeData],
                skipIfAlreadyDeployed: true
            },
            deploymentName: contractName
        })
        const customOFTAdapter = KATCustomOFTAdapterUpgradeable.attach(deployment.address);

        // Make sure the contract has been initialized with the right implem
        let [isAdmin] = await customOFTAdapter.functions.hasRole(ethers.constants.HashZero, owner.address);
        expect(isAdmin).to.be.true
        let [isBridgeUser] = await customOFTAdapter.functions.isBridgeUser(owner.address);
        expect(isBridgeUser).to.be.false

        // Deploy the new implementation
        const { address: newImplementationAddress } = await deployImplementation({
            hre,
            deployOptions: {
                from: deployer.address,
                args: [token.address, endpoint.address],
                skipIfAlreadyDeployed: true,
                contract: 'KATOFTAdapterUpgradeable',
            },
        })

        // Upgrade the contract to the standard contract 
        const proxyAdmin = await ethers.getContractAt('ProxyAdmin', proxyAdminAddress)
        await proxyAdmin.upgrade(customOFTAdapter.address, newImplementationAddress);
        const oftAdapter = KATOFTAdapterUpgradeable.attach(deployment.address);

        // Ensure the implementation address are not the same
        expect(implementationAddress).to.not.equal(newImplementationAddress)
        // check that isBridgeUser does not exist anymore
        await expect(customOFTAdapter.functions.isBridgeUser(owner.address)).to.reverted;
        // Make sure the contract can still be interacted with and storage didn't change
        [isAdmin] = await oftAdapter.functions.hasRole(ethers.constants.HashZero, owner.address);
        expect(isAdmin).to.be.true;
        
        // Downgrade the contract to the custom adapter again
        await proxyAdmin.upgrade(oftAdapter.address, implementationAddress);
        // Ensure that the isBridgeUser function is accessible again
        await expect(customOFTAdapter.functions.isBridgeUser(owner.address)).to.not.reverted
    })
})
