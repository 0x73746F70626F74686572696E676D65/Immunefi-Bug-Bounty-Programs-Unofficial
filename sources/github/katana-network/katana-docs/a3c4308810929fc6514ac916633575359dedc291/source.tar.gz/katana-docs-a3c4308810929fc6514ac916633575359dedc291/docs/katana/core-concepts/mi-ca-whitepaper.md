<!-- # KAT MiCAR White Paper Page -->

Under Regulation (EU) 2023/1114 of the European Parliament and of the Council of 31 May 2023 on markets in crypto assets (MiCAR), crypto-assets offered to the public or of which admission to trading is sought in the EU must be accompanied by a compliant whitepaper duly notified to a National Competent Authority and published by the offeror or person seeking admission to trading at a reasonable time in advance of the relevant event.

This KAT MiCAR Whitepaper has been notified to the Central Bank of Ireland on November 26, 2025, and was published in accordance with Article 9 MiCAR on January 16, 2026. Amendments to the KAT MiCAR Whitepaper has been notified to the Central Bank of Ireland on March 9, 2026 and was published on March 18, 2026.

Based thereon, KAT has been effectively admitted to trading on the following trading platforms within the EU and/or EEA on March 18: Binance, OKX and Kraken.

<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; border: 1px solid; border-radius: 8px; padding: 16px;">
  <strong>
    Click <a href="/files/kat_whitepaper_latest.pdf" target="_blank" rel="noopener">here</a> to view the KAT Whitepaper
  </strong>
</div>

<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; border: 1px solid; border-radius: 8px; padding: 16px; margin-top: 16px;">
  <strong>
    Click <a href="/files/kat_whitepaper_admission_to_trading.xhtml" target="_blank" rel="noopener">here</a> to view the white paper for the Admission to Trading
  </strong>
</div>

<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; border: 1px solid; border-radius: 8px; padding: 16px; margin-top: 16px;">
  <strong>
    Click <a href="/files/kat_whitepaper_offering.xhtml" target="_blank" rel="noopener">here</a> to view the white paper for the Offering
  </strong>
</div>

Version: 1.0

Publication Date: January 16, 2026
