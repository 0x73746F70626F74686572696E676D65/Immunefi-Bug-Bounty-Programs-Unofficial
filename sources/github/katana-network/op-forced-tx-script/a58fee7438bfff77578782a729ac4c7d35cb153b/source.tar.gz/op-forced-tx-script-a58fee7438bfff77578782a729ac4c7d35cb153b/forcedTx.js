require("dotenv").config();
const { ethers } = require("ethers");
const PORTAL_ABI = require("./abi/portal");
const STORAGE_ABI = require("./abi/storage");
const STORAGE_BYTECODE = require("./utils/storage_bytecode");

// Configuration from .env file
const L1_RPC_URL = process.env.L1_RPC_URL;
const L2_RPC_URL = process.env.L2_RPC_URL;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const OPTIMISM_PORTAL = process.env.OPTIMISM_PORTAL;

async function deployStorageContractOnL2(l2Provider, wallet) {
    console.log("Step 1: Deploying Storage Contract on L2...");

    const l2Wallet = wallet.connect(l2Provider);

    // Deploy the storage contract
    const factory = new ethers.ContractFactory(STORAGE_ABI, STORAGE_BYTECODE, l2Wallet);
    const storageContract = await factory.deploy();
    await storageContract.waitForDeployment();

    const contractAddress = await storageContract.getAddress();
    console.log("✅ Storage contract deployed on L2 at:", contractAddress);

    // Verify initial state
    const initialValue = await storageContract.getValue();
    console.log("Initial storage value:", initialValue.toString());

    return contractAddress;
}

async function sendForcedTransaction(l1Provider, wallet, storageContractAddress, newValue) {
    console.log("Step 2: Sending Forced Transaction via L1 Portal...");

    const l1Wallet = wallet.connect(l1Provider);
    const portal = new ethers.Contract(OPTIMISM_PORTAL, PORTAL_ABI, l1Wallet);

    // Encode the setValue function call
    const storageInterface = new ethers.Interface(STORAGE_ABI);
    const setValueCalldata = storageInterface.encodeFunctionData("setValue", [newValue]);

    console.log("Calldata for setValue(" + newValue + "):", setValueCalldata);

    // Forced transaction params
    const params = {
        _to: storageContractAddress,
        _value: 0,
        _gasLimit: 100000,
        _isCreation: false,
        _data: setValueCalldata
    };

    console.log("Forced transaction parameters:", params);

    // Send the forced transaction
    const tx = await portal.depositTransaction(
        params._to,
        params._value,
        params._gasLimit,
        params._isCreation,
        params._data
    );

    console.log("✅ Sent forced transaction:", tx.hash);
    const receipt = await tx.wait();
    console.log("⛏️  Transaction mined in L1 block:", receipt.blockNumber);

    // Extract TransactionDeposited event
    const event = receipt.logs
        .map(log => {
            try {
                return portal.interface.parseLog(log);
            } catch {
                return null;
            }
        })
        .find(e => e && e.name === "TransactionDeposited");

    if (event) {
        console.log("TransactionDeposited event found");
        console.log("From:", event.args.from);
        console.log("To:", event.args.to);
        console.log("Version:", event.args.version.toString());
    } else {
        console.log("⚠️  TransactionDeposited event not found in logs");
    }

    return receipt;
}

async function verifyForcedTransaction(l2Provider, storageContractAddress, expectedValue) {
    console.log("Step 3: Verifying Forced Transaction Execution on L2...");

    const storageContract = new ethers.Contract(storageContractAddress, STORAGE_ABI, l2Provider);

    console.log("⏳ Waiting for forced transaction to be processed on L2...");

    let attempts = 0;
    const maxAttempts = 60; // Wait up to 5 minutes (60 * 5 seconds)

    while (attempts < maxAttempts) {
        try {
            const currentValue = await storageContract.getValue();
            console.log("Current storage value:", currentValue.toString());

            if (currentValue.toString() === expectedValue.toString()) {
                console.log("✅ SUCCESS: Forced transaction executed successfully!");
                console.log("✅ Storage value updated from 0 to", expectedValue.toString());
                return true;
            } else {
                console.log("⏳ Value not updated yet, waiting 5 seconds... (attempt " + (attempts + 1) + "/" + maxAttempts + ")");
            }
        } catch (error) {
            console.log("Error reading storage value:", error.message);
        }

        await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
        attempts++;
    }

    console.log("❌ TIMEOUT: Forced transaction was not processed within expected time");
    return false;
}

async function main() {
    if (!PRIVATE_KEY) {
        throw new Error("❌ PRIVATE_KEY environment variable is required");
    }

    console.log("Starting Forced Transaction Demo");
    console.log("====================================");

    // Initialize providers and wallet
    const l1Provider = new ethers.JsonRpcProvider(L1_RPC_URL);
    const l2Provider = new ethers.JsonRpcProvider(L2_RPC_URL);
    const wallet = new ethers.Wallet(PRIVATE_KEY);

    const senderAddress = await wallet.getAddress();
    console.log("Sender address:", senderAddress);
    console.log("L1 RPC:", L1_RPC_URL);
    console.log("L2 RPC:", L2_RPC_URL);
    console.log("Optimism Portal:", OPTIMISM_PORTAL);
    console.log("");

    try {
        // Step 1: Deploy storage contract on L2
        const storageContractAddress = await deployStorageContractOnL2(l2Provider, wallet);
        console.log("");

        // Step 2: Send forced transaction via L1 Portal
        const newValue = 42; // Value to set in storage
        await sendForcedTransaction(l1Provider, wallet, storageContractAddress, newValue);
        console.log("");

        // Step 3: Verify the forced transaction was executed
        const success = await verifyForcedTransaction(l2Provider, storageContractAddress, newValue);

        if (success) {
            console.log("");
            console.log("The forced transaction was sent via L1 Portal and executed on L2");
        } else {
            console.log("");
            console.log("The forced transaction may not have been processed correctly");
        }

    } catch (error) {
        console.error("❌ Error in main execution:", error);
        process.exit(1);
    }
}

main().catch((err) => {
    console.error("❌ Fatal error:", err);
    process.exit(1);
});
