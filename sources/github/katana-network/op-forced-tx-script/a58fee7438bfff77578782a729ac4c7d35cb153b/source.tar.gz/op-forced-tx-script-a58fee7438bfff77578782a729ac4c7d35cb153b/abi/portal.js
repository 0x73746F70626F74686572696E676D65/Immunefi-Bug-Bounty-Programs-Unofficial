// OptimismPortal ABI - key functions for forced transactions
const PORTAL_ABI = [
    {
        "inputs": [
            { "internalType": "address", "name": "_to", "type": "address" },
            { "internalType": "uint256", "name": "_value", "type": "uint256" },
            { "internalType": "uint64", "name": "_gasLimit", "type": "uint64" },
            { "internalType": "bool", "name": "_isCreation", "type": "bool" },
            { "internalType": "bytes", "name": "_data", "type": "bytes" }
        ],
        "name": "depositTransaction",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "anonymous": false,
        "inputs": [
            { "indexed": true, "internalType": "address", "name": "from", "type": "address" },
            { "indexed": true, "internalType": "address", "name": "to", "type": "address" },
            { "indexed": true, "internalType": "uint256", "name": "version", "type": "uint256" },
            { "indexed": false, "internalType": "bytes", "name": "opaqueData", "type": "bytes" }
        ],
        "name": "TransactionDeposited",
        "type": "event"
    },
    {
        "inputs": [],
        "name": "minimumGasLimit",
        "outputs": [{ "internalType": "uint64", "name": "", "type": "uint64" }],
        "stateMutability": "view",
        "type": "function"
    }
];

module.exports = PORTAL_ABI; 
