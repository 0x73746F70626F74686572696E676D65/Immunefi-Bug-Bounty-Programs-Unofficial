const BRIDGE_ABI = [
    {
        "inputs": [
            { "internalType": "address", "name": "_to", "type": "address" },
            { "internalType": "uint32", "name": "_l2Gas", "type": "uint32" },
            { "internalType": "bytes", "name": "_data", "type": "bytes" }
        ],
        "name": "depositETHTo",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "anonymous": false,
        "inputs": [
            { "indexed": true, "internalType": "address", "name": "from", "type": "address" },
            { "indexed": true, "internalType": "address", "name": "to", "type": "address" },
            { "indexed": false, "internalType": "uint256", "name": "amount", "type": "uint256" },
            { "indexed": false, "internalType": "bytes", "name": "data", "type": "bytes" }
        ],
        "name": "ETHBridgeInitiated",
        "type": "event"
    }
];

module.exports = BRIDGE_ABI; 
