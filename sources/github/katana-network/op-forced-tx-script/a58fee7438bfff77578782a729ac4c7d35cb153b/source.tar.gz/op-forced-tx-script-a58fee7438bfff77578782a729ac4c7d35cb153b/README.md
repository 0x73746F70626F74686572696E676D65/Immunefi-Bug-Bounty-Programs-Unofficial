# Optimism L1 ↔ L2 Bridge & Forced Transaction Scripts

Scripts for interacting with Optimism's Layer 2: ETH bridging and forced transactions via the Portal contract.

## 🚀 Quick Start

### Prerequisites
- Node.js (v16+)
- Local OP Stack deployment
- Test ETH on L1

### Setup
```bash
git clone <your-repo>
cd forced-deposit
npm install
```

Create a `.env` file with your configuration (see `.env.example`).

## 📋 Available Scripts

| Script | Command | Description |
|--------|---------|-------------|
| **ETH Bridge** | `npm run bridge-eth` | Bridge ETH from L1 to L2 via Standard Bridge |
| **Forced Transaction** | `npm run forced-tx` | Send forced transaction via L1 Portal (no ETH) |
| **Forced Transaction (with ETH)** | `npm run forced-tx-value` | Transfer ETH on L2 via forced transaction from L1 |
| **Forced Transaction (Fail Case)** | `npm run forced-tx-failcase` | Test forced transaction with insufficient funds |

---

## 🌉 ETH Bridge (`depositEthTo.js`)

Bridges ETH from L1 to L2 using the L1StandardBridge contract.

**Usage**: `npm run bridge-eth`

**Features**: Monitors bridge events, verifies L2 balance updates, computes cross-domain message hashes.

---

## 💪 Forced Transaction Scripts

### 1. Basic Forced Transaction (`forcedTx.js`)

Sends a forced transaction via L1 Portal to execute on L2 (no ETH transfer).

**Usage**: `npm run forced-tx`

**Flow**: Deploy storage contract on L2 → Send forced tx from L1 → Verify execution on L2

---

### 2. Forced Transaction with ETH Transfer (`forcedTx_value.js`)

**Purpose**: Transfer ETH on L2 from one address to another via a forced transaction sent on L1.

**How it works**:
1. Forced transaction is sent to L1 Portal
2. The inner transaction (processed on L2) transfers ETH to the target address
3. Verifies both contract state and balance changes on L2

**Usage**: `npm run forced-tx-value`

**Configuration**:
```javascript
const AMOUNT_ETH = "0.001"; // ETH amount to transfer on L2
```

**Key Points**:
- Forced transaction sent on **L1** via Portal
- Inner transaction executes on **L2** and transfers ETH
- Verifies ETH was received at the target address on L2
- Uses separate ABI/bytecode files (`./abi/storage`, `./utils/storage_bytecode`)

**When to Use**: When you need to transfer ETH on L2 from one address to another using a forced transaction initiated on L1.

---

### 3. Forced Transaction Fail Case (`forcedTx_value_failcase.js`)

**Purpose**: Demonstrate forced transaction inclusion even when the transaction fails due to insufficient funds on L2.

**How it works**:
1. Creates a second wallet (wallet2) with a random private key
2. Transfers ETH from wallet1 to wallet2 on L1
3. Wallet2 sends a forced transaction via L1 Portal to transfer ETH to a random address
4. The transaction is **processed on L2 but fails** (wallet2 has 0 ETH on L2 for gas)
5. Verifies the transaction was included and processed on L2 (even though it failed)

**Usage**: `npm run forced-tx-failcase`

**Key Points**:
- Demonstrates **forced inclusion**: transactions are included on L2 even if they fail
- Wallet2 has ETH on L1 but 0 ETH on L2
- The forced transaction is processed on L2 but fails due to insufficient gas
- Verification checks for transaction presence (not just success)
- Proves that forced transactions bypass the sequencer and are guaranteed inclusion

**When to Use**: When testing that forced transactions are always included on L2, regardless of whether they succeed or fail. This is crucial for understanding censorship resistance in Optimism.

