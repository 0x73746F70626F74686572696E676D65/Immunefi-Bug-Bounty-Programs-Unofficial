require("dotenv").config();
const { ethers } = require("ethers");
const BRIDGE_ABI = require("./abi/bridge");
const MESSENGER_ABI = require("./abi/messenger");

const L1_RPC_URL = process.env.L1_RPC_URL;
const L2_RPC_URL = process.env.L2_RPC_URL;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const L1_STANDARD_BRIDGE = process.env.L1_STANDARD_BRIDGE;
const RECIPIENT_ON_L2 = process.env.RECIPIENT_ON_L2;

const AMOUNT_ETH = "0.00005";
const L2_GAS_LIMIT = 1_500_000;

async function main() {
    const l1Provider = new ethers.JsonRpcProvider(L1_RPC_URL);
    const l2Provider = new ethers.JsonRpcProvider(L2_RPC_URL);
    const wallet = new ethers.Wallet(PRIVATE_KEY, l1Provider);
    const sender = await wallet.getAddress();

    console.log("Sender (L1):", sender);
    console.log("Recipient (L2):", RECIPIENT_ON_L2);

    const bridge = new ethers.Contract(L1_STANDARD_BRIDGE, BRIDGE_ABI, wallet);

    // Send depositETHTo transaction
    const tx = await bridge.depositETHTo(
        RECIPIENT_ON_L2,
        L2_GAS_LIMIT,
        "0x",
        { value: ethers.parseEther(AMOUNT_ETH) }
    );

    console.log("✅ Sent depositETHTo tx:", tx.hash);
    const receipt = await tx.wait(1, 60000);
    console.log("⛏️  Tx mined in block", receipt.blockNumber);

    // Extract ETHBridgeInitiated log
    const event = receipt.logs
        .map(log => {
            try {
                return bridge.interface.parseLog(log);
            } catch {
                return null;
            }
        })
        .find(e => e && e.name === "ETHBridgeInitiated");

    if (!event) {
        throw new Error("❌ ETHBridgeInitiated event not found");
    }

    const { from, to, amount, data } = event.args;
    console.log("Bridge log: from", from, "to", to, "amount", ethers.formatEther(amount));

    // Compute xDomain calldata hash
    const xDomainData = ethers.solidityPacked(
        ["address", "address", "bytes", "uint256"],
        [from, to, data, BigInt(0)] // nonce is 0 on depositETHTo in local devnets
    );

    const messageHash = ethers.keccak256(xDomainData);
    console.log("Message hash:", messageHash);

    // Check L2 balance change to verify transaction success
    const initialL2Balance = await l2Provider.getBalance(RECIPIENT_ON_L2);
    console.log("Initial L2 Balance of recipient:", ethers.formatEther(initialL2Balance), "ETH");
    console.log("--------------------------------")
    console.log("")

    const expectedAmount = ethers.parseEther(AMOUNT_ETH);

    while (true) {
        const currentL2Balance = await l2Provider.getBalance(RECIPIENT_ON_L2);
        const balanceDifference = currentL2Balance - initialL2Balance;

        if (balanceDifference == expectedAmount) {
            console.log("✅ Transaction successfully processed on L2");
            console.log("Final L2 Balance of recipient:", ethers.formatEther(currentL2Balance), "ETH");
            console.log("Balance increased by:", ethers.formatEther(balanceDifference), "ETH");
            break;
        } else {
            console.log("⏳ Transaction not yet processed on L2. Current balance:", ethers.formatEther(currentL2Balance), "ETH");
            console.log("Checking again in 5 seconds...");
            console.log("")

            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

main().catch((err) => {
    console.error("❌ Error:", err);
    process.exit(1);
});
