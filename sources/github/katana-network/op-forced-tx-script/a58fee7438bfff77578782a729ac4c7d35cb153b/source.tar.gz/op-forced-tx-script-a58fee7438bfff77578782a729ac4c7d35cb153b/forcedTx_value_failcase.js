require("dotenv").config();
const { ethers } = require("ethers");
const PORTAL_ABI = require("./abi/portal");

// Configuration from .env file
const L1_RPC_URL = process.env.L1_RPC_URL;
const L2_RPC_URL = process.env.L2_RPC_URL;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const OPTIMISM_PORTAL = process.env.OPTIMISM_PORTAL;

const AMOUNT_ETH = "0.000001231";

async function sendForcedTransaction(l1Provider, wallet, targetAddress) {
    console.log("Step 1: Sending Forced Transaction via L1 Portal...");

    const l1Wallet = wallet.connect(l1Provider);
    const portal = new ethers.Contract(OPTIMISM_PORTAL, PORTAL_ABI, l1Wallet);

    // Forced transaction params - just sending ETH with no calldata
    const params = {
        _to: targetAddress,
        _value: ethers.parseEther(AMOUNT_ETH),
        _gasLimit: 100000,
        _isCreation: false,
        _data: "0x" // Empty calldata
    };

    console.log("Forced transaction parameters:");
    console.log("  Target address:", params._to);
    console.log("  ETH value:", AMOUNT_ETH);
    console.log("  Gas limit:", params._gasLimit);

    // Send the forced transaction
    const tx = await portal.depositTransaction(
        params._to,
        params._value,
        params._gasLimit,
        params._isCreation,
        params._data
    );

    console.log("✅ Sent forced transaction:", tx.hash);
    const receipt = await tx.wait();
    console.log("⛏️  Transaction mined in L1 block:", receipt.blockNumber);

    // Extract TransactionDeposited event
    const event = receipt.logs
        .map(log => {
            try {
                return portal.interface.parseLog(log);
            } catch {
                return null;
            }
        })
        .find(e => e && e.name === "TransactionDeposited");

    if (event) {
        console.log("TransactionDeposited event found");
        console.log("  From:", event.args.from);
        console.log("  To:", event.args.to);
        console.log("  Version:", event.args.version.toString());
    } else {
        console.log("⚠️  TransactionDeposited event not found in logs");
    }

    return receipt;
}

async function verifyForcedTransaction(l2Provider, targetAddress, expectedAmount, depositTxHash) {
    console.log("Step 2: Verifying Forced Transaction was Processed on L2...");

    console.log("⏳ Waiting for forced transaction to be processed on L2...");

    const initialBalance = await l2Provider.getBalance(targetAddress);
    console.log("Initial balance of target address:", ethers.formatEther(initialBalance), "ETH");

    let attempts = 0;
    const maxAttempts = 60; // Wait up to 5 minutes (60 * 5 seconds)
    let depositTxFound = false;
    let lastCheckedBlock = await l2Provider.getBlockNumber();

    while (attempts < maxAttempts) {
        try {
            // Check recent blocks for deposit transactions
            const currentBlock = await l2Provider.getBlockNumber();
            console.log(`Checking L2 blocks from ${lastCheckedBlock} to ${currentBlock}`);

            // Check all blocks from lastCheckedBlock to currentBlock (don't skip any)
            for (let blockNum = lastCheckedBlock; blockNum <= currentBlock; blockNum++) {
                if (blockNum < 0) continue;

                console.log(`Checking L2 block: ${blockNum}`);

                const block = await l2Provider.getBlock(blockNum, true);
                if (block && block.transactions) {
                    console.log(`Found ${block.transactions.length} transactions in block ${blockNum}`);
                    for (const txOrHash of block.transactions) {
                        // If transaction is a string (hash), fetch the full transaction
                        const tx = typeof txOrHash === 'string'
                            ? await l2Provider.getTransaction(txOrHash)
                            : txOrHash;

                        if (!tx) {
                            console.log(`  ⚠️  Could not fetch transaction`);
                            continue;
                        }

                        if (typeof tx === 'object' && tx.from) {
                            // Check if transaction is type 126 (deposit transaction) with specific value
                            const txType = tx.type;
                            const txValue = tx.value;

                            // Convert value to BigInt for comparison
                            const txValueBigInt = typeof txValue === 'bigint' ? txValue : BigInt(txValue || 0);
                            const expectedValue = ethers.parseEther(AMOUNT_ETH);

                            console.log(`    Type Match: ${txType === 126}`);
                            console.log(`    Value Match: ${txValueBigInt === expectedValue}`);

                            // Check for type 126 (deposit tx) with AMOUNT_ETH value
                            if (txType === 126 && txValueBigInt === expectedValue) {
                                console.log("\n✅ MATCH FOUND!");
                                const receipt = await l2Provider.getTransactionReceipt(tx.hash);
                                if (receipt) {
                                    console.log("\n🔍 Found deposit transaction (Type 126) on L2!");
                                    console.log("  Tx Hash:", tx.hash);
                                    console.log("  Type:", txType);
                                    console.log("  Value:", ethers.formatEther(txValueBigInt), "ETH");
                                    console.log("  From:", tx.from);
                                    console.log("  To:", receipt.to);
                                    console.log("  Block:", receipt.blockNumber);
                                    console.log("  Status:", receipt.status === 1 ? "SUCCESS" : "FAILED");
                                    console.log("  Gas Used:", receipt.gasUsed.toString());

                                    depositTxFound = true;

                                    if (receipt.status === 0) {
                                        console.log("\n⚠️  Transaction was PROCESSED but FAILED on L2");
                                        console.log("This is expected - wallet2 has 0 ETH on L2 to pay for gas");
                                        return { found: true, succeeded: false, receipt };
                                    } else {
                                        console.log("\n✅ Transaction SUCCEEDED on L2");
                                        return { found: true, succeeded: true, receipt };
                                    }
                                }
                            } else {
                                console.log("    ❌ No match");
                            }
                        }
                    }
                }
            }

            // Also check balance change as secondary verification
            const currentBalance = await l2Provider.getBalance(targetAddress);
            const balanceDiff = currentBalance - initialBalance;

            if (balanceDiff >= ethers.parseEther(expectedAmount)) {
                console.log("✅ SUCCESS: Target address received ETH!");
                console.log("✅ Received:", ethers.formatEther(balanceDiff), "ETH");
                return { found: true, succeeded: true };
            }

            if (!depositTxFound) {
                console.log(`⏳ Deposit transaction not found yet, waiting 5 seconds... (attempt ${attempts + 1}/${maxAttempts})`);
                console.log(`   Current balance: ${ethers.formatEther(currentBalance)} ETH`);
            }

            // Update lastCheckedBlock to avoid rechecking the same blocks
            lastCheckedBlock = currentBlock + 1;

        } catch (error) {
            console.log("Error checking L2:", error.message);
        }

        await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
        attempts++;
    }

    console.log("\n❌ TIMEOUT: Could not find deposit transaction on L2 within expected time");
    return { found: false, succeeded: false };
}

async function main() {
    if (!PRIVATE_KEY) {
        throw new Error("❌ PRIVATE_KEY environment variable is required");
    }

    console.log("Starting Forced Transaction Demo");
    console.log("====================================");

    // Initialize providers and wallet
    const l1Provider = new ethers.JsonRpcProvider(L1_RPC_URL);
    const l2Provider = new ethers.JsonRpcProvider(L2_RPC_URL);
    const wallet = new ethers.Wallet(PRIVATE_KEY);

    const senderAddress = await wallet.getAddress();
    console.log("Wallet 1 address:", senderAddress);

    // Create wallet2 with a new random private key
    const wallet2 = ethers.Wallet.createRandom();
    const wallet2Address = await wallet2.getAddress();
    console.log("Wallet 2 address (new):", wallet2Address);

    // Connect wallet to L1 provider
    const wallet1L1 = wallet.connect(l1Provider);

    // Check wallet 1 balance on L1
    const wallet1L1Balance = await l1Provider.getBalance(senderAddress);
    console.log("Wallet 1 L1 Balance:", ethers.formatEther(wallet1L1Balance), "ETH");

    // Transfer ETH from wallet to wallet2 on L1
    console.log("\n💸 Transferring ETH from Wallet 1 to Wallet 2 on L1...");
    const transferAmount = ethers.parseEther("0.0005"); // Send 0.0005 ETH
    const transferTx = await wallet1L1.sendTransaction({
        to: wallet2Address,
        value: transferAmount
    });
    console.log("Transfer tx hash:", transferTx.hash);
    await transferTx.wait();
    console.log("✅ Transfer completed on L1");

    // Check wallet2 balance on L1
    const wallet2L1Balance = await l1Provider.getBalance(wallet2Address);
    console.log("Wallet 2 L1 Balance after transfer:", ethers.formatEther(wallet2L1Balance), "ETH");

    console.log("\nL1 RPC:", L1_RPC_URL);
    console.log("L2 RPC:", L2_RPC_URL);
    console.log("Optimism Portal:", OPTIMISM_PORTAL);
    console.log("");

    try {
        // Create a random target address to receive ETH on L2
        const randomWallet = ethers.Wallet.createRandom();
        const targetAddress = await randomWallet.getAddress();
        console.log("Random target address (to receive ETH on L2):", targetAddress);
        console.log("");

        // Step 1: Send forced transaction via L1 Portal using wallet2
        const depositReceipt = await sendForcedTransaction(l1Provider, wallet2, targetAddress);
        console.log("");

        // Step 2: Verify the forced transaction was executed
        const result = await verifyForcedTransaction(l2Provider, targetAddress, AMOUNT_ETH, depositReceipt.hash);

        console.log("");
        if (result.found && result.succeeded) {
            console.log("✅ UNEXPECTED: The forced transaction succeeded on L2");
            console.log("This should NOT happen since wallet2 has 0 ETH on L2");
        } else if (result.found && !result.succeeded) {
            console.log("✅ EXPECTED BEHAVIOR: The forced transaction was PROCESSED but FAILED on L2");
            console.log("Reason: wallet2 has 0 ETH on L2 to pay for gas");
            console.log("This demonstrates that forced transactions are included even if they fail");
        } else {
            console.log("❌ Could not verify if the forced transaction was processed");
        }

    } catch (error) {
        console.error("❌ Error in main execution:", error);
        process.exit(1);
    }
}

main().catch((err) => {
    console.error("❌ Fatal error:", err);
    process.exit(1);
});
