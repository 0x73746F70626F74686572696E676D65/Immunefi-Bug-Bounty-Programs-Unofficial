//SPDX-License-Identifier: GPL-3.0
pragma solidity ^0.8.0;

interface IStakeManager {
    struct BotUndelegateRequest {
        uint256 startTime;
        uint256 endTime;
        uint256 amount;
        uint256 amountInSnBnb;
    }

    struct WithdrawalRequest {
        uint256 uuid;
        uint256 amountInSnBnb;
        uint256 startTime;
    }

    struct UserRequest {
        uint256 uuid;
        uint256 amount;
        uint256 amountInSlisBnb;
        uint256 totalAmount;
        uint256 totalAmountInSlisBnb;
    }

    function initialize(
        address _slisBnb,
        address _admin,
        address _manager,
        address _bot,
        uint256 _feeBps,
        address _revenuePool,
        address _validator,
        uint256 _bufferSizePct
    ) external;

    function deposit() external payable;

    function delegateTo(address validator, uint256 amount) external;

    function redelegate(address srcValidator, address dstValidator, uint256 shares) external;

    function redelegateShares(address srcValidator, address dstValidator, uint256 shares) external;

    function requestWithdraw(uint256 _amountInSnBnb) external;

    function claimWithdraw(uint256 _idx) external;

    function claimWithdrawFor(address _user, uint256 _idx) external;

    function undelegateFrom(address _operator, uint256 _amount) external returns (uint256 _actualBnbAmount);

    function undelegateSharesFrom(address _operator, uint256 _shares) external returns (uint256 _actualBnbAmount);

    function claimUndelegated(address _validator) external returns (uint256, uint256);

    function delegateVoteTo(address _delegateTo) external;

    function binarySearchCoveredMaxIndex(uint256 _bnbAmount) external returns (uint256);

    function depositReserve() external payable;

    function withdrawReserve(uint256) external;

    function setReserveAmount(uint256) external;

    function setSynFee(uint256 _synFee) external;

    function setRevenuePool(address _address) external;

    function setMinBnb(uint256 _minBnb) external;

    function getTotalPooledBnb() external view returns (uint256);

    function setRedirectAddress(address _address) external;

    function whitelistValidator(address _address) external;

    function disableValidator(address _address) external;

    function removeValidator(address _address) external;

    function setBufferSizePct(uint256 _bufferSizePct) external;

    function setInstantWithdrawFeeRate(uint256 _feeRate) external;

    function setInstantWhitelist(address _user, bool _status) external;

    function setInstantWhitelistOff(bool _off) external;

    function getBotUndelegateRequest(uint256 _uuid) external view returns (BotUndelegateRequest memory);

    function getUserWithdrawalRequests(address _address) external view returns (WithdrawalRequest[] memory);

    function getUserRequestStatus(address _user, uint256 _idx)
        external
        view
        returns (bool _isClaimable, uint256 _amount);

    function getSlisBnbWithdrawLimit() external view returns (uint256 _slisBnbWithdrawLimit);

    function getAmountToUndelegate() external view returns (uint256);

    function getDelegated(address validator) external view returns (uint256);

    function convertSharesToBnb(address _operator, uint256 _shares) external view returns (uint256);

    function convertBnbToShares(address _operator, uint256 _bnbAmount) external view returns (uint256);

    function convertBnbToSnBnb(uint256 _amount) external view returns (uint256);

    function convertSnBnbToBnb(uint256 _amountInSlisBnb) external view returns (uint256);

    function getClaimableAmount(address _validator) external view returns (uint256 _amount);

    function compoundRewards() external;

    function refundCommission(uint256 _days) external payable;

    function getTotalBnbInValidators() external returns (uint256);

    function getRedelegateFee(uint256 bnbAmount) external view returns (uint256);

    function skipDelegateOrNot(uint256 _amount)
        external
        view
        returns (bool skipDelegate, uint256 maxBufferSize, uint256 currBufferSize);

    event Deposit(address _src, uint256 _amount);
    event DelegateTo(address _validator, uint256 _amount, bool _delegateVotePower);
    event ReDelegate(address _src, address _dest, uint256 _amount);
    event RequestWithdraw(address indexed _account, uint256 _amountInSlisBnb);
    event ClaimWithdrawal(address indexed _account, uint256 _idx, uint256 _amount);
    event UndelegateFrom(address indexed _operator, uint256 _bnbAmount, uint256 _shares);
    event Redelegate(uint256 _rewardsId, uint256 _amount);
    event SetManager(address indexed _address);
    event SetSynFee(uint256 _synFee);
    event SetRedirectAddress(address indexed _address);
    event SetRevenuePool(address indexed _address);
    event RewardsCompounded(uint256 _amount);
    event SetReserveAmount(uint256 _amount);
    event ClaimUndelegatedFrom(address indexed _validator, uint256 _uuid, uint256 _amount);
    event WhitelistValidator(address indexed _address);
    event DisableValidator(address indexed _address);
    event RemoveValidator(address indexed _address);
    event SyncCreditContract(address indexed _validator, address _credit, bool toRemove);
    event SetMinBnb(uint256 _minBnb);
    event DelegateVoteTo(address _delegateTo, uint256 _votesChange);
    event SetSubStaker(address indexed _subStaker);
    event SetSubValidator(address indexed _validator, bool _toSub);
    event RefundCommission(uint256 _bnbAmount, uint256 _dailySlisBnb, uint256 _days, uint256 _remainingSlisBnb);
    event InstantWithdraw(address indexed _user, uint256 _slisBnbAmount, uint256 _bnbAmountAfterFee, uint256 _fee);
    event ClaimWithdrawFee(address indexed _recipient, uint256 _amount);
    event SetBufferSizePct(uint256 _bufferSizePct);
    event SetInstantWithdrawFeeRate(uint256 _feeRate);
    event SetInstantWhitelist(address indexed _user, bool _status);
    event SetInstantWhitelistOff(bool _off);
}
