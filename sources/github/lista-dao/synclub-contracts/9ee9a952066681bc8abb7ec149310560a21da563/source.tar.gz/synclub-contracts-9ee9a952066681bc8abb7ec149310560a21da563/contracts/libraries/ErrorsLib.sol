//SPDX-License-Identifier: GPL-3.0
pragma solidity 0.8.4;

library ErrorsLib {
    error ZeroAddress();
    error InvalidAddress();
    error InvalidAmount();
    error InvalidSlisBnbAmount();
    error InactiveValidator();
    error NotEnoughBnb();
    error NotEnoughFee();
    error AmountTooSmall();
    error BufferTooSmall();
    error AmountTooLarge();
    error InvalidSynFee();
    error UnclaimableRequest();
    error NotWhitelisted();
    error AlreadySet();
    error SubStakerNotDrained();
    error NotTimelock();
}
