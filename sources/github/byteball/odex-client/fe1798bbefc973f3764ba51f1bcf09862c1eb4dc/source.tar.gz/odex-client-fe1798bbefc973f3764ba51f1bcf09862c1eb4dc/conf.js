/*jslint node: true */
"use strict";
exports.port = null;
//exports.myUrl = 'wss://mydomain.com/bb';
exports.bServeAsHub = false;
exports.bLight = true;

exports.storage = 'sqlite';

// TOR is recommended. Uncomment the next two lines to enable it
//exports.socksHost = '127.0.0.1';
//exports.socksPort = 9050;

exports.hub = process.env.testnet ? 'obyte.org/bb-test' : 'obyte.org/bb';
exports.deviceName = 'ODEX client';
exports.permanent_pairing_secret = '0000'; // * allows to pair with any code, the code is passed as 2nd param to the pairing event handler
exports.control_addresses = [''];
exports.payout_address = 'WHERE THE MONEY CAN BE SENT TO';

exports.bIgnoreUnpairRequests = true;
exports.bSingleAddress = true;
exports.bStaticChangeAddress = true;
exports.KEYS_FILENAME = 'keys.json';

exports.bNoPassphrase = true;

// emails
exports.admin_email = '';
exports.from_email = '';

// set owner_address if this bot is trading on behalf of another account. In this case, the bot can trade but is not allowed to withdraw funds. If owner_address is not set, the bot is trading its own money and has full access.
exports.owner_address = '';

// websocket URL of ODEX node we are are connecting to
const testnet_domain = process.env.testnet ? 'testnet.' : '';
exports.odex_ws_url = 'wss://' + testnet_domain + 'odex.ooo/socket';
exports.odex_http_url = 'https://' + testnet_domain + 'odex.ooo/api';

exports.MAX_PRICE_PRECISION = 8;
exports.aa_address = 'ODEX5NGJKLKAWJYJ7JILB6AQQKOCJ34W';
