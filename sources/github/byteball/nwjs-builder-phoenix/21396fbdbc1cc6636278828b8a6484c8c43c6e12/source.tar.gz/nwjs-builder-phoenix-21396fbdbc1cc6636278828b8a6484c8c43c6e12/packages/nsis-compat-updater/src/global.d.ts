
declare const nw: any;
