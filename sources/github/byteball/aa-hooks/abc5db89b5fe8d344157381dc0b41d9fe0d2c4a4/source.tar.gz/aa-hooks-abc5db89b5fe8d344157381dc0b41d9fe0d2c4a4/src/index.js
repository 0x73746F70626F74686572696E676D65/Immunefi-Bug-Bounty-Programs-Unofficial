const Hooks = require('./hooks');

module.exports.Hooks = Hooks;
