import { ethers } from "ethers";

import { nativeSymbols } from "nativeSymbols";
import config from "appConfig";

import { Cache } from "./Cache";

const environment = config.ENVIRONMENT;

const cache_lifetime = 10 * 60 * 1000; // 10 minutes

// Only the short-lived, in-memory cache the file always had: callers go through
// services/prices, which persists whatever these APIs answer.
const cache = new Cache(cache_lifetime);

// `name` keeps the cache key stable: func.name gets mangled by the minifier, which risks two
// functions sharing one key.
function cachify(func, count_args, name) {
  return async function () {
    const cached = arguments[count_args]; // the last arg is optional
    const args = [];
    for (let i = 0; i < count_args; i++) // not including the 'cached' arg
      args[i] = arguments[i];
    const key = (name || func.name) + '_' + args.join(',');
    if (cached) {
      const value = cache.get(key);
      if (value !== null) {
        return value;
      }
    }
    const value = await func.apply(null, args);
    cache.put(key, value);
    return value
  }
}

const request = async (url, options) => {
  const response = await fetch(url, {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    ...options
  })
  if (!response.ok) {
    const error = await response.text()
    console.error('-- error', error)
    throw new Error(error)
  }
  const data = await response.json()
  return data
}

export const fetchERC20ExchangeRate = async (chain, token_address, quote) => {
  if (environment !== "mainnet") {
    if (token_address === '0x4DBCdF9B62e891a7cec5A2568C3F4FAF9E8Abe2b') // USDC rinkeby
      token_address = '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';
    else if (token_address === '0xbF7A7169562078c96f0eC1A8aFD6aE50f12e5A99') // BAT rinkeby
      token_address = '0x0D8775F648430679A709E98d2b0Cb6250d2887EF';
    else if (token_address === '0xeD24FC36d5Ee211Ea25A80239Fb8C4Cfd80f12Ee') // BUSD testnet
      token_address = '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56';
    else if (token_address === '0x43D8814FdFB9B8854422Df13F1c66e34E4fa91fD') // Kava USDC testnet
			token_address = '0xfA9343C3897324496A05fC75abeD6bAC29f8A40f';
    else if (token_address === '0xB554fCeDb8E4E0DFDebbE7e58Ee566437A19bfB2') // DAI devnet
      token_address = '0x6b175474e89094c44da98b954eedeac495271d0f';
    else
      return undefined;
  }
  const data = await request(`https://api.coingecko.com/api/v3/coins/${chain}/contract/${token_address.toLowerCase()}`)
  const prices = data.market_data.current_price

  quote = quote.toLowerCase()
	if (!prices[quote]) {
		if (!prices.usd)
			throw new Error(`no ${quote} and no usd in response ${JSON.stringify(data)}`);
		const quote_price_in_usd = await fetchCoingeckoExchangeRateCached(quote, 'USD', true);
		return prices.usd / quote_price_in_usd;
	}
  return prices[quote]
}

// CoinGecko addresses coins by its own ids, not by ticker
const coingeckoCoinIds = {
  GBYTE: 'byteball',
  ETH: 'ethereum',
  BNB: 'binancecoin',
  MATIC: 'matic-network',
  KAVA: 'kava',
};

export const fetchCoingeckoExchangeRate = async (in_currency, out_currency) => {
  const id = coingeckoCoinIds[in_currency.toUpperCase()];
  if (!id)
    throw new Error(`no CoinGecko id for ${in_currency}`);
  const vs = out_currency.toLowerCase();
  const data = await request(`https://api.coingecko.com/api/v3/simple/price?ids=${id}&vs_currencies=${vs}`)
  if (!data?.[id]?.[vs])
    throw new Error(`no ${out_currency} in CoinGecko response ${JSON.stringify(data)}`);
  return data[id][vs]
}

export const fetchObyteTokenPrices = async () => {
  const data = await request(environment === "mainnet" ? "https://referrals.ostable.org/prices" : "https://testnet.ostable.org/r/prices");
  const prices = data.data
  if (!prices)
    throw Error(`no prices from referrals ${data.error}`);
  return prices
}


const fetchERC20ExchangeRateCached = cachify(fetchERC20ExchangeRate, 3, 'erc20')
const fetchCoingeckoExchangeRateCached = cachify(fetchCoingeckoExchangeRate, 2, 'coingecko')
const fetchObyteTokenPricesCached = cachify(fetchObyteTokenPrices, 0, 'obytePrices')

const coingeckoChainIds = {
  Ethereum: 'ethereum',
  BSC: 'binance-smart-chain',
  Polygon: 'polygon-pos',
  Kava: 'kava',
};

async function tryGetTokenPrice(network, token_address, nativeSymbol, cached) {
  switch (network) {
    case 'Ethereum':
    case 'BSC':
    case 'Polygon':
    case 'Kava':
      try {
        const chain = coingeckoChainIds[network];
        return await fetchERC20ExchangeRateCached(chain, token_address, nativeSymbol, cached);
      }
      catch (e) {
        console.log(`fetchERC20ExchangeRate for ${network} ${token_address}/${nativeSymbol} failed`, e);
      }
      break;
    
    default: {
      break;
    }
  }
  return null;
}

export const fetchExchangeRateInUSD = async (network, asset, cached) => {
  try {
    if (network === 'Obyte') {
      if (asset === 'base')
        return await fetchCoingeckoExchangeRateCached('GBYTE', 'USD', cached);
      const prices = await fetchObyteTokenPricesCached(cached);
      const price_in_usd = prices[asset];
      return price_in_usd || null;
    }
    if (asset === ethers.constants.AddressZero)
      return await fetchCoingeckoExchangeRateCached(nativeSymbols[network], 'USD', cached);
    return await tryGetTokenPrice(network, asset, 'USD', cached);
  } catch (e) {
    console.error('fetchExchangeRateInUSD error', e);
    return 0;
  }
}