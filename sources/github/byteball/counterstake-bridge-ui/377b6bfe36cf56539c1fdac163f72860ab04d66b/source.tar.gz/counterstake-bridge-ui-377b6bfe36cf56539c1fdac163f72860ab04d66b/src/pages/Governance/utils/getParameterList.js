import { ethers } from "ethers";
import { isNaN } from "lodash";
import obyte from "obyte";
import config from "appConfig";

const environment = config.ENVIRONMENT;
const f = (x) => (~(x + "").indexOf(".") ? (x + "").split(".")[1].length : 0);

export const getParameterList = (network) => ({
  ratio: {
    name: "ratio",
    evm_name: "ratio100",
    type: "uint",
    description: "The ratio between the stake and the claimed amount.",
    rule: "The value of the ratio parameter must be between 0.1 and 10",
    initValue: 1,
    validator: value => value >= 0.1 && value <= 10
  },
  counterstake_coef: {
    name: "counterstake_coef",
    evm_name: "counterstake_coef100",
    type: "uint",
    description: "How much the stake grows in each subsequent challenging period.",
    rule: "The value of the counterstake_coef parameter must be greater than to 1",
    initValue: 1.5,
    validator: value => value > 1
  },
  min_tx_age: {
    name: "min_tx_age",
    type: "uint",
    description: "Minimum transaction age in seconds before it can be claimed.",
    rule: "The value of the min_tx_age parameter must be integer greater than or equal to 0",
    initValue: network === "Obyte" ? 30 : 0,
    validator: value => value >= 0
  },
  min_stake: {
    name: "min_stake",
    type: "uint",
    description: "Minimum stake amount.",
    rule: "The value of the min_stake parameter must be integer greater than or equal to 0",
    initValue: network === "Obyte" ? 100000 : 0,
    validator: (value, { stakeTokenDecimals = 0 }) => value >= 0 && f(value) <= stakeTokenDecimals
  },
  large_threshold: {
    name: "large_threshold",
    type: "uint",
    description: "The threshold amount that makes a stake “large” and triggers longer challenging periods.",
    rule: "The value of the large_threshold parameter must be integer greater than or equal to 0",
    initValue: network === "Obyte" ? 100000000 : 0,
    validator: (value, meta = {}) => {
      const { stakeTokenDecimals = 0 } = meta;
      return value >= 0 && f(value) <= stakeTokenDecimals;
    }
  },
  challenging_periods: {
    name: "challenging_periods",
    type: "unitArray",
    description: "Challenging periods (in hours) for regular amounts.",
    rule: "The value of the challenging_periods parameter must be Array of numbers, each at least 24 (hours). Numbers must be separated by a space and each of the numbers must be larger than the previous one. Example: 72 168 720 1440",
    initValue: environment === "mainnet" ? [72, 168, 720, 1440] : [0.1, 0.2, 0.5, 1],
    validator: value => is_valid_challenging_periods_string(value, network)
  },
  large_challenging_periods: {
    name: "large_challenging_periods",
    type: "unitArray",
    description: "Challenging periods (in hours) for large amounts.",
    rule: "The value of the large_challenging_periods parameter must be Array of numbers, each at least 24 (hours). Numbers must be separated by a space and each of the numbers must be larger than the previous one. Example: 168 720 1440 2160",
    initValue: environment === "mainnet" ? [168, 720, 1440, 2160] : [0.2, 0.3, 0.7, 1.5],
    validator: value => is_valid_challenging_periods_string(value, network)
  },
  min_price: {
    name: "min_price",
    evm_name: "min_price20",
    type: "uint",
    description: "Minimum price of foreign asset in terms of stake asset. This overrides the price reported by the oracle if it is lower than the minimum and is meant to protect against malfunctioning oracle reporting a very low price.",
    rule: "The value of the min_price parameter must be integer greater than or equal to 0",
    initValue: 0,
    importOnly: true,
    validator: value => value >= 0
  },
  oracles: {
    name: "oracle",
    evm_name: "oracleAddress",
    type: "address",
    description: "Oracles that report the price of foreign asset in terms of stake asset.",
    rule: network === "Obyte"
      ? "Up to 3 oracles formatted as ADDRESS*FEED_NAME or ADDRESS/FEED_NAME separated by space"
      : `The value of the oracle parameter must be a valid ${network} address`,
    initValue: 1,
    importOnly: true,
    validator: value => is_valid_oracle_string(value, network)
  }
});

export const is_valid_challenging_periods_string = (value) => {
  const valueFormatted = value.split(" ");

  if (valueFormatted.length > 20) return false;
  let isError = false;
  let prev = -1;

  valueFormatted?.forEach((period) => {
    if (isNaN(Number(period))) return isError = true;

    const nPeriod = Number(period);

    if (nPeriod < 24 || (nPeriod > 3 * 365 * 24)) isError = true

    if (nPeriod < prev) return isError = true

    prev = nPeriod;
  });

  return !isError
}

export const is_valid_oracle_string = (value, network) => {
  if (network === "Obyte") {
    if (!value || typeof value !== "string") return false;
    let isError = false;
    const pairs = value.trim().split(" ");
    if (pairs.length > 3 || pairs.length === 0) return false;
    pairs.forEach((pair) => {
      const oracle = String(pair).substring(0, 32);
      if (!obyte.utils.isValidAddress(oracle)) return isError = true;
      const op = String(pair).substring(32, 33);
      if (op !== '*' && op !== '/') return isError = true;
      const feed_name = String(pair).substring(33);
      if (!feed_name) return isError = true;
    });
    return !isError;
  } else {
    try {
      return ethers.utils.getAddress(value) === value;
    } catch (e) {
      return false;
    }
  }
};