import { FC } from "react";

import { GovernanceItem } from "./governance-item";

import { appConfig } from "@/app-config";

export const GovernanceParamList: FC = () => (<div className="grid gap-y-8">
  {Object.keys(appConfig.initialParamsVariables).map((key) => (
    <GovernanceItem
      key={key}
      name={key as keyof AgentParams}
    />
  ))}
</div>)
