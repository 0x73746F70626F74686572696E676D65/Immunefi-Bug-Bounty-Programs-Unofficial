import "server-only";

import { env } from "@/env";
import { FriendsList, ProfileInfo, ProfileStats } from "@/features/profile";
import { getFriendList } from "@/lib/calculations/get-friend-list";
import { getCeilingPrice, getTotalBalance } from "@/lib/calculations/get-rewards";
import { getProfileUsername } from "@/lib/get-profile-username.server";
import { isValidAddress } from "@/lib/is-valid-address";
import { toLocalString } from "@/lib/to-local-string";

import { RefCookieApplier } from "@/components/ref-cookie-applier";
import { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = 'force-dynamic';


export async function generateMetadata(
  { params, searchParams }: { params: Promise<{ address: string }>; searchParams: Promise<Record<string, string | string[]>> }
): Promise<Metadata> {
  const { address } = await params;

  if (!address || !isValidAddress(address)) {
    return {
      title: 'Obyte Friends - Not Found',
      description: 'The page you are looking for does not exist.',
      robots: { index: false, follow: false }
    }
  }

  const username = await getProfileUsername(address) || "Anonymous";
  const state = globalThis.__GLOBAL_STORE__?.getState() ?? {};
  const queryParams = await searchParams;
  const userData: IUserData | undefined = state?.[`user_${address}`];
  const friends = getFriendList(state, address);
  const isChart = queryParams.r === 'c';

  const ceilingPrice = getCeilingPrice(state.constants!);
  const totalBalance = (await getTotalBalance(userData?.balances ?? {}, ceilingPrice)).sans_reducers;

  const frdTokenMeta = globalThis.__GLOBAL_STORE__?.getOwnToken();
  const frdDecimals = frdTokenMeta?.decimals ?? 9;
  const frdSymbol = frdTokenMeta?.symbol ?? "FRD";

  return ({
    title: `Obyte Friends — ${username}`,
    description: `Profile of user ${username} in Obyte Friends: total ${friends.length} friends, ${toLocalString(totalBalance / 10 ** frdDecimals)} ${frdSymbol} locked`,
    openGraph: {
      images: [
        `/api/og/${isChart ? 'chart' : 'puzzle'}/${address}`,
      ]
    },
    twitter: {
      card: 'summary_large_image',
      creator: '@ObyteOrg',
    },
    robots: {
      index: true,
      follow: true,
    },
    metadataBase: new URL(env.NEXT_PUBLIC_SITE_URL),
  })
}

export default async function ProfilePage({ params }: { params: Promise<{ address: string }> }) {
  const { address } = await params;

  if (!address || !isValidAddress(address)) return notFound();

  const state = globalThis.__GLOBAL_STORE__?.getState() ?? {};

  const userData: IUserData | undefined = state?.[`user_${address}`];

  const ceilingPrice = getCeilingPrice(state.constants!);
  const totalBalance = (await getTotalBalance(userData?.balances ?? {}, ceilingPrice)).sans_reducers;

  const username = await getProfileUsername(address) ?? address.slice(0, 6) + "..." + address.slice(-4);

  return <div className="grid gap-y-5">
    <ProfileInfo address={address} userData={userData} />

    <RefCookieApplier
      refAddress={address}
    />

    <ProfileStats
      address={address}
      totalBalance={totalBalance}
    />

    <div>
      <Link
        href={`https://city.obyte.org/user/${address}`}
        target="_blank"
      >
        {username}&apos;s profile on Obyte City
      </Link>
    </div>

    <FriendsList
      address={address}
    />
  </div>
}