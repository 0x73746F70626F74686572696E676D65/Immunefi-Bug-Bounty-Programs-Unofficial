/*jslint node: true */
'use strict';

const db = require('ocore/db');
const device = require('ocore/device');
const headlessWallet = require('headless-obyte');
const async = require('async');
const conf = require('ocore/conf');
const storage = require('ocore/storage');
const notifications = require('./notifications.js');

function getMyAddressFromContract(shared_address, cb) {
	db.query("SELECT address FROM shared_address_signing_paths WHERE shared_address = ? AND device_address = ? LIMIT 0,1", [shared_address, device.getMyDeviceAddress()], (rows)=>{
		cb(rows[0].address);
	})
}

exports.getMyAddressFromContract = getMyAddressFromContract;

exports.checkAndRefundContractsTimeout = () => {
	storage.readLastStableMcUnitProps(db, objUnitProps => {
		const timestamp = objUnitProps.timestamp;
		db.query("SELECT shared_address, peer_amount FROM contracts WHERE timeout<? AND checked_timeout_date IS NULL", [timestamp], rows => {
			if (!rows.length) return;
			let arrAddressesToRefund = [];
			let arrFullyFundedAddresses = [];

			async.each(rows, (row, callback) => {
				db.query(
					"SELECT address, amount FROM outputs JOIN units USING(unit) \n\
					WHERE address = ? AND amount = ? AND asset IS NULL AND is_stable = 1 AND sequence = 'good'", 
					[row.shared_address, row.peer_amount], 
					(rows2) => {
						if (rows2.length) {
							arrFullyFundedAddresses.push(row.shared_address);
						} else {
							arrAddressesToRefund.push(row.shared_address);
						}
						callback();
					}
				);
			}, () => {
				if (arrFullyFundedAddresses.length)
					db.query("UPDATE contracts SET checked_timeout_date="+db.getNow()+", refunded=0 WHERE shared_address IN (?)", [arrFullyFundedAddresses]);

				if (!arrAddressesToRefund.length) return;
				async.each(arrAddressesToRefund, (address, callback) => {
					getMyAddressFromContract(address, myAddress => {
						headlessWallet.sendAllBytesFromAddress(address, myAddress, null, (err, unit) => {
							if (err) {
								notifications.notifyAdmin('timeout refund '+address+' failed', err);
								arrAddressesToRefund.splice(arrAddressesToRefund.indexOf(address), 1);
							}else {
								db.query("UPDATE contracts SET checked_timeout_date="+db.getNow()+", refunded = 1, unlock_unit=? WHERE shared_address=?", [unit, address]);
							}
							callback();
						});
					});
				});
			});
		});
	});
};

exports.getListOfContactsForVerification = (cb) => {
	db.query("SELECT * FROM contracts WHERE checked_timeout_date IS NOT NULL AND refunded = 0 AND checked_flight_date IS NULL AND date < " + db.addTime('-2 days'), cb);
};

exports.getContractsByFeedName = (feed_name, cb) => {
	db.query("SELECT * FROM contracts WHERE feed_name=?", [feed_name], cb);
};

exports.setWinner = (feed_name, winner) => {
	db.query("UPDATE contracts SET winner = ? WHERE feed_name = ? AND refunded=0", [winner, feed_name]);
};

exports.setWinnerAndCheckedFlightDate = (feed_name, winner) => {
	db.query("UPDATE contracts SET checked_flight_date="+db.getNow()+", winner = ? WHERE feed_name = ? AND refunded=0", [winner, feed_name]);
};

exports.getContractsToRetryUnlock = (cb) => {
	db.query("SELECT * FROM contracts WHERE checked_timeout_date IS NOT NULL AND refunded = 0 AND winner IS NOT NULL AND unlocked_date IS NULL", cb)
};

exports.getExpiredContracts = (cb) => {
	db.query("SELECT * FROM contracts WHERE checked_timeout_date IS NOT NULL AND refunded = 0 AND checked_flight_date IS NULL AND winner IS NULL AND unlocked_date IS NULL AND date<"+db.addTime('-'+(conf.contractExpiry + 3)+' days'), cb);
};

exports.setUnlockedContract = (shared_address, unit) => {
	db.query("UPDATE contracts SET unlocked_date="+db.getNow()+", unlock_unit=? WHERE shared_address = ?", [unit, shared_address], () => {});
};
