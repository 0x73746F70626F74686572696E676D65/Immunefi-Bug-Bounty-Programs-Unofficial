const { DbService } = require("./db");
const discordService = require("./discord/index.js");

module.exports = async () => {
  // Checking environment variables

  if (!process.env.AA_ADDRESS) {
    throw Error(
      "Please specify the agent's address in the environment variables"
    );
  }

  if (process.env.DISCORD_CHANNEL && process.env.DISCORD_TOKEN) {
    // not awaited on purpose: Discord login must not block AA event processing.
    // login() retries internally; this .catch is a defensive backstop against unhandled rejections.
    discordService.login().catch(err => console.error('[discord] login gave up:', err && err.message));

    // register slash commands (/info, /gbyte_price, /top) for the guild.
    // requires DISCORD_APP_ID + DISCORD_GUILD_ID. not awaited: registering must not
    // block AA event processing on Discord REST latency; failures are logged, not fatal.
    if (process.env.DISCORD_APP_ID && process.env.DISCORD_GUILD_ID) {
      discordService.initCommands()
        .catch(err => console.error('[discord] failed to register slash commands:', err && err.message));
    }
  } else if (
    process.env.DISCORD_EVENT_MOVE_VOTES
    || process.env.DISCORD_EVENT_PARAM_COMMIT
    || process.env.DISCORD_EVENT_PARAM_VOTES
    || process.env.DISCORD_EVENT_POOL_LISTED
    || process.env.DISCORD_EVENT_POOL_VOTES
    || process.env.DISCORD_EVENT_STAKE_TOKEN
    || process.env.DISCORD_EVENT_UNSTAKE_TOKEN
    || process.env.DISCORD_EVENT_WITHDRAW_REWARDS
    || process.env.DISCORD_EVENT_ADD_PROPOSAL
  ) {
    throw Error(
      "Please specify environment variables for discord"
    );
  }


  await DbService.create();
};
