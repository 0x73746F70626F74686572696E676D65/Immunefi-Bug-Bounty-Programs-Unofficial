const moment = require("moment");
const dag = require('aabot/dag.js');
const conf = require("ocore/conf.js");

const { DbService } = require("../db");
const DiscordService = require("../discord");
const { getDataByTriggerUnit, getUnitUrl, getAddressUrl, getAssetUrl } = require("../utils")

exports.stakeHandler = async (triggerUnit, responseObj) => {
    const payload = getDataByTriggerUnit(triggerUnit);
    const author = payload?.to || responseObj.trigger_address;
    const ts = triggerUnit.timestamp;
    const poolKeys = Object.keys(payload.percentages);
    const untilDate = moment.unix(ts).add(payload.term, 'days').format("LL");
    const tokenAsset = await dag.readAAStateVars(process.env.AA_ADDRESS, `constants`).then((vars) => vars.constants?.asset);

    let amount = 0;

    const msg = tokenAsset && triggerUnit?.messages?.find(({ app, payload }) => app === 'payment' && payload && payload?.asset === tokenAsset && payload?.outputs?.find(({ address }) => address === process.env.AA_ADDRESS));

    if (msg) {
        amount += msg.payload.outputs.find(({ address }) => address === process.env.AA_ADDRESS)?.amount
    }

    const amountView = +(amount / 1e9).toFixed(9);

    const pools = [];
    let hasNonOswapPool = false;

    for (const asset_key of poolKeys) {
        const poolInfo = await DbService.getPoolInfoByKeys(payload.group_key, asset_key);

        pools.push({
            percent: payload.percentages[asset_key],
            view: poolInfo?.symbol || poolInfo?.name || "NOT AN OSWAP POOL",
            address: poolInfo?.address,
            asset: poolInfo?.asset,
        })

        if (!(poolInfo?.address)) {
            hasNonOswapPool = true
        }
    }

    const name = ' ';
    const fields = pools.map(({ view, percent, address, asset }) => {
        // asset is unknown when the pool is missing from our db entirely, so there is nothing to link to
        const poolView = address
            ? `[${String(view)}](https://oswap.io/#/swap/${address})`
            : (asset ? `[\`NOT AN OSWAP POOL\`](${getAssetUrl(asset)})` : '`NOT AN OSWAP POOL`');

        return ({ value: `${poolView} — ${String(percent)}%`, name, inline: false });
    });

    const amountFields = amount > 0 ? [{ value: `**Amount:** ${amountView} OSWAP`, name, inline: false }] : [];


    const embed = new DiscordService.EmbedBuilder()
        .setColor(!hasNonOswapPool ? conf.discord_primary_color : conf.discord_error_color)
        .setTitle(`Staking: ${amount > 0 ? "stake" : "re-stake"} OSWAP tokens`)
        .setTimestamp(ts * 1e3)
        .setURL(getUnitUrl(triggerUnit.unit))
        .addFields(amountFields)
        .addFields({ value: `**Author:** [${author}](${getAddressUrl(author)})`, name: ' ', inline: false })
        .addFields({ value: `**Term:** ${payload.term} days (until ${untilDate})`, name, inline: false })
        .addFields({ value: "**Pool list**", name })
        .addFields(fields)
        .setThumbnail('https://token.oswap.io/logo.png')
        .addFields({ value: `**Term:** ${payload.term} days (until ${untilDate})`, name: ' ', inline: false })
        .addFields({ value: 'You can stake OSWAP token at [token.oswap.io](https://token.oswap.io)', name: ' ', inline: false  });

    if (amount > 0 ? true : process.env.DISCORD_EVENT_RESTAKE_TOKEN) {
        DiscordService.send(embed);
    }
}