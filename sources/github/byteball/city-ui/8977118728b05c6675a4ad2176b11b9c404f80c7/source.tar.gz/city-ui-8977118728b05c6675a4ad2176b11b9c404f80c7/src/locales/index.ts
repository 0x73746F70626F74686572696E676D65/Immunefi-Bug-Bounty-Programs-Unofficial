export { defaultInformationFields } from "./defaultInformationFields";

