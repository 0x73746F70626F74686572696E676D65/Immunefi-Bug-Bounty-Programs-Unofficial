export const popularCurrencies = ["btc"];
