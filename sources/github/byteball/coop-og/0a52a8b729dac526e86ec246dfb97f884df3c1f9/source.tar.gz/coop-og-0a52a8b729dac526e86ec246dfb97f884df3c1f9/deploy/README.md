# Deploying coop-og + the COOP UI

`coop-og` serves two things crawlers need that a pure SPA can't give them
(crawlers don't run JS):

- `GET /user/:address` → the SPA `index.html` with **per-wallet** `<title>` /
  `og:*` / `twitter:*` / `canonical` injected server-side from live AA state.
- `GET /og/...png` → the Open Graph card images (Satori + resvg).

A reverse proxy routes `/user/*` and `/og/*` to `coop-og`; everything else is the
normal static SPA. Humans still get the full SPA — the client strips the
server-injected `data-prerender` tags on hydration and re-renders the head.

```
            ┌────────── /assets/*, SPA ──────────► static dist/
crawler ───►│ nginx
            └── /user/:addr, /og/* ──────────────► coop-og :4001 ──► obyte hub (AA state)
```

Files in this folder:

| File                        | Use                                                        |
| --------------------------- | ---------------------------------------------------------- |
| `docker-compose.yml`        | **Production** — runs coop-og on `127.0.0.1:4001`          |
| `nginx.conf`                | **Production** — host nginx, TLS via certbot               |
| `docker-compose.local.yml`  | **Local test** — nginx + coop-og + built SPA on `:8080`    |
| `nginx.local.conf`          | **Local test** — nginx container config (no TLS)           |

Environment reference: [`../.env.example.mainnet`](../.env.example.mainnet)
(production) and [`../.env.example.testnet`](../.env.example.testnet) (local dev).

---

## Environment

Create `coop-og/.env` (not committed):

```ini
PORT=4001
AA_ADDRESS=<32-char COOP AA address>
TESTNET=false              # MUST match the network your AA is on
OG_BASE_URL=https://<domain>   # public https origin — used for the og:image URL
SPA_BASE_URL=https://<domain>  # where coop-og fetches index.html AND the canonical base
SITE_DOMAIN=<domain>
```

> **Critical:** in production `OG_BASE_URL` / `SPA_BASE_URL` must be the **public
> https origin**, not `http://localhost:...`. Otherwise the `og:image` URL baked
> into the HTML points at localhost and crawlers can't fetch the card.

---

## Local test (nginx + coop-og in Docker)

Exercises the real routing on your machine, no TLS.

```bash
# 1. Build the SPA the nginx container will serve:
(cd coop-ui && pnpm install && pnpm build)

# 2. Bring up nginx + coop-og:
docker compose -f coop-og/deploy/docker-compose.local.yml up --build -d

# 3. Open a wallet profile (any valid testnet address works):
#    http://localhost:8080/user/WMFLGI2GLAB2MDF2KQAH37VNRRMK7A5N
```

`docker-compose.local.yml` points `coop-og` at the AA via env it sets inline
(testnet AA `SUOLWPFSOJ3VRM3GDYNEOJLFKAELGBR7`), serves `coop-ui/dist` as the
static SPA, and proxies through `nginx.local.conf`.

Quick checks:

```bash
ADDR=WMFLGI2GLAB2MDF2KQAH37VNRRMK7A5N
# per-wallet head (one clean set of tags)
curl -s http://localhost:8080/user/$ADDR | grep -E 'og:title|og:image|og:description'
# OG image renders (valid PNG)
curl -s -o /tmp/card.png http://localhost:8080/og/user/$ADDR.png && file /tmp/card.png
# locale path routes through coop-og too
curl -s http://localhost:8080/ru/user/$ADDR | grep -o '<title[^>]*>[^<]*</title>'
# coop-og down → falls back to the SPA (200, not 502)
docker stop deploy-coop-og-1; curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8080/user/$ADDR; docker start deploy-coop-og-1
```

> Locally `canonical`/`og:url` show `http://nginx` because `SPA_BASE_URL` is the
> internal docker hostname. In production (`SPA_BASE_URL=https://<domain>`) they
> are correct.

Tear down: `docker compose -f coop-og/deploy/docker-compose.local.yml down`.

---

## Production

Host nginx terminates TLS and proxies to `coop-og` running in Docker on
`127.0.0.1:4001`.

### 1. Configure env

Create `coop-og/.env` as above with your real domain and AA address.

### 2. Build & deploy the SPA

```bash
cd coop-ui
VITE_OG_URL=https://<domain> pnpm install && pnpm build
sudo mkdir -p /var/www/coop-ui/dist
sudo rsync -a --delete dist/ /var/www/coop-ui/dist/
```

### 3. Start coop-og

```bash
docker compose -f coop-og/deploy/docker-compose.yml up -d --build
docker compose -f coop-og/deploy/docker-compose.yml ps      # STATUS = healthy
curl -s http://127.0.0.1:4001/healthz                        # {"ok":true,...}
```

Binds `127.0.0.1:4001` only (nginx reaches it). `restart: unless-stopped`
survives reboots — ensure Docker starts at boot: `sudo systemctl enable docker`.

### 4. nginx + TLS

```bash
sudo cp coop-og/deploy/nginx.conf /etc/nginx/sites-available/coop
sudo sed -i 's/<domain>/your.domain/g' /etc/nginx/sites-available/coop   # + check root path
sudo ln -s /etc/nginx/sites-available/coop /etc/nginx/sites-enabled/coop
sudo nginx -t
sudo certbot --nginx -d your.domain     # issues cert + injects ssl_* lines
sudo systemctl reload nginx
```

### 5. Verify

```bash
curl -s https://<domain>/user/<addr> | grep -E 'og:title|og:image|rel="canonical"'
#   canonical / og:url now = https://<domain>/user/<addr>
curl -sI https://<domain>/og/user/<addr>.png    # 200, content-type: image/png
```

Then the real crawlers (need the public URL):

- Facebook Sharing Debugger — `developers.facebook.com/tools/debug/` (use **Scrape Again**)
- Telegram — send the URL to **@WebpageBot**
- Discord — paste in any channel

---

## Operations

```bash
# update coop-og after a git pull / code change
docker compose -f coop-og/deploy/docker-compose.yml up -d --build
# update the SPA: rebuild coop-ui, rsync dist/
# logs
docker compose -f coop-og/deploy/docker-compose.yml logs -f coop-og
```

certbot installs a renewal timer automatically (`sudo certbot renew --dry-run`).

### Gotcha: hairpin NAT

`coop-og` fetches `SPA_BASE_URL=https://<domain>`, i.e. it calls back to its own
public domain. Some servers can't reach their own public IP from inside a
container (no hairpinning). If coop-og logs `fetch failed` on `/user/*`, add to
the service in `docker-compose.yml`:

```yaml
    extra_hosts:
      - "<domain>:host-gateway"   # resolve the domain to the host where nginx listens
```

`canonical` stays correct — it's built from the `SPA_BASE_URL` string, not from
how the name resolves.

---

## Notes

- Fonts (Inter) ship in `coop-og/public/fonts/` and are baked into the image, so
  rendering has no runtime CDN dependency.
- Both `coop-og` HTML injection and the build-time prerender plugin in `coop-ui`
  mark their head tags with `data-prerender`; the client removes them on
  hydration so TanStack Router owns the head without duplicates.
