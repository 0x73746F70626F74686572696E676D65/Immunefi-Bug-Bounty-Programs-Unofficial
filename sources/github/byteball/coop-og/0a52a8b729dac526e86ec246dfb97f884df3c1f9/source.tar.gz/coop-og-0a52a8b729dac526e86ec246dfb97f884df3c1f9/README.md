# coop-og

Open Graph image generator for [Obyte COOP](../coop-ui). Renders 1200×630 PNG
images on demand using [Hono](https://hono.dev) + [Satori](https://github.com/vercel/satori)
+ [resvg-js](https://github.com/yisibl/resvg-js).

## Endpoints

| Path                          | Source                                   |
| ----------------------------- | ---------------------------------------- |
| `GET /og/home.png`            | static                                   |
| `GET /og/faq.png`             | static                                   |
| `GET /og/governance.png`      | AA state (current parameters)            |
| `GET /og/leaderboard.png`     | AA state (top-5 by balance)              |
| `GET /og/user/:address.png`   | AA state (per-user)                      |
| `GET /healthz`                | health check                             |

## Environment

Ready-made examples: `.env.example.mainnet` (production values) and
`.env.example.testnet` (testnet AA, localhost URLs). Copy one to `.env` and edit.

| Var            | Description                                                        |
| -------------- | ------------------------------------------------------------------ |
| `PORT`         | HTTP port (default `4001`)                                         |
| `AA_ADDRESS`   | 32-char COOP AA address (**required**)                             |
| `TESTNET`      | `true` to connect to `wss://obyte.org/bb-test`                     |
| `OG_BASE_URL`  | Public base URL of this service (og:image URLs, image footers)     |
| `SPA_BASE_URL` | Where to fetch the SPA `index.html`; also the canonical/og:url base |
| `SITE_DOMAIN`  | Domain label rendered on the OG card (default `coop.obyte.org`)    |

## Develop

```bash
pnpm install
pnpm dev          # tsx watch on $PORT
```

## Build & run (production)

```bash
pnpm build
pnpm start
```

## Docker

```bash
docker build -t coop-og .
docker run --rm -p 4001:4001 \
  -e AA_ADDRESS=2QHG7K... \
  -e TESTNET=false \
  coop-og
```
