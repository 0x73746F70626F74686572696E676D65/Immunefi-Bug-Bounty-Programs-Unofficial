import satori from "satori";
import { Resvg } from "@resvg/resvg-js";

import { loadFonts } from "./fonts.js";

import type { ReactNode } from "react";

const WIDTH = 1200;
const HEIGHT = 630;

export const renderPng = async (node: ReactNode): Promise<Buffer> => {
  const fonts = await loadFonts();
  const svg = await satori(node as never, {
    width: WIDTH,
    height: HEIGHT,
    fonts,
  });
  const resvg = new Resvg(svg, {
    fitTo: { mode: "width", value: WIDTH },
  });
  return resvg.render().asPng();
};
