import { TtlCache } from "#cache.js";
import { getAssetMetadata } from "#obyte/asset.js";
import { getCoopState } from "#obyte/state.js";

import type { CoopState } from "#obyte/state.js";

const STATE_TTL_MS = 60_000;

const stateCache = new TtlCache<CoopState>(STATE_TTL_MS);

export const loadCoopState = (): Promise<CoopState> =>
  stateCache.get("coop", getCoopState);

interface AssetInfo {
  symbol: string;
  decimals: number;
}

const FALLBACK: AssetInfo = { symbol: "COOP", decimals: 0 };

export const loadAssetInfo = async (): Promise<AssetInfo> => {
  const state = await loadCoopState();
  const asset = state.constants?.asset;
  if (!asset) return FALLBACK;
  try {
    return await getAssetMetadata(asset);
  } catch {
    return FALLBACK;
  }
};
