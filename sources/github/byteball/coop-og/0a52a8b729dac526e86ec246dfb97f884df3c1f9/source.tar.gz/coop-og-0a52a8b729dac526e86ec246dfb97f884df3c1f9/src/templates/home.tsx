import { Shell } from "./shell.js";

import { colors } from "#render/colors.js";

export const HomeTemplate = () => (
  <Shell>
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 24,
      }}
    >
      <div
        style={{
          fontSize: 96,
          fontWeight: 700,
          letterSpacing: "-0.05em",
          lineHeight: 1.125,
        }}
      >
        Cooperative token
      </div>
      <div
        style={{
          fontSize: 36,
          color: colors.muted,
          fontWeight: 400,
        }}
      >
        Lock tokens, vote for contributors, contribute, and receive daily
        emission rewards.
      </div>

      <div
        style={{
          display: "flex",
          gap: 24,
          marginTop: 40,
        }}
      >
        {[
          { label: "Lock", value: "1 year +" },
          { label: "Locked reward", value: "1% / day" },
          { label: "Liquid reward", value: "0.1% / day" },
        ].map((item) => (
          <div
            key={item.label}
            style={{
              display: "flex",
              flexDirection: "column",
              padding: "24px 28px",
              backgroundColor: colors.surface,
              border: `1px solid ${colors.border}`,
              borderRadius: 18,
              gap: 8,
              flexGrow: 1,
            }}
          >
            <span style={{ color: colors.muted, fontSize: 22 }}>
              {item.label}
            </span>
            <span style={{ fontSize: 36, fontWeight: 700 }}>{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  </Shell>
);
