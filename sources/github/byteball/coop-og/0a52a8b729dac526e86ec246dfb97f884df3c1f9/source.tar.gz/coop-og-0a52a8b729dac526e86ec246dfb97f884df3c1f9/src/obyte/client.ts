import obyte from "obyte";

import { env } from "#env.js";

const testnet = env.TESTNET;

const client = new obyte.Client(`wss://obyte.org/bb${testnet ? "-test" : ""}`, {
  testnet,
  reconnect: true,
});

client.onConnect(() => {
  console.log("[coop-og] connected to hub");
});

// Without client-initiated heartbeats a half-open connection (idle NAT/proxy
// drop, hub restart) is never detected: readyState stays 1 and requests sent
// into the dead socket hang until TCP notices. The heartbeat logic closes the
// connection when a ping goes unanswered, which rejects all pending requests
// and triggers reconnect. A rejection fires once per detected drop (while the
// socket is closed heartbeats are skipped, not rejected), so logging it can't
// spam and marks the exact moment the dead connection was noticed.
setInterval(() => {
  client.api.heartbeat().catch((err: unknown) => {
    console.warn(
      "[coop-og] hub heartbeat failed, reconnecting:",
      err instanceof Error ? err.message : err,
    );
  });
}, 10_000);

export default client;
