import { Shell } from "./shell.js";

import { colors } from "#render/colors.js";

interface GovernanceTemplateProps {
  rows: Array<{ label: string; value: string }>;
}

export const GovernanceTemplate = ({ rows }: GovernanceTemplateProps) => (
  <Shell>
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <div
        style={{
          fontSize: 60,
          fontWeight: 700,
          letterSpacing: "-0.05em",
          lineHeight: 1.125,
        }}
      >
        Governance
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: colors.surface,
          border: `1px solid ${colors.border}`,
          borderRadius: 18,
          marginTop: 28,
        }}
      >
        {rows.map((row, idx) => (
          <div
            key={row.label}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "14px 24px",
              borderTop: idx === 0 ? "none" : `1px solid ${colors.border}`,
            }}
          >
            <span style={{ fontSize: 24, color: colors.muted }}>
              {row.label}
            </span>
            <span style={{ fontSize: 26, fontWeight: 700 }}>{row.value}</span>
          </div>
        ))}
      </div>
    </div>
  </Shell>
);
