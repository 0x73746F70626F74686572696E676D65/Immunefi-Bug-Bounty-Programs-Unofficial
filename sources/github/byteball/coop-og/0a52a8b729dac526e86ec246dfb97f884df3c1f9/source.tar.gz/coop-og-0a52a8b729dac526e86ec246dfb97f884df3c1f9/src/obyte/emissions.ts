import { defaultParams } from "./defaults.js";

import type { AppParamName } from "./defaults.js";
import type { CoopState, CoopUser } from "./state.js";

const YEAR_SECONDS = 365.25 * 24 * 3600;

export const getParam = (state: CoopState, name: AppParamName): number => {
  const raw = state.governance[name];
  if (typeof raw === "number") return raw;
  if (typeof raw === "string") {
    const parsed = Number(raw);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return defaultParams[name];
};

export const getCeilingPrice = (launchTs: number | undefined): number => {
  if (!launchTs) return 1;
  const nowSec = Math.floor(Date.now() / 1000);
  return Math.pow(2, (nowSec - launchTs) / YEAR_SECONDS);
};

export const computePendingLocked = (
  user: CoopUser,
  state: CoopState,
): number => {
  if (!user.votes || user.votes <= 0) return 0;
  if (
    state.ts === undefined ||
    state.total_locked === undefined ||
    state.total_locked_bytes === undefined ||
    state.total_votes === undefined ||
    state.total_votes_bal === undefined ||
    state.locked_emissions_per_vote === undefined ||
    state.locked_emissions_per_vb === undefined
  ) {
    return 0;
  }

  const ceilingPrice = getCeilingPrice(state.constants?.launch_ts);
  const dailyLocked = getParam(state, "daily_locked_reward");
  const bytesReducer = getParam(state, "bytes_reducer");
  const byVotesShare = getParam(state, "by_votes_share");

  const nowSec = Math.floor(Date.now() / 1000);
  const elapsedDays = Math.max(0, (nowSec - state.ts) / 86400);
  const s =
    state.total_locked +
    (state.total_locked_bytes / ceilingPrice) * bytesReducer;
  const newLockedEmissions = s * dailyLocked * elapsedDays;

  let liveLockedPerVote = state.locked_emissions_per_vote;
  let liveLockedPerVb = state.locked_emissions_per_vb;
  if (state.total_votes > 0 && state.total_votes_bal > 0) {
    liveLockedPerVote += newLockedEmissions / state.total_votes;
    liveLockedPerVb += newLockedEmissions / state.total_votes_bal;
  }

  const dLockedPerVote =
    liveLockedPerVote - (user.last_locked_emissions_per_vote ?? 0);
  const dLockedPerVb =
    liveLockedPerVb - (user.last_locked_emissions_per_vb ?? 0);

  const v = byVotesShare * user.votes;
  const vb = (1 - byVotesShare) * user.votes * user.total_balance;

  return v * dLockedPerVote + vb * dLockedPerVb;
};
