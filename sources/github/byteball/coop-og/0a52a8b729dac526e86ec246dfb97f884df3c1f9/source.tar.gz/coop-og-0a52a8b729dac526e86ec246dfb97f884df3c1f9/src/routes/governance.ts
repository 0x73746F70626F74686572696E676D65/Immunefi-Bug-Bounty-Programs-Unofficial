import { Hono } from "hono";

import { TtlCache } from "#cache.js";
import { defaultParams } from "#obyte/defaults.js";

import type { AppParamName } from "#obyte/defaults.js";
import { renderPng } from "#render/satori.js";
import { GovernanceTemplate } from "#templates/governance.js";

import { pngResponse } from "./_response.js";
import { loadAssetInfo, loadCoopState } from "./_state.js";

const PNG_TTL_MS = 60_000;
const HEADER_CACHE = "public, max-age=60, s-maxage=60";

const pngCache = new TtlCache<Buffer>(PNG_TTL_MS);

const pickParam = (
  state: Record<string, number | string>,
  name: AppParamName,
): number => {
  const fromState = state[name];
  if (typeof fromState === "number") return fromState;
  return defaultParams[name];
};

const formatPercent = (value: number): string =>
  `${(value * 100).toFixed(2).replace(/\.?0+$/, "")}%`;

const renderGovernancePng = async (): Promise<Buffer> => {
  const [state, asset] = await Promise.all([loadCoopState(), loadAssetInfo()]);
  const g = state.governance;

  const referralRaw = pickParam(g, "referral_reward");
  const referralScaled =
    asset.decimals > 0 ? referralRaw / 10 ** asset.decimals : referralRaw;
  const referralLabel = `${new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 2,
  }).format(referralScaled)} ${asset.symbol}`;

  const rows = [
    { label: "Daily locked reward", value: formatPercent(pickParam(g, "daily_locked_reward")) },
    { label: "Daily liquid reward", value: formatPercent(pickParam(g, "daily_liquid_reward")) },
    { label: "Votes share", value: formatPercent(pickParam(g, "by_votes_share")) },
    { label: "Referral reward", value: referralLabel },
  ];

  return renderPng(GovernanceTemplate({ rows }));
};

const app = new Hono();

app.get("/og/governance.png", async () => {
  const png = await pngCache.get("governance", renderGovernancePng);
  return pngResponse(png, HEADER_CACHE);
});

export default app;
