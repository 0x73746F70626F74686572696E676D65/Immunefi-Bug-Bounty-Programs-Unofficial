import { env } from "#env.js";

const attestorsByNetwork = {
  livenet: {
    telegram: ["JBW7HT5CRBSF7J7RD26AYLQG6GZDPFPS"],
    discord: ["5KM36CFPBD2QJLVD65PHZG34WEM4RPY2"],
    realName: ["JFKWGRMXP3KHUAFMF4SJZVDXFL6ACC6P"],
  },
  testnet: {
    telegram: [
      "WMFLGI2GLAB2MDF2KQAH37VNRRMK7A5N",
      "JBW7HT5CRBSF7J7RD26AYLQG6GZDPFPS",
    ],
    discord: [
      "WMFLGI2GLAB2MDF2KQAH37VNRRMK7A5N",
      "5KM36CFPBD2QJLVD65PHZG34WEM4RPY2",
      "UADF7ZDFREOUXMPRRGI2JHLKD2YQI5EV",
      "AXUWOO2XGPQVRS4FGC2N6LCFLZ4LFRMJ",
      "5K2U5I7R74XNZMG7LYGMHVXSQXIZDBKG",
    ],
    realName: ["JFKWGRMXP3KHUAFMF4SJZVDXFL6ACC6P"],
  },
} as const;

export const attestors =
  attestorsByNetwork[env.TESTNET ? "testnet" : "livenet"];
