import { createEnv } from "@t3-oss/env-core";
import { z } from "zod";

export const env = createEnv({
  server: {
    PORT: z.coerce.number().int().positive().default(4001),
    AA_ADDRESS: z.string().length(32),
    TESTNET: z
      .enum(["true", "false"])
      .optional()
      .default("false")
      .transform((v) => v === "true"),
    OG_BASE_URL: z.string().url().default("http://localhost:4001"),
    SITE_DOMAIN: z.string().min(1).default("coop.obyte.org"),
    SPA_BASE_URL: z.string().url().default("https://coop.obyte.org"),
  },
  runtimeEnv: process.env,
  emptyStringAsUndefined: true,
});
