import { env } from "#env.js";
import { colors } from "#render/colors.js";
import { logoDataUri } from "#render/logo.js";

import type { ReactNode } from "react";

interface ShellProps {
  children: ReactNode;
}

export const Shell = ({ children }: ShellProps) => (
  <div
    style={{
      width: "100%",
      height: "100%",
      display: "flex",
      flexDirection: "column",
      backgroundColor: colors.bg,
      color: colors.fg,
      fontFamily: "Inter",
      padding: "28px 72px 18px",
      position: "relative",
    }}
  >
    <div
      style={{
        display: "flex",
        alignItems: "center",
      }}
    >
      <img src={logoDataUri} alt="COOP" width={171} height={114} />
    </div>

    <div
      style={{
        display: "flex",
        flexDirection: "column",
        flexGrow: 1,
        marginTop: 0,
      }}
    >
      {children}
    </div>

    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        color: colors.muted,
        fontSize: 22,
      }}
    >
      {env.SITE_DOMAIN}
    </div>
  </div>
);
