import { Hono } from "hono";

import { renderPng } from "#render/satori.js";
import { HomeTemplate } from "#templates/home.js";

import { pngResponse } from "./_response.js";

const STATIC_CACHE = "public, max-age=86400, s-maxage=86400";

const app = new Hono();

let cached: Buffer | null = null;

app.get("/og/home.png", async () => {
  if (!cached) {
    cached = await renderPng(HomeTemplate());
  }
  return pngResponse(cached, STATIC_CACHE);
});

export default app;
