import { Hono } from "hono";
import obyte from "obyte";

import { TtlCache } from "#cache.js";
import { env } from "#env.js";
import { formatAmount, formatVotes, shortAddress } from "#format.js";
import { getDisplayName } from "#obyte/attestations.js";
import { getUserAvatar } from "#obyte/avatar.js";
import { computePendingLocked } from "#obyte/emissions.js";
import { renderPng } from "#render/satori.js";
import {
  buildHeadBlock,
  injectHeadIntoHtml,
  loadSpaIndexHtml,
} from "#spa.js";
import { UserTemplate } from "#templates/user.js";

import { pngResponse } from "./_response.js";
import { loadAssetInfo, loadCoopState } from "./_state.js";

const PNG_TTL_MS = 5 * 60_000;
const HTML_TTL_MS = 5 * 60_000;
const HEADER_CACHE = "public, max-age=300, s-maxage=300";

const pngCache = new TtlCache<Buffer>(PNG_TTL_MS);
const htmlCache = new TtlCache<string>(HTML_TTL_MS);

const renderUserPng = async (address: string): Promise<Buffer> => {
  const [state, asset, displayName, avatarDataUri] = await Promise.all([
    loadCoopState(),
    loadAssetInfo(),
    getDisplayName(address).catch(() => null),
    getUserAvatar(address).catch(() => null),
  ]);
  const user = state.users[address];

  const short = shortAddress(address);
  const liveTotalBalance = user
    ? user.total_balance + computePendingLocked(user, state)
    : 0;
  const lockedBalance = formatAmount(
    liveTotalBalance,
    asset.decimals,
    asset.symbol,
  );
  const votes = formatVotes(user?.votes, asset.decimals);

  return renderPng(
    UserTemplate({
      displayName: displayName ?? short,
      shortAddress: short,
      fullAddress: address,
      lockedBalance,
      votes,
      avatarDataUri,
    }),
  );
};

const renderUserHtml = async (address: string): Promise<string> => {
  const [state, asset, displayName, baseHtml] = await Promise.all([
    loadCoopState(),
    loadAssetInfo(),
    getDisplayName(address).catch(() => null),
    loadSpaIndexHtml(),
  ]);
  const user = state.users[address];

  const short = shortAddress(address);
  const name = displayName ?? short;
  const liveTotalBalance = user
    ? user.total_balance + computePendingLocked(user, state)
    : 0;
  const lockedFormatted = formatAmount(
    liveTotalBalance,
    asset.decimals,
    asset.symbol,
  );

  const title = `${name} — Obyte COOP`;
  const description = user
    ? `${name} has ${lockedFormatted} locked on Obyte COOP.`
    : `${name} on Obyte COOP.`;
  const ogImageUrl = new URL(
    `/og/user/${address}.png`,
    env.OG_BASE_URL,
  ).toString();
  const canonicalUrl = new URL(
    `/user/${address}`,
    env.SPA_BASE_URL,
  ).toString();

  const headBlock = buildHeadBlock({
    title,
    description,
    ogImageUrl,
    canonicalUrl,
  });
  return injectHeadIntoHtml(baseHtml, headBlock);
};

const app = new Hono();

app.get("/og/user/:address{.+\\.png}", async (c) => {
  const param = c.req.param("address");
  const address = param.replace(/\.png$/, "");

  if (!obyte.utils.isValidAddress(address)) {
    return c.text("Invalid address", 400);
  }

  const png = await pngCache.get(address, () => renderUserPng(address));
  return pngResponse(png, HEADER_CACHE);
});

app.get("/user/:address", async (c) => {
  const address = c.req.param("address");

  if (!obyte.utils.isValidAddress(address)) {
    return c.text("Invalid address", 400);
  }

  const html = await htmlCache.get(address, () => renderUserHtml(address));
  return c.html(html, 200, { "Cache-Control": HEADER_CACHE });
});

export default app;
