import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import type { Font } from "satori";

const here = path.dirname(fileURLToPath(import.meta.url));
const FONTS_DIR = path.resolve(here, "../../public/fonts");

// Fonts ship in public/fonts so the service never depends on a CDN at runtime
// (satori parses ttf/otf/woff — woff is fine). The URLs are only a fallback if
// the files are ever missing; the old `fontsource/fonts/...` path now redirect-loops.
const SOURCES = {
  regular: {
    filename: "Inter-Regular.woff",
    url: "https://cdn.jsdelivr.net/npm/@fontsource/inter@4.5.15/files/inter-latin-400-normal.woff",
  },
  bold: {
    filename: "Inter-Bold.woff",
    url: "https://cdn.jsdelivr.net/npm/@fontsource/inter@4.5.15/files/inter-latin-700-normal.woff",
  },
} as const;

const loadOne = async (filename: string, url: string): Promise<ArrayBuffer> => {
  const localPath = path.join(FONTS_DIR, filename);
  if (existsSync(localPath)) {
    const buf = await readFile(localPath);
    return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  }

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch font ${filename}: ${response.status}`);
  }
  return await response.arrayBuffer();
};

let cached: Promise<Font[]> | null = null;

export const loadFonts = (): Promise<Font[]> => {
  if (cached) return cached;
  const next = (async (): Promise<Font[]> => {
    const [regular, bold] = await Promise.all([
      loadOne(SOURCES.regular.filename, SOURCES.regular.url),
      loadOne(SOURCES.bold.filename, SOURCES.bold.url),
    ]);
    return [
      { name: "Inter", data: regular, weight: 400, style: "normal" } as const,
      { name: "Inter", data: bold, weight: 700, style: "normal" } as const,
    ];
  })().catch((err) => {
    cached = null;
    throw err;
  });
  cached = next;
  return next;
};
