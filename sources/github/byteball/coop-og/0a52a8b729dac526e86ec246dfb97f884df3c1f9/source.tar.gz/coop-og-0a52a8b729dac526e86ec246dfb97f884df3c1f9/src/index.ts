import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { logger } from "hono/logger";

import client from "#obyte/client.js";
import { env } from "#env.js";
import { loadFonts } from "#render/fonts.js";

import faqRoute from "./routes/faq.js";
import governanceRoute from "./routes/governance.js";
import homeRoute from "./routes/home.js";
import leaderboardRoute from "./routes/leaderboard.js";
import userRoute from "./routes/user.js";

const app = new Hono();

app.use("*", logger());

app.get("/healthz", (c) => {
  const wsReady = (client as unknown as { client?: { ws?: { readyState?: number } } })
    .client?.ws?.readyState === 1;
  return c.json(
    { ok: true, aaConnected: wsReady },
    200,
    { "Cache-Control": "no-store" },
  );
});

app.route("/", homeRoute);
app.route("/", faqRoute);
app.route("/", governanceRoute);
app.route("/", leaderboardRoute);
app.route("/", userRoute);

app.notFound((c) => c.text("Not found", 404));

const bootstrap = async () => {
  await loadFonts();
  console.log(`[coop-og] fonts loaded`);
  serve(
    { fetch: app.fetch, port: env.PORT },
    (info) => {
      console.log(`[coop-og] listening on :${info.port}`);
    },
  );
};

bootstrap().catch((err) => {
  console.error("[coop-og] fatal", err);
  process.exit(1);
});
