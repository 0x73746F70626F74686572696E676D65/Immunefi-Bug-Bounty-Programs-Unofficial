import { withTimeout } from "#timeout.js";

interface Entry<T> {
  value: T;
  expiresAt: number;
}

const DEFAULT_LOAD_TIMEOUT_MS = 15_000;

export class TtlCache<T> {
  private readonly entries = new Map<string, Entry<T>>();
  private readonly pending = new Map<string, Promise<T>>();

  constructor(
    private readonly ttlMs: number,
    private readonly loadTimeoutMs = DEFAULT_LOAD_TIMEOUT_MS,
  ) {}

  async get(key: string, load: () => Promise<T>): Promise<T> {
    const entry = this.entries.get(key);
    if (entry && entry.expiresAt > Date.now()) {
      return entry.value;
    }

    const refresh = this.refresh(key, load);

    if (entry) {
      // Stale entry: serve it immediately and let the refresh finish in the
      // background, so a slow or dead hub connection never blocks responses.
      refresh.catch(() => {});
      return entry.value;
    }

    return refresh;
  }

  set(key: string, value: T): void {
    this.entries.set(key, { value, expiresAt: Date.now() + this.ttlMs });
  }

  private refresh(key: string, load: () => Promise<T>): Promise<T> {
    const inflight = this.pending.get(key);
    if (inflight) return inflight;

    // The timeout guarantees the promise settles even if load() never does
    // (e.g. a request sent into a half-open WebSocket), so the pending slot
    // is always released and the next request retries instead of piling up.
    const promise = (async () => {
      try {
        const value = await withTimeout(
          load(),
          this.loadTimeoutMs,
          `cache load "${key}"`,
        );
        this.entries.set(key, { value, expiresAt: Date.now() + this.ttlMs });
        return value;
      } finally {
        this.pending.delete(key);
      }
    })();

    this.pending.set(key, promise);
    return promise;
  }
}
