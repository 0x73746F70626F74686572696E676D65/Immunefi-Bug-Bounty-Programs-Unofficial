import { Shell } from "./shell.js";

import { colors } from "#render/colors.js";

interface LeaderboardRow {
  rank: number;
  name: string;
  balance: string;
  votes: number;
}

interface LeaderboardTemplateProps {
  rows: LeaderboardRow[];
}

export const LeaderboardTemplate = ({ rows }: LeaderboardTemplateProps) => (
  <Shell>
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 28,
      }}
    >
      <div
        style={{
          fontSize: 60,
          fontWeight: 700,
          letterSpacing: "-0.05em",
          lineHeight: 1.125,
        }}
      >
        Leaderboard
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: colors.surface,
          border: `1px solid ${colors.border}`,
          borderRadius: 18,
        }}
      >
        {rows.map((row, idx) => (
          <div
            key={row.rank}
            style={{
              display: "flex",
              alignItems: "center",
              padding: "14px 24px",
              borderTop: idx === 0 ? "none" : `1px solid ${colors.border}`,
              gap: 16,
            }}
          >
            <span
              style={{
                fontSize: 24,
                fontWeight: 700,
                color: colors.muted,
                width: 54,
                flexShrink: 0,
              }}
            >
              #{row.rank}
            </span>
            <span
              style={{
                fontSize: 26,
                fontWeight: 700,
                flexGrow: 1,
                flexBasis: 0,
                minWidth: 0,
                overflow: "hidden",
              }}
            >
              {row.name}
            </span>
            <span
              style={{
                fontSize: 24,
                fontWeight: 700,
                width: 240,
                textAlign: "right",
                flexShrink: 0,
              }}
            >
              {row.balance}
            </span>
            <span
              style={{
                fontSize: 22,
                color: colors.muted,
                width: 130,
                textAlign: "right",
                flexShrink: 0,
              }}
            >
              {row.votes} {row.votes === 1 ? "vote" : "votes"}
            </span>
          </div>
        ))}
      </div>
    </div>
  </Shell>
);
