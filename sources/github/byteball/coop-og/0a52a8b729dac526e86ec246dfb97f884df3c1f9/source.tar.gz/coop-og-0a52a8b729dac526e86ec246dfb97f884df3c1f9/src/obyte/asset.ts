import client from "./client.js";

import { withTimeout } from "#timeout.js";

interface AssetMetadata {
  symbol: string;
  decimals: number;
}

const LOAD_TIMEOUT_MS = 15_000;

const cache = new Map<string, Promise<AssetMetadata>>();

export const getAssetMetadata = (asset: string): Promise<AssetMetadata> => {
  let pending = cache.get(asset);
  if (pending) return pending;

  const load = async (): Promise<AssetMetadata> => {
    const registryAddress = client.api.getOfficialTokenRegistryAddress();
    const [symbol, decimals] = (await Promise.all([
      client.api.getSymbolByAsset(registryAddress, asset),
      client.api.getDecimalsBySymbolOrAsset(registryAddress, asset),
    ])) as [string | null | undefined, number | null | undefined];
    return { symbol: symbol ?? "COOP", decimals: decimals ?? 0 };
  };

  // The timeout must wrap the promise that lands in the cache: a hung load
  // would otherwise be memoized forever and block every caller.
  pending = withTimeout(
    load(),
    LOAD_TIMEOUT_MS,
    `asset metadata ${asset}`,
  ).catch((err: unknown) => {
    cache.delete(asset);
    throw err;
  });

  cache.set(asset, pending);
  return pending;
};
