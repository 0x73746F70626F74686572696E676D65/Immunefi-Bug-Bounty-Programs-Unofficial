import { TtlCache } from "#cache.js";
import { env } from "#env.js";

const SPA_HTML_TTL_MS = 5 * 60_000;
const FETCH_TIMEOUT_MS = 10_000;

const spaHtmlCache = new TtlCache<string>(SPA_HTML_TTL_MS);

const fetchIndexHtml = async (): Promise<string> => {
  const res = await fetch(env.SPA_BASE_URL, {
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    headers: { accept: "text/html" },
  });
  if (!res.ok) {
    throw new Error(`SPA fetch ${env.SPA_BASE_URL}: ${res.status}`);
  }
  return await res.text();
};

export const loadSpaIndexHtml = (): Promise<string> =>
  spaHtmlCache.get("index", fetchIndexHtml);

const escapeHtml = (s: string): string =>
  s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

interface HeadParams {
  title: string;
  description: string;
  ogImageUrl: string;
  canonicalUrl?: string;
}

/**
 * Marker attribute on every server-injected head tag. The SPA's client-side
 * head manager removes elements carrying this attribute on hydration so
 * TanStack Router's `<HeadContent />` re-renders without duplicates — same
 * contract as the build-time prerender plugin in coop-ui.
 */
const PRERENDER_ATTR = "data-prerender";

export const buildHeadBlock = (params: HeadParams): string => {
  const { title, description, ogImageUrl, canonicalUrl } = params;
  const a = PRERENDER_ATTR;
  const tags = [
    `<title ${a}>${escapeHtml(title)}</title>`,
    `<meta ${a} name="description" content="${escapeHtml(description)}" />`,
    canonicalUrl
      ? `<link ${a} rel="canonical" href="${escapeHtml(canonicalUrl)}" />`
      : null,
    `<meta ${a} property="og:type" content="profile" />`,
    `<meta ${a} property="og:site_name" content="Obyte COOP" />`,
    `<meta ${a} property="og:title" content="${escapeHtml(title)}" />`,
    `<meta ${a} property="og:description" content="${escapeHtml(description)}" />`,
    `<meta ${a} property="og:image" content="${escapeHtml(ogImageUrl)}" />`,
    canonicalUrl
      ? `<meta ${a} property="og:url" content="${escapeHtml(canonicalUrl)}" />`
      : null,
    `<meta ${a} name="twitter:card" content="summary_large_image" />`,
    `<meta ${a} name="twitter:title" content="${escapeHtml(title)}" />`,
    `<meta ${a} name="twitter:description" content="${escapeHtml(description)}" />`,
    `<meta ${a} name="twitter:image" content="${escapeHtml(ogImageUrl)}" />`,
  ].filter((t): t is string => t !== null);
  return tags.join("\n    ");
};

const HEAD_CLOSE_RE = /<\/head>/i;

// Remove every head tag the SPA shell or the build-time prerender plugin marked
// with data-prerender (title/meta/link) so we can re-emit one clean per-wallet
// set without duplicates. Both producers use the same data-prerender contract,
// and the plugin emits `<meta data-prerender property=...>` — i.e. the marker
// comes before property/name, which a naive `<meta property=...>` strip misses.
const PRERENDER_TITLE_RE =
  /<title\b[^>]*\bdata-prerender\b[^>]*>[\s\S]*?<\/title>\s*/gi;
const PRERENDER_VOID_RE =
  /<(?:meta|link)\b[^>]*\bdata-prerender\b[^>]*\/?>\s*/gi;

// Defense in depth: also drop any non-marked SEO tags (attribute-order tolerant)
// and any leftover <title>, so the injected block is the single source of truth.
const STRIP_RE_LIST: RegExp[] = [
  /<meta\b[^>]*\b(?:property|name)=["'](?:og|twitter):[^"']+["'][^>]*\/?>\s*/gi,
  /<meta\b[^>]*\bname=["']description["'][^>]*\/?>\s*/gi,
  /<link\b[^>]*\brel=["']canonical["'][^>]*\/?>\s*/gi,
];
const TITLE_RE = /<title[^>]*>[\s\S]*?<\/title>\s*/i;

export const injectHeadIntoHtml = (html: string, headBlock: string): string => {
  let out = html.replace(PRERENDER_TITLE_RE, "").replace(PRERENDER_VOID_RE, "");
  for (const re of STRIP_RE_LIST) out = out.replace(re, "");
  out = out.replace(TITLE_RE, "");
  if (HEAD_CLOSE_RE.test(out)) {
    return out.replace(HEAD_CLOSE_RE, `    ${headBlock}\n  </head>`);
  }
  return out + headBlock;
};
