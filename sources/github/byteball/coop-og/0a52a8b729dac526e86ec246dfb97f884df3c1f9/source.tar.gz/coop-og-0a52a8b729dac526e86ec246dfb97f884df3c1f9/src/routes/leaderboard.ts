import { Hono } from "hono";

import { TtlCache } from "#cache.js";
import { formatAmount, formatVotes, shortAddress } from "#format.js";
import { getDisplayName } from "#obyte/attestations.js";
import { computePendingLocked } from "#obyte/emissions.js";
import { renderPng } from "#render/satori.js";
import { LeaderboardTemplate } from "#templates/leaderboard.js";

import { pngResponse } from "./_response.js";
import { loadAssetInfo, loadCoopState } from "./_state.js";

const PNG_TTL_MS = 60_000;
const HEADER_CACHE = "public, max-age=60, s-maxage=60";
const TOP_N = 5;

const pngCache = new TtlCache<Buffer>(PNG_TTL_MS);

const renderLeaderboardPng = async (): Promise<Buffer> => {
  const [state, asset] = await Promise.all([loadCoopState(), loadAssetInfo()]);

  const sorted = Object.entries(state.users)
    .filter((entry): entry is [string, NonNullable<typeof entry[1]>] => {
      const u = entry[1];
      return Boolean(u) && typeof u.total_balance === "number" && u.total_balance > 0;
    })
    .map(([address, user]) => ({
      address,
      user,
      liveBalance: user.total_balance + computePendingLocked(user, state),
    }))
    .sort((a, b) => b.liveBalance - a.liveBalance)
    .slice(0, TOP_N);

  const displayNames = await Promise.all(
    sorted.map(({ address }) => getDisplayName(address).catch(() => null)),
  );

  const rows = sorted.map(({ address, user, liveBalance }, idx) => ({
    rank: idx + 1,
    name: displayNames[idx] ?? shortAddress(address),
    balance: formatAmount(liveBalance, asset.decimals, asset.symbol),
    votes: formatVotes(user.votes, asset.decimals),
  }));

  return renderPng(LeaderboardTemplate({ rows }));
};

const app = new Hono();

app.get("/og/leaderboard.png", async () => {
  const png = await pngCache.get("leaderboard", renderLeaderboardPng);
  return pngResponse(png, HEADER_CACHE);
});

export default app;
