import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const LOGO_PATH = path.resolve(here, "../../public/logo.svg");

const svg = readFileSync(LOGO_PATH, "utf8");

export const logoDataUri = `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
