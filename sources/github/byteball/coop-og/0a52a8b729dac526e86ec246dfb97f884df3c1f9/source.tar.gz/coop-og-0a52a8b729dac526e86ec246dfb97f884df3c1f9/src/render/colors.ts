export const colors = {
  bg: "#0a0a0f",
  surface: "#15151c",
  border: "#27272f",
  fg: "#fafafa",
  muted: "#a1a1aa",
  primary: "#fafafa",
  accent: "#3f3f46",
  success: "#22c55e",
  danger: "#ef4444",
} as const;
