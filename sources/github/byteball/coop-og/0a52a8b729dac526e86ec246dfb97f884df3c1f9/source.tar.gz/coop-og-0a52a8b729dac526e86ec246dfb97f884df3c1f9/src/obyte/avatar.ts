import { TtlCache } from "#cache.js";

import { getUserProfile } from "./attestations.js";

const AVATAR_BASE = "https://friends.obyte.org";
const FETCH_TIMEOUT_MS = 5_000;
const AVATAR_TTL_MS = 60 * 60_000;

const avatarCache = new TtlCache<string | null>(AVATAR_TTL_MS);

const tryFetchAsDataUri = async (url: string): Promise<string | null> => {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") ?? "image/png";
    if (!contentType.startsWith("image/")) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length === 0) return null;
    return `data:${contentType};base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
};

const fetchAvatar = async (address: string): Promise<string | null> => {
  const profile = await getUserProfile(address);

  if (profile.tgUserId) {
    const params = new URLSearchParams({ userId: profile.tgUserId });
    if (profile.tgUsername) params.set("username", profile.tgUsername);
    const tg = await tryFetchAsDataUri(
      `${AVATAR_BASE}/api/avatar/tg?${params}`,
    );
    if (tg) return tg;
  }
  if (profile.discordUserId) {
    const params = new URLSearchParams({ userId: profile.discordUserId });
    const dc = await tryFetchAsDataUri(
      `${AVATAR_BASE}/api/avatar/discord?${params}`,
    );
    if (dc) return dc;
  }
  return null;
};

export const getUserAvatar = (address: string): Promise<string | null> =>
  avatarCache.get(address, () => fetchAvatar(address));
