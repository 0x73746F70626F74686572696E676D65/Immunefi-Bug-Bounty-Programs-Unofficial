/**
 * Reject if `promise` does not settle within `ms`. The underlying operation is
 * not cancelled — use this for operations that cannot be aborted (e.g. hub
 * WebSocket requests). For fetch() prefer `AbortSignal.timeout(ms)`, which also
 * aborts the request itself.
 */
export const withTimeout = <T>(
  promise: Promise<T>,
  ms: number,
  label = "operation",
): Promise<T> =>
  new Promise<T>((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error(`${label} timed out after ${ms}ms`)),
      ms,
    );
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err: unknown) => {
        clearTimeout(timer);
        reject(err instanceof Error ? err : new Error(String(err)));
      },
    );
  });
