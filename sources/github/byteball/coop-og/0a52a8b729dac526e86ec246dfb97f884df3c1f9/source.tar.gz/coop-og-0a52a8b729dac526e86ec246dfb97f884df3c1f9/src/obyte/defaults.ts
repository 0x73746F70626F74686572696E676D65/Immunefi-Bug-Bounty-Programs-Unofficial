export const defaultParams = {
  daily_locked_reward: 0.01,
  daily_liquid_reward: 0.001,
  bytes_reducer: 0.75,
  by_votes_share: 0.5,
  referrer_coop_deposit_reward_share: 0.02,
  referrer_bytes_deposit_reward_share: 0.01,
  referral_reward: 10e9,
  min_balance_instead_of_real_name: 1e8,
} as const;

export type AppParamName = keyof typeof defaultParams;
