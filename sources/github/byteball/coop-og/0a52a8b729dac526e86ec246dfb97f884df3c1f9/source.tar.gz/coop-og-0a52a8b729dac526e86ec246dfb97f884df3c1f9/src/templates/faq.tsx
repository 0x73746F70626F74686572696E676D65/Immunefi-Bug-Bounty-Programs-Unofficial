import { Shell } from "./shell.js";

import { colors } from "#render/colors.js";

export const FaqTemplate = () => (
  <Shell>
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 32,
      }}
    >
      <div
        style={{
          fontSize: 96,
          fontWeight: 700,
          letterSpacing: "-0.05em",
          lineHeight: 1.125,
        }}
      >
        FAQ
      </div>
      <div
        style={{
          fontSize: 34,
          color: colors.muted,
          fontWeight: 400,
          maxWidth: 900,
          lineHeight: 1.3,
        }}
      >
        How does COOP work? Who can vote? When do I get rewards? — answers about
        the cooperative protocol.
      </div>
    </div>
  </Shell>
);
