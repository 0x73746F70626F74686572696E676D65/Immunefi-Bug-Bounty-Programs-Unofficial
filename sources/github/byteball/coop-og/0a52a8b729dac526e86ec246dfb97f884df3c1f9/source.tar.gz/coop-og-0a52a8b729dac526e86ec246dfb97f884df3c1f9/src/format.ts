const NUM_FORMATTER = new Intl.NumberFormat("en-US", {
  maximumFractionDigits: 2,
});

export const formatAmount = (
  rawValue: number | undefined,
  decimals: number,
  symbol: string,
): string => {
  const value = typeof rawValue === "number" ? rawValue : 0;
  const scaled = decimals > 0 ? value / 10 ** decimals : value;
  return `${NUM_FORMATTER.format(scaled)} ${symbol}`;
};

export const shortAddress = (address: string): string =>
  address.length > 12 ? `${address.slice(0, 6)}…${address.slice(-4)}` : address;

export const getVotesDivisor = (decimals: number): number =>
  Math.sqrt(10 ** decimals);

export const formatVotes = (raw: number | undefined, decimals: number): number => {
  const value = typeof raw === "number" ? raw : 0;
  return Math.round(value / getVotesDivisor(decimals));
};

