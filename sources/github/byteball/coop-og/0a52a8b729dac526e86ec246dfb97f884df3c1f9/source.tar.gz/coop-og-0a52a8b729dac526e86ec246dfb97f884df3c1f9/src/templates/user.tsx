import { Shell } from "./shell.js";

import { colors } from "#render/colors.js";

interface UserTemplateProps {
  displayName: string;
  shortAddress: string;
  fullAddress: string;
  lockedBalance: string;
  votes: number;
  avatarDataUri: string | null;
}

export const UserTemplate = ({
  displayName,
  shortAddress,
  fullAddress,
  lockedBalance,
  votes,
  avatarDataUri,
}: UserTemplateProps) => {
  const showShort = displayName !== shortAddress && displayName !== fullAddress;
  const AVATAR_SIZE = 120;

  return (
    <Shell>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 12,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 24,
          }}
        >
          {avatarDataUri && (
            <img
              src={avatarDataUri}
              alt=""
              width={AVATAR_SIZE}
              height={AVATAR_SIZE}
              style={{
                borderRadius: AVATAR_SIZE / 2,
                objectFit: "cover",
                border: `1px solid ${colors.border}`,
              }}
            />
          )}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 6,
              minWidth: 0,
            }}
          >
            <div
              style={{
                fontSize: 72,
                fontWeight: 700,
                letterSpacing: "-0.05em",
                lineHeight: 1.125,
                maxWidth: 1000,
                overflow: "hidden",
              }}
            >
              {displayName}
            </div>
            <div
              style={{
                display: "flex",
                fontSize: 26,
                color: colors.muted,
              }}
            >
              {showShort ? shortAddress : ""}
            </div>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: 20,
            marginTop: 36,
          }}
        >
          {[
            { label: "Locked", value: lockedBalance },
            { label: "Votes received", value: String(votes) },
          ].map((stat) => (
            <div
              key={stat.label}
              style={{
                display: "flex",
                flexDirection: "column",
                padding: "24px 28px",
                backgroundColor: colors.surface,
                border: `1px solid ${colors.border}`,
                borderRadius: 18,
                gap: 10,
                flexGrow: 1,
                width: 1,
              }}
            >
              <span style={{ color: colors.muted, fontSize: 22 }}>
                {stat.label}
              </span>
              <span
                style={{
                  fontSize: 40,
                  fontWeight: 700,
                  letterSpacing: -0.5,
                }}
              >
                {stat.value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </Shell>
  );
};
