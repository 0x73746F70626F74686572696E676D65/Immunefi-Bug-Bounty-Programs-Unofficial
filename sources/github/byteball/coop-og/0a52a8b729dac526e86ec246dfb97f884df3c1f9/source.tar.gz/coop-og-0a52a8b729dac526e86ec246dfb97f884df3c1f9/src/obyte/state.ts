import client from "./client.js";

import { env } from "#env.js";

const MAX_ITERATIONS = 25;

export type AaStateVars = Record<string, unknown>;

export const getAllStateVarsByAddress = async (
  address: string,
): Promise<AaStateVars> => {
  const aaState: AaStateVars = {};
  let lastKey = "";

  for (let i = 0; i < MAX_ITERATIONS; i++) {
    const chunkData = (await client.api.getAaStateVars({
      address,
      ...(lastKey && { var_prefix_from: lastKey }),
    })) as AaStateVars;

    const keys = Object.keys(chunkData);

    Object.assign(aaState, chunkData);

    if (keys.length <= 1) break;

    lastKey = keys[keys.length - 1] ?? "";
  }

  return aaState;
};

export interface CoopConstants {
  asset?: string;
  launch_ts?: number;
}

export interface CoopUser {
  balance: number;
  bytes_balance: number;
  total_balance: number;
  unlock_date: string | number | false;
  reg_date?: string;
  reg_ts?: number;
  last_ts?: number;
  votes?: number;
  liquid_balance?: number;
  liquid_rewards?: number;
  last_locked_emissions_per_vote?: number;
  last_liquid_emissions_per_vote?: number;
  last_locked_emissions_per_vb?: number;
  last_liquid_emissions_per_vb?: number;
}

export interface CoopState {
  constants?: CoopConstants;
  users: Record<string, CoopUser>;
  governance: Record<string, number | string>;
  total_locked?: number;
  total_locked_bytes?: number;
  total_votes?: number;
  total_votes_bal?: number;
  locked_emissions_per_vote?: number;
  liquid_emissions_per_vote?: number;
  locked_emissions_per_vb?: number;
  liquid_emissions_per_vb?: number;
  ts?: number;
}

const USER_PREFIX = "user_";

export const parseCoopState = (vars: AaStateVars): CoopState => {
  const state: CoopState = { users: {}, governance: {} };

  const numericFields = [
    "total_locked",
    "total_locked_bytes",
    "total_votes",
    "total_votes_bal",
    "locked_emissions_per_vote",
    "liquid_emissions_per_vote",
    "locked_emissions_per_vb",
    "liquid_emissions_per_vb",
    "ts",
  ] as const;

  for (const [key, raw] of Object.entries(vars)) {
    if (key === "constants" && raw && typeof raw === "object") {
      state.constants = raw;
      continue;
    }
    if (key === "state" && raw && typeof raw === "object") {
      const nested = raw as Record<string, unknown>;
      for (const field of numericFields) {
        const value = nested[field];
        if (typeof value === "number") state[field] = value;
      }
      continue;
    }
    if (key.startsWith(USER_PREFIX) && raw && typeof raw === "object") {
      const address = key.slice(USER_PREFIX.length);
      state.users[address] = raw as CoopUser;
      continue;
    }
    if (typeof raw === "number" || typeof raw === "string") {
      state.governance[key] = raw;
    }
  }

  return state;
};

export const getCoopState = async (): Promise<CoopState> => {
  const vars = await getAllStateVarsByAddress(env.AA_ADDRESS);
  return parseCoopState(vars);
};
