export const pngResponse = (png: Buffer, cacheControl: string): Response =>
  new Response(new Uint8Array(png.buffer, png.byteOffset, png.byteLength), {
    status: 200,
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": cacheControl,
    },
  });
