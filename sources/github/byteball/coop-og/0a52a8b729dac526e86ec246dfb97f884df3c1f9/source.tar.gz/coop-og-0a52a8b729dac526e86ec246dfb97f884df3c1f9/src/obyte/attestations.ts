import { TtlCache } from "#cache.js";

import { attestors } from "./attestors.js";
import client from "./client.js";

const tgSet = new Set<string>(attestors.telegram);
const discordSet = new Set<string>(attestors.discord);
const realNameSet = new Set<string>(attestors.realName);

interface RawAttestation {
  attestor_address: string;
  profile: Record<string, unknown>;
}

export interface UserProfile {
  displayName: string | null;
  tgUserId: string | null;
  tgUsername: string | null;
  discordUserId: string | null;
}

const EMPTY: UserProfile = {
  displayName: null,
  tgUserId: null,
  tgUsername: null,
  discordUserId: null,
};

const pickString = (
  profile: Record<string, unknown> | null,
  field: string,
): string | null => {
  if (!profile) return null;
  const value = profile[field];
  if (typeof value === "string" && value.length > 0) return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return null;
};

const pickUserId = (profile: Record<string, unknown> | null): string | null =>
  pickString(profile, "userId") ?? pickString(profile, "user_id");

const hasUserId = (profile: Record<string, unknown>): boolean =>
  pickUserId(profile) != null;

const hasUsername = (profile: Record<string, unknown>): boolean =>
  pickString(profile, "username") != null;

// How complete an identity an attestation carries. A profile with BOTH a userId
// and a username is the most useful (avatar lookup + display name), so it must
// win over one that has only an id or only a username.
const completeness = (profile: Record<string, unknown>): number =>
  (hasUserId(profile) ? 1 : 0) + (hasUsername(profile) ? 1 : 0);

// A user can hold several attestations in the same category (e.g. an old one
// with only a username and a newer one that also carries the userId consumers
// need for avatar lookups). Keep the first match, but upgrade to a strictly
// more complete profile — an id-only or username-only slot is replaced by one
// that has both. Mirrors the coop-ui parseAttestations logic so both render the
// same identity.
const merge = (
  current: Record<string, unknown> | null,
  next: Record<string, unknown>,
): Record<string, unknown> => {
  if (!current) return next;
  return completeness(next) > completeness(current) ? next : current;
};

const parseProfile = (raw: RawAttestation[]): UserProfile => {
  let telegram: Record<string, unknown> | null = null;
  let discord: Record<string, unknown> | null = null;
  let realName: Record<string, unknown> | null = null;

  for (const att of raw) {
    if (!telegram && tgSet.has(att.attestor_address)) {
      telegram = att.profile;
    } else if (discordSet.has(att.attestor_address)) {
      discord = merge(discord, att.profile);
    } else if (realNameSet.has(att.attestor_address)) {
      realName = merge(realName, att.profile);
    } else if (tgSet.has(att.attestor_address)) {
      telegram = merge(telegram, att.profile);
    }
  }

  const displayName =
    pickString(telegram, "username") ??
    pickString(discord, "username") ??
    pickString(realName, "username");

  return {
    displayName,
    tgUserId: pickUserId(telegram),
    tgUsername: pickString(telegram, "username"),
    discordUserId: pickUserId(discord),
  };
};

const PROFILE_TTL_MS = 60 * 60_000;
const profileCache = new TtlCache<UserProfile>(PROFILE_TTL_MS);

const fetchProfile = async (address: string): Promise<UserProfile> => {
  const raw = (await client.api
    .getAttestations({ address })
    .catch(() => [] as RawAttestation[])) as RawAttestation[];
  return parseProfile(Array.isArray(raw) ? raw : []);
};

export const getUserProfile = (address: string): Promise<UserProfile> =>
  profileCache.get(address, () => fetchProfile(address)).catch(() => EMPTY);

export const getDisplayName = async (address: string): Promise<string | null> =>
  (await getUserProfile(address)).displayName;
