/*jslint node: true */
"use strict";
const check_daemon = require('ocore/check_daemon.js');

check_daemon.checkDaemonAndNotify('node start.js obyte-gov-discord');

