import sharp from "sharp";

import { getBasicTemplate } from "../templates/basic";
import { getUnitTemplate } from "../templates/unit";
import { getUserTemplate } from "../templates/user";

export interface IUnitOptions {
  house?: number;
  plot?: number;
}

export const getOgImageData = async (page: string, unitOptions: IUnitOptions | undefined, address?: string): Promise<Buffer<ArrayBufferLike>> => {

  let title = page;

  if (title === "faq") {
    title = "F.A.Q.";
  }

  title = title.charAt(0).toUpperCase() + title.slice(1);

  let svg: string = "";

  if (page === "unit") {
    if (unitOptions && (unitOptions.house || unitOptions.plot)) {
      svg = await getUnitTemplate(unitOptions);
    } else {
      svg = getBasicTemplate('A community engagement \n space for Obyte', true);
    }

  } else if (page === "claim") {
    svg = getBasicTemplate('You are neighbors', true);
  } else if (page === "user") {
    if(!address || typeof address !== 'string') throw new Error('address is required for user page');

    svg = await getUserTemplate(address);
  } else {
    svg = getBasicTemplate(title);
  }


  const b = Buffer.from(svg);

  let image: Buffer<ArrayBufferLike>;

  try {
    image = await sharp(b).jpeg().toBuffer();
  } catch (e) {
    console.error(e);
    throw e;
  }

  return image;
};