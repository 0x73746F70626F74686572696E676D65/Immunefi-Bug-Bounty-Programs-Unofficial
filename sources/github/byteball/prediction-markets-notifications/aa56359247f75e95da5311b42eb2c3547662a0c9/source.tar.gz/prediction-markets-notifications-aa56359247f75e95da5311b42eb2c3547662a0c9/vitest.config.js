import { defineConfig } from 'vitest/config';

export default defineConfig({
    test: {
        environment: 'node',
        include: ['tests/**/*.test.js'],
        setupFiles: ['tests/setup.js'],
        clearMocks: true,
        restoreMocks: true,
        server: {
            deps: {
                inline: true,
            },
        },
    },
});
