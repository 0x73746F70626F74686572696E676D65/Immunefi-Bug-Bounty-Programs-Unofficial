interface ILoadingProps {
  fullscreen?: boolean;
}
