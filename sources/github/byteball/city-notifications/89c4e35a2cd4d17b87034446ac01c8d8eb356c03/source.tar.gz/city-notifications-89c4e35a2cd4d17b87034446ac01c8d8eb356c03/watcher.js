"use strict";
const _ = require('lodash');

const eventBus = require('ocore/event_bus.js');
const conf = require('ocore/conf.js');
const network = require('ocore/network.js');
const storage = require("ocore/storage.js");
const db = require("ocore/db.js");
const walletGeneral = require("ocore/wallet_general.js");
const light_wallet = require("ocore/light_wallet.js");
const constants = require("ocore/constants.js");
const formulaEvaluation = require("ocore/formula/evaluation.js");

const dag = require('aabot/dag.js');
const operator = require('aabot/operator.js');
const aa_state = require('aabot/aa_state.js');

const discordInstance = require('./discordInstance');
const telegramInstance = require('./telegramInstance');

const website = 'https://city.obyte.org';

const followup_reward_days = [
	['1st', 60],
	['2nd', 150],
	['3rd', 270],
	['4th', 450],
	['5th', 720],
	['6th', 1080],
	['7th', 1620],
];

let notifiedPlots = {};
let notifiedPaidFU = {};
let bHaveMembers = false;

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

async function onAAResponse(objAAResponse) {
	const { aa_address, trigger_unit, trigger_address, bounced, response } = objAAResponse;
	if (bounced && trigger_address === operator.getAddress())
		return console.log(`=== our request ${trigger_unit} bounced with error`, response.error);
	if (bounced)
		return console.log(`request ${trigger_unit} bounced with error`, response.error);
	handleAAResponse(objAAResponse);
}

async function onAARequest(objAARequest, arrResponses) {
	const address = objAARequest.unit.authors[0].address;
	if (address === operator.getAddress())
		return console.log(`skipping our own request`);
	if (arrResponses[0].bounced)
		return console.log(`trigger ${objAARequest.unit.unit} from ${address} will bounce`, arrResponses[0].response.error);
	const aas = arrResponses.map(r => r.aa_address);
	console.log(`request from ${address} trigger ${objAARequest.unit.unit} affected AAs`, aas);
	for (let objAAResponse of arrResponses)
		handleAAResponse(objAAResponse, true)
}

function handleAAResponse(objAAResponse, bEstimated) {
	const { aa_address, response: { responseVars } } = objAAResponse;
	if (aa_address === conf.city_aa && responseVars) {
		const { event, events } = responseVars;
		if (event) {
			const objEvent = JSON.parse(event);
			console.log('city event', objEvent);
			const { type } = objEvent;
			if (type === 'allocate') {
				const { plot_num, city, x, y } = objEvent;
				console.log(`new plot ${plot_num} in ${city} at ${x}:${y}`);
				if (typeof plot_num !== 'number')
					throw Error(`plot_num ${plot_num} not a number`);
				checkForNeighbors(plot_num);
			}
			else if (type === 'followup') {
				const { house1_num, house2_num, reward } = objEvent;
				notifyAboutPaidFollowupRewards(house1_num, house2_num, reward);
			}
			else
				console.log(`not an allocation or followup event`);
		}
		else if (events) {
			const arrEvents = JSON.parse(events);
			console.log('build events', arrEvents);
			notifyAboutRewards(arrEvents, bEstimated);
		}
		else
			console.log(`no event from city`);
	}
}

async function checkForNeighbors(plot_num) {
	console.log(`checking for neighbors of ${plot_num}`);
	const aa_unlock = await aa_state.lock();
	let upcomingStateVars = _.cloneDeep(aa_state.getUpcomingStateVars());
	let upcomingBalances = _.cloneDeep(aa_state.getUpcomingBalances());
	const vars = aa_state.getUpcomingAAStateVars(conf.city_aa);
	const plot = vars['plot_' + plot_num];
	if (!plot)
		throw Error(`plot ${plot_num} not found`);
	const { city, owner, status } = plot;
	if (status !== 'land')
		return aa_unlock(`plot ${plot_num} in ${city} is ${status}`);
	console.log(`checking for neighbors of ${plot_num} in ${city}`);
	let neighbor_plot_num;
	for (let name in vars) {
		const m = name.match(/^plot_(\d+)$/);
		if (m) {
			const plot1_num = +m[1];
			const plot1 = vars[name];
			if (plot1.city === city && plot1.status === 'land' && plot1_num < plot_num) {
				console.log(`will check if ${name} is a neighbor of ${plot_num}`);
				if (plot1.owner === owner) {
					console.log(`plots ${name} and ${plot_num} have the same owner`);
					continue;
				}
				try {
					const bNeighbors = await formulaEvaluation.executeGetterInState(db, conf.city_aa, 'are_neighbors', [plot1_num, plot_num], upcomingStateVars, upcomingBalances);
					console.log(`plots ${plot1_num} and ${plot_num} are neighbors? ${bNeighbors}`);
					if (bNeighbors) {
						neighbor_plot_num = plot1_num;
						break;
					}
				}
				catch (e) {
					console.log(`are_neighbors failed`, plot1_num, plot_num, e);
				//	neighbor_plot_num = plot1_num;
				//	break;
				}
			}
		}
	}
	aa_unlock();
	if (neighbor_plot_num) {
		await notifyNeighbors(neighbor_plot_num, plot_num);
	}
	await db.query("UPDATE node_vars SET value=? WHERE name='last_plot_num'", [plot_num]);
	console.log(`done checking for neighbors of ${plot_num} in ${city}`);
}

async function getDiscordChannelAndGuild(tries = 0) {
	const channel = await discordInstance.channels.fetch(conf.DISCORD_CHANNEL_ID);
	if (!channel)
		throw Error(`failed to get discord channel`);
		
	const guild = channel.guild;
	if (!guild) throw Error('server not found');
	
	try {
		await guild.members.fetch();
		bHaveMembers = true;
	}
	catch (e) {
		console.log(`guild.members.fetch failed`, e);
		if (!bHaveMembers) {
			if (tries > 10)
				throw e;
			return await getDiscordChannelAndGuild(tries + 1);
		}
	}
	
	return { channel, guild };
}

async function sendDiscordMessage(channel, content) {
	await channel.send({
		content,
		allowedMentions: { parse: ['users'] }
	});
	
	return true;
}

async function formatDiscordMention(guild, username) {
	const discordMember = guild.members.cache.find(m => m.user.username === username);
	return discordMember ? `<@${discordMember.user.id}>` : '@' + username;
}


async function notifyNeighbors(plot1_num, plot2_num) {
	if (notifiedPlots[plot2_num])
		return console.log(`already notified about plot ${plot2_num} matching`);
	const vars = aa_state.getUpcomingAAStateVars(conf.city_aa);
	const plot1 = vars['plot_' + plot1_num];
	const plot2 = vars['plot_' + plot2_num];
	const usernames1 = await getUsernames(plot1.owner);
	const usernames2 = await getUsernames(plot2.owner);
	console.log({ usernames1, usernames2 });
	let bSent = false;

	const claimUrl = `${website}/claim/${plot1_num}-${plot2_num}`;
	const messageText = `you became neighbors! Each of you gets two new empty plots and a house on the old one. You both need to claim the new plots and the house at ${claimUrl} within 10 minutes of each other. You can do this at any time (but not too late as the matching area around your plots might reduce due to more plots being bought). Please message each other to agree when you send your claiming transactions.`;

	if (usernames1.discord && usernames2.discord) {
		const { channel, guild } = await getDiscordChannelAndGuild();
		const member1Mention = await formatDiscordMention(guild, usernames1.discord);
		const member2Mention = await formatDiscordMention(guild, usernames2.discord);

		await sendDiscordMessage(channel, `${member1Mention} ${member2Mention} ${messageText}`);
		bSent = true;
	}

	if (usernames1.telegram && usernames2.telegram) {
		const tagUsersForMessage = `${telegramInstance.formatTagUser(usernames1.telegram)} ${telegramInstance.formatTagUser(usernames2.telegram)}`;

		await telegramInstance.sendMessage(`${tagUsersForMessage} ${messageText}`);
		bSent = true;
	}

	// users are on different networks
	if (
		usernames1.discord && !usernames1.telegram && !usernames2.discord && usernames2.telegram
		||
		usernames2.discord && !usernames2.telegram && !usernames1.discord && usernames1.telegram
	) {
		if (bSent)
			throw Error(`already sent ${plot1_num} and ${plot2_num}`);

		const discordUsername = usernames1.discord || usernames2.discord;
		const telegramUsername = usernames1.telegram || usernames2.telegram;

		// discord
		const { channel, guild } = await getDiscordChannelAndGuild();
		const discordMentionForDS = await formatDiscordMention(guild, discordUsername);
		await sendDiscordMessage(channel, `${discordMentionForDS} and telegram user @${telegramUsername} ${messageText}`);

		// telegram
		const telegramMentionForTG = telegramInstance.formatTagUser(telegramUsername);
		await telegramInstance.sendMessage(`${telegramMentionForTG} and discord user @${discordUsername} ${messageText}`);
		bSent = true;
	}

	if (!bSent)
		console.error(`not notified about plots ${plot1_num} and ${plot2_num}`, usernames1, usernames2);

	notifiedPlots[plot2_num] = true;
}

async function notifyAboutRewards(arrEvents, bEstimated) {
	const { owner: address1, house_num: house_num1 } = arrEvents[0];
	const { owner: address2, house_num: house_num2 } = arrEvents[1];
	const { plot_num: plot_num11, amount } = arrEvents[2];
	const { plot_num: plot_num12 } = arrEvents[3];
	const { plot_num: plot_num21 } = arrEvents[4];
	const { plot_num: plot_num22 } = arrEvents[5];

	const getText = (mention1, mention2) => {
		const both = mention1.includes(' user ') // reorder
			? `${mention2} and ${mention1}`
			: `${mention1} and ${mention2}`;
		if (bEstimated)
			return `${both} you've claimed your rewards! The links to your new houses and plots will become known in a few minutes, please wait.`;
		return `${both} you've claimed your rewards! ${mention1} receives house ${website}/?house=${house_num1} and plots ${website}/?plot=${plot_num11} and ${website}/?plot=${plot_num12}, ${mention2} receives house ${website}/?house=${house_num2} and plots ${website}/?plot=${plot_num21} and ${website}/?plot=${plot_num22}. There are ${amount / 1e9} CITY on each new plot. You can claim your first follow-up rewards of ${0.1 * amount / 1e9} CITY in 60 days. Congratulations!`;
	};

	await notify(address1, address2, getText);
}

async function notify(address1, address2, getText) {
	let usernames = {
		[address1]: await getUsernames(address1),
		[address2]: await getUsernames(address2),
	};
	const { channel, guild } = await getDiscordChannelAndGuild();
	let mentions = {};
	for (let address in usernames) {
		const { discord, telegram } = usernames[address];
		mentions[address] = {
			discord: discord ? await formatDiscordMention(guild, discord) : `telegram user @${telegram}`,
			telegram: telegram ? await telegramInstance.formatTagUser(telegram) : `discord user @${discord}`,
		};
	}

	let bSent = false;
	if (usernames[address1].discord && usernames[address2].discord) {
		await sendDiscordMessage(channel, getText(mentions[address1].discord, mentions[address2].discord));
		bSent = true;
	}
	
	if (usernames[address1].telegram && usernames[address2].telegram) {		
		await telegramInstance.sendMessage(getText(mentions[address1].telegram, mentions[address2].telegram));
		bSent = true;
	}

	// users are on different networks
	if (
		usernames[address1].discord && !usernames[address1].telegram && !usernames[address2].discord && usernames[address2].telegram
		||
		usernames[address2].discord && !usernames[address2].telegram && !usernames[address1].discord && usernames[address1].telegram
	) {
		if (bSent)
			throw Error(`already sent to ${address1} and ${address2}`);
		await sendDiscordMessage(channel, getText(mentions[address1].discord, mentions[address2].discord));
		await telegramInstance.sendMessage(getText(mentions[address1].telegram, mentions[address2].telegram));
		bSent = true;
	}

	if (!bSent)
		console.error(`not notified`, usernames);
}

// get usernames of a user on discord, telegram, etc
async function getUsernames(address) {
	const rows = await db.query("SELECT attested_fields.attestor_address, messages.payload FROM messages INNER JOIN attested_fields USING(unit, message_index) WHERE attested_fields.attestor_address IN(?) AND attested_fields.address=? AND attested_fields.field='username' ORDER BY attested_fields.rowid DESC", [Object.keys(conf.attestors), address]);
	if (rows.length === 0)
		throw Error(`no attestations for ${address}`);

	let usernames = {};
	let tgId;

	for (let { attestor_address, payload } of rows) {
		const profile = JSON.parse(payload).profile;
		const service = conf.attestors[attestor_address];

		for (const [field, value] of Object.entries(profile)) {
			if (service === 'telegram' && field === 'userId') {
				if (tgId) continue;
				tgId = value;
				continue;
			}

			if (!usernames[service] && field === 'username') // the later attestation has precedence
				usernames[service] = value;
		}
	}

	if (tgId) {
		const newUsername = telegramInstance.getUsernameById(tgId);

		if (newUsername)
			usernames.telegram = newUsername;
	}

	return usernames;
}

async function loadLibs() {
	for (let address of conf.lib_aas) {
	//	await dag.loadAA(address);
		const definition = await dag.readAADefinition(address);
		const payload = { address, definition };
		await storage.insertAADefinitions(db, [payload], constants.GENESIS_UNIT, 0, false);
	}
}




function initAsset() {
	const vars = aa_state.getAAStateVars(conf.city_aa);
	const asset = vars.constants?.asset;
	if (!asset)
		throw Error(`asset not defined yet in ${conf.city_aa}`);
	network.requestHistoryFor([asset]);
}

async function checkForMissedNeighbors() {
	console.log(`checking for missed neighbors`);
	await db.query(`CREATE TABLE IF NOT EXISTS node_vars (
		name VARCHAR(30) NOT NULL PRIMARY KEY,
		value TEXT NOT NULL,
		last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
	)`);
	await db.query(`INSERT OR IGNORE INTO node_vars (name, value) VALUES ('last_plot_num', 0)`);
	const [{ value: last_seen_plot_num }] = await db.query("SELECT value FROM node_vars WHERE name='last_plot_num'");
	const vars = aa_state.getAAStateVars(conf.city_aa);
	const last_plot_num = vars.state.last_plot_num;
	for (let plot_num = +last_seen_plot_num + 1; plot_num <= last_plot_num; plot_num++){
		const plot = vars['plot_' + plot_num];
		if (plot)
			await checkForNeighbors(plot_num);
	}
	console.log(`done checking for missed neighbors`);
}


function getFollowupRewardInfo(elapsed_days, bWithExpiry) {
	for (let i = followup_reward_days.length - 1; i >= 0; i--) {
		const [fu_reward_number, days] = followup_reward_days[i];
		if (elapsed_days >= days && (!bWithExpiry || elapsed_days <= days + 10))
			return { fu_reward_number, days, next_days: followup_reward_days[i + 1] ? followup_reward_days[i + 1][1] : null };
	}
	return {};
}

async function checkForFollowups() {
	console.log(`checking for followups`);
	const vars = aa_state.getAAStateVars(conf.city_aa);

	function getHouseByPlotNum(plot_num) {
		for (let name in vars) {
			const m = name.match(/^house_(\d+)$/);
			if (m) {
				const house = vars[name];
				if (house.plot_num === plot_num) {
					const house_num = +m[1];
					return { ...house, house_num };
				}
			}
		}
		throw Error(`no house found by plot ${plot_num}`);
	}

	for (let name in vars) {
		const m = name.match(/^match_(\d+)_(\d+)$/);
		if (m) {
			const plot1_num = +m[1];
			const plot2_num = +m[2];
			const match = vars[name];
			if (!match.built_ts) {
				console.log(`houses not built`, name);
				continue;
			}
			const elapsed_days = (Date.now() / 1000 - match.built_ts) / 3600 / 24;
			const { fu_reward_number, days } = getFollowupRewardInfo(elapsed_days, true);
			if (!fu_reward_number) continue;
			const { house_num: house1_num, owner: owner1, amount } = getHouseByPlotNum(plot1_num);
			const { house_num: house2_num, owner: owner2 } = getHouseByPlotNum(plot2_num);
			const rows = await db.query("SELECT 1 FROM sent_followup_notifications WHERE house1_num=? AND house2_num=? AND reward_number=?", [house1_num, house2_num, fu_reward_number]);
			if (rows.length > 0) {
				console.log(`${fu_reward_number} followup reward notification already sent to houses ${house1_num}-${house2_num} (plots ${plot1_num}-${plot2_num})`);
				continue;
			}
			const fu = vars['followup_' + house1_num + '_' + house2_num];
			const reward = fu ? fu.reward : Math.floor(amount * vars.variables.followup_reward_share);

			const getText = (mention1, mention2) => {
				const both = mention1.includes(' user ') // reorder
					? `${mention2} and ${mention1}`
					: `${mention1} and ${mention2}`;
				const claimUrl = `${website}/followup/${house1_num}-${house2_num}`;
				return `${both} you are eligible for your ${fu_reward_number} follow-up reward after becoming neighbors ${days} days ago. Each of you gets ${reward / 1e9} CITY. You both need to claim the rewards at ${claimUrl} within 10 minutes of each other, like you claimed your initial rewards. Please claim the rewards within 10 days, otherwise they'll be lost. The rewards will be added to your accounts and can be used to buy new plots. Please message each other to agree when you send your claiming transactions.`;
			};

			await notify(owner1, owner2, getText);
			await db.query("INSERT INTO sent_followup_notifications (house1_num, house2_num, reward_number) VALUES (?,?,?)", [house1_num, house2_num, fu_reward_number]);
			console.log(`notified houses ${house1_num}-${house2_num} about the ${fu_reward_number} followup reward`);
		}
	}
	console.log(`done checking for followups`);
}


async function notifyAboutPaidFollowupRewards(house1_num, house2_num, reward) {
	const vars = aa_state.getUpcomingAAStateVars(conf.city_aa);
	const house1 = vars['house_' + house1_num];
	const house2 = vars['house_' + house2_num];
	const match = vars['match_' + house1.plot_num + '_' + house2.plot_num];
	if (!match) throw Error(`no match for ${house1_num}-${house2_num}`);
	const elapsed_days = (Date.now() / 1000 - match.built_ts) / 3600 / 24;
	const { fu_reward_number, days, next_days } = getFollowupRewardInfo(elapsed_days);
	if (!fu_reward_number)
		throw Error(`unrecognized followup reward by ${house1_num}-${house2_num}`);
	const key = house1_num + '-' + fu_reward_number;
	if (notifiedPaidFU[key])
		return console.log(`already notified houses ${house1_num}-${house2_num} about the ${fu_reward_number} followup reward`);

	const getText = (mention1, mention2) => {
		const both = mention1.includes(' user ') // reorder
			? `${mention2} and ${mention1}`
			: `${mention1} and ${mention2}`;
		let text = `${both} you've claimed your ${fu_reward_number} follow-up rewards, congratulations! A ${reward / 1e9} CITY reward has been added to each of your accounts. You can use these follow-up rewards to buy new plots as soon as you accumulate the sufficient amount.`;
		if (next_days)
			text += ` The next follow-up reward will be available in ${next_days - days} days.`;
		return text;
	};

	await notify(house1.owner, house2.owner, getText);
	notifiedPaidFU[key] = true;
}


// wait until all the addresses added in addWatchedAddress() are processed
async function waitForUnprocessedAddresses() {
	while (true) {
		const rows = await db.query("SELECT address FROM unprocessed_addresses");
		if (rows.length === 0)
			return;
		console.log(`still have unprocessed addresses, will wait`, rows);
		await sleep(1000);
	}
}

async function startWatching() {
	await loadLibs();

	if (!conf.DISCORD_BOT_TOKEN) throw new Error('error: DISCORD_BOT_TOKEN is required');
	if (!conf.DISCORD_CHANNEL_ID) throw new Error('error: DISCORD_CHANNEL_ID is required');
	if (!conf.TELEGRAM_BOT_TOKEN) throw new Error('error: TELEGRAM_BOT_TOKEN is required');
	if (!conf.TELEGRAM_CHANNEL_USERNAME) throw new Error('error: TELEGRAM_CHANNEL_USERNAME is required');
	if (!conf.TELEGRAM_APPID) throw new Error('error: TELEGRAM_APPID is required');
	if (!conf.TELEGRAM_APIHASH) throw new Error('error: TELEGRAM_APIHASH is required');

	await discordInstance.login(conf.DISCORD_BOT_TOKEN);
	await telegramInstance.startBot();
	
	eventBus.on("aa_request_applied", onAARequest);
	eventBus.on("aa_response_applied", onAAResponse);

	await aa_state.followAA(conf.city_aa);
	await aa_state.followAA(conf.vrf_oracle_aa);

	await light_wallet.waitUntilFirstHistoryReceived();
	console.log('first history received');

	for (let address in conf.attestors)
		walletGeneral.addWatchedAddress(address);

	initAsset();
	
	await waitForUnprocessedAddresses(); // for update attestors history

	await checkForMissedNeighbors();

	await checkForFollowups();
	setInterval(checkForFollowups, 12 * 3600_000);
}

exports.startWatching = startWatching;
