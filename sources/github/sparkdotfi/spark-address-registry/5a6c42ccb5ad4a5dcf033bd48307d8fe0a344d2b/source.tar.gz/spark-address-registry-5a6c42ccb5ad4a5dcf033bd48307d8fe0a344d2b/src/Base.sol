// SPDX-License-Identifier: AGPL-3.0-or-later
pragma solidity >=0.8.0;

library Base {

    /*******************************************************************************************************************

    ███████╗██████╗  █████╗ ██████╗ ██╗  ██╗     █████╗ ██╗   ██╗████████╗██╗  ██╗ ██████╗ ██████╗ ███████╗██████╗
    ██╔════╝██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝    ██╔══██╗██║   ██║╚══██╔══╝██║  ██║██╔═══██╗██╔══██╗██╔════╝██╔══██╗
    ███████╗██████╔╝███████║██████╔╝█████╔╝     ███████║██║   ██║   ██║   ███████║██║   ██║██████╔╝█████╗  ██║  ██║
    ╚════██║██╔═══╝ ██╔══██║██╔══██╗██╔═██╗     ██╔══██╗██║   ██║   ██║   ██╔══██║██║   ██║██╔══██╗██╔══╝  ██║  ██║
    ███████║██║     ██║  ██║██║  ██║██║  ██╗    ██║  ██║╚██████╔╝   ██║   ██║  ██║╚██████╔╝██║  ██║███████╗██████╔╝
    ╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝

    /******************************************************************************************************************/
    /*** Governance Relay addresses                                                                                 ***/
    /******************************************************************************************************************/

    address internal constant SPARK_EXECUTOR = 0xF93B7122450A50AF3e5A76E1d546e95Ac1d0F579;  // spark-gov-relay/Executor.sol@5c16676 (v1.0.1)
    address internal constant SPARK_RECEIVER = 0xfda082e00EF89185d9DB7E5DcD8c5505070F5A3B;  // xchain-helpers/OptimismReceiver.sol@07e27b6 (v1.0.0)

    /******************************************************************************************************************/
    /*** Spark Liquidity Layer addresses                                                                            ***/
    /******************************************************************************************************************/

    address internal constant ALM_CONTROLLER      = 0x86036CE5d2f792367C0AA43164e688d13c5A60A8;  // spark-alm-controller/ForeignController.sol@7be9593 (v1.8.0)
    address internal constant ALM_PROXY           = 0x2917956eFF0B5eaF030abDB4EF4296DF775009cA;  // spark-alm-controller/ALMProxy.sol@6058f68 (v1.0.0)
    address internal constant ALM_PROXY_FREEZABLE = 0x92d7B06e5844e67174AE9E86bdCb06428482DDF9;  // diamond-pau/ALMProxyFreezable.sol@a84fe96 (v1.12.0)
    address internal constant ALM_RATE_LIMITS     = 0x983eC82E45C61a42FDDA7B3c43B8C767004c8A74;  // spark-alm-controller/RateLimits.sol@6058f68 (v1.0.0)

    /******************************************************************************************************************/
    /*** PSM addresses                                                                                              ***/
    /******************************************************************************************************************/

    address internal constant PSM3 = 0x1601843c5E9bC251A3272907010AFa41Fa18347E;  // spark-psm/PSM3.sol@6a5a579 (v1.0.0)

    /******************************************************************************************************************/
    /*** SSR Oracle addresses                                                                                       ***/
    /******************************************************************************************************************/

    address internal constant SSR_AUTH_ORACLE             = 0x65d946e533748A998B1f0E430803e39A6388f7a1;  // xchain-ssr-oracle/SSRAuthOracle.sol@dc9fc30 (v1.2.0)
    address internal constant SSR_BALANCER_RATE_PROVIDER  = 0x49aF4eE75Ae62C2229bb2486a59Aa1a999f050f0;  // xchain-ssr-oracle/SSRBalancerRateProviderAdapter.sol@dc9fc30 (v1.2.0)
    address internal constant SSR_CHAINLINK_RATE_PROVIDER = 0x026a5B6114431d8F3eF2fA0E1B2EDdDccA9c540E;  // xchain-ssr-oracle/SSRChainlinkRateProviderAdapter.sol@466595d (v1.2.1)
    address internal constant SSR_RECEIVER                = 0x212871A1C235892F86cAB30E937e18c94AEd8474;  // xchain-helpers/OptimismReceiver.sol@07e27b6 (v1.0.0)

    /******************************************************************************************************************/
    /*** DSR Oracle addresses                                                                                       ***/
    /******************************************************************************************************************/

    address internal constant DSR_AUTH_ORACLE            = 0x2Dd2a2Fe346B5704380EfbF6Bd522042eC3E8FAe;  // xchain-ssr-oracle/DSRAuthOracle.sol@463e012 (v1.0.0-beta.2, audited: ChainSecurity/SparkDAO 2024-07-24)
    address internal constant DSR_RECEIVER               = 0xaDEAf02Ddb5Bed574045050B8096307bE66E0676;  // xchain-ssr-oracle/DSROracleReceiverOptimism.sol@463e012 (v1.0.0-beta.2, audited: ChainSecurity/SparkDAO 2024-07-24)
    address internal constant DSR_BALANCER_RATE_PROVIDER = 0xeC0C14Ea7fF20F104496d960FDEBF5a0a0cC14D0;  // xchain-ssr-oracle/DSRBalancerRateProviderAdapter.sol@463e012 (v1.0.0-beta.2, audited: ChainSecurity/SparkDAO 2024-07-24)

    /******************************************************************************************************************/
    /*** Spark Vault V1 addresses                                                                                   ***/
    /******************************************************************************************************************/

    address internal constant SUSDC      = 0x3128a0F7f0ea68E7B7c9B00AFa7E41045828e858;  // openzeppelin-contracts-upgradeable/ERC1967Proxy.sol@723f8cab (v5.0.2)
    address internal constant SUSDC_IMPL = 0x6ACC02ddd82206a44ff4EC13977E63d1a29C7723;  // spark-vaults/UsdcVaultL2.sol@78d37c8

    /*******************************************************************************************************************

    ███████╗██████╗  █████╗ ██████╗ ██╗  ██╗    ███╗   ███╗ █████╗ ███╗   ██╗ █████╗  ██████╗ ███████╗██████╗
    ██╔════╝██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝    ████╗ ████║██╔══██╗████╗  ██║██╔══██╗██╔════╝ ██╔════╝██╔══██╗
    ███████╗██████╔╝███████║██████╔╝█████╔╝     ██╔████╔██║███████║██╔██╗ ██║███████║██║  ███╗█████╗  ██╔══██╗
    ╚════██║██╔═══╝ ██╔══██║██╔══██╗██╔═██╗     ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══██║██║   ██║██╔══╝  ██║  ██║
    ███████║██║     ██║  ██║██║  ██║██║  ██╗    ██║ ╚═╝ ██║██║  ██║██║ ╚████║██║  ██║╚██████╔╝███████╗██████╔╝
    ╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═════╝

    /******************************************************************************************************************/
    /*** Multisig addresses                                                                                         ***/
    /******************************************************************************************************************/

    address internal constant ALM_BACKSTOP_RELAYER_MULTISIG = 0x8Cc0Cb0cfB6B7e548cfd395B833c05C346534795;
    address internal constant ALM_FREEZER_MULTISIG          = 0x90D8c80C028B4C09C0d8dcAab9bbB057F0513431;
    address internal constant ALM_RELAYER_MULTISIG          = 0x8a25A24EDE9482C4Fc0738F99611BE58F1c839AB;

    address internal constant SPARK_REWARDS_MULTISIG = 0xF649956f43825d4d7295a50EDdBe1EDC814A3a83;

    address internal constant MORPHO_CURATOR_MULTISIG  = 0x0f963A8A8c01042B69054e787E5763ABbB0646A3;
    address internal constant MORPHO_GUARDIAN_MULTISIG = 0xf5748bBeFa17505b2F7222B23ae11584932C908B;

    /******************************************************************************************************************/
    /*** Morpho Vault addresses                                                                                     ***/
    /******************************************************************************************************************/

    address internal constant MORPHO_VAULT_SUSDC = 0x7BfA7C4f149E7415b73bdeDfe609237e29CBF34A;

    /*******************************************************************************************************************

    ███████╗██╗  ██╗████████╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗
    ██╔════╝╚██╗██╔╝╚══██╔══╝██╔════╝██╔══██╗████╗  ██║██╔══██╗██║
    █████╗   ╚███╔╝    ██║   █████╗  ██████╔╝██╔██╗ ██║███████║██║
    ██╔══╝   ██╔██╗    ██║   ██╔══╝  ██╔══██╗██║╚██╗██║██╔══██║██║
    ███████╗██╔╝ ██╗   ██║   ███████╗██║  ██║██║ ╚████║██║  ██║███████╗
    ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝

    /******************************************************************************************************************/
    /*** Token addresses                                                                                            ***/
    /******************************************************************************************************************/

    address internal constant CBBTC = 0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf;
    address internal constant SKY   = 0x60e3c701e65DEE30c23c9Fb78c3866479cc0944a;
    address internal constant SUSDS = 0x5875eEE11Cf8398102FdAd704C9E96607675467a;
    address internal constant USDC  = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address internal constant USDS  = 0x820C137fa70C8691f0e44Dc420a5e53c168921Dc;
    address internal constant WETH  = 0x4200000000000000000000000000000000000006;

    /******************************************************************************************************************/
    /*** Cross-chain addresses                                                                                      ***/
    /******************************************************************************************************************/

    address internal constant CCTP_TOKEN_MESSENGER = 0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d;

    address internal constant SKY_GOV_RELAY = 0xdD0BCc201C9E47c6F6eE68E4dB05b652Bb6aC255;
    address internal constant TOKEN_BRIDGE  = 0xee44cdb68D618d58F75d9fe0818B640BD7B8A7B7;

    /******************************************************************************************************************/
    /*** Aave addresses                                                                                             ***/
    /******************************************************************************************************************/

    address internal constant ATOKEN_USDC = 0x4e65fE4DbA92790696d040ac24Aa414708F5c0AB;

    /******************************************************************************************************************/
    /*** Fluid addresses                                                                                            ***/
    /******************************************************************************************************************/

    address internal constant FLUID_SUSDS = 0xf62e339f21d8018940f188F6987Bcdf02A849619;

    /******************************************************************************************************************/
    /*** Morpho addresses                                                                                           ***/
    /******************************************************************************************************************/

    address internal constant MORPHO                   = 0xBBBBBbbBBb9cC5e90e3b3Af64bdAF62C37EEFFCb;
    address internal constant MORPHO_DEFAULT_IRM       = 0x46415998764C29aB2a25CbeA6254146D50D22687;
    address internal constant MORPHO_TOKEN             = 0xBAa5CC21fd487B8Fcc2F632f3F4E8D37262a0842;
    address internal constant MORPHO_CBBTC_USDC_ORACLE = 0x663BECd10daE6C4A3Dcd89F1d76c1174199639B9;
    address internal constant MORPHO_WETH_USDC_ORACLE  = 0xFEa2D58cEfCb9fcb597723c6bAE66fFE4193aFE4;

}
