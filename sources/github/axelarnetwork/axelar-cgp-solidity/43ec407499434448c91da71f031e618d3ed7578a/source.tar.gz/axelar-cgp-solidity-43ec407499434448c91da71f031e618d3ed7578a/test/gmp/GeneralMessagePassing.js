'use strict';

const chai = require('chai');
const { ethers, network } = require('hardhat');
const {
    utils: { defaultAbiCoder, arrayify, keccak256 },
} = ethers;
const { expect } = chai;
const { deployUpgradable } = require('@axelar-network/axelar-gmp-sdk-solidity');
const ConstAddressDeployer = require('@axelar-network/axelar-gmp-sdk-solidity/artifacts/contracts/deploy/ConstAddressDeployer.sol/ConstAddressDeployer.json');

const GasService = require('../../artifacts/contracts/gas-service/AxelarGasService.sol/AxelarGasService.json');
const GasServiceProxy = require('../../artifacts/contracts/gas-service/AxelarGasServiceProxy.sol/AxelarGasServiceProxy.json');

const {
    getWeightedAuthDeployParam,
    getSignedWeightedExecuteInput,
    getRandomID,
    getAddresses,
    getChainId,
    getWeightedProxyDeployParams,
    getGasOptions,
} = require('../utils');

describe('GeneralMessagePassing', () => {
    let ownerWallet;
    let operatorWallet;
    let userWallet;

    let sourceChainGateway;
    let destinationChainGateway;
    let sourceChainGasService;
    let sourceChainSwapContract;
    let destinationChainSwapExecutable;
    let destinationChainTokenSwapper;
    let tokenA;
    let tokenB;

    let gatewayFactory;
    let authFactory;
    let tokenDeployerFactory;
    let gatewayProxyFactory;
    let mintableCappedERC20Factory;
    let sourceChainSwapContractFactory;
    let destinationChainSwapExecutableFactory;
    let destinationChainTokenSwapperFactory;

    let auth;
    let tokenDeployer;
    let gateway;

    const sourceChain = 'chainA';
    const destinationChain = 'chainB';
    const nameA = 'testTokenX';
    const symbolA = 'testTokenX';
    const nameB = 'testTokenY';
    const symbolB = 'testTokenY';
    const decimals = 16;
    const capacity = 0;

    const getMintData = async (symbol, address, amount) =>
        arrayify(
            defaultAbiCoder.encode(
                ['uint256', 'bytes32[]', 'string[]', 'bytes[]'],
                [
                    await getChainId(),
                    [getRandomID()],
                    ['mintToken'],
                    [defaultAbiCoder.encode(['string', 'address', 'uint256'], [symbol, address, amount])],
                ],
            ),
        );

    before(async () => {
        [ownerWallet, operatorWallet, userWallet] = await ethers.getSigners();

        gatewayFactory = await ethers.getContractFactory('AxelarGateway', ownerWallet);
        authFactory = await ethers.getContractFactory('AxelarAuthWeighted', ownerWallet);
        tokenDeployerFactory = await ethers.getContractFactory('TokenDeployer', ownerWallet);
        gatewayProxyFactory = await ethers.getContractFactory('AxelarGatewayProxy', ownerWallet);
        mintableCappedERC20Factory = await ethers.getContractFactory('MintableCappedERC20', ownerWallet);
        sourceChainSwapContractFactory = await ethers.getContractFactory('SourceChainSwapContract', ownerWallet);
        destinationChainSwapExecutableFactory = await ethers.getContractFactory('DestinationChainSwapExecutable', ownerWallet);
        destinationChainTokenSwapperFactory = await ethers.getContractFactory('DestinationChainTokenSwapper', ownerWallet);
    });

    beforeEach(async () => {
        const deployGateway = async () => {
            const operatorAddresses = getAddresses([operatorWallet]);

            auth = await authFactory.deploy(getWeightedAuthDeployParam([operatorAddresses], [[1]], [1])).then((d) => d.deployed());

            tokenDeployer = await tokenDeployerFactory.deploy().then((d) => d.deployed());

            const gatewayImplementation = await gatewayFactory.deploy(auth.address, tokenDeployer.address).then((d) => d.deployed());

            const params = getWeightedProxyDeployParams(ownerWallet.address, ownerWallet.address, [], [], 1);

            const proxy = await gatewayProxyFactory.deploy(gatewayImplementation.address, params).then((d) => d.deployed());

            await auth.transferOwnership(proxy.address).then((tx) => tx.wait(network.config.confirmations));

            gateway = gatewayFactory.attach(proxy.address);

            return gateway;
        };

        const getTokenDeployData = async (withAddress) =>
            arrayify(
                defaultAbiCoder.encode(
                    ['uint256', 'bytes32[]', 'string[]', 'bytes[]'],
                    [
                        await getChainId(),
                        [getRandomID(), getRandomID()],
                        ['deployToken', 'deployToken'],
                        [
                            defaultAbiCoder.encode(
                                ['string', 'string', 'uint8', 'uint256', 'address', 'uint256'],
                                [nameA, symbolA, decimals, capacity, withAddress ? tokenA.address : ethers.constants.AddressZero, 0],
                            ),
                            defaultAbiCoder.encode(
                                ['string', 'string', 'uint8', 'uint256', 'address', 'uint256'],
                                [nameB, symbolB, decimals, capacity, withAddress ? tokenB.address : ethers.constants.AddressZero, 0],
                            ),
                        ],
                    ],
                ),
            );

        sourceChainGateway = await deployGateway();
        destinationChainGateway = await deployGateway();
        const constAddressDeployerFactory = await ethers.getContractFactory(
            ConstAddressDeployer.abi,
            ConstAddressDeployer.bytecode,
            ownerWallet,
        );
        const constAddressDeployer = await constAddressDeployerFactory.deploy().then((d) => d.deployed());

        sourceChainGasService = await deployUpgradable(constAddressDeployer.address, ownerWallet, GasService, GasServiceProxy, [
            ownerWallet.address,
        ]);

        tokenA = await mintableCappedERC20Factory.deploy(nameA, symbolA, decimals, capacity).then((d) => d.deployed());
        tokenB = await mintableCappedERC20Factory.deploy(nameB, symbolB, decimals, capacity).then((d) => d.deployed());

        await sourceChainGateway
            .execute(
                await getSignedWeightedExecuteInput(await getTokenDeployData(false), [operatorWallet], [1], 1, [operatorWallet]),
                getGasOptions(),
            )
            .then((tx) => tx.wait(network.config.confirmations));

        await destinationChainGateway
            .execute(
                await getSignedWeightedExecuteInput(await getTokenDeployData(true), [operatorWallet], [1], 1, [operatorWallet]),
                getGasOptions(),
            )
            .then((tx) => tx.wait(network.config.confirmations));

        destinationChainTokenSwapper = await destinationChainTokenSwapperFactory
            .deploy(tokenA.address, tokenB.address)
            .then((d) => d.deployed());
        destinationChainSwapExecutable = await destinationChainSwapExecutableFactory
            .deploy(destinationChainGateway.address, destinationChainTokenSwapper.address)
            .then((d) => d.deployed());
        sourceChainSwapContract = await sourceChainSwapContractFactory
            .deploy(sourceChainGateway.address, sourceChainGasService.address, destinationChain, destinationChainSwapExecutable.address)
            .then((d) => d.deployed());

        await tokenA.mint(destinationChainGateway.address, 1e9).then((tx) => tx.wait(network.config.confirmations));
        await tokenB.mint(destinationChainTokenSwapper.address, 1e9).then((tx) => tx.wait(network.config.confirmations));

        await sourceChainGateway
            .execute(
                await getSignedWeightedExecuteInput(await getMintData(symbolA, userWallet.address, 1e9), [operatorWallet], [1], 1, [
                    operatorWallet,
                ]),
                getGasOptions(),
            )
            .then((tx) => tx.wait(network.config.confirmations));

        await tokenA
            .connect(ownerWallet)
            .mint(userWallet.address, 1e9)
            .then((tx) => tx.wait(network.config.confirmations));
    });

    describe('general message passing', () => {
        it('should swap tokens on remote chain', async () => {
            // Source chain.

            const swapAmount = 1e6;
            const gasFeeAmount = 1e3;
            const convertedAmount = 2 * swapAmount;
            const payload = defaultAbiCoder.encode(['string', 'string'], [symbolB, userWallet.address.toString()]);
            const payloadHash = keccak256(payload);

            const sourceChainTokenA = mintableCappedERC20Factory
                .attach(await sourceChainGateway.tokenAddresses(symbolA))
                .connect(userWallet);
            await sourceChainTokenA
                .approve(sourceChainSwapContract.address, swapAmount + gasFeeAmount)
                .then((tx) => tx.wait(network.config.confirmations));

            await expect(
                sourceChainSwapContract
                    .connect(userWallet)
                    .swapToken(symbolA, symbolB, swapAmount, userWallet.address.toString(), { value: gasFeeAmount }),
            )
                .to.emit(sourceChainGasService, 'NativeGasPaidForContractCallWithToken')
                .withArgs(
                    sourceChainSwapContract.address,
                    destinationChain,
                    destinationChainSwapExecutable.address.toString(),
                    payloadHash,
                    symbolA,
                    swapAmount,
                    gasFeeAmount,
                    userWallet.address,
                )
                .and.to.emit(sourceChainGateway, 'ContractCallWithToken')
                .withArgs(
                    sourceChainSwapContract.address.toString(),
                    destinationChain,
                    destinationChainSwapExecutable.address.toString(),
                    payloadHash,
                    payload,
                    symbolA,
                    swapAmount,
                );

            // Destination chain

            const approveCommandId = getRandomID();
            const sourceTxHash = keccak256('0x123abc123abc');
            const sourceEventIndex = 17;

            const approveWithMintData = arrayify(
                defaultAbiCoder.encode(
                    ['uint256', 'bytes32[]', 'string[]', 'bytes[]'],
                    [
                        await getChainId(),
                        [approveCommandId],
                        ['approveContractCallWithMint'],
                        [
                            defaultAbiCoder.encode(
                                ['string', 'string', 'address', 'bytes32', 'string', 'uint256', 'bytes32', 'uint256'],
                                [
                                    sourceChain,
                                    sourceChainSwapContract.address.toString(),
                                    destinationChainSwapExecutable.address,
                                    payloadHash,
                                    symbolA,
                                    swapAmount,
                                    sourceTxHash,
                                    sourceEventIndex,
                                ],
                            ),
                        ],
                    ],
                ),
            );

            const approveExecute = await destinationChainGateway.execute(
                await getSignedWeightedExecuteInput(approveWithMintData, [operatorWallet], [1], 1, [operatorWallet]),
                getGasOptions(),
            );

            await expect(approveExecute)
                .to.emit(destinationChainGateway, 'ContractCallApprovedWithMint')
                .withArgs(
                    approveCommandId,
                    sourceChain,
                    sourceChainSwapContract.address.toString(),
                    destinationChainSwapExecutable.address,
                    payloadHash,
                    symbolA,
                    swapAmount,
                    sourceTxHash,
                    sourceEventIndex,
                );

            const swap = await destinationChainSwapExecutable.executeWithToken(
                approveCommandId,
                sourceChain,
                sourceChainSwapContract.address.toString(),
                payload,
                symbolA,
                swapAmount,
                getGasOptions(),
            );

            const returnPayload = defaultAbiCoder.encode(['string'], [userWallet.address.toString()]);
            const returnPayloadHash = keccak256(returnPayload);

            await expect(swap)
                .to.emit(tokenA, 'Transfer')
                .withArgs(destinationChainGateway.address, destinationChainSwapExecutable.address, swapAmount)
                .and.to.emit(tokenB, 'Transfer')
                .withArgs(destinationChainTokenSwapper.address, destinationChainSwapExecutable.address, convertedAmount)
                .and.to.emit(tokenB, 'Transfer')
                .withArgs(destinationChainSwapExecutable.address, destinationChainGateway.address, convertedAmount)
                .and.to.emit(destinationChainGateway, 'ContractCallWithToken')
                .withArgs(
                    destinationChainSwapExecutable.address,
                    sourceChain,
                    sourceChainSwapContract.address.toString(),
                    returnPayloadHash,
                    returnPayload,
                    symbolB,
                    convertedAmount,
                );

            // Source chain

            const returnApproveCommandId = getRandomID();
            const returnSourceTxHash = keccak256('0x456def456def');
            const returnSourceEventIndex = 18;

            const returnApproveWithMintData = arrayify(
                defaultAbiCoder.encode(
                    ['uint256', 'bytes32[]', 'string[]', 'bytes[]'],
                    [
                        await getChainId(),
                        [returnApproveCommandId],
                        ['approveContractCallWithMint'],
                        [
                            defaultAbiCoder.encode(
                                ['string', 'string', 'address', 'bytes32', 'string', 'uint256', 'bytes32', 'uint256'],
                                [
                                    destinationChain,
                                    destinationChainSwapExecutable.address.toString(),
                                    sourceChainSwapContract.address,
                                    returnPayloadHash,
                                    symbolB,
                                    convertedAmount,
                                    returnSourceTxHash,
                                    returnSourceEventIndex,
                                ],
                            ),
                        ],
                    ],
                ),
            );

            const returnApproveExecute = await sourceChainGateway.execute(
                await getSignedWeightedExecuteInput(returnApproveWithMintData, [operatorWallet], [1], 1, [operatorWallet]),
                getGasOptions(),
            );

            await expect(returnApproveExecute)
                .to.emit(sourceChainGateway, 'ContractCallApprovedWithMint')
                .withArgs(
                    returnApproveCommandId,
                    destinationChain,
                    destinationChainSwapExecutable.address.toString(),
                    sourceChainSwapContract.address,
                    returnPayloadHash,
                    symbolB,
                    convertedAmount,
                    returnSourceTxHash,
                    returnSourceEventIndex,
                );

            const sourceChainTokenB = mintableCappedERC20Factory.attach(await sourceChainGateway.tokenAddresses(symbolB));

            const returnSwap = await sourceChainSwapContract.executeWithToken(
                returnApproveCommandId,
                destinationChain,
                destinationChainSwapExecutable.address.toString(),
                returnPayload,
                symbolB,
                convertedAmount,
                getGasOptions(),
            );

            await expect(returnSwap)
                .to.emit(sourceChainTokenB, 'Transfer')
                .withArgs(ethers.constants.AddressZero, sourceChainSwapContract.address, convertedAmount)
                .and.to.emit(sourceChainTokenB, 'Transfer')
                .withArgs(sourceChainSwapContract.address, userWallet.address, convertedAmount);
        });
    });
});
