const { sortBy } = require('lodash');
const chai = require('chai');
const { ethers, network } = require('hardhat');
const {
    utils: { arrayify, keccak256, toUtf8Bytes },
    constants: { HashZero },
    Wallet,
} = ethers;
const { expect } = chai;

const { getWeightedSignersProof, encodeWeightedSigners } = require('../../scripts/utils');

describe('BaseWeightedMultisig', () => {
    const previousSignersRetention = 0;
    const domainSeparator = keccak256(toUtf8Bytes('chain'));
    const data = '0x123abc123abc';
    const dataHash = keccak256(arrayify(data));

    let owner;
    let testMultisigFactory;

    before(async () => {
        const wallets = await ethers.getSigners();

        owner = wallets[0];

        testMultisigFactory = await ethers.getContractFactory('TestBaseWeightedMultisig', owner);
    });

    it('should validate storage constants', async () => {
        const multisig = await testMultisigFactory.deploy(previousSignersRetention, domainSeparator);
        await multisig.deployTransaction.wait(network.config.confirmations);
    });

    it('should validate proof from signers', async () => {
        const threshold = 2;
        const wallets = sortBy((await ethers.getSigners()).slice(0, threshold), (wallet) =>
            wallet.address.toLowerCase(),
        );

        const newSigners = {
            signers: wallets.map((wallet) => {
                return { signer: wallet.address, weight: 1 };
            }),
            threshold,
            nonce: HashZero,
        };

        const multisig = await testMultisigFactory.deploy(previousSignersRetention, domainSeparator);
        await multisig.deployTransaction.wait(network.config.confirmations);

        await multisig.rotateSigners(newSigners).then((tx) => tx.wait());

        const proof = await getWeightedSignersProof(data, domainSeparator, newSigners, wallets);
        await multisig.validateProof(dataHash, proof).then((tx) => tx.wait());
    });

    it('should allow signer rotation to a large set of 40 signers', async () => {
        const numSigners = 40;

        const multisig = await testMultisigFactory.deploy(previousSignersRetention, domainSeparator);
        await multisig.deployTransaction.wait(network.config.confirmations);

        const defaultNonce = HashZero;
        const threshold = Math.floor(numSigners / 2) + 1;

        const wallets = sortBy(
            Array(numSigners)
                .fill(0)
                .map(() => Wallet.createRandom()),
            (wallet) => wallet.address.toLowerCase(),
        );
        const signers = wallets.map((wallet) => {
            return { signer: wallet.address, weight: 1 };
        });
        const newSigners = {
            signers,
            threshold,
            nonce: defaultNonce,
        };
        const encodedSigners = encodeWeightedSigners(newSigners);
        const signersHash = keccak256(encodedSigners);

        const prevEpoch = (await multisig.epoch()).toNumber();

        await expect(multisig.rotateSigners(newSigners))
            .to.emit(multisig, 'SignersRotated')
            .withArgs(prevEpoch + 1, signersHash, encodedSigners);

        const proof = await getWeightedSignersProof(data, domainSeparator, newSigners, wallets.slice(0, threshold));

        await multisig.validateProof(dataHash, proof).then((tx) => tx.wait());
    });
});
