# @axelar-network/axelar-gmp-sdk-solidity

## 6.2.0

### Minor Changes

-   ce79e3e: Add pause/unpause to `AxelarAmplifierGateway` via `setPauseStatus(bool)` (operator-or-owner gated). While paused, `callContract` reverts and `validateMessage` / `validateContractCall` are gated, with an owner bypass so the owner can still consume inbound messages.

## 6.1.0

### Minor Changes

-   6344af2: Removed the deprecated `sendToken` function and `TokenSent` event from the `IAxelarGatewayWithToken` interface

## 6.0.6

### Patch Changes

-   07330bc: fix gh release action

## 6.0.5

### Patch Changes

-   6093489: Added GitHub actions for automatic docs generation and Aderyn static analysis for contracts

## 6.0.4

### Patch Changes

-   f25a2d4: Allowed chainName() to be accessible internally in InterchainAddressTracker

## 6.0.3

### Patch Changes

-   cb4385d: add public access for the publish config

## 6.0.2

### Patch Changes

-   7ecf8e3: split express executable gateway token contracts. Use `*WithToken` variants of express executables if you need gateway token support
-   53c9a1e: update signerHash to signersHash

## 6.0.1

### Patch Changes

-   819f361: reverted use of named return value in RolesBase to not change bytecode of InterchainToken
