## axelard query ibc-transfer

IBC fungible token transfer query subcommands

### Options

```
  -h, --help   help for ibc-transfer
```

### Options inherited from parent commands

```
      --home string         directory for config and data (default "$HOME/.axelar")
      --log_format string   The logging format (json|plain) (default "plain")
      --log_level string    The logging level (trace|debug|info|warn|error|fatal|panic) (default "info")
      --output string       Output format (text|json) (default "text")
      --trace               print out full stack trace on errors
```

### SEE ALSO

- [axelard query](axelard_query.md) - Querying subcommands
- [axelard query ibc-transfer denom](axelard_query_ibc-transfer_denom.md) - Query the denom trace info from a given hash or ibc denom
- [axelard query ibc-transfer denom-hash](axelard_query_ibc-transfer_denom-hash.md) - Query the denom hash info from a given denom trace
- [axelard query ibc-transfer denoms](axelard_query_ibc-transfer_denoms.md) - Query for all token denominations
- [axelard query ibc-transfer escrow-address](axelard_query_ibc-transfer_escrow-address.md) - Get the escrow address for a channel
- [axelard query ibc-transfer params](axelard_query_ibc-transfer_params.md) - Query the current ibc-transfer parameters
- [axelard query ibc-transfer total-escrow](axelard_query_ibc-transfer_total-escrow.md) - Query the total amount of tokens in escrow for a denom
