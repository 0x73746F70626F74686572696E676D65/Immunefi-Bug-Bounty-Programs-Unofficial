## axelard query ibc client

IBC client query subcommands

```
axelard query ibc client [flags]
```

### Options

```
  -h, --help   help for client
```

### Options inherited from parent commands

```
      --home string         directory for config and data (default "$HOME/.axelar")
      --log_format string   The logging format (json|plain) (default "plain")
      --log_level string    The logging level (trace|debug|info|warn|error|fatal|panic) (default "info")
      --output string       Output format (text|json) (default "text")
      --trace               print out full stack trace on errors
```

### SEE ALSO

- [axelard query ibc](axelard_query_ibc.md) - Querying commands for the IBC module
- [axelard query ibc client config](axelard_query_ibc_client_config.md) - Query a client's config
- [axelard query ibc client consensus-state](axelard_query_ibc_client_consensus-state.md) - Query the consensus state of a client at a given height
- [axelard query ibc client consensus-state-heights](axelard_query_ibc_client_consensus-state-heights.md) - Query the heights of all consensus states of a client.
- [axelard query ibc client consensus-states](axelard_query_ibc_client_consensus-states.md) - Query all the consensus states of a client.
- [axelard query ibc client counterparty-info](axelard_query_ibc_client_counterparty-info.md) - Query a client's counterparty info
- [axelard query ibc client creator](axelard_query_ibc_client_creator.md) - Query a client's creator
- [axelard query ibc client header](axelard_query_ibc_client_header.md) - Query the latest header of the running chain
- [axelard query ibc client params](axelard_query_ibc_client_params.md) - Query the current ibc client parameters
- [axelard query ibc client params](axelard_query_ibc_client_params.md) - Query the current ibc client parameters
- [axelard query ibc client self-consensus-state](axelard_query_ibc_client_self-consensus-state.md) - Query the self consensus state for this chain
- [axelard query ibc client state](axelard_query_ibc_client_state.md) - Query a client state
- [axelard query ibc client states](axelard_query_ibc_client_states.md) - Query all available light clients
- [axelard query ibc client status](axelard_query_ibc_client_status.md) - Query client status
