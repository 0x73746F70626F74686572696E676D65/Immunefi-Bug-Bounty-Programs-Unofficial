## axelard tx ibc

IBC transaction subcommands

```
axelard tx ibc [flags]
```

### Options

```
  -h, --help   help for ibc
```

### Options inherited from parent commands

```
      --home string         directory for config and data (default "$HOME/.axelar")
      --log_format string   The logging format (json|plain) (default "plain")
      --log_level string    The logging level (trace|debug|info|warn|error|fatal|panic) (default "info")
      --output string       Output format (text|json) (default "text")
      --trace               print out full stack trace on errors
```

### SEE ALSO

- [axelard tx](axelard_tx.md) - Transactions subcommands
- [axelard tx ibc channelv2](axelard_tx_ibc_channelv2.md) - IBC channel/v2 transaction subcommands
- [axelard tx ibc client](axelard_tx_ibc_client.md) - IBC client transaction subcommands
