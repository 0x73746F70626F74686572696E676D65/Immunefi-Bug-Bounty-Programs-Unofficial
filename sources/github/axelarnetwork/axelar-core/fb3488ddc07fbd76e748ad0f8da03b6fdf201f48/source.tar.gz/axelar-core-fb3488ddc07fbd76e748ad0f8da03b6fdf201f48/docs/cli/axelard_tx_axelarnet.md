## axelard tx axelarnet

axelarnet transactions subcommands

```
axelard tx axelarnet [flags]
```

### Options

```
  -h, --help   help for axelarnet
```

### Options inherited from parent commands

```
      --home string         directory for config and data (default "$HOME/.axelar")
      --log_format string   The logging format (json|plain) (default "plain")
      --log_level string    The logging level (trace|debug|info|warn|error|fatal|panic) (default "info")
      --output string       Output format (text|json) (default "text")
      --trace               print out full stack trace on errors
```

### SEE ALSO

- [axelard tx](axelard_tx.md) - Transactions subcommands
- [axelard tx axelarnet add-cosmos-based-chain](axelard_tx_axelarnet_add-cosmos-based-chain.md) - Add a new cosmos based chain
- [axelard tx axelarnet execute-pending-transfers](axelard_tx_axelarnet_execute-pending-transfers.md) - Send all pending transfers to Axelar chain
- [axelard tx axelarnet register-asset](axelard_tx_axelarnet_register-asset.md) - Register a new asset to a cosmos based chain
- [axelard tx axelarnet register-fee-collector](axelard_tx_axelarnet_register-fee-collector.md) - Register axelarnet fee collector account
- [axelard tx axelarnet retry-ibc-transfer](axelard_tx_axelarnet_retry-ibc-transfer.md) - Retry a failed IBC transfer
- [axelard tx axelarnet route-ibc-transfers](axelard_tx_axelarnet_route-ibc-transfers.md) - Routes pending transfers to cosmos chains
- [axelard tx axelarnet route-message](axelard_tx_axelarnet_route-message.md) - Route an approved general message to the destination chain
