## axelard comet show-validator

Show this node's CometBFT validator info

```
axelard comet show-validator [flags]
```

### Options

```
  -h, --help   help for show-validator
```

### Options inherited from parent commands

```
      --home string         directory for config and data (default "$HOME/.axelar")
      --log_format string   The logging format (json|plain) (default "plain")
      --log_level string    The logging level (trace|debug|info|warn|error|fatal|panic) (default "info")
      --output string       Output format (text|json) (default "text")
      --trace               print out full stack trace on errors
```

### SEE ALSO

- [axelard comet](axelard_comet.md) - CometBFT subcommands
