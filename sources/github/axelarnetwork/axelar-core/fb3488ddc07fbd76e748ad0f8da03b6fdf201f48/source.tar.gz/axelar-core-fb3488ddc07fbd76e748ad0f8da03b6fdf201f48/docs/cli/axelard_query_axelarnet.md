## axelard query axelarnet

Querying commands for the axelarnet module

```
axelard query axelarnet [flags]
```

### Options

```
  -h, --help   help for axelarnet
```

### Options inherited from parent commands

```
      --home string         directory for config and data (default "$HOME/.axelar")
      --log_format string   The logging format (json|plain) (default "plain")
      --log_level string    The logging level (trace|debug|info|warn|error|fatal|panic) (default "info")
      --output string       Output format (text|json) (default "text")
      --trace               print out full stack trace on errors
```

### SEE ALSO

- [axelard query](axelard_query.md) - Querying subcommands
- [axelard query axelarnet chain-by-ibc-path](axelard_query_axelarnet_chain-by-ibc-path.md) - Returns the Cosmos chain for the given IBC path
- [axelard query axelarnet ibc-path](axelard_query_axelarnet_ibc-path.md) - Returns the registered IBC path for the given Cosmos chain
- [axelard query axelarnet ibc-transfer-count](axelard_query_axelarnet_ibc-transfer-count.md) - returns the number of pending IBC transfers per chain
- [axelard query axelarnet params](axelard_query_axelarnet_params.md) - Returns the params for the axelarnet module
