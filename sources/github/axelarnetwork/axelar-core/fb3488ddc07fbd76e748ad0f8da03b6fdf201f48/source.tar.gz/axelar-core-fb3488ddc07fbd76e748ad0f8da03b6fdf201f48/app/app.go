package app

import (
	"encoding/json"
	"fmt"
	"io"
	stdlog "log"
	"net/http"
	"os"
	"path/filepath"

	"cosmossdk.io/client/v2/autocli"
	"cosmossdk.io/core/appmodule"
	sdklogger "cosmossdk.io/log"
	store "cosmossdk.io/store/types"
	"cosmossdk.io/x/evidence"
	evidencekeeper "cosmossdk.io/x/evidence/keeper"
	evidencetypes "cosmossdk.io/x/evidence/types"
	"cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	feegrantmodule "cosmossdk.io/x/feegrant/module"
	"cosmossdk.io/x/upgrade"
	upgradekeeper "cosmossdk.io/x/upgrade/keeper"
	upgradetypes "cosmossdk.io/x/upgrade/types"
	"github.com/CosmWasm/wasmd/x/wasm"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	wasmtypes "github.com/CosmWasm/wasmd/x/wasm/types"
	abci "github.com/cometbft/cometbft/abci/types"
	tmjson "github.com/cometbft/cometbft/libs/json"
	tmos "github.com/cometbft/cometbft/libs/os"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	bam "github.com/cosmos/cosmos-sdk/baseapp"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/client/grpc/cmtservice"
	nodeservice "github.com/cosmos/cosmos-sdk/client/grpc/node"
	"github.com/cosmos/cosmos-sdk/codec"
	"github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	runtimeservices "github.com/cosmos/cosmos-sdk/runtime/services"
	"github.com/cosmos/cosmos-sdk/server"
	"github.com/cosmos/cosmos-sdk/server/api"
	"github.com/cosmos/cosmos-sdk/server/config"
	servertypes "github.com/cosmos/cosmos-sdk/server/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"
	"github.com/cosmos/cosmos-sdk/version"
	"github.com/cosmos/cosmos-sdk/x/auth"
	authAnte "github.com/cosmos/cosmos-sdk/x/auth/ante"
	authcodec "github.com/cosmos/cosmos-sdk/x/auth/codec"
	authkeeper "github.com/cosmos/cosmos-sdk/x/auth/keeper"
	authtx "github.com/cosmos/cosmos-sdk/x/auth/tx"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/cosmos/cosmos-sdk/x/auth/vesting"
	vestingtypes "github.com/cosmos/cosmos-sdk/x/auth/vesting/types"
	"github.com/cosmos/cosmos-sdk/x/authz"
	authzkeeper "github.com/cosmos/cosmos-sdk/x/authz/keeper"
	authzmodule "github.com/cosmos/cosmos-sdk/x/authz/module"
	"github.com/cosmos/cosmos-sdk/x/bank"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/cosmos/cosmos-sdk/x/consensus"
	consensusparamkeeper "github.com/cosmos/cosmos-sdk/x/consensus/keeper"
	consensusparamtypes "github.com/cosmos/cosmos-sdk/x/consensus/types"
	distr "github.com/cosmos/cosmos-sdk/x/distribution"
	distrkeeper "github.com/cosmos/cosmos-sdk/x/distribution/keeper"
	distrtypes "github.com/cosmos/cosmos-sdk/x/distribution/types"
	"github.com/cosmos/cosmos-sdk/x/genutil"
	genutiltypes "github.com/cosmos/cosmos-sdk/x/genutil/types"
	"github.com/cosmos/cosmos-sdk/x/gov"
	govkeeper "github.com/cosmos/cosmos-sdk/x/gov/keeper"
	govtypes "github.com/cosmos/cosmos-sdk/x/gov/types"
	"github.com/cosmos/cosmos-sdk/x/mint"
	mintkeeper "github.com/cosmos/cosmos-sdk/x/mint/keeper"
	minttypes "github.com/cosmos/cosmos-sdk/x/mint/types"
	"github.com/cosmos/cosmos-sdk/x/params"
	paramskeeper "github.com/cosmos/cosmos-sdk/x/params/keeper"
	paramstypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/cosmos/cosmos-sdk/x/slashing"
	slashingkeeper "github.com/cosmos/cosmos-sdk/x/slashing/keeper"
	slashingtypes "github.com/cosmos/cosmos-sdk/x/slashing/types"
	"github.com/cosmos/cosmos-sdk/x/staking"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"
	ibchooks "github.com/cosmos/ibc-apps/modules/ibc-hooks/v10"
	ibchookskeeper "github.com/cosmos/ibc-apps/modules/ibc-hooks/v10/keeper"
	ibchookstypes "github.com/cosmos/ibc-apps/modules/ibc-hooks/v10/types"
	"github.com/cosmos/ibc-go/v10/modules/apps/transfer"
	ibctransferkeeper "github.com/cosmos/ibc-go/v10/modules/apps/transfer/keeper"
	ibctransfertypes "github.com/cosmos/ibc-go/v10/modules/apps/transfer/types"
	ibc "github.com/cosmos/ibc-go/v10/modules/core"
	porttypes "github.com/cosmos/ibc-go/v10/modules/core/05-port/types"
	ibcante "github.com/cosmos/ibc-go/v10/modules/core/ante"
	ibcexported "github.com/cosmos/ibc-go/v10/modules/core/exported"
	ibckeeper "github.com/cosmos/ibc-go/v10/modules/core/keeper"
	ibctendermint "github.com/cosmos/ibc-go/v10/modules/light-clients/07-tendermint"
	"github.com/gorilla/mux"
	"github.com/rakyll/statik/fs"
	"github.com/spf13/cast"

	axelarParams "github.com/axelarnetwork/axelar-core/app/params"
	"github.com/axelarnetwork/axelar-core/x/ante"
	"github.com/axelarnetwork/axelar-core/x/auxiliary"
	auxiliarytypes "github.com/axelarnetwork/axelar-core/x/auxiliary/types"
	"github.com/axelarnetwork/axelar-core/x/axelarnet"
	axelarnetKeeper "github.com/axelarnetwork/axelar-core/x/axelarnet/keeper"
	axelarnetTypes "github.com/axelarnetwork/axelar-core/x/axelarnet/types"
	axelarbankkeeper "github.com/axelarnetwork/axelar-core/x/bank/keeper"
	axelardistr "github.com/axelarnetwork/axelar-core/x/distribution"
	axelardistrkeeper "github.com/axelarnetwork/axelar-core/x/distribution/keeper"
	"github.com/axelarnetwork/axelar-core/x/evm"
	evmKeeper "github.com/axelarnetwork/axelar-core/x/evm/keeper"
	evmTypes "github.com/axelarnetwork/axelar-core/x/evm/types"
	"github.com/axelarnetwork/axelar-core/x/feepolicy"
	feepolicyKeeper "github.com/axelarnetwork/axelar-core/x/feepolicy/keeper"
	feepolicyTypes "github.com/axelarnetwork/axelar-core/x/feepolicy/types"
	"github.com/axelarnetwork/axelar-core/x/multisig"
	multisigKeeper "github.com/axelarnetwork/axelar-core/x/multisig/keeper"
	multisigTypes "github.com/axelarnetwork/axelar-core/x/multisig/types"
	"github.com/axelarnetwork/axelar-core/x/nexus"
	nexusKeeper "github.com/axelarnetwork/axelar-core/x/nexus/keeper"
	nexusTypes "github.com/axelarnetwork/axelar-core/x/nexus/types"
	"github.com/axelarnetwork/axelar-core/x/permission"
	permissionKeeper "github.com/axelarnetwork/axelar-core/x/permission/keeper"
	permissionTypes "github.com/axelarnetwork/axelar-core/x/permission/types"
	"github.com/axelarnetwork/axelar-core/x/reward"
	rewardKeeper "github.com/axelarnetwork/axelar-core/x/reward/keeper"
	rewardTypes "github.com/axelarnetwork/axelar-core/x/reward/types"
	"github.com/axelarnetwork/axelar-core/x/snapshot"
	snapKeeper "github.com/axelarnetwork/axelar-core/x/snapshot/keeper"
	snapTypes "github.com/axelarnetwork/axelar-core/x/snapshot/types"
	"github.com/axelarnetwork/axelar-core/x/tss"
	tssTypes "github.com/axelarnetwork/axelar-core/x/tss/types"
	"github.com/axelarnetwork/axelar-core/x/vote"
	voteKeeper "github.com/axelarnetwork/axelar-core/x/vote/keeper"
	voteTypes "github.com/axelarnetwork/axelar-core/x/vote/types"
	"github.com/axelarnetwork/utils/funcs"

	// Override with generated statik docs
	_ "github.com/axelarnetwork/axelar-core/client/docs/statik"
)

// Name is the name of the application
const Name = "axelar"

const WasmDirFlag = "wasm-dir"

var (
	// DefaultNodeHome default home directories for the application daemon
	DefaultNodeHome string

	// WasmEnabled indicates whether wasm module is added to the app.
	// "true" setting means it will be, otherwise it won't.
	// This is configured during the build.
	WasmEnabled = ""

	// IBCWasmHooksEnabled indicates whether wasm hooks for ibc are enabled.
	// "true" setting means it will be, otherwise it won't.
	// When disabled, cosmwasm contracts cannot be called via IBC.
	// This is configured during the build.
	IBCWasmHooksEnabled = ""

	// WasmCapabilities specifies the capabilities of the wasm vm
	// capabilities are detailed here: https://github.com/CosmWasm/cosmwasm/blob/main/docs/CAPABILITIES-BUILT-IN.md
	WasmCapabilities = ""

	// MaxWasmSize specifies the maximum wasm code size (in bytes) that can be uploaded. wasmd's setting is used by default
	// https://github.com/CosmWasm/wasmd/blob/main/README.md#compile-time-parameters
	MaxWasmSize = ""
)

var (
	_ servertypes.Application = (*AxelarApp)(nil)
)

func init() {
	userHomeDir, err := os.UserHomeDir()
	if err != nil {
		stdlog.Println("Failed to get home dir %2", err)
	}

	DefaultNodeHome = filepath.Join(userHomeDir, "."+Name)

	if !IsWasmEnabled() && IsIBCWasmHooksEnabled() {
		panic("ibc wasm hooks should only be enabled when wasm is enabled")
	}
}

// AxelarApp defines the axelar Cosmos app that runs all modules
type AxelarApp struct {
	*bam.BaseApp
	// Keys and Keepers are necessary for the app to interact with the cosmos-sdk and to be able to test the app in isolation without mocks
	Keepers *KeeperCache
	Keys    map[string]*store.KVStoreKey

	appCodec codec.Codec

	interfaceRegistry types.InterfaceRegistry

	mm *FilteredModuleManager
}

// NewAxelarApp is a constructor function for axelar
func NewAxelarApp(
	logger sdklogger.Logger,
	db dbm.DB,
	traceStore io.Writer,
	loadLatest bool,
	encodingConfig axelarParams.EncodingConfig,
	appOpts servertypes.AppOptions,
	wasmOpts []wasm.Option,
	baseAppOptions ...func(*bam.BaseApp),
) *AxelarApp {
	keys := CreateStoreKeys()
	tkeys := store.NewTransientStoreKeys(paramstypes.TStoreKey)

	keepers := NewKeeperCache()
	appCodec := codec.NewProtoCodec(encodingConfig.InterfaceRegistry)

	SetKeeper(keepers, initParamsKeeper(encodingConfig, keys[paramstypes.StoreKey], tkeys[paramstypes.TStoreKey]))
	SetKeeper(keepers, initConsensusParamsKeeper(appCodec, keys))

	// BaseApp handles interactions with Tendermint through the ABCI protocol
	bApp := initBaseApp(db, traceStore, encodingConfig, keepers, baseAppOptions, logger)

	moduleAccountPermissions := InitModuleAccountPermissions()

	// set up predefined keepers
	SetKeeper(keepers, initAccountKeeper(appCodec, keys, moduleAccountPermissions))
	SetKeeper(keepers, initBankKeeper(logger, appCodec, keys, keepers, moduleAccountPermissions))
	SetKeeper(keepers, initStakingKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initMintKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initDistributionKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initSlashingKeeper(appCodec, encodingConfig.Amino, keys, keepers))

	// get skipUpgradeHeights from the app options
	skipUpgradeHeights := map[int64]bool{}
	for _, h := range cast.ToIntSlice(appOpts.Get(server.FlagUnsafeSkipUpgrades)) {
		skipUpgradeHeights[int64(h)] = true
	}
	homePath := cast.ToString(appOpts.Get(flags.FlagHome))
	SetKeeper(keepers, initUpgradeKeeper(appCodec, keys, skipUpgradeHeights, homePath, bApp))
	SetKeeper(keepers, initEvidenceKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initFeegrantKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initAuthzKeeper(appCodec, keys, keepers, bApp))
	SetKeeper(keepers, initIBCKeeper(appCodec, keys, keepers))

	// set up custom axelar keepers
	SetKeeper(keepers, initAxelarDistributionKeeper(keepers))
	SetKeeper(keepers, initAxelarnetKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initEvmKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initNexusKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initRewardKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initMultisigKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initSnapshotKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initVoteKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initPermissionKeeper(appCodec, keys, keepers))
	SetKeeper(keepers, initFeePolicyKeeper(keepers))

	// set up ibc/wasm keepers
	wasmHooks := InitWasmHooks(keys)
	ics4Wrapper := InitICS4Wrapper(keepers, wasmHooks)
	SetKeeper(keepers, initIBCTransferKeeper(appCodec, keys, keepers, ics4Wrapper, bApp.MsgServiceRouter()))

	SetKeeper(keepers, initAxelarIBCKeeper(keepers))

	if IsWasmEnabled() {
		wasmDir := cast.ToString(appOpts.Get(WasmDirFlag))
		if wasmDir == "" {
			dbDir := cast.ToString(appOpts.Get("db_dir"))
			wasmDir = filepath.Join(homePath, dbDir, "wasm")
		}

		wasmPath, err := filepath.Abs(wasmDir)
		if err != nil {
			panic(fmt.Sprintf("failed to resolve absolute path for new wasm dir %s: %v", wasmDir, err))
		}

		SetKeeper(keepers, initWasmKeeper(encodingConfig, keys, keepers, bApp, appOpts, wasmOpts, wasmPath))
		SetKeeper(keepers, initWasmContractKeeper(keepers))

		// set the contract keeper for the Ics20WasmHooks
		if wasmHooks != nil {
			wasmHooks.ContractKeeper = GetKeeper[wasm.Keeper](keepers)
		}
	}

	// set up governance keeper last when it has access to all other keepers to set up governance routes
	SetKeeper(keepers, initGovernanceKeeper(appCodec, keys, keepers, bApp.MsgServiceRouter()))

	// set routers
	GetKeeper[nexusKeeper.Keeper](keepers).SetMessageRouter(initMessageRouter(keepers))
	GetKeeper[ibckeeper.Keeper](keepers).SetRouter(initIBCRouter(keepers, initIBCMiddleware(keepers, ics4Wrapper)))

	// light clients are no longer implicit in ibc-go v10; they must be registered
	// as modular routes on the client keeper
	tmLightClientModule := ibctendermint.NewLightClientModule(appCodec, GetKeeper[ibckeeper.Keeper](keepers).ClientKeeper.GetStoreProvider())
	GetKeeper[ibckeeper.Keeper](keepers).ClientKeeper.AddRoute(ibctendermint.ModuleName, &tmLightClientModule)

	// register the staking hooks
	GetKeeper[stakingkeeper.Keeper](keepers).SetHooks(
		stakingtypes.NewMultiStakingHooks(
			GetKeeper[distrkeeper.Keeper](keepers).Hooks(),
			GetKeeper[slashingkeeper.Keeper](keepers).Hooks(),
		),
	)

	/****  Module Options ****/

	appModules := initAppModules(
		keepers,
		keys,
		bApp,
		encodingConfig,
		appOpts,
		axelarnet.NewAppModule(
			*GetKeeper[axelarnetKeeper.IBCKeeper](keepers),
			GetKeeper[nexusKeeper.Keeper](keepers),
			axelarbankkeeper.NewBankKeeper(GetKeeper[bankkeeper.BaseKeeper](keepers)),
			GetKeeper[authkeeper.AccountKeeper](keepers),
			logger,
		),
	)
	appModules = append(appModules, ibctendermint.NewAppModule(tmLightClientModule))

	mm := NewFilteredModuleManager(appModules, []string{vestingtypes.ModuleName})
	mm.SetOrderMigrations(orderMigrations()...)
	// upgrade module must run first so upgrades are applied before any other
	// module's PreBlock; x/auth implements PreBlock since cosmos-sdk v0.53
	mm.SetOrderPreBlockers(upgradetypes.ModuleName, authtypes.ModuleName)
	mm.SetOrderBeginBlockers(orderBeginBlockers()...)
	mm.SetOrderEndBlockers(orderEndBlockers()...)
	mm.SetOrderInitGenesis(orderModulesForGenesis()...)

	configurator := module.NewConfigurator(appCodec, bApp.MsgServiceRouter(), bApp.GRPCQueryRouter())
	mm.RegisterServices(configurator)

	var app = &AxelarApp{
		BaseApp:           bApp,
		appCodec:          appCodec,
		interfaceRegistry: encodingConfig.InterfaceRegistry,
		Keepers:           keepers,
		Keys:              keys,
		mm:                mm,
	}

	app.setUpgradeBehaviour(configurator, keepers)

	// initialize stores
	app.MountKVStores(keys)
	app.MountTransientStores(tkeys)

	// The initChainer handles translating the genesis.json file into initial state for the network
	app.SetInitChainer(app.InitChainer)
	app.SetPreBlocker(app.PreBlocker)
	app.SetBeginBlocker(app.BeginBlocker)
	app.SetEndBlocker(app.EndBlocker)

	app.SetAnteHandler(initAnteHandlers(encodingConfig, keys, keepers, appOpts))

	// Register wasm snapshot extension for state-sync compatibility
	// MUST be done before loading the version
	app.registerWasmSnapshotExtension(keepers)

	if loadLatest {
		if err := app.LoadLatestVersion(); err != nil {
			tmos.Exit(err.Error())
		}

		if IsWasmEnabled() {
			ctx := app.BaseApp.NewUncachedContext(true, tmproto.Header{})

			// Initialize pinned codes in wasmvm as they are not persisted there
			if err := GetKeeper[wasm.Keeper](keepers).InitializePinnedCodes(ctx); err != nil {
				tmos.Exit(fmt.Sprintf("failed initialize pinned codes %s", err))
			}
		}
	}

	/* ==== at this point all stores are fully loaded ==== */

	// we need to ensure that all chain subspaces are loaded at start-up to prevent unexpected consensus failures
	// when the params keeper is used outside the evm module's context
	GetKeeper[evmKeeper.BaseKeeper](keepers).InitChains(app.NewContext(true))

	return app
}

func InitICS4Wrapper(keepers *KeeperCache, wasmHooks *ibchooks.WasmHooks) ibchooks.ICS4Middleware {
	// ICS4Wrapper deals with sending IBC packets.
	// Wrap the channel keeper with a chain activation check to reject
	// outgoing packets to deactivated chains.
	ics4Wrapper := axelarnet.NewChainActivationICS4Wrapper(
		GetKeeper[ibckeeper.Keeper](keepers).ChannelKeeper,
		GetKeeper[axelarnetKeeper.Keeper](keepers),
		GetKeeper[nexusKeeper.Keeper](keepers),
	)
	// create a middleware to integrate wasm hooks into the ibc pipeline
	if wasmHooks != nil {
		return ibchooks.NewICS4Middleware(ics4Wrapper, wasmHooks)
	} else {
		// we need to erase the type of the wasm hooks when it is nil so the middleware's type casts do not succeed.
		// Otherwise, it will try to call an interface function on wasmHooks and create a nil pointer panic
		return ibchooks.NewICS4Middleware(ics4Wrapper, nil)
	}
}

func initIBCMiddleware(keepers *KeeperCache, ics4Middleware ibchooks.ICS4Middleware) ibchooks.IBCMiddleware {
	// IBCModule deals with received IBC packets.
	ibcModule := axelarnet.NewAxelarnetIBCModule(
		transfer.NewIBCModule(*GetKeeper[ibctransferkeeper.Keeper](keepers)),
		*GetKeeper[axelarnetKeeper.IBCKeeper](keepers),
		GetKeeper[nexusKeeper.Keeper](keepers),
		axelarbankkeeper.NewBankKeeper(GetKeeper[bankkeeper.BaseKeeper](keepers)),
	)

	// By merging the middlewares the receiving IBC Module has access to all registered hooks in the ICS4Middleware
	return ibchooks.NewIBCMiddleware(ibcModule, &ics4Middleware)
}

func InitWasmHooks(keys map[string]*store.KVStoreKey) *ibchooks.WasmHooks {
	if !(IsWasmEnabled() && IsIBCWasmHooksEnabled()) {
		return nil
	}

	// Configure the IBC hooks keeper to make wasm calls via IBC transfer memo
	ibcHooksKeeper := ibchookskeeper.NewKeeper(keys[ibchookstypes.StoreKey])

	// The contract keeper needs to be set later
	var wasmHooks = ibchooks.NewWasmHooks(&ibcHooksKeeper, nil, sdk.GetConfig().GetBech32AccountAddrPrefix())
	return &wasmHooks
}

func initIBCRouter(keepers *KeeperCache, axelarnetModule porttypes.IBCModule) *porttypes.Router {
	// Finalize the IBC router
	// Create static IBC router, add axelarnet module as the IBC transfer route, and seal it
	ibcRouter := porttypes.NewRouter()
	ibcRouter.AddRoute(ibctransfertypes.ModuleName, axelarnetModule)
	if IsWasmEnabled() {
		// Create wasm ibc stack
		var wasmStack porttypes.IBCModule = wasm.NewIBCHandler(
			GetKeeper[wasm.Keeper](keepers),
			GetKeeper[ibckeeper.Keeper](keepers).ChannelKeeper,
			GetKeeper[ibckeeper.Keeper](keepers).ChannelKeeper,
		)
		ibcRouter.AddRoute(wasm.ModuleName, wasmStack)
	}
	return ibcRouter
}

func initMessageRouter(keepers *KeeperCache) nexusTypes.MessageRouter {
	messageRouter := nexusTypes.NewMessageRouter().
		AddRoute(evmTypes.ModuleName, evmKeeper.NewMessageRoute()).
		AddRoute(axelarnetTypes.ModuleName, axelarnetKeeper.NewMessageRoute(
			GetKeeper[axelarnetKeeper.IBCKeeper](keepers),
			GetKeeper[feegrantkeeper.Keeper](keepers),
			axelarbankkeeper.NewBankKeeper(GetKeeper[bankkeeper.BaseKeeper](keepers)),
			GetKeeper[nexusKeeper.Keeper](keepers),
			GetKeeper[stakingkeeper.Keeper](keepers),
		))

	if IsWasmEnabled() {
		messageRouter.AddRoute(wasm.ModuleName, nexusKeeper.NewMessageRoute(
			GetKeeper[nexusKeeper.Keeper](keepers),
			GetKeeper[authkeeper.AccountKeeper](keepers),
			GetKeeper[wasmkeeper.PermissionedKeeper](keepers),
		))
	}
	return messageRouter
}

func (app *AxelarApp) registerWasmSnapshotExtension(keepers *KeeperCache) {
	// Register wasm snapshot extension to enable state-sync compatibility for wasm.
	// MUST be done before loading the version
	// Requires the snapshot store to be created and registered as a BaseAppOption
	if IsWasmEnabled() {
		if manager := app.SnapshotManager(); manager != nil {
			err := manager.RegisterExtensions(
				wasmkeeper.NewWasmSnapshotter(app.CommitMultiStore(), GetKeeper[wasm.Keeper](keepers)),
			)
			if err != nil {
				panic(fmt.Errorf("failed to register snapshot extension: %s", err))
			}
		}
	}
}

func initBaseApp(db dbm.DB, traceStore io.Writer, encodingConfig axelarParams.EncodingConfig, keepers *KeeperCache, baseAppOptions []func(*bam.BaseApp), logger sdklogger.Logger) *bam.BaseApp {
	bApp := bam.NewBaseApp(Name, logger, db, encodingConfig.TxConfig.TxDecoder(), baseAppOptions...)
	bApp.SetCommitMultiStoreTracer(traceStore)
	bApp.SetVersion(version.Version)
	bApp.SetInterfaceRegistry(encodingConfig.InterfaceRegistry)
	bApp.SetParamStore(GetKeeper[consensusparamkeeper.Keeper](keepers).ParamsStore)
	bApp.SetTxEncoder(encodingConfig.TxConfig.TxEncoder())

	return bApp
}

func initAppModules(keepers *KeeperCache, keys map[string]*store.KVStoreKey, bApp *bam.BaseApp, encodingConfig axelarParams.EncodingConfig, appOpts servertypes.AppOptions, axelarnetModule axelarnet.AppModule) []module.AppModule {
	// NOTE: we may consider parsing `appOpts` inside module constructors. For the moment
	// we prefer to be more strict in what arguments the modules expect.
	appCodec := encodingConfig.Codec
	paramsKeeper := GetKeeper[paramskeeper.Keeper](keepers)

	distrAppModule := distr.NewAppModule(appCodec, *GetKeeper[distrkeeper.Keeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers), GetKeeper[bankkeeper.BaseKeeper](keepers), GetKeeper[stakingkeeper.Keeper](keepers), funcs.MustOk(paramsKeeper.GetSubspace(distrtypes.ModuleName)))

	appModules := []module.AppModule{
		genutil.NewAppModule(GetKeeper[authkeeper.AccountKeeper](keepers), GetKeeper[stakingkeeper.Keeper](keepers), bApp, encodingConfig.TxConfig),
		auth.NewAppModule(appCodec, *GetKeeper[authkeeper.AccountKeeper](keepers), nil, funcs.MustOk(paramsKeeper.GetSubspace(authtypes.ModuleName))),
		vesting.NewAppModule(*GetKeeper[authkeeper.AccountKeeper](keepers), GetKeeper[bankkeeper.BaseKeeper](keepers)),

		// bank module accepts a reference to the base keeper, but panics when RegisterService is called on a reference, so we need to dereference it
		bank.NewAppModule(appCodec, *GetKeeper[bankkeeper.BaseKeeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers), funcs.MustOk(paramsKeeper.GetSubspace(banktypes.ModuleName))),
		gov.NewAppModule(appCodec, GetKeeper[govkeeper.Keeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers), GetKeeper[bankkeeper.BaseKeeper](keepers), funcs.MustOk(paramsKeeper.GetSubspace(govtypes.ModuleName))),
		mint.NewAppModule(appCodec, *GetKeeper[mintkeeper.Keeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers), nil, funcs.MustOk(paramsKeeper.GetSubspace(minttypes.ModuleName))),
		slashing.NewAppModule(appCodec, *GetKeeper[slashingkeeper.Keeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers), GetKeeper[bankkeeper.BaseKeeper](keepers), GetKeeper[stakingkeeper.Keeper](keepers), funcs.MustOk(paramsKeeper.GetSubspace(slashingtypes.ModuleName)), encodingConfig.InterfaceRegistry),
		axelardistr.NewAppModule(distrAppModule, *GetKeeper[axelardistrkeeper.Keeper](keepers)),
		staking.NewAppModule(appCodec, GetKeeper[stakingkeeper.Keeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers), GetKeeper[bankkeeper.BaseKeeper](keepers), funcs.MustOk(paramsKeeper.GetSubspace(stakingtypes.ModuleName))),
		upgrade.NewAppModule(GetKeeper[upgradekeeper.Keeper](keepers), GetKeeper[authkeeper.AccountKeeper](keepers).AddressCodec()),
		evidence.NewAppModule(*GetKeeper[evidencekeeper.Keeper](keepers)),
		params.NewAppModule(*GetKeeper[paramskeeper.Keeper](keepers)),
		consensus.NewAppModule(appCodec, *GetKeeper[consensusparamkeeper.Keeper](keepers)),
	}

	// wasm module needs to be added in a specific order, so we cannot just append it at the end
	if IsWasmEnabled() {
		appModules = append(
			appModules,
			wasm.NewAppModule(
				appCodec,
				GetKeeper[wasm.Keeper](keepers),
				GetKeeper[stakingkeeper.Keeper](keepers),
				GetKeeper[authkeeper.AccountKeeper](keepers),
				GetKeeper[bankkeeper.BaseKeeper](keepers),
				bApp.MsgServiceRouter(),
				funcs.MustOk(paramsKeeper.GetSubspace(wasmtypes.ModuleName)),
			),
		)
	}

	if IsIBCWasmHooksEnabled() {
		appModules = append(appModules, ibchooks.NewAppModule(*GetKeeper[authkeeper.AccountKeeper](keepers)))
	}

	appModules = append(appModules,
		evidence.NewAppModule(*GetKeeper[evidencekeeper.Keeper](keepers)),
		ibc.NewAppModule(GetKeeper[ibckeeper.Keeper](keepers)),
		transfer.NewAppModule(*GetKeeper[ibctransferkeeper.Keeper](keepers)),
		feegrantmodule.NewAppModule(
			appCodec,
			GetKeeper[authkeeper.AccountKeeper](keepers),
			GetKeeper[bankkeeper.BaseKeeper](keepers),
			*GetKeeper[feegrantkeeper.Keeper](keepers),
			encodingConfig.InterfaceRegistry,
		),
		authzmodule.NewAppModule(
			appCodec,
			*GetKeeper[authzkeeper.Keeper](keepers),
			GetKeeper[authkeeper.AccountKeeper](keepers),
			GetKeeper[bankkeeper.BaseKeeper](keepers),
			encodingConfig.InterfaceRegistry,
		),
		snapshot.NewAppModule(*GetKeeper[snapKeeper.Keeper](keepers)),
		multisig.NewAppModule(
			*GetKeeper[multisigKeeper.Keeper](keepers),
			GetKeeper[stakingkeeper.Keeper](keepers),
			GetKeeper[slashingkeeper.Keeper](keepers),
			GetKeeper[snapKeeper.Keeper](keepers),
			GetKeeper[rewardKeeper.Keeper](keepers),
			GetKeeper[nexusKeeper.Keeper](keepers),
		),
		tss.NewAppModule(),
		vote.NewAppModule(*GetKeeper[voteKeeper.Keeper](keepers)),
		nexus.NewAppModule(
			*GetKeeper[nexusKeeper.Keeper](keepers),
			GetKeeper[snapKeeper.Keeper](keepers),
			GetKeeper[slashingkeeper.Keeper](keepers),
			GetKeeper[stakingkeeper.Keeper](keepers),
			GetKeeper[axelarnetKeeper.Keeper](keepers),
			GetKeeper[rewardKeeper.Keeper](keepers),
			GetKeeper[bankkeeper.BaseKeeper](keepers),
			GetKeeper[authkeeper.AccountKeeper](keepers),
		),
		evm.NewAppModule(
			GetKeeper[evmKeeper.BaseKeeper](keepers),
			GetKeeper[voteKeeper.Keeper](keepers),
			GetKeeper[nexusKeeper.Keeper](keepers),
			GetKeeper[snapKeeper.Keeper](keepers),
			GetKeeper[stakingkeeper.Keeper](keepers),
			GetKeeper[slashingkeeper.Keeper](keepers),
			GetKeeper[multisigKeeper.Keeper](keepers),
			GetKeeper[permissionKeeper.Keeper](keepers),
		),
		axelarnetModule,
		reward.NewAppModule(
			*GetKeeper[rewardKeeper.Keeper](keepers),
			GetKeeper[nexusKeeper.Keeper](keepers),
			*GetKeeper[mintkeeper.Keeper](keepers),
			GetKeeper[stakingkeeper.Keeper](keepers),
			GetKeeper[slashingkeeper.Keeper](keepers),
			GetKeeper[multisigKeeper.Keeper](keepers),
			GetKeeper[snapKeeper.Keeper](keepers),
			GetKeeper[bankkeeper.BaseKeeper](keepers),
			bApp.MsgServiceRouter(),
			encodingConfig.Codec,
		),
		permission.NewAppModule(*GetKeeper[permissionKeeper.Keeper](keepers)),
		feepolicy.NewAppModule(*GetKeeper[feepolicyKeeper.Keeper](keepers)),
		auxiliary.NewAppModule(encodingConfig.Codec, bApp.MsgServiceRouter()),
	)
	return appModules
}

func mustReadWasmConfig(appOpts servertypes.AppOptions) wasmtypes.NodeConfig {
	wasmConfig, err := wasm.ReadNodeConfig(appOpts)
	if err != nil {
		panic(fmt.Sprintf("error while reading wasm config: %s", err))
	}
	return wasmConfig
}

func initAnteHandlers(encodingConfig axelarParams.EncodingConfig, keys map[string]*store.KVStoreKey, keepers *KeeperCache, appOpts servertypes.AppOptions) sdk.AnteHandler {
	// The baseAnteHandler handles signature verification and transaction pre-processing
	baseAnteHandler, err := authAnte.NewAnteHandler(
		authAnte.HandlerOptions{
			AccountKeeper:   GetKeeper[authkeeper.AccountKeeper](keepers),
			BankKeeper:      GetKeeper[bankkeeper.BaseKeeper](keepers),
			SignModeHandler: encodingConfig.TxConfig.SignModeHandler(),
			FeegrantKeeper:  GetKeeper[feegrantkeeper.Keeper](keepers),
			SigGasConsumer:  authAnte.DefaultSigVerificationGasConsumer,
		},
	)
	if err != nil {
		panic(err)
	}

	preDecorators := InitCustomAntePreDecorators(keepers)
	postDecorators := InitCustomAntePostDecorators(encodingConfig, keys, keepers, appOpts)

	anteDecorators := make([]sdk.AnteDecorator, 0, len(preDecorators)+1+len(postDecorators))
	anteDecorators = append(anteDecorators, preDecorators...)
	anteDecorators = append(anteDecorators, ante.NewAnteHandlerDecorator(baseAnteHandler))
	anteDecorators = append(anteDecorators, postDecorators...)

	return sdk.ChainAnteDecorators(anteDecorators...)
}

func InitCustomAntePreDecorators(keepers *KeeperCache) []sdk.AnteDecorator {
	return []sdk.AnteDecorator{
		// reject fees in non-allowlisted denominations
		ante.NewLimitFeeDenomDecorator(GetKeeper[feepolicyKeeper.Keeper](keepers)),
	}
}

func InitCustomAntePostDecorators(
	encodingConfig axelarParams.EncodingConfig,
	keys map[string]*store.KVStoreKey,
	keepers *KeeperCache,
	appOpts servertypes.AppOptions,
) []sdk.AnteDecorator {
	var anteDecorators []sdk.AnteDecorator

	// unwrap batch messages, must be done before any other custom decorators
	anteDecorators = append(anteDecorators, ante.NewBatchDecorator(encodingConfig.Codec))

	// enforce wasm limits earlier in the ante handler chain
	if IsWasmEnabled() {
		wasmConfig := mustReadWasmConfig(appOpts)
		wasmAnteDecorators := []sdk.AnteDecorator{
			ante.NewLimitSimulationGasDecorator(wasmConfig.SimulationGasLimit),
			wasmkeeper.NewCountTXDecorator(runtime.NewKVStoreService(keys[wasmtypes.StoreKey])),
			wasmkeeper.NewGasRegisterDecorator(GetKeeper[wasmkeeper.Keeper](keepers).GetGasRegister()),
			wasmkeeper.NewTxContractsDecorator(),
		}

		anteDecorators = append(anteDecorators, wasmAnteDecorators...)
	}

	anteDecorators = append(anteDecorators,
		ibcante.NewRedundantRelayDecorator(GetKeeper[ibckeeper.Keeper](keepers)),
		ante.NewCheckRefundFeeDecorator(
			encodingConfig.Codec,
			GetKeeper[authkeeper.AccountKeeper](keepers),
			GetKeeper[stakingkeeper.Keeper](keepers),
			GetKeeper[snapKeeper.Keeper](keepers),
			GetKeeper[rewardKeeper.Keeper](keepers),
		),
		ante.NewAnteHandlerDecorator(
			initMessageAnteDecorators(encodingConfig, keepers).ToAnteHandler()),
	)
	return anteDecorators
}

func initMessageAnteDecorators(encodingConfig axelarParams.EncodingConfig, keepers *KeeperCache) ante.MessageAnteHandler {
	return ante.ChainMessageAnteDecorators(
		ante.NewLogMsgDecorator(encodingConfig.Codec),
		ante.NewCheckCommissionRate(GetKeeper[stakingkeeper.Keeper](keepers)),
		ante.NewUndelegateDecorator(
			GetKeeper[multisigKeeper.Keeper](keepers),
			GetKeeper[nexusKeeper.Keeper](keepers),
			GetKeeper[snapKeeper.Keeper](keepers),
		),

		ante.NewCheckProxy(GetKeeper[snapKeeper.Keeper](keepers)),
		ante.NewRestrictedTx(GetKeeper[permissionKeeper.Keeper](keepers), encodingConfig.Codec),
	)
}

func InitModuleAccountPermissions() map[string][]string {
	return map[string][]string{
		authtypes.FeeCollectorName:     nil,
		distrtypes.ModuleName:          {authtypes.Minter, authtypes.Burner},
		minttypes.ModuleName:           {authtypes.Minter},
		stakingtypes.BondedPoolName:    {authtypes.Burner, authtypes.Staking},
		stakingtypes.NotBondedPoolName: {authtypes.Burner, authtypes.Staking},
		govtypes.ModuleName:            {authtypes.Burner},
		ibctransfertypes.ModuleName:    {authtypes.Minter, authtypes.Burner},
		axelarnetTypes.ModuleName:      nil,
		rewardTypes.ModuleName:         {authtypes.Minter},
		wasm.ModuleName:                {authtypes.Burner},
		nexusTypes.ModuleName:          {authtypes.Minter, authtypes.Burner},
	}
}

func orderMigrations() []string {
	migrationOrder := []string{
		// auth module needs to go first
		authtypes.ModuleName,
		// sdk modules
		upgradetypes.ModuleName,
		govtypes.ModuleName,
		stakingtypes.ModuleName,
		ibctransfertypes.ModuleName,
		ibcexported.ModuleName,
		ibctendermint.ModuleName,
		banktypes.ModuleName,
		distrtypes.ModuleName,
		slashingtypes.ModuleName,
		minttypes.ModuleName,
		genutiltypes.ModuleName,
		evidencetypes.ModuleName,
		feegrant.ModuleName,
		authz.ModuleName,
		paramstypes.ModuleName,
		vestingtypes.ModuleName,
		consensusparamtypes.ModuleName,
	}

	// wasm module needs to be added in a specific order, so we cannot just append it at the end
	if IsWasmEnabled() {
		migrationOrder = append(migrationOrder, wasm.ModuleName)
	}

	if IsIBCWasmHooksEnabled() {
		migrationOrder = append(migrationOrder, ibchookstypes.ModuleName)
	}

	// axelar modules
	migrationOrder = append(migrationOrder,
		multisigTypes.ModuleName,
		tssTypes.ModuleName,
		rewardTypes.ModuleName,
		voteTypes.ModuleName,
		evmTypes.ModuleName,
		nexusTypes.ModuleName,
		permissionTypes.ModuleName,
		snapTypes.ModuleName,
		axelarnetTypes.ModuleName,
		feepolicyTypes.ModuleName,
		auxiliarytypes.ModuleName,
	)
	return migrationOrder
}

func orderBeginBlockers() []string {
	// During begin block slashing happens after distr.BeginBlocker so that
	// there is nothing left over in the validator fee pool, so as to keep the
	// CanWithdrawInvariant invariant.
	// NOTE: staking module is required if HistoricalEntries param > 0
	beginBlockerOrder := []string{
		// upgrades should be run first
		upgradetypes.ModuleName,
		govtypes.ModuleName,
		stakingtypes.ModuleName,
		ibctransfertypes.ModuleName,
		ibcexported.ModuleName,
		authtypes.ModuleName,
		banktypes.ModuleName,
		distrtypes.ModuleName,
		slashingtypes.ModuleName,
		minttypes.ModuleName,
		genutiltypes.ModuleName,
		evidencetypes.ModuleName,
		feegrant.ModuleName,
		authz.ModuleName,
		paramstypes.ModuleName,
		vestingtypes.ModuleName,
		consensusparamtypes.ModuleName,
	}

	// wasm module needs to be added in a specific order, so we cannot just append it at the end
	if IsWasmEnabled() {
		beginBlockerOrder = append(beginBlockerOrder, wasm.ModuleName)
	}

	if IsIBCWasmHooksEnabled() {
		beginBlockerOrder = append(beginBlockerOrder, ibchookstypes.ModuleName)
	}

	return beginBlockerOrder
}

func orderEndBlockers() []string {
	endBlockerOrder := []string{
		govtypes.ModuleName,
		stakingtypes.ModuleName,
		ibctransfertypes.ModuleName,
		ibcexported.ModuleName,
		feegrant.ModuleName,
		authz.ModuleName,
		authtypes.ModuleName,
		banktypes.ModuleName,
		distrtypes.ModuleName,
		slashingtypes.ModuleName,
		minttypes.ModuleName,
		genutiltypes.ModuleName,
		evidencetypes.ModuleName,
		paramstypes.ModuleName,
		upgradetypes.ModuleName,
		vestingtypes.ModuleName,
		consensusparamtypes.ModuleName,
	}

	// wasm module needs to be added in a specific order, so we cannot just append it at the end
	if IsWasmEnabled() {
		endBlockerOrder = append(endBlockerOrder, wasm.ModuleName)
	}

	if IsIBCWasmHooksEnabled() {
		endBlockerOrder = append(endBlockerOrder, ibchookstypes.ModuleName)
	}

	// axelar custom modules
	endBlockerOrder = append(endBlockerOrder,
		axelarnetTypes.ModuleName,
		multisigTypes.ModuleName,
		evmTypes.ModuleName,
		nexusTypes.ModuleName,
		rewardTypes.ModuleName,
		voteTypes.ModuleName,
	)

	return endBlockerOrder
}

func orderModulesForGenesis() []string {
	// Sets the order of Genesis - Order matters, genutil is to always come last
	// NOTE: The genutils module must occur after staking so that pools are
	// properly initialized with tokens from genesis accounts.
	genesisOrder := []string{
		authtypes.ModuleName,
		banktypes.ModuleName,
		distrtypes.ModuleName,
		stakingtypes.ModuleName,
		slashingtypes.ModuleName,
		govtypes.ModuleName,
		minttypes.ModuleName,
		feepolicyTypes.ModuleName,
		genutiltypes.ModuleName,
		evidencetypes.ModuleName,
		ibcexported.ModuleName,
		ibctransfertypes.ModuleName,
		feegrant.ModuleName,
		authz.ModuleName,
		paramstypes.ModuleName,
		upgradetypes.ModuleName,
		vestingtypes.ModuleName,
		consensusparamtypes.ModuleName,
	}

	// wasm module needs to be added in a specific order, so we cannot just append it at the end
	if IsWasmEnabled() {
		genesisOrder = append(genesisOrder, wasm.ModuleName)
	}

	if IsIBCWasmHooksEnabled() {
		genesisOrder = append(genesisOrder, ibchookstypes.ModuleName)
	}

	genesisOrder = append(genesisOrder,
		snapTypes.ModuleName,
		multisigTypes.ModuleName,
		tssTypes.ModuleName,
		nexusTypes.ModuleName,
		evmTypes.ModuleName, // Run evm end blocker after nexus so GMP calls routed to EVM get processed within the same block
		voteTypes.ModuleName,
		axelarnetTypes.ModuleName,
		rewardTypes.ModuleName,
		permissionTypes.ModuleName,
		auxiliarytypes.ModuleName,
	)
	return genesisOrder
}

func CreateStoreKeys() map[string]*store.KVStoreKey {
	keys := []string{
		authtypes.StoreKey,
		banktypes.StoreKey,
		stakingtypes.StoreKey,
		minttypes.StoreKey,
		distrtypes.StoreKey,
		slashingtypes.StoreKey,
		govtypes.StoreKey,
		paramstypes.StoreKey,
		upgradetypes.StoreKey,
		evidencetypes.StoreKey,
		ibcexported.StoreKey,
		ibctransfertypes.StoreKey,
		feegrant.StoreKey,
		authz.ModuleName,
		consensusparamtypes.StoreKey,

		voteTypes.StoreKey,
		evmTypes.StoreKey,
		snapTypes.StoreKey,
		multisigTypes.StoreKey,
		tssTypes.StoreKey,
		nexusTypes.StoreKey,
		axelarnetTypes.StoreKey,
		rewardTypes.StoreKey,
		permissionTypes.StoreKey,
	}

	if IsWasmEnabled() {
		keys = append(keys, wasm.StoreKey)
	}

	if IsIBCWasmHooksEnabled() {
		keys = append(keys, ibchookstypes.StoreKey)
	}

	return store.NewKVStoreKeys(keys...)
}

// GenesisState represents chain state at the start of the chain. Any initial state (account balances) are stored here.
type GenesisState map[string]json.RawMessage

// InitChainer handles the chain initialization from a genesis file
func (app *AxelarApp) InitChainer(ctx sdk.Context, req *abci.RequestInitChain) (*abci.ResponseInitChain, error) {
	var genesisState GenesisState
	if err := tmjson.Unmarshal(req.AppStateBytes, &genesisState); err != nil {
		panic(err)
	}

	err := GetKeeper[upgradekeeper.Keeper](app.Keepers).SetModuleVersionMap(ctx, app.mm.GetVersionMap())
	if err != nil {
		panic(err)
	}

	return app.mm.InitGenesis(ctx, app.appCodec, genesisState)
}

// PreBlocker checks if there is a scheduled upgrade and executes it if it is ready
func (app *AxelarApp) PreBlocker(ctx sdk.Context, _ *abci.RequestFinalizeBlock) (*sdk.ResponsePreBlock, error) {
	return app.mm.PreBlock(ctx)
}

// BeginBlocker calls the BeginBlock() function of every module at the beginning of a new block
func (app *AxelarApp) BeginBlocker(ctx sdk.Context) (sdk.BeginBlock, error) {
	return app.mm.BeginBlock(ctx)
}

// EndBlocker calls the EndBlock() function of every module at the end of a block
func (app *AxelarApp) EndBlocker(ctx sdk.Context) (sdk.EndBlock, error) {
	return app.mm.EndBlock(ctx)
}

// LoadHeight loads the application version at a given height. It will panic if called
// more than once on a running baseapp.
func (app *AxelarApp) LoadHeight(height int64) error {
	return app.LoadVersion(height)
}

// AppCodec returns AxelarApp's app codec.
//
// NOTE: This is solely to be used for testing purposes as it may be desirable
// for modules to register their own custom testing types.
func (app *AxelarApp) AppCodec() codec.Codec {
	return app.appCodec
}

// RegisterAPIRoutes registers all application module routes with the provided
// API server.
func (app *AxelarApp) RegisterAPIRoutes(apiSvr *api.Server, apiConfig config.APIConfig) {
	clientCtx := apiSvr.ClientCtx

	// Register new tx routes from grpc-gateway.
	authtx.RegisterGRPCGatewayRoutes(clientCtx, apiSvr.GRPCGatewayRouter)

	// Register new tendermint queries routes from grpc-gateway.
	cmtservice.RegisterGRPCGatewayRoutes(clientCtx, apiSvr.GRPCGatewayRouter)

	// Register node gRPC service for grpc-gateway.
	nodeservice.RegisterGRPCGatewayRoutes(clientCtx, apiSvr.GRPCGatewayRouter)

	// Register grpc-gateway routes for all modules.
	GetModuleBasics().RegisterGRPCGatewayRoutes(clientCtx, apiSvr.GRPCGatewayRouter)

	// register swagger API from root so that other applications can override easily
	if apiConfig.Swagger {
		RegisterSwaggerAPI(apiSvr.Router)
	}
}

// RegisterSwaggerAPI registers swagger route with API Server
func RegisterSwaggerAPI(rtr *mux.Router) {
	statikFS, err := fs.New()
	if err != nil {
		panic(err)
	}

	staticServer := http.FileServer(statikFS)
	rtr.PathPrefix("/static/").Handler(http.StripPrefix("/static/", staticServer))
}

// RegisterTxService implements the Application.RegisterTxService method.
func (app *AxelarApp) RegisterTxService(clientCtx client.Context) {
	authtx.RegisterTxService(app.BaseApp.GRPCQueryRouter(), clientCtx, app.BaseApp.Simulate, app.interfaceRegistry)
}

// RegisterTendermintService implements the Application.RegisterTendermintService method.
func (app *AxelarApp) RegisterTendermintService(clientCtx client.Context) {
	cmtservice.RegisterTendermintService(clientCtx, app.BaseApp.GRPCQueryRouter(), app.interfaceRegistry, app.Query)
}

func (app *AxelarApp) RegisterNodeService(clientCtx client.Context, cfg config.Config) {
	nodeservice.RegisterNodeService(clientCtx, app.GRPCQueryRouter(), cfg)
}

// GetModuleBasics initializes the module BasicManager is in charge of setting up basic,
// non-dependant module elements, such as codec registration and genesis verification.
// Initialization is dependent on whether wasm is enabled.
func GetModuleBasics() module.BasicManager {
	managers := []module.AppModuleBasic{
		auth.AppModuleBasic{},
		genutil.NewAppModuleBasic(genutiltypes.DefaultMessageValidator),
		bank.AppModuleBasic{},
		staking.AppModuleBasic{},
		mint.AppModuleBasic{},
		distr.AppModuleBasic{},
		gov.NewAppModuleBasic(nil),
		params.AppModuleBasic{},
		slashing.AppModuleBasic{},
		feegrantmodule.AppModuleBasic{},
		authzmodule.AppModuleBasic{},
		upgrade.AppModuleBasic{},
		evidence.AppModuleBasic{},
		vesting.AppModuleBasic{},
		consensus.AppModuleBasic{},
		ibc.AppModuleBasic{},
		ibctendermint.AppModuleBasic{},
		transfer.AppModuleBasic{},

		multisig.AppModuleBasic{},
		tss.AppModuleBasic{},
		vote.AppModuleBasic{},
		evm.AppModuleBasic{},
		snapshot.AppModuleBasic{},
		nexus.AppModuleBasic{},
		axelarnet.AppModuleBasic{},
		reward.AppModuleBasic{},
		permission.AppModuleBasic{},
		feepolicy.AppModuleBasic{},
		auxiliary.AppModuleBasic{},
	}

	if IsWasmEnabled() {
		managers = append(managers, NewWasmAppModuleBasicOverride(wasm.AppModuleBasic{}))
	}

	if IsIBCWasmHooksEnabled() {
		managers = append(managers, ibchooks.AppModuleBasic{})
	}

	return module.NewBasicManager(managers...)
}

// IsWasmEnabled returns whether wasm is enabled
func IsWasmEnabled() bool {
	return WasmEnabled == "true"
}

// IsIBCWasmHooksEnabled returns whether ibc wasm hooks are enabled
func IsIBCWasmHooksEnabled() bool {
	return IBCWasmHooksEnabled == "true"
}

// AutoCliOpts returns the autocli options for the app.
func (app *AxelarApp) AutoCliOpts() autocli.AppOptions {
	modules := make(map[string]appmodule.AppModule, 0)
	for _, m := range app.mm.Modules {
		if moduleWithName, ok := m.(module.HasName); ok {
			moduleName := moduleWithName.Name()
			if appModule, ok := moduleWithName.(appmodule.AppModule); ok {
				modules[moduleName] = appModule
			}
		}
	}

	return autocli.AppOptions{
		Modules:               modules,
		ModuleOptions:         runtimeservices.ExtractAutoCLIOptions(app.mm.Modules),
		AddressCodec:          authcodec.NewBech32Codec(sdk.GetConfig().GetBech32AccountAddrPrefix()),
		ValidatorAddressCodec: authcodec.NewBech32Codec(sdk.GetConfig().GetBech32ValidatorAddrPrefix()),
		ConsensusAddressCodec: authcodec.NewBech32Codec(sdk.GetConfig().GetBech32ConsensusAddrPrefix()),
	}
}
