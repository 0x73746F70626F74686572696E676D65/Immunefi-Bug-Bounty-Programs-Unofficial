// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

import {IBridge} from "src/interfaces/IBridge.sol";

contract BridgeMock is IBridge {
    mapping(bytes32 => uint256) private amounts;
    mapping(uint256 => bytes) private headers;
    mapping(bytes32 => bytes) private headersByHash;
    int256 private bestBlock;
    int256 private confirmations;

    // RSKIP-502 state variables
    uint256 private lockingCap = 400 ether;
    uint256 private weisTransferredToUnionBridge = 0;
    bool private transfersDisabled = false;
    address payable private unionBridgeContractAddress = payable(address(0));
    uint256 private maxIncreaseMultiplier = 2; // Maximum allowed increase (e.g., 2 = doubling)
    // RSKIP-529: Base Event state variable
    bytes private baseEvent;
    bytes private superEvent;
    bool public storeEvents = false;

    // accept rbtc from blockchain and send it to the union bridge contract
    receive() external payable {}

    function registerFastBridgeBtcTransaction(
        bytes memory,
        uint256,
        bytes memory,
        bytes32 derivationArgumentsHash,
        bytes memory,
        address payable liquidityBridgeContractAddress,
        bytes memory,
        bool
    ) external override returns (int256) {
        uint256 amount = amounts[derivationArgumentsHash];
        amounts[derivationArgumentsHash] = 0;
        (bool success,) = liquidityBridgeContractAddress.call{value: amount}("");
        require(success, "Sending funds failed");
        return int256(amount);
    }

    function getBtcBlockchainBlockHeaderByHeight(uint256 height) external view override returns (bytes memory) {
        return headers[height];
    }

    function setPegin(bytes32 derivationArgumentsHash) public payable {
        amounts[derivationArgumentsHash] = msg.value;
    }

    function setHeader(uint256 height, bytes memory header) public {
        headers[height] = header;
    }

    function setHeaderByHash(bytes32 blockHash, bytes memory header) public {
        headersByHash[blockHash] = header;
    }

    function getActivePowpegRedeemScript() external pure returns (bytes memory) {
        bytes memory part1 = hex"522102cd53fc53a07f211641a677d250f6de99caf620e8e77071e811a28b3bcddf0be1210362634ab5";
        bytes memory part2 = hex"7dae9cb373a5d536e66a8c4f67468bbcfb063809bab643072d78a1242103c5946b3fbae03a654237da86";
        bytes memory part3 = hex"3c9ed534e0878657175b132b8ca630f245df04db53ae";
        return abi.encodePacked(part1, part2, part3);
    }

    function setBtcBlockchainBestChainHeight(int256 _block) external {
        bestBlock = _block;
    }

    function getBtcBlockchainBestChainHeight() external view override returns (int256) {
        return bestBlock;
    }

    function getStateForBtcReleaseClient() external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getStateForDebugging() external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getBtcTxHashProcessedHeight(string calldata) external pure override returns (int64) {
        return int64(0);
    }

    function isBtcTxHashAlreadyProcessed(string calldata) external pure override returns (bool) {
        return false;
    }

    function getFederationAddress() external pure override returns (string memory) {
        return "2N5muMepJizJE1gR7FbHJU6CD18V3BpNF9p";
    } // regtest genesis fed addr

    function registerBtcTransaction(bytes calldata atx, int256 height, bytes calldata pmt) external override {}

    function addSignature(bytes calldata pubkey, bytes[] calldata signatures, bytes calldata txhash)
        external
        override
    {}

    function receiveHeaders(bytes[] calldata blocks) external override {}

    function receiveHeader(bytes calldata) external pure override returns (int256) {
        return int256(0);
    }

    function getFederationSize() external pure override returns (int256) {
        return int256(0);
    }

    function getFederationThreshold() external pure override returns (int256) {
        return int256(0);
    }

    function getFederatorPublicKey(int256) external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getFederatorPublicKeyOfType(int256, string calldata) external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getFederationCreationTime() external pure override returns (int256) {
        return int256(0);
    }

    function getFederationCreationBlockNumber() external pure override returns (int256) {
        return int256(0);
    }

    function getRetiringFederationAddress() external pure override returns (string memory) {
        return "";
    }

    function getRetiringFederationSize() external pure override returns (int256) {
        return int256(0);
    }

    function getRetiringFederationThreshold() external pure override returns (int256) {
        return int256(0);
    }

    function getRetiringFederatorPublicKey(int256) external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getRetiringFederatorPublicKeyOfType(int256, string calldata)
        external
        pure
        override
        returns (bytes memory)
    {
        bytes memory b;
        return b;
    }

    function getRetiringFederationCreationTime() external pure override returns (int256) {
        return int256(0);
    }

    function getRetiringFederationCreationBlockNumber() external pure override returns (int256) {
        return int256(0);
    }

    function createFederation() external pure override returns (int256) {
        return int256(0);
    }

    function addFederatorPublicKey(bytes calldata) external pure override returns (int256) {
        return int256(0);
    }

    function addFederatorPublicKeyMultikey(bytes calldata, bytes calldata, bytes calldata)
        external
        pure
        override
        returns (int256)
    {
        return int256(0);
    }

    function commitFederation(bytes calldata) external pure override returns (int256) {
        return int256(0);
    }

    function rollbackFederation() external pure override returns (int256) {
        return int256(0);
    }

    function getPendingFederationHash() external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getPendingFederationSize() external pure override returns (int256) {
        return int256(0);
    }

    function getPendingFederatorPublicKey(int256) external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    function getPendingFederatorPublicKeyOfType(int256, string calldata)
        external
        pure
        override
        returns (bytes memory)
    {
        bytes memory b;
        return b;
    }

    function getLockWhitelistSize() external pure override returns (int256) {
        return int256(0);
    }

    function getLockWhitelistAddress(int256) external pure override returns (string memory) {
        return "";
    }

    function getLockWhitelistEntryByAddress(string calldata) external pure override returns (int256) {
        return int256(0);
    }

    function addLockWhitelistAddress(string calldata, int256) external pure override returns (int256) {
        return int256(0);
    }

    function addOneOffLockWhitelistAddress(string calldata, int256) external pure override returns (int256) {
        return int256(0);
    }

    function addUnlimitedLockWhitelistAddress(string calldata) external pure override returns (int256) {
        return int256(0);
    }

    function removeLockWhitelistAddress(string calldata) external pure override returns (int256) {
        return int256(0);
    }

    function setLockWhitelistDisableBlockDelay(int256) external pure override returns (int256) {
        return int256(0);
    }

    function getFeePerKb() external pure override returns (int256) {
        return int256(0);
    }

    function voteFeePerKbChange(int256) external pure override returns (int256) {
        return int256(0);
    }

    function updateCollections() external override {}

    function getMinimumLockTxValue() external pure override returns (int256) {
        return int256(2);
    }

    function setBtcTransactionConfirmations(int256 _confirmations) external {
        confirmations = _confirmations;
    }

    function getBtcTransactionConfirmations(bytes32, bytes32, uint256, bytes32[] calldata)
        external
        view
        override
        returns (int256)
    {
        return confirmations;
    }

    function getLockingCap() external pure override returns (int256) {
        return int256(0);
    }

    function increaseLockingCap(int256) external pure override returns (bool) {
        return false;
    }

    function registerBtcCoinbaseTransaction(
        bytes calldata btcTxSerialized,
        bytes32 blockHash,
        bytes calldata pmtSerialized,
        bytes32 witnessMerkleRoot,
        bytes32 witnessReservedValue
    ) external override {}

    function hasBtcBlockCoinbaseTransactionInformation(bytes32) external pure override returns (bool) {
        return false;
    }

    function getActiveFederationCreationBlockHeight() external pure override returns (uint256) {
        return uint256(0);
    }

    function getBtcBlockchainBestBlockHeader() external view override returns (bytes memory) {
        // Check if there's a header set for the current RSK block number
        // This allows tests to return different BTC headers for different RSK blocks
        if (headers[block.number].length > 0) {
            return headers[block.number];
        }

        // Return a mock Bitcoin block hash for testing purposes
        // bytes corresponding to block 904463 hash 0000000000000000000049b460f18614380a01b8709d2c3a8ddf451d08d862b8
        // This simulates a Bitcoin best block header
        bytes memory b =
            hex"0000003c9d087b22bc8c482ad398dcfed27a115490cfbc144b3801000000000000000000a923a1461ac1dd2b222f3525f071bec2026acee9038ee440d6915488894a1452e7d66b6816680217f35754aa";
        return b;
    }

    function getBtcBlockchainBlockHeaderByHash(bytes32 blockHash) external view override returns (bytes memory) {
        return headersByHash[blockHash];
    }

    function getBtcBlockchainParentBlockHeaderByHash(bytes32) external pure override returns (bytes memory) {
        bytes memory b;
        return b;
    }

    // ===================== RSKIP-502: Union Bridge RBTC Methods =====================

    function requestUnionBridgeRbtcHarness() external payable returns (int256) {
        return _requestUnionBridgeRbtc(msg.value);
    }

    function _requestUnionBridgeRbtc(uint256 amount) internal returns (int256) {
        if (amount > lockingCap) {
            return int256(-2);
        }
        if (transfersDisabled) {
            return int256(-3);
        }
        weisTransferredToUnionBridge += amount;
        lockingCap -= amount;
        (bool success,) = unionBridgeContractAddress.call{value: amount}("");
        require(success, "BridgeMock: Sending funds failed");
        return int256(0);
    }

    function requestUnionBridgeRbtc(uint256 amount) external override returns (int256) {
        if (msg.sender != unionBridgeContractAddress) {
            return int256(-1);
        }
        return _requestUnionBridgeRbtc(amount);
    }

    function releaseUnionBridgeRbtcHarness() external payable returns (int256) {
        return _releaseUnionBridgeRbtc();
    }

    function _releaseUnionBridgeRbtc() internal returns (int256) {
        if (transfersDisabled) {
            return int256(-3);
        }
        if (msg.value > weisTransferredToUnionBridge) {
            return int256(-2);
        }
        weisTransferredToUnionBridge -= msg.value;
        lockingCap += msg.value;
        return int256(0);
    }

    function releaseUnionBridgeRbtc() external payable override returns (int256) {
        if (msg.sender != unionBridgeContractAddress) {
            return int256(-1);
        }
        return _releaseUnionBridgeRbtc();
    }

    function getUnionBridgeLockingCap() external view override returns (uint256) {
        return lockingCap;
    }

    function increaseUnionBridgeLockingCap(uint256 newCap) external override returns (int256) {
        uint256 currentTotalCap = lockingCap + weisTransferredToUnionBridge;

        // Check that newCap is actually an increase (RSKIP-502: cap can only be increased)
        if (newCap <= currentTotalCap) {
            return int256(-2); // Invalid value - less than current cap
        }

        // Check that increase is not excessive (RSKIP-502: increase should be controlled)
        uint256 maxAllowedCap = currentTotalCap * maxIncreaseMultiplier;
        if (newCap > maxAllowedCap) {
            return int256(-2); // Invalid value - excessive increase
        }

        // Update the available capacity
        lockingCap = newCap - weisTransferredToUnionBridge;
        return int256(0);
    }

    function setUnionBridgeContractAddressForTestnet(address newAddress) external override returns (int256) {
        unionBridgeContractAddress = payable(newAddress);
        return int256(0);
    }

    function getUnionBridgeContractAddress() external view override returns (address) {
        return unionBridgeContractAddress;
    }

    // ===================== RSKIP-529: Base Event Methods =====================

    function getBaseEvent() external view override returns (bytes memory) {
        return baseEvent;
    }

    function setBaseEvent(bytes memory _baseEvent) external override onlyUnionBridgeContract {
        if (_baseEvent.length > 128) {
            revert("BaseEventTooLong");
        }
        if (_baseEvent.length == 0) {
            revert("EmptyBaseEvent");
        }
        if (storeEvents) {
            baseEvent = _baseEvent;
        }
    }

    function clearBaseEvent() external override onlyUnionBridgeContract {
        baseEvent = "";
    }

    function getSuperEvent() external view override returns (bytes memory) {
        return superEvent;
    }

    function setSuperEvent(bytes memory _superEvent) external override onlyUnionBridgeContract {
        if (_superEvent.length > 128) {
            revert("SuperEventTooLong");
        }
        if (_superEvent.length == 0) {
            revert("EmptySuperEvent");
        }
        if (storeEvents) {
            superEvent = _superEvent;
        }
    }

    function clearSuperEvent() external override onlyUnionBridgeContract {
        superEvent = "";
    }

    //-------------------------------- Test Helpers ------------------------------------

    function setTransfersDisabled(bool _disabled) external {
        transfersDisabled = _disabled;
    }

    function setWeisTransferredToUnionBridge(uint256 _amount) external {
        uint256 totalCap = lockingCap + weisTransferredToUnionBridge;
        weisTransferredToUnionBridge = _amount;
        lockingCap = totalCap - _amount;
    }

    function setStoreEvents(bool _storeEvents) external {
        storeEvents = _storeEvents;
    }

    modifier onlyUnionBridgeContract() {
        _onlyUnionBridgeContract(msg.sender);
        _;
    }

    function _onlyUnionBridgeContract(address _sender) internal view {
        if (_sender != unionBridgeContractAddress) {
            revert("OnlyUnionBridgeContract");
        }
    }
}
