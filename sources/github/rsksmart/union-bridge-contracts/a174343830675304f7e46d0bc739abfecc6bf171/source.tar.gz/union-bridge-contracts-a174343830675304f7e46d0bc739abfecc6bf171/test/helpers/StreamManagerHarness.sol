// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {SlotState, Slot, SlotLocation, StreamManager} from "src/StreamManager.sol";
import {Role} from "src/interfaces/ICommitteeRegistry.sol";
import {IBitcoinManager} from "src/interfaces/IBitcoinManager.sol";
import {StreamManagerSettings} from "src/interfaces/IStreamManager.sol";
import {IAccessManager} from "src/interfaces/IAccessManager.sol";

/// @notice Wrapper for testing StreamManager
contract StreamManagerHarness is StreamManager {
    function initialize(
        address _initialOwner,
        IAccessManager _accessManager,
        IBitcoinManager _bitcoinManager,
        StreamManagerSettings memory _settings
    ) public override initializer {
        StreamManager.initialize(_initialOwner, _accessManager, _bitcoinManager, _settings);
    }

    function setSlotHarness(
        uint64 _streamId,
        uint64 _packet,
        bytes memory _scriptPubKey,
        bytes32 _txId,
        uint64 _amount,
        SlotState _state
    ) external returns (uint64) {
        return _setSlotHarness(_streamId, _packet, _scriptPubKey, _txId, _amount, _state);
    }

    function _setSlotHarness(
        uint64 _streamId,
        uint64 _packet,
        bytes memory _scriptPubKey,
        bytes32 _txId,
        uint64 _amount,
        SlotState _state
    ) internal returns (uint64) {
        uint64 slotId = uint64(slots[_streamId][_packet].length);
        slots[_streamId][_packet].push(
            Slot({
                slotId: slotId,
                state: _state,
                acceptPeginTx: _txId,
                acceptPeginAmount: _amount,
                scriptPubKey: _scriptPubKey,
                takeTx: ""
            })
        );

        if (_state == SlotState.FILLED) {
            SlotLocation memory newFilledSlot = SlotLocation({packetId: _packet, slotId: slotId});
            filledSlots[_streamId].push(newFilledSlot);
        }

        if (_state == SlotState.LOCKED) {
            if (isPegoutInProcess[_streamId]) {
                revert PegoutInProcess(_streamId);
            }
            isPegoutInProcess[_streamId] = true;
            nextPegoutSlotIndex[_streamId]++;
        }

        if (_state == SlotState.COMPLETED) {
            isPegoutInProcess[_streamId] = false;
        }

        return slotId;
    }

    function setPacketEnablerScriptHarness(uint64 _streamId, uint64 _packetNumber, bytes memory _enablerScriptPubKey)
        external
    {
        packets[_streamId][_packetNumber].enablerScriptPubKey = _enablerScriptPubKey;
    }

    function pushSlotsHarness(uint64 _streamId, uint64 _packet, uint64 _slotsAmount, SlotState _slotState) external {
        for (uint64 i = 0; i < _slotsAmount; i++) {
            _setSlotHarness(_streamId, _packet, hex"00", bytes32(0), 0, _slotState);
        }
    }

    function getSlotsLengthHarness(uint64 _streamId, uint64 _packet) external view returns (uint256) {
        return slots[_streamId][_packet].length;
    }

    function getNextPegoutSlotIndex(uint64 _streamId) external view returns (uint64) {
        return nextPegoutSlotIndex[_streamId];
    }

    function getFilledSlots(uint64 _streamId) external view returns (SlotLocation[] memory) {
        return filledSlots[_streamId];
    }

    function setSlotStateHarness(uint64 _streamId, uint64 _packet, uint64 _slotId, SlotState _state) external {
        if (_packet >= packets[_streamId].length) {
            revert NoPacketsHarness(_streamId, _packet);
        }
        if (_slotId >= slots[_streamId][_packet].length) {
            revert NoSlotsHarness(_streamId, _packet, _slotId);
        }
        slots[_streamId][_packet][_slotId].state = _state;
    }

    /// @dev Returns the security bond percentage for a given role
    /// @param _role The role for which to get the security bond percentage
    /// @return The security bond percentage in 10_000 format (e.g. 1000 = 10%)
    /// @notice Reverts if the role is NONE
    function getSecurityBondPercentage(Role _role) external view returns (uint16) {
        if (_role == Role.NONE) {
            revert InvalidRole(_role);
        }
        return securityBondPercentage[_role];
    }

    error NoSlotsHarness(uint64 streamId, uint64 packet, uint64 slot);
    error NoPacketsHarness(uint64 streamId, uint64 packet);
}
