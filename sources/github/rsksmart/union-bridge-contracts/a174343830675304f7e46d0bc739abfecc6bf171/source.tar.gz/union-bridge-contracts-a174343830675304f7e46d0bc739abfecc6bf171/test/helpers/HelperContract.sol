// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {DeployScript} from "script/deploy/DeployScript.s.sol";
import {StreamManagerHarness} from "test/helpers/StreamManagerHarness.sol";
import {MemberRegistryHarness} from "test/helpers/MemberRegistryHarness.sol";
import {PeginManagerHarness} from "test/helpers/PeginManagerHarness.sol";
import {PegoutManagerHarness} from "test/helpers/PegoutManagerHarness.sol";
import {CommitteeRegistryHarness} from "test/helpers/CommitteeRegistryHarness.sol";
import {SignatureManager} from "src/SignatureManager.sol";
import {AccessManager} from "src/AccessManager.sol";
import {BitcoinManager} from "src/BitcoinManager.sol";
import {OperatorTakeManagerHarness} from "test/helpers/OperatorTakeManagerHarness.sol";
import {ChallengeManager} from "src/ChallengeManager.sol";
import {RbtcBridge} from "src/RbtcBridge.sol";
import {BridgeMock} from "./BridgeMock.sol";
import {TestUtils} from "./TestUtils.sol";
import {
    Role,
    CommitteeMember,
    Committee,
    UTXO,
    CommunicationData,
    COMMUNICATION_DATA_CHUNKS
} from "src/interfaces/ICommitteeRegistry.sol";
import {MemberRegistrationKeys, MemberKeys, CompactPubKey} from "src/interfaces/IMemberRegistry.sol";
import {StreamDenomination, Slot, Stream, SlotState, SlotLocation} from "src/interfaces/IStreamManager.sol";
import {
    BtcTxIn, BtcTxOut, BtcTransaction, BitcoinSignatureData, PrevoutData
} from "src/interfaces/IBitcoinManager.sol";
import {BtcTxSPVProof, StreamPosition, PegStatus} from "src/interfaces/IPegCommonTypes.sol";
import {IOperatorTakeManager, OperatorTakeInfo} from "src/interfaces/IOperatorTakeManager.sol";
import {BtcScriptParser} from "src/libraries/BtcScriptParser.sol";
import {BtcHelper} from "src/libraries/BtcHelper.sol";
import {BtcTxEncoder} from "src/libraries/BtcTxEncoder.sol";
import {Constants} from "src/libraries/Constants.sol";
import {OpCodes} from "src/libraries/OpCodes.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";

abstract contract HelperContract is Test, TestUtils {
    bytes32 internal constant BTC_REIMBURSEMENT_PUBKEY =
        0x7d235c24420b2f55450c8414725aa74e6db01035245efdab0e1cfa7ab29aca0f;

    uint128 constant COMMITTEE_ID_STREAM_1_COMMITTEE_1 = 118226726889222519722182588745663749063;
    uint128 constant COMMITTEE_ID_STREAM_1_COMMITTEE_2 = 9059004642890852444280677687625412743;
    uint128 constant COMMITTEE_ID_STREAM_1_COMMITTEE_3 = 252028015853910751738154200832734646518;
    // 33-byte compressed public key (0x02 prefix + 32 bytes)

    function COMMITTEE_TAKE_PUB_KEY() internal pure returns (bytes memory) {
        return
            abi.encodePacked(bytes1(0x02), bytes32(0xd1cfc2049322ff6ba3a88c6e17c6622308f0fb1d2910ffadb309e4116358723d));
    }

    function COMMITTEE_DISPUTE_PUB_KEY() internal pure returns (bytes memory) {
        return
            abi.encodePacked(bytes1(0x02), bytes32(0xe2dfc3050433ff7cb4b99d7f18d7733319f1fc2e4020ffbcc410f5227469834e));
    }

    uint256 constant BLOCK_COMMITTEE_1 = 10;
    uint256 constant BLOCK_COMMITTEE_2 = 100000;
    uint256 constant BLOCK_COMMITTEE_3 = 200000;
    StreamDenomination constant SETUP_PENDING_COMMITTEE_DENOMINATION = StreamDenomination._0_01BTC;
    uint64 constant SETUP_PENDING_COMMITTEE_STREAM_ID = 1;

    uint256 constant TAKE_0_TIMEOUT_DEFAULT = 2 hours;
    uint256 constant TAKE_1_TIMEOUT_DEFAULT = 2 hours;

    int256 constant BEST_CHAIN_HEIGHT = 1000;

    // Default accept pegin txid for testing blockSlot
    bytes32 constant DEFAULT_ACCEPT_PEGIN_TXID = 0xdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef;
    bytes constant ACCEPT_PEGIN_P2TR_SCRIPT_PUBKEY =
        hex"51209687ca13c4fb3fa3ba05c2f9119dda026bfe66f0098dcf9b896a98ecb2e96702";

    // Default requested roles and streams for the members
    StreamDenomination internal constant DEFAULT_STREAM = StreamDenomination._0_01BTC;
    Role internal constant DEFAULT_ROLE = Role.OPERATOR;

    BitcoinManager internal bitcoinManager;
    BridgeMock internal bridgeMock;
    CommitteeRegistryHarness internal registry;
    MemberRegistryHarness internal memberRegistry;
    SignatureManager internal signatureManager;
    StreamManagerHarness internal streamManager;
    RbtcBridge internal rbtcBridge;
    PeginManagerHarness internal peginManager;
    PegoutManagerHarness internal pegoutManager;
    AccessManager internal accessManager;
    ChallengeManager internal challengeManager;
    OperatorTakeManagerHarness internal operatorTakeManager;

    // Arrange
    uint64 internal constant VALUE = 1_000_000; // 0.01 BTC
    uint256 registeredMembersCounter = 0; // Counter to keep track of registered members
    address globalUserAddress;

    function runTestDeployScript() internal {
        // Using the deployment script in tests like in
        // https://github.com/Cyfrin/foundry-smart-contract-lottery-cu/blob/main/test/unit/RaffleTest.t.sol#L38
        DeployScript deployScript = new DeployScript();
        deployScript.run();
        bitcoinManager = deployScript.bitcoinManager();
        registry = CommitteeRegistryHarness(address(deployScript.committeeRegistry()));
        memberRegistry = MemberRegistryHarness(address(deployScript.memberRegistry()));
        streamManager = StreamManagerHarness(address(deployScript.streamManager()));
        rbtcBridge = RbtcBridge(payable(address(deployScript.rbtcBridge())));
        peginManager = PeginManagerHarness(address(deployScript.peginManager()));
        pegoutManager = PegoutManagerHarness(address(deployScript.pegoutManager()));
        accessManager = AccessManager(deployScript.accessManager());
        signatureManager = SignatureManager(deployScript.signatureManager());
        challengeManager = ChallengeManager(deployScript.challengeManager());
        operatorTakeManager = OperatorTakeManagerHarness(address(deployScript.operatorTakeManager()));
        // Set up bridge mock at bridge precompiled address
        bridgeMock = BridgeMock(deployScript.bridgeAddress());
        globalUserAddress = address(this);
    }

    // ========================== UTXO Helper ==========================

    function generateDefaultUTXO() internal pure returns (UTXO memory) {
        return UTXO({
            txid: 0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef,
            outputIndex: 0,
            amount: 50000
        });
    }

    // ========================== Apply to stream ==========================

    /**
     * @notice Registers a batch of new members (watchtowers first, then operators)
     */
    function setup_registerNewMembers(uint256 numWatchtowers, uint256 numOperators, StreamDenomination denomination)
        internal
    {
        uint256 startingMemberIndex = registeredMembersCounter;
        _applyMembersByCounts(denomination, numWatchtowers, numOperators, startingMemberIndex);
        registeredMembersCounter = startingMemberIndex + numWatchtowers + numOperators;
    }

    /**
     * @notice Applies a single address to a stream by sending the minimum deposit and calling the registry.                   Role requested by the member (WATCHTOWER or OPERATOR).
     */
    function setup_applyToStream(
        StreamDenomination _denomination,
        address _address,
        MemberRegistrationKeys memory _publicKeysRegistration,
        Role _role
    ) internal {
        setup_whitelistAddress(_address); // to be able to apply to stream

        uint256 minimumDeposit = streamManager.getMinimumDeposit(_denomination, _role);
        vm.deal(_address, minimumDeposit);

        vm.prank(_address);
        registry.applyToStream{value: minimumDeposit}(
            _denomination, _role, _publicKeysRegistration, generateDefaultUTXO()
        );
    }

    function setup_whitelistAddress(address _address) internal {
        vm.prank(registry.whitelister());
        registry.whitelistAddress(_address);
    }

    /**
     * @notice Applies an explicit list of committee members to a stream.
     */
    function setup_applyToStream_MultipleMembers(
        StreamDenomination _denomination,
        CommitteeMember[] memory _committeeMembers
    ) internal {
        uint256 totalMembers = _committeeMembers.length;

        for (uint256 memberIndex = 0; memberIndex < totalMembers; memberIndex++) {
            CommitteeMember memory committeeMember = _committeeMembers[memberIndex];
            _applyMemberToStream(_denomination, committeeMember.memberAddress, committeeMember.role);
        }
    }

    function getMemberDisputePubKey(address _memberAddress) internal returns (bytes32) {
        return generateRegistrationPublicKeys(uint256(uint160(_memberAddress))).disputeKey.publicKeyX;
    }

    /**
     * @notice Applies a batch of members determined by counts and a base index.
     * Should be used for members that has been already registered; it won't fail if the member is not registered.
     * It will just apply to the stream with the given denomination and role.
     */
    function setup_applyToStream_MultipleMembers(
        StreamDenomination _denomination,
        uint256 _numWatchtowers,
        uint256 _numOperators,
        uint256 _startingMemberIndex
    ) internal {
        _applyMembersByCounts(_denomination, _numWatchtowers, _numOperators, _startingMemberIndex);
    }

    /**
     * @notice Derives deterministic mock registration keys from an EOA address.
     */
    function _deriveRegistrationKeysFromAddress(address memberAddress)
        internal
        returns (MemberRegistrationKeys memory keys)
    {
        return generateRegistrationPublicKeys(uint256(uint160(memberAddress)));
    }

    /**
     * @notice Applies a single member to a stream with keys derived from their address.
     */
    function _applyMemberToStream(StreamDenomination denomination, address memberAddress, Role memberRole) internal {
        MemberRegistrationKeys memory keys = _deriveRegistrationKeysFromAddress(memberAddress);
        setup_applyToStream(denomination, memberAddress, keys, memberRole);
    }

    /**
     * @notice Returns a deterministic address for a given position, based on a starting index.
     */
    function _addressForIndex(uint256 startingMemberIndex, uint256 memberOffset)
        internal
        pure
        returns (address memberAddress)
    {
        // +1 to avoid returning address(0) at offset 0
        return vm.addr(startingMemberIndex + memberOffset + 1);
    }

    /**
     * @notice Computes the role for a member position in a watchtower-first layout.
     */
    function _roleForMemberIndex(uint256 memberIndex, uint256 numWatchtowers)
        internal
        pure
        returns (Role roleForPosition)
    {
        return memberIndex < numWatchtowers ? Role.WATCHTOWER : Role.OPERATOR;
    }

    /**
     * @notice Shared implementation used by the count-based entry points.
     */
    function _applyMembersByCounts(
        StreamDenomination denomination,
        uint256 numWatchtowers,
        uint256 numOperators,
        uint256 startingMemberIndex
    ) internal {
        uint256 totalMembers = numWatchtowers + numOperators;
        for (uint256 memberIndex = 0; memberIndex < totalMembers; memberIndex++) {
            Role roleForPosition = _roleForMemberIndex(memberIndex, numWatchtowers);
            address memberAddress = _addressForIndex(startingMemberIndex, memberIndex);
            _applyMemberToStream(denomination, memberAddress, roleForPosition);
        }
    }

    // ========================== Peg In Request ==========================
    // This counter is added to the txId from getRequestPeginTxIn to avoid collisions when doing multiple pegin's
    uint256 internal txIdCounter = 0;

    function getRequestPeginTxIn() internal returns (BtcTxIn memory) {
        return BtcTxIn({
            txId: bytes32(uint256(0x360b81785dc7c2f40627fea364676dbb73e6276683caffd9f906b0e0bd36b3d2) + txIdCounter++),
            vout: 1694,
            sequence: Constants.SEQUENCE,
            scriptSig: hex""
        });
    }

    function getRequestPeginP2TROut() internal pure returns (BtcTxOut memory) {
        return BtcTxOut({
            amount: VALUE,
            scriptPubKey: hex"5120705364e5015f051b3c85957d8e2c581c17318b50156a68c333739720d388ddfc"
        });
    }

    function getRequestPeginPacket() internal pure returns (uint64) {
        return 0;
    }

    function getPeginRskDestinationAddress() internal pure returns (address) {
        return 0x7Ac5496aee77c1bA1F0854206A26DdA82A81d6d8;
    }

    function getPeginBtcReimbursementPubKey() internal pure returns (bytes32) {
        return 0x7d235c24420b2f55450c8414725aa74e6db01035245efdab0e1cfa7ab29aca0f;
    }

    function getRequestPeginOpReturnOut(
        uint64 _packetNumber,
        address _rskDestinationAddress,
        bytes32 _btcReimbursementPubKey
    ) internal pure returns (BtcTxOut memory) {
        bytes memory script = abi.encodePacked(
            OpCodes.OP_RETURN, // (1 byte)
            OpCodes.OP_PUSHBYTES_69, // (1 byte)
            "RSK_PEGIN", // (9 bytes)
            _packetNumber, // (8 bytes)
            _rskDestinationAddress, // (20 bytes)
            _btcReimbursementPubKey // (32 bytes)
        );

        // Return the constructed output
        return BtcTxOut({amount: 0, scriptPubKey: script});
    }

    function getRequestPeginEnablerOut() internal view returns (BtcTxOut memory) {
        // Get committee members and dispute keys
        Stream memory stream = streamManager.getStream(VALUE);
        uint128 committeeId = streamManager.getCommitteeId(stream.streamId, stream.peginPacketPointer);

        bytes memory aggregatedTakePubKey = registry.getCommitteeTakePubKey(committeeId);
        CompactPubKey[] memory disputeKeys = registry.getCommitteeDisputeKeys(committeeId);

        // Get the enabler output script using the BitcoinManager
        bytes memory enablerScript = bitcoinManager.getEnablerOutputP2TRScriptPub(aggregatedTakePubKey, disputeKeys);

        return BtcTxOut({amount: Constants.ENABLER_AMOUNT, scriptPubKey: enablerScript});
    }

    function getBtcRequestPeginTx() internal returns (BtcTransaction memory, uint64 slotId) {
        BtcTxIn[] memory btcInputs = new BtcTxIn[](1);
        btcInputs[0] = getRequestPeginTxIn();
        // Output
        BtcTxOut[] memory btcOutputs = new BtcTxOut[](Constants.REQUEST_PEGIN_OUTPUT_COUNT);
        btcOutputs[0] = getRequestPeginP2TROut();

        Stream memory stream = streamManager.getStream(VALUE);
        uint64 packetNumber = stream.peginPacketPointer;
        slotId = streamManager.getPacketSlotsLength(stream.streamId, packetNumber);

        address rskDestinationAddress = getPeginRskDestinationAddress();
        bytes32 btcReimbursementPubKey = getPeginBtcReimbursementPubKey();
        btcOutputs[1] = getRequestPeginOpReturnOut(packetNumber, rskDestinationAddress, btcReimbursementPubKey);
        btcOutputs[2] = getRequestPeginEnablerOut();

        return (
            BtcTransaction({
                version: Constants.BTC_TX_VERSION,
                inputs: btcInputs,
                outputs: btcOutputs,
                locktime: Constants.LOCKTIME
            }),
            slotId
        );
    }

    function getBtcTxid(BtcTransaction memory _tx) internal pure returns (bytes32) {
        return BtcHelper.hash256(BtcTxEncoder.encodeTx(_tx));
    }

    // ========================== Peg In Accept ==========================
    function getBtcAcceptPeginTx(BtcTransaction memory _tx) internal view returns (BtcTransaction memory) {
        BtcTxIn[] memory btcInputs = new BtcTxIn[](2);
        btcInputs[0] = getAcceptPeginTxIn(_tx);
        btcInputs[1] = getAcceptPeginEnablerTxIn(_tx);
        // Output
        BtcTxOut[] memory btcOutputs = new BtcTxOut[](Constants.ACCEPT_PEGIN_OUTPUT_COUNT);
        btcOutputs[0] = getAcceptPeginP2TROut();
        btcOutputs[1] = getAcceptPeginEnablerOut(_tx);
        btcOutputs[2] = getUserSpeedUpOut();
        // Locktime
        return BtcTransaction({
            version: Constants.BTC_TX_VERSION,
            inputs: btcInputs,
            outputs: btcOutputs,
            locktime: Constants.LOCKTIME
        });
    }

    function getAcceptPeginTxIn(BtcTransaction memory _tx) internal pure returns (BtcTxIn memory) {
        return BtcTxIn({txId: getBtcTxid(_tx), vout: 0, sequence: Constants.SEQUENCE, scriptSig: hex""});
    }

    function getAcceptPeginEnablerTxIn(BtcTransaction memory _tx) internal pure returns (BtcTxIn memory) {
        return BtcTxIn({
            txId: getBtcTxid(_tx),
            vout: Constants.REQUEST_PEGIN_VOUT_ENABLER,
            sequence: Constants.SEQUENCE,
            scriptSig: hex""
        });
    }

    function getUserSpeedUpOut() internal pure returns (BtcTxOut memory) {
        return BtcTxOut({
            amount: Constants.SPEED_UP_AMOUNT,
            scriptPubKey: BtcScriptParser.getP2WPKHScript(BtcHelper.assumeEvenParityCompact(BTC_REIMBURSEMENT_PUBKEY))
        });
    }

    function getAcceptPeginP2TROut() internal pure returns (BtcTxOut memory) {
        return BtcTxOut({
            // we subtract the fee, speed up amount from the value
            // the enabler amount cancels out between the input and the output
            amount: VALUE - (Constants.P2TR_FEE + Constants.SPEED_UP_AMOUNT),
            scriptPubKey: ACCEPT_PEGIN_P2TR_SCRIPT_PUBKEY
        });
    }

    function getAcceptPeginEnablerOut(BtcTransaction memory _requestTx) internal view returns (BtcTxOut memory) {
        // Extract packet number from the request pegin transaction's OP_RETURN output
        (uint64 packetNumber,,) =
            bitcoinManager.getPeginOpReturnData(_requestTx.outputs[Constants.REQUEST_PEGIN_VOUT_OP_RETURN]);

        uint128 committeeId = streamManager.getCommitteeId(uint64(DEFAULT_STREAM), packetNumber);
        bytes memory aggregatedTakePubKey = registry.getCommitteeTakePubKey(committeeId);
        CompactPubKey[] memory disputeKeys = registry.getCommitteeDisputeKeys(committeeId);
        bytes memory enablerScript = bitcoinManager.getEnablerOutputP2TRScriptPub(aggregatedTakePubKey, disputeKeys);

        return BtcTxOut({amount: Constants.ENABLER_AMOUNT, scriptPubKey: enablerScript});
    }

    // ========================== User Reimbursement ==========================
    function getBtcUserReimbursementTx(bytes32 _requestPeginTxid) internal pure returns (BtcTransaction memory) {
        return createBtcUserReimbursementTx(_requestPeginTxid, VALUE, BTC_REIMBURSEMENT_PUBKEY);
    }

    function satoshiToWei(uint256 _amount) internal pure returns (uint256) {
        return _amount * 10 ** 10;
    }

    function setup_multipleRequestAndAcceptPeginFlows(uint256 _numberOfPegins) internal {
        if (_numberOfPegins > Constants.SLOTS_PER_PACKET) {
            vm.roll(BLOCK_COMMITTEE_2);
            vm.warp(BLOCK_COMMITTEE_2);
        }

        for (uint256 i = 0; i < _numberOfPegins; i++) {
            (BtcTransaction memory btcTx,) = setup_requestPeginFlow();
            setup_acceptPeginFlow(btcTx);

            if (
                _numberOfPegins > Constants.SLOTS_PER_PACKET
                    && (i % Constants.SLOTS_PER_PACKET) == Constants.SLOT_USAGE_THRESHOLD
            ) {
                uint256 memberIndexStart = registry.committeeMemberCount();
                uint256 memberCount = registry.committeeMemberCount();
                setup_depositAggregatedKey_MultipleMembers(
                    COMMITTEE_ID_STREAM_1_COMMITTEE_2, memberIndexStart, memberCount
                );
            }
        }
    }

    function setup_acceptPeginFlow(BtcTransaction memory _tx) public returns (BtcTransaction memory) {
        // Arrange
        BtcTransaction memory btcTransaction = getBtcAcceptPeginTx(_tx);
        // Set Mock Bridge state
        bridgeMock.setBtcBlockchainBestChainHeight(BEST_CHAIN_HEIGHT);
        bridgeMock.setBtcTransactionConfirmations(CONFIRMATIONS);
        // Create Pegin accepted tx struct information
        BtcTxSPVProof memory peginAcceptedTxSPVProof = createBtcTxSPVProof(btcTransaction);

        // Act
        peginManager.acceptPegin(peginAcceptedTxSPVProof);

        bridgeMock.setBtcBlockchainBestChainHeight(BEST_CHAIN_HEIGHT + 1);

        return btcTransaction;
    }

    function setup_requestPeginFlow() public returns (BtcTransaction memory btcTransaction, uint64 slotId) {
        // Arrange
        (btcTransaction, slotId) = getBtcRequestPeginTx();
        Stream memory stream = streamManager.getStream(VALUE);

        // Set Mock Bridge state
        bridgeMock.setBtcBlockchainBestChainHeight(BEST_CHAIN_HEIGHT);
        bridgeMock.setBtcTransactionConfirmations(CONFIRMATIONS);
        // Create Pegin struct information
        BtcTxSPVProof memory requestPeginTxSPVProof = createBtcTxSPVProof(btcTransaction);

        // Act
        peginManager.requestPegin(requestPeginTxSPVProof);

        // Update the best chain for timelock verifications
        bridgeMock.setBtcBlockchainBestChainHeight(
            BEST_CHAIN_HEIGHT + int256(uint256(stream.timelockSettings.requestPeginTimelock))
        );
        // Assert
        Slot memory slot = streamManager.getSlot(stream.streamId, stream.peginPacketPointer, slotId);
        assertEq(uint256(slot.state), uint256(SlotState.RESERVED), "Slot state should be RESERVED after pegin request");
    }

    function setup_requestAndAcceptPeginFlow(uint128 _committeeId)
        public
        returns (bytes32 acceptPeginTxid, BtcTransaction memory peginTx, BtcTransaction memory acceptPeginTx)
    {
        uint64 peginSlotId;
        (peginTx, peginSlotId) = setup_requestPeginFlow();
        acceptPeginTx = setup_acceptPeginFlow(peginTx);
        acceptPeginTxid = bitcoinManager.getBtcTxid(acceptPeginTx);

        // This cover all operators in the committee
        setup_addOperatorTakeTxids_MultipleOperators(
            acceptPeginTxid, _committeeId, uint32(peginSlotId), registry.committeeMemberCount()
        );
    }

    // ========================== Register Pegout Setup ==========================
    struct RegisterUserTakeSetup {
        BtcTransaction pegoutTx;
        BtcTxSPVProof pegoutTxSPVProof;
        BtcTxSPVProof cancelUserTakeSPV;
        BtcTxSPVProof advanceFundsSPV;
        BtcTxSPVProof reimbursementKickoffSPV;
        BtcTxSPVProof operatorTakeSPV;
        BtcTxSPVProof challengeSPV;
        BtcTxSPVProof inputRevealedSPV;
        BtcTxSPVProof inputNotRevealedSPV;
        BtcTxSPVProof operatorWonSPV;
        BtcTxSPVProof stopOperatorWonSPV;
        BtcTxSPVProof acceptPeginSPV;
        Stream stream;
        uint64 packetNumber;
        uint64 slotId;
        bytes32 acceptPeginTxid;
        bytes userPubKey;
        bytes32 pegoutTxid;
        bytes32 pegoutSignatureHash;
        bytes32 pegoutId;
    }

    function setup_peginAndSPVs() internal returns (RegisterUserTakeSetup memory setup) {
        return setup_peginAndSPVs(COMMITTEE_ID_STREAM_1_COMMITTEE_1);
    }

    function setup_peginAndSPVs(uint128 _committeeId) internal returns (RegisterUserTakeSetup memory setup) {
        // =========== Request Peg-In & Accept Peg-In ============
        (bytes32 acceptPeginTxid,, BtcTransaction memory acceptPeginTx) = setup_requestAndAcceptPeginFlow(_committeeId);

        // Get the accept peg-in tx id that will be spent in the peg-out
        setup.acceptPeginSPV = createBtcTxSPVProof(acceptPeginTx);
        setup.acceptPeginTxid = bitcoinManager.getBtcTxid(acceptPeginTx);
        setup.stream = streamManager.getStream(VALUE);
        setup.userPubKey = hex"02d56ad001b55eabf431e602599fcc0d7ed9d676ac93c2be11d0de6e25dd598d8b";

        // =================== Request Peg-Out ===================
        Stream memory stream = streamManager.getStream(VALUE);

        SlotLocation memory slotLocation = streamManager.getNextPegoutSlotLocation(stream.streamId);
        setup.packetNumber = slotLocation.packetId;
        setup.slotId = slotLocation.slotId;
        Slot memory slot = streamManager.getSlot(stream.streamId, setup.packetNumber, setup.slotId);

        // Set up mock to allow burning this amount
        // Add capacity to support multiple pegout calls in sequence
        bridgeMock.setWeisTransferredToUnionBridge(BtcHelper.satoshiToWei(VALUE));

        // Prepare prevout data for both inputs: taptree and enabler outputs
        // Read taptree from slot, enabler from packet (matching production code in _preparePegoutPrevoutDatas)
        PrevoutData[] memory prevoutDatas = new PrevoutData[](2);
        prevoutDatas[0] = PrevoutData({value: slot.acceptPeginAmount, scriptPubKey: slot.scriptPubKey});
        prevoutDatas[1] = PrevoutData({
            value: Constants.ENABLER_AMOUNT,
            scriptPubKey: streamManager.getEnablerScriptPubKey(stream.streamId, setup.packetNumber)
        });

        BitcoinSignatureData memory pegoutSignatureData =
            bitcoinManager.getPegoutTxData(setup.userPubKey, setup.acceptPeginTxid, prevoutDatas);

        // Create a peg-out transaction that spends the accept peg-in UTXO
        setup.pegoutTx = pegoutSignatureData.tx;

        // Create SPV proof for the peg-out transaction
        setup.pegoutTxSPVProof = createBtcTxSPVProof(setup.pegoutTx);

        setup.pegoutSignatureHash = pegoutSignatureData.signatureHash;
        setup.pegoutTxid = pegoutSignatureData.txid;
    }

    function setup_pegout() internal returns (RegisterUserTakeSetup memory setup) {
        setup = setup_peginAndSPVs();
        uint256 pegoutAmountInWei = BtcHelper.satoshiToWei(VALUE);

        // Request peg-out
        vm.prank(globalUserAddress);
        pegoutManager.tryPegout{value: pegoutAmountInWei}(setup.userPubKey);

        // Verify slot was locked
        Slot memory slot = streamManager.getSlot(setup.stream.streamId, setup.packetNumber, setup.slotId);
        assertEq(uint256(slot.state), uint256(SlotState.LOCKED), "Slot should be locked after peg-out request");
        assertEq(slot.acceptPeginTx, setup.acceptPeginTxid, "Slot should reference the correct accept peg-in tx");
    }

    function calculatePegoutId(
        CompactPubKey memory operatorTakePubKey,
        uint64 streamId,
        uint64 packetNumber,
        uint64 slotId
    ) internal view returns (bytes32) {
        return keccak256(
            abi.encodePacked(
                Constants.PEGOUT_ID_VERSION,
                operatorTakeManager.sequenceNumber() + 1,
                streamId,
                packetNumber,
                slotId,
                operatorTakePubKey.parity,
                operatorTakePubKey.xOnly,
                BtcHelper.hash256(bridgeMock.getBtcBlockchainBestBlockHeader())
            )
        );
    }

    function setup_pegFlow() internal returns (RegisterUserTakeSetup memory setup) {
        setup = setup_pegout();
        pegoutManager.registerUserTake(setup.pegoutTxSPVProof);

        return setup;
    }

    function setup_multiplePegFlows(uint8 amount) internal returns (RegisterUserTakeSetup[] memory setups) {
        setups = new RegisterUserTakeSetup[](amount);
        for (uint8 i = 0; i < amount; i++) {
            setups[i] = setup_pegFlow();
        }
    }

    function setup_pegoutAndMemberNonces() internal returns (RegisterUserTakeSetup memory setup) {
        setup = setup_pegout();
        setup_addMemberNonce_MultipleMembers(setup.pegoutTxid, 0, registry.committeeMemberCount());
    }

    function setup_addOperatorTakeTxids_MultipleOperators(
        bytes32 _acceptPeginTxid,
        uint128 _committeeId,
        uint64 _slotId,
        uint256 _operatorCount
    ) internal {
        CommitteeMember[] memory members = registry.getCommitteeMembers(_committeeId);
        uint256 operatorAdded = 0;
        for (uint256 i = 0; i < members.length && operatorAdded < _operatorCount; i++) {
            if (members[i].role == Role.OPERATOR) {
                (BtcTransaction memory opTakeTx, BtcTransaction memory opWonTx,) =
                    setup_getOperatorTakeData(_acceptPeginTxid, members[i].memberAddress, _slotId);

                bytes32 takeTxid = bitcoinManager.getBtcTxid(opTakeTx);
                bytes32 wonTxid = bitcoinManager.getBtcTxid(opWonTx);

                setup_addOperatorTakeTxids(members[i].memberAddress, _acceptPeginTxid, takeTxid, wonTxid);
                operatorAdded++;
            }
        }
    }

    function setup_depositAggregatedKey(uint128 _committeeId, address _memberAddress) internal {
        vm.prank(_memberAddress);
        registry.depositAggregatedKeys(_committeeId, COMMITTEE_TAKE_PUB_KEY(), COMMITTEE_DISPUTE_PUB_KEY());
    }

    // This function is used to deposit the aggregated key for multiple members in a committee
    // It will deposit the aggregated key for members with indexes from _memberIndexInit to _memberIndexInit + _memberCount - 1
    function setup_depositAggregatedKey_MultipleMembers(
        uint128 _committeeId,
        uint256 _memberIndexInit,
        uint256 _memberCount
    ) internal {
        uint256 memberIndexEnd = _memberIndexInit + _memberCount;

        for (uint256 i = _memberIndexInit; i < memberIndexEnd; i++) {
            // Member address is vm.address(memberIndex + 1);
            setup_depositAggregatedKey(_committeeId, vm.addr(i + 1));
        }
    }

    /// @notice Internal helper to register members for a pending committee
    /// @param _size The committee size to register members for
    function _registerMembersForPendingCommittee(uint256 _size) private {
        uint256 numOperators = _size / 2;
        uint256 numWatchtowers = _size - numOperators;
        setup_registerNewMembers(numWatchtowers, numOperators, SETUP_PENDING_COMMITTEE_DENOMINATION);
    }

    function setup_pendingCommittee() internal returns (Committee memory expectedCommittee, uint128 committeeId) {
        vm.warp(BLOCK_COMMITTEE_1);
        vm.roll(BLOCK_COMMITTEE_1);
        _registerMembersForPendingCommittee(registry.committeeMemberCount());
        return (setup_getExpectedCommitteeBeforeExpire(), COMMITTEE_ID_STREAM_1_COMMITTEE_1);
    }

    function setup_pendingCommitteeAndExpire()
        internal
        returns (Committee memory expectedCommittee, uint128 committeeId)
    {
        (, committeeId) = setup_pendingCommittee();
        vm.warp(BLOCK_COMMITTEE_3);
        vm.roll(BLOCK_COMMITTEE_3);
        expectedCommittee = setup_getExpectedCommitteeAfterExpire();
    }

    function setup_completeCommittee() internal returns (Committee memory expectedCommittee, uint128 committeeId) {
        (expectedCommittee, committeeId) = setup_pendingCommittee();

        setup_depositAggregatedKey_MultipleMembers(committeeId, 0, registry.committeeMemberCount());
        expectedCommittee.takeAggregatedKey = COMMITTEE_TAKE_PUB_KEY();
        expectedCommittee.disputeAggregatedKey = COMMITTEE_DISPUTE_PUB_KEY();
        expectedCommittee.isPending = false;
        expectedCommittee.missingData = 0;

        return (expectedCommittee, committeeId);
    }

    function setup_completeAdditionalCommittee(uint256 _blockTime) internal returns (uint128 committeeId) {
        vm.warp(_blockTime);
        vm.roll(_blockTime);

        uint256 memberIndexStart = registeredMembersCounter;
        uint256 numOperators = registry.committeeMemberCount() / 2;
        uint256 numWatchtowers = registry.committeeMemberCount() - numOperators;
        setup_registerNewMembers(numWatchtowers, numOperators, SETUP_PENDING_COMMITTEE_DENOMINATION);

        // In a real scenario the committee (and packet) creation would be triggered automatically when
        // a new packet is needed (i.e., when we hit the threshold of the used slots),
        // we force the creation here to simplify the test setup and test specific things
        vm.prank(address(peginManager));
        registry.createCommittee(SETUP_PENDING_COMMITTEE_STREAM_ID);

        committeeId = registry.getPendingCommitteeId(SETUP_PENDING_COMMITTEE_STREAM_ID);
        setup_depositAggregatedKey_MultipleMembers(committeeId, memberIndexStart, registry.committeeMemberCount());
    }

    function setup_twoActiveCommittees()
        internal
        returns (uint128 firstCommitteeId, uint128 secondCommitteeId, uint64 streamId)
    {
        (, firstCommitteeId) = setup_completeCommittee();
        secondCommitteeId = setup_completeAdditionalCommittee(BLOCK_COMMITTEE_2);
        streamId = SETUP_PENDING_COMMITTEE_STREAM_ID;
    }

    /// @notice Sets up a pending committee with a specific size
    /// @param _size The desired committee size
    /// @return committeeId The ID of the created committee
    /// @return members The array of committee members
    function setup_pendingCommitteeWithSize(uint256 _size)
        internal
        returns (uint128 committeeId, CommitteeMember[] memory members)
    {
        vm.prank(registry.owner());
        registry.setCommitteeMemberCount(_size);

        uint64 streamId = uint64(SETUP_PENDING_COMMITTEE_DENOMINATION);

        _registerMembersForPendingCommittee(_size);

        vm.roll(block.number + 1);

        vm.prank(address(peginManager));
        registry.createCommittee(streamId);

        committeeId = registry.getPendingCommitteeId(streamId);

        members = registry.getCommitteeMembers(committeeId);

        return (committeeId, members);
    }

    /// @notice Sets up a complete committee with a specific size (all aggregated keys deposited)
    /// @param _size The desired committee size
    /// @return committeeId The ID of the created committee
    /// @return members The array of committee members
    function setup_completeCommitteeWithSize(uint256 _size)
        internal
        returns (uint128 committeeId, CommitteeMember[] memory members)
    {
        uint256 memberIndexStart = registeredMembersCounter;
        (committeeId, members) = setup_pendingCommitteeWithSize(_size);

        setup_depositAggregatedKey_MultipleMembers(committeeId, memberIndexStart, _size);

        return (committeeId, members);
    }

    /// @notice Registers candidates to a stream using harness functions without triggering automatic committee creation
    /// @dev This function uses harness methods (registerMemberHarness and registerCandidateToStreamHarness) which bypass
    ///      the normal applyToStream flow. This allows candidates to accumulate without automatically creating a committee,
    ///      which is necessary for testing selectCommittee functionality that requires multiple candidates to be available.
    /// @param numWatchtowers The number of watchtower candidates to register
    /// @param numOperators The number of operator candidates to register
    /// @param denomination The stream denomination to register candidates for
    function setup_registerCandidatesForStream(
        uint256 numWatchtowers,
        uint256 numOperators,
        StreamDenomination denomination
    ) internal {
        uint256 startingMemberIndex = registeredMembersCounter;
        uint256 totalMembers = numWatchtowers + numOperators;

        for (uint256 i = 0; i < totalMembers; i++) {
            Role roleForPosition = _roleForMemberIndex(i, numWatchtowers);
            address memberAddress = _addressForIndex(startingMemberIndex, i);
            MemberRegistrationKeys memory keys = _deriveRegistrationKeysFromAddress(memberAddress);
            uint256 minimumDeposit = streamManager.getMinimumDeposit(denomination, roleForPosition);
            vm.deal(memberAddress, minimumDeposit);

            memberRegistry.registerMemberHarness(memberAddress, keys);

            vm.prank(address(registry));
            memberRegistry.registerCandidateToStreamHarness(
                memberAddress, denomination, roleForPosition, minimumDeposit, generateDefaultUTXO()
            );
        }
        registeredMembersCounter = startingMemberIndex + totalMembers;
    }

    function setup_completeCommitteeAndNewMembers()
        internal
        returns (Committee memory firstCommittee, Committee memory secondCommittee, uint128 committeeId)
    {
        (firstCommittee, committeeId) = setup_completeCommittee();

        // Register new members
        vm.warp(BLOCK_COMMITTEE_2);
        vm.roll(BLOCK_COMMITTEE_2);
        uint256 numOperators = registry.committeeMemberCount() / 2;
        uint256 numWatchtowers = registry.committeeMemberCount() - numOperators;
        setup_registerNewMembers(numWatchtowers, numOperators, StreamDenomination(firstCommittee.streamId));

        secondCommittee = setup_getExpectedSecondCommittee();
        secondCommittee.takeAggregatedKey = COMMITTEE_TAKE_PUB_KEY();
        secondCommittee.disputeAggregatedKey = COMMITTEE_DISPUTE_PUB_KEY();

        return (firstCommittee, secondCommittee, COMMITTEE_ID_STREAM_1_COMMITTEE_2);
    }

    function setup_getExpectedSecondCommittee() internal view returns (Committee memory) {
        Committee memory committee = Committee({
            takeAggregatedKey: new bytes(0),
            disputeAggregatedKey: new bytes(0),
            members: new CommitteeMember[](registry.committeeMemberCount()),
            leaderAddress: address(0),
            operatorTakeIndex: 0,
            createdAt: BLOCK_COMMITTEE_2,
            missingData: 10,
            missingCommunicationData: 10,
            isPending: true,
            streamId: SETUP_PENDING_COMMITTEE_STREAM_ID,
            fundingUTXOs: new UTXO[](registry.committeeMemberCount())
        });

        for (uint256 i = 0; i < committee.members.length; i++) {
            committee.fundingUTXOs[i] = generateDefaultUTXO();
        }

        committee.members[0] = CommitteeMember({memberAddress: vm.addr(18 + 1), role: Role.OPERATOR});
        committee.members[1] = CommitteeMember({memberAddress: vm.addr(15 + 1), role: Role.OPERATOR});
        committee.members[2] = CommitteeMember({memberAddress: vm.addr(19 + 1), role: Role.OPERATOR});
        committee.members[3] = CommitteeMember({memberAddress: vm.addr(16 + 1), role: Role.OPERATOR});
        committee.members[4] = CommitteeMember({memberAddress: vm.addr(17 + 1), role: Role.OPERATOR});
        committee.members[5] = CommitteeMember({memberAddress: vm.addr(13 + 1), role: Role.WATCHTOWER});
        committee.members[6] = CommitteeMember({memberAddress: vm.addr(10 + 1), role: Role.WATCHTOWER});
        committee.members[7] = CommitteeMember({memberAddress: vm.addr(14 + 1), role: Role.WATCHTOWER});
        committee.members[8] = CommitteeMember({memberAddress: vm.addr(11 + 1), role: Role.WATCHTOWER});
        committee.members[9] = CommitteeMember({memberAddress: vm.addr(12 + 1), role: Role.WATCHTOWER});

        return committee;
    }

    function setup_getExpectedCommitteeBeforeExpire() internal view returns (Committee memory) {
        // NOTE: This function is tied to the initial setup of members that it's 0 members
        Committee memory committee = Committee({
            takeAggregatedKey: new bytes(0),
            disputeAggregatedKey: new bytes(0),
            members: new CommitteeMember[](registry.committeeMemberCount()),
            leaderAddress: address(0),
            operatorTakeIndex: 0,
            createdAt: BLOCK_COMMITTEE_1,
            missingData: 10,
            missingCommunicationData: 10,
            isPending: true,
            streamId: SETUP_PENDING_COMMITTEE_STREAM_ID,
            fundingUTXOs: new UTXO[](registry.committeeMemberCount())
        });
        for (uint256 i = 0; i < committee.members.length; i++) {
            committee.fundingUTXOs[i] = generateDefaultUTXO();
        }

        committee.members[0] = CommitteeMember({memberAddress: vm.addr(8 + 1), role: Role.OPERATOR});
        committee.members[1] = CommitteeMember({memberAddress: vm.addr(5 + 1), role: Role.OPERATOR});
        committee.members[2] = CommitteeMember({memberAddress: vm.addr(9 + 1), role: Role.OPERATOR});
        committee.members[3] = CommitteeMember({memberAddress: vm.addr(6 + 1), role: Role.OPERATOR});
        committee.members[4] = CommitteeMember({memberAddress: vm.addr(7 + 1), role: Role.OPERATOR});
        committee.members[5] = CommitteeMember({memberAddress: vm.addr(3 + 1), role: Role.WATCHTOWER});
        committee.members[6] = CommitteeMember({memberAddress: vm.addr(0 + 1), role: Role.WATCHTOWER});
        committee.members[7] = CommitteeMember({memberAddress: vm.addr(4 + 1), role: Role.WATCHTOWER});
        committee.members[8] = CommitteeMember({memberAddress: vm.addr(1 + 1), role: Role.WATCHTOWER});
        committee.members[9] = CommitteeMember({memberAddress: vm.addr(2 + 1), role: Role.WATCHTOWER});

        return committee;
    }

    function setup_registerMember(uint256 privKey) internal {
        MemberRegistrationKeys memory memberRegistrationKeys = generateRegistrationPublicKeys(privKey);
        address user = vm.addr(privKey);

        memberRegistry.registerMemberHarness(user, memberRegistrationKeys);
    }

    function setup_memberWithOddParityTakeKey() internal returns (MemberKeys memory keys) {
        // Private key 5 produces a wallet with odd Y take key (verified: publicKeyY % 2 == 1)
        uint256 oddParityTakePrivKey = 5;
        address memberAddr = vm.addr(oddParityTakePrivKey);
        MemberRegistrationKeys memory regKeys = generateRegistrationPublicKeys(oddParityTakePrivKey);
        setup_applyToStream(StreamDenomination._0_001BTC, memberAddr, regKeys, Role.OPERATOR);
        keys = memberRegistry.getMemberPublicKeys(memberAddr);
    }

    function setup_memberWithOddParityDisputeKey() internal returns (MemberKeys memory keys) {
        // Private key 2 produces a wallet with odd Y dispute key (verified: publicKeyY % 2 == 1)
        uint256 oddParityDisputePrivKey = 2;
        address memberAddr = vm.addr(oddParityDisputePrivKey);
        MemberRegistrationKeys memory regKeys = generateRegistrationPublicKeys(oddParityDisputePrivKey);
        setup_applyToStream(StreamDenomination._0_001BTC, memberAddr, regKeys, Role.OPERATOR);
        keys = memberRegistry.getMemberPublicKeys(memberAddr);
    }

    function setup_getExpectedCommitteeAfterExpire() internal view returns (Committee memory) {
        // NOTE: member order is tied to the timeout used in setup_pendingCommitteeAndExpire()
        Committee memory committee = Committee({
            takeAggregatedKey: new bytes(0),
            disputeAggregatedKey: new bytes(0),
            members: new CommitteeMember[](registry.committeeMemberCount()),
            leaderAddress: address(0),
            operatorTakeIndex: 0,
            createdAt: BLOCK_COMMITTEE_3,
            missingData: 10,
            missingCommunicationData: 10,
            isPending: true,
            streamId: SETUP_PENDING_COMMITTEE_STREAM_ID,
            fundingUTXOs: new UTXO[](registry.committeeMemberCount())
        });

        for (uint256 i = 0; i < committee.members.length; i++) {
            committee.fundingUTXOs[i] = generateDefaultUTXO();
        }

        committee.members[0] = CommitteeMember({memberAddress: vm.addr(8 + 1), role: Role.OPERATOR});
        committee.members[1] = CommitteeMember({memberAddress: vm.addr(5 + 1), role: Role.OPERATOR});
        committee.members[2] = CommitteeMember({memberAddress: vm.addr(9 + 1), role: Role.OPERATOR});
        committee.members[3] = CommitteeMember({memberAddress: vm.addr(6 + 1), role: Role.OPERATOR});
        committee.members[4] = CommitteeMember({memberAddress: vm.addr(7 + 1), role: Role.OPERATOR});
        committee.members[5] = CommitteeMember({memberAddress: vm.addr(3 + 1), role: Role.WATCHTOWER});
        committee.members[6] = CommitteeMember({memberAddress: vm.addr(0 + 1), role: Role.WATCHTOWER});
        committee.members[7] = CommitteeMember({memberAddress: vm.addr(4 + 1), role: Role.WATCHTOWER});
        committee.members[8] = CommitteeMember({memberAddress: vm.addr(1 + 1), role: Role.WATCHTOWER});
        committee.members[9] = CommitteeMember({memberAddress: vm.addr(2 + 1), role: Role.WATCHTOWER});

        return committee;
    }

    function setup_addMemberNonce(address _memberAddress, bytes32 _txid, bytes memory _nonce) internal {
        vm.prank(_memberAddress);
        signatureManager.addMemberNonce(_txid, _nonce);
    }

    function setup_initOperatorTakeTxids(bytes32 _acceptPeginTxid, uint128 _committeeId) internal {
        vm.prank(address(peginManager));
        signatureManager.initOperatorTakeTxids(_acceptPeginTxid, _committeeId);
    }

    function setup_addOperatorTakeTxids(
        address _memberAddress,
        bytes32 _acceptPeginTxid,
        bytes32 _takeTxid,
        bytes32 _wonTxid
    ) internal {
        vm.prank(_memberAddress);
        signatureManager.addOperatorTakeTxids(_acceptPeginTxid, _takeTxid, _wonTxid);
    }

    function setup_addMemberNonce_MultipleMembers(bytes32 _txid, uint256 _memberIndexStart, uint256 _memberCount)
        internal
    {
        uint256 memberIndexEnd = _memberIndexStart + _memberCount;
        for (uint256 i = _memberIndexStart; i < memberIndexEnd; i++) {
            // The nonce values are dummy values
            bytes memory nonce =
                hex"f8c0b1a2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0f8c0b1a2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a00000";
            setup_addMemberNonce(vm.addr(i + 1), _txid, nonce);
        }
    }

    function setup_addMemberSignature(address _memberAddress, bytes32 _pegoutTxid, bytes32 _signature) internal {
        vm.prank(_memberAddress);
        signatureManager.addMemberSignature(_pegoutTxid, _signature);
    }

    function setup_addMemberSignature_MultipleMembers(
        bytes32 _pegoutTxid,
        uint256 _memberIndexStart,
        uint256 _membersCount
    ) internal {
        uint256 memberIndexEnd = _memberIndexStart + _membersCount;
        for (uint256 i = _memberIndexStart; i < memberIndexEnd; i++) {
            // The signarture values are dummy values
            bytes32 signature = hex"f8c0b1a2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0";
            setup_addMemberSignature(vm.addr(i + 1), _pegoutTxid, signature);
        }
    }

    function setup_cancelUserTake() internal returns (address operatorAddress, RegisterUserTakeSetup memory setup) {
        // Arrange
        setup = setup_pegoutAndMemberNonces();
        uint256 createdAt = block.timestamp;
        // Expire TAKE_0
        vm.warp(createdAt + TAKE_0_TIMEOUT_DEFAULT + 1);
        // This depende on how they have been registered. First registered group are the watchtowers
        uint256 firstHonestOpIndex = registry.committeeMemberCount() / 2 + 1;

        // Add just 2 signatures for the first and second operators (by registration order)
        setup_addMemberSignature_MultipleMembers(setup.pegoutTxid, firstHonestOpIndex, 2);

        // Trigger operator take and get the actual operator address selected by the contract
        operatorTakeManager.triggerOperatorTake(setup.acceptPeginTxid);

        // Get the actual operator that was selected from the contract state
        OperatorTakeInfo memory opInfo = operatorTakeManager.getOperatorTakeInfo(setup.acceptPeginTxid);
        operatorAddress = opInfo.operatorTakeAddress;
        setup.pegoutId = opInfo.pegoutId;

        setup.cancelUserTakeSPV = createBtcTxSPVProof(
            createCancelUserTakeTx(
                setup.acceptPeginTxid,
                BtcHelper.compactPubKeyToBytes(memberRegistry.getMemberDisputePubKey(operatorAddress))
            )
        );

        setup.advanceFundsSPV = createBtcTxSPVProof(createAdvanceFundsTx(setup.userPubKey, VALUE, setup.pegoutId));

        BtcTransaction memory opTakeTx;
        (opTakeTx,, setup.reimbursementKickoffSPV) =
            setup_getOperatorTakeData(setup.acceptPeginTxid, operatorAddress, uint32(setup.slotId));

        setup.operatorTakeSPV = createBtcTxSPVProof(opTakeTx);

        bytes32 reimbursementTxid = bitcoinManager.getBtcTxid(setup.reimbursementKickoffSPV.btcTx);
        uint128 committeeId = streamManager.getCommitteeId(uint64(DEFAULT_STREAM), setup.packetNumber);
        bytes memory committeePubKey = registry.getCommitteeTakePubKey(committeeId);

        setup.challengeSPV = createBtcTxSPVProof(createChallengeTx(reimbursementTxid, committeePubKey));
    }

    function setup_advanceFunds() internal returns (address operatorAddress, RegisterUserTakeSetup memory setup) {
        (operatorAddress, setup) = setup_cancelUserTake();
        operatorTakeManager.registerCancelUserTake(setup.cancelUserTakeSPV);
    }

    function setup_getOperatorTakeData(bytes32 _acceptPeginTxid, address _operatorAddress, uint64 _slotId)
        internal
        returns (
            BtcTransaction memory opTakeTx,
            BtcTransaction memory opWonTx,
            BtcTxSPVProof memory reimbursementKickoffSPV
        )
    {
        bytes memory operatorDisputePubKeyCompact = _getMemberDisputePubKeyCompact(_operatorAddress);

        bytes32 reimbursementTxid;
        (reimbursementTxid, reimbursementKickoffSPV) =
            _createReimbursementKickoffSPV(operatorDisputePubKeyCompact, uint32(_slotId));

        opTakeTx = createOperatorTakeTx(_acceptPeginTxid, reimbursementTxid, operatorDisputePubKeyCompact, VALUE);

        uint128 committeeId = streamManager.getCommitteeId(uint64(DEFAULT_STREAM), 0);
        bytes memory committeePubKey = registry.getCommitteeTakePubKey(committeeId);

        bytes32 challengeTxid = _createChallengeTxid(reimbursementTxid, committeePubKey);

        bytes32 inputRevealedTxid =
            _createInputRevealedTxid(challengeTxid, committeePubKey, operatorDisputePubKeyCompact);

        opWonTx = createOperatorWonTx(_acceptPeginTxid, inputRevealedTxid, operatorDisputePubKeyCompact, VALUE);
    }

    function _getMemberDisputePubKeyCompact(address _operatorAddress) internal view returns (bytes memory) {
        CompactPubKey memory compactKey = memberRegistry.getMemberDisputePubKey(_operatorAddress);
        return BtcHelper.compactPubKeyToBytes(compactKey);
    }

    function _createReimbursementKickoffSPV(bytes memory _operatorDisputePubKeyCompact, uint64 _slotId)
        internal
        returns (bytes32 reimbursementTxid, BtcTxSPVProof memory reimbursementKickoffSPV)
    {
        BtcTransaction memory reimbursementKickoffTx =
            createReimbursementKickoffTx(_operatorDisputePubKeyCompact, uint32(_slotId));
        reimbursementTxid = bitcoinManager.getBtcTxid(reimbursementKickoffTx);
        reimbursementKickoffSPV = createBtcTxSPVProof(reimbursementKickoffTx);
    }

    function _createChallengeTxid(bytes32 _reimbursementTxid, bytes memory _committeePubKey)
        internal
        returns (bytes32 challengeTxid)
    {
        BtcTransaction memory challengeTx = createChallengeTx(_reimbursementTxid, _committeePubKey);
        return bitcoinManager.getBtcTxid(challengeTx);
    }

    function _createInputRevealedTxid(
        bytes32 _challengeTxid,
        bytes memory _committeePubKey,
        bytes memory _operatorDisputePubKeyCompact
    ) internal returns (bytes32 inputRevealedTxid) {
        BtcTransaction memory inputRevealedTx =
            createInputRevealedTx(_challengeTxid, _committeePubKey, _operatorDisputePubKeyCompact);
        return bitcoinManager.getBtcTxid(inputRevealedTx);
    }

    function setup_operatorTake() internal returns (address operatorAddress, RegisterUserTakeSetup memory setup) {
        (operatorAddress, setup) = setup_reimbursementKickoff();

        vm.prank(operatorAddress);
        operatorTakeManager.registerReimbursementKickoff(setup.acceptPeginTxid, setup.reimbursementKickoffSPV);
    }

    function setup_challenge() internal returns (address operatorAddress, RegisterUserTakeSetup memory setup) {
        (operatorAddress, setup) = setup_operatorTake();

        uint128 committeeId = streamManager.getCommitteeId(uint64(DEFAULT_STREAM), setup.packetNumber);
        bytes memory committeePubKey = registry.getCommitteeTakePubKey(committeeId);
        bytes32 challengeTxid = bitcoinManager.getBtcTxid(setup.challengeSPV.btcTx);
        bytes memory operatorPubKey =
            BtcHelper.compactPubKeyToBytes(memberRegistry.getMemberDisputePubKey(operatorAddress));
        setup.inputRevealedSPV =
            createBtcTxSPVProof(createInputRevealedTx(challengeTxid, committeePubKey, operatorPubKey));

        CompactPubKey[] memory disputePubKeys = registry.getCommitteeDisputeKeys(committeeId);
        setup.inputNotRevealedSPV = createBtcTxSPVProof(createInputNotRevealedTx(challengeTxid, disputePubKeys));

        vm.prank(operatorAddress);
        challengeManager.registerChallenge(setup.acceptPeginTxid, setup.challengeSPV);
    }

    function setup_inputRevealed() internal returns (address operatorAddress, RegisterUserTakeSetup memory setup) {
        (operatorAddress, setup) = setup_challenge();

        bytes memory operatorDisputePubKeyCompact =
            BtcHelper.compactPubKeyToBytes(memberRegistry.getMemberDisputePubKey(operatorAddress));

        bytes32 inputRevealedTxid = bitcoinManager.getBtcTxid(setup.inputRevealedSPV.btcTx);
        setup.operatorWonSPV = createBtcTxSPVProof(
            createOperatorWonTx(setup.acceptPeginTxid, inputRevealedTxid, operatorDisputePubKeyCompact, VALUE)
        );

        setup.stopOperatorWonSPV = createBtcTxSPVProof(createStopOperatorWonTx(inputRevealedTxid));

        vm.prank(operatorAddress);
        challengeManager.registerInputRevealed(setup.acceptPeginTxid, setup.inputRevealedSPV);
    }

    function setup_reimbursementKickoff()
        internal
        returns (address operatorAddress, RegisterUserTakeSetup memory setup)
    {
        bridgeMock.setBtcBlockchainBestChainHeight(BEST_CHAIN_HEIGHT);
        (operatorAddress, setup) = setup_advanceFunds();

        vm.prank(operatorAddress);
        operatorTakeManager.registerAdvanceFunds(setup.acceptPeginTxid, setup.advanceFundsSPV);

        bridgeMock.setBtcBlockchainBestChainHeight(BEST_CHAIN_HEIGHT + 1);
    }

    function assertStreamPositionAndSlotStateByRequestPegin(
        bytes32 _requestPeginTxid,
        uint64 _streamId,
        uint64 _packetNumber,
        uint64 _slotId,
        SlotState _expectedSlotState
    ) internal view {
        // Verify each request gets correct slotId
        StreamPosition memory streamPosition = peginManager.getStreamPositionByRequestPegin(_requestPeginTxid);
        assertEq(streamPosition.streamId, _streamId, "Incorrect streamId registered");
        assertEq(streamPosition.packetNumber, _packetNumber, "Incorrect packetNumber registered");
        assertEq(streamPosition.slotId, _slotId, "Incorrect slotId registered");

        // Verify slot state
        Slot memory reservedSlot =
            streamManager.getSlot(streamPosition.streamId, streamPosition.packetNumber, streamPosition.slotId);
        assertEq(uint256(reservedSlot.state), uint256(_expectedSlotState), "Incorrect slot state registered");
        assertEq(reservedSlot.slotId, streamPosition.slotId, "Slot ID should match StreamPosition");
    }

    function assertEventOperatorTakeTriggered(RegisterUserTakeSetup memory setup, address _operatorAddress) internal {
        MemberKeys memory keys = memberRegistry.getMemberPublicKeys(_operatorAddress);

        OperatorTakeInfo memory expectedOpInfo = OperatorTakeInfo({
            operatorTakeUpdatedAt: block.timestamp,
            operatorTakeAddress: _operatorAddress,
            operatorTakePubKey: keys.takePubKey,
            operatorDisputePubKey: keys.disputePubKey,
            pegoutId: calculatePegoutId(keys.takePubKey, setup.stream.streamId, setup.packetNumber, setup.slotId),
            advanceFundsBlockNumber: 0,
            reimbursementKickoffTxid: bytes32(0)
        });

        StreamPosition memory expectedStreamPosition = StreamPosition({
            streamId: setup.stream.streamId,
            packetNumber: setup.packetNumber,
            slotId: setup.slotId,
            pegStatus: PegStatus.OP_SELECTED
        });

        vm.expectEmit(address(operatorTakeManager));
        emit IOperatorTakeManager.OperatorTakeTriggered(
            setup.pegoutTxid,
            expectedOpInfo,
            expectedStreamPosition,
            block.timestamp,
            block.timestamp + TAKE_1_TIMEOUT_DEFAULT
        );
    }

    // ====== Communication Data Helper Functions ======

    /// @notice Creates communication data chunks for a member using a unique identifier
    /// @param identifier Unique string to generate deterministic chunks
    /// @return chunks Array of 8 bytes32 chunks
    function createCommunicationDataChunks(string memory identifier)
        internal
        pure
        returns (bytes32[COMMUNICATION_DATA_CHUNKS] memory chunks)
    {
        for (uint256 i = 0; i < COMMUNICATION_DATA_CHUNKS; i++) {
            chunks[i] = keccak256(abi.encodePacked(identifier, "chunk", i));
        }
        return chunks;
    }

    /// @notice Creates valid communication data array for a committee member
    /// @param committeeSize Number of members in the committee
    /// @param memberIndex Index of the member depositing data (own slot will be zero)
    /// @return communicationData Array with zeros for own slot, non-zero for others
    function createValidCommunicationData(uint256 committeeSize, uint256 memberIndex)
        internal
        pure
        returns (CommunicationData[] memory communicationData)
    {
        communicationData = new CommunicationData[](committeeSize);

        for (uint256 i = 0; i < committeeSize; i++) {
            if (i != memberIndex) {
                // Other slots - non-zero data
                string memory identifier = string(abi.encodePacked("member", i, "for", memberIndex));
                communicationData[i] = CommunicationData({data: createCommunicationDataChunks(identifier)});
            }
        }

        return communicationData;
    }

    /// @notice Creates minimal communication data for testing with just 1 character per chunk
    /// @param committeeSize Size of the committee
    /// @param memberIndex Index of the member creating the data
    /// @return communicationData Array of communication data with minimal content
    function createMinimalCommunicationData(uint256 committeeSize, uint256 memberIndex)
        internal
        pure
        returns (CommunicationData[] memory communicationData)
    {
        communicationData = new CommunicationData[](committeeSize);

        for (uint256 i = 0; i < committeeSize; i++) {
            if (i != memberIndex) {
                // Other slots - minimal data (just one bit set in first chunk)
                bytes32[COMMUNICATION_DATA_CHUNKS] memory chunks;
                chunks[0] = bytes32(uint256(1)); // Single bit set
                communicationData[i] = CommunicationData({data: chunks});
            }
        }

        return communicationData;
    }

    /// @notice Asserts that two CommunicationData arrays are equal
    /// @param expected Expected communication data array
    /// @param actual Actual communication data array
    /// @param message Error message if assertion fails
    function assertCommunicationDataEqual(
        CommunicationData[] memory expected,
        CommunicationData[] memory actual,
        string memory message
    ) internal pure {
        assertEq(expected.length, actual.length, string(abi.encodePacked(message, ": array lengths differ")));

        for (uint256 i = 0; i < expected.length; i++) {
            for (uint256 j = 0; j < COMMUNICATION_DATA_CHUNKS; j++) {
                assertEq(
                    expected[i].data[j],
                    actual[i].data[j],
                    string(
                        abi.encodePacked(
                            message, ": data differs at index [", Strings.toString(i), "][", Strings.toString(j), "]"
                        )
                    )
                );
            }
        }
    }

    /// @notice Helper to deposit communication data for a specific member
    /// @param streamId Stream ID for the pending committee
    /// @param memberAddress Address of the member depositing data
    /// @param memberIndex Index of the member in the committee (for generating valid data)
    function setup_depositCommunicationData(uint64 streamId, address memberAddress, uint256 memberIndex) internal {
        Committee memory committee = registry.getPendingCommittee(streamId);
        CommunicationData[] memory communicationData =
            createValidCommunicationData(committee.members.length, memberIndex);

        vm.prank(memberAddress);
        registry.depositCommunicationData(streamId, communicationData);
    }

    /// @notice Helper to deposit communication data for multiple members
    /// @param streamId Stream ID for the pending committee
    /// @param startIndex Starting member index
    /// @param count Number of members to deposit data for
    function setup_depositCommunicationData_MultipleMembers(uint64 streamId, uint256 startIndex, uint256 count)
        internal
    {
        for (uint256 i = 0; i < count; i++) {
            uint256 memberIndex = startIndex + i;
            address memberAddress = vm.addr(memberIndex + 1);
            setup_depositCommunicationData(streamId, memberAddress, memberIndex);
        }
    }

    function pauseContracts() internal {
        vm.prank(accessManager.owner());
        accessManager.pause();
    }

    function pauseAndUnpauseContracts() internal {
        vm.startPrank(accessManager.owner());
        accessManager.pause();
        accessManager.unpause();
        vm.stopPrank();
    }

    /// @notice Gets the dispute key 33 bytes compact format for a member by address
    /// @param _memberAddress The address of the member
    /// @return disputeKey The dispute key 33 bytes compact format for the member
    function getDisputeKeyByAddress(address _memberAddress) internal view returns (bytes memory disputeKey) {
        CompactPubKey memory compactKey = memberRegistry.getMemberDisputePubKey(_memberAddress);
        disputeKey = BtcHelper.compactPubKeyToBytes(compactKey);
        return disputeKey;
    }

    /// @notice Gets the committee member address by index
    /// @param committeeId The committee ID
    /// @param index The index of the member
    /// @return memberAddress The address of the member
    function getCommitteeMemberAddressByIndex(uint128 committeeId, uint256 index) internal view returns (address) {
        Committee memory committee = registry.getCommittee(committeeId);
        require(index < committee.members.length, "Index out of bounds");
        return committee.members[index].memberAddress;
    }

    // ========================== Gas Calculation Helper ==========================

    /// @notice Helper function to calculate gas price and cost in wei
    /// @param gasUsed Amount of gas used
    /// @return gasPrice The gas price in wei (set via vm.txGasPrice())
    /// @return costInWei Total cost in wei (gasUsed * gasPrice)
    function calculateGasCost(uint256 gasUsed) internal view returns (uint256 gasPrice, uint256 costInWei) {
        gasPrice = tx.gasprice;
        costInWei = gasUsed * gasPrice;
    }

    /// @notice Helper to create a slot in a specific state using harness, with stream position set up
    /// @param _streamId The stream ID
    /// @param _packetNumber The packet number
    /// @param _state The desired slot state
    /// @return slotId The created slot ID
    /// @return txid The unique txid mapped to this slot's stream position
    function setup_slotWithState(uint64 _streamId, uint64 _packetNumber, SlotState _state)
        internal
        returns (uint64 slotId, bytes32 txid)
    {
        slotId = uint64(streamManager.getSlotsLengthHarness(_streamId, _packetNumber));

        // Generate unique txid based on slot parameters
        txid = keccak256(abi.encodePacked(_streamId, _packetNumber, slotId));

        streamManager.pushSlotsHarness(_streamId, _packetNumber, 1, _state);

        vm.prank(address(peginManager));
        streamManager.setStreamPosition(txid, StreamPosition(_streamId, _packetNumber, slotId, PegStatus.REGISTERED));
    }

    function getExpectedBitcoinSignatureData()
        public
        returns (BitcoinSignatureData memory data, bytes32 acceptPeginTxid)
    {
        // This function only works for first accept pegin with txid: 0x14fdaad7499abf1ef94b3705749fad1d3979cce2dc636e978b83e756bd6ad23a,
        // If that's not the case txid, signatureHash and signatureMessage should be updated accordingly
        acceptPeginTxid = 0x14fdaad7499abf1ef94b3705749fad1d3979cce2dc636e978b83e756bd6ad23a;

        BtcTxIn[] memory inputs = new BtcTxIn[](2);
        inputs[0] = BtcTxIn({txId: acceptPeginTxid, vout: 0, sequence: 4294967293, scriptSig: hex""});
        inputs[1] = BtcTxIn({
            txId: acceptPeginTxid,
            vout: 1, // Enabler output from accept pegin
            sequence: 4294967293,
            scriptSig: hex""
        });

        BtcTxOut[] memory outputs = new BtcTxOut[](2);
        outputs[0] = BtcTxOut({amount: 998250, scriptPubKey: hex"00143fd2e14f4b448a071e074e1e1879318447f2a266"});
        outputs[1] = BtcTxOut({amount: 540, scriptPubKey: hex"00143fd2e14f4b448a071e074e1e1879318447f2a266"});

        data = BitcoinSignatureData({
            tx: BtcTransaction({version: 2, inputs: inputs, outputs: outputs, locktime: 0}),
            txid: 0xe170b24b41e5bfb912fb4d9ea6688994a2290db667bdf9bcd207202fdc56a3c4,
            signatureHash: 0x0a1043930f6622205d3c54be82a44e2090f38001dc95d188cf7ec4cfa7441ae0,
            signatureMessage: hex"00010200000000000000a0e918b6e29da87a5467ddb8d7f29a4de304b82573887401d0b1fd7b81d4cdccac72564c6204c6e42cdd3fa58fd3314ac25c5e7a7d324d5dd03ee456abdcce386278a9f4ca919d3af59490c32ad58017de5f25e9c95d50c1569249e0f7eb688482d397cbbcff87bc5d0c4c70e424f9b830efbad7bf0be479da5d1d1bafdb9798f81b4776c4bc98417c41f791185dfa89d0789939526bc6907fcdcb6f7490398b0000000000"
        });
    }
}
