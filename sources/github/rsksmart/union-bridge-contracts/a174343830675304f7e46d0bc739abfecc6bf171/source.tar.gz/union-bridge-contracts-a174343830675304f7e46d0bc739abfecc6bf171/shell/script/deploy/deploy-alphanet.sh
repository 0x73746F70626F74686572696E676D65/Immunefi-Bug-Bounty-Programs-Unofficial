#!/bin/bash
set -e

# we go to the root of the project to avoid relative path issues
CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd "$CURRENT_PATH/../../.."

# set up environment variables
source .env

# Set network-specific variables
export NETWORK=alphanet
export RPC=$RSK_ALPHANET_RPC
export RSK_EXPLORER_API=$RSK_EXPLORER_ALPHANET_API
export RSK_EXPLORER_URL=$RSK_EXPLORER_ALPHANET_URL
export CHAIN_ID=31
# Note: BLOCKSCOUT_API is intentionally not set for alphanet (no Blockscout verification)

# Call the common deployment script
"$CURRENT_PATH/deploy-common.sh"
