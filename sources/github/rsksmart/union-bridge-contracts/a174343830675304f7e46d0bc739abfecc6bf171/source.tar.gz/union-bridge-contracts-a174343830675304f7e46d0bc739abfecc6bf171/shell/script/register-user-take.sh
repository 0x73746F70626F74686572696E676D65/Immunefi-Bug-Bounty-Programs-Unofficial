#!/bin/sh

# we go to the root of the project to avoid relative path issues
CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd "$CURRENT_PATH/../.."

# set up environment variables
source .env
RPC=$LOCAL_RPC

# Parse args
while getopts ":-:" opt; do
  case "$opt" in
    -)
      case "${OPTARG}" in
        alphanet)
          RPC=$RSK_ALPHANET_RPC
          export NETWORK=alphanet
          ;;
        *)
          echo "Unknown option --${OPTARG}"
          exit 1
          ;;
      esac
      ;;
    *)
      echo "Usage: $0 [--alphanet]"
      echo "Example: $0 "
      exit 1
      ;;
  esac
done


echo "================ REGISTER USER TAKE REQUEST TO $RPC ================"

forge script \
    script/RegisterUserTake.s.sol \
    --sig "run()" \
    --rpc-url $RPC \
    --legacy \
    --broadcast \