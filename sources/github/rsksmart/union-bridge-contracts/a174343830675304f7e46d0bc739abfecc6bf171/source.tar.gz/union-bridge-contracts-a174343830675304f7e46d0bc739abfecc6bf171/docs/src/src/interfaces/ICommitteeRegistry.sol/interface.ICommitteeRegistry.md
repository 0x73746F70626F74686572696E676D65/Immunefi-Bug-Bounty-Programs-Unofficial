# ICommitteeRegistry
[Git Source](https://github.com/rsksmart/union-bridge-contracts/blob/6c85aeb17a23ee9d675a92f8655a551ecca7b4c9/src/interfaces/ICommitteeRegistry.sol)

Interface for managing committee registration and formation in the union bridge

*This interface provides functions for member registration, committee formation,*

*and balance management for the committee system*


## Functions
### isWhitelisted

Checks if an address is whitelisted


```solidity
function isWhitelisted(address _address) external view returns (bool);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_address`|`address`|The address to check|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`bool`|True if the address is whitelisted, false otherwise|


### whitelistAddress

Whitelists an address to enable it to apply to a stream

*Only callable by the contract whitelister*


```solidity
function whitelistAddress(address _address) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_address`|`address`|The address to whitelist|


### whitelistAddresses

Whitelists multiple addresses to enable them to apply to a stream

*Only callable by the contract whitelister*


```solidity
function whitelistAddresses(address[] memory _addresses) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_addresses`|`address[]`|The addresses to whitelist|


### unwhitelistAddress

Unwhitelists an address to disable it from applying to a stream

*Only callable by the contract whitelister*


```solidity
function unwhitelistAddress(address _address) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_address`|`address`|The address to unwhitelist|


### unwhitelistAddresses

Unwhitelists multiple addresses to disable them from applying to a stream

*Only callable by the contract whitelister*


```solidity
function unwhitelistAddresses(address[] memory _addresses) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_addresses`|`address[]`|The addresses to unwhitelist|


### applyToStream

Applies to participate in a stream with a specific role

*Registers public keys, deposits required bond, and provides funding UTXO for the requested role*


```solidity
function applyToStream(
    StreamDenomination _requestedStream,
    Role _requestedRole,
    MemberRegistrationKeys calldata _publicKeys,
    UTXO calldata _fundingUTXO
) external payable;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_requestedStream`|`StreamDenomination`|The stream denomination to apply for|
|`_requestedRole`|`Role`|The role requested in the committee|
|`_publicKeys`|`MemberRegistrationKeys`|Member public key registration with ECDSA and RSA hash keys|
|`_fundingUTXO`|`UTXO`|The Bitcoin UTXO that will be used for committee funding|


### unsubscribeFromStream

Unsubscribes from a stream and sets the pre-staked balance as available

*Only callable when contract is unpaused*


```solidity
function unsubscribeFromStream(StreamDenomination _denomination) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_denomination`|`StreamDenomination`|The stream denomination to unsubscribe from|


### getCommittee

Gets a committee by its ID


```solidity
function getCommittee(uint128 _committeeId) external view returns (Committee calldata);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`Committee`|Committee The complete committee information|


### getCommitteeTakePubKey

Retrieves the committee take aggregated public key for a specific packet


```solidity
function getCommitteeTakePubKey(uint128 _committeeId) external view returns (bytes memory);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`bytes`|bytes The committee take aggregated public key for this packet (33 bytes compressed format)|


### getCommitteeDisputePubKey

Retrieves the committee dispute aggregated public key for a specific packet


```solidity
function getCommitteeDisputePubKey(uint128 _committeeId) external view returns (bytes memory);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`bytes`|bytes The committee dispute aggregated public key for this packet (33 bytes compressed format)|


### getCommitteeMembers

Gets all members of a specific committee


```solidity
function getCommitteeMembers(uint128 _committeeId) external view returns (CommitteeMember[] memory);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`CommitteeMember[]`|Array of committee members with their roles|


### getCommitteeMembersLength

Gets the number of members in a specific committee


```solidity
function getCommitteeMembersLength(uint128 _committeeId) external view returns (uint256);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`uint256`|The number of committee members (e.g. for validating input-not-revealed tx output count)|


### memberRegistry

Gets the member registry contract address


```solidity
function memberRegistry() external view returns (IMemberRegistry);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`IMemberRegistry`|The member registry contract|


### depositAggregatedKeys

Allows a member to deposit their aggregated keys for committee formation

*Called by members to provide their take and dispute aggregated keys for a pending committee*

*Only callable when contract is unpaused*


```solidity
function depositAggregatedKeys(
    uint128 _committeeId,
    bytes memory _takeAggregatedKey,
    bytes memory _disputeAggregatedKey
) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The ID of the pending committee|
|`_takeAggregatedKey`|`bytes`|The take aggregated public key provided by the member (must be exactly 33 bytes)|
|`_disputeAggregatedKey`|`bytes`|The dispute aggregated public key provided by the member (must be exactly 33 bytes)|


### createCommittee

Triggers the creation of a new committee for a stream if the timeout has expired

*This function is called when the slot usage threshold is reached*


```solidity
function createCommittee(uint64 _streamId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID to create a new committee for|


### isPendingCommitteeExpired

Checks if there is a pending committee for the stream and it's expired


```solidity
function isPendingCommitteeExpired(uint64 _streamId) external view returns (bool);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID to check for a pending committee|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`bool`|True if the pending committee exists and is expired|


### getPendingCommittee

Returns the pending committee for the stream

*This function will revert if  there is no pending committee or if it's expired*


```solidity
function getPendingCommittee(uint64 _streamId) external view returns (Committee memory);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID to get the pending committee for|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`Committee`|Committee The pending committee (contains createdAt and missingData fields)|


### getPendingCommitteeId

Returns the committee ID for a pending committee in the given stream


```solidity
function getPendingCommitteeId(uint64 _streamId) external view returns (uint128 committeeId);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID to get the pending committee ID for|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee ID of the pending committee|


### getMissingCommunicationDataCount

Returns the number of members that have not deposited their communication data yet


```solidity
function getMissingCommunicationDataCount(uint128 _committeeId)
    external
    view
    returns (uint16 missingCommunicationData);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID to check for missing communication data|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`missingCommunicationData`|`uint16`|The number of members that have not deposited their communication data yet|


### depositCommunicationData

Deposits encrypted communication data (IP and Port) for a member in a pending committee

*This function is called by members to provide their encrypted communication data*

*Only callable when contract is unpaused*


```solidity
function depositCommunicationData(uint128 _committeeId, CommunicationData[] memory _communicationData) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The ID of the pending committee|
|`_communicationData`|`CommunicationData[]`|Array of encrypted communication data (IP and Port) for the member|


### getMemberCommunicationData

Gets the encrypted communication data for one member in a committee

*This function returns the encrypted communication data (IP and Port) deposited for a particular member*

*The order of the data corresponds to the order of members in the committee*


```solidity
function getMemberCommunicationData(uint128 _committeeId, address _memberAddress)
    external
    view
    returns (CommunicationData[] memory communicationData);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID for the committee|
|`_memberAddress`|`address`|The address of the member we are requesting data for|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`communicationData`|`CommunicationData[]`|encrypted communication data (IP and Port) from the committee members|


### validateMemberInCommittee

Validates that a member is part of a specific committee; reverts if not


```solidity
function validateMemberInCommittee(uint128 _committeeId, address _memberAddress) external view;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|
|`_memberAddress`|`address`|The address of the member to check|


### setWhitelister

Sets the Whitelister address

*Only callable by the contract owner*


```solidity
function setWhitelister(address _newWhitelister) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_newWhitelister`|`address`|The address of the whitelister|


### setPendingCommitteeTimeout

Sets the pending committee timeout

*Only callable by the contract owner*


```solidity
function setPendingCommitteeTimeout(uint256 _timeout) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_timeout`|`uint256`|The timeout in seconds for the pending committee|


### setCommitteeMinWatchtowers

Sets the minimum watchtowers required for a committee

*Only callable by the contract owner*


```solidity
function setCommitteeMinWatchtowers(uint256 _minWatchtowers) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_minWatchtowers`|`uint256`|The minimum watchtowers required for a committee|


### setCommitteeMinOperators

Sets the minimum operators required for a committee

*Only callable by the contract owner*


```solidity
function setCommitteeMinOperators(uint256 _minOperators) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_minOperators`|`uint256`|The minimum operators required for a committee|


### setCommitteeMemberCount

Sets the exact number of members required for a committee

*Only callable by the contract owner*


```solidity
function setCommitteeMemberCount(uint256 _committeeMemberCount) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeMemberCount`|`uint256`|The exact number of members required for a committee|


### demoteOperatorToWatchtower

Demotes an operator to watchtower in a specific active committee

*Only callable by the contract owner*

*Owner-only access is temporary, once slashing is implemented, this function
will be internal and called directly by the slashing mechanism*


```solidity
function demoteOperatorToWatchtower(uint128 _committeeId, address _memberAddress) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The ID of the active committee|
|`_memberAddress`|`address`|The address of the operator to demote|


### selectTakeOperator

Gets the operator dispute data (address and dispute public key) for operator-take operations

*Rotates through committee operators to distribute take responsibilities*

*Only operators who have deposited their signatures nonces are eligible for take operations*

*Reverts with TakeOperatorNotFound if no eligible operator is found*


```solidity
function selectTakeOperator(uint128 _committeeId, SignatureData[] calldata _signatureData, uint8 _missingNonces)
    external
    returns (address operatorAddress, CompactPubKey memory disputePubKey, CompactPubKey memory takePubKey);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID to get the operator from|
|`_signatureData`|`SignatureData[]`|Array of signature data for committee members|
|`_missingNonces`|`uint8`|Number of missing nonces|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`operatorAddress`|`address`|The address of the next available operator for take operations|
|`disputePubKey`|`CompactPubKey`|The operator's dispute public key|
|`takePubKey`|`CompactPubKey`|The operator's take public key|


### releaseCommittee

Releases committee members from a packet and handles their staked balance

*Called by PegManager to release committee members after packet completion*

*Only callable by PegManager contract*

*Members with reApply=true will be re-added as candidates, others get their balance as available*


```solidity
function releaseCommittee(uint64 _streamId, uint64 _packetNumber) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID for the committee|
|`_packetNumber`|`uint64`|The packet number where the committee was active|


### restartPendingCommittee

Restarts a pending committee if it has expired

*Only callable when contract is unpaused*


```solidity
function restartPendingCommittee(uint64 _streamId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID to restart the pending committee for|


### committeeMemberCount

Gets the committee member count


```solidity
function committeeMemberCount() external view returns (uint256);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`uint256`|The committee member count|


### minCommitteeWatchtowers

Gets the minimum watchtowers required for a committee


```solidity
function minCommitteeWatchtowers() external view returns (uint256);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`uint256`|The minimum watchtowers required for a committee|


### minCommitteeOperators

Gets the minimum operators required for a committee


```solidity
function minCommitteeOperators() external view returns (uint256);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`uint256`|The minimum operators required for a committee|


### pendingCommitteeTimeout

Gets the pending committee timeout


```solidity
function pendingCommitteeTimeout() external view returns (uint256);
```
**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`uint256`|The pending committee timeout|


### getCommitteeDisputeKeys

Gets the dispute keys for all committee members


```solidity
function getCommitteeDisputeKeys(uint128 _committeeId) external view returns (CompactPubKey[] memory);
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The committee ID|

**Returns**

|Name|Type|Description|
|----|----|-----------|
|`<none>`|`CompactPubKey[]`|Array of dispute keys for all members|


### forceDiscardPendingCommittee_TESTNET

Forces a discard of a pending committee, and enables the creation of a new committee

*Only callable on testnet*


```solidity
function forceDiscardPendingCommittee_TESTNET(uint64 _streamId) external;
```
**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_streamId`|`uint64`|The stream ID for the pending committee to discard|


## Events
### NewCommittee
Event emitted when a new committee is created


```solidity
event NewCommittee(uint128 indexed committeeId, Committee _committee);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the newly created committee|
|`_committee`|`Committee`|The committee information|

### NewPendingCommittee
Event emitted when a new pending committee is created


```solidity
event NewPendingCommittee(uint128 indexed committeeId, Committee _committee);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The stream ID for the pending committee|
|`_committee`|`Committee`|The pending committee information|

### PendingCommitteeTimeoutUpdated
Event emitted when pending committee timeout is updated


```solidity
event PendingCommitteeTimeoutUpdated(uint256 timeout);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`timeout`|`uint256`|The new timeout value|

### CommitteeMinWatchtowersUpdated
Event emitted when minimum watchtowers requirement is updated


```solidity
event CommitteeMinWatchtowersUpdated(uint256 minWatchtowers);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`minWatchtowers`|`uint256`|The new minimum watchtowers requirement|

### CommitteeMinOperatorsUpdated
Event emitted when minimum operators requirement is updated


```solidity
event CommitteeMinOperatorsUpdated(uint256 minOperators);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`minOperators`|`uint256`|The new minimum operators requirement|

### CommitteeMemberCountUpdated
Event emitted when minimum members requirement is updated


```solidity
event CommitteeMemberCountUpdated(uint256 minMembers);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`minMembers`|`uint256`|The new minimum members requirement|

### WhitelisterUpdated
Event emitted when the whitelister address is updated


```solidity
event WhitelisterUpdated(address indexed newWhitelister);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`newWhitelister`|`address`|The new whitelister address|

### AddressWhitelisted
Event emitted when an address is whitelisted


```solidity
event AddressWhitelisted(address indexed whitelistedAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`whitelistedAddress`|`address`|The address that is now whitelisted|

### AddressUnwhitelisted
Event emitted when an address is unwhitelisted


```solidity
event AddressUnwhitelisted(address indexed unwhitelistedAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`unwhitelistedAddress`|`address`|The address that is now unwhitelisted|

### MemberInfoDeposited
Event emitted when member info is deposited for committee formation


```solidity
event MemberInfoDeposited(
    uint128 indexed committeeId, address indexed member, bytes takeAggregatedKey, bytes disputeAggregatedKey
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the pending committee|
|`member`|`address`|The member's address|
|`takeAggregatedKey`|`bytes`|The take aggregated key provided by the member|
|`disputeAggregatedKey`|`bytes`|The dispute aggregated key provided by the member|

### NoRemainingHonestOperators
Event emitted when no honest operators remain in a committee


```solidity
event NoRemainingHonestOperators(uint128 committeeId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the committee with no honest operators|

### MemberCommunicationDataDeposited
Event emitted when a member has deposited their communication data

*The communication data are encrypted IP's and Port's for each member in the committee*


```solidity
event MemberCommunicationDataDeposited(
    uint128 indexed _committeeId, address indexed member, CommunicationData[] communicationData
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The ID of the committee for which the member deposited data|
|`member`|`address`|The address of the member who deposited the data|
|`communicationData`|`CommunicationData[]`|The encrypted communication data deposited by the member|

### AllCommunicationDataReady
Event emitted when all committee members have deposited their communication data


```solidity
event AllCommunicationDataReady(uint128 indexed _committeeId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`_committeeId`|`uint128`|The ID of the committee for which all communication data is ready|

### CommitteeMembersReleased
Event emitted when members from a packet's committee are released


```solidity
event CommitteeMembersReleased(uint64 streamId, uint64 packetNumber);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`streamId`|`uint64`|The stream ID for the committee|
|`packetNumber`|`uint64`|The packet number where the committee was active|

### OperatorDemotedToWatchtower
Event emitted when an operator is demoted to watchtower in a committee


```solidity
event OperatorDemotedToWatchtower(uint128 indexed committeeId, address indexed memberAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee where the demotion occurred|
|`memberAddress`|`address`|The address of the demoted member|

### PendingCommitteeForceDiscarded

```solidity
event PendingCommitteeForceDiscarded(uint64 streamId, uint128 committeeId);
```

## Errors
### CommitteeIsNotPending
Thrown when a committee is not in pending state


```solidity
error CommitteeIsNotPending(uint128 committeeId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the committee that is not pending|

### PendingCommitteeNotExpired
Thrown when a pending committee is not expired


```solidity
error PendingCommitteeNotExpired(uint64 streamId, uint256 createdAt, uint256 expireAt);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`streamId`|`uint64`|The stream ID|
|`createdAt`|`uint256`|The creation timestamp|
|`expireAt`|`uint256`|The expiration timestamp|

### NonWhitelistedAddress
Thrown when non-whitelisted address tries to apply to stream


```solidity
error NonWhitelistedAddress(address nonWhitelistedAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`nonWhitelistedAddress`|`address`|The non-whitelisted address|

### UnauthorizedWhitelister
Thrown when the caller is not the whitelister


```solidity
error UnauthorizedWhitelister(address sender);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`sender`|`address`|The address of the caller|

### InvalidAggregatedKeyLength
Error thrown when the aggregated key has an invalid length


```solidity
error InvalidAggregatedKeyLength(uint256 length, uint256 expected);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`length`|`uint256`|The actual length provided|
|`expected`|`uint256`|The expected length (33 bytes)|

### InvalidAggregatedKeyZero
Error thrown when the aggregated key is all zeros


```solidity
error InvalidAggregatedKeyZero();
```

### InvalidSameAggregatedKeys
Error thrown when take and dispute aggregated keys are the same


```solidity
error InvalidSameAggregatedKeys();
```

### MemberNotInCommittee
Thrown when a member is not in the committee


```solidity
error MemberNotInCommittee(uint128 committeeId, address memberAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee ID|
|`memberAddress`|`address`|The member's address|

### MemberInfoAlreadyDeposited
Thrown when member info is already deposited


```solidity
error MemberInfoAlreadyDeposited(uint128 committeeId, address memberAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee ID|
|`memberAddress`|`address`|The member's address|

### CommitteeNotFound
Thrown when a committee is not found


```solidity
error CommitteeNotFound(uint128 committeeId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee ID|

### InvalidZeroValue
Thrown when a value is zero


```solidity
error InvalidZeroValue();
```

### InvalidMinMembers
Thrown when minimum members requirement is invalid


```solidity
error InvalidMinMembers(uint256 minMembers, uint256 minCommitteWatchtowers, uint256 minCommitteOperators);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`minMembers`|`uint256`|The minimum members requirement|
|`minCommitteWatchtowers`|`uint256`|The minimum watchtowers requirement|
|`minCommitteOperators`|`uint256`|The minimum operators requirement|

### InvalidMaxMembers
Thrown when committee member count exceeds the maximum allowed


```solidity
error InvalidMaxMembers(uint256 maxCommitteeMemberCount, uint256 committeeMemberCount);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`maxCommitteeMemberCount`|`uint256`|The maximum allowed committee member count|
|`committeeMemberCount`|`uint256`|The requested committee member count|

### InvalidMinOperators
Thrown when minimum operators requirement is invalid


```solidity
error InvalidMinOperators(uint256 minMembers, uint256 minCommitteWatchtowers, uint256 minCommitteOperators);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`minMembers`|`uint256`|The minimum members requirement|
|`minCommitteWatchtowers`|`uint256`|The minimum watchtowers requirement|
|`minCommitteOperators`|`uint256`|The minimum operators requirement|

### InvalidMinWatchtowers
Thrown when minimum watchtowers requirement is invalid


```solidity
error InvalidMinWatchtowers(uint256 minMembers, uint256 minCommitteWatchtowers, uint256 minCommitteOperators);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`minMembers`|`uint256`|The minimum members requirement|
|`minCommitteWatchtowers`|`uint256`|The minimum watchtowers requirement|
|`minCommitteOperators`|`uint256`|The minimum operators requirement|

### MemberIsInPendingCommittee
Thrown when a member is already in a pending committee


```solidity
error MemberIsInPendingCommittee(address memberAddress, StreamDenomination denomination);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`memberAddress`|`address`|The member's address|
|`denomination`|`StreamDenomination`|The stream denomination|

### TakeOperatorNotFound
Thrown when no eligible operator is found for take operations


```solidity
error TakeOperatorNotFound(uint128 committeeId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the committee where no operator was found|

### InvalidCommunicationDataLength
Thrown when the number of submitted communication data entries does not match the committee size


```solidity
error InvalidCommunicationDataLength(uint256 providedLength, uint256 expectedLength);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`providedLength`|`uint256`|The actual length of the submitted communication data array|
|`expectedLength`|`uint256`|The expected number of entries (i.e., committee size)|

### InvalidZeroCommunicationData
Thrown when a member submits an empty communication data entry for another member


```solidity
error InvalidZeroCommunicationData(uint256 index, CommunicationData communicationData);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`index`|`uint256`|The index of the communication data entry|
|`communicationData`|`CommunicationData`|The invalid communication data submitted|

### InvalidNonZeroCommunicationData
Thrown when a member submits non-zero communication data for their own slot


```solidity
error InvalidNonZeroCommunicationData(uint256 index, CommunicationData communicationData);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`index`|`uint256`|The index in the array corresponding to the submitting member|
|`communicationData`|`CommunicationData`|The non-zero data submitted in the member's own slot|

### MemberAlreadyDepositedCommunicationData
Thrown when a member attempts to deposit communication data more than once


```solidity
error MemberAlreadyDepositedCommunicationData(
    uint128 committeeId, address memberAddress, uint256 communicationDataLenght
);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the committee|
|`memberAddress`|`address`|The address of the member attempting a second deposit|
|`communicationDataLenght`|`uint256`|The number of communication data entries already stored|

### PendingCommitteeExpired
Error when attempting to deposit data in a committee that has already expired


```solidity
error PendingCommitteeExpired(uint128 committeeId, uint256 currentTime, uint256 createdAt, uint256 expireAt);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the committee|
|`currentTime`|`uint256`|Timestamp actual|
|`createdAt`|`uint256`|Timestamp committee creation|
|`expireAt`|`uint256`|Timestamp committee expiration|

### CommitteeIsNotActive
Thrown when trying to demote from a committee that is still pending


```solidity
error CommitteeIsNotActive(uint128 committeeId);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The ID of the pending committee|

### MemberIsNotOperatorInCommittee
Thrown when the member is not an operator in the given committee


```solidity
error MemberIsNotOperatorInCommittee(uint128 committeeId, address memberAddress);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee ID|
|`memberAddress`|`address`|The member's address|

### DemotionViolatesMinOperators
Thrown when demotion would drop the committee below the minimum operator count


```solidity
error DemotionViolatesMinOperators(uint128 committeeId, uint256 currentOperators, uint256 minOperators);
```

**Parameters**

|Name|Type|Description|
|----|----|-----------|
|`committeeId`|`uint128`|The committee ID|
|`currentOperators`|`uint256`|The current number of operators in the committee|
|`minOperators`|`uint256`|The minimum required|

