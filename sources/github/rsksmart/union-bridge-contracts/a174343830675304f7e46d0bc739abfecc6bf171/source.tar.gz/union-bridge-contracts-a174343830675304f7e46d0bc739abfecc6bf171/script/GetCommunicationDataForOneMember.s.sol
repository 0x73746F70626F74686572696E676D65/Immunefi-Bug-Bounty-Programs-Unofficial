// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {console} from "forge-std/console.sol";
import {ScriptUtils} from "script/helpers/ScriptUtils.sol";
import {ContractAddressManager} from "script/helpers/ContractAddressManager.sol";
import {ICommitteeRegistry, CommunicationData} from "src/interfaces/ICommitteeRegistry.sol";

contract GetCommunicationDataForOneMemberScript is ScriptUtils, ContractAddressManager {
    ICommitteeRegistry committeeRegistry;

    bytes committeePubKey;
    uint16 mnemonicIndex;
    uint64 stream;
    uint256 privKey;
    address user;
    bytes32 comPubKey;

    function setUp(uint16 _mnemonicIndex, uint64 _streamIndex) internal {
        committeeRegistry = getCommitteeRegistry();

        // Read args from command line / env
        mnemonicIndex = _mnemonicIndex;
        if (mnemonicIndex > 9) {
            revert("mnemonic index must be between 0 and 9");
        }
        stream = _streamIndex;
        if (stream > 4) {
            revert("stream index must be between 0 and 4");
        }

        privKey = getMemberKey(uint32(mnemonicIndex));
        user = vm.addr(privKey);
    }

    function run(uint16 _mnemonicIndex, uint64 _streamIndex) public {
        setUp(_mnemonicIndex, _streamIndex);

        vm.startBroadcast(privKey);
        uint128 committeeId = committeeRegistry.getPendingCommitteeId(stream);

        CommunicationData[] memory memberComData = committeeRegistry.getMemberCommunicationData(committeeId, user);
        vm.stopBroadcast();

        console.log("=== Got communication data for one member successfully ===");
        console.log("Member Communication Data length:", memberComData.length);

        // console.log("Mnemonic Index:", mnemonicIndex);
        // console.log("User:", user);
        // console.log("Stream:", stream);
        // console.log("Data:");
        // for (uint256 i = 0; i < memberComData.length; i++) {
        //     console.log("Member ", i, ":");
        //     for (uint256 j = 0; j < COMMUNICATION_DATA_CHUNKS; j++) {
        //         console.logBytes32(memberComData[i].data[j]);
        //     }
        // }
    }
}
