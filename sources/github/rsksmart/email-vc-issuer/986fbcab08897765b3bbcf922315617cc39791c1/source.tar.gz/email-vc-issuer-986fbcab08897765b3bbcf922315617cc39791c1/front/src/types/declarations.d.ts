declare module '@rsksmart/rlogin'
