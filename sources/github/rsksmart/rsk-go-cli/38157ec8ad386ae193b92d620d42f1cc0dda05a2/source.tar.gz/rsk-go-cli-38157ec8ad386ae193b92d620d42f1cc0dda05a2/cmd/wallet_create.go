package cmd

import (
	"bufio"
	"fmt"
	"log"
	"os"

	"github.com/rsksmart/rsk-go-cli/pkg/constants"
	"github.com/rsksmart/rsk-go-cli/pkg/walletmeta"

	"github.com/ethereum/go-ethereum/accounts"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

// displayPrivateKey displays the private key for the given account
func displayPrivateKey(account *accounts.Account, password string) error {
	keyJSON, err := os.ReadFile(account.URL.Path)
	if err != nil {
		return fmt.Errorf("failed to read keystore file: %w", err)
	}

	key, err := keystore.DecryptKey(keyJSON, password)
	if err != nil {
		return fmt.Errorf("failed to decrypt keystore file: %w", err)
	}

	if key.PrivateKey == nil || key.PrivateKey.D == nil {
		return fmt.Errorf("failed to extract private key from keystore")
	}

	fmt.Println("Private Key in hex: ", "0x"+fmt.Sprintf("%x", key.PrivateKey.D.Bytes()))
	return nil
}

var showPrivateKey bool

var walletCreateCmd = &cobra.Command{
	Use:   "create",
	Short: "Create a new wallet",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Creating new wallet...")
		reader := bufio.NewReader(os.Stdin)

		// 1. Password input and validation with confirmation
		password, err := utils.ReadNewPassword("Enter a password to encrypt your wallet: ")
		if err != nil {
			log.Fatal("Password input failed: ", err)
		}

		// 2. Validate and create wallet directory
		walletDir := constants.KeystoreDir
		if err := utils.ValidateAndCreateDirectory(walletDir); err != nil {
			log.Fatal("Directory validation failed: ", err)
		}

		// 3. Create keystore
		ks := keystore.NewKeyStore(walletDir, keystore.StandardScryptN, keystore.StandardScryptP)
		if ks == nil {
			log.Fatal("Failed to initialize keystore")
		}

		// 4. Create new account
		account, err := ks.NewAccount(password)
		if err != nil {
			log.Fatal("Failed to create wallet: ", err)
		}

		// 5. Validate account creation
		if account.Address.Hex() == "" {
			log.Fatal("Failed to create wallet: generated address is empty")
		}

		fmt.Println("New wallet created: ", account.Address.Hex())
		fmt.Println("Keystore file: ", account.URL.Path)

		// 6. Wallet naming with validation
		fmt.Print("Enter a name for this wallet (optional): ")
		name, err := reader.ReadString('\n')
		if err != nil {
			log.Fatal("Failed to read wallet name: ", err)
		}
		name = name[:len(name)-1] // Remove newline character

		// Validate and set wallet name
		if name != "" {
			if err := utils.ValidateWalletName(name); err != nil {
				log.Fatal("Wallet name validation failed: ", err)
			}

			// Check for duplicate names
			if err := utils.CheckDuplicateWalletName(name); err != nil {
				log.Fatal("Duplicate name check failed: ", err)
			}

			err := walletmeta.SetName(account.Address.Hex(), name)
			if err != nil {
				log.Fatal("Failed to set wallet name: ", err)
			}
			fmt.Println("Wallet name set to: ", name)
		} else {
			fmt.Println("No name provided for the wallet.")
		}

		fmt.Println("Wallet created successfully!")

		// 7. Private key display (if requested)
		if showPrivateKey {
			if err := displayPrivateKey(&account, password); err != nil {
				log.Fatal("Failed to display private key: ", err)
			}
		}
	},
}

func init() {
	walletCreateCmd.Flags().BoolVarP(&showPrivateKey, "show-private-key", "p", false, "Display the private key after wallet creation (use with caution)")
	walletCmd.AddCommand(walletCreateCmd)
}
