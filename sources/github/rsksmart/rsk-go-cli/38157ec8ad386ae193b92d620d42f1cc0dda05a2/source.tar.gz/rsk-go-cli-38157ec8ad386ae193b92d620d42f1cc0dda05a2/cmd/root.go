/*
Copyright © 2025 Rootstock Labs
*/
package cmd

import (
	"fmt"
	"log"
	"os"

	"github.com/rsksmart/rsk-go-cli/internal/version"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "rsk-go-cli",
	Short: "A command-line interface (CLI) tool for interacting with the Rootstock (RSK) blockchain.",
	Long: `A command-line interface (CLI) tool for interacting with the Rootstock (RSK) blockchain.
This tool allows users to manage wallets, send transactions, interact with smart contracts, 
and perform various blockchain operations on the RSK network.
`,
	CompletionOptions: cobra.CompletionOptions{
		DisableDefaultCmd: true,
	},
	Version: version.Version,
	PersistentPreRun: func(cmd *cobra.Command, args []string) {
		// Validate environment variables before any command runs
		if err := validateEnvironmentAtStartup(); err != nil {
			log.Fatal(err)
		}
	},
}

// validateEnvironmentAtStartup validates all required environment variables
func validateEnvironmentAtStartup() error {
	// Skip validation for help and version commands
	if len(os.Args) > 1 {
		arg := os.Args[1]
		if arg == "help" || arg == "--help" || arg == "-h" || arg == "version" || arg == "--version" || arg == "-v" {
			return nil
		}
	}

	// Validate environment
	config, err := utils.ValidateEnvironment()
	if err != nil {
		return fmt.Errorf("environment validation failed:\n%s", err)
	}

	// Log successful validation (optional, for debugging)
	if os.Getenv("DEBUG") == "true" {
		fmt.Printf("✅ Environment validated successfully\n")
		fmt.Printf("   RPC_URL: %s\n", config.RPCURL)
	}

	return nil
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the rootCmd.
func Execute() {
	err := rootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}

func init() {
	// Here you will define your flags and configuration settings.
	// Cobra supports persistent flags, which, if defined here,
	// will be global for your application.

	// rootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file (default is $HOME/.rsk-go-cli.yaml)")

	// Cobra also supports local flags, which will only run
	// when this action is called directly.
	rootCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
