package cmd

import (
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

var environmentCmd = &cobra.Command{
	Use:   "env",
	Short: "Show environment configuration and help",
	Long: `Show the current environment configuration and provide help for setting up required environment variables.

This command displays:
- Current environment variable values
- Missing required variables
- Help for setting up environment variables
- Validation status`,
	Run: func(cmd *cobra.Command, args []string) {
		// Print environment help and status
		utils.PrintEnvironmentHelp()

		// Check if environment is valid
		if utils.IsEnvironmentValid() {
			cmd.Println("✅ Environment is properly configured!")
		} else {
			cmd.Println("❌ Environment is not properly configured.")
			cmd.Println("Please fix the issues above and try again.")
		}
	},
}

func init() {
	rootCmd.AddCommand(environmentCmd)
}
