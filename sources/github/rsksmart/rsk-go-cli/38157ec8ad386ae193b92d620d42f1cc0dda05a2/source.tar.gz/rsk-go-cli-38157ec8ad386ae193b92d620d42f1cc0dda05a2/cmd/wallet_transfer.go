package cmd

import (
	"context"
	"fmt"
	"log"
	"math/big"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/rsksmart/rsk-go-cli/pkg/constants"
	"github.com/rsksmart/rsk-go-cli/pkg/keystoreutil"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

var fromAddr string
var fromName string
var toAddr string
var toName string
var transferAmount float64
var gasLimit uint64
var gasPriceGwei float64

var walletTransferCmd = &cobra.Command{
	Use:   "transfer",
	Short: "Transfer RBTC from one wallet to another",
	Run: func(cmd *cobra.Command, args []string) {

		resolvedFrom, err := utils.ResolveInputAddress(fromAddr, fromName)
		if err != nil {
			log.Fatal("Failed to resolve source address: ", err)
		}

		resolvedTo, err := utils.ResolveInputAddress(toAddr, toName)
		if err != nil {
			log.Fatal("Failed to resolve destination address: ", err)
		}

		if resolvedFrom == resolvedTo {
			log.Fatal("Source and destination addresses cannot be the same.")
		}

		if err := utils.ValidateTransferAmount(transferAmount); err != nil {
			log.Fatal(err)
		}

		if err := utils.ValidateGasPrice(gasPriceGwei); err != nil {
			log.Fatal(err)
		}

		if err := utils.ValidateGasLimit(gasLimit); err != nil {
			log.Fatal(err)
		}

		keystorePath, err := keystoreutil.FindKeystoreFile(constants.KeystoreDir, resolvedFrom)
		if err != nil {
			log.Fatalf("No keystore file found for address %s: %v", resolvedFrom, err)
		}

		password, err := utils.ReadPassword(("Enter the password to unlock the wallet: "))
		if err != nil {
			log.Fatalf("Failed to read password: %v", err)
		}
		if password == "" {
			log.Fatal("Password cannot be empty.")
		}

		key, err := keystoreutil.DecryptKeyFromFile(keystorePath, password)
		if err != nil {
			log.Fatalf("Failed to decrypt wallet: %v", err)
		}

		fmt.Printf("Transferring %.18f RBTC from %s to %s with gas limit %d and gas price %g Gwei\n",
			transferAmount, key.Address.Hex(), resolvedTo, gasLimit, gasPriceGwei)

		rpcURL := utils.GetRPCURL()
		client, err := ethclient.Dial(rpcURL)
		if err != nil {
			log.Fatalf("Failed to connect to RSK node: %v", err)
		}
		defer client.Close()

		balance, err := client.BalanceAt(context.Background(), key.Address, nil)
		if err != nil {
			log.Fatalf("Failed to get wallet balance: %v", err)
		}

		amountWei := utils.RBTCToWei(transferAmount)

		balanceInRBTC := utils.WeiToRBTC(balance)
		fmt.Printf("Balance: %s RBTC\n", balanceInRBTC.Text('f', 18))

		amountInRBTC := utils.WeiToRBTC(amountWei)
		fmt.Printf("Amount: %s RBTC\n", amountInRBTC.Text('f', 18))

		ctx := context.Background()

		var actualGasLimit uint64
		if gasLimit == 0 {
			actualGasLimit = 21000
		} else {
			actualGasLimit = gasLimit
		}

		var gasPrice *big.Int
		if gasPriceGwei > 0 {
			gasPrice = big.NewInt(int64(gasPriceGwei * 1e9))
		} else {
			gasPrice, err = client.SuggestGasPrice(ctx)
			if err != nil {
				log.Fatalf("Failed to suggest gas price: %v", err)
			}
		}

		estimatedGasCost := new(big.Int).Mul(gasPrice, big.NewInt(int64(actualGasLimit)))
		estimatedGasCostInRBTC := utils.WeiToRBTC(estimatedGasCost)
		fmt.Printf("Estimated gas cost: %s RBTC\n", estimatedGasCostInRBTC.Text('f', 18))

		totalCost := new(big.Int).Add(amountWei, estimatedGasCost)
		totalCostInRBTC := utils.WeiToRBTC(totalCost)
		fmt.Printf("Total cost: %s RBTC\n", totalCostInRBTC.Text('f', 18))

		if balance.Cmp(totalCost) < 0 {
			log.Fatalf("Insufficient balance. Required: %s wei, Available: %s wei", totalCost.String(), balance.String())
		}

		nonce, err := client.PendingNonceAt(ctx, key.Address)
		if err != nil {
			log.Fatalf("Failed to get nonce: %v", err)
		}

		tx := types.NewTransaction(
			nonce,
			common.HexToAddress(resolvedTo),
			amountWei,
			actualGasLimit,
			gasPrice,
			nil)

		chainID, err := client.ChainID(ctx)
		if err != nil {
			log.Fatalf("Failed to get chain ID: %v", err)
		}

		signedTx, err := types.SignTx(tx, types.NewEIP155Signer(chainID), key.PrivateKey)
		if err != nil {
			log.Fatalf("Failed to sign transaction: %v", err)
		}

		err = client.SendTransaction(ctx, signedTx)
		if err != nil {
			log.Fatalf("Failed to send transaction: %v", err)
		}
		fmt.Printf("Transaction sent successfully! Tx Hash: %s\n", signedTx.Hash().Hex())
	},
}

func init() {
	walletTransferCmd.Flags().StringVarP(&fromAddr, "from-address", "f", "", "Wallet address to transfer from")
	walletTransferCmd.Flags().StringVarP(&fromName, "from-name", "n", "", "Wallet address name to transfer from")
	walletTransferCmd.Flags().StringVarP(&toAddr, "to-address", "t", "", "Wallet address to transfer to (required)")
	walletTransferCmd.Flags().StringVarP(&toName, "to-name", "m", "", "Wallet address name to transfer to")
	walletTransferCmd.Flags().Float64Var(&transferAmount, "amount", 0, "Amount to send in RBTC (required)")
	walletTransferCmd.Flags().Uint64VarP(&gasLimit, "gas-limit", "g", 21000, "Optional gas limit (default 21000)")
	walletTransferCmd.Flags().Float64Var(&gasPriceGwei, "gas-price", 0, "Gas price in Gwei (optional)")

	if err := walletTransferCmd.MarkFlagRequired("amount"); err != nil {
		log.Fatalf("Failed to mark amount flag as required: %v", err)
	}

	rootCmd.AddCommand(walletTransferCmd)
}
