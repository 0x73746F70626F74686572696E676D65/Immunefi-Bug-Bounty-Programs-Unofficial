package cmd

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"

	"github.com/rsksmart/rsk-go-cli/pkg/constants"
	"github.com/rsksmart/rsk-go-cli/pkg/keystoreutil"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

var exportAddr string
var exportName string
var exportAsJSON bool

var walletExportCmd = &cobra.Command{
	Use:   "export",
	Short: "Export a wallet's private key as plain text or JSON format printed to the console",
	Run: func(cmd *cobra.Command, args []string) {

		address, err := utils.ResolveInputAddress(exportAddr, exportName)
		if err != nil {
			log.Fatal("Failed to resolve address: ", err)
		}

		// 6. Find and validate keystore file
		keystorePath, err := keystoreutil.FindKeystoreFile(constants.KeystoreDir, address)
		if err != nil {
			log.Fatalf("No keystore file found for address %s: %v", address, err)
		}

		// 7. Validate keystore file exists and is readable
		if err := utils.ValidateKeystoreFile(keystorePath); err != nil {
			log.Fatalf("Keystore file validation failed: %v", err)
		}

		// 8. Password input and validation
		password, err := utils.ReadPassword("Enter the password to unlock the wallet: ")
		if err != nil {
			log.Fatalf("Failed to read password: %v", err)
		}
		if password == "" {
			log.Fatal("Password cannot be empty.")
		}

		// 9. Decrypt and validate private key
		key, err := keystoreutil.DecryptKeyFromFile(keystorePath, password)
		if err != nil {
			log.Fatal("Failed to decrypt wallet: ", err)
		}

		// 10. Validate decrypted key
		if key == nil || key.PrivateKey == nil || key.PrivateKey.D == nil {
			log.Fatal("Failed to extract private key from wallet.")
		}

		// 11. Security warning for private key export
		fmt.Println("⚠️  WARNING: You are about to export a private key!")
		fmt.Println("   Keep this information secure and never share it with anyone.")
		fmt.Println("   Anyone with access to this private key can control your wallet.")
		fmt.Println()

		privateKeyHex := "0x" + hex.EncodeToString(key.PrivateKey.D.Bytes())

		// 12. Export in requested format with validation
		if exportAsJSON {
			output := map[string]string{
				"address":    key.Address.Hex(),
				"privateKey": privateKeyHex,
			}

			jsonBytes, err := json.MarshalIndent(output, "", "  ")
			if err != nil {
				log.Fatalf("Failed to generate JSON output: %v", err)
			}

			fmt.Println(string(jsonBytes))
		} else {
			fmt.Printf("Private key for address %s: %s\n", address, privateKeyHex)
		}

		fmt.Println("\n✅ Wallet exported successfully!")
		fmt.Println("🔒 Remember to keep your private key secure!")
	},
}

func init() {
	walletCmd.AddCommand(walletExportCmd)

	walletExportCmd.Flags().StringVarP(&exportAddr, "address", "a", "", "The address of the wallet to export (required if --name not provided)")
	walletExportCmd.Flags().StringVarP(&exportName, "name", "n", "", "The name of the wallet to export (required if --address not provided)")
	walletExportCmd.Flags().BoolVarP(&exportAsJSON, "json", "j", false, "Export the wallet as JSON format instead of plain text")

}
