package cmd

import (
	"fmt"
	"log"

	"github.com/rsksmart/rsk-go-cli/pkg/rsk"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

var balanceAddr string
var balanceName string

var walletBalanceCmd = &cobra.Command{
	Use:   "balance",
	Short: "Check the RBTC balance of a wallet",
	Run: func(cmd *cobra.Command, args []string) {

		address, err := utils.ResolveInputAddress(balanceAddr, balanceName)
		if err != nil {
			log.Fatal("Failed to resolve address: ", err)
		}

		fmt.Printf("Checking balance for address: %s\n", address)

		balance, err := rsk.GetBalance(address)
		if err != nil {
			log.Fatalf("Failed to get balance for address %s: %v", address, err)
		}

		if balance == nil {
			log.Fatal("Received nil balance from network. Please try again.")
		}

		balanceInRBTC := utils.WeiToRBTC(balance)

		fmt.Printf("Balance for address %s: %s RBTC\n", address, balanceInRBTC.Text('f', 18))
	},
}

func init() {
	walletBalanceCmd.Flags().StringVarP(&balanceAddr, "address", "a", "", "Wallet address to check balance (required if --name not provided)")
	walletBalanceCmd.Flags().StringVarP(&balanceName, "name", "n", "", "Wallet name to check balance (required if --address not provided)")

	walletCmd.AddCommand(walletBalanceCmd)
}
