package cmd

import (
	"bufio"
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"strings"

	"github.com/rsksmart/rsk-go-cli/pkg/constants"
	"github.com/rsksmart/rsk-go-cli/pkg/keystoreutil"
	"github.com/rsksmart/rsk-go-cli/pkg/walletmeta"

	"github.com/ethereum/go-ethereum/accounts/keystore"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/spf13/cobra"
)

// checkDuplicateAddress checks if a wallet address already exists
func checkDuplicateAddress(address string) error {
	// Check if keystore file already exists for this address
	keystorePath, err := keystoreutil.FindKeystoreFile(constants.KeystoreDir, address)
	if err == nil && keystorePath != "" {
		return fmt.Errorf("wallet with address %s already exists", address)
	}

	return nil
}

var walletImportCmd = &cobra.Command{
	Use:   "import",
	Short: "Import a wallet from an existing private key",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Importing wallet...")

		fmt.Println("⚠️  SECURITY WARNING:")
		fmt.Println("   Private keys are sensitive information. Never share them with anyone.")
		fmt.Println("   The private key will be entered securely and will not be displayed on screen.")
		fmt.Println()

		privateKeyHex, err := utils.ReadPrivateKey("Enter your private key (64 hex characters): ")
		if err != nil {
			log.Fatalf("Failed to read private key: %v", err)
		}

		// Validate private key is not empty
		if privateKeyHex == "" {
			log.Fatal("Private key cannot be empty")
		}

		// Validate private key format and security
		if err := utils.ValidatePrivateKey(privateKeyHex); err != nil {
			log.Fatalf("Private key validation failed: %v", err)
		}

		// Decode and validate private key bytes
		privateKeyBytes, err := hex.DecodeString(strings.TrimPrefix(privateKeyHex, "0x"))
		if err != nil {
			log.Fatalf("Invalid private key format: %v", err)
		}

		// Validate private key length
		if len(privateKeyBytes) != 32 {
			log.Fatalf("Invalid private key length: expected 32 bytes, got %d bytes", len(privateKeyBytes))
		}

		// Convert to ECDSA key and validate
		privateKey, err := crypto.ToECDSA(privateKeyBytes)
		if err != nil {
			log.Fatalf("Invalid private key: %v", err)
		}

		// Validate private key is not zero or weak
		if err := utils.ValidatePrivateKeyStrength(privateKeyBytes); err != nil {
			log.Fatalf("Private key security validation failed: %v", err)
		}

		// Generate address and check for duplicates
		address := crypto.PubkeyToAddress(privateKey.PublicKey)
		if err := checkDuplicateAddress(address.Hex()); err != nil {
			log.Fatalf("Duplicate address check failed: %v", err)
		}

		// Password input and validation
		password, err := utils.ReadNewPassword("Enter a password to encrypt your wallet: ")
		if err != nil {
			log.Fatal("Password input failed: ", err)
		}

		// Validate and create wallet directory
		walletDir := constants.KeystoreDir
		if err := utils.ValidateAndCreateDirectory(walletDir); err != nil {
			log.Fatalf("Directory validation failed: %v", err)
		}

		// Create keystore and import wallet
		ks := keystore.NewKeyStore(walletDir, keystore.StandardScryptN, keystore.StandardScryptP)
		if ks == nil {
			log.Fatal("Failed to initialize keystore")
		}

		account, err := ks.ImportECDSA(privateKey, password)
		if err != nil {
			log.Fatalf("Failed to import private key: %v", err)
		}

		// Validate account creation
		if account.Address.Hex() == "" {
			log.Fatal("Failed to import wallet: generated address is empty")
		}

		// Wallet naming with validation
		fmt.Print("Enter a name for this wallet (optional): ")
		reader := bufio.NewReader(os.Stdin)
		name, err := reader.ReadString('\n')
		if err != nil {
			log.Fatalf("Failed to read wallet name: %v", err)
		}
		name = name[:len(name)-1] // Remove newline character

		// Validate and set wallet name
		if name != "" {
			if err := utils.ValidateWalletName(name); err != nil {
				log.Fatalf("Wallet name validation failed: %v", err)
			}

			// Check for duplicate names
			if err := utils.CheckDuplicateWalletName(name); err != nil {
				log.Fatalf("Duplicate name check failed: %v", err)
			}

			err := walletmeta.SetName(account.Address.Hex(), name)
			if err != nil {
				log.Fatalf("Failed to set wallet name: %v", err)
			}
			fmt.Println("Wallet name set to: ", name)
		} else {
			fmt.Println("No name provided for the wallet.")
		}

		fmt.Println("✅ Wallet imported successfully: ", account.Address.Hex())
		fmt.Println("🔒 Remember to keep your private key secure!")
	},
}

func init() {
	walletCmd.AddCommand(walletImportCmd)
}
