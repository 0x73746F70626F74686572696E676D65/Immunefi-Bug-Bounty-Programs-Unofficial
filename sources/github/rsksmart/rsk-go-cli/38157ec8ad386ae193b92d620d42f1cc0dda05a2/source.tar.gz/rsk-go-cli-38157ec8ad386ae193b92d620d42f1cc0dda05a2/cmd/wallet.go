package cmd

import "github.com/spf13/cobra"

var walletCmd = &cobra.Command{
	Use:   "wallet",
	Short: "Manage wallets",
}

func init() {
	rootCmd.AddCommand(walletCmd)
}
