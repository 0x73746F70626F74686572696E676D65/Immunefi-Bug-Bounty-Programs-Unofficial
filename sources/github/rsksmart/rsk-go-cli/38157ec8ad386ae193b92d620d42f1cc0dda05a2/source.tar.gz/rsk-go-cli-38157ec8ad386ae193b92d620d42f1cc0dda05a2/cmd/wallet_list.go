package cmd

import (
	"fmt"
	"log"
	"os"

	"github.com/ethereum/go-ethereum/accounts/keystore"
	"github.com/rsksmart/rsk-go-cli/pkg/constants"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
	"github.com/rsksmart/rsk-go-cli/pkg/walletmeta"
	"github.com/spf13/cobra"
)

var walletListCmd = &cobra.Command{
	Use:   "list",
	Short: "List all wallets",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Listing wallets...")

		// 1. Validate wallet directory path
		walletDir := constants.KeystoreDir
		if walletDir == "" {
			log.Fatal("Wallet directory path is not configured")
		}

		// 2. Validate and check directory access
		if err := utils.ValidateDirectoryAccess(walletDir); err != nil {
			log.Fatalf("Wallet directory validation failed: %v", err)
		}

		// 3. Check if directory exists
		if _, err := os.Stat(walletDir); os.IsNotExist(err) {
			fmt.Println("No wallets found - wallet directory does not exist")
			return
		}

		// 4. Initialize keystore with validation
		ks := keystore.NewKeyStore(walletDir, keystore.StandardScryptN, keystore.StandardScryptP)
		if ks == nil {
			log.Fatal("Failed to initialize keystore")
		}

		// 5. Get accounts with basic validation
		accounts := ks.Accounts()
		if len(accounts) == 0 {
			fmt.Println("No wallets found")
			return
		}

		// 6. Load wallet metadata with error handling
		names, err := walletmeta.GetAllNames()
		if err != nil {
			log.Printf("Warning: Failed to load wallet names: %v", err)
			log.Println("Continuing with address-only display...")
			names = make(map[string]string)
		}

		// 7. Display wallets with basic validation
		fmt.Printf("Found %d wallet(s):\n", len(accounts))
		validCount := 0
		for i, account := range accounts {
			// Basic validation - check if account has valid address
			if account.Address.Hex() == "" {
				log.Printf("Warning: Skipping invalid account at index %d", i)
				continue
			}

			name := names[account.Address.Hex()]
			if name != "" {
				fmt.Printf("%d. %s (%s)\n", i+1, account.Address.Hex(), name)
			} else {
				fmt.Printf("%d. %s\n", i+1, account.Address.Hex())
			}
			validCount++
		}

		if validCount > 0 {
			fmt.Printf("\n✅ Successfully listed %d wallet(s)\n", validCount)
		} else {
			fmt.Println("\n⚠️  No valid wallets found")
		}
	},
}

func init() {
	walletCmd.AddCommand(walletListCmd)
}
