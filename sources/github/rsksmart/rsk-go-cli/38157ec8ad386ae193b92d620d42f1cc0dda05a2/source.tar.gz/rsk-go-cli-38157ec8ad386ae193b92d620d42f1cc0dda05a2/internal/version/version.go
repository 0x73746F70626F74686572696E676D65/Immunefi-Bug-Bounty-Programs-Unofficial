package version

var (
	Version = "0.1.2"
)
