package constants

import (
	"os"
	"path/filepath"
)

// KeystoreDir is the default directory for wallet keystores.
var KeystoreDir = filepath.Join(os.Getenv("HOME"), ".rsk-go-cli", "wallets")
