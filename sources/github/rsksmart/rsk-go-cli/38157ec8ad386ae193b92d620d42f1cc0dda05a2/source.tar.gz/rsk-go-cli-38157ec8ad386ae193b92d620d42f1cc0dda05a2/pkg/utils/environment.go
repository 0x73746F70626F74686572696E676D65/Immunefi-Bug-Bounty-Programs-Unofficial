package utils

import (
	"fmt"
	"os"
	"strings"
)

// EnvironmentConfig holds all required environment variables
type EnvironmentConfig struct {
	RPCURL string
}

// RequiredEnvironmentVariables defines all required environment variables
var RequiredEnvironmentVariables = map[string]string{
	"RPC_URL": "Rootstock RPC endpoint (e.g., https://public-node.testnet.rsk.co)",
}

// ValidateEnvironment validates all required environment variables at startup
func ValidateEnvironment() (*EnvironmentConfig, error) {
	var config EnvironmentConfig
	var missingVars []string
	var invalidVars []string

	// Check for required environment variables
	for envVar, description := range RequiredEnvironmentVariables {
		value := os.Getenv(envVar)
		if value == "" {
			missingVars = append(missingVars, fmt.Sprintf("%s: %s", envVar, description))
		} else {
			// Validate specific environment variables
			if err := validateEnvironmentVariable(envVar, value); err != nil {
				invalidVars = append(invalidVars, fmt.Sprintf("%s: %s", envVar, err.Error()))
			}
		}
	}

	// Set config values for valid variables
	if rpcURL := os.Getenv("RPC_URL"); rpcURL != "" {
		config.RPCURL = rpcURL
	}

	// Return comprehensive error if any validation failed
	if len(missingVars) > 0 || len(invalidVars) > 0 {
		var errorMsgs []string

		if len(missingVars) > 0 {
			errorMsgs = append(errorMsgs, "Missing required environment variables:")
			errorMsgs = append(errorMsgs, missingVars...)
		}

		if len(invalidVars) > 0 {
			errorMsgs = append(errorMsgs, "Invalid environment variables:")
			errorMsgs = append(errorMsgs, invalidVars...)
		}

		errorMsgs = append(errorMsgs, "")
		errorMsgs = append(errorMsgs, "Please create a .env file in your project root with the required variables:")
		errorMsgs = append(errorMsgs, "Example .env file:")
		errorMsgs = append(errorMsgs, "RPC_URL=https://public-node.testnet.rsk.co")

		return nil, fmt.Errorf("environment validation failed:\n%s", strings.Join(errorMsgs, "\n"))
	}

	return &config, nil
}

// validateEnvironmentVariable validates specific environment variable values
func validateEnvironmentVariable(name, value string) error {
	switch name {
	case "RPC_URL":
		return validateRPCURL(value)
	default:
		return nil // No specific validation for this variable
	}
}

// validateRPCURL validates the RPC URL format
func validateRPCURL(url string) error {
	if url == "" {
		return fmt.Errorf("RPC URL cannot be empty")
	}

	// Basic URL format validation
	if !strings.HasPrefix(url, "http://") && !strings.HasPrefix(url, "https://") {
		return fmt.Errorf("RPC URL must start with http:// or https://")
	}

	// Check for common Rootstock endpoints
	validDomains := []string{
		"rsk.co",
		"rootstock.io",
		"testnet.rsk.co",
		"public-node.rsk.co",
		"public-node.testnet.rsk.co",
	}

	urlLower := strings.ToLower(url)
	hasValidDomain := false
	for _, domain := range validDomains {
		if strings.Contains(urlLower, domain) {
			hasValidDomain = true
			break
		}
	}

	if !hasValidDomain {
		return fmt.Errorf("RPC URL should point to a valid Rootstock endpoint")
	}

	return nil
}

// GetRPCURL safely gets the RPC URL from environment
func GetRPCURL() string {
	return os.Getenv("RPC_URL")
}

// IsEnvironmentValid checks if all required environment variables are set
func IsEnvironmentValid() bool {
	_, err := ValidateEnvironment()
	return err == nil
}

// PrintEnvironmentHelp prints helpful information about environment setup
func PrintEnvironmentHelp() {
	fmt.Println("Environment Setup Help:")
	fmt.Println("=======================")
	fmt.Println()

	for envVar, description := range RequiredEnvironmentVariables {
		currentValue := os.Getenv(envVar)
		if currentValue == "" {
			fmt.Printf("❌ %s: %s (NOT SET)\n", envVar, description)
		} else {
			fmt.Printf("✅ %s: %s\n", envVar, description)
			fmt.Printf("   Current value: %s\n", currentValue)
		}
		fmt.Println()
	}

	fmt.Println("To set environment variables:")
	fmt.Println("1. Create a .env file in your project root")
	fmt.Println("2. Add the required variables:")
	fmt.Println("   RPC_URL=https://public-node.testnet.rsk.co")
	fmt.Println("3. Or set them in your shell:")
	fmt.Println("   export RPC_URL=https://public-node.testnet.rsk.co")
	fmt.Println()
}
