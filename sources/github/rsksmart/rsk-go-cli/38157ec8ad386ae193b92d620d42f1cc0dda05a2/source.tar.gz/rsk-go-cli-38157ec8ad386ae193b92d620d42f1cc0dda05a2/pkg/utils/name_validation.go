package utils

import (
	"fmt"
	"regexp"
	"strings"

	"github.com/rsksmart/rsk-go-cli/pkg/walletmeta"
)

func ValidateWalletName(name string) error {
	if len(name) < 1 {
		return fmt.Errorf("wallet name cannot be empty")
	}
	if len(name) > 50 {
		return fmt.Errorf("wallet name must be less than 50 characters")
	}

	validNameRegex := regexp.MustCompile(`^[a-zA-Z0-9\s\-_]+$`)
	if !validNameRegex.MatchString(name) {
		return fmt.Errorf("wallet name contains invalid characters. Use only letters, numbers, spaces, hyphens, and underscores")
	}

	if strings.TrimSpace(name) != name {
		return fmt.Errorf("wallet name cannot start or end with whitespace")
	}

	return nil
}

func CheckDuplicateWalletName(name string) error {
	names, err := walletmeta.GetAllNames()
	if err != nil {
		return fmt.Errorf("failed to check for duplicate names: %w", err)
	}

	for _, existingName := range names {
		if strings.EqualFold(existingName, name) {
			return fmt.Errorf("wallet name '%s' already exists", name)
		}
	}

	return nil
}
