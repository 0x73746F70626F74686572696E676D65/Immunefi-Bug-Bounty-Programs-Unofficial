package walletmeta

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/rsksmart/rsk-go-cli/pkg/constants"
)

var indexPath = filepath.Join(constants.KeystoreDir, "index.json")

func loadIndex() (map[string]string, error) {
	index := map[string]string{}

	data, err := os.ReadFile(indexPath)
	if err == nil {
		err = json.Unmarshal(data, &index)
	}

	if os.IsNotExist(err) || len(index) == 0 {
		return map[string]string{}, nil
	}

	return index, err
}

func saveIndex(index map[string]string) error {
	data, err := json.MarshalIndent(index, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal index: %w", err)
	}
	return os.WriteFile(indexPath, data, 0600)
}

func SetName(address string, name string) error {
	index, err := loadIndex()
	if err != nil {
		return fmt.Errorf("failed to load index: %w", err)
	}
	index[address] = name
	return saveIndex(index)
}

func GetName(address string) (string, error) {
	index, err := loadIndex()
	if err != nil {
		return "", fmt.Errorf("failed to load index: %w", err)
	}

	name, ok := index[address]
	if !ok {
		return "", fmt.Errorf("no name found for address %s", address)
	}

	return name, nil
}

func GetAllNames() (map[string]string, error) {
	index, err := loadIndex()
	if err != nil {
		return nil, fmt.Errorf("failed to load index: %w", err)
	}
	return index, nil
}
