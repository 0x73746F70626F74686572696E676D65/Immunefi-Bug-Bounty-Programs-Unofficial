package utils

import (
	"encoding/hex"
	"fmt"
	"math/big"
	"os"
	"strings"

	"github.com/ethereum/go-ethereum/crypto"
)

// ============================================================================
// DIRECTORY VALIDATION
// ============================================================================

// ValidateAndCreateDirectory validates and creates the directory with proper permissions
func ValidateAndCreateDirectory(dir string) error {
	if dir == "" {
		return fmt.Errorf("directory path is empty")
	}

	// Check if directory exists and has proper permissions
	if info, err := os.Stat(dir); err == nil {
		if !info.IsDir() {
			return fmt.Errorf("path exists but is not a directory: %s", dir)
		}
		// Check if directory is writable
		if info.Mode().Perm()&0200 == 0 {
			return fmt.Errorf("directory is not writable: %s", dir)
		}
	}

	// Create directory with proper permissions
	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("failed to create directory %s: %w", dir, err)
	}

	return nil
}

// ValidateDirectoryAccess validates directory permissions and access
func ValidateDirectoryAccess(dir string) error {
	if dir == "" {
		return fmt.Errorf("directory path is empty")
	}

	info, err := os.Stat(dir)
	if err != nil {
		return fmt.Errorf("failed to access directory: %w", err)
	}

	if !info.IsDir() {
		return fmt.Errorf("path is not a directory: %s", dir)
	}

	// Check if directory is readable
	if info.Mode().Perm()&0400 == 0 {
		return fmt.Errorf("directory is not readable: %s", dir)
	}

	return nil
}

// ============================================================================
// KEYSTORE FILE VALIDATION
// ============================================================================

// ValidateKeystoreFile validates that the keystore file exists and is readable
func ValidateKeystoreFile(filePath string) error {
	// Check if file exists
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return fmt.Errorf("keystore file does not exist: %s", filePath)
	}

	// Check if file is readable
	file, err := os.Open(filePath)
	if err != nil {
		return fmt.Errorf("keystore file is not readable: %w", err)
	}
	defer file.Close()

	// Check file permissions (should be 0600 for security)
	info, err := file.Stat()
	if err != nil {
		return fmt.Errorf("failed to get file info: %w", err)
	}

	// Check if file is readable by owner only
	if info.Mode().Perm() != 0600 {
		return fmt.Errorf("keystore file has insecure permissions: %s", info.Mode().Perm())
	}

	return nil
}

// ============================================================================
// PRIVATE KEY VALIDATION
// ============================================================================

// ValidatePrivateKey validates the private key format and basic security
func ValidatePrivateKey(privateKeyHex string) error {
	// Remove 0x prefix if present
	cleanKey := strings.TrimPrefix(privateKeyHex, "0x")

	// Check if it's a valid hex string
	if len(cleanKey) != 64 {
		return fmt.Errorf("private key must be exactly 64 hex characters (32 bytes)")
	}

	// Validate hex format
	if _, err := hex.DecodeString(cleanKey); err != nil {
		return fmt.Errorf("private key must be a valid hexadecimal string")
	}

	// Check for all zeros (extremely weak key)
	if cleanKey == strings.Repeat("0", 64) {
		return fmt.Errorf("private key cannot be all zeros")
	}

	// Check for all ones (extremely weak key)
	if cleanKey == strings.Repeat("f", 64) {
		return fmt.Errorf("private key cannot be all ones")
	}

	return nil
}

// ValidatePrivateKeyStrength validates the cryptographic strength of the private key
func ValidatePrivateKeyStrength(privateKeyBytes []byte) error {
	// Check if key is zero
	zeroKey := make([]byte, 32)
	if strings.EqualFold(hex.EncodeToString(privateKeyBytes), hex.EncodeToString(zeroKey)) {
		return fmt.Errorf("private key cannot be zero")
	}

	// Check if key is too small (less than curve order)
	keyInt := new(big.Int).SetBytes(privateKeyBytes)
	curveOrder := crypto.S256().Params().N

	if keyInt.Cmp(big.NewInt(0)) <= 0 || keyInt.Cmp(curveOrder) >= 0 {
		return fmt.Errorf("private key must be between 1 and the curve order")
	}

	// Check for known weak keys (very small values)
	if keyInt.Cmp(big.NewInt(1000)) <= 0 {
		return fmt.Errorf("private key is too small and may be insecure")
	}

	return nil
}

// ============================================================================
// WALLET OPERATION VALIDATION
// ============================================================================

// CheckDuplicateWalletAddress checks if a wallet address already exists
func CheckDuplicateWalletAddress(address string, keystoreDir string) error {
	// This would need to be implemented based on your keystore structure
	// For now, returning nil as placeholder
	return nil
}

// ValidateTransferAmount validates transfer amount is reasonable
func ValidateTransferAmount(amount float64) error {
	if amount <= 0 {
		return fmt.Errorf("amount must be greater than 0")
	}
	if amount > 1000000 { // 1M RBTC reasonable upper bound
		return fmt.Errorf("amount is unreasonably high. Please check your input")
	}
	return nil
}

// ValidateGasPrice validates gas price is reasonable
func ValidateGasPrice(gasPriceGwei float64) error {
	if gasPriceGwei > 0 && (gasPriceGwei < 0.0001 || gasPriceGwei > 0.1) {
		return fmt.Errorf("gas price must be between 0.0001 and 0.1 Gwei")
	}
	return nil
}

// ValidateGasLimit validates gas limit is reasonable
func ValidateGasLimit(gasLimit uint64) error {
	if gasLimit > 30000000 { // 30M gas limit
		return fmt.Errorf("gas limit is unreasonably high")
	}
	return nil
}
