package rskclient

import (
	"fmt"
	"os"

	"github.com/ethereum/go-ethereum/ethclient"
)

func Connect() (*ethclient.Client, error) {
	rpcUrl := os.Getenv("RPC_URL")
	if rpcUrl == "" {
		return nil, fmt.Errorf("RPC_URL is not set in the environment")
	}
	client, err := ethclient.Dial(rpcUrl)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to RPC: %w", err)
	}
	return client, nil
}
