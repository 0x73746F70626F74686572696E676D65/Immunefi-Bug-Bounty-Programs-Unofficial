package walletmeta

import (
	"fmt"
	"strings"
)

func FindAddressByName(walletName string) (string, error) {

	names, err := GetAllNames()
	if err != nil {
		return "", fmt.Errorf("failed to load wallet index: %w", err)
	}

	for addr, storedName := range names {
		if storedName == walletName {
			return strings.ToLower(addr), nil
		}
	}

	return "", fmt.Errorf("no wallet found with name: %s", walletName)
}
