package rsk

import (
	"context"
	"errors"
	"time"

	"math/big"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/rsksmart/rsk-go-cli/pkg/utils"
)

// GetBalance returns the balance (in wei) for the given address.
func GetBalance(address string) (*big.Int, error) {
	rpcURL := utils.GetRPCURL()
	if rpcURL == "" {
		return nil, errors.New("RPC_URL environment variable is not set")
	}

	client, err := ethclient.Dial(rpcURL)
	if err != nil {
		return nil, err
	}
	defer client.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	balance, err := client.BalanceAt(ctx, common.HexToAddress(address), nil)
	if err != nil {
		return nil, err
	}
	return balance, nil
}
