package utils

import (
	"fmt"
	"regexp"
	"strings"
	"syscall"

	"golang.org/x/term"
)

func ValidatePassword(password string) error {
	if len(password) < 8 {
		return fmt.Errorf("password must be at least 8 characters long")
	}
	if len(password) > 128 {
		return fmt.Errorf("password must be less than 128 characters")
	}

	hasUpper, _ := regexp.MatchString(`[A-Z]`, password)
	if !hasUpper {
		return fmt.Errorf("password must contain at least one uppercase letter")
	}

	hasLower, _ := regexp.MatchString(`[a-z]`, password)
	if !hasLower {
		return fmt.Errorf("password must contain at least one lowercase letter")
	}

	hasNumber, _ := regexp.MatchString(`[0-9]`, password)
	if !hasNumber {
		return fmt.Errorf("password must contain at least one number")
	}

	hasSpecial, _ := regexp.MatchString(`[^A-Za-z0-9]`, password)
	if !hasSpecial {
		return fmt.Errorf("password must contain at least one special character (!@#$%%^&*()_+-=[]{}|;':\",./<>?~`)")
	}

	return nil
}

func ReadPassword(prompt string) (string, error) {
	fmt.Print(prompt)
	bytePassword, err := term.ReadPassword(int(syscall.Stdin))
	fmt.Println()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(bytePassword)), nil
}

func ReadNewPassword(prompt string) (string, error) {
	PrintPasswordRequirements()

	password, err := ReadPassword(prompt)
	if err != nil {
		return "", fmt.Errorf("failed to read password: %w", err)
	}

	if err := ValidatePassword(password); err != nil {
		return "", fmt.Errorf("password validation failed: %w", err)
	}

	confirmPassword, err := ReadPassword("Confirm password: ")
	if err != nil {
		return "", fmt.Errorf("failed to read password confirmation: %w", err)
	}

	if password != confirmPassword {
		return "", fmt.Errorf("passwords do not match")
	}

	return password, nil
}

func PrintPasswordRequirements() {
	fmt.Println("Password Requirements:")
	fmt.Println("  • At least 8 characters long")
	fmt.Println("  • Less than 128 characters")
	fmt.Println("  • Must contain uppercase letters (A-Z)")
	fmt.Println("  • Must contain lowercase letters (a-z)")
	fmt.Println("  • Must contain numbers (0-9)")
	fmt.Println("  • Must contain special characters (!@#$%^&*()_+-=[]{}|;':\",./<>?~`)")
	fmt.Println()
}
