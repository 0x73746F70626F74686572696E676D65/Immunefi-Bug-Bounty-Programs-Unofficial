package utils

import (
	"math"
	"math/big"
)

// WeiToRBTC converts wei to RBTC (float64).

func WeiToRBTC(wei *big.Int) *big.Float {
	return new(big.Float).Quo(new(big.Float).SetInt(wei), big.NewFloat(math.Pow10(18)))
}

// balanceInRBTC := new(big.Float).Quo(new(big.Float).SetInt(balance), big.NewFloat(math.Pow10(18))) // Convert wei to RBTC

// RBTCToWei converts RBTC (float64) to wei.
func RBTCToWei(rbtc float64) *big.Int {
	return big.NewInt(int64(rbtc * math.Pow10(18)))
}
