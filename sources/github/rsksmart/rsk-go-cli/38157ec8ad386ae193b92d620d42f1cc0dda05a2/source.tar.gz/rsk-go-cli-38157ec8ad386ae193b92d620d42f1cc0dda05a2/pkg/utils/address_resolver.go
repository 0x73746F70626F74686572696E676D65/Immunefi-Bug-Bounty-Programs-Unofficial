package utils

import (
	"log"

	"github.com/rsksmart/rsk-go-cli/pkg/walletmeta"
)

func ResolveInputAddress(address string, name string) (string, error) {

	if address == "" && name == "" {
		log.Fatalf("You must provide either address or name")
	}

	if address == "" {
		if err := ValidateWalletName(name); err != nil {
			return "", err
		}

		address, err := walletmeta.FindAddressByName(name)
		if err != nil {
			return "", err
		}

		return address, nil
	}

	if !IsValidEthereumAddress(address) {
		log.Fatalf("Invalid address format: %s", address)
	}

	return address, nil
}
