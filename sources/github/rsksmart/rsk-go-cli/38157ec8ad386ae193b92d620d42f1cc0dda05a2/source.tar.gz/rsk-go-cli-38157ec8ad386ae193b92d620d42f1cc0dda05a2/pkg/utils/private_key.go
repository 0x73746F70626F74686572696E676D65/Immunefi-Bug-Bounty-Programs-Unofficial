package utils

import (
	"fmt"
	"strings"
	"syscall"

	"golang.org/x/term"
)

func ReadPrivateKey(prompt string) (string, error) {
	fmt.Print(prompt)
	bytePrivateKey, err := term.ReadPassword(int(syscall.Stdin))
	fmt.Println()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(bytePrivateKey)), nil
}
