package keystoreutil

import (
	"errors"
	"os"
	"path/filepath"
	"strings"

	"github.com/ethereum/go-ethereum/accounts"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"github.com/ethereum/go-ethereum/common"
)

// CreateNewWallet creates a new wallet/account in the given keystore directory with the provided password.
func CreateNewWallet(keystoreDir, password string) (accounts.Account, error) {
	if err := os.MkdirAll(keystoreDir, 0700); err != nil {
		return accounts.Account{}, err
	}
	ks := keystore.NewKeyStore(keystoreDir, keystore.StandardScryptN, keystore.StandardScryptP)
	return ks.NewAccount(password)
}

// FindKeystoreFile returns the path to the keystore file for a given address.
func FindKeystoreFile(keystoreDir, address string) (string, error) {

	if !common.IsHexAddress(address) {
		return "", errors.New("invalid address format")
	}
	address = strings.ToLower(address)

	files, err := os.ReadDir(keystoreDir)
	if err != nil {
		return "", err
	}
	for _, file := range files {
		if file.IsDir() {
			continue
		}
		if strings.HasPrefix(file.Name(), "UTC--") {
			fullPath := filepath.Join(keystoreDir, file.Name())
			data, _ := os.ReadFile(fullPath)

			if strings.Contains(strings.ToLower(string(data)), address[2:]) {
				return fullPath, nil
			}
		}
	}
	return "", os.ErrNotExist
}

// DecryptKeyFromFile loads and decrypts a keystore file.
func DecryptKeyFromFile(keystorePath, password string) (*keystore.Key, error) {
	keyJSON, err := os.ReadFile(keystorePath)
	if err != nil {
		return nil, err
	}
	return keystore.DecryptKey(keyJSON, password)
}
