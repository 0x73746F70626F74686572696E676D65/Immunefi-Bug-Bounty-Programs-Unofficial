package liquidity_provider

import (
	"context"
	"fmt"

	"github.com/rsksmart/liquidity-provider-server/internal/entities/alerts"
	"github.com/rsksmart/liquidity-provider-server/internal/entities/blockchain"
	"github.com/rsksmart/liquidity-provider-server/internal/entities/penalization"
	"github.com/rsksmart/liquidity-provider-server/internal/usecases"
	log "github.com/sirupsen/logrus"
)

type PenalizationAlertUseCase struct {
	contracts                blockchain.RskContracts
	sender                   alerts.AlertSender
	recipient                string
	penalizedEventRepository penalization.PenalizedEventRepository
}

func NewPenalizationAlertUseCase(
	contracts blockchain.RskContracts,
	sender alerts.AlertSender,
	recipient string,
	penalizedEventRepository penalization.PenalizedEventRepository,
) *PenalizationAlertUseCase {
	return &PenalizationAlertUseCase{
		contracts:                contracts,
		sender:                   sender,
		recipient:                recipient,
		penalizedEventRepository: penalizedEventRepository,
	}
}

func (useCase *PenalizationAlertUseCase) Run(ctx context.Context, fromBlock, toBlock uint64) error {
	var body string
	events, err := useCase.contracts.CollateralManagement.GetPenalizedEvents(ctx, fromBlock, &toBlock)
	if err != nil {
		return usecases.WrapUseCaseError(usecases.PenalizationId, err)
	}

	for _, event := range events {
		err := useCase.penalizedEventRepository.InsertPenalization(ctx, event)
		if err != nil {
			log.Error(usecases.PenalizationId, err)
		}
		body = fmt.Sprintf("You were punished in %v rBTC for the quoteHash %s", event.Penalty.ToRbtc(), event.QuoteHash)
		if err = useCase.sender.SendAlert(ctx, alerts.AlertSubjectPenalization, body, []string{useCase.recipient}); err != nil {
			log.Error("Error sending punishment alert: ", err)
		}
	}
	return nil
}
