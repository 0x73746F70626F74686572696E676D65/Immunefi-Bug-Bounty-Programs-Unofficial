package pegout_test

import (
	"context"
	"errors"
	"math/big"
	"testing"
	"time"

	"github.com/rsksmart/liquidity-provider-server/internal/entities"
	"github.com/rsksmart/liquidity-provider-server/internal/entities/blockchain"
	"github.com/rsksmart/liquidity-provider-server/internal/entities/quote"
	"github.com/rsksmart/liquidity-provider-server/internal/usecases"
	"github.com/rsksmart/liquidity-provider-server/internal/usecases/pegout"
	"github.com/rsksmart/liquidity-provider-server/test"
	"github.com/rsksmart/liquidity-provider-server/test/mocks"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
)

var (
	now                = uint32(time.Now().Unix())
	refundPegoutTxHash = "0x1f1d1b"
)

var retainedQuote = quote.RetainedPegoutQuote{
	QuoteHash:          "1c2d3f",
	DepositAddress:     "0x654321",
	Signature:          "0x112a3b",
	RequiredLiquidity:  entities.NewWei(1000),
	State:              quote.PegoutStateSendPegoutSucceeded,
	UserRskTxHash:      "0x3c2b1a",
	LpBtcTxHash:        "0x3c2b1b",
	RefundPegoutTxHash: "",
	BridgeRefundTxHash: "",
}

var pegoutQuote = quote.PegoutQuote{
	LbcAddress:            retainedQuote.QuoteHash,
	LpRskAddress:          "0x1234",
	BtcRefundAddress:      test.AnyAddress,
	RskRefundAddress:      "0x1234",
	LpBtcAddress:          "0x1234",
	CallFee:               entities.NewWei(3000),
	PenaltyFee:            entities.NewWei(2),
	Nonce:                 3,
	DepositAddress:        test.AnyAddress,
	Value:                 entities.NewWei(4000),
	AgreementTimestamp:    now,
	DepositDateLimit:      now + 60,
	DepositConfirmations:  10,
	TransferConfirmations: 10,
	TransferTime:          60,
	ExpireDate:            now + 60,
	ExpireBlock:           500,
	GasFee:                entities.NewWei(1000),
}

var btcBlockInfoMock = blockchain.BitcoinBlockInformation{
	Hash:   [32]byte{32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1},
	Height: big.NewInt(200),
}

var merkleBranchMock = blockchain.MerkleBranch{
	Hashes: [][32]byte{
		{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32},
		{32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1},
	},
	Path: big.NewInt(1),
}

var btcTxInfoMock = blockchain.BitcoinTransactionInformation{
	Hash:          "0x3c2b1b",
	Confirmations: 11,
	Outputs:       map[string][]*entities.Wei{test.AnyAddress: {entities.NewWei(1000)}},
}

var btcRawTxMock = []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32}

func TestRefundPegoutUseCase_Run_Paused(t *testing.T) {
	btc := new(mocks.BtcRpcMock)
	rpc := blockchain.Rpc{Btc: btc}
	mutex := new(mocks.MutexMock)
	bridge := new(mocks.BridgeMock)
	pegoutContract := new(mocks.PegoutContractMock)
	pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: true, Since: 5, Reason: "test"}, nil)
	pegoutContract.EXPECT().GetAddress().Return("test-contract")
	contracts := blockchain.RskContracts{PegOut: pegoutContract, Bridge: bridge}
	quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
	eventBus := new(mocks.EventBusMock)
	useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)
	err := useCase.Run(context.Background(), retainedQuote)
	require.ErrorIs(t, err, blockchain.ContractPausedError)
}

func TestRefundPegoutUseCase_Run(t *testing.T) {
	quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
	refundPegoutReceipt := blockchain.TransactionReceipt{
		TransactionHash:   refundPegoutTxHash,
		BlockHash:         "0xblock123",
		BlockNumber:       uint64(1000),
		From:              "0x123",
		To:                "0x456",
		CumulativeGasUsed: big.NewInt(21000),
		GasUsed:           big.NewInt(21000),
		Value:             entities.NewWei(0),
		GasPrice:          entities.NewWei(1000000000),
	}
	expectedRetained := quote.RetainedPegoutQuote{
		QuoteHash:            retainedQuote.QuoteHash,
		DepositAddress:       retainedQuote.DepositAddress,
		Signature:            retainedQuote.Signature,
		RequiredLiquidity:    retainedQuote.RequiredLiquidity,
		State:                quote.PegoutStateRefundPegOutSucceeded,
		UserRskTxHash:        retainedQuote.UserRskTxHash,
		LpBtcTxHash:          retainedQuote.LpBtcTxHash,
		RefundPegoutTxHash:   refundPegoutTxHash,
		RefundPegoutGasUsed:  refundPegoutReceipt.GasUsed.Uint64(),
		RefundPegoutGasPrice: refundPegoutReceipt.GasPrice,
	}
	quoteRepository.On("UpdateRetainedQuote", test.AnyCtx, expectedRetained).Return(nil).Once()
	quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
	pegoutContract := new(mocks.PegoutContractMock)
	pegoutContract.On("RefundPegout", mock.Anything, mock.Anything).Return(refundPegoutReceipt, nil).Once()
	pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: false}, nil)
	eventBus := new(mocks.EventBusMock)
	eventBus.On("Publish", mock.MatchedBy(func(event quote.PegoutQuoteCompletedEvent) bool {
		expected := retainedQuote
		expected.RefundPegoutTxHash = refundPegoutTxHash
		expected.RefundPegoutGasUsed = refundPegoutReceipt.GasUsed.Uint64()
		expected.RefundPegoutGasPrice = refundPegoutReceipt.GasPrice
		expected.State = quote.PegoutStateRefundPegOutSucceeded
		require.NoError(t, event.Error)
		return assert.Equal(t, expected, event.RetainedQuote) && assert.Equal(t, quote.PegoutQuoteCompletedEventId, event.Event.Id())
	})).Return().Once()
	btc := new(mocks.BtcRpcMock)
	btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
	btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil)
	btc.On("GetRawTransaction", mock.Anything).Return(btcRawTxMock, nil)
	btc.On("GetTransactionBlockInfo", mock.Anything).Return(btcBlockInfoMock, nil)
	mutex := new(mocks.MutexMock)
	mutex.On("Lock").Return().Once()
	mutex.On("Unlock").Return().Once()
	bridge := new(mocks.BridgeMock)

	contracts := blockchain.RskContracts{PegOut: pegoutContract, Bridge: bridge}
	rpc := blockchain.Rpc{Btc: btc}
	useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)
	err := useCase.Run(context.Background(), retainedQuote)
	quoteRepository.AssertExpectations(t)
	pegoutContract.AssertExpectations(t)
	eventBus.AssertExpectations(t)
	btc.AssertExpectations(t)
	require.NoError(t, err)
	bridge.AssertNotCalled(t, "RegisterBtcCoinbaseTransaction")
}

func TestRefundPegoutUseCase_Run_UpdateError(t *testing.T) {
	updateError := errors.New("an update error")
	quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
	quoteRepository.On("UpdateRetainedQuote", test.AnyCtx, mock.Anything).Return(updateError).Once()
	quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
	pegoutContract := new(mocks.PegoutContractMock)
	pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: false}, nil)
	refundPegoutReceipt2 := blockchain.TransactionReceipt{
		TransactionHash:   refundPegoutTxHash,
		BlockHash:         "0xblock123",
		BlockNumber:       uint64(1000),
		From:              "0x123",
		To:                "0x456",
		CumulativeGasUsed: big.NewInt(21000),
		GasUsed:           big.NewInt(21000),
		Value:             entities.NewWei(0),
		GasPrice:          entities.NewWei(1000000000),
	}
	pegoutContract.On("RefundPegout", mock.Anything, mock.Anything).Return(refundPegoutReceipt2, nil).Once()
	eventBus := new(mocks.EventBusMock)
	eventBus.On("Publish", mock.MatchedBy(func(event quote.PegoutQuoteCompletedEvent) bool {
		expected := retainedQuote
		expected.RefundPegoutTxHash = refundPegoutTxHash
		expected.State = quote.PegoutStateRefundPegOutSucceeded
		expected.RefundPegoutGasUsed = uint64(21000)
		expected.RefundPegoutGasPrice = entities.NewWei(1000000000)
		require.NoError(t, event.Error)
		return assert.Equal(t, expected, event.RetainedQuote) && assert.Equal(t, quote.PegoutQuoteCompletedEventId, event.Event.Id())
	})).Return().Once()
	btc := new(mocks.BtcRpcMock)
	btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
	btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil)
	btc.On("GetRawTransaction", mock.Anything).Return(btcRawTxMock, nil)
	btc.On("GetTransactionBlockInfo", mock.Anything).Return(btcBlockInfoMock, nil)
	mutex := new(mocks.MutexMock)
	mutex.On("Lock").Return().Once()
	mutex.On("Unlock").Return().Once()

	contracts := blockchain.RskContracts{PegOut: pegoutContract}
	rpc := blockchain.Rpc{Btc: btc}
	useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)
	err := useCase.Run(context.Background(), retainedQuote)

	quoteRepository.AssertExpectations(t)
	pegoutContract.AssertExpectations(t)
	eventBus.AssertExpectations(t)
	btc.AssertExpectations(t)
	require.ErrorIs(t, err, updateError)
}

func TestRefundPegoutUseCase_Run_NotPublishRecoverableError(t *testing.T) {
	recoverableSetups := []func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock){
		func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(nil, assert.AnError).Once()
		},
		func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(blockchain.BitcoinTransactionInformation{}, assert.AnError).Once()
		},
		func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
			btc.On("BuildMerkleBranch", mock.Anything).Return(blockchain.MerkleBranch{}, assert.AnError).Once()
		},
		func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
			btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil).Once()
			btc.On("GetTransactionBlockInfo", mock.Anything).Return(blockchain.BitcoinBlockInformation{}, assert.AnError).Once()
		},
		func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
			btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil).Once()
			btc.On("GetTransactionBlockInfo", mock.Anything).Return(btcBlockInfoMock, nil).Once()
			btc.On("GetRawTransaction", mock.Anything).Return(nil, assert.AnError).Once()

		},
		func(quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
			btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil).Once()
			btc.On("GetTransactionBlockInfo", mock.Anything).Return(btcBlockInfoMock, nil).Once()
			btc.On("GetRawTransaction", mock.Anything).Return(btcRawTxMock, nil).Once()
			pegoutContract.On("RefundPegout", mock.Anything, mock.Anything).Return(blockchain.TransactionReceipt{}, blockchain.WaitingForBridgeError).Once()
		},
	}
	for _, setup := range recoverableSetups {
		eventBus := new(mocks.EventBusMock)
		mutex := new(mocks.MutexMock)
		mutex.On("Lock").Return()
		mutex.On("Unlock").Return()
		quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
		pegoutContract := new(mocks.PegoutContractMock)
		pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: false}, nil)
		btc := new(mocks.BtcRpcMock)
		setup(quoteRepository, pegoutContract, btc)
		contracts := blockchain.RskContracts{PegOut: pegoutContract}
		rpc := blockchain.Rpc{Btc: btc}
		useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)
		err := useCase.Run(context.Background(), retainedQuote)
		pegoutContract.AssertExpectations(t)
		btc.AssertExpectations(t)
		quoteRepository.AssertExpectations(t)
		eventBus.AssertNotCalled(t, "Publish", mock.Anything)
		require.Error(t, err)
	}
}

func TestRefundPegoutUseCase_Run_PublishUnrecoverableError(t *testing.T) {
	unrecoverableSetups := []func(retainedQuote *quote.RetainedPegoutQuote, quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock){
		func(retainedQuote *quote.RetainedPegoutQuote, quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(nil, nil).Once()
		},
		func(retainedQuote *quote.RetainedPegoutQuote, quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			retainedQuote.QuoteHash = "no hex"
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
			btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil).Once()
			btc.On("GetTransactionBlockInfo", mock.Anything).Return(btcBlockInfoMock, nil).Once()
			btc.On("GetRawTransaction", mock.Anything).Return(btcRawTxMock, nil).Once()
		},
		func(retainedQuote *quote.RetainedPegoutQuote, quoteRepository *mocks.PegoutQuoteRepositoryMock, pegoutContract *mocks.PegoutContractMock, btc *mocks.BtcRpcMock) {
			quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
			btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(btcTxInfoMock, nil).Once()
			btc.On("BuildMerkleBranch", mock.Anything).Return(merkleBranchMock, nil).Once()
			btc.On("GetTransactionBlockInfo", mock.Anything).Return(btcBlockInfoMock, nil).Once()
			btc.On("GetRawTransaction", mock.Anything).Return(btcRawTxMock, nil).Once()
			pegoutContract.On("RefundPegout", mock.Anything, mock.Anything).Return(blockchain.TransactionReceipt{}, assert.AnError).Once()
		},
	}

	for _, setup := range unrecoverableSetups {
		quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
		pegoutContract := new(mocks.PegoutContractMock)
		pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: false}, nil)
		btc := new(mocks.BtcRpcMock)
		caseQuote := retainedQuote
		setup(&caseQuote, quoteRepository, pegoutContract, btc)
		mutex := new(mocks.MutexMock)
		mutex.On("Lock").Return()
		mutex.On("Unlock").Return()
		eventBus := new(mocks.EventBusMock)
		eventBus.On("Publish", mock.MatchedBy(func(event quote.PegoutQuoteCompletedEvent) bool {
			require.Error(t, event.Error)
			return assert.Equal(t, caseQuote.LpBtcTxHash, event.RetainedQuote.LpBtcTxHash) && assert.Equal(t, caseQuote.Signature, event.RetainedQuote.Signature) &&
				assert.Equal(t, caseQuote.QuoteHash, event.RetainedQuote.QuoteHash) && assert.Equal(t, caseQuote.DepositAddress, event.RetainedQuote.DepositAddress) &&
				assert.Equal(t, caseQuote.RequiredLiquidity, event.RetainedQuote.RequiredLiquidity) && assert.Equal(t, quote.PegoutStateRefundPegOutFailed, event.RetainedQuote.State) &&
				assert.Equal(t, caseQuote.UserRskTxHash, event.RetainedQuote.UserRskTxHash) && assert.Equal(t, quote.PegoutQuoteCompletedEventId, event.Event.Id())
		})).Return().Once()
		quoteRepository.On("UpdateRetainedQuote", test.AnyCtx, mock.MatchedBy(
			func(q quote.RetainedPegoutQuote) bool {
				expected := caseQuote
				expected.State = quote.PegoutStateRefundPegOutFailed
				return assert.Equal(t, expected, q)
			})).Return(nil).Once()
		contracts := blockchain.RskContracts{PegOut: pegoutContract}
		rpc := blockchain.Rpc{Btc: btc}
		useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)
		err := useCase.Run(context.Background(), caseQuote)
		pegoutContract.AssertExpectations(t)
		btc.AssertExpectations(t)
		quoteRepository.AssertExpectations(t)
		eventBus.AssertExpectations(t)
		require.Error(t, err)
	}
}

func TestRefundPegoutUseCase_Run_NoConfirmations(t *testing.T) {
	unconfirmedBlockInfo := btcTxInfoMock
	unconfirmedBlockInfo.Confirmations = 1
	quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
	quoteRepository.On("GetQuote", test.AnyCtx, retainedQuote.QuoteHash).Return(&pegoutQuote, nil).Once()
	pegoutContract := new(mocks.PegoutContractMock)
	pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: false}, nil)
	eventBus := new(mocks.EventBusMock)
	btc := new(mocks.BtcRpcMock)
	btc.On("GetTransactionInfo", retainedQuote.LpBtcTxHash).Return(unconfirmedBlockInfo, nil).Once()
	mutex := new(mocks.MutexMock)

	contracts := blockchain.RskContracts{PegOut: pegoutContract}
	rpc := blockchain.Rpc{Btc: btc}
	useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)
	err := useCase.Run(context.Background(), retainedQuote)

	quoteRepository.AssertExpectations(t)
	btc.AssertExpectations(t)
	eventBus.AssertNotCalled(t, "Publish")
	pegoutContract.AssertNotCalled(t, "RefundPegout")
	pegoutContract.AssertNotCalled(t, "GetAddress")
	mutex.AssertNotCalled(t, "Lock")
	mutex.AssertNotCalled(t, "Unlock")
	require.ErrorIs(t, err, usecases.NoEnoughConfirmationsError)
}

func TestRefundPegoutUseCase_Run_WrongState(t *testing.T) {
	wrongStateQuote := retainedQuote
	wrongStateQuote.State = quote.PegoutStateSendPegoutFailed
	quoteRepository := new(mocks.PegoutQuoteRepositoryMock)
	pegoutContract := new(mocks.PegoutContractMock)
	pegoutContract.EXPECT().PausedStatus().Return(blockchain.PauseStatus{IsPaused: false}, nil)
	eventBus := new(mocks.EventBusMock)
	btc := new(mocks.BtcRpcMock)
	mutex := new(mocks.MutexMock)

	contracts := blockchain.RskContracts{PegOut: pegoutContract}
	rpc := blockchain.Rpc{Btc: btc}
	useCase := pegout.NewRefundPegoutUseCase(quoteRepository, contracts, eventBus, rpc, mutex)

	err := useCase.Run(context.Background(), wrongStateQuote)

	quoteRepository.AssertNotCalled(t, "UpdateRetainedQuote")
	quoteRepository.AssertNotCalled(t, "GetQuote")
	quoteRepository.AssertNotCalled(t, "GetRetainedQuote")
	btc.AssertNotCalled(t, "GetTransactionInfo")
	eventBus.AssertNotCalled(t, "Publish")
	pegoutContract.AssertNotCalled(t, "RefundPegout")
	pegoutContract.AssertNotCalled(t, "GetAddress")
	mutex.AssertNotCalled(t, "Lock")
	mutex.AssertNotCalled(t, "Unlock")
	require.ErrorIs(t, err, usecases.WrongStateError)
}
