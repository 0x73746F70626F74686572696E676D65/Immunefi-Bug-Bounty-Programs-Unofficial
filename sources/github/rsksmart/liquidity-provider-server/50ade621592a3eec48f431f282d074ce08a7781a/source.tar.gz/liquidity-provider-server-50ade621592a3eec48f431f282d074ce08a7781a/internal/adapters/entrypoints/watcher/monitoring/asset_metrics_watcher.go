package monitoring

import (
	"context"

	"github.com/rsksmart/liquidity-provider-server/internal/entities/utils"
	"github.com/rsksmart/liquidity-provider-server/internal/usecases/reports"
	log "github.com/sirupsen/logrus"
)

// GetAssetReportUseCase defines the interface for getting asset reports
type GetAssetReportUseCase interface {
	Run(ctx context.Context) (reports.GetAssetsReportResult, error)
}

type AssetReportWatcher struct {
	appMetrics            *Metrics
	getAssetReportUseCase GetAssetReportUseCase
	ticker                utils.Ticker
	watcherStopChannel    chan struct{}
}

func NewAssetReportWatcher(
	appMetrics *Metrics,
	getAssetReportUseCase GetAssetReportUseCase,
	ticker utils.Ticker,
) *AssetReportWatcher {
	watcherStopChannel := make(chan struct{}, 1)
	return &AssetReportWatcher{
		appMetrics:            appMetrics,
		getAssetReportUseCase: getAssetReportUseCase,
		watcherStopChannel:    watcherStopChannel,
		ticker:                ticker,
	}
}

func (watcher *AssetReportWatcher) Prepare(ctx context.Context) error {
	return nil
}

func (watcher *AssetReportWatcher) Start() {
watcherLoop:
	for {
		select {
		case <-watcher.ticker.C():
			watcher.updateMetrics()
		case <-watcher.watcherStopChannel:
			watcher.ticker.Stop()
			close(watcher.watcherStopChannel)
			break watcherLoop
		}
	}
}

func (watcher *AssetReportWatcher) Shutdown(closeChannel chan<- bool) {
	watcher.watcherStopChannel <- struct{}{}
	closeChannel <- true
	log.Debug("AssetReportWatcher shut down")
}

func (watcher *AssetReportWatcher) updateMetrics() {
	report, err := watcher.getAssetReportUseCase.Run(context.Background())
	if err != nil {
		log.WithError(err).Error("Failed to collect asset report")
		return
	}

	watcher.appMetrics.UpdateAssetsFromReport(report)
}
