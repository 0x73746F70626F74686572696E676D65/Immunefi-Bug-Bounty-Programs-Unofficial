[![Build and Test](https://github.com/rsksmart/rsk-precompiled-abis/actions/workflows/build-test.yml/badge.svg)](https://github.com/rsksmart/rsk-precompiled-abis/actions/workflows/build-test.yml)
[![CodeQL](https://github.com/rsksmart/rsk-precompiled-abis/workflows/CodeQL/badge.svg)](https://github.com/rsksmart/rsk-precompiled-abis/actions?query=workflow%3ACodeQL)
[![OpenSSF Scorecard](https://api.scorecard.dev/projects/github.com/rsksmart/rsk-precompiled-abis/badge)](https://scorecard.dev/viewer/?uri=github.com/rsksmart/rsk-precompiled-abis)

<img src="./rootstock_logo.png" alt="Rootstock" />

# Welcome to the precompiled ABIs from Rootstock

Here you will find the ABIs for the existing precompiled contracts in Rootstock. You will also get their addresses.

# Version

Different versions of the package mentioned are required for different Rootstock releases. For each named release of Rootstock, there will be a corresponding name version in npm. See [releases](https://github.com/rsksmart/rsk-precompiled-abis/releases) page.

This package's support starts with ORCHID.

# How to use it

For the installation of these package you must execute in a terminal window:

```shell
npm install @rsksmart/rsk-precompiled-abis@<version>
```

## With Ethers

```js

const ethers = require('ethers');
const precompiledAbis = require('@rsksmart/rsk-precompiled-abis');
const networkUrl = 'https://public-node.rsk.co/';

const provider = new ethers.JsonRpcProvider(networkUrl);
const bridge = new ethers.Contract(precompiledAbis.bridge.address, precompiledAbis.bridge.abi, provider);
const blockHeader = new ethers.Contract(precompiledAbis.blockHeader.address, precompiledAbis.blockHeader.abi, provider);

bridge.getBtcBlockchainBestChainHeight().then(console.log);
// block depth: 0 = executing parent block
blockHeader.getBlockHash(0).then(console.log);

```

That would print something like: `881524n`.

## With Viem

```js
const { createPublicClient, http } = require("viem");
const { mainnet } = require("viem/chains");
const precompiledAbis = require('@rsksmart/rsk-precompiled-abis');
const networkUrl = 'https://public-node.rsk.co/';

const client = createPublicClient({
  chain: mainnet,
  transport: http(networkUrl),
});

const getBlockchainHeight = async () => {
  try {
    const height = await client.readContract({
      address: precompiledAbis.bridge.address,
      abi: precompiledAbis.bridge.abi,
      functionName: "getBtcBlockchainBestChainHeight",
    });
    console.log("btcBlockchainBestChainHeight:", height);
  } catch (error) {
    console.error("Error getting btcBlockchainBestChainHeight:", error);
  }
};

const getLatestBlockHash = async () => {
  try {
    const hashBytes = await client.readContract({
      address: precompiledAbis.blockHeader.address,
      abi: precompiledAbis.blockHeader.abi,
      functionName: "getBlockHash",
      args: [0], // executing parent block
    });
    console.log("latestBlockHash(bytes):", hashBytes);
  } catch (error) {
    console.error("Error getting block header hash:", error);
  }
};

getBlockchainHeight();
getLatestBlockHash();

```

That would print something like: `881524n`.

# Important note

If the version to be installed is not defined in the command line, it will install the latest version by default.

# Rootstock Bridge Methods Selectors and Events Topics page

A standalone HTML project to get the RSK bridge methods selectors and events topics is included under `/tools` folder, called `PrecompiledAbis.html`.

Simply download it and open it in the browser, or visit [https://rsksmart.github.io/rsk-precompiled-abis/](https://rsksmart.github.io/rsk-precompiled-abis/) to view the available HTML tools directly from this repo.

<img src="./tools/precompiledAbisMethods.png" alt="Rootstock bridge abis methods" />

<img src="./tools/precompiledAbisEvents.png" alt="Rootstock bridge abis events" />

You can see the rsk bridge abi methods and events during a given fork by selecting using the ***Abis For Fork*** dropdown.

# RootstockBridge HTML utility page

A standalone HTML project to interact with the RSK bridge methods is included under `/tools` folder, called `RootstockBridge.html`.

Simply download it and open it in the browser.

It will look like this:

<img src="./tools/RootstockBridge.png" alt="Rootstock bridge html utility project" />

Simply click on any of the buttons with the name of the Bridge method that you want to call.

For the ones that accept input, simply add the inputs required and click the button.

Change the network from Testnet to Mainnet using the **Network** select at the top of the page.

Clear all the inputs and results clicking on the **Clear** button.

Copy the result by clicking on the copy icon to the right of the result box.

To use a custom network, click on `Use Custom Network` checkbox and you will have a text field to input a custom url. Hit enter/return and use the tool as usual.

For any comments or suggestions, feel free to contribute or reach out at our [Discord server](https://discord.gg/rootstock).
