import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import actions from '../../../../ui/app/actions'
import rifActions from '../../../../ui/app/rif/actions'
import ConnectScreen from './connect-screen'
import AccountList from './account-list'
import { formatBalance } from '../../util'
import { getPlatform } from '../../../../app/scripts/lib/util'
import { PLATFORM_FIREFOX } from '../../../../app/scripts/lib/enums'
import { getMetaMaskAccounts } from '../../../../ui/app/selectors'
import { LEDGER, TREZOR } from './enum'

const initialState = {
  error: null,
  selectedAccount: null,
  selectedAccounts: [],
  accounts: [],
  browserSupported: true,
  unlocked: false,
  device: null,
  isInitProcessFinalized: false,
};

class ConnectHardwareForm extends Component {

  constructor (props, context) {
    super(props)
    this.state = initialState;
    this.initialize();
  }

  initialize () {
    this.timerID = null
    this.props.isInitProcessFinalized().then(isInitProcessFinalized => {
      this.setState({isInitProcessFinalized})
    });
  }

  componentWillReceiveProps (nextProps) {
    const { accounts, network } = nextProps
    const newAccounts = this.state.accounts.map(a => {
      const normalizedAddress = a.address.toLowerCase()
      const balanceValue = accounts[normalizedAddress] && accounts[normalizedAddress].balance || null
      a.balance = balanceValue ? formatBalance(balanceValue, 4, undefined, network) : '...'
      return a
    })
    this.setState({accounts: newAccounts})
  }

  componentWillUnmount () {
    clearTimeout(this.timerID)
  }

  componentDidMount () {
    this.checkIfUnlocked()
  }

  async checkIfUnlocked () {
    [TREZOR, LEDGER].forEach(async device => {
      const hdPath = this._setHdPath(device)
      const unlocked = await this.props.checkHardwareStatus(device, hdPath)
      if (unlocked) {
        this.setState({unlocked: true})
        this.getPage(device, 0, hdPath)
      }
    })
  }

  connectToHardwareWallet = (device) => {
    // None of the hardware wallets are supported
    // At least for now
    if (getPlatform() === PLATFORM_FIREFOX) {
      this.setState({ browserSupported: false, error: null})
      return null
    }

    if (this.state.accounts.length) {
      return null
    }

    const hdPath = this._setHdPath(device)

    // Default values
    this.getPage(device, 0, hdPath)
  }

  onPathChange = (path) => {
    this.props.setHardwareWalletDefaultHdPath({device: this.state.device, path})
    this.getPage(this.state.device, 0, path)
  }

  onAccountChange = (account) => {
    let selectedAcc = account.toString()
    const selectedAccounts = this.state.selectedAccounts
    if (!selectedAccounts.includes(selectedAcc)) {
      selectedAccounts.push(selectedAcc)
    } else {
      const indToRemove = selectedAccounts.indexOf(selectedAcc)
      selectedAccounts.splice(indToRemove, 1)
      selectedAcc = selectedAccounts[selectedAccounts.length - 1]
    }
    const newState = {
      selectedAccounts,
      selectedAccount: selectedAcc,
      error: null,
    }
    this.setState(newState)
  }

  onAccountRestriction = () => {
    this.setState({error: 'You need to make use your last account before you can add a new one.' })
  }

  showTemporaryAlert () {
    this.props.showAlert('Hardware wallet connected')
    // Autohide the alert after 5 seconds
    this.timerID = setTimeout(_ => {
      this.props.hideAlert()
    }, 5000)
  }

  getPage = (device, page, hdPath) => {
    this.props
      .connectHardware(device, page, hdPath)
      .then(accounts => {
        if (accounts.length) {

          // If we just loaded the accounts for the first time
          // (device previously locked) show the global alert
          if (this.state.accounts.length === 0 && !this.state.unlocked) {
            this.showTemporaryAlert()
          }

          const newState = { unlocked: true, device, error: null }
          // Default to the first account
          if (this.state.selectedAccount === null) {
            accounts.forEach((a, i) => {
              if (a.address.toLowerCase() === this.props.address) {
                newState.selectedAccount = a.index.toString()
              }
            })
          // If the page doesn't contain the selected account, let's deselect it
          } else if (!accounts.filter(a => a.index.toString() === this.state.selectedAccount).length) {
            newState.selectedAccount = null
          }

          // Map accounts with balances
          newState.accounts = accounts.map(account => {
            const normalizedAddress = account.address.toLowerCase()
            const balanceValue = this.props.accounts[normalizedAddress] && this.props.accounts[normalizedAddress].balance || null
            account.balance = balanceValue ? formatBalance(balanceValue, 4, undefined, this.props.network) : '...'
            return account
          })

          this.setState(newState)
        }
      })
      .catch(e => {
        if (e === 'Window blocked') {
          this.setState({ browserSupported: false, error: null})
        } else if (e !== 'Window closed') {
          this.setState({ error: (e.message || e.toString()) })
        }
      })
  }

  onForgetDevice = (device) => {
    if (this.state.isInitProcessFinalized) {
      this.props.showForgetDevicePage(device)
    } else {
      this.props.forgetDevice(device, true);
      this.setState(initialState);
      this.initialize();
      this.props.setUsingHardwareWallet(false);
    }
  }

  onUnlockAccount = (device) => {

    if (this.state.selectedAccounts.length === 0) {
      return this.setState({ error: 'You need to select an account!' })
    }

    this.unlockHardwareWalletAccounts(this.state.selectedAccounts, device)
    .then(_ => {
      this.props.finalizeInitProcess();
      this.props.goHome()
      this.props.setUsingHardwareWallet(true);
    })
  }

  unlockHardwareWalletAccounts = (accounts, device) => {
    return accounts.reduce((promise, account) => {
      return promise
        .then((result) => {
          return new Promise((resolve, reject) => {
            resolve(this.props.unlockHardwareWalletAccount(account, device))
          })
        })
        .catch(e => this.setState({ error: (e.message || e.toString()) }))
    }, Promise.resolve())
  }

  onCancel = (device) => {
    if (this.state.isInitProcessFinalized) {
      this.props.goHome()
      console.log('GOING HOMEEEEEEEEEEEEEEEEEEEEEEE');
    } else {
      this.props.forgetDevice(device, true);
      this.setState(initialState);
      this.initialize();
    }
  }

  renderError () {
    return this.state.error
      ? <span className="error" style={{ display: 'block', textAlign: 'center' }}>{this.state.error}</span>
      : null
  }

  renderContent () {
    if (!this.state.accounts.length) {
      return (
        <ConnectScreen
          connectToHardwareWallet={this.connectToHardwareWallet}
          browserSupported={this.state.browserSupported}
          goHome={this.props.goHome}
          isInitProcessFinalized={this.state.isInitProcessFinalized}
          finalizeInitProcess={this.props.finalizeInitProcess}
        />
      )
    }

    return (
      <AccountList
        onPathChange={this.onPathChange}
        selectedPath={this._setHdPath(this.state.device)}
        device={this.state.device}
        accounts={this.state.accounts}
        selectedAccount={this.state.selectedAccount}
        selectedAccounts={this.state.selectedAccounts}
        onAccountChange={this.onAccountChange}
        network={this.props.network}
        getPage={this.getPage}
        onUnlockAccount={this.onUnlockAccount}
        onForgetDevice={this.onForgetDevice}
        onCancel={this.onCancel}
        onAccountRestriction={this.onAccountRestriction}
      />
    )
  }

  render () {
    let backButton = null;
    if (this.state.isInitProcessFinalized) {
      backButton = (<i className="fa fa-arrow-left fa-lg cursor-pointer"
                       onClick={() => this.props.goHome() }
                       style={{
                         position: 'absolute',
                         left: '30px',
                       }}/>);
    }
    return (
      <div style={{width: '100%'}}>
        <div className="section-title flex-row flex-center">
          {backButton}
          <h2>Connect to hardware wallet</h2>
        </div>
        <div style={{overflowY: 'auto', height: '482px'}}>
          <div style={{padding: '0 30px'}}>
            {this.renderError()}
            {this.renderContent()}
          </div>
        </div>
      </div>
    )
  }

  _setHdPath (device) {
    let hdPath
    const {network, customHdPaths, defaultHdPaths} = this.props
    const networkInteger = parseInt(network, 10)
    if (customHdPaths.hasOwnProperty(networkInteger)) {
      hdPath = customHdPaths[networkInteger][device]
    } else {
      hdPath = defaultHdPaths[device]
    }
    return hdPath
  }
}

ConnectHardwareForm.propTypes = {
  showForgetDevicePage: PropTypes.func,
  showImportPage: PropTypes.func,
  showConnectPage: PropTypes.func,
  connectHardware: PropTypes.func,
  checkHardwareStatus: PropTypes.func,
  forgetDevice: PropTypes.func,
  showAlert: PropTypes.func,
  hideAlert: PropTypes.func,
  unlockHardwareWalletAccount: PropTypes.func,
  setHardwareWalletDefaultHdPath: PropTypes.func,
  goHome: PropTypes.func,
  numberOfExistingAccounts: PropTypes.number,
  network: PropTypes.string,
  accounts: PropTypes.object,
  address: PropTypes.string,
  defaultHdPaths: PropTypes.object,
  customHdPaths: PropTypes.object,
  finalizeInitProcess: PropTypes.func,
  isInitProcessFinalized: PropTypes.func,
  setUsingHardwareWallet: PropTypes.func,
}

const mapStateToProps = state => {
  const {
    metamask: { network, selectedAddress, identities = {} },
  } = state
  const accounts = getMetaMaskAccounts(state)
  const numberOfExistingAccounts = Object.keys(identities).length
  const {
    appState: { defaultHdPaths, customHdPaths },
  } = state

  return {
    network,
    accounts,
    address: selectedAddress,
    numberOfExistingAccounts,
    defaultHdPaths,
    customHdPaths,
  }
}

const mapDispatchToProps = dispatch => {
  return {
    goHome: () => {
      dispatch(actions.goHome())
    },
    setHardwareWalletDefaultHdPath: ({device, path}) => {
      return dispatch(actions.setHardwareWalletDefaultHdPath({device, path}))
    },
    connectHardware: (deviceName, page, hdPath) => {
      return dispatch(actions.connectHardware(deviceName, page, hdPath))
    },
    checkHardwareStatus: (deviceName, hdPath) => {
      return dispatch(actions.checkHardwareStatus(deviceName, hdPath))
    },
    forgetDevice: (deviceName, clearAccounts) => {
      return dispatch(actions.forgetDevice(deviceName, clearAccounts))
    },
    unlockHardwareWalletAccount: (index, deviceName, hdPath) => {
      return dispatch(actions.unlockHardwareWalletAccount(index, deviceName, hdPath))
    },
    showImportPage: () => dispatch(actions.showImportPage()),
    showConnectPage: () => dispatch(actions.showConnectPage()),
    showForgetDevicePage: (device) => dispatch(actions.showForgetDevicePage(device)),
    showAlert: (msg) => dispatch(actions.showAlert(msg)),
    hideAlert: () => dispatch(actions.hideAlert()),
    finalizeInitProcess: () => dispatch(rifActions.finalizeInitProcess()),
    isInitProcessFinalized: () => dispatch(rifActions.isInitProcessFinalized()),
    setUsingHardwareWallet: (using) => dispatch(rifActions.setUsingHardwareWallet(using)),
  }
}

module.exports = connect(mapStateToProps, mapDispatchToProps)(ConnectHardwareForm)
