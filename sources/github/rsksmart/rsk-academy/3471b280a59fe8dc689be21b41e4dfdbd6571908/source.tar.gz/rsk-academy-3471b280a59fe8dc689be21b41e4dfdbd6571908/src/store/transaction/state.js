export const initialState = {
  transactions: [],
}
