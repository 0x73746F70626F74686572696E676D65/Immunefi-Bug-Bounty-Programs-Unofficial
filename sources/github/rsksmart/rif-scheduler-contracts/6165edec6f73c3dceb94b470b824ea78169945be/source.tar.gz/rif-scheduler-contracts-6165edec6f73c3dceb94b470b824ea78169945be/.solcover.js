module.exports = {
    skipFiles: ['test']
  };