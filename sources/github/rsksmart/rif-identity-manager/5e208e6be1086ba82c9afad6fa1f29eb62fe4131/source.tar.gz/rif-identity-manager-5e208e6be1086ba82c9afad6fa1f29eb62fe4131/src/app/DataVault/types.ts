export const ENCRYPTED = 'ENCRYPTED'
