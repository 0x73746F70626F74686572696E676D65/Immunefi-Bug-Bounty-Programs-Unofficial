declare module 'blakejs'
