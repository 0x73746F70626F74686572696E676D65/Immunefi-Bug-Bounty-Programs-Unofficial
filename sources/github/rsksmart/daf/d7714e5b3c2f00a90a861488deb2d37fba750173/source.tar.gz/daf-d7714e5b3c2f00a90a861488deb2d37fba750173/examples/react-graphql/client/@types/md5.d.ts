declare module 'md5'
