declare module 'ganache-cli'
