declare module 'did-resolver'
