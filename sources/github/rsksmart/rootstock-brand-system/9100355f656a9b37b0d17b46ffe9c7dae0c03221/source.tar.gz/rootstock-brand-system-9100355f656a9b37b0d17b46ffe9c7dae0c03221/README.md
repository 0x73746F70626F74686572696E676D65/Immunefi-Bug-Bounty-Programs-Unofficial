# Rootstock Brand System

Official brand assets for Rootstock, Bitcoin's financial infrastructure. Rootstock is the most secure and longest-running smart contract sidechain cryptographically and economically connected to Bitcoin the network and BTC the asset. 

Brand color: `#FF9100` · Website: [rootstock.io](https://rootstock.io) X: [@rootstock_io](https://x.com/rootstock_io))

---

## Logo System

### Logomark

| Preview | Name | Download |
|---------|------|----------|
| <img src="logos/png/logomark/Rootstock_Logomark_Colour.png" width="80"> | Rootstock Logomark (Colour) | [SVG](logos/svg/logomark/Rootstock_Logomark_Colour.svg) · [PNG](logos/png/logomark/Rootstock_Logomark_Colour.png) |
| <img src="logos/png/logomark/Rootstock_Logomark_Black.png" width="80"> | Rootstock Logomark (Black) | [SVG](logos/svg/logomark/Rootstock_Logomark_Black.svg) · [PNG](logos/png/logomark/Rootstock_Logomark_Black.png) |
| <img src="logos/png/logomark/Rootstock_Logomark_White.png" width="80"> | Rootstock Logomark (White) | [SVG](logos/svg/logomark/Rootstock_Logomark_White.svg) · [PNG](logos/png/logomark/Rootstock_Logomark_White.png) |

### Lock-up (Logomark + Wordmark)

| Preview | Name | Download |
|---------|------|----------|
| <img src="logos/png/lockup/Rootstock_Lockup_Colour.png" height="40"> | Rootstock Lock-up (Colour) | [SVG](logos/svg/lockup/Rootstock_Lockup_Colour.svg) · [PNG](logos/png/lockup/Rootstock_Lockup_Colour.png) |
| <img src="logos/png/lockup/Rootstock_Lockup_Black.png" height="40"> | Rootstock Lock-up (Black) | [SVG](logos/svg/lockup/Rootstock_Lockup_Black.svg) · [PNG](logos/png/lockup/Rootstock_Lockup_Black.png) |
| <img src="logos/png/lockup/Rootstock_Lockup_White.png" height="40"> | Rootstock Lock-up (White) | [SVG](logos/svg/lockup/Rootstock_Lockup_White.svg) · [PNG](logos/png/lockup/Rootstock_Lockup_White.png) |

---

## Color Palette

### Published Palette
Used on off-white backgrounds. Orange is the core brand color.

[![Published Palette](public/Rootstock_Colour_Published.png)](public/Rootstock_Colour_Published.png)

| Swatch | Name | Hex | RGB | Pantone |
|--------|------|-----|-----|---------|
| ![#000000](https://placehold.co/40x20/000000/000000.png) | Black | `#000000` | 0, 0, 0 | Black C |
| ![#FAF9F5](https://placehold.co/40x20/FAF9F5/FAF9F5.png) | White | `#FAF9F5` | 250, 249, 245 | 9043 C |
| ![#FF71E1](https://placehold.co/40x20/FF71E1/FF71E1.png) | Rootstock Pink | `#FF71E1` | 255, 113, 225 | 927 C |
| ![#79C600](https://placehold.co/40x20/79C600/79C600.png) | Rootstock Green | `#79C600` | 121, 198, 0 | 802 C |
| ![#FF9100](https://placehold.co/40x20/FF9100/FF9100.png) | Rootstock Orange | `#FF9100` | 255, 145, 0 | 151 C |

### Editor Palette
Used on black backgrounds. Do not use Purple, Cyan, or Lime on off-white backgrounds.

[![Editor Palette](public/Rootstock_Colour_Editor.png)](public/Rootstock_Colour_Editor.png)

| Swatch | Name | Hex | RGB | Pantone |
|--------|------|-----|-----|---------|
| ![#FAF9F5](https://placehold.co/40x20/FAF9F5/FAF9F5.png) | White | `#FAF9F5` | 250, 249, 245 | 9043 C |
| ![#000000](https://placehold.co/40x20/000000/000000.png) | Black | `#000000` | 0, 0, 0 | Black C |
| ![#FF71E1](https://placehold.co/40x20/FF71E1/FF71E1.png) | Rootstock Pink | `#FF71E1` | 255, 113, 225 | 927 C |
| ![#9E76FF](https://placehold.co/40x20/9E76FF/9E76FF.png) | Purple | `#9E76FF` | 158, 118, 255 | 814 C |
| ![#79C600](https://placehold.co/40x20/79C600/79C600.png) | Rootstock Green | `#79C600` | 121, 198, 0 | 802 C |
| ![#08FFD0](https://placehold.co/40x20/08FFD0/08FFD0.png) | Cyan | `#08FFD0` | 8, 255, 208 | 0821 C |
| ![#FF9100](https://placehold.co/40x20/FF9100/FF9100.png) | Rootstock Orange | `#FF9100` | 255, 145, 0 | 151 C |
| ![#DEFF1A](https://placehold.co/40x20/DEFF1A/DEFF1A.png) | Lime | `#DEFF1A` | 222, 255, 26 | 809 C |

> For full usage rules see the [Brand Guidelines PDF](public/Rootstock_Brand_Guidelines.pdf).

---

## Typography System

Rootstock uses a custom typeface family: **Rootstock Sans**, available in three variants.

[![Rootstock Typography System](public/Rootstock_Typography_System.png)](public/Rootstock_Typography_System.png)

| Font | Use Case | Download (OTF) | Download (Web) |
|------|----------|----------------|----------------|
| Rootstock Sans Headline | Display, headings, hero text | [OTF](fonts/otf/Rootstock-Sans-Headline.otf) | [WOFF](fonts/web/Rootstock-Sans-Headline.woff) · [WOFF2](fonts/web/Rootstock-Sans-Headline.woff2) |
| Rootstock Sans Body | Body copy, UI text | [OTF](fonts/otf/Rootstock-Sans-Body.otf) | [WOFF](fonts/web/Rootstock-Sans-Body.woff) · [WOFF2](fonts/web/Rootstock-Sans-Body.woff2) |
| Rootstock Sans Tags | Labels, tags, badges, captions | [OTF](fonts/otf/Rootstock-Sans-Tags.otf) | [WOFF](fonts/web/Rootstock-Sans-Tags.woff) · [WOFF2](fonts/web/Rootstock-Sans-Tags.woff2) |


---

## rBTC Token

rBTC is Bitcoin represented on Rootstock, maintaining a 1:1 relationship with BTC. It enables smart contracts, lending, borrowing, payments, and other applications on the network. Learn more at [rootstock.io/rbtc](https://rootstock.io/rbtc)

### Logo (Symbol + Wordmark)

| Preview | Variant | SVG | PNG |
|---------|---------|-----|-----|
| <img src="tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_128px.png" height="40"> | Primary | [SVG](tokens/rBTC/SVG/Logo/rBTC_Logo_Primary.svg) | [16](tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_16px.png) · [32](tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_32px.png) · [64](tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_64px.png) · [128](tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_128px.png) · [256](tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_256px.png) · [512](tokens/rBTC/PNG/Logo/rBTC_Logo_Primary_512px.png) |
| <img src="tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_128px.png" height="40"> | Inverted | [SVG](tokens/rBTC/SVG/Logo/rBTC_Logo_Inverted.svg) | [16](tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_16px.png) · [32](tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_32px.png) · [64](tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_64px.png) · [128](tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_128px.png) · [256](tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_256px.png) · [512](tokens/rBTC/PNG/Logo/rBTC_Logo_Inverted_512px.png) |
| <img src="tokens/rBTC/PNG/Logo/rBTC_Logo_Light_128px.png" height="40"> | Light | [SVG](tokens/rBTC/SVG/Logo/rBTC_Logo_Light.svg) | [16](tokens/rBTC/PNG/Logo/rBTC_Logo_Light_16px.png) · [32](tokens/rBTC/PNG/Logo/rBTC_Logo_Light_32px.png) · [64](tokens/rBTC/PNG/Logo/rBTC_Logo_Light_64px.png) · [128](tokens/rBTC/PNG/Logo/rBTC_Logo_Light_128px.png) · [256](tokens/rBTC/PNG/Logo/rBTC_Logo_Light_256px.png) · [512](tokens/rBTC/PNG/Logo/rBTC_Logo_Light_512px.png) |
| <img src="tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_128px.png" height="40"> | Dark | [SVG](tokens/rBTC/SVG/Logo/rBTC_Logo_Dark.svg) | [16](tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_16px.png) · [32](tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_32px.png) · [64](tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_64px.png) · [128](tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_128px.png) · [256](tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_256px.png) · [512](tokens/rBTC/PNG/Logo/rBTC_Logo_Dark_512px.png) |

### Symbol (Icon only)

| Preview | Variant | SVG | PNG |
|---------|---------|-----|-----|
| <img src="tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_64px.png" width="48"> | Primary | [SVG](tokens/rBTC/SVG/Symbol/rBTC_Symbol_Primary.svg) | [16](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_16px.png) · [32](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_32px.png) · [64](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_64px.png) · [128](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_128px.png) · [256](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_256px.png) · [512](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Primary_512px.png) |
| <img src="tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_64px.png" width="48"> | Inverted | [SVG](tokens/rBTC/SVG/Symbol/rBTC_Symbol_Inverted.svg) | [16](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_16px.png) · [32](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_32px.png) · [64](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_64px.png) · [128](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_128px.png) · [256](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_256px.png) · [512](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Inverted_512px.png) |
| <img src="tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_64px.png" width="48"> | Light | [SVG](tokens/rBTC/SVG/Symbol/rBTC_Symbol_Light.svg) | [16](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_16px.png) · [32](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_32px.png) · [64](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_64px.png) · [128](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_128px.png) · [256](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_256px.png) · [512](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Light_512px.png) |
| <img src="tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_64px.png" width="48"> | Dark | [SVG](tokens/rBTC/SVG/Symbol/rBTC_Symbol_Dark.svg) | [16](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_16px.png) · [32](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_32px.png) · [64](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_64px.png) · [128](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_128px.png) · [256](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_256px.png) · [512](tokens/rBTC/PNG/Symbol/rBTC_Symbol_Dark_512px.png) |

---

## Core Tokens

The following assets are provided for convenience to help developers and designers integrate Rootstock ecosystem tokens. These are made available as-is — always consult the issuer directly for official brand guidelines, usage terms, and up-to-date assets.

### Stablecoins

| Icon | Token | Description | Learn More |
|------|-------|-------------|------------|
| <img src="tokens/DOC/DOC.svg" width="40"> | **DOC** | The OG Bitcoin-collateralised stablecoin | [moneyonchain.com](https://moneyonchain.com/) |
| <img src="tokens/USDT0/USDT0.png" width="40"> | **USDT0** | A single, unified supply of Tether's USDT available across 20+ chains | [usdt0.to](https://usdt0.to/) |
| <img src="tokens/USDRIF/USDRIF.svg" width="40"> | **USDRIF** | A Bitcoin-secured algorithmic stablecoin | [rifonchain.com](https://rifonchain.com/) |

### Utility Tokens

| Icon | Token | Description | Learn More |
|------|-------|-------------|------------|
| <img src="tokens/RIF/RIF.png" width="40"> | **RIF** | Powering DAO Governance and RIFOS Tools | [rif.technology](https://rif.technology/) |
| <img src="tokens/MOC/MOC.svg" width="40"> | **MOC** | Money on Chain Governance Token | [moneyonchain.com](https://moneyonchain.com/moc-token/) |

---

## Brand Guidelines

The full brand guidelines document covers logo usage rules, color palette, typography scale, spacing, and do/don'ts.

[📄 Download Brand Guidelines PDF](public/Rootstock_Brand_Guidelines.pdf)

---

## Repository Layout

```
rootstock-brand-system/
├── logos/
│   ├── svg/
│   │   ├── lockup/          # Logomark + wordmark combinations (SVG)
│   │   └── logomark/        # Icon only (SVG)
│   └── png/
│       ├── lockup/          # Logomark + wordmark combinations (PNG)
│       └── logomark/        # Icon only (PNG)
├── fonts/
│   ├── otf/                 # Desktop fonts (OTF)
│   └── web/                 # Web fonts (WOFF, WOFF2)
├── dist/                    # npm package output
│   ├── css/                 # Compiled CSS with @font-face declarations
│   └── fonts/               # Web fonts for npm distribution
├── src/                     # npm package source
│   ├── font/                # Next.js localFont helpers
│   └── types/               # TypeScript definitions
├── tokens/
│   ├── rBTC/                # rBTC token logos (SVG + PNG, 4 variants, 6 sizes)
│   │   ├── SVG/
│   │   │   ├── Logo/
│   │   │   └── Symbol/
│   │   └── PNG/
│   │       ├── Logo/
│   │       └── Symbol/
│   ├── DOC/                 # Dollar on Chain stablecoin
│   ├── USDT0/               # USDT0 stablecoin
│   ├── USDRIF/              # USDRIF stablecoin
│   ├── RIF/                 # RIF utility token
│   └── MOC/                 # Money on Chain governance token
└── public/
    ├── Rootstock_Brand_Guidelines.pdf
    ├── Rootstock_Typography_System.png
    ├── Rootstock_Colour_Published.png
    └── Rootstock_Colour_Editor.png
```

---

## License

MIT License — see [LICENSE.md](LICENSE.md) for details.
