import structlog
from eth_utils import to_checksum_address

from raiden.constants import DISCOVERY_DEFAULT_ROOM, PATH_FINDING_BROADCASTING_ROOM
from raiden.exceptions import InvalidSettleTimeout
from raiden.network.blockchain_service import BlockChainService
from raiden.network.proxies.discovery import Discovery
from raiden.network.proxies.secret_registry import SecretRegistry
from raiden.network.proxies.service_registry import ServiceRegistry
from raiden.network.proxies.token_network_registry import TokenNetworkRegistry
from raiden.network.proxies.user_deposit import UserDeposit
from raiden.raiden_service import RaidenService
from raiden.settings import (
    DEFAULT_NAT_INVITATION_TIMEOUT,
    DEFAULT_NAT_KEEPALIVE_RETRIES,
    DEFAULT_NAT_KEEPALIVE_TIMEOUT,
    DEFAULT_NUMBER_OF_BLOCK_CONFIRMATIONS,
    DEFAULT_PATHFINDING_IOU_TIMEOUT,
    DEFAULT_PATHFINDING_MAX_FEE,
    DEFAULT_PATHFINDING_MAX_PATHS,
    DEFAULT_REVEAL_TIMEOUT,
    DEFAULT_SETTLE_TIMEOUT,
    DEFAULT_SHUTDOWN_TIMEOUT,
    DEFAULT_TRANSPORT_MATRIX_RETRY_INTERVAL,
    DEFAULT_TRANSPORT_RETRIES_BEFORE_BACKOFF,
    DEFAULT_TRANSPORT_THROTTLE_CAPACITY,
    DEFAULT_TRANSPORT_THROTTLE_FILL_RATE,
    DEFAULT_TRANSPORT_UDP_RETRY_INTERVAL,
    INITIAL_PORT,
    RED_EYES_CONTRACT_VERSION,
)
from raiden.utils import pex, typing
from raiden.utils.typing import Address, Any, Dict
from raiden_contracts.contract_manager import contracts_precompiled_path

log = structlog.get_logger(__name__)  # pylint: disable=invalid-name


class App:  # pylint: disable=too-few-public-methods
    DEFAULT_CONFIG = {
        "reveal_timeout": DEFAULT_REVEAL_TIMEOUT,
        "settle_timeout": DEFAULT_SETTLE_TIMEOUT,
        "contracts_path": contracts_precompiled_path(RED_EYES_CONTRACT_VERSION),
        "database_path": "",
        "transport_type": "udp",
        "blockchain": {"confirmation_blocks": DEFAULT_NUMBER_OF_BLOCK_CONFIRMATIONS},
        "transport": {
            "udp": {
                "external_ip": "",
                "external_port": INITIAL_PORT,
                "host": "",
                "nat_invitation_timeout": DEFAULT_NAT_INVITATION_TIMEOUT,
                "nat_keepalive_retries": DEFAULT_NAT_KEEPALIVE_RETRIES,
                "nat_keepalive_timeout": DEFAULT_NAT_KEEPALIVE_TIMEOUT,
                "port": INITIAL_PORT,
                "retries_before_backoff": DEFAULT_TRANSPORT_RETRIES_BEFORE_BACKOFF,
                "retry_interval": DEFAULT_TRANSPORT_UDP_RETRY_INTERVAL,
                "throttle_capacity": DEFAULT_TRANSPORT_THROTTLE_CAPACITY,
                "throttle_fill_rate": DEFAULT_TRANSPORT_THROTTLE_FILL_RATE,
            },
            "matrix": {
                # None causes fetching from url in raiden.settings.py::DEFAULT_MATRIX_KNOWN_SERVERS
                "available_servers": None,
                # TODO: Remove `PATH_FINDING_BROADCASTING_ROOM` when implementing #3735
                #       and fix the conditional in `raiden.ui.app:_setup_matrix`
                #       as well as the tests
                "global_rooms": [DISCOVERY_DEFAULT_ROOM, PATH_FINDING_BROADCASTING_ROOM],
                "retries_before_backoff": DEFAULT_TRANSPORT_RETRIES_BEFORE_BACKOFF,
                "retry_interval": DEFAULT_TRANSPORT_MATRIX_RETRY_INTERVAL,
                "server": "auto",
            },
        },
        "rpc": True,
        "console": False,
        "shutdown_timeout": DEFAULT_SHUTDOWN_TIMEOUT,
        "services": {
            "pathfinding_service_address": None,
            "pathfinding_max_paths": DEFAULT_PATHFINDING_MAX_PATHS,
            "pathfinding_max_fee": DEFAULT_PATHFINDING_MAX_FEE,
            "pathfinding_iou_timeout": DEFAULT_PATHFINDING_IOU_TIMEOUT,
            "monitoring_enabled": False,
        },
    }

    def __init__(
        self,
        config: typing.Dict,
        chain: BlockChainService,
        query_start_block: typing.BlockNumber,
        default_registry: TokenNetworkRegistry,
        default_secret_registry: SecretRegistry,
        default_service_registry: typing.Optional[ServiceRegistry],
        default_one_to_n_address: typing.Optional[Address],
        transport,
        raiden_event_handler,
        message_handler,
        discovery: Discovery = None,
        user_deposit: UserDeposit = None,
    ):
        raiden = RaidenService(
            chain=chain,
            query_start_block=query_start_block,
            default_registry=default_registry,
            default_one_to_n_address=default_one_to_n_address,
            default_secret_registry=default_secret_registry,
            default_service_registry=default_service_registry,
            transport=transport,
            raiden_event_handler=raiden_event_handler,
            message_handler=message_handler,
            config=config,
            discovery=discovery,
            user_deposit=user_deposit,
        )

        # check that the settlement timeout fits the limits of the contract
        invalid_settle_timeout = (
            config["settle_timeout"] < default_registry.settlement_timeout_min()
            or config["settle_timeout"] > default_registry.settlement_timeout_max()
            or config["settle_timeout"] < config["reveal_timeout"] * 2
        )
        if invalid_settle_timeout:
            raise InvalidSettleTimeout(
                (
                    "Settlement timeout for Registry contract {} must "
                    "be in range [{}, {}], is {}"
                ).format(
                    to_checksum_address(default_registry.address),
                    default_registry.settlement_timeout_min(),
                    default_registry.settlement_timeout_max(),
                    config["settle_timeout"],
                )
            )

        self.config = config
        self.discovery = discovery
        self.user_deposit = user_deposit
        self.raiden = raiden
        self.start_console = self.config["console"]

        # raiden.ui.console:Console assumes that a services
        # attribute is available for auto-registration
        self.services: Dict[str, Any] = dict()

    def __repr__(self):
        return "<{} {}>".format(self.__class__.__name__, pex(self.raiden.address))

    def start(self):
        """ Start the raiden app. """
        if self.raiden.stop_event.is_set():
            self.raiden.start()

    def stop(self):
        """ Stop the raiden app. """
        if not self.raiden.stop_event.is_set():
            self.raiden.stop()
