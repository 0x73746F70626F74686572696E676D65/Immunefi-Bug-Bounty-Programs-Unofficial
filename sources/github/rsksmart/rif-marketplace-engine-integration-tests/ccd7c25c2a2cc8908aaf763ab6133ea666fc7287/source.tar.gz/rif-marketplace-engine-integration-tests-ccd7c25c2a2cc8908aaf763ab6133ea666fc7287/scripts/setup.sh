npm i truffle -g
