import logging

from django.test import TestCase

from eth_account import Account
from eth_utils import keccak
from web3 import Web3

from gnosis.safe.safe_signature import SafeSignatureType

from ..indexers.tx_processor import SafeTxProcessor
from ..models import (InternalTxDecoded, ModuleTransaction,
                      MultisigConfirmation, MultisigTransaction, SafeContract,
                      SafeStatus)
from .factories import EthereumTxFactory, InternalTxDecodedFactory

logger = logging.getLogger(__name__)


class TestSafeTxProcessor(TestCase):
    def test_tx_processor_with_factory(self):
        tx_processor = SafeTxProcessor()
        owner = Account.create().address
        safe_address = Account.create().address
        fallback_handler = Account.create().address
        master_copy = Account.create().address
        threshold = 1
        tx_processor.process_decoded_transaction(
            InternalTxDecodedFactory(function_name='setup', owner=owner, threshold=threshold,
                                     fallback_handler=fallback_handler,
                                     internal_tx__to=master_copy,
                                     internal_tx___from=safe_address)
        )
        self.assertTrue(SafeContract.objects.get(address=safe_address))
        safe_status = SafeStatus.objects.get(address=safe_address)
        self.assertEqual(safe_status.enabled_modules, [])
        self.assertEqual(safe_status.fallback_handler, fallback_handler)
        self.assertEqual(safe_status.master_copy, master_copy)
        self.assertEqual(safe_status.owners, [owner])
        self.assertEqual(safe_status.threshold, threshold)

        # execTransaction should be calling addOwnerWithThreshold, so we process it together
        threshold = 2
        new_owner = Account.create().address
        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='addOwnerWithThreshold', owner=new_owner, threshold=threshold,
                                         internal_tx___from=safe_address)
            ])

        self.assertEqual(SafeStatus.objects.count(), 3)
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertCountEqual(safe_status.owners, [owner, new_owner])
        self.assertEqual(safe_status.nonce, 1)
        self.assertEqual(safe_status.threshold, threshold)

        another_owner = Account.create().address
        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='swapOwner', old_owner=owner, owner=another_owner,
                                         internal_tx___from=safe_address)
            ])
        self.assertEqual(SafeStatus.objects.count(), 5)
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertCountEqual(safe_status.owners, [another_owner, new_owner])
        self.assertEqual(safe_status.nonce, 2)
        self.assertEqual(safe_status.threshold, threshold)

        threshold = 1
        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='removeOwner', old_owner=another_owner, threshold=threshold,
                                         internal_tx___from=safe_address)
            ])
        self.assertEqual(SafeStatus.objects.count(), 7)
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.owners, [new_owner])
        self.assertEqual(safe_status.nonce, 3)
        self.assertEqual(safe_status.threshold, threshold)

        fallback_handler = Account.create().address
        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='setFallbackHandler', fallback_handler=fallback_handler,
                                         internal_tx___from=safe_address)
            ])
        self.assertEqual(SafeStatus.objects.count(), 9)
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.fallback_handler, fallback_handler)
        self.assertEqual(safe_status.nonce, 4)

        master_copy = Account.create().address
        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='changeMasterCopy', master_copy=master_copy,
                                         internal_tx___from=safe_address)
            ])
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.master_copy, master_copy)
        self.assertEqual(safe_status.nonce, 5)
        self.assertEqual(safe_status.enabled_modules, [])

        module = Account.create().address
        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='enableModule', module=module,
                                         internal_tx___from=safe_address)
            ])
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.enabled_modules, [module])
        self.assertEqual(safe_status.nonce, 6)

        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                InternalTxDecodedFactory(function_name='disableModule', module=module,
                                         internal_tx___from=safe_address)
            ])
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.enabled_modules, [])
        self.assertEqual(safe_status.nonce, 7)

        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransactionFromModule',
                                         internal_tx___from=safe_address),
            ])
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.nonce, 7)  # Nonce not incrementing
        self.assertEqual(ModuleTransaction.objects.count(), 1)

        self.assertEqual(MultisigTransaction.objects.count(),
                         InternalTxDecoded.objects.filter(function_name='execTransaction').count())

        # Test ApproveHash. For that we need the `previous_trace` to get the owner
        hash_to_approve = keccak(text='HariSeldon').hex()
        owner_approving = Account.create().address
        approve_hash_decoded_tx = InternalTxDecodedFactory(function_name='approveHash',
                                                           hash_to_approve=hash_to_approve,
                                                           internal_tx___from=safe_address,
                                                           internal_tx__trace_address='0,1,0')
        previous_approve_hash_internal_tx = InternalTxDecodedFactory(
            internal_tx__ethereum_tx=approve_hash_decoded_tx.internal_tx.ethereum_tx,
            internal_tx__trace_address='0,1',
            internal_tx___from=owner_approving,
        )

        tx_processor.process_decoded_transactions(
            [
                InternalTxDecodedFactory(function_name='execTransaction',
                                         internal_tx___from=safe_address),
                approve_hash_decoded_tx,
            ])
        safe_status = SafeStatus.objects.last_for_address(safe_address)
        self.assertEqual(safe_status.nonce, 8)
        multisig_confirmation = MultisigConfirmation.objects.get(multisig_transaction_hash=hash_to_approve)
        self.assertEqual(multisig_confirmation.signature_type, SafeSignatureType.APPROVED_HASH.value)

    def test_tx_processor_failed(self):
        tx_processor = SafeTxProcessor()
        # Event for Safes < 1.1.1
        logs = [{'data': '0x0034bff0dedc4c75f43df64a179ff26d56b99fa742fcfaeeee51e2da4e279b67',
                 'topics': ['0xabfd711ecdd15ae3a6b3ad16ff2e9d81aec026a39d16725ee164be4fbf857a7c']}]
        ethereum_tx = EthereumTxFactory(logs=logs)
        self.assertTrue(tx_processor.is_failed(ethereum_tx, logs[0]['data']))
        self.assertFalse(tx_processor.is_failed(ethereum_tx, Web3.keccak(text='hola').hex()))

        # Event for Safes >= 1.1.1
        safe_tx_hash = '0x4c15b21b9c3b57aebba3c274bf0a437950bd0eea46bc7a7b2df892f91f720311'
        logs = [{'data': '0x4c15b21b9c3b57aebba3c274bf0a437950bd0eea46bc7a7b2df892f91f720311'
                         '0000000000000000000000000000000000000000000000000000000000000000',
                 'topics': ['0x23428b18acfb3ea64b08dc0c1d296ea9c09702c09083ca5272e64d115b687d23']}]
        ethereum_tx = EthereumTxFactory(logs=logs)
        self.assertTrue(tx_processor.is_failed(ethereum_tx, safe_tx_hash))
        self.assertFalse(tx_processor.is_failed(ethereum_tx, Web3.keccak(text='hola').hex()))
