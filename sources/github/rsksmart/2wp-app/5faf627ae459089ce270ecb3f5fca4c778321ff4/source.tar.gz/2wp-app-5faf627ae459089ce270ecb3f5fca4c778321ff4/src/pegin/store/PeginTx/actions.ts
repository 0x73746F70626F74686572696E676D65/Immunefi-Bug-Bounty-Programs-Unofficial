import { ActionTree } from 'vuex';
import axios, { AxiosResponse } from 'axios';
import * as rskUtils from '@rsksmart/rsk-utils';
import * as constants from '@/common/store/constants';
import {
  LedgerService,
  TrezorService, LeatherService,
  EnkryptService, XverseService,
} from '@/common/services';
import SatoshiBig from '@/common/types/SatoshiBig';
import { EnvironmentAccessorService } from '@/common/services/enviroment-accessor.service';
import { captureError } from '@/sentry';
import {
  AccountBalance, FeeAmountData, NormalizedTx, RootState,
  PeginConfiguration, PegInTxState, WalletAddress,
  BtcAccount, BtcWallet, MiningSpeedFee, UtxoListPerAccount, Utxo,
  WeiBig,
} from '@/common/types';
import {
  getBalanceFromUtxoList,
  getClearPeginTxState, getCookie, isBTCAmountValidRegex, minBigInt, setCookie,
} from '@/common/utils';
import PeginConfigurationService from '@/pegin/services/peginConfigurationService';
import ReownService from '@/common/services/ReownService';
import { BigNumber } from 'ethers';
import { BridgeService } from '@/common/services/BridgeService';
import TxFeeService from '../../services/TxFeeService';

export const actions: ActionTree<PegInTxState, RootState> = {
  [constants.IS_TREZOR_CONNECTED]: ({ commit }, trezorConnected: boolean) => {
    commit(constants.PEGIN_TX_SET_TREZOR_CONNECTED, trezorConnected);
  },
  [constants.PEGIN_TX_ADD_PEGIN_CONFIGURATION]: ({ commit }) => {
    PeginConfigurationService.getPeginConfiguration()
      .then((localConfig: PeginConfiguration) => {
        commit(constants.PEGIN_TX_SET_PEGIN_CONFIGURATION, localConfig);
      });
  },
  [constants.PEGIN_TX_ADD_BITCOIN_WALLET]: (
    { commit, state },
    { bitcoinWallet, connectedAddress }:
    { bitcoinWallet: BtcWallet, connectedAddress: WalletAddress },
  ) => {
    commit(constants.PEGIN_TX_SET_BITCOIN_WALLET, bitcoinWallet);
    try {
      switch (bitcoinWallet) {
        case constants.WALLET_NAMES.TREZOR.long_name:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, new TrezorService());
          break;
        case constants.WALLET_NAMES.LEDGER.long_name:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, new LedgerService());
          break;
        case constants.WALLET_NAMES.LEATHER.long_name:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, new LeatherService());
          break;
        case constants.WALLET_NAMES.XVERSE.long_name:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, new XverseService());
          break;
        case constants.WALLET_NAMES.ENKRYPT.long_name:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, new EnkryptService());
          break;
        case constants.WALLET_NAMES.REOWN.long_name:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, new ReownService(connectedAddress));
          break;
        default:
          commit(constants.PEGIN_TX_SET_WALLET_SERVICE, undefined);
          break;
      }
    } catch (e) {
      captureError(e, { source: constants.PEGIN_TX_ADD_BITCOIN_WALLET });
      commit(constants.PEGIN_TX_SET_WALLET_SERVICE, undefined);
      return;
    }
    commit(
      constants.PEGIN_TX_WALLET_SERVICE_SUBSCRIBE,
      (balance: AccountBalance, addressList: WalletAddress[], utxoList: UtxoListPerAccount) => {
        const loadingBalance = state.walletService ? state.walletService.isLoadingBalances : false;
        commit(constants.PEGIN_TX_SET_BALANCE, balance);
        commit(constants.PEGIN_TX_SET_ADDRESS_LIST, addressList);
        commit(constants.PEGIN_TX_SET_UTXO_LIST, utxoList);
        commit(constants.PEGIN_TX_SET_LOADING_BALANCE, loadingBalance);
      },
    );
  },
  [constants.PEGIN_TX_ADD_BITCOIN_PRICE]: ({ commit }) => {
    const storedPrice = getCookie('BtcPrice');
    if (storedPrice) {
      commit(constants.PEGIN_TX_SET_BITCOIN_PRICE, BigNumber.from(storedPrice).toNumber());
    } else {
      axios.get(constants.COINGECKO_API_URL)
        .then((response: AxiosResponse) => {
          const [result] = response.data;
          setCookie('BtcPrice', result.current_price, constants.COOKIE_EXPIRATION_HOURS);
          commit(constants.PEGIN_TX_SET_BITCOIN_PRICE, result.current_price);
        })
        .catch((e) => {
          captureError(e, { source: constants.PEGIN_TX_ADD_BITCOIN_PRICE });
          commit(constants.PEGIN_TX_SET_BITCOIN_PRICE, 0);
        });
    }
  },
  [constants.PEGIN_TX_CLEAR_STATE]: ({ commit }): void => {
    commit(constants.PEGIN_TX_CLEAR);
  },
  [constants.PEGIN_TX_INIT]: ({ dispatch }):
    Promise<void> => dispatch(constants.PEGIN_TX_ADD_BITCOIN_PRICE)
    .then(() => dispatch(constants.PEGIN_TX_ADD_PEGIN_CONFIGURATION)),

  [constants.PEGIN_TX_SELECT_ACCOUNT_TYPE]: ({ commit }, accountType: BtcAccount): void => {
    commit(constants.PEGIN_TX_SET_ACCOUNT_TYPE, accountType);
  },
  [constants.PEGIN_TX_ADD_AMOUNT_TO_TRANSFER]:
    ({ commit, dispatch, state }, amount: SatoshiBig): void => {
      commit(constants.PEGIN_TX_SET_AMOUNT_TO_TRANSFER, amount);
      const minValue = new SatoshiBig(state.peginConfiguration.minValue, 'btc');
      const isValidAmount = isBTCAmountValidRegex(amount.toBTCString()) && amount.gte(minValue);
      if (isValidAmount) {
        dispatch(constants.PEGIN_TX_CALCULATE_TX_FEE);
      }
      if (amount.eq(0)) {
        commit(constants.PEGIN_TX_SET_CALCULATED_TX_FEE, getClearPeginTxState().calculatedFees);
      }
    },
  [constants.PEGIN_TX_CALCULATE_TX_FEE]: ({ commit, state, getters }):
    Promise<void> => new Promise<void>((resolve, reject) => {
      if (!state.selectedAccount) {
        return;
      }
      const selectedBalance = getters[constants.PEGIN_TX_GET_SELECTED_BALANCE] as SatoshiBig;
      if (!selectedBalance.gt(0)) {
        return;
      }
      const amount = BigNumber.from(state.amountToTransfer.toSatoshiString()).toNumber();
      if (amount === 0) {
        return;
      }
      commit(constants.PEGIN_TX_SET_LOADING_FEE, true);
      const utxoList = getters[constants.PEGIN_TX_GET_ACCOUNT_UTXO_LIST] as Utxo[];
      if (utxoList.length) {
        const feePromises = [
          TxFeeService.getTxFee(
            state.amountToTransfer,
            utxoList,
            constants.BITCOIN_SLOW_FEE_LEVEL,
          ),
          TxFeeService.getTxFee(
            state.amountToTransfer,
            utxoList,
            constants.BITCOIN_AVERAGE_FEE_LEVEL,
          ),
          TxFeeService.getTxFee(
            state.amountToTransfer,
            utxoList,
            constants.BITCOIN_FAST_FEE_LEVEL,
          ),
        ];
        Promise.all(feePromises)
          .then(([slow, average, fast]) => {
            const fees: FeeAmountData = {
              slow: {
                amount: new SatoshiBig(slow.fee.amount, 'satoshi'),
                enoughBalance: slow.fee.enoughBalance,
                selectedUtxoList: slow.selectedUtxoList,
              },
              average: {
                amount: new SatoshiBig(average.fee.amount, 'satoshi'),
                enoughBalance: average.fee.enoughBalance,
                selectedUtxoList: average.selectedUtxoList,
              },
              fast: {
                amount: new SatoshiBig(fast.fee.amount, 'satoshi'),
                enoughBalance: fast.fee.enoughBalance,
                selectedUtxoList: fast.selectedUtxoList,
              },
            };
            commit(constants.PEGIN_TX_SET_CALCULATED_TX_FEE, fees);
            commit(constants.PEGIN_TX_SET_LOADING_FEE, false);
            resolve();
          })
          .catch(reject);
      }
    }),
  [constants.PEGIN_TX_ADD_RSK_ADDRESS]: ({ commit }, address: string): void => {
    const chainId = EnvironmentAccessorService
      .getEnvironmentVariables().vueAppCoin === constants.BTC_NETWORK_MAINNET ? 30 : 31;
    const rskChecksumAddress = rskUtils.toChecksumAddress(address, chainId);
    commit(constants.PEGIN_TX_SET_RSK_ADDRESS, rskChecksumAddress);
  },
  [constants.PEGIN_TX_SELECT_FEE_LEVEL]: ({ commit }, feeLevel: MiningSpeedFee): void => {
    commit(constants.PEGIN_TX_SET_SELECTED_FEE_LEVEL, feeLevel);
  },
  [constants.PEGIN_TX_ADD_IS_VALID_AMOUNT]: ({ commit }, isValid: boolean): void => {
    commit(constants.PEGIN_TX_SET_IS_VALID_AMOUNT, isValid);
  },
  [constants.PEGIN_TX_ADD_NORMALIZED_TX]: ({ commit }, tx: NormalizedTx): void => {
    commit(constants.PEGIN_TX_SET_NORMALIZED_TX, tx);
  },
  [constants.PEGIN_TX_START_ASKING_FOR_BALANCE]: ({ state }): Promise<void> => {
    if (state.walletService) {
      return state.walletService
        .startAskingForBalance();
    }
    return Promise.reject(new Error('Wallet service is not set'));
  },
  [constants.PEGIN_TX_STOP_ASKING_FOR_BALANCE]: ({ state }): Promise<void> => {
    if (state.walletService) {
      return state.walletService.stopAskingForBalance();
    }
    return Promise.reject(new Error('Wallet service is not set'));
  },
  [constants.PEGIN_TX_ADD_STATUS_SAFE_FEE]: ({ commit }, fee: string): void => {
    commit(constants.PEGIN_TX_SET_STATUS_SAFE_FEE, fee);
  },
  [constants.PEGIN_TX_ADD_STATUS_REFUND_ADDRESS]: ({ commit }, refundAddress: string): void => {
    commit(constants.PEGIN_TX_SET_STATUS_REFUND_ADDRESS, refundAddress);
  },
  [constants.PEGIN_TX_ADD_STATUS_TX_ID]: ({ commit }, txId: string): void => {
    commit(constants.PEGIN_TX_SET_STATUS_TX_ID, txId);
  },
  [constants.PEGIN_TX_ADD_PEGIN_TYPE]: ({ commit }, peginType: constants.peginType): void => {
    commit(constants.PEGIN_TX_SET_PEGIN_TYPE, peginType);
  },
  [constants.PEGIN_TX_SET_CURRENT_VIEW]: ({ commit }, view: string): void => {
    commit(constants.PEGIN_TX_SET_VIEW, view);
  },
  [constants.PEGIN_TX_TOGGLE_SELECTED_UTXO]: ({ commit, dispatch }, { txId, selected }:
    {txId: string, selected: boolean }): void => {
    commit(constants.PEGIN_TX_SET_SELECTED_UTXO, { txId, selected });
    dispatch(constants.PEGIN_TX_CALCULATE_BALANCES);
  },
  [constants.PEGIN_TX_CALCULATE_BALANCES]: ({ commit, state }): void => {
    const balances: AccountBalance = {
      legacy: getBalanceFromUtxoList(state.utxoList.legacy),
      segwit: getBalanceFromUtxoList(state.utxoList.segwit),
      nativeSegwit: getBalanceFromUtxoList(state.utxoList.nativeSegwit),
    };
    commit(constants.PEGIN_TX_SET_BALANCE, balances);
  },
  [constants.PEGIN_TX_ESTIMATE_MAX_VALUE]:
  ({ commit, getters }) => new Promise<SatoshiBig>((resolve) => {
    const selectedBalance = getters[constants.PEGIN_TX_GET_SELECTED_BALANCE] as SatoshiBig
      || new SatoshiBig(0, 'satoshi');
    const utxoList = getters[constants.PEGIN_TX_GET_ACCOUNT_UTXO_LIST] as Utxo[];
    TxFeeService.getTxFee(
      selectedBalance,
      utxoList,
      constants.BITCOIN_FAST_FEE_LEVEL,
    )
      .then((fast) => {
        const maxFee = new SatoshiBig(fast.fee.amount, 'satoshi')
        || new SatoshiBig(0, 'satoshi');
        commit(constants.PEGIN_TX_SET_MAX_FEE, maxFee);

        const maxValue = selectedBalance.safeMinus(maxFee);
        resolve(maxValue);
      })
      .catch(async (e) => {
        captureError(e, { source: constants.PEGIN_TX_ESTIMATE_MAX_VALUE });
        const bridgeService = new BridgeService();
        const defaultMaxValue = minBigInt(
          selectedBalance.toWeiBigIntUnsafe(),
          await bridgeService.getLockingCap(),
        );
        resolve(SatoshiBig.fromWeiBig(new WeiBig(defaultMaxValue, 'wei')));
      });
  }),
};
