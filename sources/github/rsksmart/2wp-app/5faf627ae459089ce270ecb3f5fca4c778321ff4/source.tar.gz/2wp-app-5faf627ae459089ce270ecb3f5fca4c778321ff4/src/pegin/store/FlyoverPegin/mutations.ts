import {
  FlyoverPeginState, LiquidityProvider2WP, PeginQuote, SatoshiBig,
  Utxo,
} from '@/common/types';
import { MutationTree } from 'vuex';
import * as constants from '@/common/store/constants';
import { getClearFlyoverPeginState } from '@/common/utils';

export const mutations: MutationTree<FlyoverPeginState> = {
  [constants.FLYOVER_PEGIN_SET_AMOUNT]: (state, amount: SatoshiBig) => {
    state.amountToTransfer = amount;
  },
  [constants.FLYOVER_PEGIN_SET_ROOTSTOCK_ADDRESS]: (state, address: string) => {
    state.rootstockRecipientAddress = address;
  },
  [constants.FLYOVER_PEGIN_SET_PROVIDERS]: (state, providers: Array<LiquidityProvider2WP>) => {
    state.liquidityProviders = providers;
  },
  [constants.FLYOVER_PEGIN_SET_QUOTES]: (state, quotes: Record<number, Array<PeginQuote>>) => {
    state.quotes = quotes;
  },
  [constants.FLYOVER_PEGIN_SET_SELECTED_QUOTE]: (state, quoteHash: string) => {
    state.selectedQuoteHash = quoteHash;
  },
  [constants.FLYOVER_PEGIN_PROVIDERS_SET_AVAILABLE_LIQUIDITY]: (state, payload) => {
    const { providerId, peginLiquidity } = payload;
    const providers = state.liquidityProviders;
    providers.forEach((provider, idx) => {
      if (provider.id === providerId) {
        state.liquidityProviders[idx].pegin.availableLiquidity = peginLiquidity;
      }
    });
  },
  [constants.FLYOVER_PEGIN_SET_ACCEPTED_QUOTE_SIGNATURE]: (state, quoteSignature: string) => {
    state.acceptedQuoteSignature = quoteSignature;
  },
  [constants.FLYOVER_PEGIN_SET_QR_DESTINATION_ADDRESS]: (state, { quoteHash, btcAddress }) => {
    Object.entries(state.quotes).forEach(async ([, quotes]) => {
      const selectedQuote = quotes.find((quote) => quote.quoteHash === quoteHash);
      if (selectedQuote) {
        const qrCode = await state.flyoverService.flyover?.generateQrCode(
          btcAddress,
          selectedQuote.valueToTransfer.toBTCString(),
          constants.QRCodeNetworks.BITCOIN,
        ) ?? '';
        selectedQuote.qrCode = qrCode;
        selectedQuote.recipientBtcAddress = btcAddress;
      }
    });
  },
  [constants.FLYOVER_PEGIN_SET_MAX_VALUES]: (
    state,
    {
      isMaxSelected, recommendedPegin, maxFee, maxSelectedUtxoList, maxValueToSend,
    }:
    {
      isMaxSelected: boolean,
      recommendedPegin: SatoshiBig,
      maxFee: SatoshiBig,
      maxSelectedUtxoList: Utxo[],
      maxValueToSend: SatoshiBig,
    },
  ) => {
    state.isMaxSelected = isMaxSelected;
    state.recommendedPegin = recommendedPegin;
    state.maxFee = maxFee;
    state.maxSelectedUtxoList = maxSelectedUtxoList;
    state.maxValueToSend = maxValueToSend;
  },
  [constants.FLYOVER_PEGIN_RESET_MAX_SELECTED]: (state) => {
    state.isMaxSelected = false;
  },
  [constants.FLYOVER_PEGIN_SET_CLEAR_STATE]: (state) => {
    const clearState = getClearFlyoverPeginState();
    Object.assign(state, clearState);
  },
};
