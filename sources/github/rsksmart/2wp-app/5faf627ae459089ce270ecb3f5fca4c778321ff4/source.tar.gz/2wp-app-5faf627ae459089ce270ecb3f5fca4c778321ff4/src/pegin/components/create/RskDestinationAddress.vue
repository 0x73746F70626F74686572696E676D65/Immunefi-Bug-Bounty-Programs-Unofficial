<template>
  <v-row no-gutters class="d-flex flex-column pa-0 form">
    <span class="text-body-sm mb-4">
      Destination Address
    </span>
    <v-text-field
        class="text-body-sm flex-grow-0"
        density="comfortable"
        :class="(!isValidInputAddress && isInputFilled) && 'input-error'"
        v-model="address"
        :readonly="Boolean(connectedAccount)"
        flat
        hide-details
        rounded="lg"
        variant="solo"
        :placeholder="`Paste your ${environmentContext.getRbtcTicker()} Address`">
      <template #append-inner>
        <v-btn size="small" class="text-button" @click="connectOrDisconnect">
          {{ connectedAccount ? 'Disconnect' : 'Connect Wallet' }}
        </v-btn>
      </template>
    </v-text-field>
    <v-alert v-show="isAmountFilled && !isInputFilled"
      color="orange" density="compact" variant="text" class="px-0">
      Please inform destination address
    </v-alert>
    <v-alert v-show="!isValidInputAddress && isInputFilled" type="error"
      color="orange" density="compact">
      Not an address
    </v-alert>
    <v-alert v-show="notChecksummedAddressWarning" type="warning"
      color="orange" density="compact" variant="outlined">
      <span> Not a checksummed address. To fix it
        <v-btn variant="text" style="text-decoration: underline" class="px-0"
          @click="toValidChecksumAddress">
          click here
        </v-btn>.
      </span>
    </v-alert>
  </v-row>
</template>

<script lang="ts">
import {
  computed, defineComponent, onMounted, ref, watch,
} from 'vue';
import { useAction, useGetter } from '@/common/store/helper';
import * as rskUtils from '@rsksmart/rsk-utils';
import * as constants from '@/common/store/constants';
import { EnvironmentAccessorService } from '@/common/services/enviroment-accessor.service';
import EnvironmentContextProviderService from '@/common/providers/EnvironmentContextProvider';
import { useWallet } from '@/common/composables/useWallet';

export default defineComponent({
  name: 'RskDestinationAddress',
  props: {
    isAmountFilled: {
      type: Boolean,
      required: true,
    },
  },
  setup(props, context) {
    const environmentContext = EnvironmentContextProviderService.getEnvironmentContext();
    const connectedAccount = useGetter<string>('web3Session', constants.SESSION_GET_CHECKSUMMED_ACCOUNT);
    const address = ref(connectedAccount.value);
    const { isAddress, isValidAddress, toChecksumAddress } = rskUtils;

    const CHAIN_ID = EnvironmentAccessorService.getEnvironmentVariables()
      .vueAppCoin === constants.BTC_NETWORK_MAINNET ? 30 : 31;

    const notChecksummedAddressWarning = computed(() => {
      if (isAddress(address.value)) {
        return !isValidAddress(address.value, CHAIN_ID);
      }
      return false;
    });

    const isInputFilled = computed(() => address.value !== '');
    const isValidInputAddress = computed(() => isInputFilled.value && isAddress(address.value));
    const setRskAddress = useAction('pegInTx', constants.PEGIN_TX_ADD_RSK_ADDRESS);
    const setRskAddressForFlyover = useAction('flyoverPegin', constants.FLYOVER_PEGIN_ADD_ROOTSTOCK_ADDRESS);
    const { connect, disconnect } = useWallet();

    const clearSession = useAction('web3Session', constants.WEB3_SESSION_CLEAR_ACCOUNT);

    function checkAndEmmitValidAddress() {
      if (isValidInputAddress.value) {
        setRskAddress(address.value);
        setRskAddressForFlyover(address.value);
      }
      context.emit('validAddress', isValidInputAddress.value, address.value);
    }

    function connectOrDisconnect() {
      if (connectedAccount.value) {
        clearSession()
          .then(() => disconnect())
          .then(() => { address.value = ''; });
      } else {
        connect();
      }
    }

    function toValidChecksumAddress() {
      address.value = toChecksumAddress(address.value, CHAIN_ID);
    }

    if (connectedAccount.value) {
      setRskAddress(address.value);
    }

    onMounted(() => {
      checkAndEmmitValidAddress();
    });

    watch(address, () => {
      checkAndEmmitValidAddress();
    });
    watch(connectedAccount, () => {
      address.value = connectedAccount.value;
      checkAndEmmitValidAddress();
    });

    return {
      address,
      connectedAccount,
      connectOrDisconnect,
      isValidInputAddress,
      notChecksummedAddressWarning,
      isInputFilled,
      toValidChecksumAddress,
      environmentContext,
    };
  },
});
</script>
