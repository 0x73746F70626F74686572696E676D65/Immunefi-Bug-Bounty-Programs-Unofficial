import {get, getModelSchemaRef, param, response,} from '@loopback/rest';
import {inject} from "@loopback/core";
import {getLogger, Logger} from "../utils/logger";
import {LastBlockInfo, PeginStatus, Status, TxStatus, TxStatusType} from '../models';
import {PeginStatusError} from "../models/pegin-status-error.model";
import {ServicesBindings} from "../dependency-injection-bindings";
import {PeginStatusService, PegoutStatusService, FlyoverService, BitcoinService} from "../services";
import {PegoutStatuses} from "../models/rsk/pegout-status-data-model";
import {ensure0x, remove0x} from '../utils/hex-utils';
import {isValidTxId} from '../utils/tx-validator';
import {TX_TYPE_PEGIN} from '../constants';


export class TxStatusController {
  private logger: Logger;

  constructor(
      @inject(ServicesBindings.PEGIN_STATUS_SERVICE)
      protected peginStatusService: PeginStatusService,
      @inject(ServicesBindings.PEGOUT_STATUS_SERVICE)
      protected pegoutStatusService: PegoutStatusService,
      @inject(ServicesBindings.FLYOVER_SERVICE)
      protected flyoverService: FlyoverService,
      @inject(ServicesBindings.BITCOIN_SERVICE)
      protected bitcoinService: BitcoinService,
  ) {
    this.logger = getLogger('tx-status-controller');
  }

  /**
   * `GET /tx-status/{txId}` — looks up a transaction's status without knowing
   * its type ahead of time: verifies Blockbook is in sync, then tries native
   * peg-in, native peg-out, and Flyover (in that order), returning the first
   * one that has details.
   *
   * @param txId - Transaction id/hash, either `0x`-prefixed or bare 64-char hex.
   * @returns A `TxStatus` describing the outcome: the matched type with its details, `INVALID_DATA` if `txId` is malformed or nothing matched, or `BLOCKBOOK_FAILED`/`UNEXPECTED_ERROR` on lookup failures.
   */
  @get('/tx-status/{txId}')
  @response(200, {
    description: 'TxStatus model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(TxStatus, {includeRelations: true}),
      },
    },
  })
  async getTxStatus(
    @param.path.string('txId', {
      schema: {
        type: 'string',
        pattern: '^[a-fA-F0-9]{64}$|^0x[a-fA-F0-9]{64}$',
      },
    }) txId: string,
  ): Promise<TxStatus> {
    const startTime = performance.now();
    const status = await this.searchTryingAllTypes(txId);
    this.logTime(startTime);
    return status;
  }

  /**
   * `GET /tx-status-by-type/{txId}/{txType}` — same lookup as `getTxStatus`,
   * but scoped to a single known `txType` instead of trying every protocol in turn.
   *
   * @param txId - Transaction id/hash, either `0x`-prefixed or bare 64-char hex.
   * @param txType - One of `TxStatusType`'s pegin/pegout/flyover-pegin/flyover-pegout values.
   * @returns A `TxStatus` for the requested type/id, `INVALID_DATA` if `txId` is malformed, or `UNEXPECTED_ERROR` if nothing was found for the given `txType` (including an unrecognized `txType`) or the lookup failed.
   */
  @get('/tx-status-by-type/{txId}/{txType}')
  @response(200, {
    description: 'TxStatus model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(TxStatus, {includeRelations: true}),
      },
    },
  })
  async getTxStatusByType(
    @param.path.string('txId', {
      schema: {
        type: 'string',
        pattern: '^[a-fA-F0-9]{64}$|^0x[a-fA-F0-9]{64}$',
      },
    }) txId: string,
    @param.path.string('txType') txType: string,
  ): Promise<TxStatus> {
    const startTime = performance.now();
    let txStatus:TxStatus;
    this.logger.debug({method: 'getTxStatusByType', txType, txId});

    if (!isValidTxId(txId)) {
      this.logger.debug({method: 'getTxStatusByType', txId}, 'the provided tx id is invalid');
      txStatus = new TxStatus({
        type: TxStatusType.INVALID_DATA,
      });
      this.logTime(startTime);
      return txStatus;
    }

    if(txType === TxStatusType.PEGOUT){ 
      try {
        const nativePegoutStatus = await this.getNativePegoutStatus(txId);
        if(nativePegoutStatus.txDetails){
          this.logger.info(
            {method: 'getTxStatusByType', txId, txType, type: nativePegoutStatus.type, protocol: 'NATIVE'},
            'Transaction status found',
          );
          this.logTime(startTime);
          return nativePegoutStatus;
        }
      } catch (err) {
        this.logger.error({method: 'getTxStatusByType', err, txId, txType}, 'Unexpected error retrieving tx status');
        txStatus = new TxStatus({
          type: TxStatusType.UNEXPECTED_ERROR,
        });
        this.logTime(startTime);
        return txStatus;
      }
    }
    if(txType === TxStatusType.PEGIN){ 
      try {
        const nativePeginStatus = await this.getNativePeginStatus(txId);
        if(nativePeginStatus.txDetails){
          this.logger.info(
            {method: 'getTxStatusByType', txId, txType, type: nativePeginStatus.type, protocol: 'NATIVE'},
            'Transaction status found',
          );
          this.logTime(startTime);
          return nativePeginStatus;
        }
      } catch (err) {
        this.logger.error({method: 'getTxStatusByType', err, txId, txType}, 'Unexpected error retrieving tx status');
        txStatus = new TxStatus({
          type: TxStatusType.UNEXPECTED_ERROR,
        });
        this.logTime(startTime);
        return txStatus;
      }
    }
    if(txType === TxStatusType.FLYOVER_PEGIN || txType === TxStatusType.FLYOVER_PEGOUT){ 
      try {
        const flyoverStatus = await this.getFlyoverStatus(txId);
        if(flyoverStatus.txDetails){
          this.logger.info(
            {method: 'getTxStatusByType', txId, txType, type: flyoverStatus.type, protocol: 'FLYOVER'},
            'Transaction status found',
          );
          this.logTime(startTime);
          return flyoverStatus;
        }
      } catch (err) {
        this.logger.error({method: 'getTxStatusByType', err, txId, txType}, 'Unexpected error retrieving tx status');
        txStatus = new TxStatus({
          type: TxStatusType.UNEXPECTED_ERROR,
        });
        this.logTime(startTime);
        return txStatus;
      }
    }

    this.logger.info({method: 'getTxStatusByType', txId, txType}, 'Transaction not found');
    txStatus = new TxStatus({
      type: TxStatusType.UNEXPECTED_ERROR,
    });
    this.logTime(startTime);
    return txStatus;
  }

  private async searchTryingAllTypes(txId: string): Promise<TxStatus> {
    let txStatus:TxStatus;
    
    if (!isValidTxId(txId)) {
      this.logger.debug({method: 'searchTryingAllTypes', txId}, 'the provided tx id is invalid');
      txStatus = new TxStatus({
        type: TxStatusType.INVALID_DATA,
      });
      return txStatus;
    }

    try {
      const info = await this.verifyBlockBook();
      this.logger.debug({method: 'searchTryingAllTypes'}, 'trying to get block book information');
      if (!info.inSync) {
        this.logger.debug(
          {method: 'searchTryingAllTypes', initialSync: info.intialSync, inSync: info.inSync},
          'Blockbook not in sync',
        );
        return new TxStatus({ type: TxStatusType.BLOCKBOOK_FAILED });
      }
    } catch (err) {
      this.logger.error({method: 'searchTryingAllTypes', err});
      return new TxStatus({ type: TxStatusType.BLOCKBOOK_FAILED });
    }

    try {
      const nativePeginStatus = await this.getNativePeginStatus(txId);
      if(nativePeginStatus.txDetails){
        this.logger.info(
          {method: 'searchTryingAllTypes', txId, type: nativePeginStatus.type, protocol: 'NATIVE'},
          'Transaction status found',
        );
        return nativePeginStatus;
      }
    } catch (err) {
      this.logger.error({method: 'searchTryingAllTypes', err, txId});
      txStatus = new TxStatus({
        type: TxStatusType.UNEXPECTED_ERROR,
      });
      return txStatus;
    }

    try {
      const nativePegoutStatus = await this.getNativePegoutStatus(txId);
      if(nativePegoutStatus.txDetails){
        this.logger.info(
          {method: 'searchTryingAllTypes', txId, type: nativePegoutStatus.type, protocol: 'NATIVE'},
          'Transaction status found',
        );
        return nativePegoutStatus;
      }
    } catch (err) {
      this.logger.error({method: 'searchTryingAllTypes', err, txId});
      txStatus = new TxStatus({
        type: TxStatusType.UNEXPECTED_ERROR,
      });
      return txStatus;
    }

    try {
      const flyoverStatus = await this.getFlyoverStatus(txId);
      if(flyoverStatus.txDetails){
        this.logger.info(
          {method: 'searchTryingAllTypes', txId, type: flyoverStatus.type, protocol: 'FLYOVER'},
          'Transaction status found',
        );
        return flyoverStatus;
      }
    } catch (err) {
      this.logger.error({method: 'searchTryingAllTypes', err, txId});
      txStatus = new TxStatus({
        type: TxStatusType.UNEXPECTED_ERROR,
      });
      return txStatus;
    }

    this.logger.info({method: 'searchTryingAllTypes', txId}, 'Transaction not found');
    txStatus = new TxStatus({
      type: TxStatusType.INVALID_DATA,
    });
    return txStatus;
  }

  private logTime(startTime:number){
    const endTime = performance.now();
    const totalTime = endTime - startTime;
    this.logger.debug({method: 'logTime', durationMs: totalTime}, 'Execution time');
  }

  private async verifyBlockBook(): Promise<LastBlockInfo> {
    const info = await this.bitcoinService.getLastBlock();
    this.logger.debug({method: 'verifyBlockBook'}, 'trying to get block book information');
    return info;
  }

  private async getFlyoverStatus(txId: string): Promise<TxStatus> {
    let txStatus:TxStatus = new TxStatus({});
    try {
      this.logger.debug({method: 'getFlyoverStatus', txId}, 'trying to get a Flyover with txHash');
      const flyoverStatus = await this.flyoverService.getFlyoverStatus(txId);
      if (flyoverStatus) {
        this.logger.debug(
          {method: 'getFlyoverStatus', txId, type: flyoverStatus.type, status: flyoverStatus.status},
          'Flyover Status got for txId',
        );
        if (!flyoverStatus.type) {
          this.logger.debug({method: 'getFlyoverStatus', txId, type: flyoverStatus.type}, 'Flyover Status: no tx found for the provided tx id');
          txStatus = new TxStatus({
            type: TxStatusType.INVALID_DATA, // no tx found
          });
        }else{
          txStatus = new TxStatus({
            type: flyoverStatus.type === TX_TYPE_PEGIN ? TxStatusType.FLYOVER_PEGIN : TxStatusType.FLYOVER_PEGOUT,
            txDetails: flyoverStatus,
          });
        }
      }
    } catch (err) {
      this.logger.error({method: 'getFlyoverStatus', err, txId});
      txStatus = new TxStatus({
        type: TxStatusType.UNEXPECTED_ERROR,
      });
    }
    return txStatus;
  }

  private async getNativePegoutStatus(txId: string): Promise<TxStatus> {
    let txStatus:TxStatus = new TxStatus({});
    try {
      const txHash = ensure0x(txId);
      this.logger.debug({method: 'getNativePegoutStatus', txId: txHash}, 'trying to get a Native Pegout with txHash');
      const pegoutStatus = await this.pegoutStatusService.getPegoutStatusByRskTxHash(txHash);
      if (pegoutStatus.status !== PegoutStatuses.NOT_FOUND) {
        this.logger.debug({method: 'getNativePegoutStatus', txId: txHash, status: pegoutStatus.status}, 'Native Pegout Status got for txId');
        txStatus = new TxStatus({
          type: TxStatusType.PEGOUT,
          txDetails: pegoutStatus,
        });
      }
    } catch (err) {
      this.logger.error({method: 'getNativePegoutStatus', err, txId});
      txStatus = new TxStatus({
        type: TxStatusType.UNEXPECTED_ERROR,
      });
    }
    return txStatus;
  }

  private async getNativePeginStatus(txId: string): Promise<TxStatus> {
    let txStatus:TxStatus = new TxStatus({});

    try {
      const txHash = remove0x(txId);
      this.logger.debug({method: 'getNativePeginStatus', txId: txHash}, 'trying to get a pegin with txHash');
      const peginStatus = await this.getPeginStatus(txHash);
      if (
          peginStatus.status !== Status.ERROR_NOT_A_PEGIN
          && peginStatus.status !== Status.ERROR_UNEXPECTED
          && peginStatus.status !== Status.NOT_IN_BTC_YET
      ) {
        this.logger.debug({method: 'getNativePeginStatus', txId: txHash, status: peginStatus.status}, 'Pegin status got for txId');
        txStatus = new TxStatus({
          type: TxStatusType.PEGIN,
          txDetails: peginStatus,
        });
      }

    } catch (err) {
      this.logger.error({method: 'getNativePeginStatus', err, txId});
      txStatus = new TxStatus({
        type: TxStatusType.UNEXPECTED_ERROR,
      });
    }
    return txStatus;
  }

  private async getPeginStatus(txId: string): Promise<PeginStatus> {
    try {
      const result = await this.peginStatusService.getPeginStatusInfo(txId);
      this.logger.debug({method: 'getPeginStatus', txId, status: result.status}, 'Found tx with status');
      return result;
    } catch (err) {
      this.logger.warn({method: 'getPeginStatus', err, txId});
      return Promise.resolve(new PeginStatusError(txId));
    };
  }

}
