import {inject} from '@loopback/core';
import {getLogger, Logger} from '../utils/logger';
import {ConstantsBindings, ServicesBindings} from '../dependency-injection-bindings';
import {RskBlock} from '../models/rsk/rsk-block.model';
import {getMetricLogger} from '../utils/metric-logger';
import {PeginStatusDataService} from './pegin-status-data-services/pegin-status-data.service';
import {PeginDataProcessor} from './pegin-data.processor';
import {PegoutDataProcessor} from './pegout-data.processor';
import {RskChainSyncService} from './rsk-chain-sync.service';
import RskBlockProcessorPublisher from './rsk-block-processor-publisher';

export class DaemonService implements IDaemonService {
  peginStatusStorageService: PeginStatusDataService;
  syncService: RskChainSyncService;
  peginDataProcessor: PeginDataProcessor;
  pegoutDataProcessor: PegoutDataProcessor;
  rskBlockProcessorPublisher: RskBlockProcessorPublisher

  dataFetchInterval: NodeJS.Timeout;
  started: boolean;
  logger: Logger;

  intervalTime: number;
  lastSyncLog = 0;

  constructor(
    @inject(ServicesBindings.RSK_BLOCK_PROCESSOR_PUBLISHER)
    rskBlockProcessorPublisher: RskBlockProcessorPublisher,
    @inject(ServicesBindings.PEGIN_STATUS_DATA_SERVICE)
    peginStatusStorageService: PeginStatusDataService,
    @inject(ServicesBindings.RSK_CHAIN_SYNC_SERVICE)
    syncService: RskChainSyncService,
    @inject(ConstantsBindings.SYNC_INTERVAL_TIME)
    syncIntervalTime: string | undefined,
    @inject(ServicesBindings.PEGIN_DATA_PROCESSOR)
    peginDataProcessor: PeginDataProcessor,
    @inject(ServicesBindings.PEGOUT_DATA_PROCESSOR)
    pegoutDataProcessor: PegoutDataProcessor
  ) {
    this.peginStatusStorageService = peginStatusStorageService;
    this.syncService = syncService;
    this.peginDataProcessor = peginDataProcessor;
    this.pegoutDataProcessor = pegoutDataProcessor;
    this.rskBlockProcessorPublisher = rskBlockProcessorPublisher;
    this.started = false;
    this.logger = getLogger('daemon-service');
    this.intervalTime = parseInt(syncIntervalTime ?? '2000');
  }

  private async handleNewBestBlock(rskBlock: RskBlock): Promise<void> {
    try {
      await this.rskBlockProcessorPublisher.process(rskBlock);
    } catch (e) {
      this.logger.warn({method: 'handleNewBestBlock', err: e}, 'There was a problem handling the new block');
    }
  }

  private async handleDeleteBlock(block: RskBlock): Promise<void> {
    try {
      await this.peginStatusStorageService.deleteByRskBlockHeight(block.height);
      await this.pegoutDataProcessor.deleteByRskBlockHeight(block.height);
    } catch (e) {
      this.logger.warn({method: 'handleDeleteBlock', err: e}, 'There was a problem handling the deleted block');
    }
  }

  private startTimer(): void {
    // `sync()` handles its own errors and re-arms this timer as its last act, so
    // a rejection here means it failed *outside* that handling and the daemon
    // loop has stopped for good. It was silently dropped before; logging it is
    // the smallest change that makes a stopped daemon visible.
    this.dataFetchInterval = setTimeout(() => {
      this.sync().catch(err =>
        this.logger.error({method: 'startTimer', err}, 'Sync loop stopped'),
      );
    }, this.intervalTime);
  }

  private async sync(): Promise<void> {
    // Avoid processing if the service has not started or was stopped
    if (!this.started) {
      this.startTimer();
      return;
    }
    const logMetrics = getMetricLogger(this.logger, 'sync');
    try {
      this.lastSyncLog++;
      if (this.lastSyncLog >= 5) {
        this.lastSyncLog = 0;
        const bestBlock = await this.syncService.getSyncStatus();
        this.logger.debug({method: 'sync', blockHeight: bestBlock.rskBlockHeight, blockHash: bestBlock.rskBlockHash}, 'Sync status');
      }
      await this.syncService.sync();
    } catch (error) {
      this.logger.warn({method: 'sync', err: error}, 'Got an error syncing');
    }
    logMetrics();
    this.startTimer();
  }

  public async start(): Promise<void> {
    if (this.started) {
      return;
    }
    this.logger.debug({method: 'start'}, 'Starting');
    await this.peginStatusStorageService.start();

    await this.syncService.start();
    // Both handlers wrap their whole body in a try/catch, so neither can reject
    // today and these catches should never fire. They are here anyway because
    // that guarantee lives in another method and nothing enforces it: the
    // subscriber list is notified synchronously and nobody awaits these, so a
    // rejection would have nowhere to go but the process handler.
    const unexpected = (method: string) => (err: unknown) =>
      this.logger.error({method, err}, 'Block handler rejected');
    this.syncService.subscribe({
      blockAdded: (block) => { this.handleNewBestBlock(block).catch(unexpected('blockAdded')); },
      blockDeleted: (block) => { this.handleDeleteBlock(block).catch(unexpected('blockDeleted')); }
    });

    this.rskBlockProcessorPublisher.addSubscriber(this.peginDataProcessor);
    this.rskBlockProcessorPublisher.addSubscriber(this.pegoutDataProcessor);

    this.logger.debug({method: 'start'}, 'Started');
    this.started = true;

    // Schedule daemon task
    this.startTimer();
  }

  public async stop(): Promise<void> {
    if (this.started) {
      this.started = false;
      this.logger.debug({method: 'stop'}, 'Stopping');
      clearTimeout(this.dataFetchInterval);
      await this.peginStatusStorageService.stop()
      await this.syncService.stop();
      this.rskBlockProcessorPublisher.removeSubscriber(this.peginDataProcessor);
      this.rskBlockProcessorPublisher.removeSubscriber(this.pegoutDataProcessor);
      this.logger.debug({method: 'stop'}, 'Stopped');
    }
  }

}

export interface IDaemonService {
  start(): void;

  stop(): void;
}
