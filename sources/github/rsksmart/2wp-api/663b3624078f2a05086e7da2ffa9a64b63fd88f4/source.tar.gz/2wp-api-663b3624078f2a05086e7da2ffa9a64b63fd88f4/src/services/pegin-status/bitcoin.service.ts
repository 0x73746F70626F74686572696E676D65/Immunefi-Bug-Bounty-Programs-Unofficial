import {inject} from '@loopback/core';
import {getLogger, Logger} from '../../utils/logger';
import {AddressService, TxV2Service} from '..';
import {ServicesBindings} from '../../dependency-injection-bindings';
import {BitcoinAddress} from '../../models/bitcoin-address.model';
import {BitcoinTx} from '../../models/bitcoin-tx.model';
import {LastBlockService} from '../btc-last-block.service';
import {LastBlockInfo} from '../../models/btc-last-block.model';

export class BitcoinService {
  logger: Logger;
  addressService: AddressService;
  lastBlockService: LastBlockService

  constructor(
    @inject('services.TxV2Service')
    protected txV2Service: TxV2Service,
    @inject(ServicesBindings.ADDRESS_SERVICE)
    addressService: AddressService,
    @inject(ServicesBindings.BTC_LAST_BLOCK_SERVICE)
    lastBlockService: LastBlockService,
  ) {
    this.logger = getLogger('bitcoin-service');
    this.addressService = addressService;
    this.lastBlockService = lastBlockService;
  }

  /**
   * Transaction information from the provider.
   *
   * Provider failures are rethrown unchanged, for the same reason as
   * {@link getAddressInfo}: they already carry a meaningful status, and
   * rejecting with a bare string erases it — a 502 or 504 arrives as a 500, and
   * any cancellation travelling the path is destroyed with it.
   *
   * @param txId - Transaction id to look up.
   * @returns The transaction.
   * @throws The provider's own error, unchanged.
   */
  getTx(txId: string): Promise<BitcoinTx> {
    return new Promise<BitcoinTx>((resolve, reject) => {
      this.txV2Service
        .txV2Provider(txId)
        .then((tx: any) => {
          const responseTx = new BitcoinTx();
          responseTx.txid = tx[0].txid;
          responseTx.version = tx[0].version;
          responseTx.vin = tx[0].vin;
          responseTx.vout = tx[0].vout;
          responseTx.blockhash = tx[0].blockHash;
          responseTx.blockheight = tx[0].blockHeight;
          responseTx.confirmations = tx[0].confirmations;
          responseTx.time = tx[0].time;
          responseTx.blocktime = tx[0].blockTime;
          responseTx.valueOut = tx[0].valueOut;
          responseTx.valueIn = tx[0].valueIn;
          responseTx.fees = tx[0].fees;
          responseTx.hex = tx[0].hex;
          resolve(responseTx);
        })
        .catch(err => {
          this.logger.warn({method: 'getTx', err, txId}, 'Transaction lookup failed');
          reject(err);
        });
    });
  }

  /**
   * Address information from the provider.
   *
   * Provider failures are rethrown unchanged. They already carry a meaningful
   * status — a timeout is a 504, an oversized response a 502, a cancellation a
   * 499 — and replacing them with a string erased all of that, collapsing every
   * upstream condition into a 500 and destroying any cancellation travelling
   * this path. The address goes to the log as a field rather than into the error
   * message, so nothing request-derived rides along with the error.
   *
   * @param address - BTC address to resolve.
   * @returns The provider's address information.
   */
  async getAddressInfo(address: string): Promise<BitcoinAddress> {
    let tx;
    try {
      tx = (await this.addressService.addressProvider(address)) as any;
    } catch (err) {
      this.logger.warn({method: 'getAddressInfo', err, address}, 'Address lookup failed');
      throw err;
    }

    const responseAddress = new BitcoinAddress();
    responseAddress.address = tx[0].address;
    responseAddress.balance = tx[0].balance;
    responseAddress.page = tx[0].page;
    responseAddress.totalPages = tx[0].totalPages;
    responseAddress.itemsOnPage = tx[0].itemsOnPage;
    responseAddress.totalReceived = tx[0].totalReceived;
    responseAddress.totalSent = tx[0].totalSent;
    responseAddress.unconfirmedBalance = tx[0].unconfirmedBalance;
    responseAddress.unconfirmedTxs = tx[0].unconfirmedTxs;
    responseAddress.txs = tx[0].txs;
    if (responseAddress.txs > 0) {
      responseAddress.txids = tx[0].txids;
    }
    return responseAddress;
  }

  /**
   * Provider chain tip, used by the health probe.
   *
   * Rethrows the provider's error unchanged, as {@link getTx} does. Interpolating
   * it into a string also embedded provider text in the rejection, which the
   * caller may surface.
   *
   * @returns The provider's last-block information.
   * @throws The provider's own error, unchanged.
   */
  getLastBlock(): Promise<LastBlockInfo> {
    return new Promise<LastBlockInfo>((resolve, reject) => {
      this.lastBlockService.lastBlockProvider()
        .then((lbir: any) => {
          const lastBlockInfo = new LastBlockInfo();
          lastBlockInfo.bestBlockHash = lbir[0].backend.bestBlockHash;
          lastBlockInfo.bestHeight = lbir[0].blockbook.bestHeight;
          lastBlockInfo.blocks = lbir[0].backend.blocks;
          lastBlockInfo.chain = lbir[0].backend.chain;
          lastBlockInfo.coin = lbir[0].blockbook.coin;
          lastBlockInfo.inSync = lbir[0].blockbook.inSync;
          lastBlockInfo.initialSync = lbir[0].blockbook.initialSync;
          lastBlockInfo.syncMode = lbir[0].blockbook.syncMode;
          resolve(lastBlockInfo);
        })
        .catch((err) => {
          this.logger.warn({method: 'getLastBlock', err}, 'Last block lookup failed');
          reject(err);
        });
    });
  }

}
