import { toDataURL } from 'qrcode'

/** Arguments for a Lightning (BOLT11) QR code. */
export interface LightningQrCodeArgs {
  /** The BOLT11 payment request string to encode as-is in the QR code. */
  lnPaymentString: string
}

/**
 * Arguments for the BIP21 QR code
 * @property address - The address of the wallet
 * @property amountInDecimal - The amount of the payment in decimal
 * @property label - The label of the payment
 * @property message - The message of the payment
 */
export interface Bip21QrCodeArgs {
  address: string
  amountInDecimal?: string
  label?: string
  message?: string
}

/**
 * Arguments for the EIP681 QR code
 * @property address - The address of the wallet
 * @property value - The value of the payment in wei
 * @property chainId - The chain ID of the network
 * @property tokenAddress - The address of the token. Must be provided together with recipient and uint256.
 * @property recipient - The address of the recipient. Must be provided together with tokenAddress and uint256.
 * @property uint256 - The amount of the token in uint256. Must be provided together with tokenAddress and recipient.
 */
export interface Eip681QrCodeArgs {
  address: string
  value?: string
  chainId?: number
  // For ERC20 token transfers
  tokenAddress?: string
  recipient?: string
  uint256?: string
}

/**
 * Arguments for {@link getQrCode}.
 * @property type - The type of QR code to generate 'BIP-21' | 'EIP-681' | 'BOLT11'
 * @property data - The data for the QR code Bip21QrCodeArgs | Eip681QrCodeArgs | LightningQrCodeArgs
 */
export type GetQrCodeArgs =
  | {
    type: 'BIP-21'
    data: Bip21QrCodeArgs
  }
  | {
    type: 'EIP-681'
    data: Eip681QrCodeArgs
  }
  | {
    type: 'BOLT11'
    data: LightningQrCodeArgs
  }

/**
 * Generates a QR code data URL from a payment URI.
 *
 * Supports:
 * - BIP21: Bitcoin payment URIs (e.g., bitcoin:1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa?amount=0.001)
 * - EIP681: Ethereum payment URIs for native tokens or ERC20 transfers
 * - BOLT11: Lightning Network payment requests
 */
export async function getQrCode (args: GetQrCodeArgs): Promise<string> {
  let uri: string

  try {
    switch (args.type) {
      case 'BIP-21':
        uri = buildBip21Uri(args.data)
        break
      case 'EIP-681':
        uri = buildEip681Uri(args.data)
        break
      case 'BOLT11':
        uri = args.data.lnPaymentString
        break
      default:
        throw new Error('Unsupported QR code type')
    }

    const qrCodeUrl = await toDataURL(uri)
    return qrCodeUrl
  } catch (err: unknown) {
    throw new Error('Error generating QR code: ' + (err as Error).message)
  }
}

/**
 * Builds a BIP21 URI for Bitcoin payments
 * Format: bitcoin:<address>?amount=<amount>&label=<label>&message=<message>
 */
function buildBip21Uri (args: Bip21QrCodeArgs): string {
  const { address, amountInDecimal, label, message } = args
  let uri = `bitcoin:${address}`

  const params: string[] = []
  if (amountInDecimal) {
    params.push(`amount=${encodeURIComponent(amountInDecimal)}`)
  }
  if (label) params.push(`label=${encodeURIComponent(label)}`)
  if (message) params.push(`message=${encodeURIComponent(message)}`)

  if (params.length > 0) {
    uri += `?${params.join('&')}`
  }

  return uri
}

/**
 * Builds an EIP681 URI for Ethereum/EVM payments
 * For native tokens: ethereum:<address>@<chainId>?value=<value>
 * For ERC20 tokens: ethereum:<tokenAddress>@<chainId>/transfer?address=<recipient>&uint256=<amount>
 */
function buildEip681Uri (args: Eip681QrCodeArgs): string {
  const { address, value, chainId, tokenAddress, recipient, uint256 } = args

  // ERC20 token transfer
  if (tokenAddress !== undefined || recipient !== undefined || uint256 !== undefined) {
    if (!tokenAddress || !recipient || !uint256) {
      throw new Error('Invalid EIP-681 data: tokenAddress, recipient, and uint256 must be provided together for ERC20 transfers')
    }

    const chainIdParam = chainId !== undefined ? `@${chainId}` : ''
    return `ethereum:${encodeURIComponent(tokenAddress)}${chainIdParam}/transfer?address=${encodeURIComponent(recipient)}&uint256=${encodeURIComponent(uint256)}`
  }

  // Native token payment
  const chainIdParam = chainId !== undefined ? `@${chainId}` : ''
  let uri = `ethereum:${encodeURIComponent(address)}${chainIdParam}`
  const params: string[] = []
  if (value) params.push(`value=${encodeURIComponent(value)}`)

  if (params.length > 0) {
    uri += `?${params.join('&')}`
  }

  return uri
}
