import { describe, expect, test, jest } from '@jest/globals'
import { type CreateSwapResult } from '../../api/index'
import { type TxData } from '../types'
import { LiFiClient } from './lifi'

describe('LiFiClient should', () => {
  const tokenOnNetwork1 = '0x0000000000000000000000000000000000000abc'
  const httpClient = {
    get: jest.fn(async () => ({
      symbol: 'USDC',
      description: 'USD',
      type: 'erc20' as const,
      decimals: 6,
      addresses: { 1: tokenOnNetwork1 }
    }))
  }
  const client = new LiFiClient('https://api.test', httpClient as any)

  const baseSwap: any = {
    providerSwapId: 'lifi-123',
    refundAddress: '0x9d93929a9099be4355fc2389fbf253982f9df47c',
    providerId: 'LIFI',
    fromAmount: BigInt('1000000'),
    paymentAddress: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
    receiverAddress: '0x79568c2989232dCa1840087D73d403602364c0D4',
    fromToken: 'USDC',
    toToken: 'RBTC',
    fromNetwork: '1',
    toNetwork: '30',
    status: 'CREATED',
    requiredConfirmations: 1,
    usedFees: [],
    context: {}
  }

  test('pass through ERC20-PAYMENT tx data from swap context', async () => {
    const expectedTxData: TxData = {
      to: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
      data: '0x4630a0d8000000000000000000000000',
      value: '0x0'
    }
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        context: { publicContext: expectedTxData }
      },
      actionType: 'ERC20-PAYMENT'
    }

    const action = await client.generateAction(createdSwap)

    expect(action.type).toBe('ERC20-PAYMENT')
    expect(action.requiresClaim).toBe(false)
    expect(action.data).toEqual(expectedTxData)
    expect(httpClient.get).toHaveBeenCalled()
    expect(action.executePreSteps).toBeDefined()
  })

  test('pass through EVM-NATIVE-PAYMENT tx data from swap context', async () => {
    const expectedTxData: TxData = {
      to: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
      data: '0x4630a0d8000000000000000000000000',
      value: '0x2386f26fc10000'
    }
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        context: { publicContext: expectedTxData }
      },
      actionType: 'EVM-NATIVE-PAYMENT'
    }

    const action = await client.generateAction(createdSwap)

    expect(action.type).toBe('EVM-NATIVE-PAYMENT')
    expect(action.requiresClaim).toBe(false)
    expect(action.data).toEqual(expectedTxData)
    expect(action.executePreSteps).toBeUndefined()
  })

  test('reject unsupported BIP21 action type', async () => {
    const createdSwap: CreateSwapResult = {
      swap: baseSwap,
      actionType: 'BIP21'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'Action type BIP21 not supported for LI.FI'
    )
  })

  test('reject unsupported BOLT11 action type', async () => {
    const createdSwap: CreateSwapResult = {
      swap: baseSwap,
      actionType: 'BOLT11'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'Action type BOLT11 not supported for LI.FI'
    )
  })

  test('reject unsupported NONE action type', async () => {
    const createdSwap: CreateSwapResult = {
      swap: baseSwap,
      actionType: 'NONE'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'Action type NONE not supported for LI.FI'
    )
  })

  test('reject unsupported CONTRACT-INTERACTION action type', async () => {
    const createdSwap: CreateSwapResult = {
      swap: baseSwap,
      actionType: 'CONTRACT-INTERACTION'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'Action type CONTRACT-INTERACTION not supported for LI.FI'
    )
  })

  test('create empty context', () => {
    const context = client.createContext({
      fromAmount: BigInt(0),
      fromToken: 'ETH',
      toToken: 'RBTC',
      fromNetwork: '1',
      toNetwork: '30',
      address: '0x',
      refundAddress: '0x',
      providerId: 'LIFI'
    })

    expect(context).toEqual({
      publicContext: {},
      secretContext: {}
    })
  })

  test('validate address should always return true', async () => {
    const isValid = await client.validateAddress(baseSwap)
    expect(isValid).toBe(true)
  })

  test('throw error when payment address mismatches publicContext.to', async () => {
    const expectedTxData: TxData = {
      to: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
      data: '0x4630a0d8000000000000000000000000',
      value: '0x0'
    }
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        paymentAddress: '0x79568c2989232dCa1840087D73d403602364c0D4',
        context: { publicContext: expectedTxData }
      },
      actionType: 'ERC20-PAYMENT'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'LI.FI payment address mismatch: 0x79568c2989232dCa1840087D73d403602364c0D4 !== 0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE'
    )
  })

  test('throw error when publicContext is missing', async () => {
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        context: {}
      },
      actionType: 'ERC20-PAYMENT'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'Missing to in LI.FI swap context'
    )
  })

  test('allow payment address when matching publicContext.to case-insensitively', async () => {
    const expectedTxData: TxData = {
      to: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
      data: '0x4630a0d8000000000000000000000000',
      value: '0x0'
    }
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        paymentAddress: '0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae',
        context: { publicContext: expectedTxData }
      },
      actionType: 'ERC20-PAYMENT'
    }
    await expect(client.generateAction(createdSwap)).resolves.toBeDefined()
  })

  test('throw error when publicContext is missing value field', async () => {
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        context: {
          publicContext: {
            to: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
            data: '0x4630a0d8000000000000000000000000'
            // value is missing
          }
        }
      },
      actionType: 'ERC20-PAYMENT'
    }

    await expect(client.generateAction(createdSwap)).rejects.toThrow(
      'Missing value in LI.FI swap context'
    )
  })

  test('throw when token is not listed on fromNetwork', async () => {
    const httpEmpty = {
      get: jest.fn(async () => ({
        symbol: 'USDC',
        description: 'USD',
        type: 'erc20' as const,
        decimals: 6,
        addresses: { 30: tokenOnNetwork1 }
      }))
    }
    const strictClient = new LiFiClient('https://api.test', httpEmpty as any)
    const expectedTxData: TxData = {
      to: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE',
      data: '0x4630a0d8000000000000000000000000',
      value: '0x0'
    }
    const createdSwap: CreateSwapResult = {
      swap: {
        ...baseSwap,
        fromNetwork: '1',
        context: { publicContext: expectedTxData }
      },
      actionType: 'ERC20-PAYMENT'
    }

    await expect(strictClient.generateAction(createdSwap)).rejects.toThrow(
      'is not available on 1'
    )
  })
})
