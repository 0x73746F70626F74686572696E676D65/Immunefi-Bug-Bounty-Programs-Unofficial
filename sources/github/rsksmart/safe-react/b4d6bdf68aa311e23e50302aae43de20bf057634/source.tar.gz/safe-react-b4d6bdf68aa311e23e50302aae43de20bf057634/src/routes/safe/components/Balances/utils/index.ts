export * from './setTokenImgToPlaceholder'
