/**
 * The MIT License (MIT)
 *
 * Copyright (c) 2021 RSK Labs Ltd
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include <unistd.h>

#include "hsm_u.h"
#include "enclave_provider.h"
#include "log.h"

// Simulation build
#if defined(SIM_BUILD)
#define CREATE_ENCLAVE_FLAGS OE_ENCLAVE_FLAG_SIMULATE
#elif defined(DEBUG_BUILD)
#define CREATE_ENCLAVE_FLAGS OE_ENCLAVE_FLAG_DEBUG
#else
#define CREATE_ENCLAVE_FLAGS 0
#endif

// Global pointer to the enclave. This should be the only global pointer to the
// enclave
static char* G_enclave_path = NULL;
static oe_enclave_t* G_enclave = NULL;

bool epro_init(char* enclave_path) {
    G_enclave_path = enclave_path;
    if (access(G_enclave_path, F_OK) != 0) {
        DEBUG("Invalid enclave path given: %s\n", G_enclave_path);
        return false;
    }
    return true;
}

oe_enclave_t* epro_get_enclave() {
    if (NULL == G_enclave) {
        oe_enclave_t* enclave = NULL;
        INFO("Creating HSM enclave...\n");
        DEBUG("Create enclave flags: %d\n", CREATE_ENCLAVE_FLAGS);
        oe_result_t result = oe_create_hsm_enclave(G_enclave_path,
                                                   OE_ENCLAVE_TYPE_AUTO,
                                                   CREATE_ENCLAVE_FLAGS,
                                                   NULL,
                                                   0,
                                                   &enclave);
        if (OE_OK != result) {
            DEBUG("Failed to create enclave: oe_result=%u (%s)\n",
                  result,
                  oe_result_str(result));
            return NULL;
        }

        INFO("HSM enclave created\n");
        G_enclave = enclave;
    }

    return G_enclave;
}

void epro_finalize_enclave() {
    if (NULL != G_enclave) {
        oe_terminate_enclave(G_enclave);
        INFO("HSM enclave terminated\n");
        G_enclave = NULL;
    }
}
