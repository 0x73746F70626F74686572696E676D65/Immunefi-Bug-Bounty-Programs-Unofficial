module.exports = {
  skipFiles: ['tests']
};
