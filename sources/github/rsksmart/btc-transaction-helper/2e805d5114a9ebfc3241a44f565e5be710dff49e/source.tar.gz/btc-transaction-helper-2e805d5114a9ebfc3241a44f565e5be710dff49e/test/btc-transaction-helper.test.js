const chai = require('chai');
const { assert, expect } = require('chai');
const BtcTransactionHelper = require('../btc-transaction-helper');
const config = require('../samples/config');
const sinon = require('sinon');
const chaiAsPromise = require('chai-as-promised');
const bitcoin = require('bitcoinjs-lib');
const ECPairFactory = require('ecpair').default;
const ecc = require('tiny-secp256k1');
const conversion = require('../conversion');

chai.use(chaiAsPromise);

const ECPair = ECPairFactory(ecc);

const TEST_BTC_ADDRESS = 'mxd5o5xQc6Qvo956mHGkVX9ZvAfoNNh9Ec';
const PRIVATE_KEY = 'cRDAG3moz46jcmTb4AP1jnGCzYy8kkfexQVzTMBQcswr8DKEzCz4';
const LEGACY = 'legacy';
const ADDRESS_INFORMATION = {
    address: TEST_BTC_ADDRESS,
    privateKey: PRIVATE_KEY
};

const SAMPLE_BTC_TRANSACTIONS = require('./sample-btc-transactions.json');

const MULTISIG_ADDRESS_INFORMATION = {
    address: '2N7pXoMCZjvbCJmo51t9WDrR7gR6k9VjZod',
    info: {
        members: [
            {
                address: 'mt3rLTFHEW9YwSoUFcQFK8FzvEZhtyxSpx',
                privateKey: 'cPXuhqdZVBpCfsvFM55hEpqTkmUi3K6GpPKREboHjhfh5MGRMmqp'
            },
            {
                address: 'mpvR1XSmGW11WBwNYDmGZVbWFMEVRoCkAb',
                privateKey: 'cTVq2Kg2PYEBTEb9ppVSwJ1P8xd8Uo5mancEX3FG9o4i727dthKu'
            }
        ],
        redeemScript:
            '522103ebff0e5dc444e25c72d199e3f2ba22bfef8124bb7a00ba813d691300be2d6c4521031e35f8641a77b5388e3deb31ae6321059231c3bda238405e0d3667668ff8cb8d52ae'
    }
};

const utxos = [
    {
        amount: 1000
    },
    {
        amount: 2000
    },
    {
        amount: 3000
    }
];

const blockHeader = {
    hash: '720051c391d1c162c995d645044e63bbe953555c9b28a8fbd5e624c7224d13a3',
    confirmations: 206,
    height: 600,
    version: 536870912,
    versionHex: '20000000',
    merkleroot: '08de262399541132fc020124331682bb07f289b47025e5208eb2ca8639826bfc',
    time: 1702060641,
    mediantime: 1702060640,
    nonce: 0,
    bits: '207fffff',
    difficulty: 4.656542373906925e-10,
    chainwork: '00000000000000000000000000000000000000000000000000000000000004b2',
    nTx: 1,
    previousblockhash: '6bdc887e9310d152d936f1dc94cae69b4b60b393bfdc91471b21f4d38a4644f4',
    nextblockhash: '0f7c230fc7326ddfa02e634a7165047d429db118ce60c74fb6428d079e0eedec'
};

const txId1 = '0e4f5d33e75bbc483156548e654d780b636f003d35e63a1a0324685a56ecd05a';
const txId2 = '8dcce65becbcdaaff4605c7dd285a6c9a26fbe9d92e6f50aaa1c46785e14e963';

const transactionsInMempoolVerbose = {
    '0e4f5d33e75bbc483156548e654d780b636f003d35e63a1a0324685a56ecd05a': {
        fees: {
            base: 0.0000744,
            modified: 0.0000744,
            ancestor: 0.0000744,
            descendant: 0.0000744
        },
        size: 372,
        fee: 0.0000744,
        modifiedfee: 0.0000744,
        time: 1702491432,
        height: 821,
        descendantcount: 1,
        descendantsize: 372,
        descendantfees: 7440,
        ancestorcount: 1,
        ancestorsize: 372,
        ancestorfees: 7440,
        wtxid: '0e4f5d33e75bbc483156548e654d780b636f003d35e63a1a0324685a56ecd05a',
        depends: [],
        spentby: [],
        'bip125-replaceable': false
    },
    '8dcce65becbcdaaff4605c7dd285a6c9a26fbe9d92e6f50aaa1c46785e14e963': {
        fees: {
            base: 0.0000744,
            modified: 0.0000744,
            ancestor: 0.0000744,
            descendant: 0.0000744
        },
        size: 372,
        fee: 0.0000744,
        modifiedfee: 0.0000744,
        time: 1702491430,
        height: 821,
        descendantcount: 1,
        descendantsize: 372,
        descendantfees: 7440,
        ancestorcount: 1,
        ancestorsize: 372,
        ancestorfees: 7440,
        wtxid: '8dcce65becbcdaaff4605c7dd285a6c9a26fbe9d92e6f50aaa1c46785e14e963',
        depends: [],
        spentby: [],
        'bip125-replaceable': false
    }
};

describe('BtcTransactionHelper', () => {
    it('should generate address information', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const nodeClient = btcTransactionHelper.nodeClient;
        const generateAddressInformationStub = sinon
            .stub(nodeClient, 'generateAddressInformation')
            .resolves(ADDRESS_INFORMATION);
        const result = await btcTransactionHelper.generateBtcAddress(LEGACY);

        assert.equal(result, ADDRESS_INFORMATION);

        generateAddressInformationStub.restore();
    });

    it('should generate multisig address information', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const nodeClient = btcTransactionHelper.nodeClient;
        const generateMultisigAddressInformationStub = sinon
            .stub(nodeClient, 'generateMultisigAddressInformation')
            .resolves(MULTISIG_ADDRESS_INFORMATION);
        const result = await btcTransactionHelper.generateMultisigAddress(2, 2, LEGACY);

        assert.equal(result, MULTISIG_ADDRESS_INFORMATION);

        generateMultisigAddressInformationStub.restore();
    });

    it('should select spendable utxos from address with 1000 satoshis change', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const result = await btcTransactionHelper.selectSpendableUTXOsFromAddress(TEST_BTC_ADDRESS, 2000);

        assert.equal(result.utxos.length, 2);
        assert.equal(result.utxos[0].amount, 1000);
        assert.equal(result.utxos[1].amount, 2000);
        assert.equal(result.change, 1000);

        getUtxosStub.restore();
    });

    it('should select spendable utxos from address with no change', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const result = await btcTransactionHelper.selectSpendableUTXOsFromAddress(TEST_BTC_ADDRESS, 1000);

        assert.equal(result.utxos.length, 1);
        assert.equal(result.utxos[0].amount, 1000);
        assert.equal(result.change, 0);

        getUtxosStub.restore();
    });

    it('should fail if account does not have enough funds', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);

        await expect(
            btcTransactionHelper.selectSpendableUTXOsFromAddress(TEST_BTC_ADDRESS, 8000)
        ).to.eventually.be.rejectedWith(Error, 'The sender does not have enough balance to proceed with the transfer');

        getUtxosStub.restore();
    });

    it('should return utxos', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const nodeClient = btcTransactionHelper.nodeClient;
        const getUtxosStub = sinon.stub(nodeClient, 'getUtxos').resolves(utxos);
        const result = await btcTransactionHelper.getUtxos(TEST_BTC_ADDRESS);

        assert.equal(result, utxos);

        getUtxosStub.restore();
    });

    it('should transferBtc', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const amountInBtc = 2000;
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc }];

        const utxos = [
            {
                amount: 3000,
                txid: '74f7e8c0263be8b23b3deffbaf9ee74239076a0de57c695aef4669e22bee0d01',
                vout: 0,
                scriptPubKey: '76a91481a2a37f24c2d7af1382cfe3f5bfa570705efc3288ac'
            }
        ];

        const txHex = `0100000001010dee2be26946ef5a697ce50d6a073942e79eaffbef3d3bb2e83b26c0e8f7740000000000ffffffff0200d0ed902e0000001976a914b6b298fc195725922d93f27cd01f7f382627de3b88ac60617548170000001976a914bba2e52eae9579b7605d9988d2ebe5bc306251ad88ac00000000`;
        const signedTxHex = `0100000001010dee2be26946ef5a697ce50d6a073942e79eaffbef3d3bb2e83b26c0e8f774000000006a4730440220433a46156385a556ea42e47aff98f1497040bbcd0f6206d3dfe9dbc9933a8806022026a25a95f330c05cc8f8b4d070b54b99101b6b5367e5a29b468c8c4a387138fb0121027eae337ba08d93410ad95778e3dbe10bfaaefa26448683809f16429072103c7effffffff0100e1f505000000001976a914b6b298fc195725922d93f27cd01f7f382627de3b88ac00000000`;
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const signRawTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'signTransaction')
            .resolves(signedTxHex);
        const sendRawTransactionStub = sinon.stub(btcTransactionHelper.nodeClient, 'sendTransaction').resolves(txHash);

        const result = await btcTransactionHelper.transferBtc(ADDRESS_INFORMATION, recipientsTransactionInformation);

        assert.equal(result, txHash);

        assert.isTrue(getUtxosStub.calledWith(ADDRESS_INFORMATION.address));
        assert.isTrue(signRawTransactionStub.calledWith(txHex, [], [ADDRESS_INFORMATION.privateKey]));
        assert.isTrue(sendRawTransactionStub.calledWith(signedTxHex));

        getUtxosStub.restore();
        signRawTransactionStub.restore();
        sendRawTransactionStub.restore();
    });

    it('should transferBtc from a p2sh-segwit address providing the redeem script', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const network = config.network;

        const keyPair = ECPair.fromWIF(PRIVATE_KEY, network);
        const p2shSegwit = bitcoin.payments.p2sh({
            redeem: bitcoin.payments.p2wpkh({ pubkey: keyPair.publicKey, network }),
            network
        });
        const senderAddressInformation = {
            address: p2shSegwit.address,
            privateKey: PRIVATE_KEY
        };

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc: 2000 }];

        const utxos = [
            {
                amount: 3000,
                txid: '74f7e8c0263be8b23b3deffbaf9ee74239076a0de57c695aef4669e22bee0d01',
                vout: 0,
                scriptPubKey: Buffer.from(bitcoin.address.toOutputScript(p2shSegwit.address, network)).toString('hex')
            }
        ];

        const signedTxHex = `010000000001010dee2be26946ef5a697ce50d6a073942e79eaffbef3d3bb2e83b26c0e8f774`;
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const signRawTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'signTransaction')
            .resolves(signedTxHex);
        const sendRawTransactionStub = sinon.stub(btcTransactionHelper.nodeClient, 'sendTransaction').resolves(txHash);

        const result = await btcTransactionHelper.transferBtc(
            senderAddressInformation,
            recipientsTransactionInformation
        );

        assert.equal(result, txHash);

        const prevTxs = signRawTransactionStub.args[0][1];
        assert.lengthOf(prevTxs, 1);
        assert.equal(prevTxs[0].txid, utxos[0].txid);
        assert.equal(prevTxs[0].vout, utxos[0].vout);
        assert.equal(prevTxs[0].scriptPubKey, utxos[0].scriptPubKey);
        assert.equal(prevTxs[0].redeemScript, Buffer.from(p2shSegwit.redeem.output).toString('hex'));
        assert.equal(prevTxs[0].amount, utxos[0].amount);
        assert.isTrue(signRawTransactionStub.args[0][2].includes(PRIVATE_KEY));

        getUtxosStub.restore();
        signRawTransactionStub.restore();
        sendRawTransactionStub.restore();
    });

    it('should transferBtc, multisig', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const amountInBtc = 2000;
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc }];
        const redeemScript =
            '5221039fac837f0c8a3f93fd63a9574677ca86bb60427149ac8c104d0f7da0be0555132103c35665b6940450ec15219634c4a85e8432bf4d89d2de265274b7b70e83d5982a52ae';

        const senderAddressInformation = {
            address: '2MtEkevhQZpdFH4DGHjWm68HYD8hPZgaTeH',
            info: {
                members: [
                    {
                        address: 'mzP29BbArPnUuAdr1uFX3ZwbDUiNEkW5HH',
                        privateKey: 'cVGMwpMZEatVCTAz5hr4h56fvSHb2EqnxzHGCmxqXbASkBmGtZLX'
                    },
                    {
                        address: 'mzYTf3HKxbNWFUodyMqGGc5Az7fsACQoCb',
                        privateKey: 'cRESFZCZZ7tEJPBoKBG53WU5xALnxpDN38s9jDVtkiYdKRuSehcx'
                    }
                ],
                redeemScript
            }
        };

        const utxos = [
            {
                amount: 3000,
                txid: 'dcec9f208a62edb700819331aab376c17620e4afad0cda4db2277c5313d3f12d',
                vout: 0,
                scriptPubKey: 'a914f66ff70094b55bdd8e07c21ef4ae4e9860a8f52887'
            }
        ];

        const prevTxs = [
            {
                txid: 'dcec9f208a62edb700819331aab376c17620e4afad0cda4db2277c5313d3f12d',
                vout: 0,
                scriptPubKey: 'a914f66ff70094b55bdd8e07c21ef4ae4e9860a8f52887',
                redeemScript,
                amount: 3000
            }
        ];

        const txHex = `01000000012df1d313537c27b24dda0cadafe42076c176b3aa31938100b7ed628a209fecdc0000000000ffffffff0200d0ed902e0000001976a914b6b298fc195725922d93f27cd01f7f382627de3b88ac606175481700000017a9140ae14f0852fe5c0ddc8b6d288569cc8178d8ad7c8700000000`;
        const signedTxHex = `0100000001804f88711ab22b810318171f43c3bdddc82e4f0e8665ebca7f39986437d023fe00000000d90047304402206c2cf8beda14c077cf56ddc54abfca06ad80315b4b1c7428c1ad922a32a66f9b02200e73c158932f2ac1abe7c347e774fdc8ee2dadc9cd6d5df2ecad6cadd588afc801473044022069769d01863`;
        const txHash = `d6f493316fb648f63c626b10179dbc908090fc2262866f00eee402e99bd82bbb`;

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const signRawTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'signTransaction')
            .resolves(signedTxHex);
        const sendRawTransactionStub = sinon.stub(btcTransactionHelper.nodeClient, 'sendTransaction').resolves(txHash);

        const result = await btcTransactionHelper.transferBtc(
            senderAddressInformation,
            recipientsTransactionInformation
        );

        assert.equal(result, txHash);

        assert.isTrue(getUtxosStub.calledWith(senderAddressInformation.address));
        assert.isTrue(
            signRawTransactionStub.calledWith(txHex, prevTxs, [
                senderAddressInformation.info.members[0].privateKey,
                senderAddressInformation.info.members[1].privateKey
            ])
        );
        assert.isTrue(sendRawTransactionStub.calledWith(signedTxHex));

        getUtxosStub.restore();
        signRawTransactionStub.restore();
        sendRawTransactionStub.restore();
    });

    it('should transferBtc, multisig p2sh-segwit, providing the redeem and witness scripts', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const network = config.network;

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const amountInBtc = 2000;
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc }];

        const member1 = {
            address: 'mzP29BbArPnUuAdr1uFX3ZwbDUiNEkW5HH',
            privateKey: 'cVGMwpMZEatVCTAz5hr4h56fvSHb2EqnxzHGCmxqXbASkBmGtZLX'
        };
        const member2 = {
            address: 'mzYTf3HKxbNWFUodyMqGGc5Az7fsACQoCb',
            privateKey: 'cRESFZCZZ7tEJPBoKBG53WU5xALnxpDN38s9jDVtkiYdKRuSehcx'
        };
        const pubkeys = [member1, member2].map(member => ECPair.fromWIF(member.privateKey, network).publicKey);
        const p2ms = bitcoin.payments.p2ms({ m: 2, pubkeys, network });
        const redeemScript = Buffer.from(p2ms.output).toString('hex');
        const p2shSegwit = bitcoin.payments.p2sh({
            redeem: bitcoin.payments.p2wsh({ redeem: p2ms, network }),
            network
        });

        const senderAddressInformation = {
            address: p2shSegwit.address,
            info: {
                members: [member1, member2],
                redeemScript
            }
        };

        const utxos = [
            {
                amount: 3000,
                txid: 'dcec9f208a62edb700819331aab376c17620e4afad0cda4db2277c5313d3f12d',
                vout: 0,
                scriptPubKey: Buffer.from(bitcoin.address.toOutputScript(p2shSegwit.address, network)).toString('hex')
            }
        ];

        const signedTxHex = `010000000001012df1d313537c27b24dda0cadafe42076c176b3aa31938100b7ed628a209fecdc`;
        const txHash = `d6f493316fb648f63c626b10179dbc908090fc2262866f00eee402e99bd82bbb`;

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const signRawTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'signTransaction')
            .resolves(signedTxHex);
        const sendRawTransactionStub = sinon.stub(btcTransactionHelper.nodeClient, 'sendTransaction').resolves(txHash);

        const result = await btcTransactionHelper.transferBtc(
            senderAddressInformation,
            recipientsTransactionInformation
        );

        assert.equal(result, txHash);

        const prevTxs = signRawTransactionStub.args[0][1];
        assert.lengthOf(prevTxs, 1);
        assert.equal(prevTxs[0].txid, utxos[0].txid);
        assert.equal(prevTxs[0].vout, utxos[0].vout);
        assert.equal(prevTxs[0].scriptPubKey, utxos[0].scriptPubKey);
        assert.equal(prevTxs[0].redeemScript, Buffer.from(p2shSegwit.redeem.output).toString('hex'));
        assert.equal(prevTxs[0].witnessScript, redeemScript);
        assert.equal(prevTxs[0].amount, utxos[0].amount);
        assert.isTrue(signRawTransactionStub.args[0][2].includes(member1.privateKey));
        assert.isTrue(signRawTransactionStub.args[0][2].includes(member2.privateKey));

        getUtxosStub.restore();
        signRawTransactionStub.restore();
        sendRawTransactionStub.restore();
    });

    it('should transferBtc, multisig bech32, providing the witness script only', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const network = config.network;

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const amountInBtc = 2000;
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc }];

        const member1 = {
            address: 'mzP29BbArPnUuAdr1uFX3ZwbDUiNEkW5HH',
            privateKey: 'cVGMwpMZEatVCTAz5hr4h56fvSHb2EqnxzHGCmxqXbASkBmGtZLX'
        };
        const member2 = {
            address: 'mzYTf3HKxbNWFUodyMqGGc5Az7fsACQoCb',
            privateKey: 'cRESFZCZZ7tEJPBoKBG53WU5xALnxpDN38s9jDVtkiYdKRuSehcx'
        };
        const pubkeys = [member1, member2].map(member => ECPair.fromWIF(member.privateKey, network).publicKey);
        const p2ms = bitcoin.payments.p2ms({ m: 2, pubkeys, network });
        const redeemScript = Buffer.from(p2ms.output).toString('hex');
        const p2wsh = bitcoin.payments.p2wsh({ redeem: p2ms, network });

        const senderAddressInformation = {
            address: p2wsh.address,
            info: {
                members: [member1, member2],
                redeemScript
            }
        };

        const utxos = [
            {
                amount: 3000,
                txid: 'dcec9f208a62edb700819331aab376c17620e4afad0cda4db2277c5313d3f12d',
                vout: 0,
                scriptPubKey: Buffer.from(bitcoin.address.toOutputScript(p2wsh.address, network)).toString('hex')
            }
        ];

        const signedTxHex = `010000000001012df1d313537c27b24dda0cadafe42076c176b3aa31938100b7ed628a209fecdc`;
        const txHash = `d6f493316fb648f63c626b10179dbc908090fc2262866f00eee402e99bd82bbb`;

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const signRawTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'signTransaction')
            .resolves(signedTxHex);
        const sendRawTransactionStub = sinon.stub(btcTransactionHelper.nodeClient, 'sendTransaction').resolves(txHash);

        const result = await btcTransactionHelper.transferBtc(
            senderAddressInformation,
            recipientsTransactionInformation
        );

        assert.equal(result, txHash);

        const prevTxs = signRawTransactionStub.args[0][1];
        assert.lengthOf(prevTxs, 1);
        assert.equal(prevTxs[0].txid, utxos[0].txid);
        assert.equal(prevTxs[0].vout, utxos[0].vout);
        assert.equal(prevTxs[0].scriptPubKey, utxos[0].scriptPubKey);
        assert.isUndefined(prevTxs[0].redeemScript);
        assert.equal(prevTxs[0].witnessScript, redeemScript);
        assert.equal(prevTxs[0].amount, utxos[0].amount);
        assert.isTrue(signRawTransactionStub.args[0][2].includes(member1.privateKey));
        assert.isTrue(signRawTransactionStub.args[0][2].includes(member2.privateKey));

        getUtxosStub.restore();
        signRawTransactionStub.restore();
        sendRawTransactionStub.restore();
    });

    it('should fail to transferBtc, multisig when the sender address does not match the redeem script', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc: 2000 }];
        const redeemScript =
            '5221039fac837f0c8a3f93fd63a9574677ca86bb60427149ac8c104d0f7da0be0555132103c35665b6940450ec15219634c4a85e8432bf4d89d2de265274b7b70e83d5982a52ae';

        const senderAddressInformation = {
            address: TEST_BTC_ADDRESS, // not derived from redeemScript above
            info: {
                members: [
                    {
                        address: 'mzP29BbArPnUuAdr1uFX3ZwbDUiNEkW5HH',
                        privateKey: 'cVGMwpMZEatVCTAz5hr4h56fvSHb2EqnxzHGCmxqXbASkBmGtZLX'
                    },
                    {
                        address: 'mzYTf3HKxbNWFUodyMqGGc5Az7fsACQoCb',
                        privateKey: 'cRESFZCZZ7tEJPBoKBG53WU5xALnxpDN38s9jDVtkiYdKRuSehcx'
                    }
                ],
                redeemScript
            }
        };

        const utxos = [
            {
                amount: 3000,
                txid: 'dcec9f208a62edb700819331aab376c17620e4afad0cda4db2277c5313d3f12d',
                vout: 0,
                scriptPubKey: 'a914f66ff70094b55bdd8e07c21ef4ae4e9860a8f52887'
            }
        ];

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);

        await expect(
            btcTransactionHelper.transferBtc(senderAddressInformation, recipientsTransactionInformation)
        ).to.eventually.be.rejectedWith('Error during transfer process');

        getUtxosStub.restore();
    });

    it('should transferBtc, with paymentData', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const recipientAddress = 'mxAyE9QUS2PoKAsNv7h9bx2aBkvoVA68A4';
        const amountInBtc = 2000;
        const recipientsTransactionInformation = [{ recipientAddress, amountInBtc }];
        const paymentData = [Buffer.from('52534b5401d2a3d9f938e13cd947ec05abc7fe734df8dd8260', 'hex')];

        const utxos = [
            {
                amount: 3000,
                txid: '74f7e8c0263be8b23b3deffbaf9ee74239076a0de57c695aef4669e22bee0d01',
                vout: 0,
                scriptPubKey: '76a91481a2a37f24c2d7af1382cfe3f5bfa570705efc3288ac'
            }
        ];

        const txHex = `0100000001010dee2be26946ef5a697ce50d6a073942e79eaffbef3d3bb2e83b26c0e8f7740000000000ffffffff0300d0ed902e0000001976a914b6b298fc195725922d93f27cd01f7f382627de3b88ac60617548170000001976a914bba2e52eae9579b7605d9988d2ebe5bc306251ad88ac00000000000000001b6a1952534b5401d2a3d9f938e13cd947ec05abc7fe734df8dd826000000000`;
        const signedTxHex = `0100000001010dee2be26946ef5a697ce50d6a073942e79eaffbef3d3bb2e83b26c0e8f774000000006a4730440220433a46156385a556ea42e47aff98f1497040bbcd0f6206d3dfe9dbc9933a8806022026a25a95f330c05cc8f8b4d070b54b99101b6b5367e5a29b468c8c4a387138fb0121027eae337ba08d93410ad95778e3dbe10bfaaefa26448683809f16429072103c7`;
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);
        const signRawTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'signTransaction')
            .resolves(signedTxHex);
        const sendRawTransactionStub = sinon.stub(btcTransactionHelper.nodeClient, 'sendTransaction').resolves(txHash);

        const result = await btcTransactionHelper.transferBtc(
            ADDRESS_INFORMATION,
            recipientsTransactionInformation,
            paymentData
        );

        assert.equal(result, txHash);

        assert.isTrue(getUtxosStub.calledWith(ADDRESS_INFORMATION.address));
        assert.isTrue(signRawTransactionStub.calledWith(txHex, [], [ADDRESS_INFORMATION.privateKey]));
        assert.isTrue(sendRawTransactionStub.calledWith(signedTxHex));

        assert.isTrue(signRawTransactionStub.args[0][0].includes(paymentData[0].toString('hex')));

        getUtxosStub.restore();
        signRawTransactionStub.restore();
        sendRawTransactionStub.restore();
    });

    it('should get address balance', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const getUtxosStub = sinon.stub(btcTransactionHelper, 'getUtxos').resolves(utxos);

        const result = await btcTransactionHelper.getAddressBalance(TEST_BTC_ADDRESS);

        assert.equal(result, 6000);

        assert.isTrue(getUtxosStub.calledWith(TEST_BTC_ADDRESS));

        getUtxosStub.restore();
    });

    it('should get transaction', async () => {
        const amountInBtc = 2000;
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const utxos = [
            {
                amount: 1000,
                txid: 'a20b03132ec6c1603c79af9a521ae7b287ed61dea39b8eeb61b603f3b0034a3e',
                vout: 0,
                scriptPubKey: 'a914831bf759c1c7424ba8a849e285ff0a6e4f160b3487'
            }
        ];

        const btcTransactionHelper = new BtcTransactionHelper(config);

        const tx = new bitcoin.Transaction();

        tx.addInput(Buffer.from(utxos[0].txid, 'hex').reverse(), utxos[0].vout);

        tx.addOutput(
            bitcoin.address.toOutputScript(ADDRESS_INFORMATION.address, config.network),
            BigInt(conversion.btcToSatoshis(amountInBtc))
        );

        const getTransactionStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'getRawTransaction')
            .resolves(tx.toHex());

        const result = await btcTransactionHelper.getTransaction(txHash);

        assert.deepEqual(result, tx);

        assert.isTrue(getTransactionStub.calledWith(txHash));

        getTransactionStub.restore();
    });

    it('should fund address with default mining', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const fundAddressStub = sinon.stub(btcTransactionHelper.nodeClient, 'fundAddress').resolves(txHash);
        const mineStub = sinon.stub(btcTransactionHelper, 'mine').resolves();

        const result = await btcTransactionHelper.fundAddress(TEST_BTC_ADDRESS, 2000);

        assert.equal(result, txHash);

        assert.isTrue(fundAddressStub.calledWith(TEST_BTC_ADDRESS, '2000.00000000'));

        assert.isTrue(mineStub.calledOnce);

        fundAddressStub.restore();
    });

    it('should fund address with explicit mining', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const fundAddressStub = sinon.stub(btcTransactionHelper.nodeClient, 'fundAddress').resolves(txHash);
        const mineStub = sinon.stub(btcTransactionHelper, 'mine').resolves();

        const result = await btcTransactionHelper.fundAddress(TEST_BTC_ADDRESS, 2000, true);

        assert.equal(result, txHash);

        assert.isTrue(fundAddressStub.calledWith(TEST_BTC_ADDRESS, '2000.00000000'));

        assert.isTrue(mineStub.calledOnce);

        fundAddressStub.restore();
    });

    it('should fund address without mining', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const fundAddressStub = sinon.stub(btcTransactionHelper.nodeClient, 'fundAddress').resolves(txHash);
        const mineStub = sinon.stub(btcTransactionHelper, 'mine').resolves();

        const result = await btcTransactionHelper.fundAddress(TEST_BTC_ADDRESS, 2000, false);

        assert.equal(result, txHash);

        assert.isTrue(fundAddressStub.calledWith(TEST_BTC_ADDRESS, '2000.00000000'));

        assert.isTrue(mineStub.notCalled);

        fundAddressStub.restore();
    });

    it('should mine', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const txHash = `0550fcfa26839e7b5defdef60cf19e1b3b25324c6998ac66a9a2ddc72b8f34e8`;

        const mineStub = sinon.stub(btcTransactionHelper.nodeClient, 'mine').resolves(txHash);

        const result = await btcTransactionHelper.mine(1);

        assert.equal(result, txHash);

        assert.isTrue(mineStub.calledWith(1));

        mineStub.restore();
    });

    it('should decode base 58 address', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const result = btcTransactionHelper.decodeBase58Address(TEST_BTC_ADDRESS);

        assert.equal(result, '6fbba2e52eae9579b7605d9988d2ebe5bc306251ad');
    });

    it('should decode base 58 address without version', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);

        const result = btcTransactionHelper.decodeBase58Address(TEST_BTC_ADDRESS, false);

        assert.equal(result, 'bba2e52eae9579b7605d9988d2ebe5bc306251ad');
    });

    it('should parse btc raw transaction', async () => {
        for (let i = 0; i < SAMPLE_BTC_TRANSACTIONS.length; i++) {
            // Arrange
            const btcTransaction = SAMPLE_BTC_TRANSACTIONS[i];
            const btcTransactionHelper = new BtcTransactionHelper(config);
            const parsedBtcTransactionStub = sinon
                .stub(btcTransactionHelper, 'parseRawTransaction')
                .resolves(btcTransaction.decodedTx);
            // Act
            const result = await btcTransactionHelper.parseRawTransaction(btcTransaction.rawTx);
            // Assert
            assert.isTrue(parsedBtcTransactionStub.calledWith(btcTransaction.rawTx));
            assert.equal(result.txid, btcTransaction.decodedTx.txid);
            assert.equal(result.hash, btcTransaction.decodedTx.hash);
            assert.equal(JSON.stringify(result), JSON.stringify(btcTransaction.decodedTx));

            parsedBtcTransactionStub.restore();
        }
    });

    it('should failed parsing malformed btc raw transaction', async () => {
        // Arrange
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const decodeError = new Error('Error: TX decode failed');
        decodeError.code = -22;
        sinon.stub(btcTransactionHelper, 'parseRawTransaction').throws(decodeError);

        try {
            await btcTransactionHelper.parseRawTransaction('MALFORMED BTC TRANSACTION');
        } catch (err) {
            assert.strictEqual(err.code, decodeError.code);
            assert.strictEqual(err.message, decodeError.message);
        }
    });

    it('should get latest block number', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const nodeClient = btcTransactionHelper.nodeClient;
        const getBlockCountStub = sinon.stub(nodeClient, 'getBlockCount').resolves(100);
        const result = await btcTransactionHelper.getLatestBlockNumber();

        assert.equal(result, 100);

        getBlockCountStub.restore();
    });

    it('should get block header, with jsonEncoded param true by default', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getBlockHeaderStub = sinon.stub(btcTransactionHelper.nodeClient, 'getBlockHeader');
        getBlockHeaderStub.resolves(blockHeader);
        const actualBlockHeader = await btcTransactionHelper.getBlockHeader(blockHeader.hash);
        assert.isTrue(getBlockHeaderStub.calledWith(blockHeader.hash, true));
        assert.deepEqual(actualBlockHeader, blockHeader);
        getBlockHeaderStub.restore();
    });

    it('should get block header, with jsonEncoded set manually to true', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getBlockHeaderStub = sinon.stub(btcTransactionHelper.nodeClient, 'getBlockHeader');
        getBlockHeaderStub.resolves(blockHeader);
        const actualBlockHeader = await btcTransactionHelper.getBlockHeader(blockHeader.hash, true);
        assert.isTrue(getBlockHeaderStub.calledWith(blockHeader.hash, true));
        assert.deepEqual(actualBlockHeader, blockHeader);
        getBlockHeaderStub.restore();
    });

    it('should get block header as hex when jsonEncoded param is passed as false', async () => {
        const blockHash = '720051c391d1c162c995d645044e63bbe953555c9b28a8fbd5e624c7224d13a3';
        const blockHeaderHex =
            '00000020e23f0060e4adccf6f36da74b7d49ddb41c558da75fa1ded9f6c6dae96b6d3c5aa74ee5e800fa6184aed8464eec15448de8a0ed14c3b0e2983cac13632f19637f2ba57865ffff7f2000000000';
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getBlockHeaderStub = sinon.stub(btcTransactionHelper.nodeClient, 'getBlockHeader');
        getBlockHeaderStub.resolves(blockHeaderHex);
        const actualBlockHeaderHex = await btcTransactionHelper.getBlockHeader(blockHash, false);
        assert.isTrue(getBlockHeaderStub.calledWith(blockHash, false));
        assert.equal(actualBlockHeaderHex, blockHeaderHex);
        getBlockHeaderStub.restore();
    });

    it('should get transactions in mempool, with verbose default false', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getTransactionsInMempoolStub = sinon.stub(btcTransactionHelper.nodeClient, 'getTransactionsInMempool');
        getTransactionsInMempoolStub.resolves([txId1, txId2]);
        const actualTransactionsInMempool = await btcTransactionHelper.getTransactionsInMempool();
        assert.isTrue(getTransactionsInMempoolStub.calledWith(false));
        assert.deepEqual(actualTransactionsInMempool, [txId1, txId2]);
        getTransactionsInMempoolStub.restore();
    });

    it('should get transactions in mempool with verbose', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getTransactionsInMempoolStub = sinon.stub(btcTransactionHelper.nodeClient, 'getTransactionsInMempool');
        getTransactionsInMempoolStub.resolves(transactionsInMempoolVerbose);
        const actualTransactionsInMempool = await btcTransactionHelper.getTransactionsInMempool(true);
        assert.isTrue(getTransactionsInMempoolStub.calledWith(true));
        assert.deepEqual(actualTransactionsInMempool, transactionsInMempoolVerbose);
        getTransactionsInMempoolStub.restore();
    });

    it('should get transactions in mempool with verbose manually set to false', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const getTransactionsInMempoolStub = sinon.stub(btcTransactionHelper.nodeClient, 'getTransactionsInMempool');
        getTransactionsInMempoolStub.resolves([txId1, txId2]);
        const actualTransactionsInMempool = await btcTransactionHelper.getTransactionsInMempool(false);
        assert.isTrue(getTransactionsInMempoolStub.calledWith(false));
        assert.deepEqual(actualTransactionsInMempool, [txId1, txId2]);
        getTransactionsInMempoolStub.restore();
    });

    it('should create a wallet with the default name', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const createWalletStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'createWallet')
            .resolves({ name: 'default', warning: '' });

        const result = await btcTransactionHelper.createWallet();

        assert.isTrue(createWalletStub.calledWith('default'));
        assert.equal(result.name, 'default');

        createWalletStub.restore();
    });

    it('should create a wallet with a custom name', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const createWalletStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'createWallet')
            .resolves({ name: 'my-wallet', warning: '' });

        const result = await btcTransactionHelper.createWallet('my-wallet');

        assert.isTrue(createWalletStub.calledWith('my-wallet'));
        assert.equal(result.name, 'my-wallet');

        createWalletStub.restore();
    });

    it('should wrap createWallet errors in a BtcHelperException', async () => {
        const btcTransactionHelper = new BtcTransactionHelper(config);
        const createWalletStub = sinon
            .stub(btcTransactionHelper.nodeClient, 'createWallet')
            .rejects(new Error('rpc failure'));

        await expect(btcTransactionHelper.createWallet()).to.eventually.be.rejectedWith('Error creating wallet');

        createWalletStub.restore();
    });
});
