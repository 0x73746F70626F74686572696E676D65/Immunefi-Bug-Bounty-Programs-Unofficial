'use strict';
const BtcHelperException = require('./btc-transaction-helper-error');
const BtcNodeHelper = require('./btc-node-helper/index');
const bitcoin = require('bitcoinjs-lib');
const ECPairFactory = require('ecpair').default;
const ecc = require('tiny-secp256k1');
const { btcToSatoshis, satoshisToBtc } = require('./conversion');

const ECPair = ECPairFactory(ecc);

const DEFAULT_BTC_CONFIG = {
    host: 'localhost',
    port: '18332',
    user: undefined,
    pass: undefined,
    network: bitcoin.networks.regtest,
    timeout: 30000,
    txFee: 0.001
};

class BtcTransactionHelper {
    constructor(btcConfig) {
        this.btcConfig = Object.assign({}, DEFAULT_BTC_CONFIG, btcConfig);
        this.createNodeClient();
    }

    createNodeClient() {
        try {
            this.nodeClient = new BtcNodeHelper(this.btcConfig);
        } catch (err) {
            throw new BtcHelperException('Error creating BTC client', err);
        }
    }

    /**
     *
     * @param {AddressType} type
     * @returns {AddressInformation}
     */
    generateBtcAddress(type) {
        try {
            type = type || 'legacy';
            return this.nodeClient.generateAddressInformation(type);
        } catch (err) {
            throw new BtcHelperException('Error creating BTC address', err);
        }
    }

    /**
     *
     * @param {number} signerSize
     * @param {number} requiredSigners
     * @param {AddressType} type
     * @returns {MultisigAddressInformation}
     */
    generateMultisigAddress(signerSize, requiredSigners, type) {
        try {
            return this.nodeClient.generateMultisigAddressInformation(signerSize, requiredSigners, type);
        } catch (err) {
            throw new BtcHelperException('Error creating multisig BTC address', err);
        }
    }

    /**
     *
     * @param {string} address
     * @param {number} amountInBtc
     * @returns {SpendableUtxosInformation}
     */
    async selectSpendableUTXOsFromAddress(address, amountInBtc) {
        const utxos = await this.getUtxos(address);

        const selected = [];
        let accumulated = 0;

        for (let i = 0; i < utxos.length && accumulated < amountInBtc; i++) {
            selected.push(utxos[i]);
            accumulated += utxos[i].amount;
        }

        if (Number.isNaN(accumulated)) {
            throw Error('Invalid balances');
        }

        // At this point `accumulated` should be greater than `amountInBtc`. If not, throw error.
        if (accumulated < amountInBtc) {
            throw Error('The sender does not have enough balance to proceed with the transfer');
        }

        // Necessary to avoid floating point operation issues
        const change = satoshisToBtc(btcToSatoshis(accumulated) - btcToSatoshis(amountInBtc));

        return {
            utxos: selected,
            change: change
        };
    }

    /**
     *
     * @param {string} address
     * @returns {TxOutput[]} utxos
     */
    async getUtxos(address) {
        return await this.nodeClient.getUtxos(address);
    }

    /**
     * Transfers the btc amounts to the recipients specified in the `recipientsTransactionInformation`.
     * Gets the spendable utxos of the `senderAddressInformation` up to the sum of the `amountInBtc`s specified in the `recipientsTransactionInformation`.
     * @param {{address: string, privateKey: string, info?: any }} senderAddressInformation
     * @param {Array<{recipientAddress: string, amountInBtc: number}>} recipientsTransactionInformation
     * @param {Buffer[]} paymentData
     * @returns {string} btcTxHash
     */
    async transferBtc(senderAddressInformation, recipientsTransactionInformation, paymentData) {
        try {
            const totalAmountInBtc = recipientsTransactionInformation.reduce(
                (sum, output) => sum + output.amountInBtc,
                0
            );

            const fromAddress = senderAddressInformation.address;
            const utxosInfo = await this.selectSpendableUTXOsFromAddress(fromAddress, totalAmountInBtc);

            const tx = new bitcoin.Transaction();

            utxosInfo.utxos.forEach(uxto => {
                tx.addInput(Buffer.from(uxto.txid, 'hex').reverse(), uxto.vout);
            });

            // Adding the transfer recipientsTransactionInformation outputs
            recipientsTransactionInformation.forEach(output => {
                tx.addOutput(
                    bitcoin.address.toOutputScript(output.recipientAddress, this.btcConfig.network),
                    BigInt(this.nodeClient.btcToSatoshis(output.amountInBtc))
                );
            });

            const actualChange = utxosInfo.change - this.btcConfig.txFee;

            // Adding the change output
            if (actualChange > 0) {
                tx.addOutput(
                    bitcoin.address.toOutputScript(fromAddress, this.btcConfig.network),
                    BigInt(this.nodeClient.btcToSatoshis(actualChange))
                );
            }

            if (paymentData) {
                paymentData.forEach(data => {
                    const dataScript = bitcoin.payments.embed({ data: [data] });
                    tx.addOutput(dataScript.output, 0n); // OP_RETURN always with 0 value unless you want to burn coins
                });
            }

            const prevTxs = [];
            let privateKeys = [senderAddressInformation.privateKey];

            if (senderAddressInformation.info) {
                const network = this.nodeClient.getNetwork();
                const multisigScript = senderAddressInformation.info.redeemScript;
                // `createmultisig` returns the same raw multisig script under `redeemScript` regardless of
                // address type; only for `legacy` is that value actually usable as-is as the P2SH redeem script.
                const p2ms = bitcoin.payments.p2ms({ output: Buffer.from(multisigScript, 'hex'), network });
                const p2shLegacy = bitcoin.payments.p2sh({ redeem: p2ms, network });
                const p2shSegwit = bitcoin.payments.p2sh({
                    redeem: bitcoin.payments.p2wsh({ redeem: p2ms, network }),
                    network
                });
                const p2wsh = bitcoin.payments.p2wsh({ redeem: p2ms, network });

                let multisigPrevTxFields;
                if (fromAddress === p2shLegacy.address) {
                    multisigPrevTxFields = { redeemScript: multisigScript };
                } else if (fromAddress === p2shSegwit.address) {
                    multisigPrevTxFields = {
                        redeemScript: Buffer.from(p2shSegwit.redeem.output).toString('hex'),
                        witnessScript: multisigScript
                    };
                } else if (fromAddress === p2wsh.address) {
                    multisigPrevTxFields = { witnessScript: multisigScript };
                } else {
                    throw new Error(`Address ${fromAddress} does not match the provided multisig redeem script`);
                }

                utxosInfo.utxos.forEach(uxto => {
                    prevTxs.push({
                        txid: uxto.txid,
                        vout: uxto.vout,
                        scriptPubKey: uxto.scriptPubKey.toString('hex'),
                        ...multisigPrevTxFields,
                        amount: uxto.amount
                    });
                });

                privateKeys = senderAddressInformation.info.members.map(a => a.privateKey);
            } else {
                // p2sh-segwit inputs cannot be signed from the private key alone,
                // `signrawtransactionwithkey` requires the redeem script in prevtxs
                const network = this.nodeClient.getNetwork();
                const keyPair = ECPair.fromWIF(senderAddressInformation.privateKey, network);
                const p2shSegwit = bitcoin.payments.p2sh({
                    redeem: bitcoin.payments.p2wpkh({ pubkey: keyPair.publicKey, network }),
                    network
                });
                if (fromAddress === p2shSegwit.address) {
                    utxosInfo.utxos.forEach(uxto => {
                        prevTxs.push({
                            txid: uxto.txid,
                            vout: uxto.vout,
                            scriptPubKey: uxto.scriptPubKey.toString('hex'),
                            redeemScript: Buffer.from(p2shSegwit.redeem.output).toString('hex'),
                            amount: uxto.amount
                        });
                    });
                }
            }

            const signedTx = await this.nodeClient.signTransaction(tx.toHex(), prevTxs, privateKeys);
            return this.nodeClient.sendTransaction(signedTx);
        } catch (err) {
            throw new BtcHelperException('Error during transfer process', err);
        }
    }

    /**
     *
     * @param {string} address
     * @returns {number}
     */
    async getAddressBalance(address) {
        const utxos = await this.getUtxos(address);
        return utxos.reduce((sum, utxo) => sum + utxo.amount, 0);
    }

    /**
     *
     * @param {Buffer} outputScript
     * @returns {string}
     */
    getOutputAddress(outputScript) {
        try {
            return bitcoin.address.fromOutputScript(outputScript, this.btcConfig.network);
        } catch {
            // Outputs with OP_RETURN do not have an address
            return null;
        }
    }

    /**
     *
     * @param {string} txHash
     * @returns {Transaction}
     */
    async getTransaction(txHash) {
        let rawTx = await this.nodeClient.getRawTransaction(txHash);
        return bitcoin.Transaction.fromHex(rawTx);
    }

    /**
     *
     * @param {string} address to be funded
     * @param {number} amountInBtc in btc to be send to the address
     * @param {boolean} mineBlock if true, a block will be mined after the transaction is sent. Defaults to true.
     * @returns {string} btcTxHash
     */
    async fundAddress(address, amountInBtc, mineBlock = true) {
        const fundAmount = Number(amountInBtc).toFixed(8);
        const btcTxHash = await this.nodeClient.fundAddress(address, fundAmount);
        if (mineBlock) {
            await this.mine();
        }
        return btcTxHash;
    }

    /**
     *
     * @param {number} blocks to mine. Defaults to 1.
     * @returns {string} btcTxHash
     */
    async mine(blocks = 1) {
        return await this.nodeClient.mine(blocks);
    }

    /**
     *
     * @returns {number} txFee
     */
    getFee() {
        return this.btcConfig.txFee;
    }

    /**
     *
     * @param {string} address in base58 format
     * @param {boolean} withVersion if false, the version byte will not be included in the returned address. Defaults to true.
     * @returns {string} address in hex format
     */
    decodeBase58Address(address, withVersion = true) {
        const decodedAddress = bitcoin.address.fromBase58Check(address);
        if (!withVersion) {
            return Buffer.from(decodedAddress.hash).toString('hex');
        }
        const versionByte = Buffer.alloc(1);
        versionByte.writeUInt8(decodedAddress.version);
        return Buffer.concat([versionByte, decodedAddress.hash]).toString('hex');
    }

    /**
     *
     * @param {string} rawTransaction string in hex to be parsed into an object
     * @return {BtcTransaction}
     */
    async parseRawTransaction(rawTransaction) {
        return await this.nodeClient.parseRawTransaction(rawTransaction);
    }

    /**
     *
     * @returns {number} latestBlockNumber
     *
     */
    async getLatestBlockNumber() {
        return await this.nodeClient.getBlockCount();
    }

    /**
     *
     * @param {string} blockHash
     * @param {boolean} jsonEncoded defaults to true. If false, the block header will be returned as a hex string.
     * @returns {BlockHeader | string} blockHeader
     */
    getBlockHeader(blockHash, jsonEncoded = true) {
        return this.nodeClient.getBlockHeader(blockHash, jsonEncoded);
    }

    /**
     *
     * @param {boolean} verbose defaults to false. If true, returns an object with the transaction details. If false, returns an array of transaction ids (hashes).
     * @returns {Promise<string[] | MempoolTransactions>}
     */
    getTransactionsInMempool(verbose = false) {
        return this.nodeClient.getTransactionsInMempool(verbose);
    }

    /**
     * Creates a wallet on the node so wallet-dependent methods (e.g. `mine`, `fundAddress`)
     * can be used. Bitcoin Core no longer auto-creates a default wallet on startup.
     * @param {string} walletName defaults to 'default'
     * @returns {{name: string, warning: string}} result
     */
    async createWallet(walletName = 'default') {
        try {
            return await this.nodeClient.createWallet(walletName);
        } catch (err) {
            throw new BtcHelperException('Error creating wallet', err);
        }
    }
}

module.exports = BtcTransactionHelper;
