package co.rsk.federate;

import co.rsk.bitcoinj.core.BtcTransaction;
import co.rsk.bitcoinj.core.Coin;
import co.rsk.bitcoinj.core.Sha256Hash;
import co.rsk.core.RskAddress;
import co.rsk.crypto.Keccak256;
import co.rsk.federate.signing.utils.TestUtils;
import co.rsk.peg.BridgeEvents;
import co.rsk.peg.pegin.RejectedPeginReason;

import java.util.*;

import org.ethereum.core.CallTransaction;
import org.ethereum.crypto.ECKey;
import org.ethereum.vm.DataWord;
import org.ethereum.vm.LogInfo;
import org.ethereum.vm.PrecompiledContracts;

public final class EventsTestUtils {

    private EventsTestUtils() {
    }

    private static final byte[] BRIDGE_ADDRESS = PrecompiledContracts.BRIDGE_ADDR.getBytes();

    public static List<DataWord> buildCustomTopics(CallTransaction.Function event, List<byte[]> topicsToAdd) {
        List<DataWord> topics = new ArrayList<>();

        byte[] eventSignature = event.encodeSignatureLong();
        topics.add(DataWord.valueOf(eventSignature));
        for (byte[] topicToAdd : topicsToAdd) {
            topics.add(DataWord.valueOf(topicToAdd));
        }

        return topics;
    }

    public static List<DataWord> buildEncodedTopics(CallTransaction.Function bridgeEvent, Object... args) {
        byte[][] encodedTopicsInBytes = bridgeEvent.encodeEventTopics(args);
        return LogInfo.byteArrayToList(encodedTopicsInBytes);
    }

    public static byte[] buildEncodedData(CallTransaction.Function bridgeEvent, Object... args) {
        return bridgeEvent.encodeEventData(args);
    }

    public static LogInfo createPegoutTransactionCreatedLog(
        Sha256Hash pegoutBtcTxHash,
        byte[] serializedOutpointValues
    ) {
        CallTransaction.Function pegoutTransactionCreatedEvent = BridgeEvents.PEGOUT_TRANSACTION_CREATED.getEvent();
        byte[] pegoutTransactionCreatedSignatureTopic = pegoutTransactionCreatedEvent.encodeSignatureLong();
        List<DataWord> topics = new ArrayList<>();
        topics.add(DataWord.valueOf(pegoutTransactionCreatedSignatureTopic));
        topics.add(DataWord.valueOf(pegoutBtcTxHash.getBytes()));

        byte[] pegoutTransactionCreatedEncodedData = pegoutTransactionCreatedEvent.encodeEventData(serializedOutpointValues);

        return new LogInfo(
            PrecompiledContracts.BRIDGE_ADDR.getBytes(),
            topics,
            pegoutTransactionCreatedEncodedData
        );
    }

    public static LogInfo createBatchPegoutCreatedLog(
        Sha256Hash pegoutBtcTxHash,
        List<Keccak256> pegoutRequestRskTxHashes
    ) {
        CallTransaction.Function batchPegoutCreatedEvent = BridgeEvents.BATCH_PEGOUT_CREATED.getEvent();
        byte[] batchPegoutEventSignatureTopic = batchPegoutCreatedEvent.encodeSignatureLong();
        List<DataWord> topics = new ArrayList<>();
        topics.add(DataWord.valueOf(batchPegoutEventSignatureTopic));
        topics.add(DataWord.valueOf(pegoutBtcTxHash.getBytes()));

        byte[] encodedData = batchPegoutCreatedEvent.encodeEventData(serializeRskTxHashes(pegoutRequestRskTxHashes));

        return new LogInfo(
            PrecompiledContracts.BRIDGE_ADDR.getBytes(),
            topics,
            encodedData
        );
    }

    public static LogInfo createReleaseRequestedLog(
        Keccak256 pegoutCreationRskTxHash,
        Sha256Hash pegoutBtcTxHash,
        Coin amount
    ) {
        CallTransaction.Function releaseRequestedEvent = BridgeEvents.RELEASE_REQUESTED.getEvent();
        List<DataWord> topics = buildEncodedTopics(releaseRequestedEvent, pegoutCreationRskTxHash.getBytes(), pegoutBtcTxHash.getBytes());
        byte[] data = buildEncodedData(releaseRequestedEvent, amount.getValue());

        return buildLogInfoFrom(BRIDGE_ADDRESS, topics, data);
    }

    public static LogInfo buildLogInfoFrom(byte[] sender, List<DataWord> topics, byte[] data) {
        return new LogInfo(sender, topics, data);
    }

    public static LogInfo createUpdateCollectionsLog(RskAddress senderAddress) {
        CallTransaction.Function updateCollectionsEvent = BridgeEvents.UPDATE_COLLECTIONS.getEvent();

        byte[] updateCollectionsSignatureTopic = updateCollectionsEvent.encodeSignatureLong();
        List<DataWord> topics = new ArrayList<>();
        topics.add(DataWord.valueOf(updateCollectionsSignatureTopic));

        byte[] encodedData = updateCollectionsEvent.encodeEventData(senderAddress.toString());

        return new LogInfo(
            PrecompiledContracts.BRIDGE_ADDR.getBytes(),
            topics,
            encodedData
        );
    }

    public static LogInfo createRejectedPeginLog(Sha256Hash pegoutBtcTxHash, RejectedPeginReason reason) {
        CallTransaction.Function rejectedPeginEvent = BridgeEvents.REJECTED_PEGIN.getEvent();

        byte[] rejectedPeginSignatureTopic = rejectedPeginEvent.encodeSignatureLong();
        List<DataWord> topics = new ArrayList<>();
        topics.add(DataWord.valueOf(rejectedPeginSignatureTopic));
        topics.add(DataWord.valueOf(pegoutBtcTxHash.getBytes()));

        byte[] encodedData = rejectedPeginEvent.encodeEventData(reason.getValue());

        return new LogInfo(PrecompiledContracts.BRIDGE_ADDR.getBytes(),
            topics, encodedData);
    }

    public static List<LogInfo> createCommonPegoutLogs(
        Keccak256 pegoutCreationRskTxHash,
        BtcTransaction pegoutBtcTx,
        byte[] serializedOutpointValues
    ) {
        List<LogInfo> logs = new ArrayList<>();

        // update_collections
        ECKey senderKey = TestUtils.getEcKeyFromSeed("senderKey");
        RskAddress senderAddress = new RskAddress(senderKey.getAddress());
        LogInfo updateCollectionsLog = createUpdateCollectionsLog(senderAddress);
        logs.add(updateCollectionsLog);

        // release_requested
        Coin pegoutAmount = Coin.COIN;
        LogInfo releaseRequestedLog = createReleaseRequestedLog(
            pegoutCreationRskTxHash,
            pegoutBtcTx.getHash(),
            pegoutAmount
        );
        logs.add(releaseRequestedLog);

        // batch_pegout_created
        Keccak256 pegoutRequestRskTxHash = TestUtils.createHash(10);
        List<Keccak256> pegoutRequestRskTxHashes = Collections.singletonList(pegoutRequestRskTxHash);
        LogInfo batchPegoutCreatedLog = createBatchPegoutCreatedLog(
            pegoutBtcTx.getHash(),
            pegoutRequestRskTxHashes
        );
        logs.add(batchPegoutCreatedLog);

        // pegout_transaction_created
        LogInfo pegoutTransactionCreatedLog = createPegoutTransactionCreatedLog(
            pegoutBtcTx.getHash(),
            serializedOutpointValues
        );
        logs.add(pegoutTransactionCreatedLog);

        return logs;
    }

    /*
    TODO: Remove this method once {@link co.rsk.peg.utils.BridgeEventLoggerImpl#serializeRskTxHashes(List<Keccak256> rskTxHashes)} is moved to a util class
     */
    private static byte[] serializeRskTxHashes(List<Keccak256> rskTxHashes) {
        List<byte[]> rskTxHashesList = rskTxHashes.stream()
            .map(Keccak256::getBytes)
            .toList();
        int rskTxHashesLength = rskTxHashesList.stream().mapToInt(key -> key.length).sum();

        byte[] serializedRskTxHashes = new byte[rskTxHashesLength];
        int copyPos = 0;
        for (byte[] rskTxHash : rskTxHashesList) {
            System.arraycopy(rskTxHash, 0, serializedRskTxHashes, copyPos, rskTxHash.length);
            copyPos += rskTxHash.length;
        }

        return serializedRskTxHashes;
    }
}
