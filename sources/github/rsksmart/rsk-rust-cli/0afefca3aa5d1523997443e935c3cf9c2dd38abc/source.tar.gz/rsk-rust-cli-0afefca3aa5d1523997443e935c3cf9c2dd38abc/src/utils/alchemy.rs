// src/utils/alchemy.rs
use anyhow::{Result, anyhow};
use reqwest::Client;
use serde_json::Value;

pub struct AlchemyClient {
    client: Client,
    api_key: String,
    is_testnet: bool,
}

impl AlchemyClient {
    // pub fn new(api_key: String, is_testnet: bool) -> Self {
    //     Self {
    //         client: reqwest::Client::new(),
    //         api_key,
    //         is_testnet,
    //     }
    // }
    pub fn new(api_key: String, is_testnet: bool) -> Self {
        let client = Client::builder()
            .https_only(true) // Restrict to HTTPS
            .use_rustls_tls() // Use rustls for TLS (more secure, avoids system-specific issues)
            .build()
            .expect("Failed to build reqwest client");
        Self {
            client,
            api_key,
            is_testnet,
        }
    }

    pub fn get_base_url(&self) -> String {
        let network = if self.is_testnet {
            "testnet"
        } else {
            "mainnet"
        };
        format!("https://rootstock-{}.g.alchemy.com/v2", network)
    }

    pub async fn get_asset_transfers(
        &self,
        address: &str,
        limit: u32,
        from_block: Option<&str>,
        to_block: Option<&str>,
    ) -> Result<Value> {
        let url = self.get_base_url();

        let params = serde_json::json!([{
            "fromBlock": from_block.unwrap_or("0x0"),
            "toBlock": to_block.unwrap_or("latest"),
            "fromAddress": address,
            "category": ["external", "erc20"],
            "withMetadata": true,
            "excludeZeroValue": false,
            "maxCount": format!("0x{:x}", limit),
        }]);

        let response = self
            .client
            .post(&url)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .json(&serde_json::json!({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "alchemy_getAssetTransfers",
                "params": params
            }))
            .send()
            .await
            .map_err(|e| anyhow!("Request failed: {}", e))?
            .json::<Value>()
            .await
            .map_err(|e| anyhow!("Failed to parse response: {}", e))?;

        if let Some(error) = response.get("error") {
            return Err(anyhow!("Alchemy API error: {}", error));
        }

        Ok(response)
    }

    pub async fn get_block_by_number(&self, block_number: u64) -> Result<Option<Value>> {
        let url = self.get_base_url();
        let block_number_hex = format!("0x{:x}", block_number);

        let response = self
            .client
            .post(&url)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .json(&serde_json::json!({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "eth_getBlockByNumber",
                "params": [block_number_hex, false]  // false to get transaction hashes only
            }))
            .send()
            .await
            .map_err(|e| anyhow!("Request failed: {}", e))?
            .json::<Value>()
            .await?;

        if let Some(error) = response.get("error") {
            return Err(anyhow!("Alchemy API error: {}", error));
        }

        Ok(response
            .get("result")
            .and_then(|r| if r.is_null() { None } else { Some(r.clone()) }))
    }
}
