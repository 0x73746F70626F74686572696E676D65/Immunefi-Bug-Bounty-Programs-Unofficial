module.exports = {
  'transpileDependencies': [
    'vuetify'
  ]
}