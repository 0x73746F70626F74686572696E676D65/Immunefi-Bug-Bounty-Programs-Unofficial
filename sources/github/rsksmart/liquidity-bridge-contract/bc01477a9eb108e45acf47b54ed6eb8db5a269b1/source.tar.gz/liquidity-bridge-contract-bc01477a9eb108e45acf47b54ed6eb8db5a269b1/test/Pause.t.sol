// SPDX-License-Identifier: MIT
pragma solidity 0.8.25;

import "forge-std/Test.sol";
import {FlyoverDiscovery} from "src/FlyoverDiscovery.sol";
import {CollateralManagementContract} from "src/CollateralManagement.sol";
import {ICollateralManagement} from "src/interfaces/ICollateralManagement.sol";
import {PauseRegistry} from "src/PauseRegistry.sol";
import {PegInContract} from "src/PegInContract.sol";
import {PegOutContract} from "src/PegOutContract.sol";
import {BridgeMock} from "src/test-contracts/BridgeMock.sol";
import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
import {Flyover} from "src/libraries/Flyover.sol";
import {IPauseRegistry} from "src/interfaces/IPauseRegistry.sol";
import {Quotes} from "src/libraries/Quotes.sol";

/// @title System-wide Pause Functionality Tests
/// @notice Tests that verify pause/unpause operations across all contracts in the system
contract PauseTest is Test {
    PauseRegistry public pauseRegistry;
    FlyoverDiscovery public flyoverDiscovery;
    CollateralManagementContract public collateralManagement;
    PegInContract public pegInContract;
    PegOutContract public pegOutContract;
    BridgeMock public bridgeMock;

    address public owner;
    address public pauser;
    address[] public signers;

    bytes32 constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    uint256 constant TEST_MIN_COLLATERAL = 0.6 ether;

    function setUp() public {
        owner = address(this);
        pauser = makeAddr("pauser");
        vm.deal(pauser, 100 ether);

        for (uint i = 0; i < 5; i++) {
            address signer = makeAddr(string.concat("signer", vm.toString(i)));
            vm.deal(signer, 100 ether);
            signers.push(signer);
        }

        _deployContracts();
    }

    function _deployContracts() internal {
        bridgeMock = new BridgeMock();

        PauseRegistry prImpl = new PauseRegistry();
        pauseRegistry = PauseRegistry(
            payable(
                address(
                    new ERC1967Proxy(
                        address(prImpl),
                        abi.encodeCall(prImpl.initialize, (0, owner))
                    )
                )
            )
        );

        CollateralManagementContract cmImpl = new CollateralManagementContract();
        collateralManagement = CollateralManagementContract(
            payable(
                address(
                    new ERC1967Proxy(
                        address(cmImpl),
                        abi.encodeCall(
                            cmImpl.initialize,
                            (
                                owner,
                                30,
                                TEST_MIN_COLLATERAL,
                                500,
                                1000,
                                pauseRegistry
                            )
                        )
                    )
                )
            )
        );

        FlyoverDiscovery dImpl = new FlyoverDiscovery();
        flyoverDiscovery = FlyoverDiscovery(
            payable(
                address(
                    new ERC1967Proxy(
                        address(dImpl),
                        abi.encodeCall(
                            dImpl.initialize,
                            (
                                owner,
                                5000,
                                address(collateralManagement),
                                pauseRegistry
                            )
                        )
                    )
                )
            )
        );

        PegInContract piImpl = new PegInContract();
        pegInContract = PegInContract(
            payable(
                address(
                    new ERC1967Proxy(
                        address(piImpl),
                        abi.encodeCall(
                            piImpl.initialize,
                            (
                                owner,
                                payable(address(bridgeMock)),
                                2300 * 65164000,
                                0.5 ether,
                                address(collateralManagement),
                                false,
                                pauseRegistry
                            )
                        )
                    )
                )
            )
        );

        PegOutContract poImpl = new PegOutContract();
        pegOutContract = PegOutContract(
            payable(
                address(
                    new ERC1967Proxy(
                        address(poImpl),
                        abi.encodeCall(
                            poImpl.initialize,
                            (
                                owner,
                                payable(address(bridgeMock)),
                                2300 * 65164000,
                                address(collateralManagement),
                                false,
                                900,
                                pauseRegistry
                            )
                        )
                    )
                )
            )
        );

        vm.warp(block.timestamp + 31);
        collateralManagement.grantRole(
            collateralManagement.COLLATERAL_ADDER(),
            address(flyoverDiscovery)
        );
        collateralManagement.grantRole(
            collateralManagement.COLLATERAL_SLASHER(),
            address(pegInContract)
        );
        collateralManagement.grantRole(
            collateralManagement.COLLATERAL_SLASHER(),
            address(pegOutContract)
        );
    }

    function _grantPauserRole() internal {
        pauseRegistry.grantRole(PAUSER_ROLE, pauser);
    }

    function test_CanPauseAllContractsSimultaneously() public {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("Emergency system-wide pause");

        (bool isPausedPI, string memory reasonPI, ) = pegInContract
            .pauseStatus();
        (bool isPausedPO, string memory reasonPO, ) = pegOutContract
            .pauseStatus();
        (bool isPausedD, string memory reasonD, ) = flyoverDiscovery
            .pauseStatus();
        (bool isPausedC, string memory reasonC, ) = collateralManagement
            .pauseStatus();

        assertTrue(isPausedD);
        assertEq(reasonD, "Emergency system-wide pause");
        assertTrue(isPausedC);
        assertEq(reasonC, "Emergency system-wide pause");
        assertTrue(isPausedPI);
        assertEq(reasonPI, "Emergency system-wide pause");
        assertTrue(isPausedPO);
        assertEq(reasonPO, "Emergency system-wide pause");
    }

    function test_CanUnpauseAllContractsSimultaneously() public {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("Test");

        (bool isPausedPI, , ) = pegInContract.pauseStatus();
        (bool isPausedPO, , ) = pegOutContract.pauseStatus();
        (bool isPausedD, , ) = flyoverDiscovery.pauseStatus();
        (bool isPausedC, , ) = collateralManagement.pauseStatus();
        assertTrue(isPausedD);
        assertTrue(isPausedC);
        assertTrue(isPausedPI);
        assertTrue(isPausedPO);

        vm.prank(pauser);
        pauseRegistry.unpause();

        string memory reasonD;
        string memory reasonC;
        string memory reasonPI;
        string memory reasonPO;
        (isPausedD, reasonD, ) = flyoverDiscovery.pauseStatus();
        (isPausedC, reasonC, ) = collateralManagement.pauseStatus();
        (isPausedPI, reasonPI, ) = pegInContract.pauseStatus();
        (isPausedPO, reasonPO, ) = pegOutContract.pauseStatus();

        assertFalse(isPausedPI);
        assertEq(reasonPI, "");
        assertFalse(isPausedPO);
        assertEq(reasonPO, "");
        assertFalse(isPausedD);
        assertEq(reasonD, "");
        assertFalse(isPausedC);
        assertEq(reasonC, "");
    }

    function test_TracksPauseTimestampsConsistentlyAcrossContracts() public {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("Timestamp test");

        (, , uint256 timeD) = flyoverDiscovery.pauseStatus();
        (, , uint256 timeC) = collateralManagement.pauseStatus();
        (, , uint256 timePI) = pegInContract.pauseStatus();
        (, , uint256 timePO) = pegOutContract.pauseStatus();

        assertTrue(timeD > 0 && timeC > 0 && timePI > 0 && timePO > 0);
        assertEq(timeD, timeC);
        assertEq(timePI, timeD);
        assertEq(timePO, timePI);
    }

    function test_BlocksCriticalOperationsAcrossAllContractsWhenPaused()
        public
    {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("Emergency");

        vm.prank(signers[1], signers[1]);
        vm.expectRevert(abi.encodeWithSignature("EnforcedPause()"));
        flyoverDiscovery.register{value: 1 ether}(
            "Test LP",
            "http://localhost/api",
            true,
            Flyover.ProviderType.PegIn
        );

        collateralManagement.grantRole(
            collateralManagement.COLLATERAL_ADDER(),
            owner
        );

        vm.expectRevert(abi.encodeWithSignature("EnforcedPause()"));
        collateralManagement.addPegInCollateralTo{value: 1 ether}(signers[1]);

        vm.expectRevert(abi.encodeWithSignature("EnforcedPause()"));
        pegInContract.deposit{value: 1 ether}();

        Quotes.PegOutQuote memory quote;
        vm.expectRevert(abi.encodeWithSignature("EnforcedPause()"));
        pegOutContract.depositPegOut{value: 1 ether}(quote, hex"010203");
    }

    function test_AllowsViewFunctionsToContinueWorkingWhenPaused() public view {
        assertTrue(flyoverDiscovery.getProvidersId() >= 0);
        assertEq(collateralManagement.getMinCollateral(), TEST_MIN_COLLATERAL);
        assertTrue(pegInContract.getMinPegIn() > 0);
        assertTrue(pegOutContract.dustThreshold() > 0);
    }

    function test_AllowsNonPausableFunctionsToContinueWorking() public {
        _grantPauserRole();

        // First, register a provider before pausing
        vm.prank(signers[1], signers[1]);
        flyoverDiscovery.register{value: 1 ether}(
            "Test LP",
            "http://localhost/api",
            true,
            Flyover.ProviderType.PegIn
        );

        uint256 providerId = flyoverDiscovery.getProvidersId();
        assertEq(providerId, 1, "Provider should be registered");

        // Pause via central registry
        vm.prank(pauser);
        pauseRegistry.pause("Emergency");

        // Verify contracts are paused
        (bool isPausedD, , ) = flyoverDiscovery.pauseStatus();
        (bool isPausedC, , ) = collateralManagement.pauseStatus();
        assertTrue(isPausedD, "FlyoverDiscovery should be paused");
        assertTrue(isPausedC, "CollateralManagement should be paused");

        // Test 1: setProviderStatus should work even when paused (not marked with whenNotPaused)
        vm.prank(signers[1]);
        flyoverDiscovery.setProviderStatus(providerId, false);
        Flyover.LiquidityProvider memory provider = flyoverDiscovery
            .getProvider(signers[1]);
        assertFalse(
            provider.status,
            "Provider status should be updated to false"
        );

        // Set it back to true
        vm.prank(signers[1]);
        flyoverDiscovery.setProviderStatus(providerId, true);
        provider = flyoverDiscovery.getProvider(signers[1]);
        assertTrue(
            provider.status,
            "Provider status should be updated to true"
        );

        // Test 2: withdrawRewards should work even when paused (not marked with whenNotPaused)
        // Note: In a real scenario, rewards would come from slashing, but for testing
        // we'll verify the function can be called (it will revert with NothingToWithdraw if no rewards)
        // The important part is that it doesn't revert due to pause
        vm.expectRevert(
            abi.encodeWithSelector(
                ICollateralManagement.NothingToWithdraw.selector,
                signers[1]
            )
        );
        vm.prank(signers[1]);
        collateralManagement.withdrawRewards();

        // Test 3: withdrawCollateral should work even when paused (not marked with whenNotPaused)
        // This requires the provider to have resigned first, so we'll just verify it doesn't revert
        // due to pause (it will revert for other reasons like not resigned)
        vm.expectRevert(
            abi.encodeWithSelector(
                ICollateralManagement.NotResigned.selector,
                signers[1]
            )
        );
        vm.prank(signers[1]);
        collateralManagement.withdrawCollateral();
    }

    function test_RestoresFullFunctionalityAfterSystemWideUnpause() public {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("Test");

        (bool isPausedD, , ) = flyoverDiscovery.pauseStatus();
        (bool isPausedC, , ) = collateralManagement.pauseStatus();
        (bool isPausedPI, , ) = pegInContract.pauseStatus();
        (bool isPausedPO, , ) = pegOutContract.pauseStatus();
        assertTrue(isPausedD);
        assertTrue(isPausedC);
        assertTrue(isPausedPI);
        assertTrue(isPausedPO);

        vm.prank(pauser);
        pauseRegistry.unpause();

        (isPausedD, , ) = flyoverDiscovery.pauseStatus();
        (isPausedC, , ) = collateralManagement.pauseStatus();
        (isPausedPI, , ) = pegInContract.pauseStatus();
        (isPausedPO, , ) = pegOutContract.pauseStatus();
        assertFalse(isPausedD);
        assertFalse(isPausedC);
        assertFalse(isPausedPI);
        assertFalse(isPausedPO);

        vm.prank(signers[1], signers[1]);
        flyoverDiscovery.register{value: 1 ether}(
            "Test LP",
            "http://localhost/api",
            true,
            Flyover.ProviderType.PegIn
        );

        assertEq(flyoverDiscovery.getProvidersId(), 1);

        collateralManagement.grantRole(
            collateralManagement.COLLATERAL_ADDER(),
            owner
        );
        collateralManagement.addPegInCollateralTo{value: 0.5 ether}(signers[1]);

        assertEq(
            collateralManagement.getPegInCollateral(signers[1]),
            1.5 ether
        );
    }

    function test_PauseOncePausesAllContracts() public {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("System-wide pause");

        (bool isPausedD, , ) = flyoverDiscovery.pauseStatus();
        (bool isPausedC, , ) = collateralManagement.pauseStatus();
        (bool isPausedPI, , ) = pegInContract.pauseStatus();
        (bool isPausedPO, , ) = pegOutContract.pauseStatus();

        assertTrue(isPausedD, "Discovery should be paused");
        assertTrue(isPausedC, "Collateral should be paused");
        assertTrue(isPausedPI, "PegIn should be paused");
        assertTrue(isPausedPO, "PegOut should be paused");
    }

    function test_CanPerformEmergencyPauseWithCustomReason() public {
        _grantPauserRole();

        string
            memory reason = "Critical security vulnerability detected - immediate pause required";

        vm.prank(pauser);
        pauseRegistry.pause(reason);

        (, string memory reasonD, ) = flyoverDiscovery.pauseStatus();
        (, string memory reasonC, ) = collateralManagement.pauseStatus();
        (, string memory reasonPI, ) = pegInContract.pauseStatus();
        (, string memory reasonPO, ) = pegOutContract.pauseStatus();

        assertEq(reasonD, reason);
        assertEq(reasonC, reason);
        assertEq(reasonPI, reason);
        assertEq(reasonPO, reason);
    }

    function test_MaintainsPauseStateAcrossMultipleOperations() public {
        _grantPauserRole();

        vm.prank(pauser);
        pauseRegistry.pause("Multiple ops");

        vm.startPrank(signers[1], signers[1]);

        vm.expectRevert(abi.encodeWithSignature("EnforcedPause()"));
        flyoverDiscovery.register{value: 1 ether}(
            "LP1",
            "url1",
            true,
            Flyover.ProviderType.PegIn
        );

        vm.expectRevert(abi.encodeWithSignature("EnforcedPause()"));
        flyoverDiscovery.register{value: 1 ether}(
            "LP2",
            "url2",
            true,
            Flyover.ProviderType.PegOut
        );

        vm.stopPrank();

        (bool isPausedD, , ) = flyoverDiscovery.pauseStatus();
        (bool isPausedC, , ) = collateralManagement.pauseStatus();
        (bool isPausedPI, , ) = pegInContract.pauseStatus();
        (bool isPausedPO, , ) = pegOutContract.pauseStatus();

        assertTrue(isPausedD);
        assertTrue(isPausedC);
        assertTrue(isPausedPI);
        assertTrue(isPausedPO);
    }
}
