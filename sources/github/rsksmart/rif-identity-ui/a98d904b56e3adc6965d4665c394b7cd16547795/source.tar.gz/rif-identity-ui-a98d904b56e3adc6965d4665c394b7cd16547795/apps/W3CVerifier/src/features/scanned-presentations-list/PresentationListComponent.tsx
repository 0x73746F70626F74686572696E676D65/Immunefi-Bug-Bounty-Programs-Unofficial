import React from 'react';
import {
  View,
  Text,
  StyleSheet,
} from 'react-native';
import { VerifiedPresentation } from '../../api'
import { colors } from '../../styles';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import Ionicons from 'react-native-vector-icons/Ionicons';

interface PresentationListProps {
  presentations: VerifiedPresentation[];
  strings: any
  handleShowPresentation: (presentation: VerifiedPresentation) => void,
}

const PresentationList: React.FC<PresentationListProps> = ({
  presentations,
  strings,
  handleShowPresentation,
}) => {
  const toDateString = (isoDate: string) => {
    const date = new Date(isoDate)
    
    const day = date.getUTCDate();
    const month = date.getUTCMonth() + 1;
    const year = date.getFullYear();
  
    return `${day}/${month}/${year}`;
  }

  const styles = StyleSheet.create({
    table: {
      height: 350
    },
    row: {
      alignSelf: 'stretch',
      flexDirection: 'row'
    },
    cell: { 
      alignSelf: 'stretch',
      width: 90,
      paddingTop: 10,
      paddingBottom: 10,
      alignItems: 'center'
    },
    headerText: {
      fontWeight: '500',
      fontSize: 10,
      lineHeight: 18,
      color: colors.gray2
    },
    citizenText: {
      color: colors.gray4,
      fontWeight: '500',
      fontSize: 14,
      lineHeight: 18,
    },
    contentText: {
      color: colors.gray3,
      fontWeight: '500',
      fontSize: 10,
      lineHeight: 18,
    },
    citizenCell: {
      width: 140
    }
  })

  const renderRow = (presentation: VerifiedPresentation, i: number) => {
    const rowNumber = i + 1;
    const odd = rowNumber % 2 !== 0

    const backgroundColor = odd ? colors.backgroundGray : colors.white;

    const handleViewPresentation = () => handleShowPresentation(presentation)

    return (
      <TouchableOpacity key={i} onPress={handleViewPresentation} style={{ ...styles.row, backgroundColor }}>
        <View style={{...styles.cell, ...styles.citizenCell}}>
          <Text style={styles.citizenText}>{presentation.fullName || presentation.failureReason}</Text>
        </View>
        <View style={styles.cell}>
          <Text style={styles.contentText}>{toDateString(presentation.dateVerified.toString())}</Text>
        </View>
        <View style={styles.cell}>
          <Ionicons
            name={
              presentation.success
                ? 'checkmark-circle-outline'
                : 'close-circle-outline'
            }
            size={25}
            color={presentation.success ? colors.lightBlue : colors.red}
          />
        </View>
      </TouchableOpacity>
    )
  }

  const header = (
    <View style={{...styles.row, paddingBottom: 0 }}>
      <View style={{...styles.cell, ...styles.citizenCell}}>
        <Text style={styles.headerText}>Citizen</Text>
      </View>
      <View style={styles.cell}>
        <Text style={styles.headerText}>Date</Text>
      </View>
      <View style={styles.cell}>
        <Text style={styles.headerText}>Status</Text>
      </View>
    </View>
  )
  return (
    <View style={styles.table}>
      {header}
      <ScrollView>
        {presentations.map(renderRow)}
      </ScrollView>
    </View>
  )
};

export default PresentationList;
