declare module 'redux-multilanguage';
