module.exports = 'mock-image';
