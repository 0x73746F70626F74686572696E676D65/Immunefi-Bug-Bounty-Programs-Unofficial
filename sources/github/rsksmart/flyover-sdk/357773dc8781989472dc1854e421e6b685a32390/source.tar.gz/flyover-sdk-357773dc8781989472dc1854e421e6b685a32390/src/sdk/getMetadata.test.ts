import { describe, test, expect } from '@jest/globals'
import { type PegoutQuote, type LiquidityProvider, type Quote } from '../api'
import { getMetadata } from './getMetadata'
import JSONbig from 'json-bigint'

const serializer = JSONbig({ useNativeBigInt: true })

const providerMock: LiquidityProvider = {
  id: 1,
  provider: 'any address',
  apiBaseUrl: 'http://localhost:8081',
  name: 'any name',
  status: true,
  providerType: 'pegin',
  siteKey: 'any key',
  liquidityCheckEnabled: true,
  pegin: {
    requiredConfirmations: 7,
    minTransactionValue: BigInt(1),
    maxTransactionValue: BigInt(100),
    fixedFee: BigInt(3),
    feePercentage: 1.25,
    fee: BigInt(1)
  },
  pegout: {
    requiredConfirmations: 5,
    minTransactionValue: BigInt(2),
    maxTransactionValue: BigInt(200),
    fixedFee: BigInt(5),
    feePercentage: 0.35,
    fee: BigInt(2)
  }
}

const pegoutQuoteMock: PegoutQuote = {
  quote: {
    agreementTimestamp: 1,
    btcRefundAddress: 'any address',
    callFee: BigInt(1),
    depositAddr: 'any address',
    depositConfirmations: 1,
    depositDateLimit: 1,
    expireBlocks: 1,
    expireDate: 1,
    gasFee: BigInt(1),
    lbcAddress: 'any address',
    liquidityProviderRskAddress: 'any address',
    lpBtcAddr: 'any address',
    nonce: BigInt(1),
    penaltyFee: BigInt(1),
    rskRefundAddress: 'any address',
    transferConfirmations: 1,
    transferTime: 1,
    value: BigInt(1),
    chainId: 31,
  },
  quoteHash: 'any hash'
}

const peginQuoteMock: Quote = {
  quote: {
    agreementTimestamp: 1,
    btcRefundAddr: 'any address',
    callFee: BigInt(1),
    contractAddr: 'any address',
    confirmations: 1,
    gasLimit: 1,
    lbcAddr: 'any address',
    lpRSKAddr: 'any address',
    nonce: BigInt(1),
    penaltyFee: BigInt(1),
    rskRefundAddr: 'any address',
    timeForDeposit: 1,
    value: BigInt(1),
    callOnRegister: true,
    data: '0x',
    fedBTCAddr: 'any address',
    lpBTCAddr: 'any address',
    lpCallTime: 1,
    gasFee: BigInt(1),
    chainId: 31,
  },
  quoteHash: 'any hash'
}

describe('getMetadata function should', () => {
  test('return pegin and pegout fees', async () => {
    const metadata = await getMetadata(providerMock, null, null)
    expect(metadata.length).toBe(2)
    expect(serializer.stringify(metadata.at(0))).toEqual(serializer.stringify({
      operation: 'PegIn',
      maxAmount: providerMock.pegin.maxTransactionValue,
      minAmount: providerMock.pegin.minTransactionValue,
      blocksToDeliver: providerMock.pegin.requiredConfirmations,
      fees: [
        {
          amount: providerMock.pegin.fixedFee,
          decimals: 0,
          type: 'Fixed',
          description: 'Liquidity provider fixed fee',
          unit: 'Wei'
        },
        {
          amount: providerMock.pegin.feePercentage,
          decimals: 0,
          type: 'Percental',
          description: 'Liquidity provider percentage fee. It is a percentage of the pegged value.'
        }
      ]
    }))

    expect(serializer.stringify(metadata.at(1))).toEqual(serializer.stringify({
      operation: 'PegOut',
      maxAmount: providerMock.pegout.maxTransactionValue,
      minAmount: providerMock.pegout.minTransactionValue,
      blocksToDeliver: providerMock.pegout.requiredConfirmations,
      fees: [
        {
          amount: providerMock.pegout.fixedFee,
          decimals: 0,
          type: 'Fixed',
          description: 'Liquidity provider fixed fee',
          unit: 'Wei'
        },
        {
          amount: providerMock.pegout.feePercentage,
          decimals: 0,
          type: 'Percental',
          description: 'Liquidity provider percentage fee. It is a percentage of the pegged value.'
        }
      ]
    }))
  })

  test('include service fee if pegin quote is provided', async () => {
    const metadata = await getMetadata(providerMock, peginQuoteMock, null)
    expect(serializer.stringify(metadata.at(0)?.fees.at(1))).toEqual(serializer.stringify({
      amount: peginQuoteMock.quote.gasFee,
      decimals: 0,
      type: 'Fixed',
      description: 'Service fee. Pays for the cost of making transactions on behalf of the user',
      unit: 'Wei'
    }))
  })

  test('include service fee if pegout quote is provided', async () => {
    const metadata = await getMetadata(providerMock, null, pegoutQuoteMock)
    expect(serializer.stringify(metadata.at(1)?.fees.at(1))).toEqual(serializer.stringify({
      amount: pegoutQuoteMock.quote.gasFee,
      decimals: 0,
      type: 'Fixed',
      description: 'Service fee. Pays for the cost of making transactions on behalf of the user',
      unit: 'Wei'
    }))
  })
})
