module.exports = {
  lint: {
    files: []
  }
}
