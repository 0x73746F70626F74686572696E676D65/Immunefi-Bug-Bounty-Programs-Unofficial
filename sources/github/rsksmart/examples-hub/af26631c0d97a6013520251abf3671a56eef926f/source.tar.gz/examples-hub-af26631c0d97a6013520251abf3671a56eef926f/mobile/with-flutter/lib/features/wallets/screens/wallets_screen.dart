import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:para/para.dart';
import '../../../client/para.dart';
import '../widgets/wallet_card.dart';
import 'details/evm_wallet_view.dart';
import 'details/solana_wallet_view.dart';
import 'details/cosmos_wallet_view.dart';

class WalletsScreen extends StatefulWidget {
  final VoidCallback onLogout;
  final VoidCallback onDeleteAccount;

  const WalletsScreen({
    super.key,
    required this.onLogout,
    required this.onDeleteAccount,
  });

  @override
  State<WalletsScreen> createState() => _WalletsScreenState();
}

class _WalletsScreenState extends State<WalletsScreen> {
  List<Wallet> _wallets = [];
  bool _isLoading = true;
  bool _isRefreshing = false;
  WalletType? _creatingWalletType;
  bool _isDeletingAccount = false;
  String? _error;
  bool _isFetchingJwt = false;

  @override
  void initState() {
    super.initState();
    _loadWallets();
  }

  Future<void> _loadWallets() async {
    try {
      final wallets = await para.fetchWallets();
      if (mounted) {
        setState(() {
          _wallets = wallets;
          _isLoading = false;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _error = e.toString();
        });
      }
    }
  }

  Future<void> _refreshWallets() async {
    if (_isRefreshing) return;

    setState(() => _isRefreshing = true);

    try {
      final wallets = await para.fetchWallets();
      if (mounted) {
        setState(() {
          _wallets = wallets;
          _isRefreshing = false;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isRefreshing = false;
          _error = e.toString();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Refresh failed: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> _createWallet(WalletType type, StateSetter setModalState) async {
    setState(() => _creatingWalletType = type);
    setModalState(() => _creatingWalletType = type);

    try {
      await para.createWallet(type: type, skipDistribute: false);
      await _loadWallets();
      if (mounted) {
        setState(() => _creatingWalletType = null);
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _creatingWalletType = null);
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Create wallet failed: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> _handleDeleteAccount() async {
    if (_isDeletingAccount) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Account?'),
        content: const Text(
          'This will permanently remove your Para account and all wallets. This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true) {
      return;
    }

    setState(() => _isDeletingAccount = true);
    try {
      await para.deleteAccount();
      if (!mounted) {
        return;
      }
      widget.onDeleteAccount();
    } catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isDeletingAccount = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Delete account failed: ${e.toString()}')),
      );
    }
  }

  Future<void> _showJwtDemo() async {
    setState(() => _isFetchingJwt = true);

    try {
      final response = await para.issueJwt();
      if (!mounted) return;
      setState(() => _isFetchingJwt = false);

      // Decode the JWT payload for display
      final parts = response.token.split('.');
      String? decodedPayload;
      if (parts.length == 3) {
        try {
          // Add padding if needed for base64 decoding
          var payload = parts[1];
          final remainder = payload.length % 4;
          if (remainder > 0) {
            payload += '=' * (4 - remainder);
          }
          final bytes = base64Url.decode(payload);
          final json = utf8.decode(bytes);
          // Pretty print the JSON
          final parsed = jsonDecode(json);
          const encoder = JsonEncoder.withIndent('  ');
          decodedPayload = encoder.convert(parsed);
        } catch (_) {
          decodedPayload = 'Unable to decode payload';
        }
      }

      if (!mounted) return;
      showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        builder: (context) => SafeArea(
          child: Container(
            padding: const EdgeInsets.all(16),
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.7,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'JWT Demo',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
                const Divider(),
                const Text(
                  'Key ID',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  response.keyId,
                  style: const TextStyle(
                    fontSize: 12,
                    fontFamily: 'monospace',
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Token (truncated)',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${response.token.substring(0, 50)}...',
                  style: const TextStyle(
                    fontSize: 12,
                    fontFamily: 'monospace',
                    color: Colors.black87,
                  ),
                ),
                if (decodedPayload != null) ...[
                  const SizedBox(height: 16),
                  const Text(
                    'Decoded Payload',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Flexible(
                    child: SingleChildScrollView(
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          decodedPayload,
                          style: const TextStyle(
                            fontSize: 11,
                            fontFamily: 'monospace',
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline, size: 16, color: Colors.blue),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Verify this JWT server-side using Para\'s JWKS endpoint.',
                          style: TextStyle(fontSize: 12, color: Colors.blue),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isFetchingJwt = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch JWT: ${e.toString()}')),
      );
    }
  }

  void _showCreateWalletSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => SafeArea(
          child: Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Select Wallet Type',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 24),
                ...WalletType.values.map((type) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: _creatingWalletType != null
                              ? null
                              : () => _createWallet(type, setModalState),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: _creatingWalletType == type
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.white),
                                  ),
                                )
                              : Text(
                                  type.value,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                        ),
                      ),
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _navigateToWalletDetail(Wallet wallet) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) {
          switch (wallet.type) {
            case WalletType.evm:
              return EVMWalletView(wallet: wallet);
            case WalletType.solana:
              return SolanaWalletView(wallet: wallet);
            case WalletType.cosmos:
              return CosmosWalletView(wallet: wallet);
            default:
              return Scaffold(
                appBar: AppBar(title: const Text('Unknown Wallet')),
                body: const Center(child: Text('Unknown wallet type')),
              );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: const Key('wallets_screen'),
      backgroundColor: const Color(0xFFFBF9F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFBF9F7),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            _isRefreshing ? Icons.hourglass_empty : Icons.refresh,
            color: Colors.black,
          ),
          onPressed: _isRefreshing ? null : _refreshWallets,
        ),
        title: const Text(
          'Wallets',
          key: ValueKey('wallets_screen_title'),
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            icon: _isFetchingJwt
                ? const SizedBox(
                    height: 16,
                    width: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.key, color: Colors.black),
            onPressed: _isFetchingJwt ? null : _showJwtDemo,
            tooltip: 'JWT Demo',
          ),
          TextButton(
            key: const ValueKey('wallets_screen_logout_button'),
            onPressed: _isDeletingAccount ? null : widget.onLogout,
            child: const Text(
              'Logout',
              style: TextStyle(color: Colors.black),
            ),
          ),
          TextButton(
            key: const ValueKey('wallets_screen_delete_account_button'),
            onPressed: _isDeletingAccount ? null : _handleDeleteAccount,
            child: _isDeletingAccount
                ? const SizedBox(
                    height: 16,
                    width: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                : const Text(
                    'Delete',
                    style: TextStyle(color: Colors.red),
                  ),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 48,
                        color: Colors.red,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Error loading wallets',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[800],
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: _loadWallets,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _refreshWallets,
                  child: _wallets.isEmpty
                      ? ListView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 48),
                          children: [
                            Center(
                              child: GestureDetector(
                                onTap: _showCreateWalletSheet,
                                child: Container(
                                  width: 250,
                                  height: 200,
                                  padding: const EdgeInsets.all(40),
                                  decoration: BoxDecoration(
                                    color: Colors.blue
                                        .withAlpha((255 * 0.1).round()),
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.add_circle,
                                        size: 60,
                                        color: Colors.blue[600],
                                      ),
                                      const SizedBox(height: 16),
                                      const Text(
                                        'Create Your First Wallet',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _wallets.length + 1,
                          itemBuilder: (context, index) {
                            if (index == _wallets.length) {
                              return AddWalletCard(
                                onTap: _showCreateWalletSheet,
                              );
                            }

                            final wallet = _wallets[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: WalletCard(
                                wallet: wallet,
                                onTap: () => _navigateToWalletDetail(wallet),
                              ),
                            );
                          },
                        ),
                ),
    );
  }
}
