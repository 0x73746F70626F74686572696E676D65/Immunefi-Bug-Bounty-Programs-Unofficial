---
rskip: 553
title: "Network Upgrade: Vetiver"
created: 23-MAR-26
author: AE
purpose: Usa, Sca, Sec
layer: Core
complexity: 2
status: Adopted
---

# Network Upgrade: Vetiver

## Abstract
This RSKIP outlines the consensus changes proposed for inclusion in Rootstock’s upcoming network upgrade, codenamed Vetiver. Some of the proposed RSKIPs, if ultimately approved, are intended to activate initially only on the Rootstock Testnet as part of an incremental rollout strategy. This approach allows them to be validated in a less critical environment before deployment on Mainnet. These RSKIPs are marked below as (Testnet only). Additionally, some RSKIPs that were already activated on Testnet in previous network upgrades are now being proposed for activation on Mainnet. These RSKIPs are marked below as (Mainnet only).
## Specification

- Codename: Vetiver
- Block activations for Vetiver 9.0.0:
	- Rootstock Mainnet block: 8,804,200
	- Rootstock Testnet block: 7,604,200

### Included RSKIPs

- [RSKIP-535](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP535.md): (Testnet-only) Add the baseEvent field to the Block header extension
- [RSKIP-536](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP536.md): (Mainnet-only) Additional methods for the BlockHeader precompiled contract
- [RSKIP-540](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP540.md): Bridge method `getEstimatedFeesForNextPegOutEvent` improvements and new parameterized method
- [RSKIP-544](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP544.md): Reject new contract code starting with the `0xEF` byte
- [RSKIP-551](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP551.md): Deprecate RSKIP-459
- [RSKIP-552](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP552.md): Improve Blake2F input validation

### Accepted RSKIPs

- [RSKIP-535](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP535.md): (Testnet-only) Add the baseEvent field to the Block header extension
- [RSKIP-536](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP536.md): (Mainnet-only) Additional methods for the BlockHeader precompiled contract
- [RSKIP-540](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP540.md): Bridge method `getEstimatedFeesForNextPegOutEvent` improvements and new parameterized method
- [RSKIP-544](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP544.md): Reject new contract code starting with the `0xEF` byte
- [RSKIP-551](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP551.md): Deprecate RSKIP-459
- [RSKIP-552](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP552.md): Improve Blake2F input validation

### Rejected RSKIPs

No rejected RSKIPs

### Proposed RSKIPs

- [RSKIP-535](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP535.md): (Testnet-only) Add the baseEvent field to the Block header extension
- [RSKIP-536](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP536.md): (Mainnet-only) Additional methods for the BlockHeader precompiled contract
- [RSKIP-540](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP540.md): Bridge method `getEstimatedFeesForNextPegOutEvent` improvements and new parameterized method
- [RSKIP-544](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP544.md): Reject new contract code starting with the `0xEF` byte
- [RSKIP-551](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP551.md): Deprecate RSKIP-459
- [RSKIP-552](https://github.com/rsksmart/RSKIPs/blob/master/IPs/RSKIP552.md): Improve Blake2F input validation

## Timeline

- MAR-23-26: RSKIP created with an initial list of proposed RSKIPs
- APR-06-26: Update to reflect RSKIPs included in Vetiver
- APR-06-26: Activation heights for Mainnet and Testnet defined

## References

## Copyright

Copyright and related rights waived via [CC0](https://creativecommons.org/publicdomain/zero/1.0/).


