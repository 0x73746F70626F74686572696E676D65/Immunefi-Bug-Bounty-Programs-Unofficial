#pragma once

#include "appflags.h"
#include "decorators.h"
#include "lcx_ecfp.h"
#include "os_types.h"

/* ----------------------------------------------------------------------- */
/* -                             SEED FEATURE                            - */
/* ----------------------------------------------------------------------- */

#define BOLOS_UX_ONBOARDING_ALGORITHM_BIP39 1
#define BOLOS_UX_ONBOARDING_ALGORITHM_ELECTRUM 2
#if defined(HAVE_VAULT_RECOVERY_ALGO)
#define BOLOS_UX_ONBOARDING_ALGORITHM_BIP39_VAULT_REC_MSK 3
#endif // HAVE_VAULT_RECOVERY_ALGO

/**
 * Set the persisted seed if none yet, else override the volatile seed (in RAM)
 */
SYSCALL PERMISSION(APPLICATION_FLAG_BOLOS_UX) void os_perso_set_seed(
    unsigned int identity, unsigned int algorithm,
    unsigned char *seed PLENGTH(length), unsigned int length);

SYSCALL PERMISSION(APPLICATION_FLAG_BOLOS_UX) void os_perso_derive_and_set_seed(
    unsigned char identity, const char *prefix PLENGTH(prefix_length),
    unsigned int prefix_length,
    const char *passphrase PLENGTH(passphrase_length),
    unsigned int passphrase_length, const char *words PLENGTH(words_length),
    unsigned int words_length);

#if defined(HAVE_VAULT_RECOVERY_ALGO)
SYSCALL
    PERMISSION(APPLICATION_FLAG_BOLOS_UX) void os_perso_derive_and_prepare_seed(
        const char *words, unsigned int words_length);
SYSCALL PERMISSION(APPLICATION_FLAG_BOLOS_UX) void os_perso_derive_and_xor_seed(
    void);
SYSCALL PERMISSION(
    APPLICATION_FLAG_BOLOS_UX) unsigned char os_perso_get_seed_algorithm(void);
#endif // HAVE_VAULT_RECOVERY_ALGO

SYSCALL PERMISSION(APPLICATION_FLAG_BOLOS_UX) void os_perso_set_words(
    const unsigned char *words PLENGTH(length), unsigned int length);
SYSCALL PERMISSION(APPLICATION_FLAG_BOLOS_UX) void os_perso_finalize(void);

// checked in the ux flow to avoid asking the pin for example
// NBA : could also be checked by applications running in unsecure mode - thus
// unprivilegied
// @return BOLOS_UX_OK when perso is onboarded.
SYSCALL bolos_bool_t os_perso_isonboarded(void);

SYSCALL void os_perso_set_onboarding_status(unsigned int kind,
                                            unsigned int count,
                                            unsigned int maxCount,
                                            unsigned int isConfirming);

// derive the seed for the requested BIP32 path
SYSCALL void os_perso_derive_node_bip32(
    cx_curve_t curve,
    const unsigned int *path PLENGTH(4 * (pathLength & 0x0FFFFFFFu)),
    unsigned int pathLength, unsigned char *privateKey PLENGTH(64),
    unsigned char *chain PLENGTH(32));

#define HDW_NORMAL 0
#define HDW_ED25519_SLIP10 1
// symmetric key derivation according to SLIP-0021
// this only supports derivation of the master node (level 1)
// the beginning of the authorized path is to be provided in the authorized
// derivation tag of the registry starting with a \x00 Note: for SLIP21, the
// path is a string and the pathLength is the number of chars including the
// starting \0 byte. However, firewall checks are processing a number of
// integers, therefore, take care not to locate the buffer too far in memory to
// pass the firewall check.
#define HDW_SLIP21 2
// derive the seed for the requested BIP32 path, with the custom provided
// seed_key for the sha512 hmac ("Bitcoin Seed", "Nist256p1 Seed", "ed25519
// seed", ...)
SYSCALL void os_perso_derive_node_with_seed_key(
    unsigned int mode, cx_curve_t curve,
    const unsigned int *path PLENGTH(4 * (pathLength & 0x0FFFFFFFu)),
    unsigned int pathLength, unsigned char *privateKey PLENGTH(64),
    unsigned char *chain PLENGTH(32),
    unsigned char *seed_key PLENGTH(seed_key_length),
    unsigned int seed_key_length);
#define os_perso_derive_node_bip32_seed_key(mode, curve, path, pathLength,     \
                                            privateKey, chain, seed_key,       \
                                            seed_key_length)                   \
  os_perso_derive_node_with_seed_key(mode, curve, path, pathLength,            \
                                     privateKey, chain, seed_key,              \
                                     seed_key_length)

/**
 * @brief   Gets the private key from the device seed using the specified bip32 path and seed key.
 *
 * @param[in]  derivation_mode Derivation mode, one of HDW_NORMAL / HDW_ED25519_SLIP10 / HDW_SLIP21.
 *
 * @param[in]  curve           Curve identifier.
 *
 * @param[in]  path            Bip32 path to use for derivation.
 *
 * @param[in]  path_len        Bip32 path length.
 *
 * @param[out] raw_privkey     Buffer where to store the private key.
 *
 * @param[out] chain_code      Buffer where to store the chain code. Can be NULL.
 *
 * @param[in]  seed            Seed key to use for derivation.
 *
 * @param[in]  seed_len        Seed key length.
 *
 * @return                     Error code:
 *                             - CX_OK on success
 *                             - CX_INTERNAL_ERROR
 */
static inline cx_err_t os_derive_bip32_with_seed_no_throw(unsigned int derivation_mode,
                                                          cx_curve_t curve,
                                                          const uint32_t *path,
                                                          size_t path_len,
                                                          uint8_t raw_privkey[static 64],
                                                          uint8_t *chain_code,
                                                          unsigned char *seed,
                                                          size_t seed_len) {
    cx_err_t error = CX_OK;

    BEGIN_TRY {
        TRY {
            // Derive the seed with path
            os_perso_derive_node_bip32_seed_key(derivation_mode,
                                                curve,
                                                path,
                                                path_len,
                                                raw_privkey,
                                                chain_code,
                                                seed,
                                                seed_len);
        }
        CATCH_OTHER(e) {
            error = e;
        }
        FINALLY {
        }
    }
    END_TRY;

    return error;
}

/**
 * @brief   Gets the private key from the device seed using the specified bip32 path.
 *
 * @param[in]  curve           Curve identifier.
 *
 * @param[in]  path            Bip32 path to use for derivation.
 *
 * @param[in]  path_len        Bip32 path length.
 *
 * @param[out] raw_privkey     Buffer where to store the private key.
 *
 * @param[out] chain_code      Buffer where to store the chain code. Can be NULL.
 *
 * @return                     Error code:
 *                             - CX_OK on success
 *                             - CX_INTERNAL_ERROR
 */
static inline cx_err_t os_derive_bip32_no_throw(cx_curve_t curve,
                                                const uint32_t *path,
                                                size_t path_len,
                                                uint8_t raw_privkey[static 64],
                                                uint8_t *chain_code) {
    return os_derive_bip32_with_seed_no_throw(HDW_NORMAL,
                                              curve,
                                              path,
                                              path_len,
                                              raw_privkey,
                                              chain_code,
                                              NULL,
                                              0);
}

SYSCALL void os_perso_derive_eip2333(
    cx_curve_t curve,
    const unsigned int *path PLENGTH(4 * (pathLength & 0x0FFFFFFFu)),
    unsigned int pathLength, unsigned char *privateKey PLENGTH(32));

/**
 * @brief   Gets the private key from the device seed using the specified eip2333 path.
 *
 * @param[in]  curve           Curve identifier.
 *
 * @param[in]  path            Eip2333 path to use for derivation.
 *
 * @param[in]  path_len        Eip2333 path length.
 *
 * @param[out] raw_privkey     Buffer where to store the private key.
 *
 * @return                     Error code:
 *                             - CX_OK on success
 *                             - CX_INTERNAL_ERROR
 */
static inline cx_err_t os_derive_eip2333_no_throw(cx_curve_t curve,
                                                  const uint32_t *path,
                                                  size_t path_len,
                                                  uint8_t raw_privkey[static 64]) {
    cx_err_t error = CX_OK;

    BEGIN_TRY {
        TRY {
            // Derive the seed with path
            os_perso_derive_eip2333(curve, path, path_len, raw_privkey);
        }
        CATCH_OTHER(e) {
            error = e;
        }
        FINALLY {
        }
    }
    END_TRY;

    return error;
}

/**
 * Generate a seed based cookie
 * seed => derivation (path 0xda7aba5e/0xc1a551c5) => priv key =SECP256K1=>
 * pubkey => sha512 => cookie
 */

#if defined(HAVE_SEED_COOKIE)
SYSCALL unsigned int
os_perso_seed_cookie(unsigned char *seed_cookie PLENGTH(seed_cookie_length),
                     unsigned int seed_cookie_length);
#endif // HAVE_SEED_COOKIE
