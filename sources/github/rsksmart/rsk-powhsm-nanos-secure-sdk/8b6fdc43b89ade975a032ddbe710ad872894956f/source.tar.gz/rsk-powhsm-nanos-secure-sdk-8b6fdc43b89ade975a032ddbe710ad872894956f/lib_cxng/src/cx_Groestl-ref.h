#ifdef HAVE_GROESTL

#ifndef __groestl_ref_h
#define __groestl_ref_h

//#include <stdio.h>
//#include <stdlib.h>
#define NEED_UINT_64T

/* ****
#include "brg_types.h"
//Inline the file here:
*/

/*
 ---------------------------------------------------------------------------
 Copyright (c) 1998-2008, Brian Gladman, Worcester, UK. All rights reserved.

 (a few lines added by Soeren S. Thomsen, October 2008)

 LICENSE TERMS

 The redistribution and use of this software (with or without changes)
 is allowed without the payment of fees or royalties provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 in respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
 Issue Date: 20/12/2007

 The unsigned integer types defined here are of the form uint_<nn>t where
 <nn> is the length of the type; for example, the unsigned 32-bit type is
 'uint_32t'.  These are NOT the same as the 'C99 integer types' that are
 defined in the inttypes.h and stdint.h headers since attempts to use these
 types have shown that support for them is still highly variable.  However,
 since the latter are of the form uint<nn>_t, a regular expression search
 and replace (in VC++ search on 'uint_{:z}t' and replace with 'uint\1_t')
 can be used to convert the types used here to the C99 standard types.
*/

#ifndef _BRG_TYPES_H
#define _BRG_TYPES_H

#include <limits.h>

#if defined(_MSC_VER) && (_MSC_VER >= 1300)
#include <stddef.h>
#define ptrint_t intptr_t
#elif defined(__GNUC__) && (__GNUC__ >= 3)
#include <stdint.h>
#define ptrint_t intptr_t
#else
#define ptrint_t int
#endif

#ifndef BRG_UI8
#define BRG_UI8
#if UCHAR_MAX == 255u
typedef unsigned char uint_8t;
#else
#error Please define uint_8t as an 8-bit unsigned integer type in brg_types.h
#endif
#endif

#ifndef BRG_UI16
#define BRG_UI16
#if USHRT_MAX == 65535u
typedef unsigned short uint_16t;
#else
#error Please define uint_16t as a 16-bit unsigned short type in brg_types.h
#endif
#endif

#ifndef BRG_UI32
#define BRG_UI32
#if UINT_MAX == 4294967295u
#define li_32(h) 0x##h##u
typedef unsigned int uint_32t;
#elif ULONG_MAX == 4294967295u
#define li_32(h) 0x##h##ul
typedef unsigned long    uint_32t;
#elif defined(_CRAY)
#error This code needs 32-bit data types, which Cray machines do not provide
#else
#error Please define uint_32t as a 32-bit unsigned integer type in brg_types.h
#endif
#endif

#ifndef BRG_UI64
#if defined(__BORLANDC__) && !defined(__MSDOS__)
#define BRG_UI64
#define li_64(h) 0x##h##ui64
typedef unsigned __int64 uint_64t;
#elif defined(_MSC_VER) && (_MSC_VER < 1300) /* 1300 == VC++ 7.0 */
#define BRG_UI64
#define li_64(h) 0x##h##ui64
typedef unsigned __int64 uint_64t;
#elif defined(__sun) && defined(ULONG_MAX) && ULONG_MAX == 0xfffffffful
#define BRG_UI64
#define li_64(h) 0x##h##ull
typedef unsigned long long uint_64t;
#elif defined(__MVS__)
#define BRG_UI64
#define li_64(h) 0x##h##ull
typedef unsigned int long long uint_64t;
#elif defined(UINT_MAX) && UINT_MAX > 4294967295u
#if UINT_MAX == 18446744073709551615u
#define BRG_UI64
#define li_64(h) 0x##h##u
typedef unsigned int uint_64t;
#endif
#elif defined(ULONG_MAX) && ULONG_MAX > 4294967295u
#if ULONG_MAX == 18446744073709551615ul
#define BRG_UI64
#define li_64(h) 0x##h##ul
typedef unsigned long uint_64t;
#endif
#elif defined(ULLONG_MAX) && ULLONG_MAX > 4294967295u
#if ULLONG_MAX == 18446744073709551615ull
#define BRG_UI64
#define li_64(h) 0x##h##ull
typedef unsigned long long uint_64t;
#endif
#elif defined(ULONG_LONG_MAX) && ULONG_LONG_MAX > 4294967295u
#if ULONG_LONG_MAX == 18446744073709551615ull
#define BRG_UI64
#define li_64(h) 0x##h##ull
typedef unsigned long long uint_64t;
#endif
#endif
#endif

#if !defined(BRG_UI64)
#if defined(NEED_UINT_64T)
#error Please define uint_64t as an unsigned 64 bit type in brg_types.h
#endif
#endif

#ifndef RETURN_VALUES
#define RETURN_VALUES
#if defined(DLL_EXPORT)
#if defined(_MSC_VER) || defined(__INTEL_COMPILER)
#define VOID_RETURN __declspec(dllexport) void __stdcall
#define INT_RETURN __declspec(dllexport) int __stdcall
#elif defined(__GNUC__)
#define VOID_RETURN __declspec(__dllexport__) void
#define INT_RETURN __declspec(__dllexport__) int
#else
#error Use of the DLL is only available on the Microsoft, Intel and GCC compilers
#endif
#elif defined(DLL_IMPORT)
#if defined(_MSC_VER) || defined(__INTEL_COMPILER)
#define VOID_RETURN __declspec(dllimport) void __stdcall
#define INT_RETURN __declspec(dllimport) int __stdcall
#elif defined(__GNUC__)
#define VOID_RETURN __declspec(__dllimport__) void
#define INT_RETURN __declspec(__dllimport__) int
#else
#error Use of the DLL is only available on the Microsoft, Intel and GCC compilers
#endif
#elif defined(__WATCOMC__)
#define VOID_RETURN void __cdecl
#define INT_RETURN int __cdecl
#else
#define VOID_RETURN void
#define INT_RETURN int
#endif
#endif

/*  These defines are used to detect and set the memory alignment of pointers.
    Note that offsets are in bytes.

    ALIGN_OFFSET(x,n)           return the positive or zero offset of
                                the memory addressed by the pointer 'x'
                                from an address that is aligned on an
                                'n' byte boundary ('n' is a power of 2)

    ALIGN_FLOOR(x,n)            return a pointer that points to memory
                                that is aligned on an 'n' byte boundary
                                and is not higher than the memory address
                                pointed to by 'x' ('n' is a power of 2)

    ALIGN_CEIL(x,n)             return a pointer that points to memory
                                that is aligned on an 'n' byte boundary
                                and is not lower than the memory address
                                pointed to by 'x' ('n' is a power of 2)
*/

#define ALIGN_OFFSET(x, n) (((ptrint_t)(x)) & ((n)-1))
#define ALIGN_FLOOR(x, n) ((uint_8t *)(x) - (((ptrint_t)(x)) & ((n)-1)))
#define ALIGN_CEIL(x, n) ((uint_8t *)(x) + (-((ptrint_t)(x)) & ((n)-1)))

/*  These defines are used to declare buffers in a way that allows
    faster operations on longer variables to be used.  In all these
    defines 'size' must be a power of 2 and >= 8. NOTE that the
    buffer size is in bytes but the type length is in bits

    UNIT_TYPEDEF(x,size)        declares a variable 'x' of length
                                'size' bits

    BUFR_TYPEDEF(x,size,bsize)  declares a buffer 'x' of length 'bsize'
                                bytes defined as an array of variables
                                each of 'size' bits (bsize must be a
                                multiple of size / 8)

    UNIT_CAST(x,size)           casts a variable to a type of
                                length 'size' bits

    UPTR_CAST(x,size)           casts a pointer to a pointer to a
                                varaiable of length 'size' bits
*/

#define UI_TYPE(size) uint_##size##t
#define UNIT_TYPEDEF(x, size) typedef UI_TYPE(size) x
#define BUFR_TYPEDEF(x, size, bsize) typedef UI_TYPE(size) x[bsize / (size >> 3)]
#define UNIT_CAST(x, size) ((UI_TYPE(size))(x))
#define UPTR_CAST(x, size) ((UI_TYPE(size) *)(x))

/* Added by Soeren S. Thomsen (begin) */
#define u8 uint_8t
#define u32 uint_32t
#define u64 uint_64t
/* (end) */

#endif

/*
//End of inline
**** */

#define ROWS 8
#define LENGTHFIELDLEN ROWS
#define COLS512 8
#define COLS1024 16
#define SIZE512 (ROWS * COLS512)
// #define SIZE1024 (ROWS*COLS1024)
#define ROUNDS512 10
#define ROUNDS1024 14

typedef enum { P512 = 0, Q512 = 1, P1024 = 2, Q1024 = 3 } Variant;

#define mul1(b) ((u8)(b))
#define mul2(b) ((u8)((b) >> 7 ? ((b) << 1) ^ 0x1b : ((b) << 1)))
#define mul3(b) (mul2(b) ^ mul1(b))
#define mul4(b) mul2(mul2(b))
#define mul5(b) (mul4(b) ^ mul1(b))
#define mul6(b) (mul4(b) ^ mul2(b))
#define mul7(b) (mul4(b) ^ mul2(b) ^ mul1(b))

/* NIST API begin */
typedef unsigned long long DataLength;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHLEN = 2 } HashReturn;
/* NIST API end */

/* helper functions */
void PrintHash(BitSequence *, int);

#endif /* __groestl_ref_h */

#endif // HAVE_GROESTL
