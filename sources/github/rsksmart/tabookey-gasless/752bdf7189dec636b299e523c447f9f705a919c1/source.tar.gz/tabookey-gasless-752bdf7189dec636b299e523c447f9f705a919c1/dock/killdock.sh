docker rm -f relaydock
