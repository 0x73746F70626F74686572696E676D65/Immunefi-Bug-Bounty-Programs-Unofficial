import React from "react";

function ArrowRight() {
  return (
    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_7984_759)">
        <path
          d="M11.8125 3.9375L10.8741 4.85166L15.8484 9.84375H2.625V11.1562H15.8484L10.8741 16.126L11.8125 17.0625L18.375 10.5L11.8125 3.9375Z"
          fill="white"
        />
      </g>
      <defs>
        <clipPath id="clip0_7984_759">
          <rect width="21" height="21" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}

export default ArrowRight;
