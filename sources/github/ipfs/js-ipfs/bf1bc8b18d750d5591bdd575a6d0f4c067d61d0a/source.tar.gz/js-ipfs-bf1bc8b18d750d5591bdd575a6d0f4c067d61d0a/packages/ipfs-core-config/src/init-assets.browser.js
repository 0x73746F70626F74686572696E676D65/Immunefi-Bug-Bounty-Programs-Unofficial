
export function initAssets () {}
