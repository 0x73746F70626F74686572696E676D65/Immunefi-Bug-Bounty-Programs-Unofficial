export default `Index
`
