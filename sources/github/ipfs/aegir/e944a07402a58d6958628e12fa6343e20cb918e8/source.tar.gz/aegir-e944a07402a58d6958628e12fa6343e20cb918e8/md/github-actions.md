Create a new file called `js-test-and-release.yml` inside `.github/workflows` with the following content:

```yml
name: test & maybe release

on:
  push:
    branches:
      - main
  pull_request:
  workflow_dispatch:

permissions:
  contents: write
  id-token: write
  packages: write
  pull-requests: write

concurrency:
  group: ${{ github.workflow }}-${{ github.event_name }}-${{ github.event_name == 'push' && github.sha || github.ref }}
  cancel-in-progress: true

jobs:
  js-test-and-release:
    uses: ipdxco/unified-github-workflows/.github/workflows/js-test-and-release.yml@v1.0
    secrets:
      DOCKER_TOKEN: ${{ secrets.DOCKER_TOKEN }}
      DOCKER_USERNAME: ${{ secrets.DOCKER_USERNAME }}
      NPM_TOKEN: ${{ secrets.NPM_TOKEN }}
      UCI_GITHUB_TOKEN: ${{ secrets.UCI_GITHUB_TOKEN }}
      CODECOV_TOKEN: ${{ secrets.CODECOV_TOKEN }}
```