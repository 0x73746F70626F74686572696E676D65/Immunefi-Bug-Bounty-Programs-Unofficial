```typescript
still.bad.code
```