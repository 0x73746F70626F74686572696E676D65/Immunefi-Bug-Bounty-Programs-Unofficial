```typescript
   wrong.code()
```