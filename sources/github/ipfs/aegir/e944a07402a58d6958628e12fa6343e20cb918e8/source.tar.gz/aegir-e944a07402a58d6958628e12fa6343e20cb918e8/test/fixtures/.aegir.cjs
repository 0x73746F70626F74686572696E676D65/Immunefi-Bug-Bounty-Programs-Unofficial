
module.exports = {
  config: 'mine'
}
