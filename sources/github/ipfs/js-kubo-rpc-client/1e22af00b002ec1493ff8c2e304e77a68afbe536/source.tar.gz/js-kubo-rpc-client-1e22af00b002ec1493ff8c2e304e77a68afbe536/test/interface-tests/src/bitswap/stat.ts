import { expect } from 'aegir/chai'
import { expectIsBitswap } from '../stats/utils.ts'
import { getDescribe, getIt } from '../utils/mocha.ts'
import type { KuboRPCClient } from '../../../../src/index.ts'
import type { MochaConfig } from '../utils/mocha.ts'
import type { Factory, KuboNode } from 'ipfsd-ctl'

export function testStat (factory: Factory<KuboNode>, options: MochaConfig): void {
  const describe = getDescribe(options)
  const it = getIt(options)

  describe('.bitswap.stat', function () {
    this.timeout(60 * 1000)

    let ipfs: KuboRPCClient

    before(async function () {
      ipfs = (await factory.spawn()).api
    })

    after(async function () {
      await factory.clean()
    })

    it('should get bitswap stats', async () => {
      const res = await ipfs.bitswap.stat()
      expectIsBitswap(null, res)
    })

    it('should not get bitswap stats when offline', async () => {
      const node = await factory.spawn()
      await node.stop()

      return expect(node.api.bitswap.stat()).to.eventually.be.rejected()
    })
  })
}
