// @ts-check
const { screen, BrowserWindow, ipcMain, app, session } = require('electron')
const { join } = require('path')
const { URL } = require('url')
const serve = require('electron-serve')
const i18n = require('i18next')
const openExternal = require('./open-external')
const logger = require('../common/logger')
const store = require('../common/store')
const { OPEN_WEBUI_LAUNCH: CONFIG_KEY } = require('../common/config-keys')
const dock = require('../utils/dock')
const { VERSION, ELECTRON_VERSION } = require('../common/consts')
const createToggler = require('../utils/create-toggler')
const { showDialog } = require('../dialogs')
const { getSecondsSinceAppStart } = require('../metrics/appStart')
const { performance } = require('perf_hooks')
const Countly = require('countly-sdk-nodejs')
const { analyticsKeys } = require('../analytics/keys')
const ipcMainEvents = require('../common/ipc-main-events')
const getCtx = require('../context')
const { STATUS } = require('../daemon/consts')
const WEBUI_ORIGIN = 'webui://localhost'

serve({ scheme: 'webui', directory: join(__dirname, '../../assets/webui') })

/**
 *
 * @returns {BrowserWindow}
 */
const createWindow = () => {
  logger.info('[webui] creating window')
  const dimensions = screen.getPrimaryDisplay()

  const window = new BrowserWindow({
    title: 'IPFS Desktop',
    show: false,
    autoHideMenuBar: true,
    titleBarStyle: 'hiddenInset',
    width: store.get('window.width', dimensions.width < 1440 ? dimensions.width : 1440),
    height: store.get('window.height', dimensions.height < 900 ? dimensions.height : 900),
    webPreferences: {
      preload: join(__dirname, 'preload.js'),
      webSecurity: false,
      allowRunningInsecureContent: false,
      enableRemoteModule: process.env.NODE_ENV === 'test', // https://github.com/electron-userland/spectron/pull/738#issuecomment-754810364
      nodeIntegration: process.env.NODE_ENV === 'test'
    }
  })

  window.webContents.once('did-start-loading', (event) => {
    const msg = '[web ui] loading'
    const webContentLoad = logger.start(msg, { withAnalytics: analyticsKeys.WEB_UI_READY })
    window.webContents.once('did-finish-load', () => {
      webContentLoad.end()
    })
    window.webContents.once('did-fail-load', (_, errorCode, errorDescription) => {
      // -3 is ERR_ABORTED and can happen when a navigation gets superseded.
      if (errorCode === -3) {
        logger.debug(`[web ui] loading aborted (code: ${errorCode})`)
        return
      }
      const desc = errorDescription || 'unknown error'
      webContentLoad.fail(new Error(`${msg}: ${desc}, code: ${errorCode}`))
    })
  })
  window.webContents.once('dom-ready', async (event) => {
    const endTime = performance.now()
    try {
      const dur = getSecondsSinceAppStart(endTime)
      logger.info(`[App] startup time - ${dur} seconds`)
      Countly.add_event({
        key: 'APP_START_TO_DOM_READY',
        count: 1,
        dur
      })
    } catch (err) {
      logger.error(err)
    }
  })

  // open devtools with: DEBUG=ipfs-desktop
  if (process.env.DEBUG && process.env.DEBUG.match(/ipfs-desktop/)) {
    window.webContents.openDevTools()
  }

  window.webContents.on('render-process-gone', (_, { reason, exitCode }) => {
    logger.error(`[web ui] render-process-gone: ${reason}, code: ${exitCode}`)
  })

  window.webContents.on('unresponsive', async () => {
    logger.error('[web ui] the webui became unresponsive')

    const opt = showDialog({
      title: i18n.t('unresponsiveWindowDialog.title'),
      message: i18n.t('unresponsiveWindowDialog.message'),
      buttons: [
        i18n.t('unresponsiveWindowDialog.forceReload'),
        i18n.t('unresponsiveWindowDialog.doNothing')
      ]
    })

    if (opt === 0) {
      window.webContents.forcefullyCrashRenderer()
      window.webContents.reload()
    }
  })

  window.on('resize', () => {
    const dim = window.getSize()
    store.safeSet('window.width', dim[0])
    store.safeSet('window.height', dim[1])
  })

  // Visibility tracking drives the renderer's `#/blank` route, which unmounts
  // the entire ipfs-webui app while the window is not visible, so we avoid
  // re-rendering the bandwidth graph on Status and the peer list on Peers
  // when the user cannot see them. We forward visibility from the main
  // process (deterministic on programmatic show/hide, which the renderer's
  // `visibilitychange` does not always observe in time) and the renderer
  // additionally listens to `document.visibilitychange` to cover OS-driven
  // cases the main process never sees: occlusion by another window, macOS
  // app-hide (Cmd+H) and Mission Control / Spaces.
  let hasShownWindow = false
  let lastVisibilityState = null
  const sendVisibilityChange = (isVisible) => {
    if (window.isDestroyed()) return
    if (!isVisible && !hasShownWindow) return
    if (lastVisibilityState === isVisible) return
    lastVisibilityState = isVisible
    if (isVisible) hasShownWindow = true
    window.webContents.send(ipcMainEvents.WEBUI_VISIBILITY_CHANGED, isVisible)
  }

  window.webContents.on('did-finish-load', () => {
    sendVisibilityChange(window.isVisible())
  })

  window.on('show', () => {
    sendVisibilityChange(true)
    try {
      window.webContents.focus()
    } catch (err) {
      logger.debug(`[web ui] unable to focus webContents: ${err}`)
    }
  })

  window.on('hide', () => {
    sendVisibilityChange(false)
  })

  // Electron emits `minimize`/`restore` (not `hide`/`show`) when the user
  // minimizes the window, so wire them up explicitly to keep the WebUI
  // blanked while minimized.
  window.on('minimize', () => {
    sendVisibilityChange(false)
  })

  window.on('restore', () => {
    sendVisibilityChange(true)
  })

  window.on('close', (event) => {
    event.preventDefault()
    window.hide()
    dock.hide()
    logger.info('[web ui] window hidden')
  })

  app.on('before-quit', () => {
    logger.info('[web ui] app-quit requested')
    // Makes sure the app quits even though we prevent
    // the closing of this window.
    window.removeAllListeners('close')
  })

  return window
}

module.exports = async function () {
  logger.info('[webui] init...')
  const ctx = getCtx()
  const isWebUiUrl = (value) => {
    try {
      return new URL(value).origin === WEBUI_ORIGIN
    } catch (_) {
      return false
    }
  }

  if (store.get(CONFIG_KEY, null) === null) {
    // First time running this. Enable opening ipfs-webui at app launch.
    // This accounts for users on OSes who may have extensions for
    // decluttering system menus/trays, and thus have no initial "way in" to
    // Desktop upon install:
    // https://github.com/ipfs-shipyard/ipfs-desktop/issues/1741
    store.safeSet(CONFIG_KEY, true)
  }

  createToggler(CONFIG_KEY, async ({ newValue }) => {
    store.safeSet(CONFIG_KEY, newValue)
    return true
  })

  openExternal()
  const window = createWindow()
  ctx.setProp('webui', window)
  let apiAddress = null

  const url = new URL('/', WEBUI_ORIGIN)
  url.hash = '/blank'
  url.searchParams.set('deviceId', await ctx.getProp('countlyDeviceId'))
  let lastLoadedUrl = null
  const getCurrentWebUiUrl = () => {
    try {
      const currentUrl = window.webContents.getURL()
      if (isWebUiUrl(currentUrl)) {
        return currentUrl
      }
    } catch (_) {}
    return null
  }

  const loadIfChanged = (nextUrl) => {
    const currentUrl = getCurrentWebUiUrl()
    // Prefer the live URL when available so stale cached state cannot
    // suppress a requested tray navigation.
    if (currentUrl) {
      if (currentUrl === nextUrl) {
        lastLoadedUrl = currentUrl
        return
      }
      lastLoadedUrl = currentUrl
    } else if (lastLoadedUrl === nextUrl) {
      return
    }
    lastLoadedUrl = nextUrl
    window.loadURL(nextUrl)
  }

  ctx.setProp('launchWebUI', async (path, { focus = true, forceRefresh = false } = {}) => {
    if (window.isDestroyed()) {
      logger.error(`[web ui] window is destroyed, not launching web ui with ${path}`)
      return
    }
    const shouldFocusBeforeNavigation = focus && Boolean(path) && !window.isVisible()
    if (shouldFocusBeforeNavigation) {
      window.show()
      window.focus()
      dock.show()
    }
    if (forceRefresh) window.webContents.reload()
    if (!path) {
      logger.info('[web ui] launching web ui', { withAnalytics: analyticsKeys.FN_LAUNCH_WEB_UI })
    } else {
      logger.info(`[web ui] navigate to ${path}`, { withAnalytics: analyticsKeys.FN_LAUNCH_WEB_UI_WITH_PATH })
      const nextPath = String(path)
      url.hash = nextPath
      let navigatedInPage = false

      if (window.isVisible()) {
        const expectedHash = nextPath.startsWith('#') ? nextPath : `#${nextPath}`
        try {
          navigatedInPage = await window.webContents.executeJavaScript(`
            (() => {
              const expectedHash = ${JSON.stringify(expectedHash)}
              if (window.location.hash !== expectedHash) {
                window.location.hash = ${JSON.stringify(nextPath)}
              }
              return window.location.hash === expectedHash
            })()
          `, true)
        } catch (_) {}
      }

      if (!navigatedInPage) {
        loadIfChanged(url.toString())
      }
    }
    if (focus && !shouldFocusBeforeNavigation) {
      window.show()
      window.focus()
      dock.show()
    }
  })

  function updateLanguage () {
    url.searchParams.set('lng', store.get('language'))
  }

  const getIpfsd = ctx.getFn('getIpfsd')
  const openWebUiAtLaunch = Boolean(store.get(CONFIG_KEY))
  let startupRoutePending = openWebUiAtLaunch
  let ipfsdStatus = null
  ipcMain.on(ipcMainEvents.IPFSD, async (status) => {
    const ipfsd = await getIpfsd(true)
    ipfsdStatus = status

    if (ipfsd && ipfsd.apiAddr !== apiAddress) {
      try {
        const currentUrl = window.webContents.getURL()
        if (isWebUiUrl(currentUrl)) {
          url.hash = new URL(currentUrl).hash
        }
      } catch (err) {
        logger.warn('[web ui] unable to preserve current hash on reload', err)
      }

      // During startup with auto-open enabled, prefer loading the status
      // route directly once API is known to avoid ending up stuck on blank.
      if (startupRoutePending && (!url.hash || url.hash === '#/blank')) {
        url.hash = '/'
      }

      apiAddress = ipfsd.apiAddr
      url.searchParams.set('api', apiAddress.toString())
      updateLanguage()
      loadIfChanged(url.toString())
    }
  })

  // Set user agent
  session.defaultSession.webRequest.onBeforeSendHeaders((details, callback) => {
    details.requestHeaders['User-Agent'] = `ipfs-desktop/${VERSION} (Electron ${ELECTRON_VERSION})`
    callback({ cancel: false, requestHeaders: details.requestHeaders }) // eslint-disable-line
  })

  const launchWebUI = ctx.getFn('launchWebUI')
  // null when the splash window could not be created, so carry on without it.
  const splashScreen = await ctx.getProp('splashScreen')
  if (!splashScreen) {
    logger.info('[web ui] no splash screen to show')
  } else if (openWebUiAtLaunch) {
    // we're supposed to show the window on startup, display the splash screen
    splashScreen.show()
  } else {
    // we don't need the splash screen, ignore it.
    splashScreen.destroy()
  }
  let splashScreenTimeoutId = null
  window.on('close', () => {
    if (splashScreenTimeoutId) {
      clearTimeout(splashScreenTimeoutId)
      splashScreenTimeoutId = null
    }
  })
  const handleSplashScreen = async () => {
    if ([null, STATUS.STARTING_STARTED].includes(ipfsdStatus)) {
      splashScreenTimeoutId = setTimeout(handleSplashScreen, 500)
      return
    }

    try {
      await launchWebUI('/')
    } finally {
      startupRoutePending = false
    }
    try {
      splashScreen?.destroy()
    } catch (err) {
      logger.error('[web ui] failed to hide splash screen')
      logger.error(err)
    }
  }

  return /** @type {Promise<void>} */(new Promise(resolve => {
    if (openWebUiAtLaunch) {
      logger.info('[web ui] waiting for ipfsd to start')
      window.once('ready-to-show', async () => {
        logger.info('[web ui] window ready')

        handleSplashScreen()

        resolve()
      })
    }

    updateLanguage()
    loadIfChanged(url.toString())
  }))
}
