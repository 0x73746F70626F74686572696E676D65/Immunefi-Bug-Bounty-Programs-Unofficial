// @ts-check
const { app } = require('electron')
const i18n = require('i18next')
const os = require('os')
const path = require('path')
const fs = require('fs-extra')
const untildify = require('untildify')
const createToggler = require('./utils/create-toggler')
const logger = require('./common/logger')
const store = require('./common/store')
const { IS_MAC, IS_WIN } = require('./common/consts')
const { AUTO_LAUNCH: CONFIG_KEY } = require('./common/config-keys')
const { showDialog, recoverableErrorDialog } = require('./dialogs')

function isSupported () {
  const plat = os.platform()
  return plat === 'linux' || plat === 'win32' || plat === 'darwin'
}

function getDesktopFile () {
  return path.join(untildify('~/.config/autostart/'), 'ipfs-desktop.desktop')
}

// Quote and escape a value as an argument in a Desktop Entry Exec= field.
// The freedesktop.org spec requires arguments with reserved characters (space,
// $, backtick, etc.) to be wrapped in double quotes, and literal backslashes,
// double quotes, dollar signs, or backticks inside the quotes must each be
// preceded by a backslash. Always quoting handles paths with spaces such as
// /opt/My Apps/electron39.
function quoteDesktopEntryArg (value) {
  return `"${value.replace(/[\\`$"]/g, '\\$&')}"`
}

function getLinuxAutostartExec () {
  // Distro packages launch IPFS Desktop through a wrapper script and set
  // IPFS_DESKTOP_EXEC to its path, so autostart runs the wrapper instead of a
  // reconstructed electron command. The value is a single executable path, not
  // a command line: flags would be quoted into the path and break the entry.
  const launcher = process.env.IPFS_DESKTOP_EXEC
  if (launcher) return quoteDesktopEntryArg(launcher)

  const command = [process.execPath]

  // Some distro packages launch as `electron <app.asar>`.
  if (path.basename(process.execPath).startsWith('electron')) {
    const appPath = app.getAppPath()

    if (appPath && appPath !== process.execPath) {
      command.push(appPath)
    }
  }

  return command.map(quoteDesktopEntryArg).join(' ')
}

async function enable () {
  if (app.setLoginItemSettings && (IS_MAC || IS_WIN)) {
    app.setLoginItemSettings({ openAtLogin: true })
    return
  }

  const exec = getLinuxAutostartExec()
  const desktop = `[Desktop Entry]
Type=Application
Version=1.0
Name=IPFS Desktop
Comment=IPFS Desktop Startup Script
Exec=${exec}
Icon=ipfs-desktop
StartupNotify=false
Terminal=false`

  await fs.outputFile(getDesktopFile(), desktop)
  logger.info(`[launch on startup] wrote ${getDesktopFile()} with Exec=${exec}`)
}

async function disable () {
  if (app.setLoginItemSettings && (IS_MAC || IS_WIN)) {
    app.setLoginItemSettings({ openAtLogin: false })
    return
  }

  await fs.remove(getDesktopFile())
}

module.exports = async function () {
  const activate = async ({ newValue, oldValue, feedback }) => {
    if (process.env.NODE_ENV === 'development') {
      logger.info('[launch on startup] unavailable during development')

      if (feedback) {
        showDialog({
          title: 'Launch at Login',
          message: 'Not available during development.',
          buttons: [i18n.t('close')]
        })
      }

      return
    }

    if (!isSupported()) {
      logger.info('[launch on startup] not supported on this platform')

      if (feedback) {
        showDialog({
          title: i18n.t('launchAtLoginNotSupported.title'),
          message: i18n.t('launchAtLoginNotSupported.message'),
          buttons: [i18n.t('close')]
        })
      }

      return false
    }

    if (newValue === oldValue) return

    try {
      if (newValue === true) {
        await enable()
        logger.info('[launch on startup] enabled')
      } else {
        await disable()
        logger.info('[launch on startup] disabled')
      }

      return true
    } catch (err) {
      logger.error(`[launch on startup] ${err.toString()}`)

      if (feedback) {
        recoverableErrorDialog(err, {
          title: i18n.t('launchAtLoginFailed.title'),
          message: i18n.t('launchAtLoginFailed.message')
        })
      }

      return false
    }
  }

  activate({ newValue: store.get(CONFIG_KEY, false) })
  createToggler(CONFIG_KEY, activate)
}

module.exports.isSupported = isSupported
module.exports.quoteDesktopEntryArg = quoteDesktopEntryArg
module.exports.getLinuxAutostartExec = getLinuxAutostartExec
