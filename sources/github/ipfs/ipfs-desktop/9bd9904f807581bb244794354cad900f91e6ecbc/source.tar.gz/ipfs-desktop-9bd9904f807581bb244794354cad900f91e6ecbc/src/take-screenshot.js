const i18n = require('i18next')
const { clipboard, desktopCapturer, screen } = require('electron')
const logger = require('./common/logger')
const { IS_MAC } = require('./common/consts')
const { notify, notifyError } = require('./common/notify')
const { SCREENSHOT_SHORTCUT: CONFIG_KEY } = require('./common/config-keys')
const setupGlobalShortcut = require('./utils/setup-global-shortcut')
const { analyticsKeys } = require('./analytics/keys')
const getCtx = require('./context')

const SHORTCUT = IS_MAC
  ? 'Command+Control+S'
  : 'CommandOrControl+Alt+S'

async function makeScreenshotDir (ipfs) {
  try {
    await ipfs.files.stat('/screenshots')
  } catch (_) {
    await ipfs.files.mkdir('/screenshots')
  }
}

async function onSuccess (ipfs, launchWebUI, path, img) {
  // preserve filename if single file is shared
  const filename = path.endsWith('.png') ? `?filename=${encodeURIComponent(path.split('/').pop())}` : ''
  const { cid } = await ipfs.files.stat(path)
  const url = `https://dweb.link/ipfs/${cid}${filename}`
  await clipboard.writeText(url)

  notify({
    title: i18n.t('screenshotTaken'),
    body: i18n.t('shareableLinkCopied'),
    icon: img.resize({
      width: 200,
      quality: 'good'
    })
  }, () => {
    launchWebUI(`/files${path}`)
  })
}

function onError (e) {
  logger.error(`[screenshot] ${e.toString()}`)

  notifyError({
    title: i18n.t('couldNotTakeScreenshot'),
    body: i18n.t('errorwhileTakingScreenshot')
  })
}

// Ask for thumbnails at the display's pixel size, which is what makes them
// full-resolution grabs rather than previews. getSources rejects fractional
// dimensions, so round before handing the size over.
async function captureScreens () {
  const { size, scaleFactor } = screen.getPrimaryDisplay()

  const sources = await desktopCapturer.getSources({
    types: ['screen'],
    thumbnailSize: {
      width: Math.round(size.width * scaleFactor),
      height: Math.round(size.height * scaleFactor)
    }
  })

  // An empty thumbnail is how a missing screen-recording grant surfaces on
  // macOS: getSources still lists the display, it just hands back nothing.
  return sources.filter(({ thumbnail }) => !thumbnail.isEmpty())
}

async function takeScreenshot () {
  const ctx = getCtx()
  const launchWebUI = ctx.getFn('launchWebUI')
  const getIpfsd = ctx.getFn('getIpfsd')
  const ipfsd = await getIpfsd()

  if (!ipfsd) {
    return
  }

  const ipfs = ipfsd.api

  if (!ipfs) {
    logger.info('[screenshot] daemon not running')
    return
  }

  try {
    logger.info('[screenshot] taking screenshot')
    const screens = await captureScreens()

    if (screens.length === 0) {
      throw new Error('no screen could be captured, screen recording may not be permitted')
    }

    await makeScreenshotDir(ipfs)
    const isDir = screens.length > 1
    const d = new Date()
    const pad = n => String(n).padStart(2, '0')
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
    const time = `${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getMilliseconds())}`
    let baseName = `/screenshots/${date}_${time}`

    if (isDir) {
      baseName += '/'
      await ipfs.files.mkdir(baseName, { parents: true })
    } else {
      baseName += '.png'
    }

    logger.info(`[screenshot] started: writing screenshots to ${baseName}`, { withAnalytics: analyticsKeys.SCREENSHOT_TAKEN })
    let lastImage = null

    for (const { name, thumbnail } of screens) {
      const path = isDir ? `${baseName}${name}.png` : baseName
      const { cid } = await ipfs.add(thumbnail.toPNG(), { pin: false }) // no low level pin, presence in MFS will be enough to keep it around
      await ipfs.files.cp(cid, path)
      lastImage = thumbnail
    }

    logger.info(`[screenshot] completed: writing screenshots to ${baseName}`)
    onSuccess(ipfs, launchWebUI, baseName, lastImage)
  } catch (e) {
    onError(e)
  }
}

module.exports = function () {
  setupGlobalShortcut({
    confirmationDialog: {
      title: i18n.t('enableGlobalTakeScreenshotShortcut.title'),
      message: i18n.t('enableGlobalTakeScreenshotShortcut.message', { accelerator: SHORTCUT })
    },
    settingsOption: CONFIG_KEY,
    accelerator: SHORTCUT,
    action: () => {
      takeScreenshot()
    }
  })
}

module.exports.takeScreenshot = takeScreenshot
module.exports.SHORTCUT = SHORTCUT
