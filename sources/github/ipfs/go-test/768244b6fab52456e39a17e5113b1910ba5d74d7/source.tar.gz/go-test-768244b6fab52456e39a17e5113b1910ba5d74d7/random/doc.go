// Package random provides functionality to generate pseudo-random test data.
//
// All random numbers and data are created deterministically using the ChaCha8
// pseudo-random number generator. This generator's output is determined by a
// seed value that can be set explicitly. If not set, then cryptographically
// secure random data is used as the seed.
package random
