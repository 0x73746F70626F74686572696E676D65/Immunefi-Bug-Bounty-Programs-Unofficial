package random_test

import (
	"strings"
	"testing"

	blocks "github.com/ipfs/go-block-format"
	"github.com/ipfs/go-test/random"
	"github.com/libp2p/go-libp2p/core/peer"
	"github.com/multiformats/go-multiaddr"
	"github.com/multiformats/go-multihash"
	"github.com/stretchr/testify/require"
)

func TestUint64ToSeed(t *testing.T) {
	val := random.New().Uint64()
	seed := random.Uint64ToSeed(val)
	require.Equal(t, seed, random.Uint64ToSeed(val))
	seed2 := random.Uint64ToSeed(val + 1)
	require.NotEqual(t, seed, seed2)

	rnd1 := random.NewSeeded(seed)
	n1 := rnd1.Int()

	rnd2 := random.NewSeeded(seed)
	require.Equal(t, n1, rnd2.Int())

	rnd3 := random.NewSeeded(seed2)
	require.NotEqual(t, n1, rnd3.Int())
}

func TestStringToSeed(t *testing.T) {
	name := random.New().Name(100)
	seed := random.StringToSeed(name)
	require.Equal(t, seed, random.StringToSeed(name))
	seed2 := random.StringToSeed(name + "X")
	require.NotEqual(t, seed, seed2)
	rnd1 := random.NewSeeded(seed)
	n1 := rnd1.Int()

	rnd2 := random.NewSeeded(seed)
	require.Equal(t, n1, rnd2.Int())

	rnd3 := random.NewSeeded(seed2)
	require.NotEqual(t, n1, rnd3.Int())
}

func TestAddrs(t *testing.T) {
	addrs := random.Addrs(3)
	require.Len(t, addrs, 3)
	for _, a := range addrs {
		require.True(t, strings.HasPrefix(a, "/ip4/"))
		require.Equal(t, 3, strings.Count(a, "."))
		require.Contains(t, a, "/tcp/")
		_, err := multiaddr.NewMultiaddr(a)
		require.NoError(t, err)
	}
}

func TestBytes(t *testing.T) {
	b1 := random.Bytes(32)
	b2 := random.Bytes(32)
	require.Len(t, b1, 32)
	require.NotEqual(t, b1, b2)
	t.Logf("bytes: %x", b1)
	t.Logf("bytes: %x", b2)
}

func TestBlocksOfSize(t *testing.T) {
	const blockSize = 64
	blks := random.BlocksOfSize(3, blockSize)
	require.Len(t, blks, 3)
	for _, b := range blks {
		require.Equal(t, blockSize, len(b.RawData()))
		require.Equal(t, blocks.NewBlock(b.RawData()).Cid(), b.Cid(), "block CIDs mismatch")
	}
}

func TestDnsAddrs(t *testing.T) {
	addrs := random.DnsAddrs(3)
	require.Len(t, addrs, 3)
	for _, a := range addrs {
		require.True(t, strings.HasPrefix(a, "/dns4/"))
		require.Equal(t, 2, strings.Count(a, "."))
		require.Contains(t, a, ".example.com/tcp/")
		_, err := multiaddr.NewMultiaddr(a)
		require.NoError(t, err)
	}
}

func TestMultiaddrs(t *testing.T) {
	const n = 2000
	ms := random.Multiaddrs(n)
	require.Len(t, ms, n)
	for _, ma := range ms {
		maStr := ma.String()
		after, ok := strings.CutPrefix(maStr, "/ip4/")
		require.True(t, ok, "missing /ip4/ prefix")
		require.False(t, strings.HasPrefix(after, "0."), "bad addr:", maStr)
		require.False(t, strings.HasPrefix(after, "255."), "bad addr:", maStr)
	}
}

func TestDnsMultiaddrs(t *testing.T) {
	ms := random.DnsMultiaddrs(3)
	require.Len(t, ms, 3)
	for _, ma := range ms {
		maStr := ma.String()
		require.True(t, strings.HasPrefix(maStr, "/dns4/"))
		t.Log("dns multiaddr:", maStr)
	}
}

func TestHttpMultiaddrs(t *testing.T) {
	hms := random.HttpMultiaddrs(3)
	require.Len(t, hms, 3)
	for _, ma := range hms {
		maStr := ma.String()
		require.True(t, strings.HasPrefix(maStr, "/ip4/"))
		require.True(t, strings.HasSuffix(maStr, "/http"))
		t.Log("http multiaddr:", maStr)
	}
}

func TestHttpDnsMultiaddrs(t *testing.T) {
	hdms := random.HttpDnsMultiaddrs(3)
	require.Len(t, hdms, 3)
	for _, ma := range hdms {
		maStr := ma.String()
		require.True(t, strings.HasPrefix(maStr, "/dns4/"))
		require.True(t, strings.HasSuffix(maStr, "/http"))
		t.Log("http multiaddr:", maStr)
	}
}

func TestAddrInfos(t *testing.T) {
	const (
		numPeers = 3
		numAddrs = 2
	)
	addrInfos := random.AddrInfos(numPeers, numAddrs)
	require.Len(t, addrInfos, numPeers)
	for _, addrInfo := range addrInfos {
		require.Len(t, addrInfo.Addrs, numAddrs)
		for _, addr := range addrInfo.Addrs {
			maStr := addr.String()
			require.True(t, strings.HasPrefix(maStr, "/ip4/"))
			require.False(t, strings.HasSuffix(maStr, "/http"))
		}
		t.Log("AddrInfo:", addrInfo)
	}
}

func TestDnsAddrInfos(t *testing.T) {
	const (
		numPeers = 3
		numAddrs = 2
	)
	addrInfos := random.DnsAddrInfos(numPeers, numAddrs)
	require.Len(t, addrInfos, numPeers)
	for _, addrInfo := range addrInfos {
		require.Len(t, addrInfo.Addrs, numAddrs)
		for _, addr := range addrInfo.Addrs {
			maStr := addr.String()
			require.True(t, strings.HasPrefix(maStr, "/dns4/"))
			require.False(t, strings.HasSuffix(maStr, "/http"))
		}
		t.Log("AddrInfo:", addrInfo)
	}
}

func TestHttpAddrInfos(t *testing.T) {
	const (
		numPeers = 3
		numAddrs = 2
	)
	addrInfos := random.HttpAddrInfos(numPeers, numAddrs)
	require.Len(t, addrInfos, numPeers)
	for _, addrInfo := range addrInfos {
		require.Len(t, addrInfo.Addrs, numAddrs)
		for _, addr := range addrInfo.Addrs {
			maStr := addr.String()
			require.True(t, strings.HasPrefix(maStr, "/ip4/"))
			require.True(t, strings.HasSuffix(maStr, "/http"))
		}
		t.Log("AddrInfo:", addrInfo)
	}
}
func TestHttpDnsAddrInfos(t *testing.T) {
	const (
		numPeers = 3
		numAddrs = 2
	)
	addrInfos := random.HttpDnsAddrInfos(numPeers, numAddrs)
	require.Len(t, addrInfos, numPeers)
	for _, addrInfo := range addrInfos {
		require.Len(t, addrInfo.Addrs, numAddrs)
		for _, addr := range addrInfo.Addrs {
			maStr := addr.String()
			require.True(t, strings.HasPrefix(maStr, "/dns4/"))
			require.True(t, strings.HasSuffix(maStr, "/http"))
		}
		t.Log("AddrInfo:", addrInfo)
	}
}

func TestCids(t *testing.T) {
	cids := random.Cids(3)
	require.Len(t, cids, 3)
	for _, c := range cids {
		require.True(t, strings.HasPrefix(c.String(), "baguqeera"))
		t.Log("cid:", c.String())
	}
}

func TestIdentity(t *testing.T) {
	id, pvtKey, pubKey := random.Identity()

	testID, err := peer.IDFromPrivateKey(pvtKey)
	require.NoError(t, err)
	require.Equal(t, id, testID)
	testPub := pvtKey.GetPublic()
	require.Equal(t, pubKey, testPub)
}

func TestMultihashes(t *testing.T) {
	mhs := random.Multihashes(3)
	require.Len(t, mhs, 3)
	for _, mh := range mhs {
		decMh, err := multihash.Decode(mh)
		require.NoError(t, err)
		require.Equal(t, int(decMh.Code), multihash.SHA2_256)
	}
}

func TestName(t *testing.T) {
	const nameLen = 8
	var prevName string
	for range 3 {
		name := random.Name(nameLen)
		require.Len(t, name, nameLen)
		if prevName != "" {
			require.NotEqual(t, prevName, name)
		}
		prevName = name
	}
}

func TestNameSize(t *testing.T) {
	const (
		minSize  = 4
		maxSize  = 16
		maxIters = (maxSize - minSize) * 1000
	)
	wantSizes := make(map[int]struct{}, maxSize-minSize)
	for i := minSize; i <= maxSize; i++ {
		wantSizes[i] = struct{}{}
	}
	var prevName string
	var iters int
	for len(wantSizes) != 0 {
		name := random.NameSize(minSize, maxSize)
		require.GreaterOrEqual(t, len(name), minSize)
		require.LessOrEqual(t, len(name), maxSize)
		delete(wantSizes, len(name))
		if prevName != "" {
			require.NotEqual(t, prevName, name)
		}
		prevName = name
		if iters == maxIters {
			t.Fatalf("did not generate all name sizes within %d tries", maxIters)
		}
		iters++
	}
	t.Log("got all sizes in", iters, "iterarions")
}

func TestPeers(t *testing.T) {
	peerIDs := random.Peers(3)
	require.Len(t, peerIDs, 3)
	for _, peerID := range peerIDs {
		peerStr := peerID.String()
		require.True(t, strings.HasPrefix(peerStr, "12D3Koo"))
		t.Log("peerID:", peerStr)
	}
}

func TestSeed(t *testing.T) {
	seed := random.NewSeed()

	rnd := random.NewSeeded(seed)
	b1 := rnd.Bytes(32)
	num1 := rnd.Int()
	name1 := rnd.NameSize(5, 10)

	b2 := rnd.Bytes(32)
	num2 := rnd.Int()
	name2 := rnd.NameSize(5, 10)

	rnd.Seed(seed)

	b3 := rnd.Bytes(32)
	num3 := rnd.Int()
	name3 := rnd.NameSize(5, 10)

	require.NotEqual(t, b1, b2)
	require.NotEqual(t, num1, num2)
	require.NotEqual(t, name1, name2)

	require.Equal(t, b1, b3)
	require.Equal(t, num1, num3)
	require.Equal(t, name1, name3)
}

func TestNewSeeded(t *testing.T) {
	seed := random.NewSeed()
	buf1 := make([]byte, 16)
	buf2 := make([]byte, 16)

	rng1 := random.NewSeeded(seed)
	rng2 := random.NewSeeded(seed)
	for range 10 {
		n1 := rng1.Int()
		n2 := rng2.Int()
		require.Equal(t, n1, n2)

		name1 := rng1.NameSize(5, 10)
		name2 := rng2.NameSize(5, 10)
		require.Equal(t, name1, name2)

		rng1.Read(buf1)
		rng2.Read(buf2)
		require.Equal(t, buf1, buf2)
	}

	rng1 = random.New()
	rng2 = random.New()
	for range 10 {
		n1 := rng1.Int()
		n2 := rng2.Int()
		require.NotEqual(t, n1, n2)

		name1 := rng1.NameSize(5, 10)
		name2 := rng2.NameSize(5, 10)
		require.NotEqual(t, name1, name2)

		rng1.Read(buf1)
		rng2.Read(buf2)
		require.NotEqual(t, buf1, buf2)
	}
}
