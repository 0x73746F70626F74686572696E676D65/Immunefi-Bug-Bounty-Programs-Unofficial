package random

import (
	crand "crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math/rand/v2"

	blocks "github.com/ipfs/go-block-format"
	"github.com/ipfs/go-cid"
	"github.com/libp2p/go-libp2p/core/crypto"
	"github.com/libp2p/go-libp2p/core/peer"
	"github.com/multiformats/go-multiaddr"
	"github.com/multiformats/go-multicodec"
	"github.com/multiformats/go-multihash"
)

const (
	minTcpPort = 1024
	maxTcpPort = 65535
)

// NewSeed creates a new random seed for use in seeding creating random sources
// with the same seed value using NewSeeded.
func NewSeed() [32]byte {
	var seed [32]byte
	_, _ = crand.Read(seed[:])
	return seed
}

// StringToSeed creates a seed value from a string. The string is hashed so
// that if the string is longer than the necessary seed data, the entire string
// contributes to the seed value.
func StringToSeed(s string) [32]byte {
	return sha256.Sum256([]byte(s))
}

// Uint64ToSeed creates a seed value from a uint64 value.
func Uint64ToSeed(val uint64) [32]byte {
	var seed [32]byte
	binary.BigEndian.PutUint64(seed[:], val)
	return seed
}

// Random extends math/rand/v2 Rand with functions for generating many useful
// types of data. It also provides a Read function to read random data into a
// buffer and serve as an io.Reader. Random contains its own pseudo-random
// source. The same Random instance must not be used concurrently. Create
// separate Random instances for use in concurrent goroutines.
type Random struct {
	*rand.Rand
	cc8 *rand.ChaCha8
}

// New returns a new Random instance that contains its own pseudo-random number
// source, seeded with a random value.
func New() *Random {
	var seed [32]byte
	_, _ = crand.Read(seed[:])
	cc8 := rand.NewChaCha8(seed)

	return &Random{
		cc8:  cc8,
		Rand: rand.New(cc8),
	}
}

// NewSeeded returns a new Random instance that contains its own pseudo-random
// number source seeded with the specified value. Creating a random source
// using the same seed value causes the generator to deterministically produce
// the same sequence of pseudo-random numbers.
func NewSeeded(seed [32]byte) *Random {
	cc8 := rand.NewChaCha8(seed)
	return &Random{
		Rand: rand.New(cc8),
		cc8:  cc8,
	}
}

// Read reads exactly len(p) bytes into p. It always returns len(p) and a nil error.
func (r *Random) Read(p []byte) (n int, err error) {
	return r.cc8.Read(p)
}

// Seed resets the Random instance to behave the same way as NewSeeded(seed).
func (r *Random) Seed(seed [32]byte) {
	r.cc8.Seed(seed)
}

// Addrs returns a slice of n random unique IPv4 addresses with a random port.
// The string is formatted as a multiaddr: "/ip4/n.n.n.n/tcp/n"
func (r *Random) Addrs(n int) []string {
	addrs := make([]string, 0, n)
	addrSet := make(map[string]struct{}, n)
	for len(addrs) < n {
		addr := fmt.Sprintf("%d.%d.%d.%d", r.IntN(254)+1, r.IntN(254)+1, r.IntN(254)+1, r.IntN(254)+1)
		if _, ok := addrSet[addr]; ok {
			continue
		}
		addrSet[addr] = struct{}{}
		addrs = append(addrs, fmt.Sprintf("/ip4/%s/tcp/%d", addr, r.IntN(maxTcpPort-minTcpPort)+minTcpPort))
	}
	return addrs
}

// DnsAddrs returns a slice of n random unique DNS addresses, formmated as a multiaddr:
// "/dns4/xxxxxxxx.example.com/tcp/n"
func (r *Random) DnsAddrs(n int) []string {
	const nameLen = 8
	addrs := make([]string, 0, n)
	nameSet := make(map[string]struct{}, n)
	for len(addrs) < n {
		name := r.Name(nameLen)
		if _, ok := nameSet[name]; ok {
			continue
		}
		nameSet[name] = struct{}{}
		addrs = append(addrs, fmt.Sprintf("/dns4/%s.example.com/tcp/%d", name, r.IntN(maxTcpPort-minTcpPort)+minTcpPort))
	}
	return addrs
}

// BlocksOfSize generates a slice of blocks of the specified byte size.
func (r *Random) BlocksOfSize(n int, size int64) []blocks.Block {
	genBlocks := make([]blocks.Block, n)
	for i := range n {
		genBlocks[i] = blocks.NewBlock(r.Bytes(size))
	}
	return genBlocks
}

// Bytes returns a byte array of the given size with random values.
func (r *Random) Bytes(n int64) []byte {
	data := make([]byte, n)
	r.Read(data)
	return data
}

// Cids returns a slice of n random unique CIDs.
func (r *Random) Cids(n int) []cid.Cid {
	cids := make([]cid.Cid, 0, n)
	for len(cids) < n {
		var b [32]byte
		r.Read(b[:])
		h, err := multihash.Encode(b[:], multihash.SHA2_256)
		if err != nil {
			panic(err)
		}
		cids = append(cids, cid.NewCidV1(uint64(multicodec.DagJson), h))
	}
	return cids
}

// Identity returns a random unique peer ID, private key, and public key.
func (r *Random) Identity() (peer.ID, crypto.PrivKey, crypto.PubKey) {
	privKey, pubKey, err := crypto.GenerateKeyPairWithReader(crypto.Ed25519, 256, r)
	if err != nil {
		panic(err)
	}
	peerID, err := peer.IDFromPublicKey(pubKey)
	if err != nil {
		panic(err)
	}
	return peerID, privKey, pubKey
}

// Multiaddrs returns a slice of n random unique Multiaddrs with ipv4 addresses.
func (r *Random) Multiaddrs(n int) []multiaddr.Multiaddr {
	return addrsToMultiaddrs(r.Addrs(n))
}

// DnsMultiaddrs returns a slice of n random unique Multiaddrs with dns addresses.
func (r *Random) DnsMultiaddrs(n int) []multiaddr.Multiaddr {
	return addrsToMultiaddrs(r.DnsAddrs(n))
}

// HttpMultiaddrs returns a slice of n random unique Multiaddrs with ipv4
// addresses and http protocol.
func (r *Random) HttpMultiaddrs(n int) []multiaddr.Multiaddr {
	return addrsToHttpMultiaddrs(r.Addrs(n))
}

// HttpDnsMultiaddrs returns a slice of n random unique Multiaddrs with dns
// addresses and http protocol.
func (r *Random) HttpDnsMultiaddrs(n int) []multiaddr.Multiaddr {
	return addrsToHttpMultiaddrs(r.DnsAddrs(n))
}

// Multihashes returns a slice of n random unique Multihashes.
func (r *Random) Multihashes(n int) []multihash.Multihash {
	mhashes := make([]multihash.Multihash, 0, n)
	for len(mhashes) < n {
		var b [32]byte
		r.Read(b[:])
		h, err := multihash.Encode(b[:], multihash.SHA2_256)
		if err != nil {
			panic(err.Error())
		}
		mhashes = append(mhashes, h)
	}
	return mhashes
}

// Name returns a string of n random lower-alphanumeric characters.
func (r *Random) Name(size int) string {
	const alphanum = "abcdefghijklmnopqrstuvwxyz0123456789"

	if size <= 0 {
		return ""
	}
	src := make([]byte, size)
	r.Read(src)
	for i := range src {
		src[i] = alphanum[src[i]%36]
	}
	return string(src)
}

// NameSize returns a string of random lower-alphanumeric characters, having a
// random size of at least minSize and at most maxSize.
func (r *Random) NameSize(minSize, maxSize int) string {
	if minSize > maxSize {
		minSize, maxSize = maxSize, minSize
	}
	sizeDiff := maxSize - minSize
	size := minSize
	if sizeDiff != 0 {
		size += r.IntN(sizeDiff + 1)
	}
	return r.Name(size)
}

// Peers returns a slice of n random peer IDs.
func (r *Random) Peers(n int) []peer.ID {
	peerIDs := make([]peer.ID, n)
	for i := range n {
		_, publicKey, err := crypto.GenerateEd25519Key(r)
		if err != nil {
			panic(err)
		}
		peerID, err := peer.IDFromPublicKey(publicKey)
		if err != nil {
			panic(err)
		}
		peerIDs[i] = peerID
	}
	return peerIDs
}

// AddrInfos returns a slice AddrInfo with numPeers elements. Each AddrInfo has
// a unique ID and numAddrs Addresses. The multiaddrs are ipv4 addresses.
func (r *Random) AddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return r.addrInfos(numPeers, numAddrs, r.Multiaddrs)
}

// DnsAddrInfos returns a slice AddrInfo with numPeers elements. Each AddrInfo
// has a unique ID and numAddrs Addresses. The multiaddrs are dns addresses.
func (r *Random) DnsAddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return r.addrInfos(numPeers, numAddrs, r.DnsMultiaddrs)
}

// HttpAddrInfos returns a slice AddrInfo with numPeers elements. Each AddrInfo
// has a unique ID and numAddrs Addresses. The multiaddrs are ipv4 addresses
// with http protocol
func (r *Random) HttpAddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return r.addrInfos(numPeers, numAddrs, r.HttpMultiaddrs)
}

// HttpDnsAddrInfos returns a slice AddrInfo with numPeers elements. Each
// AddrInfo has a unique ID and numAddrs Addresses. The multiaddrs are dns
// addresses with http protocol.
func (r *Random) HttpDnsAddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return r.addrInfos(numPeers, numAddrs, r.HttpDnsMultiaddrs)
}

func (r *Random) addrInfos(numPeers, numAddrs int, multiaddrsFunc func(int) []multiaddr.Multiaddr) []peer.AddrInfo {
	peerIDs := r.Peers(numPeers)
	addrInfos := make([]peer.AddrInfo, numPeers)
	for i := range numPeers {
		addrInfos[i] = peer.AddrInfo{
			ID:    peerIDs[i],
			Addrs: multiaddrsFunc(numAddrs),
		}
	}
	return addrInfos
}

// Addrs returns a slice of n random unique IPv4 addresses.
//
// Creates its own random source; safe for concurrent use.
func Addrs(n int) []string {
	return New().Addrs(n)
}

// DnsAddrs returns a slice of n random unique DNS addresses in the format
// "xxxxxxxx.example.com:port".
//
// Creates its own random source; safe for concurrent use.
func DnsAddrs(n int) []string {
	return New().DnsAddrs(n)
}

// BlocksOfSize generates a slice of blocks of the specified byte size.
//
// Creates its own random source; safe for concurrent use.
func BlocksOfSize(n int, size int64) []blocks.Block {
	return New().BlocksOfSize(n, size)
}

// Bytes returns a byte array of the given size with random values.
//
// Creates its own random source; safe for concurrent use.
func Bytes(n int64) []byte {
	return New().Bytes(n)
}

// Cids returns a slice of n random unique CIDs.
//
// Creates its own random source; safe for concurrent use.
func Cids(n int) []cid.Cid {
	return New().Cids(n)
}

// Identity returns a random unique peer ID, private key, and public key.
//
// Creates its own random source; safe for concurrent use.
func Identity() (peer.ID, crypto.PrivKey, crypto.PubKey) {
	return New().Identity()
}

// Multiaddrs returns a slice of n random unique Multiaddrs with ipv4 addresses.
//
// Creates its own random source; safe for concurrent use.
func Multiaddrs(n int) []multiaddr.Multiaddr {
	return New().Multiaddrs(n)
}

// DnsMultiaddrs returns a slice of n random unique Multiaddrs with dns addresses.
//
// Creates its own random source; safe for concurrent use.
func DnsMultiaddrs(n int) []multiaddr.Multiaddr {
	return New().DnsMultiaddrs(n)
}

// HttpMultiaddrs returns a slice of n random unique Multiaddrs with ipv4
// addresses and http protocol.
//
// Creates its own random source; safe for concurrent use.
func HttpMultiaddrs(n int) []multiaddr.Multiaddr {
	return New().HttpMultiaddrs(n)
}

// HttpDnsMultiaddrs returns a slice of n random unique Multiaddrs with dns
// addresses and http protocol.
//
// Creates its own random source; safe for concurrent use.
func HttpDnsMultiaddrs(n int) []multiaddr.Multiaddr {
	return New().HttpDnsMultiaddrs(n)
}

// Multihashes returns a slice of n random unique Multihashes.
//
// Creates its own random source; safe for concurrent use.
func Multihashes(n int) []multihash.Multihash {
	return New().Multihashes(n)
}

// Name returns a string of n random lower-alphanumeric characters.
//
// Creates its own random source; safe for concurrent use.
func Name(size int) string {
	return New().Name(size)
}

// NameSize returns a string of random lower-alphanumeric characters, having a
// random size of at least minSize and at most maxSize.
//
// Creates its own random source; safe for concurrent use.
func NameSize(minSize, maxSize int) string {
	return New().NameSize(minSize, maxSize)
}

// Peers returns a slice of n random peer IDs.
//
// Creates its own random source; safe for concurrent use.
func Peers(n int) []peer.ID {
	return New().Peers(n)
}

// AddrInfos returns a slice AddrInfo with numPeers elements. Each AddrInfo has
// a unique ID and numAddrs Addresses. The multiaddrs are ipv4 addresses.
//
// Creates its own random source; safe for concurrent use.
func AddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return New().AddrInfos(numPeers, numAddrs)
}

// DnsAddrInfos returns a slice AddrInfo with numPeers elements. Each AddrInfo
// has a unique ID and numAddrs Addresses. The multiaddrs are dns addresses.
//
// Creates its own random source; safe for concurrent use.
func DnsAddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return New().DnsAddrInfos(numPeers, numAddrs)
}

// HttpAddrInfos returns a slice AddrInfo with numPeers elements. Each AddrInfo
// has a unique ID and numAddrs Addresses. The multiaddrs are ipv4 addresses
// with http protocol
//
// Creates its own random source; safe for concurrent use.
func HttpAddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return New().HttpAddrInfos(numPeers, numAddrs)
}

// HttpDnsAddrInfos returns a slice AddrInfo with numPeers elements. Each
// AddrInfo has a unique ID and numAddrs Addresses. The multiaddrs are dns
// addresses with http protocol.
//
// Creates its own random source; safe for concurrent use.
func HttpDnsAddrInfos(numPeers, numAddrs int) []peer.AddrInfo {
	return New().HttpDnsAddrInfos(numPeers, numAddrs)
}

func addrsToMultiaddrs(addrs []string) []multiaddr.Multiaddr {
	maddrs := make([]multiaddr.Multiaddr, len(addrs))
	for i, addr := range addrs {
		maddr, err := multiaddr.NewMultiaddr(addr)
		if err != nil {
			panic(err)
		}
		maddrs[i] = maddr
	}
	return maddrs
}

func addrsToHttpMultiaddrs(addrs []string) []multiaddr.Multiaddr {
	httpMultiaddrComponent := multiaddr.StringCast("/http")
	maddrs := make([]multiaddr.Multiaddr, len(addrs))
	for i, addr := range addrs {
		maddr, err := multiaddr.NewMultiaddr(addr)
		if err != nil {
			panic(err)
		}
		maddrs[i] = multiaddr.Join(maddr, httpMultiaddrComponent)
	}
	return maddrs
}

// Deprecated: use New()
func NewRand() *Random {
	return New()
}

// Deprecated: use NewSeeded(bytesSeed) or NewSeeded(MakeSeed(uint64Seed))
func NewSeededRand(seed uint64) *Random {
	return NewSeeded(Uint64ToSeed(seed))
}
