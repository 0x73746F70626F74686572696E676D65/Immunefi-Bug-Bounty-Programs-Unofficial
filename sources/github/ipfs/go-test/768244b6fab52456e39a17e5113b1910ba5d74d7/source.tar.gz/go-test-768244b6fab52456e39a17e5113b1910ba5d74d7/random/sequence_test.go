package random_test

import (
	"sync"
	"testing"

	"github.com/ipfs/go-test/random"
	"github.com/stretchr/testify/require"
)

func TestSequence(t *testing.T) {
	const (
		seqCount = 5
		seqSize  = 10
	)
	seq := random.NewSequence()

	firstNum := seq.Next()
	secondNum := seq.NextN(1)[0]
	require.Equal(t, firstNum+1, secondNum)

	seen := make(map[uint64]struct{}, seqSize*seqCount+1)
	seen[firstNum] = struct{}{}
	seen[secondNum] = struct{}{}

	seqs := make(chan []uint64)
	startGate := make(chan struct{})
	var ready sync.WaitGroup
	ready.Add(seqCount)

	for range seqCount {
		go func() {
			ready.Done()
			<-startGate
			seqs <- seq.NextN(seqSize)
		}()
	}

	ready.Wait()
	close(startGate)

	for range seqCount {
		nums := <-seqs
		for _, num := range nums {
			_, found := seen[num]
			require.Falsef(t, found, "sequence number %d is not unique", num)
			seen[num] = struct{}{}
		}
	}
	lastNum := seq.Next()
	t.Log("first seq num:", firstNum)
	t.Log("last seq num: ", lastNum)
	require.Equal(t, secondNum+(seqCount*seqSize)+1, lastNum, "expected lastnum to be %d + %d + 1, was %d", secondNum, seqCount*seqSize, lastNum)
}
