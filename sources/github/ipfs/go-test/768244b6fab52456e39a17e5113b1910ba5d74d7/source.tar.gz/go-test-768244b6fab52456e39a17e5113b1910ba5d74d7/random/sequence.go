package random

import (
	"math/rand/v2"
	"sync/atomic"
)

// Sequence returns a series of monotonically increasing numbers, starting at
// the next unique global sequence value. Any current calls to Sequence will
// not generate any overlapping values.
//
// The sequence numbers themselves are not random, only the global starting
// value of the sequence numbers is random. This ensures that all sequences
// generated within a test are unique, assuming < 2^64 values are generated,
// but start out at a random value.
type Sequence struct {
	next atomic.Uint64
}

// NewSequence creates a new Sequence that starts at a random number.
func NewSequence() *Sequence {
	return NewSequenceAt(rand.Uint64())
}

// NewSequenceAt creates a new Sequence that starts at a the specified number.
func NewSequenceAt(start uint64) *Sequence {
	s := new(Sequence)
	s.next.Store(start)
	return s
}

// NextN returns the next n sequence values.
func (s *Sequence) NextN(n int) []uint64 {
	if n == 1 {
		return []uint64{s.next.Add(1)}
	}
	seqVal := s.next.Add(uint64(n)) - uint64(n-1)
	seq := make([]uint64, n)
	for i := range n {
		seq[i] = seqVal + uint64(i)
	}
	return seq
}

// Next returns the next sequence value. This is equivalent to NextN(1)[0].
func (s *Sequence) Next() uint64 {
	return s.next.Add(1)
}
