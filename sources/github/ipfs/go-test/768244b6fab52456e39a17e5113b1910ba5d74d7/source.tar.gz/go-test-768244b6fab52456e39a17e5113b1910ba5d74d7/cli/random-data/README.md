# random-data - writes random data to stdout

`random-data` writes pseudo-random data to stdout for testing. The data can be written as raw bytes or base64 encodde.

## Install

```
go install github.com/ipfs/go-test/cli/random-data
```

## Usage

```sh
> random-bytes -help
NAME
  ./random-data - Write random data to stdout

USAGE
  ./random-data [options]

OPTIONS:
  -b64
        base-64 encode output
  -seed string
        random seed, leave empty to use random value
  -size int
        number of bytes to generate
```

## Examples

```sh
random-data -size=64 -b64 -seed=hello
ce6rEiwW4jN+E6pCW8UZErXC21sGpkTFuaPEW8VrtayX6nhbbSHOmkFQ1MoHbB2KU2J0ocATYGK4JFEsYNEtlA==
```

Note: Specifying the same seed will produce the same results. Specifying no ssed procudes random results.
