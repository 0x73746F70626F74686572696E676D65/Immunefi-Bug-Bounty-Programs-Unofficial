# random-files - create random filesystem hierarchies

`random-files` creates random filesystem hierarchies for testing

## Install

```
go install github.com/ipfs/go-test/cli/random-files
```

## Usage

```sh
> random-files -help
NAME
  random-files - Write a random filesystem hierarchy to each <path>

USAGE
  random-files [options] <path>...

OPTIONS:
  -depth int
        depth of the directory tree including the root directory (default 2)
  -dirs int
        number of subdirectories at each depth (default 5)
  -files int
        number of files at each depth (default 10)
  -filesize int
        bytes of random data in each file (default 4096)
  -q    do not print files and directories
  -random-dirs
        randomize number of subdirectories, from 1 to -dirs
  -random-files
        randomize number of files, from 1 to -files
  -random-size
        randomize file size, from 1 to -filesize (default true)
  -seed string
        random seed, leave empty to use random value
```

## Examples

```sh
> random-files -depth=2 -files=3 -seed=1701 foo
foo/mts2ph
foo/wsu46w33-df_v44c
foo/fcuxmunecbs_de
foo/vfpwv_asjhs2nz/
foo/vfpwv_asjhs2nz/8533
foo/vfpwv_asjhs2nz/8nj3jouo1xg_
foo/vfpwv_asjhs2nz/v9awmhr
foo/ujj95a/
foo/ujj95a/n1mf
foo/ujj95a/-taw_yfnc2
foo/ujj95a/h5j-x7rkawl6zc8
foo/v2isuq37wxt/
foo/v2isuq37wxt/0v1od94eojxv
foo/v2isuq37wxt/u4z-gcvoe4w
foo/v2isuq37wxt/ogm2b-coenbu8t2
foo/sn35leocdzm15l/
foo/sn35leocdzm15l/b4w3
foo/sn35leocdzm15l/f73xrgznl57
foo/sn35leocdzm15l/7tt51n7lbvv9
foo/m4ttn58z0x77sbo0/
foo/m4ttn58z0x77sbo0/ydv5ld_4o7tvw7
foo/m4ttn58z0x77sbo0/khdlmwfpegefix
foo/m4ttn58z0x77sbo0/ud2mo
```

It made:

```sh
> tree foo
foo
├── fcuxmunecbs_de
├── m4ttn58z0x77sbo0
│   ├── khdlmwfpegefix
│   ├── ud2mo
│   └── ydv5ld_4o7tvw7
├── mts2ph
├── sn35leocdzm15l
│   ├── 7tt51n7lbvv9
│   ├── b4w3
│   └── f73xrgznl57
├── ujj95a
│   ├── -taw_yfnc2
│   ├── h5j-x7rkawl6zc8
│   └── n1mf
├── v2isuq37wxt
│   ├── 0v1od94eojxv
│   ├── ogm2b-coenbu8t2
│   └── u4z-gcvoe4w
├── vfpwv_asjhs2nz
│   ├── 8533
│   ├── 8nj3jouo1xg_
│   └── v9awmhr
└── wsu46w33-df_v44c

6 directories, 18 files
```

Note: Specifying the same seed will produce the same results. Specifying no ssed procudes random results.

### Acknowledgments

Credit to [Juan Benet](https://github.com/jbenet) as the author of [`go-random-files`](https://github.com/jbenet/go-random-files) from which this code was derived.
