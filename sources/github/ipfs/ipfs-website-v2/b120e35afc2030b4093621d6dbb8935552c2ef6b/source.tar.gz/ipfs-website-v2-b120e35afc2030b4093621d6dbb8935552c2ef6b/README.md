[Moved](https://github.com/ipfs/ipfs-website/pull/322) into the [main IPFS Website Repository](https://github.com/ipfs/ipfs-website/)

