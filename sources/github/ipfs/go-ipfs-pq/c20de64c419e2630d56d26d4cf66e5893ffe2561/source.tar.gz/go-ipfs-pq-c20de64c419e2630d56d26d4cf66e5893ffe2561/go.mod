module github.com/ipfs/go-ipfs-pq

go 1.25
