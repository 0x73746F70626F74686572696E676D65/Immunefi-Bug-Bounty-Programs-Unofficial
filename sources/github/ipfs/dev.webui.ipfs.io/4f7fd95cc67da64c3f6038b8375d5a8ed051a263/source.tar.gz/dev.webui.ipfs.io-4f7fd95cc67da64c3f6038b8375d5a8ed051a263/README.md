# dev.webui.ipfs.io

Deploy target for <https://dev.webui.ipfs.io>: a preview of the `main` branch of [ipfs/ipfs-webui](https://github.com/ipfs/ipfs-webui), served by GitHub Pages.

Do not commit here and do not open PRs. Everything on the `gh-pages` branch is machine-written and overwritten on every publish. Source code, issues, and PRs belong in [ipfs/ipfs-webui](https://github.com/ipfs/ipfs-webui).

## How it works

- Every merge to `main` in `ipfs/ipfs-webui` runs the `publishPreview` job in its `ci.yml`, which force-pushes the built app to the `gh-pages` branch of this repo as a single orphan commit (no history, so the repo stays small).
- GitHub Pages serves that branch at <https://dev.webui.ipfs.io>. The custom domain lives in this repo's Pages settings and in the `CNAME` file, which CI rewrites on every push.
- The same build is pinned to IPFS and published under DNSLink (`_dnslink.dev.webui.ipfs.io`), so the preview is also reachable over IPFS, for example as `ipns://dev.webui.ipfs.io` via IPFS Companion. GitHub Pages only provides the plain HTTPS entrypoint.

## Operations

- Publishing credential: a write-access SSH deploy key on this repo. The private half is the `DEV_WEBUI_PAGES_DEPLOY_KEY` secret in the `Deploy` environment of `ipfs/ipfs-webui`.
- Rotation: generate a fresh key with `ssh-keygen -t ed25519 -N "" -C "ipfs-webui-ci -> dev.webui.ipfs.io pages"`, replace the deploy key here (Settings > Deploy keys, allow write access) and the secret there. Two clicks, no user account involved.
- Pages settings: source "Deploy from a branch", branch `gh-pages`, folder `/ (root)`, custom domain `dev.webui.ipfs.io`, "Enforce HTTPS" on.
- Branch protection stays off for `gh-pages`: publishing force-pushes an orphan commit.
- DNS (`ipfs.io` zone): `dev.webui.ipfs.io` is a `CNAME` to `ipfs.github.io`, DNS-only (not proxied), so GitHub can issue and renew the TLS certificate. The `_dnslink.dev.webui.ipfs.io` TXT record is managed separately and must never be removed.
- This repo intentionally contains no workflows; all publishing logic lives in `ipfs/ipfs-webui`.
