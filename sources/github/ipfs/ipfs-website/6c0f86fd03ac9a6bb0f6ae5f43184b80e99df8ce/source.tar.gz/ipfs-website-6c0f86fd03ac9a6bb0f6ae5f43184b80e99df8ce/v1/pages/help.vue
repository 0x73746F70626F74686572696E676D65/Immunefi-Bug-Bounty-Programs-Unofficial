<template>
  <ContentPage />
</template>
