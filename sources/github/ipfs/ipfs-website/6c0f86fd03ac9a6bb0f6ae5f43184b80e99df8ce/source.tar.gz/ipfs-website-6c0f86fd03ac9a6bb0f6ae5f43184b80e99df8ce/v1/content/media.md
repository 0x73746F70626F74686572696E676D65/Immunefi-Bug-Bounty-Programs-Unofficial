---
title: IPFS Press Kit
description: Resources for the media, including explainers, logos, and more.
---

We've created this IPFS press kit to help news and media outlets quickly find material to help understand and explain what IPFS is, who powers the IPFS project, and how it will shape the future of the internet.
If you're a member of the media and would like to request more information or interviews, please [email](mailto:press@protocol.ai).

### About IPFS

_Feel free to reprint the following descriptions in their entirety without explicit approval._

#### Long description

IPFS (the InterPlanetary File System) is a peer-to-peer hypermedia protocol for content addressing. An alternative to the HTTP protocol, IPFS builds on the principles of peer-to-peer networking and content-based addressing to create a decentralized, distributed, and trustless data storage and delivery network. With IPFS, users ask for a file and the system finds and delivers the closest copy without the need to trust a centralized delivery source. In addition to more efficient content distribution, IPFS offers improved security, content integrity, and resistance to third-party tampering. _(621 characters/95 words)_

#### Short description

IPFS (the InterPlanetary File System) is a peer-to-peer network and protocol designed to make the web faster, safer, and more open. IPFS upgrades the web to work peer to peer, addressing data by _what_ it is instead of _where_ it’s located on the network, or who is hosting it. _(282 characters/52 words)_

#### IPFS and Filecoin

Filecoin is an independent, complementary protocol that builds on the content addressing of IPFS to add longer term data persistence using cryptoeconomic incentives.
For details on understanding the relationship between IPFS and Filecoin, please see [this guide in Filecoin documentation (2023)](https://web.archive.org/web/20230223052220/https://docs.filecoin.io/developers/introduction/filecoin-and-ipfs/).

#### Does IPFS have a blockchain?

No, [IPFS does not have a blockchain](https://doesipfshaveablockchain.com/).

### The IPFS ecosystem

IPFS is made up of a large number of individuals and teams contributing to the project at a variety of levels, for a variety of individual, non-profit, and corporate projects.

#### Core team

The IPFS project is made up of a series of working groups, populated by many full-time and part-time contributors to core project needs.

[Interplanetary Shipyard](https://ipshipyard.com/) are the core maintainers of many of the popular IPFS and libp2p implementations.

#### Open-source community

As an open-source project, IPFS is home to a vibrant, diverse community of thousands of contributors and participants from all over the globe! Learn more about who they are and where to find them [in the Community section of the IPFS docs](https://docs.ipfs.tech/community/).

#### Projects using IPFS

A vast variety of commercial and non-profit projects alike are incorporating IPFS as critical to their goals and success. Many are amenable to talking to the media. Find out more about existing success stories at the following resources:

- [Case studies](https://docs.ipfs.tech/concepts/#examples-and-case-studies) for IPFS success stories in a variety of industries.
- Video presentations and demos from IPFS builders and collaborators in our [YouTube channel](https://www.youtube.com/c/IPFSbot/videos).
- Interactive [IPFS ecosystem directory](https://ecosystem.ipfs.tech) of companies and organizations worldwide building apps, services, and developer tools on IPFS.

### Logos
To request official IPFS logos and other graphic elements, please [email](mailto:press@protocol.ai).

### Featured news
All IPFS-related news can be found on our [Blog & News](http://blog.ipfs.tech) page. Items can be filtered by topic for easy access:

- [Blog posts](http://blog.ipfs.tech/?category=Blog%20post)
- [Video content](http://blog.ipfs.tech/?category=Video)
- [News coverage](http://blog.ipfs.tech/?category=News%20coverage)
- [Events](http://blog.ipfs.tech/?category=Event)

Additionally, you can get up-to-the minute updates on our [Twitter](https://twitter.com/ipfs) and [YouTube](https://www.youtube.com/c/IPFSbot) channels.
