## [3.0.8](https://github.com/ipfs/js-hamt-sharding/compare/v3.0.7...v3.0.8) (2026-05-12)

### Bug Fixes

* remove lockfile ([#76](https://github.com/ipfs/js-hamt-sharding/issues/76)) ([29b9139](https://github.com/ipfs/js-hamt-sharding/commit/29b9139e4852de13cbdeb8ad8e385a4120e95375))

### Dependencies

* update uint8arrays ([#75](https://github.com/ipfs/js-hamt-sharding/issues/75)) ([c2099ea](https://github.com/ipfs/js-hamt-sharding/commit/c2099ea12ed0e29ad3d38285d36bc5095c1f0b81))

## [3.0.7](https://github.com/ipfs/js-hamt-sharding/compare/v3.0.6...v3.0.7) (2026-05-12)

### Trivial Changes

* **deps:** update aegir to v47.0.26 ([#74](https://github.com/ipfs/js-hamt-sharding/issues/74)) ([ffab487](https://github.com/ipfs/js-hamt-sharding/commit/ffab487be9380c2322e3b97bcd4726e9a05e46cd))
* Update .github/workflows/stale.yml [skip ci] ([c44d10e](https://github.com/ipfs/js-hamt-sharding/commit/c44d10e7a20159122dfe3a0f1f4f422caa1a025a))

### Dependencies

* **dev:** bump aegir from 47.2.0 to 48.0.4 ([#71](https://github.com/ipfs/js-hamt-sharding/issues/71)) ([f1f07e7](https://github.com/ipfs/js-hamt-sharding/commit/f1f07e76b4de1e68cdc3068c92479f4b82e2a782))

## [3.0.6](https://github.com/ipfs/js-hamt-sharding/compare/v3.0.5...v3.0.6) (2024-02-06)


### Trivial Changes

* rename master to main ([4e780c0](https://github.com/ipfs/js-hamt-sharding/commit/4e780c0085d9f7c8120a1748c316385c16dff7e2))
* update urls ([e2a5ccc](https://github.com/ipfs/js-hamt-sharding/commit/e2a5ccca109a6c70ab2093773ce00c829ccccb22))


### Documentation

* update readme ([16a17f3](https://github.com/ipfs/js-hamt-sharding/commit/16a17f32a7dec7b702a510e8dcba389002bad2f9))

## [3.0.5](https://github.com/ipfs-shipyard/js-hamt-sharding/compare/v3.0.4...v3.0.5) (2024-02-06)


### Dependencies

* bump uint8arrays from 4.0.10 to 5.0.1 ([#64](https://github.com/ipfs-shipyard/js-hamt-sharding/issues/64)) ([63d56e4](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/63d56e4284a98238597694724f24dbe25f144581))

## [3.0.4](https://github.com/ipfs-shipyard/js-hamt-sharding/compare/v3.0.3...v3.0.4) (2024-02-06)


### Dependencies

* **dev:** bump aegir from 37.12.1 to 42.2.3 ([#63](https://github.com/ipfs-shipyard/js-hamt-sharding/issues/63)) ([f4a59e9](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/f4a59e994637b149da1f676814b98bf13a1e5a54))

## [3.0.3](https://github.com/ipfs/js-hamt-sharding/compare/v3.0.2...v3.0.3) (2024-02-06)


### Trivial Changes

* add or force update .github/workflows/js-test-and-release.yml ([#61](https://github.com/ipfs/js-hamt-sharding/issues/61)) ([a993a1e](https://github.com/ipfs/js-hamt-sharding/commit/a993a1e5a3dc234b118a4a32974478d3ba632af9))
* delete templates [skip ci] ([#60](https://github.com/ipfs/js-hamt-sharding/issues/60)) ([2d4bdc6](https://github.com/ipfs/js-hamt-sharding/commit/2d4bdc6fcc2965745974efe012ccf70c7bc8420d))
* Update .github/workflows/stale.yml [skip ci] ([18629a9](https://github.com/ipfs/js-hamt-sharding/commit/18629a905a4dbbe9ca540ac576f2f1941f00b12f))
* Update .github/workflows/stale.yml [skip ci] ([97305d6](https://github.com/ipfs/js-hamt-sharding/commit/97305d6ee50fc95f289e8cfae4154ee4847187d6))
* Update .github/workflows/stale.yml [skip ci] ([12ec5c4](https://github.com/ipfs/js-hamt-sharding/commit/12ec5c47c44ec2e893415150f92ad7af63a48c02))


### Dependencies

* **dev:** bump it-length from 2.0.1 to 3.0.4 ([#62](https://github.com/ipfs/js-hamt-sharding/issues/62)) ([6fec868](https://github.com/ipfs/js-hamt-sharding/commit/6fec8685c5b04a4e6e22e5e56b7c424f2a8c7b14))

## [3.0.2](https://github.com/ipfs/js-hamt-sharding/compare/v3.0.1...v3.0.2) (2022-10-18)


### Documentation

* update readme ([#37](https://github.com/ipfs/js-hamt-sharding/issues/37)) ([c064fcc](https://github.com/ipfs/js-hamt-sharding/commit/c064fcc62fd744076ccd21eb029a7190c6385de1))


### Dependencies

* bump uint8arrays from 3.1.1 to 4.0.2 ([#35](https://github.com/ipfs/js-hamt-sharding/issues/35)) ([f8867d6](https://github.com/ipfs/js-hamt-sharding/commit/f8867d6bab93a0759717105a4318d8090f627721))
* **dev:** bump it-length from 1.0.4 to 2.0.0 ([#36](https://github.com/ipfs/js-hamt-sharding/issues/36)) ([c844d7a](https://github.com/ipfs/js-hamt-sharding/commit/c844d7a5f31eefe8e871ea55e80117df9c10253a))

## [3.0.1](https://github.com/ipfs/js-hamt-sharding/compare/v3.0.0...v3.0.1) (2022-08-11)


### Trivial Changes

* Update .github/workflows/stale.yml [skip ci] ([0c6fd46](https://github.com/ipfs/js-hamt-sharding/commit/0c6fd461c134c2134a54caccb052f0ac72d962a7))


### Dependencies

* update aegir to 37.x.x ([#32](https://github.com/ipfs/js-hamt-sharding/issues/32)) ([bec52e7](https://github.com/ipfs/js-hamt-sharding/commit/bec52e70f607d81d87a2e33f1dd92192ef6cc245))

## [3.0.0](https://github.com/ipfs/js-hamt-sharding/compare/v2.0.1...v3.0.0) (2022-02-21)


### ⚠ BREAKING CHANGES

* this module is ESM-only now

### Bug Fixes

* interface exports ([#6](https://github.com/ipfs/js-hamt-sharding/issues/6)) ([36396f0](https://github.com/ipfs/js-hamt-sharding/commit/36396f02c62cda238625d5b48a39ac2f70063415))


### Trivial Changes

* switch to unified CI ([#8](https://github.com/ipfs/js-hamt-sharding/issues/8)) ([dca4537](https://github.com/ipfs/js-hamt-sharding/commit/dca45372186c18a9d5fae1713fb978fd49b53c4d))

## [2.0.1](https://github.com/ipfs-shipyard/js-hamt-sharding/compare/v2.0.0...v2.0.1) (2021-08-23)



# [2.0.0](https://github.com/ipfs-shipyard/js-hamt-sharding/compare/v1.0.0...v2.0.0) (2021-02-18)


### Features

* add types ([#3](https://github.com/ipfs-shipyard/js-hamt-sharding/issues/3)) ([8b7e204](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/8b7e204b9452ab3f7be1717bef0caa715dcbd91c))



<a name="1.0.0"></a>
# [1.0.0](https://github.com/ipfs-shipyard/js-hamt-sharding/compare/v0.0.2...v1.0.0) (2020-01-08)


### Bug Fixes

* linting ([83e6192](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/83e6192))



## 0.0.2 (2018-11-23)


### Bug Fixes

* compact children before counting them ([56a2ece](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/56a2ece))
* remove async generator so we can webpack it ([ebef92a](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/ebef92a))


### Features

* use async instead of callbacks ([2478d09](https://github.com/ipfs-shipyard/js-hamt-sharding/commit/2478d09))
