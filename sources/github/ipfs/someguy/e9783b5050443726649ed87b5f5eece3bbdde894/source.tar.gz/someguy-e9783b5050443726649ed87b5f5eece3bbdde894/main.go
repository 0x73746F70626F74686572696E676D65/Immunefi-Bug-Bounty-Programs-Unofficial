package main

import (
	"crypto/sha256"
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/ipfs/boxo/autoconf"
	"github.com/ipfs/boxo/ipns"
	"github.com/ipfs/go-cid"
	"github.com/libp2p/go-libp2p/core/peer"
	"github.com/multiformats/go-multibase"
	"github.com/multiformats/go-multihash"
	"github.com/urfave/cli/v2"
)

func main() {
	app := &cli.App{
		Name:    name,
		Usage:   "Delegated Routing V1 server and proxy.",
		Version: version,
		Commands: []*cli.Command{
			{
				Name:  "start",
				Usage: "Run a Delegated Routing V1 server",
				Flags: []cli.Flag{
					&cli.StringFlag{
						Name:    "listen-address",
						Value:   "127.0.0.1:8190",
						EnvVars: []string{"SOMEGUY_LISTEN_ADDRESS"},
						Usage:   "listen address",
					},
					&cli.StringFlag{
						Name:    "dht",
						Value:   "accelerated",
						EnvVars: []string{"SOMEGUY_DHT"},
						Usage:   "Amino DHT client mode: 'accelerated', 'standard', or 'disabled'",
					},
					&cli.BoolFlag{
						Name:    "cached-addr-book",
						Value:   true,
						EnvVars: []string{"SOMEGUY_CACHED_ADDR_BOOK"},
						Usage:   "use a cached address book to improve provider lookup responses",
					},
					&cli.BoolFlag{
						Name:    "cached-addr-book-active-probing",
						Value:   true,
						EnvVars: []string{"SOMEGUY_CACHED_ADDR_BOOK_ACTIVE_PROBING"},
						Usage:   "actively probe peers in cache to keep their multiaddrs up to date",
					},
					&cli.DurationFlag{
						Name:        "cached-addr-book-recent-ttl",
						DefaultText: DefaultRecentlyConnectedAddrTTL.String(),
						Value:       DefaultRecentlyConnectedAddrTTL,
						EnvVars:     []string{"SOMEGUY_CACHED_ADDR_BOOK_RECENT_TTL"},
						Usage:       "TTL for recently connected peers' multiaddrs in the cached address book",
					},
					&cli.IntFlag{
						Name:        "cached-addr-book-max-concurrent-find-peers",
						DefaultText: strconv.Itoa(DefaultMaxConcurrentFindPeers),
						Value:       DefaultMaxConcurrentFindPeers,
						EnvVars:     []string{"SOMEGUY_CACHED_ADDR_BOOK_MAX_CONCURRENT_FIND_PEERS"},
						Usage:       "maximum background FindPeer lookups running at once for provider records that arrive without addresses",
					},
					&cli.StringFlag{
						Name:    "dnsaddr-resolution",
						Value:   string(DNSAddrResolutionAppend),
						EnvVars: []string{"SOMEGUY_DNSADDR_RESOLUTION"},
						Usage:   "what an unfiltered response does with a /dnsaddr it resolved: 'append' (add the resolved addresses, keep the /dnsaddr), 'replace' (drop the /dnsaddr), 'filtered' (resolve only when the request sends filter-addrs), or 'never'; a request that sends filter-addrs gets it replaced in every resolving mode, unless the filter itself names dnsaddr",
					},
					&cli.DurationFlag{
						Name:        "routing-timeout",
						DefaultText: DefaultRoutingTimeout.String(),
						Value:       DefaultRoutingTimeout,
						EnvVars:     []string{"SOMEGUY_ROUTING_TIMEOUT"},
						Usage:       "maximum time spent in the routers per /routing/v1 request; keep it below the timeout clients apply to the whole request",
					},
					&cli.IntFlag{
						Name:    "records-limit",
						Value:   DefaultRecordsLimit,
						EnvVars: []string{"SOMEGUY_RECORDS_LIMIT"},
						Usage:   "maximum providers or peers per `Accept: application/json` request (HTTP Routing v1 section 4.1.5 recommends 100; 0 disables the cap)",
					},
					&cli.IntFlag{
						Name:    "streaming-records-limit",
						Value:   DefaultStreamingRecordsLimit,
						EnvVars: []string{"SOMEGUY_STREAMING_RECORDS_LIMIT"},
						Usage:   "maximum providers or peers per `Accept: application/x-ndjson` request (0 disables the cap)",
					},
					&cli.StringSliceFlag{
						Name:    "provider-endpoints",
						Value:   cli.NewStringSlice(autoconf.AutoPlaceholder),
						EnvVars: []string{"SOMEGUY_PROVIDER_ENDPOINTS"},
						Usage:   "additional Delegated Routing V1 endpoints for provider lookups",
					},
					&cli.StringSliceFlag{
						Name:    "http-block-provider-endpoints",
						Value:   nil,
						EnvVars: []string{"SOMEGUY_HTTP_BLOCK_PROVIDER_ENDPOINTS"},
						Usage:   "HTTP trustless gateway endpoints used to synthesize provider records",
					},
					&cli.StringSliceFlag{
						Name:    "http-block-provider-peerids",
						Value:   nil,
						EnvVars: []string{"SOMEGUY_HTTP_BLOCK_PROVIDER_PEERIDS"},
						Usage:   "PeerIDs to pair with --http-block-provider-endpoints (matching order)",
					},
					&cli.StringSliceFlag{
						Name:    "peer-endpoints",
						Value:   cli.NewStringSlice(autoconf.AutoPlaceholder),
						EnvVars: []string{"SOMEGUY_PEER_ENDPOINTS"},
						Usage:   "additional Delegated Routing V1 endpoints for peer lookups",
					},
					&cli.StringSliceFlag{
						Name:    "ipns-endpoints",
						Value:   cli.NewStringSlice(autoconf.AutoPlaceholder),
						EnvVars: []string{"SOMEGUY_IPNS_ENDPOINTS"},
						Usage:   "additional Delegated Routing V1 endpoints for IPNS records",
					},
					&cli.StringSliceFlag{
						Name: "libp2p-listen-addrs",
						// These defaults mirror libp2p.DefaultListenAddrs paired with
						// libp2p.DefaultTransports (see newHost), but on port 4004 to avoid
						// colliding with Kubo's 4001. Reviewer/LLM note: when bumping
						// go-libp2p, diff libp2p.DefaultListenAddrs and
						// libp2p.DefaultTransports (both in go-libp2p defaults.go) against
						// this list. If the transport set drifts, update this slice and
						// double-check that docs/environment-variables.md still matches.
						Value: cli.NewStringSlice(
							"/ip4/0.0.0.0/tcp/4004",
							"/ip4/0.0.0.0/udp/4004/quic-v1",
							"/ip4/0.0.0.0/udp/4004/webrtc-direct",
							"/ip4/0.0.0.0/udp/4004/quic-v1/webtransport",
							"/ip6/::/tcp/4004",
							"/ip6/::/udp/4004/quic-v1",
							"/ip6/::/udp/4004/webrtc-direct",
							"/ip6/::/udp/4004/quic-v1/webtransport"),
						EnvVars: []string{"SOMEGUY_LIBP2P_LISTEN_ADDRS"},
						Usage:   "libp2p listen multiaddresses (comma-separated)",
					},
					&cli.IntFlag{
						Name:    "libp2p-connmgr-low",
						Value:   100,
						EnvVars: []string{"SOMEGUY_LIBP2P_CONNMGR_LOW"},
						Usage:   "minimum number of libp2p connections to keep",
					},
					&cli.IntFlag{
						Name:    "libp2p-connmgr-high",
						Value:   3000,
						EnvVars: []string{"SOMEGUY_LIBP2P_CONNMGR_HIGH"},
						Usage:   "maximum number of libp2p connections to keep",
					},
					&cli.DurationFlag{
						Name:    "libp2p-connmgr-grace",
						Value:   time.Minute,
						EnvVars: []string{"SOMEGUY_LIBP2P_CONNMGR_GRACE_PERIOD"},
						Usage:   "minimum libp2p connection TTL",
					},
					&cli.Uint64Flag{
						Name:    "libp2p-max-memory",
						Value:   0,
						EnvVars: []string{"SOMEGUY_LIBP2P_MAX_MEMORY"},
						Usage:   "maximum memory to use for libp2p. Defaults to 85% of the system's available RAM",
					},
					&cli.Uint64Flag{
						Name:    "libp2p-max-fd",
						Value:   0,
						EnvVars: []string{"SOMEGUY_LIBP2P_MAX_FD"},
						Usage:   "maximum number of file descriptors used by libp2p node. Defaults to 50% of the process' limit",
					},
					&cli.StringFlag{
						Name:    "tracing-auth",
						Value:   "",
						EnvVars: []string{"SOMEGUY_TRACING_AUTH"},
						Usage:   "If set, requires clients to pass this value in the Authorization header before Traceparent is honored",
					},
					&cli.Float64Flag{
						Name:    "sampling-fraction",
						Value:   0,
						EnvVars: []string{"SOMEGUY_SAMPLING_FRACTION"},
						Usage:   "Fraction of routing requests to sample (0 to 1). Requests with Traceparent headers are always sampled, independent of this setting",
					},
					&cli.StringFlag{
						Name:    "datadir",
						Value:   "",
						EnvVars: []string{"SOMEGUY_DATADIR"},
						Usage:   "Directory for persistent data (autoconf cache)",
					},
					&cli.BoolFlag{
						Name:    "autoconf",
						Value:   true,
						EnvVars: []string{"SOMEGUY_AUTOCONF"},
						Usage:   "Enable autoconf for bootstrap, DNS resolvers, and HTTP routers",
					},
					&cli.StringFlag{
						Name:    "autoconf-url",
						Value:   "https://conf.ipfs-mainnet.org/autoconf.json",
						EnvVars: []string{"SOMEGUY_AUTOCONF_URL"},
						Usage:   "URL to fetch autoconf data from",
					},
					&cli.DurationFlag{
						Name:    "autoconf-refresh",
						Value:   24 * time.Hour,
						EnvVars: []string{"SOMEGUY_AUTOCONF_REFRESH"},
						Usage:   "How often to refresh autoconf data",
					},
				},
				Action: func(ctx *cli.Context) error {
					recordsLimit := ctx.Int("records-limit")
					if recordsLimit < 0 {
						return fmt.Errorf("records-limit must be non-negative, got %d (0 means unbounded)", recordsLimit)
					}
					streamingRecordsLimit := ctx.Int("streaming-records-limit")
					if streamingRecordsLimit < 0 {
						return fmt.Errorf("streaming-records-limit must be non-negative, got %d (0 means unbounded)", streamingRecordsLimit)
					}
					dnsAddrResolution, err := ParseDNSAddrResolution(ctx.String("dnsaddr-resolution"))
					if err != nil {
						return err
					}
					cfg := &config{
						listenAddress:               ctx.String("listen-address"),
						dhtType:                     ctx.String("dht"),
						cachedAddrBook:              ctx.Bool("cached-addr-book"),
						cachedAddrBookActiveProbing: ctx.Bool("cached-addr-book-active-probing"),
						cachedAddrBookRecentTTL:     ctx.Duration("cached-addr-book-recent-ttl"),
						cachedAddrBookMaxFindPeers:  ctx.Int("cached-addr-book-max-concurrent-find-peers"),
						routingTimeout:              ctx.Duration("routing-timeout"),
						dnsAddrResolution:           dnsAddrResolution,
						recordsLimit:                recordsLimit,
						streamingRecordsLimit:       streamingRecordsLimit,

						contentEndpoints:       ctx.StringSlice("provider-endpoints"),
						peerEndpoints:          ctx.StringSlice("peer-endpoints"),
						ipnsEndpoints:          ctx.StringSlice("ipns-endpoints"),
						blockProviderEndpoints: ctx.StringSlice("http-block-provider-endpoints"),
						blockProviderPeerIDs:   ctx.StringSlice("http-block-provider-peerids"),

						libp2pListenAddress: ctx.StringSlice("libp2p-listen-addrs"),
						connMgrLow:          ctx.Int("libp2p-connmgr-low"),
						connMgrHi:           ctx.Int("libp2p-connmgr-high"),
						connMgrGrace:        ctx.Duration("libp2p-connmgr-grace"),
						maxMemory:           ctx.Uint64("libp2p-max-memory"),
						maxFD:               ctx.Int("libp2p-max-fd"),

						tracingAuth:      ctx.String("tracing-auth"),
						samplingFraction: ctx.Float64("sampling-fraction"),

						autoConf: autoConfConfig{
							enabled:         ctx.Bool("autoconf"),
							url:             ctx.String("autoconf-url"),
							refreshInterval: ctx.Duration("autoconf-refresh"),
							cacheDir:        filepath.Join(ctx.String("datadir"), ".autoconf-cache"),
						},
					}

					fmt.Printf("Starting %s %s\n", name, version)

					fmt.Printf("SOMEGUY_DHT = %s\n", cfg.dhtType)
					printIfListConfigured("SOMEGUY_PROVIDER_ENDPOINTS = ", cfg.contentEndpoints)
					printIfListConfigured("SOMEGUY_PEER_ENDPOINTS = ", cfg.peerEndpoints)
					printIfListConfigured("SOMEGUY_IPNS_ENDPOINTS = ", cfg.ipnsEndpoints)

					if len(cfg.blockProviderEndpoints) > 0 && len(cfg.blockProviderPeerIDs) == 0 {
						fmt.Printf("SOMEGUY_HTTP_BLOCK_PROVIDER_ENDPOINTS is set but SOMEGUY_HTTP_BLOCK_PROVIDER_PEERIDS were not. PeerIDs will be autogenerated.\n")
						// Generate synthetic PeerIDs for HTTP block providers. These are deterministic
						// identifiers based on endpoint URLs, used solely for routing system compatibility.
						// Since HTTP providers use trustless gateway protocol, these PeerIDs are never
						// used for cryptographic operations or libp2p authentication.
						for i := 0; i < len(cfg.blockProviderEndpoints); i++ {
							digest := sha256.Sum256([]byte(cfg.blockProviderEndpoints[i]))
							mh, err := multihash.Encode((digest[:]), multihash.SHA2_256)
							if err != nil {
								return err
							}
							p, err := peer.IDFromBytes(mh)
							if err != nil {
								return err
							}
							cfg.blockProviderPeerIDs = append(cfg.blockProviderPeerIDs, p.String())
						}
					}

					printIfListConfigured("SOMEGUY_HTTP_BLOCK_PROVIDER_ENDPOINTS = ", cfg.blockProviderEndpoints)
					printIfListConfigured("SOMEGUY_HTTP_BLOCK_PROVIDER_PEERIDS = ", cfg.blockProviderPeerIDs)

					return start(ctx.Context, cfg)
				},
			},
			{
				Name:  "ask",
				Usage: "Query a Delegated Routing V1 server",
				Flags: []cli.Flag{
					&cli.StringFlag{
						Name:  "endpoint",
						Value: autoconf.AutoPlaceholder,
						Usage: "Delegated Routing V1 endpoint to query",
					},
					&cli.BoolFlag{
						Name:  "pretty",
						Value: false,
						Usage: "pretty-print output (may omit some fields)",
					},
					&cli.StringFlag{
						Name:    "datadir",
						Value:   "",
						EnvVars: []string{"SOMEGUY_DATADIR"},
						Usage:   "Directory for persistent data (autoconf cache)",
					},
					&cli.BoolFlag{
						Name:    "autoconf",
						Value:   true,
						EnvVars: []string{"SOMEGUY_AUTOCONF"},
						Usage:   "Enable autoconf for bootstrap, DNS resolvers, and HTTP routers",
					},
					&cli.StringFlag{
						Name:    "autoconf-url",
						Value:   "https://conf.ipfs-mainnet.org/autoconf.json",
						EnvVars: []string{"SOMEGUY_AUTOCONF_URL"},
						Usage:   "URL to fetch autoconf data from",
					},
					&cli.DurationFlag{
						Name:    "autoconf-refresh",
						Value:   24 * time.Hour,
						EnvVars: []string{"SOMEGUY_AUTOCONF_REFRESH"},
						Usage:   "How often to refresh autoconf data",
					},
				},
				Subcommands: []*cli.Command{
					{
						Name:      "findprovs",
						Usage:     "Find providers of a given CID",
						ArgsUsage: "<cid>",
						Action: func(ctx *cli.Context) error {
							if ctx.NArg() != 1 {
								return errors.New("invalid command, see help")
							}
							cidStr := ctx.Args().Get(0)
							c, err := cid.Parse(cidStr)
							if err != nil {
								return err
							}

							cfg := &config{
								dhtType:          "none",
								contentEndpoints: []string{ctx.String("endpoint")},
								autoConf: autoConfConfig{
									enabled:         ctx.Bool("autoconf"),
									url:             ctx.String("autoconf-url"),
									refreshInterval: ctx.Duration("autoconf-refresh"),
									cacheDir:        filepath.Join(ctx.String("datadir"), ".autoconf-cache"),
								},
							}

							autoConf, err := startAutoConf(ctx.Context, cfg)
							if err != nil {
								logger.Error(err.Error())
							}

							if err = expandDelegatedRoutingEndpoints(cfg, autoConf); err != nil {
								return err
							}
							if len(cfg.contentEndpoints) == 0 {
								return errors.New("no delegated routing endpoint configured, use --endpoint to specify")
							}

							endPoint := cfg.contentEndpoints[0]
							logger.Debugf("delegated routing endpoint: %s", endPoint)

							return findProviders(ctx.Context, c, endPoint, ctx.Bool("pretty"))
						},
					},
					{
						Name:      "findpeers",
						Usage:     "Find a peer by peer ID",
						ArgsUsage: "<pid>",
						Action: func(ctx *cli.Context) error {
							if ctx.NArg() != 1 {
								return errors.New("invalid command, see help")
							}
							pidStr := ctx.Args().Get(0)
							pid, err := peer.Decode(pidStr)
							if err != nil {
								return err
							}
							cfg := &config{
								dhtType:          "none",
								contentEndpoints: []string{ctx.String("endpoint")},
								autoConf: autoConfConfig{
									enabled:         ctx.Bool("autoconf"),
									url:             ctx.String("autoconf-url"),
									refreshInterval: ctx.Duration("autoconf-refresh"),
									cacheDir:        filepath.Join(ctx.String("datadir"), ".autoconf-cache"),
								},
							}

							autoConf, err := startAutoConf(ctx.Context, cfg)
							if err != nil {
								logger.Error(err.Error())
							}

							if err = expandDelegatedRoutingEndpoints(cfg, autoConf); err != nil {
								return err
							}
							if len(cfg.contentEndpoints) == 0 {
								return errors.New("no delegated routing endpoint configured, use --endpoint to specify")
							}

							endPoint := cfg.contentEndpoints[0]
							logger.Debugf("delegated routing endpoint: %s", endPoint)

							return findPeers(ctx.Context, pid, endPoint, ctx.Bool("pretty"))
						},
					},
					{
						Name:      "getclosestpeers",
						Usage:     "Find DHT-closest peers to a key (CID or peer ID)",
						ArgsUsage: "<key>",
						Action: func(ctx *cli.Context) error {
							if ctx.NArg() != 1 {
								return errors.New("invalid command, see help")
							}
							keyStr := ctx.Args().Get(0)
							c, err := parseKey(keyStr)
							if err != nil {
								return err
							}
							return getClosestPeers(ctx.Context, c, ctx.String("endpoint"), ctx.Bool("pretty"))
						},
					},
					{
						Name:      "getipns",
						Usage:     "Get the value of an IPNS name",
						ArgsUsage: "<ipns-id>",
						Action: func(ctx *cli.Context) error {
							if ctx.NArg() != 1 {
								return errors.New("invalid command, see help")
							}
							nameStr := ctx.Args().Get(0)
							name, err := ipns.NameFromString(nameStr)
							if err != nil {
								return err
							}
							return getIPNS(ctx.Context, name, ctx.String("endpoint"), ctx.Bool("pretty"))
						},
					},
					{
						Name:      "putipns",
						Usage:     "Publish an IPNS record",
						ArgsUsage: "<ipns-id> <multibase-encoded-record>",
						Flags:     []cli.Flag{},
						Action: func(ctx *cli.Context) error {
							if ctx.NArg() != 2 {
								return errors.New("invalid command, see help")
							}
							nameStr := ctx.Args().Get(0)
							name, err := ipns.NameFromString(nameStr)
							if err != nil {
								return err
							}
							recordStr := ctx.Args().Get(1)
							_, recBytes, err := multibase.Decode(recordStr)
							if err != nil {
								return err
							}
							return putIPNS(ctx.Context, name, recBytes, ctx.String("endpoint"))
						},
					},
				},
			},
		},
	}

	err := app.Run(os.Args)
	if err != nil {
		log.Fatal(err)
	}
}

func printIfListConfigured(message string, list []string) {
	if len(list) > 0 {
		fmt.Printf(message+"%v\n", strings.Join(list, ", "))
	}
}

// parseKey parses a string that can be either a CID or a PeerID.
// It accepts the following formats:
//   - Arbitrary CIDs (e.g., bafkreidcd7frenco2m6ch7mny63wztgztv3q6fctaffgowkro6kljre5ei)
//   - CIDv1 with libp2p-key codec (e.g., bafzaajaiaejca...)
//   - Base58-encoded PeerIDs (e.g., 12D3KooW... or QmYyQ...)
//
// Returns the key as a CID. PeerIDs are converted to CIDv1 with libp2p-key codec.
func parseKey(keyStr string) (cid.Cid, error) {
	// Try parsing as PeerID first using peer.Decode
	// This handles legacy PeerID formats per:
	// https://github.com/libp2p/specs/blob/master/peer-ids/peer-ids.md#string-representation
	pid, pidErr := peer.Decode(keyStr)
	if pidErr == nil {
		return peer.ToCid(pid), nil
	}

	// Fall back to parsing as CID (handles arbitrary CIDs and CIDv1 libp2p-key format)
	c, cidErr := cid.Parse(keyStr)
	if cidErr == nil {
		return c, nil
	}

	return cid.Cid{}, fmt.Errorf("unable to parse as CID or PeerID: %w", errors.Join(cidErr, pidErr))
}
