# 🤷 Someguy

[![Official Part of IPFS Project](https://img.shields.io/badge/project-IPFS-blue.svg?style=flat-square)](https://ipfs.tech)
[![Discourse Forum](https://img.shields.io/discourse/posts?server=https%3A%2F%2Fdiscuss.ipfs.tech)](https://discuss.ipfs.tech)
[![Matrix](https://img.shields.io/matrix/ipfs-space%3Aipfs.io?server_fqdn=matrix.org)](https://matrix.to/#/#ipfs-space:ipfs.io)
[![CI](https://img.shields.io/github/actions/workflow/status/ipfs/someguy/go-test.yml?branch=main)](https://github.com/ipfs/someguy/actions)
[![Code Coverage](https://codecov.io/gh/ipfs/someguy/branch/main/graph/badge.svg?token=9eG7d8fbCB)](https://codecov.io/gh/ipfs/someguy)
[![GitHub Release](https://img.shields.io/github/v/release/ipfs/someguy?filter=!*rc*)](https://github.com/ipfs/someguy/releases)
[![Go Reference](https://pkg.go.dev/badge/github.com/ipfs/someguy.svg)](https://pkg.go.dev/github.com/ipfs/someguy)

Someguy is an [HTTP Delegated Routing V1](https://specs.ipfs.tech/routing/http-routing-v1/) server that proxies requests to the [Amino DHT](https://docs.ipfs.tech/concepts/glossary/#amino) and other [delegated routing servers](https://specs.ipfs.tech/routing/http-routing-v1/).

Someguy was the backend of `https://delegated-ipfs.dev/routing/v1` until 2026 Q3 (see [Maintainer Info](#maintainer-info)).

## Build

```bash
go build -o someguy
```

## Install

```bash
go install github.com/ipfs/someguy@latest
```

### Docker

Automated Docker container releases are available from the [Github container registry](https://github.com/ipfs/someguy/pkgs/container/someguy):

- 🟢 Releases
  - `latest` always points at the latest stable release
  - `vN.N.N` point at a specific [release tag](https://github.com/ipfs/someguy/releases)
- 🟠 Unreleased developer builds
  - `main-latest` always points at the `HEAD` of the `main` branch
  - `main-YYYY-DD-MM-GITSHA` points at a specific commit from the `main` branch
- ⚠️ Experimental, unstable builds
  - `staging-latest` always points at the `HEAD` of the `staging` branch
  - `staging-YYYY-DD-MM-GITSHA` points at a specific commit from the `staging` branch
  - This tag is used by developers for internal testing, not intended for end users

When using Docker, pass configuration via `-e`:
```console
$ docker pull ghcr.io/ipfs/someguy:main-latest
$ docker run --rm -it --net=host ghcr.io/ipfs/someguy:main-latest
```

See [`/docs/environment-variables.md`](./docs/environment-variables.md).

## Usage

Run `someguy` as a client or as a server.

### Server

Start the server with `someguy start`. By default it proxies requests to the [IPFS Amino DHT](https://blog.ipfs.tech/2023-09-amino-refactoring/) and other [Delegated Routing V1](https://specs.ipfs.tech/routing/http-routing-v1/) servers.

For more details, run `someguy start --help`.

### Client

To query an existing server without running one yourself, use `someguy ask <subcommand>` to look up a provider, peer, or IPNS record.

For more details, run `someguy ask --help`.

### AutoConf

Automatic configuration of bootstrap peers and delegated routing endpoints. When enabled (default), Someguy replaces the `auto` placeholder with network-recommended values fetched from a remote URL.

Configuration:
- `--autoconf` / [`SOMEGUY_AUTOCONF`](docs/environment-variables.md#someguy_autoconf)
- `--autoconf-url` / [`SOMEGUY_AUTOCONF_URL`](docs/environment-variables.md#someguy_autoconf_url)
- `--autoconf-refresh` / [`SOMEGUY_AUTOCONF_REFRESH`](docs/environment-variables.md#someguy_autoconf_refresh)

Endpoint flags (default to `auto`):
- `--provider-endpoints` / [`SOMEGUY_PROVIDER_ENDPOINTS`](docs/environment-variables.md#someguy_provider_endpoints)
- `--peer-endpoints` / [`SOMEGUY_PEER_ENDPOINTS`](docs/environment-variables.md#someguy_peer_endpoints)
- `--ipns-endpoints` / [`SOMEGUY_IPNS_ENDPOINTS`](docs/environment-variables.md#someguy_ipns_endpoints)

To use custom endpoints instead of `auto`:
```bash
someguy start --ipns-endpoints https://example.com
```

See [environment-variables.md](docs/environment-variables.md) for URL formats and configuration details.

## Documentation

- [environment-variables.md](docs/environment-variables.md): all config flags and environment variables
- [peer-address-caching.md](docs/peer-address-caching.md): how `/providers` and `/peers` cache and refresh peer addresses, and the trade-offs behind what someguy deliberately does not do
- [response-streaming.md](docs/response-streaming.md): NDJSON streaming contract, the timeout budget, and traps that break streaming
- [dnsaddr-resolution.md](docs/dnsaddr-resolution.md): why `/dnsaddr` is resolved before `filter-addrs`, and how it is bounded
- [metrics.md](docs/metrics.md): Prometheus metrics
- [tracing.md](docs/tracing.md): OpenTelemetry tracing

## Deployment

For self-hosting, run the [prebuilt Docker image](#docker).

## Release

1. Create a PR from branch `release-vX.Y.Z` against `main` that:
   1. Updates [`CHANGELOG.md`](CHANGELOG.md) with entries for the current release
   2. Updates the [`version.json`](./version.json) file
2. Once the release checker creates a draft release, copy-paste the changelog into the draft
3. Merge the PR; the release workflow tags and publishes automatically

## Maintainer Info

> [!IMPORTANT]
> There is no dedicated maintainer at the moment.
>
> After Protocol Labs nucleation, the [Shipyard](https://ipshipyard.com/) team maintained this project in 2024, 2025 and 2026. Shipyard's IPFS maintenance work [ended with 2026 Q3](https://ipshipyard.com/blog/2026-the-end-of-ipfs-at-shipyard/).
>
> Bring support and transition questions to the [community forum](https://discuss.ipfs.tech/).

## License

Dual-licensed under [MIT + Apache 2.0](LICENSE.md)
