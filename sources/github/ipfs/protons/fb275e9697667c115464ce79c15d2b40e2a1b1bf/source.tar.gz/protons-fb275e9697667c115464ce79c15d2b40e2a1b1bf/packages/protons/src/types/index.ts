import type { Field } from '../fields/field.ts'
import type { Flags } from '../index.ts'
import type { MessageDef } from './message.ts'
import type { Module } from './module.ts'

export interface TypeCodec {
  encode: string
  decode: string
}

export interface Type {
  jsType: TypeCodec
  pbType: string
  init(module: Module): void
  getDecoder(field: Field, indent?: string, reader?: string): string
  getStreamingDecoder(field: Field, prefix: string, indent?: string, reader?: string): string
  getEncoder(field: Field, accessor: string): string
  getValueTest(field: Field, accessor: string): string
}

export interface Parent {
  flags: Flags
  findType (type: string, jsOverride?: 'string' | 'number'): Type
  addImport (module: string, symbol: string, alias?: string): void
  addTypeImport (module: string, symbol: string, alias?: string): void
  addEslintIgnore (rule: string): void
}

export interface Message extends Parent {
  def: MessageDef
}
