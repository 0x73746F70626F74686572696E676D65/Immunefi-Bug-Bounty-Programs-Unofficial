## [protons-v10.0.5](https://github.com/ipfs/protons/compare/protons-10.0.4...protons-10.0.5) (2026-09-18)

### Bug Fixes

* support packed option in proto3 ([#210](https://github.com/ipfs/protons/issues/210)) ([3d6c248](https://github.com/ipfs/protons/commit/3d6c2484cf1a8b8a7988d60f35911aaa2c2c5479))

## [protons-v10.0.4](https://github.com/ipfs/protons/compare/protons-10.0.3...protons-10.0.4) (2026-09-18)

### Bug Fixes

* document message naming conventions ([#209](https://github.com/ipfs/protons/issues/209)) ([c1e3bcb](https://github.com/ipfs/protons/commit/c1e3bcb31e6be41101916999264f6d78ca14acce)), closes [#64](https://github.com/ipfs/protons/issues/64)

## [protons-v10.0.3](https://github.com/ipfs/protons/compare/protons-10.0.2...protons-10.0.3) (2026-09-18)

### Bug Fixes

* add warning for incorrect packed option usage ([#208](https://github.com/ipfs/protons/issues/208)) ([1fb677f](https://github.com/ipfs/protons/commit/1fb677f8e226940f63463fa8fae7ebb7d4ddf276))

## [protons-v10.0.2](https://github.com/ipfs/protons/compare/protons-10.0.1...protons-10.0.2) (2026-09-18)

### Bug Fixes

* only declare decode opts if used ([#206](https://github.com/ipfs/protons/issues/206)) ([545ca31](https://github.com/ipfs/protons/commit/545ca31f382fbed8bf2e296cc46c18c79b221b53)), closes [#130](https://github.com/ipfs/protons/issues/130)

## [protons-v10.0.1](https://github.com/ipfs/protons/compare/protons-10.0.0...protons-10.0.1) (2026-09-18)

### Bug Fixes

* update sibling deps ([#207](https://github.com/ipfs/protons/issues/207)) ([ff1aade](https://github.com/ipfs/protons/commit/ff1aade226d907b67f4167be4fa9ed274eb09399))

## [protons-v10.0.0](https://github.com/ipfs/protons/compare/protons-9.1.2...protons-10.0.0) (2026-09-18)

### ⚠ BREAKING CHANGES

* non-string/byte scalar fields are now packed by default in proto3 or later files as per the protobuf spec - annotate fields with `[features.repeated_field_encoding=EXPANDED]` for the previous behavior
* definitions will need to be regenerated

### Features

* accept any Uint8Array for encoding ([#203](https://github.com/ipfs/protons/issues/203)) ([6556bc4](https://github.com/ipfs/protons/commit/6556bc404669cbc66f93af4b36f10b02cc33f11d))
* support packed fields ([#205](https://github.com/ipfs/protons/issues/205)) ([35bd501](https://github.com/ipfs/protons/commit/35bd50106fa4d3b4f84d3b10aee8b9bd9006b651)), closes [#24](https://github.com/ipfs/protons/issues/24)

## [protons-v9.1.2](https://github.com/ipfs/protons/compare/protons-9.1.1...protons-9.1.2) (2026-09-17)

### Dependencies

* bump protobufjs from 7.6.5 to 8.7.1 ([#200](https://github.com/ipfs/protons/issues/200)) ([a19225b](https://github.com/ipfs/protons/commit/a19225b93481bf645927e162a72c060e99b61046))

## [protons-v9.1.1](https://github.com/ipfs/protons/compare/protons-9.1.0...protons-9.1.1) (2026-09-14)

### Bug Fixes

* stream function argument order ([#202](https://github.com/ipfs/protons/issues/202)) ([bc9c0a2](https://github.com/ipfs/protons/commit/bc9c0a25197933eefb34e0242728ed8dff1ea075))

## [protons-v9.1.0](https://github.com/ipfs/protons/compare/protons-9.0.2...protons-9.1.0) (2026-09-10)

### Features

* generate start/end events for sub messages ([#201](https://github.com/ipfs/protons/issues/201)) ([c879d0c](https://github.com/ipfs/protons/commit/c879d0cb6719defdfbb51d5406e6acf7daafcc10))

## [protons-v9.0.2](https://github.com/ipfs/protons/compare/protons-9.0.1...protons-9.0.2) (2026-07-01)

### Bug Fixes

* add backing buffer type to Uint8Array fields ([#194](https://github.com/ipfs/protons/issues/194)) ([1369612](https://github.com/ipfs/protons/commit/1369612f7ddce7f005cca8041028ed49f15aac9b))

## [protons-v9.0.1](https://github.com/ipfs/protons/compare/protons-9.0.0...protons-9.0.1) (2026-05-07)

### Bug Fixes

* update sibling deps ([20f3e99](https://github.com/ipfs/protons/commit/20f3e99177a880b7e4d2cca97c37cd6686567b49))

## [protons-v9.0.0](https://github.com/ipfs/protons/compare/protons-8.1.2...protons-9.0.0) (2026-05-07)

### ⚠ BREAKING CHANGES

* Returned `Uint8Array`s are now generic

### Bug Fixes

* uint8arrays are generic ([#170](https://github.com/ipfs/protons/issues/170)) ([048a855](https://github.com/ipfs/protons/commit/048a8552d310dea51f7b0a0c0397c50ff2611d55))

## [protons-v8.1.2](https://github.com/ipfs/protons/compare/protons-8.1.1...protons-8.1.2) (2026-05-07)

### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#167](https://github.com/ipfs/protons/issues/167)) ([b38cb94](https://github.com/ipfs/protons/commit/b38cb9443b9046db74fb5bdd73b8c7c7486a1cdf))

## [protons-v8.1.1](https://github.com/ipfs/protons/compare/protons-8.1.0...protons-8.1.1) (2026-03-26)

### Bug Fixes

* check collection size before iteration ([#161](https://github.com/ipfs/protons/issues/161)) ([860a874](https://github.com/ipfs/protons/commit/860a874203749ec148cdae7417572b69a477d19f))

## [protons-v8.1.0](https://github.com/ipfs/protons/compare/protons-8.0.2...protons-8.1.0) (2026-03-26)

### Features

* support js type overrides for map keys and values ([#160](https://github.com/ipfs/protons/issues/160)) ([5ed4a54](https://github.com/ipfs/protons/commit/5ed4a547108e491248e57fa4658b1d86cdd9270b))

## [protons-v8.0.2](https://github.com/ipfs/protons/compare/protons-8.0.1...protons-8.0.2) (2026-03-24)

### Bug Fixes

* simplify generated code ([8810af6](https://github.com/ipfs/protons/commit/8810af61a87c0feda03b9185d44423a4490c6d77))

## [protons-v8.0.1](https://github.com/ipfs/protons/compare/protons-8.0.0...protons-8.0.1) (2026-03-24)

### Bug Fixes

* update sibling versions ([2cd6d52](https://github.com/ipfs/protons/commit/2cd6d521d4f2d8859728af6799e0aeb08068f966))

## [protons-v8.0.0](https://github.com/ipfs/protons/compare/protons-7.7.0...protons-8.0.0) (2026-03-24)

### ⚠ BREAKING CHANGES

* add streaming decode (#158)

### Features

* add streaming decode ([#158](https://github.com/ipfs/protons/issues/158)) ([36e915e](https://github.com/ipfs/protons/commit/36e915e8fe8e2ceaac507ee5f6a11669f2c05bbc))

### Bug Fixes

* update project config ([#159](https://github.com/ipfs/protons/issues/159)) ([5f574a0](https://github.com/ipfs/protons/commit/5f574a0161305fd4093a17936255c9b549ad9065))

### Trivial Changes

* import using .ts ([#157](https://github.com/ipfs/protons/issues/157)) ([604fd58](https://github.com/ipfs/protons/commit/604fd5849e40aa6268aedc698a88f4accc55c468))

### Dependencies

* bump meow from 13.2.0 to 14.1.0 ([#155](https://github.com/ipfs/protons/issues/155)) ([62079bf](https://github.com/ipfs/protons/commit/62079bf576e71c38d1959312beac113f67111afe))

## protons [7.5.0](https://github.com/ipfs/protons/compare/protons-7.4.0...protons-7.5.0) (2024-02-02)


### Features

* allow limiting nested repeating fields ([#129](https://github.com/ipfs/protons/issues/129)) ([a81f997](https://github.com/ipfs/protons/commit/a81f997a490cdcc7c59d00fe5e8b666e54230745))



### Dependencies

* **protons-runtime:** upgraded to 5.4.0

## protons [7.4.0](https://github.com/ipfs/protons/compare/protons-v7.3.4...protons-7.4.0) (2024-01-31)


### Features

* runtime size limits for arrays and maps ([#128](https://github.com/ipfs/protons/issues/128)) ([a737d05](https://github.com/ipfs/protons/commit/a737d05d8cd8b22568ff489d07c9e4c824cb4f40))


### Trivial Changes

* update publish config ([942e050](https://github.com/ipfs/protons/commit/942e050bc0c14d3c8177da218f178d8dab1c0333))



### Dependencies

* **protons-runtime:** upgraded to 5.3.0

## [protons-v7.3.4](https://github.com/ipfs/protons/compare/protons-v7.3.3...protons-v7.3.4) (2024-01-08)


### Dependencies

* bump aegir from 41.3.5 to 42.0.1 ([#127](https://github.com/ipfs/protons/issues/127)) ([02eafe9](https://github.com/ipfs/protons/commit/02eafe9abc565d7719ed54b64c6ae17a55ebf235))

## [protons-v7.3.3](https://github.com/ipfs/protons/compare/protons-v7.3.2...protons-v7.3.3) (2023-12-30)


### Dependencies

* bump uint8arrays from 4.0.10 to 5.0.1 ([#126](https://github.com/ipfs/protons/issues/126)) ([1e5a0b0](https://github.com/ipfs/protons/commit/1e5a0b0608b4395283c7571353918bacc3a3bd63))

## [protons-v7.3.2](https://github.com/ipfs/protons/compare/protons-v7.3.1...protons-v7.3.2) (2023-12-30)


### Dependencies

* bump meow from 12.1.1 to 13.0.0 ([#125](https://github.com/ipfs/protons/issues/125)) ([2b356b8](https://github.com/ipfs/protons/commit/2b356b87619cdcadbbcde6f4d8c4c35cb252d970))

## [protons-v7.3.1](https://github.com/ipfs/protons/compare/protons-v7.3.0...protons-v7.3.1) (2023-11-22)


### Bug Fixes

* use uint8arrays alloc for new buffers ([#123](https://github.com/ipfs/protons/issues/123)) ([d1bfc94](https://github.com/ipfs/protons/commit/d1bfc948940dbff3e5fe25ab09d7df9d8367d191))

## [protons-v7.3.0](https://github.com/ipfs/protons/compare/protons-v7.2.1...protons-v7.3.0) (2023-11-01)


### Features

* add custom protons options for limiting list/map sizes ([#120](https://github.com/ipfs/protons/issues/120)) ([a5ba36b](https://github.com/ipfs/protons/commit/a5ba36bbfbfb1d2bded026e0da1251e02defacdd)), closes [#113](https://github.com/ipfs/protons/issues/113)

## [protons-v7.2.1](https://github.com/ipfs/protons/compare/protons-v7.2.0...protons-v7.2.1) (2023-10-23)


### Tests

* regenerate custom options ([768573b](https://github.com/ipfs/protons/commit/768573b5f607fb80b2b1e94205b848b72cbc85e4))

## [protons-v7.2.0](https://github.com/ipfs/protons/compare/protons-v7.1.0...protons-v7.2.0) (2023-10-23)


### Features

* support jstype custom options ([#117](https://github.com/ipfs/protons/issues/117)) ([ba35475](https://github.com/ipfs/protons/commit/ba354756bbec60055bbeb4a6ee5bc3ab73267312)), closes [#112](https://github.com/ipfs/protons/issues/112)

## [protons-v7.1.0](https://github.com/ipfs/protons/compare/protons-v7.0.7...protons-v7.1.0) (2023-10-23)


### Features

* add strict option to CLI ([#119](https://github.com/ipfs/protons/issues/119)) ([8c039c5](https://github.com/ipfs/protons/commit/8c039c50c0085bd496d684ffc42b30ae786f4a52))


### Trivial Changes

* update project config ([c54b7ac](https://github.com/ipfs/protons/commit/c54b7acbc9ac3839d1ef2d2653f1d19b5a0fdbf4))

## [protons-v7.0.7](https://github.com/ipfs/protons/compare/protons-v7.0.6...protons-v7.0.7) (2023-10-13)


### Bug Fixes

* port protobuf reader/writer to ts ([#60](https://github.com/ipfs/protons/issues/60)) ([d101804](https://github.com/ipfs/protons/commit/d101804674e6ba42c28505fc8fdf605020ac319e))

## [protons-v7.0.6](https://github.com/ipfs/protons/compare/protons-v7.0.5...protons-v7.0.6) (2023-10-12)


### Dependencies

* bump aegir from 40.0.13 to 41.0.4 ([#116](https://github.com/ipfs/protons/issues/116)) ([b95e988](https://github.com/ipfs/protons/commit/b95e9881a5c842b3c70a40d6d93b4aa5219b8aee))

## [protons-v7.0.5](https://github.com/ipfs/protons/compare/protons-v7.0.4...protons-v7.0.5) (2023-08-05)


### Dependencies

* bump aegir from 39.0.13 to 40.0.8 ([#108](https://github.com/ipfs/protons/issues/108)) ([8b54c80](https://github.com/ipfs/protons/commit/8b54c8097683b055736a8e431728422cedf82697))

## [protons-v7.0.4](https://github.com/ipfs/protons/compare/protons-v7.0.3...protons-v7.0.4) (2023-06-30)


### Dependencies

* bump meow from 11.0.0 to 12.0.1 ([#97](https://github.com/ipfs/protons/issues/97)) ([33250df](https://github.com/ipfs/protons/commit/33250df60fc3f613126fe3a8b1043547e2d6779e))

## [protons-v7.0.3](https://github.com/ipfs/protons/compare/protons-v7.0.2...protons-v7.0.3) (2023-06-30)


### Dependencies

* bump aegir from 38.1.8 to 39.0.13 ([#104](https://github.com/ipfs/protons/issues/104)) ([912e0e6](https://github.com/ipfs/protons/commit/912e0e627fbe8047b56cdcd5d26cb81bf5700bf8))

## [protons-v7.0.2](https://github.com/ipfs/protons/compare/protons-v7.0.1...protons-v7.0.2) (2023-02-08)


### Bug Fixes

* remove writing default values ([#88](https://github.com/ipfs/protons/issues/88)) ([078c62f](https://github.com/ipfs/protons/commit/078c62f569fab2163ccb5772d796b56f5e7adf37))

## [protons-v7.0.1](https://github.com/ipfs/protons/compare/protons-v7.0.0...protons-v7.0.1) (2023-02-08)


### Bug Fixes

* treat nested enums as enums and not messages ([#87](https://github.com/ipfs/protons/issues/87)) ([3af689b](https://github.com/ipfs/protons/commit/3af689b08975aa686b23beb33622264af18b4697))

## [protons-v7.0.0](https://github.com/ipfs/protons/compare/protons-v6.1.3...protons-v7.0.0) (2023-02-02)


### ⚠ BREAKING CHANGES

* singular fields should be optional to write (#83)

### Bug Fixes

* singular fields should be optional to write ([#83](https://github.com/ipfs/protons/issues/83)) ([229afbc](https://github.com/ipfs/protons/commit/229afbcb38ba0edc0622d4c2e97847462b439dc8)), closes [#42](https://github.com/ipfs/protons/issues/42)
* sort imports ([#84](https://github.com/ipfs/protons/issues/84)) ([6f796f1](https://github.com/ipfs/protons/commit/6f796f1e7dfd631314f9a1df534eabd96dd1528c))
* update sibling dep versions ([a77d027](https://github.com/ipfs/protons/commit/a77d027e055e442f4d1b004ebc1203e52292e7ed))


### Trivial Changes

* move bad fixtures to separate directory ([#82](https://github.com/ipfs/protons/issues/82)) ([76aa198](https://github.com/ipfs/protons/commit/76aa19882cd9fb4fa918dda6701b1f7b4ad740a4))

## [protons-v6.1.3](https://github.com/ipfs/protons/compare/protons-v6.1.2...protons-v6.1.3) (2023-01-31)


### Bug Fixes

* throw when .proto is empty ([#81](https://github.com/ipfs/protons/issues/81)) ([ed392cb](https://github.com/ipfs/protons/commit/ed392cb84847fe0be8b96c582eaca0d99d4a40d1))

## [protons-v6.1.2](https://github.com/ipfs/protons/compare/protons-v6.1.1...protons-v6.1.2) (2023-01-31)


### Bug Fixes

* throw when unsupported fields are detected ([#80](https://github.com/ipfs/protons/issues/80)) ([8108875](https://github.com/ipfs/protons/commit/81088755804629e68a0a51d3e4037e58253134fc)), closes [#34](https://github.com/ipfs/protons/issues/34)

## [protons-v6.1.1](https://github.com/ipfs/protons/compare/protons-v6.1.0...protons-v6.1.1) (2023-01-17)


### Bug Fixes

* support empty messages ([#78](https://github.com/ipfs/protons/issues/78)) ([8a02910](https://github.com/ipfs/protons/commit/8a0291096c6b9aab9050bf8b35958015d99e9470))

## [protons-v6.1.0](https://github.com/ipfs/protons/compare/protons-v6.0.2...protons-v6.1.0) (2023-01-12)


### Features

* add support for maps ([#75](https://github.com/ipfs/protons/issues/75)) ([e8dfc0a](https://github.com/ipfs/protons/commit/e8dfc0a6a7700225e2cf9c6d2e82d17979da1549))

## [protons-v6.0.2](https://github.com/ipfs/protons/compare/protons-v6.0.1...protons-v6.0.2) (2023-01-12)


### Dependencies

* remove lerna, update aegir ([#76](https://github.com/ipfs/protons/issues/76)) ([83a24f2](https://github.com/ipfs/protons/commit/83a24f2a924704bd4a356b6f8a3195245d8b1062))

## [protons-v6.0.1](https://github.com/ipfs/protons/compare/protons-v6.0.0...protons-v6.0.1) (2022-10-14)


### Dependencies

* bump meow from 10.1.5 to 11.0.0 ([#67](https://github.com/ipfs/protons/issues/67)) ([d489fd3](https://github.com/ipfs/protons/commit/d489fd35b8864fcc675da29f24b6a01f0c56d39d))
* bump uint8arrays from 3.1.1 to 4.0.2 ([#71](https://github.com/ipfs/protons/issues/71)) ([b537e92](https://github.com/ipfs/protons/commit/b537e920a6704f005ea2b7bcef49741a9c3deb96))

## [protons-v6.0.0](https://github.com/ipfs/protons/compare/protons-v5.1.0...protons-v6.0.0) (2022-10-12)


### ⚠ BREAKING CHANGES

* ts definitions will need to be generated from `.proto` files - singular message fields have become optional as message fields are always optional in proto3

### Bug Fixes

* adhere more closely to the language guide for proto3 default values ([#66](https://github.com/ipfs/protons/issues/66)) ([406d775](https://github.com/ipfs/protons/commit/406d7757d490eb0dbac93343d6622dd689ff0707)), closes [#43](https://github.com/ipfs/protons/issues/43)


### Dependencies

* update sibling dependencies ([b1316fa](https://github.com/ipfs/protons/commit/b1316fa23b6fa623bc438c6cf51c53f94759e199))

## [protons-v5.1.0](https://github.com/ipfs/protons/compare/protons-v5.0.0...protons-v5.1.0) (2022-08-11)


### Features

* define default types during decode ([#62](https://github.com/ipfs/protons/issues/62)) ([6453809](https://github.com/ipfs/protons/commit/64538091f7339f285ab6efbb0e18054970e00f33)), closes [#43](https://github.com/ipfs/protons/issues/43)

## [protons-v5.0.0](https://github.com/ipfs/protons/compare/protons-v4.0.3...protons-v5.0.0) (2022-08-10)


### ⚠ BREAKING CHANGES

* the exported types of `protons-runtime` have changed and protobuf encoders/decoders will need to be regenerated

### Bug Fixes

* increase encoding/decoding performance ([#58](https://github.com/ipfs/protons/issues/58)) ([9987b97](https://github.com/ipfs/protons/commit/9987b97cc6910dd67152c3a9c0941ae0ab0a8b9a))


### Trivial Changes

* update sibling deps ([7568283](https://github.com/ipfs/protons/commit/756828339bc1ad3fae784b28d7d218bbc55c3518))

## [protons-v4.0.3](https://github.com/ipfs/protons/compare/protons-v4.0.2...protons-v4.0.3) (2022-08-04)


### Bug Fixes

* tidy up formatting of generated code ([#57](https://github.com/ipfs/protons/issues/57)) ([387c9e9](https://github.com/ipfs/protons/commit/387c9e94abf477dbb1553295b7ac3054a82bf2ec))

## [protons-v4.0.2](https://github.com/ipfs/protons/compare/protons-v4.0.1...protons-v4.0.2) (2022-08-04)


### Bug Fixes

* single instance codec ([#55](https://github.com/ipfs/protons/issues/55)) ([66d9387](https://github.com/ipfs/protons/commit/66d9387dc32c79651873b8436391ae30125ec201)), closes [#51](https://github.com/ipfs/protons/issues/51)

## [protons-v4.0.1](https://github.com/ipfs/protons/compare/protons-v4.0.0...protons-v4.0.1) (2022-07-30)


### Bug Fixes

* use uint8-varint, byte-accesor and longbits modules ([#56](https://github.com/ipfs/protons/issues/56)) ([66d72f5](https://github.com/ipfs/protons/commit/66d72f50ca3733b97efa5155d3cdcb33ec531d4a))

## [protons-v4.0.0](https://github.com/ipfs/protons/compare/protons-v3.0.5...protons-v4.0.0) (2022-07-28)


### ⚠ BREAKING CHANGES

* Uses Uint8ArrayList v2

### Features

* support no-copy serialization ([#54](https://github.com/ipfs/protons/issues/54)) ([caa0d71](https://github.com/ipfs/protons/commit/caa0d71b60367f2f3551688ad09fd695840e0852))


### Bug Fixes

* update project config ([3199131](https://github.com/ipfs/protons/commit/3199131f1f199bcb57fcf1e7aba4ca0b6d9207db))


### Trivial Changes

* update sibling dependencies [skip ci] ([c9291e0](https://github.com/ipfs/protons/commit/c9291e03b3b6a12140a5aa62a30bd94eac559fad))

## [protons-v3.0.5](https://github.com/ipfs/protons/compare/protons-v3.0.4...protons-v3.0.5) (2022-07-28)


### Bug Fixes

* use CLI flag `--output` ([#46](https://github.com/ipfs/protons/issues/46)) ([58dc0ba](https://github.com/ipfs/protons/commit/58dc0baed9fdf4ea65f0df8fde0875cc5f210c50))

## [protons-v3.0.4](https://github.com/ipfs/protons/compare/protons-v3.0.3...protons-v3.0.4) (2022-05-10)


### Bug Fixes

* encode enum values ([#30](https://github.com/ipfs/protons/issues/30)) ([676c01d](https://github.com/ipfs/protons/commit/676c01dae7ff5b4d3985113573079ba605d83ef6))

## [protons-v3.0.3](https://github.com/ipfs/protons/compare/protons-v3.0.2...protons-v3.0.3) (2022-04-10)


### Bug Fixes

* remove redundant defs and declare codec return type ([#28](https://github.com/ipfs/protons/issues/28)) ([c3ea5ec](https://github.com/ipfs/protons/commit/c3ea5ec9101e37d8ac0437eb22ac0b4eeeb14eb7))

## [protons-v3.0.2](https://github.com/ipfs/protons/compare/protons-v3.0.1...protons-v3.0.2) (2022-04-08)


### Bug Fixes

* update aegir, make codec creation dynamic ([#26](https://github.com/ipfs/protons/issues/26)) ([ecc46cc](https://github.com/ipfs/protons/commit/ecc46ccad90696c4d5cda6b2cb1db723770577d0))


### Trivial Changes

* update readme ([#27](https://github.com/ipfs/protons/issues/27)) ([0ccb1a3](https://github.com/ipfs/protons/commit/0ccb1a36766e620eed2fb65973ff2d6c7854caf9))

## [protons-v3.0.1](https://github.com/ipfs/protons/compare/protons-v3.0.0...protons-v3.0.1) (2022-03-31)


### Trivial Changes

* remove long dep ([#22](https://github.com/ipfs/protons/issues/22)) ([8795507](https://github.com/ipfs/protons/commit/879550710b846f2448db646ba69e5938bbad8aa0))
* update readme to remove breaking character ([#21](https://github.com/ipfs/protons/issues/21)) ([023c29b](https://github.com/ipfs/protons/commit/023c29bf1839794e9daaa890b3780e3c70612ea4))

## [protons-v3.0.0](https://github.com/ipfs/protons/compare/protons-v2.0.3...protons-v3.0.0) (2022-03-31)


### ⚠ BREAKING CHANGES

* This module is now ESM only

### Features

* transpile to ts ([#17](https://github.com/ipfs/protons/issues/17)) ([74d3b7a](https://github.com/ipfs/protons/commit/74d3b7abf1e857f7320c100734e797855ea728c1))


### Trivial Changes

* update protons-runtime dep ([#19](https://github.com/ipfs/protons/issues/19)) ([e119076](https://github.com/ipfs/protons/commit/e119076f82e735a8e991cc74505e255523f83bea))
