import { decodeMessage, encodeMessage, enumeration, message, streamMessage } from 'protons-runtime'
import type { Codec, DecodeOptions } from 'protons-runtime'
import type { Uint8ArrayList } from 'uint8arraylist'

export enum EnumType {
  Val1 = 'Val1',
  Val2 = 'Val2'
}

enum __EnumTypeValues {
  Val1 = 0,
  Val2 = 1
}

export namespace EnumType {
  export const codec = (): Codec<EnumType, EnumType> => {
    return enumeration<EnumType>(__EnumTypeValues)
  }
}

export interface OneOfMessage {
  fieldOne?: string
  fieldTwo?: string
  fieldThree?: EnumType
  fieldFour?: EnumType
  fieldFive: string
}

export interface OneOfMessageInput {
  fieldOne?: string
  fieldTwo?: string
  fieldThree?: EnumType
  fieldFour?: EnumType
  fieldFive?: string
}

export namespace OneOfMessage {
  let _codec: Codec<OneOfMessage, OneOfMessageInput>

  export const codec = (): Codec<OneOfMessage, OneOfMessageInput> => {
    if (_codec == null) {
      _codec = message<OneOfMessage, OneOfMessageInput>((obj, w, opts = {}) => {
        if (opts.lengthDelimited !== false) {
          w.fork()
        }

        obj = { ...obj }

        if (obj.fieldTwo != null) {
          obj.fieldOne = undefined
        }

        if (obj.fieldOne != null) {
          obj.fieldTwo = undefined
        }

        if (obj.fieldFour != null) {
          obj.fieldThree = undefined
        }

        if (obj.fieldThree != null) {
          obj.fieldFour = undefined
        }

        if (obj.fieldOne != null) {
          w.uint32(10)
          w.string(obj.fieldOne)
        }

        if (obj.fieldTwo != null) {
          w.uint32(18)
          w.string(obj.fieldTwo)
        }

        if (obj.fieldThree != null) {
          w.uint32(24)
          EnumType.codec().encode(obj.fieldThree, w)
        }

        if (obj.fieldFour != null) {
          w.uint32(32)
          EnumType.codec().encode(obj.fieldFour, w)
        }

        if ((obj.fieldFive != null && obj.fieldFive !== '')) {
          w.uint32(42)
          w.string(obj.fieldFive)
        }

        if (opts.lengthDelimited !== false) {
          w.ldelim()
        }
      }, (r, length) => {
        const obj: any = {
          fieldFive: ''
        }

        const end = length == null ? r.len : r.pos + length

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              obj.fieldOne = r.string()
              break
            }
            case 2: {
              obj.fieldTwo = r.string()
              break
            }
            case 3: {
              obj.fieldThree = EnumType.codec().decode(r)
              break
            }
            case 4: {
              obj.fieldFour = EnumType.codec().decode(r)
              break
            }
            case 5: {
              obj.fieldFive = r.string()
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (obj.fieldTwo != null) {
          delete obj.fieldOne
        }

        if (obj.fieldOne != null) {
          delete obj.fieldTwo
        }

        if (obj.fieldFour != null) {
          delete obj.fieldThree
        }

        if (obj.fieldThree != null) {
          delete obj.fieldFour
        }

        return obj
      }, function * (r, length, prefix) {
        const end = length == null ? r.len : r.pos + length

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'start',
            message: 'OneOfMessage'
          }
        }

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              yield {
                field: `${prefix}fieldOne`,
                value: r.string()
              }
              break
            }
            case 2: {
              yield {
                field: `${prefix}fieldTwo`,
                value: r.string()
              }
              break
            }
            case 3: {
              yield {
                field: `${prefix}fieldThree`,
                value: EnumType.codec().decode(r)
              }
              break
            }
            case 4: {
              yield {
                field: `${prefix}fieldFour`,
                value: EnumType.codec().decode(r)
              }
              break
            }
            case 5: {
              yield {
                field: `${prefix}fieldFive`,
                value: r.string()
              }
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'end',
            message: 'OneOfMessage'
          }
        }
      })
    }

    return _codec
  }

  export interface OneOfMessageFieldOneFieldEvent {
    field: '.fieldOne'
    value: string
  }

  export interface OneOfMessageFieldTwoFieldEvent {
    field: '.fieldTwo'
    value: string
  }

  export interface OneOfMessageFieldThreeFieldEvent {
    field: '.fieldThree'
    value: EnumType
  }

  export interface OneOfMessageFieldFourFieldEvent {
    field: '.fieldFour'
    value: EnumType
  }

  export interface OneOfMessageFieldFiveFieldEvent {
    field: '.fieldFive'
    value: string
  }

  export function encode (obj: OneOfMessageInput): Uint8Array<ArrayBuffer> {
    return encodeMessage(obj, OneOfMessage.codec())
  }

  export function decode (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<OneOfMessage>): OneOfMessage {
    return decodeMessage(buf, OneOfMessage.codec(), opts)
  }

  export function stream (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<OneOfMessage>): Generator<OneOfMessageFieldOneFieldEvent | OneOfMessageFieldTwoFieldEvent | OneOfMessageFieldThreeFieldEvent | OneOfMessageFieldFourFieldEvent | OneOfMessageFieldFiveFieldEvent> {
    return streamMessage(buf, OneOfMessage.codec(), opts)
  }
}

export interface MessageWithoutOneOfs {
  fieldOne: string
  fieldTwo: string
  fieldThree: EnumType
  fieldFour: EnumType
  fieldFive: string
}

export interface MessageWithoutOneOfsInput {
  fieldOne?: string
  fieldTwo?: string
  fieldThree?: EnumType
  fieldFour?: EnumType
  fieldFive?: string
}

export namespace MessageWithoutOneOfs {
  let _codec: Codec<MessageWithoutOneOfs, MessageWithoutOneOfsInput>

  export const codec = (): Codec<MessageWithoutOneOfs, MessageWithoutOneOfsInput> => {
    if (_codec == null) {
      _codec = message<MessageWithoutOneOfs, MessageWithoutOneOfsInput>((obj, w, opts = {}) => {
        if (opts.lengthDelimited !== false) {
          w.fork()
        }

        if ((obj.fieldOne != null && obj.fieldOne !== '')) {
          w.uint32(10)
          w.string(obj.fieldOne)
        }

        if ((obj.fieldTwo != null && obj.fieldTwo !== '')) {
          w.uint32(18)
          w.string(obj.fieldTwo)
        }

        if (obj.fieldThree != null && __EnumTypeValues[obj.fieldThree] !== 0) {
          w.uint32(24)
          EnumType.codec().encode(obj.fieldThree, w)
        }

        if (obj.fieldFour != null && __EnumTypeValues[obj.fieldFour] !== 0) {
          w.uint32(32)
          EnumType.codec().encode(obj.fieldFour, w)
        }

        if ((obj.fieldFive != null && obj.fieldFive !== '')) {
          w.uint32(42)
          w.string(obj.fieldFive)
        }

        if (opts.lengthDelimited !== false) {
          w.ldelim()
        }
      }, (r, length) => {
        const obj: any = {
          fieldOne: '',
          fieldTwo: '',
          fieldThree: EnumType.Val1,
          fieldFour: EnumType.Val1,
          fieldFive: ''
        }

        const end = length == null ? r.len : r.pos + length

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              obj.fieldOne = r.string()
              break
            }
            case 2: {
              obj.fieldTwo = r.string()
              break
            }
            case 3: {
              obj.fieldThree = EnumType.codec().decode(r)
              break
            }
            case 4: {
              obj.fieldFour = EnumType.codec().decode(r)
              break
            }
            case 5: {
              obj.fieldFive = r.string()
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        return obj
      }, function * (r, length, prefix) {
        const end = length == null ? r.len : r.pos + length

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'start',
            message: 'MessageWithoutOneOfs'
          }
        }

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              yield {
                field: `${prefix}fieldOne`,
                value: r.string()
              }
              break
            }
            case 2: {
              yield {
                field: `${prefix}fieldTwo`,
                value: r.string()
              }
              break
            }
            case 3: {
              yield {
                field: `${prefix}fieldThree`,
                value: EnumType.codec().decode(r)
              }
              break
            }
            case 4: {
              yield {
                field: `${prefix}fieldFour`,
                value: EnumType.codec().decode(r)
              }
              break
            }
            case 5: {
              yield {
                field: `${prefix}fieldFive`,
                value: r.string()
              }
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'end',
            message: 'MessageWithoutOneOfs'
          }
        }
      })
    }

    return _codec
  }

  export interface MessageWithoutOneOfsFieldOneFieldEvent {
    field: '.fieldOne'
    value: string
  }

  export interface MessageWithoutOneOfsFieldTwoFieldEvent {
    field: '.fieldTwo'
    value: string
  }

  export interface MessageWithoutOneOfsFieldThreeFieldEvent {
    field: '.fieldThree'
    value: EnumType
  }

  export interface MessageWithoutOneOfsFieldFourFieldEvent {
    field: '.fieldFour'
    value: EnumType
  }

  export interface MessageWithoutOneOfsFieldFiveFieldEvent {
    field: '.fieldFive'
    value: string
  }

  export function encode (obj: MessageWithoutOneOfsInput): Uint8Array<ArrayBuffer> {
    return encodeMessage(obj, MessageWithoutOneOfs.codec())
  }

  export function decode (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<MessageWithoutOneOfs>): MessageWithoutOneOfs {
    return decodeMessage(buf, MessageWithoutOneOfs.codec(), opts)
  }

  export function stream (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<MessageWithoutOneOfs>): Generator<MessageWithoutOneOfsFieldOneFieldEvent | MessageWithoutOneOfsFieldTwoFieldEvent | MessageWithoutOneOfsFieldThreeFieldEvent | MessageWithoutOneOfsFieldFourFieldEvent | MessageWithoutOneOfsFieldFiveFieldEvent> {
    return streamMessage(buf, MessageWithoutOneOfs.codec(), opts)
  }
}
