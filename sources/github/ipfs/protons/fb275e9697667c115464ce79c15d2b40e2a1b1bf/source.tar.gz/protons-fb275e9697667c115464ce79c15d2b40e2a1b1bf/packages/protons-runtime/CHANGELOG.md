## [protons-runtime-v8.0.1](https://github.com/ipfs/protons/compare/protons-runtime-8.0.0...protons-runtime-8.0.1) (2026-09-18)

### Bug Fixes

* document message naming conventions ([#209](https://github.com/ipfs/protons/issues/209)) ([c1e3bcb](https://github.com/ipfs/protons/commit/c1e3bcb31e6be41101916999264f6d78ca14acce)), closes [#64](https://github.com/ipfs/protons/issues/64)

## [protons-runtime-v8.0.0](https://github.com/ipfs/protons/compare/protons-runtime-7.1.2...protons-runtime-8.0.0) (2026-09-18)

### ⚠ BREAKING CHANGES

* definitions will need to be regenerated

### Features

* accept any Uint8Array for encoding ([#203](https://github.com/ipfs/protons/issues/203)) ([6556bc4](https://github.com/ipfs/protons/commit/6556bc404669cbc66f93af4b36f10b02cc33f11d))

## [protons-runtime-v7.1.2](https://github.com/ipfs/protons/compare/protons-runtime-7.1.1...protons-runtime-7.1.2) (2026-09-17)

### Bug Fixes

* fix typo in skip method documentation ([#204](https://github.com/ipfs/protons/issues/204)) ([070a715](https://github.com/ipfs/protons/commit/070a715202083a0d5d0d081ff57f605998329f08))

## [protons-runtime-v7.1.1](https://github.com/ipfs/protons/compare/protons-runtime-7.1.0...protons-runtime-7.1.1) (2026-09-14)

### Bug Fixes

* stream function argument order ([#202](https://github.com/ipfs/protons/issues/202)) ([bc9c0a2](https://github.com/ipfs/protons/commit/bc9c0a25197933eefb34e0242728ed8dff1ea075))

## [protons-runtime-v7.1.0](https://github.com/ipfs/protons/compare/protons-runtime-7.0.0...protons-runtime-7.1.0) (2026-09-10)

### Features

* generate start/end events for sub messages ([#201](https://github.com/ipfs/protons/issues/201)) ([c879d0c](https://github.com/ipfs/protons/commit/c879d0cb6719defdfbb51d5406e6acf7daafcc10))

## [protons-runtime-v7.0.0](https://github.com/ipfs/protons/compare/protons-runtime-6.0.2...protons-runtime-7.0.0) (2026-05-07)

### ⚠ BREAKING CHANGES

* Returned `Uint8Array`s are now generic

### Bug Fixes

* uint8arrays are generic ([#170](https://github.com/ipfs/protons/issues/170)) ([048a855](https://github.com/ipfs/protons/commit/048a8552d310dea51f7b0a0c0397c50ff2611d55))

## [protons-runtime-v6.0.2](https://github.com/ipfs/protons/compare/protons-runtime-6.0.1...protons-runtime-6.0.2) (2026-05-07)

### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#167](https://github.com/ipfs/protons/issues/167)) ([b38cb94](https://github.com/ipfs/protons/commit/b38cb9443b9046db74fb5bdd73b8c7c7486a1cdf))

## [protons-runtime-v6.0.1](https://github.com/ipfs/protons/compare/protons-runtime-6.0.0...protons-runtime-6.0.1) (2026-03-24)

### Bug Fixes

* simplify generated code ([8810af6](https://github.com/ipfs/protons/commit/8810af61a87c0feda03b9185d44423a4490c6d77))

## [protons-runtime-v6.0.0](https://github.com/ipfs/protons/compare/protons-runtime-5.6.0...protons-runtime-6.0.0) (2026-03-24)

### ⚠ BREAKING CHANGES

* add streaming decode (#158)

### Features

* add streaming decode ([#158](https://github.com/ipfs/protons/issues/158)) ([36e915e](https://github.com/ipfs/protons/commit/36e915e8fe8e2ceaac507ee5f6a11669f2c05bbc))

### Bug Fixes

* update project config ([#159](https://github.com/ipfs/protons/issues/159)) ([5f574a0](https://github.com/ipfs/protons/commit/5f574a0161305fd4093a17936255c9b549ad9065))

### Trivial Changes

* import using .ts ([#157](https://github.com/ipfs/protons/issues/157)) ([604fd58](https://github.com/ipfs/protons/commit/604fd5849e40aa6268aedc698a88f4accc55c468))

## protons-runtime [5.4.0](https://github.com/ipfs/protons/compare/protons-runtime-5.3.0...protons-runtime-5.4.0) (2024-02-02)


### Features

* allow limiting nested repeating fields ([#129](https://github.com/ipfs/protons/issues/129)) ([a81f997](https://github.com/ipfs/protons/commit/a81f997a490cdcc7c59d00fe5e8b666e54230745))

## protons-runtime [5.3.0](https://github.com/ipfs/protons/compare/protons-runtime-v5.2.2...protons-runtime-5.3.0) (2024-01-31)


### Features

* runtime size limits for arrays and maps ([#128](https://github.com/ipfs/protons/issues/128)) ([a737d05](https://github.com/ipfs/protons/commit/a737d05d8cd8b22568ff489d07c9e4c824cb4f40))


### Bug Fixes

* improve uint64 perf ([#122](https://github.com/ipfs/protons/issues/122)) ([3234bb6](https://github.com/ipfs/protons/commit/3234bb61eac82ebbc40925df084793efbb0f0186))


### Trivial Changes

* update publish config ([942e050](https://github.com/ipfs/protons/commit/942e050bc0c14d3c8177da218f178d8dab1c0333))

## [protons-runtime-v5.2.2](https://github.com/ipfs/protons/compare/protons-runtime-v5.2.1...protons-runtime-v5.2.2) (2024-01-08)


### Dependencies

* bump aegir from 41.3.5 to 42.0.1 ([#127](https://github.com/ipfs/protons/issues/127)) ([02eafe9](https://github.com/ipfs/protons/commit/02eafe9abc565d7719ed54b64c6ae17a55ebf235))

## [protons-runtime-v5.2.1](https://github.com/ipfs/protons/compare/protons-runtime-v5.2.0...protons-runtime-v5.2.1) (2023-12-30)


### Dependencies

* bump uint8arrays from 4.0.10 to 5.0.1 ([#126](https://github.com/ipfs/protons/issues/126)) ([1e5a0b0](https://github.com/ipfs/protons/commit/1e5a0b0608b4395283c7571353918bacc3a3bd63))

## [protons-runtime-v5.2.0](https://github.com/ipfs/protons/compare/protons-runtime-v5.1.0...protons-runtime-v5.2.0) (2023-11-01)


### Features

* add custom protons options for limiting list/map sizes ([#120](https://github.com/ipfs/protons/issues/120)) ([a5ba36b](https://github.com/ipfs/protons/commit/a5ba36bbfbfb1d2bded026e0da1251e02defacdd)), closes [#113](https://github.com/ipfs/protons/issues/113)

## [protons-runtime-v5.1.0](https://github.com/ipfs/protons/compare/protons-runtime-v5.0.5...protons-runtime-v5.1.0) (2023-10-23)


### Features

* support jstype custom options ([#117](https://github.com/ipfs/protons/issues/117)) ([ba35475](https://github.com/ipfs/protons/commit/ba354756bbec60055bbeb4a6ee5bc3ab73267312)), closes [#112](https://github.com/ipfs/protons/issues/112)

## [protons-runtime-v5.0.5](https://github.com/ipfs/protons/compare/protons-runtime-v5.0.4...protons-runtime-v5.0.5) (2023-10-13)


### Bug Fixes

* write string into output buffer as uint8array ([#118](https://github.com/ipfs/protons/issues/118)) ([03ab706](https://github.com/ipfs/protons/commit/03ab706e03cdc16ff897e4ab54d87f343a8d61db))


### Trivial Changes

* update project config ([c54b7ac](https://github.com/ipfs/protons/commit/c54b7acbc9ac3839d1ef2d2653f1d19b5a0fdbf4))

## [protons-runtime-v5.0.4](https://github.com/ipfs/protons/compare/protons-runtime-v5.0.3...protons-runtime-v5.0.4) (2023-10-13)


### Bug Fixes

* port protobuf reader/writer to ts ([#60](https://github.com/ipfs/protons/issues/60)) ([d101804](https://github.com/ipfs/protons/commit/d101804674e6ba42c28505fc8fdf605020ac319e))

## [protons-runtime-v5.0.3](https://github.com/ipfs/protons/compare/protons-runtime-v5.0.2...protons-runtime-v5.0.3) (2023-10-12)


### Dependencies

* bump aegir from 40.0.13 to 41.0.4 ([#116](https://github.com/ipfs/protons/issues/116)) ([b95e988](https://github.com/ipfs/protons/commit/b95e9881a5c842b3c70a40d6d93b4aa5219b8aee))

## [protons-runtime-v5.0.2](https://github.com/ipfs/protons/compare/protons-runtime-v5.0.1...protons-runtime-v5.0.2) (2023-08-05)


### Dependencies

* bump aegir from 39.0.13 to 40.0.8 ([#108](https://github.com/ipfs/protons/issues/108)) ([8b54c80](https://github.com/ipfs/protons/commit/8b54c8097683b055736a8e431728422cedf82697))

## [protons-runtime-v5.0.1](https://github.com/ipfs/protons/compare/protons-runtime-v5.0.0...protons-runtime-v5.0.1) (2023-06-30)


### Dependencies

* bump aegir from 38.1.8 to 39.0.13 ([#104](https://github.com/ipfs/protons/issues/104)) ([912e0e6](https://github.com/ipfs/protons/commit/912e0e627fbe8047b56cdcd5d26cb81bf5700bf8))

## [protons-runtime-v5.0.0](https://github.com/ipfs/protons/compare/protons-runtime-v4.0.2...protons-runtime-v5.0.0) (2023-02-02)


### ⚠ BREAKING CHANGES

* singular fields should be optional to write (#83)

### Bug Fixes

* singular fields should be optional to write ([#83](https://github.com/ipfs/protons/issues/83)) ([229afbc](https://github.com/ipfs/protons/commit/229afbcb38ba0edc0622d4c2e97847462b439dc8)), closes [#42](https://github.com/ipfs/protons/issues/42)
* sort imports ([#84](https://github.com/ipfs/protons/issues/84)) ([6f796f1](https://github.com/ipfs/protons/commit/6f796f1e7dfd631314f9a1df534eabd96dd1528c))

## [protons-runtime-v4.0.2](https://github.com/ipfs/protons/compare/protons-runtime-v4.0.1...protons-runtime-v4.0.2) (2023-01-12)


### Dependencies

* remove lerna, update aegir ([#76](https://github.com/ipfs/protons/issues/76)) ([83a24f2](https://github.com/ipfs/protons/commit/83a24f2a924704bd4a356b6f8a3195245d8b1062))

## [protons-runtime-v4.0.1](https://github.com/ipfs/protons/compare/protons-runtime-v4.0.0...protons-runtime-v4.0.1) (2022-10-12)


### Bug Fixes

* only import reader/writer to decrease bundle size ([#69](https://github.com/ipfs/protons/issues/69)) ([8eea129](https://github.com/ipfs/protons/commit/8eea129d1b4fe5914830b29b79c4af6348eddf73))

## [protons-runtime-v4.0.0](https://github.com/ipfs/protons/compare/protons-runtime-v3.1.0...protons-runtime-v4.0.0) (2022-10-12)


### ⚠ BREAKING CHANGES

* ts definitions will need to be generated from `.proto` files - singular message fields have become optional as message fields are always optional in proto3

### Bug Fixes

* adhere more closely to the language guide for proto3 default values ([#66](https://github.com/ipfs/protons/issues/66)) ([406d775](https://github.com/ipfs/protons/commit/406d7757d490eb0dbac93343d6622dd689ff0707)), closes [#43](https://github.com/ipfs/protons/issues/43)

## [protons-runtime-v3.1.0](https://github.com/ipfs/protons/compare/protons-runtime-v3.0.1...protons-runtime-v3.1.0) (2022-08-11)


### Features

* define default types during decode ([#62](https://github.com/ipfs/protons/issues/62)) ([6453809](https://github.com/ipfs/protons/commit/64538091f7339f285ab6efbb0e18054970e00f33)), closes [#43](https://github.com/ipfs/protons/issues/43)

## [protons-runtime-v3.0.1](https://github.com/ipfs/protons/compare/protons-runtime-v3.0.0...protons-runtime-v3.0.1) (2022-08-10)


### Bug Fixes

* add uint8arraylist peer dep ([#61](https://github.com/ipfs/protons/issues/61)) ([eb16e86](https://github.com/ipfs/protons/commit/eb16e8690f28435c198d5f0facf5514f2d6574a3)), closes [#59](https://github.com/ipfs/protons/issues/59)

## [protons-runtime-v3.0.0](https://github.com/ipfs/protons/compare/protons-runtime-v2.0.2...protons-runtime-v3.0.0) (2022-08-10)


### ⚠ BREAKING CHANGES

* the exported types of `protons-runtime` have changed and protobuf encoders/decoders will need to be regenerated

### Bug Fixes

* increase encoding/decoding performance ([#58](https://github.com/ipfs/protons/issues/58)) ([9987b97](https://github.com/ipfs/protons/commit/9987b97cc6910dd67152c3a9c0941ae0ab0a8b9a))

## [protons-runtime-v2.0.2](https://github.com/ipfs/protons/compare/protons-runtime-v2.0.1...protons-runtime-v2.0.2) (2022-07-30)


### Bug Fixes

* use uint8-varint, byte-accesor and longbits modules ([#56](https://github.com/ipfs/protons/issues/56)) ([66d72f5](https://github.com/ipfs/protons/commit/66d72f50ca3733b97efa5155d3cdcb33ec531d4a))

## [protons-runtime-v2.0.1](https://github.com/ipfs/protons/compare/protons-runtime-v2.0.0...protons-runtime-v2.0.1) (2022-07-28)


### Bug Fixes

* update project config ([3199131](https://github.com/ipfs/protons/commit/3199131f1f199bcb57fcf1e7aba4ca0b6d9207db))

## [protons-runtime-v2.0.0](https://github.com/ipfs/protons/compare/protons-runtime-v1.0.4...protons-runtime-v2.0.0) (2022-07-28)


### ⚠ BREAKING CHANGES

* Uses Uint8ArrayList v2

### Features

* support no-copy serialization ([#54](https://github.com/ipfs/protons/issues/54)) ([caa0d71](https://github.com/ipfs/protons/commit/caa0d71b60367f2f3551688ad09fd695840e0852))

## [protons-runtime-v1.0.4](https://github.com/ipfs/protons/compare/protons-runtime-v1.0.3...protons-runtime-v1.0.4) (2022-05-10)


### Bug Fixes

* encode enum values ([#30](https://github.com/ipfs/protons/issues/30)) ([676c01d](https://github.com/ipfs/protons/commit/676c01dae7ff5b4d3985113573079ba605d83ef6))

## [protons-runtime-v1.0.3](https://github.com/ipfs/protons/compare/protons-runtime-v1.0.2...protons-runtime-v1.0.3) (2022-04-10)


### Bug Fixes

* remove redundant defs and declare codec return type ([#28](https://github.com/ipfs/protons/issues/28)) ([c3ea5ec](https://github.com/ipfs/protons/commit/c3ea5ec9101e37d8ac0437eb22ac0b4eeeb14eb7))

## [protons-runtime-v1.0.2](https://github.com/ipfs/protons/compare/protons-runtime-v1.0.1...protons-runtime-v1.0.2) (2022-04-08)


### Trivial Changes

* update readme ([#27](https://github.com/ipfs/protons/issues/27)) ([0ccb1a3](https://github.com/ipfs/protons/commit/0ccb1a36766e620eed2fb65973ff2d6c7854caf9))

## [protons-runtime-v1.0.1](https://github.com/ipfs/protons/compare/protons-runtime-v1.0.0...protons-runtime-v1.0.1) (2022-04-08)


### Bug Fixes

* update aegir, make codec creation dynamic ([#26](https://github.com/ipfs/protons/issues/26)) ([ecc46cc](https://github.com/ipfs/protons/commit/ecc46ccad90696c4d5cda6b2cb1db723770577d0))

## protons-runtime-v1.0.0 (2022-03-31)


### ⚠ BREAKING CHANGES

* This module is now ESM only

### Features

* transpile to ts ([#17](https://github.com/ipfs/protons/issues/17)) ([74d3b7a](https://github.com/ipfs/protons/commit/74d3b7abf1e857f7320c100734e797855ea728c1))
