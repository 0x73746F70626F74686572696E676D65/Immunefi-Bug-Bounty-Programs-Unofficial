import { decodeMessage, encodeMessage, enumeration, message, streamMessage } from 'protons-runtime'
import type { Codec, DecodeOptions } from 'protons-runtime'
import type { Uint8ArrayList } from 'uint8arraylist'

export enum OptionalEnum {
  NO_VALUE = 'NO_VALUE',
  VALUE_1 = 'VALUE_1',
  VALUE_2 = 'VALUE_2'
}

enum __OptionalEnumValues {
  NO_VALUE = 0,
  VALUE_1 = 1,
  VALUE_2 = 2
}

export namespace OptionalEnum {
  export const codec = (): Codec<OptionalEnum, OptionalEnum> => {
    return enumeration<OptionalEnum>(__OptionalEnumValues)
  }
}

export interface OptionalSubMessage {
  foo?: string
  bar?: number
}

export interface OptionalSubMessageInput {
  foo?: string
  bar?: number
}

export namespace OptionalSubMessage {
  let _codec: Codec<OptionalSubMessage, OptionalSubMessageInput>

  export const codec = (): Codec<OptionalSubMessage, OptionalSubMessageInput> => {
    if (_codec == null) {
      _codec = message<OptionalSubMessage, OptionalSubMessageInput>((obj, w, opts = {}) => {
        if (opts.lengthDelimited !== false) {
          w.fork()
        }

        if (obj.foo != null) {
          w.uint32(10)
          w.string(obj.foo)
        }

        if (obj.bar != null) {
          w.uint32(16)
          w.int32(obj.bar)
        }

        if (opts.lengthDelimited !== false) {
          w.ldelim()
        }
      }, (r, length) => {
        const obj: any = {}

        const end = length == null ? r.len : r.pos + length

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              obj.foo = r.string()
              break
            }
            case 2: {
              obj.bar = r.int32()
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        return obj
      }, function * (r, length, prefix) {
        const end = length == null ? r.len : r.pos + length

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'start',
            message: 'OptionalSubMessage'
          }
        }

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              yield {
                field: `${prefix}foo`,
                value: r.string()
              }
              break
            }
            case 2: {
              yield {
                field: `${prefix}bar`,
                value: r.int32()
              }
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'end',
            message: 'OptionalSubMessage'
          }
        }
      })
    }

    return _codec
  }

  export interface OptionalSubMessageFooFieldEvent {
    field: '.foo'
    value: string
  }

  export interface OptionalSubMessageBarFieldEvent {
    field: '.bar'
    value: number
  }

  export function encode (obj: OptionalSubMessageInput): Uint8Array<ArrayBuffer> {
    return encodeMessage(obj, OptionalSubMessage.codec())
  }

  export function decode (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<OptionalSubMessage>): OptionalSubMessage {
    return decodeMessage(buf, OptionalSubMessage.codec(), opts)
  }

  export function stream (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<OptionalSubMessage>): Generator<OptionalSubMessageFooFieldEvent | OptionalSubMessageBarFieldEvent> {
    return streamMessage(buf, OptionalSubMessage.codec(), opts)
  }
}

export interface Optional {
  double?: number
  float?: number
  int32?: number
  int64?: bigint
  uint32?: number
  uint64?: bigint
  sint32?: number
  sint64?: bigint
  fixed32?: number
  fixed64?: bigint
  sfixed32?: number
  sfixed64?: bigint
  bool?: boolean
  string?: string
  bytes?: Uint8Array<ArrayBuffer>
  enum?: OptionalEnum
  subMessage?: OptionalSubMessage
}

export interface OptionalInput {
  double?: number
  float?: number
  int32?: number
  int64?: bigint
  uint32?: number
  uint64?: bigint
  sint32?: number
  sint64?: bigint
  fixed32?: number
  fixed64?: bigint
  sfixed32?: number
  sfixed64?: bigint
  bool?: boolean
  string?: string
  bytes?: Uint8Array
  enum?: OptionalEnum
  subMessage?: OptionalSubMessageInput
}

export namespace Optional {
  let _codec: Codec<Optional, OptionalInput>

  export const codec = (): Codec<Optional, OptionalInput> => {
    if (_codec == null) {
      _codec = message<Optional, OptionalInput>((obj, w, opts = {}) => {
        if (opts.lengthDelimited !== false) {
          w.fork()
        }

        if (obj.double != null) {
          w.uint32(9)
          w.double(obj.double)
        }

        if (obj.float != null) {
          w.uint32(21)
          w.float(obj.float)
        }

        if (obj.int32 != null) {
          w.uint32(24)
          w.int32(obj.int32)
        }

        if (obj.int64 != null) {
          w.uint32(32)
          w.int64(obj.int64)
        }

        if (obj.uint32 != null) {
          w.uint32(40)
          w.uint32(obj.uint32)
        }

        if (obj.uint64 != null) {
          w.uint32(48)
          w.uint64(obj.uint64)
        }

        if (obj.sint32 != null) {
          w.uint32(56)
          w.sint32(obj.sint32)
        }

        if (obj.sint64 != null) {
          w.uint32(64)
          w.sint64(obj.sint64)
        }

        if (obj.fixed32 != null) {
          w.uint32(77)
          w.fixed32(obj.fixed32)
        }

        if (obj.fixed64 != null) {
          w.uint32(81)
          w.fixed64(obj.fixed64)
        }

        if (obj.sfixed32 != null) {
          w.uint32(93)
          w.sfixed32(obj.sfixed32)
        }

        if (obj.sfixed64 != null) {
          w.uint32(97)
          w.sfixed64(obj.sfixed64)
        }

        if (obj.bool != null) {
          w.uint32(104)
          w.bool(obj.bool)
        }

        if (obj.string != null) {
          w.uint32(114)
          w.string(obj.string)
        }

        if (obj.bytes != null) {
          w.uint32(122)
          w.bytes(obj.bytes)
        }

        if (obj.enum != null) {
          w.uint32(128)
          OptionalEnum.codec().encode(obj.enum, w)
        }

        if (obj.subMessage != null) {
          w.uint32(138)
          OptionalSubMessage.codec().encode(obj.subMessage, w)
        }

        if (opts.lengthDelimited !== false) {
          w.ldelim()
        }
      }, (r, length, opts = {}) => {
        const obj: any = {}

        const end = length == null ? r.len : r.pos + length

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              obj.double = r.double()
              break
            }
            case 2: {
              obj.float = r.float()
              break
            }
            case 3: {
              obj.int32 = r.int32()
              break
            }
            case 4: {
              obj.int64 = r.int64()
              break
            }
            case 5: {
              obj.uint32 = r.uint32()
              break
            }
            case 6: {
              obj.uint64 = r.uint64()
              break
            }
            case 7: {
              obj.sint32 = r.sint32()
              break
            }
            case 8: {
              obj.sint64 = r.sint64()
              break
            }
            case 9: {
              obj.fixed32 = r.fixed32()
              break
            }
            case 10: {
              obj.fixed64 = r.fixed64()
              break
            }
            case 11: {
              obj.sfixed32 = r.sfixed32()
              break
            }
            case 12: {
              obj.sfixed64 = r.sfixed64()
              break
            }
            case 13: {
              obj.bool = r.bool()
              break
            }
            case 14: {
              obj.string = r.string()
              break
            }
            case 15: {
              obj.bytes = r.bytes()
              break
            }
            case 16: {
              obj.enum = OptionalEnum.codec().decode(r)
              break
            }
            case 17: {
              obj.subMessage = OptionalSubMessage.codec().decode(r, r.uint32(), {
                limits: opts.limits?.subMessage
              })
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        return obj
      }, function * (r, length, prefix, opts = {}) {
        const end = length == null ? r.len : r.pos + length

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'start',
            message: 'Optional'
          }
        }

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              yield {
                field: `${prefix}double`,
                value: r.double()
              }
              break
            }
            case 2: {
              yield {
                field: `${prefix}float`,
                value: r.float()
              }
              break
            }
            case 3: {
              yield {
                field: `${prefix}int32`,
                value: r.int32()
              }
              break
            }
            case 4: {
              yield {
                field: `${prefix}int64`,
                value: r.int64()
              }
              break
            }
            case 5: {
              yield {
                field: `${prefix}uint32`,
                value: r.uint32()
              }
              break
            }
            case 6: {
              yield {
                field: `${prefix}uint64`,
                value: r.uint64()
              }
              break
            }
            case 7: {
              yield {
                field: `${prefix}sint32`,
                value: r.sint32()
              }
              break
            }
            case 8: {
              yield {
                field: `${prefix}sint64`,
                value: r.sint64()
              }
              break
            }
            case 9: {
              yield {
                field: `${prefix}fixed32`,
                value: r.fixed32()
              }
              break
            }
            case 10: {
              yield {
                field: `${prefix}fixed64`,
                value: r.fixed64()
              }
              break
            }
            case 11: {
              yield {
                field: `${prefix}sfixed32`,
                value: r.sfixed32()
              }
              break
            }
            case 12: {
              yield {
                field: `${prefix}sfixed64`,
                value: r.sfixed64()
              }
              break
            }
            case 13: {
              yield {
                field: `${prefix}bool`,
                value: r.bool()
              }
              break
            }
            case 14: {
              yield {
                field: `${prefix}string`,
                value: r.string()
              }
              break
            }
            case 15: {
              yield {
                field: `${prefix}bytes`,
                value: r.bytes()
              }
              break
            }
            case 16: {
              yield {
                field: `${prefix}enum`,
                value: OptionalEnum.codec().decode(r)
              }
              break
            }
            case 17: {
              yield * OptionalSubMessage.codec().stream(r, r.uint32(), `${prefix}subMessage.`, {
                limits: opts.limits?.subMessage
              })

              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'end',
            message: 'Optional'
          }
        }
      })
    }

    return _codec
  }

  export interface OptionalDoubleFieldEvent {
    field: '.double'
    value: number
  }

  export interface OptionalFloatFieldEvent {
    field: '.float'
    value: number
  }

  export interface OptionalInt32FieldEvent {
    field: '.int32'
    value: number
  }

  export interface OptionalInt64FieldEvent {
    field: '.int64'
    value: bigint
  }

  export interface OptionalUint32FieldEvent {
    field: '.uint32'
    value: number
  }

  export interface OptionalUint64FieldEvent {
    field: '.uint64'
    value: bigint
  }

  export interface OptionalSint32FieldEvent {
    field: '.sint32'
    value: number
  }

  export interface OptionalSint64FieldEvent {
    field: '.sint64'
    value: bigint
  }

  export interface OptionalFixed32FieldEvent {
    field: '.fixed32'
    value: number
  }

  export interface OptionalFixed64FieldEvent {
    field: '.fixed64'
    value: bigint
  }

  export interface OptionalSfixed32FieldEvent {
    field: '.sfixed32'
    value: number
  }

  export interface OptionalSfixed64FieldEvent {
    field: '.sfixed64'
    value: bigint
  }

  export interface OptionalBoolFieldEvent {
    field: '.bool'
    value: boolean
  }

  export interface OptionalStringFieldEvent {
    field: '.string'
    value: string
  }

  export interface OptionalBytesFieldEvent {
    field: '.bytes'
    value: Uint8Array<ArrayBuffer>
  }

  export interface OptionalEnumFieldEvent {
    field: '.enum'
    value: OptionalEnum
  }

  export interface OptionalSubMessageMessageStart {
    field: '.subMessage'
    type: 'start'
  }

  export interface OptionalSubMessageMessageEnd {
    field: '.subMessage'
    type: 'end'
  }

  export interface OptionalSubMessageFooFieldEvent {
    field: '.subMessage.foo'
    value: string
  }

  export interface OptionalSubMessageBarFieldEvent {
    field: '.subMessage.bar'
    value: number
  }

  export function encode (obj: OptionalInput): Uint8Array<ArrayBuffer> {
    return encodeMessage(obj, Optional.codec())
  }

  export function decode (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<Optional>): Optional {
    return decodeMessage(buf, Optional.codec(), opts)
  }

  export function stream (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<Optional>): Generator<OptionalDoubleFieldEvent | OptionalFloatFieldEvent | OptionalInt32FieldEvent | OptionalInt64FieldEvent | OptionalUint32FieldEvent | OptionalUint64FieldEvent | OptionalSint32FieldEvent | OptionalSint64FieldEvent | OptionalFixed32FieldEvent | OptionalFixed64FieldEvent | OptionalSfixed32FieldEvent | OptionalSfixed64FieldEvent | OptionalBoolFieldEvent | OptionalStringFieldEvent | OptionalBytesFieldEvent | OptionalEnumFieldEvent | OptionalSubMessageMessageStart | OptionalSubMessageMessageEnd | OptionalSubMessageFooFieldEvent | OptionalSubMessageBarFieldEvent> {
    return streamMessage(buf, Optional.codec(), opts)
  }
}
