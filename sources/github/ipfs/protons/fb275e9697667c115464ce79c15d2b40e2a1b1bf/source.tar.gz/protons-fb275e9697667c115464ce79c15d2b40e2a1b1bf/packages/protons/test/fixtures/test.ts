import { decodeMessage, encodeMessage, enumeration, MaxLengthError, message, streamMessage } from 'protons-runtime'
import type { Codec, DecodeOptions } from 'protons-runtime'
import type { Uint8ArrayList } from 'uint8arraylist'

export enum AnEnum {
  HERP = 'HERP',
  DERP = 'DERP'
}

enum __AnEnumValues {
  HERP = 0,
  DERP = 1
}

export namespace AnEnum {
  export const codec = (): Codec<AnEnum, AnEnum> => {
    return enumeration<AnEnum>(__AnEnumValues)
  }
}

export interface SubMessage {
  foo: string
}

export interface SubMessageInput {
  foo?: string
}

export namespace SubMessage {
  let _codec: Codec<SubMessage, SubMessageInput>

  export const codec = (): Codec<SubMessage, SubMessageInput> => {
    if (_codec == null) {
      _codec = message<SubMessage, SubMessageInput>((obj, w, opts = {}) => {
        if (opts.lengthDelimited !== false) {
          w.fork()
        }

        if ((obj.foo != null && obj.foo !== '')) {
          w.uint32(10)
          w.string(obj.foo)
        }

        if (opts.lengthDelimited !== false) {
          w.ldelim()
        }
      }, (r, length) => {
        const obj: any = {
          foo: ''
        }

        const end = length == null ? r.len : r.pos + length

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              obj.foo = r.string()
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        return obj
      }, function * (r, length, prefix) {
        const end = length == null ? r.len : r.pos + length

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'start',
            message: 'SubMessage'
          }
        }

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              yield {
                field: `${prefix}foo`,
                value: r.string()
              }
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'end',
            message: 'SubMessage'
          }
        }
      })
    }

    return _codec
  }

  export interface SubMessageFooFieldEvent {
    field: '.foo'
    value: string
  }

  export function encode (obj: SubMessageInput): Uint8Array<ArrayBuffer> {
    return encodeMessage(obj, SubMessage.codec())
  }

  export function decode (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<SubMessage>): SubMessage {
    return decodeMessage(buf, SubMessage.codec(), opts)
  }

  export function stream (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<SubMessage>): Generator<SubMessageFooFieldEvent> {
    return streamMessage(buf, SubMessage.codec(), opts)
  }
}

export interface AllTheTypes {
  field1?: boolean
  field2?: number
  field3?: bigint
  field4?: number
  field5?: bigint
  field6?: number
  field7?: bigint
  field8?: number
  field9?: number
  field10?: string
  field11?: Uint8Array<ArrayBuffer>
  field12?: AnEnum
  field13?: SubMessage
  field14: string[]
  field15?: number
  field16?: bigint
  field17?: number
  field18?: bigint
}

export interface AllTheTypesInput {
  field1?: boolean
  field2?: number
  field3?: bigint
  field4?: number
  field5?: bigint
  field6?: number
  field7?: bigint
  field8?: number
  field9?: number
  field10?: string
  field11?: Uint8Array
  field12?: AnEnum
  field13?: SubMessageInput
  field14?: string[]
  field15?: number
  field16?: bigint
  field17?: number
  field18?: bigint
}

export namespace AllTheTypes {
  let _codec: Codec<AllTheTypes, AllTheTypesInput>

  export const codec = (): Codec<AllTheTypes, AllTheTypesInput> => {
    if (_codec == null) {
      _codec = message<AllTheTypes, AllTheTypesInput>((obj, w, opts = {}) => {
        if (opts.lengthDelimited !== false) {
          w.fork()
        }

        if (obj.field1 != null) {
          w.uint32(8)
          w.bool(obj.field1)
        }

        if (obj.field2 != null) {
          w.uint32(16)
          w.int32(obj.field2)
        }

        if (obj.field3 != null) {
          w.uint32(24)
          w.int64(obj.field3)
        }

        if (obj.field4 != null) {
          w.uint32(32)
          w.uint32(obj.field4)
        }

        if (obj.field5 != null) {
          w.uint32(40)
          w.uint64(obj.field5)
        }

        if (obj.field6 != null) {
          w.uint32(48)
          w.sint32(obj.field6)
        }

        if (obj.field7 != null) {
          w.uint32(56)
          w.sint64(obj.field7)
        }

        if (obj.field8 != null) {
          w.uint32(65)
          w.double(obj.field8)
        }

        if (obj.field9 != null) {
          w.uint32(77)
          w.float(obj.field9)
        }

        if (obj.field10 != null) {
          w.uint32(82)
          w.string(obj.field10)
        }

        if (obj.field11 != null) {
          w.uint32(90)
          w.bytes(obj.field11)
        }

        if (obj.field12 != null) {
          w.uint32(96)
          AnEnum.codec().encode(obj.field12, w)
        }

        if (obj.field13 != null) {
          w.uint32(106)
          SubMessage.codec().encode(obj.field13, w)
        }

        if (obj.field14 != null && obj.field14.length > 0) {
          for (const value of obj.field14) {
            w.uint32(114)
            w.string(value)
          }
        }

        if (obj.field15 != null) {
          w.uint32(125)
          w.fixed32(obj.field15)
        }

        if (obj.field16 != null) {
          w.uint32(129)
          w.fixed64(obj.field16)
        }

        if (obj.field17 != null) {
          w.uint32(141)
          w.sfixed32(obj.field17)
        }

        if (obj.field18 != null) {
          w.uint32(145)
          w.sfixed64(obj.field18)
        }

        if (opts.lengthDelimited !== false) {
          w.ldelim()
        }
      }, (r, length, opts = {}) => {
        const obj: any = {
          field14: []
        }

        const end = length == null ? r.len : r.pos + length

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              obj.field1 = r.bool()
              break
            }
            case 2: {
              obj.field2 = r.int32()
              break
            }
            case 3: {
              obj.field3 = r.int64()
              break
            }
            case 4: {
              obj.field4 = r.uint32()
              break
            }
            case 5: {
              obj.field5 = r.uint64()
              break
            }
            case 6: {
              obj.field6 = r.sint32()
              break
            }
            case 7: {
              obj.field7 = r.sint64()
              break
            }
            case 8: {
              obj.field8 = r.double()
              break
            }
            case 9: {
              obj.field9 = r.float()
              break
            }
            case 10: {
              obj.field10 = r.string()
              break
            }
            case 11: {
              obj.field11 = r.bytes()
              break
            }
            case 12: {
              obj.field12 = AnEnum.codec().decode(r)
              break
            }
            case 13: {
              obj.field13 = SubMessage.codec().decode(r, r.uint32(), {
                limits: opts.limits?.field13
              })
              break
            }
            case 14: {
              if (opts.limits?.field14 != null && obj.field14.length === opts.limits.field14) {
                throw new MaxLengthError('Decode error - repeated field "field14" had too many elements')
              }

              obj.field14.push(r.string())
              break
            }
            case 15: {
              obj.field15 = r.fixed32()
              break
            }
            case 16: {
              obj.field16 = r.fixed64()
              break
            }
            case 17: {
              obj.field17 = r.sfixed32()
              break
            }
            case 18: {
              obj.field18 = r.sfixed64()
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        return obj
      }, function * (r, length, prefix, opts = {}) {
        const obj = {
          field14: 0
        }

        const end = length == null ? r.len : r.pos + length

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'start',
            message: 'AllTheTypes'
          }
        }

        while (r.pos < end) {
          const tag = r.uint32()

          switch (tag >>> 3) {
            case 1: {
              yield {
                field: `${prefix}field1`,
                value: r.bool()
              }
              break
            }
            case 2: {
              yield {
                field: `${prefix}field2`,
                value: r.int32()
              }
              break
            }
            case 3: {
              yield {
                field: `${prefix}field3`,
                value: r.int64()
              }
              break
            }
            case 4: {
              yield {
                field: `${prefix}field4`,
                value: r.uint32()
              }
              break
            }
            case 5: {
              yield {
                field: `${prefix}field5`,
                value: r.uint64()
              }
              break
            }
            case 6: {
              yield {
                field: `${prefix}field6`,
                value: r.sint32()
              }
              break
            }
            case 7: {
              yield {
                field: `${prefix}field7`,
                value: r.sint64()
              }
              break
            }
            case 8: {
              yield {
                field: `${prefix}field8`,
                value: r.double()
              }
              break
            }
            case 9: {
              yield {
                field: `${prefix}field9`,
                value: r.float()
              }
              break
            }
            case 10: {
              yield {
                field: `${prefix}field10`,
                value: r.string()
              }
              break
            }
            case 11: {
              yield {
                field: `${prefix}field11`,
                value: r.bytes()
              }
              break
            }
            case 12: {
              yield {
                field: `${prefix}field12`,
                value: AnEnum.codec().decode(r)
              }
              break
            }
            case 13: {
              yield * SubMessage.codec().stream(r, r.uint32(), `${prefix}field13.`, {
                limits: opts.limits?.field13
              })

              break
            }
            case 14: {
              if (opts.limits?.field14 != null && obj.field14 === opts.limits.field14) {
                throw new MaxLengthError('Streaming decode error - repeated field "field14" had too many elements')
              }

              yield {
                field: `${prefix}field14[]`,
                index: obj.field14,
                value: r.string()
              }

              obj.field14++

              break
            }
            case 15: {
              yield {
                field: `${prefix}field15`,
                value: r.fixed32()
              }
              break
            }
            case 16: {
              yield {
                field: `${prefix}field16`,
                value: r.fixed64()
              }
              break
            }
            case 17: {
              yield {
                field: `${prefix}field17`,
                value: r.sfixed32()
              }
              break
            }
            case 18: {
              yield {
                field: `${prefix}field18`,
                value: r.sfixed64()
              }
              break
            }
            default: {
              r.skipType(tag & 7)
              break
            }
          }
        }

        if (prefix !== '.') {
          yield {
            field: prefix.endsWith('.') ? prefix.substring(0, prefix.length - 1) : prefix,
            type: 'end',
            message: 'AllTheTypes'
          }
        }
      })
    }

    return _codec
  }

  export interface AllTheTypesField1FieldEvent {
    field: '.field1'
    value: boolean
  }

  export interface AllTheTypesField2FieldEvent {
    field: '.field2'
    value: number
  }

  export interface AllTheTypesField3FieldEvent {
    field: '.field3'
    value: bigint
  }

  export interface AllTheTypesField4FieldEvent {
    field: '.field4'
    value: number
  }

  export interface AllTheTypesField5FieldEvent {
    field: '.field5'
    value: bigint
  }

  export interface AllTheTypesField6FieldEvent {
    field: '.field6'
    value: number
  }

  export interface AllTheTypesField7FieldEvent {
    field: '.field7'
    value: bigint
  }

  export interface AllTheTypesField8FieldEvent {
    field: '.field8'
    value: number
  }

  export interface AllTheTypesField9FieldEvent {
    field: '.field9'
    value: number
  }

  export interface AllTheTypesField10FieldEvent {
    field: '.field10'
    value: string
  }

  export interface AllTheTypesField11FieldEvent {
    field: '.field11'
    value: Uint8Array<ArrayBuffer>
  }

  export interface AllTheTypesField12FieldEvent {
    field: '.field12'
    value: AnEnum
  }

  export interface AllTheTypesField13MessageStart {
    field: '.field13'
    type: 'start'
  }

  export interface AllTheTypesField13MessageEnd {
    field: '.field13'
    type: 'end'
  }

  export interface AllTheTypesField13FooFieldEvent {
    field: '.field13.foo'
    value: string
  }

  export interface AllTheTypesField14FieldEvent {
    field: '.field14[]'
    index: number
    value: string
  }

  export interface AllTheTypesField15FieldEvent {
    field: '.field15'
    value: number
  }

  export interface AllTheTypesField16FieldEvent {
    field: '.field16'
    value: bigint
  }

  export interface AllTheTypesField17FieldEvent {
    field: '.field17'
    value: number
  }

  export interface AllTheTypesField18FieldEvent {
    field: '.field18'
    value: bigint
  }

  export function encode (obj: AllTheTypesInput): Uint8Array<ArrayBuffer> {
    return encodeMessage(obj, AllTheTypes.codec())
  }

  export function decode (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<AllTheTypes>): AllTheTypes {
    return decodeMessage(buf, AllTheTypes.codec(), opts)
  }

  export function stream (buf: Uint8Array | Uint8ArrayList, opts?: DecodeOptions<AllTheTypes>): Generator<AllTheTypesField1FieldEvent | AllTheTypesField2FieldEvent | AllTheTypesField3FieldEvent | AllTheTypesField4FieldEvent | AllTheTypesField5FieldEvent | AllTheTypesField6FieldEvent | AllTheTypesField7FieldEvent | AllTheTypesField8FieldEvent | AllTheTypesField9FieldEvent | AllTheTypesField10FieldEvent | AllTheTypesField11FieldEvent | AllTheTypesField12FieldEvent | AllTheTypesField13MessageStart | AllTheTypesField13MessageEnd | AllTheTypesField13FooFieldEvent | AllTheTypesField14FieldEvent | AllTheTypesField15FieldEvent | AllTheTypesField16FieldEvent | AllTheTypesField17FieldEvent | AllTheTypesField18FieldEvent> {
    return streamMessage(buf, AllTheTypes.codec(), opts)
  }
}
