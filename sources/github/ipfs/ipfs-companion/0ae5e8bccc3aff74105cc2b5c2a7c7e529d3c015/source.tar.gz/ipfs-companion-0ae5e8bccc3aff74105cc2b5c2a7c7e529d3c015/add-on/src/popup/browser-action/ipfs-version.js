'use strict'

import browser from 'webextension-polyfill'
import html from 'choo/html/index.js'

function statusEntry ({ label, labelLegend, title, value, check, valueClass = '' }) {
  const offline = browser.i18n.getMessage('panel_statusOffline')
  label = label ? browser.i18n.getMessage(label) : null
  labelLegend = labelLegend ? browser.i18n.getMessage(labelLegend) : label
  value = value || value === 0 ? value : offline
  return html`
      <div title="${labelLegend}" class="ma0 pa0" style="position: absolute; line-height: 0.25">
        <span class="f7 tr monospace force-select-all ${valueClass}" title="${title}">${value}</span>
      </div>
    `
}

export default function ipfsVersion ({
  kuboRpcBackendVersion
}) {
  return html`
  ${statusEntry({
    title: browser.i18n.getMessage('panel_kuboRpcBackendVersionTitle'),
    value: kuboRpcBackendVersion,
    check: kuboRpcBackendVersion
  })}
  `
}
