# MV3 Migration

## Overview

This document describes the migration process from MV2 to MV3. MV3 is the extension manifest format that changes how extensions intercept and redirect network requests. A few notable changes have been discussed in this [thread](https://discuss.ipfs.tech/t/announcing-ipfs-companion-mv3-rc-beta/16442) and a detailed plan can be found [here](https://github.com/ipfs/ipfs-companion/issues/1152).

## Implementation

The change that drove this migration is how request interception works. In MV2, we used `webRequest.onBeforeRequest` to intercept requests and redirect them to the local gateway. That process looked something like:

```mermaid
flowchart TD
    A[Web Request] --> B[Companion Blocks]:::companion
    B --> C[Check if request\ncan be served\nover IPFS?]:::companion
    C --> D[Address Contains CID?]:::companion
    D --> |yes| F:::companion
    D --> |no| E[Address Resolves\nOver IPNS?]:::companion
    E --> |yes| F[Redirect to Local\nIPFS Node]:::companion
    E --> |no| G[Continue Request\nNormally]
    classDef companion fill:#0aca9f,stroke:#7f8491,stroke-width:2px;
    classDef browser fill:#d9dbe2,stroke:#7f8491,stroke-width:1px;
```

The process was simple and synchronous, the request is intercepted and handed over to companion, which then redirects it to the local gateway as needed. MV3 changes this process by introducing a new API called `declarativeNetRequest`. MV3 does not allow synchronous request interception (also called blocking request), which is not secure and can lead to performance issues. Instead, it uses a declarative approach where the extension declares a set of rules that are then used by the browser to intercept requests. This process looks something like:

```mermaid
flowchart TD
    A[Web Request] --> B[Companion Observes Request]
    A --> C{Check if any\nredirect rule applies\nto the current request}
    B:::companion --> D[Check if request can\nbe served over IPFS?]
    D:::companion --> E[Address Contains CID?]:::companion
    E --> |no| F[Address Resolves\nOver IPNS?]:::companion
    F --> |no| I[Ignore Request]:::companion
    F --> |yes| H:::companion
    E --> |yes| H[Insert Redirect Rules]:::companion
    H:::companion --> K(Declarative NetRequest Store):::browser
    C:::browser <--> |check| K
    C --> |redirect| G[To Local IPFS Node]
    C --> |no-redirect| J[Continue Request Normally]
    classDef companion fill:#0aca9f,stroke:#7f8491,stroke-width:2px;
    classDef browser fill:#d9dbe2,stroke:#7f8491,stroke-width:1px;
```

The process is asynchronous, the browser allows "observation" of requests to companion, which asynchronously determines if the given request is serviceable by IPFS and then dynamically introduces a rule for the browser to perform redirects to the local gateway. A sample rule looks something like:

```js
{
  id,                                    // random id for reference
  priority: 1,                           // priority of the rule
  action: {
    type: 'redirect',
    redirect: { '<regex substitution>' } // redirect to gateway
  },
  condition: {
    '<regex filter>',                    // filter to match requests
    '<filtered domains list>',
    resourceTypes: [
      'csp_report',
      'font',
      'image',
      'main_frame',
      'media',
      'object',
      'other',
      'ping',
      'script',
      'stylesheet',
      'sub_frame',
      'webbundle',
      'xmlhttprequest'
    ]
  }
}
```

The API only allows for 5000 such rules to exist at the time of writing this, so that value can be exhausted pretty quickly. So instead of adding one rule per redirect, we can dynamically generate a single regex pattern to handle multiple redirections.

For example

```
https://ipfs.io/ipns/en.wikipedia-on-ipfs.org -> http://localhost:8080/ipns/en.wikipedia-on-ipfs.org
```

can be represented as

```
https://ipfs.io/ipns/(.*) -> http://localhost:8080/ipns/$1
```

That's just an example, but in reality it looks more like (which covers edge cases like URL endings):

```js
{
  "action": {
    "redirect": {
      "regexSubstitution": "http://localhost:8080\\1"
    },
    "type": "redirect"
  },
  "condition": {
    "excludedInitiatorDomains": [],
    "regexFilter": "^https?\\:\\/\\/ipfs\\.io((?:[^\\.]|$).*)$",
    "resourceTypes": [
      "csp_report",
      "font",
      "image",
      "main_frame",
      "media",
      "object",
      "other",
      "ping",
      "script",
      "stylesheet",
      "sub_frame",
      "webbundle",
      "xmlhttprequest"
    ]
  },
  "id": 1234,
  "priority": 1
}
```

This is a single rule that covers all the redirects from `ipfs.io` to `localhost:8080`. This means that we can save a lot of rules and gain more coverage of serviceable URLs. This is the approach we have taken in MV3.

## Gotchas

Since the process is asynchronous, there are a few things that we need to keep in mind:

- There will always be scenarios, where the servicing of the public URL happens before companion determines if the URL is serviceable over IPFS (consider ipns/fqdn resolutions.) To tackle this a refresh mechanism has been put in place that refreshes the page after a few milliseconds if the URL is serviceable. This is not ideal, but it is the best we can do for now.
- Similarly there are scenarios around page recovery, where the page starts redirection, but the kubo node goes offline, in which case companion needs to remove offending rule and replace it with the recovery URL.
- If the kubo rpc api url changes for some reason, companion needs to update the rules to reflect the new URL. We can preemptively generate new rules based on the new url, but the new node might not be servicing content over the old URL structure (e.g. https://ipfs.io/ipns/en.wikipedia-on-ipfs.org resolves to http://en.wikipedia-on-ipfs.org.ipns.localhost:8080/ with kubo but http://en-wikipedia--on--ipfs-org.ipns.localhost:48084/wiki/ on custom Kubo RPC port, similarly the node can have its own URL structure,) which we need to account for. Hence, we remove all such rules as offending and begin the process of generating new rules on the fly.
- A public gateway that serves content from an in-page service worker cannot be redirected once the worker takes over its origin, and this cannot be fixed easily inside Companion. Example: [inbrowser.link](https://inbrowser.link), the [service-worker-gateway](https://github.com/ipfs/service-worker-gateway), registers a root-scope (`scope: '/'`) worker on first load. `declarativeNetRequest` and the observe-then-`tabs.update` fallback only act on requests that reach the network stack; a navigation answered by the worker from CacheStorage (or any worker-generated response) never reaches it, so no redirect rule matches and no `webRequest` event is observed. The state survives reloads because the worker registration and its cache persist, so a redirect to the local gateway never happens no matter how many times the user refreshes. This is a documented Chromium limitation, see the [chromium-extensions thread](https://groups.google.com/a/chromium.org/g/chromium-extensions/c/K2DtYbwtCAA). MV2 Firefox is not affected because its blocking `webRequest` redirects the navigation itself before the worker handles it, which the declarative model cannot do. Companion reaches this state because the `?x-ipfs-companion-no-redirect` opt-out (or a lost first-load race) lets the worker register in the first place; once it controls the origin, Chromium will not hand the navigation back at the network layer. To recover, Companion watches `webNavigation.onCommitted` (`recoverRedirectMiss` in `ipfs-request.js`): when a top-level navigation commits to serviceable public gateway content and a local gateway is available, it sends the tab to the local gateway with `tabs.update`. This still honors the opt-out (a URL carrying the token is left alone) and skips Back/Forward navigations so it does not trap the Back button. A user who wants to stay on the public worker can also clear it with the gateway's own `?ipfs-sw-unregister` escape hatch.

## Other Thoughts

Not intercepting requests synchronously has its quirks, but maintaining a dynamic ruleset of possible redirects is more complicated. From the second request to a given host onwards, the browser applies the declarative rules itself, so Companion is no longer in the request path. That should cut load times and keep Companion from being a bottleneck.
