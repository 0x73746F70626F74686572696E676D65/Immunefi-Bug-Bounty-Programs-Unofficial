import { isAbortWithServerTimingError, MEDIA_TYPE_CAR, MEDIA_TYPE_CBOR, MEDIA_TYPE_DAG_CBOR, MEDIA_TYPE_DAG_JSON, MEDIA_TYPE_DAG_PB, MEDIA_TYPE_IPNS_RECORD, MEDIA_TYPE_JSON, MEDIA_TYPE_RAW, MEDIA_TYPE_TAR } from '@helia/verified-fetch'
import { CURRENT_CACHES } from '../../constants.ts'
import { errorToObject } from '../../lib/error-to-object.ts'
import { getSubdomainParts } from '../../lib/get-subdomain-parts.ts'
import { getSwLogger } from '../../lib/logger.ts'
import { isBitswapProvider, isFallbackTrustlessGatewayProvider, isTrustlessGatewayProvider } from '../../lib/providers.ts'
import { canUseStaleResponseOnError, needsRevalidateAfterUse, needsRevalidateBeforeUse } from '../lib/cache-control.ts'
import { parseHeaderDirectives } from '../lib/header-directives.ts'
import { sniffRawContentType } from '../lib/sniff-raw-content-type.ts'
import { getVerifiedFetch } from '../lib/verified-fetch.ts'
import { fetchErrorPageResponse } from '../pages/fetch-error-page.ts'
import { renderEntityPageResponse } from '../pages/render-entity.ts'
import { tryRenderMediaViewer } from '../pages/render-media.ts'
import type { Handler } from './index.ts'
import type { ContentURI } from '../../lib/parse-request.ts'
import type { Providers } from '../sw.ts'
import type { VerifiedFetchInit } from '@helia/verified-fetch'
import type { ClearableSignal } from 'any-signal'

const FORMAT_TO_MEDIA_TYPE: Record<string, string> = {
  raw: 'application/vnd.ipld.raw',
  car: 'application/vnd.ipld.car',
  tar: 'application/x-tar',
  'dag-json': 'application/vnd.ipld.dag-json',
  'dag-cbor': 'application/vnd.ipld.dag-cbor',
  json: 'application/json',
  cbor: 'application/cbor',
  'ipns-record': 'application/vnd.ipfs.ipns-record'
}

interface FetchHandlerArg {
  event: FetchEvent
  logs: string[]
  request: ContentURI
  headers: Headers
  renderHtml: boolean
  cacheKey: string
  isMutable: boolean
  accept: string | null
  signal: ClearableSignal
}

const MAX_REDIRECTS = 5

function getCacheKey (resource: ContentURI, headers: Headers, renderHtml: boolean, destination: RequestDestination): string {
  // Include `destination` so a cached media-viewer wrapper (top-level
  // navigation) does not collide with a subresource `<img>`/`<video>`
  // re-fetch of the same URL that needs the raw bytes.
  return `${resource.subdomainURL}-${headers.get('accept')}-html-${renderHtml}-dest-${destination}-match-${headers.get('if-none-match')}`
}

async function getResponseFromCacheOrFetch (args: FetchHandlerArg): Promise<Response> {
  const log = getSwLogger('get-response-from-cache-or-fetch')

  const cache = await caches.open(args.isMutable ? CURRENT_CACHES.mutable : CURRENT_CACHES.immutable)
  const cachedResponse = await cache.match(args.cacheKey)
  args.signal.throwIfAborted()

  if (cachedResponse == null) {
    log('cached response MISS for %s (cache key %s)', args.event.request.url, args.cacheKey)
    return fetchAndUpdateCache(args)
  }

  if (needsRevalidateBeforeUse(cachedResponse)) {
    log('cached response HIT for %s (cache key %s) but needs revalidation before use', args.event.request.url, args.cacheKey)

    const response = await fetchAndUpdateCache(args)

    if (canUseStaleResponseOnError(response, cachedResponse)) {
      log('%d error revalidating response but can re-use cached response HIT for %s (cache key %s)', response.status, args.event.request.url, args.cacheKey)
      return cachedResponse
    }

    return response
  }

  if (needsRevalidateAfterUse(cachedResponse)) {
    log('cached response HIT for %s (cache key %s) but needs background revalidation', args.event.request.url, args.cacheKey)

    args.event.waitUntil(
      fetchAndUpdateCache(args)
        .catch(err => {
          log.error('background revalidate for %s (cache key %s) failed - %e', args.event.request.url, args.cacheKey, err)
        })
    )

    return cachedResponse
  }

  log('cached response HIT for %s (cache key %s)', args.event.request.url, args.cacheKey)
  return cachedResponse
}

async function fetchAndUpdateCache (args: FetchHandlerArg): Promise<Response> {
  const log = getSwLogger('fetch-and-update-cache')

  const response = await fetchHandler(args)
  log.trace('got response from fetchHandler')

  log('response status: %s', response.status)

  try {
    await storeResponseInCache(response, args)
    log.trace('updated cache for %s', args.cacheKey)
  } catch (err) {
    log.error('failed updating response in cache for %s - %e', args.cacheKey, err)
  }

  return response
}

function shouldCacheResponse (response: Response, args: FetchHandlerArg): boolean {
  const log = getSwLogger('should-cache-response')

  if (!response.ok) {
    log.trace('response not ok, not caching %s %d %s', response.url, response.status, response.statusText)

    for (const [key, value] of response.headers) {
      log.trace('%s: %s', key, value)
    }

    return false
  }

  const statusCodesToNotCache = [206]

  if (statusCodesToNotCache.some(code => code === response.status)) {
    log.trace('not caching response with status %s', response.status)
    return false
  }

  if (args.event.request.headers.get('pragma') === 'no-cache' || args.event.request.headers.get('cache-control') === 'no-cache') {
    log.trace('request indicated no-cache, not caching')
    return false
  }

  // no-store directive prevents any kind of caching
  if (parseHeaderDirectives(response.headers.get('cache-control'))['no-store'] === true) {
    return false
  }

  return true
}

async function storeResponseInCache (response: Response, args: FetchHandlerArg): Promise<void> {
  const log = getSwLogger('store-response-in-cache')

  if (!shouldCacheResponse(response, args)) {
    return
  }

  // ensure we can invalidate the cache later
  if (response.headers.get('date') == null) {
    log.trace('setting date header on response key %s before storing in cache', args.cacheKey)
    response.headers.set('date', new Date().toUTCString())
  }

  log.trace('updating cache for %s in the background', args.cacheKey)
  const cache = await caches.open(args.isMutable ? CURRENT_CACHES.mutable : CURRENT_CACHES.immutable)
  args.signal.throwIfAborted()

  // Clone the response since streams can only be consumed once.
  const respToCache = response.clone()

  log('storing response for key %s in cache', args.cacheKey)
  // do not await this.. large responses will delay [TTFB](https://web.dev/articles/ttfb)
  // and [TTI](https://web.dev/articles/tti)

  try {
    // make sure the event lives until async work has completed but do not delay
    // the response
    args.event.waitUntil(
      cache.put(args.cacheKey, respToCache)
        .catch((err) => {
          log.error('error storing response for %s in cache - %e', args.cacheKey, err)
        })
    )
  } catch (err) {
    log.error('storing response for %s in cache threw - %e', args.cacheKey, err)
  }
}

async function fetchHandler ({ request, headers, renderHtml, event, logs, accept, signal }: FetchHandlerArg): Promise<Response> {
  const log = getSwLogger('fetch-handler')

  const providers: Providers = {
    total: 0,
    providers: []
  }

  let resource = request.nativeURL
  let ifNoneMatch = headers.get('if-none-match')

  // these tokens are added to the header by the entity renderer response,
  // remove them for internal comparison by verified fetch
  if (ifNoneMatch != null) {
    ifNoneMatch = ifNoneMatch.replace('DirIndex-.*_CID-', '')
    ifNoneMatch = ifNoneMatch.replace('DagIndex-', '')

    headers.set('if-none-match', ifNoneMatch)
  }

  const init: VerifiedFetchInit = {
    signal,
    headers,
    redirect: 'manual',
    onProgress: (evt) => {
      if (evt.type.endsWith(':found-provider')) {
        if (isFallbackTrustlessGatewayProvider(evt.detail)) {
          // do not include fallback trustless gateways in provider list since
          // they aren't really providers in the IPFS sense
          return
        }

        log('got found-provider event %s %j', evt.type, evt.detail)

        if (isBitswapProvider(evt.detail)) {
          providers.providers.push({
            type: evt.detail.type,
            router: evt.detail.router,
            provider: evt.detail.provider
          })
        } else if (isTrustlessGatewayProvider(evt.detail)) {
          providers.providers.push({
            type: evt.detail.type,
            router: evt.detail.router,
            provider: evt.detail.url
          })
        } else {
          providers.providers.push({
            type: 'unknown',
            // @ts-expect-error cannot derive type
            router: evt.detail?.router ?? 'unknown',
            provider: evt.detail
          })
        }

        providers.total++

        // truncate providers if there are too many
        if (providers.providers.length > 10) {
          providers.providers.length = 10
        }
      }
    },
    supportDirectoryIndexes: resource.searchParams.get('download') !== 'false',
    supportWebRedirects: resource.searchParams.get('download') !== 'false'
  }

  let streamingResponse = false

  try {
    const verifiedFetch = await getVerifiedFetch()

    log('request')
    log('%s %s HTTP/1.1', init.method ?? 'GET', resource)

    for (const [key, value] of headers.entries()) {
      log('%s: %s', key, value)
    }

    let response: Response | undefined
    let redirectStatus: number | undefined

    // when we follow redirects in `_redirects` file, ensure we don't loop forever
    for (let i = 0; i < MAX_REDIRECTS; i++) {
      response = await verifiedFetch(resource, init)

      if (isManualRedirect(response)) {
        // a non-30x with a location header should be treated as a rewrite not a
        // redirect so we need to follow the location header internally
        // @see https://specs.ipfs.tech/http-gateways/web-redirects-file/#status
        log('rewrite %s to %s', resource, response.headers.get('location'))
        resource = new URL(response.headers.get('location') ?? '')

        // use the original status code
        if (redirectStatus == null) {
          redirectStatus = response.status
        }
      } else {
        break
      }
    }

    if (response == null) {
      throw new Error('Failed to fetch')
    }

    if (isManualRedirect(response)) {
      // manual redirects occur when an entry in the _redirects file was used
      throw new Error('Too many redirects')
    }

    if (redirectStatus != null) {
      // if we are here, it's because the user defined status codes in a
      // _redirects file so just return the response instead of showing UI
      streamingResponse = true
      return new Response(abortableBody(response, signal), {
        status: redirectStatus,
        headers: response.headers,
        statusText: response.statusText
      })
    }

    log('response')
    log('HTTP/1.1 %d %s', response.status, response.statusText)

    for (const [key, value] of response.headers.entries()) {
      log('%s: %s', key, value)
    }

    // Workaround for verified-fetch's `plugin-handle-raw` not honouring
    // the path-gateway spec's content-type sniffing requirement. Without
    // this, raw-codec single-block CIDs (`bafkrei…`, the default for
    // helia/unixfs content that fits in one block) come back as
    // `application/vnd.ipld.raw` even when the bytes carry recognisable
    // PDF / PNG / MP4 magic. Running the override here means the wrapper
    // decision below sees the sniffed type and the sniffed response is
    // what gets cached.
    response = await sniffRawContentType(response, accept)

    // render previews for UnixFS directories
    if (response.headers.get('content-type') === MEDIA_TYPE_DAG_PB) {
      renderHtml = shouldRenderDirectory(resource, accept)
    }

    if (response.status > 399) {
      return fetchErrorPageResponse(request, init, response, await response.text(), providers, logs)
    }

    if (response.status > 199 && response.status < 300) {
      // Wrap top-level navigations to renderable media (image/video/audio/
      // pdf/text/json) in a viewer page that exposes an explicit Download
      // button. Workaround for the Chromium SW "Save As" bug — see
      // https://github.com/ipfs/service-worker-gateway/issues/574 and
      // https://issues.chromium.org/issues/400455011. Subresource fetches
      // arrive with `destination !== 'document'`, so they skip the wrapper
      // and avoid recursion.
      const wrapped = tryRenderMediaViewer(
        request,
        response,
        event.request.destination,
        renderHtml,
        resource.searchParams.get('download')
      )

      if (wrapped != null) {
        return wrapped
      }

      if (renderHtml) {
        try {
          return renderEntityPageResponse(request, headers, response, await response.arrayBuffer())
        } catch (err: any) {
          log.error('error while loading body to render - %e', err)

          // if the response content involves loading more than one block and
          // loading a subsequent block fails, the `.arrayBuffer()` promise will
          // reject with an opaque 'TypeError: Failed to fetch' so show a 502
          // Bad Gateway with debugging information
          return fetchErrorPageResponse(request, init, new Response('', {
            status: 502,
            statusText: 'Bad Gateway',
            headers: {
              'Content-Type': 'application/json'
            }
          }), JSON.stringify(errorToObject(err), null, 2), providers, logs)
        }
      } else if (resource.searchParams.get('download') === 'true') {
        // override inline attachments if present
        let contentDisposition = response.headers.get('content-disposition')

        if (contentDisposition == null || contentDisposition === '') {
          contentDisposition = 'attachment'
        } else if (contentDisposition.startsWith('inline')) {
          contentDisposition = contentDisposition.replace('inline', 'attachment')
        }

        response.headers.set('content-disposition', contentDisposition)
      }
    }

    // Create a completely new response object with the same body, status,
    // statusText, and headers.
    //
    // This is necessary to work around a bug with Safari not rendering
    // content correctly.
    streamingResponse = true
    return new Response(abortableBody(response, signal), {
      status: response.status,
      headers: response.headers,
      statusText: response.statusText
    })
  } catch (err: any) {
    let response: Response
    let responseBody: string

    if (err.name === 'TimeoutError') {
      response = new Response('', {
        status: 504,
        statusText: 'Gateway Timeout',
        headers: {
          'content-type': 'application/json'
        }
      })

      responseBody = JSON.stringify(errorToObject(err), null, 2)
    } else {
      log.error('error during request - %e', err)

      response = new Response('', {
        status: 500,
        statusText: 'Internal Server Error',
        headers: {
          'content-type': 'application/json',
          'x-error-message': btoa(err.message)
        }
      })

      responseBody = JSON.stringify(errorToObject(err), null, 2)
    }

    if (isAbortWithServerTimingError(err)) {
      response.headers.set('server-timing', err.serverTiming)
    }

    return fetchErrorPageResponse(request, init, response, responseBody, providers, logs)
  } finally {
    if (!streamingResponse) {
      signal.clear()
    }
  }
}

function shouldRenderDirectory (url: URL, accept?: string | null): boolean {
  if (url.searchParams.get('download') === 'true') {
    return false
  } else if (url.searchParams.get('download') === 'false') {
    return true
  }

  return accept?.includes('text/html') === true
}

export const contentRequestHandler: Handler = {
  name: 'content-request-handler',

  canHandle (request) {
    return request.type === 'subdomain'
  },

  async handle (request: ContentURI, event, logs, signal) {
    // request was for subdomain or path gateway
    const log = getSwLogger('fetch-handler')

    log('handling request for %s', request.subdomainURL)

    const urlParts = getSubdomainParts(event.request.url)

    // `bafkqaaa` is an empty identity CID that is used to detect subdomain
    // support so this response MUST be returned before we check for config on
    // this subdomain, otherwise we go into an endless loop of redirects trying
    // to load content
    if (urlParts.id === 'bafkqaaa') {
      return new Response('', {
        status: 200
      })
    }

    const headers = createHeaders(event)
    let renderHtml = false

    const accept = headers.get('accept')

    if (accept != null) {
      if (acceptsIPLD(accept)) {
        // honour an Accept header that verified-fetch supports - this will not
        // 406
      } else if (acceptsAnything(accept)) {
        // this is a workaround for the fact that browsers always send an accept
        // header that includes text/html so we'd never send file content
        headers.delete('accept')
      } else if (acceptsHTML(accept)) {
        // verified-fetch will 406 but we can render an HTML view of the result so
        // remove the accept header and accept whatever verified-fetch gives us
        headers.delete('accept')
        renderHtml = true
      }
    }

    // if the user has explicitly requested a preview, show it to them
    if (request.subdomainURL.searchParams.get('download') === 'false') {
      renderHtml = true
    }

    const response = await getResponseFromCacheOrFetch({
      event,
      request,
      headers,
      logs,
      cacheKey: getCacheKey(request, headers, renderHtml, event.request.destination),
      isMutable: urlParts.protocol === 'ipns',
      renderHtml,
      accept,
      signal
    })

    return response
  }
}

function createHeaders (event: FetchEvent): Headers {
  const headers = new Headers(event.request.headers)
  const url = new URL(event.request.url)

  const accept = headers.get('accept')
  let defaultVersion = '1'
  let defaultOrder = 'unk'
  let defaultDups = 'y'

  if (accept?.includes('application/vnd.ipld.car')) {
    accept.split(';')
      .forEach(part => {
        const [key, value] = part.split('=').map(s => s.trim())

        if (key === 'version' && (value === '1' || value === '2')) {
          defaultVersion = value
        }

        if (key === 'order' && (value === 'dfs' || value === 'unk')) {
          defaultOrder = value
        }

        if (key === 'dups' && (value === 'y' || value === 'n')) {
          defaultDups = value
        }
      })
  }

  // override the Accept header if the format param is present
  // https://specs.ipfs.tech/http-gateways/path-gateway/#format-request-query-parameter
  const format = url.searchParams.get('format')
  if (isCarRequest(url)) {
    const accept = `application/vnd.ipld.car; version=${
      url.searchParams.get('car-version') ?? defaultVersion
    }; order=${
      url.searchParams.get('car-order') ?? defaultOrder
    }; dups=${
      url.searchParams.get('car-dups') ?? defaultDups
    }`

    headers.set('accept', accept)
  } else if (format != null) {
    const accept = FORMAT_TO_MEDIA_TYPE[format]

    if (accept != null) {
      headers.set('accept', accept)
    }
  }

  // if the user has specified CAR options but no Accept header, default to
  // the car content type with the passed options
  return headers
}

/**
 * Returns `true` if the user has requested a specific IPLD format
 */
function acceptsIPLD (accept: string): boolean {
  return [
    MEDIA_TYPE_DAG_CBOR,
    MEDIA_TYPE_CBOR,
    MEDIA_TYPE_DAG_JSON,
    MEDIA_TYPE_JSON,
    MEDIA_TYPE_RAW,
    MEDIA_TYPE_IPNS_RECORD,
    MEDIA_TYPE_DAG_PB,
    MEDIA_TYPE_CAR,
    MEDIA_TYPE_TAR
  ].some(val => accept.includes(val))
}

/**
 * Returns `true` if the user accepts HTML
 */
function acceptsHTML (accept: string): boolean {
  return [
    'text/html'
  ].some(val => accept.includes(val))
}

/**
 * Returns `true` if the user accepts HTML
 */
function acceptsAnything (accept: string): boolean {
  return [
    '*/*'
  ].some(val => accept.includes(val))
}

/**
 * Returns `true` if the user requested a CAR file via search params
 */
function isCarRequest (url: URL): boolean {
  return url.searchParams.get('format') === 'car' ||
    url.searchParams.has('entity-bytes') ||
    url.searchParams.has('dag-scope') ||
    url.searchParams.has('car-order') ||
    url.searchParams.has('car-dups') ||
    url.searchParams.has('car-version')
}

function isManualRedirect (response: Response): boolean {
  if (response.status > 299 && response.status < 400) {
    return false
  }

  return response.headers.has('location')
}

/**
 * A passthrough body stream that clears the passed signal after all bytes have
 * been sent
 */
function abortableBody (response: Response, signal: ClearableSignal): BodyInit | undefined {
  return response.body?.pipeThrough(new TransformStream({
    flush () {
      signal.clear()
    }
  }))
}
