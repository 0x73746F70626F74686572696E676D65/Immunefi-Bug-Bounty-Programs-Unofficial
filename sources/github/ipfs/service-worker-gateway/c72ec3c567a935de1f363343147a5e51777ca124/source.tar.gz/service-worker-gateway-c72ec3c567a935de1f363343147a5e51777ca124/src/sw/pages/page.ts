/**
 * HTML-escape a string for safe interpolation into element content
 * (e.g. between `<title>...</title>`). Replaces `&`, `<`, `>` with their
 * named entities; that is sufficient for element content. Attribute
 * interpolation would also need `"` and `'` escapes.
 */
function escapeHtml (s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

/**
 * Returns HTML that makes up a page with a title and a value injected into
 * `globalThis` with the passed key.
 *
 * `title` is HTML-escaped before interpolation: it lands inside `<title>` and
 * may carry user-controlled bytes (e.g. an IPFS path segment routed through
 * `displayName`). Without escaping, a path containing `</title><script>...`
 * would close the title element and inject script.
 *
 * The `.replace(/</g, '\\u003c')` on the JSON output prevents `</script>`
 * (or `<!--`, `<![CDATA[`, etc.) from terminating the script tag if any prop
 * value contains those sequences. `JSON.stringify` does not escape `<` by
 * default, so without this any user-controlled string in `value` could break
 * out of the script context.
 */
export function htmlPage (title: string, key: string, value: any): string {
  return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="robots" content="noindex" />
    <link rel='shortcut icon' href='data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlo89/56ZQ/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACUjDu1lo89/6mhTP+zrVP/nplD/5+aRK8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHNiIS6Wjz3/ubFY/761W/+vp1D/urRZ/8vDZf/GvmH/nplD/1BNIm8AAAAAAAAAAAAAAAAAAAAAAAAAAJaPPf+knEj/vrVb/761W/++tVv/r6dQ/7q0Wf/Lw2X/y8Nl/8vDZf+tpk7/nplD/wAAAAAAAAAAAAAAAJaPPf+2rVX/vrVb/761W/++tVv/vrVb/6+nUP+6tFn/y8Nl/8vDZf/Lw2X/y8Nl/8G6Xv+emUP/AAAAAAAAAACWjz3/vrVb/761W/++tVv/vrVb/761W/+vp1D/urRZ/8vDZf/Lw2X/y8Nl/8vDZf/Lw2X/nplD/wAAAAAAAAAAlo89/761W/++tVv/vrVb/761W/++tVv/r6dQ/7q0Wf/Lw2X/y8Nl/8vDZf/Lw2X/y8Nl/56ZQ/8AAAAAAAAAAJaPPf++tVv/vrVb/761W/++tVv/vbRa/5aPPf+emUP/y8Nl/8vDZf/Lw2X/y8Nl/8vDZf+emUP/AAAAAAAAAACWjz3/vrVb/761W/++tVv/vrVb/5qTQP+inkb/op5G/6KdRv/Lw2X/y8Nl/8vDZf/Lw2X/nplD/wAAAAAAAAAAlo89/761W/++tVv/sqlS/56ZQ//LxWb/0Mlp/9DJaf/Kw2X/oJtE/7+3XP/Lw2X/y8Nl/56ZQ/8AAAAAAAAAAJaPPf+9tFr/mJE+/7GsUv/Rymr/0cpq/9HKav/Rymr/0cpq/9HKav+xrFL/nplD/8vDZf+emUP/AAAAAAAAAACWjz3/op5G/9HKav/Rymr/0cpq/9HKav/Rymr/0cpq/9HKav/Rymr/0cpq/9HKav+inkb/nplD/wAAAAAAAAAAAAAAAKKeRv+3slb/0cpq/9HKav/Rymr/0cpq/9HKav/Rymr/0cpq/9HKav+1sFX/op5G/wAAAAAAAAAAAAAAAAAAAAAAAAAAop5GUKKeRv/Nxmf/0cpq/9HKav/Rymr/0cpq/83GZ/+inkb/op5GSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAop5G16KeRv/LxWb/y8Vm/6KeRv+inkaPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAop5G/6KeRtcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/n8AAPgfAADwDwAAwAMAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAwAMAAPAPAAD4HwAA/n8AAA==' />
    <title>${escapeHtml(title)}</title>
    <link rel="icon" href="/ipfs-sw-favicon.ico" type="image/ico"/>
    <link rel="shortcut icon" href="/ipfs-sw-favicon.ico" type="image/x-icon"/>
    <script type="module">
globalThis.${key} = ${JSON.stringify(value, null, 2).replace(/</g, '\\u003c')}
    </script>
  </head>
  <body>
    <div id="root" class="sans-serif charcoal f5"></div>
    <script>
      ${''
      // Marks, on the current history entry, that we have already tried to
      // recover from an app chunk that would not load.
      //
      // history.state is the right place for it. It survives location.reload(),
      // it is scoped to this page rather than the whole origin, and reading it
      // needs no storage permission, so the cap still holds in a browser
      // configured to deny block storage
      }
      const CHUNK_RETRIED = 'ipfsSwChunkRetried'

      function alreadyRetriedChunk () {
        return history.state?.[CHUNK_RETRIED] === true
      }

      function markChunkRetried () {
        history.replaceState({ ...history.state, [CHUNK_RETRIED]: true }, '')
      }

      function forgetChunkRetry () {
        if (!alreadyRetriedChunk()) {
          return
        }

        const state = { ...history.state }
        delete state[CHUNK_RETRIED]
        history.replaceState(state, '')
      }

      ${''
      // Tell the user the app chunk will not load, using only the bootstrap DOM
      }
      function showAppChunkError () {
        document.querySelector('.loading-indicator-js')?.classList.add('hidden')

        const root = document.getElementById('root')

        if (root == null) {
          return
        }

        ${''
        // .sw-error is defined in the inline stylesheet of index.html, because
        // the stylesheet the app ships is inside the chunk that failed to load.
        }
        root.classList.add('sw-error')

        const title = document.createElement('h1')
        title.textContent = 'Could not load this page'

        const cause = document.createElement('p')
        cause.textContent = 'The application script failed to load. Usually a CDN or your browser is holding a stale copy of this page that points at a script which no longer exists.'

        const remedy = document.createElement('p')
        remedy.textContent = 'Waiting a few minutes and trying again normally clears it. A hard reload, which bypasses your browser cache, fetches a fresh copy right away.'

        const retry = document.createElement('button')
        retry.textContent = 'Try again'
        retry.addEventListener('click', () => {
          forgetChunkRetry()
          document.location.reload(true)
        })

        root.replaceChildren(title, cause, remedy, retry)
      }

      const script = document.createElement('script')
      script.addEventListener('load', () => {
        forgetChunkRetry()
      })
      script.addEventListener('error', () => {
      ${''
      // Recover once, and only once. Dropping the caches and the service worker
      // is what fixes a bootstrap left behind by a deploy, and the reload is
      // what picks up the current one. If the chunk is still missing after
      // that, the stale copy lives in a CDN entry that no reload can evict, so
      // trying again only hammers the CDN until it rate limits us, with the
      // user watching a blank page throughout. That is the cyclic reload
      // reported in #1155.
      }
      if (alreadyRetriedChunk()) {
        showAppChunkError()
        return
      }

      ${''
      // Mark before the purge below, which deletes every cache, and before the
      // reload, which resets the page.
      }
      markChunkRetried()

      ${''
      // failed to load script, there may be a new service worker available -
      // delete all caches, unregister the service worker and reload
      }
      Promise.all([
        caches.keys()
          .then(async (cacheNames) => {
            return Promise.all(
              cacheNames.map(async function (cacheName) {
                return caches.delete(cacheName)
              })
            )
          })
          .catch(err => {
            console.error('could not delete out of date cache - %e', err)
          }),
        navigator.serviceWorker.getRegistration()
          .then(async registration => {
            registration?.unregister()
          })
      ])
        .then(() => {
          document.location.reload(true)
        })
        .catch((err) => {
          console.error('could not refresh context', err)
        })
      })
      script.type = 'module'
      script.src = '<%-- src/ui/index.tsx --%>'
      document.body.appendChild(script)
    </script>
  </body>
</html>
`
}
