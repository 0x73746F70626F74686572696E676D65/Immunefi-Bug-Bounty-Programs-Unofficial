import React from 'react'
import { FaFileDownload, FaCopy } from 'react-icons/fa'
import { MULTICODECS } from '../pages/multicodec-table.ts'
import { CopyCidButton } from './copy-cid-button.tsx'
import { DownloadButton } from './download-button.tsx'
import { FaFileSearch } from './fa-file-search.ts'
import { InspectBlockButton } from './inspect-block-button.tsx'
import type { CID } from 'multiformats/cid'
import type { ReactElement } from 'react'

export interface CIDDetailsProps {
  cid: CID
  ipfsPath: string
  className?: string
  buttonClassName?: string
}

export function CIDDetails ({ cid, ipfsPath, className, buttonClassName }: CIDDetailsProps): ReactElement {
  return (
    <div className={`db normal flex ${className ?? ''}`}>
      <code className='mt1'>
        CIDv{cid.version} {MULTICODECS[cid.code].name} {MULTICODECS[cid.multihash.code].name}
      </code>
      <CopyCidButton cid={cid} className={`ml1 copy-cid-button ${buttonClassName ?? ''}`}>
        <FaCopy />
      </CopyCidButton>
      <DownloadButton ipfsPath={ipfsPath} className={`ml1 download-block-button ${buttonClassName ?? ''}`}>
        <FaFileDownload />
      </DownloadButton>
      <InspectBlockButton ipfsPath={ipfsPath} className={`ml1 view-block-button ${buttonClassName ?? ''}`}>
        <FaFileSearch />
      </InspectBlockButton>
    </div>
  )
}
