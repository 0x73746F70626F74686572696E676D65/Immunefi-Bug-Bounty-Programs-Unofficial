import React, { useState } from 'react'
import { parseRequest } from '../../lib/parse-request-cheap.ts'
import { removeRootHashIfPresent } from '../../lib/remove-root-hash.ts'
import { toGatewayRoot } from '../../lib/to-gateway-root.ts'
import { Button } from '../components/button.tsx'
import ContentBox from '../components/content-box.tsx'
import { Link } from '../components/link.tsx'
import Terminal from '../components/terminal.tsx'
import { createLink } from '../utils/links.ts'
import type { RequestDetails, ResponseDetails } from '../../sw/pages/fetch-error-page.ts'
import type { Providers } from '../../sw/sw.ts'
import type { ReactElement } from 'react'

declare global {
  var fetchError: {
    request: RequestDetails
    response: ResponseDetails
    providers: Providers
    title: string
    logs: string[]
  }
}

function capitalizeHeader (key: string): string {
  return key.split('-').map(s => `${s.substring(0, 1).toUpperCase()}${s.substring(1)}`).join('-')
}

function toRequest (request: RequestDetails): string {
  const url = new URL(request.resource)
  const headers = [
    `Host: ${url.host}`
  ]

  for (const [key, value] of new Headers(request.headers ?? {}).entries()) {
    headers.push(`${capitalizeHeader(key)}: ${value}`)
  }

  return `${request.method ?? 'GET'} ${url.pathname} HTTP/1.1
${
  headers.join('\n')
}`
}

function toResponse (response: ResponseDetails): string {
  let body = response.body

  // try to make JSON body legible
  if (response?.headers['content-type']?.includes('application/json')) {
    try {
      body = JSON.stringify(JSON.parse(response.body), null, 2)
    } catch {}
  }

  return `HTTP/1.1 ${response.status} ${response.statusText}
${
  [...Object.entries(response.headers)].map(([key, value]) => `${capitalizeHeader(key)}: ${value}`).join('\n')
}

${body}`.trim()
}

function findCid (request: RequestDetails): string | void {
  try {
    const url = new URL(request.resource)

    const req = parseRequest(url, new URL(globalThis.location.href))

    if ((req.type === 'subdomain' || req.type === 'path' || req.type === 'native') && req.protocol === 'ipfs') {
      return req.cid.toString()
    }
  } catch {}
}

export interface FetchErrorPageProps {
  request?: RequestDetails
  response?: ResponseDetails
  logs?: string[]
  providers?: Providers
}

function DebugInfo ({ request, response, logs }: FetchErrorPageProps): ReactElement {
  let requestDisplay = <></>

  if (request != null) {
    requestDisplay = (
      <>
        <h4 className='ma3'>Request</h4>
        <Terminal>{toRequest(request)}</Terminal>
      </>
    )
  }

  let responseDisplay = <></>

  if (response != null) {
    responseDisplay = (
      <>
        <h4 className='ma3'>Response</h4>
        <Terminal>{toResponse(response)}</Terminal>
      </>
    )
  }

  let logDisplay = <></>

  if (logs != null && logs.length > 0) {
    logDisplay = (
      <>
        <h4 className='ma3'>Logs</h4>
        <Terminal>{logs.join('\n')}</Terminal>
      </>
    )
  }

  return (
    <>
      <h3 className='ma3'>Debug</h3>
      {/* this message is already displayed if it's a 500 */}
      {response?.status === 500 ? '' : <p className='ma3'>If you open a <Link href='https://github.com/ipfs/service-worker-gateway/issues?q=sort%3Aupdated-desc+is%3Aissue+is%3Aopen'>bug report</Link> please include all of the information below.</p>}
      {requestDisplay}
      {responseDisplay}
      {logDisplay}
    </>
  )
}

export function FetchErrorPage ({ request, response, logs, providers }: FetchErrorPageProps): ReactElement {
  request = request ?? globalThis.fetchError?.request
  response = response ?? globalThis.fetchError?.response
  logs = logs ?? globalThis.fetchError?.logs
  providers = providers ?? globalThis.fetchError?.providers

  if (request == null || response == null || logs == null || providers == null) {
    globalThis.location.href = toGatewayRoot('/')

    return (
      <></>
    )
  }

  removeRootHashIfPresent()

  const defaultShowDebugInfo = response.status === 500

  let showDebugInfo = defaultShowDebugInfo
  let setShowDebugInfo = (val: boolean): void => {}

  try {
    [showDebugInfo, setShowDebugInfo] = useState<boolean>(defaultShowDebugInfo)
  } catch {
    // useState breaks during the initial server-side renderToString call as it
    // seems to break hooks - https://github.com/facebook/react/issues/22214
  }

  function toggleDebugInfo (): void {
    setShowDebugInfo(!showDebugInfo)
  }

  function retry (): void {
    // remove any UI-added navigation info
    history.pushState('', document.title, window.location.pathname + window.location.search)

    // @ts-expect-error boolean `forceGet` argument is firefox-only
    window.location.reload(true)
  }

  function goBack (): void {
    window.history.back()
  }

  function checkAvailability (cid: string): void {
    window.open(`https://check.ipfs.network/?cid=${cid}`)
  }

  const cid = findCid(request)
  let showCheckAvailability = Boolean(cid)

  const openIssueLink = (
    <>
      <p className='f5 ma3 fw4 db'>Please <Link href='https://github.com/ipfs/service-worker-gateway/issues'>open an issue</Link> with the URL you tried to access and any debugging information displayed below.</p>
    </>
  )

  let providersMessage = <></>

  if (providers.total === 0) {
    providersMessage = (
      <>
        <Terminal>No providers were found</Terminal>
      </>
    )
  } else {
    providersMessage = (
      <>
        <Terminal>
          These providers were found but did not return the requested data:

          {'\n\n' + JSON.stringify(providers.providers, null, 2)}
        </Terminal>
      </>
    )
  }

  const whatNextMessage = (
    <>
      <p className='f5 ma3 fw4 db'>How you can proceed:</p>
      <ul className='db pt1 lh-copy ma3'>
        <li>Verify the URL and try again.</li>
        <li>Self-host and run an <Link href='https://docs.ipfs.tech/concepts/ipfs-implementations/'>IPFS client</Link> that verifies your data.</li>
        <li>Try diagnosing your request with the <Link href='https://docs.ipfs.tech/reference/diagnostic-tools/'>IPFS diagnostic tools</Link>.</li>
        <li>Inspect the <Link href={`https://cid.ipfs.tech/${cid ? `#${cid}` : ''}`}>CID</Link> or <Link href={`https://explore.ipld.io/${cid ? `#/explore/${cid}` : ''}`}>DAG</Link>.</li>
        <li>Install the <Link href='https://docs.ipfs.tech/install/ipfs-companion'>IPFS companion browser extension </Link> to run a local IPFS node.</li>
      </ul>
    </>
  )

  let showInspectBlock = false
  let showRetry = false

  let message = (
    <>
      <p className='f5 ma3 fw4 db'>An error occurred in the service worker gateway.</p>
      {openIssueLink}
    </>
  )

  if (response.body.includes('UnknownHashAlgorithmError')) {
    message = (
      <>
        <p className='f5 ma3 fw4 db'>The requested CID contains a hash algorithm for which no implementation has been configured so it is not possible to verify the received block.</p>
        <p className='f5 ma3 fw4 db'>It is not currently possible to configure arbitrary hashing algorithms though this could be a feature added in the future.</p>
        {openIssueLink}
      </>
    )
  } else if (response.status === 501) {
    showInspectBlock = true
    message = (
      <>
        <p className='f5 ma3 fw4 db'>This gateway encountered content it did not know how to handle.</p>
        {providersMessage}
        {openIssueLink}
      </>
    )
  } else if (response.status === 502) {
    message = (
      <>
        <p className='f5 ma3 fw4 db'>An error occurred while streaming the content.</p>
        {providers.total === 0
          ? (
            <p className='f5 ma3 fw4 db'>This means that no providers with browser-compatible transports were found, and that the fallback trustless gateway failed to to find TCP or QUIC providers.</p>
            )
          : ''}
        {providers.total > 0
          ? (
            <p className='f5 ma3 fw4 db'>This means that one or more providers claimed to have the content but then failed to send the data.</p>
            )
          : ''}
        <Terminal>{response.body}</Terminal>
        {providersMessage}
        {whatNextMessage}
      </>
    )
  } else if (response.status === 504) {
    showRetry = true
    message = (
      <>
        <p className='db pt1 lh-copy ma3'>Fetching your content from the <Link href='https://docs.ipfs.tech/concepts/glossary/#mainnet'>public IPFS network</Link> failed.</p>
        <Terminal>{response.body}</Terminal>
        {providersMessage}
        {whatNextMessage}
      </>
    )
  } else if (response.status === 404) {
    const url = new URL(request.resource)

    message = (
      <>
        <p className='f5 ma3 fw4 db'>The path {url.pathname} was not found under the CID {url.hostname.split('.ipfs')[0]}</p>
      </>
    )
  } else if (response.status === 406) {
    showCheckAvailability = false

    message = (
      <>
        <p className='f5 ma3 fw4 db'>The requested content cannot be represented in the requested format.</p>
      </>
    )
  } else if (response.status >= 400 && response.status < 500) {
    message = (
      <>
        <p className='f5 ma3 fw4 db'>The request was invalid</p>
      </>
    )
  }

  let checkAvailabilityButton = <></>

  if (showCheckAvailability && cid != null) {
    checkAvailabilityButton = (
      <>
        <Button className='bg-teal' onClick={() => checkAvailability(cid)}>Check CID availability</Button>
      </>
    )
  }

  let inspectBlockButton = <></>

  if (inspectBlockButton && cid != null && showInspectBlock) {
    inspectBlockButton = (
      <>
        <Button
          className='bg-navy-muted' onClick={(evt: MouseEvent) => {
            evt.preventDefault()
            evt.stopPropagation()

            window.location.href = createLink({
              params: {
                format: 'raw',
                download: 'false'
              }
            })
          }}
        >Inspect block
        </Button>
      </>
    )
  }

  let retryButton = <></>

  if (showRetry) {
    retryButton = (
      <>
        <Button className='bg-navy-muted' onClick={retry}>Retry</Button>
      </>
    )
  }

  return (
    <>
      <ContentBox title={`${response.status} ${response.statusText}`}>
        <>
          {message}
          <p className='ma3'>
            {checkAvailabilityButton}
            {retryButton}
            <Button className='bg-navy-muted' onClick={goBack}>Go back</Button>
            <Button className='bg-navy-muted' onClick={toggleDebugInfo}>{showDebugInfo ? 'Hide' : 'Show'} debug info</Button>
            {inspectBlockButton}
          </p>
          {showDebugInfo && <DebugInfo request={request} response={response} logs={logs} />}
        </>
      </ContentBox>
    </>
  )
}
