import { setMaxListeners } from '@libp2p/interface'
import { anySignal } from 'any-signal'
import { raceSignal } from 'race-signal'
import weald from 'weald'
import { config } from '../config/index.ts'
import { CURRENT_CACHES } from '../constants.ts'
import { logEmitter } from '../lib/collecting-logger.ts'
import { QUERY_PARAMS } from '../lib/constants.ts'
import { getSwLogger } from '../lib/logger.ts'
import { parseRequest } from '../lib/parse-request.ts'
import { getGatewayRoot } from '../lib/to-gateway-root.ts'
import { APP_NAME, APP_VERSION, GIT_REVISION } from '../version.ts'
import { handlers } from './handlers/index.ts'
import { updateRedirect } from './lib/update-redirect.ts'
import { serverErrorPageResponse } from './pages/server-error-page.ts'
import type { ResolvableURI } from '../lib/parse-request.ts'
import type { Handler } from './handlers/index.ts'
import type { ClearableSignal } from 'any-signal'

weald.enable(config.debug)

export interface Provider {
  type: string
  router: string
  provider: any
}

/**
 * These are block/car providers that were used while downloading data
 */
export interface Providers {
  total: number
  // this is limited to 10x entries to prevent new routing systems causing OOMs
  providers: Provider[]
}

declare let self: ServiceWorkerGlobalScope

self.addEventListener('install', (event) => {
  const log = getSwLogger('install')

  // 👇 When a new version of the SW is installed, activate immediately
  event.waitUntil(
    Promise.all([
      self.skipWaiting()
        .catch(err => {
          log.error('error skipping waiting - %e', err)
        }),
      clearSwAssetCache()
    ])
  )
})

self.addEventListener('activate', (event) => {
  const log = getSwLogger('activate')

  /**
   * 👇 Claim all clients immediately. This handles the case when subdomain is
   * loaded for the first time, and config is updated and then a pre-fetch is
   * sent (await fetch(window.location.href, { method: 'GET' })) to start
   * loading the content prior the user reloading or clicking the "load content"
   * button.
   */
  event.waitUntil(
    self.clients.claim()
      .catch(err => {
        const log = getSwLogger('fetch')
        log.error('error claiming clients - %e', err)
      })
  )

  // eslint-disable-next-line no-console
  console.info(`Service Worker Gateway: To manually unregister, append "?${QUERY_PARAMS.UNREGISTER_SERVICE_WORKER}=true" to the URL, or use the button on the config page.`)

  // delete all caches that aren't named in CURRENT_CACHES.
  const expectedCacheNames = Object.keys(CURRENT_CACHES).map(function (key) {
    return CURRENT_CACHES[key as keyof typeof CURRENT_CACHES]
  })

  event.waitUntil(
    caches.keys()
      .then(async function (cacheNames) {
        return Promise.all(
          cacheNames.map(async function (cacheName) {
            if (!expectedCacheNames.includes(cacheName as (typeof CURRENT_CACHES)[keyof typeof CURRENT_CACHES])) {
              // If this cache name isn't present in the array of "expected" cache names, then delete it.
              log('deleting out of date cache:', cacheName)
              return caches.delete(cacheName)
            }
          })
        )
      })
      .catch(err => {
        log.error('could not delete out of date cache - %e', err)
      })
  )
})

self.addEventListener('fetch', (event) => {
  const log = getSwLogger('fetch')
  const url = new URL(event.request.url)
  // Fragments are client-side only, but Chromium leaks the navigation
  // hash through to `event.request.url` for `location.reload()` (and
  // any top-level navigation targeting a fragment URL). Letting it
  // through here pollutes cache keys, threads stale state into wrapper
  // props (causing `URL#frag#frag` iframe srcs when the client appends
  // `globalThis.location.hash`), and complicates `parseRequest`. The
  // wrapper UI reads `globalThis.location.hash` directly when it needs
  // the user fragment for embedded viewers (e.g. PDF `#page=N`).
  url.hash = ''
  const request = parseRequest(url, new URL(self.location.href))

  // collect logs from Helia/libp2p during the fetch operation
  const logs: string[] = []

  function onLog (event: CustomEvent<string>): void {
    logs.push(event.detail)
  }

  logEmitter.addEventListener('log', onLog)

  const handler = handlers.find(handler => handler.canHandle(request, event, logs))

  if (handler == null) {
    log('no handler found, falling back to global fetch for %s', url)
    return
  }

  log.trace('incoming request url %s - handler %s', event.request.url, handler.name)

  const controller = new AbortController()

  const signal = anySignal([
    event.request.signal,
    controller.signal
  ])
  setMaxListeners(Infinity, signal)

  let body: ReadableStream<Uint8Array> | undefined | null

  // `event.respondWith` must be called synchronously in the event handler, but
  // we can pass it a promise
  // https://stackoverflow.com/questions/76848928/failed-to-execute-respondwith-on-fetchevent-the-event-handler-is-already-f
  event.respondWith(
    handleFetch(request, event, handler, logs, signal)
      .then(async response => {
        if (response.body?.locked) {
          throw new Error('Body was locked after handleFetch')
        }

        if (response.body?.locked) {
          throw new Error('Body was locked before updating redirect')
        }

        // if verified-fetch has redirected us, update the location header in
        // the response to be a HTTP location not ipfs/ipns
        updateRedirect(url, new URL(getGatewayRoot()), response)

        if (response.body?.locked) {
          throw new Error('Body was locked after updating redirect')
        }

        // add the server header to the response so we can be sure this response
        // came from the service worker - sometimes these are read-only so we
        // cannot just `response.headers.set('server', ...)`
        const headers = new Headers(response.headers)
        headers.set('server', `${APP_NAME}/${APP_VERSION}#${GIT_REVISION}`)

        body = response.body

        if (body == null) {
          return new Response(body, {
            status: response.status,
            statusText: response.statusText,
            headers
          })
        }

        const { readable, writable } = new TransformStream<Uint8Array, Uint8Array>()
        const writer = writable.getWriter()
        const reader = body.getReader()

        ;(async () => {
          try {
            while (true) {
              const [result] = await raceSignal(Promise.all([
                reader.read(),
                writer.ready
              ]), signal)

              if (writer.desiredSize === null || writer.desiredSize === 0) {
                // if desiredSize is not a positive integer it means the stream
                // has errored (null) or is closed (0) so abort any in-flight
                // operations
                throw new Error(`Stream ${writer.desiredSize === null ? 'errored' : 'closed'}`)
              }

              if (result.done === true) {
                // request body finished
                await raceSignal(writer.close(), signal)
                break
              }

              if (result.value != null) {
                await raceSignal(writer.write(result.value), signal)
              }
            }
          } catch (e) {
            if (!controller.signal.aborted) {
              controller.abort(e)
            }

            try {
              await Promise.all([
                reader.cancel(e),
                writer.abort(e),
                readable.cancel(e)
              ])
            } catch {
              // ignore cleanup errors
            }
          } finally {
            // Release the writer lock
            writer.releaseLock()

            signal.clear()
            logEmitter.removeEventListener('log', onLog)
          }
        })()

        return new Response(readable, {
          status: response.status,
          statusText: response.statusText,
          headers
        })
      })
      .catch(err => {
        return serverErrorPageResponse(url, err, logs)
      })
      .finally(() => {
        if (body == null) {
          signal.clear()
          logEmitter.removeEventListener('log', onLog)
        }
      })
  )
})

async function handleFetch (request: ResolvableURI, event: FetchEvent, handler: Handler, logs: string[], signal: ClearableSignal): Promise<Response> {
  try {
    const response = await handler.handle(request, event, logs, signal)

    if (response.body?.locked) {
      throw new Error('Body was locked after handler ' + handler.name)
    }

    // if running tests, inform the runner which handler served this response
    // this allows the load-with-service-worker function to only return the
    // final response and not an interstitial or forwarding page
    if (process.env.NODE_ENV === 'test') {
      try {
        if (response.headers.get('service-worker-handler') == null) {
          response.headers.set('service-worker-handler', handler.name)
        }
      } catch {
        // cached responses are immutable so ignore any failure to set the
        // handler header
      }
    }

    return response
  } catch (err) {
    // ensure we only reject, never throw
    return Promise.reject(err)
  }
}

/**
 * To be called on 'install' sw event. This will clear out the old swAssets cache,
 * which is used for storing the service worker's css,js, and html assets.
 */
async function clearSwAssetCache (): Promise<void> {
  const log = getSwLogger('clear-sw-asset-cache')

  // clear out old swAssets cache
  const cacheName = CURRENT_CACHES.swAssets
  const cache = await caches.open(cacheName)

  try {
    const keys = await cache.keys()
    for (const request of keys) {
      await cache.delete(request)
    }
  } catch (err) {
    log.error('could not clear SW asset cache - %e', err)
  }
}
