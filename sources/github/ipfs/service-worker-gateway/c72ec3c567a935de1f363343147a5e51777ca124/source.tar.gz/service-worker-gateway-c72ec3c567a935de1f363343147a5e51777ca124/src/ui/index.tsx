import React from 'react'
import ReactDOMClient from 'react-dom/client'
import './index.css'
import { FaInfoCircle, FaGithub, FaExclamationTriangle, FaExclamationCircle, FaHome, FaListAlt, FaFileDownload } from 'react-icons/fa'
import { HashRouter, Route, Routes, NavLink } from 'react-router-dom'
import { HASH_FRAGMENTS } from '../lib/constants.ts'
import { isBrowserSupported } from '../lib/is-browser-supported.ts'
import { ErrorBoundary } from './components/error-boundary.tsx'
import ipfsLogo from './ipfs-logo.svg'
import AboutPage from './pages/about.tsx'
import { DownloadingPage } from './pages/downloading-page.tsx'
import { FetchErrorPage } from './pages/fetch-error.tsx'
import HomePage from './pages/home.tsx'
import NoServiceWorkerErrorPage from './pages/no-service-worker.tsx'
import OriginIsolationWarningPage from './pages/origin-isolation-warning.tsx'
import { RenderEntityPage } from './pages/render-entity.tsx'
import { RenderMediaPage } from './pages/render-media.tsx'
import { ServerErrorPage } from './pages/server-error.tsx'
import UnsupportedBrowserErrorPage from './pages/unsupported-browser.tsx'
import { injectCSS } from './utils/css-injector.ts'

// SW did not trigger for this request

function toAbsolutePath (path: string): string {
  if (path.startsWith('./')) {
    return path.substring(1)
  }

  return path
}

/**
 * Do not redirect to `#/` if we are already on the bare domain, otherwise the
 * hash can interfere with CTRL+R-style page reloads
 */
function doNothingIfClickedOnRoot (event: React.MouseEvent): boolean {
  if (globalThis.location.hash === '') {
    event.preventDefault()
    event.stopPropagation()
    return false
  }

  return true
}

function Header (): React.ReactElement {
  let errorPageLink: React.ReactElement | undefined

  if (globalThis.fetchError != null) {
    errorPageLink = (
      <NavLink to='/' className={({ isActive }) => (isActive || globalThis.location.hash === '') ? 'yellow-muted' : 'yellow'} onClickCapture={doNothingIfClickedOnRoot}>
        <FaExclamationCircle className='ml2 f3' />
      </NavLink>
    )
  }

  if (globalThis.serverError != null) {
    errorPageLink = (
      <NavLink to='/' className={({ isActive }) => (isActive || globalThis.location.hash === '') ? 'red-muted' : 'red'} onClickCapture={doNothingIfClickedOnRoot}>
        <FaExclamationCircle className='ml2 f3' />
      </NavLink>
    )
  }

  if (globalThis.originIsolationWarning != null) {
    errorPageLink = (
      <NavLink to='/' className={({ isActive }) => (isActive || globalThis.location.hash === '') ? 'yellow-muted' : 'yellow'} onClickCapture={doNothingIfClickedOnRoot}>
        <FaExclamationTriangle className='ml2 f3' />
      </NavLink>
    )
  }

  if (globalThis.renderEntity != null) {
    errorPageLink = (
      <NavLink to='/' className={({ isActive }) => (isActive || globalThis.location.hash === '') ? 'white' : 'aqua'} onClickCapture={doNothingIfClickedOnRoot}>
        <FaListAlt className='ml2 f3' />
      </NavLink>
    )
  }

  if (globalThis.downloadingPage != null) {
    errorPageLink = (
      <NavLink to='/' className={({ isActive }) => (isActive || globalThis.location.hash === '') ? 'white' : 'aqua'} onClickCapture={doNothingIfClickedOnRoot}>
        <FaFileDownload className='ml2 f3' />
      </NavLink>
    )
  }

  return (
    <header className='e2e-header flex items-center pa2 bg-navy bb bw3 b--aqua tc justify-between'>
      <div>
        <a href='https://ipfs.tech' title='IPFS Project' target='_blank' rel='noopener noreferrer' aria-label='Visit the website of the IPFS Project'>
          <img alt='IPFS logo' src={toAbsolutePath(ipfsLogo)} style={{ height: 50 }} className='v-top' />
        </a>
      </div>
      <div className='pb1 ma0 mr2 inline-flex items-center aqua'>
        <h1 className='e2e-header-title f3 fw2 ttu sans-serif'>Service Worker Gateway</h1>
        {errorPageLink}
        <NavLink id='e2e-link-home-page' to={`/${HASH_FRAGMENTS.IPFS_SW_LOAD_UI}`} className={({ isActive }) => (isActive || (errorPageLink == null && globalThis.location.hash === '')) ? 'white' : 'aqua'}>
          <FaHome className='ml2 f3' />
        </NavLink>
        <NavLink id='e2e-link-about-page' to={`/${HASH_FRAGMENTS.IPFS_SW_ABOUT_UI}`} className={({ isActive }) => isActive ? 'white' : 'aqua'}>
          <FaInfoCircle className='ml2 f3' />
        </NavLink>
        <a href='https://github.com/ipfs/service-worker-gateway' className='aqua' title='IPFS Service Worker Gateway on GitHub' target='_blank' rel='noopener noreferrer' aria-label='Visit the GitHub repository for the IPFS Service Worker Gateway'>
          <FaGithub className='ml2 f3' />
        </a>
      </div>
    </header>
  )
}

/**
 * Dynamically create an index route - if an error has occurred, show that on
 * the landing page, otherwise show the "Enter a CID" UI page
 */
function getIndexRoute (): React.ReactElement {
  if (globalThis.fetchError != null) {
    return (
      <Route element={<FetchErrorPage />} path='*' index />
    )
  }

  if (globalThis.serverError != null) {
    return (
      <Route element={<ServerErrorPage />} path='*' index />
    )
  }

  if (globalThis.originIsolationWarning != null) {
    return (
      <Route element={<OriginIsolationWarningPage />} path='*' index />
    )
  }

  if (globalThis.renderEntity != null) {
    return (
      <Route element={<RenderEntityPage />} path='*' index />
    )
  }

  if (globalThis.downloadingPage != null) {
    return (
      <Route element={<DownloadingPage />} path='*' index />
    )
  }

  return (
    <Route element={<HomePage />} path='*' index />
  )
}

/**
 * This component is used when either:
 *
 * 1. the SW encountered an error fulfilling the request
 * 2. Installing the service worker failed
 * 3. The user wants to update the service worker config
 * 4. The user needs to accept the origin isolation warning
 */
function App (): React.ReactElement {
  // Media viewer pages render without the global Header / HashRouter chrome
  // so the sticky top bar in RenderMediaPage is the only navigation surface.
  // See https://github.com/ipfs/service-worker-gateway/issues/574
  if (globalThis.renderMedia != null) {
    return <RenderMediaPage />
  }

  return (
    <HashRouter>
      <Header />
      <ErrorBoundary>
        <Routes>
          <Route path={`/${HASH_FRAGMENTS.IPFS_SW_LOAD_UI}`} element={<HomePage />} />,
          <Route path={`/${HASH_FRAGMENTS.IPFS_SW_ABOUT_UI}`} element={<AboutPage />} />,
          <Route path={`/${HASH_FRAGMENTS.IPFS_SW_FETCH_ERROR_UI}`} element={<FetchErrorPage />} />
          <Route path={`/${HASH_FRAGMENTS.IPFS_SW_SERVER_ERROR_UI}`} element={<ServerErrorPage />} />
          <Route path={`/${HASH_FRAGMENTS.IPFS_SW_ORIGIN_ISOLATION_WARNING}`} element={<OriginIsolationWarningPage />} />
          {getIndexRoute()}
        </Routes>
      </ErrorBoundary>
    </HashRouter>
  )
}

/**
 * Wraps an error page in the minimal header chrome used when the full app
 * cannot run (no service worker, unsupported browser).
 */
function errorScreen (page: React.ReactElement): React.ReactElement {
  return (
    <React.StrictMode>
      <header className='e2e-header flex items-center pa2 bg-navy bb bw3 b--aqua tc justify-between'>
        <div>
          <a href='https://ipfs.tech' title='IPFS Project' target='_blank' rel='noopener noreferrer' aria-label='Visit the website of the IPFS Project'>
            <img alt='IPFS logo' src={toAbsolutePath(ipfsLogo)} style={{ height: 50 }} className='v-top' />
          </a>
        </div>
        <div className='pb1 ma0 mr2 inline-flex items-center aqua'>
          <h1 className='e2e-header-title f3 fw2 ttu sans-serif'>Service Worker Gateway</h1>
          <a href='https://github.com/ipfs/service-worker-gateway' title='IPFS Service Worker Gateway on GitHub' target='_blank' rel='noopener noreferrer' aria-label='Visit the GitHub repository for the IPFS Service Worker Gateway'>
            <FaGithub className='ml2 f3' />
          </a>
        </div>
      </header>
      {page}
    </React.StrictMode>
  )
}

async function renderUi (): Promise<void> {
  try {
    await injectCSS('<%-- src/ui/index.css --%>')
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn('Failed to load CSS config, UI will render without styles:', err)
  }

  const loadingIndicator = document.querySelector('.loading-indicator-js')

  if (loadingIndicator != null) {
    loadingIndicator.classList.add('hidden')
  }

  const container = document.getElementById('root')

  if (container == null) {
    throw new Error('No root container found')
  }

  const root = ReactDOMClient.createRoot(container)

  if (!isBrowserSupported()) {
    root.render(errorScreen(<UnsupportedBrowserErrorPage />))

    return
  }

  if (!('serviceWorker' in navigator)) {
    root.render(errorScreen(<NoServiceWorkerErrorPage />))

    return
  }

  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  )
}

renderUi().catch(err => {
  // eslint-disable-next-line no-console
  console.error('Failed to render UI:', err)
})

// only register PWA manifest on root domain, not on CID subdomains
// where it causes unnecessary background DNS lookups
if (!location.hostname.includes('.ipfs.') && !location.hostname.includes('.ipns.')) {
  const manifest = document.createElement('link')
  manifest.rel = 'manifest'
  manifest.href = '/ipfs-sw-manifest.json'
  document.head.appendChild(manifest)
}
