import { isUnregisterRequest } from '../../lib/unregister-request.ts'
import type { Handler } from './index.ts'

declare let self: ServiceWorkerGlobalScope

export const unregisterHandler: Handler = {
  name: 'unregister-service-worker-handler',

  canHandle (url, event) {
    return isUnregisterRequest(event.request.url)
  },

  handle (url, event) {
    event.waitUntil(self.registration.unregister())

    return new Response('Service worker unregistered', {
      status: 200
    })
  }
}
