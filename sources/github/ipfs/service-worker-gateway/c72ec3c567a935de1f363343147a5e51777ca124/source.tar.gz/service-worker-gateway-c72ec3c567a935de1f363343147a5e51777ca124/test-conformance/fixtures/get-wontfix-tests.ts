export function getWontFixTests (): string[] {
  return [
    // these tests make HTTP requests to hosts that are not supported by the
    // service worker gateway
    'TestDNSLinkGatewayUnixFSDirectoryListing',
    'TestRedirectsFileSupportWithDNSLink',
    'TestDNSLinkGatewayIPNS',
    'TestDNSLinkGatewayWithSubpath',

    // kubo-specific tests
    'TestUnixFSDirectoryListing/path_gw:_backlink_on_root_CID_should_be_hidden_%28TODO:_cleanup_Kubo-specifics%29',
    'TestUnixFSDirectoryListing/path_gw:_dir_listing_HTML_response_%28TODO:_cleanup_Kubo-specifics%29',
    'TestUnixFSDirectoryListingOnSubdomainGateway/backlink_on_root_CID_should_be_hidden_%28TODO:_cleanup_Kubo-specifics%29',
    'TestUnixFSDirectoryListingOnSubdomainGateway/Regular_dir_listing_HTML_%28TODO:_cleanup_Kubo-specifics%29',
    'TestGatewaySubdomains/valid_breadcrumb_links_in_the_header_of_directory_listing_at_%7Bcid%7D.ipfs.example.com%2Fsub%2Fdir_%28TODO:_cleanup_Kubo-specifics%29',

    // not sure why this needs to error
    'TestPathing/GET_DAG-JSON_traversal_returns_501_if_there_is_path_remainder',
    'TestPathing/GET_DAG-CBOR_traversal_returns_501_if_there_is_path_remainder',

    // these tests require the block /ipfs/bafybeib3ffl2teiqdncv3mkz4r23b5ctrwkzrrhctdbne6iboayxuxk5ui/root2/root3/root4
    // to be in the blockstore already
    'TestNativeDag/Cache_control_HTTP_headers_%28json%29',
    'TestGatewayCache/HEAD_for_%2Fipfs%2F_with_only-if-cached_succeeds_when_in_local_datastore',
    'TestGatewayCache/GET_for_%2Fipfs%2F_with_only-if-cached_succeeds_when_in_local_datastore',

    // cannot skip the tests that require reporting unrelated errors
    'TestRedirectsFileSupport',

    // playwright cannot intercept redirects so we cannot assert 301/302 status
    // codes were received
    'TestRedirectsFileSupport/request_for_%7Bcid%7D.ipfs.example.com%2Fredirect-one_redirects_with_default_of_301%2C_per__redirects_file',
    'TestRedirectsFileSupport/request_for_%7Bcid%7D.ipfs.example.com%2F301-redirect-one_redirects_with_301%2C_per__redirects_file',
    'TestRedirectsFileSupport/request_for_%7Bcid%7D.ipfs.example.com%2Fposts%2F:year%2F:month%2F:day%2F:title_redirects_with_301_and_placeholders%2C_per__redirects_file',
    'TestRedirectsFileSupport/request_for_%7Bcid%7D.ipfs.example.com%2Fsplat%2Fone.html_redirects_with_301_and_splat_placeholder%2C_per__redirects_file',
    'TestRedirectsFileSupport/newline:_request_for_$NEWLINE_REDIRECTS_DIR_HOSTNAME%2Fredirect-one_redirects_with_default_of_301%2C_per__redirects_file',

    // these test that responses are redirects - redirects are followed by
    // browsers automatically so we can't intercept the redirect
    'TestGatewaySubdomains',
    'TestGatewaySubdomainAndIPNS',
    'TestSubdomainGatewayDNSLinkInlining',
    'TestRedirectCanonicalIPNS',
    'TestUnixFSDirectoryListing/path_gw:_redirect_dir_listing_to_URL_with_trailing_slash',
    'TestUnixFSDirectoryListingOnSubdomainGateway',
    'TestGatewaySubdomains/request_for_example.com%2Fipfs%2F%7Bcid%7D_redirects_to_%7Bcid%7D.ipfs.example.com',

    // does not apply to service worker
    'TestProxyTunnelGatewaySubdomains',
    'TestProxyGatewaySubdomains',

    // last few tests
    'TestTar/GET_TAR_with_relative_paths_inside_root_works',
    'TestGatewaySymlink/Test_the_directory_listing',
    'TestGatewaySymlink/Test_the_symlink',
    'TestTrustlessCarEntityBytes/GET_CAR_with_entity-bytes_succeeds_even_if_the_gateway_is_missing_a_block_before_the_requested_range_%28Accept_Header%29/Body',
    'TestTrustlessCarEntityBytes/GET_CAR_with_entity-bytes_succeeds_even_if_the_gateway_is_missing_a_block_before_the_requested_range_%28format=car%29/Body',
    'TestTrustlessCarEntityBytes/GET_CAR_with_entity-bytes_succeeds_even_if_the_gateway_is_missing_a_block_after_the_requested_range_%28Accept_Header%29/Body',
    'TestTrustlessCarEntityBytes/GET_CAR_with_entity-bytes_succeeds_even_if_the_gateway_is_missing_a_block_after_the_requested_range_%28format=car%29/Body',

    // Media-viewer wrapper for top-level navigations to renderable content
    // (workaround for the Chromium "Save As" bug,
    // https://github.com/ipfs/service-worker-gateway/issues/574). Top-level
    // navigation to JSON / text / other renderable content now returns the
    // wrapper page (text/html) with the resource embedded in an iframe;
    // the conformance suite expects the bare content-type and body bytes
    // on the navigation response. The bytes are still served correctly to
    // subresource fetches and to `?download=true` requests; only the
    // document-level content-type and body change.
    //
    // Each entry is scoped to the specific failing leaf assertion so that
    // sibling sub-tests (status codes, range headers, etc.) keep running.
    'TestGatewayJsonCbor/GET_UnixFS_file_with_JSON_bytes_is_returned_with_application%2Fjson_Content-Type_-_without_headers/Header_Content-Type',
    'TestGatewayJsonCbor/GET_UnixFS_file_with_JSON_bytes_is_returned_with_application%2Fjson_Content-Type_-_without_headers/Body',
    'TestNativeDag/GET_plain_JSON_codec_with_format=json_returns_same_payload_as_format=dag-json_but_with_plain_Content-Type/Header_Content-Type',
    'TestNativeDag/GET_plain_JSON_codec_with_format=json_returns_same_payload_as_format=dag-json_but_with_plain_Content-Type/Body',
    'TestPlainCodec/GET_plain_JSON_codec_with_%3Fformat=_has_expected_json_Content-Type_and_body_as-is_-_full_request/Check_0/Header_Content-Disposition',
    'TestPlainCodec/GET_plain_JSON_codec_with_%3Fformat=_has_expected_json_Content-Type_and_body_as-is_-_full_request/Check_1/Body',
    'TestPlainCodec/GET_plain_JSON_codec_without_Accept_or_format=_has_expected_%22json%22_Content-Type_and_body_as-is_-_full_request/Check_0/Header_Content-Disposition',
    'TestPlainCodec/GET_plain_JSON_codec_without_Accept_or_format=_has_expected_%22json%22_Content-Type_and_body_as-is_-_full_request/Check_1/Body',
    'TestPathGatewayMiscellaneous/GET_for_%2Fipfs%2F_file_whose_filename_contains_percentage-encoded_characters_works/Body',
    'TestGatewayIPNSPath/GET_for_%2Fipns%2Fname_with_valid_V1\\+V2_signatures_succeeds/Body',
    'TestGatewayIPNSPath/GET_for_%2Fipns%2Fname_with_valid_V2_and_broken_V1_signature_succeeds/Body',
    'TestGatewayIPNSPath/GET_for_%2Fipns%2Fname_with_valid_V2-only_signature_succeeds/Body',
    'TestGatewayUnixFSFileRanges/GET_for_%2Fipfs%2F_file_includes_Accept-Ranges_header/Body'
  ]
}
