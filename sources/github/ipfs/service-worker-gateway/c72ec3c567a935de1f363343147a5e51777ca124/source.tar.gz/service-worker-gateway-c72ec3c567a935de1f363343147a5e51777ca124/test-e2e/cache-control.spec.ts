import { stop } from '@libp2p/interface'
import * as cbor from 'cborg'
import { createKuboRPCClient } from 'kubo-rpc-client'
import { test, expect } from './fixtures/config-test-fixtures.ts'
import { makeFetchRequest } from './fixtures/make-fetch-request.ts'
import type { KuboRPCClient } from 'kubo-rpc-client'
import type { CID } from 'multiformats/cid'

const object = {
  hello: 'world'
}

test.describe('cache-control', () => {
  let kubo: KuboRPCClient
  let cid: CID
  let block: Uint8Array

  test.beforeEach(async ({ page }) => {
    if (process.env.KUBO_GATEWAY == null || process.env.KUBO_GATEWAY === '') {
      throw new Error('KUBO_GATEWAY not set')
    }

    kubo = createKuboRPCClient(process.env.KUBO_RPC)

    block = cbor.encode(object)
    cid = await kubo.block.put(block, {
      format: 'cbor'
    })
  })

  test.afterEach(async () => {
    await stop(kubo)
  })

  test('should return block that is in local datastore', async ({ page, baseURL }) => {
    // try offline without block
    const response0 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`, {
      headers: {
        'cache-control': 'only-if-cached'
      }
    })
    expect(response0.status()).toBe(412)

    // fetch block from gateway
    const response1 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`)
    expect(response1.status()).toBe(200)
    expect(new Uint8Array(await response1.body())).toStrictEqual(block)

    // try again offline, should be cached now
    const response2 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`, {
      headers: {
        'cache-control': 'only-if-cached'
      }
    })

    expect(response2.status()).toBe(200)
    expect(new Uint8Array(await response2.body())).toStrictEqual(block)
  })

  test('should return 412 for block that is not in local datastore', async ({ page, baseURL }) => {
    const response = await makeFetchRequest(page, `${baseURL}/ipfs/bafybeicvjyaiqmgfe7wupl72gpf7cadwyjqf7nzsxrap6npgrgtd3d6m4a`, {
      headers: {
        'cache-control': 'only-if-cached'
      }
    })
    expect(response.status()).toBe(412)
  })
})
