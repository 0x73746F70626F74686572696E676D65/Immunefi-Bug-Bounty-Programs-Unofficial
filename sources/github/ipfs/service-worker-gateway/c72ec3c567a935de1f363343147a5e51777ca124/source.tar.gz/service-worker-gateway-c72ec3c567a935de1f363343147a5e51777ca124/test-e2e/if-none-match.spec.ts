import { stop } from '@libp2p/interface'
import * as cbor from 'cborg'
import { createKuboRPCClient } from 'kubo-rpc-client'
import { test, expect } from './fixtures/config-test-fixtures.ts'
import { makeFetchRequest } from './fixtures/make-fetch-request.ts'
import type { KuboRPCClient } from 'kubo-rpc-client'
import type { CID } from 'multiformats/cid'

const object = {
  hello: 'world'
}

test.describe('if-none-match', () => {
  let kubo: KuboRPCClient
  let cid: CID
  let block: Uint8Array

  test.beforeEach(async ({ page }) => {
    if (process.env.KUBO_GATEWAY == null || process.env.KUBO_GATEWAY === '') {
      throw new Error('KUBO_GATEWAY not set')
    }

    kubo = createKuboRPCClient(process.env.KUBO_RPC)

    block = cbor.encode(object)
    cid = await kubo.block.put(block, {
      format: 'cbor'
    })
  })

  test.afterEach(async () => {
    await stop(kubo)
  })

  test('should return 304 if the etag matches', async ({ page, baseURL }) => {
    const response0 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`)
    expect(response0.status()).toBe(200)

    const etag = await response0.headerValue('etag') ?? ''
    expect(etag).toContain(cid.toString())

    const response1 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`, {
      headers: {
        'if-none-match': etag
      }
    })
    expect(response1.status()).toBe(304)
  })

  test('should return 304 if the etag matches one of the etags', async ({ page, baseURL }) => {
    const response0 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`)
    expect(response0.status()).toBe(200)

    const etag = await response0.headerValue('etag') ?? ''
    expect(etag).toContain(cid.toString())

    const response1 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`, {
      headers: {
        'if-none-match': `"foo", W/"bar", ${etag}, "baz"`
      }
    })
    expect(response1.status()).toBe(304)
  })

  test('should return 304 if the etag matches a wildcard', async ({ page, baseURL }) => {
    const response0 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`)
    expect(response0.status()).toBe(200)

    const etag = await response0.headerValue('etag') ?? ''
    expect(etag).toContain(cid.toString())

    const response1 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`, {
      headers: {
        'if-none-match': '*'
      }
    })
    expect(response1.status()).toBe(304)
  })

  test('should return 304 if the etag matches a weak value', async ({ page, baseURL }) => {
    const response0 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`)
    expect(response0.status()).toBe(200)

    const etag = await response0.headerValue('etag') ?? ''
    expect(etag).toContain(cid.toString())

    const response1 = await makeFetchRequest(page, `${baseURL}/ipfs/${cid}`, {
      headers: {
        'if-none-match': `W/"${cid}.dag-cbor"`
      }
    })
    expect(response1.status()).toBe(304)
  })
})
