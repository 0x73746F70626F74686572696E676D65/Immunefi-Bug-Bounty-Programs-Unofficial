import { readFileSync } from 'node:fs'
import { parseRequest } from '../../src/lib/parse-request-cheap.ts'
import type { Page, Response } from 'playwright'

export interface LoadWithServiceWorkerOptions {
  /**
   * See Playwright Page.goto args
   *
   * @see {Page.goto}
   */
  referer?: string

  /**
   * See Playwright Page.goto args
   *
   * @see {Page.goto}
   */
  timeout?: number

  /**
   * See Playwright Page.goto args
   *
   * @see {Page.goto}
   */
  waitUntil?: 'load' | 'domcontentloaded' | 'networkidle' | 'commit'
}

const DOWNLOAD_CONTENT_TYPES: string[] = [
  'application/vnd.ipld.dag-json',
  'application/vnd.ipld.dag-cbor',
  'application/vnd.ipld.dag-pb',
  'application/vnd.ipld.car',
  'application/vnd.ipld.raw',
  'application/cbor',
  'application/octet-stream',
  'application/x-tar'
]

const DOWNLOAD_ENCODINGS: string[] = [
  'gzip'
]

async function wasDownloaded (response: Response): Promise<boolean> {
  const contentType = await response.headerValue('content-type')

  // if the browser downloaded the file, stream the download back to
  // the conformance test client, otherwise just send the response
  // body
  if (contentType != null && DOWNLOAD_CONTENT_TYPES.includes(contentType)) {
    return true
  }

  const encoding = await response.headerValue('accept-encoding')

  if (encoding != null && DOWNLOAD_ENCODINGS.includes(encoding)) {
    return true
  }

  // check content disposition - attachment means it was downloaded, inline or
  // absent means the browser displayed it
  const disposition = await response.headerValue('content-disposition')

  if (disposition?.includes('attachment') === true) {
    return true
  }

  return false
}

/**
 * Navigates to the passed resource and waits for a response from the service
 * worker that does not include a URL param to redirect to
 */
export async function loadWithServiceWorker (page: Page, resource: string, options?: LoadWithServiceWorkerOptions): Promise<Response> {
  const downloadPromise = page.waitForEvent('download')
    .catch(() => {})

  const resourceUrl = new URL(resource)
  const parsedRequest = parseRequest(resource, new URL(`${resourceUrl.protocol}//${resourceUrl.host}`))
  let target = resourceUrl

  if (parsedRequest.type === 'subdomain' || parsedRequest.type === 'path') {
    target = parsedRequest.subdomainURL
  }

  const [
    response
  ] = await Promise.all([
    page.waitForResponse(async (response) => {
      // used when process.env.NODE_ENV === 'test'
      if ((await response.headerValue('service-worker-handler')) === 'content-request-handler') {
        return true
      }

      // used when benchmarking prod/dev service worker gateway in chrome -
      // cannot use this for e2e tests because `fromServiceWorker` is broken in
      // firefox
      if (response.url() === target.toString() && response.fromServiceWorker()) {
        return true
      }

      return false
    }, options),
    page.goto(resource, {
      waitUntil: 'networkidle',
      ...options
    })
      .catch((err) => {
        const message = `${err?.message?.toLowerCase()}`

        if (message.includes('is interrupted by another navigation to')) {
          // accepting the origin isolation warning can interrupt the page load
          return
        } else if (message.includes('download is starting')) {
          // requesting content in a format that causes a download can interrupt
          // the page load
          return
        }

        throw err
      })
  ])

  if (await wasDownloaded(response)) {
    const download = await downloadPromise

    if (download == null) {
      throw new Error('Download was null after awaiting')
    }

    const buf = readFileSync(await download.path())
    response.body = async () => buf
    response.text = async () => new TextDecoder().decode(await response.body())
    response.json = async () => JSON.parse(await response.text())
  }

  return response
}
