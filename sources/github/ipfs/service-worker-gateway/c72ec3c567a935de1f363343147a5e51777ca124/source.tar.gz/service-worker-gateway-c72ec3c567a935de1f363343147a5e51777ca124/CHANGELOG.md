# Changelog

## [3.4.15](https://github.com/ipfs/service-worker-gateway/compare/v3.4.14...v3.4.15) (2026-08-27)


### Bug Fixes

* use ipfs-uri where available ([#1194](https://github.com/ipfs/service-worker-gateway/issues/1194)) ([2543c2f](https://github.com/ipfs/service-worker-gateway/commit/2543c2fa23b9f9095d178bcda8c7bc296884a67d))

## [3.4.14](https://github.com/ipfs/service-worker-gateway/compare/v3.4.13...v3.4.14) (2026-08-19)


### Bug Fixes

* update libp2p version to get smaller bundle size ([#1191](https://github.com/ipfs/service-worker-gateway/issues/1191)) ([7b8056d](https://github.com/ipfs/service-worker-gateway/commit/7b8056dbed8ae85ffabdcbc82cab44be87968cc6))

## [3.4.13](https://github.com/ipfs/service-worker-gateway/compare/v3.4.12...v3.4.13) (2026-08-18)


### Bug Fixes

* update @helia/libp2p ([#1186](https://github.com/ipfs/service-worker-gateway/issues/1186)) ([2576c49](https://github.com/ipfs/service-worker-gateway/commit/2576c49c9a5162ec2d645f0b6cf1564e7dcf7c67))

## [3.4.12](https://github.com/ipfs/service-worker-gateway/compare/v3.4.11...v3.4.12) (2026-07-29)


### Bug Fixes

* use iife instead of esm bundle ([#1176](https://github.com/ipfs/service-worker-gateway/issues/1176)) ([2789adb](https://github.com/ipfs/service-worker-gateway/commit/2789adbb6c71ca38dc73ded3eaa18f848925e9dc))

## [3.4.11](https://github.com/ipfs/service-worker-gateway/compare/v3.4.10...v3.4.11) (2026-07-28)


### Bug Fixes

* cyclic reload from a poisoned cdn cache ([#1156](https://github.com/ipfs/service-worker-gateway/issues/1156)) ([9e0c642](https://github.com/ipfs/service-worker-gateway/commit/9e0c642ee6a69ed603a941970378b28eec849140)), closes [#1155](https://github.com/ipfs/service-worker-gateway/issues/1155)
* do not wait for UI forever ([#1163](https://github.com/ipfs/service-worker-gateway/issues/1163)) ([5bda231](https://github.com/ipfs/service-worker-gateway/commit/5bda231fbd4058587e9cac767a576ef2e6a726e6))
* only wait for ui in WebKit when navigating ([#1171](https://github.com/ipfs/service-worker-gateway/issues/1171)) ([ca93870](https://github.com/ipfs/service-worker-gateway/commit/ca9387019bb09ca50829c05b681d7240e14c99ed))
* remove transport/address filters ([#1173](https://github.com/ipfs/service-worker-gateway/issues/1173)) ([54513a5](https://github.com/ipfs/service-worker-gateway/commit/54513a5c8293ca3817620baf8acbaa290193e4c5))
* use cheap parse request in ui ([#1172](https://github.com/ipfs/service-worker-gateway/issues/1172)) ([a116557](https://github.com/ipfs/service-worker-gateway/commit/a116557b9fb1e72c00fdb103c0541c03c8973529))
* wait for skipWaiting promise ([#1162](https://github.com/ipfs/service-worker-gateway/issues/1162)) ([cd4d19b](https://github.com/ipfs/service-worker-gateway/commit/cd4d19b324623aa5fc72220c26815933306ac3bd))
* wait for UI before reloading in Safari ([#1161](https://github.com/ipfs/service-worker-gateway/issues/1161)) ([85da529](https://github.com/ipfs/service-worker-gateway/commit/85da52948e035797da75540c45a98155914ec885)), closes [#1159](https://github.com/ipfs/service-worker-gateway/issues/1159)

## [3.4.10](https://github.com/ipfs/service-worker-gateway/compare/v3.4.9...v3.4.10) (2026-07-09)


### Bug Fixes

* downgrade `@cloudflare/workers-types` ([5b79e77](https://github.com/ipfs/service-worker-gateway/commit/5b79e7711512d90b70c51c57f570a7662ca06b30))
* revert @cloudflare/workers-types upgrade ([c2b0b5e](https://github.com/ipfs/service-worker-gateway/commit/c2b0b5e639d1f96293243cd4a335e3c4f53053fd))

## [3.4.9](https://github.com/ipfs/service-worker-gateway/compare/v3.4.8...v3.4.9) (2026-07-09)


### Bug Fixes

* display correct namespace in directory listing ([#1127](https://github.com/ipfs/service-worker-gateway/issues/1127)) ([3997469](https://github.com/ipfs/service-worker-gateway/commit/399746900920a30dfd5a13530d1229c359f02f9a)), closes [#1120](https://github.com/ipfs/service-worker-gateway/issues/1120)
* remove cache on failed asset get ([#1151](https://github.com/ipfs/service-worker-gateway/issues/1151)) ([86255f8](https://github.com/ipfs/service-worker-gateway/commit/86255f8ab7f2a68492e9b935ba36f38c9e8701eb))
* remove service worker ttl ([#1147](https://github.com/ipfs/service-worker-gateway/issues/1147)) ([0b4ea0d](https://github.com/ipfs/service-worker-gateway/commit/0b4ea0db763df97a2e7e3fe955d2c540ac801e70))
* update deps ([f788639](https://github.com/ipfs/service-worker-gateway/commit/f78863997d25d53ee289c333af6477af1db3fcda))
* use module version for cache version ([#1152](https://github.com/ipfs/service-worker-gateway/issues/1152)) ([663990c](https://github.com/ipfs/service-worker-gateway/commit/663990c77a9f07219aa37dc3a1c7164025a16c02))
* use persistent storage ([#1137](https://github.com/ipfs/service-worker-gateway/issues/1137)) ([5fcbb21](https://github.com/ipfs/service-worker-gateway/commit/5fcbb21c0bdee3b942068d83d3734ecee6918b15)), closes [#996](https://github.com/ipfs/service-worker-gateway/issues/996)
* use wrapper to load sw ([#1149](https://github.com/ipfs/service-worker-gateway/issues/1149)) ([5bb7514](https://github.com/ipfs/service-worker-gateway/commit/5bb751464ffb13f9235897fa8870e1a2793667f7)), closes [#1146](https://github.com/ipfs/service-worker-gateway/issues/1146)

## [3.4.8](https://github.com/ipfs/service-worker-gateway/compare/v3.4.7...v3.4.8) (2026-06-08)


### Bug Fixes

* update verified-fetch to include cache-control directives ([239eb02](https://github.com/ipfs/service-worker-gateway/commit/239eb02fc822fdfe97992190b7a0ca6342506f4c))

## [3.4.7](https://github.com/ipfs/service-worker-gateway/compare/v3.4.6...v3.4.7) (2026-06-08)


### Bug Fixes

* only show logs on error page if there are logs to show ([#1112](https://github.com/ipfs/service-worker-gateway/issues/1112)) ([c8f2874](https://github.com/ipfs/service-worker-gateway/commit/c8f287459ed19e622949149dc5ba0f93046f8abd))
* respect cache-control response header ([#1109](https://github.com/ipfs/service-worker-gateway/issues/1109)) ([023d3d0](https://github.com/ipfs/service-worker-gateway/commit/023d3d026581baf39afa0d52ead57a6c634a6bf9))
* show clear notice on unsupported browsers ([#1115](https://github.com/ipfs/service-worker-gateway/issues/1115)) ([771c838](https://github.com/ipfs/service-worker-gateway/commit/771c838a1ffde0cf6509907524dd6af68640e16a))

## [3.4.6](https://github.com/ipfs/service-worker-gateway/compare/v3.4.5...v3.4.6) (2026-06-01)


### Bug Fixes

* disable logging on production ([4e988e4](https://github.com/ipfs/service-worker-gateway/commit/4e988e400ad97935b4e05699e7c010a876a62998))

## [3.4.5](https://github.com/ipfs/service-worker-gateway/compare/v3.4.4...v3.4.5) (2026-05-31)


### Bug Fixes

* enable logging on inbrowser.link ([#1102](https://github.com/ipfs/service-worker-gateway/issues/1102)) ([18c837d](https://github.com/ipfs/service-worker-gateway/commit/18c837d8973f83b0593737aee3c6a34c8087fc8f))
* remove error message if input emptied ([#1101](https://github.com/ipfs/service-worker-gateway/issues/1101)) ([358de78](https://github.com/ipfs/service-worker-gateway/commit/358de782884e7c775a4496d66b8132f6109ec7d5))

## [3.4.4](https://github.com/ipfs/service-worker-gateway/compare/v3.4.3...v3.4.4) (2026-05-29)


### Bug Fixes

* make url hash available to loaded HTML page ([#1089](https://github.com/ipfs/service-worker-gateway/issues/1089)) ([cac1087](https://github.com/ipfs/service-worker-gateway/commit/cac1087f20944501d3a354ecc17619cf73e851ed)), closes [#1088](https://github.com/ipfs/service-worker-gateway/issues/1088)
* start libp2p and patch block brokers/webtransport transport ([#1100](https://github.com/ipfs/service-worker-gateway/issues/1100)) ([0c87b35](https://github.com/ipfs/service-worker-gateway/commit/0c87b355f10eaa7a65aa7aa26d0c2bd6f84d07a9))

## [3.4.3](https://github.com/ipfs/service-worker-gateway/compare/v3.4.2...v3.4.3) (2026-05-19)


### Bug Fixes

* show "Check CID Availability" button on downloading page ([#1085](https://github.com/ipfs/service-worker-gateway/issues/1085)) ([de23da1](https://github.com/ipfs/service-worker-gateway/commit/de23da167a451eacdd054cd25a09e6b6de926688))
* **snippets:** installer cache poisoning ([#1081](https://github.com/ipfs/service-worker-gateway/issues/1081)) ([b9ffe7d](https://github.com/ipfs/service-worker-gateway/commit/b9ffe7d45289457bda8982ea9d4e57e17e5052a8))

## [3.4.2](https://github.com/ipfs/service-worker-gateway/compare/v3.4.1...v3.4.2) (2026-05-18)


### Bug Fixes

* improve 502 error messaging ([#1078](https://github.com/ipfs/service-worker-gateway/issues/1078)) ([73210cd](https://github.com/ipfs/service-worker-gateway/commit/73210cdfa3ae13bb354296ac183b402aa0e78603)), closes [#1070](https://github.com/ipfs/service-worker-gateway/issues/1070)
* make download block button download dag ([#1079](https://github.com/ipfs/service-worker-gateway/issues/1079)) ([bd318ec](https://github.com/ipfs/service-worker-gateway/commit/bd318ec7eefd4b7be58e7d2512b72470f0611cc6))

## [3.4.1](https://github.com/ipfs/service-worker-gateway/compare/v3.4.0...v3.4.1) (2026-05-18)


### Bug Fixes

* set up go before node ([#1076](https://github.com/ipfs/service-worker-gateway/issues/1076)) ([c94c120](https://github.com/ipfs/service-worker-gateway/commit/c94c1203944f3688085bff4234bb57b87ab03963))

## [3.4.0](https://github.com/ipfs/service-worker-gateway/compare/v3.3.1...v3.4.0) (2026-05-16)


### Features

* enable webtransport on all supporting browsers ([#1064](https://github.com/ipfs/service-worker-gateway/issues/1064)) ([f0cb785](https://github.com/ipfs/service-worker-gateway/commit/f0cb785ac08780843bbb71eeb484cff7b663d241))


### Bug Fixes

* display translated hamt shard entries ([#1074](https://github.com/ipfs/service-worker-gateway/issues/1074)) ([16b8cf4](https://github.com/ipfs/service-worker-gateway/commit/16b8cf45d926e149d3efbb2624c123bbd3e9403e)), closes [#1066](https://github.com/ipfs/service-worker-gateway/issues/1066)
* encode filename in url as uri component ([#1071](https://github.com/ipfs/service-worker-gateway/issues/1071)) ([25ee418](https://github.com/ipfs/service-worker-gateway/commit/25ee4183a0f467258200cbc3d9f446b971f72f58))
* escape download form input and block download/preview links ([#1073](https://github.com/ipfs/service-worker-gateway/issues/1073)) ([9172fe2](https://github.com/ipfs/service-worker-gateway/commit/9172fe2d8506e89410f82c894de659f4c7e093ae))
* only show size if defined ([6300c2b](https://github.com/ipfs/service-worker-gateway/commit/6300c2b8f736b1ed2e737b758b06cca869c974fc))
* share edge cache across SPA paths per subdomain ([#1061](https://github.com/ipfs/service-worker-gateway/issues/1061)) ([cbd5cd6](https://github.com/ipfs/service-worker-gateway/commit/cbd5cd606f7d30ee34061758956b71604e97fabc))
* use ipfs path as title of dir listing ([#1049](https://github.com/ipfs/service-worker-gateway/issues/1049)) ([60ee8f7](https://github.com/ipfs/service-worker-gateway/commit/60ee8f7d2ebbf1d9176a01e03e55a48afb2b9d95))

## [3.3.1](https://github.com/ipfs/service-worker-gateway/compare/v3.3.0...v3.3.1) (2026-05-11)


### Bug Fixes

* update benchmark ([3c7cdba](https://github.com/ipfs/service-worker-gateway/commit/3c7cdbabb4b3a5207e62b0a0485f2e3dd82087b4))

## [3.3.0](https://github.com/ipfs/service-worker-gateway/compare/v3.2.0...v3.3.0) (2026-05-08)


### Features

* multibase parity with Kubo / Rainbow ([#1040](https://github.com/ipfs/service-worker-gateway/issues/1040)) ([405560b](https://github.com/ipfs/service-worker-gateway/commit/405560bcaefd56a9aa21829e2101b3887f4a2de4))


### Bug Fixes

* wrap renderable media in viewer page ([#1039](https://github.com/ipfs/service-worker-gateway/issues/1039)) ([f230fcb](https://github.com/ipfs/service-worker-gateway/commit/f230fcb38712f95a07b61d52e13d0f47bd749973))

## [3.2.0](https://github.com/ipfs/service-worker-gateway/compare/v3.1.7...v3.2.0) (2026-04-21)


### Features

* show ui after download ([#1031](https://github.com/ipfs/service-worker-gateway/issues/1031)) ([4470da0](https://github.com/ipfs/service-worker-gateway/commit/4470da04e3a7cee68641263cb28fc0a6e9874a52)), closes [#1025](https://github.com/ipfs/service-worker-gateway/issues/1025)


### Bug Fixes

* improve 502 error message when streaming fails ([#1033](https://github.com/ipfs/service-worker-gateway/issues/1033)) ([5bbfc70](https://github.com/ipfs/service-worker-gateway/commit/5bbfc701dcc7e3662e4af025f6b390f8a0d9dbd4))
* remove invalid conversions ([#1029](https://github.com/ipfs/service-worker-gateway/issues/1029)) ([d2e08ca](https://github.com/ipfs/service-worker-gateway/commit/d2e08ca4410c6d143a363d238948d2acdcb95dc5))
* remove preview link on downloading page ([#1034](https://github.com/ipfs/service-worker-gateway/issues/1034)) ([706f274](https://github.com/ipfs/service-worker-gateway/commit/706f274706152b1a7eb2961480ca3edf9e456dcc))
* set subdomain url from stored form input ([#1030](https://github.com/ipfs/service-worker-gateway/issues/1030)) ([b0caf3d](https://github.com/ipfs/service-worker-gateway/commit/b0caf3d3c94456ba14ed9784b4cf67b434a48cd9))
* update about page text ([#1028](https://github.com/ipfs/service-worker-gateway/issues/1028)) ([26ead6d](https://github.com/ipfs/service-worker-gateway/commit/26ead6d639032f9d477a5b1594bfa453b4a33456))

## [3.1.7](https://github.com/ipfs/service-worker-gateway/compare/v3.1.6...v3.1.7) (2026-04-09)


### Bug Fixes

* include server-timing header on abort ([#1023](https://github.com/ipfs/service-worker-gateway/issues/1023)) ([2f8961b](https://github.com/ipfs/service-worker-gateway/commit/2f8961b7be08b2f1bc73e69b16b4dc30729e7d7a))

## [3.1.6](https://github.com/ipfs/service-worker-gateway/compare/v3.1.5...v3.1.6) (2026-04-09)


### Bug Fixes

* improve error message when streaming fails ([#1021](https://github.com/ipfs/service-worker-gateway/issues/1021)) ([d1a6c67](https://github.com/ipfs/service-worker-gateway/commit/d1a6c674a61a0bf049104c4564a2595fec6a3793))
* restore logo ([#1012](https://github.com/ipfs/service-worker-gateway/issues/1012)) ([b90b2ff](https://github.com/ipfs/service-worker-gateway/commit/b90b2ffe97f42f01339f1bc58ae97170c780d9ed))
* update deps to support server-timing header ([#1020](https://github.com/ipfs/service-worker-gateway/issues/1020)) ([5c62280](https://github.com/ipfs/service-worker-gateway/commit/5c6228024b1bcfb01407e320ca352408a8700bda)), closes [#956](https://github.com/ipfs/service-worker-gateway/issues/956)
* update helia deps ([#1010](https://github.com/ipfs/service-worker-gateway/issues/1010)) ([94116b2](https://github.com/ipfs/service-worker-gateway/commit/94116b29757d4ccb8087c83fce805cdf5c8eb23a))

## [3.1.5](https://github.com/ipfs/service-worker-gateway/compare/v3.1.4...v3.1.5) (2026-03-05)


### Bug Fixes

* reduce initial bundle size and improve load order ([#1006](https://github.com/ipfs/service-worker-gateway/issues/1006)) ([16e5051](https://github.com/ipfs/service-worker-gateway/commit/16e50510ac6ae333d19b372e3d79d123439de87c))

## [3.1.4](https://github.com/ipfs/service-worker-gateway/compare/v3.1.3...v3.1.4) (2026-02-26)


### Bug Fixes

* handle DNSLink in directory listing links correctly ([#1003](https://github.com/ipfs/service-worker-gateway/issues/1003)) ([2b7c053](https://github.com/ipfs/service-worker-gateway/commit/2b7c053d5ad7c22a6e814cedc7434adb4e07b309))
* remove conversion links ([#1001](https://github.com/ipfs/service-worker-gateway/issues/1001)) ([08915a7](https://github.com/ipfs/service-worker-gateway/commit/08915a7058ddea622bd512211be08d63b4038caf)), closes [#1000](https://github.com/ipfs/service-worker-gateway/issues/1000)

## [3.1.3](https://github.com/ipfs/service-worker-gateway/compare/v3.1.2...v3.1.3) (2026-02-25)


### Bug Fixes

* update verified-fetch to handle paths in IPNS records correctly ([#997](https://github.com/ipfs/service-worker-gateway/issues/997)) ([87d493c](https://github.com/ipfs/service-worker-gateway/commit/87d493cf2d8e41e664231e68ba6fbfff5d453948))

## [3.1.2](https://github.com/ipfs/service-worker-gateway/compare/v3.1.1...v3.1.2) (2026-02-24)


### Bug Fixes

* **ci:** use CF_PAGES_TOKEN for deployment log fetching ([7ee6077](https://github.com/ipfs/service-worker-gateway/commit/7ee607775ba92cafc24fa12036e0048fe5b9211e))
* resolve DNSLink records that point to IPNS names ([#994](https://github.com/ipfs/service-worker-gateway/issues/994)) ([7b5a54a](https://github.com/ipfs/service-worker-gateway/commit/7b5a54a91e7d06c74e40385a9b0b3098bf2b6de2)), closes [#991](https://github.com/ipfs/service-worker-gateway/issues/991)

## [3.1.1](https://github.com/ipfs/service-worker-gateway/compare/v3.1.0...v3.1.1) (2026-02-20)


### Bug Fixes

* remove double render ([#987](https://github.com/ipfs/service-worker-gateway/issues/987)) ([87a0a2e](https://github.com/ipfs/service-worker-gateway/commit/87a0a2e51312e7af1d2272290fd8c069a16691ee))

## [3.1.0](https://github.com/ipfs/service-worker-gateway/compare/v3.0.1...v3.1.0) (2026-02-20)


### Features

* pre-connect to routers and resolve gateway dns ([#984](https://github.com/ipfs/service-worker-gateway/issues/984)) ([9b05c43](https://github.com/ipfs/service-worker-gateway/commit/9b05c438a11b15ed0aefbbf9a388cc2d2a44a791))
* support _redirects file ([#978](https://github.com/ipfs/service-worker-gateway/issues/978)) ([e906aaa](https://github.com/ipfs/service-worker-gateway/commit/e906aaac143ebf2d5ae48a8f30fa30e911f53f28))


### Bug Fixes

* handle hard refresh ([#983](https://github.com/ipfs/service-worker-gateway/issues/983)) ([4ce0b09](https://github.com/ipfs/service-worker-gateway/commit/4ce0b0940bb338eb68f81c9d81698370ac5fd78f))
* load CSS dynamically ([#986](https://github.com/ipfs/service-worker-gateway/issues/986)) ([d263589](https://github.com/ipfs/service-worker-gateway/commit/d26358969c79172ce3a5cacc32f3e41c886686fb))
* skip PWA manifest on CID subdomains ([#975](https://github.com/ipfs/service-worker-gateway/issues/975)) ([67ad16d](https://github.com/ipfs/service-worker-gateway/commit/67ad16d5b7fc82c41a45510c6ed563b6131ba25e))

## [3.0.1](https://github.com/ipfs/service-worker-gateway/compare/v3.0.0...v3.0.1) (2026-02-13)


### Bug Fixes

* remove support for gateway hints ([#973](https://github.com/ipfs/service-worker-gateway/issues/973)) ([43e4e8c](https://github.com/ipfs/service-worker-gateway/commit/43e4e8cdd2a4a8684472f183b6ebe3bd316d0b98)), closes [#972](https://github.com/ipfs/service-worker-gateway/issues/972)

## [3.0.0](https://github.com/ipfs/service-worker-gateway/compare/v2.2.0...v3.0.0) (2026-02-05)


### ⚠ BREAKING CHANGES

* the config page has been removed
* path gateway or access via IP addresses is no longer supported

### Features

* parse gateway from entered URL ([#966](https://github.com/ipfs/service-worker-gateway/issues/966)) ([26e3b0d](https://github.com/ipfs/service-worker-gateway/commit/26e3b0dcd40dbc2facdfc226a3a011631235238c)), closes [#814](https://github.com/ipfs/service-worker-gateway/issues/814)
* remove path gateway support ([#959](https://github.com/ipfs/service-worker-gateway/issues/959)) ([9c7ddfd](https://github.com/ipfs/service-worker-gateway/commit/9c7ddfd6ec1da457d2b7bd7e8d04a34259e689b2))
* support gateway hints ([#968](https://github.com/ipfs/service-worker-gateway/issues/968)) ([8b858eb](https://github.com/ipfs/service-worker-gateway/commit/8b858eb30f0cdb8edbf50eb180cba32140977aac)), closes [#814](https://github.com/ipfs/service-worker-gateway/issues/814)


### Bug Fixes

* flash of unstyled content ([#969](https://github.com/ipfs/service-worker-gateway/issues/969)) ([cc9f7a4](https://github.com/ipfs/service-worker-gateway/commit/cc9f7a46b6884bd1cebdc8d29aeb0cf5161e8e3c))
* remove config page ([#963](https://github.com/ipfs/service-worker-gateway/issues/963)) ([a13fbc6](https://github.com/ipfs/service-worker-gateway/commit/a13fbc6f6afa5504be86ae8023f8b3c478a6cd32))
* show provider routing source ([#971](https://github.com/ipfs/service-worker-gateway/issues/971)) ([0066239](https://github.com/ipfs/service-worker-gateway/commit/00662394c286ac7cf357d14e66486c255a6786ea))

## [2.2.0](https://github.com/ipfs/service-worker-gateway/compare/v2.1.2...v2.2.0) (2026-01-20)


### Features

* implement retrieval timeout ([#953](https://github.com/ipfs/service-worker-gateway/issues/953)) ([0b7aa87](https://github.com/ipfs/service-worker-gateway/commit/0b7aa8710696f5ac703eeacc1b85e5550de70e7b)), closes [#901](https://github.com/ipfs/service-worker-gateway/issues/901)
* implement URI router for registerProtocolHandler ([#951](https://github.com/ipfs/service-worker-gateway/issues/951)) ([49ff20d](https://github.com/ipfs/service-worker-gateway/commit/49ff20d3ebef1aed54fb51012087576cdd2fcac8)), closes [#214](https://github.com/ipfs/service-worker-gateway/issues/214)


### Bug Fixes

* allow passthrough to for non-intercepted URLs ([#949](https://github.com/ipfs/service-worker-gateway/issues/949)) ([192d290](https://github.com/ipfs/service-worker-gateway/commit/192d2907db0ed4dfdf1f8276bd1e7eee34cf6b4d)), closes [#947](https://github.com/ipfs/service-worker-gateway/issues/947)
* re-encode domain on redirect ([#958](https://github.com/ipfs/service-worker-gateway/issues/958)) ([a93a474](https://github.com/ipfs/service-worker-gateway/commit/a93a474190ae08c5af39649aa3b4ed58fc7d0112)), closes [#957](https://github.com/ipfs/service-worker-gateway/issues/957)
* reduce bundle size ([#955](https://github.com/ipfs/service-worker-gateway/issues/955)) ([eea42d7](https://github.com/ipfs/service-worker-gateway/commit/eea42d731e323f5a4bb1f449ff14a28a9085cd35))

## [2.1.2](https://github.com/ipfs/service-worker-gateway/compare/v2.1.1...v2.1.2) (2026-01-12)


### Bug Fixes

* export intermediate subshards in car files ([#948](https://github.com/ipfs/service-worker-gateway/issues/948)) ([8f3fa03](https://github.com/ipfs/service-worker-gateway/commit/8f3fa0365642314f83193d2ddc5d844290dbb86f))
* parse path/subdomain gateway url as ipfs/ipns url ([#946](https://github.com/ipfs/service-worker-gateway/issues/946)) ([ea9e4f4](https://github.com/ipfs/service-worker-gateway/commit/ea9e4f4c2013ef1fc95eeefb88782d4893d03a9d))
* support accept header as per conformance tests ([#940](https://github.com/ipfs/service-worker-gateway/issues/940)) ([87dbae8](https://github.com/ipfs/service-worker-gateway/commit/87dbae86731cf62751e375c6d38e3baa2f59f07e))

## [2.1.1](https://github.com/ipfs/service-worker-gateway/compare/v2.1.0...v2.1.1) (2025-12-18)


### Bug Fixes

* include dir index config in cache key ([#932](https://github.com/ipfs/service-worker-gateway/issues/932)) ([72a57a1](https://github.com/ipfs/service-worker-gateway/commit/72a57a104fdf9a3b94a0f2cbc55b659413bae629))
* proxy all requests to root ([#935](https://github.com/ipfs/service-worker-gateway/issues/935)) ([258ad5c](https://github.com/ipfs/service-worker-gateway/commit/258ad5c625cd62eff46f14e494e899d070384181))

## [2.1.0](https://github.com/ipfs/service-worker-gateway/compare/v2.0.0...v2.1.0) (2025-11-21)


### Features

* add download form ([#920](https://github.com/ipfs/service-worker-gateway/issues/920)) ([6f2ecc5](https://github.com/ipfs/service-worker-gateway/commit/6f2ecc5fcfc2033c6c7728eca9d9d8180e98baa8))
* update error pages ([#902](https://github.com/ipfs/service-worker-gateway/issues/902)) ([5b649a8](https://github.com/ipfs/service-worker-gateway/commit/5b649a8dd318ce289ed7dcb80e846ba6be3141de)), closes [#875](https://github.com/ipfs/service-worker-gateway/issues/875) [#876](https://github.com/ipfs/service-worker-gateway/issues/876)


### Bug Fixes

* ensure IPNS results go in the mutable cache ([#912](https://github.com/ipfs/service-worker-gateway/issues/912)) ([e5b9812](https://github.com/ipfs/service-worker-gateway/commit/e5b9812510f578278eddf847ec5eb034f494da5e))
* internal error page styling ([#893](https://github.com/ipfs/service-worker-gateway/issues/893)) ([16ec8c5](https://github.com/ipfs/service-worker-gateway/commit/16ec8c5cdec085c529d0f522bcfa147e247b1941)), closes [#875](https://github.com/ipfs/service-worker-gateway/issues/875)
* prevent endless loops ([#911](https://github.com/ipfs/service-worker-gateway/issues/911)) ([19cdb7c](https://github.com/ipfs/service-worker-gateway/commit/19cdb7cb07f7943cae1a538978db31a410abe5b8))
* strip root hash from URL on error page ([#907](https://github.com/ipfs/service-worker-gateway/issues/907)) ([1535f6f](https://github.com/ipfs/service-worker-gateway/commit/1535f6fbd3dafb1e2e1477a0da34373648907c0c))
* structural overhaul ([#906](https://github.com/ipfs/service-worker-gateway/issues/906)) ([61eea77](https://github.com/ipfs/service-worker-gateway/commit/61eea77930f716244af895807d29aa9b4672d56c))
* support base16 CIDs and IPNS names ([#913](https://github.com/ipfs/service-worker-gateway/issues/913)) ([d62632e](https://github.com/ipfs/service-worker-gateway/commit/d62632e5e138149b24dad1a2beac3bc5d5032d29)), closes [#745](https://github.com/ipfs/service-worker-gateway/issues/745)
* update logo ([#921](https://github.com/ipfs/service-worker-gateway/issues/921)) ([ca0a5ad](https://github.com/ipfs/service-worker-gateway/commit/ca0a5ad20e5f9aac7a50047cade51f0a2d7a31b0))
* use home icon instead of download ([#917](https://github.com/ipfs/service-worker-gateway/issues/917)) ([b39a55d](https://github.com/ipfs/service-worker-gateway/commit/b39a55d16c04d12d85992ec0391d9ccc3a06519a)), closes [#916](https://github.com/ipfs/service-worker-gateway/issues/916)

## [2.0.0](https://github.com/ipfs/service-worker-gateway/compare/v1.14.2...v2.0.0) (2025-10-20)


### ⚠ BREAKING CHANGES

* upgrades helia to v6, verified fetch to v4 and libp2p to v3

### deps

* upgrade helia to v6, verified fetch to v4 and libp2p to v3 ([#881](https://github.com/ipfs/service-worker-gateway/issues/881)) ([b28ab8f](https://github.com/ipfs/service-worker-gateway/commit/b28ab8f7912ff52a8eccdde1f3e03f4d1ef3b6d5))

## [1.14.2](https://github.com/ipfs/service-worker-gateway/compare/v1.14.1...v1.14.2) (2025-09-23)


### Bug Fixes

* reloading a page with hash fragment doesnt err ([#860](https://github.com/ipfs/service-worker-gateway/issues/860)) ([4a053c4](https://github.com/ipfs/service-worker-gateway/commit/4a053c47a0389a9e56518b330af8fab3a983c8b5))

## [1.14.1](https://github.com/ipfs/service-worker-gateway/compare/v1.14.0...v1.14.1) (2025-09-18)


### Bug Fixes

* no implicit any, add missing types ([#852](https://github.com/ipfs/service-worker-gateway/issues/852)) ([1d743ab](https://github.com/ipfs/service-worker-gateway/commit/1d743ab22d2f870cbbae0522dad7a0a5273e7744))
* refresh and ttl edgecases ([#841](https://github.com/ipfs/service-worker-gateway/issues/841)) ([6a532c6](https://github.com/ipfs/service-worker-gateway/commit/6a532c6aafae6cb3393bfa1314afb4cdfe78dacb))
* svg content-type correction; update helia deps ([#853](https://github.com/ipfs/service-worker-gateway/issues/853)) ([15370d6](https://github.com/ipfs/service-worker-gateway/commit/15370d643f2e26ed3aeaee7cd7bf730fd6d0013c))

## [1.14.0](https://github.com/ipfs/service-worker-gateway/compare/v1.13.5...v1.14.0) (2025-07-10)


### Features

* add sw registration ttl config ([#809](https://github.com/ipfs/service-worker-gateway/issues/809)) ([b3a9b8d](https://github.com/ipfs/service-worker-gateway/commit/b3a9b8d29e4771f25670ce4f35fadc7cea652221))
* migrate to hash fragments ([#760](https://github.com/ipfs/service-worker-gateway/issues/760)) ([a787aa7](https://github.com/ipfs/service-worker-gateway/commit/a787aa71c26a85b002ac80163154e981546f7e5b))

## [1.13.5](https://github.com/ipfs/service-worker-gateway/compare/v1.13.4...v1.13.5) (2025-07-08)


### Bug Fixes

* allow injection of config ([#791](https://github.com/ipfs/service-worker-gateway/issues/791)) ([470dab7](https://github.com/ipfs/service-worker-gateway/commit/470dab7a1a6f92f9a9e40da94d33b14f4d223dc0))

## [1.13.4](https://github.com/ipfs/service-worker-gateway/compare/v1.13.3...v1.13.4) (2025-06-26)


### Bug Fixes

* loading indicator displays while loading content ([#784](https://github.com/ipfs/service-worker-gateway/issues/784)) ([761e8be](https://github.com/ipfs/service-worker-gateway/commit/761e8be157cfb3c447c1309fa80d8d0e9c6012ed))
* remove unused redirect-page ([#785](https://github.com/ipfs/service-worker-gateway/issues/785)) ([c73132b](https://github.com/ipfs/service-worker-gateway/commit/c73132bed54d2c31e89599ef2ef651d0a16a48db))

## [1.13.3](https://github.com/ipfs/service-worker-gateway/compare/v1.13.2...v1.13.3) (2025-06-24)


### Bug Fixes

* css and UI js load dynamically ([#782](https://github.com/ipfs/service-worker-gateway/issues/782)) ([da05cdc](https://github.com/ipfs/service-worker-gateway/commit/da05cdc08537c69e1a8b4473d6a0c5546555dedf))

## [1.13.2](https://github.com/ipfs/service-worker-gateway/compare/v1.13.1...v1.13.2) (2025-06-23)


### Bug Fixes

* dynamically import UI css&js ([#778](https://github.com/ipfs/service-worker-gateway/issues/778)) ([61fb6b7](https://github.com/ipfs/service-worker-gateway/commit/61fb6b7acd38802175795c6ce28ab10e0377b210))

## [1.13.1](https://github.com/ipfs/service-worker-gateway/compare/v1.13.0...v1.13.1) (2025-06-23)


### Bug Fixes

* cloudflare redirect not being handled properly ([#776](https://github.com/ipfs/service-worker-gateway/issues/776)) ([35a288b](https://github.com/ipfs/service-worker-gateway/commit/35a288b63a211076364f89baf5892643033c92ca))

## [1.13.0](https://github.com/ipfs/service-worker-gateway/compare/v1.12.3...v1.13.0) (2025-06-23)


### Features

* add dag-cbor HTML preview ([#774](https://github.com/ipfs/service-worker-gateway/issues/774)) ([343a26e](https://github.com/ipfs/service-worker-gateway/commit/343a26e4f82615c4882c4800f690002f8b8cd0db))


### Bug Fixes

* build allows for not including js or css file ([#768](https://github.com/ipfs/service-worker-gateway/issues/768)) ([0a10b47](https://github.com/ipfs/service-worker-gateway/commit/0a10b471f071b34aeaeec59cf3eeb1226238b2d3))
* do not import css or react JS unless needed ([#773](https://github.com/ipfs/service-worker-gateway/issues/773)) ([78d4d45](https://github.com/ipfs/service-worker-gateway/commit/78d4d4507d8893639e119941d14c7c9305969dae))
* global config is passed to subdomains ([#759](https://github.com/ipfs/service-worker-gateway/issues/759)) ([58fc25b](https://github.com/ipfs/service-worker-gateway/commit/58fc25b4f6f3f25a2e72bf7b67fbac1d8f77640b))
* go server handles requests with paths ([#761](https://github.com/ipfs/service-worker-gateway/issues/761)) ([7b4ffce](https://github.com/ipfs/service-worker-gateway/commit/7b4ffce8aa160bceef6a784e51309f060befdc65))

## [1.12.3](https://github.com/ipfs/service-worker-gateway/compare/v1.12.2...v1.12.3) (2025-06-13)


### Bug Fixes

* safari renders images correctly ([#753](https://github.com/ipfs/service-worker-gateway/issues/753)) ([1f1de46](https://github.com/ipfs/service-worker-gateway/commit/1f1de4675a0eab7b9ce8c724a98da2e4049dd803))

## [1.12.2](https://github.com/ipfs/service-worker-gateway/compare/v1.12.1...v1.12.2) (2025-06-04)


### Bug Fixes

* inform users how to deregister the service worker ([#721](https://github.com/ipfs/service-worker-gateway/issues/721)) ([573519e](https://github.com/ipfs/service-worker-gateway/commit/573519e5bc987607d1b2883f7bd687493f440ed6))
* update deps and ensure 504 test passes ([#738](https://github.com/ipfs/service-worker-gateway/issues/738)) ([6ce9735](https://github.com/ipfs/service-worker-gateway/commit/6ce973567d2abc942168a5921851fbde6f59b82c))

## [1.12.1](https://github.com/ipfs/service-worker-gateway/compare/v1.12.0...v1.12.1) (2025-05-14)


### Bug Fixes

* improve binary onboarding experience  ([#718](https://github.com/ipfs/service-worker-gateway/issues/718)) ([d491194](https://github.com/ipfs/service-worker-gateway/commit/d4911943feff543eaf12eee06c22250ed3135aa8))

## [1.12.0](https://github.com/ipfs/service-worker-gateway/compare/v1.11.0...v1.12.0) (2025-04-23)


### Features

* configurable 30s timeout ([#681](https://github.com/ipfs/service-worker-gateway/issues/681)) ([fc1b9ec](https://github.com/ipfs/service-worker-gateway/commit/fc1b9ec3310d63ad82a8172aad322bfb55bff55d))
* display 504 error page with helpful info ([#689](https://github.com/ipfs/service-worker-gateway/issues/689)) ([9275bc6](https://github.com/ipfs/service-worker-gateway/commit/9275bc68e5d1c442e4ec26a7a139227ec610e367))
* single sw-gateway binary ([#673](https://github.com/ipfs/service-worker-gateway/issues/673)) ([4cd09ee](https://github.com/ipfs/service-worker-gateway/commit/4cd09eed5d1d350e97267fe7920fa743a32c6b98))

## [1.11.0](https://github.com/ipfs/service-worker-gateway/compare/v1.10.5...v1.11.0) (2025-04-15)


### Features

* npm start boots up fully operational sw-gateway ([#670](https://github.com/ipfs/service-worker-gateway/issues/670)) ([49fe12d](https://github.com/ipfs/service-worker-gateway/commit/49fe12db8d36a3fb3ba013945277e76efa1d8829))
* updated error page ([#664](https://github.com/ipfs/service-worker-gateway/issues/664)) ([b3de5a6](https://github.com/ipfs/service-worker-gateway/commit/b3de5a611ace42d94a16ae7aae79ca7a1bb0e8e8))


### Bug Fixes

* subdomain config loads from root ([#677](https://github.com/ipfs/service-worker-gateway/issues/677)) ([4752c41](https://github.com/ipfs/service-worker-gateway/commit/4752c4144bc3125588a9b10646e486341c72fba4))

## [1.10.5](https://github.com/ipfs/service-worker-gateway/compare/v1.10.4...v1.10.5) (2025-04-07)


### Bug Fixes

* cloudflare pages handles redirects properly ([#659](https://github.com/ipfs/service-worker-gateway/issues/659)) ([7ead1e9](https://github.com/ipfs/service-worker-gateway/commit/7ead1e9e405eec6a94602bcce511bf1ae814b782))

## [1.10.4](https://github.com/ipfs/service-worker-gateway/compare/v1.10.3...v1.10.4) (2025-04-02)


### Bug Fixes

* query parameters are preserved ([#636](https://github.com/ipfs/service-worker-gateway/issues/636)) ([7b0ad66](https://github.com/ipfs/service-worker-gateway/commit/7b0ad66ab392c47e13591569aed57006cd9de028))

## [1.10.3](https://github.com/ipfs/service-worker-gateway/compare/v1.10.2...v1.10.3) (2025-03-31)


### Bug Fixes

* first-hit loads config properly ([#652](https://github.com/ipfs/service-worker-gateway/issues/652)) ([0ff5d2d](https://github.com/ipfs/service-worker-gateway/commit/0ff5d2da1b064ba46f1e9635662c2db28dbc6991))

## [1.10.2](https://github.com/ipfs/service-worker-gateway/compare/v1.10.1...v1.10.2) (2025-03-25)


### Bug Fixes

* sw registers on root scope ([#647](https://github.com/ipfs/service-worker-gateway/issues/647)) ([f2d3030](https://github.com/ipfs/service-worker-gateway/commit/f2d30302d6c45118d5eddb51f21333aea2b2070a))

## [1.10.1](https://github.com/ipfs/service-worker-gateway/compare/v1.10.0...v1.10.1) (2025-03-24)


### Bug Fixes

* use default verified-fetch contentTypeParser ([#635](https://github.com/ipfs/service-worker-gateway/issues/635)) ([db8720a](https://github.com/ipfs/service-worker-gateway/commit/db8720acf6de8c640122a0c40e4b9532116e34f9))

## [1.10.0](https://github.com/ipfs/service-worker-gateway/compare/v1.9.3...v1.10.0) (2025-03-18)


### Features

* display origin isolation warnings ([#615](https://github.com/ipfs/service-worker-gateway/issues/615)) ([815ea3c](https://github.com/ipfs/service-worker-gateway/commit/815ea3c8e162067b6e3ed0cdcd79095361533958))


### Bug Fixes

* prevent config UI flash on subdomain first load ([#580](https://github.com/ipfs/service-worker-gateway/issues/580)) ([a326451](https://github.com/ipfs/service-worker-gateway/commit/a3264517ff81b484b1319dab55e39f6d7613d9d3))

## [1.9.3](https://github.com/ipfs/service-worker-gateway/compare/v1.9.2...v1.9.3) (2025-03-05)


### Bug Fixes

* firefox video plays correctly ([#616](https://github.com/ipfs/service-worker-gateway/issues/616)) ([c0eb353](https://github.com/ipfs/service-worker-gateway/commit/c0eb3534a3f44dfbaef6a5f6607b5468faf1e516))

## [1.9.2](https://github.com/ipfs/service-worker-gateway/compare/v1.9.1...v1.9.2) (2025-02-28)


### Bug Fixes

* recognize svg and json content-types ([#603](https://github.com/ipfs/service-worker-gateway/issues/603)) ([2d6ff74](https://github.com/ipfs/service-worker-gateway/commit/2d6ff749ec7988d176c0985401bbf3013ff1f1af))

## [1.9.1](https://github.com/ipfs/service-worker-gateway/compare/v1.9.0...v1.9.1) (2025-02-17)


### Bug Fixes

* trigger release ([002ecf5](https://github.com/ipfs/service-worker-gateway/commit/002ecf5c4996d745420b00f3e9741df8e6b9c1e8))

## [1.9.0](https://github.com/ipfs/service-worker-gateway/compare/v1.8.3...v1.9.0) (2025-02-12)


### Features

* support unixfs dir-index-html listing ([#576](https://github.com/ipfs/service-worker-gateway/issues/576)) ([bcb6e1f](https://github.com/ipfs/service-worker-gateway/commit/bcb6e1f50d19d53132bfb147fc6635b0579c0a7a)), closes [#342](https://github.com/ipfs/service-worker-gateway/issues/342)


### Bug Fixes

* error page merges verified-fetch headers ([#531](https://github.com/ipfs/service-worker-gateway/issues/531)) ([b9d062e](https://github.com/ipfs/service-worker-gateway/commit/b9d062e9464be305a19992749201c7c0a7038abf))

## [1.8.3](https://github.com/ipfs/service-worker-gateway/compare/v1.8.2...v1.8.3) (2025-02-11)


### Bug Fixes

* **ci:** timeout and cache playwright deps ([#566](https://github.com/ipfs/service-worker-gateway/issues/566)) ([3b29772](https://github.com/ipfs/service-worker-gateway/commit/3b29772cf9c7a3ff4a8b2974c477dd67821ba8cc))

## [1.8.2](https://github.com/ipfs/service-worker-gateway/compare/v1.8.1...v1.8.2) (2025-01-22)


### Bug Fixes

* enable verified-fetch server-timing headers ([#552](https://github.com/ipfs/service-worker-gateway/issues/552)) ([08828d8](https://github.com/ipfs/service-worker-gateway/commit/08828d8ca33a923aca47483914ff533889e97d9e))

## [1.8.1](https://github.com/ipfs/service-worker-gateway/compare/v1.8.0...v1.8.1) (2025-01-21)


### Bug Fixes

* config loading ([#547](https://github.com/ipfs/service-worker-gateway/issues/547)) ([5495199](https://github.com/ipfs/service-worker-gateway/commit/549519999196ff676bfa88a2cf18382c5c31e06e))

## [1.8.0](https://github.com/ipfs/service-worker-gateway/compare/v1.7.1...v1.8.0) (2024-12-12)


### ⚠ BREAKING CHANGES

* config is always visible on landing page ([#496](https://github.com/ipfs/service-worker-gateway/issues/496))

### Features

* config is always visible on landing page ([#496](https://github.com/ipfs/service-worker-gateway/issues/496)) ([d21178c](https://github.com/ipfs/service-worker-gateway/commit/d21178c33fbe354face8325ec53ec6f3db50f73d))
* subdomain detection is resilient ([#497](https://github.com/ipfs/service-worker-gateway/issues/497)) ([9c6e2df](https://github.com/ipfs/service-worker-gateway/commit/9c6e2df0b4abaa9ca222386cbae01bb68040bb8d))


### Bug Fixes

* config ui is in sync with IDB ([#528](https://github.com/ipfs/service-worker-gateway/issues/528)) ([2d8dbd9](https://github.com/ipfs/service-worker-gateway/commit/2d8dbd9aab18944c8c18be7030e906a170068fb9))


### Miscellaneous Chores

* adjust release verion ([8895691](https://github.com/ipfs/service-worker-gateway/commit/8895691df0b31a98b52293926bfea2f8f5770be6))

## [1.7.1](https://github.com/ipfs/service-worker-gateway/compare/v1.7.0...v1.7.1) (2024-11-22)


### Bug Fixes

* debug logs enabled on dev environments ([#456](https://github.com/ipfs/service-worker-gateway/issues/456)) ([65fd112](https://github.com/ipfs/service-worker-gateway/commit/65fd112d192b200388a37bb4ba403782a46bc18e)), closes [#455](https://github.com/ipfs/service-worker-gateway/issues/455)
* no-sw error shows for subdomain requests ([#491](https://github.com/ipfs/service-worker-gateway/issues/491)) ([c16688e](https://github.com/ipfs/service-worker-gateway/commit/c16688e2d5fb6f9f56146aec4d947d41c0646023))

## [1.7.0](https://github.com/ipfs/service-worker-gateway/compare/v1.6.2...v1.7.0) (2024-11-14)


### Features

* global config validation ([#451](https://github.com/ipfs/service-worker-gateway/issues/451)) ([334a077](https://github.com/ipfs/service-worker-gateway/commit/334a0773f3015290f581abf4f4ac700309988986))


### Bug Fixes

* dont use local storage for text config items ([#448](https://github.com/ipfs/service-worker-gateway/issues/448)) ([aab3c00](https://github.com/ipfs/service-worker-gateway/commit/aab3c00db9ef40fc93996f894df954fbfe4c4d0f))
* input toggles dont use localStorage ([#450](https://github.com/ipfs/service-worker-gateway/issues/450)) ([c838307](https://github.com/ipfs/service-worker-gateway/commit/c83830714475a7a20d949d5bf9f74bf65c7e387d))

## [1.6.2](https://github.com/ipfs/service-worker-gateway/compare/v1.6.1...v1.6.2) (2024-11-13)


### Bug Fixes

* more CI fixes ([#439](https://github.com/ipfs/service-worker-gateway/issues/439)) ([b5e0e25](https://github.com/ipfs/service-worker-gateway/commit/b5e0e25fa8eee8b33b4b56471fcb7e7f2cac1a21))

## [1.6.1](https://github.com/ipfs/service-worker-gateway/compare/v1.6.0...v1.6.1) (2024-11-11)


### Bug Fixes

* ci and deployment workflows ([#437](https://github.com/ipfs/service-worker-gateway/issues/437)) ([17ca8d5](https://github.com/ipfs/service-worker-gateway/commit/17ca8d5e803eab9cc409c43b40af2cc5786924ea))

## [1.6.0](https://github.com/ipfs/service-worker-gateway/compare/v1.5.0...v1.6.0) (2024-11-11)


### Features

* delegated routing request deduplication and caching ([90c48a0](https://github.com/ipfs/service-worker-gateway/commit/90c48a070e2316bb83bf97400c9ae07d8ac4acc8))

## [1.5.0](https://github.com/ipfs/service-worker-gateway/compare/v1.4.1...v1.5.0) (2024-11-05)


### Features

* add blake3 hasher ([#421](https://github.com/ipfs/service-worker-gateway/issues/421)) ([6270acd](https://github.com/ipfs/service-worker-gateway/commit/6270acd2696417afe2b61803278f461636c3a69a))


### Bug Fixes

* apply dns resolvers corectly ([#412](https://github.com/ipfs/service-worker-gateway/issues/412)) ([ba0ede9](https://github.com/ipfs/service-worker-gateway/commit/ba0ede9f3c050f20adf5cd391818d332e9b301b8))
* force use of latest multiaddr-to-uri ([#409](https://github.com/ipfs/service-worker-gateway/issues/409)) ([4915b34](https://github.com/ipfs/service-worker-gateway/commit/4915b346cb64514e47102de32aec74a88e67cd5e))

## [1.4.1](https://github.com/ipfs/service-worker-gateway/compare/v1.4.0...v1.4.1) (2024-10-25)


### Bug Fixes

* support discovery of /tls/../ws|http  providers ([#405](https://github.com/ipfs/service-worker-gateway/issues/405)) ([d848e6c](https://github.com/ipfs/service-worker-gateway/commit/d848e6cbff01d38b851d601a3f65dfdac235086f))

## [1.4.0](https://github.com/ipfs/service-worker-gateway/compare/v1.3.0...v1.4.0) (2024-10-24)


### Features

* add p2p retrieval option ([#391](https://github.com/ipfs/service-worker-gateway/issues/391)) ([0db6d94](https://github.com/ipfs/service-worker-gateway/commit/0db6d94393238853ad5130a6fb17e0a2a821efde))
* build with esbuild, apply source maps ([#392](https://github.com/ipfs/service-worker-gateway/issues/392)) ([2b26bd6](https://github.com/ipfs/service-worker-gateway/commit/2b26bd6354a5f2b9ca51d078ad7c146d69360dac))


### Bug Fixes

* remove auto-reload config and default to true ([#319](https://github.com/ipfs/service-worker-gateway/issues/319)) ([42e6b64](https://github.com/ipfs/service-worker-gateway/commit/42e6b64cf46856eba231b676a4f9c104ff1090f9))
* remove fonts from dist folder ([#394](https://github.com/ipfs/service-worker-gateway/issues/394)) ([86641e5](https://github.com/ipfs/service-worker-gateway/commit/86641e590c8991dad1cc3c1f7b89931b630ccb11))
* service worker logs are visible again ([#395](https://github.com/ipfs/service-worker-gateway/issues/395)) ([98659e2](https://github.com/ipfs/service-worker-gateway/commit/98659e28e98ec5297fd9dc1e6ed2e3d244a51a58))
* use enable from @libp2p/logger ([#398](https://github.com/ipfs/service-worker-gateway/issues/398)) ([cb8c662](https://github.com/ipfs/service-worker-gateway/commit/cb8c662a3d27248c72cb9da2beef5fb56228550e))
* use more ipfs-sw prefixes ([#396](https://github.com/ipfs/service-worker-gateway/issues/396)) ([ade0074](https://github.com/ipfs/service-worker-gateway/commit/ade0074d7f08a61b15f33077c00dc5a1cb273cb7))

## [1.3.0](https://github.com/ipfs/service-worker-gateway/compare/v1.2.0...v1.3.0) (2024-07-04)


### Features

* about section on subdomain loads ([#263](https://github.com/ipfs/service-worker-gateway/issues/263)) ([947011e](https://github.com/ipfs/service-worker-gateway/commit/947011e772f73d32b2380bb6d7521f61fc8d27bf))
* config page ux improvements ([#315](https://github.com/ipfs/service-worker-gateway/issues/315)) ([16b31b9](https://github.com/ipfs/service-worker-gateway/commit/16b31b98f391197c745dcc4328c49fc32905d0ff))
* error page when service worker not available ([#283](https://github.com/ipfs/service-worker-gateway/issues/283)) ([774e388](https://github.com/ipfs/service-worker-gateway/commit/774e388bd2c4696988121c42ce511c59837348f0))
* minimal PWA manifest ([#310](https://github.com/ipfs/service-worker-gateway/issues/310)) ([6d758c9](https://github.com/ipfs/service-worker-gateway/commit/6d758c91b8ffc389ff672a6a0f987651f5a2dba2))


### Bug Fixes

* load default css on interstitial ([#298](https://github.com/ipfs/service-worker-gateway/issues/298)) ([9990664](https://github.com/ipfs/service-worker-gateway/commit/9990664899005fca960544d7e03216bb1c47d7f0))
* remove fonts except woff2 ([#282](https://github.com/ipfs/service-worker-gateway/issues/282)) ([7517a62](https://github.com/ipfs/service-worker-gateway/commit/7517a620a66aab260c66e0cce2270bc8898a0160))

## [1.2.0](https://github.com/ipfs/service-worker-gateway/compare/v1.1.0...v1.2.0) (2024-05-17)


### Features

* _redirects only for /ipns and /ipfs ([#233](https://github.com/ipfs/service-worker-gateway/issues/233)) ([89faa58](https://github.com/ipfs/service-worker-gateway/commit/89faa588ee0c033f3d2631d5c2823c005f17ead5))
* add content-loading indication page ([#258](https://github.com/ipfs/service-worker-gateway/issues/258)) ([c815a25](https://github.com/ipfs/service-worker-gateway/commit/c815a25d2657244cde5cea95cf535dd1bc728675))
* cache sw assets with service worker ([#234](https://github.com/ipfs/service-worker-gateway/issues/234)) ([20a8f32](https://github.com/ipfs/service-worker-gateway/commit/20a8f329402dac4cba53fec55bd059eeb7f7137d))
* landing & config page UX improvements ([#235](https://github.com/ipfs/service-worker-gateway/issues/235)) ([fb9b04e](https://github.com/ipfs/service-worker-gateway/commit/fb9b04e06b6b3670728c243838ee86f3d6b55067))
* meaningful error pages ([#195](https://github.com/ipfs/service-worker-gateway/issues/195)) ([80774f5](https://github.com/ipfs/service-worker-gateway/commit/80774f50760e4b757dfacfb7d5df79f3fb020012))


### Bug Fixes

* ipfs-hosted redirects are not infinite ([#215](https://github.com/ipfs/service-worker-gateway/issues/215)) ([40cc8c7](https://github.com/ipfs/service-worker-gateway/commit/40cc8c7612302e60a2be2c9372e22e95fa10a799))
* multiple bugs ([#220](https://github.com/ipfs/service-worker-gateway/issues/220)) ([75aa0b8](https://github.com/ipfs/service-worker-gateway/commit/75aa0b8773c8f1ab484ac110fe607404303e2e8c))
* revert "feat: migrate to preact/compat ([#190](https://github.com/ipfs/service-worker-gateway/issues/190))" ([#219](https://github.com/ipfs/service-worker-gateway/issues/219)) ([4443174](https://github.com/ipfs/service-worker-gateway/commit/44431745be1f5638fb47969326865c8825ade141))
* use separate logger for ui/sw ([#217](https://github.com/ipfs/service-worker-gateway/issues/217)) ([a96837b](https://github.com/ipfs/service-worker-gateway/commit/a96837b9cf753fa71dcf5a393686fe4d21c7036f))

## [1.1.0](https://github.com/ipfs-shipyard/service-worker-gateway/compare/v1.0.0...v1.1.0) (2024-04-19)


### Features

* code split & dynamic imports ([#188](https://github.com/ipfs-shipyard/service-worker-gateway/issues/188)) ([bdc2979](https://github.com/ipfs-shipyard/service-worker-gateway/commit/bdc2979e02e934b4a3fc696e79ecefe202f059d7))
* helper-ui input-validator update ([#202](https://github.com/ipfs-shipyard/service-worker-gateway/issues/202)) ([e95e70e](https://github.com/ipfs-shipyard/service-worker-gateway/commit/e95e70efdf84fc70c95956138f6bf32382f69e44))
* http range support ([#122](https://github.com/ipfs-shipyard/service-worker-gateway/issues/122)) ([b064d20](https://github.com/ipfs-shipyard/service-worker-gateway/commit/b064d20b4d9b67ba33690ee115cbf6a2d78d3d1b))
* migrate to preact/compat ([#190](https://github.com/ipfs-shipyard/service-worker-gateway/issues/190)) ([8c98f57](https://github.com/ipfs-shipyard/service-worker-gateway/commit/8c98f579b95992072474f02fe39865fda825379d))
* quick TTFB & TTI for large content ([#138](https://github.com/ipfs-shipyard/service-worker-gateway/issues/138)) ([b3c08d1](https://github.com/ipfs-shipyard/service-worker-gateway/commit/b3c08d1df385fb7a27d6420c7d93ba20c598b84f))


### Bug Fixes

* **ci:** attach car to published release ([41d2cff](https://github.com/ipfs-shipyard/service-worker-gateway/commit/41d2cffcff5bc3061212fe13aadb5df9c1a3f64c))
* first-hit handling renders redirect page correctly ([#163](https://github.com/ipfs-shipyard/service-worker-gateway/issues/163)) ([a961662](https://github.com/ipfs-shipyard/service-worker-gateway/commit/a961662aa606b835fc535b9ed3612142ef1d4886))
* fix unixfs directory redirects ([#156](https://github.com/ipfs-shipyard/service-worker-gateway/issues/156)) ([4304333](https://github.com/ipfs-shipyard/service-worker-gateway/commit/4304333846c1af45fb7375adcc14768b439eb473))
* redirect page and first-hit normalization ([#201](https://github.com/ipfs-shipyard/service-worker-gateway/issues/201)) ([8c85b6f](https://github.com/ipfs-shipyard/service-worker-gateway/commit/8c85b6ffe80685617b00ba51af3547f67a39fdf0))

## 1.0.0 (2024-03-15)


### ⚠ BREAKING CHANGES

* dist files optimizations (sw asset name changes) ([#97](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/97))

### Features

* add caching to service worker ([#92](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/92)) ([4674dd0](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/4674dd0a6e37c3555ab98b2f59c20f7cc806fba2))
* add context to mplex streammuxer addition ([ed1b23e](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/ed1b23e0b02426f3234f352dcf6d5ceab66af941))
* add demo video ([e673b77](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/e673b77cb3c92f67b7dc62b7e35fa3e8f57f1a0f))
* add e2e & aegir test support ([#115](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/115)) ([bf6a382](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/bf6a382bf8fa4d98a1c9340ebc04457a1b8e745e))
* add reframev1 routing support ([c5bc7fb](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/c5bc7fb2ad56b411e4fbd6b201e28125cf8d5444))
* allow explicit sw de-registering + timebomb ([#100](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/100)) ([8ec199c](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/8ec199c64d5a6e80fcf2a16b71df91cff50edd5b))
* allow loading config page from subdomain after sw registration ([#96](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/96)) ([1201b22](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/1201b2250fa0a5930628d26f1a7147ba78c6eee6))
* BASE_URL can be overridden ([#27](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/27)) ([2ba597a](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/2ba597aec8a905f04e800bdee5e73faeb933f713))
* **ci:** build car, pin to cluster, update dnslink ([#69](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/69)) ([1bc8d1b](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/1bc8d1b7e4b631c837f40b840f598a43a070dba8))
* **ci:** pin latest inbrowser.link to cluster ([#65](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/65)) ([ed2de44](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/ed2de44cf5d8ffabe94c4b9a774d979225ed5f0a))
* **ci:** update inbrowser.link on release publish ([#117](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/117)) ([90440d9](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/90440d948d0b7c56f25cf814e6c47937c861e75d))
* compress assets using gzip ([f9537c2](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/f9537c21ce387dbcfe8ced3551463f0617ad7a81))
* create config page for sw settings ([#24](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/24)) ([d933208](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/d933208d81b303b81c106de396369b2dd236396c))
* implement gateway _redirects file ([#11](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/11)) ([fadb400](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/fadb4005bfdd2f25a1269da63607079f68e7b150))
* Implement service worker and main-thread demo ([#3](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/3)) ([2a630c0](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/2a630c0ad28558f3d27b4bd65650cf7a81a9a135))
* improve styling of header ([#77](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/77)) ([8eec72e](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/8eec72e3d904f9979ea668ffb9d223dd2a405ad2))
* load static websites and paths ([#2](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/2)) ([3bad813](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/3bad8132579dd2eadff042d48c9b169fd1842624))
* make it work ([8f7944c](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/8f7944c1e18fef940730fbecb151873aaed3ad02))
* pull in Adin changes ([722f487](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/722f487a51201772e4d3a82161e2184e871e92ea))
* rendered CID in browser with content-type recognition ([0c9d304](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/0c9d304c464160713d77be3d38a3ac765ba1ca40))
* support ens resolution ([#56](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/56)) ([4c9a3f3](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/4c9a3f30cc179684ba3acf6886a9db2b5612d3c3))
* support gateway-like functionality ([5ff3cfe](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/5ff3cfecc8d375664f4e02385432671f16a3944f))
* use @helia/verified-fetch ([#17](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/17)) ([bd38764](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/bd38764b511276d1a57f4b72a5132aa851b69194))


### Bug Fixes

* code cleanup, dep removal, & miscellaneous ([#89](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/89)) ([0a6d2f3](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/0a6d2f3dcc3dc2e421187604b4dbbd3df41cbed0))
* css styles applied & config page collapse ([#112](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/112)) ([47b8af4](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/47b8af4f433454e20c833b45feaebcd2c7b60a2d))
* dnsLinkLabel decode encode ([#34](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/34)) ([306e19b](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/306e19b0910f54c20bac32ffa518aac2d70841f1))
* dynamic subdomain gateway detection ([#53](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/53)) ([333ee9f](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/333ee9ff91f9f4135175b86c720c976cb6d1e5aa))
* enforce origin isolation on subdomain gws ([#60](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/60)) ([3071332](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/30713329938fa2bd32c1de0914266412782d419e))
* first load for new ipns site redirects properly ([4fb8357](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/4fb83575b2c20d61e6c9a0ba3c7d6bda61c4c7a2))
* handle helia-sw query from _redirects ([#67](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/67)) ([cfd70a6](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/cfd70a63e0d4f0ef74e393c81b5d73fb676d26f2))
* infinite loop during redirect parsing ([#10](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/10)) ([19bea1c](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/19bea1ce2acde3395e552681c92a16d7b95917a1))
* load the iframe in the same port as the parent domain ([af68be4](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/af68be4a450fabd3027d4ff41aa4a6d6dec6aee9))
* remove invalid char from the helia fetch url ([#29](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/29)) ([674c69f](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/674c69fc5b24a2a88cb9c2c754e943fe3c261989))


### Miscellaneous Chores

* dist files optimizations (sw asset name changes) ([#97](https://github.com/ipfs-shipyard/helia-service-worker-gateway/issues/97)) ([0c81f2a](https://github.com/ipfs-shipyard/helia-service-worker-gateway/commit/0c81f2aa05db6dbdd64aaaef278fdb11b5c0843a))
