/**
 * @packageDocumentation
 *
 * @example
 *
 * Let's create a little directory to import:
 *
 * ```console
 * > cd /tmp
 * > mkdir foo
 * > echo 'hello' > foo/bar
 * > echo 'world' > foo/quux
 * ```
 *
 * And write the importing logic:
 *
 * ```TypeScript
 * import { importer } from 'ipfs-unixfs-importer'
 * import { MemoryBlockstore } from 'blockstore-core/memory'
 * import * as fs from 'node:fs'
 *
 * // Where the blocks will be stored
 * const blockstore = new MemoryBlockstore()
 *
 * // Import path /tmp/foo/
 * const source = [{
 *   path: '/tmp/foo/bar',
 *   content: fs.createReadStream('/tmp/foo/bar')
 * }, {
 *   path: '/tmp/foo/quxx',
 *   content: fs.createReadStream('/tmp/foo/quux')
 * }]
 *
 * for await (const entry of importer(source, blockstore)) {
 *   console.info(entry)
 * }
 * ```
 *
 * When run, metadata about DAGNodes in the created tree is printed until the root:
 *
 * ```
 * {
 *   cid: CID, // see https://github.com/multiformats/js-cid
 *   path: 'tmp/foo/bar',
 *   unixfs: UnixFS // see https://github.com/ipfs/js-ipfs-unixfs
 * }
 * {
 *   cid: CID, // see https://github.com/multiformats/js-cid
 *   path: 'tmp/foo/quxx',
 *   unixfs: UnixFS // see https://github.com/ipfs/js-ipfs-unixfs
 * }
 * {
 *   cid: CID, // see https://github.com/multiformats/js-cid
 *   path: 'tmp/foo',
 *   unixfs: UnixFS // see https://github.com/ipfs/js-ipfs-unixfs
 * }
 * {
 *   cid: CID, // see https://github.com/multiformats/js-cid
 *   path: 'tmp',
 *   unixfs: UnixFS // see https://github.com/ipfs/js-ipfs-unixfs
 * }
 * ```
 */

import first from 'it-first'
import parallelBatch from 'it-parallel-batch'
import { fixedSize } from './chunker/fixed-size.ts'
import { DEFAULT_BLOCK_WRITE_CONCURRENCY, DEFAULT_CHUNK_SIZE_1MIB, DEFAULT_CHUNK_SIZE_256KIB, DEFAULT_CID_VERSION, DEFAULT_FIELD_ORDER, DEFAULT_FILE_IMPORT_CONCURRENCY, DEFAULT_LEAF_TYPE, DEFAULT_RAW_LEAVES, DEFAULT_REDUCE_SINGLE_LEAF_TO_SELF, DEFAULT_SHARD_FANOUT_BITS, DEFAULT_SHARD_SPLIT_STRATEGY, DEFAULT_SHARD_SPLIT_THRESHOLD_BYTES, DEFAULT_WRAP_WITH_DIRECTORY } from './constants.ts'
import { defaultBufferImporter } from './dag-builder/buffer-importer.ts'
import { defaultDagBuilder } from './dag-builder/index.ts'
import { defaultChunkValidator } from './dag-builder/validate-chunks.ts'
import { InvalidParametersError } from './errors.ts'
import { balanced } from './layout/index.ts'
import { defaultTreeBuilder } from './tree-builder.ts'
import type { Chunker } from './chunker/index.ts'
import type { BufferImportProgressEvents } from './dag-builder/buffer-importer.ts'
import type { DirBuilder } from './dag-builder/dir.ts'
import type { FileBuilder, ReducerProgressEvents } from './dag-builder/file.ts'
import type { DAGBuilder, DagBuilderProgressEvents } from './dag-builder/index.ts'
import type { ChunkValidator } from './dag-builder/validate-chunks.ts'
import type { FileLayout } from './layout/index.ts'
import type { FieldOrder } from '@ipld/dag-pb'
import type { Blockstore } from 'interface-blockstore'
import type { UnixFS, Mtime } from 'ipfs-unixfs'
import type { CID, Version as CIDVersion } from 'multiformats/cid'
import type { ProgressOptions } from 'progress-events'

export * from './errors.ts'

export type ByteStream = Iterable<Uint8Array> | AsyncIterable<Uint8Array>
export type ImportContent = ByteStream | Uint8Array

export type WritableStorage = Pick<Blockstore, 'put'>

export interface FileCandidate<T extends ImportContent = ImportContent> {
  path?: string
  content: T
  mtime?: Mtime
  mode?: number
}

export interface DirectoryCandidate {
  path: string
  mtime?: Mtime
  mode?: number
}

export interface SymlinkCandidate {
  path: string
  link: string
  mtime?: Mtime
  mode?: number
}

export type ImportCandidate = FileCandidate | DirectoryCandidate | SymlinkCandidate

export interface File {
  content: AsyncIterable<Uint8Array>
  path?: string
  mtime?: Mtime
  mode?: number
  originalPath?: string
}

export interface Directory {
  path?: string
  mtime?: Mtime
  mode?: number
  originalPath?: string
}

export interface Symlink {
  link: string
  path: string
  name?: string
  mtime?: Mtime
  mode?: number
  originalPath?: string
}

export interface ImportResult {
  cid: CID
  size: bigint
  path?: string
  unixfs?: UnixFS
}

export interface MultipleBlockImportResult extends ImportResult {
  originalPath?: string
}

export interface SingleBlockImportResult extends ImportResult {
  single: true
  originalPath?: string
  block: Uint8Array
}

export type InProgressImportResult = SingleBlockImportResult | MultipleBlockImportResult

export interface BufferImporterResult extends ImportResult {
  block: Uint8Array
}

export interface HamtHashFn { (value: Uint8Array): Promise<Uint8Array> }
export interface TreeBuilder { (source: AsyncIterable<InProgressImportResult>, blockstore: WritableStorage): AsyncIterable<ImportResult> }
export interface BufferImporter { (file: File, blockstore: WritableStorage): AsyncIterable<() => Promise<BufferImporterResult>> }

export type ImporterProgressEvents =
  BufferImportProgressEvents |
  DagBuilderProgressEvents |
  ReducerProgressEvents

/**
 * Profile names as defined by:
 *
 * - IPIP-499 - https://github.com/ipfs/specs/pull/499
 */
export type CIDProfile = 'unixfs-v0-2015' | 'unixfs-v1-2025'

/**
 * How to determine when to shard a directory
 */
export type ShardSplitStrategy = 'links-bytes' | 'block-bytes'

/**
 * Options to control the importer's behaviour
 */
export interface ImporterOptions extends ProgressOptions<ImporterProgressEvents> {
  /**
   * The CID profile to use when calculating CIDs - see IPIP-499 for details
   *
   * @see https://github.com/ipfs/specs/pull/499
   */
  profile?: CIDProfile

  /**
   * When a file would span multiple DAGNodes, if this is true the leaf nodes
   * will not be wrapped in `UnixFS` protobufs and will instead contain the
   * raw file bytes. Default: true
   */
  rawLeaves?: boolean

  /**
   * If the file being imported is small enough to fit into one DAGNodes, store
   * the file data in the root node along with the UnixFS metadata instead of
   * in a leaf node which would then require additional I/O to load. Default: true
   */
  reduceSingleLeafToSelf?: boolean

  /**
   * What type of UnixFS node leaves should be - can be `'file'` or `'raw'`
   * (ignored when `rawLeaves` is `true`).
   *
   * This option exists to simulate kubo's trickle dag which uses a combination
   * of `'raw'` UnixFS leaves and `reduceSingleLeafToSelf: false`.
   *
   * For modern code the `rawLeaves: true` option should be used instead so leaves
   * are plain Uint8Arrays without a UnixFS/Protobuf wrapper.
   */
  leafType?: 'file' | 'raw'

  /**
   * the CID version to use when storing the data. Default: 1
   */
  cidVersion?: CIDVersion

  /**
   * If the serialized node is larger than this it might be converted to a HAMT
   * sharded directory.
   *
   * @default 262144
   */
  shardSplitThresholdBytes?: number

  /**
   * Whether to estimate the size of the data that determines whether to shard
   * the directory instead by counting link bytes, or count it accurately by
   * calculating the size of the resulting block.
   */
  shardSplitStrategy?: ShardSplitStrategy

  /**
   * The number of bits of a hash digest used at each level of sharding to
   * the child index. 2**shardFanoutBits will dictate the maximum number of
   * children for any shard in the HAMT.
   *
   * @default 8
   */
  shardFanoutBits?: number

  /**
   * By default `Links` are written before `Data` field, however this leads to
   * inefficient HAMT shard traversal since the parameters needed to derive the
   * hash prefix length are stored in the `Data` field, so all `Links` have to
   * be read before any of them can be processed.
   *
   * Pass `data-first` here to write the `Data` field before any `Links`.
   *
   * @default 'links-first'
   */
  fieldOrder?: FieldOrder

  /**
   * How many files to import concurrently. For large numbers of small files this
   * should be high (e.g. 50).
   *
   * @default 10
   */
  fileImportConcurrency?: number

  /**
   * How many blocks to hash and write to the block store concurrently. For small
   * numbers of large files this should be high (e.g. 50).
   *
   * @default 50
   */
  blockWriteConcurrency?: number

  /**
   * If true, all imported files and folders will be contained in a directory that
   * will correspond to the CID of the final entry yielded.
   *
   * @default false
   */
  wrapWithDirectory?: boolean

  /**
   * The chunking strategy. See [./src/chunker/index.ts](./src/chunker/index.ts)
   * for available chunkers.
   */
  chunker?: Chunker

  /**
   * How the DAG that represents files are created. See
   * [./src/layout/index.ts](./src/layout/index.ts) for available layouts.
   */
  layout?: FileLayout

  /**
   * This option can be used to override the importer internals.
   *
   * This function should read `{ path, content }` entries from `source` and
   * turn them into DAGs.
   *
   * It should yield a `function` that returns a `Promise` that resolves to
   * `{ cid, path, unixfs, node }` where `cid` is a `CID`, `path` is a string,
   * `unixfs` is a UnixFS entry and `node` is a `DAGNode`.
   *
   * Values will be pulled from this generator in parallel - the amount of
   * parallelization is controlled by the `fileImportConcurrency` option.
   *
   * @default 50
   */
  dagBuilder?: DAGBuilder

  /**
   * This option can be used to override the importer internals.
   *
   * This function should read `{ cid, path, unixfs, node }` entries from `source` and
   * place them in a directory structure
   * It should yield an object with the properties `{ cid, path, unixfs, size }` where
   * `cid` is a `CID`, `path` is a string, `unixfs` is a UnixFS entry and `size` is a `Number`.
   */
  treeBuilder?: TreeBuilder

  /**
   * This option can be used to override the importer internals.
   *
   * This function should read `Buffer`s from `source` and persist them using
   * `blockstore.put` or similar.
   *
   * `entry` is the `{ path, content }` entry, where `entry.content` is an async
   * generator that yields Buffers.
   *
   * It should yield functions that return a Promise that resolves to an object
   * with the properties `{ cid, unixfs, size }` where `cid` is a [CID],
   * `unixfs` is a [UnixFS] entry and `size` is a `Number` that represents the
   * serialized size of the [IPLD] node that holds the buffer data.
   *
   * Values will be pulled from this generator in parallel - the amount of
   * parallelization is controlled by the `blockWriteConcurrency` option
   */
  bufferImporter?: BufferImporter

  /**
   * This option can be used to override the importer internals.
   *
   * This function takes input from the `content` field of imported entries.
   * It should transform them into `Buffer`s, throwing an error if it cannot.
   * It should yield `Buffer` objects constructed from the `source` or throw an
   * `Error`
   */
  chunkValidator?: ChunkValidator

  /**
   * This option can be used to override how a directory IPLD node is built.
   *
   * This function takes a `Directory` object and returns a `Promise` that resolves to an `InProgressImportResult`.
   */
  dirBuilder?: DirBuilder

  /**
   * This option can be used to override how a file IPLD node is built.
   *
   * This function takes a `File` object and returns a `Promise` that resolves to an `InProgressImportResult`.
   */
  fileBuilder?: FileBuilder
}

export type ImportCandidateStream = AsyncIterable<FileCandidate | DirectoryCandidate | SymlinkCandidate> | Iterable<FileCandidate | DirectoryCandidate | SymlinkCandidate>

/**
 * The importer creates UnixFS DAGs and stores the blocks that make
 * them up in the passed blockstore.
 *
 * @example
 *
 * ```typescript
 * import { importer } from 'ipfs-unixfs-importer'
 * import { MemoryBlockstore } from 'blockstore-core'
 *
 * // store blocks in memory, other blockstores are available
 * const blockstore = new MemoryBlockstore()
 *
 * const input = [{
 *   path: './foo.txt',
 *   content: Uint8Array.from([0, 1, 2, 3, 4])
 * }, {
 *   path: './bar.txt',
 *   content: Uint8Array.from([0, 1, 2, 3, 4])
 * }]
 *
 * for await (const entry of importer(input, blockstore)) {
 *   console.info(entry)
 *   // { cid: CID(), ... }
 * }
 * ```
 */
export async function * importer (source: ImportCandidateStream, blockstore: WritableStorage, options: ImporterOptions = {}): AsyncGenerator<ImportResult, void, unknown> {
  let candidates: ImportCandidateStream

  if (Symbol.asyncIterator in source || Symbol.iterator in source) {
    candidates = source
  } else {
    candidates = [source]
  }

  let chunkSize
  let maxChildrenPerNode

  if (options.profile === 'unixfs-v0-2015') {
    options.shardSplitStrategy = options.shardSplitStrategy ?? 'links-bytes'
    options.cidVersion = options.cidVersion ?? 0
    options.rawLeaves = options.rawLeaves ?? false
    chunkSize = DEFAULT_CHUNK_SIZE_256KIB
    maxChildrenPerNode = 174
    options.fieldOrder = 'links-first'
  } else if (options.profile === 'unixfs-v1-2025') {
    options.shardSplitStrategy = options.shardSplitStrategy ?? 'block-bytes'
    options.cidVersion = options.cidVersion ?? 1
    options.rawLeaves = options.rawLeaves ?? true
    chunkSize = DEFAULT_CHUNK_SIZE_1MIB
    maxChildrenPerNode = 1_024
    options.fieldOrder = 'links-first'
  }

  const wrapWithDirectory = options.wrapWithDirectory ?? DEFAULT_WRAP_WITH_DIRECTORY
  const shardSplitThresholdBytes = options.shardSplitThresholdBytes ?? DEFAULT_SHARD_SPLIT_THRESHOLD_BYTES
  const shardSplitStrategy = options.shardSplitStrategy ?? DEFAULT_SHARD_SPLIT_STRATEGY
  const shardFanoutBits = options.shardFanoutBits ?? DEFAULT_SHARD_FANOUT_BITS
  const cidVersion = options.cidVersion ?? DEFAULT_CID_VERSION
  const rawLeaves = options.rawLeaves ?? DEFAULT_RAW_LEAVES
  const leafType = options.leafType ?? DEFAULT_LEAF_TYPE
  const fileImportConcurrency = options.fileImportConcurrency ?? DEFAULT_FILE_IMPORT_CONCURRENCY
  const blockWriteConcurrency = options.blockWriteConcurrency ?? DEFAULT_BLOCK_WRITE_CONCURRENCY
  const reduceSingleLeafToSelf = options.reduceSingleLeafToSelf ?? DEFAULT_REDUCE_SINGLE_LEAF_TO_SELF
  const fieldOrder = options.fieldOrder ?? DEFAULT_FIELD_ORDER

  const chunker = options.chunker ?? fixedSize({
    chunkSize
  })
  const chunkValidator = options.chunkValidator ?? defaultChunkValidator()
  const buildDag: DAGBuilder = options.dagBuilder ?? defaultDagBuilder({
    chunker,
    chunkValidator,
    wrapWithDirectory,
    layout: options.layout ?? balanced({
      maxChildrenPerNode
    }),
    bufferImporter: options.bufferImporter ?? defaultBufferImporter({
      cidVersion,
      rawLeaves,
      leafType,
      onProgress: options.onProgress
    }),
    blockWriteConcurrency,
    reduceSingleLeafToSelf,
    cidVersion,
    onProgress: options.onProgress,
    dirBuilder: options.dirBuilder,
    fileBuilder: options.fileBuilder,
    fieldOrder
  })
  const buildTree: TreeBuilder = options.treeBuilder ?? defaultTreeBuilder({
    wrapWithDirectory,
    shardSplitThresholdBytes,
    shardSplitStrategy,
    shardFanoutBits,
    cidVersion,
    onProgress: options.onProgress,
    fieldOrder
  })

  for await (const entry of buildTree(parallelBatch(buildDag(candidates, blockstore), fileImportConcurrency), blockstore)) {
    yield {
      cid: entry.cid,
      path: entry.path,
      unixfs: entry.unixfs,
      size: entry.size
    }
  }
}

/**
 * `importFile` is similar to `importer` except it accepts a single
 * `FileCandidate` and returns a promise of a single `ImportResult`
 * instead of a stream of results.
 *
 * @example
 *
 * ```typescript
 * import { importFile } from 'ipfs-unixfs-importer'
 * import { MemoryBlockstore } from 'blockstore-core'
 *
 * // store blocks in memory, other blockstores are available
 * const blockstore = new MemoryBlockstore()
 *
 * const input: FileCandidate = {
 *   path: './foo.txt',
 *   content: Uint8Array.from([0, 1, 2, 3, 4])
 * }
 *
 * const entry = await importFile(input, blockstore)
 * ```
 */
export async function importFile (content: FileCandidate, blockstore: WritableStorage, options: ImporterOptions = {}): Promise<ImportResult> {
  const result = await first(importer([content], blockstore, options))

  if (result == null) {
    throw new InvalidParametersError('Nothing imported')
  }

  return result
}

/**
 * `importDir` is similar to `importer` except it accepts a single
 * `DirectoryCandidate` and returns a promise of a single `ImportResult`
 * instead of a stream of results.
 *
 * @example
 *
 * ```typescript
 * import { importDirectory } from 'ipfs-unixfs-importer'
 * import { MemoryBlockstore } from 'blockstore-core'
 *
 * // store blocks in memory, other blockstores are available
 * const blockstore = new MemoryBlockstore()
 *
 * const input: DirectoryCandidate = {
 *   path: './foo.txt'
 * }
 *
 * const entry = await importDirectory(input, blockstore)
 * ```
 */
export async function importDirectory (content: DirectoryCandidate, blockstore: WritableStorage, options: ImporterOptions = {}): Promise<ImportResult> {
  const result = await first(importer([content], blockstore, options))

  if (result == null) {
    throw new InvalidParametersError('Nothing imported')
  }

  return result
}

/**
 * `importBytes` accepts a single Uint8Array and returns a promise
 * of a single `ImportResult`.
 *
 * @example
 *
 * ```typescript
 * import { importBytes } from 'ipfs-unixfs-importer'
 * import { MemoryBlockstore } from 'blockstore-core'
 *
 * // store blocks in memory, other blockstores are available
 * const blockstore = new MemoryBlockstore()
 *
 * const input = Uint8Array.from([0, 1, 2, 3, 4])
 *
 * const entry = await importBytes(input, blockstore)
 * ```
 */
export async function importBytes (buf: ImportContent, blockstore: WritableStorage, options: ImporterOptions = {}): Promise<ImportResult> {
  return importFile({
    content: buf
  }, blockstore, options)
}

/**
 * `importByteStream` accepts a single stream of Uint8Arrays and
 * returns a promise of a single `ImportResult`.
 *
 * @example
 *
 * ```typescript
 * import { importByteStream } from 'ipfs-unixfs-importer'
 * import { MemoryBlockstore } from 'blockstore-core'
 *
 * // store blocks in memory, other blockstores are available
 * const blockstore = new MemoryBlockstore()
 *
 * const input = [
 *   Uint8Array.from([0, 1, 2, 3, 4]),
 *   Uint8Array.from([5, 6, 7, 8, 9])
 * ]
 *
 * const entry = await importByteStream(input, blockstore)
 * ```
 */
export async function importByteStream (bufs: ByteStream, blockstore: WritableStorage, options: ImporterOptions = {}): Promise<ImportResult> {
  return importFile({
    content: bufs
  }, blockstore, options)
}
