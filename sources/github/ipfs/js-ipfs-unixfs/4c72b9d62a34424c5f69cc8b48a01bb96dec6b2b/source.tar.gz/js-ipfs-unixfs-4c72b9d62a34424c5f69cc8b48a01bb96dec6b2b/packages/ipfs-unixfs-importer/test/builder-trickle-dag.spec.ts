import { expect } from 'aegir/chai'
import { trickle } from '../src/layout/trickle.ts'
import asAsyncIterable from './helpers/as-async-iterable.ts'

const createValues = (max: number): number[] => {
  const output = []

  for (let i = 0; i < max; i++) {
    output.push(i)
  }

  return output
}

function reduce (leaves: any): any {
  if (leaves.length > 1) {
    return { children: leaves }
  } else {
    return leaves[0]
  }
}

const options = {
  maxChildrenPerNode: 3,
  layerRepeat: 2
}

describe('builder: trickle', () => {
  it('reduces one value into itself', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(asAsyncIterable([1]), reduce)

    expect(result).to.deep.equal(1)
  })

  it('reduces 3 values into parent', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(3), reduce)

    expect(result).to.deep.equal({
      children: [
        0,
        1,
        2
      ]
    })
  })

  it('reduces 6 values correctly', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(6), reduce)

    expect(result).to.deep.equal({
      children: [
        0,
        1,
        2,
        {
          children: [
            3,
            4,
            5
          ]
        }
      ]
    })
  })

  it('reduces 9 values correctly', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(9), reduce)

    expect(result).to.deep.equal({
      children: [
        0,
        1,
        2,
        {
          children: [
            3,
            4,
            5
          ]
        },
        {
          children: [
            6,
            7,
            8
          ]
        }
      ]
    })
  })

  it('reduces 12 values correctly', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(12), reduce)

    expect(result).to.deep.equal({
      children: [
        0,
        1,
        2,
        {
          children: [
            3,
            4,
            5
          ]
        },
        {
          children: [
            6,
            7,
            8
          ]
        },
        {
          children: [
            9,
            10,
            11
          ]
        }
      ]
    })
  })

  it('reduces 21 values correctly', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(21), reduce)

    expect(result).to.deep.equal({
      children: [
        0,
        1,
        2,
        {
          children: [
            3,
            4,
            5
          ]
        },
        {
          children: [
            6,
            7,
            8
          ]
        },
        {
          children: [
            9,
            10,
            11,
            {
              children: [
                12,
                13,
                14
              ]
            },
            {
              children: [
                15,
                16,
                17
              ]
            }
          ]
        },
        {
          children: [
            18,
            19,
            20
          ]
        }
      ]
    })
  })

  it('reduces 68 values correctly', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(68), reduce)

    expect(result).to.deep.equal(
      {
        children: [
          0,
          1,
          2,
          {
            children: [
              3,
              4,
              5
            ]
          },
          {
            children: [
              6,
              7,
              8
            ]
          },
          {
            children: [
              9,
              10,
              11,
              {
                children: [
                  12,
                  13,
                  14
                ]
              },
              {
                children: [
                  15,
                  16,
                  17
                ]
              }
            ]
          },
          {
            children: [
              18,
              19,
              20,
              {
                children: [
                  21,
                  22,
                  23
                ]
              },
              {
                children: [
                  24,
                  25,
                  26
                ]
              }
            ]
          },
          {
            children: [
              27,
              28,
              29,
              {
                children: [
                  30,
                  31,
                  32
                ]
              },
              {
                children: [
                  33,
                  34,
                  35
                ]
              },
              {
                children: [
                  36,
                  37,
                  38,
                  {
                    children: [
                      39,
                      40,
                      41
                    ]
                  },
                  {
                    children: [
                      42,
                      43,
                      44
                    ]
                  }
                ]
              },
              {
                children: [
                  45,
                  46,
                  47,
                  {
                    children: [
                      48,
                      49,
                      50
                    ]
                  },
                  {
                    children: [
                      51,
                      52,
                      53
                    ]
                  }
                ]
              }
            ]
          },
          {
            children: [
              54,
              55,
              56,
              {
                children: [
                  57,
                  58,
                  59
                ]
              },
              {
                children: [
                  60,
                  61,
                  62
                ]
              },
              {
                children: [
                  63,
                  64,
                  65,
                  {
                    children: [
                      66,
                      67
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    )
  })

  it('reduces 93 values correctly', async () => {
    // @ts-expect-error number is incorrect type
    const result = await trickle(options)(createValues(93), reduce)

    expect(result).to.deep.equal(
      {
        children: [
          0,
          1,
          2,
          {
            children: [
              3,
              4,
              5
            ]
          },
          {
            children: [
              6,
              7,
              8
            ]
          },
          {
            children: [
              9,
              10,
              11,
              {
                children: [
                  12,
                  13,
                  14
                ]
              },
              {
                children: [
                  15,
                  16,
                  17
                ]
              }
            ]
          },
          {
            children: [
              18,
              19,
              20,
              {
                children: [
                  21,
                  22,
                  23
                ]
              },
              {
                children: [
                  24,
                  25,
                  26
                ]
              }
            ]
          },
          {
            children: [
              27,
              28,
              29,
              {
                children: [
                  30,
                  31,
                  32
                ]
              },
              {
                children: [
                  33,
                  34,
                  35
                ]
              },
              {
                children: [
                  36,
                  37,
                  38,
                  {
                    children: [
                      39,
                      40,
                      41
                    ]
                  },
                  {
                    children: [
                      42,
                      43,
                      44
                    ]
                  }
                ]
              },
              {
                children: [
                  45,
                  46,
                  47,
                  {
                    children: [
                      48,
                      49,
                      50
                    ]
                  },
                  {
                    children: [
                      51,
                      52,
                      53
                    ]
                  }
                ]
              }
            ]
          },
          {
            children: [
              54,
              55,
              56,
              {
                children: [
                  57,
                  58,
                  59
                ]
              },
              {
                children: [
                  60,
                  61,
                  62
                ]
              },
              {
                children: [
                  63,
                  64,
                  65,
                  {
                    children: [
                      66,
                      67,
                      68
                    ]
                  },
                  {
                    children: [
                      69,
                      70,
                      71
                    ]
                  }
                ]
              },
              {
                children: [
                  72,
                  73,
                  74,
                  {
                    children: [
                      75,
                      76,
                      77
                    ]
                  },
                  {
                    children: [
                      78,
                      79,
                      80
                    ]
                  }
                ]
              }
            ]
          },
          {
            children: [
              81,
              82,
              83,
              {
                children: [
                  84,
                  85,
                  86
                ]
              },
              {
                children: [
                  87,
                  88,
                  89
                ]
              },
              {
                children: [
                  90,
                  91,
                  92
                ]
              }
            ]
          }
        ]
      }
    )
  })
})
