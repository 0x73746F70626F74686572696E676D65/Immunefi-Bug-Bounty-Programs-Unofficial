import { CustomProgressEvent } from 'progress-events'
import { extractDataFromBlock } from './extract-data-from-block.ts'
import { validateOffsetAndLength } from './validate-offset-and-length.ts'
import type { ExportContentOptions, ExportProgress } from '../../index.ts'

export function rawContent (node: Uint8Array, event: string): ((options?: ExportContentOptions) => AsyncGenerator<Uint8Array, void, undefined>) {
  async function * contentGenerator (options: ExportContentOptions = {}): AsyncGenerator<Uint8Array, void, undefined> {
    const {
      start,
      end
    } = validateOffsetAndLength(node.length, options.offset, options.length)

    const buf = extractDataFromBlock(node, 0n, start, end)

    options.onProgress?.(new CustomProgressEvent<ExportProgress>(event, {
      bytesRead: BigInt(buf.byteLength),
      totalBytes: end - start,
      fileSize: BigInt(node.byteLength)
    }))

    yield buf
  }

  return contentGenerator
}
