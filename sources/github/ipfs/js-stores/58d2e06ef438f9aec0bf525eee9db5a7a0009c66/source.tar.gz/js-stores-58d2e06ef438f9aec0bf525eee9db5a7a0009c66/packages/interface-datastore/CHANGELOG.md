## [interface-datastore-v10.0.1](https://github.com/ipfs/js-stores/compare/interface-datastore-10.0.0...interface-datastore-10.0.1) (2026-05-11)

### Bug Fixes

* update sibling deps ([#377](https://github.com/ipfs/js-stores/issues/377)) ([280842e](https://github.com/ipfs/js-stores/commit/280842ed2cabefbf9ae7b1baa3745876173b3cc9))

## [interface-datastore-v10.0.0](https://github.com/ipfs/js-stores/compare/interface-datastore-9.0.3...interface-datastore-10.0.0) (2026-05-11)

### ⚠ BREAKING CHANGES

* bump multiformats from 13.4.2 to 14.0.0 (#372)

### Trivial Changes

* bump aegir from 47.2.0 to 48.0.4 ([#375](https://github.com/ipfs/js-stores/issues/375)) ([be6174f](https://github.com/ipfs/js-stores/commit/be6174f87f17ba02c3cf2eac17f78807d4cd8630))

### Dependencies

* bump multiformats from 13.4.2 to 14.0.0 ([#372](https://github.com/ipfs/js-stores/issues/372)) ([5bc9912](https://github.com/ipfs/js-stores/commit/5bc991280ce2a386cfa89a5b4474c1ca07e2b1ed))

## [interface-datastore-v9.0.3](https://github.com/ipfs/js-stores/compare/interface-datastore-9.0.2...interface-datastore-9.0.3) (2026-04-10)

### Bug Fixes

* allow require and update doc links ([#369](https://github.com/ipfs/js-stores/issues/369)) ([dadf436](https://github.com/ipfs/js-stores/commit/dadf4361e985e091d33d753f48dcca3dea542217))

## [interface-datastore-v9.0.2](https://github.com/ipfs/js-stores/compare/interface-datastore-9.0.1...interface-datastore-9.0.2) (2025-10-03)

### Dependencies

* bump level from 8.0.1 to 10.0.0 ([#356](https://github.com/ipfs/js-stores/issues/356)) ([c0ec61f](https://github.com/ipfs/js-stores/commit/c0ec61fe965e3bad9d607a0bd3a3c750f00f41d0))

## [interface-datastore-v9.0.1](https://github.com/ipfs/js-stores/compare/interface-datastore-9.0.0...interface-datastore-9.0.1) (2025-10-03)

### Bug Fixes

* update sibling deps ([3f73b3d](https://github.com/ipfs/js-stores/commit/3f73b3d53ea2d86d0f5c3f06785c0bfc30e8b5e9))

## [interface-datastore-v9.0.0](https://github.com/ipfs/js-stores/compare/interface-datastore-8.3.2...interface-datastore-9.0.0) (2025-10-03)

### ⚠ BREAKING CHANGES

* blockstore.get and similar now return streams of bytes

### Features

* streaming blockstores ([#358](https://github.com/ipfs/js-stores/issues/358)) ([4dbb136](https://github.com/ipfs/js-stores/commit/4dbb1362d20fc87fcdd261568dca297972f9bc08))

## [interface-datastore-v8.3.2](https://github.com/ipfs/js-stores/compare/interface-datastore-8.3.1...interface-datastore-8.3.2) (2025-05-26)

### Dependencies

* bump aegir from 44.1.4 to 47.0.16 ([#349](https://github.com/ipfs/js-stores/issues/349)) ([d33d15f](https://github.com/ipfs/js-stores/commit/d33d15f0638856530d0e1868c723e5567abf27e6))

## [interface-datastore-v8.3.1](https://github.com/ipfs/js-stores/compare/interface-datastore-8.3.0...interface-datastore-8.3.1) (2024-09-13)

### Bug Fixes

* restore release config to package.json ([#321](https://github.com/ipfs/js-stores/issues/321)) ([4f14fb0](https://github.com/ipfs/js-stores/commit/4f14fb09d65a3460b548b59557af108412dc9156))

### Dependencies

* **dev:** bump aegir from 42.2.11 to 44.1.0 ([#316](https://github.com/ipfs/js-stores/issues/316)) ([581a467](https://github.com/ipfs/js-stores/commit/581a46720832916bea11efa2476eb85a00bae9d4))

## interface-datastore [8.3.0](https://github.com/ipfs/js-stores/compare/interface-datastore-8.2.11...interface-datastore-8.3.0) (2024-08-02)



### Dependencies

* **interface-store:** upgraded to 6.0.0

## interface-datastore [8.2.11](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.10...interface-datastore-8.2.11) (2024-02-12)


### Bug Fixes

* bump aegir to 42.2.3, update project config and fix deps ([#297](https://github.com/ipfs/js-stores/issues/297)) ([d521ef2](https://github.com/ipfs/js-stores/commit/d521ef251815527baee0a70705f775c0e47481ad))



### Dependencies

* **interface-store:** upgraded to 5.1.8

## [interface-datastore-v8.2.10](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.9...interface-datastore-v8.2.10) (2023-12-30)


### Bug Fixes

* publish with limited concurrency ([85bcc4a](https://github.com/ipfs/js-stores/commit/85bcc4acc09d76d7938c55163c81d9b948c53803))
* readme update ([3bcfb6d](https://github.com/ipfs/js-stores/commit/3bcfb6d311d32a00f24c64cb55c3ba90ca495dba))


### Trivial Changes

* **release:** 8.2.10 [skip ci] ([a8c793e](https://github.com/ipfs/js-stores/commit/a8c793ed72f3e1442f6ead18361f428f6b698bf8))

## [interface-datastore-v8.2.10](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.9...interface-datastore-v8.2.10) (2023-12-30)


### Bug Fixes

* readme update ([3bcfb6d](https://github.com/ipfs/js-stores/commit/3bcfb6d311d32a00f24c64cb55c3ba90ca495dba))

## [interface-datastore-v8.2.9](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.8...interface-datastore-v8.2.9) (2023-12-08)


### Bug Fixes

* remove nanoid ([#283](https://github.com/ipfs/js-stores/issues/283)) ([da03ee2](https://github.com/ipfs/js-stores/commit/da03ee29970fdc860eead076ccedb5eea8ff4266))

## [interface-datastore-v8.2.8](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.7...interface-datastore-v8.2.8) (2023-12-08)


### Dependencies

* bump uint8arrays from 4.0.10 to 5.0.0 ([#282](https://github.com/ipfs/js-stores/issues/282)) ([2cbfd52](https://github.com/ipfs/js-stores/commit/2cbfd52257e9358786962d94e144df9583a45c30))

## [interface-datastore-v8.2.7](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.6...interface-datastore-v8.2.7) (2023-11-27)


### Dependencies

* bump nanoid from 4.0.2 to 5.0.3 ([#269](https://github.com/ipfs/js-stores/issues/269)) ([02cb8cd](https://github.com/ipfs/js-stores/commit/02cb8cd82de4174e7c417ea7e45ef7111f38e990))

## [interface-datastore-v8.2.6](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.5...interface-datastore-v8.2.6) (2023-11-27)


### Dependencies

* **dev:** bump aegir from 40.0.13 to 41.1.9 ([#268](https://github.com/ipfs/js-stores/issues/268)) ([0aa0944](https://github.com/ipfs/js-stores/commit/0aa0944d42798d1f6fd589e8a58de7d791760644))

## [interface-datastore-v8.2.5](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.4...interface-datastore-v8.2.5) (2023-09-05)


### Documentation

* update api docs ([#244](https://github.com/ipfs/js-stores/issues/244)) ([e0f6145](https://github.com/ipfs/js-stores/commit/e0f614575d675fe4db2ab30ea6a2a854e892d635))

## [interface-datastore-v8.2.4](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.3...interface-datastore-v8.2.4) (2023-08-03)


### Dependencies

* **dev:** bump aegir from 39.0.13 to 40.0.8 ([#241](https://github.com/ipfs/js-stores/issues/241)) ([00741ff](https://github.com/ipfs/js-stores/commit/00741ff043b40cf10ecc185665fcb705160c9877))

## [interface-datastore-v8.2.3](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.2...interface-datastore-v8.2.3) (2023-06-07)


### Bug Fixes

* restore empty object default ([#228](https://github.com/ipfs/js-stores/issues/228)) ([f82d02c](https://github.com/ipfs/js-stores/commit/f82d02cc8742b595939b58e2eae0a86bb1cec6b1))

## [interface-datastore-v8.2.2](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.1...interface-datastore-v8.2.2) (2023-06-03)


### Documentation

* Update Blockstore and Datastore implementation lists ([#224](https://github.com/ipfs/js-stores/issues/224)) ([ab3b31b](https://github.com/ipfs/js-stores/commit/ab3b31b5ae2dba4b5ddb4b79740afb7c003aedae))

## [interface-datastore-v8.2.1](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.2.0...interface-datastore-v8.2.1) (2023-06-03)


### Trivial Changes

* rename master to main ([#200](https://github.com/ipfs/js-stores/issues/200)) ([f85d719](https://github.com/ipfs/js-stores/commit/f85d719b711cd60237bdaa6a0bcd418e69a98598))


### Dependencies

* bump aegir from 38.1.8 to 39.0.9 ([#225](https://github.com/ipfs/js-stores/issues/225)) ([d0f301b](https://github.com/ipfs/js-stores/commit/d0f301b1243a0f4f692011449567b51b2706e70f))

## [interface-datastore-v8.2.0](https://github.com/ipfs/js-stores/compare/interface-datastore-v8.1.2...interface-datastore-v8.2.0) (2023-03-23)


### Features

* add all blockstore and datastore implementations ([#197](https://github.com/ipfs/js-stores/issues/197)) ([0d85128](https://github.com/ipfs/js-stores/commit/0d851286d48c357b07df3f7419c1e903ed0e7fac))

## [interface-datastore-v8.1.2](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v8.1.1...interface-datastore-v8.1.2) (2023-03-23)


### Dependencies

* update sibling dependencies ([7c84601](https://github.com/ipfs/js-ipfs-interfaces/commit/7c84601df3a17b5e163de68b224c0efef5d5b746))

## [interface-datastore-v8.1.1](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v8.1.0...interface-datastore-v8.1.1) (2023-03-22)


### Bug Fixes

* make datastore batch commit option extension optional ([#194](https://github.com/ipfs/js-ipfs-interfaces/issues/194)) ([7bb6729](https://github.com/ipfs/js-ipfs-interfaces/commit/7bb6729f616546284c107eaf5dacf12598ea37a0))

## [interface-datastore-v8.1.0](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v8.0.0...interface-datastore-v8.1.0) (2023-03-15)


### Features

* allow extending store method options ([#193](https://github.com/ipfs/js-ipfs-interfaces/issues/193)) ([007e8ac](https://github.com/ipfs/js-ipfs-interfaces/commit/007e8ac83a43ec185368cfad57193f57ef700c45))

## [interface-datastore-v8.0.0](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v7.0.4...interface-datastore-v8.0.0) (2023-03-13)


### ⚠ BREAKING CHANGES

* open/close/batch/query methods have been removed from store interface, query/batch added to datastore, getAll added to blockstore

### Features

* simplify store interface, move query/batch to datastore, add getAll to blockstore ([#189](https://github.com/ipfs/js-ipfs-interfaces/issues/189)) ([0b8f1a0](https://github.com/ipfs/js-ipfs-interfaces/commit/0b8f1a0d7644b32395059db250b301d3d5f024cb))


### Dependencies

* update sibling dependencies ([8f7928c](https://github.com/ipfs/js-ipfs-interfaces/commit/8f7928c28b5869001728cc997f0204a40f51978d))

## [interface-datastore-v7.0.4](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v7.0.3...interface-datastore-v7.0.4) (2023-01-30)


### Dependencies

* bump aegir from 37.12.1 to 38.1.0 ([#184](https://github.com/ipfs/js-ipfs-interfaces/issues/184)) ([c8ab418](https://github.com/ipfs/js-ipfs-interfaces/commit/c8ab418db835a6beefbb44c3ba9176779cebcd0d))

## [interface-datastore-v7.0.3](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v7.0.2...interface-datastore-v7.0.3) (2023-01-06)


### Trivial Changes

* remove lerna ([#183](https://github.com/ipfs/js-ipfs-interfaces/issues/183)) ([04e77ec](https://github.com/ipfs/js-ipfs-interfaces/commit/04e77ec37ca5857b6156dd211f07a61eddcf19b0))


### Documentation

* remove duplicate readme section ([851a110](https://github.com/ipfs/js-ipfs-interfaces/commit/851a11033140e7ae0996adeaf880d6554d12837c))

## [interface-datastore-v7.0.2](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v7.0.1...interface-datastore-v7.0.2) (2022-12-16)


### Documentation

* publish api docs ([#181](https://github.com/ipfs/js-ipfs-interfaces/issues/181)) ([64f8473](https://github.com/ipfs/js-ipfs-interfaces/commit/64f8473a1d646eda431972afb489ac81d23248fa))

## [interface-datastore-v7.0.1](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore-v7.0.0...interface-datastore-v7.0.1) (2022-10-12)


### Trivial Changes

* **deps:** bump nanoid from 3.3.4 to 4.0.0 in /packages/interface-datastore ([#110](https://github.com/ipfs/js-ipfs-interfaces/issues/110)) ([5e40d9c](https://github.com/ipfs/js-ipfs-interfaces/commit/5e40d9c86170fc4c7f0d6c6ee54161327a5493f1))


### Dependencies

* bump uint8arrays from 3.0.0 to 4.0.1 ([#175](https://github.com/ipfs/js-ipfs-interfaces/issues/175)) ([e8d5ea6](https://github.com/ipfs/js-ipfs-interfaces/commit/e8d5ea63feaaaf379890171f4660bfd8f1cfef5e))
* update sibling dependencies ([94dec57](https://github.com/ipfs/js-ipfs-interfaces/commit/94dec576ae4c259f5bd10c811f1d57785445beab))

# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [6.1.2](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@6.1.1...interface-datastore@6.1.2) (2022-06-22)

**Note:** Version bump only for package interface-datastore





## [6.1.1](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@6.1.0...interface-datastore@6.1.1) (2022-01-26)

**Note:** Version bump only for package interface-datastore





# [6.1.0](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@6.0.3...interface-datastore@6.1.0) (2021-09-17)


### Features

* add Key.asKey method ([#41](https://github.com/ipfs/js-ipfs-interfaces/issues/41)) ([783dcc8](https://github.com/ipfs/js-ipfs-interfaces/commit/783dcc866e4ca6784d2801a8e18fa1135a137a6b))





## [6.0.3](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@6.0.2...interface-datastore@6.0.3) (2021-09-08)


### Bug Fixes

* export key properly ([749b656](https://github.com/ipfs/js-ipfs-interfaces/commit/749b656c23fb91aa13bfaf9a5ad99703490b24b4))





## [6.0.2](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@6.0.1...interface-datastore@6.0.2) (2021-09-08)

**Note:** Version bump only for package interface-datastore





## [6.0.1](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@6.0.0...interface-datastore@6.0.1) (2021-09-08)

**Note:** Version bump only for package interface-datastore





# [6.0.0](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@5.1.3...interface-datastore@6.0.0) (2021-09-08)


### chore

* switch to ESM ([#39](https://github.com/ipfs/js-ipfs-interfaces/issues/39)) ([c04aa80](https://github.com/ipfs/js-ipfs-interfaces/commit/c04aa80d48a84b681962cae227dd2628e7d35cb5))


### BREAKING CHANGES

* deep requires/imports are no longer possible, moves adapters/in-memory impls etc to core packages





## [5.1.3](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@5.1.2...interface-datastore@5.1.3) (2021-09-02)


### Bug Fixes

* make tests more stable ([#38](https://github.com/ipfs/js-ipfs-interfaces/issues/38)) ([595de43](https://github.com/ipfs/js-ipfs-interfaces/commit/595de438cbb5bda7444bdd8c4ce561215855d190))





## [5.1.2](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@5.1.1...interface-datastore@5.1.2) (2021-08-20)

**Note:** Version bump only for package interface-datastore





## [5.1.1](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@5.1.0...interface-datastore@5.1.1) (2021-06-30)

**Note:** Version bump only for package interface-datastore





# [5.1.0](https://github.com/ipfs/js-ipfs-interfaces/compare/interface-datastore@5.0.0...interface-datastore@5.1.0) (2021-06-30)


### Features

* add unwrap method ([0c22c9f](https://github.com/ipfs/js-ipfs-interfaces/commit/0c22c9ff4fe12ac92e38bcfb6ced626077fdb0ed))





# 5.0.0 (2021-06-28)


### Features

* import interface-datastore ([294b249](https://github.com/ipfs/js-ipfs-interfaces/commit/294b249de30e6fa80c4246a6a253db0ab493886b))


### BREAKING CHANGES

* the compliance tests for interface-datastore have been removed - use the interface-datastore-tests module instead





## [4.0.2](https://github.com/ipfs/interface-datastore/compare/v4.0.1...v4.0.2) (2021-06-10)



## [4.0.1](https://github.com/ipfs/interface-datastore/compare/v4.0.0...v4.0.1) (2021-05-04)



# [4.0.0](https://github.com/ipfs/interface-datastore/compare/v3.0.6...v4.0.0) (2021-04-15)


### Features

* split .query into .query and .queryKeys ([#87](https://github.com/ipfs/interface-datastore/issues/87)) ([4bb5ebc](https://github.com/ipfs/interface-datastore/commit/4bb5ebccec28a6fbfa51411183e037c77313fb8f))



## [3.0.6](https://github.com/ipfs/interface-datastore/compare/v3.0.5...v3.0.6) (2021-04-14)



## [3.0.5](https://github.com/ipfs/interface-datastore/compare/v3.0.4...v3.0.5) (2021-04-06)



## [3.0.4](https://github.com/ipfs/interface-datastore/compare/v3.0.3...v3.0.4) (2021-02-05)


### Bug Fixes

* renames .ts to .d.ts and copies to dist/src on build ([#71](https://github.com/ipfs/interface-datastore/issues/71)) ([568ee54](https://github.com/ipfs/interface-datastore/commit/568ee54323e487bff191437e13b1aeaa0a85f411)), closes [#68](https://github.com/ipfs/interface-datastore/issues/68) [#69](https://github.com/ipfs/interface-datastore/issues/69)



## [3.0.3](https://github.com/ipfs/interface-datastore/compare/v3.0.2...v3.0.3) (2021-01-22)


### Bug Fixes

* fix datastore factory ([#65](https://github.com/ipfs/interface-datastore/issues/65)) ([586f883](https://github.com/ipfs/interface-datastore/commit/586f883d3f5ea0391cf3184024db9a60d9b4aa56))



## [3.0.2](https://github.com/ipfs/interface-datastore/compare/v3.0.1...v3.0.2) (2021-01-22)


### Bug Fixes

* open store in tests ([#66](https://github.com/ipfs/interface-datastore/issues/66)) ([6092b10](https://github.com/ipfs/interface-datastore/commit/6092b103b40cb8ee1c57d42082221c1e899bdc14))



## [3.0.1](https://github.com/ipfs/interface-datastore/compare/v3.0.0...v3.0.1) (2021-01-17)



# [3.0.0](https://github.com/ipfs/interface-datastore/compare/v2.0.1...v3.0.0) (2021-01-15)


### Bug Fixes

* ci ([f197aa4](https://github.com/ipfs/interface-datastore/commit/f197aa4a719a388ba91c65ea49ee3cdc5be4dc84))
* feedback ([248cddb](https://github.com/ipfs/interface-datastore/commit/248cddb7d14ee9f29e92fdbe24916578577f4f6d))
* fix some types ([42aebd5](https://github.com/ipfs/interface-datastore/commit/42aebd5f56e4577e6743f0c3861ea0a558e142b7))
* remove types versions and tweak orders ([e449528](https://github.com/ipfs/interface-datastore/commit/e449528d5b98edf6b62e770033d59686928fe67e))
* types ([f8fe99e](https://github.com/ipfs/interface-datastore/commit/f8fe99ec949a694434564b0494bc9f6b57351df4))
* update aegir and feedback ([eab84b0](https://github.com/ipfs/interface-datastore/commit/eab84b025c03b6a2fff805af3a238cefd57545f2))


### Features

* ts types, github ci and clean up ([2afd9be](https://github.com/ipfs/interface-datastore/commit/2afd9be3abf747528473c46550671f92acc5792e))



## [2.0.1](https://github.com/ipfs/interface-datastore/compare/v2.0.0...v2.0.1) (2020-11-09)



<a name="2.0.0"></a>
# [2.0.0](https://github.com/ipfs/interface-datastore/compare/v1.0.4...v2.0.0) (2020-07-29)


### Bug Fixes

* remove node buffer ([#43](https://github.com/ipfs/interface-datastore/issues/43)) ([b2f0963](https://github.com/ipfs/interface-datastore/commit/b2f0963))


### BREAKING CHANGES

* - node Buffers have been replaced with Uint8Arrays
- `key.toBuffer` has been replaced with `key.uint8Array()`



<a name="1.0.4"></a>
## [1.0.4](https://github.com/ipfs/interface-datastore/compare/v1.0.3...v1.0.4) (2020-06-10)



<a name="1.0.3"></a>
## [1.0.3](https://github.com/ipfs/interface-datastore/compare/v1.0.2...v1.0.3) (2020-06-10)


### Bug Fixes

* remove .has method from interface ([a0ebd3a](https://github.com/ipfs/interface-datastore/commit/a0ebd3a))


### BREAKING CHANGES

* - The `.has` method has been removed, call `.get` instead



<a name="1.0.2"></a>
## [1.0.2](https://github.com/ipfs/interface-datastore/compare/v1.0.1...v1.0.2) (2020-05-07)


### Features

* add adapter ([4223581](https://github.com/ipfs/interface-datastore/commit/4223581))



<a name="1.0.1"></a>
## [1.0.1](https://github.com/ipfs/interface-datastore/compare/v1.0.0...v1.0.1) (2020-05-07)



<a name="1.0.0"></a>
# [1.0.0](https://github.com/ipfs/interface-datastore/compare/v0.8.3...v1.0.0) (2020-05-07)


### Features

* add streaming methods and allow passing AbortSignals ([#36](https://github.com/ipfs/interface-datastore/issues/36)) ([6dace38](https://github.com/ipfs/interface-datastore/commit/6dace38))



<a name="0.8.3"></a>
## [0.8.3](https://github.com/ipfs/interface-datastore/compare/v0.8.2...v0.8.3) (2020-04-07)



<a name="0.8.2"></a>
## [0.8.2](https://github.com/ipfs/interface-datastore/compare/v0.8.1...v0.8.2) (2020-04-01)


### Bug Fixes

* remove node globals ([#35](https://github.com/ipfs/interface-datastore/issues/35)) ([a9130c0](https://github.com/ipfs/interface-datastore/commit/a9130c0))



<a name="0.8.1"></a>
## [0.8.1](https://github.com/ipfs/interface-datastore/compare/v0.8.0...v0.8.1) (2020-02-17)


### Bug Fixes

* do not stringify potentially invalid characters ([#34](https://github.com/ipfs/interface-datastore/issues/34)) ([0034ede](https://github.com/ipfs/interface-datastore/commit/0034ede))



<a name="0.8.0"></a>
# [0.8.0](https://github.com/ipfs/interface-datastore/compare/v0.7.0...v0.8.0) (2019-08-09)


### Features

* concat operation on Key ([8c9226c](https://github.com/ipfs/interface-datastore/commit/8c9226c))



<a name="0.7.0"></a>
# [0.7.0](https://github.com/ipfs/interface-datastore/compare/v0.6.0...v0.7.0) (2019-05-01)


### Features

* refactor to async iterators ([#25](https://github.com/ipfs/interface-datastore/issues/25)) ([ab2f2b9](https://github.com/ipfs/interface-datastore/commit/ab2f2b9))



<a name="0.6.0"></a>
# [0.6.0](https://github.com/ipfs/interface-datastore/compare/v0.5.0...v0.6.0) (2018-10-24)


### Bug Fixes

* add _key to the API functions using the instance ([5a377ed](https://github.com/ipfs/interface-datastore/commit/5a377ed))


### Features

* add class-is module ([362eff8](https://github.com/ipfs/interface-datastore/commit/362eff8))



<a name="0.5.0"></a>
# [0.5.0](https://github.com/ipfs/interface-datastore/compare/v0.4.2...v0.5.0) (2018-09-17)


### Features

* add basic error codes ([bbf5f70](https://github.com/ipfs/interface-datastore/commit/bbf5f70))



<a name="0.4.2"></a>
## [0.4.2](https://github.com/ipfs/interface-datastore/compare/v0.4.1...v0.4.2) (2017-12-05)



<a name="0.4.1"></a>
## [0.4.1](https://github.com/ipfs/interface-datastore/compare/v0.4.0...v0.4.1) (2017-11-04)



<a name="0.4.0"></a>
# [0.4.0](https://github.com/ipfs/interface-datastore/compare/v0.3.1...v0.4.0) (2017-11-03)


### Bug Fixes

* make datastore OS agnostic (path things) ([#13](https://github.com/ipfs/interface-datastore/issues/13)) ([5697173](https://github.com/ipfs/interface-datastore/commit/5697173))



<a name="0.3.1"></a>
## [0.3.1](https://github.com/ipfs/interface-datastore/compare/v0.3.0...v0.3.1) (2017-09-07)



<a name="0.3.0"></a>
# [0.3.0](https://github.com/ipfs/interface-datastore/compare/v0.2.2...v0.3.0) (2017-07-22)



<a name="0.2.2"></a>
## [0.2.2](https://github.com/ipfs/interface-datastore/compare/v0.2.1...v0.2.2) (2017-06-03)


### Bug Fixes

* use os specific path separator ([d7ec65a](https://github.com/ipfs/interface-datastore/commit/d7ec65a))



<a name="0.2.1"></a>
## [0.2.1](https://github.com/ipfs/interface-datastore/compare/v0.2.0...v0.2.1) (2017-05-23)



<a name="0.2.0"></a>
# [0.2.0](https://github.com/ipfs/interface-datastore/compare/v0.1.1...v0.2.0) (2017-03-23)


### Features

* add open method ([#4](https://github.com/ipfs/interface-datastore/issues/4)) ([cbe8f7f](https://github.com/ipfs/interface-datastore/commit/cbe8f7f))



<a name="0.1.1"></a>
## [0.1.1](https://github.com/ipfs/interface-datastore/compare/v0.1.0...v0.1.1) (2017-03-15)


### Bug Fixes

* libp2p-crypto is a regular dependency ([3db267b](https://github.com/ipfs/interface-datastore/commit/3db267b))
