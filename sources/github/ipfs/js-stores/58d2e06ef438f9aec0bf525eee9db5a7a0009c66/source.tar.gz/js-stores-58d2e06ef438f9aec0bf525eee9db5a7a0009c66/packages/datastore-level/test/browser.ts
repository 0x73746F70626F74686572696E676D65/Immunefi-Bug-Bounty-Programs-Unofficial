import { MountDatastore } from 'datastore-core'
import { Key } from 'interface-datastore/key'
import { interfaceDatastoreTests } from 'interface-datastore-tests'
import { LevelDatastore } from '../src/index.ts'

describe('LevelDatastore', () => {
  describe('interface-datastore (leveljs)', () => {
    interfaceDatastoreTests({
      setup: () => new LevelDatastore(`hello-${Math.random()}`),
      teardown: () => {}
    })
  })

  describe('interface-datastore (mount(leveljs, leveljs, leveljs))', () => {
    interfaceDatastoreTests({
      setup () {
        return new MountDatastore([{
          prefix: new Key('/a'),
          datastore: new LevelDatastore(`one-${Math.random()}`)
        }, {
          prefix: new Key('/q'),
          datastore: new LevelDatastore(`two-${Math.random()}`)
        }, {
          prefix: new Key('/z'),
          datastore: new LevelDatastore(`three-${Math.random()}`)
        }, {
          prefix: new Key('/dht'),
          datastore: new LevelDatastore(`four-${Math.random()}`)
        }])
      },
      teardown () {}
    })
  })
})
