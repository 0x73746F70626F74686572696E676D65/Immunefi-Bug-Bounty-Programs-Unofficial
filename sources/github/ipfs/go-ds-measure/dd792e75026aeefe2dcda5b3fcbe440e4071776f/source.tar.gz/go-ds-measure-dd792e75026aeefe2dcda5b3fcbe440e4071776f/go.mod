module github.com/ipfs/go-ds-measure

go 1.25.0

require (
	github.com/ipfs/go-datastore v0.9.2
	github.com/ipfs/go-metrics-interface v0.3.0
)

require (
	github.com/google/uuid v1.6.0 // indirect
	github.com/ipfs/go-detect-race v0.0.1 // indirect
)
