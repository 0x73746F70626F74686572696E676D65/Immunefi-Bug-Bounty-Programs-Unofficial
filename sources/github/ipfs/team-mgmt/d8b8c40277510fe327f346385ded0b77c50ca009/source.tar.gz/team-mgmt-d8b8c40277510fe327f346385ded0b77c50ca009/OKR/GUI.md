# IPFS GUI team OKRs

We frame our ongoing work using a process based on quarterly Objectives and Key Results (OKRs). Objectives reflect outcomes that are challenging, but realistic. Results are tangible and measurable.

More: https://github.com/ipfs/ipfs-gui

## 2019 Q2

- [ipfs-gui 2019 Q2 OKRs](https://docs.google.com/spreadsheets/d/1YSeyWqXh3ImanRrTkYQHHkCofiORn68bYqM_KTLBlsA/edit#gid=1841105909)

## 2019 Q1

- [ipfs-gui 2019 Q1 OKRs](https://docs.google.com/spreadsheets/d/1BtOfd7s9oYO5iKsIorCpsm4QuQoIsoZzSz7GItE-9ys/edit?ts=5c2f3d49#gid=1841105909)

## 2018 Q4

- [ipfs-gui 2018 Q4 OKRs](https://docs.google.com/spreadsheets/d/139lROP7-Ee4M4S7A_IO4iIgSgugYm7dct620LYnalII/edit#gid=1841105909)
- [Open Planning Thread](https://github.com/ipfs/ipfs-gui/issues/67)
- [Previous Quarter Retrospective](https://docs.google.com/document/d/1fXFUntQrOb5HYDP0jMlKTQ4SC014tWwam3pfGojMiFY/edit#heading=h.1xrdg4st69mx)

## 2018 Q3

- [ipfs-gui 2018 Q3 OKRs](https://docs.google.com/spreadsheets/d/19vjigg4locq4fO6JXyobS2yTx-k-fSzlFM5ngZDPDbQ/edit?ts=5b489369#gid=1841105909)
- [Open Planning Thread](https://hackmd.io/63Ot04yETI6_Lmpa8sjw5A?view)


## 2018 Q2

- IPFS GUI team was born from the IPFS in web browsers working group.
