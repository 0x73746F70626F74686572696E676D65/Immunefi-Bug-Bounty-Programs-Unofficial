#!/usr/bin/env bash
set -euo pipefail

CLUSTER_HOST="/dnsaddr/ipfs-websites.collab.ipfscluster.io"
CLUSTER_AUTH="${CLUSTER_USER}:${CLUSTER_PASSWORD}"

cluster_ctl() {
    ipfs-cluster-ctl --enc=json \
        --host "$CLUSTER_HOST" \
        --basic-auth "$CLUSTER_AUTH" \
        "$@"
}

# Print per-peer pin status for a given CID.
print_status() {
    echo "Pin status for $1:"
    cluster_ctl status "$1" |
        jq -r '.peer_map | to_entries[] | "\(.value.peername // .key): \(.value.status)"' || true
}

# Return the number of peers with "pinned" status for a given CID.
count_pinned() {
    cluster_ctl status "$1" |
        jq '[.peer_map[].status] | map(select(. == "pinned")) | length' || echo 0
}

# Remove the temporary additions pin on any exit path (success or failure)
# so we never leak it on the cluster when pin add or status polling fails.
ADDITIONS_CID=""
cleanup_additions() {
    local exit_code=$?
    if [[ -n "$ADDITIONS_CID" ]]; then
        echo "::group::unpin additions"
        echo "Removing temporary additions pin '$ADDITIONS_CID'"
        # best-effort: never let cleanup mask the script's real exit code,
        # the additions pin will expire in 2h regardless
        cluster_ctl pin rm "$ADDITIONS_CID" 2>/dev/null \
            || echo "warn: failed to remove additions pin (will expire in 2h)"
        echo "::endgroup::"
    fi
    exit "$exit_code"
}
trap cleanup_additions EXIT

# Upload additions .car to pre-seed new blocks before the full root pin.
# Note: we do NOT pass --local. Without it, cluster fans the blocks out to
# the peers allocated for this pin during the add itself, so the new blocks
# land on the eventual pin holders directly instead of relying on bitswap
# replication from a single entry peer afterwards.
if [[ -n "${ADDITIONS_CAR:-}" ]]; then
    car_file=$(ls $ADDITIONS_CAR 2>/dev/null | head -1) || true
    if [[ -n "$car_file" ]]; then
        echo "::group::upload additions .car"
        echo "Uploading $car_file as pin '${ADDITIONS_PIN_NAME}'"
        add_output=$(cluster_ctl add --format=car \
            --name "$ADDITIONS_PIN_NAME" \
            --expire-in 2h \
            "$car_file")
        echo "$add_output"
        ADDITIONS_CID=$(echo "$add_output" | jq -rs '.[-1].cid' 2>/dev/null) || true
        echo "Additions CID: ${ADDITIONS_CID:-unknown}"
        echo "::endgroup::"
    else
        echo "No file matching ADDITIONS_CAR='${ADDITIONS_CAR}', skipping upload"
    fi
fi

# Preconnect to cluster peers so they can fetch root DAG blocks from this node.
# Done after car upload to give connections time to establish before pin add.
echo "::group::preconnect to cluster"
cluster_ctl peers ls | tee cluster-peers-ls
for maddr in $(jq -r '.ipfs.addresses[]?' cluster-peers-ls); do
    ipfs swarm peering add "$maddr"
    ipfs swarm connect "$maddr" || true &
done
# best-effort: wait for background dials, never fail the script
wait || true
echo "::endgroup::"

# Submit pin request (returns immediately, does not wait for completion).
echo "::group::pin root CID"
echo "Pinning $PIN_CID as '${PIN_NAME}'"
cluster_ctl pin add --no-status \
    --name "$PIN_NAME" $PIN_ADD_EXTRA_ARGS \
    "$PIN_CID"
echo "::endgroup::"

# Wait until at least one peer confirms pinned status for the root CID.
echo "::group::waiting until pinned"
while true; do
    sleep 60
    print_status "$PIN_CID"
    if [[ $(count_pinned "$PIN_CID") -ge 1 ]]; then
        echo "Root pin confirmed, finishing"
        break
    fi
    echo "Still waiting for pin confirmation..."
done
echo "::endgroup::"

# Temporary additions pin is removed by the EXIT trap registered above.
