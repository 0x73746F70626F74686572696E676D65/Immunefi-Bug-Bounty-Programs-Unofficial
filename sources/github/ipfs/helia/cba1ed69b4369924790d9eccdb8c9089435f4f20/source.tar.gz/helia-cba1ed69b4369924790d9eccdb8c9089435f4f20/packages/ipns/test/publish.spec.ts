import { start, stop } from '@libp2p/interface'
import { expect } from 'aegir/chai'
import last from 'it-last'
import { base36 } from 'multiformats/bases/base36'
import { CID } from 'multiformats/cid'
import Sinon from 'sinon'
import { fromString as uint8ArrayFromString } from 'uint8arrays/from-string'
import { toString as uint8ArrayToString } from 'uint8arrays/to-string'
import { localStore } from '../src/local-store.ts'
import { IPNSPublishMetadata, Upkeep } from '../src/pb/metadata.ts'
import { decodeExtensibleData, dhtRoutingKey, ipnsMetadataKey, multihashToIPNSRoutingKey } from '../src/utils.ts'
import { createIPNS } from './fixtures/create-ipns.ts'
import type { CreateIPNSResult } from './fixtures/create-ipns.ts'
import type { IPNS } from '../src/ipns.ts'

const cid = CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn')

describe('publish', () => {
  let name: IPNS
  let customRouting: any
  let heliaRouting: any
  let result: CreateIPNSResult

  beforeEach(async () => {
    result = await createIPNS()
    name = result.name
    customRouting = result.customRouting
    heliaRouting = result.heliaRouting

    await start(name)
  })

  afterEach(async () => {
    await stop(name)
  })

  it('should publish an IPNS record with the default params', async function () {
    const keyName = 'test-key-1'
    const ipnsEntry = await name.publish(keyName, cid)

    const extensibleData = decodeExtensibleData(ipnsEntry.record.data)
    expect(extensibleData).to.have.property('Sequence', 1n)
    expect(extensibleData).to.have.property('TTL', 300_000_000_000n) // 5 minutes
  })

  it('should publish an IPNS record with a custom lifetime params', async function () {
    const keyName = 'test-key-2'
    const lifetime = 123000
    const ipnsEntry = await name.publish(keyName, cid, {
      lifetime
    })

    const extensibleData = decodeExtensibleData(ipnsEntry.record.data)
    expect(extensibleData).to.have.property('Sequence', 1n)

    // Calculate expected validity as a Date object
    const expectedValidity = new Date(Date.now() + lifetime)
    const actualValidity = new Date(uint8ArrayToString(extensibleData.Validity))
    const timeDifference = Math.abs(actualValidity.getTime() - expectedValidity.getTime())
    expect(timeDifference).to.be.lessThan(1000)

    expect(heliaRouting.put.called).to.be.true()
    expect(customRouting.put.called).to.be.true()
  })

  it('should publish an IPNS record with a custom ttl params', async function () {
    const keyName = 'test-key-3'
    const ttl = 1000 // override the default ttl

    const ipnsEntry = await name.publish(keyName, cid, {
      ttl
    })

    const extensibleData = decodeExtensibleData(ipnsEntry.record.data)
    expect(extensibleData).to.have.property('Sequence', 1n)
    expect(extensibleData).to.have.property('TTL', BigInt(ttl * 1e+6))

    expect(heliaRouting.put.called).to.be.true()
    expect(customRouting.put.called).to.be.true()
  })

  it('should publish a record offline', async () => {
    const keyName = 'test-key-4'
    await name.publish(keyName, cid, {
      offline: true
    })

    expect(heliaRouting.put.called).to.be.false()
    expect(customRouting.put.called).to.be.false()
  })

  it('should emit progress events', async function () {
    const keyName = 'test-key-5'
    const onProgress = Sinon.stub()
    await name.publish(keyName, cid, {
      onProgress
    })

    expect(onProgress).to.have.property('called', true)
  })

  it('should publish an IPNS record extensible metadata', async function () {
    const keyName = 'test-key'
    const ipnsEntry = await name.publish(keyName, cid, {
      data: {
        hello: 'world'
      }
    })

    const extensibleData = decodeExtensibleData(ipnsEntry.record.data)
    expect(extensibleData).to.have.property('Sequence', 1n)
    expect(extensibleData).to.have.property('TTL', 300_000_000_000n) // 5 minutes
    expect(extensibleData).to.have.property('hello', 'world') // 5 minutes
  })

  it('should publish recursively using a public key', async () => {
    const keyName1 = 'test-key-6'
    const published = await name.publish(keyName1, cid, {
      offline: true
    })

    const extensibleData = decodeExtensibleData(published.record.data)
    expect(extensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    const keyName2 = 'test-key-7'
    const recursiveRecord = await name.publish(keyName2, published.publicKey, {
      offline: true
    })

    const recursiveExtensibleData = decodeExtensibleData(recursiveRecord.record.data)
    expect(recursiveExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipns/${published.publicKey.toCID().toString(base36)}`))

    const recursiveResult = await last(name.resolve(recursiveRecord.publicKey))

    if (recursiveResult == null) {
      throw new Error('No results found')
    }

    const recursiveResultExtensibleData = decodeExtensibleData(recursiveResult.record.data)
    expect(recursiveResultExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    expect(recursiveResult).to.have.property('value').that.equals(`/ipfs/${cid.toV1()}`)
  })

  it('should publish recursively using a libp2p-key CID', async () => {
    const keyName1 = 'test-key-6'
    const published = await name.publish(keyName1, cid, {
      offline: true
    })

    const extensibleData = decodeExtensibleData(published.record.data)
    expect(extensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    const keyName2 = 'test-key-7'
    const recursiveRecord = await name.publish(keyName2, published.publicKey.toCID(), {
      offline: true
    })

    const recursiveExtensibleData = decodeExtensibleData(recursiveRecord.record.data)
    expect(recursiveExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipns/${published.publicKey.toCID().toString(base36)}`))

    const recursiveResult = await last(name.resolve(recursiveRecord.publicKey))

    if (recursiveResult == null) {
      throw new Error('No results found')
    }

    const recursiveResultExtensibleData = decodeExtensibleData(recursiveResult.record.data)
    expect(recursiveResultExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    expect(recursiveResult).to.have.property('value').that.equals(`/ipfs/${cid.toV1()}`)
  })

  it('should publish recursively using a multihash', async () => {
    const keyName1 = 'test-key-8'
    const published = await name.publish(keyName1, cid, {
      offline: true
    })

    const extensibleData = decodeExtensibleData(published.record.data)
    expect(extensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    const keyName2 = 'test-key-9'
    const recursiveRecord = await name.publish(keyName2, published.publicKey.toMultihash(), {
      offline: true
    })

    const recursiveExtensibleData = decodeExtensibleData(recursiveRecord.record.data)
    expect(recursiveExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipns/${base36.encode(published.publicKey.toMultihash().bytes)}`))

    const recursiveResult = await last(name.resolve(recursiveRecord.publicKey))

    if (recursiveResult == null) {
      throw new Error('No results found')
    }

    const recursiveResultExtensibleData = decodeExtensibleData(recursiveResult.record.data)
    expect(recursiveResultExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    expect(recursiveResult).to.have.property('value').that.equals(`/ipfs/${cid.toV1()}`)
  })

  it('should publish recursively using a string IPNS key', async () => {
    const keyName1 = 'test-key-10'
    const published = await name.publish(keyName1, cid, {
      offline: true
    })

    const extensibleData = decodeExtensibleData(published.record.data)
    expect(extensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    const keyName2 = 'test-key-11'
    const recursiveRecord = await name.publish(keyName2, `/ipns/${published.publicKey.toCID().toString(base36)}`, {
      offline: true
    })

    const recursiveExtensibleData = decodeExtensibleData(recursiveRecord.record.data)
    expect(recursiveExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipns/${published.publicKey.toCID().toString(base36)}`))

    const recursiveResult = await last(name.resolve(recursiveRecord.publicKey))

    if (recursiveResult == null) {
      throw new Error('No results found')
    }

    const recursiveResultExtensibleData = decodeExtensibleData(recursiveResult.record.data)
    expect(recursiveResultExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}`))

    expect(recursiveResult).to.have.property('value').that.equals(`/ipfs/${cid.toV1()}`)
  })

  it('should publish record with a path', async () => {
    const path = '/foo/bar/baz'
    const fullPath = `/ipfs/${cid}/${path}`

    const keyName = 'test-key-12'
    const published = await name.publish(keyName, fullPath, {
      offline: true
    })

    const extensibleData = decodeExtensibleData(published.record.data)
    expect(extensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}${path}`))

    const result = await last(name.resolve(published.publicKey))

    if (result == null) {
      throw new Error('No results found')
    }

    const resultExtensibleData = decodeExtensibleData(result.record.data)
    expect(resultExtensibleData).to.have.property('Value').that.equalBytes(uint8ArrayFromString(`/ipfs/${cid.toV1()}${path}`))

    expect(result).to.have.property('value').that.equals(`/ipfs/${cid.toV1()}${path}`)
  })

  it('should round-trip the upkeep option through metadata', async () => {
    const cases: Array<'reissue' | 'rebroadcast' | 'none'> = ['reissue', 'rebroadcast', 'none']
    for (const upkeep of cases) {
      const { publicKey } = await name.publish(`test-key-upkeep-${upkeep}`, cid, { offline: true, upkeep })
      const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())
      const metadataBuf = await result.datastore.get(ipnsMetadataKey(routingKey))
      expect(IPNSPublishMetadata.decode(metadataBuf).upkeep).to.equal(Upkeep[upkeep])
    }
  })

  it('should default the stored upkeep policy to reissue', async () => {
    const { publicKey } = await name.publish('test-key-default-upkeep', cid, { offline: true })
    const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())
    const metadataBuf = await result.datastore.get(ipnsMetadataKey(routingKey))
    expect(IPNSPublishMetadata.decode(metadataBuf).upkeep).to.equal(Upkeep.reissue)
  })

  describe('localStore error handling', () => {
    it('should handle datastore errors during publish', async () => {
      await start(name)

      // Stub localStore.get to throw an error
      const store = localStore(result.datastore, result.log)
      const getStub = Sinon.stub(store, 'get').rejects(new Error('Datastore get failed'))
      const hasStub = Sinon.stub(store, 'has').resolves(true)

      // Override the localStore on the IPNS instance
      // @ts-ignore
      name.localStore = name['publisher']['localStore'] = store

      const keyName = 'test-key-error'
      await expect(name.publish(keyName, cid)).to.be.rejectedWith('Datastore get failed')

      expect(hasStub.called).to.be.true()
      expect(getStub.called).to.be.true()
    })

    it('should handle datastore put errors during publish', async () => {
      await start(name)

      // Stub datastore.put to throw an error
      const putStub = Sinon.stub(result.datastore, 'put').rejects(new Error('Datastore put failed'))
      const hasStub = Sinon.stub(result.datastore, 'has').resolves(false)

      const keyName = 'test-key-put-error'
      await expect(name.publish(keyName, cid)).to.be.rejectedWith('Datastore put failed')

      expect(hasStub.called).to.be.true()
      expect(putStub.called).to.be.true()
    })

    it('should emit error progress events when localStore fails', async () => {
      await start(name)

      const progressEvents: any[] = []

      const originalGet = result.datastore.get.bind(result.datastore)
      const getStub = Sinon.stub(result.datastore, 'get').callsFake(async (key, options) => {
        if (key.toString().startsWith('/dht/record')) {
          throw new Error('Storage error')
        }

        return originalGet(key, options)
      })
      const hasStub = Sinon.stub(result.datastore, 'has').resolves(false)

      const keyName = 'test-key-progress-error'

      await expect(name.publish(keyName, cid, {
        onProgress: (evt) => progressEvents.push(evt)
      })).to.be.rejectedWith('Storage error')

      expect(hasStub.called).to.be.true('has stub was not called')
      expect(getStub.called).to.be.true('get stub was not called')

      // Check if error progress event was emitted by localStore
      const errorEvent = progressEvents.find(evt => evt.type === 'ipns:routing:datastore:error')
      expect(errorEvent).to.exist()
      expect(errorEvent.detail.message).to.equal('Storage error')
    })

    it('should handle network timeouts in localStore', async () => {
      await start(name)

      // Create a timeout error
      const timeoutError = new Error('Network timeout')
      timeoutError.name = 'TimeoutError'

      const hasStub = Sinon.stub(result.datastore, 'has').rejects(timeoutError)

      const keyName = 'test-key-timeout'
      await expect(name.publish(keyName, cid)).to.be.rejectedWith('Network timeout')

      expect(hasStub.called).to.be.true()
    })
  })
})

describe('unpublish', () => {
  let name: IPNS
  let result: CreateIPNSResult

  beforeEach(async () => {
    result = await createIPNS()
    name = result.name

    await start(name)
  })

  afterEach(async () => {
    await stop(name)
  })

  it('should unpublish by string keyName', async () => {
    const keyName = 'test-key-unpublish-1'
    const { publicKey } = await name.publish(keyName, cid, { offline: true })
    const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.true()
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.true()

    await name.unpublish(keyName)

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.true('unpublish keeps the record by default')
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.false()
  })

  it('should unpublish by PublicKey', async () => {
    const keyName = 'test-key-unpublish-2'
    const { publicKey } = await name.publish(keyName, cid, { offline: true })

    const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())

    await name.unpublish(publicKey)

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.true('unpublish keeps the record by default')
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.false()
  })

  it('should unpublish by libp2p-key CID', async () => {
    const keyName = 'test-key-unpublish-3'
    const { publicKey } = await name.publish(keyName, cid, { offline: true })
    const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())

    await name.unpublish(publicKey.toCID())

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.true('unpublish keeps the record by default')
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.false()
  })

  it('should unpublish by multihash', async () => {
    const keyName = 'test-key-unpublish-4'
    const { publicKey } = await name.publish(keyName, cid, { offline: true })
    const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())

    await name.unpublish(publicKey.toMultihash())

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.true('unpublish keeps the record by default')
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.false()
  })

  it('should remove the record when removeRecord is set', async () => {
    const keyName = 'test-key-unpublish-remove'
    const { publicKey } = await name.publish(keyName, cid, { offline: true })
    const routingKey = multihashToIPNSRoutingKey(publicKey.toMultihash())

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.true()
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.true()

    await name.unpublish(keyName, { removeRecord: true })

    expect(await result.datastore.has(dhtRoutingKey(routingKey))).to.be.false('removeRecord should delete the record')
    expect(await result.datastore.has(ipnsMetadataKey(routingKey))).to.be.false()
  })
})
