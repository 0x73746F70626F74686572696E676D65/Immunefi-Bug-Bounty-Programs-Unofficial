import { NotFoundError } from '@libp2p/interface'
import { defaultLogger } from '@libp2p/logger'
import { RecordType } from '@multiformats/dns'
import { expect } from 'aegir/chai'
import delay from 'delay'
import { base58btc } from 'multiformats/bases/base58'
import { CID } from 'multiformats/cid'
import * as Digest from 'multiformats/hashes/digest'
import { stubInterface } from 'sinon-ts'
import { dnsLink } from '../src/index.ts'
import type { DNSLink, DNSLinkResolveResult } from '../src/index.ts'
import type { Answer, DNS, DNSResponse } from '@multiformats/dns'
import type { StubbedInstance } from 'sinon-ts'

function dnsResponse (answers: Answer[]): DNSResponse {
  return {
    Status: 0,
    TC: true,
    RD: true,
    RA: true,
    AD: true,
    CD: true,
    Question: [],
    Answer: answers
  }
}

describe('dnslink', () => {
  let dns: StubbedInstance<DNS>
  let name: DNSLink

  beforeEach(async () => {
    dns = stubInterface()
    name = dnsLink({
      dns,
      logger: defaultLogger()
    })
  })

  it('should resolve a domain', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true, offline: true })
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
    expect(result).to.have.nested.property('[0].path', '')
  })

  it('should cache the response', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    await name.resolve('foobar.baz')
    await name.resolve('foobar.baz')

    expect(dns.query).to.have.property('callCount', 1)
  })

  it('should ignore the cached response', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    await name.resolve('foobar.baz')
    await name.resolve('foobar.baz', { nocache: true })

    expect(dns.query).to.have.property('callCount', 2)
  })

  it('should return only answers within their TTL', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 0.5,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }, {
      name: '_dnslink.foobar.baz.',
      TTL: 10,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'
    }]))

    await expect(name.resolve('foobar.baz')).to.eventually.have.lengthOf(2)

    await delay(1000)

    await expect(name.resolve('foobar.baz')).to.eventually.have.lengthOf(1)
  })

  it('should resolve a domain to multiple values', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }, {
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true, offline: true })
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'))
    expect(result).to.have.nested.property('[0].path', '')
    expect(result).to.have.deep.nested.property('[1].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
    expect(result).to.have.nested.property('[1].path', '')
  })

  it('should retry without `_dnslink.` on a domain', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').rejects(new NotFoundError('Not found'))
    dns.query.withArgs('foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true, offline: true })
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
    expect(result).to.have.nested.property('[0].path', '')
  })

  it('should handle bad records', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink'
    }, {
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=invalid'
    }, {
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'bad text record'
    }, {
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/hyper/link-for-other-namespace'
    }, {
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/invalid cid'
    }, {
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true, offline: true })
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
  })

  it('should handle records wrapped in quotation marks', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: '"dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn"'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true, offline: true })
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
  })

  it('should support trailing slash in returned dnslink value', async () => {
    // see https://github.com/ipfs/helia/issues/402
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe/'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true })
    // spellchecker:disable-next-line
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'), 'doesn\'t support trailing slashes')
  })

  it('should support paths in returned dnslink value', async () => {
    // see https://github.com/ipfs/helia/issues/402
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe/foobar/path/123'
    }]))

    const result = await name.resolve('foobar.baz', { nocache: true })
    // spellchecker:disable-next-line
    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'), 'doesn\'t support trailing paths')
    expect(result).to.have.nested.property('[0].path', '/foobar/path/123')
  })

  it('should resolve recursive dnslink -> <Qm_PeerId>/<path>', async () => {
    const multihash = 'QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'

    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: `dnslink=/ipns/${multihash}/foobar/path/123`
    }]))

    const result = await name.resolve('foobar.baz')

    if (result == null) {
      throw new Error('Did not resolve entry')
    }

    expect(result).to.have.deep.nested.property('[0].value', Digest.decode(base58btc.baseDecode(multihash)))
    expect(result).to.have.nested.property('[0].path', '/foobar/path/123')
  })

  it('should resolve recursive dnslink -> <12D3Koo_PeerId>/<path>', async () => {
    const multihash = '12D3KooWDUyFJTGJADckWJdfh2haqj6ckaXFWi1DReJ4RP8KsHg5'

    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: `dnslink=/ipns/${multihash}/foobar/path/123`
    }]))

    const result = await name.resolve('foobar.baz')

    if (result == null) {
      throw new Error('Did not resolve entry')
    }

    expect(result).to.have.deep.nested.property('[0].value', Digest.decode(base58btc.baseDecode(multihash)))
    expect(result).to.have.nested.property('[0].path', '/foobar/path/123')
  })

  it('should resolve recursive dnslink -> <IPNS_base36_CID>/<path>', async () => {
    const cid = 'k51qzi5uqu5dhjghbwdvbo6mi40htrq6e2z4pwgp15pgv3ho1azvidttzh8yy2'

    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: 'foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: `dnslink=/ipns/${cid}/foobar/path/123`
    }]))

    const result = await name.resolve('foobar.baz')

    if (result == null) {
      throw new Error('Did not resolve entry')
    }

    expect(result).to.have.deep.nested.property('[0].value', CID.parse(cid).multihash)
    expect(result).to.have.nested.property('[0].path', '/foobar/path/123')
  })

  it('should follow CNAMES to delegated DNSLink domains', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.CNAME,
      data: '_dnslink.delegated.foobar.baz'
    }]))
    dns.query.withArgs('_dnslink.delegated.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.delegated.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'
    }]))
    const result = await name.resolve('foobar.baz')

    if (result == null) {
      throw new Error('Did not resolve entry')
    }

    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'))
  })

  it('should resolve dnslink namespace', async () => {
    const cid = CID.parse('bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe')
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/dnslink/delegated.foobar.baz'
    }]))
    dns.query.withArgs('_dnslink.delegated.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.delegated.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'
    }]))

    const result = await name.resolve('foobar.baz')

    if (result == null) {
      throw new Error('Did not resolve entry')
    }

    expect(result).to.have.deep.nested.property('[0].cid', cid)
  })

  it('should include DNS Answer in result', async () => {
    const answer = {
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'
    }
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([answer]))

    const result = await name.resolve('foobar.baz')

    if (result == null) {
      throw new Error('Did not resolve entry')
    }

    expect(result).to.have.deep.nested.property('[0].answer', answer)
  })

  it('should support custom parsers', async () => {
    const answer = {
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/hello/world'
    }
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([answer]))

    interface HelloResult extends DNSLinkResolveResult {
      value?: string
    }

    const name = dnsLink({
      dns,
      logger: defaultLogger()
    }, {
      namespaces: {
        hello: (value, answer): HelloResult => {
          return {
            namespace: 'hello',
            value: value.split('/hello/').pop(),
            answer
          }
        }
      }
    })

    const result = await name.resolve('foobar.baz')

    if (result[0].namespace === 'hello') {
      // assert that we can derive the returned type from the parser config
      // passed to the factory method correctly
      const res: HelloResult = result[0]
      expect(res).to.be.ok('dummy assertion')
    }

    expect(result).to.have.nested.property('[0].namespace', 'hello')
    expect(result).to.have.nested.property('[0].value', 'world')
  })

  it('should resolve recursive DNSLink names', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipns/qux.quux'
    }]))

    dns.query.withArgs('_dnslink.qux.quux').resolves(dnsResponse([{
      name: '_dnslink.qux.quux.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    const result = await name.resolve('foobar.baz')

    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
  })

  it('should resolve multiple recursive DNSLink names', async () => {
    dns.query.withArgs('_dnslink.foobar.baz').resolves(dnsResponse([{
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipns/qux.quux'
    }, {
      name: '_dnslink.foobar.baz.',
      TTL: 60,
      type: RecordType.TXT,
      // spellchecker:disable-next-line
      data: 'dnslink=/ipfs/bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'
    }]))

    dns.query.withArgs('_dnslink.qux.quux').resolves(dnsResponse([{
      name: '_dnslink.qux.quux.',
      TTL: 60,
      type: RecordType.TXT,
      data: 'dnslink=/ipfs/QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'
    }]))

    const result = await name.resolve('foobar.baz')

    expect(result).to.have.deep.nested.property('[0].cid', CID.parse('bafybeifcaqowoyito3qvsmbwbiugsu4umlxn4ehu223hvtubbfvwyuxjoe'))
    expect(result).to.have.deep.nested.property('[1].cid', CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn'))
  })
})
