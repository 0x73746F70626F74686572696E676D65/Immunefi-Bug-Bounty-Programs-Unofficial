/**
 * @packageDocumentation
 *
 * This module implements the [Bitswap protocol](https://docs.ipfs.tech/concepts/bitswap/) in TypeScript.
 *
 * It supersedes the older [ipfs-bitswap](https://www.npmjs.com/package/ipfs-bitswap) module with the aim of being smaller, faster, better integrated with libp2p/helia, having fewer dependencies and using standard JavaScript instead of Node.js APIs.
 */

import { start } from '@libp2p/interface'
import { BitswapBlockBroker } from './block-broker.ts'
import type { BitswapBlockBrokerInit } from './block-broker.ts'
import type { BitswapNetworkNotifyProgressEvents, BitswapNetworkWantProgressEvents, BitswapNetworkProgressEvents } from './network.ts'
import type { WantType } from './pb/message.ts'
import type { BlockBrokerGetBlockProgressEvents, CreateSessionOptions, HasherLoader, HeliaMixin, ProviderOptions, SessionBlockBroker } from '@helia/interface'
import type { Routing } from '@helia/interface'
import type { HeliaWithLibp2p } from '@helia/libp2p'
import type { Libp2p, AbortOptions, Startable, ComponentLogger, Metrics, PeerId, ServiceMap } from '@libp2p/interface'
import type { Blockstore } from 'interface-blockstore'
import type { CID } from 'multiformats/cid'
import type { ProgressEvent, ProgressOptions } from 'progress-events'

export type BitswapWantProgressEvents =
  BitswapWantBlockProgressEvents

export type BitswapNotifyProgressEvents =
  BitswapNetworkNotifyProgressEvents

export type BitswapWantBlockProgressEvents =
  ProgressEvent<'bitswap:unwant', CID> |
  ProgressEvent<'bitswap:want', CID> |
  ProgressEvent<'bitswap:block', { cid: CID, sender: PeerId }> |
  BitswapNetworkWantProgressEvents |
  BlockBrokerGetBlockProgressEvents

export type { BitswapNetworkNotifyProgressEvents }
export type { BitswapNetworkWantProgressEvents }
export type { BitswapNetworkProgressEvents }
export type { WantType }
export type { BitswapProvider } from './network.ts'
export type { BitswapBlockBrokerInit } from './block-broker.ts'

export type WantStatus = 'want' | 'sending' | 'sent'

export interface WantListEntry {
  cid: CID
  priority: number
  wantType: WantType
}

export interface PeerWantListEntry extends WantListEntry {
  status: WantStatus
}

export interface Bitswap extends Startable {
  /**
   * Returns the current state of the wantlist
   */
  getWantlist(): WantListEntry[]

  /**
   * Returns the current state of the wantlist for a peer, if it is being
   * tracked
   */
  getPeerWantlist(peerId: PeerId): PeerWantListEntry[] | undefined

  /**
   * Notify bitswap that a new block is available
   */
  notify(cid: CID, options?: ProgressOptions<BitswapNotifyProgressEvents>): Promise<void>

  /**
   * Start a session to retrieve a file from the network
   */
  want(cid: CID, options?: AbortOptions & ProgressOptions<BitswapWantProgressEvents> & ProviderOptions): Promise<Uint8Array>

  /**
   * Start a session to retrieve a file from the network
   */
  createSession(options?: CreateSessionOptions<BitswapWantProgressEvents>): Required<Pick<SessionBlockBroker<BitswapWantProgressEvents>, 'retrieve' | 'addPeer'>>
}

export interface BitswapComponents {
  routing: Routing
  blockstore: Blockstore
  logger: ComponentLogger
  libp2p: Libp2p
  getHasher: HasherLoader
  metrics?: Metrics
}

export interface BitswapOptions {
  /**
   * This is the maximum number of concurrent inbound bitswap streams that are
   * allowed
   *
   * @default 32
   */
  maxInboundStreams?: number

  /**
   * This is the maximum number of concurrent outbound bitswap streams that are
   * allowed
   *
   * @default 128
   */
  maxOutboundStreams?: number

  /**
   * An incoming stream must resolve within this number of seconds
   *
   * @default 30000
   */
  incomingStreamTimeout?: number

  /**
   * Whether to run on transient (e.g. time/data limited) connections
   *
   * @default false
   */
  runOnLimitedConnections?: boolean

  /**
   * The protocol that we speak
   *
   * @default '/ipfs/bitswap/1.2.0'
   */
  protocol?: string

  /**
   * When sending messages to peers (our wantlist updates, blocks from their
   * wantlist), how many messages to send at once
   *
   * @default 50
   */
  messageSendConcurrency?: number

  /**
   * Wantlist or blocks must be sent to peers within this many milliseconds
   *
   * @default 10_000
   */
  messageSendTimeout?: number

  /**
   * Incoming wantlist or block messages must be received from peers within this
   * many milliseconds
   *
   * @default 10_000
   */
  messageReceiveTimeout?: number

  /**
   * When sending blocks to individual peers, how many messages to send at once.
   * This should be left as the default.
   *
   * @default 1
   */
  sendBlocksConcurrency?: number

  /**
   * Sending blocks is triggered by an incoming Bitswap message from the peer.
   * To prevent runaway message sending, message send operations are stored in
   * a queue. This setting defines the maximum queue length.
   *
   * Once the queue exceeds this length no further message send operations will
   * be queued. Local wantlists are updated synchronously so the updated wants
   * should be handled by send operations still in the queue.
   *
   * @default 10
   */
  sendBlocksMaxQueueLength?: number

  /**
   * When sending blocks to peers, timeout after this many milliseconds.
   * This is useful for preventing slow/large peer-connections from consuming
   * your bandwidth/streams.
   *
   * @default 10_000
   */
  sendBlocksTimeout?: number

  /**
   * When a block is added to the blockstore and we are about to send that block
   * to peers who have it in their wantlist, wait this many milliseconds before
   * queueing the send job in case more blocks are added that they want
   *
   * @default 10
   */
  sendBlocksDebounce?: number

  /**
   * When a want is added to the local wantlist, wait this many milliseconds
   * before sending the wantlist to connected or session peers in case more
   * wants are about to be added
   *
   * @default 10
   */
  sendWantlistDebounce?: number

  /**
   * If the client sends a want-have, and we have the corresponding block, we
   * check the size of the block and if it's small enough we send the block
   * itself, rather than sending a HAVE.
   *
   * This defines the maximum size up to which we replace a HAVE with a block.
   *
   * @default 1024
   */
  maxSizeReplaceHasWithBlock?: number

  /**
   * The maximum size in bytes of a message that we will send. If a message is
   * larger than this (due to lots of blocks or wantlist entries) it will be
   * broken up into several smaller messages that are under this size.
   *
   * @see https://github.com/ipfs/boxo/blob/eeea414587350401b6b804f0574ed8436833331d/bitswap/client/internal/messagequeue/messagequeue.go#L33
   *
   * @default 2097152
   */
  maxOutgoingMessageSize?: number

  /**
   * The maximum size in bytes of an incoming message that we will process.
   *
   * Messages larger than this will cause the incoming stream to be reset.
   *
   * Defaults to `maxOutgoingMessageSize`
   *
   * @default 2097152
   */
  maxIncomingMessageSize?: number

  /**
   * If a block has been sent to a peer and it is requested again by the same
   * peer, do not send it again until this many ms have elapsed
   *
   * @default 5000
   */
  doNotResendBlockWindow?: number

  /**
   * Restrict the local copy of each peer wantlist to this many entries
   *
   * @default 1024
   */
  maxWantlistSize?: number
}

/**
 * Return a Helia node augmented with a libp2p instance
 */
export function withBitswap <M extends ServiceMap = ServiceMap> (helia: HeliaWithLibp2p<M>, options: BitswapBlockBrokerInit = {}): HeliaWithLibp2p<M> {
  const mixin: HeliaMixin<HeliaWithLibp2p> = {
    name: 'bitswap',
    start: async (helia) => {
      if (helia.status === 'starting' && !helia.hasBlockBroker('bitswap')) {
        const broker = new BitswapBlockBroker(helia, options)
        await start(broker)

        helia.addBlockBroker(broker)
      }
    }
  }

  helia.addMixin(mixin)

  return helia
}
