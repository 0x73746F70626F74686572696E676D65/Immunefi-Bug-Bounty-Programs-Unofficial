<p align="center">
  <a href="https://github.com/ipfs/helia-http" title="helia-http">
    <img src="https://raw.githubusercontent.com/ipfs/helia/main/assets/helia.png" alt="Helia logo" width="300" />
  </a>
</p>

# @helia/http

[![ipfs.tech](https://img.shields.io/badge/project-IPFS-blue.svg?style=flat-square)](https://ipfs.tech)
[![Discuss](https://img.shields.io/discourse/https/discuss.ipfs.tech/posts.svg?style=flat-square)](https://discuss.ipfs.tech)
[![codecov](https://img.shields.io/codecov/c/github/ipfs/helia.svg?style=flat-square)](https://codecov.io/gh/ipfs/helia)
[![CI](https://img.shields.io/github/actions/workflow/status/ipfs/helia/main.yml?branch=main\&style=flat-square)](https://github.com/ipfs/helia/actions/workflows/main.yml?query=branch%3Amain)

> A lightweight implementation of IPFS over HTTP in JavaScript

# About

<!--

!IMPORTANT!

Everything in this README between "# About" and "# Install" is automatically
generated and will be overwritten the next time the doc generator is run.

To make changes to this section, please update the @packageDocumentation section
of src/index.js or src/index.ts

To experiment with formatting, please run "npm run docs" from the root of this
repo and examine the changes made.

-->

Exports a `withHTTP` function configures a Helia node that with block brokers and gateways that only run over HTTP.

By default, content and peer routing are requests are resolved using the [Delegated HTTP Routing API](https://specs.ipfs.tech/routing/http-routing-v1/) and blocks are fetched from [Trustless Gateways](https://specs.ipfs.tech/http-gateways/trustless-gateway/).

Pass it to other modules like @helia/unixfs to fetch files from the distributed web.

## Example

```typescript
import { withHTTP } from '@helia/http'
import { unixfs } from '@helia/unixfs'
import { createHeliaLight } from 'helia'
import { CID } from 'multiformats/cid'

const helia = await withHTTP(createHeliaLight(), {
  delegatedRouters: [
    'https://delegated-ipfs.dev'
  ],
  recursiveGateways: [
    'https://trustless-gateway.link',
    'https://4everland.io'
  ]
}).start()

const fs = unixfs(helia)
fs.cat(CID.parse('bafyFoo'))
```

## Example - without using this module

It's possible to manually configure your node without using this module.

```typescript
import { createHeliaLight } from 'helia'
import { trustlessGatewayBlockBroker } from '@helia/trustless-gateway-client'
import { fallbackRouter } from '@helia/fallback-router'
import { delegatedHTTPRouter } from '@helia/delegated-http-routing-client'
import { unixfs } from '@helia/unixfs'
import { CID } from 'multiformats/cid'

const helia = await createHeliaLight({
  blockBrokers: [
    trustlessGatewayBlockBroker()
  ],
  routers: [
    delegatedHTTPRouter({
      url: 'https://delegated-ipfs.dev'
    }),
    fallbackRouter({
      gateways: ['https://trustless-gateway.link', 'https://4everland.io']
    })
  ]
}).start()

const fs = unixfs(helia)
fs.cat(CID.parse('bafyFoo'))
```

# Install

```console
$ npm i @helia/http
```

## Browser `<script>` tag

Loading this module through a script tag will make its exports available as `HeliaHttp` in the global namespace.

```html
<script src="https://unpkg.com/@helia/http/dist/index.min.js"></script>
```

# Helia-http

# API Docs

- <https://ipfs.github.io/helia/modules/_helia_http.html>

# License

Licensed under either of

- Apache 2.0, ([LICENSE-APACHE](https://github.com/ipfs/helia/blob/main/packages/http/LICENSE-APACHE) / <http://www.apache.org/licenses/LICENSE-2.0>)
- MIT ([LICENSE-MIT](https://github.com/ipfs/helia/blob/main/packages/http/LICENSE-MIT) / <http://opensource.org/licenses/MIT>)

# Contribute

Contributions welcome! Please check out [the issues](https://github.com/ipfs/helia/issues).

Also see our [contributing document](https://github.com/ipfs/community/blob/master/CONTRIBUTING_JS.md) for more information on how we work, and about contributing in general.

Please be aware that all interactions related to this repo are subject to the IPFS [Code of Conduct](https://github.com/ipfs/community/blob/master/code-of-conduct.md).

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in the work by you, as defined in the Apache-2.0 license, shall be dual licensed as above, without any additional terms or conditions.

[![](https://cdn.rawgit.com/jbenet/contribute-ipfs-gif/master/img/contribute.gif)](https://github.com/ipfs/community/blob/master/CONTRIBUTING.md)
