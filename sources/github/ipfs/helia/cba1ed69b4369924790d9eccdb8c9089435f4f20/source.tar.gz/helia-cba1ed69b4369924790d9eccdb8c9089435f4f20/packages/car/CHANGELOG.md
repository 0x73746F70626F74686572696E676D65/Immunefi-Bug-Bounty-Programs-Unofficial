# Changelog

## [6.0.9](https://github.com/ipfs/helia/compare/car-v6.0.8...car-v6.0.9) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^8.0.8 to ^8.0.9
    * @helia/unixfs bumped from ^8.0.8 to ^8.0.9

## [6.0.8](https://github.com/ipfs/helia/compare/car-v6.0.7...car-v6.0.8) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.1 to ^7.1.2
    * @helia/utils bumped from ^3.0.5 to ^3.0.6
  * devDependencies
    * @helia/mfs bumped from ^8.0.7 to ^8.0.8
    * @helia/unixfs bumped from ^8.0.7 to ^8.0.8

## [6.0.7](https://github.com/ipfs/helia/compare/car-v6.0.6...car-v6.0.7) (2026-09-14)


### Bug Fixes

* update protons and regenerate messages ([#1127](https://github.com/ipfs/helia/issues/1127)) ([b34bc7c](https://github.com/ipfs/helia/commit/b34bc7c76d8ab1f1eeba9893af792299b05de111))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^8.0.6 to ^8.0.7
    * @helia/unixfs bumped from ^8.0.6 to ^8.0.7

## [6.0.6](https://github.com/ipfs/helia/compare/car-v6.0.5...car-v6.0.6) (2026-09-10)


### Bug Fixes

* update unixfs deps to allow for streaming dags ([#1125](https://github.com/ipfs/helia/issues/1125)) ([16fc74d](https://github.com/ipfs/helia/commit/16fc74d30cded1773e9ac18b0a62ca4582f7eab9))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^8.0.5 to ^8.0.6
    * @helia/unixfs bumped from ^8.0.5 to ^8.0.6

## [6.0.5](https://github.com/ipfs/helia/compare/car-v6.0.4...car-v6.0.5) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.0 to ^7.1.1
    * @helia/utils bumped from ^3.0.4 to ^3.0.5
  * devDependencies
    * @helia/mfs bumped from ^8.0.4 to ^8.0.5
    * @helia/unixfs bumped from ^8.0.4 to ^8.0.5

## [6.0.4](https://github.com/ipfs/helia/compare/car-v6.0.3...car-v6.0.4) (2026-07-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.3 to ^7.1.0
    * @helia/utils bumped from ^3.0.3 to ^3.0.4
  * devDependencies
    * @helia/mfs bumped from ^8.0.3 to ^8.0.4
    * @helia/unixfs bumped from ^8.0.3 to ^8.0.4

## [6.0.3](https://github.com/ipfs/helia/compare/car-v6.0.2...car-v6.0.3) (2026-07-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.2 to ^7.0.3
    * @helia/utils bumped from ^3.0.2 to ^3.0.3
  * devDependencies
    * @helia/mfs bumped from ^8.0.2 to ^8.0.3
    * @helia/unixfs bumped from ^8.0.2 to ^8.0.3

## [6.0.2](https://github.com/ipfs/helia/compare/car-v6.0.1...car-v6.0.2) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.1 to ^7.0.2
    * @helia/utils bumped from ^3.0.1 to ^3.0.2
  * devDependencies
    * @helia/mfs bumped from ^8.0.1 to ^8.0.2
    * @helia/unixfs bumped from ^8.0.1 to ^8.0.2

## [6.0.1](https://github.com/ipfs/helia/compare/car-v6.0.0...car-v6.0.1) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.0 to ^7.0.1
    * @helia/utils bumped from ^3.0.0 to ^3.0.1
  * devDependencies
    * @helia/mfs bumped from ^8.0.0 to ^8.0.1
    * @helia/unixfs bumped from ^8.0.0 to ^8.0.1

## [6.0.0](https://github.com/ipfs/helia/compare/car-v5.4.2...car-v6.0.0) (2026-06-29)


### ⚠ BREAKING CHANGES

* import from `@helia/interface` not `@helia/interface/foo`
* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))
* returned instances of `CID` and `MultihashDigest` come from the `multiformats@14.x.x` module

### Features

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Bug Fixes

* export all types at root of `@helia/interface` ([#1053](https://github.com/ipfs/helia/issues/1053)) ([a464d83](https://github.com/ipfs/helia/commit/a464d83a68eea5a6f9af8fa26bf95ef9c997af61))
* update to multiformats@14.x.x ([#1039](https://github.com/ipfs/helia/issues/1039)) ([f6cc764](https://github.com/ipfs/helia/commit/f6cc7640840b77757c09d9463539b41e6ea33099))


### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#1015](https://github.com/ipfs/helia/issues/1015)) ([ae98a4f](https://github.com/ipfs/helia/commit/ae98a4f4940310383c2a384cde64f99264326583))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.1 to ^7.0.0
    * @helia/utils bumped from ^2.5.2 to ^3.0.0
  * devDependencies
    * @helia/mfs bumped from ^7.1.1 to ^8.0.0
    * @helia/unixfs bumped from ^7.2.1 to ^8.0.0

## [5.4.2](https://github.com/ipfs/helia/compare/car-v5.4.1...car-v5.4.2) (2026-04-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.5.1 to ^2.5.2

## [5.4.1](https://github.com/ipfs/helia/compare/car-v5.4.0...car-v5.4.1) (2026-04-10)


### Bug Fixes

* add module-sync ([#1001](https://github.com/ipfs/helia/issues/1001)) ([ef5363e](https://github.com/ipfs/helia/commit/ef5363e834439ba1838a408639cb2d05d3ba6867))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.0 to ^6.2.1
    * @helia/utils bumped from ^2.5.0 to ^2.5.1
  * devDependencies
    * @helia/mfs bumped from ^7.1.0 to ^7.1.1
    * @helia/unixfs bumped from ^7.2.0 to ^7.2.1

## [5.4.0](https://github.com/ipfs/helia/compare/car-v5.3.10...car-v5.4.0) (2026-04-08)


### Features

* emit standardized block broker events ([#995](https://github.com/ipfs/helia/issues/995)) ([397f2d8](https://github.com/ipfs/helia/commit/397f2d86cefd425178a67e70e8f338093d666fe9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.1.1 to ^6.2.0
    * @helia/utils bumped from ^2.4.2 to ^2.5.0
  * devDependencies
    * @helia/mfs bumped from ^7.0.5 to ^7.1.0
    * @helia/unixfs bumped from ^7.1.0 to ^7.2.0

## [5.3.10](https://github.com/ipfs/helia/compare/car-v5.3.9...car-v5.3.10) (2026-03-18)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^7.0.4 to ^7.0.5
    * @helia/unixfs bumped from ^7.0.4 to ^7.1.0

## [5.3.9](https://github.com/ipfs/helia/compare/car-v5.3.8...car-v5.3.9) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.1.0 to ^6.1.1
    * @helia/utils bumped from ^2.4.1 to ^2.4.2
  * devDependencies
    * @helia/mfs bumped from ^7.0.3 to ^7.0.4
    * @helia/unixfs bumped from ^7.0.3 to ^7.0.4

## [5.3.8](https://github.com/ipfs/helia/compare/car-v5.3.7...car-v5.3.8) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.4.0 to ^2.4.1

## [5.3.7](https://github.com/ipfs/helia/compare/car-v5.3.6...car-v5.3.7) (2026-02-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.3 to ^6.1.0
    * @helia/utils bumped from ^2.3.5 to ^2.4.0
  * devDependencies
    * @helia/mfs bumped from ^7.0.2 to ^7.0.3
    * @helia/unixfs bumped from ^7.0.2 to ^7.0.3

## [5.3.6](https://github.com/ipfs/helia/compare/car-v5.3.5...car-v5.3.6) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.2 to ^6.0.3
    * @helia/utils bumped from ^2.3.4 to ^2.3.5
  * devDependencies
    * @helia/mfs bumped from ^7.0.1 to ^7.0.2
    * @helia/unixfs bumped from ^7.0.1 to ^7.0.2

## [5.3.5](https://github.com/ipfs/helia/compare/car-v5.3.4...car-v5.3.5) (2026-01-15)


### Bug Fixes

* use non-deprecated factory function to create delegated client ([#934](https://github.com/ipfs/helia/issues/934)) ([20ba9cf](https://github.com/ipfs/helia/commit/20ba9cf6256961d2b664af0e8f48b5e9d009d834))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.3 to ^2.3.4
  * devDependencies
    * @helia/mfs bumped from ^7.0.0 to ^7.0.1
    * @helia/unixfs bumped from ^7.0.0 to ^7.0.1

## [5.3.4](https://github.com/ipfs/helia/compare/car-v5.3.3...car-v5.3.4) (2026-01-12)


### Dependencies

* update ipfs-unixfs-exporter in @helia/car ([#933](https://github.com/ipfs/helia/issues/933)) ([4e19769](https://github.com/ipfs/helia/commit/4e19769aaa0f5b1fe6c9471275cb28f850d4ab56))
* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^6.0.4 to ^7.0.0
    * @helia/unixfs bumped from ^6.0.4 to ^7.0.0

## [5.3.3](https://github.com/ipfs/helia/compare/car-v5.3.2...car-v5.3.3) (2025-12-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.2 to ^2.3.3

## [5.3.2](https://github.com/ipfs/helia/compare/car-v5.3.1...car-v5.3.2) (2025-12-12)


### Bug Fixes

* throw a specific error when offline and a block is missing ([#917](https://github.com/ipfs/helia/issues/917)) ([e27aa2d](https://github.com/ipfs/helia/commit/e27aa2de96fef39950f4c7d00a517208372aaf4e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.1 to ^2.3.2
  * devDependencies
    * @helia/mfs bumped from ^6.0.3 to ^6.0.4
    * @helia/unixfs bumped from ^6.0.3 to ^6.0.4

## [5.3.1](https://github.com/ipfs/helia/compare/car-v5.3.0...car-v5.3.1) (2025-12-12)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.0 to ^2.3.1

## [5.3.0](https://github.com/ipfs/helia/compare/car-v5.2.5...car-v5.3.0) (2025-11-20)


### Features

* allow specifying graph export strategy ([#907](https://github.com/ipfs/helia/issues/907)) ([7676912](https://github.com/ipfs/helia/commit/7676912ec08b7599309e3a6afdd4183f8dc61b27))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.5 to ^2.3.0

## [5.2.5](https://github.com/ipfs/helia/compare/car-v5.2.4...car-v5.2.5) (2025-11-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.4 to ^2.2.5

## [5.2.4](https://github.com/ipfs/helia/compare/car-v5.2.3...car-v5.2.4) (2025-11-13)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.3 to ^2.2.4

## [5.2.3](https://github.com/ipfs/helia/compare/car-v5.2.2...car-v5.2.3) (2025-10-29)


### Bug Fixes

* use libp2p provider routing field ([#889](https://github.com/ipfs/helia/issues/889)) ([d4d97b8](https://github.com/ipfs/helia/commit/d4d97b83f76be7e3b480052467408839f808e230))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.1 to ^6.0.2
    * @helia/utils bumped from ^2.2.2 to ^2.2.3
  * devDependencies
    * @helia/mfs bumped from ^6.0.2 to ^6.0.3
    * @helia/unixfs bumped from ^6.0.2 to ^6.0.3

## [5.2.2](https://github.com/ipfs/helia/compare/car-v5.2.1...car-v5.2.2) (2025-10-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.0 to ^6.0.1
    * @helia/utils bumped from ^2.2.1 to ^2.2.2
  * devDependencies
    * @helia/mfs bumped from ^6.0.1 to ^6.0.2
    * @helia/unixfs bumped from ^6.0.1 to ^6.0.2

## [5.2.1](https://github.com/ipfs/helia/compare/car-v5.2.0...car-v5.2.1) (2025-10-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.0 to ^2.2.1

## [5.2.0](https://github.com/ipfs/helia/compare/car-v5.1.1...car-v5.2.0) (2025-10-20)


### Features

* add offset/length to export slices of DAGs ([#881](https://github.com/ipfs/helia/issues/881)) ([921696f](https://github.com/ipfs/helia/commit/921696f914fbe2af6ba04464fbbcf5072cf8d088))
* support directory enumeration ([#883](https://github.com/ipfs/helia/issues/883)) ([4e5ff55](https://github.com/ipfs/helia/commit/4e5ff555d61e124c68e041cfab415108f199b8bd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.1.1 to ^2.2.0

## [5.1.1](https://github.com/ipfs/helia/compare/car-v5.1.0...car-v5.1.1) (2025-10-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.1.0 to ^2.1.1

## [5.1.0](https://github.com/ipfs/helia/compare/car-v5.0.1...car-v5.1.0) (2025-10-17)


### Features

* add `includeTraversalBlocks` options ([#872](https://github.com/ipfs/helia/issues/872)) ([eb91b81](https://github.com/ipfs/helia/commit/eb91b810af71375cd97677dfaa9247cfa974b12c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.0.1 to ^2.1.0

## [5.0.1](https://github.com/ipfs/helia/compare/car-v5.0.0...car-v5.0.1) (2025-10-09)


### Bug Fixes

* enforce maximum identity hash size ([#865](https://github.com/ipfs/helia/issues/865)) ([d9051cd](https://github.com/ipfs/helia/commit/d9051cdc2fd19ab7def32d195b5798b27d85a078)), closes [#846](https://github.com/ipfs/helia/issues/846)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^6.0.0 to ^6.0.1
    * @helia/unixfs bumped from ^6.0.0 to ^6.0.1

## [5.0.0](https://github.com/ipfs/helia/compare/car-v4.2.0...car-v5.0.0) (2025-10-09)


### ⚠ BREAKING CHANGES

* car.stream has been renamed car.export
* uses libp2p v3 and updated block/data stores

### Features

* rename car stream to export ([#859](https://github.com/ipfs/helia/issues/859)) ([63338b9](https://github.com/ipfs/helia/commit/63338b9c261a1120592e5afb256dfa8c8feed16b))
* update to libp2p@v3 and latest data/block stores ([#856](https://github.com/ipfs/helia/issues/856)) ([34d3ecd](https://github.com/ipfs/helia/commit/34d3ecd76c8424387c57221000e226f08ccd1d1e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.4.0 to ^6.0.0
  * devDependencies
    * @helia/mfs bumped from ^5.1.0 to ^6.0.0
    * @helia/unixfs bumped from ^5.1.0 to ^6.0.0

## [4.2.0](https://github.com/ipfs/helia/compare/car-v4.1.3...car-v4.2.0) (2025-07-31)


### Features

* expose providers option ([#834](https://github.com/ipfs/helia/issues/834)) ([5a911c6](https://github.com/ipfs/helia/commit/5a911c6977ec47d1906ccc69b5f57667f22d9ccf))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^5.0.4 to ^5.1.0
    * @helia/unixfs bumped from ^5.0.4 to ^5.1.0

## [4.1.3](https://github.com/ipfs/helia/compare/car-v4.1.2...car-v4.1.3) (2025-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.2 to ^5.4.0
  * devDependencies
    * @helia/mfs bumped from ^5.0.3 to ^5.0.4
    * @helia/unixfs bumped from ^5.0.3 to ^5.0.4

## [4.1.2](https://github.com/ipfs/helia/compare/car-v4.1.1...car-v4.1.2) (2025-05-20)


### Dependencies

* update aegir to 47.x.x ([#804](https://github.com/ipfs/helia/issues/804)) ([60fbbc2](https://github.com/ipfs/helia/commit/60fbbc2eb08e023e2eac02ae0e89ed143d715084))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.1 to ^5.3.2
  * devDependencies
    * @helia/mfs bumped from ^5.0.2 to ^5.0.3
    * @helia/unixfs bumped from ^5.0.2 to ^5.0.3

## [4.1.1](https://github.com/ipfs/helia/compare/car-v4.1.0...car-v4.1.1) (2025-05-13)


### Dependencies

* update all deps ([#792](https://github.com/ipfs/helia/issues/792)) ([d43efc7](https://github.com/ipfs/helia/commit/d43efc7bdfff34071a8e4e22e01f659fbac0b78e))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.0 to ^5.3.1
  * devDependencies
    * @helia/mfs bumped from ^5.0.1 to ^5.0.2
    * @helia/unixfs bumped from ^5.0.1 to ^5.0.2

## [4.1.0](https://github.com/ipfs/helia/compare/car-v4.0.4...car-v4.1.0) (2025-05-13)


### Features

* car export supports custom dag traversal and export ([#767](https://github.com/ipfs/helia/issues/767)) ([313e2c1](https://github.com/ipfs/helia/commit/313e2c10a71c4f42533c3f077c6720563dd09ce5))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.2.1 to ^5.3.0
  * devDependencies
    * @helia/mfs bumped from ^5.0.0 to ^5.0.1
    * @helia/unixfs bumped from ^5.0.0 to ^5.0.1

## [4.0.4](https://github.com/ipfs/helia/compare/car-v4.0.3...car-v4.0.4) (2025-03-20)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^4.0.3 to ^5.0.0
    * @helia/unixfs bumped from ^4.0.3 to ^5.0.0

## [4.0.3](https://github.com/ipfs/helia/compare/car-v4.0.2...car-v4.0.3) (2025-03-13)


### Documentation

* add spell checker to ci ([#743](https://github.com/ipfs/helia/issues/743)) ([45ca6bc](https://github.com/ipfs/helia/commit/45ca6bc70b1644028500101044595fa0e2199b07))
* update @helia/car export method example ([#761](https://github.com/ipfs/helia/issues/761)) ([73cb631](https://github.com/ipfs/helia/commit/73cb631e7347688012f429cd69b1046db249e694))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.2.0 to ^5.2.1
  * devDependencies
    * @helia/mfs bumped from ^4.0.2 to ^4.0.3
    * @helia/unixfs bumped from ^4.0.2 to ^4.0.3

## [4.0.2](https://github.com/ipfs/helia/compare/car-v4.0.1...car-v4.0.2) (2025-01-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.1.0 to ^5.2.0
  * devDependencies
    * @helia/mfs bumped from ^4.0.1 to ^4.0.2
    * @helia/unixfs bumped from ^4.0.1 to ^4.0.2

## [4.0.1](https://github.com/ipfs/helia/compare/car-v4.0.0...car-v4.0.1) (2024-11-18)


### Dependencies

* bump aegir from 44.1.4 to 45.0.1 ([#669](https://github.com/ipfs/helia/issues/669)) ([e58e49c](https://github.com/ipfs/helia/commit/e58e49c6aed8ea9d1e9851435a25e33fdbee3781))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.0.0 to ^5.1.0
  * devDependencies
    * @helia/mfs bumped from ^4.0.0 to ^4.0.1
    * @helia/unixfs bumped from ^4.0.0 to ^4.0.1

## [4.0.0](https://github.com/ipfs/helia/compare/car-v3.2.1...car-v4.0.0) (2024-10-07)


### ⚠ BREAKING CHANGES

* the `.dagWalkers` property has been removed
* helia now uses libp2p@2.x.x

### Bug Fixes

* add doc-check script and export types used by functions ([#637](https://github.com/ipfs/helia/issues/637)) ([4f14996](https://github.com/ipfs/helia/commit/4f14996a9b976f2b60f4c8fe52a4fd1632420749))
* replace dag walkers with generic CID extraction from blocks ([#447](https://github.com/ipfs/helia/issues/447)) ([5ff6998](https://github.com/ipfs/helia/commit/5ff6998e6bc8b04e3407bc98c1924c55f632d9b7))
* update to libp2p@2.x.x ([#630](https://github.com/ipfs/helia/issues/630)) ([ec8bf66](https://github.com/ipfs/helia/commit/ec8bf66dd870b42d6e5ef2b41706102397e0d39a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.3.1 to ^5.0.0
  * devDependencies
    * @helia/mfs bumped from ^3.0.8 to ^4.0.0
    * @helia/unixfs bumped from ^3.0.7 to ^4.0.0

## [3.2.1](https://github.com/ipfs/helia/compare/car-v3.2.0...car-v3.2.1) (2024-09-13)


### Bug Fixes

* remove @libp2p/interfaces dep ([#591](https://github.com/ipfs/helia/issues/591)) ([e567717](https://github.com/ipfs/helia/commit/e567717102464a925f87cb10fc05808a50be960e))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/mfs bumped from ^3.0.7 to ^3.0.8

## [3.2.0](https://github.com/ipfs/helia/compare/car-v3.1.5...car-v3.2.0) (2024-07-31)


### Features

* add `filter` option to de-duplicate blocks in car files ([461d219](https://github.com/ipfs/helia/commit/461d219927a6725508014392340820d01a76a64f))


### Documentation

* fix grammar - it's -&gt; its ([#565](https://github.com/ipfs/helia/issues/565)) ([155e24d](https://github.com/ipfs/helia/commit/155e24db8c06c33972895d702a656e0c2996f3d9))


### Dependencies

* bump aegir from 42.2.11 to 43.0.1 ([#552](https://github.com/ipfs/helia/issues/552)) ([74ccc92](https://github.com/ipfs/helia/commit/74ccc92793a6d0bb4bee714d9fe4fa4183aa4ee8))
* bump aegir from 43.0.3 to 44.0.1 ([#569](https://github.com/ipfs/helia/issues/569)) ([6952f05](https://github.com/ipfs/helia/commit/6952f05357844e5aa3dffb2afaf261df06b9b7c1))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.3.0 to ^4.3.1
  * devDependencies
    * @helia/mfs bumped from ^3.0.6 to ^3.0.7
    * @helia/unixfs bumped from ^3.0.6 to ^3.0.7

## [3.1.5](https://github.com/ipfs/helia/compare/car-v3.1.4...car-v3.1.5) (2024-05-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.2.0 to ^4.3.0
  * devDependencies
    * @helia/unixfs bumped from ^3.0.5 to ^3.0.6

## [3.1.4](https://github.com/ipfs/helia/compare/car-v3.1.3...car-v3.1.4) (2024-04-22)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/unixfs bumped from ^3.0.4 to ^3.0.5

## [3.1.3](https://github.com/ipfs/helia/compare/car-v3.1.2...car-v3.1.3) (2024-04-15)


### Bug Fixes

* add sideEffects: false to package.json ([#485](https://github.com/ipfs/helia/issues/485)) ([8c45267](https://github.com/ipfs/helia/commit/8c45267a474ab10b2faadfebdab33cfe446e8c03))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.1.0 to ^4.2.0
  * devDependencies
    * @helia/unixfs bumped from ^3.0.3 to ^3.0.4

## [3.1.2](https://github.com/ipfs/helia/compare/car-v3.1.1...car-v3.1.2) (2024-04-03)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @helia/unixfs bumped from ^3.0.2 to ^3.0.3

## [3.1.1](https://github.com/ipfs/helia/compare/car-v3.1.0...car-v3.1.1) (2024-03-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.0.1 to ^4.1.0
  * devDependencies
    * @helia/unixfs bumped from ^3.0.1 to ^3.0.2

## [3.1.0](https://github.com/ipfs/helia/compare/car-v3.0.0...car-v3.1.0) (2024-02-28)


### Features

* stream car file bytes from @helia/car ([#444](https://github.com/ipfs/helia/issues/444)) ([7c07e11](https://github.com/ipfs/helia/commit/7c07e113d644a1efc32b7fd0c268f5f892256ce9))


### Bug Fixes

* support reading identity cids ([#429](https://github.com/ipfs/helia/issues/429)) ([98308f7](https://github.com/ipfs/helia/commit/98308f77488b8196b2d18f78f05ecd2d37456834))
* update project deps and docs ([77e34fc](https://github.com/ipfs/helia/commit/77e34fc115cbfb82585fd954bcf389ecebf655bc))
* use blockstore interface where possible ([#417](https://github.com/ipfs/helia/issues/417)) ([30c8981](https://github.com/ipfs/helia/commit/30c8981934ffba72d572a7b8b2712ec93b7f4d31))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.0.0 to ^4.0.1
  * devDependencies
    * @helia/unixfs bumped from ^3.0.0 to ^3.0.1

## [3.0.0](https://github.com/ipfs/helia/compare/car-v2.0.1...car-v3.0.0) (2024-01-24)


### ⚠ BREAKING CHANGES

* the `libp2p` property has been removed from the `Helia` interface in `@helia/interface` - it is still present on the return type of `createHelia` from the `helia` module

### Features

* add @helia/http to monorepo ([#372](https://github.com/ipfs/helia/issues/372)) ([76220cd](https://github.com/ipfs/helia/commit/76220cd5adf45af7fa61fd0a1321de4722b744d6))
* expose configured dag walkers and hashers on helia interface ([#381](https://github.com/ipfs/helia/issues/381)) ([843fba4](https://github.com/ipfs/helia/commit/843fba467ebb032907c888da499147a5349ec10e)), closes [#375](https://github.com/ipfs/helia/issues/375)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^3.0.1 to ^4.0.0
  * devDependencies
    * @helia/unixfs bumped from ^2.0.1 to ^3.0.0

## [2.0.0](https://github.com/ipfs/helia/compare/car-v1.0.4...car-v2.0.0) (2024-01-08)


### ⚠ BREAKING CHANGES

* uses multiformats v13 and helia v3

### Features

* update helia to v3 and multiformats to v13 ([#52](https://github.com/ipfs/helia-car/issues/52)) ([6405c34](https://github.com/ipfs/helia/commit/6405c3487879614dc4dd7308b15c946d644e0488))

### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^3.0.0 to ^3.0.1
  * devDependencies
    * @helia/unixfs bumped from ^2.0.0 to ^2.0.1


## [1.0.4](https://github.com/ipfs/helia/compare/car-v1.0.3...car-v1.0.4) (2023-10-07)


### Dependencies

* **dev:** bump aegir from 40.0.13 to 41.0.0 ([#41](https://github.com/ipfs/helia-car/issues/41)) ([e8fc99f](https://github.com/ipfs/helia/commit/e8fc99f4e372eaf72c2598f5a7a9942143c6d788))

## [1.0.3](https://github.com/ipfs/helia/compare/car-v1.0.2...car-v1.0.3) (2023-08-27)


### Dependencies

* bump @helia/interface from 1.2.2 to 2.0.0 ([#32](https://github.com/ipfs/helia-car/issues/32)) ([68656a8](https://github.com/ipfs/helia/commit/68656a81b7cd1238641a41573915635905e4a6ed))
* bump cborg from 1.10.2 to 2.0.5 ([#35](https://github.com/ipfs/helia-car/issues/35)) ([10994ea](https://github.com/ipfs/helia/commit/10994ea9abdff8906ae8c3f7d0ff5f50b50d9e60))
* bump multiformats from 11.0.2 to 12.0.1 ([#4](https://github.com/ipfs/helia-car/issues/4)) ([50bed0f](https://github.com/ipfs/helia/commit/50bed0f32b3c07111de804b0e6471e36d8e66626))

## [1.0.2](https://github.com/ipfs/helia/compare/car-v1.0.1...car-v1.0.2) (2023-08-27)


### Dependencies

* **dev:** bump aegir from 39.0.13 to 40.0.11 ([#30](https://github.com/ipfs/helia-car/issues/30)) ([ea26a0b](https://github.com/ipfs/helia/commit/ea26a0bd14137eb1de6ab282cdcecd55578064ab))

## [1.0.1](https://github.com/ipfs/helia/compare/car-v1.0.0...car-v1.0.1) (2023-08-14)


### Documentation

* fs already defined in example ([#1](https://github.com/ipfs/helia-car/issues/1)) ([356797a](https://github.com/ipfs/helia/commit/356797a9493c7753178b5f343962951bc9cd3052))

## 1.0.0 (2023-06-07)


### Bug Fixes

* import from multiformats/cid for smaller bundles ([0857d1f](https://github.com/ipfs/helia/commit/0857d1f76cd7403dbea46cf3d9c891543fc83fe1))


### Trivial Changes

* fix linting ([3803a37](https://github.com/ipfs/helia/commit/3803a378c0d7a556248e39e7a3c756e94e69888d))
