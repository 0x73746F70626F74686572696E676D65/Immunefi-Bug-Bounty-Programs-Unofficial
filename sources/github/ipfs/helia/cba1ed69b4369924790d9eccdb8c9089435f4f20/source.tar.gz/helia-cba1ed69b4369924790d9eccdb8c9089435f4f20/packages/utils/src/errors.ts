export class AlreadyPinnedError extends Error {
  static name = 'AlreadyPinnedError'
  name = 'AlreadyPinnedError'
}

export class BlockPinnedError extends Error {
  static name = 'BlockPinnedError'
  name = 'BlockPinnedError'
}

export class InvalidDatastoreVersionError extends Error {
  static name = 'InvalidDatastoreVersionError'
  name = 'InvalidDatastoreVersionError'
}

export class InvalidConfigurationError extends Error {
  static name = 'InvalidConfigurationError'
  name = 'InvalidConfigurationError'
}

export class GetFailedError extends AggregateError {
  static name = 'GetFailedError'
  name = 'GetFailedError'
}

export class LoadBlockFailedError extends AggregateError {
  static name = 'LoadBlockFailedError'
  name = 'LoadBlockFailedError'
}

export class BlockNotFoundWhileOfflineError extends Error {
  static name = 'BlockNotFoundWhileOfflineError'
  name = 'BlockNotFoundWhileOfflineError'
}

export class DecryptionFailedError extends Error {
  static name = 'DecryptionFailedError'
  name = 'DecryptionFailedError'
}
