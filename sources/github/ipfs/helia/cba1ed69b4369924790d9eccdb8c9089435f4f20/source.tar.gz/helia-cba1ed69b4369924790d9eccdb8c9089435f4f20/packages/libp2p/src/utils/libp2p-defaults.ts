import { delegatedHTTPRoutingDefaults } from '@helia/delegated-routing-client'
import { delegatedRoutingV1HttpApiClientContentRouting, delegatedRoutingV1HttpApiClientPeerRouting } from '@helia/delegated-routing-v1-http-api-client'
import { autoTLS } from '@ipshipyard/libp2p-auto-tls'
import { autoNAT } from '@libp2p/autonat'
import { bootstrap } from '@libp2p/bootstrap'
import { circuitRelayTransport, circuitRelayServer } from '@libp2p/circuit-relay-v2'
import { dcutr } from '@libp2p/dcutr'
import { http } from '@libp2p/http'
import { identify, identifyPush } from '@libp2p/identify'
import { kadDHT } from '@libp2p/kad-dht'
import { keychain } from '@libp2p/keychain'
import { mdns } from '@libp2p/mdns'
import { mplex } from '@libp2p/mplex'
import { noise } from '@libp2p/noise'
import { ping } from '@libp2p/ping'
import { tcp } from '@libp2p/tcp'
import { tls } from '@libp2p/tls'
import { uPnPNAT } from '@libp2p/upnp-nat'
import { webRTC, webRTCDirect } from '@libp2p/webrtc'
import { webSockets } from '@libp2p/websockets'
import { yamux } from '@libp2p/yamux'
import { bootstrapConfig } from './bootstrappers.ts'
import { merge, replace } from './config.ts'
import type { CreateLibp2pOptions } from '../index.ts'
import type { AutoTLS } from '@ipshipyard/libp2p-auto-tls'
import type { CircuitRelayService } from '@libp2p/circuit-relay-v2'
import type { HTTP } from '@libp2p/http'
import type { Identify, IdentifyPush } from '@libp2p/identify'
import type { ServiceMap } from '@libp2p/interface'
import type { KadDHT } from '@libp2p/kad-dht'
import type { Keychain } from '@libp2p/keychain'
import type { Ping } from '@libp2p/ping'
import type { Libp2pOptions } from 'libp2p'

export interface DefaultLibp2pServices extends Record<string, unknown> {
  autoNAT: unknown
  autoTLS: AutoTLS
  dcutr: unknown
  delegatedContentRouting: unknown
  delegatedPeerRouting: unknown
  dht: KadDHT
  identify: Identify
  identifyPush: IdentifyPush
  keychain: Keychain
  ping: Ping
  relay: CircuitRelayService
  upnp: unknown
  http: HTTP
}

export type DefaultLibp2pOptions = Libp2pOptions<DefaultLibp2pServices> & Required<Pick<Libp2pOptions<DefaultLibp2pServices>, 'nodeInfo' | 'addresses' | 'transports' | 'connectionEncrypters' | 'streamMuxers' | 'peerDiscovery' | 'services'>>

/**
 * Returns the default libp2p config used by Helia which can then be modified or
 * extended to suit individual applications.
 *
 * @example Adding an additional libp2p service
 *
 * ```ts
 * import { myService } from '@example/my-service'
 * import { createHelia } from 'helia'
 * import { libp2pDefaults } from '@helia/libp2p'
 *
 * // get a copy of the default libp2p config
 * const libp2p = libp2pDefaults()
 *
 * // add the custom service to the service map
 * libp2p.services.myService = myService()
 *
 * // create a Helia node with the custom libp2p config
 * const helia = await createHelia({
 *   libp2p
 * })
 *
 * //... use service
 * helia.libp2p.services.myService.serviceMethod()
 * ```
 */
export function libp2pDefaults (): DefaultLibp2pOptions
export function libp2pDefaults <M extends ServiceMap, Options extends CreateLibp2pOptions<M>> (options: Options): DefaultLibp2pOptions & Options
export function libp2pDefaults (options?: any): any {
  const defaults = {
    addresses: {
      listen: [
        '/ip4/0.0.0.0/tcp/0',
        '/ip4/0.0.0.0/tcp/0/ws',
        '/ip4/0.0.0.0/udp/0/webrtc-direct',
        '/ip6/::/tcp/0',
        '/ip6/::/tcp/0/ws',
        '/ip6/::/udp/0/webrtc-direct',
        '/p2p-circuit'
      ]
    },
    transports: [
      circuitRelayTransport(),
      tcp(),
      webRTC(),
      webRTCDirect(),
      webSockets()
    ],
    connectionEncrypters: [
      noise(),
      tls()
    ],
    streamMuxers: [
      yamux(),
      mplex()
    ],
    peerDiscovery: [
      mdns(),
      bootstrap(bootstrapConfig)
    ],
    services: {
      autoNAT: autoNAT(),
      autoTLS: autoTLS(),
      dcutr: dcutr(),
      delegatedPeerRouting: delegatedRoutingV1HttpApiClientPeerRouting(delegatedHTTPRoutingDefaults()),
      delegatedContentRouting: delegatedRoutingV1HttpApiClientContentRouting(delegatedHTTPRoutingDefaults()),
      dht: kadDHT(),
      identify: identify(),
      identifyPush: identifyPush(),
      keychain: keychain(options?.keychain),
      ping: ping(),
      relay: circuitRelayServer(),
      upnp: uPnPNAT(),
      http: http()
    }
  }

  if (options == null) {
    return defaults
  }

  if (options?.config === 'merge') {
    return merge(defaults, options)
  }

  return replace(defaults, options)
}
