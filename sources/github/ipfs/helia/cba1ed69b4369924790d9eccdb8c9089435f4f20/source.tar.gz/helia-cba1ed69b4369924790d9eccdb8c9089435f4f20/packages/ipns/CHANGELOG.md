# Changelog

## [10.2.2](https://github.com/ipfs/helia/compare/ipns-v10.2.1...ipns-v10.2.2) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.1 to ^7.1.2

## [10.2.1](https://github.com/ipfs/helia/compare/ipns-v10.2.0...ipns-v10.2.1) (2026-09-23)


### Dependencies

* update protons ([#1131](https://github.com/ipfs/helia/issues/1131)) ([d496208](https://github.com/ipfs/helia/commit/d49620874dc67a5cb8a4b70fb568b73de66584fc))

## [10.2.0](https://github.com/ipfs/helia/compare/ipns-v10.1.1...ipns-v10.2.0) (2026-09-14)


### Features

* republish third-party ipns record ([#891](https://github.com/ipfs/helia/issues/891)) ([2ab3bfc](https://github.com/ipfs/helia/commit/2ab3bfc6905c9128f89059b67a8a1986f211c73a))


### Bug Fixes

* update protons and regenerate messages ([#1127](https://github.com/ipfs/helia/issues/1127)) ([b34bc7c](https://github.com/ipfs/helia/commit/b34bc7c76d8ab1f1eeba9893af792299b05de111))

## [10.1.1](https://github.com/ipfs/helia/compare/ipns-v10.1.0...ipns-v10.1.1) (2026-09-10)


### Bug Fixes

* update unixfs deps to allow for streaming dags ([#1125](https://github.com/ipfs/helia/issues/1125)) ([16fc74d](https://github.com/ipfs/helia/commit/16fc74d30cded1773e9ac18b0a62ca4582f7eab9))

## [10.1.0](https://github.com/ipfs/helia/compare/ipns-v10.0.8...ipns-v10.1.0) (2026-08-19)


### Features

* add withLibp2pLight function ([#1110](https://github.com/ipfs/helia/issues/1110)) ([c9f35da](https://github.com/ipfs/helia/commit/c9f35dabc828991fc10056aa8d149645aaea8f3e))

## [10.0.8](https://github.com/ipfs/helia/compare/ipns-v10.0.7...ipns-v10.0.8) (2026-08-13)


### Bug Fixes

* export ipns selector ([#1105](https://github.com/ipfs/helia/issues/1105)) ([0b5ca22](https://github.com/ipfs/helia/commit/0b5ca22f588e581f2e9abf1f12e45a7946e60287))
* export ipns validator function ([#1099](https://github.com/ipfs/helia/issues/1099)) ([a3e7d23](https://github.com/ipfs/helia/commit/a3e7d235e32135b5d9d7f85cb0338dd128e30f33))

## [10.0.7](https://github.com/ipfs/helia/compare/ipns-v10.0.6...ipns-v10.0.7) (2026-07-31)


### Dependencies

* bump cborg from 5.1.11 to 6.1.1 ([#1095](https://github.com/ipfs/helia/issues/1095)) ([81d9624](https://github.com/ipfs/helia/commit/81d96244c432fa5ad8e121d2462f40c0dcd61531))

## [10.0.6](https://github.com/ipfs/helia/compare/ipns-v10.0.5...ipns-v10.0.6) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.0 to ^7.1.1

## [10.0.5](https://github.com/ipfs/helia/compare/ipns-v10.0.4...ipns-v10.0.5) (2026-07-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.3 to ^7.1.0

## [10.0.4](https://github.com/ipfs/helia/compare/ipns-v10.0.3...ipns-v10.0.4) (2026-07-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.2 to ^7.0.3

## [10.0.3](https://github.com/ipfs/helia/compare/ipns-v10.0.2...ipns-v10.0.3) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.1 to ^7.0.2

## [10.0.2](https://github.com/ipfs/helia/compare/ipns-v10.0.1...ipns-v10.0.2) (2026-07-02)


### Bug Fixes

* add value to ipns result and export util to create records ([#1065](https://github.com/ipfs/helia/issues/1065)) ([883ff05](https://github.com/ipfs/helia/commit/883ff053cefc4b9f7cf7fd6759bc79f68def9297))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.0 to ^7.0.1

## [10.0.1](https://github.com/ipfs/helia/compare/ipns-v10.0.0...ipns-v10.0.1) (2026-06-30)


### Bug Fixes

* relax CID input type for resolving IPNS names ([#1060](https://github.com/ipfs/helia/issues/1060)) ([3d869e9](https://github.com/ipfs/helia/commit/3d869e9d902706f0115393a25add89f07aff2c49))

## [10.0.0](https://github.com/ipfs/helia/compare/ipns-v9.2.1...ipns-v10.0.0) (2026-06-29)


### ⚠ BREAKING CHANGES

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))
* `secp256k1` support has been removed from the default config, it must now be configured separately
* returned instances of `CID` and `MultihashDigest` come from the `multiformats@14.x.x` module

### Features

* keychain and configurable crypto ([#1041](https://github.com/ipfs/helia/issues/1041)) ([73a28ed](https://github.com/ipfs/helia/commit/73a28edaab2b1dcf056bfc9333cbebc811aa28db))
* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Bug Fixes

* update to multiformats@14.x.x ([#1039](https://github.com/ipfs/helia/issues/1039)) ([f6cc764](https://github.com/ipfs/helia/commit/f6cc7640840b77757c09d9463539b41e6ea33099))


### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#1015](https://github.com/ipfs/helia/issues/1015)) ([ae98a4f](https://github.com/ipfs/helia/commit/ae98a4f4940310383c2a384cde64f99264326583))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.1 to ^7.0.0

## [9.2.1](https://github.com/ipfs/helia/compare/ipns-v9.2.0...ipns-v9.2.1) (2026-04-10)


### Bug Fixes

* add module-sync ([#1001](https://github.com/ipfs/helia/issues/1001)) ([ef5363e](https://github.com/ipfs/helia/commit/ef5363e834439ba1838a408639cb2d05d3ba6867))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.0 to ^6.2.1

## [9.2.0](https://github.com/ipfs/helia/compare/ipns-v9.1.9...ipns-v9.2.0) (2026-04-08)


### Features

* emit standardized block broker events ([#995](https://github.com/ipfs/helia/issues/995)) ([397f2d8](https://github.com/ipfs/helia/commit/397f2d86cefd425178a67e70e8f338093d666fe9))
* ipns libp2p fetch ([#906](https://github.com/ipfs/helia/issues/906)) ([8efd119](https://github.com/ipfs/helia/commit/8efd1195ab27fea83543153ef04e57a60c3f0e83))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.1.1 to ^6.2.0

## [9.1.9](https://github.com/ipfs/helia/compare/ipns-v9.1.8...ipns-v9.1.9) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.1.0 to ^6.1.1

## [9.1.8](https://github.com/ipfs/helia/compare/ipns-v9.1.7...ipns-v9.1.8) (2026-02-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.3 to ^6.1.0

## [9.1.7](https://github.com/ipfs/helia/compare/ipns-v9.1.6...ipns-v9.1.7) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.2 to ^6.0.3

## [9.1.6](https://github.com/ipfs/helia/compare/ipns-v9.1.5...ipns-v9.1.6) (2026-01-15)


### Bug Fixes

* use non-deprecated factory function to create delegated client ([#934](https://github.com/ipfs/helia/issues/934)) ([20ba9cf](https://github.com/ipfs/helia/commit/20ba9cf6256961d2b664af0e8f48b5e9d009d834))

## [9.1.5](https://github.com/ipfs/helia/compare/ipns-v9.1.4...ipns-v9.1.5) (2025-12-12)


### Bug Fixes

* throw specific error when IPNS lookup fails ([#919](https://github.com/ipfs/helia/issues/919)) ([574ac5e](https://github.com/ipfs/helia/commit/574ac5e4405ba904d223c740e07e9ac21394cb9b))

## [9.1.4](https://github.com/ipfs/helia/compare/ipns-v9.1.3...ipns-v9.1.4) (2025-12-12)


### Bug Fixes

* improve error reporting ([#896](https://github.com/ipfs/helia/issues/896)) ([71f9c4e](https://github.com/ipfs/helia/commit/71f9c4ef2c8557d92e5769675a69da2679c8b7d2))

## [9.1.3](https://github.com/ipfs/helia/compare/ipns-v9.1.2...ipns-v9.1.3) (2025-10-29)


### Bug Fixes

* use libp2p provider routing field ([#889](https://github.com/ipfs/helia/issues/889)) ([d4d97b8](https://github.com/ipfs/helia/commit/d4d97b83f76be7e3b480052467408839f808e230))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.1 to ^6.0.2

## [9.1.2](https://github.com/ipfs/helia/compare/ipns-v9.1.1...ipns-v9.1.2) (2025-10-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.0 to ^6.0.1

## [9.1.1](https://github.com/ipfs/helia/compare/ipns-v9.1.0...ipns-v9.1.1) (2025-10-22)


### Bug Fixes

* update log formatting to print errors correctly ([#884](https://github.com/ipfs/helia/issues/884)) ([f35ecd1](https://github.com/ipfs/helia/commit/f35ecd1c8ad3c712d3882d0f0f2abaf0f0296ec1))

## [9.1.0](https://github.com/ipfs/helia/compare/ipns-v9.0.0...ipns-v9.1.0) (2025-10-14)


### Features

* add ipns resolver ([#868](https://github.com/ipfs/helia/issues/868)) ([4d51f16](https://github.com/ipfs/helia/commit/4d51f16de47c80df2fbfa4932825153ce5330100))

## [9.0.0](https://github.com/ipfs/helia/compare/ipns-v8.2.4...ipns-v9.0.0) (2025-10-09)


### ⚠ BREAKING CHANGES

* `ipns.publish` now accepts key name strings rather than private keys Names previously publishing using an user controlled private key, will need to be explicitly published again by first importing the key into the keychain (`await libp2p.keychain.importKey('my-key', key)` and then published with `ipns.publish('my-key', ...)`.
* uses libp2p v3 and updated block/data stores

### Features

* add ipns reproviding/republishing ([#764](https://github.com/ipfs/helia/issues/764)) ([008747b](https://github.com/ipfs/helia/commit/008747b59a03682e1b6f648a39635e1b1971e481))
* resolve IPNS records with PeerId and CID keys ([#861](https://github.com/ipfs/helia/issues/861)) ([b81ec52](https://github.com/ipfs/helia/commit/b81ec52026bee611f859c896da7d4234bac486a2)), closes [#801](https://github.com/ipfs/helia/issues/801)
* update to libp2p@v3 and latest data/block stores ([#856](https://github.com/ipfs/helia/issues/856)) ([34d3ecd](https://github.com/ipfs/helia/commit/34d3ecd76c8424387c57221000e226f08ccd1d1e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.4.0 to ^6.0.0

## [8.2.4](https://github.com/ipfs/helia/compare/ipns-v8.2.3...ipns-v8.2.4) (2025-07-22)


### Bug Fixes

* flaky test to publish an IPNS record  ([#810](https://github.com/ipfs/helia/issues/810)) ([28a7091](https://github.com/ipfs/helia/commit/28a7091260fda1f711b93318084a65ff3d2f3f8a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.2 to ^5.4.0

## [8.2.3](https://github.com/ipfs/helia/compare/ipns-v8.2.2...ipns-v8.2.3) (2025-05-20)


### Dependencies

* update aegir to 47.x.x ([#804](https://github.com/ipfs/helia/issues/804)) ([60fbbc2](https://github.com/ipfs/helia/commit/60fbbc2eb08e023e2eac02ae0e89ed143d715084))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.1 to ^5.3.2

## [8.2.2](https://github.com/ipfs/helia/compare/ipns-v8.2.1...ipns-v8.2.2) (2025-05-13)


### Dependencies

* update all deps ([#792](https://github.com/ipfs/helia/issues/792)) ([d43efc7](https://github.com/ipfs/helia/commit/d43efc7bdfff34071a8e4e22e01f659fbac0b78e))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.0 to ^5.3.1

## [8.2.1](https://github.com/ipfs/helia/compare/ipns-v8.2.0...ipns-v8.2.1) (2025-05-13)


### Bug Fixes

* propagate ipns failures ([#789](https://github.com/ipfs/helia/issues/789)) ([cd1eb58](https://github.com/ipfs/helia/commit/cd1eb588998ddb1eb17894230cde4a68f9455398))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.2.1 to ^5.3.0

## [8.2.0](https://github.com/ipfs/helia/compare/ipns-v8.1.0...ipns-v8.2.0) (2025-03-13)


### Features

* add republish signed ipns records ([#745](https://github.com/ipfs/helia/issues/745)) ([91880b0](https://github.com/ipfs/helia/commit/91880b076fbfa24e5354fb6cda8a556a807f17cc))


### Bug Fixes

* align implicit default ttl with specs ([#749](https://github.com/ipfs/helia/issues/749)) ([375796a](https://github.com/ipfs/helia/commit/375796aaead36111c4d663b061bf0edfe01c62ca))
* handle /ipns/ prefixed keys in republishRecord ([#763](https://github.com/ipfs/helia/issues/763)) ([e6339ed](https://github.com/ipfs/helia/commit/e6339ed3cf86f7d56d1aa098de5e091b322e654e))


### Documentation

* add spell checker to ci ([#743](https://github.com/ipfs/helia/issues/743)) ([45ca6bc](https://github.com/ipfs/helia/commit/45ca6bc70b1644028500101044595fa0e2199b07))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.2.0 to ^5.2.1

## [8.1.0](https://github.com/ipfs/helia/compare/ipns-v8.0.2...ipns-v8.1.0) (2025-01-24)


### Features

* allow passing custom ttl when publishing ipns ([#723](https://github.com/ipfs/helia/issues/723)) ([12df657](https://github.com/ipfs/helia/commit/12df657aa421c86df53bc54becf1d505b1c145ce))


### Bug Fixes

* handle dnslink pointing to CID with peer id (ipns name) ([#722](https://github.com/ipfs/helia/issues/722)) ([2666d64](https://github.com/ipfs/helia/commit/2666d643d8bd90db077095f20edb1924c8594185))

## [8.0.2](https://github.com/ipfs/helia/compare/ipns-v8.0.1...ipns-v8.0.2) (2025-01-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.1.0 to ^5.2.0

## [8.0.1](https://github.com/ipfs/helia/compare/ipns-v8.0.0...ipns-v8.0.1) (2024-11-18)


### Dependencies

* bump aegir from 44.1.4 to 45.0.1 ([#669](https://github.com/ipfs/helia/issues/669)) ([e58e49c](https://github.com/ipfs/helia/commit/e58e49c6aed8ea9d1e9851435a25e33fdbee3781))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.0.0 to ^5.1.0

## [8.0.0](https://github.com/ipfs/helia/compare/ipns-v7.2.3...ipns-v8.0.0) (2024-10-07)


### ⚠ BREAKING CHANGES

* helia now uses libp2p@2.x.x

### Bug Fixes

* add doc-check script and export types used by functions ([#637](https://github.com/ipfs/helia/issues/637)) ([4f14996](https://github.com/ipfs/helia/commit/4f14996a9b976f2b60f4c8fe52a4fd1632420749))
* update to libp2p@2.x.x ([#630](https://github.com/ipfs/helia/issues/630)) ([ec8bf66](https://github.com/ipfs/helia/commit/ec8bf66dd870b42d6e5ef2b41706102397e0d39a))


### Dependencies

* **dev:** bump sinon from 18.0.1 to 19.0.2 ([#634](https://github.com/ipfs/helia/issues/634)) ([23e62e1](https://github.com/ipfs/helia/commit/23e62e16b8962bfe982a1bbb157a144382ca7099))
* update kad-dht to 14.0.0 ([#648](https://github.com/ipfs/helia/issues/648)) ([60d8c8a](https://github.com/ipfs/helia/commit/60d8c8a9ff2104302d1c87bcf39258f1da33cd45))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.3.1 to ^5.0.0

## [7.2.3](https://github.com/ipfs/helia/compare/ipns-v7.2.2...ipns-v7.2.3) (2024-07-31)


### Documentation

* fix grammar - it's -&gt; its ([#565](https://github.com/ipfs/helia/issues/565)) ([155e24d](https://github.com/ipfs/helia/commit/155e24db8c06c33972895d702a656e0c2996f3d9))


### Dependencies

* bump aegir from 42.2.11 to 43.0.1 ([#552](https://github.com/ipfs/helia/issues/552)) ([74ccc92](https://github.com/ipfs/helia/commit/74ccc92793a6d0bb4bee714d9fe4fa4183aa4ee8))
* bump aegir from 43.0.3 to 44.0.1 ([#569](https://github.com/ipfs/helia/issues/569)) ([6952f05](https://github.com/ipfs/helia/commit/6952f05357844e5aa3dffb2afaf261df06b9b7c1))
* **dev:** bump sinon from 17.0.2 to 18.0.0 ([#536](https://github.com/ipfs/helia/issues/536)) ([62f77df](https://github.com/ipfs/helia/commit/62f77dfbff94a64e9c248f5be54055c18a6427f7))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.3.0 to ^4.3.1

## [7.2.2](https://github.com/ipfs/helia/compare/ipns-v7.2.1...ipns-v7.2.2) (2024-05-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.2.0 to ^4.3.0

## [7.2.1](https://github.com/ipfs/helia/compare/ipns-v7.2.0...ipns-v7.2.1) (2024-04-15)


### Bug Fixes

* add sideEffects: false to package.json ([#485](https://github.com/ipfs/helia/issues/485)) ([8c45267](https://github.com/ipfs/helia/commit/8c45267a474ab10b2faadfebdab33cfe446e8c03))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.1.0 to ^4.2.0

## [7.0.0](https://github.com/ipfs/helia/compare/ipns-v6.0.1...ipns-v7.0.0) (2024-03-14)


### ⚠ BREAKING CHANGES

* requires @helia/interface@4.1.x or later, `resolveDns` has been renamed `resolveDNSLink`

### Features

* use custom DNS resolver in @helia/ipns for DNSLink ([#466](https://github.com/ipfs/helia/issues/466)) ([2c71b6e](https://github.com/ipfs/helia/commit/2c71b6ec8d34dcc722a3914702f67603492c335f)), closes [#369](https://github.com/ipfs/helia/issues/369)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.0.1 to ^4.1.0

## [7.2.0](https://github.com/ipfs/helia/compare/ipns-v7.1.0...ipns-v7.2.0) (2024-04-03)


### Features

* add cache control to IPNS ([#473](https://github.com/ipfs/helia/issues/473)) ([b00f682](https://github.com/ipfs/helia/commit/b00f682647d3687e54bd48f8f68ab79d1e4e96cc))


### Bug Fixes

* respect the IPNS TTL field ([#482](https://github.com/ipfs/helia/issues/482)) ([1561e4a](https://github.com/ipfs/helia/commit/1561e4a106074b94e421a77b0b8776b065e48bc5))

## [7.1.0](https://github.com/ipfs/helia/compare/ipns-v7.0.0...ipns-v7.1.0) (2024-03-15)


### Features

* add `record`/`answer` fields to IPNS results ([#471](https://github.com/ipfs/helia/issues/471)) ([b6765fe](https://github.com/ipfs/helia/commit/b6765fe7632231407c4a8506015ac07e30152190))

## [6.0.1](https://github.com/ipfs/helia/compare/ipns-v6.0.0...ipns-v6.0.1) (2024-02-28)


### Bug Fixes

* remove is-ipfs from @helia/ipns dependencies ([#421](https://github.com/ipfs/helia/issues/421)) ([3851fe2](https://github.com/ipfs/helia/commit/3851fe2df6af337b7e2cabe694bd3dba17748fce))
* update project deps and docs ([77e34fc](https://github.com/ipfs/helia/commit/77e34fc115cbfb82585fd954bcf389ecebf655bc))


### Dependencies

* update libp2p patch versions ([917a1bc](https://github.com/ipfs/helia/commit/917a1bceb9e9b56428a15dc3377a963f06affd12))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.0.0 to ^4.0.1

## [6.0.0](https://github.com/ipfs/helia/compare/ipns-v5.0.0...ipns-v6.0.0) (2024-01-31)


### ⚠ BREAKING CHANGES

* to support paths in `@helia/ipns`, the return type of `ipns.resolve` is now `{ path: string, cid: CID }` instead of just `CID`

### Features

* support paths in @helia/ipns ([#410](https://github.com/ipfs/helia/issues/410)) ([ca8d5eb](https://github.com/ipfs/helia/commit/ca8d5ebdf587574c7fb84517b558226c3479caa9))


### Bug Fixes

* export IPNSRoutingEvents ([#407](https://github.com/ipfs/helia/issues/407)) ([44f4e88](https://github.com/ipfs/helia/commit/44f4e88030a21d86b2a8473d3d00efb624cfce8f))

## [5.0.0](https://github.com/ipfs/helia/compare/ipns-v4.0.0...ipns-v5.0.0) (2024-01-24)


### ⚠ BREAKING CHANGES

* remove gossipsub from default libp2p services ([#401](https://github.com/ipfs/helia/issues/401))
* `helia.routing` is the default routing used, the `libp2p` routing has been removed as it is redundant
* the `libp2p` property has been removed from the `Helia` interface in `@helia/interface` - it is still present on the return type of `createHelia` from the `helia` module

### Features

* add @helia/http to monorepo ([#372](https://github.com/ipfs/helia/issues/372)) ([76220cd](https://github.com/ipfs/helia/commit/76220cd5adf45af7fa61fd0a1321de4722b744d6))
* use helia router for IPNS put/get ([#387](https://github.com/ipfs/helia/issues/387)) ([ce74026](https://github.com/ipfs/helia/commit/ce740268e83f50e6f144b74969a98d54005cd852))


### Bug Fixes

* remove gossipsub from default libp2p services ([#401](https://github.com/ipfs/helia/issues/401)) ([99c94f4](https://github.com/ipfs/helia/commit/99c94f4b85c4ed826a6195207e3545cbbc87a6d1))
* update ipns module to v9 and fix double verification of records ([#396](https://github.com/ipfs/helia/issues/396)) ([f2853f8](https://github.com/ipfs/helia/commit/f2853f8bd5bdcee8ab7a685355b0be47f29620e0))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^3.0.1 to ^4.0.0

## [4.0.0](https://github.com/ipfs/helia/compare/ipns-v3.0.1...ipns-v4.0.0) (2024-01-08)


### ⚠ BREAKING CHANGES

* uses multiformats v13 and helia v3, renames `dht` routing to `libp2p`

### Features

* update helia to v3 and multiformats to v13 ([#167](https://github.com/ipfs/helia-ipns/issues/167)) ([a0381b9](https://github.com/ipfs/helia/commit/a0381b95051bbf3edfa4f53e0ae2d5f43c1e4382))


### Bug Fixes

* make @libp2p/interface a dependency ([#159](https://github.com/ipfs/helia-ipns/issues/159)) ([546ecf0](https://github.com/ipfs/helia/commit/546ecf023bd619d32e187fa6a55d39fcf12e4bbe)), closes [#158](https://github.com/ipfs/helia-ipns/issues/158)


## [3.0.1](https://github.com/ipfs/helia/compare/ipns-v3.0.0...ipns-v3.0.1) (2023-12-08)


### Trivial Changes

* fix docs and aegir dep in subpackages ([#142](https://github.com/ipfs/helia-ipns/issues/142)) ([f66dd71](https://github.com/ipfs/helia/commit/f66dd71f18dab57471749e6a708917ea291d05e1))
* update sibling dependencies ([6ab5ddc](https://github.com/ipfs/helia/commit/6ab5ddcecb377bf61b6a4566292249fd5dc3d2c7))
* update sibling dependencies ([d0d84f0](https://github.com/ipfs/helia/commit/d0d84f07db9338ccc8245167929bd71f4cb8b238))


### Documentation

* fix typo ([#113](https://github.com/ipfs/helia-ipns/issues/113)) ([d732db9](https://github.com/ipfs/helia/commit/d732db9f4fea23aa11456d451f02d4f143846ba3))

## [3.0.0](https://github.com/ipfs/helia/compare/ipns-v2.0.3...ipns-v3.0.0) (2023-12-05)


### ⚠ BREAKING CHANGES

* alters the options object passed to the `ipns` factory function

### Features

* support DNS over HTTPS and DNS-JSON over HTTPS ([#55](https://github.com/ipfs/helia-ipns/issues/55)) ([2ac0e8b](https://github.com/ipfs/helia/commit/2ac0e8b26556b73961e67191c564ac2b18d32b31))

## [2.0.3](https://github.com/ipfs/helia/compare/ipns-v2.0.2...ipns-v2.0.3) (2023-10-26)


### Bug Fixes

* update libp2p interfaces ([#109](https://github.com/ipfs/helia-ipns/issues/109)) ([514b6e1](https://github.com/ipfs/helia/commit/514b6e1e4192f700a6f0e769d52a4ec5dfe757ec))

## [2.0.2](https://github.com/ipfs/helia/compare/ipns-v2.0.1...ipns-v2.0.2) (2023-10-24)


### Dependencies

* **dev:** bump sinon from 16.1.3 to 17.0.0 ([#108](https://github.com/ipfs/helia-ipns/issues/108)) ([530aeff](https://github.com/ipfs/helia/commit/530aeff8af103c9126411cc1b035ee106f113f1f))

## [2.0.1](https://github.com/ipfs/helia/compare/ipns-v2.0.0...ipns-v2.0.1) (2023-10-07)


### Dependencies

* **dev:** bump aegir from 40.0.13 to 41.0.0 ([#107](https://github.com/ipfs/helia-ipns/issues/107)) ([5402d30](https://github.com/ipfs/helia/commit/5402d30de1437052e9e9b955d9be3c2898515447))

## [2.0.0](https://github.com/ipfs/helia/compare/ipns-v1.1.7...ipns-v2.0.0) (2023-09-22)


### ⚠ BREAKING CHANGES

* the `IPNSRecord` type returned from the `publish` method has changed

### Dependencies

* update ipns to v7.x.x ([#106](https://github.com/ipfs/helia-ipns/issues/106)) ([83a1d14](https://github.com/ipfs/helia/commit/83a1d147e8ba758efd7d2574ea486218bd1f3df2))

## [1.1.7](https://github.com/ipfs/helia/compare/ipns-v1.1.6...ipns-v1.1.7) (2023-09-15)


### Dependencies

* **dev:** bump sinon from 15.2.0 to 16.0.0 ([#105](https://github.com/ipfs/helia-ipns/issues/105)) ([231ebbd](https://github.com/ipfs/helia/commit/231ebbd4cda2196d7914a81aa1b0d79473c3a325))

## [1.1.6](https://github.com/ipfs/helia/compare/ipns-v1.1.5...ipns-v1.1.6) (2023-09-15)


### Dependencies

* **dev:** bump libp2p from 0.45.9 to 0.46.6 ([#92](https://github.com/ipfs/helia-ipns/issues/92)) ([efe02e5](https://github.com/ipfs/helia/commit/efe02e5b38992189edb40cd34d79e76dca4c34a3))

## [1.1.5](https://github.com/ipfs/helia/compare/ipns-v1.1.4...ipns-v1.1.5) (2023-09-11)


### Dependencies

* bump @libp2p/logger from 2.1.1 to 3.0.2 ([#87](https://github.com/ipfs/helia-ipns/issues/87)) ([b2886b9](https://github.com/ipfs/helia/commit/b2886b9598a66a31c69ee0c3c7e13748614be37e))

## [1.1.4](https://github.com/ipfs/helia/compare/ipns-v1.1.3...ipns-v1.1.4) (2023-09-11)


### Trivial Changes

* update project config ([#99](https://github.com/ipfs/helia-ipns/issues/99)) ([a704fdc](https://github.com/ipfs/helia/commit/a704fdcbe8507ea97065f40525f0bbc251b57a4d))


### Dependencies

* bump multiformats from 11.0.2 to 12.0.1 ([#57](https://github.com/ipfs/helia-ipns/issues/57)) ([6f93e51](https://github.com/ipfs/helia/commit/6f93e51e9b6f603f7c1d396705dc5b190108fe79))
* **dev:** bump aegir from 39.0.13 to 40.0.8 ([#65](https://github.com/ipfs/helia-ipns/issues/65)) ([174987b](https://github.com/ipfs/helia/commit/174987b2817cfe99cbabb9835dd6a2d99c1c35a9))

## [1.1.3](https://github.com/ipfs/helia/compare/ipns-v1.1.2...ipns-v1.1.3) (2023-05-24)


### Dependencies

* update all deps and fix linting ([4cdba4f](https://github.com/ipfs/helia/commit/4cdba4fda743e7805725f4155242b93bc74ba4ae))

## [1.1.2](https://github.com/ipfs/helia/compare/ipns-v1.1.1...ipns-v1.1.2) (2023-05-09)


### Bug Fixes

* cache IPNS entries after resolving ([#35](https://github.com/ipfs/helia-ipns/issues/35)) ([704b413](https://github.com/ipfs/helia/commit/704b41355768b3e8723560c5f7ed3d7c12b58c3b)), closes [#20](https://github.com/ipfs/helia-ipns/issues/20)

## [1.1.1](https://github.com/ipfs/helia/compare/ipns-v1.1.0...ipns-v1.1.1) (2023-05-05)


### Bug Fixes

* use the content routing api for get/put operations ([#34](https://github.com/ipfs/helia-ipns/issues/34)) ([55208cc](https://github.com/ipfs/helia/commit/55208ccfdc4f3a799736f29e614910cbd8375a9d))

## [1.1.0](https://github.com/ipfs/helia/compare/ipns-v1.0.1...ipns-v1.1.0) (2023-03-29)


### Features

* allow publish/resolve using only local datastore ([#15](https://github.com/ipfs/helia-ipns/issues/15)) ([43e32a2](https://github.com/ipfs/helia/commit/43e32a20f44fffd533531a57e6d60883cebc55ca))

## [1.0.1](https://github.com/ipfs/helia/compare/ipns-v1.0.0...ipns-v1.0.1) (2023-03-21)


### Documentation

* fix typos ([#4](https://github.com/ipfs/helia-ipns/issues/4)) ([4369653](https://github.com/ipfs/helia/commit/4369653892d1434b9519f8f7f93371ae4531bc21))


### Dependencies

* update blockstore/datastore deps ([#10](https://github.com/ipfs/helia-ipns/issues/10)) ([3189737](https://github.com/ipfs/helia/commit/3189737040a9dfe631e1d07f7f884ff19b873f17))
* update ipns to 6.x.x ([#12](https://github.com/ipfs/helia-ipns/issues/12)) ([6866638](https://github.com/ipfs/helia/commit/6866638830f32442f9cfeadbde795e74b0865e00))

## 1.0.0 (2023-02-15)


### Features

* initial implementation ([#1](https://github.com/ipfs/helia-ipns/issues/1)) ([b176179](https://github.com/ipfs/helia/commit/b1761795f023e9150201e41f0b9e2c3021425f26))
