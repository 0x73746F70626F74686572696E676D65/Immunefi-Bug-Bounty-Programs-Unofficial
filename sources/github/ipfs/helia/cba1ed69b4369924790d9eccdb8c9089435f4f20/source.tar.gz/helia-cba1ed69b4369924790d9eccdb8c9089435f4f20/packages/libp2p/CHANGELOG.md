# Changelog

## [2.1.5](https://github.com/ipfs/helia/compare/libp2p-v2.1.4...libp2p-v2.1.5) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.6 to ^1.0.7
    * @helia/interface bumped from ^7.1.1 to ^7.1.2

## [2.1.4](https://github.com/ipfs/helia/compare/libp2p-v2.1.3...libp2p-v2.1.4) (2026-09-22)


### Bug Fixes

* switch to @libp2p/noise and @libp2p/yamux ([#1140](https://github.com/ipfs/helia/issues/1140)) ([7a206db](https://github.com/ipfs/helia/commit/7a206db71ba3d1b127639b6c604d738ec591777d))

## [2.1.3](https://github.com/ipfs/helia/compare/libp2p-v2.1.2...libp2p-v2.1.3) (2026-08-22)


### Bug Fixes

* replace all config fields ([#1120](https://github.com/ipfs/helia/issues/1120)) ([6c96dd3](https://github.com/ipfs/helia/commit/6c96dd38b999f55475133fed65e97f4cbe5d7d41))

## [2.1.2](https://github.com/ipfs/helia/compare/libp2p-v2.1.1...libp2p-v2.1.2) (2026-08-21)


### Bug Fixes

* restore config replacing ([#1118](https://github.com/ipfs/helia/issues/1118)) ([91ed35a](https://github.com/ipfs/helia/commit/91ed35a488a7fc7cb1e9e0e4c00b548ec638c290))

## [2.1.1](https://github.com/ipfs/helia/compare/libp2p-v2.1.0...libp2p-v2.1.1) (2026-08-21)


### Bug Fixes

* detect libp2p option type ([#1117](https://github.com/ipfs/helia/issues/1117)) ([dc9e15b](https://github.com/ipfs/helia/commit/dc9e15bc228bbfbc563fc2fd25dbb84224642455))
* specify fields present in libp2p defaults ([#1115](https://github.com/ipfs/helia/issues/1115)) ([ae012cf](https://github.com/ipfs/helia/commit/ae012cf99e82f3a26502343046ab65f00d9e3f15))

## [2.1.0](https://github.com/ipfs/helia/compare/libp2p-v2.0.0...libp2p-v2.1.0) (2026-08-19)


### Features

* add withLibp2pLight function ([#1110](https://github.com/ipfs/helia/issues/1110)) ([c9f35da](https://github.com/ipfs/helia/commit/c9f35dabc828991fc10056aa8d149645aaea8f3e))

## [2.0.0](https://github.com/ipfs/helia/compare/libp2p-v1.0.8...libp2p-v2.0.0) (2026-08-15)


### ⚠ BREAKING CHANGES

* pass libp2p config to withLibp2p, not a running node

### Bug Fixes

* include identify push in default services ([ca4dee6](https://github.com/ipfs/helia/commit/ca4dee6f4a2146d0bfe1cf95514938148fd709dc))
* only accept libp2p config, not running nodes ([#1106](https://github.com/ipfs/helia/issues/1106)) ([56f87f0](https://github.com/ipfs/helia/commit/56f87f0356cd3cbf2842189ffd811f2cc7d978fc))

## [1.0.8](https://github.com/ipfs/helia/compare/libp2p-v1.0.7...libp2p-v1.0.8) (2026-07-31)


### Bug Fixes

* add helia user agent to libp2p ([#1097](https://github.com/ipfs/helia/issues/1097)) ([a87d6d8](https://github.com/ipfs/helia/commit/a87d6d8de1bd6841770901cecdec4f84353b6dd3))

## [1.0.7](https://github.com/ipfs/helia/compare/libp2p-v1.0.6...libp2p-v1.0.7) (2026-07-28)


### Bug Fixes

* do not evict fallback providers from session ([#1092](https://github.com/ipfs/helia/issues/1092)) ([f713369](https://github.com/ipfs/helia/commit/f713369d232dc9a09b1fbac5672e9053649a6579))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.5 to ^1.0.6
    * @helia/interface bumped from ^7.1.0 to ^7.1.1

## [1.0.6](https://github.com/ipfs/helia/compare/libp2p-v1.0.5...libp2p-v1.0.6) (2026-07-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.4 to ^1.0.5
    * @helia/interface bumped from ^7.0.3 to ^7.1.0

## [1.0.5](https://github.com/ipfs/helia/compare/libp2p-v1.0.4...libp2p-v1.0.5) (2026-07-04)


### Bug Fixes

* include which router found the peer in get peer ([#1077](https://github.com/ipfs/helia/issues/1077)) ([0cc31cd](https://github.com/ipfs/helia/commit/0cc31cd61e6585adfc10b7946f6d71d16a509709))
* override routing operations ([#1080](https://github.com/ipfs/helia/issues/1080)) ([f028ccf](https://github.com/ipfs/helia/commit/f028ccf8ab5343eba29e005d6dc0c8950fd8c674))
* the routing is made up of routers ([da4aa40](https://github.com/ipfs/helia/commit/da4aa40a30b8958e7fd9dcb1a82f7133443cb9fb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.3 to ^1.0.4
    * @helia/interface bumped from ^7.0.2 to ^7.0.3

## [1.0.4](https://github.com/ipfs/helia/compare/libp2p-v1.0.3...libp2p-v1.0.4) (2026-07-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.2 to ^1.0.3

## [1.0.3](https://github.com/ipfs/helia/compare/libp2p-v1.0.2...libp2p-v1.0.3) (2026-07-02)


### Bug Fixes

* include keychain in browser ([4f47203](https://github.com/ipfs/helia/commit/4f4720349230404954fdf8fe759a990e555bc77b))

## [1.0.2](https://github.com/ipfs/helia/compare/libp2p-v1.0.1...libp2p-v1.0.2) (2026-07-02)


### Dependencies

* update delegated-routing deps ([688bd9d](https://github.com/ipfs/helia/commit/688bd9de67113276b3124025c07cb85c1194f241))
* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.1 to ^1.0.2
    * @helia/interface bumped from ^7.0.1 to ^7.0.2

## [1.0.1](https://github.com/ipfs/helia/compare/libp2p-v1.0.0...libp2p-v1.0.1) (2026-07-02)


### Bug Fixes

* add value to ipns result and export util to create records ([#1065](https://github.com/ipfs/helia/issues/1065)) ([883ff05](https://github.com/ipfs/helia/commit/883ff053cefc4b9f7cf7fd6759bc79f68def9297))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^1.0.0 to ^1.0.1
    * @helia/interface bumped from ^7.0.0 to ^7.0.1

## 1.0.0 (2026-06-29)


### ⚠ BREAKING CHANGES

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))

### Features

* add light constructor ([#1058](https://github.com/ipfs/helia/issues/1058)) ([16d805e](https://github.com/ipfs/helia/commit/16d805e18f8ebbe4f3c7b255c274e8b82f4d520b))
* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/delegated-routing-client bumped from ^0.0.0 to ^1.0.0
    * @helia/interface bumped from ^6.2.1 to ^7.0.0
