# Changelog

## [4.0.20](https://github.com/ipfs/helia/compare/bitswap-v4.0.19...bitswap-v4.0.20) (2026-09-29)


### Bug Fixes

* filter blocks previously confirmed as not in the blockstore ([#1145](https://github.com/ipfs/helia/issues/1145)) ([bdbda7a](https://github.com/ipfs/helia/commit/bdbda7ae8c9755b039d595c481310c5fc6b890ef)), closes [#1144](https://github.com/ipfs/helia/issues/1144)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.1 to ^7.1.2
    * @helia/libp2p bumped from ^2.1.4 to ^2.1.5
    * @helia/utils bumped from ^3.0.5 to ^3.0.6

## [4.0.19](https://github.com/ipfs/helia/compare/bitswap-v4.0.18...bitswap-v4.0.19) (2026-09-23)


### Dependencies

* update protons ([#1131](https://github.com/ipfs/helia/issues/1131)) ([d496208](https://github.com/ipfs/helia/commit/d49620874dc67a5cb8a4b70fb568b73de66584fc))

## [4.0.18](https://github.com/ipfs/helia/compare/bitswap-v4.0.17...bitswap-v4.0.18) (2026-09-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^2.1.3 to ^2.1.4

## [4.0.17](https://github.com/ipfs/helia/compare/bitswap-v4.0.16...bitswap-v4.0.17) (2026-09-21)


### Bug Fixes

* pass runOnLimitedConnections to the topology and the dial ([#1129](https://github.com/ipfs/helia/issues/1129)) ([bbf05cb](https://github.com/ipfs/helia/commit/bbf05cb7b862cc1a02f5a0fc62412bb141c903cd)), closes [#1124](https://github.com/ipfs/helia/issues/1124)

## [4.0.16](https://github.com/ipfs/helia/compare/bitswap-v4.0.15...bitswap-v4.0.16) (2026-09-14)


### Bug Fixes

* update protons and regenerate messages ([#1127](https://github.com/ipfs/helia/issues/1127)) ([b34bc7c](https://github.com/ipfs/helia/commit/b34bc7c76d8ab1f1eeba9893af792299b05de111))

## [4.0.15](https://github.com/ipfs/helia/compare/bitswap-v4.0.14...bitswap-v4.0.15) (2026-09-10)


### Bug Fixes

* update unixfs deps to allow for streaming dags ([#1125](https://github.com/ipfs/helia/issues/1125)) ([16fc74d](https://github.com/ipfs/helia/commit/16fc74d30cded1773e9ac18b0a62ca4582f7eab9))

## [4.0.14](https://github.com/ipfs/helia/compare/bitswap-v4.0.13...bitswap-v4.0.14) (2026-08-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^2.1.2 to ^2.1.3

## [4.0.13](https://github.com/ipfs/helia/compare/bitswap-v4.0.12...bitswap-v4.0.13) (2026-08-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^2.1.1 to ^2.1.2

## [4.0.12](https://github.com/ipfs/helia/compare/bitswap-v4.0.11...bitswap-v4.0.12) (2026-08-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^2.1.0 to ^2.1.1

## [4.0.11](https://github.com/ipfs/helia/compare/bitswap-v4.0.10...bitswap-v4.0.11) (2026-08-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^2.0.0 to ^2.1.0

## [4.0.10](https://github.com/ipfs/helia/compare/bitswap-v4.0.9...bitswap-v4.0.10) (2026-08-15)


### Bug Fixes

* update bitswap sig to allow custom libp2p services ([3aeb397](https://github.com/ipfs/helia/commit/3aeb3977515bcd10b8ba488d095daf2529d29719))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^1.0.8 to ^2.0.0

## [4.0.9](https://github.com/ipfs/helia/compare/bitswap-v4.0.8...bitswap-v4.0.9) (2026-08-14)


### Bug Fixes

* use per-peer queue for incoming wantlist updates ([#1107](https://github.com/ipfs/helia/issues/1107)) ([0873bb5](https://github.com/ipfs/helia/commit/0873bb5f57daff610f4a8f416f2cdb2775d84f24))

## [4.0.8](https://github.com/ipfs/helia/compare/bitswap-v4.0.7...bitswap-v4.0.8) (2026-07-31)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^1.0.7 to ^1.0.8

## [4.0.7](https://github.com/ipfs/helia/compare/bitswap-v4.0.6...bitswap-v4.0.7) (2026-07-28)


### Bug Fixes

* do not evict fallback providers from session ([#1092](https://github.com/ipfs/helia/issues/1092)) ([f713369](https://github.com/ipfs/helia/commit/f713369d232dc9a09b1fbac5672e9053649a6579))
* do not evict session peers before querying them ([#1091](https://github.com/ipfs/helia/issues/1091)) ([244f77c](https://github.com/ipfs/helia/commit/244f77cf94be175c3dd44569910919e3b5e6eedc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.0 to ^7.1.1
    * @helia/libp2p bumped from ^1.0.6 to ^1.0.7
    * @helia/utils bumped from ^3.0.4 to ^3.0.5

## [4.0.6](https://github.com/ipfs/helia/compare/bitswap-v4.0.5...bitswap-v4.0.6) (2026-07-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.3 to ^7.1.0
    * @helia/libp2p bumped from ^1.0.5 to ^1.0.6
    * @helia/utils bumped from ^3.0.3 to ^3.0.4

## [4.0.5](https://github.com/ipfs/helia/compare/bitswap-v4.0.4...bitswap-v4.0.5) (2026-07-04)


### Bug Fixes

* the routing is made up of routers ([da4aa40](https://github.com/ipfs/helia/commit/da4aa40a30b8958e7fd9dcb1a82f7133443cb9fb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.2 to ^7.0.3
    * @helia/libp2p bumped from ^1.0.4 to ^1.0.5
    * @helia/utils bumped from ^3.0.2 to ^3.0.3

## [4.0.4](https://github.com/ipfs/helia/compare/bitswap-v4.0.3...bitswap-v4.0.4) (2026-07-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^1.0.3 to ^1.0.4

## [4.0.3](https://github.com/ipfs/helia/compare/bitswap-v4.0.2...bitswap-v4.0.3) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/libp2p bumped from ^1.0.2 to ^1.0.3

## [4.0.2](https://github.com/ipfs/helia/compare/bitswap-v4.0.1...bitswap-v4.0.2) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.1 to ^7.0.2
    * @helia/libp2p bumped from ^1.0.1 to ^1.0.2
    * @helia/utils bumped from ^3.0.1 to ^3.0.2

## [4.0.1](https://github.com/ipfs/helia/compare/bitswap-v4.0.0...bitswap-v4.0.1) (2026-07-02)


### Bug Fixes

* add value to ipns result and export util to create records ([#1065](https://github.com/ipfs/helia/issues/1065)) ([883ff05](https://github.com/ipfs/helia/commit/883ff053cefc4b9f7cf7fd6759bc79f68def9297))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.0 to ^7.0.1
    * @helia/libp2p bumped from ^1.0.0 to ^1.0.1
    * @helia/utils bumped from ^3.0.0 to ^3.0.1

## [4.0.0](https://github.com/ipfs/helia/compare/bitswap-v3.2.3...bitswap-v4.0.0) (2026-06-29)


### ⚠ BREAKING CHANGES

* import from `@helia/interface` not `@helia/interface/foo`
* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))
* returned instances of `CID` and `MultihashDigest` come from the `multiformats@14.x.x` module

### Features

* add light constructor ([#1058](https://github.com/ipfs/helia/issues/1058)) ([16d805e](https://github.com/ipfs/helia/commit/16d805e18f8ebbe4f3c7b255c274e8b82f4d520b))
* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Bug Fixes

* export all types at root of `@helia/interface` ([#1053](https://github.com/ipfs/helia/issues/1053)) ([a464d83](https://github.com/ipfs/helia/commit/a464d83a68eea5a6f9af8fa26bf95ef9c997af61))
* skip identify race when peer protocols are already known ([#1040](https://github.com/ipfs/helia/issues/1040)) ([b52cede](https://github.com/ipfs/helia/commit/b52cedec85919a7a6b39217703e1560756b362e8))
* update to multiformats@14.x.x ([#1039](https://github.com/ipfs/helia/issues/1039)) ([f6cc764](https://github.com/ipfs/helia/commit/f6cc7640840b77757c09d9463539b41e6ea33099))


### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#1015](https://github.com/ipfs/helia/issues/1015)) ([ae98a4f](https://github.com/ipfs/helia/commit/ae98a4f4940310383c2a384cde64f99264326583))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.1 to ^7.0.0
    * @helia/libp2p bumped from ^0.0.0 to ^1.0.0
    * @helia/utils bumped from ^2.5.2 to ^3.0.0

## [3.2.3](https://github.com/ipfs/helia/compare/bitswap-v3.2.2...bitswap-v3.2.3) (2026-04-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.5.1 to ^2.5.2

## [3.2.2](https://github.com/ipfs/helia/compare/bitswap-v3.2.1...bitswap-v3.2.2) (2026-04-10)


### Bug Fixes

* add module-sync ([#1001](https://github.com/ipfs/helia/issues/1001)) ([ef5363e](https://github.com/ipfs/helia/commit/ef5363e834439ba1838a408639cb2d05d3ba6867))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.0 to ^6.2.1
    * @helia/utils bumped from ^2.5.0 to ^2.5.1

## [3.2.1](https://github.com/ipfs/helia/compare/bitswap-v3.2.0...bitswap-v3.2.1) (2026-04-09)


### Bug Fixes

* propagate progress events during bitswap operations ([#999](https://github.com/ipfs/helia/issues/999)) ([79dc114](https://github.com/ipfs/helia/commit/79dc114f480dd6da4a9e6ffa76e1d63d009f331e))

## [3.2.0](https://github.com/ipfs/helia/compare/bitswap-v3.1.4...bitswap-v3.2.0) (2026-04-08)


### Features

* emit standardized block broker events ([#995](https://github.com/ipfs/helia/issues/995)) ([397f2d8](https://github.com/ipfs/helia/commit/397f2d86cefd425178a67e70e8f338093d666fe9))
* emit standardized routing events ([#981](https://github.com/ipfs/helia/issues/981)) ([5ee3283](https://github.com/ipfs/helia/commit/5ee3283f6f414a9cff4fbe941481aec5f0e4143a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.1.1 to ^6.2.0
    * @helia/utils bumped from ^2.4.2 to ^2.5.0

## [3.1.4](https://github.com/ipfs/helia/compare/bitswap-v3.1.3...bitswap-v3.1.4) (2026-03-18)


### Bug Fixes

* add toString method to bitswap providers ([#973](https://github.com/ipfs/helia/issues/973)) ([0a6e505](https://github.com/ipfs/helia/commit/0a6e5052e75c83383bff2429c75a7a97a615de40))

## [3.1.3](https://github.com/ipfs/helia/compare/bitswap-v3.1.2...bitswap-v3.1.3) (2026-03-06)


### Bug Fixes

* do not send blocks repeatedly ([#966](https://github.com/ipfs/helia/issues/966)) ([92480ee](https://github.com/ipfs/helia/commit/92480ee8b81ceaff212ed198b84c1ec0460ad86c))
* enforce maximum peer wantlist size ([#970](https://github.com/ipfs/helia/issues/970)) ([eaeb734](https://github.com/ipfs/helia/commit/eaeb734da7f48aef3d4086d731587d9f2a185ffb))
* lower do not resend window ([#969](https://github.com/ipfs/helia/issues/969)) ([b3783c0](https://github.com/ipfs/helia/commit/b3783c0d4c28113989600482474f883b72db8af1))

## [3.1.2](https://github.com/ipfs/helia/compare/bitswap-v3.1.1...bitswap-v3.1.2) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.1.0 to ^6.1.1
    * @helia/utils bumped from ^2.4.1 to ^2.4.2

## [3.1.1](https://github.com/ipfs/helia/compare/bitswap-v3.1.0...bitswap-v3.1.1) (2026-02-05)


### Bug Fixes

* emit provider event for initial providers ([#953](https://github.com/ipfs/helia/issues/953)) ([f058fba](https://github.com/ipfs/helia/commit/f058fba8a06f8afdd3558bdf7c3801381648ffec))
* emit provider event for initial provides ([f058fba](https://github.com/ipfs/helia/commit/f058fba8a06f8afdd3558bdf7c3801381648ffec))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.4.0 to ^2.4.1

## [3.1.0](https://github.com/ipfs/helia/compare/bitswap-v3.0.15...bitswap-v3.1.0) (2026-02-04)


### Features

* allow adding peers to session ([#950](https://github.com/ipfs/helia/issues/950)) ([33e4681](https://github.com/ipfs/helia/commit/33e4681394539d4298a028d2d9ff48a14f76a8e3))


### Bug Fixes

* add name to block brokers ([#949](https://github.com/ipfs/helia/issues/949)) ([0456c42](https://github.com/ipfs/helia/commit/0456c42dbd92d94633c133d4f5fe35264a6bbb80))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.3 to ^6.1.0
    * @helia/utils bumped from ^2.3.5 to ^2.4.0

## [3.0.15](https://github.com/ipfs/helia/compare/bitswap-v3.0.14...bitswap-v3.0.15) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.2 to ^6.0.3
    * @helia/utils bumped from ^2.3.4 to ^2.3.5

## [3.0.14](https://github.com/ipfs/helia/compare/bitswap-v3.0.13...bitswap-v3.0.14) (2026-01-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.3 to ^2.3.4

## [3.0.13](https://github.com/ipfs/helia/compare/bitswap-v3.0.12...bitswap-v3.0.13) (2025-12-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.2 to ^2.3.3

## [3.0.12](https://github.com/ipfs/helia/compare/bitswap-v3.0.11...bitswap-v3.0.12) (2025-12-12)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.1 to ^2.3.2

## [3.0.11](https://github.com/ipfs/helia/compare/bitswap-v3.0.10...bitswap-v3.0.11) (2025-12-12)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.3.0 to ^2.3.1

## [3.0.10](https://github.com/ipfs/helia/compare/bitswap-v3.0.9...bitswap-v3.0.10) (2025-11-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.5 to ^2.3.0

## [3.0.9](https://github.com/ipfs/helia/compare/bitswap-v3.0.8...bitswap-v3.0.9) (2025-11-14)


### Bug Fixes

* allow truncated hashes ([#903](https://github.com/ipfs/helia/issues/903)) ([c3d41c1](https://github.com/ipfs/helia/commit/c3d41c1f9584c87fbebc88bc6f106e93b8444698))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.4 to ^2.2.5

## [3.0.8](https://github.com/ipfs/helia/compare/bitswap-v3.0.7...bitswap-v3.0.8) (2025-11-13)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.3 to ^2.2.4

## [3.0.7](https://github.com/ipfs/helia/compare/bitswap-v3.0.6...bitswap-v3.0.7) (2025-10-29)


### Bug Fixes

* use libp2p provider routing field ([#889](https://github.com/ipfs/helia/issues/889)) ([d4d97b8](https://github.com/ipfs/helia/commit/d4d97b83f76be7e3b480052467408839f808e230))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.1 to ^6.0.2
    * @helia/utils bumped from ^2.2.2 to ^2.2.3

## [3.0.6](https://github.com/ipfs/helia/compare/bitswap-v3.0.5...bitswap-v3.0.6) (2025-10-27)


### Bug Fixes

* add provider events to bitswap and trustless gateways ([#888](https://github.com/ipfs/helia/issues/888)) ([95d95da](https://github.com/ipfs/helia/commit/95d95dad7ff2a1e462b5a8a4f57ac40c4503f4ef))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.0.0 to ^6.0.1
    * @helia/utils bumped from ^2.2.1 to ^2.2.2

## [3.0.5](https://github.com/ipfs/helia/compare/bitswap-v3.0.4...bitswap-v3.0.5) (2025-10-22)


### Bug Fixes

* update log formatting to print errors correctly ([#884](https://github.com/ipfs/helia/issues/884)) ([f35ecd1](https://github.com/ipfs/helia/commit/f35ecd1c8ad3c712d3882d0f0f2abaf0f0296ec1))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.2.0 to ^2.2.1

## [3.0.4](https://github.com/ipfs/helia/compare/bitswap-v3.0.3...bitswap-v3.0.4) (2025-10-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.1.1 to ^2.2.0

## [3.0.3](https://github.com/ipfs/helia/compare/bitswap-v3.0.2...bitswap-v3.0.3) (2025-10-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.1.0 to ^2.1.1

## [3.0.2](https://github.com/ipfs/helia/compare/bitswap-v3.0.1...bitswap-v3.0.2) (2025-10-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.0.1 to ^2.1.0

## [3.0.1](https://github.com/ipfs/helia/compare/bitswap-v3.0.0...bitswap-v3.0.1) (2025-10-09)


### Bug Fixes

* enforce maximum identity hash size ([#865](https://github.com/ipfs/helia/issues/865)) ([d9051cd](https://github.com/ipfs/helia/commit/d9051cdc2fd19ab7def32d195b5798b27d85a078)), closes [#846](https://github.com/ipfs/helia/issues/846)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^2.0.0 to ^2.0.1

## [3.0.0](https://github.com/ipfs/helia/compare/bitswap-v2.2.0...bitswap-v3.0.0) (2025-10-09)


### ⚠ BREAKING CHANGES

* uses libp2p v3 and updated block/data stores

### Features

* update to libp2p@v3 and latest data/block stores ([#856](https://github.com/ipfs/helia/issues/856)) ([34d3ecd](https://github.com/ipfs/helia/commit/34d3ecd76c8424387c57221000e226f08ccd1d1e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.4.0 to ^6.0.0
    * @helia/utils bumped from ^1.4.0 to ^2.0.0

## [2.2.0](https://github.com/ipfs/helia/compare/bitswap-v2.1.3...bitswap-v2.2.0) (2025-07-31)


### Features

* add block received event ([#837](https://github.com/ipfs/helia/issues/837)) ([7d471a0](https://github.com/ipfs/helia/commit/7d471a027606254f4fb4e1b73d62b8646426237d))

## [2.1.3](https://github.com/ipfs/helia/compare/bitswap-v2.1.2...bitswap-v2.1.3) (2025-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.2 to ^5.4.0
    * @helia/utils bumped from ^1.3.2 to ^1.4.0

## [2.1.2](https://github.com/ipfs/helia/compare/bitswap-v2.1.1...bitswap-v2.1.2) (2025-05-20)


### Dependencies

* update aegir to 47.x.x ([#804](https://github.com/ipfs/helia/issues/804)) ([60fbbc2](https://github.com/ipfs/helia/commit/60fbbc2eb08e023e2eac02ae0e89ed143d715084))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.1 to ^5.3.2
    * @helia/utils bumped from ^1.3.1 to ^1.3.2

## [2.1.1](https://github.com/ipfs/helia/compare/bitswap-v2.1.0...bitswap-v2.1.1) (2025-05-13)


### Dependencies

* update all deps ([#792](https://github.com/ipfs/helia/issues/792)) ([d43efc7](https://github.com/ipfs/helia/commit/d43efc7bdfff34071a8e4e22e01f659fbac0b78e))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.3.0 to ^5.3.1
    * @helia/utils bumped from ^1.3.0 to ^1.3.1

## [2.1.0](https://github.com/ipfs/helia/compare/bitswap-v2.0.5...bitswap-v2.1.0) (2025-05-13)


### Features

* pass initial providers to session ([#777](https://github.com/ipfs/helia/issues/777)) ([3d77369](https://github.com/ipfs/helia/commit/3d773698389deb70e1a0181eb81fb8b5992857b8))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.2.1 to ^5.3.0
    * @helia/utils bumped from ^1.2.2 to ^1.3.0

## [2.0.5](https://github.com/ipfs/helia/compare/bitswap-v2.0.4...bitswap-v2.0.5) (2025-03-13)


### Documentation

* add spell checker to ci ([#743](https://github.com/ipfs/helia/issues/743)) ([45ca6bc](https://github.com/ipfs/helia/commit/45ca6bc70b1644028500101044595fa0e2199b07))


### Dependencies

* bump it-length-prefixed from 9.1.1 to 10.0.1 ([#740](https://github.com/ipfs/helia/issues/740)) ([ac7185a](https://github.com/ipfs/helia/commit/ac7185af8f0da0782f6273fba76ccfe9427d2fa4))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.2.0 to ^5.2.1
    * @helia/utils bumped from ^1.2.1 to ^1.2.2

## [2.0.4](https://github.com/ipfs/helia/compare/bitswap-v2.0.3...bitswap-v2.0.4) (2025-02-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^1.2.0 to ^1.2.1

## [2.0.3](https://github.com/ipfs/helia/compare/bitswap-v2.0.2...bitswap-v2.0.3) (2025-01-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.1.0 to ^5.2.0
    * @helia/utils bumped from ^1.1.0 to ^1.2.0

## [2.0.2](https://github.com/ipfs/helia/compare/bitswap-v2.0.1...bitswap-v2.0.2) (2024-11-18)


### Dependencies

* bump aegir from 44.1.4 to 45.0.1 ([#669](https://github.com/ipfs/helia/issues/669)) ([e58e49c](https://github.com/ipfs/helia/commit/e58e49c6aed8ea9d1e9851435a25e33fdbee3781))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^5.0.0 to ^5.1.0
    * @helia/utils bumped from ^1.0.1 to ^1.1.0

## [2.0.1](https://github.com/ipfs/helia/compare/bitswap-v2.0.0...bitswap-v2.0.1) (2024-10-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^1.0.0 to ^1.0.1

## [2.0.0](https://github.com/ipfs/helia/compare/bitswap-v1.1.4...bitswap-v2.0.0) (2024-10-07)


### ⚠ BREAKING CHANGES

* helia now uses libp2p@2.x.x

### Bug Fixes

* add doc-check script and export types used by functions ([#637](https://github.com/ipfs/helia/issues/637)) ([4f14996](https://github.com/ipfs/helia/commit/4f14996a9b976f2b60f4c8fe52a4fd1632420749))
* update to libp2p@2.x.x ([#630](https://github.com/ipfs/helia/issues/630)) ([ec8bf66](https://github.com/ipfs/helia/commit/ec8bf66dd870b42d6e5ef2b41706102397e0d39a))


### Dependencies

* **dev:** bump sinon from 18.0.1 to 19.0.2 ([#634](https://github.com/ipfs/helia/issues/634)) ([23e62e1](https://github.com/ipfs/helia/commit/23e62e16b8962bfe982a1bbb157a144382ca7099))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.3.1 to ^5.0.0
    * @helia/utils bumped from ^0.3.3 to ^1.0.0

## [1.1.4](https://github.com/ipfs/helia/compare/bitswap-v1.1.3...bitswap-v1.1.4) (2024-09-13)


### Bug Fixes

* remove @libp2p/interfaces dep ([#591](https://github.com/ipfs/helia/issues/591)) ([e567717](https://github.com/ipfs/helia/commit/e567717102464a925f87cb10fc05808a50be960e))

## [1.1.3](https://github.com/ipfs/helia/compare/bitswap-v1.1.2...bitswap-v1.1.3) (2024-07-31)


### Bug Fixes

* update deps and fix types ([#572](https://github.com/ipfs/helia/issues/572)) ([f16c9ea](https://github.com/ipfs/helia/commit/f16c9eac32677333313c433eb918b705439c0819))


### Documentation

* fix grammar - it's -&gt; its ([#565](https://github.com/ipfs/helia/issues/565)) ([155e24d](https://github.com/ipfs/helia/commit/155e24db8c06c33972895d702a656e0c2996f3d9))


### Dependencies

* bump aegir from 42.2.11 to 43.0.1 ([#552](https://github.com/ipfs/helia/issues/552)) ([74ccc92](https://github.com/ipfs/helia/commit/74ccc92793a6d0bb4bee714d9fe4fa4183aa4ee8))
* bump aegir from 43.0.3 to 44.0.1 ([#569](https://github.com/ipfs/helia/issues/569)) ([6952f05](https://github.com/ipfs/helia/commit/6952f05357844e5aa3dffb2afaf261df06b9b7c1))
* **dev:** bump sinon from 17.0.2 to 18.0.0 ([#536](https://github.com/ipfs/helia/issues/536)) ([62f77df](https://github.com/ipfs/helia/commit/62f77dfbff94a64e9c248f5be54055c18a6427f7))
* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.3.0 to ^4.3.1
    * @helia/utils bumped from ^0.3.2 to ^0.3.3

## [1.1.2](https://github.com/ipfs/helia/compare/bitswap-v1.1.1...bitswap-v1.1.2) (2024-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^0.3.1 to ^0.3.2

## [1.1.1](https://github.com/ipfs/helia/compare/bitswap-v1.1.0...bitswap-v1.1.1) (2024-05-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/utils bumped from ^0.3.0 to ^0.3.1

## [1.1.0](https://github.com/ipfs/helia/compare/bitswap-v1.0.1...bitswap-v1.1.0) (2024-05-01)


### Features

* add metrics property to helia interface ([#512](https://github.com/ipfs/helia/issues/512)) ([f7f71bb](https://github.com/ipfs/helia/commit/f7f71bb20ab0b4efbe802be5af1189e76153b826))


### Bug Fixes

* improve bitswap message merging ([#522](https://github.com/ipfs/helia/issues/522)) ([7419dfc](https://github.com/ipfs/helia/commit/7419dfc2fe273d3f816d27b62062636be0964d7a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.2.0 to ^4.3.0
    * @helia/utils bumped from ^0.2.0 to ^0.3.0

## [1.0.1](https://github.com/ipfs/helia/compare/bitswap-v1.0.0...bitswap-v1.0.1) (2024-04-22)


### Bug Fixes

* define max bitswap message sizes ([#510](https://github.com/ipfs/helia/issues/510)) ([58d7ddf](https://github.com/ipfs/helia/commit/58d7ddf19cd965a8a5cc1d8148fa073a6b44d8ae))
* split bitswap messages ([#507](https://github.com/ipfs/helia/issues/507)) ([59de059](https://github.com/ipfs/helia/commit/59de0599367c828998069ac37dc93e10ddb565a1))

## 1.0.0 (2024-04-15)


### Features

* add @helia/bitswap with sessions ([#409](https://github.com/ipfs/helia/issues/409)) ([e582c63](https://github.com/ipfs/helia/commit/e582c63ca296c789312f5fcf5e3e18f267f74c03))


### Bug Fixes

* improve sessions implementation ([#495](https://github.com/ipfs/helia/issues/495)) ([9ea934e](https://github.com/ipfs/helia/commit/9ea934ed7208e87c28bc65e9090bdedf66ceeffd))
* increase default listers on abort signals ([#484](https://github.com/ipfs/helia/issues/484)) ([7cd012a](https://github.com/ipfs/helia/commit/7cd012aa2ba568845d49d63a71806d20f6ac678f))
* remove wants from wantlist when multiple block retrievers are used ([#491](https://github.com/ipfs/helia/issues/491)) ([b1c761d](https://github.com/ipfs/helia/commit/b1c761db6db7a7aca3044263fdd5e8967204deeb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^4.0.0 to ^4.2.0
    * @helia/utils bumped from ^0.1.0 to ^0.2.0
