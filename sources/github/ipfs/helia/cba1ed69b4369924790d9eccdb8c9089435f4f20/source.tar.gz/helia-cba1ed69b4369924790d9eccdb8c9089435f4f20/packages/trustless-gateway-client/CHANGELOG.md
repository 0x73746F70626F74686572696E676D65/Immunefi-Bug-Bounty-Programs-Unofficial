# Changelog

## [1.0.7](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.6...trustless-gateway-client-v1.0.7) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.1 to ^7.1.2
    * @helia/utils bumped from ^3.0.5 to ^3.0.6

## [1.0.6](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.5...trustless-gateway-client-v1.0.6) (2026-09-22)


### Bug Fixes

* make trustless gateway requests stateless ([#1139](https://github.com/ipfs/helia/issues/1139)) ([654052a](https://github.com/ipfs/helia/commit/654052a62ce68950f95d46adaa414992037caf17))
* use default caching strategy for trustless gateways ([#1137](https://github.com/ipfs/helia/issues/1137)) ([47363dd](https://github.com/ipfs/helia/commit/47363dd2da06a93c24ea9006a938835ce73e82cb))

## [1.0.5](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.4...trustless-gateway-client-v1.0.5) (2026-07-28)


### Bug Fixes

* do not evict fallback providers from session ([#1092](https://github.com/ipfs/helia/issues/1092)) ([f713369](https://github.com/ipfs/helia/commit/f713369d232dc9a09b1fbac5672e9053649a6579))
* do not evict session peers before querying them ([#1091](https://github.com/ipfs/helia/issues/1091)) ([244f77c](https://github.com/ipfs/helia/commit/244f77cf94be175c3dd44569910919e3b5e6eedc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.0 to ^7.1.1
    * @helia/utils bumped from ^3.0.4 to ^3.0.5

## [1.0.4](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.3...trustless-gateway-client-v1.0.4) (2026-07-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.3 to ^7.1.0
    * @helia/utils bumped from ^3.0.3 to ^3.0.4

## [1.0.3](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.2...trustless-gateway-client-v1.0.3) (2026-07-04)


### Bug Fixes

* the routing is made up of routers ([da4aa40](https://github.com/ipfs/helia/commit/da4aa40a30b8958e7fd9dcb1a82f7133443cb9fb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.2 to ^7.0.3
    * @helia/utils bumped from ^3.0.2 to ^3.0.3

## [1.0.2](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.1...trustless-gateway-client-v1.0.2) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.1 to ^7.0.2
    * @helia/utils bumped from ^3.0.1 to ^3.0.2

## [1.0.1](https://github.com/ipfs/helia/compare/trustless-gateway-client-v1.0.0...trustless-gateway-client-v1.0.1) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.0 to ^7.0.1
    * @helia/utils bumped from ^3.0.0 to ^3.0.1

## 1.0.0 (2026-06-29)


### ⚠ BREAKING CHANGES

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))

### Features

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.1 to ^7.0.0
    * @helia/utils bumped from ^2.5.2 to ^3.0.0
