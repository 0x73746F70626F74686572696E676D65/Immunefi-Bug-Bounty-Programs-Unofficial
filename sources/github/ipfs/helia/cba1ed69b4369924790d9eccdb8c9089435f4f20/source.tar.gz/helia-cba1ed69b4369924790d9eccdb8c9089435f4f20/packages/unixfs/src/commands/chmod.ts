import * as dagPB from '@ipld/dag-pb'
import { logger } from '@libp2p/logger'
import { UnixFS } from 'ipfs-unixfs'
import { exporter, recursive } from 'ipfs-unixfs-exporter'
import { importer } from 'ipfs-unixfs-importer'
import last from 'it-last'
import { pipe } from 'it-pipe'
import toBuffer from 'it-to-buffer'
import { CID } from 'multiformats/cid'
import * as raw from 'multiformats/codecs/raw'
import { sha256 } from 'multiformats/hashes/sha2'
import { InvalidPBNodeError, NotUnixFSError, UnknownError } from '../errors.ts'
import { persist } from './utils/persist.ts'
import { resolve, updatePathCids } from './utils/resolve.ts'
import type { ChmodOptions } from '../index.ts'
import type { GetStore, PutStore } from '../unixfs.ts'
import type { PBNode, PBLink } from '@ipld/dag-pb'

const log = logger('helia:unixfs:chmod')

export async function chmod (cid: CID, mode: number, blockstore: PutStore & GetStore, options: ChmodOptions = {}): Promise<CID> {
  const resolved = await resolve(cid, options.path, blockstore, options)

  log('chmod %c %d', resolved.cid, mode)

  if (options.recursive === true) {
    // recursively export from root CID, change perms of each entry then reimport
    // but do not reimport files, only manipulate dag-pb nodes
    const root = await pipe(
      async function * () {
        for await (const entry of recursive(resolved.cid, blockstore, options)) {
          let metadata: UnixFS
          let links: PBLink[] = []
          const file = await exporter(entry.cid, blockstore, options)

          if (file.type === 'raw') {
            // convert to UnixFS
            metadata = new UnixFS({ type: 'file', data: file.node })
          } else if (file.type === 'file' || file.type === 'directory') {
            metadata = file.unixfs
            links = file.node.Links
          } else {
            throw new NotUnixFSError()
          }

          metadata.mode = mode

          const node = {
            Data: metadata.marshal(),
            Links: links
          }

          yield {
            path: entry.path,
            content: node
          }
        }
      },
      // @ts-expect-error cannot combine progress types
      (source) => importer(source, blockstore, {
        ...options,
        dagBuilder: async function * (source, block) {
          for await (const entry of source) {
            yield async function () {
              // @ts-expect-error cannot derive type
              const node: PBNode = entry.content

              const buf = dagPB.encode(node)
              const updatedCid = await persist(buf, block, {
                ...options,
                cidVersion: cid.version
              })

              if (node.Data == null) {
                throw new InvalidPBNodeError(`${updatedCid} had no data`)
              }

              const unixfs = UnixFS.unmarshal(node.Data)

              return {
                cid: updatedCid,
                size: BigInt(buf.length),
                path: entry.path,
                unixfs
              }
            }
          }
        }
      }),
      async (nodes) => last(nodes)
    )

    if (root == null) {
      throw new UnknownError(`Could not chmod ${resolved.cid.toString()}`)
    }

    return updatePathCids(root.cid, resolved, blockstore, options)
  }

  const block = await toBuffer(blockstore.get(resolved.cid, options))
  let metadata: UnixFS
  let links: PBLink[] = []

  if (resolved.cid.code === raw.code) {
    // convert to UnixFS
    metadata = new UnixFS({ type: 'file', data: block })
  } else {
    const node = dagPB.decode(block)

    if (node.Data == null) {
      throw new InvalidPBNodeError(`${resolved.cid.toString()} had no data`)
    }

    links = node.Links
    metadata = UnixFS.unmarshal(node.Data)
  }

  metadata.mode = mode
  const updatedBlock = dagPB.encode({
    Data: metadata.marshal(),
    Links: links
  })

  const hash = await sha256.digest(updatedBlock)
  const updatedCid = CID.create(resolved.cid.version, dagPB.code, hash)

  await blockstore.put(updatedCid, updatedBlock)

  return updatePathCids(updatedCid, resolved, blockstore, options)
}
