# Changelog

## [2.0.2](https://github.com/ipfs/helia/compare/dnslink-v2.0.1...dnslink-v2.0.2) (2026-07-03)


### Bug Fixes

* handle multihashes in dns link results ([#1072](https://github.com/ipfs/helia/issues/1072)) ([f4eb7d2](https://github.com/ipfs/helia/commit/f4eb7d27ca159f4908c607ead0b9859f93af8df2))

## [2.0.1](https://github.com/ipfs/helia/compare/dnslink-v2.0.0...dnslink-v2.0.1) (2026-06-30)


### Bug Fixes

* return multihash value instead of peer id ([#1062](https://github.com/ipfs/helia/issues/1062)) ([cee53d7](https://github.com/ipfs/helia/commit/cee53d7daa50af23f064681f07d75c24093aacbe))

## [2.0.0](https://github.com/ipfs/helia/compare/dnslink-v1.2.1...dnslink-v2.0.0) (2026-06-29)


### ⚠ BREAKING CHANGES

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))
* returned instances of `CID` and `MultihashDigest` come from the `multiformats@14.x.x` module

### Features

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Bug Fixes

* update to multiformats@14.x.x ([#1039](https://github.com/ipfs/helia/issues/1039)) ([f6cc764](https://github.com/ipfs/helia/commit/f6cc7640840b77757c09d9463539b41e6ea33099))


### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#1015](https://github.com/ipfs/helia/issues/1015)) ([ae98a4f](https://github.com/ipfs/helia/commit/ae98a4f4940310383c2a384cde64f99264326583))

## [1.2.1](https://github.com/ipfs/helia/compare/dnslink-v1.2.0...dnslink-v1.2.1) (2026-04-10)


### Bug Fixes

* add module-sync ([#1001](https://github.com/ipfs/helia/issues/1001)) ([ef5363e](https://github.com/ipfs/helia/commit/ef5363e834439ba1838a408639cb2d05d3ba6867))

## [1.2.0](https://github.com/ipfs/helia/compare/dnslink-v1.1.4...dnslink-v1.2.0) (2026-04-08)


### Features

* emit standardized block broker events ([#995](https://github.com/ipfs/helia/issues/995)) ([397f2d8](https://github.com/ipfs/helia/commit/397f2d86cefd425178a67e70e8f338093d666fe9))

## [1.1.4](https://github.com/ipfs/helia/compare/dnslink-v1.1.3...dnslink-v1.1.4) (2026-01-15)


### Bug Fixes

* use non-deprecated factory function to create delegated client ([#934](https://github.com/ipfs/helia/issues/934)) ([20ba9cf](https://github.com/ipfs/helia/commit/20ba9cf6256961d2b664af0e8f48b5e9d009d834))

## [1.1.3](https://github.com/ipfs/helia/compare/dnslink-v1.1.2...dnslink-v1.1.3) (2025-11-10)


### Bug Fixes

* support recursive DNSLink lookups ([#897](https://github.com/ipfs/helia/issues/897)) ([636e950](https://github.com/ipfs/helia/commit/636e9503ff56e49c2209f6af480df36b7a8c3735))

## [1.1.2](https://github.com/ipfs/helia/compare/dnslink-v1.1.1...dnslink-v1.1.2) (2025-10-29)


### Bug Fixes

* use libp2p provider routing field ([#889](https://github.com/ipfs/helia/issues/889)) ([d4d97b8](https://github.com/ipfs/helia/commit/d4d97b83f76be7e3b480052467408839f808e230))

## [1.1.1](https://github.com/ipfs/helia/compare/dnslink-v1.1.0...dnslink-v1.1.1) (2025-10-22)


### Bug Fixes

* update log formatting to print errors correctly ([#884](https://github.com/ipfs/helia/issues/884)) ([f35ecd1](https://github.com/ipfs/helia/commit/f35ecd1c8ad3c712d3882d0f0f2abaf0f0296ec1))

## [1.1.0](https://github.com/ipfs/helia/compare/dnslink-v1.0.1...dnslink-v1.1.0) (2025-10-14)


### Features

* add lookup cache ([#869](https://github.com/ipfs/helia/issues/869)) ([bb88944](https://github.com/ipfs/helia/commit/bb889444c85270e891d384f2ca9d2789f5ad37d6))

## [1.0.1](https://github.com/ipfs/helia/compare/dnslink-v1.0.0...dnslink-v1.0.1) (2025-10-09)


### Bug Fixes

* support multiple DNSLink entries ([#863](https://github.com/ipfs/helia/issues/863)) ([fe38409](https://github.com/ipfs/helia/commit/fe384098a0930915eff4c41d562606955e0e710d)), closes [#368](https://github.com/ipfs/helia/issues/368)

## 1.0.0 (2025-10-09)


### ⚠ BREAKING CHANGES

* `ipns.publish` now accepts key name strings rather than private keys Names previously publishing using an user controlled private key, will need to be explicitly published again by first importing the key into the keychain (`await libp2p.keychain.importKey('my-key', key)` and then published with `ipns.publish('my-key', ...)`.

### Features

* add ipns reproviding/republishing ([#764](https://github.com/ipfs/helia/issues/764)) ([008747b](https://github.com/ipfs/helia/commit/008747b59a03682e1b6f648a39635e1b1971e481))
