import { ed25519Crypto } from '@ipshipyard/crypto'
import { multiaddr } from '@multiformats/multiaddr'
import { uriToMultiaddr } from '@multiformats/uri-to-multiaddr'
import { expect } from 'aegir/chai'
import { defaultLogger } from 'birnam'
import { CID } from 'multiformats/cid'
import { sha256 } from 'multiformats/hashes/sha2'
import { stubInterface } from 'sinon-ts'
import { equals as uint8ArrayEquals } from 'uint8arrays/equals'
import { TrustlessGatewayBlockBroker } from '../src/broker.ts'
import { TrustlessGateway } from '../src/trustless-gateway.ts'
import type { Provider, Routing } from '@helia/interface'
import type { StubbedInstance } from 'sinon-ts'

describe('trustless-gateway-block-broker', () => {
  let gatewayBlockBroker: TrustlessGatewayBlockBroker
  let routing: StubbedInstance<Required<Routing>>
  let badGatewayPeer: Provider
  let goodGatewayPeer: Provider
  let cid: CID
  let expectedBlock: Uint8Array

  beforeEach(async () => {
    // see .aegir.js - bad gateway returns block that fails validation
    cid = CID.parse('bafkreiefnkxuhnq3536qo2i2w3tazvifek4mbbzb6zlq3ouhprjce5c3aq')
    expectedBlock = Uint8Array.from([0, 1, 2, 0])

    routing = stubInterface()

    badGatewayPeer = {
      id: (await ed25519Crypto().generatePrivateKey()).publicKey.toCID(),
      multiaddrs: [
        uriToMultiaddr(process.env.BAD_TRUSTLESS_GATEWAY ?? '')
      ],
      router: 'test-routing',
      fallback: false
    }
    goodGatewayPeer = {
      id: (await ed25519Crypto().generatePrivateKey()).publicKey.toCID(),
      multiaddrs: [
        uriToMultiaddr(process.env.TRUSTLESS_GATEWAY ?? '')
      ],
      router: 'test-routing',
      fallback: false
    }

    gatewayBlockBroker = new TrustlessGatewayBlockBroker({
      routing,
      logger: defaultLogger()
    }, {
      allowInsecure: true,
      allowLocal: true
    })
  })

  it('tries all gateways before failing', async () => {
    routing.findProviders.callsFake(async function * () {
      yield badGatewayPeer
      yield badGatewayPeer
    })

    // see .aegir.js - bad gateway returns 500
    const cid = CID.parse('bafkreihrn5vx6hgqqltsfbhyr4fqlfu47icddprfubkqrztm6yft5iwpmm')

    await expect(gatewayBlockBroker.retrieve?.(cid))
      .to.eventually.be.rejected()
      .with.property('errors')
      .with.lengthOf(2)
  })

  it('tries other gateways if it receives invalid blocks', async () => {
    routing.findProviders.callsFake(async function * () {
      yield badGatewayPeer
      yield goodGatewayPeer
    })

    const block = await gatewayBlockBroker.retrieve?.(cid, {
      validateFn: async (block) => {
        const hash = await sha256.digest(block)

        if (!uint8ArrayEquals(hash.digest, cid.multihash.digest)) {
          throw new Error('Bad hash')
        }
      }
    })

    expect(block).to.equalBytes(expectedBlock)
  })

  it('does not call other gateways if the first gateway returns a valid block', async () => {
    routing.findProviders.callsFake(async function * () {
      yield goodGatewayPeer
      yield badGatewayPeer
    })

    const cid = CID.parse('bafkreiefnkxuhnq3536qo2i2w3tazvifek4mbbzb6zlq3ouhprjce5c3aq')
    const expectedBlock = Uint8Array.from([0, 1, 2, 0])

    const block = await gatewayBlockBroker.retrieve?.(cid, {
      validateFn: async (block) => {
        const hash = await sha256.digest(block)

        if (!uint8ArrayEquals(hash.digest, cid.multihash.digest)) {
          throw new Error('Bad hash')
        }
      }
    })

    expect(block).to.equalBytes(expectedBlock)
  })

  it('creates a session', async () => {
    routing.findProviders.returns(async function * () {
      // non-http provider
      yield {
        id: (await ed25519Crypto().generatePrivateKey()).publicKey.toCID(),
        multiaddrs: [
          multiaddr('/ip4/132.32.25.6/tcp/1234')
        ],
        router: 'test-routing',
        fallback: false
      }
      // expired peer info
      yield {
        id: (await ed25519Crypto().generatePrivateKey()).publicKey.toCID(),
        multiaddrs: [],
        router: 'test-routing',
        fallback: false
      }
      // http gateway
      yield {
        id: (await ed25519Crypto().generatePrivateKey()).publicKey.toCID(),
        multiaddrs: [
          uriToMultiaddr(process.env.TRUSTLESS_GATEWAY ?? '')
        ],
        router: 'test-routing',
        fallback: false
      }
    }())

    const sessionBlockstore = gatewayBlockBroker.createSession?.({
      minProviders: 1,
      allowInsecure: true,
      allowLocal: true
    })

    expect(sessionBlockstore).to.be.ok()

    await expect(sessionBlockstore?.retrieve?.(cid)).to.eventually.deep.equal(expectedBlock)
  })

  it('does not trigger new network requests if the same cid request is in-flight', async function () {
    // from .aegir.js polka server
    const cid = CID.parse('bafkqabtimvwgy3yk')
    if (process.env.TRUSTLESS_GATEWAY == null) {
      return this.skip()
    }
    const trustlessGateway = new TrustlessGateway(process.env.TRUSTLESS_GATEWAY, false, {
      logger: defaultLogger(),
      router: 'test'
    })

    // Call getRawBlock multiple times with the same CID
    const promises = Array.from({ length: 10 }, async () => trustlessGateway.getRawBlock(cid))

    // Wait for both promises to resolve
    const [block1, ...blocks] = await Promise.all(promises)

    // Assert that all calls to getRawBlock returned the same block
    for (const block of blocks) {
      expect(block).to.deep.equal(block1)
    }

    expect(trustlessGateway.getStats()).to.deep.equal({
      // attempt is only incremented when a new request is made
      attempts: 1,
      errors: 0,
      invalidBlocks: 0,
      successes: 1,
      pendingResponses: 0 // the queue is empty
    })
  })

  it('can pass custom headers to the gateway', async function () {
    if (process.env.TRUSTLESS_GATEWAY == null) {
      return this.skip()
    }
    const cid = CID.parse('bafybeic3q4y65yxu3yckr76q63bcvanhklwf6cwxuacnrot6v3gykrgsvq')

    const trustlessGateway = new TrustlessGateway(process.env.TRUSTLESS_GATEWAY, false, {
      logger: defaultLogger(),
      router: 'test',
      transformRequestInit: (requestInit) => {
        requestInit.headers = {
          ...requestInit.headers,
          'X-My-Header': 'my-value'
        }

        return requestInit
      }
    })

    await fetch(`${process.env.TRUSTLESS_GATEWAY}/logs/enable`)
    await trustlessGateway.getRawBlock(cid)
    await fetch(`${process.env.TRUSTLESS_GATEWAY}/logs/disable`)

    const reqLogs = await fetch(`${process.env.TRUSTLESS_GATEWAY}/logs`)
    const logs = await reqLogs.json()
    await fetch(`${process.env.TRUSTLESS_GATEWAY}/logs/clear`)

    // assert that fetch was called with the custom header
    expect(logs).to.have.lengthOf(1)
    expect(logs[0].headers['x-my-header']).to.equal('my-value')
  })

  it('should notify of progress during find providers', async function () {
    routing.findProviders.callsFake(async function * () {
      yield badGatewayPeer
    })

    const events = new Map<string, number>()

    await gatewayBlockBroker.retrieve?.(cid, {
      onProgress: (evt) => {
        let count = events.get(evt.type) ?? 0
        count++
        events.set(evt.type, count)
      }
    })

    expect(events.get('helia:block-broker:connect')).to.equal(1)
    expect(events.get('helia:block-broker:connected')).to.equal(1)
    expect(events.get('helia:block-broker:request-block')).to.equal(1)
    expect(events.get('helia:block-broker:receive-block')).to.equal(1)
  })
})
