# Changelog

## [1.1.2](https://github.com/ipfs/helia/compare/fallback-router-v1.1.1...fallback-router-v1.1.2) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.1 to ^7.1.2

## [1.1.1](https://github.com/ipfs/helia/compare/fallback-router-v1.1.0...fallback-router-v1.1.1) (2026-07-28)


### Bug Fixes

* do not evict fallback providers from session ([#1092](https://github.com/ipfs/helia/issues/1092)) ([f713369](https://github.com/ipfs/helia/commit/f713369d232dc9a09b1fbac5672e9053649a6579))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.1.0 to ^7.1.1

## [1.1.0](https://github.com/ipfs/helia/compare/fallback-router-v1.0.3...fallback-router-v1.1.0) (2026-07-10)


### Features

* add router capabilities for fallback routers ([#1084](https://github.com/ipfs/helia/issues/1084)) ([aea1416](https://github.com/ipfs/helia/commit/aea1416dda67a0d76e31efb9e75d0ec287fa63ea))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.3 to ^7.1.0

## [1.0.3](https://github.com/ipfs/helia/compare/fallback-router-v1.0.2...fallback-router-v1.0.3) (2026-07-04)


### Bug Fixes

* include which router found the peer in get peer ([#1077](https://github.com/ipfs/helia/issues/1077)) ([0cc31cd](https://github.com/ipfs/helia/commit/0cc31cd61e6585adfc10b7946f6d71d16a509709))
* the routing is made up of routers ([da4aa40](https://github.com/ipfs/helia/commit/da4aa40a30b8958e7fd9dcb1a82f7133443cb9fb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.2 to ^7.0.3

## [1.0.2](https://github.com/ipfs/helia/compare/fallback-router-v1.0.1...fallback-router-v1.0.2) (2026-07-02)


### Bug Fixes

* split http args ([#1069](https://github.com/ipfs/helia/issues/1069)) ([ef258e7](https://github.com/ipfs/helia/commit/ef258e7e7d0bcd10143137d953b60471daab60d9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.1 to ^7.0.2

## [1.0.1](https://github.com/ipfs/helia/compare/fallback-router-v1.0.0...fallback-router-v1.0.1) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^7.0.0 to ^7.0.1

## 1.0.0 (2026-06-29)


### ⚠ BREAKING CHANGES

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))

### Features

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^6.2.1 to ^7.0.0
