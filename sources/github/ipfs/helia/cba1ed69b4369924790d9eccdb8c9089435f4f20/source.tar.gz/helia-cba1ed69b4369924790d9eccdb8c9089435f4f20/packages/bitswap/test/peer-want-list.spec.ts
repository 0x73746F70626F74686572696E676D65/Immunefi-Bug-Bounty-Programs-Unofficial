import { generateKeyPair } from '@libp2p/crypto/keys'
import { defaultLogger } from '@libp2p/logger'
import { peerIdFromPrivateKey } from '@libp2p/peer-id'
import { expect } from 'aegir/chai'
import { MemoryBlockstore } from 'blockstore-core'
import delay from 'delay'
import { CID } from 'multiformats/cid'
import { sha256 } from 'multiformats/hashes/sha2'
import pRetry from 'p-retry'
import Sinon from 'sinon'
import { stubInterface } from 'sinon-ts'
import { DEFAULT_MAX_SIZE_REPLACE_HAS_WITH_BLOCK, DEFAULT_WANTLIST_SEND_DEBOUNCE } from '../src/constants.ts'
import { Network } from '../src/network.ts'
import { BlockPresenceType, WantlistEntry, WantType } from '../src/pb/message.ts'
import { PeerWantLists } from '../src/peer-want-lists/index.ts'
import ve from '../src/utils/varint-encoder.ts'
import type { BitswapMessageEventDetail } from '../src/network.ts'
import type { Routing } from '@helia/interface'
import type { Libp2p, ComponentLogger, PeerId, Connection } from '@libp2p/interface'
import type { Blockstore } from 'interface-blockstore'

interface PeerWantListsComponentStubs {
  peerId: PeerId
  blockstore: Blockstore
  network: Network
  libp2p: Libp2p
  logger: ComponentLogger
}

function receiveWant (network: Network, from: PeerId, entries: WantlistEntry[], full: boolean = false): void {
  network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
    detail: {
      peer: from,
      connection: stubInterface<Connection>({
        remotePeer: from
      }),
      message: {
        blocks: [],
        blockPresences: [],
        pendingBytes: 0,
        wantlist: {
          full,
          entries
        }
      }
    }
  })
}

describe('peer-want-lists', () => {
  let components: PeerWantListsComponentStubs
  let wantLists: PeerWantLists
  let network: Network
  let cids: CID[]
  let blocks: Uint8Array[]

  beforeEach(async () => {
    blocks = []
    cids = []

    for (let i = 0; i < 5; i++) {
      const block = new Uint8Array(DEFAULT_MAX_SIZE_REPLACE_HAS_WITH_BLOCK + 1).fill(i)
      const cid = CID.createV0(await sha256.digest(block)).toV1()

      blocks.push(block)
      cids.push(cid)
    }

    const logger = defaultLogger()
    const libp2p = stubInterface<Libp2p>({
      getConnections: () => [],
      metrics: undefined
    })
    network = new Network({
      routing: stubInterface<Routing>(),
      logger,
      libp2p
    })

    components = {
      peerId: peerIdFromPrivateKey(await generateKeyPair('Ed25519')),
      blockstore: new MemoryBlockstore(),
      network,
      libp2p,
      logger: defaultLogger()
    }

    wantLists = new PeerWantLists(components)
  })

  it('should keep a ledger for a peer', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    expect(wantLists.ledgerForPeer(remotePeer)).to.be.undefined('should not have list initially')

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            full: true,
            entries: [{
              cid: cid.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    const ledger = wantLists.ledgerForPeer(remotePeer)

    expect(ledger).to.have.property('peer', remotePeer)
    expect(ledger).to.have.property('value', 0)
    expect(ledger).to.have.property('sent', 0)
    expect(ledger).to.have.property('received', 0)
    expect(ledger).to.have.property('exchanged', 1)
  })

  it('should replace the wantlist for a peer when the full list is received', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid1 = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const cid2 = CID.parse('bafyreidykglsfhoixmivffc5uwhcgshx4j465xwqntbmu43nb2dzqwfvae')

    // first wantlist
    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid1.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    let entries = wantLists.wantListForPeer(remotePeer)

    expect(entries?.map(entry => entry.cid.toString())).to.include(cid1.toString())

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            full: true,
            entries: [{
              cid: cid2.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    entries = wantLists.wantListForPeer(remotePeer)

    // should only have CIDs from the second message
    expect(entries?.map(entry => entry.cid.toString())).to.not.include(cid1.toString())
    expect(entries?.map(entry => entry.cid.toString())).to.include(cid2.toString())
  })

  it('should merge the wantlist for a peer when a partial list is received', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid1 = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const cid2 = CID.parse('bafyreidykglsfhoixmivffc5uwhcgshx4j465xwqntbmu43nb2dzqwfvae')

    // first wantlist
    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid1.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    let entries = wantLists.wantListForPeer(remotePeer)

    expect(entries?.map(entry => entry.cid.toString())).to.include(cid1.toString())

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid2.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    entries = wantLists.wantListForPeer(remotePeer)

    // should have both CIDs
    expect(entries?.map(entry => entry.cid.toString())).to.include(cid1.toString())
    expect(entries?.map(entry => entry.cid.toString())).to.include(cid2.toString())
  })

  it('should record the amount of incoming data', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [{
            prefix: Uint8Array.from([0, 1, 2, 3, 4]),
            data: Uint8Array.from([0, 1, 2, 3, 4])
          }, {
            prefix: Uint8Array.from([0, 1, 2]),
            data: Uint8Array.from([0, 1, 2])
          }],
          blockPresences: [],
          pendingBytes: 0
        }
      }
    })

    const ledger = wantLists.ledgerForPeer(remotePeer)

    expect(ledger).to.have.property('received', 8)
  })

  it('should send requested blocks to peer', async () => {
    const sendMessageStub = network.sendMessage = Sinon.stub()
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const block = Uint8Array.from([0, 1, 2, 3, 4])

    // we have block
    await components.blockstore.put(cid, block)

    // incoming message
    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    // wait for network send
    await pRetry(() => {
      if (!sendMessageStub.called) {
        throw new Error('Network message not sent')
      }
    })

    const message = sendMessageStub.getCall(0).args[1]

    expect(message.blocks).to.have.lengthOf(1)
    expect([...message.blocks.values()][0].data).to.equalBytes(block)
    expect([...message.blocks.values()][0].prefix).to.equalBytes(ve([
      cid.version, cid.code, cid.multihash.code, cid.multihash.digest.byteLength
    ]))

    // have to wait for network send
    await delay(DEFAULT_WANTLIST_SEND_DEBOUNCE * 3)

    expect(wantLists.wantListForPeer(remotePeer)
      ?.filter(entry => entry.status === 'want')
      .map(entry => entry.cid.toString())).to.not.include(cid.toString()
    )
  })

  it('should send requested block presences to peer', async () => {
    const sendMessageStub = network.sendMessage = Sinon.stub()
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const block = Uint8Array.from(new Array(DEFAULT_MAX_SIZE_REPLACE_HAS_WITH_BLOCK + 1))

    // we have block
    await components.blockstore.put(cid, block)

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1,
              wantType: WantType.WantHave
            }]
          }
        }
      }
    })

    // wait for network send
    await pRetry(() => {
      if (!sendMessageStub.called) {
        throw new Error('Network message not sent')
      }
    })

    const message = sendMessageStub.getCall(0).args[1]

    expect(message.blocks).to.be.empty('should not have sent blocks')
    expect(message.blockPresences).to.have.lengthOf(1)
    expect([...message.blockPresences.values()][0].cid).to.equalBytes(cid.bytes)
    expect([...message.blockPresences.values()][0].type).to.equal(BlockPresenceType.HaveBlock, 'should have sent HaveBlock presence')
  })

  it('should send requested lack of block presences to peer', async () => {
    const sendMessageStub = network.sendMessage = Sinon.stub()
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    // CID for a block we don't have
    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1,
              wantType: WantType.WantBlock,
              sendDontHave: true
            }]
          }
        }
      }
    })

    // wait for network send
    await pRetry(() => {
      if (!sendMessageStub.called) {
        throw new Error('Network message not sent')
      }
    })

    const message = sendMessageStub.getCall(0).args[1]

    expect(message.blocks).to.be.empty('should not have sent blocks')
    expect(message.blockPresences).to.have.lengthOf(1)
    expect([...message.blockPresences.values()][0].cid).to.equalBytes(cid.bytes)
    expect([...message.blockPresences.values()][0].type).to.equal(BlockPresenceType.DoNotHaveBlock, 'should have sent DoNotHaveBlock presence')
  })

  it('should send requested blocks to peer when presence was requested but block size is less than maxSizeReplaceHasWithBlock', async () => {
    const sendMessageStub = network.sendMessage = Sinon.stub()
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const block = Uint8Array.from([0, 1, 2, 3, 4])

    // we have block
    await components.blockstore.put(cid, block)

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1,
              wantType: WantType.WantHave
            }]
          }
        }
      }
    })

    // wait for network send
    await pRetry(() => {
      if (!sendMessageStub.called) {
        throw new Error('Network message not sent')
      }
    })

    const message = sendMessageStub.getCall(0).args[1]

    expect(message.blockPresences).to.be.empty()
    expect(message.blocks).to.have.lengthOf(1)
    expect([...message.blocks.values()][0].data).to.equalBytes(block)
    expect([...message.blocks.values()][0].prefix).to.equalBytes(ve([
      cid.version, cid.code, cid.multihash.code, cid.multihash.digest.byteLength
    ]))

    // have to wait for network send
    await delay(1)

    expect(wantLists.wantListForPeer(remotePeer)
      ?.filter(entry => entry.status === 'want')
      .map(entry => entry.cid.toString())).to.not.include(cid.toString()
    )
  })

  it('should send requested block presences to peer for blocks we don\'t have', async () => {
    const sendMessageStub = network.sendMessage = Sinon.stub()
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1,
              wantType: WantType.WantHave,
              sendDontHave: true
            }]
          }
        }
      }
    })

    // wait for network send
    await pRetry(() => {
      if (!sendMessageStub.called) {
        throw new Error('Network message not sent')
      }
    })

    const message = sendMessageStub.getCall(0).args[1]

    expect(message.blocks).to.be.empty('should not have sent blocks')
    expect(message.blockPresences).to.have.lengthOf(1)
    expect([...message.blockPresences.values()][0].cid).to.equalBytes(cid.bytes)
    expect([...message.blockPresences.values()][0].type).to.equal(BlockPresenceType.DoNotHaveBlock, 'should have sent DoNotHaveBlock presence')
  })

  it('should remove wants when peer cancels', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    expect(wantLists.wantListForPeer(remotePeer)?.map(entry => entry.cid.toString())).to.include(cid.toString())

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1,
              cancel: true
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    expect(wantLists.wantListForPeer(remotePeer)?.map(entry => entry.cid.toString())).to.not.include(cid.toString())
  })

  it('should remove wantlist and ledger when peer disconnects', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const block = Uint8Array.from([0, 1, 2, 3, 4])

    // we have block
    await components.blockstore.put(cid, block)

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    expect(wantLists.ledgerForPeer(remotePeer)).to.be.ok()
    expect(wantLists.wantListForPeer(remotePeer)).to.be.ok()

    wantLists.peerDisconnected(remotePeer)

    expect(wantLists.ledgerForPeer(remotePeer)).to.be.undefined()
    expect(wantLists.wantListForPeer(remotePeer)).to.be.undefined()
  })

  it('should return peers with want lists', async () => {
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    expect(wantLists.peers()).to.be.empty()

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [{
            prefix: Uint8Array.from([0, 1, 2, 3, 4]),
            data: Uint8Array.from([0, 1, 2, 3, 4])
          }, {
            prefix: Uint8Array.from([0, 1, 2]),
            data: Uint8Array.from([0, 1, 2])
          }],
          blockPresences: [],
          pendingBytes: 0
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    expect(wantLists.peers().map(p => p.toString())).to.include(remotePeer.toString())
  })

  it('should send requested blocks to peer when they are received', async () => {
    const sendMessageStub = network.sendMessage = Sinon.stub()
    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    const cid = CID.parse('QmaQwYWpchozXhFv8nvxprECWBSCEppN9dfd2VQiJfRo3F')
    const block = Uint8Array.from([0, 1, 2, 3, 4])

    network.safeDispatchEvent<BitswapMessageEventDetail>('bitswap:message', {
      detail: {
        peer: remotePeer,
        connection: stubInterface<Connection>({
          remotePeer
        }),
        message: {
          blocks: [],
          blockPresences: [],
          pendingBytes: 0,
          wantlist: {
            entries: [{
              cid: cid.bytes,
              priority: 1
            }]
          }
        }
      }
    })

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    expect(wantLists.wantListForPeer(remotePeer)?.map(e => e.cid.toString())).to.include(cid.toString())

    // now we have block
    await components.blockstore.put(cid, block)

    // we received it
    await wantLists.receivedBlock(cid, {})

    // wait for network send
    await pRetry(() => {
      if (!sendMessageStub.called) {
        throw new Error('Network message not sent')
      }
    })

    const message = sendMessageStub.getCall(0).args[1]

    expect(message.blocks).to.have.lengthOf(1)
    expect([...message.blocks.values()][0].data).to.equalBytes(block)
    expect([...message.blocks.values()][0].prefix).to.equalBytes(ve([
      cid.version, cid.code, cid.multihash.code, cid.multihash.digest.byteLength
    ]))

    // have to wait for network send
    await delay(1)

    expect(wantLists.wantListForPeer(remotePeer)
      ?.filter(entry => entry.status === 'want')
      .map(entry => entry.cid.toString())
    )
      .to.not.include(cid.toString())

    // should only have sent one message
    await delay(100)
    expect(sendMessageStub.callCount).to.equal(1)
  })

  it('should evict low priority wants', async () => {
    const maxWantListSize = 3

    // @ts-expect-error private, readonly field
    wantLists.maxWantListSize = maxWantListSize

    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    receiveWant(network, remotePeer, [{
      cid: cids[0].bytes,
      priority: 1
    }, {
      cid: cids[1].bytes,
      priority: 1
    }, {
      cid: cids[2].bytes,
      priority: 10
    }, {
      cid: cids[3].bytes,
      priority: 10
    }, {
      cid: cids[4].bytes,
      priority: 10
    }])

    await delay(100)

    expect(wantLists.wantListForPeer(remotePeer)).to.have.lengthOf(maxWantListSize)
    expect(wantLists.wantListForPeer(remotePeer)?.every(entry => entry.priority > 1)).to.be.true()
  })

  it('should evict old wants', async () => {
    const maxWantListSize = 3

    // @ts-expect-error private, readonly field
    wantLists.maxWantListSize = maxWantListSize

    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    receiveWant(network, remotePeer, [{
      cid: cids[0].bytes,
      priority: 10
    }])

    await delay(10)

    // reset haveBlock to ensure we only sort on created time
    wantLists.wantListForPeer(remotePeer)?.forEach(entry => {
      // @ts-expect-error not in interface
      delete entry.haveBlock
    })

    receiveWant(network, remotePeer, [{
      cid: cids[1].bytes,
      priority: 10
    }])

    await delay(10)

    // reset haveBlock to ensure we only sort on created time
    wantLists.wantListForPeer(remotePeer)?.forEach(entry => {
      // @ts-expect-error not in interface
      delete entry.haveBlock
    })

    receiveWant(network, remotePeer, [{
      cid: cids[2].bytes,
      priority: 10
    }])

    await delay(10)

    // reset haveBlock to ensure we only sort on created time
    wantLists.wantListForPeer(remotePeer)?.forEach(entry => {
      // @ts-expect-error not in interface
      delete entry.haveBlock
    })

    receiveWant(network, remotePeer, [{
      cid: cids[3].bytes,
      priority: 10
    }])

    await delay(10)

    // reset haveBlock to ensure we only sort on created time
    wantLists.wantListForPeer(remotePeer)?.forEach(entry => {
      // @ts-expect-error not in interface
      delete entry.haveBlock
    })

    receiveWant(network, remotePeer, [{
      cid: cids[4].bytes,
      priority: 10
    }])

    await delay(100)

    expect(wantLists.wantListForPeer(remotePeer)).to.have.lengthOf(maxWantListSize)
    expect(wantLists.wantListForPeer(remotePeer)?.map(entry => entry.cid.toString()).sort()).to.deep.equal([
      `${cids[2]}`,
      `${cids[3]}`,
      `${cids[4]}`
    ].sort())
  })

  it('should evict wants we do not have blocks for', async () => {
    const maxWantListSize = 3

    // @ts-expect-error private, readonly field
    wantLists.maxWantListSize = maxWantListSize

    const remotePeer = peerIdFromPrivateKey(await generateKeyPair('Ed25519'))

    receiveWant(network, remotePeer, [{
      cid: cids[0].bytes,
      priority: 10
    }, {
      cid: cids[1].bytes,
      priority: 10
    }, {
      cid: cids[2].bytes,
      priority: 10
    }])

    await wantLists.ledgerForPeer(remotePeer)?.sendQueue.onIdle()

    const entry0 = wantLists.wantListForPeer(remotePeer)?.find(entry => entry.cid.equals(cids[0]))

    if (entry0 != null) {
      // @ts-expect-error haveBlock is not in interface
      delete entry0.haveBlock
    }

    const entry1 = wantLists.wantListForPeer(remotePeer)?.find(entry => entry.cid.equals(cids[2]))

    if (entry1 != null) {
      expect(entry1).to.have.property('haveBlock', false)
    }

    const entry2 = wantLists.wantListForPeer(remotePeer)?.find(entry => entry.cid.equals(cids[2]))

    if (entry2 != null) {
      // @ts-expect-error haveBlock is not in interface
      delete entry2.haveBlock
    }

    // cids[1] will be evicted as `haveBlock` is false
    receiveWant(network, remotePeer, [{
      cid: cids[3].bytes,
      priority: 10
    }])

    expect(wantLists.wantListForPeer(remotePeer)).to.have.lengthOf(maxWantListSize)
    expect(wantLists.wantListForPeer(remotePeer)?.map(entry => entry.cid.toString()).sort()).to.deep.equal([
      `${cids[0]}`,
      `${cids[2]}`,
      `${cids[3]}`
    ].sort())
  })
})
