# Changelog

## [8.0.9](https://github.com/ipfs/helia/compare/mfs-v8.0.8...mfs-v8.0.9) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.8 to ^8.0.9

## [8.0.8](https://github.com/ipfs/helia/compare/mfs-v8.0.7...mfs-v8.0.8) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.7 to ^8.0.8

## [8.0.7](https://github.com/ipfs/helia/compare/mfs-v8.0.6...mfs-v8.0.7) (2026-09-14)


### Bug Fixes

* update protons and regenerate messages ([#1127](https://github.com/ipfs/helia/issues/1127)) ([b34bc7c](https://github.com/ipfs/helia/commit/b34bc7c76d8ab1f1eeba9893af792299b05de111))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.6 to ^8.0.7

## [8.0.6](https://github.com/ipfs/helia/compare/mfs-v8.0.5...mfs-v8.0.6) (2026-09-10)


### Bug Fixes

* update unixfs deps to allow for streaming dags ([#1125](https://github.com/ipfs/helia/issues/1125)) ([16fc74d](https://github.com/ipfs/helia/commit/16fc74d30cded1773e9ac18b0a62ca4582f7eab9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.5 to ^8.0.6

## [8.0.5](https://github.com/ipfs/helia/compare/mfs-v8.0.4...mfs-v8.0.5) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.4 to ^8.0.5

## [8.0.4](https://github.com/ipfs/helia/compare/mfs-v8.0.3...mfs-v8.0.4) (2026-07-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.3 to ^8.0.4

## [8.0.3](https://github.com/ipfs/helia/compare/mfs-v8.0.2...mfs-v8.0.3) (2026-07-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.2 to ^8.0.3

## [8.0.2](https://github.com/ipfs/helia/compare/mfs-v8.0.1...mfs-v8.0.2) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.1 to ^8.0.2

## [8.0.1](https://github.com/ipfs/helia/compare/mfs-v8.0.0...mfs-v8.0.1) (2026-07-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^8.0.0 to ^8.0.1

## [8.0.0](https://github.com/ipfs/helia/compare/mfs-v7.1.1...mfs-v8.0.0) (2026-06-29)


### ⚠ BREAKING CHANGES

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049))
* returned instances of `CID` and `MultihashDigest` come from the `multiformats@14.x.x` module

### Features

* make libp2p optional ([#1049](https://github.com/ipfs/helia/issues/1049)) ([4b2aea6](https://github.com/ipfs/helia/commit/4b2aea6f6111ba12590384f80c1bc18650ea5d8e))


### Bug Fixes

* update to multiformats@14.x.x ([#1039](https://github.com/ipfs/helia/issues/1039)) ([f6cc764](https://github.com/ipfs/helia/commit/f6cc7640840b77757c09d9463539b41e6ea33099))


### Dependencies

* bump aegir from 47.2.0 to 48.0.1 ([#1015](https://github.com/ipfs/helia/issues/1015)) ([ae98a4f](https://github.com/ipfs/helia/commit/ae98a4f4940310383c2a384cde64f99264326583))
* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.2.1 to ^8.0.0

## [7.1.1](https://github.com/ipfs/helia/compare/mfs-v7.1.0...mfs-v7.1.1) (2026-04-10)


### Bug Fixes

* add module-sync ([#1001](https://github.com/ipfs/helia/issues/1001)) ([ef5363e](https://github.com/ipfs/helia/commit/ef5363e834439ba1838a408639cb2d05d3ba6867))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.2.0 to ^7.2.1

## [7.1.0](https://github.com/ipfs/helia/compare/mfs-v7.0.5...mfs-v7.1.0) (2026-04-08)


### Features

* emit standardized block broker events ([#995](https://github.com/ipfs/helia/issues/995)) ([397f2d8](https://github.com/ipfs/helia/commit/397f2d86cefd425178a67e70e8f338093d666fe9))
* emit standardized routing events ([#981](https://github.com/ipfs/helia/issues/981)) ([5ee3283](https://github.com/ipfs/helia/commit/5ee3283f6f414a9cff4fbe941481aec5f0e4143a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.1.0 to ^7.2.0

## [7.0.5](https://github.com/ipfs/helia/compare/mfs-v7.0.4...mfs-v7.0.5) (2026-03-18)


### Bug Fixes

* support profiles and shard split thresholds in mfs ([#972](https://github.com/ipfs/helia/issues/972)) ([9aff8d0](https://github.com/ipfs/helia/commit/9aff8d097a27a71efbdd500ab7b97a89baf57aa6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.0.4 to ^7.1.0

## [7.0.4](https://github.com/ipfs/helia/compare/mfs-v7.0.3...mfs-v7.0.4) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.0.3 to ^7.0.4

## [7.0.3](https://github.com/ipfs/helia/compare/mfs-v7.0.2...mfs-v7.0.3) (2026-02-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.0.2 to ^7.0.3

## [7.0.2](https://github.com/ipfs/helia/compare/mfs-v7.0.1...mfs-v7.0.2) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.0.1 to ^7.0.2

## [7.0.1](https://github.com/ipfs/helia/compare/mfs-v7.0.0...mfs-v7.0.1) (2026-01-15)


### Bug Fixes

* use non-deprecated factory function to create delegated client ([#934](https://github.com/ipfs/helia/issues/934)) ([20ba9cf](https://github.com/ipfs/helia/commit/20ba9cf6256961d2b664af0e8f48b5e9d009d834))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^7.0.0 to ^7.0.1

## [7.0.0](https://github.com/ipfs/helia/compare/mfs-v6.0.4...mfs-v7.0.0) (2026-01-12)


### ⚠ BREAKING CHANGES

* metadata is no longer returned from fs.ls - use fs.stat or similar to obtain it

### Features

* return cid/name/path from ls ([#929](https://github.com/ipfs/helia/issues/929)) ([b0033ca](https://github.com/ipfs/helia/commit/b0033ca2e1591981d2c9ecb6105911e41e7b786b))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^6.0.4 to ^7.0.0

## [6.0.4](https://github.com/ipfs/helia/compare/mfs-v6.0.3...mfs-v6.0.4) (2025-12-12)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^6.0.3 to ^6.0.4

## [6.0.3](https://github.com/ipfs/helia/compare/mfs-v6.0.2...mfs-v6.0.3) (2025-10-29)


### Bug Fixes

* use libp2p provider routing field ([#889](https://github.com/ipfs/helia/issues/889)) ([d4d97b8](https://github.com/ipfs/helia/commit/d4d97b83f76be7e3b480052467408839f808e230))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^6.0.2 to ^6.0.3

## [6.0.2](https://github.com/ipfs/helia/compare/mfs-v6.0.1...mfs-v6.0.2) (2025-10-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^6.0.1 to ^6.0.2

## [6.0.1](https://github.com/ipfs/helia/compare/mfs-v6.0.0...mfs-v6.0.1) (2025-10-09)


### Bug Fixes

* enforce maximum identity hash size ([#865](https://github.com/ipfs/helia/issues/865)) ([d9051cd](https://github.com/ipfs/helia/commit/d9051cdc2fd19ab7def32d195b5798b27d85a078)), closes [#846](https://github.com/ipfs/helia/issues/846)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^6.0.0 to ^6.0.1

## [6.0.0](https://github.com/ipfs/helia/compare/mfs-v5.1.0...mfs-v6.0.0) (2025-10-09)


### ⚠ BREAKING CHANGES

* uses libp2p v3 and updated block/data stores

### Features

* update to libp2p@v3 and latest data/block stores ([#856](https://github.com/ipfs/helia/issues/856)) ([34d3ecd](https://github.com/ipfs/helia/commit/34d3ecd76c8424387c57221000e226f08ccd1d1e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^5.1.0 to ^6.0.0

## [5.1.0](https://github.com/ipfs/helia/compare/mfs-v5.0.4...mfs-v5.1.0) (2025-07-31)


### Features

* expose extended option for ls in mfs and unixfs ([#836](https://github.com/ipfs/helia/issues/836)) ([9f51b17](https://github.com/ipfs/helia/commit/9f51b175c003a8e052231f4b85c1119165b590c6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^5.0.4 to ^5.1.0

## [5.0.4](https://github.com/ipfs/helia/compare/mfs-v5.0.3...mfs-v5.0.4) (2025-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^5.0.3 to ^5.0.4

## [5.0.3](https://github.com/ipfs/helia/compare/mfs-v5.0.2...mfs-v5.0.3) (2025-05-20)


### Dependencies

* update aegir to 47.x.x ([#804](https://github.com/ipfs/helia/issues/804)) ([60fbbc2](https://github.com/ipfs/helia/commit/60fbbc2eb08e023e2eac02ae0e89ed143d715084))
* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^5.0.2 to ^5.0.3

## [5.0.2](https://github.com/ipfs/helia/compare/mfs-v5.0.1...mfs-v5.0.2) (2025-05-13)


### Dependencies

* update all deps ([#792](https://github.com/ipfs/helia/issues/792)) ([d43efc7](https://github.com/ipfs/helia/commit/d43efc7bdfff34071a8e4e22e01f659fbac0b78e))
* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^5.0.1 to ^5.0.2

## [5.0.1](https://github.com/ipfs/helia/compare/mfs-v5.0.0...mfs-v5.0.1) (2025-05-13)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^5.0.0 to ^5.0.1

## [5.0.0](https://github.com/ipfs/helia/compare/mfs-v4.0.3...mfs-v5.0.0) (2025-03-20)


### ⚠ BREAKING CHANGES

* Fields that would involve DAG traversal have been removed from the output of `fs.stat` - pass the `extended` option to have them returned

### Bug Fixes

* return simple stats or extended stats ([#760](https://github.com/ipfs/helia/issues/760)) ([325b36f](https://github.com/ipfs/helia/commit/325b36f70624d3dcc25b2723f9e3e2d26e1e5199))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^4.0.3 to ^5.0.0

## [4.0.3](https://github.com/ipfs/helia/compare/mfs-v4.0.2...mfs-v4.0.3) (2025-03-13)


### Bug Fixes

* use bytestream methods to add byte streams ([#758](https://github.com/ipfs/helia/issues/758)) ([70b8fa9](https://github.com/ipfs/helia/commit/70b8fa96cb5fe0fddbb0e1528e6685778af90aa8))


### Documentation

* add spell checker to ci ([#743](https://github.com/ipfs/helia/issues/743)) ([45ca6bc](https://github.com/ipfs/helia/commit/45ca6bc70b1644028500101044595fa0e2199b07))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^4.0.2 to ^4.0.3

## [4.0.2](https://github.com/ipfs/helia/compare/mfs-v4.0.1...mfs-v4.0.2) (2025-01-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^4.0.1 to ^4.0.2

## [4.0.1](https://github.com/ipfs/helia/compare/mfs-v4.0.0...mfs-v4.0.1) (2024-11-18)


### Dependencies

* bump aegir from 44.1.4 to 45.0.1 ([#669](https://github.com/ipfs/helia/issues/669)) ([e58e49c](https://github.com/ipfs/helia/commit/e58e49c6aed8ea9d1e9851435a25e33fdbee3781))
* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^4.0.0 to ^4.0.1

## [4.0.0](https://github.com/ipfs/helia/compare/mfs-v3.0.8...mfs-v4.0.0) (2024-10-07)


### ⚠ BREAKING CHANGES

* helia now uses libp2p@2.x.x

### Bug Fixes

* add doc-check script and export types used by functions ([#637](https://github.com/ipfs/helia/issues/637)) ([4f14996](https://github.com/ipfs/helia/commit/4f14996a9b976f2b60f4c8fe52a4fd1632420749))
* update to libp2p@2.x.x ([#630](https://github.com/ipfs/helia/issues/630)) ([ec8bf66](https://github.com/ipfs/helia/commit/ec8bf66dd870b42d6e5ef2b41706102397e0d39a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.7 to ^4.0.0

## [3.0.8](https://github.com/ipfs/helia/compare/mfs-v3.0.7...mfs-v3.0.8) (2024-09-13)


### Bug Fixes

* remove @libp2p/interfaces dep ([#591](https://github.com/ipfs/helia/issues/591)) ([e567717](https://github.com/ipfs/helia/commit/e567717102464a925f87cb10fc05808a50be960e))

## [3.0.7](https://github.com/ipfs/helia/compare/mfs-v3.0.6...mfs-v3.0.7) (2024-07-31)


### Documentation

* fix grammar - it's -&gt; its ([#565](https://github.com/ipfs/helia/issues/565)) ([155e24d](https://github.com/ipfs/helia/commit/155e24db8c06c33972895d702a656e0c2996f3d9))


### Dependencies

* bump aegir from 42.2.11 to 43.0.1 ([#552](https://github.com/ipfs/helia/issues/552)) ([74ccc92](https://github.com/ipfs/helia/commit/74ccc92793a6d0bb4bee714d9fe4fa4183aa4ee8))
* bump aegir from 43.0.3 to 44.0.1 ([#569](https://github.com/ipfs/helia/issues/569)) ([6952f05](https://github.com/ipfs/helia/commit/6952f05357844e5aa3dffb2afaf261df06b9b7c1))
* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.6 to ^3.0.7

## [3.0.6](https://github.com/ipfs/helia/compare/mfs-v3.0.5...mfs-v3.0.6) (2024-05-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.5 to ^3.0.6

## [3.0.5](https://github.com/ipfs/helia/compare/mfs-v3.0.4...mfs-v3.0.5) (2024-04-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.4 to ^3.0.5

## [3.0.4](https://github.com/ipfs/helia/compare/mfs-v3.0.3...mfs-v3.0.4) (2024-04-15)


### Bug Fixes

* add sideEffects: false to package.json ([#485](https://github.com/ipfs/helia/issues/485)) ([8c45267](https://github.com/ipfs/helia/commit/8c45267a474ab10b2faadfebdab33cfe446e8c03))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.3 to ^3.0.4

## [3.0.3](https://github.com/ipfs/helia/compare/mfs-v3.0.2...mfs-v3.0.3) (2024-04-03)

### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.2 to ^3.0.3

## [3.0.2](https://github.com/ipfs/helia/compare/mfs-v3.0.1...mfs-v3.0.2) (2024-03-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.1 to ^3.0.2

## [3.0.1](https://github.com/ipfs/helia/compare/mfs-v3.0.0...mfs-v3.0.1) (2024-02-28)


### Bug Fixes

* support reading identity cids ([#429](https://github.com/ipfs/helia/issues/429)) ([98308f7](https://github.com/ipfs/helia/commit/98308f77488b8196b2d18f78f05ecd2d37456834))
* update project deps and docs ([77e34fc](https://github.com/ipfs/helia/commit/77e34fc115cbfb82585fd954bcf389ecebf655bc))
* use blockstore interface where possible ([#417](https://github.com/ipfs/helia/issues/417)) ([30c8981](https://github.com/ipfs/helia/commit/30c8981934ffba72d572a7b8b2712ec93b7f4d31))


### Dependencies

* update libp2p patch versions ([917a1bc](https://github.com/ipfs/helia/commit/917a1bceb9e9b56428a15dc3377a963f06affd12))
* The following workspace dependencies were updated
  * dependencies
    * @helia/unixfs bumped from ^3.0.0 to ^3.0.1

## [3.0.0](https://github.com/ipfs/helia/compare/mfs-v2.0.1...mfs-v3.0.0) (2024-01-24)


### ⚠ BREAKING CHANGES

* the `libp2p` property has been removed from the `Helia` interface in `@helia/interface` - it is still present on the return type of `createHelia` from the `helia` module

### Features

* add @helia/http to monorepo ([#372](https://github.com/ipfs/helia/issues/372)) ([76220cd](https://github.com/ipfs/helia/commit/76220cd5adf45af7fa61fd0a1321de4722b744d6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^3.0.1 to ^4.0.0
    * @helia/unixfs bumped from ^2.0.1 to ^3.0.0

## [2.0.0](https://github.com/ipfs/helia/compare/mfs-v1.0.2...mfs-v2.0.0) (2024-01-08)


### ⚠ BREAKING CHANGES

* uses multiformats v13

### Features

* update helia to v3 and multiformats to v13 ([9f7dc0a](https://github.com/ipfs/helia/commit/9f7dc0a0581524531501fc062fefb6ba26d99c02))

### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @helia/interface bumped from ^3.0.0 to ^3.0.1
    * @helia/unixfs bumped from ^2.0.0 to ^2.0.1

## [1.0.2](https://github.com/ipfs/helia/compare/mfs-v1.0.1...mfs-v1.0.2) (2023-10-07)


### Dependencies

* **dev:** bump helia from 2.0.1 to 2.0.3 ([#10](https://github.com/ipfs/helia-mfs/issues/10)) ([6911470](https://github.com/ipfs/helia/commit/6911470cb43720798fca571669a166eb3689dad2))

## [1.0.1](https://github.com/ipfs/helia/compare/mfs-v1.0.0...mfs-v1.0.1) (2023-09-08)


### Documentation

* update docs to use MFS style API ([#4](https://github.com/ipfs/helia-mfs/issues/4)) ([88b23b0](https://github.com/ipfs/helia/commit/88b23b0db4ac9da2a9e94291f2db7b10f436ce00))


### Dependencies

* bump @helia/interface from 1.2.2 to 2.0.0 ([#2](https://github.com/ipfs/helia-mfs/issues/2)) ([351fae7](https://github.com/ipfs/helia/commit/351fae7a129e642a6f312c9a61609273dec190bf))

## 1.0.0 (2023-08-14)


### Features

* initial import ([a70f4eb](https://github.com/ipfs/helia/commit/a70f4eb982e377eeeeb6fd4a53f7baf40c09641b))


### Trivial Changes

* fix up missing deps ([0b407a3](https://github.com/ipfs/helia/commit/0b407a3a7e1da8418fad72e6b3631528a912a493))
* use release versions ([0e7ca5e](https://github.com/ipfs/helia/commit/0e7ca5e3422472712bb83044a483a1a1326ea618))
