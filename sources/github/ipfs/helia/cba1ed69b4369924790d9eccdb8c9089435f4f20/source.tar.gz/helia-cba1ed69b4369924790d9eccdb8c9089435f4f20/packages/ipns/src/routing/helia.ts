import { CustomProgressEvent } from 'progress-events'
import type { IPNSRoutingGetOptions, IPNSRoutingPutOptions } from './index.ts'
import type { IPNSRouting } from '../index.ts'
import type { Routing } from '@helia/interface'
import type { ProgressEvent } from 'progress-events'

export interface HeliaRoutingComponents {
  routing: Routing
}

export type HeliaRoutingProgressEvents =
  ProgressEvent<'ipns:routing:helia:error', Error>

export class HeliaIPNSRouting implements IPNSRouting {
  private readonly routing: Routing

  constructor (routing: Routing) {
    this.routing = routing
  }

  async put (routingKey: Uint8Array, marshaledRecord: Uint8Array, options: IPNSRoutingPutOptions = {}): Promise<void> {
    try {
      await this.routing.put(routingKey, marshaledRecord, options)
    } catch (err: any) {
      options.onProgress?.(new CustomProgressEvent<Error>('ipns:routing:helia:error', err))
      throw err
    }
  }

  async get (routingKey: Uint8Array, options: IPNSRoutingGetOptions = {}): Promise<Uint8Array<ArrayBuffer>> {
    try {
      return await this.routing.get(routingKey, options)
    } catch (err: any) {
      options.onProgress?.(new CustomProgressEvent<Error>('ipns:routing:helia:error', err))
      throw err
    }
  }

  toString (): string {
    return 'HeliaRouting()'
  }
}

/**
 * The helia routing uses any available Routers configured on the passed Helia
 * node. This could be libp2p, HTTP API Delegated Routing, etc.
 */
export function heliaIPNSRouting (routing: Routing): IPNSRouting {
  return new HeliaIPNSRouting(routing)
}
