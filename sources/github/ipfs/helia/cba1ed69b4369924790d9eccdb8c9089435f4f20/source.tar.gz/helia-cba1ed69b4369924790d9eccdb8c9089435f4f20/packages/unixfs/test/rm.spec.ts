import { expect } from 'aegir/chai'
import { MemoryBlockstore } from 'blockstore-core'
import { importer } from 'ipfs-unixfs-importer'
import last from 'it-last'
import { unixfs } from '../src/index.ts'
import { createShardedDirectory } from './fixtures/create-sharded-directory.ts'
import { createSubShardedDirectory } from './fixtures/create-subsharded-directory.ts'
import { smallFile } from './fixtures/files.ts'
import type { UnixFS } from '../src/index.ts'
import type { Blockstore } from 'interface-blockstore'
import type { CID } from 'multiformats/cid'

describe('rm', () => {
  let blockstore: Blockstore
  let fs: UnixFS
  let emptyDirCid: CID

  beforeEach(async () => {
    blockstore = new MemoryBlockstore()

    fs = unixfs({ blockstore })

    emptyDirCid = await fs.addDirectory()
  })

  it('refuses to remove files without arguments', async () => {
    // @ts-expect-error invalid args
    await expect(fs.rm()).to.eventually.be.rejected()
  })

  it('removes a file', async () => {
    const path = 'foo'
    const fileCid = await fs.addBytes(smallFile)
    const dirCid = await fs.cp(fileCid, emptyDirCid, path)
    const updatedDirCid = await fs.rm(dirCid, path)

    await expect(fs.stat(updatedDirCid, {
      path
    })).to.eventually.be.rejected
      .with.property('name', 'NotFoundError')
  })

  it('removes a directory', async () => {
    const path = 'foo'
    const dirCid = await fs.cp(emptyDirCid, emptyDirCid, path)
    const updatedDirCid = await fs.rm(dirCid, path)

    await expect(fs.stat(updatedDirCid, {
      path
    })).to.eventually.be.rejected
      .with.property('name', 'NotFoundError')
  })

  it('removes a sharded directory inside a normal directory', async () => {
    const shardedDirCid = await createShardedDirectory(blockstore)
    const dirName = `subdir-${Math.random()}`
    const containingDirCid = await fs.cp(shardedDirCid, emptyDirCid, dirName)

    await expect(fs.stat(containingDirCid)).to.eventually.have.nested.property('unixfs.type', 'directory')
    await expect(fs.stat(containingDirCid, {
      path: dirName
    })).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    const updatedContainingDirCid = await fs.rm(containingDirCid, dirName)

    await expect(fs.stat(updatedContainingDirCid, {
      path: dirName
    })).to.eventually.be.rejected
      .with.property('name', 'NotFoundError')
  })

  it('removes a sharded directory inside a sharded directory', async () => {
    const shardedDirCid = await createShardedDirectory(blockstore)
    const otherShardedDirCid = await createShardedDirectory(blockstore)
    const dirName = `subdir-${Math.random()}`
    const containingDirCid = await fs.cp(shardedDirCid, otherShardedDirCid, dirName)

    await expect(fs.stat(containingDirCid)).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')
    await expect(fs.stat(containingDirCid, {
      path: dirName
    })).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    const updatedContainingDirCid = await fs.rm(containingDirCid, dirName)

    await expect(fs.stat(updatedContainingDirCid, {
      path: dirName
    })).to.eventually.be.rejected
      .with.property('name', 'NotFoundError')

    expect(updatedContainingDirCid.toString()).to.equal(shardedDirCid.toString(), 'adding and removing a file from a sharded directory did not result in the original sharded CID')
  })

  it('results in the same hash as a sharded directory created by the importer when removing a file and removing the file means the root node is below the shard threshold', async function () {
    const shardSplitThresholdBytes = 55

    // create a shard with the importer
    const importResult = await last(importer([{
      path: 'file-1.txt',
      content: Uint8Array.from([0, 1, 2, 3, 4])
    }], blockstore, {
      wrapWithDirectory: true,
      shardSplitThresholdBytes
    }))

    if (importResult == null) {
      throw new Error('Nothing imported')
    }

    const { cid: importerCid } = importResult
    await expect(fs.stat(importerCid)).to.eventually.have.nested.property('unixfs.type', 'directory')

    // create the same shard with unixfs command
    const fileCid = await fs.addBytes(Uint8Array.from([0, 1, 2, 3, 4]))
    const containingDirCid = await fs.cp(fileCid, emptyDirCid, 'file-1.txt', {
      shardSplitThresholdBytes
    })

    await expect(fs.stat(containingDirCid)).to.eventually.have.nested.property('unixfs.type', 'directory')

    const dirWithFileCid = await fs.cp(fileCid, containingDirCid, 'file-2.txt', {
      shardSplitThresholdBytes
    })

    await expect(fs.stat(dirWithFileCid)).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    const dirWithoutFileCid = await fs.rm(dirWithFileCid, 'file-2.txt', {
      shardSplitThresholdBytes
    })

    await expect(fs.stat(dirWithoutFileCid)).to.eventually.have.nested.property('unixfs.type', 'directory')

    expect(dirWithoutFileCid).to.eql(importerCid)
  })

  it('results in the same hash as a sharded directory created by the importer when removing a file', async function () {
    const shardSplitThresholdBytes = 1

    // create a shard with the importer
    const importResult = await last(importer([{
      path: 'file-1.txt',
      content: Uint8Array.from([0, 1, 2, 3, 4])
    }], blockstore, {
      wrapWithDirectory: true,
      shardSplitThresholdBytes
    }))

    if (importResult == null) {
      throw new Error('Nothing imported')
    }

    const { cid: importerCid } = importResult
    await expect(fs.stat(importerCid)).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    // create the same shard with unixfs command
    const fileCid = await fs.addBytes(Uint8Array.from([0, 1, 2, 3, 4]))
    let containingDirCid = await fs.cp(fileCid, emptyDirCid, 'file-1.txt', {
      shardSplitThresholdBytes
    })

    await expect(fs.stat(containingDirCid)).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    containingDirCid = await fs.cp(fileCid, containingDirCid, 'file-2.txt', {
      shardSplitThresholdBytes
    })

    await expect(fs.stat(containingDirCid)).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    containingDirCid = await fs.rm(containingDirCid, 'file-2.txt', {
      shardSplitThresholdBytes
    })

    await expect(fs.stat(containingDirCid)).to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    expect(containingDirCid).to.eql(importerCid)
  })

  it('results in the same hash as a sharded directory created by the importer when removing a sub-shard', async function () {
    const {
      containingDirCid,
      fileName,
      importerCid
    } = await createSubShardedDirectory(blockstore)

    await expect(fs.stat(importerCid))
      .to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    // remove the file that caused the sub-shard to be created and the CID should be the same as the importer
    const finalDirCid = await fs.rm(containingDirCid, fileName, {
      shardSplitThresholdBytes: 1
    })

    // should still be a shard
    await expect(fs.stat(finalDirCid))
      .to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    expect(finalDirCid).to.eql(importerCid, 'removing a file from the imported dir not result in the same CID')
  })

  it('results in the same hash as a sharded directory created by the importer when removing a sub-shard of a sub-shard', async function () {
    let {
      containingDirCid,
      fileName,
      importerCid
    } = await createSubShardedDirectory(blockstore, 2)

    await expect(fs.stat(importerCid))
      .to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    // remove the file that caused the sub-shard to be created and the CID should be the same as the importer
    containingDirCid = await fs.rm(containingDirCid, fileName, {
      shardSplitThresholdBytes: 1
    })

    await expect(fs.stat(containingDirCid))
      .to.eventually.have.nested.property('unixfs.type', 'hamt-sharded-directory')

    expect(containingDirCid).to.eql(importerCid)
  })

  it('results in the same hash as the importer when removing a subshard that leaves the only child as a subshard', async () => {
    const opts: any = {
      shardSplitThresholdBytes: 1,
      cidVersion: 1,
      rawLeaves: true
    }

    async function importDir (names: string[]): Promise<CID> {
      const files = names.map(n => ({ path: `dir/${n}`, content: new TextEncoder().encode(`content of ${n}\n`) }))
      let root: CID | undefined

      for await (const entry of fs.addAll(files, opts)) {
        if (entry.path === 'dir') {
          root = entry.cid
        }
      }

      if (root == null) {
        throw new Error('Nothing imported')
      }

      return root
    }

    // hash prefixes: other-190.txt 46 B8, file-174.txt 46 63 D5, file-308.txt 46 63 C5
    const before = await importDir(['other-190.txt', 'file-174.txt', 'file-308.txt'])
    const after = await fs.rm(before, 'other-190.txt', opts)
    const expected = await importDir(['file-174.txt', 'file-308.txt'])

    expect(after).to.deep.equal(expected)
  })

  it('refuses to rm missing blocks', async () => {
    const cid = await fs.addBytes(smallFile)

    await blockstore.delete(cid)
    expect(blockstore.has(cid)).to.be.false()

    await expect(fs.rm(cid, 'dir', {
      offline: true
    })).to.eventually.be.rejected
      .with.property('name', 'NotFoundError')
  })
})
