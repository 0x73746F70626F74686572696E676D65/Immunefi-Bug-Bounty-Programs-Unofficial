import { start, stop } from '@libp2p/interface'
import { Record } from '@libp2p/kad-dht'
import { expect } from 'aegir/chai'
import { Key } from 'interface-datastore'
import drain from 'it-drain'
import last from 'it-last'
import { CID } from 'multiformats/cid'
import Sinon from 'sinon'
import { toString as uint8ArrayToString } from 'uint8arrays/to-string'
import { IPNSEntry } from '../src/pb/ipns.ts'
import { createIPNSRecord } from '../src/records.ts'
import { decodeExtensibleData, encodeExtensibleData, ipnsRecordDataForV2Sig, multihashToIPNSRoutingKey } from '../src/utils.ts'
import { createIPNS } from './fixtures/create-ipns.ts'
import type { IPNS } from '../src/index.ts'
import type { Routing } from '@helia/interface'
import type { Keychain } from '@helia/interface'
import type { Datastore } from 'interface-datastore'
import type { StubbedInstance } from 'sinon-ts'

const cid = CID.parse('QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn')

describe('resolve', () => {
  let name: IPNS
  let customRouting: any
  let datastore: Datastore
  let heliaRouting: StubbedInstance<Routing>
  let keychain: Keychain

  beforeEach(async () => {
    const result = await createIPNS()
    name = result.name
    customRouting = result.customRouting
    heliaRouting = result.heliaRouting
    datastore = result.datastore
    keychain = result.keychain

    await start(name)
  })

  afterEach(async () => {
    await stop(name)
  })

  it('should resolve a record', async () => {
    const keyName = 'test-key'
    const { record, publicKey } = await name.publish(keyName, cid)

    // empty the datastore to ensure we resolve using the routing
    await drain(datastore.deleteMany(datastore.queryKeys({})))

    heliaRouting.get.resolves(IPNSEntry.encode(record))

    const result = await last(name.resolve(publicKey))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    expect(heliaRouting.get.called).to.be.true()
    expect(customRouting.get.called).to.be.true()
  })

  it('should resolve a record using a cid', async () => {
    const keyName = 'test-key'
    const { record, publicKey } = await name.publish(keyName, cid)

    // empty the datastore to ensure we resolve using the routing
    await drain(datastore.deleteMany(datastore.queryKeys({})))

    heliaRouting.get.resolves(IPNSEntry.encode(record))

    const result = await last(name.resolve(publicKey.toCID()))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    expect(heliaRouting.get.called).to.be.true()
    expect(customRouting.get.called).to.be.true()
  })

  it('should resolve a record offline', async () => {
    const keyName = 'test-key'
    const { publicKey } = await name.publish(keyName, cid)

    expect(heliaRouting.put.called).to.be.true()
    expect(customRouting.put.called).to.be.true()

    const result = await last(name.resolve(publicKey, {
      offline: true
    }))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    expect(heliaRouting.get.called).to.be.false()
    expect(customRouting.get.called).to.be.false()
  })

  it('should skip the local cache when resolving a record', async () => {
    const cachePutSpy = Sinon.spy(datastore, 'put')
    const cacheGetSpy = Sinon.spy(datastore, 'get')

    const keyName = 'test-key'
    const { record, publicKey } = await name.publish(keyName, cid)

    heliaRouting.get.resolves(IPNSEntry.encode(record))

    // @ts-ignore cannot access private localStore property
    const storeGetSpy = Sinon.spy(name.localStore, 'get')

    const result = await last(name.resolve(publicKey, {
      nocache: true
    }))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    // check that localStore.get not called
    expect(storeGetSpy.called).to.be.false()

    expect(heliaRouting.get.called).to.be.true()
    expect(customRouting.get.called).to.be.true()

    // we call `.get` during `.put`
    expect(cachePutSpy.calledBefore(cacheGetSpy)).to.be.true()
  })

  it('should retrieve from local cache when resolving a record', async () => {
    const cacheGetSpy = Sinon.spy(datastore, 'get')

    const keyName = 'test-key'
    const { publicKey } = await name.publish(keyName, cid)

    const result = await last(name.resolve(publicKey))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    expect(heliaRouting.get.called).to.be.false()
    expect(customRouting.get.called).to.be.false()
    expect(cacheGetSpy.called).to.be.true()
  })

  it('should resolve a recursive record', async () => {
    const keyName1 = 'key1'
    const keyName2 = 'key2'

    const { publicKey: publicKey2 } = await name.publish(keyName2, cid)
    const { publicKey: publicKey1 } = await name.publish(keyName1, publicKey2)

    const result = await last(name.resolve(publicKey1))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)
  })

  it('should resolve a recursive record with path', async () => {
    const keyName1 = 'key1'
    const keyName2 = 'key2'

    const { publicKey: publicKey2 } = await name.publish(keyName2, cid)
    const { publicKey: publicKey1 } = await name.publish(keyName1, publicKey2)

    const result = await last(name.resolve(publicKey1))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)
  })

  it('should emit progress events', async function () {
    const onProgress = Sinon.stub()
    const keyName = 'test-key'
    const { publicKey } = await name.publish(keyName, cid)

    await drain(name.resolve(publicKey, {
      onProgress
    }))

    expect(onProgress).to.have.property('called', true)
  })

  it('should cache a record', async function () {
    const key = await keychain.generateKey('test-key')
    const customRoutingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(customRoutingKey, 'base32'), false)

    expect(datastore.has(dhtKey)).to.be.false('already had record')

    const record = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 0n, 60000)
    const marshalledRecord = IPNSEntry.encode(record)

    customRouting.get.withArgs(customRoutingKey).resolves(marshalledRecord)

    const result = await last(name.resolve(key.publicKey))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    expect(datastore.has(dhtKey)).to.be.true('did not cache record locally')
  })

  it('should cache the most recent record', async function () {
    const key = await keychain.generateKey('test-key')
    const customRoutingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(customRoutingKey, 'base32'), false)

    const marshalledRecordA = IPNSEntry.encode(await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 0n, 60000))
    const marshalledRecordB = IPNSEntry.encode(await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 10n, 60000))

    // records should not match
    expect(marshalledRecordA).to.not.equalBytes(marshalledRecordB)

    // cache has older record
    await datastore.put(dhtKey, marshalledRecordA)
    customRouting.get.withArgs(customRoutingKey).resolves(marshalledRecordB)

    const result = await last(name.resolve(key.publicKey))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result.value).to.equal(`/ipfs/${cid.toV1()}`)

    const cached = await datastore.get(dhtKey)
    const record = Record.deserialize(cached)

    // should have cached the updated record
    expect(record.value).to.equalBytes(marshalledRecordB)
  })

  it('should include IPNS record in result', async () => {
    const keyName = 'test-key'
    const { record, publicKey } = await name.publish(keyName, cid)

    const result = await last(name.resolve(publicKey))

    if (result == null) {
      throw new Error('No results found')
    }

    expect(result).to.have.property('record')
    expect(IPNSEntry.encode(result.record)).to.equalBytes(IPNSEntry.encode(record))
  })

  it('should not search the routing for updated IPNS records when a locally cached copy is within the TTL', async () => {
    const key = await keychain.generateKey('test-key')
    const customRoutingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(customRoutingKey, 'base32'), false)

    // create a record with a valid lifetime and a non-expired TTL
    const ipnsRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 1, Math.pow(2, 10), {
      ttlNs: 10_000_000_000n
    })
    const dhtRecord = new Record(customRoutingKey, IPNSEntry.encode(ipnsRecord), new Date(Date.now()))

    await datastore.put(dhtKey, dhtRecord.serialize())

    const result = await last(name.resolve(key.publicKey))
    expect(result).to.have.deep.property('record', ipnsRecord)
    expect(result).to.have.property('value', `/ipfs/${cid.toV1()}`)

    // should not have searched the routing
    expect(customRouting.get.called).to.be.false('searched the routing for an updated record')
  })

  it('should search the routing for updated IPNS records when a locally cached copy has passed the TTL', async () => {
    const key = await keychain.generateKey('test-key')
    const routingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(routingKey, 'base32'), false)

    // create a record with a valid lifetime but an expired ttl
    const ipnsRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 1, Math.pow(2, 10), {
      ttlNs: 10n
    })
    const dhtRecord = new Record(routingKey, IPNSEntry.encode(ipnsRecord), new Date(Date.now() - 1000))

    await datastore.put(dhtKey, dhtRecord.serialize())

    const result = await last(name.resolve(key.publicKey))
    expect(result).to.have.deep.property('record', ipnsRecord)
    expect(result).to.have.property('value', `/ipfs/${cid.toV1()}`)

    // should have searched the routing
    expect(customRouting.get.called).to.be.true('did not search the routing for an updated record')
  })

  it('should search the routing for updated IPNS records when a locally cached copy has passed the TTL and choose the record with a higher sequence number', async () => {
    const key = await keychain.generateKey('test-key')
    const customRoutingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(customRoutingKey, 'base32'), false)

    // create a record with a valid lifetime but an expired ttl
    const ipnsRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 10, Math.pow(2, 10), {
      ttlNs: 10n
    })
    const dhtRecord = new Record(customRoutingKey, IPNSEntry.encode(ipnsRecord), new Date(Date.now() - 1000))

    await datastore.put(dhtKey, dhtRecord.serialize())

    // the routing returns a valid record with an higher sequence number
    const ipnsRecordFromRouting = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 11, Math.pow(2, 10), {
      ttlNs: 10_000_000n
    })
    customRouting.get.withArgs(customRoutingKey).resolves(IPNSEntry.encode(ipnsRecordFromRouting))

    const result = await last(name.resolve(key.publicKey))
    expect(result).to.have.deep.property('record', ipnsRecordFromRouting)

    // should have searched the routing
    expect(customRouting.get.called).to.be.true()
  })

  it('should search the routing when a locally cached copy has an expired lifetime', async () => {
    const key = await keychain.generateKey('test-key')
    const customRoutingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(customRoutingKey, 'base32'), false)

    // create a record with an expired lifetime but valid TTL
    const ipnsRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 10, -Math.pow(2, 10), {
      ttlNs: 10_000_000n
    })
    const dhtRecord = new Record(customRoutingKey, IPNSEntry.encode(ipnsRecord), new Date(Date.now()))

    await datastore.put(dhtKey, dhtRecord.serialize())

    // the routing returns a valid record with an higher sequence number
    const ipnsRecordFromRouting = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 11, Math.pow(2, 10), {
      ttlNs: 10_000_000n
    })
    customRouting.get.withArgs(customRoutingKey).resolves(IPNSEntry.encode(ipnsRecordFromRouting))

    const result = await last(name.resolve(key.publicKey))
    expect(result).to.have.deep.property('record', ipnsRecordFromRouting)

    // should have searched the routing
    expect(customRouting.get.called).to.be.true()
  })

  it('should return the network record without validating it when validate is false', async () => {
    const key = await keychain.generateKey('test-key')

    // the routing serves a record the validator would reject (expired lifetime)
    const expiredRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 1, -Math.pow(2, 10), {
      ttlNs: 10_000_000n
    })
    customRouting.get.resolves(IPNSEntry.encode(expiredRecord))
    heliaRouting.get.resolves(IPNSEntry.encode(expiredRecord))

    // with validate: false the expired record is returned as-is instead of throwing
    const result = await last(name.resolve(key.publicKey, { validate: false }))
    expect(result).to.have.deep.property('record', expiredRecord)
  })

  it('should return an expired cached record without validating or deleting it when validate is false', async () => {
    const key = await keychain.generateKey('test-key')
    const routingKey = multihashToIPNSRoutingKey(key.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(routingKey, 'base32'), false)

    // an expired-lifetime record (validation would reject it) with a valid TTL,
    // stored fresh so it is served from the cache within its TTL window
    const expiredRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 1, -Math.pow(2, 10), {
      ttlNs: 60n * 60n * 1_000_000_000n
    })
    const dhtRecord = new Record(routingKey, IPNSEntry.encode(expiredRecord), new Date())
    await datastore.put(dhtKey, dhtRecord.serialize())

    const result = await last(name.resolve(key.publicKey, { validate: false }))
    expect(result).to.have.deep.property('record', expiredRecord)

    // served from cache: the routing was not queried and the record was kept
    expect(customRouting.get.called).to.be.false('queried the routing')
    expect(await datastore.has(dhtKey)).to.be.true('deleted the cached record')
  })

  it('should throw when the routing has only records that fail validation', async () => {
    const key = await keychain.generateKey('test-key')

    // the routing serves a record that fails validation (expired lifetime)
    const invalidRecord = await createIPNSRecord(key, `/ipfs/${cid.toV1()}`, 1, -Math.pow(2, 10), {
      ttlNs: 10_000_000n
    })
    customRouting.get.resolves(IPNSEntry.encode(invalidRecord))
    heliaRouting.get.resolves(IPNSEntry.encode(invalidRecord))

    await expect(last(name.resolve(key.publicKey))).to.eventually.be.rejected
      .with.property('name', 'RecordsFailedValidationError')
  })

  it('should resolve a legacy record with CID bytes as the value', async () => {
    const privateKey = await keychain.generateKey('test-key')
    const routingKey = multihashToIPNSRoutingKey(privateKey.publicKey.toMultihash())
    const dhtKey = new Key('/dht/record/' + uint8ArrayToString(routingKey, 'base32'), false)

    const record = await createIPNSRecord(privateKey, '/ipns/will-be-overwritten', 10, 30_000)
    const data = decodeExtensibleData(record.data)
    data.Value = cid.bytes
    record.value = cid.bytes

    // re-sign record
    record.data = encodeExtensibleData(data)
    const sigData = ipnsRecordDataForV2Sig(record.data)
    record.signatureV2 = await privateKey.sign(sigData)

    const dhtRecord = new Record(routingKey, IPNSEntry.encode(record), new Date(Date.now()))
    await datastore.put(dhtKey, dhtRecord.serialize())

    const result = await last(name.resolve(privateKey.publicKey))
    expect(result).to.have.deep.property('record', record)
    expect(result).to.have.property('value', `/ipfs/${cid}`)
  })
})
