module github.com/ipfs/go-datastore

go 1.25.0

require (
	github.com/google/uuid v1.6.0
	github.com/ipfs/go-detect-race v0.0.1
	github.com/ipfs/go-ipfs-delay v0.0.1
	github.com/stretchr/testify v1.11.1
	go.opentelemetry.io/otel v1.44.0
	go.opentelemetry.io/otel/trace v1.44.0
)

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/otel/metric v1.44.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
