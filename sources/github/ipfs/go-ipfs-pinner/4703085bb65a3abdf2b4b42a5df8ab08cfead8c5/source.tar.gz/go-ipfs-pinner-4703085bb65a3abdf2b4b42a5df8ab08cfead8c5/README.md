# go-ipfs-pinner

[![](https://img.shields.io/badge/made%20by-Protocol%20Labs-blue.svg?style=flat-square)](https://protocol.ai)
[![](https://img.shields.io/badge/project-IPFS-blue.svg?style=flat-square)](http://ipfs.io/)
[![](https://img.shields.io/badge/freenode-%23ipfs-blue.svg?style=flat-square)](http://webchat.freenode.net/?channels=%23ipfs)
[![Coverage Status](https://codecov.io/gh/ipfs/go-ipfs-pinner/branch/master/graph/badge.svg)](https://codecov.io/gh/ipfs/go-ipfs-pinner)
[![Travis CI](https://travis-ci.org/ipfs/go-ipfs-pinner.svg?branch=master)](https://travis-ci.org/ipfs/go-ipfs-pinner)

## ❗ This repo is no longer maintained.
👉 We highly recommend switching to the maintained version at https://github.com/ipfs/boxo/tree/main/pinning/pinner.
🏎️ Good news!  There is [tooling and documentation](https://github.com/ipfs/boxo#migrating-to-boxo) to expedite a switch in your repo. 

⚠️ If you continue using this repo, please note that security fixes will not be provided (unless someone steps in to maintain it).

📚 Learn more, including how to take the maintainership mantle or ask questions, [here](https://github.com/ipfs/boxo/wiki/Copied-or-Migrated-Repos-FAQ).

## Background

The pinner system is responsible for keeping track of which objects a user wants to keep stored locally

## Install

Via `go get`:

```sh
$ go get github.com/ipfs/go-ipfs-pinner
```

> Requires Go 1.13

## Documentation

https://godoc.org/github.com/ipfs/go-ipfs-pinner

## License

This library is dual-licensed under Apache 2.0 and MIT terms.

Copyright 2019. Protocol Labs, Inc.
