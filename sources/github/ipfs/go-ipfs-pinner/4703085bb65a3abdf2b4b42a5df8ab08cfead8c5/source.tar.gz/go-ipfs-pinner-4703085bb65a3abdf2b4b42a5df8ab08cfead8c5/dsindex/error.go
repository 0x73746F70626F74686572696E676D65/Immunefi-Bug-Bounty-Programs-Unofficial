package dsindex

import "errors"

var (
	// Deprecated: use github.com/ipfs/boxo/pinning/pinner/dsindex.ErrEmptyKey
	ErrEmptyKey = errors.New("key is empty")
	// Deprecated: use github.com/ipfs/boxo/pinning/pinner/dsindex.ErrEmptyValue
	ErrEmptyValue = errors.New("value is empty")
)
