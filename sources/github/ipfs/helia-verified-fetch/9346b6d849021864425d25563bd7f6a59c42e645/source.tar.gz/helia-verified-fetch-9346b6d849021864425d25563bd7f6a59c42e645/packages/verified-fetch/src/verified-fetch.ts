import { dnsLink } from '@helia/dnslink'
import { ipnsResolver } from '@helia/ipns'
import { isPeerId, isPublicKey } from '@libp2p/interface'
import { CID } from 'multiformats/cid'
import { CustomProgressEvent } from 'progress-events'
import { MAX_HEADER_VALUE_LENGTH } from './constants.ts'
import { CarPlugin } from './plugins/plugin-handle-car.ts'
import { IpldPlugin } from './plugins/plugin-handle-ipld.ts'
import { IpnsRecordPlugin } from './plugins/plugin-handle-ipns-record.ts'
import { RawPlugin } from './plugins/plugin-handle-raw.ts'
import { TarPlugin } from './plugins/plugin-handle-tar.ts'
import { UnixFSPlugin } from './plugins/plugin-handle-unixfs.ts'
import { URLResolver } from './url-resolver.ts'
import { abbreviate, abbreviateAddress } from './utils/abbreviate.ts'
import { contentTypeParser } from './utils/content-type-parser.ts'
import { getContentType, getSupportedContentTypes, CONTENT_TYPE_OCTET_STREAM, MEDIA_TYPE_IPNS_RECORD, CONTENT_TYPE_IPNS } from './utils/content-types.ts'
import { errorToObject } from './utils/error-to-object.ts'
import { errorToResponse } from './utils/error-to-response.ts'
import { getETag, ifNoneMatches } from './utils/get-e-tag.ts'
import { getRangeHeader } from './utils/get-range-header.ts'
import { toIpfsUri } from './utils/ipfs-uri.ts'
import { stringToIpfsUrl } from './utils/parse-resource.ts'
import { setCacheControlHeader } from './utils/response-headers.ts'
import { notAcceptableResponse, notImplementedResponse, notModifiedResponse } from './utils/responses.ts'
import { ServerTiming } from './utils/server-timing.ts'
import { toXIpfsPath } from './utils/x-ipfs-path.ts'
import type { AcceptHeader, CIDDetail, ContentTypeParser, CreateVerifiedFetchOptions, Resource, ResourceDetail, VerifiedFetchInit as VerifiedFetchOptions, VerifiedFetchPlugin, PluginContext, PluginOptions } from './index.ts'
import type { DNSLink } from '@helia/dnslink'
import type { Helia } from '@helia/interface'
import type { IPNSResolver } from '@helia/ipns'
import type { AbortOptions, Logger } from '@libp2p/interface'

/**
 * Retypes the `.signal` property of the options from
 * `AbortSignal | null | undefined` to `AbortSignal | undefined`.
 */
function convertOptions (options?: VerifiedFetchOptions): (Omit<VerifiedFetchOptions, 'signal'> & AbortOptions) | undefined {
  if (options == null) {
    return
  }

  return {
    ...options,
    signal: options?.signal == null ? undefined : options?.signal
  }
}

/**
 * Returns true if the quest is only for an IPNS record
 */
function isIPNSRecordRequest (headers: Headers): boolean {
  const acceptHeaders = headers.get('accept')?.split(',') ?? []

  if (acceptHeaders.length !== 1) {
    return false
  }

  const mediaType = acceptHeaders[0].split(';')[0]

  return mediaType === MEDIA_TYPE_IPNS_RECORD
}

function truncate (obj?: any): string {
  return `${obj}`.substring(0, 10)
}

export class VerifiedFetch {
  private readonly helia: Helia
  private readonly ipnsResolver: IPNSResolver
  private readonly dnsLink: DNSLink
  private readonly log: Logger
  private readonly contentTypeParser: ContentTypeParser | undefined
  private readonly withServerTiming: boolean
  private readonly plugins: VerifiedFetchPlugin[] = []
  private readonly urlResolver: URLResolver

  constructor (helia: Helia, init: CreateVerifiedFetchOptions = {}) {
    this.helia = helia
    this.log = helia.logger.forComponent('helia:verified-fetch')
    this.ipnsResolver = init.ipnsResolver ?? ipnsResolver(helia)
    this.dnsLink = init.dnsLink ?? dnsLink(helia)
    this.contentTypeParser = init.contentTypeParser ?? contentTypeParser
    this.withServerTiming = init?.withServerTiming ?? false
    this.urlResolver = new URLResolver({
      ipnsResolver: this.ipnsResolver,
      dnsLink: this.dnsLink,
      helia: this.helia
    }, init)

    const pluginOptions: PluginOptions = {
      ...init,
      logger: helia.logger.forComponent('verified-fetch'),
      helia,
      contentTypeParser: this.contentTypeParser,
      ipnsResolver: this.ipnsResolver
    }

    const defaultPlugins = [
      new UnixFSPlugin(pluginOptions),
      new IpldPlugin(pluginOptions),
      new CarPlugin(pluginOptions),
      new TarPlugin(pluginOptions),
      new IpnsRecordPlugin(pluginOptions),
      new RawPlugin(pluginOptions)
    ]

    const customPlugins = init.plugins?.map((pluginFactory) => pluginFactory(pluginOptions)) ?? []

    if (customPlugins.length > 0) {
      // allow custom plugins to replace default plugins
      const defaultPluginMap = new Map(defaultPlugins.map(plugin => [plugin.id, plugin]))
      const customPluginMap = new Map(customPlugins.map(plugin => [plugin.id, plugin]))

      this.plugins = defaultPlugins.map(plugin => customPluginMap.get(plugin.id) ?? plugin)

      // add any custom plugins that don't replace default ones with a higher
      // priority than anything built-in
      this.plugins.unshift(...customPlugins.filter(plugin => !defaultPluginMap.has(plugin.id)))
    } else {
      this.plugins = defaultPlugins
    }
  }

  /**
   * Load a resource from the IPFS network and ensure the retrieved data is the
   * data that was expected to be loaded.
   *
   * Like [fetch](https://developer.mozilla.org/en-US/docs/Web/API/Window/fetch)
   * but verified.
   */
  async fetch (resource: Resource, opts?: VerifiedFetchOptions): Promise<Response> {
    this.log('fetch %s %s', opts?.method ?? 'GET', resource)

    // Create serverTiming outside try block so it's accessible in catch
    const serverTiming = new ServerTiming()
    const withServerTiming = Boolean(opts?.withServerTiming) || Boolean(this.withServerTiming)

    try {
      opts?.signal?.throwIfAborted()

      if (opts?.method === 'OPTIONS') {
        return this.handleFinalResponse(new Response(null, {
          status: 200
        }), withServerTiming, {
          serverTiming
        })
      }

      const options = convertOptions(opts)
      const headers = new Headers(options?.headers)

      if (options != null) {
        options.offline ??= headers.get('cache-control') === 'only-if-cached'
      }

      options?.onProgress?.(new CustomProgressEvent<ResourceDetail>('verified-fetch:request:start', { resource }))

      const range = getRangeHeader(resource, headers)

      if (range instanceof Response) {
        // invalid range request
        return this.handleFinalResponse(range, withServerTiming, {
          serverTiming
        })
      }

      let url: URL

      try {
        url = this.parseResource(resource)
      } catch (err: any) {
        return this.handleFinalResponse(errorToResponse(resource, err, opts), withServerTiming, {
          serverTiming
        })
      }

      if (url.protocol === 'ipfs:' && url.pathname === '') {
        // if we don't need to resolve an IPNS names or traverse a DAG, we can
        // check the if-none-match header and maybe return a 304 without needing
        // to load any blocks
        if (ifNoneMatches(`"${url.hostname}"`, headers)) {
          return this.handleFinalResponse(notModifiedResponse(resource, new Headers({
            etag: `"${url.hostname}"`,
            'cache-control': 'public, max-age=29030400, immutable'
          })), withServerTiming, {
            serverTiming
          })
        }
      }

      const requestedMimeTypes = getRequestedMimeTypes(url, headers.get('accept'))

      // if a raw IPNS record has been requested, don't try to load the block
      // the record points to or do any recursive IPNS resolving
      if (isIPNSRecordRequest(headers)) {
        if (url.protocol !== 'ipns:') {
          return notAcceptableResponse(url, requestedMimeTypes, [
            CONTENT_TYPE_IPNS
          ])
        }

        // @ts-expect-error ipnsRecordPlugin may not be of type IpnsRecordPlugin
        const ipnsRecordPlugin: IpnsRecordPlugin | undefined = this.plugins.find(plugin => plugin.id === 'ipns-record-plugin')

        if (ipnsRecordPlugin == null) {
          // IPNS record was requested but no IPNS Record plugin is configured?!
          return notAcceptableResponse(resource, requestedMimeTypes, [])
        }

        const context = {
          ...options,
          range,
          url,
          resource,
          redirected: false,
          serverTiming
        }

        // @ts-expect-error headers type is wrong
        return this.handleFinalResponse(await ipnsRecordPlugin.handle(context), withServerTiming, context)
      }

      const resolveResult = await this.urlResolver.resolve(url, serverTiming, options)

      if (resolveResult instanceof Response) {
        return this.handleFinalResponse(resolveResult, withServerTiming, {
          serverTiming
        })
      }

      options?.onProgress?.(new CustomProgressEvent<CIDDetail>('verified-fetch:request:resolve', {
        cid: resolveResult.terminalElement.cid,
        path: resolveResult.url.pathname
      }))

      const accept = this.getAcceptHeader(resolveResult.url, requestedMimeTypes, resolveResult.terminalElement.cid)

      if (accept instanceof Response) {
        this.log('allowed media types for requested CID did not contain anything the client can understand')

        // invalid accept header
        return this.handleFinalResponse(accept, withServerTiming, {
          serverTiming
        })
      }

      const routingTimers: Record<string, { start: number, found: number }> = {}
      const connectTimers: Record<string, { start: number, transport: string }> = {}
      const blockTimers: Record<string, number> = {}

      const context: PluginContext = {
        ...options,
        ...resolveResult,
        resource,
        accept,
        range,
        serverTiming,
        headers,
        requestedMimeTypes,
        onProgress: (evt) => {
          options?.onProgress?.(evt)

          if (evt.type === 'helia:routing:find-providers:start') {
            routingTimers[evt.detail.router] = {
              start: performance.now(),
              found: 0
            }
          } else if (evt.type === 'helia:routing:find-providers:provider') {
            if (routingTimers[evt.detail.router] == null) {
              return
            }

            routingTimers[evt.detail.router].found++

            serverTiming.add(abbreviate('found-provider'), `${abbreviate(evt.detail.router)},${truncate(evt.detail.provider.id)}`, performance.now() - routingTimers[evt.detail.router].start)
          } else if (evt.type === 'helia:routing:find-providers:end') {
            const routing = routingTimers[evt.detail.router]

            if (routing == null) {
              return
            }

            serverTiming.add(abbreviate('find-providers'), `${abbreviate(evt.detail.router)},${routing.found}`, performance.now() - routing.start)
          } else if (evt.type === 'helia:block-broker:connect') {
            connectTimers[`connect-${evt.detail.broker}-${evt.detail.provider}`] = {
              start: performance.now(),
              transport: ''
            }
          } else if (evt.type === 'helia:block-broker:connected') {
            const start = connectTimers[`connect-${evt.detail.broker}-${evt.detail.provider}`]

            if (start == null) {
              return
            }

            serverTiming.add(abbreviate('connect'), `${abbreviate(evt.detail.broker)},${truncate(evt.detail.provider)},${abbreviateAddress(evt.detail.address)}`, performance.now() - start.start)
          } else if (evt.type === 'helia:block-broker:request-block') {
            blockTimers[`block-${evt.detail.broker}-${evt.detail.cid}-${evt.detail.provider}`] = performance.now()
          } else if (evt.type === 'helia:block-broker:receive-block') {
            const start = blockTimers[`block-${evt.detail.broker}-${evt.detail.cid}-${evt.detail.provider}`]

            if (start == null) {
              return
            }

            serverTiming.add(abbreviate('block'), `${abbreviate(evt.detail.broker)},${truncate(evt.detail.provider)},${truncate(evt.detail.cid)}`, performance.now() - start)
          }
        }
      }

      this.log.trace('finding handler for cid code "0x%s" and response content types %s', resolveResult.terminalElement.cid.code.toString(16), accept.map(header => header.contentType.mediaType).join(', '))

      const response = await this.runPluginPipeline(context)

      options?.onProgress?.(new CustomProgressEvent<CIDDetail>('verified-fetch:request:end', {
        cid: resolveResult.terminalElement.cid,
        path: resolveResult.url.pathname
      }))

      if (response == null) {
        this.log.error('no plugin could handle request for %s', resource)
      }

      return this.handleFinalResponse(response, withServerTiming, context)
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        err.serverTiming = serverTiming.getHeader()
      }

      this.log.error('error fetching resource %s - %e', resource, err)

      try {
        return this.handleFinalResponse(errorToResponse(resource, err, opts), withServerTiming, {
          serverTiming
        })
      } catch (rethrowErr: any) {
        // Attach server timing to rethrown errors (e.g., AbortError)
        // so callers can access timing data even when the request was aborted
        const timingHeader = serverTiming.getHeader()
        if (timingHeader !== '') {
          rethrowErr.serverTiming = timingHeader
        }
        throw rethrowErr
      }
    }
  }

  /**
   * Returns a prioritized list of acceptable content types for the response
   * based on the CID and a passed `Accept` header
   */
  private getAcceptHeader (url: URL, requestedMimeTypes: RequestedMimeType[], cid?: CID): AcceptHeader[] | Response {
    const supportedContentTypes = getSupportedContentTypes(url.protocol, cid)
    const acceptable: AcceptHeader[] = []

    for (const headerFormat of requestedMimeTypes) {
      const [headerFormatType, headerFormatSubType] = headerFormat.mediaType.split('/')

      for (const contentType of supportedContentTypes) {
        const [contentTypeType, contentTypeSubType] = contentType.mediaType.split('/')

        if (headerFormat.mediaType.includes(contentType.mediaType)) {
          acceptable.push({
            contentType,
            options: headerFormat.options
          })
        }

        if (headerFormat.mediaType === '*/*') {
          acceptable.push({
            contentType,
            options: headerFormat.options
          })
        }

        if (headerFormat.mediaType.startsWith('*/') && contentTypeSubType === headerFormatSubType) {
          acceptable.push({
            contentType,
            options: headerFormat.options
          })
        }

        if (headerFormat.mediaType.endsWith('/*') && contentTypeType === headerFormatType) {
          acceptable.push({
            contentType,
            options: headerFormat.options
          })
        }
      }
    }

    if (acceptable.length === 0) {
      this.log('requested %o', requestedMimeTypes.map(({ mediaType }) => mediaType))
      this.log('supported %o', supportedContentTypes.map(({ mediaType }) => mediaType))

      return notAcceptableResponse(url, requestedMimeTypes, supportedContentTypes)
    }

    return acceptable
  }

  private parseResource (resource: Resource): URL {
    if (isPeerId(resource) || isPublicKey(resource)) {
      resource = `/ipns/${resource}`
    }

    if (CID.asCID(resource) === resource || resource instanceof CID) {
      resource = `/ipfs/${resource}`
    }

    return new URL(stringToIpfsUrl(resource.toString()))
  }

  /**
   * The last place a Response touches in verified-fetch before being returned
   * to the user. This is where we add the Server-Timing header to the response
   * if it has been collected. It should be used for any final processing of the
   * response before it is returned to the user.
   */
  private handleFinalResponse (response: Response, withServerTiming: boolean, context: Partial<PluginContext>): Response {
    const contentType = getContentType(response.headers.get('content-type')) ?? CONTENT_TYPE_OCTET_STREAM

    if (withServerTiming === true && context?.serverTiming != null) {
      const timingHeader = context?.serverTiming.getHeader()

      if (timingHeader !== '') {
        response.headers.set('server-timing', timingHeader)
      }
    }

    if (context?.url?.protocol != null && context.ttl != null) {
      setCacheControlHeader({
        response,
        ttl: context.ttl,
        expires: context.expires,
        protocol: context.url.protocol
      })
    }

    if (context?.terminalElement?.cid != null && context?.url != null) {
      const ipfsUri = toIpfsUri(context.url)

      // the value is ASCII-only so string length equals byte length; a value
      // of exactly MAX_HEADER_VALUE_LENGTH bytes is still sent
      if (ipfsUri != null && ipfsUri.length <= MAX_HEADER_VALUE_LENGTH) {
        try {
          response.headers.set('ipfs-uri', ipfsUri)
        } catch (err) {
          this.log.error('could not set ipfs-uri to "%s"', ipfsUri)
        }
      }

      // x-ipfs-path is deprecated by IPIP-0548 in favour of ipfs-uri, and is
      // kept for clients that still read it. It is omitted for content paths
      // that an HTTP field value cannot carry, e.g. a file name with
      // non-ASCII bytes
      const ipfsPath = toXIpfsPath(context.url)

      if (ipfsPath != null && ipfsPath.length <= MAX_HEADER_VALUE_LENGTH) {
        try {
          response.headers.set('x-ipfs-path', ipfsPath)
        } catch (err) {
          this.log.error('could not set x-ipfs-path to "%s"', ipfsPath)
        }
      }
    }

    // set CORS headers. If hosting your own gateway with verified-fetch behind
    // the scenes, you can alter these before you send the response to the
    // client.
    //
    // n.b. the values here must align with the conformance testing suite:
    // @see https://github.com/ipfs/gateway-conformance/blob/5106287edf36898b77fa5fac23f555638a16d778/tests/path_gateway_cors_test.go#L22-L34
    response.headers.set('access-control-allow-origin', '*')
    response.headers.set('access-control-allow-methods', 'GET, HEAD, OPTIONS')
    response.headers.set('access-control-allow-headers', 'Content-Type, Range, User-Agent, X-Requested-With')
    response.headers.set('access-control-expose-headers', 'Content-Range, Content-Length, Ipfs-Uri, X-Ipfs-Path, X-Ipfs-Roots, X-Chunked-Output, X-Stream-Output')

    if (context?.terminalElement?.cid != null && response.headers.get('etag') == null) {
      const etag = getETag({
        cid: context.terminalElement.cid,
        contentType,
        ranges: context?.range?.ranges
      })

      response.headers.set('etag', etag)

      if (ifNoneMatches(etag, context?.headers)) {
        return notModifiedResponse(response.url, response.headers)
      }
    }

    if (context?.method === 'HEAD') {
      // don't send the body for HEAD requests
      return new Response(null, {
        status: 200,
        headers: response.headers
      })
    }

    // make sure users are not expected to "download" error responses
    if (response.status > 399) {
      response.headers.delete('content-disposition')
    }

    return response
  }

  private async runPluginPipeline (context: PluginContext): Promise<Response> {
    let finalResponse: Response | undefined
    const pluginsUsed = new Set<string>()

    this.log.trace('checking which plugins can handle %c%s with accept %s', context.terminalElement.cid, context.url.pathname, context.accept.map(contentType => contentType.contentType.mediaType).join(', '))

    const plugins = this.plugins.filter(p => !pluginsUsed.has(p.id)).filter(p => p.canHandle(context))

    if (plugins.length === 0) {
      this.log.trace('no plugins found that can handle request; exiting pipeline')
      return notImplementedResponse(context.resource)
    }

    this.log.trace('plugins ready to handle request: %s', plugins.map(p => p.id).join(', '))

    // track if any plugin changed the context or returned a response
    const contextChanged = false
    let pluginHandled = false

    for (const plugin of plugins) {
      // try {
      this.log('invoking plugin: %s', plugin.id)
      pluginsUsed.add(plugin.id)

      const maybeResponse = await plugin.handle(context)

      this.log('plugin response %s %o', plugin.id, maybeResponse)

      if (maybeResponse != null) {
        // if a plugin returns a final Response, short-circuit
        finalResponse = maybeResponse
        pluginHandled = true
        break
      }

      if (finalResponse != null) {
        this.log.trace('plugin %s produced final response', plugin.id)
        break
      }

      if (pluginHandled && finalResponse != null) {
        break
      }

      if (!contextChanged) {
        this.log.trace('no context changes and no final response; exiting pipeline.')
        break
      }
    }

    return finalResponse ?? notImplementedResponse(context.resource, JSON.stringify({
      error: errorToObject(new Error('No verified fetch plugin could handle the request'))
    }), {
      headers: {
        'content-type': 'application/json'
      }
    })
  }

  /**
   * Start the Helia instance
   */
  async start (): Promise<void> {
    await this.helia.start()
  }

  /**
   * Shut down the Helia instance
   */
  async stop (): Promise<void> {
    await this.helia.stop()
  }
}

export interface RequestedMimeType {
  mediaType: string
  options: Record<string, string>
}

function getRequestedMimeTypes (url: URL, accept?: string | null): RequestedMimeType[] {
  if (accept == null || accept === '') {
    // yolo content-type
    accept = '*/*'
  }

  return accept
    .split(',')
    .map(s => {
      const parts = s.trim().split(';')

      const options: Record<string, string> = {
        q: '1'
      }

      for (let i = 1; i < parts.length; i++) {
        const [key, value] = parts[i].split('=').map(s => s.trim())

        options[key] = value
      }

      return {
        mediaType: `${parts[0]}`.trim(),
        options
      }
    })
    .sort((a, b) => {
      if (a.options.q === b.options.q) {
        return 0
      }

      if (a.options.q > b.options.q) {
        return -1
      }

      return 1
    })
}
