import { unixfs } from '@helia/unixfs'
import { stop } from '@libp2p/interface'
import { expect } from 'aegir/chai'
import { VerifiedFetch } from '../src/verified-fetch.ts'
import { createHelia } from './fixtures/create-offline-helia.ts'
import { getCustomPluginFactory } from './fixtures/get-custom-plugin-factory.ts'
import type { Helia } from '@helia/interface'
import type { CID } from 'multiformats/cid'

describe('plugins', () => {
  let helia: Helia
  let verifiedFetch: VerifiedFetch
  let cid: CID

  beforeEach(async () => {
    helia = await createHelia()

    const fs = unixfs(helia)
    cid = await fs.addBytes(new Uint8Array(10), {
      rawLeaves: false
    })
  })

  afterEach(async () => {
    await stop(helia, verifiedFetch)
  })

  it('can override existing plugins', async () => {
    verifiedFetch = new VerifiedFetch(helia, {
      plugins: [
        getCustomPluginFactory({
          id: 'unixfs-plugin',
          canHandle: () => true,
          handle: async () => new Response('Hello, world!')
        })
      ]
    })

    const response = await verifiedFetch.fetch(`ipfs://${cid}`)
    expect(response).to.be.instanceOf(Response)
    expect(response.status).to.equal(200)
    expect(await response.text()).to.equal('Hello, world!')
  })

  it('can shortcut the request pipeline with an error', async () => {
    verifiedFetch = new VerifiedFetch(helia, {
      plugins: [getCustomPluginFactory({
        id: 'my-custom-plugin',
        canHandle: () => true,
        handle: async () => {
          throw new Error('Something went wrong')
        }
      })]
    })

    const response = await verifiedFetch.fetch(`ipfs://${cid}`)
    expect(response).to.be.instanceOf(Response)
    expect(response.status).to.equal(500)
    expect(await response.text()).to.include('Something went wrong')
  })
/*
  it('should continue to the next plugin when null is returned', async () => {
    // Create one plugin that throws a non-fatal error and another that returns a valid response.
    const errorPlugin = getCustomPluginFactory({
      constructorName: 'ErrorPlugin',
      canHandle: () => true,
      handle: async () => {
        return null
      }
    })

    const finalPlugin = getCustomPluginFactory({
      constructorName: 'FinalPlugin',
      canHandle: () => true,
      handle: async () => new Response('Final result', { status: 200 })
    })

    verifiedFetch = new VerifiedFetch(helia, { plugins: [errorPlugin, finalPlugin] })

    const response = await verifiedFetch.fetch(`ipfs://${cid}`)
    expect(response).to.be.instanceOf(Response)
    expect(response.status).to.equal(200)
    expect(await response.text()).to.equal('Final result')
  })

  it('should perform multiple passes when context is updated', async () => {
    const updaterPlugin = getCustomPluginFactory({
      constructorName: 'UpdaterPlugin',
      canHandle: (context: any) => context.processed !== true,
      handle: async (context: any) => {
        // Simulate partial work: update the context and its "modified" property.
        context.processed = true
        context.modified = (context.modified ?? 0) + 1

        return null
      }
    })

    const finalPlugin = getCustomPluginFactory({
      constructorName: 'FinalPlugin',
      // custom context property "processed" is set to true by the updaterPlugin.
      canHandle: (context: any) => context.processed === true,
      handle: async (context) => new Response('Processed!', { status: 200 })
    })

    verifiedFetch = new VerifiedFetch(helia, {
      plugins: [
        updaterPlugin,
        finalPlugin
      ]
    })

    const response = await verifiedFetch.fetch('ipfs://bafyaaaa')
    expect(response).to.be.instanceOf(Response)
    expect(response.status).to.equal(200)
    expect(await response.text()).to.equal('Processed!')
  })

  it('should not call the same plugin twice in a single pipeline run', async () => {
    // Create a plugin that counts its invocations.
    let invocationCount = 0
    const singleCallPlugin = getCustomPluginFactory({
      constructorName: 'SingleCallPlugin',
      canHandle: () => true,
      handle: async (context) => {
        invocationCount++
        context.modified = (context.modified ?? 0) + 1
        return null
      }
    })

    verifiedFetch = new VerifiedFetch(helia, {
      plugins: [
        singleCallPlugin
      ]
    })

    // Call fetch. The runPluginPipeline should add the plugin's name to the used set,
    // ensuring it is not invoked more than once.
    await verifiedFetch.fetch(`ipfs://${cid}`)
    expect(invocationCount).to.equal(1)
  })

  it('should exit pipeline after maxPasses if no plugin produces a response', async () => {
    // create a few plugins that do nothing
    let iteration = 0
    const loopingPlugins = Array.from({ length: 5 }, (_, i) => getCustomPluginFactory({
      constructorName: `LoopingPlugin${i}`,
      canHandle: () => {
        return i === iteration
      },
      handle: async (context) => {
        iteration++
        context.modified = (context.modified ?? 0) + 1
        return null
      }
    }))

    verifiedFetch = new VerifiedFetch(helia, { plugins: loopingPlugins })

    // With no final response produced after max passes, the fetch method should
    // return a notSupportedResponse (or similar). The content we're requesting
    // here is dag-pb and a dag-cbor accept header, is unsupported
    const response = await verifiedFetch.fetch(`ipfs://${cid}`, {
      headers: {
        accept: 'application/vnd.ipld.dag-cbor'
      }
    })

    expect(response).to.be.instanceOf(Response)
    expect(response.status).to.equal(501)
    expect(iteration).to.equal(3)
  })
    */
})
