module github.com/ipfs/go-ipfs-delay

go 1.25
