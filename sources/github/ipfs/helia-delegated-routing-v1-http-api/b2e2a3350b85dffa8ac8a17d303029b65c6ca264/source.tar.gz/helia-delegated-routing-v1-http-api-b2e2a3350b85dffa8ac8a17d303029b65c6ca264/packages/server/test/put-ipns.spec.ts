import { createIPNSRecord, IPNSEntry, multihashToIPNSRoutingKey } from '@helia/ipns'
import { ed25519Crypto } from '@ipshipyard/crypto'
import { keychain } from '@ipshipyard/keychain'
import { expect } from 'aegir/chai'
import { MemoryDatastore } from 'datastore-core'
import { CID } from 'multiformats'
import { stubInterface } from 'sinon-ts'
import { withArrayBuffer } from 'uint8arrays/with-array-buffer'
import { createDelegatedRoutingV1HttpApiServer } from '../src/index.ts'
import { getCrypto } from './fixtures/get-crypto.ts'
import type { Helia } from '@helia/interface'
import type { FastifyInstance } from 'fastify'
import type { StubbedInstance } from 'sinon-ts'

describe('put IPNS', () => {
  let helia: StubbedInstance<Helia>
  let server: FastifyInstance
  let url: URL

  beforeEach(async () => {
    const datastore = new MemoryDatastore()
    helia = stubInterface<Helia>({
      keychain: keychain()({
        datastore,
        getCrypto
      })
    })
    server = await createDelegatedRoutingV1HttpApiServer(helia, {
      listen: {
        host: '127.0.0.1',
        port: 0
      }
    })

    const address = server.server.address()
    const port = typeof address === 'string' ? address : address?.port

    expect(port).to.be.a('number')

    url = new URL(`http://127.0.0.1:${port}`)
  })

  afterEach(async () => {
    if (server != null) {
      await server.close()
    }
  })

  it('PUT ipns puts record', async () => {
    const privateKey = await ed25519Crypto().generatePrivateKey()
    const cid = CID.parse('bafkreifjjcie6lypi6ny7amxnfftagclbuxndqonfipmb64f2km2devei4')
    const record = await createIPNSRecord(privateKey, `/ipfs/${cid}`, 0, 1000)
    const marshalledRecord = IPNSEntry.encode(record)

    let putKey: Uint8Array = new Uint8Array()
    let putValue: Uint8Array = new Uint8Array()

    helia.routing.put = async function (key: Uint8Array, value: Uint8Array) {
      putKey = key
      putValue = value
    }

    const res = await fetch(`${url}routing/v1/ipns/${privateKey.publicKey.toCID()}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/vnd.ipfs.ipns-record'
      },
      body: withArrayBuffer(marshalledRecord)
    })

    expect(res.status).to.equal(200)
    expect(putKey).to.equalBytes(multihashToIPNSRoutingKey(privateKey.publicKey.toMultihash()))
    expect(putValue).to.equalBytes(marshalledRecord)
  })
})
