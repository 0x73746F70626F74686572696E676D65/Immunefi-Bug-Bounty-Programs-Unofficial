import { ed25519Crypto } from '@ipshipyard/crypto'
import { multiaddr } from '@multiformats/multiaddr'
import { expect } from 'aegir/chai'
import { base58btc } from 'multiformats/bases/base58'
import { stubInterface } from 'sinon-ts'
import { createDelegatedRoutingV1HttpApiServer } from '../src/index.ts'
import type { Helia } from '@helia/interface'
import type { FastifyInstance } from 'fastify'
import type { StubbedInstance } from 'sinon-ts'

describe('get peers', () => {
  let helia: StubbedInstance<Helia>
  let server: FastifyInstance
  let url: URL

  beforeEach(async () => {
    helia = stubInterface<Helia>()
    server = await createDelegatedRoutingV1HttpApiServer(helia, {
      listen: {
        host: '127.0.0.1',
        port: 0
      }
    })

    const address = server.server.address()
    const port = typeof address === 'string' ? address : address?.port

    expect(port).to.be.a('number')

    url = new URL(`http://127.0.0.1:${port}`)
  })

  afterEach(async () => {
    if (server != null) {
      await server.close()
    }
  })

  it('GET peers returns 422 if peer id is not cid', async () => {
    const privateKey = await ed25519Crypto().generatePrivateKey()

    const res = await fetch(`${url}routing/v1/peers/${base58btc.baseEncode(privateKey.publicKey.toMultihash().bytes)}`, {
      method: 'GET'
    })

    expect(res.status).to.equal(422)
  })

  it('GET peers returns 422 if cid is not peer id', async () => {
    const res = await fetch(`${url}routing/v1/peers/bafkreifjjcie6lypi6ny7amxnfftagclbuxndqonfipmb64f2km2devei4`, {
      method: 'GET'
    })

    expect(res.status).to.equal(422)
  })

  it('GET peers returns peer records for get peers', async () => {
    const privateKey = await ed25519Crypto().generatePrivateKey()
    const peer = {
      id: privateKey.publicKey.toCID(),
      multiaddrs: [
        multiaddr('/ip4/123.123.123.123/tcp/123')
      ],
      router: 'test'
    }

    helia.routing.findPeer = async function () {
      return peer
    }

    const res = await fetch(`${url}routing/v1/peers/${peer.id}`, {
      method: 'GET'
    })
    expect(res.status).to.equal(200)

    const json = await res.json()
    expect(json).to.have.nested.property('Peers[0].Schema', 'peer')
    expect(json).to.have.nested.property('Peers[0].ID', base58btc.baseEncode(peer.id.multihash.bytes))
    expect(json).to.have.deep.nested.property('Peers[0].Addrs', peer.multiaddrs.map(ma => ma.toString()))
  })

  it('GET peers returns 200 with empty array if peer is not found', async () => {
    const privateKey = await ed25519Crypto().generatePrivateKey()

    helia.routing.findPeer = async function () {
      const error = new Error('Not found')
      // @ts-expect-error - code property not on Error
      error.code = 'ERR_NOT_FOUND'
      throw error
    }

    const res = await fetch(`${url}routing/v1/peers/${privateKey.publicKey.toCID()}`, {
      method: 'GET'
    })
    expect(res.status).to.equal(200)

    const json = await res.json()
    expect(json).to.have.property('Peers').that.is.an('array').with.lengthOf(0)
  })

  it('GET peers returns 200 with empty NDJSON if peer is not found when streaming', async () => {
    const privateKey = await ed25519Crypto().generatePrivateKey()

    helia.routing.findPeer = async function () {
      const error = new Error('Not found')
      // @ts-expect-error - code property not on Error
      error.code = 'ERR_NOT_FOUND'
      throw error
    }

    const res = await fetch(`${url}routing/v1/peers/${privateKey.publicKey.toCID()}`, {
      method: 'GET',
      headers: {
        accept: 'application/x-ndjson'
      }
    })
    expect(res.status).to.equal(200)

    const text = await res.text()
    expect(text).to.equal('')
  })
})
