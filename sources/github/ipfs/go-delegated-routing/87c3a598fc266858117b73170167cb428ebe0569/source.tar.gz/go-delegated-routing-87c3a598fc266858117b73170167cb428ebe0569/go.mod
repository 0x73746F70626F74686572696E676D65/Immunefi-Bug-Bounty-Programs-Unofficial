module github.com/ipfs/go-delegated-routing

go 1.18

require (
	github.com/ipfs/boxo v0.8.0-rc1
	github.com/ipfs/go-cid v0.4.0
	github.com/ipfs/go-log/v2 v2.5.1
	github.com/ipld/edelweiss v0.2.0
	github.com/ipld/go-ipld-prime v0.20.0
	github.com/libp2p/go-libp2p v0.26.3
	github.com/libp2p/go-libp2p-record v0.2.0
	github.com/multiformats/go-multiaddr v0.8.0
	github.com/multiformats/go-multicodec v0.8.1
	github.com/multiformats/go-multihash v0.2.1
	github.com/polydawn/refmt v0.89.0
	go.opencensus.io v0.24.0
)

require (
	github.com/decred/dcrd/dcrec/secp256k1/v4 v4.1.0 // indirect
	github.com/gogo/protobuf v1.3.2 // indirect
	github.com/klauspost/cpuid/v2 v2.2.3 // indirect
	github.com/libp2p/go-buffer-pool v0.1.0 // indirect
	github.com/mattn/go-isatty v0.0.17 // indirect
	github.com/minio/sha256-simd v1.0.0 // indirect
	github.com/mr-tron/base58 v1.2.0 // indirect
	github.com/multiformats/go-base32 v0.1.0 // indirect
	github.com/multiformats/go-base36 v0.2.0 // indirect
	github.com/multiformats/go-multibase v0.1.1 // indirect
	github.com/multiformats/go-multistream v0.4.1 // indirect
	github.com/multiformats/go-varint v0.0.7 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/spaolacci/murmur3 v1.1.0 // indirect
	go.uber.org/atomic v1.10.0 // indirect
	go.uber.org/multierr v1.9.0 // indirect
	go.uber.org/zap v1.24.0 // indirect
	golang.org/x/crypto v0.6.0 // indirect
	golang.org/x/sys v0.6.0 // indirect
	google.golang.org/protobuf v1.28.1 // indirect
	lukechampine.com/blake3 v1.1.7 // indirect
)
