import { readFile } from 'fs/promises'
import { readFileSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

import { create } from 'kubo-rpc-client'
import { CID } from 'multiformats/cid'
import * as dagPb from '@ipld/dag-pb'
import { sha256 } from 'multiformats/hashes/sha2'

import { test, expect } from './setup/coverage.js'
import { explore } from './setup/locators.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

/**
 * @template {number} Code
 * @param {any} value
 * @param {import('multiformats/block').BlockEncoder<Code, any>} codec
 * @param {import('multiformats/hashes/interface').MultihashHasher<Code>} hasher
 * @param {import('multiformats/cid').Version} version
 * @returns {Promise<CID | null>}
 */
const createCID = async (value, codec, hasher, version = 1) => {
  try {
    const digest = await hasher.digest(codec.encode(value))
    return CID.create(version, codec.code, digest)
  } catch (err) {
    console.log('Failed to create CID', value, err)
    return null
  }
}

/**
 * Fills out the explore form (optional), waits for CID of given type to be loaded, and checks if CID details are correct.
 * @param {object} options
 * @param {import('playwright').Page} options.page
 * @param {string} options.cid
 * @param {string} options.type
 * @param {string} [options.humanReadableCID]
 * @param {boolean} [options.fillOutForm]
 */
async function testExploredCid ({ cid, type, humanReadableCID, page, fillOutForm = true }) {
  if (fillOutForm) {
    await explore.cidInput(page).fill(cid)
    await expect(explore.inspectButton(page)).toBeEnabled()
    await explore.inspectButton(page).press('Enter')
  }

  // wait for cid to be displayed in the CID INFO section
  await expect(page.locator(`.joyride-explorer-cid [title="${cid}"]`)).toBeVisible()
  await expect(page.locator(`[title="${type}"]`)).toBeVisible()

  if (humanReadableCID != null) {
    // expect cid details
    const humanReadableElement = explore.humanReadableCid(page)
    await expect(humanReadableElement).toBeVisible()
    await expect(humanReadableElement).toHaveText(humanReadableCID)
  }
}

/**
 * Loads saved block fixtures from fixtures/explore/blocks and adds them locally to the ipfs node
 * @param {object} param0
 * @param {import('kubo-rpc-client').KuboRPCClient} param0.ipfs
 * @param {string|string[]} param0.blockCid
 * @param {object} [param0.blockPutArgs]
 */
async function loadBlockFixtures ({ ipfs, blockCid, blockPutArgs = { format: 'v0' } }) {
  try {
    if (Array.isArray(blockCid)) {
      return await Promise.all(blockCid.map(cid => loadBlockFixtures({ ipfs, blockCid: cid, blockPutArgs })))
    }
    // read the data from the file
    const data = await readFile(join(__dirname, '/fixtures/explore/blocks', blockCid), { encoding: '' })
    // add the data to the ipfs node
    const result = await ipfs.block.put(data, blockPutArgs)
    // check that the CID returned from block.put matches the given block fixture CID
    expect(result.toString()).toBe(blockCid)
  } catch (e) {
    console.error(e)
  }
}

// Inlined CIDs that work without network retrieval (identity multihash)
const INLINED_HELLO_WORLD_CID = 'bafkqac3imvwgy3zao5xxe3de' // "hello world"

test.describe('Explore screen', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/#/explore')
    // wait for connection indicator (teal = connected)
    await expect(explore.connectionIndicator(page)).toBeVisible()
  })

  test.describe('CID/path input bar', () => {
    test('Inspect button opens DAG Explorer and shows Raw Block', async ({ page }) => {
      // enter the inlined "hello world" CID in the explore form
      await explore.cidInput(page).fill(INLINED_HELLO_WORLD_CID)
      await expect(explore.inspectButton(page)).toBeEnabled()
      await explore.inspectButton(page).click()

      // should navigate to Explore screen with the CID
      await page.waitForURL(`/#/explore/${INLINED_HELLO_WORLD_CID}`)

      // should display "Raw Block" type in DAG Explorer
      await expect(page.getByText('Raw Block')).toBeVisible()

      // should display the CID in CID INFO section
      await expect(page.locator(`.joyride-explorer-cid [title="${INLINED_HELLO_WORLD_CID}"]`)).toBeVisible()
    })
  })

  test.describe('Start Exploring', () => {
    test('should have Project Apollo Archive as one of examples', async ({ page }) => {
      await expect(page.locator('a[href="#/explore/QmSnuWmxptJZdLJpKRarxBMS2Ju2oANVrgbr2xWbie9b2D"]')).toBeVisible()
      await expect(page.getByText('Project Apollo Archives')).toBeVisible()
      await expect(page.getByText('QmSnuWmxptJZdLJpKRarxBMS2Ju2oANVrgbr2xWbie9b2D')).toBeVisible()
    })
  })

  test.describe('Inspecting CID', () => {
    /**
     * @type {ReturnType<import('kubo-rpc-client')['create']>}
     */
    let ipfs
    test.beforeEach(async () => {
      ipfs = create(process.env.IPFS_RPC_ADDR)
    })

    test('should open raw CID', async ({ page }) => {
      // add a local file to repo so test is fast and works in offline mode
      const cid = 'bafkreicgkmwhdunxgdqwqveecdo3wqmgulb4azm6sfnrtvd7g47mnrixji'
      const expectedData = readFileSync(join(__dirname, '../../LICENSE'), 'utf8')
      const result = await ipfs.add(expectedData, { cidVersion: 1 })
      await expect(result.cid.toString()).toStrictEqual(cid)

      await testExploredCid({
        cid,
        page,
        type: 'raw',
        humanReadableCID: 'base32 - cidv1 - raw - sha2-256~256~46532C71D1B730E168548410DDBB4186A2C3C0659E915B19D47F373EC6C5174A'
      })
    })

    test('should open dag-pb', async ({ page }) => {
      test.setTimeout(60000)
      const cidData = new Uint8Array(Buffer.from('hello world'))
      const dagPbAsDagJson = {
        Data: cidData,
        Links: []
      }
      const cid = await createCID(dagPbAsDagJson, dagPb, sha256, 0) // QmU1Sq1B7RPQD2XcQNLB58qJUyJffVJqihcxmmN1STPMxf

      // add bytes to backend node so that explore page can load the content
      const cidInstance = await ipfs.dag.put(dagPbAsDagJson, {
        storeCodec: 'dag-pb',
        hashAlg: 'sha2-256'
      })
      const dagPbCid = cidInstance.toString() // bafybeicuhktpnonfgpel7acwqcim34slne5kul43k5fdg6cnqrrp3rkxtq

      await testExploredCid({
        page,
        cid: cid.toString(),
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~543AA6F6B9A533C8BF80568090CDF24B693AAA2F9B574A33784D8462FDC5579C',
        type: 'dag-pb'
      })

      await testExploredCid({
        page,
        cid: dagPbCid,
        humanReadableCID: 'base32 - cidv1 - dag-pb - sha2-256~256~543AA6F6B9A533C8BF80568090CDF24B693AAA2F9B574A33784D8462FDC5579C',
        type: 'dag-pb'
      })
    })

    test('should open dag-cbor cid', async ({ page }) => {
      const type = 'dag-cbor'
      const cid = 'bafyreicds4picvqi46ljgw2eombkoifaftyjgd4abvfvledghftn2xnena'

      await loadBlockFixtures({
        ipfs,
        blockCid: [
          cid
        ],
        blockPutArgs: {
          storeCodec: type,
          format: type,
          version: 1,
          hashAlg: 'sha2-256'
        }
      })

      await testExploredCid({
        page,
        cid,
        humanReadableCID: 'base32 - cidv1 - dag-cbor - sha2-256~256~43971E815608E796935B447302A720A02CF0930F800D4B5590663966DD5DA468',
        type
      })
    })

    test('should open dag-pb unixFS XKCD Archives', async ({ page }) => {
      test.setTimeout(120000)
      await loadBlockFixtures({
        ipfs,
        blockCid: [
          'QmdmQXB2mzChmMeKY47C43LxUdg1NDJ5MWcKMKxDu7RgQm',
          'QmbQDovX7wRe9ek7u6QXe9zgCXkTzoUSsTFJEkrYV1HrVR',
          'QmawceGscqN4o8Y8Fv26UUmB454kn2bnkXV5tEQYc4jBd6'
        ]
      })

      await testExploredCid({
        page,
        cid: 'QmdmQXB2mzChmMeKY47C43LxUdg1NDJ5MWcKMKxDu7RgQm',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~E536C7F88D731F374DCCB568AFF6F56E838A19382E488039B1CA8AD2599E82FE',
        type: 'dag-pb'
      })
      await expect(page.getByText('UnixFS')).toBeVisible()

      await page.getByText('QmbQDovX7wRe9ek7u6QXe9zgCXkTzoUSsTFJEkrYV1HrVR').click()
      await testExploredCid({
        fillOutForm: false,
        page,
        cid: 'QmbQDovX7wRe9ek7u6QXe9zgCXkTzoUSsTFJEkrYV1HrVR',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~C212195DE60CE9B899EFDB2830101B16556018A24C7428E32198FAAB9D493F94',
        type: 'dag-pb'
      })

      await page.getByText('QmawceGscqN4o8Y8Fv26UUmB454kn2bnkXV5tEQYc4jBd6').click()
      await testExploredCid({
        fillOutForm: false,
        page,
        cid: 'QmawceGscqN4o8Y8Fv26UUmB454kn2bnkXV5tEQYc4jBd6',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~BB413C3DE0BA745523A3D701D6CB4283BCA7E187EC21556F4456036F692A5075',
        type: 'dag-pb'
      })
    })

    test('should explore Project Apollo Archive', async ({ page }) => {
      test.setTimeout(240000)
      await loadBlockFixtures({
        ipfs,
        blockCid: [
          'QmSnuWmxptJZdLJpKRarxBMS2Ju2oANVrgbr2xWbie9b2D',
          'QmeQtZfwuq6aWRarY9P3L9MWhZ6QTonDe9ahWECGBZjyEJ',
          'QmVmf9vLEdWeBjh74kTibHVkim6iLsRXs5jhHzbSdWjoLt',
          'QmT4hPa6EeeCaTAb4a6ddFf4Lk5da9C1f4nMBmMJgbAW3z',
          'QmZA6h4vP17Ktw5vyMdSQNTvzsncQKDSifYwJznY461rY2',
          'QmR2pm6hPxv7pEgNaPE477rVBNSZnbUgXsSn2R9RqK9tAH'
        ]
      })

      await testExploredCid({
        page,
        cid: 'QmSnuWmxptJZdLJpKRarxBMS2Ju2oANVrgbr2xWbie9b2D',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~422896A1CE82A7B1CC0BA27C7D8DE2886C7DF95588473D5E88A28A9FCFA0E43E',
        type: 'dag-pb'
      })

      await page.getByText('QmeQtZfwuq6aWRarY9P3L9MWhZ6QTonDe9ahWECGBZjyEJ').click()
      await testExploredCid({
        page,
        cid: 'QmeQtZfwuq6aWRarY9P3L9MWhZ6QTonDe9ahWECGBZjyEJ',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~EED0FABF56CC4483BD066183A55EDC7817D3549C394C1967521B35AAC9D51FF3',
        type: 'dag-pb',
        fillOutForm: false
      })

      await page.getByText('QmVmf9vLEdWeBjh74kTibHVkim6iLsRXs5jhHzbSdWjoLt').click()
      await testExploredCid({
        page,
        cid: 'QmVmf9vLEdWeBjh74kTibHVkim6iLsRXs5jhHzbSdWjoLt',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~6E69D4FA6F373B9DAC05974C31CAE53A8F39A0C67A6895CAC1DD2B274C079B19',
        type: 'dag-pb',
        fillOutForm: false
      })

      await page.getByText('QmT4hPa6EeeCaTAb4a6ddFf4Lk5da9C1f4nMBmMJgbAW3z').click()
      await testExploredCid({
        page,
        cid: 'QmT4hPa6EeeCaTAb4a6ddFf4Lk5da9C1f4nMBmMJgbAW3z',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~46342C25ED0D9CA0BCB2350DB258941A08BDFC0064E824FE39FBEB2171D604E9',
        type: 'dag-pb',
        fillOutForm: false
      })

      await page.getByText('QmZA6h4vP17Ktw5vyMdSQNTvzsncQKDSifYwJznY461rY2').click()
      await testExploredCid({
        page,
        cid: 'QmZA6h4vP17Ktw5vyMdSQNTvzsncQKDSifYwJznY461rY2',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~A0BC8B9BA2A4F6A91311F259A648F259723F7C6E13061E42462FC15FE6E1CA5B',
        type: 'dag-pb',
        fillOutForm: false
      })

      await page.getByText('QmR2pm6hPxv7pEgNaPE477rVBNSZnbUgXsSn2R9RqK9tAH').click()
      await testExploredCid({
        page,
        cid: 'QmR2pm6hPxv7pEgNaPE477rVBNSZnbUgXsSn2R9RqK9tAH',
        humanReadableCID: 'base58btc - cidv0 - dag-pb - sha2-256~256~2801F8B9FF4924F0938CBAF0F53B43E68088DBE272C6905C8D7AAA21A67102A6',
        type: 'dag-pb',
        fillOutForm: false
      })
    })
  })
})
