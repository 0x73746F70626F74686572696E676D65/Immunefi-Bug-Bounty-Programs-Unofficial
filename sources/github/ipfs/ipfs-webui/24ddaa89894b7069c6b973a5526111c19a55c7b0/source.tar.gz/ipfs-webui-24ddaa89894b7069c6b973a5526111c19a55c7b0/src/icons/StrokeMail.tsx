import React from 'react'
import type { SVGProps } from 'react'
const SvgStrokeMail = (props: SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" {...props}>
        <path d="M77.34 24.44H23.59c-4.43 0-8.77 4.33-8.77 8.75v34.4c0 4.25 4.1 8 8.77 8h53.75a7.82 7.82 0 0 0 7.84-8v-34.4c0-4.19-3.18-8.75-7.84-8.75m-53.75 3h53.75a4.64 4.64 0 0 1 3.75 2.25L49.87 57.83 19.58 29.38a5.77 5.77 0 0 1 4.01-1.94m-5.77 40.15v-34.4a4.8 4.8 0 0 1 .59-2.19l21 19.75L20 71.34a4.83 4.83 0 0 1-2.18-3.75m5.77 5a5.7 5.7 0 0 1-1.74-.28l19-20.13 8.94 8.4L59 52.27l19.37 20.18a5 5 0 0 1-1 .11zm58.59-5a5.13 5.13 0 0 1-1.89 4L60.51 50.93 82 31.6a6.2 6.2 0 0 1 .22 1.59z" />
    </svg>
)
export default SvgStrokeMail
