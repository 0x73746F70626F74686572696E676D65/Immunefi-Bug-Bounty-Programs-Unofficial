---
name: Translations, typos, localization
about: Please use Transifex! https://explore.transifex.com/ipfs/
title: ''
labels: need/triage
assignees: ''

---

Thank you for caring about localization! You are a good person.

We use [transifex.com](https://explore.transifex.com/ipfs/) to manage translations. **Please don't edit the locale files directly.**

- Go to https://explore.transifex.com/ipfs/
- Select languages can help with
- Start translating!

Once most of the text for the app is translated into a new language, the locale files are generated and added to this repo automatically.

Please [open an issue](https://github.com/ipfs/ipfs-webui/issues/new) if you'd like to help translate but something is not clear.

See https://github.com/ipfs/i18n for more information.
