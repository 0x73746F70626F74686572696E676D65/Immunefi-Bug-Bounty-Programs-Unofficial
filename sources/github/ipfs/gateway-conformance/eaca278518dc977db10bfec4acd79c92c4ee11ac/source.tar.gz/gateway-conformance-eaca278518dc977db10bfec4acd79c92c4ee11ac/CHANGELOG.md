# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
### Added

### Changed

### Fixed

## [0.14.1] - 2026-08-27
### Added
- New `TestUnixFSPBNodeFieldOrder` and `TestTrustlessRawPBNodeFieldOrder` tests covering both PBNode field orders: the streaming-friendly `Data`-before-`Links` order proposed in [IPIP-550](https://github.com/ipfs/specs/pull/550), and the legacy `Links`-before-`Data` order. Path resolution must work through UnixFS directories and HAMT shards in either encoding, and raw block responses must return the stored bytes verbatim without re-encoding to a preferred order. Backed by the new `pbnode-field-orders.car` fixture, byte-identical to the IPIP-550 fixtures table.

## [0.14.0] - 2026-08-27
### Added
- New `TestGatewayIpfsUri*` tests for the `Ipfs-Uri` response header introduced by [IPIP-548](https://github.com/ipfs/specs/pull/548), one request per failure class: canonical percent-encoded path segments (delimiters, platform-encoder gaps like `!'()*~`, 4-byte UTF-8), request-spelling independence over the existing `dir-with-percent-encoded-filename.car` (raw sub-delims, lowercase hex escapes), decode-once normalization (`%2F`, `%2E`, dot segments), nested-directory trailing slashes, query exclusion on alternate formats, redirects, and CIDv0 / legacy base58 peer ID authority normalization. Backed by the new `dir-with-tricky-filenames.car` and `dir-with-tricky-nested-filenames.car` fixtures, plus a hand-built `dir-with-slash-in-filename.car` proving that a dag-pb link with `/` in its name is not addressable by any content path (`%2F` always decodes to a separator); the full byte-level vectors live in the IPIP-0548 test fixtures table. `TestDNSLinkGatewayUnixFSDirectoryListing` also asserts the `ipns://` value for DNSLink hosts, and `TestDNSLinkGatewayIpfsUriAuthority` checks that only dotted DNSLink names appear as `ipns://` authorities.

### Changed
- Updated `github.com/ipfs/boxo` to v0.42.2 and `github.com/libp2p/go-libp2p` to v0.49.0.
- **BREAKING**: [IPIP-548](https://github.com/ipfs/specs/pull/548) deprecates `X-Ipfs-Path` in favor of `Ipfs-Uri`. Existing `X-Ipfs-Path` expectations on deserialized responses (`TestGatewayCache`, `TestGatewayCacheWithIPNS`, `TestNativeDag`, `TestGatewayJSONCborAndIPNS`) now assert `Ipfs-Uri` instead, and `TestCors` expects `Ipfs-Uri` in `Access-Control-Expose-Headers`. On raw block responses (`TestTrustlessRaw`, `TestGatewayBlock`) the `X-Ipfs-Path` expectation was dropped without a replacement, because gateways MAY omit both headers with trustless response types (`application/vnd.ipld.raw` and `application/vnd.ipld.car`). The `TestGatewayIpfsUri*` tests also fail gateways that return `X-Ipfs-Path` for content paths containing bytes invalid in HTTP field values (outside HTAB, SP, and visible ASCII per RFC 9110 section 5.5): such gateways must omit the header, since the raw legacy value would be corrupted in transit. When the header is returned for an ASCII-safe path, its value must be the decoded legacy content path, unchanged.

### Fixed
- `Header().Has()` checked only its last argument, so all but one value in each list were silently ignored. It now checks every value, which tightens `TestCors`: the full `Access-Control-Allow-Methods`, `Access-Control-Allow-Headers`, and `Access-Control-Expose-Headers` lists are enforced. The kubo-specific `X-Chunked-Output` and `X-Stream-Output` entries, which no spec mandates, were removed from the `Access-Control-Expose-Headers` expectation instead of becoming newly enforced.

## [0.13.2] - 2026-04-30
### Fixed
- `check.CheckIsJSONEqual.Check` no longer panics when the gateway response body is not valid JSON (e.g. an HTML wrapper page or upstream error). It now returns a graceful failure that includes the parser error and offending body, so consumers can use Go's `-skip` to selectively skip leaf sub-tests like `.../GET_for/Body` without losing sibling coverage. [#298](https://github.com/ipfs/gateway-conformance/pull/298)

## [0.13.1] - 2026-04-08
### Fixed
- Release workflow failed when changelog body contained special characters (`<`, `"`), preventing the v0.13.0 Docker image from being published. [#292](https://github.com/ipfs/gateway-conformance/pull/292)

## [0.13.0] - 2026-04-01
### Changed
- Removed `If-None-Match` test that sent bare CID as weak ETag (`W/"<CID>"`) for directory listings. Matching a bare CID against a `DirIndex-*` ETag is not a spec requirement, just an optimization specific to `boxo/gateway`. Test moved to [ipfs/boxo#1129](https://github.com/ipfs/boxo/pull/1129). [#261](https://github.com/ipfs/gateway-conformance/issues/261)
- **BREAKING**: Range request tests (`TestGatewayUnixFSFileRanges`) moved to a new `path-range-gateway` spec. Gateways that do not support HTTP Range requests can now skip them with `--specs -path-range-gateway`. Multi-range response detection via side-effect was replaced by `AnyOf` that accepts both single-range and multipart responses. [#258](https://github.com/ipfs/gateway-conformance/issues/258)

### Fixed
- `HeaderBuilder.Clone()` was copying `Key_` into `Value_`, silently weakening response header assertions in cloned test cases (e.g. range request and CAR helpers). [#280](https://github.com/ipfs/gateway-conformance/pull/280)
- Removed `X-Content-Type-Options: nosniff` assertion from `dag-json` and `dag-cbor` response tests in `TestNativeDag`. The spec only requires this header for `application/vnd.ipld.car` and `application/vnd.ipld.raw` responses. [#282](https://github.com/ipfs/gateway-conformance/pull/282)
- `CheckNot` error messages now include a human-readable description of the negated check instead of printing Go pointer addresses (e.g. `not(contains 'nosniff')` instead of `&{0x140001b3710}`). [#282](https://github.com/ipfs/gateway-conformance/pull/282)
- Removed `Content-Type` request header from range test helpers. GET requests should not include `Content-Type` per RFC 7231 section 3.1.1.5, as it describes message body payload. [#282](https://github.com/ipfs/gateway-conformance/pull/282)
- JSON report now uses `suite_pass`/`suite_fail` actions for the overall test suite result, making it easier to distinguish from individual test `pass`/`fail` events. [#250](https://github.com/ipfs/gateway-conformance/issues/250)
- JSON report (`--json-output`) is now streamed as tests run instead of being generated after the suite finishes. Results appear in the file incrementally, and partial output is preserved if the process is interrupted. [#249](https://github.com/ipfs/gateway-conformance/issues/249)

## [0.12.0] - 2026-03-11
### Changed
- Split `TestRedirectsFileWithIfNoneMatchHeader` into independent subtests (`SubdomainIPFS`, `SubdomainIPNS`, `DNSLinkGateway`) so `dnslink-gateway` and `subdomain-ipns-gateway` tests can be disabled via `--specs` without losing `If-None-Match` coverage for CID-based subdomain gateways. [#270](https://github.com/ipfs/gateway-conformance/issues/270)

## [0.11.2] - 2026-03-10
### Fixed
- Relaxed `_redirects` error message assertion in `TestRedirectsFileSupport` to no longer require a specific "forced redirects" error string. Implementations may report `301!` as an invalid status code, unsupported forced redirect syntax, or any other parse error. [#269](https://github.com/ipfs/gateway-conformance/issues/269)

## [0.11.1] - 2026-02-24
### Added
- New test `TestGatewayIPNSRecordWithSubpath` for IPNS records whose Value field contains a sub-path (e.g. `/ipfs/<cid>/root2`). All prior IPNS tests only covered bare `/ipfs/<cid>` in the record Value.
- New test `TestDNSLinkGatewayWithSubpath` for DNSLink TXT records pointing at a content path with a sub-path (e.g. `dnslink=/ipfs/<cid>/root2`).

## [0.11.0] - 2026-02-24
### Added
- New test `TestDNSLinkGatewayIPNS` for DNSLink TXT records pointing at `/ipns/<key>` instead of `/ipfs/<cid>`. All prior DNSLink tests only covered the `/ipfs/` case. [#272](https://github.com/ipfs/gateway-conformance/pull/272)
- New test cases in `TestSubdomainGatewayDNSLinkInlining` for the subdomain form of DNSLink -> IPNS resolution (`{dnslink}.ipns.{gateway}` and `{inlined-dnslink}.ipns.{gateway}`). [#272](https://github.com/ipfs/gateway-conformance/pull/272)

## [0.10.1] - 2026-02-13
### Fixed
- Renamed `Base32Cid()` to `DNSSafeCidV1()` and fixed it to convert CIDv0 to CIDv1 before encoding. Uses base36 for `libp2p-key` codec (IPNS keys) and base32 for everything else, producing valid DNS-safe CID strings for subdomain gateway tests. [#264](https://github.com/ipfs/gateway-conformance/issues/264)

## [0.10.0] - 2026-02-05
### Changed
- [IPIP-524](https://github.com/ipfs/specs/pull/524): codec conversion tests now expect HTTP 406 Not Acceptable when the requested format does not match the block's native codec. Implementations supporting optional codec conversions for backward compatibility may skip these tests. [#254](https://github.com/ipfs/gateway-conformance/pull/254)

## [0.9.0] - 2026-02-04
### Changed
- [IPIP-523](https://github.com/ipfs/specs/pull/523): `?format=` URL query parameter now takes precedence over `Accept` HTTP header. URL query parameters for CAR options (`car-version`, `car-order`, `car-dups`) also take precedence over parameters in the `Accept` header. [#252](https://github.com/ipfs/gateway-conformance/pull/252)

## [0.8.4] - 2025-12-12
### Fixed
- Prevent panic in report template when dump fails, allowing test reports to render gracefully on timeouts. [#253](https://github.com/ipfs/gateway-conformance/pull/253)

### Changed
- Use official ipfs org for `munge.js` instead of fork. [d3f6a67](https://github.com/ipfs/gateway-conformance/commit/d3f6a679d5f3e7cc67e5c801deaf8f36c9dc4348)

## [0.8.3] - 2025-09-01
### Changed
- Added temporary support for legacy 200 with X-Stream-Error header behavior when missing blocks are detected during CAR streaming. This ensures compatibility with current boxo/gateway implementations that defer header setting. This third option will be removed once implementations ship with [ipfs/boxo#1019](https://github.com/ipfs/boxo/pull/1019). [#245](https://github.com/ipfs/gateway-conformance/pull/245)

## [0.8.2] - 2025-08-31
### Changed
- Relaxed CAR tests to accept both HTTP 200 and 404 for non-existing paths. The response code now depends on implementation details such as locality and cost of path traversal checks. Implementations that can efficiently detect non-existing paths should return 404 (improved behavior per [ipfs/boxo#458](https://github.com/ipfs/boxo/issues/458)). Implementations focusing on stateless streaming and low latency may return 200 with partial CAR up to the missing link (legacy behavior). [#244](https://github.com/ipfs/gateway-conformance/pull/244)

## [0.8.1] - 2025-06-17
### Changed
- DAG-CBOR HTML preview pages previously had to be returned without Cache-Control headers. Now they can use Cache-Control headers similar to those used in generated UnixFS directory listings. [#241](https://github.com/ipfs/gateway-conformance/pull/241)

## [0.8.0] - 2025-05-28
### Changed
- Comprehensive tests for HTTP Range Requests over deserialized UnixFS files have been added. The `--specs path-gateway` now requires support for at least single-range requests. Deserialized range-requests can be skipped with `--skip 'TestGatewayUnixFSFileRanges'` [#213](https://github.com/ipfs/gateway-conformance/pull/213)
- Updated dependencies [#236](https://github.com/ipfs/gateway-conformance/pull/236) & [#239](https://github.com/ipfs/gateway-conformance/pull/239)

## [0.7.1] - 2025-01-03
### Changed
- Expect all URL escapes to use uppercase hex [#232](https://github.com/ipfs/gateway-conformance/pull/232)

## [0.7.0] - 2025-01-03
### Changed
- Update dependencies [#226](https://github.com/ipfs/gateway-conformance/pull/226) and [#227](https://github.com/ipfs/gateway-conformance/pull/227)
- Expect upper-case hex digits in escaped redirect URL [#225](https://github.com/ipfs/gateway-conformance/pull/225)

## [0.6.2] - 2024-08-09
### Changed
- Relaxed negative test of TAR response [#221](https://github.com/ipfs/gateway-conformance/pull/221)

## [0.6.1] - 2024-07-29
### Changed
- Support meaningful `Cache-Control` on generated UnixFS directory listing responses on `/ipfs` namespace

## [0.6.0] - 2024-06-10
### Changed
- Gateway URL
  - `--gateway-url` is no longer defaulting to predefined URL. User has to
    provide it via CLI or `GATEWAY_URL` environment variable or the test suite
    will refuse to start.
  - This aims to ensure no confusion about which gateway endpoint is being
    tested.
  - Docs and examples use `--gateway-url http://127.0.0.1:8080` to ensure no
    confusion with `localhost:8080` subdomain gateway feature in IPFS
    implementations like Kubo.
- Subdomain URL and UX related to subdomain tests
  - The `--subdomain-url` is no longer set by default.
  - User has to provide the origin of the subdomain gateway via CLI or
    `SUBDOMAIN_GATEWAY_URL` to be used during subdomain tests. This aims to
    ensure no confusion about which domain name is being tested.
  - Simplified the way `--subdomain-url` works. We no longer run implicit tests
    against `http://localhost` in addition to the URL passed via
    `--subdomain-url`. To test more than one domain, run test multiple times.
  - `localhost` subdomain gateway tests  are no longer implicit. To run tests
    against `localhost` use `--subdomain-url http://localhost:8080`
-  DNSLink test fixtures changed
   - DNSLink fixtures no longer depend on `--subdomain-url` and use unrelated
     `*.example.org` domains instead.
   - `gateway-conformance extract-fixtures` creates `dnslinks.IPFS_NS_MAP` with
     content that can be directly set as `IPNS_NS_MAP` environment variable
     supported by various implementations, incl.
     [Kubo](https://github.com/ipfs/kubo/blob/master/docs/environment-variables.md#ipfs_ns_map)
     and
     [Rainbow](https://github.com/ipfs/rainbow/blob/main/docs/environment-variables.md#ipfs_ns_map).
- Docker: image can now be run under non-root user
- HTTP Proxy tests are no longer implicit. An explicit spec named
  `proxy-gateway` exists now, and can be disabled via `--specs -proxy-gateway`.

## [0.5.2] - 2024-05-20
### Changed
- Fixed: relaxed dag-cbor error check ([#205](https://github.com/ipfs/gateway-conformance/pull/205))
- Fixed: Header().Has works properly for checking multiple values ([#207](https://github.com/ipfs/gateway-conformance/pull/207))

## [0.5.1] - 2024-04-11
- Removed byte range text for DAG-CBOR objects converted to `text/html`. [PR](https://github.com/ipfs/gateway-conformance/pull/202)

## [0.5.0] - 2024-01-25
### Changed
- Fixed tests of CAR requests with `entity-bytes` and negative indexing. [PR](https://github.com/ipfs/gateway-conformance/pull/190) (BREAKING CHANGE)
- Fixed IPNS provisioning with Kubo. [PR](https://github.com/ipfs/gateway-conformance/pull/192)

## [0.4.2] - 2023-11-20
### Changed
- Fixed versioning in Docker containers. [PR](https://github.com/ipfs/gateway-conformance/pull/179)

## [0.4.1] - 2023-10-11
### Changed
- Loosened the `Cache-Control` and `Last-Modified` checks for IPNS paths, as they are now allowed. [PR](https://github.com/ipfs/gateway-conformance/pull/173)

## [0.4.0] - 2023-10-02
### Added
- Added tests for HTTP Range requests, as well as some basic helpers for `AnyOf` and `AllOf`. [PR](https://github.com/ipfs/gateway-conformance/pull/162)

## [0.3.1] - 2023-09-15
### Added
- Specs Dashboard Output. [PR](https://github.com/ipfs/gateway-conformance/pull/163)
- `--version` flag shows the current version
- Metadata logging used to associate tests with custom data like versions, specs identifiers, etc.
- Output Github's workflow URL with metadata. [PR](https://github.com/ipfs/gateway-conformance/pull/145)
- Basic Dashboard Output with content generation. [PR](https://github.com/ipfs/gateway-conformance/pull/152)
- Test Group Metadata on Tests. [PR](https://github.com/ipfs/gateway-conformance/pull/156)
- Specs Metadata on Tests. [PR](https://github.com/ipfs/gateway-conformance/pull/159)

### Changed
- Escape test names to avoid confusion when processing test hierarchies. [PR](https://github.com/ipfs/gateway-conformance/pull/166)

## [0.3.0] - 2023-07-31
### Added
- `--verbose` flag displays all the output to the console
- `Expect.Headers.ChecksAll`: an expectation to test all the header values (0, 1, or more)

### Changed
- finalized port of Kubo's sharness tests. [PR](https://github.com/ipfs/gateway-conformance/pull/92)
- `extract-fixtures --merged` generates a car version 1 with a single root now
- refactored multi-range requests. [PR](https://github.com/ipfs/gateway-conformance/pull/113)

## [0.2.0] - 2023-06-26
### Added
- `carFixture.MustGetChildren`
- Gateway backend timeout test for entity-bytes from IPIP-402. [Issue](https://github.com/ipfs/gateway-conformance/issues/75).

### Changed
- Renamed methods using `Children` into `Descendants` when relevant
- CAR tests no longer check for the roots. See discussion in [IPIP-402](https://github.com/ipfs/specs/pull/402).

## [0.1.0] - 2023-06-08
### Added
- `Fmt` a string interpolation that replaces golang's and works better with HTML entities, and HTTP headers and URLs.
- Support for calling multiple requests in a single test case and comparing their payloads.

### Changed
- `Path(url)` does not add a leading `/` to the URL anymore.
- Do not follow redirects by default anymore, remove `DoNotFollowRedirect` and add `FollowRedirect`.
- `Body` check is running in its own test. #67

## [0.0.2] - 2023-06-01
### Removed
- Body check for subdomain redirection

## [0.0.1] - 2023-03-27
### Added
- v0 of the Gateway Conformance test suite
