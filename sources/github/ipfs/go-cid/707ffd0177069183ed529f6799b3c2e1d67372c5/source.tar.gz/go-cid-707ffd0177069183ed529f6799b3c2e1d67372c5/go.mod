module github.com/ipfs/go-cid

go 1.25.0

require (
	github.com/multiformats/go-multibase v0.3.0
	github.com/multiformats/go-multihash v0.2.3
	github.com/multiformats/go-varint v0.1.0
)

require (
	github.com/klauspost/cpuid/v2 v2.0.9 // indirect
	github.com/minio/sha256-simd v1.0.0 // indirect
	github.com/mr-tron/base58 v1.3.0 // indirect
	github.com/multiformats/go-base32 v0.1.0 // indirect
	github.com/multiformats/go-base36 v0.2.0 // indirect
	github.com/spaolacci/murmur3 v1.1.0 // indirect
	golang.org/x/crypto v0.53.0 // indirect
	golang.org/x/sys v0.46.0 // indirect
	lukechampine.com/blake3 v1.1.6 // indirect
)
