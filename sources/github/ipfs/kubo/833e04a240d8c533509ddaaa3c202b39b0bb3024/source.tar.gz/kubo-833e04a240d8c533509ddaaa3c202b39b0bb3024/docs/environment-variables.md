# Kubo environment variables

- [Variables](#variables)
  - [`IPFS_PATH`](#ipfs_path)
  - [`IPFS_LOGGING`](#ipfs_logging)
  - [`IPFS_LOGGING_FMT`](#ipfs_logging_fmt)
  - [`GOLOG_LOG_LEVEL`](#golog_log_level)
  - [`GOLOG_LOG_FMT`](#golog_log_fmt)
  - [`GOLOG_FILE`](#golog_file)
  - [`GOLOG_OUTPUT`](#golog_output)
  - [`GOLOG_TRACING_FILE`](#golog_tracing_file)
  - [`IPFS_FUSE_DEBUG`](#ipfs_fuse_debug)
  - [`YAMUX_DEBUG`](#yamux_debug)
  - [`IPFS_FD_MAX`](#ipfs_fd_max)
  - [`IPFS_DIST_PATH`](#ipfs_dist_path)
  - [`IPFS_NS_MAP`](#ipfs_ns_map)
  - [`IPFS_HTTP_ROUTERS`](#ipfs_http_routers)
  - [`IPFS_HTTP_ROUTERS_FILTER_PROTOCOLS`](#ipfs_http_routers_filter_protocols)
  - [`IPFS_CONTENT_BLOCKING_DISABLE`](#ipfs_content_blocking_disable)
  - [`IPFS_WAIT_REPO_LOCK`](#ipfs_wait_repo_lock)
  - [`IPFS_TELEMETRY`](#ipfs_telemetry)
  - [`DO_NOT_TRACK`](#do_not_track)
  - [`HTTPS_PROXY`](#https_proxy)
  - [`HTTP_PROXY`](#http_proxy)
  - [`NO_PROXY`](#no_proxy)
  - [`GOMEMLIMIT`](#gomemlimit)
  - [`LIBP2P_TCP_REUSEPORT`](#libp2p_tcp_reuseport)
  - [`LIBP2P_TCP_MUX`](#libp2p_tcp_mux)
  - [`LIBP2P_MUX_PREFS`](#libp2p_mux_prefs)
  - [`LIBP2P_RCMGR`](#libp2p_rcmgr)
  - [`LIBP2P_DEBUG_RCMGR`](#libp2p_debug_rcmgr)
  - [`LIBP2P_SWARM_FD_LIMIT`](#libp2p_swarm_fd_limit)
- [Tracing](#tracing)

# Variables

## `IPFS_PATH`

Sets the location of the IPFS repo (where the config, blocks, etc.
are stored).

Default: ~/.ipfs

## `IPFS_LOGGING`

Specifies the log level for Kubo.

`IPFS_LOGGING` is a deprecated alias for the `GOLOG_LOG_LEVEL` environment variable.  See below.

## `IPFS_LOGGING_FMT`

Specifies the log message format.

`IPFS_LOGGING_FMT` is a deprecated alias for the `GOLOG_LOG_FMT` environment variable.  See below.

## `GOLOG_LOG_LEVEL`

Specifies the log-level, both globally and on a per-subsystem basis.  Level can be one of:

* `debug`
* `info`
* `warn`
* `error`
* `dpanic`
* `panic`
* `fatal`

Per-subsystem levels can be specified with `subsystem=level`.  One global level and one or more per-subsystem levels
can be specified by separating them with commas.

Default: `error`

Example:

```console
GOLOG_LOG_LEVEL="error,core/server=debug" ipfs daemon
```

Logging can also be configured at runtime, both globally and on a per-subsystem basis, with the `ipfs log` command.

See [Known logger subsystems](./debug-guide.md#known-logger-subsystems) for subsystem names related to the provide/reprovide pipeline.

## `GOLOG_LOG_FMT`

Specifies the log message format.  It supports the following values:

- `color` -- human readable, colorized (ANSI) output
- `nocolor` -- human readable, plain-text output.
- `json` -- structured JSON.

For example, to log structured JSON (for easier parsing):

```bash
export GOLOG_LOG_FMT="json"
```
The logging format defaults to `color` when the output is a terminal, and `nocolor` otherwise.

## `GOLOG_FILE`

Sets the file to which Kubo logs. By default, Kubo logs to standard error.

## `GOLOG_OUTPUT`

When stderr and/or stdout options are configured or specified by the `GOLOG_OUTPUT` environ variable, log only to the output(s) specified. For example:

- `GOLOG_OUTPUT="stderr"` logs only to stderr
- `GOLOG_OUTPUT="stdout"` logs only to stdout
- `GOLOG_OUTPUT="stderr+stdout"` logs to both stderr and stdout

## `GOLOG_TRACING_FILE`

Sets the file to which Kubo sends tracing events. By default, tracing is
disabled.

This log can be read at runtime (without writing it to a file) using the `ipfs
log tail` command.

Warning: Enabling tracing will likely affect performance.

## `IPFS_FUSE_DEBUG`

When set to any non-empty value, logs every FUSE operation (open, read, write, lookup, getattr, etc.) to stderr with its arguments and return values. Useful for diagnosing mount issues or inspecting what the kernel requests.

Default: not set (no debug logging)

## `YAMUX_DEBUG`

If SET, enables debug logging for the yamux stream muxer.

Default: false

## `IPFS_FD_MAX`

Sets the file descriptor limit for Kubo. If Kubo fails to set the file
descriptor limit, it will log an error.

Defaults: 2048

## `IPFS_DIST_PATH`

IPFS Content Path from which Kubo fetches repo migrations (when the daemon
is launched with the `--migrate` flag).

Default: `/ipfs/<cid>` (the exact path is hardcoded in
`migrations.CurrentIpfsDist`, depends on the IPFS version)

## `IPFS_NS_MAP`

Adds static namesys records for deterministic tests and debugging.
Useful for testing things like DNSLink without real DNS lookup.

Example:

```console
$ IPFS_NS_MAP="dnslink-test1.example.com:/ipfs/bafkreicysg23kiwv34eg2d7qweipxwosdo2py4ldv42nbauguluen5v6am,dnslink-test2.example.com:/ipns/dnslink-test1.example.com" ipfs daemon
...
$ ipfs resolve -r /ipns/dnslink-test2.example.com
/ipfs/bafkreicysg23kiwv34eg2d7qweipxwosdo2py4ldv42nbauguluen5v6am
```

## `IPFS_HTTP_ROUTERS`

Overrides AutoConf and all other HTTP routers when set.
When `Routing.Type=auto`, this environment variable takes precedence over
both AutoConf-provided endpoints and any manually configured delegated routers.
The value should be a space or comma-separated list of HTTP routing endpoint URLs.

This is useful for:
- Testing and debugging in offline contexts
- Overriding AutoConf endpoints temporarily
- Using custom or private HTTP routing services

Example:

```console
$ ipfs config Routing.Type auto
$ IPFS_HTTP_ROUTERS="http://127.0.0.1:7423" ipfs daemon
```

The above will replace all AutoConf endpoints with a single local one, allowing for
inspection/debug of HTTP requests sent by Kubo via `while true ; do nc -l 7423; done`
or more advanced tools like [mitmproxy](https://docs.mitmproxy.org/stable/#mitmproxy).

When not set, Kubo uses endpoints from AutoConf (when enabled) or manually configured `Routing.DelegatedRouters`.

## `IPFS_HTTP_ROUTERS_FILTER_PROTOCOLS`

Overrides values passed with `filter-protocols` parameter defined in IPIP-484.
Value is space-separated.

```console
$ IPFS_HTTP_ROUTERS_FILTER_PROTOCOLS="unknown transport-bitswap transport-foo" ipfs daemon
```

Default: `config.DefaultHTTPRoutersFilterProtocols`

## `IPFS_CONTENT_BLOCKING_DISABLE`

Disables the content-blocking subsystem. No denylists will be watched and no
content will be blocked.

## `IPFS_WAIT_REPO_LOCK`

Specifies the amount of time to wait for the repo lock. Set the value of this variable to a string that can be [parsed](https://pkg.go.dev/time@go1.24.3#ParseDuration) as a golang `time.Duration`. For example:
```
IPFS_WAIT_REPO_LOCK="15s"
```

If the lock cannot be acquired because someone else has the lock, and `IPFS_WAIT_REPO_LOCK` is set to a valid value, then acquiring the lock is retried every second until the lock is acquired or the specified wait time has elapsed.

## `IPFS_TELEMETRY`

Controls the behavior of the [telemetry plugin](telemetry.md). The plugin sends nothing unless an endpoint is configured, so this variable matters only for a node that has one. Valid values are:

- `on`: Enables telemetry.
- `off`: Disables telemetry. Nothing is sent, and the stored anonymous identifier is removed.
- `auto`: Like `on`, but logs an informative message about telemetry and gives user 15 minutes to opt-out before first collection. Used automatically on first run and when `IPFS_TELEMETRY` is not set.

The mode can also be set in the config file under `Plugins.Plugins.telemetry.Config.Mode`. This variable takes precedence over both the config file and [`DO_NOT_TRACK`](#do_not_track), so `IPFS_TELEMETRY=on` keeps telemetry on for one node on a machine that opts out globally.

Example:

```bash
export IPFS_TELEMETRY="off"
```

## `DO_NOT_TRACK`

Disables the [telemetry plugin](telemetry.md). This is the shared opt-out convention read by other command line tools, so one setting covers them all. Kubo reads `1` and `true` as opting out, and ignores `0` and `false`.

```bash
export DO_NOT_TRACK=1
```

[`IPFS_TELEMETRY`](#ipfs_telemetry) overrides this variable in both directions. `DO_NOT_TRACK` overrides the `Mode` set in the config file.

## `HTTPS_PROXY`

Proxy for outbound `https://` HTTP requests and `/wss` libp2p WebSocket peer dials. Kubo relies on Go's `http.ProxyFromEnvironment`, which is honored by every HTTP client in the default code paths:

- `ipfs` CLI talking to a remote daemon over [Kubo RPC](https://docs.ipfs.tech/reference/kubo/rpc/).
- Programmatic [Kubo RPC](https://docs.ipfs.tech/reference/kubo/rpc/) client (`client/rpc`) used by third-party Go applications.
- `ipfs update` downloader fetching release binaries and checksums from GitHub.
- Delegated HTTP routing configured via [`Routing.DelegatedRouters`](config.md#routingdelegatedrouters).
- HTTP block retrieval used by Bitswap against [Trustless Gateways](https://specs.ipfs.tech/http-gateways/trustless-gateway/).
- AutoConf fetch of network bootstrap defaults ([`AutoConf.URL`](config.md#autoconfurl)).
- AutoTLS ACME cert issuance via [`certmagic`](https://github.com/caddyserver/certmagic): both the challenge broker request to `p2p-forge` and the ACME flow to the configured CA (Let's Encrypt by default).
- go-libp2p WebSocket transport for `/wss` outbound peer dials (`gorilla/websocket` `DefaultDialer`).

Accepted forms:

- `http://host:port`: plain HTTP proxy; TLS targets tunnel through `CONNECT`. Works for both `https://` and `wss://`.
- `https://host:port`: proxy itself is reached over TLS. Requires Kubo 0.41 or newer.
- Basic auth is supported: `http://user:pass@host:port`.

Example:

```console
HTTPS_PROXY=http://proxy.local:8080 ipfs daemon
```

Scope:

- Outbound only. Inbound listeners (`/ws`, `/wss`, gateway, RPC) are not affected.
- Direct libp2p transports (TCP, QUIC, WebTransport, WebRTC) do not use a proxy.

## `HTTP_PROXY`

Same as [`HTTPS_PROXY`](#https_proxy), applied to `http://` URLs and `/ws` libp2p WebSocket peer dials.

## `NO_PROXY`

Comma-separated list of host names, domain suffixes (prefixed with a dot), or CIDR blocks that bypass [`HTTP_PROXY`](#http_proxy) and [`HTTPS_PROXY`](#https_proxy).

Example:

```console
NO_PROXY="localhost,127.0.0.1,.internal" HTTPS_PROXY=http://proxy.local:8080 ipfs daemon
```

## `GOMEMLIMIT`

Soft memory limit for the Go runtime, recognized by every Go program. As the Kubo daemon's memory use approaches this value, the garbage collector runs more often and returns free memory to the OS sooner. The limit is soft: memory that is still in use cannot be freed, so the process can exceed it under load.

On devices with limited RAM, set it to about half of total memory and pair it with OS-level limits; see [Kubo on low-memory devices](production/low-memory.md) for a worked setup and the [Go garbage collector guide](https://go.dev/doc/gc-guide) for the mechanics.

Default: not set (no limit)

## `LIBP2P_TCP_REUSEPORT`

Kubo tries to reuse the same source port for all connections to improve NAT
traversal. If this is an issue, you can disable it by setting
`LIBP2P_TCP_REUSEPORT` to false.

Default: `true`

## `LIBP2P_TCP_MUX`

By default Kubo tries to reuse the same listener port for raw TCP and WebSockets transports via experimental `libp2p.ShareTCPListener()` feature introduced in [go-libp2p#2984](https://github.com/libp2p/go-libp2p/pull/2984).
If this is an issue, you can disable it by setting `LIBP2P_TCP_MUX` to `false` and use separate ports for each TCP transport.

> [!CAUTION]
> This configuration option may be removed once `libp2p.ShareTCPListener()`  becomes default in go-libp2p.

Default: `true`

## `LIBP2P_MUX_PREFS`

Deprecated: Use the `Swarm.Transports.Multiplexers` config field.

Tells Kubo which multiplexers to use in which order.

Default: "/yamux/1.0.0 /mplex/6.7.0"

## `LIBP2P_RCMGR`

Forces [libp2p Network Resource Manager](https://github.com/libp2p/go-libp2p-resource-manager#readme)
to be enabled (`1`) or disabled (`0`).
When set, overrides [`Swarm.ResourceMgr.Enabled`](https://github.com/ipfs/kubo/blob/master/docs/config.md#swarmresourcemgrenabled) from the config.

Default: use config (not set)

## `LIBP2P_DEBUG_RCMGR`

Enables tracing of [libp2p Network Resource Manager](https://github.com/libp2p/go-libp2p-resource-manager#readme)
and outputs it to `rcmgr.json.gz`


Default: disabled (not set)

## `LIBP2P_SWARM_FD_LIMIT`

This variable controls the number of concurrent outbound dials (except dials to relay addresses which have their own limiting logic).

Reducing it slows down connection ballooning but might affect performance negatively.

Default: [160](https://github.com/libp2p/go-libp2p/blob/master/p2p/net/swarm/swarm_dial.go#L91) (not set)

## `TEST_DHT_STUB`

Lifts WAN DHT filters so kubo can operate against DHT peers on
loopback, enabling end-to-end provide/findprovs/IPNS testing
without public internet access. Exercises every DHT code path:
dial, protocol negotiation, message serialization, routing table
management.

Filters removed on the WAN DHT when this variable is set:

- `AddressFilter`: accepts loopback addresses (default rejects non-public)
- `QueryFilter`: accepts all peers (default rejects non-public)
- `RoutingTableFilter`: accepts all peers (default rejects non-public)
- `RoutingTablePeerDiversityFilter`: disabled (default caps same-IP peers to 3)

In the CLI test harness, `h.BootstrapWithStubDHT(nodes)` spawns a
mini-DHT on the loopback interface and sets this variable on each
node automatically, allowing the loopback DHT to serve as a WAN
replacement. Tests do not need to set this variable externally.

Default: disabled (not set)

# Tracing

For tracing configuration, please check: https://github.com/ipfs/boxo/blob/main/docs/tracing.md
