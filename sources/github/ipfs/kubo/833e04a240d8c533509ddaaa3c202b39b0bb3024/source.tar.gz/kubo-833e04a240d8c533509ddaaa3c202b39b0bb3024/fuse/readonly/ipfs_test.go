//go:build (linux || darwin || freebsd) && !nofuse

// Unit tests for the read-only /ipfs FUSE mount.
// These test the filesystem implementation directly without a daemon.
// End-to-end tests that exercise mount/unmount through a real daemon
// live in test/cli/fuse/.

package readonly

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"os"
	gopath "path"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/hanwen/go-fuse/v2/fs"
	"github.com/hanwen/go-fuse/v2/fuse"

	core "github.com/ipfs/kubo/core"
	coreapi "github.com/ipfs/kubo/core/coreapi"
	coremock "github.com/ipfs/kubo/core/mock"

	chunker "github.com/ipfs/boxo/chunker"
	"github.com/ipfs/boxo/files"
	dag "github.com/ipfs/boxo/ipld/merkledag"
	ft "github.com/ipfs/boxo/ipld/unixfs"
	importer "github.com/ipfs/boxo/ipld/unixfs/importer"
	uio "github.com/ipfs/boxo/ipld/unixfs/io"
	"github.com/ipfs/boxo/path"
	cid "github.com/ipfs/go-cid"
	cbor "github.com/ipfs/go-ipld-cbor"
	ipld "github.com/ipfs/go-ipld-format"
	"github.com/ipfs/go-test/random"
	options "github.com/ipfs/kubo/core/coreiface/options"
	"github.com/ipfs/kubo/fuse/fusetest"
	fusemnt "github.com/ipfs/kubo/fuse/mount"
	mh "github.com/multiformats/go-multihash"
	"github.com/stretchr/testify/require"
	"golang.org/x/sys/unix"
)

func testMount(t *testing.T, root fs.InodeEmbedder) string {
	t.Helper()
	return fusetest.TestMount(t, root, &fs.Options{
		AttrTimeout:  &immutableAttrCacheTime,
		EntryTimeout: &immutableAttrCacheTime,
		MountOptions: fuse.MountOptions{
			MaxReadAhead: fusemnt.MaxReadAhead,
		},
	})
}

func randObj(t *testing.T, nd *core.IpfsNode, size int64) (ipld.Node, []byte) {
	buf := make([]byte, size)
	_, err := io.ReadFull(random.New(), buf)
	if err != nil {
		t.Fatal(err)
	}
	read := bytes.NewReader(buf)
	obj, err := importer.BuildTrickleDagFromReader(nd.DAG, chunker.DefaultSplitter(read))
	if err != nil {
		t.Fatal(err)
	}

	return obj, buf
}

func setupIpfsTest(t *testing.T, node *core.IpfsNode) (*core.IpfsNode, string) {
	t.Helper()

	var err error
	if node == nil {
		node, err = coremock.NewMockNode()
		if err != nil {
			t.Fatal(err)
		}
	}

	root := NewRoot(node)
	mntDir := testMount(t, root)

	return node, mntDir
}

// Test that an empty directory can be listed without errors.
func TestEmptyDirListing(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	// Create an empty UnixFS directory and add it to the DAG.
	db, err := uio.NewDirectory(nd.DAG)
	if err != nil {
		t.Fatal(err)
	}
	emptyDir, err := db.GetNode()
	if err != nil {
		t.Fatal(err)
	}
	if err := nd.DAG.Add(nd.Context(), emptyDir); err != nil {
		t.Fatal(err)
	}

	// List it via FUSE.
	dirPath := gopath.Join(mntDir, emptyDir.Cid().String())
	entries, err := os.ReadDir(dirPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 0 {
		t.Fatalf("expected empty directory, got %d entries", len(entries))
	}
}

// Test that a bare file CID can be read at the /ipfs mount root.
func TestBareFileCID(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	api, err := coreapi.NewCoreAPI(nd)
	if err != nil {
		t.Fatal(err)
	}

	content := []byte("bare file CID test content")

	t.Run("CIDv0", func(t *testing.T) {
		resolved, err := api.Unixfs().Add(t.Context(),
			files.NewBytesFile(content),
			options.Unixfs.CidVersion(0),
			options.Unixfs.RawLeaves(false))
		if err != nil {
			t.Fatal(err)
		}
		cidStr := resolved.RootCid().String()
		got, err := os.ReadFile(gopath.Join(mntDir, cidStr))
		if err != nil {
			t.Fatalf("read %s via FUSE: %v", cidStr, err)
		}
		if !bytes.Equal(got, content) {
			t.Fatalf("content mismatch: got %d bytes, want %d", len(got), len(content))
		}
	})

	t.Run("CIDv1", func(t *testing.T) {
		resolved, err := api.Unixfs().Add(t.Context(),
			files.NewBytesFile(content),
			options.Unixfs.CidVersion(1),
			options.Unixfs.RawLeaves(true))
		if err != nil {
			t.Fatal(err)
		}
		cidStr := resolved.RootCid().String()
		got, err := os.ReadFile(gopath.Join(mntDir, cidStr))
		if err != nil {
			t.Fatalf("read %s via FUSE: %v", cidStr, err)
		}
		if !bytes.Equal(got, content) {
			t.Fatalf("content mismatch: got %d bytes, want %d", len(got), len(content))
		}
	})
}

// TestInodeNumbersFromCID verifies that /ipfs entries are numbered from the
// CID they resolve to, so a file keeps one inode number no matter which path
// reaches it or how often the kernel looks it up.
func TestInodeNumbersFromCID(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	api, err := coreapi.NewCoreAPI(nd)
	require.NoError(t, err)

	content := []byte("inode numbering test content")
	file, err := api.Unixfs().Add(t.Context(), files.NewBytesFile(content))
	require.NoError(t, err)

	dir, err := api.Unixfs().Add(t.Context(), files.NewMapDirectory(map[string]files.Node{
		"child": files.NewBytesFile(content),
	}))
	require.NoError(t, err)

	ino := func(path string) uint64 {
		t.Helper()
		info, err := os.Stat(path)
		require.NoError(t, err)
		st, ok := info.Sys().(*syscall.Stat_t)
		require.True(t, ok)
		return st.Ino
	}

	direct := ino(gopath.Join(mntDir, file.RootCid().String()))
	require.NotZero(t, direct, "file should report an inode number")
	// Numbers at or above this point are the ones go-fuse hands out when a
	// filesystem does not number a node itself.
	require.Less(t, direct, uint64(fusemnt.AutomaticIno),
		"inode number should be derived from the CID, not left to go-fuse")

	require.Equal(t, direct, ino(gopath.Join(mntDir, file.RootCid().String())),
		"repeated lookups of one path should agree")
	require.Equal(t, direct, ino(gopath.Join(mntDir, dir.RootCid().String(), "child")),
		"the same content reached through another path is the same object")
}

// TestSameBlockUnderTwoCodecs reads one block through both a dag-pb and a raw
// CID. They name different files, since the raw CID is the block itself and
// the dag-pb CID is the UnixFS file inside it, so they have to be numbered
// apart: go-fuse serves two entries that agree on their whole identity from
// one node, and the first one read would then answer for both.
func TestSameBlockUnderTwoCodecs(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	api, err := coreapi.NewCoreAPI(nd)
	require.NoError(t, err)

	content := []byte("one block, two codecs")
	added, err := api.Unixfs().Add(t.Context(), files.NewBytesFile(content),
		options.Unixfs.CidVersion(1), options.Unixfs.RawLeaves(false))
	require.NoError(t, err)

	pbCid := added.RootCid()
	rawCid := cid.NewCidV1(cid.Raw, pbCid.Hash())

	block, err := nd.Blockstore.Get(t.Context(), pbCid)
	require.NoError(t, err)

	stat := func(c cid.Cid) (uint64, []byte) {
		t.Helper()
		p := gopath.Join(mntDir, c.String())
		info, err := os.Stat(p)
		require.NoError(t, err)
		st, ok := info.Sys().(*syscall.Stat_t)
		require.True(t, ok)
		data, err := os.ReadFile(p)
		require.NoError(t, err)
		return st.Ino, data
	}

	pbIno, pbData := stat(pbCid)
	rawIno, rawData := stat(rawCid)

	require.NotEqual(t, pbIno, rawIno, "two CIDs for one block should be numbered apart")
	require.Equal(t, content, pbData, "the dag-pb CID should read as the UnixFS file")
	require.Equal(t, block.RawData(), rawData, "the raw CID should read as the block itself")
}

// TestLookupOfUnreadableChild covers the two children a UnixFS directory can
// hold that this mount cannot read as a UnixFS file: one in a codec it does
// not decode, and one whose block is not in the blockstore. A stat of either
// used to dereference the UnixFS metadata it never got and take the whole
// daemon down with it.
func TestLookupOfUnreadableChild(t *testing.T) {
	dirWithChild := func(t *testing.T, nd *core.IpfsNode, name string, child ipld.Node) string {
		t.Helper()
		db, err := uio.NewDirectory(nd.DAG)
		require.NoError(t, err)
		require.NoError(t, db.AddChild(t.Context(), name, child))
		dir, err := db.GetNode()
		require.NoError(t, err)
		require.NoError(t, nd.DAG.Add(t.Context(), dir))
		return dir.Cid().String()
	}

	t.Run("dag-cbor child", func(t *testing.T) {
		nd, mntDir := setupIpfsTest(t, nil)

		child, err := cbor.WrapObject(map[string]string{"hello": "world"}, mh.SHA2_256, -1)
		require.NoError(t, err)
		require.NoError(t, nd.DAG.Add(t.Context(), child))

		dir := dirWithChild(t, nd, "obj", child)
		info, err := os.Stat(gopath.Join(mntDir, dir, "obj"))
		require.NoError(t, err)
		require.False(t, info.IsDir())
		require.EqualValues(t, len(child.RawData()), info.Size(),
			"a block this mount cannot decode should report its own size")

		got, err := os.ReadFile(gopath.Join(mntDir, dir, "obj"))
		require.NoError(t, err, "a size stat reports has to be a size reads can deliver")
		require.Equal(t, child.RawData(), got)
	})

	t.Run("missing block", func(t *testing.T) {
		// An offline node, so that a block nobody has is reported missing
		// rather than waited for.
		offline, err := core.NewNode(t.Context(), &core.BuildCfg{})
		require.NoError(t, err)
		t.Cleanup(func() { _ = offline.Close() })
		_, mntDir := setupIpfsTest(t, offline)

		child := dag.NodeWithData(ft.FilePBData([]byte("gone"), 4))
		dir := dirWithChild(t, offline, "gone", child)
		require.NoError(t, offline.DAG.Remove(t.Context(), child.Cid()))

		_, err = os.Stat(gopath.Join(mntDir, dir, "gone"))
		require.Error(t, err, "a child whose block is missing should not resolve")
	})
}

// A listing has to survive one child whose block is missing. The other
// entries are still worth having, and the caller finds out what is wrong with
// the bad one by stat'ing it.
func TestReaddirWithUnreadableChild(t *testing.T) {
	offline, err := core.NewNode(t.Context(), &core.BuildCfg{})
	require.NoError(t, err)
	t.Cleanup(func() { _ = offline.Close() })
	_, mntDir := setupIpfsTest(t, offline)

	good := dag.NodeWithData(ft.FilePBData([]byte("here"), 4))
	gone := dag.NodeWithData(ft.FilePBData([]byte("gone"), 4))
	// AddChild only links a node, it does not store it, and an entry whose
	// block was never stored is missing in the same way as one that was.
	require.NoError(t, offline.DAG.Add(t.Context(), good))
	require.NoError(t, offline.DAG.Add(t.Context(), gone))

	db, err := uio.NewDirectory(offline.DAG)
	require.NoError(t, err)
	require.NoError(t, db.AddChild(t.Context(), "good", good))
	require.NoError(t, db.AddChild(t.Context(), "gone", gone))
	dirNode, err := db.GetNode()
	require.NoError(t, err)
	require.NoError(t, offline.DAG.Add(t.Context(), dirNode))
	require.NoError(t, offline.DAG.Remove(t.Context(), gone.Cid()))

	entries, err := os.ReadDir(gopath.Join(mntDir, dirNode.Cid().String()))
	require.NoError(t, err, "one missing block should not fail the whole listing")

	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	// The unreadable name is reported with no type and no inode number, which
	// readdirplus and Go's dirent parsing then drop; what matters is that the
	// readable half of the directory is still there.
	require.Contains(t, names, "good")
}

// The ipfs.cid xattr has to answer with the CID the caller used to get here.
// The mount rebuilds the node by decoding the block, which loses the version
// and codec of the path it came from.
func TestXattrCIDMatchesPath(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	api, err := coreapi.NewCoreAPI(nd)
	require.NoError(t, err)

	added, err := api.Unixfs().Add(t.Context(),
		files.NewBytesFile([]byte("xattr cid version")),
		options.Unixfs.CidVersion(1),
		options.Unixfs.RawLeaves(false))
	require.NoError(t, err)
	want := added.RootCid().String()

	dest := make([]byte, 256)
	sz, err := unix.Getxattr(gopath.Join(mntDir, want), fusemnt.XattrCID, dest)
	require.NoError(t, err)
	require.Equal(t, want, string(dest[:sz]))
}

// Test reading a directory that contains both dag-pb and raw-leaf children.
// This is the typical layout produced by `ipfs add --raw-leaves`: the
// directory node is dag-pb, while file leaves are raw blocks.
func TestMixedDAGDirectory(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	api, err := coreapi.NewCoreAPI(nd)
	if err != nil {
		t.Fatal(err)
	}

	fileA := []byte("file in dag-pb leaf")
	fileB := []byte("file in raw leaf")

	dir := files.NewMapDirectory(map[string]files.Node{
		"dagpb.txt": files.NewBytesFile(fileA),
		"raw.txt":   files.NewBytesFile(fileB),
	})

	// CIDv1 with raw leaves: directory is dag-pb, file leaves are raw.
	resolved, err := api.Unixfs().Add(t.Context(), dir,
		options.Unixfs.CidVersion(1),
		options.Unixfs.RawLeaves(true))
	if err != nil {
		t.Fatal(err)
	}

	dirPath := gopath.Join(mntDir, resolved.RootCid().String())

	entries, err := os.ReadDir(dirPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(entries))
	}

	for _, tc := range []struct {
		name string
		want []byte
	}{
		{"dagpb.txt", fileA},
		{"raw.txt", fileB},
	} {
		got, err := os.ReadFile(gopath.Join(dirPath, tc.name))
		if err != nil {
			t.Fatalf("read %s: %v", tc.name, err)
		}
		if !bytes.Equal(got, tc.want) {
			t.Fatalf("%s: content mismatch: got %d bytes, want %d", tc.name, len(got), len(tc.want))
		}
	}
}

// Test writing an object and reading it back through fuse.
func TestIpfsBasicRead(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	fi, data := randObj(t, nd, 10000)
	k := fi.Cid()
	fname := gopath.Join(mntDir, k.String())
	rbuf, err := os.ReadFile(fname)
	if err != nil {
		t.Fatal(err)
	}

	if !bytes.Equal(rbuf, data) {
		t.Fatal("Incorrect Read!")
	}
}

func getPaths(t *testing.T, ipfs *core.IpfsNode, name string, n *dag.ProtoNode) []string {
	if len(n.Links()) == 0 {
		return []string{name}
	}
	var out []string
	for _, lnk := range n.Links() {
		child, err := lnk.GetNode(ipfs.Context(), ipfs.DAG)
		if err != nil {
			t.Fatal(err)
		}

		childpb, ok := child.(*dag.ProtoNode)
		if !ok {
			t.Fatal(dag.ErrNotProtobuf)
		}

		sub := getPaths(t, ipfs, gopath.Join(name, lnk.Name), childpb)
		out = append(out, sub...)
	}
	return out
}

// Perform a large number of concurrent reads to stress the system.
func TestIpfsStressRead(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	api, err := coreapi.NewCoreAPI(nd)
	if err != nil {
		t.Fatal(err)
	}

	var nodes []ipld.Node
	var paths []string

	nobj := 50
	ndiriter := 50

	// Make a bunch of objects
	for range nobj {
		fi, _ := randObj(t, nd, rand.Int63n(50000))
		nodes = append(nodes, fi)
		paths = append(paths, fi.Cid().String())
	}

	// Now make a bunch of dirs
	for range ndiriter {
		db, err := uio.NewDirectory(nd.DAG)
		if err != nil {
			t.Fatal(err)
		}
		for j := 0; j < 1+rand.Intn(10); j++ {
			name := fmt.Sprintf("child%d", j)

			err := db.AddChild(nd.Context(), name, nodes[rand.Intn(len(nodes))])
			if err != nil {
				t.Fatal(err)
			}
		}
		newdir, err := db.GetNode()
		if err != nil {
			t.Fatal(err)
		}

		err = nd.DAG.Add(nd.Context(), newdir)
		if err != nil {
			t.Fatal(err)
		}

		nodes = append(nodes, newdir)
		npaths := getPaths(t, nd, newdir.Cid().String(), newdir.(*dag.ProtoNode))
		paths = append(paths, npaths...)
	}

	// Now read a bunch, concurrently
	wg := sync.WaitGroup{}
	errs := make(chan error)

	for range 4 {
		wg.Go(func() {

			for range 2000 {
				item, err := path.NewPath("/ipfs/" + paths[rand.Intn(len(paths))])
				if err != nil {
					errs <- err
					continue
				}

				relpath := strings.Replace(item.String(), item.Namespace(), "", 1)
				fname := gopath.Join(mntDir, relpath)

				rbuf, err := os.ReadFile(fname)
				if err != nil {
					errs <- err
					continue
				}

				// nd.Context() is never closed which leads to
				// hitting 8128 goroutine limit in go test -race mode
				ctx, cancelFunc := context.WithCancel(context.Background())

				read, err := api.Unixfs().Get(ctx, item)
				if err != nil {
					cancelFunc()
					errs <- err
					continue
				}

				data, err := io.ReadAll(read.(files.File))
				if err != nil {
					cancelFunc()
					errs <- err
					continue
				}

				cancelFunc()

				if !bytes.Equal(rbuf, data) {
					errs <- errors.New("incorrect read")
				}
			}
		})
	}

	go func() {
		wg.Wait()
		close(errs)
	}()

	for err := range errs {
		if err != nil {
			t.Fatal(err)
		}
	}
}

// Test writing a file and reading it back.
func TestIpfsBasicDirRead(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	// Make a 'file'
	fi, data := randObj(t, nd, 10000)

	// Make a directory and put that file in it
	db, err := uio.NewDirectory(nd.DAG)
	if err != nil {
		t.Fatal(err)
	}
	err = db.AddChild(nd.Context(), "actual", fi)
	if err != nil {
		t.Fatal(err)
	}

	d1nd, err := db.GetNode()
	if err != nil {
		t.Fatal(err)
	}

	err = nd.DAG.Add(nd.Context(), d1nd)
	if err != nil {
		t.Fatal(err)
	}

	dirname := gopath.Join(mntDir, d1nd.Cid().String())
	fname := gopath.Join(dirname, "actual")
	rbuf, err := os.ReadFile(fname)
	if err != nil {
		t.Fatal(err)
	}

	dirents, err := os.ReadDir(dirname)
	if err != nil {
		t.Fatal(err)
	}
	if len(dirents) != 1 {
		t.Fatal("Bad directory entry count")
	}
	if dirents[0].Name() != "actual" {
		t.Fatal("Bad directory entry")
	}

	if !bytes.Equal(rbuf, data) {
		t.Fatal("Incorrect Read!")
	}
}

// Test to make sure the filesystem reports file sizes correctly.
func TestFileSizeReporting(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	fi, data := randObj(t, nd, 10000)
	k := fi.Cid()

	fname := gopath.Join(mntDir, k.String())

	finfo, err := os.Stat(fname)
	if err != nil {
		t.Fatal(err)
	}

	if finfo.Size() != int64(len(data)) {
		t.Fatal("Read incorrect size from stat!")
	}
}

// Test that mode and mtime stored in UnixFS metadata are reported in stat.
func TestUnixFSMetadataInStat(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	storedMode := os.FileMode(0o755)
	storedMtime := time.Date(2025, 6, 15, 12, 0, 0, 0, time.UTC)
	content := []byte("file with metadata")

	// Create a UnixFS node with explicit mode and mtime.
	pbdata := ft.FilePBDataWithStat(content, uint64(len(content)), storedMode, storedMtime)
	node := dag.NodeWithData(pbdata)
	if err := nd.DAG.Add(nd.Context(), node); err != nil {
		t.Fatal(err)
	}

	fpath := gopath.Join(mntDir, node.Cid().String())
	fi, err := os.Stat(fpath)
	if err != nil {
		t.Fatal(err)
	}

	if fi.Mode().Perm() != storedMode.Perm() {
		t.Fatalf("expected mode %04o, got %04o", storedMode.Perm(), fi.Mode().Perm())
	}
	if !fi.ModTime().Equal(storedMtime) {
		t.Fatalf("expected mtime %v, got %v", storedMtime, fi.ModTime())
	}
}

// Test that files without UnixFS metadata get the read-only defaults.
func TestDefaultModeReadonly(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	// Create a plain UnixFS file (no mode/mtime metadata).
	fi, _ := randObj(t, nd, 100)
	fpath := gopath.Join(mntDir, fi.Cid().String())

	finfo, err := os.Stat(fpath)
	if err != nil {
		t.Fatal(err)
	}
	if finfo.Mode().Perm() != fusemnt.DefaultFileModeRO.Perm() {
		t.Fatalf("expected default mode %04o, got %04o", fusemnt.DefaultFileModeRO.Perm(), finfo.Mode().Perm())
	}
}

// Test that ipfs.cid xattr returns the correct CID for files and directories.
func TestXattrCID(t *testing.T) {
	nd, _ := setupIpfsTest(t, nil)

	t.Run("file", func(t *testing.T) {
		obj, _ := randObj(t, nd, 100)
		node := &Node{ipfs: nd, nd: obj, cid: obj.Cid()}

		dest := make([]byte, 256)
		sz, errno := node.Listxattr(t.Context(), dest)
		if errno != 0 {
			t.Fatalf("Listxattr: %v", errno)
		}
		if !bytes.Contains(dest[:sz], []byte(fusemnt.XattrCID)) {
			t.Fatal("ipfs.cid not listed")
		}

		sz, errno = node.Getxattr(t.Context(), fusemnt.XattrCID, dest)
		if errno != 0 {
			t.Fatalf("Getxattr: %v", errno)
		}
		if string(dest[:sz]) != obj.Cid().String() {
			t.Fatalf("expected CID %s, got %s", obj.Cid().String(), string(dest[:sz]))
		}
	})

	t.Run("directory", func(t *testing.T) {
		db, err := uio.NewDirectory(nd.DAG)
		if err != nil {
			t.Fatal(err)
		}
		dirNode, err := db.GetNode()
		if err != nil {
			t.Fatal(err)
		}
		if err := nd.DAG.Add(nd.Context(), dirNode); err != nil {
			t.Fatal(err)
		}
		node := &Node{ipfs: nd, nd: dirNode, cid: dirNode.Cid()}

		dest := make([]byte, 256)
		sz, errno := node.Listxattr(t.Context(), dest)
		if errno != 0 {
			t.Fatalf("Listxattr: %v", errno)
		}
		if !bytes.Contains(dest[:sz], []byte(fusemnt.XattrCID)) {
			t.Fatal("ipfs.cid not listed")
		}

		sz, errno = node.Getxattr(t.Context(), fusemnt.XattrCID, dest)
		if errno != 0 {
			t.Fatalf("Getxattr: %v", errno)
		}
		if string(dest[:sz]) != dirNode.Cid().String() {
			t.Fatalf("expected CID %s, got %s", dirNode.Cid().String(), string(dest[:sz]))
		}
	})

}

// Test that symlinks in UnixFS are rendered via Readlink.
func TestReadlink(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	// Build a directory containing a symlink.
	db, err := uio.NewDirectory(nd.DAG)
	if err != nil {
		t.Fatal(err)
	}

	target := "hello.txt"
	slData, err := ft.SymlinkData(target)
	if err != nil {
		t.Fatal(err)
	}
	symlinkNode := dag.NodeWithData(slData)
	if err := nd.DAG.Add(nd.Context(), symlinkNode); err != nil {
		t.Fatal(err)
	}
	if err := db.AddChild(nd.Context(), "link", symlinkNode); err != nil {
		t.Fatal(err)
	}

	dirNode, err := db.GetNode()
	if err != nil {
		t.Fatal(err)
	}
	if err := nd.DAG.Add(nd.Context(), dirNode); err != nil {
		t.Fatal(err)
	}

	linkPath := gopath.Join(mntDir, dirNode.Cid().String(), "link")
	got, err := os.Readlink(linkPath)
	if err != nil {
		t.Fatal(err)
	}
	if got != target {
		t.Fatalf("expected readlink %q, got %q", target, got)
	}
}

// Test that readdir reports symlinks with ModeSymlink so that
// tools like ls -l and find -type l see the correct file type.
func TestReaddirSymlink(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	db, err := uio.NewDirectory(nd.DAG)
	require.NoError(t, err)

	// Regular file child.
	fileData := []byte("hello")
	fileNode := dag.NodeWithData(ft.FilePBData(fileData, uint64(len(fileData))))
	require.NoError(t, nd.DAG.Add(nd.Context(), fileNode))
	require.NoError(t, db.AddChild(nd.Context(), "regular", fileNode))

	// Symlink child.
	slData, err := ft.SymlinkData("hello")
	require.NoError(t, err)
	symlinkNode := dag.NodeWithData(slData)
	require.NoError(t, nd.DAG.Add(nd.Context(), symlinkNode))
	require.NoError(t, db.AddChild(nd.Context(), "link", symlinkNode))

	dirNode, err := db.GetNode()
	require.NoError(t, err)
	require.NoError(t, nd.DAG.Add(nd.Context(), dirNode))

	entries, err := os.ReadDir(gopath.Join(mntDir, dirNode.Cid().String()))
	require.NoError(t, err)

	found := false
	for _, e := range entries {
		if e.Name() == "link" {
			require.NotZero(t, e.Type()&os.ModeSymlink, "readdir should report symlink type")
			found = true
		}
		if e.Name() == "regular" {
			require.Zero(t, e.Type()&os.ModeSymlink, "regular file should not have symlink type")
		}
	}
	require.True(t, found, "symlink entry not found in readdir")
}

// Test reading a slice from the middle of a file, skipping both
// the beginning and the end.
func TestSeekRead(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	obj, data := randObj(t, nd, 10000)
	fpath := gopath.Join(mntDir, obj.Cid().String())

	f, err := os.Open(fpath)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()

	off := int64(3000)
	readLen := 2000
	if _, err := f.Seek(off, io.SeekStart); err != nil {
		t.Fatal(err)
	}

	buf := make([]byte, readLen)
	n, err := io.ReadFull(f, buf)
	if err != nil {
		t.Fatal(err)
	}
	if n != readLen {
		t.Fatalf("short read: got %d, want %d", n, readLen)
	}
	if !bytes.Equal(buf, data[off:off+int64(readLen)]) {
		t.Fatal("content mismatch for middle slice")
	}
}

// Test that concurrent reads of the same large file produce correct data.
// The kernel sends multiple Read requests concurrently via readahead;
// without a mutex on roFileHandle the DagReader's internal state
// corrupts, causing data mismatches or panics.
func TestConcurrentLargeFileRead(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	// 1 MiB + 1 byte: large enough to span multiple DAG nodes and
	// trigger concurrent kernel readahead requests.
	fi, data := randObj(t, nd, 1024*1024+1)
	fpath := gopath.Join(mntDir, fi.Cid().String())

	// Multiple goroutines opening and reading the same file exercises
	// both per-handle serialization (Seek+Read within one handle) and
	// independent handle isolation (separate DagReaders).
	var wg sync.WaitGroup
	for range 8 {
		wg.Go(func() {
			got, err := os.ReadFile(fpath)
			if err != nil {
				t.Errorf("ReadFile: %v", err)
				return
			}
			if !bytes.Equal(got, data) {
				t.Errorf("data mismatch: got %d bytes, want %d", len(got), len(data))
			}
		})
	}
	wg.Wait()
}

// blockingDagReader is a uio.DagReader that blocks in CtxReadFull until
// the supplied context is cancelled. Used to verify that roFileHandle
// propagates cancellation from FUSE down to the underlying reader.
type blockingDagReader struct {
	entered chan struct{} // closed when CtxReadFull begins blocking
}

func (b *blockingDagReader) CtxReadFull(ctx context.Context, _ []byte) (int, error) {
	close(b.entered)
	<-ctx.Done()
	return 0, ctx.Err()
}

// Stub uio.DagReader methods that the test does not exercise. Returning
// zero values keeps roFileHandle.Read on the CtxReadFull path.
func (*blockingDagReader) Seek(int64, int) (int64, error)   { return 0, nil }
func (*blockingDagReader) Read([]byte) (int, error)         { return 0, io.EOF }
func (*blockingDagReader) Close() error                     { return nil }
func (*blockingDagReader) WriteTo(io.Writer) (int64, error) { return 0, nil }
func (*blockingDagReader) Size() uint64                     { return 0 }
func (*blockingDagReader) Mode() os.FileMode                { return 0 }
func (*blockingDagReader) ModTime() time.Time               { return time.Time{} }

var _ uio.DagReader = (*blockingDagReader)(nil)

// TestReadCancellationUnblocks confirms that cancelling the context
// passed to roFileHandle.Read returns promptly with EINTR. This guards
// the "killing a stuck cat works" fix: the kernel sends FUSE_INTERRUPT
// when a userspace process is killed mid-read, go-fuse cancels the
// per-request context, and the read handler must propagate cancellation
// down to the DagReader instead of blocking forever on a stuck fetch.
func TestReadCancellationUnblocks(t *testing.T) {
	fake := &blockingDagReader{entered: make(chan struct{})}
	fh := &roFileHandle{r: fake}

	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()

	type result struct {
		errno syscall.Errno
	}
	done := make(chan result, 1)
	go func() {
		buf := make([]byte, 4096)
		_, errno := fh.Read(ctx, buf, 0)
		done <- result{errno}
	}()

	// Wait for the fake reader to actually block on ctx.Done() before
	// cancelling, so the test exercises mid-read cancellation rather
	// than racing the goroutine start.
	select {
	case <-fake.entered:
	case <-time.After(5 * time.Second):
		t.Fatal("CtxReadFull never entered; cancellation path unreachable")
	}

	cancel() // simulates FUSE_INTERRUPT from the kernel

	select {
	case r := <-done:
		if r.errno != syscall.EINTR {
			t.Fatalf("expected EINTR after cancel, got errno %v", r.errno)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("roFileHandle.Read did not return after ctx cancel; cancellation is not propagated")
	}
}

// TestStatBlocks verifies that stat(2) on entries in /ipfs populates
// st_blocks (used by du and ls -s) consistent with the file size, and
// that st_blksize advertises the FUSE preferred I/O size.
func TestStatBlocks(t *testing.T) {
	nd, mntDir := setupIpfsTest(t, nil)

	t.Run("multi-block file", func(t *testing.T) {
		// >1 MiB spans several chunks, so the DAG has multiple leaf links.
		fi, data := randObj(t, nd, 1024*1024+1)
		require.Greater(t, len(data), 1024*1024)
		fusetest.AssertStatBlocks(t,
			gopath.Join(mntDir, fi.Cid().String()),
			fusemnt.DefaultBlksize)
	})

	t.Run("small single-chunk file", func(t *testing.T) {
		// <512 B fits in a single UnixFS chunk with no child links;
		// st_blocks still rounds up to 1 so du reports at least 512 B.
		fi, _ := randObj(t, nd, 100)
		fusetest.AssertStatBlocks(t,
			gopath.Join(mntDir, fi.Cid().String()),
			fusemnt.DefaultBlksize)
	})

	t.Run("directory", func(t *testing.T) {
		// du sums child leaves, so the directory's own st_blocks is not
		// arithmetically meaningful. Report a nominal 1 block so tools
		// that treat 0 as "unsupported" behave correctly.
		child, _ := randObj(t, nd, 100)

		db, err := uio.NewDirectory(nd.DAG)
		require.NoError(t, err)
		require.NoError(t, db.AddChild(nd.Context(), "f", child))
		dirNode, err := db.GetNode()
		require.NoError(t, err)
		require.NoError(t, nd.DAG.Add(nd.Context(), dirNode))

		info, err := os.Stat(gopath.Join(mntDir, dirNode.Cid().String()))
		require.NoError(t, err)
		st, ok := info.Sys().(*syscall.Stat_t)
		require.True(t, ok)
		require.EqualValues(t, 1, st.Blocks, "directory should report 1 nominal block")
	})

	t.Run("symlink", func(t *testing.T) {
		// UnixFS TSymlink node: Size is the target path length, Blocks
		// rounds up to 1 so tools don't see a zero-block symlink.
		const target = "hello.txt"

		slData, err := ft.SymlinkData(target)
		require.NoError(t, err)
		symNode := dag.NodeWithData(slData)
		require.NoError(t, nd.DAG.Add(nd.Context(), symNode))

		db, err := uio.NewDirectory(nd.DAG)
		require.NoError(t, err)
		require.NoError(t, db.AddChild(nd.Context(), "link", symNode))
		dirNode, err := db.GetNode()
		require.NoError(t, err)
		require.NoError(t, nd.DAG.Add(nd.Context(), dirNode))

		linkPath := gopath.Join(mntDir, dirNode.Cid().String(), "link")
		info, err := os.Lstat(linkPath)
		require.NoError(t, err)
		st, ok := info.Sys().(*syscall.Stat_t)
		require.True(t, ok)
		require.EqualValues(t, len(target), st.Size)
		require.EqualValues(t, 1, st.Blocks)
		require.EqualValues(t, fusemnt.DefaultBlksize, st.Blksize)
	})
}

// TestStatfs verifies that statfs on the /ipfs mount reports the disk
// space of the repo's backing filesystem. macOS Finder refuses to copy
// files onto a volume that reports zero free space.
func TestStatfs(t *testing.T) {
	nd, err := coremock.NewMockNode()
	require.NoError(t, err)

	// Point repoPath at a real directory so Statfs has a valid target.
	// (NewMockNode's in-memory repo returns "" for Path().)
	repoDir := t.TempDir()
	root := &Root{ipfs: nd, repoPath: repoDir}
	mntDir := testMount(t, root)

	fusetest.AssertStatfsNonZero(t, mntDir)
}

// Test that getxattr on an unknown attribute returns ENODATA (Linux) / ENOATTR.
func TestUnknownXattr(t *testing.T) {
	nd, _ := setupIpfsTest(t, nil)

	obj, _ := randObj(t, nd, 100)
	node := &Node{ipfs: nd, nd: obj, cid: obj.Cid()}

	dest := make([]byte, 256)
	_, errno := node.Getxattr(t.Context(), "user.bogus", dest)
	if errno == 0 {
		t.Fatal("expected error for unknown xattr, got success")
	}
}
