// SPDX-License-Identifier: SEL-1.0
// Copyright © 2025 Veda Tech Labs
// Derived from Boring Vault Software © 2025 Veda Tech Labs (TEST ONLY – NO COMMERCIAL USE)
// Licensed under Software Evaluation License, Version 1.0
pragma solidity 0.8.21;

import {FixedPointMathLib} from "@solmate/utils/FixedPointMathLib.sol";
import {ERC20} from "@solmate/tokens/ERC20.sol";
import {Strings} from "lib/openzeppelin-contracts/contracts/utils/Strings.sol";
import {ERC4626} from "@solmate/tokens/ERC4626.sol";
import {ManagerWithMerkleVerification} from "src/base/Roles/ManagerWithMerkleVerification.sol";
import {MerkleTreeHelper} from "test/resources/MerkleTreeHelper/MerkleTreeHelper.sol";
import "forge-std/Script.sol";

/**
 *  source .env && forge script script/MerkleRootCreation/Mainnet/CreateSuperSymbioticLRTMerkleRoot.s.sol:CreateSuperSymbioticLRTMerkleRootScript --rpc-url $MAINNET_RPC_URL
 */
contract CreateSuperSymbioticLRTMerkleRootScript is Script, MerkleTreeHelper {
    using FixedPointMathLib for uint256;

    address public boringVault = 0x917ceE801a67f933F2e6b33fC0cD1ED2d5909D88;
    address public managerAddress = 0xA24dD7B978Fbe36125cC4817192f7b8AA18d213c;
    address public accountantAddress = 0xbe16605B22a7faCEf247363312121670DFe5afBE;
    address public rawDataDecoderAndSanitizer = 0xa0f45529DdF2B4a17DD394Bd1459bbfb03f4E87E;
    address public oneInchOwnedDecoderAndSanitizer = 0x42842201E199E6328ADBB98e7C2CbE77561FAC88;
    address public odosOwnedDecoderAndSanitizer = 0x6149c711434C54A48D757078EfbE0E2B2FE2cF6a;

    function setUp() external {}

    /**
     * @notice Uncomment which script you want to run.
     */
    function run() external {
        /// NOTE Only have 1 function run at a time, otherwise the merkle root created will be wrong.
        generateAdminStrategistMerkleRoot();
        // generateSniperMerkleRoot();
    }

    function generateSniperMerkleRoot() public {
        setSourceChainName(mainnet);
        setAddress(false, mainnet, "boringVault", boringVault);
        setAddress(false, mainnet, "managerAddress", managerAddress);
        setAddress(false, mainnet, "accountantAddress", accountantAddress);
        setAddress(false, mainnet, "rawDataDecoderAndSanitizer", rawDataDecoderAndSanitizer);

        ManageLeaf[] memory leafs = new ManageLeaf[](16);
        leafIndex = type(uint256).max;
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "wstETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "cbETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "wBETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "rETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "mETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "swETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "sfrxETHDefaultCollateral"));
        _addSymbioticApproveAndDepositLeaf(leafs, getAddress(sourceChain, "ETHxDefaultCollateral"));
        // _addSymbioticApproveAndDepositLeaf(leafs, uniETHDefaultCollateral);

        string memory filePath = "./leafs/SuperSymbioticSniperLeafs.json";

        bytes32[][] memory manageTree = _generateMerkleTree(leafs);

        _generateLeafs(filePath, leafs, manageTree[manageTree.length - 1][0], manageTree);
    }

    function generateAdminStrategistMerkleRoot() public {
        setSourceChainName(mainnet);
        setAddress(false, mainnet, "boringVault", boringVault);
        setAddress(false, mainnet, "managerAddress", managerAddress);
        setAddress(false, mainnet, "accountantAddress", accountantAddress);
        setAddress(false, mainnet, "rawDataDecoderAndSanitizer", rawDataDecoderAndSanitizer);

        ManageLeaf[] memory leafs = new ManageLeaf[](1024);

        // ========================== Symbiotic ==========================
        address[] memory defaultCollaterals = new address[](8);
        defaultCollaterals[0] = getAddress(sourceChain, "wstETHDefaultCollateral");
        defaultCollaterals[1] = getAddress(sourceChain, "cbETHDefaultCollateral");
        defaultCollaterals[2] = getAddress(sourceChain, "wBETHDefaultCollateral");
        defaultCollaterals[3] = getAddress(sourceChain, "rETHDefaultCollateral");
        defaultCollaterals[4] = getAddress(sourceChain, "mETHDefaultCollateral");
        defaultCollaterals[5] = getAddress(sourceChain, "swETHDefaultCollateral");
        defaultCollaterals[6] = getAddress(sourceChain, "sfrxETHDefaultCollateral");
        defaultCollaterals[7] = getAddress(sourceChain, "ETHxDefaultCollateral");

        _addSymbioticLeafs(leafs, defaultCollaterals);

        // ========================== Lido ==========================
        _addLidoLeafs(leafs);

        // ========================== EtherFi ==========================
        _addEtherFiLeafs(leafs);

        // ========================== Native ==========================
        _addNativeLeafs(leafs);

        // ========================== FrxEth ==========================
        _addFraxLeafs(leafs);

        // ========================== swETH ==========================
        _addSwellStakingLeafs(leafs);

        // ========================== mETH ==========================
        _addMantleStakingLeafs(leafs);

        // ========================== UniswapV3 ==========================
        address[] memory token0 = new address[](66);
        token0[0] = getAddress(sourceChain, "WETH");
        token0[1] = getAddress(sourceChain, "WETH");
        token0[2] = getAddress(sourceChain, "WETH");
        token0[3] = getAddress(sourceChain, "WETH");
        token0[4] = getAddress(sourceChain, "WETH");
        token0[5] = getAddress(sourceChain, "WETH");
        token0[6] = getAddress(sourceChain, "WETH");
        token0[7] = getAddress(sourceChain, "WETH");
        token0[8] = getAddress(sourceChain, "WETH");
        token0[9] = getAddress(sourceChain, "WETH");
        token0[10] = getAddress(sourceChain, "WEETH");
        token0[11] = getAddress(sourceChain, "WEETH");
        token0[12] = getAddress(sourceChain, "WEETH");
        token0[13] = getAddress(sourceChain, "WEETH");
        token0[14] = getAddress(sourceChain, "WEETH");
        token0[15] = getAddress(sourceChain, "WEETH");
        token0[16] = getAddress(sourceChain, "WEETH");
        token0[17] = getAddress(sourceChain, "WEETH");
        token0[18] = getAddress(sourceChain, "WEETH");
        token0[19] = getAddress(sourceChain, "WSTETH");
        token0[20] = getAddress(sourceChain, "WSTETH");
        token0[21] = getAddress(sourceChain, "WSTETH");
        token0[22] = getAddress(sourceChain, "WSTETH");
        token0[23] = getAddress(sourceChain, "WSTETH");
        token0[24] = getAddress(sourceChain, "WSTETH");
        token0[25] = getAddress(sourceChain, "WSTETH");
        token0[26] = getAddress(sourceChain, "WSTETH");
        token0[27] = getAddress(sourceChain, "RETH");
        token0[28] = getAddress(sourceChain, "RETH");
        token0[29] = getAddress(sourceChain, "RETH");
        token0[30] = getAddress(sourceChain, "RETH");
        token0[31] = getAddress(sourceChain, "RETH");
        token0[32] = getAddress(sourceChain, "RETH");
        token0[33] = getAddress(sourceChain, "RETH");
        token0[34] = getAddress(sourceChain, "cbETH");
        token0[35] = getAddress(sourceChain, "cbETH");
        token0[36] = getAddress(sourceChain, "cbETH");
        token0[37] = getAddress(sourceChain, "cbETH");
        token0[38] = getAddress(sourceChain, "cbETH");
        token0[39] = getAddress(sourceChain, "cbETH");
        token0[40] = getAddress(sourceChain, "WBETH");
        token0[41] = getAddress(sourceChain, "WBETH");
        token0[42] = getAddress(sourceChain, "WBETH");
        token0[43] = getAddress(sourceChain, "WBETH");
        token0[44] = getAddress(sourceChain, "WBETH");
        token0[45] = getAddress(sourceChain, "METH");
        token0[46] = getAddress(sourceChain, "METH");
        token0[47] = getAddress(sourceChain, "METH");
        token0[48] = getAddress(sourceChain, "METH");
        token0[49] = getAddress(sourceChain, "SWETH");
        token0[50] = getAddress(sourceChain, "SWETH");
        token0[51] = getAddress(sourceChain, "SWETH");
        token0[52] = getAddress(sourceChain, "ETHX");
        token0[53] = getAddress(sourceChain, "ETHX");
        token0[54] = getAddress(sourceChain, "UNIETH");
        token0[55] = getAddress(sourceChain, "USDC");
        token0[56] = getAddress(sourceChain, "USDC");
        token0[57] = getAddress(sourceChain, "USDC");
        token0[58] = getAddress(sourceChain, "USDC");
        token0[59] = getAddress(sourceChain, "USDC");
        token0[60] = getAddress(sourceChain, "USDC");
        token0[61] = getAddress(sourceChain, "USDC");
        token0[62] = getAddress(sourceChain, "USDC");
        token0[63] = getAddress(sourceChain, "USDC");
        token0[64] = getAddress(sourceChain, "USDC");
        token0[65] = getAddress(sourceChain, "USDC");

        address[] memory token1 = new address[](66);
        token1[0] = getAddress(sourceChain, "WEETH");
        token1[1] = getAddress(sourceChain, "WSTETH");
        token1[2] = getAddress(sourceChain, "RETH");
        token1[3] = getAddress(sourceChain, "cbETH");
        token1[4] = getAddress(sourceChain, "WBETH");
        token1[5] = getAddress(sourceChain, "METH");
        token1[6] = getAddress(sourceChain, "SWETH");
        token1[7] = getAddress(sourceChain, "ETHX");
        token1[8] = getAddress(sourceChain, "UNIETH");
        token1[9] = getAddress(sourceChain, "SFRXETH");
        token1[10] = getAddress(sourceChain, "WSTETH");
        token1[11] = getAddress(sourceChain, "RETH");
        token1[12] = getAddress(sourceChain, "cbETH");
        token1[13] = getAddress(sourceChain, "WBETH");
        token1[14] = getAddress(sourceChain, "METH");
        token1[15] = getAddress(sourceChain, "SWETH");
        token1[16] = getAddress(sourceChain, "ETHX");
        token1[17] = getAddress(sourceChain, "UNIETH");
        token1[18] = getAddress(sourceChain, "SFRXETH");
        token1[19] = getAddress(sourceChain, "RETH");
        token1[20] = getAddress(sourceChain, "cbETH");
        token1[21] = getAddress(sourceChain, "WBETH");
        token1[22] = getAddress(sourceChain, "METH");
        token1[23] = getAddress(sourceChain, "SWETH");
        token1[24] = getAddress(sourceChain, "ETHX");
        token1[25] = getAddress(sourceChain, "UNIETH");
        token1[26] = getAddress(sourceChain, "SFRXETH");
        token1[27] = getAddress(sourceChain, "cbETH");
        token1[28] = getAddress(sourceChain, "WBETH");
        token1[29] = getAddress(sourceChain, "METH");
        token1[30] = getAddress(sourceChain, "SWETH");
        token1[31] = getAddress(sourceChain, "ETHX");
        token1[32] = getAddress(sourceChain, "UNIETH");
        token1[33] = getAddress(sourceChain, "SFRXETH");
        token1[34] = getAddress(sourceChain, "WBETH");
        token1[35] = getAddress(sourceChain, "METH");
        token1[36] = getAddress(sourceChain, "SWETH");
        token1[37] = getAddress(sourceChain, "ETHX");
        token1[38] = getAddress(sourceChain, "UNIETH");
        token1[39] = getAddress(sourceChain, "SFRXETH");
        token1[40] = getAddress(sourceChain, "METH");
        token1[41] = getAddress(sourceChain, "SWETH");
        token1[42] = getAddress(sourceChain, "ETHX");
        token1[43] = getAddress(sourceChain, "UNIETH");
        token1[44] = getAddress(sourceChain, "SFRXETH");
        token1[45] = getAddress(sourceChain, "SWETH");
        token1[46] = getAddress(sourceChain, "ETHX");
        token1[47] = getAddress(sourceChain, "UNIETH");
        token1[48] = getAddress(sourceChain, "SFRXETH");
        token1[49] = getAddress(sourceChain, "ETHX");
        token1[50] = getAddress(sourceChain, "UNIETH");
        token1[51] = getAddress(sourceChain, "SFRXETH");
        token1[52] = getAddress(sourceChain, "UNIETH");
        token1[53] = getAddress(sourceChain, "SFRXETH");
        token1[54] = getAddress(sourceChain, "SFRXETH");
        token1[55] = getAddress(sourceChain, "WEETH");
        token1[56] = getAddress(sourceChain, "WSTETH");
        token1[57] = getAddress(sourceChain, "RETH");
        token1[58] = getAddress(sourceChain, "cbETH");
        token1[59] = getAddress(sourceChain, "WBETH");
        token1[60] = getAddress(sourceChain, "METH");
        token1[61] = getAddress(sourceChain, "SWETH");
        token1[62] = getAddress(sourceChain, "ETHX");
        token1[63] = getAddress(sourceChain, "UNIETH");
        token1[64] = getAddress(sourceChain, "SFRXETH");
        token1[65] = getAddress(sourceChain, "WETH");

        _addUniswapV3Leafs(leafs, token0, token1, false);

        // ========================== 1inch ==========================
        address[] memory assets = new address[](14);
        SwapKind[] memory kind = new SwapKind[](14);
        assets[0] = getAddress(sourceChain, "WETH");
        kind[0] = SwapKind.BuyAndSell;
        assets[1] = getAddress(sourceChain, "WEETH");
        kind[1] = SwapKind.BuyAndSell;
        assets[2] = getAddress(sourceChain, "WSTETH");
        kind[2] = SwapKind.BuyAndSell;
        assets[3] = getAddress(sourceChain, "RETH");
        kind[3] = SwapKind.BuyAndSell;
        assets[4] = getAddress(sourceChain, "cbETH");
        kind[4] = SwapKind.BuyAndSell;
        assets[5] = getAddress(sourceChain, "WBETH");
        kind[5] = SwapKind.BuyAndSell;
        assets[6] = getAddress(sourceChain, "METH");
        kind[6] = SwapKind.BuyAndSell;
        assets[7] = getAddress(sourceChain, "SWETH");
        kind[7] = SwapKind.BuyAndSell;
        assets[8] = getAddress(sourceChain, "ETHX");
        kind[8] = SwapKind.BuyAndSell;
        assets[9] = getAddress(sourceChain, "UNIETH");
        kind[9] = SwapKind.BuyAndSell;
        assets[10] = getAddress(sourceChain, "SFRXETH");
        kind[10] = SwapKind.BuyAndSell;
        assets[11] = getAddress(sourceChain, "INST");
        kind[11] = SwapKind.Sell;
        assets[12] = getAddress(sourceChain, "FRXETH");
        kind[12] = SwapKind.BuyAndSell;
        assets[13] = getAddress(sourceChain, "USDC");
        kind[13] = SwapKind.Sell;

        setAddress(true, sourceChain, "rawDataDecoderAndSanitizer", oneInchOwnedDecoderAndSanitizer);
        _addLeafsFor1InchOwnedGeneralSwapping(leafs, assets, kind);

        // ========================== Odos ==========================
        setAddress(true, sourceChain, "rawDataDecoderAndSanitizer", odosOwnedDecoderAndSanitizer);
        _addOdosOwnedSwapLeafs(leafs, assets, kind);
        setAddress(true, sourceChain, "rawDataDecoderAndSanitizer", rawDataDecoderAndSanitizer);

        // ========================== EtherFi ==========================
        _addEtherFiLeafs(leafs);

        // ========================== Symbiotic Vault ==========================
        address[] memory vaults = new address[](2);
        vaults[0] = getAddress(sourceChain, "EtherFi_wstETHSymbioticVault");
        vaults[1] = getAddress(sourceChain, "EtherFi_Cap_weETHSymbioticVault");
        ERC20[] memory vault_assets = new ERC20[](2);
        vault_assets[0] = ERC20(getAddress(sourceChain, "WSTETH"));
        vault_assets[1] = ERC20(getAddress(sourceChain, "weETH"));

        // NOTE: No rewards for EtherFi wstETH vault for now.
        address[] memory rewards = new address[](0);
        _addSymbioticVaultLeafs(leafs, vaults, vault_assets, rewards);

        _verifyDecoderImplementsLeafsFunctionSelectors(leafs);

        string memory filePath = "./leafs/Mainnet/SuperSymbioticStrategistLeafs.json";

        bytes32[][] memory manageTree = _generateMerkleTree(leafs);

        _generateLeafs(filePath, leafs, manageTree[manageTree.length - 1][0], manageTree);
    }
}
