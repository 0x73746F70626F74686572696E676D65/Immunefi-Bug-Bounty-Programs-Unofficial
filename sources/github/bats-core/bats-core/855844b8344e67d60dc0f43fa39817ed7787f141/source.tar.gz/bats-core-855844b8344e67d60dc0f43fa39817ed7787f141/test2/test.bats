@test "fail" {
	echo success!
}
