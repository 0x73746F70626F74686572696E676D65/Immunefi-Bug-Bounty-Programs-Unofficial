setup_suite() {
	false
}
