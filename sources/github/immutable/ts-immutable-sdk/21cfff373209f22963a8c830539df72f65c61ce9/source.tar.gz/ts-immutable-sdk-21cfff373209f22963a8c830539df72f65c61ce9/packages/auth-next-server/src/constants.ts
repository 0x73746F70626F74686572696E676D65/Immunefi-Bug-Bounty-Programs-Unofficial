/**
 * Shared constants for @imtbl/auth-next-server
 */

/**
 * Default Immutable authentication domain
 */
export const DEFAULT_AUTH_DOMAIN = 'https://auth.immutable.com';

/**
 * Default OAuth audience
 */
export const DEFAULT_AUDIENCE = 'platform_api';

/**
 * Default OAuth scopes
 */
export const DEFAULT_SCOPE = 'openid profile email offline_access transact';

/**
 * NextAuth credentials provider ID for Immutable
 */
export const IMMUTABLE_PROVIDER_ID = 'immutable';

/**
 * Default NextAuth API base path
 */
export const DEFAULT_NEXTAUTH_BASE_PATH = '/api/auth';

/**
 * Default token expiry in seconds (15 minutes)
 * Used as fallback when exp claim cannot be extracted from JWT
 */
export const DEFAULT_TOKEN_EXPIRY_SECONDS = 900;

/**
 * Default token expiry in milliseconds
 */
export const DEFAULT_TOKEN_EXPIRY_MS = DEFAULT_TOKEN_EXPIRY_SECONDS * 1000;

/**
 * Buffer time in seconds before token expiry to trigger refresh
 * Tokens will be refreshed when they expire within this window
 */
export const TOKEN_EXPIRY_BUFFER_SECONDS = 60;

/**
 * Buffer time in milliseconds before token expiry to trigger refresh.
 * Used by auth-next-client for client-side refresh timing.
 */
export const TOKEN_EXPIRY_BUFFER_MS = TOKEN_EXPIRY_BUFFER_SECONDS * 1000;

/**
 * Default session max age in seconds (365 days)
 * This is how long the NextAuth session cookie will be valid
 */
export const DEFAULT_SESSION_MAX_AGE_SECONDS = 365 * 24 * 60 * 60;

/**
 * Sandbox client ID for auth-next zero-config.
 */
export const DEFAULT_SANDBOX_CLIENT_ID = 'mjtCL8mt06BtbxSkp2vbrYStKWnXVZfo';

/**
 * Default redirect URI path for sandbox zero-config.
 */
export const DEFAULT_REDIRECT_URI_PATH = '/callback';

/**
 * Default logout redirect URI path
 */
export const DEFAULT_LOGOUT_REDIRECT_URI_PATH = '/';
