export { Audience } from './sdk';
export { AudienceEvents } from './events';
export {
  CONVERSION_ID_PROPERTY,
  CONVERSION_NETWORK_PROPERTY,
  DEDUP_CAPABLE_NETWORKS,
} from './conversion';
export type { ConversionResult } from './conversion';
export {
  IdentityType,
  canTrack,
  canIdentify,
  AudienceError,
  getAttributionNetwork,
  collectPageAttribution,
  clearAttribution,
} from '@imtbl/audience-core';
export type { ImmutableAudienceGlobal } from './cdn';
export type { AudienceConfig } from './types';
export type {
  Attribution, AudienceErrorCode, AutocaptureOptions, AttributionNetwork,
} from '@imtbl/audience-core';
export type {
  AchievementType,
  AchievementUnlockedProperties,
  AudienceEventName,
  EmailAcquiredProperties,
  GameLaunchProperties,
  GamePageViewedProperties,
  LinkClickedProperties,
  ProgressionProperties,
  ProgressionStatus,
  PropsFor,
  PurchaseProperties,
  ResourceFlow,
  ResourceProperties,
  SignInProperties,
  SignUpProperties,
  WishlistAddProperties,
  WishlistRemoveProperties,
} from './events';
export type { ConsentLevel, UserTraits } from '@imtbl/audience-core';
