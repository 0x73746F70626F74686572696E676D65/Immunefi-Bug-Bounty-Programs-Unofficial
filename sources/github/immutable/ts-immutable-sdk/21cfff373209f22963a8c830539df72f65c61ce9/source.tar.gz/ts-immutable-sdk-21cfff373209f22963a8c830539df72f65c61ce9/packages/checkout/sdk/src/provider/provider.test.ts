/*
 * @jest-environment jsdom
 */
import { BrowserProvider } from 'ethers';
import { Passport } from '@imtbl/passport';
import detectEthereumProvider from '@metamask/detect-provider';
import { CheckoutErrorType } from '../errors';
import { WalletProviderName } from '../types';
import { createProvider } from './provider';
import { InjectedProvidersManager } from './injectedProvidersManager';

jest.mock('@metamask/detect-provider', () => jest.fn());

jest.mock('./injectedProvidersManager', () => ({
  // eslint-disable-next-line @typescript-eslint/naming-convention
  InjectedProvidersManager: {
    getInstance: jest.fn(),
  },
}));

describe('createProvider', () => {
  const providerRequestMock: jest.Mock = jest.fn();
  const mockFindProvider = jest.fn().mockReturnValue(null);
  const mockDetectEthereumProvider = detectEthereumProvider as jest.MockedFunction<
    typeof detectEthereumProvider
  >;

  beforeEach(() => {
    Object.defineProperty(window, 'ethereum', {
      configurable: true,
      writable: true,
      value: {
        request: providerRequestMock,
        isMetaMask: true,
      },
    });

    jest.spyOn(console, 'error').mockImplementation(() => {});

    mockFindProvider.mockReturnValue(null);
    mockDetectEthereumProvider.mockResolvedValue(window.ethereum as any);
    jest.spyOn(InjectedProvidersManager as any, 'getInstance')
      .mockImplementation(() => ({
        findProvider: mockFindProvider,
      }));
  });

  afterEach(() => {
    delete (window as any).ethereum;
    jest.resetAllMocks();
  });

  it('should create a provider for Passport with a valid passport instance', async () => {
    const mockPassport = {
      connectEvm: jest.fn(() => ({ request: jest.fn(), isPassport: true })),
    } as unknown as Passport;
    const result = await createProvider(WalletProviderName.PASSPORT, mockPassport);

    expect(result.provider).toBeInstanceOf(BrowserProvider);
    expect(result.walletProviderName).toBe(WalletProviderName.PASSPORT);
    expect(mockPassport.connectEvm).toHaveBeenCalled();
  });

  it('should create a provider for Passport when Passport is injected via EIP-6963', async () => {
    mockFindProvider.mockReturnValue({ provider: { request: jest.fn(), isPassport: true } });
    const result = await createProvider(WalletProviderName.PASSPORT);

    expect(result.provider).toBeInstanceOf(BrowserProvider);
    expect(result.walletProviderName).toBe(WalletProviderName.PASSPORT);
  });

  it('should create a provider for Metamask when Metamask is injected via EIP-6963', async () => {
    mockFindProvider.mockReturnValue({ provider: { request: jest.fn(), isMetaMask: true } });
    const result = await createProvider(WalletProviderName.METAMASK);

    expect(result.provider).toBeInstanceOf(BrowserProvider);
    expect(result.walletProviderName).toBe(WalletProviderName.METAMASK);
  });

  it('should throw an error if connect is called with a preference that is not expected', async () => {
    try {
      await createProvider('trust-wallet' as WalletProviderName);
    } catch (err: any) {
      expect(err.message).toEqual('Provider not supported');
      expect(err.type).toEqual(CheckoutErrorType.DEFAULT_PROVIDER_ERROR);
    }
  });

  it('should throw an error if metamask provider is not found', async () => {
    mockDetectEthereumProvider.mockResolvedValue(null);

    try {
      await createProvider(WalletProviderName.METAMASK);
    } catch (err: any) {
      expect(err.message).toEqual('No MetaMask provider installed.');
      expect(err.type).toEqual(CheckoutErrorType.METAMASK_PROVIDER_ERROR);
    }
  });

  it('should throw an error if provider.request is not found', async () => {
    mockDetectEthereumProvider.mockResolvedValue({} as any);

    try {
      await createProvider(WalletProviderName.METAMASK);
    } catch (err: any) {
      expect(err.message).toEqual('No MetaMask provider installed.');
      expect(err.type).toEqual(CheckoutErrorType.METAMASK_PROVIDER_ERROR);
    }
  });
});
