export type {
  Surface,
  MessageType,
  EventContext,
  UserTraits,
  TrackMessage,
  PageMessage,
  IdentifyMessage,
  AliasMessage,
  Message,
  BatchPayload,
  ConsentLevel,
  ConsentStatus,
} from './types';
export { IdentityType } from './types';

export {
  getOrCreateAnonymousId,
  getCookie,
  deleteCookie,
} from './cookie';

export {
  BASE_URL,
  COOKIE_NAME,
  SESSION_COOKIE,
} from './config';

export { generateId, getTimestamp, isBrowser } from './utils';

export type { HttpSend, TransportOptions } from './transport';
export { httpSend } from './transport';
export type {
  TransportResult, AudienceErrorCode, RejectionError, MessageRejection,
} from './errors';
export { TransportError, AudienceError, invokeOnError } from './errors';
export { MessageQueue, clearLegacyQueue } from './queue';
export { collectContext } from './context';
export {
  isTimestampValid,
  isAliasValid,
  isPassportIdValid,
  isValidConsentLevel,
  isValidIdentityType,
  hasValue,
  truncate,
} from './validation';

export { getOrCreateSessionId } from './session';

export {
  collectSessionAttribution,
  collectPageAttribution,
  clearAttribution,
  clearLegacyAttribution,
  getAttributionNetwork,
} from './attribution';
export type { Attribution, AttributionNetwork } from './attribution';

export { collectThirdPartyIds } from './thirdPartyIds';

export { setupAutocapture } from './autocapture';
export type { AutocaptureOptions } from './autocapture';

export {
  createConsentManager, detectDoNotTrack,
  canTrack, canIdentify,
} from './consent';
export type { ConsentManager } from './consent';

export { detectCmp, startCmpDetection } from './cmp';
export type { CmpSource, ConsentCallback, CmpDetector } from './cmp';
