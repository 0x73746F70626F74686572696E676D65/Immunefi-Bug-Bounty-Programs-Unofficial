import { Audience, AudienceEvents } from './index';

declare const sdk: Audience;

sdk.track('sign_up');
sdk.track('sign_up', { method: 'email' });
sdk.track('sign_in');
sdk.track('sign_in', { method: 'passport' });
sdk.track('wishlist_add', { game_id: 'abc' });
sdk.track('wishlist_add', { game_id: 'abc', source: 'game_page', platform: 'steam' });
sdk.track('wishlist_remove', { game_id: 'abc' });
sdk.track('purchase', { currency: 'USD', value: '9.99' });
sdk.track('purchase', {
  currency: 'USD',
  value: '9.99',
  item_id: 'sku_1',
  item_name: 'Gold Pack',
  quantity: 2,
  transaction_id: 'txn_42',
});
sdk.track('game_launch');
sdk.track('game_launch', { platform: 'webgl', version: '1.2.0', build_id: 'ci-42' });
sdk.track('progression', { status: 'start' });
sdk.track('progression', { status: 'complete', world: 'tutorial' });
sdk.track('progression', {
  status: 'fail',
  world: 'forest',
  level: '5',
  stage: 'boss',
  score: 420,
  duration_sec: 87,
});
sdk.track('resource', { flow: 'sink', currency: 'gold', amount: 50 });
sdk.track('resource', {
  flow: 'source',
  currency: 'USD',
  amount: 9.99,
  item_type: 'iap',
  item_id: 'sku_1',
});
sdk.track('email_acquired');
sdk.track('email_acquired', { source: 'linked_account_steam' });
sdk.track('game_page_viewed', { game_id: 'abc' });
sdk.track('game_page_viewed', { game_id: 'abc', game_name: 'Devilfish', slug: 'devilfish' });
sdk.track('link_clicked', { url: 'https://example.com' });
sdk.track('link_clicked', {
  url: 'https://example.com',
  label: 'Play Now',
  source: 'game_page',
});

// @ts-expect-error — unknown property 'game_id'
sdk.track('link_clicked', { url: 'https://example.com', game_id: 'abc' });

sdk.track(AudienceEvents.SIGN_UP, { method: 'email' });
sdk.track(AudienceEvents.PURCHASE, { currency: 'USD', value: '9.99' });
sdk.track(AudienceEvents.PROGRESSION, { status: 'complete' });
sdk.track(AudienceEvents.ACHIEVEMENT_UNLOCKED, { achievement_id: 'first_win', achievement_name: 'First Win' });
sdk.track('achievement_unlocked', { achievement_id: 'first_win', achievement_name: 'First Win' });
sdk.track('achievement_unlocked', {
  achievement_id: 'first_win',
  achievement_name: 'First Win',
  achievement_type: 'progression',
});

// @ts-expect-error — missing required 'value'
sdk.track('purchase', { currency: 'USD' });

// @ts-expect-error — missing required 'game_id'
sdk.track('wishlist_add', {});

// @ts-expect-error — missing required 'status'
sdk.track('progression', { world: 'tutorial' });

// @ts-expect-error — missing required 'flow', 'currency', 'amount'
sdk.track('resource', { item_type: 'iap' });

// @ts-expect-error — missing required 'url'
sdk.track('link_clicked', { label: 'Play Now' });

// @ts-expect-error — missing required 'game_id'
sdk.track('game_page_viewed', {});

// @ts-expect-error — purchase requires properties
sdk.track('purchase');

// @ts-expect-error — wishlist_add requires properties
sdk.track('wishlist_add');

// @ts-expect-error — wishlist_remove requires properties
sdk.track('wishlist_remove');

// @ts-expect-error — progression requires properties
sdk.track('progression');

// @ts-expect-error — resource requires properties
sdk.track('resource');

// @ts-expect-error — game_page_viewed requires properties
sdk.track('game_page_viewed');

// @ts-expect-error — link_clicked requires properties
sdk.track('link_clicked');

// @ts-expect-error — unknown property 'currenyc'
sdk.track('purchase', { currenyc: 'USD', value: '9.99' });

// @ts-expect-error — unknown property 'extra'
sdk.track('purchase', { currency: 'USD', value: '9.99', extra: 1 });

// @ts-expect-error — unknown property 'isLoggedIn'
sdk.track('link_clicked', { url: 'x', isLoggedIn: true });

// @ts-expect-error — 'value' must be a string
sdk.track('purchase', { currency: 'USD', value: 9.99 });

// @ts-expect-error — 'status' must be a ProgressionStatus
sdk.track('progression', { status: 'done' });

// @ts-expect-error — 'flow' must be a ResourceFlow
sdk.track('resource', { flow: 'both', currency: 'gold', amount: 1 });

// @ts-expect-error — missing required 'achievement_id'
sdk.track('achievement_unlocked', { achievement_name: 'First Win' });

// @ts-expect-error — missing required 'achievement_name'
sdk.track('achievement_unlocked', { achievement_id: 'first_win' });

// @ts-expect-error — achievement_unlocked requires properties
sdk.track('achievement_unlocked');

// @ts-expect-error — 'achievement_type' must be a valid AchievementType
sdk.track('achievement_unlocked', { achievement_id: 'x', achievement_name: 'X', achievement_type: 'invalid' });

sdk.track('beta_key_redeemed', { source: 'influencer' });
sdk.track('discord_joined');
sdk.track('trailer_watched', { duration: 45, platform: 'youtube' });

declare const dynamicName: string;
sdk.track(dynamicName, { anything: 'goes' });
sdk.track(dynamicName);
