# Imx.Sdk.Gen.Model.ListMintsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cursor** | **string** | Generated cursor returned by previous query | 
**Remaining** | **int** | Remaining results flag. 1: there are remaining results matching this query, 0: no remaining results | 
**Result** | [**List&lt;Mint&gt;**](Mint.md) | Mints matching query parameters | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

