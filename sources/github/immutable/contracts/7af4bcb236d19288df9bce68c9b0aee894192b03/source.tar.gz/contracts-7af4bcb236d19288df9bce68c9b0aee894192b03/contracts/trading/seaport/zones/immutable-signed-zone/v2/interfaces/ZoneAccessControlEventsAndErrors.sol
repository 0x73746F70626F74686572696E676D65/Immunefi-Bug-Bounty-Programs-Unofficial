// Copyright (c) Immutable Pty Ltd 2018 - 2026
// SPDX-License-Identifier: Apache-2
pragma solidity ^0.8.17;

/**
 * @notice ZoneAccessControlEventsAndErrors contains errors and events
 *         related to zone access control.
 */
interface ZoneAccessControlEventsAndErrors {
    /**
     * @dev Revert with an error if revoking last DEFAULT_ADMIN_ROLE.
     */
    error LastDefaultAdminRole(address account);
}
