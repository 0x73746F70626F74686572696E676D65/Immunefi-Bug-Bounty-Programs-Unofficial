// Copyright Immutable Pty Ltd 2018 - 2026
// SPDX-License-Identifier: GPL-3.0
pragma solidity >=0.8.19 <=0.8.27;

import {IWIMX} from "./IWIMX.sol";
import {Address} from "openzeppelin-contracts-5/utils/Address.sol";

/**
 * @notice WIMX is a wrapped IMX contract that allows users to wrap their native IMX.
 * @dev This contract is adapted from the official Wrapped ETH contract.
 * This contract is copied from https://github.com/immutable/zkevm-bridge-contracts/blob/main/src/child/WIMX.sol
 */
contract WIMX is IWIMX {
    // slither-disable-start constable-states
    string public name = "Wrapped IMX";
    string public symbol = "WIMX";
    uint8 public decimals = 18;
    // slither-disable-end constable-states

    mapping(address account => uint256 balance) public balanceOf;
    mapping(address account => mapping(address spender => uint256 amount)) public allowance;

    /**
     * @notice Fallback function on receiving native IMX.
     */
    receive() external payable {
        deposit();
    }

    /**
     * @notice Deposit native IMX in the function call and mint the equal amount of wrapped IMX to msg.sender.
     */
    function deposit() public payable {
        balanceOf[msg.sender] += msg.value;
        emit Deposit(msg.sender, msg.value);
    }

    /**
     * @notice Withdraw given amount of native IMX to msg.sender and burn the equal amount of wrapped IMX.
     * @param wad The amount to withdraw.
     */
    // slither-disable-start reentrancy-events
    function withdraw(uint256 wad) public {
        require(balanceOf[msg.sender] >= wad, "Wrapped IMX: Insufficient balance");
        balanceOf[msg.sender] -= wad;

        Address.sendValue(payable(msg.sender), wad);
        emit Withdrawal(msg.sender, wad);
    }

    // slither-disable-end reentrancy-events

    /**
     * @notice Obtain the current total supply of wrapped IMX.
     * @return uint The amount of supplied wrapped IMX.
     */
    function totalSupply() public view returns (uint256) {
        return address(this).balance;
    }

    /**
     * @notice Approve given spender the ability to spend a given amount of msg.sender's tokens.
     * @param guy Approved spender.
     * @param wad Amount of allowance.
     * @return bool Returns true if function call is successful.
     */
    function approve(address guy, uint256 wad) public returns (bool) {
        allowance[msg.sender][guy] = wad;
        emit Approval(msg.sender, guy, wad);
        return true;
    }

    /**
     * @notice Transfer given amount of tokens from msg.sender to given destination.
     * @param dst Destination of this transfer.
     * @param wad Amount of this transfer.
     * @return bool Returns true if function call is successful.
     */
    function transfer(address dst, uint256 wad) public returns (bool) {
        return transferFrom(msg.sender, dst, wad);
    }

    /**
     * @notice Transfer given amount of tokens from given source to given destination.
     * @param src Source of this transfer.
     * @param dst Destination of this transfer.
     * @param wad Amount of this transfer.
     * @return bool Returns true if function call is successful.
     */
    function transferFrom(address src, address dst, uint256 wad) public returns (bool) {
        require(balanceOf[src] >= wad, "Wrapped IMX: Insufficient balance");

        if (src != msg.sender && allowance[src][msg.sender] != type(uint256).max) {
            require(allowance[src][msg.sender] >= wad, "Wrapped IMX: Insufficient allowance");
            allowance[src][msg.sender] -= wad;
        }

        balanceOf[src] -= wad;
        balanceOf[dst] += wad;

        emit Transfer(src, dst, wad);

        return true;
    }
}
