// Copyright Immutable Pty Ltd 2018 - 2026
// SPDX-License-Identifier: Apache 2.0
pragma solidity >=0.8.19 <=0.8.27;

import {IImmutableERC721ByQuantity} from "./IImmutableERC721ByQuantity.sol";

interface IImmutableERC721ByQuantityV2 is IImmutableERC721ByQuantity {
    /**
     * @notice returns the next token id that will be minted for the first
     *  NFT in a call to mintByQuantity or safeMintByQuantity.
     */
    function mintBatchByQuantityNextTokenId() external pure returns (uint256);
}
