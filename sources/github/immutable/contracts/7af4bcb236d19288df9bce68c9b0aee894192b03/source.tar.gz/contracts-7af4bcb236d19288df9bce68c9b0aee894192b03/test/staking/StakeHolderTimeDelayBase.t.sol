// Copyright Immutable Pty Ltd 2018 - 2026
// SPDX-License-Identifier: Apache 2.0
pragma solidity >=0.8.19 <=0.8.27;

import {IStakeHolder} from "../../contracts/staking/IStakeHolder.sol";
import {StakeHolderBaseTest} from "./StakeHolderBase.t.sol";
import {TimelockController} from "openzeppelin-contracts-5/governance/TimelockController.sol";
import {UUPSUpgradeable} from "openzeppelin-contracts-upgradeable-4/proxy/utils/UUPSUpgradeable.sol";
import {StakeHolderBase} from "../../contracts/staking/StakeHolderBase.sol";

abstract contract StakeHolderTimeDelayBaseTest is StakeHolderBaseTest {
    TimelockController stakeHolderTimeDelay;

    uint256 delay = 604800; // 604800 seconds = 1 week

    address adminProposer;
    address adminExecutor;

    function setUp() public virtual override {
        super.setUp();

        adminProposer = makeAddr("adminProposer");
        adminExecutor = makeAddr("adminExecutor");

        address[] memory proposers = new address[](1);
        proposers[0] = adminProposer;
        address[] memory executors = new address[](1);
        executors[0] = adminExecutor;

        stakeHolderTimeDelay = new TimelockController(delay, proposers, executors, address(0));
    }

    function testTimeLockControllerDeployment() public view {
        assertEq(stakeHolderTimeDelay.getMinDelay(), delay, "Incorrect time delay");
    }

    function testUpgradeToV2() public {
        IStakeHolder v2Impl = _deployV2();

        bytes memory callData = abi.encodeWithSelector(StakeHolderBase.upgradeStorage.selector, bytes(""));
        bytes memory upgradeCall =
            abi.encodeWithSelector(UUPSUpgradeable.upgradeToAndCall.selector, address(v2Impl), callData);

        address target = address(stakeHolder);
        uint256 value = 0;
        bytes memory data = upgradeCall;
        bytes32 predecessor = bytes32(0);
        bytes32 salt = bytes32(uint256(1));
        uint256 theDelay = delay;

        uint256 timeNow = block.timestamp;

        vm.prank(adminProposer);
        stakeHolderTimeDelay.schedule(target, value, data, predecessor, salt, theDelay);

        vm.warp(timeNow + delay);

        vm.prank(adminExecutor);
        stakeHolderTimeDelay.execute(target, value, data, predecessor, salt);

        uint256 ver = stakeHolder.version();
        assertEq(ver, 2, "Upgrade did not upgrade version 2");
    }

    function testUpgradeToV3() public {
        testUpgradeToV2();

        IStakeHolder v3Impl = _deployV3();

        bytes memory callData = abi.encodeWithSelector(StakeHolderBase.upgradeStorage.selector, bytes(""));
        bytes memory upgradeCall =
            abi.encodeWithSelector(UUPSUpgradeable.upgradeToAndCall.selector, address(v3Impl), callData);

        address target = address(stakeHolder);
        uint256 value = 0;
        bytes memory data = upgradeCall;
        bytes32 predecessor = bytes32(0);
        bytes32 salt = bytes32(uint256(2));
        uint256 theDelay = delay;

        uint256 timeNow = block.timestamp;

        vm.prank(adminProposer);
        stakeHolderTimeDelay.schedule(target, value, data, predecessor, salt, theDelay);

        vm.warp(timeNow + delay);

        vm.prank(adminExecutor);
        stakeHolderTimeDelay.execute(target, value, data, predecessor, salt);

        uint256 ver = stakeHolder.version();
        assertEq(ver, 3, "Upgrade did not upgrade version 3");
    }

    function testTooShortDelay() public {
        IStakeHolder v2Impl = _deployV2();

        bytes memory initData = abi.encodeWithSelector(StakeHolderBase.upgradeStorage.selector, bytes(""));
        bytes memory upgradeCall =
            abi.encodeWithSelector(UUPSUpgradeable.upgradeToAndCall.selector, address(v2Impl), initData);

        address target = address(stakeHolder);
        uint256 value = 0;
        bytes memory data = upgradeCall;
        bytes32 predecessor = bytes32(0);
        bytes32 salt = bytes32(uint256(1));
        uint256 theDelay = delay - 1; // Too small

        vm.expectRevert(abi.encodeWithSelector(TimelockController.TimelockInsufficientDelay.selector, theDelay, delay));
        vm.prank(adminProposer);
        stakeHolderTimeDelay.schedule(target, value, data, predecessor, salt, theDelay);
    }

    function testExecuteEarly() public {
        IStakeHolder v2Impl = _deployV2();

        bytes memory initData = abi.encodeWithSelector(StakeHolderBase.upgradeStorage.selector, bytes(""));
        bytes memory upgradeCall =
            abi.encodeWithSelector(UUPSUpgradeable.upgradeToAndCall.selector, address(v2Impl), initData);

        address target = address(stakeHolder);
        uint256 value = 0;
        bytes memory data = upgradeCall;
        bytes32 predecessor = bytes32(0);
        bytes32 salt = bytes32(uint256(1));
        uint256 theDelay = delay;

        uint256 timeNow = block.timestamp;

        vm.prank(adminProposer);
        stakeHolderTimeDelay.schedule(target, value, data, predecessor, salt, theDelay);

        bytes32 operationId = stakeHolderTimeDelay.hashOperation(target, value, data, predecessor, salt);

        /// forge-lint: disable-next-line(incorrect-shift)
        bytes32 stateMask = bytes32(1 << uint8(TimelockController.OperationState.Ready));
        vm.expectRevert(
            abi.encodeWithSelector(TimelockController.TimelockUnexpectedOperationState.selector, operationId, stateMask)
        );
        vm.warp(timeNow + delay - 1); // Too early
        vm.prank(adminExecutor);
        stakeHolderTimeDelay.execute(target, value, data, predecessor, salt);
    }

    function _deployV2() internal virtual returns (IStakeHolder);
    function _deployV3() internal virtual returns (IStakeHolder);
}
