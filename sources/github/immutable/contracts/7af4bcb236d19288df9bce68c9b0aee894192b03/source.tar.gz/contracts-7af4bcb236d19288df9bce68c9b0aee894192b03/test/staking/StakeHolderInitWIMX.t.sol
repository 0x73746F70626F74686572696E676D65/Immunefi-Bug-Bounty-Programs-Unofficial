// Copyright Immutable Pty Ltd 2018 - 2026
// SPDX-License-Identifier: Apache 2.0
pragma solidity >=0.8.19 <=0.8.27;

import {StakeHolderInitBaseTest} from "./StakeHolderInitBase.t.sol";

contract StakeHolderInitWIMXTest is StakeHolderInitBaseTest {
    function setUp() public override {
        super.setUp();
        deployWIMX();
        deployStakeHolderWIMXV1();
    }
}
