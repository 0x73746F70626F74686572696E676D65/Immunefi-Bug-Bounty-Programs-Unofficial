import { AlchemyProvider, JsonRpcProvider } from '@ethersproject/providers';

export function getEnv(
  name: string,
  defaultValue: string | undefined = undefined,
): string {
  const value = process.env[name];

  if (value !== undefined) {
    return value;
  }
  if (defaultValue !== undefined) {
    return defaultValue;
  }
  throw new Error(`Environment variable '${name}' not set`);
}

export function requireEnvironmentVariable(key: string): string {
  const value = getEnv(key);
  if (!value) {
    throw new Error(`Please ensure a value exists for ${key}`);
  }
  return value;
}

export function validateString<T extends string>(
  val: string,
  validValues: readonly string[],
): T {
  const res = validValues.indexOf(val);
  if (res < 0) {
    throw Error(`${val} is not one of ${validValues}`);
  }
  return val as T;
}

export function getProvider(
  network: string,
  alchemyKey: string,
): JsonRpcProvider {
  if (network !== 'sepolia') {
    return new AlchemyProvider(network, alchemyKey);
  }

  return new JsonRpcProvider(
    `https://eth-sepolia.g.alchemy.com/v2/${alchemyKey}`,
    {
      name: 'sepolia',
      chainId: 11155111,
    },
  );
}
