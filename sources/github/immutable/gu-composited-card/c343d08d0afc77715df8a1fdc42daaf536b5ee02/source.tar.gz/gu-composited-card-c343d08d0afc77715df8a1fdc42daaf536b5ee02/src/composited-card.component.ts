import { LitElement, html, customElement, property } from 'lit-element';
import { ResizeObserver } from '@juggle/resize-observer';

import {
  loadingTemplate,
  mythicImageLayersTemplate,
  nonMythicImageLayersTemplate,
  baseArtworkLayersTemplate,
  textLayersTemplate,

  baseArtworkLayersCompositionTemplate,
  imageLayersCompositionTemplate,
  textLayersCompositionTemplate,
  profileArtworkLayersCompositionTemplate
} from './templating';

import './assets/fonts.css';
import { getStyles } from './styles';
import { type } from 'os';

export interface IResolutionSettings {
  lowDpi: number;
  highDpi: number;
}

export interface ICardProtoData {
  type: string;
  effect: string;
  name: string;
  rarity: string;
  god: string;
  set: string;
  tribe: string;
  mana: string;
  id: string;
  attack: number;
  health: number;
  art_id: string;
}

export interface ICompositionData {
  illustration?: string[];
  frame?: string[];
  rosette?: string[];
  gems?: string[];
  wreath?: string[];
  lock?: string[];
  tribe_bar?: string[];
  set?: string[];
  profile?: string[];
}

export interface ICardCompsitionData extends ICardProtoData {
  composition: ICompositionData;
}

// @TODO: these should really come from an endpoint call,
// so that we can easily update them in the future...
export const legacyQualities = [
  'plain',
  // @NOTE: there may be "0" quality items in future, for now, these items
  // can use the plain layer imagery assets
  'plain',
  'bronze',
  'iron',
  'meteorite',
  'shadow',
  'gold',
  'diamond',
];

export const qualities = ['diamond', 'gold', 'shadow', 'meteorite', 'plain'];

// Card data can arrive either pre-flattened to a plain string (eg. from
// consumers that already resolved it) or as the raw backend shape
// { String, Valid } (eg. raw composition API data passed straight into
// inputCompositionData/inputProtoData) — normalize both to a plain string.
function normalizeTribe(tribe: unknown): string {
  if (tribe && typeof tribe === 'object') {
    const { Valid, String: tribeString } = tribe as { Valid?: boolean; String?: string };
    return Valid && tribeString ? tribeString : '';
  }
  return (tribe as string) || '';
}

// Deploy a native ResizeOberver for this component instance:
const ro = new ResizeObserver((entries) => {
  entries.forEach((entry) => {
    const el = entry.target as CompositedCard;
    el.handleResize(entry);
  });
});

/**
 *
 * GU Composited Card Web Component
 * -----------------------------------------------------------------
 *
 * A simple, framework agnostic web component to facilitate the
 * display of Gods Unchained card element(s).
 *
 * @customElement
 * @demo https://immutable.github.io/gu-composited-card/
 *
 * @input protoId
 * @input quality
 * @input inputProtoData
 * @input responsiveSrcsetSizes
 * @input useLegacyQualityMapping
 * @input compositionVersion
 *
 * @author Tim Paul <tim.paul@immutable.com> <@glomotion>
 *
 */
@customElement('composited-card')
export class CompositedCard extends LitElement {
  @property({ type: Number }) protoId: number;
  @property({ type: Number }) quality: number = 5;
  @property({ type: Object }) inputProtoData: ICardProtoData;
  @property({ type: Object }) inputCompositionData: ICardCompsitionData;
  @property({ type: String }) responsiveSrcsetSizes: string;
  @property({ type: Boolean }) useLegacyQualityMapping = false;
  @property({ type: Number }) compositionVersion: number = 1;
  @property({ type: String }) illustrationSource: string;
  @property({ type: String }) format = "card";
  @property({ type: String }) filter: string;

  public compositionCardData: ICardCompsitionData = {
    type: '',
    effect: '',
    name: '',
    rarity: '',
    god: '',
    set: '',
    mana: '',
    id: '',
    attack: null,
    health: null,
    tribe: '',
    art_id: '',
    composition: {
      illustration: [],
      frame: [],
      rosette: [],
      gems: [],
      wreath: [],
      lock: [],
      tribe_bar: [],
      profile: [],
    }
  };

  public ch: number;
  public cw: number;
  public loading: boolean;

  static get styles() {
    return getStyles();
  }

  constructor() {
    super();
    this.loading = true;
    this.quality = 0;
    this.ch = this.offsetHeight * 0.01;
    this.cw = this.offsetWidth * 0.01;
  }

  /**
   * Generic LitElement component life-cycle events
   */
  connectedCallback() {
    super.connectedCallback();
    ro.observe(this);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    ro.unobserve(this);
  }
  updated(changedProps) {
    changedProps.forEach((oldValue, propName) => {
      if (propName === 'protoId') {
        this.getProtoDataFromApi();
      } else if (propName === 'inputProtoData' || propName === 'inputCompositionData') {
        this.getProtoDataFromInput(propName);
      } 
    });
  }

  /**
   * Generic resize handling
   */
  public handleResize(event) {
    const container = event.target.shadowRoot.children[0];
    this.ch = container.offsetHeight * 0.01;
    this.cw = container.offsetWidth * 0.01;
    this.requestUpdate();
  }

  /**
   * A method to fetch a protoId's card info data
   */
  private async fetchProtoData() {
    this.loading = true;
    return fetch(
      `https://api.godsunchained.com/v0/composition?pairs=${this.protoId}@${this.quality}`,
    ).then((resp) => resp.json());
  }

  /**
   * A method to handle the fetching, and then processing
   * of proto card data
   */
  private async getProtoDataFromApi() {
    return this.fetchProtoData().then((data) => {
      if(!data || data.error || data.length != 1) return null
      const {
        id,
        type,
        attack,
        health,
        effect,
        name,
        rarity,
        god,
        mana,
        set,
        tribe,
        art_id,
        composition,
      } = data[0];
      this.compositionCardData = {
        id,
        type,
        attack: attack.Int64,
        health: health.Int64,
        effect,
        name,
        rarity,
        god,
        mana,
        set,
        tribe: normalizeTribe(tribe),
        art_id,
        composition,
      };
      this.loading = false;
      this.requestUpdate();
      return data;
    });
  }

  /**
   * A method for Injesting of proto card data that is manually
   * input into the component
   */
  private getProtoDataFromInput(dataType : string) {
    if(dataType == 'inputProtoData') {
      this.compositionCardData = { ...(this.inputProtoData as ICardCompsitionData) };
    } else {
      this.compositionCardData = { ...this.inputCompositionData };
    }
    this.compositionCardData.tribe = normalizeTribe(this.compositionCardData.tribe);

    if(!this.compositionCardData.composition && this.compositionVersion != 1) {
      this.compositionVersion = 1
    }
    
    this.loading = false;
    this.requestUpdate();
  }

  /**
   * A `render` method to define the DOM structure of the component
   */
  render() {

    if (this.compositionVersion == 2) {

      if(this.format == "profile") {
        return this.renderProfile()
      }

      if(this.filter && this.filter.length > 0) {
        let filterVal = "-" + this.filter
        if(this.compositionCardData.composition.illustration[0] != null && !this.compositionCardData.composition.illustration[0].includes(filterVal)) {
          this.compositionCardData.composition.illustration[0] += filterVal //Apply filter to first value of illustration
        }
      }

      const baseArtworkLayersCompositionTemplateData = {
        illustration: this.compositionCardData.composition.illustration,
        responsiveSrcsetSizes: this.responsiveSrcsetSizes,
      }

      if(this.illustrationSource?.length > 0) baseArtworkLayersCompositionTemplateData["imageSrc"] = this.illustrationSource

      return html`
        <div class="card__innerRatioConstrainer">
          ${this.loading
            ? loadingTemplate()
            : html`
              ${baseArtworkLayersCompositionTemplate(baseArtworkLayersCompositionTemplateData)}
              ${imageLayersCompositionTemplate({
                frame: this.compositionCardData.composition.frame,
                rosette: this.compositionCardData.composition.rosette,
                gems: this.compositionCardData.composition.gems,
                wreath: this.compositionCardData.composition.wreath,
                lock: this.compositionCardData.composition.lock,
                // tribe_bar can be a non-empty array even for non-tribe cards (bad upstream data) —
                // only forward it once the card's own tribe name is actually valid.
                tribe: this.compositionCardData.tribe ? this.compositionCardData.composition.tribe_bar : [],
                rarity: this.compositionCardData.rarity,
                responsiveSrcsetSizes: this.responsiveSrcsetSizes,
              })}
              ${textLayersCompositionTemplate({
                ch: this.ch,
                cw: this.cw,
                ...this.compositionCardData,
                cardSet: this.compositionCardData.composition.set,
              })}
            `}
        </div>
      `;
    } else {
      const qualityName = this.useLegacyQualityMapping ? legacyQualities[this.quality] : qualities[this.quality - 1];
      const isMythicCard = this.compositionCardData.rarity === 'mythic';
      const baseArtworkLayersTemplateData = {
        id: this.compositionCardData.id,
        responsiveSrcsetSizes: this.responsiveSrcsetSizes,
      }

      if(this.illustrationSource?.length > 0) baseArtworkLayersTemplateData["imageSrc"] = this.illustrationSource

      return html`
        <div class="card__innerRatioConstrainer">
          ${this.loading
            ? loadingTemplate()
            : html`
                ${baseArtworkLayersTemplate(baseArtworkLayersTemplateData)}
                ${isMythicCard
                  ? mythicImageLayersTemplate({
                      responsiveSrcsetSizes: this.responsiveSrcsetSizes,
                      ...this.compositionCardData,
                    })
                  : nonMythicImageLayersTemplate({
                      qualityName: qualityName,
                      responsiveSrcsetSizes: this.responsiveSrcsetSizes,
                      ...this.compositionCardData,
                    })}
                ${textLayersTemplate({
                  ch: this.ch,
                  cw: this.cw,
                  ...this.compositionCardData,
                  cardSet: this.compositionCardData.set,
                })}
              `}
        </div>
      `;
    }

    
  }

  renderProfile() {

    const baseArtworkLayersCompositionTemplateData = {
      illustration: this.compositionCardData.composition.illustration,
      profile: this.compositionCardData.composition.profile,
      responsiveSrcsetSizes: this.responsiveSrcsetSizes,
    }

    if(this.illustrationSource?.length > 0) baseArtworkLayersCompositionTemplateData["imageSrc"] = this.illustrationSource

    return html`
        <div class="profile__ratioConstrainer">
          ${this.loading
            ? loadingTemplate()
            : html`
              ${profileArtworkLayersCompositionTemplate(baseArtworkLayersCompositionTemplateData)}
            `}
        </div>
      `;
  }
}
