#pragma once

#include "CoreMinimal.h"
#include "Immutable/ImmutablePassport.h"
#include "ImtblBlueprintAsyncAction.h"
#include "ImtblConnectionAsyncAction.generated.h"

UCLASS()
class IMMUTABLE_API UImtblConnectionAsyncActions : public UImtblBlueprintAsyncAction
{
	GENERATED_BODY()

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FPassportConnectOutputPin, FString, ErrorMessage);

public:
	/**
	 * Log into Passport
	 *
	 * @param	WorldContextObject	World context
	 * @param	DirectLoginOptions	Direct login options for authentication (email, google, apple, facebook)
	 *
	 * @return	A reference to the object represented by this node
	 */
	UFUNCTION(BlueprintCallable, meta = (WorldContext = "WorldContextObject", BlueprintInternalUseOnly = "true"), Category = "Immutable")
	static UImtblConnectionAsyncActions* Login(UObject* WorldContextObject, const FImmutableDirectLoginOptions& DirectLoginOptions);

	virtual void Activate() override;

	FPassportConnectOutputPin* DynamicMulticastDelegate_OnSuccess();
	FPassportConnectOutputPin* DynamicMulticastDelegate_OnFailed();

private:
	void DoConnect(TWeakObjectPtr<class UImtblJSConnector> JSConnector);
	void OnConnect(FImmutablePassportResult Result);

	UPROPERTY(BlueprintAssignable, Meta = (DisplayName = "OnSuccess"))
	FPassportConnectOutputPin Internal_DynamicMulticastDelegate_OnSuccess;
	UPROPERTY(BlueprintAssignable, Meta = (DisplayName = "OnFailed"))
	FPassportConnectOutputPin Internal_DynamicMulticastDelegate_OnFailed;

	FImmutableDirectLoginOptions DirectLoginOptions;
};
