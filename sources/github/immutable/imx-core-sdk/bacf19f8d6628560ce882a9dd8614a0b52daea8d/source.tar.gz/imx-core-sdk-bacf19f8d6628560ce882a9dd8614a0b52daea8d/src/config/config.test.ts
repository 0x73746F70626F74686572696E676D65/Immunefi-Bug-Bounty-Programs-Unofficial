import { Config, ImmutableXConfiguration } from './config';
import { version } from '../../package.json';
import { Configuration } from '../api';

const defaultHeaders = { 'x-sdk-version': `imx-core-sdk-ts-${version}` };

describe('createConfig', () => {
  it('should throw if basePath is whitespace', () => {
    expect(() =>
      Config.createConfig({
        coreContractAddress: '0x1',
        registrationContractAddress: '0x2',
        registrationV4ContractAddress: '0x3',
        chainID: 3,
        basePath: ' ',
      }),
    ).toThrowError('basePath can not be empty');
  });

  it('should throw if basePath is empty', () => {
    expect(() =>
      Config.createConfig({
        coreContractAddress: '0x1',
        registrationContractAddress: '0x2',
        registrationV4ContractAddress: '0x3',
        chainID: 3,
        basePath: '',
      }),
    ).toThrowError('basePath can not be empty');
  });

  it('should return config', () => {
    const basePath = 'https://api.sandbox.x.immutable.com';
    const coreContractAddress = '0x1';
    const registrationContractAddress = '0x2';
    const registrationV4ContractAddress = '0x3';
    const chainID = 3;
    const customHeaders = {
      'x-custom-headers': 'x values',
      'x-sdk-version': 'this should get overwritten',
    };
    const expected: ImmutableXConfiguration = {
      apiConfiguration: new Configuration({
        basePath,
        baseOptions: {
          headers: { 'x-custom-headers': 'x values', ...defaultHeaders },
        },
      }),
      ethConfiguration: {
        chainID,
        coreContractAddress,
        registrationContractAddress,
        registrationV4ContractAddress,
      },
    };

    const actual = Config.createConfig({
      coreContractAddress,
      registrationContractAddress,
      registrationV4ContractAddress,
      chainID,
      basePath,
      headers: customHeaders,
    });
    expect(actual).toEqual(expected);
  });

  it('config should return sdkVersion thats provided', () => {
    const sdkVersion = `imx-core-sdk-ts-test-1.0.0`;

    const basePath = 'https://api.sandbox.x.immutable.com';
    const coreContractAddress = '0x1';
    const registrationContractAddress = '0x2';
    const registrationV4ContractAddress = '0x3';
    const chainID = 3;
    const customHeaders = {
      'x-custom-headers': 'x values',
      'x-sdk-version': 'this should get overwritten',
    };
    const expected: ImmutableXConfiguration = {
      apiConfiguration: new Configuration({
        basePath,
        baseOptions: {
          headers: {
            'x-custom-headers': 'x values',
            'x-sdk-version': sdkVersion,
          },
        },
      }),
      ethConfiguration: {
        chainID,
        coreContractAddress,
        registrationContractAddress,
        registrationV4ContractAddress,
      },
    };

    const actual = Config.createConfig({
      coreContractAddress,
      registrationContractAddress,
      registrationV4ContractAddress,
      chainID,
      basePath,
      headers: customHeaders,
      sdkVersion: sdkVersion,
    });
    expect(actual).toEqual(expected);
  });
});
