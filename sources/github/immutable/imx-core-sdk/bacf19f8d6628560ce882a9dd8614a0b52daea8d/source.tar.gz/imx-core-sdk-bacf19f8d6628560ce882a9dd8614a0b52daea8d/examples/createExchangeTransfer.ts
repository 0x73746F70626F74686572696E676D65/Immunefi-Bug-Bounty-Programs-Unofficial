import {
  ImmutableX,
  Config,
  UnsignedExchangeTransferRequest,
} from '@imtbl/core-sdk';
import { generateWalletConnection } from './libs/walletConnection';

(async () => {
  const walletConnection = await generateWalletConnection('sepolia');

  const imxClient = new ImmutableX(Config.SANDBOX);

  const exchangeTransferParams: UnsignedExchangeTransferRequest = {
    type: 'ETH',
    amount: '0.001',
    transactionID: '0',
    receiver: '',
  };

  try {
    const exchangeTransferResponse = await imxClient.exchangeTransfer(
      walletConnection,
      exchangeTransferParams,
    );

    console.log('exchangeTransferResponse', exchangeTransferResponse);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
})();
