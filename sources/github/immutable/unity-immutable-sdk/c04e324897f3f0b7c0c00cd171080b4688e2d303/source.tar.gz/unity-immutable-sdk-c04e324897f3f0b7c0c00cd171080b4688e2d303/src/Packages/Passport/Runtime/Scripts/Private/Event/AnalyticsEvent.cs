using System.Collections.Generic;
using System;
using UnityEngine;
using Immutable.Passport.Model;
using Immutable.Passport.Core;
using Immutable.Passport.Helpers;
using Cysharp.Threading.Tasks;

namespace Immutable.Passport.Event
{
    public class PassportAnalytics
    {
        public const string TRACK = "track";
        private const string MODULE_NAME = "unitySdk";

        public static class EventName
        {
            public const string INIT_PASSPORT = "initialisedPassport";

            // Login
            public const string START_LOGIN_PKCE = "startedLoginPkce";
            public const string COMPLETE_LOGIN_PKCE = "performedLoginPkce";
            public const string COMPLETE_RELOGIN = "performedRelogin";

            // Logout
            public const string COMPLETE_LOGOUT_PKCE = "performedLogoutPkce";
        }

        private static class Properties
        {
            public const string SUCCESS = "succeeded";
        }

        public async UniTask Track(IBrowserCommunicationsManager communicationsManager, string eventName,
            bool? success = null, Dictionary<string, object>? properties = null)
        {
            try
            {
                properties ??= new Dictionary<string, object>();
                if (success != null)
                {
                    properties.Add(Properties.SUCCESS, success);
                }
                var json = JsonUtility.ToJson(new TrackData
                {
                    moduleName = MODULE_NAME,
                    eventName = eventName,
                    properties = properties.ToJson()
                });
                await communicationsManager.Call(TRACK, json);
            }
            catch (Exception)
            {
                // Ignore tracking errors
            }
        }
    }
}