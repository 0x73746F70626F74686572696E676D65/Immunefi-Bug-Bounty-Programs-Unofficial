using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Immutable.Audience.Tests
{
    [TestFixture]
    internal class ImmutableAudienceTests
    {
        private string _testDir;

        [SetUp]
        public void SetUp()
        {
            _testDir = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(_testDir);
        }

        [TearDown]
        public void TearDown()
        {
            ImmutableAudience.ResetState();
            ImmutableAudience.LaunchContextProvider = null;
            ImmutableAudience.ContextProvider = null;
            ImmutableAudience.DefaultPersistentDataPathProvider = null;
            ImmutableAudience.MobileAttributionProvider = null;
            ImmutableAudience.MobileAttributionContextProvider = null;
            ImmutableAudience.TrackingAuthorizationRequestProvider = null;
            ImmutableAudience.MobileInstallReferrerProvider = null;
            ImmutableAudience.MobileATTStatusProvider = null;
            ImmutableAudience.MobileIDFAProvider = null;
            Identity.Reset(_testDir);
            if (Directory.Exists(_testDir))
                Directory.Delete(_testDir, recursive: true);
        }

        private AudienceConfig MakeConfig(ConsentLevel consent = ConsentLevel.Anonymous)
        {
            return new AudienceConfig
            {
                PublishableKey = "pk_imapik-test-key1",
                Consent = consent,
                PersistentDataPath = _testDir,
                FlushIntervalSeconds = 600, // large; we flush manually in tests
                FlushSize = 1000,
                HttpHandler = new KeepOnDiskHandler()
            };
        }

        /// <summary>
        /// Returns 503 so the transport keeps files on disk for inspection.
        /// Tests verify queuing behavior, not sending behavior.
        /// </summary>
        private class KeepOnDiskHandler : HttpMessageHandler
        {
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
            {
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.ServiceUnavailable));
            }
        }

        // -----------------------------------------------------------------
        // Diagnostic getters (Initialized / CurrentConsent / UserId /
        // AnonymousId / SessionId / QueueSize)
        // -----------------------------------------------------------------

        [Test]
        public void Initialized_FlipsAroundInitAndShutdown()
        {
            Assert.IsFalse(ImmutableAudience.Initialized,
                "Initialized should be false before Init");

            ImmutableAudience.Init(MakeConfig());
            Assert.IsTrue(ImmutableAudience.Initialized,
                "Initialized should flip true after Init");

            ImmutableAudience.Shutdown();
            Assert.IsFalse(ImmutableAudience.Initialized,
                "Initialized should flip back to false after Shutdown");
        }

        [Test]
        public void CurrentConsent_ReflectsLatestSetConsent()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            Assert.AreEqual(ConsentLevel.Anonymous, ImmutableAudience.CurrentConsent);

            ImmutableAudience.SetConsent(ConsentLevel.Full);
            Assert.AreEqual(ConsentLevel.Full, ImmutableAudience.CurrentConsent);

            ImmutableAudience.SetConsent(ConsentLevel.None);
            Assert.AreEqual(ConsentLevel.None, ImmutableAudience.CurrentConsent);
        }

        [Test]
        public void UserId_Uninitialised_ReturnsNull()
        {
            Assert.IsNull(ImmutableAudience.UserId);
        }

        [Test]
        public void UserId_AfterIdentifyAndReset_TracksState()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            Assert.IsNull(ImmutableAudience.UserId,
                "UserId should be null until Identify is called");

            ImmutableAudience.Identify("player-42", IdentityType.Custom);
            Assert.AreEqual("player-42", ImmutableAudience.UserId,
                "UserId must reflect the most recent Identify call");

            ImmutableAudience.Reset();
            Assert.IsNull(ImmutableAudience.UserId,
                "Reset must clear UserId so the next player is not attributed to the previous one");
        }

        [Test]
        public void CurrentIdentityType_AfterIdentifyAndReset_TracksState()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            Assert.IsNull(ImmutableAudience.CurrentIdentityType,
                "CurrentIdentityType should be null until Identify is called");

            ImmutableAudience.Identify("player-42", IdentityType.Steam);
            Assert.AreEqual(IdentityType.Steam, ImmutableAudience.CurrentIdentityType,
                "CurrentIdentityType must reflect the most recent Identify call");

            ImmutableAudience.Reset();
            Assert.IsNull(ImmutableAudience.CurrentIdentityType,
                "Reset must clear CurrentIdentityType so the next player is not attributed to the previous one");
        }

        [Test]
        public void AnonymousId_ConsentNone_ReturnsNull()
        {
            // Anonymous identifier is consent-gated: below tracking consent,
            // no stable id should leak through the getter.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.None));

            Assert.IsNull(ImmutableAudience.AnonymousId);
        }

        [Test]
        public void AnonymousId_ConsentAnonymous_ReturnsPersistedId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            // Track once so Identity.GetOrCreate runs and writes the id file.
            ImmutableAudience.Track("warmup_event");

            var id = ImmutableAudience.AnonymousId;
            Assert.IsFalse(string.IsNullOrEmpty(id),
                "AnonymousId should return the persisted id once tracking has created one");
        }

        // -----------------------------------------------------------------
        // DeviceId
        // -----------------------------------------------------------------

        [Test]
        public void DeviceId_ConsentNone_ReturnsNull()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.None));
            Assert.IsNull(ImmutableAudience.DeviceId);
        }

        [Test]
        public void DeviceId_ConsentAnonymous_ReturnsNonEmptyId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.Track("warmup");

            Assert.IsFalse(string.IsNullOrEmpty(ImmutableAudience.DeviceId));
        }

        [Test]
        public void DeviceId_DifferentFromAnonymousId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.Track("warmup");

            Assert.AreNotEqual(ImmutableAudience.AnonymousId, ImmutableAudience.DeviceId);
        }

        [Test]
        public void DeviceId_SurvivesReset()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.Track("warmup");

            var deviceIdBefore = ImmutableAudience.DeviceId;
            ImmutableAudience.Reset();

            Assert.AreEqual(deviceIdBefore, ImmutableAudience.DeviceId,
                "device_id must survive logout (Reset)");
        }

        [Test]
        public void DeviceId_WipedBySetConsentNone()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.Track("warmup");

            var deviceIdBefore = ImmutableAudience.DeviceId;
            ImmutableAudience.SetConsent(ConsentLevel.None);
            ImmutableAudience.SetConsent(ConsentLevel.Anonymous);
            ImmutableAudience.Track("post-optin");

            Assert.AreNotEqual(deviceIdBefore, ImmutableAudience.DeviceId,
                "device_id must be regenerated after opt-out then opt-back-in");
        }

        [Test]
        public void DeviceId_PresentOnTrackEvents()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.Track("test_event");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();

            Assert.IsTrue(blobs.Any(b => b.Contains("\"deviceId\":")),
                "track events must include deviceId at Anonymous+ consent");
        }

        [Test]
        public void IdentityType_PersistsFromIdentifyOntoSubsequentTrackEvents()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify("player-42", IdentityType.Steam);
            ImmutableAudience.Track("post_identify_event");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();

            Assert.IsTrue(
                blobs.Any(b => b.Contains("\"eventName\":\"post_identify_event\"") && b.Contains("\"identityType\":\"steam\"")),
                "track events after Identify must carry the identityType from that Identify call");
        }

        [Test]
        public void IdentityType_ClearedByReset_AbsentFromSubsequentTrackEvents()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify("player-42", IdentityType.Steam);
            ImmutableAudience.Reset();
            ImmutableAudience.Track("post_reset_event");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            var postResetBlob = blobs.First(b => b.Contains("\"eventName\":\"post_reset_event\""));

            Assert.IsFalse(postResetBlob.Contains("\"identityType\":"),
                "track events after Reset must not carry a stale identityType");
        }

        [Test]
        public void DeviceId_StableAcrossAnonIdRotation()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.Track("warmup");

            var deviceIdBefore = ImmutableAudience.DeviceId;
            var anonIdBefore = ImmutableAudience.AnonymousId;

            ImmutableAudience.Reset();

            Assert.AreNotEqual(anonIdBefore, ImmutableAudience.AnonymousId, "anon_id must rotate on Reset");
            Assert.AreEqual(deviceIdBefore, ImmutableAudience.DeviceId, "device_id must be stable across Reset");
        }

        [Test]
        public void SessionId_MirrorsSessionLifecycle()
        {
            Assert.IsNull(ImmutableAudience.SessionId,
                "SessionId should be null before Init");

            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            Assert.IsFalse(string.IsNullOrEmpty(ImmutableAudience.SessionId),
                "SessionId should be non-null once Init creates a session");

            ImmutableAudience.Shutdown();
            Assert.IsNull(ImmutableAudience.SessionId,
                "SessionId should be null after Shutdown disposes the session");
        }

        [Test]
        public void QueueSize_ZeroBeforeInit_GrowsWithEnqueue()
        {
            Assert.AreEqual(0, ImmutableAudience.QueueSize,
                "QueueSize should be 0 before Init");

            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            // Init enqueues session_start + game_launch; those stay
            // in-memory until a flush. QueueSize sums memory + disk so the
            // pre-flush snapshot must be > 0.
            var afterInit = ImmutableAudience.QueueSize;
            Assert.Greater(afterInit, 0,
                "QueueSize should include session_start and game_launch after Init");

            ImmutableAudience.Track("explicit_track_event");
            Assert.Greater(ImmutableAudience.QueueSize, afterInit,
                "QueueSize should grow when a new event is enqueued");
        }

        // -----------------------------------------------------------------
        // Unity context provider
        // -----------------------------------------------------------------

        [Test]
        public void ContextProvider_Set_MergesFieldsIntoEveryMessageContext()
        {
            ImmutableAudience.ContextProvider = () => new Dictionary<string, object>
            {
                ["userAgent"] = "TestOS 1.0",
                ["locale"] = "en-GB",
                ["timezone"] = "Europe/London",
                ["screen"] = "1920x1080",
            };

            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Track("unit_test_event");
            ImmutableAudience.Shutdown();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();

            Assert.IsTrue(blobs.Any(b =>
                b.Contains("\"userAgent\":\"TestOS 1.0\"") &&
                b.Contains("\"locale\":\"en-GB\"") &&
                b.Contains("\"timezone\":\"Europe/London\"") &&
                b.Contains("\"screen\":\"1920x1080\"") &&
                b.Contains("\"library\":")),
                "Enqueue should merge ContextProvider fields into msg.context alongside library/libraryVersion");
        }

        [Test]
        public void ContextProvider_Set_MergesOnIdentifyPath()
        {
            // EnqueueIdentity must merge ContextProvider fields the same way
            // EnqueueTrack does. Otherwise Identify events ship without the
            // userAgent / locale / timezone / screen context every other
            // event carries.
            ImmutableAudience.ContextProvider = () => new Dictionary<string, object>
            {
                ["userAgent"] = "TestOS 1.0",
                ["locale"] = "en-GB",
            };

            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify("player-42", IdentityType.Custom);
            ImmutableAudience.Shutdown();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();

            Assert.IsTrue(blobs.Any(b =>
                b.Contains("\"type\":\"identify\"") &&
                b.Contains("\"userAgent\":\"TestOS 1.0\"") &&
                b.Contains("\"locale\":\"en-GB\"")),
                "Identify message must carry ContextProvider fields in msg.context");
        }

        [Test]
        public void ContextProvider_ThrowingDelegate_SwallowsAndShipsBaseContext()
        {
            ImmutableAudience.ContextProvider = () => throw new InvalidOperationException("boom");

            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Track("unit_test_event");
            ImmutableAudience.Shutdown();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();

            Assert.IsTrue(blobs.Any(b => b.Contains("\"unit_test_event\"") && b.Contains("\"library\":")),
                "event should still ship with base context when ContextProvider throws");
        }

        [Test]
        public void ContextProvider_ReturnsNull_ShipsBaseContext()
        {
            ImmutableAudience.ContextProvider = () => null;

            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Track("unit_test_event");
            ImmutableAudience.Shutdown();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();

            Assert.IsTrue(blobs.Any(b => b.Contains("\"unit_test_event\"") && b.Contains("\"library\":")),
                "event should still ship with base context when ContextProvider returns null");
        }

        // -----------------------------------------------------------------
        // Init
        // -----------------------------------------------------------------

        [Test]
        public void Init_NullConfig_Throws()
        {
            Assert.Throws<ArgumentNullException>(() => ImmutableAudience.Init(null));
        }

        [Test]
        public void Init_MissingPublishableKey_Throws()
        {
            var config = MakeConfig();
            config.PublishableKey = null;
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Init(config));
        }

        [Test]
        public void Init_MissingPersistentDataPath_Throws()
        {
            var config = MakeConfig();
            config.PersistentDataPath = null;
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Init(config));
        }

        [Test]
        public void Init_CalledTwice_IgnoresSecondCall()
        {
            ImmutableAudience.Init(MakeConfig());
            Assert.DoesNotThrow(() => ImmutableAudience.Init(MakeConfig()));
        }

        [Test]
        public void Track_NullEvent_Throws()
        {
            ImmutableAudience.Init(MakeConfig());

            Assert.Throws<ArgumentNullException>(() => ImmutableAudience.Track((IEvent)null),
                "a null event is a caller bug and must throw, not just log a warning that's easy to miss");
        }

        [Test]
        public void Track_NullEvent_ThrowsEvenAtNoneConsent()
        {
            // A caller bug must throw regardless of consent; the None no-op
            // must never mask a null event the way it masks a valid one.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.None));

            Assert.Throws<ArgumentNullException>(() => ImmutableAudience.Track((IEvent)null));
        }

        [Test]
        public void Track_BuiltInEventMissingRequiredField_Throws()
        {
            ImmutableAudience.Init(MakeConfig());

            // Purchase with no Value set: ToProperties throws. Purchase is one of
            // Immutable's own built-in events, so that's a caller bug and must
            // throw straight through, the same as Identify()/Alias() do for an
            // equivalent mistake, rather than ship an incomplete event silently.
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track(new Purchase { Currency = "USD" }));

            ImmutableAudience.Shutdown();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"purchase\"")),
                "purchase event with missing required Value must never reach the queue");
        }

        private class ThrowingCustomEvent : IEvent
        {
            public string EventName => "custom_event";
            public Dictionary<string, object> ToProperties() => throw new InvalidOperationException("boom");
        }

        [Test]
        public void Track_CustomEventThrows_DropsWithWarn()
        {
            ImmutableAudience.Init(MakeConfig());

            var lines = new List<string>();
            Log.Writer = lines.Add;
            try
            {
                // A consumer's own custom IEvent (not one of Immutable's built-in
                // types) is not held to the same "throw straight through" standard:
                // we can't predict what a third-party implementation might throw,
                // so it's caught, warned, and dropped instead of crashing the game.
                Assert.DoesNotThrow(() => ImmutableAudience.Track(new ThrowingCustomEvent()));
                Assert.That(lines, Has.Some.Contains(nameof(ThrowingCustomEvent)));
                Assert.That(lines, Has.Some.Contains("Dropping"));
            }
            finally { Log.Writer = null; }

            ImmutableAudience.Shutdown();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("custom_event")),
                "custom event whose ToProperties() throws must be dropped, not enqueued");
        }

        [Test]
        public void Track_NullOrEmptyEventName_Throws()
        {
            ImmutableAudience.Init(MakeConfig());

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track((string)null),
                "an empty event name is a caller bug and must throw, not just log a warning that's easy to miss");
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track(""));
        }

        [Test]
        public void Track_NullOrEmptyEventName_ThrowsEvenAtNoneConsent()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.None));

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track((string)null));
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track(""));
        }

        [Test]
        public void Track_StringOverload_ReservedEventMissingRequiredProps_Throws()
        {
            // The typed IEvent classes can't stop a caller from bypassing them
            // entirely and calling the string overload directly for a reserved
            // event name; this closes that gap.
            ImmutableAudience.Init(MakeConfig());

            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Track("purchase", new Dictionary<string, object> { ["currency"] = "USD" }),
                "purchase is missing required 'value'");
            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Track("progression"),
                "progression is missing required 'status'");
            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Track("resource", new Dictionary<string, object> { ["flow"] = "source" }),
                "resource is missing required 'currency' and 'amount'");
            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Track("achievement_unlocked", new Dictionary<string, object> { ["achievement_id"] = "a1" }),
                "achievement_unlocked is missing required 'achievement_name'");
        }

        [Test]
        public void Track_StringOverload_ReservedEventWithAllRequiredProps_DoesNotThrow()
        {
            ImmutableAudience.Init(MakeConfig());

            Assert.DoesNotThrow(() => ImmutableAudience.Track("purchase",
                new Dictionary<string, object> { ["currency"] = "USD", ["value"] = 9.99m }));
            Assert.DoesNotThrow(() => ImmutableAudience.Track("progression",
                new Dictionary<string, object> { ["status"] = "start" }));
            Assert.DoesNotThrow(() => ImmutableAudience.Track("resource",
                new Dictionary<string, object> { ["flow"] = "source", ["currency"] = "gold", ["amount"] = 10f }));
            Assert.DoesNotThrow(() => ImmutableAudience.Track("achievement_unlocked",
                new Dictionary<string, object> { ["achievement_id"] = "a1", ["achievement_name"] = "First Steps" }));
        }

        [Test]
        public void Track_StringOverload_UnrecognisedEventName_DoesNotValidate()
        {
            ImmutableAudience.Init(MakeConfig());

            Assert.DoesNotThrow(() => ImmutableAudience.Track("some_custom_event"));
        }

        [Test]
        public void Identify_NullOrEmptyUserId_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Identify(null, IdentityType.Passport));
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Identify("", IdentityType.Passport));
        }

        [Test]
        public void Identify_InvalidIdentityTypeCast_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            var invalid = (IdentityType)999;

            Assert.Throws<ArgumentOutOfRangeException>(
                () => ImmutableAudience.Identify("user1", invalid),
                "invalid enum cast must throw so a broken call fails loud rather than " +
                "shipping an identify event that cannot be matched for deletion");
        }

        [Test]
        public void Alias_InvalidIdentityTypeCast_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            var invalid = (IdentityType)999;

            Assert.Throws<ArgumentOutOfRangeException>(
                () => ImmutableAudience.Alias("fromId", invalid, "toId", IdentityType.Steam),
                "invalid enum cast must throw so a broken alias call fails loud rather " +
                "than shipping an event that cannot be matched for deletion");
        }

        [Test]
        public void Alias_NullOrEmptyIds_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Alias(null, IdentityType.Passport, "to", IdentityType.Steam));
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Alias("from", IdentityType.Passport, "", IdentityType.Steam));
        }

        [Test]
        public void Init_CalledTwice_LogsWarning()
        {
            var lines = new List<string>();
            Log.Writer = lines.Add;
            try
            {
                ImmutableAudience.Init(MakeConfig());
                ImmutableAudience.Init(MakeConfig());

                Assert.That(lines, Has.Some.Contains(AudienceLogs.InitCalledTwice),
                    "second Init must surface a warning so a developer notices the silent no-op");
            }
            finally
            {
                Log.Writer = null;
            }
        }

        [Test]
        public void Init_ConcurrentCalls_OnlyOneSucceeds_OthersWarn()
        {
            // Spin up N threads that all race to call Init. With the lock in place,
            // exactly one initialises; the rest hit the duplicate-call warning branch.
            // Without the lock, all of them would pass the _initialized check and
            // double-allocate Timer + HttpClient + EventQueue, leaking the first set.
            const int threadCount = 16;
            var lines = new System.Collections.Concurrent.ConcurrentBag<string>();
            Log.Writer = msg => lines.Add(msg);

            try
            {
                var barrier = new System.Threading.Barrier(threadCount);
                var threads = new Thread[threadCount];

                for (int i = 0; i < threadCount; i++)
                {
                    threads[i] = new Thread(() =>
                    {
                        barrier.SignalAndWait();
                        ImmutableAudience.Init(MakeConfig());
                    });
                    threads[i].Start();
                }

                foreach (var t in threads) t.Join(TimeSpan.FromSeconds(5));

                var warningCount = lines.Count(l => l.Contains(AudienceLogs.InitCalledTwice));
                Assert.AreEqual(threadCount - 1, warningCount,
                    "exactly one thread should initialise; the other (threadCount - 1) should hit the duplicate-call warning branch");
            }
            finally
            {
                Log.Writer = null;
            }
        }

        // -----------------------------------------------------------------
        // Track: custom events
        // -----------------------------------------------------------------

        [Test]
        public void Track_CustomEvent_WritesEventToDisk()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track("crafting_started", new Dictionary<string, object>
            {
                { "recipe_id", "iron_sword" }
            });

            // Flush memory → disk
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var files = Directory.GetFiles(queueDir, "*.json");
            // game_launch + crafting_started
            Assert.GreaterOrEqual(files.Length, 2);

            var contents = files.Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"crafting_started\"")),
                "should contain the custom event");
        }

        [Test]
        public void Track_NoProperties_WritesEvent()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track("main_menu_opened");
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"main_menu_opened\"")));
        }

        [Test]
        public void Track_ConsentNone_DoesNotEnqueue()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.None));

            ImmutableAudience.Track("should_not_appear");
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            if (!Directory.Exists(queueDir))
            {
                Assert.Pass("queue directory not created; no events");
                return;
            }

            Assert.AreEqual(0, Directory.GetFiles(queueDir, "*.json").Length);
        }

        // -----------------------------------------------------------------
        // Track: typed events
        // -----------------------------------------------------------------

        private class NullNameEvent : IEvent
        {
            public string EventName => null;
            public Dictionary<string, object> ToProperties() => new Dictionary<string, object>();
        }

        private class EmptyNameEvent : IEvent
        {
            public string EventName => "";
            public Dictionary<string, object> ToProperties() => new Dictionary<string, object>();
        }

        [Test]
        public void Track_TypedEvent_NullEventName_Throws()
        {
            ImmutableAudience.Init(MakeConfig());

            // Sanity: game_launch is already on disk; drain it first so the
            // assertion counts only our test event.
            ImmutableAudience.FlushQueueToDiskForTesting();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track(new NullNameEvent()),
                "an IEvent with a null/empty EventName is a caller bug and must throw");
            Assert.Throws<ArgumentException>(() => ImmutableAudience.Track(new EmptyNameEvent()));

            ImmutableAudience.FlushQueueToDiskForTesting();
            Assert.AreEqual(0, Directory.GetFiles(queueDir, "*.json").Length,
                "IEvent with null/empty EventName must never reach the queue");
        }

        [Test]
        public void Track_TypedProgression_WritesCorrectEventName()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track(new Progression
            {
                Status = ProgressionStatus.Complete,
                World = "tutorial",
                Level = "1"
            });
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c =>
                c.Contains("\"progression\"") && c.Contains("\"complete\"")));
        }

        [Test]
        public void Track_TypedPurchase_WritesCorrectEventName()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track(new Purchase
            {
                Currency = "USD",
                Value = "9.99"
            });
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"purchase\"")));
        }

        // -----------------------------------------------------------------
        // Identity
        // -----------------------------------------------------------------

        [Test]
        public void Identify_FullConsent_WritesIdentifyEvent()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            ImmutableAudience.Identify("76561198012345", IdentityType.Steam);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c =>
                c.Contains("\"identify\"") && c.Contains("\"76561198012345\"")));
        }

        [Test]
        public void Identify_AnonymousConsent_IsIgnored()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));

            ImmutableAudience.Identify("user1", IdentityType.Steam);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"identify\"")),
                "identify should be discarded at Anonymous consent");
        }

        [Test]
        public void Identify_PassportWithInvalidIdFormat_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Identify("12345", IdentityType.Passport),
                "a malformed passport id is a caller bug and must throw, not just log a warning that's easy to miss");
            Assert.IsNull(ImmutableAudience.UserId,
                "the call must be a full no-op so later Track/Page calls don't inherit the bad id");

            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"identify\"")),
                "the event should never reach the queue");
        }

        [TestCase("email|abc123")]
        [TestCase("google-oauth2|11261203362550278288455")]
        [TestCase("550e8400-e29b-41d4-a716-446655440000")]
        [TestCase(" 550e8400-e29b-41d4-a716-446655440000\n")]
        public void Identify_PassportWithValidIdFormat_DoesNotWarn(string userId)
        {
            var lines = new List<string>();
            Log.Writer = lines.Add;
            try
            {
                ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

                ImmutableAudience.Identify(userId, IdentityType.Passport);

                Assert.IsEmpty(lines);
            }
            finally
            {
                Log.Writer = null;
            }
        }

        [Test]
        public void Identify_PassportWithWhitespaceOnlyPadding_StillThrows()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(() => ImmutableAudience.Identify("  12345  ", IdentityType.Passport),
                "surrounding whitespace alone must not turn an invalid id into a valid one");
        }

        [Test]
        public void Identify_PassportWithPaddedValidId_StoresAndSendsTrimmedId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            ImmutableAudience.Identify(" email|abc123\n", IdentityType.Passport);

            Assert.AreEqual("email|abc123", ImmutableAudience.UserId,
                "the id validated and the id stored must be the same trimmed value");

            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"email|abc123\"")),
                "the enqueued event must carry the trimmed id, not the padded one");
            Assert.IsFalse(contents.Any(c => c.Contains("email|abc123\\n")),
                "the enqueued event must not carry the untrimmed padding");
        }

        [Test]
        public void Alias_PassportWithPaddedValidId_SendsTrimmedId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            ImmutableAudience.Alias("steam123", IdentityType.Steam, " email|user_456\n", IdentityType.Passport);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"email|user_456\"")),
                "the enqueued event must carry the trimmed id, not the padded one");
            Assert.IsFalse(contents.Any(c => c.Contains("email|user_456\\n")),
                "the enqueued event must not carry the untrimmed padding");
        }

        [Test]
        public void Identify_NonPassportWithNumericId_DoesNotWarn()
        {
            var lines = new List<string>();
            Log.Writer = lines.Add;
            try
            {
                ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

                ImmutableAudience.Identify("12345", IdentityType.Steam);

                Assert.IsEmpty(lines);
            }
            finally
            {
                Log.Writer = null;
            }
        }

        [Test]
        public void Alias_FullConsent_WritesAliasEvent()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            ImmutableAudience.Alias("steam123", IdentityType.Steam, "email|user_456", IdentityType.Passport);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c =>
                c.Contains("\"alias\"") && c.Contains("\"steam123\"")));
        }

        [Test]
        public void Alias_FullConsent_IncludesAnonymousId()
        {
            // anonymousId isn't used for the merge (fromId/toId are), but every
            // message type, alias included, must still carry it.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            var expectedAnonId = Identity.GetOrCreate(_testDir, ConsentLevel.Full);

            ImmutableAudience.Alias("steam123", IdentityType.Steam, "email|user_456", IdentityType.Passport);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(
                contents.Any(c => c.Contains("\"alias\"") && c.Contains($"\"anonymousId\":\"{expectedAnonId}\"")),
                "an Alias() envelope must carry the session's actual anonymousId, not just any anonymousId key");
        }

        [Test]
        public void Track_IdentityPersistenceFails_QueuedEventStillIncludesAnonymousId()
        {
            // End-to-end regression test for the actual bug: block only the identity
            // file specifically (not the whole AudienceDir, which the queue also
            // lives under and must keep working) by pre-creating a directory at the
            // exact path the identity file needs, then verify a real Track() call
            // still enqueues an envelope carrying anonymousId.
            var identityFile = AudiencePaths.IdentityFile(_testDir);
            Directory.CreateDirectory(identityFile);

            try
            {
                ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
                ImmutableAudience.Track("test_event");
                ImmutableAudience.Shutdown();

                var queueDir = AudiencePaths.QueueDir(_testDir);
                var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
                Assert.IsTrue(contents.Any(c => c.Contains("\"test_event\"") && c.Contains("\"anonymousId\"")),
                    "a track event must still carry anonymousId even when identity persistence fails");
            }
            finally
            {
                // TearDown calls Identity.Reset, which File.Deletes this path; it must
                // be a plain file (or absent) again, not the blocking directory.
                Directory.Delete(identityFile, recursive: true);
            }
        }

        [Test]
        public void Alias_PassportToWithInvalidIdFormat_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Alias("steam123", IdentityType.Steam, "12345", IdentityType.Passport),
                "a malformed passport id on the to side is a caller bug and must throw");

            ImmutableAudience.Shutdown();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"alias\"")),
                "the event should never reach the queue");
        }

        [Test]
        public void Alias_PassportFromWithInvalidIdFormat_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Alias("12345", IdentityType.Passport, "steam123", IdentityType.Steam),
                "a malformed passport id on the from side is a caller bug and must throw");

            ImmutableAudience.Shutdown();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"alias\"")),
                "the event should never reach the queue");
        }

        [Test]
        public void Alias_IdenticalIds_Throws()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Alias("same_id", IdentityType.Steam, "same_id", IdentityType.Steam),
                "identical ids are a caller bug and must throw");

            ImmutableAudience.Shutdown();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"alias\"")),
                "the event should never reach the queue");
        }

        [Test]
        public void Alias_IdenticalIdsDifferentTypes_StillThrows()
        {
            // Matches the backend: it rejects on id equality alone, ignoring
            // identityType, so the client must reject this case too instead
            // of sending something the backend will bounce.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            Assert.Throws<ArgumentException>(
                () => ImmutableAudience.Alias("same_id", IdentityType.Steam, "same_id", IdentityType.Email),
                "identical ids must throw even with different identityTypes");

            ImmutableAudience.Shutdown();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"alias\"")),
                "the event should never reach the queue");
        }

        [Test]
        public void Alias_NonPassportIdentityTypes_DoesNotWarn()
        {
            var lines = new List<string>();
            Log.Writer = lines.Add;
            try
            {
                ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

                ImmutableAudience.Alias("12345", IdentityType.Steam, "67890", IdentityType.Epic);

                Assert.IsEmpty(lines);
            }
            finally
            {
                Log.Writer = null;
            }
        }

        // -----------------------------------------------------------------
        // sessionId envelope field
        // -----------------------------------------------------------------

        [Test]
        public void Track_ActiveSession_EnvelopeIncludesSessionId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            var sessionId = ImmutableAudience.SessionId;
            Assert.IsFalse(string.IsNullOrEmpty(sessionId), "sanity: a session should be active after Init");

            ImmutableAudience.Track("crafting_started");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            Assert.IsTrue(
                contents.Any(c => c.Contains("\"crafting_started\"") && c.Contains($"\"sessionId\":\"{sessionId}\"")),
                "a Track() envelope should carry the active session's id even though the call site never set it");

            ImmutableAudience.Shutdown();
        }

        [Test]
        public void Track_IEvent_ActiveSession_EnvelopeIncludesSessionId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            var sessionId = ImmutableAudience.SessionId;
            Assert.IsFalse(string.IsNullOrEmpty(sessionId), "sanity: a session should be active after Init");

            ImmutableAudience.Track(new Purchase { Currency = "USD", Value = "9.99" });
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            Assert.IsTrue(
                contents.Any(c => c.Contains("\"purchase\"") && c.Contains($"\"sessionId\":\"{sessionId}\"")),
                "the typed Track(IEvent) overload should carry the active session's id, same as the string overload");

            ImmutableAudience.Shutdown();
        }

        [Test]
        public void Identify_ActiveSession_EnvelopeIncludesSessionId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            var sessionId = ImmutableAudience.SessionId;
            Assert.IsFalse(string.IsNullOrEmpty(sessionId), "sanity: a session should be active after Init");

            ImmutableAudience.Identify("player-42", IdentityType.Custom);
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            Assert.IsTrue(
                contents.Any(c => c.Contains("\"identify\"") && c.Contains($"\"sessionId\":\"{sessionId}\"")),
                "an Identify() envelope should carry the active session's id");

            ImmutableAudience.Shutdown();
        }

        [Test]
        public void Alias_ActiveSession_EnvelopeIncludesSessionId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            var sessionId = ImmutableAudience.SessionId;
            Assert.IsFalse(string.IsNullOrEmpty(sessionId), "sanity: a session should be active after Init");

            ImmutableAudience.Alias("steam123", IdentityType.Steam, "email|user_456", IdentityType.Passport);
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            Assert.IsTrue(
                contents.Any(c => c.Contains("\"alias\"") && c.Contains($"\"sessionId\":\"{sessionId}\"")),
                "an Alias() envelope should carry the active session's id");

            ImmutableAudience.Shutdown();
        }

        [Test]
        public void Shutdown_SessionEndEnvelope_CarriesEndingSessionId_NotNull()
        {
            // Regression guard: the envelope sessionId must be the value already
            // handed to TrackDelegate before Session.End() nulls its live SessionId,
            // not a live re-read of the (by-then-null) session.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            var endingSessionId = ImmutableAudience.SessionId;
            Assert.IsFalse(string.IsNullOrEmpty(endingSessionId), "sanity: a session should be active after Init");

            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            var sessionEnd = contents.FirstOrDefault(c => c.Contains("\"session_end\""));
            Assert.IsNotNull(sessionEnd, "Shutdown should emit session_end");
            Assert.IsTrue(sessionEnd.Contains($"\"sessionId\":\"{endingSessionId}\""),
                "session_end's envelope sessionId must equal the id of the session that just ended, not be null");
        }

        // -----------------------------------------------------------------
        // Reset
        // -----------------------------------------------------------------

        [Test]
        public void Reset_GeneratesNewAnonymousId()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track("before_reset");
            var id1 = Identity.GetOrCreate(_testDir, ConsentLevel.Anonymous);

            ImmutableAudience.Reset();

            ImmutableAudience.Track("after_reset");
            var id2 = Identity.GetOrCreate(_testDir, ConsentLevel.Anonymous);

            Assert.AreNotEqual(id1, id2, "Reset should generate a new anonymousId");
        }

        [Test]
        public void Reset_DiscardsQueuedEventsOnDisk()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track("before_reset");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            Assert.Greater(Directory.GetFiles(queueDir, "*.json").Length, 0,
                "precondition: queued event should be on disk before reset");

            ImmutableAudience.Reset();

            Assert.AreEqual(0, Directory.GetFiles(queueDir, "*.json").Length,
                "Reset must discard queued events on disk to match the Web SDK");
        }

        // -----------------------------------------------------------------
        // SetConsent: queue retention + persistence
        // -----------------------------------------------------------------

        [Test]
        public void SetConsent_DowngradeToNone_KeepsQueuedEvents()
        {
            ImmutableAudience.Init(MakeConfig());

            ImmutableAudience.Track("event_under_old_consent");

            var queueDir = AudiencePaths.QueueDir(_testDir);
            ImmutableAudience.FlushQueueToDiskForTesting();
            var before = Directory.GetFiles(queueDir, "*.json").Length;
            Assert.Greater(before, 0,
                "precondition: events queued before downgrade exist on disk");

            ImmutableAudience.SetConsent(ConsentLevel.None);

            // A consent change gates only future collection; events already
            // recorded keep the consent they were captured under and are not
            // purged (GDPR: consent is determined at capture time).
            Assert.AreEqual(before, Directory.GetFiles(queueDir, "*.json").Length,
                "downgrade to None must not purge already-queued events");
        }

        // Blocks inside ToProperties -- called by Track after it has already
        // snapshotted _state but before the message is built and enqueued --
        // until the test signals Proceed. This pins the race window deterministically
        // instead of hoping a real thread loses a scheduling race against SetConsent.
        private class GatedEvent : IEvent
        {
            private readonly ManualResetEventSlim _ready = new ManualResetEventSlim(false);
            private readonly ManualResetEventSlim _proceed = new ManualResetEventSlim(false);

            public string EventName { get; }

            public GatedEvent(string eventName) => EventName = eventName;

            public Dictionary<string, object> ToProperties()
            {
                _ready.Set();
                _proceed.Wait(TimeSpan.FromSeconds(5));
                return new Dictionary<string, object>();
            }

            // Blocks until Track has captured the pre-flip state and is
            // parked in ToProperties, poised to build and enqueue.
            public void WaitUntilReady() =>
                Assert.IsTrue(_ready.Wait(TimeSpan.FromSeconds(5)), "Track did not reach the gate in time");

            public void Proceed() => _proceed.Set();
        }

        [Test]
        public void SetConsent_DowngradeToNone_DropsInFlightTrack_RecordedAfterRevocation()
        {
            // Reproduces the window where a Track call observed consent=Anonymous,
            // built its message, and is about to enqueue, while a concurrent
            // SetConsent(None) revokes consent. The event is recorded (enqueued)
            // after revocation, so the record-time consent gate inside the drain
            // lock must drop it. Without the re-check, the enqueue lands post-
            // revocation and the event is recorded despite consent being None.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));

            // Drain the game_launch that Init auto-fires so the assertion below is
            // about our race event only.
            ImmutableAudience.FlushQueueToDiskForTesting();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            // Track snapshots _state (Anonymous) then parks in ToProperties.
            // SetConsent(None) runs to completion while it's parked, so the
            // enqueue that follows Proceed() is guaranteed to land after the flip.
            var evt = new GatedEvent("racing_event");
            var trackTask = Task.Run(() => ImmutableAudience.Track(evt));

            evt.WaitUntilReady();
            ImmutableAudience.SetConsent(ConsentLevel.None);
            evt.Proceed();
            trackTask.Wait(TimeSpan.FromSeconds(5));

            // Flush any residue that a faulty Enqueue may have pushed to memory.
            ImmutableAudience.FlushQueueToDiskForTesting();

            var leaked = Directory.Exists(queueDir)
                ? Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText)
                    .Count(c => c.Contains("\"racing_event\""))
                : 0;

            Assert.AreEqual(0, leaked,
                "Track that raced SetConsent(None) must not be recorded after revocation");
        }

        [Test]
        public void SetConsent_DowngradeToNone_StressTest_NoLeak()
        {
            // Multi-tracker variant of the single-shot test above: several
            // Track calls all park mid-flight (post state-snapshot, pre-enqueue)
            // simultaneously, then SetConsent(None) runs to completion before
            // any of them is released, so every enqueue lands after the flip
            // and must be dropped -- also exercising concurrent contention on
            // EventQueue's drain lock.
            //
            // Without the EnqueueChecked re-check, this test records events
            // reproducibly. With the fix, zero leaks.
            const int trackersPerIteration = 4;

            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));

            // Clear game_launch so only race events can leak.
            ImmutableAudience.FlushQueueToDiskForTesting();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            if (Directory.Exists(queueDir))
                foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            var events = new GatedEvent[trackersPerIteration];
            var trackers = new Task[trackersPerIteration];
            for (int t = 0; t < trackersPerIteration; t++)
            {
                var evt = new GatedEvent("race_stress");
                events[t] = evt;
                trackers[t] = Task.Run(() => ImmutableAudience.Track(evt));
            }

            foreach (var evt in events) evt.WaitUntilReady();
            ImmutableAudience.SetConsent(ConsentLevel.None);
            foreach (var evt in events) evt.Proceed();
            Task.WaitAll(trackers, TimeSpan.FromSeconds(5));

            // Anything the drain loop hasn't picked up yet → force it.
            ImmutableAudience.FlushQueueToDiskForTesting();

            int leaked = 0;
            if (Directory.Exists(queueDir))
            {
                leaked = Directory.GetFiles(queueDir, "*.json")
                    .Select(File.ReadAllText)
                    .Count(c => c.Contains("\"race_stress\""));
            }

            Assert.AreEqual(0, leaked, "race_stress events must not be recorded after SetConsent(None)");
        }

        [Test]
        public void Init_ConcurrentWithSetConsent_LeavesConsistentState()
        {
            // Pre-fix (before 1784ae3f), SetConsent mutated _consent and
            // _session outside any lock. A SetConsent landing between Init's
            // _initialized = true and its _session = new Session(...)
            // observed _session = null, skipped the dispose path, and let
            // Init finish creating a Session whose timer was never disposed.
            //
            // Limitation: the race window is narrow and not deterministically
            // reproducible without a test hook inside Init. This is a
            // probabilistic guard: many iterations of concurrent Init /
            // SetConsent(None) from two threads, asserting only that the
            // final state is consistent (consent is whichever the last lock
            // holder set, no exceptions escape, Init did not silently ignore
            // the race). Regressions that fully remove SetConsent's lock
            // would still show up here via ConsentLevel mismatches or
            // exceptions on a majority of iterations.
            const int iterations = 50;
            for (int iter = 0; iter < iterations; iter++)
            {
                Exception initEx = null;
                Exception setConsentEx = null;

                var setConsentTask = Task.Run(() =>
                {
                    try
                    {
                        Thread.Yield();
                        ImmutableAudience.SetConsent(ConsentLevel.None);
                    }
                    catch (Exception ex) { setConsentEx = ex; }
                });

                var initTask = Task.Run(() =>
                {
                    try { ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous)); }
                    catch (Exception ex) { initEx = ex; }
                });

                Assert.IsTrue(Task.WaitAll(new[] { initTask, setConsentTask }, TimeSpan.FromSeconds(5)),
                    $"iteration {iter}: Init / SetConsent must complete within 5s");
                Assert.IsNull(initEx, $"iteration {iter}: Init threw {initEx}");
                Assert.IsNull(setConsentEx, $"iteration {iter}: SetConsent threw {setConsentEx}");

                // Either order is valid:
                //   - SetConsent runs first: _initialized is false, SetConsent
                //     early-returns, Init then initialises with Anonymous.
                //   - Init runs first: Init sets Anonymous, SetConsent flips
                //     to None under the lock, consent ends at None.
                var finalConsent = ImmutableAudience.CurrentConsent;
                Assert.That(finalConsent,
                    Is.EqualTo(ConsentLevel.None).Or.EqualTo(ConsentLevel.Anonymous),
                    $"iteration {iter}: unexpected final consent {finalConsent}");

                ImmutableAudience.ResetState();
                if (Directory.Exists(AudiencePaths.AudienceDir(_testDir)))
                    Directory.Delete(AudiencePaths.AudienceDir(_testDir), recursive: true);
            }
        }

        [Test]
        public void SetConsent_ConcurrentUpgradeFromNone_StartsOneSession_StressTest()
        {
            // Starting from ConsentLevel.None, N threads race to
            // SetConsent(Anonymous). Without the _initLock in SetConsent,
            // multiple threads observe previous == None, each take the
            // upgrade branch, each build a fresh Session, each Start() it.
            // The last _session = new Session(...) wins; the earlier
            // instances keep their heartbeat timers running on the
            // thread pool forever (heartbeats land as dropped-by-CanTrack
            // no-ops but the Timer allocations leak unbounded).
            //
            // Wire-visible symptom: multiple session_start events hit the
            // queue per iteration. With the lock, exactly one thread
            // flips _consent, the rest observe previous == Anonymous and
            // return without touching _session.
            //
            // Sabotage: removing the lock (or widening the else-if to skip
            // the previous-consent check) fails this test reliably within
            // a handful of iterations.
            const int iterations = 100;
            const int callersPerIteration = 4;

            for (int iter = 0; iter < iterations; iter++)
            {
                ImmutableAudience.Init(MakeConfig(ConsentLevel.None));

                var barrier = new Barrier(callersPerIteration);
                var callers = new Task[callersPerIteration];
                for (int c = 0; c < callersPerIteration; c++)
                {
                    callers[c] = Task.Run(() =>
                    {
                        barrier.SignalAndWait();
                        ImmutableAudience.SetConsent(ConsentLevel.Anonymous);
                    });
                }

                Task.WaitAll(callers, TimeSpan.FromSeconds(5));
                ImmutableAudience.FlushQueueToDiskForTesting();

                var queueDir = AudiencePaths.QueueDir(_testDir);
                var sessionStarts = Directory.Exists(queueDir)
                    ? Directory.GetFiles(queueDir, "*.json")
                        .Select(File.ReadAllText)
                        .Count(c => c.Contains("\"session_start\""))
                    : 0;

                if (sessionStarts != 1)
                {
                    Assert.Fail(
                        $"iteration {iter}: expected exactly one session_start from concurrent SetConsent upgrade, got {sessionStarts}");
                }

                ImmutableAudience.ResetState();
                if (Directory.Exists(AudiencePaths.AudienceDir(_testDir)))
                    Directory.Delete(AudiencePaths.AudienceDir(_testDir), recursive: true);
            }
        }

        [Test]
        public void SetConsent_DowngradeToAnonymous_StressTest_NoUserIdLeak()
        {
            // Full → Anonymous race: several Track calls snapshot _state with
            // userId still set, then park mid-flight (post-snapshot, pre-enqueue)
            // via GatedEvent. SetConsent(Anonymous) flips _state to completion
            // while they're parked, so every enqueue that follows is guaranteed
            // to land after the flip and the record-time consent gate must strip
            // the userId so the event is recorded under the consent in force at
            // enqueue.
            //
            // With the ConsentState + EnqueueChecked transform in place, Track's
            // transform runs under _drainLock and strips userId when current state
            // is not Full. Also exercises concurrent contention on the drain lock
            // across multiple simultaneously-released trackers.
            //
            // Note: this covers the in-flight enqueue race only. Events already
            // recorded before the downgrade keep the userId/consent they were
            // captured with and are intentionally not rewritten.
            //
            // Sabotage: remove either `m.Remove(MessageFields.UserId)` or
            // `m.Remove(MessageFields.IdentityType)` in EnqueueTrack and this
            // test leaks reproducibly.
            const int trackersPerIteration = 4;
            const string testUserId = "user_race_stress";

            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify(testUserId, IdentityType.Steam);

            // Clear Init events so only race events can leak.
            ImmutableAudience.FlushQueueToDiskForTesting();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            if (Directory.Exists(queueDir))
                foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            var events = new GatedEvent[trackersPerIteration];
            var trackers = new Task[trackersPerIteration];
            for (int t = 0; t < trackersPerIteration; t++)
            {
                var evt = new GatedEvent("race_stress");
                events[t] = evt;
                trackers[t] = Task.Run(() => ImmutableAudience.Track(evt));
            }

            foreach (var evt in events) evt.WaitUntilReady();
            ImmutableAudience.SetConsent(ConsentLevel.Anonymous);
            foreach (var evt in events) evt.Proceed();
            Task.WaitAll(trackers, TimeSpan.FromSeconds(5));

            ImmutableAudience.FlushQueueToDiskForTesting();

            int userIdLeaks = 0;
            int identityTypeLeaks = 0;
            if (Directory.Exists(queueDir))
            {
                var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
                userIdLeaks = blobs.Count(c => c.Contains($"\"{testUserId}\""));
                identityTypeLeaks = blobs.Count(c => c.Contains("\"identityType\":\"steam\""));
            }

            Assert.AreEqual(0, userIdLeaks, "track events must not retain userId past SetConsent(Anonymous)");
            Assert.AreEqual(0, identityTypeLeaks, "track events must not retain identityType past SetConsent(Anonymous)");
        }

        [Test]
        public void SetConsent_DowngradeToAnonymous_ClearsIdentityTypeAndCurrentIdentityType()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify("player-42", IdentityType.Steam);

            ImmutableAudience.SetConsent(ConsentLevel.Anonymous);
            Assert.IsNull(ImmutableAudience.CurrentIdentityType,
                "CurrentIdentityType must be cleared by a downgrade out of Full consent");

            ImmutableAudience.Track("post_downgrade_event");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = Path.Combine(_testDir, "imtbl_audience", "queue");
            var blobs = Directory.GetFiles(queueDir, "*.json").Select(File.ReadAllText).ToList();
            var postDowngradeBlob = blobs.First(b => b.Contains("\"eventName\":\"post_downgrade_event\""));

            Assert.IsFalse(postDowngradeBlob.Contains("\"identityType\":"),
                "track events after a consent downgrade must not carry a stale identityType");
        }

        [Test]
        public void Shutdown_ClearsCurrentIdentityType()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify("player-42", IdentityType.Steam);
            Assert.AreEqual(IdentityType.Steam, ImmutableAudience.CurrentIdentityType);

            ImmutableAudience.Shutdown();

            Assert.IsNull(ImmutableAudience.CurrentIdentityType,
                "Shutdown must clear CurrentIdentityType so a later Init doesn't inherit a stale identity");
        }

        [Test]
        public void ResetState_ClearsIdentityCache_AcrossInitWithDifferentPath()
        {
            // First init: mints and caches an anonymousId under _testDir.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            var firstId = Identity.GetOrCreate(_testDir, ConsentLevel.Anonymous);
            ImmutableAudience.Shutdown();

            // Second init with a different persistentDataPath. If Identity's
            // static cache survives Shutdown, GetOrCreate returns firstId
            // even though the new path has its own (yet-to-be-written) file.
            var otherDir = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(otherDir);
            try
            {
                var config2 = MakeConfig(ConsentLevel.Anonymous);
                config2.PersistentDataPath = otherDir;
                ImmutableAudience.Init(config2);

                var secondId = Identity.GetOrCreate(otherDir, ConsentLevel.Anonymous);
                Assert.AreNotEqual(firstId, secondId,
                    "ResetState must drop Identity's in-memory cache so the new path mints its own id");
            }
            finally
            {
                Identity.Reset(otherDir);
                if (Directory.Exists(otherDir))
                    Directory.Delete(otherDir, recursive: true);
            }
        }

        [Test]
        public void SetConsent_PersistFailure_SurfacesOnError()
        {
            // Pre-create a directory where ConsentStore.Save wants to place
            // the consent file; File.Move then fails without disturbing
            // Init's DiskStore or Identity paths.
            var consentFile = AudiencePaths.ConsentFile(_testDir);
            Directory.CreateDirectory(consentFile);

            // Bag rather than single capture: ConsentPersistFailed fires
            // synchronously on the caller thread, SyncConsentToBackend's
            // Task.Run may also fire ConsentSyncFailed concurrently. Assert
            // presence of the one under test rather than the last seen.
            var errors = new System.Collections.Concurrent.ConcurrentBag<AudienceError>();
            var config = MakeConfig(ConsentLevel.Anonymous);
            config.OnError = err => errors.Add(err);

            ImmutableAudience.Init(config);
            ImmutableAudience.SetConsent(ConsentLevel.Full);

            Assert.That(errors.Any(e => e.Code == AudienceErrorCode.ConsentPersistFailed),
                Is.True, "OnError should receive ConsentPersistFailed for consent persist failure");
        }

        [Test]
        public void SetConsent_PersistsAcrossInit()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));
            ImmutableAudience.SetConsent(ConsentLevel.Full);
            ImmutableAudience.Shutdown();

            // Re-init with the *original* (Anonymous) config. Persisted Full should win.
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Anonymous));

            Assert.AreEqual(ConsentLevel.Full, ImmutableAudience.CurrentConsent,
                "persisted consent must override the config default after restart");
        }

        // -----------------------------------------------------------------
        // game_launch auto-fire
        // -----------------------------------------------------------------

        [Test]
        public void Init_FiresGameLaunch_Automatically()
        {
            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"game_launch\"")),
                "Init should auto-fire game_launch");
        }

        [Test]
        public void Init_GameLaunch_IncludesDistributionPlatform()
        {
            var config = MakeConfig();
            config.DistributionPlatform = DistributionPlatforms.Steam;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c =>
                c.Contains("\"game_launch\"") && c.Contains("\"steam\"")));
        }

        [Test]
        public void Init_LowercasesDistributionPlatform_WhenCallerPassesMixedCase()
        {
            var config = MakeConfig();
            config.DistributionPlatform = "Steam";
            ImmutableAudience.Init(config);

            Assert.AreEqual("steam", config.DistributionPlatform,
                "Init should lowercase mixed-case DistributionPlatform so dashboards aggregate consistently.");
        }

        [Test]
        public void Init_LowercasesDistributionPlatform_WhenCallerPassesAllUpperCase()
        {
            var config = MakeConfig();
            config.DistributionPlatform = "STEAM";
            ImmutableAudience.Init(config);

            Assert.AreEqual("steam", config.DistributionPlatform);
        }

        [Test]
        public void Init_LeavesDistributionPlatformUnchanged_WhenAlreadyLowercase()
        {
            var config = MakeConfig();
            config.DistributionPlatform = "steam";
            ImmutableAudience.Init(config);

            Assert.AreEqual("steam", config.DistributionPlatform);
        }

        [Test]
        public void Init_LeavesDistributionPlatformNull_WhenNotSet()
        {
            var config = MakeConfig();
            Assert.IsNull(config.DistributionPlatform);
            ImmutableAudience.Init(config);

            Assert.IsNull(config.DistributionPlatform);
        }

        [Test]
        public void Init_ConsentNone_DoesNotFireGameLaunch()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.None));
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            if (!Directory.Exists(queueDir))
            {
                Assert.Pass();
                return;
            }

            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(contents.Any(c => c.Contains("\"game_launch\"")));
        }

        [Test]
        public void Init_GameLaunch_IncludesLaunchContextProviderFields()
        {
            ImmutableAudience.LaunchContextProvider = () => new Dictionary<string, object>
            {
                ["platform"] = "Windows",
                ["version"] = "1.2.3",
                ["build_guid"] = "a1b2c3d4e5f6",
                ["unity_version"] = "2022.3.20f1",
            };

            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var launchFile = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText)
                .FirstOrDefault(c => c.Contains("\"game_launch\""));
            Assert.IsNotNull(launchFile, "game_launch should have been enqueued");
            StringAssert.Contains("\"platform\":\"Windows\"", launchFile);
            StringAssert.Contains("\"version\":\"1.2.3\"", launchFile);
            StringAssert.Contains("\"build_guid\":\"a1b2c3d4e5f6\"", launchFile);
            StringAssert.Contains("\"unity_version\":\"2022.3.20f1\"", launchFile);
        }

        [Test]
        public void Init_GameLaunch_ConfigDistributionPlatformOverridesProvider()
        {
            ImmutableAudience.LaunchContextProvider = () => new Dictionary<string, object>
            {
                ["distribution_platform"] = "provider_value",
            };

            var config = MakeConfig();
            config.DistributionPlatform = DistributionPlatforms.Steam;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var launchFile = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"distribution_platform\":\"steam\"", launchFile);
            Assert.IsFalse(launchFile.Contains("provider_value"),
                "config.DistributionPlatform should win over the provider's value");
        }

        [Test]
        public void Init_GameLaunch_ProviderThrows_StillFiresEvent()
        {
            ImmutableAudience.LaunchContextProvider = () =>
                throw new InvalidOperationException("provider exploded");

            Assert.DoesNotThrow(() => ImmutableAudience.Init(MakeConfig()));
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var contents = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(contents.Any(c => c.Contains("\"game_launch\"")),
                "game_launch must still ship when the context provider throws");
        }

        [Test]
        public void Init_GameLaunch_IncludesSkanRegistered_WhenProviderReturnsTrue()
        {
            ImmutableAudience.MobileAttributionProvider = () => true;
            var config = MakeConfig();
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"skan_registered\":true", launchFile);
        }

        [Test]
        public void Init_GameLaunch_OmitsSkanRegistered_WhenProviderReturnsNull()
        {
            ImmutableAudience.MobileAttributionProvider = () => null;
            var config = MakeConfig();
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            Assert.IsFalse(launchFile.Contains("skan_registered"));
        }

        [Test]
        public void Init_GameLaunch_OmitsSkanRegistered_WhenMobileAttributionDisabled()
        {
            var callCount = 0;
            ImmutableAudience.MobileAttributionProvider = () => { callCount++; return true; };
            var config = MakeConfig();
            config.EnableMobileAttribution = false;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            Assert.AreEqual(0, callCount,
                "MobileAttributionProvider must not be called when EnableMobileAttribution is false");
            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            Assert.IsFalse(launchFile.Contains("skan_registered"));
        }

        [Test]
        public void Init_GameLaunch_IncludesAttStatusAndIdfa_WhenContextProviderReturns()
        {
            ImmutableAudience.MobileAttributionContextProvider = () =>
                new Dictionary<string, object>
                {
                    ["att_status"] = "authorized",
                    ["idfa"] = "11111111-2222-3333-4444-555555555555",
                };
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"att_status\":\"authorized\"", launchFile);
            StringAssert.Contains("\"idfa\":\"11111111-2222-3333-4444-555555555555\"", launchFile);
        }

        [Test]
        public void Init_GameLaunch_IncludesAttStatusOnly_WhenIdfaUnauthorized()
        {
            ImmutableAudience.MobileAttributionContextProvider = () =>
                new Dictionary<string, object>
                {
                    ["att_status"] = "denied",
                };
            var config = MakeConfig();
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"att_status\":\"denied\"", launchFile);
            Assert.IsFalse(launchFile.Contains("\"idfa\""),
                "idfa must not appear when ATT status is denied");
        }

        [Test]
        public void Init_GameLaunch_OmitsAttributionContext_WhenMobileAttributionDisabled()
        {
            var callCount = 0;
            ImmutableAudience.MobileAttributionContextProvider = () =>
            {
                callCount++;
                return new Dictionary<string, object> { ["att_status"] = "authorized" };
            };
            var config = MakeConfig();
            config.EnableMobileAttribution = false;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            Assert.AreEqual(0, callCount,
                "MobileAttributionContextProvider must not be called when EnableMobileAttribution is false");
            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            Assert.IsFalse(launchFile.Contains("att_status"));
            Assert.IsFalse(launchFile.Contains("idfa"));
        }

        [Test]
        public void Init_AttributionProviders_NotCalled_WhenConsentNone()
        {
            // Consent gate must precede attribution side effects: SKAN
            // registration (network call), IDFA/ATT reads, and the install
            // referrer fetch must not fire when the user hasn't authorized
            // any tracking.
            var skanCallCount = 0;
            var contextCallCount = 0;
            var installReferrerCallCount = 0;
            ImmutableAudience.MobileAttributionProvider = () => { skanCallCount++; return true; };
            ImmutableAudience.MobileAttributionContextProvider = () =>
            {
                contextCallCount++;
                return new Dictionary<string, object> { ["att_status"] = "authorized" };
            };
            ImmutableAudience.MobileInstallReferrerProvider = () =>
            {
                installReferrerCallCount++;
                return "utm_source=test";
            };

            var config = MakeConfig(ConsentLevel.None);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            Assert.AreEqual(0, skanCallCount,
                "MobileAttributionProvider must not run when consent is None");
            Assert.AreEqual(0, contextCallCount,
                "MobileAttributionContextProvider must not run when consent is None");
            Assert.AreEqual(0, installReferrerCallCount,
                "MobileInstallReferrerProvider must not run when consent is None");
        }

        [Test]
        public void Init_GameLaunch_AttributionContextProviderThrows_DoesNotPreventEvent()
        {
            ImmutableAudience.MobileAttributionContextProvider = () =>
                throw new InvalidOperationException("provider exploded");
            var config = MakeConfig();
            config.EnableMobileAttribution = true;

            Assert.DoesNotThrow(() => ImmutableAudience.Init(config));
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            Assert.IsFalse(launchFile.Contains("att_status"));
        }

        [Test]
        public void Init_GameLaunch_IncludesGaidAndLimitFlag_WhenContextProviderReturns()
        {
            // Android attribution shape: gaid + gaidLimitAdTracking. Ships
            // from launch #2 onwards (Google's getAdvertisingIdInfo is async
            // off-main-thread; first launch's cache is empty when game_launch
            // fires). Test asserts the wire shape, not the async timing.
            ImmutableAudience.MobileAttributionContextProvider = () =>
                new Dictionary<string, object>
                {
                    ["gaid"] = "abcdef01-2345-6789-abcd-ef0123456789",
                    ["gaid_limit_ad_tracking"] = false,
                };
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"gaid\":\"abcdef01-2345-6789-abcd-ef0123456789\"", launchFile);
            StringAssert.Contains("\"gaid_limit_ad_tracking\":false", launchFile);
        }

        [Test]
        public void Init_GameLaunch_OmitsGaid_WhenUserOptedOut()
        {
            // User opted out: gaid omitted, but gaidLimitAdTracking=true ships
            // so the pipeline can distinguish "fetched, opted out" from
            // "not fetched yet" (both absent).
            ImmutableAudience.MobileAttributionContextProvider = () =>
                new Dictionary<string, object>
                {
                    ["gaid_limit_ad_tracking"] = true,
                };
            var config = MakeConfig();
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"gaid_limit_ad_tracking\":true", launchFile);
            Assert.IsFalse(launchFile.Contains("\"gaid\""),
                "gaid must not appear when the user has opted out");
        }

        // -----------------------------------------------------------------
        // Consent-tier tightening: idfa, gaid => Full-only
        //
        // idfa and gaid are cross-app device identifiers, same privacy class
        // as userId. They ship only when consent is Full. State-class keys
        // (att_status, gaid_limit_ad_tracking) are non-identifying and ship at
        // Anonymous+Full (CanTrack).
        // -----------------------------------------------------------------

        [Test]
        public void Init_GameLaunch_StripsIdfa_WhenConsentAnonymous()
        {
            ImmutableAudience.MobileAttributionContextProvider = () =>
                new Dictionary<string, object>
                {
                    ["att_status"] = "authorized",
                    ["idfa"] = "11111111-2222-3333-4444-555555555555",
                };
            var config = MakeConfig(ConsentLevel.Anonymous);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"att_status\":\"authorized\"", launchFile,
                "att_status must ship at Anonymous: it is non-identifying state");
            Assert.IsFalse(launchFile.Contains("\"idfa\""),
                "idfa must not ship at Anonymous: it is a cross-app device identifier");
        }

        [Test]
        public void Init_GameLaunch_StripsGaid_WhenConsentAnonymous()
        {
            // gaid is stripped at Anonymous; gaid_limit_ad_tracking is non-identifying
            // state and must still ship so the pipeline can distinguish
            // "fetched, opted out" from "not fetched yet".
            ImmutableAudience.MobileAttributionContextProvider = () =>
                new Dictionary<string, object>
                {
                    ["gaid"] = "abcdef01-2345-6789-abcd-ef0123456789",
                    ["gaid_limit_ad_tracking"] = false,
                };
            var config = MakeConfig(ConsentLevel.Anonymous);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            StringAssert.Contains("\"gaid_limit_ad_tracking\":false", launchFile,
                "gaid_limit_ad_tracking must ship at Anonymous: it is non-identifying state");
            Assert.IsFalse(launchFile.Contains("\"gaid\""),
                "gaid must not ship at Anonymous: it is a cross-app device identifier");
        }

        // -----------------------------------------------------------------
        // install_referrer_received
        //
        // Dedicated event (not a game_launch property): install attribution
        // is install-level state, decoupled from launch / session lifecycles.
        // Fires once per install. Cache landing late on first launch is
        // recovered by the next Init via the on-disk "sent" marker.
        // -----------------------------------------------------------------

        [Test]
        public void Init_FiresInstallReferrerReceived_WhenProviderReturnsReferrer()
        {
            ImmutableAudience.MobileInstallReferrerProvider = () =>
                "utm_source=google-play&utm_medium=organic";
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(blobs.Any(c =>
                c.Contains("\"install_referrer_received\"") &&
                c.Contains("\"install_referrer\":\"utm_source=google-play&utm_medium=organic\"")),
                "install_referrer_received must ship with the install_referrer property");
        }

        [Test]
        public void Init_GameLaunch_NeverIncludesInstallReferrer()
        {
            // install_referrer is exclusively on the dedicated event; ensure
            // we don't regress and start leaking it onto game_launch.
            ImmutableAudience.MobileInstallReferrerProvider = () => "utm_source=test";
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var launchFile = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText)
                .First(c => c.Contains("\"game_launch\""));
            Assert.IsFalse(launchFile.Contains("install_referrer"),
                "game_launch must never carry install_referrer; it ships on its own event");
        }

        [Test]
        public void Init_DoesNotFireInstallReferrerReceived_WhenProviderReturnsNull()
        {
            // First-launch cache miss: bridge hasn't resolved yet. No event
            // ships; sent marker is not written; next launch can fire it.
            ImmutableAudience.MobileInstallReferrerProvider = () => null;
            var config = MakeConfig();
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(c => c.Contains("\"install_referrer_received\"")));
            Assert.IsFalse(File.Exists(AudiencePaths.InstallReferrerSentFile(_testDir)),
                "sent marker must not be written when the event did not fire");
        }

        [Test]
        public void Init_DoesNotFireInstallReferrerReceived_WhenProviderReturnsEmpty()
        {
            // Empty cache file marks "fetched, no referrer". Bridge maps
            // that to null on read, but defend the contract here too.
            ImmutableAudience.MobileInstallReferrerProvider = () => string.Empty;
            var config = MakeConfig();
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(c => c.Contains("\"install_referrer_received\"")));
        }

        [Test]
        public void Init_DoesNotFireInstallReferrerReceived_WhenAlreadyFired()
        {
            // Simulate the second launch: cache is populated, marker is set
            // by the previous Init. Event must not refire.
            ImmutableAudience.MobileInstallReferrerProvider = () => "utm_source=test";
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;

            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            // Drop the queue from the first Init so we count only the second.
            var queueDir = AudiencePaths.QueueDir(_testDir);
            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            var config2 = MakeConfig(ConsentLevel.Full);
            config2.EnableMobileAttribution = true;
            ImmutableAudience.Init(config2);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(c => c.Contains("\"install_referrer_received\"")),
                "install_referrer_received must fire exactly once per install");
        }

        [Test]
        public void Init_DoesNotFireInstallReferrerReceived_WhenMobileAttributionDisabled()
        {
            var callCount = 0;
            ImmutableAudience.MobileInstallReferrerProvider = () =>
            {
                callCount++;
                return "utm_source=should_not_ship";
            };
            var config = MakeConfig();
            config.EnableMobileAttribution = false;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            Assert.AreEqual(0, callCount,
                "MobileInstallReferrerProvider must not be called when EnableMobileAttribution is false");
            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(c => c.Contains("\"install_referrer_received\"")));
        }

        [Test]
        public void Init_FiresInstallReferrerReceived_OnSecondLaunch_WhenFirstMissedCache()
        {
            // First launch: bridge fetch in flight, provider returns null.
            // Second launch: cache populated, provider returns the referrer.
            // Event must fire on the second Init even though it missed the first.
            string? firstCallReturn = null;
            string? secondCallReturn = "utm_source=second_launch";
            var callCount = 0;
            ImmutableAudience.MobileInstallReferrerProvider = () =>
                ++callCount == 1 ? firstCallReturn : secondCallReturn;

            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            // Confirm the first launch did not ship it.
            var firstBlobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(firstBlobs.Any(c => c.Contains("\"install_referrer_received\"")),
                "first Init should not ship the event when the cache is empty");

            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            var config2 = MakeConfig(ConsentLevel.Full);
            config2.EnableMobileAttribution = true;
            ImmutableAudience.Init(config2);
            ImmutableAudience.Shutdown();

            var secondBlobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(secondBlobs.Any(c =>
                c.Contains("\"install_referrer_received\"") &&
                c.Contains("\"install_referrer\":\"utm_source=second_launch\"")),
                "second Init must ship install_referrer_received when the cache landed late");
        }

        [Test]
        public void Init_InstallReferrerProviderThrows_DoesNotPreventGameLaunch()
        {
            ImmutableAudience.MobileInstallReferrerProvider = () =>
                throw new InvalidOperationException("bridge exploded");
            var config = MakeConfig();
            config.EnableMobileAttribution = true;

            Assert.DoesNotThrow(() => ImmutableAudience.Init(config));
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(blobs.Any(c => c.Contains("\"game_launch\"")),
                "game_launch must still ship when the install referrer provider throws");
            Assert.IsFalse(blobs.Any(c => c.Contains("\"install_referrer_received\"")));
        }

        [Test]
        public void Init_DoesNotFireInstallReferrerReceived_WhenConsentAnonymous()
        {
            // install_referrer encodes campaign attribution source; Full-only.
            // The sent marker must NOT be written so a later upgrade to Full
            // can fire the event.
            ImmutableAudience.MobileInstallReferrerProvider = () => "utm_source=google-play";
            var config = MakeConfig(ConsentLevel.Anonymous);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(c => c.Contains("\"install_referrer_received\"")),
                "install_referrer_received must not fire when consent is Anonymous");
            Assert.IsFalse(File.Exists(AudiencePaths.InstallReferrerSentFile(_testDir)),
                "sent marker must not be written at Anonymous so a Full upgrade can fire the event");
        }

        [Test]
        public void Init_FiresInstallReferrerReceived_AfterConsentUpgradedToFull()
        {
            // First launch at Anonymous: referrer is available but event is
            // gated; no event fires and no sent marker is written.
            // Second launch at Full: event fires and marker is written.
            ImmutableAudience.MobileInstallReferrerProvider = () => "utm_source=upgrade_test";

            var config = MakeConfig(ConsentLevel.Anonymous);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var firstBlobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(firstBlobs.Any(c => c.Contains("\"install_referrer_received\"")),
                "event must not ship on first launch when consent is Anonymous");
            Assert.IsFalse(File.Exists(AudiencePaths.InstallReferrerSentFile(_testDir)),
                "sent marker must not exist after Anonymous launch");

            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            var config2 = MakeConfig(ConsentLevel.Full);
            config2.EnableMobileAttribution = true;
            ImmutableAudience.Init(config2);
            ImmutableAudience.Shutdown();

            var secondBlobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(secondBlobs.Any(c =>
                c.Contains("\"install_referrer_received\"") &&
                c.Contains("\"install_referrer\":\"utm_source=upgrade_test\"")),
                "event must fire on the first Full-consent launch after an Anonymous launch");
        }

        // -----------------------------------------------------------------
        // RequestTrackingAuthorizationAsync
        // -----------------------------------------------------------------

        [Test]
        public async Task RequestTrackingAuthorization_NoProvider_ReturnsNotDetermined()
        {
            // No provider set (non-iOS environment).
            var status = await ImmutableAudience.RequestTrackingAuthorizationAsync();
            Assert.AreEqual(TrackingAuthorizationStatus.NotDetermined, status);
        }

        [Test]
        public async Task RequestTrackingAuthorization_ProviderReturnsAuthorized_MapsToEnum()
        {
            ImmutableAudience.TrackingAuthorizationRequestProvider = () => Task.FromResult(3);
            var status = await ImmutableAudience.RequestTrackingAuthorizationAsync();
            Assert.AreEqual(TrackingAuthorizationStatus.Authorized, status);
        }

        [Test]
        public async Task RequestTrackingAuthorization_ProviderReturnsDenied_MapsToEnum()
        {
            ImmutableAudience.TrackingAuthorizationRequestProvider = () => Task.FromResult(2);
            var status = await ImmutableAudience.RequestTrackingAuthorizationAsync();
            Assert.AreEqual(TrackingAuthorizationStatus.Denied, status);
        }

        [Test]
        public async Task RequestTrackingAuthorization_ProviderThrows_ReturnsNotDetermined()
        {
            ImmutableAudience.TrackingAuthorizationRequestProvider = () =>
                throw new InvalidOperationException("provider exploded");
            var status = await ImmutableAudience.RequestTrackingAuthorizationAsync();
            Assert.AreEqual(TrackingAuthorizationStatus.NotDetermined, status);
        }

        [Test]
        public async Task RequestTrackingAuthorization_OutOfRangeStatus_ReturnsNotDetermined()
        {
            ImmutableAudience.TrackingAuthorizationRequestProvider = () => Task.FromResult(99);
            var status = await ImmutableAudience.RequestTrackingAuthorizationAsync();
            Assert.AreEqual(TrackingAuthorizationStatus.NotDetermined, status);
        }

        // -----------------------------------------------------------------
        // Shutdown
        // -----------------------------------------------------------------

        [Test]
        public void Shutdown_CalledTwice_DoesNotThrow()
        {
            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Shutdown();
            Assert.DoesNotThrow(() => ImmutableAudience.Shutdown());
        }

        [Test]
        public void Track_AfterShutdown_IsIgnored()
        {
            ImmutableAudience.Init(MakeConfig());
            ImmutableAudience.Shutdown();

            Assert.DoesNotThrow(() => ImmutableAudience.Track("should_not_crash"));
        }

        [Test]
        public void Shutdown_ReleasesInitLock_BeforeBlockingTeardown()
        {
            // Hanging handler: the final flush inside Shutdown's Phase 2 will
            // block in transport.SendBatchAsync().Wait(timeoutMs). Pre-refactor,
            // _initLock was held across that wait; SetConsent / Reset on another
            // thread would be stranded for the full ShutdownFlushTimeoutMs.
            var handler = new BlockingHandler();
            var config = MakeConfig();
            config.HttpHandler = handler;
            config.ShutdownFlushTimeoutMs = 10_000;

            ImmutableAudience.Init(config);
            ImmutableAudience.Track("ensure_nonempty_queue");
            ImmutableAudience.FlushQueueToDiskForTesting();

            // Phase 1 flips _initialized and releases the lock; Phase 2 enters
            // the hanging final flush.
            var shutdown = Task.Run(() => ImmutableAudience.Shutdown());

            Assert.IsTrue(handler.EnteredSendAsync.Wait(TimeSpan.FromSeconds(5)),
                "Shutdown should reach the hanging final flush inside Phase 2");

            // Reset unconditionally acquires _initLock. If Phase 2 held the lock
            // this would block for ~10s; post-refactor the lock is free, Reset
            // sees !_initialized and returns in microseconds.
            var sw = System.Diagnostics.Stopwatch.StartNew();
            ImmutableAudience.Reset();
            sw.Stop();

            Assert.Less(sw.ElapsedMilliseconds, 500,
                $"Reset must not block on Shutdown's Phase 2; took {sw.ElapsedMilliseconds}ms");

            handler.Release.Set();
            Assert.IsTrue(shutdown.Wait(TimeSpan.FromSeconds(15)),
                "Shutdown should finish after handler release");
        }

        // -----------------------------------------------------------------
        // Full -> Anonymous consent downgrade
        // -----------------------------------------------------------------

        [Test]
        public void FullToAnonymous_KeepsQueuedIdentifyAliasAndUserId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));

            ImmutableAudience.Identify("player_steam", IdentityType.Steam);
            ImmutableAudience.Alias("player_steam", IdentityType.Steam, "email|player_passport", IdentityType.Passport);
            ImmutableAudience.Track("tracked_before_downgrade");

            ImmutableAudience.FlushQueueToDiskForTesting();

            ImmutableAudience.SetConsent(ConsentLevel.Anonymous);

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var msgs = Directory.GetFiles(queueDir, "*.json")
                .Select(f => JsonReader.DeserializeObject(File.ReadAllText(f)))
                .ToList();

            // Events recorded under Full keep the identity and consent they were
            // captured with; a downgrade only gates future collection and must
            // not rewrite or drop already-queued events.
            Assert.IsTrue(msgs.Any(m => (string)m["type"] == "identify"),
                "queued identify must be retained on Full -> Anonymous");
            Assert.IsTrue(msgs.Any(m => (string)m["type"] == "alias"),
                "queued alias must be retained on Full -> Anonymous");

            var track = msgs.First(m => (string)m["type"] == "track"
                && m.ContainsKey("eventName")
                && (string)m["eventName"] == "tracked_before_downgrade");
            Assert.AreEqual("player_steam", track["userId"],
                "queued track must keep the userId it was captured with under Full");
            Assert.AreEqual("full", track["consentLevel"],
                "queued track must keep the consentLevel it was captured with under Full");
        }

        [Test]
        public void FullToAnonymous_FutureTracksOmitUserId()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Identify("player_steam", IdentityType.Steam);
            ImmutableAudience.SetConsent(ConsentLevel.Anonymous);

            ImmutableAudience.Track("tracked_after_downgrade");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var trackFiles = Directory.GetFiles(queueDir, "*.json")
                .Select(f => JsonReader.DeserializeObject(File.ReadAllText(f)))
                .Where(m => (string)m["type"] == "track"
                            && m.ContainsKey("eventName")
                            && (string)m["eventName"] == "tracked_after_downgrade")
                .ToList();

            Assert.AreEqual(1, trackFiles.Count);
            Assert.IsFalse(trackFiles[0].ContainsKey("userId"),
                "Track under Anonymous consent must not carry userId");
            Assert.AreEqual("anonymous", trackFiles[0]["consentLevel"],
                "Track under Anonymous consent must stamp consentLevel anonymous");
        }

        [Test]
        public void FullConsent_TrackStampsConsentLevelFull()
        {
            ImmutableAudience.Init(MakeConfig(ConsentLevel.Full));
            ImmutableAudience.Track("tracked_under_full");
            ImmutableAudience.FlushQueueToDiskForTesting();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            var track = Directory.GetFiles(queueDir, "*.json")
                .Select(f => JsonReader.DeserializeObject(File.ReadAllText(f)))
                .First(m => (string)m["type"] == "track"
                            && m.ContainsKey("eventName")
                            && (string)m["eventName"] == "tracked_under_full");

            Assert.AreEqual("full", track["consentLevel"],
                "Track under Full consent must stamp consentLevel full");
        }

        // -----------------------------------------------------------------
        // SendBatch: overlapping timer tick guard
        // -----------------------------------------------------------------

        [Test]
        public void SendBatch_ConcurrentTicks_OnlyOneReachesTransport()
        {
            var handler = new BlockingHandler();
            var config = MakeConfig();
            config.HttpHandler = handler;

            ImmutableAudience.Init(config);
            ImmutableAudience.Track("event_to_send");
            ImmutableAudience.FlushQueueToDiskForTesting();

            // Kick off one SendBatch on a worker. It will block inside the
            // handler until we signal, holding _sendInFlight = 1.
            var blocked = Task.Run(() => ImmutableAudience.SendBatchForTesting());

            // Give the worker enough time to enter the handler's SendAsync.
            Assert.IsTrue(handler.EnteredSendAsync.Wait(TimeSpan.FromSeconds(2)),
                "first SendBatch should have reached the HTTP handler");

            // Second tick while the first is still in flight: must return
            // immediately without issuing another request.
            ImmutableAudience.SendBatchForTesting();

            // Release the blocked send and let it finish.
            handler.Release.Set();
            Assert.IsTrue(blocked.Wait(TimeSpan.FromSeconds(5)),
                "blocked SendBatch should finish after release");

            Assert.AreEqual(1, handler.RequestCount,
                "overlapping tick must not issue a second HTTP request");
        }

        [Test]
        public void FlushAsync_ConcurrentCallers_OnlyOneReachesTransport()
        {
            // Two parallel FlushAsync calls must serialise on _sendInFlight so
            // ReadBatch/POST pairs do not double-send. Sabotage: remove the
            // gate in FlushAsync and this test sees RequestCount > 1.
            var handler = new BlockingHandler();
            var config = MakeConfig();
            config.HttpHandler = handler;

            ImmutableAudience.Init(config);
            ImmutableAudience.Track("event_to_send");
            ImmutableAudience.FlushQueueToDiskForTesting();

            // First caller enters SendAsync and blocks on handler.Release.
            var flush1 = Task.Run(() => ImmutableAudience.FlushAsync());
            Assert.IsTrue(handler.EnteredSendAsync.Wait(TimeSpan.FromSeconds(2)),
                "first FlushAsync should reach the HTTP handler");

            // Second caller starts while the first holds the gate; it must
            // wait, not issue a second request.
            var flush2 = Task.Run(() => ImmutableAudience.FlushAsync());

            // Give the second caller a moment to try (and back off).
            Thread.Sleep(200);
            Assert.AreEqual(1, handler.RequestCount,
                "second FlushAsync must not issue a second HTTP request while the first is in-flight");

            handler.Release.Set();
            Assert.IsTrue(Task.WaitAll(new[] { flush1, flush2 }, TimeSpan.FromSeconds(10)),
                "both FlushAsync calls should complete after release");
        }

        [Test]
        public async Task FlushAsync_CancelledToken_Terminates_DoesNotHotLoop()
        {
            // Regression for PR #701 review (@nattb8): if SendBatchAsync
            // silently swallowed caller cancellation, the inner while-loop
            // here would re-enter on the same cancelled token and spin
            // because the batch is never deleted on that code path. The
            // task below would never complete. After the fix, cancellation
            // propagates and the task faults quickly.
            var handler = new CancellingHandler();
            var config = MakeConfig();
            config.HttpHandler = handler;

            ImmutableAudience.Init(config);
            ImmutableAudience.Track("event_to_send");
            ImmutableAudience.FlushQueueToDiskForTesting();

            using var cts = new CancellationTokenSource();
            cts.Cancel();

            var flush = ImmutableAudience.FlushAsync(cts.Token);
            var finishedFirst = await Task.WhenAny(flush, Task.Delay(TimeSpan.FromSeconds(2)));

            Assert.AreSame(flush, finishedFirst,
                "FlushAsync must terminate (not hot-loop) when the token is cancelled");
            Assert.IsTrue(flush.IsCanceled || flush.IsFaulted,
                "FlushAsync must propagate the cancellation, not return normally");
            Assert.LessOrEqual(handler.CallCount, 1,
                "a cancelled token must not drive repeated SendAsync attempts");

            // Gate must be released by the finally block; a follow-up flush
            // on an uncancelled token should proceed, proving _sendInFlight
            // is not stranded at 1.
            handler.AcceptNextAsSuccess = true;
            var followUp = ImmutableAudience.FlushAsync();
            Assert.IsTrue(followUp.Wait(TimeSpan.FromSeconds(2)),
                "_sendInFlight must be released after a cancelled flush");
        }

        private class CancellingHandler : HttpMessageHandler
        {
            public int CallCount;
            public bool AcceptNextAsSuccess;

            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
            {
                Interlocked.Increment(ref CallCount);
                ct.ThrowIfCancellationRequested();
                var status = AcceptNextAsSuccess ? HttpStatusCode.OK : HttpStatusCode.ServiceUnavailable;
                var body = AcceptNextAsSuccess ? "{\"accepted\":1,\"rejected\":0}" : "";
                return Task.FromResult(new HttpResponseMessage(status)
                {
                    Content = new StringContent(body)
                });
            }
        }

        private class BlockingHandler : HttpMessageHandler
        {
            public readonly ManualResetEventSlim EnteredSendAsync = new ManualResetEventSlim(false);
            public readonly ManualResetEventSlim Release = new ManualResetEventSlim(false);
            public int RequestCount;

            protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
            {
                Interlocked.Increment(ref RequestCount);
                EnteredSendAsync.Set();
                await Task.Run(() => Release.Wait(ct), ct).ConfigureAwait(false);
                return new HttpResponseMessage(HttpStatusCode.ServiceUnavailable);
            }
        }

        // -----------------------------------------------------------------
        // tracking_authorization_changed
        //
        // Fires when iOS ATT status transitions to a different value than the
        // last-persisted observation. Requires EnableMobileAttribution and
        // CanTrack(). idfa is included only when transitioning to authorized
        // AND consent is Full.
        // -----------------------------------------------------------------

        [Test]
        public void Init_FiresAttStatusChanged_WhenStatusTransitionsFromCached()
        {
            // Seed: previous launch observed denied (2); this launch is authorized (3).
            AttStatusStore.Save(_testDir, 2);
            ImmutableAudience.MobileATTStatusProvider = () => 3;
            ImmutableAudience.MobileIDFAProvider = () => "11111111-2222-3333-4444-555555555555";
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(blobs.Any(b =>
                b.Contains("\"tracking_authorization_changed\"") &&
                b.Contains("\"previous_status\":\"denied\"") &&
                b.Contains("\"new_status\":\"authorized\"") &&
                b.Contains("\"idfa\":\"11111111-2222-3333-4444-555555555555\"")),
                "Init must fire tracking_authorization_changed when ATT status transitions");
        }

        [Test]
        public void Init_DoesNotFireAttStatusChanged_WhenStatusUnchanged()
        {
            AttStatusStore.Save(_testDir, 3);
            ImmutableAudience.MobileATTStatusProvider = () => 3;
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(b => b.Contains("\"tracking_authorization_changed\"")),
                "no event when ATT status has not changed");
        }

        [Test]
        public void Init_StoresAttStatusBaseline_WithoutFiringEvent_OnFirstObservation()
        {
            // No prior file: first observation establishes the baseline; no event fires
            // because there is no previous state to transition from.
            ImmutableAudience.MobileATTStatusProvider = () => 2; // denied
            var config = MakeConfig(ConsentLevel.Anonymous);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(b => b.Contains("\"tracking_authorization_changed\"")),
                "first observation must not fire tracking_authorization_changed");
            Assert.AreEqual(2, AttStatusStore.Load(_testDir),
                "first observation must persist the baseline status");
        }

        [Test]
        public async Task RequestTrackingAuthorizationAsync_FiresAttStatusChanged_WhenStatusTransitions()
        {
            AttStatusStore.Save(_testDir, 0); // notDetermined
            ImmutableAudience.TrackingAuthorizationRequestProvider = () => Task.FromResult(3); // authorized
            ImmutableAudience.MobileIDFAProvider = () => "11111111-2222-3333-4444-555555555555";
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);

            ImmutableAudience.FlushQueueToDiskForTesting();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            await ImmutableAudience.RequestTrackingAuthorizationAsync();
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsTrue(blobs.Any(b =>
                b.Contains("\"tracking_authorization_changed\"") &&
                b.Contains("\"previous_status\":\"notDetermined\"") &&
                b.Contains("\"new_status\":\"authorized\"") &&
                b.Contains("\"idfa\":\"11111111-2222-3333-4444-555555555555\"")),
                "RequestTrackingAuthorizationAsync must fire tracking_authorization_changed when status transitions");
        }

        [Test]
        public async Task RequestTrackingAuthorizationAsync_DoesNotFireAttStatusChanged_WhenStatusUnchanged()
        {
            AttStatusStore.Save(_testDir, 3); // already authorized
            ImmutableAudience.TrackingAuthorizationRequestProvider = () => Task.FromResult(3);
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);

            ImmutableAudience.FlushQueueToDiskForTesting();
            var queueDir = AudiencePaths.QueueDir(_testDir);
            foreach (var f in Directory.GetFiles(queueDir, "*.json")) File.Delete(f);

            await ImmutableAudience.RequestTrackingAuthorizationAsync();
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(b => b.Contains("\"tracking_authorization_changed\"")),
                "no event when ATT status has not changed");
        }

        [Test]
        public void AttStatusChanged_StripsIdfa_WhenConsentAnonymous()
        {
            // Transition to authorized at Anonymous: event fires (non-identifying state),
            // but idfa is Full-only and must not appear.
            AttStatusStore.Save(_testDir, 2); // denied -> authorized
            ImmutableAudience.MobileATTStatusProvider = () => 3;
            ImmutableAudience.MobileIDFAProvider = () => "11111111-2222-3333-4444-555555555555";
            var config = MakeConfig(ConsentLevel.Anonymous);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            var changeEvent = blobs.FirstOrDefault(b => b.Contains("\"tracking_authorization_changed\""));
            Assert.IsNotNull(changeEvent, "event must fire at Anonymous consent");
            Assert.IsFalse(changeEvent!.Contains("\"idfa\""),
                "idfa must not ship at Anonymous: it is a cross-app device identifier");
        }

        [Test]
        public void AttStatusChanged_NotFired_WhenConsentNone()
        {
            AttStatusStore.Save(_testDir, 0);
            ImmutableAudience.MobileATTStatusProvider = () => 3;
            var config = MakeConfig(ConsentLevel.None);
            config.EnableMobileAttribution = true;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            var queueDir = AudiencePaths.QueueDir(_testDir);
            if (!Directory.Exists(queueDir)) return;
            var blobs = Directory.GetFiles(queueDir, "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(b => b.Contains("\"tracking_authorization_changed\"")),
                "tracking_authorization_changed must not fire when consent is None");
        }

        [Test]
        public void AttStatusChanged_NotFired_WhenEnableMobileAttributionFalse()
        {
            AttStatusStore.Save(_testDir, 0);
            var providerCallCount = 0;
            ImmutableAudience.MobileATTStatusProvider = () => { providerCallCount++; return 3; };
            var config = MakeConfig(ConsentLevel.Full);
            config.EnableMobileAttribution = false;
            ImmutableAudience.Init(config);
            ImmutableAudience.Shutdown();

            Assert.AreEqual(0, providerCallCount,
                "MobileATTStatusProvider must not be called when EnableMobileAttribution is false");
            var blobs = Directory.GetFiles(AudiencePaths.QueueDir(_testDir), "*.json")
                .Select(File.ReadAllText).ToList();
            Assert.IsFalse(blobs.Any(b => b.Contains("\"tracking_authorization_changed\"")));
        }
    }
}