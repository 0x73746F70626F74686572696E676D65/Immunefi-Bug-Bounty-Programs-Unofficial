#nullable enable

using System;
using System.Collections.Generic;
using System.Globalization;
using Immutable.Audience.Unity.Mobile;
using UnityEngine;

namespace Immutable.Audience.Unity
{
    internal static class DeviceCollector
    {
        internal static Dictionary<string, object> CollectContext()
        {
            // 256-char cap mirrors Web SDK's identifier truncation.
            var ctx = new Dictionary<string, object>
            {
                ["userAgent"] = Truncate(SystemInfo.operatingSystem, 256),
            };

            var timezone = SafeTimezone();
            if (timezone != null) ctx["timezone"] = Truncate(timezone, 256);

            var locale = LocaleString();
            if (locale != null) ctx["locale"] = Truncate(locale, 256);

            var screen = TryResolveScreenString();
            if (screen != null) ctx["screen"] = Truncate(screen, 256);

            return ctx;
        }

        private static string? TryResolveScreenString()
        {
            // Can throw before a window/graphics device exists this early in boot;
            // isolated so a failure here doesn't cost CollectContext()'s other fields.
            try
            {
                var resolution = Screen.currentResolution;
                int width = resolution.width;
                int height = resolution.height;

                if (width <= 0 || height <= 0)
                {
                    width = Screen.width;
                    height = Screen.height;
                }

                if (width <= 0 || height <= 0) return null;
                return $"{width}x{height}";
            }
            catch (Exception ex)
            {
                Log.Warn(AudienceLogs.ScreenResolutionReadFailed(ex));
                return null;
            }
        }

        internal static Dictionary<string, object> CollectGameLaunchProperties(
            RuntimePlatform? platformOverride = null,
            bool? isEditorOverride = null)
        {
            var platform = platformOverride ?? Application.platform;
            var isEditor = isEditorOverride ?? Application.isEditor;
            var props = new Dictionary<string, object>
            {
                ["platform"] = PlatformName(platform),
                ["is_editor"] = isEditor,
                ["version"] = Truncate(Application.version, 256),
                ["build_guid"] = Truncate(Application.buildGUID, 256),
                ["unity_version"] = Truncate(Application.unityVersion, 256),
                ["os_family"] = SystemInfo.operatingSystemFamily.ToString(),
                ["device_model"] = Truncate(SystemInfo.deviceModel, 256),
                ["gpu"] = Truncate(SystemInfo.graphicsDeviceName, 256),
                ["gpu_vendor"] = Truncate(SystemInfo.graphicsDeviceVendor, 256),
                ["cpu"] = Truncate(SystemInfo.processorType, 256),
                ["cpu_cores"] = SystemInfo.processorCount,
                ["ram_mb"] = SystemInfo.systemMemorySize,
            };

            // Screen.dpi can be 0 on some Linux WMs.
            var dpi = (int)Screen.dpi;
            if (dpi > 0) props["screen_dpi"] = dpi;

            if (platform == RuntimePlatform.Android)
                props["android_id"] = Truncate(SystemInfo.deviceUniqueIdentifier, 256);

            if (platform == RuntimePlatform.IPhonePlayer)
            {
                var idfv = IDFVBridge.GetIDFV();
                if (idfv != null) props["idfv"] = Truncate(idfv, 256);

                // iOS baseline is 163 DPI (1×); 326 → 2×, 401-460 → 3×.
                if (dpi > 0) props["screen_scale"] = (int)Math.Round(dpi / 163.0);
            }

            return props;
        }

        private static string? LocaleString()
        {
            var culture = CultureInfo.CurrentCulture;
            if (!string.IsNullOrEmpty(culture?.Name))
                return culture.Name;
            return null;
        }

        private static string? SafeTimezone()
        {
            try
            {
                return TimeZoneInfo.Local.Id;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static string PlatformName(RuntimePlatform platform) => platform switch
        {
            RuntimePlatform.WindowsPlayer or RuntimePlatform.WindowsEditor => "Windows",
            RuntimePlatform.OSXPlayer or RuntimePlatform.OSXEditor => "macOS",
            RuntimePlatform.LinuxPlayer or RuntimePlatform.LinuxEditor => "Linux",
            RuntimePlatform.IPhonePlayer => "iOS",
            RuntimePlatform.Android => "Android",
            _ => platform.ToString(),
        };

        private static string Truncate(string s, int max)
        {
            if (string.IsNullOrEmpty(s) || s.Length <= max) return s;
            // Step back one if the cut would split a surrogate pair. Leaving
            // a lone high-surrogate produces invalid UTF-16 on the wire.
            var cut = max;
            if (char.IsHighSurrogate(s[cut - 1])) cut--;
            return s.Substring(0, cut);
        }
    }
}
