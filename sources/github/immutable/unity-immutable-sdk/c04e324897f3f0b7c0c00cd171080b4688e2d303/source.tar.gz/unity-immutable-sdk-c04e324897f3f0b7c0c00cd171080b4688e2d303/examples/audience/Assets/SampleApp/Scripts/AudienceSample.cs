#nullable enable

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UIElements;

namespace Immutable.Audience.Samples.SampleApp
{
    // Audience SDK sample, UI Toolkit port of the web sample-app. Exercises
    // every public ImmutableAudience API plus an event log that mirrors SDK
    // debug output.
    //
    // Partial layout (single source of truth):
    //
    //   AudienceSample.cs        SDK calls, On* handlers, mirror state, SDK
    //                            callbacks, config builders. Reads UXML
    //                            state ONLY via UI's Capture*Form accessors.
    //                            Never touches a UXML field directly.
    //   AudienceSample.UI.cs     UXML fields, binding, rendering, log pane,
    //                            Refresh* methods, Capture*Form accessors.
    //                            No SDK calls, no mirror-state knowledge.
    //   AudienceSample.Events.cs Catalogue, typed-event factory, props
    //                            builder. Pure factory: no UXML, no SDK.
    public sealed partial class AudienceSample : MonoBehaviour
    {
        // ---- State ----

        private bool _initialised;
        private Action<string>? _priorSdkLogWriter;

        // Sample-side identity mirror. SDK owns UserId and CurrentIdentityType;
        // traits and aliases are tracked here for the Identity panel.
        private Dictionary<string, object>? _mirrorTraits;
        private readonly List<string> _mirrorAliases = new List<string>();

        // ---- Lifecycle ----

        // Logs CI build info (buildGuid, runId, cellId, jobId) to Player.log on player startup. CI-only.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void LogCiBuildInfo()
        {
            var runId  = Environment.GetEnvironmentVariable("AUDIENCE_TEST_RUN_ID")  ?? string.Empty;
            var cellId = Environment.GetEnvironmentVariable("AUDIENCE_TEST_CELL_ID") ?? string.Empty;
            var jobId  = Environment.GetEnvironmentVariable("AUDIENCE_TEST_JOB_ID")  ?? string.Empty;
            if (string.IsNullOrEmpty(runId) && string.IsNullOrEmpty(cellId)) return;
            UnityEngine.Debug.Log(
                $"[CI] buildGuid={Application.buildGUID} runId={runId} cellId={cellId} jobId={jobId}");
        }

        private void Awake()
        {
            // InitializeUi must precede the Log.Writer swap. _logView has
            // to be bound before any Log.Warn can land in RouteSdkLogToPane.
            InitializeUi();
            _priorSdkLogWriter = Immutable.Audience.Log.Writer;
            Immutable.Audience.Log.Writer = RouteSdkLogToPane;
        }

        private void OnDestroy()
        {
            Immutable.Audience.Log.Writer = _priorSdkLogWriter;
        }

        // ---- SDK action handlers: SDK lifecycle ----

        private void OnInit() => RunAndLog("INIT", () =>
        {
            var form = CaptureInitForm();
            var config = BuildAudienceConfig(form, OnSdkError);
            ImmutableAudience.Init(config);
            _initialised = true;
            OnSdkStateChanged();
            return Json.Serialize(BuildConfigEcho(config), 2);
        });

        private void OnShutdown() => RunAndLog("shutdown()", () =>
        {
            ImmutableAudience.Shutdown();
            _initialised = false;
            ResetIdentityMirror();
            OnSdkStateChanged();
            return "SDK stopped";
        });

        private void OnReset() => RunAndLog("reset()", () =>
        {
            ImmutableAudience.Reset();
            ResetIdentityMirror();
            OnSdkStateChanged();
            return "anonymous ID regenerated, queue cleared";
        });

        private async Task OnFlushAsync()
        {
            try { await ImmutableAudience.FlushAsync(); AppendLog("flush()", "queue flushed", LogLevel.Ok, LogSource.App); OnSdkStateChanged(); }
            catch (Exception ex) { AppendLog("flush()", ex.Message, LogLevel.Err, LogSource.App); }
        }

        private async Task OnRequestAttAsync()
        {
            AppendLog("requestTrackingAuthorizationAsync()", "ATT request dispatched", LogLevel.Info, LogSource.App);
            try
            {
                var status = await ImmutableAudience.RequestTrackingAuthorizationAsync();
                AppendLog("requestTrackingAuthorizationAsync()",
                    $"status: {status}", LogLevel.Ok, LogSource.App);
            }
            catch (Exception ex)
            {
                AppendLog("requestTrackingAuthorizationAsync()", ex.Message, LogLevel.Err, LogSource.App);
            }
        }

        // ---- SDK action handlers: telemetry ----

        // Prefers the typed overload for the four events with public C#
        // classes (Progression, Resource, Purchase, MilestoneReached); the
        // rest stay on the string overload. Typed validation errors are
        // expected for user input. Let them propagate through RunAndLog.
        private void OnSendCatalogueEvent(EventSpec spec, Dictionary<string, VisualElement> inputs) =>
            RunAndLog("track()", () =>
            {
                GuardConsentForTrack();
                var props = BuildPropsDictionary(spec, inputs);
                var typed = BuildTypedEvent(spec.Name, props);
                if (typed != null)
                {
                    ImmutableAudience.Track(typed);
                    return Json.Serialize(new Dictionary<string, object>
                    {
                        ["event"] = spec.Name,
                        ["overload"] = "typed",
                        ["properties"] = typed.ToProperties(),
                    }, 2);
                }

                ImmutableAudience.Track(spec.Name, props.Count > 0 ? props : null);
                return Json.Serialize(new Dictionary<string, object>
                {
                    ["event"] = spec.Name,
                    ["overload"] = "string",
                    ["properties"] = props,
                }, 2);
            });

        private void OnSendCustomEvent() => RunAndLog("track()", () =>
        {
            GuardConsentForTrack();
            var f = CaptureCustomEventForm();
            var props = string.IsNullOrEmpty(f.RawProps) ? null : JsonReader.DeserializeObject(f.RawProps);
            ImmutableAudience.Track(f.Name, props);
            var echo = new Dictionary<string, object> { ["event"] = f.Name };
            if (props != null) echo["properties"] = props;
            return Json.Serialize(echo, 2);
        });

        // ---- SDK action handlers: consent ----

        // None clears the anonymous ID and stops future collection; already-queued
        // events are kept. Dropping below Full clears UserId. Mirror is reset
        // whenever the new level can no longer identify.
        private void OnSetConsent(ConsentLevel level) => RunAndLog("setConsent()", () =>
        {
            var previous = ImmutableAudience.CurrentConsent;
            ImmutableAudience.SetConsent(level);
            if (!level.CanIdentify()) ResetIdentityMirror();
            var payload = new Dictionary<string, object>
            {
                ["from"] = previous.ToLowercaseString(),
                ["to"] = level.ToLowercaseString(),
            };
            var effects = new List<string>();
            if (previous == ConsentLevel.None && level != ConsentLevel.None) effects.Add("queue started, session created");
            if (level == ConsentLevel.None) effects.Add("tracking stopped, anonymous ID cleared (queued events kept)");
            if (!level.CanIdentify() && previous.CanIdentify()) effects.Add("userId cleared");
            if (effects.Count > 0) payload["effects"] = effects;
            OnSdkStateChanged();
            return Json.Serialize(payload, 2);
        });

        // ---- SDK action handlers: identity ----

        private void OnIdentify() => RunAndLog("identify()", () =>
        {
            var f = CaptureIdentifyForm();
            var traits = ParseTraits(f.RawTraits);
            ImmutableAudience.Identify(f.Id, ParseIdentityType(f.Type), traits);
            // Empty ids and malformed passport ids throw, caught by RunAndLog
            // before this line runs. The one silent no-op left is consent
            // below Full, which the UserId check below still catches.
            var accepted = string.Equals(ImmutableAudience.UserId, f.Id, StringComparison.Ordinal);
            if (accepted) _mirrorTraits = traits;
            OnSdkStateChanged();
            var payload = new Dictionary<string, object>
            {
                ["id"]           = f.Id,
                ["identityType"] = f.Type,
                ["accepted"]     = accepted,
            };
            if (traits != null) payload["traits"] = traits;
            return Json.Serialize(payload, 2);
        });

        private void OnIdentifyTraits() => RunAndLog("identify(traits)", () =>
        {
            var userId = ImmutableAudience.UserId;
            if (string.IsNullOrEmpty(userId)) throw new InvalidOperationException("no active identity; call Identify first");
            var traits = ParseTraits(CaptureTraitsUpdate());
            if (traits == null || traits.Count == 0) throw new InvalidOperationException("traits required");
            ImmutableAudience.Identify(userId, ImmutableAudience.CurrentIdentityType ?? IdentityType.Custom, traits);
            _mirrorTraits = traits;
            OnSdkStateChanged();
            return Json.Serialize(traits, 2);
        });

        private void OnAlias() => RunAndLog("alias()", () =>
        {
            var f = CaptureAliasForm();
            ImmutableAudience.Alias(f.FromId, ParseIdentityType(f.FromType), f.ToId, ParseIdentityType(f.ToType));
            // Empty/identical/malformed ids throw, caught by RunAndLog before this
            // line runs. Consent below Full still drops silently inside the SDK,
            // with no readable property here to detect it (unlike Identify's UserId).
            _mirrorAliases.Add($"{f.FromType}:{f.FromId} → {f.ToType}:{f.ToId}");
            OnSdkStateChanged();
            return Json.Serialize(new Dictionary<string, object>
            {
                ["from"]     = new Dictionary<string, object> { ["id"] = f.FromId, ["identityType"] = f.FromType },
                ["to"]       = new Dictionary<string, object> { ["id"] = f.ToId,   ["identityType"] = f.ToType },
                ["accepted"] = true,
            }, 2);
        });

        // ---- SDK callbacks (passed to SDK at Init time) ----

        // Fires from background flush threads; AppendLog marshals to main.
        // Body is JSON for parity with handler "Copy" output.
        // Mirrors to Debug.LogError so failures land in Player.log, not just the in-app pane.
        private void OnSdkError(AudienceError err)
        {
            var body = Json.Serialize(new Dictionary<string, object>
            {
                ["code"] = err.Code.ToString(),
                ["message"] = err.Message,
            }, 2);
            UnityEngine.Debug.LogError($"[Audience.OnError] {body}");
            AppendLog("onError", body, LogLevel.Err, LogSource.Sdk);
        }

        // SDK Log.Writer adapter. Mirrors to Debug.Log so SDK output reaches Player.log.
        private void RouteSdkLogToPane(string msg)
        {
            const string warnTag = "[ImmutableAudience] WARN:";
            const string prefix = "[ImmutableAudience]";
            string body = msg;
            var level = LogLevel.Debug;
            if (msg.StartsWith(warnTag, StringComparison.Ordinal))
            {
                level = LogLevel.Warn;
                body = msg.Substring(warnTag.Length).TrimStart();
                UnityEngine.Debug.LogWarning($"[Audience] {body}");
            }
            else if (msg.StartsWith(prefix, StringComparison.Ordinal))
            {
                body = msg.Substring(prefix.Length).TrimStart();
                UnityEngine.Debug.Log($"[Audience] {body}");
            }
            else
            {
                UnityEngine.Debug.Log($"[Audience] {body}");
            }

            if (body.StartsWith("flush ok", StringComparison.Ordinal))
            {
                AppendLog(body, null, LogLevel.Ok, LogSource.Sdk);
                return;
            }
            if (body.StartsWith("flush failed", StringComparison.Ordinal))
            {
                AppendLog(body, null, LogLevel.Err, LogSource.Sdk);
                return;
            }

            AppendLog("sdk", body, level, LogSource.Sdk);
        }

        // ---- Handler scaffolding ----

        private void RunAndLog(string label, Func<string> body)
        {
            try { AppendLog(label, body(), LogLevel.Ok, LogSource.App); }
            catch (Exception ex)
            {
                var source = ex is InvalidOperationException ? LogSource.App : LogSource.Sdk;
                AppendLog(label, ex.Message, LogLevel.Err, source);
            }
        }

        // Track silently drops when consent < Anonymous (CanTrack false, no
        // SDK log). Throw here so RunAndLog renders an App-tier error row
        // instead of a misleading Ok with a payload that was never queued.
        private static void GuardConsentForTrack()
        {
            var consent = ImmutableAudience.CurrentConsent;
            if (!consent.CanTrack())
                throw new InvalidOperationException(
                    $"track dropped: consent is {consent.ToLowercaseString()}; raise to anonymous or full to queue events");
        }

        // Refresh* are idempotent reads, so calling all four every time is
        // cheaper than tracking subsets per handler.
        private void OnSdkStateChanged()
        {
            RefreshInitState();
            RefreshConsentPills();
            RefreshIdentityPanel();
            RefreshStatusBar();
        }

        // ---- Config builders ----

        // Maps the captured Setup form to AudienceConfig. BaseUrl null → SDK
        // targets the production endpoint. The flushInterval clamp emits a warn
        // row when the user requests <1s.
        private AudienceConfig BuildAudienceConfig(InitForm form, Action<AudienceError> onError)
        {
            var config = new AudienceConfig
            {
                PublishableKey          = form.PublishableKey,
                BaseUrl                 = string.IsNullOrEmpty(form.BaseUrl) ? null : form.BaseUrl,
                Consent                 = form.Consent,
                Debug                   = form.Debug,
                TestMode                = form.TestMode,
                EnableMobileAttribution = form.EnableMobileAttribution,
                OnError                 = onError,
            };
            if (form.FlushIntervalMs is int flushMs && flushMs > 0)
            {
                if (flushMs < 1000)
                    AppendLog("INIT", $"flushInterval {flushMs}ms below 1s, clamped", LogLevel.Warn, LogSource.App);
                config.FlushIntervalSeconds = Math.Max(1, flushMs / 1000);
            }
            if (form.FlushSize is int flushSize && flushSize > 0)
                config.FlushSize = flushSize;
            return config;
        }

        // For the Init "Ok" row. Nullable fields omitted when unset;
        // publishableKey redacted.
        private static Dictionary<string, object> BuildConfigEcho(AudienceConfig config)
        {
            var echo = new Dictionary<string, object>
            {
                ["consent"]                  = config.Consent.ToString(),
                ["debug"]                    = config.Debug,
                ["testMode"]                 = config.TestMode,
                ["enableMobileAttribution"]  = config.EnableMobileAttribution,
                ["flushIntervalSeconds"]     = config.FlushIntervalSeconds,
                ["flushSize"]                = config.FlushSize,
                ["shutdownFlushTimeoutMs"]   = config.ShutdownFlushTimeoutMs,
            };
            if (!string.IsNullOrEmpty(config.PublishableKey))
                echo["publishableKey"] = RedactPublishableKey(config.PublishableKey);
            if (!string.IsNullOrEmpty(config.PersistentDataPath))
                echo["persistentDataPath"] = config.PersistentDataPath;
            return echo;
        }

        // Keeps the pk_imapik- prefix visible; masks the rest.
        // Caller must guard against null/empty; signature non-nullable so the
        // dictionary insertion in BuildInitConfigEcho doesn't trip CS8601.
        private static string RedactPublishableKey(string key)
        {
            const int PrefixChars = 16;
            const string Mask = "…****";
            return key.Length <= PrefixChars ? Mask : key.Substring(0, PrefixChars) + Mask;
        }

        // ---- Identity helpers ----

        private void ResetIdentityMirror()
        {
            _mirrorTraits = null;
            _mirrorAliases.Clear();
        }

        private static Dictionary<string, object>? ParseTraits(string? raw) =>
            string.IsNullOrWhiteSpace(raw) ? null : JsonReader.DeserializeObject(raw!);

        // Parses a wire-format identity string (e.g. "steam") back into the
        // IdentityType enum the SDK now requires. Falls back to Custom for
        // unknown or empty values.
        private static IdentityType ParseIdentityType(string? value) => (value ?? "").ToLowerInvariant() switch
        {
            "passport" => IdentityType.Passport,
            "steam"    => IdentityType.Steam,
            "epic"     => IdentityType.Epic,
            "google"   => IdentityType.Google,
            "apple"    => IdentityType.Apple,
            "discord"  => IdentityType.Discord,
            "email"    => IdentityType.Email,
            _          => IdentityType.Custom,
        };
    }
}
