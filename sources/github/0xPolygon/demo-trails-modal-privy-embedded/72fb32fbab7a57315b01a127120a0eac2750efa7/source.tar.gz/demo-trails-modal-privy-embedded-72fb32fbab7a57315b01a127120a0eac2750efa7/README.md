# Trails x Privy Embedded

This demo keeps Privy embedded-wallet auth in the app shell and delegates the Trails flow to the packaged `TrailsWidget`. The app now uses the widget in modal form and launches the Trails `fund` flow instead of maintaining custom Trails hooks and UI.

## Quickstart

```bash
npm install
cp .env.example .env.local
npm run dev
```

Local app runs on [http://localhost:4444](http://localhost:4444).

## Privy embedded wallet setup

Set these values in `.env.local`:

- `VITE_PRIVY_APP_ID`
- `VITE_PRIVY_CLIENT_ID`
- `VITE_TRAILS_API_KEY`

Optional:

- `VITE_DEFAULT_CHAIN_ID`
- `VITE_TRAILS_API_URL` (defaults to `https://trails-api.sequence.app`)

If keys are missing, the app still runs, shows setup notices, and leaves the widget unavailable until configuration is complete.

For Google login in Privy:

- Enable `Google` as a login method in your Privy app dashboard.
- Ensure your deployed origin and local dev origin (`http://localhost:4444`) are both allowed in Privy.
- Ensure your Google provider is fully configured in Privy (OAuth client setup complete).

## Dev-test loop

```bash
npm run dev
npm run test:worker
npm run test:e2e
# or
npm run test:e2e:headed
```

Playwright screenshots are written to `test-results/`.

## Deploy

```bash
npm run build
wrangler deploy
```

Worker serves static assets from `dist/client` through the `ASSETS` binding.
