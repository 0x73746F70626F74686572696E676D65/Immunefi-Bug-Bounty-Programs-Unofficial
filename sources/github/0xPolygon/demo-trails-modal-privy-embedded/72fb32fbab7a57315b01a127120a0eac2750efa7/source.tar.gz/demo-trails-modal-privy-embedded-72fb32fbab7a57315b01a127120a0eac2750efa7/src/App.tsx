import { useEffect, useMemo, useRef, useState } from 'react';
import { usePrivy, useWallets } from '@privy-io/react-auth';
import { useSetActiveWallet } from '@privy-io/wagmi';
import { TrailsWidget, type TrailsWidgetRef } from '0xtrails/widget';
import { useAccount } from 'wagmi';

type AppProps = {
  walletEnabled: boolean;
  walletDisabledReason?: string;
};

type SetupNotice = {
  id: string;
  tone: 'error' | 'warn';
  title: string;
  detail: string;
};

type WidgetShellProps = {
  walletEnabled: boolean;
  walletDisabledReason?: string;
  authReady: boolean;
  authenticated: boolean;
  isConnected: boolean;
  address?: string;
  authActionLabel?: string;
  onAuthAction?: () => Promise<void> | void;
};

const trailsApiKey = import.meta.env.VITE_TRAILS_API_KEY?.trim() ?? '';
const trailsApiUrl = import.meta.env.VITE_TRAILS_API_URL?.trim() ?? 'https://trails-api.sequence.app';
const privyAppId = import.meta.env.VITE_PRIVY_APP_ID?.trim() ?? '';
const privyClientId = import.meta.env.VITE_PRIVY_CLIENT_ID?.trim() ?? '';
const rawDefaultChainId = import.meta.env.VITE_DEFAULT_CHAIN_ID?.trim() ?? '';

function truncateAddress(address: string) {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function getSetupNotices() {
  const notices: SetupNotice[] = [];

  if (!privyAppId) {
    notices.push({
      id: 'missing-privy-app-id',
      tone: 'error',
      title: 'Privy app ID is missing.',
      detail: 'Add VITE_PRIVY_APP_ID in your .env file.'
    });
  }

  if (!privyClientId) {
    notices.push({
      id: 'missing-privy-client-id',
      tone: 'error',
      title: 'Privy client ID is missing.',
      detail: 'Add VITE_PRIVY_CLIENT_ID in your .env file to complete setup.'
    });
  }

  if (!trailsApiKey) {
    notices.push({
      id: 'missing-trails-api-key',
      tone: 'error',
      title: 'Trails quote API key is missing.',
      detail: 'Add VITE_TRAILS_API_KEY in your .env file.'
    });
  }

  if (rawDefaultChainId) {
    const parsedChainId = Number(rawDefaultChainId);
    if (!Number.isInteger(parsedChainId) || parsedChainId <= 0) {
      notices.push({
        id: 'invalid-default-chain-id',
        tone: 'warn',
        title: 'Default network setting was not recognized.',
        detail: 'Use a positive integer for VITE_DEFAULT_CHAIN_ID.'
      });
    }
  }

  return notices;
}

function WalletEnabledApp() {
  const { address, isConnected } = useAccount();
  const { ready, authenticated, login, logout } = usePrivy();
  const { wallets } = useWallets();
  const { setActiveWallet } = useSetActiveWallet();

  useEffect(() => {
    if (!authenticated || wallets.length === 0) {
      return;
    }

    const embeddedWallet =
      wallets.find(
        (wallet) => wallet.walletClientType === 'privy' || wallet.walletClientType === 'privy-v2'
      ) ?? wallets[0];

    setActiveWallet(embeddedWallet).catch(() => undefined);
  }, [authenticated, setActiveWallet, wallets]);

  return (
    <WidgetShell
      walletEnabled
      authReady={ready}
      authenticated={authenticated}
      isConnected={isConnected}
      address={address}
      authActionLabel={authenticated ? 'Disconnect' : 'Connect with Privy'}
      onAuthAction={authenticated ? logout : login}
    />
  );
}

function WidgetShell({
  walletEnabled,
  walletDisabledReason,
  authReady,
  authenticated,
  isConnected,
  address,
  authActionLabel,
  onAuthAction
}: WidgetShellProps) {
  const [copyToast, setCopyToast] = useState<string | null>(null);
  const trailsWidgetRef = useRef<TrailsWidgetRef>(null);
  const setupNotices = useMemo(() => {
    const notices = getSetupNotices();

    if (!walletEnabled && walletDisabledReason) {
      notices.unshift({
        id: 'wallet-disabled-runtime',
        tone: 'error',
        title: 'Embedded wallet could not start.',
        detail: walletDisabledReason
      });
    }

    return notices;
  }, [walletDisabledReason, walletEnabled]);

  const isLoggedIn = Boolean(walletEnabled && authenticated && isConnected && address);
  const canRenderWidget = Boolean(isLoggedIn && trailsApiKey);
  const showHeaderActions = Boolean((isConnected && address) || walletEnabled);

  const copyWalletAddress = async () => {
    if (!address || typeof navigator === 'undefined' || !navigator.clipboard?.writeText) {
      return;
    }

    try {
      await navigator.clipboard.writeText(address);
      setCopyToast('Wallet address copied.');
      window.setTimeout(() => setCopyToast(null), 1800);
    } catch {
      setCopyToast('Copy failed.');
      window.setTimeout(() => setCopyToast(null), 1800);
    }
  };

  return (
    <div className="app-shell">
      <section className="surface">
        <header className="header-row">
          <div>
            <p className="eyebrow">Trails</p>
            <h1>Trails x Privy Embedded</h1>
            <p className="subtle">1-click cross-chain orchestration.</p>
          </div>
          {showHeaderActions ? (
            <div className="status-row" role="status" aria-live="polite">
              {isConnected && address ? (
                <button
                  type="button"
                  className="status-address"
                  onClick={() => {
                    void copyWalletAddress();
                  }}
                  title="Copy wallet address"
                  aria-label="Copy wallet address"
                >
                  {truncateAddress(address)}
                </button>
              ) : null}
              {walletEnabled && onAuthAction ? (
                <button
                  type="button"
                  className="status-action"
                  onClick={() => {
                    void onAuthAction();
                  }}
                  disabled={!authReady}
                >
                  {authReady ? authActionLabel : 'Loading'}
                </button>
              ) : null}
            </div>
          ) : null}
        </header>

        {setupNotices.length > 0 ? (
          <section className="notice-stack" aria-label="Setup notices">
            {setupNotices.map((notice) => (
              <article key={notice.id} className={`notice notice-${notice.tone}`} role="status">
                <p className="notice-title">{notice.title}</p>
                <p className="notice-detail">{notice.detail}</p>
              </article>
            ))}
          </section>
        ) : null}

        <section className="layout-grid layout-grid-initial">
          <article className="column column-primary">
            <div className="launch-flow">
              <div className="launch-actions">
                {walletEnabled && onAuthAction ? (
                  <button
                    type="button"
                    className={`cta launch-cta${isLoggedIn ? ' cta-subtle' : ''}`}
                    onClick={() => {
                      void onAuthAction();
                    }}
                    disabled={!authReady}
                  >
                    {authReady
                      ? isLoggedIn
                        ? 'Disconnect Privy'
                        : 'Connect with Privy'
                      : 'Loading...'}
                  </button>
                ) : null}

                {canRenderWidget ? (
                  <>
                    <button
                      type="button"
                      className="cta launch-cta"
                      onClick={() => {
                        trailsWidgetRef.current?.openModal();
                      }}
                    >
                      Fund with Trails
                    </button>
                    <div className="widget-controller" aria-hidden="true">
                      <TrailsWidget
                        ref={trailsWidgetRef}
                        apiKey={trailsApiKey}
                        trailsApiUrl={trailsApiUrl}
                        mode="fund"
                        theme="light"
                        hideDisconnect
                        toast
                        appName="Trails x Privy Embedded"
                        appDescription="Privy-authenticated Trails funding widget demo"
                      >
                        <span />
                      </TrailsWidget>
                    </div>
                  </>
                ) : (
                  <button type="button" className="cta launch-cta" disabled>
                    Fund with Trails
                  </button>
                )}
              </div>
            </div>
          </article>
        </section>

        {copyToast ? (
          <div className="app-toast" role="status" aria-live="polite">
            {copyToast}
          </div>
        ) : null}
      </section>
    </div>
  );
}

export default function App({ walletEnabled, walletDisabledReason }: AppProps) {
  if (walletEnabled) {
    return <WalletEnabledApp />;
  }

  return (
    <WidgetShell
      walletEnabled={false}
      walletDisabledReason={walletDisabledReason}
      authReady={false}
      authenticated={false}
      isConnected={false}
    />
  );
}
