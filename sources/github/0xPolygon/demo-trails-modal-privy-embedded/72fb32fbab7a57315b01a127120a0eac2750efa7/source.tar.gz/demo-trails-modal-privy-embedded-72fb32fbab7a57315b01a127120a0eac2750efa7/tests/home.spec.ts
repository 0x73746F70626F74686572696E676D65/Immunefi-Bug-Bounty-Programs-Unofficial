import { expect, test, type Page } from '@playwright/test';

async function expectAppHeading(page: Page) {
  await expect(page.getByRole('heading', { name: 'Trails x Privy Embedded' })).toBeVisible({
    timeout: 20_000
  });
}

function getHeaderConnectButton(page: Page) {
  return page.locator('.status-row').getByRole('button', { name: 'Connect with Privy' });
}

function getPrimaryConnectButton(page: Page) {
  return page.locator('.column-primary').getByRole('button', { name: 'Connect with Privy' });
}

function getPrimaryFundButton(page: Page) {
  return page.locator('.column-primary').getByRole('button', { name: 'Fund with Trails' });
}

test('renders the widget shell in the pre-connect state (desktop)', async ({ page }) => {
  await page.goto('/', { waitUntil: 'networkidle' });

  await expectAppHeading(page);
  await expect(page.getByText('1-click cross-chain orchestration.')).toBeVisible();
  await expect(page.getByText('Embedded wallet could not start.')).toHaveCount(0);
  await expect(page.getByText('Privy failed to initialize.')).toHaveCount(0);
  await expect(getHeaderConnectButton(page)).toBeVisible();
  await expect(getPrimaryConnectButton(page)).toBeVisible();
  await expect(getPrimaryFundButton(page)).toBeDisabled();

  await page.screenshot({ path: 'test-results/trails-widget-desktop.png', fullPage: true });
});

test('renders the widget shell cleanly on mobile', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/', { waitUntil: 'networkidle' });

  await expectAppHeading(page);
  await expect(page.getByText('1-click cross-chain orchestration.')).toBeVisible();
  await expect(getHeaderConnectButton(page)).toBeVisible();
  await expect(getPrimaryConnectButton(page)).toBeVisible();
  await expect(getPrimaryFundButton(page)).toBeDisabled();

  await page.screenshot({ path: 'test-results/trails-widget-mobile.png', fullPage: true });
});

test('opens Privy auth UI from Connect action', async ({ page }) => {
  await page.goto('/', { waitUntil: 'networkidle' });

  await expectAppHeading(page);
  await getPrimaryConnectButton(page).click();

  await expect
    .poll(async () => {
      const dialogCount = await page.locator('[role="dialog"], [aria-modal="true"]').count();
      const privyDomCount = await page
        .locator('[id*="privy"], [class*="privy"], [data-testid*="privy"]')
        .count();
      return dialogCount + privyDomCount;
    })
    .toBeGreaterThan(0);

  await page.screenshot({ path: 'test-results/privy-connect-modal.png', fullPage: true });
});
