# Plans

This directory tracks implementation plans for confirmed improvements. Status values are `PENDING`, `BACKLOG`, `COMPLETE`, `REVERTED`, `IN PROGRESS`, `IMPLEMENTED (measuring)`, and `BLOCKED`.

| Plan | Status | Topic |
| --- | --- | --- |
| 01 | COMPLETE | Issue 8: Debug Artifacts |
| 02 | COMPLETE | Issue 7: Token Telemetry |
| 03 | COMPLETE | Issue 2: Packet Context Degradation |
| 04 | COMPLETE | Issue 3: Planner Coverage Semantics |
| 05 | COMPLETE | Issue 4: Stage 7 Cost |
| 06 | COMPLETE | Issue 1: Budget And Partial Runs |
| 07 | COMPLETE | Issue 5: Verification Degradation |
| 08 | COMPLETE | Issue 6: Final Composition |
| 09 | COMPLETE | Issue 9: Human Attention Noise |
| 10 | COMPLETE | Issue 10: Final Body Metadata Duplication |
| 11 | COMPLETE | Issue 11: Stage 6 Inverted Range Reads |
| 12 | COMPLETE | Issue 12: Lossy Conversion Recall |
| 13 | COMPLETE | Issue 13: Planner and Anchor Hygiene |
| 14 | COMPLETE | Issue 14: Deleted Symbol Lookup and Targeted Tool Budget |
| 15 | COMPLETE | Issue 15: Telemetry Cache Terminology |
| 16 | COMPLETE | Issue 16: Eval Matching for Merged Findings |
| 17 | COMPLETE | Issue 17: Planner Submit Plan Schema Discipline |
| 18 | COMPLETE | Issue 18: Stage 6 Read Range Guard |
| 19 | COMPLETE | Issue 19: Follow-Up Hint Deduplication |
| 20 | COMPLETE | Issue 20: Pre-Verification Candidate Clustering |
| 21 | COMPLETE | Issue 21: Targeted Cross-System Review |
| 22 | COMPLETE | Issue 22: Cache Telemetry Clarity |
| 23 | COMPLETE | Issue 23: Evidence-Aware Verification Recall |
| 24 | COMPLETE | Issue 24: Uncertainty Promotion and Verifier Policy Discipline |
| 25 | COMPLETE | Issue 25: Repository Source Recovery and Tool Budget Diagnostics |
| 26 | COMPLETE | Issue 26: Budget Completion, Overrun Telemetry, and Budget Multiplier |
| 27 | COMPLETE | Issue 27: Eval LLM Concurrency Overrides |
| 28 | COMPLETE | Issue 28: Local Context Budget Pressure Reporting |
| 29 | COMPLETE | Issue 29: Adaptive Local Source Budget Extensions |
| 30 | COMPLETE | Issue 30: Post-Verification Human-Attention Reconciliation |
| 31 | COMPLETE | Issue 31: Intent-Aware Behavior-Change Framing |
| 32 | COMPLETE | Issue 32: Adaptive Stage 6 Symbol Context |
| 33 | COMPLETE | Issue 33: Stage 7 Compact Finalize for No-Finding Packet Reviews |
| 34 | COMPLETE | Issue 34: Run-Level Tool Result Memoization |
| 35 | COMPLETE | Issue 35: Telemetry and Cache Diagnostics |
| 36 | COMPLETE | Issue 36: Human-Attention and Uncertainty Hygiene |
| 37 | COMPLETE | Issue 37: Verifier Forced-Submit Schema Repair Hardening |
| 38 | COMPLETE | Issue 38: Eval and Runtime Concurrency Tuning |
| 39 | COMPLETE | Issue 39: Shared Prompt-Prefix Cache Spike |
| 40 | COMPLETE | Issue 40: Stage 7 Closeout Recall Regression |
| 41 | COMPLETE | Issue 41: Eval Scoring and Composition Provenance Under-Credit |
| 42 | COMPLETE | Issue 42: Stage 6 Adaptive Context Underdelivery |
| 43 | COMPLETE | Issue 43: Stage 7 Compact Removal and Generic Test-Rewrite Recall |
| 44 | COMPLETE | Issue 44: Stage 7 Recall Recalibration (Generate Liberally, Verify Strictly) |
| 45 | COMPLETE | Issue 45: Provider Overload Retry and Composer Fallback |
| 46 | COMPLETE | Issue 46: Codegenie Runtime Provenance in Eval and Telemetry |
| 47 | COMPLETE | Issue 47: Run 10 Verification, Composition, and Submit Robustness |
| 48 | COMPLETE | Issue 48: Prioritize Local Behavior-Delta Uncertainty Promotions |
| 49 | COMPLETE | Issue 49: Stage 5 Planner Dossier Efficiency |
| 50 | COMPLETE | Issue 50: Narrow `find_likely_tests` Tool Surface |
| 51 | COMPLETE | Issue 51: Stage 10 Composer Schema Repair and Salvage |
| 52 | COMPLETE | Issue 52: Stage 7 Candidate Schema Repair Cost |
| 53 | COMPLETE | Issue 53: Human-Attention Note Deduplication |
| 54 | COMPLETE | Issue 54: Recovered Schema Telemetry |
| 55 | PENDING | Issue 55: Treat Documentation Hunks as Intent Context |
| 56 | COMPLETE | Issue 56: Open Review Questions and Answer Tracking |
| 57 | COMPLETE | Issue 57: Resolve Call-Site Context Hints To Callers |
| 58 | COMPLETE | Issue 58: Planner Context Hint Contract |
| 59 | COMPLETE | Issue 59: Stage 5 Planner Schema Repair Salvage |
| 60 | COMPLETE | Issue 60: Preserve Planner Concerns As Review Obligations |
| 61 | COMPLETE | Issue 61: Stage 8 Task Deduplication and Question-Finding Title Hygiene |
| 62 | COMPLETE | Issue 62: Stage 7 Schema Friction Reduction |
| 63 | COMPLETE | Issue 63: Review Question Ownership and Risk-Area Coverage |
| 64 | COMPLETE | Issue 64: Material Review Question Answer Quality and Ambiguous Ownership Follow-Up |
| 65 | COMPLETE | Issue 65: End-to-End Obligation Proof For Review Questions |
| 66 | COMPLETE | Issue 66: Simplify Stage 5-8 By Removing Planner Review Questions |
| 67 | COMPLETE | Issue 67: Planner Coverage Emphasis and Hunk Relationship Context |
| 68 | COMPLETE | Issue 68: Predicate-Preserving Promotion and Note Suppression |
| 69 | COMPLETE | Issue 69: Planner Recovery Safety and Context-Budget Coupling |
| 70 | COMPLETE | Issue 70: Merged-Anchor Inline Recovery |
| 71 | COMPLETE | Issue 71: Stage 5 First-Submit Regression Audit and Repair |
| 72 | COMPLETE | Issue 72: Relationship Attention Note Preservation |
| 73 | COMPLETE | Issue 73: Caller-Visible Guarantee Invariant and Verifier Framing |
| 74 | PENDING | Issue 74: Merged Finding Confidence Calibration |
| 75 | PENDING | Issue 75: Human-Attention Output Discipline |
| 76 | COMPLETE (phase 1) | Issue 76: Low-Confidence Anchorless True-Positive Suppression at the Verification Pre-Gate (phase 2 not shipped per stop condition) |
| 77 | REVERTED | Issue 77: Stage 6 Scoped Relationship Symbol Mention Lookups |
| 78 | COMPLETE | Issue 78: Stage-Grouped Telemetry Artifacts |
| 79 | COMPLETE | Issue 79: Eval Recall-Variance Harness and Relay Wrong-Chain Case |
| 80 | COMPLETE | Issue 80: Degrade-and-Disclose Failure Semantics for LLM Errors |
| 81 | IN PROGRESS | Issue 81: Minimal Predicate-Only Uncertainty Promotion (output-quality slice landed; deletions measurement-gated) |
| 82 | COMPLETE (mechanical) | Issue 82: BehaviorChange Severity Discipline |
| 83 | COMPLETE | Issue 83: Wording-Independent Finding Fingerprints and Compare Integrity |
| 84 | COMPLETE (dark) | Issue 84: Stage-7 Ensemble Review for Deep Packets (default off; measurement in progress) |
| 85 | COMPLETE | Issue 85: Finalize Grace for Per-Pass Worker Timeouts |
| 86 | IN PROGRESS | Issue 86: Provider Protocol Parity and Observability (steps 1-4 done; step 5 study pending) |
| 87 | COMPLETE | Issue 87: Verifier Pre-Clustering Restricted to Exact Duplicates |
| 88 | COMPLETE | Issue 88: Publisher Summary-Only Fallback Reachability and Posting Disclosure |
| 89 | IN PROGRESS | Issue 89: Deterministic Bug Sweep (phase A done; phase B Wave 4) |
| 90 | COMPLETE | Issue 90: Token-Denominated Primary Review Budget (maxBudgetTokens) |
| 91 | COMPLETE | Issue 91: pi-ai Models-API Migration (off /compat; A/B gate passed on run 0c4d5213/50) |
| 92 | IMPLEMENTED (measuring) | Issue 92: Planner Coverage Calibration and the Adaptive Second Pass |
| 93 | PENDING | Issue 93: Delete the Dead Ripgrep Fast Path (D9) |
| 94 | PENDING | Issue 94: One Shared Similarity/Util Module |
| 95 | COMPLETE | Issue 95: One Shared Submit/Salvage Layer + Prompt "Why" Ledger |
| 96 | PENDING | Issue 96: Fixed Stage-6 Symbol-Context Budget |
| 97 | IMPLEMENTED (dogfood pending) | Issue 97: GitHub Action Integration (comment-triggered PR review + live status comment) |
| 98 | COMPLETE | Issue 98: Language Support — Rust, Python, Solidity, JavaScript (tree-sitter adapters + bundled skills) |
| 99 | COMPLETE | Issue 99: Plan 98 Correctness Follow-Up — Unicode-Safe Tree-sitter Extraction and Likely-Test Compatibility |
| 100 | COMPLETE | Issue 100: Short Hunk IDs — Planner Coverage Survival and Dispatch Resilience |
| 101 | IN PROGRESS (paid semantic A/B pending) | Issue 101: Exact Skill Provenance and Evidence-Gated Bundled-Skill Revision |
| 102 | PENDING | Issue 102: Same-File Packet Packing |
| 104 | PENDING | Issue 104: Delegate Mode — Run the Harness Without a Provider API Key |
| 105 | PENDING | Issue 105: Competitive Benchmark — Measuring codegenie Against Other Review Harnesses |
| 106 | COMPLETE | Issue 106: Enforce Meaningful Verifier Revisions and Calibrate Confidence |
| 107 | COMPLETE | Issue 107: Carry Related Promotion Signals Without Changing Selection |
| 108 | COMPLETE | Issue 108: Add a Verifier Severity Rubric and Revision Telemetry |
| 109 | COMPLETE | Issue 109: Restore Summary-Only Publication for Verified Low-Confidence Deltas |
| 110 | COMPLETE | Issue 110: Make Note Fallback Publication-Aware and Score Rendered Notes |
| 111 | IMPLEMENTED (dogfood pending) | Issue 111: Fix Observed Structured-Submit Failures and Preserve Safe Diagnostics |
| 112 | IMPLEMENTED (measuring) | Issue 112: Enforce Final Structured-Submit Provenance from Pi Events |
| 113 | BACKLOG (measurement gate not met) | Issue 113: Measure Direct-Reject Note Contradictions Before Adding Suppression |
| 114 | COMPLETE | Issue 114: Re-execute Untrusted Structured Submits From Trusted Context |
| 115 | IMPLEMENTED (measuring) | [Issue 115: Lossless Submit Recovery, Planning Fidelity, and Faithful Composition](115-issue-115-lossless-submit-recovery-and-faithful-composition.md) |
| 116 | IMPLEMENTED (measuring) | [Issue 116: Local Submit Shape Cleanup](116-issue-116-local-submit-shape-cleanup.md) |
| 117 | IMPLEMENTED (measuring) | [Issue 117: Concise Reports and Contract-Aware Fix Verification](117-issue-117-concise-reports-and-contract-aware-fix-verification.md) |
| 118 | IMPLEMENTED (measuring) | [Issue 118: Report Synthesis and Recommendation Contracts](118-issue-118-report-synthesis-and-recommendation-contracts.md) |
| 119 | IMPLEMENTED (live comparison pending) | [Issue 119: Requirement-Preserving Recommendation Verification](119-issue-119-requirement-preserving-recommendation-verification.md) |
| 120 | IMPLEMENTED (live comparison pending) | [Issue 120: Verifier Completion and Faithful Fallback](120-issue-120-verifier-completion-and-faithful-fallback.md) |
| 121 | IMPLEMENTED (live comparison pending) | [Issue 121: Evidence-Backed Recommendations and Report Reconciliation](121-issue-121-evidence-backed-human-attention-reconciliation.md) |
| 122 | CORE IMPLEMENTED (live baseline pending; C2 deferred) | [Issue 122: Shared Evidence and Focused Review Follow-ups](122-issue-122-shared-evidence-and-focused-review-followups.md) |
| 123 | IMPLEMENTED (live comparisons pending) | [Issue 123: Reliable Search Evidence and Honest Review Outcomes](123-issue-123-search-evidence-and-honest-review-outcomes.md) |
| 124 | IMPLEMENTED | [Issue 124: Repair Feedback, Evidence Retention, and Faithful Fallback Reports](124-issue-124-repair-feedback-evidence-retention-and-fallback-reports.md) |
| 125 | IMPLEMENTED (dogfood pending) | [Issue 125: GitHub Action Model Aliases and Provider Credential Docs](125-issue-125-github-model-aliases-and-provider-credentials.md) |

## Recommended order for 106-110

Land the terminal visibility chain first: **106 -> 109 -> 110**. Plans 107 and
108 are lower-risk supporting improvements; both follow 106 and may land after
the visibility chain. Plan 108 must rebase its Stage-9 prompt version onto the
landed 106 version.

## Recommended order for 111-112

Implement **111 first**: it contains the observed production/eval fixes and has
no Pi release dependency. Implement **112 second**: it consumes Pi's public
event stream inside Codegenie's existing adapter, strictly verifies final
arguments, and measures whether any broader lossless syntax repair or upstream
Pi change deserves a new plan. Its implementation gate uses generic event-shape
tests plus only the existing Anthropic/OpenAI Responses smokes; do not create an
every-provider fixture matrix without evidence. After that gate, move its row
to `IMPLEMENTED (measuring)`. The 2,500-submit corpus is post-land, not a reason
to hold the PR open; move the row to `COMPLETE` after the corpus and
human-reviewed outcome. Do not implement conditional parser work unless Plan
112's written evidence gate fires.

## Recommended disposition for 113

Do not hold 0.5.5 for Plan 113. Run 72 is the sole confirmed stale-note
incident; run 73 is a negative control in which the same candidate/note shape
was correctly reconciled by the existing evidence-backed path. The current
high-risk-reject tuple is also ambiguous with evidence-unavailable rejects, so
same-packet fuzzy suppression is not authorized. Reopen design only after the
plan's repeated-evidence or production-evidence gate fires; until then, leave
113 in BACKLOG and make no source changes.

## Recommended order for 114

Implement **114 before releasing 0.5.5**. Plans 111 and 112 remain its landed
dependencies: 111 owns stage-local terminal disposition and bounded Action
diagnostics; 112 owns strict final-argument provenance and the non-executable
untrusted-call representation. Plan 114 does not weaken either contract. It
corrects the continuation after an untrusted submit by retaining the trusted
pre-response conversation for the existing one retry. It also includes the
already-confirmed cache-aggregate and bounded Action identity fixes plus four
direct contract-test corrections; each is local and adds no new mechanism.
New telemetry fields, stage-specific test matrices, and Plan 113 remain
independent and must not be pulled into the 0.5.5 release.


## Recommended order for 115

Fix the reproduced Stage-7 hint/uncertainty deletion first, then preserve planner
coverage through repair, consolidate composition without losing distinct issues,
and add strict planning-quality/recovery-fidelity eval gates. Plan 115 was
implemented and regression-tested on 2026-09-22, with the controlled eval gate pending; its clarified
contracts cover protected-field comparison, obligations across worker restarts,
and conservative composition fallback. Preserve Plans
112/114 final-argument provenance and bounded retry contracts. Run 79 passing
its existing eval is not sufficient evidence of lossless recovery: it discarded
five unresolved items and used a degraded all-normal plan. Keep provider routing
and reasoning settings fixed while measuring this work.
