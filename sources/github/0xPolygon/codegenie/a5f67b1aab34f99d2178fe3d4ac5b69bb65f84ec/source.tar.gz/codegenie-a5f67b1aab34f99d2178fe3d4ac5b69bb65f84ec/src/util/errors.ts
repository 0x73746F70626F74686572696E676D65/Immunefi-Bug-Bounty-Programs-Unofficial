import { stripCredentials } from "../telemetry/redaction.js";

export type CodegenieErrorCode =
  | "not_git_worktree"
  | "invalid_args"
  | "config_error"
  | "gh_missing"
  | "gh_auth_failed"
  | "pr_not_found"
  | "git_ref_missing"
  | "git_base_branch_unresolved"
  | "git_fetch_failed"
  | "diff_parse_failed"
  | "parser_unavailable"
  | "skill_invalid"
  | "path_outside_repo"
  | "review_failed"
  | "llm_call_failed"
  | "llm_schema_invalid"
  | "github_post_failed"
  | "budget_exhausted"
  | "timeout";

export class CodegenieError extends Error {
  readonly code: CodegenieErrorCode;
  readonly recoverable: boolean;
  readonly context?: Record<string, unknown>;

  constructor(
    code: CodegenieErrorCode,
    message: string,
    opts: { recoverable?: boolean; context?: Record<string, unknown>; cause?: unknown } = {}
  ) {
    super(message, { cause: opts.cause });
    this.name = "CodegenieError";
    this.code = code;
    this.recoverable = opts.recoverable ?? false;
    if (opts.context) {
      this.context = stripCredentials(opts.context);
    }
  }

  toJSON(): {
    name: string;
    code: CodegenieErrorCode;
    message: string;
    recoverable: boolean;
    context?: Record<string, unknown>;
  } {
    const output = {
      name: this.name,
      code: this.code,
      message: this.message,
      recoverable: this.recoverable
    };
    return this.context ? { ...output, context: this.context } : output;
  }
}

export function isCodegenieError(error: unknown): error is CodegenieError {
  return error instanceof CodegenieError;
}

export function errorExitCode(error: unknown): number {
  if (!isCodegenieError(error)) {
    return 1;
  }

  switch (error.code) {
    case "invalid_args":
    case "config_error":
    case "not_git_worktree":
    case "git_ref_missing":
    case "git_base_branch_unresolved":
    case "diff_parse_failed":
      return 2;
    default:
      return 1;
  }
}

// Shared diagnostic-message truncation for prompts and telemetry payloads
// (moved from pi-runner per plan 95; the stage-7 recovery seam needs the
// identical cap so event payloads stay byte-compatible).
export function truncateDiagnostic(input: string): string {
  const maxChars = 2_000;
  if (input.length <= maxChars) {
    return input;
  }
  return `${input.slice(0, maxChars).trimEnd()}\n[validation error truncated by codegenie]`;
}
