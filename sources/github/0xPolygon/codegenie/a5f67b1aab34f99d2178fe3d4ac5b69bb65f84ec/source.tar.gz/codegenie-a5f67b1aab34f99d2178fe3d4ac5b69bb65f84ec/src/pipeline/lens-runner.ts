import { reviewDiagnostic, unresolvedToolDiagnostic } from "../util/review-health.js";
import { clarifyFindingLocations } from "./finding-location.js";
import { SCHEMA_REPAIR_TIMEOUT_MS } from "../util/budget.js";
import { buildRepositoryToolDefinitions } from "../llm/tool-definitions.js";
import type { LlmPostToolNudgeInput, LlmRunner, LlmToolResultSummary } from "../llm/llm-runner.js";
import { SubmitPacketReviewSchema, type SubmitPacketReview } from "../llm/schemas.js";
import { skillsCompatibleWithLanguage, type LensRegistry } from "../skills/lens-registry.js";
import { projectedSkillIds, type PromptBuilder } from "../skills/prompt-builder.js";
import type { TelemetryRecorder } from "../telemetry/telemetry-recorder.js";
import type {
  AdaptiveReviewOutcome,
  AnchorSource,
  CandidateFinding,
  CodegenieConfig,
  DiffAnchor,
  PacketReviewResult,
  RepositoryTools,
  RepositoryEvidence,
  ReviewPacket,
  ReviewPlan,
  ReviewPriority,
  ReviewDepth,
  ReviewStage,
  UnifiedDiff
} from "../types.js";
import { createWorkerRunner, type WorkerTask } from "./worker-runner.js";
import { isExactDuplicateCandidate } from "./verifier.js";
import { inferAnchorFromChangedCode, isBudgetExhaustedError, isRunFatalLlmError, isRecoverableWorkerError, isSchemaInvalidError, validateAnchorForDiff } from "./pipeline-utils.js";
import { isCodegenieError } from "../util/errors.js";
import { applySeverityPolicy } from "./severity-policy.js";
import { isAdaptiveNearMissSignal } from "./uncertainty-promotion.js";
import { MAX_DEEP_ENSEMBLE_PASSES } from "../config/schema.js";
import { isPacketReviewTestPath } from "../util/path-roles.js";
import { stage7RecoverInvalidSubmit } from "../llm/stage7-submit-repair.js";
import { cleanStrings } from "../util/text-similarity.js";
import { summarizeAdaptiveReviews } from "../util/adaptive-review.js";

type LensRunnerOptions = {
  runner: LlmRunner;
  promptBuilder: PromptBuilder;
  lensRegistry: LensRegistry;
  signal?: AbortSignal;
  checkpoint?: (stage: ReviewStage) => "ok" | "exhausted";
  diff?: UnifiedDiff;
};

type SubmittedFollowUpHint = SubmitPacketReview["followUpHints"][number];
type SubmittedUncertainty = SubmitPacketReview["uncertainties"][number];
type NormalizedHints = {
  kept: PacketReviewResult["followUpHints"];
  submittedCount: number;
  droppedCount: number;
};
type NormalizedUncertainties = {
  kept: PacketReviewResult["uncertainties"];
  submittedCount: number;
  droppedCount: number;
};
type Stage7PacketGeneration = {
  directCandidates: number;
  submittedFollowUpHints: number;
  keptFollowUpHints: number;
  droppedFollowUpHints: number;
  submittedUncertainties: number;
  keptUncertainties: number;
  droppedUncertainties: number;
};

const MAX_FOLLOW_UP_HINTS_PER_PACKET = 2;
const MAX_ADAPTIVE_PASSES_PER_RUN = 4;
// Ensemble guardrail (run 0c4d5213/52): the planner assigned 14 deep packets
// in one run (vs the usual 3-5); unbounded deep x K multiplies straight into
// the token budget. Ensemble the first N deep packets in input order; the
// rest run single-pass and are disclosed.
const MAX_ENSEMBLED_PACKETS_PER_RUN = 8;
const MAX_UNCERTAINTIES_PER_PACKET = 1;
const stage7Generation = new WeakMap<PacketReviewResult, Stage7PacketGeneration>();

export async function runLensPackets(
  _plan: ReviewPlan,
  packets: ReviewPacket[],
  tools: RepositoryTools,
  config: CodegenieConfig,
  telemetry: TelemetryRecorder,
  opts: LensRunnerOptions
): Promise<PacketReviewResult[]> {
  telemetry.event({ stage: 7, level: "info", message: "stage_started", data: { packets: packets.length } });
  const workerRunner = createWorkerRunner({
    telemetry,
    concurrency: config.review.concurrency,
    signal: opts.signal,
    isRetriableError: isRecoverableWorkerError,
    ...(opts.checkpoint !== undefined ? { checkpoint: opts.checkpoint } : {})
  });
  // Plan 84: deep-coverage packets run K independent Stage-7 passes whose
  // union feeds the existing verification gate. K=1 (the default) is the
  // legacy single-pass path, byte-for-byte.
  let ensembledPackets = 0;
  let ensembleCapSkipped = 0;
  const passPlan = packets.flatMap((packet) => {
    let passes = ensemblePassesForPacket(packet, config);
    if (passes > 1) {
      if (ensembledPackets >= MAX_ENSEMBLED_PACKETS_PER_RUN) {
        passes = 1;
        ensembleCapSkipped += 1;
      } else {
        ensembledPackets += 1;
      }
    }
    return Array.from({ length: passes }, (_unused, index) => ({ packet, pass: index + 1, passes }));
  });
  if (ensembleCapSkipped > 0) {
    telemetry.event({
      stage: 7,
      level: "warn",
      message: "stage7_ensemble_packet_cap",
      data: { cap: MAX_ENSEMBLED_PACKETS_PER_RUN, ensembledPackets, skipped: ensembleCapSkipped }
    });
  }
  const retainedReads = new Map<string, RepositoryEvidence[]>();
  const tasks = passPlan.map(({ packet, pass, passes }): WorkerTask<PacketReviewResult> => ({
    stage: 7,
    priority: packetPriority(packet),
    coverage: packet.coverage,
    dispatchRank: packet.dispatchRank,
    packetId: packet.id,
    ensemblePass: pass,
    timeoutMs: config.review.perPassTimeoutMs,
    repairAllowanceMs: SCHEMA_REPAIR_TIMEOUT_MS,
    awaitCancellation: true,
    retryOnTransient: true,
    run: packetAttemptRunner(packet, tools, config, opts, telemetry, retainedReads, pass, passes > 1 ? { pass, passes } : undefined)
  }));
  const outcomes = await workerRunner.schedule(tasks);
  const passResults = outcomes.map((outcome): PacketReviewResult => {
    if (outcome.outcome === "completed" && outcome.value) {
      return outcome.value;
    }
    if (isRunFatalLlmError(outcome.error) && !isSchemaInvalidError(outcome.error)) {
      throw outcome.error;
    }
    const packetId = outcome.task.packetId ?? "unknown";
    const budgetSkipped = isBudgetExhaustedError(outcome.error);
    telemetry.event({
      stage: 7,
      level: outcome.outcome === "not_dispatched" || budgetSkipped ? "warn" : "error",
      message: `packet_review_${budgetSkipped ? "not_dispatched" : outcome.outcome}`,
      packetId,
      workerId: outcome.task.workerId,
      data: {
        error: outcome.error instanceof Error ? outcome.error.message : String(outcome.error ?? ""),
        ...(isCodegenieError(outcome.error) ? { errorCode: outcome.error.code } : {})
      }
    });
    return {
      packetId,
      lenses: packets.find((packet) => packet.id === packetId)?.lenses ?? [],
      repositoryEvidence: retainedReads.get(`${packetId}/${outcome.task.ensemblePass ?? 1}`) ?? [],
      findings: [],
      followUpHints: [],
      uncertainties: [],
      diagnostics: [reviewDiagnostic(7, outcome.error, packetId, outcome.outcome)],
      status: outcome.outcome === "not_dispatched" || budgetSkipped ? "skipped" : "failed"
    };
  });
  // Group per-pass results by the OUTCOME's own packet/pass identity —
  // schedule() returns outcomes in dispatch order (priority/coverage
  // sorted), not input order, so positional grouping would scramble pools
  // across packets (found live in eval run 0c4d5213/49).
  const resultsByPacket = new Map<string, Array<{ pass: number; result: PacketReviewResult }>>();
  outcomes.forEach((outcome, index) => {
    const result = passResults[index];
    if (result === undefined) {
      return;
    }
    const packetId = outcome.task.packetId ?? result.packetId;
    const existing = resultsByPacket.get(packetId) ?? [];
    existing.push({ pass: outcome.task.ensemblePass ?? 1, result });
    resultsByPacket.set(packetId, existing);
  });
  let results = packets.map((packet) => {
    const passes = (resultsByPacket.get(packet.id) ?? [])
      .sort((a, b) => a.pass - b.pass)
      .map((entry) => entry.result);
    return poolEnsemblePassResults(packet, passes, telemetry);
  });
  results = await runAdaptiveSecondWave(results, packets, workerRunner, tools, config, telemetry, opts);
  const adaptiveReviews = summarizeAdaptiveReviews(results);
  await clarifyFindingLocations(results.flatMap((result) => result.findings), config, telemetry, { ...opts, packets });
  telemetry.event({
    stage: 7,
    level: "info",
    message: "pipeline_metrics",
    data: {
      totals: {
        packetReviews: results.length,
        candidates: results.reduce((sum, result) => sum + result.findings.length, 0)
      },
      workers: summarizeWorkerOutcomes(outcomes),
      packets: {
        reviewed: results.filter((result) => result.status === "completed").length,
        failed: results.filter((result) => result.status === "failed" || result.status === "incomplete").length
      },
      candidates: {
        generated: results.reduce((sum, result) => sum + result.findings.length, 0)
      },
      generation: summarizeStage7Generation(results),
      ...(adaptiveReviews ? { adaptiveReviews: adaptiveReviews.counts } : {})
    }
  });
  telemetry.event({ stage: 7, level: "info", message: "stage_completed", data: { packets: results.length } });
  return results;
}

export function ensemblePassesForPacket(packet: ReviewPacket, config: CodegenieConfig): number {
  if (packet.coverage !== "deep") {
    return 1;
  }
  // Config schemas already reject values above the cap; this clamp keeps
  // programmatically-built configs honest too.
  return Math.min(MAX_DEEP_ENSEMBLE_PASSES, Math.max(1, config.review.deepEnsemblePasses ?? 1));
}

type AdaptiveTrigger = NonNullable<AdaptiveReviewOutcome["trigger"]>;

// Plan 92 layer 3: a single-pass packet whose first pass shows near-miss
// evidence earns ONE additional independent review pass — a real second draw
// instead of a fabricated promotion candidate. Capped per run; triggered
// packets are chosen in trigger-priority order (T1 > T2 > T3) then input
// order. Off unless review.adaptiveSecondPass is set.
function adaptiveTriggerFor(packet: ReviewPacket, result: PacketReviewResult): AdaptiveTrigger | undefined {
  if (result.status !== "completed") {
    return undefined;
  }
  const signals = [
    ...result.followUpHints.map((hint) => ({ question: hint.question, files: hint.files, symbols: hint.symbols, reason: hint.reason })),
    ...result.uncertainties.map((uncertainty) => ({ question: uncertainty.question, files: uncertainty.files, symbols: uncertainty.symbols, reason: "packet reviewer reported an unresolved uncertainty" }))
  ];
  if (signals.some((signal) => isAdaptiveNearMissSignal(packet, signal))) {
    return "concrete_hint";
  }
  if (result.findings.length === 0) {
    const deletedTestSignal = packet.testCoverageDelta !== undefined && packet.testCoverageDelta.deletedTestSymbols.length > 0;
    const staticSignal = packet.hunks.some((hunk) => (hunk.staticSignals?.length ?? 0) > 0);
    if (deletedTestSignal || staticSignal) {
      return "silent_with_signal";
    }
    return undefined;
  }
  if (result.findings.every((finding) => finding.confidence === "low")) {
    return "low_confidence_only";
  }
  return undefined;
}

const ADAPTIVE_TRIGGER_RANK: Record<AdaptiveTrigger, number> = {
  concrete_hint: 0,
  silent_with_signal: 1,
  low_confidence_only: 2
};

async function runAdaptiveSecondWave(
  results: PacketReviewResult[],
  packets: ReviewPacket[],
  workerRunner: ReturnType<typeof createWorkerRunner>,
  tools: RepositoryTools,
  config: CodegenieConfig,
  telemetry: TelemetryRecorder,
  opts: LensRunnerOptions
): Promise<PacketReviewResult[]> {
  if (config.review.adaptiveSecondPass !== true) {
    return results;
  }
  for (const result of results) result.adaptiveReview = { outcome: "not_triggered", attempts: 0 };
  const packetsById = new Map(packets.map((packet) => [packet.id, packet]));
  const triggered = results.flatMap((result) => {
    const packet = packetsById.get(result.packetId);
    // Packets that already ran a planned ensemble had redundancy; adaptive
    // passes are for single-pass packets only.
    if (packet === undefined || (result.passesRun ?? 1) > 1) {
      return [];
    }
    const trigger = adaptiveTriggerFor(packet, result);
    return trigger === undefined ? [] : [{ packet, result, trigger }];
  });
  // Flat cap (run 0c4d5213/52): a deep-count-scaled cap compounded with a
  // planner deep-explosion (14 planner-deep packets) into 16 adaptive passes
  // and the first budget soft-stop breach of the wave era.
  const cap = MAX_ADAPTIVE_PASSES_PER_RUN;
  const ordered = [...triggered].sort((a, b) => ADAPTIVE_TRIGGER_RANK[a.trigger] - ADAPTIVE_TRIGGER_RANK[b.trigger]);
  const scheduled = ordered.slice(0, cap);
  const capped = ordered.length - scheduled.length;
  for (const entry of ordered.slice(cap)) entry.result.adaptiveReview = { trigger: entry.trigger, outcome: "capped", attempts: 0 };
  telemetry.event({
    stage: 7,
    level: scheduled.length > 0 ? "info" : "debug",
    message: "stage7_adaptive_summary",
    data: {
      triggered: triggered.length,
      scheduled: scheduled.length,
      capped,
      cap,
      triggers: scheduled.map((entry) => ({ packetId: entry.packet.id, trigger: entry.trigger }))
    }
  });
  if (scheduled.length === 0) {
    return results;
  }
  const retainedReads = new Map<string, RepositoryEvidence[]>();
  const tasks = scheduled.map(({ packet }): WorkerTask<PacketReviewResult> => ({
    stage: 7,
    priority: packetPriority(packet),
    coverage: packet.coverage,
    dispatchRank: packet.dispatchRank,
    packetId: packet.id,
    ensemblePass: 2,
    timeoutMs: config.review.perPassTimeoutMs,
    repairAllowanceMs: SCHEMA_REPAIR_TIMEOUT_MS,
    awaitCancellation: true,
    retryOnTransient: true,
    run: packetAttemptRunner(packet, tools, config, opts, telemetry, retainedReads, 2, { pass: 2, passes: 2, adaptive: true })
  }));
  const outcomes = await workerRunner.schedule(tasks);
  const adaptiveByPacket = new Map<string, PacketReviewResult>();
  const statusByPacket = new Map<string, AdaptiveReviewOutcome>();
  outcomes.forEach((outcome) => {
    const packetId = outcome.task.packetId ?? "unknown";
    const status: AdaptiveReviewOutcome = {
      outcome: outcome.outcome, attempts: outcome.attempts,
      ...(outcome.value ? { reviewStatus: outcome.value.status } : {}),
      ...(isCodegenieError(outcome.error) ? { errorCode: outcome.error.code,
        ...(outcome.error.code === "timeout" || outcome.error.context?.reason === "timeout" ? { failureReason: "timeout" as const } : {}) } : {})
    };
    statusByPacket.set(packetId, status);
    telemetry.event({ stage: 7, level: "info", message: "adaptive_pass_outcome", packetId, data: status });
    if (outcome.outcome === "completed" && outcome.value) {
      adaptiveByPacket.set(packetId, outcome.value);
      return;
    }
    if (isRunFatalLlmError(outcome.error) && isSchemaInvalidError(outcome.error) === false) {
      throw outcome.error;
    }
    telemetry.event({
      stage: 7,
      level: "warn",
      message: "adaptive_pass_failed",
      packetId,
      data: { outcome: outcome.outcome }
    });
  });
  const triggerByPacket = new Map(scheduled.map((entry) => [entry.packet.id, entry.trigger]));
  return results.map((result) => {
    const adaptive = adaptiveByPacket.get(result.packetId);
    const packet = packetsById.get(result.packetId);
    if (adaptive === undefined || packet === undefined) {
      result.repositoryEvidence = [...(result.repositoryEvidence ?? []), ...(retainedReads.get(`${result.packetId}/2`) ?? [])];
      const status = statusByPacket.get(result.packetId);
      const trigger = triggerByPacket.get(result.packetId);
      if (status) result.adaptiveReview = { ...status, ...(trigger ? { trigger } : {}) };
      return result;
    }
    telemetry.event({
      stage: 7,
      level: "info",
      message: "stage7_adaptive_pass",
      packetId: result.packetId,
      data: {
        trigger: triggerByPacket.get(result.packetId),
        produced: adaptive.findings.length,
        firstPassCandidates: result.findings.length
      }
    });
    const pooled = poolEnsemblePassResults(packet, [result, adaptive], telemetry, false);
    const trigger = triggerByPacket.get(result.packetId);
    pooled.adaptiveReview = { ...statusByPacket.get(result.packetId)!, ...(trigger ? { trigger } : {}) };
    return pooled;
  });
}

// Plan 84: merge K independent passes of one packet into a single
// PacketReviewResult. Candidates union under the verifier's exact-duplicate
// identity (near-duplicates that differ in wording stay separate — that is
// the verifier's job to absorb); hints/uncertainties dedupe by normalized
// question under the existing per-packet caps.
function poolEnsemblePassResults(
  packet: ReviewPacket,
  passResults: PacketReviewResult[],
  telemetry: TelemetryRecorder,
  emitEvent = true
): PacketReviewResult {
  const first = passResults[0];
  if (first === undefined) {
    return { packetId: packet.id, lenses: packet.lenses, findings: [], followUpHints: [], uncertainties: [], status: "failed" };
  }
  if (passResults.length === 1) {
    // Mutate rather than clone: stage7Generation stats are keyed on the
    // result object identity (WeakMap).
    first.passesRun = first.passesRun ?? 1;
    return first;
  }
  const usable = passResults.filter((result) => result.status === "completed" || result.status === "incomplete");
  const source = usable.length > 0 ? usable : [];
  const pooled: CandidateFinding[] = [];
  let duplicatesPooled = 0;
  for (const result of source) {
    for (const finding of result.findings) {
      if (pooled.some((existing) => isExactDuplicateCandidate(finding, existing))) {
        duplicatesPooled += 1;
        continue;
      }
      pooled.push(finding);
    }
  }
  const followUpHints = dedupeByQuestion(source.flatMap((result) => result.followUpHints)).slice(0, MAX_FOLLOW_UP_HINTS_PER_PACKET);
  const uncertainties = dedupeByQuestion(source.flatMap((result) => result.uncertainties)).slice(0, MAX_UNCERTAINTIES_PER_PACKET);
  const status: PacketReviewResult["status"] = usable.some((result) => result.status === "completed")
    ? "completed"
    : usable.length > 0
      ? "incomplete"
      : passResults.some((result) => result.status === "failed")
        ? "failed"
        : "skipped";
  const noFindingReason = source.map((result) => result.noFindingReason).find((reason) => reason !== undefined);
  const reviewStatus: PacketReviewResult["reviewStatus"] = pooled.length > 0
    ? "findings"
    : source.some((result) => result.reviewStatus === "no_findings")
      ? "no_findings"
      : source.some((result) => result.reviewStatus === "incomplete")
        ? "incomplete"
        : undefined;
  if (emitEvent) telemetry.event({
    stage: 7,
    level: "info",
    message: "stage7_ensemble",
    packetId: packet.id,
    data: {
      passes: passResults.length,
      completedPasses: passResults.filter((result) => result.status === "completed").length,
      candidatesPerPass: passResults.map((result) => result.findings.length),
      uniqueAfterDedupe: pooled.length,
      duplicatesPooled
    }
  });
  const merged: PacketReviewResult = {
    packetId: packet.id,
    lenses: packet.lenses,
    passesRun: passResults.reduce((sum, result) => sum + (result.passesRun ?? 1), 0),
    ...(!passResults.some(result => result.status === "completed" && !result.diagnostics?.length) ? { diagnostics: passResults.flatMap(result => result.diagnostics ?? []) } : {}),
    repositoryEvidence: passResults.flatMap(result => result.repositoryEvidence ?? []),
    findings: pooled,
    ...(reviewStatus !== undefined ? { reviewStatus } : {}),
    ...(noFindingReason !== undefined ? { noFindingReason } : {}),
    followUpHints,
    uncertainties,
    status
  };
  const generations = source.map((result) => stage7Generation.get(result)).filter((generation) => generation !== undefined);
  if (generations.length > 0) {
    stage7Generation.set(merged, {
      directCandidates: pooled.length,
      submittedFollowUpHints: generations.reduce((sum, generation) => sum + generation.submittedFollowUpHints, 0),
      keptFollowUpHints: followUpHints.length,
      droppedFollowUpHints: generations.reduce((sum, generation) => sum + generation.droppedFollowUpHints, 0),
      submittedUncertainties: generations.reduce((sum, generation) => sum + generation.submittedUncertainties, 0),
      keptUncertainties: uncertainties.length,
      droppedUncertainties: generations.reduce((sum, generation) => sum + generation.droppedUncertainties, 0)
    });
  }
  return merged;
}

function dedupeByQuestion<T extends { question: string }>(items: T[]): T[] {
  const seen = new Set<string>();
  const kept: T[] = [];
  for (const item of items) {
    const key = item.question.toLowerCase().replace(/\s+/gu, " ").trim();
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    kept.push(item);
  }
  return kept;
}

// One journal per logical pass, bounded by the worker's existing attempt and
// tool-delivery limits. Never feed prior findings into independent prompts.
function packetAttemptRunner(
  packet: ReviewPacket, tools: RepositoryTools, config: CodegenieConfig,
  opts: LensRunnerOptions, telemetry: TelemetryRecorder,
  retained: Map<string, RepositoryEvidence[]>, pass: number,
  ensemble?: { pass: number; passes: number; adaptive?: boolean }
): WorkerTask<PacketReviewResult>["run"] {
  const reads = new Map<string, RepositoryEvidence>();
  const observations = new Map<string, LlmToolResultSummary>();
  let attempt = 0;
  return async (signal, task) => {
    const currentAttempt = ++attempt;
    const collect = (results: LlmToolResultSummary[]) => {
      results.forEach((result, index) => {
        // Provider IDs are only local to a model response and may repeat even
        // within a worker attempt. Snapshot position is a host-owned identity.
        const id = `${task.workerId}/pass-${pass}/attempt-${currentAttempt}/read-${index}`;
        observations.set(id, structuredClone(result));
        for (const [hit, evidence] of (result.repositoryEvidence ?? []).entries()) {
          const readId = result.repositoryEvidence!.length === 1 ? id : `${id}/hit-${hit}`;
          const read = { ...structuredClone(evidence), id: readId,
            origin: { workerId: task.workerId, attempt: currentAttempt, pass, toolCallId: result.id } };
          reads.set(readId, read);
        }
      });
      retained.set(`${packet.id}/${pass}`, [...reads.values()]);
      return [...observations.values()];
    };
    const result = await runPacket(packet, tools, config, opts, telemetry, task.workerId, signal, ensemble, collect);
    result.repositoryEvidence = [...reads.values()];
    return result;
  };
}

async function runPacket(
  packet: ReviewPacket,
  tools: RepositoryTools,
  config: CodegenieConfig,
  opts: LensRunnerOptions,
  telemetry: TelemetryRecorder,
  workerId: string,
  signal: AbortSignal,
  ensemble?: { pass: number; passes: number; adaptive?: boolean },
  collect?: (results: LlmToolResultSummary[]) => LlmToolResultSummary[]
): Promise<PacketReviewResult> {
  const skills = skillsCompatibleWithLanguage(
    packet.lenses.flatMap((lensId) => opts.lensRegistry.skillsForLens(lensId)),
    packet.language
  );
  const prompt = opts.promptBuilder.buildPacketReviewPrompt({ packet, skills });
  const passSkillIds = projectedSkillIds(prompt.projection);
  const repositoryTools = packet.reviewProfile === "simple" || packet.toolBudget.maxToolCalls <= 0
    ? []
    : buildRepositoryToolDefinitions(tools, { includeLikelyTests: shouldExposeLikelyTestsForPacket(packet) });
  let toolResults: LlmToolResultSummary[] = [];
  const submitted = await opts.runner.runStructured<SubmitPacketReview>({
    onToolResults: results => { toolResults = collect?.(results) ?? results; },
    stage: 7,
    prompt: prompt.prompt,
    schema: SubmitPacketReviewSchema,
    signal,
    templateVersion: prompt.templateVersion,
    tools: repositoryTools,
    toolBudget: packet.toolBudget,
    timeoutMs: config.review.perPassTimeoutMs,
    telemetryContext: { workerId, packetId: packet.id },
    // Plan 95: stage 7's deterministic submit cleanup rides the shared
    // recoverInvalidSubmit seam like every other stage; the engine and its
    // telemetry live in stage7-submit-repair.ts.
    schemaRepair: {
      recoverInvalidSubmit: (input) => stage7RecoverInvalidSubmit(input, telemetry, { workerId, packetId: packet.id })
    },
    finalization: {
      noResultInstruction: STAGE7_NO_FINDINGS_SUBMIT_INSTRUCTION,
      buildPostToolNudge: (input) => buildPostToolCloseNudge(packet, config.review.depth, input)
    }
  });
  const findings = submitted.findings.map((finding, index) => stampFinding(packet, finding, index, passSkillIds, workerId, telemetry, opts.diff, ensemble));
  const reviewStatus = normalizedReviewStatus(submitted, findings.length);
  if (reviewStatus === "no_findings") {
    telemetry.event({
      stage: 7,
      level: "info",
      message: "packet_review_no_findings",
      packetId: packet.id,
      workerId,
      data: {
        reason: submitted.noFindingReason ?? "No concrete failure mode was submitted.",
        toolBudget: packet.toolBudget,
        coverage: packet.coverage,
        reviewProfile: packet.reviewProfile
      }
    });
  } else if (reviewStatus === "incomplete") {
    telemetry.event({
      stage: 7,
      level: "warn",
      message: "packet_review_incomplete",
      packetId: packet.id,
      workerId,
      data: {
        reason: submitted.noFindingReason
      }
    });
  }
  const followUpHints = normalizeFollowUpHints(submitted.followUpHints, packet, passSkillIds, telemetry, workerId);
  const uncertainties = normalizeUncertainties(submitted.uncertainties, packet, passSkillIds, telemetry, workerId);
  const diagnostic = reviewStatus === "incomplete" || followUpHints.kept.length > 0 || uncertainties.kept.length > 0
    ? unresolvedToolDiagnostic(7, toolResults, packet.id) : undefined;
  const result: PacketReviewResult = {
    repositoryEvidence: toolResults.flatMap(result => result.repositoryEvidence ?? []),
    ...(diagnostic ? { diagnostics: [diagnostic] } : {}),
    packetId: packet.id,
    lenses: packet.lenses,
    findings,
    reviewStatus,
    ...(submitted.noFindingReason !== undefined ? { noFindingReason: submitted.noFindingReason } : {}),
    followUpHints: followUpHints.kept,
    uncertainties: uncertainties.kept,
    status: reviewStatus === "incomplete" ? "incomplete" : "completed"
  };
  stage7Generation.set(result, {
    directCandidates: findings.length,
    submittedFollowUpHints: followUpHints.submittedCount,
    keptFollowUpHints: followUpHints.kept.length,
    droppedFollowUpHints: followUpHints.droppedCount,
    submittedUncertainties: uncertainties.submittedCount,
    keptUncertainties: uncertainties.kept.length,
    droppedUncertainties: uncertainties.droppedCount
  });
  return result;
}

function normalizeFollowUpHints(
  hints: SubmittedFollowUpHint[],
  packet: ReviewPacket,
  passSkillIds: readonly string[],
  telemetry: TelemetryRecorder,
  workerId: string
): NormalizedHints {
  const valid: PacketReviewResult["followUpHints"] = [];
  for (const hint of hints) {
    const normalized = {
      ...hint,
      question: hint.question.trim(),
      files: cleanStrings(hint.files),
      symbols: cleanStrings(hint.symbols),
      suggestedLenses: cleanStrings(hint.suggestedLenses),
      reason: hint.reason.trim(),
      projectedSkillIds: [...passSkillIds]
    };
    const pointerRich = normalized.files.length > 0 || normalized.symbols.length > 0;
    if (normalized.question.length === 0 || !pointerRich) {
      telemetry.event({
        stage: 7,
        level: "warn",
        message: normalized.question.length === 0 ? "vague_hint" : "follow_up_hint_dropped",
        packetId: packet.id,
        workerId,
        data: {
          question: normalized.question,
          files: normalized.files,
          symbols: normalized.symbols,
          reason: normalized.reason,
          confidence: normalized.confidence
        }
      });
      continue;
    }
    valid.push(normalized);
  }

  const ranked = [...valid].sort((a, b) => followUpHintRank(b, packet) - followUpHintRank(a, packet) ||
    a.question.localeCompare(b.question));
  const kept = ranked.slice(0, MAX_FOLLOW_UP_HINTS_PER_PACKET);
  const dropped = ranked.slice(MAX_FOLLOW_UP_HINTS_PER_PACKET);
  for (const hint of kept) {
    telemetry.event({
      stage: 7,
      level: "info",
      message: "follow_up_hint",
      packetId: packet.id,
      workerId,
      data: {
        question: hint.question,
        files: hint.files,
        symbols: hint.symbols,
        reason: hint.reason,
        confidence: hint.confidence,
        projectedSkillIds: hint.projectedSkillIds
      }
    });
  }
  if (dropped.length > 0) {
    telemetry.event({
      stage: 7,
      level: "info",
      message: "follow_up_hint_capped",
      packetId: packet.id,
      workerId,
      data: {
        cap: MAX_FOLLOW_UP_HINTS_PER_PACKET,
        keptCount: kept.length,
        droppedCount: dropped.length,
        dropped: dropped.slice(0, 5).map((hint) => ({
          question: hint.question,
          files: hint.files,
          symbols: hint.symbols,
          confidence: hint.confidence
        }))
      }
    });
  }
  return {
    kept,
    submittedCount: hints.length,
    droppedCount: hints.length - kept.length
  };
}

function normalizeUncertainties(
  uncertainties: SubmittedUncertainty[],
  packet: ReviewPacket,
  passSkillIds: readonly string[],
  telemetry: TelemetryRecorder,
  workerId: string
): NormalizedUncertainties {
  const valid = uncertainties.flatMap((uncertainty): PacketReviewResult["uncertainties"] => {
    const normalized = {
      question: uncertainty.question.trim(),
      files: cleanStrings(uncertainty.files),
      symbols: cleanStrings(uncertainty.symbols),
      projectedSkillIds: [...passSkillIds]
    };
    if (normalized.question.length === 0) {
      telemetry.event({
        stage: 7,
        level: "warn",
        message: "uncertainty_dropped",
        packetId: packet.id,
        workerId,
        data: { reason: "empty_question", uncertainty }
      });
      return [];
    }
    return [normalized];
  });
  const ranked = [...valid].sort((a, b) => uncertaintyRank(b, packet) - uncertaintyRank(a, packet) ||
    a.question.localeCompare(b.question));
  const kept = ranked.slice(0, MAX_UNCERTAINTIES_PER_PACKET);
  const dropped = ranked.slice(MAX_UNCERTAINTIES_PER_PACKET);
  for (const uncertainty of kept) {
    telemetry.event({
      stage: 7,
      level: "info",
      message: "uncertainty",
      packetId: packet.id,
      workerId,
      data: uncertainty
    });
  }
  if (dropped.length > 0) {
    telemetry.event({
      stage: 7,
      level: "info",
      message: "uncertainty_capped",
      packetId: packet.id,
      workerId,
      data: {
        cap: MAX_UNCERTAINTIES_PER_PACKET,
        keptCount: kept.length,
        droppedCount: dropped.length,
        dropped: dropped.slice(0, 5).map((uncertainty) => ({
          question: uncertainty.question,
          files: uncertainty.files,
          symbols: uncertainty.symbols
        }))
      }
    });
  }
  return {
    kept,
    submittedCount: uncertainties.length,
    droppedCount: uncertainties.length - kept.length
  };
}

function summarizeStage7Generation(results: PacketReviewResult[]): {
  directCandidates: number;
  packetsWithCandidates: number;
  noFindingsPackets: number;
  incompletePackets: number;
  submittedFollowUpHints: number;
  keptFollowUpHints: number;
  droppedFollowUpHints: number;
  submittedUncertainties: number;
  keptUncertainties: number;
  droppedUncertainties: number;
  submittedHintsAndUncertainties: number;
  keptHintsAndUncertainties: number;
} {
  const generations = results.map((result): Stage7PacketGeneration => stage7Generation.get(result) ?? {
    directCandidates: result.findings.length,
    submittedFollowUpHints: result.followUpHints.length,
    keptFollowUpHints: result.followUpHints.length,
    droppedFollowUpHints: 0,
    submittedUncertainties: result.uncertainties.length,
    keptUncertainties: result.uncertainties.length,
    droppedUncertainties: 0
  });
  const submittedFollowUpHints = generations.reduce((sum, item) => sum + item.submittedFollowUpHints, 0);
  const keptFollowUpHints = generations.reduce((sum, item) => sum + item.keptFollowUpHints, 0);
  const droppedFollowUpHints = generations.reduce((sum, item) => sum + item.droppedFollowUpHints, 0);
  const submittedUncertainties = generations.reduce((sum, item) => sum + item.submittedUncertainties, 0);
  const keptUncertainties = generations.reduce((sum, item) => sum + item.keptUncertainties, 0);
  const droppedUncertainties = generations.reduce((sum, item) => sum + item.droppedUncertainties, 0);
  return {
    directCandidates: generations.reduce((sum, item) => sum + item.directCandidates, 0),
    packetsWithCandidates: results.filter((result) => result.findings.length > 0).length,
    noFindingsPackets: results.filter((result) => result.reviewStatus === "no_findings").length,
    incompletePackets: results.filter((result) => result.reviewStatus === "incomplete" || result.status === "incomplete").length,
    submittedFollowUpHints,
    keptFollowUpHints,
    droppedFollowUpHints,
    submittedUncertainties,
    keptUncertainties,
    droppedUncertainties,
    submittedHintsAndUncertainties: submittedFollowUpHints + submittedUncertainties,
    keptHintsAndUncertainties: keptFollowUpHints + keptUncertainties
  };
}

function followUpHintRank(hint: PacketReviewResult["followUpHints"][number], packet: ReviewPacket): number {
  return confidenceScore(hint.confidence) * 30 +
    pointerScore(hint.files, hint.symbols, packet) * 10 +
    concretenessScore(hint.question, hint.reason);
}

function uncertaintyRank(uncertainty: PacketReviewResult["uncertainties"][number], packet: ReviewPacket): number {
  return pointerScore(uncertainty.files, uncertainty.symbols, packet) * 10 +
    concretenessScore(uncertainty.question, "");
}

function confidenceScore(confidence: PacketReviewResult["followUpHints"][number]["confidence"]): number {
  return { high: 3, medium: 2, low: 1 }[confidence];
}

function pointerScore(files: string[], symbols: string[], packet: ReviewPacket): number {
  const packetPaths = new Set([packet.path, ...(packet.oldPath !== undefined ? [packet.oldPath] : [])]);
  const changedFile = files.some((file) => packetPaths.has(stripLocationSuffix(file)));
  const symbolMatch = symbols.some((symbol) => packet.symbolFacts.some((fact) =>
    symbolMatches(symbol, fact.enclosingSymbol) || symbolMatches(symbol, fact.signature)
  ));
  return (files.length > 0 ? 1 : 0) +
    (symbols.length > 0 ? 1 : 0) +
    (changedFile ? 2 : 0) +
    (symbolMatch ? 2 : 0);
}

function concretenessScore(question: string, reason: string): number {
  const text = `${question} ${reason}`.toLowerCase();
  return (/\b(if|when|whether|because|fails?|breaks?|regression|contract|auth|permission|coverage|test|zero|nil|null|overflow|timeout|leak|race)\b/u.test(text) ? 2 : 0) +
    (question.length <= 180 ? 1 : 0);
}

function shouldExposeLikelyTestsForPacket(packet: ReviewPacket): boolean {
  return isPacketReviewTestPath(packet.path) ||
    (packet.oldPath !== undefined && isPacketReviewTestPath(packet.oldPath)) ||
    packet.lenses.some(isTestingLens) ||
    packet.testCoverageDelta !== undefined ||
    packet.labels.some(isTestingSignal) ||
    packet.attentionNotes.some(isTestingSignal);
}

function isTestingLens(lens: string): boolean {
  return /(^|[/_-])tests?($|[/_-])/iu.test(lens) || /(^|[/_-])testing($|[/_-])/iu.test(lens);
}

function isTestingSignal(value: string): boolean {
  return /\b(test|tests|testing|coverage)\b/iu.test(value);
}

function symbolMatches(symbol: string, factValue: string | undefined): boolean {
  if (!factValue) {
    return false;
  }
  const left = symbol.toLowerCase().trim();
  const right = factValue.toLowerCase();
  return left.length > 0 && (right === left || right.includes(left));
}

function stripLocationSuffix(value: string): string {
  return value.trim().replace(/:\d+(?:-\d+)?$/u, "");
}

function normalizedReviewStatus(submitted: SubmitPacketReview, findingCount: number): NonNullable<PacketReviewResult["reviewStatus"]> {
  if (submitted.reviewStatus === "incomplete") {
    return "incomplete";
  }
  if (findingCount > 0) {
    return "findings";
  }
  return "no_findings";
}

const STAGE7_NO_FINDINGS_SUBMIT_INSTRUCTION =
  "If there are no findings, submit reviewStatus:\"no_findings\", findings: [], and a short noFindingReason. If concrete unresolved risk remains but evidence is insufficient for a finding, include pointer-rich followUpHints or uncertainties.";

function buildPostToolCloseNudge(packet: ReviewPacket, depth: ReviewDepth, input: LlmPostToolNudgeInput): string | undefined {
  const threshold = closeNudgeThreshold(packet, depth);
  if (input.investigationRounds < threshold) {
    return undefined;
  }
  return `Only continue if the next repository tool call resolves one named predicate for packet ${packet.id}; prefer exact source reads such as read_symbol, read_range, find_definition, or read_diff_blocks. Otherwise call ${input.submitToolName} now with either a candidate finding, a short no-finding answer, or an exact unresolved predicate. ${STAGE7_NO_FINDINGS_SUBMIT_INSTRUCTION}`;
}

function closeNudgeThreshold(packet: ReviewPacket, depth: ReviewDepth): number {
  if (depth === "light" || packet.coverage === "light" || packet.reviewProfile === "simple") {
    return 1;
  }
  if (depth === "deep" || packet.coverage === "deep" || packet.reviewProfile === "investigate") {
    return 3;
  }
  return 2;
}

function stampFinding(
  packet: ReviewPacket,
  submitted: SubmitPacketReview["findings"][number],
  index: number,
  passSkillIds: readonly string[],
  workerId: string,
  telemetry: TelemetryRecorder,
  diff: UnifiedDiff | undefined,
  ensemble?: { pass: number; passes: number; adaptive?: boolean }
): CandidateFinding {
  const modelAnchor = normalizeAnchor(submitted.anchor, packet, diff);
  // Ensemble passes ≥2 carry a pass marker so candidate ids never collide
  // across passes; pass 1 keeps the legacy id shape (plan 84). Adaptive
  // second passes (plan 92) use an `a` marker so pass attribution can
  // distinguish planned redundancy from triggered redundancy.
  const passMarker = ensemble !== undefined && ensemble.pass > 1 ? `${ensemble.adaptive === true ? "a" : "e"}${ensemble.pass}` : "";
  const candidateId = `${packet.id.slice(0, 8)}-${passMarker}f${index + 1}`;
  if (submitted.anchor !== undefined && modelAnchor === undefined) {
    telemetry.event({
      stage: 7,
      level: "warn",
      message: "out_of_hunk_anchor",
      packetId: packet.id,
      data: { candidateId, finding: submitted.title, anchor: submitted.anchor }
    });
  }
  // Tier 1 anchor reconstruction (plan 76): when the model quoted changed
  // code but did not provide a usable structured anchor, a precise anchor is
  // often derivable from the quote itself.
  let anchor = modelAnchor;
  let anchorSource: AnchorSource | undefined = modelAnchor !== undefined ? "model" : undefined;
  if (anchor === undefined && submitted.evidence.changedCode.trim().length > 0) {
    const inferred = normalizeAnchor(inferAnchorFromChangedCode(diff ?? packet, submitted.evidence.changedCode), packet, diff);
    if (inferred !== undefined) {
      anchor = inferred;
      anchorSource = "backfill_changed_code";
      telemetry.event({
        stage: 7,
        level: "info",
        message: "anchor_inferred",
        packetId: packet.id,
        data: { candidateId, hunkId: inferred.hunkId, line: inferred.line, side: inferred.side }
      });
    } else {
      telemetry.event({
        stage: 7,
        level: "info",
        message: "anchor_inference_failed",
        packetId: packet.id,
        data: { candidateId }
      });
    }
  }
  if (submitted.anchor !== undefined && anchor === undefined) {
    telemetry.event({
      stage: 7,
      level: "info",
      message: "candidate_anchor_summary_only",
      packetId: packet.id,
      data: { candidateId, finding: submitted.title, anchor: submitted.anchor }
    });
  }
  const changedLine = anchor !== undefined;
  const path = anchor?.path ?? submitted.path ?? submitted.anchor?.path ?? packet.path;
  const primaryLens = packet.lenses[0] ?? "core/code-review";
  return {
    id: candidateId,
    title: submitted.title,
    ...applySeverityPolicy(submitted.severity, submitted.behaviorChange),
    confidence: submitted.confidence,
    path,
    ...(anchor !== undefined ? { anchor } : {}),
    ...(anchorSource !== undefined ? { anchorSource } : {}),
    modelAnchorSubmitted: submitted.anchor !== undefined,
    ...(anchor === undefined ? { locationResolution: { status: "unresolved" as const, ...(submitted.anchor ? { rejectedAnchor: submitted.anchor } : {}) } } : {}),
    changedLine,
    category: submitted.category,
    evidence: submitted.evidence,
    failureMode: submitted.failureMode,
    whyThisMatters: submitted.whyThisMatters,
    ...(submitted.suggestedFix !== undefined ? { suggestedFix: submitted.suggestedFix } : {}),
    ...(submitted.suggestedTest !== undefined ? { suggestedTest: submitted.suggestedTest } : {}),
    verification: submitted.verification,
    ...(submitted.behaviorChange !== undefined ? { behaviorChange: submitted.behaviorChange } : {}),
    ...(submitted.intentEvidence !== undefined ? { intentEvidence: submitted.intentEvidence } : {}),
    producedBy: {
      kind: "packet",
      stage: 7,
      packetId: packet.id,
      lensId: primaryLens,
      skillIds: [...passSkillIds],
      workerId,
      ...(ensemble !== undefined ? { ensemblePass: ensemble.pass } : {})
    }
  };
}

function normalizeAnchor(
  anchor: DiffAnchor | undefined,
  packet: ReviewPacket,
  diff: UnifiedDiff | undefined
): DiffAnchor | undefined {
  return validateAnchorForDiff(anchor, diff);
}

function packetPriority(packet: ReviewPacket): ReviewPriority {
  return packet.reviewPriority;
}

function summarizeWorkerOutcomes(outcomes: Array<{ outcome: string; attempts: number }>): {
  started: number;
  completed: number;
  failed: number;
  retried: number;
  timedOut: number;
} {
  return {
    started: outcomes.filter((outcome) => outcome.attempts > 0).length,
    completed: outcomes.filter((outcome) => outcome.outcome === "completed").length,
    failed: outcomes.filter((outcome) => outcome.outcome === "failed" || outcome.outcome === "cancelled" || outcome.outcome === "not_dispatched").length,
    retried: outcomes.filter((outcome) => outcome.attempts > 1).length,
    timedOut: outcomes.filter((outcome) => outcome.outcome === "timed_out").length
  };
}
