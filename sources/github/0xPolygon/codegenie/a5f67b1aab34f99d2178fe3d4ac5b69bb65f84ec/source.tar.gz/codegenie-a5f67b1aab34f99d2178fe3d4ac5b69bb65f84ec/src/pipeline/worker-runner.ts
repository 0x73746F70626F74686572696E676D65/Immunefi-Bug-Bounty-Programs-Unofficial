import type { TelemetryRecorder } from "../telemetry/telemetry-recorder.js";
import { isCodegenieError } from "../util/errors.js";
import pLimit from "p-limit";
import type { CoverageLevel, ReviewPriority, ReviewStage } from "../types.js";
import { finalizeGraceMs } from "../util/budget.js";

export type WorkerTask<T> = {
  workerId?: string;
  stage: ReviewStage;
  priority: ReviewPriority;
  coverage?: Exclude<CoverageLevel, "skip">;
  dispatchRank?: number[];
  packetId?: string;
  candidateId?: string;
  // Which ensemble pass this task represents (plan 84). Outcomes are
  // returned in DISPATCH order (sorted by priority/coverage), not input
  // order, so pass identity must ride on the task itself.
  ensemblePass?: number;
  timeoutMs: number;
  /** Additional hard-deadline allowance; does not extend investigation. */
  repairAllowanceMs?: number;
  /** Only for tasks whose implementation guarantees prompt abort settlement. */
  awaitCancellation?: boolean;
  retryOnTransient: boolean;
  run: (signal: AbortSignal, task: AssignedWorkerTask<T>) => Promise<T>;
};

export type AssignedWorkerTask<T> = WorkerTask<T> & { workerId: string };

export type WorkerOutcome<T> = {
  task: AssignedWorkerTask<T>;
  outcome: "completed" | "failed" | "cancelled" | "timed_out" | "not_dispatched";
  value?: T;
  error?: unknown;
  attempts: number;
};

export interface WorkerRunner {
  schedule<T>(tasks: Array<WorkerTask<T>>): Promise<Array<WorkerOutcome<T>>>;
  cancelAll(reason: string): void;
}

type WorkerRunnerOptions = {
  telemetry?: Pick<TelemetryRecorder, "event">;
  concurrency: number;
  checkpoint?: (stage: ReviewStage) => "ok" | "exhausted";
  signal?: AbortSignal | undefined;
  isRetriableError?: (error: unknown) => boolean;
};

const PRIORITY_ORDER: Record<ReviewPriority, number> = {
  critical: 0,
  high: 1,
  normal: 2,
  low: 3
};

const COVERAGE_ORDER: Record<Exclude<CoverageLevel, "skip">, number> = {
  deep: 0,
  normal: 1,
  light: 2
};

export function createWorkerRunner(opts: WorkerRunnerOptions): WorkerRunner {
  const root = new AbortController();
  const limit = pLimit(Math.max(1, opts.concurrency));
  if (opts.signal) {
    if (opts.signal.aborted) {
      root.abort(opts.signal.reason);
    } else {
      opts.signal.addEventListener("abort", () => root.abort(opts.signal?.reason), { once: true });
    }
  }

  return {
    schedule: async <T>(tasks: Array<WorkerTask<T>>): Promise<Array<WorkerOutcome<T>>> => {
      const ordered = tasks
        .map((task, index) => ({ task, index }))
        .sort((a, b) =>
          PRIORITY_ORDER[a.task.priority] - PRIORITY_ORDER[b.task.priority] ||
          coverageRank(a.task.coverage) - coverageRank(b.task.coverage) ||
          compareDispatchRanks(a.task.dispatchRank, b.task.dispatchRank) ||
          a.index - b.index
        )
        .map(({ task }, dispatchIndex) => ({ task: assignWorkerId(task, dispatchIndex + 1) }));
      let exhausted = false;
      const outcomes = await Promise.all(
        ordered.map(({ task }) =>
          limit(async (): Promise<WorkerOutcome<T>> => {
            if (root.signal.aborted) {
              return { task, outcome: "cancelled", error: root.signal.reason, attempts: 0 };
            }
            if (exhausted || opts.checkpoint?.(task.stage) === "exhausted") {
              exhausted = true;
              return { task, outcome: "not_dispatched", attempts: 0 };
            }
            return runTask(task, root.signal, opts.isRetriableError ?? (() => false), opts.checkpoint, opts.telemetry);
          })
        )
      );
      return outcomes;
    },
    cancelAll: (reason) => root.abort(new Error(reason))
  };
}

function assignWorkerId<T>(task: WorkerTask<T>, dispatchNumber: number): AssignedWorkerTask<T> {
  return {
    ...task,
    workerId: `w${String(task.stage)}-${String(dispatchNumber).padStart(3, "0")}`
  };
}

function coverageRank(coverage: Exclude<CoverageLevel, "skip"> | undefined): number {
  return coverage === undefined ? COVERAGE_ORDER.normal : COVERAGE_ORDER[coverage];
}

function compareDispatchRanks(a: number[] | undefined, b: number[] | undefined): number {
  if (a === undefined || b === undefined) {
    return 0;
  }
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    const difference = (a[index] ?? 0) - (b[index] ?? 0);
    if (difference !== 0) {
      return difference;
    }
  }
  return 0;
}

async function runTask<T>(
  task: AssignedWorkerTask<T>,
  rootSignal: AbortSignal,
  isRetriableError: (error: unknown) => boolean,
  checkpoint: ((stage: ReviewStage) => "ok" | "exhausted") | undefined,
  telemetry: WorkerRunnerOptions["telemetry"]
): Promise<WorkerOutcome<T>> {
  const maxAttempts = task.retryOnTransient ? 2 : 1;
  let lastOutcome: WorkerOutcome<T> | undefined;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    if (attempt > 1 && checkpoint?.(task.stage) === "exhausted") {
      telemetry?.event({ stage: task.stage, level: "info", message: "worker_retry_decision",
        data: { workerId: task.workerId, packetId: task.packetId, candidateId: task.candidateId,
          scope: "full_worker", attempt, maxAttempts, retry: false, reason: "budget_exhausted_before_retry" } });
      return { task, outcome: "not_dispatched", attempts: attempt - 1, error: lastOutcome?.error };
    }
    const outcome = await runTaskOnce(task, rootSignal, attempt);
    if (outcome.outcome === "completed") {
      if (attempt > 1) telemetry?.event({ stage: task.stage, level: "info", message: "worker_retry_recovered",
        data: { workerId: task.workerId, packetId: task.packetId, candidateId: task.candidateId, attempt, scope: "full_worker" } });
      return outcome;
    }
    lastOutcome = outcome;
    const error = isCodegenieError(outcome.error) ? outcome.error : undefined;
    const retry = task.retryOnTransient && outcome.outcome === "failed"
      && isRetriableError(outcome.error) && attempt < maxAttempts;
    const reason = outcome.outcome === "timed_out" || error?.context?.reason === "timeout"
      ? "pass_deadline_exhausted"
      : outcome.outcome === "cancelled" ? "cancelled"
      : !task.retryOnTransient ? "retry_disabled"
      : attempt >= maxAttempts ? "attempts_exhausted"
      : retry ? error?.code === "llm_schema_invalid" ? "restart_after_schema_failure" : "restart_after_transient_failure"
      : "non_retryable_failure";
    telemetry?.event({ stage: task.stage, level: "info", message: "worker_retry_decision",
      data: { workerId: task.workerId, packetId: task.packetId, candidateId: task.candidateId,
        scope: "full_worker", attempt, maxAttempts, retry, reason, outcome: outcome.outcome } });
    if (!retry) return outcome;
  }
  if (lastOutcome) {
    return lastOutcome;
  }
  return { task, outcome: "failed", attempts: 0 };
}

async function runTaskOnce<T>(task: AssignedWorkerTask<T>, rootSignal: AbortSignal, attempt: number): Promise<WorkerOutcome<T>> {
  const controller = new AbortController();
  const onAbort = (): void => controller.abort(rootSignal.reason);
  if (rootSignal.aborted) {
    return { task, outcome: "cancelled", error: rootSignal.reason, attempts: attempt - 1 };
  }
  rootSignal.addEventListener("abort", onAbort, { once: true });
  // Hard deadline: the pass's soft budget plus the finalize grace window. The
  // soft deadline itself is enforced cooperatively inside the LLM runner loop
  // (no new investigation calls after it); this timer is the backstop.
  const timeout = setTimeout(
    () => controller.abort(new Error("worker timed out")),
    task.timeoutMs + finalizeGraceMs(task.timeoutMs) + (task.repairAllowanceMs ?? 0)
  );
  const abortWaiter = abortPromise(controller.signal);

  const running = Promise.resolve().then(() => task.run(controller.signal, task));
  try {
    const value = await Promise.race([running, abortWaiter.promise]);
    return { task, outcome: "completed", value, attempts: attempt };
  } catch (error) {
    if (controller.signal.aborted) {
      // Drain cooperative cleanup/telemetry before the scheduler closes the
      // stage or reuses this worker slot.
      if (task.awaitCancellation) await running.catch(() => undefined);
      return {
        task,
        outcome: rootSignal.aborted ? "cancelled" : "timed_out",
        error,
        attempts: attempt
      };
    }
    return { task, outcome: "failed", error, attempts: attempt };
  } finally {
    abortWaiter.cleanup();
    clearTimeout(timeout);
    rootSignal.removeEventListener("abort", onAbort);
  }
}

function abortPromise(signal: AbortSignal): { promise: Promise<never>; cleanup: () => void } {
  let cleanup = (): void => undefined;
  const promise = new Promise<never>((_resolve, reject) => {
    const onAbort = (): void => reject(abortError(signal));
    cleanup = () => signal.removeEventListener("abort", onAbort);
    if (signal.aborted) {
      onAbort();
      return;
    }
    signal.addEventListener("abort", onAbort, { once: true });
  });
  return { promise, cleanup };
}

function abortError(signal: AbortSignal): Error {
  return signal.reason instanceof Error ? signal.reason : new Error("worker aborted");
}
