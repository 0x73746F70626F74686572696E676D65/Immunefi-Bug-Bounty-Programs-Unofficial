import { buildDiffAnchorIndex, parseDiff, validateDiffAnchor } from "../git/diff-parser.js";
import type { TelemetryRecorder } from "../telemetry/telemetry-recorder.js";
import type {
  CodegenieConfig,
  DiffAnchor,
  FinalFinding,
  GitHubClient,
  InlineCommentInput,
  ResolvedReviewInput,
  ReviewResult,
  RunPostingRecord,
  UnifiedDiff
} from "../types.js";
import { renderBudgetStopNotice, renderCoverageSummaryLines } from "../util/coverage-summary.js";
import { CodegenieError, isCodegenieError } from "../util/errors.js";
import { inlineCode, severityBadge } from "../util/markdown.js";
import { codegenieVersionInfo, workflowRunUrl } from "../util/version-info.js";
import { sanitizeGitHubCommentBody } from "./comment-sanitizer.js";
import { createGitHubClient } from "./github-client.js";
import { detectDuplicateFindings, formatCodegenieMarker, proseContentFingerprint } from "./duplicate-detector.js";
import { isProsePath } from "../util/path-roles.js";

type PublishOptions = {
  github?: GitHubClient;
  diff?: UnifiedDiff;
  provenance?: ReviewBodyProvenance;
};

type ReviewBodyProvenance = {
  version: string;
  commit?: string;
  runUrl?: string;
};

type PreparedInlineComment = {
  finding: FinalFinding;
  anchor: DiffAnchor;
  input: InlineCommentInput;
  deletedFileAnchor: boolean;
};

type RejectedCommentDescriptor = {
  path: string;
  line?: number;
  side?: "RIGHT" | "LEFT";
};

const INLINE_BODY_CAP = 10_000;
const REVIEW_BODY_CAP = 60_000;

export async function maybePublishToGitHub(
  finalReview: ReviewResult,
  resolved: ResolvedReviewInput,
  config: CodegenieConfig,
  telemetry: TelemetryRecorder,
  opts: PublishOptions = {}
): Promise<RunPostingRecord | undefined> {
  if (finalReview.postingPlan === undefined) {
    return undefined;
  }
  if (resolved.mode !== "github_pr" || resolved.pr === undefined) {
    throw new CodegenieError("invalid_args", "GitHub posting requires github_pr review mode");
  }

  const github = opts.github ?? createGitHubClient(resolved.repoRoot);
  const currentPr = await github.viewPr(resolved.pr.number, { refresh: true });
  if (currentPr.headSha !== resolved.pr.headSha || currentPr.baseSha !== resolved.pr.baseSha) {
    throw new CodegenieError(
      "github_post_failed",
      `PR #${resolved.pr.number} changed while review was running; re-run codegenie before posting comments`,
      {
        context: {
          resolvedBaseSha: resolved.pr.baseSha,
          resolvedHeadSha: resolved.pr.headSha,
          currentBaseSha: currentPr.baseSha,
          currentHeadSha: currentPr.headSha
        }
      }
    );
  }
  const diff = opts.diff ?? parseDiff(resolved.rawDiff);
  const index = buildDiffAnchorIndex(diff);
  const deletedAnchors = deletedFileAnchorKeys(diff);
  const byId = new Map(finalReview.findings.map((finding) => [finding.id, finding]));
  const demoted: FinalFinding[] = [];
  const inlineCandidates: Array<{ finding: FinalFinding; anchor: DiffAnchor }> = [];

  for (const planned of finalReview.postingPlan.inline) {
    const finding = byId.get(planned.findingId);
    if (finding === undefined || finding.publication !== "inline") {
      continue;
    }
    const anchor = finding.anchor ?? planned.anchor;
    if (belowInlineConfidence(finding.confidence, config.review.minInlineConfidence)) {
      demoted.push(finding);
      telemetry.event({
        stage: 11,
        level: "info",
        message: "github_inline_demoted",
        data: { findingId: finding.id, reason: "min-inline-confidence" }
      });
      continue;
    }
    const normalizedAnchor = collapseSingleLineAnchor(anchor);
    const validation = validateDiffAnchor(normalizedAnchor, index);
    if (!validation.valid) {
      demoted.push(finding);
      telemetry.event({
        stage: 11,
        level: "info",
        message: "github_inline_demoted",
        data: { findingId: finding.id, reason: validation.reason ?? "invalid-anchor" }
      });
      continue;
    }
    inlineCandidates.push({ finding, anchor: normalizedAnchor });
  }

  const comments = await github.listOwnComments(resolved.pr.number);
  const duplicateDecisions = detectDuplicateFindings(
    inlineCandidates.map(({ finding, anchor }) => ({ ...finding, anchor })), comments
  );
  const duplicateById = new Map(duplicateDecisions.map((decision) => [decision.findingId, decision]));
  const prepared = inlineCandidates
    .filter(({ finding }) => duplicateById.get(finding.id)?.action === "post")
    .map(({ finding, anchor }) => prepareInlineComment(finding, anchor, telemetry.runId, deletedAnchors.has(anchorKey(anchor))));
  const skippedDuplicates = duplicateDecisions.filter((decision) => decision.action !== "post").length;
  const reviewBody = buildPostingBody(finalReview, demoted, config, { includeInlineSummary: prepared.length > 0 });
  const shouldPostBody = reviewBody.trim().length > 0;

  const record: RunPostingRecord = {
    attempted: false,
    status: "failed",
    inlinePosted: 0,
    demotedToBody: demoted.length,
    skippedDuplicates,
    attempts: [],
    duplicateDecisions
  };

  if (prepared.length === 0 && !shouldPostBody) {
    record.status = skippedDuplicates > 0 ? "skipped_all_duplicates" : "skipped_no_findings";
    await persistPostingRecord(record, telemetry);
    return attachPosting(finalReview, record);
  }

  record.attempted = true;
  const provenance = resolveReviewBodyProvenance(opts);
  const finalize = (input: string): string => finalizeReviewBody(input, provenance);
  const body = finalize(reviewBody);
  try {
    const result = await postWithRecovery(github, resolved.pr.number, body, prepared, record, finalize);
    record.status = result.summaryOnly ? "summary_only_fallback" : "posted";
    record.inlinePosted = result.inlinePosted;
    await persistPostingRecord(record, telemetry);
    telemetry.event({
      stage: 11,
      level: "info",
      message: "github_review_posted",
      data: { status: record.status, inlinePosted: record.inlinePosted, demotedToBody: record.demotedToBody }
    });
    return attachPosting(finalReview, record);
  } catch (error) {
    record.status = "failed";
    record.error = error instanceof Error ? error.message : String(error);
    await persistPostingRecord(record, telemetry);
    telemetry.event({
      stage: 11,
      level: "error",
      message: "github_posting_failed",
      data: { error: record.error }
    });
    if (isCodegenieError(error)) {
      throw error;
    }
    throw new CodegenieError("github_post_failed", record.error, { cause: error });
  }
}

async function postWithRecovery(
  github: GitHubClient,
  prNumber: number,
  body: string,
  initialComments: PreparedInlineComment[],
  record: RunPostingRecord,
  finalize: (input: string) => string
): Promise<{ inlinePosted: number; summaryOnly: boolean }> {
  let comments = [...initialComments];
  let currentBody = body;
  let summaryOnly = false;

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const attemptingSummaryOnly = summaryOnly && comments.length === 0;
    try {
      await github.createReview(prNumber, {
        body: currentBody,
        event: "COMMENT",
        comments: comments.map((comment) => comment.input)
      });
      record.attempts.push({ commentCount: comments.length, outcome: attemptingSummaryOnly ? "fallback_summary_only" : "ok" });
      return { inlinePosted: comments.length, summaryOnly };
    } catch (error) {
      if (attemptingSummaryOnly) {
        recordFailedPostingAttempt(record, 0, error);
        throw error;
      }
      if (!isGithub422(error)) {
        record.attempts.push({ commentCount: comments.length, outcome: "error" });
        throw error;
      }
      record.attempts.push({ httpStatus: 422, commentCount: comments.length, outcome: "rejected" });
      const rejectedIndexes = extractRejectedCommentIndexes(error, comments);
      const before = comments.length;
      if (rejectedIndexes.length > 0) {
        const rejected = new Set(rejectedIndexes);
        const demoted = comments.filter((_comment, index) => rejected.has(index));
        currentBody = demoteCommentsIntoBody(currentBody, demoted, record, finalize);
        comments = comments.filter((_comment, index) => !rejected.has(index));
      } else {
        const localSuspects = nextLocal422SuspectClass(comments);
        if (localSuspects.length > 0) {
          const demoted = new Set(localSuspects);
          currentBody = demoteCommentsIntoBody(currentBody, localSuspects, record, finalize);
          comments = comments.filter((comment) => !demoted.has(comment));
        } else {
          currentBody = demoteCommentsIntoBody(currentBody, comments, record, finalize);
          comments = [];
          summaryOnly = true;
        }
      }
      if (comments.length === 0 && before > 0) {
        summaryOnly = true;
      }
      if (comments.length === before && !summaryOnly) {
        currentBody = demoteCommentsIntoBody(currentBody, comments, record, finalize);
        comments = [];
        summaryOnly = true;
      }
      if (attempt === 3) {
        currentBody = demoteCommentsIntoBody(currentBody, comments, record, finalize);
        comments = [];
        summaryOnly = true;
      }
    }
  }

  try {
    await github.createReview(prNumber, { body: currentBody, event: "COMMENT", comments: [] });
    record.attempts.push({ commentCount: 0, outcome: "fallback_summary_only" });
  } catch (error) {
    recordFailedPostingAttempt(record, 0, error);
    throw error;
  }
  return { inlinePosted: 0, summaryOnly: true };
}

function recordFailedPostingAttempt(record: RunPostingRecord, commentCount: number, error: unknown): void {
  const httpStatus = githubHttpStatus(error);
  record.attempts.push(httpStatus === undefined
    ? { commentCount, outcome: "error" }
    : { httpStatus, commentCount, outcome: "error" });
}

function nextLocal422SuspectClass(comments: PreparedInlineComment[]): PreparedInlineComment[] {
  const deletedFile = comments.filter((comment) => comment.deletedFileAnchor);
  if (deletedFile.length > 0) {
    return deletedFile;
  }
  const leftSide = comments.filter((comment) => comment.anchor.side === "LEFT");
  if (leftSide.length > 0) {
    return leftSide;
  }
  const multiline = comments.filter((comment) => comment.anchor.startLine !== undefined);
  if (multiline.length > 0) {
    return multiline;
  }
  return [];
}

function prepareInlineComment(
  finding: FinalFinding,
  anchor: DiffAnchor,
  runId: string,
  deletedFileAnchor: boolean
): PreparedInlineComment {
  const contentFingerprint = isProsePath(finding.path) ? proseContentFingerprint(finding.finalBody) : undefined;
  const marker = formatCodegenieMarker(finding.fingerprint, runId, contentFingerprint);
  const input: InlineCommentInput = {
    path: anchor.path,
    line: anchor.line,
    side: anchor.side,
    body: `${capBody(sanitizeGitHubCommentBody(finding.finalBody), INLINE_BODY_CAP)}\n\n${marker}`
  };
  if (anchor.startLine !== undefined && anchor.startLine !== anchor.line) {
    input.start_line = anchor.startLine;
    input.start_side = anchor.startSide ?? anchor.side;
  }
  return { finding, anchor, input, deletedFileAnchor };
}

function demoteCommentsIntoBody(
  body: string,
  comments: PreparedInlineComment[],
  record: RunPostingRecord,
  finalize: (input: string) => string
): string {
  if (comments.length === 0) {
    return body;
  }
  record.demotedToBody += comments.length;
  // Strip the footer before appending so demoted findings never land after
  // it; finalize re-appends the footer as the last line.
  return finalize(appendDemotedFindings(stripReviewBodyFooter(body), comments.map((comment) => comment.finding)));
}

function buildPostingBody(
  finalReview: ReviewResult,
  demoted: FinalFinding[],
  config: CodegenieConfig,
  opts: { includeInlineSummary: boolean }
): string {
  const hasBodyFindings = finalReview.summaryOnlyFindings.length > 0 || demoted.length > 0;
  const shouldIncludeBase = opts.includeInlineSummary ||
    hasBodyFindings ||
    finalReview.needsHumanAttention.length > 0 ||
    finalReview.coverage.partial ||
    config.github.summaryWhenNoFindings;
  if (!shouldIncludeBase) {
    return "";
  }
  const body = appendPostingCoverageDisclosure(finalReview.postingPlan?.reviewBody ?? finalReview.summary, finalReview.coverage);
  return appendDemotedFindings(body, demoted);
}

// Self-identifies the PR-review surface: which codegenie build produced it
// and, in Actions, which workflow run — the status comment carries the full
// stats, but the review body is what reviewers see inline. Applied as the
// LAST body transform (after demotions and capping) so the footer is always
// the final line: it strips any footer a prior pass appended, and the cap
// reserves room for it so truncation cannot drop it.
function finalizeReviewBody(body: string, provenance: ReviewBodyProvenance): string {
  const stripped = stripReviewBodyFooter(body);
  if (stripped.trim().length === 0) {
    return stripped.trim();
  }
  const footer = reviewBodyFooter(provenance);
  const capped = capBody(sanitizeGitHubCommentBody(stripped), REVIEW_BODY_CAP - footer.length - 2);
  return `${capped.trimEnd()}\n\n${footer}`;
}

function reviewBodyFooter(provenance: ReviewBodyProvenance): string {
  const build = `codegenie v${provenance.version}${provenance.commit !== undefined ? ` (${inlineCode(provenance.commit.slice(0, 10))})` : ""}`;
  return `— ${build}${provenance.runUrl !== undefined ? ` · [View Workflow Job](${provenance.runUrl})` : ""}`;
}

function stripReviewBodyFooter(body: string): string {
  return body.replace(/\n+— codegenie v[^\n]*$/u, "");
}

function resolveReviewBodyProvenance(opts: PublishOptions): ReviewBodyProvenance {
  if (opts.provenance !== undefined) {
    return opts.provenance;
  }
  const info = codegenieVersionInfo();
  const runUrl = workflowRunUrl();
  return { ...info, ...(runUrl !== undefined ? { runUrl } : {}) };
}

function appendPostingCoverageDisclosure(body: string, coverage: ReviewResult["coverage"]): string {
  if (!coverage.partial) {
    return body;
  }
  const sections: string[] = [];
  const budgetNotice = renderBudgetStopNotice(coverage);
  if (budgetNotice && !body.includes(budgetNotice)) {
    sections.push(budgetNotice);
  }
  if (!body.includes("Coverage disclosure:") && !body.includes("## Coverage")) {
    sections.push("## Coverage", "", ...renderCoverageSummaryLines(coverage));
  }
  if (sections.length === 0) {
    return body;
  }
  return body.trim().length > 0 ? [body.trim(), "", ...sections].join("\n") : sections.join("\n");
}

function appendDemotedFindings(body: string, findings: FinalFinding[]): string {
  if (findings.length === 0) {
    return body;
  }
  const lines = [body.trim(), "", "**Inline findings included in the review body:**"].filter((line) => line.length > 0);
  for (const finding of findings) {
    lines.push("", `- ${severityBadge(finding.severity)}: **${finding.title}** (${inlineCode(`${finding.path}${finding.anchor ? `:${finding.anchor.line}` : ""}`)})`);
    lines.push(indent(finding.finalBody.trim() || finding.failureMode));
  }
  return lines.join("\n");
}

function indent(text: string): string {
  return text.split(/\r?\n/u).map((line) => `  ${line}`).join("\n");
}

function collapseSingleLineAnchor(anchor: DiffAnchor): DiffAnchor {
  if (anchor.startLine !== undefined && anchor.startLine === anchor.line) {
    const { startLine: _startLine, startSide: _startSide, ...singleLine } = anchor;
    return singleLine;
  }
  return anchor;
}

function belowInlineConfidence(confidence: FinalFinding["confidence"], min: CodegenieConfig["review"]["minInlineConfidence"]): boolean {
  return confidenceRank(confidence) > confidenceRank(min);
}

function confidenceRank(confidence: FinalFinding["confidence"]): number {
  return confidence === "high" ? 0 : confidence === "medium" ? 1 : 2;
}

function capBody(body: string, maxChars: number): string {
  if (body.length <= maxChars) {
    return body;
  }
  const suffix = "\n\n... (truncated)";
  const limit = Math.max(0, maxChars - suffix.length);
  const prefix = body.slice(0, limit);
  const paragraphBreak = prefix.lastIndexOf("\n\n");
  return `${prefix.slice(0, paragraphBreak > maxChars * 0.5 ? paragraphBreak : limit).trimEnd()}${suffix}`;
}

function isGithub422(error: unknown): boolean {
  return githubHttpStatus(error) === 422;
}

function githubHttpStatus(error: unknown): number | undefined {
  if (!(error instanceof CodegenieError) || error.code !== "github_post_failed") {
    return undefined;
  }
  const status = error.context?.httpStatus;
  return typeof status === "number" && Number.isInteger(status) ? status : undefined;
}

function extractRejectedCommentIndexes(error: unknown, comments: PreparedInlineComment[]): number[] {
  if (!(error instanceof CodegenieError)) {
    return [];
  }
  const payload = parseGitHubErrorPayload(error);
  if (payload === undefined) {
    return [];
  }
  const explicit = collectIndexes(payload).filter((index) => index >= 0 && index < comments.length);
  const byDescriptor = collectRejectedCommentDescriptors(payload)
    .flatMap((descriptor) => indexesMatchingRejectedDescriptor(descriptor, comments));
  return [...new Set([...explicit, ...byDescriptor])].sort((a, b) => a - b);
}

function parseGitHubErrorPayload(error: CodegenieError): unknown | undefined {
  const responseBody = error.context?.responseBody;
  if (responseBody !== undefined) {
    if (typeof responseBody === "string") {
      return parseJsonPayload(responseBody);
    }
    return responseBody;
  }
  const raw = [error.context?.stdout, error.context?.stderr]
    .map((value) => typeof value === "string" ? value : "")
    .find((value) => value.includes("{"));
  if (raw === undefined) {
    return [];
  }
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end < start) {
    return [];
  }
  return parseJsonPayload(raw.slice(start, end + 1));
}

function parseJsonPayload(raw: string): unknown | undefined {
  try {
    return JSON.parse(raw);
  } catch {
    return undefined;
  }
}

function collectIndexes(value: unknown): number[] {
  if (Array.isArray(value)) {
    return [...new Set(value.flatMap((item) => collectIndexes(item)))].sort((a, b) => a - b);
  }
  if (!value || typeof value !== "object") {
    return [];
  }
  const record = value as Record<string, unknown>;
  const direct = [
    numberField(record.index),
    numberField(record.comment_index),
    numberField(record.commentIndex),
    indexFromField(record.field)
  ].filter((index): index is number => index !== undefined);
  return [...new Set([...direct, ...Object.values(record).flatMap((item) => collectIndexes(item))])].sort((a, b) => a - b);
}

function collectRejectedCommentDescriptors(value: unknown): RejectedCommentDescriptor[] {
  if (Array.isArray(value)) {
    return value.flatMap((item) => collectRejectedCommentDescriptors(item));
  }
  if (!value || typeof value !== "object") {
    return [];
  }
  const record = value as Record<string, unknown>;
  const path = stringField(record.path);
  const descriptor: RejectedCommentDescriptor[] = [];
  if (path !== undefined) {
    const next: RejectedCommentDescriptor = { path };
    const line = numberField(record.line);
    if (line !== undefined) {
      next.line = line;
    }
    const side = sideField(record.side);
    if (side !== undefined) {
      next.side = side;
    }
    descriptor.push(next);
  }
  return [...descriptor, ...Object.values(record).flatMap((item) => collectRejectedCommentDescriptors(item))];
}

function indexesMatchingRejectedDescriptor(
  descriptor: RejectedCommentDescriptor,
  comments: PreparedInlineComment[]
): number[] {
  const matches = comments
    .map((comment, index) => ({ comment, index }))
    .filter(({ comment }) => commentMatchesRejectedDescriptor(comment, descriptor));
  const pathOnly = descriptor.line === undefined && descriptor.side === undefined;
  if (pathOnly && matches.length !== 1) {
    return [];
  }
  return matches.map((match) => match.index);
}

function commentMatchesRejectedDescriptor(
  comment: PreparedInlineComment,
  descriptor: RejectedCommentDescriptor
): boolean {
  return comment.input.path === descriptor.path &&
    (descriptor.line === undefined || comment.input.line === descriptor.line) &&
    (descriptor.side === undefined || comment.input.side === descriptor.side);
}

function stringField(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function numberField(value: unknown): number | undefined {
  return typeof value === "number" && Number.isInteger(value) ? value : undefined;
}

function sideField(value: unknown): "RIGHT" | "LEFT" | undefined {
  if (typeof value !== "string") {
    return undefined;
  }
  const upper = value.toUpperCase();
  return upper === "RIGHT" || upper === "LEFT" ? upper : undefined;
}

function indexFromField(value: unknown): number | undefined {
  if (typeof value !== "string") {
    return undefined;
  }
  const match = /comments\[(\d+)\]/u.exec(value) ?? /comments\.(\d+)/u.exec(value);
  return match?.[1] !== undefined ? Number(match[1]) : undefined;
}

function deletedFileAnchorKeys(diff: UnifiedDiff): Set<string> {
  const keys = new Set<string>();
  for (const file of diff.files) {
    if (file.status !== "deleted") {
      continue;
    }
    const path = file.oldPath ?? file.path;
    for (const hunk of file.hunks) {
      for (const line of hunk.lines) {
        if (line.kind === "delete" && line.oldLineNumber !== undefined) {
          keys.add(anchorKey({ path, line: line.oldLineNumber, side: "LEFT", hunkId: hunk.id }));
        }
      }
    }
  }
  return keys;
}

function anchorKey(anchor: Pick<DiffAnchor, "path" | "line" | "side" | "hunkId">): string {
  return `${anchor.path}\0${anchor.side}\0${anchor.line}\0${anchor.hunkId}`;
}

async function persistPostingRecord(record: RunPostingRecord, telemetry: TelemetryRecorder): Promise<void> {
  await telemetry.writeArtifact("github-posting.json", record);
  telemetry.event({ stage: 11, level: "info", message: "github_posting_recorded", data: record });
}

function attachPosting(finalReview: ReviewResult, record: RunPostingRecord): RunPostingRecord {
  finalReview.posting = record;
  return record;
}
