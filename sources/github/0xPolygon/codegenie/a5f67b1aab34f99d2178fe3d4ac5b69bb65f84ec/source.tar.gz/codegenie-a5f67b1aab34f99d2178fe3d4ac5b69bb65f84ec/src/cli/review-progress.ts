import type { TelemetryEvent } from "../types.js";
import { STAGE_LABELS } from "../review-stages.js";

type ProgressEvent = Omit<TelemetryEvent, "runId" | "eventId" | "timestamp">;

type ProgressOptions = {
  enabled: boolean;
  env?: NodeJS.ProcessEnv;
  stream?: NodeJS.WriteStream;
};

export type ReviewProgress = {
  onTelemetryEvent(event: ProgressEvent): void;
  stop(): void;
};

const FRAMES = ["-", "\\", "|", "/"] as const;

export function createReviewProgress(options: ProgressOptions): ReviewProgress | undefined {
  const stream = options.stream ?? process.stderr;
  const env = options.env ?? process.env;
  if (!shouldShowProgress({ ...options, stream, env })) {
    return undefined;
  }

  let frameIndex = 0;
  let currentText = "Reviewing ...";
  let rendered = false;
  let stopped = false;

  const render = () => {
    if (stopped) {
      return;
    }
    try {
      const frame = FRAMES[frameIndex % FRAMES.length] ?? "-";
      frameIndex += 1;
      clearLine(stream);
      stream.write(`${frame} ${currentText}`);
      rendered = true;
    } catch {
      stopped = true;
      clearInterval(timer);
    }
  };

  const timer = setInterval(render, 120);
  timer.unref?.();
  render();

  return {
    onTelemetryEvent(event) {
      if (event.message === "stage_started") {
        currentText = `Reviewing (stage ${event.stage}: ${stageLabel(event)}) ...`;
        render();
        return;
      }
      if (event.message === "stage_completed") {
        currentText = `Reviewing (stage ${event.stage}: complete) ...`;
        render();
        return;
      }
      if (event.stage === 4 && event.message === "repository_index_progress" && isRecord(event.data)) {
        const { phase, filesCompleted, filesTotal } = event.data;
        if ((phase === "symbols" || phase === "static_signals") &&
          typeof filesCompleted === "number" && typeof filesTotal === "number") {
          const label = phase === "symbols" ? "symbols" : "static signals";
          currentText = `Reviewing (stage 4: repository index, ${label} ${filesCompleted}/${filesTotal} files) ...`;
          render();
        }
      }
    },
    stop() {
      if (stopped) {
        return;
      }
      stopped = true;
      clearInterval(timer);
      if (rendered) {
        clearLine(stream);
      }
    }
  };
}

function shouldShowProgress(options: Required<ProgressOptions>): boolean {
  if (!options.enabled) {
    return false;
  }
  if (options.env.CI !== undefined && options.env.CI !== "" && options.env.CI !== "false" && options.env.CI !== "0") {
    return false;
  }
  return options.stream.isTTY === true;
}

function stageLabel(event: ProgressEvent): string {
  const name = isRecord(event.data) && typeof event.data.name === "string"
    ? event.data.name
    : STAGE_LABELS[event.stage] ?? "working";
  return name.replace(/_/gu, " ");
}

function clearLine(stream: NodeJS.WriteStream): void {
  stream.clearLine?.(0);
  stream.cursorTo?.(0);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
