import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    globals: true,
    include: ["tests/**/*.test.ts", "evals/synthetics/**/*.test.ts"],
    restoreMocks: true,
    clearMocks: true
  }
});
