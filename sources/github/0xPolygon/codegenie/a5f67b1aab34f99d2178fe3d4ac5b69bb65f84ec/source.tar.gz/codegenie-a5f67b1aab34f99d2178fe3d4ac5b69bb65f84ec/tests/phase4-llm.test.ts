import { buildAttentionReconciliation, attentionResolutionErrors, createAttentionResolutionRepair } from "../src/pipeline/attention-reconciliation.js";
import { assessFinalSuggestions } from "../src/pipeline/suggestion-assessment.js";
import { defaultConfig } from "../src/config/schema.js";
import { unresolvedToolDiagnostic } from "../src/util/review-health.js";
import { createRunTelemetry } from "../src/telemetry/run-artifacts.js";
import { authorizationComposition } from "./fixtures/composition/authorization-review.js";
import { composerSubmissionSchema } from "../src/pipeline/composer.js";
import { validateCompositionSubmission } from "../src/pipeline/composition-content.js";
import { createCompositionAttributionRepair, normalizeCompositionReferences } from "../src/pipeline/composition-repair.js";
import { execFileSync } from "node:child_process";
import { existsSync, mkdtempSync, mkdirSync, readFileSync, readdirSync, utimesSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { createAssistantMessageEventStream, Type } from "@earendil-works/pi-ai";
import { describe, expect, it, vi } from "vitest";
import { validateToolCall } from "./helpers/pi-validation.js";
import { __piRunnerTestHooks, createPiRunner, createRealPiAiAdapter } from "../src/llm/pi-runner.js";
import type {
  LlmCallUsage,
  LlmStructuredRequest,
  LlmRunner,
  PiAiAdapter,
  PiAssistantMessage,
  PiInvalidToolCall,
  PiToolCall,
  PiUntrustedArgumentParse,
  StoredProviderResponse
} from "../src/llm/llm-runner.js";
import {
  buildModelCallCacheKey,
  createModelCallCache,
  MODEL_CALL_CACHE_SCHEMA_VERSION,
  modelCallCacheEntryPath
} from "../src/llm/model-call-cache.js";
import { createToolResultCache } from "../src/llm/tool-result-cache.js";
import {
  SCHEMA_VERSIONS,
  SubmitCompositionSchema,
  type SubmitPacketReview,
  type SubmitComposition,
  SubmitPacketReviewSchema,
  SubmitPlanSchema,
  SubmitSystemReviewSchema,
  type SubmitVerificationVerdict,
  SubmitVerificationVerdictSchema,
  submitToolNameForStage
} from "../src/llm/schemas.js";
import { buildRepositoryToolDefinitions } from "../src/llm/tool-definitions.js";
import type { Logger, LogEvent, RepositoryTools, TelemetryEvent, ToolCallRecord } from "../src/types.js";
import type { LlmCallRecord, TelemetryRecorder } from "../src/telemetry/telemetry-recorder.js";
import { stage7RecoverInvalidSubmit } from "../src/llm/stage7-submit-repair.js";
import { canonicalizeVerifierRejection, normalizeVerifierSubmission, expandVerifierRevision, promotedCompletionIssues } from "../src/llm/verifier-revision.js";
import { createFieldRepair } from "../src/llm/field-repair.js";
import type { CandidateFinding } from "../src/types.js";
import { recoverStringWrappedVerifierFinding, VERIFIER_SUBMIT_EXAMPLE } from "../src/llm/verifier-submit-repair.js";
import type { LlmSchemaInvalidSubmitRecoveryInput } from "../src/llm/llm-runner.js";
import { clearRegisteredSecretsForTests, registerSecret, stripCredentials } from "../src/telemetry/redaction.js";
import type { ToolDefinition } from "../src/llm/llm-runner.js";
import type { PiAuthStorage, ProviderAuthEntry } from "../src/provider/provider-services.js";
import { CodegenieError } from "../src/util/errors.js";
import { hardToolBudget, scaleToolBudget } from "../src/util/budget.js";
import {
  buildStructuredSubmitFailureDiagnostic,
  structuredSubmitFailureDiagnosticFromError
} from "../src/llm/schema-diagnostics.js";

type RealPiAiAdapterDepsForTest = NonNullable<Parameters<typeof createRealPiAiAdapter>[0]>;
type PiStreamForTest = NonNullable<RealPiAiAdapterDepsForTest["stream"]>;
type PiStreamSimpleForTest = NonNullable<RealPiAiAdapterDepsForTest["streamSimple"]>;

describe("Phase 4 schemas and repository tool definitions", () => {
  it("redacts shared object references without mistaking them for cycles", () => {
    const shared = { token: "sk-shared-secret-value-1234567890" };
    const cyclic: { self?: unknown } = {};
    cyclic.self = cyclic;

    const redacted = stripCredentials({ first: shared, second: shared, cyclic }) as {
      first: { token: string };
      second: { token: string };
      cyclic: { self: string };
    };

    expect(redacted.first).toEqual({ token: "[redacted:pattern]" });
    expect(redacted.second).toEqual({ token: "[redacted:pattern]" });
    expect(redacted.cyclic.self).toBe("[redacted:circular]");
  });

  it("rejects hallucinated fields and exposes stage submit tool names", () => {
    expect(submitToolNameForStage(5)).toBe("submit_plan");
    expect(submitToolNameForStage(7)).toBe("submit_review");
    expect(submitToolNameForStage(8)).toBe("submit_system_review");
    expect(submitToolNameForStage(9)).toBe("submit_verdict");
    expect(submitToolNameForStage(10)).toBe("submit_composition");
    expect(SCHEMA_VERSIONS.submit_plan).toBe(6);
    expect(SCHEMA_VERSIONS.submit_verdict).toBe(11);

    const valid = {
      diffUnderstanding: { declaredIntent: "Small change", inferredBehavior: "The diff makes a small change." },
      coverage: []
    };
    const submitTool = { name: "submit_plan", description: "submit", parameters: SubmitPlanSchema };
    expect(
      validateToolCall([submitTool], {
        type: "toolCall",
        id: "submit-1",
        name: "submit_plan",
        arguments: valid
      })
    ).toEqual(valid);
    expect(() =>
      validateToolCall([submitTool], {
        type: "toolCall",
        id: "submit-2",
        name: "submit_plan",
        arguments: { ...valid, inventedField: true }
      })
    ).toThrow();
    expect(() =>
      validateToolCall([submitTool], {
        type: "toolCall",
        id: "submit-old-understanding",
        name: "submit_plan",
        arguments: { ...valid, diffUnderstanding: { summary: "old", intent: "old" } }
      })
    ).toThrow();
  });

  it("keeps a 2,000-character verifier target with a 4,000-character hard schema buffer", () => {
    const tool = { name: "submit_verdict", description: "submit", parameters: SubmitVerificationVerdictSchema };
    const verdict = (length: number): PiToolCall => ({
      type: "toolCall",
      id: `verdict-${length}`,
      name: "submit_verdict",
      arguments: {
        verdict: "reject",
        reason: "r".repeat(length),
        requiredEvidencePresent: false,
        falsePositiveRisk: "high"
      }
    });
    for (const length of [2_000, 2_001, 2_102, 2_285, 2_327, 2_984, 4_000]) {
      expect(() => validateToolCall([tool], verdict(length))).not.toThrow();
    }
    expect(() => validateToolCall([tool], verdict(4_001))).toThrow();
  });

  it("extracts only schema-owned paths and rules before Pi's received-arguments delimiter", () => {
    const secret = "sk-seeded-secret-that-must-never-surface";
    let validationMessage = "";
    try {
      validateToolCall(
        [{ name: "submit_verdict", description: "submit", parameters: SubmitVerificationVerdictSchema }],
        {
          type: "toolCall",
          id: "bad-verdict",
          name: "submit_verdict",
          arguments: {
            verdict: "reject",
            reason: `${"x".repeat(4_001)}${secret}`,
            requiredEvidencePresent: false,
            falsePositiveRisk: "high"
          }
        }
      );
    } catch (error) {
      validationMessage = error instanceof Error ? error.message : String(error);
    }
    const diagnostic = buildStructuredSubmitFailureDiagnostic({
      stage: 9,
      role: "verifier",
      submitTool: "submit_verdict",
      submitSchemaVersion: 4,
      attempt: "repair",
      classification: "schema_invalid",
      schema: SubmitVerificationVerdictSchema,
      validationMessage
    });
    expect(diagnostic.issues).toEqual(expect.arrayContaining([
      expect.objectContaining({ path: "reason", rule: "maxLength" })
    ]));
    expect(JSON.stringify(diagnostic)).not.toContain(secret);

    const malformed = buildStructuredSubmitFailureDiagnostic({
      stage: 9,
      role: "verifier",
      submitTool: "submit_verdict",
      submitSchemaVersion: 4,
      attempt: "repair",
      schema: SubmitVerificationVerdictSchema,
      validationMessage: `  - attacker.path: required property\n${secret}`
    });
    expect(malformed.issues).toEqual([]);
    expect(JSON.stringify(malformed)).not.toContain(secret);

    const manyIssues = buildStructuredSubmitFailureDiagnostic({
      stage: 9,
      role: "verifier",
      submitTool: "submit_verdict",
      submitSchemaVersion: 4,
      attempt: "repair",
      classification: "final_arguments_invalid",
      schema: SubmitVerificationVerdictSchema,
      validationMessage: `${[
        "  - attacker.path: arbitrary prose",
        ...Array.from({ length: 20 }, () => "  - reason: must not have more than 4000 characters")
      ].join("\n")}\n\nReceived arguments:\n${secret}`
    });
    expect(manyIssues.classification).toBe("final_arguments_invalid");
    expect(manyIssues.issues).toHaveLength(12);
    expect(manyIssues.issues[0]).toEqual({ path: "root", rule: "schema" });
    expect(JSON.stringify(manyIssues)).not.toContain(secret);
  });

  it("extracts Stage 8 diagnostics and rejects mismatched stage/role identities", () => {
    const diagnostic = buildStructuredSubmitFailureDiagnostic({
      stage: 8,
      role: "systemReview",
      submitTool: "submit_system_review",
      submitSchemaVersion: 1,
      attempt: "repair",
      schema: SubmitSystemReviewSchema,
      validationMessage: "  - findings: required property\n\nReceived arguments:\n{}"
    });
    const wrapped = (structuredSubmitFailure: unknown) => new CodegenieError(
      "llm_schema_invalid",
      "bounded terminal failure",
      { context: { structuredSubmitFailure } }
    );

    expect(structuredSubmitFailureDiagnosticFromError(wrapped(diagnostic))).toEqual(diagnostic);
    expect(structuredSubmitFailureDiagnosticFromError(wrapped({ ...diagnostic, role: "planner" }))).toBeUndefined();
    expect(structuredSubmitFailureDiagnosticFromError(wrapped({ ...diagnostic, stage: 7 }))).toBeUndefined();
  });

  it("exposes model-facing submit schemas without pipeline-owned fields", () => {
    const review = { findings: [], followUpHints: [], uncertainties: [] };
    const reviewTool = { name: "submit_review", description: "submit", parameters: SubmitPacketReviewSchema };
    expect(
      validateToolCall([reviewTool], {
        type: "toolCall",
        id: "submit-review",
        name: "submit_review",
        arguments: review
      })
    ).toEqual(review);
    expect(() =>
      validateToolCall([reviewTool], {
        type: "toolCall",
        id: "submit-review-owned",
        name: "submit_review",
        arguments: { ...review, packetId: "packet-1", lenses: ["core/code-review"], status: "completed" }
      })
    ).toThrow();

    const verdict = {
      verdict: "keep",
      reason: "evidence is present",
      requiredEvidencePresent: true,
      falsePositiveRisk: "low"
    };
    const verdictTool = { name: "submit_verdict", description: "submit", parameters: SubmitVerificationVerdictSchema };
    expect(
      validateToolCall([verdictTool], {
        type: "toolCall",
        id: "submit-verdict",
        name: "submit_verdict",
        arguments: verdict
      })
    ).toEqual(verdict);
    expect(() =>
      validateToolCall([verdictTool], {
        type: "toolCall",
        id: "submit-verdict-owned",
        name: "submit_verdict",
        arguments: { ...verdict, candidateId: "candidate-1", verificationIncomplete: true }
      })
    ).toThrow();

    const composition = {
      summary: "One verified finding.",
      composedFindings: [{ findingIds: ["finding-1"], finalBody: "The final body.", publication: "inline" }]
    };
    const compositionTool = { name: "submit_composition", description: "submit", parameters: SubmitCompositionSchema };
    expect(
      validateToolCall([compositionTool], {
        type: "toolCall",
        id: "submit-composition",
        name: "submit_composition",
        arguments: composition
      })
    ).toEqual(composition);
    expect(() =>
      validateToolCall([compositionTool], {
        type: "toolCall",
        id: "submit-composition-old",
        name: "submit_composition",
        arguments: {
          ...composition,
          markdown: "old markdown",
          findingOrder: ["finding-1"],
          suppressedFindingIds: [],
          notes: []
        }
      })
    ).toThrow();
  });

  it("exposes a provider-safe flat verdict schema while leaving revise payload semantics to runtime", () => {
    const tool = { name: "submit_verdict", description: "submit", parameters: SubmitVerificationVerdictSchema };
    const common = {
      reason: "decisive evidence supports this verdict",
      requiredEvidencePresent: true,
      falsePositiveRisk: "low"
    };
    const finalFinding = validCandidateReviewFinding();
    const revisedAnchor = { path: "src/a.ts", line: 4, side: "RIGHT", hunkId: "hunk-1" };
    const validate = (argumentsValue: Record<string, unknown>) => validateToolCall([tool], {
      type: "toolCall",
      id: "submit-verdict-contract",
      name: "submit_verdict",
      arguments: argumentsValue
    });
    const rootSchema = SubmitVerificationVerdictSchema as {
      type?: string;
      anyOf?: unknown;
      required?: string[];
      properties?: Record<string, unknown>;
    };

    expect(rootSchema.type).toBe("object");
    expect(rootSchema.anyOf).toBeUndefined();
    expect(rootSchema.required).toEqual(expect.arrayContaining([
      "verdict",
      "reason",
      "requiredEvidencePresent",
      "falsePositiveRisk"
    ]));
    expect(rootSchema.required).not.toContain("finalFinding");
    expect(rootSchema.required).not.toContain("revisedAnchor");
    expect(rootSchema.properties).toHaveProperty("verdict");

    expect(validate({ verdict: "keep", ...common })).toEqual({ verdict: "keep", ...common });
    expect(validate({ verdict: "reject", ...common })).toEqual({ verdict: "reject", ...common });
    expect(validate({ verdict: "keep", ...common, finalFinding })).toEqual({ verdict: "keep", ...common, finalFinding });
    expect(validate({ verdict: "revise", ...common, finalFinding })).toEqual({ verdict: "revise", ...common, finalFinding });
    expect(validate({ verdict: "revise", ...common, revisedAnchor })).toEqual({ verdict: "revise", ...common, revisedAnchor });
    expect(validate({ verdict: "revise", ...common, finalFinding, revisedAnchor })).toEqual({
      verdict: "revise",
      ...common,
      finalFinding,
      revisedAnchor
    });
    expect(validate({ verdict: "revise", ...common })).toEqual({ verdict: "revise", ...common });
    expect(() => validate({ verdict: "revise", ...common, finalFinding, extra: true })).toThrow();
  });

  it("defines all nine repository tools and renders tool failures as model-visible errors", async () => {
    const defs = buildRepositoryToolDefinitions(fakeRepositoryTools());
    expect(defs.map((tool) => tool.name)).toEqual([
      "read_range",
      "read_file_outline",
      "read_symbol",
      "find_definition",
      "read_diff_blocks",
      "search_files",
      "find_symbol_mentions",
      "find_likely_tests",
      "list_files"
    ]);

    const readRange = defs.find((tool) => tool.name === "read_range");
    const range = await readRange?.execute({ path: "src/a.ts", startLine: 1, endLine: 2 }, new AbortController().signal);
    expect(range?.text).toContain("line 1");
    expect(range?.meta?.precision).toBe("exact");

    const readSymbol = defs.find((tool) => tool.name === "read_symbol");
    const invalid = await readSymbol?.execute({ path: "src/a.ts" }, new AbortController().signal);
    expect(invalid).toMatchObject({
      isError: true
    });
    expect(invalid?.text).toContain("read_symbol requires exactly one");
  });

  it("can omit likely-test lookup from model-facing repository tools", () => {
    const defs = buildRepositoryToolDefinitions(fakeRepositoryTools(), { includeLikelyTests: false });

    expect(defs.map((tool) => tool.name)).toEqual([
      "read_range",
      "read_file_outline",
      "read_symbol",
      "find_definition",
      "read_diff_blocks",
      "search_files",
      "find_symbol_mentions",
      "list_files"
    ]);
  });

  it("allows auto source for model-facing symbol lookups and renders fallback metadata", async () => {
    const tools: RepositoryTools = {
      ...fakeRepositoryTools(),
      readSymbol: async (_path, _selector, source) => ({
        text: "func DeletedHelper() {}",
        symbol: { path: "src/a.ts", name: "DeletedHelper", kind: "function", lineRange: [1, 1] },
        meta: {
          backend: "tree-sitter",
          precision: "syntactic",
          degraded: false,
          requestedSource: source?.kind ?? "head",
          sourceUsed: "base",
          sourceFallback: true,
          baseOnly: true
        }
      }),
      findDefinition: async (_symbolName, options) => ({
        definitions: [{ symbol: { path: "src/a.ts", name: "DeletedHelper", kind: "function", lineRange: [1, 1] }, text: "func DeletedHelper() {}" }],
        meta: {
          backend: "tree-sitter",
          precision: "syntactic",
          degraded: false,
          requestedSource: options?.source?.kind ?? "head",
          sourceUsed: "base",
          sourceFallback: true,
          baseOnly: true
        }
      })
    };
    const defs = buildRepositoryToolDefinitions(tools);
    const readSymbol = defs.find((tool) => tool.name === "read_symbol");
    const findDefinition = defs.find((tool) => tool.name === "find_definition");

    const symbol = await readSymbol?.execute(
      { path: "src/a.ts", symbolName: "DeletedHelper", source: { kind: "auto" } },
      new AbortController().signal
    );
    const definition = await findDefinition?.execute(
      { symbolName: "DeletedHelper", source: { kind: "auto" } },
      new AbortController().signal
    );

    expect(symbol?.text).toContain("source: requested auto, used base");
    expect(symbol?.text).toContain("source fallback: head to base");
    expect(symbol?.text).toContain("symbol exists only in base");
    expect(definition?.text).toContain("source: requested auto, used base");
  });

  it("suppresses facade recording and preserves path rejection metadata for model tools", async () => {
    const facadeRecords: string[] = [];
    let suppressFacadeRecord = false;
    const tools = {
      ...fakeRepositoryTools(),
      withToolCallContext: async <T>(context: { record?: boolean }, run: () => Promise<T>) => {
        suppressFacadeRecord = context.record === false;
        try {
          return await run();
        } finally {
          suppressFacadeRecord = false;
        }
      },
      readRange: async () => {
        if (!suppressFacadeRecord) {
          facadeRecords.push("read_range");
        }
        throw new CodegenieError("path_outside_repo", "outside repo");
      }
    } satisfies RepositoryTools & {
      withToolCallContext<T>(context: { record?: boolean }, run: () => Promise<T>): Promise<T>;
    };

    const readRange = buildRepositoryToolDefinitions(tools).find((tool) => tool.name === "read_range");
    const result = await readRange?.execute({ path: "../secret", startLine: 1, endLine: 1 }, new AbortController().signal);

    expect(facadeRecords).toEqual([]);
    expect(result).toMatchObject({
      isError: true,
      errorCode: "path_outside_repo"
    });
  });

  it("rejects model-facing repository tools promptly when their signal aborts", async () => {
    const tools = {
      ...fakeRepositoryTools(),
      searchFiles: vi.fn(async () => new Promise<never>(() => undefined))
    } satisfies RepositoryTools;
    const search = buildRepositoryToolDefinitions(tools).find((tool) => tool.name === "search_files");
    if (!search) {
      throw new Error("search_files definition missing");
    }
    const controller = new AbortController();

    const result = search.execute({ query: "needle" }, controller.signal);
    await Promise.resolve();
    expect(tools.searchFiles).toHaveBeenCalledTimes(1);
    controller.abort(new Error("timeout"));

    await expect(result).rejects.toMatchObject({
      code: "llm_call_failed",
      context: { reason: "timeout" }
    });
  });
});

describe("Phase 4 Pi runner and model-call cache", () => {
  it("rejects a configured reasoning level the resolved model does not advertise", () => {
    const build = (reasoning: "high" | "xhigh", raw: Record<string, unknown>): LlmRunner =>
      createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", reasoning, maxConcurrentCalls: 1 },
        telemetry: fakeTelemetry().recorder,
        logger: fakeLogger(),
        runSignal: new AbortController().signal,
        adapter: { resolveModel: () => ({ provider: "fake", id: "fake-model", raw }), complete: vi.fn(), validateToolCall },
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });

    // pi advertises minimal/low/medium/high unless the model maps xhigh/max
    expect(() => build("xhigh", { id: "fake-model", reasoning: true })).toThrow(
      expect.objectContaining({
        code: "config_error",
        message: "fake/fake-model does not support reasoning xhigh; supported levels: minimal, low, medium, high"
      })
    );
    expect(() => build("xhigh", { id: "fake-model", reasoning: true, thinkingLevelMap: { xhigh: "xhigh" } })).not.toThrow();
    // models without reasoning (and bare test fakes) ignore the level
    expect(() => build("xhigh", { id: "fake-model" })).not.toThrow();
  });

  it("runs a tool round, fences tool output, validates submit payload, and records telemetry", async () => {
    const telemetry = fakeTelemetry();
    const usage: LlmCallUsage[] = [];
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-1",
          name: "read_range",
          arguments: { path: "src/a.ts", startLine: 1, endLine: 2 }
        }
      ]),
      assistant([
        {
          type: "toolCall",
          id: "submit-1",
          name: "submit_review",
          arguments: {
            findings: [],
            followUpHints: [],
            uncertainties: []
          }
        }
      ])
    ]);

    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => "ok",
        onUsage: (entry) => usage.push(entry)
      }
    });

    const result = await runner.runStructured({
      stage: 7,
      prompt: "review packet",
      schema: SubmitPacketReviewSchema,
      templateVersion: "test-template",
      tools: buildRepositoryToolDefinitions(fakeRepositoryTools()),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 2000 },
      timeoutMs: 1000,
      telemetryContext: { workerId: "worker-1", packetId: "packet-1" }
    });

    expect(result).toEqual({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });
    expect(adapter.contexts[1]).toContain("untrusted-data label=tool-result-read_range");
    expect(telemetry.modelCalls.map((call) => call.stopReason)).toEqual(["tool_calls", "submit"]);
    expect(telemetry.modelCalls[1]?.schemaValid).toBe(true);
    const modelCallEvents = telemetry.events.filter((event) =>
      event.message === "model_call_queued" || event.message === "model_call_started"
    );
    expect(modelCallEvents.map((event) => event.message)).toEqual([
      "model_call_queued",
      "model_call_started",
      "model_call_queued",
      "model_call_started"
    ]);
    expect(modelCallEvents[0]).toMatchObject({
      stage: 7,
      level: "debug",
      workerId: "worker-1",
      packetId: "packet-1",
      data: expect.objectContaining({
        callId: "mc-000001",
        role: "packetReview",
        provider: "fake",
        model: "fake-model",
        kind: "initial",
        attempt: 1,
        promptChars: expect.any(Number),
        promptHash: expect.any(String),
        toolNames: expect.arrayContaining(["read_range", "submit_review"])
      })
    });
    expect(telemetry.toolCalls).toHaveLength(1);
    expect(telemetry.toolCalls[0]).toMatchObject({
      stage: 7,
      initiator: "model",
      modelCallId: "mc-000001",
      tool: "read_range",
      status: "ok",
      packetId: "packet-1"
    });
    expect(usage).toHaveLength(2);
  });

  it("writes rejected arguments to a separate redacted diagnostic artifact, never the repair conversation", async () => {
    registerSecret("diagnostic-secret-value");
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([invalidSubmitCall("bad", "submit_review", { state: "invalid", errorKind: "invalid_syntax" })]),
      assistant([validSubmitReviewCall("repaired")])
    ]);
    const complete = adapter.complete;
    adapter.complete = async (model, context, options) => {
      if (!adapter.contexts.length) {
        (options.onRejectedArguments as (value: unknown) => void)({ contentIndex: 0, toolCallId: "bad", name: "submit_review",
          parse: { state: "invalid", errorKind: "invalid_syntax" }, capturedChars: 70, sha256: "hash",
          prefix: '{"reason":"diagnostic-secret-value","invalid":}', suffix: "", omittedChars: 0, sampleChars: 70 });
      }
      return complete(model, context, options);
    };
    try {
      const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
      await runner.runStructured({ ...submitReviewRequest("diagnostic"), schemaRepair: {
        buildPrompt: () => "Submit a new complete review from retained evidence."
      } });
      const diagnostic = telemetry.debugWrites.find(write => write.id.endsWith(".invalid-arguments-0"))!;
      expect(diagnostic.record).toMatchObject({ artifactKind: "rejected_tool_arguments", diagnosticOnly: true, toolCallId: "bad",
        redaction: { applied: true } });
      expect(JSON.stringify(diagnostic.record)).toContain("[redacted:secret]");
      expect(JSON.stringify(diagnostic.record)).not.toContain("diagnostic-secret-value");
      expect(adapter.contexts[1]).not.toContain('invalid\":');
      expect(adapter.contexts[1]).not.toContain("diagnostic-secret-value");
      expect(adapter.contexts[1]).not.toContain("invalidToolCall");
      expect(telemetry.events.some(event => event.message === "final_arguments_rejected")).toBe(true);
    } finally { clearRegisteredSecretsForTests(); }
  });

  it.each([false, true])("delivers syntax-only repair feedback with custom prompt=%s", async customPrompt => {
    registerSecret("repair-diagnostic-secret");
    const telemetry = fakeTelemetry();
    const invalid = { ...invalidSubmitCall("bad", "submit_review", { state: "invalid", errorKind: "invalid_syntax" }),
      syntaxDiagnostic: { error: "Expected ',' or '}' after property value in JSON", offset: 40, excerptStart: 0,
        excerpt: '{"note":"repair-diagnostic-secret","findings":[]}}' } };
    const adapter = scriptedAdapter([assistant([invalid]), assistant([validSubmitReviewCall("recovered")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    try {
      await expect(runner.runStructured({ ...submitReviewRequest("syntax-feedback"), schemaRepair: {
        ...(customPrompt ? { buildPrompt: () => "CUSTOM_STAGE_REPAIR" } : {})
      } })).resolves.toMatchObject({ findings: [] });
      const prompt = adapter.contexts[1]!;
      expect(prompt).toContain("rejected-json-syntax");
      expect(prompt).toContain("Expected ',' or '}' after property value in JSON");
      expect(prompt).toContain("not a retained submission or evidence");
      expect(prompt).toContain("complete schema-valid object");
      expect(prompt).toContain("[redacted:secret]");
      expect(prompt).not.toContain("repair-diagnostic-secret");
      expect(prompt).not.toContain("invalidToolCall");
      if (customPrompt) expect(prompt).toContain("CUSTOM_STAGE_REPAIR");
      expect(adapter.complete).toHaveBeenCalledTimes(2);
    } finally { clearRegisteredSecretsForTests(); }
  });

  it.each([false, true])("targets XML verifier repairs and preserves attempt limits (exhausted=%s)", async exhausted => {
    const invalid = { ...invalidSubmitCall("xml", "submit_verdict", { state: "invalid", errorKind: "invalid_syntax" }),
      syntaxDiagnostic: { error: "Invalid JSON syntax", excerptStart: 0,
        excerpt: '"proofAssessment": <parameter name="status">unresolved', xmlParameter: { field: "proofAssessment" } } };
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter(exhausted ? Array.from({ length: 4 }, () => assistant([invalid]))
      : [assistant([invalid]), assistant([validSubmitVerdictCall("recovered")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = runner.runStructured({ stage: 9, schema: SubmitVerificationVerdictSchema, prompt: "verify",
      templateVersion: "test", timeoutMs: 1000, schemaRepair: { buildPrompt: () => "CUSTOM_VERIFIER_REPAIR" } });
    if (exhausted) await expect(result).rejects.toMatchObject({ code: "llm_schema_invalid" });
    else await expect(result).resolves.toHaveProperty("verdict");
    const prompt = adapter.contexts[1]!;
    expect(prompt).toContain("CUSTOM_VERIFIER_REPAIR");
    expect(prompt).toContain("XML-style parameter tags occurred outside JSON strings");
    expect(prompt).toContain("xml-json-shape-targets");
    expect(prompt).toContain("jsonStructureExample");
    expect(prompt).toContain("Optional fields remain optional");
    expect(prompt).toContain("not default decisions");
    expect(prompt).toContain("assumptions");
    expect(prompt).toContain("do not convert or merge the unreadable draft");
    expect(telemetry.modelCalls[0]).toMatchObject({ stopReason: "submit", status: "schema_invalid", finalArgumentState: "invalid" });
    expect(adapter.complete).toHaveBeenCalledTimes(exhausted ? 4 : 2);
  });

  it("writes redacted reconstructable model request and response debug artifacts", async () => {
    clearRegisteredSecretsForTests();
    registerSecret("debug-secret-token");
    const telemetry = fakeTelemetry();
    const usage: LlmCallUsage[] = [];
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-debug",
          name: "read_range",
          arguments: { path: "src/a.ts", startLine: 1, endLine: 2 }
        }
      ]),
      assistant([validSubmitReviewCall("submit-debug")])
    ]);
    const tools = fakeRepositoryTools();
    tools.readRange = async () => ({
      text: "line 1 debug-secret-token\nline 2",
      meta: { backend: "text", precision: "exact", degraded: false }
    });
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => "ok",
        onUsage: (entry) => usage.push(entry)
      }
    });

    await runner.runStructured({
      stage: 7,
      prompt: "review debug-secret-token",
      schema: SubmitPacketReviewSchema,
      templateVersion: "debug-template",
      tools: buildRepositoryToolDefinitions(tools),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 2000 },
      timeoutMs: 1000,
      telemetryContext: { workerId: "worker-debug", packetId: "packet-debug" }
    });

    const request1 = debugRecord(telemetry, "mc-000001.request");
    expect(request1).toMatchObject({
      schemaVersion: 1,
      artifactKind: "llm_call_request",
      callId: "mc-000001",
      stage: 7,
      role: "packetReview",
      kind: "initial",
      workerId: "worker-debug",
      packetId: "packet-debug",
      provider: { provider: "fake", model: "fake-model", reasoning: "high" },
      request: {
        runnerMessageVersion: "pi-runner-loop-v24",
        promptTemplateVersion: "debug-template",
        schemaName: "submit_review",
        schemaVersion: 5,
        toolChoice: "auto",
        messageCount: 1
      },
      redaction: {
        applied: true,
        markerCounts: { secret: 1 }
      }
    });
    const request1Text = JSON.stringify(request1);
    expect(request1Text).not.toContain("debug-secret-token");
    expect(request1Text).toContain("[redacted:secret]");
    const request1Payload = request1.request as { messages: unknown[]; tools: Array<Record<string, unknown>> };
    expect(request1Payload.messages).toEqual([
      expect.objectContaining({ role: "user", content: expect.stringContaining("review [redacted:secret]") })
    ]);
    expect(request1Payload.tools.find((tool) => tool.name === "read_range")).toMatchObject({
      localParametersHash: expect.any(String),
      providerParametersHash: expect.any(String),
      providerParameters: expect.any(Object)
    });
    expect(request1Payload.tools.find((tool) => tool.name === "submit_review")).toMatchObject({
      providerParametersHash: expect.any(String)
    });

    const response1 = debugRecord(telemetry, "mc-000001.response");
    expect(response1).toMatchObject({
      schemaVersion: 1,
      artifactKind: "llm_call_response",
      callId: "mc-000001",
      stage: 7,
      stopReason: "tool_calls",
      response: { role: "assistant" }
    });

    const request2 = debugRecord(telemetry, "mc-000002.request");
    const request2Text = JSON.stringify(request2);
    expect(request2Text).not.toContain("debug-secret-token");
    expect(request2Text).toContain("[redacted:secret]");
    expect(request2Text).toContain("tool-result-read_range");
    const request2Payload = request2.request as { messages: Array<Record<string, unknown>> };
    expect(request2Payload.messages).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          role: "toolResult",
          toolCallId: "tool-debug",
          toolName: "read_range"
        })
      ])
    );
    expect(usage).toHaveLength(2);
    clearRegisteredSecretsForTests();
  });

  it("truncates oversized model debug artifacts and records a warning", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([assistant([validSubmitReviewCall("submit-large-debug")])]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => "ok",
        onUsage: () => undefined
      }
    });

    await runner.runStructured({
      stage: 7,
      prompt: "x".repeat(1_500_100),
      schema: SubmitPacketReviewSchema,
      templateVersion: "debug-template",
      timeoutMs: 1000,
      telemetryContext: { packetId: "packet-large-debug" }
    });

    expect(debugRecord(telemetry, "mc-000001.request")).toMatchObject({
      schemaVersion: 1,
      artifactKind: "truncated_debug_artifact",
      stage: 7,
      id: "mc-000001.request",
      kind: "llm-calls",
      originalChars: expect.any(Number),
      maxChars: 1_500_000,
      preview: expect.any(String)
    });
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 7,
          level: "warn",
          message: "debug_artifact_truncated",
          packetId: "packet-large-debug",
          data: expect.objectContaining({
            kind: "llm-calls",
            id: "mc-000001.request",
            originalChars: expect.any(Number),
            maxChars: 1_500_000
          })
        })
      ])
    );
  });

  it("normalizes prompt-cache usage into explicit token and cost fields", async () => {
    const telemetry = fakeTelemetry();
    const usage: LlmCallUsage[] = [];
    const cache = {
      get: vi.fn(async (_key: string) => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    };
    const response = assistant([validSubmitReviewCall("submit-cache-usage")]);
    response.usage = {
      input: 10,
      output: 5,
      cacheRead: 100,
      cacheWrite: 2,
      totalTokens: 117,
      cost: {
        input: 0.01,
        output: 0.02,
        cacheRead: 0.003,
        cacheWrite: 0.004,
        total: 0.037
      }
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter: scriptedAdapter([response]),
      cache,
      hooks: {
        checkpoint: () => "ok",
        onUsage: (entry) => usage.push(entry)
      }
    });

    await runner.runStructured(submitReviewRequest("packet-cache-usage"));

    const expectedUsage = {
      inputTokens: 112,
      uncachedInputTokens: 10,
      cacheReadTokens: 100,
      cacheWriteTokens: 2,
      billableInputTokens: 112,
      outputTokens: 5,
      totalTokens: 117,
      costUSD: 0.037,
      inputCostUSD: 0.01,
      outputCostUSD: 0.02,
      cacheReadCostUSD: 0.003,
      cacheWriteCostUSD: 0.004
    };
    expect(telemetry.modelCalls[0]).toMatchObject(expectedUsage);
    expect(usage[0]).toMatchObject(expectedUsage);
    expect(cache.put.mock.calls[0]?.[1].usage).toMatchObject(expectedUsage);
    expect(debugRecord(telemetry, "mc-000001.response")).toMatchObject({
      usage: {
        usageProvider: "fake",
        usageRaw: response.usage,
        usageNormalized: expectedUsage
      }
    });
  });

  it("continues after a path_outside_repo repository tool rejection and records the rejected tool call", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-outside",
          name: "read_range",
          arguments: { path: "../secret", startLine: 1, endLine: 1 }
        }
      ]),
      assistant([validSubmitReviewCall("submit-after-rejected-tool")])
    ]);
    const tools = fakeRepositoryTools();
    tools.readRange = async () => {
      throw new CodegenieError("path_outside_repo", "outside repo");
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => "ok",
        onUsage: () => undefined
      }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-rejected-tool"),
        tools: buildRepositoryToolDefinitions(tools),
        toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 2000 },
        telemetryContext: { workerId: "worker-reject", packetId: "packet-rejected-tool" }
      })
    ).resolves.toEqual({ findings: [], followUpHints: [], uncertainties: [] });

    expect(adapter.contexts[1]).toContain("\"isError\":true");
    expect(adapter.contexts[1]).toContain("path_outside_repo");
    expect(telemetry.toolCalls).toEqual([
      expect.objectContaining({
        stage: 7,
        tool: "read_range",
        status: "rejected",
        errorCode: "path_outside_repo",
        packetId: "packet-rejected-tool",
        workerId: "worker-reject"
      })
    ]);
    const manipulationEvents = telemetry.events.filter(
      (event) => event.data?.event === "tool_path_outside_repo"
    );
    expect(manipulationEvents).toHaveLength(1);
    expect(manipulationEvents[0]).toMatchObject({
      stage: 7,
      level: "warn",
      workerId: "worker-reject",
      packetId: "packet-rejected-tool",
      data: { event: "tool_path_outside_repo", tool: "read_range" }
    });
  });

  it("redacts provider responses before appending them to the live conversation", async () => {
    clearRegisteredSecretsForTests();
    registerSecret("super-secret-provider-token");
    const adapter = scriptedAdapter([
      assistant([{ type: "text", text: "provider leaked super-secret-provider-token" }]),
      assistant([validSubmitReviewCall("submit-after-redaction")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => "ok",
        onUsage: () => undefined
      }
    });

    await runner.runStructured(submitReviewRequest("packet-redaction"));

    expect(adapter.contexts[1]).not.toContain("super-secret-provider-token");
    expect(adapter.contexts[1]).toContain("[redacted:secret]");
    clearRegisteredSecretsForTests();
  });

  it("uses a separate investigation signal while tools and finalization share the hard deadline", async () => {
    const providerSignals: AbortSignal[] = [];
    const toolSignals: AbortSignal[] = [];
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute: vi.fn(async (_args, signal) => {
        toolSignals.push(signal);
        return {
          text: "line 1",
          meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
        };
      })
    };
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, _context, options) => {
        if (!(options.signal instanceof AbortSignal)) {
          throw new Error("missing abort signal");
        }
        providerSignals.push(options.signal);
        return providerSignals.length === 1
          ? assistant([
              {
                type: "toolCall",
                id: "tool-timeout-signal",
                name: "read_range",
                arguments: { path: "src/a.ts" }
              }
            ])
          : assistant([validSubmitReviewCall("submit-timeout-signal")]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-timeout-signal"),
      tools: [tool],
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 3 }
    });

    expect(providerSignals).toHaveLength(2);
    expect(new Set(providerSignals).size).toBe(2);
    expect(toolSignals).toEqual([providerSignals[1]]);
  });

  it("times out provider calls even when the adapter ignores the abort signal", async () => {
    const telemetry = fakeTelemetry();
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => new Promise<PiAssistantMessage>(() => undefined)),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-provider-timeout"),
        timeoutMs: 20
      })
    ).rejects.toMatchObject({
      code: "llm_call_failed",
      context: { reason: "timeout" }
    });

    expect(adapter.complete).toHaveBeenCalledTimes(1);
    expect(telemetry.events.map((event) => event.message)).toEqual(
      expect.arrayContaining(["model_call_queued", "model_call_started"])
    );
    expect(telemetry.modelCalls).toEqual([
      expect.objectContaining({
        status: "timeout",
        stopReason: "error",
        errorCode: "llm_call_failed"
      })
    ]);
    expect(debugRecord(telemetry, "mc-000001.request")).toMatchObject({
      artifactKind: "llm_call_request",
      callId: "mc-000001",
      kind: "initial"
    });
    expect(debugRecord(telemetry, "mc-000001.response")).toMatchObject({
      artifactKind: "llm_call_response",
      callId: "mc-000001",
      status: "timeout",
      errorCode: "llm_call_failed",
      error: { message: "LLM model task timed out" }
    });
  });

  it("routes a pass past its soft deadline to a forced finalize within the grace window", async () => {
    const telemetry = fakeTelemetry();
    const scripted = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "tool-1", name: "read_range", arguments: { path: "src/a.ts", startLine: 1, endLine: 2 } }
      ]),
      assistant([
        { type: "toolCall", id: "submit-1", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ])
    ]);
    const baseComplete = scripted.complete;
    let firstCall = true;
    const adapter: typeof scripted = {
      ...scripted,
      complete: vi.fn(async (model, context, options) => {
        if (firstCall) {
          firstCall = false;
          // Consume the scripted response before delaying; its late tool call
          // must be discarded when the investigation is cancelled at 150ms.
          const late = await baseComplete(model, context, options);
          await new Promise((resolve) => setTimeout(resolve, 200));
          return late;
        }
        return baseComplete(model, context, options);
      })
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    const result = await runner.runStructured({
      ...submitReviewRequest("packet-soft-deadline"),
      tools: buildRepositoryToolDefinitions(fakeRepositoryTools()),
      toolBudget: { maxToolCalls: 3, maxInvestigationRounds: 3, maxResultChars: 2000 },
      timeoutMs: 150,
      telemetryContext: { workerId: "worker-1", packetId: "packet-soft-deadline" }
    });

    expect(result).toEqual({ findings: [], followUpHints: [], uncertainties: [] });
    expect(scripted.toolNames[1]).toEqual(["submit_review"]);
    expect(scripted.contexts[1]).toContain("time budget is exhausted");
    const finalizeStart = telemetry.events.find((event) => event.message === "full_finalize_started");
    expect(finalizeStart?.data).toMatchObject({ reason: "soft_deadline" });
    const graceUsed = telemetry.events.find((event) => event.message === "finalize_grace_used");
    expect(graceUsed?.data).toMatchObject({ graceMsUsed: expect.any(Number) });
    expect(telemetry.modelCalls[1]).toMatchObject({ kind: "finalize", status: "ok" });
  });

  it("records the effective provider protocol on model calls and emits provider_protocol once", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "submit-1", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured(submitReviewRequest("packet-protocol"));

    expect(telemetry.modelCalls[0]).toMatchObject({
      toolChoiceRequested: "forced:submit_review",
      toolChoiceEffective: "required",
      toolChoiceDowngraded: false,
      reasoningRequested: "high",
      reasoningMechanism: "unknown",
      reasoningLevelEffective: "high"
    });
    const protocolEvents = telemetry.events.filter((event) => event.message === "provider_protocol");
    expect(protocolEvents).toHaveLength(1);
    expect(protocolEvents[0]?.data).toMatchObject({
      api: "faux",
      forcedToolChoiceEffective: "required",
      toolChoiceDowngraded: false,
      reasoningMechanism: "unknown"
    });
    expect(telemetry.events.filter((event) => event.message === "tool_choice_downgraded")).toHaveLength(0);
  });

  it("scopes prompt-cache session keys per worker, stable across one worker's calls", async () => {
    const scripted = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "tool-1", name: "read_range", arguments: { path: "src/a.ts", startLine: 1, endLine: 2 } }
      ]),
      assistant([
        { type: "toolCall", id: "submit-1", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ]),
      assistant([
        { type: "toolCall", id: "submit-2", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter: scripted,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-a"),
      tools: buildRepositoryToolDefinitions(fakeRepositoryTools()),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 2000 },
      telemetryContext: { workerId: "w7-001", packetId: "packet-a" }
    });
    await runner.runStructured({
      ...submitReviewRequest("packet-b"),
      telemetryContext: { workerId: "w7-002", packetId: "packet-b" }
    });

    const sessionIds = scripted.options.map((options) => options.sessionId as string);
    // Worker w7-001 made two calls (tool round + submit) sharing one key;
    // worker w7-002 gets a different key.
    expect(sessionIds[0]).toBe(sessionIds[1]);
    expect(sessionIds[0]).toContain("stage-7-w7-001");
    expect(sessionIds[2]).toContain("stage-7-w7-002");
    expect(sessionIds[2]).not.toBe(sessionIds[0]);
  });

  it("records ttfb and rate-limit headers from the provider response", async () => {
    const telemetry = fakeTelemetry();
    const scripted = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "submit-1", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ])
    ]);
    const baseComplete = scripted.complete;
    const adapter: typeof scripted = {
      ...scripted,
      complete: vi.fn(async (model, context, options) => {
        const onResponse = (options as { onResponse?: (response: { status: number; headers: Record<string, string> }) => void }).onResponse;
        onResponse?.({
          status: 200,
          headers: {
            "request-id": "req_test123",
            "anthropic-ratelimit-input-tokens-remaining": "39000",
            "anthropic-ratelimit-input-tokens-limit": "40000",
            "content-type": "application/json"
          }
        });
        return baseComplete(model, context, options);
      })
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured(submitReviewRequest("packet-headers"));

    expect(telemetry.modelCalls[0]).toMatchObject({
      ttfbMs: expect.any(Number),
      providerHttpStatus: 200,
      providerRequestId: "req_test123",
      rateLimit: {
        "anthropic-ratelimit-input-tokens-remaining": "39000",
        "anthropic-ratelimit-input-tokens-limit": "40000"
      }
    });
    expect((telemetry.modelCalls[0] as { rateLimit?: Record<string, string> }).rateLimit).not.toHaveProperty("content-type");
  });

  it("runs anthropic submit turns with real forcing and thinking off by default (plan 86 step 3)", async () => {
    const telemetry = fakeTelemetry();
    const scripted = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "submit-1", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ])
    ]);
    const adapter: typeof scripted = {
      ...scripted,
      resolveModel: () => ({ provider: "anthropic", id: "fake-opus", raw: { id: "fake-opus", api: "anthropic-messages" } })
    };
    const runner = createPiRunner({
      llmConfig: { provider: "anthropic", model: "fake-opus", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured(submitReviewRequest("packet-anthropic-protocol"));

    expect(telemetry.modelCalls[0]).toMatchObject({
      toolChoiceRequested: "forced:submit_review",
      toolChoiceEffective: "forced:submit_review",
      toolChoiceDowngraded: false,
      // The forced-submit call runs with thinking disabled, so no reasoning
      // mechanism is in play for this call.
      reasoningMechanism: "none"
    });
    expect(telemetry.events.filter((event) => event.message === "tool_choice_downgraded")).toHaveLength(0);
    const protocolEvent = telemetry.events.find((event) => event.message === "provider_protocol");
    expect(protocolEvent?.data).toMatchObject({
      forceSubmitToolChoice: true,
      forcedToolChoiceEffective: "forced:submit_review",
      toolChoiceDowngraded: false
    });
  });

  it("surfaces the anthropic downgrade when forceSubmitToolChoice is disabled", async () => {
    const telemetry = fakeTelemetry();
    const scripted = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "submit-1", name: "submit_review", arguments: { findings: [], followUpHints: [], uncertainties: [] } }
      ])
    ]);
    const adapter: typeof scripted = {
      ...scripted,
      resolveModel: () => ({ provider: "anthropic", id: "fake-opus", raw: { id: "fake-opus", api: "anthropic-messages" } })
    };
    const runner = createPiRunner({
      llmConfig: { provider: "anthropic", model: "fake-opus", maxConcurrentCalls: 1, forceSubmitToolChoice: false },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured(submitReviewRequest("packet-anthropic-downgrade"));

    expect(telemetry.modelCalls[0]).toMatchObject({
      toolChoiceRequested: "forced:submit_review",
      toolChoiceEffective: "auto",
      toolChoiceDowngraded: true,
      reasoningMechanism: "adaptive-effort"
    });
    const downgraded = telemetry.events.filter((event) => event.message === "tool_choice_downgraded");
    expect(downgraded).toHaveLength(1);
    expect(downgraded[0]?.level).toBe("warn");
  });

  it("enforces maxConcurrentCalls across provider misses", async () => {
    const telemetry = fakeTelemetry();
    let active = 0;
    let maxActive = 0;
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        active += 1;
        maxActive = Math.max(maxActive, active);
        await delay(25);
        active -= 1;
        return assistant([validSubmitReviewCall("submit-concurrent")]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await Promise.all([
      runner.runStructured(submitReviewRequest("one")),
      runner.runStructured(submitReviewRequest("two")),
      runner.runStructured(submitReviewRequest("three"))
    ]);

    expect(maxActive).toBe(1);
  });

  it("passes stage-scoped Pi prompt cache hints and records debug visibility", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([validSubmitReviewCall("submit-cache-hint-review")]),
      assistant([validSubmitVerdictCall("submit-cache-hint-verdict")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 2 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured(submitReviewRequest("cache-hint-review"));
    await runner.runStructured({
      stage: 9,
      prompt: "verify cache hint",
      schema: SubmitVerificationVerdictSchema,
      templateVersion: "test-template",
      timeoutMs: 1000
    });

    expect(adapter.options).toEqual([
      expect.objectContaining({
        sessionId: "codegenie-phase4-llm-stage-7",
        cacheRetention: "short"
      }),
      expect.objectContaining({
        sessionId: "codegenie-phase4-llm-stage-9",
        cacheRetention: "short"
      })
    ]);
    const strategyEvents = telemetry.events.filter((event) => event.message === "provider_prompt_cache_strategy");
    expect(strategyEvents).toHaveLength(2);
    expect(strategyEvents).toEqual([
      expect.objectContaining({
        stage: 7,
        data: expect.objectContaining({
          strategy: "pi-session",
          sessionId: "codegenie-phase4-llm-stage-7",
          cacheRetention: "short",
          scope: "run-stage",
          explicitCacheBlocks: false,
          sessionIdHash: expect.any(String)
        })
      }),
      expect.objectContaining({
        stage: 9,
        data: expect.objectContaining({
          strategy: "pi-session",
          sessionId: "codegenie-phase4-llm-stage-9",
          cacheRetention: "short",
          scope: "run-stage",
          explicitCacheBlocks: false,
          sessionIdHash: expect.any(String)
        })
      })
    ]);
    expect(debugRecord(telemetry, "mc-000001.request")).toMatchObject({
      request: {
        providerPromptCache: {
          strategy: "pi-session",
          sessionId: "codegenie-phase4-llm-stage-7",
          cacheRetention: "short",
          scope: "run-stage",
          explicitCacheBlocks: false
        }
      }
    });
  });

  it("reuses identical deterministic repository tool results within one runner", async () => {
    const telemetry = fakeTelemetry();
    const readRange = vi.fn(async () => ({
      text: "cached source",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const tools: RepositoryTools = { ...fakeRepositoryTools(), readRange };
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, context) => {
        const messages = context.messages as unknown[];
        if (messages.length === 1) {
          return assistant([
            {
              type: "toolCall",
              id: "read-cache",
              name: "read_range",
              arguments: { path: "src/a.ts", startLine: 1, endLine: 3 }
            }
          ]);
        }
        return assistant([validSubmitReviewCall(`submit-${messages.length}`)]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 2 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      toolResultCache: createToolResultCache(),
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const request = {
      ...submitReviewRequest("packet-cache"),
      tools: buildRepositoryToolDefinitions(tools),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 1000 }
    };

    await runner.runStructured(request);
    await runner.runStructured(request);

    expect(readRange).toHaveBeenCalledTimes(1);
    expect(telemetry.toolCalls).toHaveLength(2);
    expect(telemetry.toolCalls.map((call) => call.cacheStatus)).toEqual(["write", "hit"]);
    expect(telemetry.toolCalls.map((call) => call.backendExecuted)).toEqual([true, false]);
    expect(telemetry.toolCalls[1]?.cacheHitKind).toBe("stored");
  });

  it("coalesces concurrent identical repository tool requests in flight", async () => {
    const telemetry = fakeTelemetry();
    const readRange = vi.fn(async () => {
      await delay(50);
      return {
        text: "shared source",
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      };
    });
    const tools: RepositoryTools = { ...fakeRepositoryTools(), readRange };
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, context) => {
        const messages = context.messages as unknown[];
        if (messages.length === 1) {
          return assistant([
            {
              type: "toolCall",
              id: "read-inflight",
              name: "read_range",
              arguments: { path: "src/a.ts", startLine: 1, endLine: 3 }
            }
          ]);
        }
        return assistant([validSubmitReviewCall(`submit-${messages.length}`)]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 4 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      toolResultCache: createToolResultCache(),
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const request = {
      ...submitReviewRequest("packet-inflight"),
      tools: buildRepositoryToolDefinitions(tools),
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 1000 }
    };

    await Promise.all([runner.runStructured(request), runner.runStructured(request)]);

    expect(readRange).toHaveBeenCalledTimes(1);
    expect(telemetry.toolCalls).toHaveLength(2);
    expect(telemetry.toolCalls.map((call) => call.cacheStatus).sort()).toEqual(["hit", "write"]);
    expect(telemetry.toolCalls.filter((call) => call.backendExecuted === true)).toHaveLength(1);
    expect(telemetry.toolCalls.some((call) => call.cacheHitKind === "inflight")).toBe(true);
  });

  it("lets an in-flight cache waiter honor its own timeout", async () => {
    const telemetry = fakeTelemetry();
    const readRange = vi.fn(async () => {
      await delay(80);
      return {
        text: "slow shared source",
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      };
    });
    const tools: RepositoryTools = { ...fakeRepositoryTools(), readRange };
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, context) => {
        const messages = context.messages as unknown[];
        if (messages.length === 1) {
          return assistant([
            {
              type: "toolCall",
              id: "read-inflight-timeout",
              name: "read_range",
              arguments: { path: "src/a.ts", startLine: 1, endLine: 3 }
            }
          ]);
        }
        return assistant([validSubmitReviewCall(`submit-${messages.length}`)]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 4 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      toolResultCache: createToolResultCache(),
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const request = {
      ...submitReviewRequest("packet-inflight-timeout"),
      tools: buildRepositoryToolDefinitions(tools),
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 1000 },
      timeoutMs: 250
    };
    const first = runner.runStructured(request);
    await delay(5);
    const second = runner.runStructured({ ...request, timeoutMs: 20 });

    await expect(second).rejects.toMatchObject({
      code: "llm_call_failed",
      context: { reason: "timeout" }
    });
    await expect(first).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });

    expect(readRange).toHaveBeenCalledTimes(1);
    expect(telemetry.toolCalls).toHaveLength(1);
    expect(telemetry.toolCalls[0]).toMatchObject({
      cacheStatus: "write",
      backendExecuted: true
    });
  });

  it("does not cache repository tool errors", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "tool error: invalid_args: bad range",
      isError: true,
      errorCode: "invalid_args" as const,
      meta: { backend: "text" as const, precision: "text" as const, degraded: true, degradationReason: "invalid_args" }
    }));
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read range",
      parameters: Type.Object({ path: Type.String({ minLength: 1 }) }, { additionalProperties: false }),
      execute
    };
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, context) => {
        const messages = context.messages as unknown[];
        if (messages.length === 1) {
          return assistant([{ type: "toolCall", id: "read-error", name: "read_range", arguments: { path: "src/a.ts" } }]);
        }
        return assistant([validSubmitReviewCall(`submit-${messages.length}`)]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 2 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      toolResultCache: createToolResultCache(),
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const request = {
      ...submitReviewRequest("packet-error-cache"),
      tools: [tool],
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 1000 }
    };

    await runner.runStructured(request);
    await runner.runStructured(request);

    expect(execute).toHaveBeenCalledTimes(2);
    expect(telemetry.toolCalls.map((call) => call.status)).toEqual(["error", "error"]);
    expect(telemetry.toolCalls.map((call) => call.cacheStatus)).toEqual(["miss", "miss"]);
    expect(telemetry.toolCalls.map((call) => call.backendExecuted)).toEqual([true, true]);
  });

  it("keeps different repository tool arguments in separate cache entries", async () => {
    const telemetry = fakeTelemetry();
    const readRange = vi.fn(async (_path: string, startLine: number) => ({
      text: `source from ${startLine}`,
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const tools: RepositoryTools = { ...fakeRepositoryTools(), readRange };
    const requestedStarts = [1, 2];
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, context) => {
        const messages = context.messages as unknown[];
        if (messages.length === 1) {
          const startLine = requestedStarts.shift() ?? 1;
          return assistant([
            {
              type: "toolCall",
              id: `read-${startLine}`,
              name: "read_range",
              arguments: { path: "src/a.ts", startLine, endLine: startLine + 1 }
            }
          ]);
        }
        return assistant([validSubmitReviewCall(`submit-${messages.length}`)]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 2 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      toolResultCache: createToolResultCache(),
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const request = {
      ...submitReviewRequest("packet-cache-args"),
      tools: buildRepositoryToolDefinitions(tools),
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 1000 }
    };

    await runner.runStructured(request);
    await runner.runStructured(request);

    expect(readRange).toHaveBeenCalledTimes(2);
    expect(readRange.mock.calls.map((call) => call[1])).toEqual([1, 2]);
    expect(telemetry.toolCalls.map((call) => call.cacheStatus)).toEqual(["write", "write"]);
  });

  it.each(["metadata", "side", "empty", "alias", "run81-note"])("locally corrects run-80 %s in one call and replays raw cached arguments", async kind => {
    const telemetry = fakeTelemetry();
    const call = kind === "alias" ? validSubmitVerdictCall("local") : validCandidateSubmitReviewCall("local");
    const expected = structuredClone(call.arguments);
    if (kind === "alias") {
      call.arguments.falsePositivesRisk = call.arguments.falsePositiveRisk;
      delete call.arguments.falsePositiveRisk;
    } else {
      const finding = (call.arguments.findings as Record<string, unknown>[])[0]!;
      const expectedFinding = (expected.findings as Record<string, unknown>[])[0]!;
      finding.anchor = expectedFinding.anchor = { path: "src/a.ts", line: 1, side: "RIGHT", hunkId: "h1" };
      Object.assign(finding.evidence as object, kind === "metadata" ? { maxItems: 10 } : kind === "side" ? { changedCodeSide: "new" } : { changedCodeNote: kind === "run81-note" ? "The changed conversion truncates the output amount before rescaling." : "" });
    }
    const raw = structuredClone(call.arguments);
    let entry: StoredProviderResponse | undefined;
    const cache = {
      get: vi.fn(async (_key: string) => entry ? { status: "hit" as const, response: entry } : { status: "miss" as const, reason: "not_found" as const }),
      put: vi.fn(async (_key: string, response: StoredProviderResponse) => { entry = response; return { status: "write" as const }; })
    };
    const adapter = scriptedAdapter([assistant([call])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = kind === "alias" ? { stage: 9 as const, schema: SubmitVerificationVerdictSchema, prompt: "verify", templateVersion: "test", timeoutMs: 1000 } : submitReviewRequest("run80");
    await expect(runner.runStructured(request)).resolves.toEqual(expected);
    await expect(runner.runStructured(request)).resolves.toEqual(expected);
    expect(adapter.contexts).toHaveLength(1);
    expect(call.arguments).toEqual(raw);
    expect(entry?.message.content).toEqual([trustedSubmitCall(call)]);
    expect(telemetry.events.filter(event => event.message === "submit_shape_correction_accepted")).toHaveLength(2);
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_opened")).toHaveLength(0);
  });

  it.each(["flat", "nested", "full"])("merges run-85 %s repairs, keeps optional omissions, and replays raw cached updates", async form => {
    const telemetry = fakeTelemetry();
    const original: PiToolCall = { type: "toolCall", id: "run85", name: "submit_review", arguments: {
      findings: [], followUpHints: [{ question: "Does the caller rescale?", files: ["amount.go"], symbols: ["Caller"], lenses: ["lang/go"], reason: "Unresolved caller", confidence: "medium" }],
      uncertainties: [{ question: "Does truncation reach callers?", files: ["amount.go"] }],
      reviewStatus: "no_findings", noFindingReason: 'The complete original explanation includes \"collateral\" and continues after it.'
    } };
    const values = form === "flat" ? { "followUpHints.0.suggestedLenses": ["lang/go"], "uncertainties.0.symbols": ["Caller"] }
      : form === "nested" ? { followUpHints: [{ suggestedLenses: ["lang/go"] }], uncertainties: [{ symbols: ["Caller"] }] }
      : { findings: [], followUpHints: [{ ...(original.arguments.followUpHints as object[])[0], suggestedLenses: ["lang/go"] }], uncertainties: [{ ...(original.arguments.uncertainties as object[])[0], symbols: ["Caller"] }], noFindingReason: "A newer complete explanation." };
    const repaired: PiToolCall = { type: "toolCall", id: "repair", name: "submit_review", arguments: values };
    const entries = new Map<string, StoredProviderResponse>();
    const cache = { get: vi.fn(async (key: string) => entries.has(key) ? { status: "hit" as const, response: entries.get(key)! } : { status: "miss" as const, reason: "not_found" as const }),
      put: vi.fn(async (key: string, entry: StoredProviderResponse) => { entries.set(key, entry); return { status: "write" as const }; }) };
    const adapter = scriptedAdapter([assistant([original]), assistant([repaired]), assistant([original])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("run85-merge");
    const first = await runner.runStructured(request);
    expect(first).toMatchObject({ reviewStatus: "no_findings", noFindingReason: form === "full" ? "A newer complete explanation." : original.arguments.noFindingReason,
      followUpHints: [expect.objectContaining({ question: "Does the caller rescale?", suggestedLenses: ["lang/go"] })], uncertainties: [expect.objectContaining({ symbols: ["Caller"] })] });
    await expect(runner.runStructured(request)).resolves.toEqual(first);
    expect(adapter.contexts).toHaveLength(3); // Invalid primary is not cached; repair is.
    expect(entries.size).toBe(1);
    expect([...entries.values()][0]!.message.content).toEqual([trustedSubmitCall(repaired)]);
    expect(adapter.contexts[1]).toContain("Optional schema fields remain optional");
    expect(adapter.contexts[1]).not.toContain("Return the WHOLE submission");
    expect(telemetry.events.filter(event => event.message === "field_repair_accepted")).toHaveLength(2);
    expect(telemetry.events.filter(event => event.message === "recovery_content_revised")).toHaveLength(form === "full" ? 2 : 0);
  });

  it.each([{}, { "findings.0.confidence": "wrong" }, { "findings.0.confidence": "high", reviewStatus: "no_findings" }])("rejects incomplete, invalid or contradictory merged repairs before caching: %j", async values => {
    const telemetry = fakeTelemetry();
    const original = validCandidateSubmitReviewCall("original");
    delete (original.arguments.findings as Record<string, unknown>[])[0]!.confidence;
    const adapter = scriptedAdapter([assistant([original]), assistant([{ type: "toolCall", name: "submit_review", id: "patch", arguments: values }]), assistant([{ type: "toolCall", name: "submit_review", id: "patch", arguments: values }]), assistant([{ type: "toolCall", name: "submit_review", id: "patch", arguments: values }])]);
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured(submitReviewRequest("run85-invalid-merge"))).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(adapter.contexts).toHaveLength(4);
    expect(cache.put).not.toHaveBeenCalled();
    expect(telemetry.events.some(event => event.message === "field_repair_accepted" || event.message === "recovery_obligation_resolved")).toBe(false);
  });

  it("repairs a schema-valid contradictory status with a partial update and caches only the merged-valid result", async () => {
    const telemetry = fakeTelemetry();
    const original = validCandidateSubmitReviewCall("contradictory");
    original.arguments.reviewStatus = "no_findings";
    const adapter = scriptedAdapter([assistant([original]), assistant([{ type: "toolCall", id: "status-update", name: "submit_review", arguments: { reviewStatus: "findings" } }])]);
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured(submitReviewRequest("semantic-merge"))).resolves.toEqual({ ...original.arguments, reviewStatus: "findings" });
    expect(adapter.contexts[1]).toContain("review_status_findings_mismatch");
    expect(adapter.contexts).toHaveLength(2);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "recovery_content_revised", data: expect.objectContaining({ paths: ["reviewStatus"] }) }));
  });

  it.each([false, true])("reconstructs run-84 envelopes before validation, missing field repair: %s", async missing => {
    const telemetry = fakeTelemetry();
    const fixed = validCandidateSubmitReviewCall("fixed");
    const draft = structuredClone(fixed.arguments);
    if (missing) delete draft.uncertainties;
    const raw = { ...fixed, id: "raw", arguments: { findings: JSON.stringify(draft).slice('{"findings":'.length) } };
    const adapter = scriptedAdapter([assistant([raw]), assistant([fixed])]);
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured(submitReviewRequest("run84-envelope"))).resolves.toEqual(fixed.arguments);
    expect(adapter.contexts).toHaveLength(missing ? 2 : 1);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(missing ? 1 : 0);
    if (missing) {
      expect(adapter.contexts[1]).toContain("repair-field-diagnostics");
      expect(adapter.contexts[1]).toContain("uncertainties");
      expect(adapter.contexts[1]).toContain("misplaced_sibling_envelope");
    }
  });

  it("rejects duplicate-key drafts without an impossible obligation and permits a fresh worker attempt", async () => {
    const telemetry = fakeTelemetry();
    const fixed = validCandidateSubmitReviewCall("fixed");
    const raw = { ...fixed, id: "raw", arguments: { findings: '[{"failureMode":"first","failureMode":"second"}],"followUpHints":[],"uncertainties":[]}' } };
    const adapter = scriptedAdapter([assistant([raw]), assistant([raw]), assistant([raw]), assistant([raw]), assistant([fixed])]);
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("run84-unusable");
    await expect(runner.runStructured(request)).rejects.toMatchObject({ code: "llm_schema_invalid", recoverable: true });
    expect(adapter.contexts).toHaveLength(4);
    expect(cache.put).not.toHaveBeenCalled();
    await expect(runner.runStructured(request)).resolves.toEqual(fixed.arguments);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(adapter.contexts[1]).toContain("Generate a new complete submission");
    expect(adapter.contexts[4]).not.toContain("unresolved-submission");
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "recovery_unusable_submission", data: expect.objectContaining({ paths: ["findings"], preservation: "unproven" }) }));
    expect(telemetry.events.some(event => event.message === "recovery_obligation_opened" || event.message === "recovery_obligation_resolved")).toBe(false);
  });

  it("completes an explicit rejection carrying irrelevant revisions without repair", async () => {
    const candidate = { ...VERIFIER_SUBMIT_EXAMPLE.finalFinding, id: "candidate", changedLine: true,
      producedBy: { kind: "packet", stage: 7, packetId: "p", lensId: "core/code-review", skillIds: [] } } as CandidateFinding;
    const original = { verdict: "reject", reason: "An existing guard disproves the claim.", requiredEvidencePresent: false,
      falsePositiveRisk: "high", findingUpdates: { confidence: "low" }, finalFinding: { title: "irrelevant partial revision" },
      revisedAnchor: { path: "irrelevant.ts" }, proofAssessment: { status: "refuted", evidence: "guard.ts:42 rejects unauthorized requests", assumptions: [] } };
    const adapter = scriptedAdapter([assistant([{ type: "toolCall", id: "reject", name: "submit_verdict", arguments: original }])]);
    const telemetry = fakeTelemetry();
    let cached: StoredProviderResponse | undefined;
    const cache = { get: vi.fn(async () => cached ? { status: "hit" as const, response: cached } : { status: "miss" as const, reason: "not_found" as const }),
      put: vi.fn(async (_key: string, entry: StoredProviderResponse) => { cached = entry; return { status: "write" as const }; }) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request: LlmStructuredRequest<SubmitVerificationVerdict> = { stage: 9, schema: SubmitVerificationVerdictSchema,
      normalizeSubmit: canonicalizeVerifierRejection,
      prompt: "verify rejection", templateVersion: "test", timeoutMs: 1000,
      validateSubmit(value) { try { expandVerifierRevision(candidate, value); return { ok: true }; }
        catch (error) { return { ok: false, classification: "invalid_tool_arguments", details: String(error) }; } }
    };
    const result = await runner.runStructured(request);
    expect(await runner.runStructured(request)).toEqual(result);
    expect(telemetry.modelCalls.at(-1)?.cacheStatus).toBe("hit");
    const { findingUpdates, finalFinding, revisedAnchor, ...expected } = original;
    expect(result).toEqual(expected);
    expect(original.findingUpdates).toEqual({ confidence: "low" });
    expect(adapter.contexts).toHaveLength(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "submit_semantic_canonicalization_accepted",
      data: expect.objectContaining({ removedFields: ["findingUpdates", "finalFinding", "revisedAnchor"], reason: "reject_revision_fields_inapplicable" }) }));
  });

  it("does not invoke rejection normalization on untrusted final arguments", async () => {
    const normalize = vi.fn(canonicalizeVerifierRejection);
    const adapter = scriptedAdapter([assistant([invalidSubmitCall("partial", "submit_verdict", { state: "partial", errorKind: "unexpected_end" })]),
      assistant([validSubmitVerdictCall("complete")])]);
    const telemetry = fakeTelemetry();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured({ stage: 9, schema: SubmitVerificationVerdictSchema,
      prompt: "verify", templateVersion: "test", timeoutMs: 1000, normalizeSubmit: normalize })).resolves.toHaveProperty("verdict");
    expect(adapter.contexts).toHaveLength(2);
    expect(telemetry.modelCalls[0]?.schemaValid).toBe(false);
    expect(normalize.mock.calls.every(([value]) => value && typeof value === "object" && "verdict" in value)).toBe(true);
    expect(telemetry.events.some(event => event.message === "submit_semantic_canonicalization_accepted")).toBe(false);
  });

  it.each(["omitted", "reject", "keep"] as const)("canonicalizes only the effective repaired rejection: %s", async branch => {
    const full = VERIFIER_SUBMIT_EXAMPLE.finalFinding;
    const candidate = { ...full, id: "candidate", changedLine: true,
      producedBy: { kind: "packet", stage: 7, packetId: "p", lensId: "core/code-review", skillIds: [] } } as CandidateFinding;
    const original = { verdict: branch === "reject" ? "revise" : "reject", requiredEvidencePresent: false,
      falsePositiveRisk: "high", findingUpdates: { confidence: "low" },
      proofAssessment: { status: "refuted", evidence: "The complete guard rejects unauthorized requests.", assumptions: [] } };
    const patch = { reason: "Existing guard refutes the claim.", ...(branch === "omitted" ? {} : { verdict: branch }),
      ...(branch === "reject" ? { finalFinding: "inapplicable malformed revision" } : {}) };
    const submit = (args: Record<string, unknown>) => assistant([{ type: "toolCall" as const, id: "submit", name: "submit_verdict", arguments: args }]);
    const adapter = scriptedAdapter([submit(original), submit(patch), submit({ verdict: "reject" })]);
    const telemetry = fakeTelemetry();
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = await runner.runStructured<SubmitVerificationVerdict>({ stage: 9, schema: SubmitVerificationVerdictSchema,
      prompt: "repair rejection", templateVersion: "test", timeoutMs: 1000, normalizeSubmit: canonicalizeVerifierRejection,
      schemaRepair: { replacementGroups: [["finalFinding", "findingUpdates"]] },
      validateSubmit(value) {
        if (value.verdict !== "reject" && value.proofAssessment?.status !== "established") return {
          ok: false, classification: "schema_invalid", details: "A publishable verdict requires established proof; the guard refutes this claim." };
        try { expandVerifierRevision(candidate, value); return { ok: true }; }
        catch (error) { return { ok: false, classification: "invalid_tool_arguments", details: String(error) }; }
      }
    });
    expect(result).toMatchObject({ verdict: "reject", reason: patch.reason, proofAssessment: original.proofAssessment });
    expect(result).not.toHaveProperty("findingUpdates");
    expect(result).not.toHaveProperty("finalFinding");
    expect(adapter.contexts).toHaveLength(branch === "keep" ? 3 : 2);
    if (branch === "keep") expect(adapter.contexts[2]).toContain("the guard refutes this claim");
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(telemetry.events.some(event => event.message === "recovery_preservation_rejected")).toBe(false);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "recovery_obligation_resolved" }));
  });

  it.each(["duplicate", "rejected", "conflicting"])("does not transfer retained assessment support after repairing a %s draft", async kind => {
    const full = { ...VERIFIER_SUBMIT_EXAMPLE.finalFinding, suggestedFix: "Honor the original retention request." };
    const candidate = { ...full, id: "candidate", changedLine: true,
      producedBy: { kind: "packet", stage: 7, packetId: "p", lensId: "core/code-review", skillIds: [] } } as CandidateFinding;
    const original = { verdict: kind === "rejected" ? "reject" : "revise", requiredEvidencePresent: true, falsePositiveRisk: "low",
      findingUpdates: { suggestedFix: kind === "conflicting" ? "Discard the retention request." : full.suggestedFix },
      finalFinding: full,
      suggestionAssessments: { suggestedFix: { status: "supported", rationale: "Preserves the original retention minimum.",
        contractCheck: { status: "established", requirement: "Meet the original retention request." },
        evidence: [{ path: "caller.ts", lines: "5-10", whyRelevant: "Checks the requested minimum." }] } } };
    // A missing reason triggers repair. The patch changes the remedy without
    // supplying a new assessment, so the prior support must not follow it.
    const replacement = kind === "conflicting" ? full.suggestedFix : "Reduce the advertised retention below the request.";
    const patch = { verdict: "revise", reason: "Revised", findingUpdates: { suggestedFix: replacement } };
    const submit = (args: Record<string, unknown>) => assistant([{ type: "toolCall" as const, id: "submit", name: "submit_verdict", arguments: args }]);
    const adapter = scriptedAdapter([submit(original), submit(patch)]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = await runner.runStructured<SubmitVerificationVerdict>({ stage: 9, schema: SubmitVerificationVerdictSchema,
      prompt: "verify retention", templateVersion: "test", timeoutMs: 1000,
      normalizeSubmit: value => normalizeVerifierSubmission(candidate, value),
      schemaRepair: { replacementGroups: [["finalFinding", "findingUpdates"]] },
      validateSubmit(value) {
        try { expandVerifierRevision(candidate, value); return { ok: true }; }
        catch (error) { return { ok: false, classification: "invalid_tool_arguments", details: String(error) }; }
      }
    });
    const final = { ...candidate, ...expandVerifierRevision(candidate, result).finalFinding };
    const assessments = result.suggestionAssessments as CandidateFinding["suggestionAssessments"];
    expect(assessFinalSuggestions(final, assessments)?.suggestedFix?.status).toBe("unverified");
    expect(adapter.contexts).toHaveLength(2);
  });

  it("run-88 verifier repair selects a compact revision and caches only the validated result", async () => {
    const full = VERIFIER_SUBMIT_EXAMPLE.finalFinding;
    const candidate = { ...full, id: "candidate", changedLine: true,
      producedBy: { kind: "packet", stage: 7, packetId: "p", lensId: "core/code-review", skillIds: [] } } as CandidateFinding;
    const submit = (arguments_: Record<string, unknown>) => assistant([{ type: "toolCall" as const, id: "submit", name: "submit_verdict", arguments: arguments_ }]);
    const adapter = scriptedAdapter([submit({ ...VERIFIER_SUBMIT_EXAMPLE, findingUpdates: { title: "Conflicting revision" } }),
      submit({}), submit({ findingUpdates: { title: "Resolved revision" } })]);
    const telemetry = fakeTelemetry();
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = await runner.runStructured<SubmitVerificationVerdict>({
      stage: 9, schema: SubmitVerificationVerdictSchema, prompt: "verify", templateVersion: "test", timeoutMs: 1000,
      schemaRepair: { replacementGroups: [["finalFinding", "findingUpdates"]] },
      validateSubmit(value) {
        try { expandVerifierRevision(candidate, value); return { ok: true }; }
        catch (error) { return { ok: false, classification: "invalid_tool_arguments", details: String(error) }; }
      }
    });
    expect(result.finalFinding).toBeUndefined();
    expect(expandVerifierRevision(candidate, result).finalFinding?.title).toBe("Resolved revision");
    expect(adapter.contexts[1]).toContain("conflicting: title");
    expect(adapter.contexts[2]).toContain("conflicting: title");
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(adapter.contexts).toHaveLength(3);
  });

  it.each([false, true])("merges duplicate repair encodings and reports actual conflicts, conflicting=%s", async conflicting => {
    const schema = Type.Object({ findingUpdates: Type.Object({ confidence: Type.String(), severity: Type.String(), suggestedTest: Type.Optional(Type.String()) }) });
    const submit = (id: string, args: Record<string, unknown>) => assistant([{ type: "toolCall", id, name: "submit_verdict", arguments: args }]);
    const adapter = scriptedAdapter([
      submit("original", { findingUpdates: {} }),
      submit("repair", { findingUpdates: { confidence: "high", suggestedTest: "Exercise the rejected boundary." },
        "findingUpdates.confidence": conflicting ? "low" : "high", "findingUpdates.severity": "medium" }),
      ...(conflicting ? [submit("retry", { "findingUpdates.confidence": "high", "findingUpdates.severity": "medium" })] : [])
    ]);
    const telemetry = fakeTelemetry();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = await runner.runStructured<{ findingUpdates: Record<string, string> }>({ stage: 9, prompt: "Verify boundary.", schema,
      templateVersion: "repair-duplicates", timeoutMs: 1000 });
    expect(result.findingUpdates).toMatchObject({ confidence: "high", severity: "medium" });
    if (conflicting) expect(adapter.contexts[2]).toContain("Conflicting field repair representations at findingUpdates.confidence");
    else expect(result.findingUpdates.suggestedTest).toBe("Exercise the rejected boundary.");
    expect(adapter.contexts).toHaveLength(conflicting ? 3 : 2);
    const ids = new Set(telemetry.modelCalls.map(call => call.structuredRequestId));
    expect(ids.size).toBe(1);
    expect(ids.has(undefined)).toBe(false);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "structured_submission_accepted",
      data: expect.objectContaining({ structuredRequestId: [...ids][0] }) }));
  });

  it("run-88 regeneration merges into the retained draft after an unreadable worker retry", async () => {
    const complete = validCandidateSubmitReviewCall("complete");
    const incomplete = structuredClone(complete);
    delete (incomplete.arguments.findings as Record<string, unknown>[])[0]!.whyThisMatters;
    delete incomplete.arguments.uncertainties;
    const opaque = { ...complete, arguments: { findings: '[{"title":"truncated' } };
    const revised = structuredClone(complete);
    const finding = (revised.arguments.findings as Record<string, unknown>[])[0]!;
    (finding.evidence as Record<string, unknown>).changedCode = "newer complete quoted code";
    const patch = { ...complete, arguments: { uncertainties: [] } };
    const adapter = scriptedAdapter([assistant([incomplete]), assistant([patch]), assistant([patch]), assistant([patch]), assistant([opaque]), assistant([revised])]);
    const telemetry = fakeTelemetry();
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("run88-regeneration");
    await expect(runner.runStructured(request)).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(cache.put).not.toHaveBeenCalled();
    await expect(runner.runStructured(request)).resolves.toEqual(revised.arguments);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(adapter.contexts).toHaveLength(6);
    expect(new Set(telemetry.modelCalls.map(call => call.structuredRequestId)).size).toBe(1);
    expect(adapter.contexts[5]).toContain("retained-submission");
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "recovery_content_revised",
      data: expect.objectContaining({ paths: expect.arrayContaining(["findings.0.evidence.changedCode"]) }) }));
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
  });

  it("keeps a readable preservation obligation when a later repair becomes unreadable", async () => {
    const telemetry = fakeTelemetry();
    const fixed = validCandidateSubmitReviewCall("fixed");
    const incomplete = structuredClone(fixed);
    delete incomplete.arguments.uncertainties;
    const opaque = { ...fixed, arguments: { findings: '[{"title":"truncated' } };
    const adapter = scriptedAdapter([assistant([incomplete]), assistant([opaque]), assistant([opaque]), assistant([opaque]), assistant([validSubmitReviewCall("erased")]), assistant([fixed])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("retained-readable-draft");
    await expect(runner.runStructured(request)).rejects.toMatchObject({ code: "llm_schema_invalid" });
    await expect(runner.runStructured(request)).resolves.toEqual(fixed.arguments);
    expect(adapter.contexts).toHaveLength(6);
    expect(adapter.contexts[4]).toContain("unresolved-submission");
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "recovery_preservation_rejected", data: expect.objectContaining({ paths: ["findings"] }) }));
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_opened")).toHaveLength(1);
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
  });

  it.each(["findings", "no_findings"])("run-82 repair optional status %s must agree with retained findings", async status => {
    const telemetry = fakeTelemetry();
    const repaired = validCandidateSubmitReviewCall("repaired");
    repaired.arguments.reviewStatus = status;
    const original = { ...repaired, id: "original", arguments: { findings: structuredClone(repaired.arguments.findings) } };
    const cache = {
      get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async () => ({ status: "write" as const }))
    };
    const adapter = scriptedAdapter([assistant([original]), assistant([repaired]), assistant([repaired]), assistant([repaired])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = runner.runStructured(submitReviewRequest("run82"));
    if (status === "findings") {
      await expect(result).resolves.toEqual(repaired.arguments);
      expect(cache.put).toHaveBeenCalledTimes(1);
      expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
    } else {
      await expect(result).rejects.toMatchObject({ code: "llm_schema_invalid" });
      expect(cache.put).not.toHaveBeenCalled();
      expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(0);
    }
    expect(adapter.contexts).toHaveLength(status === "findings" ? 2 : 4);
    expect(repaired.arguments.findings).toEqual(original.arguments.findings);
  });

  it("focuses the existing single repair on an unfamiliar typo and retains original values", async () => {
    const telemetry = fakeTelemetry();
    const fixed = validSubmitVerdictCall("fixed");
    const original = structuredClone(fixed);
    original.arguments.falsePostiveRisk = original.arguments.falsePositiveRisk;
    delete original.arguments.falsePositiveRisk;
    original.arguments.emptyNote = "Unexpected substantive diagnostic retained for repair.";
    const adapter = scriptedAdapter([assistant([original]), assistant([fixed])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured({ stage: 9, schema: SubmitVerificationVerdictSchema, prompt: "verify", templateVersion: "test", timeoutMs: 1000 })).resolves.toEqual(fixed.arguments);
    expect(adapter.contexts).toHaveLength(2);
    for (const marker of ["repair-field-diagnostics", "retained-submission", "falsePostiveRisk", "falsePositiveRisk", "originalValue", "missing", "spelling, case", "emptyNote"]) expect(adapter.contexts[1]).toContain(marker);
    expect(adapter.contexts[1]).toContain("Unexpected substantive diagnostic retained for repair.");
    expect(adapter.contexts[1]).toContain("removedUnexpectedFields");
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
  });

  it("does not accept missing required fields after discarding extras on all repair attempts", async () => {
    const telemetry = fakeTelemetry();
    const missing = validSubmitVerdictCall("missing");
    delete missing.arguments.falsePositiveRisk;
    missing.arguments.note = "This unknown note is disposable, not a required risk value.";
    const adapter = scriptedAdapter([assistant([missing]), assistant([missing]), assistant([missing]), assistant([missing])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured({ stage: 9, schema: SubmitVerificationVerdictSchema, prompt: "verify", templateVersion: "test", timeoutMs: 1000 })).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(adapter.contexts).toHaveLength(4);
    expect(adapter.contexts[1]).toContain("falsePositiveRisk");
    expect(adapter.contexts[1]).toContain("missing");
    expect(adapter.contexts[1]).toContain("This unknown note is disposable");
    expect(telemetry.events.some(event => event.message === "recovery_obligation_resolved")).toBe(false);
  });

  it("repairs the latest reconstructed run-86 draft after an empty first attempt", async () => {
    const rich = validCandidateSubmitReviewCall("rich");
    const finding = (rich.arguments.findings as Record<string, unknown>[])[0]!;
    delete finding.whyThisMatters;
    const wrapped = { findings: JSON.stringify(rich.arguments.findings) };
    Object.assign(wrapped, Object.fromEntries(Object.entries(rich.arguments).filter(([key]) => key !== "findings")));
    const submit = (args: Record<string, unknown>) => assistant([{ type: "toolCall" as const, id: "submit", name: "submit_review", arguments: args }]);
    const adapter = scriptedAdapter([submit({}), submit({}), submit({}), submit({}), submit(wrapped), submit({ "findings.0.whyThisMatters": "Required impact explanation." })]);
    const telemetry = fakeTelemetry();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("run86-latest-draft", telemetry.recorder);
    await expect(runner.runStructured(request)).rejects.toMatchObject({ code: "llm_schema_invalid" });
    await expect(runner.runStructured(request)).resolves.toMatchObject({
      findings: [{ ...finding, whyThisMatters: "Required impact explanation." }]
    });
    expect(adapter.contexts[5]).toContain("findings.0.whyThisMatters");
    expect(adapter.contexts[5]).toContain(String(finding.title));
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_opened")).toHaveLength(1);
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
  });

  it("retains a valid repair patch when other required fields still need a worker retry", async () => {
    const rich = validCandidateSubmitReviewCall("rich");
    const finding = (rich.arguments.findings as Record<string, unknown>[])[0]!;
    delete finding.whyThisMatters;
    delete rich.arguments.uncertainties;
    const submit = (args: Record<string, unknown>) => assistant([{ type: "toolCall" as const, id: "submit", name: "submit_review", arguments: args }]);
    const adapter = scriptedAdapter([submit(rich.arguments), submit({ "findings.0.whyThisMatters": "Retained repair progress." }),
      submit({}), submit({}), submit({}), submit({ uncertainties: [] })]);
    const telemetry = fakeTelemetry();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("run86-retained-patch", telemetry.recorder);
    await expect(runner.runStructured(request)).rejects.toMatchObject({ code: "llm_schema_invalid" });
    await expect(runner.runStructured(request)).resolves.toMatchObject({
      findings: [{ ...finding, whyThisMatters: "Retained repair progress." }], uncertainties: []
    });
    expect(adapter.contexts[4]).toContain("Retained repair progress.");
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
  });

  it("carries five unresolved run-79 items across worker restart and never caches destructive repair", async () => {
    const draft = {
      reviewStatus: "no_findings", findings: [], noFindingReason: "Predicates remain recorded below.",
      followUpHints: ["zero rejection", "caller scaling", "truncation tests"].map(question => ({ question, files: ["amount.go"], symbols: [], reason: "Unresolved predicate", confidence: "medium" })),
      uncertainties: ["contract", "caller"].map(question => ({ question, files: ["amount.go"], symbols: [] }))
    };
    const fixed = { ...draft, followUpHints: draft.followUpHints.map(hint => ({ ...hint, suggestedLenses: ["core/code-review"] })) };
    const erased = { ...draft, followUpHints: [], uncertainties: [] };
    const submit = (arguments_: typeof draft | typeof fixed) => assistant([{ type: "toolCall" as const, id: "submit", name: "submit_review", arguments: arguments_ }]);
    const telemetry = fakeTelemetry();
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const adapter = scriptedAdapter([submit(draft), submit(erased), submit(erased), submit(erased), assistant([validSubmitReviewCall("other-worker")]), submit(fixed)]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
      logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = submitReviewRequest("run79-preservation", telemetry.recorder);
    await expect(runner.runStructured(request)).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(cache.put).not.toHaveBeenCalled();
    expect(telemetry.events).not.toContainEqual(expect.objectContaining({ message: "recovery_obligation_resolved" }));
    // The same packet/prompt in an independent ensemble worker is not a restart.
    await expect(runner.runStructured({ ...request, telemetryContext: { packetId: "run79-preservation", workerId: "independent" } })).resolves.toMatchObject({ findings: [] });
    await expect(runner.runStructured(request)).resolves.toEqual(fixed);
    expect(adapter.contexts[5]).toContain("previous attempt");
    expect(adapter.contexts[5]).toContain("truncation tests");
    expect(cache.put).toHaveBeenCalledTimes(2);
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_opened")).toHaveLength(1);
    expect(telemetry.events.filter(event => event.message === "recovery_obligation_resolved")).toHaveLength(1);
  });

  it.each([{ cached: false, exhaust: false }, { cached: true, exhaust: false }, { cached: false, exhaust: true }])("repairs unfinished composition with retained context ($cached / $exhaust)", async ({ cached, exhaust }) => {
    const { findings, sections, evidenceRefs } = authorizationComposition();
    const schema = composerSubmissionSchema([{ fingerprint: "auth", representative: findings[0]!, findings }]);
    const good = { summary: "Authorization regression", composedFindings: [{ findingIds: findings.map(f => f.id), sections, evidenceRefs, publication: "inline" }] };
    const original = structuredClone(good);
    original.composedFindings[0]!.sections[0]!.text = "placeholder";
    original.composedFindings[0]!.sections[1]!.text = "TODO";
    if (!cached) original.composedFindings[0]!.sections[0]!.sourceRefs.push("unknown/source");
    const updates = [original, ...(cached ? [original] : []),
      { composedFindings: [{ sections: [sections[0]] }] },
      { composedFindings: [{ sections: [{}, { text: exhaust ? "TODO" : sections[1]!.text }] }] },
      ...(exhaust ? [{ composedFindings: [{ sections: [{}, { text: "TODO" }] }] }] : [])];
    const adapter = scriptedAdapter(updates.map((arguments_, index) => assistant([{ type: "toolCall", name: "submit_composition", id: `c${index}`, arguments: arguments_ }])));
    const telemetry = fakeTelemetry();
    const entries = new Map<string, StoredProviderResponse>();
    const cache = { get: vi.fn(async (key: string) => entries.has(key) ? { status: "hit" as const, response: entries.get(key)! } : { status: "miss" as const, reason: "not_found" as const }),
      put: vi.fn(async (key: string, entry: StoredProviderResponse) => { entries.set(key, entry); return { status: "write" as const }; }) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    // Seed an older schema-valid response without the new semantic checks.
    const request = { stage: 10 as const, schema, prompt: "IMMUTABLE_AUTH_SOURCE_INVENTORY", templateVersion: "test", timeoutMs: 10000 };
    if (cached) await runner.runStructured(request);
    const result = runner.runStructured({ ...request,
      validateSubmit(value) { try { validateCompositionSubmission(value as typeof good, findings); return { ok: true }; }
        catch (error) { return { ok: false, classification: "schema_invalid", details: String(error) }; } },
      schemaRepair: { createFieldRepair: (schema, retained) => createCompositionAttributionRepair(schema, retained, findings) }
    });
    if (exhaust) {
      await expect(result).rejects.toMatchObject({ code: "llm_schema_invalid" });
      expect(cache.put).not.toHaveBeenCalled();
    } else await expect(result).resolves.toEqual(good);
    expect(adapter.contexts.at(-1)).toContain("IMMUTABLE_AUTH_SOURCE_INVENTORY");
    expect(adapter.contexts.at(-1)).toContain("composedFindings.0.sections.1.text");
    expect(telemetry.events.filter(e => e.message === "schema_repair_scheduled")).toHaveLength(exhaust ? 3 : 2);
    if (cached) expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "model_call_cache_schema_invalid_miss" }));
  });

  it("repairs missing promoted decisions and rejects an old cached anchor-only verdict", async () => {
    const candidate: CandidateFinding = { ...VERIFIER_SUBMIT_EXAMPLE.finalFinding, id: "promoted", changedLine: true,
      producedBy: { kind: "packet", stage: 7, packetId: "p", lensId: "core/code-review", skillIds: [] },
      provenance: { source: "uncertainty_promotion", sourceKind: "uncertainty", sourcePacketId: "p", files: [], symbols: [], question: "Is access revoked?", reason: "Investigate" } };
    const original = { verdict: "keep", reason: "Revised to a testing finding", requiredEvidencePresent: true, falsePositiveRisk: "low" };
    const updates = Object.fromEntries(["title", "failureMode", "whyThisMatters", "verification", "category", "severity", "confidence"].map(key => [key, candidate[key as keyof CandidateFinding]]));
    const adapter = scriptedAdapter([original, original, { findingUpdates: updates }].map((arguments_, i) =>
      assistant([{ type: "toolCall", name: "submit_verdict", id: `v${i}`, arguments: arguments_ }])));
    const telemetry = fakeTelemetry();
    const entries = new Map<string, StoredProviderResponse>();
    const cache = { get: vi.fn(async (key: string) => entries.has(key) ? { status: "hit" as const, response: entries.get(key)! } : { status: "miss" as const, reason: "not_found" as const }),
      put: vi.fn(async (key: string, entry: StoredProviderResponse) => { entries.set(key, entry); return { status: "write" as const }; }) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const request = { stage: 9 as const, schema: SubmitVerificationVerdictSchema, prompt: "verify promoted", templateVersion: "test", timeoutMs: 10000 };
    await runner.runStructured(request);
    const result = await runner.runStructured<SubmitVerificationVerdict>({ ...request,
      validateSubmit(value) { try { expandVerifierRevision(candidate, value); return { ok: true }; }
        catch (error) { return { ok: false, classification: "invalid_tool_arguments", details: String(error) }; } },
      schemaRepair: { replacementGroups: [["finalFinding", "findingUpdates"]] }
    });
    expect(expandVerifierRevision(candidate, result).finalFinding).toMatchObject(updates);
    expect(adapter.contexts.at(-1)).toContain("findingUpdates.whyThisMatters");
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "model_call_cache_schema_invalid_miss" }));
  });

  it("refreshes semantic repair targets after a sparse promoted-verdict patch without repeating retained evidence", async () => {
    const candidate: CandidateFinding = { ...VERIFIER_SUBMIT_EXAMPLE.finalFinding, id: "promoted", changedLine: true,
      producedBy: { kind: "packet", stage: 7, packetId: "p", lensId: "core/code-review", skillIds: [] },
      provenance: { source: "uncertainty_promotion", sourceKind: "uncertainty", sourcePacketId: "p", files: [], symbols: [], question: "Is access revoked?", reason: "Investigate" } };
    const findingUpdates = Object.fromEntries(["title", "failureMode", "whyThisMatters", "verification", "category"].map(key => [key, candidate[key as keyof CandidateFinding]]));
    const initial = { verdict: "revise", reason: "Confirmed", requiredEvidencePresent: true, falsePositiveRisk: "low", findingUpdates };
    const adapter = scriptedAdapter([initial, { "findingUpdates.severity": "low" }, { findingUpdates: { confidence: "high" } }].map((args, i) =>
      assistant([{ type: "toolCall", name: "submit_verdict", id: `v${i}`, arguments: args }])));
    const telemetry = fakeTelemetry();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = await runner.runStructured<SubmitVerificationVerdict>({ stage: 9, schema: SubmitVerificationVerdictSchema,
      prompt: "verify promoted", templateVersion: "test", timeoutMs: 10000,
      validateSubmit(value) { try { expandVerifierRevision(candidate, value); return { ok: true }; }
        catch (error) { return { ok: false, classification: "invalid_tool_arguments", details: String(error) }; } },
      schemaRepair: { replacementGroups: [["finalFinding", "findingUpdates"]], createFieldRepair: (schema, retained) =>
        createFieldRepair(schema, retained, true, [["finalFinding", "findingUpdates"]], promotedCompletionIssues(candidate, retained)) }
    });
    expect(expandVerifierRevision(candidate, result).finalFinding).toMatchObject({ ...findingUpdates, severity: "low", confidence: "high", evidence: candidate.evidence });
    expect(adapter.contexts).toHaveLength(3);
    expect(telemetry.events.filter(event => event.message === "field_repair_scheduled").map(event => event.data?.paths))
      .toEqual([["findingUpdates.severity", "findingUpdates.confidence"], ["findingUpdates.confidence"]]);
    expect(adapter.contexts[1]).toContain("unless stage validation conditionally requires them");
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "schema_repair_retry_scheduled",
      data: expect.objectContaining({ remainingPaths: ["findingUpdates.confidence"] }) }));
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "field_repair_accepted" }));
    expect(initial.findingUpdates).toEqual(findingUpdates);
  });

  it("records schema-invalid submits and does not cache them before repair", async () => {
    const telemetry = fakeTelemetry();
    const cache = {
      get: vi.fn(async (_key: string) => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    };
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "submit-invalid",
          name: "submit_review",
          arguments: {}
        }
      ]),
      assistant([validSubmitReviewCall("submit-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-1"))).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });

    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid", "ok"]);
    expect(telemetry.modelCalls[0]).toMatchObject({
      schemaValid: false,
      errorCode: "llm_schema_invalid"
    });
    expect(telemetry.modelCalls.map((call) => call.cacheStatus)).toEqual(["miss", "write"]);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(cache.put.mock.calls[0]?.[1].message.content).toEqual([trustedSubmitCall(validSubmitReviewCall("submit-repair"))]);
  });

  it("requires planner responses to submit exactly one plan and repairs with replacement context", async () => {
    const telemetry = fakeTelemetry();
    const cache = {
      get: vi.fn(async (_key: string) => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    };
    const adapter = scriptedAdapter([
      assistant([validSubmitPlanCall("submit-plan-a"), validSubmitPlanCall("submit-plan-b")]),
      assistant([validSubmitPlanCall("submit-plan-repaired")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const originalPromptMarker = "ORIGINAL_PLANNER_PROMPT_SHOULD_NOT_BE_RESENT";

    await expect(runner.runStructured({
      stage: 5,
      prompt: `${originalPromptMarker} ${"x".repeat(12_000)}`,
      schema: SubmitPlanSchema,
      templateVersion: "test-template",
      timeoutMs: 1000,
      schemaRepair: {
        replaceConversation: true,
        buildPrompt: (input) => {
          expect(input.submitTool).toBe("submit_plan");
          expect(input.submitCalls.map((call) => call.id)).toEqual(["submit-plan-a", "submit-plan-b"]);
          return `compact planner repair for ${input.submitCalls.map((call) => call.id).join(",")}`;
        }
      }
    })).resolves.toMatchObject({
      diffUnderstanding: { declaredIntent: "test", inferredBehavior: "test" },
      coverage: []
    });

    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid", "ok"]);
    expect(telemetry.modelCalls.map((call) => call.kind)).toEqual(["initial", "repair"]);
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 5,
        message: "planner_schema_repair_scheduled",
        data: expect.objectContaining({
          submitTool: "submit_plan",
          invalidSubmitCallCount: 2,
          repairPromptChars: expect.any(Number),
          replaceConversation: true
        })
      })
    ]));
    expect(adapter.contexts[1]).toContain("compact planner repair");
    expect(adapter.contexts[1]).not.toContain(originalPromptMarker);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(cache.put.mock.calls[0]?.[1].message.content).toEqual([trustedSubmitCall(validSubmitPlanCall("submit-plan-repaired"))]);
  });

  it("repairs planner responses that omit submit_plan without generic finalization nudges", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "text", text: "plain planning text" }]),
      assistant([validSubmitPlanCall("submit-plan-after-missing")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured({
      stage: 5,
      prompt: "planner",
      schema: SubmitPlanSchema,
      templateVersion: "test-template",
      timeoutMs: 1000,
      schemaRepair: {
        replaceConversation: true,
        buildPrompt: (input) => {
          expect(input.submitCalls).toEqual([]);
          return "compact missing-submit repair";
        }
      }
    })).resolves.toMatchObject({
      diffUnderstanding: { declaredIntent: "test", inferredBehavior: "test" }
    });

    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid", "ok"]);
    expect(telemetry.modelCalls.map((call) => call.kind)).toEqual(["initial", "repair"]);
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 5,
        message: "planner_schema_repair_scheduled",
        data: expect.objectContaining({ invalidSubmitCallCount: 0 })
      })
    ]));
  });

  it.each([true, false])("uses the lowest supported non-off effort for repairs (%s)", async (supportsLow) => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([validSubmitPlanCall("a"), validSubmitPlanCall("b")]),
      assistant([validSubmitPlanCall("fixed")])
    ]);
    adapter.resolveModel = () => ({ provider: "fake", id: "fake-model", raw: {
      id: "fake-model", api: "openai-completions", reasoning: true,
      thinkingLevelMap: supportsLow ? { minimal: null } : { low: null }
    } });
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await runner.runStructured({ stage: 5, prompt: "planner", schema: SubmitPlanSchema, templateVersion: "test", timeoutMs: 600_000 });
    expect(adapter.options.map((options) => options.reasoning)).toEqual(["high", supportsLow ? "low" : "minimal"]);
    expect(telemetry.modelCalls.map((call) => call.reasoningRequested)).toEqual(["high", supportsLow ? "low" : "minimal"]);
    expect(adapter.complete).toHaveBeenCalledTimes(2);
  });

  it.each([false, true])("applies composition step-down to retries but keeps repair policy (enabled=%s)", async enabled => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "invalid", name: "submit_composition", arguments: {} }]),
      assistant([{ type: "toolCall", id: "fixed", name: "submit_composition", arguments: { summary: "Done", composedFindings: [] } }])
    ]);
    adapter.resolveModel = () => ({ provider: "fake", id: "fake-model", raw: {
      id: "fake-model", api: "openai-completions", reasoning: true,
      thinkingLevelMap: { minimal: null, medium: null, xhigh: null, max: "max" }
    } });
    const complete = adapter.complete;
    let first = true;
    adapter.complete = vi.fn(async (...args: Parameters<PiAiAdapter["complete"]>) => {
      if (first) {
        first = false;
        throw Object.assign(new Error("service unavailable"), { status: 503 });
      }
      return complete(...args);
    });
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "max", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await runner.runStructured({ stage: 10, compositionReasoningStepDown: enabled,
      prompt: "compose", schema: SubmitCompositionSchema, templateVersion: "test", timeoutMs: 600_000 });
    const expected = enabled ? "high" : "max";
    expect(vi.mocked(adapter.complete).mock.calls.map(call => call[2].reasoning)).toEqual([expected, expected, "low"]);
    expect(telemetry.modelCalls.map(call => call.reasoningSelected)).toEqual([expected, expected, "low"]);
    expect(telemetry.modelCalls.map(call => call.reasoningPolicy)).toEqual([
      enabled ? "one_level_lower" : "configured", enabled ? "one_level_lower" : "configured", "lowest_supported"
    ]);
    expect(debugRecord(telemetry, "mc-000001.request")).toMatchObject({
      provider: { reasoningConfigured: "max", reasoning: expected }
    });
  });

  it("keeps verification at configured effort even when composition step-down is requested", async () => {
    const adapter = scriptedAdapter([assistant([validSubmitVerdictCall("verdict")])]);
    adapter.resolveModel = () => ({ provider: "fake", id: "fake-model", raw: {
      id: "fake-model", api: "openai-completions", reasoning: true, thinkingLevelMap: { max: "max" }
    } });
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "max", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await runner.runStructured({ stage: 9, compositionReasoningStepDown: true,
      prompt: "verify", schema: SubmitVerificationVerdictSchema, templateVersion: "test", timeoutMs: 600_000 });
    expect(adapter.options[0]?.reasoning).toBe("max");
  });

  it("retains omitted composition sources locally, with full validation and no model repair", async () => {
    const telemetry = fakeTelemetry();
    const { findings, sections, evidenceRefs, presentation } = authorizationComposition();
    const omitted = sections[0]!.sourceRefs.pop()!;
    const original = { summary: "Verified issue", composedFindings: [{ findingIds: findings.map(f => f.id), sections, evidenceRefs, retainedSourceRefs: [] as string[], ...presentation, publication: "inline" }] };
    const adapter = scriptedAdapter([assistant([{ type: "toolCall", id: "compose", name: "submit_composition", arguments: original }])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = await runner.runStructured({ stage: 10, prompt: "compose", templateVersion: "test", timeoutMs: 600_000,
      schema: composerSubmissionSchema([{ fingerprint: "test", representative: findings[0]!, findings }]),
      normalizeSubmit: value => normalizeCompositionReferences(value, findings),
      validateSubmit: value => {
        try { validateCompositionSubmission(value as typeof original, findings); return { ok: true }; }
        catch (error) { return { ok: false, classification: "schema_invalid", details: String(error) }; }
      }
    }) as typeof original;
    expect(result.composedFindings[0]!.retainedSourceRefs).toContain(omitted);
    expect(result.composedFindings[0]!.sections).toEqual(sections);
    expect(adapter.complete).toHaveBeenCalledOnce();
    expect(telemetry.events.some(event => event.message === "schema_repair_scheduled")).toBe(false);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "submit_semantic_canonicalization_accepted",
      data: expect.objectContaining({ addedFields: [expect.stringContaining("retainedSourceRefs")], validation: "complete_schema_and_semantics_passed" }) }));
  });

  it.each([false, true])("repairs attribution in fresh constrained contexts and validates the assembled report (exhaust=%s)", async exhaust => {
    const telemetry = fakeTelemetry();
    const { findings, sections, evidenceRefs, presentation } = authorizationComposition();
    const good = { summary: "Verified issue", composedFindings: [{ findingIds: findings.map(f => f.id), sections, evidenceRefs, ...presentation, publication: "inline" }] };
    const original = structuredClone(good);
    const fixIndex = sections.findIndex(section => section.kind === "fix");
    const testIndex = sections.findIndex(section => section.kind === "test");
    original.composedFindings[0]!.sections[fixIndex]!.sourceRefs.push("invented/fix");
    original.composedFindings[0]!.sections[testIndex]!.sourceRefs.push("invented/test");
    const fixPath = `composedFindings.0.sections.${fixIndex}.sourceRefs`;
    const testPath = `composedFindings.0.sections.${testIndex}.sourceRefs`;
    const adapter = scriptedAdapter([]);
    let calls = 0;
    adapter.complete = vi.fn(async (_model, context) => {
      calls++;
      let arguments_: Record<string, unknown> = original;
      if (calls > 1) {
        expect(context.messages).toHaveLength(1);
        const prompt = JSON.stringify(context.messages);
        expect(prompt).toContain("attribution-repair-context");
        expect(prompt).not.toContain("original-composition-marker");
        expect(prompt).toContain("unknown_source");
        if (calls > 2) expect(Object.keys(context.tools![0]!.parameters.properties ?? {})).not.toContain(fixPath);
        arguments_ = calls === 2 ? { [fixPath]: sections[fixIndex]!.sourceRefs } : { [testPath]: exhaust ? ["invented/test"] : sections[testIndex]!.sourceRefs };
      }
      return assistant([{ type: "toolCall", id: `c${calls}`, name: "submit_composition", arguments: arguments_ }]);
    });
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const schema = composerSubmissionSchema([{ fingerprint: "test", representative: findings[0]!, findings }]);
    const result = runner.runStructured({ stage: 10, prompt: "original-composition-marker", schema, templateVersion: "test", timeoutMs: 600_000,
      normalizeSubmit: value => normalizeCompositionReferences(value, findings),
      validateSubmit: value => {
        try { validateCompositionSubmission(value as typeof good, findings); return { ok: true }; }
        catch (error) { return { ok: false, classification: "schema_invalid", details: String(error) }; }
      },
      schemaRepair: { createFieldRepair: (schema, retained) => createCompositionAttributionRepair(schema, retained, findings) }
    });
    if (exhaust) await expect(result).rejects.toMatchObject({ code: "llm_schema_invalid" });
    else await expect(result).resolves.toEqual(good);
    expect(calls).toBe(exhaust ? 4 : 3);
    expect(telemetry.events.filter(event => event.message === "schema_repair_scheduled")).toHaveLength(exhaust ? 3 : 2);
    expect(telemetry.events.filter(event => event.message === "schema_repair_scheduled").every(event => event.data?.replaceConversation === true)).toBe(true);
  });

  it("repairs unsupported advice atomically without restoring removed sections on retry", async () => {
    const telemetry = fakeTelemetry();
    const { findings, sections, evidenceRefs } = authorizationComposition();
    delete findings[0]!.suggestionAssessments!.suggestedFix;
    const original = { summary: "Revocation is bypassed.", composedFindings: [{ findingIds: [findings[0]!.id], sections, evidenceRefs, publication: "inline" }] };
    const fixedSections = sections.filter(section => section.kind !== "fix");
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "original", name: "submit_composition", arguments: original }]),
      assistant([{ type: "toolCall", id: "incomplete", name: "submit_composition", arguments: {
        "composedFindings.0.sections": fixedSections, "composedFindings.0.retainedSourceRefs": []
      } }]),
      assistant([{ type: "toolCall", id: "fixed", name: "submit_composition", arguments: {
        "composedFindings.0.sections": fixedSections, "composedFindings.0.retainedSourceRefs": ["authorization/suggestedFix"]
      } }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const schema = composerSubmissionSchema([{ fingerprint: "test", representative: findings[0]!, findings }]);
    const result = await runner.runStructured<typeof original>({ stage: 10, prompt: "composition", schema, templateVersion: "test", timeoutMs: 600_000,
      normalizeSubmit: value => normalizeCompositionReferences(value, findings),
      validateSubmit: value => {
        try { validateCompositionSubmission(value, findings); return { ok: true }; }
        catch (error) { return { ok: false, classification: "schema_invalid", details: String(error) }; }
      },
      schemaRepair: { createFieldRepair: (schema, retained) => createCompositionAttributionRepair(schema, retained, findings) }
    });
    expect(result.composedFindings[0]!.sections).toEqual(fixedSections);
    expect(result.composedFindings[0]).toHaveProperty("retainedSourceRefs", ["authorization/suggestedFix"]);
    const repairTool = vi.mocked(adapter.complete).mock.calls[1]![1].tools![0]!;
    expect(repairTool.description).toContain("Supplied values update only the permitted fields");
    expect(repairTool.description).not.toContain("Supplied reference lists");
    expect(repairTool.parameters).toMatchObject({ properties: { "composedFindings.0.sections": expect.anything() } });
    expect(adapter.complete).toHaveBeenCalledTimes(3);
    expect(telemetry.events.filter(event => event.message === "field_repair_accepted")).toHaveLength(1);
    expect(telemetry.events.filter(event => event.message === "recovery_content_revised")).not.toHaveLength(0);
  });

  it.each(["timeout", "double-timeout", "repair-timeout", "transient", "invalid", "retry-invalid", "auth", "cancel"] as const)(
    "bounds composition recovery with configured reasoning: %s", async (mode) => {
      vi.useFakeTimers();
      try {
        const telemetry = fakeTelemetry();
        const abort = new AbortController();
        const valid = assistant([{ type: "toolCall", id: "composition", name: "submit_composition",
          arguments: { summary: "Done", composedFindings: [] } }]);
        const invalid = assistant([{ type: "toolCall", id: "invalid", name: "submit_composition",
          arguments: {} }]);
        const adapter = scriptedAdapter([]);
        adapter.resolveModel = () => ({ provider: "fake", id: "fake-model", raw: {
          id: "fake-model", api: "openai-completions", reasoning: true, thinkingLevelMap: { max: "max" }
        } });
        const efforts: unknown[] = [];
        let calls = 0;
        const signals: AbortSignal[] = [];
        adapter.complete = vi.fn(async (_model, _context, options) => {
          if (mode === "double-timeout") {
            signals.push(options.signal!);
            const pulse = () => (options.onStreamEvent as ((event: unknown) => void) | undefined)?.({ type: "thinking_delta", delta: "still reasoning" });
            pulse();
            const interval = setInterval(pulse, 10_000);
            options.signal!.addEventListener("abort", () => clearInterval(interval), { once: true });
          }
          efforts.push(options.reasoning);
          calls++;
          if (calls === 1) {
            if (mode === "timeout" || mode === "double-timeout" || mode === "cancel") return new Promise<PiAssistantMessage>(() => {});
            if (mode === "auth") throw Object.assign(new Error("unauthorized"), { status: 401 });
            if (mode === "transient" || mode === "retry-invalid") throw Object.assign(new Error("service unavailable"), { status: 503 });
            return invalid;
          }
          if (mode === "double-timeout" || mode === "repair-timeout") return new Promise<PiAssistantMessage>(() => {});
          return mode === "retry-invalid" ? invalid : valid;
        });
        const runner = createPiRunner({
          llmConfig: { provider: "fake", model: "fake-model", reasoning: "max", maxConcurrentCalls: 1 },
          telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: abort.signal,
          adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
        });
        const result = runner.runStructured({ stage: 10, prompt: "compose", schema: SubmitCompositionSchema,
          templateVersion: "test", timeoutMs: 600_000 });
        const fails = ["retry-invalid", "auth", "cancel", "double-timeout", "repair-timeout"].includes(mode);
        const checked = fails ? expect(result).rejects.toBeInstanceOf(CodegenieError)
          : expect(result).resolves.toMatchObject({ summary: "Done" });
        await vi.advanceTimersByTimeAsync(0);
        if (mode === "cancel") abort.abort();
        if (mode === "timeout") await vi.advanceTimersByTimeAsync(300_000);
        if (mode === "repair-timeout") await vi.advanceTimersByTimeAsync(180_000);
        if (mode === "double-timeout") await vi.advanceTimersByTimeAsync(600_000);
        await checked;
        expect(calls).toBe(mode === "auth" || mode === "cancel" ? 1 : mode === "retry-invalid" ? 5 : 2);
        if (mode === "retry-invalid") expect(efforts).toEqual(["max", "max", "minimal", "minimal", "minimal"]);
        if (mode === "double-timeout") {
          expect(signals).toHaveLength(2);
          expect(signals.every(signal => signal.aborted)).toBe(true);
          expect(telemetry.modelCalls).toHaveLength(2);
          for (const call of telemetry.modelCalls) {
            expect(call).toMatchObject({ status: "timeout", streamProgress: { toolArgumentChars: 0 } });
            expect(call.streamProgress!.thinkingChars).toBeGreaterThan(0);
            expect(call.costUSD).toBeUndefined();
          }
        }
        expect(efforts[0]).toBe("max");
        if (calls === 2) expect(efforts[1]).toBe(
          mode === "invalid" || mode === "repair-timeout" ? "minimal" : "max"
        );
        expect(telemetry.modelCalls[0]).toMatchObject({
          reasoningConfigured: "max", reasoningSelected: "max", reasoningPolicy: "configured"
        });
      } finally {
        vi.useRealTimers();
      }
    }
  );

  it.each(["success", "timeout", "cancel"] as const)("reserves repair time after a late composition retry: %s", async mode => {
    vi.useFakeTimers();
    try {
      const telemetry = fakeTelemetry();
      const abort = new AbortController();
      const adapter = scriptedAdapter([]);
      const signals: AbortSignal[] = [];
      adapter.complete = vi.fn(async (_model, _context, options) => {
        signals.push(options.signal!);
        if (signals.length === 1) return new Promise<PiAssistantMessage>(() => {});
        if (signals.length === 2) {
          await new Promise(resolve => setTimeout(resolve, 299_000));
          return assistant([{ type: "toolCall", id: "invalid", name: "submit_composition", arguments: {} }]);
        }
        if (mode !== "success") return new Promise<PiAssistantMessage>(() => {});
        await new Promise(resolve => setTimeout(resolve, 179_000));
        return assistant([{ type: "toolCall", id: "repaired", name: "submit_composition", arguments: { summary: "Done", composedFindings: [] } }]);
      });
      const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: abort.signal, adapter,
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
      const result = runner.runStructured({ stage: 10, prompt: "compose", schema: SubmitCompositionSchema,
        templateVersion: "test", timeoutMs: 600_000 });
      const checked = mode === "success" ? expect(result).resolves.toMatchObject({ summary: "Done" })
        : expect(result).rejects.toBeInstanceOf(CodegenieError);
      await vi.advanceTimersByTimeAsync(299_999);
      expect(signals).toHaveLength(1);
      expect(signals[0]!.aborted).toBe(false);
      await vi.advanceTimersByTimeAsync(1);
      expect(signals[0]!.aborted).toBe(true);
      expect(signals).toHaveLength(2);
      await vi.advanceTimersByTimeAsync(299_000);
      expect(signals).toHaveLength(3);
      // The former 600-second outer limit must not cut off this repair.
      await vi.advanceTimersByTimeAsync(1_001);
      expect(signals[2]!.aborted).toBe(false);
      if (mode === "cancel") abort.abort();
      else await vi.advanceTimersByTimeAsync(mode === "success" ? 177_999 : 178_999);
      await checked;
      expect(signals).toHaveLength(3);
      expect(telemetry.modelCalls.at(-1)).toMatchObject({ kind: "repair", status: mode === "success" ? "ok" : mode === "timeout" ? "timeout" : "aborted" });
      if (mode === "timeout") expect(telemetry.modelCalls.at(-1)?.durationMs).toBe(180_000);
    } finally { vi.useRealTimers(); }
  });

  it.each(["valid", "invalid", "missing", "transient", "timeout"] as const)("uses one lowest-reasoning attempt for location clarification: %s", async (mode) => {
    vi.useFakeTimers();
    try {
      const telemetry = fakeTelemetry();
      const adapter = scriptedAdapter([]);
      adapter.resolveModel = () => ({ provider: "fake", id: "fake-model", raw: {
        id: "fake-model", api: "openai-completions", reasoning: true, thinkingLevelMap: { max: "max" }
      } });
      const efforts: unknown[] = [];
      adapter.complete = vi.fn(async (_model, _context, options) => {
        efforts.push(options.reasoning);
        if (mode === "timeout") return new Promise<PiAssistantMessage>(() => {});
        if (mode === "transient") throw Object.assign(new Error("unavailable"), { status: 503 });
        return assistant(mode === "missing" ? [] : [{ type: "toolCall", id: "location", name: "submit_review", arguments: mode === "invalid" ? {} : { status: "unavailable" } }]);
      });
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", reasoning: "max", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
        adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      const result = runner.runStructured({ stage: 7, purpose: "location_clarification", prompt: "locate",
        schema: Type.Object({ status: Type.Literal("unavailable") }, { additionalProperties: false }), templateVersion: "test-location", timeoutMs: 180_000 });
      const checked = mode === "valid" ? expect(result).resolves.toEqual({ status: "unavailable" }) : expect(result).rejects.toBeInstanceOf(CodegenieError);
      await vi.advanceTimersByTimeAsync(mode === "timeout" ? 180_000 : 0);
      await checked;
      expect(adapter.complete).toHaveBeenCalledTimes(1);
      expect(efforts).toEqual(["minimal"]);
      expect(telemetry.events.some((event) => event.message === "recovery_obligation_opened")).toBe(false);
    } finally { vi.useRealTimers(); }
  });

  it.each([false, true])("gives repair a fresh allowance while respecting cancellation (%s)", async (cancel) => {
    vi.useFakeTimers();
    try {
      const telemetry = fakeTelemetry();
      const abort = new AbortController();
      const adapter = scriptedAdapter([]);
      let calls = 0;
      adapter.complete = vi.fn(async () => {
        calls++;
        await new Promise((resolve) => setTimeout(resolve, calls === 1 ? 1900 : 500));
        return calls === 1
          ? assistant([validSubmitPlanCall("a"), validSubmitPlanCall("b")])
          : assistant([validSubmitPlanCall("fixed")]);
      });
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: abort.signal,
        adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      // Investigation hard deadline is 2s. Repair finishes successfully at 2.4s.
      const result = runner.runStructured({ stage: 5, prompt: "plan", schema: SubmitPlanSchema,
        templateVersion: "test", timeoutMs: 1000 });
      const checked = cancel ? expect(result).rejects.toMatchObject({ code: "llm_call_failed" })
        : expect(result).resolves.toHaveProperty("coverage");
      await vi.advanceTimersByTimeAsync(1900);
      if (cancel) abort.abort();
      await vi.advanceTimersByTimeAsync(500);
      await checked;
      expect(calls).toBe(2);
    } finally {
      vi.useRealTimers();
    }
  });

  it.each(["success", "finalize-timeout", "cancel"] as const)("hands a long investigation to bounded finalization: %s", async (mode) => {
    vi.useFakeTimers();
    try {
      const telemetry = fakeTelemetry();
      const worker = new AbortController();
      const adapter = scriptedAdapter([]);
      let calls = 0;
      let investigationSignal: AbortSignal | undefined;
      let finalContext = "";
      adapter.complete = vi.fn(async (_model, context, options) => {
        calls++;
        if (calls === 1) return assistant([{ type: "toolCall", id: "read", name: "read_range",
          arguments: { path: "src/a.ts", startLine: 1, endLine: 3 } }]);
        if (calls === 2) {
          investigationSignal = options.signal;
          return new Promise<PiAssistantMessage>(() => {});
        }
        finalContext = JSON.stringify(context.messages);
        expect((context.tools as Array<{ name: string }>).map((tool) => tool.name)).toEqual(["submit_review"]);
        if (mode === "finalize-timeout") return new Promise<PiAssistantMessage>(() => {});
        await new Promise((resolve) => setTimeout(resolve, 500));
        return assistant([validSubmitReviewCall("final")]);
      });
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
        adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      const result = runner.runStructured({ ...submitReviewRequest("handoff"), timeoutMs: 1000,
        signal: worker.signal,
        tools: buildRepositoryToolDefinitions({ ...fakeRepositoryTools(), readRange: async () => ({ text: "COMPLETED_EVIDENCE", meta: { backend: "text", precision: "exact", degraded: false } }) }),
        toolBudget: { maxToolCalls: 10, maxInvestigationRounds: 10, maxResultChars: 10000 }
      });
      const checked = mode === "success" ? expect(result).resolves.toHaveProperty("findings")
        : expect(result).rejects.toMatchObject({ code: "llm_call_failed" });
      await vi.advanceTimersByTimeAsync(mode === "cancel" ? 500 : 1000);
      if (mode === "cancel") worker.abort();
      else {
        expect(investigationSignal?.aborted).toBe(true);
        expect(finalContext).toContain("COMPLETED_EVIDENCE");
        expect(finalContext).toContain("unfinished streamed response was discarded");
        await vi.advanceTimersByTimeAsync(1000);
      }
      await checked;
      expect(calls).toBe(mode === "cancel" ? 2 : 3);
      expect(telemetry.events.filter((event) => event.message === "investigation_deadline_handoff"))
        .toHaveLength(mode === "cancel" ? 0 : 1);
    } finally { vi.useRealTimers(); }
  });

  it("propagates worker cancellation into a repair and ignores late provider results", async () => {
    vi.useFakeTimers();
    try {
      const worker = new AbortController();
      const telemetry = fakeTelemetry();
      const adapter = scriptedAdapter([assistant([validSubmitPlanCall("a"), validSubmitPlanCall("b")])]);
      const originalComplete = adapter.complete;
      let repairSignal: AbortSignal | undefined;
      let finish: ((value: PiAssistantMessage) => void) | undefined;
      adapter.complete = vi.fn(async (model, context, options) => {
        if (context.messages.length > 1) {
          repairSignal = options.signal;
          return new Promise<PiAssistantMessage>((resolve) => { finish = resolve; });
        }
        return originalComplete(model, context, options);
      });
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
        adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      const result = runner.runStructured({ stage: 5, prompt: "planner", schema: SubmitPlanSchema,
        templateVersion: "test", timeoutMs: 1000, signal: worker.signal });
      const checked = expect(result).rejects.toMatchObject({ code: "llm_call_failed" });
      await vi.advanceTimersByTimeAsync(2100);
      expect(repairSignal?.aborted).toBe(false);
      worker.abort();
      await checked;
      expect(repairSignal?.aborted).toBe(true);
      const recordedCalls = telemetry.modelCalls.length;
      const recordedEvents = telemetry.events.length;
      finish?.(assistant([validSubmitPlanCall("too-late")]));
      await vi.advanceTimersByTimeAsync(180_000);
      expect(telemetry.modelCalls).toHaveLength(recordedCalls);
      expect(telemetry.events).toHaveLength(recordedEvents);
      expect(adapter.complete).toHaveBeenCalledTimes(2);
    } finally { vi.useRealTimers(); }
  });

  it.each(["success", "no-progress", "invalid", "exhausted"] as const)("retries validation failures without a progress requirement: %s", async mode => {
    const full = validCandidateSubmitReviewCall("full");
    const original = structuredClone(full);
    const finding = (original.arguments.findings as Record<string, unknown>[])[0]!;
    delete finding.severity;
    delete finding.path;
    delete original.arguments.uncertainties;
    const submit = (args: Record<string, unknown>) => assistant([{ ...full, arguments: args }]);
    const firstPatch = mode === "no-progress" ? {} : mode === "invalid" ? { uncertainties: [], findings: [{ severity: "bogus" }] } : { uncertainties: [] };
    const secondPatch = mode === "exhausted" ? { findings: [{ path: "src/example.ts" }] } : full.arguments;
    const adapter = scriptedAdapter([submit(original.arguments), submit(firstPatch), submit(secondPatch), submit(secondPatch)]);
    const telemetry = fakeTelemetry();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const result = runner.runStructured(submitReviewRequest("progress-" + mode));
    if (mode !== "exhausted") await expect(result).resolves.toEqual(full.arguments);
    else await expect(result).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(adapter.contexts).toHaveLength(mode === "exhausted" ? 4 : 3);
    expect(telemetry.events.filter(e => e.message === "schema_repair_retry_scheduled")).toHaveLength(mode === "exhausted" ? 2 : 1);
    if (mode === "success") {
      expect(adapter.contexts[2]).toContain("findings.0.severity");
      expect(adapter.contexts[2]).toContain("findings.0.path");
    }
  });

  it("fills required fields on the third repair after two no-progress responses", async () => {
    const full = validCandidateSubmitReviewCall("full");
    const original = structuredClone(full);
    delete (original.arguments.findings as Record<string, unknown>[])[0]!.severity;
    const empty = assistant([{ ...full, arguments: {} }]);
    const adapter = scriptedAdapter([assistant([original]), empty, empty, assistant([{ ...full, arguments: { "findings.0.severity": "high" } }])]);
    const telemetry = fakeTelemetry();
    const cache = { get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })), put: vi.fn(async () => ({ status: "write" as const })) };
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured(submitReviewRequest("third-repair"))).resolves.toMatchObject({ findings: [{ severity: "high" }] });
    expect(adapter.contexts).toHaveLength(4);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(telemetry.events.filter(e => e.message === "schema_repair_retry_scheduled").map(e => e.data?.attempt)).toEqual([2, 3]);
  });

  it("shares the 180 second deadline across all three repairs", async () => {
    vi.useFakeTimers();
    try {
      const full = validCandidateSubmitReviewCall("full");
      const original = structuredClone(full);
      delete original.arguments.uncertainties;
      delete (original.arguments.findings as Record<string, unknown>[])[0]!.severity;
      const adapter = scriptedAdapter([assistant([original]), assistant([{ ...full, arguments: { uncertainties: [] } }]), assistant([{ ...full, arguments: {} }])]);
      const complete = adapter.complete;
      let calls = 0;
      let thirdRepairSignal: AbortSignal | undefined;
      adapter.complete = vi.fn(async (model, context, options) => {
        calls++;
        if (calls === 2 || calls === 3) await new Promise(resolve => setTimeout(resolve, 60_000));
        if (calls === 4) {
          thirdRepairSignal = options.signal;
          return new Promise<PiAssistantMessage>(() => {});
        }
        return complete(model, context, options);
      });
      const telemetry = fakeTelemetry();
      const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
      const rejected = expect(runner.runStructured({ ...submitReviewRequest("shared-repair-deadline"), timeoutMs: 600_000 })).rejects.toMatchObject({ code: "llm_call_failed" });
      await vi.advanceTimersByTimeAsync(179_999);
      expect(calls).toBe(4);
      expect(thirdRepairSignal?.aborted).toBe(false);
      await vi.advanceTimersByTimeAsync(1);
      await rejected;
      expect(thirdRepairSignal?.aborted).toBe(true);
      expect(calls).toBe(4);
      expect(telemetry.modelCalls.at(-1)).toMatchObject({ kind: "repair", status: "timeout", durationMs: 60_000 });
    } finally { vi.useRealTimers(); }
  });

  it("aborts a nonresponsive repair after 180 seconds without another attempt", async () => {
    vi.useFakeTimers();
    try {
      const telemetry = fakeTelemetry();
      const adapter = scriptedAdapter([assistant([validSubmitPlanCall("a"), validSubmitPlanCall("b")])]);
      const originalComplete = adapter.complete;
      let repairSignal: AbortSignal | undefined;
      adapter.complete = vi.fn(async (model, context, options) => {
        if (!repairSignal && context.messages.length > 1) {
          repairSignal = options.signal;
          (options.onStreamEvent as ((event: unknown) => void) | undefined)?.({ type: "thinking_delta", delta: "progress" });
          return new Promise<PiAssistantMessage>(() => {}); // Provider ignores cancellation.
        }
        return originalComplete(model, context, options);
      });
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
        adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      const result = runner.runStructured({ stage: 5, prompt: "planner", schema: SubmitPlanSchema, templateVersion: "test", timeoutMs: 600_000 });
      const rejected = expect(result).rejects.toMatchObject({ code: "llm_call_failed" });
      await vi.advanceTimersByTimeAsync(179_999);
      expect(repairSignal?.aborted).toBe(false);
      await vi.advanceTimersByTimeAsync(1);
      await rejected;
      expect(repairSignal?.aborted).toBe(true);
      expect(adapter.complete).toHaveBeenCalledTimes(2);
      expect(telemetry.modelCalls.at(-1)).toMatchObject({
        kind: "repair", status: "timeout", durationMs: 180_000,
        streamProgress: { thinkingChunks: 1, thinkingChars: 8, contentIdleMs: 180_000 }
      });
    } finally {
      vi.useRealTimers();
    }
  });

  it("expires a repair while queued without dispatching it later", async () => {
    vi.useFakeTimers();
    const abort = new AbortController();
    try {
      const telemetry = fakeTelemetry();
      const adapter = scriptedAdapter([]);
      let finishFirst: ((message: PiAssistantMessage) => void) | undefined;
      adapter.complete = vi.fn(async () => new Promise<PiAssistantMessage>((resolve) => {
        finishFirst ??= resolve;
      }));
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: abort.signal,
        adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      const request = { stage: 5 as const, prompt: "planner", schema: SubmitPlanSchema, templateVersion: "test", timeoutMs: 600_000 };
      const first = runner.runStructured(request);
      const firstRejected = expect(first).rejects.toMatchObject({ code: "llm_call_failed" });
      await vi.advanceTimersByTimeAsync(0);
      const second = runner.runStructured(request);
      const secondRejected = expect(second).rejects.toMatchObject({ code: "llm_call_failed" });
      finishFirst!(assistant([validSubmitPlanCall("a"), validSubmitPlanCall("b")]));
      await vi.advanceTimersByTimeAsync(0);
      expect(adapter.complete).toHaveBeenCalledTimes(2); // The other investigation owns the slot.
      await vi.advanceTimersByTimeAsync(180_000);
      await firstRejected;
      expect(telemetry.modelCalls.at(-1)).toMatchObject({ kind: "repair", status: "timeout" });
      abort.abort();
      await secondRejected;
      await vi.advanceTimersByTimeAsync(0);
      expect(adapter.complete).toHaveBeenCalledTimes(2); // Expired repair never reaches the provider.
    } finally {
      abort.abort();
      vi.useRealTimers();
    }
  });

  it.each(["plain-text", "transient-error"])("does not retry a repair returning %s", async (failure) => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "bad", name: "submit_review", arguments: { findings: "invalid" } }]),
      assistant([{ type: "text", text: "Here is my answer" }])
    ]);
    if (failure === "transient-error") {
      const originalComplete = adapter.complete;
      let calls = 0;
      adapter.complete = vi.fn(async (model, context, options) => {
        if (++calls === 2) throw Object.assign(new Error("service unavailable"), { status: 503 });
        return originalComplete(model, context, options);
      });
    }
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await expect(runner.runStructured({ stage: 7, prompt: "review", schema: SubmitPacketReviewSchema, templateVersion: "test", timeoutMs: 600_000 })).rejects.toMatchObject({
      code: failure === "plain-text" ? "llm_schema_invalid" : "llm_call_failed"
    });
    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(telemetry.modelCalls.filter((call) => call.kind === "repair")).toHaveLength(1);
  });

  it("decodes a complete string-wrapped verifier finding without a model repair", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([assistant([{
      type: "toolCall", id: "wrapped", name: "submit_verdict",
      arguments: { ...VERIFIER_SUBMIT_EXAMPLE, finalFinding: JSON.stringify(VERIFIER_SUBMIT_EXAMPLE.finalFinding) }
    }])]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const result = await runner.runStructured({
      stage: 9, prompt: "verifier", schema: SubmitVerificationVerdictSchema, templateVersion: "test", timeoutMs: 1000,
      schemaRepair: { recoverInvalidSubmit: recoverStringWrappedVerifierFinding }
    });
    expect(result).toEqual(VERIFIER_SUBMIT_EXAMPLE);
    expect(adapter.complete).toHaveBeenCalledTimes(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "submit_shape_correction_accepted" }));
  });

  it.each(['{"title":"unfinished', '[]', 'null', '{"title":"missing required evidence"}'])("does not accept an invalid string-wrapped verifier finding: %s", async (finalFinding) => {
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "bad", name: "submit_verdict", arguments: { ...VERIFIER_SUBMIT_EXAMPLE, finalFinding } }]),
      assistant([{ type: "toolCall", id: "still-bad", name: "submit_verdict", arguments: { ...VERIFIER_SUBMIT_EXAMPLE, finalFinding } }])
    ,
      assistant([{ type: "toolCall", id: "still-bad", name: "submit_verdict", arguments: { ...VERIFIER_SUBMIT_EXAMPLE, finalFinding } }])
    ,
      assistant([{ type: "toolCall", id: "still-bad", name: "submit_verdict", arguments: { ...VERIFIER_SUBMIT_EXAMPLE, finalFinding } }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await expect(runner.runStructured({
      stage: 9, prompt: "verifier", schema: SubmitVerificationVerdictSchema, templateVersion: "test", timeoutMs: 1000,
      schemaRepair: { recoverInvalidSubmit: recoverStringWrappedVerifierFinding, replaceConversation: false }
    })).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(adapter.complete).toHaveBeenCalledTimes(4);
  });

  it("fails after three invalid planner repairs", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([validSubmitPlanCall("submit-plan-a"), validSubmitPlanCall("submit-plan-b")]),
      assistant([validSubmitPlanCall("submit-plan-c"), validSubmitPlanCall("submit-plan-d")])
    ,
      assistant([validSubmitPlanCall("submit-plan-c"), validSubmitPlanCall("submit-plan-d")])
    ,
      assistant([validSubmitPlanCall("submit-plan-c"), validSubmitPlanCall("submit-plan-d")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured({
      stage: 5,
      prompt: "planner",
      schema: SubmitPlanSchema,
      templateVersion: "test-template",
      timeoutMs: 1000,
      schemaRepair: {
        replaceConversation: true,
        failAfterRepair: true,
        buildPrompt: () => "compact planner repair"
      }
    })).rejects.toMatchObject({
      code: "llm_schema_invalid",
      recoverable: false
    });

    expect(adapter.complete).toHaveBeenCalledTimes(4);
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(Array(4).fill("schema_invalid"));
    expect(telemetry.modelCalls.map((call) => call.finalArgumentState)).toEqual(Array(4).fill(undefined));
  });

  it("keeps exhausted planner schema failure recoverable for deterministic fallback", async () => {
    const adapter = scriptedAdapter([
      assistant([validSubmitPlanCall("submit-plan-a"), validSubmitPlanCall("submit-plan-b")]),
      assistant([validSubmitPlanCall("submit-plan-c"), validSubmitPlanCall("submit-plan-d")])
    ,
      assistant([validSubmitPlanCall("submit-plan-c"), validSubmitPlanCall("submit-plan-d")])
    ,
      assistant([validSubmitPlanCall("submit-plan-c"), validSubmitPlanCall("submit-plan-d")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured({
      stage: 5,
      prompt: "planner",
      schema: SubmitPlanSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      schemaRepair: {
        replaceConversation: true,
        failAfterRepair: false,
        buildPrompt: () => "compact planner repair"
      }
    })).rejects.toMatchObject({
      code: "llm_schema_invalid",
      recoverable: true,
      context: {
        structuredSubmitFailure: expect.objectContaining({
          stage: 5,
          submitTool: "submit_plan",
          attempt: "repair",
          classification: "multiple_submits"
        })
      }
    });
    expect(adapter.complete).toHaveBeenCalledTimes(4);
  });

  it("repairs verifier schema-invalid submits with replacement context and submit-only tools", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-verdict-xml",
        name: "submit_verdict",
        arguments: { reason: "BAD_PRIOR_XML_BODY" }
      }]),
      assistant([{ ...validSubmitVerdictCall("submit-verdict-repaired"), arguments: { ...validSubmitVerdictCall("submit-verdict-repaired").arguments, reason: "BAD_PRIOR_XML_BODY" } }])
    ]);
    const readRange: ToolDefinition = {
      name: "read_range",
      description: "read range",
      parameters: Type.Object({ path: Type.String() }, { additionalProperties: false }),
      execute: vi.fn(async () => ({ text: "source", meta: { backend: "text" as const, precision: "exact" as const, degraded: false } }))
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", reasoning: "high", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const originalPromptMarker = "ORIGINAL_VERIFIER_PROMPT_SHOULD_NOT_BE_RESENT";

    await expect(runner.runStructured({
      stage: 9,
      prompt: `${originalPromptMarker} ${"x".repeat(4000)}`,
      schema: SubmitVerificationVerdictSchema,
      templateVersion: "test-template",
      tools: [readRange],
      timeoutMs: 1000,
      schemaRepair: {
        replaceConversation: true,
        failAfterRepair: false,
        buildPrompt: (input) => {
          expect(input.submitTool).toBe("submit_verdict");
          expect(input.submitCalls.map((call) => call.id)).toEqual(["submit-verdict-xml"]);
          expect(JSON.stringify(input.submitCalls[0]?.arguments)).toContain("BAD_PRIOR_XML_BODY");
          return [
            "compact verifier repair",
            "Do not output XML.",
            "Do not write `<parameter>` tags.",
            "Call `submit_verdict` exactly once."
          ].join("\n");
        }
      }
    })).resolves.toMatchObject({
      verdict: "reject",
      requiredEvidencePresent: false,
      falsePositiveRisk: "high"
    });

    expect(adapter.toolNames[0]).toEqual(["read_range", "submit_verdict"]);
    expect(adapter.toolNames[1]).toEqual(["submit_verdict"]);
    expect(adapter.options[1]).toMatchObject({ toolChoice: { type: "tool", name: "submit_verdict" } });
    expect(adapter.contexts[1]).toContain("supply the missing or invalid field values");
    expect(adapter.contexts[1]).toContain("Optional schema fields remain optional");
    expect(adapter.contexts[1]).not.toContain(originalPromptMarker);
    expect(adapter.contexts[1]).toContain("BAD_PRIOR_XML_BODY");
    expect(telemetry.modelCalls.map((call) => call.kind)).toEqual(["initial", "repair"]);
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid", "ok"]);
  });

  it("retains inspected source and the failed verifier verdict in submit-only repair", async () => {
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "read", name: "read_range", arguments: { path: "example.ts" } }]),
      assistant([{ type: "toolCall", id: "bad", name: "submit_verdict", arguments: {
        ...VERIFIER_SUBMIT_EXAMPLE, finalFinding: JSON.stringify({ ...validCandidateReviewFinding(), confidence: undefined })
      } }]),
      assistant([{ type: "toolCall", id: "fixed", name: "submit_verdict", arguments: { ...VERIFIER_SUBMIT_EXAMPLE, finalFinding: validCandidateReviewFinding() } }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await runner.runStructured({
      stage: 9, prompt: "original verifier context", schema: SubmitVerificationVerdictSchema,
      templateVersion: "test", timeoutMs: 1000,
      tools: [{ name: "read_range", description: "read", parameters: Type.Object({ path: Type.String() }),
        execute: async () => ({ text: "UNIQUE_INSPECTED_SOURCE: return items[0].id;" }) }],
      toolBudget: { maxToolCalls: 3, maxInvestigationRounds: 3, maxResultChars: 10_000 },
      schemaRepair: { replaceConversation: false, buildPrompt: () => "Repair shape only; preserve the verdict." }
    });
    expect(adapter.contexts[2]).toContain("UNIQUE_INSPECTED_SOURCE");
    expect(adapter.contexts[2]).toContain("original verifier context");
    expect(adapter.contexts[2]).toContain("Candidate finding");
    expect(adapter.contexts[2]).toContain("supply the missing or invalid field values");
    expect(adapter.toolNames[2]).toEqual(["submit_verdict"]);
  });

  it("routes semantic empty-revise submits through the existing single repair and cache gate", async () => {
    const telemetry = fakeTelemetry();
    const cache = {
      get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async () => ({ status: "write" as const }))
    };
    const emptyRevise = (id: string): PiToolCall => ({
      type: "toolCall",
      id,
      name: "submit_verdict",
      arguments: {
        verdict: "revise",
        reason: "The issue needs a correction.",
        requiredEvidencePresent: true,
        falsePositiveRisk: "low"
      }
    });
    const repaired = { ...emptyRevise("valid-repair"), arguments: { ...emptyRevise("valid-repair").arguments, revisedAnchor: { path: "src/a.ts", line: 12, side: "RIGHT", hunkId: "hunk-a" } } };
    const adapter = scriptedAdapter([
      assistant([emptyRevise("empty-primary")]),
      assistant([repaired])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured<SubmitVerificationVerdict>({
      stage: 9,
      prompt: "verify",
      schema: SubmitVerificationVerdictSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      validateSubmit: (value) => value.verdict === "revise" && value.finalFinding === undefined && value.revisedAnchor === undefined
        ? { ok: false, classification: "revise_without_revision_payload" }
        : { ok: true },
      schemaRepair: {
        replaceConversation: true,
        failAfterRepair: false,
        buildPrompt: (input) => {
          expect(input.classification).toBe("revise_without_revision_payload");
          return "repair the empty revision with a payload";
        }
      }
    })).resolves.toMatchObject({ verdict: "revise" });

    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(telemetry.modelCalls.map((call) => call.schemaValid)).toEqual([false, true]);
    expect(cache.put).toHaveBeenCalledTimes(1);
    const putCalls = cache.put.mock.calls as unknown as Array<[unknown, StoredProviderResponse]>;
    const cachedResponse = putCalls[0]?.[1];
    expect(cachedResponse?.message.content).toEqual([trustedSubmitCall(repaired)]);
  });

  it("rejects a semantic-invalid deterministic recovery and exposes only bounded terminal identity", async () => {
    const secret = "sk-semantic-payload-must-not-survive";
    const emptyRevise = (id: string): PiToolCall => ({
      type: "toolCall",
      id,
      name: "submit_verdict",
      arguments: {
        verdict: "revise",
        reason: `The issue needs a correction. ${secret}`,
        requiredEvidencePresent: true,
        falsePositiveRisk: "low"
      }
    });
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "schema-invalid-primary",
        name: "submit_verdict",
        arguments: {}
      }]),
      assistant([emptyRevise("empty-repair")])
    ,
      assistant([emptyRevise("empty-repair")])
    ,
      assistant([emptyRevise("empty-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    let caught: unknown;
    try {
      await runner.runStructured<SubmitVerificationVerdict>({
        stage: 9,
        prompt: "verify",
        schema: SubmitVerificationVerdictSchema,
        templateVersion: "test-template",
        timeoutMs: 1_000,
        validateSubmit: (value) => value.verdict === "revise" && value.finalFinding === undefined && value.revisedAnchor === undefined
          ? { ok: false, classification: "revise_without_revision_payload" }
          : { ok: true },
        schemaRepair: {
          replaceConversation: true,
          failAfterRepair: false,
          recoverInvalidSubmit: () => ({
            verdict: "revise",
            reason: `Recovered without a payload ${secret}`,
            requiredEvidencePresent: true,
            falsePositiveRisk: "low"
          }),
          buildPrompt: (input) => {
            expect(input.classification).toBe("revise_without_revision_payload");
            return "repair the semantic omission";
          }
        }
      });
    } catch (error) {
      caught = error;
    }

    expect(caught).toMatchObject({
      code: "llm_schema_invalid",
      recoverable: true,
      context: {
        structuredSubmitFailure: expect.objectContaining({
          classification: "revise_without_revision_payload",
          attempt: "repair",
          issues: [{ path: "root", rule: "semantic" }]
        })
      }
    });
    expect(JSON.stringify(caught)).not.toContain(secret);
    expect((caught as Error & { cause?: unknown }).cause).toBeUndefined();
    expect(adapter.complete).toHaveBeenCalledTimes(4);
  });

  it.each([
    { state: "length_stopped" } as const,
    { state: "partial", errorKind: "unexpected_end" } as const,
    { state: "invalid", errorKind: "invalid_syntax" } as const,
    { state: "event_capture_missing" } as const,
    { state: "event_final_mismatch" } as const
  ])("routes primary $state final arguments through one context-preserving repair", async (argumentParse) => {
    const telemetry = fakeTelemetry();
    const cache = {
      get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async () => ({ status: "write" as const }))
    };
    const invalid = invalidSubmitCall("untrusted-primary", "submit_review", argumentParse);
    const primary = { ...assistant([invalid]), stopReason: "toolUse" };
    const adapter = scriptedAdapter([primary, assistant([validSubmitReviewCall("trusted-repair")])]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured<SubmitPacketReview>({
      stage: 7,
      prompt: "review ORIGINAL_STAGE7_PACKET_CONTEXT",
      schema: SubmitPacketReviewSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      schemaRepair: {
        replaceConversation: true,
        failAfterRepair: false,
        buildPrompt: (input) => {
          expect(input.submitCalls).toEqual([]);
          expect(input.untrustedSubmitCalls).toEqual([expect.objectContaining({
            id: "untrusted-primary",
            name: "submit_review",
            state: argumentParse.state
          })]);
          return `retry bounded state ${argumentParse.state}`;
        }
      }
    })).resolves.toMatchObject({ findings: [] });

    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(adapter.contexts[1]).toContain(`retry bounded state ${argumentParse.state}`);
    expect(adapter.contexts[1]).toContain("ORIGINAL_STAGE7_PACKET_CONTEXT");
    expect(adapter.contexts[1]).not.toContain("invalidToolCall");
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(telemetry.modelCalls.map((call) => call.finalArgumentState)).toEqual([argumentParse.state, "strict"]);
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        message: "final_arguments_rejected",
        data: expect.objectContaining({ state: argumentParse.state, schemaRepairUsed: false })
      }),
      expect.objectContaining({
        message: "schema_repair_scheduled",
        data: expect.objectContaining({ replaceConversation: false })
      }),
      expect.objectContaining({
        message: "final_argument_repair_outcome",
        data: expect.objectContaining({ outcome: "recovered" })
      })
    ]));
  });

  it("does not execute or orphan a valid repository tool beside an invalid submit", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "must not execute",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const readRange: ToolDefinition = {
      name: "read_range",
      description: "read range",
      parameters: Type.Object({ path: Type.String() }, { additionalProperties: false }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "read-beside-invalid-submit", name: "read_range", arguments: { path: "src/a.ts" } },
        invalidSubmitCall("invalid-submit", "submit_review", { state: "event_capture_missing" })
      ]),
      assistant([validSubmitReviewCall("trusted-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured<SubmitPacketReview>({
      stage: 7,
      prompt: "review ORIGINAL_MIXED_PACKET_CONTEXT",
      schema: SubmitPacketReviewSchema,
      templateVersion: "test-template",
      tools: [readRange],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 1_000 },
      timeoutMs: 1_000,
      schemaRepair: {
        replaceConversation: true,
        failAfterRepair: false,
        buildPrompt: () => "retry invalid submit only"
      }
    })).resolves.toMatchObject({ findings: [] });

    expect(execute).not.toHaveBeenCalled();
    expect(telemetry.toolCalls).toEqual([]);
    expect(adapter.contexts[1]).toContain("ORIGINAL_MIXED_PACKET_CONTEXT");
    expect(adapter.contexts[1]).toContain("retry invalid submit only");
    expect(adapter.contexts[1]).not.toContain("read-beside-invalid-submit");
    expect(adapter.contexts[1]).not.toContain("toolResult");
    expect(telemetry.events).toContainEqual(expect.objectContaining({
      message: "schema_repair_scheduled",
      data: expect.objectContaining({ replaceConversation: false, extraToolNames: ["read_range"] })
    }));
  });

  it("records not_dispatched when budget exhaustion prevents the final-argument repair call", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      { ...assistant([invalidSubmitCall("invalid-primary", "submit_review", { state: "invalid", errorKind: "invalid_syntax" })]), stopReason: "toolUse" }
    ]);
    let checkpoints = 0;
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => ++checkpoints === 1 ? "ok" : "exhausted",
        onUsage: vi.fn()
      }
    });

    await expect(runner.runStructured<SubmitPacketReview>({
      stage: 7,
      prompt: "review",
      schema: SubmitPacketReviewSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      schemaRepair: { replaceConversation: true, failAfterRepair: false, buildPrompt: () => "retry safely" }
    })).rejects.toMatchObject({
      code: "llm_call_failed",
      context: expect.objectContaining({ reason: "budget_exhausted" })
    });

    expect(adapter.complete).toHaveBeenCalledTimes(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({
      message: "final_argument_repair_outcome",
      data: expect.objectContaining({ outcome: "not_dispatched" })
    }));
  });

  it.each([
    { state: "length_stopped" } as const,
    { state: "partial", errorKind: "unterminated" } as const,
    { state: "invalid", errorKind: "non_object_root" } as const,
    { state: "event_capture_missing" } as const,
    { state: "event_final_mismatch" } as const
  ])("fails closed when repaired submit remains $state", async (argumentParse) => {
    const telemetry = fakeTelemetry();
    const cache = {
      get: vi.fn(async () => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async () => ({ status: "write" as const }))
    };
    const adapter = scriptedAdapter([
      { ...assistant([invalidSubmitCall("invalid-primary", "submit_review", argumentParse)]), stopReason: "toolUse" },
      { ...assistant([invalidSubmitCall("invalid-repair", "submit_review", argumentParse)]), stopReason: "toolUse" }
    ,
      { ...assistant([invalidSubmitCall("invalid-repair", "submit_review", argumentParse)]), stopReason: "toolUse" }
    ,
      { ...assistant([invalidSubmitCall("invalid-repair", "submit_review", argumentParse)]), stopReason: "toolUse" }
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured<SubmitPacketReview>({
      stage: 7,
      prompt: "review",
      schema: SubmitPacketReviewSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      schemaRepair: { replaceConversation: true, failAfterRepair: false, buildPrompt: () => "retry safely" }
    })).rejects.toMatchObject({
      code: "llm_schema_invalid",
      recoverable: true,
      context: {
        structuredSubmitFailure: expect.objectContaining({
          attempt: "repair",
          classification: provenanceClassification(argumentParse)
        })
      }
    });

    expect(cache.put).not.toHaveBeenCalled();
    expect(telemetry.modelCalls.map((call) => call.finalArgumentState)).toEqual(Array(4).fill(argumentParse.state));
    expect(telemetry.events).toContainEqual(expect.objectContaining({
      message: "final_argument_repair_outcome",
      data: expect.objectContaining({ outcome: "terminal_invalid" })
    }));
  });

  it("removes provenance-less submit arguments before telemetry, repair history, and cache", async () => {
    const secret = "sk-provenance-less-argument-secret";
    const telemetry = fakeTelemetry();
    const provenanceLess = assistant([validSubmitReviewCall("missing-provenance")]);
    provenanceLess.content = [{
      type: "toolCall",
      id: "missing-provenance",
      name: "submit_review",
      arguments: { findings: [], followUpHints: [], uncertainties: [], secret }
    }];
    const adapter = scriptedAdapter([provenanceLess, assistant([validSubmitReviewCall("trusted-repair")])]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured<SubmitPacketReview>({
      stage: 7,
      prompt: "review",
      schema: SubmitPacketReviewSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      schemaRepair: { replaceConversation: true, failAfterRepair: false, buildPrompt: () => "bounded retry" }
    })).resolves.toMatchObject({ findings: [] });

    const publicRecords = JSON.stringify({
      modelCalls: telemetry.modelCalls,
      events: telemetry.events,
      debugWrites: telemetry.debugWrites,
      contexts: adapter.contexts
    });
    expect(publicRecords).not.toContain(secret);
    expect(telemetry.modelCalls[0]).toMatchObject({
      finalArgumentState: "event_capture_missing",
      schemaValid: false
    });
  });

  it("lets stages recover invalid submit arguments before model schema repair", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-composition-xml",
        name: "submit_composition",
        arguments: {
          summary: "Recovered summary."
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured({
      stage: 10,
      prompt: "compose",
      schema: SubmitCompositionSchema,
      templateVersion: "test-template",
      timeoutMs: 1000,
      schemaRepair: {
        replaceConversation: true,
        buildPrompt: () => {
          throw new Error("model repair should not be needed");
        },
        recoverInvalidSubmit: (input) => {
          expect(input.submitTool).toBe("submit_composition");
          expect(input.submitCalls.map((call) => call.id)).toEqual(["submit-composition-xml"]);
          return {
            summary: "Recovered summary.",
            composedFindings: [{ findingIds: ["finding-1"], finalBody: "Recovered body.", publication: "inline" }]
          };
        }
      }
    })).resolves.toMatchObject({
      summary: "Recovered summary.",
      composedFindings: [{ findingIds: ["finding-1"], finalBody: "Recovered body.", publication: "inline" }]
    });

    expect(adapter.complete).toHaveBeenCalledTimes(1);
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid"]);
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 10,
        message: "schema_invalid_submit_recovered",
        data: expect.objectContaining({ submitTool: "submit_composition" })
      })
    ]));
  });

  it("preserves an explicit append override returned by invalid-submit recovery", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-composition-invalid",
        name: "submit_composition",
        arguments: { summary: "Recovered composition." }
      }]),
      assistant([{
        type: "toolCall",
        id: "submit-composition-repaired",
        name: "submit_composition",
        arguments: {
          summary: "Recovered composition.",
          composedFindings: [{ findingIds: ["finding-1"], finalBody: "Recovered body.", publication: "inline" }]
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured({
      stage: 10,
      prompt: "ORIGINAL_RECOVERY_CONTEXT compose",
      schema: SubmitCompositionSchema,
      templateVersion: "test-template",
      timeoutMs: 1_000,
      schemaRepair: {
        replaceConversation: true,
        buildPrompt: () => "retry composition with complete fields",
        recoverInvalidSubmit: () => ({
          kind: "recovery",
          replaceConversationOverride: false
        })
      }
    })).resolves.toMatchObject({
      summary: "Recovered composition.",
      composedFindings: [{ findingIds: ["finding-1"] }]
    });

    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(adapter.contexts[1]).toContain("ORIGINAL_RECOVERY_CONTEXT");
    expect(adapter.contexts[1]).toContain("supply the missing or invalid field values");
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid", "ok"]);
    expect(telemetry.events).toContainEqual(expect.objectContaining({
      stage: 10,
      message: "schema_repair_scheduled",
      data: expect.objectContaining({ replaceConversation: false })
    }));
  });

  it("repairs composer responses that omit submit_composition with replacement context", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "text", text: "BAD_PRIOR_COMPOSER_TEXT" }]),
      assistant([{
        type: "toolCall",
        id: "submit-composition-repaired",
        name: "submit_composition",
        arguments: {
          summary: "Recovered composition.",
          composedFindings: [{ findingIds: ["finding-1"], finalBody: "Recovered body.", publication: "inline" }]
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    const originalPromptMarker = "ORIGINAL_COMPOSER_PROMPT_SHOULD_NOT_BE_RESENT";

    await expect(runner.runStructured({
      stage: 10,
      prompt: `${originalPromptMarker} compose`,
      schema: SubmitCompositionSchema,
      templateVersion: "test-template",
      timeoutMs: 1000,
      schemaRepair: {
        replaceConversation: true,
        buildPrompt: (input) => {
          expect(input.submitTool).toBe("submit_composition");
          expect(input.submitCalls).toEqual([]);
          return [
            "compact composer repair",
            "Do not output XML.",
            "Do not write `<parameter>` tags.",
            "Call `submit_composition` exactly once."
          ].join("\n");
        }
      }
    })).resolves.toMatchObject({
      summary: "Recovered composition.",
      composedFindings: [{ findingIds: ["finding-1"], finalBody: "Recovered body.", publication: "inline" }]
    });

    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(adapter.contexts[1]).toContain("compact composer repair");
    expect(adapter.contexts[1]).not.toContain(originalPromptMarker);
    expect(adapter.contexts[1]).not.toContain("BAD_PRIOR_COMPOSER_TEXT");
    expect(telemetry.modelCalls.map((call) => call.kind)).toEqual(["initial", "repair"]);
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["schema_invalid", "ok"]);
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 10,
        message: "schema_repair_scheduled",
        data: expect.objectContaining({ invalidSubmitCallCount: 0, replaceConversation: true })
      })
    ]));
  });

  it("makes one budget-exempt finalization provider call after checkpoint exhaustion", async () => {
    const adapter = scriptedAdapter([
      assistant([{ type: "text", text: "plain text instead of submit" }]),
      assistant([validSubmitReviewCall("must-not-run")])
    ]);
    let checkpoints = 0;
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: {
        checkpoint: () => {
          checkpoints += 1;
          return checkpoints === 1 ? "ok" : "exhausted";
        },
        onUsage: vi.fn()
      }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-budget-stop"))).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });
    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(checkpoints).toBe(2);
  });

  it("does not cache plain-text non-submissions", async () => {
    const cache = {
      get: vi.fn(async (_key: string) => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    };
    const adapter = scriptedAdapter([
      assistant([{ type: "text", text: "plain text instead of submit" }]),
      assistant([validSubmitReviewCall("must-not-run")])
    ]);
    let checkpoints = 0;
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: {
        checkpoint: () => {
          checkpoints += 1;
          return checkpoints === 1 ? "ok" : "exhausted";
        },
        onUsage: vi.fn()
      }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-plain-no-cache"))).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });
    expect(adapter.complete).toHaveBeenCalledTimes(2);
    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(cache.put.mock.calls[0]?.[1].message.content).toEqual([trustedSubmitCall(validSubmitReviewCall("must-not-run"))]);
  });

  it("includes tool budget in model-call cache keys", async () => {
    const cacheKeys: string[] = [];
    const cache = {
      get: vi.fn(async (key: string) => {
        cacheKeys.push(key);
        return { status: "miss" as const, reason: "not_found" as const };
      }),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    };
    const adapter = scriptedAdapter([
      assistant([validSubmitReviewCall("submit-budget-a")]),
      assistant([validSubmitReviewCall("submit-budget-b")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("same-packet"),
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 100 }
    });
    await runner.runStructured({
      ...submitReviewRequest("same-packet"),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 1, maxResultChars: 100 }
    });

    expect(cache.get).toHaveBeenCalledTimes(2);
    expect(cacheKeys[0]).not.toBe(cacheKeys[1]);
  });

  it("uses canonical prompt hashes for matching cache misses and hits", async () => {
    const telemetry = fakeTelemetry();
    const entries = new Map<string, StoredProviderResponse>();
    const cache = {
      get: vi.fn(async (key: string) => {
        const entry = entries.get(key);
        return entry ? { status: "hit" as const, response: entry } : { status: "miss" as const, reason: "not_found" as const };
      }),
      put: vi.fn(async (key: string, entry: StoredProviderResponse) => {
        entries.set(key, entry);
        return { status: "write" as const };
      })
    };
    const adapter = scriptedAdapter([assistant([validSubmitReviewCall("submit-canonical-cache")])]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured(submitReviewRequest("packet-canonical"));
    await runner.runStructured(submitReviewRequest("packet-canonical"));

    expect(adapter.complete).toHaveBeenCalledTimes(1);
    expect(telemetry.modelCalls.map((call) => call.cacheStatus)).toEqual(["write", "hit"]);
    expect(telemetry.modelCalls[0]?.promptHash).toBe(telemetry.modelCalls[1]?.promptHash);
    expect(telemetry.modelCalls[0]?.promptChars).toBe(telemetry.modelCalls[1]?.promptChars);
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 7,
          message: "model_call_cache_key_diagnostic",
          data: expect.objectContaining({
            missReason: "not_found",
            keyPrefix: expect.any(String),
            requestHash: expect.any(String),
            templateVersion: "test-template",
            toolBudgetHash: expect.any(String),
            toolSpecHash: expect.any(String),
            messageHash: expect.any(String),
            promptChars: expect.any(Number)
          })
        })
      ])
    );
    expect(debugRecord(telemetry, "mc-000002.request")).toMatchObject({
      artifactKind: "llm_call_request",
      cache: expect.objectContaining({ enabled: true, status: "hit" })
    });
  });

  it("records cacheable provider responses as misses when cache persistence fails", async () => {
    const telemetry = fakeTelemetry();
    const cache = {
      get: vi.fn(async (_key: string) => ({ status: "miss" as const, reason: "not_found" as const })),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "miss" as const, reason: "write_failed" as const }))
    };
    const adapter = scriptedAdapter([assistant([validSubmitReviewCall("submit-cache-write-failed")])]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-cache-write-failed"))).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });

    expect(cache.put).toHaveBeenCalledTimes(1);
    expect(telemetry.modelCalls).toEqual([
      expect.objectContaining({
        status: "ok",
        cacheStatus: "miss"
      })
    ]);
  });

  it("replays cache hits without provider budget usage or checkpoint calls", async () => {
    const telemetry = fakeTelemetry();
    const cache = {
      runFingerprint: "run-hit",
      get: vi.fn(async (_key: string) => ({ status: "hit" as const, response: cacheEntry(7) })),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    };
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => assistant([validSubmitReviewCall("must-not-call-provider")])),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const checkpoint = vi.fn(() => "ok" as const);
    const onUsage = vi.fn();
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      cache,
      hooks: { checkpoint, onUsage }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-hit"))).resolves.toEqual({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });

    expect(adapter.complete).not.toHaveBeenCalled();
    expect(checkpoint).not.toHaveBeenCalled();
    expect(onUsage).not.toHaveBeenCalled();
    expect(cache.put).not.toHaveBeenCalled();
    expect(telemetry.modelCalls).toEqual([
      expect.objectContaining({
        cacheStatus: "hit",
        inputTokens: 1,
        outputTokens: 1,
        totalTokens: 2,
        costUSD: 0.01
      })
    ]);
    expect(debugRecord(telemetry, "mc-000001.request")).toMatchObject({
      artifactKind: "llm_call_request",
      cache: expect.objectContaining({ enabled: true, status: "hit", key: expect.any(String) })
    });
    expect(debugRecord(telemetry, "mc-000001.response")).toMatchObject({
      artifactKind: "llm_call_response",
      cacheStatus: "hit",
      response: { role: "assistant" }
    });
  });

  it("includes the run fingerprint in model-call cache keys", async () => {
    const keys: string[] = [];
    const cache = (runFingerprint: string) => ({
      runFingerprint,
      get: vi.fn(async (key: string) => {
        keys.push(key);
        return { status: "miss" as const, reason: "not_found" as const };
      }),
      put: vi.fn(async (_key: string, _entry: StoredProviderResponse) => ({ status: "write" as const }))
    });
    const adapter = scriptedAdapter([
      assistant([validSubmitReviewCall("submit-run-a")]),
      assistant([validSubmitReviewCall("submit-run-b")])
    ]);

    for (const runFingerprint of ["run-a", "run-b"]) {
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: fakeTelemetry().recorder,
        logger: fakeLogger(),
        runSignal: new AbortController().signal,
        adapter,
        cache: cache(runFingerprint),
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });
      await runner.runStructured(submitReviewRequest("same-packet"));
    }

    expect(keys).toHaveLength(2);
    expect(keys[0]).not.toBe(keys[1]);
  });

  it("passes auto tool choice during investigation and forces submit-only calls", async () => {
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute: vi.fn(async () => ({
        text: "line 1",
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      }))
    };
    const investigative = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-choice-round",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ]),
      assistant([validSubmitReviewCall("submit-forced-after-tool")])
    ]);
    const investigativeRunner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter: investigative,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await investigativeRunner.runStructured({
      ...submitReviewRequest("packet-tool-choice"),
      tools: [tool],
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 3 }
    });
    expect(investigative.options.map((options) => options.toolChoice)).toEqual([
      "auto",
      { type: "tool", name: "submit_review" }
    ]);

    const submitOnly = scriptedAdapter([assistant([validSubmitReviewCall("submit-forced-initial")])]);
    const submitOnlyRunner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter: submitOnly,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await submitOnlyRunner.runStructured(submitReviewRequest("packet-submit-only"));
    expect(submitOnly.options[0]?.toolChoice).toEqual({ type: "tool", name: "submit_review" });
  });

  it("uses full forced finalization for no-candidate packet closeout", async () => {
    const telemetry = fakeTelemetry();
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute: vi.fn(async () => ({
        text: `function decisive() {\n${"return true;\n".repeat(200)}}`,
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      }))
    };
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-before-full-finalize",
          name: "read_range",
          arguments: { path: "src/a.ts", startLine: 1, endLine: 80 }
        }
      ]),
      assistant([{
        type: "toolCall",
        id: "submit-full-no-findings",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          findings: [],
          followUpHints: [],
          uncertainties: [],
          noFindingReason: "Reviewed changed hunk and helper summary; no concrete failure mode."
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-full-finalize"),
        tools: [tool],
        toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 2, maxResultChars: (`function decisive() {\n${"return true;\n".repeat(200)}}`).length / 2 },
        telemetryContext: { workerId: "worker-full", packetId: "packet-full-finalize" },
        finalization: {
          noResultInstruction: "If there are no findings, submit reviewStatus:\"no_findings\", findings: []."
        }
      })
    ).resolves.toMatchObject({
      reviewStatus: "no_findings",
      findings: [],
      noFindingReason: "Reviewed changed hunk and helper summary; no concrete failure mode."
    });
    expect(adapter.contexts[1]).toContain("function decisive");
    expect(telemetry.modelCalls[1]).toMatchObject({
      kind: "finalize",
      finalizeMode: "full",
      finalizeTarget: "no_findings"
    });
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        message: "full_finalize_started",
        packetId: "packet-full-finalize",
        data: expect.objectContaining({ mode: "full", target: "no_findings", reason: "tool_budget_exhausted" })
      })
    ]));
  });

  it("uses full forced finalization during packet closeout", async () => {
    const telemetry = fakeTelemetry();
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute: vi.fn(async () => ({
        text: "decisive source evidence.\n",
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      }))
    };
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "tool-before-full-finalize",
        name: "read_range",
        arguments: { path: "src/a.ts", startLine: 1, endLine: 2 }
      }]),
      assistant([{
        type: "toolCall",
        id: "submit-full-no-findings",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          findings: [],
          followUpHints: [{
            question: "Verify whether the changed branch still handles nil input.",
            files: ["src/a.ts"],
            symbols: ["decisive"],
            suggestedLenses: ["core/code-review"],
            reason: "The full transcript kept source context for a concrete unresolved predicate.",
            confidence: "medium"
          }],
          uncertainties: [],
          noFindingReason: "No concrete finding from gathered evidence."
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-full-finalize"),
        tools: [tool],
        toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 2, maxResultChars: 13 },
        telemetryContext: { workerId: "worker-full", packetId: "packet-full-finalize" },
        finalization: {
          noResultInstruction: "If there are no findings, submit reviewStatus:\"no_findings\", findings: []. Concrete unresolved risk may still use followUpHints or uncertainties."
        }
      })
    ).resolves.toMatchObject({
      reviewStatus: "no_findings",
      findings: [],
      followUpHints: [expect.objectContaining({ files: ["src/a.ts"] })]
    });
    expect(adapter.contexts[1]).toContain("decisive source evidence");
    expect(adapter.contexts[1]).toContain("Concrete unresolved risk may still use followUpHints");
    expect(telemetry.modelCalls[1]).toMatchObject({
      kind: "finalize",
      finalizeMode: "full",
      finalizeTarget: "no_findings"
    });
  });

  it("fills missing arrays while retaining the original optional no-finding explanation", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-xml-no-findings",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          noFindingReason: "Reviewed the packet and found no concrete failure mode.</noFindingReason>\n<parameter name=\"findings\">[]"
        }
      }]),
      assistant([validSubmitReviewCall("destructive-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-xml-no-findings", telemetry.recorder)))
      .resolves.toMatchObject({ findings: [], reviewStatus: "no_findings", noFindingReason: expect.stringContaining("Reviewed the packet") });
    expect(adapter.contexts).toHaveLength(2);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "field_repair_accepted" }));
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "recovery_obligation_resolved" }));
  });

  it("strips harmless extra candidate fields before model repair", async () => {
    const telemetry = fakeTelemetry();
    const candidate = validCandidateReviewFinding();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-candidate-extra-empty-field",
        name: "submit_review",
        arguments: {
          findings: [{ ...candidate, category_note: "" }],
          followUpHints: [],
          uncertainties: []
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-cleanup", telemetry.recorder),
        telemetryContext: { packetId: "packet-candidate-cleanup" }
      })
    ).resolves.toMatchObject({
      findings: [expect.objectContaining({ title: candidate.title })]
    });
    expect(adapter.contexts).toHaveLength(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({
      message: "submit_shape_correction_accepted",
      data: expect.objectContaining({ localEdits: [{ path: "findings.0.category_note", rule: "unknown_property" }] })
    }));
  });

  it("rejects lossy repair: truncates overlong Stage 7 no-finding reasons before model repair", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-long-no-findings",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          findings: [],
          followUpHints: [{
            question: "Does any caller rely on the old edge behavior?",
            files: ["app.ts"],
            symbols: ["handler"],
            suggestedLenses: ["core/code-review"],
            reason: "The packet found a concrete predicate worth checking, but no local failure mode.",
            confidence: "medium"
          }],
          uncertainties: [],
          noFindingReason: `No concrete issue found. ${"detail ".repeat(260)}`
        }
      }]),
      assistant([validSubmitReviewCall("destructive-repair")])
    ,
      assistant([validSubmitReviewCall("destructive-repair")])
    ,
      assistant([validSubmitReviewCall("destructive-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-long-no-findings", telemetry.recorder)))
      .rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(adapter.contexts).toHaveLength(4);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "field_repair_rejected" }));
    expect(telemetry.events).not.toContainEqual(expect.objectContaining({ message: "recovery_obligation_resolved" }));
  });

  it("strips redundant candidate anchor fields before model repair", async () => {
    const telemetry = fakeTelemetry();
    const anchor = { path: "src/a.ts", line: 12, side: "RIGHT", hunkId: "hunk-a" };
    const candidate: Record<string, unknown> = { ...validCandidateReviewFinding(), anchor };
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-candidate-extra-anchor-fields",
        name: "submit_review",
        arguments: {
          findings: [{
            ...candidate,
            line: anchor.line,
            hunkId: anchor.hunkId,
            changedLine: true,
            filePath: "src/a.ts"
          }],
          followUpHints: [],
          uncertainties: []
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-anchor-cleanup", telemetry.recorder),
        telemetryContext: { packetId: "packet-candidate-anchor-cleanup" }
      })
    ).resolves.toMatchObject({
      findings: [expect.objectContaining({ title: "Candidate finding" })]
    });
    expect(adapter.contexts).toHaveLength(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({
      message: "submit_shape_correction_accepted",
      data: expect.objectContaining({ localEdits: expect.arrayContaining(["changedLine", "filePath", "hunkId", "line"].map(key => ({ path: `findings.0.${key}`, rule: "unknown_property" }))) })
    }));
  });

  it("rejects lossy repair: salvages a no-findings packet whose prose mentions candidate/title without misrouting to candidate repair", async () => {
    // Regression guard for the run-24 misclassification: a no_findings payload whose prose
    // happens to contain words like "candidate" or "title" must NOT be treated as a candidate
    // submission. It should be salvaged deterministically as no_findings (no model re-prompt),
    // with its follow-up hint preserved.
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-prose-no-findings",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          findings: [],
          followUpHints: [{
            question: "Does any caller depend on the old fallback?",
            files: ["app.ts"],
            symbols: ["handler"],
            suggestedLenses: ["core/code-review"],
            reason: "Concrete predicate worth checking, but no local failure mode in this packet.",
            confidence: "medium"
          }],
          uncertainties: [],
          noFindingReason: `This could be a candidate for a future refactor, and the function title changed, but no concrete failure mode exists. ${"detail ".repeat(200)}`
        }
      }]),
      assistant([validSubmitReviewCall("destructive-repair")])
    ,
      assistant([validSubmitReviewCall("destructive-repair")])
    ,
      assistant([validSubmitReviewCall("destructive-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-prose-no-findings", telemetry.recorder)))
      .rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(adapter.contexts).toHaveLength(4);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "field_repair_rejected" }));
    expect(telemetry.events).not.toContainEqual(expect.objectContaining({ message: "recovery_obligation_resolved" }));
  });

  it("repairs candidate-shaped invalid submissions with compact replacement context", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-invalid-candidate",
        name: "submit_review",
        arguments: {
          findings: [{ title: "Candidate finding" }],
          followUpHints: [],
          uncertainties: []
        }
      }]),
      assistant([validCandidateSubmitReviewCall("submit-valid-after-candidate-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-repair", telemetry.recorder),
        telemetryContext: { packetId: "packet-candidate-repair" }
      })
    ).resolves.toMatchObject({ findings: [expect.objectContaining({ title: "Candidate finding" })] });
    expect(adapter.contexts[1]).toContain("supply the missing or invalid field values");
    expect(adapter.contexts[1]).toContain("retained-submission");
    expect(adapter.contexts[1]).not.toContain("review packet-candidate-repair");
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 7,
        message: "stage7_schema_repair_attempted",
        packetId: "packet-candidate-repair",
        data: expect.objectContaining({ classification: "missing_required_finding_fields" })
      }),
      expect.objectContaining({
        stage: 7,
        message: "stage7_schema_compact_repair_scheduled",
        packetId: "packet-candidate-repair",
        data: expect.objectContaining({
          classification: "missing_required_finding_fields",
          replaceConversation: true
        })
      }),
      expect.objectContaining({
        stage: 7,
        message: "stage7_schema_repair_recovered",
        packetId: "packet-candidate-repair",
        data: expect.objectContaining({ classification: "schema_valid_after_retry" })
      })
    ]));
  });

  it("strips substantive unexpected candidate fields without a repair", async () => {
    const telemetry = fakeTelemetry();
    const candidate = validCandidateReviewFinding();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-candidate-extra-substantive-field",
        name: "submit_review",
        arguments: {
          findings: [{ ...candidate, category_note: "Model intended this as a correctness issue." }],
          followUpHints: [],
          uncertainties: []
        }
      }]),
      assistant([validCandidateSubmitReviewCall("submit-repaired-substantive-field")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-substantive-extra", telemetry.recorder),
        telemetryContext: { packetId: "packet-candidate-substantive-extra" }
      })
    ).resolves.toMatchObject({ findings: [candidate] });
    expect(adapter.contexts).toHaveLength(1);
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "submit_shape_correction_accepted", data: expect.objectContaining({ localEdits: [{ path: "findings.0.category_note", rule: "unknown_property" }] }) }));
  });

  it("does not guess invalid candidate enum values locally", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-candidate-invalid-enum",
        name: "submit_review",
        arguments: {
          findings: [{ ...validCandidateReviewFinding(), category: "bug" }],
          followUpHints: [],
          uncertainties: []
        }
      }]),
      assistant([validCandidateSubmitReviewCall("submit-repaired-invalid-enum")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-invalid-enum", telemetry.recorder),
        telemetryContext: { packetId: "packet-candidate-invalid-enum" }
      })
    ).resolves.toMatchObject({ findings: [expect.objectContaining({ category: "correctness" })] });
    expect(adapter.contexts[1]).not.toContain("review packet-candidate-invalid-enum");
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 7,
        message: "stage7_schema_compact_repair_scheduled",
        packetId: "packet-candidate-invalid-enum",
        data: expect.objectContaining({ classification: "invalid_enum_value" })
      })
    ]));
  });

  it("fails Stage 7 schema repair after three malformed candidate repairs", async () => {
    const telemetry = fakeTelemetry();
    const invalidCandidate = (id: string): PiToolCall => ({
      type: "toolCall",
      id,
      name: "submit_review",
      arguments: {
        findings: [{ title: "Candidate finding" }],
        followUpHints: [],
        uncertainties: []
      }
    });
    const adapter = scriptedAdapter([
      assistant([invalidCandidate("submit-invalid-candidate-1")]),
      assistant([invalidCandidate("submit-invalid-candidate-2")])
    ,
      assistant([invalidCandidate("submit-invalid-candidate-2")])
    ,
      assistant([invalidCandidate("submit-invalid-candidate-2")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-repair-fails", telemetry.recorder),
        telemetryContext: { packetId: "packet-candidate-repair-fails" }
      })
    ).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 7,
        message: "stage7_schema_repair_failed",
        packetId: "packet-candidate-repair-fails",
        data: expect.objectContaining({ classification: "missing_required_finding_fields" })
      })
    ]));
  });

  it("rejects candidate repair that downgrades malformed findings to no-findings", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-invalid-candidate",
        name: "submit_review",
        arguments: {
          findings: [{ title: "Candidate finding" }],
          followUpHints: [],
          uncertainties: []
        }
      }]),
      assistant([validSubmitReviewCall("submit-no-findings-after-candidate-repair")])
    ,
      assistant([validSubmitReviewCall("submit-no-findings-after-candidate-repair")])
    ,
      assistant([validSubmitReviewCall("submit-no-findings-after-candidate-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-candidate-not-no-findings"),
        telemetryContext: { packetId: "packet-candidate-not-no-findings" }
      })
    ).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "field_repair_rejected" }));
  });

  it("does not salvage no-findings after a prior candidate-shaped Stage 7 submit", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{
        type: "toolCall",
        id: "submit-invalid-candidate",
        name: "submit_review",
        arguments: {
          findings: [{ title: "Candidate finding" }],
          followUpHints: [],
          uncertainties: []
        }
      }]),
      assistant([{
        type: "toolCall",
        id: "submit-xml-no-findings-after-candidate",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          noFindingReason: "No findings.</noFindingReason><parameter name=\"findings\">[]"
        }
      }])
    ,
      assistant([{
        type: "toolCall",
        id: "submit-xml-no-findings-after-candidate",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          noFindingReason: "No findings.</noFindingReason><parameter name=\"findings\">[]"
        }
      }])
    ,
      assistant([{
        type: "toolCall",
        id: "submit-xml-no-findings-after-candidate",
        name: "submit_review",
        arguments: {
          reviewStatus: "no_findings",
          noFindingReason: "No findings.</noFindingReason><parameter name=\"findings\">[]"
        }
      }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-no-salvage-after-candidate", telemetry.recorder),
        telemetryContext: { packetId: "packet-no-salvage-after-candidate" }
      })
    ).rejects.toMatchObject({ code: "llm_schema_invalid" });
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 7,
        message: "stage7_schema_repair_failed",
        packetId: "packet-no-salvage-after-candidate"
      })
    ]));
  });

  it("adds configured post-tool close nudges before continuing packet review", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-before-nudge",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ]),
      assistant([validSubmitReviewCall("submit-after-nudge")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-nudge"),
      tools: [{
        name: "read_range",
        description: "read",
        parameters: Type.Object({ path: Type.String() }),
        execute: vi.fn(async () => ({ text: "line 1", meta: { backend: "text" as const, precision: "exact" as const, degraded: false } }))
      }],
      toolBudget: { maxToolCalls: 3, maxInvestigationRounds: 3, maxResultChars: 1000 },
      finalization: {
        buildPostToolNudge: () => "NUDGE: submit no findings unless the next tool is decisive."
      }
    });
    expect(adapter.contexts[1]).toContain("NUDGE: submit no findings");
    expect(adapter.contexts[1]).toContain("Local investigation target remaining: 2 tool calls; 2 investigation rounds; 994 result characters");
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({ message: "post_tool_close_nudge" })
    ]));
  });

  it("allows a source-read recovery after crossing the outline batch soft target", async () => {
    const telemetry = fakeTelemetry();
    const outline = vi.fn(async () => ({ text: "imports" }));
    const read = vi.fn(async () => ({ text: "complete source" }));
    const adapter = scriptedAdapter([
      assistant(Array.from({ length: 3 }, (_, i) => ({ type: "toolCall" as const, id: `outline-${i}`, name: "read_file_outline", arguments: { path: `file-${i}.custom` } }))),
      assistant([{ type: "toolCall", id: "source", name: "read_range", arguments: { path: "file-2.custom", startLine: 1, endLine: 20 } }]),
      assistant([validSubmitReviewCall("done")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("outline-refusals"), tools: [
      { name: "read_file_outline", description: "outline", parameters: Type.Object({ path: Type.String() }), execute: outline },
      { name: "read_range", description: "read", parameters: Type.Object({ path: Type.String(), startLine: Type.Integer(), endLine: Type.Integer() }), execute: read }
    ], toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 4000, sourceExtension: { maxToolCalls: 1, maxResultChars: 4000 } } });
    expect(outline).toHaveBeenCalledTimes(3);
    expect(read).toHaveBeenCalledTimes(1);
    expect(adapter.contexts[1]).toContain("target has been reached");
    expect(adapter.toolNames[1]).toContain("read_range");
    expect(telemetry.toolCalls[3]).toMatchObject({ status: "ok", budgetState: { toolCallsUsed: 3, maxToolCalls: 4 } });
    expect(telemetry.events.filter(event => event.message === "tool_budget_extension_granted")).toHaveLength(0);
  });

  it("bounds invalid requests separately without consuming source-call slots", async () => {
    const telemetry = fakeTelemetry();
    const read = vi.fn(async () => ({ text: "source" }));
    const adapter = scriptedAdapter([
      assistant(Array.from({ length: 4 }, (_, i) => ({ type: "toolCall" as const, id: `invalid-${i}`, name: "read_range", arguments: {} }))),
      assistant([validSubmitReviewCall("done")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("invalid-request-limit"), tools: [{ name: "read_range", description: "read",
      parameters: Type.Object({ path: Type.String() }), execute: read }],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 10, maxResultChars: 100, sourceExtension: { maxToolCalls: 1, maxResultChars: 100 } } });
    expect(read).not.toHaveBeenCalled();
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "tool_refusal_limit_reached" }));
    expect(telemetry.events).toContainEqual(expect.objectContaining({ message: "tool_budget_remaining", data: expect.objectContaining({ ordinaryCalls: 2, resultChars: 100, rejectedCalls: 4 }) }));
    expect(adapter.toolNames[1]).toEqual(["submit_review"]);
  });

  it.each([undefined, 1.5, true, "1.5"])("corrects invalid range bounds (%s) without SDK coercion or a provider failure", async startLine => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({ text: "complete requested range" }));
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "missing-start", name: "read_range", arguments: { path: "policy.custom", ...(startLine === undefined ? {} : { startLine }), endLine: 30 } }]),
      assistant([{ type: "toolCall", id: "corrected", name: "read_range", arguments: { path: "policy.custom", startLine: 1, endLine: 30 } }]),
      assistant([validSubmitReviewCall("done")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    let summaries: import("../src/llm/llm-runner.js").LlmToolResultSummary[] = [];
    await runner.runStructured({ ...submitReviewRequest("correct-invalid-range"), onToolResults: results => { summaries = results; },
      tools: [{ name: "read_range", description: "read", parameters: Type.Object({ path: Type.String(), startLine: Type.Integer(), endLine: Type.Integer() }), execute }],
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 2, maxResultChars: 1000 } });
    expect(execute).toHaveBeenCalledTimes(1);
    expect(adapter.contexts[1]).toContain("startLine");
    expect(telemetry.toolCalls[0]).toMatchObject({ errorCode: "invalid_args", backendExecuted: false });
    expect(telemetry.toolCalls[1]).toMatchObject({ status: "ok", budgetState: { toolCallsUsed: 0 } });
    expect(unresolvedToolDiagnostic(7, summaries, "packet")).toBeUndefined();
  });

  it("caps discovery matches while preserving an ordinary source read in the same batch", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "broad", name: "search_files", arguments: {} },
        { type: "toolCall", id: "source", name: "read_range", arguments: { path: "src/a.ts", startLine: 1, endLine: 80 } }
      ]), assistant([validSubmitReviewCall("done")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const source = "source branch\n".repeat(100);
    await runner.runStructured({ ...submitReviewRequest("bounded-discovery"), tools: [
      { name: "search_files", description: "search", parameters: Type.Object({}), execute: async () => ({ text: "large search",
        searchResults: Array.from({ length: 80 }, (_, i) => ({ path: `src/a${i}.ts`, line: 1, column: 1, matchText: "a matching definition" })),
        meta: { backend: "text" as const, precision: "text" as const, degraded: false } }) },
      { name: "read_range", description: "read", parameters: Type.Object({ path: Type.String(), startLine: Type.Integer(), endLine: Type.Integer() }), execute: async () => ({ text: source }) }
    ], toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 1, maxResultChars: 4000, maxDiscoveryResultChars: 1000, reservedSourceResultChars: 2000 } });
    expect(telemetry.toolCalls[0]).toMatchObject({ status: "ok", truncated: true });
    expect(telemetry.toolCalls[0]!.resultChars).toBeLessThanOrEqual(1000);
    expect(telemetry.toolCalls[1]).toMatchObject({ status: "ok", resultChars: source.length });
    expect(adapter.contexts[0]).toContain("Discovery per-result cap: 1000");
  });

  it.each([
    { size: 1000, kind: "source", remainingReserve: 3000, discovery: 6000 },
    { size: 4000, kind: "source", remainingReserve: 0, discovery: 6000 },
    { size: 8000, kind: "source", remainingReserve: 0, discovery: 2000 },
    { size: 1000, kind: "error", remainingReserve: 4000, discovery: 5000 },
    { size: 1000, kind: "missing", remainingReserve: 4000, discovery: 5000 },
    { size: 1000, kind: "empty", remainingReserve: 4000, discovery: 5000 }
  ])("credits delivered source against the reserve, not errors/empty lookups: $kind/$size", async ({ size, kind, remainingReserve, discovery }) => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "source", name: "read_range", arguments: {} }]),
      assistant([{ type: "toolCall", id: "search", name: "search_files", arguments: {} }]),
      assistant([validSubmitReviewCall("done")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("reserve-credit"), tools: [
      { name: "read_range", description: "read", parameters: Type.Object({}), execute: async () => ({ text: "s".repeat(size),
        ...(kind === "error" ? { isError: true } : {}),
        meta: { backend: "text" as const, precision: "text" as const, degraded: false,
          lookupStatus: kind === "missing" ? "not_found" as const : "found" as const,
          deliveryStatus: kind === "empty" ? "empty" as const : "full" as const } }) },
      { name: "search_files", description: "search", parameters: Type.Object({}), execute: async () => ({ text: "hit" }) }
    ], toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 10000, reservedSourceResultChars: 4000 } });
    expect(telemetry.toolCalls[1]).toMatchObject({ status: "ok", budgetState: {
      remainingSourceReserveChars: remainingReserve, toolResultCharLimit: 20000 - size
    } });
    expect(telemetry.events.filter(event => event.message === "tool_budget_remaining")[0]?.data)
      .toMatchObject({ remainingSourceReserveChars: remainingReserve, discoveryResultChars: discovery });
  });

  it("allows a final discovery request after the source reserve has already been satisfied", async () => {
    const telemetry = fakeTelemetry();
    const calls = [1198, 1497, 1927, 1215, 3941].map((size, i): PiToolCall => ({
      type: "toolCall", id: `call-${i}`, name: i === 3 ? "list_files" : "read_range", arguments: { size }
    }));
    const adapter = scriptedAdapter([assistant(calls),
      assistant([{ type: "toolCall", id: "search", name: "search_files", arguments: { size: 2000 } }]),
      assistant([validSubmitReviewCall("done")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("reserve-regression"), tools:
      ["read_range", "list_files", "search_files"].map(name => ({ name, description: name,
        parameters: Type.Object({ size: Type.Number() }), execute: async (args: Record<string, unknown>) => ({ text: "s".repeat(Number(args.size)) }) })),
      toolBudget: { maxToolCalls: 6, maxInvestigationRounds: 2, maxResultChars: 12000,
        maxDiscoveryResultChars: 4000, reservedSourceResultChars: 4000 } });
    expect(telemetry.toolCalls[5]).toMatchObject({ status: "ok", resultChars: 2000,
      budgetState: { resultCharsUsed: 9778, sourceResultCharsUsed: 8563, remainingSourceReserveChars: 0, toolResultCharLimit: 4000 } });
    expect(telemetry.events.filter(event => event.message === "tool_budget_remaining").at(-1)?.data)
      .toMatchObject({ resultChars: 222, discoveryResultChars: 222 });
  });

  it("reports batch consumption and the source-only reserve before the next model call", async () => {
    const telemetry = fakeTelemetry();
    const call = (line: number): PiToolCall => ({ type: "toolCall", id: `read-${line}`, name: "read_range",
      arguments: { path: "src/a.ts", startLine: line, endLine: line } });
    const adapter = scriptedAdapter([
      assistant([call(1), call(2)]), assistant([call(3)]), assistant([validSubmitReviewCall("done")])
    ]);
    const execute = vi.fn(async () => ({ text: "1234567890" }));
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal,
      adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });
    await runner.runStructured({ ...submitReviewRequest("budget-feedback"),
      tools: [{ name: "read_range", description: "read",
        parameters: Type.Object({ path: Type.String(), startLine: Type.Number(), endLine: Type.Number() }), execute }],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 4, maxResultChars: 100,
        reservedSourceResultChars: 20, maxSingleToolResultChars: 40,
        sourceExtension: { maxToolCalls: 1, maxResultChars: 50 } }
    });
    expect(adapter.contexts[0]).toContain("2 tool calls; 4 investigation rounds; 100 result characters (80 within the discovery target)");
    expect(adapter.contexts[1]).toContain("0 tool calls; 3 investigation rounds; 80 result characters");
    expect(adapter.contexts[1]).toContain("target has been reached");
    expect(adapter.contexts[1]).toContain("Per-result cap: 40 characters");
    expect(adapter.contexts[2]).not.toContain("No further repository tool calls are allowed");
    expect(execute).toHaveBeenCalledTimes(3);
    expect(telemetry.events.filter(event => event.message === "tool_budget_remaining").map(event => event.data))
      .toEqual([
        expect.objectContaining({ ordinaryCalls: 0, investigationRounds: 3, resultChars: 80,
          sourceResultCharsUsed: 20, remainingSourceReserveChars: 0,
          hardRemaining: { toolCalls: 2, investigationRounds: 7, resultChars: 180 } }),
        expect.objectContaining({ ordinaryCalls: 0, investigationRounds: 2, resultChars: 70,
          sourceResultCharsUsed: 30, remainingSourceReserveChars: 0,
          hardRemaining: { toolCalls: 1, investigationRounds: 6, resultChars: 170 } })
      ]);
    expect(telemetry.events.filter(event => event.message === "tool_budget_soft_target_reached")).toHaveLength(1);
  });

  it("normalizes tuple schemas to draft 2020-12 for provider tool registration", async () => {
    const providerToolsSeen: Array<Array<{ name: string; parameters: Record<string, unknown> }>> = [];
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async (_model, context) => {
        providerToolsSeen.push(context.tools as Array<{ name: string; parameters: Record<string, unknown> }>);
        return assistant([validSubmitPlanCall("submit-plan-normalized-schema")]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      stage: 5,
      prompt: "plan",
      schema: SubmitPlanSchema,
      templateVersion: "test-template",
      timeoutMs: 1000
    });

    const submitPlan = providerToolsSeen[0]?.find((tool) => tool.name === "submit_plan");
    const coverage = (submitPlan?.parameters.properties as Record<string, unknown>).coverage as Record<string, unknown>;
    const coverageItem = coverage.items as Record<string, unknown>;
    const coverageItemRequired = coverageItem.required as string[] | undefined;
    expect(coverageItemRequired ?? []).not.toContain("surroundingContextHints");
    const hints = (coverageItem.properties as Record<string, unknown>).surroundingContextHints as Record<string, unknown>;
    const hintItem = hints.items as Record<string, unknown>;
    const hintProperties = hintItem.properties as Record<string, unknown>;
    expect(hintProperties.kind).toMatchObject({
      description: expect.stringContaining("Mechanical context retrieval mode")
    });
    expect(hintProperties.symbol).toMatchObject({
      description: expect.stringContaining("For call_site, the callee/helper")
    });
    const lineRangeSchema = hintProperties.lineRange as Record<string, unknown>;
    expect(lineRangeSchema).toMatchObject({
      prefixItems: [expect.objectContaining({ type: "integer" }), expect.objectContaining({ type: "integer" })],
      items: false
    });
    expect(lineRangeSchema).not.toHaveProperty("additionalItems");
  });

  it.each(["full", "truncated", "error", "missing"] as const)("retains only usable source reads for reconciliation: %s", async mode => {
    const telemetry = fakeTelemetry();
    const tool: ToolDefinition = { name: "read_range", description: "read", parameters: Type.Object({ path: Type.String() }),
      execute: async () => ({ text: "return db.list(tenantId);", ...(mode === "error" ? { isError: true } : {}),
        meta: { backend: "text", precision: "exact", degraded: false, sourceUsed: "base",
          deliveryStatus: mode === "missing" ? "empty" : "full", lookupStatus: mode === "missing" ? "file_missing" : "found",
          ...(mode === "truncated" ? { truncated: true } : {}) } }) };
    const adapter = scriptedAdapter([assistant([{ type: "toolCall", id: "source", name: "read_range", arguments: { path: "store.ts" } }]),
      assistant([validSubmitReviewCall("done")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const captured: import("../src/llm/llm-runner.js").LlmToolResultSummary[] = [];
    await runner.runStructured({ ...submitReviewRequest("evidence"), tools: [tool], onToolResults: results => captured.push(...results),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 2000 } });
    expect(captured).toHaveLength(1);
    if (mode === "full") expect(captured[0]!.repositoryEvidence).toMatchObject([{ path: "store.ts", source: "base", text: "return db.list(tenantId);" }]);
    else expect(captured[0]!.repositoryEvidence).toBeUndefined();
  });

  it.each([
    { requested: undefined, used: undefined, expected: "head" },
    { requested: "base", used: undefined, expected: "base" },
    { requested: "auto", used: undefined, expected: undefined },
    { requested: "auto", used: "base", expected: "base" },
    { requested: "base", used: "head", expected: "head" }
  ] as const)("retains the actual source revision without guessing an unresolved auto lookup: %j", async ({ requested, used, expected }) => {
    const tool: ToolDefinition = { name: "read_symbol", description: "source", parameters: Type.Object({ path: Type.String(),
      source: Type.Optional(Type.Object({ kind: Type.String() })) }),
      execute: async () => ({ text: "complete source", meta: { backend: "text", precision: "exact", degraded: false,
        lookupStatus: "found", deliveryStatus: "full", ...(used ? { sourceUsed: used } : {}) } }) };
    const adapter = scriptedAdapter([assistant([{ type: "toolCall", id: "read", name: tool.name,
      arguments: { path: "policy.custom", ...(requested ? { source: { kind: requested } } : {}) } }]), assistant([validSubmitReviewCall("done")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const captured: import("../src/llm/llm-runner.js").LlmToolResultSummary[] = [];
    await runner.runStructured({ ...submitReviewRequest("source-revision"), tools: [tool], onToolResults: results => captured.push(...results),
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 2000 } });
    if (expected) expect(captured[0]?.repositoryEvidence?.[0]?.source).toBe(expected);
    else expect(captured[0]?.repositoryEvidence).toBeUndefined();
  });

  it.each([{ limit: 0, meta: true }, { limit: 38, meta: true }, { limit: 38, meta: false }])("counts a search refusal without losing its correction message: %j", async ({ limit, meta }) => {
    const telemetry = fakeTelemetry();
    const matches = [{ path: "src/store.ts", line: 1, matchText: "export function loadAccount() {}" }];
    const execute = vi.fn(async () => ({ text: JSON.stringify(matches), searchResults: matches,
      ...(meta ? { meta: { backend: "text" as const, precision: "text" as const, degraded: false } } : {}) }));
    const tool: ToolDefinition = { name: "search_files", description: "search", execute,
      parameters: Type.Object({ query: Type.String() }) };
    const adapter = scriptedAdapter([assistant([{ type: "toolCall", id: "search", name: "search_files", arguments: { query: "loadAccount" } }]),
      assistant([validSubmitReviewCall("done")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const captured: import("../src/llm/llm-runner.js").LlmToolResultSummary[] = [];
    await runner.runStructured({ ...submitReviewRequest("refusal"), tools: [tool], onToolResults: results => captured.push(...results),
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: limit, maxSingleToolResultChars: limit } });
    expect(execute).toHaveBeenCalledTimes(limit ? 1 : 0);
    expect(captured[0]).toMatchObject({ status: "rejected", errorCode: "budget_exhausted",
      rejectionReason: "tool_result_budget_exhausted", deliveryStatus: "budget_rejected" });
    const run = createRunTelemetry({ telemetryConfig: defaultConfig.telemetry });
    run.recorder.recordToolCall(telemetry.toolCalls[0]!);
    expect(run.recorder.snapshotContextPressure?.().toolBudgetRejections).toBe(1);
    expect(unresolvedToolDiagnostic(7, captured, "refusal")).toMatchObject({ kind: "incomplete", code: "budget_exhausted" });
    expect(unresolvedToolDiagnostic(7, [...captured, { id: "recovered", tool: "search_files", target: "loadAccount",
      requestKey: captured[0]!.requestKey!, status: "ok", resultChars: 2 }], "refusal")).toBeUndefined();
    expect(adapter.contexts[1]).toContain("not a zero-match result");
  });

  it("packs cached search data into complete JSON under each caller cap and records its scope", async () => {
    const telemetry = fakeTelemetry();
    const matches = Array.from({ length: 20 }, (_, index) => ({ path: "src/a.ts", line: index + 1, matchText: "needle " + "x".repeat(100) }));
    const execute = vi.fn(async () => ({ text: JSON.stringify(matches), searchResults: matches,
      meta: { backend: "text" as const, precision: "text" as const, degraded: false } }));
    const tool: ToolDefinition = { name: "search_files", description: "search", execute,
      parameters: Type.Object({ query: Type.String(), pathGlob: Type.String(), maxResults: Type.Number() }) };
    const lookup = (id: string): PiToolCall => ({ type: "toolCall", id, name: "search_files", arguments: { query: "needle", pathGlob: "src/{api,data}/**", maxResults: 20 } });
    const adapter = scriptedAdapter([assistant([lookup("small")]), assistant([validSubmitReviewCall("done-small")]), assistant([lookup("large")]), assistant([validSubmitReviewCall("done-large")])]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter, toolResultCache: createToolResultCache(),
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    for (const limit of [1200, 6000]) await runner.runStructured({ ...submitReviewRequest(`search-${limit}`), tools: [tool],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: limit, maxSingleToolResultChars: limit } });
    const delivered = [adapter.contexts[1]!, adapter.contexts[3]!].map(context => {
      const messages = JSON.parse(context) as Array<{role: string; content: Array<{ text: string }>}>;
      const text = messages.find(message => message.role === "toolResult")!.content[0]!.text;
      const payload = text.split("\n").slice(3, -3).join("\n");
      return { payload, parsed: JSON.parse(payload) };
    });
    expect(delivered[0]!.payload.length).toBeLessThanOrEqual(1200);
    expect(delivered[0]!.parsed.results.length).toBeGreaterThan(0);
    expect(delivered[0]!.parsed.results.length).toBeLessThan(20);
    expect(delivered[1]!.parsed.results).toHaveLength(20);
    expect(execute).toHaveBeenCalledTimes(1);
    expect(telemetry.toolCalls[1]).toMatchObject({ cacheStatus: "hit", args: { pathGlob: "src/{api,data}/**", maxResults: 20 } });
  });

  it("rejects tools before execution when result-character budget is exhausted", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "should not execute",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-budget",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ]),
      assistant([validSubmitReviewCall("submit-after-budget")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-budget"),
      tools: [tool],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 0 }
    });

    expect(execute).not.toHaveBeenCalled();
    expect(telemetry.toolCalls[0]).toMatchObject({
      status: "rejected",
      degradationReason: "tool_result_budget_exhausted",
      budgetState: {
        toolCallsUsed: 0,
        maxToolCalls: 4,
        investigationRoundsUsed: 1,
        maxInvestigationRounds: 4,
        resultCharsUsed: 0,
        maxResultChars: 0,
        remainingResultChars: 0
      },
      deliveryStatus: "budget_rejected",
      resultChars: expect.any(Number)
    });
    expect(telemetry.toolCalls[0]?.resultChars).toBeGreaterThan(0);
    expect(telemetry.toolCalls[0]?.truncated).not.toBe(true);
    expect(adapter.contexts[1]).toContain("tool result character budget exhausted");
    expect(adapter.contexts[1]).toContain("This tool call was not executed");
    expect(adapter.contexts[1]).toContain("not a zero-match result");
    expect(telemetry.toolCalls[0]?.degradationReason).not.toBe("budget_or_tool_rejected");
    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        message: "tool_call_rejected",
        data: expect.objectContaining({
          tool: "read_range",
          reason: "tool_result_budget_exhausted",
          budgetState: expect.objectContaining({ remainingResultChars: 0 })
        })
      })
    ]));
    expect(toolDebugRecord(telemetry, "mc-000001.tool-budget")).toMatchObject({
      artifactKind: "tool_call",
      outcome: {
        status: "rejected",
        rejectionReason: "tool_result_budget_exhausted",
        degradationReason: "tool_result_budget_exhausted",
        budgetState: expect.objectContaining({ maxResultChars: 0 })
      }
    });
  });

  it("distinguishes rejected searches from zero matches at the hard character ceiling", async () => {
    const telemetry = fakeTelemetry();
    const search = vi.fn(async () => ({ text: "[]" }));
    const read = vi.fn(async () => ({ text: "source hit" }));
    const adapter = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "reserved-read", name: "read_range", arguments: { path: "src/a.ts" } },
        { type: "toolCall", id: "empty-search", name: "search_files", arguments: { query: "absent" } },
        { type: "toolCall", id: "rejected-search-1", name: "search_files", arguments: { query: "helper" } },
        { type: "toolCall", id: "rejected-search-2", name: "search_files", arguments: { query: "caller" } }
      ]),
      assistant([validSubmitReviewCall("submit-after-reserved-read")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-search-status"),
      tools: [
        { name: "search_files", description: "search", parameters: Type.Object({ query: Type.String() }), execute: search },
        { name: "read_range", description: "read", parameters: Type.Object({ path: Type.String() }), execute: read }
      ],
      toolBudget: {
        maxToolCalls: 4, maxInvestigationRounds: 2,
        maxResultChars: 6, reservedSourceResultChars: 10
      }
    });

    expect(search).toHaveBeenCalledTimes(1);
    expect(read).toHaveBeenCalledTimes(1);
    const messages = JSON.parse(adapter.contexts[1]!) as Array<{
      role: string; toolCallId?: string; isError?: boolean; content: Array<{ text: string }>;
    }>;
    const results = messages.filter((message) => message.role === "toolResult");
    expect(results).toHaveLength(4);
    expect(results[1]).toMatchObject({ toolCallId: "empty-search", isError: false });
    expect(results[1]?.content[0]?.text).toContain("\n[]\n");
    expect(results[1]?.content[0]?.text).not.toContain("tool rejected");
    for (const result of results.slice(2, 4)) {
      expect(result.isError).toBe(true);
      expect(result.content[0]?.text).toContain("tool result character budget exhausted");
      expect(result.content[0]?.text).toContain("This tool call was not executed");
      expect(result.content[0]?.text).toContain("not a zero-match result");
    }
    expect(results[0]).toMatchObject({ toolCallId: "reserved-read", isError: false });
    expect(results[0]?.content[0]?.text).toContain("source hit");
    expect(telemetry.toolCalls[0]).toMatchObject({
      status: "ok", resultChars: 10,
      budgetState: { toolCallsUsed: 0, resultCharsUsed: 0, remainingResultChars: 12 }
    });
    for (const record of telemetry.toolCalls.slice(2, 4)) {
      expect(record).toMatchObject({ status: "rejected", errorCode: "budget_exhausted", backendExecuted: false, deliveryStatus: "budget_rejected" });
      expect(record.truncated).not.toBe(true);
      expect(record.resultChars).toBeGreaterThan(0);
    }
  });

  it.each([7, 8, 9] as const)("permits continuation past each soft target and finalizes at each hard ceiling in stage %i", async stage => {
    for (const dimension of ["maxToolCalls", "maxInvestigationRounds", "maxResultChars"] as const) {
      const telemetry = fakeTelemetry();
      const execute = vi.fn(async () => ({ text: "0123456789" }));
      const read = (id: string): PiToolCall => ({ type: "toolCall", id, name: "read_range", arguments: { path: "policy.custom" } });
      const adapter = scriptedAdapter([
        assistant([read("first")]), assistant([read("continuation")]),
        assistant([stage === 7 ? validSubmitReviewCall("done") : stage === 8
          ? { type: "toolCall", id: "done", name: "submit_system_review", arguments: { findings: [], resolvedHints: [] } }
          : validSubmitVerdictCall("done")])
      ]);
      const soft = { maxToolCalls: 10, maxInvestigationRounds: 10, maxResultChars: 1000,
        [dimension]: dimension === "maxResultChars" ? 10 : 1 };
      const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
        toolResultCache: createToolResultCache(), hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
      const common = { tools: [{ name: "read_range", description: "read", parameters: Type.Object({ path: Type.String() }), execute }],
        toolBudget: { ...soft, sourceExtension: { maxToolCalls: 100, maxResultChars: 10000 } }, timeoutMs: 1000 };
      if (stage === 7) await runner.runStructured({ ...submitReviewRequest("soft-hard"), ...common });
      else if (stage === 8) await runner.runStructured({ stage: 8, prompt: "review system", schema: SubmitSystemReviewSchema, templateVersion: "test", ...common });
      else await runner.runStructured({ stage: 9, prompt: "verify", schema: SubmitVerificationVerdictSchema, templateVersion: "test", ...common });

      expect(adapter.toolNames[1]).toContain("read_range");
      expect(adapter.toolNames[2]).toEqual([submitToolNameForStage(stage)]);
      expect(adapter.contexts[1]).toContain("target has been reached");
      expect(adapter.contexts[2]).toContain("No further repository tool calls are allowed");
      expect(telemetry.toolCalls.map(call => call.status)).toEqual(["ok", "ok"]);
      // A cache hit still spends one call and ten delivered characters.
      expect(execute).toHaveBeenCalledTimes(1);
      expect(telemetry.toolCalls[1]).toMatchObject({ cacheStatus: "hit" });
      expect(telemetry.modelCalls[2]).toMatchObject({ kind: "finalize" });
      const initial = telemetry.events.find(event => event.message === "tool_budget_initial")?.data;
      expect(initial).toMatchObject({ softLimits: soft, hardLimits: {
        maxToolCalls: soft.maxToolCalls * 2, maxInvestigationRounds: soft.maxInvestigationRounds * 2,
        maxResultChars: soft.maxResultChars * 2 } });
      expect(telemetry.events.filter(event => event.message === "tool_budget_soft_target_reached")).toHaveLength(1);
      expect(telemetry.events.some(event => event.message === "tool_budget_extension_granted")).toBe(false);
      expect(adapter.contexts[0]).toContain(`${soft.maxToolCalls} tool calls; ${soft.maxInvestigationRounds} investigation rounds; ${soft.maxResultChars} result characters`);
      expect(adapter.contexts[0]).not.toContain(`${soft.maxResultChars * 2} result characters`);
    }
  });

  it("delivers the full requested search after 11,996 characters without treating soft pressure as an evidence gap", async () => {
    const telemetry = fakeTelemetry();
    const summaries: import("../src/llm/llm-runner.js").LlmToolResultSummary[] = [];
    const call = (size: number, i: number): PiToolCall => ({ type: "toolCall", id: `read-${i}`, name: "read_range", arguments: { size } });
    const adapter = scriptedAdapter([
      assistant([4000, 4000, 3996].map(call)),
      assistant([{ type: "toolCall", id: "search", name: "search_files", arguments: {} }]),
      assistant([validSubmitReviewCall("done")])
    ]);
    const matches = [{ path: "policy.custom", line: 12, matchText: "decisive evidence" }];
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("four-chars-left"),
      onToolResults: results => summaries.push(...results), tools: [
        { name: "read_range", description: "read", parameters: Type.Object({ size: Type.Number() }), execute: async (args: Record<string, unknown>) => ({ text: "s".repeat(Number(args.size)) }) },
        { name: "search_files", description: "search", parameters: Type.Object({}), execute: async () => ({ text: JSON.stringify(matches), searchResults: matches }) }
      ], toolBudget: { maxToolCalls: 6, maxInvestigationRounds: 2, maxResultChars: 12000,
        reservedSourceResultChars: 4000, maxDiscoveryResultChars: 4000 } });
    expect(telemetry.toolCalls[3]).toMatchObject({ status: "ok", budgetState: { resultCharsUsed: 11996, toolResultCharLimit: 4000 } });
    expect(adapter.contexts[2]).toContain("decisive evidence");
    expect(adapter.toolNames[2]).toContain("search_files");
    expect(unresolvedToolDiagnostic(7, summaries, "four-chars-left")).toBeUndefined();
  });

  it("keeps global exhaustion authoritative during local continuation", async () => {
    let checkpoints = 0;
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "read", name: "read_range", arguments: {} }]),
      assistant([validSubmitReviewCall("global-closeout")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => ++checkpoints === 1 ? "ok" : "exhausted", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("global-stop"), tools: [
      { name: "read_range", description: "read", parameters: Type.Object({}), execute: async () => ({ text: "source" }) }
    ], toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 100 } });
    expect(checkpoints).toBe(2);
    expect(adapter.toolNames[1]).toEqual(["submit_review"]);
    expect(telemetry.toolCalls).toHaveLength(1);
    expect(telemetry.modelCalls[1]).toMatchObject({ kind: "finalize" });
  });

  it.each(["maxToolCalls", "maxInvestigationRounds", "maxResultChars"] as const)("keeps zero %s disabled even with legacy extensions", async dimension => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({ text: "must not run" }));
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "read", name: "read_range", arguments: {} }]),
      assistant([validSubmitReviewCall("done")])
    ]);
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await runner.runStructured({ ...submitReviewRequest("zero-disabled"), tools: [
      { name: "read_range", description: "read", parameters: Type.Object({}), execute }
    ], toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 100, [dimension]: 0,
      sourceExtension: { maxToolCalls: 100, maxResultChars: 10000 } } });
    expect(execute).not.toHaveBeenCalled();
    expect(telemetry.toolCalls[0]).toMatchObject({ status: "rejected", errorCode: "budget_exhausted" });
  });

  it("derives ceilings after boost scaling without multiplying per-result caps or source targets again", () => {
    const soft = scaleToolBudget({ maxToolCalls: 4, maxInvestigationRounds: 2, maxResultChars: 10000,
      maxSingleToolResultChars: 2000, maxDiscoveryResultChars: 1000, reservedSourceResultChars: 3000,
      sourceExtension: { maxToolCalls: 100, maxResultChars: 100000 } }, 1.5);
    expect(hardToolBudget(soft)).toEqual({ maxToolCalls: 12, maxInvestigationRounds: 6, maxResultChars: 30000,
      maxSingleToolResultChars: 3000, maxDiscoveryResultChars: 1500, reservedSourceResultChars: 4500 });
    expect(soft.maxResultChars).toBe(15000);
  });

  it("does not treat repository safety rejections as source budget extensions", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "tool error: path outside repository root",
      isError: true,
      errorCode: "path_outside_repo" as const,
      meta: { backend: "text" as const, precision: "text" as const, degraded: true, degradationReason: "path_outside_repo" }
    }));
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String(), startLine: Type.Number(), endLine: Type.Number() }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-path-outside",
          name: "read_range",
          arguments: { path: "../secret.ts", startLine: 1, endLine: 2 }
        }
      ]),
      assistant([validSubmitReviewCall("submit-after-path-outside")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-path-outside-extension"),
      tools: [tool],
      toolBudget: {
        maxToolCalls: 2,
        maxInvestigationRounds: 2,
        maxResultChars: 1000,
        sourceExtension: { maxToolCalls: 1, maxResultChars: 1000 }
      }
    });

    expect(execute).toHaveBeenCalledTimes(1);
    expect(telemetry.toolCalls[0]).toMatchObject({
      status: "rejected",
      errorCode: "path_outside_repo",
      degradationReason: "path_outside_repo",
      budgetState: expect.not.objectContaining({ sourceExtensionActive: true })
    });
    expect(telemetry.events).not.toEqual(expect.arrayContaining([
      expect.objectContaining({ message: "tool_budget_extension_granted" })
    ]));
  });

  it("scales source budget extension with the tool budget multiplier", () => {
    expect(scaleToolBudget({
      maxToolCalls: 4,
      maxInvestigationRounds: 2,
      maxResultChars: 10_000,
      sourceExtension: { maxToolCalls: 1, maxResultChars: 4_000 }
    }, 1.5)).toMatchObject({
      maxToolCalls: 6,
      maxInvestigationRounds: 3,
      maxResultChars: 15_000,
      sourceExtension: {
        maxToolCalls: 2,
        maxResultChars: 6_000
      }
    });
  });

  it("records precise tool-call budget rejection reason metadata", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "first result",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([
        { type: "toolCall", id: "tool-ok", name: "read_range", arguments: { path: "src/a.ts" } },
        { type: "toolCall", id: "tool-headroom", name: "read_range", arguments: { path: "src/b.ts" } },
        { type: "toolCall", id: "tool-call-budget", name: "read_range", arguments: { path: "src/b.ts" } }
      ]),
      assistant([validSubmitReviewCall("submit-after-tool-call-budget")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-tool-call-budget"),
      tools: [tool],
      toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 2, maxResultChars: 1000 }
    });

    expect(execute).toHaveBeenCalledTimes(2);
    expect(telemetry.toolCalls[2]).toMatchObject({
      status: "rejected",
      degradationReason: "tool_call_budget_exhausted",
      budgetState: expect.objectContaining({
        toolCallsUsed: 2,
        maxToolCalls: 2,
        resultCharsUsed: 2 * "first result".length,
        maxResultChars: 2000,
        remainingResultChars: 2000 - 2 * "first result".length
      })
    });
    expect(telemetry.toolCalls[2]?.degradationReason).not.toBe("budget_or_tool_rejected");
  });

  it("records precise investigation-round budget rejection reason metadata", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "should not execute",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "tool-round-budget", name: "read_range", arguments: { path: "src/a.ts" } }]),
      assistant([validSubmitReviewCall("submit-after-round-budget")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-round-budget"),
      tools: [tool],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 0, maxResultChars: 1000 }
    });

    expect(execute).not.toHaveBeenCalled();
    expect(telemetry.toolCalls[0]).toMatchObject({
      status: "rejected",
      degradationReason: "investigation_round_budget_exhausted",
      budgetState: expect.objectContaining({
        investigationRoundsUsed: 1,
        maxInvestigationRounds: 0,
        remainingResultChars: 2000
      })
    });
    expect(telemetry.toolCalls[0]?.degradationReason).not.toBe("budget_or_tool_rejected");
  });

  it("records precise unknown-tool rejection reason metadata", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "tool-unknown", name: "read_secret", arguments: { path: "src/a.ts" } }]),
      assistant([validSubmitReviewCall("submit-after-unknown-tool")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-unknown-tool"),
      tools: [],
      toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 1000 }
    });

    expect(telemetry.toolCalls[0]).toMatchObject({
      tool: "read_secret",
      status: "rejected",
      degradationReason: "unknown_tool",
      budgetState: expect.objectContaining({
        toolCallsUsed: 0,
        maxToolCalls: 4,
        remainingResultChars: 2000
      })
    });
    expect(telemetry.toolCalls[0]?.degradationReason).not.toBe("budget_or_tool_rejected");
  });

  it("caps large verifier tool results so later small helper source can still be delivered", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async (args: Record<string, unknown>) => {
      const symbolName = String(args.symbolName ?? "");
      return {
        text: symbolName === "LargeCaller" ? "large-caller\n".repeat(120) + "requireActiveMembership(user);\n" : "func SmallHelper() { return decisiveBranch }\n",
        meta: {
          backend: "tree-sitter" as const,
          precision: "syntactic" as const,
          degraded: false,
          lookupStatus: "found" as const,
          deliveryStatus: "full" as const
        }
      };
    });
    const readSymbol: ToolDefinition = {
      name: "read_symbol",
      description: "read symbol",
      parameters: Type.Object({ symbolName: Type.String() }, { additionalProperties: false }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([{ type: "toolCall", id: "large-read", name: "read_symbol", arguments: { symbolName: "LargeCaller" } }]),
      assistant([{ type: "toolCall", id: "small-read", name: "read_symbol", arguments: { symbolName: "SmallHelper" } }]),
      assistant([validSubmitVerdictCall("submit-after-small-helper")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        stage: 9,
        prompt: "verify helper-dependent finding",
        schema: SubmitVerificationVerdictSchema,
        templateVersion: "test-template",
        tools: [readSymbol],
        toolBudget: {
          maxToolCalls: 3,
          maxInvestigationRounds: 3,
          maxResultChars: 700,
          maxSingleToolResultChars: 300,
          reservedSourceResultChars: 200
        },
        timeoutMs: 1000
      })
    ).resolves.toMatchObject({ verdict: "reject" });

    expect(execute).toHaveBeenCalledTimes(2);
    expect(adapter.contexts[1]).toContain("[tool result truncated by codegenie tool budget]");
    expect(adapter.contexts[1]).not.toContain("requireActiveMembership(user)");
    expect(adapter.contexts[2]).toContain("SmallHelper");
    expect(adapter.contexts[2]).toContain("decisiveBranch");
    expect(telemetry.toolCalls[0]).toMatchObject({
      tool: "read_symbol",
      status: "ok",
      truncated: true,
      resultChars: 300,
      budgetState: expect.objectContaining({
        maxSingleToolResultChars: 300,
        toolResultCharLimit: 300
      })
    });
    expect(telemetry.toolCalls[1]).toMatchObject({
      tool: "read_symbol",
      status: "ok",
      deliveryStatus: "full",
      budgetState: expect.objectContaining({
        resultCharsUsed: 300,
        toolResultCharLimit: 300
      })
    });
    expect(telemetry.toolCalls[1]?.truncated).not.toBe(true);
  });

  it("rejects repository tools when request.toolBudget is absent", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "should not execute without explicit budget",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-no-budget",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ]),
      assistant([validSubmitReviewCall("submit-no-budget")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await runner.runStructured({
      ...submitReviewRequest("packet-no-budget"),
      tools: [
        {
          name: "read_range",
          description: "read",
          parameters: Type.Object({ path: Type.String() }),
          execute
        }
      ]
    });

    expect(execute).not.toHaveBeenCalled();
    expect(telemetry.toolCalls[0]).toMatchObject({
      status: "rejected",
      degradationReason: "tool_result_budget_exhausted",
      deliveryStatus: "budget_rejected",
      resultChars: expect.any(Number)
    });
    expect(telemetry.toolCalls[0]?.resultChars).toBeGreaterThan(0);
  });

  it("keeps schema repair available after a plain-text finalization nudge", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([{ type: "text", text: "plain text instead of submit" }]),
      assistant([
        {
          type: "toolCall",
          id: "submit-invalid-after-nudge",
          name: "submit_review",
          arguments: {}
        }
      ]),
      assistant([validSubmitReviewCall("submit-valid-after-repair")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-plain"))).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["ok", "schema_invalid", "ok"]);
  });

  it("retries once when forced finalization calls a non-submit tool", async () => {
    const telemetry = fakeTelemetry();
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute: vi.fn(async () => ({
        text: "line 1",
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      }))
    };
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-finalize",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ]),
      assistant([
        {
          type: "toolCall",
          id: "tool-during-finalize",
          name: "read_file",
          arguments: { path: "lib/quotes/parse.go" }
        }
      ]),
      assistant([validSubmitReviewCall("submit-after-finalize-tool-misfire")])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-finalize-text"),
        tools: [tool],
        toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 3 }
      })
    ).resolves.toMatchObject({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });
    expect(adapter.complete).toHaveBeenCalledTimes(3);
    expect(adapter.contexts[1]).not.toContain("reviewStatus");
    expect(adapter.contexts[1]).toContain("smallest schema-valid empty or negative result");
    expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["ok", "schema_invalid", "ok"]);
    expect(telemetry.modelCalls[1]).toMatchObject({
      kind: "finalize",
      schemaValid: false,
      errorCode: "llm_schema_invalid"
    });
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 7,
          level: "warn",
          message: "finalize_missing_submit_retry",
          data: expect.objectContaining({
            submitTool: "submit_review",
            unexpectedTools: ["read_file"]
          })
        })
      ])
    );
  });

  it("rejects forced finalization after the submit-only retry is ignored", async () => {
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute: vi.fn(async () => ({
        text: "line 1",
        meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
      }))
    };
    const adapter = scriptedAdapter([
      assistant([
        {
          type: "toolCall",
          id: "tool-before-finalize",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ]),
      assistant([{ type: "text", text: "plain text during finalization" }]),
      assistant([{ type: "text", text: "still no submit during finalization" }])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-finalize-text"),
        tools: [tool],
        toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 3 }
      })
    ).rejects.toMatchObject({
      code: "llm_schema_invalid",
      recoverable: true,
      context: {
        structuredSubmitFailure: expect.objectContaining({
          submitTool: "submit_review",
          classification: "missing_submit",
          attempt: "primary"
        })
      }
    });
    expect(adapter.complete).toHaveBeenCalledTimes(3);
  });

  it("records submit_with_extra_tools telemetry and ignores extra model tool calls", async () => {
    const telemetry = fakeTelemetry();
    const execute = vi.fn(async () => ({
      text: "should not execute when submit is present",
      meta: { backend: "text" as const, precision: "exact" as const, degraded: false }
    }));
    const tool: ToolDefinition = {
      name: "read_range",
      description: "read",
      parameters: Type.Object({ path: Type.String() }),
      execute
    };
    const adapter = scriptedAdapter([
      assistant([
        validSubmitReviewCall("submit-with-extra-tool"),
        {
          type: "toolCall",
          id: "ignored-tool",
          name: "read_range",
          arguments: { path: "src/a.ts" }
        }
      ])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-extra-tool"),
        tools: [tool],
        toolBudget: { maxToolCalls: 1, maxInvestigationRounds: 1, maxResultChars: 1000 },
        telemetryContext: { workerId: "worker-extra", packetId: "packet-extra" }
      })
    ).resolves.toEqual({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });

    expect(execute).not.toHaveBeenCalled();
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 7,
          level: "warn",
          message: "submit_with_extra_tools",
          workerId: "worker-extra",
          packetId: "packet-extra",
          data: expect.objectContaining({
            submitTool: "submit_review",
            ignoredTools: ["read_range"],
            count: 1
          })
        })
      ])
    );
  });

  it("records extra_submit_dropped telemetry when one response contains multiple submit calls", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistant([
        validSubmitReviewCall("submit-first"),
        validSubmitReviewCall("submit-second"),
        validSubmitReviewCall("submit-third")
      ])
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(
      runner.runStructured({
        ...submitReviewRequest("packet-extra-submit"),
        telemetryContext: { workerId: "worker-submit", packetId: "packet-extra-submit", candidateId: "candidate-extra-submit" }
      })
    ).resolves.toEqual({
      findings: [],
      followUpHints: [],
      uncertainties: []
    });

    expect(telemetry.events).toEqual(expect.arrayContaining([
      expect.objectContaining({
        stage: 7,
        level: "warn",
        message: "extra_submit_dropped",
        workerId: "worker-submit",
        packetId: "packet-extra-submit",
        data: expect.objectContaining({
          submitTool: "submit_review",
          callId: "submit-first",
          droppedToolCallCount: 2,
          droppedCallIds: ["submit-second", "submit-third"],
          candidateId: "candidate-extra-submit"
        })
      })
    ]));
  });

  it("does not retry non-auth 4xx provider errors", async () => {
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        const error = new Error("bad request") as Error & { status: number };
        error.status = 400;
        throw error;
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-400"))).rejects.toMatchObject({
      code: "llm_call_failed",
      recoverable: true,
      context: { reason: "request_error" }
    });
    expect(adapter.complete).toHaveBeenCalledTimes(1);
  });

  it("does not retry authentication provider errors", async () => {
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        const error = new Error("unauthorized api key") as Error & { status: number };
        error.status = 401;
        throw error;
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-auth"))).rejects.toMatchObject({
      code: "llm_call_failed",
      recoverable: false,
      context: { reason: "auth" }
    });
    expect(adapter.complete).toHaveBeenCalledTimes(1);
  });

  it("parses HTTP statuses only from status-coded provider error contexts", () => {
    expect([
      "HTTP 500 from provider",
      "status: 503",
      "statusCode = 429",
      "code 400"
    ].map((input) => __piRunnerTestHooks.parseHttpStatus(input))).toEqual([500, 503, 429, 400]);
    expect([
      "context of 500 tokens exceeded the window",
      "processed 429 files before stopping",
      "model claude-opus-4-8 400 does not exist"
    ].map((input) => __piRunnerTestHooks.parseHttpStatus(input))).toEqual([undefined, undefined, undefined]);
  });

  it("parses the status a provider prefixes onto the raw body", () => {
    expect([
      '400 {"type":"error","error":{"type":"invalid_request_error","message":"nope"}}',
      "429: slow down",
      "503 Service Unavailable"
    ].map((input) => __piRunnerTestHooks.parseHttpStatus(input))).toEqual([400, 429, 503]);
  });

  it("reports a usage-limit rejection as terminal without retrying", async () => {
    const body =
      '400 {"type":"error","error":{"type":"invalid_request_error","message":"You have reached your specified API usage limits. You will regain access on 2026-09-01 at 00:00 UTC."},"request_id":"req_011"}';
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        throw new Error(body);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-usage-limit"))).rejects.toMatchObject({
      code: "llm_call_failed",
      message: "LLM provider usage limit reached",
      recoverable: false,
      context: {
        reason: "usage_limit",
        providerMessage:
          "HTTP 400: You have reached your specified API usage limits. You will regain access on 2026-09-01 at 00:00 UTC."
      }
    });
    // A billing wall is not transient: one call, no backoff burn.
    expect(adapter.complete).toHaveBeenCalledTimes(1);
  });

  it("carries the provider explanation on ordinary request failures too", async () => {
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        throw new Error('400 {"type":"error","error":{"type":"invalid_request_error","message":"max_tokens too large"}}');
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-request-error"))).rejects.toMatchObject({
      code: "llm_call_failed",
      context: { reason: "request_error", providerMessage: "HTTP 400: max_tokens too large" }
    });
    expect(adapter.complete).toHaveBeenCalledTimes(1);
  });

  it("treats Pi stopReason error messages as provider failures instead of schema failures", async () => {
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([
      assistantError("HTTP status 400 model claude-opus-4-8 does not exist")
    ]);
    const runner = createPiRunner({
      llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder,
      logger: fakeLogger(),
      runSignal: new AbortController().signal,
      adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
    });

    await expect(runner.runStructured(submitReviewRequest("packet-provider-message-error"))).rejects.toMatchObject({
      code: "llm_call_failed",
      context: { reason: "request_error" }
    });

    expect(adapter.complete).toHaveBeenCalledTimes(1);
    expect(telemetry.modelCalls).toEqual([
      expect.objectContaining({
        status: "transient_error",
        stopReason: "error",
        errorCode: "llm_call_failed",
        errorMessage: "HTTP status 400 model claude-opus-4-8 does not exist",
        outputChars: 2
      })
    ]);
  });

  it("retries retryable provider errors three times and preserves trace context", async () => {
    const random = vi.spyOn(Math, "random").mockReturnValue(0);
    const telemetry = fakeTelemetry();
    let calls = 0;
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        calls += 1;
        if (calls <= 3) {
          const error = new Error("rate limited") as Error & { status: number; headers: Record<string, string> };
          error.status = 429;
          error.headers = { "retry-after": "0" };
          throw error;
        }
        return assistant([validSubmitReviewCall("submit-after-retry")]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    try {
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder,
        logger: fakeLogger(),
        runSignal: new AbortController().signal,
        adapter,
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });

      await runner.runStructured({
        ...submitReviewRequest("packet-retry"),
        telemetryContext: { workerId: "worker-retry", packetId: "packet-retry", candidateId: "candidate-retry" }
      });

      expect(adapter.complete).toHaveBeenCalledTimes(4);
      expect(telemetry.modelCalls.map((call) => call.attempt)).toEqual([1, 2, 3, 4]);
      expect(telemetry.modelCalls.map((call) => call.status)).toEqual(["transient_error", "transient_error", "transient_error", "ok"]);
      expect(telemetry.modelCalls).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            workerId: "worker-retry",
            packetId: "packet-retry",
            candidateId: "candidate-retry"
          })
        ])
      );
      expect(telemetry.modelCalls.every((call) => call.workerId === "worker-retry")).toBe(true);
    } finally {
      random.mockRestore();
    }
  });

  it("retries provider overload messages without an HTTP status for all configured attempts", async () => {
    const random = vi.spyOn(Math, "random").mockReturnValue(0);
    const telemetry = fakeTelemetry();
    let calls = 0;
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        calls += 1;
        if (calls <= 3) {
          return assistantError('{"type":"error","error":{"type":"overloaded_error","message":"Overloaded"}}');
        }
        return assistant([validSubmitReviewCall("submit-after-overload")]);
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    try {
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder,
        logger: fakeLogger(),
        runSignal: new AbortController().signal,
        adapter,
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });

      await runner.runStructured(submitReviewRequest("packet-overload"));

      expect(adapter.complete).toHaveBeenCalledTimes(4);
      expect(telemetry.modelCalls.map((call) => call.attempt)).toEqual([1, 2, 3, 4]);
      expect(telemetry.modelCalls.slice(0, 3).every((call) =>
        call.status === "transient_error" &&
        call.retryable === true &&
        call.retryReason === "provider_overloaded" &&
        call.maxAttempts === 4
      )).toBe(true);
      expect(telemetry.modelCalls[3]).toMatchObject({ status: "ok", attempt: 4 });
      expect(telemetry.events.filter((event) => event.message === "provider_retry_scheduled")).toHaveLength(3);
    } finally {
      random.mockRestore();
    }
  });

  it("treats persistent retryable provider errors as recoverable task failures", async () => {
    const random = vi.spyOn(Math, "random").mockReturnValue(0);
    const telemetry = fakeTelemetry();
    const adapter: PiAiAdapter = {
      resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model" } }),
      complete: vi.fn(async () => {
        const error = new Error("provider unavailable") as Error & { status: number };
        error.status = 503;
        throw error;
      }),
      validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
    };
    try {
      const runner = createPiRunner({
        llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
        telemetry: telemetry.recorder,
        logger: fakeLogger(),
        runSignal: new AbortController().signal,
        adapter,
        hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
      });

      await expect(runner.runStructured(submitReviewRequest("packet-provider-down"))).rejects.toMatchObject({
        code: "llm_call_failed",
        recoverable: true,
        context: { reason: "transient_error" }
      });
      expect(adapter.complete).toHaveBeenCalledTimes(4);
      expect(telemetry.modelCalls.at(-1)).toMatchObject({
        attempt: 4,
        retryable: true,
        retryReason: "server_error",
        retryExhausted: true
      });
      expect(telemetry.events).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            message: "provider_retry_exhausted",
            data: expect.objectContaining({ retryReason: "server_error", maxAttempts: 4 })
          })
        ])
      );
    } finally {
      random.mockRestore();
    }
  });

  it("resolves provider-qualified real models only when auth is usable", () => {
    const previous = process.env.OPENAI_API_KEY;
    process.env.OPENAI_API_KEY = "plain-provider-qualified-secret";
    clearRegisteredSecretsForTests();
    try {
      const model = createRealPiAiAdapter().resolveModel({ model: "openai/gpt-4.1-mini" });
      expect(model).toMatchObject({
        provider: "openai",
        id: "gpt-4.1-mini",
        apiKey: "plain-provider-qualified-secret"
      });
      expect(stripCredentials("error plain-provider-qualified-secret")).toBe("error [redacted:secret]");
    } finally {
      if (previous === undefined) {
        delete process.env.OPENAI_API_KEY;
      } else {
        process.env.OPENAI_API_KEY = previous;
      }
      clearRegisteredSecretsForTests();
    }
  });

  it("does not resolve deprecated real Pi models even when auth is usable", () => {
    const previous = process.env.ANTHROPIC_API_KEY;
    process.env.ANTHROPIC_API_KEY = "plain-deprecated-anthropic-secret";
    clearRegisteredSecretsForTests();
    try {
      expect(
        createRealPiAiAdapter().resolveModel({
          provider: "anthropic",
          model: "claude-3-5-haiku-20241022"
        })
      ).toBeUndefined();
      const fallback = createRealPiAiAdapter().resolveModel({ provider: "anthropic" });
      expect(fallback?.id).not.toMatch(/^claude-3/u);
    } finally {
      if (previous === undefined) {
        delete process.env.ANTHROPIC_API_KEY;
      } else {
        process.env.ANTHROPIC_API_KEY = previous;
      }
      clearRegisteredSecretsForTests();
    }
  });

  it("rejects unknown real model ids during runner construction", () => {
    const previous = process.env.OPENAI_API_KEY;
    process.env.OPENAI_API_KEY = "plain-unknown-model-secret";
    clearRegisteredSecretsForTests();
    try {
      expect(() =>
        createPiRunner({
          llmConfig: {
            model: "openai/not-a-real-codegenie-test-model",
            maxConcurrentCalls: 1
          },
          telemetry: fakeTelemetry().recorder,
          logger: fakeLogger(),
          runSignal: new AbortController().signal,
          hooks: { checkpoint: () => "ok", onUsage: vi.fn() }
        })
      ).toThrow(CodegenieError);
    } finally {
      if (previous === undefined) {
        delete process.env.OPENAI_API_KEY;
      } else {
        process.env.OPENAI_API_KEY = previous;
      }
      clearRegisteredSecretsForTests();
    }
  });

  it("uses Pi streamSimple so resolved reasoning is provider-mapped", async () => {
    const optionsSeen: Record<string, unknown>[] = [];
    const streamSimple = ((_model, _context, options) => {
      optionsSeen.push(options as Record<string, unknown>);
      return streamForMessage(assistant([validSubmitReviewCall("submit-simple-reasoning")]));
    }) as PiStreamSimpleForTest;
    const adapter = createRealPiAiAdapter({ streamSimple });

    await adapter.complete(
      { provider: "fake", id: "fake-model", raw: { id: "fake-model" }, apiKey: "fake-api-key" },
      { messages: [], tools: [] },
      { reasoning: "xhigh", maxRetries: 0, submitToolName: "submit_review", onRejectedArguments: vi.fn() }
    );

    expect(optionsSeen).toEqual([
      expect.objectContaining({
        apiKey: "fake-api-key",
        reasoning: "xhigh"
      })
    ]);
    expect(optionsSeen[0]).not.toHaveProperty("submitToolName");
    expect(optionsSeen[0]).not.toHaveProperty("onRejectedArguments");
  });

  it("delivers rejected-argument diagnostics through both real Pi streaming paths", async () => {
    for (const toolChoice of ["auto", { type: "tool", name: "submit_review" }]) {
      const onRejectedArguments = vi.fn();
      const providerOptions: Record<string, unknown>[] = [];
      const stream = ((_model: unknown, _context: unknown, options: unknown) => {
        providerOptions.push(options as Record<string, unknown>);
        return streamForMessage(assistant([validSubmitReviewCall("malformed")]), '{"findings":');
      });
      const adapter = createRealPiAiAdapter({ stream: stream as PiStreamForTest, streamSimple: stream as PiStreamSimpleForTest });
      const result = await adapter.complete({ provider: "fake", id: "fake-model", raw: { id: "fake-model", api: "openai-completions" }, apiKey: "fake-api-key" },
        { messages: [], tools: [] }, { toolChoice, submitToolName: "submit_review", onRejectedArguments });
      expect(onRejectedArguments).toHaveBeenCalledWith(expect.objectContaining({ toolCallId: "malformed", prefix: '{"findings":' }));
      expect(result.content[0]).toMatchObject({ type: "invalidToolCall", syntaxDiagnostic: { excerpt: '{"findings":' } });
      expect(result.content[0]).not.toHaveProperty("arguments");
      expect(providerOptions[0]).not.toHaveProperty("onRejectedArguments");
    }
  });

  it("maps forced submit calls to raw Pi provider reasoning and tool choice options", async () => {
    const rawOptionsSeen: Record<string, unknown>[] = [];
    const stream = ((_model, _context, options) => {
      rawOptionsSeen.push(options as Record<string, unknown>);
      return streamForMessage(assistant([validSubmitReviewCall("submit-raw-forced")]));
    }) as PiStreamForTest;
    const streamSimple = vi.fn(() => streamForMessage(assistant([validSubmitReviewCall("must-not-use-simple")]))) as unknown as PiStreamSimpleForTest;
    const adapter = createRealPiAiAdapter({ stream, streamSimple });

    await adapter.complete(
      {
        provider: "openai",
        id: "gpt-test",
        raw: { api: "openai-completions", provider: "openai", id: "gpt-test", maxTokens: 4096, reasoning: true },
        apiKey: "fake-api-key"
      },
      { messages: [], tools: [] },
      { reasoning: "high", toolChoice: { type: "tool", name: "submit_review" }, maxRetries: 0, submitToolName: "submit_review" }
    );

    expect(streamSimple).not.toHaveBeenCalled();
    expect(rawOptionsSeen).toEqual([
      expect.objectContaining({
        apiKey: "fake-api-key",
        reasoningEffort: "high",
        toolChoice: { type: "function", function: { name: "submit_review" } }
      })
    ]);
    expect(rawOptionsSeen[0]).not.toHaveProperty("reasoning");
  });

  it("disables Anthropic thinking and applies real forced tool choice for submit turns (plan 86 step 3)", async () => {
    const rawOptionsSeen: Record<string, unknown>[] = [];
    const stream = ((_model, _context, options) => {
      rawOptionsSeen.push(options as Record<string, unknown>);
      return streamForMessage(assistant([validSubmitReviewCall("submit-anthropic-forced")]));
    }) as PiStreamForTest;
    const streamSimple = vi.fn(() => streamForMessage(assistant([validSubmitReviewCall("must-not-use-simple")]))) as unknown as PiStreamSimpleForTest;
    const adapter = createRealPiAiAdapter({ stream, streamSimple });

    await adapter.complete(
      {
        provider: "anthropic",
        id: "claude-test",
        raw: { api: "anthropic-messages", provider: "anthropic", id: "claude-test", maxTokens: 4096, reasoning: true },
        apiKey: "fake-api-key"
      },
      { messages: [], tools: [] },
      { reasoning: "high", toolChoice: { type: "tool", name: "submit_review" }, maxRetries: 0, submitToolName: "submit_review" }
    );

    expect(streamSimple).not.toHaveBeenCalled();
    expect(rawOptionsSeen).toEqual([
      expect.objectContaining({
        apiKey: "fake-api-key",
        thinkingEnabled: false,
        toolChoice: { type: "tool", name: "submit_review" }
      })
    ]);
    expect(rawOptionsSeen[0]).not.toHaveProperty("reasoning");
    expect(rawOptionsSeen[0]).not.toHaveProperty("effort");
    expect(rawOptionsSeen[0]).not.toHaveProperty("forceSubmitToolChoice");
  });

  it("keeps the legacy Anthropic downgrade when forceSubmitToolChoice is disabled", async () => {
    const rawOptionsSeen: Record<string, unknown>[] = [];
    const stream = ((_model, _context, options) => {
      rawOptionsSeen.push(options as Record<string, unknown>);
      return streamForMessage(assistant([validSubmitReviewCall("submit-anthropic-downgraded")]));
    }) as PiStreamForTest;
    const adapter = createRealPiAiAdapter({ stream });

    await adapter.complete(
      {
        provider: "anthropic",
        id: "claude-test",
        raw: { api: "anthropic-messages", provider: "anthropic", id: "claude-test", maxTokens: 4096, reasoning: true },
        apiKey: "fake-api-key"
      },
      { messages: [], tools: [] },
      { reasoning: "high", toolChoice: { type: "tool", name: "submit_review" }, maxRetries: 0, forceSubmitToolChoice: false, submitToolName: "submit_review" }
    );

    expect(rawOptionsSeen).toEqual([
      expect.objectContaining({
        thinkingEnabled: true,
        effort: "high",
        toolChoice: "auto"
      })
    ]);
  });

  it("refreshes stored OAuth credentials through Pi helpers and persists updates", async () => {
    clearRegisteredSecretsForTests();
    const oldCredentials = { access: "old-access-token", refresh: "old-refresh-token", expires: 0 };
    const newCredentials = { access: "new-access-token", refresh: "new-refresh-token", expires: Date.now() + 60_000 };
    const entries = new Map<string, ProviderAuthEntry>([
      ["github-copilot", { type: "oauth", credentials: oldCredentials, createdAt: new Date(0).toISOString() }]
    ]);
    const authStorage: PiAuthStorage = {
      loadAll: () => Object.fromEntries(entries.entries()),
      get: (provider) => entries.get(provider),
      set: (provider, entry) => {
        entries.set(provider, entry);
      },
      delete: (provider) => {
        entries.delete(provider);
      },
      clear: () => entries.clear()
    };
    const optionsSeen: Record<string, unknown>[] = [];
    const requestController = new AbortController();
    const streamSimple = ((_model, _context, options) => {
      optionsSeen.push(options as Record<string, unknown>);
      return streamForMessage(assistant([validSubmitReviewCall("submit-oauth-refresh")]));
    }) as PiStreamSimpleForTest;
    const getOAuthApiKey = vi.fn(async (
      _provider: string,
      credentials: Record<string, typeof oldCredentials>,
      signal: AbortSignal
    ) => {
      expect(credentials["github-copilot"]).toEqual(oldCredentials);
      expect(signal).toBe(requestController.signal);
      return { newCredentials, apiKey: "new-oauth-api-key" };
    }) as NonNullable<RealPiAiAdapterDepsForTest["getOAuthApiKey"]>;
    const adapter = createRealPiAiAdapter({ authStorage, streamSimple, getOAuthApiKey });

    await adapter.complete(
      { provider: "github-copilot", id: "fake-model", raw: { id: "fake-model" }, oauthProvider: "github-copilot" },
      { messages: [], tools: [] },
      { maxRetries: 0, signal: requestController.signal, submitToolName: "submit_review" }
    );

    expect(getOAuthApiKey).toHaveBeenCalledTimes(1);
    expect(entries.get("github-copilot")).toMatchObject({
      type: "oauth",
      credentials: newCredentials,
      createdAt: new Date(0).toISOString()
    });
    expect(optionsSeen[0]).toMatchObject({ apiKey: "new-oauth-api-key" });
    expect(stripCredentials("new-oauth-api-key")).toBe("[redacted:secret]");
    clearRegisteredSecretsForTests();
  });

  it("derives sensitive cache keys, redacts entries, returns hits, and misses schema-version mismatches", async () => {
    clearRegisteredSecretsForTests();
    const repoRoot = tempGitRepo();
    const telemetry = fakeTelemetry();
    const cache = await createModelCallCache({
      dir: path.join(repoRoot, ".codegenie", "cache"),
      repoRoot,
      runFingerprint: "run-a",
      logger: fakeLogger(),
      telemetry: telemetry.recorder
    });
    const keyA = buildModelCallCacheKey({ prompt: "a", model: "m" });
    const keyB = buildModelCallCacheKey({ prompt: "b", model: "m" });
    expect(keyA).not.toBe(keyB);

    const entry = cacheEntry(7);
    entry.message.content.push({ type: "text", text: "cache contains super-secret-cache-token" });
    registerSecret("super-secret-cache-token");
    await cache.put(keyA, entry);
    expect(existsSync(modelCallCacheEntryPath(path.join(repoRoot, ".codegenie", "cache"), keyA))).toBe(true);
    expect(readCacheText(path.join(repoRoot, ".codegenie", "cache"))).not.toContain("super-secret-cache-token");
    expect(readCacheText(path.join(repoRoot, ".codegenie", "cache"))).toContain("[redacted:secret]");
    const hit = await cache.get(keyA, 7);
    expect(hit).toMatchObject({ status: "hit" });
    expect(JSON.stringify(hit)).not.toContain("super-secret-cache-token");
    expect(JSON.stringify(hit)).toContain("[redacted:secret]");
    const thinkingKey = buildModelCallCacheKey({ runFingerprint: "cache-test", prompt: "thinking" });
    await cache.put(thinkingKey, {
      ...cacheEntry(7),
      message: assistant([
        {
          type: "thinking",
          thinking: "provider reasoning block",
          thinkingSignature: "signed"
        },
        {
          type: "toolCall",
          id: "submit-thinking-cache",
          name: "submit_review",
          arguments: {
            findings: [],
            followUpHints: [],
            uncertainties: []
          }
        }
      ])
    });
    const thinkingHit = await cache.get(thinkingKey, 7);
    expect(thinkingHit).toMatchObject({ status: "hit" });
    expect(JSON.stringify(thinkingHit)).toContain("provider reasoning block");
    await expect(cache.get(keyB, 7)).resolves.toEqual({ status: "miss", reason: "not_found" });
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 7,
          message: "model_call_cache_miss",
          cacheStatus: "miss"
        })
      ])
    );

    await cache.put("old-schema", { ...entry, cacheSchemaVersion: 0 });
    await expect(cache.get("old-schema", 7)).resolves.toEqual({ status: "miss", reason: "schema_mismatch" });
    const malformedKey = "malformed-current-schema";
    const malformedPath = modelCallCacheEntryPath(path.join(repoRoot, ".codegenie", "cache"), malformedKey);
    mkdirSync(path.dirname(malformedPath), { recursive: true });
    writeFileSync(
      malformedPath,
      `${JSON.stringify({
        cacheSchemaVersion: MODEL_CALL_CACHE_SCHEMA_VERSION,
        createdAt: new Date(0).toISOString(),
        stage: 7,
        message: { role: "assistant", provider: "fake", model: "fake-model" },
        finishReason: "submit",
        usage: {}
      })}\n`
    );
    await expect(cache.get(malformedKey, 7)).resolves.toEqual({ status: "miss", reason: "invalid_entry" });
    expect(existsSync(malformedPath)).toBe(false);
    const malformedContentKey = "malformed-current-schema-content";
    const malformedContentPath = modelCallCacheEntryPath(path.join(repoRoot, ".codegenie", "cache"), malformedContentKey);
    mkdirSync(path.dirname(malformedContentPath), { recursive: true });
    writeFileSync(
      malformedContentPath,
      `${JSON.stringify({
        ...cacheEntry(7),
        message: {
          ...cacheEntry(7).message,
          content: [{}]
        }
      })}\n`
    );
    await expect(cache.get(malformedContentKey, 7)).resolves.toEqual({ status: "miss", reason: "invalid_entry" });
    expect(existsSync(malformedContentPath)).toBe(false);
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 7,
          message: "model_call_cache_invalid_miss",
          cacheStatus: "miss"
        })
      ])
    );
    expect(existsSync(path.join(repoRoot, ".codegenie", "cache"))).toBe(true);
    expect(readFileSync(path.join(repoRoot, ".codegenie", ".gitignore"), "utf8")).toContain("cache/");
    expect(readFileSync(path.join(repoRoot, ".codegenie", ".gitignore"), "utf8")).toContain("locks/");
    clearRegisteredSecretsForTests();
  });

  it("evicts stale cache entries at construction and records telemetry", async () => {
    const repoRoot = tempGitRepo();
    const cacheDir = path.join(repoRoot, ".codegenie", "cache");
    const staleKey = buildModelCallCacheKey({ runFingerprint: "old", prompt: "old" });
    const freshKey = buildModelCallCacheKey({ runFingerprint: "new", prompt: "new" });
    const stalePath = modelCallCacheEntryPath(cacheDir, staleKey);
    const freshPath = modelCallCacheEntryPath(cacheDir, freshKey);
    mkdirSync(path.dirname(stalePath), { recursive: true });
    mkdirSync(path.dirname(freshPath), { recursive: true });
    writeFileSync(stalePath, `${JSON.stringify(cacheEntry(7))}\n`);
    writeFileSync(freshPath, `${JSON.stringify(cacheEntry(7))}\n`);
    const staleTime = new Date(Date.now() - 15 * 24 * 60 * 60 * 1000);
    utimesSync(stalePath, staleTime, staleTime);

    const telemetry = fakeTelemetry();
    await createModelCallCache({
      dir: cacheDir,
      repoRoot,
      runFingerprint: "run-evict",
      logger: fakeLogger(),
      telemetry: telemetry.recorder
    });

    expect(existsSync(stalePath)).toBe(false);
    expect(existsSync(freshPath)).toBe(true);
    expect(telemetry.events).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          stage: 0,
          message: "model_call_cache_evicted",
          data: expect.objectContaining({ deletedCount: 1 })
        })
      ])
    );
  });

  it("rejects repo-root cache directories before eviction and fails closed on non-git roots", async () => {
    const repoRoot = tempGitRepo();
    const trackedJson = path.join(repoRoot, "tracked.json");
    writeFileSync(trackedJson, "{}\n");
    execFileSync("git", ["add", "tracked.json"], { cwd: repoRoot, stdio: "ignore" });

    await expect(
      createModelCallCache({
        dir: repoRoot,
        repoRoot,
        runFingerprint: "run-root",
        logger: fakeLogger(),
        telemetry: fakeTelemetry().recorder
      })
    ).rejects.toMatchObject({
      code: "config_error"
    });
    expect(existsSync(trackedJson)).toBe(true);

    const nonGitRoot = tempDir();
    await expect(
      createModelCallCache({
        dir: path.join(nonGitRoot, ".codegenie", "cache"),
        repoRoot: nonGitRoot,
        runFingerprint: "run-non-git",
        logger: fakeLogger(),
        telemetry: fakeTelemetry().recorder
      })
    ).rejects.toMatchObject({
      code: "config_error"
    });
  });
});

function scriptedAdapter(messages: PiAssistantMessage[]): PiAiAdapter & { contexts: string[]; options: Record<string, unknown>[]; toolNames: string[][] } {
  const contexts: string[] = [];
  const optionsSeen: Record<string, unknown>[] = [];
  const toolNames: string[][] = [];
  return {
    contexts,
    options: optionsSeen,
    toolNames,
    resolveModel: () => ({ provider: "fake", id: "fake-model", raw: { id: "fake-model", api: "faux" } }),
    complete: vi.fn(async (_model, context, options) => {
      contexts.push(JSON.stringify(context.messages));
      optionsSeen.push(options);
      toolNames.push((context.tools as Array<{ name: string }>).map((tool) => tool.name));
      const next = messages.shift();
      if (!next) {
        throw new Error("no scripted message");
      }
      return next;
    }),
    validateToolCall: (tools, toolCall) => validateToolCall(tools, toolCall)
  };
}

function assistant(content: PiAssistantMessage["content"]): PiAssistantMessage {
  const contentWithProvenance = content.map((block) =>
    (block as { type?: unknown; name?: unknown }).type === "toolCall" &&
    typeof (block as { name?: unknown }).name === "string" &&
    String((block as { name: string }).name).startsWith("submit_")
      ? { ...block, argumentParse: { state: "strict" as const } }
      : block
  );
  return {
    role: "assistant",
    provider: "fake",
    model: "fake-model",
    content: contentWithProvenance,
    usage: {
      input: 10,
      output: 5,
      totalTokens: 15,
      cost: { total: 0.01 }
    },
    stopReason: contentWithProvenance.some((block) => (block as PiToolCall).type === "toolCall") ? "toolUse" : "stop",
    timestamp: 0
  };
}

function streamForMessage(message: PiAssistantMessage, rawArguments?: string) {
  const stream = createAssistantMessageEventStream();
  stream.push({ type: "start", partial: message as never });
  message.content.forEach((block, contentIndex) => {
    if ((block as { type?: unknown }).type !== "toolCall") {
      return;
    }
    const call = block as PiToolCall;
    stream.push({ type: "toolcall_start", contentIndex, partial: message as never });
    stream.push({
      type: "toolcall_delta",
      contentIndex,
      delta: rawArguments ?? JSON.stringify(call.arguments),
      partial: message as never
    });
    stream.push({ type: "toolcall_end", contentIndex, toolCall: call as never, partial: message as never });
  });
  if (message.stopReason === "error" || message.stopReason === "aborted") {
    stream.push({ type: "error", reason: message.stopReason, error: message as never });
  } else {
    stream.push({
      type: "done",
      reason: message.stopReason === "length" ? "length" : message.stopReason === "toolUse" ? "toolUse" : "stop",
      message: message as never
    });
  }
  return stream;
}

function assistantError(errorMessage: string): PiAssistantMessage {
  return {
    role: "assistant",
    provider: "fake",
    model: "fake-model",
    content: [],
    usage: {
      input: 0,
      output: 0,
      totalTokens: 0,
      cost: { total: 0 }
    },
    stopReason: "error",
    errorMessage,
    timestamp: 0
  };
}

function validSubmitReviewCall(id: string): PiToolCall {
  return {
    type: "toolCall",
    id,
    name: "submit_review",
    arguments: {
      findings: [],
      followUpHints: [],
      uncertainties: []
    }
  };
}

function trustedSubmitCall(call: PiToolCall): PiToolCall {
  return { ...call, argumentParse: { state: "strict" } };
}

function invalidSubmitCall(id: string, name: string, argumentParse: PiUntrustedArgumentParse): PiInvalidToolCall {
  return { type: "invalidToolCall", id, name, argumentParse };
}

function provenanceClassification(parse: PiUntrustedArgumentParse): string {
  if (parse.state === "length_stopped") return "length_stopped";
  if (parse.state === "partial") return "final_arguments_partial";
  if (parse.state === "invalid") return "final_arguments_invalid";
  return parse.state;
}

function validCandidateSubmitReviewCall(id: string): PiToolCall {
  return {
    type: "toolCall",
    id,
    name: "submit_review",
    arguments: {
      findings: [validCandidateReviewFinding()],
      followUpHints: [],
      uncertainties: []
    }
  };
}

function validCandidateReviewFinding(): Record<string, unknown> {
  return {
    title: "Candidate finding",
    severity: "medium",
    confidence: "high",
    path: "src/a.ts",
    category: "correctness",
    evidence: {
      changedCode: "+ return value"
    },
    failureMode: "The changed branch returns the wrong value for a reachable case.",
    whyThisMatters: "Callers can observe incorrect behavior from the changed code.",
    verification: "The packet hunk changes the returned value on the affected branch."
  };
}

function validSubmitVerdictCall(id: string): PiToolCall {
  return {
    type: "toolCall",
    id,
    name: "submit_verdict",
    arguments: {
      verdict: "reject",
      reason: "decisive helper source disproves the finding",
      requiredEvidencePresent: false,
      falsePositiveRisk: "high"
    }
  };
}

function validSubmitPlanCall(id: string): PiToolCall {
  return {
    type: "toolCall",
    id,
    name: "submit_plan",
    arguments: {
      diffUnderstanding: {
        declaredIntent: "test",
        inferredBehavior: "test"
      },
      coverage: []
    }
  };
}

function submitReviewRequest(packetId: string, telemetry?: TelemetryRecorder) {
  return {
    stage: 7 as const,
    prompt: `review ${packetId}`,
    schema: SubmitPacketReviewSchema,
    templateVersion: "test-template",
    timeoutMs: 1000,
    // Mirrors lens-runner's production wiring (plan 95): stage-7 deterministic
    // cleanup arrives via the shared recoverInvalidSubmit seam.
    ...(telemetry !== undefined
      ? {
          schemaRepair: {
            recoverInvalidSubmit: (input: LlmSchemaInvalidSubmitRecoveryInput) =>
              stage7RecoverInvalidSubmit(input, telemetry, { packetId })
          }
        }
      : {})
  };
}

function fakeRepositoryTools(): RepositoryTools {
  const meta = { backend: "text" as const, precision: "exact" as const, degraded: false };
  return {
    readRange: async () => ({ text: "line 1\nline 2", meta }),
    readFileOutline: async () => ({
      outline: {
        path: "src/a.ts",
        language: "typescript",
        imports: [],
        topLevelSymbols: [],
        testSymbols: [],
        notes: []
      },
      meta
    }),
    readSymbol: async () => ({ text: "function a() {}", meta }),
    readDiffBlocks: async () => ({ blocks: ["@@ -1 +1 @@"], meta }),
    findDefinition: async () => ({ definitions: [], meta }),
    searchFiles: async () => ({ results: [], meta }),
    findSymbolMentions: async () => ({ results: [], meta }),
    findLikelyTests: async () => ({ tests: [], meta }),
    listFiles: async () => ({ paths: ["src/a.ts"], meta })
  };
}

function fakeTelemetry(): {
  recorder: TelemetryRecorder;
  events: Array<Omit<TelemetryEvent, "runId" | "eventId" | "timestamp">>;
  modelCalls: Array<Omit<LlmCallRecord, "runId">>;
  toolCalls: Array<Omit<ToolCallRecord, "runId" | "toolCallId" | "timestamp">>;
  debugWrites: Array<{ kind: "llm-calls" | "tool-calls"; id: string; record: unknown }>;
} {
  const events: Array<Omit<TelemetryEvent, "runId" | "eventId" | "timestamp">> = [];
  const modelCalls: Array<Omit<LlmCallRecord, "runId">> = [];
  const toolCalls: Array<Omit<ToolCallRecord, "runId" | "toolCallId" | "timestamp">> = [];
  const debugWrites: Array<{ kind: "llm-calls" | "tool-calls"; id: string; record: unknown }> = [];
  return {
    recorder: {
      runId: "phase4-llm",
      runDir: undefined,
      event: (event) => events.push(event),
      recordModelCall: (record) => modelCalls.push(record),
      recordToolCall: (record) => {
        toolCalls.push(record);
        return `tc-${toolCalls.length}`;
      },
      writeArtifact: vi.fn(async () => undefined),
      writeDebug: vi.fn(async (kind, id, record) => {
        debugWrites.push({ kind, id, record });
      }),
      flush: vi.fn(async () => undefined)
    },
    events,
    modelCalls,
    toolCalls,
    debugWrites
  };
}

function debugRecord(telemetry: ReturnType<typeof fakeTelemetry>, id: string): Record<string, unknown> {
  const write = telemetry.debugWrites.find((entry) => entry.kind === "llm-calls" && entry.id === id);
  expect(write).toBeDefined();
  return write?.record as Record<string, unknown>;
}

function toolDebugRecord(telemetry: ReturnType<typeof fakeTelemetry>, id: string): Record<string, unknown> {
  const write = telemetry.debugWrites.find((entry) => entry.kind === "tool-calls" && entry.id === id);
  expect(write).toBeDefined();
  return write?.record as Record<string, unknown>;
}

function fakeLogger(): Logger {
  const sink = vi.fn();
  return {
    debug: sink,
    info: sink,
    warn: sink,
    error: sink
  };
}

function cacheEntry(stage: 7): StoredProviderResponse {
  return {
    cacheSchemaVersion: MODEL_CALL_CACHE_SCHEMA_VERSION,
    createdAt: new Date(0).toISOString(),
    stage,
    message: assistant([
      {
        type: "toolCall",
        id: "submit-cache",
        name: "submit_review",
        arguments: {
          findings: [],
          followUpHints: [],
          uncertainties: []
        }
      }
    ]),
    finishReason: "submit",
    usage: {
      inputTokens: 1,
      outputTokens: 1,
      totalTokens: 2,
      costUSD: 0.01
    }
  };
}

function tempDir(): string {
  const dir = mkdtempSync(path.join(tmpdir(), "codegenie-phase4-"));
  mkdirSync(dir, { recursive: true });
  writeFileSync(path.join(dir, ".keep"), "");
  return dir;
}

function tempGitRepo(): string {
  const dir = tempDir();
  execFileSync("git", ["init"], { cwd: dir, stdio: "ignore" });
  return dir;
}

function readCacheText(cacheDir: string): string {
  const parts: string[] = [];
  for (const entry of readdirSync(cacheDir, { withFileTypes: true })) {
    const entryPath = path.join(cacheDir, entry.name);
    if (entry.isDirectory()) {
      parts.push(readCacheText(entryPath));
    } else if (entry.isFile() && entry.name.endsWith(".json")) {
      parts.push(readFileSync(entryPath, "utf8"));
    }
  }
  return parts.join("\n");
}

async function delay(ms: number): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

describe("plan 124 repair feedback and failed-request evidence", () => {
  it.each(["underscore", "string", "envelope"])("explains rejected %s patches in replaced composition contexts", async mode => {
    const { findings, sections, evidenceRefs, presentation } = authorizationComposition();
    const original = { summary: "Verified issue", composedFindings: [{ findingIds: findings.map(f => f.id), sections: structuredClone(sections), evidenceRefs, ...presentation, publication: "inline" }] };
    const index = sections.findIndex(section => section.kind === "fix");
    original.composedFindings[0]!.sections[index]!.sourceRefs.push("invented/fix");
    const key = `composedFindings.0.sections.${index}.sourceRefs`;
    const good = { [key]: sections[index]!.sourceRefs };
    const bad = mode === "underscore" ? { [key.replaceAll(".", "_")]: JSON.stringify(good[key]) }
      : mode === "string" ? { [key]: '["unterminated' } : { composedFindings: JSON.stringify(good) };
    const telemetry = fakeTelemetry();
    const adapter = scriptedAdapter([original, bad, { unexpectedSecondEnvelope: "still wrong" }, good].map((arguments_, i) =>
      assistant([{ type: "toolCall", id: `submit-${i}`, name: "submit_composition", arguments: arguments_ }])));
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: telemetry.recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    const schema = composerSubmissionSchema([{ fingerprint: "test", representative: findings[0]!, findings }]);
    await expect(runner.runStructured({ stage: 10, prompt: "compose", schema, templateVersion: "test", timeoutMs: 600_000,
      normalizeSubmit: value => normalizeCompositionReferences(value, findings),
      validateSubmit: value => {
        try { validateCompositionSubmission(value as typeof original, findings); return { ok: true }; }
        catch (error) { return { ok: false, classification: "schema_invalid", details: String(error) }; }
      }, schemaRepair: { createFieldRepair: (schema, retained) => createCompositionAttributionRepair(schema, retained, findings) }
    })).resolves.toMatchObject({ composedFindings: [{ sections }] });
    const next = adapter.contexts[2]!;
    expect(next).toContain("latest-repair-feedback");
    expect(next).toContain(Object.keys(bad)[0]);
    expect(next).toContain('string');
    expect(next).toContain(key);
    expect(next).toContain("patch-format-example");
    expect(adapter.contexts[3]).not.toEqual(next);
    expect(adapter.complete).toHaveBeenCalledTimes(4);
  });

  it.each([false, true])("delivers a successful read once when submission fails (cancel=%s)", async cancel => {
    const abort = new AbortController();
    const adapter = scriptedAdapter([]);
    let calls = 0;
    adapter.complete = vi.fn(async () => {
      if (++calls === 1) return assistant([{ type: "toolCall", id: "read", name: "read_range", arguments: { path: "policy.txt" } }]);
      if (cancel) { abort.abort(new Error("cancelled by test")); throw abort.signal.reason; }
      return assistant([invalidSubmitCall("bad", "submit_review", { state: "invalid", errorKind: "invalid_syntax" })]);
    });
    const callback = vi.fn();
    const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
      telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: abort.signal, adapter,
      hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
    await expect(runner.runStructured({ ...submitReviewRequest("evidence-failure"), signal: abort.signal, onToolResults: callback,
      tools: [{ name: "read_range", description: "read", parameters: Type.Object({ path: Type.String() }), execute: async () => ({
        text: "authorize reader", meta: { backend: "text", precision: "exact", degraded: false, lookupStatus: "found", deliveryStatus: "full", sourceUsed: "head" }
      }) }], toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 2, maxResultChars: 2000 }
    })).rejects.toBeDefined();
    expect(callback).toHaveBeenCalledTimes(1);
    expect(callback.mock.calls[0]![0]).toEqual([expect.objectContaining({ repositoryEvidence: [expect.objectContaining({ text: "authorize reader", source: "head" })] })]);
  });
});

it("keeps bounded redacted key/type feedback with a non-composition custom repair", async () => {
  const secret = "sk-test-repair-feedback-secret-0123456789";
  registerSecret(secret);
  const adapter = scriptedAdapter([
    {}, { decison: "accept", [secret]: "unused" }, { decision: "accept" }
  ].map((arguments_, i) => assistant([{ type: "toolCall", id: `s${i}`, name: "submit_system_review", arguments: arguments_ }])));
  const schema = Type.Object({ decision: Type.String() }, { additionalProperties: false });
  const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
    telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
    hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
  await expect(runner.runStructured({ stage: 8, prompt: "review", schema, templateVersion: "test", timeoutMs: 1000,
    schemaRepair: { createFieldRepair: (schema, original) => {
      const repair = createFieldRepair(schema, original, true)!;
      return { ...repair, schema: Type.Object({ decision: Type.Optional(Type.String()) }, { additionalProperties: false, minProperties: 1 }),
        prompt: "Only update decision. The tool schema is authoritative.", replaceConversation: true };
    } }
  })).resolves.toEqual({ decision: "accept" });
  expect(adapter.contexts[2]).toContain("decison");
  expect(adapter.contexts[2]).toContain("permittedFields");
  expect(adapter.contexts[2]).toContain("latest-repair-feedback");
  expect(adapter.contexts[2]).not.toContain(secret);
  expect(adapter.contexts[2]!.length).toBeLessThan(10_000);
});


it.each(["full", "cached", "truncated", "error", "unknown-revision"] as const)("retains separately identified ambiguous definition hits only when delivered in full: %s", async mode => {
  const definitions = [
    { symbol: { path: "src/access.go", name: "ReadForUser", kind: "function" as const, lineRange: [20, 24] as [number, number] }, text: "func ReadForUser(user) { return read(user.org); }" },
    { symbol: { path: "docs/design.txt", name: "ReadForUser", kind: "other" as const, lineRange: [8, 8] as [number, number] }, text: "ReadForUser is used by the handler." }
  ];
  const tool: ToolDefinition = { name: "find_definition", description: "Find candidates", parameters: Type.Object({ symbolName: Type.String(), source: Type.Object({ kind: Type.String() }) }),
    execute: async () => ({ text: JSON.stringify(definitions), definitions,
      ...(mode === "error" ? { isError: true } : {}), meta: { backend: "text", precision: "text", degraded: false,
        lookupStatus: "ambiguous", deliveryStatus: mode === "truncated" ? "truncated" : "full",
        ...(mode !== "unknown-revision" ? { sourceUsed: "base" as const } : {}) } }) };
  const adapter = scriptedAdapter([assistant([{ type: "toolCall", id: "lookup", name: tool.name, arguments: { symbolName: "ReadForUser", source: { kind: "auto" } } }]), assistant([validSubmitReviewCall("done")])]);
  if (mode === "cached") adapter.complete = scriptedAdapter([
    assistant([{ type: "toolCall", id: "lookup", name: tool.name, arguments: { symbolName: "ReadForUser", source: { kind: "auto" } } }]),
    assistant([{ type: "toolCall", id: "lookup", name: tool.name, arguments: { symbolName: "ReadForUser", source: { kind: "auto" } } }]),
    assistant([validSubmitReviewCall("done")])
  ]).complete;
  const execute = vi.spyOn(tool, "execute");
  const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 },
    telemetry: fakeTelemetry().recorder, logger: fakeLogger(), runSignal: new AbortController().signal, adapter,
    toolResultCache: createToolResultCache(), hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
  const captured: import("../src/llm/llm-runner.js").LlmToolResultSummary[] = [];
  await runner.runStructured({ ...submitReviewRequest("definitions"), tools: [tool], onToolResults: results => captured.push(...results),
    toolBudget: { maxToolCalls: 2, maxInvestigationRounds: 3, maxResultChars: 2000 } });
  expect(captured[0]!.lookupStatus).toBe("ambiguous");
  if (mode === "full" || mode === "cached") {
    expect(captured[0]!.repositoryEvidence).toEqual(definitions.map((hit, i) => ({ id: `lookup/hit-${i}`, tool: "find_definition",
      path: hit.symbol.path, lineRange: hit.symbol.lineRange, symbols: [hit.symbol.name], text: hit.text, source: "base", lookupStatus: "ambiguous" })));
    if (mode === "cached") {
      expect(captured).toHaveLength(2);
      expect(captured[1]!.repositoryEvidence).toEqual(captured[0]!.repositoryEvidence);
      expect(execute).toHaveBeenCalledTimes(1);
    }
  } else expect(captured[0]!.repositoryEvidence).toBeUndefined();
});

it.each([false, true])("uses the same cleaned attention patch for acceptance and telemetry (invalid=%s)", async invalid => {
  const finding = authorizationComposition().findings[0]!;
  const input = buildAttentionReconciliation([{ candidateId: finding.id, verdict: "keep", requiredEvidencePresent: true,
    falsePositiveRisk: "low", reason: "Verified." }], [finding], [], { mode: "branch", repoRoot: "/repo", commits: [], rawDiff: "" },
    [{ id: "q", packetId: "packet", source: "uncertainty", originalFiles: [finding.path], droppedPaths: [], suggestedLenses: [], question: "Does readDocument reject revoked access?", files: [finding.path], symbols: ["readDocument"], confidence: "medium", reason: "Check the existing evidence." }]);
  const original = { summary: "Keep original summary.", composedFindings: [], attentionResolutions: [{ concernId: "packet/q", disposition: "resolved", supportingRefs: ["invented/ref"], rationale: "Incorrect citation." }] };
  const decision = { concernId: "packet/q", disposition: "resolved", supportingRefs: [`${finding.id}/verification`], rationale: "Published verification answers the question." };
  const patch = { summary: "Ignore extra summary.", composedFindings: [{ bad: true }], attentionResolutions: [{ ...decision, ...(invalid ? { supportingRefs: ["still/invented"] } : {}), extra: "ignore" }] };
  const submissions = [original, patch, ...(invalid ? [{ attentionResolutions: [decision] }] : [])];
  const adapter = scriptedAdapter(submissions.map((arguments_, i) => assistant([{ type: "toolCall", id: `submit-${i}`, name: "submit_composition", arguments: arguments_ }])));
  const telemetry = fakeTelemetry();
  const runner = createPiRunner({ llmConfig: { provider: "fake", model: "fake-model", maxConcurrentCalls: 1 }, telemetry: telemetry.recorder,
    logger: fakeLogger(), runSignal: new AbortController().signal, adapter, hooks: { checkpoint: () => "ok", onUsage: vi.fn() } });
  const schema = composerSubmissionSchema([], input);
  await expect(runner.runStructured({ stage: 10, prompt: "compose", schema, templateVersion: "test", timeoutMs: 600_000,
    validateSubmit: value => { const errors = attentionResolutionErrors(input, (value as SubmitComposition).attentionResolutions);
      return errors.length ? { ok: false, classification: "schema_invalid", details: errors.join("\n") } : { ok: true }; },
    schemaRepair: { createFieldRepair: (shape, value) => createAttentionResolutionRepair(shape, value as SubmitComposition, input) }
  })).resolves.toEqual({ ...original, attentionResolutions: [decision] });
  expect(adapter.complete).toHaveBeenCalledTimes(invalid ? 3 : 2);
  expect(telemetry.modelCalls.map(call => call.schemaValid)).toEqual(invalid ? [false, false, true] : [false, true]);
});
