constants = import_module("../package_io/constants.star")
hex = import_module("../hex/hex.star")
wallet_module = import_module("../wallet/wallet.star")


def run(
    plan,
    args,
    contract_setup_addresses,
    sovereign_contract_setup_addresses,
    deployment_stages,
    sequencer_type,
):
    # Get urls.
    l1_rpc_url = args.get("l1_rpc_url")
    l2_rpc_url = _get_l2_rpc_url(plan, args)
    bridge_service_url = _get_bridge_service_url(
        plan, args, deployment_stages.get("deploy_cdk_bridge_infra")
    )
    l2_bridge_address = _get_l2_bridge_address(
        plan,
        sequencer_type,
        contract_setup_addresses,
        sovereign_contract_setup_addresses,
    )

    # Generate new wallet for the test runner.
    funder_private_key = args.get("l2_admin_private_key")
    wallet = _generate_new_funded_l1_l2_wallet(
        plan, funder_private_key, l1_rpc_url, l2_rpc_url
    )

    # Start the test runner.
    plan.add_service(
        name="test-runner{}".format(args.get("deployment_suffix")),
        config=ServiceConfig(
            image=args.get("test_runner_image"),
            env_vars={
                # For now, we've only defined variables used by `tests/agglayer/bridges.bats`.
                # https://github.com/AggLayer/e2e/blob/main/tests/agglayer/bridges.bats
                # Agglayer and bridge.
                "AGGLAYER_RPC_URL": args.get("agglayer_readrpc_url"),
                "BRIDGE_SERVICE_URL": bridge_service_url,
                "CLAIMTXMANAGER_ADDR": args.get("l2_claimsponsor_address"),
                # L1.
                "L1_PRIVATE_KEY": wallet.private_key,
                "L1_RPC_URL": l1_rpc_url,
                "L1_BRIDGE_ADDR": contract_setup_addresses.get("l1_bridge_address"),
                # L2.
                "L2_PRIVATE_KEY": wallet.private_key,
                "L2_RPC_URL": l2_rpc_url,
                "L2_BRIDGE_ADDR": l2_bridge_address,
                # Other parameters.
                # Max time the bridge bats wait for an L2->L1 claim to become ready. Configurable
                # per rollup: the op-succinct/FEP path needs more than the sequencer-rollup default
                # because its claim only unblocks once the certificate carrying the L2 exit settles
                # (L1 finalization lag + aggkit-prover aggchain-proof generation), both of which are
                # slow on a resource-constrained multi-stack CI runner.
                "CLAIM_WAIT_DURATION": args.get(
                    "test_runner_claim_wait_duration", "20m"
                ),
                "TX_RECEIPT_TIMEOUT_SECONDS": "900",  # default: 60
            },
            entrypoint=["bash", "-c"],
            cmd=["sleep infinity"],
        ),
    )


def _get_l2_rpc_url(plan, args):
    service_name = args.get("l2_rpc_name") + args.get("deployment_suffix")
    service = plan.get_service(service_name)
    if "rpc" not in service.ports:
        fail("The 'rpc' port of the l2 rpc service is not available.")
    return service.ports["rpc"].url


def _get_bridge_service_url(plan, args, deploy_cdk_bridge_infra):
    if deploy_cdk_bridge_infra:
        service_name = "zkevm-bridge-service" + args.get("deployment_suffix")
        service = plan.get_service(service_name)
        if "rpc" not in service.ports:
            fail("The 'rpc' port of the l2 rpc service is not available.")
        return service.ports["rpc"].url
    else:
        return ""


def _get_l2_bridge_address(
    plan,
    sequencer_type,
    contract_setup_addresses,
    sovereign_contract_setup_addresses,
):
    if sequencer_type in [
        constants.SEQUENCER_TYPE.op_reth,
        constants.SEQUENCER_TYPE.besu,
    ]:
        return sovereign_contract_setup_addresses.get("sovereign_bridge_proxy_addr")

    if "l2_bridge_address" in contract_setup_addresses:
        return contract_setup_addresses.get("l2_bridge_address")
    return contract_setup_addresses.get("l1_bridge_address")


def _generate_new_funded_l1_l2_wallet(plan, funder_private_key, l1_rpc_url, l2_rpc_url):
    wallet = wallet_module.new(plan)
    wallet_module.fund(
        plan,
        address=wallet.address,
        rpc_url=l1_rpc_url,
        funder_private_key=funder_private_key,
    )
    wallet_module.fund(
        plan,
        address=wallet.address,
        rpc_url=l2_rpc_url,
        funder_private_key=funder_private_key,
    )
    return wallet
