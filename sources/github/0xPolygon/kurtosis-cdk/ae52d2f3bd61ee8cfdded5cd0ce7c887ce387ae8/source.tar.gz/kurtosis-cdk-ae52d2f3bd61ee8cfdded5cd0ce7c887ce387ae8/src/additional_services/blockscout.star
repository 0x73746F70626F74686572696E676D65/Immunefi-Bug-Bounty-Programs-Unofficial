blockscout_package = import_module(
    "github.com/xavier-romero/kurtosis-blockscout/main.star"
)  # Version pinned in kurtosis.yml
contracts_util = import_module("../contracts/util.star")


def run(plan, args):
    l2_rpc_url = contracts_util.get_l2_rpc_url(plan, args)

    blockscout_params = {
        "rpc_url": l2_rpc_url.http,
        "trace_url": l2_rpc_url.http,
        "ws_url": l2_rpc_url.ws,
        "chain_id": str(args["l2_chain_id"]),
        "deployment_suffix": args["deployment_suffix"],
    } | args.get("blockscout_params", {})

    blockscout_package.run(plan, args=blockscout_params)
