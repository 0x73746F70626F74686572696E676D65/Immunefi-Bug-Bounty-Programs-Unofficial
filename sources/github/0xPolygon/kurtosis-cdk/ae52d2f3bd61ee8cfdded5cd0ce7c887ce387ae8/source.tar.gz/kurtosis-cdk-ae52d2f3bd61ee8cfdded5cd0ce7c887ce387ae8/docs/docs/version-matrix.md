---
sidebar_position: 3
---

# Version Matrix

> This document is automatically generated.

## Contents

- [Test Environments](#test-environments)
- [Default Images](#default-images)
- [Kurtosis Packages](#kurtosis-packages)

## Test Environments

This section lists all test environments with their configurations and component versions, organized by execution client.

### CDK OP Reth

- [cdk-opreth-sovereign-ecdsa-multisig](#cdk-opreth-sovereign-ecdsa-multisig)
- [cdk-opreth-sovereign-pessimistic](#cdk-opreth-sovereign-pessimistic)
- [cdk-opreth-zkrollup](#cdk-opreth-zkrollup)

### CDK Erigon

- [cdk-erigon-sovereign-ecdsa-multisig](#cdk-erigon-sovereign-ecdsa-multisig)
- [cdk-erigon-sovereign-pessimistic](#cdk-erigon-sovereign-pessimistic)
- [cdk-erigon-validium](#cdk-erigon-validium)
- [cdk-erigon-zkrollup](#cdk-erigon-zkrollup)

### CDK Besu

- [cdk-besu-sovereign-ecdsa-multisig](#cdk-besu-sovereign-ecdsa-multisig)

## CDK OP Reth

Environments using [op-reth](https://github.com/ethereum-optimism/optimism/tree/develop/rust/op-reth) as the L2 execution client.

### cdk-opreth-sovereign-ecdsa-multisig

- File path: `.github/tests/op-reth/sovereign-ecdsa-multisig.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| aggkit | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | ✅ matches stable |
| agglayer | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | ✅ matches stable |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| op-batcher | [1.17.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-batcher/v1.17.1) | [1.17.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-batcher/v1.17.1) | ✅ matches stable |
| op-deployer | [0.7.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-deployer/v0.7.1) | [0.7.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-deployer/v0.7.1) | ✅ matches stable |
| op-node | [1.19.8](https://github.com/ethereum-optimism/optimism/releases/tag/op-node/v1.19.8) | [1.19.8](https://github.com/ethereum-optimism/optimism/releases/tag/op-node/v1.19.8) | ✅ matches stable |
| op-proposer | [1.16.6](https://github.com/ethereum-optimism/optimism/releases/tag/op-proposer/v1.16.6) | [1.16.6](https://github.com/ethereum-optimism/optimism/releases/tag/op-proposer/v1.16.6) | ✅ matches stable |
| op-reth | [2.5.0](https://github.com/ethereum-optimism/optimism/releases/tag/op-reth/v2.5.0) | [2.5.0](https://github.com/ethereum-optimism/optimism/releases/tag/op-reth/v2.5.0) | ✅ matches stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |

### cdk-opreth-sovereign-pessimistic

- File path: `.github/tests/op-reth/sovereign-pessimistic.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| aggkit | [0.5.4](https://github.com/agglayer/aggkit/releases/tag/v0.5.4) | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | 📌 pinned — Only supports aggkit 0.5.x so far. |
| agglayer | [0.6.0](https://github.com/agglayer/agglayer/releases/tag/v0.6.0) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | 📌 pinned — aggkit 0.5.4 signs V2/V3 certs, rejected by agglayer 0.6.1+. |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| op-batcher | [1.17.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-batcher/v1.17.1) | [1.17.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-batcher/v1.17.1) | ✅ matches stable |
| op-deployer | [0.7.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-deployer/v0.7.1) | [0.7.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-deployer/v0.7.1) | ✅ matches stable |
| op-node | [1.19.8](https://github.com/ethereum-optimism/optimism/releases/tag/op-node/v1.19.8) | [1.19.8](https://github.com/ethereum-optimism/optimism/releases/tag/op-node/v1.19.8) | ✅ matches stable |
| op-proposer | [1.16.6](https://github.com/ethereum-optimism/optimism/releases/tag/op-proposer/v1.16.6) | [1.16.6](https://github.com/ethereum-optimism/optimism/releases/tag/op-proposer/v1.16.6) | ✅ matches stable |
| op-reth | [2.5.0](https://github.com/ethereum-optimism/optimism/releases/tag/op-reth/v2.5.0) | [2.5.0](https://github.com/ethereum-optimism/optimism/releases/tag/op-reth/v2.5.0) | ✅ matches stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |

### cdk-opreth-zkrollup

- File path: `.github/tests/op-succinct/mock-prover.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| aggkit | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | ✅ matches stable |
| aggkit-prover | [2.1.0](https://github.com/agglayer/provers/releases/tag/v2.1.0) | [2.1.0](https://github.com/agglayer/provers/releases/tag/v2.1.0) | ✅ matches stable |
| agglayer | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | ✅ matches stable |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| op-batcher | [1.17.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-batcher/v1.17.1) | [1.17.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-batcher/v1.17.1) | ✅ matches stable |
| op-deployer | [0.7.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-deployer/v0.7.1) | [0.7.1](https://github.com/ethereum-optimism/optimism/releases/tag/op-deployer/v0.7.1) | ✅ matches stable |
| op-node | [1.19.5](https://github.com/ethereum-optimism/optimism/releases/tag/op-node/v1.19.5) | [1.19.8](https://github.com/ethereum-optimism/optimism/releases/tag/op-node/v1.19.8) | 📌 pinned — op-succinct 3.10.x cannot read op-node 1.19.6+ (dropped cross_unsafe_l2). |
| op-reth | [2.5.0](https://github.com/ethereum-optimism/optimism/releases/tag/op-reth/v2.5.0) | [2.5.0](https://github.com/ethereum-optimism/optimism/releases/tag/op-reth/v2.5.0) | ✅ matches stable |
| op-succinct-proposer | [3.10.0-agglayer](https://github.com/agglayer/op-succinct/releases/tag/v3.10.0-agglayer) | [3.13.0-agglayer](https://github.com/agglayer/op-succinct/releases/tag/v3.13.0-agglayer) | 📌 pinned — Only supports op-succinct 3.10.x so far. |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |

## CDK Erigon

Environments using [cdk-erigon](https://github.com/0xPolygon/cdk-erigon) as the L2 execution client.

### cdk-erigon-sovereign-ecdsa-multisig

- File path: `.github/tests/cdk-erigon/sovereign-ecdsa-multisig.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| aggkit | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | ✅ matches stable |
| agglayer | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | ✅ matches stable |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| cdk-erigon | [2.65.0-RC3](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.65.0-RC3) | [2.64.2](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.64.2) | ⚡️ newer than stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |
| zkevm-pool-manager | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | ✅ matches stable |

### cdk-erigon-sovereign-pessimistic

- File path: `.github/tests/cdk-erigon/sovereign-pessimistic.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| aggkit | [0.5.4](https://github.com/agglayer/aggkit/releases/tag/v0.5.4) | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | 📌 pinned — Only supports aggkit 0.5.x so far. |
| agglayer | [0.6.0](https://github.com/agglayer/agglayer/releases/tag/v0.6.0) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | 📌 pinned — aggkit 0.5.4 signs V2/V3 certs, rejected by agglayer 0.6.1+. |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| cdk-erigon | [2.65.0-RC3](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.65.0-RC3) | [2.64.2](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.64.2) | ⚡️ newer than stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |
| zkevm-pool-manager | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | ✅ matches stable |

### cdk-erigon-validium

- File path: `.github/tests/cdk-erigon/validium.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| agglayer | [0.6.0-rc.5](https://github.com/agglayer/agglayer/releases/tag/v0.6.0-rc.5) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | 📌 pinned — Only supports agglayer 0.6.0-rc.5 so far. |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| cdk-data-availability | [0.0.13](https://github.com/0xPolygon/cdk-data-availability/releases/tag/v0.0.13) | [0.0.13](https://github.com/0xPolygon/cdk-data-availability/releases/tag/v0.0.13) | ✅ matches stable |
| cdk-erigon | [2.61.24](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.61.24) | [2.64.2](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.64.2) | 📌 pinned — Only supports cdk-erigon 2.61.x so far. |
| cdk-node | [0.5.4](https://github.com/0xPolygon/cdk/releases/tag/v0.5.4) | [0.5.4](https://github.com/0xPolygon/cdk/releases/tag/v0.5.4) | ✅ matches stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |
| zkevm-pool-manager | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | ✅ matches stable |
| zkevm-prover | [8.0.0-RC16](https://github.com/0xPolygon/zkevm-prover/releases/tag/v8.0.0-RC16) | [7.0.4](https://github.com/0xPolygon/zkevm-prover/releases/tag/v7.0.4) | ⚡️ newer than stable |

### cdk-erigon-zkrollup

- File path: `.github/tests/cdk-erigon/rollup.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| agglayer | [0.6.0-rc.5](https://github.com/agglayer/agglayer/releases/tag/v0.6.0-rc.5) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | 📌 pinned — Only supports agglayer 0.6.0-rc.5 so far. |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| cdk-erigon | [2.61.24](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.61.24) | [2.64.2](https://github.com/0xPolygon/cdk-erigon/releases/tag/v2.64.2) | 📌 pinned — Only supports cdk-erigon 2.61.x so far. |
| cdk-node | [0.5.4](https://github.com/0xPolygon/cdk/releases/tag/v0.5.4) | [0.5.4](https://github.com/0xPolygon/cdk/releases/tag/v0.5.4) | ✅ matches stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |
| zkevm-pool-manager | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | [0.1.3](https://github.com/0xPolygon/zkevm-pool-manager/releases/tag/v0.1.3) | ✅ matches stable |
| zkevm-prover | [8.0.0-RC16](https://github.com/0xPolygon/zkevm-prover/releases/tag/v8.0.0-RC16) | [7.0.4](https://github.com/0xPolygon/zkevm-prover/releases/tag/v7.0.4) | ⚡️ newer than stable |

## CDK Besu

Environments using [Besu](https://github.com/hyperledger/besu) as the L2 execution client.

### cdk-besu-sovereign-ecdsa-multisig

- File path: `.github/tests/besu/sovereign-ecdsa-multisig.yml`

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| aggkit | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | [0.10.0](https://github.com/agglayer/aggkit/releases/tag/v0.10.0) | ✅ matches stable |
| agglayer | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | [0.6.1](https://github.com/agglayer/agglayer/releases/tag/v0.6.1) | ✅ matches stable |
| agglayer-contracts | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | [12.2.3](https://github.com/agglayer/agglayer-contracts/releases/tag/v12.2.3) | ✅ matches stable |
| besu | [26.9.0](https://github.com/hyperledger/besu/releases/tag/26.9.0) | [26.9.0](https://github.com/hyperledger/besu/releases/tag/26.9.0) | ✅ matches stable |
| zkevm-bridge-service | [0.6.4-RC2](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.4-RC2) | [0.6.3](https://github.com/0xPolygon/zkevm-bridge-service/releases/tag/v0.6.3) | ⚡️ newer than stable |

## Default Images

| Component | Version Deployed in Kurtosis	 | Latest Stable Version | Status |
|-----------|-------------------------------|-----------------------|--------|
| geth | [1.17.7](https://github.com/ethereum/go-ethereum/releases/tag/v1.17.7) | [1.17.7](https://github.com/ethereum/go-ethereum/releases/tag/v1.17.7) | ✅ matches stable |
| lighthouse | [8.2.3](https://github.com/sigp/lighthouse/releases/tag/v8.2.3) | [8.2.3](https://github.com/sigp/lighthouse/releases/tag/v8.2.3) | ✅ matches stable |
| reth | [2.7.0](https://github.com/paradigmxyz/reth/releases/tag/v2.7.0) | [2.7.0](https://github.com/paradigmxyz/reth/releases/tag/v2.7.0) | ✅ matches stable |
| status-checker | [0.2.9](https://github.com/0xPolygon/status-checker/releases/tag/v0.2.9) | [0.2.9](https://github.com/0xPolygon/status-checker/releases/tag/v0.2.9) | ✅ matches stable |

## Kurtosis Packages

External Kurtosis packages this package depends on. Versions are pinned in the [`replace` block of `kurtosis.yml`](https://github.com/0xPolygon/kurtosis-cdk/blob/main/kurtosis.yml), which is the single place to bump them.

| Package | Pinned Version | Latest Stable Version | Status |
|---------|----------------|-----------------------|--------|
| [github.com/agglayer/optimism-package](https://github.com/agglayer/optimism-package) | [v2.0.0](https://github.com/agglayer/optimism-package/releases/tag/v2.0.0) | [v2.0.0](https://github.com/agglayer/optimism-package/releases/tag/v2.0.0) | ✅ matches stable |
| [github.com/ethpandaops/ethereum-package](https://github.com/ethpandaops/ethereum-package) | [6dd3f2613d1f](https://github.com/ethpandaops/ethereum-package/tree/6dd3f2613d1f9d1a9274864083c692726146c9db) | [HEAD (6dd3f2613d1f)](https://github.com/ethpandaops/ethereum-package/tree/6dd3f2613d1f) | ✅ matches stable |
| [github.com/kurtosis-tech/grafana-package](https://github.com/kurtosis-tech/grafana-package) | [c8ff0b52d25d](https://github.com/kurtosis-tech/grafana-package/tree/c8ff0b52d25deb0bc4ec95971dcf25b2fca11287) | [1.0.0](https://github.com/kurtosis-tech/grafana-package/releases/tag/1.0.0) | ⚡️ newer than stable — 2 commits ahead of 1.0.0 |
| [github.com/kurtosis-tech/prometheus-package](https://github.com/kurtosis-tech/prometheus-package) | [f3402ebad8cf](https://github.com/kurtosis-tech/prometheus-package/tree/f3402ebad8cffe98eef990e41ca863f7e8746c21) | [1.1.0](https://github.com/kurtosis-tech/prometheus-package/releases/tag/1.1.0) | ⚡️ newer than stable — 2 commits ahead of 1.1.0 |
| [github.com/xavier-romero/kurtosis-blockscout](https://github.com/xavier-romero/kurtosis-blockscout) | [9de7765a6c98](https://github.com/xavier-romero/kurtosis-blockscout/tree/9de7765a6c98c8c357f747ff953fdbc0e39ebc3d) | [HEAD (9de7765a6c98)](https://github.com/xavier-romero/kurtosis-blockscout/tree/9de7765a6c98) | ✅ matches stable |
