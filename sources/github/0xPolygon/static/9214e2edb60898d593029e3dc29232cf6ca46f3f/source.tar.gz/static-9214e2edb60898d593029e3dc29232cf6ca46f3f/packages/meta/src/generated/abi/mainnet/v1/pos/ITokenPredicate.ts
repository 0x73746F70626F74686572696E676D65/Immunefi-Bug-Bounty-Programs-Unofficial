export const abi = [
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "depositor",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "depositReceiver",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "rootToken",
        "type": "address"
      },
      {
        "internalType": "bytes",
        "name": "depositData",
        "type": "bytes"
      }
    ],
    "name": "lockTokens",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "withdrawer",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "rootToken",
        "type": "address"
      },
      {
        "internalType": "bytes",
        "name": "logRLPList",
        "type": "bytes"
      }
    ],
    "name": "exitTokens",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
