export const abi = [
  {
    "payable": true,
    "stateMutability": "payable",
    "type": "fallback"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "address",
        "name": "depositManager",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "token",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      }
    ],
    "name": "deposit",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "address payable",
        "name": "withdrawManager",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "depositId",
        "type": "uint256"
      },
      {
        "internalType": "address",
        "name": "token",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "amountOrToken",
        "type": "uint256"
      }
    ],
    "name": "startExitWithDepositedTokens",
    "outputs": [],
    "payable": true,
    "stateMutability": "payable",
    "type": "function"
  }
] as const;
