export const abi = [
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "receiver",
        "type": "address"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "syncState",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
