export const abi = [
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "v",
        "type": "bytes"
      },
      {
        "internalType": "uint16",
        "name": "chainId",
        "type": "uint16"
      }
    ],
    "name": "getV",
    "outputs": [
      {
        "internalType": "uint8",
        "name": "",
        "type": "uint8"
      }
    ],
    "payable": false,
    "stateMutability": "pure",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "address",
        "name": "_addr",
        "type": "address"
      }
    ],
    "name": "isContract",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "_arg",
        "type": "bytes"
      }
    ],
    "name": "toUint8",
    "outputs": [
      {
        "internalType": "uint8",
        "name": "",
        "type": "uint8"
      }
    ],
    "payable": false,
    "stateMutability": "pure",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "_arg",
        "type": "bytes"
      }
    ],
    "name": "toUint16",
    "outputs": [
      {
        "internalType": "uint16",
        "name": "",
        "type": "uint16"
      }
    ],
    "payable": false,
    "stateMutability": "pure",
    "type": "function"
  }
] as const;
