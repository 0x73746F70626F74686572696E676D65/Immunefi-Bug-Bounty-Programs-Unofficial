export const abi = [
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "receiptRoot",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "receipt",
        "type": "bytes"
      },
      {
        "internalType": "bytes",
        "name": "receiptProof",
        "type": "bytes"
      },
      {
        "internalType": "bytes",
        "name": "branchMask",
        "type": "bytes"
      }
    ],
    "name": "verify",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "pure",
    "type": "function"
  }
] as const;
