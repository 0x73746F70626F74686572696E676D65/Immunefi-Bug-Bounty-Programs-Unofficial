export const abi = [
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "_masterCopy",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "payable": true,
    "stateMutability": "payable",
    "type": "fallback"
  }
] as const;
