export const abi = [
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "rootToken",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "childToken",
        "type": "address"
      }
    ],
    "name": "TokenMapped",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "rootToken",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "childToken",
        "type": "address"
      }
    ],
    "name": "mapToken",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "onStateReceive",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
