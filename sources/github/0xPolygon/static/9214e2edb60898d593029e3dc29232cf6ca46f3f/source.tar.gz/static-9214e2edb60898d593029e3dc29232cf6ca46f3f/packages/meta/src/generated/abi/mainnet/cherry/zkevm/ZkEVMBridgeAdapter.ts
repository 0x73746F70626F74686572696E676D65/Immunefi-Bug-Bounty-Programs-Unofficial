export const abi = [
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "recipient",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "amount",
        "type": "uint256"
      },
      {
        "internalType": "bool",
        "name": "forceUpdateGlobalExitRoot",
        "type": "bool"
      }
    ],
    "name": "bridgeToken",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
