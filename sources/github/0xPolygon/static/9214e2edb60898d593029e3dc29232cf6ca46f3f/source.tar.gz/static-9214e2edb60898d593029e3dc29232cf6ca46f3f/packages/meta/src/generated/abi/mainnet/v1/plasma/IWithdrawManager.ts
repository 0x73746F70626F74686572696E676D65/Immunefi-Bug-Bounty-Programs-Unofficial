export const abi = [
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "address",
        "name": "token",
        "type": "address"
      }
    ],
    "name": "createExitQueue",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      },
      {
        "internalType": "uint8",
        "name": "offset",
        "type": "uint8"
      },
      {
        "internalType": "bool",
        "name": "verifyTxInclusion",
        "type": "bool"
      }
    ],
    "name": "verifyInclusion",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "age",
        "type": "uint256"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "address",
        "name": "exitor",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "childToken",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "rootToken",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "exitAmountOrTokenId",
        "type": "uint256"
      },
      {
        "internalType": "bytes32",
        "name": "txHash",
        "type": "bytes32"
      },
      {
        "internalType": "bool",
        "name": "isRegularExit",
        "type": "bool"
      },
      {
        "internalType": "uint256",
        "name": "priority",
        "type": "uint256"
      }
    ],
    "name": "addExitToQueue",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "uint256",
        "name": "exitId",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "age",
        "type": "uint256"
      },
      {
        "internalType": "address",
        "name": "utxoOwner",
        "type": "address"
      },
      {
        "internalType": "address",
        "name": "token",
        "type": "address"
      }
    ],
    "name": "addInput",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "uint256",
        "name": "exitId",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "inputId",
        "type": "uint256"
      },
      {
        "internalType": "bytes",
        "name": "challengeData",
        "type": "bytes"
      },
      {
        "internalType": "address",
        "name": "adjudicatorPredicate",
        "type": "address"
      }
    ],
    "name": "challengeExit",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
