export const abi = [
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "data1",
        "type": "bytes"
      },
      {
        "internalType": "bytes",
        "name": "data2",
        "type": "bytes"
      },
      {
        "internalType": "bytes32",
        "name": "orderId",
        "type": "bytes32"
      },
      {
        "internalType": "uint256",
        "name": "expiration",
        "type": "uint256"
      },
      {
        "internalType": "address",
        "name": "taker",
        "type": "address"
      }
    ],
    "name": "executeOrder",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
