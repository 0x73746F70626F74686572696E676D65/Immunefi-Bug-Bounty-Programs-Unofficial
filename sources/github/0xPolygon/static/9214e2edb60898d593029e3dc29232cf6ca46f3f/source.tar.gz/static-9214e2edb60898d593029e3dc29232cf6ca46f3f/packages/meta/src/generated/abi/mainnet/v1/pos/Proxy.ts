export const abi = [
  {
    "inputs": [],
    "name": "proxyType",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "proxyTypeId",
        "type": "uint256"
      }
    ],
    "stateMutability": "pure",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "implementation",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
] as const;
