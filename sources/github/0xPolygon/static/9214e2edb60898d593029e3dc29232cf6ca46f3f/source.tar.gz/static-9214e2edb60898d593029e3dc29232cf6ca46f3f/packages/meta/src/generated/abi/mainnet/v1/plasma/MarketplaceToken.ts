export const abi = [
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "sig",
        "type": "bytes"
      },
      {
        "internalType": "uint256",
        "name": "tokenIdOrAmount",
        "type": "uint256"
      },
      {
        "internalType": "bytes32",
        "name": "data",
        "type": "bytes32"
      },
      {
        "internalType": "uint256",
        "name": "expiration",
        "type": "uint256"
      },
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      }
    ],
    "name": "transferWithSig",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
