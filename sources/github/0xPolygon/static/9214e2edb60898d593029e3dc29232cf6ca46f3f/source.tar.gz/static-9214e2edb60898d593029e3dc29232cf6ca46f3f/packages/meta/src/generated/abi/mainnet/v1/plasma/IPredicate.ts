export const abi = [
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "exit",
        "type": "bytes"
      },
      {
        "internalType": "bytes",
        "name": "inputUtxo",
        "type": "bytes"
      },
      {
        "internalType": "bytes",
        "name": "challengeData",
        "type": "bytes"
      }
    ],
    "name": "verifyDeprecation",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "state",
        "type": "bytes"
      }
    ],
    "name": "interpretStateUpdate",
    "outputs": [
      {
        "internalType": "bytes",
        "name": "",
        "type": "bytes"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "internalType": "bytes",
        "name": "data",
        "type": "bytes"
      }
    ],
    "name": "onFinalizeExit",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
] as const;
