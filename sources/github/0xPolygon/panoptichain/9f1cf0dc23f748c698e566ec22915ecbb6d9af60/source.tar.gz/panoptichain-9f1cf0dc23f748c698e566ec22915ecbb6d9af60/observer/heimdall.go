// Package observer defines the event and message handing objects that
// are ultimately going to be used for metrics tracking. The observers should be fast and not connect to external data.
package observer

import (
	"context"
	"fmt"
	"math/big"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/rs/zerolog"

	"github.com/0xPolygon/panoptichain/api"
	"github.com/0xPolygon/panoptichain/config"
	"github.com/0xPolygon/panoptichain/metrics"
	"github.com/0xPolygon/panoptichain/observer/topics"
	"github.com/0xPolygon/panoptichain/proto/heimdall"
)

type PreCommit struct {
	Type    uint64 `json:"type"`
	Height  string `json:"height"`
	Round   string `json:"round"`
	BlockId struct {
		Hash  string `json:"hash"`
		Parts struct {
			Total uint64 `json:"total"`
			Hash  string `json:"hash"`
		} `json:"parts"`
	} `json:"block_id"`
	Timestamp        string `json:"timestamp"`
	ValidatorAddress string `json:"validator_address"`
	ValidatorIndex   string `json:"validator_index"`
	Signature        string `json:"signature"`
	SideTxResults    []struct {
		TxHash string `json:"tx_hash"`
		Result uint64 `json:"result"`
		Sig    string `json:"sig"`
	} `json:"side_tx_results"`
}

type HeimdallBlock struct {
	Result struct {
		Block struct {
			Header struct {
				Time            string `json:"time"`
				Height          string `json:"height"`
				NumTxs          string `json:"num_txs"`
				ProposerAddress string `json:"proposer_address"`
			} `json:"header"`
			Data struct {
				Txs []string `json:"txs"`
			} `json:"data"`
			LastCommit struct {
				PreCommits []*PreCommit `json:"precommits"`
			} `json:"last_commit"`
		} `json:"block"`
	} `json:"result"`
}

type HeimdallValidator struct {
	Address          string `json:"address"`
	VotingPower      string `json:"voting_power"`
	ProposerPriority string `json:"proposer_priority"`
}

type HeimdallValidators struct {
	Result struct {
		BlockHeight string               `json:"block_height"`
		Validators  []*HeimdallValidator `json:"validators"`
		Count       string               `json:"count"`
		Total       string               `json:"total"`
	} `json:"result"`
}

func (b *HeimdallValidators) Validators() []*HeimdallValidator {
	return b.Result.Validators
}

// Number returns the Heimdall block number or nil if it doesn't exist.
func (b *HeimdallBlock) Number() *big.Int {
	height := b.Result.Block.Header.Height
	n, ok := new(big.Int).SetString(height, 10)
	if !ok {
		return nil
	}

	return n
}

func (b *HeimdallBlock) Time() (uint64, error) {
	parsedTime, err := time.Parse(time.RFC3339Nano, b.Result.Block.Header.Time)
	if err != nil {
		return 0, err
	}

	return uint64(parsedTime.Unix()), nil
}

func (b *HeimdallBlock) Txs() *big.Int {
	txs, ok := new(big.Int).SetString(b.Result.Block.Header.NumTxs, 10)
	if !ok {
		return big.NewInt(int64(len(b.Result.Block.Data.Txs)))
	}

	return txs
}

func (b *HeimdallBlock) PreCommits() []*PreCommit {
	return b.Result.Block.LastCommit.PreCommits
}

func (b *HeimdallBlock) ProposerAddress() string {
	return b.Result.Block.Header.ProposerAddress
}

type HeimdallBlockIntervalObserver struct {
	blockInterval *prometheus.HistogramVec
}

func (o *HeimdallBlockIntervalObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.HeimdallBlockInterval, o)

	o.blockInterval = metrics.NewHistogram(
		metrics.Heimdall,
		"block_interval",
		"The time interval (in seconds) between Heimdall blocks",
		newExponentialBuckets(2, 6),
	)
}

func (o *HeimdallBlockIntervalObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)

	interval := m.Data().(uint64)
	logger.Trace().Uint64("interval", interval).Msg("Heimdall block interval")

	o.blockInterval.WithLabelValues(m.Network().GetName(), m.Provider()).Observe(float64(interval))
}

func (o *HeimdallBlockIntervalObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.blockInterval}
}

type HeimdallBlockObserver struct {
	height        *prometheus.GaugeVec
	txs           *prometheus.HistogramVec
	totalTxs      *prometheus.CounterVec
	blockProposed *prometheus.CounterVec
}

func (o *HeimdallBlockObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.NewHeimdallBlock, o)

	o.height = metrics.NewGauge(
		metrics.Heimdall,
		"height",
		"The block height for Heimdall",
	)
	o.txs = metrics.NewHistogram(
		metrics.Heimdall,
		"transactions_per_block",
		"The number of transactions per Heimdall block",
		newExponentialBuckets(2, 11),
	)
	o.totalTxs = metrics.NewCounter(
		metrics.Heimdall,
		"total_transaction_count",
		"The number of total transactions observed for Heimdall",
	)
	o.blockProposed = metrics.NewCounter(
		metrics.Heimdall,
		"block_proposed",
		"Heimdall blocks proposed by validator",
		"proposer_address",
	)

	for _, h := range config.Config().Providers.HeimdallEndpoints {
		o.totalTxs.WithLabelValues(h.Name, h.Label).Add(0)
	}
}

func (o *HeimdallBlockObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)

	block := m.Data().(*HeimdallBlock)
	network := m.Network().GetName()
	provider := m.Provider()

	height := block.Number()
	if height == nil {
		logger.Error().Msg("Failed to get Heimdall block number")
	} else {
		h, _ := height.Float64()
		o.height.WithLabelValues(network, provider).Set(h)
	}

	txs, _ := block.Txs().Float64()
	o.txs.WithLabelValues(network, provider).Observe(txs)
	o.totalTxs.WithLabelValues(network, provider).Add(txs)

	if proposer := block.ProposerAddress(); proposer != "" {
		o.blockProposed.WithLabelValues(network, provider, CanonicalAddress(proposer)).Inc()
	}
}

func (o *HeimdallBlockObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.height, o.txs, o.totalTxs, o.blockProposed}
}

type HeimdallSignatureCountObserver struct {
	signature *prometheus.GaugeVec
}

func (o *HeimdallSignatureCountObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.NewHeimdallBlock, o)

	o.signature = metrics.NewGauge(
		metrics.Heimdall,
		"signatures",
		"The number of signatures on block",
	)
}

func (o *HeimdallSignatureCountObserver) Notify(ctx context.Context, m Message) {
	block := m.Data().(*HeimdallBlock)
	o.signature.WithLabelValues(m.Network().GetName(), m.Provider()).Set(float64(len(block.PreCommits())))
}

func (o *HeimdallSignatureCountObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.signature}
}

// ChainID is a uint64 that tolerates the empty string.
//
// Heimdall's `bor_chain_id` is a STRING on the wire, not a number, so its
// zero value serialises as "" rather than "0". An empty buffered checkpoint
// looks like this, and it is the normal state for a chain between
// checkpoints:
//
//	{"checkpoint":{"id":"0","bor_chain_id":"","timestamp":"0", ...}}
//
// With a plain `uint64` and a `,string` tag, encoding/json rejects that whole
// response:
//
//	json: invalid use of ,string struct tag, trying to unmarshal "" into uint64
//
// which discarded the entire checkpoint, not just this one field. On Amoy that
// fired roughly every 12 seconds, continuously.
//
// The sibling numeric fields do not need this: they are genuine numbers and
// serialise as "0" when unset. Only bor_chain_id is a string.
type ChainID uint64

func (c *ChainID) UnmarshalJSON(b []byte) error {
	s := strings.TrimSpace(string(b))

	// null, or the "" the API sends when no checkpoint is buffered.
	if s == "null" || s == `""` || s == "" {
		*c = 0
		return nil
	}

	s = strings.Trim(s, `"`)
	if s == "" {
		*c = 0
		return nil
	}

	v, err := strconv.ParseUint(s, 10, 64)
	if err != nil {
		return fmt.Errorf("bor_chain_id %q: %w", s, err)
	}

	*c = ChainID(v)

	return nil
}

type HeimdallMilestoneCount struct {
	Count uint64 `json:"count,string"`
}

type HeimdallMilestone struct {
	Proposer    string  `json:"proposer"`
	StartBlock  uint64  `json:"start_block,string"`
	EndBlock    uint64  `json:"end_block,string"`
	Hash        string  `json:"hash"`
	BorChainID  ChainID `json:"bor_chain_id"`
	MilestoneID string  `json:"milestone_id"`
	Timestamp   int64   `json:"timestamp,string"`
	Count       int64

	// Votes contains the milestone votes from the block where this milestone was finalized.
	// This is populated by matching the milestone range to vote extensions.
	Votes *HeimdallMilestoneVotes
}

type HeimdallMilestoneV2 struct {
	Milestone HeimdallMilestone `json:"milestone"`
}

type MilestoneObserver struct {
	observed   *prometheus.CounterVec
	proposed   *prometheus.CounterVec
	blockRange *prometheus.HistogramVec

	// Vote metrics (merged from HeimdallMilestoneVoteObserver)
	voteProposed        *prometheus.CounterVec
	voteMissed          *prometheus.CounterVec
	voteSignedButMissed *prometheus.CounterVec
	votingPower         *prometheus.GaugeVec
}

// Notify drives count/vote accounting from the per-milestone backlog stream. It
// gaps during catch-up (see refreshMilestone), which is acceptable.
func (o *MilestoneObserver) Notify(ctx context.Context, m Message) {
	network := m.Network().GetName()
	provider := m.Provider()

	logger := NewLogger(o, m)
	milestone := m.Data().(*HeimdallMilestone)

	o.observed.WithLabelValues(network, provider).Inc()
	o.proposed.WithLabelValues(network, provider, CanonicalAddress(milestone.Proposer)).Inc()

	// Guard the unsigned subtraction: a malformed milestone with EndBlock <
	// StartBlock would otherwise underflow to a huge value and skew the histogram.
	if milestone.EndBlock >= milestone.StartBlock {
		o.blockRange.WithLabelValues(network, provider).Observe(float64(milestone.EndBlock - milestone.StartBlock))
	}

	// Process vote metrics if votes are attached
	votes := milestone.Votes
	if votes == nil {
		return
	}

	var vpPct float64
	if votes.TotalVotingPower > 0 {
		vpPct = float64(votes.MilestoneVotingPower) / float64(votes.TotalVotingPower) * 100
	}
	o.votingPower.WithLabelValues(network, provider).Set(vpPct)

	for _, vote := range votes.Votes {
		id := strconv.FormatUint(vote.ValidatorID, 10)
		switch {
		case vote.HasMilestone:
			o.voteProposed.WithLabelValues(network, provider, id, CanonicalAddress(vote.ValidatorAddress)).Inc()
		case vote.BlockIDFlag == heimdall.BlockIDFlagCommit:
			// Signed consensus but didn't propose milestone
			o.voteSignedButMissed.WithLabelValues(network, provider, id, CanonicalAddress(vote.ValidatorAddress)).Inc()
			o.voteMissed.WithLabelValues(network, provider, id, CanonicalAddress(vote.ValidatorAddress)).Inc()
		default:
			// Absent/nil - didn't sign consensus and no milestone
			o.voteMissed.WithLabelValues(network, provider, id, CanonicalAddress(vote.ValidatorAddress)).Inc()
		}
	}

	missed := votes.TotalValidators - votes.MilestoneVoters
	if missed > 0 {
		logger.Trace().
			Uint64("height", votes.Height).
			Int("total_validators", votes.TotalValidators).
			Int("milestone_voters", votes.MilestoneVoters).
			Int("missed", missed).
			Msg("Detected validators without milestone vote")
	}
}

func (o *MilestoneObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.Milestone, o)

	o.observed = metrics.NewCounter(metrics.Heimdall, "milestone_observed", "The number of milestones observed")
	o.proposed = metrics.NewCounter(metrics.Heimdall, "milestone_proposed", "Milestones proposed by validator", "proposer")
	o.blockRange = metrics.NewHistogram(
		metrics.Heimdall,
		"milestone_block_range",
		"The number of blocks in the milestone",
		newExponentialBuckets(2, 10),
	)

	// Vote metrics (merged from HeimdallMilestoneVoteObserver)
	o.voteProposed = metrics.NewCounter(
		metrics.Heimdall,
		"milestone_vote_proposed",
		"Validators who proposed milestone in vote extension",
		"validator_id", "signer_address",
	)
	o.voteMissed = metrics.NewCounter(
		metrics.Heimdall,
		"milestone_vote_missed",
		"Validators who didn't propose milestone",
		"validator_id", "signer_address",
	)
	o.voteSignedButMissed = metrics.NewCounter(
		metrics.Heimdall,
		"milestone_signed_but_missed",
		"Validators who signed consensus but didn't propose milestone",
		"validator_id", "signer_address",
	)
	o.votingPower = metrics.NewGauge(
		metrics.Heimdall,
		"milestone_voting_power",
		"Percentage of voting power that proposed milestone",
	)

	for _, h := range config.Config().Providers.HeimdallEndpoints {
		o.observed.WithLabelValues(h.Name, h.Label).Add(0)
	}
}

func (o *MilestoneObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{
		o.observed,
		o.proposed,
		o.blockRange,
		o.voteProposed,
		o.voteMissed,
		o.voteSignedButMissed,
		o.votingPower,
	}
}

// MilestoneLatestObserver drives the milestone freshness gauges from the tip
// milestone, which is published every cycle independent of the backlog stream so
// the gauges never lag behind a slow catch-up.
type MilestoneLatestObserver struct {
	time       *prometheus.GaugeVec
	count      *prometheus.GaugeVec
	startBlock *prometheus.GaugeVec
	endBlock   *prometheus.GaugeVec
}

func (o *MilestoneLatestObserver) Notify(ctx context.Context, m Message) {
	latest := m.Data().(*HeimdallMilestone)
	if latest == nil || latest.Timestamp == 0 {
		return
	}

	network := m.Network().GetName()
	provider := m.Provider()

	seconds := time.Since(time.Unix(latest.Timestamp, 0)).Seconds()
	o.time.WithLabelValues(network, provider).Set(seconds)
	o.count.WithLabelValues(network, provider).Set(float64(latest.Count))
	o.startBlock.WithLabelValues(network, provider).Set(float64(latest.StartBlock))
	o.endBlock.WithLabelValues(network, provider).Set(float64(latest.EndBlock))
}

func (o *MilestoneLatestObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.MilestoneLatest, o)

	o.time = metrics.NewGauge(metrics.Heimdall, "time_since_last_milestone", "The time since last milestone")
	o.count = metrics.NewGauge(metrics.Heimdall, "milestone_count", "The milestone count")
	o.startBlock = metrics.NewGauge(metrics.Heimdall, "milestone_start_block", "The milestone start block")
	o.endBlock = metrics.NewGauge(metrics.Heimdall, "milestone_end_block", "The milestone end block")
}

func (o *MilestoneLatestObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{
		o.time,
		o.count,
		o.startBlock,
		o.endBlock,
	}
}

// HeimdallProposalRound is what a missed block proposal actually is: the
// consensus round a block committed in, plus the validators CometBFT selected
// in the rounds before it that did not propose. Round 0 means nothing missed.
//
// This REPLACES the previous implementation, which inferred misses from
// proposer-priority ordering. That inference approximated CometBFT's selection
// and was wrong by ~30x even on a healthy chain -- see
// missed-block-proposals.md. The metric name is deliberately unchanged so
// existing dashboards and alerts keep working; only the values become correct.
type HeimdallProposalRound struct {
	Round  int
	Missed []string
}

type HeimdallMissedBlockProposal map[uint64]HeimdallProposalRound

type HeimdallMissedBlockProposalObserver struct {
	// Failed rounds per network. Derived straight from the commit, so it does
	// not depend on predicting the proposer and is correct regardless of the
	// priority-ordering question.
	failedRounds *prometheus.CounterVec

	// The same misses attributed to a validator, by replaying CometBFT's
	// selection. Attribution is only as good as that replay, which is why the
	// unattributed counter above exists next to it.
	missedProposal *prometheus.CounterVec
}

func (o *HeimdallMissedBlockProposalObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)

	rounds := m.Data().(HeimdallMissedBlockProposal)
	for blockNumber, r := range rounds {
		// Added unconditionally, including Add(0). A counter that only comes
		// into existence on the first failed round is absent rather than zero
		// on a healthy chain, which cannot be rate()'d or alerted on.
		o.failedRounds.WithLabelValues(m.Network().GetName(), m.Provider()).Add(float64(r.Round))

		if r.Round == 0 {
			continue
		}

		logger.Debug().
			Uint64("block_number", blockNumber).
			Int("round", r.Round).
			Strs("missed", r.Missed).
			Msg("Block committed in a non-zero round")

		for _, proposer := range r.Missed {
			o.missedProposal.WithLabelValues(m.Network().GetName(), m.Provider(), CanonicalAddress(proposer)).Inc()
		}
	}
}

func (o *HeimdallMissedBlockProposalObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.HeimdallMissedBlockProposal, o)

	o.failedRounds = metrics.NewCounter(
		metrics.Heimdall,
		"failed_proposal_round",
		"Consensus rounds that failed to produce a block, summed per block",
	)

	o.missedProposal = metrics.NewCounter(
		metrics.Heimdall,
		"missed_block_proposal",
		"Validators selected as proposer for a round that did not propose",
		"signer_address",
	)
}

func (o *HeimdallMissedBlockProposalObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.failedRounds, o.missedProposal}
}

type HeimdallCheckpoint struct {
	ID         uint64  `json:"id,string"`
	StartBlock uint64  `json:"start_block,string"`
	EndBlock   uint64  `json:"end_block,string"`
	RootHash   string  `json:"root_hash"`
	BorChainID ChainID `json:"bor_chain_id"`
	Timestamp  uint64  `json:"timestamp,string"`
	Proposer   string  `json:"proposer"`
}

type HeimdallCheckpointV2 struct {
	Checkpoint HeimdallCheckpoint `json:"checkpoint"`
}

type HeimdallCheckpointObserver struct {
	startBlock *prometheus.GaugeVec
	endBlock   *prometheus.GaugeVec
	id         *prometheus.GaugeVec
	time       *prometheus.GaugeVec
}

func (o *HeimdallCheckpointObserver) Notify(ctx context.Context, m Message) {
	checkpoint := m.Data().(*HeimdallCheckpoint)

	var seconds float64
	if checkpoint.Timestamp != 0 {
		seconds = m.Time().Sub(time.Unix(int64(checkpoint.Timestamp), 0)).Seconds()
	}

	o.startBlock.WithLabelValues(m.Network().GetName(), m.Provider()).Set(float64(checkpoint.StartBlock))
	o.endBlock.WithLabelValues(m.Network().GetName(), m.Provider()).Set(float64(checkpoint.EndBlock))
	o.id.WithLabelValues(m.Network().GetName(), m.Provider()).Set(float64(checkpoint.ID))
	o.time.WithLabelValues(m.Network().GetName(), m.Provider()).Set(seconds)
}

func (o *HeimdallCheckpointObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.Checkpoint, o)

	o.startBlock = metrics.NewGauge(metrics.Heimdall, "checkpoint_start_block", "The checkpoint start block")
	o.endBlock = metrics.NewGauge(metrics.Heimdall, "checkpoint_end_block", "The checkpoint end block")
	o.id = metrics.NewGauge(metrics.Heimdall, "checkpoint_id", "The checkpoint id")
	o.time = metrics.NewGauge(metrics.Heimdall, "time_since_last_checkpoint", "The time since last checkpoint")
}

func (o *HeimdallCheckpointObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.startBlock, o.endBlock, o.id, o.time}
}

type HeimdallCurrentCheckpointProposer struct {
	Validator api.Validator `json:"validator"`
}

type HeimdallPrepareNextCheckpoint struct {
	Checkpoint struct {
		Proposer string `json:"proposer"`
	} `json:"checkpoint"`
}

type HeimdallMissedCheckpointProposalObserver struct {
	counter *prometheus.CounterVec
}

func (o *HeimdallMissedCheckpointProposalObserver) Notify(ctx context.Context, m Message) {
	proposers := m.Data().([]string)
	for _, proposer := range proposers {
		o.counter.WithLabelValues(m.Network().GetName(), m.Provider(), CanonicalAddress(proposer)).Inc()
	}
}

func (o *HeimdallMissedCheckpointProposalObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.MissedCheckpointProposal, o)
	o.counter = metrics.NewCounter(
		metrics.Heimdall,
		"missed_checkpoint_proposal",
		"Missed checkpoint proposals",
		"signer_address",
	)
}

func (o *HeimdallMissedCheckpointProposalObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.counter}
}

type HeimdallSpan struct {
	ID                uint64          `json:"id,string"`
	StartBlock        uint64          `json:"start_block,string"`
	EndBlock          uint64          `json:"end_block,string"`
	SelectedProducers []api.Validator `json:"selected_producers"`
}

type HeimdallSpanV2 struct {
	Span HeimdallSpan `json:"span"`
}

type HeimdallSpans struct {
	Curr *HeimdallSpan
	Prev *HeimdallSpan
}

// ValidatorMap maps validator IDs to validators.
type ValidatorMap = map[uint64]api.Validator

// HeimdallValidatorSets contains the current and previous validator sets.
type HeimdallValidatorSets struct {
	Curr ValidatorMap
	Prev ValidatorMap
}

type HeimdallCommitSignature struct {
	BlockIDFlag      int    `json:"block_id_flag"`
	ValidatorAddress string `json:"validator_address"`
	Timestamp        string `json:"timestamp"`
	Signature        string `json:"signature"`
}

type HeimdallCommitData struct {
	Height string `json:"height"`
	// Round is the consensus round the block committed in. Non-zero means one
	// or more selected proposers failed to propose and consensus moved on --
	// which is the literal definition of a missed block proposal.
	Round      int                       `json:"round"`
	Signatures []HeimdallCommitSignature `json:"signatures"`
}

type HeimdallSignedHeader struct {
	Commit HeimdallCommitData `json:"commit"`
}

type HeimdallCommit struct {
	Result struct {
		SignedHeader HeimdallSignedHeader `json:"signed_header"`
	} `json:"result"`
}

type HeimdallMissedVote struct {
	ValidatorID   uint64
	SignerAddress string
	FlagLabel     string
}

type HeimdallMissedVotes struct {
	Height       uint64
	MissingCount int
	MissedVotes  []HeimdallMissedVote
}

// HeimdallMilestoneVote represents a validator's milestone vote from vote extensions.
type HeimdallMilestoneVote struct {
	ValidatorAddress string
	ValidatorID      uint64
	VotingPower      int64
	BlockIDFlag      int // see heimdall.BlockIDFlag* constants
	HasMilestone     bool
	MilestoneStart   uint64
	MilestoneEnd     uint64
}

// HeimdallMilestoneVotes represents all milestone votes for a block.
type HeimdallMilestoneVotes struct {
	Height               uint64
	TotalValidators      int
	TotalVotingPower     int64
	MilestoneVoters      int   // validators who proposed milestone
	MilestoneVotingPower int64 // VP of milestone voters
	Votes                []HeimdallMilestoneVote
}

type HeimdallSpanObserver struct {
	spanID     *prometheus.GaugeVec
	startBlock *prometheus.GaugeVec
	endBlock   *prometheus.GaugeVec
	producer   *prometheus.GaugeVec
	overlaps   *prometheus.CounterVec
	overlapped *prometheus.CounterVec
}

func (o *HeimdallSpanObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.Span, o)

	o.spanID = metrics.NewGauge(metrics.Heimdall, "span_id", "The span id")
	o.startBlock = metrics.NewGauge(metrics.Heimdall, "span_start_block", "The span start block")
	o.endBlock = metrics.NewGauge(metrics.Heimdall, "span_end_block", "The span end block")
	o.producer = metrics.NewGauge(metrics.Heimdall, "span_producer", "The span selected producer")
	o.overlaps = metrics.NewCounter(metrics.Heimdall, "span_overlaps", "The number of overlapping spans")
	o.overlapped = metrics.NewCounter(metrics.Heimdall, "span_overlapped_blocks", "The number of overlapped blocks between spans")

	for _, h := range config.Config().Providers.HeimdallEndpoints {
		o.overlaps.WithLabelValues(h.Name, h.Label).Add(0)
		o.overlapped.WithLabelValues(h.Name, h.Label).Add(0)
	}
}

func (o *HeimdallSpanObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)
	data := m.Data().(*HeimdallSpans)

	network := m.Network().GetName()
	provider := m.Provider()

	curr := data.Curr
	if curr == nil {
		return
	}

	o.spanID.WithLabelValues(network, provider).Set(float64(curr.ID))
	o.startBlock.WithLabelValues(network, provider).Set(float64(curr.StartBlock))
	o.endBlock.WithLabelValues(network, provider).Set(float64(curr.EndBlock))

	if len(curr.SelectedProducers) != 1 {
		logger.Warn().
			Int("selected_producers", len(curr.SelectedProducers)).
			Msg("Unexpected number of selected producers")
	} else {
		producer := float64(curr.SelectedProducers[0].ID)
		o.producer.WithLabelValues(network, provider).Set(producer)
	}

	prev := data.Prev
	if prev == nil || curr.ID <= prev.ID {
		return
	}

	if curr.StartBlock <= prev.EndBlock || curr.StartBlock == prev.StartBlock {
		o.overlaps.WithLabelValues(network, provider).Add(1)
		blocks := prev.EndBlock - curr.StartBlock + 1
		o.overlapped.WithLabelValues(network, provider).Add(float64(blocks))
	}
}

func (o *HeimdallSpanObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{
		o.spanID,
		o.startBlock,
		o.endBlock,
		o.producer,
		o.overlaps,
		o.overlapped,
	}
}

// HeimdallActiveSpanObserver reports the active span: the span containing the
// current Bor block. Unlike HeimdallSpanObserver (the latest span), it is
// published every cycle and its series are removed when the Bor height is not
// yet known (no RPC provider for the network, or before its first successful
// fetch). A later Bor outage retains the last-good height, so the series hold
// rather than drop.
type HeimdallActiveSpanObserver struct {
	spanID     *prometheus.GaugeVec
	startBlock *prometheus.GaugeVec
	endBlock   *prometheus.GaugeVec
}

func (o *HeimdallActiveSpanObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.ActiveSpan, o)
	o.spanID = metrics.NewGauge(metrics.Heimdall, "active_span_id", "The id of the active span (the span containing the current Bor block)")
	o.startBlock = metrics.NewGauge(metrics.Heimdall, "active_span_start_block", "The start block of the active span")
	o.endBlock = metrics.NewGauge(metrics.Heimdall, "active_span_end_block", "The end block of the active span")
}

func (o *HeimdallActiveSpanObserver) Notify(ctx context.Context, m Message) {
	span := m.Data().(*HeimdallSpan)

	network := m.Network().GetName()
	provider := m.Provider()

	// Unknown span: drop the series so a stale value doesn't linger.
	if span == nil {
		o.spanID.DeleteLabelValues(network, provider)
		o.startBlock.DeleteLabelValues(network, provider)
		o.endBlock.DeleteLabelValues(network, provider)
		return
	}

	o.spanID.WithLabelValues(network, provider).Set(float64(span.ID))
	o.startBlock.WithLabelValues(network, provider).Set(float64(span.StartBlock))
	o.endBlock.WithLabelValues(network, provider).Set(float64(span.EndBlock))
}

func (o *HeimdallActiveSpanObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{
		o.spanID,
		o.startBlock,
		o.endBlock,
	}
}

type HeimdallValidatorSetChangeObserver struct {
	counter *prometheus.CounterVec
}

func (o *HeimdallValidatorSetChangeObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.ValidatorSet, o)
	o.counter = metrics.NewCounter(
		metrics.Heimdall,
		"validator_set_change",
		"The number of validator set changes (onboarded or unbonded)",
		"change_type",
	)

	for _, h := range config.Config().Providers.HeimdallEndpoints {
		o.counter.WithLabelValues(h.Name, h.Label, "onboarded").Add(0)
		o.counter.WithLabelValues(h.Name, h.Label, "unbonded").Add(0)
	}
}

func (o *HeimdallValidatorSetChangeObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)
	data := m.Data().(*HeimdallValidatorSets)

	if data.Prev == nil {
		return
	}

	o.detectChanges(logger, m, data.Curr, data.Prev, "onboarded")
	o.detectChanges(logger, m, data.Prev, data.Curr, "unbonded")
}

// detectChanges finds validators in set A that are not in set B and records
// them as the specified change type.
func (o *HeimdallValidatorSetChangeObserver) detectChanges(logger zerolog.Logger, m Message, a, b ValidatorMap, changeType string) {
	for id, v := range a {
		if _, exists := b[id]; exists {
			continue
		}

		logger.Info().
			Uint64("validator_id", v.ID).
			Str("signer", v.Signer).
			Str("change_type", changeType).
			Msg("Validator set change detected")

		o.counter.WithLabelValues(m.Network().GetName(), m.Provider(), changeType).Inc()
	}
}

func (o *HeimdallValidatorSetChangeObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.counter}
}

// HeimdallMissedVoteObserver tracks missed consensus votes.
type HeimdallMissedVoteObserver struct {
	consensus *prometheus.CounterVec
}

func (o *HeimdallMissedVoteObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.MissedVote, o)

	o.consensus = metrics.NewCounter(
		metrics.Heimdall,
		"missed_consensus_vote",
		"Missed Heimdall consensus votes",
		"validator_id", "signer_address", "flag",
	)
}

func (o *HeimdallMissedVoteObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)
	missed := m.Data().(*HeimdallMissedVotes)
	network := m.Network().GetName()
	provider := m.Provider()

	for _, vote := range missed.MissedVotes {
		id := strconv.FormatUint(vote.ValidatorID, 10)
		o.consensus.WithLabelValues(network, provider, id, CanonicalAddress(vote.SignerAddress), vote.FlagLabel).Inc()
	}

	if missed.MissingCount > 0 {
		logger.Trace().
			Uint64("height", missed.Height).
			Int("missing_count", missed.MissingCount).
			Msg("Detected missed votes")
	}
}

func (o *HeimdallMissedVoteObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.consensus}
}

// HeimdallBufferedCheckpointObserver tracks buffered checkpoint metrics.
type HeimdallBufferedCheckpointObserver struct {
	exists     *prometheus.GaugeVec
	id         *prometheus.GaugeVec
	startBlock *prometheus.GaugeVec
	endBlock   *prometheus.GaugeVec
	timeSince  *prometheus.GaugeVec
}

func (o *HeimdallBufferedCheckpointObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.BufferedCheckpoint, o)

	o.exists = metrics.NewGauge(
		metrics.Heimdall,
		"buffered_checkpoint_exists",
		"Whether a buffered checkpoint exists (0 or 1)",
	)
	o.id = metrics.NewGauge(
		metrics.Heimdall,
		"buffered_checkpoint_id",
		"Checkpoint ID of the buffered checkpoint (0 if none)",
	)
	o.startBlock = metrics.NewGauge(
		metrics.Heimdall,
		"buffered_checkpoint_start_block",
		"Start block of the buffered checkpoint (0 if none)",
	)
	o.endBlock = metrics.NewGauge(
		metrics.Heimdall,
		"buffered_checkpoint_end_block",
		"End block of the buffered checkpoint (0 if none)",
	)
	o.timeSince = metrics.NewGauge(
		metrics.Heimdall,
		"time_since_buffered_checkpoint",
		"Seconds since buffered checkpoint was created (0 if none)",
	)
}

func (o *HeimdallBufferedCheckpointObserver) Notify(ctx context.Context, m Message) {
	checkpoint := m.Data().(*HeimdallCheckpoint)
	network := m.Network().GetName()
	provider := m.Provider()

	if checkpoint == nil {
		o.exists.WithLabelValues(network, provider).Set(0)
		o.id.WithLabelValues(network, provider).Set(0)
		o.startBlock.WithLabelValues(network, provider).Set(0)
		o.endBlock.WithLabelValues(network, provider).Set(0)
		o.timeSince.WithLabelValues(network, provider).Set(0)
		return
	}

	o.exists.WithLabelValues(network, provider).Set(1)
	o.id.WithLabelValues(network, provider).Set(float64(checkpoint.ID))
	o.startBlock.WithLabelValues(network, provider).Set(float64(checkpoint.StartBlock))
	o.endBlock.WithLabelValues(network, provider).Set(float64(checkpoint.EndBlock))

	var timeSince float64
	if checkpoint.Timestamp != 0 {
		timeSince = time.Since(time.Unix(int64(checkpoint.Timestamp), 0)).Seconds()
	}
	o.timeSince.WithLabelValues(network, provider).Set(timeSince)
}

func (o *HeimdallBufferedCheckpointObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.exists, o.id, o.startBlock, o.endBlock, o.timeSince}
}

// HeimdallFeeBalance is one validator's Heimdall fee account balance.
//
// Validators fund this account on Ethereum (StakeManager.topUpForFee) and
// Heimdall debits a flat fee per transaction from it -- not gas-metered, see
// auth params tx_fees, 0.001 POL on mainnet -- for every checkpoint, milestone,
// span and clerk ack the signer submits. So the balance is transactions
// remaining, and at zero the validator cannot participate.
type HeimdallFeeBalance struct {
	ValidatorID   uint64
	SignerAddress string
	// Denom becomes a metric label rather than being summed away, so a second
	// denomination would show up as its own series instead of silently
	// inflating the POL balance.
	Denom string
	// Amount is in the denomination's base unit (wei for pol), matching the
	// rpc_ balance gauges.
	Amount *big.Int
}

// HeimdallFeeBalances is one sweep's full result, carrying every validator it
// resolved so the observer can retire those that left the set.
type HeimdallFeeBalances struct {
	Balances []HeimdallFeeBalance
	// Failed is how many validators the sweep could not resolve -- query error
	// or deadline. A partial sweep must not retire the series it never reached,
	// so this gates the reconciliation.
	Failed int
}

// HeimdallValidatorFeeBalanceObserver tracks each validator's Heimdall fee
// account balance, which is what the staking portal shows as "Heimdall Fees".
type HeimdallValidatorFeeBalanceObserver struct {
	balance *prometheus.GaugeVec
	swept   *prometheus.GaugeVec
	failed  *prometheus.GaugeVec

	// mu guards seen: one observer serves every configured endpoint and the
	// event bus notifies in its own goroutine, so mainnet and Amoy can land
	// here at once.
	mu sync.Mutex
	// seen holds the label values currently set, keyed by network and provider,
	// so a departed validator's series is deleted rather than left frozen at
	// its last balance -- a stale low balance would alert forever.
	seen map[string]map[feeBalanceKey]struct{}
}

// feeBalanceKey identifies one fee balance series within a network/provider.
type feeBalanceKey struct {
	validatorID   string
	signerAddress string
	denom         string
}

func (o *HeimdallValidatorFeeBalanceObserver) Register(eb *EventBus) {
	eb.Subscribe(topics.ValidatorFeeBalance, o)

	o.balance = metrics.NewGauge(
		metrics.Heimdall,
		"validator_fee_balance",
		"Validator Heimdall fee account balance, in the denomination's base unit (wei for pol)",
		"validator_id", "signer_address", "denom",
	)
	o.swept = metrics.NewGauge(
		metrics.Heimdall,
		"validator_fee_balance_swept",
		"Number of validators whose Heimdall fee balance was resolved in the last sweep",
	)
	o.failed = metrics.NewGauge(
		metrics.Heimdall,
		"validator_fee_balance_failed",
		"Number of validators whose Heimdall fee balance could not be resolved in the last sweep",
	)

	o.seen = make(map[string]map[feeBalanceKey]struct{})
}

func (o *HeimdallValidatorFeeBalanceObserver) Notify(ctx context.Context, m Message) {
	logger := NewLogger(o, m)

	data, ok := m.Data().(*HeimdallFeeBalances)
	if !ok || data == nil {
		return
	}

	network := m.Network().GetName()
	provider := m.Provider()
	scope := network + "\x00" + provider

	o.mu.Lock()
	defer o.mu.Unlock()

	if o.seen == nil {
		o.seen = make(map[string]map[feeBalanceKey]struct{})
	}
	if o.seen[scope] == nil {
		o.seen[scope] = make(map[feeBalanceKey]struct{})
	}

	o.swept.WithLabelValues(network, provider).Set(float64(len(data.Balances)))
	o.failed.WithLabelValues(network, provider).Set(float64(data.Failed))

	curr := make(map[feeBalanceKey]struct{}, len(data.Balances))
	for _, b := range data.Balances {
		if b.Amount == nil {
			continue
		}

		key := feeBalanceKey{
			validatorID:   strconv.FormatUint(b.ValidatorID, 10),
			signerAddress: CanonicalAddress(b.SignerAddress),
			denom:         b.Denom,
		}
		curr[key] = struct{}{}

		amount, _ := new(big.Float).SetInt(b.Amount).Float64()
		o.balance.
			WithLabelValues(network, provider, key.validatorID, key.signerAddress, key.denom).
			Set(amount)
	}

	// Only reconcile on a complete sweep: a partial one says nothing about the
	// validators it never reached, and deleting their series would blank the
	// gauge -- and any alert on it -- every time the API is slow.
	if data.Failed > 0 {
		logger.Debug().
			Int("failed", data.Failed).
			Msg("Partial Heimdall fee balance sweep; keeping existing series")

		for key := range curr {
			o.seen[scope][key] = struct{}{}
		}

		return
	}

	for key := range o.seen[scope] {
		if _, ok := curr[key]; ok {
			continue
		}

		logger.Info().
			Str("validator_id", key.validatorID).
			Str("signer_address", key.signerAddress).
			Msg("Retiring Heimdall fee balance series for a validator no longer in the set")

		o.balance.DeleteLabelValues(network, provider, key.validatorID, key.signerAddress, key.denom)
	}

	o.seen[scope] = curr
}

func (o *HeimdallValidatorFeeBalanceObserver) GetCollectors() []prometheus.Collector {
	return []prometheus.Collector{o.balance, o.swept, o.failed}
}
