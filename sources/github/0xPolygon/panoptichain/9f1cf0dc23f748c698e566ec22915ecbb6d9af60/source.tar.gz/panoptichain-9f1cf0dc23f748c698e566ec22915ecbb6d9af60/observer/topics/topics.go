package topics

//go:generate stringer -type=ObservableTopic
type ObservableTopic int

const (
	AccountBalances             ObservableTopic = iota // observer.AccountBalances
	AccountTxs                                         // observer.AccountTxs
	AggchainEvent                                      // *observer.AggchainEvent
	BlockInterval                                      // uint64
	BorMissedBlockProposal                             // observer.MissedBlockProposal
	BorStateSync                                       // *observer.StateSync
	BridgeEvent                                        // *contracts.PolygonZkEVMBridgeV2BridgeEvent
	BridgeEventTimes                                   // *observer.BridgeEventTimes
	Checkpoint                                         // *observer.HeimdallCheckpoint
	CheckpointSignatures                               // *observer.CheckpointSignatures
	ClaimEvent                                         // *contracts.PolygonZkEVMBridgeV2ClaimEvent
	ClaimEventTimes                                    // *observer.ClaimEventTimes
	DepositCounts                                      // *observer.DepositCounts
	ExchangeRate                                       // observer.ExchangeRate
	ExitRoots                                          // *observer.ExitRoots
	FinalizedHeight                                    // uint64
	Grafana                                            // *observer.GrafanaResponse
	HashDivergence                                     // *observer.HashDivergence
	HeimdallBlockInterval                              // uint64
	Milestone                                          // *observer.HeimdallMilestone
	MissedCheckpointProposal                           // []string
	NewEVMBlock                                        // *types.Block
	NewHeimdallBlock                                   // *observer.HeimdallBlock
	ProofRequest                                       // *proto.ProofRequest
	RefreshStateTime                                   // *time.Duration
	Reorg                                              // *observer.DatastoreReorg
	RollupManager                                      // *observer.RollupManager
	SensorBlockEvents                                  // *observer.SensorBlockEvents
	SensorBlocks                                       // *observer.SensorBlocks
	Span                                               // *observer.HeimdallSpans
	StakeManager                                       // *observer.StakeManager
	SPOLController                                     // *observer.SPOLController
	StolenBlock                                        // *types.Block
	System                                             // *observer.System
	TimeToFinalized                                    // uint64
	TimeToMine                                         // float64
	TransactionPool                                    // *observer.TransactionPool
	TrustedBatch                                       // *util.Batch
	ValidatorWallet                                    // observer.ValidatorWalletBalances
	ValidatorSet                                       // *observer.HeimdallValidatorSets
	MissedVote                                         // *observer.HeimdallMissedVotes
	ZkEVMBatches                                       // observer.ZkEVMBatches
	StakingEvents                                      // *observer.StakingEvents
	BufferedCheckpoint                                 // *observer.HeimdallCheckpoint (nil if no buffered checkpoint)
	MilestoneLatest                                    // *observer.HeimdallMilestone (tip milestone, drives freshness gauges)
	ActiveSpan                                         // *observer.HeimdallSpan (span containing the current Bor block; nil when Bor height unavailable)
	RequesterUsage                                     // *observer.UsageSummary (most recent complete hour; nil when the hour has no usage)
	HeimdallMissedBlockProposal                        // observer.HeimdallMissedBlockProposal
	ValidatorFeeBalance                                // observer.HeimdallFeeBalances (nil when the sweep did not run this cycle)
)
