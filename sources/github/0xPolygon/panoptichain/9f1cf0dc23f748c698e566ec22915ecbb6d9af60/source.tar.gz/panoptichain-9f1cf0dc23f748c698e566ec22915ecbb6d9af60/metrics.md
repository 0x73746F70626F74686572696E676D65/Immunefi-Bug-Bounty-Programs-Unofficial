
## AccountBalancesObserver


### panoptichain_rpc_account_balance
The account balance (wei)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- address
- token
- tag

## AccountTxsObserver


### panoptichain_rpc_account_txs
Number of transactions from/to tracked accounts

Metric Type: CounterVec

Variable Labels:
- network
- provider
- address
- tag
- direction

## HeimdallActiveSpanObserver


### panoptichain_heimdall_active_span_id
The id of the active span (the span containing the current Bor block)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_active_span_start_block
The start block of the active span

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_active_span_end_block
The end block of the active span

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## AggchainObserver


### panoptichain_rpc_aggchain_latency
The difference between the L1 timestamp and the L2 block timestamp (in seconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

### panoptichain_rpc_aggchain_output_proposed_block_number
The block number in the OutputProposed event

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_aggchain_output_index
The output index in the OutputProposed event

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## BaseFeePerGasObserver


### panoptichain_rpc_base_fee_per_gas
The base fee per gas (gwei)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## BlockObserver


### panoptichain_rpc_height
The latest known block height

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_block
The total number of blocks observed

Metric Type: CounterVec

Variable Labels:
- network
- provider

### panoptichain_rpc_difficulty
The difficulty of the block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_block_size
The block size per block (bytes)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

### panoptichain_rpc_extra_size
The size of the extra data (bytes)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## BlockIntervalObserver


### panoptichain_rpc_block_interval
The number of seconds between blocks

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## BogonBlockObserver


### panoptichain_rpc_bogon_block
The total number of bogon blocks observed

Metric Type: CounterVec

Variable Labels:
- network
- provider

## BridgeEventObserver


### panoptichain_rpc_time_since_last_bridge_event
The time since the last zkEVM bridge event (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- origin_network
- destination_network

### panoptichain_rpc_bridge_event_deposit_count
The deposit count of the latest bridge event

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- origin_network
- destination_network
- origin_address

### panoptichain_rpc_bridge_event_amount
The amount in bridged (gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- origin_network
- destination_network
- origin_address

## CheckpointObserver


### panoptichain_rpc_checkpoint_id
The last header block ID

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- finalized

### panoptichain_rpc_checkpoint_signatures
The number of validators that signed the latest checkpoint

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- finalized

### panoptichain_rpc_time_since_last_checkpoint
The elapsed time since the last checkpoint

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- finalized

### panoptichain_rpc_signed_checkpoint
Counts the number of times a validator has signed a checkpoint

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer

### panoptichain_rpc_missed_checkpoint_signature
Counts the number of times a validator missed signing a checkpoint

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address

## ClaimEventObserver


### panoptichain_rpc_time_since_last_claim_event
The time since the last zkEVM claim event (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- origin_network

### panoptichain_rpc_claim_event_amount
The amount in claimed (gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- origin_network
- origin_address

### panoptichain_rpc_observed_claim_events
The number of claim events observed

Metric Type: CounterVec

Variable Labels:
- network
- provider
- origin_network
- origin_address

## DepositCountObserver


### panoptichain_rpc_bridge_deposit_count
zkEVM bridge deposit count

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_bridge_last_updated_deposit_count
zkEVM bridge last updated deposit count

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## DoubleSignObserver


### panoptichain_sensor_double_sign
Number of double sign events detected

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer_address

## EmptyBlockObserver


### panoptichain_rpc_empty_block
The total number of empty blocks observed

Metric Type: CounterVec

Variable Labels:
- network
- provider

## ExchangeRatesObserver


### panoptichain_exchange_rates
The exchange rate between the base and quote currencies

Metric Type: GaugeVec

Variable Labels:
- base
- quote

## ExitRootsObserver


### panoptichain_rpc_time_since_last_global_exit_root
The elapsed time since the last global exit root (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_time_since_last_mainnet_exit_root
The elapsed time since the last mainnet exit root (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_time_since_last_rollup_exit_root
The elapsed time since the last rollup exit root (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## FinalizedHeightObserver


### panoptichain_rpc_finalized_height
The latest known finalized block height

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## GasLimitObserver


### panoptichain_rpc_gas_limit
The gas limit of the block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## GasUsedObserver


### panoptichain_rpc_gas_used
The gas used in the block (million gas)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## GrafanaObserver


### panoptichain_spn_mpgu_per_second
The gas used (million prover gas units per second)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- fulfiller

## HashDivergenceObserver


### panoptichain_rpc_hash_divergence
The number of blocks that have different hashes across different RPC providers

Metric Type: CounterVec

Variable Labels:
- network
- provider

## HeimdallBlockObserver


### panoptichain_heimdall_height
The block height for Heimdall

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_transactions_per_block
The number of transactions per Heimdall block

Metric Type: HistogramVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_total_transaction_count
The number of total transactions observed for Heimdall

Metric Type: CounterVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_block_proposed
Heimdall blocks proposed by validator

Metric Type: CounterVec

Variable Labels:
- network
- provider
- proposer_address

## HeimdallBlockIntervalObserver


### panoptichain_heimdall_block_interval
The time interval (in seconds) between Heimdall blocks

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## HeimdallBufferedCheckpointObserver


### panoptichain_heimdall_buffered_checkpoint_exists
Whether a buffered checkpoint exists (0 or 1)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_buffered_checkpoint_id
Checkpoint ID of the buffered checkpoint (0 if none)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_buffered_checkpoint_start_block
Start block of the buffered checkpoint (0 if none)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_buffered_checkpoint_end_block
End block of the buffered checkpoint (0 if none)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_time_since_buffered_checkpoint
Seconds since buffered checkpoint was created (0 if none)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## HeimdallCheckpointObserver


### panoptichain_heimdall_checkpoint_start_block
The checkpoint start block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_checkpoint_end_block
The checkpoint end block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_checkpoint_id
The checkpoint id

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_time_since_last_checkpoint
The time since last checkpoint

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## HeimdallMissedBlockProposalObserver


### panoptichain_heimdall_failed_proposal_round
Consensus rounds that failed to produce a block, summed per block

Metric Type: CounterVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_missed_block_proposal
Validators selected as proposer for a round that did not propose

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer_address

## HeimdallMissedCheckpointProposalObserver


### panoptichain_heimdall_missed_checkpoint_proposal
Missed checkpoint proposals

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer_address

## HeimdallMissedVoteObserver


### panoptichain_heimdall_missed_consensus_vote
Missed Heimdall consensus votes

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address
- flag

## HeimdallSignatureCountObserver


### panoptichain_heimdall_signatures
The number of signatures on block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## HeimdallValidatorFeeBalanceObserver


### panoptichain_heimdall_validator_fee_balance
Validator Heimdall fee account balance, in the denomination's base unit (wei for pol)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- signer_address
- denom

### panoptichain_heimdall_validator_fee_balance_swept
Number of validators whose Heimdall fee balance was resolved in the last sweep

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_validator_fee_balance_failed
Number of validators whose Heimdall fee balance could not be resolved in the last sweep

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## HeimdallValidatorSetChangeObserver


### panoptichain_heimdall_validator_set_change
The number of validator set changes (onboarded or unbonded)

Metric Type: CounterVec

Variable Labels:
- network
- provider
- change_type

## MilestoneObserver


### panoptichain_heimdall_milestone_observed
The number of milestones observed

Metric Type: CounterVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_milestone_proposed
Milestones proposed by validator

Metric Type: CounterVec

Variable Labels:
- network
- provider
- proposer

### panoptichain_heimdall_milestone_block_range
The number of blocks in the milestone

Metric Type: HistogramVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_milestone_vote_proposed
Validators who proposed milestone in vote extension

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address

### panoptichain_heimdall_milestone_vote_missed
Validators who didn't propose milestone

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address

### panoptichain_heimdall_milestone_signed_but_missed
Validators who signed consensus but didn't propose milestone

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address

### panoptichain_heimdall_milestone_voting_power
Percentage of voting power that proposed milestone

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## MilestoneLatestObserver


### panoptichain_heimdall_time_since_last_milestone
The time since last milestone

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_milestone_count
The milestone count

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_milestone_start_block
The milestone start block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_milestone_end_block
The milestone end block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## MissedBlockProposalObserver


### panoptichain_rpc_missed_block_proposal
Missed block proposals

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer_address

## RefreshStateTimeObserver


### panoptichain_system_refresh_state_time
The amount of time it took to refresh the state in milliseconds

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## ReorgObserver


### panoptichain_sensor_reorg_depth
The number of blocks that were reorganized

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## RollupManagerObserver


### panoptichain_rpc_zkevm_last_batch_sequenced
The last batch sequenced number

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_time_since_last_sequenced
The time since the last sequenced batch (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_total_sequenced_batches
The total number of sequenced batches

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_zkevm_time_between_sequenced_batches
The time between sequenced batches (in seconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_sequenced_batches_tx_fee
The transaction fee of OnSequencedBatches events (in gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- rollup
- address

### panoptichain_rpc_zkevm_observed_sequenced_batches
The number of sequenced batches observed

Metric Type: CounterVec

Variable Labels:
- network
- provider
- rollup
- address

### panoptichain_rpc_zkevm_last_verified_batch
The last verified batch number

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_time_since_last_verified
The time since the last verified batch (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup
- pessimistic

### panoptichain_rpc_zkevm_total_verified_batches
The total number of verified batches

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_zkevm_time_between_verified_batches
The time between verified batches (in seconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_verified_batches_tx_fee
The transaction fee of verifyBatches and verifyBatchesTrustedAggregator events (in gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- rollup
- address

### panoptichain_rpc_zkevm_observed_verified_batches
The number of verified batches observed

Metric Type: CounterVec

Variable Labels:
- network
- provider
- rollup
- address

### panoptichain_rpc_zkevm_last_force_batch
The last force batch number

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_last_force_batch_sequenced
The last force batch sequenced number

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_rollup_chain_id
The rollup chain ID

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup

### panoptichain_rpc_zkevm_batch_fee
The batch fee (gwei)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_zkevm_reward_per_batch
The reward per batch (gwei)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_zkevm_trusted_sequencer_balance
The trusted sequencer balance (wei)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- rollup
- token

### panoptichain_rpc_zkevm_aggregator_balance
The aggregator balance (wei)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- address
- token

### panoptichain_rpc_zkevm_rollup_count
The number of rollups

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_zkevm_rollup_type_count
The number of rollup types

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## SealedOutOfTurnObserver


### panoptichain_sensor_sealed_out_of_turn
The number of blocks that were sealed out of turn

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer_address

## BlockEventsObserver


### panoptichain_sensor_block_latency
The difference between the block time and the time seen for all blocks by a sensor (in milliseconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

### panoptichain_sensor_block_latency_diff
The difference between the first and last time a block was received by a sensor (in milliseconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

### panoptichain_sensor_first_block_latency
The difference between the block time and the time first seen by a sensor (in milliseconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

### panoptichain_sensor_last_block_latency
The difference between the block time and the time last seen by a sensor (in milliseconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

### panoptichain_sensor_peers
The number of unique block propagators observed by a sensor

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

### panoptichain_sensor_block_events
The number of block events that occurred for a block by a sensor

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

### panoptichain_sensor_connections
The number of sensors a peer propagated a block to

Metric Type: HistogramVec

Variable Labels:
- network
- provider

### panoptichain_sensor_latency_rank
The rank order in which a sensor received a block relative to other sensors

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- sensor

## SensorBlocksObserver


### panoptichain_sensor_forks_per_block_number
The cardinality of forks for a block number

Metric Type: HistogramVec

Variable Labels:
- network
- provider

### panoptichain_sensor_total_blocks
The total number of blocks observed by sensors including bogons

Metric Type: CounterVec

Variable Labels:
- network
- provider

## SensorBogonBlockObserver


### panoptichain_sensor_bogon_block
The total number of bogon blocks observed

Metric Type: CounterVec

Variable Labels:
- network
- provider

## HeimdallSpanObserver


### panoptichain_heimdall_span_id
The span id

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_span_start_block
The span start block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_span_end_block
The span end block

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_span_producer
The span selected producer

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_span_overlaps
The number of overlapping spans

Metric Type: CounterVec

Variable Labels:
- network
- provider

### panoptichain_heimdall_span_overlapped_blocks
The number of overlapped blocks between spans

Metric Type: CounterVec

Variable Labels:
- network
- provider

## ProofRequestObserver


### panoptichain_spn_gas_limit
The gas limit

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- requester
- fulfiller
- program

### panoptichain_spn_gas_used
The gas used

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- requester
- fulfiller
- program

### panoptichain_spn_gas_used_by_fulfiller
The gas used by fulfiller

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- fulfiller

### panoptichain_spn_cycle_limit
The cycle limit

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- requester
- fulfiller
- program

### panoptichain_spn_cycles
The number of cycles

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- requester
- fulfiller
- program

### panoptichain_spn_time_to_fulfilled
The time the proof took to be fulfilled

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- requester
- fulfiller
- program

## RequesterUsageObserver


### panoptichain_spn_gas_reserved
The reserved gas the requester used over the most recent complete hour

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- requester
- tag

### panoptichain_spn_gas_on_demand
The on-demand gas the requester used over the most recent complete hour

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- requester
- tag

### panoptichain_spn_gas_hourly
The total gas (reserved plus on-demand) the requester used over the most recent complete hour

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- requester
- tag

### panoptichain_spn_gas_consumed_total
Cumulative total gas the requester consumed, counting each hourly bucket once, for range totals

Metric Type: CounterVec

Variable Labels:
- network
- provider
- requester
- tag

## SPOLControllerObserver


### panoptichain_rpc_spol_validator_status
sPOLController validator status (0=inactive, 1=active)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

### panoptichain_rpc_spol_validator_deposit_share
sPOLController validator target deposit share percentage

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

### panoptichain_rpc_spol_validator_total_staked
sPOLController validator total staked amount (in ether)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

### panoptichain_rpc_spol_total_validators
Total number of validators in sPOLController

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_active_validators
Number of active validators in sPOLController

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_dpol_balance
Total dPOL balance in sPOLController (in ether)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_spol_balance
Total sPOL token balance in sPOLController (in ether)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_exchange_rate
sPOL to POL exchange rate (POL per 1 sPOL, in ether)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_paused
sPOLController paused state (0=active, 1=paused)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_global_withdraw_nonce
sPOLController global withdrawal nonce counter

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_spol_validator_real_dpol_balance
Real dPOL balance (balanceOf on ValidatorShare) in ether

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

### panoptichain_rpc_spol_validator_delegation_locked
Validator delegation locked state (0=enabled, 1=locked)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

### panoptichain_rpc_spol_validator_liquid_rewards
Validator pending liquid rewards (in ether)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

### panoptichain_rpc_spol_validator_share_exchange_rate
ValidatorShare exchange rate (raw value, typically ~1e29 for healthy validators)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- validator_id
- validator_address

## StakeManagerObserver


### panoptichain_rpc_total_staked
Total amount staked in the stake manager contract (in ether)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_validator_set_size
The current number of active validators

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## StakingEventsObserver


### panoptichain_rpc_stake_for_pol
The total number of Staked events observed

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address

### panoptichain_rpc_unstake_pol
The total number of UnstakeInit events observed

Metric Type: CounterVec

Variable Labels:
- network
- provider
- validator_id
- signer_address

## StateSyncObserver


### panoptichain_rpc_state_sync_id
the latest observed state sync id

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- finalized

### panoptichain_rpc_time_since_last_state_sync
The elapsed time since the last state sync

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- finalized

## StolenBlockObserver


### panoptichain_sensor_stolen_block
The number blocks stolen from a validator

Metric Type: CounterVec

Variable Labels:
- network
- provider
- signer_address

## SystemObserver


### panoptichain_system_uptime
How long the system has been running in seconds

Metric Type: gauge

## TimeToFinalizedObserver


### panoptichain_rpc_time_to_finalized
The time difference between the latest block and the last finalized block (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## TimeToMineObserver


### panoptichain_rpc_time_to_mine
Time it takes for sent transaction to be included in a block (in seconds)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- gas_price_factor

### panoptichain_rpc_time_to_mine_gas_price
The gas price for the time to mine transactions (in gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider
- gas_price_factor

## TransactionCostObserver


### panoptichain_rpc_transaction_cost
The transaction cost (ether)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TransactionCountObserver


### panoptichain_rpc_transactions_per_block
The number of transactions per block

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TransactionGasFeeCapObserver


### panoptichain_rpc_transaction_gas_fee_cap
The transaction gas fee cap (gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TransactionGasLimitObserver


### panoptichain_rpc_transaction_gas_limit
The transaction gas limit (gas)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TransactionGasPriceObserver


### panoptichain_rpc_transaction_gas_price
The transaction gas price (gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TransactionGasTipCapObserver


### panoptichain_rpc_transaction_gas_tip_cap
The transaction gas tip cap (gwei)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TransactionPoolObserver


### panoptichain_rpc_pending_tx_size
Number of pending transactions

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_queued_tx_size
Number of queued transactions

Metric Type: GaugeVec

Variable Labels:
- network
- provider

## TransactionValueObserver


### panoptichain_rpc_transaction_value
The value of the transactions (ether)

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## TrustedBatchObserver


### panoptichain_rpc_transactions_per_batch
The number of transactions per trusted batch

Metric Type: HistogramVec

Variable Labels:
- network
- provider

## UnclesObserver


### panoptichain_rpc_uncles
The number of uncles for the block

Metric Type: CounterVec

Variable Labels:
- network
- provider

## ValidatorWalletBalanceObserver


### panoptichain_rpc_validator_wallet_balance
PoS validator wallet balance

Metric Type: GaugeVec

Variable Labels:
- network
- provider
- signer_address

## ZkEVMBatchObserver


### panoptichain_rpc_trusted_batch
zkEVM trusted batch number

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_virtual_batch
zkEVM virtual batch number

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_verified_batch
zkEVM verified batch number

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_time_since_last_trusted_batch
time since last zkEVM trusted batch (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_time_since_last_virtual_batch
time since last zkEVM virtual batch (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider

### panoptichain_rpc_time_since_last_verified_batch
time since last zkEVM verified batch (in seconds)

Metric Type: GaugeVec

Variable Labels:
- network
- provider
