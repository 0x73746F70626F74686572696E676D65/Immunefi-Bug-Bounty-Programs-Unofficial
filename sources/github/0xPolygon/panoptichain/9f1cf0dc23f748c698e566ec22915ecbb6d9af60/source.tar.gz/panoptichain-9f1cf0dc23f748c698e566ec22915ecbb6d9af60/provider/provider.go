// Package provider defines the basic provider subsystems for
// observing our networks of interest
package provider

import (
	"context"
	"time"

	"github.com/rs/zerolog"

	"github.com/0xPolygon/panoptichain/config"
	"github.com/0xPolygon/panoptichain/log"
	"github.com/0xPolygon/panoptichain/network"
	"github.com/0xPolygon/panoptichain/util"
)

// Provider must be implemented by any system that's monitoring the
// state of a network.
type Provider interface {
	// Refresh state is responsible for updating the provider state. All state
	// updates should happen in this method of the provider. There should not be
	// event publishing done is this method. The Start function in runner.go will
	// call RefreshState of every provider before PublishEvents.
	RefreshState(context.Context) error

	// PublishEvents should given the current state of the provider, publish those
	// messages to the corresponding event bus. PublishEvents should not modify
	// state at all. The Start function in runner.go will call PublishEvents of
	// every provider after RefreshState.
	PublishEvents(context.Context) error

	// PollingInterval returns how often the provider should refresh it state and
	// publish events in seconds.
	PollingInterval() time.Duration

	// Logger returns the provider's contextual logger (tagged with network and
	// provider label) so cross-cutting log lines such as the cycle-overrun
	// warning are attributable to a specific provider.
	Logger() zerolog.Logger
}

// RunCycle runs a single bounded refresh/publish cycle for a provider and blocks
// until the next scheduled tick. The cycle is bounded by util.RefreshTimeout so a
// hung upstream can't pin the caller. BlockFor aligns to the interval grid, so a
// cycle that overruns its interval falls behind schedule (cycles run closer to
// back-to-back); the overrun warning surfaces that.
func RunCycle(ctx context.Context, p Provider) {
	logger := p.Logger()
	interval := p.PollingInterval()
	start := time.Now()

	cycleCtx, cancel := context.WithTimeout(ctx, util.RefreshTimeout(interval))
	if err := p.RefreshState(cycleCtx); err != nil {
		logger.Error().Err(err).Send()
	}
	cancel()

	if err := p.PublishEvents(ctx); err != nil {
		logger.Error().Err(err).Send()
	}

	if elapsed := time.Since(start); elapsed >= interval {
		logger.Warn().
			Dur("elapsed", elapsed).
			Dur("interval", interval).
			Msg("Provider refresh cycle overran its polling interval")
	}

	util.BlockFor(ctx, interval)
}

func timer(duration *time.Duration) func() {
	start := time.Now()
	return func() {
		*duration = time.Since(start)
	}
}

func NewLogger(n network.Network, provider string) zerolog.Logger {
	network := ""
	if n != nil {
		network = n.GetName()
	}

	return log.With().
		Str("network", network).
		Str("provider", provider).
		Logger()
}

func GetInterval(interval *time.Duration) time.Duration {
	if interval != nil {
		return *interval
	}

	return *config.Config().Runner.Interval
}
