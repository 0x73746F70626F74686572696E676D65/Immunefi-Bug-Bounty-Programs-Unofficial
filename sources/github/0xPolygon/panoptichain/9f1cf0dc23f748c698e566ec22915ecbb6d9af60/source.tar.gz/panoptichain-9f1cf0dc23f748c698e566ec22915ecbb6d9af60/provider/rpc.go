package provider

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"math/big"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	ethabi "github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/rpc"
	"github.com/rs/zerolog"

	"github.com/0xPolygon/panoptichain/api"
	"github.com/0xPolygon/panoptichain/blockbuffer"
	"github.com/0xPolygon/panoptichain/config"
	"github.com/0xPolygon/panoptichain/contracts"
	"github.com/0xPolygon/panoptichain/log"
	"github.com/0xPolygon/panoptichain/network"
	"github.com/0xPolygon/panoptichain/observer"
	"github.com/0xPolygon/panoptichain/observer/topics"
	"github.com/0xPolygon/panoptichain/util"
)

// RPCProvider is the generic struct for all EVM style JSON RPC services.
type RPCProvider struct {
	url      string
	network  network.Network
	label    string
	bus      *observer.EventBus
	interval time.Duration
	logger   zerolog.Logger
	// blockNumber is written only from this provider's own goroutine; blockNumberMu
	// guards it for cross-goroutine reads via BlockNumber() (used by meta-providers
	// such as the Heimdall and hash divergence providers).
	blockNumber      uint64
	blockNumberMu    sync.RWMutex
	prevBlockNumber  uint64
	finalizedHeight  uint64
	blockBuffer      *blockbuffer.BlockBuffer
	txPool           *observer.TransactionPool
	refreshStateTime *time.Duration
	contracts        config.Contracts
	timeToMine       *config.TimeToMine
	accounts         []config.Account
	accountBalances  observer.AccountBalances
	accountTxs       observer.AccountTxs
	// trackedAccounts is the subset of accounts whose balances are fetched,
	// resolved once from ExcludeBalanceTags / TrackBalances at construction.
	trackedAccounts         []config.Account
	timeToFinalized         *uint64
	blockLookBack           uint64
	accountBalanceBatchSize int
	accountBalanceTimeout   time.Duration
	hasTxPool               bool
	fetchValidatorBalances  bool
	fetchMissedProposals    bool

	// PoS
	stateSync            map[bool]*observer.StateSync
	checkpointSignatures map[bool]*observer.CheckpointSignatures
	// prevCheckpointID is the header block ID of the most recent checkpoint
	// whose signatures were counted. Checkpoints are republished on every poll
	// cycle, so this lets us mark republishes as seen and fire the counters
	// once per checkpoint.
	prevCheckpointID    *big.Int
	validatorBalances   observer.ValidatorWalletBalances
	missedBlockProposal observer.MissedBlockProposal
	stakeManager        *observer.StakeManager
	sPOLController      *observer.SPOLController
	stakingEvents       *observer.StakingEvents
	stakingInfoAddress  *common.Address

	// zkEVM
	batches        observer.ZkEVMBatches
	trustedBatches []*util.Batch

	globalExitRoot   *observer.ExitRoot
	mainnetExitRoot  *observer.ExitRoot
	rollupExitRoot   *observer.ExitRoot
	rollupExitRootL2 *observer.ExitRoot

	bridgeEvents []*contracts.PolygonZkEVMBridgeV2BridgeEvent
	claimEvents  []*contracts.PolygonZkEVMBridgeV2ClaimEvent

	bridgeEventTimes observer.BridgeEventTimes
	claimEventTimes  observer.ClaimEventTimes

	depositCount            *big.Int
	lastUpdatedDepositCount *uint32

	rollupManager       *observer.RollupManager
	trustedSequencers   map[uint32]*RPCProvider
	trustedSequencerURL chan string

	// These contract addresses will be derived from the PolygonRollupManager
	// contract.
	rollupContracts       map[uint32]common.Address
	polTokenAddress       *common.Address
	globalExitRootAddress *common.Address
}

// NewRPCProvider creates a new RPC provider.
func NewRPCProvider(n network.Network, eb *observer.EventBus, cfg config.RPC) *RPCProvider {
	// Look back this number of blocks when filtering event logs.
	blb := config.DefaultBlockLookBack
	if cfg.BlockLookBack != nil {
		blb = *cfg.BlockLookBack
	}

	// Fall back to the default for an unset, zero, or oversized value; zero would
	// spin the batch loops forever and a value past MaxInt would wrap negative
	// when used as a slice bound. (Validation catches this for top-level RPCs but
	// not for rollup overrides, which also flow through here.)
	balanceBatchSize := int(config.DefaultAccountBalanceBatchSize)
	if n := cfg.AccountBalanceBatchSize; n != nil && *n > 0 && *n <= math.MaxInt32 {
		balanceBatchSize = int(*n)
	}

	balanceTimeout := config.DefaultAccountBalanceTimeout
	if t := cfg.AccountBalanceTimeout; t != nil && *t > 0 {
		balanceTimeout = *t
	}

	fetchValidatorBalances := cfg.ValidatorBalances == nil || *cfg.ValidatorBalances
	fetchMissedProposals := cfg.MissedProposals == nil || *cfg.MissedProposals

	logger := NewLogger(n, cfg.Label)
	trackedAccounts := resolveTrackedAccounts(logger, cfg.Accounts, cfg.ExcludeBalanceTags)

	return &RPCProvider{
		url:                     cfg.URL,
		network:                 n,
		label:                   cfg.Label,
		bus:                     eb,
		blockBuffer:             blockbuffer.NewBlockBuffer(128),
		interval:                GetInterval(cfg.Interval),
		logger:                  logger,
		refreshStateTime:        new(time.Duration),
		contracts:               cfg.Contracts,
		timeToMine:              cfg.TimeToMine,
		accounts:                cfg.Accounts,
		accountBalances:         make(observer.AccountBalances, 0),
		accountTxs:              make(observer.AccountTxs, 0),
		stateSync:               make(map[bool]*observer.StateSync),
		checkpointSignatures:    make(map[bool]*observer.CheckpointSignatures),
		validatorBalances:       make(observer.ValidatorWalletBalances),
		missedBlockProposal:     make(observer.MissedBlockProposal),
		bridgeEventTimes:        make(observer.BridgeEventTimes),
		claimEventTimes:         make(observer.ClaimEventTimes),
		trustedSequencers:       make(map[uint32]*RPCProvider),
		trustedSequencerURL:     make(chan string),
		rollupContracts:         make(map[uint32]common.Address),
		trackedAccounts:         trackedAccounts,
		blockLookBack:           blb,
		accountBalanceBatchSize: balanceBatchSize,
		accountBalanceTimeout:   balanceTimeout,
		hasTxPool:               cfg.TxPool,
		fetchValidatorBalances:  fetchValidatorBalances,
		fetchMissedProposals:    fetchMissedProposals,
	}
}

// RefreshState is going to get the current head block and request all
// of the blocks between the current head and the last head. All of
// those blocks will be pushed into the buffer.
func (r *RPCProvider) RefreshState(ctx context.Context) error {
	defer timer(r.refreshStateTime)()

	c, err := ethclient.DialContext(ctx, r.url)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to create the client")
		return err
	}

	r.accountBalances = make(observer.AccountBalances, 0)
	r.accountTxs = make(observer.AccountTxs, 0)

	r.refreshBlockBuffer(ctx, c)
	r.refreshStateSync(ctx, c, true)
	r.refreshStateSync(ctx, c, false)
	r.refreshCheckpoint(ctx, c)

	if r.network.IsPolygonPoS() {
		r.refreshValidatorBalances(ctx, c)
		r.refreshMissedBlockProposal(ctx, c)
	}

	r.refreshStakeManager(ctx, c)
	r.refreshSPOLController(ctx, c)
	r.refreshStakingEvents(ctx, c)

	if r.hasTxPool {
		r.refreshTxPoolStatus(ctx, c)
	}

	r.refreshTimeToMine(ctx, c)
	r.refreshAccountBalances(ctx, c)
	r.refreshAccountTxs(ctx, c)

	if r.network.IsPolygonZkEVM() {
		r.refreshBatches(ctx, c)
	}

	r.refreshRollupManager(ctx, c)
	r.refreshExitRoots(ctx, c)
	r.refreshExitRootsL2(ctx, c)
	r.refreshBridge(ctx, c)

	return nil
}

func (r *RPCProvider) PublishEvents(ctx context.Context) error {
	for i := r.prevBlockNumber + 1; i <= r.blockNumber && r.prevBlockNumber != 0; i++ {
		b, err := r.blockBuffer.GetBlock(i)
		if err != nil {
			continue
		}
		block, ok := b.(*types.Block)
		if !ok {
			continue
		}

		m := observer.NewMessage(r.network, r.label, block)
		r.bus.Publish(ctx, topics.NewEVMBlock, m)

		pb, err := r.blockBuffer.GetBlock(b.Number().Uint64() - 1)
		if err != nil {
			continue
		}
		prev, ok := pb.(*types.Block)
		if !ok {
			continue
		}

		interval := observer.NewMessage(r.network, r.label, block.Time()-prev.Time())
		r.bus.Publish(ctx, topics.BlockInterval, interval)
	}

	if len(r.missedBlockProposal) > 0 {
		missedBlockProposal := observer.NewMessage(r.network, r.label, r.missedBlockProposal)
		r.bus.Publish(ctx, topics.BorMissedBlockProposal, missedBlockProposal)
	}

	for _, stateSync := range r.stateSync {
		r.bus.Publish(ctx, topics.BorStateSync, observer.NewMessage(r.network, r.label, stateSync))
	}

	for _, checkpointSignatures := range r.checkpointSignatures {
		m := observer.NewMessage(r.network, r.label, checkpointSignatures)
		r.bus.Publish(ctx, topics.CheckpointSignatures, m)
	}

	if len(r.validatorBalances) > 0 {
		validatorWalletBalance := observer.NewMessage(r.network, r.label, r.validatorBalances)
		r.bus.Publish(ctx, topics.ValidatorWallet, validatorWalletBalance)
	}

	if r.txPool != nil {
		txPool := observer.NewMessage(r.network, r.label, r.txPool)
		r.bus.Publish(ctx, topics.TransactionPool, txPool)
	}

	if r.batches.TrustedBatch.Number > 0 || r.batches.VirtualBatch.Number > 0 || r.batches.VerifiedBatch.Number > 0 {
		r.bus.Publish(ctx, topics.ZkEVMBatches, observer.NewMessage(r.network, r.label, r.batches))
	}

	if r.globalExitRoot != nil || r.mainnetExitRoot != nil || r.rollupExitRoot != nil {
		er := &observer.ExitRoots{
			GlobalExitRoot:  r.globalExitRoot,
			MainnetExitRoot: r.mainnetExitRoot,
			RollupExitRoot:  r.rollupExitRoot,
		}
		r.bus.Publish(ctx, topics.ExitRoots, observer.NewMessage(r.network, r.label, er))
	}

	if r.rollupExitRootL2 != nil {
		er := &observer.ExitRoots{
			RollupExitRoot: r.rollupExitRootL2,
		}
		r.bus.Publish(ctx, topics.ExitRoots, observer.NewMessage(r.network, r.label, er))
	}

	if r.depositCount != nil || r.lastUpdatedDepositCount != nil {
		m := observer.NewMessage(r.network, r.label, &observer.DepositCounts{
			DepositCount:            r.depositCount,
			LastUpdatedDepositCount: r.lastUpdatedDepositCount,
		})
		r.bus.Publish(ctx, topics.DepositCounts, m)
	}

	for _, bridgeEvent := range r.bridgeEvents {
		r.bus.Publish(ctx, topics.BridgeEvent, observer.NewMessage(r.network, r.label, bridgeEvent))
	}

	for _, claimEvent := range r.claimEvents {
		r.bus.Publish(ctx, topics.ClaimEvent, observer.NewMessage(r.network, r.label, claimEvent))
	}

	if len(r.bridgeEventTimes) > 0 {
		m := observer.NewMessage(r.network, r.label, r.bridgeEventTimes)
		r.bus.Publish(ctx, topics.BridgeEventTimes, m)
	}

	if len(r.claimEventTimes) > 0 {
		m := observer.NewMessage(r.network, r.label, r.claimEventTimes)
		r.bus.Publish(ctx, topics.ClaimEventTimes, m)
	}

	if r.rollupManager != nil {
		m := observer.NewMessage(r.network, r.label, r.rollupManager)
		r.bus.Publish(ctx, topics.RollupManager, m)
	}

	if len(r.accountBalances) > 0 {
		m := observer.NewMessage(r.network, r.label, r.accountBalances)
		r.bus.Publish(ctx, topics.AccountBalances, m)
	}

	if len(r.accountTxs) > 0 {
		m := observer.NewMessage(r.network, r.label, r.accountTxs)
		r.bus.Publish(ctx, topics.AccountTxs, m)
	}

	for _, batch := range r.trustedBatches {
		m := observer.NewMessage(r.network, r.label, batch)
		r.bus.Publish(ctx, topics.TrustedBatch, m)
	}

	if r.timeToFinalized != nil {
		m := observer.NewMessage(r.network, r.label, r.timeToFinalized)
		r.bus.Publish(ctx, topics.TimeToFinalized, m)
	}

	if r.finalizedHeight > 0 {
		m := observer.NewMessage(r.network, r.label, r.finalizedHeight)
		r.bus.Publish(ctx, topics.FinalizedHeight, m)
	}

	if r.stakeManager != nil {
		m := observer.NewMessage(r.network, r.label, r.stakeManager)
		r.bus.Publish(ctx, topics.StakeManager, m)
	}

	if r.sPOLController != nil {
		m := observer.NewMessage(r.network, r.label, r.sPOLController)
		r.bus.Publish(ctx, topics.SPOLController, m)
	}

	if r.stakingEvents != nil {
		m := observer.NewMessage(r.network, r.label, r.stakingEvents)
		r.bus.Publish(ctx, topics.StakingEvents, m)
	}

	r.bus.Publish(ctx, topics.RefreshStateTime, observer.NewMessage(r.network, r.label, r.refreshStateTime))

	return nil
}

func (r *RPCProvider) Logger() zerolog.Logger {
	return r.logger
}

func (r *RPCProvider) PollingInterval() time.Duration {
	return r.interval
}

// BlockNumber returns the latest block height seen by this provider. It is safe
// to call from other goroutines (e.g. the Heimdall and hash divergence
// meta-providers, which run on their own goroutines).
func (r *RPCProvider) BlockNumber() uint64 {
	r.blockNumberMu.RLock()
	defer r.blockNumberMu.RUnlock()
	return r.blockNumber
}

// rpcProvidersByNetwork groups RPC providers by their network name so
// meta-providers can look up the providers for a given network.
func rpcProvidersByNetwork(rpcProviders []*RPCProvider) map[string][]*RPCProvider {
	byNetwork := make(map[string][]*RPCProvider)
	for _, r := range rpcProviders {
		name := r.network.GetName()
		byNetwork[name] = append(byNetwork[name], r)
	}
	return byNetwork
}

func (r *RPCProvider) refreshBlockBuffer(ctx context.Context, c *ethclient.Client) (err error) {
	r.prevBlockNumber = r.blockNumber
	bn, err := c.BlockNumber(ctx)
	if err != nil {
		// Keep the last-good height rather than resetting to 0: other providers
		// read it via BlockNumber(), and a transient error shouldn't make the
		// height look unknown.
		r.logger.Error().Err(err).Msg("Failed to get block number")
		return err
	}
	r.blockNumberMu.Lock()
	r.blockNumber = bn
	r.blockNumberMu.Unlock()

	r.logger.Info().Uint64("block_number", r.blockNumber).Msg("Refreshing block state")

	if r.prevBlockNumber != 0 && r.prevBlockNumber != r.blockNumber {
		r.fillRange(ctx, r.prevBlockNumber, c)
	}

	finalized, err := c.HeaderByNumber(ctx, big.NewInt(int64(rpc.FinalizedBlockNumber)))
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get finalized block header")
		return err
	}
	r.finalizedHeight = finalized.Number.Uint64()

	latest, err := c.HeaderByNumber(ctx, big.NewInt(int64(r.blockNumber)))
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get latest block header")
		return err
	}

	diff := latest.Time - finalized.Time
	r.timeToFinalized = &diff

	return nil
}

func (r *RPCProvider) getFilterOpts() *bind.FilterOpts {
	opts := bind.FilterOpts{End: &r.blockNumber}

	if r.prevBlockNumber > 0 {
		opts.Start = r.prevBlockNumber
	} else if r.blockLookBack < r.blockNumber {
		opts.Start = r.blockNumber - r.blockLookBack
	}

	log.Trace().
		Any("opts", opts).
		Any("block_number", r.blockNumber).
		Any("prev_block_number", r.prevBlockNumber).
		Any("block_look_back", r.blockLookBack).
		Msg("Getting filter options")

	return &opts
}

// cast call --rpc-url https://eth.llamarpc.com 0x28e4F3a7f651294B9564800b2D01f35189A5bFbE 'function counter() view returns(uint256)'
// cast call --rpc-url https://polygon-rpc.com 0x0000000000000000000000000000000000001001 'function lastStateId() view returns(uint256)'
func (r *RPCProvider) refreshStateSync(ctx context.Context, c *ethclient.Client, finalized bool) error {
	var counter, blockNumber *big.Int
	if finalized {
		blockNumber = big.NewInt(rpc.FinalizedBlockNumber.Int64())
	}

	co := bind.CallOpts{
		Context:     ctx,
		BlockNumber: blockNumber,
	}

	if r.contracts.StateSyncSenderAddress != nil {
		address := common.HexToAddress(*r.contracts.StateSyncSenderAddress)
		ss, err := contracts.NewStateSender(address, c)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to bind state sender contract")
			return err
		}

		counter, err = ss.Counter(&co)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get state sender counter")
			return err
		}
	} else if r.contracts.StateSyncReceiverAddress != nil {
		address := common.HexToAddress(*r.contracts.StateSyncReceiverAddress)
		sr, err := contracts.NewStateReceiver(address, c)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to bind state receiver contract")
			return err
		}

		counter, err = sr.LastStateId(&co)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get state receiver counter")
			return err
		}
	} else {
		return nil
	}

	stateSync := &observer.StateSync{
		ID:        counter.Uint64(),
		Time:      time.Now(),
		Finalized: finalized,
	}

	if r.stateSync[finalized] == nil || r.stateSync[finalized].ID != stateSync.ID {
		r.stateSync[finalized] = stateSync
	}

	return nil
}

func (r *RPCProvider) refreshStakeManager(ctx context.Context, c *ethclient.Client) error {
	if r.contracts.StakeManagerAddress == nil {
		return nil
	}

	address := common.HexToAddress(*r.contracts.StakeManagerAddress)
	contract, err := contracts.NewStakeManager(address, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind stake manager contract")
		return err
	}

	co := bind.CallOpts{Context: ctx}

	stakingInfoAddress, err := contract.Logger(&co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get staking info address from stake manager")
	} else {
		r.stakingInfoAddress = &stakingInfoAddress
	}

	totalStaked, err := contract.CurrentValidatorSetTotalStake(&co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get current validator set total stake")
		return err
	}

	validatorSetSize, err := contract.CurrentValidatorSetSize(&co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get current validator set size")
		return err
	}

	r.stakeManager = &observer.StakeManager{
		TotalStaked:      totalStaked,
		ValidatorSetSize: validatorSetSize,
	}

	return nil
}

func (r *RPCProvider) refreshStakingEvents(ctx context.Context, c *ethclient.Client) error {
	if r.stakingInfoAddress == nil {
		return nil
	}

	r.stakingEvents = nil

	stakingInfo, err := contracts.NewStakingInfo(*r.stakingInfoAddress, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind staking info contract")
		return err
	}

	opts := r.getFilterOpts()

	stakedEvents := make([]*contracts.StakingInfoStaked, 0)
	stakedIter, err := stakingInfo.FilterStaked(opts, nil, nil, nil)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter Staked events")
	} else {
		for stakedIter.Next() && stakedIter.Event != nil {
			stakedEvents = append(stakedEvents, stakedIter.Event)
		}
	}

	unstakeInitEvents := make([]*contracts.StakingInfoUnstakeInit, 0)
	unstakeInitIter, err := stakingInfo.FilterUnstakeInit(opts, nil, nil, nil)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter UnstakeInit events")
	} else {
		for unstakeInitIter.Next() && unstakeInitIter.Event != nil {
			unstakeInitEvents = append(unstakeInitEvents, unstakeInitIter.Event)
		}
	}

	if len(stakedEvents) > 0 || len(unstakeInitEvents) > 0 {
		r.stakingEvents = &observer.StakingEvents{
			StakedEvents:      stakedEvents,
			UnstakeInitEvents: unstakeInitEvents,
		}
	}

	return nil
}

func (r *RPCProvider) refreshSPOLController(ctx context.Context, c *ethclient.Client) error {
	if r.contracts.SPOLControllerAddress == nil {
		return nil
	}

	address := common.HexToAddress(*r.contracts.SPOLControllerAddress)
	contract, err := contracts.NewSPOLController(address, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind sPOLController contract")
		return err
	}

	callOpts := bind.CallOpts{Context: ctx}
	validators := make([]observer.SPOLValidator, 0)
	activeCount := 0
	controllerAddr := address // SPOLController address for balanceOf queries
	const activeStatus = 1

	// Iterate through validator list until we get an error (end of list)
	for index := 0; ; index++ {
		validatorID, err := contract.ValidatorList(&callOpts, big.NewInt(int64(index)))
		if err != nil {
			break
		}

		validatorInfo, err := contract.Validators(&callOpts, validatorID)
		if err != nil {
			r.logger.Warn().Err(err).Uint16("validator_id", validatorID).Msg("Failed to get validator info")
			continue
		}

		validator := observer.SPOLValidator{
			ID:           validatorID,
			Status:       validatorInfo.Status,
			DepositShare: validatorInfo.DepositShare,
			Address:      validatorInfo.ValidatorContract,
			TotalStaked:  validatorInfo.TotalStaked,
		}

		validatorShare, err := contracts.NewValidatorShare(validatorInfo.ValidatorContract, c)
		if err != nil {
			r.logger.Warn().
				Err(err).
				Uint16("validator_id", validatorID).
				Msg("Failed to bind ValidatorShare contract")
			validators = append(validators, validator)
			if validatorInfo.Status == activeStatus {
				activeCount++
			}
			continue
		}

		balance, err := validatorShare.BalanceOf(&callOpts, controllerAddr)
		if err != nil {
			r.logger.Warn().
				Err(err).
				Uint16("validator_id", validatorID).
				Msg("Failed to get ValidatorShare balanceOf")
		} else {
			validator.RealDPOLBalance = balance
		}

		delegation, err := validatorShare.Delegation(&callOpts)
		if err != nil {
			r.logger.Warn().
				Err(err).
				Uint16("validator_id", validatorID).
				Msg("Failed to get ValidatorShare delegation")
		} else {
			validator.DelegationLocked = !delegation
		}

		rewards, err := validatorShare.GetLiquidRewards(&callOpts, controllerAddr)
		if err != nil {
			r.logger.Warn().
				Err(err).
				Uint16("validator_id", validatorID).
				Msg("Failed to get ValidatorShare liquidRewards")
		} else {
			validator.LiquidRewards = rewards
		}

		rate, err := validatorShare.ExchangeRate(&callOpts)
		if err != nil {
			r.logger.Warn().
				Err(err).
				Uint16("validator_id", validatorID).
				Msg("Failed to get ValidatorShare exchangeRate")
		} else {
			validator.ShareExchangeRate = rate
		}

		validators = append(validators, validator)
		if validatorInfo.Status == activeStatus {
			activeCount++
		}
	}

	r.sPOLController = &observer.SPOLController{
		Validators:       validators,
		TotalValidators:  len(validators),
		ActiveValidators: activeCount,
	}

	dPOL, err := contract.TotaldPOLBalance(&callOpts)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get totaldPOLBalance")
	} else {
		r.sPOLController.DPOL = dPOL
	}

	sPOL, err := contract.TotalsPOLBalance(&callOpts)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get totalsPOLBalance")
	} else {
		r.sPOLController.SPOL = sPOL
	}

	onesPOL := new(big.Int).Exp(big.NewInt(10), big.NewInt(18), nil)
	exchangeRate, err := contract.ConvertSPOLtoPOL(&callOpts, onesPOL)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get sPOL exchange rate")
	} else {
		r.sPOLController.ExchangeRate = exchangeRate
	}

	paused, err := contract.Paused(&callOpts)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get paused state")
	} else {
		r.sPOLController.Paused = paused
	}

	withdrawNonce, err := contract.GlobalWithdrawNonce(&callOpts)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get global withdraw nonce")
	} else {
		r.sPOLController.WithdrawNonce = withdrawNonce
	}

	return nil
}

func (r *RPCProvider) refreshCheckpoint(ctx context.Context, c *ethclient.Client) {
	if r.contracts.CheckpointAddress == nil {
		return
	}

	address := common.HexToAddress(*r.contracts.CheckpointAddress)
	contract, err := contracts.NewRootChain(address, c)
	if contract == nil || err != nil {
		r.logger.Warn().Err(err).Msg("Failed to bind root chain contract")
		return
	}

	iter, err := contract.FilterNewHeaderBlock(r.getFilterOpts(), nil, nil, nil)
	if iter == nil || err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter NewHeaderBlock events")
		return
	}

	// Get the last NewHeaderBlock event.
	var event *contracts.RootChainNewHeaderBlock
	for iter.Next() && iter.Event != nil {
		event = iter.Event
	}

	// A new checkpoint is not always present: between checkpoints the scan window
	// contains no event, and the same checkpoint can be re-found before the next
	// one arrives. In both cases there is nothing new to record, so skip the
	// expensive block and transaction lookups below.
	if r.seenCheckpoint(event) {
		if event != nil {
			r.refreshFinalizedCheckpoint(ctx, c)
		}
		return
	}

	// Grab that block so that we know when the transaction was mined.
	block, err := c.BlockByHash(ctx, event.Raw.BlockHash)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get block by hash")
		return
	}

	r.logger.Trace().Any("event", event).Str("network", r.network.GetName()).Msg("Latest NewHeaderBlock event")
	tx, _, err := c.TransactionByHash(ctx, event.Raw.TxHash)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not find submitCheckpoint transaction")
		return
	}

	abi, err := contracts.RootChainMetaData.GetAbi()
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get root chain ABI")
		return
	}

	method, err := abi.MethodById(tx.Data()[:4])
	if err != nil {
		r.logger.Error().Err(err).Msg("Contract method not found")
		return
	}

	inputs := make(map[string]any)
	if err := method.Inputs.UnpackIntoMap(inputs, tx.Data()[4:]); err != nil {
		r.logger.Error().Err(err).Msg("Failed to unpack input params")
		return
	}

	data := inputs["data"].([]byte)
	sigs := inputs["sigs"].([][3]*big.Int)
	vote := crypto.Keccak256(append([]byte{1}, data...))
	signers := make([]common.Address, 0, len(sigs))

	for _, sig := range sigs {
		R := padLeft(sig[0].Bytes(), 32)
		s := padLeft(sig[1].Bytes(), 32)
		v := padLeft(new(big.Int).Sub(sig[2], big.NewInt(27)).Bytes(), 1)

		signature := bytes.Join([][]byte{R, s, v}, nil)

		key, err := crypto.SigToPub(vote, signature)
		if err != nil {
			r.logger.Warn().Err(err).Msg("Failed to get public key from signature")
			continue
		}

		address := crypto.PubkeyToAddress(*key)
		signers = append(signers, address)
	}

	r.refreshFinalizedCheckpoint(ctx, c)

	// This is a checkpoint we have not counted before (seenCheckpoint returned
	// false above), so record its ID and store it unseen for the observer to
	// count.
	finalized := false
	r.prevCheckpointID = new(big.Int).Set(event.HeaderBlockId)
	r.checkpointSignatures[finalized] = &observer.CheckpointSignatures{
		Event:     event,
		Block:     block,
		Signers:   signers,
		Seen:      false,
		Finalized: finalized,
	}
}

// seenCheckpoint reports whether the latest observed checkpoint has already been
// counted. event is the latest NewHeaderBlock event in the scan window, or nil
// if none was found. A checkpoint is new when an event is present whose header
// block ID differs from the last one we recorded; in that case the caller must
// fetch its signatures and store it.
//
// Checkpoints are republished on every poll cycle, so when the checkpoint has
// already been counted — no new event, or the same header block ID — this marks
// the stored entry seen so the observer does not re-count its signatures. The
// entry is replaced with a fresh copy rather than mutated because the previous
// pointer may still be in flight in an observer goroutine.
func (r *RPCProvider) seenCheckpoint(event *contracts.RootChainNewHeaderBlock) bool {
	if event != nil && (r.prevCheckpointID == nil || event.HeaderBlockId.Cmp(r.prevCheckpointID) != 0) {
		return false
	}

	if prev := r.checkpointSignatures[false]; prev != nil && !prev.Seen {
		cp := *prev
		cp.Seen = true
		r.checkpointSignatures[false] = &cp
	}

	return true
}

func (r *RPCProvider) refreshFinalizedCheckpoint(ctx context.Context, c *ethclient.Client) {
	finalized := true
	latest := r.checkpointSignatures[!finalized]
	if latest == nil {
		return
	}

	block, err := c.BlockByNumber(ctx, big.NewInt(rpc.FinalizedBlockNumber.Int64()))
	if err != nil {
		log.Error().Err(err).Msg("Failed to get block header by number")
		return
	}

	// The block with the checkpoint transaction hasn't been finalized yet.
	if block.Number().Cmp(latest.Block.Number()) > 0 {
		return
	}

	r.checkpointSignatures[finalized] = &observer.CheckpointSignatures{
		Event:     latest.Event,
		Block:     block,
		Signers:   latest.Signers,
		Seen:      latest.Seen,
		Finalized: finalized,
	}
}

// fillRange pulls all of the blocks between the start and the current head.
func (r *RPCProvider) fillRange(ctx context.Context, start uint64, c *ethclient.Client) {
	r.logger.Debug().
		Uint64("start_block", start).
		Uint64("end_block", r.blockNumber).
		Msg("Filling block range")

	for i := start + 1; i <= r.blockNumber; i++ {
		num := new(big.Int).SetUint64(i)
		block, err := c.BlockByNumber(ctx, num)

		// Retry fetching the block if it's an unrecognized transaction.
		if errors.Is(err, types.ErrTxTypeNotSupported) {
			block, err = util.BlockByNumber(ctx, num, c)
		}

		if err != nil {
			r.logger.Warn().Err(err).Uint64("block_number", i).Msg("Failed to get block")
			break
		}

		r.blockBuffer.PutBlock(block)
	}
}

func padLeft(data []byte, size int) []byte {
	if len(data) < size {
		n := size - len(data)
		padded := make([]byte, n)

		return append(padded, data...)
	}

	return data[len(data)-size:]
}

func (r *RPCProvider) refreshValidatorBalances(ctx context.Context, c *ethclient.Client) (err error) {
	if !r.fetchValidatorBalances {
		return nil
	}

	signers, err := api.Signers(r.network)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get signers validator map")
		return
	}

	reqs := make([]rpc.BatchElem, 0, len(signers))
	addresses := make([]string, 0, len(signers))

	for address := range signers {
		addr := common.HexToAddress(address)
		addresses = append(addresses, address)
		reqs = append(reqs, rpc.BatchElem{
			Method: "eth_getBalance",
			Args:   []any{addr, "latest"},
			Result: new(json.RawMessage),
		})
	}

	err = c.Client().BatchCallContext(ctx, reqs)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to execute batch request for validator balances")
		return err
	}

	for i, req := range reqs {
		logger := r.logger.Warn().Int("index", i)

		if req.Error != nil {
			logger.Err(req.Error).Msg("Failed to get validator balance")
			continue
		}

		var b string
		if err := json.Unmarshal(*req.Result.(*json.RawMessage), &b); err != nil {
			logger.Err(err).Msg("Failed to unmarshal validator balance")
			continue
		}

		balance, err := hexutil.DecodeBig(b)
		if err != nil {
			logger.Err(err).Msg("Failed to decode validator balance")
			continue
		}

		address := addresses[i]
		r.validatorBalances[address] = balance
	}

	return nil
}

type SignerInfo struct {
	Difficulty int    `json:"Difficulty"`
	Signer     string `json:"Signer"`
}

type SnapshotProposerSequence struct {
	Author  string       `json:"Author"`
	Diff    int          `json:"Diff"`
	Signers []SignerInfo `json:"Signers"`
}

func (r *RPCProvider) refreshMissedBlockProposal(ctx context.Context, c *ethclient.Client) error {
	if !r.fetchMissedProposals {
		return nil
	}

	for i := r.prevBlockNumber + 1; i <= r.blockNumber && r.prevBlockNumber != 0; i++ {
		var response SnapshotProposerSequence
		err := c.Client().CallContext(ctx, &response, "bor_getSnapshotProposerSequence", hexutil.EncodeUint64(i))
		if err != nil {
			r.logger.Warn().Err(err).Msg("Failed to execute request for snapshot proposer sequence")
			return err
		}

		b, err := r.blockBuffer.GetBlock(i)
		if err != nil {
			continue
		}
		block := b.(*types.Block)

		bytes, err := api.Ecrecover(block.Header())
		if err != nil {
			r.logger.Warn().Err(err).Msg("Failed to get block signer")
			continue
		}

		signer := "0x" + hex.EncodeToString(bytes)
		if signer == response.Author {
			continue
		}

		for _, info := range response.Signers {
			if signer == info.Signer {
				break
			}

			r.missedBlockProposal[i] = append(r.missedBlockProposal[i], info.Signer)
		}
	}

	return nil
}

type TxPoolStatus struct {
	Pending string `json:"pending"`
	Queued  string `json:"queued"`
}

func (r *RPCProvider) refreshTxPoolStatus(ctx context.Context, c *ethclient.Client) error {
	var response TxPoolStatus
	err := c.Client().CallContext(ctx, &response, "txpool_status")
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to execute request to get transaction pool status")
		return err
	}

	pending, err := strconv.ParseUint(strings.TrimPrefix(response.Pending, "0x"), 16, 0)
	if err != nil {
		return nil
	}
	queued, err := strconv.ParseUint(strings.TrimPrefix(response.Queued, "0x"), 16, 0)
	if err != nil {
		return nil
	}

	r.txPool = &observer.TransactionPool{
		Pending: pending,
		Queued:  queued,
	}

	return nil
}

// refreshTimeToMine sends a transaction to the network and records the time it
// took to be included in a block.
func (r *RPCProvider) refreshTimeToMine(ctx context.Context, c *ethclient.Client) error {
	if r.timeToMine == nil {
		return nil
	}

	gasPriceFactor := r.timeToMine.GasPriceFactor
	if gasPriceFactor == 0 {
		gasPriceFactor = 1
	}

	sender := common.HexToAddress(r.timeToMine.Sender)
	receiver := common.HexToAddress(r.timeToMine.Receiver)
	privateKey, err := crypto.HexToECDSA(r.timeToMine.SenderPrivateKey)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to parse SenderPrivateKey")
		return err
	}

	publicKey, ok := privateKey.Public().(*ecdsa.PublicKey)
	if !ok {
		err = errors.New("PublicKey type assertion failed")
		r.logger.Error().Err(err).Send()
		return err
	}

	address := crypto.PubkeyToAddress(*publicKey)
	if address != sender {
		err = fmt.Errorf("sender address mismatch %v != %v", sender, address)
		r.logger.Error().Err(err).Send()
		return err
	}

	gasPrice, err := c.SuggestGasPrice(ctx)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get suggested gas price")
		return err
	}
	gasPrice.Mul(gasPrice, big.NewInt(gasPriceFactor))

	nonce, err := c.PendingNonceAt(ctx, sender)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get pending nonce")
		return err
	}

	value := big.NewInt(r.timeToMine.Value)
	gasLimit := r.timeToMine.GasLimit
	data := []byte(r.timeToMine.Data)

	tx := types.NewTransaction(nonce, receiver, value, gasLimit, gasPrice, data)

	chainID, err := c.ChainID(ctx)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get network ID")
		return err
	}

	signedTx, err := types.SignTx(tx, types.NewEIP155Signer(chainID), privateKey)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to sign transaction")
		return err
	}

	if err := r.sendTransaction(ctx, c, signedTx); err != nil {
		return err
	}

	start := time.Now()

	// Generally, all messages sent to topics should be done in the PublishEvents
	// method. This is the exception because of its asynchronous nature. This
	// implementation reduces complexity by not needing to manage shared variables.
	//
	// This goroutine outlives the refresh cycle (waiting for the tx to be mined
	// can take minutes), so it is detached from the cycle context — which the
	// runner cancels once RefreshState returns — and given its own deadline.
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		defer cancel()

		_, err := bind.WaitMined(ctx, c, signedTx)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to wait for transaction")
		}

		ttm := &observer.TimeToMine{
			Seconds:        time.Since(start).Seconds(),
			GasPrice:       gasPrice,
			GasPriceFactor: gasPriceFactor,
		}

		m := observer.NewMessage(r.network, r.label, ttm)
		r.bus.Publish(ctx, topics.TimeToMine, m)
	}()

	return nil
}

// sendTransaction sends a signed transaction using either a custom RPC method
// (if configured) or the standard eth_sendRawTransaction method.
func (r *RPCProvider) sendTransaction(ctx context.Context, c *ethclient.Client, signedTx *types.Transaction) error {
	if r.timeToMine.SendMethod == nil {
		if err := c.SendTransaction(ctx, signedTx); err != nil {
			r.logger.Error().Err(err).Msg("Failed to send transaction")
			return err
		}
		return nil
	}

	rawTx, err := signedTx.MarshalBinary()
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to marshal transaction")
		return err
	}

	var result common.Hash
	if err := c.Client().CallContext(ctx, &result, *r.timeToMine.SendMethod, hexutil.Encode(rawTx)); err != nil {
		r.logger.Error().Err(err).Str("method", *r.timeToMine.SendMethod).Msg("Failed to send transaction with custom method")
		return err
	}

	return nil
}

func (r *RPCProvider) refreshAccountBalances(ctx context.Context, c *ethclient.Client) {
	if len(r.trackedAccounts) == 0 {
		return
	}

	// Build one balance per tracked account up front. Batch responses are
	// scattered back into this slice, which is the single source of truth for
	// both the account address and its fetched balances.
	balances := make([]*observer.AccountBalance, 0, len(r.trackedAccounts))
	for _, account := range r.trackedAccounts {
		balances = append(balances, &observer.AccountBalance{
			Address: common.HexToAddress(account.Address),
			Tag:     account.Tag,
		})
	}

	// Bound the whole balance fetch so a slow or unresponsive gateway cannot
	// stall the rest of RefreshState. The batch loops honour this deadline via
	// their per-iteration ctx.Err() check and the BatchCallContext calls.
	ctx, cancel := context.WithTimeout(ctx, r.accountBalanceTimeout)
	defer cancel()

	r.fetchETHBalances(ctx, c, balances)
	r.fetchPOLBalances(ctx, c, balances)

	if errors.Is(ctx.Err(), context.DeadlineExceeded) {
		r.logger.Warn().Dur("timeout", r.accountBalanceTimeout).Msg("Account balance fetch timed out; some balances not refreshed this cycle")
	}

	r.accountBalances = append(r.accountBalances, balances...)
}

// resolveTrackedAccounts returns the subset of accounts whose balances should be
// fetched. An account's inline TrackBalances override wins; otherwise it is
// tracked unless its tag is listed in excludeTags. A configured exclude tag that
// matches no account is logged, since it silently reduces nothing.
func resolveTrackedAccounts(logger zerolog.Logger, accounts []config.Account, excludeTags []string) []config.Account {
	exclude := make(map[string]struct{}, len(excludeTags))
	for _, tag := range excludeTags {
		exclude[tag] = struct{}{}
	}

	accountTags := make(map[string]struct{}, len(accounts))
	for _, account := range accounts {
		accountTags[account.Tag] = struct{}{}
	}
	for _, tag := range excludeTags {
		if _, ok := accountTags[tag]; !ok {
			logger.Warn().Str("tag", tag).Msg("exclude_balance_tags entry matches no account tag")
		}
	}

	var tracked []config.Account
	for _, account := range accounts {
		if account.TrackBalances != nil {
			if *account.TrackBalances {
				tracked = append(tracked, account)
			}
			continue
		}
		if _, excluded := exclude[account.Tag]; !excluded {
			tracked = append(tracked, account)
		}
	}
	return tracked
}

// fetchETHBalances fills the ETH balance for each account using batched
// eth_getBalance calls.
func (r *RPCProvider) fetchETHBalances(ctx context.Context, c *ethclient.Client, balances []*observer.AccountBalance) {
	for start := 0; start < len(balances); start += r.accountBalanceBatchSize {
		if ctx.Err() != nil {
			return
		}
		batch := balances[start:min(start+r.accountBalanceBatchSize, len(balances))]

		reqs := ethBalanceBatch(batch)
		if err := c.Client().BatchCallContext(ctx, reqs); err != nil {
			r.logger.Warn().Err(err).Msg("Failed to execute batch request for account ETH balances")
			continue
		}
		r.applyETHBalances(reqs, batch)
	}
}

// ethBalanceBatch builds an eth_getBalance batch request, one element per account.
func ethBalanceBatch(balances []*observer.AccountBalance) []rpc.BatchElem {
	reqs := make([]rpc.BatchElem, 0, len(balances))
	for _, b := range balances {
		reqs = append(reqs, rpc.BatchElem{
			Method: "eth_getBalance",
			Args:   []any{b.Address, "latest"},
			Result: new(json.RawMessage),
		})
	}
	return reqs
}

// applyETHBalances scatters a batch response into the accounts it targeted, where
// request j maps to balances[j].
func (r *RPCProvider) applyETHBalances(reqs []rpc.BatchElem, balances []*observer.AccountBalance) {
	for j, req := range reqs {
		eth, err := decodeBalanceResult(req)
		if err != nil {
			r.logger.Error().Err(err).Any("address", balances[j].Address).Str("token", observer.ETH).Msg("Failed to get balance")
			continue
		}
		balances[j].ETH = eth
	}
}

// decodeBalanceResult decodes a single eth_getBalance batch response.
func decodeBalanceResult(req rpc.BatchElem) (*big.Int, error) {
	hexStr, err := batchResultHex(req)
	if err != nil {
		return nil, err
	}
	return hexutil.DecodeBig(hexStr)
}

// fetchPOLBalances fills the POL (ERC20) balance for each account using batched
// eth_call balanceOf requests. On any per-account failure the balance is left
// nil, matching the previous per-account behaviour.
func (r *RPCProvider) fetchPOLBalances(ctx context.Context, c *ethclient.Client, balances []*observer.AccountBalance) {
	if r.polTokenAddress == nil {
		return
	}

	erc20abi, err := contracts.ERC20MetaData.GetAbi()
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to parse ERC20 ABI for POL balances")
		return
	}
	to := *r.polTokenAddress

	for start := 0; start < len(balances); start += r.accountBalanceBatchSize {
		if ctx.Err() != nil {
			return
		}
		batch := balances[start:min(start+r.accountBalanceBatchSize, len(balances))]

		reqs, targets := r.polBalanceBatch(erc20abi, to, batch)
		if err := c.Client().BatchCallContext(ctx, reqs); err != nil {
			r.logger.Warn().Err(err).Msg("Failed to execute batch request for account POL balances")
			continue
		}
		r.applyPOLBalances(erc20abi, reqs, targets)
	}
}

// polBalanceBatch builds eth_call balanceOf requests for the given accounts,
// returning the requests alongside the accounts they target. Accounts whose call
// data fails to pack are logged and skipped, so reqs[j] always corresponds to
// targets[j].
func (r *RPCProvider) polBalanceBatch(erc20abi *ethabi.ABI, to common.Address, balances []*observer.AccountBalance) ([]rpc.BatchElem, []*observer.AccountBalance) {
	reqs := make([]rpc.BatchElem, 0, len(balances))
	targets := make([]*observer.AccountBalance, 0, len(balances))
	for _, b := range balances {
		data, err := erc20abi.Pack("balanceOf", b.Address)
		if err != nil {
			r.logger.Error().Err(err).Any("address", b.Address).Str("token", observer.POL).Msg("Failed to pack balanceOf")
			continue
		}
		targets = append(targets, b)
		reqs = append(reqs, rpc.BatchElem{
			Method: "eth_call",
			Args:   []any{map[string]any{"to": to, "data": hexutil.Encode(data)}, "latest"},
			Result: new(json.RawMessage),
		})
	}
	return reqs, targets
}

// applyPOLBalances scatters a batch response into the accounts it targeted, where
// request j maps to targets[j].
func (r *RPCProvider) applyPOLBalances(erc20abi *ethabi.ABI, reqs []rpc.BatchElem, targets []*observer.AccountBalance) {
	for j, req := range reqs {
		pol, err := decodePOLResult(erc20abi, req)
		if err != nil {
			r.logger.Error().Err(err).Any("address", targets[j].Address).Str("token", observer.POL).Msg("Failed to get balance")
			continue
		}
		targets[j].POL = pol
	}
}

// decodePOLResult decodes a single eth_call balanceOf batch response.
func decodePOLResult(erc20abi *ethabi.ABI, req rpc.BatchElem) (*big.Int, error) {
	hexStr, err := batchResultHex(req)
	if err != nil {
		return nil, err
	}
	raw, err := hexutil.Decode(hexStr)
	if err != nil {
		return nil, err
	}
	out, err := erc20abi.Unpack("balanceOf", raw)
	if err != nil {
		return nil, err
	}
	if len(out) == 0 {
		return nil, errors.New("empty balanceOf result")
	}
	pol, ok := out[0].(*big.Int)
	if !ok {
		return nil, errors.New("unexpected balanceOf result type")
	}
	return pol, nil
}

// batchResultHex extracts the hex-string result from a JSON-RPC batch element,
// returning the element's error if the call itself failed.
func batchResultHex(req rpc.BatchElem) (string, error) {
	if req.Error != nil {
		return "", req.Error
	}
	var hexStr string
	if err := json.Unmarshal(*req.Result.(*json.RawMessage), &hexStr); err != nil {
		return "", err
	}
	return hexStr, nil
}

func (r *RPCProvider) refreshAccountTxs(ctx context.Context, c *ethclient.Client) {
	if len(r.accounts) == 0 {
		return
	}

	// Build lookup map from accounts
	accountMap := make(map[common.Address]string)
	for _, acc := range r.accounts {
		accountMap[common.HexToAddress(acc.Address)] = acc.Tag
	}

	// Get chain ID for signer
	chainID, err := c.ChainID(ctx)
	if err != nil {
		r.logger.Warn().Err(err).Msg("Failed to get chain ID for account tx tracking")
		return
	}
	signer := types.LatestSignerForChainID(chainID)

	// Iterate through new blocks
	for i := r.prevBlockNumber + 1; i <= r.blockNumber && r.prevBlockNumber != 0; i++ {
		b, err := r.blockBuffer.GetBlock(i)
		if err != nil {
			continue
		}
		block, ok := b.(*types.Block)
		if !ok {
			continue
		}

		for _, tx := range block.Transactions() {
			// Check sender (from)
			sender, err := types.Sender(signer, tx)
			if err == nil {
				if tag, exists := accountMap[sender]; exists {
					r.accountTxs = append(r.accountTxs, &observer.AccountTx{
						Address:   sender,
						Tag:       tag,
						Direction: "from",
					})
				}
			}

			// Check receiver (to)
			if to := tx.To(); to != nil {
				if tag, exists := accountMap[*to]; exists {
					r.accountTxs = append(r.accountTxs, &observer.AccountTx{
						Address:   *to,
						Tag:       tag,
						Direction: "to",
					})
				}
			}
		}
	}
}

func (r *RPCProvider) refreshBatches(ctx context.Context, c *ethclient.Client) {
	r.trustedBatches = nil
	prev := r.batches.TrustedBatch.Number

	r.refreshBatch(ctx, c, "zkevm_batchNumber", &r.batches.TrustedBatch)
	for i := prev + 1; i <= r.batches.TrustedBatch.Number && prev != 0; i++ {
		var batch util.Batch

		err := c.Client().CallContext(ctx, &batch, "zkevm_getBatchByNumber", i)
		if err != nil {
			r.logger.Warn().Err(err).Msg("Failed to get trusted batch by number")
			continue
		}

		r.trustedBatches = append(r.trustedBatches, &batch)
	}

	r.refreshBatch(ctx, c, "zkevm_virtualBatchNumber", &r.batches.VirtualBatch)
	r.refreshBatch(ctx, c, "zkevm_verifiedBatchNumber", &r.batches.VerifiedBatch)
}

func (r *RPCProvider) refreshBatch(ctx context.Context, c *ethclient.Client, endpoint string, batch *observer.ZkEVMBatch) {
	var response string
	err := c.Client().CallContext(ctx, &response, endpoint)
	if err != nil {
		r.logger.Warn().Err(err).Msgf("Failed to get %s", endpoint)
		return
	}

	result, err := strconv.ParseUint(response, 0, 0)
	if err != nil {
		r.logger.Warn().Err(err).Msgf("Failed to parse %s", endpoint)
		return
	}

	if result > batch.Number {
		batch.Number = result
		batch.Time = time.Now()
	}
}

// refreshExitRoot updates the exit root. If it has not been seen, set the exit
// root `Time` to `t`. If it has already been observed, the time will remain the
// same and the `Seen` value will be set to true.
func refreshExitRoot(er *observer.ExitRoot, bytes [32]byte, t time.Time) *observer.ExitRoot {
	hash := common.BytesToHash(bytes[:])
	if er == nil || er.Hash.Cmp(hash) != 0 {
		return &observer.ExitRoot{
			Hash: hash,
			Time: t,
		}
	}

	// Don't modify the passed in exit root, so return a new one.
	return &observer.ExitRoot{
		Hash: er.Hash,
		Time: er.Time,
		Seen: true,
	}
}

func (r *RPCProvider) refreshExitRoots(ctx context.Context, c *ethclient.Client) error {
	if r.globalExitRootAddress == nil {
		return nil
	}

	co := &bind.CallOpts{Context: ctx}
	contract, err := contracts.NewPolygonZkEVMGlobalExitRootV2(*r.globalExitRootAddress, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind global exit root contract")
		return nil
	}

	r.refreshGlobalExitRoot(ctx, c, contract, co)

	if mainnetExitRoot, err := contract.LastMainnetExitRoot(co); err != nil {
		r.logger.Error().Err(err).Msg("Failed to get last mainnet exit root")
	} else {
		r.mainnetExitRoot = refreshExitRoot(r.mainnetExitRoot, mainnetExitRoot, time.Now())
	}

	if rollupExitRoot, err := contract.LastRollupExitRoot(co); err != nil {
		r.logger.Error().Err(err).Msg("Failed to get last rollup exit root")
	} else {
		r.rollupExitRoot = refreshExitRoot(r.rollupExitRoot, rollupExitRoot, time.Now())
	}

	return nil
}

func (r *RPCProvider) refreshGlobalExitRoot(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonZkEVMGlobalExitRootV2, co *bind.CallOpts) {
	globalExitRoot, err := contract.GetLastGlobalExitRoot(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get last global exit root")
		return
	}

	t := time.Now()
	hash, err := contract.GlobalExitRootMap(co, globalExitRoot)
	if err != nil || hash == nil {
		r.logger.Error().Err(err).Msg("Failed to get block hash from global exit root map")
	} else {
		header, err := c.HeaderByHash(ctx, common.BigToHash(hash))
		if err != nil || header == nil {
			r.logger.Error().Err(err).Msg("Failed to get block header from global exit root block hash")
		} else {
			t = time.Unix(int64(header.Time), 0)
		}
	}

	r.globalExitRoot = refreshExitRoot(r.globalExitRoot, globalExitRoot, t)
}

func (r *RPCProvider) refreshExitRootsL2(ctx context.Context, c *ethclient.Client) error {
	if r.contracts.GlobalExitRootL2Address == nil {
		return nil
	}

	address := common.HexToAddress(*r.contracts.GlobalExitRootL2Address)
	contract, err := contracts.NewPolygonZkEVMGlobalExitRootL2(address, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind global exit root l2 contract")
		return err
	}

	co := bind.CallOpts{Context: ctx}
	rollupExitRoot, err := contract.LastRollupExitRoot(&co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get last rollup exit root")
		return err
	}

	r.rollupExitRootL2 = refreshExitRoot(r.rollupExitRootL2, rollupExitRoot, time.Now())

	return nil
}

func (r *RPCProvider) refreshBridge(ctx context.Context, c *ethclient.Client) error {
	if r.contracts.ZkEVMBridgeAddress == nil {
		return nil
	}

	r.bridgeEvents = nil
	r.claimEvents = nil

	co := bind.CallOpts{Context: ctx}
	address := common.HexToAddress(*r.contracts.ZkEVMBridgeAddress)
	contract, err := contracts.NewPolygonZkEVMBridgeV2(address, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind zkEVM bridge contract")
		return nil
	}

	dc, err := contract.DepositCount(&co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get deposit count")
	} else {
		r.depositCount = dc
	}

	ludc, err := contract.LastUpdatedDepositCount(&co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to get last updated deposit count")
	} else {
		r.lastUpdatedDepositCount = &ludc
	}

	opts := r.getFilterOpts()
	r.refreshBridgeEvents(ctx, c, contract, opts)
	r.refreshClaimEvents(ctx, c, contract, opts)

	return nil
}

func (r *RPCProvider) refreshBridgeEvents(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonZkEVMBridgeV2, opts *bind.FilterOpts) {
	iter, err := contract.FilterBridgeEvent(opts)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter bridge events")
		return
	}

	for iter.Next() && iter.Event != nil {
		event := iter.Event
		r.bridgeEvents = append(r.bridgeEvents, event)

		block, err := util.BlockByHash(ctx, event.Raw.BlockHash, c)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get block by hash")
			continue
		}

		networks := observer.BridgeEventNetworks{
			OriginNetwork:      event.OriginNetwork,
			DestinationNetwork: event.DestinationNetwork,
		}

		r.bridgeEventTimes[networks] = time.Unix(int64(block.Time()), 0)
	}
}

func (r *RPCProvider) refreshClaimEvents(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonZkEVMBridgeV2, opts *bind.FilterOpts) {
	iter, err := contract.FilterClaimEvent(opts)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter claim events")
		return
	}

	for iter.Next() && iter.Event != nil {
		event := iter.Event
		r.claimEvents = append(r.claimEvents, event)

		block, err := util.BlockByHash(ctx, event.Raw.BlockHash, c)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get block by hash")
			continue
		}

		r.claimEventTimes[event.OriginNetwork] = time.Unix(int64(block.Time()), 0)
	}
}

func (r *RPCProvider) getPOL(c *ethclient.Client, address common.Address, co *bind.CallOpts, prev *big.Int) *big.Int {
	if r.polTokenAddress == nil {
		return prev
	}

	erc20, err := contracts.NewERC20(*r.polTokenAddress, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind ERC20 contract")
		return prev
	}

	pol, err := erc20.BalanceOf(co, address)
	if err != nil || pol == nil {
		r.logger.Error().Err(err).
			Any("address", address).
			Str("token", observer.POL).
			Msg("Failed to get balance")

		return prev
	}

	return pol
}

func (r *RPCProvider) refreshTrustedSequencerBalance(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonZkEVMEtrog, co *bind.CallOpts, rollupID uint32) {
	address, err := contract.TrustedSequencer(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get trusted sequencer address")
		return
	}

	balances := &r.rollupManager.Rollups[rollupID].TrustedSequencerBalances

	eth, err := c.BalanceAt(ctx, address, nil)
	if err != nil || eth == nil {
		r.logger.Error().Err(err).
			Any("address", address).
			Str("token", observer.ETH).
			Msg("Failed to get balance")
	} else {
		balances.ETH = eth
	}

	balances.POL = r.getPOL(c, address, co, balances.POL)
}

// rollupManagers maps L1 network names to their corresponding rollup manager
// addresses and labels. It is used to identify the rollup manager contracts
// deployed on different networks. This should not be modified during runtime.
var rollupManagers = map[string]map[common.Address]string{
	network.EthereumName: {
		common.HexToAddress("0x5132A183E9F3CB7C848b0AAC5Ae0c4f0491B7aB2"): "Mainnet",
	},
	network.SepoliaName: {
		common.HexToAddress("0x32d33D5137a7cFFb54c5Bf8371172bcEc5f310ff"): "Cardona",
		common.HexToAddress("0xE2EF6215aDc132Df6913C8DD16487aBF118d1764"): "Bali",
	},
}

// getRollupNetwork determines the appropriate network configuration for a given
// rollup ID. It prioritizes a network name override if available, then checks
// known rollup manager addresses, and finally constructs a default name if
// necessary.
func (r *RPCProvider) getRollupNetwork(contract *contracts.PolygonZkEVMEtrog, co *bind.CallOpts, rollupID uint32) network.Network {
	// Use the network name override if available.
	if rollup, ok := r.contracts.RollupManager.Rollups[rollupID]; ok && rollup.Name != nil {
		if n, err := network.GetNetworkByName(*rollup.Name); err == nil {
			return n
		}
	}

	address := common.HexToAddress(*r.contracts.RollupManagerAddress)

	name := fmt.Sprintf("%s %s Rollup %d",
		r.network.GetName(),
		address.Hex(),
		rollupID,
	)

	if addresses, ok := rollupManagers[r.network.GetName()]; ok {
		if rollupManagerName, ok := addresses[address]; ok {
			name = fmt.Sprintf("%s Rollup %d", rollupManagerName, rollupID)
		}
	}

	if networkName, err := contract.NetworkName(co); err != nil {
		log.Warn().Err(err).Msg("Failed to get rollup network name")
	} else if networkName != "" {
		name = fmt.Sprintf("%s %s", name, networkName)
	}

	return &config.Network{
		Name: name,
	}
}

// isRollupEnabled determines if a rollup with the given rollupID is enabled. By
// default, all rollups are enabled.
func (r *RPCProvider) isRollupEnabled(rollupID uint32) bool {
	if slices.Contains(r.contracts.RollupManager.Disabled, rollupID) {
		return false
	}

	if slices.Contains(r.contracts.RollupManager.Enabled, rollupID) {
		return true
	}

	return len(r.contracts.RollupManager.Enabled) == 0
}

func (r *RPCProvider) refreshTrustedSequencerURL(ctx context.Context, contract *contracts.PolygonZkEVMEtrog, co *bind.CallOpts, rollupID uint32) (err error) {
	if !r.isRollupEnabled(rollupID) {
		return nil
	}

	network := r.getRollupNetwork(contract, co, rollupID)
	if network == nil {
		return nil
	}

	url, err := contract.TrustedSequencerURL(co)
	if err != nil {
		return err
	}

	rollup, ok := r.contracts.RollupManager.Rollups[rollupID]
	if ok && rollup.URL != nil {
		rollup.RPC.URL = *rollup.URL
	} else {
		rollup.RPC.URL = url
	}

	rollup.RPC.Label = r.label
	if ok && rollup.Label != nil {
		rollup.RPC.Label = *rollup.Label
	}

	provider, ok := r.trustedSequencers[rollupID]
	if !ok {
		r.trustedSequencers[rollupID] = NewRPCProvider(network, r.bus, rollup.RPC)
		// This is a long-lived loop, so it must not capture the caller's
		// per-cycle context (which is cancelled when the parent cycle returns);
		// give it a context tied to the process lifetime instead.
		go runProvider(context.Background(), r.trustedSequencers[rollupID])
		return nil
	}

	if provider.url != url {
		provider.trustedSequencerURL <- url
	}

	return nil
}

func runProvider(ctx context.Context, p *RPCProvider) {
	for ctx.Err() == nil {
		select {
		case url := <-p.trustedSequencerURL:
			p.url = url
		default:
			// Reuse the same bounded cycle as top-level providers so a hung
			// sub-provider upstream can't pin this goroutine.
			RunCycle(ctx, p)
		}
	}
}

func (r *RPCProvider) refreshZkEVMEtrog(ctx context.Context, c *ethclient.Client, co *bind.CallOpts, rollupID uint32, rollup RollupData) error {
	contract, err := contracts.NewPolygonZkEVMEtrog(rollup.RollupContract, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind zkEVM Etrog contract")
		return nil
	}

	if _, ok := r.rollupManager.Rollups[rollupID]; !ok {
		r.rollupManager.Rollups[rollupID] = &observer.RollupData{}
	}

	r.rollupManager.Rollups[rollupID].ChainID = &rollup.ChainID

	lfb, err := contract.LastForceBatch(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get last force batch")
	} else {
		r.rollupManager.Rollups[rollupID].LastForceBatch = &lfb
	}

	lfbs, err := contract.LastForceBatchSequenced(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get last force batch sequenced")
	} else {
		r.rollupManager.Rollups[rollupID].LastForceBatchSequenced = &lfbs
	}

	r.refreshTrustedSequencerBalance(ctx, c, contract, co, rollupID)
	r.refreshTrustedSequencerURL(ctx, contract, co, rollupID)

	return nil
}

func (r *RPCProvider) refreshAggregatorBalances(ctx context.Context, c *ethclient.Client, aggregator common.Address) {
	eth, err := c.BalanceAt(ctx, aggregator, nil)
	if err != nil || eth == nil {
		r.logger.Error().Err(err).Any("address", aggregator).Msg("Failed to get aggregator balance")
		return
	}

	co := &bind.CallOpts{Context: ctx}
	balances := r.rollupManager.AggregatorBalances[aggregator]
	balances.ETH = eth
	balances.POL = r.getPOL(c, aggregator, co, balances.POL)
	r.rollupManager.AggregatorBalances[aggregator] = balances
}

func (r *RPCProvider) refreshRollupManager(ctx context.Context, c *ethclient.Client) error {
	if r.contracts.RollupManagerAddress == nil {
		return nil
	}

	if r.rollupManager == nil {
		r.rollupManager = &observer.RollupManager{
			Rollups:            make(map[uint32]*observer.RollupData),
			AggregatorBalances: make(map[common.Address]observer.TokenBalances),
		}
	}

	for _, rollup := range r.rollupManager.Rollups {
		rollup.TimeBetweenSequencedBatches = nil
		rollup.TimeBetweenVerifiedBatches = nil
		rollup.SequencedBatchesTxFees = nil
		rollup.VerifiedBatchesTxFees = nil
	}

	co := &bind.CallOpts{Context: ctx}
	address := common.HexToAddress(*r.contracts.RollupManagerAddress)
	contract, err := contracts.NewPolygonRollupManager(address, c)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to bind rollup manager contract")
		return nil
	}

	// Fetch the other contract addresses from the rollup manager contract.
	if err := r.refreshZkEVMContracts(contract, co); err != nil {
		return err
	}

	rpb, err := contract.CalculateRewardPerBatch(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not calculate reward per batch")
	} else {
		r.rollupManager.RewardPerBatch = rpb
	}

	lat, err := contract.LastAggregationTimestamp(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get last aggregation timestamp")
	} else {
		r.rollupManager.LastAggregationTimestamp = &lat
	}

	opts := r.getFilterOpts()

	r.refreshBatchFees(contract, co)
	r.refreshBatchTotals(contract, co)
	r.refreshRollupCounts(contract, co)
	r.refreshRollups(ctx, c, contract, co)
	r.refreshOnSequenceBatches(ctx, c, contract, opts)
	r.refreshRollupVerifyBatches(ctx, c, contract, opts)
	r.refreshRollupVerifyBatchesTrustedAggregator(ctx, c, contract, opts)

	return nil
}

func (r *RPCProvider) refreshZkEVMContracts(contract *contracts.PolygonRollupManager, co *bind.CallOpts) error {
	if r.contracts.ZkEVMBridgeAddress == nil {
		bridgeAddress, err := contract.BridgeAddress(co)
		if err != nil {
			return err
		}

		r.contracts.ZkEVMBridgeAddress = new(string)
		*r.contracts.ZkEVMBridgeAddress = bridgeAddress.Hex()
	}

	if r.globalExitRootAddress == nil {
		germ, err := contract.GlobalExitRootManager(co)
		if err != nil {
			return nil
		}

		r.globalExitRootAddress = &germ
	}

	if r.polTokenAddress == nil {
		pol, err := contract.Pol(co)
		if err != nil {
			return err
		}

		r.polTokenAddress = &pol
	}

	return nil
}

// RollupData is the struct returned by the RollupIDToRollupData method. This is
// here because the abigen tool doesn't generate a named struct for this data.
// Update this value if the response ever changes.
type RollupData struct {
	RollupContract                 common.Address
	ChainID                        uint64
	Verifier                       common.Address
	ForkID                         uint64
	LastLocalExitRoot              [32]byte
	LastBatchSequenced             uint64
	LastVerifiedBatch              uint64
	LastPendingState               uint64
	LastPendingStateConsolidated   uint64
	LastVerifiedBatchBeforeUpgrade uint64
	RollupTypeID                   uint64
	RollupCompatibilityID          uint8
}

func (r *RPCProvider) refreshRollups(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonRollupManager, co *bind.CallOpts) {
	if r.rollupManager.RollupCount == nil {
		return
	}

	for id := uint32(1); id <= *r.rollupManager.RollupCount; id++ {
		rollup, err := contract.RollupIDToRollupData(co, id)
		if err != nil {
			r.logger.Error().Err(err).Uint32("rollup", id).Msg("Failed to get rollup data")
			continue
		}

		r.refreshZkEVMEtrog(ctx, c, co, id, rollup)
	}
}

func (r *RPCProvider) refreshBatchFees(contract *contracts.PolygonRollupManager, co *bind.CallOpts) {
	bf, err := contract.GetBatchFee(co)
	if err != nil || bf == nil {
		r.logger.Error().Err(err).Msg("Could not get batch fee")
	} else {
		r.rollupManager.BatchFee = bf
	}

	fbf, err := contract.GetForcedBatchFee(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get forced batch fee")
	} else {
		r.rollupManager.ForcedBatchFee = fbf
	}
}

func (r *RPCProvider) refreshRollupCounts(contract *contracts.PolygonRollupManager, co *bind.CallOpts) {
	rc, err := contract.RollupCount(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get rollup count")
	} else {
		r.rollupManager.RollupCount = &rc
	}

	rtc, err := contract.RollupTypeCount(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get rollup type count")
	} else {
		r.rollupManager.RollupTypeCount = &rtc
	}
}

func (r *RPCProvider) refreshBatchTotals(contract *contracts.PolygonRollupManager, co *bind.CallOpts) {
	tsb, err := contract.TotalSequencedBatches(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get total sequenced batches")
	} else {
		r.rollupManager.TotalSequencedBatches = &tsb
	}

	tvb, err := contract.TotalVerifiedBatches(co)
	if err != nil {
		r.logger.Error().Err(err).Msg("Could not get total verified batches")
	} else {
		r.rollupManager.TotalVerifiedBatches = &tvb
	}
}

func (r *RPCProvider) refreshOnSequenceBatches(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonRollupManager, opts *bind.FilterOpts) {
	iter, err := contract.FilterOnSequenceBatches(opts, nil)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter on sequence batches events")
		return
	}

	var event *contracts.PolygonRollupManagerOnSequenceBatches
	for iter.Next() && iter.Event != nil {
		event = iter.Event

		block, err := c.BlockByHash(ctx, event.Raw.BlockHash)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get block by hash")
			continue
		}

		time := block.Time()

		rollup, ok := r.rollupManager.Rollups[event.RollupID]
		if !ok {
			continue
		}

		if rollup.LastBatchSequenced != nil {
			if *rollup.LastBatchSequenced >= event.LastBatchSequenced {
				continue
			}

			rollup.TimeBetweenSequencedBatches = append(
				rollup.TimeBetweenSequencedBatches,
				time-*rollup.LastSequencedTimestamp,
			)
		}

		// Any logic after this point means that there is a new event that hasn't
		// been published to an observer yet.

		rollup.LastSequencedTimestamp = &time
		rollup.LastBatchSequenced = &event.LastBatchSequenced

		receipt, err := c.TransactionReceipt(ctx, event.Raw.TxHash)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get transaction receipt")
			continue
		}

		fee := new(big.Int).Mul(big.NewInt(int64(receipt.GasUsed)), receipt.EffectiveGasPrice)
		rollup.SequencedBatchesTxFees = append(rollup.SequencedBatchesTxFees, observer.RollupTx{
			Fee:     fee,
			Address: event.Raw.Address,
		})
	}
}

func (r *RPCProvider) refreshRollupVerifyBatches(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonRollupManager, opts *bind.FilterOpts) {
	iter, err := contract.FilterVerifyBatches(opts, nil, nil)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter rollup verify batches events")
		return
	}

	var event *contracts.PolygonRollupManagerVerifyBatches
	for iter.Next() && iter.Event != nil {
		event = iter.Event

		r.refreshAggregatorBalances(ctx, c, event.Aggregator)

		block, err := c.BlockByHash(ctx, event.Raw.BlockHash)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get block by hash")
			continue
		}

		time := block.Time()

		rollup, ok := r.rollupManager.Rollups[event.RollupID]
		if !ok {
			continue
		}

		if rollup.LastVerifiedBatch != nil {
			if *rollup.LastVerifiedBatch >= event.NumBatch {
				continue
			}

			// There should not be an instance where a rollup has events for both the
			// VerifyBatches and VerifyBatchesTrustedAggregator, so the
			// TimeBetweenVerifiedBatches and VerifiedBatchesTxFees slices should not
			// be not be affected.
			rollup.TimeBetweenVerifiedBatches = append(
				rollup.TimeBetweenVerifiedBatches,
				time-*rollup.LastVerifiedTimestamp,
			)
		}

		// Any logic after this point means that there is a new event that hasn't
		// been published to an observer yet.

		rollup.LastVerifiedTimestamp = &time
		rollup.LastVerifiedBatch = &event.NumBatch

		receipt, err := c.TransactionReceipt(ctx, event.Raw.TxHash)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get transaction receipt")
			continue
		}

		fee := new(big.Int).Mul(big.NewInt(int64(receipt.GasUsed)), receipt.EffectiveGasPrice)
		rollup.VerifiedBatchesTxFees = append(rollup.VerifiedBatchesTxFees, observer.RollupTx{
			Fee:     fee,
			Address: event.Aggregator,
		})
	}
}

func (r *RPCProvider) refreshRollupVerifyBatchesTrustedAggregator(ctx context.Context, c *ethclient.Client, contract *contracts.PolygonRollupManager, opts *bind.FilterOpts) {
	iter, err := contract.FilterVerifyBatchesTrustedAggregator(opts, nil, nil)
	if err != nil {
		r.logger.Error().Err(err).Msg("Failed to filter rollup verify batches trusted aggregator batches events")
		return
	}

	var event *contracts.PolygonRollupManagerVerifyBatchesTrustedAggregator
	for iter.Next() && iter.Event != nil {
		event = iter.Event

		r.refreshAggregatorBalances(ctx, c, event.Aggregator)

		block, err := c.BlockByHash(ctx, event.Raw.BlockHash)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get block by hash")
			continue
		}

		time := block.Time()

		rollup, ok := r.rollupManager.Rollups[event.RollupID]
		if !ok {
			continue
		}

		pessimistic := event.NumBatch == 0 && event.StateRoot == [32]byte{}

		if rollup.LastVerifiedBatch != nil {
			// Here, pessimistic chains are handled differently because the NumBatch
			// will always be 0. The last verified timestamp is used to determine if
			// the event has already been seen.
			//
			// There is an edge case here where if both events are included in the
			// same block, there will be a missing time between verified batches
			// event. This will be rare and won't significantly impact the metric.
			if pessimistic && *rollup.LastVerifiedTimestamp >= time {
				continue
			}

			if !pessimistic && *rollup.LastVerifiedBatch >= event.NumBatch {
				continue
			}

			// At this point rollup.LastVerifiedBatch and rollup.LastVerifiedTimestamp
			// contain the data of the previous verified batch event, not the current
			// one (which is stored in event). This is used to calculate the time
			// between the verified batches.
			//
			// This iterator traverses the logs in order, so even if there's more than
			// one verified batches event, the logic will hold.
			rollup.TimeBetweenVerifiedBatches = append(
				rollup.TimeBetweenVerifiedBatches,
				time-*rollup.LastVerifiedTimestamp,
			)
		}

		// Any logic after this point means that there is a new event that hasn't
		// been published to an observer yet.

		rollup.LastVerifiedTimestamp = &time
		rollup.LastVerifiedBatch = &event.NumBatch
		rollup.Pessimistic = pessimistic

		receipt, err := c.TransactionReceipt(ctx, event.Raw.TxHash)
		if err != nil {
			r.logger.Error().Err(err).Msg("Failed to get transaction receipt")
			continue
		}

		fee := new(big.Int).Mul(big.NewInt(int64(receipt.GasUsed)), receipt.EffectiveGasPrice)
		rollup.VerifiedBatchesTxFees = append(rollup.VerifiedBatchesTxFees, observer.RollupTx{
			Fee:     fee,
			Address: event.Aggregator,
		})
	}
}
