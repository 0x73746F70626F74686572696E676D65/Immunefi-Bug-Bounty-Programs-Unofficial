package provider

import (
	"context"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog"
	orderedmap "github.com/wk8/go-ordered-map/v2"

	"github.com/0xPolygon/panoptichain/api"
	"github.com/0xPolygon/panoptichain/blockbuffer"
	"github.com/0xPolygon/panoptichain/config"
	"github.com/0xPolygon/panoptichain/network"
	"github.com/0xPolygon/panoptichain/observer"
	"github.com/0xPolygon/panoptichain/observer/topics"
	"github.com/0xPolygon/panoptichain/proto/heimdall"
)

// ErrInvalidSpan is returned when a span has zero ID with zero blocks,
// indicating a malformed API response.
var ErrInvalidSpan = errors.New("invalid span: zero ID with zero blocks")

// heimdallBlockBufferSize is how many blocks the block buffer retains. Once
// full it evicts the lowest number, so fillRange clamps to this window.
const heimdallBlockBufferSize = 128

// feeDenom is the denomination an empty fee account is reported under, so an
// exhausted one still produces a series alongside the funded ones.
const feeDenom = "pol"

type HeimdallProvider struct {
	tendermintURL string
	heimdallURL   string
	network       network.Network
	label         string
	bus           *observer.EventBus
	interval      time.Duration
	logger        zerolog.Logger

	blockNumber         uint64
	prevBlockNumber     uint64
	blockBuffer         *blockbuffer.BlockBuffer
	missedBlockProposal observer.HeimdallMissedBlockProposal

	checkpoint                *observer.HeimdallCheckpoint
	checkpointProposers       *orderedmap.OrderedMap[string, struct{}]
	missedCheckpointProposers []string

	milestones         []*observer.HeimdallMilestone
	prevMilestoneCount int64
	latestMilestone    *observer.HeimdallMilestone

	spans *observer.HeimdallSpans
	// spanUpdates holds the Prev/Curr snapshots to publish this cycle. refreshSpan
	// walks every span from the last known one up to the latest, so each
	// consecutive pair is published and overlap detection sees the full sequence.
	spanUpdates []*observer.HeimdallSpans

	// borProviders are the RPC providers for this network, used to read the
	// current Bor block height (no second Bor connection). Empty when none is
	// configured, in which case the active span is unknown.
	borProviders []*RPCProvider
	// activeSpan is the span containing the current Bor block, published every
	// cycle on topics.ActiveSpan; nil when the Bor height is unavailable or not
	// yet resolved.
	activeSpan *observer.HeimdallSpan
	// spanCursor is the convergence cursor for resolving the active span: it
	// walks one span per fetch toward the block and persists across cycles so a
	// long catch-up resumes where it left off (like refreshMilestone's backlog).
	spanCursor *observer.HeimdallSpan

	validatorSets *observer.HeimdallValidatorSets

	missedVotes    []*observer.HeimdallMissedVotes
	validatorIDMap map[string]uint64 // normalized signer_address -> val_id

	refreshStateTime *time.Duration

	bufferedCheckpoint *observer.HeimdallCheckpoint

	// feeBalances holds the most recent sweep, published on the cycle it ran.
	// nil between sweeps: the gauges are absolute and Prometheus retains them.
	feeBalances *observer.HeimdallFeeBalances
	// feeBalancesEnabled is false when the endpoint opted out.
	feeBalancesEnabled bool
	// feeBalanceInterval is how often the sweep runs, independent of the
	// provider's polling interval.
	feeBalanceInterval time.Duration
	// feeBalanceTimeout bounds one sweep, so a degraded Heimdall API cannot
	// spend the cycle deadline here and starve the refresh steps after it.
	feeBalanceTimeout time.Duration
	// nextFeeBalanceSweep is when the next sweep is due; zero sweeps at once.
	nextFeeBalanceSweep time.Time
}

// feeBalanceConcurrency bounds the sweep's in-flight requests. It is one
// request per validator against a single host, so this is what keeps a
// ~100-validator set from arriving as a burst.
const feeBalanceConcurrency = 8

// NewHeimdallProvider builds a Heimdall provider, reusing the rpcProviders entry
// matching this endpoint's network (if any) to read the current Bor block height.
func NewHeimdallProvider(n network.Network, eb *observer.EventBus, cfg config.HeimdallEndpoint, rpcProviders []*RPCProvider) *HeimdallProvider {
	logger := NewLogger(n, cfg.Label)

	borProviders := rpcProvidersByNetwork(rpcProviders)[n.GetName()]
	if len(borProviders) == 0 {
		logger.Warn().Msg("No RPC provider configured for this network; active span metrics will not be emitted")
	}

	feeBalancesEnabled := cfg.FeeBalances == nil || *cfg.FeeBalances

	feeBalanceInterval := config.DefaultFeeBalanceInterval
	if cfg.FeeBalanceInterval != nil {
		feeBalanceInterval = *cfg.FeeBalanceInterval
	}

	feeBalanceTimeout := config.DefaultFeeBalanceTimeout
	if cfg.FeeBalanceTimeout != nil {
		feeBalanceTimeout = *cfg.FeeBalanceTimeout
	}

	return &HeimdallProvider{
		tendermintURL:       cfg.TendermintURL,
		heimdallURL:         cfg.HeimdallURL,
		network:             n,
		label:               cfg.Label,
		bus:                 eb,
		borProviders:        borProviders,
		blockBuffer:         blockbuffer.NewBlockBuffer(heimdallBlockBufferSize),
		interval:            GetInterval(cfg.Interval),
		logger:              logger,
		checkpointProposers: orderedmap.New[string, struct{}](),
		refreshStateTime:    new(time.Duration),
		spans:               &observer.HeimdallSpans{},
		validatorSets:       &observer.HeimdallValidatorSets{},

		feeBalancesEnabled: feeBalancesEnabled,
		feeBalanceInterval: feeBalanceInterval,
		feeBalanceTimeout:  feeBalanceTimeout,
	}
}

func (h *HeimdallProvider) RefreshState(ctx context.Context) error {
	defer timer(h.refreshStateTime)()

	// The runner bounds this cycle with a deadline and api.GetJSON honours it, so
	// a slow/degraded upstream cannot make RefreshState run unbounded. The
	// freshness milestone is fetched first inside refreshMilestone, so a
	// truncated cycle only drops backlog accounting, never the freshness gauge.
	h.logger.Debug().Msg("Refreshing Heimdall state")

	anchorTime := h.refreshBlockBuffer(ctx)
	h.refreshValidatorSet(ctx)
	h.refreshMilestone(ctx, anchorTime)
	h.refreshCheckpoint(ctx)
	h.refreshBufferedCheckpoint(ctx)
	h.refreshMissedCheckpointProposal(ctx)
	h.refreshMissedBlockProposal(ctx)
	h.refreshSpan(ctx)
	h.refreshActiveSpan(ctx)
	h.refreshMissedVotes(ctx)
	h.refreshFeeBalances(ctx)

	return nil
}

func (h *HeimdallProvider) PublishEvents(ctx context.Context) error {
	for i := h.prevBlockNumber + 1; i <= h.blockNumber && h.prevBlockNumber != 0; i++ {
		b, err := h.blockBuffer.GetBlock(i)
		if err != nil {
			continue
		}

		block, ok := b.(*observer.HeimdallBlock)
		if !ok {
			continue
		}

		m := observer.NewMessage(h.network, h.label, block)
		h.bus.Publish(ctx, topics.NewHeimdallBlock, m)

		bn := b.Number()
		if bn == nil {
			continue
		}

		pb, err := h.blockBuffer.GetBlock(bn.Uint64() - 1)
		if pb == nil {
			continue
		}

		prev, ok := pb.(*observer.HeimdallBlock)
		if !ok {
			continue
		}

		time, err := block.Time()
		if err != nil {
			h.logger.Warn().Err(err).Msg("Failed to get Heimdall block time")
			continue
		}

		prevTime, err := prev.Time()
		if err != nil {
			h.logger.Warn().Err(err).Msg("Failed to get previous Heimdall block time")
			continue
		}

		interval := observer.NewMessage(h.network, h.label, time-prevTime)
		h.bus.Publish(ctx, topics.HeimdallBlockInterval, interval)
	}

	if h.missedBlockProposal != nil {
		m := observer.NewMessage(h.network, h.label, h.missedBlockProposal)
		h.bus.Publish(ctx, topics.HeimdallMissedBlockProposal, m)
	}

	if h.checkpoint != nil {
		m := observer.NewMessage(h.network, h.label, h.checkpoint)
		h.bus.Publish(ctx, topics.Checkpoint, m)
	}

	if len(h.missedCheckpointProposers) > 0 {
		m := observer.NewMessage(h.network, h.label, h.missedCheckpointProposers)
		h.bus.Publish(ctx, topics.MissedCheckpointProposal, m)
	}

	// Publish the tip milestone (drives the freshness gauges) independently of
	// the per-milestone backlog stream below, so freshness never lags a slow
	// catch-up.
	if h.latestMilestone != nil {
		latest := observer.NewMessage(h.network, h.label, h.latestMilestone)
		h.bus.Publish(ctx, topics.MilestoneLatest, latest)
	}

	for _, milestone := range h.milestones {
		m := observer.NewMessage(h.network, h.label, milestone)
		h.bus.Publish(ctx, topics.Milestone, m)
	}

	for _, s := range h.spanUpdates {
		m := observer.NewMessage(h.network, h.label, s)
		h.bus.Publish(ctx, topics.Span, m)
	}

	// Publish every cycle (observer handles nil) so it tracks the chain into new
	// spans, unlike the latest span above (published only on change). Skipped
	// entirely when the feature is off (no RPC provider for this network).
	if len(h.borProviders) > 0 {
		h.bus.Publish(ctx, topics.ActiveSpan, observer.NewMessage(h.network, h.label, h.activeSpan))
	}

	if h.validatorSets != nil {
		m := observer.NewMessage(h.network, h.label, h.validatorSets)
		h.bus.Publish(ctx, topics.ValidatorSet, m)
	}

	// Always publish buffered checkpoint (observer handles nil)
	h.bus.Publish(ctx, topics.BufferedCheckpoint, observer.NewMessage(h.network, h.label, h.bufferedCheckpoint))

	for _, mv := range h.missedVotes {
		if mv.MissingCount > 0 {
			m := observer.NewMessage(h.network, h.label, mv)
			h.bus.Publish(ctx, topics.MissedVote, m)
		}
	}

	// Only on the cycles the sweep ran; the gauges are absolute, so there is
	// nothing to say in between.
	if h.feeBalances != nil {
		h.bus.Publish(ctx, topics.ValidatorFeeBalance, observer.NewMessage(h.network, h.label, h.feeBalances))
		h.feeBalances = nil
	}

	h.bus.Publish(ctx, topics.RefreshStateTime, observer.NewMessage(h.network, h.label, h.refreshStateTime))

	return nil
}

func (h *HeimdallProvider) Logger() zerolog.Logger {
	return h.logger
}

func (h *HeimdallProvider) PollingInterval() time.Duration {
	return h.interval
}

// refreshBlockBuffer refreshes the block buffer and returns the latest block's
// timestamp (0 if unavailable) so callers can reuse it as a vote-height anchor
// without refetching the tip block.
func (h *HeimdallProvider) refreshBlockBuffer(ctx context.Context) uint64 {
	h.prevBlockNumber = h.blockNumber
	block := h.getBlock(ctx, 0)
	if block == nil {
		return 0
	}

	bn := block.Number()
	if bn == nil {
		return 0
	}
	h.blockNumber = bn.Uint64()

	h.logger.Debug().Uint64("block_number", h.blockNumber).Msg("Refreshing Heimdall state")
	if h.prevBlockNumber != 0 && h.prevBlockNumber != h.blockNumber {
		h.fillRange(ctx, h.prevBlockNumber)
	}

	anchorTime, err := block.Time()
	if err != nil {
		return 0
	}

	return anchorTime
}

func (h *HeimdallProvider) getBlock(ctx context.Context, height uint64) *observer.HeimdallBlock {
	path, err := url.JoinPath(h.tendermintURL, "block")
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to join path when fetching Heimdall block")
		return nil
	}

	if height > 0 {
		path = fmt.Sprintf("%s?height=%d", path, height)
	}

	var block observer.HeimdallBlock
	err = api.GetJSON(ctx, path, &block)
	if err != nil {
		h.logger.Warn().Err(err).Msg("Failed to get Heimdall block")
		return nil
	}

	return &block
}

// bufferedBlock returns block i from the in-cycle block buffer (populated by
// fillRange), fetching it over HTTP only on a cache miss.
func (h *HeimdallProvider) bufferedBlock(ctx context.Context, i uint64) *observer.HeimdallBlock {
	if b, err := h.blockBuffer.GetBlock(i); err == nil {
		if block, ok := b.(*observer.HeimdallBlock); ok {
			return block
		}
	}

	return h.getBlock(ctx, i)
}

// scanDeadlineReached reports whether the cycle deadline has been hit mid-scan,
// logging the skipped [from, to] block range. Used by the per-block range scans,
// whose skipped blocks are a hole this cycle.
func (h *HeimdallProvider) scanDeadlineReached(ctx context.Context, from, to uint64, scan string) bool {
	if ctx.Err() == nil {
		return false
	}

	h.logger.Warn().
		Err(ctx.Err()).
		Uint64("from", from).
		Uint64("to", to).
		Str("scan", scan).
		Msg("Scan deadline reached; skipping remaining")

	return true
}

func (h *HeimdallProvider) getValidatorsAtHeight(ctx context.Context, height uint64) ([]*observer.HeimdallValidator, error) {
	const perPage = 100
	const maxPages = 10

	var v []*observer.HeimdallValidator

	for page := 1; page <= maxPages; page++ {
		path, err := url.JoinPath(h.tendermintURL, "validators")
		if err != nil {
			return nil, fmt.Errorf("failed to join validators path: %w", err)
		}

		path = fmt.Sprintf("%s?height=%d&per_page=%d&page=%d", path, height, perPage, page)

		var validators observer.HeimdallValidators
		if err := api.GetJSON(ctx, path, &validators); err != nil {
			return nil, fmt.Errorf("failed to get validators at height %d page %d: %w", height, page, err)
		}

		v = append(v, validators.Validators()...)

		total, _ := strconv.Atoi(validators.Result.Total)
		if len(v) >= total {
			break
		}
	}

	return v, nil
}

func (h *HeimdallProvider) fillRange(ctx context.Context, start uint64) {
	// A load-balanced node can report a height below the last one seen, which
	// would underflow the range below.
	if h.blockNumber < start {
		return
	}

	// Blocks past the buffer window are evicted before anything reads them, and
	// each is a sequential fetch spending cycle budget that the later refresh
	// steps need. After an outage this range can reach several hundred blocks.
	if h.blockNumber-start >= heimdallBlockBufferSize {
		clamped := h.blockNumber - (heimdallBlockBufferSize - 1)

		h.logger.Warn().
			Uint64("requested_start_block", start).
			Uint64("start_block", clamped).
			Uint64("end_block", h.blockNumber).
			Uint64("skipped_blocks", clamped-start).
			Msg("Block range exceeds the buffer capacity; filling only the newest blocks")

		start = clamped
	}

	h.logger.Debug().
		Uint64("start_block", start).
		Uint64("end_block", h.blockNumber).
		Msg("Filling block range")

	for i := start; i <= h.blockNumber; i++ {
		block := h.getBlock(ctx, i)
		if block == nil {
			h.logger.Warn().Uint64("block_number", i).Msg("Failed to get block")
			break
		}

		h.blockBuffer.PutBlock(block)
	}
}

func (h *HeimdallProvider) refreshMilestone(ctx context.Context, anchorTime uint64) error {
	h.milestones = nil

	// Fetch the (cheap) count first. Keep the cursor monotonic: a load-balanced
	// node briefly reporting a lower count must not rewind it, or already-counted
	// milestones get re-published and double-counted when the count recovers. On
	// an idle cycle (no new milestone) the cached tip is republished for
	// freshness, so there's no need to fetch the tip body again.
	currentCount, err := h.getMilestoneCount(ctx)
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall milestone count")
		return err
	}

	if currentCount <= h.prevMilestoneCount {
		return nil
	}

	// Forward progress: fetch the tip for the freshness gauges. Because we only
	// get here on progress, a stale lower tip can't rewind them.
	latest, err := h.getLatestMilestone(ctx, currentCount)
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get latest Heimdall milestone")
		return err
	}
	if latest != nil {
		h.latestMilestone = latest
	}

	// On first poll, baseline to the tip; otherwise backfill new milestones.
	start := h.prevMilestoneCount + 1
	if h.prevMilestoneCount == 0 {
		start = currentCount
	}

	voteCache := make(map[uint64]*observer.HeimdallMilestoneVotes)

	// Walk milestones one at a time, advancing the cursor only over those we
	// actually process. The per-cycle deadline bounds the work; a catch-up
	// truncated by the deadline resumes from where it stopped next cycle. A
	// milestone that fails to fetch on its own (pruned/404/malformed) is skipped
	// so it can't stall every later milestone behind it.
	processed := start - 1
	for i := start; i <= currentCount; i++ {
		if ctx.Err() != nil {
			h.logger.Warn().
				Err(ctx.Err()).
				Int64("from", i).
				Int64("to", currentCount).
				Msg("Milestone refresh deadline reached; resuming next cycle")
			break
		}

		milestone, err := h.getMilestone(ctx, i, latest, currentCount)
		if err != nil {
			// Deadline hit mid-fetch: resume from here next cycle. Any other
			// error is specific to this milestone, so skip past it.
			if ctx.Err() != nil {
				h.logger.Warn().
					Err(err).
					Int64("milestone", i).
					Msg("Milestone refresh deadline reached; resuming next cycle")
				break
			}

			h.logger.Warn().
				Err(err).
				Int64("milestone", i).
				Msg("Failed to get Heimdall milestone; skipping")
			processed = i
			continue
		}

		milestone.Votes = h.findMilestoneVotes(ctx, milestone, anchorTime, voteCache)

		h.milestones = append(h.milestones, milestone)
		processed = i
	}

	h.prevMilestoneCount = processed
	return nil
}

// getMilestone returns milestone i. The tip (i == currentCount) is reused from
// latest when available so the backfill loop doesn't refetch a milestone
// getLatestMilestone already fetched this cycle.
func (h *HeimdallProvider) getMilestone(ctx context.Context, i int64, latest *observer.HeimdallMilestone, currentCount int64) (*observer.HeimdallMilestone, error) {
	if i == currentCount && latest != nil {
		return latest, nil
	}

	path, err := url.JoinPath(h.heimdallURL, "milestones", strconv.FormatInt(i, 10))
	if err != nil {
		return nil, err
	}

	var v2 observer.HeimdallMilestoneV2
	if err := api.GetJSON(ctx, path, &v2); err != nil {
		return nil, err
	}

	milestone := &v2.Milestone
	milestone.Count = i

	return milestone, nil
}

// getMilestoneCount fetches the total milestone count.
func (h *HeimdallProvider) getMilestoneCount(ctx context.Context) (int64, error) {
	countPath, err := url.JoinPath(h.heimdallURL, "milestones", "count")
	if err != nil {
		return 0, err
	}

	var count observer.HeimdallMilestoneCount
	if err := api.GetJSON(ctx, countPath, &count); err != nil {
		return 0, err
	}

	return int64(count.Count), nil
}

// getLatestMilestone fetches the tip milestone for the given count and stamps
// its Count so downstream freshness gauges report the tip index. It prefers the
// dedicated /milestones/latest endpoint but falls back to fetching by count when
// that errors or returns an empty/zero-value body (e.g. a 200 with an unexpected
// shape), so a provider that doesn't serve a usable /milestones/latest still
// keeps the freshness gauges alive. Returns nil when no usable tip is available.
func (h *HeimdallProvider) getLatestMilestone(ctx context.Context, currentCount int64) (*observer.HeimdallMilestone, error) {
	var v2 observer.HeimdallMilestoneV2
	latestPath, err := url.JoinPath(h.heimdallURL, "milestones", "latest")
	if err != nil {
		return nil, err
	}
	if err := api.GetJSON(ctx, latestPath, &v2); err != nil || v2.Milestone.Timestamp == 0 {
		if err != nil {
			h.logger.Warn().
				Err(err).
				Msg("milestones/latest unavailable; falling back to fetch by count")
		} else {
			h.logger.Warn().
				Msg("milestones/latest returned an empty body; falling back to fetch by count")
		}

		byCount, err := url.JoinPath(h.heimdallURL, "milestones", strconv.FormatInt(currentCount, 10))
		if err != nil {
			return nil, err
		}
		if err := api.GetJSON(ctx, byCount, &v2); err != nil {
			return nil, err
		}
	}

	milestone := &v2.Milestone
	if milestone.Timestamp == 0 {
		// Still empty after the fallback; don't drive the freshness gauge
		// (time.Since of a zero timestamp) from it. Backfill by count still proceeds.
		return nil, nil
	}
	milestone.Count = currentCount

	return milestone, nil
}

func (h *HeimdallProvider) refreshCheckpoint(ctx context.Context) error {
	path, err := url.JoinPath(h.heimdallURL, "checkpoints", "latest")
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall latest checkpoint path")
		return err
	}

	var v2 observer.HeimdallCheckpointV2
	if err = api.GetJSON(ctx, path, &v2); err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall latest checkpoint")
		return err
	}

	h.checkpoint = &v2.Checkpoint

	return nil
}

func (h *HeimdallProvider) refreshBufferedCheckpoint(ctx context.Context) error {
	path, err := url.JoinPath(h.heimdallURL, "checkpoints", "buffer")
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall buffered checkpoint path")
		return err
	}

	var v2 observer.HeimdallCheckpointV2
	if err = api.GetJSON(ctx, path, &v2); err != nil {
		h.logger.Warn().Err(err).Msg("Failed to get Heimdall buffered checkpoint")
		h.bufferedCheckpoint = nil
		return err
	}

	// API returns zero ID when no buffered checkpoint exists
	if v2.Checkpoint.ID == 0 {
		h.bufferedCheckpoint = nil
	} else {
		h.bufferedCheckpoint = &v2.Checkpoint
	}

	return nil
}

func (h *HeimdallProvider) getCurrentCheckpointProposer(ctx context.Context) (string, error) {
	path, err := url.JoinPath(h.heimdallURL, "checkpoints", "prepare-next")
	if err != nil {
		return "", err
	}

	var resp observer.HeimdallPrepareNextCheckpoint
	if err = api.GetJSON(ctx, path, &resp); err != nil {
		return "", err
	}

	return resp.Checkpoint.Proposer, nil
}

func (h *HeimdallProvider) refreshMissedCheckpointProposal(ctx context.Context) error {
	var proposers []string
	for pair := h.checkpointProposers.Oldest(); pair != nil; pair = pair.Next() {
		proposers = append(proposers, pair.Key)
	}

	h.logger.Debug().
		Any("checkpoint_proposers", proposers).
		Any("missed_checkpoint_proposers", h.missedCheckpointProposers).
		Msg("Refreshing missed checkpoint proposal")

	h.missedCheckpointProposers = nil

	signer, err := h.getCurrentCheckpointProposer(ctx)
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall current checkpoint proposer")
		return err
	}

	if _, ok := h.checkpointProposers.Get(signer); !ok {
		h.checkpointProposers.Set(signer, struct{}{})
	}

	// No checkpoint has been observed yet (fresh chain, or the latest checkpoint
	// fetch failed this cycle). There is nothing to measure misses against, so
	// keep the proposer we just recorded and try again next cycle.
	if h.checkpoint == nil {
		return nil
	}

	latest := h.checkpoint.Proposer
	if _, ok := h.checkpointProposers.Get(latest); !ok {
		return nil
	}

	for pair := h.checkpointProposers.Oldest(); pair != nil; pair = pair.Next() {
		proposer := pair.Key

		h.checkpointProposers.Delete(proposer)
		if proposer == latest {
			break
		}

		h.missedCheckpointProposers = append(h.missedCheckpointProposers, proposer)
	}

	return nil
}

func cometBFTProposers(validators []*observer.HeimdallValidator, rounds int) ([]string, error) {
	if len(validators) == 0 {
		return nil, fmt.Errorf("empty validator set")
	}

	type val struct {
		address  string
		priority int64
		power    int64
	}

	vals := make([]val, 0, len(validators))
	var total int64
	for _, v := range validators {
		p, err := strconv.ParseInt(v.ProposerPriority, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("proposer_priority %q for %s: %w", v.ProposerPriority, v.Address, err)
		}
		w, err := strconv.ParseInt(v.VotingPower, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("voting_power %q for %s: %w", v.VotingPower, v.Address, err)
		}
		vals = append(vals, val{address: v.Address, priority: p, power: w})
		total += w
	}

	// RescalePriorities(PriorityWindowSizeFactor * totalVotingPower). Integer
	// division truncating toward zero, matching Go's int64 `/`.
	if diffMax := 2 * total; diffMax > 0 {
		min, max := vals[0].priority, vals[0].priority
		for _, v := range vals {
			if v.priority < min {
				min = v.priority
			}
			if v.priority > max {
				max = v.priority
			}
		}
		if diff := max - min; diff > diffMax {
			ratio := (diff + diffMax - 1) / diffMax
			for i := range vals {
				vals[i].priority /= ratio
			}
		}
	}

	// shiftByAvgProposerPriority. CometBFT computes the average with big.Int
	// Div, which floors; Go's int64 `/` truncates toward zero, so they differ
	// for a negative sum. Use big.Int to match exactly.
	sum := big.NewInt(0)
	for _, v := range vals {
		sum.Add(sum, big.NewInt(v.priority))
	}
	avg := new(big.Int).Div(sum, big.NewInt(int64(len(vals)))).Int64()
	for i := range vals {
		vals[i].priority -= avg
	}

	winners := make([]string, 0, rounds+1)
	for r := 0; r <= rounds; r++ {
		best := -1
		for i := range vals {
			vals[i].priority += vals[i].power
		}
		for i := range vals {
			switch {
			case best < 0 || vals[i].priority > vals[best].priority:
				best = i
			case vals[i].priority == vals[best].priority && vals[i].address < vals[best].address:
				// CompareProposerPriority breaks ties on the lower address.
				best = i
			}
		}
		vals[best].priority -= total
		winners = append(winners, vals[best].address)
	}

	return winners, nil
}

// refreshMissedBlockProposal records, per block, the consensus round it committed
// in and which validators were selected in the rounds before that and failed
// to propose.
//
// A block that commits in round 0 missed nothing, which is the overwhelming
// majority, so the validator set is only fetched when round > 0. In normal
// operation this costs one extra commit fetch per block and nothing else.
func (h *HeimdallProvider) refreshMissedBlockProposal(ctx context.Context) error {
	rounds := make(observer.HeimdallMissedBlockProposal)

	for i := h.prevBlockNumber + 1; i <= h.blockNumber && h.prevBlockNumber != 0; i++ {
		if h.scanDeadlineReached(ctx, i, h.blockNumber, "proposal_round") {
			break
		}

		commit, err := h.getCommit(ctx, i)
		if err != nil {
			h.logger.Debug().Err(err).Uint64("height", i).Msg("Failed to get commit")
			continue
		}

		round := commit.Result.SignedHeader.Commit.Round
		if round <= 0 {
			rounds[i] = observer.HeimdallProposalRound{Round: 0}
			continue
		}

		validators, err := h.getValidatorsAtHeight(ctx, i-1)
		if err != nil {
			h.logger.Debug().Err(err).Uint64("height", i).Msg("Failed to get validators for proposal round")
			// The round itself is still known and still a real miss, so record
			// it unattributed rather than dropping it.
			rounds[i] = observer.HeimdallProposalRound{Round: round}
			continue
		}

		winners, err := cometBFTProposers(validators, round)
		if err != nil {
			h.logger.Warn().Err(err).Uint64("height", i).Msg("Failed to replay proposer selection")
			rounds[i] = observer.HeimdallProposalRound{Round: round}
			continue
		}

		rounds[i] = observer.HeimdallProposalRound{Round: round, Missed: winners[:round]}
	}

	h.missedBlockProposal = rounds

	return nil
}

func (h *HeimdallProvider) refreshSpan(ctx context.Context) error {
	h.spanUpdates = nil

	// Always fetch the latest span
	latest, err := h.getLatestSpan(ctx)
	if err != nil {
		return err
	}

	// Set current span on startup
	if h.spans.Curr == nil {
		h.spans.Curr = latest
		h.recordSpanUpdate()
		return nil
	}

	// No new span: nothing to publish. The span gauges retain their last value,
	// so republishing would only make the observer re-count the same overlap
	// every idle cycle.
	if latest.ID <= h.spans.Curr.ID {
		return nil
	}

	// Walk every new span up to the latest so overlap detection sees each
	// consecutive pair (mirrors refreshMilestone). The per-cycle deadline bounds
	// the work; a catch-up truncated by the deadline resumes from the advanced
	// Curr next cycle. Each step is published as its own Prev/Curr snapshot; the
	// final one carries the latest span forward.
	for id := h.spans.Curr.ID + 1; id <= latest.ID; id++ {
		if ctx.Err() != nil {
			h.logger.Warn().
				Uint64("span_id", id).
				Err(ctx.Err()).
				Msg("Span walk deadline reached; resuming next cycle")
			return nil
		}

		span := latest
		if id != latest.ID {
			span, err = h.getSpan(ctx, id)
			if err != nil {
				if ctx.Err() != nil {
					// Deadline reached mid-fetch; resume from here next cycle.
					h.logger.Warn().
						Uint64("span_id", id).
						Err(err).
						Msg("Span walk deadline reached; resuming next cycle")
					return nil
				}

				// Skip a span that fails on its own (pruned/404/transient) so one
				// bad span can't freeze span progress.
				h.logger.Warn().
					Uint64("span_id", id).
					Err(err).
					Msg("Failed to fetch span; skipping")
				continue
			}
		}

		h.spans.Prev = h.spans.Curr
		h.spans.Curr = span
		h.recordSpanUpdate()
	}

	return nil
}

// recordSpanUpdate snapshots the current Prev/Curr span pair for publishing this
// cycle. Each call captures the pointers as they stand, so a walk over several
// spans records every consecutive pair in order.
func (h *HeimdallProvider) recordSpanUpdate() {
	h.spanUpdates = append(h.spanUpdates, &observer.HeimdallSpans{Prev: h.spans.Prev, Curr: h.spans.Curr})
}

func (h *HeimdallProvider) getLatestSpan(ctx context.Context) (*observer.HeimdallSpan, error) {
	return h.fetchSpan(ctx, "latest")
}

func (h *HeimdallProvider) getSpan(ctx context.Context, id uint64) (*observer.HeimdallSpan, error) {
	return h.fetchSpan(ctx, strconv.FormatUint(id, 10))
}

func (h *HeimdallProvider) fetchSpan(ctx context.Context, spanID string) (*observer.HeimdallSpan, error) {
	path, err := url.JoinPath(h.heimdallURL, "bor", "spans", spanID)
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall span path")
		return nil, err
	}

	var v2 observer.HeimdallSpanV2
	if err = api.GetJSON(ctx, path, &v2); err != nil {
		h.logger.Error().Err(err).Msg("Failed to get Heimdall span")
		return nil, err
	}

	span := &v2.Span
	if span.ID == 0 && span.StartBlock == 0 && span.EndBlock == 0 {
		h.logger.Error().
			Str("requested_span", spanID).
			Msg("Received invalid zero-value span from API")
		return nil, ErrInvalidSpan
	}

	return span, nil
}

// refreshActiveSpan resolves the span containing the current Bor block from the
// RPC provider's height into activeSpan (nil when no provider or no height yet).
func (h *HeimdallProvider) refreshActiveSpan(ctx context.Context) {
	block := h.borHeight()
	if block == 0 {
		h.activeSpan = nil
		h.spanCursor = nil
		return
	}

	h.activeSpan = h.resolveActiveSpan(ctx, block)
}

// borHeight returns the highest Bor block height across the RPC providers for
// this network, or 0 when none is configured or none has a height yet. The
// highest wins so a single lagging or stalled provider can't drag the active
// span backward while a healthy one is available.
func (h *HeimdallProvider) borHeight() uint64 {
	var height uint64
	for _, r := range h.borProviders {
		if bn := r.BlockNumber(); bn > height {
			height = bn
		}
	}
	return height
}

// spanContainsBlock reports whether the span includes the given Bor block.
func spanContainsBlock(s *observer.HeimdallSpan, block uint64) bool {
	return s != nil && block >= s.StartBlock && block <= s.EndBlock
}

// knownSpanContaining returns the highest-id already-known span that contains
// the block, or nil. Spans can overlap, and the newest span owns the overlap.
func (h *HeimdallProvider) knownSpanContaining(block uint64) *observer.HeimdallSpan {
	var best *observer.HeimdallSpan
	for _, s := range []*observer.HeimdallSpan{h.spanCursor, h.spans.Curr, h.spans.Prev} {
		if spanContainsBlock(s, block) && (best == nil || s.ID > best.ID) {
			best = s
		}
	}
	return best
}

// spanByID returns the span with the given id, reusing an already-held span
// (Curr/Prev) instead of fetching when possible.
func (h *HeimdallProvider) spanByID(ctx context.Context, id uint64) (*observer.HeimdallSpan, error) {
	if h.spans.Curr != nil && h.spans.Curr.ID == id {
		return h.spans.Curr, nil
	}
	if h.spans.Prev != nil && h.spans.Prev.ID == id {
		return h.spans.Prev, nil
	}
	return h.getSpan(ctx, id)
}

// resolveActiveSpan returns the span containing the given Bor block. The
// /bor/spans/latest span can be created preemptively, before the chain reaches
// its start block, so the block often sits in an earlier span (usually
// latest-1). It converges spanCursor toward the block one span per fetch,
// bounded by the per-cycle deadline; progress persists on spanCursor so a long
// catch-up resumes next cycle (mirroring refreshMilestone's backlog walk).
// Returns nil when the block isn't in any span (a gap) or hasn't been reached
// yet.
func (h *HeimdallProvider) resolveActiveSpan(ctx context.Context, block uint64) *observer.HeimdallSpan {
	// Fast path, no fetch: an already-known span (cursor, Curr, Prev) contains it.
	if best := h.knownSpanContaining(block); best != nil {
		h.spanCursor = best
		return best
	}

	// Seed from the known span nearest the block so convergence starts with the
	// fewest fetches (e.g. step down from Curr rather than climb from a stale
	// cursor after the chain jumped forward).
	h.spanCursor = h.nearestKnownSpan(block)

	for h.spanCursor != nil && !spanContainsBlock(h.spanCursor, block) {
		if ctx.Err() != nil {
			return nil // deadline; resume from spanCursor next cycle
		}

		next := h.stepToward(ctx, h.spanCursor, block)
		if next == nil {
			return nil
		}
		h.spanCursor = next
	}

	return h.spanCursor
}

// stepToward fetches the span one step from cur toward the block, or returns nil
// if the walk should stop: the block is past the latest committed span, cur is
// the genesis span, the fetch failed, the API returned an unexpected id, or the
// block falls in a gap between adjacent spans.
func (h *HeimdallProvider) stepToward(ctx context.Context, cur *observer.HeimdallSpan, block uint64) *observer.HeimdallSpan {
	var nextID uint64
	switch {
	case block > cur.EndBlock:
		// Curr is the latest committed span; never fetch above it. A block past
		// Curr means its span isn't committed yet (rare, since the latest span is
		// usually preemptive), so it's unknown for now.
		if h.spans.Curr == nil || cur.ID >= h.spans.Curr.ID {
			return nil
		}
		nextID = cur.ID + 1
	case cur.ID == 0:
		return nil // block precedes the genesis span
	default:
		nextID = cur.ID - 1
	}

	next, err := h.spanByID(ctx, nextID)
	if err != nil {
		h.logger.Debug().Uint64("span_id", nextID).Err(err).Msg("Failed to fetch span while resolving active span")
		return nil
	}
	if next.ID != nextID {
		// The API returned a different span than requested (e.g. an out-of-range
		// id clamped to latest); bail to avoid a stuck loop.
		return nil
	}

	// The block falls in a gap between adjacent spans (an overlap/pruning
	// anomaly), so no span contains it.
	if (block > cur.EndBlock && next.StartBlock > block) ||
		(block < cur.StartBlock && next.EndBlock < block) {
		return nil
	}

	return next
}

// nearestKnownSpan returns the already-known span (cursor, Curr, Prev) closest
// to the block, so a convergence walk starts with the fewest fetches.
func (h *HeimdallProvider) nearestKnownSpan(block uint64) *observer.HeimdallSpan {
	var best *observer.HeimdallSpan
	var bestDist uint64
	for _, s := range []*observer.HeimdallSpan{h.spanCursor, h.spans.Curr, h.spans.Prev} {
		if s == nil {
			continue
		}
		if d := spanDistance(s, block); best == nil || d < bestDist {
			best, bestDist = s, d
		}
	}
	return best
}

// spanDistance returns how far the block lies outside the span (0 if inside).
func spanDistance(s *observer.HeimdallSpan, block uint64) uint64 {
	switch {
	case block < s.StartBlock:
		return s.StartBlock - block
	case block > s.EndBlock:
		return block - s.EndBlock
	default:
		return 0
	}
}

func (h *HeimdallProvider) refreshValidatorSet(ctx context.Context) error {
	validators, err := api.GetValidators(ctx, h.heimdallURL)
	if err != nil {
		h.logger.Error().Err(err).Msg("Failed to get validator set")
		return err
	}

	curr := make(observer.ValidatorMap, len(validators))
	ids := make(map[string]uint64, len(validators))
	for _, v := range validators {
		curr[v.ID] = v
		ids[normalizeAddress(v.Signer)] = v.ID
	}

	if h.validatorSets.Curr != nil {
		h.validatorSets.Prev = h.validatorSets.Curr
	}
	h.validatorSets.Curr = curr
	h.validatorIDMap = ids

	return nil
}

func (h *HeimdallProvider) getCommit(ctx context.Context, height uint64) (*observer.HeimdallCommit, error) {
	path, err := url.JoinPath(h.tendermintURL, "commit")
	if err != nil {
		return nil, fmt.Errorf("failed to join commit path: %w", err)
	}

	var commit observer.HeimdallCommit
	if err := api.GetJSON(ctx, fmt.Sprintf("%s?height=%d", path, height), &commit); err != nil {
		return nil, fmt.Errorf("failed to get commit at height %d: %w", height, err)
	}

	return &commit, nil
}

func normalizeAddress(addr string) string {
	return strings.ToLower(strings.TrimPrefix(addr, "0x"))
}

func (h *HeimdallProvider) getMissedVotes(ctx context.Context, height uint64) (*observer.HeimdallMissedVotes, error) {
	validators, err := h.getValidatorsAtHeight(ctx, height)
	if err != nil {
		return nil, fmt.Errorf("failed to get validators at height %d: %w", height, err)
	}

	commit, err := h.getCommit(ctx, height)
	if err != nil {
		return nil, err
	}

	signatures := commit.Result.SignedHeader.Commit.Signatures
	if len(signatures) != len(validators) {
		h.logger.Warn().
			Int("validators", len(validators)).
			Int("signatures", len(signatures)).
			Uint64("height", height).
			Msg("Validator and signature array length mismatch")
		return nil, nil
	}

	var missedVotes []observer.HeimdallMissedVote
	for i, sig := range signatures {
		if sig.BlockIDFlag == 2 {
			continue
		}

		validator := validators[i]
		valID := h.validatorIDMap[normalizeAddress(validator.Address)]

		flagLabel := "absent"
		if sig.BlockIDFlag == 3 {
			flagLabel = "nil"
		}

		missedVotes = append(missedVotes, observer.HeimdallMissedVote{
			ValidatorID:   valID,
			SignerAddress: validator.Address,
			FlagLabel:     flagLabel,
		})
	}

	return &observer.HeimdallMissedVotes{
		Height:       height,
		MissingCount: len(missedVotes),
		MissedVotes:  missedVotes,
	}, nil
}

func (h *HeimdallProvider) refreshMissedVotes(ctx context.Context) {
	if h.validatorIDMap == nil {
		return
	}

	h.missedVotes = nil

	h.logger.Debug().Msg("Refreshing missed consensus votes")

	for height := h.prevBlockNumber + 1; height <= h.blockNumber && h.prevBlockNumber != 0; height++ {
		if h.scanDeadlineReached(ctx, height, h.blockNumber, "missed_votes") {
			break
		}

		mv, err := h.getMissedVotes(ctx, height)
		if err != nil {
			h.logger.Warn().
				Err(err).
				Uint64("height", height).
				Msg("Failed to detect missed votes")
			continue
		}
		if mv != nil {
			h.missedVotes = append(h.missedVotes, mv)
		}
	}
}

// getExtendedCommitInfo fetches and decodes the ExtendedCommitInfo from txs[0]
// of a Heimdall block. Vote extensions from block H-1 are stored in block H's txs[0].
func (h *HeimdallProvider) getExtendedCommitInfo(ctx context.Context, height uint64) (*heimdall.ExtendedCommitInfo, error) {
	block := h.bufferedBlock(ctx, height)
	if block == nil {
		return nil, fmt.Errorf("failed to get block at height %d", height)
	}

	txs := block.Result.Block.Data.Txs
	if len(txs) == 0 {
		return nil, fmt.Errorf("no transactions in block at height %d", height)
	}

	// txs[0] contains the base64-encoded ExtendedCommitInfo
	veBytes, err := base64.StdEncoding.DecodeString(txs[0])
	if err != nil {
		return nil, fmt.Errorf("failed to base64 decode txs[0]: %w", err)
	}

	extCommit, err := heimdall.UnmarshalExtendedCommitInfo(veBytes)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal ExtendedCommitInfo: %w", err)
	}

	return extCommit, nil
}

// getMilestoneVotes processes vote extensions from a block and returns milestone vote data.
func (h *HeimdallProvider) getMilestoneVotes(ctx context.Context, height uint64) (*observer.HeimdallMilestoneVotes, error) {
	extCommit, err := h.getExtendedCommitInfo(ctx, height)
	if err != nil {
		return nil, err
	}

	var (
		votes           []observer.HeimdallMilestoneVote
		totalVP         int64
		milestoneVP     int64
		milestoneVoters int
	)

	for _, v := range extCommit.Votes {
		if v.Validator == nil {
			continue
		}
		validatorAddr := hex.EncodeToString(v.Validator.Address)
		votingPower := v.Validator.Power
		totalVP += votingPower

		vote := observer.HeimdallMilestoneVote{
			ValidatorAddress: validatorAddr,
			ValidatorID:      h.validatorIDMap[normalizeAddress(validatorAddr)],
			VotingPower:      votingPower,
			BlockIDFlag:      int(v.BlockIdFlag),
		}

		if len(v.VoteExtension) > 0 {
			h.getMilestoneFromVoteExtension(&vote, v.VoteExtension)
			if vote.HasMilestone {
				milestoneVP += votingPower
				milestoneVoters++
			}
		}

		votes = append(votes, vote)
	}

	return &observer.HeimdallMilestoneVotes{
		Height:               height,
		TotalValidators:      len(votes),
		TotalVotingPower:     totalVP,
		MilestoneVoters:      milestoneVoters,
		MilestoneVotingPower: milestoneVP,
		Votes:                votes,
	}, nil
}

// getMilestoneFromVoteExtension decodes the vote extension and populates milestone data if present.
func (h *HeimdallProvider) getMilestoneFromVoteExtension(vote *observer.HeimdallMilestoneVote, data []byte) {
	ve, err := heimdall.UnmarshalVoteExtension(data)
	if err != nil {
		h.logger.Warn().
			Err(err).
			Str("validator", vote.ValidatorAddress).
			Msg("Failed to decode vote extension")
		return
	}

	if ve.MilestoneProposition == nil {
		return
	}

	mp := ve.MilestoneProposition
	if len(mp.BlockHashes) == 0 {
		return
	}
	vote.HasMilestone = true
	vote.MilestoneStart = mp.StartBlockNumber
	vote.MilestoneEnd = mp.StartBlockNumber + uint64(len(mp.BlockHashes)) - 1
}

// getBlockHeight estimates the Heimdall block height for a given timestamp,
// anchored on the latest block's number and time (anchorTime). Assumes ~2
// second block time.
func (h *HeimdallProvider) getBlockHeight(target int64, anchorTime uint64) uint64 {
	if h.blockNumber == 0 || anchorTime == 0 {
		return 0
	}

	// Estimate based on ~2 second block time
	diff := (int64(anchorTime) - target) / 2
	if diff < 0 {
		return 0
	}

	if uint64(diff) > h.blockNumber {
		return 0
	}

	return h.blockNumber - uint64(diff)
}

// findMilestoneVotes searches for votes matching this milestone's range.
// Uses the milestone timestamp to estimate the finalization block.
// Returns the first matching vote block, or nil if not found. The cache
// memoizes successful per-height lookups across milestones within the same
// cycle; failed fetches are not cached so a later milestone can retry them.
func (h *HeimdallProvider) findMilestoneVotes(ctx context.Context, milestone *observer.HeimdallMilestone, anchorTime uint64, cache map[uint64]*observer.HeimdallMilestoneVotes) *observer.HeimdallMilestoneVotes {
	if h.validatorIDMap == nil {
		return nil
	}

	height := h.getBlockHeight(milestone.Timestamp, anchorTime)
	if height == 0 {
		return nil
	}

	// Search a small window around the estimated height
	const window = 5
	start := max(1, height-window)
	end := min(h.blockNumber, height+window)

	for i := start; i <= end; i++ {
		mv, ok := cache[i]
		if !ok {
			votes, err := h.getMilestoneVotes(ctx, i)
			if err != nil {
				// Don't cache the error; a later milestone can retry this height.
				continue
			}
			mv = votes
			cache[i] = mv
		}

		if mv == nil || mv.MilestoneVoters == 0 {
			continue
		}

		if h.votesMatchMilestone(mv, milestone) {
			return mv
		}
	}

	return nil
}

// votesMatchMilestone checks if any vote in the votes matches the milestone's block range.
func (h *HeimdallProvider) votesMatchMilestone(mv *observer.HeimdallMilestoneVotes, milestone *observer.HeimdallMilestone) bool {
	for _, vote := range mv.Votes {
		if !vote.HasMilestone {
			continue
		}

		if vote.MilestoneStart == milestone.StartBlock && vote.MilestoneEnd == milestone.EndBlock {
			return true
		}
	}

	return false
}

// heimdallBankBalances is the Cosmos bank balances response -- the same
// endpoint the staking portal reads for "Heimdall Fees".
type heimdallBankBalances struct {
	Balances []struct {
		Denom  string `json:"denom"`
		Amount string `json:"amount"`
	} `json:"balances"`
}

// refreshFeeBalances sweeps every validator's Heimdall fee account balance.
//
// It keeps its own cadence rather than running every cycle: one request per
// validator, for a balance that drains by a flat per-transaction fee and so
// moves far too slowly to poll at the provider's interval. It also takes its
// own deadline, so a slow Heimdall API cannot spend the whole cycle here.
func (h *HeimdallProvider) refreshFeeBalances(ctx context.Context) {
	if !h.feeBalancesEnabled {
		return
	}

	now := time.Now()
	if now.Before(h.nextFeeBalanceSweep) {
		return
	}

	if h.validatorSets == nil || len(h.validatorSets.Curr) == 0 {
		// refreshValidatorSet failed this cycle. Leave the cadence alone so the
		// next cycle retries rather than waiting a full interval.
		h.logger.Debug().Msg("No validator set; skipping Heimdall fee balance sweep")
		return
	}

	// Scheduled from the start of this sweep, so a slow one does not push the
	// cadence out.
	h.nextFeeBalanceSweep = now.Add(h.feeBalanceInterval)

	sweepCtx, cancel := context.WithTimeout(ctx, h.feeBalanceTimeout)
	defer cancel()

	validators := make([]api.Validator, 0, len(h.validatorSets.Curr))
	for _, v := range h.validatorSets.Curr {
		validators = append(validators, v)
	}

	type result struct {
		balances []observer.HeimdallFeeBalance
		err      error
	}

	results := make([]result, len(validators))

	var wg sync.WaitGroup
	sem := make(chan struct{}, feeBalanceConcurrency)

	for i, v := range validators {
		wg.Add(1)
		go func() {
			defer wg.Done()

			select {
			case sem <- struct{}{}:
				defer func() { <-sem }()
			case <-sweepCtx.Done():
				results[i] = result{err: sweepCtx.Err()}
				return
			}

			balances, err := h.getFeeBalance(sweepCtx, v)
			results[i] = result{balances: balances, err: err}
		}()
	}

	wg.Wait()

	out := &observer.HeimdallFeeBalances{
		Balances: make([]observer.HeimdallFeeBalance, 0, len(validators)),
	}

	var firstErr error
	for _, r := range results {
		if r.err != nil {
			out.Failed++
			if firstErr == nil {
				firstErr = r.err
			}
			continue
		}
		out.Balances = append(out.Balances, r.balances...)
	}

	if out.Failed > 0 {
		h.logger.Warn().
			Err(firstErr).
			Int("failed", out.Failed).
			Int("validators", len(validators)).
			Dur("elapsed", time.Since(now)).
			Msg("Heimdall fee balance sweep did not resolve every validator")
	}

	h.feeBalances = out
}

// getFeeBalance reads one validator's Heimdall fee account. An empty list
// becomes an explicit zero rather than being dropped: an exhausted account is
// the condition worth alerting on, so it must not go missing.
func (h *HeimdallProvider) getFeeBalance(ctx context.Context, v api.Validator) ([]observer.HeimdallFeeBalance, error) {
	path, err := url.JoinPath(h.heimdallURL, "cosmos", "bank", "v1beta1", "balances", v.Signer)
	if err != nil {
		return nil, fmt.Errorf("failed to join balances path: %w", err)
	}

	var body heimdallBankBalances
	if err := api.GetJSON(ctx, path, &body); err != nil {
		return nil, fmt.Errorf("failed to get fee balance for validator %d: %w", v.ID, err)
	}

	if len(body.Balances) == 0 {
		return []observer.HeimdallFeeBalance{{
			ValidatorID:   v.ID,
			SignerAddress: v.Signer,
			Denom:         feeDenom,
			Amount:        new(big.Int),
		}}, nil
	}

	out := make([]observer.HeimdallFeeBalance, 0, len(body.Balances))
	for _, b := range body.Balances {
		amount, ok := new(big.Int).SetString(b.Amount, 10)
		if !ok {
			h.logger.Warn().
				Uint64("validator_id", v.ID).
				Str("denom", b.Denom).
				Str("amount", b.Amount).
				Msg("Failed to parse Heimdall fee balance amount")
			continue
		}

		out = append(out, observer.HeimdallFeeBalance{
			ValidatorID:   v.ID,
			SignerAddress: v.Signer,
			Denom:         b.Denom,
			Amount:        amount,
		})
	}

	return out, nil
}
