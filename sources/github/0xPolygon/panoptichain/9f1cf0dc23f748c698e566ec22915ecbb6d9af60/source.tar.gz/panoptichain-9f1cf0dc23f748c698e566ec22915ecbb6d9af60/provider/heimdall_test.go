package provider

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	orderedmap "github.com/wk8/go-ordered-map/v2"

	"github.com/0xPolygon/panoptichain/observer"
)

// newSpan creates a HeimdallSpan with the given parameters.
func newSpan(id, start, end uint64) *observer.HeimdallSpan {
	return &observer.HeimdallSpan{
		ID:         id,
		StartBlock: start,
		EndBlock:   end,
	}
}

// newSpanServer creates a test server that responds with spans based on a path-to-span map.
func newSpanServer(t *testing.T, spans map[string]*observer.HeimdallSpan) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		span, ok := spans[r.URL.Path]
		if !ok {
			http.NotFound(w, r)
			return
		}
		json.NewEncoder(w).Encode(observer.HeimdallSpanV2{Span: *span})
	}))
}

// newProvider creates a HeimdallProvider with the given server URL and current span.
func newProvider(serverURL string, curr *observer.HeimdallSpan) *HeimdallProvider {
	return &HeimdallProvider{
		heimdallURL: serverURL,
		spans:       &observer.HeimdallSpans{Curr: curr},
		logger:      NewLogger(nil, "test"),
	}
}

func TestRefreshSpan_Bootstrap(t *testing.T) {
	span := newSpan(100, 1000, 1099)
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/latest": span,
	})
	defer server.Close()

	h := newProvider(server.URL, nil)

	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}

	if h.spans.Curr == nil {
		t.Fatal("expected Curr span to be set")
	}
	if h.spans.Curr.ID != 100 {
		t.Errorf("expected span ID 100, got %d", h.spans.Curr.ID)
	}
	if h.spans.Prev != nil {
		t.Error("expected Prev span to be nil on bootstrap")
	}
}

func TestRefreshSpan_Sequential(t *testing.T) {
	span101 := newSpan(101, 1100, 1199)
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/latest": span101,
		"/bor/spans/101":    span101,
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(100, 1000, 1099))

	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}

	if h.spans.Curr == nil {
		t.Fatal("expected Curr span to be set")
	}
	if h.spans.Curr.ID != 101 {
		t.Errorf("expected span ID 101, got %d", h.spans.Curr.ID)
	}
	if h.spans.Prev == nil {
		t.Fatal("expected Prev span to be set")
	}
	if h.spans.Prev.ID != 100 {
		t.Errorf("expected prev span ID 100, got %d", h.spans.Prev.ID)
	}
}

func TestRefreshSpan_NextSpanNotAvailable(t *testing.T) {
	span := newSpan(100, 1000, 1099)
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/latest": span,
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(100, 1000, 1099))
	originalCurr := h.spans.Curr

	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}

	if h.spans.Curr != originalCurr {
		t.Error("expected Curr span to remain unchanged when no new span available")
	}
	if h.spans.Prev != nil {
		t.Error("expected Prev span to remain nil when no new span available")
	}
}

func TestRefreshSpan_DetectsOverlappingSpans(t *testing.T) {
	// Span 101 starts at 1050, which overlaps with span 100's end block (1099)
	span101 := newSpan(101, 1050, 1149)
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/latest": span101,
		"/bor/spans/101":    span101,
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(100, 1000, 1099))

	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}

	if h.spans.Prev == nil || h.spans.Curr == nil {
		t.Fatal("expected both Prev and Curr to be set")
	}

	if h.spans.Curr.StartBlock > h.spans.Prev.EndBlock {
		t.Errorf("expected overlapping spans: curr.StartBlock (%d) <= prev.EndBlock (%d)",
			h.spans.Curr.StartBlock, h.spans.Prev.EndBlock)
	}
}

func TestRefreshSpan_WalksGapToLatest(t *testing.T) {
	// When the latest span is ahead by multiple IDs, a single refresh walks the
	// whole gap up to the latest, publishing each consecutive pair so overlap
	// detection sees the full sequence.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/latest": newSpan(103, 1300, 1399),
		"/bor/spans/101":    newSpan(101, 1100, 1199),
		"/bor/spans/102":    newSpan(102, 1200, 1299),
		"/bor/spans/103":    newSpan(103, 1300, 1399),
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(100, 1000, 1099))

	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}

	// One refresh advances all the way to the latest span.
	if h.spans.Curr.ID != 103 {
		t.Errorf("expected walk to latest span 103, got %d", h.spans.Curr.ID)
	}
	if h.spans.Prev == nil || h.spans.Prev.ID != 102 {
		t.Errorf("expected Prev to be 102, got %v", h.spans.Prev)
	}

	// Every consecutive pair is published: 100->101, 101->102, 102->103.
	wantPrev := []uint64{100, 101, 102}
	wantCurr := []uint64{101, 102, 103}
	if len(h.spanUpdates) != len(wantCurr) {
		t.Fatalf("expected %d published span pairs, got %d", len(wantCurr), len(h.spanUpdates))
	}
	for i, s := range h.spanUpdates {
		if s.Prev == nil || s.Prev.ID != wantPrev[i] || s.Curr == nil || s.Curr.ID != wantCurr[i] {
			t.Errorf("pair %d: got Prev/Curr %v/%v, want %d/%d", i, s.Prev, s.Curr, wantPrev[i], wantCurr[i])
		}
	}

	// A subsequent refresh with no new span leaves Curr unchanged and publishes
	// nothing (so the observer can't re-count the same overlap on idle cycles).
	prevCurr := h.spans.Curr
	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}
	if h.spans.Curr != prevCurr {
		t.Error("expected no change when already at latest span")
	}
	if len(h.spanUpdates) != 0 {
		t.Errorf("expected no span updates on an idle cycle, got %d", len(h.spanUpdates))
	}
}

func TestRefreshMilestone_ResumesAfterDeadline(t *testing.T) {
	// Backfill 6..15; the context is cancelled while fetching milestone 9. The
	// cursor advances only over the milestones we actually processed (6,7,8), so
	// the truncated catch-up resumes from 9 next cycle rather than skipping a gap.
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	const tip = 15
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.URL.Path == "/milestones/count":
			json.NewEncoder(w).Encode(observer.HeimdallMilestoneCount{Count: tip})
		case r.URL.Path == "/milestones/latest":
			json.NewEncoder(w).Encode(observer.HeimdallMilestoneV2{
				Milestone: observer.HeimdallMilestone{Timestamp: 1000},
			})
		case strings.HasSuffix(r.URL.Path, "/milestones/9"):
			// Simulate the cycle deadline tripping mid-fetch.
			cancel()
			http.Error(w, "deadline", http.StatusInternalServerError)
		default: // per-milestone backfill
			json.NewEncoder(w).Encode(observer.HeimdallMilestoneV2{
				Milestone: observer.HeimdallMilestone{Timestamp: 1000},
			})
		}
	}))
	defer server.Close()

	h := &HeimdallProvider{
		heimdallURL:        server.URL,
		logger:             NewLogger(nil, "test"),
		prevMilestoneCount: 5,
	}

	if err := h.refreshMilestone(ctx, 0); err != nil {
		t.Fatalf("refreshMilestone() error: %v", err)
	}

	// Cursor resumes at the last processed milestone (8), not the tip.
	if h.prevMilestoneCount != 8 {
		t.Errorf("expected cursor to resume at 8, got %d", h.prevMilestoneCount)
	}
	if len(h.milestones) != 3 {
		t.Errorf("expected 3 milestones processed (6,7,8), got %d", len(h.milestones))
	}
}

func TestRefreshMilestone_SkipsUnfetchableMilestone(t *testing.T) {
	// Milestone 8 always fails (e.g. pruned/404) without a cancelled context. It
	// must be skipped so the milestones behind it still process and the cursor
	// reaches the tip, rather than stalling the whole backlog every cycle.
	const tip = 10
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.URL.Path == "/milestones/count":
			json.NewEncoder(w).Encode(observer.HeimdallMilestoneCount{Count: tip})
		case r.URL.Path == "/milestones/latest":
			json.NewEncoder(w).Encode(observer.HeimdallMilestoneV2{
				Milestone: observer.HeimdallMilestone{Timestamp: 1000},
			})
		case strings.HasSuffix(r.URL.Path, "/milestones/8"):
			http.Error(w, "not found", http.StatusNotFound)
		default:
			json.NewEncoder(w).Encode(observer.HeimdallMilestoneV2{
				Milestone: observer.HeimdallMilestone{Timestamp: 1000},
			})
		}
	}))
	defer server.Close()

	h := &HeimdallProvider{
		heimdallURL:        server.URL,
		logger:             NewLogger(nil, "test"),
		prevMilestoneCount: 5,
	}

	if err := h.refreshMilestone(context.Background(), 0); err != nil {
		t.Fatalf("refreshMilestone() error: %v", err)
	}

	// 8 is skipped, but the cursor still reaches the tip and 6, 7, 9, 10 process.
	if h.prevMilestoneCount != tip {
		t.Errorf("expected cursor to reach tip %d, got %d", tip, h.prevMilestoneCount)
	}
	if len(h.milestones) != 4 {
		t.Errorf("expected 4 milestones processed (6,7,9,10), got %d", len(h.milestones))
	}
}

func TestFetchSpan_RejectsZeroValueSpan(t *testing.T) {
	// Server returns a zero-value span (simulating error envelope decoding to zero struct)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(observer.HeimdallSpanV2{
			Span: observer.HeimdallSpan{ID: 0, StartBlock: 0, EndBlock: 0},
		})
	}))
	defer server.Close()

	h := newProvider(server.URL, nil)
	_, err := h.fetchSpan(context.Background(), "latest")

	if err == nil {
		t.Fatal("expected error for zero-value span, got nil")
	}

	if !errors.Is(err, ErrInvalidSpan) {
		t.Errorf("expected ErrInvalidSpan, got: %v", err)
	}
}

func TestFetchSpan_AcceptsValidSpanZero(t *testing.T) {
	// Span 0 is valid on mainnet; it has StartBlock=0 but EndBlock > 0
	span0 := newSpan(0, 0, 255)
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/0": span0,
	})
	defer server.Close()

	h := newProvider(server.URL, nil)
	span, err := h.fetchSpan(context.Background(), "0")

	if err != nil {
		t.Fatalf("expected no error for valid span 0, got: %v", err)
	}

	if span.ID != 0 {
		t.Errorf("expected span ID 0, got %d", span.ID)
	}
	if span.EndBlock != 255 {
		t.Errorf("expected EndBlock 255, got %d", span.EndBlock)
	}
}

func TestRefreshSpan_LargeLagWalksAll(t *testing.T) {
	// With no lag cap, even a large gap walks every span (no jump), like
	// refreshMilestone's backlog. Span N covers [N*100, N*100+99].
	spans := map[string]*observer.HeimdallSpan{
		"/bor/spans/latest": newSpan(112, 11200, 11299),
	}
	for id := uint64(101); id <= 112; id++ {
		spans[fmt.Sprintf("/bor/spans/%d", id)] = newSpan(id, id*100, id*100+99)
	}
	server := newSpanServer(t, spans)
	defer server.Close()

	// Current span is 100, latest is 112, lag = 12.
	h := newProvider(server.URL, newSpan(100, 10000, 10099))

	if err := h.refreshSpan(context.Background()); err != nil {
		t.Fatalf("refreshSpan() error: %v", err)
	}

	if h.spans.Curr.ID != 112 {
		t.Errorf("expected walk to latest span 112, got %d", h.spans.Curr.ID)
	}
	if h.spans.Prev == nil || h.spans.Prev.ID != 111 {
		t.Errorf("expected Prev to be 111, got %v", h.spans.Prev)
	}
	if len(h.spanUpdates) != 12 {
		t.Errorf("expected 12 published span pairs, got %d", len(h.spanUpdates))
	}
}

func TestResolveActiveSpan_CurrentContainsBlock(t *testing.T) {
	// The block is inside the tracked current span, so no fetch is needed.
	h := newProvider("", newSpan(100, 1000, 1099))

	got := h.resolveActiveSpan(context.Background(), 1050)
	if got == nil || got.ID != 100 {
		t.Fatalf("expected active span 100, got %v", got)
	}
}

func TestResolveActiveSpan_PreemptiveLatestSpan(t *testing.T) {
	// The current span (101) was created preemptively: the chain is still in
	// span 100, before span 101's start block. The active span must be 100.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/100": newSpan(100, 1000, 1099),
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(101, 1100, 1199))

	got := h.resolveActiveSpan(context.Background(), 1050)
	if got == nil || got.ID != 100 {
		t.Fatalf("expected active span 100, got %v", got)
	}
}

func TestResolveActiveSpan_UsesPrevWithoutFetch(t *testing.T) {
	// Prev already contains the block, so no span should be fetched (the server
	// 404s on any request).
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{})
	defer server.Close()

	h := newProvider(server.URL, newSpan(101, 1100, 1199))
	h.spans.Prev = newSpan(100, 1000, 1099)

	got := h.resolveActiveSpan(context.Background(), 1050)
	if got == nil || got.ID != 100 {
		t.Fatalf("expected active span 100 from Prev, got %v", got)
	}
}

func TestResolveActiveSpan_CacheHit(t *testing.T) {
	// The cursor from a prior cycle still contains the block, so no fetch occurs.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{})
	defer server.Close()

	h := newProvider(server.URL, newSpan(101, 1100, 1199))
	h.spanCursor = newSpan(100, 1000, 1099)

	got := h.resolveActiveSpan(context.Background(), 1050)
	if got == nil || got.ID != 100 {
		t.Fatalf("expected cached active span 100, got %v", got)
	}
}

func TestResolveActiveSpan_WalksForwardIntoUntrackedSpan(t *testing.T) {
	// The chain advanced past the cursor into a span that is neither Curr nor
	// Prev; the resolver walks forward to it.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/101": newSpan(101, 1010, 1019),
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(103, 1030, 1039)) // Curr is ahead
	h.spanCursor = newSpan(100, 1000, 1009)                // block was here last cycle

	got := h.resolveActiveSpan(context.Background(), 1015) // now in span 101
	if got == nil || got.ID != 101 {
		t.Fatalf("expected active span 101, got %v", got)
	}
}

func TestResolveActiveSpan_WalksDeepPreemption(t *testing.T) {
	// The active span sits 5 spans below a preemptive Curr. Resolution walks all
	// the way down (no lag cap) to reach it.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/104": newSpan(104, 1040, 1049),
		"/bor/spans/103": newSpan(103, 1030, 1039),
		"/bor/spans/102": newSpan(102, 1020, 1029),
		"/bor/spans/101": newSpan(101, 1010, 1019),
		"/bor/spans/100": newSpan(100, 1000, 1009),
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(105, 1050, 1059))

	got := h.resolveActiveSpan(context.Background(), 1005)
	if got == nil || got.ID != 100 {
		t.Fatalf("expected active span 100, got %v", got)
	}
}

func TestResolveActiveSpan_SeedsFromNearestKnownSpan(t *testing.T) {
	// A stale low cursor and a much-closer Curr: resolution must seed from Curr
	// and step down one span, not climb from the stale cursor. (Climbing from 50
	// would fetch 51.. which the server doesn't have, yielding nil.)
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/99": newSpan(99, 9900, 9999),
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(100, 10000, 10099)) // Curr just above block
	h.spanCursor = newSpan(50, 5000, 5099)                   // stale, far below

	got := h.resolveActiveSpan(context.Background(), 9995)
	if got == nil || got.ID != 99 {
		t.Fatalf("expected active span 99 resolved from Curr, got %v", got)
	}
}

func TestResolveActiveSpan_DoesNotFetchAboveLatest(t *testing.T) {
	// The block is beyond the latest committed span (Curr); resolution must not
	// fetch a not-yet-created span. The empty server would 404 any fetch.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{})
	defer server.Close()

	h := newProvider(server.URL, newSpan(100, 10000, 10099))

	if got := h.resolveActiveSpan(context.Background(), 10150); got != nil {
		t.Fatalf("expected nil for block beyond the latest span, got %v", got)
	}
}

func TestResolveActiveSpan_BlockInGapReturnsNil(t *testing.T) {
	// Block 1050 falls in a gap: below the current span (101) start, above
	// span 100's start, and inside neither span 100 nor 99.
	server := newSpanServer(t, map[string]*observer.HeimdallSpan{
		"/bor/spans/100": newSpan(100, 1060, 1099),
		"/bor/spans/99":  newSpan(99, 1000, 1049),
	})
	defer server.Close()

	h := newProvider(server.URL, newSpan(101, 1100, 1199))

	if got := h.resolveActiveSpan(context.Background(), 1050); got != nil {
		t.Fatalf("expected nil for block in gap, got %v", got)
	}
}

func TestRefreshActiveSpan_ResolvesFromBorHeight(t *testing.T) {
	// The Bor RPC provider reports a height inside the current span, so the
	// active span resolves to it without any HTTP fetch.
	h := newProvider("", newSpan(100, 1000, 1099))
	h.borProviders = []*RPCProvider{{blockNumber: 1050}}

	h.refreshActiveSpan(context.Background())

	if h.activeSpan == nil || h.activeSpan.ID != 100 {
		t.Fatalf("expected active span 100, got %v", h.activeSpan)
	}
}

func TestRefreshActiveSpan_UsesMaxHeightAcrossProviders(t *testing.T) {
	// One provider lags (height 500, before the span); the healthy one is at
	// 1050. The max wins, resolving the active span without a fetch. (The lower
	// height would fall before the span and trigger a walk-back that fails
	// against the empty server, so this only passes if the max is used.)
	h := newProvider("", newSpan(100, 1000, 1099))
	h.borProviders = []*RPCProvider{{blockNumber: 500}, {blockNumber: 1050}}

	h.refreshActiveSpan(context.Background())

	if h.activeSpan == nil || h.activeSpan.ID != 100 {
		t.Fatalf("expected active span 100 from max height, got %v", h.activeSpan)
	}
}

func TestRefreshActiveSpan_NoBorProvider(t *testing.T) {
	// Without an RPC provider for this network the active span is unknown.
	h := newProvider("", newSpan(100, 1000, 1099))
	h.activeSpan = newSpan(100, 1000, 1099) // stale value from a prior cycle

	h.refreshActiveSpan(context.Background())

	if h.activeSpan != nil {
		t.Fatalf("expected nil active span without a Bor provider, got %v", h.activeSpan)
	}
}

func TestRefreshActiveSpan_HeightUnavailable(t *testing.T) {
	// The RPC provider exists but has not fetched a block yet (height 0).
	h := newProvider("", newSpan(100, 1000, 1099))
	h.borProviders = []*RPCProvider{{blockNumber: 0}}
	h.activeSpan = newSpan(100, 1000, 1099) // stale value from a prior cycle

	h.refreshActiveSpan(context.Background())

	if h.activeSpan != nil {
		t.Fatalf("expected nil active span when height unavailable, got %v", h.activeSpan)
	}
}

func TestRefreshMissedCheckpointProposal_NoCheckpointYet(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `{"checkpoint":{"proposer":"0xabc"}}`)
	}))
	defer server.Close()

	h := newProvider(server.URL, nil)
	h.checkpointProposers = orderedmap.New[string, struct{}]()

	// h.checkpoint is nil, e.g. a fresh chain where /checkpoints/latest 500s
	// with "checkpoint not found".
	if err := h.refreshMissedCheckpointProposal(context.Background()); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if _, ok := h.checkpointProposers.Get("0xabc"); !ok {
		t.Fatal("expected current proposer to be recorded")
	}
	if h.missedCheckpointProposers != nil {
		t.Fatalf("expected no missed proposers, got %v", h.missedCheckpointProposers)
	}
}

// newHeightRecorder serves /block and records each request's height. Responses
// are deliberately unusable: fillRange breaks on the first failed fetch, and the
// first height it asks for is what these tests assert on.
func newHeightRecorder(t *testing.T) (*httptest.Server, *[]string) {
	t.Helper()

	var heights []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		heights = append(heights, r.URL.Query().Get("height"))
		http.NotFound(w, r)
	}))
	t.Cleanup(srv.Close)

	return srv, &heights
}

func newFillProvider(serverURL string, blockNumber uint64) *HeimdallProvider {
	return &HeimdallProvider{
		tendermintURL: serverURL,
		blockNumber:   blockNumber,
		logger:        NewLogger(nil, "test"),
	}
}

// A range spanning hundreds of blocks must skip to the newest window rather
// than fetch blocks that get evicted unread.
func TestFillRange_ClampsToBufferCapacity(t *testing.T) {
	srv, heights := newHeightRecorder(t)

	const latest = 51062264
	h := newFillProvider(srv.URL, latest)
	h.fillRange(context.Background(), latest-330)

	if len(*heights) == 0 {
		t.Fatal("expected at least one block request")
	}

	want := fmt.Sprint(uint64(latest) - (heimdallBlockBufferSize - 1))
	if got := (*heights)[0]; got != want {
		t.Fatalf("first requested height = %s, want %s (clamped to the newest window)", got, want)
	}
}

// A range that fits in the buffer must not be clamped.
func TestFillRange_SmallRangeUnchanged(t *testing.T) {
	srv, heights := newHeightRecorder(t)

	const latest = 1000
	h := newFillProvider(srv.URL, latest)
	h.fillRange(context.Background(), latest-5)

	if len(*heights) == 0 {
		t.Fatal("expected at least one block request")
	}
	if got, want := (*heights)[0], fmt.Sprint(latest-5); got != want {
		t.Fatalf("first requested height = %s, want %s (unclamped)", got, want)
	}
}

// A node reporting a height below the last one seen must not underflow the
// range into a huge fetch loop.
func TestFillRange_StartAboveLatestFetchesNothing(t *testing.T) {
	srv, heights := newHeightRecorder(t)

	h := newFillProvider(srv.URL, 1000)
	h.fillRange(context.Background(), 1200)

	if len(*heights) != 0 {
		t.Fatalf("expected no requests when start exceeds latest, got %v", *heights)
	}
}
