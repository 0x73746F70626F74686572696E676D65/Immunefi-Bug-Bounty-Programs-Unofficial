// Package config handles application configuration by loading values from files
// and environment variables.
package config

import (
	"flag"
	"os"
	"reflect"
	"strings"
	"time"

	"github.com/go-playground/validator/v10"
	"github.com/mitchellh/mapstructure"
	"github.com/spf13/viper"
)

const DefaultBlockLookBack uint64 = 1000

// DefaultAccountBalanceBatchSize is the number of balance lookups packed into a
// single JSON-RPC batch when a provider does not override it. 1000 is the
// practical maximum some gateways accept; providers whose gateway times out on
// large batches should set a lower account_balance_batch_size.
const DefaultAccountBalanceBatchSize uint64 = 1000

// DefaultAccountBalanceTimeout bounds how long the account-balance fetch may run
// per refresh cycle when a provider does not override it. It stops a slow or
// unresponsive gateway from stalling the rest of RefreshState. A healthy sweep
// of ~2000 accounts takes a few seconds, so 10s leaves ample headroom while
// staying well under a typical poll interval.
const DefaultAccountBalanceTimeout = 10 * time.Second

// DefaultFeeBalanceInterval is how often the Heimdall fee balance sweep runs
// when an endpoint does not override it. Heimdall charges a flat fee per
// transaction (0.001 POL on mainnet), so even a busy validator moves its
// balance by a few POL per day -- five minutes is far finer than the signal.
const DefaultFeeBalanceInterval = 5 * time.Minute

// DefaultFeeBalanceTimeout bounds one sweep when an endpoint does not override
// it. A healthy sweep of the ~100 PoS validators takes a couple of seconds, so
// 30s leaves headroom without letting a degraded API starve RefreshState.
const DefaultFeeBalanceTimeout = 30 * time.Second

// Runner configures the execution interval of the job system.
type Runner struct {
	Interval *time.Duration `mapstructure:"interval" validate:"required"`
}

// Providers encloses the different providers configurations. Providers are
// responsible for fetching data.
type Providers struct {
	RPCs                   []RPC                     `mapstructure:"rpc" validate:"dive"`
	HeimdallEndpoints      []HeimdallEndpoint        `mapstructure:"heimdall" validate:"dive"`
	SensorNetworks         []SensorNetwork           `mapstructure:"sensor_network" validate:"dive"`
	SensorNetworksCH       []SensorNetworkClickHouse `mapstructure:"sensor_network_clickhouse" validate:"dive"`
	SuccinctProverNetworks []SuccinctProverNetwork   `mapstructure:"succinct_prover_network" validate:"dive"`
	Aggchains              []Aggchain                `mapstructure:"aggchain" validate:"dive"`
	Grafana                []Grafana                 `mapstructure:"grafana" validate:"dive"`
	HashDivergence         *HashDivergence           `mapstructure:"hash_divergence"`
	System                 *System                   `mapstructure:"system"`
	ExchangeRates          *ExchangeRates            `mapstructure:"exchange_rates"`
}

// Account defines an account to monitor with an optional tag.
type Account struct {
	Address string `mapstructure:"address" validate:"required"`
	Tag     string `mapstructure:"tag"`
	// TrackBalances overrides ExcludeBalanceTags for this account.
	TrackBalances *bool `mapstructure:"track_balances"`
}

// RPC defines the various RPC providers that will be monitored.
type RPC struct {
	Name                    string         `mapstructure:"name" validate:"required"`
	URL                     string         `mapstructure:"url" validate:"url,required"`
	Label                   string         `mapstructure:"label" validate:"required"`
	Interval                *time.Duration `mapstructure:"interval"`
	Contracts               Contracts      `mapstructure:"contracts"`
	TimeToMine              *TimeToMine    `mapstructure:"time_to_mine"`
	Accounts                []Account      `mapstructure:"accounts"`
	ExcludeBalanceTags      []string       `mapstructure:"exclude_balance_tags"`
	BlockLookBack           *uint64        `mapstructure:"block_look_back"`
	AccountBalanceBatchSize *uint64        `mapstructure:"account_balance_batch_size" validate:"omitempty,gt=0"`
	AccountBalanceTimeout   *time.Duration `mapstructure:"account_balance_timeout" validate:"omitempty,gt=0"`
	TxPool                  bool           `mapstructure:"txpool"`
	Observers               *Observers     `mapstructure:"observers"`
	ValidatorBalances       *bool          `mapstructure:"validator_balances"`
	MissedProposals         *bool          `mapstructure:"missed_proposals"`
}

// Contracts maps specific contracts to their addresses. This is used to
// fetch on-chain data from these contracts.
type Contracts struct {
	// PoS
	StateSyncSenderAddress   *string `mapstructure:"state_sync_sender_address"`
	StateSyncReceiverAddress *string `mapstructure:"state_sync_receiver_address"`
	CheckpointAddress        *string `mapstructure:"checkpoint_address"`
	StakeManagerAddress      *string `mapstructure:"stake_manager_address"`
	SPOLControllerAddress    *string `mapstructure:"spol_controller_address"`

	// zkEVM
	GlobalExitRootL2Address *string       `mapstructure:"global_exit_root_l2_address"`
	ZkEVMBridgeAddress      *string       `mapstructure:"zkevm_bridge_address"`
	RollupManagerAddress    *string       `mapstructure:"rollup_manager_address"`
	RollupManager           RollupManager `mapstructure:"rollup_manager"`
}

// RollupManager defines the configuration for managing a set of rollups.
type RollupManager struct {
	Rollups  map[uint32]Rollup `mapstructure:"rollups"`
	Enabled  []uint32          `mapstructure:"enabled"`
	Disabled []uint32          `mapstructure:"disabled"`
}

// Rollup represents the configuration for a single rollup. Every field of the
// `RPC` provider can be overridden here.
type Rollup struct {
	RPC   `mapstructure:",squash"`
	Name  *string `mapstructure:"name"`
	URL   *string `mapstructure:"url" validate:"url"`
	Label *string `mapstructure:"label"`
}

// TimeToMine configures the time to mine provider. This periodically sends
// transactions on the network and records how long they took to be recorded in
// a block.
type TimeToMine struct {
	Sender           string  `mapstructure:"sender" validate:"required"`
	SenderPrivateKey string  `mapstructure:"sender_private_key" validate:"required"`
	Receiver         string  `mapstructure:"receiver" validate:"required"`
	Value            int64   `mapstructure:"value" validate:"required"`
	Data             string  `mapstructure:"data"`
	GasPriceFactor   int64   `mapstructure:"gas_price_factor"`
	GasLimit         uint64  `mapstructure:"gas_limit" validate:"required"`
	SendMethod       *string `mapstructure:"send_method"`
}

// HashDivergence configures the hash divergence provider. This tracks whether
// blocks with the same block number have different hashes.
type HashDivergence struct {
	Interval *time.Duration `mapstructure:"interval"`
}

// System configures the system provider. This keeps system diagnostic metrics
// such as uptime.
type System struct {
	Interval *time.Duration `mapstructure:"interval"`
}

// ExchangeRates configures the exchange rates provider. This fetches exchange
// rate data from the Coinbase API.
type ExchangeRates struct {
	CoinbaseURL string              `mapstructure:"coinbase_url" validate:"required"`
	Tokens      map[string][]string `mapstructure:"tokens"`
	Interval    *time.Duration      `mapstructure:"interval"`
}

// HeimdallEndpoint configures the heimdall provider. This provider fetches data
// from the consensus layer endpoints for Polygon PoS chains.
type HeimdallEndpoint struct {
	Name          string         `mapstructure:"name" validate:"required"`
	TendermintURL string         `mapstructure:"tendermint_url" validate:"url,required"`
	HeimdallURL   string         `mapstructure:"heimdall_url" validate:"url,required"`
	Label         string         `mapstructure:"label" validate:"required"`
	Interval      *time.Duration `mapstructure:"interval"`

	// FeeBalances enables the per-validator Heimdall fee balance sweep. Nil
	// means enabled.
	FeeBalances *bool `mapstructure:"fee_balances"`
	// FeeBalanceInterval is how often the sweep runs, deliberately decoupled
	// from Interval: it costs one request per validator, for balances that
	// drain by a flat per-transaction fee.
	FeeBalanceInterval *time.Duration `mapstructure:"fee_balance_interval" validate:"omitempty,gt=0"`
	// FeeBalanceTimeout bounds one sweep, keeping a slow Heimdall API from
	// spending the cycle deadline here and starving the steps that follow.
	FeeBalanceTimeout *time.Duration `mapstructure:"fee_balance_timeout" validate:"omitempty,gt=0"`
}

// SensorNetwork configures the sensor network provider. This fetches data from
// GCP Datastore where the sensors write their data.
type SensorNetwork struct {
	Name    string `mapstructure:"name" validate:"required"`
	Label   string `mapstructure:"label" validate:"required"`
	Project string `mapstructure:"project" validate:"required"`
	// Database is the GCP Datastore database ID.
	Database string         `mapstructure:"database"`
	Interval *time.Duration `mapstructure:"interval"`
}

// SensorNetworkClickHouse configures the ClickHouse-backed sensor network
// provider. It reads the same sensor data as SensorNetwork but from ClickHouse
// instead of GCP Datastore.
type SensorNetworkClickHouse struct {
	Name  string `mapstructure:"name" validate:"required"`
	Label string `mapstructure:"label" validate:"required"`
	// DSN addresses the ClickHouse server, e.g.
	// clickhouse://analytics:pass@host:9000/sensor.
	DSN      string         `mapstructure:"dsn" validate:"required"`
	Interval *time.Duration `mapstructure:"interval"`
}

// SuccinctProverNetwork configures the succinct prover provider. This fetches
// data from the Succinct Prover Network.
type SuccinctProverNetwork struct {
	Name      string         `mapstructure:"name" validate:"required"`
	URL       string         `mapstructure:"url" validate:"url,required"`
	APIKey    string         `mapstructure:"api_key" validate:"required"`
	Label     string         `mapstructure:"label" validate:"required"`
	Interval  *time.Duration `mapstructure:"interval"`
	Requester *string        `mapstructure:"requester"`
	Fulfiller *string        `mapstructure:"fulfiller"`
	// UsageRequesters are the requesters to report hourly gas usage for. This
	// is deliberately separate from Requester: that field filters which proof
	// requests are observed, whereas usage is billing-scoped and the addresses
	// holding a gas budget need not be ones a configured fulfiller serves.
	UsageRequesters []UsageRequester `mapstructure:"usage_requesters" validate:"dive"`
}

// UsageRequester is a requester whose hourly gas usage is reported.
type UsageRequester struct {
	Address string `mapstructure:"address" validate:"required"`
	// Tag is a human-readable name for the requester, carried as a metric
	// label so a dashboard does not have to map addresses back to the systems
	// that own them by hand.
	Tag string `mapstructure:"tag"`
}

type Aggchain struct {
	Name          string         `mapstructure:"name" validate:"required"`
	L1URL         string         `mapstructure:"l1_url" validate:"url,required"`
	L2URL         string         `mapstructure:"l2_url" validate:"url,required"`
	Label         string         `mapstructure:"label" validate:"required"`
	Interval      *time.Duration `mapstructure:"interval"`
	RollupAddress string         `mapstructure:"rollup_address" validate:"required"`
}

type Grafana struct {
	Name     string         `mapstructure:"name" validate:"required"`
	URL      string         `mapstructure:"url" validate:"url,required"`
	Label    string         `mapstructure:"label" validate:"required"`
	Interval *time.Duration `mapstructure:"interval"`
}

// Observers defines which observers should be enabled or disabled. Observers
// are responsible for emitting the Prometheus metrics.
type Observers struct {
	Enabled  []string `mapstructure:"enabled"`
	Disabled []string `mapstructure:"disabled"`
}

// HTTP defines the properties that used for exposing metrics.
type HTTP struct {
	PromPort  int    `mapstructure:"port" validate:"required"`
	PprofPort int    `mapstructure:"pprof_port" validate:"required"`
	Address   string `mapstructure:"address" validate:"required"`
	Path      string `mapstructure:"path" validate:"required"`
}

// Network defines metadata about a blockchain network.
type Network struct {
	Name         string `mapstructure:"name" validate:"required"`
	ChainID      uint64 `mapstructure:"chain_id"`
	PolygonPoS   bool   `mapstructure:"polygon_pos"`
	PolygonZkEVM bool   `mapstructure:"polygon_zkevm"`
}

// GetName returns the network name.
func (n Network) GetName() string {
	return n.Name
}

// GetChainID returns the network chain ID.
func (n Network) GetChainID() uint64 {
	return n.ChainID
}

// IsPolygonPoS returns if this is a Polygon PoS chain.
func (n Network) IsPolygonPoS() bool {
	return n.PolygonPoS
}

// IsPolygonZkEVM returns if the network is a Polygon zkEVM chain.
func (n Network) IsPolygonZkEVM() bool {
	return n.PolygonZkEVM
}

// Logs configures logging format and verbosity options.
type Logs struct {
	Pretty    bool   `mapstructure:"pretty"`
	Verbosity string `mapstructure:"verbosity"`
}

type config struct {
	Namespace string    `mapstructure:"namespace" validate:"required"`
	Runner    Runner    `mapstructure:"runner"`
	HTTP      HTTP      `mapstructure:"http"`
	Providers Providers `mapstructure:"providers"`
	Observers Observers `mapstructure:"observers"`
	Networks  []Network `mapstructure:"networks"`
	Logs      Logs      `mapstructure:"logs"`
}

var c *config

// Config returns the configuration. `Init()` should be called before this.
func Config() *config {
	return c
}

// expandEnvHookFunc expands environment variables when the viper is decoding
// into the `config` struct.
func expandEnvHookFunc() mapstructure.DecodeHookFunc {
	return func(f reflect.Type, t reflect.Type, data any) (any, error) {
		if f.Kind() == reflect.String && t.Kind() == reflect.String {
			return os.ExpandEnv(data.(string)), nil
		}
		return data, nil
	}
}

// Init initializes the config. This should be called before using `Config()`.
func Init() error {
	viper.SetConfigName("config")
	viper.AddConfigPath(".")
	viper.AddConfigPath("/etc/panoptichain/")

	if len(flag.Args()) > 0 {
		viper.SetConfigFile(flag.Args()[0])
	}

	viper.AutomaticEnv()
	viper.SetEnvPrefix("panoptichain")
	viper.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))

	viper.SetDefault("namespace", "panoptichain")
	viper.SetDefault("runner.interval", "30s")
	viper.SetDefault("http.port", 9090)
	viper.SetDefault("http.pprof_port", 6060)
	viper.SetDefault("http.address", "localhost")
	viper.SetDefault("http.path", "/metrics")
	viper.SetDefault("logs.pretty", false)
	viper.SetDefault("logs.verbosity", "info")

	if err := viper.ReadInConfig(); err != nil {
		return err
	}

	opts := viper.DecodeHook(
		mapstructure.ComposeDecodeHookFunc(
			expandEnvHookFunc(),
			mapstructure.StringToTimeDurationHookFunc(),
		),
	)

	if err := viper.Unmarshal(&c, opts); err != nil {
		return err
	}

	validate := validator.New()
	if err := validate.Struct(c); err != nil {
		return err
	}

	return nil
}
