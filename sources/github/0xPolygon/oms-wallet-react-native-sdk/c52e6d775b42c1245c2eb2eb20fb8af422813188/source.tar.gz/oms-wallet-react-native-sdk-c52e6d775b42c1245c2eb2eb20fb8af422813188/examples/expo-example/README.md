# OMS Expo Example

Expo development-build example for `@polygonlabs/oms-wallet-react-native`.

This app mirrors the SDK demo flow with email login, Google redirect login,
wallet selection, message signing, signature verification, and transaction
sending. It uses `expo-web-browser` for redirect auth and depends on the SDK
version declared in `package.json`.

This example is intentionally excluded from the root Yarn workspace. It is not
linked to the local SDK package, which keeps it useful as a consumer-style smoke
test for the published npm artifact.

## Run

Install dependencies from the repo root:

```sh
yarn expo-example:install
```

The install helper packs the local SDK and installs that tarball into this
example. To install the published npm package instead, run
`yarn expo-example:install:published`.

Build and launch a development build:

```sh
npm run ios
npm run android
```

Start Metro for an already-installed development build:

```sh
npm start
```

Native configuration is set through `app.json`. The generated `ios/` and
`android/` folders are intentionally ignored.

The `expo-build-properties` plugin enables UIKit scene support so the generated
iOS project can run when built with Xcode 27. Native projects remain generated
by Expo and should not be edited manually.
