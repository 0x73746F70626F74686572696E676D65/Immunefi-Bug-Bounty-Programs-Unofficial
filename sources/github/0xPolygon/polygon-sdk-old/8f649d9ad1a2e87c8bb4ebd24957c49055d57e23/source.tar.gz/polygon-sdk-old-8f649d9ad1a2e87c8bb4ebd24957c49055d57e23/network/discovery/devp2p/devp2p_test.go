package discv4

import (
	"crypto/elliptic"
	"io/ioutil"
	"net"
	"reflect"
	"strings"
	"testing"
	"time"

	"github.com/hashicorp/go-hclog"
	"github.com/stretchr/testify/assert"

	"github.com/0xPolygon/minimal/crypto"
	"github.com/0xPolygon/minimal/helper/hex"
)

func newTestDiscovery(t *testing.T, transport Transport, capturePacket bool) *Backend {
	logger := hclog.New(&hclog.LoggerOptions{
		Output: ioutil.Discard,
	})

	prv0, _ := crypto.GenerateKey()

	r, err := NewBackend(logger, prv0, transport)
	assert.NoError(t, err)

	if capturePacket {
		r.packetCh = make(chan *Packet, 10)
	}
	return r
}

func pipe(t *testing.T, capturePacket bool) (*Backend, *Backend) {
	network := newMockNetwork()

	d0 := newTestDiscovery(t, network.NewTransport(), capturePacket)
	d1 := newTestDiscovery(t, network.NewTransport(), capturePacket)

	return d0, d1
}

func TestPeerExpired(t *testing.T) {
	now := time.Now()

	var cases = []struct {
		Last    time.Time
		Now     time.Time
		Bond    time.Duration
		Expired bool
	}{
		{
			Last:    now.Add(1 * time.Second),
			Now:     now.Add(3 * time.Second),
			Bond:    1 * time.Second,
			Expired: true,
		},
		{
			Last:    now.Add(1 * time.Second),
			Now:     now.Add(3 * time.Second),
			Bond:    5 * time.Second,
			Expired: false,
		},
	}

	for _, cc := range cases {
		t.Run("", func(t *testing.T) {
			prv0, _ := crypto.GenerateKey()

			pub := &prv0.PublicKey
			id := hex.EncodeToHex(elliptic.Marshal(pub.Curve, pub.X, pub.Y)[1:])

			p, err := newPeer(id, nil, 0)
			if err != nil {
				t.Fatal(err)
			}

			p.Last = &cc.Last
			if p.hasExpired(cc.Now, cc.Bond) != cc.Expired {
				t.Fatal("bad")
			}
		})
	}
}

func TestExpiredPacket(t *testing.T) {
	r0, r1 := pipe(t, true)

	expiration := uint64(time.Now().Unix())

	r0.sendPacket(r1.local, pingPacket, &pingRequest{
		Version:    4,
		From:       r0.local.toRPCEndpoint(),
		To:         r1.local.toRPCEndpoint(),
		Expiration: expiration,
	})

	time.Sleep(50 * time.Millisecond)

	p := <-r1.packetCh

	err := r1.HandlePacket(p)
	if err == nil {
		t.Fatal("bad")
	}
	if err.Error() != "ping: Message has expired" {
		t.Fatal("bad2")
	}
}

func TestNotExpectedPacket(t *testing.T) {
	r0, r1 := pipe(t, true)

	r0.sendPacket(r1.local, pongPacket, &pongResponse{
		To:         r1.local.toRPCEndpoint(),
		ReplyTok:   []byte{},
		Expiration: uint64(time.Now().Add(20 * time.Second).Unix()),
	})

	p := <-r1.packetCh

	err := r1.HandlePacket(p)
	if err == nil {
		t.Fatal("error expected")
	}
	if !strings.HasPrefix(err.Error(), "pongPacket not expected") {
		t.Fatal(err)
	}
}

func TestPingPong(t *testing.T) {
	r0, r1 := pipe(t, true)

	r0.sendPacket(r1.local, pingPacket, &pingRequest{
		Version:    4,
		From:       r0.local.toRPCEndpoint(),
		To:         r1.local.toRPCEndpoint(),
		Expiration: uint64(time.Now().Add(10 * time.Second).Unix()),
	})

	p := <-r1.packetCh

	if err := r1.HandlePacket(p); err != nil {
		t.Fatal(err)
	}

	getPacket := func() byte {
		select {
		case p := <-r0.packetCh:
			_, sigdata, _, err := decodePacket(p.Buf)
			if err != nil {
				t.Fatal(err)
			}
			return sigdata[0]

		case <-time.After(100 * time.Millisecond):
			t.Fatal("timeout")
		}
		return 0
	}

	if getPacket() != pongPacket {
		t.Fatal("pong packet expected")
	}
	if getPacket() != pingPacket {
		t.Fatal("ping packet expected")
	}
}

func testProbeNode(t *testing.T, r0 *Backend, r1 *Backend) {
	// --- 0 probe starts ---

	// 0. send ping packet
	done := make(chan bool, 1)
	go func() {
		done <- r0.probeNode(r1.local)
	}()

	// 1. receive ping packet (send pong packet)
	p := <-r1.packetCh
	if err := r1.HandlePacket(p); err != nil {
		t.Fatal(err)
	}

	// 0. receive pong packet (finish 0. probe)
	p = <-r0.packetCh
	if err := r0.HandlePacket(p); err != nil {
		t.Fatal(err)
	}

	select {
	case ok := <-done:
		if !ok {
			t.Fatal("bad")
		}
	case <-time.After(500 * time.Millisecond):
		t.Fatal("timeout")
	}

	// r0 should have now r1 as a peer
	// time.Sleep(200 * time.Millisecond)

	peers := r0.GetPeers()
	if len(peers) != 1 {
		t.Fatalf("Expected one peer but found %d", len(peers))
	}

	if !reflect.DeepEqual(peers[0].UDPAddr, r1.addr) {
		t.Fatal("address of probe node is not the same")
	}
	if peers[0].Last.String() != p.Timestamp.String() {
		t.Fatal("timestamp of the peer is different")
	}

	// --- 1 probe starts ---

	// 0. receive ping packet
	p = <-r0.packetCh

	peer, err := decodePeerFromPacket(p)
	if err != nil {
		t.Fatal(err)
	}
	if peer.addr() != r1.local.addr() {
		t.Fatalf("address mismatch: expected %s but found %s", r1.local.addr(), peer.addr())
	}
	if r0.hasExpired(peer) == true {
		t.Fatal("peer should not have expired")
	}

	if err := r0.HandlePacket(p); err != nil {
		t.Fatal(err)
	}

	// the timestamp of the peer should be updated
	peer1, ok := r0.getPeer(peer.ID)
	if !ok {
		t.Fatalf("peer %s not found after probe", peer.ID)
	}
	if peer1.Last.String() != p.Timestamp.String() {
		t.Fatal("timestamp of the peer has not been updated")
	}

	// 1.receive pong packet
	p = <-r1.packetCh
	if err := r1.HandlePacket(p); err != nil {
		t.Fatal(err)
	}

	peer, err = decodePeerFromPacket(p)
	if err != nil {
		t.Fatal(err)
	}

	// Since the probeNode in r1 has been spawn in parallel
	// we need to wait for the HandlePacket callback to update
	// the probe and add the peer
	time.Sleep(100 * time.Millisecond)

	// the timestamp of the peer should be updated
	peer1, ok = r1.getPeer(peer.ID)
	if !ok {
		t.Fatalf("peer %s not found after probe", peer.ID)
	}
	if peer1.Last.String() != p.Timestamp.String() {
		t.Fatal("timestamp of the peer has not been updated")
	}
}

func TestProbeNode(t *testing.T) {
	r0, r1 := pipe(t, true)
	testProbeNode(t, r0, r1)
}

func TestFindNodeWithUnavailableNode(t *testing.T) {
	t.Skip()

	r0, r1 := pipe(t, true)

	testProbeNode(t, r0, r1)
	r0.packetCh, r1.packetCh = nil, nil

	r0.Schedule()
	r1.Close()

	_, err := r0.findNodes(r1.local, r0.local.Bytes)
	if err == nil {
		t.Fatal("it should fail")
	}
	if err.Error() != "failed to get peers" {
		t.Fatalf("bad error message: %v", err)
	}
}

func TestFindNode(t *testing.T) {
	t.Skip()

	var cases = []int{1, 5, 10, 15, 20, 30, 50}

	for _, cc := range cases {
		t.Run("", func(t *testing.T) {
			r0, r1 := pipe(t, true)

			testProbeNode(t, r0, r1)
			r0.packetCh, r1.packetCh = nil, nil

			// r1. populate the buckets
			for i := 0; i < cc; i++ {
				prv, _ := crypto.GenerateKey()
				pub := &prv.PublicKey
				id := hex.EncodeToHex(elliptic.Marshal(pub.Curve, pub.X, pub.Y)[1:])

				addr := &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: 12345}
				p, err := newPeer(id, addr, 0)
				if err != nil {
					t.Fatal(err)
				}

				r1.updatePeer(p)
			}

			nodes, err := r0.findNodes(r1.local, r0.local.Bytes)
			if err != nil {
				t.Fatal(err)
			}
			expected, err := r1.NearestPeersFromTarget(r0.local.Bytes)
			if err != nil {
				t.Fatal(err)
			}

			if len(expected) != len(nodes) {
				t.Fatalf("length should be the same. Expected %d but found %d", len(expected), len(nodes))
			}
			for indx := range expected {
				if !reflect.DeepEqual(expected[indx].ID, nodes[indx].ID) {
					t.Fatalf("id not equal")
				}
			}
		})
	}
}
