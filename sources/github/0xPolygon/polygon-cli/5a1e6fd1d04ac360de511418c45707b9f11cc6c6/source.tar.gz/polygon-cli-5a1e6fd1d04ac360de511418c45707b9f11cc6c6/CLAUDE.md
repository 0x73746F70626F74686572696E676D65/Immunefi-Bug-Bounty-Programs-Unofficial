# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

polygon-cli is a Swiss Army knife of blockchain tools for building, testing, and running blockchain applications. It's a collection of utilities primarily focused on Polygon/Ethereum ecosystems.

## Architecture Overview

The project follows a command-based architecture using Cobra framework:

- **Main Entry**: `main.go` simply calls `cmd.Execute()`
- **Command Structure**: Each command is organized in its own package under `cmd/` (e.g., `cmd/loadtest/`, `cmd/monitor/`)
- **Subcommand Structure**: Subcommands should also be in their own package (e.g., `cmd/loadtest/uniswapv3/` for `polycli loadtest uniswapv3`)
- **Bindings**: Go bindings for smart contracts are in `bindings/` (generated from Solidity contracts in `contracts/`)
- **Utilities**: Common utilities are in `util/` package

Key architectural patterns:

- Commands are self-contained with their own usage documentation (`.md` files)
- Heavy use of code generation for documentation, protobuf, contract bindings, and RPC types
- Docker-based generation workflows to ensure consistency

## Common Development Commands

### Building and Installation

```bash
# Build the binary
make build

# Install to ~/go/bin/
make install

# Cross-compile for different platforms
make cross        # With CGO
make simplecross  # Without CGO
```

### Testing

```bash
# Run all tests with coverage
make test

# Run specific test
go test -v ./cmd/loadtest/...

# Run load test against local node
make geth          # Start local geth node
make geth-loadtest # Fund account and run load test
```

### Code Quality

```bash
# Run all linters (includes tidy, vet, golangci-lint)
make lint

# Individual linter commands
make tidy          # Clean up go.mod
make fmt           # Format code
make vet           # Run go vet and shadow
make golangci-lint # Run golangci-lint
```

### Code Generation

```bash
# Generate everything (docs, proto, bindings, etc.)
make gen

# Individual generation commands
make gen-doc              # Generate CLI documentation
make gen-proto            # Generate protobuf stubs
make gen-go-bindings      # Generate contract bindings
make gen-load-test-modes  # Generate loadtest mode strings
make gen-json-rpc-types   # Generate JSON RPC types
```

### Contract Development

```bash
# Work with smart contracts
cd contracts/
make build            # Build contracts with Foundry
make gen-go-bindings  # Generate Go bindings
```

## Adding New Features

When adding a new command:

1. Create a new package under `cmd/your-command/`
2. Add the command to `cmd/root.go` in the `NewPolycliCommand()` function
3. Create a usage documentation file (e.g., `yourCommandUsage.md`)
4. Run `make gen-doc` to update the main documentation
5. If adding a new loadtest mode, run `make gen-load-test-modes`

## CI/CD Considerations

The CI pipeline (`/.github/workflows/ci.yml`) runs:

- Linting (golangci-lint, shadow)
- Tests
- Generation checks (ensures all generated files are up-to-date)
- Load tests against both geth and anvil

Always run `make gen` before committing if you've changed anything that affects code generation.

## Key Dependencies

- Go 1.26+ required
- Foundry (for smart contract compilation)
- Docker (for generation tasks)
- Additional tools: jq, bc, protoc (for development)

## Environment Configuration

The tool supports configuration via:

- CLI flags (highest priority)
- Environment variables
- Config file (`~/.polygon-cli.yaml`)
- Viper is used for configuration management

## Logging

- Use zerolog for structured, performant logging throughout the project

## Development Guidelines

- Use conventional commit messages

## Development Memories

- Use `make build` to build polycli

## Code Quality Checklist

**CRITICAL**: Before writing any code, systematically check these categories to avoid rework:

### 0. Critical Thinking & Code Analysis (Meta-Level)

**MOST IMPORTANT**: Think critically before implementing any suggestion or requirement.

- **Analyze Existing Code First**: Before adding validation, checks, or features, thoroughly examine what already exists
- **Question Redundancy**: If validation already exists earlier in the call chain, don't add duplicate checks
- **Provide Feedback Before Implementation**: When a suggestion seems unnecessary or redundant, explain WHY rather than blindly implementing it
- **Consider Token Efficiency**: Rework wastes time and tokens. Get it right the first time by applying this entire checklist systematically
- **Defense-in-Depth vs Redundancy**:
  - Defense-in-depth = validating at system boundaries (user input, external APIs, different layers)
  - Redundancy = checking the same condition twice in the same function after it was already validated
  - Apply defense-in-depth, avoid redundancy
- **Evaluate Necessity**: Just because something CAN be added doesn't mean it SHOULD be. Ask: "Does this add value or just clutter?"

**Questions to ask before writing ANY code:**

1. "What validation/checks already exist in this call chain?"
2. "Is this truly adding safety, or is it redundant?"
3. "What value does this code provide?"
4. "Am I implementing this because it was suggested, or because it's actually needed?"

**Example of what NOT to do:**

```go
// Earlier in function (line 211)
if report.EndBlock == math.MaxUint64 {
    return fmt.Errorf("end block must be specified")
}

// ... code ...

// Later in same function (line 231) - REDUNDANT
if report.EndBlock == math.MaxUint64 {
    return fmt.Errorf("internal error: end block cannot be math.MaxUint64")
}
totalBlocks := report.EndBlock - report.StartBlock + 1
```

This is pure redundancy - if the value can't be MaxUint64 (validated at line 211), checking again at line 231 adds zero value.

### 1. Security

- **HTML/Template Injection**: Always use `html.EscapeString()` for any data interpolated into HTML, even if currently from trusted sources
- **Input Validation**: Validate all user inputs at boundaries (flags, API inputs)
- **SQL Injection**: Use parameterized queries, never string concatenation
- **Command Injection**: Never pass user input directly to shell commands
- **Question to ask**: "What data is untrusted? Where does it flow? Is it escaped/validated at every output point?"

### 2. Resource Management & Performance

- **Goroutine Lifecycle**: Every goroutine must have a clear termination condition via context cancellation
- **Timer Cleanup**: Use `time.NewTimer()` + `defer timer.Stop()`, never `time.After()` in select statements (causes goroutine leaks)
- **Channel Buffers**: Use small fixed buffers (e.g., `concurrency*2`), never proportional to total dataset size
- **Memory Allocation**: Consider behavior with 10x, 100x, 1000x expected input
- **Question to ask**: "How does every goroutine, timer, and channel clean up on cancellation? What's the memory footprint at scale?"

### 3. Context Propagation

- **Never create root contexts**: Always thread `context.Context` through call chains; never use `context.Background()` in the middle of operations
- **Cancellation Flow**: Context should flow through every I/O operation, long-running task, and goroutine
- **Timeout Management**: Create child contexts with `context.WithTimeout(parentCtx, duration)`, not `context.WithTimeout(context.Background(), duration)`
- **Question to ask**: "Does context flow through all long-running operations? Will Ctrl+C immediately stop everything?"

### 4. Data Integrity & Determinism

- **Completeness**: Data collection operations must fetch ALL requested data or fail entirely - never produce partial results
- **Retry Logic**: Failed operations should retry (with backoff) before failing
- **Idempotency**: Same input parameters should produce identical output every time
- **Validation**: Verify expected vs actual data counts; fail loudly if mismatched
- **Use Correct Data Source**: For blockchain data, prefer receipt fields over transaction fields (e.g., `effectiveGasPrice` from receipt works for both legacy and EIP-1559 txs, while `gasPrice` from transaction is missing in EIP-1559)
- **Question to ask**: "If I run this twice with the same parameters, will I get identical results? What makes this non-deterministic? Am I reading from the authoritative data source?"

### 5. Error Handling & Logging

- **Error Wrapping**: Use `fmt.Errorf("context: %w", err)` to wrap errors with context
- **Single-line Messages**: Put context before `%w` in single line: `fmt.Errorf("failed after %d attempts: %w", n, err)`
- **Failure Modes**: Consider and handle all failure paths explicitly
- **Logging Levels**: Use appropriate levels (Error for failures, Warn for retries, Info for progress)
- **Progress Accuracy**: Progress counters must reflect ALL completed work (successes + final failures), not just successes, or progress will appear stuck during retries
- **Question to ask**: "What can fail? How is each failure mode handled? Are errors properly wrapped? Is progress logging accurate during retries/failures?"

### 6. Concurrency Patterns

- **Channel Closing**: Close channels in the correct goroutine (usually the sender); use atomic counters to coordinate
- **Channel Draining**: When using select with multiple channels and one closes, drain remaining channels to avoid missing messages
- **Worker Pools**: Use `sync.WaitGroup` to wait for workers; protect shared state with mutexes or channels
- **Race Conditions**: Run with `-race` flag during testing
- **Goroutine Leaks**: Ensure every goroutine can exit on context cancellation
- **Question to ask**: "Who closes each channel? Can any goroutine block forever? Does this have race conditions? Are all channel messages guaranteed to be read?"

### 7. Testing & Validation

- **Test Coverage**: Write tests for edge cases, not just happy paths
- **Error Injection**: Test retry logic, failure modes, and error paths
- **Resource Limits**: Test with large inputs to verify scalability
- **Cancellation**: Test that context cancellation stops operations immediately
- **Documentation Consistency**: Ensure documentation accurately describes implementation behavior (e.g., "blocks are skipped" vs "command fails on errors")
- **Question to ask**: "What edge cases exist? How do I test failure modes? Does the documentation match what the code actually does?"

### Common Patterns to Apply by Default

```go
// ✅ DO: Timer cleanup
timer := time.NewTimer(500 * time.Millisecond)
defer timer.Stop()
select {
case <-timer.C:
case <-ctx.Done():
    return ctx.Err()
}

// ❌ DON'T: Timer leak
select {
case <-time.After(500 * time.Millisecond): // Leaks if ctx cancels first
case <-ctx.Done():
}

// ✅ DO: HTML escaping
html := fmt.Sprintf(`<div>%s</div>`, html.EscapeString(userInput))

// ❌ DON'T: HTML injection risk
html := fmt.Sprintf(`<div>%s</div>`, userInput)

// ✅ DO: Context propagation
func outputPDF(ctx context.Context, ...) error {
    timeoutCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
    defer cancel()
    ...
}

// ❌ DON'T: Context.Background in call chain
func outputPDF(...) error {
    ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
    ...
}

// ✅ DO: Deterministic data collection with retries
for attempt := 1; attempt <= maxRetries; attempt++ {
    if data, err := fetch(); err == nil {
        return data
    }
}
return fmt.Errorf("failed after %d attempts", maxRetries)

// ❌ DON'T: Skip failures (non-deterministic)
if data, err := fetch(); err != nil {
    log.Warn("skipping failed item")
    continue
}

// ✅ DO: Fixed channel buffer
ch := make(chan T, concurrency*2)

// ❌ DON'T: Buffer proportional to input size
ch := make(chan T, totalItems) // Can allocate GB of memory

// ✅ DO: Goroutine with cancellation
go func() {
    for {
        select {
        case <-ctx.Done():
            return
        case item := <-inputChan:
            process(item)
        }
    }
}()

// ❌ DON'T: Goroutine without cancellation path
go func() {
    for item := range inputChan { // Blocks forever if ctx cancels
        process(item)
    }
}()
```

## Additional Patterns & Lessons Learned

### Random Variation Formula
When implementing random variation within a percentage range:

```go
// ✅ DO: Correct uniform distribution
variationMin := 1.0 - variation  // e.g., 0.7 for ±30%
variationMax := 1.0 + variation  // e.g., 1.3 for ±30%
factor := variationMin + rand.Float64() * (variationMax - variationMin)
// Result: uniformly distributed between 0.7 and 1.3

// ❌ DON'T: Incorrect - produces wrong range
factor := variationMin + rand.Float64() * variationMax
// Result: distributed between 0.7 and 2.0 (not ±30%!)
```

### Type Conversion Safety (big.Int and int64)
When converting between types with different ranges:

```go
// ✅ DO: Check bounds before conversion
numBlocks := len(blocks)
if numBlocks == 0 {
    avgGasUsed = 0
} else if numBlocks > math.MaxInt64 {
    log.Warn().Msg("value exceeds int64 max")
    avgGasUsed = 0
} else {
    result := new(big.Int).Div(total, big.NewInt(int64(numBlocks)))
    if result.IsUint64() {
        avgGasUsed = result.Uint64()
    } else {
        avgGasUsed = math.MaxUint64
        log.Warn().Msg("result exceeds uint64 max")
    }
}

// ❌ DON'T: Blindly convert without checking
avgGasUsed = new(big.Int).Div(total, big.NewInt(int64(len(blocks)))).Uint64()
// Can panic if len(blocks) > MaxInt64 or result > MaxUint64
```

### Blocking Operations Must Accept Context
Any operation that can block must accept `context.Context` for cancellation:

```go
// ✅ DO: Accept context, use ticker, handle cancellation
func (v *Vault) SpendOrWait(ctx context.Context, amount uint64) error {
    ticker := time.NewTicker(100 * time.Millisecond)
    defer ticker.Stop()

    for {
        if v.trySpend(amount) {
            return nil
        }
        select {
        case <-ticker.C:
            continue
        case <-ctx.Done():
            return ctx.Err()
        }
    }
}

// ❌ DON'T: Use bare time.Sleep in infinite loop
func (v *Vault) SpendOrWait(amount uint64) {
    for {
        if v.trySpend(amount) {
            break
        }
        time.Sleep(100 * time.Millisecond)  // Cannot be cancelled!
    }
}
```

### Constructor Validation
Validate inputs in constructors and return errors:

```go
// ✅ DO: Validate and return error
func NewDynamicPricer(config Config) (*DynamicPricer, error) {
    if len(config.Prices) == 0 {
        return nil, fmt.Errorf("config.Prices cannot be empty")
    }
    return &DynamicPricer{config: config}, nil
}

// ❌ DON'T: Panic on invalid input or allow invalid state
func NewDynamicPricer(config Config) *DynamicPricer {
    // Will panic on first use if Prices is empty
    return &DynamicPricer{config: config}
}
```

### Documentation Must Match Implementation
Keep documentation (especially README files) synchronized with code:

**Critical to document:**
- Function signatures including context parameters and return types
- Error return conditions (not just success path)
- Async/timing behavior (e.g., "vault has zero budget until first block header received")
- Cancellation behavior

**Example:**
```markdown
<!-- ✅ DO: Accurate signature and behavior -->
- **`SpendOrWaitAvailableBudget(context.Context, uint64) error`**:
  Attempts to spend gas; blocks if insufficient budget is available or until context is cancelled.
  Returns nil on success, ctx.Err() if cancelled.

<!-- ❌ DON'T: Outdated or incomplete -->
- **`SpendOrWaitAvailableBudget(uint64)`**:
  Attempts to spend gas; blocks if insufficient budget is available.
```

### Test Coverage Requirements
When adding new components, always include comprehensive unit tests:

**Required test categories:**
- Basic functionality (creation, getters, setters)
- Edge cases (zero values, nil inputs, overflow, division by zero)
- Error conditions (invalid configs, failed operations)
- Concurrency (multiple goroutines, race conditions)
- Context cancellation (immediate cancel, timeout, graceful shutdown)
- Blocking/waiting behavior (wait then succeed, wait then timeout)

**Pattern for concurrent tests:**
```go
func TestConcurrentAccess(t *testing.T) {
    component := NewComponent()
    const numGoroutines = 100
    var wg sync.WaitGroup

    for i := 0; i < numGoroutines; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            // Perform concurrent operations
        }()
    }
    wg.Wait()
    // Verify final state
}
```

## Code Style

### Cobra Flags

- Flag names: lowercase with hyphens (kebab-case), e.g., `--output-file`
- Usage strings: lowercase, no ending punctuation, e.g., `"path to output file"`
- Remove unnecessary leading articles and filler words (e.g., "the", "a", "an") from usage strings
- Use `PersistentFlags()` only when flags need to be inherited by subcommands; otherwise use `Flags()`
- When defining multiple flags, use `f := cmd.Flags()` to avoid repetition
- Prefer `Var()` flag methods (e.g., `StringVar`, `IntVar`, `BoolVar`) over non-Var methods (e.g., `String`, `Int`, `Bool`) to bind directly to variables:
  ```go
  f := cmd.Flags()
  f.StringVar(&myVar, "name", "", "description")
  f.IntVar(&count, "count", 0, "description")
  ```
- Flag variables should be non-pointer types unless there's a specific need for pointers (e.g., distinguishing unset from zero value):
  ```go
  var myVar string  // preferred
  var count int     // preferred
  f.StringVar(&myVar, "name", "", "description")
  f.IntVar(&count, "count", 0, "description")
  ```

### Cobra Command Arguments

- Prefer to use Cobra built-in validators (`cobra.NoArgs`, `cobra.ExactArgs(n)`, `cobra.MinimumNArgs(n)`, `cobra.MaximumNArgs(n)`, `cobra.ArbitraryArgs`) instead of custom `Args: func(cmd *cobra.Command, args []string) error` functions, and move argument parsing/validation logic to `PreRunE` hook

### Cobra Commands

- Command `Short` descriptions: sentence case with ending period, e.g., `"Generate a node list to seed a node."`
- Command `Long` descriptions: consider using embedded usage.md file via `//go:embed usage.md` pattern; when using inline strings, use sentence case with ending period for complete sentences
- Command `Short` should be brief (~50 characters or less), appears in help menus and command lists
- Command `Long` provides detailed explanation, can be empty if `Short` is sufficient
