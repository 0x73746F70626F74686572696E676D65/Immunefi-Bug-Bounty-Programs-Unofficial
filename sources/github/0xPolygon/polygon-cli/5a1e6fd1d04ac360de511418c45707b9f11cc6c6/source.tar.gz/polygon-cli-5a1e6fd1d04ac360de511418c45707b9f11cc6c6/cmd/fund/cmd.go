package fund

import (
	"errors"
	"math/big"

	_ "embed"

	"github.com/0xPolygon/polygon-cli/flag"
	"github.com/spf13/cobra"
)

// The default private key used to send transactions.
const defaultPrivateKey = "0x42b6e34dc21598a807dc19d7784c71b2a7a01f6480dc6f58258f78e539f1a1fa"

// The default mnemonic  used to derive wallets.
const defaultMnemonic = "code code code code code code code code code code code quality"

// The default password used to create a wallet for HD derivation.
const defaultPassword = "password"

// cmdFundParams holds the command-line parameters for the fund command.
type cmdFundParams struct {
	RPCURL     string
	PrivateKey string

	WalletsNumber      uint64
	UseHDDerivation    bool
	WalletAddresses    []string
	FundingAmountInWei *big.Int
	OutputFile         string

	KeyFile string
	Seed    string

	FunderAddress     string
	Multicall3Address string

	RateLimit float64

	// Gas price parameters
	GasPrice         uint64
	PriorityGasPrice uint64

	// ERC20 specific parameters
	TokenAddress   string
	TokenAmount    *big.Int
	ApproveSpender string
	ApproveAmount  *big.Int

	// Multicall3 batching
	AccountsPerFundingTx uint64
}

var (
	//go:embed usage.md
	usage               string
	params              cmdFundParams
	defaultFundingInWei = big.NewInt(50000000000000000) // 0.05 ETH
)

// FundCmd represents the fund command.
var FundCmd = &cobra.Command{
	Use:   "fund",
	Short: "Bulk fund crypto wallets automatically.",
	Long:  usage,
	PreRunE: func(cmd *cobra.Command, args []string) (err error) {
		params.RPCURL, err = flag.GetRequiredRPCURL(cmd)
		if err != nil {
			return err
		}
		params.PrivateKey, err = flag.GetRequiredPrivateKey(cmd)
		if err != nil {
			return err
		}
		return checkFlags()
	},
	RunE: func(cmd *cobra.Command, args []string) error {
		return runFunding(cmd.Context())
	},
}

func init() {
	f := FundCmd.Flags()

	f.StringVarP(&params.RPCURL, flag.RPCURL, "r", flag.DefaultRPCURL, "RPC endpoint URL")
	f.StringVar(&params.PrivateKey, flag.PrivateKey, defaultPrivateKey, "hex encoded private key to use for sending transactions")

	// Wallet parameters.
	f.Uint64VarP(&params.WalletsNumber, "number", "n", 10, "number of wallets to fund")
	f.BoolVar(&params.UseHDDerivation, "hd-derivation", true, "derive wallets to fund from private key in deterministic way")
	f.StringSliceVar(&params.WalletAddresses, "addresses", nil, "comma-separated list of wallet addresses to fund")
	params.FundingAmountInWei = defaultFundingInWei
	f.Var(&flag.BigIntValue{Val: params.FundingAmountInWei}, "eth-amount", "amount of wei to send to each wallet")
	f.StringVar(&params.KeyFile, "key-file", "", "file containing accounts private keys, one per line")
	f.StringVar(&params.Seed, "seed", "", "seed string for deterministic wallet generation (e.g., 'ephemeral_test')")

	// Output parameters.
	f.StringVarP(&params.OutputFile, "file", "f", "wallets.json", "output JSON file path for storing addresses and private keys of funded wallets")

	// ERC20 parameters
	f.StringVar(&params.TokenAddress, "token-address", "", "address of the ERC20 token contract to mint and fund (if provided, enables ERC20 mode)")
	params.TokenAmount = new(big.Int)
	params.TokenAmount.SetString("1000000000000000000", 10) // 1 token
	f.Var(&flag.BigIntValue{Val: params.TokenAmount}, "token-amount", "amount of ERC20 tokens to transfer from private-key wallet to each wallet")
	f.StringVar(&params.ApproveSpender, "approve-spender", "", "address to approve for spending tokens from each funded wallet")
	params.ApproveAmount = new(big.Int)
	params.ApproveAmount.SetString("1000000000000000000000", 10) // 1000 tokens default
	f.Var(&flag.BigIntValue{Val: params.ApproveAmount}, "approve-amount", "amount of ERC20 tokens to approve for the spender")

	// Marking flags as mutually exclusive
	FundCmd.MarkFlagsMutuallyExclusive("addresses", "number")
	FundCmd.MarkFlagsMutuallyExclusive("addresses", "hd-derivation")
	FundCmd.MarkFlagsMutuallyExclusive("addresses", "seed")
	FundCmd.MarkFlagsMutuallyExclusive("key-file", "addresses")
	FundCmd.MarkFlagsMutuallyExclusive("key-file", "number")
	FundCmd.MarkFlagsMutuallyExclusive("key-file", "hd-derivation")
	FundCmd.MarkFlagsMutuallyExclusive("key-file", "seed")
	FundCmd.MarkFlagsMutuallyExclusive("seed", "hd-derivation")

	// Require at least one method to specify target accounts
	FundCmd.MarkFlagsOneRequired("addresses", "key-file", "number", "seed")

	// Contract parameters.
	f.StringVar(&params.FunderAddress, "funder-address", "", "address of pre-deployed funder contract")
	f.StringVar(&params.Multicall3Address, "multicall3-address", "", "address of pre-deployed multicall3 contract")
	f.Uint64Var(&params.AccountsPerFundingTx, "accounts-per-funding-tx", 400, "number of accounts to fund per multicall3 transaction")

	// RPC parameters.
	f.Float64Var(&params.RateLimit, "rate-limit", 4, "requests per second limit (use negative value to remove limit)")

	// Gas price parameters.
	f.Var(&flag.GasValue{Val: &params.GasPrice}, "gas-price", "gas price with unit support (e.g., \"100gwei\", \"1000000000\")")
	f.Var(&flag.GasValue{Val: &params.PriorityGasPrice}, "priority-gas-price", "gas tip for EIP-1559 with unit support (e.g., \"2gwei\")")
}

func checkFlags() error {
	// When using seed, require a number of wallets to generate
	if params.Seed != "" && params.WalletsNumber <= 0 {
		return errors.New("when using --seed, must also specify --number > 0 to indicate how many wallets to generate")
	}

	// Validate funding amount
	minValue := big.NewInt(1000000000)
	if params.FundingAmountInWei != nil && params.FundingAmountInWei.Cmp(minValue) <= 0 {
		return errors.New("the funding amount must be greater than 1000000000")
	}
	if params.OutputFile == "" {
		return errors.New("the output file is not specified")
	}

	// Validate gas price parameters
	if params.GasPrice != 0 && params.PriorityGasPrice != 0 && params.GasPrice < params.PriorityGasPrice {
		return errors.New("gas price must be greater than or equal to priority gas price")
	}

	// ERC20 specific validations
	if params.TokenAddress != "" {
		// ERC20 mode - validate token parameters
		if params.TokenAmount == nil || params.TokenAmount.Cmp(big.NewInt(0)) <= 0 {
			return errors.New("token amount must be greater than 0 when using ERC20 mode")
		}
		// Validate approve parameters if provided
		if params.ApproveSpender != "" {
			if params.ApproveAmount == nil || params.ApproveAmount.Cmp(big.NewInt(0)) <= 0 {
				return errors.New("approve amount must be greater than 0 when approve spender is specified")
			}
		}
	}

	return nil
}
