package bridge_service

import (
	"errors"
	"math/big"

	"github.com/ethereum/go-ethereum/common"
	"github.com/rs/zerolog/log"
)

var (
	ErrNotFound = errors.New("the bridge deposit was not found")
)

type BridgeService interface {
	GetDeposit(depositNetwork, depositCount uint32) (*Deposit, error)
	GetDeposits(destinationAddress string, offset, limit int) (deposits []Deposit, total int, err error)
	GetProof(depositNetwork, depositCount uint32) (*Proof, error)
	GetProofByGer(depositNetwork, depositCount uint32, ger common.Hash) (*Proof, error)
	GetProofByL1InfoTreeIndex(depositNetwork, depositCount uint32, l1InfoTreeIndex uint32) (*Proof, error)
	Url() string
}

type BridgeServiceBase struct {
	url string
}

func (b *BridgeServiceBase) Url() string {
	return b.url
}

func NewBridgeServiceBase(url string) BridgeServiceBase {
	return BridgeServiceBase{
		url: url,
	}
}

type Deposit struct {
	LeafType      uint8
	OrigNet       uint32
	OrigAddr      common.Address
	Amount        *big.Int
	DestNet       uint32
	DestAddr      common.Address
	BlockNum      uint64
	DepositCnt    uint32
	NetworkID     uint32
	TxHash        common.Hash
	ClaimTxHash   *common.Hash
	Metadata      []byte
	ReadyForClaim bool
	GlobalIndex   *big.Int
}

type Proof struct {
	MerkleProof       []common.Hash
	RollupMerkleProof []common.Hash
	MainExitRoot      *common.Hash
	RollupExitRoot    *common.Hash
}

func HashSliceToBytesArray(hashes []common.Hash) [32][32]byte {
	var array [32][32]byte
	for i, h := range hashes {
		if i >= 32 {
			log.Warn().Msg("HashSliceToBytesArray: more than 32 hashes, truncating")
			break
		}
		array[i] = h
	}
	return array
}
