# Polygon PoS Team Standards

`team-standards.md` in this repo is the team-wide conventions file that
public Polygon PoS repos (bor, heimdall-v2, polyproto, …) fetch at agent
session start:

    https://raw.githubusercontent.com/0xPolygon/pos-standards/main/team-standards.md

## This is a publish mirror — do not edit here

Content is authored and reviewed in the private `0xPolygon/pos-team-workspace`
repo (2 PoS-team approvals + a publish-safety scan + a manually approved
deploy gate) and pushed here by its `sync-team-standards.yml` workflow.
Direct pushes are restricted to the sync identity; PRs against this repo
will be closed and redirected to the workspace repo. Questions → the
Polygon PoS team (`@0xPolygon/pos-v1`).
