# Polygon PoS Team Standards

> **Source of truth:** this file lives in the private workspace repo
> `0xPolygon/pos-team-workspace`. It is synced to the public
> `0xPolygon/pos-standards` repo on every push to `main` of the workspace
> repo. Public PoS repos fetch it from there at session start so contributors
> using Claude or Codex auto-pick up these conventions.
>
> **Publish-safe:** this file contains zero Polygon-internal context. Internal
> context (Datadog tags, GCP project IDs, host inventory, validator addresses)
> lives in the workspace `AGENTS.md`, never here.

## Reference implementations

- Bor and Heimdall-v2 are the canonical Go style references. When in doubt,
  match what's already there.

## Go conventions

- Effective Go + Uber Go Style Guide compliance.
- `gofumpt` clean. `golangci-lint` clean against the repo's `.golangci.yml` —
  match the repo's existing config, don't override it.
- Errors wrapped with `fmt.Errorf("...: %w", err)`. Always handle errors at the
  call site — never silently drop.
- No panics in non-fatal paths. `panic` only for impossible invariants.
- No `init()` side effects beyond constant registration.
- Goroutines must have a documented termination path. No leaks.
- Context: accept `context.Context` as the first parameter on any function that
  performs IO. Don't store contexts in structs.
- Tests: standard library `testing`. Table-driven for anything with branching.
  Subtests via `t.Run`. Don't over-comment tests — structure speaks for itself.

## Repo-level Claude rules are part of the contract

Bor and Heimdall-v2 (and any Tier 1 repo that ships them) carry `.claude/rules/`
directories with security-critical guidance. Honor them. They override anything
in this file if there's a conflict — the repo author knows the local landmines
best.

## CI gates required green before requesting review

- Lint (`golangci-lint`)
- Unit tests
- Integration / e2e tests (where the repo defines them)
- Diffguard with mutation testing enabled (target: exit 0; surface and discuss
  intentional deviations rather than suppressing)
- SonarCloud — aim for no new issues and no new hotspots. 100% is the target;
  surface intentional deviations to the team for discussion rather than
  silently overriding.
- govulncheck (no new vulnerabilities)
- Kurtosis e2e tests (where the repo wires them — Bor, Heimdall-v2)

## Diffguard

- Cognitive complexity ≤10 per function.
- Function bodies ≤50 lines.
- Files ≤500 lines.
- No new dependency cycles.
- Mutation kill rate ≥90% on tier-1 code.
- Run `diffguard /path/to/repo` after every change. Final run before reporting
  work done must include mutation testing (no `--skip-mutation`).
- If a violation seems unavoidable, surface it explicitly. Never silently
  suppress, disable, or claim a passing result that didn't pass.

## Git and GitHub

- **Mutating `gh` commands must use `-R owner/repo`** (or `--repo`). Without
  it, `gh` infers the target repo from the current directory's git remote — a
  wrong-CWD failure mode that has silently overwritten PR / issue content in
  the wrong repo. Read-only commands (`pr list`, `pr view`, `issue list`, …)
  are unaffected. `gh pr create`, `gh release create`, and `gh repo create`
  use current-CWD inference by design (head ref / source repo) and are
  exempted from the rule; for them, the team standard is `cd /abs/path && gh
  …` so CWD correctness is explicit. The PreToolUse hook
  (`.claude/hooks/prevent-root-gh.sh`) blocks tracked mutations missing `-R`
  for Claude users; Codex users follow the same discipline by hand.
- Never open a PR without explicit user permission.
- Always create PRs in draft mode (`gh pr create --draft`). Mark ready
  (`gh pr ready`) only after **both** are true: CI is green **and** every
  `@claude review` / Copilot Code Review comment has been addressed.
  "Outstanding bot comments" is a blocker.
- Never commit without explicit user permission.
- All commits must be signed (GPG via GitHub). Unsigned commits are blocked by
  branch protection. Exception: when an external contributor opens a PR without
  GPG signing, the security team can temporarily relax the "signed-only" check
  on the target repo so the PR is mergeable. Document the exception window in
  the PR description.
- Update PR descriptions before marking the PR ready for team review. Mid-PR
  description updates per push are not required.
- For long-lived branches: regularly fetch the target branch and merge it into
  the feature branch to resolve conflicts and stay current. Rebase isn't
  required.
- **PR title format for Bor and Heimdall-v2:** start with the touched packages,
  comma-separated, then a colon, then the description. Use the package name as
  it appears in the source tree (Heimdall packages happen to live under `x/`,
  e.g. `bor`, `topup`; Bor packages don't share that prefix, e.g. `consensus`,
  `eth/tracers`). Examples: `consensus, eth: fix fee distribution` (Bor),
  `bor, topup: fix fee distribution` (Heimdall-v2). Other Tier 1 repos follow
  conventional commits (`feat(scope):`, `fix(scope):`, `chore(scope):`) unless
  their `CLAUDE.md` says otherwise.

## Branch flow

- **Default branch is dynamic** — most PoS repos use `develop`, some use
  `master`, some use `main`. Resolve via
  `gh repo view --json defaultBranchRef` rather than hardcoding.
- **Feature branches:** `<username>/<short-description>` or
  `<username>/<JIRA-KEY>` or `<username>/<JIRA-KEY>-<short-description>`.
- **Hotfix branches:** `<username>/hotfix-<short-description>`.
- **Release branches:** `<version>-beta-candidate` (e.g. `v0.6.4-beta-candidate`).
- **Features:** branch from `develop` (or the repo's default if not `develop`)
  → PR back to `develop` → merge as merge commit + squash.
- **Releases:** cut `<version>-beta-candidate` from `develop` → bump version
  on the branch → tag `vX.Y.Z-beta` (or `-beta2`, `-beta3`, … for subsequent
  RCs) → deploy to a devnet (24h observation) → deploy to internal testnet
  (48h) → deploy to external testnet, announce to validators (48h) → when
  stable, merge into `master`/`main` (**no squash**), tag `vX.Y.Z` →
  deploy to internal mainnet (48h) → release to external mainnet → backport
  `master`/`main` → `develop` (**no squash**). Mark `-beta` tags as
  pre-release on GitHub; mark the final `vX.Y.Z` tag as latest.
- **Hotfixes:** branch from `master`/`main`, PR back to `master`/`main`,
  tag `vX.Y.Z-hotfix` (or `-hotfix2`, `-hotfix3`, … if multiple) for
  pre-release validation, then `vX.Y.<Z+1>` for the stable hotfix release.
  Backport `master`/`main` → `develop` (no squash). Same soak ladder as
  the regular release, scaled to incident urgency. **The same flow also
  applies to small or security-oriented releases that need to ship
  independently of `develop`'s pending state** — what matters is the
  branching pattern (cut from `master`/`main` so the release doesn't
  drag in unfinished work from `develop`), not urgency. A
  non-incident patch release uses closer-to-full soak times; an
  incident hotfix can compress them.
- **Versioning** (`vX.Y.Z`):
  - **X (Major)** — breaking changes that require config rework, redeploy,
    or a from-scratch resync.
  - **Y (Minor)** — backward-incompatible changes including hardforks.
  - **Z (Patch)** — backward-compatible fixes.
  - Pre-release suffixes: `-beta` / `-betaN` for testnet validation,
    `-hotfix` / `-hotfixN` for production hotfix candidates. Increment
    sequentially; never skip numbers (the GitHub releases page reads
    cleaner without gaps).
- **Upstream syncs** (Bor ← go-ethereum, Erigon ← erigontech/erigon,
  cosmos-sdk ← upstream, cometbft ← upstream): merge with a merge commit,
  **never squash**. Preserving upstream's per-commit history is the whole
  point — squashing collapses the upstream's authorship and signed-off
  metadata into a single PoS-authored commit, which makes future syncs
  harder and obscures attribution.
- **Security rollouts:** follow the security rollout process (see best-practices
  doc in your workspace).

## PR description template

```text
## Summary
<one paragraph: what changed and why. If the change has measurable impact, add a small table or numbers (e.g. perf delta on a kurtosis devnet, mutation kill rate). Link the JIRA / GH issue inline if there is one — not required.>

## Executed tests
<what was actually run beyond CI's standard unit / integration / e2e gates: kurtosis scenarios, chaos runs, manual checks against Amoy / mainnet RPCs, devnet upgrades, etc. Include output or pointers to where the run lives.>

## Rollout notes
<consensus-affecting? requires coordinated upgrade? backwards-compatible? operator-facing change?>
```

## Branch verification (every session, every repo)

- **First mutating op per repo per session:** `git -C <abs-path> fetch origin` →
  check current branch and ahead/behind status → if
  `git -C <abs-path> log --oneline origin/<default>..HEAD` is empty, hard-stop
  and ask the user.
- **Every subsequent mutating op in the same repo:** verify
  `git -C <abs-path> branch --show-current` matches the session-confirmed
  branch.
- **Pre-commit:** rerun the empty-output check. If empty, ask whether this is a
  fresh branch or already-merged before committing.
- **Never commit or push directly to `develop`, `master`, `main`, or
  `release/<X.Y.Z>`.** All changes go through PRs.

## Code style and shape

- Don't introduce abstractions for hypothetical future requirements. No
  interfaces, generic types, or wrapper layers added "in case we need them
  later." Add the abstraction when a second concrete use case arrives.
  Existing protocol-level mechanisms (hardfork gates, version negotiation,
  package boundaries) are real requirements — keep them.
- Don't write multi-paragraph docstrings or What-comments. Comment only
  non-obvious WHY: hidden constraints, subtle invariants, workarounds for
  specific bugs, behavior that would surprise a reader.
- No all-caps emphasis in comments. No `MUST`, `MUST NOT`, `IMPORTANT`,
  `WARNING:`, etc. AIs lean on these heavily; humans don't need them. Go
  convention (lowercase, period-terminated) is the bar.
- Don't over-comment unit tests. Test names + table-driven structure should
  make intent clear.
- Three similar lines is fine. Don't extract a helper from three almost-
  identical call sites until you genuinely need to add a fourth or modify all
  three together.
- **Never name functions, files, branches, commits, comments, or PR titles
  after a vulnerability or attack technique.** No `fixHashCollisionAttack`,
  no `// fixes the reentrancy bug from POS-3399`, no
  `// CVE-2026-XXXX mitigation`. Until the security advisory is published,
  that information leaks the vulnerability via the source diff or git history.
  After publication, the link belongs in the security advisory, not in the
  code. Use neutral names that describe the post-fix behavior
  (`validateBeforeWrite`, `requireSignedHeader`).

## Confirm before destructive actions

- Always confirm before `rm -rf` on data dirs, dropping DBs, force-pushing,
  killing prod services, modifying live validator keys, deleting cloud
  instances.
- Local reversible work (file edits, branch commits, local tests) proceeds
  without confirmation.
