// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package agglayergermock

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

// AgglayergermockMetaData contains all meta data concerning the Agglayergermock contract.
var AgglayergermockMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_rollupManager\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"_bridgeAddress\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"GlobalExitRootAlreadySet\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"GlobalExitRootNotFound\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"InvalidZeroAddress\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"MerkleTreeFull\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"NewDepositCountExceedsMax\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"NonZeroValueForUnusedFrontier\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyAllowedContracts\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyGlobalExitRootRemover\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyGlobalExitRootUpdater\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyPendingGlobalExitRootRemover\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyPendingGlobalExitRootUpdater\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"SubtreeFrontierMismatch\",\"type\":\"error\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"uint32\",\"name\":\"leafCount\",\"type\":\"uint32\"},{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"currentL1InfoRoot\",\"type\":\"bytes32\"}],\"name\":\"InitL1InfoRootMap\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"version\",\"type\":\"uint8\"}],\"name\":\"Initialized\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"bytes32\",\"name\":\"mainnetExitRoot\",\"type\":\"bytes32\"},{\"indexed\":true,\"internalType\":\"bytes32\",\"name\":\"rollupExitRoot\",\"type\":\"bytes32\"}],\"name\":\"UpdateL1InfoTree\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"bytes32\",\"name\":\"currentL1InfoRoot\",\"type\":\"bytes32\"},{\"indexed\":true,\"internalType\":\"uint32\",\"name\":\"leafCount\",\"type\":\"uint32\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"blockhash\",\"type\":\"uint256\"},{\"indexed\":false,\"internalType\":\"uint64\",\"name\":\"minTimestamp\",\"type\":\"uint64\"}],\"name\":\"UpdateL1InfoTreeV2\",\"type\":\"event\"},{\"inputs\":[],\"name\":\"GER_VERSION\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"bridgeAddress\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"depositCount\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"getLastGlobalExitRoot\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"newGlobalExitRoot\",\"type\":\"bytes32\"},{\"internalType\":\"uint256\",\"name\":\"lastBlockHash\",\"type\":\"uint256\"},{\"internalType\":\"uint64\",\"name\":\"timestamp\",\"type\":\"uint64\"}],\"name\":\"getLeafValue\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"stateMutability\":\"pure\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"getRoot\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"globalExitRootMap\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"initialize\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"_root\",\"type\":\"bytes32\"},{\"internalType\":\"uint32\",\"name\":\"depositCount\",\"type\":\"uint32\"}],\"name\":\"injectGER\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint32\",\"name\":\"leafCount\",\"type\":\"uint32\"}],\"name\":\"l1InfoRootMap\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"l1InfoRoot\",\"type\":\"bytes32\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"lastMainnetExitRoot\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"lastRollupExitRoot\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"rollupManager\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"newRoot\",\"type\":\"bytes32\"}],\"name\":\"updateExitRoot\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"version\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"pure\",\"type\":\"function\"}]",
	Bin: "0x60c060405234801561000f575f5ffd5b50604051610d8e380380610d8e83398101604081905261002e9161012f565b6001600160a01b0380831660a0528116608052818161004b610054565b50505050610160565b602e54610100900460ff16156100c05760405162461bcd60e51b815260206004820152602760248201527f496e697469616c697a61626c653a20636f6e747261637420697320696e697469604482015266616c697a696e6760c81b606482015260840160405180910390fd5b602e5460ff908116101561011257602e805460ff191660ff9081179091556040519081527f7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb38474024989060200160405180910390a15b565b80516001600160a01b038116811461012a575f5ffd5b919050565b5f5f60408385031215610140575f5ffd5b61014983610114565b915061015760208401610114565b90509250929050565b60805160a051610bff61018f5f395f81816101ab015261038101525f81816102a801526103350152610bff5ff3fe608060405234801561000f575f5ffd5b50600436106100f0575f3560e01c806349b7b802116100935780638129fc1c116100635780638129fc1c1461029b578063a3c573eb146102a3578063a43ca6a6146102ca578063ef4eeb35146102fd575f5ffd5b806349b7b802146101a657806354fd4d50146101f25780635ca1e1651461022b5780635d81050114610233575f5ffd5b80632dfdf0b5116100ce5780632dfdf0b514610177578063319cf7351461018057806333d6247d146101895780633ed691ef1461019e575f5ffd5b806301fd9044146100f45780630f1426191461010f578063257b363214610158575b5f5ffd5b6100fc5f5481565b6040519081526020015b60405180910390f35b61014b6040518060400160405280600681526020017f76312e302e30000000000000000000000000000000000000000000000000000081525081565b60405161010691906108c5565b6100fc610166366004610918565b60026020525f908152604090205481565b6100fc60235481565b6100fc60015481565b61019c610197366004610918565b61031c565b005b6100fc610542565b6101cd7f000000000000000000000000000000000000000000000000000000000000000081565b60405173ffffffffffffffffffffffffffffffffffffffff9091168152602001610106565b60408051808201909152600681527f76312e302e300000000000000000000000000000000000000000000000000000602082015261014b565b6100fc610555565b6100fc61024136600461092f565b604080516020808201959095528082019390935260c09190911b7fffffffffffffffff0000000000000000000000000000000000000000000000001660608301528051604881840301815260689092019052805191012090565b61019c61055e565b6101cd7f000000000000000000000000000000000000000000000000000000000000000081565b61019c6102d8366004610989565b5f82815260026020908152604080832042905563ffffffff9093168252602f90522055565b6100fc61030b3660046109b3565b602f6020525f908152604090205481565b5f8073ffffffffffffffffffffffffffffffffffffffff7f000000000000000000000000000000000000000000000000000000000000000016330361036a57505060018190555f54816103e9565b73ffffffffffffffffffffffffffffffffffffffff7f00000000000000000000000000000000000000000000000000000000000000001633036103b75750505f81905560015481906103e9565b6040517fb49365dd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b5f6103f48284610752565b5f818152600260205260408120549192500361053c57425f6104176001436109f9565b5f8481526002602090815260409182902092409283905581518082018790528083018490527fffffffffffffffff00000000000000000000000000000000000000000000000060c087901b166060820152825180820360480181526068909101909252815191012090915061048b90610769565b5f610494610555565b60235463ffffffff165f908152602f602052604080822083905551919250879187917fda61aa7823fcd807e37b95aabcbe17f03a6f3efd514176444dae191d27fd66b391a360235463ffffffff167faf6c6cd7790e0180a4d22eb8ed846e55846f54ed10e5946db19972b5a0813a5982848660405161053093929190928352602083019190915267ffffffffffffffff16604082015260600190565b60405180910390a25050505b50505050565b5f6105506001545f54610752565b905090565b5f610550610846565b602e54610100900460ff161580801561057e5750602e54600160ff909116105b806105985750303b1580156105985750602e5460ff166001145b610628576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602e60248201527f496e697469616c697a61626c653a20636f6e747261637420697320616c72656160448201527f647920696e697469616c697a6564000000000000000000000000000000000000606482015260840160405180910390fd5b602e80547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055801561068657602e80547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff166101001790555b5f61068f610555565b6023805463ffffffff9081165f908152602f602090815260409182902085905592548151921682529181018390529192507f11f50c71891002839c2637ce302087160298255a87f1ea60d40e8db081383fad910160405180910390a150801561074f57602e80547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ff169055604051600181527f7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb38474024989060200160405180910390a15b50565b5f8281526020829052604081205b90505b92915050565b80600161077860206002610b2d565b61078291906109f9565b602354106107bc576040517fef5ccf6600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b5f60235f81546107cb90610b38565b918290555090505f5b6020811015610838578082901c6001166001036108075782600382602081106107ff576107ff610b6f565b015550505050565b61082e6003826020811061081d5761081d610b6f565b0154845f9182526020526040902090565b92506001016107d4565b50610841610b9c565b505050565b6023545f90819081805b60208110156108bc578083901c6001166001036108955761088e6003826020811061087d5761087d610b6f565b0154855f9182526020526040902090565b93506108a5565b5f84815260208390526040902093505b5f8281526020839052604090209150600101610850565b50919392505050565b602081525f82518060208401528060208501604085015e5f6040828501015260407fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f83011684010191505092915050565b5f60208284031215610928575f5ffd5b5035919050565b5f5f5f60608486031215610941575f5ffd5b8335925060208401359150604084013567ffffffffffffffff81168114610966575f5ffd5b809150509250925092565b803563ffffffff81168114610984575f5ffd5b919050565b5f5f6040838503121561099a575f5ffd5b823591506109aa60208401610971565b90509250929050565b5f602082840312156109c3575f5ffd5b61076082610971565b7f4e487b71000000000000000000000000000000000000000000000000000000005f52601160045260245ffd5b81810381811115610763576107636109cc565b6001815b6001841115610a4757808504811115610a2b57610a2b6109cc565b6001841615610a3957908102905b60019390931c928002610a10565b935093915050565b5f82610a5d57506001610763565b81610a6957505f610763565b8160018114610a7f5760028114610a8957610aa5565b6001915050610763565b60ff841115610a9a57610a9a6109cc565b50506001821b610763565b5060208310610133831016604e8410600b8410161715610ac8575081810a610763565b610af37fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8484610a0c565b807fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff04821115610b2557610b256109cc565b029392505050565b5f6107608383610a4f565b5f7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff8203610b6857610b686109cc565b5060010190565b7f4e487b71000000000000000000000000000000000000000000000000000000005f52603260045260245ffd5b7f4e487b71000000000000000000000000000000000000000000000000000000005f52600160045260245ffdfea2646970667358221220ffce07f302afe53dda3ad20db162275eda2aae92e3ca0f4b1820386b739d448c64736f6c634300081c0033",
}

// AgglayergermockABI is the input ABI used to generate the binding from.
// Deprecated: Use AgglayergermockMetaData.ABI instead.
var AgglayergermockABI = AgglayergermockMetaData.ABI

// AgglayergermockBin is the compiled bytecode used for deploying new contracts.
// Deprecated: Use AgglayergermockMetaData.Bin instead.
var AgglayergermockBin = AgglayergermockMetaData.Bin

// DeployAgglayergermock deploys a new Ethereum contract, binding an instance of Agglayergermock to it.
func DeployAgglayergermock(auth *bind.TransactOpts, backend bind.ContractBackend, _rollupManager common.Address, _bridgeAddress common.Address) (common.Address, *types.Transaction, *Agglayergermock, error) {
	parsed, err := AgglayergermockMetaData.GetAbi()
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	if parsed == nil {
		return common.Address{}, nil, nil, errors.New("GetABI returned nil")
	}

	address, tx, contract, err := bind.DeployContract(auth, *parsed, common.FromHex(AgglayergermockBin), backend, _rollupManager, _bridgeAddress)
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	return address, tx, &Agglayergermock{AgglayergermockCaller: AgglayergermockCaller{contract: contract}, AgglayergermockTransactor: AgglayergermockTransactor{contract: contract}, AgglayergermockFilterer: AgglayergermockFilterer{contract: contract}}, nil
}

// Agglayergermock is an auto generated Go binding around an Ethereum contract.
type Agglayergermock struct {
	AgglayergermockCaller     // Read-only binding to the contract
	AgglayergermockTransactor // Write-only binding to the contract
	AgglayergermockFilterer   // Log filterer for contract events
}

// AgglayergermockCaller is an auto generated read-only Go binding around an Ethereum contract.
type AgglayergermockCaller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// AgglayergermockTransactor is an auto generated write-only Go binding around an Ethereum contract.
type AgglayergermockTransactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// AgglayergermockFilterer is an auto generated log filtering Go binding around an Ethereum contract events.
type AgglayergermockFilterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// AgglayergermockSession is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type AgglayergermockSession struct {
	Contract     *Agglayergermock  // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// AgglayergermockCallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type AgglayergermockCallerSession struct {
	Contract *AgglayergermockCaller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts          // Call options to use throughout this session
}

// AgglayergermockTransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type AgglayergermockTransactorSession struct {
	Contract     *AgglayergermockTransactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts          // Transaction auth options to use throughout this session
}

// AgglayergermockRaw is an auto generated low-level Go binding around an Ethereum contract.
type AgglayergermockRaw struct {
	Contract *Agglayergermock // Generic contract binding to access the raw methods on
}

// AgglayergermockCallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type AgglayergermockCallerRaw struct {
	Contract *AgglayergermockCaller // Generic read-only contract binding to access the raw methods on
}

// AgglayergermockTransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type AgglayergermockTransactorRaw struct {
	Contract *AgglayergermockTransactor // Generic write-only contract binding to access the raw methods on
}

// NewAgglayergermock creates a new instance of Agglayergermock, bound to a specific deployed contract.
func NewAgglayergermock(address common.Address, backend bind.ContractBackend) (*Agglayergermock, error) {
	contract, err := bindAgglayergermock(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Agglayergermock{AgglayergermockCaller: AgglayergermockCaller{contract: contract}, AgglayergermockTransactor: AgglayergermockTransactor{contract: contract}, AgglayergermockFilterer: AgglayergermockFilterer{contract: contract}}, nil
}

// NewAgglayergermockCaller creates a new read-only instance of Agglayergermock, bound to a specific deployed contract.
func NewAgglayergermockCaller(address common.Address, caller bind.ContractCaller) (*AgglayergermockCaller, error) {
	contract, err := bindAgglayergermock(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &AgglayergermockCaller{contract: contract}, nil
}

// NewAgglayergermockTransactor creates a new write-only instance of Agglayergermock, bound to a specific deployed contract.
func NewAgglayergermockTransactor(address common.Address, transactor bind.ContractTransactor) (*AgglayergermockTransactor, error) {
	contract, err := bindAgglayergermock(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &AgglayergermockTransactor{contract: contract}, nil
}

// NewAgglayergermockFilterer creates a new log filterer instance of Agglayergermock, bound to a specific deployed contract.
func NewAgglayergermockFilterer(address common.Address, filterer bind.ContractFilterer) (*AgglayergermockFilterer, error) {
	contract, err := bindAgglayergermock(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &AgglayergermockFilterer{contract: contract}, nil
}

// bindAgglayergermock binds a generic wrapper to an already deployed contract.
func bindAgglayergermock(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := AgglayergermockMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Agglayergermock *AgglayergermockRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Agglayergermock.Contract.AgglayergermockCaller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Agglayergermock *AgglayergermockRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Agglayergermock.Contract.AgglayergermockTransactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Agglayergermock *AgglayergermockRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Agglayergermock.Contract.AgglayergermockTransactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Agglayergermock *AgglayergermockCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Agglayergermock.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Agglayergermock *AgglayergermockTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Agglayergermock.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Agglayergermock *AgglayergermockTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Agglayergermock.Contract.contract.Transact(opts, method, params...)
}

// GERVERSION is a free data retrieval call binding the contract method 0x0f142619.
//
// Solidity: function GER_VERSION() view returns(string)
func (_Agglayergermock *AgglayergermockCaller) GERVERSION(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "GER_VERSION")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// GERVERSION is a free data retrieval call binding the contract method 0x0f142619.
//
// Solidity: function GER_VERSION() view returns(string)
func (_Agglayergermock *AgglayergermockSession) GERVERSION() (string, error) {
	return _Agglayergermock.Contract.GERVERSION(&_Agglayergermock.CallOpts)
}

// GERVERSION is a free data retrieval call binding the contract method 0x0f142619.
//
// Solidity: function GER_VERSION() view returns(string)
func (_Agglayergermock *AgglayergermockCallerSession) GERVERSION() (string, error) {
	return _Agglayergermock.Contract.GERVERSION(&_Agglayergermock.CallOpts)
}

// BridgeAddress is a free data retrieval call binding the contract method 0xa3c573eb.
//
// Solidity: function bridgeAddress() view returns(address)
func (_Agglayergermock *AgglayergermockCaller) BridgeAddress(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "bridgeAddress")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// BridgeAddress is a free data retrieval call binding the contract method 0xa3c573eb.
//
// Solidity: function bridgeAddress() view returns(address)
func (_Agglayergermock *AgglayergermockSession) BridgeAddress() (common.Address, error) {
	return _Agglayergermock.Contract.BridgeAddress(&_Agglayergermock.CallOpts)
}

// BridgeAddress is a free data retrieval call binding the contract method 0xa3c573eb.
//
// Solidity: function bridgeAddress() view returns(address)
func (_Agglayergermock *AgglayergermockCallerSession) BridgeAddress() (common.Address, error) {
	return _Agglayergermock.Contract.BridgeAddress(&_Agglayergermock.CallOpts)
}

// DepositCount is a free data retrieval call binding the contract method 0x2dfdf0b5.
//
// Solidity: function depositCount() view returns(uint256)
func (_Agglayergermock *AgglayergermockCaller) DepositCount(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "depositCount")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// DepositCount is a free data retrieval call binding the contract method 0x2dfdf0b5.
//
// Solidity: function depositCount() view returns(uint256)
func (_Agglayergermock *AgglayergermockSession) DepositCount() (*big.Int, error) {
	return _Agglayergermock.Contract.DepositCount(&_Agglayergermock.CallOpts)
}

// DepositCount is a free data retrieval call binding the contract method 0x2dfdf0b5.
//
// Solidity: function depositCount() view returns(uint256)
func (_Agglayergermock *AgglayergermockCallerSession) DepositCount() (*big.Int, error) {
	return _Agglayergermock.Contract.DepositCount(&_Agglayergermock.CallOpts)
}

// GetLastGlobalExitRoot is a free data retrieval call binding the contract method 0x3ed691ef.
//
// Solidity: function getLastGlobalExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCaller) GetLastGlobalExitRoot(opts *bind.CallOpts) ([32]byte, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "getLastGlobalExitRoot")

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// GetLastGlobalExitRoot is a free data retrieval call binding the contract method 0x3ed691ef.
//
// Solidity: function getLastGlobalExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockSession) GetLastGlobalExitRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.GetLastGlobalExitRoot(&_Agglayergermock.CallOpts)
}

// GetLastGlobalExitRoot is a free data retrieval call binding the contract method 0x3ed691ef.
//
// Solidity: function getLastGlobalExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCallerSession) GetLastGlobalExitRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.GetLastGlobalExitRoot(&_Agglayergermock.CallOpts)
}

// GetLeafValue is a free data retrieval call binding the contract method 0x5d810501.
//
// Solidity: function getLeafValue(bytes32 newGlobalExitRoot, uint256 lastBlockHash, uint64 timestamp) pure returns(bytes32)
func (_Agglayergermock *AgglayergermockCaller) GetLeafValue(opts *bind.CallOpts, newGlobalExitRoot [32]byte, lastBlockHash *big.Int, timestamp uint64) ([32]byte, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "getLeafValue", newGlobalExitRoot, lastBlockHash, timestamp)

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// GetLeafValue is a free data retrieval call binding the contract method 0x5d810501.
//
// Solidity: function getLeafValue(bytes32 newGlobalExitRoot, uint256 lastBlockHash, uint64 timestamp) pure returns(bytes32)
func (_Agglayergermock *AgglayergermockSession) GetLeafValue(newGlobalExitRoot [32]byte, lastBlockHash *big.Int, timestamp uint64) ([32]byte, error) {
	return _Agglayergermock.Contract.GetLeafValue(&_Agglayergermock.CallOpts, newGlobalExitRoot, lastBlockHash, timestamp)
}

// GetLeafValue is a free data retrieval call binding the contract method 0x5d810501.
//
// Solidity: function getLeafValue(bytes32 newGlobalExitRoot, uint256 lastBlockHash, uint64 timestamp) pure returns(bytes32)
func (_Agglayergermock *AgglayergermockCallerSession) GetLeafValue(newGlobalExitRoot [32]byte, lastBlockHash *big.Int, timestamp uint64) ([32]byte, error) {
	return _Agglayergermock.Contract.GetLeafValue(&_Agglayergermock.CallOpts, newGlobalExitRoot, lastBlockHash, timestamp)
}

// GetRoot is a free data retrieval call binding the contract method 0x5ca1e165.
//
// Solidity: function getRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCaller) GetRoot(opts *bind.CallOpts) ([32]byte, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "getRoot")

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// GetRoot is a free data retrieval call binding the contract method 0x5ca1e165.
//
// Solidity: function getRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockSession) GetRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.GetRoot(&_Agglayergermock.CallOpts)
}

// GetRoot is a free data retrieval call binding the contract method 0x5ca1e165.
//
// Solidity: function getRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCallerSession) GetRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.GetRoot(&_Agglayergermock.CallOpts)
}

// GlobalExitRootMap is a free data retrieval call binding the contract method 0x257b3632.
//
// Solidity: function globalExitRootMap(bytes32 ) view returns(uint256)
func (_Agglayergermock *AgglayergermockCaller) GlobalExitRootMap(opts *bind.CallOpts, arg0 [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "globalExitRootMap", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GlobalExitRootMap is a free data retrieval call binding the contract method 0x257b3632.
//
// Solidity: function globalExitRootMap(bytes32 ) view returns(uint256)
func (_Agglayergermock *AgglayergermockSession) GlobalExitRootMap(arg0 [32]byte) (*big.Int, error) {
	return _Agglayergermock.Contract.GlobalExitRootMap(&_Agglayergermock.CallOpts, arg0)
}

// GlobalExitRootMap is a free data retrieval call binding the contract method 0x257b3632.
//
// Solidity: function globalExitRootMap(bytes32 ) view returns(uint256)
func (_Agglayergermock *AgglayergermockCallerSession) GlobalExitRootMap(arg0 [32]byte) (*big.Int, error) {
	return _Agglayergermock.Contract.GlobalExitRootMap(&_Agglayergermock.CallOpts, arg0)
}

// L1InfoRootMap is a free data retrieval call binding the contract method 0xef4eeb35.
//
// Solidity: function l1InfoRootMap(uint32 leafCount) view returns(bytes32 l1InfoRoot)
func (_Agglayergermock *AgglayergermockCaller) L1InfoRootMap(opts *bind.CallOpts, leafCount uint32) ([32]byte, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "l1InfoRootMap", leafCount)

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// L1InfoRootMap is a free data retrieval call binding the contract method 0xef4eeb35.
//
// Solidity: function l1InfoRootMap(uint32 leafCount) view returns(bytes32 l1InfoRoot)
func (_Agglayergermock *AgglayergermockSession) L1InfoRootMap(leafCount uint32) ([32]byte, error) {
	return _Agglayergermock.Contract.L1InfoRootMap(&_Agglayergermock.CallOpts, leafCount)
}

// L1InfoRootMap is a free data retrieval call binding the contract method 0xef4eeb35.
//
// Solidity: function l1InfoRootMap(uint32 leafCount) view returns(bytes32 l1InfoRoot)
func (_Agglayergermock *AgglayergermockCallerSession) L1InfoRootMap(leafCount uint32) ([32]byte, error) {
	return _Agglayergermock.Contract.L1InfoRootMap(&_Agglayergermock.CallOpts, leafCount)
}

// LastMainnetExitRoot is a free data retrieval call binding the contract method 0x319cf735.
//
// Solidity: function lastMainnetExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCaller) LastMainnetExitRoot(opts *bind.CallOpts) ([32]byte, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "lastMainnetExitRoot")

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// LastMainnetExitRoot is a free data retrieval call binding the contract method 0x319cf735.
//
// Solidity: function lastMainnetExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockSession) LastMainnetExitRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.LastMainnetExitRoot(&_Agglayergermock.CallOpts)
}

// LastMainnetExitRoot is a free data retrieval call binding the contract method 0x319cf735.
//
// Solidity: function lastMainnetExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCallerSession) LastMainnetExitRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.LastMainnetExitRoot(&_Agglayergermock.CallOpts)
}

// LastRollupExitRoot is a free data retrieval call binding the contract method 0x01fd9044.
//
// Solidity: function lastRollupExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCaller) LastRollupExitRoot(opts *bind.CallOpts) ([32]byte, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "lastRollupExitRoot")

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// LastRollupExitRoot is a free data retrieval call binding the contract method 0x01fd9044.
//
// Solidity: function lastRollupExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockSession) LastRollupExitRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.LastRollupExitRoot(&_Agglayergermock.CallOpts)
}

// LastRollupExitRoot is a free data retrieval call binding the contract method 0x01fd9044.
//
// Solidity: function lastRollupExitRoot() view returns(bytes32)
func (_Agglayergermock *AgglayergermockCallerSession) LastRollupExitRoot() ([32]byte, error) {
	return _Agglayergermock.Contract.LastRollupExitRoot(&_Agglayergermock.CallOpts)
}

// RollupManager is a free data retrieval call binding the contract method 0x49b7b802.
//
// Solidity: function rollupManager() view returns(address)
func (_Agglayergermock *AgglayergermockCaller) RollupManager(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "rollupManager")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// RollupManager is a free data retrieval call binding the contract method 0x49b7b802.
//
// Solidity: function rollupManager() view returns(address)
func (_Agglayergermock *AgglayergermockSession) RollupManager() (common.Address, error) {
	return _Agglayergermock.Contract.RollupManager(&_Agglayergermock.CallOpts)
}

// RollupManager is a free data retrieval call binding the contract method 0x49b7b802.
//
// Solidity: function rollupManager() view returns(address)
func (_Agglayergermock *AgglayergermockCallerSession) RollupManager() (common.Address, error) {
	return _Agglayergermock.Contract.RollupManager(&_Agglayergermock.CallOpts)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_Agglayergermock *AgglayergermockCaller) Version(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _Agglayergermock.contract.Call(opts, &out, "version")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_Agglayergermock *AgglayergermockSession) Version() (string, error) {
	return _Agglayergermock.Contract.Version(&_Agglayergermock.CallOpts)
}

// Version is a free data retrieval call binding the contract method 0x54fd4d50.
//
// Solidity: function version() pure returns(string)
func (_Agglayergermock *AgglayergermockCallerSession) Version() (string, error) {
	return _Agglayergermock.Contract.Version(&_Agglayergermock.CallOpts)
}

// Initialize is a paid mutator transaction binding the contract method 0x8129fc1c.
//
// Solidity: function initialize() returns()
func (_Agglayergermock *AgglayergermockTransactor) Initialize(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Agglayergermock.contract.Transact(opts, "initialize")
}

// Initialize is a paid mutator transaction binding the contract method 0x8129fc1c.
//
// Solidity: function initialize() returns()
func (_Agglayergermock *AgglayergermockSession) Initialize() (*types.Transaction, error) {
	return _Agglayergermock.Contract.Initialize(&_Agglayergermock.TransactOpts)
}

// Initialize is a paid mutator transaction binding the contract method 0x8129fc1c.
//
// Solidity: function initialize() returns()
func (_Agglayergermock *AgglayergermockTransactorSession) Initialize() (*types.Transaction, error) {
	return _Agglayergermock.Contract.Initialize(&_Agglayergermock.TransactOpts)
}

// InjectGER is a paid mutator transaction binding the contract method 0xa43ca6a6.
//
// Solidity: function injectGER(bytes32 _root, uint32 depositCount) returns()
func (_Agglayergermock *AgglayergermockTransactor) InjectGER(opts *bind.TransactOpts, _root [32]byte, depositCount uint32) (*types.Transaction, error) {
	return _Agglayergermock.contract.Transact(opts, "injectGER", _root, depositCount)
}

// InjectGER is a paid mutator transaction binding the contract method 0xa43ca6a6.
//
// Solidity: function injectGER(bytes32 _root, uint32 depositCount) returns()
func (_Agglayergermock *AgglayergermockSession) InjectGER(_root [32]byte, depositCount uint32) (*types.Transaction, error) {
	return _Agglayergermock.Contract.InjectGER(&_Agglayergermock.TransactOpts, _root, depositCount)
}

// InjectGER is a paid mutator transaction binding the contract method 0xa43ca6a6.
//
// Solidity: function injectGER(bytes32 _root, uint32 depositCount) returns()
func (_Agglayergermock *AgglayergermockTransactorSession) InjectGER(_root [32]byte, depositCount uint32) (*types.Transaction, error) {
	return _Agglayergermock.Contract.InjectGER(&_Agglayergermock.TransactOpts, _root, depositCount)
}

// UpdateExitRoot is a paid mutator transaction binding the contract method 0x33d6247d.
//
// Solidity: function updateExitRoot(bytes32 newRoot) returns()
func (_Agglayergermock *AgglayergermockTransactor) UpdateExitRoot(opts *bind.TransactOpts, newRoot [32]byte) (*types.Transaction, error) {
	return _Agglayergermock.contract.Transact(opts, "updateExitRoot", newRoot)
}

// UpdateExitRoot is a paid mutator transaction binding the contract method 0x33d6247d.
//
// Solidity: function updateExitRoot(bytes32 newRoot) returns()
func (_Agglayergermock *AgglayergermockSession) UpdateExitRoot(newRoot [32]byte) (*types.Transaction, error) {
	return _Agglayergermock.Contract.UpdateExitRoot(&_Agglayergermock.TransactOpts, newRoot)
}

// UpdateExitRoot is a paid mutator transaction binding the contract method 0x33d6247d.
//
// Solidity: function updateExitRoot(bytes32 newRoot) returns()
func (_Agglayergermock *AgglayergermockTransactorSession) UpdateExitRoot(newRoot [32]byte) (*types.Transaction, error) {
	return _Agglayergermock.Contract.UpdateExitRoot(&_Agglayergermock.TransactOpts, newRoot)
}

// AgglayergermockInitL1InfoRootMapIterator is returned from FilterInitL1InfoRootMap and is used to iterate over the raw logs and unpacked data for InitL1InfoRootMap events raised by the Agglayergermock contract.
type AgglayergermockInitL1InfoRootMapIterator struct {
	Event *AgglayergermockInitL1InfoRootMap // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *AgglayergermockInitL1InfoRootMapIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(AgglayergermockInitL1InfoRootMap)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(AgglayergermockInitL1InfoRootMap)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *AgglayergermockInitL1InfoRootMapIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *AgglayergermockInitL1InfoRootMapIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// AgglayergermockInitL1InfoRootMap represents a InitL1InfoRootMap event raised by the Agglayergermock contract.
type AgglayergermockInitL1InfoRootMap struct {
	LeafCount         uint32
	CurrentL1InfoRoot [32]byte
	Raw               types.Log // Blockchain specific contextual infos
}

// FilterInitL1InfoRootMap is a free log retrieval operation binding the contract event 0x11f50c71891002839c2637ce302087160298255a87f1ea60d40e8db081383fad.
//
// Solidity: event InitL1InfoRootMap(uint32 leafCount, bytes32 currentL1InfoRoot)
func (_Agglayergermock *AgglayergermockFilterer) FilterInitL1InfoRootMap(opts *bind.FilterOpts) (*AgglayergermockInitL1InfoRootMapIterator, error) {

	logs, sub, err := _Agglayergermock.contract.FilterLogs(opts, "InitL1InfoRootMap")
	if err != nil {
		return nil, err
	}
	return &AgglayergermockInitL1InfoRootMapIterator{contract: _Agglayergermock.contract, event: "InitL1InfoRootMap", logs: logs, sub: sub}, nil
}

// WatchInitL1InfoRootMap is a free log subscription operation binding the contract event 0x11f50c71891002839c2637ce302087160298255a87f1ea60d40e8db081383fad.
//
// Solidity: event InitL1InfoRootMap(uint32 leafCount, bytes32 currentL1InfoRoot)
func (_Agglayergermock *AgglayergermockFilterer) WatchInitL1InfoRootMap(opts *bind.WatchOpts, sink chan<- *AgglayergermockInitL1InfoRootMap) (event.Subscription, error) {

	logs, sub, err := _Agglayergermock.contract.WatchLogs(opts, "InitL1InfoRootMap")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(AgglayergermockInitL1InfoRootMap)
				if err := _Agglayergermock.contract.UnpackLog(event, "InitL1InfoRootMap", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseInitL1InfoRootMap is a log parse operation binding the contract event 0x11f50c71891002839c2637ce302087160298255a87f1ea60d40e8db081383fad.
//
// Solidity: event InitL1InfoRootMap(uint32 leafCount, bytes32 currentL1InfoRoot)
func (_Agglayergermock *AgglayergermockFilterer) ParseInitL1InfoRootMap(log types.Log) (*AgglayergermockInitL1InfoRootMap, error) {
	event := new(AgglayergermockInitL1InfoRootMap)
	if err := _Agglayergermock.contract.UnpackLog(event, "InitL1InfoRootMap", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// AgglayergermockInitializedIterator is returned from FilterInitialized and is used to iterate over the raw logs and unpacked data for Initialized events raised by the Agglayergermock contract.
type AgglayergermockInitializedIterator struct {
	Event *AgglayergermockInitialized // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *AgglayergermockInitializedIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(AgglayergermockInitialized)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(AgglayergermockInitialized)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *AgglayergermockInitializedIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *AgglayergermockInitializedIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// AgglayergermockInitialized represents a Initialized event raised by the Agglayergermock contract.
type AgglayergermockInitialized struct {
	Version uint8
	Raw     types.Log // Blockchain specific contextual infos
}

// FilterInitialized is a free log retrieval operation binding the contract event 0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498.
//
// Solidity: event Initialized(uint8 version)
func (_Agglayergermock *AgglayergermockFilterer) FilterInitialized(opts *bind.FilterOpts) (*AgglayergermockInitializedIterator, error) {

	logs, sub, err := _Agglayergermock.contract.FilterLogs(opts, "Initialized")
	if err != nil {
		return nil, err
	}
	return &AgglayergermockInitializedIterator{contract: _Agglayergermock.contract, event: "Initialized", logs: logs, sub: sub}, nil
}

// WatchInitialized is a free log subscription operation binding the contract event 0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498.
//
// Solidity: event Initialized(uint8 version)
func (_Agglayergermock *AgglayergermockFilterer) WatchInitialized(opts *bind.WatchOpts, sink chan<- *AgglayergermockInitialized) (event.Subscription, error) {

	logs, sub, err := _Agglayergermock.contract.WatchLogs(opts, "Initialized")
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(AgglayergermockInitialized)
				if err := _Agglayergermock.contract.UnpackLog(event, "Initialized", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseInitialized is a log parse operation binding the contract event 0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498.
//
// Solidity: event Initialized(uint8 version)
func (_Agglayergermock *AgglayergermockFilterer) ParseInitialized(log types.Log) (*AgglayergermockInitialized, error) {
	event := new(AgglayergermockInitialized)
	if err := _Agglayergermock.contract.UnpackLog(event, "Initialized", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// AgglayergermockUpdateL1InfoTreeIterator is returned from FilterUpdateL1InfoTree and is used to iterate over the raw logs and unpacked data for UpdateL1InfoTree events raised by the Agglayergermock contract.
type AgglayergermockUpdateL1InfoTreeIterator struct {
	Event *AgglayergermockUpdateL1InfoTree // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *AgglayergermockUpdateL1InfoTreeIterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(AgglayergermockUpdateL1InfoTree)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(AgglayergermockUpdateL1InfoTree)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *AgglayergermockUpdateL1InfoTreeIterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *AgglayergermockUpdateL1InfoTreeIterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// AgglayergermockUpdateL1InfoTree represents a UpdateL1InfoTree event raised by the Agglayergermock contract.
type AgglayergermockUpdateL1InfoTree struct {
	MainnetExitRoot [32]byte
	RollupExitRoot  [32]byte
	Raw             types.Log // Blockchain specific contextual infos
}

// FilterUpdateL1InfoTree is a free log retrieval operation binding the contract event 0xda61aa7823fcd807e37b95aabcbe17f03a6f3efd514176444dae191d27fd66b3.
//
// Solidity: event UpdateL1InfoTree(bytes32 indexed mainnetExitRoot, bytes32 indexed rollupExitRoot)
func (_Agglayergermock *AgglayergermockFilterer) FilterUpdateL1InfoTree(opts *bind.FilterOpts, mainnetExitRoot [][32]byte, rollupExitRoot [][32]byte) (*AgglayergermockUpdateL1InfoTreeIterator, error) {

	var mainnetExitRootRule []interface{}
	for _, mainnetExitRootItem := range mainnetExitRoot {
		mainnetExitRootRule = append(mainnetExitRootRule, mainnetExitRootItem)
	}
	var rollupExitRootRule []interface{}
	for _, rollupExitRootItem := range rollupExitRoot {
		rollupExitRootRule = append(rollupExitRootRule, rollupExitRootItem)
	}

	logs, sub, err := _Agglayergermock.contract.FilterLogs(opts, "UpdateL1InfoTree", mainnetExitRootRule, rollupExitRootRule)
	if err != nil {
		return nil, err
	}
	return &AgglayergermockUpdateL1InfoTreeIterator{contract: _Agglayergermock.contract, event: "UpdateL1InfoTree", logs: logs, sub: sub}, nil
}

// WatchUpdateL1InfoTree is a free log subscription operation binding the contract event 0xda61aa7823fcd807e37b95aabcbe17f03a6f3efd514176444dae191d27fd66b3.
//
// Solidity: event UpdateL1InfoTree(bytes32 indexed mainnetExitRoot, bytes32 indexed rollupExitRoot)
func (_Agglayergermock *AgglayergermockFilterer) WatchUpdateL1InfoTree(opts *bind.WatchOpts, sink chan<- *AgglayergermockUpdateL1InfoTree, mainnetExitRoot [][32]byte, rollupExitRoot [][32]byte) (event.Subscription, error) {

	var mainnetExitRootRule []interface{}
	for _, mainnetExitRootItem := range mainnetExitRoot {
		mainnetExitRootRule = append(mainnetExitRootRule, mainnetExitRootItem)
	}
	var rollupExitRootRule []interface{}
	for _, rollupExitRootItem := range rollupExitRoot {
		rollupExitRootRule = append(rollupExitRootRule, rollupExitRootItem)
	}

	logs, sub, err := _Agglayergermock.contract.WatchLogs(opts, "UpdateL1InfoTree", mainnetExitRootRule, rollupExitRootRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(AgglayergermockUpdateL1InfoTree)
				if err := _Agglayergermock.contract.UnpackLog(event, "UpdateL1InfoTree", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseUpdateL1InfoTree is a log parse operation binding the contract event 0xda61aa7823fcd807e37b95aabcbe17f03a6f3efd514176444dae191d27fd66b3.
//
// Solidity: event UpdateL1InfoTree(bytes32 indexed mainnetExitRoot, bytes32 indexed rollupExitRoot)
func (_Agglayergermock *AgglayergermockFilterer) ParseUpdateL1InfoTree(log types.Log) (*AgglayergermockUpdateL1InfoTree, error) {
	event := new(AgglayergermockUpdateL1InfoTree)
	if err := _Agglayergermock.contract.UnpackLog(event, "UpdateL1InfoTree", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}

// AgglayergermockUpdateL1InfoTreeV2Iterator is returned from FilterUpdateL1InfoTreeV2 and is used to iterate over the raw logs and unpacked data for UpdateL1InfoTreeV2 events raised by the Agglayergermock contract.
type AgglayergermockUpdateL1InfoTreeV2Iterator struct {
	Event *AgglayergermockUpdateL1InfoTreeV2 // Event containing the contract specifics and raw log

	contract *bind.BoundContract // Generic contract to use for unpacking event data
	event    string              // Event name to use for unpacking event data

	logs chan types.Log        // Log channel receiving the found contract events
	sub  ethereum.Subscription // Subscription for errors, completion and termination
	done bool                  // Whether the subscription completed delivering logs
	fail error                 // Occurred error to stop iteration
}

// Next advances the iterator to the subsequent event, returning whether there
// are any more events found. In case of a retrieval or parsing error, false is
// returned and Error() can be queried for the exact failure.
func (it *AgglayergermockUpdateL1InfoTreeV2Iterator) Next() bool {
	// If the iterator failed, stop iterating
	if it.fail != nil {
		return false
	}
	// If the iterator completed, deliver directly whatever's available
	if it.done {
		select {
		case log := <-it.logs:
			it.Event = new(AgglayergermockUpdateL1InfoTreeV2)
			if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
				it.fail = err
				return false
			}
			it.Event.Raw = log
			return true

		default:
			return false
		}
	}
	// Iterator still in progress, wait for either a data or an error event
	select {
	case log := <-it.logs:
		it.Event = new(AgglayergermockUpdateL1InfoTreeV2)
		if err := it.contract.UnpackLog(it.Event, it.event, log); err != nil {
			it.fail = err
			return false
		}
		it.Event.Raw = log
		return true

	case err := <-it.sub.Err():
		it.done = true
		it.fail = err
		return it.Next()
	}
}

// Error returns any retrieval or parsing error occurred during filtering.
func (it *AgglayergermockUpdateL1InfoTreeV2Iterator) Error() error {
	return it.fail
}

// Close terminates the iteration process, releasing any pending underlying
// resources.
func (it *AgglayergermockUpdateL1InfoTreeV2Iterator) Close() error {
	it.sub.Unsubscribe()
	return nil
}

// AgglayergermockUpdateL1InfoTreeV2 represents a UpdateL1InfoTreeV2 event raised by the Agglayergermock contract.
type AgglayergermockUpdateL1InfoTreeV2 struct {
	CurrentL1InfoRoot [32]byte
	LeafCount         uint32
	Blockhash         *big.Int
	MinTimestamp      uint64
	Raw               types.Log // Blockchain specific contextual infos
}

// FilterUpdateL1InfoTreeV2 is a free log retrieval operation binding the contract event 0xaf6c6cd7790e0180a4d22eb8ed846e55846f54ed10e5946db19972b5a0813a59.
//
// Solidity: event UpdateL1InfoTreeV2(bytes32 currentL1InfoRoot, uint32 indexed leafCount, uint256 blockhash, uint64 minTimestamp)
func (_Agglayergermock *AgglayergermockFilterer) FilterUpdateL1InfoTreeV2(opts *bind.FilterOpts, leafCount []uint32) (*AgglayergermockUpdateL1InfoTreeV2Iterator, error) {

	var leafCountRule []interface{}
	for _, leafCountItem := range leafCount {
		leafCountRule = append(leafCountRule, leafCountItem)
	}

	logs, sub, err := _Agglayergermock.contract.FilterLogs(opts, "UpdateL1InfoTreeV2", leafCountRule)
	if err != nil {
		return nil, err
	}
	return &AgglayergermockUpdateL1InfoTreeV2Iterator{contract: _Agglayergermock.contract, event: "UpdateL1InfoTreeV2", logs: logs, sub: sub}, nil
}

// WatchUpdateL1InfoTreeV2 is a free log subscription operation binding the contract event 0xaf6c6cd7790e0180a4d22eb8ed846e55846f54ed10e5946db19972b5a0813a59.
//
// Solidity: event UpdateL1InfoTreeV2(bytes32 currentL1InfoRoot, uint32 indexed leafCount, uint256 blockhash, uint64 minTimestamp)
func (_Agglayergermock *AgglayergermockFilterer) WatchUpdateL1InfoTreeV2(opts *bind.WatchOpts, sink chan<- *AgglayergermockUpdateL1InfoTreeV2, leafCount []uint32) (event.Subscription, error) {

	var leafCountRule []interface{}
	for _, leafCountItem := range leafCount {
		leafCountRule = append(leafCountRule, leafCountItem)
	}

	logs, sub, err := _Agglayergermock.contract.WatchLogs(opts, "UpdateL1InfoTreeV2", leafCountRule)
	if err != nil {
		return nil, err
	}
	return event.NewSubscription(func(quit <-chan struct{}) error {
		defer sub.Unsubscribe()
		for {
			select {
			case log := <-logs:
				// New log arrived, parse the event and forward to the user
				event := new(AgglayergermockUpdateL1InfoTreeV2)
				if err := _Agglayergermock.contract.UnpackLog(event, "UpdateL1InfoTreeV2", log); err != nil {
					return err
				}
				event.Raw = log

				select {
				case sink <- event:
				case err := <-sub.Err():
					return err
				case <-quit:
					return nil
				}
			case err := <-sub.Err():
				return err
			case <-quit:
				return nil
			}
		}
	}), nil
}

// ParseUpdateL1InfoTreeV2 is a log parse operation binding the contract event 0xaf6c6cd7790e0180a4d22eb8ed846e55846f54ed10e5946db19972b5a0813a59.
//
// Solidity: event UpdateL1InfoTreeV2(bytes32 currentL1InfoRoot, uint32 indexed leafCount, uint256 blockhash, uint64 minTimestamp)
func (_Agglayergermock *AgglayergermockFilterer) ParseUpdateL1InfoTreeV2(log types.Log) (*AgglayergermockUpdateL1InfoTreeV2, error) {
	event := new(AgglayergermockUpdateL1InfoTreeV2)
	if err := _Agglayergermock.contract.UnpackLog(event, "UpdateL1InfoTreeV2", log); err != nil {
		return nil, err
	}
	event.Raw = log
	return event, nil
}
