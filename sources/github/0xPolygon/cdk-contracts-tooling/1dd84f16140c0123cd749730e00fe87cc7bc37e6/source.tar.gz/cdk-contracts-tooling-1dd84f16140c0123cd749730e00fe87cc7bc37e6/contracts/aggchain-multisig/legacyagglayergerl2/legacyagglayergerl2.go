// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package legacyagglayergerl2

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

// Legacyagglayergerl2MetaData contains all meta data concerning the Legacyagglayergerl2 contract.
var Legacyagglayergerl2MetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_bridgeAddress\",\"type\":\"address\"}],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"inputs\":[],\"name\":\"GlobalExitRootAlreadySet\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"GlobalExitRootNotFound\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"InvalidZeroAddress\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyAllowedContracts\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyGlobalExitRootRemover\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyGlobalExitRootUpdater\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyPendingGlobalExitRootRemover\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"OnlyPendingGlobalExitRootUpdater\",\"type\":\"error\"},{\"inputs\":[],\"name\":\"bridgeAddress\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"name\":\"globalExitRootMap\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"lastRollupExitRoot\",\"outputs\":[{\"internalType\":\"bytes32\",\"name\":\"\",\"type\":\"bytes32\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"bytes32\",\"name\":\"newRoot\",\"type\":\"bytes32\"}],\"name\":\"updateExitRoot\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"}]",
	Bin: "0x60a0604052348015600e575f5ffd5b5060405161022f38038061022f833981016040819052602b91603b565b6001600160a01b03166080526066565b5f60208284031215604a575f5ffd5b81516001600160a01b0381168114605f575f5ffd5b9392505050565b6080516101ab6100845f395f818160a3015261010201526101ab5ff3fe608060405234801561000f575f5ffd5b506004361061004a575f3560e01c806301fd90441461004e578063257b36321461006a57806333d6247d14610089578063a3c573eb1461009e575b5f5ffd5b61005760015481565b6040519081526020015b60405180910390f35b61005761007836600461015e565b5f6020819052908152604090205481565b61009c61009736600461015e565b6100ea565b005b6100c57f000000000000000000000000000000000000000000000000000000000000000081565b60405173ffffffffffffffffffffffffffffffffffffffff9091168152602001610061565b3373ffffffffffffffffffffffffffffffffffffffff7f00000000000000000000000000000000000000000000000000000000000000001614610159576040517fb49365dd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b600155565b5f6020828403121561016e575f5ffd5b503591905056fea2646970667358221220fbd91ea9eaf44967c1036a6d6cca69117e78bf3efd67032bcff8d4a34606633e64736f6c634300081c0033",
}

// Legacyagglayergerl2ABI is the input ABI used to generate the binding from.
// Deprecated: Use Legacyagglayergerl2MetaData.ABI instead.
var Legacyagglayergerl2ABI = Legacyagglayergerl2MetaData.ABI

// Legacyagglayergerl2Bin is the compiled bytecode used for deploying new contracts.
// Deprecated: Use Legacyagglayergerl2MetaData.Bin instead.
var Legacyagglayergerl2Bin = Legacyagglayergerl2MetaData.Bin

// DeployLegacyagglayergerl2 deploys a new Ethereum contract, binding an instance of Legacyagglayergerl2 to it.
func DeployLegacyagglayergerl2(auth *bind.TransactOpts, backend bind.ContractBackend, _bridgeAddress common.Address) (common.Address, *types.Transaction, *Legacyagglayergerl2, error) {
	parsed, err := Legacyagglayergerl2MetaData.GetAbi()
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	if parsed == nil {
		return common.Address{}, nil, nil, errors.New("GetABI returned nil")
	}

	address, tx, contract, err := bind.DeployContract(auth, *parsed, common.FromHex(Legacyagglayergerl2Bin), backend, _bridgeAddress)
	if err != nil {
		return common.Address{}, nil, nil, err
	}
	return address, tx, &Legacyagglayergerl2{Legacyagglayergerl2Caller: Legacyagglayergerl2Caller{contract: contract}, Legacyagglayergerl2Transactor: Legacyagglayergerl2Transactor{contract: contract}, Legacyagglayergerl2Filterer: Legacyagglayergerl2Filterer{contract: contract}}, nil
}

// Legacyagglayergerl2 is an auto generated Go binding around an Ethereum contract.
type Legacyagglayergerl2 struct {
	Legacyagglayergerl2Caller     // Read-only binding to the contract
	Legacyagglayergerl2Transactor // Write-only binding to the contract
	Legacyagglayergerl2Filterer   // Log filterer for contract events
}

// Legacyagglayergerl2Caller is an auto generated read-only Go binding around an Ethereum contract.
type Legacyagglayergerl2Caller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Legacyagglayergerl2Transactor is an auto generated write-only Go binding around an Ethereum contract.
type Legacyagglayergerl2Transactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Legacyagglayergerl2Filterer is an auto generated log filtering Go binding around an Ethereum contract events.
type Legacyagglayergerl2Filterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Legacyagglayergerl2Session is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type Legacyagglayergerl2Session struct {
	Contract     *Legacyagglayergerl2 // Generic contract binding to set the session for
	CallOpts     bind.CallOpts        // Call options to use throughout this session
	TransactOpts bind.TransactOpts    // Transaction auth options to use throughout this session
}

// Legacyagglayergerl2CallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type Legacyagglayergerl2CallerSession struct {
	Contract *Legacyagglayergerl2Caller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts              // Call options to use throughout this session
}

// Legacyagglayergerl2TransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type Legacyagglayergerl2TransactorSession struct {
	Contract     *Legacyagglayergerl2Transactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts              // Transaction auth options to use throughout this session
}

// Legacyagglayergerl2Raw is an auto generated low-level Go binding around an Ethereum contract.
type Legacyagglayergerl2Raw struct {
	Contract *Legacyagglayergerl2 // Generic contract binding to access the raw methods on
}

// Legacyagglayergerl2CallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type Legacyagglayergerl2CallerRaw struct {
	Contract *Legacyagglayergerl2Caller // Generic read-only contract binding to access the raw methods on
}

// Legacyagglayergerl2TransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type Legacyagglayergerl2TransactorRaw struct {
	Contract *Legacyagglayergerl2Transactor // Generic write-only contract binding to access the raw methods on
}

// NewLegacyagglayergerl2 creates a new instance of Legacyagglayergerl2, bound to a specific deployed contract.
func NewLegacyagglayergerl2(address common.Address, backend bind.ContractBackend) (*Legacyagglayergerl2, error) {
	contract, err := bindLegacyagglayergerl2(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Legacyagglayergerl2{Legacyagglayergerl2Caller: Legacyagglayergerl2Caller{contract: contract}, Legacyagglayergerl2Transactor: Legacyagglayergerl2Transactor{contract: contract}, Legacyagglayergerl2Filterer: Legacyagglayergerl2Filterer{contract: contract}}, nil
}

// NewLegacyagglayergerl2Caller creates a new read-only instance of Legacyagglayergerl2, bound to a specific deployed contract.
func NewLegacyagglayergerl2Caller(address common.Address, caller bind.ContractCaller) (*Legacyagglayergerl2Caller, error) {
	contract, err := bindLegacyagglayergerl2(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &Legacyagglayergerl2Caller{contract: contract}, nil
}

// NewLegacyagglayergerl2Transactor creates a new write-only instance of Legacyagglayergerl2, bound to a specific deployed contract.
func NewLegacyagglayergerl2Transactor(address common.Address, transactor bind.ContractTransactor) (*Legacyagglayergerl2Transactor, error) {
	contract, err := bindLegacyagglayergerl2(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &Legacyagglayergerl2Transactor{contract: contract}, nil
}

// NewLegacyagglayergerl2Filterer creates a new log filterer instance of Legacyagglayergerl2, bound to a specific deployed contract.
func NewLegacyagglayergerl2Filterer(address common.Address, filterer bind.ContractFilterer) (*Legacyagglayergerl2Filterer, error) {
	contract, err := bindLegacyagglayergerl2(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &Legacyagglayergerl2Filterer{contract: contract}, nil
}

// bindLegacyagglayergerl2 binds a generic wrapper to an already deployed contract.
func bindLegacyagglayergerl2(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := Legacyagglayergerl2MetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Legacyagglayergerl2 *Legacyagglayergerl2Raw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Legacyagglayergerl2.Contract.Legacyagglayergerl2Caller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Legacyagglayergerl2 *Legacyagglayergerl2Raw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Legacyagglayergerl2.Contract.Legacyagglayergerl2Transactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Legacyagglayergerl2 *Legacyagglayergerl2Raw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Legacyagglayergerl2.Contract.Legacyagglayergerl2Transactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Legacyagglayergerl2 *Legacyagglayergerl2CallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Legacyagglayergerl2.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Legacyagglayergerl2 *Legacyagglayergerl2TransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Legacyagglayergerl2.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Legacyagglayergerl2 *Legacyagglayergerl2TransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Legacyagglayergerl2.Contract.contract.Transact(opts, method, params...)
}

// BridgeAddress is a free data retrieval call binding the contract method 0xa3c573eb.
//
// Solidity: function bridgeAddress() view returns(address)
func (_Legacyagglayergerl2 *Legacyagglayergerl2Caller) BridgeAddress(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _Legacyagglayergerl2.contract.Call(opts, &out, "bridgeAddress")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// BridgeAddress is a free data retrieval call binding the contract method 0xa3c573eb.
//
// Solidity: function bridgeAddress() view returns(address)
func (_Legacyagglayergerl2 *Legacyagglayergerl2Session) BridgeAddress() (common.Address, error) {
	return _Legacyagglayergerl2.Contract.BridgeAddress(&_Legacyagglayergerl2.CallOpts)
}

// BridgeAddress is a free data retrieval call binding the contract method 0xa3c573eb.
//
// Solidity: function bridgeAddress() view returns(address)
func (_Legacyagglayergerl2 *Legacyagglayergerl2CallerSession) BridgeAddress() (common.Address, error) {
	return _Legacyagglayergerl2.Contract.BridgeAddress(&_Legacyagglayergerl2.CallOpts)
}

// GlobalExitRootMap is a free data retrieval call binding the contract method 0x257b3632.
//
// Solidity: function globalExitRootMap(bytes32 ) view returns(uint256)
func (_Legacyagglayergerl2 *Legacyagglayergerl2Caller) GlobalExitRootMap(opts *bind.CallOpts, arg0 [32]byte) (*big.Int, error) {
	var out []interface{}
	err := _Legacyagglayergerl2.contract.Call(opts, &out, "globalExitRootMap", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GlobalExitRootMap is a free data retrieval call binding the contract method 0x257b3632.
//
// Solidity: function globalExitRootMap(bytes32 ) view returns(uint256)
func (_Legacyagglayergerl2 *Legacyagglayergerl2Session) GlobalExitRootMap(arg0 [32]byte) (*big.Int, error) {
	return _Legacyagglayergerl2.Contract.GlobalExitRootMap(&_Legacyagglayergerl2.CallOpts, arg0)
}

// GlobalExitRootMap is a free data retrieval call binding the contract method 0x257b3632.
//
// Solidity: function globalExitRootMap(bytes32 ) view returns(uint256)
func (_Legacyagglayergerl2 *Legacyagglayergerl2CallerSession) GlobalExitRootMap(arg0 [32]byte) (*big.Int, error) {
	return _Legacyagglayergerl2.Contract.GlobalExitRootMap(&_Legacyagglayergerl2.CallOpts, arg0)
}

// LastRollupExitRoot is a free data retrieval call binding the contract method 0x01fd9044.
//
// Solidity: function lastRollupExitRoot() view returns(bytes32)
func (_Legacyagglayergerl2 *Legacyagglayergerl2Caller) LastRollupExitRoot(opts *bind.CallOpts) ([32]byte, error) {
	var out []interface{}
	err := _Legacyagglayergerl2.contract.Call(opts, &out, "lastRollupExitRoot")

	if err != nil {
		return *new([32]byte), err
	}

	out0 := *abi.ConvertType(out[0], new([32]byte)).(*[32]byte)

	return out0, err

}

// LastRollupExitRoot is a free data retrieval call binding the contract method 0x01fd9044.
//
// Solidity: function lastRollupExitRoot() view returns(bytes32)
func (_Legacyagglayergerl2 *Legacyagglayergerl2Session) LastRollupExitRoot() ([32]byte, error) {
	return _Legacyagglayergerl2.Contract.LastRollupExitRoot(&_Legacyagglayergerl2.CallOpts)
}

// LastRollupExitRoot is a free data retrieval call binding the contract method 0x01fd9044.
//
// Solidity: function lastRollupExitRoot() view returns(bytes32)
func (_Legacyagglayergerl2 *Legacyagglayergerl2CallerSession) LastRollupExitRoot() ([32]byte, error) {
	return _Legacyagglayergerl2.Contract.LastRollupExitRoot(&_Legacyagglayergerl2.CallOpts)
}

// UpdateExitRoot is a paid mutator transaction binding the contract method 0x33d6247d.
//
// Solidity: function updateExitRoot(bytes32 newRoot) returns()
func (_Legacyagglayergerl2 *Legacyagglayergerl2Transactor) UpdateExitRoot(opts *bind.TransactOpts, newRoot [32]byte) (*types.Transaction, error) {
	return _Legacyagglayergerl2.contract.Transact(opts, "updateExitRoot", newRoot)
}

// UpdateExitRoot is a paid mutator transaction binding the contract method 0x33d6247d.
//
// Solidity: function updateExitRoot(bytes32 newRoot) returns()
func (_Legacyagglayergerl2 *Legacyagglayergerl2Session) UpdateExitRoot(newRoot [32]byte) (*types.Transaction, error) {
	return _Legacyagglayergerl2.Contract.UpdateExitRoot(&_Legacyagglayergerl2.TransactOpts, newRoot)
}

// UpdateExitRoot is a paid mutator transaction binding the contract method 0x33d6247d.
//
// Solidity: function updateExitRoot(bytes32 newRoot) returns()
func (_Legacyagglayergerl2 *Legacyagglayergerl2TransactorSession) UpdateExitRoot(newRoot [32]byte) (*types.Transaction, error) {
	return _Legacyagglayergerl2.Contract.UpdateExitRoot(&_Legacyagglayergerl2.TransactOpts, newRoot)
}
