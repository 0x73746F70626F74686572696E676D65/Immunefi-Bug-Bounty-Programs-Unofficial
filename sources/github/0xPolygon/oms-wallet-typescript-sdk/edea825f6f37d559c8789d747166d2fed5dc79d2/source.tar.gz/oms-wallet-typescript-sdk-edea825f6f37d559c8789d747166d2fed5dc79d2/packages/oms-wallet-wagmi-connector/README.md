# @polygonlabs/oms-wallet-wagmi-connector

Wagmi connector for an active `@polygonlabs/oms-wallet` SDK instance.

## Installation

```bash
pnpm add @polygonlabs/oms-wallet-wagmi-connector @polygonlabs/oms-wallet @wagmi/core viem
```

For npm or yarn projects:

```bash
npm install @polygonlabs/oms-wallet-wagmi-connector @polygonlabs/oms-wallet @wagmi/core viem
yarn add @polygonlabs/oms-wallet-wagmi-connector @polygonlabs/oms-wallet @wagmi/core viem
```

Peer dependencies:

| Package | Range |
|---|---|
| `@polygonlabs/oms-wallet` | The same release version as this package (the two are versioned in lockstep) |
| `@wagmi/core` | `>=3.5.0 <4` |
| `viem` | `>=2.48.4 <3` |

This package is ESM-only and requires Node.js 22 or later.

## Basic setup

```ts
import { connect, createConfig, disconnect, http } from '@wagmi/core'
import { polygon } from 'viem/chains'
import { FeeOptionSelector, OMSWallet } from '@polygonlabs/oms-wallet'
import { omsWalletConnector } from '@polygonlabs/oms-wallet-wagmi-connector'

const omsWallet = new OMSWallet({
  publishableKey: 'your-publishable-key',
})

const omsConnector = omsWalletConnector({
  omsWallet,
  initialChainId: polygon.id,
  transactionOptions: {
    selectFeeOption: FeeOptionSelector.firstAvailable,
  },
})

export const wagmiConfig = createConfig({
  chains: [polygon],
  transports: {
    [polygon.id]: http(),
  },
  connectors: [omsConnector],
})
```

## Authentication

The connector does not render authentication UI. Authenticate with the OMS Wallet SDK first, then call wagmi `connect` with the OMS Wallet connector once `omsWallet.wallet.walletAddress` is set.

The connector is Ethereum-only even though the core SDK also supports Solana wallets. Select an
Ethereum wallet before connecting. Connecting or requesting accounts with an active Solana wallet
rejects with `OMSWalletProviderRpcError` code `4100`.

Email example:

```ts
await omsWallet.wallet.startEmailAuth({ email })
await omsWallet.wallet.completeEmailAuth({ code })

if (!omsWallet.wallet.walletAddress) {
  throw new Error('OMS auth completed without an active wallet.')
}

await connect(wagmiConfig, {
  connector: omsConnector,
  chainId: polygon.id,
})
```

For redirect-based OIDC flows such as Google or Apple, complete the SDK redirect callback first, then connect through wagmi once the wallet session is active.

## Disconnect

Wagmi `disconnect()` only disconnects the wagmi connector. It does not sign out the OMS Wallet SDK session, and it prevents wagmi from automatically reconnecting the OMS Wallet connector on page refresh until the app calls wagmi `connect()` again.

To sign out completely, disconnect wagmi state and then sign out with the SDK:

```ts
await disconnect(wagmiConfig)
await omsWallet.wallet.signOut()
```

## Networks

OMS `Network` values are not wagmi chain definitions. Wagmi still needs viem `Chain` objects with RPC transport configuration. Use `wagmi/chains`, `viem/chains`, or custom viem `Chain` objects.

By default, the connector validates OMS support with `Object.values(Networks)`. Pass `networks` only when you intentionally want a narrower set of SDK-defined OMS networks for this connector instance.

The connector validates `initialChainId`, `switchChain`, and provider chain switches against both the wagmi chain list and the OMS network list. A transaction `chainId` is used for that transaction without switching the connector's current chain, and must be supported by OMS.

## Fee options

Wagmi transaction parameters do not include OMS fee-option preferences. Pass `transactionOptions` to the connector to apply static options or resolve options per transaction request.

```ts
import { TransactionMode } from '@polygonlabs/oms-wallet'

omsWalletConnector({
  omsWallet,
  transactionOptions: ({ chainId, request }) => ({
    mode: TransactionMode.Relayer,
    selectFeeOption: async (feeOptions) => {
      const usdc = feeOptions.find(option => option.feeOption.token.symbol === 'USDC')
      return usdc?.selection
    },
  }),
})
```

The SDK calls `selectFeeOption` after preparing the transaction. For an unsponsored transaction, the
selector receives `FeeOptionWithBalance[]`, including each WaaS fee option and wallet balance data
when the indexer can load it. For a sponsored transaction, it receives an empty array; return
`undefined` to continue or throw to stop execution. Use `FeeOptionSelector.firstAvailable` to handle
both cases and choose the first affordable option when payment is required, or return
`option.selection` from a custom selector. Without a selector, the SDK keeps sponsored transactions
fee-free and otherwise chooses the first returned fee option.

For React UI, keep `selectFeeOption` wired in the connector initializer and bridge it into a modal or sheet with app state. The workspace wagmi example shows this as a hook-driven modal; see `examples/wagmi/src/feeOptionSelectionBridge.ts`, `examples/wagmi/src/useFeeOptionSelection.ts`, and the fee option panel in `examples/wagmi/src/App.tsx`.

## Transactions

The connector always waits for an EVM transaction hash because wagmi `sendTransaction` must return a hash. `waitForStatus: false` is not supported through this connector; use the SDK `wallet.sendTransaction` directly when you need to work with OMS `txnId` before a hash is available.

Supported transaction fields:

- `from`: validated against the active OMS Wallet address when present.
- `to`: required; contract deployment is not supported by this connector today.
- `value`
- `data`
- `chainId`

The connector ignores wallet-managed execution fields that OMS Wallet does not accept through this path: `gas`, `gasPrice`, `maxFeePerGas`, `maxPriorityFeePerGas`, `nonce`, `type`, and `accessList`. Unknown transaction fields are rejected.

## Provider Scope

Use this package through wagmi connector APIs. Do not treat `getProvider()` as a general RPC provider.

Supported provider methods are limited to the wallet operations and state queries that map to the SDK today: `eth_chainId`, `net_version`, `eth_accounts`, `eth_requestAccounts`, `wallet_switchEthereumChain`, `personal_sign`, `eth_signTypedData_v4`, `eth_sendTransaction`, `wallet_sendTransaction`, and `wallet_getCapabilities`.

Unsupported methods include direct read/RPC methods such as `eth_call`, `eth_estimateGas`, `eth_getBalance`, `eth_getCode`, `eth_getTransactionCount`, `eth_getTransactionReceipt`, and `eth_blockNumber`. Use wagmi public transports for reads, or use `omsWallet.wallet` directly for OMS Wallet SDK operations.

Raw byte message signing is not supported because OMS Wallet signs string messages. `eth_sign` and legacy `eth_signTypedData` are not supported; use `personal_sign` and `eth_signTypedData_v4`.

`wallet_getCapabilities` returns no capabilities unless OMS Wallet adds support for capability methods.
