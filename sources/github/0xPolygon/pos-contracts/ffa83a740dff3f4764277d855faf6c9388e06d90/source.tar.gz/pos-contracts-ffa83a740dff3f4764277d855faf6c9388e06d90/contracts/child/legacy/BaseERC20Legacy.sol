// SPDX-License-Identifier: MIT
pragma solidity ^0.5.2;

import {ChildTokenLegacy} from "./ChildTokenLegacy.sol";

// FROZEN. Reproduces the old on-chain child-token code embedded in the immutable
// plasma ChildChain 0xD9c7C4ED4B66858301D0cb28Cc88bf655Fe34861 (solc 0.5.11,
// bor-chain-id 137). Do not edit.
//
// Old-code marker preserved vs the modern BaseERC20.sol: transferWithSig builds
// the digest with getTokenTransferOrderHash (which uses the CACHED
// hashEIP712Message domain hash), NOT the modern
// hashEIP712MessageWithAddress(..., address(this)).
contract BaseERC20Legacy is ChildTokenLegacy {
    event Deposit(
        address indexed token,
        address indexed from,
        uint256 amount,
        uint256 input1,
        uint256 output1
    );

    event Withdraw(
        address indexed token,
        address indexed from,
        uint256 amount,
        uint256 input1,
        uint256 output1
    );

    event LogTransfer(
        address indexed token,
        address indexed from,
        address indexed to,
        uint256 amount,
        uint256 input1,
        uint256 input2,
        uint256 output1,
        uint256 output2
    );

    constructor() public {}

    function transferWithSig(
        bytes calldata sig,
        uint256 amount,
        bytes32 data,
        uint256 expiration,
        address to
    ) external returns (address from) {
        require(amount > 0);
        require(expiration == 0 || block.number <= expiration, "Signature is expired");

        bytes32 dataHash = getTokenTransferOrderHash(msg.sender, amount, data, expiration);
        require(disabledHashes[dataHash] == false, "Sig deactivated");
        disabledHashes[dataHash] = true;

        from = ecrecovery(dataHash, sig);
        _transferFrom(from, address(uint160(to)), amount);
    }

    function balanceOf(address account) external view returns (uint256);
    function _transfer(address sender, address recipient, uint256 amount) internal;

    /// @param from Address from where tokens are withdrawn.
    /// @param to Address to where tokens are sent.
    /// @param value Number of tokens to transfer.
    /// @return Returns success of function call.
    function _transferFrom(address from, address to, uint256 value) internal returns (bool) {
        uint256 input1 = this.balanceOf(from);
        uint256 input2 = this.balanceOf(to);
        _transfer(from, to, value);
        emit LogTransfer(token, from, to, value, input1, input2, this.balanceOf(from), this.balanceOf(to));
        return true;
    }
}
