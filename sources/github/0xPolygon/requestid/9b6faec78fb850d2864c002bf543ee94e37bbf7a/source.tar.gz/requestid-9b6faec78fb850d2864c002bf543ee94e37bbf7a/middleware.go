package requestid

import (
	"context"
	"net/http"
	"time"

	"github.com/0xPolygon/typeid"
)

// MaxClockDrift bounds how far the timestamp embedded in an inbound
// Request-Id may deviate from the server clock. IDs outside this window
// are discarded and replaced with a freshly minted one.
//
// Defaults to 5 minutes. Set to 0 to disable the drift check.
var MaxClockDrift = 5 * time.Minute

// Middleware reads the request ID from the inbound Request-Id header,
// validates it as a typeid (req_…) whose embedded UUIDv7 timestamp is within
// MaxClockDrift of the server clock, and otherwise mints a fresh one.
// The (possibly new) ID is echoed on the response and stored in ctx.
func Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get(Header)
		if !validInbound(id) {
			id = New()
		}

		ctx := context.WithValue(r.Context(), ctxKey{}, id)
		w.Header().Set(Header, id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// validInbound returns true iff s parses as a typeid with the "req" prefix
// and its embedded UUIDv7 timestamp is within MaxClockDrift of now.
// MaxClockDrift == 0 disables the drift check.
func validInbound(s string) bool {
	parsed, err := typeid.ParseUUID[reqPrefix](s)
	if err != nil {
		return false
	}
	if MaxClockDrift == 0 {
		return true
	}
	return time.Since(parsed.GetTime()).Abs() <= MaxClockDrift
}
