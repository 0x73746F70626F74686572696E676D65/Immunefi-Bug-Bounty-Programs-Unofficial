package requestid

import (
	"context"
	"log/slog"
)

// LogKey is the slog attribute key used to log the request ID.
var LogKey string = "requestId"

/*
LogHandler wraps an slog.Handler so that any log record produced via the
*Context variants automatically carries the request ID from ctx.

	slog.Log()
	slog.DebugContext()
	slog.InfoContext()
	slog.WarnContext()
	slog.ErrorContext()

Example:

	ctx := requestid.NewContext(context.Background())
	handler := requestid.LogHandler(slog.NewJSONHandler(os.Stdout, nil))
	logger := slog.New(handler)
	logger.InfoContext(ctx, "message")

This would log

	{"time":"2025-04-01T13:17:43.097789397Z","level":"INFO","msg":"message","requestId":"req_01kmfjypewe1wrfeb01wjfxand"}
*/
func LogHandler(handler slog.Handler) slog.Handler {
	return &logHandler{
		handler: handler,
	}
}

type logHandler struct {
	handler slog.Handler
}

func (l *logHandler) Enabled(ctx context.Context, level slog.Level) bool {
	return l.handler.Enabled(ctx, level)
}

func (l *logHandler) Handle(ctx context.Context, record slog.Record) error {
	if id := FromContext(ctx); id != "" {
		record.AddAttrs(slog.String(LogKey, id))
	}

	return l.handler.Handle(ctx, record)
}

func (l *logHandler) WithAttrs(attrs []slog.Attr) slog.Handler {
	return &logHandler{
		handler: l.handler.WithAttrs(attrs),
	}
}

func (l *logHandler) WithGroup(name string) slog.Handler {
	return &logHandler{
		handler: l.handler.WithGroup(name),
	}
}
