module github.com/0xPolygon/requestid

go 1.21

// replace github.com/0xPolygon/typeid => ../typeid

require github.com/0xPolygon/typeid v0.3.0

require github.com/google/uuid v1.6.0 // indirect
