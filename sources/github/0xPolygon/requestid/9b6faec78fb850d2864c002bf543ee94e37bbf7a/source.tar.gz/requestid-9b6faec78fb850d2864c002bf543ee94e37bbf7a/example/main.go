package main

import (
	"fmt"
	"log/slog"
	"math/rand"
	"net/http"
	"net/http/httputil"
	"net/url"
	"time"

	"github.com/0xPolygon/requestid"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/httplog/v2"
	"github.com/go-chi/transport"
)

func main() {
	// Set Request-Id on all outgoing HTTP requests globally.
	http.DefaultTransport = transport.Chain(
		http.DefaultTransport,
		transport.SetHeader("User-Agent", "my-app/v1.0.0"),
		requestid.Transport,
	)

	// Send test request.
	go func() {
		time.Sleep(time.Millisecond * time.Duration(rand.Intn(800)+200))

		req, _ := http.NewRequest("GET", "http://localhost:3333/proxy/proxy", nil)
		_, _ = http.DefaultClient.Do(req)
	}()

	// HTTP server with Request-Id middleware + logging.
	r := chi.NewRouter()
	r.Use(requestid.Middleware)
	r.Use(httplog.RequestLogger(logger()))
	r.Use(middleware.Recoverer)

	r.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx := r.Context()

			// Log requestId to request logger.
			id := requestid.FromContext(r.Context())
			httplog.LogEntrySetField(ctx, "requestId", slog.StringValue(id))

			next.ServeHTTP(w, r.WithContext(ctx))
		})
	})

	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(requestid.FromContext(r.Context())))
	})

	r.Get("/proxy", func(w http.ResponseWriter, r *http.Request) {
		reverseProxyTo, _ := url.Parse("http://localhost:3333")
		r.URL.Path = "/"
		proxy := httputil.NewSingleHostReverseProxy(reverseProxyTo)
		proxy.ServeHTTP(w, r)
	})

	r.Get("/proxy/proxy", func(w http.ResponseWriter, r *http.Request) {
		reverseProxyTo, _ := url.Parse("http://localhost:3333")
		r.URL.Path = "/proxy"
		proxy := httputil.NewSingleHostReverseProxy(reverseProxyTo)
		proxy.ServeHTTP(w, r)
	})

	fmt.Println(`Try sending a sample request in another terminal and see Request-Id propagation:`)
	fmt.Println(`$ curl http://localhost:3333/proxy/proxy`)
	fmt.Println(`$ curl -H "Request-Id: req_01kmfjypewe1wrfeb01wjfxand" http://localhost:3333/proxy/proxy`)
	fmt.Println()
	fmt.Println(`server listening on :3333`)

	http.ListenAndServe(":3333", r)
}

func logger() *httplog.Logger {
	return httplog.NewLogger("httplog-example", httplog.Options{
		LogLevel:         slog.LevelDebug,
		RequestHeaders:   false,
		ResponseHeaders:  false,
		JSON:             false,
		Concise:          true,
		MessageFieldName: "message",
		LevelFieldName:   "severity",
		TimeFieldFormat:  time.RFC3339,
		Tags: map[string]string{
			"version": "v0.1.0",
			"env":     "dev",
		},
	})
}
