module github.com/0xPolygon/requestid/example

go 1.21

require (
	github.com/0xPolygon/requestid v0.0.0-00010101000000-000000000000
	github.com/go-chi/chi/v5 v5.2.2
	github.com/go-chi/httplog/v2 v2.0.9
	github.com/go-chi/transport v0.1.0
)

require (
	github.com/0xPolygon/typeid v0.2.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	moul.io/http2curl/v2 v2.3.0 // indirect
)

replace github.com/0xPolygon/requestid => ../
