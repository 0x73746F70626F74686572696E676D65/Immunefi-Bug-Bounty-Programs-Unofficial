package requestid

import (
	"context"
	"net/http"

	"github.com/0xPolygon/typeid"
)

// Header is the HTTP header used to propagate the request ID across services.
var Header = http.CanonicalHeaderKey("Request-Id")

type reqPrefix struct{}

func (reqPrefix) Prefix() string { return "req" }

// RequestID is a typeid-encoded UUIDv7 with a fixed "req" prefix.
type RequestID = typeid.UUID[reqPrefix]

type ctxKey struct{}

// FromContext returns the request ID stored in ctx, or "" if none is set.
func FromContext(ctx context.Context) string {
	id, _ := ctx.Value(ctxKey{}).(string)
	return id
}

// NewContext returns ctx with a request ID attached. If ctx already carries
// one, it is returned unchanged.
func NewContext(ctx context.Context) context.Context {
	if id, ok := ctx.Value(ctxKey{}).(string); ok && id != "" {
		return ctx
	}
	return context.WithValue(ctx, ctxKey{}, New())
}

// SetHeader writes the request ID from ctx onto req. If ctx has no request ID,
// a fresh one is minted for the header (but not stored back into ctx).
func SetHeader(ctx context.Context, req *http.Request) {
	id, ok := ctx.Value(ctxKey{}).(string)
	if !ok || id == "" {
		id = New()
	}
	req.Header.Set(Header, id)
}

// New mints a fresh request ID in the canonical "req_…" form.
//
// Panics only if the OS clock is unreadable, which is treated as unrecoverable.
func New() string {
	id, err := typeid.NewUUID[reqPrefix]()
	if err != nil {
		panic(err)
	}
	return id.String()
}
