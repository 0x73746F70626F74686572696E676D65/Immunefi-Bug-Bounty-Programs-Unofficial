// Command requestid mints or inspects request IDs.
package main

import (
	"fmt"
	"os"
	"time"

	"github.com/0xPolygon/requestid"
	"github.com/0xPolygon/typeid"
)

const usage = `requestid                    # mint a fresh req_… ID
requestid req_01k… [req_…]   # inspect one or more IDs

With arguments, prints one line per ID:
  <id> <uuid> <YYYY-MM-DD HH:MM:SS> (<duration> ago)`

const timeFormat = "2006-01-02 15:04:05"

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		fmt.Println(requestid.New())
		os.Exit(0)
	}

	exitCode := 0
	for _, a := range args {
		id, err := typeid.ParseAnyUUID(a)
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s: %v\n", a, err)
			exitCode = 1
			continue
		}
		ts := id.GetTime()
		fmt.Printf("%v %v %v (%v ago)\n", id, id.UUID(), ts.Format(timeFormat), time.Since(ts).Truncate(time.Second))
	}
	os.Exit(exitCode)
}
