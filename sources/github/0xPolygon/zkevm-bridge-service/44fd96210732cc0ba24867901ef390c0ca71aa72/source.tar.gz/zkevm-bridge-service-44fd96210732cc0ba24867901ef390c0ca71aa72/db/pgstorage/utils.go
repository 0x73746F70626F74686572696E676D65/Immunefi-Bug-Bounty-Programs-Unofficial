package pgstorage

import (
	"context"
	"os"
	"strconv"
	"strings"

	"github.com/0xPolygon/zkevm-bridge-service/etherman"
	"github.com/0xPolygon/zkevm-bridge-service/log"
	"github.com/ethereum/go-ethereum/accounts/abi"
	packr "github.com/gobuffalo/packr/v2"
	pgx "github.com/jackc/pgx/v4"
	"github.com/jackc/pgx/v4/stdlib"
	migrate "github.com/rubenv/sql-migrate"
)

// RunMigrationsUp migrate up.
func RunMigrationsUp(cfg Config) error {
	return runMigrations(cfg, migrate.Up)
}

// RunMigrationsDown migrate down.
func RunMigrationsDown(cfg Config) error {
	return runMigrations(cfg, migrate.Down)
}

// ResetDB.
func ResetDB(cfg Config) error {
	c, err := pgx.ParseConfig("postgres://" + cfg.User + ":" + cfg.Password + "@" + cfg.Host + ":" + cfg.Port + "/" + cfg.Name)
	if err != nil {
		return err
	}
	db := stdlib.OpenDB(*c)
	_, err = db.Exec("DROP SCHEMA IF EXISTS mt CASCADE;")
	if err != nil {
		return err
	}
	_, err = db.Exec("DROP SCHEMA IF EXISTS sync CASCADE;")
	if err != nil {
		return err
	}
	_, err = db.Exec("DROP TABLE IF EXISTS public.gorp_migrations;")
	if err != nil {
		return err
	}
	return nil
}

// runMigrations will execute pending migrations if needed to keep
// the database updated with the latest changes in either direction of up or down.
func runMigrations(cfg Config, direction migrate.MigrationDirection) error {
	c, err := pgx.ParseConfig("postgres://" + cfg.User + ":" + cfg.Password + "@" + cfg.Host + ":" + cfg.Port + "/" + cfg.Name)
	if err != nil {
		return err
	}
	db := stdlib.OpenDB(*c)

	var migrations = &migrate.PackrMigrationSource{Box: packr.New("hermez-db-migrations", "./migrations")}
	nMigrations, err := migrate.Exec(db, "postgres", migrations, direction)
	if err != nil {
		return err
	}

	log.Info("successfully ran ", nMigrations, " migrations")
	const cleanStatusSQL = "DELETE FROM sync.status"
	_, err = db.Exec(cleanStatusSQL)
	if err != nil {
		// Ignore error if table doesn't exist (SQLSTATE 42P01)
		errMsg := err.Error()
		if errMsg != "" && (errMsg == "ERROR: relation \"sync.status\" does not exist (SQLSTATE 42P01)" ||
			strings.Contains(errMsg, "relation \"sync.status\" does not exist") ||
			strings.Contains(errMsg, "SQLSTATE 42P01")) {
			return nil
		}
		return err
	}
	return nil
}

// InitOrReset will initializes the db running the migrations or
// will reset all the known data and rerun the migrations
func InitOrReset(ctx context.Context, cfg Config) error {
	// connect to database
	_, err := NewPostgresStorage(ctx, cfg)
	if err != nil {
		return err
	}

	// run migrations
	if err := ResetDB(cfg); err != nil {
		return err
	}
	return RunMigrationsUp(cfg)
}

// NewConfigFromEnv creates config from standard postgres environment variables,
func NewConfigFromEnv() Config {
	maxConns, _ := strconv.Atoi(getEnv("ZKEVM_BRIDGE_SYNCDB_PGSTORAGE_MAXCONNS", "500"))
	return Config{
		User:     getEnv("ZKEVM_BRIDGE_SYNCDB_PGSTORAGE_USER", "test_user"),
		Password: getEnv("ZKEVM_BRIDGE_SYNCDB_PGSTORAGE_PASSWORD", "test_password"),
		Name:     getEnv("ZKEVM_BRIDGE_SYNCDB_PGSTORAGE_NAME", "test_db"),
		Host:     getEnv("ZKEVM_BRIDGE_SYNCDB_PGSTORAGE_HOST", "localhost"),
		Port:     getEnv("ZKEVM_BRIDGE_SYNCDB_PGSTORAGE_PORT", "5435"),
		MaxConns: maxConns,
	}
}

func getEnv(key string, defaultValue string) string {
	value, exists := os.LookupEnv(key)
	if exists {
		return value
	}
	return defaultValue
}

// nolint
var (
	String, _ = abi.NewType("string", "", nil)
	Uint8, _  = abi.NewType("uint8", "", nil)
)

func getDecodedToken(metadata []byte) (*etherman.TokenMetadata, error) {
	//nolint
	args := abi.Arguments{
		{"name", String, false},
		{"symbol", String, false},
		{"decimals", Uint8, false},
	}
	token := make(map[string]interface{})
	err := args.UnpackIntoMap(token, metadata)
	if err != nil {
		return nil, err
	}

	return &etherman.TokenMetadata{
		Name:     token["name"].(string),
		Symbol:   token["symbol"].(string),
		Decimals: token["decimals"].(uint8),
	}, nil
}
