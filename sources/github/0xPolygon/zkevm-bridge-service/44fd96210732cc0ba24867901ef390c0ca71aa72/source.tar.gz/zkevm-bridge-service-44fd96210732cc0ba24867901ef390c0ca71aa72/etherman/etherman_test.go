package etherman

import (
	"context"
	"math"
	"math/big"
	"testing"

	"github.com/0xPolygon/zkevm-bridge-service/etherman/smartcontracts/polygonzkevm"
	"github.com/0xPolygon/zkevm-bridge-service/etherman/smartcontracts/polygonzkevmbridgev2"
	"github.com/0xPolygon/zkevm-bridge-service/etherman/smartcontracts/bridgel2sovereignchain"
	"github.com/0xPolygon/zkevm-bridge-service/log"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient/simulated"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func init() {
	log.Init(log.Config{
		Level:   "debug",
		Outputs: []string{"stdout"},
	})
}

// This function prepare the blockchain, the wallet with funds and deploy the smc
func newTestingEnv(ctx context.Context) (*Client, *simulated.Backend, *bind.TransactOpts, common.Address, *polygonzkevmbridgev2.Polygonzkevmbridgev2, *polygonzkevm.Polygonzkevm, *bridgel2sovereignchain.Bridgel2sovereignchain) {
	privateKey, err := crypto.GenerateKey()
	if err != nil {
		log.Fatal(err)
	}
	auth, err := bind.NewKeyedTransactorWithChainID(privateKey, big.NewInt(1337))
	if err != nil {
		log.Fatal(err)
	}
	ethman, ethBackend, polAddr, bridge, zkevm, l2BridgeSovereign, err := NewSimulatedEtherman(ctx, Config{}, auth)
	if err != nil {
		log.Fatal(err)
	}
	return ethman, ethBackend, auth, polAddr, bridge, zkevm, l2BridgeSovereign
}

func TestGEREvent(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, _, _, _, _ := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	amount := big.NewInt(1000000000000000)
	auth.Value = amount
	_, err = etherman.PolygonBridgeV2.BridgeAsset(auth, 1, auth.From, amount, common.Address{}, true, []byte{})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	// Now read the event
	finalBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	finalBlockNumber := finalBlock.NumberU64()
	blocks, _, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), &finalBlockNumber)
	require.NoError(t, err)

	assert.NotEqual(t, common.Hash{}, blocks[0].GlobalExitRoots[0].ExitRoots[0])
	assert.Equal(t, common.Hash{}, blocks[0].GlobalExitRoots[0].ExitRoots[1])
}

func TestBridgeEvents(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, polAddr, bridge, _, _ := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	// Deposit funds
	amount := big.NewInt(9000000000000000000)
	var destNetwork uint32 = 1 // 0 is reserved to mainnet. This variable is set in the smc
	destinationAddr := common.HexToAddress("0x61A1d716a74fb45d29f148C6C20A2eccabaFD753")
	_, err = bridge.BridgeAsset(auth, destNetwork, destinationAddr, amount, polAddr, true, []byte{})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	block, order, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), nil)
	require.NoError(t, err)
	assert.Equal(t, DepositsOrder, order[block[0].BlockHash][0].Name)
	assert.Equal(t, GlobalExitRootsOrder, order[block[0].BlockHash][1].Name)
	assert.Equal(t, uint64(8), block[0].BlockNumber)
	assert.Equal(t, big.NewInt(9000000000000000000), block[0].Deposits[0].Amount)
	assert.Equal(t, destNetwork, block[0].Deposits[0].DestinationNetwork)
	assert.Equal(t, destinationAddr, block[0].Deposits[0].DestinationAddress)
	assert.Equal(t, 1, len(block[0].GlobalExitRoots))

	//Claim funds
	var (
		network                                       uint32
		smtProofLocalExitRoot, smtProofRollupExitRoot [32][32]byte
		globalIndex, _                                = big.NewInt(0).SetString("18446744073709551650", 0)
	)
	mainnetExitRoot := block[0].GlobalExitRoots[0].ExitRoots[0]
	rollupExitRoot := block[0].GlobalExitRoots[0].ExitRoots[1]

	destNetwork = 1
	_, err = bridge.ClaimAsset(auth, smtProofLocalExitRoot, smtProofRollupExitRoot, globalIndex, mainnetExitRoot, rollupExitRoot,
		network, polAddr, destNetwork, auth.From, big.NewInt(1000000000000000000), []byte{})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	//Read claim event
	initBlock, err = etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	block, order, err = etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), nil)
	require.NoError(t, err)
	assert.Equal(t, TokensOrder, order[block[0].BlockHash][0].Name)
	assert.Equal(t, ClaimsOrder, order[block[0].BlockHash][1].Name)
	assert.Equal(t, big.NewInt(1000000000000000000), block[0].Claims[0].Amount)
	assert.Equal(t, uint64(9), block[0].BlockNumber)
	assert.NotEqual(t, common.Address{}, block[0].Claims[0].OriginalAddress)
	assert.Equal(t, auth.From, block[0].Claims[0].DestinationAddress)
	assert.Equal(t, uint32(34), block[0].Claims[0].Index)
	assert.Equal(t, uint32(0), block[0].Claims[0].RollupIndex)
	assert.Equal(t, true, block[0].Claims[0].MainnetFlag)
	assert.Equal(t, uint32(0), block[0].Claims[0].OriginalNetwork)
	assert.Equal(t, uint64(9), block[0].Claims[0].BlockNumber)
}

func TestDecodeGlobalIndex(t *testing.T) {
	globalIndex, _ := big.NewInt(0).SetString("4294967307", 0)

	var buf [32]byte
	gi := globalIndex.FillBytes(buf[:])
	for _, n := range gi {
		t.Logf("%08b ", n)
	}
	mainnetFlag, rollupIndex, localExitRootIndex, err := DecodeGlobalIndex(globalIndex)
	require.NoError(t, err)
	assert.Equal(t, false, mainnetFlag)
	assert.Equal(t, uint32(1), rollupIndex)
	assert.Equal(t, uint32(11), localExitRootIndex)

	globalIndex, _ = big.NewInt(0).SetString("8589934604", 0)

	gi = globalIndex.FillBytes(buf[:])
	for _, n := range gi {
		t.Logf("%08b ", n)
	}
	mainnetFlag, rollupIndex, localExitRootIndex, err = DecodeGlobalIndex(globalIndex)
	require.NoError(t, err)
	assert.Equal(t, false, mainnetFlag)
	assert.Equal(t, uint32(2), rollupIndex)
	assert.Equal(t, uint32(12), localExitRootIndex)

	globalIndex, _ = big.NewInt(0).SetString("18446744073709551627", 0)

	gi = globalIndex.FillBytes(buf[:])
	for _, n := range gi {
		t.Logf("%08b ", n)
	}
	mainnetFlag, rollupIndex, localExitRootIndex, err = DecodeGlobalIndex(globalIndex)
	require.NoError(t, err)
	assert.Equal(t, true, mainnetFlag)
	assert.Equal(t, uint32(0), rollupIndex)
	assert.Equal(t, uint32(11), localExitRootIndex)

	globalIndex, _ = big.NewInt(0).SetString("18446744073709551616", 0)

	gi = globalIndex.FillBytes(buf[:])
	for _, n := range gi {
		t.Logf("%08b ", n)
	}
	mainnetFlag, rollupIndex, localExitRootIndex, err = DecodeGlobalIndex(globalIndex)
	require.NoError(t, err)
	assert.Equal(t, true, mainnetFlag)
	assert.Equal(t, uint32(0), rollupIndex)
	assert.Equal(t, uint32(0), localExitRootIndex)

	globalIndex, _ = big.NewInt(0).SetString("18446744073709551615", 0)

	gi = globalIndex.FillBytes(buf[:])
	for _, n := range gi {
		t.Logf("%08b ", n)
	}
	mainnetFlag, rollupIndex, localExitRootIndex, err = DecodeGlobalIndex(globalIndex)
	require.NoError(t, err)
	assert.Equal(t, false, mainnetFlag)
	assert.Equal(t, uint32(math.MaxUint32), rollupIndex)
	assert.Equal(t, uint32(math.MaxUint32), localExitRootIndex)
}

func TestVerifyBatchEvent(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, _, _, zkevm, _ := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	rawTxs := "f84901843b9aca00827b0c945fbdb2315678afecb367f032d93f642f64180aa380a46057361d00000000000000000000000000000000000000000000000000000000000000048203e9808073efe1fa2d3e27f26f32208550ea9b0274d49050b816cadab05a771f4275d0242fd5d92b3fb89575c070e6c930587c520ee65a3aa8cfe382fcad20421bf51d621c"
	tx := polygonzkevm.PolygonRollupBaseEtrogBatchData{
		ForcedGlobalExitRoot: common.Hash{},
		ForcedBlockHashL1:    common.Hash{},
		ForcedTimestamp:      0,
		Transactions:         common.Hex2Bytes(rawTxs),
	}
	var (
		maxSequenceTimestamp uint64 = 1
		initSequencedBatch   uint64 = 1
	)
	_, err = zkevm.SequenceBatches(auth, []polygonzkevm.PolygonRollupBaseEtrogBatchData{tx}, maxSequenceTimestamp, initSequencedBatch, auth.From)
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	_, err = etherman.PolygonRollupManager.VerifyBatchesTrustedAggregator(auth, 1, uint64(0), uint64(0), uint64(1), [32]byte{}, [32]byte{}, auth.From, [24][32]byte{})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	// Now read the event
	finalBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	finalBlockNumber := finalBlock.NumberU64()
	blocks, order, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), &finalBlockNumber)
	require.NoError(t, err)
	t.Logf("Blocks: %+v, \nOrder: %+v", blocks, order)
	assert.Equal(t, uint64(9), blocks[0].BlockNumber)
	assert.Equal(t, uint64(1), blocks[0].VerifiedBatches[0].BatchNumber)
	assert.NotEqual(t, common.Address{}, blocks[0].VerifiedBatches[0].Aggregator)
	assert.NotEqual(t, common.Hash{}, blocks[0].VerifiedBatches[0].TxHash)
	assert.Equal(t, GlobalExitRootsOrder, order[blocks[0].BlockHash][0].Name)
	assert.Equal(t, VerifyBatchOrder, order[blocks[0].BlockHash][1].Name)
	assert.Equal(t, 0, order[blocks[0].BlockHash][0].Pos)
	assert.Equal(t, 0, order[blocks[0].BlockHash][1].Pos)
}

func TestGenerateGlobalIndex(t *testing.T) {
	globalIndex, _ := big.NewInt(0).SetString("4294967307", 0)
	mainnetFlag, rollupIndex, localExitRootIndex := false, uint32(1), uint32(11)
	globalIndexGenerated := GenerateGlobalIndex(mainnetFlag, rollupIndex, localExitRootIndex)
	t.Log("First test number:")
	var buf [32]byte
	gIBytes := globalIndexGenerated.FillBytes(buf[:])
	for _, n := range gIBytes {
		t.Logf("%08b ", n)
	}
	assert.Equal(t, globalIndex, globalIndexGenerated)

	globalIndex, _ = big.NewInt(0).SetString("8589934604", 0)
	mainnetFlag, rollupIndex, localExitRootIndex = false, uint32(2), uint32(12)
	globalIndexGenerated = GenerateGlobalIndex(mainnetFlag, rollupIndex, localExitRootIndex)
	t.Log("Second test number:")
	gIBytes = globalIndexGenerated.FillBytes(buf[:])
	for _, n := range gIBytes {
		t.Logf("%08b ", n)
	}
	assert.Equal(t, globalIndex, globalIndexGenerated)

	globalIndex, _ = big.NewInt(0).SetString("18446744073709551627", 0)
	mainnetFlag, rollupIndex, localExitRootIndex = true, uint32(0), uint32(11)
	globalIndexGenerated = GenerateGlobalIndex(mainnetFlag, rollupIndex, localExitRootIndex)
	t.Log("Third test number:")
	gIBytes = globalIndexGenerated.FillBytes(buf[:])
	for _, n := range gIBytes {
		t.Logf("%08b ", n)
	}
	assert.Equal(t, globalIndex, globalIndexGenerated)

	globalIndex, _ = big.NewInt(0).SetString("18446744073709551615", 0)
	globalIndexGenerated = GenerateGlobalIndex(false, math.MaxUint32, math.MaxUint32)
	t.Log("Fourth test number:")
	gIBytes = globalIndexGenerated.FillBytes(buf[:])
	for _, n := range gIBytes {
		t.Logf("%08b ", n)
	}
	assert.Equal(t, globalIndex, globalIndexGenerated)

	globalIndex = big.NewInt(0)
	globalIndexGenerated = GenerateGlobalIndex(false, uint32(0), uint32(0))
	t.Log("Fourth test number:")
	gIBytes = globalIndexGenerated.FillBytes(buf[:])
	for _, n := range gIBytes {
		t.Logf("%08b ", n)
	}
	assert.Equal(t, globalIndex.String(), globalIndexGenerated.String())

	globalIndex, _ = big.NewInt(0).SetString("18446744073709551616", 0)
	globalIndexGenerated = GenerateGlobalIndex(true, uint32(0), uint32(0))
	t.Log("Fourth test number:")
	gIBytes = globalIndexGenerated.FillBytes(buf[:])
	for _, n := range gIBytes {
		t.Logf("%08b ", n)
	}
	assert.Equal(t, globalIndex, globalIndexGenerated)
}

func TestBackwardLETSovereignEvent(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, _, _, _, l2BridgeSovereign := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	_, err = l2BridgeSovereign.BackwardLET(auth, big.NewInt(1), [32][32]byte{}, common.Hash{}, [32][32]byte{})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	// Now read the event
	finalBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	finalBlockNumber := finalBlock.NumberU64()
	blocks, _, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), &finalBlockNumber)
	require.NoError(t, err)

	assert.Equal(t, uint32(1), blocks[0].BackwardLETs[0].NewDepositCount)
	assert.Equal(t, "0x27ae5ba08d7291c96c8cbddcc148bf48a6d68c7974b94356f53754ef6171d757", blocks[0].BackwardLETs[0].NewRoot.String())
	assert.Equal(t, uint32(0), blocks[0].BackwardLETs[0].PreviousDepositCount)
	assert.Equal(t, "0x27ae5ba08d7291c96c8cbddcc148bf48a6d68c7974b94356f53754ef6171d757", blocks[0].BackwardLETs[0].PreviousRoot.String())
}

func TestUnsetMultipleClaimsSovereignEvent(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, _, _, _, l2BridgeSovereign := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	globalIndex, _ := big.NewInt(0).SetString("8589934604", 0)
	_, err = l2BridgeSovereign.UnsetMultipleClaims(auth, []*big.Int{globalIndex})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	// Now read the event
	finalBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	finalBlockNumber := finalBlock.NumberU64()
	blocks, _, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), &finalBlockNumber)
	require.NoError(t, err)

	assert.Equal(t, "8589934604", blocks[0].UnsetClaims[0].GlobalIndex.String())
	assert.Equal(t, uint32(12), blocks[0].UnsetClaims[0].Index)
	assert.Equal(t, false, blocks[0].UnsetClaims[0].MainnetFlag)
	assert.Equal(t, uint32(2), blocks[0].UnsetClaims[0].RollupIndex)
}

func TestSetMultipleClaimsSovereignEvent(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, _, _, _, l2BridgeSovereign := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	globalIndex, _ := big.NewInt(0).SetString("8589934604", 0)
	_, err = l2BridgeSovereign.SetMultipleClaims(auth, []*big.Int{globalIndex})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	// Now read the event
	finalBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	finalBlockNumber := finalBlock.NumberU64()
	blocks, _, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), &finalBlockNumber)
	require.NoError(t, err)

	assert.Equal(t, "8589934604", blocks[0].SetClaims[0].GlobalIndex.String())
	assert.Equal(t, uint32(12), blocks[0].SetClaims[0].Index)
	assert.Equal(t, false, blocks[0].SetClaims[0].MainnetFlag)
	assert.Equal(t, uint32(2), blocks[0].SetClaims[0].RollupIndex)
}

func TestForwardLETSovereignEvent(t *testing.T) {
	ctx := t.Context()
	// Set up testing environment
	etherman, ethBackend, auth, _, _, _, l2BridgeSovereign := newTestingEnv(ctx)

	// Read currentBlock
	initBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)

	leaves := []bridgel2sovereignchain.AgglayerBridgeL2LeafData {
		{
			LeafType: 0,
			OriginNetwork: 0,
			OriginAddress: common.Address{},
			DestinationNetwork: 1,
			DestinationAddress: common.HexToAddress("0x61A1d716a74fb45d29f148C6C20A2eccabaFD753"),
			Amount: big.NewInt(1),
			Metadata: []byte{},
		},
		{
			LeafType: 0,
			OriginNetwork: 0,
			OriginAddress: common.Address{},
			DestinationNetwork: 1,
			DestinationAddress: common.HexToAddress("0x61A1d716a74fb45d29f148C6C20A2eccabaFD753"),
			Amount: big.NewInt(1),
			Metadata: []byte{},
		},
	}
	_, err = l2BridgeSovereign.ForwardLET(auth, leaves, common.Hash{})
	require.NoError(t, err)

	// Mine the tx in a block
	ethBackend.Commit()

	// Now read the event
	finalBlock, err := etherman.EtherClient.BlockByNumber(ctx, nil)
	require.NoError(t, err)
	finalBlockNumber := finalBlock.NumberU64()
	blocks, _, err := etherman.GetRollupInfoByBlockRange(ctx, initBlock.NumberU64(), &finalBlockNumber)
	require.NoError(t, err)

	assert.Equal(t, uint32(2), blocks[0].ForwardLETs[0].NewDepositCount)
	assert.Equal(t, "0x143bf21923fc84104de314e92b560216e80c77c7e50e35d64968fcbc16780987", blocks[0].ForwardLETs[0].NewRoot.String())
	assert.Equal(t, uint32(0), blocks[0].ForwardLETs[0].PreviousDepositCount)
	assert.Equal(t, "0x27ae5ba08d7291c96c8cbddcc148bf48a6d68c7974b94356f53754ef6171d757", blocks[0].ForwardLETs[0].PreviousRoot.String())
	assert.NotEqual(t, common.Hash{}, blocks[0].ForwardLETs[0].TxHash)	
}