package common

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"sync/atomic"
	"unicode"

	"github.com/bytedance/sonic"
	"github.com/rs/zerolog"
)

const (
	CompositeTypeNone               = "none"
	CompositeTypeLogsSplitOnError   = "logs-split-on-error"
	CompositeTypeLogsSplitProactive = "logs-split-proactive"
)

const RequestContextKey ContextKey = "rq"
const UpstreamsContextKey ContextKey = "ups"

type RequestDirectives struct {
	// Instruct the proxy to retry if response from the upstream appears to be empty
	// indicating missing or non-synced data (empty array for logs, null for block, null for tx receipt, etc).
	// By default this value is "false" – meaning empty responses will NOT be retried unless explicitly
	// enabled via project/network directive defaults or incoming HTTP header / query parameter.
	RetryEmpty bool `json:"retryEmpty"`

	// Instruct the proxy to retry if response from the upstream appears to be a pending tx,
	// for example when blockNumber/blockHash are still null.
	// This value is "true" by default, to give a chance to receive the full TX.
	// If you intentionally require to get pending TX data immediately without waiting,
	// you can set this value to "false" via Headers.
	RetryPending bool `json:"retryPending"`

	// Instruct the proxy to skip cache reads for example to force freshness,
	// or override some cache corruption.
	SkipCacheRead bool `json:"skipCacheRead"`

	// Instruct the proxy to forward the request to a specific upstream(s) only.
	// Value can use "*" star char as a wildcard to target multiple upstreams.
	// For example "alchemy" or "my-own-*", etc.
	UseUpstream string `json:"useUpstream,omitempty"`

	// Instruct the proxy to bypass method exclusion checks.
	ByPassMethodExclusion bool `json:"-"`
}

func (d *RequestDirectives) Clone() *RequestDirectives {
	return &RequestDirectives{
		RetryEmpty:            d.RetryEmpty,
		RetryPending:          d.RetryPending,
		SkipCacheRead:         d.SkipCacheRead,
		UseUpstream:           d.UseUpstream,
		ByPassMethodExclusion: d.ByPassMethodExclusion,
	}
}

type NormalizedRequest struct {
	sync.RWMutex

	network  Network
	cacheDal CacheDAL
	body     []byte

	method         string
	directives     *RequestDirectives
	jsonRpcRequest atomic.Pointer[JsonRpcRequest]

	// Upstream selection fields - protected by upstreamMutex
	upstreamMutex    sync.Mutex
	UpstreamIdx      uint32
	ErrorsByUpstream sync.Map
	EmptyResponses   sync.Map // TODO we can potentially remove this map entirely, only use is to report "wrong empty responses"

	// Fields for centralized upstream management
	upstreamList      []Upstream // Available upstreams for this request
	ConsumedUpstreams *sync.Map  // Tracks upstreams that provided valid responses

	lastValidResponse atomic.Pointer[NormalizedResponse]
	lastUpstream      atomic.Value
	evmBlockRef       atomic.Value
	evmBlockNumber    atomic.Value

	compositeType   atomic.Value // Type of composite request (e.g., "logs-split")
	parentRequestId atomic.Value // ID of the parent request (for sub-requests)

	finality atomic.Value // Cached finality state

	user atomic.Value

	// Cached agent information to avoid recalculation
	agentName    atomic.Value // Cached agent name from User-Agent
	agentVersion atomic.Value // Cached agent version from User-Agent
}

func NewNormalizedRequest(body []byte) *NormalizedRequest {
	nr := &NormalizedRequest{
		body: body,
		directives: &RequestDirectives{
			RetryEmpty: false,
		},
	}
	nr.compositeType.Store(CompositeTypeNone)
	return nr
}

func NewNormalizedRequestFromJsonRpcRequest(jsonRpcRequest *JsonRpcRequest) *NormalizedRequest {
	nr := &NormalizedRequest{
		directives: &RequestDirectives{
			RetryEmpty: false,
		},
	}
	nr.jsonRpcRequest.Store(jsonRpcRequest)
	nr.compositeType.Store(CompositeTypeNone)
	return nr
}

func (r *NormalizedRequest) SetUser(user *User) {
	if r == nil || user == nil {
		return
	}
	r.user.Store(user)
}

func (r *NormalizedRequest) User() *User {
	if r == nil {
		return nil
	}
	if u, ok := r.user.Load().(*User); ok {
		return u
	}
	return nil
}

func (r *NormalizedRequest) SetLastUpstream(upstream Upstream) *NormalizedRequest {
	if r == nil || upstream == nil {
		return r
	}
	r.lastUpstream.Store(upstream)
	return r
}

func (r *NormalizedRequest) LastUpstream() Upstream {
	if r == nil {
		return nil
	}
	if lu := r.lastUpstream.Load(); lu != nil {
		return lu.(Upstream)
	}
	return nil
}

func (r *NormalizedRequest) SetLastValidResponse(ctx context.Context, nrs *NormalizedResponse) bool {
	if r == nil || nrs == nil {
		return false
	}
	prevLV := r.lastValidResponse.Load()
	prevIsEmpty := prevLV == nil || prevLV.IsObjectNull(ctx) || prevLV.IsResultEmptyish(ctx)
	newIsEmpty := nrs.IsObjectNull(ctx) || nrs.IsResultEmptyish(ctx)
	if prevIsEmpty || !newIsEmpty {
		r.lastValidResponse.Store(nrs)
		if !nrs.IsObjectNull(ctx) {
			ups := nrs.Upstream()
			if ups != nil {
				r.SetLastUpstream(ups)
			}
		}
		return true
	}
	return false
}

func (r *NormalizedRequest) LastValidResponse() *NormalizedResponse {
	if r == nil {
		return nil
	}
	return r.lastValidResponse.Load()
}

// ClearLastValidResponse clears the stored last valid response pointer.
func (r *NormalizedRequest) ClearLastValidResponse() {
	if r == nil {
		return
	}
	r.lastValidResponse.Store(nil)
}

func (r *NormalizedRequest) Network() Network {
	if r == nil {
		return nil
	}
	return r.network
}

func (r *NormalizedRequest) ID() interface{} {
	if r == nil {
		return nil
	}

	if jrr, _ := r.JsonRpcRequest(); jrr != nil {
		return jrr.ID
	}

	return nil
}

func (r *NormalizedRequest) NetworkId() string {
	if r == nil {
		// For certain requests such as internal eth_chainId requests, network might not be available yet.
		return "n/a"
	}
	r.RLock()
	defer r.RUnlock()
	if r.network == nil {
		return "n/a"
	}
	return r.network.Id()
}

// NetworkLabel returns a user-friendly label for the network suitable for metrics.
// It prefers the network alias when available, otherwise falls back to the canonical ID.
func (r *NormalizedRequest) NetworkLabel() string {
	if r == nil {
		return "n/a"
	}
	r.RLock()
	defer r.RUnlock()
	if r.network == nil {
		return "n/a"
	}
	lbl := r.network.Label()
	if lbl != "" {
		return lbl
	}
	return r.network.Id()
}

func (r *NormalizedRequest) SetNetwork(network Network) {
	r.Lock()
	defer r.Unlock()
	r.network = network
}

func (r *NormalizedRequest) SetCacheDal(cacheDal CacheDAL) {
	r.Lock()
	defer r.Unlock()
	r.cacheDal = cacheDal
}

func (r *NormalizedRequest) CacheDal() CacheDAL {
	if r == nil {
		return nil
	}
	r.RLock()
	defer r.RUnlock()
	return r.cacheDal
}

func (r *NormalizedRequest) SetDirectives(directives *RequestDirectives) {
	if r == nil {
		return
	}
	r.Lock()
	defer r.Unlock()
	r.directives = directives
}

func (r *NormalizedRequest) ApplyDirectiveDefaults(directiveDefaults *DirectiveDefaultsConfig) {
	if directiveDefaults == nil {
		return
	}
	r.Lock()
	defer r.Unlock()

	if r.directives == nil {
		r.directives = &RequestDirectives{}
	}

	if directiveDefaults.RetryEmpty != nil {
		r.directives.RetryEmpty = *directiveDefaults.RetryEmpty
	}
	if directiveDefaults.RetryPending != nil {
		r.directives.RetryPending = *directiveDefaults.RetryPending
	}
	if directiveDefaults.SkipCacheRead != nil {
		r.directives.SkipCacheRead = *directiveDefaults.SkipCacheRead
	}
	if directiveDefaults.UseUpstream != nil {
		r.directives.UseUpstream = *directiveDefaults.UseUpstream
	}
}

func (r *NormalizedRequest) EnrichFromHttp(headers http.Header, queryArgs url.Values) {
	r.Lock()
	defer r.Unlock()

	if r.directives == nil {
		r.directives = &RequestDirectives{}
	}

	// Headers have precedence over directive defaults, but should only override when explicitly provided.
	if hv := headers.Get("X-ERPC-Retry-Empty"); hv != "" {
		r.directives.RetryEmpty = strings.ToLower(strings.TrimSpace(hv)) == "true"
	}
	if hv := headers.Get("X-ERPC-Retry-Pending"); hv != "" {
		r.directives.RetryPending = strings.ToLower(strings.TrimSpace(hv)) == "true"
	}
	if hv := headers.Get("X-ERPC-Skip-Cache-Read"); hv != "" {
		r.directives.SkipCacheRead = strings.ToLower(strings.TrimSpace(hv)) == "true"
	}
	if hv := headers.Get("X-ERPC-Use-Upstream"); hv != "" {
		r.directives.UseUpstream = hv
	}

	// Query parameters come after headers so they can still override when explicitly present in URL.
	if useUpstream := queryArgs.Get("use-upstream"); useUpstream != "" {
		r.directives.UseUpstream = strings.TrimSpace(useUpstream)
	}

	if retryEmpty := queryArgs.Get("retry-empty"); retryEmpty != "" {
		r.directives.RetryEmpty = strings.ToLower(strings.TrimSpace(retryEmpty)) == "true"
	}

	if retryPending := queryArgs.Get("retry-pending"); retryPending != "" {
		r.directives.RetryPending = strings.ToLower(strings.TrimSpace(retryPending)) == "true"
	}

	if skipCacheRead := queryArgs.Get("skip-cache-read"); skipCacheRead != "" {
		r.directives.SkipCacheRead = strings.ToLower(strings.TrimSpace(skipCacheRead)) == "true"
	}

	// Extract and store user agent information for future use
	if userAgent := r.getUserAgent(headers, queryArgs); userAgent != "" {
		simplifiedAgentName := r.simplifyAgentName(userAgent)
		simplifiedAgentVersion := r.simplifyAgentVersion(userAgent)

		r.agentName.Store(simplifiedAgentName)
		r.agentVersion.Store(simplifiedAgentVersion)
	}
}

func (r *NormalizedRequest) SkipCacheRead() bool {
	if r == nil {
		return false
	}
	if r.directives == nil {
		return false
	}
	return r.directives.SkipCacheRead
}

func (r *NormalizedRequest) Directives() *RequestDirectives {
	if r == nil {
		return nil
	}

	return r.directives
}

func (r *NormalizedRequest) LockWithTrace(ctx context.Context) {
	_, span := StartDetailSpan(ctx, "Request.Lock")
	defer span.End()
	r.Lock()
}

func (r *NormalizedRequest) RLockWithTrace(ctx context.Context) {
	_, span := StartDetailSpan(ctx, "Request.RLock")
	defer span.End()
	r.RLock()
}

// Extract and prepare the request for forwarding.
func (r *NormalizedRequest) JsonRpcRequest(ctx ...context.Context) (*JsonRpcRequest, error) {
	if len(ctx) > 0 {
		_, span := StartDetailSpan(ctx[0], "Request.ResolveJsonRpc")
		defer span.End()
	}

	if r == nil {
		return nil, nil
	}
	if jrq := r.jsonRpcRequest.Load(); jrq != nil {
		return jrq, nil
	}

	rpcReq := new(JsonRpcRequest)
	if err := SonicCfg.Unmarshal(r.body, rpcReq); err != nil {
		return nil, NewErrJsonRpcRequestUnmarshal(err, r.body)
	}

	method := rpcReq.Method
	if method == "" {
		return nil, NewErrJsonRpcRequestUnresolvableMethod(rpcReq)
	}

	r.jsonRpcRequest.Store(rpcReq)
	// Safe to drop the raw body after successful parse to reduce retention of ReadAll buffers.
	r.body = nil

	return rpcReq, nil
}

func (r *NormalizedRequest) Method() (string, error) {
	if r == nil {
		return "", nil
	}

	if r.method != "" {
		return r.method, nil
	}

	if jrq := r.jsonRpcRequest.Load(); jrq != nil {
		r.method = jrq.Method
		return jrq.Method, nil
	}

	if len(r.body) > 0 {
		method, err := sonic.Get(r.body, "method")
		if err != nil {
			return "", NewErrJsonRpcRequestUnmarshal(err, r.body)
		}
		m, err := method.String()
		r.method = m
		return m, err
	}

	return "", NewErrJsonRpcRequestUnresolvableMethod(r.body)
}

func (r *NormalizedRequest) Body() []byte {
	return r.body
}

func (r *NormalizedRequest) MarshalZerologObject(e *zerolog.Event) {
	if r == nil {
		return
	}

	if lu := r.lastUpstream.Load(); lu != nil {
		if lup := lu.(Upstream); lup != nil {
			if lup.Config() != nil {
				e.Str("lastUpstream", lup.Id())
			} else {
				e.Str("lastUpstream", fmt.Sprintf("%p", lup))
			}
		} else {
			e.Str("lastUpstream", "nil")
		}
	} else {
		e.Str("lastUpstream", "nil")
	}

	if r.network != nil {
		e.Str("networkId", r.network.Id())
	}

	if jrq := r.jsonRpcRequest.Load(); jrq != nil {
		e.Object("jsonRpc", jrq)
	} else if r.body != nil {
		if IsSemiValidJson(r.body) {
			e.RawJSON("body", r.body)
		} else {
			e.Str("body", string(r.body))
		}
	}
}

// TODO Move evm specific data to RequestMetadata struct so we can have multiple architectures besides evm
func (r *NormalizedRequest) EvmBlockRef() interface{} {
	if r == nil {
		return nil
	}
	return r.evmBlockRef.Load()
}

func (r *NormalizedRequest) SetEvmBlockRef(blockRef interface{}) {
	if r == nil || blockRef == nil {
		return
	}
	r.evmBlockRef.Store(blockRef)
}

func (r *NormalizedRequest) EvmBlockNumber() interface{} {
	if r == nil {
		return nil
	}
	return r.evmBlockNumber.Load()
}

func (r *NormalizedRequest) SetEvmBlockNumber(blockNumber interface{}) {
	if r == nil || blockNumber == nil {
		return
	}
	r.evmBlockNumber.Store(blockNumber)
}

func (r *NormalizedRequest) MarshalJSON() ([]byte, error) {
	if r.body != nil {
		return r.body, nil
	}

	if jrq := r.jsonRpcRequest.Load(); jrq != nil {
		return SonicCfg.Marshal(map[string]interface{}{
			"method": jrq.Method,
		})
	}

	if m, _ := r.Method(); m != "" {
		return SonicCfg.Marshal(map[string]interface{}{
			"method": m,
		})
	}

	return nil, nil
}

func (r *NormalizedRequest) CacheHash(ctx ...context.Context) (string, error) {
	rq, err := r.JsonRpcRequest(ctx...)
	if err != nil {
		return "", err
	}

	if rq != nil {
		return rq.CacheHash(ctx...)
	}

	return "", fmt.Errorf("request is not valid to generate cache hash")
}

func (r *NormalizedRequest) Validate() error {
	if r == nil {
		return NewErrInvalidRequest(fmt.Errorf("request is nil"))
	}

	if r.body == nil && r.jsonRpcRequest.Load() == nil {
		return NewErrInvalidRequest(fmt.Errorf("request body is nil"))
	}

	method, err := r.Method()
	if err != nil {
		return NewErrInvalidRequest(err)
	}

	if method == "" {
		return NewErrInvalidRequest(fmt.Errorf("method is required"))
	}

	return nil
}

// IsCompositeRequest returns whether this request is a top-level composite request
func (r *NormalizedRequest) IsCompositeRequest() bool {
	if r == nil {
		return false
	}
	return r.CompositeType() != CompositeTypeNone
}

func (r *NormalizedRequest) CompositeType() string {
	if r == nil {
		return ""
	}
	if ct := r.compositeType.Load(); ct != nil {
		return ct.(string)
	}
	return ""
}

func (r *NormalizedRequest) SetCompositeType(compositeType string) {
	if r == nil || compositeType == "" {
		return
	}
	r.compositeType.Store(compositeType)
}

func (r *NormalizedRequest) ParentRequestId() interface{} {
	if r == nil {
		return nil
	}
	return r.parentRequestId.Load()
}

func (r *NormalizedRequest) SetParentRequestId(parentId interface{}) {
	if r == nil || parentId == nil {
		return
	}
	r.parentRequestId.Store(parentId)
}

func (r *NormalizedRequest) Finality(ctx context.Context) DataFinalityState {
	if r == nil {
		return DataFinalityStateUnknown
	}

	// Check if we have a cached value
	if f := r.finality.Load(); f != nil {
		return f.(DataFinalityState)
	}

	// Calculate and cache the finality
	if r.network != nil {
		finality := r.network.GetFinality(ctx, r, nil)
		// Only cache if we got a definitive answer (not unknown)
		if finality != DataFinalityStateUnknown {
			r.finality.Store(finality)
		}
		return finality
	}

	return DataFinalityStateUnknown
}

// CopyHttpContextFrom copies HTTP context (headers and query parameters) from another request
// This ensures user agent information is preserved for metrics when creating derived requests
func (r *NormalizedRequest) CopyHttpContextFrom(source *NormalizedRequest) {
	if r == nil || source == nil {
		return
	}

	r.Lock()
	defer r.Unlock()

	source.RLock()
	defer source.RUnlock()

	// Copy the user agent information
	if agentName := source.agentName.Load(); agentName != nil {
		r.agentName.Store(agentName)
	}
	if agentVersion := source.agentVersion.Load(); agentVersion != nil {
		r.agentVersion.Store(agentVersion)
	}

	// Also copy the user if it exists
	if user := source.User(); user != nil {
		r.SetUser(user)
	}
}

func (r *NormalizedRequest) SetUpstreams(upstreams []Upstream) {
	if r == nil {
		return
	}
	r.upstreamMutex.Lock()
	defer r.upstreamMutex.Unlock()

	r.upstreamList = upstreams
	if r.ConsumedUpstreams == nil {
		r.ConsumedUpstreams = &sync.Map{}
	}
}

// UserId returns the user ID from the user object, or "n/a" if not available
func (r *NormalizedRequest) UserId() string {
	if r == nil {
		return "n/a"
	}

	user := r.User()
	if user != nil && user.Id != "" {
		return user.Id
	}

	return "n/a"
}

// AgentName returns the cached agent name. The agent name should be populated via EnrichFromHttp().
func (r *NormalizedRequest) AgentName() string {
	if r == nil {
		return "unknown"
	}

	// Check if cached agent name is available
	if cachedAgentName := r.agentName.Load(); cachedAgentName != nil {
		return cachedAgentName.(string)
	}

	// If not cached, return unknown (EnrichFromHttp should be called to populate this)
	return "unknown"
}

// getUserAgent returns the user agent string, with query parameter taking precedence over header
func (r *NormalizedRequest) getUserAgent(headers http.Header, queryArgs url.Values) string {
	// Query parameter takes precedence
	if queryArgs != nil {
		if userAgent := queryArgs.Get("user-agent"); userAgent != "" {
			return userAgent
		}
	}

	// Fallback to User-Agent header
	if headers != nil {
		return headers.Get("User-Agent")
	}

	return ""
}

// simplifyAgentName extracts and simplifies the agent name for low cardinality metrics
func (r *NormalizedRequest) simplifyAgentName(userAgent string) string {
	userAgent = strings.ToLower(strings.TrimSpace(userAgent))

	// Common patterns for agent name extraction
	if strings.Contains(userAgent, "curl") {
		return "curl"
	}
	if strings.Contains(userAgent, "wget") {
		return "wget"
	}
	if strings.Contains(userAgent, "postman") {
		return "postman"
	}
	if strings.Contains(userAgent, "insomnia") {
		return "insomnia"
	}
	if strings.Contains(userAgent, "httpie") {
		return "httpie"
	}
	if strings.Contains(userAgent, "python") {
		return "python"
	}
	if strings.Contains(userAgent, "node") || strings.Contains(userAgent, "javascript") {
		return "nodejs"
	}
	if strings.Contains(userAgent, "go-http-client") || strings.Contains(userAgent, "go/") {
		return "go"
	}
	if strings.Contains(userAgent, "java") {
		return "java"
	}
	if strings.Contains(userAgent, "rust") {
		return "rust"
	}
	if strings.Contains(userAgent, "ruby") {
		return "ruby"
	}
	if strings.Contains(userAgent, "php") {
		return "php"
	}
	if strings.Contains(userAgent, "chrome") {
		return "chrome"
	}
	if strings.Contains(userAgent, "firefox") {
		return "firefox"
	}
	if strings.Contains(userAgent, "safari") {
		return "safari"
	}
	if strings.Contains(userAgent, "edge") {
		return "edge"
	}
	if strings.Contains(userAgent, "viem") {
		return "viem"
	}
	if strings.Contains(userAgent, "ethers") {
		return "ethers"
	}
	if strings.Contains(userAgent, "web3") {
		return "web3"
	}
	if strings.Contains(userAgent, "alchemy") {
		return "alchemy-sdk"
	}
	if strings.Contains(userAgent, "infura") {
		return "infura-sdk"
	}
	if strings.Contains(userAgent, "quicknode") {
		return "quicknode-sdk"
	}

	// Try to extract first word before version or space
	parts := strings.Fields(userAgent)
	if len(parts) > 0 {
		name := parts[0]
		// Remove version info from the name part
		if idx := strings.IndexAny(name, "/()"); idx != -1 {
			name = name[:idx]
		}
		// Limit length to prevent high cardinality
		if len(name) > 20 {
			name = name[:20]
		}
		if name != "" {
			return name
		}
	}

	return "other"
}

// simplifyAgentVersion extracts and simplifies the agent version for low cardinality metrics
func (r *NormalizedRequest) simplifyAgentVersion(userAgent string) string {
	userAgent = strings.ToLower(strings.TrimSpace(userAgent))

	// Look for version after slash (e.g., "curl/7.68.0")
	if idx := strings.Index(userAgent, "/"); idx != -1 {
		versionPart := userAgent[idx+1:]
		// Extract version numbers
		parts := strings.FieldsFunc(versionPart, func(r rune) bool {
			return !unicode.IsDigit(r) && r != '.'
		})
		if len(parts) > 0 {
			version := parts[0]
			// Simplify version to major.minor only for lower cardinality
			versionParts := strings.Split(version, ".")
			if len(versionParts) >= 2 {
				return versionParts[0] + "." + versionParts[1]
			} else if len(versionParts) == 1 {
				return versionParts[0]
			}
		}
	}

	// Look for version in parentheses (e.g., "Mozilla/5.0 (compatible)")
	if idx := strings.Index(userAgent, "("); idx != -1 {
		end := strings.Index(userAgent[idx:], ")")
		if end != -1 {
			versionPart := userAgent[idx+1 : idx+end]
			parts := strings.Fields(versionPart)
			for _, part := range parts {
				if len(part) > 0 && unicode.IsDigit(rune(part[0])) {
					// Simplify to major.minor
					versionParts := strings.Split(part, ".")
					if len(versionParts) >= 2 {
						return versionParts[0] + "." + versionParts[1]
					} else if len(versionParts) == 1 {
						return versionParts[0]
					}
				}
			}
		}
	}

	// Look for version after space (e.g., "Python 3.9.0")
	parts := strings.Fields(userAgent)
	for _, part := range parts {
		if len(part) > 0 && unicode.IsDigit(rune(part[0])) && strings.Contains(part, ".") {
			versionParts := strings.Split(part, ".")
			if len(versionParts) >= 2 {
				return versionParts[0] + "." + versionParts[1]
			} else if len(versionParts) == 1 {
				return versionParts[0]
			}
		}
	}

	return "unknown"
}

func (r *NormalizedRequest) NextUpstream() (Upstream, error) {
	if r == nil {
		return nil, fmt.Errorf("unexpected uninitialized request")
	}

	// Lock for 100% guaranteed sequential upstream selection
	r.upstreamMutex.Lock()
	defer r.upstreamMutex.Unlock()

	if len(r.upstreamList) == 0 {
		return nil, NewErrNoUpstreamsLeftToSelect(
			r,
			"no upstreams are set for this request",
		)
	}

	// Check if UseUpstream directive is set
	if r.directives != nil && r.directives.UseUpstream != "" {
		// Handle UseUpstream directive - find matching upstream
		for _, upstream := range r.upstreamList {
			match, err := WildcardMatch(r.directives.UseUpstream, upstream.Id())
			if err != nil {
				continue
			}
			if match {
				// Check if this upstream has already been consumed
				if _, loaded := r.ConsumedUpstreams.LoadOrStore(upstream, true); !loaded {
					return upstream, nil
				}
			}
		}
		// If no matching upstream found or all consumed, return error
		return nil, NewErrNoUpstreamsLeftToSelect(
			r,
			"no more non-consumed matching upstreams",
		)
	}

	upstreamCount := len(r.upstreamList)

	// Try all upstreams starting from current index with guaranteed sequential access
	for attempts := 0; attempts < upstreamCount; attempts++ {
		// Get current index and increment - this is now atomic within the mutex
		idx := r.UpstreamIdx % uint32(upstreamCount) // #nosec G115
		r.UpstreamIdx++                              // Guaranteed increment for next caller

		upstream := r.upstreamList[idx]

		// Skip if already consumed (gave valid response or consensus-valid error)
		if _, consumed := r.ConsumedUpstreams.Load(upstream); consumed {
			continue
		}

		// Skip if already responded with non-retryable error
		if prevErr, exists := r.ErrorsByUpstream.Load(upstream); exists {
			if pe, ok := prevErr.(error); ok && !IsRetryableTowardsUpstream(pe) {
				continue
			}
		}

		// Skip if already responded empty
		if _, isEmpty := r.EmptyResponses.Load(upstream); isEmpty {
			continue
		}

		// Try to reserve this upstream atomically
		// If LoadOrStore returns loaded=false, we successfully reserved it
		if _, loaded := r.ConsumedUpstreams.LoadOrStore(upstream, true); !loaded {
			// Successfully reserved this upstream
			return upstream, nil
		}
		// If we reach here, another goroutine reserved this upstream, continue to next
	}

	return nil, NewErrNoUpstreamsLeftToSelect(
		r,
		"no more non-consumed or working upstreams left",
	)
}

func (r *NormalizedRequest) MarkUpstreamCompleted(ctx context.Context, upstream Upstream, resp *NormalizedResponse, err error) {
	r.upstreamMutex.Lock()
	defer r.upstreamMutex.Unlock()

	hasResponse := resp != nil && !resp.IsObjectNull(ctx)

	// Check if this is a cancelled hedge - if so, just release and return
	if err != nil && HasErrorCode(err, ErrCodeEndpointRequestCanceled) {
		r.ConsumedUpstreams.Delete(upstream)
		// Don't store the error - this upstream wasn't really "tried"
		return
	}

	// We can re-use the same upstream on next rotation if there's no response or the error is retryable towards the upstream
	canReUse := !hasResponse || (err != nil && IsRetryableTowardsUpstream(err))

	if err != nil {
		r.ErrorsByUpstream.Store(upstream, err)
	} else if resp != nil && resp.IsResultEmptyish(ctx) {
		jr, err := resp.JsonRpcResponse(ctx)
		if jr == nil {
			r.ErrorsByUpstream.Store(upstream, NewErrEndpointMissingData(fmt.Errorf("upstream responded emptyish but cannot extract json-rpc response: %v", err), upstream))
		} else {
			r.ErrorsByUpstream.Store(upstream, NewErrEndpointMissingData(fmt.Errorf("upstream responded emptyish: %v", jr.GetResultString()), upstream))
		}
		r.EmptyResponses.Store(upstream, true)
	}

	if canReUse {
		r.ConsumedUpstreams.Delete(upstream)
	}
}
