# Port identifiers and numbers.
RPC_PORT_ID = "rpc"
RPC_PORT_NUMBER = 8545

WS_PORT_ID = "ws"
WS_PORT_NUMBER = 8546

DISCOVERY_PORT_ID = "discovery"
DISCOVERY_PORT_NUMBER = 30303

METRICS_PORT_ID = "metrics"
METRICS_PORT_NUMBER = 7071

PPROF_PORT_ID = "pprof"
PPROF_PORT_NUMBER = 6060

GRPC_PORT_ID = "grpc"
GRPC_PORT_NUMBER = 3131

# CPU and memory limits.
MAX_CPU = 4000  # in milicores (4 cores)
MAX_MEM = 16384  # in megabytes (16 GB)
