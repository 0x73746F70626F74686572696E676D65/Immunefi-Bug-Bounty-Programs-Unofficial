cl_shared = import_module("./shared.star")
constants = import_module("../config/constants.star")
context = import_module("./context.star")
el_launcher = import_module("../el/launcher.star")
el_shared = import_module("../el/shared.star")
heimdall_v2_launcher = import_module("./heimdall_v2/launcher.star")
rabbitmq = import_module("./rabbitmq.star")

LAUNCHERS = {
    constants.CL_TYPE.heimdall_v2: heimdall_v2_launcher.launch,
}


def launch(
    plan,
    participant,
    id,
    network_params,
    genesis_artifact,
    keys_artifact,
    node_ids,
    l1_rpc_url,
    container_proc_manager_artifact,
    producer_votes_str,
):
    # rabbitmq_url is only used by validator nodes to run the heimdall bridge.
    # Non-validator nodes don't run the bridge, so they don't need it.
    rabbitmq_url = ""
    is_validator = participant.get("kind") == constants.PARTICIPANT_KIND.validator
    if is_validator:
        rabbitmq_url = rabbitmq.launch(
            plan,
            id,
            participant.get("cl_queue_image"),
            participant.get("cl_log_level"),
            participant.get("cl_log_format"),
        )

    launch_method = _get_launcher(plan, participant)
    cl_node_name = generate_name(participant, id)

    el_node_name = el_launcher.generate_name(participant, id)
    el_rpc_url = "http://{}:{}".format(el_node_name, el_shared.RPC_PORT_NUMBER)
    el_grpc_url = "http://{}:{}".format(el_node_name, el_shared.GRPC_PORT_NUMBER)

    service = launch_method(
        plan,
        cl_node_name,
        participant,
        network_params,
        genesis_artifact,
        keys_artifact,
        node_ids,
        l1_rpc_url,
        el_rpc_url,
        el_grpc_url,
        rabbitmq_url,
        container_proc_manager_artifact,
        producer_votes_str,
    )
    http_rpc_url = service.ports[cl_shared.RPC_PORT_ID].url
    (_, _, rpc_host_port) = http_rpc_url.partition("://")
    ws_rpc_url = "ws://{}/websocket".format(rpc_host_port)

    return context.new_context(
        service_name=cl_node_name,
        api_url=service.ports[cl_shared.REST_API_PORT_ID].url,
        rpc_url=http_rpc_url,
        ws_rpc_url=ws_rpc_url,
        metrics_url=service.ports[cl_shared.METRICS_PORT_ID].url,
        cl_rpc_url=service.ports[cl_shared.RPC_PORT_ID].url,
    )


def wait_for_node_startup(plan, service_name):
    recipe = PostHttpRequestRecipe(
        endpoint="",
        content_type="application/json",
        body='{"method":"status","params":[],"id":1,"jsonrpc":"2.0"}',
        port_id=cl_shared.RPC_PORT_ID,
        extract={
            "id": ".result.node_info.id",
        },
    )
    plan.wait(
        description="Wait for '{}' to start up - it can take up to 1 minute".format(
            service_name
        ),
        service_name=service_name,
        recipe=recipe,
        field="extract.id",
        assertion="!=",
        target_value="",
        interval="1s",
        timeout="1m",
    )


def _get_launcher(plan, participant):
    cl_type = participant.get("cl_type")
    if cl_type not in LAUNCHERS:
        fail(
            "Unsupported CL launcher '{0}', need one of '{1}'".format(
                cl_type, ",".join(LAUNCHERS.keys())
            )
        )
    return LAUNCHERS.get(cl_type)


def generate_name(participant, id):
    cl_type = participant.get("cl_type")
    el_type = participant.get("el_type")
    suffix = participant.get("kind")
    # Mirror the EL `-archive` suffix here so paired EL/CL services share the
    # same name suffix and can be matched together. (Heimdall itself has its
    # own pruning knobs — cl_min_retain_blocks etc. — independent of this.)
    if participant.get("el_bor_archive_mode"):
        suffix = "{}-archive".format(suffix)
    return "l2-cl-{}-{}-{}-{}".format(id, cl_type, el_type, suffix)
