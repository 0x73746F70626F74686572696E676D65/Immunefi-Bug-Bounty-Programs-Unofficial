bor_launcher = import_module("./bor/launcher.star")
constants = import_module("../config/constants.star")
context = import_module("./context.star")
shared = import_module("./shared.star")

EL_KEYS_GENERATOR_FOLDER_PATH = "../../static_files/el/keys"

LAUNCHERS = {
    constants.EL_TYPE.bor: bor_launcher.launch,
}


def launch(
    plan,
    participant,
    id,
    network_params,
    el_genesis_artifact,
    cl_api_urls,
    cl_ws_rpc_urls,
    el_account,
    el_static_nodes,
    container_proc_manager_artifact,
    ethstats_server_params,
):
    # cl_api_urls / cl_ws_rpc_urls are lists; bor comma-joins them to
    # support multi-Heimdall failover. See src/el_cl_launcher.star
    # pass-2 for how the lists are built.
    el_node_name = generate_name(participant, id)

    # Generate keystore, nodekey and password.
    el_keys_artifact = _generate_keys(
        plan, el_node_name, el_account.eth_tendermint.private_key
    )

    # Launch node.
    launch_method = _get_launcher(participant)
    service = launch_method(
        plan,
        el_node_name,
        id,
        participant,
        network_params,
        el_genesis_artifact,
        el_keys_artifact,
        cl_api_urls,
        cl_ws_rpc_urls,
        el_account,
        el_static_nodes,
        container_proc_manager_artifact,
        ethstats_server_params,
    )
    return context.new_context(
        service_name=el_node_name,
        rpc_http_url=service.ports[shared.RPC_PORT_ID].url,
        ws_url=service.ports[shared.WS_PORT_ID].url,
        metrics_url=service.ports[shared.METRICS_PORT_ID].url,
    )


def _generate_keys(plan, el_node_name, private_key):
    keys_generator_artifact = plan.upload_files(
        name="{}-keys-generator-config".format(el_node_name),
        src=EL_KEYS_GENERATOR_FOLDER_PATH,
    )
    result = plan.run_sh(
        name="{}-keys-generator".format(el_node_name),
        description="Generating L2 EL node keys for '{}'".format(el_node_name),
        image=constants.IMAGES.get("toolbox_image"),
        env_vars={
            "EL_CLIENT_CONFIG_PATH": constants.EL_CLIENT_CONFIG_PATH,
            "PRIVATE_KEY": private_key,
        },
        files={
            "/opt/data/keys": keys_generator_artifact,
        },
        store=[
            StoreSpec(
                src=constants.EL_CLIENT_CONFIG_PATH,
                name="{}-keys".format(el_node_name),
            )
        ],
        run="bash /opt/data/keys/generate.sh",
    )
    artifact_count = len(result.files_artifacts)
    if artifact_count != 1:
        fail(
            "The EL keys generator should have generated one artifact, got {}.".format(
                artifact_count
            )
        )
    el_keys = result.files_artifacts[0]
    return el_keys


def wait_for_node_startup(plan, service_name):
    recipe = PostHttpRequestRecipe(
        endpoint="",
        content_type="application/json",
        body='{"method":"admin_nodeInfo","params":[],"id":1,"jsonrpc":"2.0"}',
        port_id=shared.RPC_PORT_ID,
        extract={
            "enode": ".result.enode",
        },
    )
    plan.wait(
        description="Wait for '{}' to start up - it can take up to 1 minute".format(
            service_name
        ),
        service_name=service_name,
        recipe=recipe,
        field="extract.enode",
        assertion="!=",
        target_value="",
        interval="1s",
        timeout="1m",
    )


def _get_launcher(participant):
    el_type = participant.get("el_type")
    if el_type not in LAUNCHERS:
        fail(
            "Unsupported EL launcher '{0}', need one of '{1}'".format(
                el_type, ",".join(LAUNCHERS.keys())
            )
        )
    return LAUNCHERS.get(el_type)


def generate_name(participant, id):
    cl_type = participant.get("cl_type")
    el_type = participant.get("el_type")
    suffix = participant.get("kind")
    # Reflect archive mode in the service name (e.g. `l2-el-1-bor-...-rpc-archive`)
    # so it's discoverable from `kurtosis enclave inspect` without reading config.
    if participant.get("el_bor_archive_mode"):
        suffix = "{}-archive".format(suffix)
    return "l2-el-{}-{}-{}-{}".format(
        id,
        el_type,
        cl_type,
        suffix,
    )
