constants = import_module("./constants.star")
math = import_module("../math/math.star")
sanity_check = import_module("./sanity_check.star")


DEV_ARGS = {
    "l1_backend": constants.L1_BACKEND.ethereum_package,
    "should_deploy_l1": True,
    "should_deploy_matic_contracts": True,
}


ANVIL_ARGS = {
    "image": constants.IMAGES.get("l1_anvil_image"),
    "network_id": constants.L1_CHAIN_ID,
    "block_time": 1,
    "slots_in_epoch": 2,  # block_time * slots_in_epoch = total seconds to transition a block from latest to safest
}


ETHEREUM_PACKAGE_ARGS = {
    "global_log_level": constants.LOG_LEVEL.info,
    # Custom property to set log format for all clients in the package.
    # Supported log formats are defined in `constants.LOG_FORMAT`.
    "global_log_format": constants.LOG_FORMAT.text,
    "participants": [
        {
            # General
            "count": 1,
            # Consensus client
            "cl_type": "lighthouse",
            "cl_image": constants.IMAGES.get("l1_cl_image"),
            "cl_max_cpu": 2000,  # in milicores (2 cores)
            "cl_max_mem": 4096,  # in megabytes (4 GB)
            # Execution client
            "el_type": "geth",
            "el_image": constants.IMAGES.get("l1_el_image"),
            "el_max_cpu": 3000,  # in milicores (3 cores)
            "el_max_mem": 8192,  # in megabytes (8 GB)
            # Validator client
            "use_separate_vc": True,
            "vc_type": "lighthouse",
            "vc_image": constants.IMAGES.get("l1_cl_image"),
            "vc_max_cpu": 2000,  # in milicores (2 cores)
            "vc_max_mem": 4096,  # in megabytes (4 GB)
            # Fulu hard fork config
            # In PeerDAS, a supernode is a node that custodies and samples all data columns (i.e. holds full awareness
            # of the erasure-coded blob data) and helps with distributed blob building — computing proofs and
            # broadcasting data on behalf of the proposer.
            # Since we don't enable perfect PeerDAS in the config, we need to have at least one supernode.
            "supernode": True,
        },
    ],
    "network_params": {
        "network_id": constants.L1_CHAIN_ID,
        "prefunded_accounts": "",
        "seconds_per_slot": 1,
        # The "minimal" preset is useful for rapid testing and development.
        # It takes 192 seconds to get to finalized epoch vs 1536 seconds with mainnet defaults.
        "preset": "minimal",
        # Ethereum hard fork configurations.
        # Supported fork epochs are documented in `static_files/genesis-generation-config/el-cl/values.env.tmpl`.
        # in the ethereum package repository.
        "altair_fork_epoch": 0,
        "bellatrix_fork_epoch": 0,
        "capella_fork_epoch": 0,
        "deneb_fork_epoch": 1,
        "electra_fork_epoch": 2,
        "fulu_fork_epoch": 3,  # Requires a supernode or perfect PeerDAS to be enabled.
        # Blob parameter only (BPO) forks bump the blob target/max. They require Fulu, so
        # every bpo_*_epoch must be >= fulu_fork_epoch. The ethereum package defaults them
        # to epoch 0, which is before our Fulu activation, so we schedule them explicitly:
        # both activate with Fulu. BPO 3 to 5 stay disabled, as in the ethereum package defaults.
        "bpo_1_epoch": 3,
        "bpo_2_epoch": 3,
    },
    "persistent": True,
}

# Log level and format are not set by default here to allow global log level override.
POLYGON_POS_PARTICIPANT = {
    "kind": constants.PARTICIPANT_KIND.validator,
    "cl_type": constants.CL_TYPE.heimdall_v2,
    "cl_image": constants.IMAGES.get("l2_cl_heimdall_v2_image"),
    "cl_queue_image": constants.IMAGES.get("l2_cl_queue_image"),
    "cl_min_retain_blocks": constants.CL_MIN_RETAIN_BLOCKS,
    "cl_compact_enabled": constants.CL_COMPACT_ENABLED,
    "cl_compaction_interval": constants.CL_COMPACTION_INTERVAL,
    "cl_storage_pruning_interval": constants.CL_STORAGE_PRUNING_INTERVAL,
    "cl_indexer_pruning_enabled": constants.CL_INDEXER_PRUNING_ENABLED,
    "el_type": constants.EL_TYPE.bor,
    "el_image": constants.IMAGES.get("l2_el_bor_image"),
    "count": 1,
}

POLYGON_POS_EL_BOR_PARTICIPANT = {
    "el_bor_produce_witness": False,
    "el_bor_sync_with_witness": False,
    "el_bor_stateless_parallel_import": False,
    "el_bor_archive_mode": False,
    "el_bor_use_sequence_store": False,
}

POLYGON_POS_PACKAGE_ARGS = {
    "log_level": constants.LOG_LEVEL.info,
    "log_format": constants.LOG_FORMAT.text,
    # The first participant is a validator and an archive node.
    "participants": [POLYGON_POS_PARTICIPANT | {"el_bor_archive_mode": True}],
    "setup_images": {
        "contract_deployer": constants.IMAGES.get("pos_contract_deployer_image"),
        "el_genesis_builder": constants.IMAGES.get("pos_el_genesis_builder_image"),
        "validator_config_generator": constants.IMAGES.get(
            "pos_validator_config_generator_image"
        ),
    },
    "network_params": {
        # Admin account generated using `cast wallet new`.
        # This private key is used to deploy Polygon PoS contracts on both L1 and L2.
        "admin_private_key": "0xd40311b5a5ca5eaeb48dfba5403bde4993ece8eccf4190e98e19fcd4754260ea",
        # Validators params.
        # Mnemonic for generating validator keys.
        "preregistered_validator_keys_mnemonic": "sibling lend brave explain wait orbit mom alcohol disorder message grace sun",
        "validator_stake_amount_eth": 10000,  # in ether
        "validator_top_up_fee_amount_eth": 2000,  # in ether
        # "cl_environment": constants.CL_ENVIRONMENT.local,
        "cl_span_poll_interval": "5s",
        "cl_checkpoint_poll_interval": "5s",
        "cl_max_age_num_blocks": 100000,
        "cl_avg_checkpoint_length": "8",
        "cl_checkpoint_buffer_time": "10s",
        "el_block_interval_seconds": 1,
        "el_sprint_duration": constants.EL_SPRINT_DURATION,
        "el_span_duration": constants.EL_SPAN_DURATION,
        # Mirrors the amoy BP (200M). Mainnet BP is 120M. Sources:
        #   amoy BP:    pos-ops/roles/deploy-amoy-config/amoy/pos-amoy-london-bp-nvme-01/bor/config.toml#L83
        #   mainnet BP: pos-ops/roles/deploy-mainnet-config/mainnet/anonymous-91/bor/config.toml#L65
        "el_gas_limit": 200000000,
        # Polygon PoS hard fork configurations
        "jaipur_fork_block": constants.EL_HARD_FORK_BLOCKS.get("jaipur"),
        "delhi_fork_block": constants.EL_HARD_FORK_BLOCKS.get("delhi"),
        "indore_fork_block": constants.EL_HARD_FORK_BLOCKS.get("indore"),
        "agra_fork_block": constants.EL_HARD_FORK_BLOCKS.get("agra"),
        "napoli_fork_block": constants.EL_HARD_FORK_BLOCKS.get("napoli"),
        "ahmedabad_fork_block": constants.EL_HARD_FORK_BLOCKS.get("ahmedabad"),
        "bhilai_fork_block": constants.EL_HARD_FORK_BLOCKS.get("bhilai"),
        "rio_fork_block": constants.EL_HARD_FORK_BLOCKS.get("rio"),
        "madhugiri_fork_block": constants.EL_HARD_FORK_BLOCKS.get("madhugiri"),
        "madhugiri_pro_fork_block": constants.EL_HARD_FORK_BLOCKS.get("madhugiriPro"),
        "dandeli_fork_block": constants.EL_HARD_FORK_BLOCKS.get("dandeli"),
        "lisovo_fork_block": constants.EL_HARD_FORK_BLOCKS.get("lisovo"),
        "lisovo_pro_fork_block": constants.EL_HARD_FORK_BLOCKS.get("lisovoPro"),
        "giugliano_fork_block": constants.EL_HARD_FORK_BLOCKS.get("giugliano"),
        "chicago_fork_block": constants.EL_HARD_FORK_BLOCKS.get("chicago"),
        "valencia_fork_block": constants.EL_HARD_FORK_BLOCKS.get("valencia"),
        "austin_fork_block": constants.EL_HARD_FORK_BLOCKS.get("austin"),
    },
    "additional_services": [],
}

SEQUENCE_STORE_ARGS = {
    "image": constants.SEQSTORE_DEFAULT_IMAGE,
    "redpanda_image": constants.IMAGES.get("seqstore_redpanda_image"),
    "redpanda_count": 1,
    "gateway_count": 1,
    "envoy_image": constants.IMAGES.get("seqstore_envoy_image"),
}

STATUS_CHECKER_ARGS = {
    "image": constants.IMAGES.get("status_checker_image"),
}

ETHSTATS_SERVER_ARGS = {
    "image": constants.IMAGES.get("ethstats_server_image"),
    "ws_secret": constants.ETHSTATS_SERVER_WS_SECRET,
}


def input_parser(plan, input_args):
    plan.print("Parsing the dev input args")
    dev_input_args = input_args.get("dev", {})
    dev_args = _parse_dev_args(plan, dev_input_args)
    l1_backend = dev_args.get("l1_backend")
    plan.print("Dev input args parsed: {}".format(str(dev_args)))

    plan.print("Parsing the L1 input args")
    l1_args = {}
    if l1_backend == constants.L1_BACKEND.ethereum_package:
        ethereum_input_args = input_args.get("ethereum_package", {})
        l1_args = _parse_ethereum_args(plan, ethereum_input_args)
    elif l1_backend == constants.L1_BACKEND.anvil:
        anvil_input_args = input_args.get("anvil", {})
        l1_args = _parse_anvil_args(plan, anvil_input_args)
    else:
        fail('Unsupported L1 backend: "{}".'.format(l1_backend))
    plan.print("L1 input anvil args parsed: {}".format(str(l1_args)))

    plan.print("Parsing the L2 input args")
    polygon_pos_input_args = input_args.get("polygon_pos_package", {})
    polygon_pos_args = _parse_polygon_pos_args(plan, polygon_pos_input_args)
    plan.print("L2 input args parsed: {}".format(str(polygon_pos_args)))

    return (l1_args, polygon_pos_args, dev_args)


def _parse_anvil_args(plan, anvil_args):
    anvil_args = dict(anvil_args) if anvil_args else {}

    # Set default params if not provided.
    for k, v in ANVIL_ARGS.items():
        anvil_args.setdefault(k, v)

    # Sort the dict and return the result.
    return _sort_dict_by_values(anvil_args)


def _parse_ethereum_args(plan, ethereum_args):
    # Create a mutable copy of ethereum_args.
    ethereum_args = dict(ethereum_args) if ethereum_args else {}

    # Set default top-level params if not provided.
    for k, v in ETHEREUM_PACKAGE_ARGS.items():
        if k != "network_params":
            ethereum_args.setdefault(k, v)

    # Set default network_params if not provided.
    network_params = ethereum_args.get("network_params", {})
    for k, v in ETHEREUM_PACKAGE_ARGS.get("network_params", {}).items():
        network_params.setdefault(k, v)
    ethereum_args["network_params"] = network_params

    # Validate global_log_format.
    log_format = ethereum_args.get("global_log_format")
    if log_format not in sanity_check.VALID_LOG_FORMATS:
        fail(
            'Invalid "global_log_format": "{}". Allowed values: {}.'.format(
                log_format, sanity_check.VALID_LOG_FORMATS
            )
        )

    # Sort the dict and return the result.
    return _sort_dict_by_values(ethereum_args)


def _parse_polygon_pos_args(plan, polygon_pos_args):
    polygon_pos_args = dict(polygon_pos_args) if polygon_pos_args else {}

    # Parse the polygon pos input args and set defaults if needed.
    result = {}

    log_level = polygon_pos_args.get("log_level", constants.LOG_LEVEL.info)
    log_format = polygon_pos_args.get("log_format", constants.LOG_FORMAT.text)
    result["log_level"] = log_level
    result["log_format"] = log_format

    participants = polygon_pos_args.get("participants", [])
    result["participants"] = _parse_participants(participants, log_level, log_format)

    setup_images = polygon_pos_args.get("setup_images", {})
    result["setup_images"] = _parse_setup_images(setup_images)

    network_params = polygon_pos_args.get("network_params", {})
    result["network_params"] = _parse_network_params(network_params)

    additional_services = polygon_pos_args.get("additional_services", [])
    result["additional_services"] = _parse_additional_services(additional_services)

    is_status_checker_deployed = (
        constants.ADDITIONAL_SERVICES.status_checker in result["additional_services"]
    )
    status_checker_params = polygon_pos_args.get("status_checker_params", {})
    result["status_checker_params"] = _parse_status_checker_params(
        is_status_checker_deployed, status_checker_params
    )

    is_ethstats_server_deployed = (
        constants.ADDITIONAL_SERVICES.ethstats_server in result["additional_services"]
    )
    ethstats_server_params = polygon_pos_args.get("ethstats_server_params", {})
    result["ethstats_server_params"] = _parse_ethstats_server_params(
        is_ethstats_server_deployed, ethstats_server_params
    )

    # The sequence store is deployed iff any participant opts into it.
    is_sequence_store_deployed = any(
        [p.get("el_bor_use_sequence_store") for p in result["participants"]]
    )
    sequence_store_params = polygon_pos_args.get("sequence_store_params", {})
    result["sequence_store_params"] = _parse_sequence_store_params(
        is_sequence_store_deployed, sequence_store_params
    )

    # Sanity check and return the result.
    sanity_check.sanity_check_polygon_args(plan, result)
    return _sort_dict_by_values(result)


def _parse_dev_args(plan, dev_args):
    # Create a mutable copy of dev_args.
    if dev_args:
        dev_args = dict(dev_args)
    else:
        # Set default dev args if not provided.
        dev_args = dict(DEV_ARGS)

    # Set default params if not provided.
    for k, v in DEV_ARGS.items():
        dev_args.setdefault(k, v)

    # Sanity check and return the result.
    sanity_check.sanity_check_dev_args(plan, dev_args)
    return _sort_dict_by_values(dev_args)


def _parse_participants(participants, log_level, log_format):
    participants_with_defaults = []

    # Set default participant if not provided.
    if len(participants) == 0:
        participants = POLYGON_POS_PACKAGE_ARGS.get("participants", [])

    for p in participants:
        # Create a mutable copy of participant.
        p = dict(p)

        # Set default CL image based on `cl_type` if provided
        cl_type = p.get("cl_type", "")
        cl_image = p.get("cl_image", "")
        if cl_type and not cl_image:
            if cl_type == constants.CL_TYPE.heimdall_v2:
                p["cl_image"] = constants.IMAGES.get("l2_cl_heimdall_v2_image")
            else:
                fail("Invalid CL client type: '{}'.".format(cl_type))

        # Set default EL image based on `el_type` if provided.
        el_type = p.get("el_type", "")
        el_image = p.get("el_image", "")
        if el_type and not el_image:
            if el_type == constants.EL_TYPE.bor:
                p["el_image"] = constants.IMAGES.get("l2_el_bor_image")
            else:
                fail("Invalid EL client type: '{}'.".format(el_type))

        # Set log levels to global log level if not provided.
        cl_log_level = p.get("cl_log_level", "")
        el_log_level = p.get("el_log_level", "")
        if log_level:
            if not cl_log_level:
                p["cl_log_level"] = log_level
            if not el_log_level:
                p["el_log_level"] = log_level

        cl_log_format = p.get("cl_log_format", "")
        el_log_format = p.get("el_log_format", "")
        if log_format:
            if not cl_log_format:
                p["cl_log_format"] = log_format
            if not el_log_format:
                p["el_log_format"] = log_format

        # Fill in any missing fields with default values.
        for k, v in POLYGON_POS_PARTICIPANT.items():
            p.setdefault(k, v)

        # Fill in any missing fields with default values for bor participants.
        # Re-read el_type from p so the defaulted value (set just above) is also honoured.
        if p.get("el_type") == constants.EL_TYPE.bor:
            for k, v in POLYGON_POS_EL_BOR_PARTICIPANT.items():
                p.setdefault(k, v)

        # Assign the modified dictionary back to the list.
        participants_with_defaults.append(p)

    # Sort each participant dictionary and return the result
    return [_sort_dict_by_values(p) for p in participants_with_defaults]


def _parse_setup_images(setup_images):
    # Create a mutable copy of setup_images.
    if setup_images:
        # Create a mutable copy of setup_images.
        setup_images = dict(setup_images)
    else:
        # Set default matic contracts params if not provided.
        setup_images = dict(POLYGON_POS_PACKAGE_ARGS.get("setup_images", {}))

    for k, v in POLYGON_POS_PACKAGE_ARGS.get("setup_images", {}).items():
        setup_images.setdefault(k, v)

    # Sort the dict and return the result.
    return _sort_dict_by_values(setup_images)


def _parse_network_params(network_params):
    if network_params:
        # Create a mutable copy of network_params.
        network_params = dict(network_params)
    else:
        # Set default network params if not provided.
        network_params = dict(POLYGON_POS_PACKAGE_ARGS.get("network_params", {}))

    for k, v in POLYGON_POS_PACKAGE_ARGS.get("network_params", {}).items():
        network_params.setdefault(k, v)

    # Sort the dict and return the result.
    return _sort_dict_by_values(network_params)


def _parse_additional_services(additional_services):
    # Set default additional services if not provided.
    if len(additional_services) == 0:
        additional_services = POLYGON_POS_PACKAGE_ARGS.get("additional_services", [])
    return additional_services


def _parse_sequence_store_params(is_sequence_store_deployed, sequence_store_params):
    # Store params without a participant opting in would be silently dead
    # config, most likely a mistake.
    if not is_sequence_store_deployed:
        if sequence_store_params:
            fail(
                "`sequence_store_params` requires at least one participant with `el_bor_use_sequence_store: true`."
            )
        return {}

    # Create a mutable copy of sequence_store_params.
    if sequence_store_params:
        sequence_store_params = dict(sequence_store_params)
    else:
        sequence_store_params = {}

    for k, v in SEQUENCE_STORE_ARGS.items():
        sequence_store_params.setdefault(k, v)

    # Sort the dict and return the result.
    return _sort_dict_by_values(sequence_store_params)


def _parse_status_checker_params(is_status_checker_deployed, status_checker_params):
    # If the status checker is not deployed, return an empty dict.
    if not is_status_checker_deployed:
        return {}

    # Create a mutable copy of status_checker_params.
    if status_checker_params:
        status_checker_params = dict(status_checker_params)
    else:
        # Set default status checker params if not provided.
        status_checker_params = dict(
            POLYGON_POS_PACKAGE_ARGS.get("status_checker_params", {})
        )

    for k, v in STATUS_CHECKER_ARGS.items():
        status_checker_params.setdefault(k, v)

    # Sort the dict and return the result.
    return _sort_dict_by_values(status_checker_params)


def _parse_ethstats_server_params(is_ethstats_server_deployed, ethstats_server_params):
    # If the status checker is not deployed, return an empty dict.
    if not is_ethstats_server_deployed:
        return {}

    # Create a mutable copy of ethstats_server_params.
    if ethstats_server_params:
        ethstats_server_params = dict(ethstats_server_params)
    else:
        # Set default status checker params if not provided.
        ethstats_server_params = dict(
            POLYGON_POS_PACKAGE_ARGS.get("ethstats_server_params", {})
        )

    for k, v in ETHSTATS_SERVER_ARGS.items():
        ethstats_server_params.setdefault(k, v)

    # Sort the dict and return the result.
    return _sort_dict_by_values(ethstats_server_params)


def _sort_dict_by_values(d):
    sorted_items = sorted(d.items(), key=lambda x: x[0])
    return {k: v for k, v in sorted_items}
