constants = import_module("../config/constants.star")
hex = import_module("../hex/hex.star")
math = import_module("../math/math.star")


EL_GENESIS_BUILDER_SCRIPT_FILE_PATH = "../../static_files/el/genesis/builder.sh"
EL_GENESIS_TEMPLATE_FILE_PATH = "../../static_files/el/genesis/genesis.json"


def generate(
    plan,
    polygon_pos_args,
    validator_accounts,
    validator_config_artifact,
    admin_address,
):
    network_params = polygon_pos_args.get("network_params")
    setup_images = polygon_pos_args.get("setup_images")

    # Generate a temporary EL genesis with an empty `alloc` field.
    el_genesis_temporary_artifact = plan.render_templates(
        name="l2-el-genesis-tmp",
        config={
            "genesis.json": struct(
                template=read_file(EL_GENESIS_TEMPLATE_FILE_PATH),
                data={
                    # chain params
                    "el_chain_id": constants.EL_CHAIN_ID,
                    "el_sprint_duration": network_params.get("el_sprint_duration"),
                    "el_gas_limit_hex": hex.int_to_hex(
                        network_params.get("el_gas_limit")
                    ),
                    # hardfork configurations
                    "jaipur_fork_block": network_params.get("jaipur_fork_block"),
                    "delhi_fork_block": network_params.get("delhi_fork_block"),
                    "indore_fork_block": network_params.get("indore_fork_block"),
                    "agra_fork_block": network_params.get("agra_fork_block"),
                    "napoli_fork_block": network_params.get("napoli_fork_block"),
                    "ahmedabad_fork_block": network_params.get("ahmedabad_fork_block"),
                    "bhilai_fork_block": network_params.get("bhilai_fork_block"),
                    "rio_fork_block": network_params.get("rio_fork_block"),
                    "madhugiri_fork_block": network_params.get("madhugiri_fork_block"),
                    "madhugiri_pro_fork_block": network_params.get(
                        "madhugiri_pro_fork_block"
                    ),
                    "dandeli_fork_block": network_params.get("dandeli_fork_block"),
                    "lisovo_fork_block": network_params.get("lisovo_fork_block"),
                    "lisovo_pro_fork_block": network_params.get(
                        "lisovo_pro_fork_block"
                    ),
                    "giugliano_fork_block": network_params.get("giugliano_fork_block"),
                    "chicago_fork_block": network_params.get("chicago_fork_block"),
                    "valencia_fork_block": network_params.get("valencia_fork_block"),
                    "austin_fork_block": network_params.get("austin_fork_block"),
                },
            )
        },
    )

    # Compute a future EL genesis timestamp so all bor nodes have time to
    # boot and peer before mining starts. Delay scales with node count,
    # capped at 180s.
    delay = _compute_delay(len(validator_accounts))
    timestamp_result = plan.run_sh(
        name="l2-el-genesis-timestamp",
        description="Computing future EL genesis timestamp ({}s from now)".format(
            delay
        ),
        run="printf '%s' $(( $(date +%s) + {} ))".format(delay),
    )
    timestamp = timestamp_result.output

    # Generate the alloc field of the EL genesis and return the final EL genesis.
    el_genesis_builder_script_artifact = plan.upload_files(
        name="l2-el-genesis-builder-config",
        src=EL_GENESIS_BUILDER_SCRIPT_FILE_PATH,
    )
    result = plan.run_sh(
        name="l2-el-genesis-generator",
        description="Generating L2 EL genesis",
        image=setup_images.get("el_genesis_builder"),
        env_vars={
            "EL_CHAIN_ID": str(constants.EL_CHAIN_ID),
            "CL_CHAIN_ID": str(constants.CL_CHAIN_ID),
            # Note that we don't add the admin address to the alloc in starlark because
            # admin_address is a Kurtosis future string. We can't perform any string
            # operations on it like removing the "0x" prefix. We do it in the bash script.
            "ADMIN_ADDRESS": admin_address,
            "ADMIN_BALANCE_WEI": hex.int_to_hex(
                math.ether_to_wei(constants.ADMIN_BALANCE_ETH)
            ),
            "EL_GENESIS_TIMESTAMP": timestamp,
        },
        files={
            # Load the artefacts one by one instead of using a Directory because it is not
            # supported by Kurtosis when using plan.run_sh unfortunately.
            "/opt/data/genesis": el_genesis_temporary_artifact,
            "/opt/data/genesis-builder": el_genesis_builder_script_artifact,
            "/opt/data/validator": validator_config_artifact,
        },
        store=[
            StoreSpec(
                src="/opt/data/genesis/genesis.json",
                name="l2-el-genesis",
            ),
        ],
        run="bash /opt/data/genesis-builder/builder.sh",
    )
    artifact_count = len(result.files_artifacts)
    if artifact_count != 1:
        fail(
            "The EL genesis generator should have generated 1 artifact, got {}.".format(
                artifact_count
            )
        )
    l2_el_genesis_artifact = result.files_artifacts[0]
    return l2_el_genesis_artifact


# Returns how many seconds to push the genesis timestamp into the future so all
# validators are ready to mine when bor wakes up. Numbers chosen by hand:
#   - 0 for single-node devnet: nothing to peer with, no race.
#   - 90s base: covers Docker Desktop / local-dev environments where image-pull
#     and the static-nodes P2P handshake settle slower than GHA runners. The
#     previous 45s floor was sufficient for n=2 on GHA but failed at n=4 on
#     macOS — bor woke up before all peers had completed handshake, forking at
#     sprint 0 (Heimdall HTTP 500 on /bor/spans/1, gRPC code 18 on span
#     broadcasts, l2-startup-monitor 5-min timeout).
#   - +15s per extra validator: docker daemon / disk / image-pull contention
#     scales faster than the original +5s slope assumed once n > 2.
#   - 240s cap: image-pull bandwidth dominates beyond that.
def _compute_delay(n):
    if n <= 1:
        return 0
    return min(240, 90 + 15 * (n - 2))
