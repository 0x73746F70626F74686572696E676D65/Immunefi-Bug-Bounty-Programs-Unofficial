constants = import_module("../../config/constants.star")
shared = import_module("../shared.star")


# The folder where the heimdall templates are stored in the repository.
HEIMDALL_TEMPLATES_FOLDER_PATH = "../../../static_files/cl/heimdall_v2"


def launch(
    plan,
    cl_node_name,
    participant,
    network_params,
    cl_genesis_artifact,
    cl_keys_artifact,
    cl_node_ids,
    l1_rpc_url,
    el_rpc_url,
    el_grpc_url,
    amqp_url,
    container_proc_manager_artifact,
    producer_votes_str,
):
    heimdall_node_config_artifacts = plan.render_templates(
        name="{}-config".format(cl_node_name),
        config={
            "app.toml": struct(
                template=read_file(
                    "{}/app.toml".format(HEIMDALL_TEMPLATES_FOLDER_PATH)
                ),
                data={
                    "kind": participant.get("kind"),
                    # Network params.
                    "cl_environment": network_params.get("cl_environment"),
                    "cl_min_retain_blocks": participant.get("cl_min_retain_blocks"),
                    "span_poll_interval": network_params.get("cl_span_poll_interval"),
                    "checkpoint_poll_interval": network_params.get(
                        "cl_checkpoint_poll_interval"
                    ),
                    "producer_votes": producer_votes_str,
                    # URLs.
                    "amqp_url": amqp_url,
                    "el_rpc_url": el_rpc_url,
                    "el_grpc_url": el_grpc_url,
                    "l1_rpc_url": l1_rpc_url,
                    # Port numbers.
                    "rest_api_port_number": shared.REST_API_PORT_NUMBER,
                    "grpc_port_number": shared.GRPC_PORT_NUMBER,
                    "rpc_port_number": shared.RPC_PORT_NUMBER,
                },
            ),
            "client.toml": struct(
                template=read_file(
                    "{}/client.toml".format(HEIMDALL_TEMPLATES_FOLDER_PATH),
                ),
                data={
                    "cl_chain_id": constants.CL_CHAIN_ID,
                    "rpc_port_number": shared.RPC_PORT_NUMBER,
                },
            ),
            "config.toml": struct(
                template=read_file(
                    "{}/config.toml".format(HEIMDALL_TEMPLATES_FOLDER_PATH)
                ),
                data={
                    # Node params.
                    "moniker": cl_node_name,
                    "log_level": participant.get("cl_log_level"),
                    "log_format": participant.get("cl_log_format"),
                    "persistent_peers": cl_node_ids,
                    "cl_compact_enabled": participant.get("cl_compact_enabled"),
                    "cl_compaction_interval": participant.get("cl_compaction_interval"),
                    "cl_storage_pruning_interval": participant.get(
                        "cl_storage_pruning_interval"
                    ),
                    "cl_indexer_pruning_enabled": participant.get(
                        "cl_indexer_pruning_enabled"
                    ),
                    # Port numbers.
                    "proxy_app_port_number": shared.PROXY_LISTEN_PORT_NUMBER,
                    "rpc_port_number": shared.RPC_PORT_NUMBER,
                    "p2p_listen_port_number": shared.NODE_LISTEN_PORT_NUMBER,
                    "metrics_port_number": shared.METRICS_PORT_NUMBER,
                    "pprof_port_number": shared.PPROF_PORT_NUMBER,
                },
            ),
        },
    )

    is_validator = participant.get("kind") == constants.PARTICIPANT_KIND.validator
    if is_validator:
        heimdall_cmds = [
            " && ".join(
                [
                    # Copy CL genesis, node and validator keys inside heimdall config folder.
                    "cp /opt/data/genesis/genesis.json /opt/data/keys/node_key.json /opt/data/keys/priv_validator_key.json {}/config/".format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    "mkdir -p {}/data".format(shared.CONFIG_FOLDER_PATH),
                    "cp /opt/data/keys/priv_validator_state.json {}/data/priv_validator_state.json".format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    # Heimdall-v2 requires that the `round` property of priv_validator_state.json be of type int32.
                    'sed -i \'s/"round": "\\([0-9]*\\)"/"round": \\1/\' {}/data/priv_validator_state.json'.format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    # Start heimdall with the bridge using the container proc manager script.
                    "/usr/local/share/container-proc-manager.sh heimdalld start --all --bridge --home {} --log_no_color --rest-server".format(
                        shared.CONFIG_FOLDER_PATH,
                    ),
                ]
            )
        ]
    else:
        heimdall_cmds = [
            " && ".join(
                [
                    # Copy CL genesis inside heimdall config folder.
                    "cp /opt/data/genesis/genesis.json {}/config/".format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    # Auto-generate node keys (no pre-generated validator keys for rpc/archive nodes).
                    "heimdalld init {} --home /tmp/init-data".format(cl_node_name),
                    "cp /tmp/init-data/config/node_key.json /tmp/init-data/config/priv_validator_key.json {}/config/".format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    "mkdir -p {}/data".format(shared.CONFIG_FOLDER_PATH),
                    "cp /tmp/init-data/data/priv_validator_state.json {}/data/priv_validator_state.json".format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    # Heimdall-v2 requires that the `round` property of priv_validator_state.json be of type int32.
                    'sed -i \'s/"round": "\\([0-9]*\\)"/"round": \\1/\' {}/data/priv_validator_state.json'.format(
                        shared.CONFIG_FOLDER_PATH
                    ),
                    # Start heimdall without the bridge using the container proc manager script.
                    "/usr/local/share/container-proc-manager.sh heimdalld start --all --home {} --log_no_color --rest-server".format(
                        shared.CONFIG_FOLDER_PATH,
                    ),
                ]
            )
        ]

    files = {
        # app data
        shared.APP_DATA_FOLDER_PATH: Directory(
            persistent_key="{}-data".format(cl_node_name)
        ),
        "{}/data".format(shared.CONFIG_FOLDER_PATH): Directory(
            persistent_key="{}-config-data".format(cl_node_name)
        ),
        "{}/bridge".format(shared.CONFIG_FOLDER_PATH): Directory(
            persistent_key="{}-bridge-data".format(cl_node_name)
        ),
        # config
        "{}/config".format(shared.CONFIG_FOLDER_PATH): heimdall_node_config_artifacts,
        "/opt/data/genesis": cl_genesis_artifact,
        # utils scripts
        "/usr/local/share": container_proc_manager_artifact,
    }
    if is_validator:
        files["/opt/data/keys"] = cl_keys_artifact

    return plan.add_service(
        name="{}".format(cl_node_name),
        config=ServiceConfig(
            image=participant.get("cl_image"),
            ports={
                shared.REST_API_PORT_ID: PortSpec(
                    number=shared.REST_API_PORT_NUMBER,
                    application_protocol="http",
                ),
                shared.GRPC_PORT_ID: PortSpec(
                    number=shared.GRPC_PORT_NUMBER,
                    application_protocol="grpc",
                ),
                shared.NODE_LISTEN_PORT_ID: PortSpec(
                    number=shared.NODE_LISTEN_PORT_NUMBER,
                    application_protocol="http",
                ),
                shared.RPC_PORT_ID: PortSpec(
                    number=shared.RPC_PORT_NUMBER,
                    application_protocol="http",
                ),
                shared.METRICS_PORT_ID: PortSpec(
                    number=shared.METRICS_PORT_NUMBER,
                    application_protocol="http",
                ),
                shared.PPROF_PORT_ID: PortSpec(
                    number=shared.PPROF_PORT_NUMBER,
                    application_protocol="http",
                ),
            },
            files=files,
            entrypoint=["sh", "-c"],
            cmd=[" && ".join(heimdall_cmds)],
            max_cpu=shared.MAX_CPU,
            max_memory=shared.MAX_MEM,
        ),
    )
