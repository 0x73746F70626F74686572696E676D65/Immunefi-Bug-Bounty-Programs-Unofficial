#!/usr/bin/env bash
set -euo pipefail

# Source logging library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/log.sh"

# Alpine image pinned by digest so the extract tooling is reproducible and
# not affected by an upstream `alpine:latest` rebase. Must match restore.sh.
ALPINE_IMAGE="alpine@sha256:5b10f432ef3da1b8d4c7eb6c487f2f5a8f096bc91145e68878dd4a5019afde11"
ALPINE_ZSTD_IMAGE="kurtosis-pos-alpine-zstd:local"

# Build the zstd-enabled alpine image once. Matches the snapshot/restore-side
# derivation so a snapshot built on one host can be extracted on another
# without depending on a pre-built image being present.
ensure_alpine_zstd_image() {
  if ! docker image inspect "$ALPINE_ZSTD_IMAGE" > /dev/null 2>&1; then
    docker build --quiet --tag "$ALPINE_ZSTD_IMAGE" - << EOF > /dev/null
FROM $ALPINE_IMAGE
RUN apk add --no-cache zstd
EOF
  fi
}

# Parse arguments
image_name="${1:-""}"
if [[ -z "$image_name" ]]; then
  log_error "Image name is required"
  exit 1
fi
log_info "Using image: $image_name"

default_output_dir="./tmp"
output_dir="${2:-$default_output_dir}"
if [[ -z "$output_dir" ]]; then
  log_error "Output directory is required"
  exit 1
fi
log_info "Using output directory: $output_dir"

# Create output directory
mkdir -p "$output_dir"
volume_folder_path="$output_dir/volumes"
mkdir -p "$volume_folder_path"

# Create a temporary container from the snapshot image to copy files out
log_info "Downloading snapshot files from image"
container_id=$(docker create "$image_name" /bin/true)
docker cp "$container_id:/volumes/." "$volume_folder_path/"
docker cp "$container_id:/docker-compose.yaml" "$output_dir/docker-compose.yaml"
docker cp "$container_id:/contractAddresses.json" "$output_dir/contractAddresses.json"
docker cp "$container_id:/l2-genesis.json" "$output_dir/l2-genesis.json"
# Only present for anvil-backend snapshots (see snapshot.sh); tolerate absence.
docker cp "$container_id:/anvil-state.hex" "$output_dir/anvil-state.hex" 2> /dev/null || true
log_info "Files downloaded to $output_dir"

docker rm "$container_id" > /dev/null
log_info "Temporary container removed"

# Extract each `.tar.zst` into its own directory under $volume_folder_path/.
# Run the extraction inside an alpine container (with zstd) so it executes as
# root: the archives include directories with modes like `0600` (no execute
# bit) — on the lighthouse VC's `secrets/` dir — and host-side tar as a
# non-root user would silently fail to write files into them, corrupting the
# validator's keystore/secret pairing.
ensure_alpine_zstd_image
log_info "Extracting volume archives"
abs_volume_folder_path="$(realpath "$volume_folder_path")"
for f in "$volume_folder_path"/*.tar.zst; do
  (
    name=$(basename "$f" .tar.zst)
    mkdir -p "$volume_folder_path/$name"
    docker run --rm \
      -v "$abs_volume_folder_path":/backup \
      -v "$abs_volume_folder_path/$name":/out \
      "$ALPINE_ZSTD_IMAGE" sh -c "zstd -d -q -c /backup/$(basename "$f") | tar xf - -C /out && chown -R $(id -u):$(id -g) /out"
    log_info "Extracted: $name"
    rm "$f"
  ) &
done
wait
log_info "Snapshot extracted to $output_dir"
