# Polygon PoS Kurtosis Package

This project provides a modular, reproducible environment for developing, testing, and running [Polygon PoS](https://docs.polygon.technology/pos/) devnets using [Kurtosis](https://kurtosis.com/).

Specifically, this package will:

1. Spin up a local L1 blockchain, fully customizable with multi-client support, leveraging the [Ethereum Kurtosis package](https://github.com/ethpandaops/ethereum-package).
2. Deploy the Polygon PoS contract suite to L1 and L2: [plasma bridge](https://github.com/0xPolygon/pos-contracts), [MATIC→POL migration](https://github.com/0xPolygon/pol-token), [pos bridge](https://github.com/maticnetwork/pos-portal), and the [sPOL / LST](https://github.com/0xPolygon/spol-contracts) liquid-staking contracts. Stakes for each validator.
3. Generate L2 consensus and execution layer genesis information.
4. Configure and launch a network of Polygon PoS nodes.

Optional features:

- Run a transaction spammer to simulate network load.
- Deploy monitoring solutions such as [Prometheus](https://prometheus.io/), [Grafana](https://grafana.com/), [Panoptichain](https://github.com/0xPolygon/panoptichain) and [Blockscout](https://www.blockscout.com/) to observe the network.

> 🚨 This package is for development and testing only — **not for production use!**

## Sections

### [Getting Started](./docs/docs/introduction/getting-started.md)

Install Kurtosis and set up your first devnet.

### [Configuration](./docs/docs/configuration/overview.md)

Learn how to configure your devnet deployment.

### Guides

Step-by-step guides for working with devnets in Kurtosis.

- [Interact with the devnet](./docs/docs/guides/interact-with-the-devnet.md)
- [Run bridge tests](./docs/docs/guides/run-bridge-tests.md)
- [Partial devnet redeploy](./docs/docs/guides/partial-devnet-redeploy.md)

### [Version Matrix](./docs/docs/version-matrix.md)

The versions of every component the package deploys, compared against the latest upstream releases.

### [Architecture](./docs/docs/configuration/overview.md)

This section will give you an overview of how the package works.

### [Contributing](./docs/docs/contributing.md)

Help us improve the package.

### Appendix

References, troubleshooting, and more.

- [FAQ](./docs/docs/appendix/faq.md)
