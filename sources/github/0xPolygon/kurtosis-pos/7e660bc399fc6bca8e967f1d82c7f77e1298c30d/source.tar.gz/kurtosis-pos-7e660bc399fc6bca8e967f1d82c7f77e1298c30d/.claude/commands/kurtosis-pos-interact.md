---
name: kurtosis-pos-interact
description: Interact with a running Polygon PoS devnet. Covers enclave inspection, service logs and shells, port access, cast chain interaction, monitoring health checks, observability stack, and EIP-2935 verification.
allowed-tools: Bash, Read, Glob, Grep
compatibility: Requires a running kurtosis-pos enclave.
---

## Related skills

- **kurtosis-pos-deploy** — deploy an enclave first
- **kurtosis-pos-test** — bridge flows, chaos, and e2e tests

---

## Enclave inspection

```bash
# List all running services, their status, and exposed ports
kurtosis enclave inspect pos

# Print the URL for a specific port
kurtosis port print pos el-1-geth-lighthouse rpc                # L1 EL
kurtosis port print pos cl-1-lighthouse-geth http               # L1 CL
kurtosis port print pos l2-el-0-bor-heimdall-v2-validator rpc   # L2 EL
kurtosis port print pos l2-cl-0-heimdall-v2-bor-validator http  # L2 CL API
kurtosis port print pos l2-cl-0-heimdall-v2-bor-validator rpc   # L2 CL RPC

# List all file artifacts in the enclave
kurtosis files ls pos

# Inspect a file inside an artifact directly (no download needed)
kurtosis files inspect pos l2-el-genesis genesis.json | jq
kurtosis files inspect pos l2-cl-genesis genesis.json | jq
kurtosis files inspect pos pos-contract-addresses contractAddresses.json | jq

# Download a full artifact to disk
kurtosis files download pos <artifact-name> ./output/
```

---

## Service logs and shells

```bash
# Stream live logs from a service
kurtosis service logs pos l2-el-0-bor-heimdall-v2-validator --follow

# Get a shell inside a running container
kurtosis service shell pos l2-el-0-bor-heimdall-v2-validator

# Dump all logs and artifacts to disk
kurtosis enclave dump pos ./enclave-dump
```

---

## Chain interaction with cast

```bash
# Get the RPC URL for the L2 EL
RPC_URL=$(kurtosis port print pos l2-el-0-bor-heimdall-v2-validator rpc)

# Read the current block number
cast block-number --rpc-url $RPC_URL

# Get the latest block
cast block latest --rpc-url $RPC_URL

# Check an account balance
cast balance 0x74Ed6F462Ef4638dc10FFb05af285e8976Fb8DC9 --rpc-url $RPC_URL

# Send a transaction
PRIVATE_KEY=0xd40311b5a5ca5eaeb48dfba5403bde4993ece8eccf4190e98e19fcd4754260ea
cast send \
  --private-key $PRIVATE_KEY \
  --rpc-url $RPC_URL \
  <to_address> \
  --value 1ether
```

---

## Load testing with polycli

```bash
PK="0xd40311b5a5ca5eaeb48dfba5403bde4993ece8eccf4190e98e19fcd4754260ea"
RPC_URL=$(kurtosis port print pos l2-el-0-bor-heimdall-v2-validator rpc)

# Transfer load (mode t)
polycli loadtest --rpc-url "$RPC_URL" --private-key "$PK" --verbosity 700 --requests 5000 --rate-limit 10 --mode t

# ERC-20 load (mode 2)
polycli loadtest --rpc-url "$RPC_URL" --private-key "$PK" --verbosity 700 --requests 500  --rate-limit 10 --mode 2

# Uniswap v3 load (mode v3)
polycli loadtest --rpc-url "$RPC_URL" --private-key "$PK" --verbosity 700 --requests 500  --rate-limit 10 --mode v3
```

---

## Health monitors

Run these after deploy to confirm the devnet is healthy. Each subcommand polls until the condition is met or times out. Build the binary once with `cd tools/devnet-monitor && go build -o devnet-monitor .` (or run via `go run ./tools/devnet-monitor`).

```bash
# Poll all Bor EL RPCs until +40 blocks past startup baseline (sends txs to stimulate progress)
tools/devnet-monitor/devnet-monitor bor --enclave pos
tools/devnet-monitor/devnet-monitor bor --enclave my-enclave --min-blocks 80 --timeout 10m

# Poll Heimdall for CL block progress
tools/devnet-monitor/devnet-monitor heimdall --enclave pos

# Poll until ≥1 span produced
tools/devnet-monitor/devnet-monitor spans --enclave pos

# Poll until ≥1 milestone produced
tools/devnet-monitor/devnet-monitor milestones --enclave pos

# Poll until ≥1 checkpoint committed to L1
tools/devnet-monitor/devnet-monitor checkpoints --enclave pos

# Run every probe in parallel
tools/devnet-monitor/devnet-monitor all --enclave pos
```

---

## Observability stack

Enable via `additional_services: [observability]` in your config.

| Service           | URL (after `kurtosis port print`) | Purpose                    |
| ----------------- | --------------------------------- | -------------------------- |
| `prometheus`      | port `http`                       | Metrics scraping           |
| `grafana`         | port `http`                       | Dashboards                 |
| `panoptichain`    | port `http`                       | Multi-chain block/tx stats |
| `ethstats-server` | port `http`                       | Live node dashboard        |
| `status-checker`  | port `http`                       | Network health monitor     |

```bash
# Get Grafana URL
kurtosis port print pos grafana http

# Get Panoptichain URL
kurtosis port print pos panoptichain http
```

---

## EIP-2935 verification

Verifies that historical block hashes are stored in the `0x0000F9...2935` contract (activated at the Rio hard fork).

```bash
# Verify against the L2 RPC — checks the last n blocks (default: 10)
RPC_URL=$(kurtosis port print pos l2-el-0-bor-heimdall-v2-validator rpc)
./scripts/verify_eip2935.sh $RPC_URL 20
```

---

## Reading contract addresses from artifacts

Contract addresses are stored in two artifacts produced during deployment. Download them and query with `jq`.

Polygon PoS uses a two-layer contract architecture:

- **Root contracts** — deployed on L1. Handle staking, checkpointing, and the deposit/withdrawal bridge (e.g. `RootChain`, `StakeManager`, `StateSender`).
- **Child contracts** — deployed on L2. The counterpart contracts that receive state syncs and manage the child chain (e.g. `ChildChain`, child tokens).
- **L2 genesis contracts** — baked into the L2 genesis block, not deployed via transaction (e.g. `StateReceiver`, `ValidatorSet`). Their addresses come from `genesis.json`, not `contractAddresses.json`.

Both root and child contract addresses live in the same `contractAddresses.json` artifact under `.root.*` and `.child.*` respectively.

**L1 root + child contracts** (`contractAddresses.json`):

```bash
kurtosis files download pos pos-contract-addresses ./output/

# Examples
jq '.root.StateSender'             ./output/contractAddresses.json  # l1_state_sender
jq '.root.RootChainProxy'          ./output/contractAddresses.json  # l1_root_chain_proxy
jq '.root.StakeManagerProxy'       ./output/contractAddresses.json  # l1_stake_manager_proxy
jq '.root.tokens.MaticToken'       ./output/contractAddresses.json  # l1_matic_token
jq '.child.ChildChain'             ./output/contractAddresses.json  # l2_child_chain
```

**L2 genesis contracts** (`genesis.json`):

```bash
kurtosis files download pos l2-el-genesis ./output/

jq '.config.bor.stateReceiverContract' ./output/genesis.json  # l2_state_receiver
jq '.config.bor.validatorContract'     ./output/genesis.json  # l2_validator_contract
jq '.config.bor.burntContract["0"]'    ./output/genesis.json  # l2_burnt_contract
```

Full jq paths for all contracts: `src/contracts/util.star` (`ROOT_CONTRACTS_MAPPING`, `CHILD_CONTRACTS_MAPPING`, `L2_GENESIS_CONTRACTS_MAPPING`).

---

## Heimdall REST API (CL)

```bash
# REST API (port: http / 1317)
CL_URL=$(kurtosis port print pos l2-cl-0-heimdall-v2-bor-validator http)

# Spans
curl -s $CL_URL/bor/spans/latest | jq .          # latest span
curl -s $CL_URL/bor/latest-span | jq .            # same, alternate endpoint

# Milestones
curl -s $CL_URL/milestone/latest | jq .           # latest milestone
curl -s $CL_URL/milestones/count | jq .           # total milestone count

# Checkpoints
curl -s $CL_URL/checkpoints/count | jq .          # total checkpoint count (.ack_count)
curl -s $CL_URL/checkpoints/list | jq .           # list of all checkpoints

# State syncs (clerk)
curl -s $CL_URL/clerk/event-record/list | jq .    # state sync event records

# Tendermint RPC (port: rpc / 26657)
CL_RPC_URL=$(kurtosis port print pos l2-cl-0-heimdall-v2-bor-validator rpc)

curl -s $CL_RPC_URL/status | jq .result.sync_info.latest_block_height  # latest CL block
```
