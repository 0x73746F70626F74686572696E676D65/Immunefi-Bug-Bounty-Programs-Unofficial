# @polygonlabs/openapi-registry

## 3.0.0

### Major Changes

- [#81](https://github.com/0xPolygon/apps-team-packages/pull/81) [`9edc162`](https://github.com/0xPolygon/apps-team-packages/commit/9edc1626f4d053e6d7b1e14dae2d691e768b16a0) Thanks [@MaximusHaximus](https://github.com/MaximusHaximus)! - `registerPath` now rejects coercing schemas (`z.coerce.*`) in parameter positions

  ## Breaking change

  `TypedRegistry.registerPath` throws at generate time when `request.params`, `request.query`, or `request.headers` contains a coercing schema (`z.coerce.number()`, `z.coerce.date()`, …), including when wrapped in `.optional()` / `.default()` / `.nullable()`.

  Why: in zod v4 a coercing schema's input type is `unknown`, so the generated OpenAPI marks the parameter `required: false, nullable: true` regardless of the author's intent — a required parameter silently documents as optional-and-nullable, and every codegen consumer inherits the misdocumented contract. The audit turns that silent corruption into a loud error on the engineer's machine, in the same spirit as the sealed shared-registry conflict check.

  ## Migration
  - Parameter converted by the server binding: declare the logical type plainly — `z.coerce.number().int()` → `z.number().int()`.
  - Wire string with a different runtime type: use a codec that declares both sides — e.g. `Int64Codec` / `IsoDateCodec` from `@polygonlabs/zod-codecs`. Codecs (`z.codec(...)`) are unaffected by the audit.
  - Request bodies are not audited — JSON bodies carry typed values on the wire.

  The check is also exported directly as `assertNoCoercingParamSchemas` for use outside `TypedRegistry`.

### Minor Changes

- [#81](https://github.com/0xPolygon/apps-team-packages/pull/81) [`0fcf6b3`](https://github.com/0xPolygon/apps-team-packages/commit/0fcf6b3d820a83a6bd7aa3781e3ac99d1de0c0b4) Thanks [@MaximusHaximus](https://github.com/MaximusHaximus)! - Make the auto-injected standard error responses configurable per registry

  `new TypedRegistry({ standardErrorResponses })` now controls the framework-emitted error responses injected into every `registerPath` call:

  - `false` — inject nothing; every route documents exactly the responses it declares.
  - `{ serverError?, validationError?, notAuthenticated? }` — override the schema for individual slots; omitted slots keep their defaults.
  - Omitted — unchanged default behaviour.

  The default shapes document `@polygonlabs/express`'s error middleware, which is correct for services using it but wrong for any other producer: a spec authored with this registry for a non-Express backend would otherwise advertise 500/400/401 shapes its server never emits, and the injected `ErrorResponse` component name can collide with the service's own same-named schema of a different shape. The injection _rules_ (when a 400/401/500 is added) are unchanged — only the shapes are configurable.

  The option is mirrored at the type level: the `Ops` accumulator reports the configured schema types (or omits the slots entirely under `false`), so `OperationsOf` consumers and codegen'd clients see the shapes the runtime registry actually holds. `inferStandardErrorResponses` accepts the same options as an optional second argument; existing single-argument calls are unaffected.

## 2.1.3

### Patch Changes

- [#73](https://github.com/0xPolygon/apps-team-packages/pull/73) [`006cf08`](https://github.com/0xPolygon/apps-team-packages/commit/006cf081e794bb156cee0f37fabc450c5b03e7c5) Thanks [@MaximusHaximus](https://github.com/MaximusHaximus)! - Ship the LICENSE file inside the published npm package

  The previous release added the Apache-2.0 license at the repo root and
  declared it in package.json, but npm only auto-includes a LICENSE file
  in the packed tarball when it lives in the same directory as the
  package's own package.json. The license metadata was correct but the
  actual license text was missing from the published package — this adds
  it.

## 2.1.2

### Patch Changes

- [#71](https://github.com/0xPolygon/apps-team-packages/pull/71) [`aa81b1a`](https://github.com/0xPolygon/apps-team-packages/commit/aa81b1a73e0b4711d195c12e12120f5f67191305) Thanks [@MaximusHaximus](https://github.com/MaximusHaximus)! - Add Apache-2.0 license: the package now declares `"license": "Apache-2.0"` in its `package.json`, and the repository carries the full Apache License 2.0 text. Previously no license was declared.

## 2.1.1

### Patch Changes

- b716507: Re-export `inferStandardErrorResponses`, `InferredStandardErrorResponses`,
  and `MergedRoute` from the package's main entry. The auto-inject
  behaviour added in 2.1.0 made `TypedRegistry.registerPath` return a type
  referencing `MergedRoute` — but the type wasn't exported through the
  public surface, so `tsc --declaration` in consumer packages emitted
  `TS2742: The inferred type of 'buildRegistry' cannot be named without a
reference to './node_modules/@polygonlabs/openapi-registry/dist/inferErrorResponses.js'`.

  Consumers using the auto-inject feature could not build their packages
  against the published 2.1.0 without manually annotating chain helpers
  to break the inferred reference. This patch makes the inference types
  properly reachable through the package's public exports.

## 2.1.0

### Minor Changes

- 53a9c3c: `TypedRegistry.registerPath` now auto-injects the standard framework-emitted
  error responses based on what each route declares, so route authors don't
  have to remember to add them by hand.

  Inference rules:
  - **400** with `ValidationErrorResponseSchema` is added when the route
    declares any of `request.params`, `request.query`, `request.body`, or
    `request.headers`. This is the shape `@polygonlabs/express`'s request
    validator actually emits (`{ error, message, info: ValidationErrorInfo }`
    with the section-keyed `z.treeifyError` tree).
  - **401** with `ErrorResponseSchema` is added when the route declares
    `security` with at least one requirement.
  - **500** with `ErrorResponseSchema` is added unconditionally.

  `403` and `404` are **not** auto-injected. Both are handler-emitted (the
  framework doesn't throw `Forbidden` or `NotFound` itself), so the registry
  has no honest signal that a route can produce them. Declare those response
  slots explicitly when a handler can throw them.

  User-authored responses always win over inferred ones: a route that wants
  a domain-shaped 400 — or that genuinely can't 500 — can still override by
  declaring the slot itself. The merge is `{ ...inferred, ...route.responses }`,
  so user keys replace inferred keys both at runtime and in the accumulated
  `Ops` type that `OperationsOf<typeof buildRegistry>` exposes to consumers.

  The codegen client picks the merged shapes up automatically — there's
  nothing new to wire on the client side. Services using
  `@polygonlabs/express`'s `createRegistryRouter` get the right OpenAPI
  spec for free, and their hey-api–generated clients now have the correct
  error types for every route the framework can fail.

## 2.0.0

### Major Changes

- 1b5d48f: Replace the asserts-based API with chainable returns; add `OperationsOf<F>` and `SchemesOf<F>` helpers.

  ## Breaking changes

  `registerPath` and `registerSecurityScheme` now return a narrower `TypedRegistry` instead of asserting `this is X`. Chain registrations to keep the type-level narrow:

  ```ts
  // before
  const registry: TypedRegistry = new TypedRegistry();
  registry.registerPath({ operationId: 'a' /* … */ });

  // after
  const registry = new TypedRegistry().registerPath({ operationId: 'a' /* … */ });
  ```

  `.extend(fn)` is renamed to `.with(fn)` and returns `this & R` (the helper's chain result intersected with the receiver). Per-domain helpers chain through:

  ```ts
  // before
  function addRoutes<Prev>(r: TypedRegistry<Prev>) {
    r.registerPath(/* … */);
    return r;
  }
  registry.extend(addRoutes);

  // after
  const addRoutes = <Ops, Schemes>(r: TypedRegistry<Ops, Schemes>) => r.registerPath(/* … */);
  registry.with(addRoutes);
  ```

  The asserts-based footguns are gone: no `: TypedRegistry` annotation requirement (TS2775), no function-wrapper requirement, no phantom-witness fields. The variable holding the chain's final value picks up the accumulated narrow without any annotation.

  `registerComponent` and `registerWebhook` now return `this` (chainable). `register` and `registerParameter` keep their schema-returning shape (matching the asteasolutions API).

  ## New helpers
  - `OperationsOf<F extends () => TypedRegistry<...>>` — extract the operations manifest from a builder function. Brands the empty-manifest case (`Operations` resolves to `{}`) as a type-level error so a downstream consumer sees the bug at the `satisfies` / `HandlerMap` use site instead of silently iterating an empty object.
  - `SchemesOf<F>` — extract the security scheme presence-map from a builder function.

  ## New silent-failure mode

  The chainable API has one new failure mode: `r.registerPath({ … });` that drops the return still mutates the underlying registry at runtime, but the type-level narrow is lost. Two complementary defences:
  - **`OperationsOf<F>`** brands the worst case (every link discarded → manifest `{}`) as a type-level error string, so downstream consumers see the bug at the `satisfies HandlerMapFor<F>` use site.
  - **`@polygonlabs/apps-team-lint`'s `polygon/no-discarded-typed-registry-chain`** rule (shipped in the same release wave) catches partial discards at lint time — type-aware, only fires on real `TypedRegistry` receivers. Enabled at `error` in the `typescript()` preset, so consuming repos pick it up automatically when they update.

  See README "The one rule".

  ## Build hygiene

  Both `@polygonlabs/openapi-registry` and `@polygonlabs/express` builds now clean `dist/` + `*.tsbuildinfo` before `tsc` runs and verify each `exports` entry point loads at the end. Catches the "incremental tsc skipped a file" failure mode that broke the initial `@polygonlabs/express` npm publish.

  See [`MIGRATION.md`](./MIGRATION.md) for migration patterns.

## 1.1.0

### Minor Changes

- cc31c39: Add `@polygonlabs/openapi-registry/error-schemas` subpath exporting the
  canonical Zod schemas for the standard error response shapes
  (`ErrorResponseSchema`, `ValidationErrorResponseSchema`,
  `ValidationErrorInfoSchema`, `ZodErrorTreeSchema`).

  These previously lived only inside `@polygonlabs/express/registry`, which
  forced schemas-only consumers to take a transitive dep on Express + pino +
  Sentry just to register the canonical 400 / 401 / 5xx response shapes in
  their OpenAPI spec. The schemas have zero Express-runtime imports — only
  `zod` and `@asteasolutions/zod-to-openapi` — so they belong with the
  registry primitives.

  Express 1.1.x's `@polygonlabs/express/registry` continues to re-export
  them unchanged for back-compat, so existing import paths keep working.
  New schemas-only packages should import from
  `@polygonlabs/openapi-registry/error-schemas` directly.

## 1.0.1

### Patch Changes

- 978435a: Initial release of `@polygonlabs/openapi-registry`.

  `TypedRegistry` is a type-accumulating drop-in for `OpenAPIRegistry` from `@asteasolutions/zod-to-openapi`. Two type-level effects ride alongside the runtime calls:
  - Every `registerPath` call narrows the receiver's `Ops` accumulator via `asserts this is X`, so the registry's type carries every registered `operationId` by the time it's returned. Downstream consumers (Express request/response validation, codegen audits, gateway aggregation) read the accumulated `Ops` directly via inferred return types.
  - Every `registerSecurityScheme(name, scheme)` call narrows the receiver's `Schemes` accumulator the same way, so consumers (typed Express auth wiring) can require a handler for every registered scheme at compile time.

  The runtime behaviour is byte-compatible with `OpenAPIRegistry` — `register`, `registerParameter`, `registerComponent`, `registerWebhook`, and the `definitions` getter all forward to the inner registry. `registerSecurityScheme` is a thin wrapper over `inner.registerComponent('securitySchemes', name, scheme)` that exists purely so the type-level narrow on `Schemes` is captured cleanly. Code that treats the registry as a plain `OpenAPIRegistry` sees no behavioural difference.

  The package also ships:
  - `.extend(fn)` — statement-form composition for per-domain helpers without chaining or per-helper boilerplate.
  - `SecuritySchemeObject` — structural shape covering OpenAPI 3.x security schemes (`apiKey`, `http`, `oauth2`, `openIdConnect`).

  See the README for the four asserts-narrowing preconditions (TS2775 explicit annotation, `<const O>` / `<const N>` literal preservation, function wrapper for cross-module narrow, and the phantom witnesses that anchor variance).
