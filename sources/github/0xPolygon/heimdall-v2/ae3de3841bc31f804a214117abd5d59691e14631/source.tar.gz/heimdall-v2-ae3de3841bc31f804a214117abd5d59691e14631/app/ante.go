package app

import (
	"errors"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/x/auth/ante"

	"github.com/0xPolygon/heimdall-v2/helper"
	"github.com/0xPolygon/heimdall-v2/sidetxs"
	checkpointante "github.com/0xPolygon/heimdall-v2/x/checkpoint/ante"
)

// HandlerOptions are the options required for constructing a default SDK AnteHandler.
type HandlerOptions struct {
	ante.HandlerOptions
	SideTxConfig sidetxs.SideTxConfigurator
}

// maxMultiSendOutputs bounds aggregate bank-transfer outputs per tx so flat-ante txs can't fan out unboundedly.
const maxMultiSendOutputs = 16

// maxFeeCoins bounds the number of coins a declared fee may contain. Heimdall
// substitutes a single fixed-denom coin for the fee actually charged, so a
// conforming tx never needs more than one.
const maxFeeCoins = 1

// NewAnteHandler returns an AnteHandler that checks and increments sequence
// numbers, checks signatures & account numbers, and deducts fees from the first
// signer.
func NewAnteHandler(options HandlerOptions) (sdk.AnteHandler, error) {
	if options.AccountKeeper == nil {
		return nil, errors.New("account keeper is required for ante builder")
	}

	if options.BankKeeper == nil {
		return nil, errors.New("bank keeper is required for ante builder")
	}

	if options.SignModeHandler == nil {
		return nil, errors.New("sign mode handler is required for ante builder")
	}

	anteDecorators := []sdk.AnteDecorator{
		ante.NewSetUpContextDecorator(), // outermost AnteDecorator. SetUpContext must be called first
		ante.NewExtensionOptionsDecorator(options.ExtensionOptionChecker),
		// Bound the fee-coin count before ValidateBasicDecorator's own O(n) scan over the same slice.
		ante.NewFeeCoinsCapDecorator(maxFeeCoins, helper.IsKyoto),
		ante.NewValidateBasicDecorator(),
		ante.NewMsgMultiSendCapDecorator(maxMultiSendOutputs, helper.IsZurichHardfork),
		checkpointante.NewAccountRootHashLenDecorator(helper.IsZurichHardfork),
		ante.NewTxTimeoutHeightDecorator(),
		ante.NewValidateMemoDecorator(options.AccountKeeper),
		ante.NewConsumeGasForTxSizeDecorator(options.AccountKeeper),
		ante.NewDeductFeeDecorator(options.AccountKeeper, options.BankKeeper, options.FeegrantKeeper, options.TxFeeChecker),
		ante.NewSetPubKeyDecorator(options.AccountKeeper, options.SignModeHandler), // SetPubKeyDecorator must be called before all signature verification decorators
		ante.NewValidateSigCountDecorator(options.AccountKeeper),
		ante.NewSigGasConsumeDecorator(options.AccountKeeper, options.SigGasConsumer),
		ante.NewSigVerificationDecorator(options.AccountKeeper, options.SignModeHandler),
		ante.NewIncrementSequenceDecorator(options.AccountKeeper),
		sidetxs.NewSideTxDecorator(options.SideTxConfig),
	}

	return sdk.ChainAnteDecorators(anteDecorators...), nil
}
