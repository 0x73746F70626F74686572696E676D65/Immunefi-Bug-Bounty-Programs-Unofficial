package app

import (
	"encoding/json"
	"testing"

	sdkmath "cosmossdk.io/math"
	abci "github.com/cometbft/cometbft/abci/types"
	cmtproto "github.com/cometbft/cometbft/proto/tendermint/types"
	"github.com/cosmos/cosmos-sdk/codec/address"
	"github.com/cosmos/cosmos-sdk/testutil/mock"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/cosmos/cosmos-sdk/types/module"
	"github.com/cosmos/cosmos-sdk/x/auth"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/cosmos/cosmos-sdk/x/bank"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/cosmos/cosmos-sdk/x/gov"
	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/require"

	"github.com/0xPolygon/heimdall-v2/helper"
	hmTypes "github.com/0xPolygon/heimdall-v2/types"
	"github.com/0xPolygon/heimdall-v2/x/bor"
	"github.com/0xPolygon/heimdall-v2/x/chainmanager"
	"github.com/0xPolygon/heimdall-v2/x/checkpoint"
	"github.com/0xPolygon/heimdall-v2/x/clerk"
	"github.com/0xPolygon/heimdall-v2/x/milestone"
	"github.com/0xPolygon/heimdall-v2/x/stake"
	"github.com/0xPolygon/heimdall-v2/x/topup"
	topupTypes "github.com/0xPolygon/heimdall-v2/x/topup/types"
)

func TestHeimdallAppExport(t *testing.T) {
	setupAppResult := SetupApp(t, 1)
	app := setupAppResult.App

	_, err := app.ExportAppStateAndValidators(false, []string{}, []string{})
	require.NoError(t, err)
}

func TestRunMigrations(t *testing.T) {
	setupAppResult := SetupApp(t, 1)
	hApp := setupAppResult.App
	configurator := module.NewConfigurator(hApp.appCodec, hApp.MsgServiceRouter(), hApp.GRPCQueryRouter())

	testCases := []struct {
		name         string
		moduleName   string
		fromVersion  uint64
		toVersion    uint64
		expRegErr    bool // errors while registering migration
		expRegErrMsg string
		expRunErr    bool // errors while running migration
		expRunErrMsg string
		expCalled    int
	}{
		{
			"cannot register migration for version 0",
			"bank", 0, 1,
			true, "module migration versions should start at 1: invalid version", false, "", 0,
		},
		{
			"throws error on RunMigrations if no migration registered for bank",
			"", 1, 2,
			false, "", true, "no migrations found for module bank: not found", 0,
		},
		{
			"can register 1->2 migration handler for x/bank, cannot run migration",
			"bank", 1, 2,
			false, "", true, "no migration found for module bank from version 2 to version 3: not found", 0,
		},
		{
			"can register 2->3 migration handler for x/bank, can run migration",
			"bank", 2, bank.AppModule{}.ConsensusVersion(),
			false, "", false, "", int(bank.AppModule{}.ConsensusVersion() - 2), // minus 2 because 1-2 is run in the previous test case.
		},
		{
			"cannot register migration handler for same module & fromVersion",
			"bank", 1, 2,
			true, "another migration for module bank and version 1 already exists: internal logic error", false, "", 0,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(tt *testing.T) {
			var err error

			// Since it's very hard to test actual in-place store migrations in
			// tests (due to the difficulty of maintaining multiple versions of a
			// module), we're just testing here that the migration logic is
			// called.
			called := 0

			if tc.moduleName != "" {
				for i := tc.fromVersion; i < tc.toVersion; i++ {
					// Register migration for module from version `fromVersion` to `fromVersion+1`.
					tt.Logf("Registering migration for %q v%d", tc.moduleName, i)
					err = configurator.RegisterMigration(tc.moduleName, i, func(sdk.Context) error {
						called++

						return nil
					})

					if tc.expRegErr {
						require.EqualError(tt, err, tc.expRegErrMsg)

						return
					}
					require.NoError(tt, err, "registering migration")
				}
			}

			// Run migrations only for bank module. That's why we put the initial
			// version for bank module as 1, and for all other modules, we put as
			// their latest ConsensusVersion.
			_, err = hApp.ModuleManager.RunMigrations(
				hApp.NewContextLegacy(true, cmtproto.Header{Height: hApp.LastBlockHeight()}), configurator,
				module.VersionMap{
					"bank":         1,
					"auth":         auth.AppModule{}.ConsensusVersion(),
					"gov":          gov.AppModule{}.ConsensusVersion(),
					"stake":        stake.AppModule{}.ConsensusVersion(),
					"clerk":        clerk.AppModule{}.ConsensusVersion(),
					"checkpoint":   checkpoint.AppModule{}.ConsensusVersion(),
					"chainmanager": chainmanager.AppModule{}.ConsensusVersion(),
					"milestone":    milestone.AppModule{}.ConsensusVersion(),
					"topup":        topup.AppModule{}.ConsensusVersion(),
					"bor":          bor.AppModule{}.ConsensusVersion(),
				},
			)

			if tc.expRunErr {
				require.EqualError(tt, err, tc.expRunErrMsg, "running migration")
			} else {
				require.NoError(tt, err, "running migration")
				// Make sure bank's migration is called.
				require.Equal(tt, tc.expCalled, called)
			}
		})
	}
}

func TestInitGenesisOnMigration(t *testing.T) {
	setupAppResult := SetupApp(t, 1)
	app := setupAppResult.App
	ctx := app.NewContextLegacy(true, cmtproto.Header{Height: app.LastBlockHeight()})

	// Create a mock module. This module will serve as the new module we're
	// adding during a migration.
	mockCtrl := gomock.NewController(t)
	t.Cleanup(mockCtrl.Finish)
	mockModule := mock.NewMockAppModuleWithAllExtensions(mockCtrl)
	mockDefaultGenesis := json.RawMessage(`{"key": "value"}`)
	mockModule.EXPECT().DefaultGenesis(gomock.Eq(app.appCodec)).Times(1).Return(mockDefaultGenesis)
	mockModule.EXPECT().InitGenesis(gomock.Eq(ctx), gomock.Eq(app.appCodec), gomock.Eq(mockDefaultGenesis)).Times(1)
	mockModule.EXPECT().ConsensusVersion().Times(1).Return(uint64(0))

	app.ModuleManager.Modules["mock"] = mockModule

	// Run migrations only for "mock" module. We exclude it from
	// the VersionMap to simulate upgrading with a new module.
	_, err := app.ModuleManager.RunMigrations(ctx, app.configurator,
		module.VersionMap{
			"bank":         bank.AppModule{}.ConsensusVersion(),
			"auth":         auth.AppModule{}.ConsensusVersion(),
			"gov":          gov.AppModule{}.ConsensusVersion(),
			"stake":        stake.AppModule{}.ConsensusVersion(),
			"clerk":        clerk.AppModule{}.ConsensusVersion(),
			"checkpoint":   checkpoint.AppModule{}.ConsensusVersion(),
			"chainmanager": chainmanager.AppModule{}.ConsensusVersion(),
			"milestone":    milestone.AppModule{}.ConsensusVersion(),
			"topup":        topup.AppModule{}.ConsensusVersion(),
			"bor":          bor.AppModule{}.ConsensusVersion(),
		},
	)
	require.NoError(t, err)
}

func TestValidateGenesis(t *testing.T) {
	t.Parallel()

	setupAppResult := SetupApp(t, 1)
	hApp := setupAppResult.App

	// not valid app state
	require.Panics(t, func() {
		_, err := hApp.InitChain(
			&abci.RequestInitChain{
				Validators:    []abci.ValidatorUpdate{},
				AppStateBytes: []byte("{}"),
			},
		)
		require.Error(t, err)
	})
}

func TestGetMaccPerms(t *testing.T) {
	t.Parallel()

	dup := GetMaccPerms()
	require.Equal(t, maccPerms, dup, "duplicated module account permissions differed from actual module account permissions")
}

func TestEndBlockerEmitsTransferEvent(t *testing.T) {
	setupAppResult := SetupApp(t, 1)
	app := setupAppResult.App
	ctx := app.NewContextLegacy(true, cmtproto.Header{Height: app.LastBlockHeight()})

	testAddr := "0x1234567890abcdef1234567890abcdef12345678"
	ac := address.NewHexCodec()
	proposer, err := ac.StringToBytes(testAddr)
	require.NoError(t, err)

	// Create a test proposer account
	proposerAcc := app.AccountKeeper.NewAccountWithAddress(ctx, proposer)
	app.AccountKeeper.SetAccount(ctx, proposerAcc)

	// Set the block proposer
	err = app.AccountKeeper.SetBlockProposer(ctx, proposerAcc.GetAddress())
	require.NoError(t, err)

	// Fund the fee collector
	feeAmount := sdkmath.NewInt(1000)
	feeCoins := sdk.NewCoins(sdk.NewCoin(authtypes.FeeToken, feeAmount))

	// Use the topup module which has minting permissions
	err = app.BankKeeper.MintCoins(ctx, topupTypes.ModuleName, feeCoins)
	require.NoError(t, err)

	// Transfer from topup to fee collector
	err = app.BankKeeper.SendCoinsFromModuleToModule(ctx, topupTypes.ModuleName, authtypes.FeeCollectorName, feeCoins)
	require.NoError(t, err)

	// Run EndBlocker
	result, err := app.EndBlocker(ctx)
	require.NoError(t, err)

	// Verify the fee transfer event was emitted in the EndBlocker result
	var feeTransferEvent *abci.Event
	for _, event := range result.Events {
		if event.Type == hmTypes.EventTypeFeeTransfer {
			feeTransferEvent = &event
			break
		}
	}
	require.NotNil(t, feeTransferEvent, "fee transfer event should be emitted")

	// Verify event attributes
	require.NotNil(t, feeTransferEvent, "fee transfer event should not be nil")
	require.NotNil(t, feeTransferEvent.Attributes, "fee transfer event should have attributes")
	require.Equal(t, 3, len(feeTransferEvent.Attributes))

	var proposerAttr, denomAttr, amountAttr *abci.EventAttribute
	for _, attr := range feeTransferEvent.Attributes {
		switch attr.Key {
		case hmTypes.AttributeKeyProposer:
			proposerAttr = &attr
		case hmTypes.AttributeKeyDenom:
			denomAttr = &attr
		case hmTypes.AttributeKeyAmount:
			amountAttr = &attr
		}
	}

	require.NotNil(t, proposerAttr)
	require.NotNil(t, proposerAcc.GetAddress(), "proposer address should not be nil")
	require.Equal(t, proposerAcc.GetAddress().String(), proposerAttr.Value)

	require.NotNil(t, denomAttr)
	require.NotNil(t, denomAttr.Value, "denom attribute value should not be nil")
	require.Equal(t, authtypes.FeeToken, denomAttr.Value)

	require.NotNil(t, amountAttr)
	require.NotNil(t, amountAttr.Value, "amount attribute value should not be nil")
	require.Equal(t, feeAmount.String(), amountAttr.Value)
}

// CheckTx rejects txs carrying more than maxMsgsPerTx messages before the
// per-message validation loop, neutralizing the oversized-tx mempool flood.
func TestCheckTx_RejectsTxExceedingMsgCap(t *testing.T) {
	priv, app, ctx, _ := SetupAppWithABCICtxAndValidators(t, 1)

	signer := sdk.AccAddress(priv.PubKey().Address()).String()
	makeMsgs := func(n int) []sdk.Msg {
		msgs := make([]sdk.Msg, n)
		for i := range msgs {
			msgs[i] = &banktypes.MsgSend{
				FromAddress: signer,
				ToAddress:   signer,
				Amount:      sdk.NewCoins(sdk.NewInt64Coin("pol", 1)),
			}
		}
		return msgs
	}

	cases := []struct {
		name       string
		count      int
		wantCapHit bool
	}{
		{name: "single message passes the cap", count: 1, wantCapHit: false},
		{name: "at cap passes", count: maxMsgsPerTx, wantCapHit: false},
		{name: "one over cap is rejected", count: maxMsgsPerTx + 1, wantCapHit: true},
		{name: "far over cap is rejected", count: maxMsgsPerTx * 100, wantCapHit: true},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			txBytes, err := buildSignedMultiMsgTx(makeMsgs(tc.count), ctx, priv, app)
			require.NoError(t, err)

			resp, err := app.CheckTx(&abci.RequestCheckTx{Tx: txBytes, Type: abci.CheckTxType_New})
			require.NoError(t, err)

			if tc.wantCapHit {
				require.Equal(t, sdkerrors.ErrTxTooLarge.ABCICode(), resp.Code)
				require.Contains(t, resp.Log, "exceeds per-tx limit")
			} else {
				require.NotEqual(t, sdkerrors.ErrTxTooLarge.ABCICode(), resp.Code,
					"under-cap tx must not be rejected by the message cap; log=%s", resp.Log)
			}
		})
	}
}

// At/after Kyoto, CheckTx rejects an over-nested transaction with the nesting-bound
// log before the full decode; below Kyoto the guard is inert and the same bytes fall
// through to the ordinary decoder. The distinct log is what proves the guard, not the
// decoder, produced the rejection.
func TestCheckTx_RejectsOverNestedTx(t *testing.T) {
	_, app, _, _ := SetupAppWithABCICtxAndValidators(t, 1)
	orig := helper.GetKyotoHeight()
	t.Cleanup(func() { helper.SetKyotoHeight(orig) })

	bomb := txRawWithBody(nestedAnyBody(maxAnyNestingDepth + 1))
	const nestingLog = "transaction exceeds the message nesting bound"

	t.Run("at/after kyoto the guard rejects", func(t *testing.T) {
		helper.SetKyotoHeight(1)
		resp, err := app.CheckTx(&abci.RequestCheckTx{Tx: bomb, Type: abci.CheckTxType_New})
		require.NoError(t, err)
		require.Equal(t, sdkerrors.ErrTxDecode.ABCICode(), resp.Code)
		require.Equal(t, nestingLog, resp.Log)
	})

	t.Run("below kyoto the guard is inert", func(t *testing.T) {
		helper.SetKyotoHeight(0)
		resp, err := app.CheckTx(&abci.RequestCheckTx{Tx: bomb, Type: abci.CheckTxType_New})
		require.NoError(t, err)
		require.NotEqual(t, nestingLog, resp.Log)
	})
}

// The cap guard only applies to fresh CheckTx, not recheck, matching the
// veBlop guards it sits alongside.
func TestCheckTx_MsgCapSkippedOnRecheck(t *testing.T) {
	priv, app, ctx, _ := SetupAppWithABCICtxAndValidators(t, 1)

	signer := sdk.AccAddress(priv.PubKey().Address()).String()
	msgs := make([]sdk.Msg, maxMsgsPerTx+1)
	for i := range msgs {
		msgs[i] = &banktypes.MsgSend{FromAddress: signer, ToAddress: signer, Amount: sdk.NewCoins(sdk.NewInt64Coin("pol", 1))}
	}
	txBytes, err := buildSignedMultiMsgTx(msgs, ctx, priv, app)
	require.NoError(t, err)

	resp, err := app.CheckTx(&abci.RequestCheckTx{Tx: txBytes, Type: abci.CheckTxType_Recheck})
	require.NoError(t, err)
	require.NotEqual(t, sdkerrors.ErrTxTooLarge.ABCICode(), resp.Code)
}
