package app

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"sort"

	"cosmossdk.io/log"
	abciTypes "github.com/cometbft/cometbft/abci/types"
	cmtCrypto "github.com/cometbft/cometbft/crypto"
	cryptoenc "github.com/cometbft/cometbft/crypto/encoding"
	"github.com/cometbft/cometbft/libs/protoio"
	cmtTypes "github.com/cometbft/cometbft/proto/tendermint/types"
	cometTypes "github.com/cometbft/cometbft/types"
	"github.com/cosmos/cosmos-sdk/codec/address"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/gogoproto/proto"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"

	"github.com/0xPolygon/heimdall-v2/helper"
	"github.com/0xPolygon/heimdall-v2/metrics/consensus"
	"github.com/0xPolygon/heimdall-v2/sidetxs"
	chainManagerKeeper "github.com/0xPolygon/heimdall-v2/x/chainmanager/keeper"
	checkpointKeeper "github.com/0xPolygon/heimdall-v2/x/checkpoint/keeper"
	checkpointTypes "github.com/0xPolygon/heimdall-v2/x/checkpoint/types"
	milestoneAbci "github.com/0xPolygon/heimdall-v2/x/milestone/abci"
	milestoneKeeper "github.com/0xPolygon/heimdall-v2/x/milestone/keeper"
	stakeKeeper "github.com/0xPolygon/heimdall-v2/x/stake/keeper"
	stakeTypes "github.com/0xPolygon/heimdall-v2/x/stake/types"
)

var (
	dummyNonRpVoteExtension   = []byte("\t\r\n#HEIMDALL-VOTE-EXTENSION#\r\n\t")
	minNonRpVoteExtensionSize = len(dummyNonRpVoteExtension)
)

const (
	maxNonRpVoteExtensionSize = 500
	maxSideTxResponsesCount   = 50

	// Params to define the VEs size and the non-rp VEs size
	// They correlate with network's size, because
	// maxVESizePerValidator is calculated as [(MaxTxBytes / validatorsCount / safety_factor) - overhead]

	safetyFactor         = 2
	overheadPerValidator = 500       // bytes for additional data (e.g. signatures, metadata, protobuf...)
	minVESize            = 10        // Minimum size for normal vote extensions (bytes)
	maxVESize            = 10 * 1024 // 10KB maximum
)

// ValidateVoteExtensions verifies the vote extension correctness
// It checks the signature of each vote extension with its signer's public key
// Also, it checks if the vote extensions are enabled, valid, and have >2/3 voting power.
// It returns an error in case the validation fails
func ValidateVoteExtensions(ctx sdk.Context, reqHeight int64, extVoteInfo []abciTypes.ExtendedVoteInfo, round int32, validatorSet *stakeTypes.ValidatorSet, milestoneKeeper milestoneKeeper.Keeper) error {
	// check if VEs are enabled
	if err := checkIfVoteExtensionsDisabled(ctx, reqHeight+1); err != nil {
		return err
	}

	// check if reqHeight is the initial height
	if reqHeight <= retrieveVoteExtensionsEnableHeight(ctx) {
		if len(extVoteInfo) != 0 {
			return fmt.Errorf("non-empty VEs received at initial height %d", reqHeight)
		}
		return nil
	}

	totalVotingPower := validatorSet.GetTotalVotingPower()
	sumVP := int64(0)

	// Map to track seen validator addresses
	seenValidators := make(map[string]struct{})
	var blockHash []byte

	ac := address.HexCodec{}

	for _, vote := range extVoteInfo {
		// Skip filtered placeholders (previously stripped by filterVoteExtensions due to size violations).
		// They are kept in the slice for completeness but must not be validated or counted toward VP.
		if isFilteredPlaceholder(vote) {
			continue
		}

		// reject unknown fields
		if err := rejectUnknownVoteExtFields(vote.VoteExtension); err != nil {
			return fmt.Errorf("unknown fields detected in vote extensions at height %d: %w", reqHeight, err)
		}

		// make sure the BlockIdFlag is valid
		if !isBlockIdFlagValid(vote.BlockIdFlag) {
			return fmt.Errorf("received vote with invalid block ID %s flag at height %d", vote.BlockIdFlag.String(), reqHeight)
		}
		// if not BlockIDFlagCommit, skip that vote, as it doesn't have relevant information
		if vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			continue
		}

		valAddrStr, err := ac.BytesToString(vote.Validator.Address)
		if err != nil {
			return fmt.Errorf("validator address %v is not valid", vote.Validator.Address)
		}

		if len(vote.ExtensionSignature) == 0 {
			return fmt.Errorf("received empty vote extension signature at height %d from validator %s", reqHeight, valAddrStr)
		}

		voteExtension := new(sidetxs.VoteExtension)
		if err = voteExtension.Unmarshal(vote.VoteExtension); err != nil {
			return fmt.Errorf("error while unmarshalling vote extension: %w", err)
		}

		if voteExtension.Height != reqHeight-1 {
			return fmt.Errorf("invalid height received for vote extension, expected %d, got %d", reqHeight-1, voteExtension.Height)
		}

		// blockHash consistency check
		if blockHash == nil {
			// store the block hash from the first vote
			blockHash = voteExtension.BlockHash
		} else {
			// compare the current block hash with the stored block hash
			if !bytes.Equal(blockHash, voteExtension.BlockHash) {
				return fmt.Errorf("invalid block hash found for vote extension, expected %s, received %s, validator %s",
					common.Bytes2Hex(blockHash), common.Bytes2Hex(voteExtension.BlockHash), valAddrStr)
			}
		}

		txHash, err := validateSideTxResponses(voteExtension.SideTxResponses)
		if err != nil {
			return fmt.Errorf("invalid sideTxResponses detected for validator %s and tx %s, error: %w", valAddrStr, common.Bytes2Hex(txHash), err)
		}

		// Gate fork-specific proposition fields at the vote extension's own height. During proposal
		// processing ctx is one block ahead of the extension being validated.
		milestoneCtx := ctx.WithBlockHeight(voteExtension.Height)
		if err := milestoneAbci.ValidateMilestoneProposition(milestoneCtx, &milestoneKeeper, voteExtension.MilestoneProposition); err != nil {
			return fmt.Errorf("invalid milestone proposition detected for validator %s, error: %w", valAddrStr, err)
		}

		// Check for duplicate votes by the same validator
		if _, found := seenValidators[valAddrStr]; found {
			return fmt.Errorf("duplicate vote detected from validator %s at height %d", valAddrStr, reqHeight)
		}
		// Add the validator address to the map
		seenValidators[valAddrStr] = struct{}{}

		_, validator := validatorSet.GetByAddress(valAddrStr)
		if validator == nil {
			if milestoneAbci.ShouldErrorOnValidatorNotFound(ctx.BlockHeight()) {
				return errors.New(helper.ErrFailedToGetValidator(valAddrStr))
			}
			continue
		}

		// ensure proposer-supplied power matches canonical power
		// This is not used for tallying, but a mismatch indicates potential tampering.
		if vote.Validator.Power != validator.VotingPower {
			return fmt.Errorf(
				"mismatching voting power in ValidateVoteExtension for validator %s: got %d from ExtendedCommitInfo, expected %d",
				valAddrStr,
				vote.Validator.Power,
				validator.VotingPower,
			)
		}

		cmtPubKey, err := getValidatorPublicKey(validator)
		if err != nil {
			return err
		}

		cve := cmtTypes.CanonicalVoteExtension{
			Extension: vote.VoteExtension,
			Height:    reqHeight - 1, // the vote extension was signed in the previous height
			Round:     int64(round),
			ChainId:   ctx.ChainID(),
		}

		marshalDelimitedFn := func(msg proto.Message) ([]byte, error) {
			var buf bytes.Buffer
			if _, err := protoio.NewDelimitedWriter(&buf).WriteMsg(msg); err != nil {
				return nil, err
			}

			return buf.Bytes(), nil
		}

		extSignBytes, err := marshalDelimitedFn(&cve)
		if err != nil {
			return fmt.Errorf("failed to encode CanonicalVoteExtension: %w", err)
		}

		if !cmtPubKey.VerifySignature(extSignBytes, vote.ExtensionSignature) {
			return fmt.Errorf("failed to verify validator %X vote extension signature", valAddrStr)
		}

		sumVP += validator.VotingPower
	}

	// Ensure we have at least 2/3 voting power for the submitted vote extensions in each side tx
	majorityVP := totalVotingPower * 2 / 3
	if sumVP <= majorityVP {
		return fmt.Errorf("insufficient cumulative voting power received to verify vote extensions; got: %d, expected: >=%d", sumVP, majorityVP)
	}

	return nil
}

// ValidateVoteExtensionsCompleteness checks that every validator who committed the previous block
// has a corresponding entry in the proposer's ExtendedCommitInfo with a matching BlockIDFlagCommit.
// This prevents a proposer from omitting or downgrading validators' vote extensions.
func ValidateVoteExtensionsCompleteness(canonicalVotes []abciTypes.VoteInfo, extCommitVotes []abciTypes.ExtendedVoteInfo) error {
	// Build a map of validator address -> BlockIdFlag from the ExtendedCommitInfo
	extCommitFlags := make(map[string]cmtTypes.BlockIDFlag, len(extCommitVotes))
	for _, vote := range extCommitVotes {
		extCommitFlags[string(vote.Validator.Address)] = vote.BlockIdFlag
	}

	// Check that every canonical commit validator with BlockIDFlagCommit is present
	// in the ExtendedCommitInfo and also has BlockIDFlagCommit there.
	for _, vote := range canonicalVotes {
		if vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			continue
		}
		flag, found := extCommitFlags[string(vote.Validator.Address)]
		if !found {
			return fmt.Errorf(
				"validator %X committed the previous block but is missing from ExtendedCommitInfo",
				vote.Validator.Address,
			)
		}
		if flag != cmtTypes.BlockIDFlagCommit {
			return fmt.Errorf(
				"validator %X committed the previous block but has flag %s in ExtendedCommitInfo instead of Commit",
				vote.Validator.Address,
				flag.String(),
			)
		}
	}

	return nil
}

// filterVoteExtensions verifies the vote extension correctness and filters out invalid ones
func filterVoteExtensions(ctx sdk.Context, reqHeight int64, extVoteInfo []abciTypes.ExtendedVoteInfo, round int32, validatorSet *stakeTypes.ValidatorSet, milestoneKeeper milestoneKeeper.Keeper, maxTxBytes int64, logger log.Logger) ([]abciTypes.ExtendedVoteInfo, error) {
	validVoteExtensions := make([]abciTypes.ExtendedVoteInfo, 0)
	toFilteredPlaceholder := func(vote abciTypes.ExtendedVoteInfo) abciTypes.ExtendedVoteInfo {
		vote.VoteExtension = nil
		vote.ExtensionSignature = nil
		vote.NonRpVoteExtension = nil
		vote.NonRpExtensionSignature = nil
		return vote
	}

	// check if VEs are enabled
	if err := checkIfVoteExtensionsDisabled(ctx, reqHeight+1); err != nil {
		return nil, err
	}

	// check if reqHeight is the initial height
	if reqHeight <= retrieveVoteExtensionsEnableHeight(ctx) {
		if len(extVoteInfo) != 0 {
			return nil, fmt.Errorf("non-empty VEs received at initial height %d", reqHeight)
		}
		return nil, nil
	}

	applyVEsFilteringFixes := helper.IsPhuketHardfork(reqHeight)
	maxVESizePerValidator := 0
	if applyVEsFilteringFixes {
		// Calculate per-validator VE's size limit based on actual MaxTxBytes.
		validatorsCount := len(validatorSet.Validators)
		if validatorsCount == 0 {
			return nil, fmt.Errorf("no validators in filterVoteExtensions")
		}

		calculatedSize := (int(maxTxBytes) / validatorsCount / safetyFactor) - overheadPerValidator

		// Clamp to [minNonRpVoteExtensionSize, maxVESize]
		maxVESizePerValidator = calculatedSize
		if maxVESizePerValidator < minNonRpVoteExtensionSize {
			maxVESizePerValidator = minNonRpVoteExtensionSize
			logger.Debug("Per-validator VE limit below minimum, using min value",
				"calculatedSize", calculatedSize, "minimum", minNonRpVoteExtensionSize)
		} else if maxVESizePerValidator > maxVESize {
			maxVESizePerValidator = maxVESize
			logger.Debug("Per-validator VE limit above maximum, using max value",
				"calculatedSize", calculatedSize, "maximum", maxVESize)
		}

		logger.Debug("Calculated per-validator VE size limits",
			"validatorsCount", validatorsCount,
			"maxTxBytes", maxTxBytes,
			"maxVESize", maxVESizePerValidator)
	}

	// Map to track seen validator addresses
	seenValidators := make(map[string]struct{})
	sumVPPerBlockHash := make(map[string]int64)

	ac := address.HexCodec{}

	for _, vote := range extVoteInfo {
		valAddrStr, err := ac.BytesToString(vote.Validator.Address)
		if err != nil {
			return nil, fmt.Errorf("validator address %v is not valid", vote.Validator.Address)
		}

		if applyVEsFilteringFixes {
			// Filter out undersized or oversized vote extensions.
			// Instead of dropping the entry (which would break ValidateVoteExtensionsCompleteness),
			// we emit a filtered placeholder: preserve Validator and BlockIdFlag but zero all
			// extension payload fields. This maintains the completeness invariant while excluding
			// the invalid VE from validation and VP tallying.
			veSize := len(vote.VoteExtension)
			nonRpSize := len(vote.NonRpVoteExtension)

			sizeFiltered := false
			if veSize < minVESize {
				logger.Warn("Filtering out undersized vote extension, emitting placeholder",
					"validator", valAddrStr,
					"veSize", veSize,
					"minVESize", minVESize)
				sizeFiltered = true
			} else if veSize > maxVESizePerValidator {
				logger.Warn("Filtering out oversized vote extension, emitting placeholder",
					"validator", valAddrStr,
					"veSize", veSize,
					"maxVESize", maxVESizePerValidator)
				sizeFiltered = true
			} else if nonRpSize < minNonRpVoteExtensionSize {
				logger.Warn("Filtering out undersized non-rp vote extension, emitting placeholder",
					"validator", valAddrStr,
					"nonRpVeSize", nonRpSize,
					"minNonRpSize", minNonRpVoteExtensionSize)
				sizeFiltered = true
			} else if nonRpSize > maxNonRpVoteExtensionSize {
				logger.Warn("Filtering out oversized non-rp vote extension, emitting placeholder",
					"validator", valAddrStr,
					"nonRpVeSize", nonRpSize,
					"maxNonRpSize", maxNonRpVoteExtensionSize)
				sizeFiltered = true
			}

			if sizeFiltered {
				// Emit placeholder: keep Validator + BlockIdFlag, zero payload.
				// Append immediately and skip all downstream validation for this vote.
				vote.VoteExtension = nil
				vote.ExtensionSignature = nil
				vote.NonRpVoteExtension = nil
				vote.NonRpExtensionSignature = nil
				validVoteExtensions = append(validVoteExtensions, vote)
				continue
			}
		}

		// reject unknown fields and skip invalid ones
		if err := rejectUnknownVoteExtFields(vote.VoteExtension); err != nil {
			if applyVEsFilteringFixes {
				logger.Warn("Unknown fields detected in vote extensions, emitting placeholder",
					"height", reqHeight, "error", err)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			logger.Warn("Unknown fields detected in vote extensions, skipping",
				"height", reqHeight, "error", err)
			continue
		}

		// make sure the BlockIdFlag is valid
		if !isBlockIdFlagValid(vote.BlockIdFlag) {
			logger.Warn("Received vote with invalid block ID flag at height, skipping",
				"blockIDFlag", vote.BlockIdFlag.String(),
				"height", reqHeight)
			continue
		}
		// if not BlockIDFlagCommit, skip that vote, as it doesn't have relevant information
		if vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			logger.Warn("Wrong block id flag, skipping",
				"blockIDFlag", vote.BlockIdFlag.String(),
				"height", reqHeight)
			continue
		}

		if len(vote.ExtensionSignature) == 0 {
			if applyVEsFilteringFixes {
				logger.Warn("Received empty vote extension signature, emitting placeholder",
					"height", reqHeight, "validator", valAddrStr)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			return nil, fmt.Errorf("received empty vote extension signature at height %d from validator %s", reqHeight, valAddrStr)
		}

		voteExtension := new(sidetxs.VoteExtension)
		if err = voteExtension.Unmarshal(vote.VoteExtension); err != nil {
			if applyVEsFilteringFixes {
				logger.Warn("Error while unmarshalling vote extension, emitting placeholder", "error", err)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			logger.Warn("Error while unmarshalling vote extension", "error", err)
			continue
		}

		if voteExtension.Height != reqHeight-1 {
			if applyVEsFilteringFixes {
				logger.Warn("Invalid height received for vote extension, emitting placeholder", "expected", reqHeight-1, "got", voteExtension.Height)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			logger.Warn("Invalid height received for vote extension", "expected", reqHeight-1, "got", voteExtension.Height)
			continue
		}

		txHash, err := validateSideTxResponses(voteExtension.SideTxResponses)
		if err != nil {
			if applyVEsFilteringFixes {
				logger.Warn("Invalid sideTxResponses detected for validator, emitting placeholder", "validator", valAddrStr, "txHash", common.Bytes2Hex(txHash), "error", err)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			logger.Warn("Invalid sideTxResponses detected for validator", "validator", valAddrStr, "txHash", common.Bytes2Hex(txHash), "error", err)
			continue
		}

		// Gate fork-specific proposition fields at the vote extension's own height. PrepareProposal's
		// context is one block ahead of the extension being filtered.
		milestoneCtx := ctx.WithBlockHeight(voteExtension.Height)
		if err := milestoneAbci.ValidateMilestoneProposition(milestoneCtx, &milestoneKeeper, voteExtension.MilestoneProposition); err != nil {
			if applyVEsFilteringFixes {
				logger.Warn("Invalid milestone proposition detected for validator, emitting placeholder", "validator", valAddrStr, "error", err)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			logger.Warn("Invalid milestone proposition detected for validator", "validator", valAddrStr, "error", err)
			continue
		}

		// Check for duplicate votes by the same validator
		if _, found := seenValidators[valAddrStr]; found {
			return nil, fmt.Errorf("duplicated vote detected from validator %s at height %d", valAddrStr, reqHeight)
		}
		// Add the validator address to the map
		seenValidators[valAddrStr] = struct{}{}

		_, validator := validatorSet.GetByAddress(valAddrStr)
		if validator == nil {
			if milestoneAbci.ShouldErrorOnValidatorNotFound(ctx.BlockHeight()) {
				logger.Warn(helper.ErrFailedToGetValidator(valAddrStr))
			}
			if applyVEsFilteringFixes {
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
			}
			continue
		}

		// ensure proposer-supplied power matches canonical power
		if vote.Validator.Power != validator.VotingPower {
			if applyVEsFilteringFixes {
				logger.Warn(
					"Mismatching voting power in FilterVoteExtension, emitting placeholder",
					"validator", valAddrStr,
					"receivedVotingPower", vote.Validator.Power,
					"expectedVotingPower", validator.VotingPower,
				)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			logger.Warn(
				"Mismatching voting power in FilterVoteExtension",
				"validator", valAddrStr,
				"receivedVotingPower", vote.Validator.Power,
				"expectedVotingPower", validator.VotingPower,
			)
			continue
		}

		cmtPubKey, err := getValidatorPublicKey(validator)
		if err != nil {
			return nil, err
		}

		cve := cmtTypes.CanonicalVoteExtension{
			Extension: vote.VoteExtension,
			Height:    reqHeight - 1, // the vote extension was signed in the previous height
			Round:     int64(round),
			ChainId:   ctx.ChainID(),
		}

		marshalDelimitedFn := func(msg proto.Message) ([]byte, error) {
			var buf bytes.Buffer
			if _, err := protoio.NewDelimitedWriter(&buf).WriteMsg(msg); err != nil {
				return nil, err
			}

			return buf.Bytes(), nil
		}

		extSignBytes, err := marshalDelimitedFn(&cve)
		if err != nil {
			return nil, fmt.Errorf("failed to encode CanonicalVoteExtension: %w", err)
		}

		if !cmtPubKey.VerifySignature(extSignBytes, vote.ExtensionSignature) {
			if applyVEsFilteringFixes {
				logger.Warn("Failed to verify ExtensionSignature, emitting placeholder",
					"validator", valAddrStr)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
			return nil, fmt.Errorf("failed to verify validator %s vote extension signature", valAddrStr)
		}

		// Verify NonRpExtensionSignature to prevent a pass for filterVoteExtensions
		// with a valid ExtensionSignature but an invalid NonRpExtensionSignature.
		if applyVEsFilteringFixes {
			if !cmtPubKey.VerifySignature(vote.NonRpVoteExtension, vote.NonRpExtensionSignature) {
				logger.Warn("Failed to verify NonRpExtensionSignature, emitting placeholder",
					"validator", valAddrStr)
				validVoteExtensions = append(validVoteExtensions, toFilteredPlaceholder(vote))
				continue
			}
		}

		sumVPPerBlockHash[common.Bytes2Hex(voteExtension.BlockHash)] += validator.VotingPower

		validVoteExtensions = append(validVoteExtensions, vote)
	}

	// Ensure we have at least 2/3 voting power for the submitted vote extensions in each side tx
	totalVotingPower := validatorSet.GetTotalVotingPower()
	sumVP := int64(0)

	majorityVP := totalVotingPower * 2 / 3
	var majorityBlockHash string
	for sumVPBlockHash, vp := range sumVPPerBlockHash {
		if vp > majorityVP {
			sumVP = vp
			majorityBlockHash = sumVPBlockHash
			break
		}
	}

	if sumVP <= majorityVP {
		return nil, fmt.Errorf("insufficient cumulative voting power received to verify vote extensions; got: %d, expected: >%d", sumVP, majorityVP)
	}

	logger.Debug("Majority block hash selected",
		"blockHash", majorityBlockHash,
		"votingPower", sumVP,
		"majorityThreshold", majorityVP)

	filteredByBlockHash := make([]abciTypes.ExtendedVoteInfo, 0, len(validVoteExtensions))
	for _, vote := range validVoteExtensions {
		// Preserve filtered placeholders through block-hash filtering
		if isFilteredPlaceholder(vote) {
			filteredByBlockHash = append(filteredByBlockHash, vote)
			continue
		}
		ve := new(sidetxs.VoteExtension)
		if err := ve.Unmarshal(vote.VoteExtension); err != nil {
			if applyVEsFilteringFixes {
				logger.Warn("Error unmarshalling VE during block-hash filtering, emitting placeholder",
					"error", err)
				filteredByBlockHash = append(filteredByBlockHash, toFilteredPlaceholder(vote))
			}
			continue
		}
		if common.Bytes2Hex(ve.BlockHash) == majorityBlockHash {
			filteredByBlockHash = append(filteredByBlockHash, vote)
		} else if applyVEsFilteringFixes {
			logger.Warn("Vote extension block hash does not match majority, emitting placeholder",
				"voteBlockHash", common.Bytes2Hex(ve.BlockHash),
				"majorityBlockHash", majorityBlockHash)
			filteredByBlockHash = append(filteredByBlockHash, toFilteredPlaceholder(vote))
		}
	}

	return filteredByBlockHash, nil
}

// tallyVotes tallies the votes received for the side tx
// It returns the lists of txs which got >2/3+ YES, NO, and UNSPECIFIED votes respectively
func tallyVotes(extVoteInfo []abciTypes.ExtendedVoteInfo, logger log.Logger, validatorSet *stakeTypes.ValidatorSet, currentHeight int64) ([][]byte, [][]byte, [][]byte, error) {
	logger.Debug("Tallying votes")

	// Always derive total voting power from the canonical validator set
	totalVotingPower := validatorSet.GetTotalVotingPower()

	voteByTxHash, err := aggregateVotes(extVoteInfo, validatorSet, currentHeight, logger)
	if err != nil {
		return nil, nil, nil, err
	}

	// check for the votes majority
	txHashList := make([]string, 0, len(voteByTxHash))
	for txHash := range voteByTxHash {
		txHashList = append(txHashList, txHash)
	}

	sort.Strings(txHashList)

	approvedTxs, rejectedTxs, skippedTxs := make([][]byte, 0, len(txHashList)), make([][]byte, 0, len(txHashList)), make([][]byte, 0, len(txHashList))

	majorityVP := totalVotingPower * 2 / 3

	for _, txHash := range txHashList {
		voteMap := voteByTxHash[txHash]

		// calculate the total voting power in the voteMap
		power := voteMap[sidetxs.Vote_VOTE_YES] + voteMap[sidetxs.Vote_VOTE_NO] + voteMap[sidetxs.Vote_UNSPECIFIED]

		// ensure the total votes do not exceed the total voting power
		if shouldCheckVotingPower(currentHeight) && power > totalVotingPower {
			logger.Error("The votes power exceeds the total voting power", "txHash", txHash, "power", power, "totalVotingPower", totalVotingPower)
			return nil, nil, nil, fmt.Errorf("votes power %d exceeds total voting power %d for txHash %s", power, totalVotingPower, txHash)
		}

		if voteMap[sidetxs.Vote_VOTE_YES] > majorityVP {
			// approved
			logger.Debug("Approved side-tx", "txHash", txHash)
			consensus.RecordConsensusApproved()
			// append to approved tx slice
			approvedTxs = append(approvedTxs, common.FromHex(txHash))
		} else if voteMap[sidetxs.Vote_VOTE_NO] > majorityVP {
			// rejected
			logger.Debug("Rejected side-tx", "txHash", txHash)
			consensus.RecordConsensusRejected()
			// append to rejected tx slice
			rejectedTxs = append(rejectedTxs, common.FromHex(txHash))
		} else {
			// skipped - 2/3 consensus not reached.
			logger.Debug("Skipped side-tx", "txHash", txHash)
			consensus.RecordConsensusFailure()
			// append to rejected tx slice
			skippedTxs = append(skippedTxs, common.FromHex(txHash))
		}
	}

	logger.Debug(fmt.Sprintf("Height %d: approved %d txs, rejected %d txs, skipped %d txs. ", currentHeight, len(approvedTxs), len(rejectedTxs), len(skippedTxs)))

	// HV2: currently, there is no functional difference between a tc being rejected or skipped (only used for debugging)
	return approvedTxs, rejectedTxs, skippedTxs, nil
}

// aggregateVotes collates votes received for side txs
func aggregateVotes(extVoteInfo []abciTypes.ExtendedVoteInfo, validatorSet *stakeTypes.ValidatorSet, currentHeight int64, logger log.Logger) (map[string]map[sidetxs.Vote]int64, error) {
	voteByTxHash := make(map[string]map[sidetxs.Vote]int64)  // track votes for a side tx
	validatorToTxMap := make(map[string]map[string]struct{}) // ensure a validator doesn't procure conflicting votes for a side tx
	var blockHash []byte                                     // store the block hash to make sure all votes are for the same block

	ac := address.HexCodec{}

	for _, vote := range extVoteInfo {
		// Skip filtered placeholders (see isFilteredPlaceholder)
		if isFilteredPlaceholder(vote) {
			continue
		}

		// make sure the BlockIdFlag is valid
		if !isBlockIdFlagValid(vote.BlockIdFlag) {
			return nil, fmt.Errorf("received vote with invalid block ID %s flag at height %d", vote.BlockIdFlag.String(), currentHeight-1)
		}
		// if not BlockIDFlagCommit, skip that vote, as it doesn't have relevant information
		if vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			continue
		}

		ve := new(sidetxs.VoteExtension)
		if err := ve.Unmarshal(vote.VoteExtension); err != nil {
			return nil, err
		}

		if ve.Height != currentHeight-1 {
			return nil, fmt.Errorf("invalid height received for vote extension, VeHeight should match CurrentHeight-1. VeHeight: %d, CurrentHeight: %d", ve.Height, currentHeight)
		}

		// blockHash consistency check
		if blockHash == nil {
			// store the block hash from the first vote
			blockHash = ve.BlockHash
		} else {
			valAddr, err := ac.BytesToString(vote.Validator.Address)
			if err != nil {
				return nil, err
			}
			// compare the current block hash with the stored block hash
			if !bytes.Equal(blockHash, ve.BlockHash) {
				logger.Error("Invalid block hash found for vote extension",
					"expectedBlockHash", common.Bytes2Hex(blockHash),
					"receivedBlockHash", common.Bytes2Hex(ve.BlockHash),
					"validator", valAddr)
				return nil, fmt.Errorf("mismatching block hash for vote extension from validator %s", valAddr)
			}
		}

		addr, err := ac.BytesToString(vote.Validator.Address)
		if err != nil {
			return nil, err
		}

		// Look up canonical validator and voting power (don't trust the power carried in ExtendedCommitInfo)
		_, validator := validatorSet.GetByAddress(addr)
		if validator == nil {
			logger.Error(
				"validator from vote extension not found in canonical validator set", "validator", addr, "height", currentHeight)
			continue
		}
		canonicalPower := validator.VotingPower

		if validatorToTxMap[addr] != nil {
			return nil, fmt.Errorf("duplicate vote received from %s", addr)
		}
		validatorToTxMap[addr] = make(map[string]struct{})

		// iterate through vote extensions and accumulate voting power for YES/NO/UNSPECIFIED votes
		for _, res := range ve.SideTxResponses {
			txHashStr := common.Bytes2Hex(res.TxHash)

			if _, hasVoted := validatorToTxMap[addr][txHashStr]; hasVoted {
				logger.Error("Multiple votes received for side tx",
					"txHash", txHashStr, "validatorAddress", addr)
				return nil, fmt.Errorf("multiple votes received for side tx %s from validator %s", txHashStr, addr)
			}

			if !isVoteValid(res.Result) {
				return nil, fmt.Errorf("invalid vote %v received for side tx %s", res.Result, txHashStr)
			}

			if voteByTxHash[txHashStr] == nil {
				voteByTxHash[txHashStr] = make(map[sidetxs.Vote]int64)
			}

			// use canonical power from the validator set
			voteByTxHash[txHashStr][res.Result] += canonicalPower

			// validator's vote received; mark it to avoid duplicated votes
			validatorToTxMap[addr][txHashStr] = struct{}{}
		}

	}

	return voteByTxHash, nil
}

// validateSideTxResponses validates the SideTxResponses and returns the txHash of the first invalid tx detected, plus the error
func validateSideTxResponses(sideTxResponses []sidetxs.SideTxResponse) ([]byte, error) {
	// track votes of the validator
	txVoteMap := make(map[string]struct{})

	if len(sideTxResponses) > maxSideTxResponsesCount {
		return nil, fmt.Errorf("too many side tx responses received: %d, max: %d", len(sideTxResponses), maxSideTxResponsesCount)
	}

	for _, res := range sideTxResponses {
		// check txHash is well-formed
		if len(res.TxHash) != common.HashLength {
			return res.TxHash, fmt.Errorf("invalid tx hash received: %s", common.Bytes2Hex(res.TxHash))
		}

		if !isVoteValid(res.Result) {
			return res.TxHash, fmt.Errorf("invalid vote result type %v received for side tx %s", res.Result, common.Bytes2Hex(res.TxHash))
		}

		// check if the validator has already voted for the side tx
		if _, found := txVoteMap[string(res.TxHash)]; found {
			return res.TxHash, fmt.Errorf("duplicated votes detected for side tx %s", common.Bytes2Hex(res.TxHash))
		}

		txVoteMap[string(res.TxHash)] = struct{}{}
	}

	return nil, nil
}

// checkIfVoteExtensionsDisabled indicates whether the proposer must include VEs from previous height in the block proposal as a special transaction.
// Since we are using a hard fork approach for the heimdall migration, VEs will be enabled from v2 genesis' initial height (v1 last height +1).
// Returning an error will result in CometBFT panic.
func checkIfVoteExtensionsDisabled(ctx sdk.Context, height int64) error {
	// voteExtensionsEnableHeight is the height from which the vote extensions are enabled, and it's (v1_last_height +1)
	voteExtensionsEnableHeight := retrieveVoteExtensionsEnableHeight(ctx)
	if voteExtensionsEnableHeight == 0 {
		return errors.New("VoteExtensions are disabled: VoteExtensionsEnableHeight is set to 0")
	}
	if height < voteExtensionsEnableHeight {
		return fmt.Errorf("vote extensions are disabled: current height is %d, and VoteExtensionsEnableHeight is set to %d", height, voteExtensionsEnableHeight)
	}
	return nil
}

func isVoteValid(v sidetxs.Vote) bool {
	return v == sidetxs.Vote_UNSPECIFIED || v == sidetxs.Vote_VOTE_YES || v == sidetxs.Vote_VOTE_NO
}

func isBlockIdFlagValid(flag cmtTypes.BlockIDFlag) bool {
	return flag == cmtTypes.BlockIDFlagAbsent || flag == cmtTypes.BlockIDFlagCommit || flag == cmtTypes.BlockIDFlagNil
}

// isFilteredPlaceholder returns true when a vote entry was kept for completeness
// but its payload was stripped after proposer-side filtering rejected the original VE.
// Placeholder semantics: the validator committed the previous block (BlockIDFlagCommit)
// but all extension data has been zeroed out. Consumers must skip these entries
// without error and without counting their voting power.
func isFilteredPlaceholder(vote abciTypes.ExtendedVoteInfo) bool {
	return vote.BlockIdFlag == cmtTypes.BlockIDFlagCommit &&
		len(vote.VoteExtension) == 0 &&
		len(vote.ExtensionSignature) == 0 &&
		len(vote.NonRpVoteExtension) == 0 &&
		len(vote.NonRpExtensionSignature) == 0
}

// retrieveVoteExtensionsEnableHeight returns the height from which the vote extensions are enabled, which is equal to the initial height of the v2 genesis
func retrieveVoteExtensionsEnableHeight(ctx sdk.Context) int64 {
	consensusParams := ctx.ConsensusParams()
	return consensusParams.GetAbci().GetVoteExtensionsEnableHeight()
}

// GetDummyNonRpVoteExtension returns a dummy non-rp vote extension for given height and chain id
func GetDummyNonRpVoteExtension(height int64, chainID string) ([]byte, error) {
	var buf bytes.Buffer

	writtenBytes, err := buf.Write(dummyNonRpVoteExtension)
	if err != nil {
		return nil, err
	}
	if writtenBytes != len(dummyNonRpVoteExtension) {
		return nil, errors.New("failed to write dummy vote extension")
	}
	if err := buf.WriteByte('|'); err != nil {
		return nil, err
	}

	if err := binary.Write(&buf, binary.BigEndian, height); err != nil {
		return nil, err
	}
	if err := buf.WriteByte('|'); err != nil {
		return nil, err
	}

	writtenBytes, err = buf.WriteString(chainID)
	if err != nil {
		return nil, err
	}
	if writtenBytes != len(chainID) {
		return nil, errors.New("failed to write chainID")
	}

	return buf.Bytes(), nil
}

// ValidateNonRpVoteExtensions validates the non-rp vote extensions
func ValidateNonRpVoteExtensions(
	ctx sdk.Context,
	height int64,
	extVoteInfo []abciTypes.ExtendedVoteInfo,
	validatorSet *stakeTypes.ValidatorSet,
	chainManagerKeeper chainManagerKeeper.Keeper,
	checkpointKeeper checkpointKeeper.Keeper,
	contractCaller helper.IContractCaller,
	logger log.Logger,
) error {
	if height <= retrieveVoteExtensionsEnableHeight(ctx) {
		return nil
	}

	// Check if there is a vote extension with majority voting power
	majorityExt, err := getMajorityNonRpVoteExtension(ctx, extVoteInfo, validatorSet, logger)
	if err != nil {
		return err
	}

	// Not running rejectUnknownVoteExtFields() here, because
	// NonRpVoteExtension is not a protobuf-encoded sidetxs.VoteExtension and
	// it would incorrectly reject valid non-rp VEs.

	// Signatures first: NonRpExtensionSignature must be verified before any
	// Bor-dependent payload validation, so the Zurich gated tolerateBorErr carve-out
	// in callers cannot suppress a signature failure when Bor is unreachable.
	if err := checkNonRpVoteExtensionsSignatures(ctx, extVoteInfo, validatorSet); err != nil {
		return fmt.Errorf("failed to check non rp vote extensions signatures: %w", err)
	}

	if err := validateNonRpVoteExtensionData(ctx, height-1, majorityExt, chainManagerKeeper, checkpointKeeper, contractCaller); err != nil {
		return fmt.Errorf("failed to validate majority non rp vote extension: %w", err)
	}

	return nil
}

// validateNonRpVoteExtensionData validates the non-rp vote extension inner data
func validateNonRpVoteExtensionData(
	ctx sdk.Context,
	height int64,
	extension []byte,
	chainManagerKeeper chainManagerKeeper.Keeper,
	checkpointKeeper checkpointKeeper.Keeper,
	contractCaller helper.IContractCaller,
) error {
	if len(extension) < minNonRpVoteExtensionSize {
		return fmt.Errorf("non-rp vote extension size is too small: %d, min: %d", len(extension), minNonRpVoteExtensionSize)
	}

	if len(extension) > maxNonRpVoteExtensionSize {
		return fmt.Errorf("non-rp vote extension size is too large: %d, max: %d", len(extension), maxNonRpVoteExtensionSize)
	}

	// Check if its dummy vote non rp extension
	dummyExt, err := GetDummyNonRpVoteExtension(height, ctx.ChainID())
	if err != nil {
		return err
	}

	if bytes.Equal(extension, dummyExt) {
		// This is a dummy vote extension, so we have nothing else to check
		return nil
	}

	// Check if valid checkpoint data
	if err := validateCheckpointMsgData(ctx, height, extension, chainManagerKeeper, checkpointKeeper, contractCaller); err != nil {
		return fmt.Errorf("failed to validate checkpoint msg data: %w", err)
	}

	return nil
}

// checkNonRpVoteExtensionsSignatures checks the signatures of the non-rp vote extensions
func checkNonRpVoteExtensionsSignatures(ctx sdk.Context, extVoteInfo []abciTypes.ExtendedVoteInfo, validatorSet *stakeTypes.ValidatorSet) error {
	ac := address.HexCodec{}

	for _, vote := range extVoteInfo {
		// Skip filtered placeholders
		if isFilteredPlaceholder(vote) {
			continue
		}

		// if not BlockIDFlagCommit, skip that vote, as it doesn't have relevant information
		if vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			continue
		}

		valAddr, err := ac.BytesToString(vote.Validator.Address)
		if err != nil {
			return err
		}

		_, validator := validatorSet.GetByAddress(valAddr)
		if validator == nil {
			if milestoneAbci.ShouldErrorOnValidatorNotFound(ctx.BlockHeight()) {
				return errors.New(helper.ErrFailedToGetValidator(valAddr))
			}
			continue
		}

		cmtPubKey, err := getValidatorPublicKey(validator)
		if err != nil {
			return err
		}

		if !cmtPubKey.VerifySignature(vote.NonRpVoteExtension, vote.NonRpExtensionSignature) {
			return fmt.Errorf("failed to verify validator %X vote extension signature", valAddr)
		}
	}

	return nil
}

// getMajorityNonRpVoteExtension returns the non-rp vote extension with the majority voting power
// It enforces that the majority extension must have >2/3 voting power
func getMajorityNonRpVoteExtension(ctx sdk.Context, extVoteInfo []abciTypes.ExtendedVoteInfo, validatorSet *stakeTypes.ValidatorSet, logger log.Logger) ([]byte, error) {
	ac := address.HexCodec{}

	hashToExt := make(map[string][]byte)
	hashToVotingPower := make(map[string]int64)

	for _, vote := range extVoteInfo {
		// Skip filtered placeholders (see isFilteredPlaceholder)
		if isFilteredPlaceholder(vote) {
			continue
		}

		// if not BlockIDFlagCommit, skip that vote, as it doesn't have relevant information
		if vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			continue
		}

		hash := common.BytesToHash(crypto.Keccak256(vote.NonRpVoteExtension)).String()
		hashToExt[hash] = vote.NonRpVoteExtension
		if _, ok := hashToVotingPower[hash]; !ok {
			hashToVotingPower[hash] = 0
		}

		valAddr, err := ac.BytesToString(vote.Validator.Address)
		if err != nil {
			return nil, err
		}

		_, validator := validatorSet.GetByAddress(valAddr)
		if validator == nil {
			if milestoneAbci.ShouldErrorOnValidatorNotFound(ctx.BlockHeight()) {
				return nil, errors.New(helper.ErrFailedToGetValidator(valAddr))
			}
			continue
		}

		hashToVotingPower[hash] += validator.VotingPower
	}

	if len(hashToVotingPower) > 1 {
		logger.Error("Multiple non-rp vote extensions detected, there should be only one: potential malicious activity")
	}

	isPhuketHardfork := helper.IsPhuketHardfork(ctx.BlockHeight())
	totalVotingPower := validatorSet.GetTotalVotingPower()
	majorityVP := totalVotingPower * 2 / 3

	var maxVotingPower int64
	var maxHash string

	hashList := make([]string, 0, len(hashToVotingPower))
	for hash := range hashToVotingPower {
		hashList = append(hashList, hash)
	}
	sort.Strings(hashList)

	for _, hash := range hashList {
		if votingPower := hashToVotingPower[hash]; votingPower > maxVotingPower {
			maxVotingPower = votingPower
			maxHash = hash
		}
	}

	// Enforce >2/3 voting power threshold only after the consensus-fixes hardfork.
	if isPhuketHardfork && maxVotingPower <= majorityVP {
		return nil, fmt.Errorf("insufficient voting power for majority non-rp vote extension: got %d, required >%d", maxVotingPower, majorityVP)
	}

	return hashToExt[maxHash], nil
}

// validateCheckpointMsgData validates the extension is a valid checkpoint
// checkpointWindowContinuity cheaply rejects a non-RP checkpoint window that doesn't
// continue from the last checkpoint, before the Bor RPC inside IsValidCheckpoint. The
// window is proposer-supplied; a window that shifts [start,end] each round would otherwise miss the
// root cache and force a fresh GetRootHash on every honest validator. A legitimate
// checkpoint starts at the last checkpoint's end block + 1 (enforced by the checkpoint side
// handler). Gated so vote validity is unchanged until the hardfork.
func checkpointWindowContinuity(ctx sdk.Context, height int64, checkpointKeeper checkpointKeeper.Keeper, startBlock uint64) error {
	if !helper.IsKyoto(height) {
		return nil
	}
	lastCheckpoint, err := checkpointKeeper.GetLastCheckpoint(ctx)
	if err != nil {
		if errors.Is(err, checkpointTypes.ErrNoCheckpointFound) {
			if startBlock != 0 {
				return fmt.Errorf("first checkpoint must start from block 0, got %d", startBlock)
			}
			return nil
		}
		// Any other error (store/decode) is abnormal; propagate it so the extension is
		// rejected deterministically rather than silently skipping the continuity check.
		return fmt.Errorf("failed to read last checkpoint for continuity check: %w", err)
	}
	if lastCheckpoint.EndBlock+1 != startBlock {
		return fmt.Errorf("checkpoint not in continuity: expected start %d, got %d", lastCheckpoint.EndBlock+1, startBlock)
	}
	return nil
}

func validateCheckpointMsgData(ctx sdk.Context, height int64, extension []byte, chainManagerKeeper chainManagerKeeper.Keeper, checkpointKeeper checkpointKeeper.Keeper, contractCaller helper.IContractCaller) error {
	if len(extension) < minNonRpVoteExtensionSize {
		return fmt.Errorf("non-rp vote extension size is too small: %d, min: %d", len(extension), minNonRpVoteExtensionSize)
	}
	// Unpack the checkpoint side sign bytes
	checkpointMsg, err := checkpointTypes.UnpackCheckpointSideSignBytes(extension[1:]) // skip the first byte which is the vote
	if err != nil {
		return fmt.Errorf("failed to unpack checkpoint side sign bytes: %w", err)
	}

	chainParams, err := chainManagerKeeper.GetParams(ctx)
	if err != nil {
		return fmt.Errorf("failed to get chain manager params: %w", err)
	}

	if chainParams.ChainParams.BorChainId != checkpointMsg.BorChainId {
		return fmt.Errorf("invalid bor chain id, expected %s, got %s", chainParams.ChainParams.BorChainId, checkpointMsg.BorChainId)
	}

	borChainTxConfirmations := chainParams.BorChainTxConfirmations

	if err := checkpointWindowContinuity(ctx, height, checkpointKeeper, checkpointMsg.StartBlock); err != nil {
		return err
	}

	params, err := checkpointKeeper.GetParams(ctx)
	if err != nil {
		return fmt.Errorf("failed to get checkpoint params: %w", err)
	}

	if err := checkpointKeeper.ValidateCheckpointWindow(ctx, height, checkpointMsg.StartBlock, checkpointMsg.EndBlock); err != nil {
		return err
	}

	isValid, err := checkpointTypes.IsValidCheckpoint(
		ctx,
		checkpointMsg.StartBlock,
		checkpointMsg.EndBlock,
		checkpointMsg.RootHash,
		params.MaxCheckpointLength,
		contractCaller,
		borChainTxConfirmations)
	if err != nil {
		return fmt.Errorf("failed to validate checkpoint msg: %w", err)
	}

	if !isValid {
		return errors.New("invalid checkpoint msg data")
	}

	return nil
}

// getPreviousBlockValidatorSet returns the validator set from the previous block
func getPreviousBlockValidatorSet(ctx sdk.Context, stakeKeeper stakeKeeper.Keeper) (*stakeTypes.ValidatorSet, error) {
	// Fetch validatorSet from the previous block
	validatorSet, err := stakeKeeper.GetPreviousBlockValidatorSet(ctx)
	if err != nil {
		return nil, err
	}
	if len(validatorSet.Validators) == 0 {
		return nil, errors.New("no validators found in validator set")
	}
	return &validatorSet, nil
}

// getPenultimateBlockValidatorSet returns the validator set from 2 blocks ago
func getPenultimateBlockValidatorSet(ctx sdk.Context, stakeKeeper stakeKeeper.Keeper) (*stakeTypes.ValidatorSet, error) {
	// fetch validatorSet from 2 blocks ago
	validatorSet, err := stakeKeeper.GetPenultimateBlockValidatorSet(ctx)
	if err != nil {
		return nil, err
	}
	if len(validatorSet.Validators) == 0 {
		return nil, errors.New("no validators found in validator set from 2 blocks ago")
	}
	return &validatorSet, nil
}

// getValidatorPublicKey returns the public key of the validator given
func getValidatorPublicKey(validator *stakeTypes.Validator) (cmtCrypto.PubKey, error) {
	cmtPubKeyProto, err := validator.CmtConsPublicKey()
	if err != nil {
		return nil, fmt.Errorf("%s: %w", helper.ErrFailedToGetValidatorPublicKey(validator.Signer), err)
	}

	cmtPubKey, err := cryptoenc.PubKeyFromProto(cmtPubKeyProto)
	if err != nil {
		return nil, fmt.Errorf("failed to convert validator %s public key: %w", validator.Signer, err)
	}

	return cmtPubKey, nil
}

// findCheckpointTx finds the checkpoint tx from the given txs that generated the given extension
// If no such tx is found, an empty string is returned
func findCheckpointTx(txs [][]byte, extension []byte, txDecoder txDecoder, logger log.Logger) string {
	for _, rawTx := range txs {
		tx, err := txDecoder.TxDecode(rawTx)
		if err != nil {
			logger.Error("Failed to decode tx", "error", err)
			continue
		}

		messages := tx.GetMsgs()
		for _, msg := range messages {
			if checkpointTypes.IsCheckpointMsg(msg) {
				checkpointMsg, ok := msg.(*checkpointTypes.MsgCheckpoint)
				if !ok {
					logger.Error("Type mismatch for MsgCheckpoint")
					continue
				}

				signBytes := checkpointMsg.GetSideSignBytes()

				if bytes.Equal(signBytes, extension) {
					var txBytes cometTypes.Tx = rawTx
					return common.Bytes2Hex(txBytes.Hash())
				}
			}
		}
	}

	return ""
}

// getCheckpointSignatures returns the checkpoint signatures from the given extVoteInfo.
// From the Zurich hardfork onward, non-commit entries are skipped.
func getCheckpointSignatures(height int64, extension []byte, extVoteInfo []abciTypes.ExtendedVoteInfo) checkpointTypes.CheckpointSignatures {
	result := checkpointTypes.CheckpointSignatures{
		Signatures: make([]checkpointTypes.CheckpointSignature, 0),
	}
	commitOnly := helper.IsZurichHardfork(height)
	for _, vote := range extVoteInfo {
		if commitOnly && vote.BlockIdFlag != cmtTypes.BlockIDFlagCommit {
			continue
		}
		if bytes.Equal(vote.NonRpVoteExtension, extension) {
			result.Signatures = append(result.Signatures, checkpointTypes.CheckpointSignature{
				ValidatorAddress: vote.Validator.Address,
				Signature:        vote.NonRpExtensionSignature,
			})
		}
	}
	return result
}

type txDecoder interface {
	TxDecode(txBytes []byte) (sdk.Tx, error)
}

func packExtensionWithVote(extension []byte) []byte {
	yesVote := []byte{0x01}
	var buf bytes.Buffer
	buf.Write(yesVote)
	buf.Write(extension)
	return buf.Bytes()
}

func shouldCheckVotingPower(currentHeight int64) bool {
	return currentHeight < helper.GetDisableVPCheckHeight() || currentHeight >= helper.GetTallyFixHeight()
}
