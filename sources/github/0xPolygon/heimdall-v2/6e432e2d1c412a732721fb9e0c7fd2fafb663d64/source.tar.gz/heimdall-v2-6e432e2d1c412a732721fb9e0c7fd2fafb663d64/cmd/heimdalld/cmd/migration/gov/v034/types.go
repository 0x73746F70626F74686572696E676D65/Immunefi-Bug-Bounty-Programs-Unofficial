// DONTCOVER
package v034

import (
	"encoding/json"
	"fmt"
	"time"

	sdk "github.com/cosmos/cosmos-sdk/types"
)

var _ ProposalContent = TextProposal{}

const (
	StatusNil           ProposalStatus = 0x00
	StatusDepositPeriod ProposalStatus = 0x01
	StatusVotingPeriod  ProposalStatus = 0x02
	StatusPassed        ProposalStatus = 0x03
	StatusRejected      ProposalStatus = 0x04
	StatusFailed        ProposalStatus = 0x05

	proposalStatusDepositPeriod = "DepositPeriod"
	proposalStatusVotingPeriod  = "VotingPeriod"
	proposalStatusPassed        = "Passed"
	proposalStatusRejected      = "Rejected"
	proposalStatusFailed        = "Failed"

	voteOptionYes        = "Yes"
	voteOptionAbstain    = "Abstain"
	voteOptionNoWithVeto = "NoWithVeto"

	proposalTypeText            = "Text"
	proposalTypeParameterChange = "ParameterChange"

	OptionEmpty      VoteOption = 0x00
	OptionYes        VoteOption = 0x01
	OptionAbstain    VoteOption = 0x02
	OptionNo         VoteOption = 0x03
	OptionNoWithVeto VoteOption = 0x04

	ProposalTypeText            ProposalKind = 0x01
	ProposalTypeParameterChange ProposalKind = 0x02
)

type (
	ProposalQueue []uint64

	ProposalKind byte

	VoteOption     byte
	ProposalStatus byte

	ProposalContent interface {
		GetTitle() string
		GetDescription() string
		ProposalType() ProposalKind
	}

	Proposals []Proposal

	TextProposal struct {
		Title       string `json:"title"`
		Description string `json:"description"`
	}

	Proposal struct {
		ProposalContent `json:"proposal_content"`

		ProposalID uint64 `json:"proposal_id"`

		Status           ProposalStatus `json:"proposal_status"`
		FinalTallyResult TallyResult    `json:"final_tally_result"`

		SubmitTime     time.Time `json:"submit_time"`
		DepositEndTime time.Time `json:"deposit_end_time"`
		TotalDeposit   sdk.Coins `json:"total_deposit"`

		VotingStartTime time.Time `json:"voting_start_time"`
		VotingEndTime   time.Time `json:"voting_end_time"`
	}

	TallyParams struct {
		Quorum    string `json:"quorum,omitempty"`
		Threshold string `json:"threshold,omitempty"`
		Veto      string `json:"veto,omitempty"`
	}

	VotingParams struct {
		VotingPeriod time.Duration `json:"voting_period,omitempty"`
	}

	TallyResult struct {
		Yes        string `json:"yes"`
		Abstain    string `json:"abstain"`
		No         string `json:"no"`
		NoWithVeto string `json:"no_with_veto"`
	}

	Deposits []Deposit

	Vote struct {
		ProposalID uint64         `json:"proposal_id"`
		Voter      sdk.AccAddress `json:"voter"`
		Option     VoteOption     `json:"option"`
	}

	Votes []Vote

	DepositParams struct {
		MinDeposit       sdk.Coins     `json:"min_deposit,omitempty"`
		MaxDepositPeriod time.Duration `json:"max_deposit_period,omitempty"`
	}

	Deposit struct {
		ProposalID uint64         `json:"proposal_id"`
		Depositor  sdk.AccAddress `json:"depositor"`
		Amount     sdk.Coins      `json:"amount"`
	}

	DepositWithMetadata struct {
		ProposalID uint64  `json:"proposal_id"`
		Deposit    Deposit `json:"deposit"`
	}

	VoteWithMetadata struct {
		ProposalID uint64 `json:"proposal_id"`
		Vote       Vote   `json:"vote"`
	}

	GenesisState struct {
		StartingProposalID uint64                `json:"starting_proposal_id"`
		Deposits           []DepositWithMetadata `json:"deposits"`
		Votes              []VoteWithMetadata    `json:"votes"`
		Proposals          []Proposal            `json:"proposals"`
		DepositParams      DepositParams         `json:"deposit_params"`
		VotingParams       VotingParams          `json:"voting_params"`
		TallyParams        TallyParams           `json:"tally_params"`
	}
)

func (tp TextProposal) GetTitle() string           { return tp.Title }
func (tp TextProposal) GetDescription() string     { return tp.Description }
func (tp TextProposal) ProposalType() ProposalKind { return ProposalTypeText }

// ProposalStatusFromString turns a string into a ProposalStatus
func ProposalStatusFromString(str string) (ProposalStatus, error) {
	switch str {
	case proposalStatusDepositPeriod:
		return StatusDepositPeriod, nil

	case proposalStatusVotingPeriod:
		return StatusVotingPeriod, nil

	case proposalStatusPassed:
		return StatusPassed, nil

	case proposalStatusRejected:
		return StatusRejected, nil

	case proposalStatusFailed:
		return StatusFailed, nil

	case "":
		return StatusNil, nil

	default:
		return ProposalStatus(0xff), fmt.Errorf("'%s' is not a valid proposal status", str)
	}
}

func (status ProposalStatus) Marshal() ([]byte, error) {
	return []byte{byte(status)}, nil
}

func (status *ProposalStatus) Unmarshal(data []byte) error {
	*status = ProposalStatus(data[0])
	return nil
}

func (status ProposalStatus) MarshalJSON() ([]byte, error) {
	return json.Marshal(status.String())
}

func (status *ProposalStatus) UnmarshalJSON(data []byte) error {
	var s string
	err := json.Unmarshal(data, &s)
	if err != nil {
		return err
	}

	bz2, err := ProposalStatusFromString(s)
	if err != nil {
		return err
	}

	*status = bz2
	return nil
}

func (status ProposalStatus) String() string {
	switch status {
	case StatusDepositPeriod:
		return proposalStatusDepositPeriod

	case StatusVotingPeriod:
		return proposalStatusVotingPeriod

	case StatusPassed:
		return proposalStatusPassed

	case StatusRejected:
		return proposalStatusRejected

	case StatusFailed:
		return proposalStatusFailed

	default:
		return ""
	}
}

func VoteOptionFromString(str string) (VoteOption, error) {
	switch str {
	case voteOptionYes:
		return OptionYes, nil

	case voteOptionAbstain:
		return OptionAbstain, nil

	case "No":
		return OptionNo, nil

	case voteOptionNoWithVeto:
		return OptionNoWithVeto, nil

	default:
		return VoteOption(0xff), fmt.Errorf("'%s' is not a valid vote option", str)
	}
}

func (vo VoteOption) Marshal() ([]byte, error) {
	return []byte{byte(vo)}, nil
}

func (vo *VoteOption) Unmarshal(data []byte) error {
	*vo = VoteOption(data[0])
	return nil
}

func (vo VoteOption) MarshalJSON() ([]byte, error) {
	return json.Marshal(vo.String())
}

func (vo *VoteOption) UnmarshalJSON(data []byte) error {
	var s string
	err := json.Unmarshal(data, &s)
	if err != nil {
		return err
	}

	bz2, err := VoteOptionFromString(s)
	if err != nil {
		return err
	}

	*vo = bz2
	return nil
}

func (vo VoteOption) String() string {
	switch vo {
	case OptionYes:
		return voteOptionYes
	case OptionAbstain:
		return voteOptionAbstain
	case OptionNo:
		return "No"
	case OptionNoWithVeto:
		return voteOptionNoWithVeto
	default:
		return ""
	}
}

func ProposalTypeFromString(str string) (ProposalKind, error) {
	switch str {
	case proposalTypeText:
		return ProposalTypeText, nil
	case proposalTypeParameterChange:
		return ProposalTypeParameterChange, nil
	default:
		return ProposalKind(0xff), fmt.Errorf("'%s' is not a valid proposal type", str)
	}
}

func (pt ProposalKind) Marshal() ([]byte, error) {
	return []byte{byte(pt)}, nil
}

func (pt *ProposalKind) Unmarshal(data []byte) error {
	*pt = ProposalKind(data[0])
	return nil
}

func (pt ProposalKind) MarshalJSON() ([]byte, error) {
	return json.Marshal(pt.String())
}

func (pt *ProposalKind) UnmarshalJSON(data []byte) error {
	var s string
	err := json.Unmarshal(data, &s)
	if err != nil {
		return err
	}

	bz2, err := ProposalTypeFromString(s)
	if err != nil {
		return err
	}
	*pt = bz2
	return nil
}

func (pt ProposalKind) String() string {
	switch pt {
	case ProposalTypeText:
		return proposalTypeText
	case ProposalTypeParameterChange:
		return proposalTypeParameterChange
	default:
		return ""
	}
}

// Content defines an interface that a proposal must implement. It contains
// information such as the title and description along with the type and routing
// information for the appropriate handler to process the proposal. Content can
// have additional fields which handle the proposal's Handler.
type Content interface {
	GetTitle() string
	GetDescription() string
	ProposalRoute() string
	ProposalType() string
	ValidateBasic() error
	String() string
}

// Handler defines a function that handles a proposal after it has passed the
// governance process.
type Handler func(ctx sdk.Context, content Content) error
