package heimdalld

import (
	"os"

	"cosmossdk.io/log"
	"github.com/cometbft/cometbft/cmd/cometbft/commands"
	db "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/config"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/server"
	simtestutil "github.com/cosmos/cosmos-sdk/testutil/sims"
	"github.com/cosmos/cosmos-sdk/types/tx/signing"
	"github.com/cosmos/cosmos-sdk/x/auth/tx"
	txmodule "github.com/cosmos/cosmos-sdk/x/auth/tx/config"
	"github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/rs/zerolog"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"

	"github.com/0xPolygon/heimdall-v2/app"
	"github.com/0xPolygon/heimdall-v2/helper"
)

var logger = helper.Logger.With("module", "cmd/heimdalld")

type EncodingConfig struct {
	InterfaceRegistry codectypes.InterfaceRegistry
	Codec             codec.Codec
	TxConfig          client.TxConfig
	Amino             *codec.LegacyAmino
}

// NewRootCmd creates a new root command for heimdalld. It is called once in the
// main function.
func NewRootCmd() *cobra.Command {
	// we "pre"-instantiate the application for getting the injected/configured encoding configuration
	// note, this is not necessary when using app wiring, as depInject can be directly used (see root_v2.go)

	// Since this is only a temp app, we don't need info logs, only warn and error logs.
	tempLogger := log.NewLogger(os.Stdout, log.LevelOption(zerolog.WarnLevel))
	tempApp := app.NewHeimdallApp(tempLogger, db.NewMemDB(), nil, true, simtestutil.NewAppOptionsWithFlagHome(tempDir()))
	defer func() {
		if err := tempApp.Close(); err != nil {
			logger.Error("Failed to close temp app", "error", err)
		}
	}()
	encodingConfig := EncodingConfig{
		InterfaceRegistry: tempApp.InterfaceRegistry(),
		Codec:             tempApp.AppCodec(),
		TxConfig:          tempApp.GetTxConfig(),
		Amino:             tempApp.LegacyAmino(),
	}

	initClientCtx := client.Context{}.
		WithCodec(encodingConfig.Codec).
		WithInterfaceRegistry(encodingConfig.InterfaceRegistry).
		WithTxConfig(encodingConfig.TxConfig).
		WithLegacyAmino(encodingConfig.Amino).
		WithInput(os.Stdin).
		WithAccountRetriever(types.AccountRetriever{}).
		WithHomeDir(app.DefaultNodeHome).
		WithViper("HD") // prefix for env variables

	rootCmd := &cobra.Command{
		Use:           "heimdalld",
		Short:         "Heimdall Daemon (server)",
		SilenceErrors: true,
		PersistentPreRunE: func(cmd *cobra.Command, _ []string) error {
			// set the default command outputs
			cmd.SetOut(cmd.OutOrStdout())
			cmd.SetErr(cmd.ErrOrStderr())

			if err := applyHomeEnvOverride(cmd); err != nil {
				return err
			}

			initClientCtx = initClientCtx.WithCmdContext(cmd.Context())
			initClientCtx, err := client.ReadPersistentCommandFlags(initClientCtx, cmd.Flags())
			if err != nil {
				return err
			}

			initClientCtx, err = config.ReadFromClientConfig(initClientCtx)
			if err != nil {
				return err
			}

			// This needs to go after ReadFromClientConfig, as that function
			// sets the RPC client needed for SIGN_MODE_TEXTUAL. This sign mode
			// is only available if the client is online.
			if !initClientCtx.Offline {
				enabledSignModes := append(tx.DefaultSignModes, signing.SignMode_SIGN_MODE_TEXTUAL)
				txConfigOpts := tx.ConfigOptions{
					EnabledSignModes:           enabledSignModes,
					TextualCoinMetadataQueryFn: txmodule.NewGRPCCoinMetadataQueryFn(initClientCtx),
				}
				txConfig, err := tx.NewTxConfigWithOptions(
					initClientCtx.Codec,
					txConfigOpts,
				)
				if err != nil {
					return err
				}

				initClientCtx = initClientCtx.WithTxConfig(txConfig)
			}

			if err := client.SetCmdClientContextHandler(initClientCtx, cmd); err != nil {
				return err
			}

			customAppTemplate, customAppConfig := initAppConfig()
			customCMTConfig := initCometBFTConfig()

			if cmd.Name() != commands.InitFilesCmd.Name() &&
				cmd.Name() != commands.VersionCmd.Name() &&
				cmd.Name() != MigrateCommand().Name() &&
				cmd.Name() != testnetCmdName {
				helper.InitHeimdallConfig("")
			}

			serverCtx, err := server.InterceptConfigsAndCreateContext(cmd, customAppTemplate, customAppConfig, customCMTConfig)
			if err != nil {
				return err
			}

			// Get log_level from serverCtx.Viper
			logLevelStr := serverCtx.Viper.GetString(flags.FlagLogLevel)

			// Set log_level value to viper
			viper.Set(flags.FlagLogLevel, logLevelStr)

			// A plain level applies globally; a "module:level" list filters per
			// module so debug can be scoped to a single subsystem. A malformed
			// spec warns and falls back to info rather than blocking startup.
			levelOpt := helper.LogLevelOptionOrDefault(logLevelStr, helper.Logger.Warn)

			logNoColor := serverCtx.Viper.GetBool(flags.FlagLogNoColor)
			// Store timestamps with millisecond precision so that log lines carry
			// sub-second granularity. Without this, zerolog stores the timestamp
			// as RFC3339 (second precision) before the ConsoleWriter ever gets a
			// chance to format it, resulting in second-only output.
			// Using 3 decimal places ("000") matches bor's log timestamp format.
			zerolog.TimeFieldFormat = helper.LogTimestampFormat
			logOpts := []log.Option{
				helper.LogFormatOption(serverCtx.Viper.GetString(flags.FlagLogFormat), logNoColor),
				levelOpt,
				log.TimeFormatOption(helper.LogTimestampFormat),
			}

			serverCtx.Logger = log.NewLogger(cmd.OutOrStdout(), logOpts...).With(log.ModuleKey, "server")
			helper.Logger = log.NewLogger(cmd.OutOrStdout(), logOpts...)

			err = helper.SanitizeConfig(serverCtx.Viper, serverCtx.Logger)
			if err != nil {
				return err
			}

			// Set server context
			return server.SetCmdServerContext(cmd, serverCtx)
		},
		PersistentPreRun: func(cmd *cobra.Command, _ []string) {
			// set the default command outputs
			cmd.SetOut(cmd.OutOrStdout())
			cmd.SetErr(cmd.ErrOrStderr())

			helper.InitHeimdallConfig("")
		},
	}

	// adding heimdall configuration flags to the root command
	helper.DecorateWithHeimdallFlags(rootCmd, viper.GetViper(), logger, "main")
	helper.DecorateWithCometBFTFlags(rootCmd, viper.GetViper(), logger, "main")

	initRootCmd(rootCmd, encodingConfig.TxConfig, tempApp.BasicManager, tempApp)

	// add keyring to autocli opts
	autoCliOpts := tempApp.AutoCliOpts()
	autoCliOpts.ClientCtx = initClientCtx

	if err := autoCliOpts.EnhanceRootCommand(rootCmd); err != nil {
		panic(err)
	}

	return rootCmd
}

// homeEnvVar lets operators choose heimdalld's home directory without
// passing --home on every invocation. "HD" is the env prefix svrcmd.Execute
// wires up in main.go, so this is the name operators already expect to work.
const homeEnvVar = "HD_HOME"

// applyHomeEnvOverride sets the --home flag from HD_HOME when the flag
// wasn't passed explicitly on the command line.
//
// cosmos-sdk's client.ReadPersistentCommandFlags is the one consumer this
// guards against: it reads --home via flagSet.GetString(flags.FlagHome)
// directly off the *pflag.FlagSet, gated on flagSet.Changed(flags.FlagHome)
// -- it never touches viper or an env var at all. Left alone, HD_HOME would
// silently do nothing for it. Mutating the flag here (before
// client.ReadPersistentCommandFlags runs, later in this same
// PersistentPreRunE) makes Changed==true so it picks up the override.
//
// No corresponding viper.Set is needed for viper-based readers
// (helper.InitHeimdallConfig, server.InterceptConfigsAndCreateContext's
// fresh *viper.Viper, cometbft's own bindFlagsLoadViper): svrcmd.Execute
// passes "HD" as the env prefix into cmtcli.PrepareBaseCmd, which calls
// viper.SetEnvPrefix("HD") + viper.AutomaticEnv() on the global viper
// singleton via a cobra.OnInitialize hook -- and that hook fires in Cobra's
// own preRun(), strictly before any PersistentPreRunE, including cometbft's
// prepended bindFlagsLoadViper. So by the time bindFlagsLoadViper computes
// `homeDir := viper.GetString(HomeFlag)`, viper's own precedence order
// (Set > changed-pflag > AutomaticEnv > config > kvstore > defaults >
// unchanged-pflag-default-as-last-resort) already resolves HD_HOME through
// the AutomaticEnv tier, since the --home flag is still unchanged at that
// point. bindFlagsLoadViper then pins that already-correct value via its own
// `viper.Set(HomeFlag, homeDir)` before ever reading config.toml, so it also
// never loads config from the pre-override default home. Verified against
// this repo's actual vendored cometbft/cobra/viper wiring, not just read.
// Separately, mutating the flag here also sets Changed==true on the
// underlying pflag.Flag object shared by every viper instance bound to this
// same *pflag.FlagSet (BindPFlags stores a reference, not a snapshot), which
// promotes it to viper's higher-priority changed-pflag tier for any reader
// -- belt and suspenders on top of AutomaticEnv, not a second mechanism to
// maintain.
func applyHomeEnvOverride(cmd *cobra.Command) error {
	if cmd.Flags().Changed(flags.FlagHome) {
		return nil
	}

	home := os.Getenv(homeEnvVar)
	if home == "" {
		return nil
	}

	return cmd.Flags().Set(flags.FlagHome, home)
}
