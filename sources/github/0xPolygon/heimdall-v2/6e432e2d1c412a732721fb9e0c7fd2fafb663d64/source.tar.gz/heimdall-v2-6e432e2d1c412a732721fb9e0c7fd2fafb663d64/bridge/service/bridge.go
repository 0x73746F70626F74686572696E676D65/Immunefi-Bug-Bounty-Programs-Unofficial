package service

import (
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"time"

	"cosmossdk.io/log"
	"cosmossdk.io/x/tx/signing"
	common "github.com/cometbft/cometbft/libs/service"
	rpchttp "github.com/cometbft/cometbft/rpc/client/http"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/codec"
	"github.com/cosmos/cosmos-sdk/codec/address"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	cryptocodec "github.com/cosmos/cosmos-sdk/crypto/codec"
	authTypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/cosmos/gogoproto/proto"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
	"golang.org/x/sync/errgroup"

	"github.com/0xPolygon/heimdall-v2/app"
	"github.com/0xPolygon/heimdall-v2/bridge/broadcaster"
	"github.com/0xPolygon/heimdall-v2/bridge/listener"
	"github.com/0xPolygon/heimdall-v2/bridge/processor"
	"github.com/0xPolygon/heimdall-v2/bridge/queue"
	"github.com/0xPolygon/heimdall-v2/bridge/util"
	"github.com/0xPolygon/heimdall-v2/helper"
	checkpointTypes "github.com/0xPolygon/heimdall-v2/x/checkpoint/types"
	clerkTypes "github.com/0xPolygon/heimdall-v2/x/clerk/types"
	milestoneTypes "github.com/0xPolygon/heimdall-v2/x/milestone/types"
	stakeTypes "github.com/0xPolygon/heimdall-v2/x/stake/types"
	topupTypes "github.com/0xPolygon/heimdall-v2/x/topup/types"
)

const (
	waitDuration  = 10 * time.Second
	borChainIDKey = "bor-chain-id"
	logsTypeKey   = "logs-type"
)

func logger() log.Logger { return helper.Logger.With("module", "bridge/service") }

// AdjustDBValue sets/normalizes viper-config for bridge runtime based on flags present on root/start cmd
func AdjustDBValue(cmd *cobra.Command) {
	cometBftNode, _ := cmd.Flags().GetString(helper.CometBFTNodeFlag)
	withHeimdallConfigValue, _ := cmd.Flags().GetString(helper.WithHeimdallConfigFlag)
	bridgeDBValue, _ := cmd.Flags().GetString(util.BridgeDBFlag)
	borChainIDValue, _ := cmd.Flags().GetString(borChainIDKey)
	logsTypeValue, _ := cmd.Flags().GetString(logsTypeKey)

	// default bridge storage dir: <home>/bridge/storage
	if bridgeDBValue == "" {
		home := viper.GetString(flags.FlagHome)
		if home == "" {
			home = app.DefaultNodeHome
		}
		bridgeDBValue = filepath.Join(home, "bridge", "storage")
	}

	// set to viper
	viper.Set(helper.CometBFTNodeFlag, cometBftNode)
	viper.Set(helper.WithHeimdallConfigFlag, withHeimdallConfigValue)
	viper.Set(util.BridgeDBFlag, bridgeDBValue)
	if borChainIDValue != "" {
		viper.Set(borChainIDKey, borChainIDValue)
	}
	if logsTypeValue != "" {
		viper.Set(logsTypeKey, logsTypeValue)
	}
}

// StartWithCtx starts the bridge runtime as a side service of heimdalld and shuts down gracefully.
func StartWithCtx(ctx context.Context, clientCtx client.Context) error {
	// set up the codec and registry
	cdc, err := makeCodec()
	if err != nil {
		panic(err)
	}
	clientCtx = attachCodecIfMissing(clientCtx, cdc)

	// setup queue and CometBFT RPC
	qc := queue.NewQueueConnector(helper.GetConfig().AmqpURL)

	httpClient, err := createAndStartRPC(helper.GetConfig().CometBFTRPCUrl)
	if err != nil {
		logger().Error("Bridge: error connecting to server", "err", err)
		return err
	}

	// cleanup runs on early-return errors; runServices owns shutdown in the happy path
	earlyReturn := true
	defer func() {
		if !earlyReturn {
			return
		}
		qc.StopWorker()
		if stopErr := httpClient.Stop(); stopErr != nil {
			logger().Error("Bridge: httpClient.Stop failed during early cleanup", "err", stopErr)
		}
	}()

	// set chain ID
	chainID, err := resolveChainID(ctx, clientCtx)
	if err != nil {
		logger().Error("Bridge: error while determining chain ID", "err", err)
		return err
	}
	clientCtx = clientCtx.WithChainID(chainID)
	clientCtx.BroadcastMode = flags.BroadcastAsync

	// wait until the node is synced
	if err := waitUntilSynced(ctx, clientCtx, waitDuration); err != nil {
		// context canceled while waiting is not an error for shutdown
		return err
	}

	// wire bridge services: register tasks before starting worker to avoid race
	txBroadcaster := broadcaster.NewTxBroadcaster(cdc, ctx, clientCtx, nil)
	listenerService := listener.NewListenerService(cdc, qc, httpClient)
	processorService := processor.NewProcessorService(cdc, qc, httpClient, txBroadcaster)
	processorService.RegisterTasks()
	qc.StartWorker()

	services := []common.Service{
		listenerService,
		processorService,
	}

	// run services and handle a graceful shutdown
	earlyReturn = false
	return runServices(ctx, services, httpClient, qc)
}

// makeCodec creates a new codec with the necessary interface registry and registers all required interfaces.
func makeCodec() (codec.Codec, error) {
	ir, err := codectypes.NewInterfaceRegistryWithOptions(codectypes.InterfaceRegistryOptions{
		ProtoFiles: proto.HybridResolver,
		SigningOptions: signing.Options{
			AddressCodec:          address.HexCodec{},
			ValidatorAddressCodec: address.HexCodec{},
		},
	})
	if err != nil {
		return nil, fmt.Errorf("bridge: interface registry: %w", err)
	}

	cryptocodec.RegisterInterfaces(ir)
	authTypes.RegisterInterfaces(ir)
	checkpointTypes.RegisterInterfaces(ir)
	milestoneTypes.RegisterInterfaces(ir)
	clerkTypes.RegisterInterfaces(ir)
	stakeTypes.RegisterInterfaces(ir)
	topupTypes.RegisterInterfaces(ir)

	return codec.NewProtoCodec(ir), nil
}

// attachCodecIfMissing checks if the client context has a codec set, and if not, attaches the provided codec.
func attachCodecIfMissing(clientCtx client.Context, cdc codec.Codec) client.Context {
	if clientCtx.Codec == nil {
		return clientCtx.WithCodec(cdc)
	}
	return clientCtx
}

// createAndStartRPC creates and starts a CometBFT HTTP client for the given RPC URL.
func createAndStartRPC(rpcURL string) (*rpchttp.HTTP, error) {
	httpClient, err := rpchttp.New(rpcURL, "/websocket")
	if err != nil {
		return nil, fmt.Errorf("bridge: creating cometbft http client: %w", err)
	}
	if err := httpClient.Start(); err != nil {
		return nil, fmt.Errorf("bridge: starting cometbft http client: %w", err)
	}
	return httpClient, nil
}

// resolveChainID retrieves the chain ID from the client context or node status.
func resolveChainID(ctx context.Context, clientCtx client.Context) (string, error) {
	if cid := clientCtx.ChainID; cid != "" {
		logger().Info("Bridge: chainID set in clientCtx", "chainId", cid)
		return cid, nil
	}

	logger().Info("Bridge: chainID is empty in clientCtx at bridge startup, fetching from node status")

	nodeStatus, err := helper.GetNodeStatus(ctx, clientCtx)
	if err != nil {
		return "", fmt.Errorf("bridge: fetching node status: %w", err)
	}
	if nodeStatus.NodeInfo.Network == "" {
		return "", errors.New("bridge: network is empty in node status, cannot determine chain ID")
	}

	logger().Info("Bridge: chainID fetched from node status", "chainId", nodeStatus.NodeInfo.Network)
	return nodeStatus.NodeInfo.Network, nil
}

// waitUntilSynced checks if the node is synced and waits until it is up to date.
func waitUntilSynced(ctx context.Context, clientCtx client.Context, d time.Duration) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(d):
			if !util.IsCatchingUp(ctx, clientCtx) {
				logger().Info("Bridge: node up to date, starting bridge services")
				return nil
			}
			logger().Info("Bridge: waiting for heimdall to be synced")
		}
	}
}

// runServices starts all the bridge services and handles graceful shutdown.
// Uses errgroup.WithContext so that a service Start() failure cancels the
// group context, which unblocks the shutdown controller and other goroutines.
func runServices(ctx context.Context, services []common.Service, httpClient stopper, qc workerStopper) error {
	g, gCtx := errgroup.WithContext(ctx)

	// start each service
	for _, svc := range services {
		s := svc
		g.Go(func() error {
			if err := s.Start(); err != nil {
				logger().Error("Bridge: service.Start failed", "err", err)
				return err
			}
			select {
			case <-s.Quit():
			case <-gCtx.Done():
			}
			return nil
		})
	}

	// shutdown controller: triggers on parent ctx cancellation OR first goroutine error
	g.Go(func() error {
		<-gCtx.Done()
		// mutator-disable-next-line operator log, removing it changes no behavior
		logger().Info("Bridge: received stop signal - stopping all heimdall bridge services")
		return stopBridge(services, httpClient, qc, closeBridgeResources)
	})

	if err := g.Wait(); err != nil {
		// mutator-disable-next-line operator log, err is returned below
		logger().Error("Bridge: stopped", "err", err)
		return err
	}
	return nil
}

// stopper and workerStopper are the minimal behaviors stopBridge needs from
// the comet RPC client and the queue connector, so the shutdown path is
// unit-testable with fakes.
type (
	stopper       interface{ Stop() error }
	workerStopper interface{ StopWorker() }
)

// closeBridgeResources runs cleanup that should happen even when an earlier
// service stop returns an error.
func closeBridgeResources() {
	// mutator-disable-next-line statement-deletion shutdown cleanup
	util.CloseBridgeDBInstance()
	// mutator-disable-next-line statement-deletion shutdown cleanup
	helper.CloseBorChainClients()
}

// stopBridge tears down the bridge services, the comet client, the DB, and the
// Bor failover clients. Called by runServices's shutdown controller once the
// group context is cancelled.
func stopBridge(services []common.Service, httpClient stopper, qc workerStopper, cleanup func()) error {
	defer cleanup()

	qc.StopWorker()

	for _, s := range services {
		if s.IsRunning() {
			if err := s.Stop(); err != nil {
				// mutator-disable-next-line operator log, err is returned below
				logger().Error("Bridge: service.Stop failed", "err", err)
				return err
			}
		}
	}

	if err := httpClient.Stop(); err != nil {
		// mutator-disable-next-line operator log, err is returned below
		logger().Error("Bridge: httpClient.Stop failed", "err", err)
		return err
	}

	return nil
}
