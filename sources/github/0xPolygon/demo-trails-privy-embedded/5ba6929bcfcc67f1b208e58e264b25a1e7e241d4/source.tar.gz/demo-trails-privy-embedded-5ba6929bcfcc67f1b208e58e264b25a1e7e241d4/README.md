# Trails x Privy Embedded

This demo shows a dedicated headless Trails SDK flow with Privy embedded wallets. Users connect through Privy, select available assets, request a quote, and execute the route directly in this app.

## Quickstart

```bash
npm install
cp .env.example .env.local
npm run dev
```

Local app runs on [http://localhost:4444](http://localhost:4444).

## Privy embedded wallet setup

Set these values in `.env.local`:

- `VITE_PRIVY_APP_ID`
- `VITE_PRIVY_CLIENT_ID`
- `VITE_TRAILS_API_KEY`

Optional:

- `VITE_DEFAULT_CHAIN_ID`
- `VITE_TRAILS_API_URL` (defaults to `https://trails-api.sequence.app`)

If keys are missing, the app still runs but quoting and execution stay unavailable.

For Google login in Privy:
- Enable `Google` as a login method in your Privy app dashboard.
- Ensure your deployed origin and local dev origin (`http://localhost:4444`) are both allowed in Privy.
- Ensure your Google provider is fully configured in Privy (OAuth client setup complete).

## Dev-test loop

```bash
npm run dev
npm run test:worker
npm run test:e2e
# or
npm run test:e2e:headed
```

Playwright screenshots are written to `test-results/`.

## Deploy

```bash
npm run build
wrangler deploy
```

Worker serves static assets from `dist/client` through the `ASSETS` binding.
