import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { cloudflare } from '@cloudflare/vite-plugin';

export default defineConfig({
  plugins: [react(), cloudflare()],
  resolve: {
    dedupe: ['react', 'react-dom', '@tanstack/react-query', '@tanstack/query-core']
  },
  server: {
    host: 'localhost',
    port: 4444
  },
  preview: {
    host: 'localhost',
    port: 4444
  }
});
