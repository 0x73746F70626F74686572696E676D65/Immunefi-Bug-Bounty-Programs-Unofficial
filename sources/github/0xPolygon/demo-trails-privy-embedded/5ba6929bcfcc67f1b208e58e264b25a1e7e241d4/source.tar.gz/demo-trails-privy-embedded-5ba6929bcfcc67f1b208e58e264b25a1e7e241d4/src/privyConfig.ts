import type { PrivyClientConfig } from '@privy-io/react-auth';
import { createConfig } from '@privy-io/wagmi';
import { getAllChains } from '0xtrails';
import { http } from 'wagmi';
import { base, type Chain } from 'wagmi/chains';

export const privyAppId = import.meta.env.VITE_PRIVY_APP_ID?.trim() ?? '';
export const privyClientId = import.meta.env.VITE_PRIVY_CLIENT_ID?.trim() ?? '';
const defaultChainId = Number(import.meta.env.VITE_DEFAULT_CHAIN_ID ?? '8453');

const wagmiChains = getAllChains() as [Chain, ...Chain[]];
const supportedChains: Chain[] = [...wagmiChains];
const chainById = new Map(wagmiChains.map((chain) => [chain.id, chain] as const));

const defaultChain = chainById.get(defaultChainId) ?? base;

export const hasPrivyConfig = privyAppId.length > 0 && privyClientId.length > 0;

export const privyWagmiConfig = createConfig({
  chains: wagmiChains,
  transports: Object.fromEntries(wagmiChains.map((chain) => [chain.id, http()]))
});

export const privyConfig: PrivyClientConfig = {
  loginMethods: ['email', 'google'],
  appearance: {
    theme: 'light',
    accentColor: '#3f5e8c',
    landingHeader: 'Trails x Privy Embedded'
  },
  embeddedWallets: {
    ethereum: {
      createOnLogin: 'users-without-wallets'
    },
    showWalletUIs: true
  },
  supportedChains,
  defaultChain
};
