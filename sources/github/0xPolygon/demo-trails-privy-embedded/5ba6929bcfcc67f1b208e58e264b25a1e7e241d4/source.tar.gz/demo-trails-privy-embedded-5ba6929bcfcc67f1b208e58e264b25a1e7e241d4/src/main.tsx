import React from 'react';
import ReactDOM from 'react-dom/client';
import { TrailsProvider } from '0xtrails';
import { PrivyProvider } from '@privy-io/react-auth';
import { WagmiProvider } from '@privy-io/wagmi';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Buffer } from 'buffer';
import App from './App';
import {
  hasPrivyConfig,
  privyAppId,
  privyClientId,
  privyConfig,
  privyWagmiConfig
} from './privyConfig';
import './styles.css';

if (!globalThis.Buffer) {
  (globalThis as typeof globalThis & { Buffer: typeof Buffer }).Buffer = Buffer;
}

const queryClient = new QueryClient();
const trailsApiKey = import.meta.env.VITE_TRAILS_API_KEY?.trim() ?? '';
const trailsApiUrl = import.meta.env.VITE_TRAILS_API_URL?.trim() ?? '';

type BootBoundaryState = {
  hasError: boolean;
  errorMessage?: string;
};

class BootBoundary extends React.Component<{ children: React.ReactNode }, BootBoundaryState> {
  state: BootBoundaryState = { hasError: false };

  private static toFriendlyMessage(error: unknown) {
    const rawMessage = error instanceof Error ? error.message : String(error);
    const normalized = rawMessage.toLowerCase();

    if (normalized.includes('missing_or_invalid_privy_app_id')) {
      return 'Privy App ID is invalid for this project.'
    }

    if (
      normalized.includes('missing_or_invalid_privy_account_id') ||
      normalized.includes('client id')
    ) {
      return 'Privy Client ID is invalid for this app.'
    }

    if (normalized.includes('origin') || normalized.includes('domain')) {
      return 'This localhost origin is not allowed in your Privy app settings.'
    }

    return rawMessage;
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  override componentDidCatch(error: unknown) {
    console.error('Boot error:', error);
    this.setState({
      errorMessage: BootBoundary.toFriendlyMessage(error)
    });
  }

  override render() {
    if (this.state.hasError) {
      const detail = this.state.errorMessage
        ? ` ${this.state.errorMessage}`
        : '';

      return (
        <QueryClientProvider client={queryClient}>
          <TrailsProvider
            config={{
              trailsApiKey,
              ...(trailsApiUrl ? { trailsApiUrl } : {})
            }}
          >
            <App
              walletEnabled={false}
              walletDisabledReason={`Privy failed to initialize.${detail} Check App ID, Client ID, and allowed localhost origins, then restart the app.`}
            />
          </TrailsProvider>
        </QueryClientProvider>
      );
    }

    return this.props.children;
  }
}

const app = (
  <QueryClientProvider client={queryClient}>
    <TrailsProvider
      config={{
        trailsApiKey,
        ...(trailsApiUrl ? { trailsApiUrl } : {})
      }}
    >
      {hasPrivyConfig ? (
        <PrivyProvider
          appId={privyAppId}
          {...(privyClientId ? { clientId: privyClientId } : {})}
          config={privyConfig}
        >
          <WagmiProvider config={privyWagmiConfig}>
            <App walletEnabled />
          </WagmiProvider>
        </PrivyProvider>
      ) : (
        <App walletEnabled={false} />
      )}
    </TrailsProvider>
  </QueryClientProvider>
);

ReactDOM.createRoot(document.getElementById('root')!).render(<BootBoundary>{app}</BootBoundary>);
