import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { usePrivy, useWallets } from '@privy-io/react-auth';
import { useSetActiveWallet } from '@privy-io/wagmi';
import { useAccount, useWalletClient } from 'wagmi';
import { isAddress, parseUnits } from 'viem';
import {
  getSupportedChains,
  getSupportedTokens,
  TradeType,
  useQuote,
  useTokenBalances,
  type Chain as TrailsChain,
  type Quote as TrailsQuote,
  type TransactionState as TrailsTransactionState,
  type Token as TrailsToken
} from '0xtrails';

type AppProps = {
  walletEnabled: boolean;
  walletDisabledReason?: string;
};

type SetupNotice = {
  id: string;
  tone: 'error' | 'warn';
  title: string;
  detail: string;
};

type Draft = {
  amount: number;
  fromToken: string;
  toToken: string;
  fromChain: number;
  toChain: number;
  slippagePercent: number;
};

type SupportedData = {
  chains: TrailsChain[];
  tokens: TrailsToken[];
};

type QuoteRequestState = {
  amountAtomic: string;
  inputKey: string;
};

type ExecuteResultState = {
  originTxHash?: string | null;
  originExplorerUrl?: string | null;
  destinationTxHash?: string | null;
  destinationExplorerUrl?: string | null;
  totalCompletionSeconds?: number;
};

type DeliveryStopState = 'queued' | 'pending' | 'confirmed' | 'failed' | 'aborted';

type DeliveryPhase =
  | 'idle'
  | 'starting'
  | 'awaiting_signature'
  | 'signature_confirmed'
  | 'submitting_origin'
  | 'routing'
  | 'completed'
  | 'failed';

type DeliveryStop = {
  id: string;
  title: string;
  detail: string;
  state: DeliveryStopState;
  transactionHash?: string;
  explorerUrl?: string;
};

type IconOption = {
  value: string;
  label: string;
  iconUrl?: string;
};

const trailsApiKey = import.meta.env.VITE_TRAILS_API_KEY?.trim() ?? '';
const trailsApiUrl = import.meta.env.VITE_TRAILS_API_URL?.trim() ?? 'https://trails-api.sequence.app';
const privyAppId = import.meta.env.VITE_PRIVY_APP_ID?.trim() ?? '';
const privyClientId = import.meta.env.VITE_PRIVY_CLIENT_ID?.trim() ?? '';
const rawDefaultChainId = import.meta.env.VITE_DEFAULT_CHAIN_ID?.trim() ?? '';

function truncateAddress(address: string) {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function getChainLogoUrl(chainId: number) {
  return `https://assets.sequence.info/images/networks/large/${chainId}.webp`;
}

function parseDefaultChainId(value: string) {
  if (!value) {
    return 8453;
  }

  const chainId = Number(value);
  return Number.isInteger(chainId) ? chainId : 8453;
}

function getUniqueTokensForChain(tokens: TrailsToken[], chainId: number) {
  const uniqueBySymbol = new Map<string, TrailsToken>();

  for (const token of tokens) {
    if (token.chainId !== chainId || !token.symbol || !token.contractAddress) {
      continue;
    }

    if (!uniqueBySymbol.has(token.symbol)) {
      uniqueBySymbol.set(token.symbol, token);
    }
  }

  return Array.from(uniqueBySymbol.values());
}

function getTokenKey(chainId: number, contractAddress: string) {
  return `${chainId}:${contractAddress.toLowerCase()}`;
}

function getTokenKeySafe(chainId?: number, contractAddress?: string) {
  if (!chainId || !contractAddress) {
    return null;
  }
  return getTokenKey(chainId, contractAddress);
}

function formatPriceImpact(value?: string | null) {
  if (!value) {
    return '0%';
  }

  return value.endsWith('%') ? value : `${value}%`;
}

function formatMoneyDisplay(value?: string | null) {
  if (!value || value.trim().length === 0) {
    return '—';
  }
  return value;
}

function normalizeAmountForWidget(value?: string | null) {
  if (!value) {
    return '0';
  }

  return value.replace(/,/g, '').trim();
}

function formatAvailableBalance(value: number) {
  if (!Number.isFinite(value)) {
    return '0';
  }
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: 6 }).format(value);
}

function powerOfTenStepToString(exponent: number) {
  if (exponent <= 0) {
    return String(10 ** -exponent);
  }
  return `0.${'0'.repeat(exponent - 1)}1`;
}

function getAmountStepFromBalance(balance: number, tokenDecimals?: number) {
  if (!Number.isFinite(balance) || balance <= 0) {
    return '0.01';
  }

  const targetStep = balance / 1000;
  if (!Number.isFinite(targetStep) || targetStep <= 0) {
    return '0.01';
  }

  const maxExponent = Math.max(0, Math.min(18, tokenDecimals ?? 8));
  const minExponent = -6;
  const rawExponent = -Math.log10(targetStep);

  const candidateExponents = Array.from(
    new Set([Math.floor(rawExponent), Math.round(rawExponent), Math.ceil(rawExponent)])
  ).map((exponent) => Math.max(minExponent, Math.min(maxExponent, exponent)));

  let bestExponent = candidateExponents[0];
  let bestDistance = Math.abs(10 ** -bestExponent - targetStep);

  for (const exponent of candidateExponents.slice(1)) {
    const step = 10 ** -exponent;
    const distance = Math.abs(step - targetStep);
    if (distance < bestDistance) {
      bestDistance = distance;
      bestExponent = exponent;
    }
  }

  return powerOfTenStepToString(bestExponent);
}

function toAtomicAmount(amount: number, decimals: number) {
  if (!Number.isFinite(amount) || amount <= 0) {
    return null;
  }

  try {
    return parseUnits(String(amount), decimals).toString();
  } catch {
    return null;
  }
}

function toErrorMessage(error: unknown) {
  if (error instanceof Error && error.message.trim()) {
    return error.message;
  }
  if (typeof error === 'string' && error.trim()) {
    return error;
  }
  return 'Could not execute this trail.';
}

function IconSelect({
  value,
  options,
  onChange,
  ariaLabel,
  disabled = false
}: {
  value: string;
  options: IconOption[];
  onChange: (nextValue: string) => void;
  ariaLabel: string;
  disabled?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [brokenIconUrls, setBrokenIconUrls] = useState<Record<string, true>>({});
  const rootRef = useRef<HTMLDivElement | null>(null);
  const selectedOption = options.find((option) => option.value === value) ?? options[0] ?? null;
  const isDisabled = disabled || options.length === 0;

  const markIconAsBroken = useCallback((iconUrl?: string) => {
    if (!iconUrl) {
      return;
    }
    setBrokenIconUrls((current) => (current[iconUrl] ? current : { ...current, [iconUrl]: true }));
  }, []);

  const renderOptionIcon = useCallback(
    (option: IconOption) => {
      const iconUrl = option.iconUrl;
      const isBroken = !iconUrl || Boolean(brokenIconUrls[iconUrl]);
      const fallbackLetter = option.label.trim().charAt(0).toUpperCase() || '?';

      if (isBroken) {
        return (
          <span className="icon-select-icon icon-select-icon-fallback" aria-hidden="true">
            {fallbackLetter}
          </span>
        );
      }

      return (
        <img
          src={iconUrl}
          alt=""
          className="icon-select-icon"
          onError={(event) => {
            const target = event.currentTarget;
            const currentSrc = target.currentSrc || target.src || iconUrl;
            if (!target.dataset.fallbackApplied && currentSrc.endsWith('.webp')) {
              target.dataset.fallbackApplied = 'true';
              target.src = currentSrc.replace(/\.webp($|\?)/, '.png$1');
              return;
            }
            markIconAsBroken(iconUrl);
          }}
        />
      );
    },
    [brokenIconUrls, markIconAsBroken]
  );

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    const onPointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const onEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onEscape);

    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onEscape);
    };
  }, [isOpen]);

  return (
    <div
      className="icon-select"
      ref={rootRef}
      onMouseDown={(event) => event.stopPropagation()}
      onClick={(event) => event.stopPropagation()}
    >
      <button
        type="button"
        className="icon-select-trigger"
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-label={ariaLabel}
        disabled={isDisabled}
        onClick={(event) => {
          event.preventDefault();
          event.stopPropagation();
          setIsOpen((current) => !current);
        }}
      >
        <span className="icon-select-value">
          {selectedOption ? renderOptionIcon(selectedOption) : null}
          <span className="icon-select-label">{selectedOption?.label ?? 'please wait'}</span>
        </span>
        <span className="icon-select-chevron" aria-hidden="true">
          ▾
        </span>
      </button>

      {isOpen && !isDisabled ? (
        <ul role="listbox" className="icon-select-menu" aria-label={ariaLabel}>
          {options.map((option) => (
            <li key={option.value}>
              <button
                type="button"
                role="option"
                aria-selected={option.value === value}
                className="icon-select-option"
                onMouseDown={(event) => {
                  event.preventDefault();
                  event.stopPropagation();
                }}
                onClick={(event) => {
                  event.preventDefault();
                  event.stopPropagation();
                  onChange(option.value);
                  setIsOpen(false);
                }}
              >
                {renderOptionIcon(option)}
                <span className="icon-select-label">{option.label}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function getSetupNotices(): SetupNotice[] {
  const notices: SetupNotice[] = [];

  if (!privyAppId) {
    notices.push({
      id: 'missing-privy-app-id',
      tone: 'error',
      title: 'Embedded wallet sign-in is not set up yet.',
      detail: 'Add VITE_PRIVY_APP_ID in your .env file.'
    });
  }

  if (!privyClientId) {
    notices.push({
      id: 'missing-privy-client-id',
      tone: 'warn',
      title: 'Privy client ID is missing.',
      detail: 'Add VITE_PRIVY_CLIENT_ID in your .env file to complete setup.'
    });
  }

  if (!trailsApiKey) {
    notices.push({
      id: 'missing-trails-api-key',
      tone: 'warn',
      title: 'Trails quote API key is missing.',
      detail: 'Add VITE_TRAILS_API_KEY in your .env file.'
    });
  }

  if (rawDefaultChainId) {
    const parsedChainId = Number(rawDefaultChainId);
    if (!Number.isInteger(parsedChainId) || parsedChainId <= 0) {
      notices.push({
        id: 'invalid-default-chain-id',
        tone: 'warn',
        title: 'Default network setting was not recognized.',
        detail: 'Use a positive integer for VITE_DEFAULT_CHAIN_ID.'
      });
    }
  }

  return notices;
}

function WalletEnabledApp() {
  const { address, isConnected } = useAccount();
  const { data: walletClient } = useWalletClient();
  const { ready, authenticated, login, logout } = usePrivy();
  const { wallets } = useWallets();
  const { setActiveWallet } = useSetActiveWallet();

  useEffect(() => {
    if (!authenticated || wallets.length === 0) {
      return;
    }

    const embeddedWallet =
      wallets.find(
        (wallet) => wallet.walletClientType === 'privy' || wallet.walletClientType === 'privy-v2'
      ) ?? wallets[0];

    setActiveWallet(embeddedWallet).catch(() => undefined);
  }, [authenticated, setActiveWallet, wallets]);

  return (
    <Dashboard
      isConnected={isConnected}
      address={address}
      walletClient={walletClient}
      walletEnabled
      authReady={ready}
      authenticated={authenticated}
      authActionLabel={authenticated ? 'Disconnect' : 'Connect'}
      onAuthAction={authenticated ? logout : login}
    />
  );
}

function Dashboard({
  walletEnabled,
  isConnected,
  address,
  walletClient,
  authReady,
  authenticated,
  authActionLabel,
  onAuthAction,
  walletDisabledReason
}: {
  walletEnabled: boolean;
  isConnected: boolean;
  address?: string;
  walletClient?: unknown;
  authReady: boolean;
  authenticated: boolean;
  authActionLabel?: string;
  onAuthAction?: () => void;
  walletDisabledReason?: string;
}) {
  const [supported, setSupported] = useState<SupportedData>({ chains: [], tokens: [] });
  const [quoteRequest, setQuoteRequest] = useState<QuoteRequestState | null>(null);
  const [lastResolvedQuote, setLastResolvedQuote] = useState<TrailsQuote | null>(null);
  const [hasPrimedQuoteFlow, setHasPrimedQuoteFlow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [executeError, setExecuteError] = useState<string | null>(null);
  const [executeResult, setExecuteResult] = useState<ExecuteResultState | null>(null);
  const [isExecutingTrail, setIsExecutingTrail] = useState(false);
  const [isExecutionFocused, setIsExecutionFocused] = useState(false);
  const [executionStates, setExecutionStates] = useState<TrailsTransactionState[]>([]);
  const [deliveryPhase, setDeliveryPhase] = useState<DeliveryPhase>('idle');
  const [copyToast, setCopyToast] = useState<string | null>(null);
  const [pendingQuoteVisualPayloadKey, setPendingQuoteVisualPayloadKey] = useState<string | null>(null);
  const lastQuoteTriggerAtRef = useRef(0);
  const autoQuoteTimerRef = useRef<number | null>(null);
  const lastInputChangedAtRef = useRef(0);
  const lastAutoQuotePayloadRef = useRef<string | null>(null);
  const lastObservedAutoInputPayloadRef = useRef<string | null>(null);
  const pendingAutoQuotePayloadRef = useRef<string | null>(null);
  const pendingAutoQuoteStartedRef = useRef(false);
  const pendingQuoteVisualLoadingStartedRef = useRef(false);
  const pendingQuoteVisualPayloadKeyRef = useRef<string | null>(null);
  const pendingQuoteVisualSetAtRef = useRef(0);
  const autoQuoteScheduleIdRef = useRef(0);
  const quoteRequestRef = useRef<QuoteRequestState | null>(null);
  const [useAlternateRecipient, setUseAlternateRecipient] = useState(false);
  const [alternateRecipient, setAlternateRecipient] = useState('');

  const setupNotices = useMemo(() => {
    const notices = getSetupNotices();

    if (!walletEnabled && walletDisabledReason) {
      notices.unshift({
        id: 'wallet-disabled-runtime',
        tone: 'error',
        title: 'Embedded wallet could not start.',
        detail: walletDisabledReason
      });
    }

    return notices;
  }, [walletDisabledReason, walletEnabled]);

  const [draft, setDraft] = useState<Draft>({
    amount: 100,
    fromToken: 'USDC',
    toToken: 'ETH',
    fromChain: 8453,
    toChain: 42161,
    slippagePercent: 0.4
  });

  const normalizedRecipientInput = useMemo(() => alternateRecipient.trim(), [alternateRecipient]);
  const recipientAddress = useMemo(
    () => (useAlternateRecipient ? normalizedRecipientInput : (address ?? '')),
    [address, normalizedRecipientInput, useAlternateRecipient]
  );
  const alternateRecipientIsValid = useMemo(
    () => !useAlternateRecipient || isAddress(normalizedRecipientInput),
    [normalizedRecipientInput, useAlternateRecipient]
  );
  const recipientIsValid = useMemo(
    () => (useAlternateRecipient ? alternateRecipientIsValid : (address ? isAddress(address) : false)),
    [address, alternateRecipientIsValid, useAlternateRecipient]
  );
  const indexedAddress = useMemo(() => (address && isAddress(address) ? address : null), [address]);
  const { sortedTokens: indexedTokens, isLoadingBalances } = useTokenBalances(indexedAddress);
  const connectedWithAddress = Boolean(isConnected && address);
  const isLoggedIn = Boolean(walletEnabled && authenticated && address);
  const isInputsLocked = !isLoggedIn;
  const showPrimaryConnectCta = Boolean(walletEnabled && !isLoggedIn);
  const showHeaderActions = Boolean((isConnected && address) || walletEnabled);
  const showExecutionFocus = isExecutionFocused || isExecutingTrail;

  const draftInputKey = useMemo(
    () =>
      [
        draft.amount,
        draft.fromToken,
        draft.toToken,
        draft.fromChain,
        draft.toChain,
        draft.slippagePercent,
        recipientAddress.toLowerCase()
      ].join('|'),
    [draft, recipientAddress]
  );

  useEffect(() => {
    let active = true;

    Promise.all([
      getSupportedChains(),
      getSupportedTokens({ trailsApiKey, trailsApiUrl })
    ])
      .then(([chains, tokens]) => {
        if (!active) {
          return;
        }

        const validTokens = tokens.filter((token) => Boolean(token.chainId) && Boolean(token.contractAddress));
        setSupported({ chains, tokens: validTokens });

        if (chains.length > 0 && validTokens.length > 0) {
          setDraft((current) => {
            const parsedDefaultChainId = parseDefaultChainId(rawDefaultChainId);
            const fallbackFromChain = chains.find((chain) => chain.id === 8453)?.id ?? chains[0]?.id ?? 8453;
            const nextFromChain =
              chains.find((chain) => chain.id === parsedDefaultChainId)?.id ?? fallbackFromChain;

            const fallbackToChain =
              chains.find((chain) => chain.id === 42161 && chain.id !== nextFromChain)?.id ??
              chains.find((chain) => chain.id !== nextFromChain)?.id ??
              nextFromChain;

            const fromTokens = getUniqueTokensForChain(validTokens, nextFromChain);
            const toTokens = getUniqueTokensForChain(validTokens, fallbackToChain);

            const nextFromToken =
              fromTokens.find((token) => token.symbol === 'USDC')?.symbol ??
              fromTokens[0]?.symbol ??
              current.fromToken;

            const nextToToken =
              toTokens.find((token) => token.symbol === 'ETH')?.symbol ??
              toTokens[0]?.symbol ??
              current.toToken;

            return {
              ...current,
              fromChain: nextFromChain,
              toChain: fallbackToChain,
              fromToken: nextFromToken,
              toToken: nextToToken
            };
          });
        }
      })
      .catch((requestError) => {
        if (!active) {
          return;
        }

        setError(requestError instanceof Error ? requestError.message : 'Could not load Trails market data.');
      });

    return () => {
      active = false;
    };
  }, []);

  const supportedTokenKeys = useMemo(() => {
    const keys = new Set<string>();
    for (const token of supported.tokens) {
      if (!token.chainId || !token.contractAddress) {
        continue;
      }
      keys.add(getTokenKey(token.chainId, token.contractAddress));
    }
    return keys;
  }, [supported.tokens]);

  const indexedSupportedTokens = useMemo(
    () =>
      indexedTokens.filter(
        (token) => {
          const tokenKey = getTokenKeySafe(token.chainId, token.contractAddress);
          return tokenKey ? supportedTokenKeys.has(tokenKey) : false;
        }
      ),
    [indexedTokens, supportedTokenKeys]
  );

  const indexedSupportedTokenKeys = useMemo(
    () =>
      new Set(
        indexedSupportedTokens
          .map((token) => getTokenKeySafe(token.chainId, token.contractAddress))
          .filter((key): key is string => Boolean(key))
      ),
    [indexedSupportedTokens]
  );

  const indexedBalanceByTokenKey = useMemo(() => {
    const balances = new Map<string, string>();
    for (const token of indexedSupportedTokens) {
      const tokenKey = getTokenKeySafe(token.chainId, token.contractAddress);
      const balanceDisplay = token.balanceDisplay || token.balanceFormatted || token.balance;
      if (!tokenKey || !balanceDisplay) {
        continue;
      }
      balances.set(tokenKey, balanceDisplay);
    }
    return balances;
  }, [indexedSupportedTokens]);

  const indexedBalanceNumberByTokenKey = useMemo(() => {
    const balances = new Map<string, number>();
    for (const token of indexedSupportedTokens) {
      const tokenKey = getTokenKeySafe(token.chainId, token.contractAddress);
      const balanceRaw = token.balanceFormatted || token.balanceDisplay || token.balance;
      if (!tokenKey || !balanceRaw) {
        continue;
      }
      const parsed = Number(balanceRaw.replace(/,/g, ''));
      if (Number.isFinite(parsed) && parsed >= 0) {
        balances.set(tokenKey, parsed);
      }
    }
    return balances;
  }, [indexedSupportedTokens]);

  const hasIndexedFromTokens = connectedWithAddress && indexedSupportedTokens.length > 0;
  const isFromSelectorLoading = connectedWithAddress && isLoadingBalances;

  const indexedFromChainIds = useMemo(() => {
    if (!hasIndexedFromTokens) {
      return new Set<number>();
    }
    return new Set(indexedSupportedTokens.map((token) => token.chainId).filter((chainId): chainId is number => Boolean(chainId)));
  }, [hasIndexedFromTokens, indexedSupportedTokens]);

  const availableFromTokens = useMemo(
    () => {
      const chainTokens = getUniqueTokensForChain(supported.tokens, draft.fromChain);
      if (!hasIndexedFromTokens) {
        return chainTokens;
      }
      return chainTokens.filter((token) => {
        const tokenKey = getTokenKeySafe(token.chainId, token.contractAddress);
        return tokenKey ? indexedSupportedTokenKeys.has(tokenKey) : false;
      });
    },
    [draft.fromChain, hasIndexedFromTokens, indexedSupportedTokenKeys, supported.tokens]
  );

  const availableToTokens = useMemo(
    () => getUniqueTokensForChain(supported.tokens, draft.toChain),
    [draft.toChain, supported.tokens]
  );

  const sourceToken = useMemo(
    () => availableFromTokens.find((token) => token.symbol === draft.fromToken) ?? null,
    [availableFromTokens, draft.fromToken]
  );

  const sourceTokenKey = useMemo(
    () => getTokenKeySafe(sourceToken?.chainId, sourceToken?.contractAddress),
    [sourceToken?.chainId, sourceToken?.contractAddress]
  );

  const sourceTokenMaxBalance = useMemo(
    () => (sourceTokenKey ? indexedBalanceNumberByTokenKey.get(sourceTokenKey) ?? null : null),
    [indexedBalanceNumberByTokenKey, sourceTokenKey]
  );

  const hasSourceTokenMax = useMemo(
    () => hasIndexedFromTokens && sourceTokenMaxBalance !== null,
    [hasIndexedFromTokens, sourceTokenMaxBalance]
  );

  const amountStep = useMemo(
    () =>
      hasSourceTokenMax && sourceTokenMaxBalance !== null
        ? getAmountStepFromBalance(sourceTokenMaxBalance, sourceToken?.decimals)
        : '0.01',
    [hasSourceTokenMax, sourceToken?.decimals, sourceTokenMaxBalance]
  );

  const destinationToken = useMemo(
    () => availableToTokens.find((token) => token.symbol === draft.toToken) ?? null,
    [availableToTokens, draft.toToken]
  );

  const fromTokenOptions = useMemo<IconOption[]>(
    () =>
      availableFromTokens.map((token) => {
        const tokenKey = getTokenKeySafe(token.chainId, token.contractAddress);
        const indexedBalance = tokenKey ? indexedBalanceByTokenKey.get(tokenKey) : null;
        return {
          value: token.symbol,
          label: hasIndexedFromTokens
            ? `${token.symbol} (${indexedBalance ?? '0'})`
            : `${token.symbol} (${token.name})`,
          iconUrl: token.imageUrl || undefined
        };
      }),
    [availableFromTokens, hasIndexedFromTokens, indexedBalanceByTokenKey]
  );

  const toTokenOptions = useMemo<IconOption[]>(
    () =>
      availableToTokens.map((token) => ({
        value: token.symbol,
        label: `${token.symbol} (${token.name})`,
        iconUrl: token.imageUrl || undefined
      })),
    [availableToTokens]
  );

  const allChainOptions = useMemo<IconOption[]>(
    () =>
      supported.chains.map((chain) => ({
        value: String(chain.id),
        label: chain.name,
        iconUrl: getChainLogoUrl(chain.id)
      })),
    [supported.chains]
  );

  const fromChainOptions = useMemo<IconOption[]>(
    () =>
      hasIndexedFromTokens
        ? supported.chains
            .filter((chain) => indexedFromChainIds.has(chain.id))
            .map((chain) => ({
              value: String(chain.id),
              label: chain.name,
              iconUrl: getChainLogoUrl(chain.id)
            }))
        : allChainOptions,
    [allChainOptions, hasIndexedFromTokens, indexedFromChainIds, supported.chains]
  );

  useEffect(() => {
    if (fromChainOptions.length === 0) {
      return;
    }
    if (!fromChainOptions.some((option) => Number(option.value) === draft.fromChain)) {
      setDraft((current) => ({ ...current, fromChain: Number(fromChainOptions[0].value) }));
    }
  }, [draft.fromChain, fromChainOptions]);

  useEffect(() => {
    if (
      availableFromTokens.length > 0 &&
      !availableFromTokens.some((token) => token.symbol === draft.fromToken)
    ) {
      setDraft((current) => ({ ...current, fromToken: availableFromTokens[0].symbol }));
    }
  }, [availableFromTokens, draft.fromToken]);

  useEffect(() => {
    if (availableToTokens.length > 0 && !availableToTokens.some((token) => token.symbol === draft.toToken)) {
      setDraft((current) => ({ ...current, toToken: availableToTokens[0].symbol }));
    }
  }, [availableToTokens, draft.toToken]);

  useEffect(() => {
    if (!hasSourceTokenMax || sourceTokenMaxBalance === null) {
      return;
    }
    if (draft.amount > sourceTokenMaxBalance) {
      setDraft((current) => ({ ...current, amount: sourceTokenMaxBalance }));
    }
  }, [draft.amount, hasSourceTokenMax, sourceTokenMaxBalance]);

  const updateDeliveryPhaseFromStates = useCallback((states: TrailsTransactionState[]) => {
    if (!states.length) {
      return;
    }

    if (states.some((state) => state.state === 'failed' || state.state === 'aborted')) {
      setDeliveryPhase('failed');
      return;
    }

    const confirmedCount = states.filter((state) => state.state === 'confirmed').length;
    const hasPending = states.some((state) => state.state === 'pending');

    if (confirmedCount >= 2) {
      setDeliveryPhase('routing');
      return;
    }

    if (confirmedCount >= 1) {
      setDeliveryPhase('submitting_origin');
      return;
    }

    if (hasPending) {
      setDeliveryPhase('submitting_origin');
    }
  }, []);

  const checkoutOnHandlers = useMemo(
    () => ({
      triggerCheckoutStart: () => setDeliveryPhase('starting'),
      triggerCheckoutSignatureRequest: () => setDeliveryPhase('awaiting_signature'),
      triggerCheckoutApprovalRequest: () => setDeliveryPhase('awaiting_signature'),
      triggerCheckoutSignatureConfirmed: () => setDeliveryPhase('signature_confirmed'),
      triggerCheckoutApprovalConfirmed: () => setDeliveryPhase('signature_confirmed'),
      triggerCheckoutSignatureRejected: (checkoutError: unknown) => {
        setExecuteError(toErrorMessage(checkoutError));
        setDeliveryPhase('failed');
      },
      triggerCheckoutApprovalRejected: (checkoutError: unknown) => {
        setExecuteError(toErrorMessage(checkoutError));
        setDeliveryPhase('failed');
      },
      triggerCheckoutStatusUpdate: (states: TrailsTransactionState[]) => {
        setExecutionStates(states);
        updateDeliveryPhaseFromStates(states);
      },
      triggerCheckoutComplete: (status: 'success' | 'fail') => {
        setDeliveryPhase(status === 'success' ? 'completed' : 'failed');
      },
      triggerCheckoutError: (checkoutError: unknown) => {
        setExecuteError(toErrorMessage(checkoutError));
        setDeliveryPhase('failed');
      }
    }),
    [updateDeliveryPhaseFromStates]
  );

  const {
    quote: sdkQuote,
    send: sendQuote,
    isLoadingQuote,
    quoteErrorPrettified
  } = useQuote({
    walletClient,
    fromTokenAddress: sourceToken?.contractAddress ?? null,
    fromChainId: draft.fromChain,
    toTokenAddress: destinationToken?.contractAddress ?? null,
    toChainId: draft.toChain,
    swapAmount: quoteRequest?.amountAtomic,
    tradeType: TradeType.EXACT_INPUT,
    toAddress: recipientIsValid ? recipientAddress : null,
    onStatusUpdate: (states) => {
      setExecutionStates(states);
      updateDeliveryPhaseFromStates(states);
    },
    checkoutOnHandlers,
    slippageTolerance: String(draft.slippagePercent / 100),
    fundMethod: 'wallet',
    apiKey: trailsApiKey || null
  });

  useEffect(() => {
    if (quoteErrorPrettified) {
      setError(quoteErrorPrettified);
    }
  }, [quoteErrorPrettified]);

  useEffect(() => {
    if (!copyToast) {
      return;
    }

    const timeout = window.setTimeout(() => {
      setCopyToast(null);
    }, 2200);

    return () => {
      window.clearTimeout(timeout);
    };
  }, [copyToast]);

  useEffect(() => {
    if (sdkQuote) {
      setLastResolvedQuote(sdkQuote);
    }
  }, [sdkQuote]);

  useEffect(() => {
    if (isLoggedIn) {
      return;
    }

    setHasPrimedQuoteFlow(false);
    setQuoteRequest(null);
    quoteRequestRef.current = null;
    setLastResolvedQuote(null);
    setExecuteResult(null);
    setExecuteError(null);
    setIsExecutingTrail(false);
    setIsExecutionFocused(false);
    setExecutionStates([]);
    setDeliveryPhase('idle');
    setPendingQuoteVisualPayloadKey(null);
    pendingAutoQuotePayloadRef.current = null;
    pendingAutoQuoteStartedRef.current = false;
    pendingQuoteVisualLoadingStartedRef.current = false;
    pendingQuoteVisualPayloadKeyRef.current = null;
    lastAutoQuotePayloadRef.current = null;
    lastObservedAutoInputPayloadRef.current = null;

    if (autoQuoteTimerRef.current !== null) {
      window.clearTimeout(autoQuoteTimerRef.current);
      autoQuoteTimerRef.current = null;
    }
  }, [isLoggedIn]);

  useEffect(() => {
    const pendingPayload = pendingAutoQuotePayloadRef.current;
    if (!pendingPayload) {
      return;
    }

    if (isLoadingQuote) {
      if (!pendingAutoQuoteStartedRef.current) {
        pendingAutoQuoteStartedRef.current = true;
      }
      return;
    }

    if (!pendingAutoQuoteStartedRef.current) {
      return;
    }

    pendingAutoQuotePayloadRef.current = null;
    pendingAutoQuoteStartedRef.current = false;
  }, [isLoadingQuote, sdkQuote, sdkQuote?.intentId]);

  useEffect(() => {
    pendingQuoteVisualPayloadKeyRef.current = pendingQuoteVisualPayloadKey;
  }, [pendingQuoteVisualPayloadKey]);

  useEffect(() => {
    if (!pendingQuoteVisualPayloadKey) {
      pendingQuoteVisualLoadingStartedRef.current = false;
      return;
    }

    if (isLoadingQuote) {
      pendingQuoteVisualLoadingStartedRef.current = true;
      return;
    }

    if (!pendingQuoteVisualLoadingStartedRef.current) {
      return;
    }

    setPendingQuoteVisualPayloadKey(null);
    pendingQuoteVisualLoadingStartedRef.current = false;
  }, [isLoadingQuote, pendingQuoteVisualPayloadKey]);

  useEffect(() => {
    if (!pendingQuoteVisualPayloadKey || isLoadingQuote) {
      return;
    }

    const payloadKey = pendingQuoteVisualPayloadKey;
    const timeout = window.setTimeout(() => {
      if (
        pendingQuoteVisualPayloadKeyRef.current !== payloadKey ||
        pendingQuoteVisualLoadingStartedRef.current ||
        isLoadingQuote
      ) {
        return;
      }

      setPendingQuoteVisualPayloadKey(null);

      if (pendingAutoQuotePayloadRef.current === payloadKey && !pendingAutoQuoteStartedRef.current) {
        pendingAutoQuotePayloadRef.current = null;
      }
    }, 2600);

    return () => {
      window.clearTimeout(timeout);
    };
  }, [isLoadingQuote, pendingQuoteVisualPayloadKey]);

  const quote = useMemo(() => {
    if (!isLoggedIn) {
      return null;
    }

    if (quoteRequest && quoteRequest.inputKey === draftInputKey && sdkQuote) {
      return sdkQuote;
    }

    if (hasPrimedQuoteFlow) {
      return lastResolvedQuote;
    }

    return null;
  }, [draftInputKey, hasPrimedQuoteFlow, isLoggedIn, lastResolvedQuote, quoteRequest, sdkQuote]);
  const isInitialQuoteLoading = isLoggedIn && hasPrimedQuoteFlow && !quote && !error;
  const isQuoteStale = useMemo(
    () =>
      Boolean(
        hasPrimedQuoteFlow &&
          quote &&
          (Boolean(pendingQuoteVisualPayloadKey) ||
            isLoadingQuote ||
            !quoteRequest ||
            quoteRequest.inputKey !== draftInputKey)
      ),
    [draftInputKey, hasPrimedQuoteFlow, isLoadingQuote, pendingQuoteVisualPayloadKey, quote, quoteRequest]
  );

  const canSubmit = useMemo(
    () =>
      draft.amount > 0 &&
      draft.fromToken.trim().length > 0 &&
      draft.toToken.trim().length > 0 &&
      Boolean(sourceToken) &&
      Boolean(destinationToken) &&
      draft.slippagePercent >= 0.05 &&
      draft.slippagePercent <= 2 &&
      (!hasSourceTokenMax || sourceTokenMaxBalance === null || draft.amount <= sourceTokenMaxBalance) &&
      alternateRecipientIsValid,
    [alternateRecipientIsValid, destinationToken, draft, hasSourceTokenMax, sourceToken, sourceTokenMaxBalance]
  );

  const canAutoQuote = useMemo(
    () =>
      hasPrimedQuoteFlow &&
      canSubmit &&
      walletEnabled &&
      authenticated &&
      Boolean(address) &&
      Boolean(walletClient) &&
      Boolean(trailsApiKey),
    [address, authenticated, canSubmit, hasPrimedQuoteFlow, walletClient, walletEnabled]
  );

  const autoQuotePayload = useMemo(() => {
    if (!canAutoQuote || !sourceToken) {
      return null;
    }

    const amountAtomic = toAtomicAmount(draft.amount, sourceToken.decimals);
    if (!amountAtomic) {
      return null;
    }

    return { inputKey: draftInputKey, amountAtomic };
  }, [canAutoQuote, draft.amount, draftInputKey, sourceToken, sourceToken?.decimals]);

  useEffect(() => {
    if (!autoQuotePayload) {
      lastObservedAutoInputPayloadRef.current = null;
      return;
    }

    const inputPayloadKey = `${autoQuotePayload.inputKey}|${autoQuotePayload.amountAtomic}`;
    if (lastObservedAutoInputPayloadRef.current === inputPayloadKey) {
      return;
    }
    lastObservedAutoInputPayloadRef.current = inputPayloadKey;

    autoQuoteScheduleIdRef.current += 1;
    const scheduleId = autoQuoteScheduleIdRef.current;

    lastInputChangedAtRef.current = Date.now();

    if (autoQuoteTimerRef.current !== null) {
      window.clearTimeout(autoQuoteTimerRef.current);
    }

    const scheduleAutoQuote = () => {
      if (scheduleId !== autoQuoteScheduleIdRef.current) {
        return;
      }

      const now = Date.now();
      const dueAt = Math.max(
        lastInputChangedAtRef.current + 1000,
        lastQuoteTriggerAtRef.current + 4000
      );
      const wait = dueAt - now;

      if (wait > 0) {
        autoQuoteTimerRef.current = window.setTimeout(scheduleAutoQuote, wait);
        return;
      }

      const payloadKey = `${autoQuotePayload.inputKey}|${autoQuotePayload.amountAtomic}`;
      if (lastAutoQuotePayloadRef.current === payloadKey) {
        return;
      }

      if (pendingAutoQuotePayloadRef.current) {
        autoQuoteTimerRef.current = window.setTimeout(scheduleAutoQuote, 250);
        return;
      }

      setError(null);

      const current = quoteRequestRef.current;
      if (
        current &&
        current.inputKey === autoQuotePayload.inputKey &&
        current.amountAtomic === autoQuotePayload.amountAtomic
      ) {
        return;
      }

      pendingAutoQuotePayloadRef.current = payloadKey;
      pendingAutoQuoteStartedRef.current = false;
      pendingQuoteVisualSetAtRef.current = Date.now();
      setPendingQuoteVisualPayloadKey(payloadKey);
      setExecuteResult(null);
      setExecuteError(null);
      setIsExecutionFocused(false);
      setExecutionStates([]);
      setDeliveryPhase('idle');
      setQuoteRequest(autoQuotePayload);
      quoteRequestRef.current = autoQuotePayload;

      lastQuoteTriggerAtRef.current = Date.now();
      lastAutoQuotePayloadRef.current = payloadKey;
    };

    autoQuoteTimerRef.current = window.setTimeout(scheduleAutoQuote, 0);

    return () => {
      if (autoQuoteTimerRef.current !== null) {
        window.clearTimeout(autoQuoteTimerRef.current);
        autoQuoteTimerRef.current = null;
      }
    };
  }, [autoQuotePayload, canAutoQuote, draftInputKey, sourceToken]);

  const executeUnavailableReason = useMemo(() => {
    if (!walletEnabled) {
      return 'Set up Privy to continue.';
    }

    if (!authenticated || !address || !walletClient) {
      return 'Connect wallet and get a quote.';
    }

    if (useAlternateRecipient && !alternateRecipientIsValid) {
      return 'Enter a valid recipient wallet.';
    }

    if (!sourceToken || !destinationToken) {
      return 'Trail is not supported.';
    }

    if (!quote) {
      return 'Waiting for you to request a quote.';
    }

    if (isQuoteStale) {
      return 'Updating quote...';
    }

    if (!sendQuote) {
      return 'Quote is not ready to execute.';
    }

    if (isExecutingTrail) {
      return 'Executing trail...';
    }

    return null;
  }, [
    address,
    alternateRecipientIsValid,
    authenticated,
    destinationToken,
    isExecutingTrail,
    isQuoteStale,
    quote,
    sendQuote,
    sourceToken,
    useAlternateRecipient,
    walletClient,
    walletEnabled
  ]);

  const updateDraft = <K extends keyof Draft>(key: K, value: Draft[K]) => {
    setDraft((current) => ({ ...current, [key]: value }));
  };

  const copyWalletAddress = async () => {
    if (!address) {
      return;
    }

    try {
      await navigator.clipboard.writeText(address);
      setCopyToast('Wallet address copied');
    } catch {
      setCopyToast('Could not copy address');
    }
  };

  const submitQuote = () => {
    if (!canSubmit || isLoadingQuote) {
      return;
    }

    if (!trailsApiKey) {
      setError('Add Trails API key to continue.');
      return;
    }

    if (!walletEnabled || !authenticated || !address || !walletClient) {
      setError('Connect wallet to get a quote.');
      return;
    }

    if (useAlternateRecipient && !alternateRecipientIsValid) {
      setError('Enter a valid recipient wallet.');
      return;
    }

    if (!sourceToken || !destinationToken) {
      setError('This trail is not supported.');
      return;
    }

    if (hasSourceTokenMax && sourceTokenMaxBalance !== null && draft.amount > sourceTokenMaxBalance) {
      setError(`Amount exceeds available ${draft.fromToken} balance.`);
      return;
    }

    const amountAtomic = toAtomicAmount(draft.amount, sourceToken.decimals);
    if (!amountAtomic) {
      setError('Enter a valid amount for this token.');
      return;
    }

    setError(null);
    setHasPrimedQuoteFlow(true);
    lastQuoteTriggerAtRef.current = Date.now();
    const payloadKey = `${draftInputKey}|${amountAtomic}`;
    lastAutoQuotePayloadRef.current = payloadKey;
    lastObservedAutoInputPayloadRef.current = payloadKey;
    pendingAutoQuotePayloadRef.current = payloadKey;
    pendingAutoQuoteStartedRef.current = false;
    pendingQuoteVisualSetAtRef.current = Date.now();
    setPendingQuoteVisualPayloadKey(payloadKey);
    setExecuteResult(null);
    setExecuteError(null);
    setIsExecutionFocused(false);
    setExecutionStates([]);
    setDeliveryPhase('idle');
    const nextRequest = { amountAtomic, inputKey: draftInputKey };
    setQuoteRequest(nextRequest);
    quoteRequestRef.current = nextRequest;
  };

  useEffect(() => {
    quoteRequestRef.current = quoteRequest;
  }, [quoteRequest?.amountAtomic, quoteRequest?.inputKey]);

  const quoteToAmount = normalizeAmountForWidget(
    quote?.destinationAmountFormatted || quote?.destinationAmountDisplay || null
  );

  const quoteHasAmount = Number(quoteToAmount) > 0;
  const canExecuteTrail =
    walletEnabled &&
    authenticated &&
    isConnected &&
    Boolean(address) &&
    Boolean(trailsApiKey) &&
    Boolean(destinationToken) &&
    Boolean(quote) &&
    !isQuoteStale &&
    quoteHasAmount &&
    Boolean(sendQuote) &&
    !isExecutingTrail;

  const routeProviderNames = useMemo(() => {
    if (!quote?.routeProviders || quote.routeProviders.length === 0) {
      return 'Auto';
    }

    const names = Array.from(
      new Set(
        quote.routeProviders
          .map((provider) => provider.name?.trim())
          .filter((name): name is string => Boolean(name))
      )
    );

    return names.length > 0 ? names.join(', ') : 'Auto';
  }, [quote?.routeProviders]);

  const isCrossChainRoute = Boolean(
    quote && quote.originChain.id !== quote.destinationChain.id
  );

  const phaseProgressIndex = useMemo(() => {
    switch (deliveryPhase) {
      case 'starting':
      case 'awaiting_signature':
        return 0;
      case 'signature_confirmed':
      case 'submitting_origin':
        return 1;
      case 'routing':
        return isCrossChainRoute ? 2 : 1;
      case 'completed':
        return isCrossChainRoute ? 3 : 2;
      case 'failed':
        return isCrossChainRoute ? 2 : 1;
      case 'idle':
      default:
        return -1;
    }
  }, [deliveryPhase, isCrossChainRoute]);

  const executionStops = useMemo<DeliveryStop[]>(() => {
    if (
      !quote ||
      (deliveryPhase === 'idle' && !isExecutingTrail && !executeResult && executionStates.length === 0)
    ) {
      return [];
    }

    const firstState = executionStates[0];
    const lastState = executionStates[executionStates.length - 1];
    const fallbackDestinationState = executionStates.length > 1 ? lastState : undefined;

    const originTxHash = executeResult?.originTxHash ?? firstState?.transactionHash ?? undefined;
    const originExplorerUrl = executeResult?.originExplorerUrl ?? firstState?.explorerUrl ?? undefined;
    const destinationTxHash =
      executeResult?.destinationTxHash ?? fallbackDestinationState?.transactionHash ?? undefined;
    const destinationExplorerUrl =
      executeResult?.destinationExplorerUrl ?? fallbackDestinationState?.explorerUrl ?? undefined;

    const activeIndex = deliveryPhase === 'failed' ? Math.max(phaseProgressIndex, 1) : phaseProgressIndex;

    const stops: Omit<DeliveryStop, 'state'>[] = [
      {
        id: 'delivery-signature',
        title: 'Authorize pickup',
        detail: 'Confirm in your embedded wallet.'
      },
      {
        id: 'delivery-origin',
        title: 'Leave origin',
        detail: `${quote.originToken.symbol} on ${quote.originChain.name}.`,
        transactionHash: originTxHash,
        explorerUrl: originExplorerUrl
      },
      {
        id: 'delivery-destination',
        title: 'Delivered',
        detail: `${quote.destinationToken.symbol} on ${quote.destinationChain.name}.`,
        transactionHash: destinationTxHash,
        explorerUrl: destinationExplorerUrl
      }
    ];

    if (isCrossChainRoute) {
      stops.splice(2, 0, {
        id: 'delivery-route',
        title: 'Cross-chain route',
        detail: `${quote.originChain.name} to ${quote.destinationChain.name}.`
      });
    }

    return stops.map((stop, index) => {
      let state: DeliveryStopState = 'queued';
      if (deliveryPhase === 'completed' || index < activeIndex) {
        state = 'confirmed';
      } else if (index === activeIndex) {
        state = deliveryPhase === 'failed' ? 'failed' : 'pending';
      }

      return { ...stop, state };
    });
  }, [deliveryPhase, executeResult, executionStates, isCrossChainRoute, isExecutingTrail, phaseProgressIndex, quote]);

  const activeDeliveryIndex = useMemo(() => {
    if (executionStops.length === 0) {
      return 0;
    }

    const failedIndex = executionStops.findIndex((stop) => stop.state === 'failed' || stop.state === 'aborted');
    if (failedIndex >= 0) {
      return failedIndex;
    }

    const pendingIndex = executionStops.findIndex((stop) => stop.state === 'pending');
    if (pendingIndex >= 0) {
      return pendingIndex;
    }

    return executionStops.length - 1;
  }, [executionStops]);

  const deliveryProgressPercent = useMemo(() => {
    if (executionStops.length === 0) {
      return 0;
    }
    if (executionStops.length === 1) {
      return 100;
    }
    return (activeDeliveryIndex / (executionStops.length - 1)) * 100;
  }, [activeDeliveryIndex, executionStops.length]);

  const deliveryStatusText = useMemo(() => {
    switch (deliveryPhase) {
      case 'starting':
        return 'Starting execution';
      case 'awaiting_signature':
        return 'Waiting for wallet signature';
      case 'signature_confirmed':
        return 'Signature received';
      case 'submitting_origin':
        return 'Submitting origin transaction';
      case 'routing':
        return 'In transit';
      case 'completed':
        return 'Delivered';
      case 'failed':
        return 'Delivery interrupted';
      case 'idle':
      default:
        return 'Preparing route';
    }
  }, [deliveryPhase]);

  useEffect(() => {
    if (executionStates.length === 0) {
      return;
    }

    const allConfirmed = executionStates.every((state) => state.state === 'confirmed');
    if (allConfirmed) {
      setDeliveryPhase('completed');

      if (!executeResult) {
        const originState = executionStates[0];
        const destinationState = executionStates[executionStates.length - 1];
        setExecuteResult({
          originTxHash: originState?.transactionHash ?? null,
          originExplorerUrl: originState?.explorerUrl ?? null,
          destinationTxHash: destinationState?.transactionHash ?? null,
          destinationExplorerUrl: destinationState?.explorerUrl ?? null
        });
      }

      if (isExecutingTrail) {
        setIsExecutingTrail(false);
      }
      return;
    }

    const hasFailure = executionStates.some(
      (state) => state.state === 'failed' || state.state === 'aborted'
    );
    if (hasFailure) {
      setDeliveryPhase('failed');
      if (isExecutingTrail) {
        setIsExecutingTrail(false);
      }
    }
  }, [executeResult, executionStates, isExecutingTrail]);

  const hasSuccessfulExecution = deliveryPhase === 'completed' && !isExecutingTrail;

  const handleGenerateAnotherQuote = () => {
    setIsExecutionFocused(false);
    setHasPrimedQuoteFlow(false);
    setQuoteRequest(null);
    quoteRequestRef.current = null;
    setLastResolvedQuote(null);
    setPendingQuoteVisualPayloadKey(null);
    setExecuteResult(null);
    setExecuteError(null);
    setExecutionStates([]);
    setDeliveryPhase('idle');
  };

  const handleExecuteTrail = async () => {
    if (!canExecuteTrail || !sendQuote) {
      return;
    }

    setExecuteError(null);
    setExecutionStates([]);
    setDeliveryPhase('starting');
    setIsExecutionFocused(true);
    setIsExecutingTrail(true);

    try {
      const result = await sendQuote();
      if (!result) {
        setExecuteError('No execution result returned.');
        setDeliveryPhase('failed');
        setIsExecutionFocused(false);
        return;
      }

      setExecuteResult({
        originTxHash: result.originTransaction?.transactionHash ?? null,
        originExplorerUrl: result.originTransaction?.explorerUrl ?? null,
        destinationTxHash: result.destinationTransaction?.transactionHash ?? null,
        destinationExplorerUrl: result.destinationTransaction?.explorerUrl ?? null,
        totalCompletionSeconds: result.totalCompletionSeconds
      });
      setDeliveryPhase('completed');
    } catch (executeUnknownError) {
      setExecuteError(toErrorMessage(executeUnknownError));
      setDeliveryPhase('failed');
      setIsExecutionFocused(false);
    } finally {
      setIsExecutingTrail(false);
    }
  };

  return (
    <main className="app-shell">
      <section className="surface">
        <header className="header-row">
          <div>
            <p className="eyebrow">Trails</p>
            <h1>Trails x Privy Embedded</h1>
            <p className="subtle">1-click cross-chain orchestration.</p>
          </div>
          {showHeaderActions ? (
            <div className="status-row" role="status" aria-live="polite">
              {isConnected && address ? (
                <button
                  type="button"
                  className="status-address"
                  onClick={copyWalletAddress}
                  title="Copy wallet address"
                  aria-label="Copy wallet address"
                >
                  {truncateAddress(address)}
                </button>
              ) : null}
              {walletEnabled ? (
                <button
                  type="button"
                  className="status-action"
                  onClick={onAuthAction}
                  disabled={!authReady || !onAuthAction}
                >
                  {authReady ? authActionLabel : 'Loading'}
                </button>
              ) : null}
            </div>
          ) : null}
        </header>

        {setupNotices.length > 0 ? (
          <section className="notice-stack" aria-label="Setup notices">
            {setupNotices.map((notice) => (
              <article key={notice.id} className={`notice notice-${notice.tone}`} role="status">
                <p className="notice-title">{notice.title}</p>
                <p className="notice-detail">{notice.detail}</p>
              </article>
            ))}
          </section>
        ) : null}

        <section
          className={`layout-grid${hasPrimedQuoteFlow ? '' : ' layout-grid-initial'}${
            showExecutionFocus ? ' layout-grid-executing' : ''
          }`}
        >
          {!showExecutionFocus ? (
            <article className="column column-primary">
            {showPrimaryConnectCta ? (
              <section className="primary-connect-row" aria-label="Connect with Privy">
                <button
                  type="button"
                  className="cta primary-connect-cta"
                  onClick={onAuthAction}
                  disabled={!authReady || !onAuthAction}
                >
                  {authReady ? 'Connect with Privy' : 'Loading...'}
                </button>
              </section>
            ) : null}

            <div className={`fields${isInputsLocked ? ' fields-locked' : ''}`}>
              <section className="route-group" aria-label="From">
                <p className="route-group-title">From</p>
                <div className="route-inline-fields">
                  <label>
                    <IconSelect
                      value={String(draft.fromChain)}
                      options={fromChainOptions}
                      disabled={isFromSelectorLoading || isInputsLocked}
                      onChange={(nextValue) => updateDraft('fromChain', Number(nextValue))}
                      ariaLabel="From network"
                    />
                  </label>

                  <label>
                    <IconSelect
                      value={draft.fromToken}
                      options={fromTokenOptions}
                      disabled={isFromSelectorLoading || isInputsLocked}
                      onChange={(nextValue) => updateDraft('fromToken', nextValue)}
                      ariaLabel="From token"
                    />
                  </label>
                </div>
              </section>

              {connectedWithAddress && (isLoadingBalances || !hasIndexedFromTokens) ? (
                <p className="asset-source-hint">
                  {isLoadingBalances
                    ? 'Loading your from assets...'
                    : 'No indexed balance found yet. Showing supported assets.'}
                </p>
              ) : null}

              <label className="field-amount">
                Amount
                <input
                  type="number"
                  min={0}
                  step={amountStep}
                  disabled={isInputsLocked}
                  value={draft.amount}
                  {...(hasSourceTokenMax && sourceTokenMaxBalance !== null
                    ? { max: String(sourceTokenMaxBalance) }
                    : {})}
                  onChange={(event) => {
                    const nextValue = Number(event.target.value);
                    if (hasSourceTokenMax && sourceTokenMaxBalance !== null && Number.isFinite(nextValue)) {
                      updateDraft('amount', Math.max(0, Math.min(nextValue, sourceTokenMaxBalance)));
                      return;
                    }
                    updateDraft('amount', nextValue);
                  }}
                />
                {hasSourceTokenMax && sourceTokenMaxBalance !== null ? (
                  <span className="amount-cap-hint">
                    Available: {formatAvailableBalance(sourceTokenMaxBalance)} {draft.fromToken}
                  </span>
                ) : null}
              </label>

              <section className="route-group" aria-label="To">
                <p className="route-group-title">To</p>
                <div className="route-inline-fields">
                  <label>
                    <IconSelect
                      value={String(draft.toChain)}
                      options={allChainOptions}
                      disabled={isInputsLocked}
                      onChange={(nextValue) => updateDraft('toChain', Number(nextValue))}
                      ariaLabel="To network"
                    />
                  </label>

                  <label>
                    <IconSelect
                      value={draft.toToken}
                      options={toTokenOptions}
                      disabled={isInputsLocked}
                      onChange={(nextValue) => updateDraft('toToken', nextValue)}
                      ariaLabel="To token"
                    />
                  </label>
                </div>
              </section>

              <div className="recipient-toggle-row">
                <label className="toggle-control">
                  <input
                    type="checkbox"
                    disabled={isInputsLocked}
                    checked={useAlternateRecipient}
                    onChange={(event) => setUseAlternateRecipient(event.target.checked)}
                  />
                  <span>Send to another wallet</span>
                </label>
              </div>

              {useAlternateRecipient ? (
                <label className="field-recipient">
                  Recipient wallet
                  <input
                    type="text"
                    disabled={isInputsLocked}
                    value={alternateRecipient}
                    placeholder="0x..."
                    spellCheck={false}
                    onChange={(event) => setAlternateRecipient(event.target.value)}
                  />
                </label>
              ) : null}

              <label className="field-slippage">
                <span className="label-with-help">
                  Slippage
                  <span className="help-inline">
                    <button
                      type="button"
                      className="help-trigger"
                      aria-label="What is slippage?"
                    >
                      i
                    </button>
                    <span className="help-tooltip" role="tooltip">
                      Higher slippage makes execution more likely in fast markets, but can lower
                      the final amount you receive.
                    </span>
                  </span>
                </span>
                <div className="input-with-suffix">
                  <input
                    type="number"
                    min={0.05}
                    max={2}
                    step={0.05}
                    disabled={isInputsLocked}
                    value={draft.slippagePercent}
                    onChange={(event) => updateDraft('slippagePercent', Number(event.target.value))}
                  />
                  <span className="input-suffix" aria-hidden="true">
                    %
                  </span>
                </div>
              </label>
            </div>

            {!hasPrimedQuoteFlow ? (
              <button
                type="button"
                className="cta"
                onClick={submitQuote}
                disabled={isInputsLocked || !canSubmit || isLoadingQuote}
              >
                {isLoadingQuote ? 'Loading...' : 'Get Quote'}
              </button>
            ) : null}

            {error ? <p className="error">{error}</p> : null}
            </article>
          ) : null}

          <article className="column quote-column">
            {isLoggedIn && (isQuoteStale || isInitialQuoteLoading) ? (
              <p className="quote-loading" role="status" aria-live="polite">
                <span className="quote-spinner" aria-hidden="true" />
                {isInitialQuoteLoading ? 'Getting quote...' : 'Updating quote...'}
              </p>
            ) : null}
            {!isLoggedIn ? (
              <p className="empty">Connect wallet to continue.</p>
            ) : quote ? (
              <div className={`quote-content${isQuoteStale ? ' quote-content-stale' : ''}`}>
                <dl className="metric-list">
                  <div>
                    <dt>You get</dt>
                    <dd>
                      ~{quote.destinationAmountDisplay} {quote.destinationToken.symbol}
                    </dd>
                  </div>
                  <div>
                    <dt>Fees</dt>
                    <dd>{quote.totalFeesUsdDisplay || '$0.00'}</dd>
                  </div>
                  <div>
                    <dt>Impact</dt>
                    <dd>{formatPriceImpact(quote.priceImpact)}</dd>
                  </div>
                </dl>

                <details className="quote-details" aria-label="Route and fee details">
                  <summary className="quote-details-title">Details</summary>
                  <dl className="detail-list">
                    <div>
                      <dt>Route</dt>
                      <dd>
                        {quote.originChain.name} {quote.originToken.symbol} to{' '}
                        {quote.destinationChain.name} {quote.destinationToken.symbol}
                      </dd>
                    </div>
                    <div>
                      <dt>Providers</dt>
                      <dd>{routeProviderNames}</dd>
                    </div>
                    <div>
                      <dt>Time to execute</dt>
                      <dd>{quote.completionEstimateDisplay || `${quote.completionEstimateSeconds}s`}</dd>
                    </div>
                    <div className="detail-item-fee">
                      <dt>Origin gas</dt>
                      <dd>{formatMoneyDisplay(quote.originGasUsdDisplay)}</dd>
                    </div>
                    <div className="detail-item-fee">
                      <dt>Destination gas</dt>
                      <dd>{formatMoneyDisplay(quote.destinationGasUsdDisplay)}</dd>
                    </div>
                    <div className="detail-item-fee">
                      <dt>Provider fee</dt>
                      <dd>{formatMoneyDisplay(quote.providerFeeUsdDisplay)}</dd>
                    </div>
                    <div className="detail-item-fee">
                      <dt>Trails fee</dt>
                      <dd>{formatMoneyDisplay(quote.trailsFeeUsdDisplay)}</dd>
                    </div>
                    <div className="detail-item-total">
                      <dt>Total fees</dt>
                      <dd>{formatMoneyDisplay(quote.totalFeesUsdDisplay)}</dd>
                    </div>
                    <div className="detail-item-total">
                      <dt>Min received</dt>
                      <dd>
                        {quote.destinationAmountMinDisplay} {quote.destinationToken.symbol}
                      </dd>
                    </div>
                  </dl>
                </details>
              </div>
            ) : hasPrimedQuoteFlow ? (
              error ? <p className="empty">No quote available.</p> : null
            ) : (
              <p className="empty">Waiting for you to request a quote.</p>
            )}

            <div className="checkout-row">
              {quote ? (
                <>
                  {!hasSuccessfulExecution ? (
                    <button
                      type="button"
                      className="cta cta-secondary"
                      onClick={handleExecuteTrail}
                      disabled={!canExecuteTrail}
                    >
                      {isExecutingTrail ? 'Executing...' : 'Execute Trail'}
                    </button>
                  ) : null}
                  {!hasSuccessfulExecution && executeUnavailableReason ? (
                    <p className="checkout-note">{executeUnavailableReason}</p>
                  ) : null}
                  {executionStops.length > 0 ? (
                    <section className="delivery-widget" role="status" aria-live="polite">
                      <header className="delivery-widget-header">
                        <p className="delivery-widget-title">Execution progress</p>
                        <p className="delivery-widget-status">{deliveryStatusText}</p>
                      </header>
                      <div className="delivery-track" aria-hidden="true">
                        <div className="delivery-track-base" />
                        <div
                          className="delivery-track-progress"
                          style={{ width: `${deliveryProgressPercent}%` }}
                        />
                        <span
                          className={`delivery-package${isExecutingTrail ? ' delivery-package-moving' : ''}`}
                          style={{ left: `${deliveryProgressPercent}%` }}
                        >
                          ■
                        </span>
                      </div>
                      <ol className="delivery-stop-list">
                        {executionStops.map((stop, index) => (
                          <li
                            key={stop.id}
                            className={`delivery-stop delivery-stop-${stop.state}${
                              index === activeDeliveryIndex ? ' delivery-stop-active' : ''
                            }`}
                          >
                            <span className="delivery-stop-dot" aria-hidden="true" />
                            <div className="delivery-stop-copy">
                              <p className="delivery-stop-title">{stop.title}</p>
                              <p className="delivery-stop-detail">{stop.detail}</p>
                              {stop.transactionHash ? (
                                stop.explorerUrl ? (
                                  <a href={stop.explorerUrl} target="_blank" rel="noreferrer">
                                    {truncateAddress(stop.transactionHash)}
                                  </a>
                                ) : (
                                  <p className="delivery-stop-hash">{truncateAddress(stop.transactionHash)}</p>
                                )
                              ) : null}
                            </div>
                          </li>
                        ))}
                      </ol>
                    </section>
                  ) : null}
                  {executeError ? (
                    <p className="error">{executeError}</p>
                  ) : null}
                  {executeResult ? (
                    <div className="execute-result" role="status" aria-live="polite">
                      <p className="execute-result-title">Execution submitted.</p>
                      {executeResult.originTxHash ? (
                        <p>
                          Origin:{' '}
                          {executeResult.originExplorerUrl ? (
                            <a href={executeResult.originExplorerUrl} target="_blank" rel="noreferrer">
                              {truncateAddress(executeResult.originTxHash)}
                            </a>
                          ) : (
                            truncateAddress(executeResult.originTxHash)
                          )}
                        </p>
                      ) : null}
                      {executeResult.destinationTxHash ? (
                        <p>
                          Destination:{' '}
                          {executeResult.destinationExplorerUrl ? (
                            <a href={executeResult.destinationExplorerUrl} target="_blank" rel="noreferrer">
                              {truncateAddress(executeResult.destinationTxHash)}
                            </a>
                          ) : (
                            truncateAddress(executeResult.destinationTxHash)
                          )}
                        </p>
                      ) : null}
                    </div>
                  ) : null}
                  {hasSuccessfulExecution ? (
                    <button
                      type="button"
                      className="cta cta-secondary execution-reset-button"
                      onClick={handleGenerateAnotherQuote}
                    >
                      Generate another Quote
                    </button>
                  ) : null}
                </>
              ) : null}
            </div>
          </article>
        </section>
      </section>
      {copyToast ? (
        <div className="app-toast" role="status" aria-live="polite">
          {copyToast}
        </div>
      ) : null}
    </main>
  );
}

export default function App({ walletEnabled, walletDisabledReason }: AppProps) {
  return walletEnabled ? (
    <WalletEnabledApp />
  ) : (
    <Dashboard
      isConnected={false}
      address={undefined}
      walletEnabled={false}
      authReady={false}
      authenticated={false}
      walletDisabledReason={walletDisabledReason}
    />
  );
}
