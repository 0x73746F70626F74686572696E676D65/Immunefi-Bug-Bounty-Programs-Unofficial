import { describe, expect, it } from 'vitest';
import worker from './worker';

type TestEnv = {
  ASSETS?: {
    fetch: (input: Request | string, init?: RequestInit) => Promise<Response>;
  };
};

function createEnv(): TestEnv {
  return {
    ASSETS: {
      fetch: async () => new Response('asset fallback', { status: 200 })
    }
  };
}

function req(path: string, init?: RequestInit) {
  return new Request(`http://localhost:4444${path}`, init);
}

describe('worker static behavior', () => {
  it('serves assets for root routes', async () => {
    const response = await worker.fetch(req('/'), createEnv());
    const text = await response.text();

    expect(response.status).toBe(200);
    expect(text).toBe('asset fallback');
  });

  it('serves assets for arbitrary routes', async () => {
    const response = await worker.fetch(req('/quotes/demo', { method: 'POST' }), createEnv());
    const text = await response.text();

    expect(response.status).toBe(200);
    expect(text).toBe('asset fallback');
  });

  it('returns 404 when ASSETS binding is missing', async () => {
    const response = await worker.fetch(req('/'), {});

    expect(response.status).toBe(404);
  });
});
