import { expect, test, type Page } from '@playwright/test';

async function expectAppHeading(page: Page) {
  await expect(page.getByRole('heading', { name: 'Trails x Privy Embedded' })).toBeVisible({
    timeout: 20_000
  });
}

test('renders sleek landing in locked pre-connect state (desktop)', async ({ page }) => {
  await page.goto('/', { waitUntil: 'networkidle' });

  await expectAppHeading(page);
  await expect(page.getByText('Embedded wallet could not start.')).toHaveCount(0);
  await expect(page.getByText('Privy failed to initialize.')).toHaveCount(0);
  await expect(page.getByLabel('Amount')).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Get Quote' })).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Connect with Privy' })).toBeVisible();

  await page.screenshot({ path: 'test-results/trails-desktop.png', fullPage: true });
});

test('renders cleanly on mobile', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/', { waitUntil: 'networkidle' });

  await expectAppHeading(page);
  await expect(page.getByText('Embedded wallet could not start.')).toHaveCount(0);
  await expect(page.getByText('Privy failed to initialize.')).toHaveCount(0);
  await expect(page.getByText('Connect wallet to continue.')).toBeVisible();
  await expect(page.getByLabel('Amount')).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Get Quote' })).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Connect with Privy' })).toBeVisible();

  await page.screenshot({ path: 'test-results/trails-mobile.png', fullPage: true });
});

test('opens Privy auth UI from Connect action', async ({ page }) => {
  await page.goto('/', { waitUntil: 'networkidle' });

  await expectAppHeading(page);
  await page.getByRole('button', { name: 'Connect with Privy' }).click();

  await expect
    .poll(async () => {
      const dialogCount = await page.locator('[role="dialog"], [aria-modal="true"]').count();
      const privyDomCount = await page
        .locator('[id*="privy"], [class*="privy"], [data-testid*="privy"]')
        .count();
      return dialogCount + privyDomCount;
    })
    .toBeGreaterThan(0);

  await page.screenshot({ path: 'test-results/privy-connect-modal.png', fullPage: true });
});
