# SEQUENCESENDER

![Diagram](./SequenceSender.png)
