module.exports = {
    plugins: [
        'mocha',
    ],
    env: {
        node: true,
        mocha: true,
    },
    extends: 'airbnb-base',
    rules: {
        indent: ['error', 4],
        'mocha/no-exclusive-tests': 'error',
        'max-len': ['error', {
            code: 140, comments: 200, ignoreStrings: true, ignoreTemplateLiterals: true,
        }],
        'no-unused-vars': [2, { varsIgnorePattern: 'export^' }],
        'no-return-assign': [0],
        'no-underscore-dangle': [0],
        'no-plusplus': ['error', { allowForLoopAfterthoughts: true }],
        'func-names': [0],
        'class-methods-use-this': [0],
        'no-bitwise': [0],
        'no-param-reassign': 'off',
        'no-console': 'off',
        'import/prefer-default-export': [0],
        'lines-between-class-members': ['error', 'always', { exceptAfterSingleLine: true }],
        'no-await-in-loop': 'off',
        'newline-before-return': 'error',
    },
    parserOptions: {
        ecmaVersion: 2020,
    },
};
