// SPDX-License-Identifier: AGPL-3.0
pragma solidity ^0.8.0;

import "forge-std/Script.sol";

import { Gnosis } from "sparklend-address-registry/src/Gnosis.sol";

import { SSRBalancerRateProviderAdapter }  from "src/adapters/SSRBalancerRateProviderAdapter.sol";
import { SSRChainlinkRateProviderAdapter } from "src/adapters/SSRChainlinkRateProviderAdapter.sol";
import { SSRAuthOracle }                   from "src/SSRAuthOracle.sol";

import { SSROracleForwarderOptimism, OptimismForwarder } from "src/forwarders/SSROracleForwarderOptimism.sol";
import { SSROracleForwarderGnosis }                      from "src/forwarders/SSROracleForwarderGnosis.sol";
import { SSROracleForwarderArbitrum, ArbitrumForwarder } from "src/forwarders/SSROracleForwarderArbitrum.sol";
import { SSROracleForwarderLZ }                          from "src/forwarders/SSROracleForwarderLZ.sol";

import { AMBReceiver }      from "xchain-helpers/receivers/AMBReceiver.sol";
import { ArbitrumReceiver } from "xchain-helpers/receivers/ArbitrumReceiver.sol";
import { OptimismReceiver } from "xchain-helpers/receivers/OptimismReceiver.sol";
import { LZComposeReceiver } from "xchain-helpers/receivers/LZComposeReceiver.sol";

contract Deploy is Script {

    address internal constant SUSDS = 0xa3931d71877C0E7a3148CB7Eb4463524FEc27fbD;

    function deploy(string memory remoteRpcUrl) internal {
        address deployer = msg.sender;
        address admin    = vm.envOr("ORACLE_ADMIN", address(0));

        vm.createSelectFork(remoteRpcUrl);

        uint256 nonce = vm.getNonce(deployer);

        vm.createSelectFork(getChain("mainnet").rpcUrl);

        vm.startBroadcast();
        address expectedReceiver = vm.computeCreateAddress(deployer, nonce + 1);
        address forwarder        = deployForwarder(expectedReceiver);
        vm.stopBroadcast();

        vm.createSelectFork(remoteRpcUrl);

        vm.startBroadcast();
        SSRAuthOracle oracle = new SSRAuthOracle();
        address receiver = deployReceiver(forwarder, address(oracle));
        require(receiver == expectedReceiver, "receiver mismatch");
        SSRBalancerRateProviderAdapter  balancerAdapter  = new SSRBalancerRateProviderAdapter(oracle);
        SSRChainlinkRateProviderAdapter chainlinkAdapter = new SSRChainlinkRateProviderAdapter(oracle);

        // Configure
        oracle.grantRole(oracle.DATA_PROVIDER_ROLE(), receiver);

        // Note that if admin role is entirely revoked, maxSSR cannot be set and DATA_PROVIDER_ROLE cannot be changed
        if (admin != address(0)) {
            oracle.grantRole(oracle.DEFAULT_ADMIN_ROLE(), admin);
        }
        oracle.renounceRole(oracle.DEFAULT_ADMIN_ROLE(), deployer);
        vm.stopBroadcast();

        console.log("Deployed Forwarder at:                     ",  forwarder);
        console.log("Deployed Receiver at:                      ",  receiver);
        console.log("Deployed SSRAuthOracle at:                 ",  address(oracle));
        console.log("Deployed SSRBalancerRateProviderAdapter at:",  address(balancerAdapter));
        console.log("Deployed SSRChainlinkRateProviderAdapter at:", address(chainlinkAdapter));
    }

    function deployForwarder(address) internal virtual returns (address) {
        return address(0);
    }

    function deployReceiver(address, address) internal virtual returns (address) {
        return address(0);
    }

}

contract DeployOptimism is Deploy {
    
    function run() external {
        deploy(getChain("optimism").rpcUrl);
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderOptimism(SUSDS, receiver, OptimismForwarder.L1_CROSS_DOMAIN_OPTIMISM));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new OptimismReceiver(forwarder, oracle));
    }

}

contract DeployBase is Deploy {
    
    function run() external {
        deploy(getChain("base").rpcUrl);
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderOptimism(SUSDS, receiver, OptimismForwarder.L1_CROSS_DOMAIN_BASE));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new OptimismReceiver(forwarder, oracle));
    }

}

contract DeployWorldChain is Deploy {
    
    function run() external {
        deploy(vm.envString("WORLD_CHAIN_RPC_URL"));
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderOptimism(SUSDS, receiver, OptimismForwarder.L1_CROSS_DOMAIN_WORLD_CHAIN));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new OptimismReceiver(forwarder, oracle));
    }

}

contract DeployGnosis is Deploy {
    
    function run() external {
        deploy(getChain("gnosis_chain").rpcUrl);
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderGnosis(SUSDS, receiver));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new AMBReceiver(Gnosis.L2_AMB, bytes32(uint256(1)), forwarder, oracle));
    }

}

contract DeployArbitrumOne is Deploy {
    
    function run() external {
        deploy(getChain("arbitrum_one").rpcUrl);
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderArbitrum(SUSDS, receiver, ArbitrumForwarder.L1_CROSS_DOMAIN_ARBITRUM_ONE));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new ArbitrumReceiver(forwarder, oracle));
    }

}

contract DeployUnichain is Deploy {
    
    function run() external {
        deploy(vm.envString("UNICHAIN_RPC_URL"));
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderOptimism(SUSDS, receiver, OptimismForwarder.L1_CROSS_DOMAIN_UNICHAIN));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new OptimismReceiver(forwarder, oracle));
    }

}

contract DeployLZ is Deploy {

    function run() external {
        deploy(vm.envString("REMOTE_RPC_URL"));
    }

    function deployForwarder(address receiver) internal override returns (address) {
        return address(new SSROracleForwarderLZ({
            _susds:    SUSDS,
            _l2Oracle: receiver,
            _endpoint: 0x1a44076050125825900e736c501f859c50fE728c,
            _delegate: msg.sender,
            _owner:    msg.sender,
            _dstEid:   uint32(vm.envUint("DST_EID"))
        }));
    }

    function deployReceiver(address forwarder, address oracle) internal override returns (address) {
        return address(new LZComposeReceiver({
            _destinationEndpoint : vm.envAddress("LZ_ENDPOINT_REMOTE"),
            _srcEid              : uint32(30101),
            _sourceAuthority     : bytes32(uint256(uint160(forwarder))),
            _target              : oracle,
            _delegate            : msg.sender,
            _owner               : msg.sender
        }));
    }

}
