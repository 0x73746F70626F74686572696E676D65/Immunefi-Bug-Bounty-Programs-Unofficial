/**
 * Copyright (c) 2017-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

const babelConfig = require('./babel.config');

module.exports = require('babel-jest').createTransformer(babelConfig);
