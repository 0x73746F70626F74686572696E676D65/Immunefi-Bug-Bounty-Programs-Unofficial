Script inputs for Base.
