Script outputs for Mainnet.
