Script inputs for Mainnet.
