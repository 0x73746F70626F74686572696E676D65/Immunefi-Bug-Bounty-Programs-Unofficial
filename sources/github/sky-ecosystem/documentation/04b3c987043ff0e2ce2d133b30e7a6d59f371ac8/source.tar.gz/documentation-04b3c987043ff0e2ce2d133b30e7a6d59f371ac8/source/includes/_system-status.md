# System Status

```javascript
const ethCdp = maker.service('cdp');
```
To access system status information, retrieve the ETH CDP Service through Maker.service('cdp').

## **getSystemCollateralization**

```javascript
const systemRatio = await ethCdp.getSystemCollateralization();
```

* **Params:** none
* **Returns:** promise (resolves to system collateralization ratio)

`getSystemCollateralization()` returns the collateralization ratio for the entire system, e.g. 2.75

## **getTargetPrice**

```javascript
const targetPrice = await ethCdp.getTargetPrice();
```

* **Params:** none
* **Returns:** promise (resolves to target price)

`getTargetPrice()` returns the target price of Dai in USD, that is, the value to which Dai is soft-pegged, which historically has been 1.  It returns a `USD_DAI` [price unit](#units).