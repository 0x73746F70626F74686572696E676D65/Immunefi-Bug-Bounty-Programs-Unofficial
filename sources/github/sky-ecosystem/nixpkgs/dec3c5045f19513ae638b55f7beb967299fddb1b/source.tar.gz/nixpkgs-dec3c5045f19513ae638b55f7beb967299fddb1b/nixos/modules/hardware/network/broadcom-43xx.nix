{
  hardware.enableRedistributableFirmware = true;
}
