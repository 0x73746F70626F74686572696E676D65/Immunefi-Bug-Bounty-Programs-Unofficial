{
  value = 42;
}
