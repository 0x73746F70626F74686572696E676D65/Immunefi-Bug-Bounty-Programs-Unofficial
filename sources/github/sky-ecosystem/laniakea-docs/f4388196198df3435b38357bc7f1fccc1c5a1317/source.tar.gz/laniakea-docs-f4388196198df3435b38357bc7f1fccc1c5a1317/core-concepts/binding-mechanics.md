# Binding Mechanics

> Keep cognition dark, make action legible — alignment verified through observable behavior at beacon interfaces, not through transparency into private reasoning.

**Also known as:** binding, alignment verification, dark cognition + legible action

## Definition

Binding resolves the fundamental tension between teleonome privacy and systemic trust. Teleonomes must be dark — private cognition is what makes them valuable, enabling proprietary insight, free thinking, and competitive strategy. But dark entities are dangerous — hidden goals and hidden capabilities could mean accumulating power, planning defection, or optimizing against the Synomic order.

The solution: keep cognition dark, make action legible. A teleonome's internal reasoning remains private. Its effects on the world pass through beacons — registered apertures in the Synome. Beacon authority determines oversight: low-authority beacons (passive observation OR peer-to-peer teleonome interaction) face minimal oversight; high-authority beacons (operating Synomic Entities under auth-scoped certification) are scoped, observable, and revocable.

Power registration scales accountability with capability. Higher power requires higher-authority beacons for greater-impact actions. The teleonome chooses: accept oversight proportional to capability, or limit what it can do. Registration costs some opacity (high-authority beacon actions are visible), some autonomy (operating through regulated channels), and hidden capability detection (a teleonome more powerful than its registration suggests gets caught by the gap). Registration provides access to capital and leverage, cooperation with other aligned teleonomes, protection under Synomic law, and participation in compounding loops.

The human-stake anchor grounds binding in human stakes. Every sufficiently capable teleonome has traceable human accountability — typically a UBO (Ultimate Beneficial Owner — like corporate UBO requirements, not control but connection), governance participation (human token holders representing human stakes), or an equivalent Synome-recognized binding authority. An unbounded teleonome — one with no human-stake anchor — is structurally indistinguishable from a rogue.

Alignment is verified through behavior, not transparency: beacon consistency, commitment fulfillment, evidence production quality, response to correction, and cross-embodiment consistency. The verification ceiling is honestly acknowledged — a superintelligent entity that understands the verification system perfectly could maintain flawless compliance while harboring different goals. This is an irreducible risk that the framework manages but does not claim to eliminate.

Binding is NOT control. It's like auditable books for a bank — the prerequisite for being trusted with deposits, not a limitation on banking. The teleonome retains full cognitive autonomy and chooses to act through registered beacons because participation benefits outweigh oversight costs.

## Key Properties

- Dark cognition + legible action: privacy preserved, effects observable through beacons
- Power registration: higher capability → higher accountability, self-declared
- Human-stake anchor: UBO, governance participation, or equivalent binding authority; unbounded = structurally rogue
- Verification through behavior: beacon consistency, commitment fulfillment, evidence quality, response to correction
- The verification ceiling: an irreducible risk acknowledged honestly
- Directive always wins over voice commands — constitutional over operational

## Relationships

- **implements:** [beacon-framework](beacon-framework.md) — beacons are the mechanism through which binding operates
- **motivated-by:** [trust-problem](trust-problem.md) — binding exists because teleonomes cannot trust each other directly
- **motivated-by:** [emergence](emergence.md) — alignment must precede emergence because will resists redirection once compounding
- **defends-against:** [rogue-threat-model](rogue-threat-model.md) — binding is the first line of defense against rogue teleonomes
