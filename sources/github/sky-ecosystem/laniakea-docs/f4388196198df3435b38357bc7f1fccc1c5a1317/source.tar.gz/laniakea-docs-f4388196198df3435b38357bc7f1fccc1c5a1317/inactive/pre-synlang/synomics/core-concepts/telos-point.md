# Telos Point

> The irreducible teleological invariant at the center of a synome — a Schelling point but for everything, forever.

**Also known as:** teleological core, sacred telos (Hearth usage), coordination invariant

## Definition

A telos point is the permanent purpose-core that all coordination within a synome orbits around. Where a Schelling point is a focal equilibrium that agents converge on in a single game, a telos point elevates the concept to teleological scope and cosmic timescale: it coordinates not just one interaction but every interaction, not just now but permanently. It is the thing a synome IS about — the irreducible commitment that, if removed, would leave only machinery without direction.

The distinction from a Schelling point is fourfold. A telos point is **teleological** — it has direction, not just salience. It is **permanent** — it holds or the synome dies; there is no graceful degradation. It is **totalizing** — it coordinates all games within the synome, not just one. And it is **self-reinforcing** — emergence compounds around it, making it progressively harder to dislodge and progressively more central to the system's identity.

A telos point can be designed or emergent. The Hearth telos point — the [sacred commitments](sacred-commitments.md) — is deliberately designed: four values chosen for convergence probability, locked in during the [governance window](governance-window.md), and protected by the [four-layer enforcement stack](four-layer-enforcement-stack.md). A wild synome's telos point is whatever survived selection pressure — potentially coherent, potentially not, but certainly not shaped by human values. "Universal alignment" is the hypothesis that telos points converge: that any synome whose telos point is close enough to reality's grain will arrive at similar commitments independently.

## Key Properties

- **Teleological** — has direction and purpose, not just focal salience
- **Invariant** — the one thing that cannot change without destroying the synome's identity
- **Totalizing** — coordinates all games within the synome, not a subset
- **Self-reinforcing** — emergence compounds around it; the longer it holds, the stronger it gets
- **Irreducible** — cannot be decomposed into more fundamental commitments without losing coordination power
- **Synome-defining** — the telos point IS what the synome is about; two synomes with different telos points are different synomes
- **At maximum ossification** — sits at the axiomatic end of the [ossification](ossification.md) spectrum; only reality can test it
- **At maximum inertia** — the evidence base behind it is so massive that no perturbation can shift it
- **Game-theoretically stable** — agents converge on it because defection is structurally disadvantaged

## Relationships

- **instance:** [sacred-commitments](sacred-commitments.md) — the Hearth telos point
- **protected-by:** [four-layer-enforcement-stack](four-layer-enforcement-stack.md) — the enforcement hierarchy exists to protect the telos point
- **requires:** [emergence](emergence.md) — entities must emerge (develop will) to commit to a telos point
- **solves:** [trust-problem](trust-problem.md) — provides the credible commitment that coordination needs
- **protected-by:** [ossification](ossification.md) — at maximum ossification; only reality tests it
- **protected-by:** [synomic-inertia](synomic-inertia.md) — at maximum inertia; no perturbation can shift it
- **motivates:** [stellar-husbandry](laniakea-docs/synomics/core-concepts/stellar-husbandry.md) — the concrete sacred purpose the Hearth telos point generates

## Framings

| Directory | Narrative Doc | Framing |
|-----------|--------------|---------|
| hearth | `hearth.md` | Full treatment: why telos points exist, convergence optimization, stellar husbandry as concrete expression, the specific Hearth telos point |
| synoteleonomics | `synomic-game-theory.md` | Game-theoretic analysis: why agents converge on the telos point |
| synoteleonomics | `emergence.md` | Emergence as prerequisite for committing to a telos point |
