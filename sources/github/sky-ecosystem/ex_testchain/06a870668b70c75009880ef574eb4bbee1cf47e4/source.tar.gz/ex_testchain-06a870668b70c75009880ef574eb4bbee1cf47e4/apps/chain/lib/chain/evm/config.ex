defmodule Chain.EVM.Config do
  @moduledoc """
  Default start configuration for new EVM.

  Options:
  - `type` - EVM type. (Default: `:ganache`)
  - `id` - Random unique internal process identificator. Example: `"11296068888839073704"`. If empty system will generate it automatically
  - `http_port` - HTTP JSONRPC port. In case of `nil` - port will be randomly assigned (Default: `nil`)
  - `ws_port` - WS JSONRPC port, in case of `nil` - port will be randomly assigned
  (for ganache it will be ignored and `http_port` will be used) (Default: `nil`)
  - `network_id` - Network ID (Default: `Application.get_env(:chain, :default_chain_id)`)
  - `db_path` - Specify a path to a directory to save the chain database
  - `block_mine_time` - Block period to use in developer mode (0 = mine only if transaction pending) (default: 0)
  - `gas_limit` - The block gas limit (defaults to `9000000000000`)
  - `accounts` - How many accoutn should be created on start (Default: `1`)
  - `notify_pid` - Internal process id that will be notified on some chain events
  - `output` - Path to logs file. If empty string passing logs will be stored into `db_path <> /out.log`. To disable logging pass `nil`
  - `clean_on_stop` - Clean up `db_path` after chain is stopped. (Default: `false`)
  - `description` - Chain description for storage
  - `snapshot_id` - Snapshot ID that should be loaded on chain start

  """

  require Logger

  @type t :: %__MODULE__{
          type: Chain.evm_type(),
          id: Chain.evm_id() | nil,
          http_port: non_neg_integer() | nil,
          ws_port: non_neg_integer() | nil,
          network_id: non_neg_integer(),
          db_path: binary(),
          block_mine_time: non_neg_integer(),
          gas_limit: pos_integer(),
          accounts: non_neg_integer(),
          output: binary,
          notify_pid: nil | pid(),
          clean_on_stop: boolean(),
          description: binary,
          snapshot_id: nil | binary
        }

  defstruct type: :ganache,
            id: nil,
            http_port: nil,
            ws_port: nil,
            network_id: Application.get_env(:chain, :default_chain_id),
            db_path: "",
            block_mine_time: 0,
            gas_limit: 9_000_000_000_000,
            accounts: 1,
            output: "",
            notify_pid: nil,
            clean_on_stop: false,
            description: "",
            snapshot_id: nil

  @doc """
  Will clean `db_path` if `clean_on_stop` is set to true
  Otherwise it will do nothing and will return `:ok`
  """
  @spec clean_on_stop(Chain.EVM.Config.t()) :: :ok | {:error, term()}
  def clean_on_stop(%__MODULE__{clean_on_stop: false}), do: :ok

  def clean_on_stop(%__MODULE__{id: id, clean_on_stop: true, db_path: db_path}) do
    case File.rm_rf(db_path) do
      {:error, err} ->
        Logger.error("#{id}: Failed to clean up #{db_path} with error: #{inspect(err)}")
        {:error, err}

      _ ->
        Logger.debug("#{id}: Cleaned path after termination #{db_path}")
        :ok
    end
  end
end
