@test "truth" {
  true
}