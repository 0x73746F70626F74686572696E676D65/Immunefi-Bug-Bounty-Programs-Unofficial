@test "foo" {
  echo "foo"
}
