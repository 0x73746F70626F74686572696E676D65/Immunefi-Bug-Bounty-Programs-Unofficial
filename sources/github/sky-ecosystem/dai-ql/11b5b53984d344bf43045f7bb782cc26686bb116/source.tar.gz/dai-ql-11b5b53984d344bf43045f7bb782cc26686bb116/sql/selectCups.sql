SELECT * FROM cups;
