# storage layout
