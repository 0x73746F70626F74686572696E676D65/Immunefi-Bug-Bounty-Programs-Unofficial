-- +goose Up
CREATE TABLE maker.vow_vat
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    vat       TEXT,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, vat)
);

CREATE INDEX vow_vat_header_id_index
    ON maker.vow_vat (header_id);

CREATE TABLE maker.vow_flapper
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    flapper   TEXT,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, flapper)
);

CREATE INDEX vow_flapper_header_id_index
    ON maker.vow_flapper (header_id);

CREATE TABLE maker.vow_flopper
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    flopper   TEXT,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, flopper)
);

CREATE INDEX vow_flopper_header_id_index
    ON maker.vow_flopper (header_id);

CREATE TABLE maker.vow_sin_integer
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    sin       NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, sin)
);

CREATE INDEX vow_sin_integer_header_id_index
    ON maker.vow_sin_integer (header_id);

CREATE TABLE maker.vow_sin_mapping
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    era       NUMERIC,
    tab       NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, era, tab)
);

CREATE INDEX vow_sin_mapping_header_id_index
    ON maker.vow_sin_mapping (header_id);
CREATE INDEX vow_sin_mapping_era_index
    ON maker.vow_sin_mapping (era);

CREATE TABLE maker.vow_ash
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    ash       NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, ash)
);

CREATE INDEX vow_ash_header_id_index
    ON maker.vow_ash (header_id);

CREATE TABLE maker.vow_wait
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    wait      NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, wait)
);

CREATE INDEX vow_wait_header_id_index
    ON maker.vow_wait (header_id);

CREATE TABLE maker.vow_dump
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    dump      NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, dump)
);

CREATE INDEX vow_dump_header_id_index
    ON maker.vow_dump (header_id);

CREATE TABLE maker.vow_sump
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    sump      NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, sump)
);

CREATE INDEX vow_sump_header_id_index
    ON maker.vow_sump (header_id);

CREATE TABLE maker.vow_bump
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    bump      NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, bump)
);

CREATE INDEX vow_bump_header_id_index
    ON maker.vow_bump (header_id);

CREATE TABLE maker.vow_hump
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    hump      NUMERIC,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, hump)
);

CREATE INDEX vow_hump_header_id_index
    ON maker.vow_hump (header_id);

CREATE TABLE maker.vow_live
(
    id        SERIAL PRIMARY KEY,
    diff_id   BIGINT  NOT NULL REFERENCES storage_diff (id) ON DELETE CASCADE,
    live      NUMERIC NOT NULL,
    header_id INTEGER NOT NULL REFERENCES headers (id) ON DELETE CASCADE,
    UNIQUE (diff_id, header_id, live)
);

CREATE INDEX vow_live_header_id_index
    ON maker.vow_live (header_id);

-- +goose Down
DROP TABLE maker.vow_vat;
DROP TABLE maker.vow_flapper;
DROP TABLE maker.vow_flopper;
DROP TABLE maker.vow_sin_integer;
DROP TABLE maker.vow_sin_mapping;
DROP TABLE maker.vow_ash;
DROP TABLE maker.vow_wait;
DROP TABLE maker.vow_dump;
DROP TABLE maker.vow_sump;
DROP TABLE maker.vow_bump;
DROP TABLE maker.vow_hump;
DROP TABLE maker.vow_live;
