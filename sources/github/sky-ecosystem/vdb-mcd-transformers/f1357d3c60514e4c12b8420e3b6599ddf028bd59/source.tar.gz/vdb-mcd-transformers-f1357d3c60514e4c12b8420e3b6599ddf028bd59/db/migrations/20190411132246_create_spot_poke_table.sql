-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE maker.spot_poke
(
    id        SERIAL PRIMARY KEY,
    log_id    BIGINT  NOT NULL REFERENCES public.event_logs (id) ON DELETE CASCADE,
    value     NUMERIC,
    spot      NUMERIC,
    header_id INTEGER NOT NULL REFERENCES public.headers (id) ON DELETE CASCADE,
    ilk_id    INTEGER NOT NULL REFERENCES maker.ilks (id) ON DELETE CASCADE,
    UNIQUE (header_id, log_id)
);

CREATE INDEX spot_poke_header_index
    ON maker.spot_poke (header_id);
CREATE INDEX spot_poke_log_index
    ON maker.spot_poke (log_id);
CREATE INDEX spot_poke_ilk_index
    ON maker.spot_poke (ilk_id);


-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP INDEX maker.spot_poke_header_index;
DROP INDEX maker.spot_poke_log_index;
DROP INDEX maker.spot_poke_ilk_index;

DROP TABLE maker.spot_poke;
