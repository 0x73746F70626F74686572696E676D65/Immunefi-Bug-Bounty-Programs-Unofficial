Inputs for Mainnet scripts.
