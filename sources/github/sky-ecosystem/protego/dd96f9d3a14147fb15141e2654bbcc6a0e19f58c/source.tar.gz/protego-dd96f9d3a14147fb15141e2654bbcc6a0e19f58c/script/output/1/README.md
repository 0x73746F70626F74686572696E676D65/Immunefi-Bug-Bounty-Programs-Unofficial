Outputs for Mainnet scripts.
