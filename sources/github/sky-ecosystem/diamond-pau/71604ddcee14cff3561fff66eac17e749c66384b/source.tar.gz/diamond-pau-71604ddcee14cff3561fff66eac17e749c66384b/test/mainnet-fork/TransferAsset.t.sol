// SPDX-License-Identifier: AGPL-3.0-or-later
pragma solidity ^0.8.34;

import { ReentrancyGuard } from "../../lib/openzeppelin-contracts/contracts/utils/ReentrancyGuard.sol";

import { Ethereum } from "../../lib/spark-address-registry/src/Ethereum.sol";

import { ITransferAssetFacet } from "../../src/facets/transfer-asset/ITransferAssetFacet.sol";

import { MockTokenReturnFalse, MockTokenReturn64Bytes } from "../mocks/Mocks.sol";

import { ForkTestBase } from "./ForkTestBase.t.sol";

interface IERC20Like {

    function balanceOf(address account) external view returns (uint256);

}

abstract contract TransferAsset_TestBase is ForkTestBase {

    IERC20Like internal constant USDT = IERC20Like(Ethereum.USDT);

    address internal receiver = makeAddr("receiver");

    function setUp() public override {
        super.setUp();

        vm.startPrank(Ethereum.SPARK_PROXY);

        rateLimits.setRateLimitData(
            mainnetController.transferAsset_getTransferRateLimitKey(Ethereum.USDC, receiver),
            1_000_000e6,
            uint256(1_000_000e6) / 1 days
        );

        vm.stopPrank();
    }

}

contract MainnetController_TransferAsset_Tests is TransferAsset_TestBase {

    function test_transferAsset_reentrancy() external {
        _setControllerEntered();
        vm.expectRevert(ReentrancyGuard.ReentrancyGuardReentrantCall.selector);
        mainnetController.transferAsset_transfer(Ethereum.USDC, receiver, 1_000_000e6);
    }

    function test_transferAsset_notAllocator() external {
        vm.expectRevert(abi.encodeWithSignature(
            "AccessControlUnauthorizedAccount(address,bytes32)",
            address(this),
            ALLOCATOR_ROLE
        ));
        mainnetController.transferAsset_transfer(Ethereum.USDC, receiver, 1_000_000e6);
    }

    function test_transferAsset_zeroMaxAmount() external {
        vm.expectRevert("RateLimits/zero-maxAmount");
        vm.prank(allocator);
        mainnetController.transferAsset_transfer(makeAddr("fake-token"), receiver, 1e18);
    }

    function test_transferAsset_rateLimitedBoundary() external {
        deal(Ethereum.USDC, address(almProxy), 1_000_000e6 + 1);

        vm.expectRevert("RateLimits/rate-limit-exceeded");
        vm.prank(allocator);
        mainnetController.transferAsset_transfer(Ethereum.USDC, receiver, 1_000_000e6 + 1);

        vm.prank(allocator);
        mainnetController.transferAsset_transfer(Ethereum.USDC, receiver, 1_000_000e6);
    }

    function test_transferAsset_transferFailedOnReturnFalse() external {
        MockTokenReturnFalse token = new MockTokenReturnFalse();

        vm.startPrank(Ethereum.SPARK_PROXY);

        rateLimits.setRateLimitData(
            mainnetController.transferAsset_getTransferRateLimitKey(address(token), receiver),
            1_000_000e18,
            uint256(1_000_000e18) / 1 days
        );

        vm.stopPrank();

        deal(address(token), address(almProxy), 1_000_000e18);

        vm.expectRevert("TransferAssetFacet/transfer-failed");
        vm.prank(allocator);
        mainnetController.transferAsset_transfer(address(token), receiver, 1_000_000e18);
    }

    function test_transferAsset_transferFailedOnNonStandardReturnData() external {
        MockTokenReturn64Bytes token = new MockTokenReturn64Bytes();

        bytes32 key = mainnetController.transferAsset_getTransferRateLimitKey(address(token), receiver);

        vm.prank(Ethereum.SPARK_PROXY);
        rateLimits.setRateLimitData(key, 1_000_000e18, uint256(1_000_000e18) / 1 days);

        vm.expectRevert("TransferAssetFacet/transfer-failed");
        vm.prank(allocator);
        mainnetController.transferAsset_transfer(address(token), receiver, 1_000_000e18);
    }

    function test_transferAsset() external {
        deal(Ethereum.USDC, address(almProxy), 2_000_000e6);
        deal(Ethereum.USDC, receiver,          1_000_000e6);

        assertEq(usdc.balanceOf(receiver),          1_000_000e6);
        assertEq(usdc.balanceOf(address(almProxy)), 2_000_000e6);

        vm.record();

        vm.expectEmit(address(mainnetController));
        emit ITransferAssetFacet.TransferAssetTransfer(Ethereum.USDC, receiver, 1_000_000e6);

        vm.prank(allocator);
        mainnetController.transferAsset_transfer(Ethereum.USDC, receiver, 1_000_000e6);

        _assertReentrancyGuardWrittenToTwice();

        assertEq(usdc.balanceOf(receiver),          2_000_000e6);
        assertEq(usdc.balanceOf(address(almProxy)), 1_000_000e6);
    }

    function test_transferAsset_successNoReturnData() external {
        vm.startPrank(Ethereum.SPARK_PROXY);

        rateLimits.setRateLimitData(
            mainnetController.transferAsset_getTransferRateLimitKey(Ethereum.USDT, receiver),
            1_000_000e6,
            uint256(1_000_000e6) / 1 days
        );

        vm.stopPrank();

        deal(Ethereum.USDT, address(almProxy), 2_000_000e6);
        deal(Ethereum.USDT, receiver,          1_000_000e6);

        assertEq(USDT.balanceOf(receiver),          1_000_000e6);
        assertEq(USDT.balanceOf(address(almProxy)), 2_000_000e6);

        vm.expectEmit(address(mainnetController));
        emit ITransferAssetFacet.TransferAssetTransfer(Ethereum.USDT, receiver, 1_000_000e6);

        vm.prank(allocator);
        mainnetController.transferAsset_transfer(Ethereum.USDT, receiver, 1_000_000e6);

        assertEq(USDT.balanceOf(receiver),          2_000_000e6);
        assertEq(USDT.balanceOf(address(almProxy)), 1_000_000e6);
    }

}
