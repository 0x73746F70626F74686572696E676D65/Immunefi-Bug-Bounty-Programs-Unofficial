import {ExecutorOptionType} from '@layerzerolabs/lz-v2-utilities';
import {OAppEnforcedOption, OmniPointHardhat} from '@layerzerolabs/toolbox-hardhat';
import {EndpointId} from '@layerzerolabs/lz-definitions';
import {generateConnectionsConfig} from '@layerzerolabs/metadata-tools';

export const ethereumContract: OmniPointHardhat = {
  eid: EndpointId.ETHEREUM_V2_MAINNET,
  contractName: 'SkyOFTAdapter',
};

export const solanaContract: OmniPointHardhat = {
  eid: EndpointId.SOLANA_V2_MAINNET,
  address: 'BEvTHkTyXooyaJzP8egDUC7WQK8cyRrq5WvERZNWhuah',
};

const EVM_ENFORCED_OPTIONS: OAppEnforcedOption[] = [
  {
    msgType: 1,
    optionType: ExecutorOptionType.LZ_RECEIVE,
    gas: 130000,
    value: 0,
  },
  {
    msgType: 2,
    optionType: ExecutorOptionType.LZ_RECEIVE,
    gas: 130000,
    value: 0,
  },
];

const CU_LIMIT = 200000 // This represents the CU limit for executing the `lz_receive` function on Solana.
const SPL_TOKEN_ACCOUNT_RENT_VALUE = 2039280 // This figure represents lamports (https://solana.com/docs/references/terminology#lamport) on Solana. Read below for more details.
/*
 *  Elaboration on `value` when sending OFTs to Solana:
 *   When sending OFTs to Solana, SOL is needed for rent (https://solana.com/docs/core/accounts#rent) to initialize the recipient's token account.
 *   The `2039280` lamports value is the exact rent value needed for SPL token accounts (0.00203928 SOL).
 *   For Token2022 token accounts, you will need to increase `value` to a higher amount, which depends on the token account size, which in turn depends on the extensions that you enable.
 */

const SOLANA_ENFORCED_OPTIONS: OAppEnforcedOption[] = [
    {
      msgType: 1,
      optionType: ExecutorOptionType.LZ_RECEIVE,
      gas: CU_LIMIT,
      value: SPL_TOKEN_ACCOUNT_RENT_VALUE,
    },
    {
      msgType: 2,
      optionType: ExecutorOptionType.LZ_RECEIVE,
      gas: CU_LIMIT,
      value: SPL_TOKEN_ACCOUNT_RENT_VALUE,
    },
]

export default async function () {
  // note: pathways declared here are automatically bidirectional
  // if you declare A,B there's no need to declare B,A
  const connections = await generateConnectionsConfig([
    [
      ethereumContract, // Chain A contract
      solanaContract, // Chain B contract
      [['LayerZero Labs', 'Nethermind'], []], // [ requiredDVN[], [ optionalDVN[], threshold ] ]
      [15, 32], // [A to B confirmations, B to A confirmations]
      [SOLANA_ENFORCED_OPTIONS, EVM_ENFORCED_OPTIONS], // Chain B enforcedOptions, Chain A enforcedOptions
    ],
  ]);

  return {
    contracts: [
      {
        contract: ethereumContract,
        config: {
          delegate: '0xBE8E3e3618f7474F8cB1d074A26afFef007E98FB',
          owner: '0xBE8E3e3618f7474F8cB1d074A26afFef007E98FB',
        }
      },
      {
        contract: solanaContract,
        config: {
          delegate: 'AYPtjx4Hc8us1ikULUedkmZ3wtiD6tmL7gK3qe4V3oHt',
          owner: 'AYPtjx4Hc8us1ikULUedkmZ3wtiD6tmL7gK3qe4V3oHt',
        }
      }],
    connections,
  };
}