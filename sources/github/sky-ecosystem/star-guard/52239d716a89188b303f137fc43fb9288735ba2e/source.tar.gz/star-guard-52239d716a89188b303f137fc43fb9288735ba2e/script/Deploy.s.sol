// SPDX-FileCopyrightText: © 2025 Dai Foundation <www.daifoundation.org>
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

pragma solidity ^0.8.24;

import {Script, console} from "forge-std/Script.sol";
import {StarGuard} from "../src/StarGuard.sol";

contract Deploy is Script {
    StarGuard starGuard;

    function setUp() public {}

    function run(address subProxy) public {
        vm.startBroadcast();

        starGuard = new StarGuard(subProxy);

        vm.stopBroadcast();
    }
}
