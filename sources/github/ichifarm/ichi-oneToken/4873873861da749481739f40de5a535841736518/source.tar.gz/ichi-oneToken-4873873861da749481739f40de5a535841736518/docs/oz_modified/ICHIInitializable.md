## `ICHIInitializable`





### `initializer()`





### `initialized()`







