## `IVoterRoll`







