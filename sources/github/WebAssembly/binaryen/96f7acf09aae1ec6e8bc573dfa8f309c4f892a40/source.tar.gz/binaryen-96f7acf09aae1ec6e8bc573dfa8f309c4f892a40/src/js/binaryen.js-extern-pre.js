var binaryen = {};
(function() {