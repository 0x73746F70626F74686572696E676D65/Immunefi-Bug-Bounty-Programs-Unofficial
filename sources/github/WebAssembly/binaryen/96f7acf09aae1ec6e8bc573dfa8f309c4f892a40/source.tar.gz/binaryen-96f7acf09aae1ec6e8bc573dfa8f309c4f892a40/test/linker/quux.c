void quux() {}
