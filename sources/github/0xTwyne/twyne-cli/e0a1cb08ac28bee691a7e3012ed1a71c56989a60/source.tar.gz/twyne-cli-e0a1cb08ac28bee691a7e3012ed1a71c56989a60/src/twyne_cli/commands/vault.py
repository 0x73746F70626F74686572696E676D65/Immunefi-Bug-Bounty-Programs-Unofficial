"""Vault commands — health, info, list."""

import click

from ..cache import get_vault_cache
from ..completions import complete_vault_address
from ..constants import USD_ADDRESS, WAD
from ..context import TwyneContext, pass_ctx
from ..contracts import (
    aave_oracle,
    aave_v3_pool,
    collateral_vault,
    euler_oracle,
)
from ..formatting import (
    format_address,
    format_bps,
    format_usd,
    is_tty,
    output_json,
    output_kv,
    output_table,
)


def _detect_protocol(cv_contract, block: int | None) -> str:
    """Detect whether a collateral vault is Aave or Euler based."""
    from ape.exceptions import ContractLogicError

    try:
        atoken = cv_contract.aToken(block_identifier=block)
        if atoken and int(atoken, 16) != 0:
            return "aave"
        return "euler"
    except (ContractLogicError, Exception):
        return "euler"


@click.group()
def vault():
    """Query collateral vault state."""
    pass


@vault.command()
@click.argument("address", shell_complete=complete_vault_address)
@pass_ctx
def health(ctx: TwyneContext, address: str):
    """Show health factors for a collateral vault."""
    click.echo(
        "Error: HealthStatViewer contract removed in v1.0.5. "
        "Health queries temporarily unavailable. "
        "Use 'twyne vault info' for basic vault state.",
        err=True,
    )
    raise SystemExit(1)


@vault.command()
@click.argument("address", shell_complete=complete_vault_address)
@pass_ctx
def info(ctx: TwyneContext, address: str):
    """Show full state of a collateral vault."""
    from ape_ethereum.multicall import Call

    ctx.connect()
    try:
        block = ctx.resolve_block()
        cv = collateral_vault(address)

        # Phase 1: basic vault state via multicall
        call1 = Call()
        call1.add(cv.totalAssetsDepositedOrReserved)
        call1.add(cv.maxRelease)
        call1.add(cv.maxRepay)
        call1.add(cv.asset)
        call1.add(cv.targetAsset)
        call1.add(cv.twyneLiqLTV)
        call1.add(cv.borrower)
        call1.add(cv.canLiquidate)
        call1.add(cv.canRebalance)

        results1 = list(call1(block_identifier=block))
        total_assets = results1[0]
        max_release = results1[1]  # credit reserved (C_LP)
        max_repay = results1[2]    # debt (B)
        asset_addr = results1[3]
        target_asset_addr = results1[4]
        twyne_liq_ltv = results1[5]
        borrower = results1[6]
        can_liquidate = results1[7]
        can_rebalance = results1[8]

        user_collateral = total_assets - max_release

        # Detect protocol and get USD values
        is_aave = _detect_protocol(cv, block) == "aave"

        if is_aave:
            oracle = aave_oracle()
            pool = aave_v3_pool()

            call2 = Call()
            call2.add(oracle.getQuote, total_assets, asset_addr, USD_ADDRESS)
            call2.add(oracle.getQuote, max_release, asset_addr, USD_ADDRESS)
            call2.add(oracle.getQuote, user_collateral, asset_addr, USD_ADDRESS)
            call2.add(pool.getUserAccountData, address)

            results2 = list(call2(block_identifier=block))
            total_assets_usd = results2[0] / WAD
            credit_usd = results2[1] / WAD
            user_coll_usd = results2[2] / WAD
            debt_usd = results2[3].totalDebtBase / 1e8
        else:
            oracle = euler_oracle()

            call2 = Call()
            call2.add(oracle.getQuote, total_assets, asset_addr, USD_ADDRESS)
            call2.add(oracle.getQuote, max_release, asset_addr, USD_ADDRESS)
            call2.add(oracle.getQuote, user_collateral, asset_addr, USD_ADDRESS)
            call2.add(oracle.getQuote, max_repay, target_asset_addr, USD_ADDRESS)

            results2 = list(call2(block_identifier=block))
            total_assets_usd = results2[0] / WAD
            credit_usd = results2[1] / WAD
            user_coll_usd = results2[2] / WAD
            debt_usd = results2[3] / WAD

        # Operating LTV = debt / user_collateral (in USD terms)
        operating_ltv = (debt_usd / user_coll_usd * 100) if user_coll_usd > 0 else 0.0

        protocol_type = "Aave V3" if is_aave else "Euler"

        if ctx.force_json or not is_tty():
            output_json({
                "vault": address,
                "borrower": borrower,
                "protocol": protocol_type,
                "collateral_asset": asset_addr,
                "borrow_asset": target_asset_addr,
                "total_assets_raw": str(total_assets),
                "credit_reserved_raw": str(max_release),
                "user_collateral_raw": str(user_collateral),
                "debt_raw": str(max_repay),
                "total_assets_usd": total_assets_usd,
                "credit_reserved_usd": credit_usd,
                "user_collateral_usd": user_coll_usd,
                "debt_usd": debt_usd,
                "twyne_liq_ltv_bps": twyne_liq_ltv,
                "twyne_liq_ltv_pct": twyne_liq_ltv / 100,
                "operating_ltv_pct": operating_ltv,
                "can_liquidate": can_liquidate,
                "can_rebalance": can_rebalance,
                "note": "Health factors unavailable — HealthStatViewer removed in v1.0.5",
            })
        else:
            output_kv([
                ("Vault", address),
                ("Borrower", borrower),
                ("Protocol", protocol_type),
                ("Collateral Asset", asset_addr),
                ("Borrow Asset", target_asset_addr),
                ("", ""),
                ("User Collateral (C)", format_usd(user_coll_usd)),
                ("Credit Reserved (C_LP)", format_usd(credit_usd)),
                ("Total Assets (C+C_LP)", format_usd(total_assets_usd)),
                ("Debt (B)", format_usd(debt_usd)),
                ("", ""),
                ("Liquidation LTV", format_bps(twyne_liq_ltv)),
                ("Operating LTV", f"{operating_ltv:.2f}%"),
                ("External HF", "N/A (HealthStatViewer removed)"),
                ("Internal HF", "N/A (HealthStatViewer removed)"),
                ("", ""),
                ("Can Liquidate", str(can_liquidate)),
                ("Can Rebalance", str(can_rebalance)),
            ], title="Vault Info")
    finally:
        ctx.disconnect()


@vault.command()
@click.argument("address", shell_complete=complete_vault_address)
@click.option("--tx-file", type=click.Path(exists=True), help="JSON tx file {to,from,data,value,chainId} to simulate")
@click.option("--to", "to_addr", help="Target contract (inline tx; overrides --tx-file)")
@click.option("--data", "data_hex", help="Calldata hex (inline tx)")
@click.option("--from", "from_addr", help="Sender to impersonate (inline tx)")
@click.option("--value", default=0, help="Wei value (inline tx)")
@click.option("--block", type=int, default=None, help="Fork at a historical block (default: latest)")
@click.option("--fork-url", default=None, help="Upstream RPC to fork (default: resolved per chain)")
@click.option("--rpc", "attach_rpc", default=None, help="Attach to an already-running fork instead of launching anvil")
@click.option("--hsv", default=None, help="HealthStatViewer address override")
@pass_ctx
def simulate(
    ctx: TwyneContext,
    address: str,
    tx_file: str | None,
    to_addr: str | None,
    data_hex: str | None,
    from_addr: str | None,
    value,
    block: int | None,
    fork_url: str | None,
    attach_rpc: str | None,
    hsv: str | None,
):
    """Simulate a tx against a collateral vault and show before/after state.

    Forks the chain with anvil, snapshots the CV's full state (collateral, debt,
    LTVs, USD values, health factors) before and after executing the calldata,
    and prints a side-by-side diff plus a safety verdict.

        twyne vault simulate <cv> --tx-file failing-repay-tx.json
    """
    from .. import simulate as sim

    if to_addr and data_hex:
        tx = {
            "to": to_addr,
            "from": from_addr or "0x0000000000000000000000000000000000000000",
            "data": data_hex,
            "value": value,
            "chainId": ctx.chain.chain_id,
        }
    elif tx_file:
        tx = sim.load_tx_file(tx_file)
    else:
        raise click.UsageError("provide --tx-file or both --to and --data")

    try:
        result = sim.simulate(
            cv_address=address, tx=tx, hsv_address=hsv, fork_url=fork_url, attach_rpc=attach_rpc, block=block
        )
    except Exception as e:  # noqa: BLE001
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1) from e

    if ctx.force_json or not is_tty():
        for k in ("_before_obj", "_after_obj", "_exec_obj"):
            result.pop(k, None)
        output_json(result)
    else:
        click.echo(sim.render_report(result))


@vault.command("list")
@pass_ctx
def list_vaults(ctx: TwyneContext):
    """List all collateral vaults (uses incremental cache)."""
    ctx.connect()
    try:
        cache = get_vault_cache(ctx)
        block = ctx.resolve_block()
        vaults = cache.get_vaults(up_to_block=block)

        if ctx.force_json or not is_tty():
            output_json({
                "total_vaults": len(vaults),
                "vaults": [
                    {"address": v.address, "block": v.block}
                    for v in vaults
                ],
            })
        else:
            rows = [
                [str(i + 1), format_address(v.address), v.address, str(v.block)]
                for i, v in enumerate(vaults)
            ]
            output_table(
                ["#", "Short", "Address", "Created Block"],
                rows,
                title=f"Collateral Vaults ({len(vaults)} total)",
            )
    finally:
        ctx.disconnect()
