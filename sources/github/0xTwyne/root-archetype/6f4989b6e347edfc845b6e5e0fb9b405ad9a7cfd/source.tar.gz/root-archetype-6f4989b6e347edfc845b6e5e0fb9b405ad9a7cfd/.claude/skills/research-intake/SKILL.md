---
name: research-intake
description: Ingest external sources into structured knowledge base. Use when user provides research material, URLs, papers, or says "research intake", "ingest this", "add to knowledge base". Do NOT use for querying existing knowledge (use project-wiki instead).
---

# Research Intake

Ingest external sources into the project's structured knowledge base.

Use when:

- User provides research material, URLs, papers, or articles
- User says "research intake", "ingest this", "add to knowledge base"
- Incorporating findings from external benchmarks or experiments

Do not use when:

- Querying existing knowledge (use project-wiki)
- Writing or editing application code
- Working on handoffs or session management

## Where to write

Research intake writes to the **log repo**, not the root repo. Resolve the log
repo path from `.archetype-manifest.json` (`log_repo_name`) via `repos/<name>`.

- Deep-dives → `<log-repo>/notes/<user>/research/<slug>.md`
- Per-user index → `<log-repo>/notes/<user>/research/intake_index.yaml`

Maintainers promote research to the master database
(`<knowledge-repo>/wiki/research/`) during master wiki compilation
(`/project-wiki compile --master`).

The knowledge repo's `wiki/research/intake_index.yaml` and `wiki/research/deep-dives/`
are the **curated master** — only updated by maintainer promotion, not by
individual intake. (Legacy location, pre-2026-08-29: root `knowledge/research/`.)

## Workflow

1. **Fetch** — Retrieve the source content (URL, file, or user-provided text)
2. **Dedup** — Check `<log-repo>/notes/<user>/research/intake_index.yaml` for existing entries with the same URL or title. Also check the master index at `<knowledge-repo>/wiki/research/intake_index.yaml`.
3. **Score** — Assess relevance to project using `<knowledge-repo>/wiki/taxonomy.yaml` categories
4. **Extract** — Summarize key findings, decisions, or data points
5. **Categorize** — Map to taxonomy categories; propose new categories if none fit
6. **Store** — Write structured deep-dive to `<log-repo>/notes/<user>/research/<slug>.md`
7. **Index** — Append entry to `<log-repo>/notes/<user>/research/intake_index.yaml`

## Deep-Dive Format

```markdown
# <Title>

**Source**: <URL or citation>
**Ingested**: <YYYY-MM-DD>
**Categories**: <comma-separated taxonomy categories>
**Confidence**: <verified|inferred|external>

## Summary

<2-3 paragraph summary of key findings>

## Key Takeaways

- <Actionable finding 1>
- <Actionable finding 2>

## Relevance to Project

<How this applies to current work>
```

## Index Entry Format

```yaml
- title: "<Title>"
  source: "<URL>"
  date: "<YYYY-MM-DD>"
  categories: [<category1>, <category2>]
  deep_dive: "<slug>.md"
  actioned: false
```

## Gotchas

- Always check for duplicates in both the per-user index AND the master index before ingesting
- Set `actioned: false` on new entries; the project-wiki lint pass flags un-actioned entries
- Confidence level `external` means the finding hasn't been validated against project code
- Deep-dive files are append-only; update the index entry rather than editing deep-dives
- Never write directly to `<knowledge-repo>/wiki/research/` — that's the maintainer-curated master. Individual intake always goes to `<log-repo>/notes/<user>/research/`
