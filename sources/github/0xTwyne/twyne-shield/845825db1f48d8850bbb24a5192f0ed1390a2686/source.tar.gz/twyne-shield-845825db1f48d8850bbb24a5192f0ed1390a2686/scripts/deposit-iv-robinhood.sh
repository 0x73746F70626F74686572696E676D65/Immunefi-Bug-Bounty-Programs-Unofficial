#!/usr/bin/env bash
# Deposit USDe into the Twyne intermediate vault on Robinhood Chain (LIVE, chainId 4663) as a Credit LP.
#
# This is the deposit that unblocks Shield migrations: the IV lends your USDe to collateral vaults as
# reserved credit (that's the CLP yield source). Withdrawals are subject to available cash — credit that
# is reserved by active vaults cannot be withdrawn until released.
#
# Usage:
#   AMOUNT is in USDe (whole tokens). Pick ONE auth method:
#
#   1) Encrypted keystore (recommended):  cast wallet import clp --interactive   # one-time
#      ACCOUNT=clp ./scripts/deposit-iv-robinhood.sh 5000
#
#   2) Ledger/Trezor:                     LEDGER=1 ./scripts/deposit-iv-robinhood.sh 5000
#
#   3) 1Password-injected key (no disk):  op run -- env PRIVATE_KEY="op://<vault>/<item>/private key" \
#                                           ./scripts/deposit-iv-robinhood.sh 5000
#
# Env overrides: RPC (default public Robinhood RPC), RECEIVER (default = sender).
set -euo pipefail

# bigint comparison helper (no bc in minimal containers)
lt() { python3 -c "import sys; sys.exit(0 if int(sys.argv[1]) < int(sys.argv[2]) else 1)" "$1" "$2"; }

# send + verify receipt status (cast send can exit 0 on a reverted tx — never trust the exit code)
send_checked() {
  local desc=$1; shift
  local out status
  out=$(cast send "$@" "${WALLET_ARGS[@]}" --rpc-url "$RPC" --json)
  status=$(python3 -c "import json,sys; print(json.loads(sys.argv[1])['status'])" "$out")
  if [[ "$status" != "0x1" ]]; then
    echo "ERROR: $desc reverted on-chain (status $status). Tx: $(python3 -c "import json,sys; print(json.loads(sys.argv[1])['transactionHash'])" "$out")" >&2
    exit 1
  fi
  echo "   $desc ok ($(python3 -c "import json,sys; print(json.loads(sys.argv[1])['transactionHash'])" "$out"))"
}

AMOUNT_USDE=${1:?usage: deposit-iv-robinhood.sh <amount-in-USDe>}
RPC=${RPC:-https://rpc.mainnet.chain.robinhood.com}

# tech-notes/robinhood-launch-addresses/RobinhoodDeployment_Jul11_2026 (live-verified 2026-07-11)
IV=0x87b8081A3ace680f35125F469526Ac10f5418Ca7
USDE=0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34

# ---- auth ----
WALLET_ARGS=()
if [[ -n "${ACCOUNT:-}" ]]; then
  WALLET_ARGS=(--account "$ACCOUNT")
elif [[ -n "${LEDGER:-}" ]]; then
  WALLET_ARGS=(--ledger)
elif [[ -n "${PRIVATE_KEY:-}" ]]; then
  WALLET_ARGS=(--private-key "$PRIVATE_KEY")
else
  echo "ERROR: set ACCOUNT=<cast keystore name>, LEDGER=1, or PRIVATE_KEY (via op run)." >&2
  exit 1
fi

SENDER=$(cast wallet address "${WALLET_ARGS[@]}")
RECEIVER=${RECEIVER:-$SENDER}
AMOUNT_WEI=$(cast to-wei "$AMOUNT_USDE")

# ---- safety checks ----
CHAIN_ID=$(cast chain-id --rpc-url "$RPC")
[[ "$CHAIN_ID" == "4663" ]] || { echo "ERROR: RPC is chain $CHAIN_ID, expected Robinhood (4663)." >&2; exit 1; }

BAL=$(cast call $USDE "balanceOf(address)(uint256)" "$SENDER" --rpc-url "$RPC" | awk '{print $1}')
if lt "$BAL" "$AMOUNT_WEI"; then
  echo "ERROR: USDe balance $(cast from-wei "$BAL") < requested $AMOUNT_USDE." >&2
  exit 1
fi

# Supply cap (Euler AmountCap uint16: amount = (cap >> 6) * 10^(cap & 63) / 100; 0 = uncapped).
read -r SUPPLY_CAP _ <<< "$(cast call $IV 'caps()(uint16,uint16)' --rpc-url "$RPC" | tr '\n' ' ')"
if [[ "$SUPPLY_CAP" != "0" ]]; then
  CAP_WEI=$(python3 -c "c=int('$SUPPLY_CAP'); print((c >> 6) * 10 ** (c & 63) // 100)")
  TOTAL=$(cast call $IV "totalAssets()(uint256)" --rpc-url "$RPC" | awk '{print $1}')
  HEADROOM=$(python3 -c "print(max(0, $CAP_WEI - $TOTAL))")
  echo "IV supply cap: $(cast from-wei "$CAP_WEI") USDe; current: $(cast from-wei "$TOTAL"); headroom: $(cast from-wei "$HEADROOM")"
  if lt "$HEADROOM" "$AMOUNT_WEI"; then
    echo "ERROR: deposit exceeds the vault's supply-cap headroom — reduce the amount or ask governance to raise the cap (setCaps, governor = VaultManager)." >&2
    exit 1
  fi
fi

echo "Depositing $AMOUNT_USDE USDe from $SENDER into IV $IV (shares to $RECEIVER) on chain $CHAIN_ID"

# ---- approve (exact amount; skip if allowance suffices) ----
ALLOWANCE=$(cast call $USDE "allowance(address,address)(uint256)" "$SENDER" $IV --rpc-url "$RPC" | awk '{print $1}')
if lt "$ALLOWANCE" "$AMOUNT_WEI"; then
  echo "-- approve"
  send_checked "approve" $USDE "approve(address,uint256)" $IV "$AMOUNT_WEI"
fi

# ---- deposit ----
# Explicit gas limit: the eVault's Permit2-attempt-then-fallback transfer path under-estimates and
# OOGs the EVK reentrancy sentry when sent with the bare estimate (unused gas is refunded).
echo "-- deposit"
send_checked "deposit" $IV "deposit(uint256,address)" "$AMOUNT_WEI" "$RECEIVER" --gas-limit 1500000

echo
echo "Done. Post-state:"
echo "  your IV shares: $(cast call $IV 'balanceOf(address)(uint256)' "$RECEIVER" --rpc-url "$RPC" | awk '{print $1}')"
echo "  IV cash:        $(cast call $IV 'cash()(uint256)' --rpc-url "$RPC" | awk '{print $1}')"
echo "Withdraw later with: cast send $IV 'redeem(uint256,address,address)' <shares> <you> <you> ... (subject to available cash)"
