#!/usr/bin/env bash
# Seed an anvil fork of Robinhood Chain (4663) for the Twyne Shield demo:
#   1. hand out USDe (impersonate the Morpho contract, which custodies supplied collateral)
#   2. CLP deposits USDe into the Twyne intermediate vault (live IV has zero CLP credit)
#   3. open a borrower position in the USDe/USDG market near the 91.5% lltv
# Prereq: `anvil --fork-url https://rpc.mainnet.chain.robinhood.com` on :8545.
# Keys are the standard anvil dev accounts, derived from the public test mnemonic at runtime.
set -euo pipefail

RPC=${RPC:-http://127.0.0.1:8545}
MN="test test test test test test test test test test test junk"
pk() { cast wallet private-key "$MN" "m/44'/60'/0'/0/$1"; }
addr() { cast wallet address --private-key "$(pk "$1")"; }

BORROWER=$(addr 2)
BORROWER_PK=$(pk 2)
CLP=$(addr 3)
CLP_PK=$(pk 3)

# tech-notes/robinhood-launch-addresses/RobinhoodDeployment_Jul11_2026 (live-verified)
MORPHO=0x9D53d5E3bd5E8d4Cbfa6DB1ca238AEA02E651010
USDE=0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34
USDG=0x5fc5360D0400a0Fd4f2af552ADD042D716F1d168
ORACLE=0xE64849bd4AD03DfaBbe02bb521de19997a19055f
IRM=0x2BD3d5965B26B51814AC95127B2b80dD6CcC0fa1
IV=0x87b8081A3ace680f35125F469526Ac10f5418Ca7
MP="($USDG,$USDE,$ORACLE,$IRM,915000000000000000)"

echo "--- 0. lift the IV supply cap (fork-only; governor = VaultManager)"
GOV=$(cast call $IV 'governorAdmin()(address)' --rpc-url $RPC)
cast rpc anvil_impersonateAccount "$GOV" --rpc-url $RPC > /dev/null
cast rpc anvil_setBalance "$GOV" 0xde0b6b3a7640000 --rpc-url $RPC > /dev/null
cast send $IV "setCaps(uint16,uint16)" 0 0 --from "$GOV" --unlocked --rpc-url $RPC > /dev/null
cast rpc anvil_stopImpersonatingAccount "$GOV" --rpc-url $RPC > /dev/null

echo "--- 1. hand out USDe (impersonate Morpho, the largest USDe custodian)"
cast rpc anvil_impersonateAccount $MORPHO --rpc-url $RPC > /dev/null
cast rpc anvil_setBalance $MORPHO 0xde0b6b3a7640000 --rpc-url $RPC > /dev/null
cast send $USDE "transfer(address,uint256)" $BORROWER 100000ether --from $MORPHO --unlocked --rpc-url $RPC > /dev/null
cast send $USDE "transfer(address,uint256)" $CLP 20000ether --from $MORPHO --unlocked --rpc-url $RPC > /dev/null
cast rpc anvil_stopImpersonatingAccount $MORPHO --rpc-url $RPC > /dev/null

echo "--- 2. CLP seeds the intermediate vault (IV asset = USDe, live cash is 0)"
cast send $USDE "approve(address,uint256)" $IV "$(cast max-uint)" --private-key $CLP_PK --rpc-url $RPC > /dev/null
cast send $IV "deposit(uint256,address)" 20000ether $CLP --private-key $CLP_PK --rpc-url $RPC > /dev/null
echo "IV cash: $(cast call $IV 'cash()(uint256)' --rpc-url $RPC)"

echo "--- 3. borrower opens USDe/USDG position at ~88% LTV (lltv is 91.5%)"
cast send $USDE "approve(address,uint256)" $MORPHO "$(cast max-uint)" --private-key $BORROWER_PK --rpc-url $RPC > /dev/null
cast send $MORPHO "supplyCollateral((address,address,address,address,uint256),uint256,address,bytes)" \
  "$MP" 100000ether $BORROWER 0x --private-key $BORROWER_PK --rpc-url $RPC > /dev/null
# 100k USDe ≈ $100k; borrow 88k USDG (6 decimals)
cast send $MORPHO "borrow((address,address,address,address,uint256),uint256,uint256,address,address)" \
  "$MP" 88000000000 0 $BORROWER $BORROWER --private-key $BORROWER_PK --rpc-url $RPC > /dev/null
MID=$(cast keccak $(cast abi-encode "f((address,address,address,address,uint256))" "$MP"))
echo "position: $(cast call $MORPHO 'position(bytes32,address)(uint256,uint128,uint128)' $MID $BORROWER --rpc-url $RPC | tr '\n' ' ')"

echo
echo "Fork seeded."
echo "  borrower: $BORROWER   (anvil account 2)"
echo "  CLP:      $CLP   (anvil account 3)"
echo
echo "dApp env: VITE_CHAIN_ID=31337 VITE_RPC_URL=$RPC   (PTO default is the live 0xc64972086Fd74DDf1718B526033EACaB3fF3Ba54)"
echo "Degrade borrower (borrow 2k more): cast send $MORPHO 'borrow((address,address,address,address,uint256),uint256,uint256,address,address)' \"$MP\" 2000000000 0 $BORROWER $BORROWER --private-key <anvil-pk-2> --rpc-url $RPC"
echo "Keeper trigger (impersonate live keeper): cast rpc anvil_impersonateAccount 0x8acA5b6B5C0f4E73038179B64e24ca01f04A32a1; cast send 0xc64972086Fd74DDf1718B526033EACaB3fF3Ba54 'triggerMigration(address)' $BORROWER --from 0x8acA5b6B5C0f4E73038179B64e24ca01f04A32a1 --unlocked --gas-limit 3000000 --rpc-url $RPC"
