#!/usr/bin/env bash
# Seed an anvil mainnet fork for the Twyne Shield demo:
#   1. deploy ProtectionTriggerOperator (keeper = anvil account 1)
#   2. seed the live wstETH IV with CLP credit (anvil account 3)
#   3. open alice's Aave position near the HF gate (anvil account 2)
# Prereq: `anvil --fork-url $MAINNET_RPC_URL` running on :8545.
# Keys are the standard anvil dev accounts, derived from the public test mnemonic at runtime.
set -euo pipefail

RPC=${RPC:-http://127.0.0.1:8545}
MN="test test test test test test test test test test test junk"
pk() { cast wallet private-key "$MN" "m/44'/60'/0'/0/$1"; }
addr() { cast wallet address --private-key "$(pk "$1")"; }

DEPLOYER_PK=$(pk 0)
KEEPER=$(addr 1)
KEEPER_PK=$(pk 1)
ALICE=$(addr 2)
ALICE_PK=$(pk 2)
CLP=$(addr 3)
CLP_PK=$(pk 3)

# live mainnet addresses (tech-notes/public-launch-addresses/TwyneAddresses_current_1.json)
POOL=0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2
WSTETH=0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0
WETH=0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2
IV=0x75029a47f28550C93Ad5A3BbD2d9b5315204B561
WRAPPER=0xFaBA8f777996C0C28fe9e6554D84cB30ca3e1881

AWSTETH=$(cast call $POOL "getReserveAToken(address)(address)" $WSTETH --rpc-url $RPC)
echo "awstETH: $AWSTETH"

echo "--- 1. deploy ProtectionTriggerOperator (keeper=$KEEPER)"
DEPLOYER_PRIVATE_KEY=$DEPLOYER_PK KEEPER_ADDRESS=$KEEPER \
  forge script script/Deploy.s.sol --rpc-url $RPC --broadcast --silent
PTO=$(python3 -c "import json;print(json.load(open('deployments/mainnet.json'))['protectionTriggerOperator'])")
echo "PTO: $PTO"

echo "--- 2. hand alice + clp wstETH (impersonate the awstETH contract, which custodies wstETH)"
cast rpc anvil_impersonateAccount $AWSTETH --rpc-url $RPC > /dev/null
cast rpc anvil_setBalance $AWSTETH 0xde0b6b3a7640000 --rpc-url $RPC > /dev/null
cast send $WSTETH "transfer(address,uint256)" $ALICE 10ether --from $AWSTETH --unlocked --rpc-url $RPC > /dev/null
cast send $WSTETH "transfer(address,uint256)" $CLP 10ether --from $AWSTETH --unlocked --rpc-url $RPC > /dev/null
cast rpc anvil_stopImpersonatingAccount $AWSTETH --rpc-url $RPC > /dev/null

echo "--- 3. CLP seeds the wstETH intermediate vault with credit"
cast send $WSTETH "approve(address,uint256)" $POOL "$(cast max-uint)" --private-key $CLP_PK --rpc-url $RPC > /dev/null
cast send $POOL "supply(address,uint256,address,uint16)" $WSTETH 10ether $CLP 0 --private-key $CLP_PK --rpc-url $RPC > /dev/null
cast send $AWSTETH "approve(address,uint256)" $WRAPPER "$(cast max-uint)" --private-key $CLP_PK --rpc-url $RPC > /dev/null
ABAL=$(cast call $AWSTETH "balanceOf(address)(uint256)" $CLP --rpc-url $RPC | awk '{print $1}')
cast send $WRAPPER "depositATokens(uint256,address)" "$ABAL" $CLP --private-key $CLP_PK --rpc-url $RPC > /dev/null
WBAL=$(cast call $WRAPPER "balanceOf(address)(uint256)" $CLP --rpc-url $RPC | awk '{print $1}')
cast send $WRAPPER "approve(address,uint256)" $IV "$(cast max-uint)" --private-key $CLP_PK --rpc-url $RPC > /dev/null
cast send $IV "deposit(uint256,address)" "$WBAL" $CLP --private-key $CLP_PK --rpc-url $RPC > /dev/null
echo "IV cash: $(cast call $IV 'cash()(uint256)' --rpc-url $RPC)"

echo "--- 4. alice opens the Aave position (10 wstETH collateral, 8.4 WETH debt)"
cast send $WSTETH "approve(address,uint256)" $POOL "$(cast max-uint)" --private-key $ALICE_PK --rpc-url $RPC > /dev/null
cast send $POOL "supply(address,uint256,address,uint16)" $WSTETH 10ether $ALICE 0 --private-key $ALICE_PK --rpc-url $RPC > /dev/null
cast send $POOL "borrow(address,uint256,uint256,uint16,address)" $WETH 8.4ether 2 0 $ALICE --private-key $ALICE_PK --rpc-url $RPC > /dev/null
echo "alice account: $(cast call $POOL 'getUserAccountData(address)(uint256,uint256,uint256,uint256,uint256,uint256)' $ALICE --rpc-url $RPC)"

echo
echo "Fork seeded."
echo "  alice  (borrower): $ALICE   (anvil account 2)"
echo "  keeper:            $KEEPER   (anvil account 1)"
echo "  PTO:               $PTO"
echo
echo "dApp env:   VITE_CHAIN_ID=31337 VITE_RPC_URL=$RPC VITE_PTO_ADDRESS=$PTO"
echo "Degrade alice (cross the gate):"
echo "  cast send $POOL 'borrow(address,uint256,uint256,uint16,address)' $WETH 0.6ether 2 0 $ALICE --private-key \$(anvil pk 2) --rpc-url $RPC"
echo "Keeper trigger:"
echo "  cast send $PTO 'triggerMigration(address)' $ALICE --private-key \$(anvil pk 1) --rpc-url $RPC"
