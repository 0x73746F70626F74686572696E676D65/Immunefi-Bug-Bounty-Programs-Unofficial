// Closed-form P(liquidation by time T) — vanilla GBM first-passage.
// Ported from repos/research/liquidation-probability/demo/index.html (validated against the
// Python reference liquidation_probability.py to 4 decimals; RES-317 / RES-321).
// Φ uses Hastings / A&S 26.2.17 (max error ~7.5e-8) — NOT the broken pt_clp_losses._norm_cdf
// variant (RES-318).

export function normCdf(x: number): number {
  const b1 = 0.31938153,
    b2 = -0.356563782,
    b3 = 1.781477937,
    b4 = -1.821255978,
    b5 = 1.330274429
  const p = 0.2316419
  const ax = Math.abs(x)
  const k = 1.0 / (1.0 + p * ax)
  const phi = Math.exp(-0.5 * ax * ax) / Math.sqrt(2 * Math.PI)
  const tail = phi * ((((b5 * k + b4) * k + b3) * k + b2) * k + b1) * k
  return x >= 0 ? 1 - tail : tail
}

export interface LiqProbParams {
  ltv0: number // current LTV = debt / collateral (same base units)
  liqLtv: number // liquidation threshold (barrier), e.g. 0.795
  T: number // horizon in years
  sigmaS: number // annualized log-vol of the collateral/debt price ratio
  muS?: number // annualized drift of log(P_C/P_B); default 0 (martingale)
  rb?: number // borrow APY (continuous); drifts LTV up
  rc?: number // collateral unit-yield APY; drifts LTV down
}

/** P(LTV first crosses liqLtv within T years). Exact for constant-vol GBM (reflection principle). */
export function liquidationProbability({ ltv0, liqLtv, T, sigmaS, muS = 0, rb = 0, rc = 0 }: LiqProbParams): number {
  if (ltv0 <= 0 || liqLtv <= 0 || T <= 0) return 0
  if (ltv0 >= liqLtv) return 1
  const alpha = rb - rc - muS
  const b = Math.log(liqLtv / ltv0)
  const V = sigmaS * sigmaS * T
  if (V <= 0) return alpha * T >= b ? 1 : 0
  const sqrtV = Math.sqrt(V)
  const sigmaBarSq = V / T
  const dPlus = (alpha * T - b) / sqrtV
  const dMinus = (alpha * T + b) / sqrtV
  const p = normCdf(dPlus) + Math.exp((2 * alpha * b) / sigmaBarSq) * normCdf(-dMinus)
  return Math.max(0, Math.min(1, p))
}

/** Probability curve over horizons 0..maxDays (1 point per day). */
export function liquidationCurve(params: Omit<LiqProbParams, "T">, maxDays = 90): { day: number; p: number }[] {
  const out: { day: number; p: number }[] = []
  for (let d = 0; d <= maxDays; d++) {
    out.push({ day: d, p: liquidationProbability({ ...params, T: d / 365.25 }) })
  }
  return out
}

/** First day (1..maxDays) where P(liq ≤ d) reaches threshold, or null. */
export function tripDay(params: Omit<LiqProbParams, "T">, thresholdP: number, maxDays = 90): number | null {
  for (let d = 1; d <= maxDays; d++) {
    if (liquidationProbability({ ...params, T: d / 365.25 }) >= thresholdP) return d
  }
  return null
}
