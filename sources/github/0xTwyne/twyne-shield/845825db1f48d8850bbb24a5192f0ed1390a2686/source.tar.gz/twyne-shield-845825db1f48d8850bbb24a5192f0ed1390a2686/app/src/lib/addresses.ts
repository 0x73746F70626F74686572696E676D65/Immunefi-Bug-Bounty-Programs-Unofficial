import { encodeAbiParameters, keccak256 } from "viem"

// Robinhood Chain (4663) Twyne Morpho deployment — the app's active target.
// Source: tech-notes/robinhood-launch-addresses/RobinhoodDeployment_Jul11_2026/
// (TwyneCoreAddresses.json, TwyneMorphoAddresses.json, CoreAddresses.json), live-verified 2026-07-11.
export const ADDR = {
  // Twyne
  evc: "0xef39D6493884C4C84D38a4bFF879Ce16CEdE702a",
  morphoTeleportOperator: "0x87E63679072A8890aab08E825FdA482D4Ceb79F3",
  collateralVaultFactory: "0x55d631c04077D791020e0416D7A27509a43E33Ef",
  vaultManager: "0x4fF123522a8d60087774F4A72765E4B592055Ae5",
  intermediateVault: "0x87b8081A3ace680f35125F469526Ac10f5418Ca7",
  // Morpho Blue
  morpho: "0x9D53d5E3bd5E8d4Cbfa6DB1ca238AEA02E651010",
} as const

export const TOKENS = {
  collateral: { address: "0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34", symbol: "USDe", decimals: 18 },
  loan: { address: "0x5fc5360D0400a0Fd4f2af552ADD042D716F1d168", symbol: "USDG", decimals: 6 },
} as const

// Launch market params (live `idToMarketParams` of the marketId in TwyneMorphoAddresses.json).
// Needed verbatim for createMorphoCollateralVault; the market id is derived below exactly like
// MarketParamsLib.id (keccak256(abi.encode(marketParams))) instead of hardcoding a 32-byte literal.
export const MARKET_PARAMS = {
  loanToken: TOKENS.loan.address,
  collateralToken: TOKENS.collateral.address,
  oracle: "0xE64849bd4AD03DfaBbe02bb521de19997a19055f",
  irm: "0x2BD3d5965B26B51814AC95127B2b80dD6CcC0fa1",
  lltv: 915_000_000_000_000_000n, // 91.5%
} as const

export const MARKET_ID = keccak256(
  encodeAbiParameters(
    [
      { type: "address" },
      { type: "address" },
      { type: "address" },
      { type: "address" },
      { type: "uint256" },
    ],
    [
      MARKET_PARAMS.loanToken,
      MARKET_PARAMS.collateralToken,
      MARKET_PARAMS.oracle,
      MARKET_PARAMS.irm,
      MARKET_PARAMS.lltv,
    ],
  ),
)

// Market liquidation LTV (= MARKET_PARAMS.lltv). Displayed and used as the P(liq) barrier.
export const MARKET_LLTV = 0.915

// MorphoProtectionTriggerOperator (deployed by operator, wiring live-verified: morpho + teleport match).
export const PTO_ADDRESS = (import.meta.env.VITE_PTO_ADDRESS ??
  "0xc64972086Fd74DDf1718B526033EACaB3fF3Ba54") as `0x${string}`

export const RPC_URL: string = import.meta.env.VITE_RPC_URL ?? "https://rpc.mainnet.chain.robinhood.com"
export const CHAIN_ID: number = Number(import.meta.env.VITE_CHAIN_ID ?? 4663) // anvil forks keep 4663

// Interim σ (annualized USDe/USDG ratio log-vol) until the calibration pipeline ships.
// Deliberately jump-inclusive/stressed: stable pairs carry their risk in depeg jumps, which the
// Gaussian closed form under-counts — an inflated effective σ partially compensates (see the
// methodology section). Overridable per build via VITE_SIGMA_S.
export const DEFAULT_SIGMA_S: number = Number(import.meta.env.VITE_SIGMA_S ?? 0.15)

// Policy defaults for "Enable protection" (no config UI in the MVP).
export const POLICY = {
  probThresholdBps: 1000n, // trigger past 10% P(liq ≤ 30d)
  hfGateWad: 1_100_000_000_000_000_000n, // on-chain gate: keeper may act only while Morpho HF < 1.10
  cvLiqLtvBps: 9500n, // Twyne liqLTV for the created vault (deployer-example precedent; max is 9800)
} as const

// Read-only spectator mode for demos: render the flow for this address without a wallet connection.
export const DEMO_ADDRESS = (import.meta.env.VITE_DEMO_ADDRESS ?? "") as "" | `0x${string}`
