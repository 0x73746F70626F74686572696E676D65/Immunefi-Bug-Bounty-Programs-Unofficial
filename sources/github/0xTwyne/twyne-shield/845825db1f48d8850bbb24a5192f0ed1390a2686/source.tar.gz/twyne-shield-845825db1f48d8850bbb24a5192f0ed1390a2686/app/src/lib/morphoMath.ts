// Morpho Blue position math — bigint mirrors of SharesMathLib / _isHealthy, plus display helpers.

const VIRTUAL_SHARES = 1_000_000n
const VIRTUAL_ASSETS = 1n
export const ORACLE_PRICE_SCALE = 10n ** 36n

/** SharesMathLib.toAssetsUp(shares, totalAssets, totalShares). */
export function toAssetsUp(shares: bigint, totalAssets: bigint, totalShares: bigint): bigint {
  const num = shares * (totalAssets + VIRTUAL_ASSETS)
  const den = totalShares + VIRTUAL_SHARES
  return (num + den - 1n) / den
}

export interface MorphoPositionView {
  collateral: bigint // collateral-token units
  borrowAssets: bigint // loan-token units, rounded up
  collateralInLoan: bigint // collateral valued in loan-token units via the market oracle
  ltv: number // borrowAssets / collateralInLoan
  healthFactor: number // lltv / ltv
}

/** Mirrors the contract's _healthFactor inputs; price is oracle.price() (1e36-scaled loan per collateral). */
export function computePosition(params: {
  collateral: bigint
  borrowShares: bigint
  totalBorrowAssets: bigint
  totalBorrowShares: bigint
  price: bigint
  lltvWad: bigint
}): MorphoPositionView | null {
  const { collateral, borrowShares, totalBorrowAssets, totalBorrowShares, price, lltvWad } = params
  if (collateral === 0n && borrowShares === 0n) return null
  const borrowAssets = borrowShares === 0n ? 0n : toAssetsUp(borrowShares, totalBorrowAssets, totalBorrowShares)
  const collateralInLoan = (collateral * price) / ORACLE_PRICE_SCALE
  const ltv = collateralInLoan === 0n ? Infinity : Number(borrowAssets) / Number(collateralInLoan)
  const lltv = Number(lltvWad) / 1e18
  return {
    collateral,
    borrowAssets,
    collateralInLoan,
    ltv,
    healthFactor: ltv > 0 ? lltv / ltv : Infinity,
  }
}

export function formatUnits(x: bigint, decimals: number, dp = 2): string {
  const neg = x < 0n
  const ax = neg ? -x : x
  const base = 10n ** BigInt(decimals)
  const whole = ax / base
  const frac = ax % base
  const fracStr = (Number(frac) / Number(base)).toFixed(dp).slice(2)
  return `${neg ? "-" : ""}${whole.toLocaleString("en-US")}.${fracStr}`
}
