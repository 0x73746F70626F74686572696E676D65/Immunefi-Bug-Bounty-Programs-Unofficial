import { createConfig, http } from "wagmi"
import { injected } from "wagmi/connectors"
import { defineChain } from "viem"
import { CHAIN_ID, RPC_URL } from "./lib/addresses"

// Robinhood Chain — Arbitrum Orbit L2. multicall3 at the canonical address (live-verified).
const robinhood = defineChain({
  id: 4663,
  name: "Robinhood Chain",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: { default: { http: [RPC_URL] } },
  contracts: { multicall3: { address: "0xcA11bde05977b3631167028862bE2a173976CA11" } },
})

// Anvil forks preserve the origin chainId (4663), so one chain definition covers live + fork;
// VITE_RPC_URL swaps the transport target. CHAIN_ID env stays for exotic setups only.
export const chain = { ...robinhood, id: CHAIN_ID }

export const config = createConfig({
  chains: [chain],
  connectors: [injected()],
  transports: { [chain.id]: http(RPC_URL) },
})
