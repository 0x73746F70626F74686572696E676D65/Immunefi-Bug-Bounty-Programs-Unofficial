import { useEffect, useMemo, useState } from "react"
import {
  useAccount,
  useConnect,
  useDisconnect,
  usePublicClient,
  useReadContract,
  useReadContracts,
  useSignTypedData,
  useSwitchChain,
  useWaitForTransactionReceipt,
  useWriteContract,
} from "wagmi"
import { decodeAbiParameters, encodeFunctionData, parseSignature, zeroAddress } from "viem"
import { evcAbi, morphoAbi, morphoCvAbi, morphoFactoryAbi, morphoPtoAbi, morphoTeleportAbi, oracleAbi } from "./lib/morphoAbis"
import {
  ADDR,
  DEFAULT_SIGMA_S,
  DEMO_ADDRESS,
  MARKET_ID,
  MARKET_LLTV,
  MARKET_PARAMS,
  POLICY,
  PTO_ADDRESS,
  TOKENS,
} from "./lib/addresses"
import { computePosition, formatUnits } from "./lib/morphoMath"
import { liquidationCurve, liquidationProbability, tripDay } from "./lib/liqProb"
import CurveChart from "./components/CurveChart"
import { chain } from "./wagmi"

const HORIZON_YEARS = 30 / 365.25
const THRESHOLD_PRESETS_BPS = [500, 1000, 2500] as const

const fmtPct = (x: number, dp = 1) => `${(x * 100).toFixed(dp)}%`

export default function App() {
  const { address, isConnected, chainId } = useAccount()
  const { connect, connectors, isPending: connecting } = useConnect()
  const { disconnect } = useDisconnect()
  const { switchChain } = useSwitchChain()

  const wrongChain = isConnected && chainId !== chain.id

  return (
    <>
      <div className="hdr">
        <h1>
          <img className="wordmark" src="/twyne-logo.svg" alt="twyne" />
          <span className="shield">shield</span>
        </h1>
        {isConnected && address ? (
          <button className="ghost" onClick={() => disconnect()} title="Disconnect">
            <span className="addr">{address}</span>
          </button>
        ) : null}
      </div>
      <p className="tagline">Liquidation protection for Morpho on Robinhood Chain. USDe/USDG → Twyne, automatically.</p>

      {wrongChain ? (
        <div className="card">
          <h3>Wrong network</h3>
          <p className="note">Shield runs on Robinhood Chain (id {chain.id}).</p>
          <button className="primary" onClick={() => switchChain({ chainId: chain.id })}>
            Switch network
          </button>
        </div>
      ) : !isConnected && DEMO_ADDRESS ? (
        <>
          <p className="note warn">Spectator mode — viewing {DEMO_ADDRESS} read-only.</p>
          <Flow user={DEMO_ADDRESS} />
        </>
      ) : !isConnected ? (
        <div className="hero">
          <h2>
            Your Morpho position gets rescued <em>before</em> it gets liquidated.
          </h2>
          <p>
            You're borrowing USDG against USDe on Morpho with a 91.5% liquidation LTV. Shield watches your
            30-day liquidation probability around the clock. If it crosses the trigger, your whole position
            migrates — atomically, in one transaction — into a Twyne vault you alone control, with a 95%
            liquidation LTV. More room, no liquidation, no 3am panic.
          </p>
          <p>
            Prefer not to wait? You can also migrate immediately and take the extra headroom today.
          </p>
          <button className="primary" disabled={connecting} onClick={() => connect({ connector: connectors[0] })}>
            {connecting ? "Connecting…" : "Connect wallet"}
          </button>
        </div>
      ) : (
        <Flow user={address!} />
      )}

      <Methodology />
    </>
  )
}

function Methodology() {
  return (
    <footer>
      <details className="method">
        <summary>How the math works — methodology</summary>

        <p>
          Your collateral, debt and LTV are read directly from the on-chain Morpho position and the market's
          own oracle on every refresh — nothing here comes from an off-chain database.
        </p>

        <h3>Liquidation probability</h3>
        <p>
          The 30-day number answers a running-maximum question: what is the probability that your LTV touches
          the 91.5% liquidation threshold at <em>any moment</em> within the horizon — not just where it sits
          at the end. Log-LTV is modeled as a drifted Brownian motion with annualized volatility σ of the
          USDe/USDG price ratio. Liquidation is the first passage of that process to the barrier{" "}
          <code>b = ln(LLTV / LTV₀)</code>, which has an exact closed form by the reflection principle:
        </p>
        <pre>{`P(τ ≤ T) = Φ((αT − b)/σ√T) + exp(2αb/σ²) · Φ(−(αT + b)/σ√T)`}</pre>
        <p>
          α is the drift of log-LTV (borrow interest pushes it up, collateral yield and ratio drift push it
          down — approximately zero for this pair). The whole curve costs two normal-CDF calls and one
          exponential per point, so it recomputes live in your browser as the position moves. Φ itself is the
          Hastings rational approximation of the standard normal CDF, accurate to about 10⁻⁷ — validated
          against a reference implementation.
        </p>

        <h3>Choosing σ for a stablecoin pair</h3>
        <p>
          Stable pairs don't drift apart smoothly — they move in jumps (depeg episodes), and a Gaussian model
          under-counts jump risk in the tails. The default σ here ({fmtPct(DEFAULT_SIGMA_S, 0)}/yr) is
          therefore deliberately stressed: it is a jump-inclusive effective volatility rather than the pair's
          quiet-market drift, partially compensating for those missing tails. The shape consequence remains —
          probability sits near zero until LTV closes in on the threshold, then rises steeply. The model
          informs the keeper; it never has the final word — that belongs to the chain:
        </p>

        <h3>On-chain enforcement</h3>
        <p>
          The protection contract recomputes your health factor exactly the way Morpho's own liquidation check
          does — accrue interest first, convert borrow shares rounding up, then
          <code> maxBorrow = collateral × price / 10³⁶ × lltv</code> — and refuses the keeper unless{" "}
          <code>HF = maxBorrow / debt</code> is below the bound you signed at opt-in. A buggy or malicious
          keeper can at worst migrate you early, into a vault only you control. It can never touch a healthy
          position and never move funds anywhere else.
        </p>

        <h3>The migration itself</h3>
        <p>
          One atomic transaction: a Morpho flashloan repays your USDG debt, your USDe collateral moves into
          your personal Twyne vault, and the vault re-opens the same debt at 95% liquidation LTV. The extra
          headroom above the market's 91.5% is real risk capacity — it exists because Twyne credit LPs reserve
          additional USDe collateral behind your position, and the vault's rate includes their compensation.
        </p>
      </details>
    </footer>
  )
}

// ---------------------------------------------------------------------------

function Flow({ user }: { user: `0x${string}` }) {
  const reads = useReadContracts({
    contracts: [
      { address: ADDR.morpho, abi: morphoAbi, functionName: "position", args: [MARKET_ID, user] },
      { address: ADDR.morpho, abi: morphoAbi, functionName: "market", args: [MARKET_ID] },
      { address: MARKET_PARAMS.oracle, abi: oracleAbi, functionName: "price" },
      { address: PTO_ADDRESS, abi: morphoPtoAbi, functionName: "protections", args: [user] },
      { address: ADDR.morpho, abi: morphoAbi, functionName: "isAuthorized", args: [user, ADDR.morphoTeleportOperator] },
      { address: ADDR.evc, abi: evcAbi, functionName: "isAccountOperatorAuthorized", args: [user, ADDR.morphoTeleportOperator] },
      { address: ADDR.evc, abi: evcAbi, functionName: "isAccountOperatorAuthorized", args: [user, PTO_ADDRESS] },
      { address: ADDR.collateralVaultFactory, abi: morphoFactoryAbi, functionName: "getCollateralVaults", args: [user] },
      { address: ADDR.morpho, abi: morphoAbi, functionName: "nonce", args: [user] },
    ],
    query: { refetchInterval: 15_000 },
  })

  const [positionRaw, marketRaw, priceRaw, protRaw, morphoAuth, opTeleport, opPto, cvsRaw, nonceRaw] = reads.data ?? []

  const cvs = (cvsRaw?.result as readonly `0x${string}`[] | undefined) ?? []
  const lastCv = cvs.length > 0 ? cvs[cvs.length - 1] : undefined
  const lastCvInfo = useReadContracts({
    contracts: lastCv
      ? [
          { address: lastCv, abi: morphoCvAbi, functionName: "marketParams" },
          { address: lastCv, abi: morphoCvAbi, functionName: "maxRepay" },
          { address: lastCv, abi: morphoCvAbi, functionName: "twyneLiqLTV" },
        ]
      : [],
    query: { enabled: !!lastCv, refetchInterval: 15_000 },
  })
  const lastCvMarketMatch =
    !!lastCvInfo.data?.[0]?.result &&
    (lastCvInfo.data[0].result as { loanToken: string }).loanToken.toLowerCase() === TOKENS.loan.address.toLowerCase()
  const lastCvDebt = (lastCvInfo.data?.[1]?.result as bigint | undefined) ?? 0n
  const lastCvLiqLtv = (lastCvInfo.data?.[2]?.result as bigint | undefined) ?? 0n

  const pos = useMemo(() => {
    if (!positionRaw?.result || !marketRaw?.result || priceRaw?.result === undefined) return null
    const [, borrowShares, collateral] = positionRaw.result as readonly [bigint, bigint, bigint]
    const [, , totalBorrowAssets, totalBorrowShares] = marketRaw.result as readonly [bigint, bigint, bigint, bigint, bigint, bigint]
    return computePosition({
      collateral,
      borrowShares,
      totalBorrowAssets,
      totalBorrowShares,
      price: priceRaw.result as bigint,
      lltvWad: MARKET_PARAMS.lltv,
    })
  }, [positionRaw?.result, marketRaw?.result, priceRaw?.result])

  if (reads.isLoading) return <p className="note">Reading your Morpho position…</p>

  const prot = protRaw?.result as readonly [`0x${string}`, bigint, bigint, boolean] | undefined
  const registered = !!prot && prot[0] !== zeroAddress

  if (registered) {
    return (
      <StatusView
        prot={prot!}
        pos={pos}
        impaired={!(morphoAuth?.result as boolean) || !(opTeleport?.result as boolean) || !(opPto?.result as boolean)}
        onChanged={() => reads.refetch()}
      />
    )
  }

  // Unregistered but already migrated (via "Migrate now"): show the migrated card.
  if ((!pos || pos.borrowAssets === 0n) && lastCvMarketMatch && lastCvDebt > 0n) {
    return <MigratedCard cv={lastCv!} debt={lastCvDebt} liqLtvBps={lastCvLiqLtv} />
  }

  if (!pos || pos.borrowAssets === 0n) {
    return (
      <div className="card">
        <h3>No active position found</h3>
        <p className="note">
          Shield protects borrow positions in the USDe/USDG market on Morpho (Robinhood Chain). Open one, then
          come back — or set a different wallet.
        </p>
      </div>
    )
  }

  return (
    <ActivePosition
      user={user}
      pos={pos}
      morphoAuthorized={!!(morphoAuth?.result as boolean)}
      morphoNonce={(nonceRaw?.result as bigint | undefined) ?? 0n}
      opTeleport={!!(opTeleport?.result as boolean)}
      opPto={!!(opPto?.result as boolean)}
      reusableCv={lastCvMarketMatch && lastCvDebt === 0n ? lastCv : undefined}
      refetchAll={async () => {
        await Promise.all([reads.refetch(), lastCvInfo.refetch()])
      }}
    />
  )
}

// ---------------------------------------------------------------------------

type Pos = NonNullable<ReturnType<typeof computePosition>>
type BatchItem = { targetContract: `0x${string}`; onBehalfOfAccount: `0x${string}`; value: bigint; data: `0x${string}` }

function PositionCard({ pos, p30, thresholdP }: { pos: Pos; p30: number; thresholdP: number }) {
  return (
    <div className="card">
      <div className="kv">
        <Item k={`Collateral (${TOKENS.collateral.symbol})`} v={formatUnits(pos.collateral, TOKENS.collateral.decimals)} />
        <Item k="Collateral ≈ USD" v={`$${formatUnits(pos.collateralInLoan, TOKENS.loan.decimals)}`} />
        <Item k={`Debt (${TOKENS.loan.symbol})`} v={formatUnits(pos.borrowAssets, TOKENS.loan.decimals)} />
        <Item k="Debt ≈ USD" v={`$${formatUnits(pos.borrowAssets, TOKENS.loan.decimals)}`} />
        <Item k="LTV" v={fmtPct(pos.ltv)} tone={pos.ltv > 0.88 ? "bad" : pos.ltv > 0.8 ? "warn" : "safe"} />
        <Item k="Liquidation LTV" v={fmtPct(MARKET_LLTV)} />
        <Item k="P(liq ≤ 30d)" v={fmtPct(p30, 2)} tone={p30 >= thresholdP ? "bad" : p30 >= thresholdP / 2 ? "warn" : "safe"} />
      </div>
    </div>
  )
}

type Phase = null | "signing" | "simulating" | "wallet" | "pending"

const PHASE_LABEL: Record<Exclude<Phase, null>, string> = {
  signing: "Waiting for your signature (free, off-chain)…",
  simulating: "Simulating the batch to predict your vault address…",
  wallet: "Confirm the transaction in your wallet…",
  pending: "Transaction pending…",
}

function ActivePosition({
  user,
  pos,
  morphoAuthorized,
  morphoNonce,
  opTeleport,
  opPto,
  reusableCv,
  refetchAll,
}: {
  user: `0x${string}`
  pos: Pos
  morphoAuthorized: boolean
  morphoNonce: bigint
  opTeleport: boolean
  opPto: boolean
  reusableCv?: `0x${string}`
  refetchAll: () => Promise<void>
}) {
  const [phase, setPhase] = useState<Phase>(null)
  const [flowError, setFlowError] = useState<string | null>(null)
  const [thresholdBps, setThresholdBps] = useState<number>(Number(POLICY.probThresholdBps))
  const thresholdP = thresholdBps / 1e4

  const curveParams = { ltv0: pos.ltv, liqLtv: MARKET_LLTV, sigmaS: DEFAULT_SIGMA_S }
  const p30 = liquidationProbability({ ...curveParams, T: HORIZON_YEARS })
  const curve = useMemo(() => liquidationCurve(curveParams), [pos.ltv]) // eslint-disable-line react-hooks/exhaustive-deps
  const trip = tripDay(curveParams, thresholdP)

  const { signTypedDataAsync } = useSignTypedData()
  const publicClient = usePublicClient()
  const tx = useWriteContract()
  const receipt = useWaitForTransactionReceipt({ hash: tx.data })

  useEffect(() => {
    if (!receipt.isSuccess && !receipt.isError) return
    ;(async () => {
      await refetchAll()
      setPhase(null)
      if (receipt.isError) setFlowError("Transaction reverted — see wallet/explorer for details.")
      tx.reset()
    })()
  }, [receipt.isSuccess, receipt.isError]) // eslint-disable-line react-hooks/exhaustive-deps

  const grantItem = (operator: `0x${string}`, authorized: boolean): BatchItem => ({
    targetContract: ADDR.evc,
    onBehalfOfAccount: zeroAddress,
    value: 0n,
    data: encodeFunctionData({ abi: evcAbi, functionName: "setAccountOperator", args: [user, operator, authorized] }),
  })

  /** One signature (if Morpho auth is missing) + ONE EVC batch:
   *  [setAuthorizationWithSig?, createVault?, grants, register|teleport].
   *  The future vault address comes from EVC.batchSimulation on the batch prefix — the CREATE2 salt only
   *  depends on the user's factory nonce, so the simulated address is what the real batch will deploy. */
  const arm = async (mode: "migrate" | "protect") => {
    setFlowError(null)
    try {
      const items: BatchItem[] = []

      if (!morphoAuthorized) {
        setPhase("signing")
        const authorization = {
          authorizer: user,
          authorized: ADDR.morphoTeleportOperator,
          isAuthorized: true,
          nonce: morphoNonce,
          deadline: BigInt(Math.floor(Date.now() / 1000) + 3600),
        }
        const sigHex = await signTypedDataAsync({
          domain: { chainId: chain.id, verifyingContract: ADDR.morpho }, // Morpho's domain has no name/version
          types: {
            Authorization: [
              { name: "authorizer", type: "address" },
              { name: "authorized", type: "address" },
              { name: "isAuthorized", type: "bool" },
              { name: "nonce", type: "uint256" },
              { name: "deadline", type: "uint256" },
            ],
          },
          primaryType: "Authorization",
          message: authorization,
        })
        const sig = parseSignature(sigHex)
        const v = sig.v !== undefined ? Number(sig.v) : sig.yParity + 27
        items.push({
          targetContract: ADDR.morpho,
          onBehalfOfAccount: user,
          value: 0n,
          data: encodeFunctionData({
            abi: morphoAbi,
            functionName: "setAuthorizationWithSig",
            args: [authorization, { v, r: sig.r, s: sig.s }],
          }),
        })
      }

      let cv = reusableCv
      if (!cv) {
        const createIdx = items.length
        items.push({
          targetContract: ADDR.collateralVaultFactory,
          onBehalfOfAccount: user,
          value: 0n,
          data: encodeFunctionData({
            abi: morphoFactoryAbi,
            functionName: "createMorphoCollateralVault",
            args: [ADDR.intermediateVault, ADDR.morpho, { ...MARKET_PARAMS }, POLICY.cvLiqLtvBps],
          }),
        })
        setPhase("simulating")
        const sim = await publicClient!.simulateContract({
          address: ADDR.evc,
          abi: evcAbi,
          functionName: "batchSimulation",
          args: [items],
          account: user,
        })
        const createResult = sim.result[0][createIdx]
        if (!createResult?.success) throw new Error("Simulation failed: vault creation would revert.")
        cv = decodeAbiParameters([{ type: "address" }], createResult.result)[0] as `0x${string}`
      }

      if (mode === "migrate") {
        const hadGrant = opTeleport
        if (!hadGrant) items.push(grantItem(ADDR.morphoTeleportOperator, true))
        items.push({
          targetContract: ADDR.morphoTeleportOperator,
          onBehalfOfAccount: user,
          value: 0n,
          data: encodeFunctionData({
            abi: morphoTeleportAbi,
            functionName: "executeTeleport",
            args: [cv, 2n ** 256n - 1n, 2n ** 256n - 1n],
          }),
        })
        if (!hadGrant) items.push(grantItem(ADDR.morphoTeleportOperator, false)) // one-shot: revoke in-batch
      } else {
        if (!opTeleport) items.push(grantItem(ADDR.morphoTeleportOperator, true)) // standing grant for the keeper path
        if (!opPto) items.push(grantItem(PTO_ADDRESS, true))
        items.push({
          targetContract: PTO_ADDRESS,
          onBehalfOfAccount: user,
          value: 0n,
          data: encodeFunctionData({
            abi: morphoPtoAbi,
            functionName: "register",
            args: [cv, POLICY.hfGateWad, BigInt(thresholdBps)],
          }),
        })
      }

      setPhase("wallet")
      tx.writeContract(
        { address: ADDR.evc, abi: evcAbi, functionName: "batch", args: [items] },
        {
          onSuccess: () => setPhase("pending"),
          onError: (e) => {
            setFlowError((e as Error).message.split("\n")[0])
            setPhase(null)
          },
        },
      )
    } catch (e) {
      setFlowError((e as Error).message.split("\n")[0])
      setPhase(null)
    }
  }

  const busy = phase !== null

  return (
    <div className="rail">
      <section className="station done">
        <h2>Your Morpho position — USDe / USDG</h2>
        <PositionCard pos={pos} p30={p30} thresholdP={thresholdP} />
      </section>

      <section className="station on">
        <h2>Choose your path — one signature, one transaction</h2>
        <div className="card">
          <div className="ctl" style={{ marginTop: 0 }}>
            <label>
              Protection trigger — auto-migrate when P(liq ≤ 30d) exceeds
              <span className="val">{fmtPct(thresholdP, 0)}</span>
            </label>
            <div className="seg">
              {THRESHOLD_PRESETS_BPS.map((t) => (
                <button key={t} className={t === thresholdBps ? "sel" : ""} onClick={() => setThresholdBps(t)} disabled={busy}>
                  {t / 100}%
                </button>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="primary" onClick={() => arm("protect")} disabled={busy}>
              Enable protection (auto-migrate)
            </button>
            <button onClick={() => arm("migrate")} disabled={busy}>
              Migrate now → 95% liq LTV
            </button>
          </div>
          {phase && <p className="note warn">{PHASE_LABEL[phase]}</p>}
          {flowError && <p className="err">{flowError}</p>}
          <p className="note">
            <strong>Migrate now</strong>: your debt is repaid via flashloan, collateral teleports into your own
            Twyne vault, and the same debt reopens at 95% liquidation LTV — atomically; the operator grant is
            revoked in the same transaction. <strong>Enable protection</strong>: stores your policy on-chain —
            auto-migrate past {fmtPct(thresholdP, 0)} P₃₀, keeper allowed to act only while your health factor
            is below {(Number(POLICY.hfGateWad) / 1e18).toFixed(2)} (enforced on-chain). Revocable anytime.
            Both flows need one off-chain Morpho authorization signature plus a single EVC batch transaction
            (vault creation included — its address is predicted by simulation).
          </p>

          <CurveChart curve={curve} thresholdP={thresholdP} tripAt={trip} />
          <p className="note">
            σ({TOKENS.collateral.symbol}/{TOKENS.loan.symbol}) = {fmtPct(DEFAULT_SIGMA_S, 1)}/yr (interim
            calibration). Stable pairs move in jumps more than drift, so this curve is sharp — probability sits
            near zero until LTV closes in on {fmtPct(MARKET_LLTV, 1)}, then rises fast. The health-factor gate
            is the model-independent backstop.
          </p>
        </div>
      </section>
    </div>
  )
}

// ---------------------------------------------------------------------------

function StatusView({
  prot,
  pos,
  impaired,
  onChanged,
}: {
  prot: readonly [`0x${string}`, bigint, bigint, boolean]
  pos: Pos | null
  impaired: boolean
  onChanged: () => void
}) {
  const [cv, thresholdBps, hfGateWad, enabled] = prot
  const cvDebt = useReadContract({ address: cv, abi: morphoCvAbi, functionName: "maxRepay", query: { refetchInterval: 15_000 } })
  const cvLiqLtv = useReadContract({ address: cv, abi: morphoCvAbi, functionName: "twyneLiqLTV" })

  const tx = useWriteContract()
  const receipt = useWaitForTransactionReceipt({ hash: tx.data })
  useEffect(() => {
    if (receipt.isSuccess) onChanged()
  }, [receipt.isSuccess]) // eslint-disable-line react-hooks/exhaustive-deps

  const thresholdP = Number(thresholdBps) / 1e4
  const curveParams = pos ? { ltv0: pos.ltv, liqLtv: MARKET_LLTV, sigmaS: DEFAULT_SIGMA_S } : null
  const p30 = curveParams ? liquidationProbability({ ...curveParams, T: HORIZON_YEARS }) : 0
  const curve = useMemo(() => (curveParams ? liquidationCurve(curveParams) : []), [pos?.ltv]) // eslint-disable-line react-hooks/exhaustive-deps
  const trip = curveParams ? tripDay(curveParams, thresholdP) : null

  const migrated = !enabled && (cvDebt.data ?? 0n) > 0n

  return (
    <div>
      {enabled ? (
        <div className="armedBanner">
          <span className="dot" />
          ARMED — watching your position. Auto-migrates past {fmtPct(thresholdP, 0)} P₃₀ (HF gate{" "}
          {(Number(hfGateWad) / 1e18).toFixed(2)}).
        </div>
      ) : migrated ? (
        <MigratedBanner liqLtvBps={(cvLiqLtv.data as bigint | undefined) ?? 0n} />
      ) : (
        <div className="armedBanner">
          <span className="dot" />
          REGISTERED (inactive) — protection has fired or was disabled.
        </div>
      )}

      {enabled && impaired && (
        <p className="note warn" style={{ marginTop: 10 }}>
          Protection impaired: a required grant was revoked (Morpho authorization or an EVC operator). The
          keeper cannot act until you re-run the opt-in.
        </p>
      )}

      <section style={{ marginTop: 4 }}>
        <div className="card" style={{ marginTop: 18 }}>
          <div className="kv">
            <Item k="Your vault" v={cv} mono />
            {pos && pos.borrowAssets > 0n && (
              <>
                <Item k="LTV" v={fmtPct(pos.ltv)} />
                <Item k="P(liq ≤ 30d)" v={fmtPct(p30, 2)} tone={p30 >= thresholdP ? "bad" : "safe"} />
              </>
            )}
            {migrated && (
              <Item k={`Vault debt (${TOKENS.loan.symbol})`} v={formatUnits((cvDebt.data as bigint) ?? 0n, TOKENS.loan.decimals)} />
            )}
          </div>
          {pos && enabled && (
            <div style={{ marginTop: 14 }}>
              <CurveChart curve={curve} thresholdP={thresholdP} tripAt={trip} />
            </div>
          )}
          <div style={{ marginTop: 14, display: "flex", gap: 10 }}>
            {enabled && (
              <button
                className="danger"
                disabled={tx.isPending || receipt.isLoading}
                onClick={() => tx.writeContract({ address: PTO_ADDRESS, abi: morphoPtoAbi, functionName: "unregister" })}
              >
                {tx.isPending || receipt.isLoading ? "Disarming…" : "Disarm Shield"}
              </button>
            )}
          </div>
          {tx.error && <p className="err">{(tx.error as Error).message.split("\n")[0]}</p>}
        </div>
      </section>
    </div>
  )
}

function MigratedBanner({ liqLtvBps }: { liqLtvBps: bigint }) {
  return (
    <div className="armedBanner migratedBanner">
      <span className="dot" />
      MIGRATED — your position now lives on Twyne at {liqLtvBps > 0n ? fmtPct(Number(liqLtvBps) / 1e4, 1) : "…"}{" "}
      liquidation LTV.
    </div>
  )
}

function MigratedCard({ cv, debt, liqLtvBps }: { cv: `0x${string}`; debt: bigint; liqLtvBps: bigint }) {
  return (
    <div>
      <MigratedBanner liqLtvBps={liqLtvBps} />
      <div className="card" style={{ marginTop: 18 }}>
        <div className="kv">
          <Item k="Your vault" v={cv} mono />
          <Item k={`Vault debt (${TOKENS.loan.symbol})`} v={formatUnits(debt, TOKENS.loan.decimals)} />
        </div>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------

function Item({ k, v, tone, mono }: { k: string; v: string; tone?: "safe" | "warn" | "bad"; mono?: boolean }) {
  return (
    <div className="item">
      <div className="k">{k}</div>
      <div className={`v ${tone ?? ""}`} style={mono ? { fontSize: 12, wordBreak: "break-all" } : undefined}>
        {v}
      </div>
    </div>
  )
}
