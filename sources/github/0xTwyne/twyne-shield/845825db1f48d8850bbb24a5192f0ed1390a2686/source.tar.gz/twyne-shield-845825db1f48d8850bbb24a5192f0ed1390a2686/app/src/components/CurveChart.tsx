import { useMemo } from "react"

export interface CurvePoint {
  day: number
  p: number
}

interface Props {
  curve: CurvePoint[]
  thresholdP: number // 0..1
  tripAt: number | null // day the curve first crosses the threshold
}

const W = 680
const H = 210
const PAD = { l: 44, r: 14, t: 12, b: 26 }

/** Probability-vs-horizon curve with the user's threshold drawn as an amber trip-line. */
export default function CurveChart({ curve, thresholdP, tripAt }: Props) {
  const maxDay = curve.length ? curve[curve.length - 1].day : 90
  const maxP = useMemo(() => {
    const peak = Math.max(...curve.map((c) => c.p), thresholdP)
    return Math.min(1, Math.max(0.02, peak * 1.25))
  }, [curve, thresholdP])

  const x = (day: number) => PAD.l + ((W - PAD.l - PAD.r) * day) / maxDay
  const y = (p: number) => H - PAD.b - ((H - PAD.t - PAD.b) * p) / maxP

  const path = useMemo(
    () => curve.map((c, i) => `${i === 0 ? "M" : "L"}${x(c.day).toFixed(1)},${y(c.p).toFixed(1)}`).join(" "),
    [curve, maxP], // eslint-disable-line react-hooks/exhaustive-deps
  )

  const yTicks = [0, maxP / 2, maxP]
  const xTicks = [0, 30, 60, 90].filter((d) => d <= maxDay)

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Liquidation probability vs horizon">
      {/* grid + axes */}
      {yTicks.map((t) => (
        <g key={t}>
          <line x1={PAD.l} x2={W - PAD.r} y1={y(t)} y2={y(t)} stroke="var(--line)" strokeWidth="1" />
          <text x={PAD.l - 6} y={y(t) + 4} textAnchor="end" fontSize="10" fill="var(--muted)" fontFamily="var(--mono)">
            {(t * 100).toFixed(t < 0.05 ? 1 : 0)}%
          </text>
        </g>
      ))}
      {xTicks.map((d) => (
        <text key={d} x={x(d)} y={H - 8} textAnchor="middle" fontSize="10" fill="var(--muted)" fontFamily="var(--mono)">
          {d}d
        </text>
      ))}

      {/* threshold trip-line */}
      <line
        x1={PAD.l}
        x2={W - PAD.r}
        y1={y(thresholdP)}
        y2={y(thresholdP)}
        stroke="var(--armed)"
        strokeWidth="1.5"
        strokeDasharray="6 4"
      />
      <text
        x={W - PAD.r}
        y={y(thresholdP) - 5}
        textAnchor="end"
        fontSize="10"
        fill="var(--armed)"
        fontFamily="var(--mono)"
      >
        trigger {(thresholdP * 100).toFixed(0)}%
      </text>

      {/* the curve */}
      <path d={path} fill="none" stroke="var(--text)" strokeWidth="2" />

      {/* trip marker */}
      {tripAt !== null && (
        <g>
          <line x1={x(tripAt)} x2={x(tripAt)} y1={y(thresholdP)} y2={H - PAD.b} stroke="var(--armed)" strokeWidth="1" />
          <circle cx={x(tripAt)} cy={y(thresholdP)} r="4" fill="var(--armed)" />
          <text
            x={x(tripAt) + 6}
            y={y(thresholdP) + 14}
            fontSize="10"
            fill="var(--armed)"
            fontFamily="var(--mono)"
          >
            trips ≤ {tripAt}d
          </text>
        </g>
      )}
    </svg>
  )
}
