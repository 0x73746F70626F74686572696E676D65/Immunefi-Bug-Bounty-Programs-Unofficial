// Minimal hand-vendored ABIs for the Robinhood/Morpho flow — only the members this app calls.

const marketParamsComponents = [
  { name: "loanToken", type: "address" },
  { name: "collateralToken", type: "address" },
  { name: "oracle", type: "address" },
  { name: "irm", type: "address" },
  { name: "lltv", type: "uint256" },
] as const

export const morphoAbi = [
  {
    type: "function",
    name: "position",
    stateMutability: "view",
    inputs: [
      { name: "id", type: "bytes32" },
      { name: "user", type: "address" },
    ],
    outputs: [
      { name: "supplyShares", type: "uint256" },
      { name: "borrowShares", type: "uint128" },
      { name: "collateral", type: "uint128" },
    ],
  },
  {
    type: "function",
    name: "market",
    stateMutability: "view",
    inputs: [{ name: "id", type: "bytes32" }],
    outputs: [
      { name: "totalSupplyAssets", type: "uint128" },
      { name: "totalSupplyShares", type: "uint128" },
      { name: "totalBorrowAssets", type: "uint128" },
      { name: "totalBorrowShares", type: "uint128" },
      { name: "lastUpdate", type: "uint128" },
      { name: "fee", type: "uint128" },
    ],
  },
  {
    type: "function",
    name: "setAuthorization",
    stateMutability: "nonpayable",
    inputs: [
      { name: "authorized", type: "address" },
      { name: "newIsAuthorized", type: "bool" },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "isAuthorized",
    stateMutability: "view",
    inputs: [
      { name: "authorizer", type: "address" },
      { name: "authorized", type: "address" },
    ],
    outputs: [{ type: "bool" }],
  },
  {
    type: "function",
    name: "nonce",
    stateMutability: "view",
    inputs: [{ name: "authorizer", type: "address" }],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "setAuthorizationWithSig",
    stateMutability: "nonpayable",
    inputs: [
      {
        name: "authorization",
        type: "tuple",
        components: [
          { name: "authorizer", type: "address" },
          { name: "authorized", type: "address" },
          { name: "isAuthorized", type: "bool" },
          { name: "nonce", type: "uint256" },
          { name: "deadline", type: "uint256" },
        ],
      },
      {
        name: "signature",
        type: "tuple",
        components: [
          { name: "v", type: "uint8" },
          { name: "r", type: "bytes32" },
          { name: "s", type: "bytes32" },
        ],
      },
    ],
    outputs: [],
  },
] as const

export const oracleAbi = [
  { type: "function", name: "price", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
] as const

export const morphoFactoryAbi = [
  {
    type: "function",
    name: "createMorphoCollateralVault",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_intermediateVault", type: "address" },
      { name: "_targetVault", type: "address" },
      { name: "_marketParams", type: "tuple", components: marketParamsComponents },
      { name: "_liqLTV", type: "uint256" },
    ],
    outputs: [{ name: "vault", type: "address" }],
  },
  {
    type: "function",
    name: "getCollateralVaults",
    stateMutability: "view",
    inputs: [{ name: "borrower", type: "address" }],
    outputs: [{ type: "address[]" }],
  },
  {
    type: "function",
    name: "isCollateralVault",
    stateMutability: "view",
    inputs: [{ name: "vault", type: "address" }],
    outputs: [{ type: "bool" }],
  },
] as const

export const morphoCvAbi = [
  { type: "function", name: "borrower", stateMutability: "view", inputs: [], outputs: [{ type: "address" }] },
  {
    type: "function",
    name: "marketParams",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "tuple", components: marketParamsComponents }],
  },
  { type: "function", name: "maxRepay", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
  { type: "function", name: "twyneLiqLTV", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] },
] as const

export const morphoTeleportAbi = [
  {
    type: "function",
    name: "executeTeleport",
    stateMutability: "nonpayable",
    inputs: [
      { name: "collateralVault", type: "address" },
      { name: "collateralAmount", type: "uint256" },
      { name: "debtAmount", type: "uint256" },
    ],
    outputs: [],
  },
] as const

export const morphoPtoAbi = [
  {
    type: "function",
    name: "protections",
    stateMutability: "view",
    inputs: [{ name: "user", type: "address" }],
    outputs: [
      { name: "collateralVault", type: "address" },
      { name: "probThresholdBps", type: "uint96" },
      { name: "hfGateWad", type: "uint256" },
      { name: "enabled", type: "bool" },
    ],
  },
  {
    type: "function",
    name: "register",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_collateralVault", type: "address" },
      { name: "_hfGateWad", type: "uint256" },
      { name: "_probThresholdBps", type: "uint96" },
    ],
    outputs: [],
  },
  { type: "function", name: "unregister", stateMutability: "nonpayable", inputs: [], outputs: [] },
  { type: "function", name: "keeper", stateMutability: "view", inputs: [], outputs: [{ type: "address" }] },
] as const

export const evcAbi = [
  {
    type: "function",
    name: "setAccountOperator",
    stateMutability: "payable",
    inputs: [
      { name: "account", type: "address" },
      { name: "operator", type: "address" },
      { name: "authorized", type: "bool" },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "isAccountOperatorAuthorized",
    stateMutability: "view",
    inputs: [
      { name: "account", type: "address" },
      { name: "operator", type: "address" },
    ],
    outputs: [{ type: "bool" }],
  },
  {
    type: "function",
    name: "batch",
    stateMutability: "payable",
    inputs: [
      {
        name: "items",
        type: "tuple[]",
        components: [
          { name: "targetContract", type: "address" },
          { name: "onBehalfOfAccount", type: "address" },
          { name: "value", type: "uint256" },
          { name: "data", type: "bytes" },
        ],
      },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "batchSimulation",
    stateMutability: "payable",
    inputs: [
      {
        name: "items",
        type: "tuple[]",
        components: [
          { name: "targetContract", type: "address" },
          { name: "onBehalfOfAccount", type: "address" },
          { name: "value", type: "uint256" },
          { name: "data", type: "bytes" },
        ],
      },
    ],
    outputs: [
      {
        name: "batchItemsResult",
        type: "tuple[]",
        components: [
          { name: "success", type: "bool" },
          { name: "result", type: "bytes" },
        ],
      },
      {
        name: "accountsStatusCheckResult",
        type: "tuple[]",
        components: [
          { name: "checkedAddress", type: "address" },
          { name: "isValid", type: "bool" },
          { name: "result", type: "bytes" },
        ],
      },
      {
        name: "vaultsStatusCheckResult",
        type: "tuple[]",
        components: [
          { name: "checkedAddress", type: "address" },
          { name: "isValid", type: "bool" },
          { name: "result", type: "bytes" },
        ],
      },
    ],
  },
] as const
