// Minimal hand-vendored ABIs — only the members this app calls.
export const erc20Abi = [
  {
    type: "function",
    name: "balanceOf",
    stateMutability: "view",
    inputs: [{ name: "a", type: "address" }],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "allowance",
    stateMutability: "view",
    inputs: [
      { name: "o", type: "address" },
      { name: "s", type: "address" },
    ],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "approve",
    stateMutability: "nonpayable",
    inputs: [
      { name: "s", type: "address" },
      { name: "v", type: "uint256" },
    ],
    outputs: [{ type: "bool" }],
  },
] as const

export const aavePoolAbi = [
  {
    type: "function",
    name: "getUserAccountData",
    stateMutability: "view",
    inputs: [{ name: "user", type: "address" }],
    outputs: [
      { name: "totalCollateralBase", type: "uint256" },
      { name: "totalDebtBase", type: "uint256" },
      { name: "availableBorrowsBase", type: "uint256" },
      { name: "currentLiquidationThreshold", type: "uint256" },
      { name: "ltv", type: "uint256" },
      { name: "healthFactor", type: "uint256" },
    ],
  },
  {
    type: "function",
    name: "getReserveAToken",
    stateMutability: "view",
    inputs: [{ name: "asset", type: "address" }],
    outputs: [{ type: "address" }],
  },
  {
    type: "function",
    name: "getReserveVariableDebtToken",
    stateMutability: "view",
    inputs: [{ name: "asset", type: "address" }],
    outputs: [{ type: "address" }],
  },
] as const

export const evcAbi = [
  {
    type: "function",
    name: "setAccountOperator",
    stateMutability: "payable",
    inputs: [
      { name: "account", type: "address" },
      { name: "operator", type: "address" },
      { name: "authorized", type: "bool" },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "isAccountOperatorAuthorized",
    stateMutability: "view",
    inputs: [
      { name: "account", type: "address" },
      { name: "operator", type: "address" },
    ],
    outputs: [{ type: "bool" }],
  },
  {
    type: "function",
    name: "batch",
    stateMutability: "payable",
    inputs: [
      {
        name: "items",
        type: "tuple[]",
        components: [
          { name: "targetContract", type: "address" },
          { name: "onBehalfOfAccount", type: "address" },
          { name: "value", type: "uint256" },
          { name: "data", type: "bytes" },
        ],
      },
    ],
    outputs: [],
  },
] as const

export const factoryAbi = [
  {
    type: "function",
    name: "createCollateralVault",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_vaultType", type: "uint8" },
      { name: "_intermediateVault", type: "address" },
      { name: "_targetVault", type: "address" },
      { name: "_liqLTV", type: "uint256" },
      { name: "_targetAsset", type: "address" },
    ],
    outputs: [{ name: "vault", type: "address" }],
  },
  {
    type: "function",
    name: "getCollateralVaults",
    stateMutability: "view",
    inputs: [{ name: "borrower", type: "address" }],
    outputs: [{ type: "address[]" }],
  },
] as const

export const vaultManagerAbi = [
  {
    type: "function",
    name: "maxTwyneLTVs",
    stateMutability: "view",
    inputs: [{ name: "iv", type: "address" }],
    outputs: [{ type: "uint16" }],
  },
] as const

export const collateralVaultAbi = [
  {
    type: "function",
    name: "borrower",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "address" }],
  },
  {
    type: "function",
    name: "targetAsset",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "address" }],
  },
  {
    type: "function",
    name: "twyneLiqLTV",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "maxRepay",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256" }],
  },
] as const

export const ptoAbi = [
  {
    type: "function",
    name: "protections",
    stateMutability: "view",
    inputs: [{ name: "user", type: "address" }],
    outputs: [
      { name: "collateralVault", type: "address" },
      { name: "probThresholdBps", type: "uint96" },
      { name: "hfGateWad", type: "uint256" },
      { name: "enabled", type: "bool" },
    ],
  },
  {
    type: "function",
    name: "register",
    stateMutability: "nonpayable",
    inputs: [
      { name: "_collateralVault", type: "address" },
      { name: "_hfGateWad", type: "uint256" },
      { name: "_probThresholdBps", type: "uint96" },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "unregister",
    stateMutability: "nonpayable",
    inputs: [],
    outputs: [],
  },
  {
    type: "function",
    name: "keeper",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "address" }],
  },
] as const
