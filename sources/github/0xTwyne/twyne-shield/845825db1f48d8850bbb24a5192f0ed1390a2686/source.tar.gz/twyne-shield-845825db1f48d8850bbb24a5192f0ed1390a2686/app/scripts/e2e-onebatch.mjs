// E2E check of the one-signature + one-EVC-batch flow against an anvil Robinhood fork.
// Mirrors App.tsx `arm()` exactly: EIP-712 Morpho authorization, batchSimulation-predicted vault
// address, single batch send. Run: node scripts/e2e-onebatch.mjs <protect|migrate> <anvil-account-index>
import { createPublicClient, createWalletClient, http, encodeFunctionData, decodeAbiParameters, parseSignature, defineChain, zeroAddress } from "viem"
import { mnemonicToAccount } from "viem/accounts"

const [, , MODE = "protect", INDEX = "6"] = process.argv
const RPC = process.env.RPC ?? "http://127.0.0.1:8545"

// mirror app/src/lib/addresses.ts
const ADDR = {
  evc: "0xef39D6493884C4C84D38a4bFF879Ce16CEdE702a",
  morphoTeleportOperator: "0x87E63679072A8890aab08E825FdA482D4Ceb79F3",
  collateralVaultFactory: "0x55d631c04077D791020e0416D7A27509a43E33Ef",
  intermediateVault: "0x87b8081A3ace680f35125F469526Ac10f5418Ca7",
  morpho: "0x9D53d5E3bd5E8d4Cbfa6DB1ca238AEA02E651010",
}
const PTO = "0xc64972086Fd74DDf1718B526033EACaB3fF3Ba54"
const MARKET_PARAMS = {
  loanToken: "0x5fc5360D0400a0Fd4f2af552ADD042D716F1d168",
  collateralToken: "0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34",
  oracle: "0xE64849bd4AD03DfaBbe02bb521de19997a19055f",
  irm: "0x2BD3d5965B26B51814AC95127B2b80dD6CcC0fa1",
  lltv: 915000000000000000n,
}
const POLICY = { probThresholdBps: 1000n, hfGateWad: 1100000000000000000n, cvLiqLtvBps: 9500n }

const morphoAbi = [
  { type: "function", name: "nonce", stateMutability: "view", inputs: [{ type: "address" }], outputs: [{ type: "uint256" }] },
  { type: "function", name: "isAuthorized", stateMutability: "view", inputs: [{ type: "address" }, { type: "address" }], outputs: [{ type: "bool" }] },
  { type: "function", name: "position", stateMutability: "view", inputs: [{ type: "bytes32" }, { type: "address" }], outputs: [{ type: "uint256" }, { type: "uint128" }, { type: "uint128" }] },
  {
    type: "function", name: "setAuthorizationWithSig", stateMutability: "nonpayable",
    inputs: [
      { name: "authorization", type: "tuple", components: [{ name: "authorizer", type: "address" }, { name: "authorized", type: "address" }, { name: "isAuthorized", type: "bool" }, { name: "nonce", type: "uint256" }, { name: "deadline", type: "uint256" }] },
      { name: "signature", type: "tuple", components: [{ name: "v", type: "uint8" }, { name: "r", type: "bytes32" }, { name: "s", type: "bytes32" }] },
    ], outputs: [],
  },
]
const factoryAbi = [
  { type: "function", name: "createMorphoCollateralVault", stateMutability: "nonpayable", inputs: [{ type: "address" }, { type: "address" }, { name: "mp", type: "tuple", components: [{ name: "loanToken", type: "address" }, { name: "collateralToken", type: "address" }, { name: "oracle", type: "address" }, { name: "irm", type: "address" }, { name: "lltv", type: "uint256" }] }, { type: "uint256" }], outputs: [{ type: "address" }] },
]
const ptoAbi = [
  { type: "function", name: "register", stateMutability: "nonpayable", inputs: [{ type: "address" }, { type: "uint256" }, { type: "uint96" }], outputs: [] },
  { type: "function", name: "protections", stateMutability: "view", inputs: [{ type: "address" }], outputs: [{ type: "address" }, { type: "uint96" }, { type: "uint256" }, { type: "bool" }] },
]
const teleportAbi = [
  { type: "function", name: "executeTeleport", stateMutability: "nonpayable", inputs: [{ type: "address" }, { type: "uint256" }, { type: "uint256" }], outputs: [] },
]
const cvAbi = [{ type: "function", name: "maxRepay", stateMutability: "view", inputs: [], outputs: [{ type: "uint256" }] }]
const evcAbi = [
  { type: "function", name: "setAccountOperator", stateMutability: "payable", inputs: [{ type: "address" }, { type: "address" }, { type: "bool" }], outputs: [] },
  { type: "function", name: "batch", stateMutability: "payable", inputs: [{ name: "items", type: "tuple[]", components: [{ name: "targetContract", type: "address" }, { name: "onBehalfOfAccount", type: "address" }, { name: "value", type: "uint256" }, { name: "data", type: "bytes" }] }], outputs: [] },
  { type: "function", name: "batchSimulation", stateMutability: "payable", inputs: [{ name: "items", type: "tuple[]", components: [{ name: "targetContract", type: "address" }, { name: "onBehalfOfAccount", type: "address" }, { name: "value", type: "uint256" }, { name: "data", type: "bytes" }] }], outputs: [{ name: "batchItemsResult", type: "tuple[]", components: [{ name: "success", type: "bool" }, { name: "result", type: "bytes" }] }, { name: "a", type: "tuple[]", components: [{ name: "checkedAddress", type: "address" }, { name: "isValid", type: "bool" }, { name: "result", type: "bytes" }] }, { name: "v", type: "tuple[]", components: [{ name: "checkedAddress", type: "address" }, { name: "isValid", type: "bool" }, { name: "result", type: "bytes" }] }] },
]

const chain = defineChain({ id: 4663, name: "Robinhood Fork", nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 }, rpcUrls: { default: { http: [RPC] } } })
const account = mnemonicToAccount("test test test test test test test test test test test junk", { addressIndex: Number(INDEX) })
const pub = createPublicClient({ chain, transport: http(RPC) })
const wallet = createWalletClient({ chain, transport: http(RPC), account })
const user = account.address

const MARKET_ID = (await import("viem")).keccak256(
  (await import("viem")).encodeAbiParameters(
    [{ type: "address" }, { type: "address" }, { type: "address" }, { type: "address" }, { type: "uint256" }],
    [MARKET_PARAMS.loanToken, MARKET_PARAMS.collateralToken, MARKET_PARAMS.oracle, MARKET_PARAMS.irm, MARKET_PARAMS.lltv],
  ),
)

console.log(`mode=${MODE} user=${user}`)
const items = []

// 1. Morpho authorization via EIP-712 signature (mirrors app)
const nonce = await pub.readContract({ address: ADDR.morpho, abi: morphoAbi, functionName: "nonce", args: [user] })
const authorization = { authorizer: user, authorized: ADDR.morphoTeleportOperator, isAuthorized: true, nonce, deadline: BigInt(Math.floor(Date.now() / 1000) + 3600) }
const sigHex = await account.signTypedData({
  domain: { chainId: chain.id, verifyingContract: ADDR.morpho },
  types: { Authorization: [{ name: "authorizer", type: "address" }, { name: "authorized", type: "address" }, { name: "isAuthorized", type: "bool" }, { name: "nonce", type: "uint256" }, { name: "deadline", type: "uint256" }] },
  primaryType: "Authorization",
  message: authorization,
})
const sig = parseSignature(sigHex)
const v = sig.v !== undefined ? Number(sig.v) : sig.yParity + 27
items.push({ targetContract: ADDR.morpho, onBehalfOfAccount: user, value: 0n, data: encodeFunctionData({ abi: morphoAbi, functionName: "setAuthorizationWithSig", args: [authorization, { v, r: sig.r, s: sig.s }] }) })

// 2. Vault creation inside the batch; address predicted via batchSimulation
const createIdx = items.length
items.push({ targetContract: ADDR.collateralVaultFactory, onBehalfOfAccount: user, value: 0n, data: encodeFunctionData({ abi: factoryAbi, functionName: "createMorphoCollateralVault", args: [ADDR.intermediateVault, ADDR.morpho, MARKET_PARAMS, POLICY.cvLiqLtvBps] }) })
const sim = await pub.simulateContract({ address: ADDR.evc, abi: evcAbi, functionName: "batchSimulation", args: [items], account: user })
const createRes = sim.result[0][createIdx]
if (!createRes.success) throw new Error("simulation: create failed")
const cv = decodeAbiParameters([{ type: "address" }], createRes.result)[0]
console.log("predicted vault:", cv)

// 3. grants + action
const grant = (operator, authorized) => ({ targetContract: ADDR.evc, onBehalfOfAccount: zeroAddress, value: 0n, data: encodeFunctionData({ abi: evcAbi, functionName: "setAccountOperator", args: [user, operator, authorized] }) })
if (MODE === "migrate") {
  items.push(grant(ADDR.morphoTeleportOperator, true))
  items.push({ targetContract: ADDR.morphoTeleportOperator, onBehalfOfAccount: user, value: 0n, data: encodeFunctionData({ abi: teleportAbi, functionName: "executeTeleport", args: [cv, 2n ** 256n - 1n, 2n ** 256n - 1n] }) })
  items.push(grant(ADDR.morphoTeleportOperator, false))
} else {
  items.push(grant(ADDR.morphoTeleportOperator, true))
  items.push(grant(PTO, true))
  items.push({ targetContract: PTO, onBehalfOfAccount: user, value: 0n, data: encodeFunctionData({ abi: ptoAbi, functionName: "register", args: [cv, POLICY.hfGateWad, POLICY.probThresholdBps] }) })
}

// 4. ONE transaction
const hash = await wallet.writeContract({ address: ADDR.evc, abi: evcAbi, functionName: "batch", args: [items], gas: 3_000_000n })
const rcpt = await pub.waitForTransactionReceipt({ hash })
if (rcpt.status !== "success") throw new Error(`batch reverted: ${hash}`)
console.log(`batch tx ok (${items.length} items):`, hash)

// 5. asserts
const authorized = await pub.readContract({ address: ADDR.morpho, abi: morphoAbi, functionName: "isAuthorized", args: [user, ADDR.morphoTeleportOperator] })
if (MODE === "migrate") {
  const [, borrowShares, collateral] = await pub.readContract({ address: ADDR.morpho, abi: morphoAbi, functionName: "position", args: [MARKET_ID, user] })
  const cvDebt = await pub.readContract({ address: cv, abi: cvAbi, functionName: "maxRepay" })
  console.log(`asserts: morpho position=(${borrowShares},${collateral}) cvDebt=${cvDebt} teleportAuthStanding=${authorized}`)
  if (borrowShares !== 0n || collateral !== 0n || cvDebt === 0n) throw new Error("migrate assertions failed")
} else {
  const [pcv, thr, gate, enabled] = await pub.readContract({ address: PTO, abi: ptoAbi, functionName: "protections", args: [user] })
  console.log(`asserts: protections=(cv=${pcv}, thr=${thr}, gate=${gate}, enabled=${enabled}) morphoAuth=${authorized}`)
  if (pcv.toLowerCase() !== cv.toLowerCase() || !enabled || !authorized) throw new Error("protect assertions failed")
}
console.log("E2E OK")
