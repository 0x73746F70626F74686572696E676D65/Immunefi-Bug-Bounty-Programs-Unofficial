// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {EVCUtil} from "ethereum-vault-connector/utils/EVCUtil.sol";
import {ReentrancyGuardTransient} from "openzeppelin-contracts/utils/ReentrancyGuardTransient.sol";
import {ICollateralVaultFactory} from "./interfaces/IExternal.sol";
import {
    IMorphoCollateralVault,
    IMorphoMinimal,
    IMorphoTeleportOperator,
    IOracleMinimal,
    MarketParams
} from "./interfaces/IMorphoExternal.sol";

/// @title MorphoProtectionTriggerOperator
/// @notice Morpho Blue variant of the protection trigger (Robinhood chain deployment). Same trust model as
///         the Aave variant: users register a policy binding their pre-created Twyne MorphoCollateralVault
///         to an on-chain health-factor gate; the keeper may trigger a migration (via the production
///         MorphoTeleportOperator) only while the user's live Morpho health factor is below their gate.
/// @dev    Health is computed exactly like Morpho's `_isHealthy`: interest accrued first, borrow shares
///         converted to assets rounding up, maxBorrow = collateral * oraclePrice / 1e36 * lltv / 1e18,
///         HF(wad) = maxBorrow * 1e18 / borrowAssets. The user's source position and the vault's target
///         market are the same market by construction (the teleport reads marketParams from the vault).
/// @dev    Opt-in grants (vs the Aave variant): EVC operator grants for BOTH operators are identical, but
///         instead of an aToken allowance the user calls `Morpho.setAuthorization(morphoTeleportOperator,
///         true)` so the teleport can withdraw their collateral on their behalf.
contract MorphoProtectionTriggerOperator is ReentrancyGuardTransient, EVCUtil {
    struct Protection {
        address collateralVault; // pre-created MorphoCollateralVault, borrower == user
        uint96 probThresholdBps; // P(liquidation within 30d) keeper trigger threshold, in basis points
        uint hfGateWad; // migration allowed only while Morpho HF < hfGateWad (1e18 scale)
        bool enabled; // set false after a successful migration (terminal action)
    }

    uint public constant MIN_HF_GATE = 1.01e18;
    uint public constant MAX_HF_GATE = 1.5e18;
    uint96 public constant MIN_THRESHOLD_BPS = 100;
    uint96 public constant MAX_THRESHOLD_BPS = 5000;

    uint internal constant ORACLE_PRICE_SCALE = 1e36;
    uint internal constant VIRTUAL_SHARES = 1e6;
    uint internal constant VIRTUAL_ASSETS = 1;
    uint internal constant WAD = 1e18;

    IMorphoTeleportOperator public immutable teleportOperator;
    ICollateralVaultFactory public immutable collateralVaultFactory;
    IMorphoMinimal public immutable morpho;

    address public owner;
    address public keeper;
    mapping(address user => Protection protection) public protections;

    event S_Registered(address indexed user, address indexed collateralVault, uint hfGateWad, uint96 probThresholdBps);
    event S_PolicyUpdated(address indexed user, uint hfGateWad, uint96 probThresholdBps);
    event S_Unregistered(address indexed user);
    event S_ProtectionExecuted(address indexed user, address indexed collateralVault, uint healthFactorAtTrigger);
    event S_KeeperUpdated(address keeper);
    event S_OwnerUpdated(address owner);

    error S_NotOwner();
    error S_NotKeeper();
    error S_NotRegistered();
    error S_NotEnabled();
    error S_InvalidCollateralVault();
    error S_NotBorrower();
    error S_PolicyOutOfRange();
    error S_NoDebt();
    error S_HealthFactorAboveGate(uint healthFactor, uint hfGateWad);
    error S_ZeroAddress();

    constructor(address _evc, address _teleportOperator, address _collateralVaultFactory, address _morpho)
        EVCUtil(_evc)
    {
        require(
            _teleportOperator != address(0) && _collateralVaultFactory != address(0) && _morpho != address(0),
            S_ZeroAddress()
        );
        teleportOperator = IMorphoTeleportOperator(_teleportOperator);
        collateralVaultFactory = ICollateralVaultFactory(_collateralVaultFactory);
        morpho = IMorphoMinimal(_morpho);
        owner = msg.sender;
        keeper = msg.sender;
    }

    // ------------------------------------------------------------------
    // User API — EVC-aware (_msgSender), callable directly or via EVC batch
    // ------------------------------------------------------------------

    function register(address _collateralVault, uint _hfGateWad, uint96 _probThresholdBps) external {
        address user = _msgSender();
        require(collateralVaultFactory.isCollateralVault(_collateralVault), S_InvalidCollateralVault());
        require(IMorphoCollateralVault(_collateralVault).borrower() == user, S_NotBorrower());
        _checkPolicy(_hfGateWad, _probThresholdBps);
        protections[user] = Protection({
            collateralVault: _collateralVault,
            probThresholdBps: _probThresholdBps,
            hfGateWad: _hfGateWad,
            enabled: true
        });
        emit S_Registered(user, _collateralVault, _hfGateWad, _probThresholdBps);
    }

    function setPolicy(uint _hfGateWad, uint96 _probThresholdBps) external {
        address user = _msgSender();
        Protection storage p = protections[user];
        require(p.collateralVault != address(0), S_NotRegistered());
        _checkPolicy(_hfGateWad, _probThresholdBps);
        p.hfGateWad = _hfGateWad;
        p.probThresholdBps = _probThresholdBps;
        emit S_PolicyUpdated(user, _hfGateWad, _probThresholdBps);
    }

    function unregister() external {
        address user = _msgSender();
        require(protections[user].collateralVault != address(0), S_NotRegistered());
        delete protections[user];
        emit S_Unregistered(user);
    }

    // ------------------------------------------------------------------
    // Keeper API
    // ------------------------------------------------------------------

    /// @notice Migrate the user's full Morpho position into their registered Twyne collateral vault.
    function triggerMigration(address _user) external nonReentrant {
        require(msg.sender == keeper, S_NotKeeper());
        Protection memory p = protections[_user];
        require(p.collateralVault != address(0), S_NotRegistered());
        require(p.enabled, S_NotEnabled());

        MarketParams memory mp = IMorphoCollateralVault(p.collateralVault).marketParams();
        uint healthFactor = _healthFactor(mp, _user);
        require(healthFactor < p.hfGateWad, S_HealthFactorAboveGate(healthFactor, p.hfGateWad));

        protections[_user].enabled = false;

        evc.call(
            address(teleportOperator),
            _user,
            0,
            abi.encodeCall(IMorphoTeleportOperator.executeTeleport, (p.collateralVault, type(uint).max, type(uint).max))
        );

        emit S_ProtectionExecuted(_user, p.collateralVault, healthFactor);
    }

    /// @notice Public view of the gate input (also used by the keeper's pre-flight and the dApp).
    /// @dev    Off-chain callers should eth_call `previewHealthFactor` for an accrual-fresh value.
    function previewHealthFactor(address _user) external returns (uint) {
        Protection memory p = protections[_user];
        require(p.collateralVault != address(0), S_NotRegistered());
        return _healthFactor(IMorphoCollateralVault(p.collateralVault).marketParams(), _user);
    }

    // ------------------------------------------------------------------
    // Admin
    // ------------------------------------------------------------------

    function setKeeper(address _keeper) external {
        require(msg.sender == owner, S_NotOwner());
        require(_keeper != address(0), S_ZeroAddress());
        keeper = _keeper;
        emit S_KeeperUpdated(_keeper);
    }

    function transferOwnership(address _owner) external {
        require(msg.sender == owner, S_NotOwner());
        require(_owner != address(0), S_ZeroAddress());
        owner = _owner;
        emit S_OwnerUpdated(_owner);
    }

    // ------------------------------------------------------------------
    // Internal
    // ------------------------------------------------------------------

    /// @dev Morpho `_isHealthy` math with fresh interest accrual. Reverts if the user has no debt on the
    ///      vault's market (nothing to protect — the gate must not pass on empty positions).
    function _healthFactor(MarketParams memory mp, address _user) internal returns (uint) {
        morpho.accrueInterest(mp);

        bytes32 id = _marketId(mp);
        (, uint128 borrowShares, uint128 collateral) = morpho.position(id, _user);
        require(borrowShares > 0, S_NoDebt());

        (,, uint128 totalBorrowAssets, uint128 totalBorrowShares,,) = morpho.market(id);

        // SharesMathLib.toAssetsUp(shares, totalAssets, totalShares)
        uint borrowAssets = _mulDivUp(uint(borrowShares), uint(totalBorrowAssets) + VIRTUAL_ASSETS, uint(totalBorrowShares) + VIRTUAL_SHARES);

        uint price = IOracleMinimal(mp.oracle).price();
        uint maxBorrow = (uint(collateral) * price / ORACLE_PRICE_SCALE) * mp.lltv / WAD;

        return maxBorrow * WAD / borrowAssets;
    }

    /// @dev keccak256(abi.encode(marketParams)) — MarketParamsLib.id.
    function _marketId(MarketParams memory mp) internal pure returns (bytes32 id) {
        assembly ("memory-safe") {
            id := keccak256(mp, 160)
        }
    }

    function _mulDivUp(uint x, uint y, uint d) internal pure returns (uint) {
        return (x * y + (d - 1)) / d;
    }

    function _checkPolicy(uint _hfGateWad, uint96 _probThresholdBps) internal pure {
        require(
            _hfGateWad >= MIN_HF_GATE && _hfGateWad <= MAX_HF_GATE && _probThresholdBps >= MIN_THRESHOLD_BPS
                && _probThresholdBps <= MAX_THRESHOLD_BPS,
            S_PolicyOutOfRange()
        );
    }
}
