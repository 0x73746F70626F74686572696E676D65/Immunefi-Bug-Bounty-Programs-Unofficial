// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {EVCUtil} from "ethereum-vault-connector/utils/EVCUtil.sol";
import {ReentrancyGuardTransient} from "openzeppelin-contracts/utils/ReentrancyGuardTransient.sol";
import {
    IAaveV3PoolMinimal,
    IAaveV3TeleportOperator,
    ICollateralVault,
    ICollateralVaultFactory
} from "./interfaces/IExternal.sol";

/// @title ProtectionTriggerOperator
/// @notice Automated liquidation protection for Aave V3 positions on Twyne. A user with an existing Aave
///         position pre-creates a Twyne collateral vault, grants EVC operator status to this contract and to
///         the audited AaveV3TeleportOperator, approves their aTokens to the teleport operator, and registers
///         a policy here. An authorized keeper may then trigger the migration of the user's Aave position into
///         their Twyne vault — but only while the user's live Aave health factor is below the user's own
///         hfGateWad. The probability threshold (probThresholdBps) is stored on-chain as the auditable policy
///         the off-chain keeper evaluates; the health-factor gate is the trustless enforcement.
/// @dev    Worst-case keeper misbehavior or key compromise = an early (HF-gated) migration of the user's
///         position into the user's own vault. The keeper can never move funds anywhere else.
contract ProtectionTriggerOperator is ReentrancyGuardTransient, EVCUtil {
    struct Protection {
        address collateralVault; // pre-created AaveV3CollateralVault with borrower == user
        uint96 probThresholdBps; // P(liquidation within 30d) keeper trigger threshold, in basis points
        uint hfGateWad; // migration allowed only while Aave healthFactor < hfGateWad (1e18 scale)
        bool enabled; // set false after a successful migration (terminal action)
    }

    uint public constant MIN_HF_GATE = 1.01e18;
    uint public constant MAX_HF_GATE = 1.5e18;
    uint96 public constant MIN_THRESHOLD_BPS = 100;
    uint96 public constant MAX_THRESHOLD_BPS = 5000;

    IAaveV3TeleportOperator public immutable teleportOperator;
    ICollateralVaultFactory public immutable collateralVaultFactory;
    IAaveV3PoolMinimal public immutable aavePool;

    address public owner;
    address public keeper;
    mapping(address user => Protection protection) public protections;

    event S_Registered(address indexed user, address indexed collateralVault, uint hfGateWad, uint96 probThresholdBps);
    event S_PolicyUpdated(address indexed user, uint hfGateWad, uint96 probThresholdBps);
    event S_Unregistered(address indexed user);
    event S_ProtectionExecuted(address indexed user, address indexed collateralVault, uint healthFactorAtTrigger);
    event S_KeeperUpdated(address keeper);
    event S_OwnerUpdated(address owner);

    error S_NotOwner();
    error S_NotKeeper();
    error S_NotRegistered();
    error S_NotEnabled();
    error S_InvalidCollateralVault();
    error S_NotBorrower();
    error S_PolicyOutOfRange();
    error S_HealthFactorAboveGate(uint healthFactor, uint hfGateWad);
    error S_ZeroAddress();

    constructor(address _evc, address _teleportOperator, address _collateralVaultFactory, address _aavePool)
        EVCUtil(_evc)
    {
        require(
            _teleportOperator != address(0) && _collateralVaultFactory != address(0) && _aavePool != address(0),
            S_ZeroAddress()
        );
        teleportOperator = IAaveV3TeleportOperator(_teleportOperator);
        collateralVaultFactory = ICollateralVaultFactory(_collateralVaultFactory);
        aavePool = IAaveV3PoolMinimal(_aavePool);
        owner = msg.sender;
        keeper = msg.sender;
    }

    // ------------------------------------------------------------------
    // User API — EVC-aware (_msgSender), callable directly or via EVC batch
    // ------------------------------------------------------------------

    /// @notice Register (or re-register) protection. Re-registration overwrites the previous policy, which
    ///         also re-arms protection after a migration once the user has a fresh vault.
    function register(address _collateralVault, uint _hfGateWad, uint96 _probThresholdBps) external {
        address user = _msgSender();
        require(collateralVaultFactory.isCollateralVault(_collateralVault), S_InvalidCollateralVault());
        require(ICollateralVault(_collateralVault).borrower() == user, S_NotBorrower());
        _checkPolicy(_hfGateWad, _probThresholdBps);
        protections[user] = Protection({
            collateralVault: _collateralVault,
            probThresholdBps: _probThresholdBps,
            hfGateWad: _hfGateWad,
            enabled: true
        });
        emit S_Registered(user, _collateralVault, _hfGateWad, _probThresholdBps);
    }

    function setPolicy(uint _hfGateWad, uint96 _probThresholdBps) external {
        address user = _msgSender();
        Protection storage p = protections[user];
        require(p.collateralVault != address(0), S_NotRegistered());
        _checkPolicy(_hfGateWad, _probThresholdBps);
        p.hfGateWad = _hfGateWad;
        p.probThresholdBps = _probThresholdBps;
        emit S_PolicyUpdated(user, _hfGateWad, _probThresholdBps);
    }

    function unregister() external {
        address user = _msgSender();
        require(protections[user].collateralVault != address(0), S_NotRegistered());
        delete protections[user];
        emit S_Unregistered(user);
    }

    // ------------------------------------------------------------------
    // Keeper API — plain msg.sender by design: the keeper is an EOA that
    // calls directly, never through the EVC.
    // ------------------------------------------------------------------

    /// @notice Migrate the user's full Aave position into their registered Twyne collateral vault.
    /// @dev    Enforcement: registered + enabled + live Aave HF below the user's gate. The teleport operator
    ///         re-verifies borrower == user through the EVC context; both operators must hold EVC operator
    ///         grants from the user and the teleport operator needs an aToken allowance, all given at opt-in.
    function triggerMigration(address _user) external nonReentrant {
        require(msg.sender == keeper, S_NotKeeper());
        Protection memory p = protections[_user];
        require(p.collateralVault != address(0), S_NotRegistered());
        require(p.enabled, S_NotEnabled());

        (,,,,, uint healthFactor) = aavePool.getUserAccountData(_user);
        require(healthFactor < p.hfGateWad, S_HealthFactorAboveGate(healthFactor, p.hfGateWad));

        protections[_user].enabled = false;

        evc.call(
            address(teleportOperator),
            _user,
            0,
            abi.encodeCall(IAaveV3TeleportOperator.executeTeleport, (p.collateralVault, type(uint).max, type(uint).max))
        );

        emit S_ProtectionExecuted(_user, p.collateralVault, healthFactor);
    }

    // ------------------------------------------------------------------
    // Admin
    // ------------------------------------------------------------------

    function setKeeper(address _keeper) external {
        require(msg.sender == owner, S_NotOwner());
        require(_keeper != address(0), S_ZeroAddress());
        keeper = _keeper;
        emit S_KeeperUpdated(_keeper);
    }

    function transferOwnership(address _owner) external {
        require(msg.sender == owner, S_NotOwner());
        require(_owner != address(0), S_ZeroAddress());
        owner = _owner;
        emit S_OwnerUpdated(_owner);
    }

    function _checkPolicy(uint _hfGateWad, uint96 _probThresholdBps) internal pure {
        require(
            _hfGateWad >= MIN_HF_GATE && _hfGateWad <= MAX_HF_GATE && _probThresholdBps >= MIN_THRESHOLD_BPS
                && _probThresholdBps <= MAX_THRESHOLD_BPS,
            S_PolicyOutOfRange()
        );
    }
}
