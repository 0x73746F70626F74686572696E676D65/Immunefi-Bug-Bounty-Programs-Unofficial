// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// Minimal Morpho Blue interfaces — only the members the Morpho protection trigger calls.
/// Mirrors morpho-blue/src/interfaces/IMorpho.sol structs exactly (ABI-compatible).

struct MarketParams {
    address loanToken;
    address collateralToken;
    address oracle;
    address irm;
    uint lltv;
}

interface IMorphoMinimal {
    /// @dev position(id, user) -> (supplyShares, borrowShares, collateral)
    function position(bytes32 id, address user) external view returns (uint supplyShares, uint128 borrowShares, uint128 collateral);
    /// @dev market(id) -> (totalSupplyAssets, totalSupplyShares, totalBorrowAssets, totalBorrowShares, lastUpdate, fee)
    function market(bytes32 id)
        external
        view
        returns (
            uint128 totalSupplyAssets,
            uint128 totalSupplyShares,
            uint128 totalBorrowAssets,
            uint128 totalBorrowShares,
            uint128 lastUpdate,
            uint128 fee
        );
    function accrueInterest(MarketParams memory marketParams) external;
}

interface IOracleMinimal {
    /// @dev Morpho oracle price of 1 collateral asset quoted in loan asset, scaled by 1e36.
    function price() external view returns (uint);
}

interface IMorphoCollateralVault {
    function borrower() external view returns (address);
    function marketParams() external view returns (MarketParams memory);
}

interface IMorphoTeleportOperator {
    function executeTeleport(address collateralVault, uint collateralAmount, uint debtAmount) external;
}
