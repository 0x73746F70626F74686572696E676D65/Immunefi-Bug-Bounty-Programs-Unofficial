// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// Minimal interfaces vendored from twyne-contracts / Aave V3. Only the members this project calls.

interface IAaveV3PoolMinimal {
    function getUserAccountData(address user)
        external
        view
        returns (
            uint totalCollateralBase,
            uint totalDebtBase,
            uint availableBorrowsBase,
            uint currentLiquidationThreshold,
            uint ltv,
            uint healthFactor
        );
    function supply(address asset, uint amount, address onBehalfOf, uint16 referralCode) external;
    function borrow(address asset, uint amount, uint interestRateMode, uint16 referralCode, address onBehalfOf) external;
    function getReserveAToken(address asset) external view returns (address);
    function ADDRESSES_PROVIDER() external view returns (address);
}

interface IAaveV3TeleportOperator {
    function executeTeleport(address collateralVault, uint aTokenAmount, uint debtAmount) external;
}

interface ICollateralVault {
    function borrower() external view returns (address);
    function targetAsset() external view returns (address);
    function asset() external view returns (address);
    function maxRepay() external view returns (uint);
    function maxRelease() external view returns (uint);
    function twyneLiqLTV() external view returns (uint);
}

interface ICollateralVaultFactory {
    function isCollateralVault(address vault) external view returns (bool);
    // Deployed mainnet factory signature (impl 0x92432BFd3bf81ec55b093F6118063A9D3d01521F):
    // generic create with VaultType enum { EULER_V2 = 0, AAVE_V3 = 1 }.
    function createCollateralVault(
        uint8 _vaultType,
        address _intermediateVault,
        address _targetVault,
        uint _liqLTV,
        address _targetAsset
    ) external returns (address vault);
}

interface ITwyneVaultManager {
    // NOTE: the deployed mainnet VaultManager (impl 0x44134feB6B76A5382b107423FC4a78B23FEE1a40) predates the
    // combined liqParams() view — use the two per-field getters.
    function maxTwyneLTVs(address intermediateVault) external view returns (uint16 maxTwyneLiqLTV);
    function externalLiqBuffers(address intermediateVault) external view returns (uint16 externalLiqBuffer);
}
