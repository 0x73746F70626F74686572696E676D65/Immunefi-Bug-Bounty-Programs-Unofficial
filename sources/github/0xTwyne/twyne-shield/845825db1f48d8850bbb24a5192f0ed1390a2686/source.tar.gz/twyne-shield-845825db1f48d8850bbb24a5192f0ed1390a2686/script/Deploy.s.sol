// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";
import {console} from "forge-std/console.sol";
import {ProtectionTriggerOperator} from "../src/ProtectionTriggerOperator.sol";

/// @notice Deploys ProtectionTriggerOperator wired to the live mainnet Twyne + Aave V3 deployment.
/// @dev    Usage (never write the key to disk; inject via 1Password):
///         op run -- forge script script/Deploy.s.sol --rpc-url $MAINNET_RPC_URL --broadcast
///         Env: DEPLOYER_PRIVATE_KEY (op://...), KEEPER_ADDRESS (the keeper EOA; may equal deployer)
contract Deploy is Script {
    // tech-notes/public-launch-addresses/TwyneAddresses_current_1.json
    address constant EVC = 0xef39D6493884C4C84D38a4bFF879Ce16CEdE702a;
    address constant TELEPORT = 0x868a21426852A775395d4b90De23B3e3E662bd78;
    address constant FACTORY = 0xa1517cCe0bE75700A8838EA1cEE0dc383cd3A332;
    address constant AAVE_POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;

    function run() external {
        uint deployerKey = vm.envUint("DEPLOYER_PRIVATE_KEY");
        address keeper = vm.envAddress("KEEPER_ADDRESS");
        address deployer = vm.addr(deployerKey);

        vm.startBroadcast(deployerKey);
        ProtectionTriggerOperator pto = new ProtectionTriggerOperator(EVC, TELEPORT, FACTORY, AAVE_POOL);
        if (keeper != deployer) {
            pto.setKeeper(keeper);
        }
        vm.stopBroadcast();

        console.log("ProtectionTriggerOperator:", address(pto));
        console.log("owner:", pto.owner());
        console.log("keeper:", pto.keeper());

        string memory json = "deployment";
        vm.serializeAddress(json, "protectionTriggerOperator", address(pto));
        vm.serializeAddress(json, "keeper", pto.keeper());
        string memory out = vm.serializeAddress(json, "owner", pto.owner());
        vm.writeJson(out, "./deployments/mainnet.json");
    }
}
