// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Script} from "forge-std/Script.sol";
import {console} from "forge-std/console.sol";
import {MorphoProtectionTriggerOperator} from "../src/MorphoProtectionTriggerOperator.sol";

/// @notice Deploys MorphoProtectionTriggerOperator wired to the Twyne deployment on Robinhood Chain
///         (chainId 4663, Arbitrum Orbit L2). Addresses from
///         tech-notes/robinhood-launch-addresses/RobinhoodDeployment_Jul11_2026/
///         (TwyneCoreAddresses.json + TwyneMorphoAddresses.json + CoreAddresses.json).
/// @dev    Usage (never write the key to disk; inject via 1Password):
///         op run -- forge script script/DeployRobinhood.s.sol --rpc-url $ROBINHOOD_RPC_URL --broadcast
///         Env: DEPLOYER_PRIVATE_KEY (op://...), KEEPER_ADDRESS (may equal deployer)
contract DeployRobinhood is Script {
    uint constant ROBINHOOD_CHAIN_ID = 4663;

    address constant EVC = 0xef39D6493884C4C84D38a4bFF879Ce16CEdE702a;
    address constant MORPHO_TELEPORT = 0x87E63679072A8890aab08E825FdA482D4Ceb79F3;
    address constant FACTORY = 0x55d631c04077D791020e0416D7A27509a43E33Ef;
    address constant MORPHO = 0x9D53d5E3bd5E8d4Cbfa6DB1ca238AEA02E651010;

    function run() external {
        require(block.chainid == ROBINHOOD_CHAIN_ID, "wrong chain: expected Robinhood (4663)");

        uint deployerKey = vm.envUint("DEPLOYER_PRIVATE_KEY");
        address keeper = vm.envAddress("KEEPER_ADDRESS");
        address deployer = vm.addr(deployerKey);

        vm.startBroadcast(deployerKey);
        MorphoProtectionTriggerOperator pto =
            new MorphoProtectionTriggerOperator(EVC, MORPHO_TELEPORT, FACTORY, MORPHO);
        if (keeper != deployer) {
            pto.setKeeper(keeper);
        }
        vm.stopBroadcast();

        console.log("MorphoProtectionTriggerOperator:", address(pto));
        console.log("owner:", pto.owner());
        console.log("keeper:", pto.keeper());

        string memory json = "deployment";
        vm.serializeAddress(json, "morphoProtectionTriggerOperator", address(pto));
        vm.serializeAddress(json, "keeper", pto.keeper());
        string memory out = vm.serializeAddress(json, "owner", pto.owner());
        vm.writeJson(out, "./deployments/robinhood.json");
    }
}
