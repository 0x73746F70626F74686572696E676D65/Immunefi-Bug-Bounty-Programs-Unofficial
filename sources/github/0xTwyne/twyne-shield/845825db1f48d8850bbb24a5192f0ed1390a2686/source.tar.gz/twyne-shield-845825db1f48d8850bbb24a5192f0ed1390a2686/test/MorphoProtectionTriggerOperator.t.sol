// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {EthereumVaultConnector} from "ethereum-vault-connector/EthereumVaultConnector.sol";
import {MorphoProtectionTriggerOperator} from "../src/MorphoProtectionTriggerOperator.sol";
import {MarketParams} from "../src/interfaces/IMorphoExternal.sol";
import {MockCollateralVaultFactory} from "./mocks/Mocks.sol";
import {
    MockMorpho,
    MockMorphoCollateralVault,
    MockMorphoTeleportOperator,
    MockOracle
} from "./mocks/MorphoMocks.sol";

contract MorphoProtectionTriggerOperatorTest is Test {
    EthereumVaultConnector evc;
    MockMorpho morpho;
    MockOracle oracle;
    MockCollateralVaultFactory factory;
    MockMorphoTeleportOperator teleport;
    MorphoProtectionTriggerOperator pto;
    MockMorphoCollateralVault cv;

    address user = makeAddr("user");
    address keeper = makeAddr("keeper");

    MarketParams mp;
    bytes32 id;

    uint constant HF_GATE = 1.10e18;
    uint96 constant THRESHOLD = 1000;

    function setUp() public {
        evc = new EthereumVaultConnector();
        morpho = new MockMorpho();
        oracle = new MockOracle();
        factory = new MockCollateralVaultFactory();
        teleport = new MockMorphoTeleportOperator(address(evc));
        pto = new MorphoProtectionTriggerOperator(address(evc), address(teleport), address(factory), address(morpho));
        pto.setKeeper(keeper);

        mp = MarketParams({
            loanToken: makeAddr("loan"),
            collateralToken: makeAddr("coll"),
            oracle: address(oracle),
            irm: makeAddr("irm"),
            lltv: 0.86e18
        });
        id = keccak256(abi.encode(mp));

        cv = new MockMorphoCollateralVault(user, mp);
        factory.setIsCollateralVault(address(cv), true);

        // 1:1 oracle, empty-market share scale (1e6 shares per asset)
        oracle.setPrice(1e36);
        morpho.setTotals(100e18, 100e24);

        vm.startPrank(user);
        pto.register(address(cv), HF_GATE, THRESHOLD);
        evc.setAccountOperator(user, address(pto), true);
        evc.setAccountOperator(user, address(teleport), true);
        vm.stopPrank();
    }

    /// HF hand-check: collateral 10, price 1, lltv 0.86 -> maxBorrow 8.6; debt 8 -> HF 1.075
    function test_healthFactorMath() public {
        morpho.setPosition(id, user, 8e24, 10e18);
        uint hf = pto.previewHealthFactor(user);
        assertApproxEqRel(hf, 1.075e18, 1e12);
        assertGt(morpho.accrueCalls(), 0, "must accrue interest before reading");
    }

    function test_trigger_revertsAboveGate() public {
        morpho.setPosition(id, user, 7e24, 10e18); // HF ~1.2286
        vm.prank(keeper);
        vm.expectRevert(); // S_HealthFactorAboveGate with computed hf
        pto.triggerMigration(user);
    }

    function test_trigger_revertsNoDebt() public {
        morpho.setPosition(id, user, 0, 10e18);
        vm.prank(keeper);
        vm.expectRevert(MorphoProtectionTriggerOperator.S_NoDebt.selector);
        pto.triggerMigration(user);
    }

    function test_trigger_success() public {
        morpho.setPosition(id, user, 8e24, 10e18); // HF 1.075 < 1.10
        vm.prank(keeper);
        pto.triggerMigration(user);

        assertEq(teleport.lastUser(), user, "teleport must observe the EVC onBehalfOf account");
        assertEq(teleport.lastCollateralVault(), address(cv));
        assertEq(teleport.lastCollateralAmount(), type(uint).max);
        assertEq(teleport.lastDebtAmount(), type(uint).max);
        (,,, bool enabled) = pto.protections(user);
        assertFalse(enabled);

        vm.prank(keeper);
        vm.expectRevert(MorphoProtectionTriggerOperator.S_NotEnabled.selector);
        pto.triggerMigration(user);
    }

    function test_trigger_notKeeper() public {
        morpho.setPosition(id, user, 8e24, 10e18);
        vm.prank(user);
        vm.expectRevert(MorphoProtectionTriggerOperator.S_NotKeeper.selector);
        pto.triggerMigration(user);
    }

    function test_register_rejectsNonBorrower() public {
        vm.prank(makeAddr("rando"));
        vm.expectRevert(MorphoProtectionTriggerOperator.S_NotBorrower.selector);
        pto.register(address(cv), HF_GATE, THRESHOLD);
    }

    /// The assembly market-id must match keccak256(abi.encode(mp)) (MarketParamsLib.id semantics).
    function test_marketIdMatchesAbiEncode() public {
        // exercised implicitly: previewHealthFactor reads the position stored under keccak256(abi.encode(mp))
        morpho.setPosition(id, user, 8e24, 10e18);
        assertGt(pto.previewHealthFactor(user), 0);
    }
}
