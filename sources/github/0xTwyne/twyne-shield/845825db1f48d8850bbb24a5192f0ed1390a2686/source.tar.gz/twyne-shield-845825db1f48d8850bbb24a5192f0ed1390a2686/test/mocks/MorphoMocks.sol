// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {EVCUtil} from "ethereum-vault-connector/utils/EVCUtil.sol";
import {MarketParams} from "../../src/interfaces/IMorphoExternal.sol";

contract MockOracle {
    uint public price;

    function setPrice(uint p) external {
        price = p;
    }
}

contract MockMorpho {
    struct Pos {
        uint supplyShares;
        uint128 borrowShares;
        uint128 collateral;
    }

    mapping(bytes32 => mapping(address => Pos)) public positions;
    uint128 public totalBorrowAssets;
    uint128 public totalBorrowShares;
    uint public accrueCalls;

    function setPosition(bytes32 id, address user, uint128 borrowShares_, uint128 collateral_) external {
        positions[id][user] = Pos(0, borrowShares_, collateral_);
    }

    function setTotals(uint128 assets, uint128 shares) external {
        totalBorrowAssets = assets;
        totalBorrowShares = shares;
    }

    function position(bytes32 id, address user) external view returns (uint, uint128, uint128) {
        Pos memory p = positions[id][user];
        return (p.supplyShares, p.borrowShares, p.collateral);
    }

    function market(bytes32) external view returns (uint128, uint128, uint128, uint128, uint128, uint128) {
        return (0, 0, totalBorrowAssets, totalBorrowShares, uint128(block.timestamp), 0);
    }

    function accrueInterest(MarketParams memory) external {
        accrueCalls++;
    }
}

contract MockMorphoCollateralVault {
    address public borrower;
    MarketParams internal mp;

    constructor(address _borrower, MarketParams memory _mp) {
        borrower = _borrower;
        mp = _mp;
    }

    function marketParams() external view returns (MarketParams memory) {
        return mp;
    }
}

contract MockMorphoTeleportOperator is EVCUtil {
    address public lastUser;
    address public lastCollateralVault;
    uint public lastCollateralAmount;
    uint public lastDebtAmount;
    uint public callCount;

    constructor(address _evc) EVCUtil(_evc) {}

    function executeTeleport(address collateralVault, uint collateralAmount, uint debtAmount) external {
        lastUser = _msgSender();
        lastCollateralVault = collateralVault;
        lastCollateralAmount = collateralAmount;
        lastDebtAmount = debtAmount;
        callCount++;
    }
}
