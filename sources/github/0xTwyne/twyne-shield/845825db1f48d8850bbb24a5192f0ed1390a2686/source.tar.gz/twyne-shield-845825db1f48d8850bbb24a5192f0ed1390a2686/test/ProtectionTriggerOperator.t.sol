// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {EthereumVaultConnector} from "ethereum-vault-connector/EthereumVaultConnector.sol";
import {ProtectionTriggerOperator} from "../src/ProtectionTriggerOperator.sol";
import {MockAavePool, MockCollateralVaultFactory, MockCollateralVault, MockTeleportOperator} from "./mocks/Mocks.sol";

contract ProtectionTriggerOperatorTest is Test {
    EthereumVaultConnector evc;
    MockAavePool pool;
    MockCollateralVaultFactory factory;
    MockTeleportOperator teleport;
    ProtectionTriggerOperator pto;

    address user = makeAddr("user");
    address keeper = makeAddr("keeper");
    address rando = makeAddr("rando");
    MockCollateralVault cv;

    uint constant HF_GATE = 1.10e18;
    uint96 constant THRESHOLD = 1000;

    function setUp() public {
        evc = new EthereumVaultConnector();
        pool = new MockAavePool();
        factory = new MockCollateralVaultFactory();
        teleport = new MockTeleportOperator(address(evc));
        pto = new ProtectionTriggerOperator(address(evc), address(teleport), address(factory), address(pool));
        pto.setKeeper(keeper);

        cv = new MockCollateralVault(user);
        factory.setIsCollateralVault(address(cv), true);
    }

    // ---------- helpers ----------

    function _register() internal {
        vm.prank(user);
        pto.register(address(cv), HF_GATE, THRESHOLD);
    }

    function _grantOperators() internal {
        vm.startPrank(user);
        evc.setAccountOperator(user, address(pto), true);
        evc.setAccountOperator(user, address(teleport), true);
        vm.stopPrank();
    }

    function _protection(address u) internal view returns (ProtectionTriggerOperator.Protection memory p) {
        (p.collateralVault, p.probThresholdBps, p.hfGateWad, p.enabled) = pto.protections(u);
    }

    // ---------- constructor ----------

    function test_constructor_zeroChecks() public {
        vm.expectRevert(ProtectionTriggerOperator.S_ZeroAddress.selector);
        new ProtectionTriggerOperator(address(evc), address(0), address(factory), address(pool));
        vm.expectRevert(ProtectionTriggerOperator.S_ZeroAddress.selector);
        new ProtectionTriggerOperator(address(evc), address(teleport), address(0), address(pool));
        vm.expectRevert(ProtectionTriggerOperator.S_ZeroAddress.selector);
        new ProtectionTriggerOperator(address(evc), address(teleport), address(factory), address(0));
    }

    // ---------- register ----------

    function test_register_success() public {
        _register();
        ProtectionTriggerOperator.Protection memory p = _protection(user);
        assertEq(p.collateralVault, address(cv));
        assertEq(p.hfGateWad, HF_GATE);
        assertEq(p.probThresholdBps, THRESHOLD);
        assertTrue(p.enabled);
    }

    function test_register_viaEvcBatch() public {
        vm.prank(user);
        evc.call(address(pto), user, 0, abi.encodeCall(pto.register, (address(cv), HF_GATE, THRESHOLD)));
        assertTrue(_protection(user).enabled);
    }

    function test_register_revertsInvalidVault() public {
        vm.prank(user);
        vm.expectRevert(ProtectionTriggerOperator.S_InvalidCollateralVault.selector);
        pto.register(makeAddr("notAVault"), HF_GATE, THRESHOLD);
    }

    function test_register_revertsNotBorrower() public {
        vm.prank(rando);
        vm.expectRevert(ProtectionTriggerOperator.S_NotBorrower.selector);
        pto.register(address(cv), HF_GATE, THRESHOLD);
    }

    function test_register_revertsPolicyOutOfRange() public {
        vm.startPrank(user);
        vm.expectRevert(ProtectionTriggerOperator.S_PolicyOutOfRange.selector);
        pto.register(address(cv), 1.0e18, THRESHOLD); // gate too low
        vm.expectRevert(ProtectionTriggerOperator.S_PolicyOutOfRange.selector);
        pto.register(address(cv), 1.6e18, THRESHOLD); // gate too high
        vm.expectRevert(ProtectionTriggerOperator.S_PolicyOutOfRange.selector);
        pto.register(address(cv), HF_GATE, 99); // threshold too low
        vm.expectRevert(ProtectionTriggerOperator.S_PolicyOutOfRange.selector);
        pto.register(address(cv), HF_GATE, 5001); // threshold too high
        vm.stopPrank();
    }

    function test_register_reRegisterOverwritesAndRearms() public {
        _register();
        _grantOperators();
        pool.setHealthFactor(user, 1.05e18);
        vm.prank(keeper);
        pto.triggerMigration(user);
        assertFalse(_protection(user).enabled);

        vm.prank(user);
        pto.register(address(cv), 1.2e18, 2500);
        ProtectionTriggerOperator.Protection memory p = _protection(user);
        assertTrue(p.enabled);
        assertEq(p.hfGateWad, 1.2e18);
        assertEq(p.probThresholdBps, 2500);
    }

    // ---------- setPolicy / unregister ----------

    function test_setPolicy() public {
        vm.prank(user);
        vm.expectRevert(ProtectionTriggerOperator.S_NotRegistered.selector);
        pto.setPolicy(HF_GATE, THRESHOLD);

        _register();
        vm.prank(user);
        pto.setPolicy(1.25e18, 500);
        ProtectionTriggerOperator.Protection memory p = _protection(user);
        assertEq(p.hfGateWad, 1.25e18);
        assertEq(p.probThresholdBps, 500);
    }

    function test_unregister() public {
        vm.prank(user);
        vm.expectRevert(ProtectionTriggerOperator.S_NotRegistered.selector);
        pto.unregister();

        _register();
        vm.prank(user);
        pto.unregister();
        assertEq(_protection(user).collateralVault, address(0));
    }

    // ---------- admin ----------

    function test_admin_auth() public {
        vm.prank(rando);
        vm.expectRevert(ProtectionTriggerOperator.S_NotOwner.selector);
        pto.setKeeper(rando);

        vm.prank(rando);
        vm.expectRevert(ProtectionTriggerOperator.S_NotOwner.selector);
        pto.transferOwnership(rando);

        vm.expectRevert(ProtectionTriggerOperator.S_ZeroAddress.selector);
        pto.setKeeper(address(0));

        pto.transferOwnership(rando);
        assertEq(pto.owner(), rando);
    }

    // ---------- triggerMigration ----------

    function test_trigger_revertsNotKeeper() public {
        _register();
        vm.prank(rando);
        vm.expectRevert(ProtectionTriggerOperator.S_NotKeeper.selector);
        pto.triggerMigration(user);
    }

    function test_trigger_revertsNotRegistered() public {
        vm.prank(keeper);
        vm.expectRevert(ProtectionTriggerOperator.S_NotRegistered.selector);
        pto.triggerMigration(user);
    }

    function test_trigger_revertsHfAboveGate() public {
        _register();
        _grantOperators();

        pool.setHealthFactor(user, 1.10e18); // exactly at gate: not strictly below -> reverts
        vm.prank(keeper);
        vm.expectRevert(
            abi.encodeWithSelector(ProtectionTriggerOperator.S_HealthFactorAboveGate.selector, 1.10e18, HF_GATE)
        );
        pto.triggerMigration(user);
    }

    function test_trigger_revertsWithoutOperatorGrant() public {
        _register();
        pool.setHealthFactor(user, 1.05e18);
        // no EVC operator grant for pto -> EVC rejects the onBehalfOf call
        vm.prank(keeper);
        vm.expectRevert();
        pto.triggerMigration(user);
        // state must be unchanged: enabled flip reverted with the whole tx
        assertTrue(_protection(user).enabled);
    }

    function test_trigger_success() public {
        _register();
        _grantOperators();
        pool.setHealthFactor(user, 1.05e18);

        vm.prank(keeper);
        pto.triggerMigration(user);

        assertEq(teleport.lastUser(), user, "teleport must observe the EVC onBehalfOf account");
        assertEq(teleport.lastCollateralVault(), address(cv));
        assertEq(teleport.lastATokenAmount(), type(uint).max);
        assertEq(teleport.lastDebtAmount(), type(uint).max);
        assertFalse(_protection(user).enabled);

        // terminal: second trigger reverts
        vm.prank(keeper);
        vm.expectRevert(ProtectionTriggerOperator.S_NotEnabled.selector);
        pto.triggerMigration(user);
    }

    function test_trigger_teleportRevertBubblesAndStateUnchanged() public {
        _register();
        _grantOperators();
        pool.setHealthFactor(user, 1.05e18);
        teleport.setShouldRevert(true);

        vm.prank(keeper);
        vm.expectRevert();
        pto.triggerMigration(user);
        assertTrue(_protection(user).enabled, "failed migration must not burn the enabled flag");
    }
}
