// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {IERC20} from "openzeppelin-contracts/token/ERC20/IERC20.sol";
import {IEVC} from "ethereum-vault-connector/interfaces/IEthereumVaultConnector.sol";
import {ProtectionTriggerOperator} from "../src/ProtectionTriggerOperator.sol";
import {
    IAaveV3PoolMinimal,
    ICollateralVault,
    ICollateralVaultFactory,
    ITwyneVaultManager
} from "../src/interfaces/IExternal.sol";

interface IPoolAddressesProvider {
    function getPriceOracle() external view returns (address);
}

interface IAaveOracle {
    function getAssetPrice(address asset) external view returns (uint);
}

interface IAaveV3ATokenWrapper {
    function depositATokens(uint amount, address receiver) external returns (uint);
    function aToken() external view returns (address);
}

interface IEVaultMinimal {
    function deposit(uint assets, address receiver) external returns (uint);
    function cash() external view returns (uint);
    function asset() external view returns (address);
}

/// @notice End-to-end fork test against the LIVE mainnet Twyne deployment (addresses from
///         tech-notes/public-launch-addresses/TwyneAddresses_current_1.json).
contract ProtectionTriggerForkTest is Test {
    // Twyne (mainnet, public launch)
    address constant EVC = 0xef39D6493884C4C84D38a4bFF879Ce16CEdE702a;
    address constant TELEPORT = 0x868a21426852A775395d4b90De23B3e3E662bd78;
    address constant FACTORY = 0xa1517cCe0bE75700A8838EA1cEE0dc383cd3A332;
    address constant VAULT_MANAGER = 0x0acd3A3c8Ab6a5F7b5A594C88DFa28999dA858aC;
    address constant IV_AWSTETH = 0x75029a47f28550C93Ad5A3BbD2d9b5315204B561;
    address constant WRAPPER_AWSTETH = 0xFaBA8f777996C0C28fe9e6554D84cB30ca3e1881;
    // Aave V3 / tokens (mainnet)
    address constant AAVE_POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;
    address constant WSTETH = 0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;

    IAaveV3PoolMinimal pool = IAaveV3PoolMinimal(AAVE_POOL);
    IEVC evc = IEVC(EVC);
    ProtectionTriggerOperator pto;

    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address keeper = makeAddr("keeper");
    address aWstEth;

    uint constant HF_GATE = 1.10e18;
    uint96 constant THRESHOLD = 1000;
    uint constant ALICE_WSTETH = 10 ether;

    function setUp() public {
        vm.createSelectFork(vm.envOr("MAINNET_RPC_URL", string("https://ethereum-rpc.publicnode.com")));

        pto = new ProtectionTriggerOperator(EVC, TELEPORT, FACTORY, AAVE_POOL);
        pto.setKeeper(keeper);
        aWstEth = pool.getReserveAToken(WSTETH);

        _ensureIvCredit(bob, 10 ether);
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    /// @dev Seed the live wstETH intermediate vault with CLP credit if it is short:
    ///      wstETH -> Aave supply (aTokens) -> wrapper shares -> IV deposit.
    function _ensureIvCredit(address clp, uint wstEthAmount) internal {
        deal(WSTETH, clp, wstEthAmount);
        vm.startPrank(clp);
        IERC20(WSTETH).approve(AAVE_POOL, type(uint).max);
        pool.supply(WSTETH, wstEthAmount, clp, 0);
        IERC20(aWstEth).approve(WRAPPER_AWSTETH, type(uint).max);
        uint shares = IAaveV3ATokenWrapper(WRAPPER_AWSTETH).depositATokens(IERC20(aWstEth).balanceOf(clp), clp);
        IERC20(WRAPPER_AWSTETH).approve(IV_AWSTETH, type(uint).max);
        IEVaultMinimal(IV_AWSTETH).deposit(shares, clp);
        vm.stopPrank();
    }

    function _wethPrice() internal view returns (uint) {
        return IAaveOracle(IPoolAddressesProvider(pool.ADDRESSES_PROVIDER()).getPriceOracle()).getAssetPrice(WETH);
    }

    /// @dev Borrow WETH so that alice's Aave HF lands (approximately) at targetHfWad.
    function _borrowToHf(address user, uint targetHfWad) internal {
        (uint tc,,, uint ltBps,,) = pool.getUserAccountData(user);
        uint targetDebtBase = tc * ltBps * 1e18 / (1e4 * targetHfWad);
        (, uint currentDebtBase,,,,) = pool.getUserAccountData(user);
        require(targetDebtBase > currentDebtBase, "target below current debt");
        uint addWeth = (targetDebtBase - currentDebtBase) * 1e18 / _wethPrice();
        vm.prank(user);
        pool.borrow(WETH, addWeth, 2, 0, user);
    }

    function _setupAlicePosition(uint targetHfWad) internal {
        deal(WSTETH, alice, ALICE_WSTETH);
        vm.startPrank(alice);
        IERC20(WSTETH).approve(AAVE_POOL, type(uint).max);
        pool.supply(WSTETH, ALICE_WSTETH, alice, 0);
        vm.stopPrank();
        _borrowToHf(alice, targetHfWad);
    }

    function _optIn(uint liqLtvBps) internal returns (address cv) {
        vm.startPrank(alice);
        cv = ICollateralVaultFactory(FACTORY).createCollateralVault(1, IV_AWSTETH, AAVE_POOL, liqLtvBps, WETH);
        evc.setAccountOperator(alice, TELEPORT, true);
        evc.setAccountOperator(alice, address(pto), true);
        IERC20(aWstEth).approve(TELEPORT, type(uint).max);
        pto.register(cv, HF_GATE, THRESHOLD);
        vm.stopPrank();
    }

    function _maxTwyneLiqLtv() internal view returns (uint maxLtv) {
        maxLtv = ITwyneVaultManager(VAULT_MANAGER).maxTwyneLTVs(IV_AWSTETH);
    }

    // ---------------------------------------------------------------
    // Tests
    // ---------------------------------------------------------------

    function test_fork_e2e_gateThenTrigger() public {
        // Start safe: HF ~1.25, above the 1.10 gate.
        _setupAlicePosition(1.25e18);
        address cv = _optIn(_maxTwyneLiqLtv());

        // Keeper cannot trigger while the user is healthy — the on-chain gate holds.
        vm.prank(keeper);
        vm.expectRevert();
        pto.triggerMigration(alice);

        // Position deteriorates (user borrows more; equivalent to price moving against them).
        _borrowToHf(alice, 1.05e18);
        (,,,,, uint hfBefore) = pool.getUserAccountData(alice);
        assertLt(hfBefore, HF_GATE, "setup: HF must be below gate");

        (, uint debtBaseBefore,,,,) = pool.getUserAccountData(alice);
        uint aTokensBefore = IERC20(aWstEth).balanceOf(alice);
        assertGt(aTokensBefore, 0);

        // Keeper triggers the migration.
        vm.prank(keeper);
        pto.triggerMigration(alice);

        // Aave position is gone...
        (uint tcAfter, uint debtBaseAfter,,,,) = pool.getUserAccountData(alice);
        assertEq(debtBaseAfter, 0, "all Aave debt migrated");
        assertLt(tcAfter, debtBaseBefore / 100, "collateral moved out of user's Aave account");
        assertLt(IERC20(aWstEth).balanceOf(alice), aTokensBefore / 1000, "aTokens pulled");

        // ...and lives in the Twyne collateral vault now.
        assertGt(IERC20(WRAPPER_AWSTETH).balanceOf(cv), 0, "CV holds wrapper shares");
        assertGt(ICollateralVault(cv).maxRepay(), 0, "CV carries the migrated debt");

        // Protection is terminal.
        (,,, bool enabled) = pto.protections(alice);
        assertFalse(enabled);
        vm.prank(keeper);
        vm.expectRevert(ProtectionTriggerOperator.S_NotEnabled.selector);
        pto.triggerMigration(alice);
    }

    function test_fork_trigger_revertsAboveGate() public {
        _setupAlicePosition(1.25e18);
        _optIn(_maxTwyneLiqLtv());
        (,,,,, uint hf) = pool.getUserAccountData(alice);
        vm.prank(keeper);
        vm.expectRevert(abi.encodeWithSelector(ProtectionTriggerOperator.S_HealthFactorAboveGate.selector, hf, HF_GATE));
        pto.triggerMigration(alice);
    }

    function test_fork_register_rejectsForeignVault() public {
        _setupAlicePosition(1.25e18);
        vm.prank(alice);
        address cv = ICollateralVaultFactory(FACTORY).createCollateralVault(1, IV_AWSTETH, AAVE_POOL, _maxTwyneLiqLtv(), WETH);
        // bob cannot register alice's vault
        vm.prank(bob);
        vm.expectRevert(ProtectionTriggerOperator.S_NotBorrower.selector);
        pto.register(cv, HF_GATE, THRESHOLD);
    }
}
