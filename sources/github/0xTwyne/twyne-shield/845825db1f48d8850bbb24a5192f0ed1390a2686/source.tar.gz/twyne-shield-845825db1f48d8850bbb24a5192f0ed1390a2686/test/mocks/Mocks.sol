// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {EVCUtil} from "ethereum-vault-connector/utils/EVCUtil.sol";

contract MockAavePool {
    mapping(address user => uint hf) public healthFactors;

    function setHealthFactor(address user, uint hf) external {
        healthFactors[user] = hf;
    }

    function getUserAccountData(address user) external view returns (uint, uint, uint, uint, uint, uint) {
        return (0, 0, 0, 0, 0, healthFactors[user]);
    }
}

contract MockCollateralVaultFactory {
    mapping(address vault => bool isCV) public isCollateralVault;

    function setIsCollateralVault(address vault, bool v) external {
        isCollateralVault[vault] = v;
    }
}

contract MockCollateralVault {
    address public borrower;

    constructor(address _borrower) {
        borrower = _borrower;
    }
}

/// @dev Records the EVC-resolved caller and parameters, mimicking AaveV3TeleportOperator's authentication view.
contract MockTeleportOperator is EVCUtil {
    address public lastUser;
    address public lastCollateralVault;
    uint public lastATokenAmount;
    uint public lastDebtAmount;
    uint public callCount;
    bool public shouldRevert;

    constructor(address _evc) EVCUtil(_evc) {}

    function setShouldRevert(bool v) external {
        shouldRevert = v;
    }

    function executeTeleport(address collateralVault, uint aTokenAmount, uint debtAmount) external {
        require(!shouldRevert, "MockTeleport: forced revert");
        lastUser = _msgSender();
        lastCollateralVault = collateralVault;
        lastATokenAmount = aTokenAmount;
        lastDebtAmount = debtAmount;
        callCount++;
    }
}
