# twyne-shield

Automated liquidation protection for Aave V3 positions, powered by Twyne.

A user with an Aave V3 position (MVP scope: wstETH collateral / WETH debt, Ethereum mainnet) opts in once.
An off-chain keeper computes their liquidation probability `P(liq ≤ 30d)` from the closed-form first-passage
model (research spec RES-317). When it crosses the user's threshold, the keeper triggers an on-chain migration
of the position into a Twyne Collateral Vault with a higher liquidation LTV — before Aave can liquidate them.

## Components

| Piece | Where | Status |
|---|---|---|
| `ProtectionTriggerOperator` contract | `src/` (this repo) | done — unit + mainnet-fork e2e green |
| Opt-in dApp | `app/` (this repo) | in progress |
| Probability engine + σ calibration + keeper | `twyne-data` repo (next batch) | planned |

## Trust model

- The migration itself is Twyne's **audited, production** `AaveV3TeleportOperator`
  (`0x868a21426852A775395d4b90De23B3e3E662bd78`): flashloan → repay Aave debt → pull aTokens → deposit into
  the user's own Collateral Vault → borrow to repay the flashloan. Atomic; funds can only move into the
  user's own vault.
- `ProtectionTriggerOperator` adds a registry + keeper gate on top. Its **on-chain health-factor gate** means
  the keeper can only migrate a user whose live Aave HF is below the user's self-chosen `hfGateWad`.
  Worst-case keeper compromise = an early, HF-gated migration into the user's own vault. Never theft.
- The user can revoke unilaterally at any time: `unregister()`, or revoke either EVC operator grant, or
  revoke the aToken allowance.

## Opt-in (3 transactions)

1. `awstETH.approve(teleportOperator, max)`
2. `factory.createCollateralVault(AAVE_V3, IV_awstETH, aavePool, liqLTV, WETH)` — pick your boosted liqLTV
   (up to `VaultManager.maxTwyneLTVs(IV)`, currently 98%)
3. EVC batch: `setAccountOperator(teleportOperator, true)` + `setAccountOperator(protectionTrigger, true)`
   + `protectionTrigger.register(cv, hfGateWad, probThresholdBps)`

## Build & test

```bash
forge build
forge test --match-contract ProtectionTriggerOperatorTest          # unit (mocked pool/factory, real EVC)
MAINNET_RPC_URL=... forge test --match-contract ProtectionTriggerForkTest  # e2e vs LIVE mainnet deployment
```

The fork suite runs against the live Twyne mainnet contracts (factory `0xa1517cCe0bE75700A8838EA1cEE0dc383cd3A332`,
EVC `0xef39D6493884C4C84D38a4bFF879Ce16CEdE702a`, wstETH IV `0x75029a47f28550C93Ad5A3BbD2d9b5315204B561`) and
exercises the full migration: CV creation, operator grants, HF-gate rejection while healthy, then a real
teleport after the position deteriorates.

## Deploy

```bash
op run -- forge script script/Deploy.s.sol --rpc-url $MAINNET_RPC_URL --broadcast
# env: DEPLOYER_PRIVATE_KEY, KEEPER_ADDRESS
```

## Keeper runbook

- **Rotate keeper:** `cast send $PTO "setKeeper(address)" $NEW_KEEPER` (owner only)
- **Kill switch:** disable the keeper service (`PROTECTION_KEEPER_ENABLED=false` in twyne-data) — users keep
  full self-service access to Twyne's `/migrate` at all times
- **Manual fallback trigger:** `cast send $PTO "triggerMigration(address)" $USER` from the keeper EOA
- **Pause a single user:** the user calls `unregister()` (or `setPolicy` to adjust)

## Deployed contract notes (mainnet, verified against live bytecode)

The deployed Twyne contracts predate current dev HEAD in two places this repo depends on:
- Factory: use `createCollateralVault(uint8 vaultType, ...)` with `AAVE_V3 = 1` (no `createAaveV3CollateralVault`)
- VaultManager: use `maxTwyneLTVs(address)` / `externalLiqBuffers(address)` (no combined `liqParams`)

## Vendored libraries

`lib/openzeppelin-contracts` (contracts only) and `lib/ethereum-vault-connector` (src only) are vendored at
the exact versions twyne-contracts pins, so this repo builds standalone with no submodule fetch. `forge-std`
is the standard submodule.

## Demo on a mainnet fork

```bash
anvil --fork-url $MAINNET_RPC_URL          # terminal 1 (setsid in devcontainers)
bash scripts/seed-fork.sh                  # deploys PTO, seeds IV credit + a borrower near the gate
cd app && VITE_CHAIN_ID=31337 VITE_RPC_URL=http://127.0.0.1:8545 \
  VITE_PTO_ADDRESS=<from seed output> pnpm build && npx vite preview
```

Connect with an anvil dev account (or set `VITE_DEMO_ADDRESS=<addr>` for a read-only spectator view).
Degrade the borrower and trigger the keeper with the `cast` commands the seed script prints.

Keeper gotcha (verified on fork): send `triggerMigration` with an explicit gas limit (e.g. 3M) or an
estimate buffer — bare `eth_estimateGas` under-provisions the teleport's nested EVC checks and the tx
reverts out-of-gas. Always check `receipt.status`, not the send call's exit code.

![opt-in](docs/demo-optin.png)
![curve](docs/demo-curve.png)
![migrated](docs/demo-migrated.png)

## Robinhood Chain (4663) — Morpho variant

Robinhood Chain runs **Morpho Blue**, not Aave V3, so it gets its own trigger contract:
`MorphoProtectionTriggerOperator` — same registry/policy/keeper model, with the HF gate computed
Morpho-style on-chain (accrue interest → shares→assets round-up → collateral·price·lltv). Opt-in grant
difference: `Morpho.setAuthorization(morphoTeleportOperator, true)` replaces the aToken approval.
Addresses baked into `script/DeployRobinhood.s.sol` from
`tech-notes/robinhood-launch-addresses/RobinhoodDeployment_Jul11_2026/` and verified against the live chain.

## Robinhood frontend (app/, active target)

The app now targets the Twyne Morpho deployment on Robinhood Chain (4663): USDe/USDG market, 91.5% market
lltv, protection contract `0xc64972086Fd74DDf1718B526033EACaB3fF3Ba54`. Landing → connect → position card
(collateral/debt in native + ≈USD via the market oracle, LTV, liq LTV, P(liq ≤ 30d)) → "Migrate now"
(one-shot teleport, grant revoked in-batch) or "Enable protection" (standing grants + on-chain policy:
10% P₃₀ trigger, 1.10 HF gate, 95% vault liqLTV). Both flows are ONE off-chain EIP-712 Morpho authorization
signature + ONE EVC batch transaction: vault creation happens inside the batch, with its address predicted
via `EVC.batchSimulation` on the batch prefix (the CREATE2 salt only depends on the user's factory nonce).
Note: `Morpho.setAuthorization` cannot be EVC-batched (msg.sender would be the EVC) — hence the signature
path via `setAuthorizationWithSig`. The Morpho authorization to the teleport operator remains standing after
a one-shot migrate (same posture as the mainnet aToken allowance); the EVC operator grant is revoked in-batch.

Demo on a fork:

```bash
anvil --fork-url https://rpc.mainnet.chain.robinhood.com     # keeps chainId 4663
bash scripts/seed-fork-robinhood.sh                          # lifts IV cap, seeds CLP credit + borrower
cd app && VITE_RPC_URL=http://127.0.0.1:8545 pnpm build && npx vite preview
```

⚠️ Production blocker: the live Robinhood IV (`0x87b8081A3ace680f35125F469526Ac10f5418Ca7`) currently has
zero CLP deposits (`cash() = 0`) AND a tight supply cap — migrations revert until credit LPs deposit USDe
(a full migration reserves ~3.8% of collateral value at 95%-vs-91.5%). The fork script works around both;
mainnet-Robinhood needs real CLP liquidity before the feature goes live.

![landing](docs/rh-landing.png)
![position](docs/rh-position.png)
![migrated](docs/rh-migrated.png)
