// SPDX-License-Identifier: MIT

pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";

import {TwyneAaveLiquidator} from "./TwyneAaveLiquidator.sol";

import "forge-std/console2.sol";

interface ICVF {
    function collateralVaultBeacon(address targetVault) external view returns (address beacon);
}

contract DeployAaveLiquidator is Script {
    address collateralVaultFactory;
    address router;
    address aavePool;

    function run() public {
        if (block.chainid == 1) {
            // mainnet
            collateralVaultFactory = 0xa1517cCe0bE75700A8838EA1cEE0dc383cd3A332;
            router = 0x111111125421cA6dc452d289314280a0f8842A65; // 1inch router
            aavePool = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2; // Aave V3 Pool
        } else {
            // To add a chain: add a branch with its CollateralVaultFactory, 1inch router, and Aave V3 Pool.
            revert("chainid not supported");
        }

        require(ICVF(collateralVaultFactory).collateralVaultBeacon(aavePool) != address(0), "aavepool is valid");

        uint256 deployerPrivateKey = vm.envUint("LIQUIDATOR_PRIVATE_KEY");
        address liquidatorOwner = vm.envAddress("LIQUIDATOR_OWNER");
        require(liquidatorOwner != address(0), "zero liquidator owner");
        address deployer = vm.addr(deployerPrivateKey);
        vm.startBroadcast(deployerPrivateKey);

        //        address deployer = vm.envAddress("DEPLOYER_ADDRESS");
        //        vm.startBroadcast(deployer);

        TwyneAaveLiquidator liquidator =
            new TwyneAaveLiquidator(liquidatorOwner, collateralVaultFactory, router, aavePool);
        console2.log("Deployer address: ", deployer);
        console2.log("Liquidator owner: ", liquidatorOwner);
        console2.log("AAVE Liquidator deployed at: ", address(liquidator));
    }
}
