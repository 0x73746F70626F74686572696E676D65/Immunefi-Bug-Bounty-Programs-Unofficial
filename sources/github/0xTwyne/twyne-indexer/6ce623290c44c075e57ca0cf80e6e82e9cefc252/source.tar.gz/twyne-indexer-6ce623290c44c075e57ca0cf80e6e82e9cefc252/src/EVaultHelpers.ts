import { createPublicClient, http } from "viem";
import { base } from "viem/chains";
import EVaultABI from "../ABIs/EVault.json";
import EulerRouterABI from "../ABIs/EulerRouter.json";
import ChainlinkOracleABI from "../ABIs/ChainlinkOracle.json";
import ChainlinkAggregatorProxyABI from "../ABIs/ChainlinkAggregatorProxy.json";
import 'dotenv/config';

const RPC_URL = "https://lb.drpc.org/ogrpc?network=base&dkey=Ag7OOaPPO0GatQcBvKDUPkEDOORdDGIR75D1ivLNMzUy";

// Configure viem client with multicall support
const client = createPublicClient({
  chain: base,
  transport: http(RPC_URL),
  batch: { multicall: true },
});

// Define the shape of the vault information we'll fetch and store
export type EVaultDetails = {
  evc: string;
  asset: string;
  supplyCap: bigint;
  borrowCap: bigint;
  creator: string;
  dToken: string;
  decimals: bigint;
  feeReceiver: string;
  governorAdmin: string;
  interestAccumulator: bigint;
  interestFee: bigint;
  interestRateModel: string;
  liquidationCoolOffTime: bigint;
  maxLiquidationDiscount: bigint;
  oracle: string;
  name: string;
  symbol: string;
  unitOfAccount: string;
  aggregator: string;
};

/**
 * Fetches details about an EulerCollateralVault from the blockchain
 * Implements caching to avoid redundant RPC calls
 */
export async function getEVaultDetails(
  vaultAddress: string,
  chainId: number,
  isIntermediate: boolean
): Promise<EVaultDetails> {

  try {
    // Use multicall to batch all the function calls into a single RPC request
    const [
      evc,
      asset,
      caps,
      creator,
      dToken,
      decimals,
      feeReceiver,
      governorAdmin,
      interestAccumulator,
      interestFee,
      interestRateModel,
      liquidationCoolOffTime,
      maxLiquidationDiscount,
      oracle,
      name,
      symbol,
      unitOfAccount,
    ] = await client.multicall({
      allowFailure: false,
      contracts: [
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "EVC",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "asset",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "caps",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "creator",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "dToken",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "decimals",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "feeReceiver",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "governorAdmin",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "interestAccumulator",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "interestFee",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "interestRateModel",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "liquidationCoolOffTime",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "maxLiquidationDiscount",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "oracle",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "name",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "symbol",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EVaultABI,
          functionName: "unitOfAccount",
        },
      ],
    });

    const [supplyCap, borrowCap] = caps as [bigint, bigint];
    let aggregator = "";

    if (isIntermediate) {
      const underlyingAsset = await client.readContract({
        address: asset as `0x${string}`,
        abi: EVaultABI,
        functionName: "asset",
      });
      aggregator = await getAggregator(oracle as string, underlyingAsset as string, unitOfAccount as string);
    } else {
      aggregator = await getAggregator(oracle as string, asset as string, unitOfAccount as string);
    }

    // Prepare and cache the result
    const vaultDetails: EVaultDetails = {
      evc: evc as string,
      asset: asset as string,
      supplyCap: supplyCap as bigint,
      borrowCap: borrowCap as bigint,
      creator: creator as string,
      dToken: dToken as string,
      decimals: decimals as bigint,
      feeReceiver: feeReceiver as string,
      governorAdmin: governorAdmin as string,
      interestAccumulator: interestAccumulator as bigint,
      interestFee: interestFee as bigint,
      interestRateModel: interestRateModel as string,
      liquidationCoolOffTime: liquidationCoolOffTime as bigint,
      maxLiquidationDiscount: maxLiquidationDiscount as bigint,
      oracle: oracle as string,
      name: name as string,
      symbol: symbol as string,
      unitOfAccount: unitOfAccount as string,
      aggregator: aggregator as string,
    };

    console.log(`Fetched details for vault ${vaultAddress}: ${name} (${symbol})`);

    return vaultDetails;
  } catch (error) {
    console.error(`Error fetching details for vault ${vaultAddress}:`, error);
    throw error;
  }
} 

export async function getAggregator(oracleAddress: string, asset: string, unitOfAccount: string): Promise<string> {
  try {
    const chainlinkOracle = await client.readContract({
      address: oracleAddress as `0x${string}`,
      abi: EulerRouterABI,
      functionName: "getConfiguredOracle",
      args: [asset, unitOfAccount],
    });
    const feed = await client.readContract({
      address: chainlinkOracle as `0x${string}`,
      abi: ChainlinkOracleABI,
      functionName: "feed",
    });
    const aggregator = await client.readContract({
      address: feed as `0x${string}`,
      abi: ChainlinkAggregatorProxyABI,
      functionName: "aggregator",
    });
    return aggregator as string;
  } catch (error) {
    console.error(`Error getting aggregator for oracle ${oracleAddress}, asset ${asset}, unitOfAccount ${unitOfAccount}:`, error);
    return "0x0000000000000000000000000000000000000000";
  }
}
