/*
 * Please refer to https://docs.envio.dev for a thorough guide on all Envio indexer features
 */
import {
  CollateralVaultFactory,
  CollateralVaultFactory_T_CollateralVaultCreated,
  CollateralVaultFactory_T_FactoryPause,
  CollateralVaultFactory_T_SetBeacon,
  CollateralVaultFactory_T_SetCollateralVaultLiquidated,
  CollateralVaultFactory_T_SetVaultManager,
  VaultManager,
  VaultManager_T_AddAllowedTargetVault,
  VaultManager_T_RemoveAllowedTargetVault,
  VaultManager_T_SetCollateralVaultFactory,
  VaultManager_T_SetExternalLiqBuffer,
  VaultManager_T_SetIntermediateVault,
  VaultManager_T_SetLTV,
  VaultManager_T_SetMaxLiqLTV,
  VaultManager_T_SetOracleResolvedVault,
  VaultManager_T_SetOracleRouter,
  EulerCollateralVault,
  EulerCollateralVault_T_Borrow,
  EulerCollateralVault_T_Repay,
  EulerCollateralVault_T_Deposit,
  EulerCollateralVault_T_DepositUnderlying,
  EulerCollateralVault_T_Withdraw,
  EulerCollateralVault_T_RedeemUnderlying,
  EulerCollateralVault_T_SetTwyneLiqLTV,
  EulerCollateralVault_T_Rebalance,
  IntermediateVault,
  IntermediateVault_Borrow,
  IntermediateVault_Deposit,
  IntermediateVault_GovSetInterestFee,
  IntermediateVault_GovSetInterestRateModel,
  IntermediateVault_Repay,
  IntermediateVault_Transfer,
  IntermediateVault_Withdraw,
  ChainlinkAggregator,
  ChainlinkAggregator_AnswerUpdated,
} from "generated";
import { getVaultDetails } from "./EulerCollateralVaultHelper";
import { getEVaultDetails } from "./EVaultHelpers";

CollateralVaultFactory.T_CollateralVaultCreated.handler(async ({ event, context }) => {
  const entity: CollateralVaultFactory_T_CollateralVaultCreated = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    vault: event.params.vault,
    srcAddress: event.srcAddress,
  };

  context.CollateralVaultFactory_T_CollateralVaultCreated.set(entity);

  // Fetch on-chain state for the newly created vault
  try {
    const vaultDetails = await getVaultDetails(event.params.vault, event.chainId);
    const collateralEVaultDetails = await getEVaultDetails(vaultDetails.asset, event.chainId, false);
    const targetEVaultDetails = await getEVaultDetails(vaultDetails.targetVault, event.chainId, false);
    
    // Store the vault details in the database
    context.EulerCollateralVaultDetails.set({
      id: event.params.vault,
      evc: vaultDetails.evc,
      asset: vaultDetails.asset,
      borrower: vaultDetails.borrower,
      intermediateVault: vaultDetails.intermediateVault,
      name: vaultDetails.name,
      symbol: vaultDetails.symbol,
      targetVault: vaultDetails.targetVault,
      twyneLiqLTV: vaultDetails.twyneLiqLTV,
      version: vaultDetails.version,
      createdAt: BigInt(event.block.timestamp),
      createdAtBlock: BigInt(event.block.number),
      totalSupplied: BigInt(0),
      totalCredit: BigInt(0),
      totalBorrowed: BigInt(0),
    });

    context.EVaultDetails.set({
      id: vaultDetails.asset,
      evc: collateralEVaultDetails.evc,
      asset: collateralEVaultDetails.asset,
      supplyCap: collateralEVaultDetails.supplyCap,
      borrowCap: collateralEVaultDetails.borrowCap,
      creator: collateralEVaultDetails.creator,
      dToken: collateralEVaultDetails.dToken,
      decimals: collateralEVaultDetails.decimals,
      feeReceiver: collateralEVaultDetails.feeReceiver,
      governorAdmin: collateralEVaultDetails.governorAdmin,
      interestAccumulator: collateralEVaultDetails.interestAccumulator,
      interestFee: collateralEVaultDetails.interestFee,
      interestRateModel: collateralEVaultDetails.interestRateModel,
      liquidationCoolOffTime: collateralEVaultDetails.liquidationCoolOffTime,
      maxLiquidationDiscount: collateralEVaultDetails.maxLiquidationDiscount,
      oracle: collateralEVaultDetails.oracle,
      name: collateralEVaultDetails.name,
      symbol: collateralEVaultDetails.symbol,
      unitOfAccount: collateralEVaultDetails.unitOfAccount,
      aggregator: collateralEVaultDetails.aggregator,
    });

    context.EVaultDetails.set({
      id: vaultDetails.targetVault,
      evc: targetEVaultDetails.evc,
      asset: targetEVaultDetails.asset,
      supplyCap: targetEVaultDetails.supplyCap,
      borrowCap: targetEVaultDetails.borrowCap,
      creator: targetEVaultDetails.creator,
      dToken: targetEVaultDetails.dToken,
      decimals: targetEVaultDetails.decimals,
      feeReceiver: targetEVaultDetails.feeReceiver,
      governorAdmin: targetEVaultDetails.governorAdmin,
      interestAccumulator: targetEVaultDetails.interestAccumulator,
      interestFee: targetEVaultDetails.interestFee,
      interestRateModel: targetEVaultDetails.interestRateModel,
      liquidationCoolOffTime: targetEVaultDetails.liquidationCoolOffTime,
      maxLiquidationDiscount: targetEVaultDetails.maxLiquidationDiscount,
      oracle: targetEVaultDetails.oracle,
      name: targetEVaultDetails.name,
      symbol: targetEVaultDetails.symbol,
      unitOfAccount: targetEVaultDetails.unitOfAccount,
      aggregator: targetEVaultDetails.aggregator,
    });
    
    console.log(`Stored details for vault ${event.params.vault}: ${vaultDetails.name} (${vaultDetails.symbol})`);
  } catch (error) {
    console.error(`Failed to fetch vault details for ${event.params.vault}:`, error);
  }

});

CollateralVaultFactory.T_FactoryPause.handler(async ({ event, context }) => {
  const entity: CollateralVaultFactory_T_FactoryPause = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    pause: event.params.pause,
    srcAddress: event.srcAddress,
  };

  context.CollateralVaultFactory_T_FactoryPause.set(entity);
});

CollateralVaultFactory.T_SetBeacon.handler(async ({ event, context }) => {
  const entity: CollateralVaultFactory_T_SetBeacon = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    targetVault: event.params.targetVault,
    beacon: event.params.beacon,
    srcAddress: event.srcAddress,
  };

  context.CollateralVaultFactory_T_SetBeacon.set(entity);
});

CollateralVaultFactory.T_SetCollateralVaultLiquidated.handler(async ({ event, context }) => {
  const entity: CollateralVaultFactory_T_SetCollateralVaultLiquidated = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    collateralVault: event.params.collateralVault,
    liquidator: event.params.liquidator,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.CollateralVaultFactory_T_SetCollateralVaultLiquidated.set(entity);
});

CollateralVaultFactory.T_SetVaultManager.handler(async ({ event, context }) => {
  const entity: CollateralVaultFactory_T_SetVaultManager = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    vaultManager: event.params.vaultManager,
    srcAddress: event.srcAddress,
  };

  context.CollateralVaultFactory_T_SetVaultManager.set(entity);
});

VaultManager.T_AddAllowedTargetVault.handler(async ({ event, context }) => {
  const entity: VaultManager_T_AddAllowedTargetVault = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    intermediateVault: event.params.intermediateVault,
    targetVault: event.params.targetVault,
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_AddAllowedTargetVault.set(entity);
});

VaultManager.T_RemoveAllowedTargetVault.handler(async ({ event, context }) => {
  const entity: VaultManager_T_RemoveAllowedTargetVault = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    intermediateVault: event.params.intermediateVault,
    targetVault: event.params.targetVault,
    index: event.params.index,
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_RemoveAllowedTargetVault.set(entity);
});

VaultManager.T_SetCollateralVaultFactory.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetCollateralVaultFactory = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    factory: event.params.factory,
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetCollateralVaultFactory.set(entity);
});

VaultManager.T_SetExternalLiqBuffer.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetExternalLiqBuffer = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    collateralAddress: event.params.collateralAddress,
    liqBuffer: event.params.liqBuffer,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetExternalLiqBuffer.set(entity);
});

VaultManager.T_SetIntermediateVault.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetIntermediateVault = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    intermediateVault: event.params.intermediateVault,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetIntermediateVault.set(entity);

  try {
    const intermediateVaultDetails = await getEVaultDetails(event.params.intermediateVault, event.chainId, true);

    context.IntermediateVaultDetails.set({
      id: event.params.intermediateVault,
      evc: intermediateVaultDetails.evc,
      asset: intermediateVaultDetails.asset,
      supplyCap: intermediateVaultDetails.supplyCap,
      borrowCap: intermediateVaultDetails.borrowCap,
      creator: intermediateVaultDetails.creator,
      dToken: intermediateVaultDetails.dToken,
      decimals: intermediateVaultDetails.decimals,
      feeReceiver: intermediateVaultDetails.feeReceiver,
      governorAdmin: intermediateVaultDetails.governorAdmin,
      interestAccumulator: intermediateVaultDetails.interestAccumulator,
      interestFee: intermediateVaultDetails.interestFee,
      interestRateModel: intermediateVaultDetails.interestRateModel,
      liquidationCoolOffTime: intermediateVaultDetails.liquidationCoolOffTime,
      maxLiquidationDiscount: intermediateVaultDetails.maxLiquidationDiscount,
      oracle: intermediateVaultDetails.oracle,
      name: intermediateVaultDetails.name,
      symbol: intermediateVaultDetails.symbol,
      unitOfAccount: intermediateVaultDetails.unitOfAccount,
      totalSupplied: BigInt(0),
      totalBorrowed: BigInt(0),
      aggregator: intermediateVaultDetails.aggregator,
    });
    
    console.log(`Stored details for vault ${event.params.intermediateVault}: ${intermediateVaultDetails.name} (${intermediateVaultDetails.symbol})`);
  } catch (error) {
    console.error(`Failed to fetch vault details for ${event.params.intermediateVault}:`, error);
  }
});

VaultManager.T_SetLTV.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetLTV = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    intermediateVault: event.params.intermediateVault,
    collateralVault: event.params.collateralVault,
    borrowLimit: event.params.borrowLimit,
    liquidationLimit: event.params.liquidationLimit,
    rampDuration: event.params.rampDuration,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetLTV.set(entity);
});

VaultManager.T_SetMaxLiqLTV.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetMaxLiqLTV = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    collateralAddress: event.params.collateralAddress,
    ltv: event.params.ltv,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetMaxLiqLTV.set(entity);
});

VaultManager.T_SetOracleResolvedVault.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetOracleResolvedVault = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    collateralAddress: event.params.collateralAddress,
    allow: event.params.allow,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetOracleResolvedVault.set(entity);
});

VaultManager.T_SetOracleRouter.handler(async ({ event, context }) => {
  const entity: VaultManager_T_SetOracleRouter = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    newOracleRouter: event.params.newOracleRouter,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.VaultManager_T_SetOracleRouter.set(entity);
});

EulerCollateralVault.T_Borrow.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_Borrow = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    targetAmount: event.params.targetAmount,
    receiver: event.params.receiver,
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_Borrow.set(entity);

  let vault = await context.EulerCollateralVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalBorrowed: (vault?.totalBorrowed ?? 0n) + event.params.targetAmount,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

EulerCollateralVault.T_Repay.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_Repay = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    repayAmount: event.params.repayAmount,
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_Repay.set(entity);

  let vault = await context.EulerCollateralVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalBorrowed: (vault?.totalBorrowed ?? 0n) - event.params.repayAmount,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

EulerCollateralVault.T_Deposit.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_Deposit = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    amount: event.params.amount,
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_Deposit.set(entity);

  let vault = await context.EulerCollateralVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalSupplied: (vault?.totalSupplied ?? 0n) + event.params.amount,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

EulerCollateralVault.T_DepositUnderlying.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_DepositUnderlying = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    amount: event.params.amount,
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_DepositUnderlying.set(entity);

  // TODO: Make sure this doesn't require addiitonal conversion to assets
  let vault = await context.EulerCollateralVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalSupplied: (vault?.totalSupplied ?? 0n) + event.params.amount,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

EulerCollateralVault.T_Withdraw.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_Withdraw = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    amount: event.params.amount,
    receiver: event.params.receiver,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_Withdraw.set(entity);

  let vault = await context.EulerCollateralVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalSupplied: (vault?.totalSupplied ?? 0n) - event.params.amount,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

EulerCollateralVault.T_RedeemUnderlying.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_RedeemUnderlying = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    amount: event.params.amount,
    receiver: event.params.receiver,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_RedeemUnderlying.set(entity);

  let vault = await context.EulerCollateralVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalSupplied: (vault?.totalSupplied ?? 0n) - event.params.amount,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

EulerCollateralVault.T_SetTwyneLiqLTV.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_SetTwyneLiqLTV = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    ltv: event.params.ltv,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_SetTwyneLiqLTV.set(entity);
});

EulerCollateralVault.T_Rebalance.handler(async ({ event, context }) => {
  const entity: EulerCollateralVault_T_Rebalance = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };

  context.EulerCollateralVault_T_Rebalance.set(entity);
});

CollateralVaultFactory.T_CollateralVaultCreated.contractRegister(async ({ event, context }) => {
  context.addEulerCollateralVault(event.params.vault);
}); 

VaultManager.T_SetIntermediateVault.contractRegister(async ({ event, context }) => {
  context.addIntermediateVault(event.params.intermediateVault);
});

IntermediateVault.Borrow.handler(async ({ event, context }) => {
  const entity: IntermediateVault_Borrow = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    account: event.params.account,
    assets: event.params.assets,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_Borrow.set(entity);

  let vault = await context.IntermediateVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalBorrowed: (vault?.totalBorrowed ?? 0n) + event.params.assets,
    };
    context.IntermediateVaultDetails.set(updatedVault);
  }

  let collateralVault = await context.EulerCollateralVaultDetails.get(event.params.account);
  if (collateralVault) {
    const updatedVault = {
      ...collateralVault,
      totalCredit: (collateralVault?.totalCredit ?? 0n) + event.params.assets,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
}); 

IntermediateVault.Deposit.handler(async ({ event, context }) => {
  const entity: IntermediateVault_Deposit = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    sender: event.params.sender,
    owner: event.params.owner,
    assets: event.params.assets,
    shares: event.params.shares,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_Deposit.set(entity);

  let vault = await context.IntermediateVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalSupplied: (vault?.totalSupplied ?? 0n) + event.params.assets,
    };
    context.IntermediateVaultDetails.set(updatedVault);
  }
});

IntermediateVault.GovSetInterestFee.handler(async ({ event, context }) => {
  const entity: IntermediateVault_GovSetInterestFee = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    newFee: event.params.newFee,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_GovSetInterestFee.set(entity);
});

IntermediateVault.GovSetInterestRateModel.handler(async ({ event, context }) => {
  const entity: IntermediateVault_GovSetInterestRateModel = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    newInterestRateModel: event.params.newInterestRateModel,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_GovSetInterestRateModel.set(entity);
});

IntermediateVault.Repay.handler(async ({ event, context }) => {
  const entity: IntermediateVault_Repay = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    account: event.params.account,
    assets: event.params.assets,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_Repay.set(entity);

  let vault = await context.IntermediateVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalBorrowed: (vault?.totalBorrowed ?? 0n) - event.params.assets,
    };
    context.IntermediateVaultDetails.set(updatedVault);
  }

  let collateralVault = await context.EulerCollateralVaultDetails.get(event.params.account);
  if (collateralVault) {
    const updatedVault = {
      ...collateralVault,
      totalCredit: (collateralVault?.totalCredit ?? 0n) - event.params.assets,
    };
    context.EulerCollateralVaultDetails.set(updatedVault);
  }
});

IntermediateVault.Transfer.handler(async ({ event, context }) => {
  const entity: IntermediateVault_Transfer = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    from: event.params.from,
    to: event.params.to,
    value: event.params.value,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_Transfer.set(entity);
});

IntermediateVault.Withdraw.handler(async ({ event, context }) => {
  const entity: IntermediateVault_Withdraw = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    sender: event.params.sender,
    receiver: event.params.receiver,
    owner: event.params.owner,
    assets: event.params.assets,
    shares: event.params.shares,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    srcAddress: event.srcAddress,
  };
  context.IntermediateVault_Withdraw.set(entity);

  let vault = await context.IntermediateVaultDetails.get(event.srcAddress);
  if (vault) {
    const updatedVault = {
      ...vault,
      totalSupplied: (vault?.totalSupplied ?? 0n) - event.params.assets,
    };
    context.IntermediateVaultDetails.set(updatedVault);
  }
});

ChainlinkAggregator.AnswerUpdated.handler(async ({ event, context }) => {
  const entity: ChainlinkAggregator_AnswerUpdated = {
    id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
    blockNumber: BigInt(event.block.number),
    blockTimestamp: BigInt(event.block.timestamp),
    current: event.params.current,
    roundId: event.params.roundId,
    updatedAt: event.params.updatedAt,
    srcAddress: event.srcAddress,
  };
  context.ChainlinkAggregator_AnswerUpdated.set(entity);
});

