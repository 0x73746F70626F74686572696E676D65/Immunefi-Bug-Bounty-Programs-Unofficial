import { createPublicClient, http } from "viem";
import { base } from "viem/chains";
import EulerCollateralVaultABI from "../ABIs/EulerCollateralVault.json";
import 'dotenv/config';

const RPC_URL = "https://lb.drpc.org/ogrpc?network=base&dkey=Ag7OOaPPO0GatQcBvKDUPkEDOORdDGIR75D1ivLNMzUy";

// Configure viem client with multicall support
const client = createPublicClient({
  chain: base,
  transport: http(RPC_URL),
  batch: { multicall: true },
});

// Define the shape of the vault information we'll fetch and store
export type EulerCollateralVaultDetails = {
  evc: string;
  asset: string;
  borrower: string;
  intermediateVault: string;
  name: string;
  symbol: string;
  targetVault: string;
  twyneLiqLTV: bigint;
  version: bigint;
};

/**
 * Fetches details about an EulerCollateralVault from the blockchain
 * Implements caching to avoid redundant RPC calls
 */
export async function getVaultDetails(
  vaultAddress: string,
  chainId: number
): Promise<EulerCollateralVaultDetails> {

  try {
    // Use multicall to batch all the function calls into a single RPC request
    const [
      evc,
      asset,
      borrower,
      intermediateVault,
      name,
      symbol,
      targetVault,
      twyneLiqLTV,
      version
    ] = await client.multicall({
      allowFailure: false,
      contracts: [
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "EVC",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "asset",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "borrower",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "intermediateVault",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "name",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "symbol",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "targetVault",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "twyneLiqLTV",
        },
        {
          address: vaultAddress as `0x${string}`,
          abi: EulerCollateralVaultABI,
          functionName: "version",
        },
      ],
    });

    // Prepare and cache the result
    const vaultDetails: EulerCollateralVaultDetails = {
      evc: evc as string,
      asset: asset as string,
      borrower: borrower as string,
      intermediateVault: intermediateVault as string,
      name: name as string,
      symbol: symbol as string,
      targetVault: targetVault as string,
      twyneLiqLTV: twyneLiqLTV as bigint,
      version: version as bigint,
    };

    console.log(`Fetched details for vault ${vaultAddress}: ${name} (${symbol})`);

    return vaultDetails;
  } catch (error) {
    console.error(`Error fetching details for vault ${vaultAddress}:`, error);
    throw error;
  }
} 