import assert from "assert";
import { 
  TestHelpers,
  CollateralVaultFactory_T_CollateralVaultCreated
} from "generated";
const { MockDb, CollateralVaultFactory } = TestHelpers;

describe("CollateralVaultFactory contract T_CollateralVaultCreated event tests", () => {
  // Create mock db
  const mockDb = MockDb.createMockDb();

  // Creating mock for CollateralVaultFactory contract T_CollateralVaultCreated event
  const event = CollateralVaultFactory.T_CollateralVaultCreated.createMockEvent({/* It mocks event fields with default values. You can overwrite them if you need */});

  it("CollateralVaultFactory_T_CollateralVaultCreated is created correctly", async () => {
    // Processing the event
    const mockDbUpdated = await CollateralVaultFactory.T_CollateralVaultCreated.processEvent({
      event,
      mockDb,
    });

    // Getting the actual entity from the mock database
    let actualCollateralVaultFactoryT_CollateralVaultCreated = mockDbUpdated.entities.CollateralVaultFactory_T_CollateralVaultCreated.get(
      `${event.chainId}_${event.block.number}_${event.logIndex}`
    );

    // Creating the expected entity
    const expectedCollateralVaultFactoryT_CollateralVaultCreated: CollateralVaultFactory_T_CollateralVaultCreated = {
      id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
      vault: event.params.vault,
    };
    // Asserting that the entity in the mock database is the same as the expected entity
    assert.deepEqual(actualCollateralVaultFactoryT_CollateralVaultCreated, expectedCollateralVaultFactoryT_CollateralVaultCreated, "Actual CollateralVaultFactoryT_CollateralVaultCreated should be the same as the expectedCollateralVaultFactoryT_CollateralVaultCreated");
  });
});
