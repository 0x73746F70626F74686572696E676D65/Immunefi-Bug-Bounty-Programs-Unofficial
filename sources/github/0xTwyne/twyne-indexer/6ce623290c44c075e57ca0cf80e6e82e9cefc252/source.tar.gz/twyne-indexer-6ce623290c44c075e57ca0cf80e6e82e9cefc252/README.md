# Twyne Indexer

This indexer tracks EulerCollateralVault contracts created by the CollateralVaultFactory and fetches on-chain state data for each vault.

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Create a `.env` file with your RPC URL:
   ```
   RPC_URL=https://eth-mainnet.alchemyapi.io/v2/your-api-key
   ```

3. Generate the indexer code:
   ```
   npx envio codegen
   ```

4. Build the indexer:
   ```
   npx envio build
   ```

5. Start the indexer:
   ```
   npx envio dev
   ```

## Features

- Tracks all EulerCollateralVault contracts created by the CollateralVaultFactory
- Fetches and stores on-chain state for each vault including:
  - EVC address
  - Asset address
  - Borrower address
  - Intermediate vault address
  - Name and symbol
  - Target vault address
  - TwyneLiqLTV value
  - Version

## Implementation Notes

The indexer uses:
- Multicall batching for efficient RPC usage
- Caching to prevent redundant RPC calls
- Error handling for robust operation

## Query Examples

Fetch all vault details:
```graphql
query {
  eulerVaultDetails {
    id
    name
    symbol
    asset
    borrower
    targetVault
    intermediateVault
    twyneLiqLTV
    createdAt
  }
}
``` 