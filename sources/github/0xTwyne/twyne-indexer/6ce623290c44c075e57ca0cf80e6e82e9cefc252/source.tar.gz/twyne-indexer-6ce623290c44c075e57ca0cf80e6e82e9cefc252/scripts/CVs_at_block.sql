-- SQL query to get all Collateral Vault positions at a specific block number
-- Usage: Replace :target_block_number with the desired block number

WITH 
-- Get all vaults created up to the target block
vaults_at_block AS (
    SELECT 
        cvc.vault AS vault_address,
        cvd.asset,
        cvd.borrower,
        cvd."intermediateVault",
        cvd.name,
        cvd.symbol,
        cvd."targetVault",
        cvd."twyneLiqLTV",
        cvd."createdAtBlock"
    FROM 
        "CollateralVaultFactory_T_CollateralVaultCreated" cvc
    JOIN 
        "EulerCollateralVaultDetails" cvd ON cvc.vault = cvd.id
    WHERE 
        cvc."blockNumber" <= :target_block_number
),

-- Calculate totalSupplied up to the target block
supplies AS (
    -- Deposits
    SELECT 
        d."srcAddress" AS vault_address,
        SUM(d.amount) AS total_supplied
    FROM 
        "EulerCollateralVault_T_Deposit" d
    WHERE 
        d."blockNumber" <= :target_block_number
    GROUP BY 
        d."srcAddress"
    
    UNION ALL
    
    -- Deposit Underlying
    SELECT 
        du."srcAddress" AS vault_address,
        SUM(du.amount) AS total_supplied
    FROM 
        "EulerCollateralVault_T_DepositUnderlying" du
    WHERE 
        du."blockNumber" <= :target_block_number
    GROUP BY 
        du."srcAddress"
    
    UNION ALL
    
    -- Withdrawals (negative)
    SELECT 
        w."srcAddress" AS vault_address,
        -SUM(w.amount) AS total_supplied
    FROM 
        "EulerCollateralVault_T_Withdraw" w
    WHERE 
        w."blockNumber" <= :target_block_number
    GROUP BY 
        w."srcAddress"
    
    UNION ALL
    
    -- Redeem Underlying (negative)
    SELECT 
        ru."srcAddress" AS vault_address,
        -SUM(ru.amount) AS total_supplied
    FROM 
        "EulerCollateralVault_T_RedeemUnderlying" ru
    WHERE 
        ru."blockNumber" <= :target_block_number
    GROUP BY 
        ru."srcAddress"
),

-- Calculate totalBorrowed up to the target block
borrows AS (
    -- Borrows
    SELECT 
        b."srcAddress" AS vault_address,
        SUM(b."targetAmount") AS total_borrowed
    FROM 
        "EulerCollateralVault_T_Borrow" b
    WHERE 
        b."blockNumber" <= :target_block_number
    GROUP BY 
        b."srcAddress"
    
    UNION ALL
    
    -- Repays (negative)
    SELECT 
        r."srcAddress" AS vault_address,
        -SUM(r."repayAmount") AS total_borrowed
    FROM 
        "EulerCollateralVault_T_Repay" r
    WHERE 
        r."blockNumber" <= :target_block_number
    GROUP BY 
        r."srcAddress"
),

-- Calculate totalCredit up to the target block
credits AS (
    -- Intermediate Vault Borrows
    SELECT 
        ivb.account AS vault_address,
        SUM(ivb.assets) AS total_credit
    FROM 
        "IntermediateVault_Borrow" ivb
    WHERE 
        ivb."blockNumber" <= :target_block_number
    GROUP BY 
        ivb.account
    
    UNION ALL
    
    -- Intermediate Vault Repays (negative)
    SELECT 
        ivr.account AS vault_address,
        -SUM(ivr.assets) AS total_credit
    FROM 
        "IntermediateVault_Repay" ivr
    WHERE 
        ivr."blockNumber" <= :target_block_number
    GROUP BY 
        ivr.account
)

-- Final query combining all data
SELECT 
    v.vault_address,
    v.asset,
    v.borrower,
    v."intermediateVault",
    v.name,
    v.symbol,
    v."targetVault",
    v."twyneLiqLTV",
    v."createdAtBlock",
    COALESCE(SUM(s.total_supplied), 0) AS "totalSupplied",
    COALESCE(SUM(c.total_credit), 0) AS "totalCredit",
    COALESCE(SUM(b.total_borrowed), 0) AS "totalBorrowed"
FROM 
    vaults_at_block v
LEFT JOIN 
    supplies s ON v.vault_address = s.vault_address
LEFT JOIN 
    borrows b ON v.vault_address = b.vault_address
LEFT JOIN 
    credits c ON v.vault_address = c.vault_address
GROUP BY 
    v.vault_address, v.asset, v.borrower, v."intermediateVault", v.name, v.symbol, v."targetVault", v."twyneLiqLTV", v."createdAtBlock"
ORDER BY 
    v."createdAtBlock";
