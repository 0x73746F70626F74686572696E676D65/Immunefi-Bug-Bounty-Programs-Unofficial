/*
 * Copyright 2020-2021, Offchain Labs, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef data_storage_executioncursor_hpp
#define data_storage_executioncursor_hpp

#include <avm/machinestate/status.hpp>
#include <avm/machinethread.hpp>
#include <avm_values/bigint.hpp>
#include <avm_values/codepointstub.hpp>
#include <data_storage/datastorage.hpp>
#include <data_storage/storageresultfwd.hpp>
#include <data_storage/value/machine.hpp>
#include <utility>

class ExecutionCursor {
   private:
    std::atomic<bool> is_aborted{false};

   public:
    std::variant<MachineStateKeys, std::unique_ptr<Machine>> machine;

   public:
    explicit ExecutionCursor(MachineStateKeys machine_) : machine(machine_) {}

    explicit ExecutionCursor(std::unique_ptr<Machine> machine_)
        : machine(std::move(machine_)) {}

    ExecutionCursor(ExecutionCursor&& rhs) noexcept
        : machine{std::move(rhs.machine)} {}

    ~ExecutionCursor() { abort(); }

    ExecutionCursor(const ExecutionCursor& rhs)
        : machine(std::unique_ptr<Machine>(nullptr)) {
        if (std::holds_alternative<std::unique_ptr<Machine>>(rhs.machine)) {
            machine = std::make_unique<Machine>(
                *std::get<std::unique_ptr<Machine>>(rhs.machine));
        } else {
            machine = std::get<MachineStateKeys>(rhs.machine);
        }
    }

    ExecutionCursor& operator=(const ExecutionCursor& rhs) {
        if (std::holds_alternative<std::unique_ptr<Machine>>(rhs.machine)) {
            machine = std::make_unique<Machine>(
                *std::get<std::unique_ptr<Machine>>(rhs.machine));
        } else {
            machine = std::get<MachineStateKeys>(rhs.machine);
        }
        return *this;
    }

    ExecutionCursor& operator=(ExecutionCursor&& rhs) noexcept {
        machine = std::move(rhs.machine);
        return *this;
    }

    ExecutionCursor* clone();

    void abort() {
        if (std::holds_alternative<std::unique_ptr<Machine>>(machine)) {
            if (std::get<std::unique_ptr<Machine>>(machine) != nullptr) {
                std::get<std::unique_ptr<Machine>>(machine)->abort();
            }
        }
        is_aborted = true;
    }

    bool isAborted() {
        if (is_aborted) {
            // Ensure machine is properly stopped
            abort();
            return true;
        }

        if (std::holds_alternative<std::unique_ptr<Machine>>(machine) &&
            (std::get<std::unique_ptr<Machine>>(machine) != nullptr)) {
            return std::get<std::unique_ptr<Machine>>(machine)->isAborted();
        }
        return is_aborted;
    }

    [[nodiscard]] std::optional<uint256_t> machineHash() const {
        if (std::holds_alternative<std::unique_ptr<Machine>>(machine)) {
            if (std::get<std::unique_ptr<Machine>>(machine) == nullptr) {
                throw std::runtime_error("machine unique_ptr is null");
            }
            return std::get<std::unique_ptr<Machine>>(machine)->hash();
        } else {
            return std::get<MachineStateKeys>(machine).machineHash();
        }
    }

    [[nodiscard]] const MachineOutput& getOutput() const {
        if (std::holds_alternative<std::unique_ptr<Machine>>(machine)) {
            if (std::get<std::unique_ptr<Machine>>(machine) == nullptr) {
                throw std::runtime_error("machine unique_ptr is null");
            }
            return std::get<std::unique_ptr<Machine>>(machine)
                ->machine_state.output;
        } else {
            return std::get<MachineStateKeys>(machine).output;
        }
    }

    [[nodiscard]] std::optional<uint256_t> getInboxAcc() const {
        return getOutput().fully_processed_inbox.accumulator;
    }

    [[nodiscard]] uint256_t getTotalMessagesRead() const {
        return getOutput().fully_processed_inbox.count;
    }
};

#endif /* data_storage_executioncursor_hpp */
