/*
 * Copyright 2020, Offchain Labs, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "carbcore.h"

#include "utils.hpp"

#include <data_storage/arbcore.hpp>

int arbCoreStartThread(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    auto status = arb_core->startThread();
    if (!status) {
        return 0;
    }

    return 1;
}

int arbCoreMessagesStatus(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    return arb_core->messagesStatus();
}

char* arbCoreMessagesGetError(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    auto str = arb_core->messagesGetError();
    return strdup(str.c_str());
}

int arbCoreCheckError(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    return arb_core->checkError();
}

char* arbCoreGetErrorString(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    auto str = arb_core->getErrorString();
    return strdup(str.c_str());
}

int arbCoreMachineIdle(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    return arb_core->machineIdle();
}

void arbCoreSaveRocksdbCheckpoint(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    arb_core->triggerSaveFullRocksdbCheckpointToDisk();
}

void* arbCoreMachineMessagesRead(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    return returnUint256(arb_core->machineMessagesRead());
}

Uint256Result arbCoreGetDelayedMessagesToSequence(
    CArbCore* arbcore_ptr,
    const void* max_block_number) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    return returnUint256Result(arb_core->getDelayedMessagesToSequence(
        receiveUint256(max_block_number)));
}

int arbCoreDeliverMessages(CArbCore* arbcore_ptr,
                           void* previous_message_count_ptr,
                           void* previous_inbox_acc_ptr,
                           ByteSliceArray sequencer_batch_items_slice,
                           ByteSliceArray delayed_messages_slice,
                           void* reorg_message_count_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    auto previous_message_count = receiveUint256(previous_message_count_ptr);
    auto previous_inbox_acc = receiveUint256(previous_inbox_acc_ptr);
    auto sequencer_batch_items =
        receiveByteSliceArray(sequencer_batch_items_slice);
    auto delayed_messages = receiveByteSliceArray(delayed_messages_slice);
    std::optional<uint256_t> reorg_message_count;
    if (reorg_message_count_ptr != nullptr) {
        reorg_message_count = receiveUint256(reorg_message_count_ptr);
    }

    auto item_count = sequencer_batch_items.size();
    auto delayed_count = delayed_messages.size();
    try {
        auto status = arb_core->deliverMessages(
            previous_message_count, previous_inbox_acc,
            std::move(sequencer_batch_items), std::move(delayed_messages),
            reorg_message_count);
        if (!status) {
            std::cerr << "error while delivering messages, previous count: "
                      << previous_message_count
                      << ", item count: " << item_count
                      << ", delayed count: " << delayed_count << std::endl;
        }
        return status;
    } catch (const std::exception& e) {
        std::cerr << "exception while delivering messages, previous count: "
                  << previous_message_count << ", item count: " << item_count
                  << ", delayed count: " << delayed_count
                  << ", error: " << e.what() << std::endl;
        return false;
    }
}

Uint256Result arbCoreGetLogCount(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto count_result = arb_core->logInsertedCount();
        if (!count_result.status.ok()) {
            return {{}, false};
        }
        return {returnUint256(count_result.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

ByteSliceArrayResult arbCoreGetLogs(CArbCore* arbcore_ptr,
                                    const void* start_index_ptr,
                                    const void* count_ptr) {
    try {
        auto arbcore = static_cast<ArbCore*>(arbcore_ptr);
        auto value_loader = arbcore->makeValueLoader();
        ValueCache cache{1, 0};
        auto logs = arbcore->getLogs(receiveUint256(start_index_ptr),
                                     receiveUint256(count_ptr), cache);
        if (!logs.status.ok()) {
            return {{}, false};
        }

        std::vector<std::vector<unsigned char>> data;
        for (const auto& log : logs.data) {
            std::vector<unsigned char> marshalled_log;
            marshal_uint256_t(log.inbox.count, marshalled_log);
            marshal_uint256_t(log.inbox.accumulator, marshalled_log);
            marshal_value(log.val, marshalled_log, &value_loader);
            data.push_back(move(marshalled_log));
        }
        return {returnCharVectorVector(data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

Uint256Result arbCoreGetSendCount(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto count_result = arb_core->sendInsertedCount();
        if (!count_result.status.ok()) {
            return {{}, false};
        }
        return {returnUint256(count_result.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

ByteSliceArrayResult arbCoreGetSends(CArbCore* arbcore_ptr,
                                     const void* start_index_ptr,
                                     const void* count_ptr) {
    try {
        auto sends = static_cast<const ArbCore*>(arbcore_ptr)
                         ->getSends(receiveUint256(start_index_ptr),
                                    receiveUint256(count_ptr));
        if (!sends.status.ok()) {
            return {{}, false};
        }

        return {returnCharVectorVector(sends.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

Uint256Result arbCoreGetMessageCount(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto count_result = arb_core->messageEntryInsertedCount();
        if (!count_result.status.ok()) {
            return {{}, false};
        }
        return {returnUint256(count_result.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

Uint256Result arbCoreGetDelayedMessageCount(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto count_result = arb_core->delayedMessageEntryInsertedCount();
        if (!count_result.status.ok()) {
            return {{}, false};
        }
        return {returnUint256(count_result.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

Uint256Result arbCoreGetTotalDelayedMessagesSequenced(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto count_result = arb_core->totalDelayedMessagesSequenced();
        if (!count_result.status.ok()) {
            return {{}, false};
        }
        return {returnUint256(count_result.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

ByteSliceArrayResult arbCoreGetMessages(CArbCore* arbcore_ptr,
                                        const void* start_index_ptr,
                                        const void* count_ptr) {
    try {
        auto messages = static_cast<const ArbCore*>(arbcore_ptr)
                            ->getMessages(receiveUint256(start_index_ptr),
                                          receiveUint256(count_ptr));
        if (!messages.status.ok()) {
            return {{}, false};
        }

        return {returnCharVectorVector(messages.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

ByteSliceArrayResult arbCoreGetSequencerBatchItems(
    CArbCore* arbcore_ptr,
    const void* start_index_ptr) {
    try {
        auto messages =
            static_cast<const ArbCore*>(arbcore_ptr)
                ->getSequencerBatchItems(receiveUint256(start_index_ptr));
        if (!messages.status.ok()) {
            return {{}, false};
        }

        return {returnCharVectorVector(messages.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

Uint256Result arbCoreGetSequencerBlockNumberAt(CArbCore* arbcore_ptr,
                                               const void* seq_num_ptr) {
    try {
        auto res = static_cast<const ArbCore*>(arbcore_ptr)
                       ->getSequencerBlockNumberAt(receiveUint256(seq_num_ptr));
        return returnUint256Result(res);
    } catch (const std::exception& e) {
        return {nullptr, false};
    }
}

ByteSliceResult arbCoreGenInboxProof(CArbCore* arbcore_ptr,
                                     const void* seq_num_ptr,
                                     const void* batch_index_ptr,
                                     const void* batch_end_count_ptr) {
    auto arbcore = static_cast<const ArbCore*>(arbcore_ptr);
    auto seq_num = receiveUint256(seq_num_ptr);
    auto batch_end_count = receiveUint256(batch_end_count_ptr);
    auto batch_index = receiveUint256(batch_index_ptr);
    try {
        auto res =
            arbcore->genInboxProof(seq_num, batch_index, batch_end_count);
        if (!res.status.ok()) {
            std::cerr << "Failed to generate inbox proof for sequence number "
                      << seq_num << " to " << batch_end_count << ": "
                      << res.status.ToString() << std::endl;
        }
        return returnDataResult(res);
    } catch (const std::exception& e) {
        std::cerr << "Failed to generate inbox proof for sequence number "
                  << seq_num << " to " << batch_end_count << ": " << e.what()
                  << std::endl;
        return {{}, false};
    }
}

int arbCoreGetInboxAcc(CArbCore* arbcore_ptr,
                       const void* index_ptr,
                       void* ret) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto result = arb_core->getInboxAcc(receiveUint256(index_ptr));
        if (!result.status.ok()) {
            return false;
        }

        std::array<unsigned char, 32> val{};
        to_big_endian(result.data, val.begin());
        std::copy(val.begin(), val.end(), reinterpret_cast<char*>(ret));
        return true;
    } catch (const std::exception& e) {
        return false;
    }
}

int arbCoreGetDelayedInboxAcc(CArbCore* arbcore_ptr,
                              const void* index_ptr,
                              void* ret) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto result = arb_core->getDelayedInboxAcc(receiveUint256(index_ptr));
        if (!result.status.ok()) {
            return false;
        }

        std::array<unsigned char, 32> val{};
        to_big_endian(result.data, val.begin());
        std::copy(val.begin(), val.end(), reinterpret_cast<char*>(ret));
        return true;
    } catch (const std::exception& e) {
        return false;
    }
}

int arbCoreGetInboxAccPair(CArbCore* arbcore_ptr,
                           const void* index1_ptr,
                           const void* index2_ptr,
                           void* ret1,
                           void* ret2) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        auto result = arb_core->getInboxAccPair(receiveUint256(index1_ptr),
                                                receiveUint256(index2_ptr));
        if (!result.status.ok()) {
            return false;
        }

        std::array<unsigned char, 32> val1{};
        to_big_endian(result.data.first, val1.begin());
        std::copy(val1.begin(), val1.end(), reinterpret_cast<char*>(ret1));

        std::array<unsigned char, 32> val2{};
        to_big_endian(result.data.second, val2.begin());
        std::copy(val2.begin(), val2.end(), reinterpret_cast<char*>(ret2));
        return true;
    } catch (const std::exception& e) {
        return false;
    }
}

int arbCoreCountMatchingBatchAccs(CArbCore* arbcore_ptr, ByteSlice data) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    try {
        std::vector<std::pair<uint256_t, uint256_t>> input;
        auto bytes = receiveByteSlice(data);
        auto it = bytes.begin();
        for (uint64_t i = 0; i < bytes.size(); i += 64) {
            auto seq_num = extractUint256(it);
            auto acc = extractUint256(it);
            input.emplace_back(seq_num, acc);
        }

        auto result = arb_core->countMatchingBatchAccs(input);
        if (!result.status.ok()) {
            return -1;
        }
        return static_cast<int>(result.data);
    } catch (const std::exception& e) {
        return -1;
    }
}

Uint256Result arbCoreLogsCursorGetPosition(CArbCore* arbcore_ptr,
                                           const void* index_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    auto cursor_index = receiveUint256(index_ptr);
    try {
        auto count_result = arb_core->logsCursorPosition(
            intx::narrow_cast<size_t>(cursor_index));
        if (!count_result.status.ok()) {
            return {{}, false};
        }
        return {returnUint256(count_result.data), true};
    } catch (const std::exception& e) {
        return {{}, false};
    }
}

int arbCoreLogsCursorRequest(CArbCore* arbcore_ptr,
                             const void* index_ptr,
                             const void* count_ptr) {
    auto arbcore = static_cast<ArbCore*>(arbcore_ptr);
    auto cursor_index = receiveUint256(index_ptr);
    auto count = receiveUint256(count_ptr);

    try {
        auto status = arbcore->logsCursorRequest(
            intx::narrow_cast<size_t>(cursor_index), count);

        return status;
    } catch (const std::exception& e) {
        std::cerr << "Exception while requesting logs from logscursor "
                  << e.what() << std::endl;
        return false;
    }
}

IndexedDoubleByteSliceArrayResult arbCoreLogsCursorGetLogs(
    CArbCore* arbcore_ptr,
    const void* index_ptr) {
    auto arbcore = static_cast<ArbCore*>(arbcore_ptr);
    auto cursor_index = receiveUint256(index_ptr);

    auto value_loader = arbcore->makeValueLoader();

    try {
        auto result =
            arbcore->logsCursorGetLogs(intx::narrow_cast<size_t>(cursor_index));
        if (!result.status.ok()) {
            if (!result.status.IsTryAgain()) {
                std::cerr << "Error getting logs from logs cursor: "
                          << result.status.ToString() << std::endl;
            }
            return {nullptr, {}, {}, false};
        }

        if (result.data.logs.empty() && result.data.deleted_logs.empty()) {
            std::cerr << "Error: no logs from logsCursor" << std::endl;
            return {nullptr, {}, {}, false};
        }

        std::vector<std::vector<unsigned char>> marshalled_logs;
        marshalled_logs.reserve(result.data.logs.size());
        for (const auto& log : result.data.logs) {
            std::vector<unsigned char> marshalled_value;
            marshal_uint256_t(log.inbox.count, marshalled_value);
            marshal_uint256_t(log.inbox.accumulator, marshalled_value);
            marshal_value(log.val, marshalled_value, &value_loader);
            marshalled_logs.push_back(move(marshalled_value));
        }

        std::vector<std::vector<unsigned char>> marshalled_deleted_logs;
        marshalled_deleted_logs.reserve(result.data.deleted_logs.size());
        for (const auto& log : result.data.deleted_logs) {
            std::vector<unsigned char> marshalled_value;
            marshal_uint256_t(log.inbox.count, marshalled_value);
            marshal_uint256_t(log.inbox.accumulator, marshalled_value);
            marshal_value(log.val, marshalled_value, &value_loader);
            marshalled_deleted_logs.push_back(move(marshalled_value));
        }

        return {returnUint256(result.data.first_log_index),
                returnCharVectorVector(marshalled_logs),
                returnCharVectorVector(marshalled_deleted_logs), true};
    } catch (const std::exception& e) {
        std::cerr << "Exception while retrieving new logs from logscursor "
                  << e.what() << std::endl;
        return {nullptr, {}, {}, false};
    }
}

int arbCoreLogsCursorConfirmReceived(CArbCore* arbcore_ptr,
                                     const void* index_ptr) {
    auto arbcore = static_cast<ArbCore*>(arbcore_ptr);
    auto cursor_index = receiveUint256(index_ptr);

    try {
        auto status = arbcore->logsCursorConfirmReceived(
            intx::narrow_cast<size_t>(cursor_index));

        return status;
    } catch (const std::exception& e) {
        std::cerr << "Exception while confirming receipt of logscursor "
                  << e.what() << std::endl;
        return 0;
    }
}

CExecutionCursor* arbCoreGetExecutionCursor(CArbCore* arbcore_ptr,
                                            const void* total_gas_used_ptr,
                                            int allow_slow_lookups) {
    auto arbcore = static_cast<ArbCore*>(arbcore_ptr);
    auto total_gas_used = receiveUint256(total_gas_used_ptr);

    try {
        auto executionCursor =
            arbcore->getExecutionCursor(total_gas_used, allow_slow_lookups);
        if (!executionCursor.status.ok()) {
            std::cerr << "Failed to load execution cursor "
                      << executionCursor.status.ToString() << std::endl;
            return nullptr;
        }
        if (executionCursor.data == nullptr) {
            // Not in cache and database lookup disabled
            return nullptr;
        }
        return static_cast<void*>(executionCursor.data.release());
    } catch (const std::exception& e) {
        std::cerr << "Exception while loading execution cursor " << e.what()
                  << std::endl;
        return nullptr;
    }
}

int arbCoreAdvanceExecutionCursor(CArbCore* arbcore_ptr,
                                  CExecutionCursor* execution_cursor_ptr,
                                  const void* max_gas_ptr,
                                  int go_over_gas,
                                  int allow_slow_lookup) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    auto executionCursor = static_cast<ExecutionCursor*>(execution_cursor_ptr);
    auto max_gas = receiveUint256(max_gas_ptr);
    try {
        auto status = arbCore->advanceExecutionCursor(
            *executionCursor, max_gas, go_over_gas, allow_slow_lookup);
        if (!status.ok()) {
            return false;
        }

        return true;
    } catch (const std::exception& e) {
        std::cerr << "Exception while advancing execution cursor " << e.what()
                  << std::endl;
        return false;
    }
}

ByteSliceCountResult arbCoreAdvanceExecutionCursorWithTracing(
    CArbCore* arbcore_ptr,
    CExecutionCursor* execution_cursor_ptr,
    const void* max_gas_ptr,
    int go_over_gas,
    int allow_slow_lookup,
    const void* log_number_begin_ptr,
    const void* log_number_end_ptr) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    auto value_loader = arbCore->makeValueLoader();
    auto executionCursor = static_cast<ExecutionCursor*>(execution_cursor_ptr);
    auto max_gas = receiveUint256(max_gas_ptr);
    auto log_number_begin = receiveUint256(log_number_begin_ptr);
    auto log_number_end = receiveUint256(log_number_end_ptr);
    try {
        auto result = arbCore->advanceExecutionCursorWithTracing(
            *executionCursor, max_gas, go_over_gas, allow_slow_lookup,
            {log_number_begin, log_number_end});
        if (!result.status.ok()) {
            return {{}, false};
        }

        std::vector<unsigned char> debug_print_data;
        int debug_print_count = 0;
        for (const auto& debug_print : result.data) {
            marshal_uint256_t(debug_print.log_count, debug_print_data);
            marshal_value(debug_print.val, debug_print_data, &value_loader);
            debug_print_count++;
        }

        return {{returnCharVector(debug_print_data), debug_print_count}, 1};
    } catch (const std::exception& e) {
        std::cerr << "Exception while advancing execution cursor " << e.what()
                  << std::endl;
        return {{}, false};
    }
}

CMachine* arbCoreGetLastMachine(CArbCore* arbcore_ptr) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    return static_cast<void*>(arbCore->getLastMachine().release());
}

Uint256Result arbCoreGetLastMachineTotalGas(CArbCore* arbcore_ptr) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    auto gas = arbCore->getLastMachineOutput().arb_gas_used;
    return returnUint256Result({rocksdb::Status::OK(), gas});
}

Uint256Result arbCoreGetLastMachineL2BlockNumber(CArbCore* arbcore_ptr) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    auto gas = arbCore->getLastMachineOutput().l2_block_number;
    return returnUint256Result({rocksdb::Status::OK(), gas});
}

void arbCoreUpdateCheckpointPruningGas(CArbCore* arbcore_ptr,
                                       const void* gas_ptr) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    auto gas = receiveUint256(gas_ptr);
    arbCore->updateCheckpointPruningGas(gas);
}

CMachine* arbCoreTakeMachine(CArbCore* arbcore_ptr,
                             CExecutionCursor* execution_cursor_ptr) {
    auto arbCore = static_cast<ArbCore*>(arbcore_ptr);
    auto executionCursor = static_cast<ExecutionCursor*>(execution_cursor_ptr);
    return static_cast<void*>(
        arbCore->takeExecutionCursorMachine(*executionCursor).release());
}

void arbCorePrintCoreThreadBacktrace(CArbCore* arbcore_ptr) {
    auto arb_core = static_cast<ArbCore*>(arbcore_ptr);
    arb_core->printCoreThreadBacktrace();
}

CExecutionCursorResult arbCoreGetExecutionCursorAtEndOfBlock(
    CArbCore* arbcore_ptr,
    uint64_t block_number,
    int allow_slow_lookup) {
    auto arbcore = static_cast<ArbCore*>(arbcore_ptr);

    try {
        auto cursor = arbcore->getExecutionCursorAtEndOfBlock(
            block_number, allow_slow_lookup);
        if (std::holds_alternative<rocksdb::Status>(cursor)) {
            auto status = std::get<rocksdb::Status>(cursor);
            if (status.IsNotFound() && !allow_slow_lookup) {
                // Machine not found in memory cache and database lookup
                // disabled
                return {nullptr, 1};
            }

            std::cerr << "Failed to load machine for sideload  at block: "
                      << block_number << ", " << status.ToString() << std::endl;
            return {nullptr, 0};
        }

        auto newCursor = new ExecutionCursor(std::get<ExecutionCursor>(cursor));
        return {static_cast<void*>(newCursor), 0};
    } catch (const std::exception& e) {
        std::cerr << "Exception while loading machine at specific block: "
                  << e.what() << std::endl;
        return {nullptr, 0};
    }
}
