module.exports = {
  skipFiles: ["test/"],
};
