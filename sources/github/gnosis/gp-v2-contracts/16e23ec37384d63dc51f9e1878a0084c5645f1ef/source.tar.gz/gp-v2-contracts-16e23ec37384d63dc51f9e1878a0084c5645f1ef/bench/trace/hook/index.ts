export { getLastTrace } from "./register";
