import { beforeEach, afterEach, before, after } from 'mocha';
import { endSnapShot, startSnapShot } from './_utils/snapshotting';
import { deployRocketPool } from './_helpers/deployment';
import { setDefaultParameters } from './_helpers/defaults';
import { injectBNHelpers } from './_helpers/bn';
import { checkInvariants } from './_helpers/invariants';

import auctionTests from './auction/auction-tests';
import daoProtocolTests from './dao/dao-protocol-tests';
import daoProtocolTreasuryTests from './dao/dao-protocol-treasury-tests';
import daoNodeTrustedTests from './dao/dao-node-trusted-tests';
import daoSecurityTests from './dao/dao-security-tests';
import depositPoolTests from './deposit/deposit-pool-tests';
import networkBalancesTests from './network/network-balances-tests';
import networkFeesTests from './network/network-fees-tests';
import networkPricesTests from './network/network-prices-tests';
import nodeManagerTests from './node/node-manager-tests';
import nodeStakingTests from './node/node-staking-tests';
import nodeDistributorTests from './node/node-distributor-tests';
import rethTests from './token/reth-tests';
import rplTests from './token/rpl-tests';
import rewardsPoolTests from './rewards/rewards-tests';
import megapoolTests from './megapool/megapool-tests';
import networkSnapshotsTests from './network/network-snapshots-tests';
import networkVotingTests from './network/network-voting-tests';
import networkRevenuesTests from './network/network-revenues-tests';
import utilTests from './util/util-tests';
import verifierTests from './util/verifier-tests';

// Header
console.log('\n');
console.log('______           _        _    ______           _ ');
console.log('| ___ \\         | |      | |   | ___ \\         | |');
console.log('| |_/ /___   ___| | _____| |_  | |_/ /__   ___ | |');
console.log('|    // _ \\ / __| |/ / _ \\ __| |  __/ _ \\ / _ \\| |');
console.log('| |\\ \\ (_) | (__|   <  __/ |_  | | | (_) | (_) | |');
console.log('\\_| \\_\\___/ \\___|_|\\_\\___|\\__| \\_|  \\___/ \\___/|_|');

// BN helpers
injectBNHelpers();

// State snapshotting and gas usage tracking
beforeEach(startSnapShot);
afterEach(checkInvariants);
afterEach(endSnapShot);

before(async function() {
  // Deploy Rocket Pool
  await deployRocketPool();
  // Set starting parameters for all tests
  await setDefaultParameters();
});

// Run tests
auctionTests();
daoProtocolTests();
daoProtocolTreasuryTests();
daoNodeTrustedTests();
daoSecurityTests();
depositPoolTests();
megapoolTests();
networkBalancesTests();
networkFeesTests();
networkPricesTests();
networkSnapshotsTests();
networkVotingTests();
networkRevenuesTests();
nodeManagerTests();
nodeStakingTests();
nodeDistributorTests();
rethTests();
rplTests();
rewardsPoolTests();
utilTests();
verifierTests();
