import { artifacts } from '../_utils/artifacts';
import hre from 'hardhat';
import { injectBNHelpers } from './bn';

const fs = require('fs');
const pako = require('pako');
const ethers = hre.ethers;

injectBNHelpers();

function compressABI(abi) {
    return Buffer.from(pako.deflate(JSON.stringify(abi))).toString('base64');
}

function loadABI(abiFilePath) {
    return JSON.parse(fs.readFileSync(abiFilePath));
}

function formatConstructorArgs(args) {
    return JSON.stringify(args, (key, value) =>
        typeof value === 'bigint'
            ? value.toString()
            : value,
    );
}

const defaultOpts = {
    protocolVersion: '1.4',
    initialRevenueSplit: ['0.05'.ether, '0.09'.ether, '0'.ether],
    depositAddress: null,
    fixedSupplyTokenAddress: null,
    deployThirdParty: false,
    genesisBlockTimestamp: 1606824023n,
    genesisValidatorRoot: '0x4b363db94e286120d76eb905340fdd4e54bfe9f06bf33ff6cf5ad27f511bfe95',
    secondsPerSlot: 12n,
    slotsPerHistoricalRoot: 8192n,
    beaconRootsHistoryBufferLength: 8191n,
    beaconRoots: '0x000F3df6D732807Ef1319fB7B8bB8522d0Beac02',
    logging: true,
    forkSlots: [
        74240n * 32n,   // Altair
        144896n * 32n,  // Bellatrix
        194048n * 32n,  // Capella
        269568n * 32n,  // Deneb
        364032n * 32n,  // Electra
    ]
};

const contractNameMap = {
    rocketVault: 'RocketVault',
    rocketTokenRPL: 'RocketTokenRPL',
    rocketTokenRPLFixedSupply: 'RocketTokenDummyRPL',
    rocketTokenRETH: 'RocketTokenRETH',
    rocketAuctionManager: 'RocketAuctionManager',
    rocketDepositPool: 'RocketDepositPool',
    rocketMinipoolDelegate: 'RocketMinipoolDelegate',
    rocketMinipoolManager: 'RocketMinipoolManager',
    rocketMinipoolQueue: 'RocketMinipoolQueue',
    rocketMinipoolPenalty: 'RocketMinipoolPenalty',
    rocketNetworkBalances: 'RocketNetworkBalances',
    rocketNetworkFees: 'RocketNetworkFees',
    rocketNetworkPrices: 'RocketNetworkPrices',
    rocketNetworkPenalties: 'RocketNetworkPenalties',
    rocketRewardsPool: 'RocketRewardsPool',
    rocketClaimDAO: 'RocketClaimDAO',
    rocketNodeDeposit: 'RocketNodeDeposit',
    rocketNodeManager: 'RocketNodeManager',
    rocketNodeStaking: 'RocketNodeStaking',
    rocketDAOProposal: 'RocketDAOProposal',
    rocketDAONodeTrusted: 'RocketDAONodeTrusted',
    rocketDAONodeTrustedProposals: 'RocketDAONodeTrustedProposals',
    rocketDAONodeTrustedActions: 'RocketDAONodeTrustedActions',
    rocketDAONodeTrustedUpgrade: 'RocketDAONodeTrustedUpgrade',
    rocketDAONodeTrustedSettingsMembers: 'RocketDAONodeTrustedSettingsMembers',
    rocketDAONodeTrustedSettingsProposals: 'RocketDAONodeTrustedSettingsProposals',
    rocketDAONodeTrustedSettingsMinipool: 'RocketDAONodeTrustedSettingsMinipool',
    rocketDAOProtocol: 'RocketDAOProtocol',
    rocketDAOProtocolProposals: 'RocketDAOProtocolProposals',
    rocketDAOProtocolActions: 'RocketDAOProtocolActions',
    rocketDAOProtocolSettingsInflation: 'RocketDAOProtocolSettingsInflation',
    rocketDAOProtocolSettingsRewards: 'RocketDAOProtocolSettingsRewards',
    rocketDAOProtocolSettingsAuction: 'RocketDAOProtocolSettingsAuction',
    rocketDAOProtocolSettingsNode: 'RocketDAOProtocolSettingsNode',
    rocketDAOProtocolSettingsNetwork: 'RocketDAOProtocolSettingsNetwork',
    rocketDAOProtocolSettingsDeposit: 'RocketDAOProtocolSettingsDeposit',
    rocketDAOProtocolSettingsMinipool: 'RocketDAOProtocolSettingsMinipool',
    rocketMerkleDistributorMainnet: 'RocketMerkleDistributorMainnet',
    rocketDAONodeTrustedSettingsRewards: 'RocketDAONodeTrustedSettingsRewards',
    rocketSmoothingPool: 'RocketSmoothingPool',
    rocketNodeDistributorFactory: 'RocketNodeDistributorFactory',
    rocketNodeDistributorDelegate: 'RocketNodeDistributorDelegate',
    rocketMinipoolFactory: 'RocketMinipoolFactory',
    rocketMinipoolBase: 'RocketMinipoolBase',
    rocketMinipoolBondReducer: 'RocketMinipoolBondReducer',
    rocketNetworkSnapshots: 'RocketNetworkSnapshots',
    rocketNetworkSnapshotsTime: 'RocketNetworkSnapshotsTime',
    rocketNetworkVoting: 'RocketNetworkVoting',
    rocketDAOProtocolSettingsProposals: 'RocketDAOProtocolSettingsProposals',
    rocketDAOProtocolVerifier: 'RocketDAOProtocolVerifier',
    rocketDAOSecurity: 'RocketDAOSecurity',
    rocketDAOSecurityActions: 'RocketDAOSecurityActions',
    rocketDAOSecurityProposals: 'RocketDAOSecurityProposals',
    rocketDAOProtocolSettingsSecurity: 'RocketDAOProtocolSettingsSecurity',
    rocketDAOProtocolProposal: 'RocketDAOProtocolProposal',
    rocketMegapoolFactory: 'RocketMegapoolFactory',
    rocketMegapoolProxy: 'RocketMegapoolProxy',
    rocketMegapoolManager: 'RocketMegapoolManager',
    rocketMegapoolDelegate: 'RocketMegapoolDelegate',
    rocketMegapoolPenalties: 'RocketMegapoolPenalties',
    rocketNetworkRevenues: 'RocketNetworkRevenues',
    rocketDAOProtocolSettingsMegapool: 'RocketDAOProtocolSettingsMegapool',
    rocketDAOSecurityUpgrade: 'RocketDAOSecurityUpgrade',
    addressQueueStorage: 'AddressQueueStorage',
    addressSetStorage: 'AddressSetStorage',
    beaconStateVerifier: 'BeaconStateVerifier',
    linkedListStorage: 'LinkedListStorage',
};

export class RocketPoolDeployer {
    signer = null;
    rocketStorageInstance = null;
    contractPlan = {};
    deployedContracts = {};
    skippedContracts = [];
    logDepth = 0;
    buildInfos = {};
    deployBlock = null;

    stages = [];

    stageTxs = [];

    constructor(signer, opts = {}) {
        this.signer = signer;

        opts = { ...defaultOpts, ...opts };

        if (!opts.logging) {
            this.log = () => {};
        }

        // Setup default contract deployment plan
        this.contractPlan['rocketStorage'] = {
            constructorArgs: [],
            artifact: artifacts.require('RocketStorage'),
        };

        for (const contract in contractNameMap) {
            this.contractPlan[contract] = {
                constructorArgs: () => this.defaultConstructorArgs(),
                artifact: artifacts.require(contractNameMap[contract]),
            };
        }

        // Override constructor args on certain contracts
        this.contractPlan['rocketTokenRPL'].constructorArgs = () => [this.rocketStorageInstance.target, this.deployedContracts['rocketTokenRPLFixedSupply'].address];
        this.contractPlan['rocketMinipoolDelegate'].constructorArgs = [];
        this.contractPlan['rocketNodeDistributorDelegate'].constructorArgs = [];
        this.contractPlan['rocketMinipoolBase'].constructorArgs = [];
        this.contractPlan['beaconStateVerifier'].constructorArgs = () => [this.rocketStorageInstance.target, opts.slotsPerHistoricalRoot, opts.forkSlots, opts.beaconRoots, opts.genesisBlockTimestamp, opts.genesisValidatorRoot];
        this.contractPlan['rocketMegapoolDelegate'].constructorArgs = () => [this.rocketStorageInstance.target];

        // Setup deployment
        this.addStage('Deploy storage', 0, [
                async () => this.deployNetworkContract('rocketStorage'),
                async () => this.setString('protocol.version', opts.protocolVersion),
                async () => this.setUint('deploy.block', this.deployBlock),
            ],
        );

        if (opts.depositAddress === null) {
            this.addStage('Deploy deposit contract', 10, [
                    async () => this.deployDepositContract(),
                ],
            );
        } else {
            const abi = loadABI('./contracts/contract/casper/compiled/Deposit.abi');
            this.addStage('Setup deposit contract', 10, [
                    async () => this.setNetworkContractAddress('casperDeposit', opts.depositAddress),
                    async () => this.setNetworkContractAbi('casperDeposit', abi),
                ],
            );
        }

        if (opts.fixedSupplyTokenAddress === null) {
            // Has to be deployed before RPL token as it's used in constructor
            this.addStage('Deploy dummy RPL fixed supply token', 20, [
                    async () => this.deployNetworkContract('rocketTokenRPLFixedSupply'),
                ],
            );
        } else {
            this.addStage('Setup RPL fixed supply', 20, [
                    async () => this.setNetworkContractAddress('rocketTokenRPLFixedSupply', opts.fixedSupplyTokenAddress),
                    async () => this.setNetworkContractAbi('rocketTokenRPLFixedSupply', artifacts.require('rocketTokenRPLFixedSupply').abi),
                ],
            );
            // No need to deploy this anymore
            this.skippedContracts.push('rocketTokenRPLFixedSupply');
        }

        this.addStage('Deploy immutable contracts', 30, [
                async () => this.deployNetworkContract('rocketVault'),
                async () => this.deployNetworkContract('rocketTokenRETH'),
                async () => this.deployNetworkContract('rocketTokenRPL'),
            ],
        );

        this.addStage('Deploy remaining network contracts', 40, [
                async () => this.deployRemainingContracts(),
            ],
        );

        this.addStage('Add combined minipool and megapool ABI', 50, [
                async () => this.setNetworkContractAbi('rocketMinipool', compressABI(this.getMinipoolAbi())),
                async () => this.setNetworkContractAbi('rocketMegapool', compressABI(this.getMegapoolAbi())),
            ],
        );

        this.addStage('Initialise contracts', 60, [
                async () => await this.deployedContracts['rocketMegapoolFactory'].instance.initialise(),
                async () => await this.deployedContracts['rocketNetworkRevenues'].instance.initialise(...opts.initialRevenueSplit),
                async () => await this.deployedContracts['rocketMerkleDistributorMainnet'].instance.initialise(),
            ],
        );

        this.addStage('Lock storage', 100, [
                async () => this.setDeploymentStatus(),
            ],
        );

        if (opts.deployThirdParty) {
            this.addStage('Deploy third party contracts', 200, [
                    async () => this.deployThirdPartyContracts(),
                ],
            );
        }
    }

    log(string = '\n', color = 'gray') {

        let colorCodes = {
            'white': 0,
            'gray': 37,
            'red': 31,
            'blue': 34,
            'green': 32,
        };

        console.log('%s\x1b[%sm%s\x1b[0m', ''.padEnd(this.logDepth, ' '), colorCodes[color], string);
    }

    addStage(name, priority, steps) {
        this.stages.push({
            name,
            priority,
            steps,
        });
    }

    defaultConstructorArgs() {
        return [this.rocketStorageInstance.target];
    }

    getMinipoolAbi() {
        // Construct ABI for rocketMinipool
        const rocketMinipoolAbi = []
            .concat(artifacts.require('RocketMinipoolDelegate').abi)
            .concat(artifacts.require('RocketMinipoolBase').abi)
            .filter(i => i.type !== 'fallback' && i.type !== 'receive');

        rocketMinipoolAbi.push({ stateMutability: 'payable', type: 'fallback' });
        rocketMinipoolAbi.push({ stateMutability: 'payable', type: 'receive' });

        return rocketMinipoolAbi;
    }

    getMegapoolAbi() {
        // Construct ABI for rocketMegapool
        const rocketMegapoolAbi = []
            .concat(artifacts.require('RocketMegapoolDelegate').abi)
            .concat(artifacts.require('RocketMegapoolProxy').abi)
            .filter(i => i.type !== 'fallback' && i.type !== 'receive');

        rocketMegapoolAbi.push({ stateMutability: 'payable', type: 'fallback' });
        rocketMegapoolAbi.push({ stateMutability: 'payable', type: 'receive' });

        return rocketMegapoolAbi;
    }

    async setDeploymentStatus() {
        // Disable direct access to storage now
        this.log('- Locking down storage');
        const tx = await this.rocketStorageInstance.setDeployedStatus();
        this.stageTxs.push(tx);
    }

    async setString(name, value) {
        this.log('- Setting string `' + name + '` to ' + value, 'white');
        const tx = await this.rocketStorageInstance.setString(
            ethers.solidityPackedKeccak256(['string'], [name]),
            value,
        );
        this.stageTxs.push(tx);
    }

    async setUint(name, value) {
        this.log('- Setting uint `' + name + '` to ' + value, 'white');
        const tx = await this.rocketStorageInstance.setUint(
            ethers.solidityPackedKeccak256(['string'], [name]),
            value,
        );
        this.stageTxs.push(tx);
    }

    async deployDepositContract() {
        this.log('- Deploying deposit contract', 'white');
        const abi = loadABI('./contracts/contract/casper/compiled/Deposit.abi');
        const factory = new ethers.ContractFactory(abi, fs.readFileSync('./contracts/contract/casper/compiled/Deposit.bin').toString(), this.signer);
        const instance = await factory.deploy();
        const address = instance.target;

        this.log(`  - Deployed to ${address}`);

        await this.setNetworkContractAddress('casperDeposit', address);
        await this.setNetworkContractAbi('casperDeposit', abi);
    }

    async setNetworkContractAddress(name, address) {
        this.log(`- Setting address for "${name}" in storage to ${address}`);
        // Register the contract address as part of the network
        const tx1 = await this.rocketStorageInstance.setBool(
            ethers.solidityPackedKeccak256(['string', 'address'], ['contract.exists', address]),
            true,
        );
        // Register the contract's name by address
        const tx2 = await this.rocketStorageInstance.setString(
            ethers.solidityPackedKeccak256(['string', 'address'], ['contract.name', address]),
            name,
        );
        // Register the contract's address by name (rocketVault and rocketTokenRETH addresses already stored)
        const tx3 = await this.rocketStorageInstance.setAddress(
            ethers.solidityPackedKeccak256(['string', 'string'], ['contract.address', name]),
            address,
        );

        this.stageTxs.push(tx1);
        this.stageTxs.push(tx2);
        this.stageTxs.push(tx3);
    }

    async setNetworkContractAbi(name, abi) {
        let compressedAbi = abi;
        if (Array.isArray(compressedAbi)) {
            compressedAbi = compressABI(abi);
        }
        this.log(`- Setting abi for "${name}" in storage to ${compressedAbi.substr(0, 40)}...`);
        // Compress and store the ABI by name
        const tx = await this.rocketStorageInstance.setString(
            ethers.solidityPackedKeccak256(['string', 'string'], ['contract.abi', name]),
            compressedAbi,
        );

        this.stageTxs.push(tx);
    }

    async deployRemainingContracts() {
        for (const contract in this.contractPlan) {

            if (this.deployedContracts.hasOwnProperty(contract)) {
                this.log(`- Skipping already deployed ${contract}`, 'red');
                continue;
            }

            if (this.skippedContracts.includes(contract)) {
                this.log(`- Skipping ${contract}`, 'red');
                continue;
            }

            await this.deployNetworkContract(contract);
        }
    }

    async deployNetworkContract(name) {
        const plan = this.contractPlan[name];
        if (!plan) {
            throw Error(`No contract deployment plan for ${name}`);
        }

        let artifact = plan.artifact;
        let abi = artifact.abi;

        this.log(`- Deploying "${name}"`, 'white');

        let constructorArgs = typeof plan.constructorArgs === 'function' ? plan.constructorArgs() : plan.constructorArgs;

        this.logDepth += 2;

        this.log(`- Constructor args = ${formatConstructorArgs(constructorArgs)}`);

        // Deploy and log result
        const instance = await artifact.newImmediate(...constructorArgs);
        const rsTx = await instance.deploymentTransaction();
        const address = instance.target;
        this.log(`- Deployed to ${address} @ ${rsTx.hash}`);

        // Encode the constructor args
        const iface = new ethers.Interface(abi);
        const encodedConstructorArgs = iface.encodeDeploy(constructorArgs);

        // Special case for rocketStorage as it's used for all value setting
        if (name === 'rocketStorage') {
            this.rocketStorageInstance = instance;
            const receipt = await rsTx.wait();
            this.deployBlock = receipt.blockNumber;
        } else {
            this.stageTxs.push(rsTx);
        }

        await this.setNetworkContractAddress(name, address);
        await this.setNetworkContractAbi(name, abi);

        // Add to deployed contracts
        this.deployedContracts[name] = {
            artifact: artifact,
            constructorArgs: encodedConstructorArgs,
            abi: abi,
            address: address,
            instance: instance,
        };

        this.logDepth -= 2;
    }

    async bootstrapProtocolDAOSetting(contractName, settingPath, value) {
        const rocketDAOProtocol = this.deployedContracts['rocketDAOProtocol'].instance;

        if (ethers.isAddress(value)) {
            this.log(`- Bootstrap pDAO setting address \`${settingPath}\` = "${value}" on \`${contractName}\``, 'white');
            const tx = await rocketDAOProtocol.bootstrapSettingAddress(contractName, settingPath, value);
            this.stageTxs.push(tx);
        } else {
            if (typeof (value) == 'number' || typeof (value) == 'string' || typeof (value) == 'bigint') {
                this.log(`- Bootstrap pDAO setting uint \`${settingPath}\` = ${value} on \`${contractName}\``, 'white');
                const tx = await rocketDAOProtocol.bootstrapSettingUint(contractName, settingPath, value);
                this.stageTxs.push(tx);
            } else if (typeof (value) == 'boolean') {
                this.log(`- Bootstrap pDAO setting bool \`${settingPath}\` = ${value} on \`${contractName}\``, 'white');
                const tx = await rocketDAOProtocol.bootstrapSettingBool(contractName, settingPath, value);
                this.stageTxs.push(tx);
            }
        }
    }

    async bootstrapProtocolDAOClaimers(trustedNodePerc, protocolPerc, nodePerc) {
        const rocketDAOProtocol = this.deployedContracts['rocketDAOProtocol'].instance;
        this.log(`- Bootstrap pDAO setting claimers: oDAO = ${ethers.formatEther(trustedNodePerc * 100n)}%, protocol = ${ethers.formatEther(protocolPerc * 100n)}%, node = ${ethers.formatEther(nodePerc * 100n)}% `, 'white');
        const tx = await rocketDAOProtocol.bootstrapSettingClaimers(trustedNodePerc, protocolPerc, nodePerc);
        this.stageTxs.push(tx);
    }

    async deploy() {
        this.log(`Deploying RocketPool`, 'green');

        // Sort stages by priority
        this.stages.sort((a, b) => a.priority - b.priority);

        // Iterate over stages and execute steps
        for (let l = 0; l < this.stages.length; ++l) {
            const stage = this.stages[l];
            this.log(`# ${stage.name}`, 'blue');

            this.logDepth += 2;

            // Clear txs for this stage
            this.stageTxs = [];

            // Iterate over steps and execute
            for (let i = 0; i < stage.steps.length; ++i) {
                // Execute the step
                await stage.steps[i]();
            }

            // Wait for all txs to complete
            this.log(`Waiting for ${this.stageTxs.length} txs to be mined`)
            await Promise.all(this.stageTxs.map(async tx => tx.wait()))

            this.logDepth -= 2;

            this.log();
        }

        return this.deployedContracts;
    }

    async deployThirdPartyContract(artifactName, constructorArgs = []) {
        const artifact = artifacts.require(artifactName);
        // Deploy and log result
        this.log('- Deploying ' + artifact.contractName, 'white');
        const instance = await artifact.newImmediate(...constructorArgs);
        const rsTx = await instance.deploymentTransaction();
        const address = instance.target;
        this.log(`- Deployed to ${address} @ ${rsTx.hash}`);
        this.stageTxs.push(rsTx);
    }

    async deployThirdPartyContracts() {
        await this.deployThirdPartyContract('EthBalanceChecker');
        await this.deployThirdPartyContract('Multicall2');
        await this.deployThirdPartyContract('RocketSignerRegistry');
        await this.deployThirdPartyContract('UniswapOracleMock');
    }
}