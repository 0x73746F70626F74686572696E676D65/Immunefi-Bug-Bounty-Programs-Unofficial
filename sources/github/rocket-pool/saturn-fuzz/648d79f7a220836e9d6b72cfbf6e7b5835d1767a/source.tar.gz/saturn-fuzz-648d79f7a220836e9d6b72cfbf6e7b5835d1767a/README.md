## Saturn Deposit Data Root Fuzzer

This test suite runs a fuzz test against Rocket Pool's implementation of deposit data root calculation used in the
Ethereum deposit contract.

Deposit contract: https://etherscan.io/address/0x00000000219ab540356cbb839cbe05303d7705fa#code
Rocket Pool implementation: https://github.com/rocket-pool/rocketpool/blob/59f1a2933ef26e6dc88bef21be0d41aac2e0221f/contracts/contract/megapool/RocketMegapoolDelegate.sol#L801

# Run

```bash
# Compile deposit contract with same settings as deploy to Mainnet
FOUNDRY_PROFILE=0_6_x forge build

# Compile Rocket Pool contract with same settings as mainnet
forge build

# Run fuzz test
forge test --fuzz-runs 1000000
```

# Requirements

Requires nightly version of Foundry.

```bash
curl -L https://foundry.paradigm.xyz | bash
foundryup -v nightly
```