// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.30;

import {Test} from "../lib/forge-std/src/Test.sol";
import {RocketPoolDepositDataRoot} from "../src/RocketPoolDepositDataRoot.sol";

interface DepositDataRootInterface {
    function calculate(
        bytes calldata pubkey,
        bytes calldata withdrawalCredentials,
        bytes calldata signature,
        uint64 amount
    ) external returns (bytes32 ret);
}

contract DepositDataRootTest is Test {
    RocketPoolDepositDataRoot public rocketPool;
    DepositDataRootInterface public depositContract;

    function setUp() public {
        rocketPool = new RocketPoolDepositDataRoot();
        depositContract = DepositDataRootInterface(deployCode("DepositContractDepositDataRoot.sol:DepositContractDepositDataRoot"));
    }

    function testFuzz_CalculateRoot(
        bytes32 pubkeyA,
        bytes16 pubkeyB,
        bytes32 withdrawalCredentials,
        bytes32 signatureA,
        bytes32 signatureB,
        bytes32 signatureC,
        uint64 amount
    ) public {
        bytes memory pubkey = bytes.concat(pubkeyA, pubkeyB);
        bytes memory withdrawalCredentialsBytes = bytes.concat(withdrawalCredentials);
        bytes memory signature = bytes.concat(signatureA, signatureB, signatureC);

        bytes32 rocketPoolResult = rocketPool.calculate(pubkey, withdrawalCredentials, signature, amount);
        bytes32 depositContractResult = depositContract.calculate(pubkey, withdrawalCredentialsBytes, signature, amount);

        assertEq(rocketPoolResult, depositContractResult);
    }
}
