// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.30;

// @dev Extracted deposit data root calculation from RocketMegapoolDelegate at https://github.com/rocket-pool/rocketpool/blob/59f1a2933ef26e6dc88bef21be0d41aac2e0221f/contracts/contract/megapool/RocketMegapoolDelegate.sol#L801
contract RocketPoolDepositDataRoot {
    function calculate(
        bytes memory pubkey,
        bytes32 withdrawalCredentials,
        bytes memory signature,
        uint64 amount
    ) external view returns (bytes32 ret) {
        assembly {
            let result
            let temp := mload(0x40)

            // [0x00] = pubkey[0x00:0x20]
            // [0x20] = pubkey[0x20:0x30] . bytes16(0)
            mstore(0x00, mload(add(pubkey, 0x20)))
            mstore(0x20, and(mload(add(pubkey, 0x40)), 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000000000000000000000000000))

            // temp[0x00] = sha256([0x00:0x40])
            result := staticcall(gas(), 0x02, 0x00, 0x40, temp, 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // temp[0x20] = withdrawal_credentials
            mstore(add(temp, 0x20), withdrawalCredentials)

            // temp[0x00] = sha256(temp[0x00:0x40])
            result := staticcall(gas(), 0x02, temp, 0x40, temp, 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // temp[0x20] = sha256(signature[0x00:0x40])
            result := staticcall(gas(), 0x02, add(signature, 0x20), 0x40, add(temp, 0x20), 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // [0x00] = signature[0x40]
            // [0x20] = bytes32(0)
            mstore(0x00, mload(add(signature, 0x60)))
            mstore(0x20, 0)

            // [0x20] = sha256([0x00:0x40])
            result := staticcall(gas(), 0x02, 0x00, 0x40, 0x20, 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // [0x00] = temp[0x20]
            mstore(0x00, mload(add(temp, 0x20)))

            // [0x20] = sha256([0x00:0x40])
            result := staticcall(gas(), 0x02, 0x00, 0x40, 0x20, 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // [0x00] = to_little_endian(amount) . bytes24(0)
            mstore(0x00, 0)
            mstore8(0x00, shr(0x00, amount))
            mstore8(0x01, shr(0x08, amount))
            mstore8(0x02, shr(0x10, amount))
            mstore8(0x03, shr(0x18, amount))
            mstore8(0x04, shr(0x20, amount))
            mstore8(0x05, shr(0x28, amount))
            mstore8(0x06, shr(0x30, amount))
            mstore8(0x07, shr(0x38, amount))

            // [0x20] = sha256([0x00:0x40])
            result := staticcall(gas(), 0x02, 0x00, 0x40, 0x20, 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // [0x00] = temp[0x00]
            mstore(0x00, mload(temp))

            // [0x00] = sha256([0x00:0x40])
            result := staticcall(gas(), 0x02, 0x00, 0x40, 0x00, 0x20)
            if iszero(result) {
                revert(0, 0)
            }

            // Return [0x00:0x20]
            ret := mload(0x00)
        }
    }
}
