import { getAddress } from '@ethersproject/address';
import { subgraphRequest } from '../../utils';

const INFINITYPROTOCOL_SUBGRAPH_URL = {
  '56': 'https://subgrapher.snapshot.org/subgraph/arbitrum/5bvBvmThMNxZiioc5qkfE3s43YWMVsvLCgFstr1nDfiH'
};

export async function strategy(
  _space,
  network,
  _provider,
  addresses,
  options,
  snapshot
) {
  const params = {
    users: {
      __args: {
        where: {
          id_in: addresses.map(address => address.toLowerCase())
        },
        first: 1000
      },
      id: true,
      liquidityPositions: {
        __args: {
          where: {
            liquidityTokenBalance_gt: 0
          }
        },
        liquidityTokenBalance: true,
        pair: {
          id: true,
          token0: {
            id: true
          },
          reserve0: true,
          token1: {
            id: true
          },
          reserve1: true,
          totalSupply: true
        }
      }
    }
  };
  if (snapshot !== 'latest') {
    // @ts-ignore
    params.users.liquidityPositions.__args.block = { number: snapshot };
  }
  const tokenAddress = options.address.toLowerCase();
  const result = await subgraphRequest(
    options.subGraphURL
      ? options.subGraphURL
      : INFINITYPROTOCOL_SUBGRAPH_URL[network],
    params
  );
  const score = {};
  if (result && result.users) {
    result.users.forEach(u => {
      u.liquidityPositions
        .filter(
          lp =>
            lp.pair.token0.id == tokenAddress ||
            lp.pair.token1.id == tokenAddress
        )
        .forEach(lp => {
          const token0perShard = lp.pair.reserve0 / lp.pair.totalSupply;
          const token1perShard = lp.pair.reserve1 / lp.pair.totalSupply;
          let userScore =
            lp.pair.token0.id == tokenAddress
              ? token0perShard * lp.liquidityTokenBalance
              : token1perShard * lp.liquidityTokenBalance;
          if (options.scoreMultiplier) {
            userScore = userScore * options.scoreMultiplier;
          }
          const userAddress = getAddress(u.id);
          if (!score[userAddress]) score[userAddress] = 0;
          score[userAddress] = score[userAddress] + userScore;
        });
    });
  }
  return score || {};
}
