import { getAddress } from '@ethersproject/address';
import { formatUnits } from '@ethersproject/units';
import { customFetch, sha256 } from '../../utils';

export async function strategy(
  space,
  network,
  provider,
  addresses,
  options,
  snapshot
) {
  let url: string = options.url;
  const additionalParameters: string = options.additionalParameters || '';
  const type: string = options.type || 'api-get';
  const method: string = type === 'api-post' ? 'POST' : 'GET';
  let body: string | null = null;

  if (!url) throw new Error('Invalid url');

  if (type === 'ipfs') {
    url = url.replace('ipfs://', 'https://gateway.pinata.cloud/ipfs/');
  } else if (type === 'api-get') {
    url += `?network=${network}`;
    url += `&snapshot=${snapshot}`;
    url += `&addresses=${addresses.join(',')}`;
    if (additionalParameters) url += `&${additionalParameters}`;
  } else if (type === 'api-post') {
    const requestBody = {
      options,
      network,
      snapshot,
      addresses
    };
    body = JSON.stringify(requestBody);
  }
  const snapshotSecretHeader = sha256(
    `${url}${process.env.SNAPSHOT_API_STRATEGY_SALT}`
  );

  const response = await customFetch(url, {
    method,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'X-Snapshot-API-Strategy-Secret': snapshotSecretHeader
    },
    body
  });
  let responseData: any = await response.text();
  try {
    responseData = JSON.parse(responseData);
  } catch {
    throw new Error(
      `[api-v2] Errors found in API: URL: ${url}, Status: ${response.status}${response.ok}`
        ? `, Response: ${responseData.substring(0, 512)}`
        : ''
    );
  }

  if (!responseData?.score) throw new Error('Invalid response from API');

  return Object.fromEntries(
    addresses.map(address => [
      getAddress(address),
      parseFloat(
        formatUnits(
          responseData.score
            .find(s => s.address?.toLowerCase() === address.toLowerCase())
            ?.score?.toString() || '0',
          options.hasOwnProperty('decimals') ? options.decimals : 0
        )
      )
    ])
  );
}
