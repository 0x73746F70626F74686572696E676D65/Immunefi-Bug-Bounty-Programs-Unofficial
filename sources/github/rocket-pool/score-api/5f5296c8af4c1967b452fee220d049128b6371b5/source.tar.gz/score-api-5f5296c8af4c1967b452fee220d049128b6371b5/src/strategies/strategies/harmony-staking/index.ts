import { BigNumber } from '@ethersproject/bignumber';
import { StaticJsonRpcProvider } from '@ethersproject/providers';
import { formatUnits } from '@ethersproject/units';

type Params = {
  symbol: string;
  decimals: number;
};

export async function strategy(
  _space: string,
  _network: string,
  provider: StaticJsonRpcProvider,
  // adding a 0 value for addresses not in the result is not needed
  // since they are dropped anyway in utils.ts
  // https://github.com/snapshot-labs/score-api/blob/8186c5b68caa3ef3a5b3040b078c30f008b030cb/src/strategies/utils.ts#L41-L43
  _addresses: Array<string>,
  options: Params,
  snapshot: number | string
) {
  // provider = new StaticJsonRpcProvider({
  //     url: "http://127.0.0.1:9500",
  //     timeout: 25000,
  // });
  const blockTag: number | string =
    typeof snapshot === 'number' ? snapshot : 'latest';
  const response: Record<string, number> = await provider.send(
    'hmyv2_getValidatorsStakeByBlockNumber',
    [blockTag]
  );
  return Object.fromEntries(
    Object.entries(response).map(([address, balance]) => [
      address,
      parseFloat(
        formatUnits(
          BigNumber.from(`0x${balance.toString(16)}`),
          options && options.decimals ? options.decimals : 18
        )
      )
    ])
  );
}
