# Helix

This is the strategy, it returns the balances of the voters for HELIX token balances
in Helix project(pools, farms, vaults, token).

Here is an example of parameters:

```json
[
  {
    "name": "Example query Helix",
    "strategy": {
      "name": "helix",
      "params": {
        "address": "0x79DD2dad8D04F9279F94580DBEd2306A0aE118Bd",
        "masterChef": "0x15B400a434E0d94e0F1e1A0AA4a08E98A2d04128",
        "autoHelix": "0xF34316463B29B0D7A387a8443b2E17B3629e99b2",
        "vault": "0x370650b477D550E4611CCe63eE8b7eCa64F207C0",
        "helixLPs": [
          {
            "address": "0xfbfe53025c54b70b48070904f8765703D2aD749D",
            "pid": 1
          },
          {
            "address": "0x161962Aec8f3c61D865cd5d53A334780763364e6",
            "pid": 2
          }
        ],
        "symbol": "HELIX",
        "decimals": 18
      }
    },
    "network": "4",
    "addresses": [
      "0x2155BCeA4f362D5D9CE67817b826A8F31b61D0BF",
      "0xb1F7D313Ce45fe62EdE9CE4cfb46833051d38e57"
    ],
    "snapshot": 10819269
  }
]
```
