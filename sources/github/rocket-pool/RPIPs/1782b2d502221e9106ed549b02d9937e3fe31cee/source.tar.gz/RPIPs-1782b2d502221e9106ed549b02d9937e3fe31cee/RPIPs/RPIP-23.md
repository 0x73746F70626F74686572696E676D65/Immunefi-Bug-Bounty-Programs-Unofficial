---
rpip: 23
title: pDAO Charter
description: Describes what the pDAO is for and how it will operate
author: Valdorff (@Valdorff)
discussions-to: https://dao.rocketpool.net/t/odao-charter-draft-and-more/1832
status: Final
type: Meta
created: 2023-06-02
vote-to: https://vote.rocketpool.net/#/proposal/0xb9f389a5de8ae7d4356ef508fd5af7277fae88d66616fed5ef71aa9cc0f93fff
vote-date: 2023-07-17
vote-result: Passed
---

## Abstract
It would be useful to more explicitly define the Protocol DAO (pDAO) in terms of who they are, what they are
expected to do, and how they are expected to do it. This document is intended to be a foundational
definition document that will serve (a) the pDAO itself in answering "what's the right thing to do"
in a given situation, and (b) the greater community in understanding "what should we expect" and
"what shouldn't we expect" from the pDAO.

## Specification
Superseding this RPIP requires a 2/3 or greater supermajority pDAO vote

### pDAO Values
1. The pDAO SHALL serve the Rocket Pool community at large; this comprises rETH holders, Node Operators, and RPL holders
1. The pDAO SHALL be defined as Node Operators, with power based on effectively staked RPL
1. The pDAO SHALL actively govern the protocol in the interest of the Rocket Pool community at large
1. pDAO members SHOULD either
    1. Be informed and engage in public discourse about governance, or;
    1. Delegate their voting power to someone that is informed and engaged
1. The pDAO SHALL prioritize protocol safety
1. The pDAO SHOULD prioritize the health of the Ethereum network
1. The pDAO SHOULD prioritize decentralization
1. The pDAO SHOULD prioritize permissionlessness

## Copyright
Copyright and related rights waived via [CC0](https://creativecommons.org/publicdomain/zero/1.0/).
