// SPDX-License-Identifier: MIT
pragma experimental ABIEncoderV2;
pragma solidity ^0.8.20;

interface ICurvePool {
    function A_precise() external view returns (uint256);

    function get_balances() external view returns (uint256[2] memory);

    function totalSupply() external view returns (uint256);

    function add_liquidity(uint256[2] memory amounts, uint256 min_mint_amount) external returns (uint256);

    function remove_liquidity_one_coin(
        uint256 _token_amount,
        int128 i,
        uint256 min_amount
    ) external returns (uint256);

    function balances(
        int128 i
    ) external view returns (uint256);

    function fee() external view returns (uint256);

    function coins(
        uint256 i
    ) external view returns (address);

    function get_virtual_price() external view returns (uint256);

    function calc_token_amount(uint256[2] calldata amounts, bool deposit) external view returns (uint256);

    function calc_withdraw_one_coin(uint256 _token_amount, int128 i) external view returns (uint256);

    function exchange(int128 i, int128 j, uint256 dx, uint256 min_dy) external returns (uint256);

    function exchange_underlying(int128 i, int128 j, uint256 dx, uint256 min_dy) external returns (uint256);

    function transfer(address recipient, uint256 amount) external returns (bool);
}

interface ICurveZap {
    function add_liquidity(
        address _pool,
        uint256[4] memory _deposit_amounts,
        uint256 _min_mint_amount
    ) external returns (uint256);

    function calc_token_amount(
        address _pool,
        uint256[4] memory _amounts,
        bool _is_deposit
    ) external returns (uint256);
}

interface ICurvePoolR {
    function exchange(int128 i, int128 j, uint256 dx, uint256 min_dy, address receiver) external returns (uint256);

    function exchange_underlying(
        int128 i,
        int128 j,
        uint256 dx,
        uint256 min_dy,
        address receiver
    ) external returns (uint256);

    function remove_liquidity_one_coin(
        uint256 _token_amount,
        int128 i,
        uint256 min_amount,
        address receiver
    ) external returns (uint256);
}

interface ICurvePool2R {
    function add_liquidity(
        uint256[2] memory amounts,
        uint256 min_mint_amount,
        address reciever
    ) external returns (uint256);

    function remove_liquidity(
        uint256 _burn_amount,
        uint256[2] memory _min_amounts,
        address reciever
    ) external returns (uint256[2] calldata);

    function remove_liquidity_imbalance(
        uint256[2] memory _amounts,
        uint256 _max_burn_amount,
        address reciever
    ) external returns (uint256);
}

interface ICurvePool3R {
    function add_liquidity(
        uint256[3] memory amounts,
        uint256 min_mint_amount,
        address reciever
    ) external returns (uint256);

    function remove_liquidity(
        uint256 _burn_amount,
        uint256[3] memory _min_amounts,
        address reciever
    ) external returns (uint256[3] calldata);

    function remove_liquidity_imbalance(
        uint256[3] memory _amounts,
        uint256 _max_burn_amount,
        address reciever
    ) external returns (uint256);
}

interface ICurvePool4R {
    function add_liquidity(
        uint256[4] memory amounts,
        uint256 min_mint_amount,
        address reciever
    ) external returns (uint256);

    function remove_liquidity(
        uint256 _burn_amount,
        uint256[4] memory _min_amounts,
        address reciever
    ) external returns (uint256[4] calldata);

    function remove_liquidity_imbalance(
        uint256[4] memory _amounts,
        uint256 _max_burn_amount,
        address reciever
    ) external returns (uint256);
}

interface I3Curve {
    function get_virtual_price() external view returns (uint256);
}

interface ICurveFactory {
    function get_coins(
        address _pool
    ) external view returns (address[4] calldata);

    function get_underlying_coins(
        address _pool
    ) external view returns (address[8] calldata);
}

interface ICurveCryptoFactory {
    function get_coins(
        address _pool
    ) external view returns (address[8] calldata);
}

interface ICurvePoolC {
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 min_dy) external returns (uint256);
}

interface ICurvePoolNoReturn {
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 min_dy) external;

    function add_liquidity(uint256[3] memory amounts, uint256 min_mint_amount) external;

    function remove_liquidity(uint256 _burn_amount, uint256[3] memory _min_amounts) external;

    function remove_liquidity_imbalance(uint256[3] memory _amounts, uint256 _max_burn_amount) external;

    function remove_liquidity_one_coin(uint256 _token_amount, uint256 i, uint256 min_amount) external;
}

interface ICurvePoolNoReturn128 {
    function exchange(int128 i, int128 j, uint256 dx, uint256 min_dy) external;

    function remove_liquidity_one_coin(uint256 _token_amount, int128 i, uint256 min_amount) external;
}
