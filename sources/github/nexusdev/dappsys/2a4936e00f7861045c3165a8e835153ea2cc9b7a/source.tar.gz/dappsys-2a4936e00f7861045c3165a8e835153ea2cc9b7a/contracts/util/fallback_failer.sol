contract DSFallbackFailer {
    function () {
        throw;
    }
}

