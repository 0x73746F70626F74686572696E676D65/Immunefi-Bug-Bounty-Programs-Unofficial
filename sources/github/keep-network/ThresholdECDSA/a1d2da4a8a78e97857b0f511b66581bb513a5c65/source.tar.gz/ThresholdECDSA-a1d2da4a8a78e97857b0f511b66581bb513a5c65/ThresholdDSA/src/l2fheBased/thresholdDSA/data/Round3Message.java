/*
 * Copyright 2013 Matija Mazi.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package l2fheBased.thresholdDSA.data;

import paillierp.l2fhe.L2PartialDecryption;

public class Round3Message {

	public final L2PartialDecryption etaShare;

	
	public Round3Message(L2PartialDecryption etaShare) {
		this.etaShare = etaShare;

	}

}
