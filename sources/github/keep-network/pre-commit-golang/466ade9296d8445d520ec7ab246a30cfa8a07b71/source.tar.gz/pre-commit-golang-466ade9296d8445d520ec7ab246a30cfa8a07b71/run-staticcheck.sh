#!/bin/bash

if ! command -v staticcheck &> /dev/null
then
    echo "You must install staticcheck: `go install honnef.co/go/tools/cmd/staticcheck@latest`"
    exit 1
fi

gitroot=$(git rev-parse --show-toplevel)

GOPATH=${GOPATH:-}:$gitroot

cd $gitroot

pkg=$(go list)
for dir in $(echo $@|xargs -n1 dirname|sort -u); do
  staticcheck $pkg/$dir
done
