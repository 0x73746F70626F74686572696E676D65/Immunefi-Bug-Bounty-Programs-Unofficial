---
template: home-page
path: /
title: Home
hero:
  buttons:
    - text: tBTC 발행
      url: https://dapp.tbtc.network/
  subtitle: 중개인 없이 BTC를 입금하고 Defi BTC를 발급 받으세요.
  title: 비트코인을 이용해 안전하게 수익내는 방법.
  image:
    alt: tBTC 발행
    image: /img/dapp.svg
    url: https://dapp.tbtc.network/
features:
  - description: '모든 tBTC는 BTC와 1:1로 담보되어 있습니다'
    title: 담보
  - description: 중개인이 없습니다 - BTC를 이용해 tBTC를 언제든 발급 받으세요
    title: 비허가형
  - description: 검증 완료되었으며, 오픈소스입니다
    title: 안정성
  - description: BTC를 tBTC로 변환 및 복구하기 위해 3 단계 작업이 필요합니다
    title: 간단함
spotlight_1:
  body: ' tBTC는 candidate 모델을 배포할 예정이며, 공급량음 점차 늘어날 예정입니다. 추가적인 검증 과 10배의 버그 바운티를 통해 확대된 보안을 제공합니다.'
  button:
    text: 자세히 보기
    url: 'https://tbtc.network/news/2020-05-22-an-update-on-tbtc%E2%80%99s-launch/'
  label: Announcement
  title: tBTC 론칭 업데이트
spotlight_2:
  button:
    text: 개발자 툴킷
    url: /developers
  label: Developers
  title: tBTC로 여러분의 dApp에 비트코인을 추가하세요
  image:
    image: /img/spotlight-2-bg.png
    alt: Integra tBTC icon
  align: left
integrations_section:
  title: Integrations
---

