---
template: home-page
path: /
title: 首页
hero:
  buttons:
    - text: 铸造 tBTC
      url: https://dapp.tbtc.network/
  subtitle: 在无中介机构的情况下，在DeFi中存款和赎回BTC。
  title: 用比特币赚钱的安全方法
  image:
    alt: 铸造 tBTC
    image: /img/dapp.svg
    url: https://dapp.tbtc.network/
features:
  - description: tBTC和BTC完全1:1
    title: 可靠
  - description: 不需要第三方，tBTC随时可以兑换BTC
    title: 无需许可
  - description: 审计并开源
    title: 安全
  - description: 3个步就可以将BTC转换到tBTC
    title: 简便
spotlight_1:
  body: ' tBTC将转换为一个版本候选模型，并实施分级供应上限。扩展的安全措施包括进一步的审计和10倍的bug奖励 '
  button:
    text: 阅读更多
    url: 'https://tbtc.network/news/2020-05-22-an-update-on-tbtc%E2%80%99s-launch/'
  label: 公告
  title: tBTC发布的最新消息
spotlight_2:
  button:
    text: 开发人员工具包
    url: /developers
  label: 开发者
  title: 整合tBTC将比特币添加到你的dApp中
  image:
    image: /img/spotlight-2-bg.png
    alt: Integra tBTC icon
  align: left
integrations_section:
  title: 整合
---
