---
template: home-page
path: /
title: Trang chủ
hero:
  buttons:
    - text: Đúc tBTC
      url: https://dapp.tbtc.network/
  subtitle: Gửi tiền vào đổi BTC trong DEFI mà không qua trung gian.
  title: Cách an toàn để kiếm tiền với Bitcoin của bạn.
  image:
    alt: Đúc tBTC
    image: /img/dapp.svg
    url: https://dapp.tbtc.network/
features:
  - description: 'Mỗi tBTC được hỗ trợ 1: 1 bằng BTC'
    title: Bảo chứng
  - description: Không có trung gian - Đổi tBTC lấy BTC bất cứ lúc nào
    title: Không trung gian
  - description: Đã kiểm toán và là mã nguồn mở
    title: Bảo mật
  - description: Chỉ cần 3 bước để đổi BTC sang tBTC và ngược lại.
    title: Đơn giản
spotlight_1:
  body: ' tBTC sẽ chuyển sang mô hình ứng cử viên và sẽ giới hạn tổng cung. Mở rộng các biện pháp an ninh bao gồm kiểm toán thêm và trao giải thưởng cho các lỗi tìm thấy gấp 10 lần.'
  button:
    text: Xem thêm
    url: 'https://tbtc.network/news/2020-05-22-an-update-on-tbtc%E2%80%99s-launch/'
  label: Thông báo
  title: Cập nhật về ra mắt tBTC
spotlight_2:
  button:
    text: Bộ công cụ dành cho nhà phát triển
    url: /developers
  label: Nhà phát triển
  title: Tích hợp tBTC để thêm Bitcoin vào dApp của bạn
  image:
    image: /img/spotlight-2-bg.png
    alt: Integra tBTC icon
  align: left
integrations_section:
  title: Tích hợp
---

