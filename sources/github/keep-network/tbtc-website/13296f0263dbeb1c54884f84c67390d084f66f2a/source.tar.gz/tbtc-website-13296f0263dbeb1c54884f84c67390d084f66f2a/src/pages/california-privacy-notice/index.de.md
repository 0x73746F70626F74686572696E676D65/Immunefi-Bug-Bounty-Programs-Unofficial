---
template: 'legal-page'
path: /california-privacy-notice
title: KEEP SECZ Privacy Notice for California Residents
---
**Effective Date:** - April 16, 2020

This **Privacy Notice for California Residents** supplements the information contained in KEEP SECZ&#39;s [Privacy Policy](/privacy-policy) and applies solely to all visitors, users, and others who reside in the State of California (&quot;consumers&quot; or &quot;you&quot;). We adopt this notice to comply with the California Consumer Privacy Act of 2018 (CCPA) and any terms defined in the CCPA have the same meaning when used in this notice.

## Information We Collect

Our Website may collect information that identifies, relates to, describes, references, is capable of being associated with, or could reasonably be linked, directly or indirectly, with a particular consumer or device (&quot; **personal information**&quot;). In particular, our Website collects the following categories of personal information from its consumers within the last twelve (12) months:

| **Category** | **Examples** | **Collected** |
| --- | --- | --- |
| A. Identifiers. | Email address, Ethereum Wallet address | YES |
| B. Personal information categories listed in the California Customer Records statute (Cal. Civ. Code § 1798.80(e)). | A name, signature, Social Security number, physical characteristics or description, address, telephone number, passport number, driver&#39;s license or state identification card number, insurance policy number, education, employment, employment history, account number, credit card number, debit card number, or any other financial information, medical information, or health insurance information.Some personal information included in this category may overlap with other categories. | YES |
| C. Protected classification characteristics under California or federal law. | Age (40 years or older), race, color, ancestry, national origin, citizenship, religion or creed, marital status, medical condition, physical or mental disability, sex (including gender, gender identity, gender expression, pregnancy or childbirth and related medical conditions), sexual orientation, veteran or military status, genetic information (including familial genetic information).| NO |
| D. Commercial information. | Records of personal property, products or services purchased, obtained, or considered, or other purchasing or consuming histories or tendencies. | NO |
| E. Biometric information. | Genetic, physiological, behavioral, and biological characteristics, or activity patterns used to extract a template or other identifier or identifying information, such as, fingerprints, faceprints, and voiceprints, iris or retina scans, keystroke, gait, or other physical patterns, and sleep, health, or exercise data. | NO |
| F. Internet or other similar network activity. | Browsing history, search history, information on a consumer&#39;s interaction with a website, application, or advertisement. | NO |
| G. Geolocation data. | Physical location or movements. | NO |
| H. Sensory data. | Audio, electronic, visual, thermal, olfactory, or similar information. | NO |
| I. Professional or employment-related information. | Current or past job history or performance evaluations. | NO |
| J. Non-public education information (per the Family Educational Rights and Privacy Act (20 U.S.C. Section 1232g, 34 C.F.R. Part 99)). | Education records directly related to a student maintained by an educational institution or party acting on its behalf, such as grades, transcripts, class lists, student schedules, student identification codes, student financial information, or student disciplinary records. | NO |
| K. Inferences drawn from other personal information. | Profile reflecting a person&#39;s preferences, characteristics, psychological trends, predispositions, behavior, attitudes, intelligence, abilities, and aptitudes. | NO |

Personal information does not include:

- Publicly available information from government records.
- Deidentified or aggregated consumer information.
- Information excluded from the CCPA&#39;s scope, like:
  - health or medical information covered by the Health Insurance Portability and Accountability Act of 1996 (HIPAA) and the California Confidentiality of Medical Information Act (CMIA) or clinical trial data;
  - personal information covered by certain sector-specific privacy laws, including the Fair Credit Reporting Act (FRCA), the Gramm-Leach-Bliley Act (GLBA) or California Financial Information Privacy Act (FIPA), and the Driver&#39;s Privacy Protection Act of 1994.

KEEP SECZ obtains the categories of personal information listed above from the following categories of sources:

- Directly from you. For example, from forms you complete or products you use.

## Use of Personal Information

We may use or disclose the personal information we collect for one or more of the following business purposes:

- To fulfill or meet the reason you provided the information. For example, if you request to be included on an email list or in a user group, we will use that personal information to respond to your request. If you provide your personal information to enter into a smart contract, we will use that information for that purpose. We may also save your information to facilitate your future use of our Network.
- To process your requests, purchases, transactions, and payments and prevent transactional fraud.
- To provide you with support and to respond to your inquiries, including to investigate and address your concerns and monitor and improve our responses.
- To respond to law enforcement requests and as required by applicable law, court order, or governmental regulations.
- As described to you when collecting your personal information or as otherwise set forth in the CCPA.

KEEP SECZ will not collect additional categories of personal information or use the personal information we collected for materially different, unrelated, or incompatible purposes without providing you notice.

## Sharing Personal Information

KEEP SECZ may disclose your personal information to a third party for a business purpose. When we disclose personal information for a business purpose, we enter a contract that describes the purpose and requires the recipient to both keep that personal information confidential and not use it for any purpose except performing the contract.

We may share your personal information with the following categories of third parties:

- Service providers.

**_Disclosures of Personal Information for a Business Purpose_**

In the preceding twelve (12) months, Keep SECZ has not disclosed personal information for a business purpose.

We may disclose your personal information for a business purpose to the following categories of third parties:

- Service providers.

**_Sales of Personal Information_**

In the preceding twelve (12) months, Keep SECZ has not sold personal information.

## Your Rights and Choices

The CCPA provides consumers (California residents) with specific rights regarding their personal information. This section describes your CCPA rights and explains how to exercise those rights.

**_Access to Specific Information and Data Portability Rights_**

You have the right to request that KEEP SECZ disclose certain information to you about our collection and use of your personal information over the past 12 months. Once we receive and confirm your verifiable consumer request (see Exercising Access, Data Portability, and Deletion Rights), we will disclose to you:

- The categories of personal information we collected about you.
- The categories of sources for the personal information we collected about you.
- Our business or commercial purpose for collecting or selling that personal information.
- The categories of third parties with whom we share that personal information.
- The specific pieces of personal information we collected about you (also called a data portability request).
- If we sold or disclosed your personal information for a business purpose, two separate lists disclosing:
  - sales, identifying the personal information categories that each category of recipient purchased; and
  - disclosures for a business purpose, identifying the personal information categories that each category of recipient obtained.

**_Deletion Request Rights_**

You have the right to request that KEEP SECZ delete any of your personal information that we collected from you and retained, subject to certain exceptions. Once we receive and confirm your verifiable consumer request (see Exercising Access, Data Portability, and Deletion Rights), we will delete (and direct our service providers to delete) your personal information from our records, unless an exception applies. You acknowledge and agree that we will not be able to delete transactional histories involving your Ethereum wallet address from the Ethereum Blockchain ledger.

We may deny your deletion request if retaining the information is necessary for us or our service provider(s) to:

1. Complete the transaction for which we collected the personal information, provide a good or service that you requested, take actions reasonably anticipated within the context of our ongoing business relationship with you, or otherwise perform our contract with you.
2. Detect security incidents, protect against malicious, deceptive, fraudulent, or illegal activity, or prosecute those responsible for such activities.
3. Debug products to identify and repair errors that impair existing intended functionality.
4. Exercise free speech, ensure the right of another consumer to exercise their free speech rights, or exercise another right provided for by law.
5. Comply with the California Electronic Communications Privacy Act (Cal. Penal Code § 1546 _et. seq._).
6. Enable solely internal uses that are reasonably aligned with consumer expectations based on your relationship with us.
7. Comply with a legal obligation.
8. Make other internal and lawful uses of that information that are compatible with the context in which you provided it.

**_Exercising Access, Data Portability, and Deletion Rights_**

To exercise the access, data portability, and deletion rights described above, please submit a verifiable consumer request to us by either:

- Emailing us at: [legal@keep.network](mailto:legal@keep.network).

Only you, or a person registered with the California Secretary of State that you authorize to act on your behalf, may make a verifiable consumer request related to your personal information. You may also make a verifiable consumer request on behalf of your minor child.

You may only make a verifiable consumer request for access or data portability twice within a 12-month period. The verifiable consumer request must:

- Provide sufficient information that allows us to reasonably verify you are the person about whom we collected personal information or an authorized representative.
- Describe your request with sufficient detail that allows us to properly understand, evaluate, and respond to it.

We cannot respond to your request or provide you with personal information if we cannot verify your identity or authority to make the request and confirm the personal information relates to you.

Making a verifiable consumer request does not require you to create an account with us.

We will only use personal information provided in a verifiable consumer request to verify the requestor&#39;s identity or authority to make the request.

For instructions on exercising sale opt-out rights, see Personal Information Sales Opt-Out and Opt-In Rights.

**_Response Timing and Format_**

We endeavor to respond to a verifiable consumer request within forty-five (45) days of its receipt. If we require more time, we will inform you of the reason and extension period in writing. We will deliver our written response to the email address from which you submit it.

Any disclosures we provide will only cover the 12-month period preceding the verifiable consumer request&#39;s receipt. The response we provide will also explain the reasons we cannot comply with a request, if applicable.

We do not charge a fee to process or respond to your verifiable consumer request unless it is excessive, repetitive, or manifestly unfounded. If we determine that the request warrants a fee, we will tell you why we made that decision and provide you with a cost estimate before completing your request.

**_Personal Information Sales Opt-Out and Opt-In Rights_**

We do not sell your personal information so there is no reason for you to opt out of such sales.

## Non-Discrimination

We will not discriminate against you for exercising any of your CCPA rights. Unless permitted by the CCPA, we will not:

- Deny you goods or services.
- Charge you different prices or rates for goods or services, including through granting discounts or other benefits, or imposing penalties.
- Provide you a different level or quality of goods or services.
- Suggest that you may receive a different price or rate for goods or services or a different level or quality of goods or services.

## Other California Privacy Rights

California&#39;s &quot;Shine the Light&quot; law (Civil Code Section § 1798.83) permits users of our Website that are California residents to request certain information regarding our disclosure of personal information to third parties for their direct marketing purposes. We do not disclose personal information for marketing purposes so there is no need to make such a request.

## Changes to Our Privacy Notice

KEEP SECZreserves the right to amend this privacy notice at our discretion and at any time. When we make changes to this privacy notice, we will post the updated notice on the Website and update the notice&#39;s effective date. **Your continued use of our Website following the posting of changes constitutes your acceptance of such changes**.

## Contact Information

If you have any questions or comments about this notice, the ways in which KEEP SECZ collects and uses your information, your choices and rights regarding such use, or wish to exercise your rights under California law, please do not hesitate to contact us at:

**Email**: [legal@keep.network](mailto:legal@keep.network)