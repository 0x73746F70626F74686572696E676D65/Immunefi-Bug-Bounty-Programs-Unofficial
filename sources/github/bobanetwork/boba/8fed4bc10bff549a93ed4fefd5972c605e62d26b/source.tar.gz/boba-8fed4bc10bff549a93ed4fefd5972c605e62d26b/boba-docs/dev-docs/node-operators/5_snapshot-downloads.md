import SnapshotTable from '@site/src/components/SnapshotTable';

# Node Snapshots

This page has a list of important snapshots for node operators. Data directories and node snapshots are not required but can significantly simplify the node operation process.

## Current snapshots

These are the snapshots to use. They are published weekly, and the entries below
are regenerated from what was actually published — so this page always shows the
current snapshot.

Each URL is immutable: it always serves the exact bytes listed beside it, which
means an interrupted download can be resumed safely. Only the most recent couple
of snapshots are retained, though, so **do not hardcode a URL** — resolve it at
download time (see [below](#scripted-downloads)) or come back to this page.

Always verify a download against the `sha256sum` shown with it:

```bash
sha256sum <filename>
```

### BOBA Mainnet

<SnapshotTable chain="boba-mainnet" />

### BOBA Sepolia Testnet

<SnapshotTable chain="boba-sepolia" />

## Scripted downloads

Every snapshot is published with a small JSON manifest, and `latest.json` always
points at the current one:

```
https://snapshots.boba.network/boba-mainnet/latest.json
https://snapshots.boba.network/boba-sepolia/latest.json
```

It carries the download URL, its `sha256`, the block the snapshot was taken at,
and its size — so a script can fetch and verify without anything hardcoded:

```bash
CHAIN=boba-mainnet   # or boba-sepolia

MANIFEST=$(curl -fsSL "https://snapshots.boba.network/$CHAIN/latest.json")
URL=$(echo "$MANIFEST" | jq -r .url)
SHA=$(echo "$MANIFEST" | jq -r .sha256)

echo "$MANIFEST" | jq -r '"block \(.block_number), \(.size_compressed_bytes/1073741824|floor) GiB"'

# --continue-at - resumes if the download is interrupted
curl -fL --retry 3 --continue-at - "$URL" -o snapshot.tar.zst
echo "$SHA  snapshot.tar.zst" | sha256sum -c -

zstd -dc snapshot.tar.zst | tar -xf - -C /path/to/datadir
```

The [`boba-community` docker-compose setup](https://github.com/bobanetwork/boba/tree/develop/boba-community)
does exactly this for you — `docker compose --profile seed run --rm seed-database`
resolves, downloads, verifies and extracts the current snapshot.

### Manifest fields

| Field | Meaning |
| --- | --- |
| `url` | Download URL for this snapshot |
| `sha256` | Checksum of the archive, as `sha256sum` reports it |
| `block_number`, `block_hash` | The chain head the snapshot was taken at |
| `block_timestamp_utc` | Timestamp of that block |
| `size_compressed_bytes` | Download size |
| `size_uncompressed_bytes` | Disk needed after extraction |
| `reth_image` | The op-reth build that produced it |
| `includes_proofsdb` | Whether a proofs database is included |
| `proofs_history_window_blocks` | How many blocks of `eth_getProof` history it covers |

## Bootstrapping from genesis

You only need this section if you want to rebuild the database yourself rather
than download it — for example to verify the chain from its initial state
migration. Most operators can ignore everything below.

### Migration artifacts

The inputs to `op-reth init-state`, published so the migration stays reproducible
without a synced geth or erigon node.

#### BOBA Mainnet

These are the source artifacts used to generate the initial reth database via `op-reth init-state`. They allow independent verification and reproducibility without needing a synced geth/erigon node.

| File | Description | Size | Download Link | Sha256sum |
| ---- | ----------- | ---- | ------------- | --------- |
| State dump | All accounts at migration block 1149019 in reth JSONL format | 150MB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-reth-state-initial.jsonl) | `1b226876bf6de17deed4865226ad87c77fd57dd43f47f67d5c870d937396463a` |
| Block header | RLP-encoded header for block 1149019 | 508B | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-reth-header-initial.rlp) | `323a5337d151204724817a826d7846cb29a7aef0738448c9c0dd9250a8402eb8` |

#### BOBA Sepolia Testnet

| File | Description | Size | Download Link | Sha256sum |
| ---- | ----------- | ---- | ------------- | --------- |
| State dump | All accounts at migration block 511 in reth JSONL format | 1.1MB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-reth-state-initial.jsonl) | `79dbeaaff89db3422ff057b67e78f3a576494213e5927347ce6f22cc829c0943` |
| Block header | RLP-encoded header for block 511 | 1KB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-reth-header-initial.rlp) | `0514713a96e46856b3db8618d2c76c98433e1e506431f47c76473d77b5a676b8` |

### Initial databases

The database immediately after the state migration, before any later blocks — the
smallest starting point from which a node can sync the whole chain itself.

#### BOBA Mainnet

| Client | Snapshot Date | Size | Download Link | Sha256sum |
| ------ | ------------- | ---- | ------------- | --------- |
| Reth   | initial (block 1149019) | 74MB     | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-reth-db-initial.tar.zst) | `22b26c59ecbfc7b8f77525dc210d1780aa2bbf072084aae2b9d2e88b1f1d3301` |

#### BOBA Sepolia Testnet

| Client | Snapshot Date | Size | Download Link | Sha256sum |
| ------ | ------------- | ---- | ------------- | --------- |
| Reth   | initial (block 511) | 343KB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-reth-db-initial.tar.zst) | `703cb2c0c33a4689d7cfabb10483e7ec0900068f597da9455db0dcba06a9d8bf` |

## Historical archives

Retained only for operators migrating an existing database to op-reth (see the
[migration guide](https://github.com/bobanetwork/boba/tree/develop/boba-community/scripts/geth-to-reth)),
and for the optional pre-Anchorage l2geth node.

**Geth and Erigon are not supported execution clients.** op-reth is the only one.

### Unsupported client archives

#### BOBA Mainnet

| Client | Snapshot Date | Size | Download Link | Sha256sum |
| ------ | ------------- | ---- | ------------- | --------- |
| Erigon | 2024-04-16    | 1016.4MB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-erigon-db-1149019.tgz) | `98bfd73716585f412a6388bb51a8bfb945170d0d228efb4d218d98d523d76168` |
| Geth   | 2024-04-16    | 16.3GB   | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-geth-db-114909.tgz) | `102922968680e86afe0588cf22924639f6f2ab32aee1c1e2325c3026b262692b` |
| Geth   | 2024-07-30    | 49.7GB   | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-geth-snapshot-5683043.tgz) | `9d20e16434bbdb8d2fdcdfee848f7941337e6b2cfb8feece441820c9a6364d09` |
| Geth   | 2025-10-10    | 146GB   | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-geth-db-20251010.tar.zst) | `4f4c0a1d2376382110ecc90d46329850222feaedd9d320b146c326359d5b1353` |

#### BOBA Sepolia Testnet

| Client | Snapshot Date | Size | Download Link | Sha256sum |
| ------ | ------------- | ---- | ------------- | --------- |
| Erigon | 2024-01-18    | 912KB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-erigon-db.tgz) | `b887d2e0318e9299e844da7d39ca32040e3d0fb6a9d7abe2dd2f8624eca1cade` |
| Geth   | 2024-01-18    | 2MB   | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-geth-db.tgz) | `b229c8e51e41a26bb21a84b329d3134ae5cc6541b04eb160aebd573f0e6b94ae` |
| Erigon | 2024-02-13    | 586M  | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-erigon-snapshot-1126371.tgz) | `688fd431656b673d3f2c690d79277b6d659a51c48c7b73a5e36bb8fbfdbdea80` |
| Erigon | 2024-3-01     | 956M  | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-erigon-snapshot-1857820.tgz) | `3464fa9c1f669ad3d26359e5c463c33d3d60735a7aafb8e10d2dfd4719a71c07` |
| Geth   | 2025-10-02    | 135GB   | [Link](https://boba-db.s3.us-east-2.amazonaws.com/sepolia/boba-sepolia-geth-db-20251002.tar.zst) | `578cdc9ae438986a7895e3c16485e8268c2eae9fafa622dd3f0c778b30a2a5a8` |

### Pre-Anchorage l2geth (BOBA Mainnet)

| Client | Snapshot Date | Size   | Download Link                                                | Sha256sum                                                    |
| ------ | ------------- | ------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| Geth   | 2024-04-16    | 16.3GB | [Link](https://boba-db.s3.us-east-2.amazonaws.com/mainnet/boba-mainnet-geth-db-legacy.tgz) | `5864b5da7cebe0810a2be4d9cdcc0fdca91f2ee6b278c87ef518e8a852f0da72` |
