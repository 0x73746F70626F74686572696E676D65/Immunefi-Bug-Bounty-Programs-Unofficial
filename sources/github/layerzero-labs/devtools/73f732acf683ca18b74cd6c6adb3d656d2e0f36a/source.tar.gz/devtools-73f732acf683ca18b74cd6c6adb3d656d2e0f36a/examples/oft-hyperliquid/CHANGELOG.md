# @layerzerolabs/oft-hyperliquid-example

## 0.0.11

### Patch Changes

- 9be22c2: change fork fuzzing to works off a forked anvil
- 253612c: fuzz run 1 on ci

## 0.0.10

### Patch Changes

- 26c44d4: hyperliquid corewriter variant

## 0.0.9

### Patch Changes

- 9578746: docs update + onlyComposer on internal -> external transformation

## 0.0.8

### Patch Changes

- 9c0c90c: using CoreWriter instead of WritePrecompile

## 0.0.7

### Patch Changes

- e633f6d: patch: skip fork tests when forking testnet fails

## 0.0.6

### Patch Changes

- 4416064: wrapper for viewing deployment state "spotDeployState" and adding in missing step to deploy the token on the spot order book

## 0.0.5

### Patch Changes

- d23edda: docs update - deployer trading fee

## 0.0.4

### Patch Changes

- 1900486: docs typo cleanup

## 0.0.3

### Patch Changes

- 690885c: get asset bridge address for any token and listing hip-1 token information - https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint/spot#retrieve-information-about-a-token

## 0.0.2

### Patch Changes

- 000f6ec: hyperliquid sdk update - oapp-config is optional and will prompt the user for oft address and oft deploy transaction hash
