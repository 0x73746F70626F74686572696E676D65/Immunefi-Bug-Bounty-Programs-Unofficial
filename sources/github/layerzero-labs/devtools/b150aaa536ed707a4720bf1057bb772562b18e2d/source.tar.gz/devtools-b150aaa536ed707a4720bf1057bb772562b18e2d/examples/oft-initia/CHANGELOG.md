# @layerzerolabs/oft-initia-example

## 0.0.9

### Patch Changes

- 39ddee8: remove usage of MyOFTMock

## 0.0.8

### Patch Changes

- c44e657: update evm networks used

## 0.0.7

### Patch Changes

- 5e15a8d: Add lockfiles to example packages

## 0.0.6

### Patch Changes

- ba7754d: Bump package versions

## 0.0.5

### Patch Changes

- b1feef7: Devex improvements.

## 0.0.4

### Patch Changes

- bb6ac29: Updating object ownership validation instructions

## 0.0.3

### Patch Changes

- cd6de9d: Tx export functinality for Initia, improving README.md instructions for clarity, 2 minor bug fixes.

## 0.0.2

### Patch Changes

- ff0b018: adjusting readme to reflect new installation process
