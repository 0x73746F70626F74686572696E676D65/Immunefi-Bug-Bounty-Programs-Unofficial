// SPDX-License-Identifier: MIT

pragma solidity =0.8.24;

contract ArbitrumUniV3Addresses {
    address internal constant POSITION_MANAGER_ADDR = 0xC36442b4a4522E871399CD717aBDD847Ab11FE88;
}
