// SPDX-License-Identifier: MIT
pragma solidity =0.8.24;

import { SafeERC20 } from "../../_vendor/openzeppelin/SafeERC20.sol";
import { ActionBase } from "../ActionBase.sol";
import { IERC20 } from "../../interfaces/token/IERC20.sol";

/// @title Helper action to remove token approval given to a spender
contract RemoveTokenApproval is ActionBase {
    using SafeERC20 for IERC20;

    /// @param tokenAddr Address of the token to remove approval from
    /// @param spender Address of the spender
    struct Params {
        address tokenAddr;
        address spender;
    }

    /// @inheritdoc ActionBase
    function executeAction(
        bytes memory _callData,
        bytes32[] memory _subData,
        uint8[] memory _paramMapping,
        bytes32[] memory _returnValues
    ) public payable virtual override returns (bytes32) {
        Params memory inputData = parseInputs(_callData);

        inputData.tokenAddr =
            _parseParamAddr(inputData.tokenAddr, _paramMapping[0], _subData, _returnValues);
        inputData.spender =
            _parseParamAddr(inputData.spender, _paramMapping[1], _subData, _returnValues);

        _removeApproval(inputData.tokenAddr, inputData.spender);

        emit ActionEvent("RemoveTokenApproval", abi.encode(inputData));
        return bytes32(0);
    }

    /// @inheritdoc ActionBase
    function executeActionDirect(bytes memory _callData) public payable override {
        Params memory inputData = parseInputs(_callData);

        _removeApproval(inputData.tokenAddr, inputData.spender);
        logger.logActionDirectEvent("RemoveTokenApproval", abi.encode(inputData));
    }

    /// @inheritdoc ActionBase
    function actionType() public pure virtual override returns (uint8) {
        return uint8(ActionType.STANDARD_ACTION);
    }

    //////////////////////////// ACTION LOGIC ////////////////////////////

    /// @notice Remove approval for spender to pull tokens from user wallet
    /// @param _tokenAddr Address of token
    /// @param _spender Address of the spender
    function _removeApproval(address _tokenAddr, address _spender) internal {
        IERC20(_tokenAddr).safeApprove(_spender, 0);
    }

    function parseInputs(bytes memory _callData) public pure returns (Params memory params) {
        params = abi.decode(_callData, (Params));
    }
}
