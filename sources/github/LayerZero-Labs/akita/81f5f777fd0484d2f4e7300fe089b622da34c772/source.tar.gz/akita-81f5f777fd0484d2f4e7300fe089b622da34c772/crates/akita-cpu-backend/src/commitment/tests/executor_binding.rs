use super::*;
use crate::commitment::{
    CommitmentSource, DenseType, InnerCommitOperation, InnerImage, InnerRelationState,
    InnerRelationStateMaterial, NoRetainedStatePolicy, ResolvedCommitSource, StateOwnerCapability,
};
use crate::{AkitaProverSetup, DensePoly};
use akita_challenges::SparseChallengeConfig;
use akita_params::{
    CommittedGroupParams, SetupMatrixCapacity, SisModulusProfileId, TerminalFoldParams,
};
use akita_types::RingVec;
use jolt_field::{Prime64Offset59, Ring};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

type F = Prime64Offset59;

#[test]
fn inner_relation_material_rejects_incomplete_exported_rows() {
    let params = CommittedGroupParams::params_only(
        SisModulusProfileId::Q64Offset59,
        64,
        2,
        1,
        1,
        1,
        SparseChallengeConfig::pm1_only(1),
    )
    .with_decomp(4, 8, 1, 2, 2)
    .unwrap();
    let plan =
        CommitmentExecutionPlan::for_terminal(&TerminalFoldParams::from_expanded_group(params), 0)
            .unwrap();
    let setup = AkitaProverSetup::<F>::generate_with_capacity(
        9,
        1,
        SetupMatrixCapacity {
            num_field_elements: 128 * 64,
        },
    )
    .unwrap();
    let binding = CommitmentStateBinding::new(
        setup.expanded.descriptor().clone(),
        *plan.inner(),
        1,
        None,
        None,
    )
    .unwrap();
    let short_row = RingVec::from_coeffs_with_ring_dim(vec![F::default(); 64], 64).unwrap();

    assert!(InnerRelationStateMaterial::from_binding(&binding, vec![short_row]).is_err());
}

#[test]
fn generic_inner_state_material_rejects_incomplete_rows() {
    struct MalformedState;

    impl InnerRelationState<F> for MalformedState {
        type Material = InnerRelationStateMaterial<F>;

        fn inner_relation_material(
            &self,
            plan: &crate::opaque::CommitInnerPlan,
            source_count: usize,
        ) -> Result<InnerRelationStateMaterial<F>, AkitaError> {
            InnerRelationStateMaterial::new(
                plan,
                source_count,
                vec![RingVec::from_coeffs_with_ring_dim(vec![F::default(); 64], 64).unwrap()],
            )
        }
    }

    let plan = crate::opaque::CommitInnerPlan {
        ring_dimension: 64,
        num_live_blocks: 1,
        n_a: 2,
        num_positions_per_block: 1,
        num_digits_inner: 1,
        log_basis_inner: 1,
    };
    assert!(MalformedState.inner_relation_material(&plan, 1).is_err());
}

#[test]
fn inner_relation_material_rejects_same_size_different_plan() {
    let plan = crate::opaque::CommitInnerPlan {
        ring_dimension: 64,
        num_live_blocks: 1,
        n_a: 2,
        num_positions_per_block: 1,
        num_digits_inner: 1,
        log_basis_inner: 1,
    };
    let material = InnerRelationStateMaterial::new(
        &plan,
        1,
        vec![RingVec::from_coeffs_with_ring_dim(vec![F::default(); 128], 64).unwrap()],
    )
    .unwrap();
    let same_size = crate::opaque::CommitInnerPlan {
        num_live_blocks: 2,
        n_a: 1,
        ..plan
    };
    assert!(material.validate(&same_size, 1).is_err());
}

#[test]
fn generic_preflight_does_not_materialize_or_replace_relation_state() {
    struct CountingState(AtomicUsize);

    impl InnerRelationState<F> for CountingState {
        type Material = InnerRelationStateMaterial<F>;

        fn inner_relation_material(
            &self,
            plan: &crate::opaque::CommitInnerPlan,
            source_count: usize,
        ) -> Result<InnerRelationStateMaterial<F>, AkitaError> {
            self.0.fetch_add(1, Ordering::SeqCst);
            let coefficient_count = plan
                .num_live_blocks
                .checked_mul(plan.n_a)
                .and_then(|count| count.checked_mul(plan.ring_dimension))
                .ok_or_else(|| AkitaError::InvalidSetup("test row length overflow".into()))?;
            InnerRelationStateMaterial::new(
                plan,
                source_count,
                (0..source_count)
                    .map(|_| {
                        RingVec::from_coeffs_with_ring_dim(
                            vec![F::default(); coefficient_count],
                            plan.ring_dimension,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )
        }
    }

    let plan = crate::opaque::CommitInnerPlan {
        ring_dimension: 64,
        num_live_blocks: 1,
        n_a: 2,
        num_positions_per_block: 1,
        num_digits_inner: 1,
        log_basis_inner: 1,
    };
    let state = CountingState(AtomicUsize::new(0));
    state.preflight_inner_relation(&plan, 1).unwrap();
    assert_eq!(state.0.load(Ordering::SeqCst), 0);
    state.inner_relation_material(&plan, 1).unwrap();
    assert_eq!(state.0.load(Ordering::SeqCst), 1);
}

struct ReboundInner {
    owner: StateOwnerCapability<InnerImage>,
    rebound: bool,
}

impl InnerCommitOperation<F> for ReboundInner {
    fn commit_inner(
        &self,
        binding: &CommitmentStateBinding,
        plan: &crate::opaque::CommitInnerPlan,
        _sources: &[ResolvedCommitSource<'_, F>],
    ) -> Result<InnerCommitOutput, AkitaError> {
        let output_binding = if self.rebound {
            CommitmentStateBinding::new(
                binding.setup().clone(),
                *plan,
                binding.source_count(),
                binding.relation_mode(),
                binding.compression_plan().cloned(),
            )?
        } else {
            binding.clone()
        };
        Ok(InnerCommitOutput::new(self.owner.bind(
            output_binding,
            0,
            (),
        )))
    }
}

#[test]
fn executor_rejects_same_shape_rebinding_and_foreign_state_owners() {
    struct Backend;
    struct InnerContext;

    let params = CommittedGroupParams::params_only(
        SisModulusProfileId::Q64Offset59,
        64,
        2,
        1,
        1,
        1,
        SparseChallengeConfig::pm1_only(1),
    )
    .with_decomp(4, 8, 1, 2, 2)
    .unwrap();
    let plan =
        CommitmentExecutionPlan::for_terminal(&TerminalFoldParams::from_expanded_group(params), 0)
            .unwrap();
    let setup = AkitaProverSetup::<F>::generate_with_capacity(
        9,
        1,
        SetupMatrixCapacity {
            num_field_elements: 128 * 64,
        },
    )
    .unwrap();
    let mut builder =
        CommitmentExecutorBuilder::new(setup.expanded.as_ref(), NoRetainedStatePolicy);
    let context = builder
        .operation_context(
            builder.issue_backend_instance(),
            "rebound-inner",
            StageResources::none(),
        )
        .unwrap();
    let operation = Arc::new(ReboundInner {
        owner: StateOwnerCapability::new(),
        rebound: true,
    });
    let capabilities = CommitmentRequestCapabilities::split::<InnerContext>(
        BackendKindId::of::<Backend>("rebound").unwrap(),
        vec![PolynomialType::Dense(DenseType::Coefficients)],
    );
    builder
        .register_inner(
            PreparedInnerCommitment::new(
                operation.clone(),
                operation.owner.clone(),
                context,
                capabilities,
                StageDimensionCapabilities::new(vec![64]).unwrap(),
                None,
            )
            .unwrap(),
        )
        .unwrap();
    let executor = builder.build().unwrap();
    let consumer_error = executor
        .preflight_prover_state_consumers(&plan)
        .expect_err("missing inner state consumer must fail preflight");
    assert!(matches!(
        consumer_error,
        AkitaError::InvalidInput(message) if message.contains("inner-relation state operation")
    ));
    let source = DensePoly::from_field_evals(9, vec![F::from_u64(1); 512]).unwrap();
    let sources: [&dyn CommitmentSource<F>; 1] = [&source];

    let error = match executor.execute_inner(&plan, &sources) {
        Err(error) => error,
        Ok(_) => panic!("rebound state must be rejected"),
    };
    assert!(
        matches!(
            &error,
            AkitaError::InvalidInput(message) if message.contains("different commitment request")
        ),
        "unexpected error: {error:?}"
    );

    let mut builder =
        CommitmentExecutorBuilder::new(setup.expanded.as_ref(), NoRetainedStatePolicy);
    let context = builder
        .operation_context(
            builder.issue_backend_instance(),
            "wrong-owner-inner",
            StageResources::none(),
        )
        .unwrap();
    let operation = Arc::new(ReboundInner {
        owner: StateOwnerCapability::new(),
        rebound: false,
    });
    let capabilities = CommitmentRequestCapabilities::split::<InnerContext>(
        BackendKindId::of::<Backend>("wrong-owner").unwrap(),
        vec![PolynomialType::Dense(DenseType::Coefficients)],
    );
    builder
        .register_inner(
            PreparedInnerCommitment::new(
                operation,
                StateOwnerCapability::new(),
                context,
                capabilities,
                StageDimensionCapabilities::new(vec![64]).unwrap(),
                None,
            )
            .unwrap(),
        )
        .unwrap();
    let error = match builder.build().unwrap().execute_inner(&plan, &sources) {
        Err(error) => error,
        Ok(_) => panic!("foreign state owner must be rejected"),
    };
    assert!(matches!(
        error,
        AkitaError::InvalidInput(message) if message.contains("different prepared implementation")
    ));
}
