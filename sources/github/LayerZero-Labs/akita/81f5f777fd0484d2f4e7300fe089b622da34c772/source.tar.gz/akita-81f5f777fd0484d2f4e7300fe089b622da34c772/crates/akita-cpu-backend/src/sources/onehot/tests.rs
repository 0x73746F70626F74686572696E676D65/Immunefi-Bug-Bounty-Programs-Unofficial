use super::test_helpers::inner_ajtai_reference;
use super::*;
use crate::opaque::RootOpeningSource;
use crate::DensePoly;
use akita_params::FlatMatrix;
use jolt_field::{Field, Ring};
use jolt_field::{Fp64, Prime128Offset275, Prime24Offset3};
use rand::rngs::StdRng;
use rand::SeedableRng;

fn aggregate_witnesses<const D: usize>(witnesses: &[DecomposeFoldWitness]) -> DecomposeFoldWitness {
    let Some((first, rest)) = witnesses.split_first() else {
        panic!("aggregate_witnesses requires at least one witness");
    };
    first
        .ensure_ring_dim::<D>()
        .expect("witness ring dimension");
    let mut centered_coeffs = first.centered_coeffs_owned::<D>();

    for witness in rest {
        witness
            .ensure_ring_dim::<D>()
            .expect("witness ring dimension");
        assert_eq!(witness.row_count(), centered_coeffs.len());
        for (dst, src) in centered_coeffs
            .iter_mut()
            .zip(witness.centered_coeffs_trusted::<D>())
        {
            for k in 0..D {
                dst[k] = dst[k]
                    .checked_add(src[k])
                    .expect("centered coefficient overflow");
            }
        }
    }

    DecomposeFoldWitness::from_centered_rows(centered_coeffs)
}

#[test]
fn batch_fold_rejects_mixed_extents_and_count_mismatch() {
    use crate::opaque::{CpuBackend, DecomposeFoldBatchPlan, OpeningBatchKernel};
    use akita_challenges::SparseChallenge;

    type F = Prime24Offset3;
    const D: usize = 64;
    let polys = [
        OneHotPoly::<F>::new(64, vec![Some(0usize)]).unwrap(),
        OneHotPoly::<F>::new(64, vec![Some(0usize); 2]).unwrap(),
    ];
    let challenges = vec![
        SparseChallenge {
            positions: vec![0].into(),
            coeffs: vec![1].into(),
        };
        2
    ];
    let backend = CpuBackend::<F, F>::for_arithmetic_tests();
    let run = |refs: &[&OneHotPoly<F>]| {
        OpeningBatchKernel::decompose_fold_batch(
            &backend,
            None,
            <OneHotPoly<F> as RootOpeningSource<F, D>>::opening_batch(refs).unwrap(),
            DecomposeFoldBatchPlan::Sparse {
                challenges: &challenges,
                num_positions_per_block: 1,
                num_digits: 1,
                log_basis: 1,
            },
        )
    };

    assert!(matches!(
        run(&[&polys[0], &polys[1]]),
        Err(AkitaError::InvalidInput(_))
    ));
    assert!(matches!(
        run(&[&polys[0], &polys[0], &polys[0]]),
        Err(AkitaError::InvalidInput(_))
    ));
}

fn materialize_onehot_as_dense<F, const D: usize, I>(poly: &OneHotPoly<F, I>) -> DensePoly<F>
where
    F: Field + CanonicalEncoding,
    I: OneHotIndex,
{
    let mut coeffs = vec![CyclotomicRing::<F, D>::zero(); (1usize << poly.num_vars).div_ceil(D)];
    for (chunk_idx, hot_idx) in poly.indices.iter().copied().enumerate() {
        let Some(raw) = hot_idx else {
            continue;
        };
        let field_pos = chunk_idx * poly.onehot_k + raw.as_usize();
        let ring_idx = field_pos / D;
        let coeff_idx = field_pos % D;
        coeffs[ring_idx].coeffs[coeff_idx] += F::one();
    }
    DensePoly::from_ring_coeffs(coeffs).unwrap()
}

#[test]
fn scalar_fold_rejects_short_and_excess_challenges() {
    use crate::opaque::{CpuBackend, DecomposeFoldPlan, OpeningFoldKernel, RootOpeningSource};
    use akita_challenges::SparseChallenge;

    type F = Prime24Offset3;
    const D: usize = 64;
    // Two chunks of 64 positions fill two rings, so two live blocks at one position per block.
    let poly = OneHotPoly::<F>::new(64, vec![Some(0usize); 2]).unwrap();
    let challenge = SparseChallenge {
        positions: vec![0].into(),
        coeffs: vec![1].into(),
    };
    let backend = CpuBackend::<F, F>::for_arithmetic_tests();
    let run = |count: usize| {
        let challenges = vec![challenge.clone(); count];
        OpeningFoldKernel::decompose_fold(
            &backend,
            None,
            <OneHotPoly<F> as RootOpeningSource<F, D>>::opening_view(&poly).unwrap(),
            DecomposeFoldPlan {
                challenges: &challenges,
                num_positions_per_block: 1,
                num_digits: 1,
                log_basis: 1,
            },
        )
    };

    assert!(run(2).is_ok());
    for count in [0, 1, 3] {
        assert!(
            matches!(
                run(count),
                Err(AkitaError::InvalidSize { expected: 2, actual }) if actual == count
            ),
            "{count} challenges for two live blocks must be rejected"
        );
    }
}
fn test_ring_scalar<F, const D: usize>(seed: u64) -> CyclotomicRing<F, D>
where
    F: Field + CanonicalEncoding,
{
    CyclotomicRing::from_coefficients(std::array::from_fn(|idx| {
        F::from_u128_reduced(u128::from(seed + idx as u64 + 1))
    }))
}

fn block_entry(pos_in_block: usize, coeff_idx: usize) -> SparseRingBlockEntry {
    SparseRingBlockEntry::new(pos_in_block as u32, coeff_idx as u16, 1)
}

#[test]
fn wide_matches_reference() {
    type F = Fp64<4294967197>;
    const D: usize = 64;

    let mut rng = StdRng::seed_from_u64(0xdead_beef);
    let n_a = 3;
    let num_positions_per_block = 4;
    let num_digits = 5;
    let a_matrix: Vec<Vec<CyclotomicRing<F, D>>> = (0..n_a)
        .map(|_| {
            (0..num_positions_per_block * num_digits)
                .map(|_| CyclotomicRing::random(&mut rng))
                .collect()
        })
        .collect();

    let entries = vec![
        block_entry(0, 1),
        block_entry(0, 7),
        block_entry(0, 15),
        block_entry(2, 0),
        block_entry(2, 63),
    ];

    let a_flat_elems: Vec<CyclotomicRing<F, D>> = a_matrix
        .iter()
        .flat_map(|row| row.iter().copied())
        .collect();
    let a_flat = FlatMatrix::from_ring_slice(&a_flat_elems);
    let a_view = a_flat
        .ring_view::<D>(n_a, num_positions_per_block * num_digits)
        .unwrap();
    let ref_result = inner_ajtai_reference(&a_matrix, &entries, num_digits);
    let wide_result = inner_ajtai_wide_onehot(&a_view, &entries, num_digits);

    assert_eq!(ref_result.len(), wide_result.len());
    for (r, w) in ref_result.iter().zip(wide_result.iter()) {
        assert_eq!(r, w, "wide result must match reference");
    }
}

#[test]
fn wide_matches_reference_fp128() {
    type F = Prime128Offset275;
    const D: usize = 64;

    let mut rng = StdRng::seed_from_u64(0xcafe_1234);
    let n_a = 2;
    let num_positions_per_block = 2;
    let num_digits = 3;
    let a_matrix: Vec<Vec<CyclotomicRing<F, D>>> = (0..n_a)
        .map(|_| {
            (0..num_positions_per_block * num_digits)
                .map(|_| CyclotomicRing::random(&mut rng))
                .collect()
        })
        .collect();

    let entries = vec![
        block_entry(0, 0),
        block_entry(0, 5),
        block_entry(0, 32),
        block_entry(0, 63),
        block_entry(1, 10),
    ];

    let a_flat_elems: Vec<CyclotomicRing<F, D>> = a_matrix
        .iter()
        .flat_map(|row| row.iter().copied())
        .collect();
    let a_flat = FlatMatrix::from_ring_slice(&a_flat_elems);
    let a_view = a_flat
        .ring_view::<D>(n_a, num_positions_per_block * num_digits)
        .unwrap();
    let ref_result = inner_ajtai_reference(&a_matrix, &entries, num_digits);
    let wide_result = inner_ajtai_wide_onehot(&a_view, &entries, num_digits);

    assert_eq!(ref_result.len(), wide_result.len());
    for (r, w) in ref_result.iter().zip(wide_result.iter()) {
        assert_eq!(r, w, "wide result must match reference (Fp128)");
    }
}

fn assert_counting_column_sweep_matches_per_block_reference(num_live_blocks: usize) {
    type F = Fp64<4294967197>;
    const D: usize = 64;

    let mut rng = StdRng::seed_from_u64(0x51ee_7eed);
    let n_a = 2;
    let num_positions_per_block = 4;
    let num_digits_inner = 3;
    let active_a_cols = num_positions_per_block * num_digits_inner;
    let a_matrix: Vec<Vec<CyclotomicRing<F, D>>> = (0..n_a)
        .map(|_| {
            (0..active_a_cols)
                .map(|_| CyclotomicRing::random(&mut rng))
                .collect()
        })
        .collect();
    let buckets = (0..num_live_blocks)
        .map(|block| {
            vec![
                block_entry(block % num_positions_per_block, 0),
                block_entry(block % num_positions_per_block, 7),
                block_entry(block % num_positions_per_block, 31),
                block_entry((block + 1) % num_positions_per_block, 5),
                block_entry((block + 1) % num_positions_per_block, 19),
            ]
        })
        .collect::<Vec<_>>();
    let blocks = super::test_helpers::from_buckets(buckets.clone());
    let block_views = (0..num_live_blocks)
        .map(|block| blocks.block(block))
        .collect::<Vec<_>>();
    let a_flat =
        FlatMatrix::from_ring_slice(&a_matrix.iter().flatten().copied().collect::<Vec<_>>());
    let a_view = a_flat.ring_view::<D>(n_a, active_a_cols).unwrap();

    let got = column_sweep_ajtai_onehot::<F, D>(
        &a_view,
        &block_views,
        n_a,
        active_a_cols,
        num_digits_inner,
    );
    let expected = buckets
        .iter()
        .map(|entries| inner_ajtai_reference::<F, D>(&a_matrix, entries, num_digits_inner))
        .collect::<Vec<_>>();

    assert_eq!(got, expected);
}

#[test]
fn counting_column_sweep_matches_per_block_reference() {
    // The production sweep threshold is 32 blocks per worker.
    const BLOCKS_PER_THREAD: usize = 33;
    #[cfg(feature = "parallel")]
    let num_live_blocks = rayon::current_num_threads() * BLOCKS_PER_THREAD;
    #[cfg(not(feature = "parallel"))]
    let num_live_blocks = BLOCKS_PER_THREAD;
    assert_counting_column_sweep_matches_per_block_reference(num_live_blocks);
}

#[cfg(feature = "parallel")]
#[test]
fn counting_column_sweep_is_worker_count_invariant() {
    for workers in [1, 2, 4, 8, 16] {
        rayon::ThreadPoolBuilder::new()
            .num_threads(workers)
            .build()
            .unwrap()
            .install(|| assert_counting_column_sweep_matches_per_block_reference(257));
    }
}

// -------------------------------------------------------------------------
// Tests that exercise the column-sweep kernels and the OneHotPoly-level
// behaviour defined above.
// -------------------------------------------------------------------------

#[test]
fn single_chunk_onehot_large_block_uses_safe_accumulator_path() {
    type F = Prime24Offset3;
    const D: usize = 64;

    let num_positions_per_block = F::MAX_COMMIT_ACCUMULATIONS + 1;
    let max_coeff = F::from_u128_reduced((1u128 << 24) - 4);
    let dense_ring = CyclotomicRing::from_coefficients([max_coeff; D]);
    let a_matrix = [vec![dense_ring; num_positions_per_block]];
    let bucket: Vec<SparseRingBlockEntry> = (0..num_positions_per_block)
        .map(|pos| block_entry(pos, pos % D))
        .collect();
    let single_chunk_blocks = super::test_helpers::from_buckets(vec![bucket.clone()]);

    let a_flat = FlatMatrix::from_ring_slice(&a_matrix[0]);
    let a_view = a_flat.ring_view::<D>(1, num_positions_per_block).unwrap();

    let single_chunk_views: Vec<&[SparseRingBlockEntry]> = (0..single_chunk_blocks
        .num_live_blocks())
        .map(|i| single_chunk_blocks.block(i))
        .collect();
    let got = column_sweep_ajtai_onehot::<F, D>(
        &a_view,
        &single_chunk_views,
        1,
        num_positions_per_block,
        1,
    );
    let expected = inner_ajtai_wide_single_chunk_tiled::<F, D>(&a_view, &bucket, 1);

    assert_eq!(got.len(), 1);
    assert_eq!(got[0], expected);
}

#[test]
fn multi_chunk_onehot_large_block_uses_safe_accumulator_path() {
    type F = Prime24Offset3;
    const D: usize = 64;

    let coeffs_per_entry: usize = D / 2;
    let num_entries: usize = F::MAX_COMMIT_ACCUMULATIONS / coeffs_per_entry + 1;
    let total_shift_accumulates: usize = num_entries * coeffs_per_entry;
    assert!(total_shift_accumulates > F::MAX_COMMIT_ACCUMULATIONS);

    let n_a = 1;
    let num_digits_inner = 1;
    let num_positions_per_block = num_entries;

    let max_coeff = F::from_u128_reduced((1u128 << 24) - 4);
    let dense_ring = CyclotomicRing::from_coefficients([max_coeff; D]);
    let a_matrix = [vec![dense_ring; num_positions_per_block * num_digits_inner]];

    let nonzero_coeffs: Vec<u16> = (0..coeffs_per_entry as u16).collect();
    let bucket: Vec<SparseRingBlockEntry> = (0..num_positions_per_block)
        .flat_map(|pos| {
            nonzero_coeffs
                .iter()
                .map(move |&coeff| block_entry(pos, usize::from(coeff)))
        })
        .collect();
    let multi_chunk_blocks = super::test_helpers::from_buckets(vec![bucket.clone()]);

    let a_flat = FlatMatrix::from_ring_slice(&a_matrix[0]);
    let a_view = a_flat
        .ring_view::<D>(n_a, num_positions_per_block * num_digits_inner)
        .unwrap();

    let views: Vec<&[SparseRingBlockEntry]> = (0..multi_chunk_blocks.num_live_blocks())
        .map(|i| multi_chunk_blocks.block(i))
        .collect();

    let got = column_sweep_ajtai_onehot::<F, D>(
        &a_view,
        &views,
        n_a,
        num_positions_per_block * num_digits_inner,
        num_digits_inner,
    );
    let reference = inner_ajtai_reference::<F, D>(&a_matrix, &bucket, num_digits_inner);

    assert_eq!(got.len(), 1, "single-block test: expected one output row");
    assert_eq!(
        got[0], reference,
        "column_sweep_ajtai_onehot must agree with the non-wide \
         reference above the field's commitment accumulation cap"
    );
}

#[test]
fn repeated_onehot_position_overflow_splits_entries() {
    type F = Prime24Offset3;
    const D: usize = 64;

    let n_a = 1;
    let num_digits_inner = 1;
    let max_coeff = F::from_u128_reduced((1u128 << 24) - 4);
    let dense_ring = CyclotomicRing::from_coefficients([max_coeff; D]);
    let a_matrix = [vec![dense_ring]];

    let bucket = vec![block_entry(0, 0); F::MAX_COMMIT_ACCUMULATIONS + 1];
    let multi_chunk_blocks = super::test_helpers::from_buckets(vec![bucket.clone()]);
    let views: Vec<&[SparseRingBlockEntry]> = (0..multi_chunk_blocks.num_live_blocks())
        .map(|i| multi_chunk_blocks.block(i))
        .collect();

    let a_flat = FlatMatrix::from_ring_slice(&a_matrix[0]);
    let a_view = a_flat.ring_view::<D>(n_a, num_digits_inner).unwrap();

    let got =
        column_sweep_ajtai_onehot::<F, D>(&a_view, &views, n_a, num_digits_inner, num_digits_inner);
    let reference = inner_ajtai_reference::<F, D>(&a_matrix, &bucket, num_digits_inner);

    assert_eq!(got[0], reference);
}

#[test]
fn batched_single_chunk_onehot_decompose_fold_matches_individual_aggregation() {
    type F = Prime24Offset3;
    const D: usize = 64;

    let num_positions_per_block = 64;
    let mut indices0 = vec![None; 128];
    indices0[0] = Some(1usize);
    indices0[17] = Some(5usize);
    indices0[64] = Some(9usize);
    indices0[91] = Some(33usize);
    let mut indices1 = vec![None; 128];
    indices1[3] = Some(7usize);
    indices1[29] = Some(11usize);
    indices1[64] = Some(19usize);
    indices1[100] = Some(21usize);
    let polys = [
        OneHotPoly::<F>::new(num_positions_per_block, indices0).unwrap(),
        OneHotPoly::<F>::new(num_positions_per_block, indices1).unwrap(),
    ];
    let challenges = vec![
        SparseChallenge {
            positions: vec![0, 5].into(),
            coeffs: vec![1, -1].into(),
        },
        SparseChallenge {
            positions: vec![2, 7].into(),
            coeffs: vec![1, 1].into(),
        },
        SparseChallenge {
            positions: vec![4, 11].into(),
            coeffs: vec![-1, 2].into(),
        },
        SparseChallenge {
            positions: vec![8, 13].into(),
            coeffs: vec![1, -2].into(),
        },
    ];

    let expected = aggregate_witnesses::<D>(
        &polys
            .iter()
            .zip(challenges.chunks(2))
            .map(|(poly, poly_challenges)| {
                poly.decompose_fold::<D>(poly_challenges, num_positions_per_block, 1, 0)
                    .unwrap()
            })
            .collect::<Vec<_>>(),
    );
    let poly_refs: Vec<&OneHotPoly<F>> = polys.iter().collect();
    let got = OneHotPoly::<F>::decompose_fold_batched_onehot::<D>(
        &poly_refs,
        &challenges,
        2,
        num_positions_per_block,
        1,
    )
    .expect("onehot batched path should apply");

    assert_eq!(got, expected);
}

#[test]
fn single_chunk_onehot_evaluate_and_fold_matches_factorized_eval() {
    type F = Prime24Offset3;
    const D: usize = 64;

    let poly =
        OneHotPoly::<F>::new(64, vec![Some(1usize), None, Some(9usize), Some(17usize)]).unwrap();
    let num_positions_per_block = 2usize;
    let position_weights = vec![F::from_u64(3), F::from_u64(5)];
    let live_block_weights = vec![F::from_u64(7), F::from_u64(11)];

    let (eval, folded) = poly
        .evaluate_and_fold::<D>(
            &live_block_weights,
            &position_weights,
            num_positions_per_block,
        )
        .unwrap();
    let expected_folded = poly
        .fold_blocks::<D>(&position_weights, num_positions_per_block)
        .unwrap();
    assert_eq!(folded, expected_folded);

    let full_scalars: Vec<F> = live_block_weights
        .iter()
        .flat_map(|outer| position_weights.iter().map(move |inner| *outer * *inner))
        .collect();
    let expected_eval = super::test_helpers::evaluate_ring_onehot::<F, D, _>(&poly, &full_scalars);
    assert_eq!(eval, expected_eval);
}

#[test]
fn single_chunk_onehot_ring_fold_matches_dense_materialization() {
    type F = Prime24Offset3;
    const D: usize = 8;

    let poly =
        OneHotPoly::<F>::new(16, vec![Some(1usize), None, Some(13usize), Some(7usize)]).unwrap();
    let dense = materialize_onehot_as_dense::<F, D, _>(&poly);
    let num_positions_per_block = 4usize;
    let position_weights = vec![
        test_ring_scalar::<F, D>(10),
        test_ring_scalar::<F, D>(40),
        test_ring_scalar::<F, D>(90),
        test_ring_scalar::<F, D>(120),
    ];

    assert_eq!(
        poly.fold_blocks_ring(&position_weights, num_positions_per_block),
        dense
            .fold_blocks_ring(&position_weights, num_positions_per_block)
            .unwrap()
    );
}

#[test]
fn onehot_ring_fold_matches_dense_for_partial_final_slice() {
    type F = Prime24Offset3;
    const D: usize = 8;

    let poly =
        OneHotPoly::<F>::new(16, vec![Some(1usize), None, Some(13usize), Some(7usize)]).unwrap();
    let dense = materialize_onehot_as_dense::<F, D, _>(&poly);
    let num_positions_per_block = 16usize;
    let position_weights = (0..num_positions_per_block)
        .map(|index| test_ring_scalar::<F, D>(10 + index as u64))
        .collect::<Vec<_>>();

    assert_eq!(
        poly.fold_blocks_ring(&position_weights, num_positions_per_block),
        dense
            .fold_blocks_ring(&position_weights, num_positions_per_block)
            .unwrap()
    );
}

#[test]
fn multi_chunk_onehot_evaluate_and_fold_matches_factorized_eval() {
    type F = Prime24Offset3;
    const D: usize = 64;

    let poly = OneHotPoly::<F>::new(
        32,
        vec![
            Some(1usize),
            None,
            Some(7usize),
            Some(12usize),
            None,
            Some(3usize),
            None,
            Some(15usize),
        ],
    )
    .unwrap();
    let num_positions_per_block = 2usize;
    let position_weights = vec![F::from_u64(2), F::from_u64(4)];
    let live_block_weights = vec![F::from_u64(3), F::from_u64(5)];

    let (eval, folded) = poly
        .evaluate_and_fold::<D>(
            &live_block_weights,
            &position_weights,
            num_positions_per_block,
        )
        .unwrap();
    let expected_folded = poly
        .fold_blocks::<D>(&position_weights, num_positions_per_block)
        .unwrap();
    assert_eq!(folded, expected_folded);

    let full_scalars: Vec<F> = live_block_weights
        .iter()
        .flat_map(|outer| position_weights.iter().map(move |inner| *outer * *inner))
        .collect();
    let expected_eval = super::test_helpers::evaluate_ring_onehot::<F, D, _>(&poly, &full_scalars);
    assert_eq!(eval, expected_eval);
}

#[test]
fn multi_chunk_onehot_ring_fold_matches_dense_materialization() {
    type F = Prime24Offset3;
    const D: usize = 16;

    let poly = OneHotPoly::<F>::new(
        4,
        vec![
            Some(0usize),
            Some(3usize),
            None,
            Some(2usize),
            Some(1usize),
            None,
            Some(3usize),
            Some(0usize),
            None,
            Some(2usize),
            Some(1usize),
            None,
            Some(3usize),
            None,
            Some(0usize),
            Some(2usize),
        ],
    )
    .unwrap();
    let dense = materialize_onehot_as_dense::<F, D, _>(&poly);
    let num_positions_per_block = 2usize;
    let position_weights = vec![test_ring_scalar::<F, D>(7), test_ring_scalar::<F, D>(80)];

    assert_eq!(
        poly.fold_blocks_ring(&position_weights, num_positions_per_block),
        dense
            .fold_blocks_ring(&position_weights, num_positions_per_block)
            .unwrap()
    );
}

mod decompose_fold;
mod layout_and_ownership;
mod optimized_commit;

#[test]
fn base_fold_rejects_zero_block_width() {
    let poly = OneHotPoly::<Prime24Offset3>::new(64, vec![Some(1usize)]).unwrap();
    assert!(matches!(
        poly.fold_blocks::<64>(&[], 0),
        Err(AkitaError::InvalidInput(_))
    ));
}
