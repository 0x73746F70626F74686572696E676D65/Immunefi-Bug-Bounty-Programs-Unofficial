use super::poly::DensePoly;
use crate::commitment::CommitmentSource;
use crate::opaque::RootPolyMeta;
use akita_algebra::CyclotomicRing;
use akita_error::AkitaError;
use jolt_field::Prime128OffsetA7F7 as F;
use jolt_field::{CanonicalEncoding, Ring, Zero};

#[test]
fn chunked_fold_matches_windowed_reference_and_global() {
    use akita_challenges::SparseChallenge;

    const D: usize = 64;
    const POSITIONS: usize = 2;
    let poly =
        DensePoly::<F>::from_ring_coeffs((0..8).map(|index| ring::<D>(index * 10)).collect())
            .unwrap();
    let challenges = (0..4)
        .map(|block| SparseChallenge {
            positions: vec![(block * 2) as u32, (block * 2 + 1) as u32].into(),
            coeffs: vec![1, -1].into(),
        })
        .collect::<Vec<_>>();
    let global = poly
        .decompose_fold::<D>(&challenges, POSITIONS, 2, 4)
        .unwrap();

    for chunk_count in [2, 4, 8] {
        let ranges = akita_params::dyadic_block_ranges(challenges.len(), chunk_count).unwrap();
        let chunks = poly
            .decompose_fold_chunked::<D>(&challenges, &ranges, POSITIONS, 2, 4)
            .unwrap();
        assert_eq!(chunks.len(), chunk_count);
        for (range, chunk) in ranges.iter().zip(&chunks) {
            let window = challenges
                .iter()
                .enumerate()
                .map(|(block, challenge)| {
                    if range.contains(&block) {
                        challenge.clone()
                    } else {
                        SparseChallenge {
                            positions: Vec::new().into(),
                            coeffs: Vec::new().into(),
                        }
                    }
                })
                .collect::<Vec<_>>();
            let expected = poly.decompose_fold::<D>(&window, POSITIONS, 2, 4).unwrap();
            assert_eq!(
                chunk.centered_coeffs_flat(),
                expected.centered_coeffs_flat()
            );
        }
        let combined = crate::opaque::aggregate_decompose_fold_witnesses::<D>(
            chunks
                .iter()
                .map(|chunk| Ok::<_, AkitaError>(chunk.clone())),
        )
        .unwrap();
        assert_eq!(
            combined.centered_coeffs_flat(),
            global.centered_coeffs_flat()
        );
    }
}

fn ring<const D: usize>(offset: u64) -> CyclotomicRing<F, D> {
    CyclotomicRing::from_coefficients(std::array::from_fn(|idx| {
        F::from_u64(offset + idx as u64 + 1)
    }))
}

#[test]
fn ring_fold_matches_dense_multiplication_reference() {
    const D: usize = 8;
    let coeffs = (0..2).map(|idx| ring::<D>(10 * idx)).collect::<Vec<_>>();
    let poly = DensePoly::<F>::from_ring_coeffs(coeffs.clone()).unwrap();
    let scalars = vec![
        ring::<D>(100),
        ring::<D>(200),
        ring::<D>(300),
        ring::<D>(400),
    ];
    let got = poly.fold_blocks_ring(&scalars, 4).unwrap();
    let expected = coeffs
        .chunks(4)
        .map(|block| {
            block
                .iter()
                .zip(scalars.iter())
                .fold(CyclotomicRing::<F, D>::zero(), |acc, (coeff, scalar)| {
                    acc + (*coeff * *scalar)
                })
        })
        .collect::<Vec<_>>();

    assert_eq!(got, expected);
}

#[test]
fn dense_constructor_reuses_owned_evaluation_buffer() {
    let evals = (0..2048).map(F::from_u64).collect::<Vec<_>>();
    let allocation = evals.as_ptr();
    let poly = DensePoly::<F>::from_field_evals(11, evals).unwrap();
    assert_eq!(poly.field_coeffs().as_ptr(), allocation);
}

#[test]
fn dense_source_has_exact_views_across_supported_ring_dimensions() {
    let evals = (1..=32).map(F::from_u64).collect::<Vec<_>>();
    let poly = DensePoly::<F>::from_field_evals(5, evals.clone()).unwrap();

    fn assert_view<const D: usize>(poly: &DensePoly<F>, evals: &[F]) {
        let rings = poly.ring_coeffs::<D>().expect("supported dense view");
        let flat = rings
            .iter()
            .flat_map(|ring| ring.coefficients().iter().copied())
            .collect::<Vec<_>>();
        assert_eq!(&flat[..evals.len()], evals);
        assert!(flat[evals.len()..].iter().all(|value| *value == F::zero()));
    }

    assert_view::<64>(&poly, &evals);
    assert_view::<128>(&poly, &evals);
    assert_view::<256>(&poly, &evals);
    assert_view::<512>(&poly, &evals);
    assert_view::<1024>(&poly, &evals);
}

#[test]
fn dense_ring_constructor_rejects_empty_and_irregular_sources() {
    const D: usize = 512;
    // 96 rings previously exposed only the first 32 of the supplied rings.
    for num_rings in [0, 3, 96] {
        let result =
            DensePoly::<F>::from_ring_coeffs(vec![CyclotomicRing::<F, D>::zero(); num_rings]);
        assert!(matches!(result, Err(AkitaError::InvalidInput(_))));
    }
    let zero_degree = DensePoly::<F>::from_ring_coeffs(vec![CyclotomicRing::<F, 0>::zero()]);
    assert!(matches!(zero_degree, Err(AkitaError::InvalidInput(_))));
    let odd_degree = DensePoly::<F>::from_ring_coeffs(vec![CyclotomicRing::<F, 3>::zero(); 2]);
    assert!(matches!(odd_degree, Err(AkitaError::InvalidInput(_))));
}

#[test]
fn dense_ring_constructor_preserves_the_entire_commitment_source_and_bound_scan() {
    const D: usize = 512;
    let modulus = (-F::from_u64(1)).to_u128_checked().unwrap() + 1;
    // Exercise both small-i8 and full-field storage, including physical padding.
    for num_rings in [1, 32, 64] {
        for reach in [127u64, 128] {
            let mut evals = (0..num_rings * D)
                .map(|idx| F::from_u64((idx % 32) as u64))
                .collect::<Vec<_>>();
            evals[num_rings * D - 2] = -F::from_u64(reach);
            evals[num_rings * D - 1] = F::from_u64(reach);
            let rings = evals
                .chunks_exact(D)
                .map(|chunk| CyclotomicRing::<F, D>::from_coefficients(chunk.try_into().unwrap()))
                .collect::<Vec<_>>();
            let poly = DensePoly::<F>::from_ring_coeffs(rings.clone()).unwrap();

            assert_eq!(1usize << RootPolyMeta::num_vars(&poly), evals.len());
            assert_eq!(&poly.field_coeffs()[..evals.len()], evals);
            assert_eq!(poly.ring_coeffs::<D>().unwrap(), rings);
            let descriptor = <DensePoly<F> as CommitmentSource<F>>::descriptor(&poly).unwrap();
            assert_eq!(descriptor.num_vars(), RootPolyMeta::num_vars(&poly));
            assert_eq!(descriptor.live_coefficient_len(), evals.len());
            assert_eq!(
                <DensePoly<F> as CommitmentSource<F>>::committed_centered_reach(
                    &poly,
                    modulus,
                    modulus / 2,
                )
                .unwrap(),
                (u128::from(reach), u128::from(reach)),
            );
            assert_eq!(
                poly,
                DensePoly::from_field_evals(RootPolyMeta::num_vars(&poly), evals).unwrap(),
            );
        }
    }
}

#[test]
fn dense_field_constructor_rejects_unrepresentable_arities() {
    for num_vars in [usize::BITS as usize, usize::MAX] {
        let result = DensePoly::<F>::from_field_evals(num_vars, vec![F::zero()]);
        assert!(matches!(result, Err(AkitaError::InvalidInput(_))));
    }
}

#[cfg(target_pointer_width = "64")]
#[test]
fn dense_field_constructor_rejects_arity_that_truncates_to_a_valid_shift() {
    let result = DensePoly::<F>::from_field_evals((1usize << 32) + 14, vec![F::zero(); 1 << 14]);
    assert!(matches!(result, Err(AkitaError::InvalidInput(_))));
}

#[test]
fn batch_fold_rejects_mixed_extents_and_count_mismatch() {
    use crate::opaque::{
        CpuBackend, DecomposeFoldBatchPlan, OpeningBatchKernel, RootOpeningSource,
    };
    use akita_challenges::SparseChallenge;

    const D: usize = 64;
    let polys = [
        DensePoly::from_field_evals(6, vec![F::from_u64(1); 1 << 6]).unwrap(),
        DensePoly::from_field_evals(7, vec![F::from_u64(1); 1 << 7]).unwrap(),
    ];
    let challenges = vec![
        SparseChallenge {
            positions: vec![0].into(),
            coeffs: vec![1].into(),
        };
        2
    ];
    let backend = CpuBackend::<F, F>::for_arithmetic_tests();
    let run = |refs: &[&DensePoly<F>]| {
        OpeningBatchKernel::decompose_fold_batch(
            &backend,
            None,
            <DensePoly<F> as RootOpeningSource<F, D>>::opening_batch(refs).unwrap(),
            DecomposeFoldBatchPlan::Sparse {
                challenges: &challenges,
                num_positions_per_block: 1,
                num_digits: 1,
                log_basis: 1,
            },
        )
    };

    assert!(matches!(
        run(&[&polys[0], &polys[1]]),
        Err(AkitaError::InvalidInput(_))
    ));
    assert!(matches!(
        run(&[&polys[0], &polys[0], &polys[0]]),
        Err(AkitaError::InvalidInput(_))
    ));
}

#[test]
fn scalar_fold_rejects_short_and_excess_challenges() {
    use crate::opaque::{CpuBackend, DecomposeFoldPlan, OpeningFoldKernel, RootOpeningSource};
    use akita_challenges::SparseChallenge;

    const D: usize = 8;
    // Two rings at one position per block give two live blocks.
    let poly = DensePoly::from_ring_coeffs(vec![ring::<D>(0), ring::<D>(10)]).unwrap();
    let challenge = SparseChallenge {
        positions: vec![0].into(),
        coeffs: vec![1].into(),
    };
    let backend = CpuBackend::<F, F>::for_arithmetic_tests();
    let run = |count: usize| {
        let challenges = vec![challenge.clone(); count];
        OpeningFoldKernel::decompose_fold(
            &backend,
            None,
            <DensePoly<F> as RootOpeningSource<F, D>>::opening_view(&poly).unwrap(),
            DecomposeFoldPlan {
                challenges: &challenges,
                num_positions_per_block: 1,
                num_digits: 1,
                log_basis: 6,
            },
        )
    };

    assert!(run(2).is_ok());
    for count in [0, 1, 3] {
        assert!(
            matches!(
                run(count),
                Err(AkitaError::InvalidSize { expected: 2, actual }) if actual == count
            ),
            "{count} challenges for two live blocks must be rejected"
        );
    }
}

// A +1 monomial challenge must leave every single balanced digit unchanged.
// The expectation is the input integer itself, independent of decomposition.
#[test]
fn single_digit_fold_preserves_signed_i8_i16_boundaries() {
    use akita_challenges::SparseChallenge;
    use jolt_field::Prime64Offset59;
    const D: usize = 128;
    let challenge = SparseChallenge {
        positions: vec![0].into(),
        coeffs: vec![1].into(),
    };
    let mut mismatches = Vec::new();
    for log_basis in [8_u32, 9] {
        let half = 1_i64 << (log_basis - 1);
        for value in [127_i64, 128, 255, -128, -129, -256] {
            if !(-half..half).contains(&value) {
                continue; // Only admissible balanced digits belong in this oracle.
            }
            let mut coefficients = vec![Prime64Offset59::zero(); D];
            coefficients[0] = Prime64Offset59::from_i64(value);
            let poly = DensePoly::from_field_evals(7, coefficients).unwrap();
            let actual = poly
                .decompose_fold::<D>(std::slice::from_ref(&challenge), 1, 1, log_basis)
                .unwrap();
            let mut expected = vec![0_i32; D];
            expected[0] = value as i32;
            if actual.centered_coeffs_flat() != expected {
                mismatches.push((log_basis, value, actual.centered_coeffs_flat()[0]));
            }
        }
    }
    assert!(
        mismatches.is_empty(),
        "(basis, expected, actual): {mismatches:?}"
    );
}

#[test]
fn fold_operations_reject_invalid_ring_views() {
    let poly = DensePoly::<F>::from_field_evals(0, vec![F::zero()]).unwrap();
    assert!(matches!(
        poly.fold_blocks::<0>(&[], 1),
        Err(AkitaError::InvalidInput(_))
    ));
    assert!(matches!(
        poly.fold_blocks_ring::<0>(&[], 1),
        Err(AkitaError::InvalidInput(_))
    ));
    assert!(matches!(
        poly.decompose_fold::<0>(&[], 1, 1, 1),
        Err(AkitaError::InvalidInput(_))
    ));
    assert!(matches!(
        poly.decompose_fold_chunked::<0>(&[], &[], 1, 1, 1),
        Err(AkitaError::InvalidInput(_))
    ));
}

mod batch_only {
    use super::*;
    use crate::commitment::{
        AvailablePolynomialTypes, CommitSourceDescriptor, PolynomialRepresentation,
        PolynomialTypeSelection,
    };
    use crate::opaque::*;
    use crate::sources::poly::SourceCoefficients;

    struct BatchOnlySource(DensePoly<F>);

    impl RootPolyMeta<F> for BatchOnlySource {
        fn num_vars(&self) -> usize {
            RootPolyMeta::num_vars(&self.0)
        }
    }
    impl<const D: usize> RootPolyShape<F, D> for BatchOnlySource {
        fn num_ring_elems(&self) -> usize {
            RootPolyShape::<F, D>::num_ring_elems(&self.0)
        }
    }
    impl<const D: usize> RootOpeningSource<F, D> for BatchOnlySource {
        type OpeningView<'a> = ();
        type OpeningBatchView<'a> = Vec<&'a DensePoly<F>>;
        fn opening_view(&self) -> Result<(), AkitaError> {
            Err(AkitaError::InvalidInput("batch-only source".into()))
        }
        fn opening_batch<'a>(polys: &'a [&'a Self]) -> Result<Vec<&'a DensePoly<F>>, AkitaError> {
            Ok(polys.iter().map(|poly| &poly.0).collect())
        }
    }
    impl SourceCoefficients<F> for BatchOnlySource {
        fn source_coefficients(&self) -> Result<std::borrow::Cow<'_, [F]>, AkitaError> {
            self.0.source_coefficients()
        }
    }
    impl CommitmentSource<F> for BatchOnlySource {
        fn descriptor(&self) -> Result<CommitSourceDescriptor, AkitaError> {
            self.0.descriptor()
        }
        fn committed_centered_reach(
            &self,
            modulus: u128,
            threshold: u128,
        ) -> Result<(u128, u128), AkitaError> {
            self.0.committed_centered_reach(modulus, threshold)
        }
        fn available_polynomial_types(
            &self,
            plan: &CommitInnerPlan,
        ) -> Result<AvailablePolynomialTypes, AkitaError> {
            self.0.available_polynomial_types(plan)
        }
        fn represent_as(
            &self,
            selected: PolynomialTypeSelection,
            plan: &CommitInnerPlan,
        ) -> Result<PolynomialRepresentation<'_, F>, AkitaError> {
            self.0.represent_as(selected, plan)
        }
    }
    impl<const D: usize> OpeningBatchKernel<Vec<&DensePoly<F>>, F, D> for CpuBackend<F, F> {
        fn evaluate_and_fold_batch(
            &self,
            prepared: Option<&Self::PreparedSetup>,
            source: Vec<&DensePoly<F>>,
            plan: OpeningFoldPlan<'_, F>,
        ) -> Result<Vec<OpeningFoldOutput<F, D>>, AkitaError> {
            self.evaluate_and_fold_batch(
                prepared,
                <DensePoly<F> as RootOpeningSource<F, D>>::opening_batch(&source)?,
                plan,
            )
        }
        fn decompose_fold_batch(
            &self,
            prepared: Option<&Self::PreparedSetup>,
            source: Vec<&DensePoly<F>>,
            plan: DecomposeFoldBatchPlan<'_>,
        ) -> Result<CpuFoldResponses, AkitaError> {
            self.decompose_fold_batch(
                prepared,
                <DensePoly<F> as RootOpeningSource<F, D>>::opening_batch(&source)?,
                plan,
            )
        }
    }
    impl<const D: usize> SubringCoefficientPackingBatchKernel<Vec<&DensePoly<F>>, F, F, D>
        for CpuBackend<F, F>
    {
        fn coefficient_packing_partials_batch(
            &self,
            prepared: Option<&Self::PreparedSetup>,
            source: Vec<&DensePoly<F>>,
            plan: SubringCoefficientPackingPlan<'_, F>,
        ) -> Result<Vec<SubringCoefficientPackingPartials<F>>, AkitaError> {
            self.coefficient_packing_partials_batch(
                prepared,
                <DensePoly<F> as RootOpeningSource<F, D>>::opening_batch(&source)?,
                plan,
            )
        }
    }

    #[test]
    fn import_source_admits_batch_only_opening_kernels() {
        let setup = crate::AkitaProverSetup::<F>::generate_with_capacity(
            9,
            1,
            akita_params::SetupMatrixCapacity {
                num_field_elements: 4096,
            },
        )
        .unwrap();
        let backend = CpuBackend::<F, F>::new(setup.expanded.clone()).unwrap();
        let poly = DensePoly::from_field_evals(9, vec![F::from_u64(1); 512]).unwrap();
        // No OpeningFoldKernel<()> implementation exists for this source's singleton view.
        assert!(backend.import_source(vec![BatchOnlySource(poly)]).is_ok());
    }
}
