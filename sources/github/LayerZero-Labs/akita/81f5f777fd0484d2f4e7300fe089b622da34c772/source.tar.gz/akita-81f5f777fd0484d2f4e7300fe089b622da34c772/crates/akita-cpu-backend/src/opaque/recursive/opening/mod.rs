//! Prover-side extension-opening-reduction sumcheck instance.
//!
//! Generic sumcheck proof containers and transcript drivers live in
//! `akita-sumcheck`. This module owns the Akita-specific EOR prover state over
//! witness and factor tables.

use crate::arithmetic::extension_opening_reduction::{
    num_rounds_from_table_len, reduction_table_len, validate_reduction_tables,
};
use akita_algebra::poly::fold_evals_in_place;

use akita_error::AkitaError;
use akita_params::EXTENSION_OPENING_REDUCTION_DEGREE;
use akita_sumcheck::SumcheckInstanceProver;
use jolt_field::{Field, Zero};
use jolt_field::{Fold, Unreduced};
#[cfg(feature = "parallel")]
use rayon::prelude::*;

/// Degree-two round-message accumulator that honors a field's delayed-reduction
/// exactness contract (`Unreduced::SUM_IS_EXACT`).
///
/// Every extension-opening reduction round needs two batch sums: the constant
/// coefficient `Σ c0·c1` and the quadratic coefficient `Σ q0·q1`. This trait
/// abstracts how those products are summed so the dense and fused-fold paths
/// can both pick the right policy from one place:
///
/// - [`DelayedDeg2`] sums the wide `E::Product` products and reduces once
///   per round. This is only sound when `SUM_IS_EXACT` is set,
///   i.e. the field's accumulator has been proven not to wrap for these batch
///   sizes (e.g. `FpExt4<Fp32>`, `FpExt2<Fp64>`).
/// - [`DirectDeg2`] reduces every product immediately via `Mul`, so the summed
///   coefficient is byte-identical to per-term reduction. This is the
///   contract-safe path for fields that leave `SUM_IS_EXACT` at
///   its conservative `false` default.
trait Deg2RoundAccum<E: Field + Unreduced>: Sized + Send {
    /// Empty accumulator (both coefficients zero).
    fn zero() -> Self;
    /// Accumulate `lhs·rhs` into the constant coefficient.
    fn add_constant_product(&mut self, lhs: E, rhs: E);
    /// Accumulate `lhs·rhs` into the quadratic coefficient.
    fn add_quadratic_product(&mut self, lhs: E, rhs: E);
    /// Combine two partial accumulators (for parallel reduction).
    #[cfg(feature = "parallel")]
    fn merge(self, other: Self) -> Self;
    /// Reduce to the `(constant, quadratic)` round coefficients.
    fn finish(self) -> (E, E);
}

/// Delayed-reduction accumulator. Sound only when the field's
/// `SUM_IS_EXACT` is `true`.
struct DelayedDeg2<E: Unreduced> {
    constant: E::Product,
    quadratic: E::Product,
}

impl<E: Field + Unreduced> Deg2RoundAccum<E> for DelayedDeg2<E> {
    #[inline]
    fn zero() -> Self {
        Self {
            constant: E::Product::zero(),
            quadratic: E::Product::zero(),
        }
    }
    #[inline]
    fn add_constant_product(&mut self, lhs: E, rhs: E) {
        self.constant += lhs.mul_unreduced(rhs);
    }
    #[inline]
    fn add_quadratic_product(&mut self, lhs: E, rhs: E) {
        self.quadratic += lhs.mul_unreduced(rhs);
    }
    #[cfg(feature = "parallel")]
    #[inline]
    fn merge(self, other: Self) -> Self {
        Self {
            constant: self.constant + other.constant,
            quadratic: self.quadratic + other.quadratic,
        }
    }
    #[inline]
    fn finish(self) -> (E, E) {
        (
            E::reduce_product(self.constant),
            E::reduce_product(self.quadratic),
        )
    }
}

/// Per-term reduction accumulator: every product is reduced immediately, so the
/// summed coefficient is byte-identical to per-term `Mul`. Contract-safe
/// fallback for fields with `SUM_IS_EXACT == false`.
struct DirectDeg2<E> {
    constant: E,
    quadratic: E,
}

impl<E: Field + Unreduced> Deg2RoundAccum<E> for DirectDeg2<E> {
    #[inline]
    fn zero() -> Self {
        Self {
            constant: E::zero(),
            quadratic: E::zero(),
        }
    }
    #[inline]
    fn add_constant_product(&mut self, lhs: E, rhs: E) {
        self.constant += lhs * rhs;
    }
    #[inline]
    fn add_quadratic_product(&mut self, lhs: E, rhs: E) {
        self.quadratic += lhs * rhs;
    }
    #[cfg(feature = "parallel")]
    #[inline]
    fn merge(self, other: Self) -> Self {
        Self {
            constant: self.constant + other.constant,
            quadratic: self.quadratic + other.quadratic,
        }
    }
    #[inline]
    fn finish(self) -> (E, E) {
        (self.constant, self.quadratic)
    }
}

mod dense;
mod prover;
mod tables;
mod term;

pub use prover::ExtensionOpeningReductionProver;
pub use tables::ExtensionOpeningReductionGroup;
pub use term::ExtensionOpeningReductionTerm;

pub(crate) use dense::accumulate_dense_round;
pub(in crate::opaque::recursive::opening) use dense::{
    fused_fold_group_head_and_accumulate, fused_fold_witness_and_accumulate,
};
