use crate::opaque::RecursiveWitnessFlat;
use akita_error::{checked, AkitaError};
use akita_types::pack_tensor_base_lift_i8_digits;
use jolt_field::{ExtField, Field};

fn tensor_extension_split<F, E>(context: &'static str) -> Result<(usize, usize), AkitaError>
where
    F: Field,
    E: ExtField<F>,
{
    let split_bits = E::DEGREE.trailing_zeros() as usize;
    let width = checked::pow2(split_bits)
        .ok_or_else(|| AkitaError::InvalidInput("tensor extension width overflow".to_string()))?;
    if width != E::DEGREE || !E::DEGREE.is_power_of_two() {
        return Err(AkitaError::InvalidInput(format!(
            "tensor extension {context} requires power-of-two extension degree"
        )));
    }
    Ok((split_bits, width))
}

/// Pack a logical recursive digit witness into the canonical tensor extension
/// ring-subfield layout.
pub(crate) fn tensor_pack_recursive_witness<F, E, const D: usize>(
    logical_w: &RecursiveWitnessFlat,
) -> Result<RecursiveWitnessFlat, AkitaError>
where
    F: Field,
    E: ExtField<F>,
{
    let (_split_bits, width) = tensor_extension_split::<F, E>("packing")?;
    let packed = pack_tensor_base_lift_i8_digits::<D>(logical_w.digits(), E::DEGREE, width)?;
    RecursiveWitnessFlat::from_tensor_packed_i8_digits(packed, logical_w.live_coeff_len())?
        .align_for_commitment_ring_dim(D)
}

#[cfg(test)]
mod tests {
    use super::*;
    use jolt_field::{FpExt4, Prime32Offset99};

    #[test]
    fn recursive_tensor_pack_rejects_non_divisible_digit_count() {
        type F = Prime32Offset99;
        type E = FpExt4<F>;
        const D: usize = 32;
        let witness = RecursiveWitnessFlat::from_i8_digits(vec![1, 2, 3]);

        let err = tensor_pack_recursive_witness::<F, E, D>(&witness).unwrap_err();
        assert!(matches!(
            err,
            AkitaError::InvalidSize {
                expected: 4,
                actual: 3
            }
        ));
    }

    #[test]
    fn recursive_tensor_pack_preserves_logical_live_length() {
        type F = Prime32Offset99;
        type E = FpExt4<F>;
        const D: usize = 128;
        let logical_len = D + <E as ExtField<F>>::DEGREE;
        let witness = RecursiveWitnessFlat::from_i8_digits(vec![1; logical_len]);

        let packed = tensor_pack_recursive_witness::<F, E, D>(&witness).unwrap();

        assert_eq!(packed.live_coeff_len(), logical_len);
        assert_eq!(packed.to_i8_digits().len(), 2 * D);
        assert_eq!(packed.committed_coeff_len().unwrap(), 2 * D);
    }

    #[test]
    fn tensor_packed_extrema_in_physical_tail_are_admitted() {
        type F = Prime32Offset99;
        type E = FpExt4<F>;
        const D: usize = 128;
        let logical_len = D + <E as ExtField<F>>::DEGREE;
        let mut digits = vec![0; logical_len];
        digits[D + 1] = 3;
        let witness = RecursiveWitnessFlat::from_i8_digits(digits);
        let packed = tensor_pack_recursive_witness::<F, E, D>(&witness).unwrap();
        let stored = packed.to_i8_digits();
        assert!(stored[logical_len..].contains(&3));
        let (bytes, width, negative, positive) = packed.packed_representation_parts();

        crate::commitment::ShortNormRepresentation::new(
            bytes,
            packed.live_coeff_len(),
            stored.len(),
            packed.committed_coeff_len().unwrap(),
            width,
            negative,
            positive,
        )
        .unwrap();
    }
}
