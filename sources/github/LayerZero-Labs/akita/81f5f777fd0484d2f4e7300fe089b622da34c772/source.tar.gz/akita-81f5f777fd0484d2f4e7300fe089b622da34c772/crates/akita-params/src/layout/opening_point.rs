//! Ring-native opening point for the Akita protocol.

use akita_algebra::{eq_poly::EqPolynomial, CyclotomicRing};
use akita_error::AkitaError;
use akita_serialization::DEFAULT_MAX_SEQUENCE_LEN;
use jolt_field::Field;

/// Polynomial basis mode for the evaluation relation.
///
/// Determines how the polynomial's values are interpreted during an opening
/// proof. The commitment itself is basis-agnostic; the basis only affects
/// the tensor-product weights used in `prove` and `verify`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BasisMode {
    /// Evaluations over the boolean hypercube.
    ///
    /// The weight vector is `⊗ᵢ (1 − xᵢ, xᵢ)` (multilinear Lagrange basis).
    /// Use when the committed values are `f(b)` for `b ∈ {0,1}^n`.
    Lagrange,

    /// Coefficients of multilinear monomials.
    ///
    /// The weight vector is `⊗ᵢ (1, xᵢ)`.
    /// Use when the committed values are the coefficients `c_S` such that
    /// `f(x) = Σ_S c_S · ∏_{i ∈ S} x_i`.
    Monomial,
}

/// Ring-native opening point storing field scalars.
///
/// Contains the two exact factors of the physical source opening:
/// - `position_weights`: position weights of length `M`.
/// - `live_block_weights`: the live prefix of `B` block weights.
///
/// These are raw field scalars, not ring elements — they originate from
/// basis weight evaluations (Lagrange or monomial) and are always constant
/// (scalar) ring elements when embedded into the ring.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RingOpeningPoint<F: Field> {
    /// Position weights, with exactly one entry per block position.
    pub position_weights: Vec<F>,
    /// Block-select weights, truncated to the exact live block prefix.
    pub live_block_weights: Vec<F>,
}

/// Multilinear Lagrange weights: `⊗ᵢ (1 − xᵢ, xᵢ)`.
///
/// # Errors
///
/// Returns an error if the implied weight table would overflow or exceed the
/// verifier sequence bound.
pub fn lagrange_weights<F: Field>(point: &[F]) -> Result<Vec<F>, AkitaError> {
    basis_weight_len(point.len())?;
    EqPolynomial::evals(point)
}

/// Multilinear monomial weights: `⊗ᵢ (1, xᵢ)`.
///
/// The j-th entry is `∏_{i ∈ bits(j)} point[i]`.
///
/// # Errors
///
/// Returns an error if the implied weight table would overflow or exceed the
/// verifier sequence bound.
pub fn monomial_weights<F: Field>(point: &[F]) -> Result<Vec<F>, AkitaError> {
    let len = basis_weight_len(point.len())?;
    let mut weights = vec![F::zero(); len];
    weights[0] = F::one();
    for (level, &p) in point.iter().enumerate() {
        let k = 1usize << level;
        for i in (0..k).rev() {
            weights[i + k] = weights[i] * p;
        }
    }
    Ok(weights)
}

/// Return tensor-product weights for one opening point under the chosen basis.
pub fn basis_weights<F: Field>(point: &[F], basis: BasisMode) -> Result<Vec<F>, AkitaError> {
    match basis {
        BasisMode::Lagrange => lagrange_weights(point),
        BasisMode::Monomial => monomial_weights(point),
    }
}

/// Return the first `live_len` tensor-product weights without retaining the
/// padded Boolean suffix.
pub fn basis_weights_prefix<F: Field>(
    point: &[F],
    basis: BasisMode,
    live_len: usize,
) -> Result<Vec<F>, AkitaError> {
    let capacity = basis_weight_len(point.len())?;
    if live_len == 0 || live_len > capacity {
        return Err(AkitaError::InvalidSize {
            expected: capacity,
            actual: live_len,
        });
    }
    match basis {
        BasisMode::Lagrange => EqPolynomial::evals_prefix(point, live_len),
        BasisMode::Monomial => (0..live_len)
            .map(|index| {
                Ok(point
                    .iter()
                    .enumerate()
                    .filter(|(bit, _)| index & (1usize << bit) != 0)
                    .fold(F::one(), |acc, (_, &coordinate)| acc * coordinate))
            })
            .collect(),
    }
}

fn basis_weight_len(num_vars: usize) -> Result<usize, AkitaError> {
    let shift = u32::try_from(num_vars).map_err(|_| AkitaError::InvalidSize {
        expected: usize::BITS as usize,
        actual: num_vars,
    })?;
    let len = 1usize
        .checked_shl(shift)
        .ok_or_else(|| AkitaError::InvalidInput("basis weight dimension overflow".to_string()))?;
    if len > DEFAULT_MAX_SEQUENCE_LEN {
        return Err(AkitaError::InvalidSize {
            expected: DEFAULT_MAX_SEQUENCE_LEN,
            actual: len,
        });
    }
    Ok(len)
}

/// Boolean opening-domain capacity for an exact compact physical source.
pub fn opening_domain_len(source_len: usize) -> Result<usize, AkitaError> {
    if source_len == 0 {
        return Err(AkitaError::InvalidSetup(
            "opening source length must be positive".to_string(),
        ));
    }
    source_len
        .checked_next_power_of_two()
        .ok_or_else(|| AkitaError::InvalidSetup("opening domain length overflow".to_string()))
}

/// Committed coefficient length for an exact live witness prefix under a
/// successor commitment ring dimension.
pub fn witness_commitment_domain_len(
    live_coeff_len: usize,
    successor_ring_dim: usize,
) -> Result<usize, AkitaError> {
    if successor_ring_dim == 0 || !successor_ring_dim.is_power_of_two() {
        return Err(AkitaError::InvalidSetup(
            "successor commitment ring dimension must be a power of two".to_string(),
        ));
    }
    let live_ring_len = live_coeff_len
        .checked_add(successor_ring_dim - 1)
        .ok_or_else(|| AkitaError::InvalidSetup("witness commitment length overflow".into()))?
        / successor_ring_dim;
    opening_domain_len(live_ring_len)?
        .checked_mul(successor_ring_dim)
        .ok_or_else(|| AkitaError::InvalidSetup("witness commitment domain overflow".into()))
}

/// Validate and return an index in the exact physical opening source.
pub fn checked_opening_source_index(
    source_len: usize,
    physical_index: usize,
) -> Result<usize, AkitaError> {
    if physical_index >= source_len {
        return Err(AkitaError::InvalidInput(
            "physical opening index out of range".to_string(),
        ));
    }
    Ok(physical_index)
}

/// Convert the outer portion of a field opening point into ring-native vectors.
///
/// The first `log2(num_positions_per_block)` coordinates select a position and the
/// remaining `log2(next_power_of_two(num_live_blocks))` coordinates select a
/// block. Only the exact live block prefix is retained.
///
/// # Errors
///
/// Returns an error if the point dimension does not match `layout`.
pub fn ring_opening_point_from_field<F: Field>(
    opening_point: &[F],
    num_positions_per_block: usize,
    num_live_blocks: usize,
    basis: BasisMode,
) -> Result<RingOpeningPoint<F>, AkitaError> {
    if !num_positions_per_block.is_power_of_two() || num_live_blocks == 0 {
        return Err(AkitaError::InvalidSetup(
            "opening geometry requires power-of-two M and positive B".to_string(),
        ));
    }
    let position_index_bits =
        crate::BlockGeometry::position_index_bits_for(num_positions_per_block);
    let block_index_bits = crate::BlockGeometry::checked_block_index_bits_for(num_live_blocks)
        .ok_or_else(|| AkitaError::InvalidSetup("block-index domain size overflow".to_string()))?;
    let expected_len = position_index_bits
        .checked_add(block_index_bits)
        .ok_or_else(|| AkitaError::InvalidSetup("opening point length overflow".to_string()))?;
    if opening_point.len() != expected_len {
        return Err(AkitaError::InvalidPointDimension {
            expected: expected_len,
            actual: opening_point.len(),
        });
    }

    let position_weights = basis_weights(&opening_point[..position_index_bits], basis)?;
    let live_block_weights = basis_weights_prefix(
        &opening_point[position_index_bits..],
        basis,
        num_live_blocks,
    )?;
    Ok(RingOpeningPoint {
        position_weights,
        live_block_weights,
    })
}

/// Reduce the inner `alpha = log2(D)` opening coordinates to one ring element.
///
/// # Errors
///
/// Returns an error if the number of basis weights implied by `inner_point`
/// does not match `D`.
pub fn reduce_inner_opening_to_ring_element<F: Field, const D: usize>(
    inner_point: &[F],
    basis: BasisMode,
) -> Result<CyclotomicRing<F, D>, AkitaError> {
    let weights = basis_weights(inner_point, basis)?;
    if weights.len() != D {
        return Err(AkitaError::InvalidInput(format!(
            "inner basis length {} does not match D={D}",
            weights.len()
        )));
    }
    Ok(CyclotomicRing::from_slice(&weights))
}

#[cfg(test)]
mod tests {
    use super::*;
    use jolt_field::Prime128OffsetA7F7;
    use jolt_field::{One, Ring};

    type F = Prime128OffsetA7F7;

    #[test]
    fn lagrange_weights_match_direct_multilinear_basis() {
        let x = F::from_u64(2);
        let y = F::from_u64(3);
        assert_eq!(lagrange_weights::<F>(&[]).unwrap(), vec![F::one()]);
        assert_eq!(
            lagrange_weights(&[x, y]).unwrap(),
            vec![
                (F::one() - x) * (F::one() - y),
                x * (F::one() - y),
                (F::one() - x) * y,
                x * y,
            ]
        );
    }

    #[test]
    fn lagrange_weights_preserve_the_verifier_sequence_bound() {
        let point = vec![F::one(); DEFAULT_MAX_SEQUENCE_LEN.ilog2() as usize + 1];
        assert!(matches!(
            lagrange_weights(&point),
            Err(AkitaError::InvalidSize {
                expected: DEFAULT_MAX_SEQUENCE_LEN,
                actual,
            }) if actual > DEFAULT_MAX_SEQUENCE_LEN
        ));
    }

    #[test]
    fn opening_point_keeps_exact_live_block_prefix() {
        let point = [
            F::from_u64(2),
            F::from_u64(3),
            F::from_u64(5),
            F::from_u64(7),
        ];
        let opening = ring_opening_point_from_field(&point, 4, 3, BasisMode::Lagrange).unwrap();
        assert_eq!(
            opening.position_weights,
            lagrange_weights(&point[..2]).unwrap()
        );
        assert_eq!(
            opening.live_block_weights,
            lagrange_weights(&point[2..]).unwrap()[..3]
        );
    }

    #[test]
    fn monomial_prefix_omits_boolean_capacity_tail() {
        let point = [F::from_u64(2), F::from_u64(3)];
        let prefix = basis_weights_prefix(&point, BasisMode::Monomial, 3).unwrap();
        assert_eq!(prefix, monomial_weights(&point).unwrap()[..3]);
    }
}
