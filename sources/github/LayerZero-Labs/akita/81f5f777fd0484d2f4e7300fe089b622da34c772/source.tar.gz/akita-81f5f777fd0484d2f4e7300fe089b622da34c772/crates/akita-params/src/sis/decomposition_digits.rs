//! Gadget-decomposition digit counts and the committed-matrix widths derived
//! from them.
//!
//! Three layers live here, lowest to highest:
//!
//! 1. **Core digit-count math** — how many balanced base-`2^log_basis` digits
//!    represent a bound. Two centering conventions exist:
//!    - `compute_num_digits` (crate-private): the *symmetric* signed range
//!      `[-2^(k-1), 2^(k-1) - 1]`, including the sign-bit correction. Reached
//!      only through the router below.
//!    - [`compute_num_digits_field_width`]: an arbitrary field element's
//!      *asymmetric* residue, using plain `ceil(field_bits / log_basis)` with no
//!      correction.
//!    - [`num_digits_for_bound`]: the router. Field-width bounds
//!      (`log_bound >= field_bits`) use the asymmetric count; smaller bounds use
//!      the symmetric one. This is the *only* symmetric entry point, so a caller
//!      cannot accidentally request the symmetric count of a field-width bound
//!      (the historical `compute_num_digits(128, _)` footgun).
//!
//! 2. **Per-role selectors** — map a [`DecompositionParams`] to the digit depth
//!    of a specific witness role, encoding which bound applies to each:
//!    - [`num_digits_inner`]: committed witness `s` (`log_commit_bound` at
//!      the root, `log_basis` at recursive levels).
//!    - [`num_digits_open`]: opening witnesses `t̂` / `ŵ` (`log_open_bound`).
//!    - [`super::honest_fold_policy::HonestFoldPolicy`]: folded witness `z` — the
//!      group-owned offline policy returns its exact scheduled digit count.
//!
//! 3. **Committed-matrix widths** — name the `checked_mul` product that turns a
//!    digit depth plus block geometry into the A matrix's ring-column count:
//!    [`decomposed_s_block_ring_count`]. This is layout arithmetic, not digit
//!    math; it sits here so the width formula lives beside the depth it
//!    multiplies.

use crate::DecompositionParams;

/// Signed coefficient interval represented by `num_digits` balanced
/// base-`2^log_basis` digits, returned as `(negative_abs_reach, positive_reach)`.
///
/// This is the accepted envelope for **any** balanced-digit plane: the folded
/// response `z` the verifier admits, and equally the committed source `s` a
/// bounded commitment can represent. A source coefficient outside this interval
/// cannot be recovered from its `num_digits` digits, so a producer must reject it
/// rather than commit the truncation
/// (see [`crate::DecompositionParams::log_commit_bound`]).
///
/// Each side is exact while it fits in `u128` and **saturates to `u128::MAX`**,
/// a lower bound on the true reach, beyond it, inheriting that behavior from
/// `balanced_digit_max` / [`balanced_digit_abs_max`]. A caller that needs
/// to distinguish "the reach is this value" from "the reach is beyond `u128`" must
/// use [`checked_balanced_digit_representable_bounds`]; comparing a saturated
/// value against a real coefficient rejects legitimate inputs.
#[inline]
#[must_use]
pub fn balanced_digit_representable_bounds(log_basis: u32, num_digits: usize) -> (u128, u128) {
    let num_digits = num_digits.max(1);
    (
        balanced_digit_abs_max(log_basis, num_digits),
        balanced_digit_max(log_basis, num_digits),
    )
}

/// Exact signed coefficient interval, as
/// `(negative_abs_reach, positive_reach)`, with `None` on a side whose true reach
/// exceeds `u128::MAX`.
///
/// `None` means "unbounded for any `u128` coefficient", which is the distinction
/// [`balanced_digit_representable_bounds`] loses by saturating. A commit-side
/// range check needs it: a full-field decomposition can span more than 128 bits
/// (`ceil(128 / 11) * 11 = 132`), and treating a saturated lower bound as the
/// accepted interval would reject valid field elements.
///
/// Total function: a degenerate `log_basis` (`0`, or `>= 128`) yields a
/// `(0, 0)`-reach answer rather than panicking, so a verifier-reachable caller can
/// pass unvalidated schedule data through it.
#[must_use]
pub fn checked_balanced_digit_representable_bounds(
    log_basis: u32,
    num_digits: usize,
) -> (Option<u128>, Option<u128>) {
    if log_basis == 0 || log_basis >= 128 {
        return (Some(0), Some(0));
    }
    let num_digits = num_digits.max(1);
    let half_base = 1u128 << (log_basis - 1);
    // Balanced digits span `[-b/2, b/2 - 1]`, so the positive factor is one less.
    (
        checked_digit_reach(Some(half_base), log_basis, num_digits),
        checked_digit_reach(Some(half_base - 1), log_basis, num_digits),
    )
}

/// `1 + b + ... + b^(num_digits - 1)` for `b = 2^log_basis`, or `None` when it
/// exceeds `u128::MAX`.
///
/// Total over `log_basis`: `0` is base 1, and a base of `2^128` or more is
/// `None` from the second digit on. The loop stops at the first overflow, so a
/// schedule-supplied `num_digits` costs at most `ceil(128 / log_basis) + 1`
/// iterations rather than `num_digits`.
fn checked_digit_series(log_basis: u32, num_digits: usize) -> Option<u128> {
    if log_basis == 0 {
        return u128::try_from(num_digits).ok();
    }
    let base = 1u128.checked_shl(log_basis);
    let mut series = 0u128;
    let mut power = Some(1u128);
    for _ in 0..num_digits {
        // An overflowed power already exceeds `u128::MAX`, and so does the sum.
        series = series.checked_add(power?)?;
        power = power
            .zip(base)
            .and_then(|(term, base)| term.checked_mul(base));
    }
    Some(series)
}

/// Exact `factor · (1 + b + ... + b^(n-1))`, or `None` when it exceeds
/// `u128::MAX`. A `None` factor stands for one of at least `2^128`.
///
/// A zero factor or an empty series is exactly `0`, however large the other
/// operand: base-2 balanced digits `{-1, 0}` have positive reach `0` at every
/// depth.
fn checked_digit_reach(factor: Option<u128>, log_basis: u32, num_digits: usize) -> Option<u128> {
    if factor == Some(0) || num_digits == 0 {
        return Some(0);
    }
    factor
        .zip(checked_digit_series(log_basis, num_digits))
        .and_then(|(factor, series)| factor.checked_mul(series))
}

/// Minimum balanced-digit depth whose exact signed range contains
/// `[-cap, cap]`.
///
/// Unlike [`num_digits_for_bound`], this function accepts an exact integer
/// magnitude instead of a power-of-two bit width. The positive reach is the
/// binding side because balanced digits extend farther in the negative
/// direction.
#[inline]
#[must_use]
pub fn num_digits_for_linf_cap(cap: u128, field_bits: u32, log_basis: u32) -> usize {
    assert!(log_basis > 0 && log_basis < 128, "invalid log_basis");
    if cap == 0 {
        return 1;
    }
    let signed_bits = (u128::BITS - cap.leading_zeros()).saturating_add(1);
    if signed_bits >= field_bits {
        return compute_num_digits_field_width(field_bits, log_basis);
    }
    let fallback = num_digits_for_bound(signed_bits, field_bits, log_basis);
    for digits in 1..fallback {
        if balanced_digit_max(log_basis, digits) >= cap {
            return digits;
        }
    }
    fallback
}

/// Maximum positive value representable by `num_digits` balanced base-`b`
/// digits, where `b = 2^log_basis`. Each balanced digit lies in
/// `[-b/2, b/2 - 1]`; the max positive value is the geometric series
/// `(b/2 - 1) · (b^n - 1) / (b - 1)`. The result is exact while it fits in
/// `u128` and saturates to `u128::MAX` beyond it, a lower bound (safe for digit
/// selection: it can only add a digit, never drop one). Base 1
/// (`log_basis = 0`) has no positive digit and returns `0`.
pub(crate) fn balanced_digit_max(log_basis: u32, num_digits: usize) -> u128 {
    let max_digit = match log_basis {
        0 => Some(0),
        _ => 1u128
            .checked_shl(log_basis - 1)
            .map(|half_base| half_base - 1),
    };
    checked_digit_reach(max_digit, log_basis, num_digits).unwrap_or(u128::MAX)
}

/// Maximum absolute value accepted by `num_digits` balanced base-`b` digits,
/// i.e. the negative reach `(b/2) · (b^n - 1)/(b - 1)`.
///
/// This is the coefficient-`L∞` envelope the verifier accepts for the folded
/// witness `z`: stage-1 digit membership admits every balanced `num_digits`-digit
/// string, and balanced digits `[-b/2, b/2 - 1]` reach further on the negative
/// side, so the absolute envelope is this negative reach. The result is exact
/// while it fits in `u128` and saturates to `u128::MAX` beyond it. Base 1
/// (`log_basis = 0`) returns `0`.
#[inline]
#[must_use]
pub fn balanced_digit_abs_max(log_basis: u32, num_digits: usize) -> u128 {
    let max_abs_digit = match log_basis {
        0 => Some(0),
        _ => 1u128.checked_shl(log_basis - 1),
    };
    checked_digit_reach(max_abs_digit, log_basis, num_digits).unwrap_or(u128::MAX)
}

/// Diameter of the signed interval represented by `num_digits` balanced
/// base-`2^log_basis` digits.
///
/// Balanced digits lie in `[-b/2, b/2 - 1]`. The difference of two accepted
/// recompositions therefore has per-digit magnitude at most `b - 1`, so the
/// complete interval diameter is
/// `(b - 1) * (1 + b + ... + b^(num_digits - 1)) = b^num_digits - 1`.
/// This is tighter than twice [`balanced_digit_abs_max`] because the accepted
/// interval is asymmetric. The result is exact while it fits in `u128`
/// (through `log_basis · num_digits = 128`) and saturates to `u128::MAX`
/// beyond it. Base 1 (`log_basis = 0`) returns `0`.
#[inline]
#[must_use]
pub fn balanced_digit_interval_diameter(log_basis: u32, num_digits: usize) -> u128 {
    if log_basis == 0 {
        return 0;
    }
    u32::try_from(num_digits)
        .ok()
        .and_then(|num_digits| log_basis.checked_mul(num_digits))
        .filter(|&bits| bits < 128)
        .map_or(u128::MAX, |bits| (1u128 << bits) - 1)
}

/// Minimum number of balanced base-`2^log_basis` digits needed to represent a
/// `log_bound`-bit *signed* coefficient, using symmetric centering.
///
/// Following [`crate::DecompositionParams::log_commit_bound`], a bound of `k`
/// bits denotes the centered range `[-2^(k-1), 2^(k-1) - 1]`, i.e. one sign bit
/// plus `k-1` magnitude bits. The binding constraint is the positive end,
/// `2^(k-1) - 1`, since the balanced digit range `[-b/2, b/2 - 1]` reaches
/// further on the negative side. This is *not* `2^log_bound - 1`: the leading
/// bit is the sign, so callers that mean "magnitude up to `2^m`" must pass
/// `log_bound = m + 1`.
///
/// The count is `ceil(log_bound / log_basis)`, plus one more digit when the
/// balanced-digit positive reach `balanced_digit_max` still falls short of
/// `2^(log_bound-1) - 1`. The extra digit is only ever needed when `log_basis`
/// divides `log_bound` exactly (otherwise `ceil(log_bound/log_basis)·log_basis
/// > log_bound`, so the reach already clears `2^(log_bound-1)`); the check is
/// run unconditionally because it is cheap and self-evidently correct. Both the
/// coverage and the minimality of the result are pinned by the
/// `compute_num_digits_covers_signed_range` unit test.
///
/// This symmetric count is for *small* bounds (`log_bound < field_bits`):
/// one-hot `log_commit_bound = 1`, recursive `log_basis`, and fold `log_beta`.
/// It is crate-private and reached only through [`num_digits_for_bound`], which
/// routes field-width bounds to the asymmetric [`compute_num_digits_field_width`]
/// instead — so no caller can ask for the symmetric count of a field-width bound.
///
/// # Panics
///
/// Panics if `log_basis` is 0 or at least 128, or if `log_bound` exceeds 128.
pub(crate) fn compute_num_digits(log_bound: u32, log_basis: u32) -> usize {
    assert!(log_basis > 0 && log_basis < 128, "invalid log_basis");
    assert!(
        log_bound <= 128,
        "log_bound={log_bound} exceeds 128-bit field"
    );

    if log_bound == 0 {
        return 1;
    }

    let mut num_digits = (log_bound as usize).div_ceil(log_basis as usize);
    let required_positive = (1u128 << (log_bound - 1)).saturating_sub(1);
    if balanced_digit_max(log_basis, num_digits) < required_positive {
        num_digits += 1;
    }
    num_digits.max(1)
}

/// Decomposition depth for arbitrary field elements using asymmetric centering:
/// `ceil(field_bits / log_basis)` with no +1 correction.
///
/// # Panics
///
/// Panics if `log_basis` is 0 or >= 128.
pub fn compute_num_digits_field_width(field_bits: u32, log_basis: u32) -> usize {
    assert!(log_basis > 0 && log_basis < 128, "invalid log_basis");
    if field_bits == 0 {
        return 1;
    }
    (field_bits as usize).div_ceil(log_basis as usize).max(1)
}

/// Choose the correct digit-count function for an explicit field bit width.
/// Field-width bounds (`log_bound >= field_bits`) use asymmetric centering;
/// smaller bounds use symmetric centering.
///
/// # Panics
///
/// Panics if `log_basis` is 0 or at least 128, or if the effective symmetric
/// bound exceeds 128 bits.
pub fn num_digits_for_bound(log_bound: u32, field_bits: u32, log_basis: u32) -> usize {
    if log_bound >= field_bits {
        compute_num_digits_field_width(field_bits, log_basis)
    } else {
        compute_num_digits(log_bound, log_basis)
    }
}

/// `δ_commit`: digits per coefficient of the committed witness `s`, using the
/// level's gadget base `decomposition.log_basis`.
///
/// The root commits against its configured `log_commit_bound`; a recursive
/// level commits the balanced-digit witness, whose commit bound collapses to
/// `log_basis`.
pub fn num_digits_inner(decomposition: DecompositionParams, is_root: bool) -> usize {
    let bound = if is_root {
        decomposition.log_commit_bound
    } else {
        decomposition.log_basis
    };
    num_digits_inner_for_bound(decomposition, bound)
}

/// `δ_commit` for an explicit source coefficient bound.
///
/// This is the general planner entry point when the source bound and selected
/// A decomposition basis are independent. `source_log_bound` follows the same
/// signed-bound convention as [`num_digits_for_bound`].
pub fn num_digits_inner_for_bound(
    decomposition: DecompositionParams,
    source_log_bound: u32,
) -> usize {
    num_digits_for_bound(
        source_log_bound,
        decomposition.field_bits(),
        decomposition.log_basis,
    )
}

/// `δ_open`: digits per coefficient of the opening witnesses `t̂` / `ŵ`,
/// which are opened at the field level (`log_open_bound`).
pub fn num_digits_open(decomposition: DecompositionParams) -> usize {
    let field_bits = decomposition.field_bits();
    let bound = decomposition
        .log_open_bound
        .unwrap_or(decomposition.log_commit_bound);
    num_digits_for_bound(bound, field_bits, decomposition.log_basis)
}

/// A-matrix committed width (ring columns): `num_positions_per_block · δ_commit`.
#[inline]
pub fn decomposed_s_block_ring_count(
    num_positions_per_block: usize,
    num_digits_inner: usize,
) -> Option<usize> {
    num_positions_per_block.checked_mul(num_digits_inner)
}

/// Convert an A-native ring-column count into the physical column count of a
/// projected B- or D-native role.
///
/// The role dimension must divide the source dimension exactly.
#[inline]
pub fn projected_role_ring_count(
    source_dimension: usize,
    role_dimension: usize,
    native_ring_count: usize,
) -> Option<usize> {
    if role_dimension == 0 || !source_dimension.is_multiple_of(role_dimension) {
        return None;
    }
    native_ring_count.checked_mul(source_dimension / role_dimension)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sis::{fold_witness_beta_inf, FoldChallengeNorms, FoldWitnessNorms};

    #[test]
    fn balanced_digit_max_cases() {
        assert_eq!(balanced_digit_max(2, 2), 5);
        assert_eq!(balanced_digit_max(3, 1), 3);
    }

    #[test]
    fn balanced_digit_abs_max_uses_negative_reach() {
        // b = 4, δ = 3 digits represent [-42, 21]; A-role pricing must use
        // the accepted absolute envelope, not the shorter positive side.
        assert_eq!(balanced_digit_max(2, 3), 21);
        assert_eq!(balanced_digit_abs_max(2, 3), 42);
        // b = 8, δ = 2 digits represent [-36, 27].
        assert_eq!(balanced_digit_max(3, 2), 27);
        assert_eq!(balanced_digit_abs_max(3, 2), 36);
    }

    #[test]
    fn balanced_digit_interval_diameter_is_positive_minus_negative_reach() {
        for (log_basis, num_digits) in [(2, 3), (3, 2), (11, 6), (16, 4)] {
            let negative = balanced_digit_abs_max(log_basis, num_digits);
            let positive = balanced_digit_max(log_basis, num_digits);
            assert_eq!(
                balanced_digit_interval_diameter(log_basis, num_digits),
                negative + positive
            );
        }
        assert_eq!(balanced_digit_interval_diameter(3, 2), 63);
    }

    /// Pins all three saturating series at and around their saturation points,
    /// against closed forms in `2^(k·n)`, for every `log_basis` below 128: each
    /// is exact while it fits in `u128` and `u128::MAX` beyond it.
    #[test]
    fn saturating_series_match_closed_forms_at_every_boundary() {
        for log_basis in 1u32..=127 {
            let base = 1u128 << log_basis;
            // `1 + b + ... + b^(n-1) = (2^(k·n) - 1) / (b - 1)` for `k·n <= 128`.
            let geometric = |bits: u64| {
                (bits <= 128).then(|| {
                    let power_minus_one = if bits == 128 {
                        u128::MAX
                    } else {
                        (1u128 << bits) - 1
                    };
                    power_minus_one / (base - 1)
                })
            };
            let reach = |factor: u128, series: Option<u128>| match series {
                Some(series) => factor.saturating_mul(series),
                None if factor == 0 => 0,
                None => u128::MAX,
            };
            for num_digits in 0usize..=260 {
                let bits = u64::from(log_basis) * num_digits as u64;
                // Past `k·n = 128`, one more term `b · S_(n-1) + 1` either fits or
                // overflows; `S_(n-1)` itself is `None` once `k·(n-1) > 128`.
                let series = if bits <= 128 {
                    geometric(bits)
                } else {
                    geometric(bits - u64::from(log_basis))
                        .and_then(|below| below.checked_mul(base))
                        .and_then(|below| below.checked_add(1))
                };
                let context = format!("log_basis={log_basis} num_digits={num_digits}");
                assert_eq!(
                    balanced_digit_interval_diameter(log_basis, num_digits),
                    if bits >= 128 {
                        u128::MAX
                    } else {
                        (1u128 << bits) - 1
                    },
                    "{context}"
                );
                assert_eq!(
                    balanced_digit_max(log_basis, num_digits),
                    reach(base / 2 - 1, series),
                    "{context}"
                );
                assert_eq!(
                    balanced_digit_abs_max(log_basis, num_digits),
                    reach(base / 2, series),
                    "{context}"
                );
                // The saturating pair is the checked pair with `None` read as
                // `u128::MAX`.
                let (negative, positive) =
                    checked_balanced_digit_representable_bounds(log_basis, num_digits);
                assert_eq!(
                    balanced_digit_representable_bounds(log_basis, num_digits),
                    (negative.unwrap_or(u128::MAX), positive.unwrap_or(u128::MAX)),
                    "{context}"
                );
            }
            // Digit counts past `u32::MAX` must answer without iterating.
            for num_digits in [
                u32::MAX as usize,
                (u32::MAX as usize).saturating_add(1),
                usize::MAX,
            ] {
                assert_eq!(
                    balanced_digit_interval_diameter(log_basis, num_digits),
                    u128::MAX
                );
                assert_eq!(
                    balanced_digit_max(log_basis, num_digits),
                    if log_basis == 1 { 0 } else { u128::MAX }
                );
                assert_eq!(balanced_digit_abs_max(log_basis, num_digits), u128::MAX);
            }
        }
    }

    /// Bases outside `1..=127` answer instead of panicking: base 1 has no
    /// nonzero reach, and a base of `2^128` or more is exact for one digit and
    /// saturated from the second on.
    #[test]
    fn saturating_series_are_total_over_log_basis() {
        for num_digits in [0, 1, 2, 1_000, usize::MAX] {
            assert_eq!(balanced_digit_max(0, num_digits), 0);
            assert_eq!(balanced_digit_abs_max(0, num_digits), 0);
            assert_eq!(balanced_digit_interval_diameter(0, num_digits), 0);
        }
        for log_basis in [128u32, 129, 200, u32::MAX] {
            for num_digits in [0usize, 1, 2, usize::MAX] {
                let (positive, negative, diameter) = match (log_basis, num_digits) {
                    (_, 0) => (0, 0, 0),
                    (128, 1) => ((1u128 << 127) - 1, 1u128 << 127, u128::MAX),
                    _ => (u128::MAX, u128::MAX, u128::MAX),
                };
                let context = format!("log_basis={log_basis} num_digits={num_digits}");
                assert_eq!(
                    balanced_digit_max(log_basis, num_digits),
                    positive,
                    "{context}"
                );
                assert_eq!(
                    balanced_digit_abs_max(log_basis, num_digits),
                    negative,
                    "{context}"
                );
                assert_eq!(
                    balanced_digit_interval_diameter(log_basis, num_digits),
                    diameter,
                    "{context}"
                );
            }
        }
    }

    /// The checked reaches agree with the saturating ones inside `u128` and
    /// report `None` beyond it.
    ///
    /// Beyond `u128` the saturating pair is `u128::MAX`, a *lower* bound on the
    /// true reach, which is correct for choosing a digit depth but wrong as an
    /// acceptance interval. A commit-side range check must not read it as exact.
    #[test]
    fn checked_reaches_are_exact_where_the_saturating_reaches_are() {
        for (log_basis, num_digits) in [(2u32, 3usize), (3, 2), (5, 13), (11, 11)] {
            let (checked_negative, checked_positive) =
                checked_balanced_digit_representable_bounds(log_basis, num_digits);
            let (negative, positive) = balanced_digit_representable_bounds(log_basis, num_digits);
            assert_eq!(checked_negative, Some(negative));
            assert_eq!(checked_positive, Some(positive));
        }

        // `ceil(128 / 11) = 12` digits of base 2^11 span 132 bits, so both true
        // reaches exceed `u128::MAX` and the saturating pair understates them.
        let (negative, positive) = checked_balanced_digit_representable_bounds(11, 12);
        assert_eq!((negative, positive), (None, None));
        assert_eq!(
            balanced_digit_representable_bounds(11, 12),
            (u128::MAX, u128::MAX)
        );
        // Base 4 with 64 digits: the positive reach `(4^64 - 1) / 3` fits exactly.
        // It must not come out one short, as it would by dividing a saturated
        // `4^64`.
        assert_eq!(balanced_digit_max(2, 64), u128::MAX / 3);

        // Total over degenerate bases: verifier-reachable callers pass unvalidated
        // schedule data, so this must answer rather than panic.
        for log_basis in [0u32, 128, u32::MAX] {
            assert_eq!(
                checked_balanced_digit_representable_bounds(log_basis, 4),
                (Some(0), Some(0))
            );
        }
        // Base 2 balanced digits are `{-1, 0}`: four of them reach `-15` and
        // nothing positive. Not a production basis, but the reach must still be
        // the exact one rather than a wrapped `base / 2 - 1`.
        assert_eq!(
            checked_balanced_digit_representable_bounds(1, 4),
            (Some(15), Some(0))
        );
    }

    #[test]
    fn exact_linf_cap_does_not_round_through_a_power_of_two_range() {
        assert_eq!(num_digits_for_linf_cap(20, 64, 3), 2);
        assert_eq!(num_digits_for_linf_cap(27, 64, 3), 2);
        assert_eq!(num_digits_for_linf_cap(28, 64, 3), 3);
        assert_eq!(num_digits_for_linf_cap(1_755, 128, 3), 4);
        assert_eq!(num_digits_for_linf_cap(1_756, 128, 3), 5);
    }

    #[test]
    fn digits_basic() {
        // Production `compute_num_digits` inputs are small symmetric bounds:
        // one-hot `log_commit_bound = 1`, recursive `log_basis`, fold
        // `log_beta`. Field-width bounds go through `num_digits_for_bound` to
        // `compute_num_digits_field_width`, not here.
        assert_eq!(compute_num_digits(1, 2), 1);
        assert_eq!(compute_num_digits(0, 2), 1);
        // `log_basis` itself (the recursive commit bound): one base-`2^lb`
        // digit covers the balanced range `[-2^(lb-1), 2^(lb-1) - 1]` exactly.
        assert_eq!(compute_num_digits(2, 2), 1);
        assert_eq!(compute_num_digits(3, 3), 1);
    }

    /// The returned digit count must actually cover the signed range
    /// `[-2^(log_bound-1), 2^(log_bound-1) - 1]` its contract promises, for
    /// every production base and bound. This pins the invariant the previous
    /// conditional guard left unchecked whenever `log_basis ∤ log_bound`.
    #[test]
    fn compute_num_digits_covers_signed_range() {
        for log_basis in 2u32..=8 {
            for log_bound in 1u32..=120 {
                let n = compute_num_digits(log_bound, log_basis);
                let required_positive = (1u128 << (log_bound - 1)).saturating_sub(1);
                assert!(
                    balanced_digit_max(log_basis, n) >= required_positive,
                    "log_bound={log_bound} log_basis={log_basis} n={n} \
                     reach={} < required={required_positive}",
                    balanced_digit_max(log_basis, n),
                );
                // Minimality: one fewer digit must be insufficient (unless n==1).
                if n > 1 {
                    assert!(
                        balanced_digit_max(log_basis, n - 1) < required_positive,
                        "non-minimal: log_bound={log_bound} log_basis={log_basis} n={n}",
                    );
                }
            }
        }
    }

    #[test]
    fn field_element_digits() {
        assert_eq!(compute_num_digits_field_width(128, 2), 64);
        assert_eq!(compute_num_digits_field_width(128, 3), 43);
        assert_eq!(compute_num_digits_field_width(128, 4), 32);
        assert_eq!(compute_num_digits_field_width(128, 8), 16);
    }

    #[test]
    fn num_digits_for_bound_selects_correctly() {
        assert_eq!(num_digits_for_bound(128, 128, 2), 64);
        assert_eq!(num_digits_for_bound(10, 128, 2), compute_num_digits(10, 2));
        assert_eq!(num_digits_for_bound(128, 128, 3), 43);
    }

    #[test]
    fn widths_are_checked() {
        assert_eq!(decomposed_s_block_ring_count(4, 3), Some(12));
        assert_eq!(decomposed_s_block_ring_count(usize::MAX, 2), None);
        assert_eq!(projected_role_ring_count(256, 64, 7), Some(28));
        assert_eq!(projected_role_ring_count(256, 128, 7), Some(14));
        assert_eq!(projected_role_ring_count(128, 256, 7), None);
        assert_eq!(projected_role_ring_count(256, 0, 7), None);
    }

    #[test]
    fn fold_witness_digit_plan_derives_beta() {
        // Dense witness (||s||_inf = b/2, ||s||_1 = D·b/2) picks the
        // ||c||_1·||s||_inf side; one-hot (||s||_1 = 1) picks ||c||_inf and
        // needs strictly fewer digits.
        let challenge = FoldChallengeNorms {
            infinity_norm: 8,
            l1_norm: 54,
        };
        // dense: log_basis=3 ⇒ ||s||_inf = b/2 = 4, ||s||_1 = D·b/2 = 64·4.
        let dense = FoldWitnessNorms::bounded(3, 64);
        // one-hot single-chunk: ||s||_inf = 1, ||s||_1 = 1.
        let onehot = FoldWitnessNorms::sparse_binary(64, 64).unwrap();
        let dense_beta = fold_witness_beta_inf(8, 1, challenge, dense).unwrap();
        let onehot_beta = fold_witness_beta_inf(8, 1, challenge, onehot).unwrap();
        let dense_digits =
            num_digits_for_bound((128 - dense_beta.leading_zeros()).saturating_add(1), 128, 3);
        let onehot_digits = num_digits_for_bound(
            (128 - onehot_beta.leading_zeros()).saturating_add(1),
            128,
            3,
        );
        assert!(dense_digits > 0 && onehot_digits > 0);
        assert!(onehot_digits < dense_digits);
        // More claims never reduce the digit count.
        let batched_beta = fold_witness_beta_inf(8, 4, challenge, dense).unwrap();
        let batched_digits = num_digits_for_bound(
            (128 - batched_beta.leading_zeros()).saturating_add(1),
            128,
            3,
        );
        assert!(batched_digits >= dense_digits);
    }

    #[test]
    fn fold_witness_digit_plan_rejects_zero_live_blocks() {
        let challenge = FoldChallengeNorms {
            infinity_norm: 8,
            l1_norm: 54,
        };
        let witness = FoldWitnessNorms::bounded(3, 64);
        // A fold must contain at least one live block.
        assert!(fold_witness_beta_inf(0, 1, challenge, witness).is_err());
    }
}
