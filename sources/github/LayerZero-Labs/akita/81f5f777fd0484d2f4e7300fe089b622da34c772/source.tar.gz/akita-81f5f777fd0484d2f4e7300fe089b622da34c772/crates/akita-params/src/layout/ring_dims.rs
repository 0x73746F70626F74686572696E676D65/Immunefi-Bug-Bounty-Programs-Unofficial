//! Per-level and per-schedule ring dimension validation.
//!
//! [`validate_schedule_ring_dims`] checks every fold level's [`CommitmentRingDims`].
//! Per-level geometry lives on [`super::CommittedGroupParams`].

use crate::schedule::FoldSchedule;
use akita_error::AkitaError;

/// Upper bound on fold levels accepted by [`validate_schedule_ring_dims`].
pub const MAX_FOLD_LEVELS: usize = 16;

/// Ring dimensions valid for A-role (`d_a`) sparse fold challenges.
pub const SUPPORTED_CHALLENGE_RING_DIMS: &[usize] =
    akita_challenges::PRODUCTION_FOLD_CHALLENGE_RING_DIMS;

/// Ring dimensions admitted for A/B/D commitment matrices.
///
/// Compression maps and NTT kernels have separate, field-profile-specific
/// dispatch domains. Their smaller dimensions must not enter role admission.
pub const SUPPORTED_COMMITMENT_RING_DIMS: [usize; 6] = [64, 128, 256, 512, 1024, 2048];

/// Minimum `d_a` for sparse fold ring challenges (no sampler below this).
pub const MIN_A_ROLE_FOLD_CHALLENGE_RING_D: usize = 64;

/// Which commitment matrix owns a buffer or ring dimension at one fold level.
///
/// “Role” is the historical protocol name for the fixed job of one of the
/// three Ajtai matrices. It does not mean that a matrix changes jobs between
/// levels: A always carries the relation witness, B always commits the next
/// witness, and D always commits the opening digits.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RingRole {
    /// A matrix (`d_a`): fold witness, row coefficients, ring-switch geometry.
    Inner,
    /// B matrix (`d_b`): sent commitment rows, COMMIT segment of `y`.
    Outer,
    /// D matrix (`d_d`): opening digits, D-block rows `v`.
    Opening,
}

/// Per-fold ring dimensions of the A, B, and D commitment matrices.
///
/// Z, E, and T are produced over the A-native source ring. B- and D-native
/// projections therefore require `inner >= outer` and `inner >= opening`.
/// B and D are independent: neither is ordered relative to the other.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CommitmentRingDims {
    /// Fold / ring-switch / inner-commitment ring (`d_a`).
    pub inner: usize,
    /// Outer-commitment ring (`d_b`).
    pub outer: usize,
    /// Opening-commitment ring (`d_d`).
    pub opening: usize,
}

impl CommitmentRingDims {
    #[must_use]
    pub const fn uniform(d: usize) -> Self {
        Self {
            inner: d,
            outer: d,
            opening: d,
        }
    }

    /// Validate the representation-level native projection geometry
    /// independently of production dispatch and challenge catalogs.
    ///
    /// This permits small dimensions in arithmetic/layout tests while keeping
    /// the same ordering contract used by [`validate_role_dims`].
    pub fn validate_role_projection(self) -> Result<(), AkitaError> {
        for (role, d) in [
            (RingRole::Inner, self.inner),
            (RingRole::Outer, self.outer),
            (RingRole::Opening, self.opening),
        ] {
            if d == 0 || !d.is_power_of_two() {
                return Err(AkitaError::InvalidSetup(format!(
                    "{role:?} ring dimension must be a non-zero power of two, got {d}"
                )));
            }
        }
        if self.outer > self.inner || self.opening > self.inner {
            return Err(AkitaError::InvalidSetup(format!(
                "A-role ring dimension d_a={} must be at least d_b={} and d_d={}",
                self.inner, self.outer, self.opening
            )));
        }
        Ok(())
    }

    /// Ring dimension for A-role data: the folded witness `z`, A quotient
    /// rows, the consistency row, and fold/ring-switch arithmetic.
    #[must_use]
    pub const fn d_a(self) -> usize {
        self.inner
    }

    /// Ring dimension for B-role data: next-witness digit commitments (`t_hat`)
    /// and the slice-major B relation rows.
    #[must_use]
    pub const fn d_b(self) -> usize {
        self.outer
    }

    /// Ring dimension for D-role data: opening digits (`e_hat`) and the
    /// D-block relation rows (`v = D * e_hat`).
    #[must_use]
    pub const fn d_d(self) -> usize {
        self.opening
    }

    /// Largest low coefficient block shared by every relation role.
    ///
    /// This is the relation-algebra boundary: alpha exponents for every role
    /// reset on multiples of this count. It does not depend on the outgoing
    /// witness representation.
    #[must_use]
    pub const fn common_relation_coeff_count(self) -> usize {
        let inner_outer_min = if self.inner < self.outer {
            self.inner
        } else {
            self.outer
        };
        if inner_outer_min < self.opening {
            inner_outer_min
        } else {
            self.opening
        }
    }

    /// Ring dimension for `role`.
    #[must_use]
    pub const fn dim_for(self, role: RingRole) -> usize {
        match role {
            RingRole::Inner => self.inner,
            RingRole::Outer => self.outer,
            RingRole::Opening => self.opening,
        }
    }
}

/// Validate every fold level's per-role ring dimensions.
///
/// Reads [`super::CommittedGroupParams::role_dims`] from each scheduled fold step; does
/// not copy them into a separate plan object.
///
/// # Errors
///
/// Returns [`AkitaError::InvalidSetup`] when any catalog, key-consistency, or
/// witness-length check fails. Prover and verifier setup capacity are checked
/// separately because offloaded setup-prefix claims give them different matrix
/// requirements.
pub fn validate_schedule_ring_dims(schedule: &FoldSchedule) -> Result<(), AkitaError> {
    let num_folds = schedule.num_fold_levels();
    if num_folds > MAX_FOLD_LEVELS {
        return Err(AkitaError::InvalidSetup(format!(
            "schedule has {num_folds} fold levels, max supported is {MAX_FOLD_LEVELS}"
        )));
    }
    let validate_step = |lp: &crate::CommittedGroupParams,
                         input_witness_len: usize,
                         output_witness_len: Option<usize>,
                         next_ring_d: Option<usize>|
     -> Result<(), AkitaError> {
        let dims = lp.role_dims();
        validate_role_dims(dims)?;
        validate_role_dims_match_keys(lp)?;
        // The live witness is a compact field-element prefix.  It may end in a
        // partial A ring; successor preparation supplies the one zero suffix
        // required to form complete successor rings and the Boolean domain.
        if input_witness_len == 0 {
            return Err(AkitaError::InvalidSetup(format!(
                "witness length {} is invalid for fold ring d_a={}",
                input_witness_len, dims.inner
            )));
        }
        if let (Some(output_witness_len), Some(next_ring_d)) = (output_witness_len, next_ring_d) {
            if next_ring_d == 0 || output_witness_len == 0 {
                return Err(AkitaError::InvalidSetup(format!(
                    "next witness length {} is invalid for next fold ring d_a={next_ring_d}",
                    output_witness_len,
                )));
            }
        }
        Ok(())
    };
    let root_next_d = schedule
        .recursive_folds
        .first()
        .map_or_else(|| schedule.terminal.d_a(), |next| next.params.d_a());
    validate_step(
        &schedule.root.params,
        schedule.root.input_witness_len,
        Some(schedule.root.output_witness_len),
        Some(root_next_d),
    )?;
    // The shared D matrix is stored once, so it cannot disagree with itself.
    let root = &schedule.root.params;
    let final_params = &root;
    let shared_d = root.open().matrix.ring_dimension();
    for (group_index, group) in root.precommitted_groups().iter().enumerate() {
        group.profile.validate_frozen_precommit(
            group
                .profile
                .inner
                .matrix
                .sis_modulus_profile()
                .field_bits(),
        )?;
        group.validate()?;
        if group.opening.log_basis_open != final_params.open().digits.log_basis {
            return Err(AkitaError::InvalidSetup(format!(
                "root precommitted group {group_index} opening basis disagrees with the batch-shared basis"
            )));
        }
        if group.opening.fold_challenge_config.weight() == 0 {
            return Err(AkitaError::InvalidSetup(format!(
                "root precommitted group {group_index} has an empty fold challenge"
            )));
        }
        validate_role_dims(group.role_dims(shared_d))?;
    }
    for (index, step) in schedule.recursive_folds.iter().enumerate() {
        let next_ring_d = schedule
            .recursive_folds
            .get(index + 1)
            .map_or_else(|| schedule.terminal.d_a(), |next| next.params.d_a());
        validate_step(
            &step.params,
            step.input_witness_len,
            Some(step.output_witness_len),
            Some(next_ring_d),
        )?;
    }
    let terminal = &schedule.terminal;
    let terminal_d = terminal.d_a();
    if terminal_d == 0
        || !SUPPORTED_COMMITMENT_RING_DIMS.contains(&terminal_d)
        || !schedule
            .terminal
            .input_witness_len
            .is_multiple_of(terminal_d)
        || terminal.inner.matrix.ring_dimension() != terminal_d
    {
        return Err(AkitaError::InvalidSetup(
            "terminal inner ring dimension is inconsistent with witness length".to_string(),
        ));
    }
    Ok(())
}

pub fn validate_role_dims_match_keys(lp: &crate::CommittedGroupParams) -> Result<(), AkitaError> {
    let dims = lp.role_dims();
    let a_ring = lp.inner().matrix.ring_dimension();
    let b_ring = lp.outer().matrix.sis_table_key().ring_dimension as usize;
    let d_ring = lp.open().matrix.sis_table_key().ring_dimension as usize;
    if a_ring != dims.inner {
        return Err(AkitaError::InvalidSetup(format!(
            "A-key ring dimension {a_ring} disagrees with role_dims.d_a={}",
            dims.inner
        )));
    }
    if b_ring != dims.outer {
        return Err(AkitaError::InvalidSetup(format!(
            "B-key ring dimension {b_ring} disagrees with role_dims.d_b={}",
            dims.outer
        )));
    }
    if d_ring != dims.opening {
        return Err(AkitaError::InvalidSetup(format!(
            "D-key ring dimension {d_ring} disagrees with role_dims.d_d={}",
            dims.opening
        )));
    }
    lp.fold_challenge_config()
        .validate_for_ring_dim(lp.d_a())
        .map_err(|msg| AkitaError::InvalidSetup(msg.to_string()))?;
    Ok(())
}

pub fn validate_role_dims(dims: CommitmentRingDims) -> Result<(), AkitaError> {
    dims.validate_role_projection()?;
    for (role, d) in [
        (RingRole::Inner, dims.inner),
        (RingRole::Outer, dims.outer),
        (RingRole::Opening, dims.opening),
    ] {
        if !SUPPORTED_COMMITMENT_RING_DIMS.contains(&d) {
            return Err(AkitaError::InvalidSetup(format!(
                "unsupported {role:?} commitment-matrix ring dimension {d}; A/B/D dimensions must be at least 64"
            )));
        }
    }
    if !SUPPORTED_CHALLENGE_RING_DIMS.contains(&dims.inner) {
        return Err(AkitaError::InvalidSetup(format!(
            "A-role ring dimension d_a={} is unsupported for sparse fold challenges (need d_a >= {MIN_A_ROLE_FOLD_CHALLENGE_RING_D})",
            dims.inner
        )));
    }
    Ok(())
}

#[cfg(test)]
#[path = "ring_dims_tests.rs"]
mod tests;
