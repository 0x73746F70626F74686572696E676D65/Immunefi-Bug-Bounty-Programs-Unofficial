#![allow(missing_docs)]
//! Benchmarks for the crypto precompiles

pub mod blake2;
pub mod ecrecover;
pub mod eip1962;
pub mod eip2537;
pub mod eip4844;

use criterion::{criterion_group, criterion_main, Criterion};

/// Benchmarks different cryptography-related precompiles.
pub fn benchmark_crypto_precompiles(c: &mut Criterion) {
    let mut group = c.benchmark_group("Crypto Precompile benchmarks");

    // Run BLS12-381 benchmarks (EIP-2537)
    eip2537::add_g1_add_benches(&mut group);
    eip2537::add_g2_add_benches(&mut group);
    eip2537::add_g1_msm_benches(&mut group);
    eip2537::add_g2_msm_benches(&mut group);
    eip2537::add_pairing_benches(&mut group);
    eip2537::add_map_fp_to_g1_benches(&mut group);
    eip2537::add_map_fp2_to_g2_benches(&mut group);

    // Run BN254 benchmarks
    eip1962::add_bn254_add_benches(&mut group);
    eip1962::add_bn254_mul_benches(&mut group);
    eip1962::add_bn254_pair_benches(&mut group);

    // Run secp256k1 benchmarks
    ecrecover::add_benches(&mut group);

    // Run KZG point evaluation benchmarks
    eip4844::add_benches(&mut group);

    // Run Blake2 benchmarks
    blake2::add_benches(&mut group);
}

criterion_group! {
    name = benches;
    config = Criterion::default();
    targets = benchmark_crypto_precompiles
}

criterion_main!(benches);
