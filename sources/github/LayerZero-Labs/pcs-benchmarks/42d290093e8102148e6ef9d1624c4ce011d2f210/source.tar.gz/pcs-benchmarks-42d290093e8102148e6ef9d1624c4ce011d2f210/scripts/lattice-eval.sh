#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
exec cargo run --release -p pcs-bench-runner --bin pcs-bench -- lattice-eval "$@"
