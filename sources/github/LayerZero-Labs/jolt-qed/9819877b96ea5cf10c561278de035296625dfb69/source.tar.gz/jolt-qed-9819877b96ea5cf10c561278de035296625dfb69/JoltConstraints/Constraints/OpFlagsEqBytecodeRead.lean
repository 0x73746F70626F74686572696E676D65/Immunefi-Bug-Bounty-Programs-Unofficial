import JoltConstraints.Constraints.BytecodeReadData
import JoltConstraints.Constraints.BytecodeReadSelection
import JoltConstraints.honest_witness

set_option autoImplicit false

namespace JoltConstraints

open scoped BigOperators

/-- Constraint (46) in `constraints.md` (stages 6a–6b):
each circuit flag is selected from the fixed bytecode table.
Rust: https://github.com/abiswas3/jolt/tree/main/crates/jolt-claims/src/protocols/jolt/geometry/bytecode.rs#L545-L557 -/
def opFlagsEqBytecodeRead {F : Type} [Field F] {params : WitnessParams}
    (program : JoltProgram) (witness : WitnessType F params) : Prop :=
  ∀ (flag : CircuitFlags) (t : Fin params.traceLength),
    witness.OpFlags flag t =
      ∑ address : Fin (2 ^ params.logBytecodeK),
        bytecodeCircuitFlag program flag address.val * bytecodeRa witness address t

/-- The honest witness satisfies constraint (46).
The bytecode domain must contain every program row and the leading no-op slot.
This bound prevents the address chunks from truncating an executed bytecode PC. -/
theorem honestWitness_opFlagsEqBytecodeRead
    {F : Type} [Field F] (params : WitnessParams)
    {program : JoltProgram} (trace : JoltTrace program)
    (ramFits : params.RamFits trace)
    (traceFits : params.ProverPaddedFor trace.rows.size)
    (bytecodeDomain : params.BytecodeDomainFor program.expandedBytecode.size) :
    opFlagsEqBytecodeRead program
      (JoltProgram.honestWitness (F := F) params trace ramFits traceFits bytecodeDomain) := by
  intro flag t
  rw [bytecodeRead_honest params trace ramFits traceFits bytecodeDomain
    (bytecodeCircuitFlag program flag) t]
  by_cases h : t.val < trace.rows.size
  · simp [JoltProgram.honestWitness, HonestWitness.OpFlags,
      HonestWitness.bytecodePc, bytecodeCircuitFlag, bytecodeRow, h]
  · cases flag <;>
      simp [JoltProgram.honestWitness, HonestWitness.OpFlags,
        HonestWitness.bytecodePc, bytecodeCircuitFlag, bytecodeRow, h]

end JoltConstraints
