always include AGENTS.md.
