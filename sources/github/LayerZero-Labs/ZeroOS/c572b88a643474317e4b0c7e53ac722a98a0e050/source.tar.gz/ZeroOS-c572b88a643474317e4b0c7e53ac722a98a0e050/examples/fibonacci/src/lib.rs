#![no_std]

pub fn fibonacci(n: u32) -> u128 {
    let mut a: u128 = 0;
    let mut b: u128 = 1;
    let mut sum: u128;

    for _ in 1..n {
        sum = a + b;
        a = b;
        b = sum;
    }
    b
}
