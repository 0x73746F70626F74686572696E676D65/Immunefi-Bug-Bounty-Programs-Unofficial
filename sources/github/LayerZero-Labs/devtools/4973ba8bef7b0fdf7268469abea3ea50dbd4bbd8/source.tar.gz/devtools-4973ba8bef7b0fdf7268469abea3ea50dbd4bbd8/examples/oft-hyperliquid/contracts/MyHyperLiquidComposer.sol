// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.22;

import { HyperLiquidComposer } from "@layerzerolabs/hyperliquid-composer/contracts/HyperLiquidComposer.sol";

/// @dev This contract is a composer that allows transfers of ERC20 and HYPE tokens to a target address on hypercore.
///
/// @dev This contract does NOT refund dust because we do not expect any due to truncation of sharedDecimals.
///      In the off-chance that you have dust you would have to implement dust refunds to the receiver in:
///      `_transferERC20ToHyperCore` and `_transferNativeToHyperCore`
///
/// @dev Disclaimer: If your token's evm total supply exceeds your asset bridge's balance when scaled to EVM,
///      it is possible that the composer will not be able to send the tokens to the receiver on hypercore.
///      Tokens would instead be returned to the sender address on HyperEVM. Front-end handling is recommended.
contract MyHyperLiquidComposer is HyperLiquidComposer {
    /// @notice Constructor for the HyperLiquidComposer
    ///
    /// @param _oft The address of the OFT
    /// @param _hlIndexId The HyperLiquid core spot's index value
    /// @param _assetDecimalDiff The decimal difference: ERC20.decimals() - HIP1.weiDecimals() (must be in [-2, 18])
    constructor(
        address _oft,
        uint64 _hlIndexId,
        int8 _assetDecimalDiff
    ) HyperLiquidComposer(_oft, _hlIndexId, _assetDecimalDiff) {}
}
