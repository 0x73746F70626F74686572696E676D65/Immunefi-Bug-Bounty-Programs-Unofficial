# @layerzerolabs/oapp-solana-example

## 0.2.0

### Minor Changes

- 6c95cd3: migrate oapp-solana to LzReceiveTypesV2

## 0.1.5

### Patch Changes

- e64021c: apply fix around message library and config PDAs checks

## 0.1.4

### Patch Changes

- 7ef51d7: bump up versions for anchor, solana, rust

## 0.1.3

### Patch Changes

- c44e657: update evm networks used
- e415855: rename retryPayload to retryMessage

## 0.1.2

### Patch Changes

- 5e15a8d: Add lockfiles to example packages

## 0.1.1

### Patch Changes

- f829409: Fixing comments on config files
