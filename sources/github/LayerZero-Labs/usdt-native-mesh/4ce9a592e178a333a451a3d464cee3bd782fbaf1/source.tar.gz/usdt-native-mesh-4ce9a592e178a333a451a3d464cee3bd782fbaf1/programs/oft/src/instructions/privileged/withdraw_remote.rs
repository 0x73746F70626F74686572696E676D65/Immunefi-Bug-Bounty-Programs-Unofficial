use crate::{
    errors::OFTError,
    events::RemoteWithdrawn,
    instructions::{build_msg_and_options, SendParams},
    state::{Credits, OFTStore, PeerConfig},
    types::MessageType,
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;
use oapp::endpoint::{instructions::SendParams as EndpointSendParams, MessagingReceipt};

#[event_cpi]
#[derive(Accounts)]
#[instruction(params: SendParams)]
pub struct WithdrawRemote<'info> {
    #[account(constraint = oft_store.only_lp_admin_or_super_admin(admin.key) @ OFTError::Unauthorized)]
    pub admin: Signer<'info>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(mut, seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
}

impl WithdrawRemote<'_> {
    pub fn apply(
        ctx: &mut Context<WithdrawRemote>,
        params: &SendParams,
    ) -> Result<MessagingReceipt> {
        // We use minAmountLd to follow same pattern as the TON implementation
        ctx.accounts.credits.decrease_credits(params.dst_eid, params.min_amount_ld)?;

        let (message, options) = build_msg_and_options(
            MessageType::WithdrawRemote,
            params.dst_eid,
            &params.to,
            params.min_amount_ld, // same as amount_sd
            &ctx.accounts.admin.key(),
            &params.compose_msg,
            &params.extra_options,
            &ctx.accounts.peer.enforced_options,
        )?;

        let msg_receipt = oapp::endpoint_cpi::send(
            ctx.accounts.oft_store.endpoint_program,
            ctx.accounts.oft_store.key(),
            ctx.remaining_accounts,
            &ctx.accounts.oft_store.signer_seeds(),
            EndpointSendParams {
                dst_eid: params.dst_eid,
                receiver: ctx.accounts.peer.peer_address,
                message,
                options,
                native_fee: params.native_fee,
                lz_token_fee: params.lz_token_fee,
            },
        )?;

        emit_cpi!(RemoteWithdrawn {
            guid: msg_receipt.guid,
            dst_eid: params.dst_eid,
            amount_ld: params.min_amount_ld,
        });

        Ok(msg_receipt)
    }
}
