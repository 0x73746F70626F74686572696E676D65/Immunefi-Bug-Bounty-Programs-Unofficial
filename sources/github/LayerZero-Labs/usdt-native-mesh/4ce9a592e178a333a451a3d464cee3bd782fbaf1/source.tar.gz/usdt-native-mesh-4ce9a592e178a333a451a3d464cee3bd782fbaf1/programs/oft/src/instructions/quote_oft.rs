use crate::{
    instructions::debit_view,
    state::{Credits, OFTStore, PeerConfig},
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;

#[derive(Accounts)]
#[instruction(params: QuoteOFTParams)]
pub struct QuoteOFT<'info> {
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
}

impl QuoteOFT<'_> {
    pub fn apply(ctx: &Context<QuoteOFT>, params: &QuoteOFTParams) -> Result<QuoteOFTResult> {
        let max_amount_ld = ctx.accounts.credits.get_credits(params.dst_eid)?;
        let oft_limits = OFTLimits { min_amount_ld: 0, max_amount_ld };

        // Unused in this implementation
        let oft_fee_details = vec![];

        // This is the same as the send() operation, but without the actual send.
        // - amountSent is the amount that would be debited from the sender.
        // - amountReceived is the amount that will be credited to the recipient.
        // The diff is the fee amount to be applied
        let (amount_sent_ld, amount_received_ld, _oft_fee_ld) =
            debit_view(params.amount_ld, params.min_amount_ld, ctx.accounts.oft_store.fee_bps)?;
        let oft_receipt = OFTReceipt { amount_sent_ld, amount_received_ld };

        Ok(QuoteOFTResult { oft_limits, oft_fee_details, oft_receipt })
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct QuoteOFTParams {
    pub dst_eid: u32,
    pub to: [u8; 32],
    pub amount_ld: u64,
    pub min_amount_ld: u64,
    pub extra_options: Vec<u8>,
    pub compose_msg: Option<Vec<u8>>,
    pub pay_in_lz_token: bool,
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct QuoteOFTResult {
    pub oft_limits: OFTLimits,
    pub oft_fee_details: Vec<OFTFeeDetail>,
    pub oft_receipt: OFTReceipt,
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct OFTFeeDetail {
    pub fee_amount_ld: u64,
    pub description: String,
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct OFTReceipt {
    pub amount_sent_ld: u64,
    pub amount_received_ld: u64,
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct OFTLimits {
    pub min_amount_ld: u64,
    pub max_amount_ld: u64,
}
