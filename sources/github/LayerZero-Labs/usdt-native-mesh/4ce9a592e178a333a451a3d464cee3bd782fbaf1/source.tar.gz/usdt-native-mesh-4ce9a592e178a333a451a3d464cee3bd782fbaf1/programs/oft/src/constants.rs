pub const OFT_SEED: &[u8] = b"OFT";
pub const PEER_SEED: &[u8] = b"Peer";
pub const CREDITS_SEED: &[u8] = b"Credits";

pub const SHARED_DECIMALS: u8 = 6;
pub const BPS_DENOMINATOR: u128 = 10_000;
// re-export the Endpoint IDs
pub use env::*;

// Environment-specific Endpoint IDs (EIDs)
// Select one of the Cargo features: "mainnet", "testnet", or "sandbox".
// Default is "mainnet".
#[cfg(feature = "mainnet")]
mod env {
    pub const SOLANA_EID: u32 = 30168;
    pub const ARBITRUM_EID: u32 = 30110;
    pub const CELO_EID: u32 = 30125;
    pub const ETH_EID: u32 = 30101;
    pub const TON_EID: u32 = 30343;
    pub const TRON_EID: u32 = 30420;
}

#[cfg(all(feature = "testnet", not(feature = "mainnet")))]
mod env {
    pub const SOLANA_EID: u32 = 40168;
    pub const ARBITRUM_EID: u32 = 40231;
    pub const CELO_EID: u32 = 40125;
    pub const ETH_EID: u32 = 40161;
    pub const TON_EID: u32 = 40343;
    pub const TRON_EID: u32 = 40420;
}

#[cfg(not(any(feature = "mainnet", feature = "testnet")))]
mod env {
    pub const SOLANA_EID: u32 = 50168;
    pub const ARBITRUM_EID: u32 = 50231;
    pub const CELO_EID: u32 = 50125;
    pub const ETH_EID: u32 = 50121;
    pub const TON_EID: u32 = 50343;
    pub const TRON_EID: u32 = 50420;
}
