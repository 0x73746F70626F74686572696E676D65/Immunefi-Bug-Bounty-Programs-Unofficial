use crate::{
    events::LocalDeposit,
    state::{Credits, OFTStore},
    CREDITS_SEED, OFT_SEED, SOLANA_EID,
};
use anchor_lang::prelude::*;
use anchor_spl::token_interface::{self, Mint, TokenAccount, TokenInterface, TransferChecked};

#[event_cpi]
#[derive(Accounts)]
pub struct DepositLocal<'info> {
    pub signer: Signer<'info>,
    #[account(
        mut,
        token::authority = signer,
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_source: InterfaceAccount<'info, TokenAccount>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(
        mut,
        address = oft_store.token_escrow,
        token::authority = oft_store.key(),
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_escrow: InterfaceAccount<'info, TokenAccount>,
    #[account(mut, seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(
        address = oft_store.token_mint,
        mint::token_program = token_program
    )]
    pub token_mint: InterfaceAccount<'info, Mint>,
    pub token_program: Interface<'info, TokenInterface>,
}

impl DepositLocal<'_> {
    pub fn apply(ctx: &mut Context<DepositLocal>, params: &DepositLocalParams) -> Result<()> {
        token_interface::transfer_checked(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.token_source.to_account_info(),
                    mint: ctx.accounts.token_mint.to_account_info(),
                    to: ctx.accounts.token_escrow.to_account_info(),
                    authority: ctx.accounts.signer.to_account_info(),
                },
            ),
            params.amount_ld,
            ctx.accounts.token_mint.decimals,
        )?;
        ctx.accounts.credits.increase_credits(SOLANA_EID, params.amount_ld)?;
        emit_cpi!(LocalDeposit { amount_ld: params.amount_ld });
        Ok(())
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct DepositLocalParams {
    pub amount_ld: u64,
}
