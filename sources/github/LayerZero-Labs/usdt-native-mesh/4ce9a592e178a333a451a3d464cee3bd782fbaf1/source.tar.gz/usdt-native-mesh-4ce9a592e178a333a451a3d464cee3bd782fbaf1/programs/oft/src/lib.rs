use anchor_lang::prelude::*;

pub mod codec;
pub mod constants;
pub mod errors;
pub mod events;
pub mod instructions;
pub mod state;
pub mod types;

use constants::*;
use instructions::*;
use oapp::{
    endpoint::{MessagingFee, MessagingReceipt},
    lz_receive_types_v2::{LzReceiveTypesV2Accounts, LzReceiveTypesV2Result},
    LzReceiveParams,
};
use solana_helper::program_id_from_env;

declare_id!(Pubkey::new_from_array(program_id_from_env!(
    "OFT_ID",
    "9UovNrJD8pQyBLheeHNayuG1wJSEAoxkmM14vw5gcsTT"
)));

#[program]
pub mod oft {

    use super::*;
    pub fn oft_version(_ctx: Context<OFTVersion>) -> Result<Version> {
        Ok(Version { interface: 2, message: 1 })
    }

    // =============================== PRIVILEGED INSTRUCTIONS ===============================

    pub fn init_oft(mut ctx: Context<InitOFT>, params: InitOFTParams) -> Result<()> {
        InitOFT::apply(&mut ctx, &params)
    }

    pub fn burn(mut ctx: Context<Burn>, params: BurnParams) -> Result<()> {
        Burn::apply(&mut ctx, &params)
    }

    pub fn nilify(mut ctx: Context<Nilify>, params: NilifyParams) -> Result<()> {
        Nilify::apply(&mut ctx, &params)
    }

    pub fn set_oft_config(
        mut ctx: Context<SetOFTConfig>,
        params: SetOFTConfigParams,
    ) -> Result<()> {
        SetOFTConfig::apply(&mut ctx, &params)
    }

    pub fn set_peer_config(
        mut ctx: Context<SetPeerConfig>,
        params: SetPeerConfigParams,
    ) -> Result<()> {
        SetPeerConfig::apply(&mut ctx, &params)
    }

    pub fn deposit_local(mut ctx: Context<DepositLocal>, params: DepositLocalParams) -> Result<()> {
        DepositLocal::apply(&mut ctx, &params)
    }

    pub fn withdraw_local(
        mut ctx: Context<WithdrawLocal>,
        params: WithdrawLocalParams,
    ) -> Result<()> {
        WithdrawLocal::apply(&mut ctx, &params)
    }

    pub fn quote_withdraw_remote(
        mut ctx: Context<QuoteWithdrawRemote>,
        params: QuoteSendParams,
    ) -> Result<MessagingFee> {
        QuoteWithdrawRemote::apply(&mut ctx, &params)
    }

    pub fn withdraw_remote(
        mut ctx: Context<WithdrawRemote>,
        params: SendParams,
    ) -> Result<MessagingReceipt> {
        WithdrawRemote::apply(&mut ctx, &params)
    }

    pub fn withdraw_fees(mut ctx: Context<WithdrawFees>, params: WithdrawFeesParams) -> Result<()> {
        WithdrawFees::apply(&mut ctx, &params)
    }

    pub fn quote_send_credits(
        mut ctx: Context<QuoteSendCredits>,
        params: QuoteSendCreditsParams,
    ) -> Result<MessagingFee> {
        QuoteSendCredits::apply(&mut ctx, &params)
    }

    pub fn send_credits(
        mut ctx: Context<SendCredits>,
        params: SendCreditsParams,
    ) -> Result<MessagingReceipt> {
        SendCredits::apply(&mut ctx, &params)
    }

    // =============================== OFT INSTRUCTIONS ===============================

    pub fn quote_oft(mut ctx: Context<QuoteOFT>, params: QuoteOFTParams) -> Result<QuoteOFTResult> {
        QuoteOFT::apply(&mut ctx, &params)
    }

    pub fn quote_send(
        mut ctx: Context<QuoteSend>,
        params: QuoteSendParams,
    ) -> Result<MessagingFee> {
        QuoteSend::apply(&mut ctx, &params)
    }

    pub fn send(
        mut ctx: Context<Send>,
        params: SendParams,
    ) -> Result<(MessagingReceipt, OFTReceipt)> {
        Send::apply(&mut ctx, &params)
    }

    // =============================== LZ RECEIVE INSTRUCTIONS ===============================

    pub fn lz_receive_types_info(
        mut ctx: Context<LzReceiveTypesInfo>,
        params: LzReceiveParams,
    ) -> Result<(u8, LzReceiveTypesV2Accounts)> {
        LzReceiveTypesInfo::apply(&mut ctx, &params)
    }

    pub fn lz_receive_types_v2(
        mut ctx: Context<LzReceiveTypesV2>,
        params: LzReceiveParams,
    ) -> Result<LzReceiveTypesV2Result> {
        LzReceiveTypesV2::apply(&mut ctx, &params)
    }

    pub fn lz_receive(mut ctx: Context<LzReceive>, params: LzReceiveParams) -> Result<()> {
        LzReceive::apply(&mut ctx, &params)
    }
}

#[derive(Accounts)]
pub struct OFTVersion {}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct Version {
    pub interface: u64,
    pub message: u64,
}
