use crate::{
    errors::OFTError,
    events::{
        AddressLookupTableSet, BurnAndNilifyAdminSet, FeeBpsSet, LpAdminSet, PlannerSet,
        SuperAdminSet,
    },
    state::OFTStore,
    BPS_DENOMINATOR, OFT_SEED,
};
use anchor_lang::prelude::*;
use oapp::endpoint::instructions::SetDelegateParams;

#[event_cpi]
#[derive(Accounts)]
pub struct SetOFTConfig<'info> {
    #[account(constraint = oft_store.only_super_admin(admin.key) @ OFTError::Unauthorized)]
    pub admin: Signer<'info>,
    #[account(mut, seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
}

impl SetOFTConfig<'_> {
    pub fn apply(ctx: &mut Context<SetOFTConfig>, params: &SetOFTConfigParams) -> Result<()> {
        match params.clone() {
            SetOFTConfigParams::SuperAdmin(super_admin) => {
                ctx.accounts.oft_store.super_admin = super_admin;
                emit_cpi!(SuperAdminSet { address: super_admin });
            },
            SetOFTConfigParams::Planner(planner) => {
                ctx.accounts.oft_store.planner = planner;
                emit_cpi!(PlannerSet { address: planner });
            },
            SetOFTConfigParams::LpAdmin(lp_admin) => {
                ctx.accounts.oft_store.lp_admin = lp_admin;
                emit_cpi!(LpAdminSet { address: lp_admin });
            },
            SetOFTConfigParams::BurnAndNilifyAdmin(burn_and_nilify_admin) => {
                ctx.accounts.oft_store.burn_and_nilify_admin = burn_and_nilify_admin;
                emit_cpi!(BurnAndNilifyAdminSet { address: burn_and_nilify_admin });
            },
            SetOFTConfigParams::FeeBps(fee_bps) => {
                require!(fee_bps < BPS_DENOMINATOR as u16, OFTError::InvalidFeeBps);
                ctx.accounts.oft_store.fee_bps = fee_bps;
                emit_cpi!(FeeBpsSet { fee_bps });
            },
            SetOFTConfigParams::AddressLookupTable(alt) => {
                ctx.accounts.oft_store.alt = alt;
                emit_cpi!(AddressLookupTableSet { address: alt });
            },
            SetOFTConfigParams::Delegate(delegate) => {
                let oft_store = &ctx.accounts.oft_store;
                oapp::endpoint_cpi::set_delegate(
                    oft_store.endpoint_program,
                    oft_store.key(),
                    &ctx.remaining_accounts,
                    &oft_store.signer_seeds(),
                    SetDelegateParams { delegate },
                )?;
            },
        }
        Ok(())
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub enum SetOFTConfigParams {
    SuperAdmin(Pubkey),
    Delegate(Pubkey), // OApp delegate for the endpoint
    Planner(Pubkey),
    LpAdmin(Pubkey),
    BurnAndNilifyAdmin(Pubkey),
    FeeBps(u16),
    AddressLookupTable(Option<Pubkey>),
}
