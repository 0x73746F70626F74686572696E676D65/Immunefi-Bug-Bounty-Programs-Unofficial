use crate::{
    codec::msg_codec,
    errors::OFTError,
    events::OFTSent,
    instructions::{debit_view, OFTReceipt},
    state::{Credits, EnforcedOptions, OFTStore, PeerConfig},
    types::MessageType,
    CREDITS_SEED, OFT_SEED, PEER_SEED, SOLANA_EID, TON_EID,
};
use anchor_lang::prelude::*;
use anchor_spl::token_interface::{self, Mint, TokenAccount, TokenInterface, TransferChecked};
use oapp::endpoint::{instructions::SendParams as EndpointSendParams, MessagingReceipt};

#[event_cpi]
#[derive(Accounts)]
#[instruction(params: SendParams)]
pub struct Send<'info> {
    pub signer: Signer<'info>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
    #[account(mut, seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(mut, seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(
        mut,
        token::authority = signer,
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_source: InterfaceAccount<'info, TokenAccount>,
    #[account(
        mut,
        address = oft_store.token_escrow,
        token::authority = oft_store.key(),
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_escrow: InterfaceAccount<'info, TokenAccount>,
    #[account(
        address = oft_store.token_mint,
        mint::token_program = token_program
    )]
    pub token_mint: InterfaceAccount<'info, Mint>,
    pub token_program: Interface<'info, TokenInterface>,
}

impl Send<'_> {
    pub fn apply(
        ctx: &mut Context<Send>,
        params: &SendParams,
    ) -> Result<(MessagingReceipt, OFTReceipt)> {
        // Applies fees and determines the total amount to deduct from the token source, and the amount received
        let (amount_sent_ld, amount_received_ld, oft_fee_ld) =
            debit_view(params.amount_ld, params.min_amount_ld, ctx.accounts.oft_store.fee_bps)?;

        // transfer all tokens to escrow
        token_interface::transfer_checked(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.token_source.to_account_info(),
                    mint: ctx.accounts.token_mint.to_account_info(),
                    to: ctx.accounts.token_escrow.to_account_info(),
                    authority: ctx.accounts.signer.to_account_info(),
                },
            ),
            amount_sent_ld,
            ctx.accounts.token_mint.decimals,
        )?;

        // Update the fee balance and credits
        ctx.accounts.oft_store.fee_balance += oft_fee_ld;
        ctx.accounts.credits.decrease_credits(params.dst_eid, amount_received_ld)?;
        ctx.accounts.credits.increase_credits(SOLANA_EID, amount_received_ld)?;

        // Build the message and options
        let (message, options) = build_msg_and_options(
            MessageType::SendOFT,
            params.dst_eid,
            &params.to,
            amount_received_ld, // same as amount_sd
            &ctx.accounts.signer.key(),
            &params.compose_msg,
            &params.extra_options,
            &ctx.accounts.peer.enforced_options,
        )?;

        // send message to endpoint
        let msg_receipt = oapp::endpoint_cpi::send(
            ctx.accounts.oft_store.endpoint_program,
            ctx.accounts.oft_store.key(),
            ctx.remaining_accounts,
            &ctx.accounts.oft_store.signer_seeds(),
            EndpointSendParams {
                dst_eid: params.dst_eid,
                receiver: ctx.accounts.peer.peer_address,
                message,
                options,
                native_fee: params.native_fee,
                lz_token_fee: params.lz_token_fee,
            },
        )?;

        emit_cpi!(OFTSent {
            guid: msg_receipt.guid,
            dst_eid: params.dst_eid,
            from: ctx.accounts.token_source.key(),
            amount_sent_ld,
            amount_received_ld
        });

        Ok((msg_receipt, OFTReceipt { amount_sent_ld, amount_received_ld }))
    }
}

pub(crate) fn build_msg_and_options(
    msg_type: MessageType,
    dst_eid: u32,
    send_to: &[u8; 32],
    amount_sd: u64,
    sender: &Pubkey,
    compose_msg: &Option<Vec<u8>>,
    options: &Vec<u8>,
    enforced_options: &EnforcedOptions,
) -> Result<(Vec<u8>, Vec<u8>)> {
    let message = msg_codec::encode(send_to, amount_sd, sender, compose_msg);

    let msg_type = if compose_msg.is_some() {
        require!(TON_EID != dst_eid, OFTError::TONComposeNotSupported);
        MessageType::SendOFTAndCall
    } else {
        msg_type
    };

    require!(amount_sd > 0, OFTError::InvalidAmount);
    let message = {
        let mut message_with_type = Vec::with_capacity(2 + message.len());
        message_with_type.extend_from_slice(&(msg_type.clone() as u16).to_be_bytes());
        message_with_type.extend_from_slice(&message);
        message_with_type
    };
    let options = enforced_options.combine_options(&msg_type, options)?;
    Ok((message, options))
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct SendParams {
    pub dst_eid: u32,
    pub to: [u8; 32],
    pub amount_ld: u64,
    pub min_amount_ld: u64,
    pub extra_options: Vec<u8>,
    pub compose_msg: Option<Vec<u8>>,
    pub native_fee: u64,
    pub lz_token_fee: u64,
}
