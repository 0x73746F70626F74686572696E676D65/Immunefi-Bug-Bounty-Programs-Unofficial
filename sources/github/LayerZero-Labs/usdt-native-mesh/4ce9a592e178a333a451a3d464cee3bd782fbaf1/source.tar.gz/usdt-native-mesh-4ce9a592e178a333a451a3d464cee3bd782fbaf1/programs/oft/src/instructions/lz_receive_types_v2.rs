use crate::{
    codec::{compose_msg_codec, msg_codec},
    errors::OFTError,
    instructions::extract_message_type_and_payload,
    state::OFTStore,
    types::MessageType,
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::{prelude::*, solana_program};
use anchor_spl::{
    associated_token::get_associated_token_address_with_program_id, token_interface::Mint,
};
use oapp::{
    common::{
        compact_accounts_with_alts, AccountMetaRef, AddressLocator, EXECUTION_CONTEXT_VERSION_1,
    },
    lz_receive_types_v2::{
        get_accounts_for_clear, get_accounts_for_send_compose, Instruction, LzReceiveTypesV2Result,
    },
    LzReceiveParams,
};

/// LzReceiveTypesV2 instruction implements the V2 framework for resolving account dependencies.
///
/// V2 introduces an extensible and optimized framework addressing V1 limitations by introducing:
/// - Support for multiple ALTs to increase the number of accounts
/// - A compact and flexible account reference model via AddressLocator
/// - Explicit support for multiple EOA signers, enabling dynamic data account initialization
/// - A multi-instruction execution model for complex workflows within a single atomic transaction
///
/// Unlike V1's single-instruction CPI-based execution model, V2 adopts a transaction-based
/// execution model to avoid Solana's CPI depth limitation of 4, making ABA messaging patterns
/// feasible.
///
/// The Counter implementation demonstrates:
/// - Basic account resolution using ALT address mapping
/// - Multi-instruction execution with both LzReceive and Standard instructions
/// - Integration with endpoint operations for message processing
#[derive(Accounts)]
#[instruction(params: LzReceiveParams)]
pub struct LzReceiveTypesV2<'info> {
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(address = oft_store.token_mint)]
    pub token_mint: InterfaceAccount<'info, Mint>,
}

impl LzReceiveTypesV2<'_> {
    /// Returns the account dependencies and execution plan for lz_receive
    ///
    /// This instruction is called by the Executor after resolving version and account data
    /// from lz_receive_types_info. It returns a complete execution plan including:
    /// - ALTs required for this execution context (from remaining_accounts)
    /// - List of instructions required for LzReceive (including exactly one LzReceive instruction)
    ///
    /// The Counter implementation demonstrates V2 features:
    /// - Address Lookup Table (ALT) support for efficient account referencing
    /// - Multi-instruction execution (LzReceive + verification instruction)
    ///
    /// # Arguments
    /// * `ctx` - Context containing the count account and remaining_accounts (ALTs)
    /// * `params` - LayerZero receive parameters including message content and metadata
    ///
    /// # Returns
    /// LzReceiveTypesV2Result containing ALTs and instruction list for execution
    pub fn apply(
        ctx: &Context<LzReceiveTypesV2>,
        params: &LzReceiveParams,
    ) -> Result<LzReceiveTypesV2Result> {
        // There are two accounts that are used in the LzReceive instruction,
        // except those accounts for endpoint program.
        let oft_store = &ctx.accounts.oft_store;

        // The second account is the peer account, we find it by the params.src_eid.
        let peer_seeds = [PEER_SEED, &params.src_eid.to_be_bytes()];
        let (peer, _) = Pubkey::find_program_address(&peer_seeds, ctx.program_id);

        // The third account is the credits account
        let credits_seeds = [CREDITS_SEED];
        let (credits, _) = Pubkey::find_program_address(&credits_seeds, &ctx.program_id);

        // The fourth account is the token mint
        let token_mint = oft_store.token_mint;
        let token_program = ctx.accounts.token_mint.to_account_info().owner;

        let (msg_type, msg_without_msg_type) = extract_message_type_and_payload(&params.message)?;
        let (to_address, token_dest) = match msg_type {
            MessageType::SendCredits => (ctx.program_id.key(), ctx.program_id.key()),
            _ => {
                let to_address = Pubkey::from(msg_codec::send_to(msg_without_msg_type));
                let token_dest = get_associated_token_address_with_program_id(
                    &to_address,
                    &token_mint,
                    &token_program,
                );
                (to_address, token_dest)
            },
        };

        let (event_authority_account, _) =
            Pubkey::find_program_address(&[oapp::endpoint_cpi::EVENT_SEED], &ctx.program_id);

        let mut accounts = vec![
            // payer
            AccountMetaRef { pubkey: AddressLocator::Payer, is_writable: true },
            // peer
            AccountMetaRef { pubkey: peer.into(), is_writable: false },
            // oft_store
            AccountMetaRef { pubkey: oft_store.key().into(), is_writable: false },
            // credits
            AccountMetaRef { pubkey: credits.key().into(), is_writable: true },
            // token_escrow
            AccountMetaRef { pubkey: oft_store.token_escrow.into(), is_writable: true },
            // to_address - the wallet address to receive the token
            AccountMetaRef { pubkey: to_address.into(), is_writable: false },
            // token_dest - the associated token account for the to_address
            AccountMetaRef { pubkey: token_dest.into(), is_writable: true },
            // token_mint
            AccountMetaRef { pubkey: token_mint.into(), is_writable: false },
            // token_program
            AccountMetaRef { pubkey: token_program.clone().into(), is_writable: false },
            // associated token program
            AccountMetaRef { pubkey: anchor_spl::associated_token::ID.into(), is_writable: false },
            // system program
            AccountMetaRef {
                pubkey: solana_program::system_program::ID.into(),
                is_writable: false,
            },
            // event authority account - used for event logging
            AccountMetaRef { pubkey: event_authority_account.into(), is_writable: false },
            // program id - the program that is executing this instruction
            AccountMetaRef { pubkey: crate::ID.into(), is_writable: false },
        ];

        // Add accounts required for LayerZero's clear operation
        // These accounts handle the core message verification and processing
        let accounts_for_clear: Vec<AccountMetaRef> = get_accounts_for_clear(
            oft_store.endpoint_program,
            &oft_store.key(),
            params.src_eid,
            &params.sender,
            params.nonce,
        );
        accounts.extend(accounts_for_clear);

        // If message is composed, add accounts for send compose operation
        if msg_type == MessageType::SendOFTAndCall {
            let amount_received_ld = msg_codec::amount_sd(msg_without_msg_type); // same as amount_sd
            let compose_msg =
                msg_codec::compose_msg(msg_without_msg_type).ok_or(OFTError::InvalidMessage)?;
            let accounts_for_composing = get_accounts_for_send_compose(
                oft_store.endpoint_program,
                &ctx.accounts.oft_store.key(),
                &to_address,
                &params.guid,
                0,
                &compose_msg_codec::encode(
                    params.nonce,
                    params.src_eid,
                    amount_received_ld,
                    &compose_msg,
                ),
            );
            accounts.extend(accounts_for_composing);
        }

        // Return the complete execution plan with ALTs and instructions
        Ok(LzReceiveTypesV2Result {
            context_version: EXECUTION_CONTEXT_VERSION_1,
            alts: ctx.remaining_accounts.iter().map(|alt| alt.key()).collect(),
            instructions: vec![
                // Main LzReceive instruction - processes the cross-chain message
                Instruction::LzReceive {
                    accounts: compact_accounts_with_alts(&ctx.remaining_accounts, accounts)?,
                },
            ],
        })
    }
}
