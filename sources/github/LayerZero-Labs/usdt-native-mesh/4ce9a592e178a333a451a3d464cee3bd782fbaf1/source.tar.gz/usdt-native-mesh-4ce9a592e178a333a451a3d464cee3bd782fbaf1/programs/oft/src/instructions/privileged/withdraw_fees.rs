use crate::{errors::OFTError, events::FeesWithdrawn, state::OFTStore, OFT_SEED};
use anchor_lang::prelude::*;
use anchor_spl::token_interface::{self, Mint, TokenAccount, TokenInterface, TransferChecked};

#[event_cpi]
#[derive(Accounts)]
pub struct WithdrawFees<'info> {
    #[account(constraint = oft_store.only_lp_admin_or_super_admin(admin.key) @ OFTError::Unauthorized)]
    pub admin: Signer<'info>,
    #[account(mut, seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(
        address = oft_store.token_mint,
        mint::token_program = token_program
    )]
    pub token_mint: InterfaceAccount<'info, Mint>,
    #[account(
        mut,
        address = oft_store.token_escrow,
        token::authority = oft_store,
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_escrow: InterfaceAccount<'info, TokenAccount>,
    #[account(
        mut,
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_dest: InterfaceAccount<'info, TokenAccount>,
    pub token_program: Interface<'info, TokenInterface>,
}

impl WithdrawFees<'_> {
    pub fn apply(ctx: &mut Context<WithdrawFees>, params: &WithdrawFeesParams) -> Result<()> {
        let oft_store = &mut ctx.accounts.oft_store;
        require!(oft_store.fee_balance >= params.amount_ld, OFTError::InsufficientFeeBalance);
        oft_store.fee_balance -= params.amount_ld;

        token_interface::transfer_checked(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.token_escrow.to_account_info(),
                    mint: ctx.accounts.token_mint.to_account_info(),
                    to: ctx.accounts.token_dest.to_account_info(),
                    authority: oft_store.to_account_info(),
                },
            )
            .with_signer(&[&oft_store.signer_seeds()]),
            params.amount_ld,
            ctx.accounts.token_mint.decimals,
        )?;
        emit_cpi!(FeesWithdrawn { to: ctx.accounts.token_dest.key(), amount_ld: params.amount_ld });
        Ok(())
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct WithdrawFeesParams {
    pub amount_ld: u64,
}
