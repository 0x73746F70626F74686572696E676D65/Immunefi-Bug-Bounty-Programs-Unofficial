use crate::{
    codec::credits_codec,
    state::{Credits, OFTStore, PeerConfig},
    types::{CreditsBatch, MessageType},
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;
use oapp::endpoint::{instructions::QuoteParams, MessagingFee};

#[derive(Accounts)]
#[instruction(params: QuoteSendCreditsParams)]
pub struct QuoteSendCredits<'info> {
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
}

impl QuoteSendCredits<'_> {
    pub fn apply(
        ctx: &Context<QuoteSendCredits>,
        params: &QuoteSendCreditsParams,
    ) -> Result<MessagingFee> {
        // ensure the credits are available
        ctx.accounts.credits.assert_credits_batch(&params.credits_batch)?;

        // encode message and options
        let message = credits_codec::encode(&params.credits_batch);
        let options = ctx
            .accounts
            .peer
            .enforced_options
            .combine_options(&MessageType::SendCredits, &params.extra_options)?;

        // calling endpoint quote cpi
        oapp::endpoint_cpi::quote(
            ctx.accounts.oft_store.endpoint_program,
            ctx.remaining_accounts,
            QuoteParams {
                sender: ctx.accounts.oft_store.key(),
                dst_eid: params.dst_eid,
                receiver: ctx.accounts.peer.peer_address,
                message,
                options,
                pay_in_lz_token: params.pay_in_lz_token,
            },
        )
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct QuoteSendCreditsParams {
    pub dst_eid: u32,
    pub credits_batch: CreditsBatch,
    pub extra_options: Vec<u8>,
    pub pay_in_lz_token: bool,
}
