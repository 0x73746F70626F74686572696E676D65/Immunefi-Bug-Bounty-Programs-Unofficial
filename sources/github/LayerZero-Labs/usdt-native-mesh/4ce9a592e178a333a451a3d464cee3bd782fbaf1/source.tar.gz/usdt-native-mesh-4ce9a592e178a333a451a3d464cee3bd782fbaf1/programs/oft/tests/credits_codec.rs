#[cfg(test)]
mod test_credits_codec {
    use oft::{codec::credits_codec, types::CreditsBatch};

    const CREDITS_BATCH: CreditsBatch = CreditsBatch {
        credits_arbitrum: 1,
        credits_celo: 2,
        credits_eth: 3,
        credits_solana: 4,
        credits_ton: 5,
        credits_tron: 6,
    };

    const ENCODED_CREDITS_BATCH: &[u8] = &[
        0, 3, // SendCredits
        0, 0, 0, 0, 0, 0, 0, 1, // arb
        0, 0, 0, 0, 0, 0, 0, 2, // celo
        0, 0, 0, 0, 0, 0, 0, 3, // eth
        0, 0, 0, 0, 0, 0, 0, 4, // sol
        0, 0, 0, 0, 0, 0, 0, 5, // ton
        0, 0, 0, 0, 0, 0, 0, 6, // tron
    ];

    #[test]
    fn test_encode() {
        let res: Vec<u8> = credits_codec::encode(&CREDITS_BATCH);
        assert_eq!(res.len(), 50);
        assert_eq!(res, ENCODED_CREDITS_BATCH);
    }

    #[test]
    fn test_decode() {
        let res: CreditsBatch = credits_codec::decode(ENCODED_CREDITS_BATCH).unwrap();
        assert_eq!(res, CREDITS_BATCH);
    }

    #[test]
    fn test_decode_incorrect_length() {
        let res = credits_codec::decode(&Vec::<u8>::new());
        assert!(res.is_err());
        match res {
            Err(err) => {
                let err_str = err.to_string();
                assert!(err_str.contains("InvalidMessage"));
                assert!(err_str.contains("6009"));
            },
            Ok(_) => panic!("Expected an error but got Ok"),
        }
    }

    #[test]
    fn test_decode_incorrect_message_type() {
        let mut incorrect_message_type = ENCODED_CREDITS_BATCH.to_vec();
        incorrect_message_type[1] = 99; // Change message type to invalid value

        let res = credits_codec::decode(&incorrect_message_type);
        assert!(res.is_err());
        match res {
            Err(err) => {
                let err_str = err.to_string();
                assert!(err_str.contains("InvalidMessage"));
                assert!(err_str.contains("6009"));
            },
            Ok(_) => panic!("Expected an error but got Ok"),
        }
    }

    #[test]
    fn test_decode_without_msg_type() {
        let res: CreditsBatch =
            credits_codec::decode_msg_without_msg_type(&ENCODED_CREDITS_BATCH[2..]).unwrap();
        assert_eq!(res, CREDITS_BATCH);
    }

    #[test]
    fn test_decode_without_msg_type_incorrect_length() {
        let res = credits_codec::decode_msg_without_msg_type(&Vec::<u8>::new());
        assert!(res.is_err());
        match res {
            Err(err) => {
                let err_str = err.to_string();
                assert!(err_str.contains("InvalidMessage"));
                assert!(err_str.contains("6009"));
            },
            Ok(_) => panic!("Expected an error but got Ok"),
        }
    }
}
