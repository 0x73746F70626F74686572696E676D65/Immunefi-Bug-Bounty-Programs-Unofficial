use crate::{
    errors::OFTError,
    events::LocalWithdrawn,
    state::{Credits, OFTStore},
    CREDITS_SEED, OFT_SEED, SOLANA_EID,
};
use anchor_lang::prelude::*;
use anchor_spl::token_interface::{self, Mint, TokenAccount, TokenInterface, TransferChecked};

#[event_cpi]
#[derive(Accounts)]
#[instruction(params: WithdrawLocalParams)]
pub struct WithdrawLocal<'info> {
    #[account(constraint = oft_store.only_lp_admin_or_super_admin(admin.key) @ OFTError::Unauthorized)]
    pub admin: Signer<'info>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(mut, seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(
        mut,
        address = oft_store.token_escrow,
        token::authority = oft_store.key(),
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_escrow: InterfaceAccount<'info, TokenAccount>,
    #[account(
        mut,
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_dest: InterfaceAccount<'info, TokenAccount>,
    #[account(
        address = oft_store.token_mint,
        mint::token_program = token_program
    )]
    pub token_mint: InterfaceAccount<'info, Mint>,
    pub token_program: Interface<'info, TokenInterface>,
}

impl WithdrawLocal<'_> {
    pub fn apply(ctx: &mut Context<WithdrawLocal>, params: &WithdrawLocalParams) -> Result<()> {
        let amount_ld = params.amount_ld;
        ctx.accounts.credits.decrease_credits(SOLANA_EID, amount_ld)?;

        let oft_store = &ctx.accounts.oft_store;
        token_interface::transfer_checked(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.token_escrow.to_account_info(),
                    mint: ctx.accounts.token_mint.to_account_info(),
                    to: ctx.accounts.token_dest.to_account_info(),
                    authority: oft_store.to_account_info(),
                },
            )
            .with_signer(&[&oft_store.signer_seeds()]),
            amount_ld,
            ctx.accounts.token_mint.decimals,
        )?;
        emit_cpi!(LocalWithdrawn { to: ctx.accounts.token_dest.key(), amount_ld });
        Ok(())
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct WithdrawLocalParams {
    pub amount_ld: u64,
}
