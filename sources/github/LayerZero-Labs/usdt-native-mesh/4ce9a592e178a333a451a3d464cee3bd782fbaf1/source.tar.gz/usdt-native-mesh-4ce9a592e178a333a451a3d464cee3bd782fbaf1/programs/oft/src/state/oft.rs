use crate::OFT_SEED;
use anchor_lang::prelude::*;

#[account]
#[derive(InitSpace)]
pub struct OFTStore {
    // immutable
    pub token_mint: Pubkey,
    // this account is used to hold TVL and fees
    // TVL(total value locked) = balance of token_escrow - fee_balance
    pub token_escrow: Pubkey,
    pub endpoint_program: Pubkey,
    pub bump: u8,
    // mutable
    pub fee_balance: u64,
    // configurable
    pub super_admin: Pubkey,
    pub planner: Pubkey,
    pub lp_admin: Pubkey,
    pub burn_and_nilify_admin: Pubkey,
    pub fee_bps: u16,
    pub alt: Option<Pubkey>, // Address Lookup Table
}

impl OFTStore {
    pub fn signer_seeds(&self) -> [&[u8]; 2] {
        [OFT_SEED, std::slice::from_ref(&self.bump)]
    }

    pub fn only_super_admin(&self, signer: &Pubkey) -> bool {
        self.super_admin == *signer
    }

    pub fn only_lp_admin_or_super_admin(&self, signer: &Pubkey) -> bool {
        self.lp_admin == *signer || self.super_admin == *signer
    }

    pub fn only_planner(&self, signer: &Pubkey) -> bool {
        self.planner == *signer
    }

    pub fn only_burn_and_nilify_admin(&self, signer: &Pubkey) -> bool {
        self.burn_and_nilify_admin == *signer
    }
}
