#[cfg(test)]
mod test_compose_msg_codec {
    use oft::codec::compose_msg_codec;

    const BASE_MESSAGE: &[u8] = &[0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 3];
    const MESSAGE_52_CHARS: &[u8] = b"0123456789012345678901234567890123456789012345678901";
    const MESSAGE_55_CHARS: &[u8] = b"0123456789012345678901234567890123456789012345678901ABC";

    #[test]
    fn test_encode() {
        let res: Vec<u8> = compose_msg_codec::encode(1, 2, 3, &Vec::<u8>::new());
        assert_eq!(res.len(), 20);
        assert_eq!(res, BASE_MESSAGE);
    }

    #[test]
    fn test_encode_with_compose_msg() {
        let compose_msg = [7, 8, 9].to_vec();
        let res: Vec<u8> = compose_msg_codec::encode(1, 2, 3, &compose_msg);

        assert_eq!(res.len(), 23);

        let mut expected = BASE_MESSAGE.to_vec();
        expected.extend_from_slice(&compose_msg);
        assert_eq!(res, expected);
    }

    #[test]
    fn test_nonce() {
        let res: u64 = compose_msg_codec::nonce(BASE_MESSAGE);
        assert_eq!(res, 1);
    }

    #[test]
    fn test_src_eid() {
        let res: u32 = compose_msg_codec::src_eid(BASE_MESSAGE);
        assert_eq!(res, 2);
    }

    #[test]
    fn test_amount_ld() {
        let res: u64 = compose_msg_codec::amount_ld(BASE_MESSAGE);
        assert_eq!(res, 3);
    }

    #[test]
    fn test_compose_from() {
        let res: [u8; 32] = compose_msg_codec::compose_from(MESSAGE_52_CHARS);
        assert_eq!(&res, b"01234567890123456789012345678901");
    }

    #[test]
    fn test_compose_empty_message() {
        let res: Vec<u8> = compose_msg_codec::compose_msg(b"");
        assert_eq!(res, Vec::<u8>::new());
    }

    #[test]
    fn test_compose_non_empty_message_52_chars() {
        let res: Vec<u8> = compose_msg_codec::compose_msg(MESSAGE_52_CHARS);
        assert_eq!(res, Vec::<u8>::new());
    }

    #[test]
    fn test_compose_non_empty_message_55_chars() {
        let res: Vec<u8> = compose_msg_codec::compose_msg(MESSAGE_55_CHARS);
        assert_eq!(res, b"ABC");
    }
}
