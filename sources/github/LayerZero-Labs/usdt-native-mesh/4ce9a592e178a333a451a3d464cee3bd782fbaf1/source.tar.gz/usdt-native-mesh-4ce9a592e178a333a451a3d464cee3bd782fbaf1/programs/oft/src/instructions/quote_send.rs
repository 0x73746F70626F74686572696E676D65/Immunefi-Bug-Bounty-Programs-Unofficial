use crate::{
    errors::OFTError,
    instructions::build_msg_and_options,
    state::{Credits, OFTStore, PeerConfig},
    types::MessageType,
    BPS_DENOMINATOR, CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;
use oapp::endpoint::{instructions::QuoteParams, MessagingFee};

#[derive(Accounts)]
#[instruction(params: QuoteSendParams)]
pub struct QuoteSend<'info> {
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
}

impl QuoteSend<'_> {
    pub fn apply(ctx: &Context<QuoteSend>, params: &QuoteSendParams) -> Result<MessagingFee> {
        // Mock the amount to receive, this is the same operation used in the send().
        let (_, amount_received_ld, _) =
            debit_view(params.amount_ld, params.min_amount_ld, ctx.accounts.oft_store.fee_bps)?;
        ctx.accounts.credits.assert_credits(params.dst_eid, amount_received_ld)?;

        let (message, options) = build_msg_and_options(
            MessageType::SendOFT,
            params.dst_eid,
            &params.to,
            amount_received_ld, // same as amount_sd
            &Pubkey::default(),
            &params.compose_msg,
            &params.extra_options,
            &ctx.accounts.peer.enforced_options,
        )?;

        // calling endpoint cpi
        oapp::endpoint_cpi::quote(
            ctx.accounts.oft_store.endpoint_program,
            ctx.remaining_accounts,
            QuoteParams {
                sender: ctx.accounts.oft_store.key(),
                dst_eid: params.dst_eid,
                receiver: ctx.accounts.peer.peer_address,
                message,
                options,
                pay_in_lz_token: params.pay_in_lz_token,
            },
        )
    }
}

pub fn debit_view(amount_ld: u64, min_amount_ld: u64, fee_bps: u16) -> Result<(u64, u64, u64)> {
    let amount_sent_ld = amount_ld;

    // Calculate the OFT fee based on the amount actually received after transfer fees
    let oft_fee = (amount_sent_ld as u128 * fee_bps as u128 / BPS_DENOMINATOR) as u64;

    let amount_received_ld = amount_sent_ld - oft_fee;
    require!(amount_received_ld >= min_amount_ld, OFTError::SlippageExceeded);

    Ok((amount_sent_ld, amount_received_ld, oft_fee))
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct QuoteSendParams {
    pub dst_eid: u32,
    pub to: [u8; 32],
    pub amount_ld: u64,
    pub min_amount_ld: u64,
    pub extra_options: Vec<u8>,
    pub compose_msg: Option<Vec<u8>>,
    pub pay_in_lz_token: bool,
}
