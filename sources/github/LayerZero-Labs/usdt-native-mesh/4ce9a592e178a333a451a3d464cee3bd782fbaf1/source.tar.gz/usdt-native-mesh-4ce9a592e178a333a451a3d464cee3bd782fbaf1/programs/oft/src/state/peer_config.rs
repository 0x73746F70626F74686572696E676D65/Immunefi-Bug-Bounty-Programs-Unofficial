use crate::types::MessageType;
use anchor_lang::prelude::*;

pub const ENFORCED_OPTIONS_WITHDRAW_REMOTE_MAX_LEN: usize = 512;
pub const ENFORCED_OPTIONS_SEND_OFT_MAX_LEN: usize = 512;
pub const ENFORCED_OPTIONS_SEND_CREDITS_MAX_LEN: usize = 512;
pub const ENFORCED_OPTIONS_SEND_AND_CALL_MAX_LEN: usize = 1024;

#[account]
#[derive(InitSpace)]
pub struct PeerConfig {
    pub peer_address: [u8; 32],
    pub enforced_options: EnforcedOptions,
    pub bump: u8,
}

#[derive(Clone, Default, AnchorSerialize, AnchorDeserialize, InitSpace)]
pub struct EnforcedOptions {
    #[max_len(ENFORCED_OPTIONS_WITHDRAW_REMOTE_MAX_LEN)]
    pub withdraw_remote: Vec<u8>,
    #[max_len(ENFORCED_OPTIONS_SEND_OFT_MAX_LEN)]
    pub send_oft: Vec<u8>,
    #[max_len(ENFORCED_OPTIONS_SEND_CREDITS_MAX_LEN)]
    pub send_credits: Vec<u8>,
    #[max_len(ENFORCED_OPTIONS_SEND_AND_CALL_MAX_LEN)]
    pub send_oft_and_call: Vec<u8>,
}

impl EnforcedOptions {
    pub fn get_enforced_options(&self, msg_type: &MessageType) -> Vec<u8> {
        match msg_type {
            MessageType::WithdrawRemote => self.withdraw_remote.clone(),
            MessageType::SendOFT => self.send_oft.clone(),
            MessageType::SendCredits => self.send_credits.clone(),
            MessageType::SendOFTAndCall => self.send_oft_and_call.clone(),
        }
    }

    pub fn combine_options(
        &self,
        msg_type: &MessageType,
        extra_options: &Vec<u8>,
    ) -> Result<Vec<u8>> {
        let enforced_options = self.get_enforced_options(msg_type);
        oapp::options::combine_options(enforced_options, extra_options)
    }
}
