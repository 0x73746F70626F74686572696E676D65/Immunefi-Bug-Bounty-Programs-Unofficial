use crate::types::CreditsBatch;
use anchor_lang::prelude::*;

#[event]
pub struct OFTSent {
    pub guid: [u8; 32],
    pub dst_eid: u32,
    pub from: Pubkey,
    pub amount_sent_ld: u64,
    pub amount_received_ld: u64,
}

#[event]
pub struct LocalDeposit {
    pub amount_ld: u64,
}

#[event]
pub struct CreditsSent {
    pub dst_eid: u32,
    pub credits_batch: CreditsBatch,
    pub guid: [u8; 32],
}

#[event]
pub struct CreditsReceived {
    pub guid: [u8; 32],
    pub src_eid: u32,
    pub message: Vec<u8>,
}

#[event]
pub struct OFTReceived {
    pub guid: [u8; 32],
    pub src_eid: u32,
    pub to: Pubkey,
    pub amount_received_ld: u64,
}

#[event]
pub struct RemoteWithdrawReceived {
    pub guid: [u8; 32],
    pub src_eid: u32,
    pub to: Pubkey,
    pub amount_received_ld: u64,
}

#[event]
pub struct FeesWithdrawn {
    pub to: Pubkey,
    pub amount_ld: u64,
}

#[event]
pub struct LocalWithdrawn {
    pub to: Pubkey,
    pub amount_ld: u64,
}

#[event]
pub struct RemoteWithdrawn {
    pub guid: [u8; 32],
    pub dst_eid: u32,
    pub amount_ld: u64,
}

#[event]
pub struct SuperAdminSet {
    pub address: Pubkey,
}

#[event]
pub struct LpAdminSet {
    pub address: Pubkey,
}

#[event]
pub struct PlannerSet {
    pub address: Pubkey,
}

#[event]
pub struct BurnAndNilifyAdminSet {
    pub address: Pubkey,
}

#[event]
pub struct FeeBpsSet {
    pub fee_bps: u16,
}

#[event]
pub struct AddressLookupTableSet {
    pub address: Option<Pubkey>,
}

#[event]
pub struct PeerAddressSet {
    pub address: [u8; 32],
}

#[event]
pub struct EnforcedOptionsSet {
    pub send: Vec<u8>,
    pub send_and_call: Vec<u8>,
    pub send_credits: Vec<u8>,
    pub withdraw_remote: Vec<u8>,
}
