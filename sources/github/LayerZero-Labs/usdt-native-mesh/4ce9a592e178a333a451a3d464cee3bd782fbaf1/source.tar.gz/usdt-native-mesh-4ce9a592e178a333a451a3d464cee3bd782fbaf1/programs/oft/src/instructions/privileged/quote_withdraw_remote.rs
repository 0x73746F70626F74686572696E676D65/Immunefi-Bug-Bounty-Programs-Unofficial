use crate::{
    instructions::{build_msg_and_options, QuoteSendParams},
    state::{Credits, OFTStore, PeerConfig},
    types::MessageType,
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;
use oapp::endpoint::{instructions::QuoteParams, MessagingFee};

#[derive(Accounts)]
#[instruction(params: QuoteSendParams)]
pub struct QuoteWithdrawRemote<'info> {
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
}

impl QuoteWithdrawRemote<'_> {
    pub fn apply(
        ctx: &Context<QuoteWithdrawRemote>,
        params: &QuoteSendParams,
    ) -> Result<MessagingFee> {
        // We use minAmountLd to follow same pattern as the TON implementation
        ctx.accounts.credits.assert_credits(params.dst_eid, params.min_amount_ld)?;

        let (message, options) = build_msg_and_options(
            MessageType::WithdrawRemote,
            params.dst_eid,
            &params.to,
            params.min_amount_ld, // same as amount_sd
            &Pubkey::default(),
            &params.compose_msg,
            &params.extra_options,
            &ctx.accounts.peer.enforced_options,
        )?;

        // calling endpoint cpi
        oapp::endpoint_cpi::quote(
            ctx.accounts.oft_store.endpoint_program,
            ctx.remaining_accounts,
            QuoteParams {
                sender: ctx.accounts.oft_store.key(),
                dst_eid: params.dst_eid,
                receiver: ctx.accounts.peer.peer_address,
                message,
                options,
                pay_in_lz_token: params.pay_in_lz_token,
            },
        )
    }
}
