use anchor_lang::prelude::*;

use crate::errors::OFTError;

#[derive(Clone, AnchorSerialize, AnchorDeserialize, PartialEq, Eq)]
pub enum MessageType {
    WithdrawRemote = 1,
    SendOFT = 2,
    SendCredits = 3,
    SendOFTAndCall = 4,
}

impl TryFrom<u16> for MessageType {
    type Error = error::Error;

    fn try_from(value: u16) -> Result<MessageType> {
        match value {
            1 => Ok(MessageType::WithdrawRemote),
            2 => Ok(MessageType::SendOFT),
            3 => Ok(MessageType::SendCredits),
            4 => Ok(MessageType::SendOFTAndCall),
            _ => Err(OFTError::InvalidMessage.into()),
        }
    }
}

impl Into<u16> for MessageType {
    fn into(self) -> u16 {
        self as u16
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize, Debug, PartialEq)]
pub struct CreditsBatch {
    pub credits_arbitrum: u64,
    pub credits_celo: u64,
    pub credits_eth: u64,
    pub credits_solana: u64,
    pub credits_ton: u64,
    pub credits_tron: u64,
}
