use crate::{
    codec::{compose_msg_codec, credits_codec, msg_codec},
    errors::OFTError,
    events::{CreditsReceived, OFTReceived, RemoteWithdrawReceived},
    state::{Credits, OFTStore, PeerConfig},
    types::MessageType,
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    token_interface::{self, Mint, TokenAccount, TokenInterface, TransferChecked},
};
use oapp::{
    endpoint::{
        cpi::accounts::Clear,
        instructions::{ClearParams, SendComposeParams},
        ConstructCPIContext,
    },
    LzReceiveParams,
};

#[event_cpi]
#[derive(Accounts)]
#[instruction(params: LzReceiveParams)]
pub struct LzReceive<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    #[account(
        seeds = [PEER_SEED, &params.src_eid.to_be_bytes()],
        bump = peer.bump,
        constraint = peer.peer_address == params.sender @OFTError::InvalidSender
    )]
    pub peer: Account<'info, PeerConfig>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(mut, seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(
        mut,
        address = oft_store.token_escrow,
        token::authority = oft_store,
        token::mint = token_mint,
        token::token_program = token_program
    )]
    pub token_escrow: InterfaceAccount<'info, TokenAccount>,
    /// CHECK: the wallet address to receive the token    
    pub to_address: Option<AccountInfo<'info>>,
    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = token_mint,
        associated_token::authority = to_address,
        associated_token::token_program = token_program
    )]
    pub token_dest: Option<InterfaceAccount<'info, TokenAccount>>,
    #[account(        
        address = oft_store.token_mint,
        mint::token_program = token_program
    )]
    pub token_mint: InterfaceAccount<'info, Mint>,
    pub token_program: Interface<'info, TokenInterface>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

impl LzReceive<'_> {
    pub fn apply(ctx: &mut Context<LzReceive>, params: &LzReceiveParams) -> Result<()> {
        // Validate and clear the payload
        let accounts_for_clear = &ctx.remaining_accounts[0..Clear::MIN_ACCOUNTS_LEN];
        let _ = oapp::endpoint_cpi::clear(
            ctx.accounts.oft_store.endpoint_program,
            ctx.accounts.oft_store.key(),
            accounts_for_clear,
            &ctx.accounts.oft_store.signer_seeds(),
            ClearParams {
                receiver: ctx.accounts.oft_store.key(),
                src_eid: params.src_eid,
                sender: params.sender,
                nonce: params.nonce,
                guid: params.guid,
                message: params.message.clone(),
            },
        )?;

        // Handle the message by type
        let (msg_type, msg_without_type) = extract_message_type_and_payload(&params.message)?;
        match msg_type {
            MessageType::SendCredits => {
                // Assert the to_address and token_dest should be unset
                require!(ctx.accounts.to_address.is_none(), OFTError::InvalidTokenDest);
                require!(ctx.accounts.token_dest.is_none(), OFTError::InvalidTokenDest);

                let credits_batch = credits_codec::decode_msg_without_msg_type(msg_without_type)?;
                ctx.accounts.credits.increase_credits_batch(&credits_batch)?;
                emit_cpi!(CreditsReceived {
                    guid: params.guid,
                    src_eid: params.src_eid,
                    message: params.message.clone(),
                });
            },
            MessageType::WithdrawRemote => {
                let (amount_received_ld, to_address) = receive_oft(msg_without_type, ctx)?;
                emit_cpi!(RemoteWithdrawReceived {
                    guid: params.guid,
                    src_eid: params.src_eid,
                    to: to_address,
                    amount_received_ld,
                });
            },
            MessageType::SendOFT | MessageType::SendOFTAndCall => {
                let (amount_received_ld, to_address) = receive_oft(msg_without_type, ctx)?;
                emit_cpi!(OFTReceived {
                    guid: params.guid,
                    src_eid: params.src_eid,
                    to: to_address,
                    amount_received_ld,
                });
                
                if msg_type == MessageType::SendOFTAndCall {
                    let compose_msg = msg_codec::compose_msg(msg_without_type).ok_or(OFTError::InvalidMessage)?;
                    oapp::endpoint_cpi::send_compose(
                        ctx.accounts.oft_store.endpoint_program,
                        ctx.accounts.oft_store.key(),
                        &ctx.remaining_accounts[Clear::MIN_ACCOUNTS_LEN..],
                        &ctx.accounts.oft_store.signer_seeds(),
                        SendComposeParams {
                            to: to_address,
                            guid: params.guid,
                            index: 0, // only 1 compose msg per lzReceive
                            message: compose_msg_codec::encode(
                                params.nonce,
                                params.src_eid,
                                amount_received_ld,
                                &compose_msg,
                            ),
                        },
                    )?;
                }
            },
        }

        Ok(())
    }
}

/// Decode the message type and return the message without the type
pub(crate) fn extract_message_type_and_payload(message: &[u8]) -> Result<(MessageType, &[u8])> {
    let msg_type = MessageType::try_from(u16::from_be_bytes([message[0], message[1]]))?;
    Ok((msg_type, &message[2..]))
}

pub(crate) fn receive_oft(message_without_type: &[u8], ctx: &mut Context<LzReceive>) -> Result<(u64, Pubkey)> {
    // Ensure the to_address and token_dest are set if receiving OFT
    let to_account_info = ctx
        .accounts
        .to_address
        .as_ref()
        .ok_or(OFTError::InvalidTokenDest)?
        .to_account_info();
    let token_dest = ctx.accounts.token_dest.as_ref().ok_or(OFTError::InvalidTokenDest)?;

    // Ensure the to_address is the same as the one in the message
    let to_address = Pubkey::from(msg_codec::send_to(message_without_type));
    require!(to_account_info.key() == to_address, OFTError::InvalidTokenDest);

    // Transfer the OFT to the token_dest
    let amount_received_ld = msg_codec::amount_sd(message_without_type);
    token_interface::transfer_checked(
        CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            TransferChecked {
                from: ctx.accounts.token_escrow.to_account_info(),
                mint: ctx.accounts.token_mint.to_account_info(),
                to: token_dest.to_account_info(),
                authority: ctx.accounts.oft_store.to_account_info(),
            },
        )
        .with_signer(&[&ctx.accounts.oft_store.signer_seeds()]),
        amount_received_ld,
        ctx.accounts.token_mint.decimals,
    )?;

    Ok((amount_received_ld, to_address))
}
