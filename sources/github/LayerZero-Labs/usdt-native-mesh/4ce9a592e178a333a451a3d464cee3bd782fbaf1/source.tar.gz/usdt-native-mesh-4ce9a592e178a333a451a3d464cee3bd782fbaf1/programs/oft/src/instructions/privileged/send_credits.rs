use crate::{
    codec::credits_codec,
    errors::OFTError,
    events::CreditsSent,
    state::{Credits, OFTStore, PeerConfig},
    types::{CreditsBatch, MessageType},
    CREDITS_SEED, OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;
use oapp::endpoint::{instructions::SendParams as EndpointSendParams, MessagingReceipt};

#[derive(Accounts)]
#[instruction(params: SendCreditsParams)]
#[event_cpi]
pub struct SendCredits<'info> {
    #[account(constraint = oft_store.only_planner(planner.key) @ OFTError::Unauthorized)]
    pub planner: Signer<'info>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    #[account(mut, seeds = [CREDITS_SEED], bump = credits.bump)]
    pub credits: Account<'info, Credits>,
    #[account(seeds = [PEER_SEED, &params.dst_eid.to_be_bytes()], bump = peer.bump)]
    pub peer: Account<'info, PeerConfig>,
}

impl SendCredits<'_> {
    pub fn apply(
        ctx: &mut Context<SendCredits>,
        params: &SendCreditsParams,
    ) -> Result<MessagingReceipt> {
        // decrease the credits from this chain
        ctx.accounts.credits.decrease_credits_batch(&params.credits_batch)?;

        // encode message and options
        let message = credits_codec::encode(&params.credits_batch);
        let options = ctx
            .accounts
            .peer
            .enforced_options
            .combine_options(&MessageType::SendCredits, &params.extra_options)?;

        // send message to endpoint
        let msg_receipt = oapp::endpoint_cpi::send(
            ctx.accounts.oft_store.endpoint_program,
            ctx.accounts.oft_store.key(),
            ctx.remaining_accounts,
            &ctx.accounts.oft_store.signer_seeds(),
            EndpointSendParams {
                dst_eid: params.dst_eid,
                receiver: ctx.accounts.peer.peer_address,
                message,
                options,
                native_fee: params.native_fee,
                lz_token_fee: params.lz_token_fee,
            },
        )?;

        // emit event
        emit_cpi!(CreditsSent {
            dst_eid: params.dst_eid,
            credits_batch: params.credits_batch.clone(),
            guid: msg_receipt.guid,
        });
        Ok(msg_receipt)
    }
}

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct SendCreditsParams {
    pub dst_eid: u32,
    pub credits_batch: CreditsBatch,
    pub extra_options: Vec<u8>,
    pub native_fee: u64,
    pub lz_token_fee: u64,
}
