#[cfg(test)]
mod test_msg_codec {
    use anchor_lang::prelude::Pubkey;
    use oft::codec::msg_codec;

    const SEND_TO: &[u8] = &[
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, //
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // send_to
    ];

    const BASE_MESSAGE: &[u8] = &[
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, //
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // send_to
        0, 0, 0, 0, 0, 0, 0, 2, // amount_sd
    ];
    const MESSAGE_40_CHARS: &[u8] = b"0123456789012345678901234567890123456789";
    const MESSAGE_43_CHARS: &[u8] = b"0123456789012345678901234567890123456789ABC";

    #[test]
    fn test_encode() {
        let res: Vec<u8> =
            msg_codec::encode(SEND_TO.try_into().unwrap(), 2, &Pubkey::default(), &None);
        assert_eq!(res.len(), 40);
        assert_eq!(res, BASE_MESSAGE);
    }

    #[test]
    fn test_encode_with_compose_msg() {
        let compose_msg = [7, 8, 9].to_vec();
        let pk = &Pubkey::default();
        let res: Vec<u8> =
            msg_codec::encode(SEND_TO.try_into().unwrap(), 2, pk, &Some(compose_msg.clone()));

        assert_eq!(res.len(), 75);

        let mut expected = BASE_MESSAGE.to_vec();
        expected.extend_from_slice(&pk.to_bytes());
        expected.extend_from_slice(&compose_msg);
        assert_eq!(res, expected);
    }

    #[test]
    fn test_send_to() {
        let res: [u8; 32] = msg_codec::send_to(BASE_MESSAGE);
        assert_eq!(res, BASE_MESSAGE[0..32]);
    }

    #[test]
    fn test_amount_sd() {
        let res: u64 = msg_codec::amount_sd(BASE_MESSAGE);
        assert_eq!(res, 2);
    }

    #[test]
    fn test_compose_empty_message() {
        let res: Option<Vec<u8>> = msg_codec::compose_msg(b"");
        assert!(res.is_none());
    }

    #[test]
    fn test_compose_non_empty_message_40_chars() {
        let res: Option<Vec<u8>> = msg_codec::compose_msg(MESSAGE_40_CHARS);
        assert!(res.is_none());
    }

    #[test]
    fn test_compose_non_empty_message_43_chars() {
        let res: Option<Vec<u8>> = msg_codec::compose_msg(MESSAGE_43_CHARS);
        assert_eq!(res, Some(b"ABC".to_vec()));
    }
}
