use crate::{
    errors::OFTError, state::{Credits, OFTStore}, 
    CREDITS_SEED, OFT_SEED, SHARED_DECIMALS
};
use anchor_lang::prelude::*;
use anchor_spl::token_interface::{Mint, TokenAccount, TokenInterface};
use oapp::{
    endpoint::{instructions::RegisterOAppParams, state::EndpointSettings, ID as ENDPOINT_ID, ENDPOINT_SEED},
};

#[derive(Accounts)]
#[instruction(params: InitOFTParams)]
pub struct InitOFT<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    #[account(
        init,
        payer = payer,
        space = 8 + OFTStore::INIT_SPACE,
        seeds = [OFT_SEED],
        bump
    )]
    pub oft_store: Account<'info, OFTStore>,
    #[account(
        init,
        payer = payer,
        space = 8 + Credits::INIT_SPACE,
        seeds = [CREDITS_SEED],
        bump
    )]
    pub credits: Account<'info, Credits>,
    #[account(mint::token_program = token_program)]
    pub token_mint: InterfaceAccount<'info, Mint>,
    #[account(
        init,
        payer = payer,
        token::authority = oft_store,
        token::mint = token_mint,
        token::token_program = token_program,
    )]
    pub token_escrow: InterfaceAccount<'info, TokenAccount>,
    #[account(
        seeds = [ENDPOINT_SEED], 
        seeds::program = params.endpoint_program.unwrap_or(ENDPOINT_ID), 
        bump = endpoint_settings.bump
    )]
    pub endpoint_settings: Account<'info, EndpointSettings>,
    pub token_program: Interface<'info, TokenInterface>,
    pub system_program: Program<'info, System>,
}

impl InitOFT<'_> {
    pub fn apply(ctx: &mut Context<InitOFT>, params: &InitOFTParams) -> Result<()> {
        require!(ctx.accounts.token_mint.decimals == SHARED_DECIMALS, OFTError::InvalidDecimals);

        // Initialize the oft_store        
        ctx.accounts.oft_store.token_mint = ctx.accounts.token_mint.key();
        ctx.accounts.oft_store.token_escrow = ctx.accounts.token_escrow.key();
        ctx.accounts.oft_store.endpoint_program = params.endpoint_program.unwrap_or(ENDPOINT_ID);
        ctx.accounts.oft_store.bump = ctx.bumps.oft_store;
        ctx.accounts.oft_store.fee_balance = 0;
        ctx.accounts.oft_store.super_admin = params.super_admin;
        ctx.accounts.oft_store.planner = params.super_admin;
        ctx.accounts.oft_store.lp_admin = params.super_admin;
        ctx.accounts.oft_store.burn_and_nilify_admin = params.super_admin;
        ctx.accounts.oft_store.fee_bps = 0; // 0 fee bps by default
        ctx.accounts.oft_store.alt = params.alt;

        // Initialize the credits
        ctx.accounts.credits.initialize();
        ctx.accounts.credits.bump = ctx.bumps.credits;

        // Register the oapp
        oapp::endpoint_cpi::register_oapp(
            ctx.accounts.oft_store.endpoint_program,
            ctx.accounts.oft_store.key(),
            ctx.remaining_accounts,
            &ctx.accounts.oft_store.signer_seeds(),
            RegisterOAppParams { delegate: params.super_admin },
        )
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct InitOFTParams {
    pub super_admin: Pubkey,
    pub endpoint_program: Option<Pubkey>,    
    pub alt: Option<Pubkey>,
}
