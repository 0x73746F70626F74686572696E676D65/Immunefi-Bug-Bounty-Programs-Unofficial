use crate::{
    errors::OFTError,
    types::{CreditsBatch, MessageType},
};
use anchor_lang::prelude::*;

pub fn encode(credits: &CreditsBatch) -> Vec<u8> {
    let CreditsBatch {
        credits_arbitrum,
        credits_celo,
        credits_eth,
        credits_solana,
        credits_ton,
        credits_tron,
    } = credits;
    let mut message = Vec::with_capacity(50); // 2 + 8 * 6
    message.extend_from_slice(&(MessageType::SendCredits as u16).to_be_bytes());
    message.extend_from_slice(&credits_arbitrum.to_be_bytes());
    message.extend_from_slice(&credits_celo.to_be_bytes());
    message.extend_from_slice(&credits_eth.to_be_bytes());
    message.extend_from_slice(&credits_solana.to_be_bytes());
    message.extend_from_slice(&credits_ton.to_be_bytes());
    message.extend_from_slice(&credits_tron.to_be_bytes());
    message
}

/// Decode a full message (includes 2-byte message type prefix) into a CreditsByChain
pub fn decode(message: &[u8]) -> Result<CreditsBatch> {
    require!(message.len() == 50, OFTError::InvalidMessage);
    let msg_type = u16::from_be_bytes([message[0], message[1]]);
    require!(msg_type == MessageType::SendCredits as u16, OFTError::InvalidMessage);
    decode_msg_without_msg_type(&message[2..])
}

/// Decode the message body (without the 2-byte message type) into a CreditsByChain
pub fn decode_msg_without_msg_type(message: &[u8]) -> Result<CreditsBatch> {
    require!(message.len() == 48, OFTError::InvalidMessage);

    let read_u64 = |start: usize| -> Result<u64> {
        let bytes: [u8; 8] =
            message[start..start + 8].try_into().map_err(|_| OFTError::InvalidMessage)?;
        Ok(u64::from_be_bytes(bytes))
    };

    Ok(CreditsBatch {
        credits_arbitrum: read_u64(0)?,
        credits_celo: read_u64(8)?,
        credits_eth: read_u64(16)?,
        credits_solana: read_u64(24)?,
        credits_ton: read_u64(32)?,
        credits_tron: read_u64(40)?,
    })
}
