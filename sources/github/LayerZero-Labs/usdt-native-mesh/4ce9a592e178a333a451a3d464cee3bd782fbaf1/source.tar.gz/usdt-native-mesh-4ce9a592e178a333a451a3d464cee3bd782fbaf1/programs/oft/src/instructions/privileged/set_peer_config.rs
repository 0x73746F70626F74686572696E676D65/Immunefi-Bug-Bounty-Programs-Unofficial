use crate::{
    errors::OFTError,
    events::{EnforcedOptionsSet, PeerAddressSet},
    state::{OFTStore, PeerConfig},
    OFT_SEED, PEER_SEED,
};
use anchor_lang::prelude::*;

#[derive(Accounts)]
#[instruction(params: SetPeerConfigParams)]
#[event_cpi]
pub struct SetPeerConfig<'info> {
    #[account(mut, constraint = oft_store.only_super_admin(admin.key) @ OFTError::Unauthorized)]
    pub admin: Signer<'info>,
    #[account(
        init_if_needed,
        payer = admin,
        space = 8 + PeerConfig::INIT_SPACE,
        seeds = [PEER_SEED, &params.remote_eid.to_be_bytes()],
        bump
    )]
    pub peer: Account<'info, PeerConfig>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
    pub system_program: Program<'info, System>,
}

impl SetPeerConfig<'_> {
    pub fn apply(ctx: &mut Context<SetPeerConfig>, params: &SetPeerConfigParams) -> Result<()> {
        match params.config.clone() {
            PeerConfigParam::PeerAddress(peer_address) => {
                ctx.accounts.peer.peer_address = peer_address;
                emit_cpi!(PeerAddressSet { address: peer_address });
            },
            PeerConfigParam::EnforcedOptions {
                send,
                send_and_call,
                send_credits,
                withdraw_remote,
            } => {
                oapp::options::assert_type_3(&send)?;
                ctx.accounts.peer.enforced_options.send_oft = send.clone();
                oapp::options::assert_type_3(&send_and_call)?;
                ctx.accounts.peer.enforced_options.send_oft_and_call = send_and_call.clone();
                oapp::options::assert_type_3(&send_credits)?;
                ctx.accounts.peer.enforced_options.send_credits = send_credits.clone();
                oapp::options::assert_type_3(&withdraw_remote)?;
                ctx.accounts.peer.enforced_options.withdraw_remote = withdraw_remote.clone();
                emit_cpi!(EnforcedOptionsSet {
                    send,
                    send_and_call,
                    send_credits,
                    withdraw_remote,
                });
            },
        }
        ctx.accounts.peer.bump = ctx.bumps.peer;
        Ok(())
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct SetPeerConfigParams {
    pub remote_eid: u32,
    pub config: PeerConfigParam,
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub enum PeerConfigParam {
    PeerAddress([u8; 32]),
    EnforcedOptions {
        send: Vec<u8>,
        send_and_call: Vec<u8>,
        send_credits: Vec<u8>,
        withdraw_remote: Vec<u8>,
    },
}
