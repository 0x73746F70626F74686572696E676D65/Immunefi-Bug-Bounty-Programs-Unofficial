use crate::{
    errors::OFTError, types::CreditsBatch, ARBITRUM_EID, CELO_EID, ETH_EID, SOLANA_EID, TON_EID,
    TRON_EID,
};
use anchor_lang::prelude::*;

#[account]
#[derive(InitSpace)]
pub struct Credits {
    pub bump: u8,
    #[max_len(6)]
    pub entries: Vec<CreditsEntry>,
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize, InitSpace)]
pub struct CreditsEntry {
    pub eid: u32,
    pub amount: u64,
}

impl Credits {
    pub fn initialize(&mut self) {
        #[cfg(feature = "sandbox")]
        {
            self.entries = vec![
                CreditsEntry { eid: ARBITRUM_EID, amount: 1000 },
                CreditsEntry { eid: CELO_EID, amount: 1000 },
                CreditsEntry { eid: ETH_EID, amount: 1000 },
                CreditsEntry { eid: SOLANA_EID, amount: 0 },
                CreditsEntry { eid: TON_EID, amount: 1000 },
                CreditsEntry { eid: TRON_EID, amount: 1000 },
            ];
        }

        #[cfg(not(feature = "sandbox"))]
        {
            self.entries = vec![
                CreditsEntry { eid: ARBITRUM_EID, amount: 0 },
                CreditsEntry { eid: CELO_EID, amount: 0 },
                CreditsEntry { eid: ETH_EID, amount: 0 },
                CreditsEntry { eid: SOLANA_EID, amount: 0 },
                CreditsEntry { eid: TON_EID, amount: 0 },
                CreditsEntry { eid: TRON_EID, amount: 0 },
            ];
        }
    }

    pub fn get_credits(&self, eid: u32) -> Result<u64> {
        let entry = self.find_entry(eid)?;
        Ok(entry.amount)
    }

    pub fn assert_credits(&self, eid: u32, amount: u64) -> Result<()> {
        let available_credits = self.get_credits(eid)?;
        require!(available_credits >= amount, OFTError::InsufficientCredits);
        Ok(())
    }

    pub fn decrease_credits(&mut self, eid: u32, amount: u64) -> Result<()> {
        // if amount is 0, do nothing
        if amount > 0 {
            self.assert_credits(eid, amount)?;
            let entry = self.find_entry_mut(eid)?;
            entry.amount -= amount;
        }
        Ok(())
    }

    pub fn increase_credits(&mut self, eid: u32, amount: u64) -> Result<()> {
        let entry = self.find_entry_mut(eid)?;
        entry.amount += amount;
        Ok(())
    }

    pub fn assert_credits_batch(&self, credits_batch: &CreditsBatch) -> Result<()> {
        // create a copy of self to try to decrease the credits and see if it fails
        let mut self_copy = self.clone();
        self_copy.decrease_credits_batch(credits_batch)
    }

    pub fn decrease_credits_batch(&mut self, credits_batch: &CreditsBatch) -> Result<()> {
        self.decrease_credits(ARBITRUM_EID, credits_batch.credits_arbitrum)?;
        self.decrease_credits(CELO_EID, credits_batch.credits_celo)?;
        self.decrease_credits(ETH_EID, credits_batch.credits_eth)?;
        self.decrease_credits(SOLANA_EID, credits_batch.credits_solana)?;
        self.decrease_credits(TON_EID, credits_batch.credits_ton)?;
        self.decrease_credits(TRON_EID, credits_batch.credits_tron)?;
        Ok(())
    }

    pub fn increase_credits_batch(&mut self, credits_batch: &CreditsBatch) -> Result<()> {
        self.increase_credits(ARBITRUM_EID, credits_batch.credits_arbitrum)?;
        self.increase_credits(CELO_EID, credits_batch.credits_celo)?;
        self.increase_credits(ETH_EID, credits_batch.credits_eth)?;
        self.increase_credits(SOLANA_EID, credits_batch.credits_solana)?;
        self.increase_credits(TON_EID, credits_batch.credits_ton)?;
        self.increase_credits(TRON_EID, credits_batch.credits_tron)?;
        Ok(())
    }

    fn find_entry(&self, eid: u32) -> Result<&CreditsEntry> {
        self.entries
            .iter()
            .find(|entry| entry.eid == eid)
            .ok_or(OFTError::InvalidEID.into())
    }

    fn find_entry_mut(&mut self, eid: u32) -> Result<&mut CreditsEntry> {
        self.entries
            .iter_mut()
            .find(|entry| entry.eid == eid)
            .ok_or(OFTError::InvalidEID.into())
    }
}
