use anchor_lang::prelude::error_code;

#[error_code]
pub enum OFTError {
    Unauthorized,
    InvalidSender,
    InvalidDecimals,
    SlippageExceeded,
    InvalidTokenDest,
    InsufficientFeeBalance,
    InvalidAmount,
    InsufficientCredits,
    InvalidEID,
    InvalidMessage,
    InvalidFeeBps,
    TONComposeNotSupported,
}
