use crate::{errors::OFTError, state::OFTStore, OFT_SEED};
use anchor_lang::prelude::*;
use oapp::endpoint::{
    self as endpoint, cpi::accounts::Nilify as EndpointNilify, ConstructCPIContext,
};

#[derive(Accounts)]
pub struct Nilify<'info> {
    #[account(constraint = oft_store.only_burn_and_nilify_admin(admin.key) @ OFTError::Unauthorized)]
    pub admin: Signer<'info>,
    #[account(seeds = [OFT_SEED], bump = oft_store.bump)]
    pub oft_store: Account<'info, OFTStore>,
}

impl Nilify<'_> {
    pub fn apply(ctx: &mut Context<Nilify>, params: &NilifyParams) -> Result<()> {
        let oft_store = ctx.accounts.oft_store.to_account_info();
        let cpi_ctx = EndpointNilify::construct_context(
            ctx.accounts.oft_store.endpoint_program,
            ctx.remaining_accounts,
        )?;
        endpoint::cpi::nilify(
            cpi_ctx.with_signer(&[&ctx.accounts.oft_store.signer_seeds()]),
            endpoint::instructions::NilifyParams {
                receiver: oft_store.key(),
                src_eid: params.src_eid,
                sender: params.sender,
                nonce: params.nonce,
                payload_hash: params.payload_hash,
            },
        )
    }
}

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct NilifyParams {
    pub src_eid: u32,
    pub sender: [u8; 32],
    pub nonce: u64,
    pub payload_hash: [u8; 32],
}
