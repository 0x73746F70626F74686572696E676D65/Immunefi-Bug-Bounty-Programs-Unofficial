//! Lock-free resizable slots with dynamic resizing.
//!
//! A generic resizable ring buffer of slots for O(1) access by integer ID.
//! IDs are monotonically increasing, so we use `id % capacity` for indexing.
//!
//! # Why ResizableSlots instead of DashMap?
//!
//! `ResizableSlots<T>` is designed as a high-performance alternative to `DashMap<i64, Arc<T>>`
//! for scenarios where keys are **monotonically increasing integers** (e.g., file IDs, block heights).
//!
//! ## Performance Advantages
//!
//! ### 1. No Hash Computation
//!
//! - **DashMap**: Computes hash for every lookup (~5-10 ns)
//! - **ResizableSlots**: Direct index via `id % capacity` (~1 ns)
//!
//! ### 2. True Lock-Free Reads (No RwLock)
//!
//! - **DashMap**: Acquires a per-shard `RwLock` read lock for each `get()` (~10-20 ns)
//! - **ResizableSlots**: Uses `epoch::pin()` which is thread-local (~2-5 ns)
//!
//! ### 3. No Refcount Cacheline Ping-Pong (Critical!)
//!
//! This is the most important advantage for high-concurrency scenarios.
//!
//! **DashMap with `Arc<T>` values**:
//! ```text
//! // When multiple cores read the same key and clone the Arc:
//! Core 0: Arc::clone() → fetch_add(refcount) → cacheline invalidate
//! Core 1: Arc::clone() → wait for cacheline → fetch_add → invalidate
//! Core 2: Arc::clone() → wait for cacheline → fetch_add → invalidate
//! // Result: Serialized execution due to RMW on shared cacheline
//! ```
//!
//! **ResizableSlots with ArcSwap**:
//! ```text
//! // ArcSwap::load() returns a Guard, NOT a cloned Arc
//! Core 0: load() → pure read, no refcount touch
//! Core 1: load() → pure read, no refcount touch
//! Core 2: load() → pure read, no refcount touch
//! // Result: Perfect parallelism, each core reads its own cacheline copy
//! ```
//!
//! The `Guard` returned by `ArcSwap::load()` uses **epoch-based protection** instead of
//! reference counting. Multiple threads can concurrently read the same slot without
//! any atomic Read-Modify-Write operations, eliminating cacheline bouncing entirely.
//!
//! ### 4. Cache-Friendly Memory Layout
//!
//! - **DashMap**: HashMap buckets with pointer chasing
//! - **ResizableSlots**: Contiguous array, predictable memory access
//!
//! ## Performance Comparison
//!
//! | Operation | DashMap | ResizableSlots |
//! |-----------|---------|----------------|
//! | Single-thread get | ~25 ns | ~8 ns |
//! | 8-core concurrent get (same key) | ~200+ ns (serialized) | ~8 ns (parallel) |
//! | Cacheline state under contention | Modified ↔ Invalid | Shared (read-only) |
//!
//! ## When to Use ResizableSlots
//!
//! ✅ **Good fit**:
//! - Keys are monotonically increasing integers
//! - High-frequency concurrent reads on hot keys
//! - Values are wrapped in `Arc<T>`
//! - Bounded key range (or old keys are pruned)
//!
//! ❌ **Not suitable**:
//! - Arbitrary key types (strings, UUIDs, etc.)
//! - Sparse, non-sequential key distribution
//! - Need for complex query patterns (range queries, iteration)
//!
//! # Dynamic Resizing
//!
//! When capacity is exceeded (slot collision with different ID), the array is automatically
//! resized. This uses `crossbeam::epoch` for safe lock-free memory reclamation:
//! - Readers use `pin()` to safely access the current slots array
//! - Writers can resize by creating a new array and atomically swapping
//! - Old arrays are reclaimed after all readers have finished
//!
//! # File-specific Usage (FileSlots)
//!
//! For HPFile, we use `ResizableSlots<File>` with additional file-specific features:
//! - `slots`: All files opened with O_DIRECT (for reading)
//! - `current_file`: The latest file opened without O_DIRECT (for writing)
//!
//! The latest segment has TWO file handles:
//! - One in `slots[largest_id % capacity]` (O_DIRECT, for reading)
//! - One in `current_file` (non-O_DIRECT, for writing)
//!
//! # Safety with io_uring
//!
//! When using io_uring for async reads, the caller must ensure that `remove()` or `clear()`
//! is NOT called on slots that have in-flight io_uring operations. If a slot is removed
//! while an io_uring read is pending, the file descriptor may be closed (or reused),
//! leading to undefined behavior or incorrect reads.

use arc_swap::{ArcSwapOption, Guard};
use crossbeam::epoch::{self, Atomic, Owned};
use std::fs::File;
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::Arc;

/// Default initial capacity: 256 slots.
pub const DEFAULT_CAPACITY: usize = 256;

/// Growth factor when resizing (double the capacity).
const GROWTH_FACTOR: usize = 2;

/// A borrowed reference to a value (via Guard, no refcount overhead).
pub type SlotGuard<T> = Guard<Option<Arc<T>>>;

/// A borrowed reference to a file (via Guard, no refcount overhead).
pub type FileGuard = SlotGuard<File>;

// ============================================================================
// Generic Resizable Slots
// ============================================================================

/// A slot entry storing both id and value.
///
/// The id is needed for correct remapping during resize,
/// since `slot_index = id % capacity` changes when capacity changes.
struct SlotEntry<T> {
    /// The ID stored in this slot, or -1 if empty.
    id: AtomicI64,
    /// The value handle.
    value: ArcSwapOption<T>,
}

impl<T> SlotEntry<T> {
    fn new() -> Self {
        Self {
            id: AtomicI64::new(-1),
            value: ArcSwapOption::new(None),
        }
    }

    #[inline]
    fn get_id(&self) -> i64 {
        self.id.load(Ordering::Acquire)
    }

    fn store(&self, id: i64, value: Arc<T>) {
        self.value.store(Some(value));
        // Memory barrier to ensure value is visible before id update.
        // This prevents readers from seeing the new id but stale value.
        std::sync::atomic::fence(Ordering::Release);
        self.id.store(id, Ordering::Release);
    }

    fn clear(&self) -> Option<Arc<T>> {
        self.id.store(-1, Ordering::Release);
        self.value.swap(None)
    }

    fn load_value(&self) -> Option<SlotGuard<T>> {
        let guard = self.value.load();
        if guard.is_some() {
            Some(guard)
        } else {
            None
        }
    }
}

/// Inner storage for slots, protected by epoch.
struct SlotsInner<T> {
    entries: Box<[SlotEntry<T>]>,
}

impl<T> SlotsInner<T> {
    fn with_capacity(capacity: usize) -> Self {
        let entries: Vec<_> = (0..capacity).map(|_| SlotEntry::new()).collect();
        Self {
            entries: entries.into_boxed_slice(),
        }
    }

    #[inline]
    fn capacity(&self) -> usize {
        self.entries.len()
    }

    #[inline]
    fn slot_index(&self, id: i64) -> usize {
        (id as usize) % self.entries.len()
    }

    #[inline]
    fn get_entry(&self, id: i64) -> &SlotEntry<T> {
        &self.entries[self.slot_index(id)]
    }
}

/// Lock-free resizable slots using a ring buffer.
///
/// Generic container for storing values indexed by monotonically increasing integer IDs.
/// Automatically resizes when capacity is exceeded.
///
/// # Thread Safety
///
/// - Multiple readers can call `get()` concurrently (lock-free)
/// - Write operations (`insert`, `remove`) should be externally synchronized
///   (typically single-writer usage)
pub struct ResizableSlots<T> {
    /// Epoch-protected slots array for safe resizing.
    inner: Atomic<SlotsInner<T>>,
    /// The largest ID currently stored.
    largest_id: AtomicI64,
}

impl<T> ResizableSlots<T> {
    /// Create ResizableSlots with the given initial capacity.
    pub fn with_capacity(capacity: usize) -> Self {
        let inner = SlotsInner::with_capacity(capacity);
        Self {
            inner: Atomic::new(inner),
            largest_id: AtomicI64::new(-1),
        }
    }

    /// Get a value by ID as a borrowed Guard.
    ///
    /// This operation is lock-free and safe for concurrent access.
    #[inline]
    pub fn get(&self, id: i64) -> Option<SlotGuard<T>> {
        let guard = epoch::pin();
        // SAFETY: We hold an epoch guard, so the inner pointer is valid.
        let inner = unsafe { self.inner.load(Ordering::Acquire, &guard).as_ref()? };
        let entry = inner.get_entry(id);
        // Verify this slot actually contains the requested id
        // (not a different value that hashes to the same slot)
        if entry.get_id() == id {
            entry.load_value()
        } else {
            None
        }
    }

    /// Get the largest ID currently stored.
    #[inline]
    pub fn largest_id(&self) -> i64 {
        self.largest_id.load(Ordering::SeqCst)
    }

    /// Get the current capacity.
    pub fn capacity(&self) -> usize {
        let guard = epoch::pin();
        // SAFETY: We hold an epoch guard.
        unsafe {
            self.inner
                .load(Ordering::Acquire, &guard)
                .as_ref()
                .map(|inner| inner.capacity())
                .unwrap_or(0)
        }
    }

    /// Insert a value with the given ID.
    ///
    /// If the slot is occupied by a different ID, the array will be resized.
    ///
    /// # Note
    ///
    /// Write operations should be externally synchronized (single-writer).
    pub fn insert(&self, id: i64, value: Arc<T>) {
        let guard = epoch::pin();
        loop {
            // SAFETY: We hold an epoch guard.
            let inner_ptr = self.inner.load(Ordering::Acquire, &guard);
            let inner = unsafe { inner_ptr.as_ref().expect("inner should not be null") };

            let entry = inner.get_entry(id);
            let existing_id = entry.get_id();

            if existing_id < 0 {
                // Slot is empty, insert directly
                entry.store(id, value);
                self.largest_id.fetch_max(id, Ordering::SeqCst);
                return;
            } else if existing_id == id {
                // Same id, update the value
                entry.store(id, value);
                self.largest_id.fetch_max(id, Ordering::SeqCst);
                return;
            } else {
                // Slot collision with different id - need to resize
                self.grow(&guard);
                // Retry after growing
            }
        }
    }

    /// Grow the slots array to accommodate more values.
    ///
    /// This creates a new array with doubled capacity and remaps all existing values.
    fn grow(&self, guard: &epoch::Guard) {
        // SAFETY: We hold an epoch guard.
        let old_ptr = self.inner.load(Ordering::Acquire, guard);
        let old_inner = unsafe { old_ptr.as_ref().expect("inner should not be null") };

        let old_capacity = old_inner.capacity();
        let new_capacity = old_capacity * GROWTH_FACTOR;

        // Create new slots array
        let new_inner = SlotsInner::with_capacity(new_capacity);

        // Remap all existing values to new positions
        for entry in old_inner.entries.iter() {
            let entry_id = entry.get_id();
            if entry_id >= 0 {
                if let Some(value_guard) = entry.load_value() {
                    // Clone the Arc<T> for the new slot
                    if let Some(value_arc) = value_guard.as_ref() {
                        let new_entry = new_inner.get_entry(entry_id);
                        new_entry.store(entry_id, Arc::clone(value_arc));
                    }
                }
            }
        }

        // Atomically replace the old array
        let new_owned = Owned::new(new_inner);
        match self
            .inner
            .compare_exchange(old_ptr, new_owned, Ordering::AcqRel, Ordering::Acquire, guard)
        {
            Ok(_) => {
                // Successfully swapped, defer destruction of old array
                // SAFETY: old_ptr was loaded from self.inner and we successfully CAS'd it out.
                unsafe {
                    guard.defer_destroy(old_ptr);
                }
            }
            Err(_) => {
                // Another thread already resized, our new array will be dropped
                // This shouldn't happen with single-writer assumption, but handle gracefully
            }
        }
    }

    /// Remove a value from the slot.
    pub fn remove(&self, id: i64) -> Option<Arc<T>> {
        let guard = epoch::pin();
        // SAFETY: We hold an epoch guard.
        let inner = unsafe { self.inner.load(Ordering::Acquire, &guard).as_ref()? };

        let entry = inner.get_entry(id);
        if entry.get_id() == id {
            entry.clear()
        } else {
            None
        }
    }

    /// Remove the largest value and decrement largest_id.
    pub fn remove_largest(&self) -> Option<(i64, Arc<T>)> {
        // `largest_id` is expected to be monotonic and point at an existing entry, but in
        // practice we may observe "holes" (e.g. partial directories, external deletion,
        // or past bugs). Be defensive: scan downward until we find an existing entry.
        let mut id = self.largest_id.load(Ordering::SeqCst);
        if id < 0 {
            return None;
        }

        while id >= 0 {
            if let Some(v) = self.remove(id) {
                // Update largest_id to the next existing ID below `id`, or -1 if none.
                let mut new_largest = id - 1;
                while new_largest >= 0 && !self.contains(new_largest) {
                    new_largest -= 1;
                }
                self.largest_id.store(new_largest, Ordering::SeqCst);
                return Some((id, v));
            }
            id -= 1;
        }

        self.largest_id.store(-1, Ordering::SeqCst);
        None
    }

    /// Clear all slots and reset state.
    pub fn clear(&self) {
        let guard = epoch::pin();
        // SAFETY: We hold an epoch guard.
        if let Some(inner) = unsafe { self.inner.load(Ordering::Acquire, &guard).as_ref() } {
            for entry in inner.entries.iter() {
                entry.clear();
            }
        }
        self.largest_id.store(-1, Ordering::SeqCst);
    }

    /// Check if a value exists for the given ID.
    #[inline]
    pub fn contains(&self, id: i64) -> bool {
        let guard = epoch::pin();
        // SAFETY: We hold an epoch guard.
        if let Some(inner) = unsafe { self.inner.load(Ordering::Acquire, &guard).as_ref() } {
            let entry = inner.get_entry(id);
            entry.get_id() == id
        } else {
            false
        }
    }

    /// Get an existing value, or insert a new one if not present.
    ///
    /// Returns a `SlotGuard` for zero-refcount-overhead access. Use `get_or_insert_with_arc`
    /// if you need to hold an `Arc<T>`.
    ///
    /// # Note
    ///
    /// Write operations should be externally synchronized (single-writer).
    /// If multiple writers call this concurrently, they may both call `f`.
    pub fn get_or_insert_with<F>(&self, id: i64, f: F) -> SlotGuard<T>
    where
        F: FnOnce() -> Arc<T>,
    {
        // Fast path: check if already exists
        if let Some(guard) = self.get(id) {
            return guard;
        }

        // Slow path: insert and return
        let value = f();
        self.insert(id, value);

        // Return the guard (insert succeeded, so get must succeed)
        self.get(id).expect("just inserted, must exist")
    }

    /// Get an existing value, or insert a new one if not present. Returns `Arc<T>`.
    ///
    /// Use this when you need to hold the value (e.g., cache it in a struct).
    /// For read-only access, prefer `get_or_insert_with` which returns a `SlotGuard`
    /// with zero refcount overhead.
    ///
    /// # Note
    ///
    /// Write operations should be externally synchronized (single-writer).
    pub fn get_or_insert_with_arc<F>(&self, id: i64, f: F) -> Arc<T>
    where
        F: FnOnce() -> Arc<T>,
    {
        let guard = self.get_or_insert_with(id, f);
        Arc::clone(guard.as_ref().expect("just inserted or found"))
    }

    /// Remove all values with ID less than `min_id`.
    ///
    /// This is useful for evicting old entries in a sliding window pattern.
    ///
    /// # Note
    ///
    /// Write operations should be externally synchronized (single-writer).
    pub fn remove_below(&self, min_id: i64) {
        let guard = epoch::pin();
        // SAFETY: We hold an epoch guard.
        if let Some(inner) = unsafe { self.inner.load(Ordering::Acquire, &guard).as_ref() } {
            for entry in inner.entries.iter() {
                let entry_id = entry.get_id();
                if entry_id >= 0 && entry_id < min_id {
                    entry.clear();
                }
            }
        }
    }

}

impl<T> Drop for ResizableSlots<T> {
    fn drop(&mut self) {
        // Clean up the inner allocation
        // SAFETY: We have exclusive access during drop.
        let guard = epoch::pin();
        let ptr = self.inner.load(Ordering::Acquire, &guard);
        if !ptr.is_null() {
            // SAFETY: We're dropping, so no other references exist.
            unsafe {
                drop(ptr.into_owned());
            }
        }
    }
}

impl<T> std::fmt::Debug for ResizableSlots<T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ResizableSlots")
            .field("capacity", &self.capacity())
            .field("largest_id", &self.largest_id())
            .finish()
    }
}

// ============================================================================
// FileSlots - File-specific wrapper
// ============================================================================

/// Lock-free file slots using a resizable ring buffer.
///
/// This is a specialized wrapper around `ResizableSlots<File>` with additional
/// file-specific features:
/// - `slots`: O_DIRECT files for reading (all segments)
/// - `current_file`: Non-O_DIRECT file for writing (latest segment only)
///
/// # Thread Safety
///
/// - Multiple readers can call `get()` concurrently (lock-free)
/// - Write operations (`insert`, `remove`, `rotate`) should be externally synchronized
///   (typically single-writer in HPFile usage)
pub struct FileSlots {
    /// Generic resizable slots for O_DIRECT file handles.
    slots: ResizableSlots<File>,
    /// The current writable file (non-O_DIRECT, latest segment only).
    current_file: ArcSwapOption<File>,
}

impl FileSlots {
    /// Create FileSlots with the given initial capacity.
    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            slots: ResizableSlots::with_capacity(capacity),
            current_file: ArcSwapOption::new(None),
        }
    }

    /// Get a file for reading (O_DIRECT version) as a borrowed Guard.
    ///
    /// All files in slots are opened with O_DIRECT, suitable for direct I/O reads.
    /// This operation is lock-free and safe for concurrent access.
    #[inline]
    pub fn get(&self, file_id: i64) -> Option<FileGuard> {
        self.slots.get(file_id)
    }

    /// Get the current writable file (non-O_DIRECT version).
    ///
    /// Only the latest segment has a writable file handle.
    #[inline]
    pub fn get_current(&self) -> Option<FileGuard> {
        let guard = self.current_file.load();
        if guard.is_some() {
            Some(guard)
        } else {
            None
        }
    }

    /// Get the largest file ID currently stored.
    #[inline]
    pub fn largest_id(&self) -> i64 {
        self.slots.largest_id()
    }

    /// Get the current capacity.
    pub fn capacity(&self) -> usize {
        self.slots.capacity()
    }

    /// Set the current writable file (non-O_DIRECT).
    ///
    /// Used after inserting the latest segment via `insert()`.
    pub fn set_current_file(&self, write_file: Arc<File>) {
        self.current_file.store(Some(write_file));
    }

    /// Insert a segment (O_DIRECT for reading).
    ///
    /// For the latest segment, also call `set_current_file()` to set the writable handle.
    /// If the slot is occupied by a different file_id, the array will be resized.
    ///
    /// # Note
    ///
    /// Write operations should be externally synchronized (single-writer).
    pub fn insert(&self, file_id: i64, direct_file: Arc<File>) {
        self.slots.insert(file_id, direct_file);
    }

    /// Rotate to a new segment.
    ///
    /// The old `current_file` is dropped (no longer needed - reading uses O_DIRECT from slots).
    /// The new segment gets both O_DIRECT (in slots) and non-O_DIRECT (in current_file) handles.
    pub fn rotate(&self, new_direct_file: Arc<File>, new_write_file: Arc<File>) {
        let new_file_id = self.slots.largest_id() + 1;

        // 1. Insert new O_DIRECT file into slots (may trigger resize)
        self.slots.insert(new_file_id, new_direct_file);

        // 2. Replace current_file with new writable handle (old one is dropped)
        self.current_file.store(Some(new_write_file));
    }

    /// Remove a file from the slot.
    ///
    /// # Safety Note
    ///
    /// The caller must ensure there are no in-flight io_uring operations using this file.
    pub fn remove(&self, file_id: i64) -> Option<Arc<File>> {
        self.slots.remove(file_id)
    }

    /// Remove the largest file and decrement largest_id.
    ///
    /// Removes both the O_DIRECT file from slots and clears current_file.
    ///
    /// # Safety Note
    ///
    /// The caller must ensure there are no in-flight io_uring operations using this file.
    pub fn remove_largest(&self) -> Option<(i64, Arc<File>)> {
        self.current_file.store(None);
        self.slots.remove_largest()
    }

    /// Clear all slots and reset state.
    ///
    /// # Safety Note
    ///
    /// The caller must ensure there are no in-flight io_uring operations on any file.
    pub fn clear(&self) {
        self.slots.clear();
        self.current_file.store(None);
    }
}

impl std::fmt::Debug for FileSlots {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("FileSlots")
            .field("capacity", &self.capacity())
            .field("largest_id", &self.largest_id())
            .field("has_current_file", &self.current_file.load().is_some())
            .finish()
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_temp_file() -> Arc<File> {
        let mut temp = NamedTempFile::new().unwrap();
        temp.write_all(b"test").unwrap();
        Arc::new(temp.reopen().unwrap())
    }

    // --- ResizableSlots generic tests ---

    #[test]
    fn test_generic_basic_insert_get() {
        let slots: ResizableSlots<String> = ResizableSlots::with_capacity(4);
        let value = Arc::new("hello".to_string());

        slots.insert(0, value.clone());
        assert!(slots.get(0).is_some());
        assert!(slots.get(1).is_none());

        let guard = slots.get(0).unwrap();
        assert_eq!(guard.as_ref().unwrap().as_str(), "hello");
    }

    #[test]
    fn test_generic_auto_resize() {
        let slots: ResizableSlots<i32> = ResizableSlots::with_capacity(4);

        // Insert values that would collide without resize
        for i in 0..8 {
            slots.insert(i, Arc::new(i as i32 * 10));
        }

        // Verify all values are accessible
        for i in 0..8 {
            let guard = slots.get(i).expect(&format!("Value {} should exist", i));
            assert_eq!(**guard.as_ref().unwrap(), i as i32 * 10);
        }

        assert!(slots.capacity() >= 8);
    }

    #[test]
    fn test_generic_remove() {
        let slots: ResizableSlots<String> = ResizableSlots::with_capacity(4);
        slots.insert(5, Arc::new("test".to_string()));

        assert!(slots.get(5).is_some());
        let removed = slots.remove(5);
        assert!(removed.is_some());
        assert_eq!(removed.unwrap().as_str(), "test");
        assert!(slots.get(5).is_none());
    }

    #[test]
    fn test_generic_remove_largest_with_holes() {
        let slots: ResizableSlots<i32> = ResizableSlots::with_capacity(8);
        // Create a hole at the top: largest_id will be 10, but 9 is missing.
        slots.insert(8, Arc::new(80));
        slots.insert(10, Arc::new(100));

        // Remove largest should remove 10 first.
        let (id, v) = slots.remove_largest().expect("should remove largest");
        assert_eq!(id, 10);
        assert_eq!(*v, 100);
        // Now largest should become 8 (skipping the hole at 9).
        assert_eq!(slots.largest_id(), 8);

        let (id2, v2) = slots.remove_largest().expect("should remove next largest");
        assert_eq!(id2, 8);
        assert_eq!(*v2, 80);
        assert_eq!(slots.largest_id(), -1);
        assert!(slots.remove_largest().is_none());
    }

    // --- FileSlots tests ---

    #[test]
    fn test_basic_insert_get() {
        let slots = FileSlots::with_capacity(4);
        let file = create_temp_file();

        slots.insert(0, file.clone());
        assert!(slots.get(0).is_some());
        assert!(slots.get(1).is_none());
    }

    #[test]
    fn test_remove() {
        let slots = FileSlots::with_capacity(4);
        let file = create_temp_file();

        slots.insert(5, file);
        assert!(slots.get(5).is_some());

        let removed = slots.remove(5);
        assert!(removed.is_some());
        assert!(slots.get(5).is_none());
    }

    #[test]
    fn test_auto_resize() {
        let slots = FileSlots::with_capacity(4);

        // Insert files that would collide without resize
        // With capacity 4: file_id 0 and 4 both map to slot 0
        for i in 0..8 {
            let file = create_temp_file();
            slots.insert(i, file);
        }

        // Verify all files are accessible
        for i in 0..8 {
            assert!(
                slots.get(i).is_some(),
                "File {} should be accessible after resize",
                i
            );
        }

        // Capacity should have grown
        assert!(
            slots.capacity() >= 8,
            "Capacity should be at least 8, got {}",
            slots.capacity()
        );
    }

    #[test]
    fn test_resize_preserves_files() {
        let slots = FileSlots::with_capacity(2);

        let file0 = create_temp_file();
        let file1 = create_temp_file();

        slots.insert(0, file0);
        slots.insert(1, file1);

        // This should trigger resize (slot 2 % 2 = 0, collides with file 0)
        let file2 = create_temp_file();
        slots.insert(2, file2);

        // All files should still be accessible
        assert!(slots.get(0).is_some());
        assert!(slots.get(1).is_some());
        assert!(slots.get(2).is_some());
    }

    #[test]
    fn test_largest_id() {
        let slots = FileSlots::with_capacity(4);
        assert_eq!(slots.largest_id(), -1);

        slots.insert(5, create_temp_file());
        assert_eq!(slots.largest_id(), 5);

        slots.insert(3, create_temp_file());
        assert_eq!(slots.largest_id(), 5); // Should not decrease

        slots.insert(10, create_temp_file());
        assert_eq!(slots.largest_id(), 10);
    }

    #[test]
    fn test_rotate() {
        let slots = FileSlots::with_capacity(4);

        // Insert first file
        slots.insert(0, create_temp_file());
        slots.set_current_file(create_temp_file());

        // Rotate to new segment
        slots.rotate(create_temp_file(), create_temp_file());

        assert_eq!(slots.largest_id(), 1);
        assert!(slots.get(0).is_some());
        assert!(slots.get(1).is_some());
        assert!(slots.get_current().is_some());
    }

    #[test]
    fn test_clear() {
        let slots = FileSlots::with_capacity(4);

        for i in 0..4 {
            slots.insert(i, create_temp_file());
        }
        slots.set_current_file(create_temp_file());

        slots.clear();

        assert_eq!(slots.largest_id(), -1);
        for i in 0..4 {
            assert!(slots.get(i).is_none());
        }
        assert!(slots.get_current().is_none());
    }
}
