use crate::error::ErrorCode;
use crate::states::*;
use anchor_lang::prelude::*;
use std::ops::DerefMut;

#[derive(Accounts)]
#[instruction(index: u16)]
pub struct CreateAmmConfig<'info> {
    /// Address to be set as protocol owner.
    #[account(
        mut,
        address = crate::admin::ID @ ErrorCode::NotApproved
    )]
    pub owner: Signer<'info>,

    /// Initialize config state account to store protocol owner address and fee rates.
    #[account(
        init,
        seeds = [
            AMM_CONFIG_SEED.as_bytes(),
            &index.to_be_bytes()
        ],
        bump,
        payer = owner,
        space = AmmConfig::LEN
    )]
    pub amm_config: Account<'info, AmmConfig>,

    pub system_program: Program<'info, System>,
}

pub fn create_amm_config(
    ctx: Context<CreateAmmConfig>,
    index: u16,
    tick_spacing: u16,
    trade_fee_rate: u32,
    protocol_fee_rate: u32,
    fund_fee_rate: u32,
) -> Result<()> {
    require_gt!(FEE_RATE_DENOMINATOR_VALUE, trade_fee_rate);
    require_gte!(
        FEE_RATE_DENOMINATOR_VALUE,
        fund_fee_rate + protocol_fee_rate
    );
    require_gte!(MAX_TICK_SPACING, tick_spacing);
    let amm_config = ctx.accounts.amm_config.deref_mut();
    amm_config.owner = crate::protocol_fee_owner::ID;
    amm_config.bump = ctx.bumps.amm_config;
    amm_config.index = index;
    amm_config.trade_fee_rate = trade_fee_rate;
    amm_config.protocol_fee_rate = protocol_fee_rate;
    amm_config.tick_spacing = tick_spacing;
    amm_config.fund_fee_rate = fund_fee_rate;
    amm_config.padding_u32 = 0;
    amm_config.fund_owner = crate::fund_fee_owner::ID;

    emit!(ConfigChangeEvent {
        index: amm_config.index,
        owner: ctx.accounts.owner.key(),
        trade_fee_rate: amm_config.trade_fee_rate,
        protocol_fee_rate: amm_config.protocol_fee_rate,
        tick_spacing: amm_config.tick_spacing,
        fund_fee_rate: amm_config.fund_fee_rate,
        fund_owner: amm_config.fund_owner,
    });

    Ok(())
}
