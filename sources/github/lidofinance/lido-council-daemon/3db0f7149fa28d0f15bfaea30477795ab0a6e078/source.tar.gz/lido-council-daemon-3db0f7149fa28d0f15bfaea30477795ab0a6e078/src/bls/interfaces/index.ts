export * from './deposit.interface';
