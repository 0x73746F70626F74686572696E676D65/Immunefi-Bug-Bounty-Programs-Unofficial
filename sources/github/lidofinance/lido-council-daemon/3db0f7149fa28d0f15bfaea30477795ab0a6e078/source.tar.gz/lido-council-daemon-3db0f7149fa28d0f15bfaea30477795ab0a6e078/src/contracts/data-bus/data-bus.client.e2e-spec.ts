import { Block } from '@ethersproject/providers';
import { ethers } from 'ethers';
import { formatBytes32String } from 'ethers/lib/utils';
import { TEST_SERVER_PORT } from './utils/constants';
import { DataBusClient } from './data-bus.client';
import {
  MessageDepositV1,
  MessageDepositV2,
  MessagePauseV3,
  MessagePauseV4,
  MessagePingV1,
  MessagesDataMap,
  MessagesNames,
  MessageUnvetV1,
  MessageUnvetV2,
} from './data-bus.serializer';
import { HardhatServer } from '../../../test/helpers/hardhat-server';
import { accountImpersonate, setBalance } from '../../../test/helpers/provider';
import { getSecurityOwner } from '../../../test/helpers/dsm';

jest.setTimeout(40_000);

export const randomInt = (min: number, max: number) =>
  Math.floor(Math.random() * (max - min + 1)) + min;

/** The compact pair DSM v4 takes. */
const COMPACT_SIGNATURE = {
  r: '0x' + '0'.repeat(64),
  vs: '0x' + '0'.repeat(64),
};

/** 65 bytes, the layout DSM v5 forwards to the guardian's ERC-1271 check. */
const SIGNATURE_BLOB = '0x' + '0'.repeat(130);

const getVariants = (block: Block) => {
  const messages = [
    {
      name: 'MessagePingV1' as const,
      data: {
        blockNumber: block.number,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
    {
      name: 'MessageDepositV1' as const,
      data: {
        blockNumber: block.number,
        blockHash: block.hash as string,
        depositRoot: '0x' + '0'.repeat(64),
        stakingModuleId: randomInt(1, 5),
        nonce: randomInt(1, 100),
        signature: COMPACT_SIGNATURE,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
    {
      name: 'MessageUnvetV1' as const,
      data: {
        blockNumber: block.number,
        blockHash: block.hash as string,
        stakingModuleId: randomInt(1, 5),
        nonce: randomInt(1, 100),
        operatorIds: formatBytes32String(
          'operator' + randomInt(1, 10).toString(),
        ),
        vettedKeysByOperator: formatBytes32String(
          'keys' + randomInt(1, 10).toString(),
        ),
        signature: COMPACT_SIGNATURE,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
    {
      name: 'MessagePauseV3' as const,
      data: {
        blockNumber: block.number,
        blockHash: block.hash as string,
        signature: COMPACT_SIGNATURE,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
    {
      name: 'MessageDepositV2' as const,
      data: {
        blockNumber: block.number,
        blockHash: block.hash as string,
        depositRoot: '0x' + '0'.repeat(64),
        stakingModuleId: randomInt(1, 5),
        nonce: randomInt(1, 100),
        signature: SIGNATURE_BLOB,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
    {
      name: 'MessageUnvetV2' as const,
      data: {
        blockNumber: block.number,
        blockHash: block.hash as string,
        stakingModuleId: randomInt(1, 5),
        nonce: randomInt(1, 100),
        operatorIds: formatBytes32String(
          'operator' + randomInt(1, 10).toString(),
        ),
        vettedKeysByOperator: formatBytes32String(
          'keys' + randomInt(1, 10).toString(),
        ),
        signature: SIGNATURE_BLOB,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
    {
      name: 'MessagePauseV4' as const,
      data: {
        blockNumber: block.number,
        blockHash: block.hash as string,
        signature: SIGNATURE_BLOB,
        app: { version: '0x' + '0'.repeat(64) },
      },
    },
  ];

  return messages;
};

const getVariant = <Name extends MessagesNames>(
  name: Name,
  variants: ReturnType<typeof getVariants>,
): MessagesDataMap[Name] => {
  const dataVariant = variants.find((n) => n.name === name);
  if (!dataVariant) {
    throw new Error(`variant with name ${name} not found`);
  }
  return dataVariant.data as MessagesDataMap[Name];
};

describe('DataBus', () => {
  let provider: ethers.providers.JsonRpcProvider;
  let owner: ethers.Signer;
  let sdk: DataBusClient;
  let variants: ReturnType<typeof getVariants>;
  let hardhatServer: HardhatServer;
  let dsmOwnerAddress: string;
  let dataBusAddress: string;
  let testStartBlock: number;

  const setupServer = async () => {
    hardhatServer = new HardhatServer();
    await hardhatServer.start();
  };

  beforeEach(async () => {
    await setupServer();
    dsmOwnerAddress = await getSecurityOwner();
    await accountImpersonate(dsmOwnerAddress);
    await setBalance(dsmOwnerAddress, 100);

    // Set up Ganache provider (ensure Ganache is running on port 8545)
    provider = new ethers.providers.JsonRpcProvider(
      'http://127.0.0.1:' + TEST_SERVER_PORT,
    );

    // Add mock waitForTransactionWithFallback method for tests
    // DataBusClient expects SimpleFallbackJsonRpcBatchProvider
    (provider as any).waitForTransactionWithFallback = async (
      txHash: string,
    ) => {
      const receipt = await provider.waitForTransaction(txHash);
      return { receipt, pollCount: 1, elapsedMs: 0 };
    };

    // Get current block number for test start reference
    const currentBlock = await provider.getBlock('latest');
    testStartBlock = currentBlock.number;

    variants = getVariants(currentBlock);

    // Get the first account as the owner
    // const accounts = await provider.listAccounts();
    owner = provider.getSigner(dsmOwnerAddress); //accounts[0]);

    // Deploy the DataBus contract from bytecode
    const dataBusBytecode =
      '0x6080604052348015600f57600080fd5b5061023e8061001f6000396000f3fe608060405234801561001057600080fd5b506004361061002b5760003560e01c806323c640e714610030575b600080fd5b61004a60048036038101906100459190610126565b61004c565b005b3373ffffffffffffffffffffffffffffffffffffffff168383836040516100749291906101e4565b60405180910390a2505050565b600080fd5b600080fd5b6000819050919050565b61009e8161008b565b81146100a957600080fd5b50565b6000813590506100bb81610095565b92915050565b600080fd5b600080fd5b600080fd5b60008083601f8401126100e6576100e56100c1565b5b8235905067ffffffffffffffff811115610103576101026100c6565b5b60208301915083600182028301111561011f5761011e6100cb565b5b9250929050565b60008060006040848603121561013f5761013e610081565b5b600061014d868287016100ac565b935050602084013567ffffffffffffffff81111561016e5761016d610086565b5b61017a868287016100d0565b92509250509250925092565b600082825260208201905092915050565b82818337600083830152505050565b6000601f19601f8301169050919050565b60006101c38385610186565b93506101d0838584610197565b6101d9836101a6565b840190509392505050565b600060208201905081810360008301526101ff8184866101b7565b9050939250505056fea2646970667358221220826bce2fe59a712d479e84bbd2d619db54603716b7144a93a507d3ee391eb60f64736f6c634300081a0033'; // Replace with your contract's bytecode

    // The ABI for the DataBus contract functions
    const dataBusABI = ['function sendMessage(bytes32 _eventId, bytes _data)'];

    // Create a ContractFactory to deploy the contract
    const factory = new ethers.ContractFactory(
      dataBusABI,
      dataBusBytecode,
      owner,
    );
    const dataBusContract = await factory.deploy();
    await dataBusContract.deployed();

    dataBusAddress = dataBusContract.address;
    // Create the SDK instance
    sdk = new DataBusClient(dataBusAddress, owner);
  });

  afterEach(async () => {
    await hardhatServer.stop();
  });

  afterAll(() => {
    if (global.gc) global.gc();
  });

  it('should measure gas for sendPingMessage', async () => {
    const messageName = 'MessagePingV1' as const;
    const dataVariant: MessagePingV1 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant);

    const receipt = await tx.wait();
    const { gasUsed } = receipt;

    console.log('Gas used for sendPingMessage:', gasUsed.toString());

    expect(gasUsed.toNumber()).toBeLessThanOrEqual(29847);

    const events = await sdk.get('MessagePingV1', testStartBlock - 1);
    const [event] = events;

    expect(event.data).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());

    const allEvents = await sdk.getAll(testStartBlock - 1);
    expect(event).toEqual(allEvents[0]);
  });

  it('should measure gas for sendDepositMessage', async () => {
    const messageName = 'MessageDepositV2' as const;
    const dataVariant: MessageDepositV2 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant);

    const receipt = await tx.wait();
    const { gasUsed } = receipt;

    console.log('Gas used for sendDepositMessage:', gasUsed.toString());

    expect(gasUsed.toNumber()).toBeLessThanOrEqual(31858);

    const events = await sdk.get(messageName, testStartBlock - 1);

    const [event] = events;
    const eventData = event.data;

    expect(eventData).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());

    const allEvents = await sdk.getAll(testStartBlock - 1);
    expect(event).toEqual(allEvents[0]);
  });

  it('should measure gas for sendUnvetMessage', async () => {
    const messageName = 'MessageUnvetV2' as const;
    const dataVariant: MessageUnvetV2 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant);

    const receipt = await tx.wait();
    const { gasUsed } = receipt;

    console.log('Gas used for sendUnvetMessage:', gasUsed.toString());

    expect(gasUsed.toNumber()).toBeLessThanOrEqual(34024);

    const events = await sdk.get('MessageUnvetV2', testStartBlock - 1);
    const [event] = events;

    expect(event.data).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());

    const allEvents = await sdk.getAll(testStartBlock - 1);
    expect(event).toEqual(allEvents[0]);
  });

  it('should measure gas for sendPauseMessage', async () => {
    const messageName = 'MessagePauseV4' as const;
    const dataVariant: MessagePauseV4 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant as any);

    const receipt = await tx.wait();
    const { gasUsed } = receipt;

    console.log('Gas used for sendPauseMessage:', gasUsed.toString());

    expect(gasUsed.toNumber()).toBeLessThanOrEqual(30213);

    const events = await sdk.get(messageName, testStartBlock - 1);
    const [event] = events;

    expect(event.data).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());

    const allEvents = await sdk.getAll(testStartBlock - 1);
    expect(event).toEqual(allEvents[0]);
  });

  // The DSM v4 events stay live while that contract is supported.

  it('should measure gas for the v4 deposit message', async () => {
    const messageName = 'MessageDepositV1' as const;
    const dataVariant: MessageDepositV1 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant);
    const { gasUsed } = await tx.wait();

    console.log('Gas used for the v4 deposit message:', gasUsed.toString());
    expect(gasUsed.toNumber()).toBeLessThanOrEqual(31858);

    const [event] = await sdk.get(messageName, testStartBlock - 1);

    expect(event.data).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());
  });

  it('should measure gas for the v4 unvet message', async () => {
    const messageName = 'MessageUnvetV1' as const;
    const dataVariant: MessageUnvetV1 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant);
    const { gasUsed } = await tx.wait();

    console.log('Gas used for the v4 unvet message:', gasUsed.toString());
    expect(gasUsed.toNumber()).toBeLessThanOrEqual(34024);

    const [event] = await sdk.get(messageName, testStartBlock - 1);

    expect(event.data).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());
  });

  it('should measure gas for the v4 pause message', async () => {
    const messageName = 'MessagePauseV3' as const;
    const dataVariant: MessagePauseV3 = getVariant(messageName, variants);

    const tx = await sdk.sendMessage(messageName, dataVariant as any);
    const { gasUsed } = await tx.wait();

    console.log('Gas used for the v4 pause message:', gasUsed.toString());
    expect(gasUsed.toNumber()).toBeLessThanOrEqual(30213);

    const [event] = await sdk.get(messageName, testStartBlock - 1);

    expect(event.data).toEqual(dataVariant);
    expect(event.guardianAddress).toEqual(await owner.getAddress());
  });
});
