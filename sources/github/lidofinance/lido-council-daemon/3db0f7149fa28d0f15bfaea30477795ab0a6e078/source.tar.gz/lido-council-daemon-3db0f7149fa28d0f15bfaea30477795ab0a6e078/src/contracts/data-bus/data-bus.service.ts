import { formatEther } from '@ethersproject/units';
import { Wallet } from '@ethersproject/wallet';
import { BigNumber } from '@ethersproject/bignumber';
import { Inject, Injectable, LoggerService } from '@nestjs/common';
import { getToken, InjectMetric } from '@willsoto/nestjs-prometheus';
import { OneAtTime } from 'common/decorators';
import {
  METRIC_DATA_BUS_ACCOUNT_BALANCE,
  METRIC_DATA_BUS_RPC_REQUEST_DURATION,
  METRIC_DATA_BUS_RPC_REQUEST_ERRORS,
  METRIC_NONCE_LATEST,
  METRIC_NONCE_PENDING,
  METRIC_NONCE_GAP,
} from 'common/prometheus';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Counter, Gauge, Histogram } from 'prom-client';
import {
  DATA_BUS_ADDRESS,
  DATA_BUS_BALANCE_UPDATE_BLOCK_RATE,
} from './data-bus.constants';

import { Configuration } from 'common/config';
import { DataBusClient } from './data-bus.client';
import { MessageRequiredFields } from 'messages';
import { DSMMessageSender } from './dsm-message-sender.client';
import { SimpleFallbackJsonRpcBatchProvider } from '@lido-nestjs/execution';
import { DATA_BUS_PROVIDER_TOKEN } from 'provider/data-bus-provider.module';
import { WalletService } from 'wallet';

@Injectable()
export class DataBusService {
  private readonly dsmMessageSenders = new Map<string, DSMMessageSender>();
  private provider!: SimpleFallbackJsonRpcBatchProvider;
  constructor(
    @InjectMetric(METRIC_DATA_BUS_ACCOUNT_BALANCE)
    private accountBalance: Gauge<string>,
    @InjectMetric(METRIC_NONCE_LATEST) private nonceLatest: Gauge<string>,
    @InjectMetric(METRIC_NONCE_PENDING) private noncePending: Gauge<string>,
    @InjectMetric(METRIC_NONCE_GAP) private nonceGap: Gauge<string>,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private logger: LoggerService,
    @Inject(DATA_BUS_ADDRESS) private dataBusAddress: string,
    private walletService: WalletService,
    protected readonly config: Configuration,
    @Inject(getToken(METRIC_DATA_BUS_RPC_REQUEST_DURATION))
    private rpcReqDurationMetric: Histogram<string>,
    @Inject(getToken(METRIC_DATA_BUS_RPC_REQUEST_ERRORS))
    private rpcReqErrorsMetric: Counter<string>,
    @Inject(DATA_BUS_PROVIDER_TOKEN)
    private dataBusProvider: SimpleFallbackJsonRpcBatchProvider,
  ) {}

  async initialize() {
    this.provider = this.dataBusProvider;

    await this.monitorGuardianDataBusBalance();
    this.subscribeToEVMChainUpdates();
  }

  /**
   * Subscribes to the event of a new block appearance
   */
  public subscribeToEVMChainUpdates() {
    const provider = this.provider;
    provider.on('block', async (blockNumber) => {
      if (blockNumber % DATA_BUS_BALANCE_UPDATE_BLOCK_RATE !== 0) return;
      await this.monitorGuardianDataBusBalance().catch((error) =>
        this.logger.error(error),
      );
    });

    this.logger.log('DataBusService subscribed to network events');
  }

  /**
   * Monitors the guardian account balance and nonce to ensure it is sufficient for transactions.
   * Updates the account balance and nonce metrics.
   */
  @OneAtTime()
  public async monitorGuardianDataBusBalance() {
    const delegateAddress = this.address;
    const [balanceWei, latestNonce, pendingNonce, network] = await Promise.all([
      this.getAccountBalance(delegateAddress),
      this.provider.getTransactionCount(delegateAddress, 'latest'),
      this.provider.getTransactionCount(delegateAddress, 'pending'),
      this.provider.getNetwork(),
    ]);

    const balanceETH = formatEther(balanceWei);
    const { chainId } = network;
    this.accountBalance.set({ chainId, delegateAddress }, Number(balanceETH));
    this.isBalanceSufficient(balanceWei, chainId);

    const gap = pendingNonce - latestNonce;
    const labels = { network: 'data-bus', delegateAddress };
    this.nonceLatest.labels(labels).set(latestNonce);
    this.noncePending.labels(labels).set(pendingNonce);
    this.nonceGap.labels(labels).set(gap);
  }

  /**
   * Retrieves the account balance in Wei.
   * @returns The account balance in Wei.
   */
  public async getAccountBalance(
    walletAddress = this.address,
  ): Promise<BigNumber> {
    const provider = this.provider;
    return await provider.getBalance(walletAddress);
  }

  /**
   * Checks if the balance is sufficient to perform at least 10000 messages.
   * @param balanceWei The current balance in Wei.
   * @returns True if the balance is sufficient, otherwise false.
   */
  public isBalanceSufficient(balanceWei: BigNumber, chainId: number): boolean {
    const balance = formatEther(balanceWei);
    const isSufficient = balanceWei.gte(
      this.config.EVM_CHAIN_DATA_BUS_WALLET_MIN_BALANCE,
    );

    if (isSufficient) {
      this.logger.log('DataBusService account balance is sufficient', {
        balance,
        chainId,
      });
    } else {
      this.logger.warn('DataBusService account balance is too low', {
        balance,
        chainId,
      });
    }

    return isSufficient;
  }

  /**
   * Wallet class inherits Signer and can sign transactions and messages
   * using a private key as a standard Externally Owned Account (EOA)
   */
  private get wallet(): Wallet {
    return this.walletService.wallet.connect(this.provider);
  }

  private get dsmMessageSender(): DSMMessageSender {
    const wallet = this.wallet;
    const cachedSender = this.dsmMessageSenders.get(wallet.address);
    if (cachedSender) return cachedSender;

    const dataBusClient = new DataBusClient(this.dataBusAddress, wallet);
    const sender = new DSMMessageSender(dataBusClient);
    this.dsmMessageSenders.set(wallet.address, sender);

    return sender;
  }

  /**
   * Guardian wallet address
   */
  private get address(): string {
    return this.wallet.address;
  }

  public async publish(
    message: MessageRequiredFields & { app: { version: string } },
  ) {
    try {
      return await this.dsmMessageSender.sendMessage(message);
    } catch (error: any) {
      this.logger.error(
        `An error occurred when sending a message using Data Bus`,
        { errorMessage: error.message, dataBusMessage: message },
      );
      throw error;
    }
  }
}
