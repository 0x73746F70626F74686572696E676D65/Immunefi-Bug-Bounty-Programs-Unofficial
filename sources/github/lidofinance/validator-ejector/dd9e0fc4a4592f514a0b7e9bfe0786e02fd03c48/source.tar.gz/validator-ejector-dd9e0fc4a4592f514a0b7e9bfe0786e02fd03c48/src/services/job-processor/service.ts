import type { LoggerService } from '../../lib/index.js'
import type { ExecutionApiService } from '../execution-api/service.js'
import type { ConfigService } from '../config/service.js'
import type { MessagesProcessorService } from '../messages-processor/service.js'
import type { ConsensusApiService } from '../consensus-api/service.js'
import type { WebhookProcessorService } from '../webhook-caller/service.js'
import type { MetricsService } from '../prom/service.js'
import type { MessageStorage } from './message-storage.js'
import type { MessageReloader } from '../message-reloader/message-reloader.js'
import { ExitLogsService } from 'services/exit-logs/service.js'

export type ExitMessage = {
  message: {
    epoch: string
    validator_index: string
  }
  signature: string
}

export type ExitMessageWithMetadata = {
  data: ExitMessage
  meta: {
    fileChecksum: string
    filename: string
    forkVersion: string
  }
}

const FINALIZED_BLOCK_EQUIVALENT = 120

export type JobProcessorService = ReturnType<typeof makeJobProcessor>

export const makeJobProcessor = ({
  logger,
  config,
  messageReloader,
  executionApi,
  exitLogs,
  consensusApi,
  messagesProcessor,
  webhookProcessor,
  metrics,
}: {
  logger: LoggerService
  config: ConfigService
  messageReloader: MessageReloader
  executionApi: ExecutionApiService
  exitLogs: ExitLogsService
  consensusApi: ConsensusApiService
  messagesProcessor: MessagesProcessorService
  webhookProcessor: WebhookProcessorService
  metrics: MetricsService
}) => {
  const createExitingValidatorsRecord = (
    validators: any[]
  ): Record<string, boolean> => {
    return Object.fromEntries(
      validators.map((v) => [
        v.index,
        consensusApi.isValidatorExiting(v.validator.exit_epoch),
      ])
    )
  }

  const handleJob = async ({
    messageStorage,
  }: {
    eventsNumber: number
    messageStorage: MessageStorage
  }) => {
    logger.info('Job started', {
      ejectorScope: config.EJECTOR_SCOPE,
    })

    await messageReloader.reloadAndVerifyMessages(messageStorage)

    // Resolving contract addresses on each job to automatically pick up changes without requiring a restart
    await executionApi.resolveExitBusAddress()
    await executionApi.resolveConsensusAddress()

    const lastBlockNumber = await executionApi.latestBlockNumber()

    const eventsForEject = await exitLogs.getLogs(lastBlockNumber)

    logger.info('Handling ejection requests', {
      amount: eventsForEject.length,
    })

    const validatorIndices = eventsForEject.map((event) => event.validatorIndex)

    const validatorsHead = await consensusApi.fetchValidatorsBatch(
      validatorIndices,
      config.VALIDATORS_BATCH_SIZE,
      'head'
    )
    const exitingValidatorsRecord =
      createExitingValidatorsRecord(validatorsHead)

    const validatorsFinalized = await consensusApi.fetchValidatorsBatch(
      validatorIndices,
      config.VALIDATORS_BATCH_SIZE,
      'finalized'
    )
    const exitingValidatorsFinalizedRecord =
      createExitingValidatorsRecord(validatorsFinalized)

    for (const [ix, event] of eventsForEject.entries()) {
      logger.debug(`Handling exit ${ix + 1}/${eventsForEject.length}`, event)

      if (event.acknowledged) {
        logger.debug('Event already acknowledged, skipping')
        continue
      }

      try {
        if (exitingValidatorsRecord[event.validatorIndex]) {
          logger.info('Validator is already exiting(ed), skipping', {
            validatorIndex: event.validatorIndex,
          })
          // Acknowledge the event to avoid processing it again
          // We do an additional check, because if we didn't check for finalized,
          // we might miss the reorganization.
          if (
            lastBlockNumber - event.blockNumber > FINALIZED_BLOCK_EQUIVALENT ||
            exitingValidatorsFinalizedRecord[event.validatorIndex]
          ) {
            event.ack()
          }
          continue
        }

        if (config.DRY_RUN) {
          logger.info('Not initiating an exit in dry run mode')
          continue
        }

        if (config.VALIDATOR_EXIT_WEBHOOK) {
          await webhookProcessor.send(config.VALIDATOR_EXIT_WEBHOOK, event)
        } else {
          await messagesProcessor.exit(messageStorage, event)
        }
      } catch (e) {
        logger.error(`Unable to process exit for ${event.validatorPubkey}`, e)
        metrics.exitActions.inc({ result: 'error' })
      }
    }

    logger.info('Updating exit messages left metrics from validator statuses')

    try {
      const validatorIndices = messageStorage.messages.map(
        (msg) => msg.message.validator_index
      )
      const exitingCount = await consensusApi.getExitingValidatorsCount(
        validatorIndices,
        config.VALIDATORS_BATCH_SIZE
      )
      metrics.updateLeftMessages(messageStorage, exitingCount)
    } catch (e) {
      logger.error(
        'Unable to update exit messages left metrics from validator statuses',
        e
      )
    }

    logger.info('Job finished')
  }

  return { handleJob }
}
