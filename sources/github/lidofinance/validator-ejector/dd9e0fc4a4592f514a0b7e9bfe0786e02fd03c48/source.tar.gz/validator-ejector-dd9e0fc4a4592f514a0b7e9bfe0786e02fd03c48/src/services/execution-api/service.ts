import {
  makeFallback,
  makeLogger,
  safelyParseJsonResponse,
} from '../../lib/index.js'
import { makeRequest } from '../../lib/index.js'

import { ethers } from 'ethers'

import { ConfigService } from '../../services/config/service.js'
import { JwtService } from '../jwt/service.js'

import {
  syncingDTO,
  lastBlockNumberDTO,
  funcDTO,
  genericArrayOfStringsDTO,
  logsDTO,
} from './dto.js'
import { RequestConfig } from '../../lib/request/types.js'
import { JsonRpcServerError } from './errors.js'

// JSON-RPC 2.0 server-side error codes: see https://www.jsonrpc.org/specification#error_object
// and Ethereum geth's commonly-seen variants. Treat as retryable since they're
// endpoint-specific or transient, not request-validation errors.
const RPC_SERVER_ERROR_CODES = new Set([
  -32603, // internal error
  -32005, // limit exceeded (throttling)
  -32000, // server error (generic)
])

const isRpcServerError = (json: unknown): boolean => {
  if (!json || typeof json !== 'object') return false
  const err = (json as { error?: { code?: number } }).error
  return (
    err != null &&
    typeof err.code === 'number' &&
    RPC_SERVER_ERROR_CODES.has(err.code)
  )
}

export type ExecutionApiService = ReturnType<typeof makeExecutionApi>

export const createExecutionRequestHeaders = (
  JWT_SECRET_PATH: string | undefined,
  jwtService?: JwtService
) => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }

  if (JWT_SECRET_PATH && jwtService) {
    const token = jwtService.generateToken()
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
  }

  return headers
}

export const makeExecutionApi = (
  request: ReturnType<typeof makeRequest>,
  logger: ReturnType<typeof makeLogger>,
  {
    EXECUTION_NODE,
    LOCATOR_ADDRESS,
    JWT_SECRET_PATH,
    LOAD_LOGS_STEP,
  }: ConfigService,
  jwtService?: JwtService
) => {
  const fallback = makeFallback(EXECUTION_NODE, logger, 'EL')

  let exitBusAddress: string
  let consensusAddress: string

  const elRequest = (requestConfig: RequestConfig) =>
    fallback(async (url) => {
      const headers = createExecutionRequestHeaders(JWT_SECRET_PATH, jwtService)
      const res = await request(url, { ...requestConfig, headers })
      const json = await safelyParseJsonResponse(res, logger)
      if (isRpcServerError(json)) {
        const rpcErr = (json as { error?: unknown }).error
        throw new JsonRpcServerError(rpcErr as any)
      }
      return json
    })

  const checkSync = async () => {
    const json = await elRequest({
      method: 'POST',
      body: JSON.stringify({
        jsonrpc: '2.0',
        method: 'eth_syncing',
        params: [],
        id: 1,
      }),
    })
    const { result } = syncingDTO(json)
    logger.debug('fetched syncing status')
    return result
  }

  const latestBlockNumber = async () => {
    const json = await elRequest({
      method: 'POST',
      body: JSON.stringify({
        jsonrpc: '2.0',
        method: 'eth_getBlockByNumber',
        params: ['finalized', false],
        id: 1,
      }),
    })
    const {
      result: { number },
    } = lastBlockNumberDTO(json)
    logger.debug('fetched latest block number', json)
    return ethers.BigNumber.from(number).toNumber()
  }

  const resolveExitBusAddress = async () => {
    const func = ethers.utils.Fragment.from(
      'function validatorsExitBusOracle() view returns (address)'
    )
    const iface = new ethers.utils.Interface([func])
    const sig = iface.encodeFunctionData(func.name)

    try {
      const json = await elRequest({
        method: 'POST',
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_call',
          params: [
            {
              from: null,
              to: LOCATOR_ADDRESS,
              data: sig,
            },
            'finalized',
          ],
          id: 1,
        }),
      })

      const { result } = funcDTO(json)

      const decoded = iface.decodeFunctionResult(func.name, result)

      const validated = genericArrayOfStringsDTO(decoded)

      exitBusAddress = validated[0] // only returns one value

      logger.info('Resolved Exit Bus contract address using the Locator', {
        exitBusAddress,
      })
    } catch (e) {
      logger.error('Unable to resolve Exit Bus contract', e)
      throw new Error(
        'Unable to resolve Exit Bus contract address using the Locator. Please make sure LOCATOR_ADDRESS is correct.'
      )
    }
  }

  const resolveConsensusAddress = async () => {
    const func = ethers.utils.Fragment.from(
      'function getConsensusContract() view returns (address)'
    )
    const iface = new ethers.utils.Interface([func])
    const sig = iface.encodeFunctionData(func.name)

    try {
      const json = await elRequest({
        method: 'POST',
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_call',
          params: [
            {
              from: null,
              to: exitBusAddress,
              data: sig,
            },
            'finalized',
          ],
          id: 1,
        }),
      })

      const { result } = funcDTO(json)

      const decoded = iface.decodeFunctionResult(func.name, result)

      const validated = genericArrayOfStringsDTO(decoded)

      consensusAddress = validated[0] // only returns one value

      logger.info('Resolved Consensus contract address', {
        consensusAddress,
      })
    } catch (e) {
      logger.error('Unable to resolve Consensus contract', e)
      throw new Error('Unable to resolve Consensus contract.')
    }
  }

  const getLogs = async (
    fromBlock: number,
    toBlock: number,
    address: string,
    topics: (string | string[])[]
  ) => {
    if (fromBlock < 0) {
      throw new Error(`fromBlock must be non-negative, got: ${fromBlock}`)
    }

    if (toBlock < 0) {
      throw new Error(`toBlock must be non-negative, got: ${toBlock}`)
    }

    if (fromBlock > toBlock) {
      throw new Error(
        `fromBlock (${fromBlock}) must be <= toBlock (${toBlock})`
      )
    }

    if (!ethers.utils.isAddress(address)) {
      throw new Error(`Invalid Ethereum address: ${address}`)
    }

    // Ranges wider than LOAD_LOGS_STEP are split into sequential sub-requests:
    // nodes and RPC providers cap eth_getLogs ranges, sometimes by silently
    // returning an empty result instead of an error
    const result: ReturnType<typeof logsDTO>['result'] = []

    for (let from = fromBlock; from <= toBlock; from += LOAD_LOGS_STEP) {
      const to = Math.min(from + LOAD_LOGS_STEP - 1, toBlock)

      const json = await elRequest({
        method: 'POST',
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_getLogs',
          params: [
            {
              fromBlock: ethers.utils.hexStripZeros(
                ethers.BigNumber.from(from).toHexString()
              ),
              toBlock: ethers.utils.hexStripZeros(
                ethers.BigNumber.from(to).toHexString()
              ),
              address,
              topics,
            },
          ],
          id: 1,
        }),
      })

      result.push(...logsDTO(json).result)
    }

    return { result }
  }

  return {
    elRequest,
    getLogs,
    get exitBusAddress() {
      if (!exitBusAddress) {
        throw new Error('Exit Bus address is not resolved yet')
      }
      return exitBusAddress
    },
    get consensusAddress() {
      if (!consensusAddress) {
        throw new Error('Consensus address is not resolved yet')
      }
      return consensusAddress
    },
    checkSync,
    latestBlockNumber,
    resolveExitBusAddress,
    resolveConsensusAddress,
  }
}
