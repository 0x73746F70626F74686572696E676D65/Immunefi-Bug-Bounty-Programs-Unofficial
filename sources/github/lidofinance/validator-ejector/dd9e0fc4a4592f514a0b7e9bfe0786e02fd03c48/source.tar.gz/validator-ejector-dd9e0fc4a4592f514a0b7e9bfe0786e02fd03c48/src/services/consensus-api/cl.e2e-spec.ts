import { ConsensusApiService, makeConsensusApi } from './service.js'
import {
  LoggerService,
  abort,
  logger as loggerMiddleware,
  makeLogger,
  makeRequest,
  retry,
} from '../../lib/index.js'
import { mockConfig } from '../../test/config.js'
import { ConfigService } from '../config/service.js'

describe('makeConsensusApi e2e', () => {
  let api: ConsensusApiService
  let logger: LoggerService
  let config: ConfigService

  beforeEach(() => {
    logger = makeLogger({
      level: 'error',
      format: 'simple',
    })

    config = mockConfig(logger, {
      CONSENSUS_NODE:
        process.env.CONSENSUS_NODE ??
        'https://ethereum-beacon-api.publicnode.com',
    })
    api = makeConsensusApi(
      makeRequest([retry(3), loggerMiddleware(logger), abort(30_000)]),
      logger,
      config
    )
  })

  it('should handle batch size correctly with large index array e2e', async () => {
    const indices = Array.from({ length: 3000 }, (_, i) => (i + 1).toString())
    // An exit epoch never unsets, so this count only grows over time;
    // it was 1226 at slot 11724253
    const count = await api.getExitingValidatorsCount(
      indices,
      1000,
      'finalized'
    )
    expect(count).toBeGreaterThanOrEqual(1226)
    expect(count).toBeLessThanOrEqual(3000)
  })

  it('should validate public keys e2e', async () => {
    const validatorData = [
      {
        validatorIndex: '1',
        validatorPubkey:
          '0xa1d1ad0714035353258038e964ae9675dc0252ee22cea896825c01458e1807bfad2f9969338798548d9858a571f7425c',
      },
      {
        validatorIndex: '2',
        validatorPubkey:
          '0xb2ff4716ed345b05dd1dfc6a5a9fa70856d8c75dcc9e881dd2f766d5f891326f0d10e96f3a444ce6c912b69c22c6754d',
      },
      {
        validatorIndex: '3',
        validatorPubkey:
          '0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
      },
    ]

    const validIndices = await api.validatePublicKeys(
      validatorData,
      1000,
      'finalized'
    )
    expect(validIndices.size).toEqual(2)
  })

  it('should fetch validators batch e2e', async () => {
    const indices = ['1', '2']
    const validators = await api.fetchValidatorsBatch(
      indices,
      1000,
      'finalized'
    )

    expect(validators).toHaveLength(2)

    expect(validators[0].index).toBe('1')
    expect(validators[0].status).toBeTruthy()
    expect(validators[0].validator.pubkey).toBe(
      '0xa1d1ad0714035353258038e964ae9675dc0252ee22cea896825c01458e1807bfad2f9969338798548d9858a571f7425c'
    )

    expect(validators[1].index).toBe('2')
    expect(validators[1].status).toBeTruthy()
    expect(validators[1].validator.pubkey).toBe(
      '0xb2ff4716ed345b05dd1dfc6a5a9fa70856d8c75dcc9e881dd2f766d5f891326f0d10e96f3a444ce6c912b69c22c6754d'
    )
  })
})
