import { LRUCache } from 'lru-cache'
import { makeLogger } from '../../lib/index.js'

import { ethers } from 'ethers'

import { txDTO } from './dto.js'
import { ExecutionApiService } from '../../services/execution-api/service.js'

// This is the number of blocks to look back when searching for
// the ConsensusReached event. It should be more than the VEBO frame
const ORACLE_FRAME_BLOCKS = 7200
const LRU_CACHE_MAX_SIZE = 50

// Every calldata shape the verifier can walk. The 4-byte selector of a
// transaction input is the explicit gate that picks the branch.
const submitReportDataIface = new ethers.utils.Interface([
  'function submitReportData(tuple(uint256 consensusVersion, uint256 refSlot, uint256 requestsCount, uint256 dataFormat, bytes data) data, uint256 contractVersion)',
])
const submitExitRequestsDataIface = new ethers.utils.Interface([
  'function submitExitRequestsData(tuple(bytes data, uint256 dataFormat) request)',
])
const submitReportIface = new ethers.utils.Interface([
  'function submitReport(uint256 slot, bytes32 report, uint256 consensusVersion)',
])
// EDF (LIP-37): the oracle member is a DelegationContract and its delegate
// key submits the report wrapped in execute()
const executeIface = new ethers.utils.Interface([
  'function execute(address target, bytes data)',
])

const SUBMIT_REPORT_DATA_SELECTOR =
  submitReportDataIface.getSighash('submitReportData')
const SUBMIT_EXIT_REQUESTS_DATA_SELECTOR =
  submitExitRequestsDataIface.getSighash('submitExitRequestsData')
const SUBMIT_REPORT_SELECTOR = submitReportIface.getSighash('submitReport')
const EXECUTE_SELECTOR = executeIface.getSighash('execute')

const selectorOf = (input: string) => input.slice(0, 10).toLowerCase()

type ExitRequestEvent = {
  stakingModuleId: ethers.BigNumberish
  nodeOperatorId: ethers.BigNumberish
  validatorIndex: ethers.BigNumberish
  validatorPubkey: string
}

// One packed exit request record, layouts from ValidatorsExitBus.sol:
//
// DATA_FORMAT_LIST (1), 64 bytes:
//   | moduleId (3) | nodeOpId (5) | validatorIndex (8) | pubkey (48) |
//
// DATA_FORMAT_LIST_WITH_KEY_INDEX (2), 72 bytes — same fields plus a
// keyIndex the contract uses to look the pubkey up in the registry;
// it is not part of the event, so it is skipped here:
//   | moduleId (3) | nodeOpId (5) | validatorIndex (8) | keyIndex (8) | pubkey (48) |
const decodeExitRequest = (record: string) => ({
  stakingModuleId: ethers.BigNumber.from(
    ethers.utils.hexDataSlice(record, 0, 3)
  ),
  nodeOperatorId: ethers.BigNumber.from(
    ethers.utils.hexDataSlice(record, 3, 8)
  ),
  validatorIndex: ethers.BigNumber.from(
    ethers.utils.hexDataSlice(record, 8, 16)
  ),
  // In both formats the pubkey is the last 48 bytes of the record
  validatorPubkey: ethers.utils.hexDataSlice(
    record,
    ethers.utils.hexDataLength(record) - 48
  ),
})

// The `data` of an oracle report or a submitExitRequestsData call is a batch:
// exit request records packed back to back with no separator, one record per
// validator asked to exit. `dataFormat` (from the same authenticated calldata)
// picks the record layout above and therefore the record length
export const parseExitRequests = (
  data: string,
  dataFormat: ethers.BigNumber
) => {
  const format = dataFormat.toNumber()
  if (format !== 1 && format !== 2)
    throw new Error(`Unsupported exit requests data format ${format}`)

  const recordLength = format === 1 ? 64 : 72
  const dataLength = ethers.utils.hexDataLength(data)
  if (dataLength === 0 || dataLength % recordLength !== 0)
    throw new Error('Invalid exit requests data length')

  const records: ReturnType<typeof decodeExitRequest>[] = []
  for (let offset = 0; offset < dataLength; offset += recordLength)
    records.push(
      decodeExitRequest(
        ethers.utils.hexDataSlice(data, offset, offset + recordLength)
      )
    )
  return records
}

// The exit downstream is executed by the validator index from the event, so
// the signed data must contain the whole requested record, not merely the
// pubkey somewhere in the byte stream: every event field has to match one
// record exactly.
export const containsExitRequest = (
  data: string,
  dataFormat: ethers.BigNumber,
  event: ExitRequestEvent
) =>
  parseExitRequests(data, dataFormat).some(
    (request) =>
      request.stakingModuleId.eq(event.stakingModuleId) &&
      request.nodeOperatorId.eq(event.nodeOperatorId) &&
      request.validatorIndex.eq(event.validatorIndex) &&
      request.validatorPubkey === event.validatorPubkey.toLowerCase()
  )

export type VerifierService = ReturnType<typeof makeVerifier>

export const makeVerifier = (
  logger: ReturnType<typeof makeLogger>,
  el: ExecutionApiService,
  {
    ORACLE_ADDRESSES_ALLOWLIST,
    SUBMIT_TX_HASH_ALLOWLIST,
  }: {
    ORACLE_ADDRESSES_ALLOWLIST: string[]
    SUBMIT_TX_HASH_ALLOWLIST: string[]
  }
) => {
  const lruTransactionCache = new LRUCache<string, ReturnType<typeof txDTO>>({
    max: LRU_CACHE_MAX_SIZE,
  })
  const lruConsensusReachedLogsCache = new LRUCache<string, string>({
    max: LRU_CACHE_MAX_SIZE,
  })

  const getTransaction = async (transactionHash: string) => {
    const cachedResult = lruTransactionCache.get(transactionHash)
    if (cachedResult?.result) return cachedResult.result

    const json = await el.elRequest({
      method: 'POST',
      body: JSON.stringify({
        jsonrpc: '2.0',
        method: 'eth_getTransactionByHash',
        params: [transactionHash],
        id: 1,
      }),
    })

    const { result } = txDTO(json)
    lruTransactionCache.set(result.hash, { result })
    return result
  }

  const consensusReachedTransactionHash = async (
    toBlock: number,
    refSlot: string,
    hash: string
  ) => {
    const key = `${toBlock}-${refSlot}-${hash}`
    const cachedResult = lruConsensusReachedLogsCache.get(key)
    if (cachedResult) return cachedResult

    const event = ethers.utils.Fragment.from(
      'event ConsensusReached(uint256 indexed refSlot, bytes32 report, uint256 support)'
    )
    const iface = new ethers.utils.Interface([event])
    const eventTopic = iface.getEventTopic(event.name)

    const from = toBlock - ORACLE_FRAME_BLOCKS

    const { result } = await el.getLogs(from, toBlock, el.consensusAddress, [
      eventTopic,
      ethers.utils.hexZeroPad(ethers.BigNumber.from(refSlot).toHexString(), 32),
    ])

    logger.debug('Loaded ConsensusReached events', { amount: result.length })

    const decoded = result.map((event) => ({
      transactionHash: event.transactionHash,
      ...iface.parseLog(event),
    }))

    const found = decoded.find((event) => event.args.report === hash)

    if (!found) {
      logger.error('Failed to find transaction by report hash', {
        toBlock,
        refSlot,
        hash,
      })
      throw new Error('Failed to find transaction by report hash')
    }
    lruConsensusReachedLogsCache.set(key, found.transactionHash)
    return found.transactionHash
  }

  const prepareTransactionData = (tx: ReturnType<typeof txDTO>['result']) => {
    const isLegacyTx =
      Number(tx.type) === 0 || (!tx.maxFeePerGas && !tx.maxPriorityFeePerGas)

    if (isLegacyTx && !tx.gasPrice) {
      throw new Error(
        '[validateTransactionType] Legacy transaction missing gasPrice'
      )
    }

    const baseTxData = {
      gasLimit: ethers.BigNumber.from(tx.gas),
      data: tx.input,
      nonce: parseInt(tx.nonce),
      to: tx.to,
      value: ethers.BigNumber.from(tx.value),
      type: parseInt(tx.type),
      chainId: parseInt(tx.chainId),
    }

    return isLegacyTx
      ? { ...baseTxData, gasPrice: ethers.BigNumber.from(tx.gasPrice || '0') }
      : {
          ...baseTxData,
          maxFeePerGas: ethers.BigNumber.from(tx.maxFeePerGas || '0'),
          maxPriorityFeePerGas: ethers.BigNumber.from(
            tx.maxPriorityFeePerGas || '0'
          ),
        }
  }

  const recoverAddress = async (tx: ReturnType<typeof txDTO>['result']) => {
    const expandedSig = {
      r: tx.r,
      s: tx.s,
      v: parseInt(tx.v),
    }
    const sig = ethers.utils.joinSignature(expandedSig)

    const txData = prepareTransactionData(tx)

    const encodedTx = ethers.utils.serializeTransaction(txData)
    const hash = ethers.utils.keccak256(encodedTx)
    return ethers.utils.recoverAddress(hash, sig)
  }

  // Decodes the consensus report transaction. A pre-EDF member calls
  // submitReport itself; an EDF (LIP-37) member is a DelegationContract
  // whose delegate key wraps the same call in execute(). In both cases the
  // trusted identity is the transaction signer, checked later against the
  // allowlist.
  const decodeSubmitReport = (tx: ReturnType<typeof txDTO>['result']) => {
    switch (selectorOf(tx.input)) {
      case SUBMIT_REPORT_SELECTOR:
        return submitReportIface.decodeFunctionData('submitReport', tx.input)

      case EXECUTE_SELECTOR: {
        const executeDecoded = executeIface.decodeFunctionData(
          'execute',
          tx.input
        )
        if (
          (executeDecoded.target as string).toLowerCase() !==
          el.consensusAddress.toLowerCase()
        ) {
          throw new Error(
            `execute() in the ConsensusReached transaction targets ${executeDecoded.target} instead of the consensus contract (tx: ${tx.hash})`
          )
        }
        if (selectorOf(executeDecoded.data) !== SUBMIT_REPORT_SELECTOR) {
          throw new Error(
            `execute() in the ConsensusReached transaction wraps an unknown function (tx: ${tx.hash})`
          )
        }
        return submitReportIface.decodeFunctionData(
          'submitReport',
          executeDecoded.data
        )
      }

      default:
        throw new Error(
          `ConsensusReached transaction calls an unknown function (tx: ${tx.hash})`
        )
    }
  }

  const verifyTransactionIntegrity = (
    tx: ReturnType<typeof txDTO>['result'],
    expectedHash: string
  ) => {
    const signature = {
      v: Number(tx.v),
      r: tx.r,
      s: tx.s,
    }

    const txData = prepareTransactionData(tx)

    const serialized = ethers.utils.serializeTransaction(txData, signature)
    const computedHash = ethers.utils.keccak256(serialized)

    if (computedHash.toLowerCase() !== expectedHash.toLowerCase()) {
      logger.error(
        '[verifyTransactionIntegrity] Transaction hash mismatch detected',
        {
          computedHash,
          expectedHash,
        }
      )
      throw new Error(
        '[verifyTransactionIntegrity] Transaction hash mismatch detected'
      )
    }
  }

  const verifyEvent = async (
    event: ExitRequestEvent,
    transactionHash: string,
    toBlock: number
  ) => {
    const tx = await getTransaction(transactionHash)

    // EDF (LIP-37): an oracle member that is a DelegationContract submits
    // the Exit Bus report wrapped in execute(); unwrap it before gating on
    // the report function. The trust decision does not rest on this
    // transaction: verifyOracleEvent re-derives it from the consensus report
    let input = tx.input
    if (selectorOf(input) === EXECUTE_SELECTOR) {
      const executeDecoded = executeIface.decodeFunctionData('execute', input)
      if (
        (executeDecoded.target as string).toLowerCase() !==
        el.exitBusAddress.toLowerCase()
      ) {
        throw new Error(
          `execute() in the ValidatorExitRequest transaction targets ${executeDecoded.target} instead of the Exit Bus (tx: ${tx.hash})`
        )
      }
      input = executeDecoded.data
    }

    // Explicit gate: which contract function produced ValidatorExitRequest
    switch (selectorOf(input)) {
      case SUBMIT_REPORT_DATA_SELECTOR:
        // Oracle report finalized on the Exit Bus
        await verifyOracleEvent(
          event,
          submitReportDataIface.decodeFunctionData('submitReportData', input),
          toBlock
        )
        return

      case SUBMIT_EXIT_REQUESTS_DATA_SELECTOR:
        // This transaction contains the full exit requests data. Its hash,
        // unlike the hash of execute(proposalId), commits to that data.
        await verifySubmitExitRequestsDataTransaction(
          event,
          tx,
          transactionHash,
          input
        )
        return

      default:
        throw new Error(
          `ValidatorExitRequest was emitted by unknown contract function (tx: ${tx.hash})`
        )
    }
  }

  const verifyOracleEvent = async (
    event: ExitRequestEvent,
    decoded: ethers.utils.Result,
    toBlock: number
  ) => {
    const { data, refSlot, consensusVersion, requestsCount, dataFormat } =
      decoded.data as {
        data: string
        refSlot: ethers.BigNumber
        consensusVersion: ethers.BigNumber
        requestsCount: ethers.BigNumber
        dataFormat: ethers.BigNumber
      }

    if (!containsExitRequest(data, dataFormat, event))
      throw new Error(
        'Exit request for the validator was not found in finalized tx data'
      )

    const encodedData = ethers.utils.defaultAbiCoder.encode(
      [
        'tuple(uint256 consensusVersion, uint256 refSlot, uint256 requestsCount, uint256 dataFormat, bytes data)',
      ],
      [[consensusVersion, refSlot, requestsCount, dataFormat, data]]
    )

    const dataHash = ethers.utils.keccak256(encodedData)

    const originTxHash = await consensusReachedTransactionHash(
      toBlock,
      refSlot.toString(),
      dataHash
    )

    const originTx = await getTransaction(originTxHash)

    // Bind the transaction body to the log-derived hash before trusting any
    // of its fields (to, input, signature). Without this the delegation
    // branch would rest on an unauthenticated RPC response
    verifyTransactionIntegrity(originTx, originTxHash)

    const submitReportDecoded = decodeSubmitReport(originTx)

    if (submitReportDecoded.report !== dataHash) {
      logger.error(
        'Report data hash mismatch detected between the original report and finalized event',
        {
          finalizedHash: dataHash,
          originHash: submitReportDecoded.report,
        }
      )
      throw new Error(
        'Report data hash mismatch detected between the original report and finalized event'
      )
    }

    const recoveredAddress = await recoverAddress(originTx)

    // The signature is the only anchor a lying RPC cannot forge, so the
    // signer is checked against the allowlist for both member kinds. For an
    // EDF member the allowlist holds its delegate keys; a rotation adds the
    // new delegate and keeps the old one until its reports leave the
    // lookback window.
    const allowlist = ORACLE_ADDRESSES_ALLOWLIST.map((address) =>
      address.toLowerCase()
    )
    if (!allowlist.includes(recoveredAddress.toLowerCase())) {
      logger.error('Transaction is not signed by a trusted Oracle', {
        address: recoveredAddress,
      })
      throw new Error('Transaction is not signed by a trusted Oracle')
    }
  }

  const verifySubmitExitRequestsDataTransaction = async (
    event: ExitRequestEvent,
    tx: ReturnType<typeof txDTO>['result'],
    transactionHash: string,
    input: string
  ) => {
    if (!SUBMIT_TX_HASH_ALLOWLIST.includes(transactionHash.toLowerCase())) {
      throw new Error(
        '[verifySubmitExitRequestsDataTransaction] transaction is not allowlisted'
      )
    }

    // Authenticate the calldata before using the submitted exit requests.
    verifyTransactionIntegrity(tx, transactionHash)

    const decoded = submitExitRequestsDataIface.decodeFunctionData(
      'submitExitRequestsData',
      input
    )
    const { data, dataFormat } = decoded.request as {
      data: string
      dataFormat: ethers.BigNumber
    }

    if (!containsExitRequest(data, dataFormat, event))
      throw new Error(
        '[verifySubmitExitRequestsDataTransaction] Exit request for the validator was not found in finalized tx data'
      )

    logger.info(
      '[verifySubmitExitRequestsDataTransaction] transaction found in allowlist, verification passed'
    )
  }

  return {
    verifyEvent,
  }
}
