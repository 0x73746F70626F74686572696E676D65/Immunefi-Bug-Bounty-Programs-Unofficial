import {
  makeLogger,
  makeRequest,
  logger as loggerMiddleware,
  retry,
  abort,
  prom,
} from '../../../lib/index.js'

import { makeConfig } from '../../../services/config/service.js'
import { makeConsensusApi } from '../../../services/consensus-api/service.js'
import { makeMetrics } from '../../../services/prom/service.js'
import { makeForkVersionResolver } from '../../../services/fork-version-resolver/service.js'
import {
  MessageFile,
  makeLocalFileReader,
} from '../../../services/local-file-reader/service.js'
import { makeS3Store } from '../../../services/s3-store/service.js'
import { makeGsStore } from '../../../services/gs-store/service.js'
import { makeMessagesProcessor } from '../../../services/messages-processor/service.js'
import { MessageStorage } from '../../../services/job-processor/message-storage.js'
import {
  depositContractMock,
  genesisMock,
  stateMock,
  validatorsBatchMock,
} from './fixtures.js'
import nock from 'nock'
import { defaultConfig } from '../../../test/config.js'

const mockEthCLNode = (
  res: { url: string; method: string; result: any },
  clNode: string,
  status = 200
): [string, () => boolean] => {
  const interceptor = nock(clNode).get(res.url)
  interceptor.reply(status, res.result).persist()

  return [res.url, () => nock.removeInterceptor(interceptor)]
}

const metrics = makeMetrics({ PREFIX: `PROM_TEST` })

export const prepareDeps = (
  messages: MessageFile[],
  validator: { pubKey: string; id: string },
  fork: {
    previous_version: string
    current_version: string
    epoch: string
  },
  options: { failValidatorsBatch?: boolean } = {}
) => {
  const logger = makeLogger({
    level: 'error',
    format: 'simple',
    sanitizer: {
      secrets: [],
      replacer: '<secret>',
    },
  })

  const config = makeConfig({
    logger,
    env: defaultConfig as unknown as NodeJS.ProcessEnv,
  })

  const serverMocks = [
    mockEthCLNode(depositContractMock('17000'), config.CONSENSUS_NODE[0]),
    mockEthCLNode(stateMock(fork), config.CONSENSUS_NODE[0]),
    mockEthCLNode(
      validatorsBatchMock(validator),
      config.CONSENSUS_NODE[0],
      options.failValidatorsBatch ? 500 : 200
    ),
    mockEthCLNode(genesisMock(), config.CONSENSUS_NODE[0]),
  ]

  const consensusApi = makeConsensusApi(
    makeRequest([
      retry(3),
      loggerMiddleware(logger),
      prom(metrics.consensusRequestDurationSeconds),
      abort(30_000),
    ]),
    logger,
    config
  )
  vi.spyOn(consensusApi, 'fetchValidatorsInfoBatch')

  const forkVersionResolver = makeForkVersionResolver(
    consensusApi,
    logger,
    config
  )

  const localFileReader = makeLocalFileReader({ logger })

  vi.spyOn(localFileReader, 'readFilesFromFolder').mockImplementation(
    async () => messages
  )

  const s3Service = makeS3Store({ logger })
  const gsService = makeGsStore({ logger })

  const messagesProcessor = makeMessagesProcessor({
    logger,
    config,
    localFileReader,
    consensusApi,
    metrics,
    s3Service,
    gsService,
  })

  const infoLogger = makeLogger({
    level: 'info',
    format: 'simple',
    sanitizer: {
      secrets: [],
      replacer: '<secret>',
    },
  })

  const messageStorage = new MessageStorage()

  const restore = (url?: string) => {
    serverMocks.map(([fnUrl, fn]) => {
      if (!url) return fn()
      if (fnUrl === url) return fn()
    })
  }

  const changeForkState = (fork: {
    previous_version: string
    current_version: string
    epoch: string
  }) => {
    restore('/eth/v1/beacon/states/finalized/fork')
    mockEthCLNode(stateMock(fork), config.CONSENSUS_NODE[0])
  }

  return {
    messagesProcessor,
    consensusApi,
    errorLogger: logger,
    logger: infoLogger,
    forkVersionResolver,
    messageStorage,
    restore,
    changeForkState,
  }
}
