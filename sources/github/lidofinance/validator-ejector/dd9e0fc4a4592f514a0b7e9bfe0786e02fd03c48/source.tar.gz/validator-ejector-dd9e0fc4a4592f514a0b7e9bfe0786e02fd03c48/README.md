<img src="https://user-images.githubusercontent.com/4752441/209329469-aee5d699-af5e-467b-9213-4d09b1a22012.png" width="50%" height="50%">

# Lido Validator Ejector

Daemon service which loads LidoOracle events for validator exits and sends out exit messages when necessary.

On start, it will load events from a configurable amount of blocks behind and then poll for new events.

## Requirements

- Folder of pre-signed exit messages as individual JSON files in either [spec format](https://github.com/lidofinance/validator-ejector/blob/d2e4db190935239e019618b948a1bd1cea20f88f/src/services/messages-processor/service.ts#L19-L25) (generic) or [ethdo output format](https://github.com/wealdtech/ethdo/blob/master/docs/usage.md#exit)
- Execution node
- Consensus node

This service has to be run in a single instance as it expects to fulfil every request to exit. Each unfulfilled request (no exit message being present for required validator) will log an error.

## Configuration

### Operation Modes

For both modes, Ejector will monitor exit request events, but react to them differently.

#### Messages Mode

In this mode, Ejector will load pre-signed exit messages from .json files on start, validate them, and submit them to a CL node when necessary.

Mode is activated by setting the MESSAGES_LOCATION variable.

#### Webhook Mode

In this mode, Ejector will make a request to a specified endpoint when an exit needs to be made instead of submitting a pre-signed exit message to a CL node.

Mode is activated by setting the VALIDATOR_EXIT_WEBHOOK variable.

Requests can optionally be authenticated with a bearer token by setting either the WEBHOOK_TOKEN variable or the WEBHOOK_TOKEN_FILE variable pointing to a file with the token inside. The token is sent in the `Authorization: Bearer <token>` header. Set WEBHOOK_HEADER to send the token in a custom header instead (e.g. `X-Api-Key: <token>`), in which case the raw token is sent without the `Bearer` prefix.

This allows NOs to implement JIT approach by offloading exiting logic to an external service and using the Ejector as a secure exit events reader.

On the endpoint, JSON will be POSTed with the following structure:

```json
{
  "validatorIndex": "123",
  "validatorPubkey": "0x123"
}
```

200 response from the endpoint will be counted as a successful exit, non-200 as a fail.

### Environment Variables

Options are configured via environment variables.

| Variable                                      | Required | Default/Example       | Description                                                                                                                                                                                                                                                                     |
|-----------------------------------------------|----------|-----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| EXECUTION_NODE                                | Yes      | http://1.2.3.4:8545   | Ethereum Execution Node endpoint. Accepts a single URL or a comma-separated list (e.g. `http://primary:8545,http://backup:8545`). Each request tries the endpoints in order; on a 5xx, 408, 429, network or timeout error the daemon moves to the next URL. Other 4xx and validation errors are terminal (not retried across endpoints). Voluntary-exit submissions are an exception: they broadcast to every CL URL in parallel. **Cross-endpoint consistency.** At startup the daemon issues `eth_chainId` to every EL URL and `/eth/v1/config/deposit_contract` to every CL URL, and refuses to boot if the chain ids disagree. Misconfigured mixed-network URLs (e.g. mainnet + testnet pasted together) are caught at boot, not in production.        |
| CONSENSUS_NODE                                | Yes      | http://1.2.3.4:5051   | Ethereum Consensus Node endpoint. Same multi-URL semantics as `EXECUTION_NODE`.                                                                                                                                                                                                                                                          |
| JWT_SECRET_PATH                               | No       | /data/neth/jwt.hex    | Path to JWT secret hex file for Nethermind RPC authentication. If provided, will generate a new JWT token for each execution node request. The same secret is sent to every URL configured in `EXECUTION_NODE`.                                                                                                                          |
| LOCATOR_ADDRESS                               | Yes      | 0x123                 | Address of the Locator contract [Hoodi](https://docs.lido.fi/deployed-contracts/hoodi/) / [Mainnet](https://docs.lido.fi/deployed-contracts/)                                                                                                                                   |
| EJECTOR_SCOPE                                 | Yes*     | {"1":[123]}           | Preferred module-to-operators mapping: object keys are `stakingModuleId`, array values are `operatorIds`. Example: `{"1":[123]}` means staking module `1`, operator `123`; `{"1":[123],"4":[0,1]}` adds staking module `4` operators `0` and `1`. Replaces deprecated `STAKING_MODULE_ID`, `OPERATOR_ID`, and `OPERATOR_IDENTIFIERS`. |
| STAKING_MODULE_ID                             | No       | 123                   | Deprecated legacy single-module config. Use `EJECTOR_SCOPE` instead.                                                                                                                                                                                                            |
| OPERATOR_ID                                   | No       | 123                   | Deprecated legacy single-operator config. Use `EJECTOR_SCOPE` instead.                                                                                                                                                                                                          |
| OPERATOR_IDENTIFIERS                          | No       | [0,1,2]               | Deprecated legacy multi-operator config for one `STAKING_MODULE_ID`. Use `EJECTOR_SCOPE` instead.                                                                                                                                                                               |
| MESSAGES_LOCATION                             | No       | messages              | Local folder or external storage bucket url to load json exit message files from. Required if you are using exit messages mode                                                                                                                                                  |
| VALIDATOR_EXIT_WEBHOOK                        | No       | http://webhook        | POST validator info to an endpoint instead of sending out an exit message in order to initiate an exit. Required if you are using webhook mode                                                                                                                                  |
| ORACLE_ADDRESSES_ALLOWLIST                    | Yes      | ["0x123"]             | Allowed Oracle addresses to accept transactions. List can be obtained from HashConsensus contract on [Hoodi](https://hoodi.etherscan.io/address/0x32EC59a78abaca3f91527aeB2008925D5AaC1eFC)/[Mainnet](https://etherscan.io/address/0xD624B08C83bAECF0807Dd2c6880C3154a5F0B288)  |
| SUBMIT_TX_HASH_ALLOWLIST                      | No       | ["0x123"]             | Exact hashes of final non-Oracle transactions that call `submitExitRequestsData`. The Ejector reconstructs the signed transaction hash and accepts only validator pubkeys present in its authenticated calldata. Leave empty to reject this path. |
| MESSAGES_PASSWORD                             | No       | password              | Password to decrypt encrypted exit messages with. Needed only if you encrypt your exit messages                                                                                                                                                                                 |
| MESSAGES_PASSWORD_FILE                        | No       | password_inside.txt   | Path to a file with password inside to decrypt exit messages with. Needed only if you have encrypted exit messages. If used, MESSAGES_PASSWORD (not MESSAGES_PASSWORD_FILE) needs to be added to LOGGER_SECRETS in order to be sanitized                                        |
| BLOCKS_PRELOAD                                | No       | 50000                 | Amount of blocks to load events from on start. Increase if daemon was not running for some time. Defaults to a week of blocks                                                                                                                                                   |
| LOAD_LOGS_STEP                                | No       | 10000                 | Maximum block range per eth_getLogs request. Wider ranges are split into multiple requests. Lower this value if your node or RPC provider limits event query ranges                                                                                                             |
| VALIDATORS_BATCH_SIZE                         | No       | 1000                  | Validator IDs per Consensus API validators request batch.                                                                                                                                                                                                                       |
| JOB_INTERVAL                                  | No       | 384000                | Time interval in milliseconds to run checks. Defaults to time of 1 epoch                                                                                                                                                                                                        |
| HTTP_PORT                                     | No       | 8989                  | Port to serve metrics and health check on                                                                                                                                                                                                                                       |
| RUN_METRICS                                   | No       | false                 | Enable metrics endpoint                                                                                                                                                                                                                                                         |
| RUN_HEALTH_CHECK                              | No       | true                  | Enable health check endpoint                                                                                                                                                                                                                                                    |
| LOGGER_LEVEL                                  | No       | info                  | Severity level from which to start showing errors eg info will hide debug messages                                                                                                                                                                                              |
| LOGGER_FORMAT                                 | No       | simple                | Simple or JSON log output: simple/json                                                                                                                                                                                                                                          |
| LOGGER_SECRETS                                | No       | ["MESSAGES_PASSWORD"] | JSON array of env var names or literal values to redact from logs. `EXECUTION_NODE` and `CONSENSUS_NODE` also redact each URL from a comma-separated RPC list. |
| DRY_RUN                                       | No       | false                 | Run the service without actually sending out exit messages                                                                                                                                                                                                                      |
| TRUST_MODE                                    | No       | false                 | Skip security checks for exit requests. Please, use it only if you running your own RPC nodes.                                                                                                                                                                                  |
| DISABLE_SECURITY_DONT_USE_IN_PRODUCTION       | No       | false                 | Deprecated: Use TRUST_MODE instead. Skip security checks for exit requests                                                                                                                                                                                                      |
| FORCE_DENCUN_FORK_MODE                        | No       | false                 | Start the service in Dencun fork mode                                                                                                                                                                                                                                           |
| WEBHOOK_ABORT_TIMEOUT_MS                      | No       | 10_000                | Timeout for webhook response                                                                                                                                                                                                                                                    |
| WEBHOOK_MAX_RETRIES                           | No       | 0                     | Maximum retries for webhook                                                                                                                                                                                                                                                     |
| WEBHOOK_TOKEN                                 | No       | token                 | Bearer token sent in the Authorization header of webhook requests. Add it to LOGGER_SECRETS in order to be sanitized                                                                                                                                                            |
| WEBHOOK_TOKEN_FILE                            | No       | token_inside.txt      | Path to a file with the webhook bearer token inside. Ignored if WEBHOOK_TOKEN is set. If used, WEBHOOK_TOKEN (not WEBHOOK_TOKEN_FILE) needs to be added to LOGGER_SECRETS in order to be sanitized                                                                              |
| WEBHOOK_HEADER                                | No       | Authorization         | Header the webhook token is sent in. With the default Authorization header the token is sent as `Bearer <token>`, with a custom header (e.g. X-Api-Key) the raw token is sent                                                                                                   |
| CAPELLA_FORK_VERSION                          | No       | 0x03000000            | Optional parameter to specify Capella fork version                                                                                                                                                                                                                              |

Messages can also be loaded from remote storages: AWS S3 and Google Cloud Storage.

Simply set a url with an appropriate protocol in `MESSAGES_LOCATION`:

- `s3://` for S3
- `gs://` for GCS

Authentication setup: [GCS](https://cloud.google.com/docs/authentication/application-default-credentials#attached-sa), [S3](https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/setting-credentials-node.html).

## Preparing Exit Messages

Once you generate and sign exit messages, you can encrypt them for storage safety.

Exit messages are encrypted and decrypted following the [EIP-2335](https://github.com/ethereum/EIPs/blob/master/EIPS/eip-2335.md) spec.

You can check a simple example in JS in `encryptor` folder:

Simply copy JSON exit message files to `encryptor/input`, set encryption password as `MESSAGES_PASSWORD` in `.env` and run:

```bash
yarn encrypt
```

Done, your encrypted files will be in `encryptor/output`.

## Running

Either:

- Use a Docker image from [Docker Hub](https://hub.docker.com/r/lidofinance/validator-ejector)
- Clone repo, install dependencies, build and start the service:

```bash
git clone https://github.com/lidofinance/validator-ejector.git
cd validator-ejector
yarn
yarn build
yarn start
```

Don't forget env variables in the last command.

### Running e2e tests

The EDF mainnet-fork tests use Hardhat. Hardhat is not an application
dependency and is not installed by the regular Yarn install. Use Node.js 18 or
newer and install the pinned test dependency without changing the application
manifest:

```bash
npm install --no-save --package-lock=false hardhat@2.26.3
yarn test:e2e
```

## Metrics

Enable metrics endpoint by setting `HTTP_PORT=1234` and `RUN_METRICS=true` environment variables.

Metrics will be available on `$HOST:$HTTP_PORT/metrics`.

Available metrics:

- exit_messages: ['valid'] - Exit messages and their validity: JSON parseability, structure and signature
- exit_actions: ['result'] - Statuses of initiated validator exits
- event_security_verification: ['result'] - Statuses of exit event security verifications
- polling_last_blocks_duration_seconds: ['eventsNumber'] - Duration of polling last blocks in microseconds
- execution_request_duration_seconds: ['result', 'status', 'domain'] - Execution node request duration in microseconds
- consensus_request_duration_seconds: ['result', 'status', 'domain'] - Consensus node request duration in microseconds
- job_duration_seconds: ['name', 'interval', 'result'] - Duration of Ejector cycle cron job
- job_message_reloader_duration_seconds: ['name', 'interval', 'result'] - Duration of Pre-signed message reloader cron job
- exit_messages_left_number - Number of exit messages left
- exit_messages_left_percent - Percentage of exit messages left

## Safety Features

- Encrypted messages allow for secure file storage
- Invalid files in messages folder are noticed
- Exit JSON structure is checked
- Exit signature is fully validated
- Exit event pubkeys are checked to exist in transaction data
- Exit event report data hashes are checked to match hashes in original submitReport() Oracle transactions
- Exit events original consensus transactions are checked to be signed by allowlisted Oracles
- Node requests are repeated on error or timeouts
- Amount of messages left to send out can be checked using metrics
- Dry run mode to test setup

## Troubleshooting

When you try to use Lido Validator Ejector on ARM, you may encounter an unexpected
problem related to the inability to install @chainsafe/blst dependencies under darwin arm64.

### Why does it happen?!

It happens because https://www.npmjs.com/package/@chainsafe/blst doesn't provide native C binding to https://github.com/supranational/blst under darwin arm64.
Such as there no native binding, a user has to compile C binding to blst lab manually for darwin arm64.
@chainsafe/blst has compile option but inside itself for downloading dependencies this lib uses Python language.
Historically MacOs uses alias python3 for python. So then @chainsafe/blst fails with an error that it could not install all dependencies.
To fix it on MacOs just create alias python for python3.

```bash
ln -s /opt/homebrew/bin/python3 /usr/local/bin/python
```

More info here - https://github.com/ChainSafe/lodestar/issues/4767#issuecomment-1640631566
