import { Inject, Injectable, LoggerService, Optional } from '@nestjs/common';
import { EntityManager } from '@mikro-orm/knex';
import { LOGGER_PROVIDER } from '@lido-nestjs/logger';

import { RegistryMetaFetchService } from '../fetch/meta.fetch';
import { RegistryOperatorFetchService } from '../fetch/operator.fetch';

import { RegistryKeyStorageService } from '../../registry/storage/key.storage';
import { RegistryOperatorStorageService } from '../../registry/storage/operator.storage';

import { RegistryKey } from '../../registry/storage/key.entity';
import { RegistryOperator } from '../../registry/storage/operator.entity';

import { compareOperators } from '../utils/operator.utils';

import { REGISTRY_GLOBAL_OPTIONS_TOKEN } from './constants';
import { RegistryOptions } from './interfaces/module.interface';
import { chunk } from '@lido-nestjs/utils';
import { RegistryKeyBatchFetchService } from '../fetch/key-batch.fetch';
import { IsolationLevel } from '@mikro-orm/core';
import { PrometheusService } from 'common/prometheus';

@Injectable()
export abstract class AbstractRegistryService {
  constructor(
    @Inject(LOGGER_PROVIDER) protected logger: LoggerService,

    protected readonly metaFetch: RegistryMetaFetchService,

    protected readonly keyBatchFetch: RegistryKeyBatchFetchService,
    protected readonly keyStorage: RegistryKeyStorageService,

    protected readonly operatorFetch: RegistryOperatorFetchService,
    protected readonly operatorStorage: RegistryOperatorStorageService,

    protected readonly entityManager: EntityManager,

    protected readonly prometheusService: PrometheusService,

    @Optional()
    @Inject(REGISTRY_GLOBAL_OPTIONS_TOKEN)
    public options?: RegistryOptions,
  ) {}

  /** collects changed data from the contract and store it to the db */
  public async update(moduleAddress: string, blockHash: string) {
    const previousOperators = await this.getOperatorsFromStorage(moduleAddress);
    const currentOperators = await this.getOperatorsFromContract(moduleAddress, blockHash);

    this.logger.log('Collected operators', {
      previousOperators: previousOperators.length,
      currentOperators: currentOperators.length,
      stakingModuleAddress: moduleAddress,
    });

    await this.entityManager.transactional(
      async () => {
        await this.saveOperators(moduleAddress, currentOperators);

        this.logger.log('Saved data operators to the DB', {
          operators: currentOperators.length,
          stakingModuleAddress: moduleAddress,
        });

        await this.syncUpdatedKeysWithContract(moduleAddress, previousOperators, currentOperators, blockHash);
      },
      { isolationLevel: IsolationLevel.READ_COMMITTED },
    );
  }

  /**
   *
   * @param moduleAddress contract address
   * @returns Check if operators have been changed
   */
  public async operatorsWereChanged(
    moduleAddress: string,
    fromBlockNumber: number,
    toBlockNumber: number,
  ): Promise<boolean> {
    return await this.operatorFetch.operatorsWereChanged(moduleAddress, fromBlockNumber, toBlockNumber);
  }

  /** returns operators from the contract */
  public async getOperatorsFromContract(moduleAddress: string, blockHash: string) {
    const overrides = { blockTag: { blockHash } };
    return await this.operatorFetch.fetch(moduleAddress, 0, -1, overrides);
  }

  public async updateOperators(moduleAddress, blockHash): Promise<void> {
    const currentOperators = await this.getOperatorsFromContract(moduleAddress, blockHash);
    await this.saveOperators(moduleAddress, currentOperators);
  }

  /** returns the right border of the update keys range */
  abstract getToIndex(currOperator: RegistryOperator): number;

  /** sync keys with contract */
  public async syncUpdatedKeysWithContract(
    moduleAddress: string,
    previousOperators: RegistryOperator[],
    currentOperators: RegistryOperator[],
    blockHash: string,
  ) {
    /**
     * it's possible to update keys faster by using different strategies depending on the reason for the update
     */
    const updateTimeStart = performance.now();
    let totalKeysAmount = 0;

    for (const [currentIndex, currOperator] of currentOperators.entries()) {
      // check if the operator in the registry has changed since the last update
      const prevOperator = previousOperators[currentIndex] ?? null;
      const isSameOperator = compareOperators(prevOperator, currOperator);

      const finalizedUsedSigningKeys = prevOperator ? prevOperator.finalizedUsedSigningKeys : null;
      // skip updating keys from 0 to `usedSigningKeys` of previous collected data
      // since the contract guarantees that these keys cannot be changed
      const unchangedKeysMaxIndex = isSameOperator && finalizedUsedSigningKeys ? finalizedUsedSigningKeys : 0;

      // get the right border up to which the keys should be updated
      // it's different for different scenarios
      const toIndex = this.getToIndex(currOperator);

      // fromIndex may become larger than toIndex if used keys are deleted
      // this should not happen in mainnet, but sometimes keys can be deleted in testnet by modification of the contract
      const fromIndex = unchangedKeysMaxIndex <= toIndex ? unchangedKeysMaxIndex : 0;

      const operatorIndex = currOperator.index;
      const overrides = { blockTag: { blockHash } };
      const stakingLimit = currOperator.stakingLimit;

      const result = await this.keyBatchFetch.fetch(
        moduleAddress,
        operatorIndex,
        stakingLimit,
        fromIndex,
        toIndex,
        currOperator.usedSigningKeys,
        overrides,
      );

      const operatorKeys = result.filter((key) => key);

      const operatorKeysCount = operatorKeys.length;
      totalKeysAmount += operatorKeysCount;

      const logMeta = {
        operatorIndex,
        fromIndex,
        toIndex,
        operatorKeys: operatorKeysCount,
        fetchedKeys: result.length,
        stakingModuleAddress: moduleAddress,
      };

      if (operatorKeysCount > 0) {
        this.logger.log('Keys fetched', logMeta);
        await this.saveKeys(operatorKeys);
        this.logger.log('Keys saved', { operatorIndex, stakingModuleAddress: moduleAddress });
      }

      if (operatorKeysCount === 0) {
        this.logger.log('No keys fetched', logMeta);
      }
    }

    const updateTimeEnd = performance.now();
    const updateTime = Math.ceil(updateTimeEnd - updateTimeStart) / 1000;

    this.prometheusService.updateDurationByModule.labels(moduleAddress, totalKeysAmount.toString()).observe(updateTime);

    const usedKeysInDb = await this.keyStorage.countUsedKeys(moduleAddress);
    const depositedPerOperators = currentOperators.reduce((sum, op) => sum + op.usedSigningKeys, 0);
    this.logger.log('Update statistic', {
      stakingModuleAddress: moduleAddress,
      time: updateTime,
      totalKeysAmount,
      usedKeysInDb,
      depositedPerOperators,
      blockHash,
    });
  }

  /** storage */

  /** returns the latest operators data from the db */
  public async getOperatorsFromStorage(moduleAddress: string) {
    return await this.operatorStorage.findAll(moduleAddress);
  }

  /** returns all the keys from storage */
  public async getOperatorsKeysFromStorage(moduleAddress: string) {
    return await this.keyStorage.findAll(moduleAddress);
  }

  public async saveKeys(keys: RegistryKey[]) {
    await this.entityManager.transactional(async (entityManager) => {
      await Promise.all(
        // 500 — SQLite limit in insert operation
        chunk(keys, 499).map(async (keysChunk) => {
          await entityManager
            .createQueryBuilder(RegistryKey)
            .insert(keysChunk)
            .onConflict(['index', 'operator_index', 'module_address'])
            .merge()
            .execute();
        }),
      );
    });
  }

  /** contract */
  /** returns the meta data from the contract */
  public async getStakingModuleNonce(moduleAddress: string, blockHash: string): Promise<number> {
    const keysOpIndex = await this.metaFetch.fetchStakingModuleNonce(moduleAddress, { blockTag: { blockHash } });
    return keysOpIndex;
  }

  /** saves all data to the db for staking module*/
  public async saveOperators(moduleAddress: string, currentOperators: RegistryOperator[]) {
    // save all data in a transaction
    await this.entityManager.transactional(async (entityManager) => {
      await Promise.all(
        // remove all keys from the database that are greater than the total number of keys
        // it's needed to clear the list in db when removing keys from the contract

        currentOperators.map(async (operator) => {
          await entityManager.nativeDelete(RegistryKey, {
            index: { $gte: operator.totalSigningKeys },
            operatorIndex: operator.index,
            moduleAddress,
          });
        }),
      );

      await Promise.all(
        // 500 — SQLite limit in insert operation
        chunk(currentOperators, 499).map(async (operatorsChunk) => {
          await entityManager
            .createQueryBuilder(RegistryOperator)
            .insert(operatorsChunk)
            .onConflict(['index', 'module_address'])
            .merge()
            .execute();
        }),
      );
    });
  }
}
