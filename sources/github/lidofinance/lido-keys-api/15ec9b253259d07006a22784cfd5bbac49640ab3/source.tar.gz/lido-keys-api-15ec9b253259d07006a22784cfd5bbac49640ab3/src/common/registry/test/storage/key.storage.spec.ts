import { Test } from '@nestjs/testing';
import { key } from '../fixtures/key.fixture';
import { RegistryKeyStorageService, RegistryKey, RegistryKeyRepository } from '../../';
import * as streamUtils from '../../utils/stream.utils';
import { STREAM_KEYS_TIMEOUT_MESSAGE, DEFAULT_STREAM_TIMEOUT } from '../../../registry/storage/constants';
import { ConfigModule, ConfigService } from 'common/config';

describe('Keys', () => {
  const address = '0x55032650b14df07b85bF18A3a3eC8E0Af2e028d5';
  const registryKey = { index: 1, operatorIndex: 1, moduleAddress: address, ...key, vetted: true };

  async function* findKeysAsStream() {
    yield registryKey;
  }

  const streamValue = jest.fn().mockReturnValue(findKeysAsStream());

  const mockedCreateQueryBuilder = {
    select: jest.fn().mockReturnThis(),
    where: jest.fn().mockReturnThis(),
    orderBy: jest.fn().mockReturnThis(),
    getKnexQuery: jest.fn().mockReturnValue({
      stream: streamValue,
    }),
  };

  const addTimeoutToStream = jest.spyOn(streamUtils, 'addTimeoutToStream').mockReturnValue();

  const mockRegistryKeyRepository = {
    findAll: jest.fn().mockImplementation(() => {
      return Promise.resolve([]);
    }),
    find: jest.fn().mockImplementation(() => {
      return Promise.resolve([]);
    }),
    count: jest.fn().mockImplementation(() => {
      return Promise.resolve(0);
    }),
    findOne: jest.fn().mockImplementation(() => {
      return Promise.resolve(registryKey);
    }),
    persistAndFlush: jest.fn().mockImplementation((key: RegistryKey) => {
      return Promise.resolve({ ...key });
    }),
    persist: jest.fn().mockImplementation((key: RegistryKey) => {
      return Promise.resolve({ ...key });
    }),
    flush: jest.fn().mockImplementation(() => {
      return;
    }),
    nativeDelete: jest.fn().mockImplementation(() => {
      return 1;
    }),
    createQueryBuilder: jest.fn().mockReturnValue(mockedCreateQueryBuilder),
  };

  let storageService: RegistryKeyStorageService;
  let configService: ConfigService;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [ConfigModule],
      providers: [RegistryKeyStorageService, { provide: RegistryKeyRepository, useValue: mockRegistryKeyRepository }],
    }).compile();

    storageService = moduleRef.get(RegistryKeyStorageService);
    configService = moduleRef.get(ConfigService);

    jest.spyOn(configService, 'get').mockImplementation((path) => {
      if (path === 'STREAM_TIMEOUT') {
        return DEFAULT_STREAM_TIMEOUT;
      }

      return configService.get(path);
    });
  });

  beforeEach(() => {
    Object.values(mockRegistryKeyRepository).forEach((mockCall) => {
      mockCall.mockClear();
    });
  });

  test('find', async () => {
    await expect(storageService.find({ used: true }, { limit: 1 })).resolves.toEqual([]);
    expect(mockRegistryKeyRepository.find).toBeCalledTimes(1);
    expect(mockRegistryKeyRepository.find).toBeCalledWith({ used: true }, { limit: 1 });
  });

  test('findAsStream', async () => {
    const stream = storageService.findAsStream({ used: true });
    const actualResult: RegistryKey[] = [];
    for await (const item of stream) {
      actualResult.push(item);
    }
    expect(actualResult).toEqual([registryKey]);
    expect(mockRegistryKeyRepository.createQueryBuilder).toBeCalledTimes(1);
    expect(mockedCreateQueryBuilder.select).toBeCalledWith('*');
    expect(mockedCreateQueryBuilder.where).toBeCalledWith({ used: true });
    expect(mockedCreateQueryBuilder.orderBy).toBeCalledWith({ index: 'asc', operator_index: 'asc' });
    expect(mockedCreateQueryBuilder.getKnexQuery).toBeCalledTimes(1);
    expect(streamValue).toBeCalledTimes(1);
    expect(addTimeoutToStream).toBeCalledWith(stream, DEFAULT_STREAM_TIMEOUT, STREAM_KEYS_TIMEOUT_MESSAGE);
  });

  test('findAll', async () => {
    await expect(storageService.findAll(address)).resolves.toEqual([]);
    expect(mockRegistryKeyRepository.find).toBeCalledTimes(1);
  });

  test('findUsed', async () => {
    await expect(storageService.findUsed(address)).resolves.toEqual([]);
    expect(mockRegistryKeyRepository.find).toBeCalledTimes(1);
    expect(mockRegistryKeyRepository.find).toBeCalledWith({ moduleAddress: address, used: true });
  });

  test('findByOperatorIndex', async () => {
    await expect(storageService.findByOperatorIndex(address, 1)).resolves.toEqual([]);
    expect(mockRegistryKeyRepository.find).toBeCalledTimes(1);
  });

  test('countUsedKeys', async () => {
    mockRegistryKeyRepository.count.mockResolvedValueOnce(42);
    await expect(storageService.countUsedKeys(address)).resolves.toEqual(42);
    expect(mockRegistryKeyRepository.count).toBeCalledWith({ moduleAddress: address, used: true });
  });

  test('findOneByIndex', async () => {
    await expect(storageService.findOneByIndex(address, registryKey.operatorIndex, registryKey.index)).resolves.toEqual(
      registryKey,
    );
    expect(mockRegistryKeyRepository.findOne).toBeCalledTimes(1);
  });

  test('findOneByPubkey', async () => {
    await expect(storageService.findByPubkey(address, '')).resolves.toEqual([]);
    expect(mockRegistryKeyRepository.find).toBeCalledTimes(1);
  });

  test('findOneBySignature', async () => {
    await expect(storageService.findBySignature(address, '')).resolves.toEqual([]);
    expect(mockRegistryKeyRepository.find).toBeCalledTimes(1);
  });

  test('removeOneByIndex', async () => {
    await expect(
      storageService.removeOneByIndex(address, registryKey.operatorIndex, registryKey.index),
    ).resolves.toEqual(1);
    expect(mockRegistryKeyRepository.nativeDelete).toBeCalledTimes(1);
  });

  test('removeAll', async () => {
    await expect(storageService.removeAll()).resolves.toEqual(1);
    expect(mockRegistryKeyRepository.nativeDelete).toBeCalledTimes(1);
  });

  test('saveOne', async () => {
    await expect(storageService.saveOne(registryKey)).resolves.toEqual(registryKey);
    expect(mockRegistryKeyRepository.persistAndFlush).toBeCalledTimes(1);
  });

  test('save', async () => {
    await expect(storageService.save([registryKey])).resolves.toEqual([registryKey]);
    expect(mockRegistryKeyRepository.persist).toBeCalledTimes(1);
    expect(mockRegistryKeyRepository.flush).toBeCalledTimes(1);
  });
});
