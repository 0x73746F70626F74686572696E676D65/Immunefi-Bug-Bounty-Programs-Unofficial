export * from './prometheus.interface';
