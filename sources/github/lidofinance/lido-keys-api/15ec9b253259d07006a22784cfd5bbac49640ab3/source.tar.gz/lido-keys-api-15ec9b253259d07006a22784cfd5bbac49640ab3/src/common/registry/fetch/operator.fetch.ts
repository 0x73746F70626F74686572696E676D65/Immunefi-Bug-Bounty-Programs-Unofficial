/* eslint-disable @typescript-eslint/no-explicit-any */
import { Inject, Injectable, LoggerService } from '@nestjs/common';
import { LOGGER_PROVIDER } from '@lido-nestjs/logger';
import { rangePromise } from '@lido-nestjs/utils';
import { Registry } from 'generated';
import { REGISTRY_CONTRACT_TOKEN, ContractFactoryFn } from 'common/contracts';
import { CallOverrides } from './interfaces/overrides.interface';
import { RegistryOperator } from './interfaces/operator.interface';
import { REGISTRY_OPERATORS_BATCH_SIZE } from './operator.constants';
import { utils } from 'ethers';
@Injectable()
export class RegistryOperatorFetchService {
  constructor(
    @Inject(LOGGER_PROVIDER) protected logger: LoggerService,
    @Inject(REGISTRY_CONTRACT_TOKEN) private connectRegistry: ContractFactoryFn<Registry>,
  ) {}

  /**
   * Exits early if relevant events are found, as they are used only as indicators for an update.
   */
  private async fetchOperatorsEvents(moduleAddress: string, fromBlock: number, toBlock: number) {
    if (fromBlock > toBlock) {
      return [];
    }

    const contract = this.connectRegistry(moduleAddress);

    // https://github.com/lidofinance/core/blob/master/contracts/0.4.24/nos/NodeOperatorsRegistry.sol#L39
    // https://docs.ethers.org/v5/api/providers/provider/#Provider-getLogs
    // from docs: Keep in mind that many backends will discard old events,
    // and that requests which are too broad may get dropped as they require too many resources to execute the query.

    const events = await contract.provider.getLogs({
      address: moduleAddress,
      topics: [
        // KECCAK256 hash of the text bytes
        [
          utils.id('NodeOperatorAdded(uint256,string,address,uint64)'),
          utils.id('NodeOperatorNameSet(uint256,string)'),
          utils.id('NodeOperatorRewardAddressSet(uint256,address)'),
        ],
      ],
      fromBlock,
      toBlock,
    });

    return events;
  }

  public async operatorsWereChanged(moduleAddress: string, fromBlock: number, toBlock: number): Promise<boolean> {
    const events = await this.fetchOperatorsEvents(moduleAddress, fromBlock, toBlock);

    return events.length > 0;
  }

  /** return blockTag for finalized block, it need for testing purposes */
  public getFinalizedBlockTag() {
    return 'finalized';
  }

  /** fetches number of operators */
  public async count(moduleAddress: string, overrides: CallOverrides = {}): Promise<number> {
    const bigNumber = await this.connectRegistry(moduleAddress).getNodeOperatorsCount(overrides as any);
    return bigNumber.toNumber();
  }

  /**
   * fetches finalized operator
   * @param moduleAddress address of sr module
   * @param operatorIndex index of sr module operator
   * @returns used signing keys count, if error happened returns 0 (because of range error)
   */
  public async getFinalizedNodeOperatorUsedSigningKeys(moduleAddress: string, operatorIndex: number): Promise<number> {
    const fullInfo = true;
    const contract = this.connectRegistry(moduleAddress);
    try {
      const { totalDepositedValidators } = await contract.getNodeOperator(operatorIndex, fullInfo, {
        blockTag: this.getFinalizedBlockTag(),
      });

      return totalDepositedValidators.toNumber();
    } catch (error) {
      this.logger.warn(
        `an error occurred while trying to load the finalized state for operator ${operatorIndex} from module ${moduleAddress}`,
        error,
      );
      return 0;
    }
  }

  /** fetches one operator */
  public async fetchOne(
    moduleAddress: string,
    operatorIndex: number,
    overrides: CallOverrides = {},
  ): Promise<RegistryOperator> {
    const fullInfo = true;
    const contract = this.connectRegistry(moduleAddress);

    const [operator, summary, rawFinalizedUsedSigningKeys] = await Promise.all([
      contract.getNodeOperator(operatorIndex, fullInfo, overrides as any),
      contract.getNodeOperatorSummary(operatorIndex, overrides as any),
      this.getFinalizedNodeOperatorUsedSigningKeys(moduleAddress, operatorIndex),
    ]);

    const {
      active,
      rewardAddress,
      totalVettedValidators,
      totalExitedValidators,
      totalAddedValidators,
      totalDepositedValidators,
    } = operator;

    // In case of wrong input, replace with default value
    let name: string;
    try {
      name = operator.name;
    } catch (error) {
      this.logger.error(
        `Failed to read name for operator ${operatorIndex} of module ${moduleAddress}; using a placeholder.`,
      );
      this.logger.error(error);
      name = `invalidName${operatorIndex}`;
    }

    if (name.includes(String.fromCharCode(0))) {
      this.logger.error(
        `Operator ${operatorIndex} of module ${moduleAddress} has a NUL byte in its name; using a placeholder.`,
      );
      name = `invalidName${operatorIndex}`;
    }

    // min(finalized, deposited count at the latest block fixed at the cycle start) guarantees that
    // in the next cycle there will be no frozen keys with a wrong `used` flag.
    const finalizedUsedSigningKeys = Math.min(rawFinalizedUsedSigningKeys, totalDepositedValidators.toNumber());

    return {
      index: operatorIndex,
      active,
      name,
      rewardAddress,
      stakingLimit: totalVettedValidators.toNumber(),
      stoppedValidators: totalExitedValidators.toNumber(),
      totalSigningKeys: totalAddedValidators.toNumber(),
      usedSigningKeys: totalDepositedValidators.toNumber(),
      moduleAddress,
      finalizedUsedSigningKeys,
      depositableValidatorsCount: summary.depositableValidatorsCount.toNumber(),
      // curated (NOR) modules do not expose a withdrawn-keys counter on-chain; left undefined so the
      // column stays NULL (a distinct "not applicable" marker, never confused with a real 0)
    };
  }

  /** fetches operators */
  public async fetch(
    moduleAddress: string,
    fromIndex = 0,
    toIndex = -1,
    overrides: CallOverrides = {},
  ): Promise<RegistryOperator[]> {
    if (fromIndex > toIndex && toIndex !== -1) {
      throw new Error('fromIndex is greater than or equal to toIndex');
    }

    if (toIndex == null || toIndex === -1) {
      toIndex = await this.count(moduleAddress, overrides);
    }

    const fetcher = async (operatorIndex: number) => {
      return await this.fetchOne(moduleAddress, operatorIndex, overrides);
    };

    const batchSize = REGISTRY_OPERATORS_BATCH_SIZE;

    return await rangePromise(fetcher, fromIndex, toIndex, batchSize);
  }
}
