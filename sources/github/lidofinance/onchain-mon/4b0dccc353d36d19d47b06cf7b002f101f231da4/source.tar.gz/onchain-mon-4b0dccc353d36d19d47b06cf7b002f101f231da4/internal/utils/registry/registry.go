package registry

import "github.com/lidofinance/onchain-mon/generated/databus"

type FindingMapping = map[databus.Severity]bool
type FindingFilterMap = map[string]bool

type NotificationChannel string

const (
	Telegram NotificationChannel = `Telegram`
	Discord  NotificationChannel = `Discord`
	OpsGenie NotificationChannel = `OpsGenie`
	Slack    NotificationChannel = `Slack`
)
