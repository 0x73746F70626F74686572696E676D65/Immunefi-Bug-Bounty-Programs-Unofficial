"""Humanity assessment package."""
