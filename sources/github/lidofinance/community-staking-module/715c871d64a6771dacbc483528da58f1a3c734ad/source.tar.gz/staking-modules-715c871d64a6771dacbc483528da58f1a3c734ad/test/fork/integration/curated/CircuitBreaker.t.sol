// SPDX-FileCopyrightText: 2026 Lido <info@lido.fi>
// SPDX-License-Identifier: GPL-3.0

pragma solidity 0.8.33;

import { CuratedIntegrationBase } from "../common/ModuleTypeBase.sol";

contract CircuitBreakerTest is CuratedIntegrationBase {
    function setUp() public {
        _setUpModule();
    }

    function _pause(address pausable) internal {
        vm.prank(circuitBreaker.getPauser(pausable));
        circuitBreaker.pause(pausable);
    }

    function test_pauseAll() public {
        address[] memory pausables = new address[](5);
        pausables[0] = address(curatedModule);
        pausables[1] = address(accounting);
        pausables[2] = address(oracle);
        pausables[3] = address(verifier);
        pausables[4] = address(ejector);

        for (uint256 i = 0; i < pausables.length; i++) {
            _pause(pausables[i]);
        }

        assertTrue(curatedModule.isPaused());
        assertTrue(accounting.isPaused());
        assertTrue(oracle.isPaused());
        assertTrue(verifier.isPaused());
        assertTrue(ejector.isPaused());
    }

    function test_pauseCuratedModule() public {
        _pause(address(curatedModule));

        assertTrue(curatedModule.isPaused());
        assertFalse(accounting.isPaused());
        assertFalse(oracle.isPaused());
        assertFalse(verifier.isPaused());
        assertFalse(ejector.isPaused());
    }

    function test_pauseAccounting() public {
        _pause(address(accounting));

        assertFalse(curatedModule.isPaused());
        assertTrue(accounting.isPaused());
        assertFalse(oracle.isPaused());
        assertFalse(verifier.isPaused());
        assertFalse(ejector.isPaused());
    }

    function test_pauseOracle() public {
        _pause(address(oracle));

        assertFalse(curatedModule.isPaused());
        assertFalse(accounting.isPaused());
        assertTrue(oracle.isPaused());
        assertFalse(verifier.isPaused());
        assertFalse(ejector.isPaused());
    }

    function test_pauseVerifier() public {
        _pause(address(verifier));

        assertFalse(curatedModule.isPaused());
        assertFalse(accounting.isPaused());
        assertFalse(oracle.isPaused());
        assertTrue(verifier.isPaused());
        assertFalse(ejector.isPaused());
    }

    function test_pauseEjector() public {
        _pause(address(ejector));

        assertFalse(curatedModule.isPaused());
        assertFalse(accounting.isPaused());
        assertFalse(oracle.isPaused());
        assertFalse(verifier.isPaused());
        assertTrue(ejector.isPaused());
    }
}
