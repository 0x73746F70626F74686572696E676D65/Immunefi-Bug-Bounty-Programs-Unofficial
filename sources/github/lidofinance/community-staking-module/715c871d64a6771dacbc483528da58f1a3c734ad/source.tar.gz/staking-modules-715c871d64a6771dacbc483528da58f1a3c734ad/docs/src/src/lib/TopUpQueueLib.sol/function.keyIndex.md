# keyIndex
[Git Source](https://github.com/lidofinance/staking-modules/blob/68bbef5148bb51c1967785a7c6ed6e168acccc0f/src/lib/TopUpQueueLib.sol)


```solidity
function keyIndex(TopUpQueueItem self) pure returns (uint32 n);
```

