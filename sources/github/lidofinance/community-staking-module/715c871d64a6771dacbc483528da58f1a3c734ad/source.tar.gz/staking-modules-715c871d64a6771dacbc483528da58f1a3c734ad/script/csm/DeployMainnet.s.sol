// SPDX-FileCopyrightText: 2026 Lido <info@lido.fi>
// SPDX-License-Identifier: GPL-3.0

pragma solidity 0.8.33;

import { DeployBase } from "./DeployBase.s.sol";
import { GIndices } from "../constants/GIndices.sol";

contract DeployMainnet is DeployBase {
    constructor() DeployBase("mainnet", 1) {
        // Lido addresses
        config.lidoLocatorAddress = 0xC1d0b3DE6792Bf6b4b37EccdcC24e45978Cfd2Eb;
        config.aragonAgent = 0x3e40D73EB977Dc6a537aF587D48316feE66E9C8c;
        config.easyTrackEVMScriptExecutor = 0xFE5986E06210aC1eCC1aDCafc0cc7f8D63B3F977;
        config.proxyAdmin = config.aragonAgent;

        // Oracle
        config.secondsPerSlot = 12; // https://github.com/eth-clients/mainnet/blob/f6b7882618a5ad2c1d2731ae35e5d16a660d5bb7/metadata/config.yaml#L58
        config.slotsPerEpoch = 32; // https://github.com/ethereum/consensus-specs/blob/7df1ce30384b13d01617f8ddf930f4035da0f689/specs/phase0/beacon-chain.md?plain=1#L246
        config.clGenesisTime = 1606824023; // https://github.com/eth-clients/mainnet/blob/f6b7882618a5ad2c1d2731ae35e5d16a660d5bb7/README.md?plain=1#L10
        config.oracleReportEpochsPerFrame = 225 * 28;
        config.fastLaneLengthSlots = 300;
        config.consensusVersion = 4;
        config.oracleMembers = new address[](9);
        config.oracleMembers[0] = 0xC4f2704273598d51A0ec76A31C12553ec8f5A891; // MatrixedLink
        config.oracleMembers[1] = 0xE75A431A98487DC69A14Bdd13d858E3238e9C1b3; // Instadapp
        config.oracleMembers[2] = 0xc77d0Bf3AA4778E36a89CDC8bbc9c34d8060637d; // Caliber
        config.oracleMembers[3] = 0xc7442d4d8F3FfEa0fA4a18Ad3062c8137cE21749; // Staking Facilities
        config.oracleMembers[4] = 0x56B3eA8016Da18C6E8CD8135492d242F0dE0DBBC; // Chorus One (Bitwise)
        config.oracleMembers[5] = 0x4E3F2DEeb59eB9a205D82D17647b3e56422e0FEe; // P2P
        config.oracleMembers[6] = 0xd524101C3c40f71Fce7B9312D299603880a06Bdb; // Chainlayer
        config.oracleMembers[7] = 0x99Cd2EF33040879D40BBC77Df81863D97f13C64d; // bloXroute
        config.oracleMembers[8] = 0x5e8Ed9f10307eD6FA793A347e4D0f407D00B9C6f; // Stakefish

        config.hashConsensusQuorum = 5;

        // Verifier
        config.gIFirstWithdrawal = GIndices.FIRST_WITHDRAWAL_ELECTRA;
        config.gIFirstValidator = GIndices.FIRST_VALIDATOR_ELECTRA;
        config.gIFirstHistoricalSummary = GIndices.FIRST_HISTORICAL_SUMMARY_ELECTRA; // prettier-ignore
        config.gIFirstBalanceNode = GIndices.FIRST_BALANCE_NODE_ELECTRA;
        config.verifierFirstSupportedSlot = 364032 * config.slotsPerEpoch; // https://github.com/ethereum/EIPs/blob/master/EIPS/eip-7600.md#activation
        config.capellaSlot = 194048 * config.slotsPerEpoch; // @see https://github.com/eth-clients/mainnet/blob/main/metadata/config.yaml#L50
        config.minWithdrawalRatio = 9900;

        // Accounting
        // 2.4 -> 1.3
        config.defaultBondCurve.push([1, 2.4 ether]);
        config.defaultBondCurve.push([2, 1.3 ether]);
        // 1.5 -> 1.3
        config.legacyEaBondCurve.push([1, 1.5 ether]);
        config.legacyEaBondCurve.push([2, 1.3 ether]);

        config.minBondLockPeriod = 4 weeks;
        config.maxBondLockPeriod = 365 days;
        config.bondLockPeriod = 8 weeks;
        config.setResetBondCurveAddress = 0xC52fC3081123073078698F1EAc2f1Dc7Bd71880f; // CSM Committee MS
        config.chargePenaltyRecipient = 0x3e40D73EB977Dc6a537aF587D48316feE66E9C8c; // locator.treasury()

        // Module
        config.moduleType = "community-onchain-v1"; // Just a unique type name to be used by the off-chain tooling
        config.generalDelayedPenaltyReporter = 0xC52fC3081123073078698F1EAc2f1Dc7Bd71880f; // CSM Committee MS

        // ParametersRegistry
        config.defaultKeyRemovalCharge = 0.02 ether;
        config.defaultGeneralDelayedPenaltyAdditionalFine = 0.1 ether;
        config.defaultKeysLimit = type(uint256).max;
        config.defaultAvgPerfLeewayBP = 300;
        config.defaultRewardShareBP = 5834; // 58.34% of 6% = 3.5% of the total
        config.defaultStrikesLifetimeFrames = 6;
        config.defaultStrikesThreshold = 3;
        config.queueLowestPriority = 5;
        config.defaultQueuePriority = 5;
        config.defaultQueueMaxDeposits = type(uint32).max;
        config.defaultBadPerformancePenalty = 0.258 ether;
        config.defaultAttestationsWeight = 54; // https://eth2book.info/capella/part2/incentives/rewards/
        config.defaultBlocksWeight = 8; // https://eth2book.info/capella/part2/incentives/rewards/
        config.defaultSyncWeight = 2; // https://eth2book.info/capella/part2/incentives/rewards/
        config.defaultAllowedExitDelay = 4 days;
        config.defaultExitDelayFee = 0.1 ether;
        config.defaultMaxElWithdrawalRequestFee = 0.1 ether;
        config.penaltiesManager = 0xC52fC3081123073078698F1EAc2f1Dc7Bd71880f; // CSM Committee MS

        // VettedGate
        config.identifiedCommunityStakersGateManager = 0xC52fC3081123073078698F1EAc2f1Dc7Bd71880f; // CSM Committee MS
        config.identifiedCommunityStakersGateCurveId = 2;
        config.identifiedCommunityStakersGateName = "Identified Community Stakers Gate";
        config
            .identifiedCommunityStakersGateTreeRoot = 0x8c92643a5320749acb56f82705e45e3cd680e1760c172e28a4945118f3769b69;
        config.identifiedCommunityStakersGateTreeCid = "bafkreihg2mqulwsmhiho6bcd4mf4ao2kigzaq3uh5dlna34cjiyllawvja";
        config.identifiedDVTClusterGateName = "Identified DVT Clusters Gate";
        config.identifiedDVTClusterGateTreeRoot = 0xb61a11aaa84f3956f54784f7e8548ff165cab8a4866f3950ea7edbc9cd19464e;
        config.identifiedDVTClusterGateTreeCid = "bafkreiakdug6tbysfvwm5hoizdvmex4wxh3kfkjq6pfxxjp5cv4mrokdiq";
        // 1.5 -> 1.3
        config.identifiedCommunityStakersGateBondCurve.push([1, 1.5 ether]);
        config.identifiedCommunityStakersGateBondCurve.push([2, 1.3 ether]);

        // Parameters for Identified Community Staker type
        config.identifiedCommunityStakersGateKeyRemovalCharge = 0.01 ether;
        config.identifiedCommunityStakersGateGeneralDelayedPenaltyAdditionalFine = 0.05 ether;
        config.identifiedCommunityStakersGateKeysLimit = type(uint248).max;
        config.identifiedCommunityStakersGateAvgPerfLeewayData.push([1, 500]);
        config.identifiedCommunityStakersGateAvgPerfLeewayData.push([151, 300]);
        config.identifiedCommunityStakersGateRewardShareData.push([1, 10000]);
        config.identifiedCommunityStakersGateRewardShareData.push([17, 5834]);
        config.identifiedCommunityStakersGateStrikesLifetimeFrames = 6;
        config.identifiedCommunityStakersGateStrikesThreshold = 4;
        config.identifiedCommunityStakersGateQueuePriority = 0;
        config.identifiedCommunityStakersGateQueueMaxDeposits = 10;
        config.identifiedCommunityStakersGateBadPerformancePenalty = 0.172 ether;
        config.identifiedCommunityStakersGateAttestationsWeight = 54;
        config.identifiedCommunityStakersGateBlocksWeight = 4;
        config.identifiedCommunityStakersGateSyncWeight = 2;
        config.identifiedCommunityStakersGateAllowedExitDelay = 5 days;
        config.identifiedCommunityStakersGateExitDelayFee = 0.05 ether;
        config.identifiedCommunityStakersGateMaxElWithdrawalRequestFee = 0.1 ether;

        // Parameters for Identified DVT Cluster type
        config.identifiedDVTClusterBondCurve.push([1, 1.5 ether]);
        config.identifiedDVTClusterBondCurve.push([2, 0.5 ether]);
        config.identifiedDVTClusterRewardShareData.push([1, 5834]); // 58.34% of 6% = 3.5% of the total
        config.identifiedDVTClusterRewardShareData.push([65, 3334]); // 33.34% of 6% = 2% of the total
        config.identifiedDVTClusterQueuePriority = 1;
        config.identifiedDVTClusterQueueMaxDeposits = 40;
        config.identifiedDVTClusterKeyRemovalCharge = 0.01 ether;
        config.identifiedDVTClusterGeneralDelayedPenaltyAdditionalFine = 0.05 ether;
        config.identifiedDVTClusterAllowedExitDelay = 5 days;
        config.identifiedDVTClusterExitDelayFee = 0.05 ether;

        // CircuitBreaker
        config.circuitBreaker = 0x6019CB557978296BA3C08a7B73225C0975DFB2F7; // Proposed by LIP-34
        config.circuitBreakerPauser = 0xC52fC3081123073078698F1EAc2f1Dc7Bd71880f; // CSM Committee MS

        // DG
        config.resealManager = 0x7914b5a1539b97Bd0bbd155757F25FD79A522d24;
        _setUp();
    }
}
