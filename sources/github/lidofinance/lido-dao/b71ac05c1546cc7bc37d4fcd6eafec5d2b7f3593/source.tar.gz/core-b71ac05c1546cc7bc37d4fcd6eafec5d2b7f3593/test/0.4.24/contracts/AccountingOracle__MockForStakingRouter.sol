// SPDX-License-Identifier: UNLICENSED
// for testing purposes only

pragma solidity 0.8.9;

contract AccountingOracle__MockForStakingRouter {
    uint256 currentFrameRefSlot;
    uint256 lastProcessingRefSlot;
    bool mainDataSubmitted;
    bool extraDataSubmitted;

    uint256 public constant SECONDS_PER_SLOT = 4;
    uint256 public constant GENESIS_TIME = 100;

    constructor() {
        currentFrameRefSlot = 0;
        mainDataSubmitted = false;
        extraDataSubmitted = false;
    }

    struct ProcessingState {
        uint256 currentFrameRefSlot;
        uint256 processingDeadlineTime;
        bytes32 mainDataHash;
        bool mainDataSubmitted;
        bytes32 extraDataHash;
        uint256 extraDataFormat;
        bool extraDataSubmitted;
        uint256 extraDataItemsCount;
        uint256 extraDataItemsSubmitted;
    }

    function getProcessingState() external view returns (ProcessingState memory result) {
        result.currentFrameRefSlot = currentFrameRefSlot;
        result.mainDataSubmitted = mainDataSubmitted;
        result.extraDataSubmitted = extraDataSubmitted;
    }

    function getLastProcessingRefSlot() external view returns (uint256) {
        return lastProcessingRefSlot;
    }

    function getCurrentFrame() external view returns (uint256 refSlot, uint256 refSlotTimestamp) {
        refSlot = currentFrameRefSlot;
        refSlotTimestamp = GENESIS_TIME + refSlot * SECONDS_PER_SLOT;
    }

    function mock_setProcessingState(uint256 _refSlot, bool _mainDataSubmitted, bool _extraDataSubmitted) external {
        currentFrameRefSlot = _refSlot;
        lastProcessingRefSlot = _refSlot;
        mainDataSubmitted = _mainDataSubmitted;
        extraDataSubmitted = _extraDataSubmitted;
    }
}
