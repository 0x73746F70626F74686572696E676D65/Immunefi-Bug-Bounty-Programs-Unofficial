// SPDX-License-Identifier: UNLICENSED
// for testing purposes only

pragma solidity 0.8.9;

contract StakingRouter__MockForLidoMisc {
    event Mock__DepositCalled();

    uint256 public constant INITIAL_DEPOSIT_SIZE = 32 ether;

    uint256 private stakingModuleMaxDepositsCount;
    uint256 private stakingModuleMaxInitialDepositsAmount;

    function getWithdrawalCredentials() external pure returns (bytes32) {
        return 0x010000000000000000000000b9d7934878b5fb9610b3fe8a5e441e8fad7e293f; // Lido Withdrawal Creds
    }

    function getTotalFeeE4Precision() external pure returns (uint16) {
        return 1000; // 10%
    }

    function TOTAL_BASIS_POINTS() external pure returns (uint256) {
        return 10000; // 100%
    }

    function getStakingFeeAggregateDistributionE4Precision()
        external
        pure
        returns (uint16 treasuryFee, uint16 modulesFee)
    {
        treasuryFee = 500;
        modulesFee = 500;
    }

    function getStakingModuleMaxInitialDepositsAmount(
        uint256 stakingModuleId,
        uint256 eth
    ) external view returns (uint256, uint256) {
        return (stakingModuleMaxInitialDepositsAmount, stakingModuleMaxDepositsCount);
    }

    function getStakingModuleMaxDepositsCount(
        uint256, // _stakingModuleId,
        uint256 // _maxDepositsValue
    ) external view returns (uint256) {
        return stakingModuleMaxDepositsCount;
    }

    function deposit(
        uint256, // _stakingModuleId,
        bytes calldata // _depositCalldata
    ) external payable {
        emit Mock__DepositCalled();
    }

    function receiveDepositableEther() external payable {
        // Mock function to receive ETH from Lido.withdrawDepositableEther
    }

    function mock__getStakingModuleMaxDepositsCount(uint256 newValue) external {
        stakingModuleMaxDepositsCount = newValue;
        stakingModuleMaxInitialDepositsAmount = newValue * INITIAL_DEPOSIT_SIZE;
    }

    function mock__setStakingModuleMaxInitialDepositsAmount(uint256 newValue) external {
        stakingModuleMaxInitialDepositsAmount = newValue;
    }
}
