import fs from "node:fs";
import path from "node:path";

import { ethers } from "hardhat";

import { log } from "./log";
import { toBool } from "./string";

class StepsFileNotFoundError extends Error {
  constructor(filePath: string) {
    super(`Steps file ${filePath} not found!`);
    this.name = "StepsFileNotFoundError";
  }
}

class MigrationFileNotFoundError extends Error {
  constructor(filePath: string) {
    super(`Migration file ${filePath} not found!`);
    this.name = "MigrationFileNotFoundError";
  }
}

class MigrationMainFunctionError extends Error {
  constructor(filePath: string) {
    super(`Migration file ${filePath} does not export a 'main' function!`);
    this.name = "MigrationMainFunctionError";
  }
}

class MigrationSkipFunctionError extends Error {
  constructor(filePath: string) {
    super(`Migration file ${filePath} exports 'skip' but it is not a function!`);
    this.name = "MigrationSkipFunctionError";
  }
}

const deployedSteps: string[] = [];

async function applySteps(steps: string[]) {
  if (steps.every((step) => deployedSteps.includes(step))) {
    return; // All steps have been deployed
  }

  for (const step of steps) {
    const migrationFile = resolveMigrationFile(step);

    await applyMigrationScript(migrationFile);
    await ethers.provider.send("evm_mine", []); // Persist the state after each step

    deployedSteps.push(step);
  }
}

export async function deployUpgrade(networkName: string, stepsFile: string): Promise<void> {
  try {
    const steps = loadSteps(stepsFile);
    await applySteps(steps);
  } catch (error) {
    if (error instanceof StepsFileNotFoundError) {
      log.warning(`Upgrade steps not found in ${stepsFile}, assuming the protocol is already deployed`);
    } else {
      log.error("Upgrade failed:", (error as Error).message);
    }
  }
}

export async function deployScratchProtocol(): Promise<void> {
  const stepsFile = process.env.STEPS_FILE || "scratch/steps.json";
  const steps = loadSteps(stepsFile);

  await applySteps(steps);
}

type StepsFile = {
  steps: string[];
};

export const loadSteps = (stepsFile: string): string[] => {
  const stepsPath = path.resolve(process.cwd(), `scripts/${stepsFile}`);
  if (!fs.existsSync(stepsPath)) {
    throw new StepsFileNotFoundError(stepsPath);
  }

  return (JSON.parse(fs.readFileSync(stepsPath, "utf8")) as StepsFile).steps;
};

export const resolveMigrationFile = (step: string): string => {
  const migrationFile = path.resolve(process.cwd(), `scripts/${step}.ts`);
  if (!fs.existsSync(migrationFile)) {
    throw new MigrationFileNotFoundError(migrationFile);
  }

  return migrationFile;
};

/**
 * Executes a migration script.
 * @param {string} migrationFile - The path to the migration file.
 * @throws {Error} If the migration file doesn't export a 'main' function or if any error occurs during migration.
 */
export async function applyMigrationScript(migrationFile: string): Promise<void> {
  const fullPath = path.resolve(migrationFile);
  const { main, skip } = await import(fullPath);
  const allowSkipSteps = toBool(process.env.ALLOW_SKIP_STEPS);

  if (typeof main !== "function") {
    throw new MigrationMainFunctionError(migrationFile);
  }

  if (skip !== undefined && typeof skip !== "function") {
    throw new MigrationSkipFunctionError(migrationFile);
  }

  try {
    if (allowSkipSteps && skip && (await skip())) {
      log.scriptSkip(migrationFile);
      return;
    }

    log.scriptStart(migrationFile);
    await main();
    log.scriptFinish(migrationFile);
  } catch (error) {
    log.error("Migration failed:", error as Error);
    process.exit(1);
  }
}
