import { expect } from "chai";
import {
  ContractMethodArgs,
  ContractTransactionReceipt,
  ContractTransactionResponse,
  hexlify,
  Interface,
} from "ethers";
import { ethers } from "hardhat";

import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";
import { StandardMerkleTree } from "@openzeppelin/merkle-tree";

import {
  Dashboard,
  IStakingVault,
  Permissions,
  PinnedBeaconProxy,
  PredepositGuarantee,
  StakingVault,
  VaultFactory,
} from "typechain-types";
import { BLS12_381 } from "typechain-types/contracts/0.8.25/vaults/predeposit_guarantee/PredepositGuarantee";

import {
  days,
  de0x,
  findEventsWithInterfaces,
  generatePredeposit,
  getCurrentBlockTimestamp,
  impersonate,
  log,
  prepareLocalMerkleTree,
  TOTAL_BASIS_POINTS,
  Validator,
} from "lib";

import { ether } from "../../units";
import { LoadedContract, ProtocolContext } from "../types";

import {
  ensureFirstPostMigrationReport,
  normalizeWithdrawalVaultBaseline,
  waitNextAvailableReportTime,
} from "./accounting";

const VAULT_NODE_OPERATOR_FEE = 3_00n; // 3% node operator fee
const DEFAULT_CONFIRM_EXPIRY = days(7n);
export const VAULT_CONNECTION_DEPOSIT = ether("1");

// 1. Define the role keys as a const array
export const vaultRoleKeys = [
  "funder",
  "withdrawer",
  "minter",
  "burner",
  "rebalancer",
  "depositPauser",
  "depositResumer",
  "validatorExitRequester",
  "validatorWithdrawalTriggerer",
  "disconnecter",
  "unguaranteedDepositor",
  "unknownValidatorProver",
  "tierChanger",
  "nodeOperatorFeeExemptor",
  "assetCollector",
] as const;

export type VaultRoles = {
  [K in (typeof vaultRoleKeys)[number]]: HardhatEthersSigner;
};

export type VaultRoleMethods = {
  [K in (typeof vaultRoleKeys)[number]]: Promise<string>;
};

export interface VaultWithDashboard {
  stakingVault: StakingVault;
  dashboard: Dashboard;
  proxy: PinnedBeaconProxy;
}

/**
 * Creates a new vault with dashboard contract
 *
 * This function deploys a new StakingVault contract and its associated Dashboard contract
 * using the provided VaultFactory. It sets up all necessary roles and permissions.
 *
 * @param ctx Protocol context for event handling and contract interaction
 * @param stakingVaultFactory Factory contract used to create the vault
 * @param owner Address that will be set as the owner/admin of the vault
 * @param nodeOperator Address of the node operator
 * @param nodeOperatorManager Address of the node operator manager contract
 * @param roleAssignments Optional object to override default randomly generated role addresses
 * @param fee Node operator fee in basis points (default: 3% = 300 basis points)
 * @param confirmExpiry Time period for confirmation expiry (default: 7 days)
 * @returns Object containing the created StakingVault, Dashboard contract, and role addresses
 */
export async function createVaultWithDashboard(
  ctx: ProtocolContext,
  stakingVaultFactory: VaultFactory & { address: string },
  owner: HardhatEthersSigner,
  nodeOperator: HardhatEthersSigner,
  nodeOperatorManager: HardhatEthersSigner = nodeOperator,
  roleAssignments: Permissions.RoleAssignmentStruct[] = [],
  fee = VAULT_NODE_OPERATOR_FEE,
  confirmExpiry = DEFAULT_CONFIRM_EXPIRY,
): Promise<VaultWithDashboard> {
  const deployTx = await stakingVaultFactory
    .connect(owner)
    .createVaultWithDashboard(owner, nodeOperator, nodeOperatorManager, fee, confirmExpiry, roleAssignments, {
      value: VAULT_CONNECTION_DEPOSIT,
    });

  const createVaultTxReceipt = (await deployTx.wait()) as ContractTransactionReceipt;
  const createVaultEvents = ctx.getEvents(createVaultTxReceipt, "VaultCreated");

  expect(createVaultEvents.length).to.equal(1n, "Expected exactly one VaultCreated event");
  expect(createVaultEvents[0].args).to.not.be.undefined, "VaultCreated event args should be defined";

  const vaultAddress = createVaultEvents[0].args!.vault;

  const createDashboardEvents = ctx.getEvents(createVaultTxReceipt, "DashboardCreated");
  expect(createDashboardEvents.length).to.equal(1n, "Expected exactly one DashboardCreated event");
  expect(createDashboardEvents[0].args).to.not.be.undefined, "DashboardCreated event args should be defined";

  const dashboardAddress = createDashboardEvents[0].args!.dashboard;
  expect(createDashboardEvents[0].args!.vault).to.equal(vaultAddress);
  const adminAddress = createDashboardEvents[0].args!.admin;
  expect(adminAddress).to.equal(owner.address);

  const stakingVault = await ethers.getContractAt("StakingVault", vaultAddress);
  const dashboard = await ethers.getContractAt("Dashboard", dashboardAddress);
  const proxy = (await ethers.getContractAt("PinnedBeaconProxy", vaultAddress)) as PinnedBeaconProxy;

  return {
    stakingVault,
    dashboard,
    proxy,
  };
}

export const getRoleMethods = (dashboard: Dashboard): VaultRoleMethods => {
  return {
    funder: dashboard.FUND_ROLE(),
    withdrawer: dashboard.WITHDRAW_ROLE(),
    minter: dashboard.MINT_ROLE(),
    burner: dashboard.BURN_ROLE(),
    rebalancer: dashboard.REBALANCE_ROLE(),
    depositPauser: dashboard.PAUSE_BEACON_CHAIN_DEPOSITS_ROLE(),
    depositResumer: dashboard.RESUME_BEACON_CHAIN_DEPOSITS_ROLE(),
    validatorExitRequester: dashboard.REQUEST_VALIDATOR_EXIT_ROLE(),
    validatorWithdrawalTriggerer: dashboard.TRIGGER_VALIDATOR_WITHDRAWAL_ROLE(),
    disconnecter: dashboard.VOLUNTARY_DISCONNECT_ROLE(),
    unguaranteedDepositor: dashboard.NODE_OPERATOR_UNGUARANTEED_DEPOSIT_ROLE(),
    unknownValidatorProver: dashboard.NODE_OPERATOR_PROVE_UNKNOWN_VALIDATOR_ROLE(),
    tierChanger: dashboard.VAULT_CONFIGURATION_ROLE(),
    nodeOperatorFeeExemptor: dashboard.NODE_OPERATOR_FEE_EXEMPT_ROLE(),
    assetCollector: dashboard.COLLECT_VAULT_ERC20_ROLE(),
  };
};

export async function autofillRoles(
  dashboard: Dashboard,
  nodeOperatorManager: HardhatEthersSigner,
): Promise<VaultRoles> {
  const roleMethodMap: VaultRoleMethods = getRoleMethods(dashboard);

  const roleIds = await Promise.all(Object.values(roleMethodMap));
  const signers = await ethers.getSigners();

  const OFFSET = 10;

  const roleAssignments: Permissions.RoleAssignmentStruct[] = roleIds.map((roleId, i) => {
    return {
      role: roleId,
      account: signers[i + OFFSET],
    };
  });

  const nodeOperatorManagerRole = await dashboard.NODE_OPERATOR_MANAGER_ROLE();

  const NORoleAssignments: Permissions.RoleAssignmentStruct[] = [];
  const otherRoleAssignments: Permissions.RoleAssignmentStruct[] = [];

  for (const roleAssignment of roleAssignments) {
    if ((await dashboard.getRoleAdmin(roleAssignment.role)) !== nodeOperatorManagerRole) {
      otherRoleAssignments.push(roleAssignment);
    } else {
      NORoleAssignments.push(roleAssignment);
    }
  }

  await dashboard.connect(nodeOperatorManager).grantRoles(NORoleAssignments);
  await dashboard.grantRoles(otherRoleAssignments);

  // Build the result using the keys
  const result = {} as VaultRoles;
  vaultRoleKeys.forEach((key, i) => {
    result[key] = signers[i + OFFSET];
  });

  return result;
}

/**
 * Sets up the protocol with a maximum external ratio
 */
export async function setupLidoForVaults(ctx: ProtocolContext) {
  const { lido, acl } = ctx.contracts;

  if ((await lido.getMaxExternalRatioBP()) < 20_00n) {
    const agentSigner = await ctx.getSigner("agent");
    const role = await lido.STAKING_CONTROL_ROLE();
    const agentAddress = await agentSigner.getAddress();
    await acl.connect(agentSigner).grantPermission(agentAddress, lido.address, role);
    await lido.connect(agentSigner).setMaxExternalRatioBP(20_00n);
    await acl.connect(agentSigner).revokePermission(agentAddress, lido.address, role);
    log.success("Setting max external ratio to 20%");
  }

  // Initialize LazyOracle timestamp after the upgrade without activating
  // existing CL pending validators from the migrated state.
  await ensureFirstPostMigrationReport(ctx);
  await normalizeWithdrawalVaultBaseline(ctx, 0n);
}

export type VaultReportItem = {
  vault: string;
  totalValue: bigint;
  cumulativeLidoFees: bigint;
  liabilityShares: bigint;
  maxLiabilityShares: bigint;
  slashingReserve: bigint;
};

// Utility type to extract all value types from an object type
export type ValuesOf<T> = T[keyof T];

// Auto-extract value types from VaultReportItem
export type VaultReportValues = ValuesOf<VaultReportItem>[];

export function createVaultsReportTree(vaultReports: VaultReportItem[]): StandardMerkleTree<VaultReportValues> {
  return StandardMerkleTree.of(
    vaultReports.map((vaultReport) => [
      vaultReport.vault,
      vaultReport.totalValue,
      vaultReport.cumulativeLidoFees,
      vaultReport.liabilityShares,
      vaultReport.maxLiabilityShares,
      vaultReport.slashingReserve,
    ]),
    ["address", "uint256", "uint256", "uint256", "uint256", "uint256"],
  );
}

export async function reportVaultDataWithProof(
  ctx: ProtocolContext,
  stakingVault: StakingVault,
  params: Partial<Omit<VaultReportItem, "vault">> & {
    reportTimestamp?: bigint;
    reportRefSlot?: bigint;
    updateReportData?: boolean;
    waitForNextRefSlot?: boolean;
  } = {},
) {
  const { vaultHub, locator, lazyOracle, hashConsensus } = ctx.contracts;

  const vaultRecord = await vaultHub.vaultRecord(stakingVault);

  const vaultReport: VaultReportItem = {
    vault: await stakingVault.getAddress(),
    totalValue: params.totalValue ?? (await vaultHub.totalValue(stakingVault)),
    cumulativeLidoFees: params.cumulativeLidoFees ?? vaultRecord.cumulativeLidoFees,
    liabilityShares: params.liabilityShares ?? (await vaultHub.liabilityShares(stakingVault)),
    maxLiabilityShares: params.maxLiabilityShares ?? vaultRecord.maxLiabilityShares,
    slashingReserve: params.slashingReserve ?? 0n,
  };

  const reportTree = createVaultsReportTree([vaultReport]);

  if (params.waitForNextRefSlot) {
    await waitNextAvailableReportTime(ctx);
  }

  if (params.updateReportData ?? true) {
    const reportTimestampArg = params.reportTimestamp ?? (await getCurrentBlockTimestamp());
    const reportRefSlotArg = params.reportRefSlot ?? (await hashConsensus.getCurrentFrame()).refSlot;

    const accountingSigner = await impersonate(await locator.accountingOracle(), ether("100"));
    await lazyOracle
      .connect(accountingSigner)
      .updateReportData(reportTimestampArg, reportRefSlotArg, reportTree.root, "");
  }

  return lazyOracle.updateVaultData(
    await stakingVault.getAddress(),
    vaultReport.totalValue,
    vaultReport.cumulativeLidoFees,
    vaultReport.liabilityShares,
    vaultReport.maxLiabilityShares,
    vaultReport.slashingReserve,
    reportTree.getProof(0),
  );
}

/**
 * Report data for multiple vaults in a single Merkle tree
 * This is useful when you need to ensure all vaults have fresh reports at the same time
 *
 * @param ctx Protocol context
 * @param stakingVaults Array of StakingVault contracts to report
 * @param params Parameters for the report. If arrays are provided, they must match the length of stakingVaults
 */
export async function reportVaultsDataWithProof(
  ctx: ProtocolContext,
  stakingVaults: StakingVault[],
  params: {
    totalValue?: bigint | bigint[];
    cumulativeLidoFees?: bigint | bigint[];
    liabilityShares?: bigint | bigint[];
    maxLiabilityShares?: bigint | bigint[];
    slashingReserve?: bigint | bigint[];
    reportTimestamp?: bigint;
    reportRefSlot?: bigint;
    updateReportData?: boolean;
    waitForNextRefSlot?: boolean;
  } = {},
) {
  const { vaultHub, locator, lazyOracle, hashConsensus } = ctx.contracts;

  if (params.waitForNextRefSlot) {
    await waitNextAvailableReportTime(ctx);
  }

  // Helper to get value from array or single value
  const getValue = <T>(param: T | T[] | undefined, index: number, defaultValue: T): T => {
    if (param === undefined) return defaultValue;
    return Array.isArray(param) ? param[index] : param;
  };

  // Build vault reports for all vaults
  const vaultReports: VaultReportItem[] = await Promise.all(
    stakingVaults.map(async (vault, index) => {
      const vaultRecord = await vaultHub.vaultRecord(vault);
      return {
        vault: await vault.getAddress(),
        totalValue: getValue(params.totalValue, index, await vaultHub.totalValue(vault)),
        cumulativeLidoFees: getValue(params.cumulativeLidoFees, index, vaultRecord.cumulativeLidoFees),
        liabilityShares: getValue(params.liabilityShares, index, await vaultHub.liabilityShares(vault)),
        maxLiabilityShares: getValue(params.maxLiabilityShares, index, vaultRecord.maxLiabilityShares),
        slashingReserve: getValue(params.slashingReserve, index, 0n),
      };
    }),
  );

  // Create single Merkle tree for all vaults
  const reportTree = createVaultsReportTree(vaultReports);

  // Update report data once for all vaults
  if (params.updateReportData ?? true) {
    const reportTimestampArg = params.reportTimestamp ?? (await getCurrentBlockTimestamp());
    const reportRefSlotArg = params.reportRefSlot ?? (await hashConsensus.getCurrentFrame()).refSlot;

    const accountingSigner = await impersonate(await locator.accountingOracle(), ether("100"));
    await lazyOracle
      .connect(accountingSigner)
      .updateReportData(reportTimestampArg, reportRefSlotArg, reportTree.root, "");
  }

  // Update each vault data with its proof from the common tree
  const txs = [];
  for (let i = 0; i < stakingVaults.length; i++) {
    const vaultReport = vaultReports[i];
    const tx = await lazyOracle.updateVaultData(
      vaultReport.vault,
      vaultReport.totalValue,
      vaultReport.cumulativeLidoFees,
      vaultReport.liabilityShares,
      vaultReport.maxLiabilityShares,
      vaultReport.slashingReserve,
      reportTree.getProof(i),
    );
    txs.push(tx);
  }

  return txs;
}

interface CreateVaultResponse {
  tx: ContractTransactionResponse;
  proxy: PinnedBeaconProxy;
  vault: StakingVault;
  dashboard: Dashboard;
}

export async function createVaultProxy(
  caller: HardhatEthersSigner,
  vaultFactory: VaultFactory,
  vaultOwner: HardhatEthersSigner,
  nodeOperator: HardhatEthersSigner,
  nodeOperatorManager: HardhatEthersSigner = nodeOperator,
  nodeOperatorFeeBP: bigint = 200n,
  confirmExpiry: bigint = days(7n),
  roleAssignments: Permissions.RoleAssignmentStruct[] = [],
): Promise<CreateVaultResponse> {
  const tx = await vaultFactory
    .connect(caller)
    .createVaultWithDashboard(
      vaultOwner,
      nodeOperator,
      nodeOperatorManager,
      nodeOperatorFeeBP,
      confirmExpiry,
      roleAssignments,
      { value: VAULT_CONNECTION_DEPOSIT },
    );

  // Get the receipt manually
  const receipt = (await tx.wait())!;
  const events = findEventsWithInterfaces(receipt, "VaultCreated", [vaultFactory.interface]);

  if (events.length === 0) throw new Error("Vault creation event not found");

  const event = events[0];
  const { vault } = event.args;

  const dashboardEvents = findEventsWithInterfaces(receipt, "DashboardCreated", [vaultFactory.interface]);

  if (dashboardEvents.length === 0) throw new Error("Dashboard creation event not found");

  const { dashboard: dashboardAddress } = dashboardEvents[0].args;

  const proxy = (await ethers.getContractAt("PinnedBeaconProxy", vault, caller)) as PinnedBeaconProxy;
  const stakingVault = (await ethers.getContractAt("StakingVault", vault, caller)) as StakingVault;
  const dashboard = (await ethers.getContractAt("Dashboard", dashboardAddress, caller)) as Dashboard;

  return {
    tx,
    proxy,
    vault: stakingVault,
    dashboard,
  };
}

export async function createVaultProxyWithoutConnectingToVaultHub(
  caller: HardhatEthersSigner,
  vaultFactory: VaultFactory,
  vaultOwner: HardhatEthersSigner,
  nodeOperator: HardhatEthersSigner,
  nodeOperatorManager: HardhatEthersSigner = nodeOperator,
  nodeOperatorFeeBP: bigint = 200n,
  confirmExpiry: bigint = days(7n),
  roleAssignments: Permissions.RoleAssignmentStruct[] = [],
): Promise<CreateVaultResponse> {
  const tx = await vaultFactory
    .connect(caller)
    .createVaultWithDashboardWithoutConnectingToVaultHub(
      vaultOwner,
      nodeOperator,
      nodeOperatorManager,
      nodeOperatorFeeBP,
      confirmExpiry,
      roleAssignments,
    );

  // Get the receipt manually
  const receipt = (await tx.wait())!;
  const events = findEventsWithInterfaces(receipt, "VaultCreated", [vaultFactory.interface]);

  if (events.length === 0) throw new Error("Vault creation event not found");

  const event = events[0];
  const { vault } = event.args;

  const dashboardEvents = findEventsWithInterfaces(receipt, "DashboardCreated", [vaultFactory.interface]);

  if (dashboardEvents.length === 0) throw new Error("Dashboard creation event not found");

  const { dashboard: dashboardAddress } = dashboardEvents[0].args;

  const proxy = (await ethers.getContractAt("PinnedBeaconProxy", vault, caller)) as PinnedBeaconProxy;
  const stakingVault = (await ethers.getContractAt("StakingVault", vault, caller)) as StakingVault;
  const dashboard = (await ethers.getContractAt("Dashboard", dashboardAddress, caller)) as Dashboard;

  return {
    tx,
    proxy,
    vault: stakingVault,
    dashboard,
  };
}

/**
 * Sets up a staking vault with bad debt by slashing its total value below its liabilities
 * @param ctx Protocol context
 * @param vaultOwner Vault owner signer
 * @param nodeOperator Node operator signer
 * @param fundAmount Amount to fund the vault with
 * @param slashTo Amount to slash the vault's total value to
 * @returns Object containing the staking vault and the amount of bad debt shares
 */
export async function setupVaultWithBadDebt(
  ctx: ProtocolContext,
  vaultOwner: HardhatEthersSigner,
  nodeOperator: HardhatEthersSigner,
  fundAmount = ether("10"),
  slashTo = ether("1"),
): Promise<{ stakingVault: StakingVault; badDebtShares: bigint }> {
  const { stakingVaultFactory, lido } = ctx.contracts;

  // Create vault with dashboard
  const { stakingVault, dashboard } = await createVaultWithDashboard(
    ctx,
    stakingVaultFactory,
    vaultOwner,
    nodeOperator,
    nodeOperator,
  );

  // Fund and mint max shares
  await dashboard.connect(vaultOwner).fund({ value: fundAmount });

  const capacity = await dashboard.remainingMintingCapacityShares(0n);
  await dashboard.connect(vaultOwner).mintShares(vaultOwner, capacity);

  // Slash to create bad debt
  await reportVaultDataWithProof(ctx, stakingVault, {
    totalValue: slashTo,
    slashingReserve: slashTo,
    waitForNextRefSlot: true,
  });

  // Verify bad debt exists
  const totalValue = await dashboard.totalValue();
  const liabilityShares = await dashboard.liabilityShares();
  const liabilityValue = await lido.getPooledEthBySharesRoundUp(liabilityShares);
  expect(totalValue).to.be.lessThan(liabilityValue, "Vault should have bad debt");

  // Calculate bad debt amount
  const badDebtShares = liabilityShares - (await lido.getSharesByPooledEth(totalValue));

  return { stakingVault, badDebtShares };
}

/**
 * Queue bad debt internalization for a staking vault
 * @param ctx Protocol context
 * @param stakingVault Staking vault to internalize bad debt for
 * @param badDebtShares Amount of bad debt shares to internalize
 */
export async function queueBadDebtInternalization(
  ctx: ProtocolContext,
  stakingVault: StakingVault,
  badDebtShares: bigint,
): Promise<void> {
  expect(badDebtShares).to.be.gt(0n, "Bad debt shares must be greater than zero");

  // Grant BAD_DEBT_MASTER_ROLE to daoAgent
  const { vaultHub } = ctx.contracts;
  const aragonAgent = await ctx.getSigner("agent");
  await vaultHub.connect(aragonAgent).grantRole(await vaultHub.BAD_DEBT_MASTER_ROLE(), aragonAgent);

  // Queue bad debt for internalization
  const badDebtToBefore = await vaultHub.badDebtToInternalize();
  await vaultHub.connect(aragonAgent).internalizeBadDebt(stakingVault, badDebtShares);
  const badDebtToAfter = await vaultHub.badDebtToInternalize();

  expect(badDebtToAfter - badDebtToBefore).to.equal(badDebtShares, "Bad debt should be queued");
}

export const getPubkeys = (num: number): { pubkeys: string[]; stringified: string } => {
  const pubkeys = Array.from({ length: num }, (_, i) => {
    const paddedIndex = (i + 1).toString().padStart(8, "0");
    return `0x${paddedIndex.repeat(12)}`;
  });

  return {
    pubkeys,
    stringified: `0x${pubkeys.map(de0x).join("")}`,
  };
};

export const generatePredepositData = async (
  predepositGuarantee: LoadedContract<PredepositGuarantee>,
  dashboard: Dashboard,
  owner: HardhatEthersSigner,
  nodeOperator: HardhatEthersSigner,
  validator: Validator,
  guarantor?: HardhatEthersSigner,
): Promise<{
  deposit: IStakingVault.DepositStruct;
  depositY: BLS12_381.DepositYStruct;
}> => {
  guarantor = guarantor ?? nodeOperator;

  // Pre-requisite: fund the vault to have enough balance to start a validator
  await dashboard.connect(owner).fund({ value: ether("32") });

  // Step 1: Top up the node operator balance
  await predepositGuarantee.connect(guarantor).topUpNodeOperatorBalance(nodeOperator, {
    value: ether("1"),
  });

  // Step 2: Predeposit a validator
  return await generatePredeposit(validator, {
    depositDomain: await predepositGuarantee.DEPOSIT_DOMAIN(),
  });
};

export const mockProof = async (ctx: ProtocolContext, validator: Validator) => {
  const { predepositGuarantee } = ctx.contracts;

  // Step 3: Prove and deposit the validator
  const pivot_slot = await predepositGuarantee.PIVOT_SLOT();

  const mockCLtree = await prepareLocalMerkleTree(await predepositGuarantee.GI_FIRST_VALIDATOR_PREV());
  const { validatorIndex } = await mockCLtree.addValidator(validator.container);
  const { childBlockTimestamp, beaconBlockHeader } = await mockCLtree.commitChangesToBeaconRoot(
    Number(pivot_slot) + 100,
  );
  const proof = await mockCLtree.buildProof(validatorIndex, beaconBlockHeader);

  const pubkey = hexlify(validator.container.pubkey);

  return {
    proof,
    pubkey,
    validatorIndex,
    childBlockTimestamp,
    slot: beaconBlockHeader.slot,
    proposerIndex: beaconBlockHeader.proposerIndex,
  };
};

export async function calculateLockedValue(
  ctx: ProtocolContext,
  stakingVault: StakingVault,
  params: {
    liabilityShares?: bigint;
    liabilitySharesIncrease?: bigint;
    minimalReserve?: bigint;
    reserveRatioBP?: bigint;
  } = {},
) {
  const { vaultHub, lido } = ctx.contracts;

  const liabilitySharesIncrease = params.liabilitySharesIncrease ?? 0n;

  const liabilityShares =
    (params.liabilityShares ?? (await vaultHub.liabilityShares(stakingVault))) + liabilitySharesIncrease;
  const minimalReserve = params.minimalReserve ?? (await vaultHub.vaultRecord(stakingVault)).minimalReserve;
  const reserveRatioBP = params.reserveRatioBP ?? (await vaultHub.vaultConnection(stakingVault)).reserveRatioBP;

  const liability = await lido.getPooledEthBySharesRoundUp(liabilityShares);
  const reserve = ceilDiv(liability * reserveRatioBP, TOTAL_BASIS_POINTS - reserveRatioBP);

  return liability + (reserve > minimalReserve ? reserve : minimalReserve);
}

export function ceilDiv(a: bigint, b: bigint): bigint {
  return (a + b - 1n) / b;
}

// Helper type to extract method names from a contract
export type Methods<T> = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [K in keyof T]: T[K] extends (...args: any) => any ? K : never;
}[keyof T];

// Helper functions for testing access control
export async function testMethod<
  T extends unknown[],
  C extends { connect: (signer: HardhatEthersSigner) => C; interface: Interface },
>(
  contract: C,
  methodName: Methods<C> & string,
  { successUsers, failingUsers }: { successUsers: HardhatEthersSigner[]; failingUsers: HardhatEthersSigner[] },
  argument: T,
  requiredRole: string,
  errorName = "AccessControlUnauthorizedAccount",
) {
  for (const user of failingUsers) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await expect((contract.connect(user) as any)[methodName](...(argument as ContractMethodArgs<T>)))
      .to.be.revertedWithCustomError(contract, errorName)
      .withArgs(user, requiredRole);
  }

  for (const user of successUsers) {
    await expect(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (contract.connect(user) as any)[methodName](...(argument as ContractMethodArgs<T>)),
    ).to.not.be.revertedWithCustomError(contract, errorName);
  }
}
