// SPDX-FileCopyrightText: 2025 Lido <info@lido.fi>
// SPDX-License-Identifier: GPL-3.0

pragma solidity 0.8.6;

import "../../TrustedCaller.sol";
import "../../libraries/EVMScriptCreator.sol";
import "../../interfaces/IEVMScriptFactory.sol";
import "../../interfaces/IOperatorGrid.sol";
import "../../interfaces/ILidoLocator.sol";

/// @author dry914
/// @notice Creates EVMScript to alter tiers in OperatorGrid
contract AlterTiersInOperatorGrid is TrustedCaller, IEVMScriptFactory {

    // -------------
    // ERROR MESSAGES
    // -------------

    string private constant ERROR_ZERO_LIDO_LOCATOR = "ZERO_LIDO_LOCATOR";
    string private constant ERROR_EMPTY_TIER_IDS = "EMPTY_TIER_IDS";
    string private constant ERROR_ARRAY_LENGTH_MISMATCH = "ARRAY_LENGTH_MISMATCH";
    string private constant ERROR_TIER_SHARE_LIMIT_TOO_HIGH = "TIER_SHARE_LIMIT_TOO_HIGH";
    string private constant ERROR_ZERO_RESERVE_RATIO = "ZERO_RESERVE_RATIO";
    string private constant ERROR_RESERVE_RATIO_TOO_HIGH = "RESERVE_RATIO_TOO_HIGH";
    string private constant ERROR_ZERO_FORCED_REBALANCE_THRESHOLD = "ZERO_FORCED_REBALANCE_THRESHOLD";
    string private constant ERROR_FORCED_REBALANCE_THRESHOLD_TOO_HIGH = "FORCED_REBALANCE_THRESHOLD_TOO_HIGH";
    string private constant ERROR_INFRA_FEE_TOO_HIGH = "INFRA_FEE_TOO_HIGH";
    string private constant ERROR_LIQUIDITY_FEE_TOO_HIGH = "LIQUIDITY_FEE_TOO_HIGH";
    string private constant ERROR_RESERVATION_FEE_TOO_HIGH = "RESERVATION_FEE_TOO_HIGH";

    // -------------
    // CONSTANTS
    // -------------

    /// @dev max value for fees in basis points - it's about 650%
    uint256 internal constant MAX_FEE_BP = type(uint16).max;
    uint256 internal constant MAX_RESERVE_RATIO_BP = 9999;
    uint256 internal constant DEFAULT_TIER_ID = 0;

    // -------------
    // VARIABLES
    // -------------

    /// @notice Address of Lido Locator
    ILidoLocator public immutable lidoLocator;

    /// @notice Maximum share limit
    uint256 public immutable defaultTierMaxShareLimit;

    // -------------
    // CONSTRUCTOR
    // -------------

    constructor(address _trustedCaller, address _lidoLocator, uint256 _defaultTierMaxShareLimit)
        TrustedCaller(_trustedCaller)
    {
        require(_lidoLocator != address(0), ERROR_ZERO_LIDO_LOCATOR);

        lidoLocator = ILidoLocator(_lidoLocator);
        defaultTierMaxShareLimit = _defaultTierMaxShareLimit;
    }

    // -------------
    // EXTERNAL METHODS
    // -------------

    /// @notice Creates EVMScript to alter tiers in OperatorGrid
    /// @param _creator Address who creates EVMScript
    /// @param _evmScriptCallData Encoded: uint256[] _tierIds, TierParams[] _tierParams
    function createEVMScript(address _creator, bytes calldata _evmScriptCallData)
        external
        view
        override
        onlyTrustedCaller(_creator)
        returns (bytes memory)
    {
        (uint256[] memory _tierIds, TierParams[] memory _tierParams) = _decodeEVMScriptCallData(_evmScriptCallData);

        _validateInputData(_tierIds, _tierParams);

        return
            EVMScriptCreator.createEVMScript(
                lidoLocator.operatorGrid(),
                IOperatorGrid.alterTiers.selector,
                _evmScriptCallData
            );
    }

    /// @notice Decodes call data used by createEVMScript method
    /// @param _evmScriptCallData Encoded: uint256[] _tierIds, TierParams[] _tierParams
    /// @return Tier IDs and tier parameters which should be updated in OperatorGrid
    function decodeEVMScriptCallData(bytes calldata _evmScriptCallData)
        external
        pure
        returns (uint256[] memory, TierParams[] memory)
    {
        return _decodeEVMScriptCallData(_evmScriptCallData);
    }

    // ------------------
    // PRIVATE METHODS
    // ------------------

    function _decodeEVMScriptCallData(bytes memory _evmScriptCallData)
        private
        pure
        returns (uint256[] memory, TierParams[] memory)
    {
        return abi.decode(_evmScriptCallData, (uint256[], TierParams[]));
    }

    function _validateInputData(uint256[] memory _tierIds, TierParams[] memory _tierParams) private view {
        require(_tierIds.length > 0, ERROR_EMPTY_TIER_IDS);
        require(_tierIds.length == _tierParams.length, ERROR_ARRAY_LENGTH_MISMATCH);

        IOperatorGrid operatorGrid = IOperatorGrid(lidoLocator.operatorGrid());

        // Validate tier parameters
        for (uint256 i = 0; i < _tierIds.length; i++) {
            // reverts if tier does not exist in the operator grid
            IOperatorGrid.Tier memory tier = operatorGrid.tier(_tierIds[i]);

            if (_tierIds[i] == DEFAULT_TIER_ID) {
                require(_tierParams[i].shareLimit <= defaultTierMaxShareLimit, ERROR_TIER_SHARE_LIMIT_TOO_HIGH);
            } else {
                IOperatorGrid.Group memory group = operatorGrid.group(tier.operator);
                require(_tierParams[i].shareLimit <= group.shareLimit, ERROR_TIER_SHARE_LIMIT_TOO_HIGH);
            }

            require(_tierParams[i].reserveRatioBP != 0, ERROR_ZERO_RESERVE_RATIO);
            require(_tierParams[i].reserveRatioBP <= MAX_RESERVE_RATIO_BP, ERROR_RESERVE_RATIO_TOO_HIGH);

            require(_tierParams[i].forcedRebalanceThresholdBP != 0, ERROR_ZERO_FORCED_REBALANCE_THRESHOLD);
            require(_tierParams[i].forcedRebalanceThresholdBP + 10 < _tierParams[i].reserveRatioBP, ERROR_FORCED_REBALANCE_THRESHOLD_TOO_HIGH);

            require(_tierParams[i].infraFeeBP <= MAX_FEE_BP, ERROR_INFRA_FEE_TOO_HIGH);
            require(_tierParams[i].liquidityFeeBP <= MAX_FEE_BP, ERROR_LIQUIDITY_FEE_TOO_HIGH);
            require(_tierParams[i].reservationFeeBP <= MAX_FEE_BP, ERROR_RESERVATION_FEE_TOO_HIGH);
        }
    }
}
