from unittest.mock import Mock

import pytest

from src.constants import FAR_FUTURE_EPOCH, UINT64_MAX
from src.modules.oracles.accounting.types import BalanceStats
from src.providers.consensus.types import Validator, ValidatorState
from src.services.bunker_cases.abnormal_cl_rebase import AbnormalClRebase
from src.services.bunker_cases.types import BunkerConfig
from src.types import EpochNumber, Gwei, SlotNumber, ValidatorIndex
from src.web3py.extensions import LidoValidatorsProvider
from src.web3py.types import Web3
from tests.factory.blockstamp import ReferenceBlockStampFactory
from tests.factory.configs import BunkerConfigFactory, ChainConfigFactory, FrameConfigFactory
from tests.factory.no_registry import LidoValidatorFactory, ValidatorStateFactory
from tests.modules.accounting.bunker.conftest import simple_blockstamp, simple_key, simple_ref_blockstamp


DEFAULT_BALANCE = Gwei(32 * 10**9)
_LIDO_WC = '0x010000000000000000000000aabbccddaabbccddaabbccddaabbccddaabbccdd'
_NON_LIDO_WC = '0x010000000000000000000000deadbeefdeadbeefdeadbeefdeadbeefdeadbeef'


def simple_validators(
    from_index: int,
    to_index: int,
    balance=DEFAULT_BALANCE,
    effective_balance=DEFAULT_BALANCE,
) -> list[Validator]:
    validators = []
    for index in range(from_index, to_index + 1):
        validator = Validator(
            index=ValidatorIndex(index),
            balance=balance,
            validator=ValidatorState(
                pubkey=f"0x{index}",
                withdrawal_credentials='',
                effective_balance=effective_balance,
                slashed=False,
                activation_eligibility_epoch=FAR_FUTURE_EPOCH,
                activation_epoch=EpochNumber(0),
                exit_epoch=FAR_FUTURE_EPOCH,
                withdrawable_epoch=FAR_FUTURE_EPOCH,
            ),
        )
        validators.append(validator)
    return validators


@pytest.mark.unit
@pytest.mark.parametrize(
    (
        "blockstamp",
        "frame_cl_rebase",
        "nearest_epoch_distance",
        "far_epoch_distance",
        "expected_is_abnormal",
        "lido_validators_exist",
    ),
    [
        (simple_ref_blockstamp(40), 378585832, 0, 0, False, True),  # < mistake rate
        (simple_ref_blockstamp(40), 378585831.6, 0, 0, False, True),  # == mistake rate and no check specific rebase
        (simple_ref_blockstamp(40), 378585830, 10, 20, False, True),  # > mistake rate but specific rebase is positive
        (simple_ref_blockstamp(40), 378585830, 10, 10, False, True),  # > mistake rate but specific rebase is positive
        (simple_ref_blockstamp(40), 378585830, 0, 0, True, True),  # > mistake rate and no check specific rebase
        (simple_ref_blockstamp(20), 126195276, 10, 20, True, True),  # > mistake rate and specific rebase is negative
        (simple_ref_blockstamp(20), 126195276, 10, 10, True, True),  # > mistake rate and specific rebase is negative
        (simple_ref_blockstamp(20), 126195276, 10, 10, False, False),  # > mistake rate and specific rebase is negative
    ],
)
def test_is_abnormal_cl_rebase(
    blockstamp,
    abnormal_case,
    mock_get_accounting_last_processing_ref_slot,
    mock_get_used_lido_keys,
    mock_get_eth_distributed_events,
    mock_get_withdrawal_vault_balance,
    mock_get_blockstamp,
    frame_cl_rebase,
    nearest_epoch_distance,
    far_epoch_distance,
    expected_is_abnormal,
    lido_validators_exist,
):
    all_validators = abnormal_case.w3.cc.get_validators(blockstamp)

    lido_validators = []
    if lido_validators_exist:
        lido_validators = abnormal_case.w3.cc.get_validators(blockstamp)[3:6]

    abnormal_case.b_conf = BunkerConfig(
        normalized_cl_reward_per_epoch=64,
        normalized_cl_reward_mistake_rate=0.1,
        rebase_check_nearest_epoch_distance=nearest_epoch_distance,
        rebase_check_distant_epoch_distance=far_epoch_distance,
    )
    abnormal_case.w3.lido_contracts.accounting_oracle.get_consensus_version = Mock(return_value=3)
    result = abnormal_case.is_abnormal_cl_rebase(blockstamp, all_validators, lido_validators, frame_cl_rebase)

    assert result == expected_is_abnormal


@pytest.mark.unit
@pytest.mark.parametrize(
    ("blockstamp", "expected_rebase"),
    [
        (simple_ref_blockstamp(50), 512000000),
        (simple_ref_blockstamp(40), 420650924),
        (simple_ref_blockstamp(20), 140216974),
        (simple_ref_blockstamp(123), 1120376622),
    ],
)
def test_calculate_lido_normal_cl_rebase(
    abnormal_case,
    mock_get_used_lido_keys,
    mock_get_accounting_last_processing_ref_slot,
    mock_get_eth_distributed_events,
    mock_get_withdrawal_vault_balance,
    mock_get_blockstamp,
    blockstamp,
    expected_rebase,
):
    abnormal_case.all_validators = abnormal_case.w3.cc.get_validators(blockstamp)
    abnormal_case.lido_validators = abnormal_case.w3.cc.get_validators(blockstamp)[3:6]
    abnormal_case.lido_keys = abnormal_case.w3.kac.get_used_lido_keys(blockstamp)

    abnormal_case.w3.lido_contracts.accounting_oracle.get_consensus_version = Mock(return_value=3)
    result = abnormal_case._calculate_lido_normal_cl_rebase(blockstamp)

    assert result == expected_rebase


@pytest.mark.unit
@pytest.mark.parametrize(
    ("blockstamp", "nearest_epoch_distance", "far_epoch_distance", "expected_is_negative"),
    [
        (simple_ref_blockstamp(40), 10, 20, False),
        (simple_ref_blockstamp(20), 10, 20, True),
        (simple_ref_blockstamp(20), 10, 10, True),
        (simple_ref_blockstamp(33), 2, 33, True),
        (
            simple_ref_blockstamp(20),
            20,
            10,
            "nearest_slot=0 should be between distant_slot=10 and ref_slot=20 in specific CL rebase calculation",
        ),
        (
            simple_ref_blockstamp(20),
            10,
            -10,
            "nearest_slot=10 should be between distant_slot=30 and ref_slot=20 in specific CL rebase calculation",
        ),
    ],
)
def test_is_negative_specific_cl_rebase(
    abnormal_case,
    mock_get_accounting_last_processing_ref_slot,
    mock_get_eth_distributed_events,
    mock_get_withdrawal_vault_balance,
    mock_get_blockstamp,
    blockstamp,
    nearest_epoch_distance,
    far_epoch_distance,
    expected_is_negative,
):
    abnormal_case.lido_validators = abnormal_case.w3.cc.get_validators(blockstamp)[3:6]
    abnormal_case.lido_keys = [
        simple_key('0x03'),
        simple_key('0x04'),
        simple_key('0x05'),
    ]
    abnormal_case.b_conf = BunkerConfig(
        normalized_cl_reward_per_epoch=64,
        normalized_cl_reward_mistake_rate=0.1,
        rebase_check_nearest_epoch_distance=nearest_epoch_distance,
        rebase_check_distant_epoch_distance=far_epoch_distance,
    )
    abnormal_case.w3.lido_contracts.accounting_oracle.get_consensus_version = Mock(return_value=3)
    if isinstance(expected_is_negative, str):
        with pytest.raises(ValueError, match=expected_is_negative):
            abnormal_case._is_negative_specific_cl_rebase(blockstamp)
    else:
        result = abnormal_case._is_negative_specific_cl_rebase(blockstamp)
        assert result == expected_is_negative


@pytest.mark.unit
@pytest.mark.parametrize(
    ("blockstamp", "expected_blockstamps"),
    [
        (simple_ref_blockstamp(40), (simple_blockstamp(30), simple_blockstamp(20))),
        (simple_ref_blockstamp(20), (simple_blockstamp(10), simple_blockstamp(0))),
        (simple_ref_blockstamp(444444), (simple_blockstamp(444431), simple_blockstamp(444420))),
    ],
)
def test_get_nearest_and_distant_blockstamps(
    abnormal_case,
    mock_get_blockstamp,
    blockstamp,
    expected_blockstamps,
):
    abnormal_case.b_conf = BunkerConfig(
        normalized_cl_reward_per_epoch=64,
        normalized_cl_reward_mistake_rate=0.1,
        rebase_check_nearest_epoch_distance=10,
        rebase_check_distant_epoch_distance=20,
    )

    nearest_blockstamp, distant_blockstamp = abnormal_case._get_nearest_and_distant_blockstamps(blockstamp)

    assert nearest_blockstamp == expected_blockstamps[0]
    assert distant_blockstamp == expected_blockstamps[1]


@pytest.mark.unit
@pytest.mark.parametrize(
    (
        "prev_lido_validators",
        "curr_lido_validators",
        "prev_withdrawals_vault_balance",  # wei
        "curr_withdrawals_vault_balance",  # wei
        "withdrawn_from_vault",  # Gwei
        "expected_rebase",  # Gwei
    ),
    [
        (
            # The same count of validators,
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # but current validators have more balance (has non-withdrawn rewards).
            LidoValidatorFactory.batch(10, balance=(32 * 10**9) + Gwei(100_000)),
            # Previous withdrawals vault balance the same as current
            15 * 10**18,
            15 * 10**18,
            # and nothing was withdrawn from the vault.
            Gwei(0),
            # Rebase is equal non-withdrawn rewards from vals above.
            Gwei(10 * 100_000),
        ),
        (
            # The same count of validators,
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # and the same balance.
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # Previous withdrawals vault balance the same as current
            15 * 10**18,
            15 * 10**18,
            # and rewards was withdrawn from the vault.
            Gwei(10 * 100_000),
            # Rebase is equal withdrawn rewards.
            Gwei(10 * 100_000),
        ),
        (
            # New vals count is more than previous,
            LidoValidatorFactory.batch(9, balance=32 * 10**9),
            # and have the same balance.
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # Previous withdrawals vault balance the same as current
            15 * 10**18,
            15 * 10**18,
            # and nothing was withdrawn from the vault.
            Gwei(0),
            # Rebase should be equal to 0 because validators diff has been accounted.
            Gwei(0),
        ),
        (
            # The same count of validators,
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # but some validators have less balance (has penalties).
            [
                *LidoValidatorFactory.batch(5, balance=(32 * 10**9) - Gwei(100_000)),
                *LidoValidatorFactory.batch(5, balance=32 * 10**9),
            ],
            # Previous withdrawals vault balance the same as current.
            15 * 10**18,
            15 * 10**18,
            # rewards was withdrawn from the vault.
            Gwei(10 * 100_000),
            # Rebase is equal to rewards minus penalties.
            Gwei(5 * 100_000),
        ),
        (
            # The same count of validators,
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # but some validators have less balance (has penalties).
            [
                *LidoValidatorFactory.batch(5, balance=(32 * 10**9) - Gwei(100_000)),
                *LidoValidatorFactory.batch(5, balance=32 * 10**9),
            ],
            # Current withdrawals vault balance is more than previous because some rewards were withdrawn
            15 * 10**18,
            15 * 10**18 + Web3.to_wei(10 * 100_000, 'gwei'),
            # but wasn't withdrawn from the vault.
            Gwei(0),
            # Rebase is equal to rewards on vault minus penalties
            Gwei(5 * 100_000),
        ),
        (
            # New vals count is more than previous,
            LidoValidatorFactory.batch(9, balance=32 * 10**9),
            # but some validators have less balance (has penalties).
            #     and another part has non-withdrawn rewards.
            [
                *LidoValidatorFactory.batch(5, balance=(32 * 10**9) - Gwei(100_000)),
                *LidoValidatorFactory.batch(5, balance=(32 * 10**9) + Gwei(100_000)),
            ],
            # Current withdrawals vault balance is more than previous
            # because some were got between withdrawal event and ref block,
            15 * 10**18,
            15 * 10**18 + Web3.to_wei(100_000, 'gwei'),
            # and some were withdrawn from the vault.
            Gwei(10 * 100_000),
            # Rebase is equal to rewards withdrawn from vault plus diff between vaults balances
            Gwei(10 * 100_000 + 100_000),
        ),
        (
            # New vals count is more than previous,
            LidoValidatorFactory.batch(9, balance=32 * 10**9),
            # but some validators have less balance (has penalties).
            [
                *LidoValidatorFactory.batch(5, balance=(32 * 10**9) - Gwei(100_000)),
                *LidoValidatorFactory.batch(5, balance=32 * 10**9),
            ],
            # Current withdrawals vault balance is less than previous
            15 * 10**18,
            15 * 10**18 - Web3.to_wei(10 * 100_000, 'gwei'),
            # because were withdrawn from the vault.
            Gwei(10 * 100_000),
            # Rebase is equal to penalties. Validators diff has been accounted
            Gwei(-5 * 100_000),
        ),
        (
            # The same count of validators,
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # but current validators have less balance (has penalties).
            LidoValidatorFactory.batch(10, balance=(32 * 10**9) - Gwei(100_000)),
            # Previous withdrawals vault balance the same as current
            15 * 10**18,
            15 * 10**18,
            # nothing was withdrawn from the vault.
            Gwei(0),
            # Rebase is equal to penalties.
            Gwei(-10 * 100_000),
        ),
        (
            # New vals count is less than previous,
            LidoValidatorFactory.batch(10, balance=32 * 10**9),
            # and have the same balance
            LidoValidatorFactory.batch(9, balance=32 * 10**9),
            UINT64_MAX,
            UINT64_MAX,
            UINT64_MAX,
            # It is an exception because the new vals count can't be less that previous
            ValueError("Validators count diff should be positive or 0. Something went wrong with CL API"),
        ),
    ],
)
def test_calculate_cl_rebase_between_blocks(
    monkeypatch,
    web3,
    prev_lido_validators,
    curr_lido_validators,
    prev_withdrawals_vault_balance,
    curr_withdrawals_vault_balance,
    withdrawn_from_vault,
    expected_rebase,
):
    prev_blockstamp = ReferenceBlockStampFactory.build(block_number=8)
    ref_blockstamp = ReferenceBlockStampFactory.build(block_number=88)
    abnormal_case = AbnormalClRebase(
        web3, ChainConfigFactory.build(), BunkerConfigFactory.build(), FrameConfigFactory.build()
    )
    abnormal_case.lido_keys = Mock()
    abnormal_case.w3.cc = Mock()
    abnormal_case.w3.lido_contracts = Mock()
    abnormal_case.w3.cc.get_validators_no_cache = Mock()

    monkeypatch.setattr(
        LidoValidatorsProvider,
        "compute_lido_validators",
        Mock(return_value=(prev_lido_validators, [])),
    )
    abnormal_case.lido_validators = curr_lido_validators
    abnormal_case.w3.lido_contracts.get_withdrawal_balance_no_cache = Mock(
        side_effect=[curr_withdrawals_vault_balance, prev_withdrawals_vault_balance]
    )
    abnormal_case._get_withdrawn_from_vault_between_blocks = Mock(return_value=withdrawn_from_vault)
    abnormal_case.w3.lido_contracts.accounting_oracle.get_consensus_version = Mock(return_value=3)
    # Pre-v4: version check returns 3, so _calculate_injected_capital uses the fallback path
    abnormal_case.w3.lido_contracts.lido.get_contract_version = Mock(return_value=3)
    abnormal_case._get_last_report_reference_blockstamp = Mock(
        return_value=ReferenceBlockStampFactory.build(block_number=0)
    )

    if isinstance(expected_rebase, Exception):
        with pytest.raises(ValueError, match=expected_rebase.args[0]):
            abnormal_case._calculate_cl_rebase_between_blocks(prev_blockstamp, ref_blockstamp)
    else:
        result = abnormal_case._calculate_cl_rebase_between_blocks(prev_blockstamp, ref_blockstamp)
        assert result == expected_rebase


@pytest.mark.unit
@pytest.mark.parametrize(
    ("blockstamp", "expected_result"),
    [
        (simple_ref_blockstamp(40), 98001157445),
        (simple_ref_blockstamp(20), 77999899300),
    ],
)
def test_get_lido_validators_balance_with_vault_pre_electra(
    abnormal_case,
    mock_get_withdrawal_vault_balance,
    blockstamp,
    expected_result,
):
    lido_validators = abnormal_case.w3.cc.get_validators(blockstamp)[3:6]

    abnormal_case.w3.lido_contracts.accounting_oracle.get_consensus_version = Mock(return_value=3)
    result = abnormal_case._get_lido_validators_balance_with_vault(blockstamp, lido_validators)

    assert result == expected_result


@pytest.mark.unit
@pytest.mark.parametrize(
    ("blockstamp", "expected_result"),
    [
        (simple_ref_blockstamp(50), 66001157445),
        (simple_ref_blockstamp(40), 98001157445),
        (simple_ref_blockstamp(20), 77999899300),
    ],
)
def test_get_lido_validators_balance_with_vault_post_electra(
    abnormal_case,
    mock_get_withdrawal_vault_balance,
    blockstamp,
    expected_result,
):
    lido_validators = abnormal_case.w3.cc.get_validators(blockstamp)[3:6]

    abnormal_case.w3.lido_contracts.accounting_oracle.get_consensus_version = Mock(return_value=3)
    abnormal_case.w3.cc.get_config_spec = Mock(return_value=Mock(ELECTRA_FORK_EPOCH=blockstamp.ref_epoch))
    result = abnormal_case._get_lido_validators_balance_with_vault(blockstamp, lido_validators)

    assert result == expected_result


@pytest.mark.unit
@pytest.mark.parametrize(
    ("prev_blockstamp", "blockstamp", "expected_result"),
    [
        (simple_ref_blockstamp(0), simple_ref_blockstamp(10), 1 * 10**9),
        (simple_ref_blockstamp(10), simple_ref_blockstamp(20), 0),
        (simple_ref_blockstamp(20), simple_ref_blockstamp(31), "More than one ETHDistributed event found"),
    ],
)
def test_get_withdrawn_from_vault_between(
    abnormal_case, mock_get_eth_distributed_events, prev_blockstamp, blockstamp, expected_result
):
    if isinstance(expected_result, str):
        with pytest.raises(ValueError, match=expected_result):
            abnormal_case._get_withdrawn_from_vault_between_blocks(prev_blockstamp, blockstamp)
    else:
        result = abnormal_case._get_withdrawn_from_vault_between_blocks(prev_blockstamp, blockstamp)
        assert result == expected_result


MAX_EB_BALANCE = Gwei(2048 * 10**9)


@pytest.mark.unit
@pytest.mark.parametrize(
    ("prev_validators", "curr_validators", "expected_result"),
    [
        ([], [], 0),
        # No new validators
        (simple_validators(0, 9), simple_validators(0, 9), 0),
        # Two new validators at 32 ETH each
        (simple_validators(0, 9), simple_validators(0, 11), 2 * 32 * 10**9),
        # One new validator — counted at LIDO_DEPOSIT_AMOUNT (32 ETH) regardless of balance
        (
            simple_validators(0, 9),
            simple_validators(0, 9) + simple_validators(10, 10, balance=MAX_EB_BALANCE),
            32 * 10**9,
        ),
    ],
)
def test_get_validators_diff_in_gwei(prev_validators, curr_validators, expected_result):
    result = AbnormalClRebase.calculate_validators_count_diff_in_gwei(prev_validators, curr_validators)
    assert result == expected_result


@pytest.mark.unit
def test_get_validators_diff_in_gwei_raises_on_shrink():
    with pytest.raises(ValueError, match="Something went wrong with CL API"):
        AbnormalClRebase.calculate_validators_count_diff_in_gwei(simple_validators(0, 10), simple_validators(0, 9))


@pytest.mark.unit
@pytest.mark.parametrize(
    (
        "ref_deposited_since_last_report_wei",
        "ref_deposited_for_current_report_wei",
        "prev_deposited_since_last_report_wei",
        "prev_deposited_for_current_report_wei",
        "old_pending_gwei",
        "current_pending_gwei",
        "expected_gwei",
    ),
    [
        # NOTE: the fixture below has no Lido validator on the CL (lido_validators == [] on both ends),
        # so every queued deposit here is attributed through the *new-key* path. The already-indexed
        # top-up branch of _sum_valid_lido_pending is covered separately, in the tests below.
        #
        # 32 ETH deposited in [prev, ref]; nothing queued at either end
        (32 * 10**18, 0, 0, 0, 0, 0, 32 * 10**9),
        # 64 ETH deposited in [prev, ref], but 32 ETH of it is still queued at ref
        (64 * 10**18, 0, 0, 0, 0, 32 * 10**9, 32 * 10**9),
        # 32 ETH already queued at prev gets applied by ref, on top of 64 ETH deposited in [prev, ref]
        (64 * 10**18, 0, 0, 0, 32 * 10**9, 0, 96 * 10**9),
        # Plain intra-frame delta, no backlog anywhere
        (100 * 10**18, 0, 40 * 10**18, 0, 0, 0, 60 * 10**9),
        # A backlog of 40 ETH exists at prev (deposited_for_current_report == deposited_since_last_report
        # there, i.e. nothing deposited yet in the frame active at prev) and gets settled/reset before
        # ref is read, so ref's deposited_since_last_report (60 ETH) no longer includes that backlog.
        # A naive diff (60 - 40 = 20 ETH) would under-count; subtracting prev's own backlog back in
        # recovers the true 60 ETH deposited in [prev, ref].
        (60 * 10**18, 0, 40 * 10**18, 40 * 10**18, 0, 0, 60 * 10**9),
        # Same 40 ETH backlog exists at BOTH prev and ref (no report ever settles in [prev, ref], so it's
        # never cleared). Subtracting deposited_for_current_report from both ends cancels the backlog on
        # both sides; a formula that only corrected prev (deposited_since_last_report(ref) minus prev's
        # adjusted value) would wrongly return 100 ETH here instead of the true 60 ETH deposited in
        # [prev, ref].
        (100 * 10**18, 40 * 10**18, 40 * 10**18, 40 * 10**18, 0, 0, 60 * 10**9),
        # No deposits in [prev, ref], no pending changes
        (0, 0, 0, 0, 0, 0, 0),
    ],
)
def test_calculate_injected_capital__v4__correct_wei_to_gwei_conversion(
    web3,
    monkeypatch,
    ref_deposited_since_last_report_wei,
    ref_deposited_for_current_report_wei,
    prev_deposited_since_last_report_wei,
    prev_deposited_for_current_report_wei,
    old_pending_gwei,
    current_pending_gwei,
    expected_gwei,
):
    prev_blockstamp = ReferenceBlockStampFactory.build(block_number=10)
    ref_blockstamp = ReferenceBlockStampFactory.build(block_number=20)
    abnormal_case = AbnormalClRebase(
        web3, ChainConfigFactory.build(), BunkerConfigFactory.build(), FrameConfigFactory.build()
    )

    lido_pubkey = '0xabc'
    lido_wc = '0x010000000000000000000000aabbccddaabbccddaabbccddaabbccddaabbccdd'
    abnormal_case.lido_keys = [simple_key(lido_pubkey)]
    abnormal_case.lido_validators = []

    last_report_bs = ReferenceBlockStampFactory.build(block_number=5)
    abnormal_case._get_last_report_reference_blockstamp = Mock(return_value=last_report_bs)
    abnormal_case.w3.lido_contracts.lido.get_contract_version = Mock(return_value=4)
    abnormal_case.w3.lido_validators.get_lido_wc_list = Mock(return_value=[lido_wc])
    genesis_mock = Mock()
    genesis_mock.genesis_fork_version = '0x00000000'
    abnormal_case.w3.cc.get_genesis = Mock(return_value=genesis_mock)

    monkeypatch.setattr(
        'src.web3py.extensions.lido_validators.is_valid_deposit_signature',
        Mock(return_value=True),
    )
    monkeypatch.setattr(
        'src.web3py.extensions.lido_validators.hex_str_to_bytes',
        lambda s: s.encode() if isinstance(s, str) else s,
    )

    def make_deposit(amount):
        return Mock(pubkey=lido_pubkey, withdrawal_credentials=lido_wc, signature='0xsig', amount=amount)

    pending_at_prev = [make_deposit(old_pending_gwei)] if old_pending_gwei else []
    pending_at_ref = [make_deposit(current_pending_gwei)] if current_pending_gwei else []
    abnormal_case.w3.cc.get_pending_deposits = Mock(side_effect=[pending_at_prev, pending_at_ref])

    abnormal_case.w3.lido_contracts.lido.get_balance_stats = Mock(
        side_effect=[
            BalanceStats(0, 0, ref_deposited_since_last_report_wei, ref_deposited_for_current_report_wei),
            BalanceStats(0, 0, prev_deposited_since_last_report_wei, prev_deposited_for_current_report_wei),
        ]
    )

    result = abnormal_case._calculate_injected_capital(prev_blockstamp, ref_blockstamp, [])

    assert result == Gwei(expected_gwei)
    # The v4 upgrade check must read the contract version at the last report block
    abnormal_case.w3.lido_contracts.lido.get_contract_version.assert_called_once_with(last_report_bs.block_number)


@pytest.mark.unit
@pytest.mark.parametrize(
    ("topup_wc", "topup_signature"),
    [
        (_LIDO_WC, '0xsig'),
        # A top-up to an already-indexed validator is credited by the CL regardless of what the
        # deposit data says — the validator's own credentials apply. So neither a foreign WC nor a
        # broken proof-of-possession may make the oracle drop it.
        (_NON_LIDO_WC, '0xsig'),
        (_LIDO_WC, '0xgarbage'),
    ],
)
def test_calculate_injected_capital__v4__topup_to_indexed_validator__counted_without_validation(
    web3, monkeypatch, topup_wc, topup_signature
):
    """The `d.pubkey in existing_pubkeys` branch of _sum_valid_lido_pending.

    A key that already has a validator on the CL bypasses front-run detection entirely. If this
    top-up were instead routed through _collect_valid_pending_deposits it would be rejected for the
    foreign-WC and bad-signature cases, current_pending would drop to 0, and injected capital would
    come out as 64 ETH instead of 32 ETH — inflating the apparent CL rebase.
    """
    # Arrange
    prev_blockstamp = ReferenceBlockStampFactory.build(block_number=10)
    ref_blockstamp = ReferenceBlockStampFactory.build(block_number=20)
    abnormal_case = AbnormalClRebase(
        web3, ChainConfigFactory.build(), BunkerConfigFactory.build(), FrameConfigFactory.build()
    )

    lido_pubkey = '0xabc'
    indexed_validator = LidoValidatorFactory.build(validator=ValidatorStateFactory.build(pubkey=lido_pubkey))
    abnormal_case.lido_keys = [simple_key(lido_pubkey)]
    abnormal_case.lido_validators = [indexed_validator]  # the key is already on the CL at ref

    abnormal_case._get_last_report_reference_blockstamp = Mock(
        return_value=ReferenceBlockStampFactory.build(block_number=5)
    )
    abnormal_case.w3.lido_contracts.lido.get_contract_version = Mock(return_value=4)
    abnormal_case.w3.lido_validators.get_lido_wc_list = Mock(return_value=[_LIDO_WC])
    abnormal_case.w3.cc.get_genesis = Mock(return_value=Mock(genesis_fork_version='0x00000000'))
    monkeypatch.setattr(
        'src.web3py.extensions.lido_validators.hex_str_to_bytes',
        lambda s: s.encode() if isinstance(s, str) else s,
    )

    topup = Mock(
        pubkey=lido_pubkey,
        withdrawal_credentials=topup_wc,
        signature=topup_signature,
        amount=32 * 10**9,
    )
    # Nothing queued at prev; the 32 ETH top-up is still queued at ref.
    abnormal_case.w3.cc.get_pending_deposits = Mock(side_effect=[[], [topup]])
    # get_balance_stats is read for ref first, then prev: 64 ETH deposited inside the window.
    abnormal_case.w3.lido_contracts.lido.get_balance_stats = Mock(
        side_effect=[BalanceStats(0, 0, 64 * 10**18, 0), BalanceStats(0, 0, 0, 0)]
    )

    # Act — the same validator existed at prev, so it is indexed on both ends
    result = abnormal_case._calculate_injected_capital(prev_blockstamp, ref_blockstamp, [indexed_validator])

    # Assert — 64 ETH deposited in the window, 32 ETH of it not yet applied on the CL
    assert result == Gwei(32 * 10**9)


@pytest.mark.unit
def test_calculate_injected_capital__v4__topup_queued_at_prev_and_applied_by_ref__counted_once(web3, monkeypatch):
    """Mirror of the above on the `old_pending` side: a top-up already queued at prev.

    Once the CL applies it, it shows up in validator balances, so it must be added back to injected
    capital — otherwise the rebase looks larger than it was.
    """
    # Arrange
    prev_blockstamp = ReferenceBlockStampFactory.build(block_number=10)
    ref_blockstamp = ReferenceBlockStampFactory.build(block_number=20)
    abnormal_case = AbnormalClRebase(
        web3, ChainConfigFactory.build(), BunkerConfigFactory.build(), FrameConfigFactory.build()
    )

    lido_pubkey = '0xabc'
    indexed_validator = LidoValidatorFactory.build(validator=ValidatorStateFactory.build(pubkey=lido_pubkey))
    abnormal_case.lido_keys = [simple_key(lido_pubkey)]
    abnormal_case.lido_validators = [indexed_validator]

    abnormal_case._get_last_report_reference_blockstamp = Mock(
        return_value=ReferenceBlockStampFactory.build(block_number=5)
    )
    abnormal_case.w3.lido_contracts.lido.get_contract_version = Mock(return_value=4)
    abnormal_case.w3.lido_validators.get_lido_wc_list = Mock(return_value=[_LIDO_WC])
    abnormal_case.w3.cc.get_genesis = Mock(return_value=Mock(genesis_fork_version='0x00000000'))
    monkeypatch.setattr(
        'src.web3py.extensions.lido_validators.hex_str_to_bytes',
        lambda s: s.encode() if isinstance(s, str) else s,
    )

    topup = Mock(pubkey=lido_pubkey, withdrawal_credentials=_LIDO_WC, signature='0xsig', amount=32 * 10**9)
    # 32 ETH queued at prev, applied by ref; another 64 ETH deposited inside the window.
    abnormal_case.w3.cc.get_pending_deposits = Mock(side_effect=[[topup], []])
    abnormal_case.w3.lido_contracts.lido.get_balance_stats = Mock(
        side_effect=[BalanceStats(0, 0, 64 * 10**18, 0), BalanceStats(0, 0, 0, 0)]
    )

    # Act
    result = abnormal_case._calculate_injected_capital(prev_blockstamp, ref_blockstamp, [indexed_validator])

    # Assert — 64 ETH deposited in the window plus the 32 ETH backlog that landed during it
    assert result == Gwei(96 * 10**9)


@pytest.mark.unit
def test_calculate_injected_capital__v4__prev_slot_before_ref_frame__raises(web3):
    """prev_blockstamp here stands in for either the nearest or distant blockstamp resolved by
    _get_nearest_and_distant_blockstamps — get_blockstamp can walk it back past a missed slot into
    an already-processed frame, which breaks the deposited_since_last_report/deposited_for_current_report
    diffing this function relies on. Checked here (not in _get_nearest_and_distant_blockstamps) so it
    covers both the nearest and distant case, against the resolved slot rather than the pre-resolution one.
    """
    # ChainConfigFactory/FrameConfigFactory defaults: slots_per_epoch=32, epochs_per_frame=10,
    # initial_epoch=0 -> 320-slot frames. ref_blockstamp's default ref_slot=294271 sits in the frame
    # starting at slot 294080; prev_blockstamp's slot_number=294079 is one slot before it.
    prev_blockstamp = ReferenceBlockStampFactory.build(block_number=10, slot_number=SlotNumber(294079))
    ref_blockstamp = ReferenceBlockStampFactory.build(block_number=20)
    abnormal_case = AbnormalClRebase(
        web3, ChainConfigFactory.build(), BunkerConfigFactory.build(), FrameConfigFactory.build()
    )
    abnormal_case._get_last_report_reference_blockstamp = Mock(return_value=ReferenceBlockStampFactory.build())
    abnormal_case.w3.lido_contracts.lido.get_contract_version = Mock(return_value=4)

    with pytest.raises(ValueError, match="prev_slot=294079 is before the start of the current reporting frame"):
        abnormal_case._calculate_injected_capital(prev_blockstamp, ref_blockstamp, [])


@pytest.mark.unit
def test_calculate_injected_capital__v4__invalid_signature_deposit_excluded(web3, monkeypatch):
    """Invalid-signature deposits in old_pending must not inflate injected_capital."""
    prev_blockstamp = ReferenceBlockStampFactory.build(block_number=10)
    ref_blockstamp = ReferenceBlockStampFactory.build(block_number=20)
    abnormal_case = AbnormalClRebase(
        web3, ChainConfigFactory.build(), BunkerConfigFactory.build(), FrameConfigFactory.build()
    )

    lido_pubkey = '0xabc'
    lido_wc = '0x010000000000000000000000aabbccddaabbccddaabbccddaabbccddaabbccdd'
    abnormal_case.lido_keys = [simple_key(lido_pubkey)]
    abnormal_case.lido_validators = []

    last_report_bs = ReferenceBlockStampFactory.build(block_number=5)
    abnormal_case._get_last_report_reference_blockstamp = Mock(return_value=last_report_bs)
    abnormal_case.w3.lido_contracts.lido.get_contract_version = Mock(return_value=4)
    abnormal_case.w3.lido_validators.get_lido_wc_list = Mock(return_value=[lido_wc])
    genesis_mock = Mock()
    genesis_mock.genesis_fork_version = '0x00000000'
    abnormal_case.w3.cc.get_genesis = Mock(return_value=genesis_mock)

    valid_deposit = Mock(pubkey=lido_pubkey, withdrawal_credentials=lido_wc, signature='0xvalid', amount=1000 * 10**9)
    invalid_deposit = Mock(pubkey=lido_pubkey, withdrawal_credentials=lido_wc, signature='0xinvalid', amount=1 * 10**9)

    def fake_is_valid(pubkey, withdrawal_credentials, amount, signature, genesis_fork_version):
        return signature != b'0xinvalid'

    monkeypatch.setattr(
        'src.web3py.extensions.lido_validators.is_valid_deposit_signature',
        fake_is_valid,
    )
    monkeypatch.setattr(
        'src.web3py.extensions.lido_validators.hex_str_to_bytes',
        lambda s: s.encode() if isinstance(s, str) else s,
    )

    # Invalid deposit comes first in queue (by deposit index), valid one second.
    # With frontrun-detection logic: invalid sig → skipped; valid sig + correct WC → counted.
    abnormal_case.w3.cc.get_pending_deposits = Mock(side_effect=[[invalid_deposit, valid_deposit], []])
    abnormal_case.w3.lido_contracts.lido.get_balance_stats = Mock(return_value=BalanceStats(0, 0, 0, 0))

    result = abnormal_case._calculate_injected_capital(prev_blockstamp, ref_blockstamp, [])

    # Only the valid 1000 ETH deposit should be counted; invalid 1 ETH excluded
    assert result == Gwei(1000 * 10**9)
    # The v4 upgrade check must read the contract version at the last report block
    abnormal_case.w3.lido_contracts.lido.get_contract_version.assert_called_once_with(last_report_bs.block_number)


@pytest.mark.unit
@pytest.mark.parametrize(
    ("curr_validators", "last_report_validators", "expected_result"),
    [
        ([], [], 0),
        (simple_validators(0, 9), simple_validators(0, 9), 10 * 32 * 10**9),
        (simple_validators(0, 9), simple_validators(0, 9, effective_balance=31 * 10**9), 10 * int(31.5 * 10**9)),
    ],
)
def test_get_mean_effective_balance_sum(curr_validators, last_report_validators, expected_result):
    result = AbnormalClRebase.get_mean_sum_of_effective_balance(
        simple_ref_blockstamp(0), simple_ref_blockstamp(0), curr_validators, last_report_validators
    )

    assert result == expected_result


@pytest.mark.unit
@pytest.mark.parametrize(
    ("distant_slot", "nearest_slot", "ref_slot", "expected_result"),
    [
        (1, 2, 3, None),
        (2, 1, 3, "nearest_slot=1 should be between distant_slot=2 and ref_slot=3 in specific CL rebase calculation"),
        (3, 2, 1, "nearest_slot=2 should be between distant_slot=3 and ref_slot=1 in specific CL rebase calculation"),
        (3, 1, 2, "nearest_slot=1 should be between distant_slot=3 and ref_slot=2 in specific CL rebase calculation"),
    ],
)
def test_validate_slot_distance(distant_slot, nearest_slot, ref_slot, expected_result):
    if expected_result is None:
        assert AbnormalClRebase.validate_slot_distance(distant_slot, nearest_slot, ref_slot) is None
    else:
        with pytest.raises(ValueError, match=expected_result):
            AbnormalClRebase.validate_slot_distance(distant_slot, nearest_slot, ref_slot)


@pytest.mark.unit
@pytest.mark.parametrize(
    ("validators", "expected_balance"),
    [
        ([], 0),
        (simple_validators(0, 9), 10 * 32 * 10**9),
        (
            simple_validators(0, 9, balance=int(31.75 * 10**9), effective_balance=32 * 10**9),
            10 * int(31.75 * 10**9),
        ),
        (simple_validators(0, 9, balance=10**9), 10 * 10**9),
    ],
)
def test_calculate_real_balance(validators, expected_balance):
    total_effective_balance = AbnormalClRebase.calculate_validators_balance_sum(validators)

    assert total_effective_balance == expected_balance


@pytest.mark.unit
@pytest.mark.parametrize(
    ("epoch_passed", "mean_lido", "mean_total", "expected"),
    [
        (0, 32 * 152261 * 10**9, 32 * 517310 * 10**9, 0),
        (1, 32 * 152261 * 10**9, 32 * 517310 * 10**9, 2423640516),
        (225, 32 * 152261 * 10**9, 32 * 517310 * 10**9, 545319116173),
        (450, 32 * 152261 * 10**9, 32 * 517310 * 10**9, 1090638232347),
    ],
)
def test_calculate_normal_cl_rebase(epoch_passed, mean_lido, mean_total, expected):
    bunker_config = BunkerConfig(
        normalized_cl_reward_per_epoch=64,
        normalized_cl_reward_mistake_rate=0.1,
        rebase_check_nearest_epoch_distance=0,
        rebase_check_distant_epoch_distance=0,
    )

    normal_cl_rebase = AbnormalClRebase.calculate_normal_cl_rebase(
        bunker_config,
        mean_total,
        mean_lido,
        epoch_passed,
    )
    assert normal_cl_rebase == expected
