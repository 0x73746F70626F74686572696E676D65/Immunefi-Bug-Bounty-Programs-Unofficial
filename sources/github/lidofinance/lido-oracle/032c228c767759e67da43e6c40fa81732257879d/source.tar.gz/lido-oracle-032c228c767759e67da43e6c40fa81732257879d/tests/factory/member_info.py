from src.modules.common.types import MemberInfo
from tests.factory.web3_factory import Web3DataclassFactory


class MemberInfoFactory(Web3DataclassFactory[MemberInfo]):  # noqa: E701
    ...
