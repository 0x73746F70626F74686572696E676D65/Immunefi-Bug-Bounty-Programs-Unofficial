import math
import re
from collections import defaultdict
from unittest.mock import Mock

import pytest
from eth_utils.address import to_checksum_address
from hexbytes import HexBytes
from web3.types import Wei

from src.constants import (
    EFFECTIVE_BALANCE_INCREMENT,
    MIN_ACTIVATION_BALANCE,
    TOTAL_BASIS_POINTS,
)
from src.modules.oracles.staking_modules.common.distribution import (
    Distribution,
    ValidatorDuties,
    ValidatorDutiesOutcome,
)
from src.modules.oracles.staking_modules.common.log import FramePerfLog, OperatorFrameSummary, ValidatorFrameSummary
from src.modules.oracles.staking_modules.common.state import DutyAccumulator, Frame, NetworkDuties, State
from src.modules.oracles.staking_modules.common.types import StrikesList
from src.providers.execution.contracts.cs_fee_distributor import CSFeeDistributorContract
from src.providers.execution.contracts.cs_parameters_registry import (
    CurveParams,
    KeyNumberValueInterval,
    KeyNumberValueIntervalList,
    PerformanceCoefficients,
    StrikesParams,
)
from src.providers.execution.exceptions import InconsistentData
from src.providers.keys.client import KAPIInconsistentData
from src.types import EpochNumber, NodeOperatorId, ValidatorIndex
from src.web3py.extensions import StakingModuleContracts
from src.web3py.types import Web3StakingModule
from tests.factory.blockstamp import ReferenceBlockStampFactory
from tests.factory.no_registry import LidoKeyFactory, LidoValidatorFactory, ValidatorFactory, ValidatorStateFactory


# Matches how distribution.py computes it: effective_balance // EFFECTIVE_BALANCE_INCREMENT
PARTICIPATION_SHARE_MULTIPLIER = MIN_ACTIVATION_BALANCE // EFFECTIVE_BALANCE_INCREMENT


def make_state() -> State:
    return State(EpochNumber(0), EpochNumber(31), epochs_per_frame=32)


@pytest.mark.parametrize(
    (
        "frames",
        "last_report",
        "mocked_curve_params",
        "frame_blockstamps",
        "shares_to_distribute",
        "distribution_in_frame",
        "expected_total_rewards",
        "expected_total_rewards_map",
        "expected_total_rebate",
        "expected_strikes",
    ),
    [
        # One frame
        (
            [(0, 31)],
            Mock(
                strikes={(NodeOperatorId(1), HexBytes("0x01")): StrikesList([1, 0, 0, 0, 1, 1])},
                rewards=[(NodeOperatorId(1), 500)],
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=StrikesParams(lifetime=6, threshold=...),
                    perf_leeway_data=...,
                    reward_share_data=...,
                    perf_coeffs=...,
                )
            ),
            [ReferenceBlockStampFactory.build(ref_epoch=31)],
            [500],
            [
                (
                    # rewards
                    {NodeOperatorId(1): 500},
                    # distributed_rewards
                    500,
                    # rebate_to_protocol
                    0,
                    # strikes
                    {(NodeOperatorId(1), HexBytes("0x01")): 1},
                )
            ],
            500,
            {NodeOperatorId(1): 1000},
            0,
            {(NodeOperatorId(1), HexBytes("0x01")): [1, 1, 0, 0, 0, 1]},
        ),
        # One frame, no strikes and rewards before
        (
            [(0, 31)],
            Mock(strikes={}, rewards=[]),
            Mock(
                return_value=CurveParams(
                    strikes_params=StrikesParams(lifetime=6, threshold=...),
                    perf_leeway_data=...,
                    reward_share_data=...,
                    perf_coeffs=...,
                )
            ),
            [ReferenceBlockStampFactory.build(ref_epoch=31)],
            [500],
            [
                (
                    # rewards
                    {NodeOperatorId(1): 500},
                    # distributed_rewards
                    500,
                    # rebate_to_protocol
                    0,
                    # strikes
                    {(NodeOperatorId(1), HexBytes("0x01")): 1},
                )
            ],
            500,
            {NodeOperatorId(1): 500},
            0,
            {(NodeOperatorId(1), HexBytes("0x01")): [1, 0, 0, 0, 0, 0]},
        ),
        # Multiple frames
        (
            [(0, 31), (32, 63), (64, 95)],
            Mock(
                strikes={
                    (NodeOperatorId(1), HexBytes("0x01")): StrikesList([1, 0, 0, 0, 1, 1]),
                    (NodeOperatorId(100500), HexBytes("0x100500")): StrikesList([0, 0, 0, 1, 1, 1]),
                },
                rewards=[(NodeOperatorId(1), 500)],
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=StrikesParams(lifetime=6, threshold=...),
                    perf_leeway_data=...,
                    reward_share_data=...,
                    perf_coeffs=...,
                )
            ),
            [
                ReferenceBlockStampFactory.build(ref_epoch=31),
                ReferenceBlockStampFactory.build(ref_epoch=63),
                ReferenceBlockStampFactory.build(ref_epoch=95),
            ],
            [
                500,
                500 + 700,
                500 + 700 + 300,
            ],
            [
                (
                    # rewards
                    {NodeOperatorId(1): 500},
                    # distributed_rewards
                    500,
                    # rebate_to_protocol
                    0,
                    # strikes
                    {(NodeOperatorId(1), HexBytes("0x01")): 1},
                ),
                (
                    # rewards
                    {NodeOperatorId(1): 700},
                    # distributed_rewards
                    700,
                    # rebate_to_protocol
                    0,
                    # strikes
                    {(NodeOperatorId(2), HexBytes("0x02")): 1},
                ),
                (
                    # rewards
                    {NodeOperatorId(1): 300},
                    # distributed_rewards
                    300,
                    # rebate_to_protocol
                    0,
                    # strikes
                    {},
                ),
            ],
            1500,
            {NodeOperatorId(1): 2000},
            0,
            {
                (NodeOperatorId(1), HexBytes("0x01")): [0, 0, 1, 1, 0, 0],
                (NodeOperatorId(2), HexBytes("0x02")): [0, 1, 0, 0, 0, 0],
            },
        ),
        # One frame with no distribution (all rewards rebated to the protocol)
        (
            [(0, 31)],
            Mock(
                strikes={(NodeOperatorId(1), HexBytes("0x01")): StrikesList([1, 0, 0, 0, 1, 1])},
                rewards=[(NodeOperatorId(1), 500)],
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=StrikesParams(lifetime=6, threshold=...),
                    perf_leeway_data=...,
                    reward_share_data=...,
                    perf_coeffs=...,
                )
            ),
            [ReferenceBlockStampFactory.build(ref_epoch=31)],
            [500],
            [
                (
                    # rewards
                    {},
                    # distributed_rewards
                    0,
                    # rebate_to_protocol
                    500,
                    # strikes
                    {(NodeOperatorId(1), HexBytes("0x01")): 1},
                )
            ],
            0,
            {NodeOperatorId(1): 500},
            500,
            {(NodeOperatorId(1), HexBytes("0x01")): [1, 1, 0, 0, 0, 1]},
        ),
        # Multiple frames, some of which are not distributed
        (
            [(0, 31), (32, 63), (64, 95)],
            Mock(
                strikes={
                    (NodeOperatorId(1), HexBytes("0x01")): StrikesList([1, 0, 0, 0, 1, 1]),
                    (NodeOperatorId(100500), HexBytes("0x100500")): StrikesList([0, 0, 0, 1, 1, 1]),
                },
                rewards=[(NodeOperatorId(1), 500)],
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=StrikesParams(lifetime=6, threshold=...),
                    perf_leeway_data=...,
                    reward_share_data=...,
                    perf_coeffs=...,
                )
            ),
            [
                ReferenceBlockStampFactory.build(ref_epoch=31),
                ReferenceBlockStampFactory.build(ref_epoch=63),
                ReferenceBlockStampFactory.build(ref_epoch=95),
            ],
            [
                500,
                500 + 700,
                500 + 700 + 300,
            ],
            [
                (
                    # rewards
                    {},
                    # distributed_rewards
                    0,
                    # rebate_to_protocol
                    500,
                    # strikes
                    {(NodeOperatorId(1), HexBytes("0x01")): 1},
                ),
                (
                    # rewards
                    {NodeOperatorId(1): 700},
                    # distributed_rewards
                    700,
                    # rebate_to_protocol
                    0,
                    # strikes
                    {(NodeOperatorId(2), HexBytes("0x02")): 1},
                ),
                (
                    # rewards
                    {},
                    # distributed_rewards
                    0,
                    # rebate_to_protocol
                    300,
                    # strikes
                    {},
                ),
            ],
            700,
            {NodeOperatorId(1): 500 + 700},
            500 + 300,
            {
                (NodeOperatorId(1), HexBytes("0x01")): [0, 0, 1, 1, 0, 0],
                (NodeOperatorId(2), HexBytes("0x02")): [0, 1, 0, 0, 0, 0],
            },
        ),
    ],
)
@pytest.mark.unit
def test_calculate_distribution(
    frames: list[Frame],
    last_report,
    mocked_curve_params,
    frame_blockstamps,
    shares_to_distribute,
    distribution_in_frame,
    expected_total_rewards,
    expected_total_rewards_map,
    expected_total_rebate,
    expected_strikes,
):
    # Mocking the data from EL
    w3 = Mock(
        spec=Web3StakingModule,
        staking_module=Mock(spec=StakingModuleContracts, fee_distributor=Mock(spec=CSFeeDistributorContract)),
    )
    w3.staking_module.fee_distributor.shares_to_distribute = Mock(side_effect=shares_to_distribute)
    w3.staking_module.get_curve_params = mocked_curve_params

    distribution = Distribution(w3, converter=..., state=make_state())
    distribution._get_module_validators = Mock(...)
    distribution.state.data = {f: {} for f in frames}
    distribution._get_frame_blockstamp = Mock(side_effect=frame_blockstamps)
    distribution._calculate_distribution_in_frame = Mock(side_effect=distribution_in_frame)

    result = distribution.calculate(blockstamp=..., last_report=last_report)

    assert result.total_rewards == expected_total_rewards
    assert result.total_rewards_map == expected_total_rewards_map
    assert result.total_rebate == expected_total_rebate
    assert result.strikes == expected_strikes

    assert len(result.logs.frames) == len(frames)
    for i, log in enumerate(result.logs.frames):
        assert log.blockstamp == frame_blockstamps[i]
        assert log.frame == frames[i]


@pytest.mark.unit
def test_calculate_distribution_handles_invalid_distribution():
    # Mocking the data from EL
    w3 = Mock(
        spec=Web3StakingModule,
        staking_module=Mock(spec=StakingModuleContracts, fee_distributor=Mock(spec=CSFeeDistributorContract)),
    )
    w3.staking_module.fee_distributor.shares_to_distribute = Mock(return_value=500)
    w3.staking_module.get_curve_params = Mock(...)

    distribution = Distribution(w3, converter=..., state=make_state())
    distribution._get_module_validators = Mock(...)
    distribution.state.data = {(EpochNumber(0), EpochNumber(31)): {}}
    distribution._get_frame_blockstamp = Mock(return_value=ReferenceBlockStampFactory.build(ref_epoch=31))
    distribution._calculate_distribution_in_frame = Mock(
        return_value=(
            # rewards
            {NodeOperatorId(1): 500},
            # distributed_rewards
            500,
            # rebate_to_protocol
            1,
            # strikes
            {},
        )
    )

    with pytest.raises(ValueError, match=re.escape("Invalid distribution: 500 + 1 > 500")):
        distribution.calculate(..., Mock(strikes={}, rewards=[]))


@pytest.mark.unit
def test_calculate_distribution_handles_invalid_distribution_in_total():
    # Mocking the data from EL
    w3 = Mock(
        spec=Web3StakingModule,
        staking_module=Mock(spec=StakingModuleContracts, fee_distributor=Mock(spec=CSFeeDistributorContract)),
    )
    w3.staking_module.fee_distributor.shares_to_distribute = Mock(return_value=500)
    w3.staking_module.get_curve_params = Mock(...)

    distribution = Distribution(w3, converter=..., state=make_state())
    distribution._get_module_validators = Mock(...)
    distribution.state.data = {(EpochNumber(0), EpochNumber(31)): {}}
    distribution._get_frame_blockstamp = Mock(return_value=ReferenceBlockStampFactory.build(ref_epoch=31))
    distribution._calculate_distribution_in_frame = Mock(
        return_value=(
            # rewards
            {NodeOperatorId(1): 500},
            # distributed_rewards
            400,
            # rebate_to_protocol
            1,
            # strikes
            {},
        )
    )

    with pytest.raises(InconsistentData, match="Invalid distribution"):
        distribution.calculate(..., Mock(strikes={}, rewards=[]))


@pytest.mark.parametrize(
    (
        "to_distribute",
        "frame_validators",
        "frame_state_data",
        "mocked_curve_params",
        "expected_rewards_distribution_map",
        "expected_distributed_rewards",
        "expected_rebate_to_protocol",
        "expected_frame_strikes",
        "expected_log",
    ),
    [
        # All above threshold performance
        (
            100,
            {
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1), validator=ValidatorStateFactory.build(slashed=False)
                    ),
                ],
            },
            NetworkDuties(
                attestations=defaultdict(
                    DutyAccumulator, {ValidatorIndex(1): DutyAccumulator(assigned=10, included=6)}
                ),
                proposals=defaultdict(DutyAccumulator, {ValidatorIndex(1): DutyAccumulator(assigned=10, included=6)}),
                syncs=defaultdict(DutyAccumulator, {ValidatorIndex(1): DutyAccumulator(assigned=10, included=6)}),
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=...,
                    perf_leeway_data=Mock(get_for=Mock(return_value=0.1)),
                    reward_share_data=Mock(get_for=Mock(return_value=1)),
                    perf_coeffs=PerformanceCoefficients(),
                )
            ),
            # Expected:
            # Rewards map
            {
                NodeOperatorId(1): 100,
            },
            # Distributed rewards
            100,
            # Rebate to protocol
            0,
            # Strikes
            {},
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=100,
                rebate_to_protocol=0,
                operators={
                    NodeOperatorId(1): OperatorFrameSummary(
                        distributed_rewards=100,
                        performance_coefficients=PerformanceCoefficients(),
                        validators={
                            ValidatorIndex(1): ValidatorFrameSummary(
                                distributed_rewards=100,
                                performance=0.6,
                                threshold=0.5,
                                reward_share=1.0,
                                participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                slashed=False,
                                strikes=0,
                                attestation_duty=DutyAccumulator(assigned=10, included=6),
                                proposal_duty=DutyAccumulator(assigned=10, included=6),
                                sync_duty=DutyAccumulator(assigned=10, included=6),
                            )
                        },
                    )
                },
            ),
        ),
        # All below threshold performance
        (
            100,
            {
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1), validator=ValidatorStateFactory.build(slashed=False, pubkey="0x01")
                    ),
                ],
            },
            NetworkDuties(
                attestations=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=5),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                    },
                ),
                proposals=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=5),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                    },
                ),
                syncs=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=5),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                    },
                ),
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=...,
                    perf_leeway_data=Mock(get_for=Mock(return_value=0.1)),
                    reward_share_data=Mock(get_for=Mock(return_value=1)),
                    perf_coeffs=PerformanceCoefficients(),
                )
            ),
            # Expected:
            # Distribution map
            {},
            # Distributed rewards
            0,
            # Rebate to protocol
            100,
            # Strikes
            {
                (NodeOperatorId(1), HexBytes('0x01')): 1,
            },
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=0,
                rebate_to_protocol=100,
                operators={
                    NodeOperatorId(1): OperatorFrameSummary(
                        distributed_rewards=0,
                        performance_coefficients=PerformanceCoefficients(),
                        validators={
                            ValidatorIndex(1): ValidatorFrameSummary(
                                performance=0.5,
                                threshold=0.65,
                                reward_share=1.0,
                                participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                slashed=False,
                                strikes=1,
                                attestation_duty=DutyAccumulator(assigned=10, included=5),
                                proposal_duty=DutyAccumulator(assigned=10, included=5),
                                sync_duty=DutyAccumulator(assigned=10, included=5),
                            )
                        },
                    )
                },
            ),
        ),
        # Leeway of 1.0 disables strikes regardless of performance
        (
            100,
            {
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x01", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(2),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x02", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
            },
            NetworkDuties(
                attestations=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                    },
                ),
                proposals=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                    },
                ),
                syncs=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                    },
                ),
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=...,
                    perf_leeway_data=Mock(get_for=Mock(return_value=1)),
                    reward_share_data=Mock(get_for=Mock(return_value=1)),
                    perf_coeffs=PerformanceCoefficients(),
                )
            ),
            # Expected:
            # Distribution map
            {
                NodeOperatorId(1): 100,
            },
            # Distributed rewards
            100,
            # Rebate to protocol
            0,
            # Strikes
            {},
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=100,
                rebate_to_protocol=0,
                operators={
                    NodeOperatorId(1): OperatorFrameSummary(
                        distributed_rewards=100,
                        performance_coefficients=PerformanceCoefficients(),
                        validators={
                            ValidatorIndex(1): ValidatorFrameSummary(
                                distributed_rewards=50,
                                performance=0.0,
                                threshold=0.0,
                                reward_share=1.0,
                                participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                slashed=False,
                                strikes=0,
                                attestation_duty=DutyAccumulator(assigned=10, included=0),
                                proposal_duty=DutyAccumulator(assigned=10, included=0),
                                sync_duty=DutyAccumulator(assigned=10, included=0),
                            ),
                            ValidatorIndex(2): ValidatorFrameSummary(
                                distributed_rewards=50,
                                performance=1.0,
                                threshold=0.0,
                                reward_share=1.0,
                                participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                slashed=False,
                                strikes=0,
                                attestation_duty=DutyAccumulator(assigned=10, included=10),
                                proposal_duty=DutyAccumulator(assigned=10, included=10),
                                sync_duty=DutyAccumulator(assigned=10, included=10),
                            ),
                        },
                    )
                },
            ),
        ),
        # Leeway of 1.0 (curated module scenario): no validator activated — full rebate to protocol
        (
            100,
            {
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x01", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(2),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x02", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
            },
            NetworkDuties(),
            Mock(
                return_value=CurveParams(
                    strikes_params=...,
                    perf_leeway_data=Mock(get_for=Mock(return_value=1)),
                    reward_share_data=Mock(get_for=Mock(return_value=1)),
                    perf_coeffs=PerformanceCoefficients(),
                )
            ),
            # Expected:
            # Distribution map
            {},
            # Distributed rewards
            0,
            # Rebate to protocol
            100,
            # Strikes
            {},
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=0,
                rebate_to_protocol=100,
                operators={},
            ),
        ),
        # Leeway of 1.0 (curated module scenario): all validators have 0 performance —
        # no rebate, all rewards go to operators because 100% leeway protects them
        (
            100,
            {
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x01", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(2),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x02", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
            },
            NetworkDuties(
                attestations=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=0),
                    },
                ),
                proposals=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=0),
                    },
                ),
                syncs=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=0),
                    },
                ),
            ),
            Mock(
                return_value=CurveParams(
                    strikes_params=...,
                    perf_leeway_data=Mock(get_for=Mock(return_value=1)),
                    reward_share_data=Mock(get_for=Mock(return_value=1)),
                    perf_coeffs=PerformanceCoefficients(),
                )
            ),
            # Expected:
            # Distribution map
            {
                NodeOperatorId(1): 100,
            },
            # Distributed rewards
            100,
            # Rebate to protocol
            0,
            # Strikes
            {},
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=100,
                rebate_to_protocol=0,
                operators={
                    NodeOperatorId(1): OperatorFrameSummary(
                        distributed_rewards=100,
                        performance_coefficients=PerformanceCoefficients(),
                        validators={
                            ValidatorIndex(1): ValidatorFrameSummary(
                                distributed_rewards=50,
                                performance=0.0,
                                threshold=0.0,
                                reward_share=1.0,
                                participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                slashed=False,
                                strikes=0,
                                attestation_duty=DutyAccumulator(assigned=10, included=0),
                                proposal_duty=DutyAccumulator(assigned=10, included=0),
                                sync_duty=DutyAccumulator(assigned=10, included=0),
                            ),
                            ValidatorIndex(2): ValidatorFrameSummary(
                                distributed_rewards=50,
                                performance=0.0,
                                threshold=0.0,
                                reward_share=1.0,
                                participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                slashed=False,
                                strikes=0,
                                attestation_duty=DutyAccumulator(assigned=10, included=0),
                                proposal_duty=DutyAccumulator(assigned=10, included=0),
                                sync_duty=DutyAccumulator(assigned=10, included=0),
                            ),
                        },
                    )
                },
            ),
        ),
        #  Mixed. With custom threshold and reward share
        (
            100,
            {
                # Operator 1. One above threshold performance, one slashed
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x01", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(2),
                        validator=ValidatorStateFactory.build(
                            slashed=True, pubkey="0x02", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
                # Operator 2. One above threshold performance, one below
                NodeOperatorId(2): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(3),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x03", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(4),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x04", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
                # Operator 3. All below threshold performance
                NodeOperatorId(3): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(5),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x05", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
                # Operator 4. No duties
                NodeOperatorId(4): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(6),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x06", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
                # Operator 5. All above threshold performance
                NodeOperatorId(5): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(7),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x07", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(8),
                        validator=ValidatorStateFactory.build(
                            slashed=False, pubkey="0x08", effective_balance=MIN_ACTIVATION_BALANCE
                        ),
                    ),
                ],
            },
            NetworkDuties(
                attestations=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(3): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(4): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(5): DutyAccumulator(assigned=10, included=0),
                        ValidatorIndex(7): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(8): DutyAccumulator(assigned=10, included=10),
                        # Network validator
                        ValidatorIndex(100500): DutyAccumulator(assigned=1000, included=1000),
                    },
                ),
                proposals=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(1): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(4): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(7): DutyAccumulator(assigned=10, included=10),
                        # Network validator
                        ValidatorIndex(100500): DutyAccumulator(assigned=1000, included=1000),
                    },
                ),
                syncs=defaultdict(
                    DutyAccumulator,
                    {
                        ValidatorIndex(2): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(3): DutyAccumulator(assigned=10, included=10),
                        ValidatorIndex(8): DutyAccumulator(assigned=10, included=10),
                        # Network validator
                        ValidatorIndex(100500): DutyAccumulator(assigned=1000, included=1000),
                    },
                ),
            ),
            Mock(
                side_effect=lambda no_id, _: {
                    NodeOperatorId(5): CurveParams(
                        strikes_params=...,
                        perf_leeway_data=KeyNumberValueIntervalList(
                            [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(2, 2000)]
                        ),
                        reward_share_data=KeyNumberValueIntervalList(
                            [KeyNumberValueInterval(1, 10000), KeyNumberValueInterval(2, 9000)]
                        ),
                        perf_coeffs=PerformanceCoefficients(attestations_weight=1, blocks_weight=0, sync_weight=0),
                    ),
                }.get(
                    no_id,
                    CurveParams(
                        strikes_params=...,
                        perf_leeway_data=Mock(get_for=Mock(return_value=0.1)),
                        reward_share_data=Mock(get_for=Mock(return_value=1)),
                        perf_coeffs=PerformanceCoefficients(),
                    ),
                ),
            ),
            # Expected:
            # Distribution map
            {
                NodeOperatorId(1): 25,
                NodeOperatorId(2): 25,
                NodeOperatorId(5): 47,
            },
            # Distributed rewards
            97,
            # Rebate to protocol
            3,
            # Strikes
            {
                (NodeOperatorId(1), HexBytes('0x02')): 1,  # Slashed
                (NodeOperatorId(2), HexBytes('0x04')): 1,  # Below threshold
                (NodeOperatorId(3), HexBytes('0x05')): 1,  # Below threshold
            },
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=97,
                rebate_to_protocol=3,
                operators=defaultdict(
                    OperatorFrameSummary,
                    {
                        NodeOperatorId(1): OperatorFrameSummary(
                            distributed_rewards=25,
                            performance_coefficients=PerformanceCoefficients(),
                            validators=defaultdict(
                                ValidatorFrameSummary,
                                {
                                    ValidatorIndex(1): ValidatorFrameSummary(
                                        distributed_rewards=25,
                                        performance=1.0,
                                        threshold=0.8842289719626168,
                                        reward_share=1,
                                        participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                        attestation_duty=DutyAccumulator(assigned=10, included=10),
                                        proposal_duty=DutyAccumulator(assigned=10, included=10),
                                    ),
                                    ValidatorIndex(2): ValidatorFrameSummary(
                                        slashed=True,
                                        strikes=1,
                                    ),
                                },
                            ),
                        ),
                        NodeOperatorId(2): OperatorFrameSummary(
                            distributed_rewards=25,
                            performance_coefficients=PerformanceCoefficients(),
                            validators=defaultdict(
                                ValidatorFrameSummary,
                                {
                                    ValidatorIndex(3): ValidatorFrameSummary(
                                        distributed_rewards=25,
                                        performance=1.0,
                                        threshold=0.8842289719626168,
                                        reward_share=1,
                                        participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                        attestation_duty=DutyAccumulator(assigned=10, included=10),
                                        sync_duty=DutyAccumulator(assigned=10, included=10),
                                    ),
                                    ValidatorIndex(4): ValidatorFrameSummary(
                                        distributed_rewards=0,
                                        performance=0.12903225806451613,
                                        threshold=0.8842289719626168,
                                        reward_share=1,
                                        participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                        strikes=1,
                                        attestation_duty=DutyAccumulator(assigned=10, included=0),
                                        proposal_duty=DutyAccumulator(assigned=10, included=10),
                                    ),
                                },
                            ),
                        ),
                        NodeOperatorId(3): OperatorFrameSummary(
                            distributed_rewards=0,
                            performance_coefficients=PerformanceCoefficients(),
                            validators=defaultdict(
                                ValidatorFrameSummary,
                                {
                                    ValidatorIndex(5): ValidatorFrameSummary(
                                        performance=0.0,
                                        threshold=0.8842289719626168,
                                        reward_share=1,
                                        participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                        strikes=1,
                                        attestation_duty=DutyAccumulator(assigned=10, included=0),
                                    ),
                                },
                            ),
                        ),
                        NodeOperatorId(5): OperatorFrameSummary(
                            distributed_rewards=47,
                            performance_coefficients=PerformanceCoefficients(
                                attestations_weight=1,
                                blocks_weight=0,
                                sync_weight=0,
                            ),
                            validators=defaultdict(
                                ValidatorFrameSummary,
                                {
                                    ValidatorIndex(7): ValidatorFrameSummary(
                                        distributed_rewards=25,
                                        performance=1.0,
                                        threshold=0.8842289719626168,
                                        reward_share=1.0,
                                        participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                        slashed=False,
                                        strikes=0,
                                        attestation_duty=DutyAccumulator(assigned=10, included=10),
                                        proposal_duty=DutyAccumulator(assigned=10, included=10),
                                    ),
                                    ValidatorIndex(8): ValidatorFrameSummary(
                                        distributed_rewards=22,
                                        performance=1.0,
                                        threshold=0.7842289719626168,
                                        reward_share=0.9,
                                        participation_share_multiplier=PARTICIPATION_SHARE_MULTIPLIER,
                                        slashed=False,
                                        strikes=0,
                                        attestation_duty=DutyAccumulator(assigned=10, included=10),
                                        sync_duty=DutyAccumulator(assigned=10, included=10),
                                    ),
                                },
                            ),
                        ),
                    },
                ),
            ),
        ),
        # No duties
        (
            100,
            {
                NodeOperatorId(1): [
                    LidoValidatorFactory.build(
                        index=ValidatorIndex(1), validator=ValidatorStateFactory.build(slashed=False)
                    ),
                ],
            },
            NetworkDuties(),
            Mock(
                return_value=CurveParams(
                    strikes_params=...,
                    perf_leeway_data=Mock(get_for=Mock(return_value=0.1)),
                    reward_share_data=Mock(get_for=Mock(return_value=1)),
                    perf_coeffs=PerformanceCoefficients(),
                )
            ),
            # Expected:
            # Distribution map
            {},
            # Distributed rewards
            0,
            # Rebate to protocol
            100,
            # Strikes
            {},
            FramePerfLog(
                blockstamp=...,
                frame=...,
                distributable=100,
                distributed_rewards=0,
                rebate_to_protocol=100,
                operators={},
            ),
        ),
    ],
)
@pytest.mark.unit
def test_calculate_distribution_in_frame(
    to_distribute,
    frame_validators,
    frame_state_data,
    mocked_curve_params,
    expected_rewards_distribution_map,
    expected_distributed_rewards,
    expected_rebate_to_protocol,
    expected_frame_strikes,
    expected_log,
):
    log = FramePerfLog(blockstamp=..., frame=...)
    # Mocking the data from EL
    w3 = Mock(spec=Web3StakingModule, staking_module=Mock(spec=StakingModuleContracts))
    w3.staking_module.get_curve_params = mocked_curve_params

    frame = (EpochNumber(0), EpochNumber(31))
    state = State(*frame, epochs_per_frame=32)
    state.data = {frame: frame_state_data}

    distribution = Distribution(w3, converter=..., state=state)

    (rewards_distribution, distributed_rewards, rebate_to_protocol, strikes_in_frame) = (
        distribution._calculate_distribution_in_frame(
            frame,
            blockstamp=...,
            rewards_to_distribute=to_distribute,
            operators_to_validators=frame_validators,
            log=log,
        )
    )

    assert dict(rewards_distribution) == expected_rewards_distribution_map
    assert distributed_rewards == expected_distributed_rewards
    assert rebate_to_protocol == expected_rebate_to_protocol
    assert strikes_in_frame == expected_frame_strikes
    assert log == expected_log


@pytest.mark.parametrize(
    "att_perf, prop_perf, sync_perf, expected",
    [
        (1.0, 1.0, 1.0, 1.0),
        (0.0, 0.0, 0.0, 0.0),
        (0.5, 0.5, 0.5, 0.5),
        (0.9, None, 0.7, pytest.approx(0.8928, rel=1e-4)),
        (0.95, None, None, 0.95),
        (0.95, 0.5, None, pytest.approx(0.8919, rel=1e-4)),
        (0.95, None, 0.7, pytest.approx(0.9410, rel=1e-4)),
        (0.95, 0.5, 0.7, pytest.approx(0.8859, rel=1e-4)),
    ],
)
@pytest.mark.unit
def test_get_network_performance(att_perf, prop_perf, sync_perf, expected):
    distribution = Distribution(Mock(), Mock(), Mock())
    distribution.state.get_att_network_aggr = Mock(return_value=Mock(perf=att_perf) if att_perf is not None else None)
    distribution.state.get_prop_network_aggr = Mock(
        return_value=Mock(perf=prop_perf) if prop_perf is not None else None
    )
    distribution.state.get_sync_network_aggr = Mock(
        return_value=Mock(perf=sync_perf) if sync_perf is not None else None
    )
    frame = Mock(spec=Frame)

    result = distribution._get_network_performance(frame)

    assert result == expected


@pytest.mark.unit
def test_get_network_performance_raises_error_for_invalid_performance():
    distribution = Distribution(Mock(), Mock(), Mock())
    distribution.state.get_att_network_aggr = Mock(return_value=Mock(perf=1.1))
    distribution.state.get_prop_network_aggr = Mock(return_value=Mock(perf=1.0))
    distribution.state.get_sync_network_aggr = Mock(return_value=Mock(perf=1.0))
    frame = Mock(spec=Frame)

    with pytest.raises(ValueError, match="Invalid performance: performance"):
        distribution._get_network_performance(frame)


@pytest.mark.unit
def test_get_module_validators_raises_for_operator_module_address_mismatch():
    module_address = to_checksum_address("0x" + "11" * 20)
    wrong_module_address = to_checksum_address("0x" + "22" * 20)
    blockstamp = ReferenceBlockStampFactory.build()

    w3 = Mock(
        spec=Web3StakingModule,
        staking_module=Mock(spec=StakingModuleContracts, module=Mock(address=module_address)),
        kac=Mock(),
        cc=Mock(),
    )
    w3.kac.get_used_module_operators_keys.return_value = {
        "module": {"id": 1},
        "operators": [{"index": 1, "moduleAddress": wrong_module_address}],
        "keys": [],
    }

    distribution = Distribution(w3, converter=Mock(), state=Mock())

    with pytest.raises(KAPIInconsistentData, match="Invalid module address"):
        distribution._get_module_validators(blockstamp)


@pytest.mark.unit
def test_get_module_validators_raises_for_key_module_address_mismatch():
    module_address = to_checksum_address("0x" + "11" * 20)
    wrong_module_address = to_checksum_address("0x" + "22" * 20)
    blockstamp = ReferenceBlockStampFactory.build()
    validator = ValidatorFactory.build(validator=ValidatorStateFactory.build())
    key = LidoKeyFactory.build(
        key=validator.validator.pubkey,
        operator_index=NodeOperatorId(1),
        module_address=wrong_module_address,
    )

    w3 = Mock(
        spec=Web3StakingModule,
        staking_module=Mock(spec=StakingModuleContracts, module=Mock(address=module_address)),
        kac=Mock(),
        cc=Mock(),
    )
    w3.kac.get_used_module_operators_keys.return_value = {
        "module": {"id": 1},
        "operators": [{"index": 1, "moduleAddress": module_address}],
        "keys": [key],
    }
    w3.cc.get_validators.return_value = [validator]

    distribution = Distribution(w3, converter=Mock(), state=make_state())

    with pytest.raises(KAPIInconsistentData, match="Invalid key"):
        distribution._get_module_validators(blockstamp)


@pytest.mark.parametrize(
    "validator_duties, is_slashed, threshold, reward_share, expected_outcome",
    [
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=10, included=6),
                proposal=DutyAccumulator(assigned=10, included=6),
                sync=DutyAccumulator(assigned=10, included=6),
            ),
            False,
            0.5,
            1,
            ValidatorDutiesOutcome(participation_share=10 * 32, rebate_share=0, strikes=0),
        ),
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=10, included=5),
                proposal=DutyAccumulator(assigned=10, included=5),
                sync=DutyAccumulator(assigned=10, included=5),
            ),
            False,
            0.5,
            1,
            ValidatorDutiesOutcome(participation_share=10 * 32, rebate_share=0, strikes=0),
        ),
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=10, included=10),
                proposal=DutyAccumulator(assigned=10, included=10),
                sync=DutyAccumulator(assigned=10, included=10),
            ),
            False,
            0.5,
            0.85,
            ValidatorDutiesOutcome(participation_share=272, rebate_share=48, strikes=0),
        ),
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=3, included=3),
                proposal=DutyAccumulator(assigned=3, included=3),
                sync=DutyAccumulator(assigned=3, included=3),
            ),
            False,
            0.5,
            0.3,
            ValidatorDutiesOutcome(participation_share=29, rebate_share=67, strikes=0),
        ),
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=10, included=4),
                proposal=DutyAccumulator(assigned=10, included=4),
                sync=DutyAccumulator(assigned=10, included=4),
            ),
            False,
            0.5,
            1,
            ValidatorDutiesOutcome(participation_share=0, rebate_share=0, strikes=1),
        ),
        (
            ValidatorDuties(attestation=None, proposal=None, sync=None),
            False,
            0.5,
            1,
            ValidatorDutiesOutcome(participation_share=0, rebate_share=0, strikes=0),
        ),
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=1, included=1),
                proposal=DutyAccumulator(assigned=1, included=1),
                sync=DutyAccumulator(assigned=1, included=1),
            ),
            True,
            0.5,
            1,
            ValidatorDutiesOutcome(participation_share=0, rebate_share=0, strikes=1),
        ),
        (
            ValidatorDuties(
                attestation=DutyAccumulator(assigned=1, included=1),
                proposal=DutyAccumulator(assigned=1, included=1),
                sync=DutyAccumulator(assigned=1, included=1),
            ),
            True,
            0,
            1,
            ValidatorDutiesOutcome(participation_share=0, rebate_share=0, strikes=0),
        ),
    ],
)
@pytest.mark.unit
def test_process_validator_duty(validator_duties, is_slashed, threshold, reward_share, expected_outcome):
    validator = LidoValidatorFactory.build()
    validator.validator.slashed = is_slashed
    validator.validator.effective_balance = MIN_ACTIVATION_BALANCE
    log_operator = Mock()
    log_operator.validators = defaultdict(ValidatorFrameSummary)

    outcome = Distribution.get_validator_duties_outcome(
        validator,
        validator_duties,
        threshold,
        reward_share,
        PerformanceCoefficients(),
        log_operator,
    )

    assert outcome == expected_outcome
    if validator_duties.attestation and not is_slashed:
        assert log_operator.validators[validator.index].threshold == threshold
        assert log_operator.validators[validator.index].reward_share == reward_share
        if validator_duties.attestation:
            assert log_operator.validators[validator.index].attestation_duty == validator_duties.attestation
        if validator_duties.proposal:
            assert log_operator.validators[validator.index].proposal_duty == validator_duties.proposal
        if validator_duties.sync:
            assert log_operator.validators[validator.index].sync_duty == validator_duties.sync

    if not validator_duties.attestation:
        assert validator.index not in log_operator.validators

    assert log_operator.validators[validator.index].slashed is is_slashed


@pytest.mark.parametrize(
    "participation_shares, rewards_to_distribute, rebate_share, expected_distribution",
    [
        (
            {NodeOperatorId(1): {ValidatorIndex(0): 100}, NodeOperatorId(2): {ValidatorIndex(1): 200}},
            Wei(1 * 10**18),
            0,
            {NodeOperatorId(1): Wei(333333333333333333), NodeOperatorId(2): Wei(666666666666666666)},
        ),
        (
            {NodeOperatorId(1): {ValidatorIndex(0): 0}, NodeOperatorId(2): {ValidatorIndex(1): 0}},
            Wei(1 * 10**18),
            0,
            {},
        ),
        (
            {},
            Wei(1 * 10**18),
            0,
            {},
        ),
        (
            {NodeOperatorId(1): {ValidatorIndex(0): 100}, NodeOperatorId(2): {ValidatorIndex(1): 0}},
            Wei(1 * 10**18),
            0,
            {NodeOperatorId(1): Wei(1 * 10**18)},
        ),
        (
            {NodeOperatorId(1): {ValidatorIndex(0): 100}, NodeOperatorId(2): {ValidatorIndex(1): 200}},
            Wei(1 * 10**18),
            10,
            {NodeOperatorId(1): Wei(322580645161290322), NodeOperatorId(2): Wei(645161290322580645)},
        ),
    ],
)
@pytest.mark.unit
def test_calc_rewards_distribution_in_frame(
    participation_shares, rewards_to_distribute, rebate_share, expected_distribution
):
    log = FramePerfLog(ReferenceBlockStampFactory.build(), (EpochNumber(100), EpochNumber(500)))
    rewards_distribution = Distribution.calc_rewards_distribution_in_frame(
        participation_shares, rebate_share, rewards_to_distribute, log
    )
    assert rewards_distribution == expected_distribution


@pytest.mark.unit
def test_calc_rewards_distribution_in_frame_handles_negative_to_distribute():
    participation_shares = {NodeOperatorId(1): {ValidatorIndex(0): 100}, NodeOperatorId(2): {ValidatorIndex(1): 200}}
    rewards_to_distribute = Wei(-1)
    rebate_share = 0

    with pytest.raises(ValueError, match="Invalid rewards to distribute"):
        Distribution.calc_rewards_distribution_in_frame(
            participation_shares, rebate_share, rewards_to_distribute, log=Mock()
        )


@pytest.mark.parametrize(
    ("acc", "strikes_in_frame", "threshold_per_op", "expected"),
    [
        pytest.param({}, {}, {}, {}, id="empty_acc_empty_strikes_in_frame"),
        pytest.param(
            {},
            {
                (NodeOperatorId(42), b"00"): 3,
                (NodeOperatorId(17), b"01"): 1,
            },
            {
                NodeOperatorId(42): Mock(lifetime=6),
                NodeOperatorId(17): Mock(lifetime=4),
            },
            {
                (NodeOperatorId(42), b"00"): [3, 0, 0, 0, 0, 0],
                (NodeOperatorId(17), b"01"): [1, 0, 0, 0],
            },
            id="empty_acc_non_empty_strikes_in_frame",
        ),
        pytest.param(
            {
                (NodeOperatorId(42), b"00"): StrikesList([3, 0, 0, 0, 0, 0]),
                (NodeOperatorId(17), b"01"): StrikesList([1, 0, 0, 0]),
                (NodeOperatorId(17), b"02"): StrikesList([0, 0, 0, 1]),
            },
            {},
            {
                NodeOperatorId(42): Mock(lifetime=5),
                NodeOperatorId(17): Mock(lifetime=4),
            },
            {
                (NodeOperatorId(42), b"00"): [0, 3, 0, 0, 0],
                (NodeOperatorId(17), b"01"): [0, 1, 0, 0],
            },
            id="non_empty_acc_empty_strikes_in_frame",
        ),
        pytest.param(
            {
                (NodeOperatorId(42), b"00"): StrikesList([3, 0, 0, 0, 0, 0]),
                (NodeOperatorId(17), b"01"): StrikesList([1, 0, 0, 0]),
            },
            {
                (NodeOperatorId(42), b"00"): 2,
                (NodeOperatorId(18), b"02"): 1,
            },
            {
                NodeOperatorId(42): Mock(lifetime=5),
                NodeOperatorId(17): Mock(lifetime=4),
                NodeOperatorId(18): Mock(lifetime=6),
            },
            {
                (NodeOperatorId(42), b"00"): [2, 3, 0, 0, 0],
                (NodeOperatorId(17), b"01"): [0, 1, 0, 0],
                (NodeOperatorId(18), b"02"): [1, 0, 0, 0, 0, 0],
            },
            id="non_empty_acc_non_empty_strikes_in_frame",
        ),
    ],
)
@pytest.mark.unit
def test_merge_strikes(
    acc: dict,
    strikes_in_frame: dict,
    threshold_per_op: dict,
    expected: dict,
):
    distribution = Distribution(Mock(csm=Mock()), Mock(), Mock())
    distribution.w3.staking_module.get_curve_params = Mock(
        side_effect=lambda no_id, _: Mock(strikes_params=threshold_per_op[no_id])
    )

    result = distribution._process_strikes(acc, strikes_in_frame, frame_blockstamp=Mock())

    assert result == expected


@pytest.mark.parametrize(
    "total_distributed_rewards, total_rebate, total_rewards_to_distribute",
    [
        (100, 50, 150),
        (0, 0, 0),
        (50, 50, 100),
        # Nothing distributed, all rewards rebated to the protocol
        (0, 100, 100),
        # All distributed to operators, nothing rebated
        (100, 0, 100),
    ],
)
@pytest.mark.unit
def tests_validates_correct_distribution(total_distributed_rewards, total_rebate, total_rewards_to_distribute):
    Distribution.validate_distribution(total_distributed_rewards, total_rebate, total_rewards_to_distribute)


@pytest.mark.parametrize(
    "total_distributed_rewards, total_rebate, total_rewards_to_distribute",
    [
        (100, 51, 150),
        (200, 0, 199),
        # Nothing distributed or rebated while there are rewards to distribute
        (0, 0, 100),
    ],
)
@pytest.mark.unit
def test_raises_error_for_invalid_distribution(total_distributed_rewards, total_rebate, total_rewards_to_distribute):
    with pytest.raises(ValueError, match="Invalid distribution"):
        Distribution.validate_distribution(total_distributed_rewards, total_rebate, total_rewards_to_distribute)


@pytest.mark.unit
def test_validate_distribution_raises_when_nothing_distributed_or_rebated():
    with pytest.raises(ValueError, match="nothing was distributed or rebated"):
        Distribution.validate_distribution(0, 0, 100)


@pytest.mark.parametrize(
    "attestation_perf, proposal_perf, sync_perf, expected",
    [
        (0.95, None, None, 0.95),
        (0.95, 0.5, None, pytest.approx(0.8919, rel=1e-4)),
        (0.95, None, 0.7, pytest.approx(0.9410, rel=1e-4)),
        (0.95, 0.5, 0.7, pytest.approx(0.8859, rel=1e-4)),
        (1, 1, 1, 1),
    ],
)
@pytest.mark.unit
def test_performance_coefficients_calc_performance(attestation_perf, proposal_perf, sync_perf, expected):
    performance_coefficients = PerformanceCoefficients()
    duties = ValidatorDuties(
        attestation=Mock(perf=attestation_perf),
        proposal=Mock(perf=proposal_perf) if proposal_perf is not None else None,
        sync=Mock(perf=sync_perf) if sync_perf is not None else None,
    )
    assert performance_coefficients.calc_performance(duties) == expected


@pytest.mark.parametrize(
    "intervals, key_index, expected",
    [
        ([KeyNumberValueInterval(1, 10000)], 100500, 10000 / TOTAL_BASIS_POINTS),
        ([KeyNumberValueInterval(1, 10000), KeyNumberValueInterval(2, 9000)], 1, 10000 / TOTAL_BASIS_POINTS),
        ([KeyNumberValueInterval(1, 10000), KeyNumberValueInterval(2, 9000)], 2, 9000 / TOTAL_BASIS_POINTS),
        (
            [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(11, 2000), KeyNumberValueInterval(21, 3000)],
            4,
            1000 / TOTAL_BASIS_POINTS,
        ),
        (
            [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(11, 2000), KeyNumberValueInterval(21, 3000)],
            9,
            1000 / TOTAL_BASIS_POINTS,
        ),
        (
            [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(11, 2000), KeyNumberValueInterval(21, 3000)],
            14,
            2000 / TOTAL_BASIS_POINTS,
        ),
        (
            [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(11, 2000), KeyNumberValueInterval(21, 3000)],
            19,
            2000 / TOTAL_BASIS_POINTS,
        ),
        (
            [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(11, 2000), KeyNumberValueInterval(21, 3000)],
            24,
            3000 / TOTAL_BASIS_POINTS,
        ),
    ],
)
@pytest.mark.unit
def test_interval_mapping_returns_correct_reward_share(intervals, key_index, expected):
    reward_share = KeyNumberValueIntervalList(intervals)
    assert reward_share.get_for(key_index) == expected


@pytest.mark.unit
def test_interval_mapping_raises_error_for_invalid_key_number():
    reward_share = KeyNumberValueIntervalList(
        [KeyNumberValueInterval(1, 1000), KeyNumberValueInterval(11, 2000), KeyNumberValueInterval(21, 3000)]
    )
    with pytest.raises(ValueError, match="Key number should be greater than 1 or equal"):
        reward_share.get_for(-1)


@pytest.mark.unit
def test_interval_mapping_raises_error_for_key_number_out_of_range():
    reward_share = KeyNumberValueIntervalList([KeyNumberValueInterval(11, 10000)])
    with pytest.raises(ValueError, match="No value found for key number=2"):
        reward_share.get_for(2)


@pytest.mark.parametrize("multiplier", [1, 2, 3, 64])
@pytest.mark.unit
def test_get_validator_duties_outcome_scales_by_effective_balance(multiplier: int):
    validator = LidoValidatorFactory.build()
    validator.validator.slashed = False
    validator.validator.effective_balance = MIN_ACTIVATION_BALANCE * multiplier

    duties = ValidatorDuties(
        attestation=DutyAccumulator(assigned=10, included=10),
        proposal=None,
        sync=None,
    )

    threshold = 0.0
    reward_share = 0.5
    log_operator = Mock()
    log_operator.validators = defaultdict(ValidatorFrameSummary)

    outcome = Distribution.get_validator_duties_outcome(
        validator,
        duties,
        threshold,
        reward_share,
        PerformanceCoefficients(),
        log_operator,
    )

    expected_assigned = 10 * MIN_ACTIVATION_BALANCE * multiplier // EFFECTIVE_BALANCE_INCREMENT
    expected_participation = math.ceil(expected_assigned * reward_share)
    expected_rebate = expected_assigned - expected_participation
    expected_participation_share_multiplier = MIN_ACTIVATION_BALANCE * multiplier // EFFECTIVE_BALANCE_INCREMENT

    assert outcome == ValidatorDutiesOutcome(
        participation_share=expected_participation,
        rebate_share=expected_rebate,
        strikes=0,
    )
    assert log_operator.validators[validator.index] == ValidatorFrameSummary(
        distributed_rewards=0,
        performance=1.0,
        threshold=threshold,
        reward_share=reward_share,
        participation_share_multiplier=expected_participation_share_multiplier,
        slashed=False,
        strikes=0,
        attestation_duty=DutyAccumulator(assigned=10, included=10),
        proposal_duty=DutyAccumulator(),
        sync_duty=DutyAccumulator(),
    )


@pytest.mark.unit
def test_calculate_distribution_in_frame_assigns_keys_by_sorted_order():
    w3 = Mock(spec=Web3StakingModule, staking_module=Mock())
    reward_share_data = Mock()
    reward_share_data.get_for = Mock(side_effect=lambda k: {1: 1.0, 2: 0.9, 3: 0.8, 4: 0.7, 5: 0.6, 6: 0.5}[k])
    w3.staking_module.get_curve_params = Mock(
        return_value=CurveParams(
            strikes_params=...,
            perf_leeway_data=Mock(get_for=Mock(return_value=0.0)),
            reward_share_data=reward_share_data,
            perf_coeffs=PerformanceCoefficients(attestations_weight=1, blocks_weight=0, sync_weight=0),
        )
    )

    distribution = Distribution(w3, converter=..., state=make_state())
    distribution._get_network_performance = Mock(return_value=0.9)

    frame = (EpochNumber(0), EpochNumber(31))
    blockstamp = ReferenceBlockStampFactory.build(ref_epoch=31)
    log = FramePerfLog(blockstamp, frame)

    # Three validators with different indices and balances; final order expected by index asc
    v_idx5 = LidoValidatorFactory.build(index=ValidatorIndex(5))
    v_idx7 = LidoValidatorFactory.build(index=ValidatorIndex(7))
    v_idx8 = LidoValidatorFactory.build(index=ValidatorIndex(8))
    v_idx9 = LidoValidatorFactory.build(index=ValidatorIndex(9))
    v_idx10 = LidoValidatorFactory.build(index=ValidatorIndex(10))
    v_idx6 = LidoValidatorFactory.build(index=ValidatorIndex(6))
    v_idx5.validator.slashed = False
    v_idx7.validator.slashed = False
    v_idx8.validator.slashed = False
    v_idx9.validator.slashed = False
    v_idx10.validator.slashed = False
    v_idx6.validator.slashed = False

    v_idx5.validator.effective_balance = MIN_ACTIVATION_BALANCE
    v_idx7.validator.effective_balance = MIN_ACTIVATION_BALANCE * 3
    v_idx8.validator.effective_balance = MIN_ACTIVATION_BALANCE * 2
    v_idx10.validator.effective_balance = MIN_ACTIVATION_BALANCE * 2
    v_idx9.validator.effective_balance = MIN_ACTIVATION_BALANCE * 64
    v_idx6.validator.effective_balance = MIN_ACTIVATION_BALANCE * 64

    # Same perfect duties for all
    distribution.state.data = {
        frame: NetworkDuties(
            attestations=defaultdict(
                DutyAccumulator,
                {
                    v_idx5.index: DutyAccumulator(assigned=10, included=10),
                    v_idx7.index: DutyAccumulator(assigned=10, included=10),
                    v_idx8.index: DutyAccumulator(assigned=10, included=10),
                    v_idx9.index: DutyAccumulator(assigned=10, included=10),
                    v_idx10.index: DutyAccumulator(assigned=10, included=10),
                    v_idx6.index: DutyAccumulator(assigned=10, included=10),
                },
            ),
            proposals=defaultdict(DutyAccumulator),
            syncs=defaultdict(DutyAccumulator),
        )
    }

    operators_to_validators = {
        NodeOperatorId(1): [v_idx10, v_idx7, v_idx5, v_idx8, v_idx9, v_idx6],
    }

    distribution._calculate_distribution_in_frame(frame, blockstamp, Wei(300), operators_to_validators, log)

    assert log.operators[NodeOperatorId(1)].validators[ValidatorIndex(6)].reward_share == 1.0
    assert log.operators[NodeOperatorId(1)].validators[ValidatorIndex(9)].reward_share == 0.9
    assert log.operators[NodeOperatorId(1)].validators[ValidatorIndex(7)].reward_share == 0.8
    assert log.operators[NodeOperatorId(1)].validators[ValidatorIndex(8)].reward_share == 0.7
    assert log.operators[NodeOperatorId(1)].validators[ValidatorIndex(10)].reward_share == 0.6
    assert log.operators[NodeOperatorId(1)].validators[ValidatorIndex(5)].reward_share == 0.5
