import logging
import math
from collections.abc import Sequence
from typing import cast

from eth_typing import HexStr
from web3.contract.contract import ContractEvent
from web3.types import EventData, Wei

from src.constants import EFFECTIVE_BALANCE_INCREMENT, LIDO_DEPOSIT_AMOUNT
from src.modules.common.types import ChainConfig, FrameConfig
from src.providers.consensus.types import Validator
from src.providers.keys.types import LidoKey
from src.services.bunker_cases.types import BunkerConfig
from src.types import BlockNumber, BlockStamp, EpochNumber, Gwei, ReferenceBlockStamp, SlotNumber
from src.utils.events import get_events_in_range
from src.utils.slot import get_blockstamp, get_reference_blockstamp
from src.utils.types import hex_str_to_bytes
from src.utils.units import wei_to_gwei
from src.utils.validator_state import calculate_active_effective_balance_sum
from src.utils.web3converter import Web3Converter
from src.web3py.extensions.lido_validators import LidoValidator, LidoValidatorsProvider
from src.web3py.types import Web3


logger = logging.getLogger(__name__)

_LIDO_V4 = 4  # Lido contract version that introduced getBalanceStats / EIP-7251 top-up support


class AbnormalClRebase:
    all_validators: list[Validator]
    lido_validators: list[LidoValidator]
    lido_keys: list[LidoKey]

    def __init__(self, w3: Web3, c_conf: ChainConfig, b_conf: BunkerConfig, frame_config: FrameConfig):
        self.w3 = w3
        self.c_conf = c_conf
        self.b_conf = b_conf
        self._web3_converter = Web3Converter(c_conf, frame_config)

    def is_abnormal_cl_rebase(
        self,
        blockstamp: ReferenceBlockStamp,
        all_validators: list[Validator],
        lido_validators: list[LidoValidator],
        current_report_cl_rebase: Gwei,
    ) -> bool:
        """
        First of all, we should calculate the normal CL rebase for this report
        If diff between current CL rebase and normal CL rebase is more than
        `normalized_cl_reward_mistake_rate`,
        then we should check the intraframe sampled CL rebase: we consider two points (nearest and distant slots)
        in frame and calculate CL rebase for each of them and if one of them is negative, then it is abnormal CL rebase.

        `normalized_cl_reward_mistake_rate`,
        `rebase_check_nearest_epoch_distance` and
        `rebase_check_distant_epoch_distance`
        are configurable parameters, which can change behavior of this check.
        Like, don't check intraframe sampled CL rebase and look only on normal CL rebase
        """
        self.all_validators = all_validators
        self.lido_validators = lido_validators
        self.lido_keys = self.w3.kac.get_used_lido_keys(blockstamp)

        logger.info({"msg": "Checking abnormal CL rebase"})

        normal_report_cl_rebase = self._calculate_lido_normal_cl_rebase(blockstamp)

        # If there were no cl balance, no need to check changes
        if normal_report_cl_rebase == 0:
            return False

        diff_current_with_normal = 1 - current_report_cl_rebase / normal_report_cl_rebase

        if diff_current_with_normal > self.b_conf.normalized_cl_reward_mistake_rate:
            logger.info({"msg": "CL rebase in frame is abnormal"})

            no_need_intraframe_sampled_cl_rebase_check = (
                self.b_conf.rebase_check_nearest_epoch_distance == 0
                and self.b_conf.rebase_check_distant_epoch_distance == 0
            )
            if no_need_intraframe_sampled_cl_rebase_check:
                logger.info({"msg": "Intraframe sampled CL rebase calculation are disabled. Cl rebase is abnormal"})
                return True

            if self._is_negative_specific_cl_rebase(blockstamp):
                return True

        return False

    def _calculate_lido_normal_cl_rebase(self, blockstamp: ReferenceBlockStamp) -> Gwei:
        """
        Calculate normal CL rebase for Lido validators (relative to all validators and the previous Lido frame)
        for current frame for Lido validators
        """
        last_report_blockstamp = self._get_last_report_reference_blockstamp(blockstamp)

        epochs_passed_since_last_report = blockstamp.ref_epoch - last_report_blockstamp.ref_epoch

        last_report_all_validators = self.w3.cc.get_validators_no_cache(last_report_blockstamp)
        last_report_lido_validators = LidoValidatorsProvider.compute_lido_validators(
            self.lido_keys, last_report_all_validators
        )[0]

        # Calculate mean sum of effective balance for all validators and Lido validators (ACTIVE only)
        mean_sum_of_all_effective_balance = AbnormalClRebase.get_mean_sum_of_effective_balance(
            last_report_blockstamp, blockstamp, last_report_all_validators, self.all_validators
        )
        mean_sum_of_lido_effective_balance = AbnormalClRebase.get_mean_sum_of_effective_balance(
            last_report_blockstamp, blockstamp, last_report_lido_validators, self.lido_validators
        )

        normal_cl_rebase = AbnormalClRebase.calculate_normal_cl_rebase(
            self.b_conf,
            mean_sum_of_all_effective_balance,
            mean_sum_of_lido_effective_balance,
            epochs_passed_since_last_report,
        )

        logger.info({"msg": f"Normal CL rebase: {normal_cl_rebase} Gwei"})
        return Gwei(normal_cl_rebase)

    def _is_negative_specific_cl_rebase(self, blockstamp: ReferenceBlockStamp) -> bool:
        """
        Calculate CL rebase from nearest and distant epochs to ref epoch given the changes in withdrawal vault
        """
        logger.info({"msg": "Calculating nearest and distant CL rebase"})

        nearest_blockstamp, distant_blockstamp = self._get_nearest_and_distant_blockstamps(blockstamp)

        # dict preserves insertion order and deduplicates by block_number
        for bs in {
            nearest_blockstamp.block_number: nearest_blockstamp,
            distant_blockstamp.block_number: distant_blockstamp,
        }.values():
            rebase = self._calculate_cl_rebase_between_blocks(bs, blockstamp)
            logger.info({"msg": f"Intraframe sampled CL rebase: {rebase} Gwei"})
            if rebase < 0:
                return True

        return False

    def _get_nearest_and_distant_blockstamps(
        self, ref_blockstamp: ReferenceBlockStamp
    ) -> tuple[BlockStamp, BlockStamp]:
        """Get nearest and distant blockstamps by given reference blockstamp"""
        nearest_slot = SlotNumber(
            ref_blockstamp.ref_slot - self.b_conf.rebase_check_nearest_epoch_distance * self.c_conf.slots_per_epoch
        )
        distant_slot = SlotNumber(
            ref_blockstamp.ref_slot - self.b_conf.rebase_check_distant_epoch_distance * self.c_conf.slots_per_epoch
        )

        AbnormalClRebase.validate_slot_distance(distant_slot, nearest_slot, ref_blockstamp.slot_number)

        nearest_blockstamp = get_blockstamp(
            self.w3.cc, nearest_slot, last_finalized_slot_number=ref_blockstamp.slot_number
        )
        distant_blockstamp = get_blockstamp(
            self.w3.cc, distant_slot, last_finalized_slot_number=ref_blockstamp.slot_number
        )

        return nearest_blockstamp, distant_blockstamp

    def _validate_prev_slot_within_ref_frame(self, prev_slot: SlotNumber, ref_slot: SlotNumber) -> None:
        """prev_slot (nearest or distant blockstamp's resolved slot) must stay within the same reporting
        frame as ref_slot: _calculate_injected_capital's deposit accounting assumes at most one report can
        settle between prev_slot and ref_slot, which no longer holds once prev_slot reaches back into an
        already-processed frame.
        """
        frame_first_slot = self._web3_converter.get_frame_first_slot(self._web3_converter.get_frame_by_slot(ref_slot))
        if prev_slot < frame_first_slot:
            raise ValueError(
                f"{prev_slot=} is before the start of the current reporting frame ({frame_first_slot=}) "
                f"for {ref_slot=} — rebase_check_nearest_epoch_distance/rebase_check_distant_epoch_distance "
                "is too large"
            )

    def _calculate_cl_rebase_between_blocks(
        self, prev_blockstamp: BlockStamp, ref_blockstamp: ReferenceBlockStamp
    ) -> Gwei:
        """
        Calculate CL rebase from prev_blockstamp to ref_blockstamp.
        Skimmed validator rewards are sent to 0x01 withdrawal credentials address
        which in Lido case is WithdrawalVault contract.
        To account for all changes in validators' balances, we must account
        withdrawn events from WithdrawalVault contract.
        Check for these events is enough to account for all withdrawals since the protocol assumes that
        the vault can only be withdrawn at the time of the Oracle report between reference slots.
        """
        if prev_blockstamp.block_number == ref_blockstamp.block_number:
            # Can't calculate rebase between the same block
            return Gwei(0)

        (prev_lido_validators, _) = LidoValidatorsProvider.compute_lido_validators(
            self.lido_keys,
            self.w3.cc.get_validators_no_cache(prev_blockstamp),
        )

        ref_balance_with_vault = self._get_lido_validators_balance_with_vault(ref_blockstamp, self.lido_validators)

        prev_balance_with_vault = self._get_lido_validators_balance_with_vault(prev_blockstamp, prev_lido_validators)

        # Raw CL rebase is calculated as the difference between reference and previous Lido validators' balances
        # Without accounting for withdrawals from WithdrawalVault
        raw_cl_rebase = ref_balance_with_vault - prev_balance_with_vault

        # And withdrawals from WithdrawalVault
        withdrawn_from_vault = self._get_withdrawn_from_vault_between_blocks(prev_blockstamp, ref_blockstamp)

        # Capital injected via deposits: new validators (pre-v4)
        # or new validators + top-ups (post-v4)
        injected_capital = self._calculate_injected_capital(prev_blockstamp, ref_blockstamp, prev_lido_validators)

        # Finally, we can calculate a corrected CL rebase
        cl_rebase = Gwei(raw_cl_rebase - injected_capital + withdrawn_from_vault)

        logger.info(
            {
                "msg": (
                    "CL rebase between "
                    f"{prev_blockstamp.block_number, ref_blockstamp.block_number} "
                    f"blocks: {cl_rebase} Gwei"
                )
            }
        )

        return cl_rebase

    def _get_lido_validators_balance_with_vault(
        self,
        blockstamp: BlockStamp,
        lido_validators: Sequence[LidoValidator],
    ) -> Gwei:
        """
        Get Lido validator balance with withdrawals vault balance
        """
        real_cl_balance = AbnormalClRebase.calculate_validators_balance_sum(lido_validators)
        withdrawals_vault_balance = wei_to_gwei(self.w3.lido_contracts.get_withdrawal_balance_no_cache(blockstamp))
        total_balance = real_cl_balance + withdrawals_vault_balance
        return Gwei(total_balance)

    def _get_withdrawn_from_vault_between_blocks(
        self, prev_blockstamp: BlockStamp, ref_blockstamp: ReferenceBlockStamp
    ) -> Gwei:
        """
        Lookup for ETHDistributed event and expect no one or only one event,
        from which we'll get withdrawalsWithdrawn value
        """

        logger.info(
            {
                "msg": (
                    "Get withdrawn from vault between "
                    f"{prev_blockstamp.block_number, ref_blockstamp.block_number} "
                    "blocks"
                )
            }
        )

        events = self._get_eth_distributed_events(
            # We added +1 to prev block number because withdrawals from vault
            # are already counted in balance state on prev block number
            from_block=BlockNumber(prev_blockstamp.block_number + 1),
            to_block=BlockNumber(ref_blockstamp.block_number),
        )

        if len(events) > 1:
            raise ValueError("More than one ETHDistributed event found")

        if not events:
            logger.info({"msg": "No ETHDistributed event found. Vault withdrawals: 0 Gwei."})
            return Gwei(0)

        vault_withdrawals = wei_to_gwei(events[0]['args']['withdrawalsWithdrawn'])
        logger.info({"msg": f"Vault withdrawals: {vault_withdrawals} Gwei"})

        return vault_withdrawals

    def _get_eth_distributed_events(self, from_block: BlockNumber, to_block: BlockNumber) -> list[EventData]:
        """Get ETHDistributed events between blocks"""
        return list(
            get_events_in_range(
                cast(ContractEvent, self.w3.lido_contracts.lido.events.ETHDistributed),
                from_block,
                to_block,
            )
        )

    def _calculate_injected_capital(
        self,
        prev_blockstamp: BlockStamp,
        ref_blockstamp: ReferenceBlockStamp,
        prev_lido_validators: list[LidoValidator],
    ) -> Gwei:
        """How much ETH entered Lido validators' balances via deposits in [prev, ref].

        Pre-v4: only new validators, counted as 32 ETH each.
        Post-v4 (EIP-7251): new validators + top-ups to existing ones.
        """
        last_report_blockstamp = self._get_last_report_reference_blockstamp(ref_blockstamp)

        if self.w3.lido_contracts.lido.get_contract_version(last_report_blockstamp.block_number) < _LIDO_V4:
            return AbnormalClRebase.calculate_validators_count_diff_in_gwei(prev_lido_validators, self.lido_validators)

        self._validate_prev_slot_within_ref_frame(prev_blockstamp.slot_number, ref_blockstamp.ref_slot)

        lido_pubkeys = {key.key for key in self.lido_keys}
        lido_wc_list = self.w3.lido_validators.get_lido_wc_list(ref_blockstamp)
        genesis_fork_version = hex_str_to_bytes(self.w3.cc.get_genesis().genesis_fork_version)

        prev_pubkeys = {v.validator.pubkey for v in prev_lido_validators}
        ref_pubkeys = {v.validator.pubkey for v in self.lido_validators}

        old_pending = self._sum_valid_lido_pending(
            blockstamp=prev_blockstamp,
            lido_pubkeys=lido_pubkeys,
            existing_pubkeys=prev_pubkeys,
            lido_wc_list=lido_wc_list,
            genesis_fork_version=genesis_fork_version,
        )
        ref_balance_stats = self.w3.lido_contracts.lido.get_balance_stats(ref_blockstamp.block_hash)
        prev_balance_stats = self.w3.lido_contracts.lido.get_balance_stats(prev_blockstamp.block_hash)
        # deposited_since_last_report - deposited_for_current_report ("depositedNextReport") only resets
        # on a frame rollover, never on a report settling, so applying it at both ends and diffing gives
        # deposits in [prev, ref] regardless of how many reports settled in between — as long as prev and
        # ref share the same frame (see _validate_prev_slot_within_ref_frame).
        ref_deposited_in_frame = (
            ref_balance_stats.deposited_since_last_report - ref_balance_stats.deposited_for_current_report
        )
        prev_deposited_in_frame = (
            prev_balance_stats.deposited_since_last_report - prev_balance_stats.deposited_for_current_report
        )
        deposited_in_window = wei_to_gwei(Wei(ref_deposited_in_frame - prev_deposited_in_frame))

        current_pending = self._sum_valid_lido_pending(
            blockstamp=ref_blockstamp,
            lido_pubkeys=lido_pubkeys,
            existing_pubkeys=ref_pubkeys,
            lido_wc_list=lido_wc_list,
            genesis_fork_version=genesis_fork_version,
        )

        return Gwei(deposited_in_window + old_pending - current_pending)

    def _sum_valid_lido_pending(
        self,
        blockstamp: BlockStamp,
        lido_pubkeys: set[HexStr],
        existing_pubkeys: set[str],
        lido_wc_list: list[HexStr],
        genesis_fork_version: bytes,
    ) -> Gwei:
        """Sum pending deposits for Lido keys at blockstamp.

        Existing validators: count all their top-ups unconditionally (Lido owns them).
        New/pending validators: use shared frontrun-detection logic from
        _collect_valid_pending_deposits — only count keys whose first valid-signature
        deposit has Lido withdrawal credentials.
        """
        pending_deposits = self.w3.cc.get_pending_deposits(blockstamp)
        total = Gwei(0)

        for d in pending_deposits:
            if d.pubkey in existing_pubkeys:
                total = Gwei(total + d.amount)

        valid = LidoValidatorsProvider._collect_valid_pending_deposits(
            pending_deposits,
            filter_pubkeys=cast(set[str], lido_pubkeys) - existing_pubkeys,
            lido_wc_list=lido_wc_list,
            genesis_fork_version=genesis_fork_version,
        )
        for deposits in valid.values():
            total = Gwei(total + sum(d.amount for d in deposits))

        return total

    def _get_last_report_reference_blockstamp(self, ref_blockstamp: ReferenceBlockStamp) -> ReferenceBlockStamp:
        """Get blockstamp of last report"""
        last_report_ref_slot = self.w3.lido_contracts.get_accounting_last_processing_ref_slot(ref_blockstamp)
        return get_reference_blockstamp(
            self.w3.cc,
            last_report_ref_slot,
            ref_epoch=EpochNumber(last_report_ref_slot // self.c_conf.slots_per_epoch),
            last_finalized_slot_number=ref_blockstamp.slot_number,
        )

    @staticmethod
    def calculate_validators_count_diff_in_gwei(
        prev_validators: Sequence[Validator],
        ref_validators: Sequence[Validator],
    ) -> Gwei:
        """
        Handle 32 ETH balances of freshly baked validators, who appeared between epochs
        Lido validators are counted by public keys that the protocol deposited with 32 ETH,
        so we can safely count the differences in the number of validators when they occur by deposit size.
        Any pre-deposits to Lido keys will not be counted until the key is deposited through the protocol
        and goes into `used` state
        """
        validators_diff = len(ref_validators) - len(prev_validators)
        if validators_diff < 0:
            raise ValueError("Validators count diff should be positive or 0. Something went wrong with CL API")
        return Gwei(validators_diff * LIDO_DEPOSIT_AMOUNT)

    @staticmethod
    def get_mean_sum_of_effective_balance(
        last_report_blockstamp: ReferenceBlockStamp,
        ref_blockstamp: ReferenceBlockStamp,
        last_report_validators: Sequence[Validator],
        ref_validators: Sequence[Validator],
    ) -> Gwei:
        """
        Calculate mean of effective balance sums
        """
        last_report_effective_balance_sum = calculate_active_effective_balance_sum(
            last_report_validators, last_report_blockstamp.ref_epoch
        )
        ref_effective_balance_sum = calculate_active_effective_balance_sum(ref_validators, ref_blockstamp.ref_epoch)
        return Gwei((ref_effective_balance_sum + last_report_effective_balance_sum) // 2)

    @staticmethod
    def validate_slot_distance(distant_slot: SlotNumber, nearest_slot: SlotNumber, ref_slot: SlotNumber):
        if distant_slot <= nearest_slot <= ref_slot:
            return
        raise ValueError(
            f"{nearest_slot=} should be between {distant_slot=} and {ref_slot=} in specific CL rebase calculation"
        )

    @staticmethod
    def calculate_validators_balance_sum(validators: Sequence[Validator]) -> Gwei:
        return sum((v.balance for v in validators), Gwei(0))

    @staticmethod
    def calculate_normal_cl_rebase(
        bunker_config: BunkerConfig,
        mean_sum_of_all_effective_balance: Gwei,
        mean_sum_of_lido_effective_balance: Gwei,
        epochs_passed: int,
    ) -> Gwei:
        """
        Calculate normal CL rebase for particular effective balance

        Actual value of `normal_cl_rebase` is a random variable with embedded variance for four reasons:
         * Calculating expected proposer rewards instead of actual - Randomness within specification
         * Calculating expected sync committee rewards instead of actual  - Randomness within specification
         * Instead of using data on active validators for each epoch
          estimation on number of active validators through interception of
          active validators between current oracle report epoch and last one - Randomness within measurement algorithm
         * Not absolutely ideal performance of Lido Validators and network as a whole  - Randomness of real world
        If the difference between observed real CL rewards and its theoretical
        value (normal_cl_rebase) couldn't be explained by
        those 4 factors means there is an additional factor leading to lower
        rewards, i.e. incidents within Lido or BeaconChain.
        To formalize “high enough” difference we’re suggesting `normalized_cl_reward_per_epoch` constant
        represent ethereum specification and equals to `BASE_REWARD_FACTOR` constant
        """
        # It should be at least 1 ETH to avoid division by zero
        mean_sum_of_all_effective_balance = max(Gwei(EFFECTIVE_BALANCE_INCREMENT), mean_sum_of_all_effective_balance)
        normal_cl_rebase = int(
            (bunker_config.normalized_cl_reward_per_epoch * mean_sum_of_lido_effective_balance * epochs_passed)
            / math.sqrt(mean_sum_of_all_effective_balance)
        )
        return Gwei(normal_cl_rebase)
