import functools
from collections.abc import Callable, Sequence
from dataclasses import dataclass, fields, is_dataclass
from types import GenericAlias
from typing import Self

from src.types import (
    BlockNumber,
    CommitteeIndex,
    EpochNumber,
    Gwei,
    SlotNumber,
    Timestamp,
    ValidatorIndex,
)
from src.utils.abi import named_tuple_to_dataclass


class DecodeToDataclassException(Exception):
    pass


@dataclass
class Nested:
    """
    Base class for dataclasses that converts all inner dicts into dataclasses
    Also works with lists of dataclasses
    """

    def __post_init__(self):
        for field in fields(self):
            if isinstance(field.type, GenericAlias):
                field_type = field.type.__args__[0]
                if is_dataclass(field_type):
                    factory = self.__get_dataclass_factory(field_type)

                    setattr(
                        self,
                        field.name,
                        field.type.__origin__(
                            map(  # type: ignore[misc]
                                lambda x: self._transform(factory, x),
                                getattr(self, field.name),
                            )
                        ),
                    )
                elif self.__is_numberish_type(field_type):
                    setattr(self, field.name, field.type.__origin__(int(v) for v in getattr(self, field.name)))  # type: ignore[misc]
            elif is_dataclass(field.type) and not is_dataclass(getattr(self, field.name)):
                factory = self.__get_dataclass_factory(field.type)
                setattr(self, field.name, factory(**getattr(self, field.name)))
            elif self.__is_numberish_type(field.type):
                setattr(self, field.name, int(getattr(self, field.name)))

    @staticmethod
    def __get_dataclass_factory(field_type):
        if issubclass(field_type, FromResponse):
            return field_type.from_response
        return field_type

    @staticmethod
    def __is_numberish_type(field_type):
        return field_type in (
            int,
            Gwei,
            BlockNumber,
            SlotNumber,
            EpochNumber,
            Timestamp,
            ValidatorIndex,
            CommitteeIndex,
        )

    @staticmethod
    def _transform(factory, x):
        """
        Tries to cast x to factory (some dataclass) type.
        """
        if is_dataclass(x):
            return x

        # Check if x is a namedtuple
        if hasattr(x, "_asdict") and hasattr(x, "_fields"):
            return named_tuple_to_dataclass(x, factory)

        return factory(**x)


@dataclass
class FromResponse:
    """
    Class for extending dataclass with custom from_response method, ignored extra fields
    """

    @classmethod
    def from_response(cls, **kwargs) -> Self:
        class_field_names = [field.name for field in fields(cls)]
        return cls(**{k: v for k, v in kwargs.items() if k in class_field_names})


def list_of_dataclasses[T](
    _dataclass_factory: Callable[..., T],
) -> Callable[[Callable[..., Sequence]], Callable[..., list[T]]]:
    """Decorator to transform list of dicts from func response to list of dataclasses"""

    def decorator(func: Callable[..., Sequence]) -> Callable[..., list[T]]:
        @functools.wraps(func)
        def wrapper_decorator(*args, **kwargs):
            list_of_elements = func(*args, **kwargs)

            if not isinstance(list_of_elements, list) and not isinstance(list_of_elements, tuple):
                raise DecodeToDataclassException(f'Type {type(list_of_elements)} is not supported.')

            if not list_of_elements:
                return []

            if isinstance(list_of_elements[0], dict):
                return list(map(lambda x: _dataclass_factory(**x), list_of_elements))

            if isinstance(list_of_elements[0], tuple):
                return list(map(lambda x: named_tuple_to_dataclass(x, _dataclass_factory), list_of_elements))

            raise DecodeToDataclassException(f'Type {type(list_of_elements[0])} is not supported.')

        return wrapper_decorator

    return decorator
