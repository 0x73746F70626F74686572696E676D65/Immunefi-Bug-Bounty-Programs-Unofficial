class IncompatibleException(Exception):
    pass
