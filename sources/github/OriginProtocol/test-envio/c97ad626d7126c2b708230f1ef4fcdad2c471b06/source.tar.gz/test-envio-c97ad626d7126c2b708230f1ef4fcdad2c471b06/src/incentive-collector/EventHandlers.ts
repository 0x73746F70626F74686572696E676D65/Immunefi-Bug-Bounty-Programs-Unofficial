import { toNumber } from 'dnum';
import { createEffect, S } from 'envio';

import { getTokenByAddress } from '../utils/getToken';
import { ERC20 } from './generated';

const COLLECTOR_ADDRESS = '0x3bb354a1e0621f454c5d5ce98f6ea21a53bf2d7d';

const SUPPORTED_PRICES = [
  '1:USDC_USD',
  '1:ETH_USD',
  '1:USDT_USD',
  '1:OETH_1:ETH',
  '8453:ETH_USD',
  '8453:AERO_USD',
  '8453:OGN_USD',
  '8453:USDC_USD',
  '146:ETH_USD',
  '146:S_USD',
  '146:OS_146:S',
];

export const getTokenPrice = createEffect(
  {
    name: 'getTokenPrice',
    input: {
      address: S.string,
      chainId: S.number,
      blockNumber: S.number,
    },
    output: S.number,
    rateLimit: false,
    cache: true,
  },
  async ({ input }) => {
    const token = getTokenByAddress(input.address, input.chainId);
    if (
      token === undefined ||
      !SUPPORTED_PRICES.includes(`${input.chainId}:${token.symbol}_USD`)
    ) {
      return 0;
    }
    const res = await fetch('http://localhost:8080/v1/graphql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: `
query Price {
  OraclePrice(limit: 1, where: {block: {_gte: ${input.blockNumber}, _lte: ${input.blockNumber}}, pair: "${input.chainId}:${token.symbol}_USD"}) {
    block
    id
    timestamp
    value
    pair
    chain_id
  }
}
`,
    });
    const data = (await res.json()) as {
      data: { OraclePrice: { value: number }[] };
    };

    if (data.data.OraclePrice.length === 0) {
      return 0;
    }

    return data.data.OraclePrice[0].value;
  },
);

ERC20.Transfer.handler(
  async ({ event, context }) => {
    const token = getTokenByAddress(event.srcAddress, event.chainId);

    if (token === undefined) {
      return;
    }

    const tokenEntity = await context.Token.get(token.id);
    if (tokenEntity === undefined) {
      context.Token.set({
        id: token.id,
        address: event.srcAddress,
        symbol: token.symbol,
        decimals: token.decimals,
      });
    }

    const price = await context.effect(getTokenPrice, {
      address: event.srcAddress,
      chainId: event.chainId,
      blockNumber: event.block.number,
    });

    try {
      context.Transfer.set({
        id: `${event.chainId}_${event.block.number}_${event.logIndex}`,
        from: event.params.from,
        to: event.params.to,
        value: event.params.value,
        value_int: toNumber([event.params.value, token.decimals]),
        timestamp: event.block.timestamp,
        txHash: event.transaction.hash,
        token_id: token.id,
        price,
      });
    } catch (e) {
      context.log.error(`Error in Transfer handler: ${e}`);
    }
  },
  {
    wildcard: true,
    eventFilters: [{ to: COLLECTOR_ADDRESS }, { from: COLLECTOR_ADDRESS }],
  },
);
