export * from './views/CollateralsView';
