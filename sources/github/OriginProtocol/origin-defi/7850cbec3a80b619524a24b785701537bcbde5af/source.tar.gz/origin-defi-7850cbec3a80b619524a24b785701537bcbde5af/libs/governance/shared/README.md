# governance-shared

This library was generated with [Nx](https://nx.dev).
