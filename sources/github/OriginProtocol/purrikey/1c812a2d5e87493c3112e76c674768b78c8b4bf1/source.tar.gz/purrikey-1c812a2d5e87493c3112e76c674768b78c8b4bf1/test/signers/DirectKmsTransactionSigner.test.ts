import { GetPublicKeyCommand, KMSClient, SignCommand } from '@aws-sdk/client-kms';
import { mockClient } from 'aws-sdk-client-mock';
import { SigningKey, Transaction, computeAddress, hexlify, verifyMessage } from 'ethers';
import { DirectKmsTransactionSigner } from '../../src';
import { CURVE_N, HALF_N } from '../../src/utils/constants';
import { normaliseSignature } from '../../src/utils/signature';

const kmsMock = mockClient(KMSClient);
const TEST_PRIVATE_KEY = '0x0123456789012345678901234567890123456789012345678901234567890123';
const TEST_PUBLIC_KEY_HEX =
  '046655feed4d214c261e0a6b554395596f1f1476a77d999560e5a8df9b8a1a3515217e88dd05e938efdd71b2cce322bf01da96cd42087b236e8f5043157a9c068e';
const TEST_PUBLIC_KEY_DER_HEX = `3056301006072a8648ce3d020106052b8104000a034200${TEST_PUBLIC_KEY_HEX}`;

function signatureToDer(rHex: string, sHex: string): Buffer {
  const encodeInteger = (hexValue: string): Buffer => {
    let raw = Buffer.from(hexValue.slice(2), 'hex');

    while (raw.length > 1 && raw[0] === 0x00) {
      raw = raw.slice(1);
    }

    if ((raw[0] & 0x80) !== 0) {
      raw = Buffer.concat([Buffer.from([0x00]), raw]);
    }

    return Buffer.concat([Buffer.from([0x02, raw.length]), raw]);
  };

  const r = encodeInteger(rHex);
  const s = encodeInteger(sHex);
  const len = r.length + s.length;
  return Buffer.concat([Buffer.from([0x30, len]), r, s]);
}

describe('DirectKmsTransactionSigner', () => {
  const TEST_KEY_ID = 'test-key-id';
  const TEST_REGION = 'us-west-2';
  const knownHighS = '0xd97bfcd60a78716f381c12d97a9c22fa15df48510da977322eb5ba1add10ebb2';

  let signer: DirectKmsTransactionSigner;

  beforeEach(() => {
    kmsMock.reset();

    signer = new DirectKmsTransactionSigner(TEST_KEY_ID, null, TEST_REGION, false);

    const publicKey = Buffer.from(TEST_PUBLIC_KEY_DER_HEX, 'hex');

    kmsMock.on(GetPublicKeyCommand).resolves({
      PublicKey: publicKey,
      KeyId: TEST_KEY_ID,
    });

    const signingKey = new SigningKey(TEST_PRIVATE_KEY);
    kmsMock.on(SignCommand).callsFake((input: any) => {
      const digest = hexlify(input.Message);
      const sig = signingKey.sign(digest);

      return {
        Signature: signatureToDer(sig.r, sig.s),
        KeyId: TEST_KEY_ID,
      };
    });
  });

  describe('Basic functionality', () => {
    it('should initialize correctly with provided values', () => {
      expect((signer as any).kmsKeyId).toBe(TEST_KEY_ID);
      expect((signer as any).region).toBe(TEST_REGION);
      expect((signer as any).debug).toBe(false);
    });

    it('should return the correct address from KMS public key', async () => {
      const publicKey = Buffer.from(TEST_PUBLIC_KEY_HEX, 'hex');
      const expectedAddress = computeAddress(hexlify(publicKey));

      const address = await signer.getAddress();

      expect(address).toBe(expectedAddress);
      expect(kmsMock.calls()).toHaveLength(1);
    });

    it('should cache the address after first retrieval', async () => {
      const publicKey = Buffer.from(TEST_PUBLIC_KEY_HEX, 'hex');
      const expectedAddress = computeAddress(hexlify(publicKey));

      await signer.getAddress();
      kmsMock.resetHistory();

      const address = await signer.getAddress();

      expect(address).toBe(expectedAddress);
      expect(kmsMock.calls()).toHaveLength(0);
    });
  });

  describe('signature normalization', () => {
    it('should normalize signatures with s > HALF_N', () => {
      const r = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef';
      const s = knownHighS;
      const recoveryParam = 0;

      const normalized = normaliseSignature(r, s, undefined, recoveryParam);

      expect(BigInt(normalized.s) <= HALF_N).toBe(true);
      expect(normalized.v).toBe(28);

      const expectedS = CURVE_N - BigInt(knownHighS);
      expect(BigInt(normalized.s)).toBe(expectedS);
    });

    it('should not modify signatures that already have low-s values', () => {
      const r = '0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890';
      const lowS = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef';
      const recoveryParam = 1;

      const normalized = normaliseSignature(r, lowS, undefined, recoveryParam);

      expect(normalized.r).toBe(r);
      expect(normalized.s).toBe(lowS);
      expect(normalized.v).toBe(28);
    });
  });

  describe('Transaction handling', () => {
    it('should sign a message that recovers to signer address', async () => {
      const address = await signer.getAddress();
      const signature = await signer.signMessage('hello');
      const recovered = verifyMessage('hello', signature);

      expect(recovered).toBe(address);
    });

    it('should sign an EIP-1559 transaction with recoverable sender', async () => {
      const address = await signer.getAddress();
      const signed = await signer.signTransaction({
        to: '0x1234567890123456789012345678901234567890',
        nonce: 0,
        gasLimit: 21_000n,
        maxFeePerGas: 2_000_000_000n,
        maxPriorityFeePerGas: 1_000_000_000n,
        value: 0n,
        chainId: 1n,
        type: 2,
      });

      const parsed = Transaction.from(signed);
      expect(parsed.from).toBe(address);
      expect(parsed.serialized).toBe(signed);
    });

    it('should throw when no chainId is available', async () => {
      const tx = {
        to: '0x1234567890123456789012345678901234567890',
        data: '0x',
        gasLimit: 21000n,
      };

      await expect(signer.signTransaction(tx)).rejects.toThrow('Transaction missing chainId');
    });

    it('should broadcast signed transaction through provider', async () => {
      const address = await signer.getAddress();
      const mockResponse = { hash: '0x' + '11'.repeat(32) };
      const mockProvider = {
        broadcastTransaction: jest.fn().mockResolvedValue(mockResponse),
      } as any;

      const connectedSigner = signer.connect(mockProvider) as DirectKmsTransactionSigner;

      const response = await connectedSigner.sendTransaction({
        to: '0x1234567890123456789012345678901234567890',
        nonce: 0,
        gasLimit: 21_000n,
        maxFeePerGas: 2_000_000_000n,
        maxPriorityFeePerGas: 1_000_000_000n,
        value: 0n,
        chainId: 1n,
        type: 2,
      });

      expect(response).toBe(mockResponse);
      expect(mockProvider.broadcastTransaction).toHaveBeenCalledTimes(1);

      const [rawTx] = mockProvider.broadcastTransaction.mock.calls[0];
      const parsed = Transaction.from(rawTx);
      expect(parsed.from).toBe(address);
    });

    it('should return a new instance with the connected provider', () => {
      const mockProvider = {
        getNetwork: jest.fn(),
        getFeeData: jest.fn(),
        broadcastTransaction: jest.fn(),
      } as any;

      const connectedSigner = signer.connect(mockProvider);

      expect(connectedSigner).toBeInstanceOf(DirectKmsTransactionSigner);
      expect(connectedSigner).not.toBe(signer);
      expect((connectedSigner as any).provider).toBe(mockProvider);
    });
  });
});
