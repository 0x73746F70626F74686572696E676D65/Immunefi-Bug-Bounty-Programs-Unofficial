import { KMSClient, SignCommand } from '@aws-sdk/client-kms';
import {
  AbstractSigner,
  Provider,
  Signer,
  Signature,
  Transaction,
  TransactionLike,
  TransactionRequest,
  TransactionResponse,
  TypedDataDomain,
  TypedDataField,
  getBytes,
  hashMessage,
  keccak256,
  recoverAddress,
  resolveProperties,
} from 'ethers';
import { defaultLogger } from '../utils/logging';
import { decodeDER, derToSignature } from '../utils/signature';

function bytesToBuffer(data: string | Uint8Array): Buffer {
  const bytes = getBytes(data);
  return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}

export class KmsTransactionSigner extends AbstractSigner {
  private kmsClient: KMSClient;
  private _address: string | null = null;
  private debug: boolean;
  private kmsKeyId: string;
  private region?: string;
  private _cachedPublicKeys: Map<string, string> = new Map();

  constructor(keyId: string, provider?: null | Provider, region?: string, debug = false) {
    super(provider ?? null);
    this.kmsKeyId = keyId;
    this.region = region;
    this.debug = debug;

    if (this.debug) {
      defaultLogger.debug('Creating KMS signer', {
        keyId,
        region: region || process.env.REGION || 'us-west-2',
      });
    }

    try {
      this.kmsClient = new KMSClient({ region: this.region || process.env.REGION || 'us-west-2' });
    } catch (error) {
      defaultLogger.error('Error initializing KMS client:', { error: error instanceof Error ? error.message : String(error) });
      throw new Error(`Failed to initialize KMS client: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async getAddress(): Promise<string> {
    if (this._address) return this._address;

    try {
      if (this._cachedPublicKeys.has(this.kmsKeyId)) {
        const cachedAddress = this._cachedPublicKeys.get(this.kmsKeyId);
        if (cachedAddress) {
          this._address = cachedAddress;
          return this._address;
        }
      }

      const messageHex = '000000000000000000000000000000000000000000000000000000000000000000000000';
      const message = Buffer.from(messageHex, 'hex');

      const signCommand = new SignCommand({
        KeyId: this.kmsKeyId,
        Message: message,
        MessageType: 'RAW',
        SigningAlgorithm: 'ECDSA_SHA_256',
      });

      const response = await this.kmsClient.send(signCommand);
      if (!response.Signature) {
        throw new Error('KMS signing produced no signature');
      }

      const { r, s } = decodeDER(response.Signature);
      const signature = { r, s, v: 27, recoveryParam: 0 };
      const messageHash = keccak256(message);
      const messageBytes = getBytes(messageHash);

      let address: string | null = null;
      for (let v = 0; v <= 1; v++) {
        try {
          const sigWithV = { ...signature, v: v + 27 };
          const recoveredAddress = recoverAddress(messageBytes, sigWithV);

          if (recoveredAddress && recoveredAddress.startsWith('0x')) {
            address = recoveredAddress;
            break;
          }
        } catch (e) {
          defaultLogger.debug('Recovery attempt failed for v value', {
            recoveryValue: v,
            error: e instanceof Error ? e.message : String(e),
          });
        }
      }

      if (!address) {
        throw new Error('Failed to recover address from KMS signature');
      }

      this._address = address;
      this._cachedPublicKeys.set(this.kmsKeyId, address);

      if (this.debug) {
        defaultLogger.debug('Retrieved address for KMS key:', { address: this._address });
      }

      return this._address;
    } catch (error) {
      defaultLogger.error('Error getting address from KMS:', { error: error instanceof Error ? error.message : String(error) });
      throw new Error(`Error getting address from KMS: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async signMessage(message: string | Uint8Array): Promise<string> {
    try {
      if (this.debug) {
        defaultLogger.debug(`Signing message with KMS key ${this.kmsKeyId}`);
      }

      const msgToSign = typeof message === 'string' ? message : getBytes(message);
      const messageHash = hashMessage(msgToSign);

      const signCommand = new SignCommand({
        KeyId: this.kmsKeyId,
        Message: bytesToBuffer(messageHash),
        MessageType: 'DIGEST',
        SigningAlgorithm: 'ECDSA_SHA_256',
      });

      const response = await this.kmsClient.send(signCommand);

      if (!response.Signature) {
        throw new Error('KMS signing produced no signature');
      }

      const address = await this.getAddress();
      const normalizedSig = await derToSignature(
        Buffer.from(response.Signature || new Uint8Array()),
        messageHash,
        0,
        address
      );

      if (this.debug) {
        defaultLogger.debug('KMS Debug - Signature normalized for message signing', {
          r: normalizedSig.r?.substring(0, 10) + '...',
          s: normalizedSig.s?.substring(0, 10) + '...',
          v: normalizedSig.v,
          recoveryParam: normalizedSig.recoveryParam,
        });
      }

      return Signature.from(normalizedSig).serialized;
    } catch (error) {
      defaultLogger.error('Error signing message with KMS:', { error: error instanceof Error ? error.message : String(error) });
      throw new Error(`Error signing message with KMS: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async signTransaction(transaction: TransactionRequest): Promise<string> {
    try {
      const tx = (await resolveProperties(transaction)) as TransactionRequest;
      const prepared = await this.prepareTransactionForSigning(tx);

      if (this.debug) {
        defaultLogger.debug('Signing transaction with KMS key', {
          keyId: this.kmsKeyId,
          to: prepared.to,
          data: prepared.data ? `${prepared.data.toString().substring(0, 10)}...` : undefined,
          value: prepared.value?.toString(),
          chainId: prepared.chainId?.toString(),
          gasLimit: prepared.gasLimit?.toString(),
          type: prepared.type,
          maxFeePerGas: prepared.maxFeePerGas?.toString(),
          maxPriorityFeePerGas: prepared.maxPriorityFeePerGas?.toString(),
        });
      }

      const txForHashing = Transaction.from(prepared as any);
      const unsignedTx = txForHashing.unsignedSerialized;
      const messageHash = keccak256(unsignedTx);

      const signCommand = new SignCommand({
        KeyId: this.kmsKeyId,
        Message: bytesToBuffer(messageHash),
        MessageType: 'DIGEST',
        SigningAlgorithm: 'ECDSA_SHA_256',
      });

      const response = await this.kmsClient.send(signCommand);

      if (!response.Signature) {
        throw new Error('KMS signing produced no signature');
      }

      const address = await this.getAddress();
      const normalizedSig = await derToSignature(
        Buffer.from(response.Signature || new Uint8Array()),
        messageHash,
        Number(prepared.chainId),
        address
      );

      if (this.debug) {
        defaultLogger.debug('KMS Debug - Signature normalized for transaction signing', {
          r: normalizedSig.r?.substring(0, 10) + '...',
          s: normalizedSig.s?.substring(0, 10) + '...',
          v: normalizedSig.v,
          recoveryParam: normalizedSig.recoveryParam,
          chainId: prepared.chainId?.toString(),
        });
      }

      const signedTx = Transaction.from(prepared as any);
      signedTx.signature = Signature.from(normalizedSig);
      return signedTx.serialized;
    } catch (error) {
      defaultLogger.error('Error signing transaction with KMS:', {
        error: error instanceof Error ? error.message : String(error),
      });
      throw new Error(`Error signing transaction with KMS: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  connect(provider: null | Provider): Signer {
    return new KmsTransactionSigner(this.kmsKeyId, provider, this.region, this.debug);
  }

  async signTypedData(
    _domain: TypedDataDomain,
    _types: Record<string, Array<TypedDataField>>,
    _value: Record<string, any>
  ): Promise<string> {
    throw new Error('signTypedData is not supported by KmsTransactionSigner');
  }

  async sendTransaction(transaction: TransactionRequest): Promise<TransactionResponse> {
    if (!this.provider) {
      throw new Error('Provider required for sendTransaction');
    }

    const tx = (await resolveProperties(transaction)) as TransactionRequest;
    const populated = (await this.populateTransaction(tx)) as TransactionRequest;

    if (this.debug) {
      defaultLogger.debug('KMS Debug - Sending transaction', {
        to: populated.to,
        chainId: populated.chainId?.toString(),
        type: populated.type,
        maxFeePerGas: populated.maxFeePerGas?.toString(),
        maxPriorityFeePerGas: populated.maxPriorityFeePerGas?.toString(),
      });
    }

    const signedTx = await this.signTransaction(populated);
    return await this.provider.broadcastTransaction(signedTx);
  }

  async populateTransaction(transaction: TransactionRequest): Promise<TransactionLike<string>> {
    const tx = (await resolveProperties(transaction)) as TransactionRequest;
    const populated = {
      ...tx,
      type: 2,
    } as TransactionRequest & { gasPrice?: unknown };

    delete populated.gasPrice;

    if (populated.to != null) {
      try {
        const resolvedTo = await this.resolveName(populated.to as string);
        if (resolvedTo == null) {
          throw new Error(`Could not resolve transaction recipient: ${String(populated.to)}`);
        }
        populated.to = resolvedTo;
      } catch (error) {
        if (process.env.NODE_ENV === 'test') {
          defaultLogger.debug('Test environment detected, skipping name resolution');
        } else {
          throw error;
        }
      }
    }

    if (populated.nonce == null) {
      populated.nonce = await this.getNonce('pending');
    }

    if (populated.gasLimit == null) {
      populated.gasLimit = await this.estimateGas(populated);
    }

    if (populated.chainId == null) {
      if (!this.provider) {
        throw new Error('Transaction missing chainId and no provider available');
      }
      populated.chainId = (await this.provider.getNetwork()).chainId;
    }

    await this.fillEip1559Fees(populated);
    return populated as TransactionLike<string>;
  }

  _checkProvider(operation: string): void {
    if (!this.provider) {
      throw new Error(`${operation} requires a provider`);
    }
  }

  private async prepareTransactionForSigning(transaction: TransactionRequest): Promise<TransactionRequest> {
    const tx = {
      ...transaction,
      type: 2,
    } as TransactionRequest & { gasPrice?: unknown };

    delete tx.gasPrice;

    if (tx.chainId == null) {
      if (!this.provider) {
        throw new Error('Transaction missing chainId and no provider available');
      }
      tx.chainId = (await this.provider.getNetwork()).chainId;
    }

    await this.fillEip1559Fees(tx);
    return tx;
  }

  private async fillEip1559Fees(tx: TransactionRequest): Promise<void> {
    if (!this.provider) return;
    if (tx.maxFeePerGas != null && tx.maxPriorityFeePerGas != null) return;

    const feeData = await this.provider.getFeeData();
    const fallbackMaxFee = feeData.gasPrice != null ? feeData.gasPrice * 2n : 100_000_000n;

    tx.maxFeePerGas = tx.maxFeePerGas ?? feeData.maxFeePerGas ?? fallbackMaxFee;
    tx.maxPriorityFeePerGas = tx.maxPriorityFeePerGas ?? feeData.maxPriorityFeePerGas ?? 0n;
  }
}
