// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.36;

import {Initializable} from "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";

import {AbstractARM} from "./AbstractARM.sol";

/**
 * @title Automated Redemption Manager (ARM) for Origin Vaults with a single asset. eg OETH, OS and SuperOETH
 * @dev This implementation supports multiple Liquidity Providers (LPs) with single buy and sell prices.
 * It also integrates to a CapManager contract that caps the amount of assets a liquidity provider
 * can deposit and caps the ARM's total assets.
 * A fee is accrued on discounted base-asset buy swaps.
 * @author Origin Protocol Inc
 */
contract OriginARM is Initializable, AbstractARM {
    /// @notice The address of the Origin Vault
    address public immutable vault;

    /// @dev Deprecated vault withdrawal amount retained for storage layout compatibility.
    uint256 internal _deprecatedVaultWithdrawalAmount;

    event RequestOriginWithdrawal(uint256 amount, uint256 requestId);
    event ClaimOriginWithdrawals(uint256[] requestIds, uint256 amountClaimed);

    /// @param _otoken The address of the Origin token. eg OETH or OS
    /// @param _liquidityAsset The address of the liquidity asset. eg WETH or wS
    /// @param _vault The address of the Origin Vault
    /// @param _claimDelay The delay in seconds before a user can claim a redeem from the request
    /// @param _minSharesToRedeem The minimum amount of shares to redeem from the active lending market
    /// @param _allocateThreshold The minimum amount of liquidity assets in excess of the ARM buffer before
    /// the ARM can allocate to a active lending market.
    constructor(
        address _otoken,
        address _liquidityAsset,
        address _vault,
        uint256 _claimDelay,
        uint256 _minSharesToRedeem,
        int256 _allocateThreshold
    ) AbstractARM(_liquidityAsset, _claimDelay, _minSharesToRedeem, _allocateThreshold) {
        (_otoken);

        vault = _vault;

        _disableInitializers();
    }

    /// @notice Initialize the storage variables stored in the proxy contract.
    /// The deployer that calls initialize has to approve the ARM's proxy contract to transfer 1e12 liquid assets.
    /// @param _name The name of the liquidity provider (LP) token.
    /// @param _symbol The symbol of the liquidity provider (LP) token.
    /// @param _operator The address of the account that can request and claim Origin withdrawals.
    /// @param _fee The fee accrued on discounted base-asset buy swaps measured in basis points (1/100th of a percent).
    /// 10,000 = 100% fee
    /// 500 = 5% fee
    /// @param _feeCollector The account that can collect the accrued swap fee
    /// @param _capManager The address of the CapManager contract
    function initialize(
        string calldata _name,
        string calldata _symbol,
        address _operator,
        uint256 _fee,
        address _feeCollector,
        address _capManager
    ) external initializer {
        _initARM(_operator, _name, _symbol, _fee, _feeCollector, _capManager);
    }

    /// @notice Deprecated legacy Origin vault withdrawal amount view.
    /// @dev New vault withdrawal state is owned by the Origin asset adapter.
    /// @return The deprecated vault withdrawal amount.
    function vaultWithdrawalAmount() external view returns (uint256) {
        return _deprecatedVaultWithdrawalAmount;
    }

    /// @dev Revert if legacy Origin vault withdrawal requests are still outstanding.
    function checkNoLegacyWithdrawQueue() external view {
        require(_deprecatedVaultWithdrawalAmount == 0, "Legacy Origin vault pending");
    }
}
