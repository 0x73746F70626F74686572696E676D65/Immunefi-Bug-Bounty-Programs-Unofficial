// SPDX-License-Identifier: MIT
pragma solidity ^0.8.36;

// Foundry
import {console} from "forge-std/console.sol";

// Test imports
import {TargetFunctions} from "./TargetFunctions.sol";

// Helpers
import {Math} from "./helpers/Math.sol";

// Interfaces
import {UserCooldown} from "contracts/Interfaces.sol";

/// @title Properties
/// @notice Abstract contract defining invariant properties for formal verification and fuzzing.
/// @dev    This contract contains pure property functions that express system invariants:
///         - Properties must be implemented as view/pure functions returning bool
///         - Each property should represent a mathematical invariant of the system
///         - Properties should be stateless and deterministic
///         - Property names should clearly indicate what invariant they check
///         Usage: Properties are called by fuzzing contracts to validate system state
abstract contract Properties is TargetFunctions {
    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                           ✦✦✦ SWAP PROPERTIES ✦✦✦                            ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    // [x] Invariant A: USDe  balance == ∑swapIn - ∑swapOut
    //                                   + ∑userDeposit - ∑userWithdraw
    //                                   + ∑marketWithdraw - ∑marketDeposit
    //                                   + ∑baseRedeem - ∑feesCollected
    // [x] Invariant B: sUSDe balance == (∑swapIn - ∑swapOut) - ∑baseRedeem
    //
    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                            ✦✦✦ LP PROPERTIES ✦✦✦                             ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    // [x] Invariant C: ∑shares > 0 due to initial deposit
    // [x] Invariant D: totalShares == ∑userShares + deadShares
    // [x] Invariant E: previewRedeem(∑shares) == totalAssets
    // [x] Invariant F: reservedWithdrawLiquidity == ∑unclaimed request.assets
    // [x] Invariant G: withdrawsQueuedShares >= withdrawsClaimedShares
    // [x] Invariant H: withdrawsQueuedShares == ∑request.shares
    // [x] Invariant I: withdrawsClaimedShares == ∑claimed request.shares
    // [x] Invariant J: ARM escrowed shares == withdrawsQueuedShares - withdrawsClaimedShares
    // [x] Invariant K: ∑feesCollected == feeCollector.balance
    //
    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                         ✦✦✦ LIQUIDITY MANAGEMENT ✦✦✦                         ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    // [x] Invariant L: liquidityAmountInCooldown == ∑unstaker.underlyingAmount
    // [x] Invariant M: nextUnstakerIndex < MAX_UNSTAKERS
    // [x] Invariant N: ∀ unstaker, usde.balanceOf(unstaker) == 0 && susde.balanceOf(unstaker) == 0
    //
    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                              ✦✦✦ AFTER ALL ✦✦✦                               ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    // [x] sUSDe in ARM == 0
    // [x] Morpho shares in ARM == 0
    // [x] ∀ user, usde.balanceOf(user) >= totalMinted - 1e1
    //
    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                                   ✦✦✦  ✦✦✦                                   ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝

    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                           ✦✦✦ SWAP PROPERTIES ✦✦✦                            ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    function propertyA() public view returns (bool) {
        uint256 usdeBalance = usde.balanceOf(address(arm));
        uint256 inflow = 1e12 + sumUSDeSwapIn + sumUSDeUserDeposit + sumUSDeMarketWithdraw + sumUSDeBaseRedeem;
        uint256 outflow = sumUSDeSwapOut + sumUSDeUserRedeem + sumUSDeMarketDeposit + sumUSDeFeesCollected;
        // console.log(">>> Property A:");
        // console.log("    - USDe balance:         %18e", usdeBalance);
        // console.log("    - Inflow breakdown:");
        // console.log("        o Initial buffer:   %18e", uint256(1e12));
        // console.log("        o Swap In:          %18e", sumUSDeSwapIn);
        // console.log("        o User Deposit:     %18e", sumUSDeUserDeposit);
        // console.log("        o Market Withdraw:  %18e", sumUSDeMarketWithdraw);
        // console.log("        o Base Redeem:      %18e", sumUSDeBaseRedeem);
        // console.log("    - USDe inflow sum:      %18e", inflow);
        // console.log("    - Outflow breakdown:");
        // console.log("        o Swap Out:         %18e", sumUSDeSwapOut);
        // console.log("        o User Redeem:      %18e", sumUSDeUserRedeem);
        // console.log("        o Market Deposit:   %18e", sumUSDeMarketDeposit);
        // console.log("        o Fees Collected:   %18e", sumUSDeFeesCollected);
        // console.log("    - USDe outflow sum:     %18e", outflow);
        // console.log("    - Diff:                 %18e", Math.absDiff(inflow, outflow));
        return Math.eq(usdeBalance, Math.absDiff(inflow, outflow));
    }

    function propertyB() public view returns (bool) {
        uint256 susdeBalance = susde.balanceOf(address(arm));
        uint256 inflow = sumSUSDeSwapIn;
        uint256 outflow = sumSUSDeSwapOut + sumSUSDeBaseRedeem;
        // console.log(">>> Property B:");
        // console.log("    - sUSDe balance:        %18e", susdeBalance);
        // console.log("    - Inflow breakdown:");
        // console.log("        o Swap In:          %18e", sumSUSDeSwapIn);
        // console.log("    - sUSDe inflow sum:     %18e", inflow);
        // console.log("    - Outflow breakdown:");
        // console.log("        o Swap Out:         %18e", sumSUSDeSwapOut);
        // console.log("        o Base Redeem:      %18e", sumSUSDeBaseRedeem);
        // console.log("    - sUSDe outflow sum:    %18e", outflow);
        // console.log("    - Diff:                 %18e", Math.absDiff(inflow, outflow));
        return Math.eq(susdeBalance, Math.absDiff(inflow, outflow));
    }

    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                            ✦✦✦ LP PROPERTIES ✦✦✦                             ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    function propertyC() public view returns (bool) {
        return Math.gt(arm.totalSupply(), 0);
    }

    function propertyD() public view returns (bool) {
        uint256 totalUserShares = 0;
        for (uint256 i = 0; i < MAKERS_COUNT; i++) {
            totalUserShares += arm.balanceOf(makers[i]);
        }
        totalUserShares += arm.balanceOf(address(arm));
        uint256 deadShares = 1e12;
        return Math.eq(arm.totalSupply(), totalUserShares + deadShares);
    }

    function propertyE() public view returns (bool) {
        return Math.eq(arm.previewRedeem(arm.totalSupply()), arm.totalAssets());
    }

    function propertyF() public view returns (bool) {
        return Math.eq(arm.reservedWithdrawLiquidity(), sumOfUnclaimedRequestAssets());
    }

    function propertyG() public view returns (bool) {
        return Math.gte(arm.withdrawsQueuedShares(), arm.withdrawsClaimedShares());
    }

    function propertyH() public view returns (bool) {
        return Math.eq(arm.withdrawsQueuedShares(), sumARMUserRequestShares);
    }

    function propertyI() public view returns (bool) {
        return Math.eq(arm.withdrawsClaimedShares(), sumARMUserRedeemShares);
    }

    function propertyJ() public view returns (bool) {
        return Math.eq(arm.balanceOf(address(arm)), arm.withdrawsQueuedShares() - arm.withdrawsClaimedShares());
    }

    function sumOfUnclaimedRequestAssets() public view returns (uint256 sum) {
        uint256 len = arm.nextWithdrawalIndex();
        for (uint256 i; i < len; i++) {
            (, bool claimed,, uint128 amount,) = arm.withdrawalRequests(i);
            if (!claimed) sum += amount;
        }
    }

    function propertyK() public view returns (bool) {
        uint256 feeCollectorBalance = usde.balanceOf(treasury);
        return Math.eq(sumUSDeFeesCollected, feeCollectorBalance);
    }

    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                         ✦✦✦ LIQUIDITY MANAGEMENT ✦✦✦                         ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    function propertyL() public view returns (bool) {
        uint256 liquidityAmountInCooldown;
        uint256 len = unstakers.length;
        for (uint256 i; i < len; i++) {
            UserCooldown memory cooldown = susde.cooldowns(address(unstakers[i]));
            liquidityAmountInCooldown += cooldown.underlyingAmount;
        }
        (,,,,, uint128 pendingRedeemAssets,,,) = arm.baseAssetConfigs(address(susde));
        return Math.eq(liquidityAmountInCooldown, pendingRedeemAssets);
    }

    function propertyM() public view returns (bool) {
        uint256 nextUnstakerIndex = ethenaAssetAdapter.nextUnstakerIndex();
        return Math.lt(nextUnstakerIndex, ethenaAssetAdapter.MAX_UNSTAKERS());
    }

    function propertyN() public view returns (bool) {
        uint256 len = unstakers.length;
        for (uint256 i; i < len; i++) {
            address unstaker = address(unstakers[i]);
            if (usde.balanceOf(unstaker) != 0 || susde.balanceOf(unstaker) != 0) {
                return false;
            }
        }
        return true;
    }

    // ╔══════════════════════════════════════════════════════════════════════════════╗
    // ║                              ✦✦✦ AFTER ALL ✦✦✦                               ║
    // ╚══════════════════════════════════════════════════════════════════════════════╝
    function _propertyAfterAll() internal view returns (bool) {
        uint256 usdeBalance = usde.balanceOf(address(arm));
        uint256 susdeBalance = susde.balanceOf(address(arm));
        uint256 morphoBalance = morpho.balanceOf(address(arm));
        uint256 armTotalAssets = arm.totalAssets();
        if (isConsoleAvailable) {
            console.log("--- Final Balances ---");
            console.log("ARM USDe balance:\t %18e", usdeBalance);
            console.log("ARM sUSDe balance:\t %18e", susdeBalance);
            console.log("ARM Morpho shares:\t %18e", morphoBalance);
            console.log("ARM total assets:\t %18e", armTotalAssets);
        }
        require(susdeBalance == 0, "sUSDe balance not zero");
        require(morphoBalance == 0, "Morpho shares not zero");
        return true;
    }
}
