// SPDX-License-Identifier: MIT
pragma solidity ^0.8.36;

// Solmate
import {ERC20} from "@solmate/tokens/ERC20.sol";
import {ERC4626} from "@solmate/mixins/ERC4626.sol";

contract MockMorpho is ERC4626 {
    //////////////////////////////////////////////////////
    /// --- STATE VARIABLES
    //////////////////////////////////////////////////////
    uint256 public utilizationRate;

    //////////////////////////////////////////////////////
    /// --- EVENTS
    //////////////////////////////////////////////////////
    event UtilizationRateChanged(uint256 oldUtilizationRate, uint256 newUtilizationRate);

    //////////////////////////////////////////////////////
    /// --- CONSTRUCTOR
    //////////////////////////////////////////////////////
    constructor(address _underlying) ERC4626(ERC20(_underlying), "Mock Morpho Blue", "Mock Morpho Blue") {}

    //////////////////////////////////////////////////////
    /// --- VIEW FUNCTIONS
    //////////////////////////////////////////////////////
    function totalAssets() public view override returns (uint256) {
        return asset.balanceOf(address(this));
    }

    function maxWithdraw(address owner) public view override returns (uint256) {
        uint256 remainingLiquidity = availableLiquidity();
        uint256 userLiquidity = convertToAssets(balanceOf[owner]);
        return userLiquidity > remainingLiquidity ? remainingLiquidity : userLiquidity;
    }

    function maxRedeem(address owner) public view override returns (uint256) {
        uint256 maxRedeemableShares = convertToShares(availableLiquidity());
        uint256 userShares = balanceOf[owner];
        return userShares > maxRedeemableShares ? maxRedeemableShares : userShares;
    }

    function beforeWithdraw(uint256 assets, uint256) internal view override {
        require(assets <= availableLiquidity(), "INSUFFICIENT_LIQUIDITY");
    }

    function availableLiquidity() public view returns (uint256) {
        return totalAssets() * (1e18 - utilizationRate) / 1e18;
    }

    //////////////////////////////////////////////////////
    /// --- MUTATIVE FUNCTIONS
    //////////////////////////////////////////////////////
    function setUtilizationRate(uint256 _utilizationRate) external {
        emit UtilizationRateChanged(utilizationRate, _utilizationRate);
        utilizationRate = _utilizationRate;
    }
}
