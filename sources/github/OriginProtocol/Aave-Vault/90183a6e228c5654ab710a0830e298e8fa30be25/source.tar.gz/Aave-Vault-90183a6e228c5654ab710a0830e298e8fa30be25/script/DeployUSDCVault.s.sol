// SPDX-License-Identifier: MIT

pragma solidity ^0.8.10;

import "forge-std/Script.sol";
import {TransparentUpgradeableProxy} from "@openzeppelin/proxy/transparent/TransparentUpgradeableProxy.sol";
import {IERC20Upgradeable} from "@openzeppelin-upgradeable/interfaces/IERC20Upgradeable.sol";

import "../src/ATokenVault.sol";

contract DeployUSDCVault is Script {
    // DEPLOYMENT PARAMETERS
    // ===================================================
    address constant UNDERLYING_ASSET_ADDRESS = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48; // USDC
    uint16 constant REFERRAL_CODE = 0;
    address constant AAVE_POOL_ADDRESSES_PROVIDER_ADDRESS = 0x2f39d218133AFaB8F2B819B1066c7E434Ad94E9e;
    address constant PROXY_ADMIN_ADDRESS = 0x35918cDE7233F2dD33fA41ae3Cb6aE0e42E0e69F; // Timelock
    address constant OWNER_ADDRESS = 0x35918cDE7233F2dD33fA41ae3Cb6aE0e42E0e69F; // Timelock
    string constant SHARE_NAME = "Wrapped aUSDC";
    string constant SHARE_SYMBOL = "waUSDC";
    uint256 constant FEE = 0;
    uint256 constant INITIAL_LOCK_DEPOSIT = 1e6; // 1 USDC
    // ===================================================

    ATokenVault public vault;

    function run() external {
        address deployerAddress = vm.envAddress("DEPLOYER_ADDRESS");

        console.log("Deployer address: ", deployerAddress);
        console.log("Deployer balance: ", deployerAddress.balance);
        console.log("BlockNumber: ", block.number);
        console.log("ChainId: ", block.chainid);
        console.log("Deploying vault...");

        require(block.chainid == 1, "Ethereum mainnet only");
        require(
            INITIAL_LOCK_DEPOSIT != 0,
            "Initial deposit not set. This prevents a frontrunning attack, please set a non-trivial initial deposit."
        );

        vm.startBroadcast(deployerAddress);

        // Deploy the implementation, which disables initializers on construction.
        vault = new ATokenVault(
            UNDERLYING_ASSET_ADDRESS, REFERRAL_CODE, IPoolAddressesProvider(AAVE_POOL_ADDRESSES_PROVIDER_ADDRESS)
        );
        console.log("Vault impl deployed at: ", address(vault));

        console.log("Deploying proxy...");
        bytes memory data = abi.encodeWithSelector(
            ATokenVault.initialize.selector, OWNER_ADDRESS, FEE, SHARE_NAME, SHARE_SYMBOL, INITIAL_LOCK_DEPOSIT
        );
        console.logBytes(data);

        // The approve transaction is broadcast before the proxy deployment, hence the +1 nonce.
        address proxyAddr = computeCreateAddress(deployerAddress, vm.getNonce(deployerAddress) + 1);
        IERC20Upgradeable(UNDERLYING_ASSET_ADDRESS).approve(proxyAddr, INITIAL_LOCK_DEPOSIT);
        console.log("Precomputed proxy address: ", proxyAddr);
        console.log(
            "Allowance for proxy: ", IERC20Upgradeable(UNDERLYING_ASSET_ADDRESS).allowance(deployerAddress, proxyAddr)
        );

        TransparentUpgradeableProxy proxy = new TransparentUpgradeableProxy(address(vault), PROXY_ADMIN_ADDRESS, data);
        console.log("Vault proxy deployed and initialized at: ", address(proxy));

        vm.stopBroadcast();

        console.log("\nVault data:");
        vault = ATokenVault(address(proxy));
        console.log("POOL_ADDRESSES_PROVIDER:", address(vault.POOL_ADDRESSES_PROVIDER()));
        console.log("REFERRAL_CODE:", vault.REFERRAL_CODE());
        console.log("UNDERLYING:", address(vault.UNDERLYING()));
        console.log("ATOKEN:", address(vault.ATOKEN()));
        console.log("Name:", vault.name());
        console.log("Symbol:", vault.symbol());
        console.log("Owner:", vault.owner());
        console.log("Fee:", vault.getFee());
    }
}
