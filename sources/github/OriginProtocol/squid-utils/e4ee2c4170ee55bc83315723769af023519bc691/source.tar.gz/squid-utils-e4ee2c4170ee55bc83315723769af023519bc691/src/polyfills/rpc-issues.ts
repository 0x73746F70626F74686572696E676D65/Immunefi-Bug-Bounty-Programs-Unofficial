// Fix RPC issues
// import * as fs from 'node:fs'
import { CallOptions, RpcClient } from '@subsquid/rpc-client';
import { RpcCall } from '@subsquid/rpc-client/src/interfaces';
import { DEFAULT_CU_COST, RPC_CU_COSTS } from '../constants/rpc-cu-costs';
import { processingStats } from '../processing-stats';

(RpcClient.prototype as any)._call = RpcClient.prototype.call
;(RpcClient.prototype as any)._batchCall = RpcClient.prototype.batchCall

// let count = 0

const getMethodCUCost = (method: string): number => {
  return RPC_CU_COSTS[method] ?? DEFAULT_CU_COST;
};

/**
 * The portal's `/stream` hands us a block a few hundred ms before the RPC node
 * has it, so a contract read at the head block can come back "block not found".
 * The gateway path never saw this, because RPC head-polling *was* the ingestion
 * source — a block could not arrive ahead of the node it came from.
 *
 * Retry briefly, then give up: the gap is sub-second, so a block still missing
 * after this window is a real problem (a reorg, or a node genuinely behind) and
 * must surface rather than be papered over.
 */
const BLOCK_NOT_FOUND_RETRIES = 10
const BLOCK_NOT_FOUND_RETRY_MS = 150

// Some providers answer with HTTP 400 instead of a JSON-RPC error (dRPC:
// `{code: 26, message: 'Unknown block'}`), which `@subsquid/http-client` throws
// as an `HttpError` whose own message is only "Got 400 from <url>". The JSON-RPC
// error is in the response body, so look there too.
const rpcErrorOf = (err: any) => {
  const body = err?.response?.body
  if (Array.isArray(body)) return body.find((r) => r?.error)?.error ?? err
  return body?.error ?? err
}

const isBlockNotFound = (err: any) => {
  const rpcError = rpcErrorOf(err)
  return (
    rpcError != null &&
    (rpcError.code === -32001 || rpcError.code === -32000 || rpcError.code === 26) &&
    typeof rpcError.message === 'string' &&
    /block not found|header not found|unknown block|missing trie node/i.test(rpcError.message)
  )
}

// `RpcClient.batchCall` sends a single-call batch through `this.call`, which
// would nest this retry inside the batch retry (up to 11 x 11 attempts). The
// batch path marks its options so the inner `call` does not retry again.
const NO_HEAD_RETRY = Symbol('noHeadRetry')

const callWithHeadRetry = async function (this: any, method: string, params?: any[], options?: any) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await this._call(method, params, options)
    } catch (err) {
      if (attempt >= BLOCK_NOT_FOUND_RETRIES || !isBlockNotFound(err)) throw err
      await new Promise((resolve) => setTimeout(resolve, BLOCK_NOT_FOUND_RETRY_MS))
    }
  }
}

RpcClient.prototype.call = async function <T = any>(
  method: string,
  params?: any[],
  options?: CallOptions<T>,
): Promise<T> {
  const startTime = Date.now();
  const cuCost = getMethodCUCost(method);
  
  processingStats.rpcCalls++;
  processingStats.rpcCallTypes.set(method, (processingStats.rpcCallTypes.get(method) ?? 0) + 1);
  if (method === 'eth_call') {
    const callMethod = params?.[0]?.data.slice(0, 10) ?? '';
    const count = processingStats.ethCallCounts.get(callMethod) ?? 0;
    processingStats.ethCallCounts.set(callMethod, count + 1);
  }

  const response = (options as any)?.[NO_HEAD_RETRY]
    ? await (this as any)._call(method, params, options)
    : await callWithHeadRetry.call(this, method, params, options);

  if (method === 'debug_traceBlockByHash') {
    fixSelfDestructs(response);
  }

  const duration = Date.now() - startTime;
  processingStats.rpcCallTime += duration;
  
  return response;
}

RpcClient.prototype.batchCall = async function <T = any>(batch: RpcCall[], options?: CallOptions<T>): Promise<T[]> {
  const startTime = Date.now();
  const batchCUCost = batch.reduce((total, call) => total + getMethodCUCost(call.method), 0);
  
  processingStats.rpcCalls += batch.length;
  
  // Same head race as `call` — multicall reads at the head block hit it too.
  let response: any
  for (let attempt = 0; ; attempt++) {
    try {
      response = await (this as any)._batchCall(batch, { ...options, [NO_HEAD_RETRY]: true })
      break
    } catch (err) {
      if (attempt >= BLOCK_NOT_FOUND_RETRIES || !isBlockNotFound(err)) throw err
      await new Promise((resolve) => setTimeout(resolve, BLOCK_NOT_FOUND_RETRY_MS))
    }
  }


  for (let i = 0; i < batch.length; i++) {
    if (batch[i].method === 'debug_traceBlockByHash') {
      fixSelfDestructs(response[i]);
    }
    const method = batch[i].method;
    const cuCost = getMethodCUCost(method);
    processingStats.rpcCallTypes.set(method, (processingStats.rpcCallTypes.get(method) ?? 0) + 1);
    if (method === 'eth_call') {
      const callMethod = (batch[i].params?.[0] as any)?.data.slice(0, 10) ?? '';
      const count = processingStats.ethCallCounts.get(callMethod) ?? 0;
      processingStats.ethCallCounts.set(callMethod, count + 1);
    }
  }

  const duration = Date.now() - startTime;
  processingStats.rpcCallTime += duration;
  
  return response;
}

const fixSelfDestructs = (input: any) => {
  if (!input) return
  if (typeof input !== 'object') return
  if (Array.isArray(input)) {
    input.forEach((v) => fixSelfDestructs(v))
  }
  if ('calls' in input && Array.isArray(input.calls)) {
    input.calls.forEach((v: any) => fixSelfDestructs(v))
  }
  if ('type' in input && input.type === 'SELFDESTRUCT' && !input.to) {
    input.to = '0x0'
  }
  if ('result' in input) {
    fixSelfDestructs(input.result)
  }
}
