const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const ethers = require("ethers");
const { createHash } = require("crypto");
const { parseUnits } = require("ethers");
const { getContractsAndConstants } = require("./common");

/// They following use Lodestar API calls
const getValidatorBalance = async (pubkey) => {
  const client = await configClient();

  console.log(`Fetching validator details for ${pubkey} from the beacon node`);
  const validatorRes = await client.beacon.getStateValidator({
    stateId: "head",
    validatorId: pubkey,
  });
  if (!validatorRes.ok) {
    console.error(validatorRes);
    throw Error(
      `Failed to get validator details for ${pubkey}. Status ${validatorRes.status} ${validatorRes.statusText}`
    );
  }

  const values = validatorRes.value();
  console.log(`Got balance ${values.balance} for validator ${values.index}`);
  return values.balance;
};

/**
 * Get the slot for a given block identifier.
 * @param {string} [blockId=head] - is "head", slot number or the beacon block root.
 */
const getSlot = async (blockId = "head") => {
  const client = await configClient();

  // Get the latest beacon block data using Lodestar
  console.log(`Fetching block header for blockId: ${blockId} from the beacon node`);
  const blockHeaderRes = await client.beacon.getBlockHeader({
    blockId,
  });
  if (!blockHeaderRes.ok) {
    console.error(blockHeaderRes);
    throw Error(
      `Failed to get block header for blockId ${blockId}. Status ${blockHeaderRes.status} ${blockHeaderRes.statusText}`
    );
  }

  const slot = blockHeaderRes.value().header.message.slot;
  console.log(`Got slot ${slot} for block id ${blockId}`);

  return slot;
};

const getBeaconBlockRoot = async (blockId = "head") => {
  const client = await configClient();

  console.log(
    `Fetching beacon block root for block id ${blockId} from the beacon node`
  );
  const blockHeaderRes = await client.beacon.getBlockRoot({
    blockId,
  });
  if (!blockHeaderRes.ok) {
    console.error(blockHeaderRes);
    throw Error(
      `Failed to get beacon block root for block id ${blockId}. Status ${blockHeaderRes.status} ${blockHeaderRes.statusText}`
    );
  }

  const root = blockHeaderRes.root;
  console.log(`Got beacon block root ${root} for block id ${blockId}`);

  return root;
};

/**
 * Gets the full beacon chain data for a given slot, root or "head".
 * @param {string|number} [slot=head] - The slot to get the beacon block for. Can be "head", a slot number or a beacon block root.
 */
const getBeaconBlock = async (slot = "head") => {
  const client = await configClient();

  const { ssz } = await import("@lodestar/types");
  const BeaconBlock = ssz.electra.BeaconBlock;
  const BeaconState = ssz.electra.BeaconState;

  // Get the beacon block for the slot from the beacon node.
  console.log(`Fetching block for slot ${slot} from the beacon node`);
  const blockRes = await client.beacon.getBlockV2({ blockId: slot });
  if (!blockRes.ok) {
    console.error(blockRes);
    throw new Error(
      `Failed to get beacon block for id ${slot}. It could be because the slot was missed or the provider URL does not support beacon chain API. Error: ${blockRes.status} ${blockRes.statusText}`
    );
  }

  const blockView = BeaconBlock.toView(blockRes.value().message);

  // Read the state from a local file or fetch it from the beacon node.
  let stateSsz;
  
  const cacheDir = './cache';
  if (!fs.existsSync(cacheDir)) {
    fs.mkdirSync(cacheDir, { recursive: true });
  }

  const stateFilename = `./cache/state_${blockView.slot}.ssz`;
  if (fs.existsSync(stateFilename)) {
    console.log(`Loading state from file ${stateFilename}`);
    stateSsz = fs.readFileSync(stateFilename);
  } else {
    console.log(`Fetching state for slot ${blockView.slot} from the beacon node`);
    const stateRes = await client.debug.getStateV2(
      { stateId: blockView.slot },
      "ssz"
    );
    if (!stateRes.ok) {
      console.error(stateRes);
      throw new Error(
        `Failed to get state for slot ${blockView.slot}. Probably because it was missed. Error: ${stateRes.status} ${stateRes.statusText}`
      );
    }

    console.log(`Writing state to file ${stateFilename}`);
    fs.writeFileSync(stateFilename, stateRes.ssz());
    stateSsz = stateRes.ssz();
  }

  const stateView = BeaconState.deserializeToView(stateSsz);

  const blockTree = blockView.tree.clone();
  const stateRootGIndex = blockView.type.getPropertyGindex("stateRoot");
  // Patching the tree by attaching the state in the `stateRoot` field of the block.
  blockTree.setNode(stateRootGIndex, stateView.node);

  return { blockTree, blockView, stateView };
};

const concatProof = (proof) => {
  const witnessLength = proof.witnesses.length;
  const witnessBytes = new Uint8Array(witnessLength * 32);
  for (let i = 0; i < witnessLength; i++) {
    witnessBytes.set(proof.witnesses[i], i * 32);
  }
  return witnessBytes;
};

const hashPubKey = (pubKey) => {
  // Ensure pubKey is a hex string or Buffer
  const pubKeyBytes = ethers.utils.arrayify(pubKey);

  // Create 16 bytes of zeros
  const zeroBytes = ethers.utils.hexZeroPad("0x0", 16);

  // Concatenate pubKey and zero bytes
  const concatenated = ethers.utils.concat([pubKeyBytes, zeroBytes]);

  // Compute SHA256 hash
  return ethers.utils.sha256(concatenated);
};

/**
 * Gets a Lodestar API client.
 * @returns {Promise<Client>} - The Lodestar API client.
 */
const configClient = async () => {
  // Get the latest slot from the beacon chain API
  // Dynamically import the Lodestar API client as its an ESM module
  const { getClient } = await import("@lodestar/api");
  const { config } = await import("@lodestar/config/default");

  console.log(`BEACON_PROVIDER_URL: ${process.env.BEACON_PROVIDER_URL}`);
  const baseUrl = process.env.BEACON_PROVIDER_URL;

  // 20 minutes timeout for Ralway network throttling reasons
  const client = await getClient({ baseUrl, globalInit: { timeoutMs: 1200000 } }, { config });

  return client;
};

/// The following connect directly to the BeaconChain API
/// They could be replaced with Lodestar API calls in the future.

const getValidator = async (pubkey) => {
  const beaconProvider = (await getContractsAndConstants()).beaconProvider;

  return await beaconchainRequest(`validator/${pubkey}`, beaconProvider);
};

const getValidatorDeposits = async (pubkey) => {
  const beaconProvider = (await getContractsAndConstants()).beaconProvider;
  return await beaconchainRequest(`validator/${pubkey}/deposits`, beaconProvider);
};

const getValidators = async (pubkeys, beaconChainApiKey) => {
  const encodedPubkeys = encodeURIComponent(pubkeys);
  return await beaconchainRequest(
    `validator/${encodedPubkeys}`,
    beaconChainApiKey
  );
};

const getEpoch = async (epochId = "latest") => {
  return await beaconchainRequest(`epoch/${epochId}`);
};

const getSlotBySlotId = async (slotId = "head") => {
  const beaconProvider = (await getContractsAndConstants()).beaconProvider;
  return await beaconchainRequest(`slot/${slotId}`, beaconProvider);
};

const beaconchainRequest = async (endpoint, overrideProvider) => {
  const beaconProvider = (await getContractsAndConstants()).beaconProvider;

  const API_URL =
    overrideProvider ||
    beaconProvider

  const apikey = process.env.BEACONCHAIN_API_KEY;
  const url = `${beaconProvider}${endpoint}`;
  if (!apikey) {
    throw new Error(
      "Set BEACONCHAIN_API_KEY in order to be able to query the API"
    );
  }

  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json",
    apikey,
  };

  console.log(`About to call Beacon API: ${url} `);

  const rawResponse = await fetch(url, {
    method: "GET",
    headers,
  });

  const response = await rawResponse.json();
  if (response.status != "OK") {
    console.log(`Call to Beacon API failed: ${url}`);
    console.log(`response: `, response);
    throw new Error(
      `Call to Beacon API failed. Error: ${JSON.stringify(response.status)}`
    );
  } else {
    console.log(`GET request to Beacon API succeeded. Response: `, response);
  }

  return response.data;
};

const serializeUint64 = async (value) => {
  const { ssz } = await import("@lodestar/types");

  // Need to convert to little-endian Uint8Array
  const slotLittleEndian = ssz.Slot.serialize(Number(value));
  // Pad to 32 bytes
  const leafBuf = Buffer.concat([
    slotLittleEndian,
    Buffer.alloc(32 - slotLittleEndian.length),
  ]);
  return "0x" + Buffer.from(leafBuf).toString("hex");
};

/**
 * Calculates the Merkle root (as hex string) from a leaf and flat Merkle proof.
 *
 * @param {string} leafHex - 0x-prefixed 32-byte hex string
 * @param {string} proofHex - 0x-prefixed hex string containing N × 32-byte proof (concatenated)
 * @param {bigint} gIndex - Generalized index of the leaf in the Merkle tree
 * @returns {string} - 0x-prefixed hex string of the calculated Merkle root
 */
const calcBeaconBlockRoot = (leafHex, proofHex, gIndex) => {
  const valueBytes = Buffer.from(leafHex.slice(2), "hex");
  const proofBytes = Buffer.from(proofHex.slice(2), "hex");

  if (proofBytes.length % 32 !== 0) {
    throw new Error("proofHex must be a multiple of 32 bytes");
  }

  const proofCount = proofBytes.length / 32;
  let value = valueBytes;
  let index = gIndex;

  for (let i = 0; i < proofCount; i++) {
    const sibling = proofBytes.slice(i * 32, (i + 1) * 32);
    const hasher = createHash("sha256");

    if (index % 2n === 0n) {
      hasher.update(value);
      hasher.update(sibling);
    } else {
      hasher.update(sibling);
      hasher.update(value);
    }

    value = hasher.digest();
    index >>= 1n;

    if (index === 0n) throw new Error("proof has extra item");
  }

  if (index !== 1n) throw new Error("proof is missing items");

  const rootHex = "0x" + value.toString("hex");

  console.log(
    `Calculated beacon block root: ${rootHex} from leaf: ${leafHex} and gindex: ${gIndex}`
  );

  return rootHex;
};

const calcBlockTimestamp = async (slot) => {
  const genesisTime = (await getContractsAndConstants()).beaconChainGenesisTime;
  return 12n * BigInt(slot) + BigInt(genesisTime);
};

const calcSlot = async (blockTimestamp) => {
  const genesisTime = (await getContractsAndConstants()).beaconChainGenesisTime;
  return (BigInt(blockTimestamp) - BigInt(genesisTime)) / 12n;
};

const calcEpoch = (blockTimestamp) => {
  const slotsPerEpoch = 32n;
  return calcSlot(blockTimestamp) / slotsPerEpoch;
};

// verifies the deposit signature so we can confirm P2P has not generated a faulty one
// and a the deposit message root. The latter should also be verified by the Beacon chain
// deposit contract
const verifyDepositSignatureAndMessageRoot = async ({
  pubkey, // validator public key with or without 0x
  withdrawalCredentials, // withdrawal credentials with or without 0x
  amount, // amount in eth units
  signature, // signature without 0x
  depositMessageRoot, // p2p supplied deposit message root with or without 0x
  forkVersion, // fork version
}) => {
  // Can not import via require since these packages support only ESM mode
  const bls = await import("@chainsafe/bls");
  const { ssz } = await import("@lodestar/types/phase0");
  const { computeDomain, computeSigningRoot } = await import(
    "@lodestar/state-transition"
  );
  const { DOMAIN_DEPOSIT } = await import("@lodestar/params");
  const { fromHex } = await import("@lodestar/utils");

  console.log("Validating BLS deposit message signature");
  console.log(`pubkey: ${pubkey}`);
  console.log(`withdrawalCredentials: ${withdrawalCredentials}`);
  console.log(`amount: ${amount}`);
  console.log(`signature: ${signature}`);
  console.log(`depositMessageRoot: ${depositMessageRoot}`);
  console.log(`forkVersion: ${forkVersion}`);

  const amountGwei = parseUnits(amount.toString(), 9);
  depositMessageRoot = depositMessageRoot.startsWith("0x")
    ? depositMessageRoot.substring(2)
    : depositMessageRoot;

  // Prepare the DepositMessage
  const depositMessage = {
    pubkey: fromHex(pubkey),
    withdrawalCredentials: fromHex(withdrawalCredentials),
    amount: amountGwei.toString(),
  };

  const domain = computeDomain(
    DOMAIN_DEPOSIT,
    fromHex(forkVersion),
    new Uint8Array(32)
  );

  // Compute signing root
  const signingRoot = computeSigningRoot(
    ssz.DepositMessage,
    depositMessage,
    domain
  );

  if (
    !bls.default.verify(depositMessage.pubkey, signingRoot, fromHex(signature))
  ) {
    throw Error(`BLS signature is invalid`);
  }

  console.log(`BLS signature valid`);

  // Compare computed deposit_message_root with provided one for sanity check
  const computedMessageRoot = ssz.DepositMessage.hashTreeRoot(depositMessage);
  const computedMessageRootString =
    Buffer.from(computedMessageRoot).toString("hex");
  if (depositMessageRoot != computedMessageRootString) {
    throw Error(
      `Deposit message root miss-match. Computed value: ${computedMessageRootString} vs supplied value: ${depositMessageRoot}`
    );
  }
  console.log(
    `Deposit message root matches the computed message root: ${depositMessageRoot}`
  );
};

module.exports = {
  concatProof,
  getBeaconBlock,
  getSlot,
  getBeaconBlockRoot,
  calcBlockTimestamp,
  calcSlot,
  calcEpoch,
  getValidator,
  getValidators,
  getValidatorBalance,
  getEpoch,
  hashPubKey,
  serializeUint64,
  calcBeaconBlockRoot,
  verifyDepositSignatureAndMessageRoot,
};
