import { base, mainnet, sonic } from 'viem/chains'

import { chainState } from '@utils/chainState'

import {
  DAI_ADDRESS,
  EETH_ADDRESS,
  FRXETH_ADDRESS,
  LEGACY_OGN_STAKING_IMPLEMENTATION,
  OETH_BEACON_PROOFS,
  OETH_COMPOUND_STAKING_SSV_STRATEGIES,
  OETH_COMPOUND_STAKING_STRATEGY_VIEW,
  OETH_CURVE_WETH_AMO_STRATEGY,
  OETH_DRIPPER_ADDRESS,
  OETH_ETH_AMO_METAPOOL,
  OETH_ETH_PRICE_FEED,
  OETH_FIXED_RATE_DRIPPER,
  OETH_HARVESTER_ADDRESS,
  OETH_HARVESTER_SIMPLE,
  OETH_MORPHO_AAVE_ADDRESS,
  OETH_NATIVE_STAKING_FEE_ACCUMULATORS,
  OETH_NATIVE_STRATEGIES,
  OETH_STRATEGY_BALANCER_ADDRESS,
  OETH_WETH_ARM,
  OETH_ZAPPER_ADDRESS,
  OGN_GOVERNANCE_ADDRESS,
  OGV_OGN_MIGRATOR_ADDRESS,
  OUSD_HARVESTER_ADDRESS,
  OUSD_LUSD_STRATEGY_DEPRECATED,
  OUSD_OLD_BUYBACK_1,
  OUSD_OLD_VAULT,
  OUSD_ORACLE_ROUTER,
  PRIME_ETH_LRT_DEPOSIT_POOL,
  PYUSD_ADDRESS,
  RETH_ADDRESS,
  STETH_ADDRESS,
  USDC_ADDRESS,
  USDG_ADDRESS,
  USDT_ADDRESS,
  VEOGV_ADDRESS,
  WEETH_ADDRESS,
  WSTETH_ADDRESS,
  XOGN_ADDRESS,
  YNLSDE_ADDRESS,
  addresses,
  poolBoosters,
} from './addresses'
import { baseAddresses } from './addresses-base'
import { sonicAddresses } from './addresses-sonic'
import { EXTERNAL_ADDR_TO_NAME } from './external-names'
import {
  CDAI,
  CHAINLINK_KEEPER_REGISTRY,
  CHAINLINK_ORACLE,
  COMP,
  COMPENSATION_CLAIMS,
  COMPOUND_COMPTROLLER,
  COMPOUND_COMPTROLLER_G7,
  COMPOUND_GOVERNOR_ALPHA,
  COMPOUND_GOVERNOR_BRAVO,
  COMPOUND_TIMELOCK,
  CURVE_3CRV_TOKEN,
  CURVE_3POOL,
  CURVE_ANOTHER_3POOL,
  CURVE_ARAGON_51,
  CURVE_ARAGON_60,
  CURVE_CRV_TOKEN,
  CURVE_METAPOOL,
  CUSDC,
  CUSDT,
  CVX,
  DRIPPER,
  FLIPPER,
  FLUX_DAO,
  FLUX_TIMELOCK,
  GOVERNANCE,
  GOVERNANCE_TIMELOCK,
  GOVERNOR,
  GOVERNORV2,
  GOVERNORV3,
  LINK,
  LUSD,
  METAMASK_SWAP_ROUTER,
  MISTX_ROUTER,
  MIX_ORACLE,
  OETH,
  OETH_BUYBACK_PROXY,
  OETH_ZAPPER,
  OGN,
  OGN_REWARDS_SOURCE,
  OGN_STAKING,
  OGV,
  OGV_BUYBACK_LEGACY,
  ONE_INCH_V3,
  OUSD,
  OUSD_BUYBACK_PROXY,
  OUSD_KEEPER,
  OX_EXCHANGE,
  REWARDS_SOURCE,
  STORY_STAKING_SEASON_ONE,
  STORY_STAKING_SEASON_THREE,
  STORY_STAKING_SEASON_TWO,
  STORY_STAKING_SERIES,
  STRAT3POOL,
  STRATAAVE2,
  STRATAAVEDAI,
  STRATCOMP1,
  STRATCOMP2,
  STRATCONVEX1,
  SUSHISWAP,
  UNISWAP_V2,
  UNISWAP_V3_ROUTER,
  WETH,
  WOETH,
} from './ousd-analytics'
import {
  FLUX_STRAT,
  FRAX_ETH_STRATEGY,
  MAKER_DSR_STRAT,
  MORPHO,
  MORPHO_AAVE,
  OETH_CURVE_AMO_STRATEGY,
  OETH_VAULT,
  OUSD_METASTRAT,
  OUSD_VAULT,
} from './strategies-py'

const AAVE_GOVERNANCE_ADDRESS = '0x9aee0b04504cef83a65ac3f0e838d0593bcb2bc7'

export const CONTRACT_ADDR_TO_NAME: Record<number, Record<string, string | undefined>> = {
  [mainnet.id]: {
    [OUSD]: 'OUSD',
    [COMP]: 'COMP Token',
    [OUSD_VAULT]: 'OUSD Vault',
    [GOVERNANCE]: 'OUSD Governance (old)',
    [GOVERNANCE_TIMELOCK]: 'Mainnet Timelock',
    [MIX_ORACLE]: 'MixOracle',
    [CHAINLINK_ORACLE]: 'ChainlinkOracle',
    [OGN_STAKING]: 'OGN Staking',
    [XOGN_ADDRESS]: 'xOGN',
    [STORY_STAKING_SERIES]: 'Story Staking Series',
    [STORY_STAKING_SEASON_ONE]: 'Season One',
    [STORY_STAKING_SEASON_TWO]: 'Season Two',
    [STORY_STAKING_SEASON_THREE]: 'Season Three',
    [STRATCOMP1]: 'Compound Strategy',
    [STRATCOMP2]: 'Compound Strategy',
    [STRATAAVEDAI]: 'Aave Strategy',
    [STRATAAVE2]: 'Aave Strategy',
    [STRAT3POOL]: '3Pool Strategy',
    [STRATCONVEX1]: 'Convex Strategy',
    [COMPOUND_TIMELOCK]: 'Compound Timelock',
    [COMPOUND_GOVERNOR_ALPHA]: 'Compound Governor Alpha',
    [COMPOUND_GOVERNOR_BRAVO]: 'Compound Governor Bravo',
    [COMPOUND_COMPTROLLER]: 'Compound Comptroller/Unitroller',
    [COMPOUND_COMPTROLLER_G7]: 'StdComptrollerG7',
    [CDAI]: 'cDAI',
    [CUSDT]: 'cUSDT',
    [CUSDC]: 'cUSDC',
    [LUSD]: 'LUSD',
    [COMPENSATION_CLAIMS]: 'Compensation Claims',
    [CURVE_CRV_TOKEN]: 'CRV Token',
    [CURVE_3CRV_TOKEN]: '3CRV Token',
    [CURVE_3POOL]: '3Pool Swap Contract',
    [CURVE_ARAGON_51]: 'Curve Aragon Voting (51%)',
    [CURVE_ARAGON_60]: 'Curve Aragon Voting (60%)',
    [DRIPPER]: 'OUSD Dripper',
    [GOVERNOR]: 'Origin Governor V1',
    [GOVERNORV2]: 'Origin Governor V2',
    [GOVERNORV3]: 'Origin Governor V3',
    [addresses.multisig['5/8']]: 'Mainnet Multisig 5/8',
    [addresses.multisig['2/8']]: 'Mainnet Multisig 2/8',
    [addresses.multisig['multichain-guardian']]: 'Multichain Guardian',
    [METAMASK_SWAP_ROUTER]: 'Metamask Swap Router',
    [FLIPPER]: 'OUSD Swap',
    [UNISWAP_V3_ROUTER]: 'Uniswap V3 Router',
    [OX_EXCHANGE]: '0x Exchange',
    [ONE_INCH_V3]: '1inch V3',
    [SUSHISWAP]: 'SushiSwap',
    [UNISWAP_V2]: 'Uniswap V2 Router',
    [MISTX_ROUTER]: 'MistX Router',
    [CURVE_ANOTHER_3POOL]: 'Curve 3Pool 2',
    [CURVE_METAPOOL]: 'Curve USDT/OUSD Metapool',
    [CHAINLINK_KEEPER_REGISTRY]: 'Chainlink KeeperRegistry',
    [OUSD_KEEPER]: 'OUSD Keeper',
    [LINK]: 'LINK',
    [OGV]: 'OGV',
    [OGN]: 'OGN',
    [OGV_BUYBACK_LEGACY]: 'OGV Buyback (Legacy)',
    [OUSD_BUYBACK_PROXY]: 'OUSD Buyback',
    [OETH_BUYBACK_PROXY]: 'OETH Buyback',
    [REWARDS_SOURCE]: 'RewardsSource',
    [OGN_REWARDS_SOURCE]: 'OGN RewardsSource',
    [FLUX_DAO]: 'Flux DAO',
    [FLUX_TIMELOCK]: 'Flux Timelock',

    [MAKER_DSR_STRAT]: 'Maker DSR Strategy',
    [FLUX_STRAT]: 'Flux Strategy',
    [MORPHO_AAVE]: 'Morpho Aave Strategy',
    [MORPHO]: 'Morpho Strategy',
    [OUSD_METASTRAT]: 'OUSD Metapool Strategy',

    // Tokens
    [WETH]: 'WETH',
    [CVX]: 'CVX',
    [VEOGV_ADDRESS]: 'veOGV',
    [USDT_ADDRESS]: 'USDT',
    [USDC_ADDRESS]: 'USDC',
    [USDG_ADDRESS]: 'USDG',
    [PYUSD_ADDRESS]: 'PYUSD',
    [DAI_ADDRESS]: 'DAI',
    [FRXETH_ADDRESS]: 'frxETH',
    [RETH_ADDRESS]: 'rETH',
    [STETH_ADDRESS]: 'stETH',
    [WSTETH_ADDRESS]: 'wstETH',
    [EETH_ADDRESS]: 'eETH',
    [WEETH_ADDRESS]: 'weETH',
    [addresses.tokens.USDe]: 'USDe',
    [addresses.tokens.sUSDe]: 'sUSDe',

    // ARM Contracts
    [addresses.arms['ARM-USDe-sUSDe'].address]: 'Origin Ethena ARM',
    [addresses.arms['ARM-USDe-sUSDe'].capManager]: 'Ethena ARM Cap Manager',
    [addresses.arms['ARM-USDe-sUSDe'].morphoStrategy!]: 'Ethena ARM AAVE Strategy',
    [addresses.arms['ARM-WETH-eETH'].address]: 'EtherFi ARM',
    [addresses.arms['ARM-WETH-eETH'].capManager]: 'EtherFi ARM Cap Manager',
    [addresses.arms['ARM-WETH-eETH'].zapper!]: 'EtherFi ARM Zapper',
    [addresses.arms['ARM-WETH-eETH'].morphoStrategy!]: 'EtherFi ARM Morpho Strategy',
    [addresses.arms['ARM-WETH-stETH'].address]: 'Lido ARM',
    [addresses.arms['ARM-WETH-stETH'].capManager]: 'Lido ARM Cap Manager',
    [addresses.arms['ARM-WETH-stETH'].zapper!]: 'Lido ARM Zapper',
    [addresses.arms['ARM-WETH-stETH'].morphoStrategy!]: 'Lido ARM Morpho Strategy',
    [addresses.arms['ARM-WETH-stETH'].pendleSy!]: 'Lido ARM Pendle SY',
    [addresses.arms['ARM-WETH'].address]: 'Origin WETH ARM',
    [addresses.arms['ARM-WETH'].capManager]: 'WETH ARM Cap Manager',
    [addresses.arms['ARM-USDC'].address]: 'Origin USDC ARM',
    [addresses.arms['ARM-USDC'].capManager]: 'USDC ARM Cap Manager',
    [addresses.armOperators.ethenaEtherfi]: 'ARM Operator (Ethena/EtherFi)',
    [addresses.armOperators.originOETH]: 'ARM Operator (Origin OETH)',

    [OETH_STRATEGY_BALANCER_ADDRESS]: 'OETH Balancer rETH Strategy',
    [OETH_MORPHO_AAVE_ADDRESS]: 'OETH Morpho Aave Strategy',
    ...OETH_NATIVE_STRATEGIES.reduce(
      (map, strategy, index) => {
        map[strategy.address] = `OETH Native Staking Strategy ${index + 1}`
        return map
      },
      {} as Record<string, string>,
    ),
    ...OETH_COMPOUND_STAKING_SSV_STRATEGIES.reduce(
      (map, strategy, index) => {
        map[strategy.address] = `OETH Compound Staking SSV Strategy ${index + 1}`
        return map
      },
      {} as Record<string, string>,
    ),
    [OGV_OGN_MIGRATOR_ADDRESS]: 'OGV Migrator',
    [OGN_GOVERNANCE_ADDRESS]: 'OGN Governance',
    [AAVE_GOVERNANCE_ADDRESS]: 'Aave Governance',

    // OUSD Contracts
    [OUSD_HARVESTER_ADDRESS]: 'OUSD Harvester',
    [OUSD_ORACLE_ROUTER]: 'OUSD Oracle Router',
    [OUSD_OLD_VAULT]: 'OUSD Old Vault (Deprecated)',
    [OUSD_OLD_BUYBACK_1]: 'OUSD Old Buyback 1 (Deprecated)',
    [LEGACY_OGN_STAKING_IMPLEMENTATION]: 'Original OGN Staking Implementation (Legacy)',
    [addresses.strategies.ousd.MetaMorphoStrategy]: 'OUSD Meta Morpho Strategy',
    [addresses.strategies.ousd.GauntletPrimeUSDTStrategy]: 'OUSD Gauntlet Prime USDT Strategy',
    [addresses.strategies.ousd.GauntletPrimeUSDCStrategy]: 'OUSD Gauntlet Prime USDC Strategy',
    [addresses.strategies.ousd.SkySavingsRateStrategy]: 'OUSD Sky Savings Rate Strategy',
    [addresses.strategies.ousd.OUSDCurveAMOStrategy]: 'OUSD Curve AMO Strategy',
    [addresses.strategies.ousd.MorphoV2Strategy]: 'OUSD Morpho V2 Strategy',
    [OUSD_LUSD_STRATEGY_DEPRECATED]: 'OUSD LUSD Strategy (Deprecated)',

    // OETH Contracts
    [OETH]: 'OETH',
    [WOETH]: 'WOETH',
    [OETH_VAULT]: 'OETH Vault',
    [FRAX_ETH_STRATEGY]: 'FraxETH Strategy',
    [OETH_ZAPPER]: 'OETH Zapper',
    [OETH_CURVE_AMO_STRATEGY]: 'OETH/ETH Curve AMO Strategy',
    [OETH_HARVESTER_ADDRESS]: 'OETH Harvester',
    [OETH_HARVESTER_SIMPLE]: 'OETH Harvester Simple',
    [OETH_ZAPPER_ADDRESS]: 'OETH Zapper',
    [OETH_DRIPPER_ADDRESS]: 'OETH Dripper',
    [OETH_FIXED_RATE_DRIPPER]: 'OETH Fixed Rate Dripper',
    [OETH_ETH_AMO_METAPOOL]: 'OETH Curve AMO Metapool',
    [OETH_CURVE_WETH_AMO_STRATEGY]: 'OETH Curve WETH AMO Strategy',
    [OETH_COMPOUND_STAKING_STRATEGY_VIEW]: 'OETH Compounding Staking Strategy View',
    [OETH_BEACON_PROOFS]: 'OETH Beacon Proofs',
    [OETH_WETH_ARM]: 'Origin OETH ARM',
    [OETH_ETH_PRICE_FEED]: 'OETH/ETH Price Feed (Chainlink)',
    ...OETH_NATIVE_STAKING_FEE_ACCUMULATORS.reduce(
      (map, acc) => {
        map[acc.address] = `OETH Native Staking Fee Accumulator ${acc.strategy}`
        return map
      },
      {} as Record<string, string>,
    ),

    // primeETH Contracts
    [PRIME_ETH_LRT_DEPOSIT_POOL]: 'PrimeETH Deposit Pool',
    '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee': 'ETH',
    [YNLSDE_ADDRESS]: 'ynLSDe',

    // Pool Booster Contracts
    [poolBoosters.centralRegistry]: 'Pool Booster Central Registry',
    [poolBoosters.factoryMerkl]: 'Pool Booster Factory (Merkl)',
    [poolBoosters.factoryCurve]: 'Pool Booster Factory (Curve)',
    [poolBoosters.ousdFactoryCurve]: 'Pool Booster Factory (OUSD Curve)',

    // Misc
    '0x17768cfd6030e2b65eb5086e34a512fde5dc1f1f': 'danielvf.eth',
    '0xc8f2cf4742c86295653f893214725813b16f7410': 'ARM Gnosis Safe',
  },
  [base.id]: {
    // OETH Base Contracts / Addresses
    [baseAddresses.superOETHb.address]: 'superOETHb',
    [baseAddresses.superOETHb.wrapped]: 'wsuperOETHb',
    [baseAddresses.superOETHb.vault]: 'Super OETH Base Vault',
    [baseAddresses.superOETHb.oracleRouter]: 'Super OETH Base Price Oracle',
    [baseAddresses.superOETHb.woethExchangeRateOracle]: 'wOETH Exchange Rate Oracle (Chainlink)',
    [baseAddresses.superOETHb.dripper]: 'Super OETH Dripper',
    [baseAddresses.superOETHb.zapper]: 'Super OETH Zapper',
    [baseAddresses.superOETHb.strategies.bridgedWOETH]: 'Super OETH - Bridged WOETH Strategy',
    [baseAddresses.superOETHb.strategies.amo]: 'Super OETH - Aerodrome AMO Strategy',
    [baseAddresses.superOETHb.strategies.curveAMO]: 'Super OETH - Curve AMO Strategy',
    [baseAddresses.multisig['5/8']]: 'Base Multisig 5/8',
    [baseAddresses.multisig['2/8']]: 'Base Multisig 2/8',
    [baseAddresses.multisig['multichain-guardian']]: 'Multichain Guardian',
    [baseAddresses.multisig.reservoir]: 'Super OETH Base Reservoir',
    [baseAddresses.timelock]: 'Base Timelock',
    [baseAddresses.baseHotWallet]: 'Base Hot Wallet',

    // Base Tokens
    [baseAddresses.tokens.bridgedWOETH]: 'WOETH',
    [baseAddresses.tokens.OGN]: 'OGN (Base)',
    [baseAddresses.tokens.WETH]: 'WETH (Base)',
    [baseAddresses.tokens.cbETH]: 'cbETH (Base)',
    [baseAddresses.tokens.USDC]: 'USDC (Base)',
    [baseAddresses.tokens.AERO]: 'AERO',

    // Aerodrome Pools
    [baseAddresses.aerodrome.pools['vAMM-WETH/OGN'].address]: 'Aerodrome: vAMM-WETH/OGN',
    [baseAddresses.aerodrome.pools['vAMM-OGN/superOETHb'].address]: 'Aerodrome: vAMM-OGN/superOETHb',
    [baseAddresses.aerodrome.pools['CL1-WETH/superOETHb'].address]: 'Aerodrome: CL1-WETH/superOETHb',

    // Pool Booster Contracts (Base)
    [baseAddresses.poolBoosters.centralRegistry]: 'Pool Booster Central Registry (Base)',
    [baseAddresses.poolBoosters.factoryMerkl]: 'Pool Booster Factory Merkl (Base)',
  },
  [sonic.id]: {
    [sonicAddresses.OS.address]: 'OS',
    [sonicAddresses.OS.dripper]: 'OS Dripper',
    [sonicAddresses.OS.harvester]: 'OS Harvester',
    [sonicAddresses.OS.oracleRouter]: 'OS Price Oracle',
    [sonicAddresses.OS.vault]: 'OS Vault',
    [sonicAddresses.OS.vaultAdmin]: 'OS Vault Admin',
    [sonicAddresses.OS.vaultValueChecker]: 'OS Vault Value Checker',
    [sonicAddresses.OS.wrapped]: 'Wrapped OS',
    [sonicAddresses.OS.zapper]: 'OS Zapper',
    [sonicAddresses.OS.strategies.sonicStaking]: 'OS Sonic Staking Strategy',
    [sonicAddresses.OS.strategies.swapXAMO]: 'OS SwapX AMO Strategy',
    [sonicAddresses.contracts.Multicall3]: 'Multicall3',
    [sonicAddresses.contracts.SFC]: 'SFC',
    [sonicAddresses.multisig.admin]: 'Multisig Admin',
    [sonicAddresses.multisig.guardian]: 'Multisig Guardian',
    [sonicAddresses.tokens.USDC]: 'USDC',
    [sonicAddresses.tokens.WETH]: 'WETH',
    [sonicAddresses.tokens.wS]: 'Wrapped S',
    // In the case of Zapper, it sends 0xee... even for S.
    //  Potentially an issue later down the line...
    '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee': 'S',
  },
}

// DB-loaded wallet labels (address → description), loaded at startup from Railway DB
const walletLabels = new Map<string, string>()

/**
 * Load wallet labels from the Railway database.
 * Call once at startup before processing begins.
 */
export const loadWalletLabels = async (): Promise<void> => {
  const url = process.env.RAILWAY_DATABASE_URL
  if (!url) {
    console.log('Wallet labels: RAILWAY_DATABASE_URL not set, skipping')
    return
  }
  try {
    // @ts-expect-error pg has no type declarations in this project
    const pg = await import('pg')
    const pool = new pg.default.Pool({ connectionString: url })
    try {
      const { rows } = await pool.query('SELECT address, description FROM wallet_label')
      for (const row of rows) {
        if (row.address && row.description) {
          walletLabels.set(row.address.toLowerCase(), row.description)
        }
      }
      console.log(`Wallet labels: loaded ${walletLabels.size} labels from DB`)
    } finally {
      await pool.end()
    }
  } catch (err) {
    console.error('Failed to load wallet labels:', err)
  }
}

export const getAddressesPyName = (address?: string): string | undefined =>
  address
    ? CONTRACT_ADDR_TO_NAME[chainState.current?.id ?? mainnet.id]?.[address.toLowerCase()] ??
      CONTRACT_ADDR_TO_NAME[base.id]?.[address.toLowerCase()] ??
      CONTRACT_ADDR_TO_NAME[sonic.id]?.[address.toLowerCase()] ??
      EXTERNAL_ADDR_TO_NAME[address.toLowerCase()] ??
      walletLabels.get(address.toLowerCase())
    : undefined

export const getAddressName = (address: string): string =>
  CONTRACT_ADDR_TO_NAME[chainState.current?.id ?? mainnet.id]?.[address.toLowerCase()] ??
  CONTRACT_ADDR_TO_NAME[base.id]?.[address.toLowerCase()] ??
  CONTRACT_ADDR_TO_NAME[sonic.id]?.[address.toLowerCase()] ??
  EXTERNAL_ADDR_TO_NAME[address.toLowerCase()] ??
  walletLabels.get(address.toLowerCase()) ??
  address
