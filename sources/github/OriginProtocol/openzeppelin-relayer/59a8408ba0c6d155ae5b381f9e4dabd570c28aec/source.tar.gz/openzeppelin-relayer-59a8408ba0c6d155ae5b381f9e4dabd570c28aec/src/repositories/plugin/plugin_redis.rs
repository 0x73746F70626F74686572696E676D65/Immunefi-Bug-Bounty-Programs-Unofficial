//! Redis-backed implementation of the PluginRepository.

use crate::models::{PaginationQuery, PluginModel, RepositoryError};
use crate::repositories::redis_base::RedisRepository;
use crate::repositories::{BatchRetrievalResult, PaginatedResult, PluginRepositoryTrait};
use crate::utils::RedisConnections;
use async_trait::async_trait;
use lru::LruCache;
use parking_lot::RwLock;
use redis::AsyncCommands;
use std::fmt;
use std::num::NonZeroUsize;
use std::sync::Arc;
use std::time::Instant;
use tracing::{debug, error, warn};

const PLUGIN_PREFIX: &str = "plugin";
const PLUGIN_LIST_KEY: &str = "plugin_list";
const COMPILED_CODE_PREFIX: &str = "compiled_code";
const SOURCE_HASH_PREFIX: &str = "source_hash";

#[derive(Clone)]
struct CachedCompiledCode {
    code: String,
    cached_at: Instant,
}

#[derive(Clone)]
pub struct RedisPluginRepository {
    pub connections: Arc<RedisConnections>,
    pub key_prefix: String,
    compiled_code_cache: Arc<RwLock<LruCache<String, CachedCompiledCode>>>,
}

impl RedisRepository for RedisPluginRepository {}

impl RedisPluginRepository {
    pub fn new(
        connections: Arc<RedisConnections>,
        key_prefix: String,
    ) -> Result<Self, RepositoryError> {
        if key_prefix.is_empty() {
            return Err(RepositoryError::InvalidData(
                "Redis key prefix cannot be empty".to_string(),
            ));
        }

        Ok(Self {
            connections,
            key_prefix,
            compiled_code_cache: Arc::new(RwLock::new(LruCache::new(
                NonZeroUsize::new(100).unwrap(),
            ))),
        })
    }

    /// Generate key for plugin data: plugin:{plugin_id}
    fn plugin_key(&self, plugin_id: &str) -> String {
        format!("{}:{}:{}", self.key_prefix, PLUGIN_PREFIX, plugin_id)
    }

    /// Generate key for plugin list: plugin_list (paginated list of plugin IDs)
    fn plugin_list_key(&self) -> String {
        format!("{}:{}", self.key_prefix, PLUGIN_LIST_KEY)
    }

    /// Generate key for compiled code: compiled_code:{plugin_id}
    fn compiled_code_key(&self, plugin_id: &str) -> String {
        format!("{}:{}:{}", self.key_prefix, COMPILED_CODE_PREFIX, plugin_id)
    }

    /// Generate key for source hash: source_hash:{plugin_id}
    fn source_hash_key(&self, plugin_id: &str) -> String {
        format!("{}:{}:{}", self.key_prefix, SOURCE_HASH_PREFIX, plugin_id)
    }

    /// Get plugin by ID using an existing connection.
    /// This method is useful to prevent creating new connections for
    /// getting individual plugins on list operations.
    ///
    /// # Arguments
    ///
    /// * `id` - The ID of the plugin to get.
    /// * `conn` - The connection to use.
    async fn get_by_id_with_connection(
        &self,
        id: &str,
        conn: &mut deadpool_redis::Connection,
    ) -> Result<Option<PluginModel>, RepositoryError> {
        if id.is_empty() {
            return Err(RepositoryError::InvalidData(
                "Plugin ID cannot be empty".to_string(),
            ));
        }
        let key = self.plugin_key(id);

        debug!(plugin_id = %id, "fetching plugin data");

        let json: Option<String> = conn
            .get(&key)
            .await
            .map_err(|e| self.map_redis_error(e, "get_plugin_by_id"))?;

        match json {
            Some(json) => {
                debug!(plugin_id = %id, "found plugin data");
                let plugin = self.deserialize_entity::<PluginModel>(&json, id, "plugin")?;
                Ok(Some(plugin))
            }
            None => {
                debug!(plugin_id = %id, "no plugin found");
                Ok(None)
            }
        }
    }

    async fn get_by_ids(
        &self,
        ids: &[String],
    ) -> Result<BatchRetrievalResult<PluginModel>, RepositoryError> {
        if ids.is_empty() {
            debug!("no plugin IDs provided for batch fetch");
            return Ok(BatchRetrievalResult {
                results: vec![],
                failed_ids: vec![],
            });
        }

        let mut conn = self
            .get_connection(self.connections.reader(), "get_by_ids")
            .await?;
        let keys: Vec<String> = ids.iter().map(|id| self.plugin_key(id)).collect();

        let values: Vec<Option<String>> = conn
            .mget(&keys)
            .await
            .map_err(|e| self.map_redis_error(e, "batch_fetch_plugins"))?;

        let mut plugins = Vec::new();
        let mut failed_count = 0;
        let mut failed_ids = Vec::new();
        for (i, value) in values.into_iter().enumerate() {
            match value {
                Some(json) => match self.deserialize_entity(&json, &ids[i], "plugin") {
                    Ok(plugin) => plugins.push(plugin),
                    Err(e) => {
                        failed_count += 1;
                        error!(plugin_id = %ids[i], error = %e, "failed to deserialize plugin");
                        failed_ids.push(ids[i].clone());
                    }
                },
                None => {
                    warn!(plugin_id = %ids[i], "plugin not found in batch fetch");
                }
            }
        }

        if failed_count > 0 {
            warn!(failed_count = %failed_count, total_count = %ids.len(), "failed to deserialize plugins in batch");
        }

        Ok(BatchRetrievalResult {
            results: plugins,
            failed_ids,
        })
    }
}

impl fmt::Debug for RedisPluginRepository {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RedisPluginRepository")
            .field("pool", &"<Pool>")
            .field("key_prefix", &self.key_prefix)
            .finish()
    }
}

#[async_trait]
impl PluginRepositoryTrait for RedisPluginRepository {
    async fn get_by_id(&self, id: &str) -> Result<Option<PluginModel>, RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.reader(), "get_by_id")
            .await?;
        self.get_by_id_with_connection(id, &mut conn).await
    }

    async fn add(&self, plugin: PluginModel) -> Result<(), RepositoryError> {
        if plugin.id.is_empty() {
            return Err(RepositoryError::InvalidData(
                "Plugin ID cannot be empty".to_string(),
            ));
        }

        if plugin.path.is_empty() {
            return Err(RepositoryError::InvalidData(
                "Plugin path cannot be empty".to_string(),
            ));
        }

        let mut conn = self
            .get_connection(self.connections.primary(), "add")
            .await?;
        let key = self.plugin_key(&plugin.id);
        let list_key = self.plugin_list_key();

        debug!(plugin_id = %plugin.id, "adding plugin");

        // Check if plugin already exists
        let exists: bool = conn
            .exists(&key)
            .await
            .map_err(|e| self.map_redis_error(e, "check_plugin_exists"))?;

        if exists {
            return Err(RepositoryError::ConstraintViolation(format!(
                "Plugin with ID {} already exists",
                plugin.id
            )));
        }

        // Serialize plugin
        let json = self.serialize_entity(&plugin, |p| &p.id, "plugin")?;

        // Use a pipeline to ensure atomicity
        let mut pipe = redis::pipe();
        pipe.atomic();
        pipe.set(&key, &json);
        pipe.sadd(&list_key, &plugin.id);

        pipe.exec_async(&mut conn).await.map_err(|e| {
            error!(plugin_id = %plugin.id, error = %e, "failed to add plugin");
            self.map_redis_error(e, "add_plugin")
        })?;

        debug!(plugin_id = %plugin.id, "successfully added plugin");
        Ok(())
    }

    async fn update(&self, plugin: PluginModel) -> Result<PluginModel, RepositoryError> {
        if plugin.id.is_empty() {
            return Err(RepositoryError::InvalidData(
                "Plugin ID cannot be empty".to_string(),
            ));
        }

        let mut conn = self
            .get_connection(self.connections.primary(), "update")
            .await?;
        let key = self.plugin_key(&plugin.id);

        debug!(plugin_id = %plugin.id, "updating plugin");

        // Check if plugin exists
        let exists: bool = conn
            .exists(&key)
            .await
            .map_err(|e| self.map_redis_error(e, &format!("check_plugin_exists_{}", plugin.id)))?;

        if !exists {
            return Err(RepositoryError::NotFound(format!(
                "Plugin with ID {} not found",
                plugin.id
            )));
        }

        // Serialize plugin
        let json = self.serialize_entity(&plugin, |p| &p.id, "plugin")?;

        // Update the plugin data
        conn.set::<_, _, ()>(&key, &json)
            .await
            .map_err(|e| self.map_redis_error(e, &format!("update_plugin_{}", plugin.id)))?;

        debug!(plugin_id = %plugin.id, "successfully updated plugin");
        Ok(plugin)
    }

    async fn list_paginated(
        &self,
        query: PaginationQuery,
    ) -> Result<PaginatedResult<PluginModel>, RepositoryError> {
        if query.page == 0 {
            return Err(RepositoryError::InvalidData(
                "Page number must be greater than 0".to_string(),
            ));
        }

        if query.per_page == 0 {
            return Err(RepositoryError::InvalidData(
                "Per page count must be greater than 0".to_string(),
            ));
        }

        let (total, ids_to_query) = {
            let mut conn = self
                .get_connection(self.connections.reader(), "list_paginated")
                .await?;
            let plugin_list_key = self.plugin_list_key();

            // Get total count
            let total: u64 = conn
                .scard(&plugin_list_key)
                .await
                .map_err(|e| self.map_redis_error(e, "list_paginated_count"))?;

            if total == 0 {
                return Ok(PaginatedResult {
                    items: vec![],
                    total: 0,
                    page: query.page,
                    per_page: query.per_page,
                });
            }

            // Get all IDs and paginate in memory
            let all_ids: Vec<String> = conn
                .smembers(&plugin_list_key)
                .await
                .map_err(|e| self.map_redis_error(e, "list_paginated_members"))?;

            let start = ((query.page - 1) * query.per_page) as usize;
            let end = (start + query.per_page as usize).min(all_ids.len());

            (total, all_ids[start..end].to_vec())
            // Connection dropped here before nested call to avoid connection doubling
        };

        let items = self.get_by_ids(&ids_to_query).await?;

        Ok(PaginatedResult {
            items: items.results.clone(),
            total,
            page: query.page,
            per_page: query.per_page,
        })
    }

    async fn count(&self) -> Result<usize, RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.reader(), "count")
            .await?;
        let plugin_list_key = self.plugin_list_key();

        let count: u64 = conn
            .scard(&plugin_list_key)
            .await
            .map_err(|e| self.map_redis_error(e, "count_plugins"))?;

        Ok(count as usize)
    }

    async fn has_entries(&self) -> Result<bool, RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.reader(), "has_entries")
            .await?;
        let plugin_list_key = self.plugin_list_key();

        debug!("checking if plugin entries exist");

        let exists: bool = conn
            .exists(&plugin_list_key)
            .await
            .map_err(|e| self.map_redis_error(e, "has_entries_check"))?;

        debug!(exists = %exists, "plugin entries exist");
        Ok(exists)
    }

    async fn drop_all_entries(&self) -> Result<(), RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.primary(), "drop_all_entries")
            .await?;
        let plugin_list_key = self.plugin_list_key();

        debug!("dropping all plugin entries");

        // Get all plugin IDs first
        let plugin_ids: Vec<String> = conn
            .smembers(&plugin_list_key)
            .await
            .map_err(|e| self.map_redis_error(e, "drop_all_entries_get_ids"))?;

        if plugin_ids.is_empty() {
            debug!("no plugin entries to drop");
            return Ok(());
        }

        // Use pipeline for atomic operations
        let mut pipe = redis::pipe();
        pipe.atomic();

        // Delete all individual plugin entries
        for plugin_id in &plugin_ids {
            let plugin_key = self.plugin_key(plugin_id);
            pipe.del(&plugin_key);
        }

        // Delete the plugin list key
        pipe.del(&plugin_list_key);

        pipe.exec_async(&mut conn)
            .await
            .map_err(|e| self.map_redis_error(e, "drop_all_entries_pipeline"))?;

        debug!(count = %plugin_ids.len(), "dropped plugin entries");
        Ok(())
    }

    // Compiled code cache methods

    async fn get_compiled_code(&self, plugin_id: &str) -> Result<Option<String>, RepositoryError> {
        const CACHE_TTL_SECS: u64 = 300; // 5 minutes

        // Check memory cache first - extract data without holding lock across await
        // The cache is invalidated by store_compiled_code and invalidate_compiled_code,
        // so we can trust it within the TTL without calling Redis to verify
        let cached_code = {
            let cache = self.compiled_code_cache.read();
            cache.peek(plugin_id).and_then(|cached| {
                if cached.cached_at.elapsed().as_secs() < CACHE_TTL_SECS {
                    Some(cached.code.clone())
                } else {
                    None
                }
            })
        };

        if let Some(code) = cached_code {
            return Ok(Some(code));
        }

        // Cache miss or expired - fetch from Redis
        let mut conn = self
            .get_connection(self.connections.reader(), "get_compiled_code")
            .await?;
        let key = self.compiled_code_key(plugin_id);

        let code: Option<String> = conn
            .get(&key)
            .await
            .map_err(|e| self.map_redis_error(e, &format!("get_compiled_code_{plugin_id}")))?;

        // Update cache if found - fetch hash in same connection batch would be better
        // but for now we avoid the extra Redis call since the hash is only used for
        // external invalidation which already clears the in-memory cache
        if let Some(ref code_str) = code {
            let mut cache = self.compiled_code_cache.write();
            cache.put(
                plugin_id.to_string(),
                CachedCompiledCode {
                    code: code_str.clone(),
                    cached_at: Instant::now(),
                },
            );
        }

        Ok(code)
    }

    async fn store_compiled_code(
        &self,
        plugin_id: &str,
        compiled_code: &str,
        source_hash: Option<&str>,
    ) -> Result<(), RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.primary(), "store_compiled_code")
            .await?;
        let code_key = self.compiled_code_key(plugin_id);

        debug!(plugin_id = %plugin_id, "storing compiled code in Redis");

        // Use pipeline to store both code and hash atomically
        let mut pipe = redis::pipe();
        pipe.atomic();
        pipe.set(&code_key, compiled_code);

        if let Some(hash) = source_hash {
            let hash_key = self.source_hash_key(plugin_id);
            pipe.set(&hash_key, hash);
        }

        pipe.exec_async(&mut conn)
            .await
            .map_err(|e| self.map_redis_error(e, &format!("store_compiled_code_{plugin_id}")))?;

        // Invalidate memory cache
        self.compiled_code_cache.write().pop(plugin_id);

        Ok(())
    }

    async fn invalidate_compiled_code(&self, plugin_id: &str) -> Result<(), RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.primary(), "invalidate_compiled_code")
            .await?;
        let code_key = self.compiled_code_key(plugin_id);
        let hash_key = self.source_hash_key(plugin_id);

        debug!(plugin_id = %plugin_id, "invalidating compiled code in Redis");

        // Use pipeline to delete both keys atomically
        let mut pipe = redis::pipe();
        pipe.atomic();
        pipe.del(&code_key);
        pipe.del(&hash_key);

        pipe.exec_async(&mut conn).await.map_err(|e| {
            self.map_redis_error(e, &format!("invalidate_compiled_code_{plugin_id}"))
        })?;

        // Invalidate memory cache
        self.compiled_code_cache.write().pop(plugin_id);

        Ok(())
    }

    async fn invalidate_all_compiled_code(&self) -> Result<(), RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.primary(), "invalidate_all_compiled_code")
            .await?;
        let plugin_list_key = self.plugin_list_key();

        debug!("invalidating all compiled code in Redis");

        // Get all plugin IDs from the list
        let plugin_ids: Vec<String> = conn
            .smembers(&plugin_list_key)
            .await
            .map_err(|e| self.map_redis_error(e, "get_plugin_list_for_invalidate"))?;

        // Delete all compiled code and hash keys
        for plugin_id in &plugin_ids {
            let code_key = self.compiled_code_key(plugin_id);
            let hash_key = self.source_hash_key(plugin_id);

            let _ = conn.del::<_, ()>(&code_key).await;
            let _ = conn.del::<_, ()>(&hash_key).await;
        }

        // Clear all cached compiled code
        self.compiled_code_cache.write().clear();

        Ok(())
    }

    async fn has_compiled_code(&self, plugin_id: &str) -> Result<bool, RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.reader(), "has_compiled_code")
            .await?;
        let key = self.compiled_code_key(plugin_id);

        let exists: bool = conn
            .exists(&key)
            .await
            .map_err(|e| self.map_redis_error(e, &format!("exists_compiled_code_{plugin_id}")))?;

        Ok(exists)
    }

    async fn get_source_hash(&self, plugin_id: &str) -> Result<Option<String>, RepositoryError> {
        let mut conn = self
            .get_connection(self.connections.reader(), "get_source_hash")
            .await?;
        let key = self.source_hash_key(plugin_id);

        let hash: Option<String> = conn
            .get(&key)
            .await
            .map_err(|e| self.map_redis_error(e, &format!("get_source_hash_{plugin_id}")))?;

        Ok(hash)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::constants::DEFAULT_PLUGIN_TIMEOUT_SECONDS;
    use crate::models::PluginModel;
    use std::{sync::Arc, time::Duration};

    fn create_test_plugin(id: &str, path: &str) -> PluginModel {
        PluginModel {
            id: id.to_string(),
            path: path.to_string(),
            timeout: Duration::from_secs(DEFAULT_PLUGIN_TIMEOUT_SECONDS),
            emit_logs: false,
            emit_traces: false,
            raw_response: false,
            allow_get_invocation: false,
            config: None,
            forward_logs: false,
        }
    }

    async fn setup_test_repo() -> RedisPluginRepository {
        let redis_url =
            std::env::var("REDIS_URL").unwrap_or_else(|_| "redis://127.0.0.1:6379/".to_string());
        let cfg = deadpool_redis::Config::from_url(&redis_url);
        let pool = Arc::new(
            cfg.builder()
                .expect("Failed to create pool builder")
                .max_size(16)
                .runtime(deadpool_redis::Runtime::Tokio1)
                .build()
                .expect("Failed to build Redis pool"),
        );
        let connections = Arc::new(RedisConnections::new_single_pool(pool));

        let random_id = uuid::Uuid::new_v4().to_string();
        let key_prefix = format!("test_prefix:{random_id}");

        RedisPluginRepository::new(connections, key_prefix)
            .expect("Failed to create Redis plugin repository")
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_new_repository_creation() {
        let repo = setup_test_repo().await;
        assert!(repo.key_prefix.contains("test_prefix"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_new_repository_empty_prefix_fails() {
        let redis_url = "redis://127.0.0.1:6379/";
        let cfg = deadpool_redis::Config::from_url(redis_url);
        let pool = Arc::new(
            cfg.builder()
                .expect("Failed to create pool builder")
                .max_size(16)
                .runtime(deadpool_redis::Runtime::Tokio1)
                .build()
                .expect("Failed to build Redis pool"),
        );
        let connections = Arc::new(RedisConnections::new_single_pool(pool));

        let result = RedisPluginRepository::new(connections, "".to_string());
        assert!(result.is_err());
        assert!(result
            .unwrap_err()
            .to_string()
            .contains("key prefix cannot be empty"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_key_generation() {
        let repo = setup_test_repo().await;

        let plugin_key = repo.plugin_key("test-plugin");
        assert!(plugin_key.contains(":plugin:test-plugin"));

        let list_key = repo.plugin_list_key();
        assert!(list_key.contains(":plugin_list"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_serialize_deserialize_plugin() {
        let repo = setup_test_repo().await;
        let plugin = create_test_plugin("test-plugin", "/path/to/plugin");

        let json = repo.serialize_entity(&plugin, |p| &p.id, "plugin").unwrap();
        let deserialized: PluginModel = repo
            .deserialize_entity(&json, &plugin.id, "plugin")
            .unwrap();

        assert_eq!(plugin.id, deserialized.id);
        assert_eq!(plugin.path, deserialized.path);
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_add_plugin() {
        let repo = setup_test_repo().await;
        let plugin_name = uuid::Uuid::new_v4().to_string();
        let plugin = create_test_plugin(&plugin_name, "/path/to/plugin");

        let result = repo.add(plugin).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_get_plugin() {
        let repo = setup_test_repo().await;
        let plugin_name = uuid::Uuid::new_v4().to_string();
        let plugin = create_test_plugin(&plugin_name, "/path/to/plugin");

        // Add the plugin first
        repo.add(plugin.clone()).await.unwrap();

        // Get the plugin
        let retrieved = repo.get_by_id(&plugin_name).await.unwrap();
        assert!(retrieved.is_some());
        let retrieved = retrieved.unwrap();
        assert_eq!(retrieved.id, plugin.id);
        assert_eq!(retrieved.path, plugin.path);
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_get_nonexistent_plugin() {
        let repo = setup_test_repo().await;

        let result = repo.get_by_id("nonexistent-plugin").await;
        assert!(matches!(result, Ok(None)));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_duplicate_plugin_addition() {
        let repo = setup_test_repo().await;
        let plugin_name = uuid::Uuid::new_v4().to_string();
        let plugin = create_test_plugin(&plugin_name, "/path/to/plugin");

        // Add the plugin first time
        repo.add(plugin.clone()).await.unwrap();

        // Try to add the same plugin again
        let result = repo.add(plugin).await;
        assert!(result.is_err());

        if let Err(RepositoryError::ConstraintViolation(msg)) = result {
            assert!(msg.contains("already exists"));
        } else {
            panic!("Expected ConstraintViolation error");
        }
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_debug_implementation() {
        let repo = setup_test_repo().await;
        let debug_str = format!("{repo:?}");
        assert!(debug_str.contains("RedisPluginRepository"));
        assert!(debug_str.contains("test_prefix"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_error_handling_empty_id() {
        let repo = setup_test_repo().await;

        let result = repo.get_by_id("").await;
        assert!(result.is_err());
        assert!(result
            .unwrap_err()
            .to_string()
            .contains("ID cannot be empty"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_add_plugin_with_empty_id() {
        let repo = setup_test_repo().await;
        let plugin = create_test_plugin("", "/path/to/plugin");

        let result = repo.add(plugin).await;
        assert!(result.is_err());
        assert!(result
            .unwrap_err()
            .to_string()
            .contains("ID cannot be empty"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_add_plugin_with_empty_path() {
        let repo = setup_test_repo().await;
        let plugin = create_test_plugin("test-plugin", "");

        let result = repo.add(plugin).await;
        assert!(result.is_err());
        assert!(result
            .unwrap_err()
            .to_string()
            .contains("path cannot be empty"));
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_get_by_ids_plugins() {
        let repo = setup_test_repo().await;
        let plugin_name1 = uuid::Uuid::new_v4().to_string();
        let plugin_name2 = uuid::Uuid::new_v4().to_string();
        let plugin1 = create_test_plugin(&plugin_name1, "/path/to/plugin1");
        let plugin2 = create_test_plugin(&plugin_name2, "/path/to/plugin2");

        repo.add(plugin1.clone()).await.unwrap();
        repo.add(plugin2.clone()).await.unwrap();

        let retrieved = repo
            .get_by_ids(&[plugin1.id.clone(), plugin2.id.clone()])
            .await
            .unwrap();
        assert_eq!(retrieved.results.len(), 2);
        // Results order may vary, so check that both plugins are present
        let result_ids: Vec<String> = retrieved.results.iter().map(|p| p.id.clone()).collect();
        assert!(result_ids.contains(&plugin1.id));
        assert!(result_ids.contains(&plugin2.id));
        assert_eq!(retrieved.failed_ids.len(), 0);
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_list_paginated_plugins() {
        let repo = setup_test_repo().await;

        let plugin_id1 = uuid::Uuid::new_v4().to_string();
        let plugin_id2 = uuid::Uuid::new_v4().to_string();
        let plugin_id3 = uuid::Uuid::new_v4().to_string();
        let plugin1 = create_test_plugin(&plugin_id1, "/path/to/plugin1");
        let plugin2 = create_test_plugin(&plugin_id2, "/path/to/plugin2");
        let plugin3 = create_test_plugin(&plugin_id3, "/path/to/plugin3");

        repo.add(plugin1.clone()).await.unwrap();
        repo.add(plugin2.clone()).await.unwrap();
        repo.add(plugin3.clone()).await.unwrap();

        let query = PaginationQuery {
            page: 1,
            per_page: 2,
        };

        let result = repo.list_paginated(query).await;
        assert!(result.is_ok());
        let result = result.unwrap();
        assert!(result.items.len() == 2);
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_has_entries() {
        let repo = setup_test_repo().await;
        assert!(!repo.has_entries().await.unwrap());
        repo.add(create_test_plugin("test-plugin", "/path/to/plugin"))
            .await
            .unwrap();
        assert!(repo.has_entries().await.unwrap());
        repo.drop_all_entries().await.unwrap();
        assert!(!repo.has_entries().await.unwrap());
    }

    #[tokio::test]
    #[ignore = "Requires active Redis instance"]
    async fn test_drop_all_entries() {
        let repo = setup_test_repo().await;
        repo.add(create_test_plugin("test-plugin", "/path/to/plugin"))
            .await
            .unwrap();
        assert!(repo.has_entries().await.unwrap());
        repo.drop_all_entries().await.unwrap();
        assert!(!repo.has_entries().await.unwrap());
    }
}
