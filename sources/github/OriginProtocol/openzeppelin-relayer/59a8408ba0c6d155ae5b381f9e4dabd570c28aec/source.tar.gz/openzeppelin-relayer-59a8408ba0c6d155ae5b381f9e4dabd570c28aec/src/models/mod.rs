//! # Models Module
//!
//! Contains core data structures and type definitions for the relayer service.

mod network;
pub use network::*;

mod app_state;
pub use app_state::*;

mod api_response;
pub use api_response::*;

pub mod transaction;
#[allow(ambiguous_glob_reexports)]
pub use transaction::*;

pub mod relayer;
#[allow(ambiguous_glob_reexports)]
pub use relayer::*;

// Type aliases for backward compatibility with domain logic
pub use relayer::{
    RelayerStellarSwapConfig, SolanaAllowedTokensPolicy, SolanaFeePaymentStrategy,
    SolanaSwapStrategy, StellarAllowedTokensPolicy, StellarFeePaymentStrategy, StellarSwapStrategy,
};

mod error;
pub use error::*;

mod pagination;
pub use pagination::*;

pub mod signer;
pub use signer::*;

mod address;
pub use address::*;

mod notification;
pub use notification::*;

mod rpc;
pub use rpc::*;

pub mod types;
pub use types::*;

mod secret_string;
pub use secret_string::*;

mod plain_or_env_value;
pub use plain_or_env_value::*;

mod plugin;
pub use plugin::*;

mod api_key;
pub use api_key::*;

pub mod health;
pub use health::*;
