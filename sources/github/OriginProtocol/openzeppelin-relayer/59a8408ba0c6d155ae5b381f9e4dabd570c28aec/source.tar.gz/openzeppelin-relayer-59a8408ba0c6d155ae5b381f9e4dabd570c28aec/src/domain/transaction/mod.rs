//! This module defines the core transaction handling logic for different blockchain networks,
//! including Ethereum (EVM), Solana, and Stellar. It provides a unified interface for preparing,
//! submitting, handling, canceling, replacing, signing, and validating transactions across these
//! networks. The module also includes a factory for creating network-specific transaction handlers
//! based on relayer and repository information.
//!
//! The main components of this module are:
//! - `Transaction` trait: Defines the operations for handling transactions.
//! - `NetworkTransaction` enum: Represents a transaction for different network types.
//! - `RelayerTransactionFactory`: A factory for creating network transactions.
//!
//! The module leverages async traits to handle asynchronous operations and uses the `eyre` crate
//! for error handling.
use crate::{
    constants::{STELLAR_HORIZON_MAINNET_URL, STELLAR_HORIZON_TESTNET_URL},
    jobs::{JobProducer, StatusCheckContext},
    models::{
        EvmNetwork, NetworkTransactionRequest, NetworkType, RelayerRepoModel, SignerRepoModel,
        SolanaNetwork, StellarNetwork, StellarSwapStrategy, TransactionError, TransactionRepoModel,
    },
    repositories::{
        NetworkRepository, NetworkRepositoryStorage, RelayerRepositoryStorage,
        TransactionCounterRepositoryStorage, TransactionRepositoryStorage,
    },
    services::{
        gas::{
            cache::GasPriceCache, evm_gas_price::EvmGasPriceService,
            price_params_handler::PriceParamsHandler,
        },
        provider::get_network_provider,
        signer::{EvmSignerFactory, SolanaSignerFactory, StellarSignerFactory},
        stellar_dex::{DexServiceWrapper, OrderBookService, SoroswapService, StellarDexService},
    },
};
use async_trait::async_trait;
use eyre::Result;
#[cfg(test)]
use mockall::automock;
use std::sync::Arc;
use tracing::instrument;

pub mod common;
pub mod evm;
pub mod solana;
pub mod stellar;

mod util;
pub use util::*;

// Explicit re-exports to avoid ambiguous glob re-exports
pub use common::is_final_state;
pub use common::*;
pub use evm::{ensure_status, ensure_status_one_of, DefaultEvmTransaction, EvmRelayerTransaction};
pub use solana::{DefaultSolanaTransaction, SolanaRelayerTransaction};
pub use stellar::{DefaultStellarTransaction, StellarRelayerTransaction};

/// A trait that defines the operations for handling transactions across different networks.
#[cfg_attr(test, automock)]
#[async_trait]
#[allow(dead_code)]
pub trait Transaction {
    /// Prepares a transaction for submission.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be prepared.
    ///
    /// # Returns
    ///
    /// A `Result` containing the prepared `TransactionRepoModel` or a `TransactionError`.
    async fn prepare_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Submits a transaction to the network.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be submitted.
    ///
    /// # Returns
    ///
    /// A `Result` containing the submitted `TransactionRepoModel` or a `TransactionError`.
    async fn submit_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Resubmits a transaction with updated parameters.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be resubmitted.
    ///
    /// # Returns
    ///
    /// A `Result` containing the resubmitted `TransactionRepoModel` or a `TransactionError`.
    async fn resubmit_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Handles the status of a transaction.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction whose status is to be
    ///   handled.
    /// * `context` - Optional `StatusCheckContext` containing failure tracking information
    ///   for circuit breaker decisions. When provided, handlers can use this to decide
    ///   whether to force-finalize a transaction that has exceeded retry limits.
    ///
    /// # Returns
    ///
    /// A `Result` containing the updated `TransactionRepoModel` or a `TransactionError`.
    async fn handle_transaction_status(
        &self,
        tx: TransactionRepoModel,
        context: Option<StatusCheckContext>,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Cancels a transaction.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be canceled.
    ///
    /// # Returns
    ///
    /// A `Result` containing the canceled `TransactionRepoModel` or a `TransactionError`.
    async fn cancel_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Replaces a transaction with a new one.
    ///
    /// # Arguments
    ///
    /// * `old_tx` - A `TransactionRepoModel` representing the transaction to be replaced.
    /// * `new_tx_request` - A `NetworkTransactionRequest` representing the new transaction data.
    ///
    /// # Returns
    ///
    /// A `Result` containing the new `TransactionRepoModel` or a `TransactionError`.
    async fn replace_transaction(
        &self,
        old_tx: TransactionRepoModel,
        new_tx_request: NetworkTransactionRequest,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Signs a transaction.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be signed.
    ///
    /// # Returns
    ///
    /// A `Result` containing the signed `TransactionRepoModel` or a `TransactionError`.
    async fn sign_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError>;

    /// Validates a transaction.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be validated.
    ///
    /// # Returns
    ///
    /// A `Result` containing a boolean indicating the validity of the transaction or a
    /// `TransactionError`.
    async fn validate_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<bool, TransactionError>;
}

/// An enum representing a transaction for different network types.
pub enum NetworkTransaction {
    Evm(Box<DefaultEvmTransaction>),
    Solana(DefaultSolanaTransaction),
    Stellar(DefaultStellarTransaction),
}

#[async_trait]
impl Transaction for NetworkTransaction {
    /// Prepares a transaction for submission based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be prepared.
    ///
    /// # Returns
    ///
    /// A `Result` containing the prepared `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
        )
    )]
    async fn prepare_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => relayer.prepare_transaction(tx).await,
            NetworkTransaction::Solana(relayer) => relayer.prepare_transaction(tx).await,
            NetworkTransaction::Stellar(relayer) => relayer.prepare_transaction(tx).await,
        }
    }

    /// Submits a transaction to the network based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be submitted.
    ///
    /// # Returns
    ///
    /// A `Result` containing the submitted `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
        )
    )]
    async fn submit_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => relayer.submit_transaction(tx).await,
            NetworkTransaction::Solana(relayer) => relayer.submit_transaction(tx).await,
            NetworkTransaction::Stellar(relayer) => relayer.submit_transaction(tx).await,
        }
    }
    /// Resubmits a transaction with updated parameters based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be resubmitted.
    ///
    /// # Returns
    ///
    /// A `Result` containing the resubmitted `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
        )
    )]
    async fn resubmit_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => relayer.resubmit_transaction(tx).await,
            NetworkTransaction::Solana(relayer) => relayer.resubmit_transaction(tx).await,
            NetworkTransaction::Stellar(relayer) => relayer.resubmit_transaction(tx).await,
        }
    }

    /// Handles the status of a transaction based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction whose status is to be
    ///   handled.
    /// * `context` - Optional `StatusCheckContext` containing failure tracking information
    ///   for circuit breaker decisions.
    ///
    /// # Returns
    ///
    /// A `Result` containing the updated `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx, context),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
            has_context = %context.is_some(),
        )
    )]
    async fn handle_transaction_status(
        &self,
        tx: TransactionRepoModel,
        context: Option<StatusCheckContext>,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => {
                relayer.handle_transaction_status(tx, context).await
            }
            NetworkTransaction::Solana(relayer) => {
                relayer.handle_transaction_status(tx, context).await
            }
            NetworkTransaction::Stellar(relayer) => {
                relayer.handle_transaction_status(tx, context).await
            }
        }
    }

    /// Cancels a transaction based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be canceled.
    ///
    /// # Returns
    ///
    /// A `Result` containing the canceled `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
        )
    )]
    async fn cancel_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => relayer.cancel_transaction(tx).await,
            NetworkTransaction::Solana(_) => solana_not_supported_transaction(),
            NetworkTransaction::Stellar(relayer) => relayer.cancel_transaction(tx).await,
        }
    }

    /// Replaces a transaction with a new one based on the network type.
    ///
    /// # Arguments
    ///
    /// * `old_tx` - A `TransactionRepoModel` representing the transaction to be replaced.
    /// * `new_tx_request` - A `NetworkTransactionRequest` representing the new transaction data.
    ///
    /// # Returns
    ///
    /// A `Result` containing the new `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, old_tx, new_tx_request),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %old_tx.id,
            relayer_id = %old_tx.relayer_id,
            tx_status = ?old_tx.status,
            network_type = ?old_tx.network_type,
        )
    )]
    async fn replace_transaction(
        &self,
        old_tx: TransactionRepoModel,
        new_tx_request: NetworkTransactionRequest,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => {
                relayer.replace_transaction(old_tx, new_tx_request).await
            }
            NetworkTransaction::Solana(_) => solana_not_supported_transaction(),
            NetworkTransaction::Stellar(relayer) => {
                relayer.replace_transaction(old_tx, new_tx_request).await
            }
        }
    }

    /// Signs a transaction based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be signed.
    ///
    /// # Returns
    ///
    /// A `Result` containing the signed `TransactionRepoModel` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
        )
    )]
    async fn sign_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<TransactionRepoModel, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => relayer.sign_transaction(tx).await,
            NetworkTransaction::Solana(relayer) => relayer.sign_transaction(tx).await,
            NetworkTransaction::Stellar(relayer) => relayer.sign_transaction(tx).await,
        }
    }

    /// Validates a transaction based on the network type.
    ///
    /// # Arguments
    ///
    /// * `tx` - A `TransactionRepoModel` representing the transaction to be validated.
    ///
    /// # Returns
    ///
    /// A `Result` containing a boolean indicating the validity of the transaction or a
    /// `TransactionError`.
    #[instrument(
        level = "debug",
        skip(self, tx),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            tx_id = %tx.id,
            relayer_id = %tx.relayer_id,
            tx_status = ?tx.status,
            network_type = ?tx.network_type,
        )
    )]
    async fn validate_transaction(
        &self,
        tx: TransactionRepoModel,
    ) -> Result<bool, TransactionError> {
        match self {
            NetworkTransaction::Evm(relayer) => relayer.validate_transaction(tx).await,
            NetworkTransaction::Solana(relayer) => relayer.validate_transaction(tx).await,
            NetworkTransaction::Stellar(relayer) => relayer.validate_transaction(tx).await,
        }
    }
}

/// A trait for creating network transactions.
#[allow(dead_code)]
pub trait RelayerTransactionFactoryTrait {
    /// Creates a network transaction based on the relayer and repository information.
    ///
    /// # Arguments
    ///
    /// * `relayer` - A `RelayerRepoModel` representing the relayer.
    /// * `relayer_repository` - An `Arc` to the `RelayerRepositoryStorage`.
    /// * `transaction_repository` - An `Arc` to the `TransactionRepositoryStorage`.
    /// * `job_producer` - An `Arc` to the `JobProducer`.
    ///
    /// # Returns
    ///
    /// A `Result` containing the created `NetworkTransaction` or a `TransactionError`.
    fn create_transaction(
        relayer: RelayerRepoModel,
        relayer_repository: Arc<RelayerRepositoryStorage>,
        transaction_repository: Arc<TransactionRepositoryStorage>,
        job_producer: Arc<JobProducer>,
    ) -> Result<NetworkTransaction, TransactionError>;
}
/// A factory for creating relayer transactions.
pub struct RelayerTransactionFactory;

#[allow(dead_code)]
impl RelayerTransactionFactory {
    /// Creates a network transaction based on the relayer, signer, and repository information.
    ///
    /// # Arguments
    ///
    /// * `relayer` - A `RelayerRepoModel` representing the relayer.
    /// * `signer` - A `SignerRepoModel` representing the signer.
    /// * `relayer_repository` - An `Arc` to the `RelayerRepositoryStorage`.
    /// * `transaction_repository` - An `Arc` to the `InMemoryTransactionRepository`.
    /// * `transaction_counter_store` - An `Arc` to the `InMemoryTransactionCounter`.
    /// * `job_producer` - An `Arc` to the `JobProducer`.
    ///
    /// # Returns
    ///
    /// A `Result` containing the created `NetworkTransaction` or a `TransactionError`.
    #[instrument(
        level = "debug",
        skip(
            relayer,
            signer,
            relayer_repository,
            network_repository,
            transaction_repository,
            transaction_counter_store,
            job_producer
        ),
        fields(
            request_id = ?crate::observability::request_id::get_request_id(),
            relayer_id = %relayer.id,
            network_type = ?relayer.network_type,
        )
    )]
    pub async fn create_transaction(
        relayer: RelayerRepoModel,
        signer: SignerRepoModel,
        relayer_repository: Arc<RelayerRepositoryStorage>,
        network_repository: Arc<NetworkRepositoryStorage>,
        transaction_repository: Arc<TransactionRepositoryStorage>,
        transaction_counter_store: Arc<TransactionCounterRepositoryStorage>,
        job_producer: Arc<JobProducer>,
    ) -> Result<NetworkTransaction, TransactionError> {
        match relayer.network_type {
            NetworkType::Evm => {
                let network_repo = network_repository
                    .get_by_name(NetworkType::Evm, &relayer.network)
                    .await
                    .ok()
                    .flatten()
                    .ok_or_else(|| {
                        TransactionError::NetworkConfiguration(format!(
                            "Network {} not found",
                            relayer.network
                        ))
                    })?;

                let network = EvmNetwork::try_from(network_repo)
                    .map_err(|e| TransactionError::NetworkConfiguration(e.to_string()))?;

                let evm_provider = get_network_provider(&network, relayer.custom_rpc_urls.clone())?;
                let signer_service = EvmSignerFactory::create_evm_signer(signer.into()).await?;
                let price_params_handler =
                    PriceParamsHandler::for_network(&network, evm_provider.clone());

                let evm_gas_cache = GasPriceCache::global();

                // Use the global cache if gas price caching is enabled
                let cache = if let Some(cfg) = &network.gas_price_cache {
                    evm_gas_cache.configure_network(network.chain_id, cfg.clone());
                    Some(evm_gas_cache.clone())
                } else {
                    if evm_gas_cache.has_configuration_for_network(network.chain_id) {
                        evm_gas_cache.remove_network(network.chain_id);
                    }
                    None
                };

                let gas_price_service =
                    EvmGasPriceService::new(evm_provider.clone(), network.clone(), cache);

                let price_calculator =
                    evm::PriceCalculator::new(gas_price_service, price_params_handler);

                Ok(NetworkTransaction::Evm(Box::new(
                    DefaultEvmTransaction::new(
                        relayer,
                        evm_provider,
                        relayer_repository,
                        network_repository,
                        transaction_repository,
                        transaction_counter_store,
                        job_producer,
                        price_calculator,
                        signer_service,
                    )?,
                )))
            }
            NetworkType::Solana => {
                let network_repo = network_repository
                    .get_by_name(NetworkType::Solana, &relayer.network)
                    .await
                    .ok()
                    .flatten()
                    .ok_or_else(|| {
                        TransactionError::NetworkConfiguration(format!(
                            "Network {} not found",
                            relayer.network
                        ))
                    })?;

                let network = SolanaNetwork::try_from(network_repo)
                    .map_err(|e| TransactionError::NetworkConfiguration(e.to_string()))?;

                let solana_provider = Arc::new(get_network_provider(
                    &network,
                    relayer.custom_rpc_urls.clone(),
                )?);

                let signer_service =
                    Arc::new(SolanaSignerFactory::create_solana_signer(&signer.into())?);

                Ok(NetworkTransaction::Solana(SolanaRelayerTransaction::new(
                    relayer,
                    relayer_repository,
                    solana_provider,
                    transaction_repository,
                    job_producer,
                    signer_service,
                )?))
            }
            NetworkType::Stellar => {
                // Create signer once and wrap in Arc, then clone Arc for both uses
                // Arc implements Clone (cheap reference count increment)
                let stellar_signer = StellarSignerFactory::create_stellar_signer(&signer.into())?;
                let signer_service = Arc::new(stellar_signer);

                let network_repo = network_repository
                    .get_by_name(NetworkType::Stellar, &relayer.network)
                    .await
                    .ok()
                    .flatten()
                    .ok_or_else(|| {
                        TransactionError::NetworkConfiguration(format!(
                            "Network {} not found",
                            relayer.network
                        ))
                    })?;

                let network = StellarNetwork::try_from(network_repo)
                    .map_err(|e| TransactionError::NetworkConfiguration(e.to_string()))?;

                let stellar_provider =
                    get_network_provider(&network, relayer.custom_rpc_urls.clone())
                        .map_err(|e| TransactionError::NetworkConfiguration(e.to_string()))?;

                // Create DEX service for swap operations and validations
                let horizon_url = network.horizon_url.clone().unwrap_or_else(|| {
                    if network.is_testnet() {
                        STELLAR_HORIZON_TESTNET_URL.to_string()
                    } else {
                        STELLAR_HORIZON_MAINNET_URL.to_string()
                    }
                });
                let provider_arc = Arc::new(stellar_provider.clone());
                // Clone Arc for DEX service (cheap - just increments reference count)
                let signer_arc = signer_service.clone();

                // Get strategies from relayer policy (default to OrderBook if none specified)
                let strategies = relayer
                    .policies
                    .get_stellar_policy()
                    .get_swap_config()
                    .and_then(|config| {
                        if config.strategies.is_empty() {
                            None
                        } else {
                            Some(config.strategies.clone())
                        }
                    })
                    .unwrap_or_else(|| vec![StellarSwapStrategy::OrderBook]);

                // Create DEX services for each configured strategy
                let mut dex_services: Vec<DexServiceWrapper<_, _>> = Vec::new();
                for strategy in &strategies {
                    match strategy {
                        StellarSwapStrategy::OrderBook => {
                            let order_book_service = Arc::new(
                                OrderBookService::new(
                                    horizon_url.clone(),
                                    provider_arc.clone(),
                                    signer_arc.clone(),
                                )
                                .map_err(|e| {
                                    TransactionError::NetworkConfiguration(format!(
                                        "Failed to create OrderBook DEX service: {e}"
                                    ))
                                })?,
                            );
                            dex_services.push(DexServiceWrapper::OrderBook(order_book_service));
                        }
                        StellarSwapStrategy::Soroswap => {
                            let is_testnet = network.is_testnet();
                            let network_label = if is_testnet { "TESTNET" } else { "MAINNET" };

                            let router_address =
                                crate::config::ServerConfig::resolve_stellar_soroswap_router_address(is_testnet)
                                    .ok_or_else(|| {
                                        eyre::eyre!(
                                            "Soroswap router address not configured. Set STELLAR_{network_label}_SOROSWAP_ROUTER_ADDRESS env var."
                                        )
                                    })?;
                            let factory_address =
                                crate::config::ServerConfig::resolve_stellar_soroswap_factory_address(is_testnet)
                                    .ok_or_else(|| {
                                        eyre::eyre!(
                                            "Soroswap factory address not configured. Set STELLAR_{network_label}_SOROSWAP_FACTORY_ADDRESS env var."
                                        )
                                    })?;
                            let native_wrapper_address =
                                crate::config::ServerConfig::resolve_stellar_soroswap_native_wrapper_address(is_testnet)
                                    .ok_or_else(|| {
                                        eyre::eyre!(
                                            "Soroswap native wrapper address not configured. Set STELLAR_{network_label}_SOROSWAP_NATIVE_WRAPPER_ADDRESS env var."
                                        )
                                    })?;

                            let soroswap_service = Arc::new(SoroswapService::new(
                                router_address,
                                factory_address,
                                native_wrapper_address,
                                provider_arc.clone(),
                                network.passphrase.clone(),
                            ));
                            dex_services.push(DexServiceWrapper::Soroswap(soroswap_service));
                        }
                    }
                }

                // Create multi-strategy DEX service
                let dex_service = Arc::new(StellarDexService::new(dex_services));

                Ok(NetworkTransaction::Stellar(DefaultStellarTransaction::new(
                    relayer,
                    relayer_repository,
                    transaction_repository,
                    job_producer,
                    signer_service,
                    stellar_provider,
                    transaction_counter_store,
                    dex_service,
                )?))
            }
        }
    }
}
