use crate::constants::{
    ARBITRUM_GAS_LIMIT, DEFAULT_GAS_LIMIT, DEFAULT_TRANSACTION_SPEED, DEFAULT_TX_VALID_TIMESPAN,
    EVM_MIN_AGE_FOR_RESUBMIT_SECONDS, MAXIMUM_NOOP_RETRY_ATTEMPTS, MAXIMUM_TX_ATTEMPTS,
};
use crate::domain::get_age_since_created;
use crate::models::EvmNetwork;
use crate::models::{
    EvmTransactionData, TransactionError, TransactionRepoModel, TransactionStatus, U256,
};
use crate::services::provider::EvmProviderTrait;
use chrono::{DateTime, Duration, Utc};
use eyre::Result;

/// Updates an existing transaction to be a "noop" transaction (transaction to self with zero value and no data)
/// This is commonly used for cancellation and replacement transactions
/// For Arbitrum networks, uses eth_estimateGas to account for L1 + L2 costs
pub async fn make_noop<P: EvmProviderTrait>(
    evm_data: &mut EvmTransactionData,
    network: &EvmNetwork,
    provider: Option<&P>,
) -> Result<(), TransactionError> {
    // Update the transaction to be a noop
    evm_data.value = U256::from(0u64);
    evm_data.data = Some("0x".to_string());
    evm_data.to = Some(evm_data.from.clone());
    evm_data.speed = Some(DEFAULT_TRANSACTION_SPEED);

    // Set gas limit based on network type
    if network.is_arbitrum() {
        // For Arbitrum networks, try to estimate gas to account for L1 + L2 costs
        if let Some(provider) = provider {
            match provider.estimate_gas(evm_data).await {
                Ok(estimated_gas) => {
                    // Use the estimated gas, but ensure it's at least the default minimum
                    evm_data.gas_limit = Some(estimated_gas.max(DEFAULT_GAS_LIMIT));
                }
                Err(e) => {
                    // If estimation fails, fall back to a conservative estimate
                    tracing::warn!(
                        "Failed to estimate gas for Arbitrum noop transaction: {:?}",
                        e
                    );
                    evm_data.gas_limit = Some(ARBITRUM_GAS_LIMIT);
                }
            }
        } else {
            // No provider available, use conservative estimate
            evm_data.gas_limit = Some(ARBITRUM_GAS_LIMIT);
        }
    } else {
        // For other networks, use the standard gas limit
        evm_data.gas_limit = Some(DEFAULT_GAS_LIMIT);
    }

    Ok(())
}

/// Checks if a transaction is already a NOOP transaction
pub fn is_noop(evm_data: &EvmTransactionData) -> bool {
    evm_data.value == U256::from(0u64)
        && evm_data.data.as_ref().is_some_and(|data| data == "0x")
        && evm_data.to.as_ref() == Some(&evm_data.from)
        && evm_data.speed.is_some()
}

/// Checks if a transaction has too many attempts
pub fn too_many_attempts(tx: &TransactionRepoModel) -> bool {
    tx.hashes.len() > MAXIMUM_TX_ATTEMPTS
}

/// Checks if a transaction has too many NOOP attempts
pub fn too_many_noop_attempts(tx: &TransactionRepoModel) -> bool {
    tx.noop_count.unwrap_or(0) > MAXIMUM_NOOP_RETRY_ATTEMPTS
}

/// Validates that a transaction is in the expected state.
///
/// This enforces state machine invariants and prevents invalid state transitions.
/// Used for domain-level validation to ensure business rules are always enforced.
///
/// # Arguments
///
/// * `tx` - The transaction to validate
/// * `expected` - The expected status
/// * `operation` - Optional operation name for better error messages (e.g., "prepare_transaction")
///
/// # Returns
///
/// `Ok(())` if the status matches, `Err(TransactionError)` otherwise
pub fn ensure_status(
    tx: &TransactionRepoModel,
    expected: TransactionStatus,
    operation: Option<&str>,
) -> Result<(), TransactionError> {
    if tx.status != expected {
        let error_msg = if let Some(op) = operation {
            format!(
                "Invalid transaction state for {}. Current: {:?}, Expected: {:?}",
                op, tx.status, expected
            )
        } else {
            format!(
                "Invalid transaction state. Current: {:?}, Expected: {:?}",
                tx.status, expected
            )
        };
        return Err(TransactionError::ValidationError(error_msg));
    }
    Ok(())
}

/// Validates that a transaction is in one of the expected states.
///
/// This enforces state machine invariants for operations that are valid
/// in multiple states (e.g., cancel, replace).
///
/// # Arguments
///
/// * `tx` - The transaction to validate
/// * `expected` - Slice of acceptable statuses
/// * `operation` - Optional operation name for better error messages (e.g., "cancel_transaction")
///
/// # Returns
///
/// `Ok(())` if the status is one of the expected values, `Err(TransactionError)` otherwise
pub fn ensure_status_one_of(
    tx: &TransactionRepoModel,
    expected: &[TransactionStatus],
    operation: Option<&str>,
) -> Result<(), TransactionError> {
    if !expected.contains(&tx.status) {
        let error_msg = if let Some(op) = operation {
            format!(
                "Invalid transaction state for {}. Current: {:?}, Expected one of: {:?}",
                op, tx.status, expected
            )
        } else {
            format!(
                "Invalid transaction state. Current: {:?}, Expected one of: {:?}",
                tx.status, expected
            )
        };
        return Err(TransactionError::ValidationError(error_msg));
    }
    Ok(())
}

/// Helper function to check if a transaction has enough confirmations.
pub fn has_enough_confirmations(
    tx_block_number: u64,
    current_block_number: u64,
    required_confirmations: u64,
) -> bool {
    current_block_number >= tx_block_number + required_confirmations
}

/// Checks if a transaction is still valid based on its valid_until timestamp.
pub fn is_transaction_valid(created_at: &str, valid_until: &Option<String>) -> bool {
    if let Some(valid_until_str) = valid_until {
        match DateTime::parse_from_rfc3339(valid_until_str) {
            Ok(valid_until_time) => return Utc::now() < valid_until_time,
            Err(e) => {
                tracing::warn!(error = %e, "failed to parse valid_until timestamp");
                return false;
            }
        }
    }
    match DateTime::parse_from_rfc3339(created_at) {
        Ok(created_time) => {
            let default_valid_until =
                created_time + Duration::milliseconds(DEFAULT_TX_VALID_TIMESPAN);
            Utc::now() < default_valid_until
        }
        Err(e) => {
            tracing::warn!(error = %e, "failed to parse created_at timestamp");
            false
        }
    }
}

/// Get age since status last changed
/// Uses sent_at, otherwise falls back to created_at
pub fn get_age_since_status_change(
    tx: &TransactionRepoModel,
) -> Result<Duration, TransactionError> {
    // For Sent/Submitted status, use sent_at if available
    if let Some(sent_at) = &tx.sent_at {
        let sent = DateTime::parse_from_rfc3339(sent_at)
            .map_err(|e| {
                TransactionError::UnexpectedError(format!("Error parsing sent_at time: {e}"))
            })?
            .with_timezone(&Utc);
        return Ok(Utc::now().signed_duration_since(sent));
    }

    // Fallback to created_at
    get_age_since_created(tx)
}

/// Check if transaction is too young for resubmission and timeout checks.
///
/// Returns true if the transaction was created less than EVM_MIN_AGE_FOR_RESUBMIT_SECONDS ago.
/// This is used to defer resubmission logic and timeout checks for newly created transactions,
/// while still allowing basic status updates from the blockchain.
pub fn is_too_early_to_resubmit(tx: &TransactionRepoModel) -> Result<bool, TransactionError> {
    let age = get_age_since_created(tx)?;
    Ok(age < Duration::seconds(EVM_MIN_AGE_FOR_RESUBMIT_SECONDS))
}

/// Deprecated: Use `is_too_early_to_resubmit` instead.
/// This alias exists for backward compatibility.
#[deprecated(since = "1.1.0", note = "Use `is_too_early_to_resubmit` instead")]
pub fn is_too_early_to_check(tx: &TransactionRepoModel) -> Result<bool, TransactionError> {
    is_too_early_to_resubmit(tx)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::constants::{ARBITRUM_BASED_TAG, ROLLUP_TAG};
    use crate::domain::transaction::evm::test_helpers::test_utils::make_test_transaction;
    use crate::models::{evm::Speed, EvmTransactionData, NetworkTransactionData, U256};
    use crate::services::provider::{MockEvmProviderTrait, ProviderError};
    use crate::utils::mocks::mockutils::create_mock_transaction;

    fn create_standard_network() -> EvmNetwork {
        EvmNetwork {
            network: "ethereum".to_string(),
            rpc_urls: vec![crate::models::RpcConfig::new(
                "https://mainnet.infura.io".to_string(),
            )],
            explorer_urls: None,
            average_blocktime_ms: 12000,
            is_testnet: false,
            tags: vec!["mainnet".to_string()],
            chain_id: 1,
            required_confirmations: 12,
            features: vec!["eip1559".to_string()],
            symbol: "ETH".to_string(),
            gas_price_cache: None,
        }
    }

    fn create_arbitrum_network() -> EvmNetwork {
        use crate::models::RpcConfig;
        EvmNetwork {
            network: "arbitrum".to_string(),
            rpc_urls: vec![RpcConfig::new("https://arb1.arbitrum.io/rpc".to_string())],
            explorer_urls: None,
            average_blocktime_ms: 1000,
            is_testnet: false,
            tags: vec![ROLLUP_TAG.to_string(), ARBITRUM_BASED_TAG.to_string()],
            chain_id: 42161,
            required_confirmations: 1,
            features: vec!["eip1559".to_string()],
            symbol: "ETH".to_string(),
            gas_price_cache: None,
        }
    }

    fn create_arbitrum_nova_network() -> EvmNetwork {
        use crate::models::RpcConfig;
        EvmNetwork {
            network: "arbitrum-nova".to_string(),
            rpc_urls: vec![RpcConfig::new("https://nova.arbitrum.io/rpc".to_string())],
            explorer_urls: None,
            average_blocktime_ms: 1000,
            is_testnet: false,
            tags: vec![ROLLUP_TAG.to_string(), ARBITRUM_BASED_TAG.to_string()],
            chain_id: 42170,
            required_confirmations: 1,
            features: vec!["eip1559".to_string()],
            symbol: "ETH".to_string(),
            gas_price_cache: None,
        }
    }

    #[tokio::test]
    async fn test_make_noop_standard_network() {
        let mut evm_data = EvmTransactionData {
            from: "0x1234567890123456789012345678901234567890".to_string(),
            to: Some("0xoriginal_destination".to_string()),
            value: U256::from(1000000000000000000u64), // 1 ETH
            data: Some("0xoriginal_data".to_string()),
            gas_limit: Some(50000),
            gas_price: Some(10_000_000_000),
            max_fee_per_gas: None,
            max_priority_fee_per_gas: None,
            nonce: Some(42),
            signature: None,
            hash: Some("0xoriginal_hash".to_string()),
            speed: Some(Speed::Fast),
            chain_id: 1,
            raw: Some(vec![1, 2, 3]),
        };

        let network = create_standard_network();
        let result = make_noop(&mut evm_data, &network, None::<&MockEvmProviderTrait>).await;
        assert!(result.is_ok());

        // Verify the transaction was updated correctly
        assert_eq!(evm_data.gas_limit, Some(21_000)); // Standard gas limit
        assert_eq!(evm_data.to.unwrap(), evm_data.from); // Should send to self
        assert_eq!(evm_data.value, U256::from(0u64)); // Zero value
        assert_eq!(evm_data.data.unwrap(), "0x"); // Empty data
        assert_eq!(evm_data.nonce, Some(42)); // Original nonce preserved
        assert_eq!(evm_data.speed, Some(DEFAULT_TRANSACTION_SPEED));
    }

    #[tokio::test]
    async fn test_make_noop_arbitrum_network() {
        let mut evm_data = EvmTransactionData {
            from: "0x1234567890123456789012345678901234567890".to_string(),
            to: Some("0xoriginal_destination".to_string()),
            value: U256::from(1000000000000000000u64), // 1 ETH
            data: Some("0xoriginal_data".to_string()),
            gas_limit: Some(50000),
            gas_price: Some(10_000_000_000),
            max_fee_per_gas: None,
            max_priority_fee_per_gas: None,
            nonce: Some(42),
            signature: None,
            hash: Some("0xoriginal_hash".to_string()),
            speed: Some(Speed::Fast),
            chain_id: 42161, // Arbitrum One
            raw: Some(vec![1, 2, 3]),
        };

        let network = create_arbitrum_network();
        let result = make_noop(&mut evm_data, &network, None::<&MockEvmProviderTrait>).await;
        assert!(result.is_ok());

        // Verify the transaction was updated correctly for Arbitrum
        assert_eq!(evm_data.gas_limit, Some(50_000)); // Higher gas limit for Arbitrum
        assert_eq!(evm_data.to.unwrap(), evm_data.from); // Should send to self
        assert_eq!(evm_data.value, U256::from(0u64)); // Zero value
        assert_eq!(evm_data.data.unwrap(), "0x"); // Empty data
        assert_eq!(evm_data.nonce, Some(42)); // Original nonce preserved
        assert_eq!(evm_data.chain_id, 42161); // Chain ID preserved
    }

    #[tokio::test]
    async fn test_make_noop_arbitrum_nova() {
        let mut evm_data = EvmTransactionData {
            from: "0x1234567890123456789012345678901234567890".to_string(),
            to: Some("0xoriginal_destination".to_string()),
            value: U256::from(1000000000000000000u64), // 1 ETH
            data: Some("0xoriginal_data".to_string()),
            gas_limit: Some(30000),
            gas_price: Some(10_000_000_000),
            max_fee_per_gas: None,
            max_priority_fee_per_gas: None,
            nonce: Some(42),
            signature: None,
            hash: Some("0xoriginal_hash".to_string()),
            speed: Some(Speed::Fast),
            chain_id: 42170, // Arbitrum Nova
            raw: Some(vec![1, 2, 3]),
        };

        let network = create_arbitrum_nova_network();
        let result = make_noop(&mut evm_data, &network, None::<&MockEvmProviderTrait>).await;
        assert!(result.is_ok());

        // Verify the transaction was updated correctly for Arbitrum Nova
        assert_eq!(evm_data.gas_limit, Some(50_000)); // Higher gas limit for Arbitrum
        assert_eq!(evm_data.to.unwrap(), evm_data.from); // Should send to self
        assert_eq!(evm_data.value, U256::from(0u64)); // Zero value
        assert_eq!(evm_data.data.unwrap(), "0x"); // Empty data
        assert_eq!(evm_data.nonce, Some(42)); // Original nonce preserved
        assert_eq!(evm_data.chain_id, 42170); // Chain ID preserved
    }

    #[tokio::test]
    async fn test_make_noop_arbitrum_with_provider() {
        let mut mock_provider = MockEvmProviderTrait::new();

        // Mock the gas estimation to return a higher value (simulating L1 + L2 costs)
        mock_provider
            .expect_estimate_gas()
            .times(1)
            .returning(|_| Box::pin(async move { Ok(35_000) }));

        let mut evm_data = EvmTransactionData {
            from: "0x1234567890123456789012345678901234567890".to_string(),
            to: Some("0xoriginal_destination".to_string()),
            value: U256::from(1000000000000000000u64), // 1 ETH
            data: Some("0xoriginal_data".to_string()),
            gas_limit: Some(30000),
            gas_price: Some(10_000_000_000),
            max_fee_per_gas: None,
            max_priority_fee_per_gas: None,
            nonce: Some(42),
            signature: None,
            hash: Some("0xoriginal_hash".to_string()),
            speed: Some(Speed::Fast),
            chain_id: 42161, // Arbitrum One
            raw: Some(vec![1, 2, 3]),
        };

        let network = create_arbitrum_network();
        let result = make_noop(&mut evm_data, &network, Some(&mock_provider)).await;
        assert!(result.is_ok());

        // Verify the transaction was updated correctly with estimated gas
        assert_eq!(evm_data.gas_limit, Some(35_000)); // Should use estimated gas
        assert_eq!(evm_data.to.unwrap(), evm_data.from); // Should send to self
        assert_eq!(evm_data.value, U256::from(0u64)); // Zero value
        assert_eq!(evm_data.data.unwrap(), "0x"); // Empty data
        assert_eq!(evm_data.nonce, Some(42)); // Original nonce preserved
        assert_eq!(evm_data.chain_id, 42161); // Chain ID preserved
    }

    #[tokio::test]
    async fn test_make_noop_arbitrum_provider_estimation_fails() {
        let mut mock_provider = MockEvmProviderTrait::new();

        // Mock the gas estimation to fail
        mock_provider.expect_estimate_gas().times(1).returning(|_| {
            Box::pin(async move { Err(ProviderError::Other("Network error".to_string())) })
        });

        let mut evm_data = EvmTransactionData {
            from: "0x1234567890123456789012345678901234567890".to_string(),
            to: Some("0xoriginal_destination".to_string()),
            value: U256::from(1000000000000000000u64), // 1 ETH
            data: Some("0xoriginal_data".to_string()),
            gas_limit: Some(30000),
            gas_price: Some(10_000_000_000),
            max_fee_per_gas: None,
            max_priority_fee_per_gas: None,
            nonce: Some(42),
            signature: None,
            hash: Some("0xoriginal_hash".to_string()),
            speed: Some(Speed::Fast),
            chain_id: 42161, // Arbitrum One
            raw: Some(vec![1, 2, 3]),
        };

        let network = create_arbitrum_network();
        let result = make_noop(&mut evm_data, &network, Some(&mock_provider)).await;
        assert!(result.is_ok());

        // Verify the transaction falls back to conservative estimate
        assert_eq!(evm_data.gas_limit, Some(50_000)); // Should use fallback gas limit
        assert_eq!(evm_data.to.unwrap(), evm_data.from); // Should send to self
        assert_eq!(evm_data.value, U256::from(0u64)); // Zero value
        assert_eq!(evm_data.data.unwrap(), "0x"); // Empty data
        assert_eq!(evm_data.nonce, Some(42)); // Original nonce preserved
        assert_eq!(evm_data.chain_id, 42161); // Chain ID preserved
    }

    #[test]
    fn test_is_noop() {
        // Create a NOOP transaction
        let noop_tx = EvmTransactionData {
            from: "0x1234567890123456789012345678901234567890".to_string(),
            to: Some("0x1234567890123456789012345678901234567890".to_string()), // Same as from
            value: U256::from(0u64),
            data: Some("0x".to_string()),
            gas_limit: Some(21000),
            gas_price: Some(10_000_000_000),
            max_fee_per_gas: None,
            max_priority_fee_per_gas: None,
            nonce: Some(42),
            signature: None,
            hash: None,
            speed: Some(Speed::Fast),
            chain_id: 1,
            raw: None,
        };
        assert!(is_noop(&noop_tx));

        // Test non-NOOP transactions
        let mut non_noop = noop_tx.clone();
        non_noop.value = U256::from(1000000000000000000u64); // 1 ETH
        assert!(!is_noop(&non_noop));

        let mut non_noop = noop_tx.clone();
        non_noop.data = Some("0x123456".to_string());
        assert!(!is_noop(&non_noop));

        let mut non_noop = noop_tx.clone();
        non_noop.to = Some("0x9876543210987654321098765432109876543210".to_string());
        assert!(!is_noop(&non_noop));

        let mut non_noop = noop_tx;
        non_noop.speed = None;
        assert!(!is_noop(&non_noop));
    }

    #[test]
    fn test_too_many_attempts() {
        let mut tx = TransactionRepoModel {
            id: "test-tx".to_string(),
            relayer_id: "test-relayer".to_string(),
            status: TransactionStatus::Pending,
            status_reason: None,
            created_at: "2024-01-01T00:00:00Z".to_string(),
            sent_at: None,
            confirmed_at: None,
            valid_until: None,
            network_type: crate::models::NetworkType::Evm,
            network_data: NetworkTransactionData::Evm(EvmTransactionData {
                from: "0x1234".to_string(),
                to: Some("0x5678".to_string()),
                value: U256::from(0u64),
                data: Some("0x".to_string()),
                gas_limit: Some(21000),
                gas_price: Some(10_000_000_000),
                max_fee_per_gas: None,
                max_priority_fee_per_gas: None,
                nonce: Some(42),
                signature: None,
                hash: None,
                speed: Some(Speed::Fast),
                chain_id: 1,
                raw: None,
            }),
            priced_at: None,
            hashes: vec![], // Start with no attempts
            noop_count: None,
            is_canceled: Some(false),
            delete_at: None,
            metadata: None,
        };

        // Test with no attempts
        assert!(!too_many_attempts(&tx));

        // Test with maximum attempts
        tx.hashes = vec!["hash".to_string(); MAXIMUM_TX_ATTEMPTS];
        assert!(!too_many_attempts(&tx));

        // Test with too many attempts
        tx.hashes = vec!["hash".to_string(); MAXIMUM_TX_ATTEMPTS + 1];
        assert!(too_many_attempts(&tx));
    }

    #[test]
    fn test_too_many_noop_attempts() {
        let mut tx = TransactionRepoModel {
            id: "test-tx".to_string(),
            relayer_id: "test-relayer".to_string(),
            status: TransactionStatus::Pending,
            status_reason: None,
            created_at: "2024-01-01T00:00:00Z".to_string(),
            sent_at: None,
            confirmed_at: None,
            valid_until: None,
            network_type: crate::models::NetworkType::Evm,
            network_data: NetworkTransactionData::Evm(EvmTransactionData {
                from: "0x1234".to_string(),
                to: Some("0x5678".to_string()),
                value: U256::from(0u64),
                data: Some("0x".to_string()),
                gas_limit: Some(21000),
                gas_price: Some(10_000_000_000),
                max_fee_per_gas: None,
                max_priority_fee_per_gas: None,
                nonce: Some(42),
                signature: None,
                hash: None,
                speed: Some(Speed::Fast),
                chain_id: 1,
                raw: None,
            }),
            priced_at: None,
            hashes: vec![],
            noop_count: None,
            is_canceled: Some(false),
            delete_at: None,
            metadata: None,
        };

        // Test with no NOOP attempts
        assert!(!too_many_noop_attempts(&tx));

        // Test with maximum NOOP attempts
        tx.noop_count = Some(MAXIMUM_NOOP_RETRY_ATTEMPTS);
        assert!(!too_many_noop_attempts(&tx));

        // Test with too many NOOP attempts
        tx.noop_count = Some(MAXIMUM_NOOP_RETRY_ATTEMPTS + 1);
        assert!(too_many_noop_attempts(&tx));
    }

    #[test]
    fn test_has_enough_confirmations() {
        // Not enough confirmations
        let tx_block_number = 100;
        let current_block_number = 110; // Only 10 confirmations
        let required_confirmations = 12;
        assert!(!has_enough_confirmations(
            tx_block_number,
            current_block_number,
            required_confirmations
        ));

        // Exactly enough confirmations
        let current_block_number = 112; // Exactly 12 confirmations
        assert!(has_enough_confirmations(
            tx_block_number,
            current_block_number,
            required_confirmations
        ));

        // More than enough confirmations
        let current_block_number = 120; // 20 confirmations
        assert!(has_enough_confirmations(
            tx_block_number,
            current_block_number,
            required_confirmations
        ));
    }

    #[test]
    fn test_is_transaction_valid_with_future_timestamp() {
        let now = Utc::now();
        let valid_until = Some((now + Duration::hours(1)).to_rfc3339());
        let created_at = now.to_rfc3339();

        assert!(is_transaction_valid(&created_at, &valid_until));
    }

    #[test]
    fn test_is_transaction_valid_with_past_timestamp() {
        let now = Utc::now();
        let valid_until = Some((now - Duration::hours(1)).to_rfc3339());
        let created_at = now.to_rfc3339();

        assert!(!is_transaction_valid(&created_at, &valid_until));
    }

    #[test]
    fn test_is_transaction_valid_with_valid_until() {
        // Test with valid_until in the future
        let created_at = Utc::now().to_rfc3339();
        let valid_until = Some((Utc::now() + Duration::hours(1)).to_rfc3339());
        assert!(is_transaction_valid(&created_at, &valid_until));

        // Test with valid_until in the past
        let valid_until = Some((Utc::now() - Duration::hours(1)).to_rfc3339());
        assert!(!is_transaction_valid(&created_at, &valid_until));

        // Test with valid_until exactly at current time (should be invalid)
        let valid_until = Some(Utc::now().to_rfc3339());
        assert!(!is_transaction_valid(&created_at, &valid_until));

        // Test with valid_until very far in the future
        let valid_until = Some((Utc::now() + Duration::days(365)).to_rfc3339());
        assert!(is_transaction_valid(&created_at, &valid_until));

        // Test with invalid valid_until format
        let valid_until = Some("invalid-date-format".to_string());
        assert!(!is_transaction_valid(&created_at, &valid_until));

        // Test with empty valid_until string
        let valid_until = Some("".to_string());
        assert!(!is_transaction_valid(&created_at, &valid_until));
    }

    #[test]
    fn test_is_transaction_valid_without_valid_until() {
        // Test with created_at within the default timespan
        let created_at = Utc::now().to_rfc3339();
        let valid_until = None;
        assert!(is_transaction_valid(&created_at, &valid_until));

        // Test with created_at older than the default timespan (8 hours)
        let old_created_at =
            (Utc::now() - Duration::milliseconds(DEFAULT_TX_VALID_TIMESPAN + 1000)).to_rfc3339();
        assert!(!is_transaction_valid(&old_created_at, &valid_until));

        // Test with created_at exactly at the boundary
        let boundary_created_at =
            (Utc::now() - Duration::milliseconds(DEFAULT_TX_VALID_TIMESPAN)).to_rfc3339();
        assert!(!is_transaction_valid(&boundary_created_at, &valid_until));

        // Test with created_at just within the default timespan
        let within_boundary_created_at =
            (Utc::now() - Duration::milliseconds(DEFAULT_TX_VALID_TIMESPAN - 1000)).to_rfc3339();
        assert!(is_transaction_valid(
            &within_boundary_created_at,
            &valid_until
        ));

        // Test with invalid created_at format
        let invalid_created_at = "invalid-date-format";
        assert!(!is_transaction_valid(invalid_created_at, &valid_until));

        // Test with empty created_at string
        assert!(!is_transaction_valid("", &valid_until));
    }

    #[test]
    fn test_ensure_status_success() {
        let tx = make_test_transaction(TransactionStatus::Pending);

        // Should succeed when status matches
        let result = ensure_status(&tx, TransactionStatus::Pending, Some("test_operation"));
        assert!(result.is_ok());
    }

    #[test]
    fn test_ensure_status_failure_with_operation() {
        let tx = make_test_transaction(TransactionStatus::Sent);

        // Should fail with operation context in error message
        let result = ensure_status(&tx, TransactionStatus::Pending, Some("prepare_transaction"));
        assert!(result.is_err());

        if let Err(TransactionError::ValidationError(msg)) = result {
            assert!(msg.contains("prepare_transaction"));
            assert!(msg.contains("Sent"));
            assert!(msg.contains("Pending"));
        } else {
            panic!("Expected ValidationError");
        }
    }

    #[test]
    fn test_ensure_status_failure_without_operation() {
        let tx = make_test_transaction(TransactionStatus::Sent);

        // Should fail without operation context
        let result = ensure_status(&tx, TransactionStatus::Pending, None);
        assert!(result.is_err());

        if let Err(TransactionError::ValidationError(msg)) = result {
            assert!(!msg.contains("for"));
            assert!(msg.contains("Sent"));
            assert!(msg.contains("Pending"));
        } else {
            panic!("Expected ValidationError");
        }
    }

    #[test]
    fn test_ensure_status_all_states() {
        // Test that ensure_status works for all possible status values
        let statuses = vec![
            TransactionStatus::Pending,
            TransactionStatus::Sent,
            TransactionStatus::Submitted,
            TransactionStatus::Mined,
            TransactionStatus::Confirmed,
            TransactionStatus::Failed,
            TransactionStatus::Expired,
            TransactionStatus::Canceled,
        ];

        for status in &statuses {
            let tx = make_test_transaction(status.clone());

            // Should succeed when expecting the same status
            assert!(ensure_status(&tx, status.clone(), Some("test")).is_ok());

            // Should fail when expecting a different status
            for other_status in &statuses {
                if other_status != status {
                    assert!(ensure_status(&tx, other_status.clone(), Some("test")).is_err());
                }
            }
        }
    }

    #[test]
    fn test_ensure_status_one_of_success() {
        let tx = make_test_transaction(TransactionStatus::Submitted);

        // Should succeed when status is in the list
        let result = ensure_status_one_of(
            &tx,
            &[TransactionStatus::Submitted, TransactionStatus::Mined],
            Some("resubmit_transaction"),
        );
        assert!(result.is_ok());
    }

    #[test]
    fn test_ensure_status_one_of_success_first_in_list() {
        let tx = make_test_transaction(TransactionStatus::Pending);

        // Should succeed when status is first in list
        let result = ensure_status_one_of(
            &tx,
            &[
                TransactionStatus::Pending,
                TransactionStatus::Sent,
                TransactionStatus::Submitted,
            ],
            Some("cancel_transaction"),
        );
        assert!(result.is_ok());
    }

    #[test]
    fn test_ensure_status_one_of_success_last_in_list() {
        let tx = make_test_transaction(TransactionStatus::Submitted);

        // Should succeed when status is last in list
        let result = ensure_status_one_of(
            &tx,
            &[
                TransactionStatus::Pending,
                TransactionStatus::Sent,
                TransactionStatus::Submitted,
            ],
            Some("cancel_transaction"),
        );
        assert!(result.is_ok());
    }

    #[test]
    fn test_ensure_status_one_of_failure_with_operation() {
        let tx = make_test_transaction(TransactionStatus::Confirmed);

        // Should fail with operation context when status not in list
        let result = ensure_status_one_of(
            &tx,
            &[TransactionStatus::Pending, TransactionStatus::Sent],
            Some("cancel_transaction"),
        );
        assert!(result.is_err());

        if let Err(TransactionError::ValidationError(msg)) = result {
            assert!(msg.contains("cancel_transaction"));
            assert!(msg.contains("Confirmed"));
            assert!(msg.contains("Pending"));
            assert!(msg.contains("Sent"));
        } else {
            panic!("Expected ValidationError");
        }
    }

    #[test]
    fn test_ensure_status_one_of_failure_without_operation() {
        let tx = make_test_transaction(TransactionStatus::Confirmed);

        // Should fail without operation context
        let result = ensure_status_one_of(
            &tx,
            &[TransactionStatus::Pending, TransactionStatus::Sent],
            None,
        );
        assert!(result.is_err());

        if let Err(TransactionError::ValidationError(msg)) = result {
            assert!(!msg.contains("for"));
            assert!(msg.contains("Confirmed"));
        } else {
            panic!("Expected ValidationError");
        }
    }

    #[test]
    fn test_ensure_status_one_of_single_status() {
        let tx = make_test_transaction(TransactionStatus::Pending);

        // Should work with a single status in the list
        let result = ensure_status_one_of(&tx, &[TransactionStatus::Pending], Some("test"));
        assert!(result.is_ok());

        // Should fail when status doesn't match
        let tx2 = make_test_transaction(TransactionStatus::Sent);
        let result = ensure_status_one_of(&tx2, &[TransactionStatus::Pending], Some("test"));
        assert!(result.is_err());
    }

    #[test]
    fn test_ensure_status_one_of_all_states() {
        let all_statuses = vec![
            TransactionStatus::Pending,
            TransactionStatus::Sent,
            TransactionStatus::Submitted,
            TransactionStatus::Mined,
            TransactionStatus::Confirmed,
            TransactionStatus::Failed,
            TransactionStatus::Expired,
            TransactionStatus::Canceled,
        ];

        // Should succeed for each status when it's in the list
        for status in &all_statuses {
            let tx = make_test_transaction(status.clone());
            let result = ensure_status_one_of(&tx, &all_statuses, Some("test"));
            assert!(result.is_ok());
        }
    }

    #[test]
    fn test_ensure_status_one_of_empty_list() {
        let tx = make_test_transaction(TransactionStatus::Pending);

        // Should always fail with empty list
        let result = ensure_status_one_of(&tx, &[], Some("test"));
        assert!(result.is_err());
    }

    #[test]
    fn test_ensure_status_error_message_formatting() {
        let tx = make_test_transaction(TransactionStatus::Confirmed);

        // Test error message format for ensure_status
        let result = ensure_status(&tx, TransactionStatus::Pending, Some("my_operation"));
        if let Err(TransactionError::ValidationError(msg)) = result {
            // Should have clear format: "Invalid transaction state for {operation}. Current: {current}, Expected: {expected}"
            assert!(msg.starts_with("Invalid transaction state for my_operation"));
            assert!(msg.contains("Current: Confirmed"));
            assert!(msg.contains("Expected: Pending"));
        } else {
            panic!("Expected ValidationError");
        }

        // Test error message format for ensure_status_one_of
        let result = ensure_status_one_of(
            &tx,
            &[TransactionStatus::Pending, TransactionStatus::Sent],
            Some("another_operation"),
        );
        if let Err(TransactionError::ValidationError(msg)) = result {
            // Should have clear format with list of expected states
            assert!(msg.starts_with("Invalid transaction state for another_operation"));
            assert!(msg.contains("Current: Confirmed"));
            assert!(msg.contains("Expected one of:"));
        } else {
            panic!("Expected ValidationError");
        }
    }

    #[test]
    fn test_get_age_since_created() {
        let now = Utc::now();

        // Test with transaction created 2 hours ago
        let created_time = now - Duration::hours(2);
        let tx = TransactionRepoModel {
            created_at: created_time.to_rfc3339(),
            ..create_mock_transaction()
        };

        let age_result = get_age_since_created(&tx);
        assert!(age_result.is_ok());
        let age = age_result.unwrap();
        // Age should be approximately 2 hours (with some tolerance)
        assert!(age.num_minutes() >= 119 && age.num_minutes() <= 121);
    }

    #[test]
    fn test_get_age_since_created_invalid_timestamp() {
        let tx = TransactionRepoModel {
            created_at: "invalid-timestamp".to_string(),
            ..create_mock_transaction()
        };

        let result = get_age_since_created(&tx);
        assert!(result.is_err());
        match result.unwrap_err() {
            TransactionError::UnexpectedError(msg) => {
                assert!(msg.contains("Invalid created_at timestamp"));
            }
            _ => panic!("Expected UnexpectedError for invalid timestamp"),
        }
    }

    #[test]
    fn test_get_age_since_created_recent_transaction() {
        let now = Utc::now();

        // Test with transaction created just 1 minute ago
        let created_time = now - Duration::minutes(1);
        let tx = TransactionRepoModel {
            created_at: created_time.to_rfc3339(),
            ..create_mock_transaction()
        };

        let age_result = get_age_since_created(&tx);
        assert!(age_result.is_ok());
        let age = age_result.unwrap();
        // Age should be approximately 1 minute
        assert!(age.num_seconds() >= 59 && age.num_seconds() <= 61);
    }

    #[test]
    fn test_get_age_since_status_change_with_sent_at() {
        let now = Utc::now();

        // Test with transaction that has sent_at (1 hour ago)
        let sent_time = now - Duration::hours(1);
        let created_time = now - Duration::hours(3); // Created 3 hours ago
        let tx = TransactionRepoModel {
            status: TransactionStatus::Sent,
            created_at: created_time.to_rfc3339(),
            sent_at: Some(sent_time.to_rfc3339()),
            ..create_mock_transaction()
        };

        let age_result = get_age_since_status_change(&tx);
        assert!(age_result.is_ok());
        let age = age_result.unwrap();
        // Should use sent_at (1 hour), not created_at (3 hours)
        assert!(age.num_minutes() >= 59 && age.num_minutes() <= 61);
    }

    #[test]
    fn test_get_age_since_status_change_without_sent_at() {
        let now = Utc::now();

        // Test with transaction that doesn't have sent_at
        let created_time = now - Duration::hours(2);
        let tx = TransactionRepoModel {
            created_at: created_time.to_rfc3339(),
            ..create_mock_transaction()
        };

        let age_result = get_age_since_status_change(&tx);
        assert!(age_result.is_ok());
        let age = age_result.unwrap();
        // Should fall back to created_at (2 hours)
        assert!(age.num_minutes() >= 119 && age.num_minutes() <= 121);
    }

    #[test]
    fn test_get_age_since_status_change_invalid_sent_at() {
        let now = Utc::now();
        let created_time = now - Duration::hours(2);

        let tx = TransactionRepoModel {
            status: TransactionStatus::Sent,
            created_at: created_time.to_rfc3339(),
            sent_at: Some("invalid-timestamp".to_string()),
            ..create_mock_transaction()
        };

        let result = get_age_since_status_change(&tx);
        assert!(result.is_err());
        match result.unwrap_err() {
            TransactionError::UnexpectedError(msg) => {
                assert!(msg.contains("Error parsing sent_at time"));
            }
            _ => panic!("Expected UnexpectedError for invalid sent_at timestamp"),
        }
    }

    #[test]
    fn test_is_too_early_to_resubmit_recent_transaction() {
        let now = Utc::now();

        // Test with transaction created just 1 second ago (too early)
        let created_time = now - Duration::seconds(1);
        let tx = TransactionRepoModel {
            created_at: created_time.to_rfc3339(),
            ..create_mock_transaction()
        };

        let result = is_too_early_to_resubmit(&tx);
        assert!(result.is_ok());
        assert!(result.unwrap()); // Should be true (too early)
    }

    #[test]
    fn test_is_too_early_to_resubmit_old_transaction() {
        let now = Utc::now();

        // Test with transaction created well past the minimum age
        let created_time = now - Duration::seconds(EVM_MIN_AGE_FOR_RESUBMIT_SECONDS + 10);
        let tx = TransactionRepoModel {
            created_at: created_time.to_rfc3339(),
            ..create_mock_transaction()
        };

        let result = is_too_early_to_resubmit(&tx);
        assert!(result.is_ok());
        assert!(!result.unwrap()); // Should be false (old enough to resubmit)
    }

    #[test]
    fn test_is_too_early_to_resubmit_boundary() {
        let now = Utc::now();

        // Test with transaction created exactly at the boundary
        let created_time = now - Duration::seconds(EVM_MIN_AGE_FOR_RESUBMIT_SECONDS);
        let tx = TransactionRepoModel {
            created_at: created_time.to_rfc3339(),
            ..create_mock_transaction()
        };

        let result = is_too_early_to_resubmit(&tx);
        assert!(result.is_ok());
        // At the exact boundary, should be false (not too early)
        assert!(!result.unwrap());
    }

    #[test]
    fn test_is_too_early_to_resubmit_invalid_timestamp() {
        let tx = TransactionRepoModel {
            created_at: "invalid-timestamp".to_string(),
            ..create_mock_transaction()
        };

        let result = is_too_early_to_resubmit(&tx);
        assert!(result.is_err());
        match result.unwrap_err() {
            TransactionError::UnexpectedError(msg) => {
                assert!(msg.contains("Invalid created_at timestamp"));
            }
            _ => panic!("Expected UnexpectedError for invalid timestamp"),
        }
    }
}
