//! Signs a prepared transaction and immediately submits it to the Solana blockchain.
//!
//! # Description
//!
//! This function combines the signing and submission steps into one operation. After validating
//! and signing the provided transaction, it is immediately sent to the blockchain for
//! execution. This is particularly useful when you want to reduce the number of
//! client-server interactions.
//!
//! # Parameters
//!
//! * `transaction` - A Base64-encoded prepared transaction that needs to be signed and submitted.
//!
//! # Returns
//!
//! On success, returns a tuple containing:
//!
//! * `transaction` - A Base64-encoded signed transaction that has been submitted.
//! * `signature` - Signature of the submitted transaction.
use std::str::FromStr;

use chrono::Utc;
use solana_sdk::{pubkey::Pubkey, transaction::Transaction};
use tracing::{debug, error};

use crate::{
    models::{
        produce_solana_rpc_webhook_payload, EncodedSerializedTransaction, NetworkTransactionData,
        NetworkTransactionRequest, SolanaFeePaymentStrategy,
        SolanaSignAndSendTransactionRequestParams, SolanaSignAndSendTransactionResult,
        SolanaTransactionData, SolanaTransactionRequest, SolanaWebhookRpcPayload,
        TransactionRepoModel, TransactionStatus, TransactionUpdateRequest,
    },
    repositories::{Repository, TransactionRepository},
    services::{provider::SolanaProviderTrait, signer::SolanaSignTrait, JupiterServiceTrait},
};

use super::*;

impl<P, S, J, JP, TR> SolanaRpcMethodsImpl<P, S, J, JP, TR>
where
    P: SolanaProviderTrait + Send + Sync,
    S: SolanaSignTrait + Send + Sync,
    J: JupiterServiceTrait + Send + Sync,
    JP: JobProducerTrait + Send + Sync,
    TR: TransactionRepository + Repository<TransactionRepoModel, String> + Send + Sync + 'static,
{
    pub(crate) async fn sign_and_send_transaction_impl(
        &self,
        params: SolanaSignAndSendTransactionRequestParams,
    ) -> Result<SolanaSignAndSendTransactionResult, SolanaRpcError> {
        debug!("Processing sign and send transaction request");
        let transaction_request = Transaction::try_from(params.transaction.clone())?;

        validate_sign_and_send_transaction(&transaction_request, &self.relayer, &*self.provider)
            .await?;

        let policy = self.relayer.policies.get_solana_policy();
        let total_fee = self
            .estimate_fee_with_margin(&transaction_request, policy.fee_margin_percentage)
            .await
            .map_err(|e| {
                error!(error = %e, "failed to estimate total fee");
                SolanaRpcError::Estimation(e.to_string())
            })?;

        let user_pays_fee =
            policy.fee_payment_strategy.unwrap_or_default() == SolanaFeePaymentStrategy::User;

        if user_pays_fee {
            self.confirm_user_fee_payment(&transaction_request, total_fee)
                .await?;
        }

        SolanaTransactionValidator::validate_max_fee(
            total_fee,
            &self.relayer.policies.get_solana_policy(),
        )?;
        // Validate relayer has sufficient balance
        SolanaTransactionValidator::validate_sufficient_relayer_balance(
            total_fee,
            &self.relayer.address,
            &self.relayer.policies.get_solana_policy(),
            &*self.provider,
        )
        .await
        .map_err(|e| {
            error!(error = %e, "insufficient funds");
            SolanaRpcError::InsufficientFunds(e.to_string())
        })?;

        let (signed_transaction, _) = self.relayer_sign_transaction(transaction_request).await?;

        let network_transaction = NetworkTransactionRequest::Solana(SolanaTransactionRequest {
            transaction: Some(params.transaction.clone()),
            instructions: None,
            valid_until: None,
        });

        let transaction =
            TransactionRepoModel::try_from((&network_transaction, &self.relayer, &self.network))
                .map_err(|e| {
                    error!(error = %e, "failed to create transaction repo model");
                    SolanaRpcError::Internal(e.to_string())
                })?;

        let tx_repo_model = self
            .transaction_repository
            .create(transaction.clone())
            .await
            .map_err(|e| {
                error!(error = %e, "failed to create transaction repo model");
                SolanaRpcError::Internal(e.to_string())
            })?;

        let send_signature = match self.provider.send_transaction(&signed_transaction).await {
            Ok(signature) => signature,
            Err(e) => {
                error!(
                    tx_id = %tx_repo_model.id,
                    error = %e,
                    "failed to send transaction - marking as failed"
                );

                // Mark transaction as failed in the database
                // Most RPC errors at this point are simulation failures or invalid transaction body
                let failure_reason = format!("Transaction send failed: {e}");
                let update = TransactionUpdateRequest {
                    status: Some(TransactionStatus::Failed),
                    status_reason: Some(failure_reason),
                    ..Default::default()
                };

                // Attempt to mark as failed, but don't fail the error return if update fails
                if let Err(update_err) = self
                    .transaction_repository
                    .partial_update(tx_repo_model.id.clone(), update)
                    .await
                {
                    error!(
                        tx_id = %tx_repo_model.id,
                        error = %update_err,
                        "failed to update transaction status to Failed"
                    );
                }

                return Err(SolanaRpcError::Send(e.to_string()));
            }
        };

        let update = TransactionUpdateRequest {
            status: Some(TransactionStatus::Submitted),
            sent_at: Some(Utc::now().to_rfc3339()),
            network_data: Some(NetworkTransactionData::Solana(SolanaTransactionData {
                signature: Some(send_signature.to_string()),
                transaction: Some(params.transaction.clone().into_inner()),
                ..Default::default()
            })),
            ..Default::default()
        };

        let _updated_tx = self
            .transaction_repository
            .partial_update(tx_repo_model.id.clone(), update)
            .await
            .map_err(|e| {
                error!(error = %e, "failed to update transaction status");
                SolanaRpcError::Internal(e.to_string())
            })?;

        let serialized_transaction = EncodedSerializedTransaction::try_from(&signed_transaction)?;

        let result = SolanaSignAndSendTransactionResult {
            transaction: serialized_transaction,
            signature: send_signature.to_string(),
            id: tx_repo_model.id.clone(),
        };

        if let Some(notification_id) = &self.relayer.notification_id {
            let webhook_result = self
                .job_producer
                .produce_send_notification_job(
                    produce_solana_rpc_webhook_payload(
                        notification_id,
                        "sign_and_send_transaction".to_string(),
                        SolanaWebhookRpcPayload::SignAndSendTransaction(result.clone()),
                    ),
                    None,
                )
                .await;

            if let Err(e) = webhook_result {
                error!(error = %e, "failed to produce notification job");
            }
        }

        self.schedule_status_check_job(&tx_repo_model, Some(5))
            .await?;

        debug!(
            "Transaction signed and sent successfully with signature: {}",
            result.signature
        );
        Ok(result)
    }
}

/// Validates a fully prepared Solana transaction according to relayer policies.
///
/// This orchestrates multiple validation checks in parallel for optimal performance.
///
/// # Validations Performed
/// - **Policy checks**: Allowed/disallowed accounts, programs, signatures, data size, fee payer
/// - **Blockhash validation**: Ensures blockhash is still valid on-chain
/// - **Simulation**: Executes transaction simulation on-chain
/// - **Transfer validation**: Validates lamports and token transfers
async fn validate_sign_and_send_transaction<P: SolanaProviderTrait + Send + Sync>(
    tx: &Transaction,
    relayer: &RelayerRepoModel,
    provider: &P,
) -> Result<(), SolanaTransactionValidationError> {
    use futures::{try_join, TryFutureExt};

    let policy = &relayer.policies.get_solana_policy();
    let relayer_pubkey = Pubkey::from_str(&relayer.address).map_err(|e| {
        SolanaTransactionValidationError::ValidationError(format!("Invalid relayer address: {e}"))
    })?;

    // Group all synchronous policy validations together
    let sync_validations = async {
        SolanaTransactionValidator::validate_tx_allowed_accounts(tx, policy)?;
        SolanaTransactionValidator::validate_tx_disallowed_accounts(tx, policy)?;
        SolanaTransactionValidator::validate_allowed_programs(tx, policy)?;
        SolanaTransactionValidator::validate_max_signatures(tx, policy)?;
        SolanaTransactionValidator::validate_fee_payer(tx, &relayer_pubkey)?;
        SolanaTransactionValidator::validate_data_size(tx, policy)?;
        Ok::<(), SolanaTransactionValidationError>(())
    };

    // Run all validations concurrently for optimal performance
    try_join!(
        sync_validations,
        SolanaTransactionValidator::validate_blockhash(tx, provider),
        SolanaTransactionValidator::simulate_transaction(tx, provider).map_ok(|_| ()),
        SolanaTransactionValidator::validate_token_transfers(tx, policy, provider, &relayer_pubkey),
        SolanaTransactionValidator::validate_lamports_transfers(tx, &relayer_pubkey),
    )?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use crate::{
        constants::WRAPPED_SOL_MINT,
        services::{QuoteResponse, RoutePlan, SwapInfo},
        utils::mocks::mockutils::create_mock_solana_transaction,
    };

    use super::super::test_setup::setup_signer_mocks;
    use super::*;
    use mockall::predicate::{self};
    use solana_sdk::{program_pack::Pack, signature::Signature, signer::Signer};
    use spl_token_interface::state::Account;

    #[tokio::test]
    async fn test_sign_and_send_transaction_success_relayer_fee_strategy() {
        let (
            relayer,
            mut signer,
            mut provider,
            jupiter_service,
            encoded_tx,
            mut job_producer,
            network,
        ) = setup_test_context();

        // Setup signer mocks and capture the expected signature
        let expected_signature = setup_signer_mocks(&mut signer, relayer.address.clone());

        provider
            .expect_is_blockhash_valid()
            .with(predicate::always(), predicate::always())
            .returning(|_, _| Box::pin(async { Ok(true) }));

        provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(1_000_000u64) }));

        provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async {
                Ok(solana_client::rpc_response::RpcSimulateTransactionResult {
                    err: None,
                    logs: None,
                    accounts: None,
                    units_consumed: None,
                    return_data: None,
                    replacement_blockhash: None,
                    inner_instructions: None,
                    loaded_accounts_data_size: None,
                    fee: None,
                    pre_balances: None,
                    post_balances: None,
                    pre_token_balances: None,
                    post_token_balances: None,
                    loaded_addresses: None,
                })
            })
        });

        provider
            .expect_send_transaction()
            .returning(move |_| Box::pin(async move { Ok(expected_signature) }));

        let mut tx_repo_mock = MockTransactionRepository::new();
        tx_repo_mock
            .expect_create()
            .returning(move |_| Ok(create_mock_solana_transaction()));

        tx_repo_mock
            .expect_partial_update()
            .returning(move |_, _| Ok(create_mock_solana_transaction()));

        job_producer
            .expect_produce_check_transaction_status_job()
            .returning(move |_, _| Box::pin(async { Ok(()) }));

        let rpc = SolanaRpcMethodsImpl::new_mock(
            relayer,
            network,
            Arc::new(provider),
            Arc::new(signer),
            Arc::new(jupiter_service),
            Arc::new(job_producer),
            Arc::new(tx_repo_mock),
        );

        let params = SolanaSignAndSendTransactionRequestParams {
            transaction: encoded_tx,
        };

        let result = rpc.sign_and_send_transaction(params).await;
        assert!(result.is_ok());

        let send_result = result.unwrap();
        assert_eq!(send_result.signature, expected_signature.to_string());
        assert!(!send_result.id.is_empty());
    }

    #[tokio::test]
    async fn test_sign_and_send_transaction_success_user_fee_strategy() {
        let mut ctx = setup_test_context_user_fee_strategy();
        let expected_signature = Signature::new_unique();

        ctx.provider
            .expect_get_account_from_pubkey()
            .returning(move |pubkey| {
                let pubkey = *pubkey;
                let relayer_pubkey = ctx.relayer_keypair.pubkey();
                let user_pubkey = ctx.user_keypair.pubkey();
                Box::pin(async move {
                    let mut account_data = vec![0; Account::LEN];

                    if pubkey == ctx.relayer_token_account {
                        // Create relayer's token account
                        let token_account = spl_token_interface::state::Account {
                            mint: ctx.token_mint,
                            owner: relayer_pubkey,
                            amount: 0, // Current balance doesn't matter
                            state: spl_token_interface::state::AccountState::Initialized,
                            ..Default::default()
                        };
                        spl_token_interface::state::Account::pack(token_account, &mut account_data)
                            .unwrap();

                        Ok(solana_sdk::account::Account {
                            lamports: 1_000_000,
                            data: account_data,
                            owner: spl_token_interface::id(),
                            executable: false,
                            rent_epoch: 0,
                        })
                    } else if pubkey == ctx.user_token_account {
                        // Create user's token account with sufficient balance
                        let token_account = spl_token_interface::state::Account {
                            mint: ctx.token_mint,
                            owner: user_pubkey,
                            amount: ctx.main_transfer_amount + ctx.fee_amount, // Enough for both transfers
                            state: spl_token_interface::state::AccountState::Initialized,
                            ..Default::default()
                        };
                        spl_token_interface::state::Account::pack(token_account, &mut account_data)
                            .unwrap();
                        Ok(solana_sdk::account::Account {
                            lamports: 1_000_000,
                            data: account_data,
                            owner: spl_token_interface::id(),
                            executable: false,
                            rent_epoch: 0,
                        })
                    } else {
                        Err(SolanaProviderError::RpcError(
                            "Account not found".to_string(),
                        ))
                    }
                })
            });

        // Setup signer mocks
        setup_signer_mocks(&mut ctx.signer, ctx.relayer.address.clone());

        ctx.provider
            .expect_is_blockhash_valid()
            .with(predicate::always(), predicate::always())
            .returning(|_, _| Box::pin(async { Ok(true) }));

        ctx.provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(1_000_000u64) }));

        ctx.provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        let token_clone = ctx.token.clone();
        ctx.jupiter_service
            .expect_get_sol_to_token_quote()
            .returning(move |_, _, _| {
                let token_clone = token_clone.clone();
                Box::pin(async {
                    Ok(QuoteResponse {
                        input_mint: WRAPPED_SOL_MINT.to_string(),
                        output_mint: token_clone,
                        in_amount: 5000,
                        out_amount: 100_000,
                        price_impact_pct: 0.1,
                        other_amount_threshold: 0,
                        slippage_bps: 1,
                        swap_mode: "ExactIn".to_string(),
                        route_plan: vec![RoutePlan {
                            swap_info: SwapInfo {
                                amm_key: "63mqrcydH89L7RhuMC3jLBojrRc2u3QWmjP4UrXsnotS".to_string(),
                                label: "Stabble Stable Swap".to_string(),
                                input_mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                                    .to_string(),
                                output_mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"
                                    .to_string(),
                                in_amount: "1000000".to_string(),
                                out_amount: "999984".to_string(),
                                fee_amount: Some("10".to_string()),
                                fee_mint: Some(
                                    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB".to_string(),
                                ),
                            },
                            percent: 1,
                        }],
                    })
                })
            });

        ctx.provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        ctx.provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async {
                Ok(solana_client::rpc_response::RpcSimulateTransactionResult {
                    err: None,
                    logs: None,
                    accounts: None,
                    units_consumed: None,
                    return_data: None,
                    replacement_blockhash: None,
                    inner_instructions: None,
                    loaded_accounts_data_size: None,
                    fee: None,
                    pre_balances: None,
                    post_balances: None,
                    pre_token_balances: None,
                    post_token_balances: None,
                    loaded_addresses: None,
                })
            })
        });

        ctx.provider
            .expect_send_transaction()
            .returning(move |_| Box::pin(async move { Ok(expected_signature) }));

        ctx.transaction_repository
            .expect_create()
            .returning(move |_| Ok(create_mock_solana_transaction()));

        ctx.transaction_repository
            .expect_partial_update()
            .returning(move |_, _| Ok(create_mock_solana_transaction()));

        ctx.job_producer
            .expect_produce_check_transaction_status_job()
            .returning(move |_, _| Box::pin(async { Ok(()) }));

        let rpc = SolanaRpcMethodsImpl::new_mock(
            ctx.relayer,
            ctx.network,
            Arc::new(ctx.provider),
            Arc::new(ctx.signer),
            Arc::new(ctx.jupiter_service),
            Arc::new(ctx.job_producer),
            Arc::new(ctx.transaction_repository),
        );

        let params = SolanaSignAndSendTransactionRequestParams {
            transaction: ctx.encoded_tx,
        };

        let result = rpc.sign_and_send_transaction_impl(params).await;

        assert!(
            result.is_ok(),
            "Should successfully sign transaction with token fee payment"
        );
        let send_result = result.unwrap();
        assert_eq!(send_result.signature, expected_signature.to_string());
    }

    #[tokio::test]
    async fn test_sign_and_send_transaction_insufficient_token_amount_user_fee_strategy() {
        let mut ctx = setup_test_context_user_fee_strategy();
        let expected_signature = Signature::new_unique();

        ctx.provider
            .expect_get_account_from_pubkey()
            .returning(move |pubkey| {
                let pubkey = *pubkey;
                let relayer_pubkey = ctx.relayer_keypair.pubkey();
                let user_pubkey = ctx.user_keypair.pubkey();
                Box::pin(async move {
                    let mut account_data = vec![0; Account::LEN];

                    if pubkey == ctx.relayer_token_account {
                        // Create relayer's token account
                        let token_account = spl_token_interface::state::Account {
                            mint: ctx.token_mint,
                            owner: relayer_pubkey,
                            amount: 0, // Current balance doesn't matter
                            state: spl_token_interface::state::AccountState::Initialized,
                            ..Default::default()
                        };
                        spl_token_interface::state::Account::pack(token_account, &mut account_data)
                            .unwrap();

                        Ok(solana_sdk::account::Account {
                            lamports: 1_000_000,
                            data: account_data,
                            owner: spl_token_interface::id(),
                            executable: false,
                            rent_epoch: 0,
                        })
                    } else if pubkey == ctx.user_token_account {
                        // Create user's token account with sufficient balance
                        let token_account = spl_token_interface::state::Account {
                            mint: ctx.token_mint,
                            owner: user_pubkey,
                            amount: 1_000_000, // NOT enough for both transfers
                            state: spl_token_interface::state::AccountState::Initialized,
                            ..Default::default()
                        };
                        spl_token_interface::state::Account::pack(token_account, &mut account_data)
                            .unwrap();
                        Ok(solana_sdk::account::Account {
                            lamports: 1_000_000,
                            data: account_data,
                            owner: spl_token_interface::id(),
                            executable: false,
                            rent_epoch: 0,
                        })
                    } else {
                        Err(SolanaProviderError::RpcError(
                            "Account not found".to_string(),
                        ))
                    }
                })
            });

        // Setup signer mocks
        setup_signer_mocks(&mut ctx.signer, ctx.relayer.address.clone());

        ctx.provider
            .expect_is_blockhash_valid()
            .with(predicate::always(), predicate::always())
            .returning(|_, _| Box::pin(async { Ok(true) }));

        ctx.provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(1_000_000u64) }));

        ctx.provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        let token_clone = ctx.token.clone();
        ctx.jupiter_service
            .expect_get_sol_to_token_quote()
            .returning(move |_, _, _| {
                let token_clone = token_clone.clone();
                Box::pin(async {
                    Ok(QuoteResponse {
                        input_mint: WRAPPED_SOL_MINT.to_string(),
                        output_mint: token_clone,
                        in_amount: 5000,
                        out_amount: 100_000,
                        price_impact_pct: 0.1,
                        other_amount_threshold: 0,
                        slippage_bps: 1,
                        swap_mode: "ExactIn".to_string(),
                        route_plan: vec![RoutePlan {
                            swap_info: SwapInfo {
                                amm_key: "63mqrcydH89L7RhuMC3jLBojrRc2u3QWmjP4UrXsnotS".to_string(),
                                label: "Stabble Stable Swap".to_string(),
                                input_mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                                    .to_string(),
                                output_mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"
                                    .to_string(),
                                in_amount: "1000000".to_string(),
                                out_amount: "999984".to_string(),
                                fee_amount: Some("10".to_string()),
                                fee_mint: Some(
                                    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB".to_string(),
                                ),
                            },
                            percent: 1,
                        }],
                    })
                })
            });

        ctx.provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        ctx.provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async {
                Ok(solana_client::rpc_response::RpcSimulateTransactionResult {
                    err: None,
                    logs: None,
                    accounts: None,
                    units_consumed: None,
                    return_data: None,
                    replacement_blockhash: None,
                    inner_instructions: None,
                    loaded_accounts_data_size: None,
                    fee: None,
                    pre_balances: None,
                    post_balances: None,
                    pre_token_balances: None,
                    post_token_balances: None,
                    loaded_addresses: None,
                })
            })
        });

        ctx.provider
            .expect_send_transaction()
            .returning(move |_| Box::pin(async move { Ok(expected_signature) }));

        let rpc = SolanaRpcMethodsImpl::new_mock(
            ctx.relayer,
            ctx.network,
            Arc::new(ctx.provider),
            Arc::new(ctx.signer),
            Arc::new(ctx.jupiter_service),
            Arc::new(ctx.job_producer),
            Arc::new(ctx.transaction_repository),
        );

        let params = SolanaSignAndSendTransactionRequestParams {
            transaction: ctx.encoded_tx,
        };

        let result = rpc.sign_and_send_transaction_impl(params).await;

        assert!(result.is_err());

        match result {
            Err(SolanaRpcError::SolanaTransactionValidation(err)) => {
                let error_string = err.to_string();
                assert!(
                    error_string
                        .contains("Insufficient balance for cumulative transfers: account "),
                    "Unexpected error message: {err}"
                );
                assert!(
                    error_string.contains(
                        "has balance 1000000 but requires 6000000 across all instructions"
                    ),
                    "Unexpected error message: {err}"
                );
            }
            other => panic!("Expected ValidationError, got: {other:?}"),
        }
    }

    #[tokio::test]
    async fn test_sign_and_send_transaction_insufficient_balance_user_fee_strategy() {
        let mut ctx = setup_test_context_user_fee_strategy();
        let expected_signature = Signature::new_unique();

        ctx.provider
            .expect_get_account_from_pubkey()
            .returning(move |pubkey| {
                let pubkey = *pubkey;
                let relayer_pubkey = ctx.relayer_keypair.pubkey();
                let user_pubkey = ctx.user_keypair.pubkey();
                Box::pin(async move {
                    let mut account_data = vec![0; Account::LEN];

                    if pubkey == ctx.relayer_token_account {
                        // Create relayer's token account
                        let token_account = spl_token_interface::state::Account {
                            mint: ctx.token_mint,
                            owner: relayer_pubkey,
                            amount: 0, // Current balance doesn't matter
                            state: spl_token_interface::state::AccountState::Initialized,
                            ..Default::default()
                        };
                        spl_token_interface::state::Account::pack(token_account, &mut account_data)
                            .unwrap();

                        Ok(solana_sdk::account::Account {
                            lamports: 1_000_000,
                            data: account_data,
                            owner: spl_token_interface::id(),
                            executable: false,
                            rent_epoch: 0,
                        })
                    } else if pubkey == ctx.user_token_account {
                        // Create user's token account with sufficient balance
                        let token_account = spl_token_interface::state::Account {
                            mint: ctx.token_mint,
                            owner: user_pubkey,
                            amount: ctx.main_transfer_amount + ctx.fee_amount, // Enough for both transfers
                            state: spl_token_interface::state::AccountState::Initialized,
                            ..Default::default()
                        };
                        spl_token_interface::state::Account::pack(token_account, &mut account_data)
                            .unwrap();
                        Ok(solana_sdk::account::Account {
                            lamports: 1_000_000,
                            data: account_data,
                            owner: spl_token_interface::id(),
                            executable: false,
                            rent_epoch: 0,
                        })
                    } else {
                        Err(SolanaProviderError::RpcError(
                            "Account not found".to_string(),
                        ))
                    }
                })
            });

        // Setup signer mocks
        setup_signer_mocks(&mut ctx.signer, ctx.relayer.address.clone());

        ctx.provider
            .expect_is_blockhash_valid()
            .with(predicate::always(), predicate::always())
            .returning(|_, _| Box::pin(async { Ok(true) }));

        ctx.provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(1_000_000u64) }));

        ctx.provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000) }));

        let token_clone = ctx.token.clone();
        ctx.jupiter_service
            .expect_get_sol_to_token_quote()
            .returning(move |_, _, _| {
                let token_clone = token_clone.clone();
                Box::pin(async {
                    Ok(QuoteResponse {
                        input_mint: WRAPPED_SOL_MINT.to_string(),
                        output_mint: token_clone,
                        in_amount: 5000,
                        out_amount: 100_000,
                        price_impact_pct: 0.1,
                        other_amount_threshold: 0,
                        slippage_bps: 1,
                        swap_mode: "ExactIn".to_string(),
                        route_plan: vec![RoutePlan {
                            swap_info: SwapInfo {
                                amm_key: "63mqrcydH89L7RhuMC3jLBojrRc2u3QWmjP4UrXsnotS".to_string(),
                                label: "Stabble Stable Swap".to_string(),
                                input_mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                                    .to_string(),
                                output_mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"
                                    .to_string(),
                                in_amount: "1000000".to_string(),
                                out_amount: "999984".to_string(),
                                fee_amount: Some("10".to_string()),
                                fee_mint: Some(
                                    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB".to_string(),
                                ),
                            },
                            percent: 1,
                        }],
                    })
                })
            });

        ctx.provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        ctx.provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async {
                Ok(solana_client::rpc_response::RpcSimulateTransactionResult {
                    err: None,
                    logs: None,
                    accounts: None,
                    units_consumed: None,
                    return_data: None,
                    replacement_blockhash: None,
                    inner_instructions: None,
                    loaded_accounts_data_size: None,
                    fee: None,
                    pre_balances: None,
                    post_balances: None,
                    pre_token_balances: None,
                    post_token_balances: None,
                    loaded_addresses: None,
                })
            })
        });

        ctx.provider
            .expect_send_transaction()
            .returning(move |_| Box::pin(async move { Ok(expected_signature) }));

        let rpc = SolanaRpcMethodsImpl::new_mock(
            ctx.relayer,
            ctx.network,
            Arc::new(ctx.provider),
            Arc::new(ctx.signer),
            Arc::new(ctx.jupiter_service),
            Arc::new(ctx.job_producer),
            Arc::new(ctx.transaction_repository),
        );

        let params = SolanaSignAndSendTransactionRequestParams {
            transaction: ctx.encoded_tx,
        };

        let result = rpc.sign_and_send_transaction_impl(params).await;

        assert!(result.is_err());

        match result {
            Err(SolanaRpcError::InsufficientFunds(err)) => {
                let error_string = err.to_string();
                assert!(
                    error_string.contains("Insufficient balance:"),
                    "Unexpected error message: {err}"
                );
            }
            other => panic!("Expected ValidationError, got: {other:?}"),
        }
    }

    #[tokio::test]
    async fn test_sign_and_send_transaction_invalid_blockhash() {
        let (relayer, signer, mut provider, jupiter_service, encoded_tx, job_producer, network) =
            setup_test_context();

        // Blockhash validation will be triggered for multi-signer transactions
        // and will fail, causing validation to error out
        provider
            .expect_is_blockhash_valid()
            .returning(|_, _| Box::pin(async { Ok(false) }));

        // Other validations may be called concurrently even if blockhash validation fails
        provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async {
                Ok(solana_client::rpc_response::RpcSimulateTransactionResult {
                    err: None,
                    logs: None,
                    accounts: None,
                    units_consumed: None,
                    return_data: None,
                    inner_instructions: None,
                    replacement_blockhash: None,
                    loaded_accounts_data_size: None,
                    fee: None,
                    pre_balances: None,
                    post_balances: None,
                    pre_token_balances: None,
                    post_token_balances: None,
                    loaded_addresses: None,
                })
            })
        });

        provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(1_000_000u64) }));

        provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000u64) }));

        let rpc = SolanaRpcMethodsImpl::new_mock(
            relayer,
            network,
            Arc::new(provider),
            Arc::new(signer),
            Arc::new(jupiter_service),
            Arc::new(job_producer),
            Arc::new(MockTransactionRepository::new()),
        );

        let result = rpc
            .sign_and_send_transaction_impl(SolanaSignAndSendTransactionRequestParams {
                transaction: encoded_tx,
            })
            .await;

        assert!(matches!(
            result,
            Err(SolanaRpcError::SolanaTransactionValidation(_))
        ));
    }

    #[tokio::test]
    async fn test_sign_and_send_transaction_simulation_failure() {
        let (relayer, mut signer, mut provider, jupiter_service, encoded_tx, job_producer, network) =
            setup_test_context();

        // Setup signer mocks
        setup_signer_mocks(&mut signer, relayer.address.clone());

        provider
            .expect_is_blockhash_valid()
            .returning(|_, _| Box::pin(async { Ok(true) }));

        provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(1_000_000u64) }));

        provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async { Err(SolanaProviderError::RpcError("Simulate error".to_string())) })
        });

        let rpc = SolanaRpcMethodsImpl::new_mock(
            relayer,
            network,
            Arc::new(provider),
            Arc::new(signer),
            Arc::new(jupiter_service),
            Arc::new(job_producer),
            Arc::new(MockTransactionRepository::new()),
        );

        let result = rpc
            .sign_and_send_transaction_impl(SolanaSignAndSendTransactionRequestParams {
                transaction: encoded_tx,
            })
            .await;
        assert!(matches!(
            result,
            Err(SolanaRpcError::SolanaTransactionValidation(_))
        ));
    }

    #[tokio::test]
    async fn test_sign_and_send_transaction_with_webhook_success() {
        let (
            mut relayer,
            mut signer,
            mut provider,
            jupiter_service,
            encoded_tx,
            mut job_producer,
            network,
        ) = setup_test_context();

        relayer.notification_id = Some("test-webhook-id".to_string());

        // Setup signer mocks and capture the signature
        let signature = setup_signer_mocks(&mut signer, relayer.address.clone());

        provider
            .expect_is_blockhash_valid()
            .returning(|_, _| Box::pin(async { Ok(true) }));

        provider
            .expect_calculate_total_fee()
            .returning(|_| Box::pin(async { Ok(5000u64) }));

        provider
            .expect_get_balance()
            .returning(|_| Box::pin(async { Ok(1_000_000_000) }));

        provider.expect_simulate_transaction().returning(|_| {
            Box::pin(async {
                Ok(solana_client::rpc_response::RpcSimulateTransactionResult {
                    err: None,
                    logs: None,
                    accounts: None,
                    units_consumed: None,
                    return_data: None,
                    replacement_blockhash: None,
                    inner_instructions: None,
                    loaded_accounts_data_size: None,
                    fee: None,
                    pre_balances: None,
                    post_balances: None,
                    pre_token_balances: None,
                    post_token_balances: None,
                    loaded_addresses: None,
                })
            })
        });

        provider
            .expect_send_transaction()
            .returning(move |_| Box::pin(async move { Ok(signature) }));

        // Expect webhook job to be produced
        job_producer
            .expect_produce_send_notification_job()
            .withf(move |notification, _| {
                matches!(notification.notification_id.as_str(), "test-webhook-id")
            })
            .times(1)
            .returning(|_, _| Box::pin(async { Ok(()) }));

        let mut tx_repo_mock = MockTransactionRepository::new();

        tx_repo_mock
            .expect_create()
            .returning(move |_| Ok(create_mock_solana_transaction()));

        tx_repo_mock
            .expect_partial_update()
            .returning(move |_, _| Ok(create_mock_solana_transaction()));

        job_producer
            .expect_produce_check_transaction_status_job()
            .returning(move |_, _| Box::pin(async { Ok(()) }));

        let rpc = SolanaRpcMethodsImpl::new_mock(
            relayer,
            network,
            Arc::new(provider),
            Arc::new(signer),
            Arc::new(jupiter_service),
            Arc::new(job_producer),
            Arc::new(tx_repo_mock),
        );

        let params = SolanaSignAndSendTransactionRequestParams {
            transaction: encoded_tx,
        };

        let result = rpc.sign_and_send_transaction_impl(params).await;
        assert!(result.is_ok());
    }
}
