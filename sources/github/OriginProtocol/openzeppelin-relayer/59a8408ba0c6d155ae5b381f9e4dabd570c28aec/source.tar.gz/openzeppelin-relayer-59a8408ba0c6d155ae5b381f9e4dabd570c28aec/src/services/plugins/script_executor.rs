//! This module is responsible for executing a typescript script.
//!
//! 1. Checks if `ts-node` is installed.
//! 2. Executes the script using the `ts-node` command.
//! 3. Returns the output and errors of the script.
use serde::{Deserialize, Serialize};
use std::process::Stdio;
use tokio::process::Command;
use utoipa::ToSchema;

use super::PluginError;

#[derive(Serialize, Deserialize, Debug, PartialEq, Clone, ToSchema)]
#[serde(rename_all = "lowercase")]
pub enum LogLevel {
    Log,
    Info,
    Error,
    Warn,
    Debug,
    Result,
}

#[derive(Serialize, Deserialize, Debug, PartialEq, Clone, ToSchema)]
pub struct LogEntry {
    pub level: LogLevel,
    pub message: String,
}

#[derive(Serialize, Deserialize, Debug, ToSchema)]
pub struct ScriptResult {
    pub logs: Vec<LogEntry>,
    pub error: String,
    pub trace: Vec<serde_json::Value>,
    pub return_value: String,
}

pub struct ScriptExecutor;

impl ScriptExecutor {
    #[allow(clippy::too_many_arguments)]
    pub async fn execute_typescript(
        plugin_id: String,
        script_path: String,
        socket_path: String,
        script_params: String,
        http_request_id: Option<String>,
        headers_json: Option<String>,
        route: Option<String>,
        config_json: Option<String>,
        method: Option<String>,
        query_json: Option<String>,
    ) -> Result<ScriptResult, PluginError> {
        if Command::new("ts-node")
            .arg("--version")
            .output()
            .await
            .is_err()
        {
            return Err(PluginError::SocketError(
                "ts-node is not installed or not in PATH. Please install it with: npm install -g ts-node".to_string()
            ));
        }

        // Use the centralized executor script instead of executing user script directly
        // Use absolute path to avoid working directory issues in CI
        let executor_path = std::env::current_dir()
            .map(|cwd| cwd.join("plugins/lib/executor.ts").display().to_string())
            .unwrap_or_else(|_| "plugins/lib/executor.ts".to_string());

        let output = Command::new("ts-node")
            .arg(executor_path)       // Execute executor script
            .arg(socket_path)         // Socket path (argv[2])
            .arg(plugin_id)           // Plugin ID (argv[3])
            .arg(script_params)       // Plugin parameters (argv[4])
            .arg(script_path)         // User script path (argv[5])
            .arg(http_request_id.unwrap_or_default()) // HTTP x-request-id (argv[6], optional)
            .arg(headers_json.unwrap_or_default()) // HTTP headers as JSON (argv[7], optional)
            .arg(route.unwrap_or_default()) // Wildcard route (argv[8], optional)
            .arg(config_json.unwrap_or_default()) // Plugin config as JSON (argv[9], optional)
            .arg(method.unwrap_or_default()) // HTTP method (argv[10], optional)
            .arg(query_json.unwrap_or_default()) // Query parameters as JSON (argv[11], optional)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .output()
            .await
            .map_err(|e| PluginError::SocketError(format!("Failed to execute script: {e}")))?;

        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);

        let (logs, return_value) =
            Self::parse_logs(stdout.lines().map(|l| l.to_string()).collect())?;

        // Check if the script failed (non-zero exit code)
        if !output.status.success() {
            // Try to parse error info from stderr
            if let Some(error_line) = stderr.lines().find(|l| !l.trim().is_empty()) {
                if let Ok(error_info) = serde_json::from_str::<serde_json::Value>(error_line) {
                    let message = error_info["message"]
                        .as_str()
                        .unwrap_or(&stderr)
                        .to_string();
                    let status = error_info
                        .get("status")
                        .and_then(|v| v.as_u64())
                        .unwrap_or(500) as u16;
                    let code = error_info
                        .get("code")
                        .and_then(|v| v.as_str())
                        .map(|s| s.to_string());
                    let details = error_info
                        .get("details")
                        .cloned()
                        .or_else(|| error_info.get("data").cloned());
                    return Err(PluginError::HandlerError(Box::new(
                        super::PluginHandlerPayload {
                            message,
                            status,
                            code,
                            details,
                            logs: Some(logs),
                            traces: None,
                        },
                    )));
                }
            }
            // Fallback to stderr as error message
            return Err(PluginError::HandlerError(Box::new(
                super::PluginHandlerPayload {
                    message: stderr.to_string(),
                    status: 500,
                    code: None,
                    details: None,
                    logs: Some(logs),
                    traces: None,
                },
            )));
        }

        Ok(ScriptResult {
            logs,
            return_value,
            error: stderr.to_string(),
            trace: Vec::new(),
        })
    }

    fn parse_logs(logs: Vec<String>) -> Result<(Vec<LogEntry>, String), PluginError> {
        let mut result = Vec::new();
        let mut return_value = String::new();

        for log in logs {
            let log: LogEntry = serde_json::from_str(&log).map_err(|e| {
                PluginError::PluginExecutionError(format!("Failed to parse log: {e}"))
            })?;

            if log.level == LogLevel::Result {
                return_value = log.message;
            } else {
                result.push(log);
            }
        }

        Ok((result, return_value))
    }
}

#[cfg(test)]
mod tests {
    use std::fs;

    use tempfile::tempdir;

    use super::*;

    static TS_CONFIG: &str = r#"
    {
        "compilerOptions": {
          "target": "es2016",
          "module": "commonjs",
          "esModuleInterop": true,
          "forceConsistentCasingInFileNames": true,
          "strict": true,
          "skipLibCheck": true
        }
      }
"#;

    #[tokio::test]
    async fn test_execute_typescript() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir.path().join("test_execute_typescript.ts");
        let socket_path = temp_dir.path().join("test_execute_typescript.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('test');
                console.info('test-info');
                return 'test-result';
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-1".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert_eq!(result.logs[0].message, "test");
        assert_eq!(result.logs[1].level, LogLevel::Info);
        assert_eq!(result.logs[1].message, "test-info");
        assert_eq!(result.return_value, "test-result");
    }

    #[tokio::test]
    async fn test_execute_typescript_with_result() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_with_result.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_with_result.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('test');
                console.info('test-info');
                return {
                    test: 'test-result',
                    test2: 'test-result2'
                };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-1".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert_eq!(result.logs[0].message, "test");
        assert_eq!(result.logs[1].level, LogLevel::Info);
        assert_eq!(result.logs[1].message, "test-info");
        assert_eq!(
            result.return_value,
            "{\"test\":\"test-result\",\"test2\":\"test-result2\"}"
        );
    }

    #[tokio::test]
    async fn test_execute_typescript_error() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir.path().join("test_execute_typescript_error.ts");
        let socket_path = temp_dir.path().join("test_execute_typescript_error.sock");

        let content = "console.logger('test');";
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-1".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        // Script errors should now return an Err with PluginFailed
        assert!(result.is_err());

        if let Err(PluginError::HandlerError(ctx)) = result {
            // The error will be from our JSON output or raw stderr
            // It should contain error info about the logger issue
            assert_eq!(ctx.status, 500);
            // The message should contain something about the error
            assert!(!ctx.message.is_empty());
        } else {
            panic!("Expected PluginError::HandlerError, got: {result:?}");
        }
    }

    #[tokio::test]
    async fn test_execute_typescript_handler_json_error() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_handler_json_error.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_handler_json_error.sock");

        // This handler throws an error with code/status/details; our executor should capture
        // and emit a normalized JSON error to stderr which the Rust side parses.
        let content = r#"
            export async function handler(_api: any, _params: any) {
                const err: any = new Error('Validation failed');
                err.code = 'VALIDATION_FAILED';
                err.status = 422;
                err.details = { field: 'email' };
                throw err;
            }
        "#;
        fs::write(&script_path, content).unwrap();
        fs::write(&ts_config, TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-json-error".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        match result {
            Err(PluginError::HandlerError(ctx)) => {
                assert_eq!(ctx.message, "Validation failed");
                assert_eq!(ctx.status, 422);
                assert_eq!(ctx.code.as_deref(), Some("VALIDATION_FAILED"));
                let d = ctx.details.expect("details should be present");
                assert_eq!(d["field"].as_str(), Some("email"));
            }
            other => panic!("Expected HandlerError, got: {other:?}"),
        }
    }
    #[tokio::test]
    async fn test_parse_logs_error() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir.path().join("test_execute_typescript.ts");
        let socket_path = temp_dir.path().join("test_execute_typescript.sock");

        let invalid_content = r#"
            export async function handler(api: any, params: any) {
                // Output raw invalid JSON directly to stdout (bypasses LogInterceptor)
                process.stdout.write('invalid json line\n');
                process.stdout.write('{"level":"log","message":"valid"}\n');
                process.stdout.write('another invalid line\n');
                return 'test';
            }
        "#;
        fs::write(script_path.clone(), invalid_content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-1".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_err());
        assert!(result
            .err()
            .unwrap()
            .to_string()
            .contains("Failed to parse log"));
    }

    #[tokio::test]
    async fn test_execute_typescript_with_headers() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_with_headers.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_with_headers.sock");

        // Plugin using modern context pattern to access headers
        let content = r#"
            export async function handler(context: any) {
                const { headers, params } = context;
                console.log(`Received ${Object.keys(headers).length} headers`);
                return {
                    headerCount: Object.keys(headers).length,
                    customHeader: headers['x-custom-header']?.[0],
                    authHeader: headers['authorization']?.[0],
                    multiValueHeader: headers['x-multi-value'],
                    params: params
                };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        // Create headers JSON matching HashMap<String, Vec<String>>
        let headers_json = r#"{"x-custom-header":["custom-value"],"authorization":["Bearer token123"],"x-multi-value":["value1","value2"]}"#;

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-headers".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            r#"{"foo":"bar"}"#.to_string(),
            None,
            Some(headers_json.to_string()),
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();

        // Verify log output
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert!(result.logs[0].message.contains("Received 3 headers"));

        // Parse return value and verify headers were accessible
        let return_obj: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");

        assert_eq!(return_obj["headerCount"], 3);
        assert_eq!(return_obj["customHeader"], "custom-value");
        assert_eq!(return_obj["authHeader"], "Bearer token123");
        assert_eq!(
            return_obj["multiValueHeader"],
            serde_json::json!(["value1", "value2"])
        );
        assert_eq!(return_obj["params"], serde_json::json!({"foo": "bar"}));
    }

    #[tokio::test]
    async fn test_execute_typescript_all_log_levels() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_all_log_levels.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_all_log_levels.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('log message');
                console.info('info message');
                console.warn('warn message');
                console.error('error message');
                console.debug('debug message');
                return 'success';
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-log-levels".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs.len(), 5);
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert_eq!(result.logs[0].message, "log message");
        assert_eq!(result.logs[1].level, LogLevel::Info);
        assert_eq!(result.logs[1].message, "info message");
        assert_eq!(result.logs[2].level, LogLevel::Warn);
        assert_eq!(result.logs[2].message, "warn message");
        assert_eq!(result.logs[3].level, LogLevel::Error);
        assert_eq!(result.logs[3].message, "error message");
        assert_eq!(result.logs[4].level, LogLevel::Debug);
        assert_eq!(result.logs[4].message, "debug message");
        assert_eq!(result.return_value, "success");
    }

    #[tokio::test]
    async fn test_execute_typescript_with_request_id() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_with_request_id.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_with_request_id.sock");

        // Note: The request ID is passed to the executor but not directly accessible
        // in the plugin handler. It's used for internal tracing/logging.
        // This test verifies the parameter is accepted without errors.
        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('handler executed');
                return { status: 'ok' };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-request-id".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            Some("req-12345-abcde".to_string()),
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert_eq!(result.logs[0].message, "handler executed");
        assert_eq!(result.return_value, "{\"status\":\"ok\"}");
    }

    #[tokio::test]
    async fn test_execute_typescript_empty_return() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_empty_return.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_empty_return.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('handler called');
                // Return undefined (no explicit return)
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-empty-return".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert_eq!(result.logs[0].message, "handler called");
        // undefined becomes empty string or "undefined" depending on serialization
        assert!(result.return_value.is_empty() || result.return_value == "undefined");
    }

    #[tokio::test]
    async fn test_execute_typescript_null_return() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_null_return.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_null_return.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('returning null');
                return null;
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-null-return".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.return_value, "null");
    }

    #[tokio::test]
    async fn test_execute_typescript_legacy_two_param_handler() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_legacy_handler.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_legacy_handler.sock");

        // Explicitly test the legacy 2-parameter handler pattern
        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('legacy handler');
                return {
                    paramsReceived: params,
                    handlerType: 'legacy-2-param'
                };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-legacy".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            r#"{"key":"value"}"#.to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert_eq!(result.logs[0].message, "legacy handler");

        let return_obj: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");
        assert_eq!(return_obj["handlerType"], "legacy-2-param");
        assert_eq!(
            return_obj["paramsReceived"],
            serde_json::json!({"key": "value"})
        );
    }

    #[tokio::test]
    async fn test_execute_typescript_context_single_param_handler() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_context_handler.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_context_handler.sock");

        // Test the modern context-based single parameter handler
        let content = r#"
            export async function handler(context: any) {
                const { api, params, kv, headers } = context;
                console.log('modern context handler');
                return {
                    paramsReceived: params,
                    hasApi: !!api,
                    hasKv: !!kv,
                    hasHeaders: !!headers,
                    handlerType: 'modern-context'
                };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-context".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            r#"{"foo":"bar"}"#.to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();

        let return_obj: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");
        assert_eq!(return_obj["handlerType"], "modern-context");
        assert_eq!(return_obj["hasApi"], true);
        assert_eq!(return_obj["hasKv"], true);
        assert_eq!(return_obj["hasHeaders"], true);
        assert_eq!(
            return_obj["paramsReceived"],
            serde_json::json!({"foo": "bar"})
        );
    }

    #[tokio::test]
    async fn test_execute_typescript_complex_params() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_complex_params.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_complex_params.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log(`Received ${params.items.length} items`);
                return {
                    processedItems: params.items.map((item: any) => ({
                        ...item,
                        processed: true
                    })),
                    metadata: params.metadata,
                    totalCount: params.items.length
                };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let complex_params = r#"{
            "items": [
                {"id": 1, "name": "item1", "tags": ["a", "b"]},
                {"id": 2, "name": "item2", "tags": ["c", "d"]}
            ],
            "metadata": {
                "source": "test",
                "timestamp": 1234567890,
                "nested": {
                    "deep": {
                        "value": true
                    }
                }
            }
        }"#;

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-complex-params".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            complex_params.to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert!(result.logs[0].message.contains("Received 2 items"));

        let return_obj: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");
        assert_eq!(return_obj["totalCount"], 2);
        assert_eq!(return_obj["processedItems"][0]["processed"], true);
        assert_eq!(return_obj["processedItems"][1]["processed"], true);
        assert_eq!(return_obj["processedItems"][0]["name"], "item1");
        assert_eq!(return_obj["metadata"]["source"], "test");
        assert_eq!(return_obj["metadata"]["nested"]["deep"]["value"], true);
    }

    #[tokio::test]
    async fn test_execute_typescript_empty_params() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_empty_params.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_empty_params.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log(`Params is empty: ${Object.keys(params).length === 0}`);
                return { receivedEmptyParams: Object.keys(params).length === 0 };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-empty-params".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();
        assert!(result.logs[0].message.contains("Params is empty: true"));

        let return_obj: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");
        assert_eq!(return_obj["receivedEmptyParams"], true);
    }

    #[tokio::test]
    async fn test_execute_typescript_array_return() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_array_return.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_array_return.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.log('returning array');
                return [1, 2, 3, { nested: 'value' }, 'string'];
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-array-return".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();

        let return_array: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");
        assert!(return_array.is_array());
        assert_eq!(return_array[0], 1);
        assert_eq!(return_array[1], 2);
        assert_eq!(return_array[2], 3);
        assert_eq!(return_array[3]["nested"], "value");
        assert_eq!(return_array[4], "string");
    }

    #[tokio::test]
    async fn test_execute_typescript_multiple_errors() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_multiple_errors.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_multiple_errors.sock");

        let content = r#"
            export async function handler(api: any, params: any) {
                console.error('Error message 1');
                console.error('Error message 2');
                console.warn('Warning message');
                throw new Error('Handler failed');
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-multiple-errors".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            "{}".to_string(),
            None,
            None,
            None,
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_err());
        if let Err(PluginError::HandlerError(ctx)) = result {
            // Should capture logs even when handler fails
            let logs = ctx.logs.expect("logs should be present");
            assert_eq!(logs.len(), 3);
            assert_eq!(logs[0].level, LogLevel::Error);
            assert_eq!(logs[0].message, "Error message 1");
            assert_eq!(logs[1].level, LogLevel::Error);
            assert_eq!(logs[1].message, "Error message 2");
            assert_eq!(logs[2].level, LogLevel::Warn);
            assert_eq!(logs[2].message, "Warning message");
            assert!(ctx.message.contains("Handler failed"));
        } else {
            panic!("Expected HandlerError");
        }
    }

    #[tokio::test]
    async fn test_execute_typescript_with_route() {
        let temp_dir = tempdir().unwrap();
        let ts_config = temp_dir.path().join("tsconfig.json");
        let script_path = temp_dir
            .path()
            .join("test_execute_typescript_with_route.ts");
        let socket_path = temp_dir
            .path()
            .join("test_execute_typescript_with_route.sock");

        // Plugin using modern context pattern to access route
        let content = r#"
            export async function handler(context: any) {
                const { route, params } = context;
                console.log(`Received route: ${route}`);
                return {
                    route: route,
                    params: params
                };
            }
        "#;
        fs::write(script_path.clone(), content).unwrap();
        fs::write(ts_config.clone(), TS_CONFIG.as_bytes()).unwrap();

        let result = ScriptExecutor::execute_typescript(
            "test-plugin-route".to_string(),
            script_path.display().to_string(),
            socket_path.display().to_string(),
            r#"{"foo":"bar"}"#.to_string(),
            None,
            None,
            Some("/verify".to_string()),
            None,
            None,
            None,
        )
        .await;

        assert!(result.is_ok());
        let result = result.unwrap();

        // Verify log output
        assert_eq!(result.logs[0].level, LogLevel::Log);
        assert!(result.logs[0].message.contains("Received route: /verify"));

        // Parse return value and verify route was accessible
        let return_obj: serde_json::Value =
            serde_json::from_str(&result.return_value).expect("Failed to parse return value");

        assert_eq!(return_obj["route"], "/verify");
        assert_eq!(return_obj["params"], serde_json::json!({"foo": "bar"}));
    }
}
