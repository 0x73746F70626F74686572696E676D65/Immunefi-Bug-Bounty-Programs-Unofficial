# OpenZeppelin Relayer — LaunchTube Plugin Example

Run the LaunchTube plugin with OpenZeppelin Relayer to simplify Stellar Soroban transactions. LaunchTube handles fees, sequence numbers, simulation, and retries automatically.

## Quick Start

```bash
# Clone and navigate to this example:
git clone https://github.com/OpenZeppelin/openzeppelin-relayer
cd openzeppelin-relayer/examples/launchtube-plugin-example

# Then follow the Setup steps below
```

## Prerequisites

- Docker and Docker Compose
- Rust (for generating keys and IDs)
- Node.js >= 18 and pnpm >= 10

## Setup

You only need to:

1. Install and build the LaunchTube plugin
2. Create the keys for LaunchTube accounts
3. Set up environment variables
4. Start Docker to get account addresses
5. Fund accounts on testnet

All configurations are pre-set for testnet use.

### 1. Install Dependencies

Install and build the LaunchTube plugin:

```bash
# From this directory (examples/launchtube-plugin-example)
cd launchtube
pnpm install
pnpm run build
cd ..
```

### 2. Create Keys and Configuration

LaunchTube requires two types of keys:

- **Fund account**: Pays transaction fees
- **Sequence accounts**: Manage sequence numbers (at least 2 recommended)

From this directory (`examples/launchtube-plugin-example`), run these commands:

#### Create LaunchTube accounts

```bash
# Replace each YOUR_PASSWORD with a unique strong password for each key
# You will need to add these passwords to your .env file
# Password must contain at least one uppercase letter, one lowercase letter,
# one number, and one special character (e.g., MyPass123!)

# Create fund account (pays fees)
cargo run --example create_key -- \
  --password YOUR_PASSWORD \
  --output-dir config/keys \
  --filename launchtube-fund.json

# Create first sequence account
cargo run --example create_key -- \
  --password YOUR_PASSWORD \
  --output-dir config/keys \
  --filename launchtube-seq-001.json

# Create second sequence account (recommended for better throughput)
cargo run --example create_key -- \
  --password YOUR_PASSWORD \
  --output-dir config/keys \
  --filename launchtube-seq-002.json
```

#### Generate API credentials

```bash
# Generate API key (save this output)
cargo run --example generate_uuid

# Generate webhook signing key (save this output)
cargo run --example generate_uuid
```

#### Create environment file

Create `.env` in this directory:

```env
REDIS_URL=redis://redis:6379
KEYSTORE_PASSPHRASE_FUND=YOUR_PASSWORD
KEYSTORE_PASSPHRASE_SEQ_001=YOUR_PASSWORD
KEYSTORE_PASSPHRASE_SEQ_002=YOUR_PASSWORD
WEBHOOK_SIGNING_KEY=<webhook_key_from_above>
API_KEY=<api_key_from_above>
# LaunchTube Configuration
STELLAR_NETWORK=testnet
LAUNCHTUBE_ADMIN_SECRET=<admin_secret_for_launchtube_mgmt_api>
SOROBAN_RPC_URL=https://soroban-testnet.stellar.org
FUND_RELAYER_ID=launchtube-fund
LOCK_TTL_SECONDS=30
LOG_LEVEL=info
```

### 2b. Provision LaunchTube Sequence Accounts

After generating the credentials above, you can use the bundled TypeScript
script to create the required relayers, signers, and Stellar accounts while also
updating the LaunchTube plugin configuration:

```bash
cd launchtube
pnpm install
pnpm exec tsx ./scripts/create-sequence-accounts.ts \
  --total 3 \
  --base-url http://localhost:8080 \
  --api-key <RELAYER_API_KEY> \
  --funding-relayer launchtube-fund \
  --plugin-id launchtube-plugin \
  --plugin-admin-secret <LAUNCHTUBE_ADMIN_SECRET> \
  --network testnet

# Rerun with --fix to audit or heal any partially created state
pnpm exec tsx ./scripts/create-sequence-accounts.ts \
  --total 3 \
  --base-url http://localhost:8080 \
  --api-key <RELAYER_API_KEY> \
  --funding-relayer launchtube-fund \
  --plugin-id launchtube-plugin \
  --plugin-admin-secret <LAUNCHTUBE_ADMIN_SECRET> \
  --network testnet \
  --fix
```

The script waits for each funding transaction to confirm, prints a summary of
the relayer/signer state, and updates the LaunchTube management API with the
sequence account list so the plugin is immediately ready for use.

### 3. Verify Configuration

The LaunchTube plugin and relayer configurations are already set up for testnet. The configurations include:

**`config/config.json`** (pre-configured):

- Three relayers defined: `launchtube-fund`, `launchtube-seq-001`, `launchtube-seq-002`
- The Fund relayer has `concurrent_transactions: true` enabled in policies to allow parallel processing
- Corresponding signers pointing to the key files you'll create
- Plugin registered as `launchtube-plugin`

**LaunchTube Configuration** (via environment variables):

LaunchTube is configured through environment variables in your `.env` file:

- `STELLAR_NETWORK=testnet` - Sets the Stellar network
- `SOROBAN_RPC_URL=https://soroban-testnet.stellar.org` - RPC endpoint
- `FUND_RELAYER_ID=launchtube-fund` - ID of the fund relayer
- `LAUNCHTUBE_ADMIN_SECRET` - Admin secret for LaunchTube operations
- `LOCK_TTL_SECONDS=30` - Lock timeout for sequence management

### 4. (Optional) Configure Webhooks

For transaction notifications, edit `config/config.json` to add a webhook notification:

```json
{
  "notifications": [
    {
      "id": "webhook-notification",
      "type": "webhook",
      "url": "https://webhook.site/your-unique-id",
      "signing_key": {
        "type": "env",
        "value": "WEBHOOK_SIGNING_KEY"
      }
    }
  ]
}
```

### 5. Start the Service and Get Account Addresses

```bash
docker compose up
```

The relayer will start and display the public addresses for your accounts in the logs:

```
relayer-1  | Syncing sequence for relayer: launchtube-fund (GCP7KWGZCDDVBFKANDJTA74H2HSORV34SMSQIPGZ3PK7V6OHKCFGRTF6)
relayer-1  | Syncing sequence for relayer: launchtube-seq-001 (GCWFXU6HZNHLTXMHWZRPXYBZFOODJYRDZXFOPMUQN4S2JJGEZA2ZHA4B)
relayer-1  | Syncing sequence for relayer: launchtube-seq-002 (GA7IXWK3VKF25JOXJZZ7XMFB3A3IPM5A66MW5DJ6FPOIWME4F66UK4HL)
```

### 6. Fund Your Accounts on Testnet

In a new terminal, copy the addresses from the logs above and fund them:

```bash
# Replace with your actual addresses from the logs
curl "https://friendbot.stellar.org?addr=YOUR_FUND_ADDRESS"     # fund account
curl "https://friendbot.stellar.org?addr=YOUR_SEQ_001_ADDRESS"  # seq-001
curl "https://friendbot.stellar.org?addr=YOUR_SEQ_002_ADDRESS"  # seq-002
```

After funding, restart the service for it to recognize the funded accounts:

```bash
# Stop the service with Ctrl+C, then restart
docker compose up
```

### 7. Initialize Sequence Accounts

**Critical Step**: Before LaunchTube can process transactions, you must configure the sequence accounts using the Management API:

```bash
# Replace YOUR_API_KEY with your actual API key from the .env file
# Replace YOUR_ADMIN_SECRET with your LAUNCHTUBE_ADMIN_SECRET from the .env file
curl -X POST http://localhost:8080/api/v1/plugins/launchtube-plugin/call \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "params": {
      "management": {
        "action": "setSequenceAccounts",
        "adminSecret": "YOUR_ADMIN_SECRET",
        "relayerIds": ["launchtube-seq-001", "launchtube-seq-002"]
      }
    }
  }'
```

**Expected Response (HTTP 200):**

```json
{
  "success": true,
  "data": {
    "result": {
      "ok": true,
      "appliedRelayerIds": ["launchtube-seq-001", "launchtube-seq-002"]
    }
  },
  "error": null
}
```

## Usage

### Test Connection

```bash
curl -X GET http://localhost:8080/api/v1/plugins \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Submit Transactions

#### Option 1: Complete Transaction XDR

```bash
curl -X POST http://localhost:8080/api/v1/plugins/launchtube-plugin/call \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "params": {
      "xdr": "AAAAAgAAAAA...",
      "sim": false
    }
  }'
```

#### Option 2: Soroban Function + Auth

```bash
curl -X POST http://localhost:8080/api/v1/plugins/launchtube-plugin/call \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "params": {
      "func": "AAAABAAAAAEAAAAGc3ltYm9s...",
      "auth": ["AAAACAAAAAEAAAA..."],
      "sim": true
    }
  }'
```

**Parameters:**

- `xdr`: Complete transaction envelope XDR
- `func`: Soroban host function XDR
- `auth`: Array of authorization entry XDRs
- `sim`: Simulate before submission (true/false)

> Use either `xdr` OR `func`+`auth`, not both

**Response (HTTP 200):**

```json
{
  "success": true,
  "data": {
    "result": {
      "transactionId": "tx_123456",
      "status": "submitted",
      "hash": "1234567890abcdef..."
    }
  },
  "error": null
}
```

## Local Plugin Development (Swap Built Output Only)

If you're actively developing `@openzeppelin/relayer-plugin-launchtube`, you can replace only the installed package's built output (`dist/`) with your local build — no code or package.json changes required.

### One-time setup

1. Set an environment variable pointing to your local plugin directory:

```bash
export LAUNCHTUBE_PLUGIN_DIR=/path/to/your/relayer-plugin-launchtube
```

Replace `/path/to/your/relayer-plugin-launchtube` with the actual path to your local plugin repository.

2. Build the plugin so `dist/` exists (or run a watch build):

```bash
pnpm -C $LAUNCHTUBE_PLUGIN_DIR install
pnpm -C $LAUNCHTUBE_PLUGIN_DIR build
```

### Start with the dev override

`docker-compose.plugin-dev.yaml` mounts your local plugin's `dist/` over the installed package's `dist/` in the container.

```bash
export LAUNCHTUBE_PLUGIN_LOCAL_DIST=$LAUNCHTUBE_PLUGIN_DIR/dist
docker compose -f docker-compose.yaml -f docker-compose.plugin-dev.yaml up -d --build
```

Under the hood:

- Your local `dist/` is mounted at `/app/plugins/launchtube/node_modules/@openzeppelin/relayer-plugin-launchtube/dist` inside the container.
- Dependencies remain intact from the installed npm package; only the runtime JS is swapped.

### Iterating on code

1. Edit code in your plugin repo.
2. Rebuild the plugin outputs (e.g., `pnpm -C $LAUNCHTUBE_PLUGIN_DIR build`).
3. Restart the relayer to reload the module: `docker compose restart relayer`.

````

### Management API

LaunchTube provides a management API to dynamically configure sequence accounts. This requires the `LAUNCHTUBE_ADMIN_SECRET` from your `.env` file.

#### List Current Sequence Accounts

```bash
curl -X POST http://localhost:8080/api/v1/plugins/launchtube-plugin/call \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "params": {
      "management": {
        "action": "listSequenceAccounts",
        "adminSecret": "YOUR_ADMIN_SECRET"
      }
    }
  }'
````

#### Add or Update Sequence Accounts

```bash
curl -X POST http://localhost:8080/api/v1/plugins/launchtube-plugin/call \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "params": {
      "management": {
        "action": "setSequenceAccounts",
        "adminSecret": "YOUR_ADMIN_SECRET",
        "relayerIds": ["launchtube-seq-001", "launchtube-seq-002", "launchtube-seq-003"]
      }
    }
  }'
```

**Important Notes:**

- You must configure at least one sequence account before LaunchTube can process transactions
- The management API will prevent removing accounts that are currently locked (in use)
- All relayer IDs must exist in your OpenZeppelin Relayer configuration

### Generating XDR for the Relayer

Use [@stellar/stellar-sdk](https://stellar.github.io/js-stellar-sdk/TransactionBuilder.html) to export either a full transaction envelope XDR, or Soroban `func` + `auth` XDRs.

#### Full transaction envelope XDR

```ts
import { Networks, TransactionBuilder, rpc } from '@stellar/stellar-sdk';

// ...build your tx with TransactionBuilder and Contract.call(...)
const tx = new TransactionBuilder(account, {
  fee: '100',
  networkPassphrase: Networks.TESTNET,
})
  .addOperation(/* Operation.invokeHostFunction from Contract.call(...) */)
  .setTimeout(30)
  .build();

// Optional: pre-simulate to set resources/fees before signing
const sim = await rpcServer.simulateTransaction(tx);
const prepared = rpc.assembleTransaction(tx, sim).build();
prepared.sign(keypair);

// Export base64 envelope XDR
const envelopeXdr = prepared.toXDR();
```

#### Soroban `func` + `auth` XDR

```ts
// Build and simulate first to obtain auth
const baseTx = /* TransactionBuilder(...).addOperation(...).build() */;
const sim = await rpcServer.simulateTransaction(baseTx);

// Apply simulation, then extract from the single InvokeHostFunction op
const assembled = rpc.assembleTransaction(baseTx, sim).build();
const op = assembled.operations[0]; // Operation.InvokeHostFunction

const funcXdr = op.func.toXDR("base64");
const authXdrs = (op.auth ?? []).map(a => a.toXDR("base64"));
```

## How It Works

1. **Request Validation**: Validates input parameters and extracts Soroban data
2. **Sequence Account Pool**: Acquires an available sequence account
3. **Auth Checking**: Validates authorization entries
4. **Simulation** (if enabled): Simulates transaction and rebuilds with proper resources
5. **Fee Bumping**: Fund account wraps transaction with fee bump
6. **Submission**: Sends to Stellar network

### Concurrent Transaction Processing

This example uses multiple Stellar accounts (fund account + sequence accounts) with `concurrent_transactions: true` enabled in the fund account relayer policy. This configuration:

- **Allows parallel processing**: Fund account leverages the sequence accounts sequence number, so transactions can be processed concurrently without blocking each other
- **Improves throughput**: Multiple transactions can be in-flight simultaneously

## Troubleshooting

### Common issues

- **Plugin not found**: Verify the plugin `id` and `path` in `examples/launchtube-plugin-example/config/config.json`.
- **Missing LaunchTube config**: Ensure required environment variables are set in `.env` and that sequence accounts are configured via the Management API.
- **API authentication**: Ensure the `Authorization` header is present and the `API_KEY` is set in `.env`.
- **Webhook not received**: Ensure the `notifications[0].url` is set to a reachable URL.

### View logs

```bash
docker compose -f examples/launchtube-plugin-example/docker-compose.yaml logs -f relayer
```

## Docker notes

This compose file mounts:

```yaml
volumes:
  - ./config:/app/config/
  - ../../config/networks:/app/config/networks
  - ./launchtube:/app/plugins/launchtube
```

The container image already includes the relayer and plugin runtime. You only need to mount your config and the LaunchTube plugin wrapper.

## Learn more

- LaunchTube plugin GitHub: `https://github.com/OpenZeppelin/relayer-plugin-launchtube`
- LaunchTube on npm: `https://www.npmjs.com/package/@openzeppelin/relayer-plugin-launchtube`
- OpenZeppelin Relayer docs: `https://docs.openzeppelin.com/relayer`
