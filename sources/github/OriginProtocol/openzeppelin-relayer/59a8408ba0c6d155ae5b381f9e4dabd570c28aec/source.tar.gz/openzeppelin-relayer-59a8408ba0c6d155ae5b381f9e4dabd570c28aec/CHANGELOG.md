# Changelog

## [1.4.0](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v1.3.0...v1.4.0) (2026-02-20)


### 🚀 Features

* add evm intrinsic gas_limit validation ([dd1b2d6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/dd1b2d6768d09f051791d0db68c912a38d273715))
* Add metrics for failed and successful txs ([#637](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/637)) ([e770954](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e770954d4c07b8b634df7beb43362c44a64d28fe))
* Add status check circuit breaker ([#623](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/623)) ([961bc68](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/961bc68278e5da89f25846d88f7618392af9750f))
* add the number requests to plugin metric ([#645](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/645)) ([fc97ddc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/fc97ddc9183feb7c9e656fbacc95e00325908cf1))
* Adding Local node using Anvil ([#594](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/594)) ([4716987](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/47169872ef950937f8fd6a7df298b7bad2c53ff3))
* Background queue connection improvements ([#640](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/640)) ([1fe278c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1fe278ccc0410650f63f453ff86d51b4ef3470f6))
* Cleanup improvements ([#651](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/651)) ([34448a7](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/34448a7b9f8f52397cb7a73912e00d52b286b2e8))
* **evm:** add status_reason for failed on-chain transactions ([#522](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/522)) ([#659](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/659)) ([d81325d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d81325d38d4bc48b36ab854f23f859c304ad6a6a))
* Fix fd issue ([#615](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/615)) ([ae411bd](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ae411bd773308b8ca4216f9456bfe40866ccd23c))
* Forward plugin logs to Rust logs ([#589](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/589)) ([d250717](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d25071765bd7d8804f199adceb0383077df36106))
* Handle Stellar tx submission status ([#626](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/626)) ([#629](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/629)) ([4c30746](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4c307463a1767ff3d6e398446e32bb5e00646033))
* Improve plugin lock usage ([#638](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/638)) ([d52d03f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d52d03f863c2886b8278feb9aa30f2b1f6670379))
* Improve ready route, expose more stats ([#632](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/632)) ([9447c19](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9447c19d9ca212453104993676fccdb2e6c60d53))
* Improve request id tracing logic ([#656](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/656)) ([6dd1431](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6dd143178085ec3fcb2b953ecd0b78d3efdfa41a))
* Improve tracing logs ([#639](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/639)) ([a2e2243](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a2e22433eacf9b74669a79c2c77ee1d95c0866fe))
* Pass arbitrary payloads to script execution ([#312](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/312)) ([adecaf5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/adecaf5d73c3df9083c6a3fcf62ed669bc90b25c))
* Plugin performance improvements ([#606](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/606)) ([bfc7033](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/bfc70335d6ed4250f77176bb399fc1582dd55dac))
* Plugin routing support ([#587](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/587)) ([7ad8bee](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7ad8beeda185ef3e865ade834593879967762d5b))
* Redis conn optimisations ([#630](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/630)) ([a2cd2c6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a2cd2c610016973ef6b3955eeba92bf91db52332))
* Redis pool ([#609](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/609)) ([0350f61](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0350f617da2747dc373fefddb2248cd5e80f581c))
* RPC improvements ([#600](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/600)) ([0ac8b4c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0ac8b4cb5286c119113bd52bfdd8ff564c15e2fc))
* SQS queue backend support ([#650](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/650)) ([2740c76](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2740c760b7d5fd32ae8af389b89efb4ee58715f0))
* Stellar soroban gas abstraction ([#642](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/642)) ([3a9b71c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3a9b71cd76c367c2a8bac1f05e280229345b8ace))
* **stellar:** Add simple resubmit logic ([#665](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/665)) ([8dc11a7](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8dc11a735fcf05c4b0444972ee0c2193f4e3ad91))
* **stellar:** Surface inner failure details ([#653](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/653)) ([9a23b17](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9a23b17a75b41d83b97c0c24fe3ee0334928c6e3))
* Store and return stellar soroban transaction result ([#590](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/590)) ([9370790](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9370790d4272f27edb3c269ed517572fe38107a2))
* Support more frequent transaction cleanup ([#617](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/617)) ([c92fb2a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c92fb2a10aeb1d3e4b06f478744ef03ab5a3fa0e))
* Transaction store optimisations ([#611](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/611)) ([00de860](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/00de86075ddd6326e5df359cad809de555f197f0))
* Use separate connection for queues ([#646](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/646)) ([badb70c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/badb70c845f00c284de4104652b366f116bc437e))


### 🐛 Bug Fixes

* Adding coverage report for integration tests ([#599](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/599)) ([f350048](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f3500489da3ee8de3086943f4ea09e8bb3f4e86c))
* Adding worker for removing redis queues metadata ([#620](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/620)) ([3ce6c19](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3ce6c1902e8895129883b745129b83a7c046b35e))
* Encrypt google kms key ([#603](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/603)) ([e6faf5a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e6faf5aa92520f46d553ef36c381b733a869dcc9))
* Encryption for webhook signing key ([#619](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/619)) ([df776b0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/df776b0c5394faaab90c4f0123dc43f22a70f14f))
* Fix SDK breaking change for calling plugins method ([#607](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/607)) ([82117e1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/82117e160256f60148349ade730b85cd33846f0e))
* Fix system cleanup redis usage ([#625](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/625)) ([f5e903f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f5e903f90dff197700f92ef81dd5e3ef7abeae90))
* Google kms universe_domain security validation ([#610](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/610)) ([19f47dc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/19f47dcc86c3d0bfb47f24e91e75dba3bf9d81f6))
* Improve security for Redis container ([#598](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/598)) ([caa5803](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/caa5803fa5ad806115aa788afea44c5566d54ee2))
* Improve security validations for RPC urls ([#605](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/605)) ([0f9b288](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0f9b288721225666a639ace895b976d18b5236c0))
* Limit transaction cleanup concurrency ([#618](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/618)) ([5d3e267](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5d3e26744eddf9c6865defc3fb016d629215e787))
* **logging:** preserve span context when output is warn-filtered ([#658](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/658)) ([c33635d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c33635de541a805b09674225a29995b9421b1eab))
* plat-6480 allow transferring wrapped sol tokens ([#132](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/132)) ([f04e66a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f04e66a568c877c2a4c5c5378fb6017c2e41d2c6))
* Recover stuck Stellar Sent transactions ([#612](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/612)) ([d3d5e32](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d3d5e3295136e39656b36b587392215efa8d5dab))
* Revert queue buffer changes ([#648](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/648)) ([e7ad9b8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e7ad9b858c69920bc359666365eeb54c8d27f2c4))
* Skip re-simulation for pre-simulated fee-bump ([#631](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/631)) ([582fba7](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/582fba7e74d8b6930da85fea3747a22362c323a6))
* stellar tx data persistence ([#500](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/500)) ([d60a019](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d60a01958582aa5ab70b2dc369b1531d493db637))
* Use rustls tls in stellar client ([#596](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/596)) ([459a301](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/459a301d554698929ee56d98720a041c5757675e))

## [1.3.0](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v1.2.0...v1.3.0) (2025-12-05)


### 🚀 Features

* Add AWS KMS Ed25519 support ([#567](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/567)) ([d87d41b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d87d41bf4b819ac0bfd2c11dd1e7ac053fd7797f))
* Stellar sponsored transactions (gas abstraction) ([#563](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/563)) ([9a38990](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9a3899073cc3a73d6f2c3501b7af572d23cddba7))
* Transactions list endpoint - sort improvements ([#573](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/573)) ([63433ad](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/63433ad71208cbdb6bd1508d7df2c66b6839e81d))
* Update plugin system to support HTTP headers ([#566](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/566)) ([26e66a2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/26e66a228d155917c87691774c234cbe346d2990))


### 🐛 Bug Fixes


## [1.2.0](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v1.1.0...v1.2.0) (2025-11-11)


### 🚀 Features

* Add background job redis collections prefix support ([#484](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/484)) ([971ab9b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/971ab9b49c1397247a36d6daf54738249e854132))
* Add Channels plugin documentation and update navigation ([#530](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/530)) ([cbb1fba](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/cbb1fba363ac4b82e85427d0edb0466c6cff6f7f))
* Add channels plugin example ([#526](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/526)) ([6a107c6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6a107c6ef7866011a39ac4011d520fc745b5ac86))
* Add EIP-712 signing and KMS fixes ([#501](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/501)) ([23c9c7d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/23c9c7d6f589fbcc540303c6800b38196750449f))
* add INTHEWILD.md ([#543](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/543)) ([2592dc1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2592dc13b2908c0e9d0f47312f1952b6e4484553))
* Add key-value storage support for plugins ([#463](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/463)) ([dfb12e0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/dfb12e0128088eda36f827b9346348783e1d1651))
* Add optimism-based tag to networks ([#439](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/439)) ([101338d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/101338d843ceef854edc7863f25ec528db2d3f5e))
* Add PEAQ network ([#465](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/465)) ([0c23016](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0c2301675b2fed1576d8ae7eb261f5faca1803c0))
* Add plugin requestId support ([#471](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/471)) ([0296ed1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0296ed1b778dbd2139059fcf88015158d6ad16b0))
* Add SEI network ([#477](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/477)) ([9174be4](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9174be4f4cb0db7c9dc1e54eef94a77cc55c94eb))
* Add Stellar account creation script ([#503](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/503)) ([0550c49](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0550c49444be585c6d40c43514758f57604d818b))
* Add Stellar Channels Guide documentation ([#544](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/544)) ([5c45c67](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5c45c67cc342e70e63f2115ccadcf3c47450e119))
* Add support for Japan Open Chain ([#464](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/464)) ([44aaad1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/44aaad1d9f51e354992861282cadab4c51f3b1e5))
* Authentication improvements ([#456](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/456)) ([429e29e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/429e29e55a72e9d5c13a5ce6d7024edeb8d942ac))
* Enhance LaunchTube plugin configuration ([#473](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/473)) ([84bde73](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/84bde737b20cea48cb10ae575fe4f96515795243))
* Enhance logging with requestIds for traceability ([#455](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/455)) ([25b453f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/25b453f8c385e8abc4c5dc31fc0d9b9467ed3031))
* Enhance Stellar with concurrent transaction support ([#423](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/423)) ([7e7fb4f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7e7fb4ffba95133c4eb983c9d8ef0b0b4bc0c786))
* gas price cache ([#422](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/422)) ([6b838c5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6b838c5121e84bec4f50edf16ac5fc601d1fce3d))
* Implement network inheritance for configs ([#428](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/428)) ([818258a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/818258a7b2770523f869e812113b1b3079926360))
* Improve plugin error handling and response structure ([#480](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/480)) ([a9bd690](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a9bd6903ade06335511a25ada1cf0a25966590b3))
* Include method tag in solana rpc result ([#437](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/437)) ([53ad7b0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/53ad7b0c5fd0a9571a1d753c623818be6f4429d7))
* **polkadot:** Add Polkadot testnet and TLS 1.3 compatibility ([#525](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/525)) ([9a3780c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9a3780c632b8016b322d70b5b1287b3b859165fa))
* **polygon-zkevm:** Support for custom estimation methods ([#461](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/461)) ([1180d92](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1180d921da23d5b0d675c441a926600dc72d49bc))
* Relayer health check job ([#506](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/506)) ([de01f67](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/de01f67e8ca2a30c5b5c99b98dc5bcc8c735ec34))
* replace l2 extra fees with price overriders ([#460](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/460)) ([da2d90e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/da2d90e958bb6f86d3227f251b1981672a9a4fb1))
* RPC logic improvements ([#535](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/535)) ([68b2145](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/68b214559a8957f79c40fe43477a2f2aebf6026a))
* Scalability improvements ([#515](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/515)) ([471128d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/471128d51951bf6cb89dcd206ce821bd5146937c))
* **signer:** Implement CDP signing for evm+solana ([#457](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/457)) ([187ca0c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/187ca0c5de9889d5ad39433abcf54408cb66596f))
* Solana send transaction endpoint ([#521](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/521)) ([1ecb022](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1ecb022e2acbc928e3834451240477e32d9140b8))
* **stellar:** Add Google Cloud KMS signer support ([#481](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/481)) ([9886d84](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9886d842888cf5549f2dbcf488543c46011bb2fd))
* **stellar:** Add Turnkey signer support ([#495](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/495)) ([2a8cdde](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2a8cddec0625556fe46c4b6fa0194906ef4eea57))
* Unify mempool detection ([#427](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/427)) ([63c04dc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/63c04dce27f8afb3a136e8b0400ca7853def19d8))
* Update alloy package ([#430](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/430)) ([1725804](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1725804bcb534b58a23216de18386f1dad0485d7))


### 🐛 Bug Fixes

* Add launchtube env vars to docker-compose ([#425](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/425)) ([3879b88](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3879b88932313e28b3a9b8dcaf97edfa944ccea7))
* **cdp:** Solana signing ([187ca0c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/187ca0c5de9889d5ad39433abcf54408cb66596f))
* clippy issues with deps ([#434](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/434)) ([632b93c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/632b93cea00a8c7ea7d16b21ccac7c545160a6ed))
* Docker cross-platform build architecture mismatch ([#496](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/496)) ([5c4fdaa](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5c4fdaa99a796f0ad8a1540e4e8b784c425a12b5))
* fix alloy error mapping and improve provider retry logic ([#540](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/540)) ([f181f15](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f181f15d161f34ce3b0be0a3a755a3b1542344e7))
* Fix initialise relayer logic for persisted mode ([#485](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/485)) ([5398adf](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5398adf054080b0f925607509e8ffa107f288895))
* Fix initialize relayer logic for persisted mode ([5398adf](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5398adf054080b0f925607509e8ffa107f288895))
* Fixes solana allowed_tokens policy validation ([#467](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/467)) ([367a6e9](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/367a6e9b1eaf333ea288147c4349a93246407e16))
* Improve docker cargo caching ([#505](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/505)) ([da288c0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/da288c06e6636f1f3ea43fbc8040a575e1788f49))
* Improve openapi spec for evm transaction response ([#468](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/468)) ([1c0ba6c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1c0ba6c8f2c4b94c9b223e58d8aad834ce512761))
* Openapi spec version and update gh workflow ([#470](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/470)) ([afdc091](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/afdc091d8bafbc3900e8f909f62cfd490a757aac))
* Optimism L1 data fee formula ([#513](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/513)) ([fca1c01](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/fca1c01d321a7c3d61cf88513af187163db5d184))
* place the gh release app token setup after docker build step ([#547](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/547)) ([8fae614](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8fae61415935e505d30edfb507c6dc12c5f2e354))
* plae the gh release app token setup after docker build step ([8fae614](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8fae61415935e505d30edfb507c6dc12c5f2e354))
* Resolve Redis race condition and price calculator overflow ([#483](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/483)) ([3e6a2ca](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3e6a2ca2ff6d712ed173a08acb90066221b1109f))
* stellar tx data persistence ([#500](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/500)) ([d60a019](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d60a01958582aa5ab70b2dc369b1531d493db637))
* Update base image digest ([#556](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/556)) ([fb114fa](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/fb114fa7acefcfeae653cf43f91cbf0272bf002f))

## [1.1.0](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v1.0.0...v1.1.0) (2025-08-11)


### 🚀 Features

* Add Arbitrum support ([#373](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/373)) ([7b5372b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7b5372bf54fe26756ca5db6cb393e0d9d79ae621))
* add evm intrinsic gas_limit validation ([dd1b2d6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/dd1b2d6768d09f051791d0db68c912a38d273715))
* Add Launctube plugin example ([#414](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/414)) ([5bda763](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5bda7635f304923fcd4031f855009228eeefee4b))
* Add status_reason field to transaction responses ([#369](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/369)) ([c489e5d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c489e5d39e3cec555caf92ac93266016c547b2bb))
* Add stellar launchtube plugin ([#401](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/401)) ([801e2f7](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/801e2f7efc8f0cb7eb54f545ce398e6ee24cf6b9))
* Add support to plugin list endpoint ([#358](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/358)) ([6517af0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6517af0a753db41638b006fa2b896a3ccec0d4ef))
* Add wait API for plugin transactions ([#345](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/345)) ([6069af2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6069af256e6cfe8470244731d4bb444b87bd175f))
* Added resolve_plugin_path for script_path ([#340](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/340)) ([0b30739](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0b30739e51f5ef6c0b97c1da585d403496b2bbac))
* Enhance Stellar tx handling with fee updates ([#368](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/368)) ([05617d7](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/05617d7cb06ab378c2c2207f9d0a2e11a04cc472))
* Plat-6303 store solana submitted transactions to db and run status check logic ([#398](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/398)) ([e8420bc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e8420bca02c20a53b02d9bedc8da1b7a784716dc))
* Plat-6677 implement redis repositories for existing collections ([#350](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/350)) ([5fee731](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5fee731c5f19013f41a12a5b93af79d65bdf777e))
* Plat-6679 implement startup logic to populate redis from config file ([#359](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/359)) ([5e1c0c8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5e1c0c825d3c1185a5c59360a2c857d79b46abba))
* Plat-6681 expose crud api endpoints ([#365](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/365)) ([f3c3426](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f3c34266f3f035cd240105833ef4e67711cb0356))
* Plat-6684 add support for transaction entries expiration ([#394](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/394)) ([6f6f765](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6f6f765556b2fc16764f8afe02ceedf268c26c13))
* plat-6817 EVM add support for gas limit calculation ([#355](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/355)) ([dd1b2d6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/dd1b2d6768d09f051791d0db68c912a38d273715))
* plat-6873 add storage documentation ([#395](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/395)) ([ffd4ed5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ffd4ed58d322bad63be500a084a0b082ac7b59d9))
* Plugins improvements ([#410](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/410)) ([648a0f1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/648a0f121a6308e8bde0e09010d2e0c83de5c6ec))
* Support plugin timeouts ([#348](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/348)) ([0a1c51e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0a1c51e9fe540ba570af25146538992a26b9a8a0))
* Types introduced for plugin params and result ([#351](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/351)) ([dda83a2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/dda83a296fd5bd5bfca7f7902f4ca035e1bd8796))
* Update Stellar network config and docs ([#380](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/380)) ([a4e1a0f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a4e1a0f38590f21c6d5e917a02fee4f6bef4f075))


### 🐛 Bug Fixes

* Correct env var value in semgrep.yml ([#375](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/375)) ([2e98e21](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2e98e2149135b97a62b90c302675379642fdf7b3))
* Docker readme file ([#339](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/339)) ([2db9933](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2db9933def061046cc3585a07249107a236ef98c))
* Implement stellar sequence sync and tx reset ([#367](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/367)) ([60b5deb](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/60b5deb4915041d60a064cfac1a066406c339517))
* Inheritance validation ([#374](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/374)) ([f8b921b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f8b921b4d6d85b8068428f1e34de121183a02179))
* Minor fixes in Plugin docs ([#325](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/325)) ([33bb6a1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/33bb6a1841f2e84723e49cc81258a930241dc735))
* Plat-6815 resubmission bug ([#353](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/353)) ([72ac174](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/72ac17471e3a0a6ac35e9a9bb9ff8fe5e8b94bf2))
* plat-6888 aws kms signer issue ([#411](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/411)) ([3c12c88](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3c12c88703c92526fe975eabba6ba0ffa9ca9c79))
* Plugin result + adds tests for plugin ts lib ([#336](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/336)) ([b30246e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b30246e8922d3cb5bd3c5b92a7678f7591db5b97))
* Replace tx request body ([#326](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/326)) ([a20c916](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a20c916b592891b7a2afafd2e62b32723fc05dc2))
* SBOM upload error ([#342](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/342)) ([1f9318e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1f9318e22cbe59ca03bc617b0986379574e5f770))
* Semgrep CI integration ([#371](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/371)) ([6b9a6d2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6b9a6d24e22b78743f16c566026b34f9912669ad))
* Semgrep send metrics value ([#381](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/381)) ([315ccbc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/315ccbca9a48816fc6e0c8133301aa3e3186ff93))
* Solve issues with new solana_sdk version ([#324](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/324)) ([ab97253](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ab972533259506bb21e22ec7f899a45d2fc97db5))
* Switch Redocly build to use standalone html file ([#291](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/291)) ([97a8698](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/97a86980bec6260920a469018fee0d3541d1a063))
* syntax error in codeql.yml ([#385](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/385)) ([987fd33](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/987fd33566b66b2821490d0769a3c863a778c271))
* Update semgrep.yml ([#347](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/347)) ([5ffb803](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5ffb8036ca6d3fb5a8cdb34fa5484e7732c842a1))
* Use unicode character for emoji ([#343](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/343)) ([784e89f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/784e89fae4ad2ddad037ddbbd0bec6df160e9a6a))

## [1.0.0](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v0.2.0...v1.0.0) (2025-06-30)


### 🚀 Features

* Add get_status method for EVM and Stellar ([#229](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/229)) ([e84217e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e84217e0fa941fcd580ad6b84ab6bfac939dd5f4))
* Add node support to environment  ([#236](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/236)) ([3ab46f8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3ab46f848e7e4c6dee2545d62dc646b33623d63d))
* Add plugin invoker service  ([#290](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/290)) ([489ce02](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/489ce0285cd88a18b1616af94bfc970a4a674228))
* Add plugins call endpoint ([#279](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/279)) ([c278589](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c278589f4c6bf88be86788fdd9b68c2f166f5f33))
* Add support for feebumped tx ([#309](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/309)) ([b4efd2e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b4efd2e894fb6534b61a10c5f8872a73d923410c))
* Add support for stellar InvokeHostFunction transactions ([#284](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/284)) ([32ba63e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/32ba63e58e3dfc1359b7a5c9f61f9ff2a8b6c317))
* Add transaction status handling for stellar ([#223](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/223)) ([9496eb6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9496eb63514afb0bd29c731bebe86ffdcf393362))
* Create initial js plugins library  ([#302](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/302)) ([98238e9](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/98238e9a6a30de8dba3bf8d308a82658e29de46f))
* **evm:** Add AWS KMS signer support ([#287](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/287)) ([723a9a8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/723a9a8d7e625dd3f52b2d678d0e1cd842053e06))
* **evm:** Implement delete pending txs ([#289](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/289)) ([bc6f829](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/bc6f829e580d42359adebceeddaf38002390e10b))
* **evm:** Implement json rpc endpoint ([#286](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/286)) ([91528aa](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/91528aab82e3fa3cba08f63feb4ac9879aa8940e))
* extract networks to json files ([#238](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/238)) ([5ac07b3](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/5ac07b3c570485d7cdbc419a23f373867d7ebe81))
* handle non-retriable errors and provider health errors ([#233](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/233)) ([7add348](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7add348da4d06af5ebebcce78d856485e9894ac3))
* Implement get_balance method for StellarRelayer ([#228](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/228)) ([d92c75f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d92c75fe7da1b02ddb7a38df32f98082474e4cd9))
* implement network config deserializing ([#235](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/235)) ([6d537f9](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6d537f9298626fefc0d5a45c311a95208e1c8ef5))
* Pass arbitrary payloads to script execution ([#312](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/312)) ([adecaf5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/adecaf5d73c3df9083c6a3fcf62ed669bc90b25c))
* plat-6215 add support for rpc failovers and retries ([#231](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/231)) ([ca6d24f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ca6d24f1bcdbb912795dcb1496519b49b5e81bf1))
* plat-6522 allow for the use of on chain defi to automatically swap spl ([#198](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/198)) ([dc9e2e2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/dc9e2e2dd1d46830bc6479c1928a2e7ef7f91fb3))
* plat-6571 add support for gcp signer ([#221](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/221)) ([0170fa1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0170fa12c3ecc64d1c48ed3a726358ed74d4596b))
* Relayer plugins - add support to plugins in configs  ([#253](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/253)) ([6a14239](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6a14239486900b2ef121b5de9e87410c412b65fe))
* **replace_tx:** Implement replace tx for evm ([#272](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/272)) ([b48e71f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b48e71f55fda03bea83e90255b0d180db704cb52))
* Set default network folder ([#313](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/313)) ([b28c99c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b28c99c43bedd921a55660622d845e63890e0d74))
* **signer:** Add GCP Signer to EVM ([#305](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/305)) ([a8817b6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a8817b6c87c65731232d0a141338f3996aef2510))
* Stellar RPC config ([#213](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/213)) ([6fd75ea](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6fd75ea65bf1a945ba891f99d83b0cdacdf30014))
* support for retries and failovers in EVM Provider ([#197](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/197)) ([542f21a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/542f21a9346def9b7fe47e0a29a2bbd5ab2af349))


### 🐛 Bug Fixes

* Add memo validation for InvokeHostFunction ([#294](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/294)) ([6bb4ffa](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6bb4ffaf9ceb4a8daef29ec5878595cca7041300))
* change the ampersand to and, as as the shell interpret it ([#206](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/206)) ([d164d6a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d164d6a4d63fbf0acdfe1330cf25147e86280af8))
* Changing base image to wolfi, added node and npm ([#266](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/266)) ([1181996](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1181996dac6da52f96e164b1c937828a3940d5b8))
* Config example file ([#285](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/285)) ([a020c6f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a020c6fcd6f9b638d955d5f2c99aa0e199d8bf6e))
* docker-scan - chainguard issue ([#255](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/255)) ([c9ab94b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c9ab94bcee7b386a33b063504b3e6d2cf188d8b5))
* Make plugins entry in configs optional ([#300](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/300)) ([f299779](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f299779318429677fd672d4a2433828971a1b62e))
* Relayer plugins format output ([#307](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/307)) ([8f25e5f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8f25e5f55812e3d346c8bc0ff063cf07e2f0b753))
* remove the ci job dependant from the test job ([#222](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/222)) ([4056610](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/40566108b66c701323145c2889ce0141b84714b8))
* Replace automatic minor version bumps ([#315](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/315)) ([85784b4](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/85784b486a9508429ae94373a7f3db13d78b39d6))
* Update configs and dockerfiles in examples ([#298](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/298)) ([2e505ad](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2e505ad827ab7544f7c6a3fdf4018b1e9428f1d6))
* Update Stellar API docs to match implementation ([#292](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/292)) ([96d95e3](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/96d95e35784c25f39afe626b56f11477fd213196))

## [0.2.0](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v0.1.1...v0.2.0) (2025-05-14)


### 🚀 Features

* add optimism extra cost calculation ([#146](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/146)) ([b85e070](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b85e070074ecc0aa4fbd7d5dc3af6ca0d600220b))
* add timeout_seconds to EVM relayer configuration ([#169](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/169)) ([6fd59bc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6fd59bc0e5993d63608d47e7ba7825a027e26b99))
* implement balance validation in EVM ([#168](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/168)) ([27fe333](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/27fe333806c28c268af981f5377e188160c845b9))
* Local signing for stellar ([#178](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/178)) ([f69270a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f69270ade4c9a9239bba874ac74858c8e7375298))
* plat-6471 add Solana Token 2022 extensions support ([#166](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/166)) ([d35c506](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d35c506ea298a86897ede5702481403f839f2451))
* Plat-6521 add turnkey hosted signer support (evm, solana) ([#174](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/174)) ([b24688e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b24688ead4fe3015ca3b7c74e56f1906085a5aa3))
* Stellar RPC service ([#183](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/183)) ([9943ffd](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9943ffd67a709df487264f50eccd03b06cc817d4))
* Stellar transaction submission ([#199](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/199)) ([c6b72bf](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c6b72bfba82c7fb9288c07e49bef04cf527d1245))
* support for multiple custom RPCs with weighted configuration ([#182](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/182)) ([92ea5ad](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/92ea5ad324323b957fcbdce85c37517ec6f963ba))


### 🐛 Bug Fixes

* CLA assistant ([#171](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/171)) ([b326a56](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b326a5680722e812263aab949003c214795fd2c0))
* CLA labels ([#173](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/173)) ([e31405b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e31405b8cba9ffd2ff991d56444320ff3d069ad0))
* Docker Compose ([#156](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/156)) ([6ca012f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6ca012fb9b50d5c2159c498679673cb27530fc3c))
* Missing libssl and workflow ([#155](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/155)) ([9de7133](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9de7133c2ba1768f4d989158f19c27444e522f9e))
* Release merge conflicts ([#163](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/163)) ([4cac422](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4cac4221817373a1ae7eff92db187dbae2f1665b))
* Skip releases ([ccafcbe](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ccafcbe11bc6ea46dacb9c59be578abd45112ad3))

## [0.1.1](https://github.com/OpenZeppelin/openzeppelin-relayer/compare/v0.1.0...v0.1.1) (2025-04-08)


### 🐛 Bug Fixes

* Skip releases ([e79b2e9](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e79b2e963439721dd8e151fa0827654e4019df5f))
* Skip releases with release please ([#158](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/158)) ([e79b2e9](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e79b2e963439721dd8e151fa0827654e4019df5f))


### ⚙️ Miscellaneous Chores

* Fix workflow and missing libs in docker file ([#157](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/157)) ([c7a681d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c7a681dea154b06b675a286e936606e2f9ce087b))
* plat-7575 Docs fixes ([#153](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/153)) ([#154](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/154)) ([44257e8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/44257e8ea3e658adbf40f69ad809e4e3503e9af4))

## 0.1.0 (2025-04-07)


### 🚀 Features

* add base models ([#5](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/5)) ([55db42b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/55db42b16d88e95ca8f6927e3b4d07c939e677c8))
* Add CLA assistant bot ([#130](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/130)) ([4ad5733](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4ad5733daadefe5e52bd617eaa47039677443745))
* add directory structure and example ([d946c10](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d946c10fd96ee2d1ce2e373ba4ccfced31f985f9))
* Add logging improvements ([#28](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/28)) ([bb6751a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/bb6751a4f868eb82787e7763a7995d3974ecfd49))
* Add logic to resubmit transaction ([#102](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/102)) ([6c258b6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6c258b625dc7edb1d028b771647ff25b12c2b07d))
* Add noop support and refactor status ([#134](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/134)) ([f0e3a17](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f0e3a177a536c53fe8eff834243d417bb673b744))
* Add queue processing support ([#6](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/6)) ([3ebbac2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3ebbac25f1ecb403dec7d090d39882a85227d883))
* Add release workflow ([#148](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/148)) ([bd9a7e9](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/bd9a7e91a300e6650b08f799aecea4478bb4b974))
* Add sign tx for evm local signer ([#65](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/65)) ([b17fb36](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b17fb3625677f1dbcf1ddf3963db13b9b88ca25e))
* add support for relayer paused and system disabled state ([#13](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/13)) ([44968a2](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/44968a29ec4f1cf1166c2ad726f2c9a1bac246c3))
* Add worldchain testnet support ([#137](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/137)) ([25751ef](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/25751ef97b7b9fbe0c4b53fab5b762d1696f8c93))
* Adding job tests ([#110](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/110)) ([4d2dd98](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4d2dd98efedacaded8d4ace118c43dbe25907278))
* enabling it to listen on all interfaces - allows for easy docker config ([74a59da](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/74a59da79b314160baf35ec9750e372fbad0f360))
* enabling it to listen on all interfaces - allows for easy docker config ([23f94c0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/23f94c07ce46254f7b80df77ce8c4fc59fb4eef6))
* improve examples ([#119](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/119)) ([7e59aa6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7e59aa64f75f3470807396b293e71cd68d3292d1))
* Improve Redis startup logic ([#120](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/120)) ([8618ecf](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8618ecf00b4739891fe4ce98caf14f729face896))
* initial repo setup ([d8815b6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/d8815b6752931003536aa427370ca8fb1c57231c))
* Integrate Netlify with antora ([#74](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/74)) ([09e3d48](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/09e3d4894b54c58754b373da239e9d564df69aa9))
* Plat 5744 implement an api key authentication mechanism ([#11](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/11)) ([8891887](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/88918872d51ab10632ec6d590689d52e59dfd640))
* Plat 5768 setup metrics endpoint ([#50](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/50)) ([7c292a5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7c292a572a7aef8213969fc72cadca74f9016fe8))
* Plat 6434 improve authorization header validation ([#122](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/122)) ([eed7c31](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/eed7c31e938c7b6ecaa82774ca5d3a508bb89281))
* Plat-5749 implement basic webhook notifications service ([#12](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/12)) ([1b47b64](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1b47b64c318208eb7dc2ec6d62020fab30ccafbb))
* Plat-5802 openapi sdk client ([#109](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/109)) ([1b4b681](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1b4b681a3755f60e2934548a9666c60a4465dabb))
* PLAT-6026 Imp cancel transaction ([#101](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/101)) ([1e5cc47](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1e5cc47bdc54acafeeefb60489db410b42722b0f))
* Plat-6118 implement logic for syncing relayer state upon service start ([#19](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/19)) ([2ba3629](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2ba36292a0b8d0d67ddab42d2845a6a0d5f31e3a))
* Plat-6153 add network definitions for Solana networks ([#26](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/26)) ([ff453d5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ff453d59724eeaa194ccf7f83993ce8d649f7432))
* Plat-6154 add support for solana local signer ([#29](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/29)) ([40caead](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/40caeadde5f08200410912b98943346971084163))
* plat-6158 implement Solana rpc service ([#36](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/36)) ([8fb50a8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8fb50a833e7f9b1773dbe4ca1d77a9609a5d5ec1))
* Plat-6159 extend relayer config file solana policies ([#38](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/38)) ([4f4602b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4f4602b754e71539937447c1743a7f069317598b))
* Plat-6164 implement feeestimate rpc method ([#61](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/61)) ([43b016c](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/43b016c4e5faa5ee1fedcdadccf3bc768962178e))
* Plat-6165 implement transfertransaction rpc method ([#63](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/63)) ([c59a3b8](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c59a3b8894c32470adf10770f4804e272aa829d3))
* Plat-6167 implement signtransaction rpc method ([#57](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/57)) ([ad7a1ff](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ad7a1ffe41eb868f54737c1f1b44a52c6d02d172))
* Plat-6169 implement getsupportedtokens rpc method ([#45](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/45)) ([3f91199](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3f9119981acd7f92618ba6ec12c3039563368202))
* Plat-6170 add vault hosted signer support ([#99](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/99)) ([7a9491d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7a9491d4094fc21bc87551c68687b4f44f3edd18))
* Plat-6207 implement trait abstraction relayer ([#43](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/43)) ([abeb7cf](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/abeb7cfccc9e70b26ddd0d41d736352d57d6ade9))
* Plat-6216 adding network symbol support ([#37](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/37)) ([21f798f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/21f798fc114de47ae0ed7e127e496bb50ca081a8))
* Plat-6236 adding validation payload ([#42](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/42)) ([a5ff165](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a5ff165df14f48d47adee03e8e2c8ef5a899ff57))
* Plat-6239 whitelist policy validation ([#44](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/44)) ([3adb45e](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3adb45e17b8b23c70e09e422cfca051ebab266f1))
* Plat-6248 implementation dummy of legacy price ([#49](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/49)) ([6319d64](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6319d64bf27fd75f5192165df885156ca91ea9f0))
* Plat-6267 add utility script for generating local keystore files ([#69](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/69)) ([b5df7f6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/b5df7f6b0450118c9123de46689fa115efcdec94))
* Plat-6291 add webhook notifications for rpc methods ([#72](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/72)) ([2f35d81](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2f35d81b3711cf2f87dbc6df31b9e0f90432164e))
* Plat-6299 clean transaction response ([#76](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/76)) ([fc5dd05](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/fc5dd05154bca4a1d740cef058bb797cd3f513a0))
* Plat-6300 returning the balance of the relayer ([#78](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/78)) ([e0ce8e0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/e0ce8e04f3950c094c9af3e3413d61cd7162c8e7))
* Plat-6304 use Authorization header instead of x api key ([#94](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/94)) ([34e8a81](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/34e8a813234ee6aaf2a6956f6dd45f82e47e7861))
* Plat-6309 Fetching eip1559 prices ([#83](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/83)) ([68d574f](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/68d574fcb159ae3b6502167a9bcf34bb1a56ea7e))
* plat-6340 store private keys securely in memory ([#104](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/104)) ([28c2fab](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/28c2fab84f3db6b9d971126cf917263da395c421))
* PLAT-6350 - Sign EIP-1559 ([#98](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/98)) ([673e420](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/673e4202f9d98bfd02512090fa3daacfa40831fe))
* PLAT-6374 EIP-1559 default if network support it and not explicit false ([#100](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/100)) ([c982dde](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c982ddefeba93381ac7d2c5e09f616a60820b8b8))
* PLAT-6416 Use generics transaction factory ([#105](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/105)) ([7b94662](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/7b946625af77c6aabd336d34646e9ae62ece3b6a))
* plat-6433 add minimum length validations for config sensitive values ([#125](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/125)) ([31453c5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/31453c5586ca4fef70e7ea0e2dcd0260a8a721a6))
* Plat-6441 document upcoming work  ([#131](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/131)) ([377a8bb](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/377a8bb57ff5b3b23abb58d1c3378489c40218cf))
* PLAT-6442 - Abstraction and unit tests relayer domain ([#117](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/117)) ([643194a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/643194acd9079ac3ac157e909f0b30199af8b0c9))
* Plat-6457 Ignore utoipa ([#127](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/127)) ([234854a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/234854afbf30a9a94fa3365f60f035e53e068938))
* Plat-6459 create mermaid architecture diagram ([#126](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/126)) ([3de147b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3de147b907c28d3e9a8a38a2d6b8cd665253c423))
* plat-6476 Add support to collect transaction fee ([#135](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/135)) ([4f4a07b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4f4a07b2846d2980bbf09734602315702ded9dbe))
* Plat-6479 added support for rpc custom endpoints ([#138](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/138)) ([3df3d49](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/3df3d49ec6a662698a90630811d717920b7cdf3b))
* Pricing validation on receiving payload EVM ([#59](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/59)) ([1206d42](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1206d4241dbda84bc861f501d322f6bd33234f0b))
* Signer service ([#8](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/8)) ([4f85b7b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4f85b7bf5b6aa83903ed8febdfe244d54e803642))
* Speed support transaction ([#62](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/62)) ([a572af6](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/a572af65ca4f664dce13e705eac37b56dee306fa))
* Tx submissions and status mgmt ([#81](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/81)) ([9f829f1](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9f829f1c59c4221c9cf38c6cb1ff36351a348cd1))
* Update transaction status to mined/expired ([#85](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/85)) ([8f5ee53](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8f5ee53bbe64d55ccf8015a1c8d203cf5e391f08))


### 🐛 Bug Fixes

* Codecov changes and adjustments ([#113](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/113)) ([6e62dcf](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/6e62dcf212a917421c7559566136c018e17c38f5))
* Docs link ([#128](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/128)) ([8263828](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/82638284cf13a4da376624362f5353b57365302a))
* Docs path for crate ([#129](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/129)) ([51cf556](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/51cf556411c9c1f79dbee7f4c3aa25df7fe2af49))
* **docs:** replaced Monitor for Relayer ([2ff196b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/2ff196bf772668556210a895d4f83315e579577f))
* Documentation name for antora ([#121](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/121)) ([63c36f5](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/63c36f5393b1369a169c8617b20952bca30aef0c))
* Environment variables ([#124](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/124)) ([8d31131](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/8d31131c087a6d0a64ae2dadecb5ae395ad1b575))
* Fix the codecov yaml syntax ([#108](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/108)) ([ab9ab5b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/ab9ab5b0c9313d083cd47c71d7faade867c58deb))
* Flaky logging tests ([#89](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/89)) ([bc909cc](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/bc909cc336613bb5a191c562632278bd3c270b09))
* Plat 6286 write tests for metrics and middleware functions ([#70](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/70)) ([18124fb](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/18124fbbfbc26f300648a7a4050ebf9be72465ac))
* PLAT-6426 Increase test coverage ([#118](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/118)) ([1fa41f0](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/1fa41f0f225c9d515690738e960073396dce66ce))
* PLAT-6478 create unit test for use of on relayers dotenv ([#139](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/139)) ([509e166](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/509e1664518823ef3844e52e818707f3371ddbff))
* plat-6480 allow transferring wrapped sol tokens ([#132](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/132)) ([f04e66a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/f04e66a568c877c2a4c5c5378fb6017c2e41d2c6))


### 📚 Documentation

* add cargo docs ([#75](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/75)) ([c4dd8e3](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c4dd8e30525ccaeb563560bc2ef87cdcec5b1790))
* Add testing instructions ([#107](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/107)) ([c7c2ed7](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/c7c2ed7772d99b4b68ced9fbf8835fa9e46da5e1))
* Adding configuration documentation ([#48](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/48)) ([929cc1b](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/929cc1bf1e0c6b3be872daf6654abe24eb79b907))
* Fixing formatting and location of files ([#41](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/41)) ([4d4f153](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/4d4f1530f466a5bd597d0338559ccb33815286f0))
* Move README to a similar format to Monitor ([#39](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/39)) ([5985339](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/59853396b3786a972ce7bbc793d4dbacc62fe6c0))
* Readability improvements ([#133](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/133)) ([9220727](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/9220727cc2b4349052c2d96a48c5d9c3012b38b9))
* Small doc updates - policy field descriptions ([#51](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/51)) ([cc83c49](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/cc83c496bbe2593018b03c414a864691c967ff41))
* Small fixes and Antora docs improvements ([#40](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/40)) ([655d16d](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/655d16dc658a74b7413ce785dee5b8e33cfb40f7))
* TG link and other minor doc updates ([#116](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/116)) ([fc68b6a](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/fc68b6afa844d2c2638d031fce44fcc514d59a7d))
* Update API docs. Fix Dockerfiles ([#77](https://github.com/OpenZeppelin/openzeppelin-relayer/issues/77)) ([0bd6bfe](https://github.com/OpenZeppelin/openzeppelin-relayer/commit/0bd6bfea69d60c1a7e9d6b8a690ba1a2d0e44b74))
