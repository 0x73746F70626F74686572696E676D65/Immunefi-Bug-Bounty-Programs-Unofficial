#!/usr/bin/env node

/**
 * Legacy Plugin Executor (ts-node mode)
 *
 * **⚠️ Legacy/Fallback Implementation**
 * This executor is used only when pool-based execution is disabled (`PLUGIN_USE_POOL=false`).
 * The default execution mode uses the pool executor (`pool-executor.ts`), which is faster
 * and more efficient. This ts-node executor spawns a new process per request, which is
 * slower but simpler.
 *
 * **Default Execution Path**: Pool executor (`pool-executor.ts`) via `pool-server.ts` →
 * `worker-pool.ts` → `pool-executor.ts` (Piscina workers)
 *
 * **Legacy Execution Path**: This executor (`executor.ts`) via `script_executor.rs` →
 * ts-node → `executor.ts` (one-shot process per request)
 *
 * Called from: `src/services/plugins/script_executor.rs` (only when `PLUGIN_USE_POOL=false`)
 * The Rust code invokes this script via ts-node and passes parameters as command line arguments.
 *
 * This script:
 * 1. Receives plugin execution parameters from Rust via process.argv
 * 2. Loads the user's plugin script dynamically
 * 3. Calls the plugin's exported 'handler' function
 * 4. Returns results back to the Rust environment
 *
 * Usage: ts-node executor.ts <socket_path> <plugin_id> <params_json> <user_script_path>
 *
 * Arguments:
 * - socket_path: Unix socket path for communication with relayer
 * - plugin_id: Plugin ID for namespacing KV storage
 * - params_json: JSON string containing plugin parameters
 * - user_script_path: Path to the user's plugin file to execute
 */

import { runUserPlugin, serializeResult } from './plugin';

import { LogInterceptor } from './logger';

/**
 * Extract and validate CLI arguments passed from Rust script_executor.rs
 * Now includes pluginId as a separate argument
 */
function extractCliArguments() {
  // Get arguments: [node, executor.ts, socketPath, pluginId, paramsJson, userScriptPath, httpRequestId, headersJson, route, configJson, method, queryJson]
  const socketPath = process.argv[2];
  const pluginId = process.argv[3]; // NEW: Plugin ID as separate arg
  const paramsJson = process.argv[4]; // Shifted from argv[3]
  const userScriptPath = process.argv[5]; // Shifted from argv[4]
  const httpRequestId = process.argv[6]; // original HTTP request id
  const headersJson = process.argv[7]; // HTTP headers as JSON (optional)
  const route = process.argv[8]; // Wildcard route (optional)
  const configJson = process.argv[9]; // Plugin config as JSON (optional)
  const method = process.argv[10]; // HTTP method (optional)
  const queryJson = process.argv[11]; // Query parameters as JSON (optional)

  // Validate required arguments
  if (!socketPath) {
    throw new Error('Socket path is required (argument 1)');
  }

  if (!pluginId) {
    throw new Error('Plugin ID is required (argument 2)');
  }

  if (!paramsJson) {
    throw new Error('Plugin parameters JSON is required (argument 3)');
  }

  if (!userScriptPath) {
    throw new Error('User script path is required (argument 4)');
  }

  return { socketPath, pluginId, paramsJson, userScriptPath, httpRequestId, headersJson, route, configJson, method, queryJson };
}

/**
 * Parse and validate plugin parameters
 */
function parsePluginParameters<T = any>(paramsJson: string): T {
  try {
    return JSON.parse(paramsJson) as T;
  } catch (error) {
    throw new Error(`Failed to parse plugin parameters JSON: ${error instanceof Error ? error.message : error}`);
  }
}

/**
 * Parse HTTP headers from JSON string
 */
function parseHeaders(headersJson: string | undefined): Record<string, string[]> | undefined {
  if (!headersJson) {
    return undefined;
  }
  try {
    return JSON.parse(headersJson) as Record<string, string[]>;
  } catch {
    // If parsing fails, return undefined (headers won't be available)
    return undefined;
  }
}

/**
 * Parse plugin config from JSON string
 * Config must be a JSON object (not array, string, or primitive)
 */
function parseConfig(configJson: string | undefined): Record<string, any> | undefined {
  if (!configJson) {
    return undefined;
  }
  try {
    const parsed = JSON.parse(configJson);
    // Ensure config is an object (not array or primitive)
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, any>;
    }
    return undefined;
  } catch {
    // If parsing fails, return undefined (config won't be available)
    return undefined;
  }
}

/**
 * Parse query parameters from JSON string
 */
function parseQuery(queryJson: string | undefined): Record<string, string[]> | undefined {
  if (!queryJson) {
    return undefined;
  }
  try {
    return JSON.parse(queryJson) as Record<string, string[]>;
  } catch {
    // If parsing fails, return undefined (query won't be available)
    return undefined;
  }
}

/**
 * Main executor logic
 */
async function main(): Promise<void> {
  const logInterceptor = new LogInterceptor();

  try {
    // Start intercepting all console output at the executor level
    // This provides better backward compatibility with existing scripts
    logInterceptor.start();

    // Extract and validate CLI arguments including plugin ID
    const { socketPath, pluginId, paramsJson, userScriptPath, httpRequestId, headersJson, route, configJson, method, queryJson } = extractCliArguments();

    // Parse plugin parameters
    const pluginParams = parsePluginParameters(paramsJson);

    // Parse HTTP headers (optional)
    const headers = parseHeaders(headersJson);

    // Parse plugin config (optional)
    const config = parseConfig(configJson);

    // Parse query parameters (optional)
    const query = parseQuery(queryJson);

    // Pass plugin ID as separate argument
    const result = await runUserPlugin(socketPath, pluginId, pluginParams, userScriptPath, httpRequestId, headers, route, config, method, query);

    // Add the result to LogInterceptor output
    logInterceptor.addResult(serializeResult(result));
  } catch (error) {
    process.stderr.write(`Plugin executor failed: ${error instanceof Error ? error.message : error}\n`);
    process.exit(1);
  } finally {
    logInterceptor.stop();
    process.exit(0);
  }
}

// Entry point for executor
main();
