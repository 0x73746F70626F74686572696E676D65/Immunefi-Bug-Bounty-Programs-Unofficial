require("some-plugin");
