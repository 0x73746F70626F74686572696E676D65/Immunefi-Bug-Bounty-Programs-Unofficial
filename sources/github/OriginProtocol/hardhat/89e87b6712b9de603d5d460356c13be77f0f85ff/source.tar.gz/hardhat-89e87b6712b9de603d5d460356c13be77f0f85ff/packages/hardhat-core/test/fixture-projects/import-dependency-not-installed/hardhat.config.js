require("some-dependency");
