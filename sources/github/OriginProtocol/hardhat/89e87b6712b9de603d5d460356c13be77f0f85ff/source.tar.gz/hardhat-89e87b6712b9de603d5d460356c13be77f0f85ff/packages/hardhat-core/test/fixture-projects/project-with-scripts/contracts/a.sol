contract A {}

