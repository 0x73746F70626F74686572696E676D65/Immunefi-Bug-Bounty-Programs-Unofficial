declare module "@fvictorio/tabtab";
