declare module "solpp";
