// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.0;

import { InitializeGovernedUpgradeabilityProxy } from "./InitializeGovernedUpgradeabilityProxy.sol";
import { InitializeGovernedUpgradeabilityProxy2 } from "./InitializeGovernedUpgradeabilityProxy2.sol";

/**
 * @notice OUSDProxy delegates calls to an OUSD implementation
 */
contract OUSDProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice WrappedOUSDProxy delegates calls to a WrappedOUSD implementation
 */
contract WrappedOUSDProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice VaultProxy delegates calls to a Vault implementation
 */
contract VaultProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice HarvesterProxy delegates calls to a Harvester implementation
 */
contract HarvesterProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice DripperProxy delegates calls to a Dripper implementation
 */
contract DripperProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice OETHProxy delegates calls to nowhere for now
 */
contract OETHProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice WOETHProxy delegates calls to nowhere for now
 */
contract WOETHProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice OETHVaultProxy delegates calls to a Vault implementation
 */
contract OETHVaultProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice OETHMorphoAaveStrategyProxy delegates calls to a MorphoAaveStrategy implementation
 */
contract OETHMorphoAaveStrategyProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice OETHBalancerMetaPoolrEthStrategyProxy delegates calls to a BalancerMetaPoolStrategy implementation
 */
contract OETHBalancerMetaPoolrEthStrategyProxy is
    InitializeGovernedUpgradeabilityProxy
{

}

/**
 * @notice OETHBalancerMetaPoolwstEthStrategyProxy delegates calls to a BalancerMetaPoolStrategy implementation
 */
contract OETHBalancerMetaPoolwstEthStrategyProxy is
    InitializeGovernedUpgradeabilityProxy
{

}

/**
 * @notice MakerDsrStrategyProxy delegates calls to a Generalized4626Strategy implementation
 */
contract MakerDsrStrategyProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice BridgedWOETHProxy delegates calls to BridgedWOETH implementation
 */
contract BridgedWOETHProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice MetaMorphoStrategyProxy delegates calls to a Generalized4626Strategy implementation
 */
contract MetaMorphoStrategyProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice MorphoGauntletPrimeUSDCStrategyProxy delegates calls to a Generalized4626Strategy implementation
 */
contract MorphoGauntletPrimeUSDCStrategyProxy is
    InitializeGovernedUpgradeabilityProxy
{

}

/**
 * @notice CurvePoolBoosterProxy delegates calls to a CurvePoolBooster implementation
 */
contract CurvePoolBoosterProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice PoolBoostCentralRegistryProxy delegates calls to the PoolBoostCentralRegistry implementation
 */
contract PoolBoostCentralRegistryProxy is
    InitializeGovernedUpgradeabilityProxy
{

}

/**
 * @notice OUSDCurveAMOProxy delegates calls to a CurveAMOStrategy implementation
 */
contract OUSDCurveAMOProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice OETHCurveAMOProxy delegates calls to a CurveAMOStrategy implementation
 */
contract OETHCurveAMOProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice CompoundingStakingStrategyProxy delegates calls to a CompoundingStakingStrategy implementation
 */
contract CompoundingStakingStrategyProxy is
    InitializeGovernedUpgradeabilityProxy
{

}

/**
 * @notice OUSDMorphoV2StrategyProxy delegates calls to a Generalized4626Strategy implementation
 */
contract OUSDMorphoV2StrategyProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice Legacy Supernova AMO proxy
 */
contract OETHSupernovaAMOProxy is InitializeGovernedUpgradeabilityProxy {

}

/**
 * @notice OETHVaultLensProxy delegates calls to an OETHVaultLens implementation
 */
contract OETHVaultLensProxy is InitializeGovernedUpgradeabilityProxy {

}
