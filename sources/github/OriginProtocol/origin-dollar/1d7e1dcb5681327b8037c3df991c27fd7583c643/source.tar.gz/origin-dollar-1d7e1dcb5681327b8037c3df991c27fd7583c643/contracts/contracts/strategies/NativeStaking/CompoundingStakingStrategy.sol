// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.0;

import { SafeERC20 } from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import { SafeCast } from "@openzeppelin/contracts/utils/math/SafeCast.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";
import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import { Pausable } from "@openzeppelin/contracts/security/Pausable.sol";
import { Governable } from "../../governance/Governable.sol";
import { IDepositContract } from "../../interfaces/IDepositContract.sol";
import { IWETH9 } from "../../interfaces/IWETH9.sol";
import { BeaconRoots } from "../../beacon/BeaconRoots.sol";
import { PartialWithdrawal } from "../../beacon/PartialWithdrawal.sol";
import { IBeaconProofs } from "../../interfaces/IBeaconProofs.sol";
import { InitializableAbstractStrategy } from "../../utils/InitializableAbstractStrategy.sol";

/**
 * @title Compounding validator strategy
 * @notice This contract implements all the required functionality to
 * deposit, withdraw and account for vanilla compounding validators.
 * @author Origin Protocol Inc
 */
abstract contract CompoundingValidatorStorage is Governable, Pausable {
    /// @dev Validator balances over this amount will eventually become active on the beacon chain.
    /// Due to hysteresis, if the effective balance is 31 ETH, the actual balance
    /// must rise to 32.25 ETH to trigger an effective balance update to 32 ETH.
    /// https://eth2book.info/capella/part2/incentives/balances/#hysteresis
    uint256 internal constant MIN_ACTIVATION_BALANCE_GWEI = 32.25 ether / 1e9;
    /// @dev The maximum number of deposits that are waiting to be verified as processed on the beacon chain.
    uint256 internal constant MAX_DEPOSITS = 32;
    /// @dev The maximum number of validators that can be verified.
    uint256 internal constant MAX_VERIFIED_VALIDATORS = 48;
    /// @dev The maximum amount of ETH that can be used for the initial deposit to a new validator.
    uint256 internal constant MAX_INITIAL_DEPOSIT_AMOUNT_WEI = 2048 ether;
    /// @dev The default withdrawable epoch value on the Beacon chain.
    /// A value in the far future means the validator is not exiting.
    uint64 internal constant FAR_FUTURE_EPOCH = type(uint64).max;
    /// @dev The number of seconds between each beacon chain slot.
    uint64 internal constant SLOT_DURATION = 12;
    /// @dev The number of slots in each beacon chain epoch.
    uint64 internal constant SLOTS_PER_EPOCH = 32;
    /// @dev Minimum time in seconds to allow snapped balances to be verified.
    /// Set to 35 slots which is 3 slots more than 1 epoch (32 slots). Deposits get processed
    /// once per epoch. This larger than 1 epoch delay should achieve that `snapBalances` sometimes
    /// get called in the middle (or towards the end) of the epoch. Giving the off-chain script
    /// sufficient time after the end of the epoch to prepare the proofs and call `verifyBalances`.
    /// This is considering a malicious actor would keep calling `snapBalances` as frequent as possible
    /// to disturb our operations.
    uint64 public constant SNAP_BALANCES_DELAY = 35 * SLOT_DURATION;

    /// @notice The address of the Wrapped ETH (WETH) token contract
    address internal immutable WETH;
    /// @notice The address of the beacon chain deposit contract
    address internal immutable BEACON_CHAIN_DEPOSIT_CONTRACT;
    /// @notice Address of the OETH Vault proxy contract
    address internal immutable VAULT_ADDRESS;
    /// @notice Address of the Beacon Proofs contract that verifies beacon chain data
    address public immutable BEACON_PROOFS;
    /// @notice The timestamp of the Beacon chain genesis.
    /// @dev this is different on Testnets like Hoodi so is set at deployment time.
    uint64 internal immutable BEACON_GENESIS_TIMESTAMP;

    /// @notice Address of the registrator - allowed to register, withdraw, exit and remove validators
    address public validatorRegistrator;

    /// @notice Deposit data for new compounding validators.
    /// @dev A `VERIFIED` deposit can mean 3 separate things:
    ///      - a deposit has been processed by the beacon chain and shall be included in the
    ///        balance of the next verifyBalances call
    ///      - a deposit has been done to a slashed validator and has probably been recovered
    ///        back to this strategy. Probably because we can not know for certain. This contract
    ///        only detects when the validator has passed its withdrawal epoch. It is close to impossible
    ///        to prove with Merkle Proofs that the postponed deposit this contract is responsible for
    ///        creating is not present anymore in BeaconChain.state.pending_deposits. This in effect
    ///        means that there might be a period where this contract thinks the deposit has been already
    ///        returned as ETH balance before it happens. This will result in some days (or weeks)
    ///        -> depending on the size of deposit queue of showing a deficit when calling `checkBalance`.
    ///        As this only offsets the yield and doesn't cause a critical double-counting we are not addressing
    ///        this issue.
    ///      - A deposit has been done to the validator, but our deposit has been front run by a malicious
    ///        actor. Funds in the deposit this contract makes are not recoverable.
    enum DepositStatus {
        UNKNOWN, // default value
        PENDING, // deposit is pending and waiting to be  verified
        VERIFIED // deposit has been verified
    }

    /// @param pubKeyHash Hash of validator's public key using the Beacon Chain's format
    /// @param amountGwei Amount of ETH in gwei that has been deposited to the beacon chain deposit contract
    /// @param slot The beacon chain slot number when the deposit has been made
    /// @param depositIndex The index of the deposit in the list of active deposits
    /// @param status The status of the deposit, either UNKNOWN, PENDING or VERIFIED
    struct DepositData {
        bytes32 pubKeyHash;
        uint64 amountGwei;
        uint64 slot;
        uint32 depositIndex;
        DepositStatus status;
    }
    /// @notice Restricts to only one deposit to an unverified validator at a time.
    /// This is to limit front-running attacks of deposits to the beacon chain contract.
    ///
    /// @dev The value is set to true when a deposit to a new validator has been done that has
    /// not yet be verified.
    bool public firstDeposit;
    /// @notice Mapping of the pending deposit roots to the deposit data
    mapping(bytes32 => DepositData) public deposits;
    /// @notice List of strategy deposit IDs to a validator.
    /// The ID is the merkle root of the pending deposit data which is unique for each validator, amount and block.
    /// Duplicate pending deposit roots are prevented so can be used as an identifier to each strategy deposit.
    /// The list can be for deposits waiting to be verified as processed on the beacon chain,
    /// or deposits that have been verified to an exiting validator and is now waiting for the
    /// validator's balance to be swept.
    /// The list may not be ordered by time of deposit.
    /// Removed deposits will move the last deposit to the removed index.
    bytes32[] public depositList;

    enum ValidatorState {
        NON_REGISTERED, // validator has not staked its first deposit
        REGISTERED, // validator has been registered by an extension contract
        STAKED, // validator has funds staked
        VERIFIED, // validator has been verified to exist on the beacon chain
        ACTIVE, // The validator balance is at least 32.25 ETH. The validator may not yet be active on the beacon chain.
        EXITING, // The validator has been requested to exit
        EXITED, // The validator has been verified to have a zero balance
        REMOVED, // validator has been removed by an extension contract
        INVALID // The validator has been front-run and the withdrawal address is not this strategy
    }

    // Validator data
    struct ValidatorData {
        ValidatorState state; // The state of the validator known to this contract
        uint40 index; // The index of the validator on the beacon chain
    }
    /// @notice List of validator public key hashes that have been verified to exist on the beacon chain.
    /// These have had a deposit processed and the validator's balance increased.
    /// Validators will be removed from this list when its verified they have a zero balance.
    bytes32[] public verifiedValidators;
    /// @notice Mapping of the hash of the validator's public key to the validator state and index.
    /// Uses the Beacon chain hashing for BLSPubkey which is sha256(abi.encodePacked(validator.pubkey, bytes16(0)))
    mapping(bytes32 => ValidatorData) public validator;

    /// @param blockRoot Beacon chain block root of the snapshot
    /// @param timestamp Timestamp of the snapshot
    /// @param ethBalance The balance of ETH in the strategy contract at the snapshot
    struct Balances {
        bytes32 blockRoot;
        uint64 timestamp;
        uint128 ethBalance;
    }
    /// @notice Mapping of the block root to the balances at that slot
    Balances public snappedBalance;
    /// @notice The last verified ETH balance of the strategy
    uint256 public lastVerifiedEthBalance;

    /// @dev This contract receives WETH as the deposit asset, but unlike other strategies doesn't immediately
    /// deposit it to an underlying platform. Rather a special privilege account stakes it to the validators.
    /// For that reason calling WETH.balanceOf(this) in a deposit function can contain WETH that has just been
    /// deposited and also WETH that has previously been deposited. To keep a correct count we need to keep track
    /// of WETH that has already been accounted for.
    /// This value represents the amount of WETH balance of this contract that has already been accounted for by the
    /// deposit events.
    /// It is important to note that this variable is not concerned with WETH that is a result of full/partial
    /// withdrawal of the validators. It is strictly concerned with WETH that has been deposited and is waiting to
    /// be staked.
    uint256 public depositedWethAccountedFor;
    /// @notice The amount of ETH in wei that is required for the first deposit to a new validator.
    uint256 public initialDepositAmountWei;
    /// @notice Timestamp of the last balance snapshot successfully verified against beacon chain data.
    uint64 public lastVerifiedBalanceTimestamp;

    // For future use
    uint256[39] private __gap;

    /// @param _wethAddress Address of the Erc20 WETH Token contract
    /// @param _vaultAddress Address of the Vault
    /// @param _beaconChainDepositContract Address of the beacon chain deposit contract
    /// @param _beaconProofs Address of the Beacon Proofs contract that verifies beacon chain data
    /// @param _beaconGenesisTimestamp The timestamp of the Beacon chain's genesis.
    constructor(
        address _wethAddress,
        address _vaultAddress,
        address _beaconChainDepositContract,
        address _beaconProofs,
        uint64 _beaconGenesisTimestamp
    ) {
        WETH = _wethAddress;
        BEACON_CHAIN_DEPOSIT_CONTRACT = _beaconChainDepositContract;
        VAULT_ADDRESS = _vaultAddress;
        BEACON_PROOFS = _beaconProofs;
        BEACON_GENESIS_TIMESTAMP = _beaconGenesisTimestamp;

        require(
            block.timestamp > _beaconGenesisTimestamp,
            "Invalid genesis timestamp"
        );
    }
}

contract CompoundingStakingStrategy is
    CompoundingValidatorStorage,
    InitializableAbstractStrategy
{
    using SafeERC20 for IERC20;

    /// @param _baseConfig Base strategy config with
    ///   `platformAddress` not used so empty address
    ///   `vaultAddress` the address of the OETH Vault contract
    /// @param _wethAddress Address of the WETH Token contract
    /// @param _beaconChainDepositContract Address of the beacon chain deposit contract
    /// @param _beaconProofs Address of the Beacon Proofs contract that verifies beacon chain data
    /// @param _beaconGenesisTimestamp The timestamp of the Beacon chain's genesis.
    constructor(
        BaseStrategyConfig memory _baseConfig,
        address _wethAddress,
        address _beaconChainDepositContract,
        address _beaconProofs,
        uint64 _beaconGenesisTimestamp
    )
        InitializableAbstractStrategy(_baseConfig)
        CompoundingValidatorStorage(
            _wethAddress,
            _baseConfig.vaultAddress,
            _beaconChainDepositContract,
            _beaconProofs,
            _beaconGenesisTimestamp
        )
    {
        // Make sure nobody owns the implementation contract
        _setGovernor(address(0));
    }

    event RegistratorChanged(address indexed newAddress);
    event InitialDepositAmountChanged(uint256 amountWei);
    event FirstDepositReset();
    event ETHStaked(
        bytes32 indexed pubKeyHash,
        bytes32 indexed pendingDepositRoot,
        bytes pubKey,
        uint256 amountWei
    );
    event ValidatorVerified(
        bytes32 indexed pubKeyHash,
        uint40 indexed validatorIndex
    );
    event ValidatorInvalid(bytes32 indexed pubKeyHash);
    event DepositVerified(
        bytes32 indexed pendingDepositRoot,
        uint256 amountWei
    );
    event ValidatorWithdraw(bytes32 indexed pubKeyHash, uint256 amountWei);
    event BalancesSnapped(bytes32 indexed blockRoot, uint256 ethBalance);
    event BalancesVerified(
        uint64 indexed timestamp,
        uint256 totalDepositsWei,
        uint256 totalValidatorBalance,
        uint256 ethBalance
    );

    error NotRegistratorOrGovernor(); // 0xbf454a2d
    error NotRegistrator(); // 0x929df920
    error NoFirstDeposit(); // 0x30e60c37
    error InvalidFirstDepositAmount(); // 0x29829bdd
    error UnsupportedAsset(); // 0x24a01144
    error UnsupportedFunction(); // 0xea1c702e

    /// @dev Throws if called by any account other than the Registrator
    modifier onlyRegistrator() {
        _onlyRegistrator();
        _;
    }

    /// @dev internal function used to reduce contract size
    function _onlyRegistrator() internal view {
        if (msg.sender != validatorRegistrator) {
            revert NotRegistrator();
        }
    }

    /// @dev Throws if called by any account other than the Registrator or Governor
    modifier onlyRegistratorOrGovernor() {
        if (msg.sender != validatorRegistrator && !isGovernor()) {
            revert NotRegistratorOrGovernor();
        }
        _;
    }

    /// @notice Set up initial internal state.
    /// @param _rewardTokenAddresses Not used so empty array
    /// @param _assets Not used so empty array
    /// @param _pTokens Not used so empty array
    /// @param _initialDepositAmountWei The amount of ETH required for the first deposit to a new validator.
    function initialize(
        address[] memory _rewardTokenAddresses,
        address[] memory _assets,
        address[] memory _pTokens,
        uint256 _initialDepositAmountWei
    ) external onlyGovernor initializer {
        InitializableAbstractStrategy._initialize(
            _rewardTokenAddresses,
            _assets,
            _pTokens
        );
        _setInitialDepositAmountWei(_initialDepositAmountWei);
    }

    /**
     *
     *             Admin Functions
     *
     */

    /// @notice Set the address of the registrator which can register, exit and remove validators
    function setRegistrator(address _address) external onlyGovernor {
        validatorRegistrator = _address;
        emit RegistratorChanged(_address);
    }

    /// @notice Set the amount of ETH required for the first deposit to a new validator.
    function setInitialDepositAmount(uint256 _initialDepositAmountWei)
        external
        onlyGovernor
    {
        _setInitialDepositAmountWei(_initialDepositAmountWei);
    }

    /// @notice Reset the `firstDeposit` flag to false so deposits to unverified validators can be made again.
    function resetFirstDeposit() external onlyGovernorOrStrategist {
        if (!firstDeposit) {
            revert NoFirstDeposit();
        }

        firstDeposit = false;

        emit FirstDepositReset();
    }

    function pause() external onlyRegistratorOrGovernor {
        _pause();
    }

    function unPause() external onlyGovernor {
        _unpause();
    }

    /**
     *
     *             Validator Management
     *
     */

    struct ValidatorStakeData {
        bytes pubkey;
        bytes signature;
        bytes32 depositDataRoot;
    }

    /// @notice Stakes WETH in this strategy to a compounding validator.
    /// The first deposit to a new validator must be less than or equal to `initialDepositAmountWei`.
    /// Once verified on the beacon chain, rewards can push the validator's balance above
    /// the activation threshold so it can become active without requiring a second deposit.
    /// Does not convert any ETH sitting in this strategy to WETH.
    /// There can not be two deposits to the same validator in the same block for the same amount.
    /// Function is pausable so in case a run-away Registrator can be prevented from continuing
    /// to deposit funds to slashed or undesired validators.
    /// @param validatorStakeData validator data needed to stake.
    /// The `ValidatorStakeData` struct contains the pubkey, signature and depositDataRoot.
    /// Only the registrator can call this function.
    /// @param depositAmountGwei The amount of WETH to stake to the validator in Gwei.
    // slither-disable-start reentrancy-eth,reentrancy-no-eth
    function stakeEth(
        ValidatorStakeData calldata validatorStakeData,
        uint64 depositAmountGwei
    ) external onlyRegistrator whenNotPaused {
        uint256 depositAmountWei = uint256(depositAmountGwei) * 1 gwei;
        // Check there is enough WETH from the deposits sitting in this strategy contract
        // There could be ETH from withdrawals but we'll ignore that. If it's really needed
        // the ETH can be withdrawn and then deposited back to the strategy.
        require(
            depositAmountWei <= IWETH9(WETH).balanceOf(address(this)),
            "Insufficient WETH"
        );
        require(depositList.length < MAX_DEPOSITS, "Max deposits");

        // Convert required ETH from WETH and do the necessary accounting
        _convertWethToEth(depositAmountWei);

        // Hash the public key using the Beacon Chain's hashing for BLSPubkey
        bytes32 pubKeyHash = _hashPubKey(validatorStakeData.pubkey);
        // Can only stake to a validator that is new, verified or active.
        // Can not stake to a validator that has been staked but not yet verified.
        require(depositAmountWei >= 1 ether, "Deposit too small");
        _admitStake(pubKeyHash, depositAmountWei);

        /* 0x02 to indicate that withdrawal credentials are for a compounding validator
         * that was introduced with the Pectra upgrade.
         * bytes11(0) to fill up the required zeros
         * remaining bytes20 are for the address
         */
        bytes memory withdrawalCredentials = abi.encodePacked(
            bytes1(0x02),
            bytes11(0),
            address(this)
        );

        /// After the Pectra upgrade the validators have a new restriction when proposing
        /// blocks. The timestamps are at strict intervals of 12 seconds from the genesis block
        /// forward. Each slot is created at strict 12 second intervals and those slots can
        /// either have blocks attached to them or not. This way using the block.timestamp
        /// the slot number can easily be calculated.
        uint64 depositSlot = (SafeCast.toUint64(block.timestamp) -
            BEACON_GENESIS_TIMESTAMP) / SLOT_DURATION;

        // Calculate the merkle root of the beacon chain pending deposit data.
        // This is used as the unique ID of the deposit.
        bytes32 pendingDepositRoot = IBeaconProofs(BEACON_PROOFS)
            .merkleizePendingDeposit(
                pubKeyHash,
                withdrawalCredentials,
                depositAmountGwei,
                validatorStakeData.signature,
                depositSlot
            );
        require(
            deposits[pendingDepositRoot].status == DepositStatus.UNKNOWN,
            "Duplicate deposit"
        );

        // Store the deposit data for verifyDeposit and verifyBalances
        deposits[pendingDepositRoot] = DepositData({
            pubKeyHash: pubKeyHash,
            amountGwei: depositAmountGwei,
            slot: depositSlot,
            depositIndex: SafeCast.toUint32(depositList.length),
            status: DepositStatus.PENDING
        });
        depositList.push(pendingDepositRoot);

        // Deposit to the Beacon Chain deposit contract.
        // This will create a deposit in the beacon chain's pending deposit queue.
        IDepositContract(BEACON_CHAIN_DEPOSIT_CONTRACT).deposit{
            value: depositAmountWei
        }(
            validatorStakeData.pubkey,
            withdrawalCredentials,
            validatorStakeData.signature,
            validatorStakeData.depositDataRoot
        );

        emit ETHStaked(
            pubKeyHash,
            pendingDepositRoot,
            validatorStakeData.pubkey,
            depositAmountWei
        );
    }

    // slither-disable-end reentrancy-eth,reentrancy-no-eth

    function _admitStake(bytes32 pubKeyHash, uint256 depositAmountWei)
        internal
        virtual
    {
        ValidatorState currentState = validator[pubKeyHash].state;
        require(
            currentState == ValidatorState.NON_REGISTERED ||
                currentState == ValidatorState.VERIFIED ||
                currentState == ValidatorState.ACTIVE,
            "Not registered or verified"
        );

        if (currentState == ValidatorState.NON_REGISTERED) {
            _recordFirstDeposit(pubKeyHash, depositAmountWei);
        }
    }

    function _recordFirstDeposit(bytes32 pubKeyHash, uint256 depositAmountWei)
        internal
    {
        // Can only have one pending deposit to an unverified validator at a time.
        // This is to limit front-running deposit attacks to a single deposit.
        // The existing deposit needs to be verified before another deposit can be made.
        // If there was a front-running attack, the validator needs to be verified as invalid
        // and the Governor calls `resetFirstDeposit` to set `firstDeposit` to false.
        require(!firstDeposit, "Existing first deposit");
        // Limits the amount of ETH that can be at risk from a front-running deposit attack.
        if (depositAmountWei > initialDepositAmountWei) {
            revert InvalidFirstDepositAmount();
        }
        // Limits the number of validator balance proofs to verifyBalances
        require(
            verifiedValidators.length + 1 <= MAX_VERIFIED_VALIDATORS,
            "Max validators"
        );

        // Flag a deposit to an unverified validator so no other deposits can be made
        // to an unverified validator.
        firstDeposit = true;
        validator[pubKeyHash].state = ValidatorState.STAKED;
    }

    /// @notice Request a full or partial withdrawal from a validator.
    /// A zero amount will trigger a full withdrawal.
    /// If the remaining balance is < 32 ETH then only the amount in excess of 32 ETH will be withdrawn.
    /// Only the Registrator can call this function.
    /// 1 wei of value should be sent with the tx to pay for the withdrawal request fee.
    /// If no value sent, 1 wei will be taken from the strategy's ETH balance if it has any.
    /// If no ETH balance, the tx will revert.
    /// @param publicKey The public key of the validator
    /// @param amountGwei The amount of ETH to be withdrawn from the validator in Gwei.
    /// A zero amount will trigger a full withdrawal.
    // slither-disable-start reentrancy-no-eth
    function validatorWithdrawal(bytes calldata publicKey, uint64 amountGwei)
        external
        payable
        onlyRegistrator
    {
        // Hash the public key using the Beacon Chain's format
        bytes32 pubKeyHash = _hashPubKey(publicKey);
        ValidatorData memory validatorDataMem = validator[pubKeyHash];
        // Validator full withdrawal could be denied due to multiple reasons:
        //  - the validator has not been activated or active long enough
        //    (current_epoch < activation_epoch + SHARD_COMMITTEE_PERIOD)
        //  - the validator has pending balance to withdraw from a previous partial withdrawal request
        //
        // Meaning that the on-chain to beacon chain full withdrawal request could fail. Instead
        // of adding complexity of verifying if a validator is eligible for a full exit, we allow
        // multiple full withdrawal requests per validator.
        require(
            validatorDataMem.state == ValidatorState.ACTIVE ||
                validatorDataMem.state == ValidatorState.EXITING,
            "Validator not active/exiting"
        );

        // If a full withdrawal (validator exit)
        if (amountGwei == 0) {
            // For each staking strategy's deposits
            uint256 depositsCount = depositList.length;
            for (uint256 i = 0; i < depositsCount; ++i) {
                bytes32 pendingDepositRoot = depositList[i];
                // Check there is no pending deposits to the exiting validator
                require(
                    pubKeyHash != deposits[pendingDepositRoot].pubKeyHash,
                    "Pending deposit"
                );
            }

            // Store the validator state as exiting so no more deposits can be made to it.
            // This may already be EXITING if the previous exit request failed. eg the validator
            // was not active long enough.
            validator[pubKeyHash].state = ValidatorState.EXITING;
        }

        // Do not remove from the list of verified validators.
        // This is done in the verifyBalances function once the validator's balance has been verified to be zero.
        // The validator state will be set to EXITED in the verifyBalances function.

        PartialWithdrawal.request(publicKey, amountGwei);

        emit ValidatorWithdraw(pubKeyHash, uint256(amountGwei) * 1 gwei);
    }

    // slither-disable-end reentrancy-no-eth

    /**
     *
     *             Beacon Chain Proofs
     *
     */

    /// @notice Verifies a validator's index to its public key.
    /// Adds to the list of verified validators if the validator's withdrawal address is this strategy's address.
    /// Marks the validator as invalid and removes the deposit if the withdrawal address is not this strategy's address.
    /// @param nextBlockTimestamp The timestamp of the execution layer block after the beacon chain slot
    /// we are verifying.
    /// The next one is needed as the Beacon Oracle returns the parent beacon block root for a block timestamp,
    /// which is the beacon block root of the previous block.
    /// @param validatorIndex The index of the validator on the beacon chain.
    /// @param pubKeyHash The hash of the validator's public key using the Beacon Chain's format
    /// @param withdrawalCredentials contain the validator type and withdrawal address. These can be incorrect and/or
    ///        malformed. In case of incorrect withdrawalCredentials the validator deposit has been front run
    /// @param validatorPubKeyProof The merkle proof for the validator public key to the beacon block root.
    /// This is 53 witness hashes of 32 bytes each concatenated together starting from the leaf node.
    /// BeaconBlock.state.validators[validatorIndex].pubkey
    function verifyValidator(
        uint64 nextBlockTimestamp,
        uint40 validatorIndex,
        bytes32 pubKeyHash,
        bytes32 withdrawalCredentials,
        bytes calldata validatorPubKeyProof
    ) external {
        require(
            validator[pubKeyHash].state == ValidatorState.STAKED,
            "Validator not staked"
        );

        // Get the beacon block root of the slot we are verifying the validator in.
        // The parent beacon block root of the next block is the beacon block root of the slot we are verifying.
        bytes32 blockRoot = BeaconRoots.parentBlockRoot(nextBlockTimestamp);

        // Verify the validator index is for the validator with the given public key.
        // Also verify the validator's withdrawal credentials
        IBeaconProofs(BEACON_PROOFS).verifyValidator(
            blockRoot,
            pubKeyHash,
            validatorPubKeyProof,
            validatorIndex,
            withdrawalCredentials
        );

        // Store the validator state as verified
        validator[pubKeyHash] = ValidatorData({
            state: ValidatorState.VERIFIED,
            index: validatorIndex
        });

        bytes32 expectedWithdrawalCredentials = bytes32(
            abi.encodePacked(bytes1(0x02), bytes11(0), address(this))
        );

        // If the initial deposit was front-run and the withdrawal address is not this strategy
        // or the validator type is not a compounding validator (0x02)
        if (expectedWithdrawalCredentials != withdrawalCredentials) {
            // override the validator state
            validator[pubKeyHash].state = ValidatorState.INVALID;

            // Find and remove the deposit as the funds can not be recovered
            uint256 depositCount = depositList.length;
            for (uint256 i = 0; i < depositCount; i++) {
                DepositData memory depositData = deposits[depositList[i]];
                if (depositData.pubKeyHash == pubKeyHash) {
                    // next verifyBalances will correctly account for the loss of a front-run
                    // deposit. Doing it here accounts for the loss as soon as possible
                    lastVerifiedEthBalance -= Math.min(
                        lastVerifiedEthBalance,
                        uint256(depositData.amountGwei) * 1 gwei
                    );
                    _removeDeposit(depositList[i], depositData);
                    break;
                }
            }

            // Leave the `firstDeposit` flag as true so no more deposits to unverified validators can be made.
            // The Governor has to reset the `firstDeposit` to false before another deposit to
            // an unverified validator can be made.
            // The Governor can set a new `validatorRegistrator` if they suspect it has been compromised.

            emit ValidatorInvalid(pubKeyHash);
            return;
        }

        // Add the new validator to the list of verified validators
        verifiedValidators.push(pubKeyHash);

        // Reset the firstDeposit flag as the first deposit to an unverified validator has been verified.
        firstDeposit = false;

        emit ValidatorVerified(pubKeyHash, validatorIndex);
    }

    struct FirstPendingDepositSlotProofData {
        uint64 slot;
        bytes proof;
    }

    struct StrategyValidatorProofData {
        uint64 withdrawableEpoch;
        bytes withdrawableEpochProof;
    }

    /// @notice Verifies a deposit on the execution layer has been processed by the beacon chain.
    /// This means the accounting of the strategy's ETH moves from a pending deposit to a validator balance.
    ///
    /// Important: this function has a limitation where `depositProcessedSlot` that is passed by the off-chain
    /// verifier requires a slot immediately after it to propose a block otherwise the `BeaconRoots.parentBlockRoot`
    /// will fail. This shouldn't be a problem, since by the current behaviour of beacon chain only 1%-3% slots
    /// don't propose a block.
    /// @param pendingDepositRoot The unique identifier of the deposit emitted in `ETHStaked` from
    /// the `stakeEth` function.
    /// @param depositProcessedSlot Any slot on or after the strategy's deposit was processed on the beacon chain.
    /// Can not be a slot with pending deposits with the same slot as the deposit being verified.
    /// Can not be a slot before a missed slot as the Beacon Root contract will have the parent block root
    /// set for the next block timestamp in 12 seconds time.
    /// @param firstPendingDeposit a `FirstPendingDepositSlotProofData` struct containing:
    /// - slot: The beacon chain slot of the first deposit in the beacon chain's deposit queue.
    ///   Can be any non-zero value if the deposit queue is empty.
    /// - proof: The merkle proof of the first pending deposit's slot to the beacon block root.
    ///   Can be either:
    ///   * 40 witness hashes for BeaconBlock.state.PendingDeposits[0].slot when the deposit queue is not empty.
    ///   * 37 witness hashes for BeaconBlock.state.PendingDeposits[0] when the deposit queue is empty.
    ///   The 32 byte witness hashes are concatenated together starting from the leaf node.
    /// @param strategyValidatorData a `StrategyValidatorProofData` struct containing:
    /// - withdrawableEpoch: The withdrawable epoch of the validator the strategy is depositing to.
    /// - withdrawableEpochProof: The merkle proof for the withdrawable epoch of the validator the strategy
    ///   is depositing to, to the beacon block root.
    ///   This is 53 witness hashes of 32 bytes each concatenated together starting from the leaf node.
    // slither-disable-start reentrancy-no-eth
    function verifyDeposit(
        bytes32 pendingDepositRoot,
        uint64 depositProcessedSlot,
        FirstPendingDepositSlotProofData calldata firstPendingDeposit,
        StrategyValidatorProofData calldata strategyValidatorData
    ) external {
        // Load into memory the previously saved deposit data
        DepositData memory depositData = deposits[pendingDepositRoot];
        ValidatorData memory strategyValidator = validator[
            depositData.pubKeyHash
        ];
        require(
            depositData.status == DepositStatus.PENDING,
            "Deposit not pending"
        );
        require(firstPendingDeposit.slot != 0, "Zero 1st pending deposit slot");

        // We should allow the verification of deposits for validators that have been marked as exiting
        // to cover this situation:
        //  - there are 2 pending deposits
        //  - beacon chain has slashed the validator
        //  - when verifyDeposit is called for the first deposit it sets the Validator state to EXITING
        //  - verifyDeposit should allow a secondary call for the other deposit to a slashed validator
        require(
            strategyValidator.state == ValidatorState.VERIFIED ||
                strategyValidator.state == ValidatorState.ACTIVE ||
                strategyValidator.state == ValidatorState.EXITING,
            "Not verified/active/exiting"
        );
        // The verification slot must be after the deposit's slot.
        // This is needed for when the deposit queue is empty.
        require(
            depositData.slot < depositProcessedSlot,
            "Slot not after deposit"
        );

        uint64 snapTimestamp = snappedBalance.timestamp;

        // This check prevents an accounting error that can happen if:
        //  - snapBalances are snapped at the time of T
        //  - deposit is processed on the beacon chain after time T and before verifyBalances()
        //  - verifyDeposit is called before verifyBalances which removes a deposit from depositList
        //    and deposit balance from totalDepositsWei
        //  - verifyBalances is called under-reporting the strategy's balance
        require(
            (_calcNextBlockTimestamp(depositProcessedSlot) <= snapTimestamp) ||
                snapTimestamp == 0,
            "Deposit after balance snapshot"
        );

        // Get the parent beacon block root of the next block which is the block root of the deposit verification slot.
        // This will revert if the slot after the verification slot was missed.
        bytes32 depositBlockRoot = BeaconRoots.parentBlockRoot(
            _calcNextBlockTimestamp(depositProcessedSlot)
        );

        // Verify the slot of the first pending deposit matches the beacon chain
        bool isDepositQueueEmpty = IBeaconProofs(BEACON_PROOFS)
            .verifyFirstPendingDeposit(
                depositBlockRoot,
                firstPendingDeposit.slot,
                firstPendingDeposit.proof
            );

        // Verify the withdrawableEpoch on the validator of the strategy's deposit
        IBeaconProofs(BEACON_PROOFS).verifyValidatorWithdrawable(
            depositBlockRoot,
            strategyValidator.index,
            strategyValidatorData.withdrawableEpoch,
            strategyValidatorData.withdrawableEpochProof
        );

        uint64 firstPendingDepositEpoch = firstPendingDeposit.slot /
            SLOTS_PER_EPOCH;

        // If deposit queue is empty all deposits have certainly been processed. If not
        // a validator can either be not exiting and no further checks are required.
        // Or a validator is exiting then this function needs to make sure that the
        // pending deposit to an exited validator has certainly been processed. The
        // slot/epoch of first pending deposit is the one that contains the transaction
        // where the deposit to the ETH Deposit Contract has been made.
        //
        // Once the firstPendingDepositEpoch becomes greater than the withdrawableEpoch of
        // the slashed validator then the deposit has certainly been processed. When the beacon
        // chain reaches the withdrawableEpoch of the validator the deposit will no longer be
        // postponed. And any new deposits created (and present in the deposit queue)
        // will have an equal or larger withdrawableEpoch.
        require(
            strategyValidatorData.withdrawableEpoch == FAR_FUTURE_EPOCH ||
                strategyValidatorData.withdrawableEpoch <=
                firstPendingDepositEpoch ||
                isDepositQueueEmpty,
            "Exit Deposit likely not proc."
        );

        // solhint-disable max-line-length
        // Check the deposit slot is before the first pending deposit's slot on the beacon chain.
        // If this is not true then we can't guarantee the deposit has been processed by the beacon chain.
        // The deposit's slot can not be the same slot as the first pending deposit as there could be
        // many deposits in the same block, hence have the same pending deposit slot.
        // If the deposit queue is empty then our deposit must have been processed on the beacon chain.
        // The deposit slot can be zero for validators consolidating to a compounding validator or 0x01 validator
        // being promoted to a compounding one. Reference:
        // - [switch_to_compounding_validator](https://ethereum.github.io/consensus-specs/specs/electra/beacon-chain/#new-switch_to_compounding_validator
        // - [queue_excess_active_balance](https://ethereum.github.io/consensus-specs/specs/electra/beacon-chain/#new-queue_excess_active_balance)
        // - [process_consolidation_request](https://ethereum.github.io/consensus-specs/specs/electra/beacon-chain/#new-process_consolidation_request)
        // We can not guarantee that the deposit has been processed in that case.
        // solhint-enable max-line-length
        require(
            depositData.slot < firstPendingDeposit.slot || isDepositQueueEmpty,
            "Deposit likely not processed"
        );

        // Remove the deposit now it has been verified as processed on the beacon chain.
        _removeDeposit(pendingDepositRoot, depositData);

        emit DepositVerified(
            pendingDepositRoot,
            uint256(depositData.amountGwei) * 1 gwei
        );
    }

    function _removeDeposit(
        bytes32 pendingDepositRoot,
        DepositData memory depositData
    ) internal {
        // After verifying the proof, update the contract storage
        deposits[pendingDepositRoot].status = DepositStatus.VERIFIED;
        // Move the last deposit to the index of the verified deposit
        bytes32 lastDeposit = depositList[depositList.length - 1];
        depositList[depositData.depositIndex] = lastDeposit;
        deposits[lastDeposit].depositIndex = depositData.depositIndex;
        // Delete the last deposit from the list
        depositList.pop();
    }

    /// @dev Calculates the timestamp of the next execution block from the given slot.
    /// @param slot The beacon chain slot number used for merkle proof verification.
    function _calcNextBlockTimestamp(uint64 slot)
        internal
        view
        returns (uint64)
    {
        // Calculate the next block timestamp from the slot.
        return SLOT_DURATION * slot + BEACON_GENESIS_TIMESTAMP + SLOT_DURATION;
    }

    // slither-disable-end reentrancy-no-eth

    /// @notice Stores the current ETH balance at the current block and beacon block root
    ///         of the slot that is associated with the previous block.
    ///
    /// When snapping / verifying balance it is of a high importance that there is no
    /// miss-match in respect to ETH that is held by the contract and balances that are
    /// verified on the validators.
    ///
    /// First some context on the beacon-chain block building behaviour. Relevant parts of
    /// constructing a block on the beacon chain consist of:
    ///  - process_withdrawals: ETH is deducted from the validator's balance
    ///  - process_execution_payload: immediately after the previous step executing all the
    ///    transactions
    ///  - apply the withdrawals: adding ETH to the recipient which is the withdrawal address
    ///    contained in the withdrawal credentials of the exited validators
    ///
    /// That means that balance increases which are part of the post-block execution state are
    /// done within the block, but the transaction that are contained within that block can not
    /// see / interact with the balance from the exited validators. Only transactions in the
    /// next block can do that.
    ///
    /// When snap balances is performed the state of the chain is snapped across 2 separate
    /// chain states:
    ///  - ETH balance of the contract is recorded on block X -> and corresponding slot Y
    ///  - beacon chain block root is recorded of block X - 1 -> and corresponding slot Y - 1
    ///    given there were no missed slots. It could also be Y - 2, Y - 3 depending on how
    ///    many slots have not managed to propose a block. For the sake of simplicity this slot
    ///    will be referred to as Y - 1 as it makes no difference in the argument
    ///
    /// Given these 2 separate chain states it is paramount that verify balances can not experience
    /// miss-counting ETH or much more dangerous double counting of the ETH.
    ///
    /// When verifyBalances is called it is performed on the current block Z where Z > X. Verify
    /// balances adds up all the ETH (omitting WETH) controlled by this contract:
    ///  - ETH balance in the contract on block X
    ///  - ETH balance in Deposits on block Z that haven't been yet processed in slot Y - 1
    ///  - ETH balance in validators that are active in slot Y - 1
    ///  - skips the ETH balance in validators that have withdrawn in slot Y - 1 (or sooner)
    ///    and have their balance visible to transactions in slot Y and corresponding block X
    ///    (or sooner)
    ///
    /// Lets verify the correctness of ETH accounting given the above described behaviour.
    ///
    /// *ETH balance in the contract on block X*
    ///
    /// This is an ETH balance of the contract on a non current X block. Any ETH leaving the
    /// contract as a result of a withdrawal subtracts from the ETH accounted for on block X
    /// if `verifyBalances` has already been called. It also invalidates a `snapBalances` in
    /// case `verifyBalances` has not been called yet. Not performing this would result in not
    /// accounting for the withdrawn ETH that has happened anywhere in the block interval [X + 1, Z].
    ///
    /// Similarly to withdrawals any `stakeEth` deposits to the deposit contract adds to the ETH
    /// accounted for since the last `verifyBalances` has been called. And it invalidates the
    /// `snapBalances` in case `verifyBalances` hasn't been yet called. Not performing this
    /// would result in double counting the `stakedEth` since it would be present once in the
    /// snapped contract balance and the second time in deposit storage variables.
    ///
    /// This behaviour is correct.
    ///
    /// *ETH balance in Deposits on block Z that haven't been yet processed in slot Y - 1*
    ///
    /// The contract sums up all the ETH that has been deposited to the Beacon chain deposit
    /// contract at block Z. The execution layer doesn't have direct access to the state of
    /// deposits on the beacon chain. And if it is to sum up all the ETH that is marked to be
    /// deposited it needs to be sure to not double count ETH that is in deposits (storage vars)
    /// and could also be part of the validator balances. It does that by verifying that at
    /// slot Y - 1 none of the deposits visible on block Z have been processed. Meaning since
    /// the last snap till now all are still in queue. Which ensures they can not be part of
    /// the validator balances in later steps.
    ///
    /// This behaviour is correct.
    ///
    /// *ETH balance in validators that are active in slot Y - 1*
    ///
    /// The contract is verifying none of the deposits on Y - 1 slot have been processed and
    /// for that reason it checks the validator balances in the same slot. Ensuring accounting
    /// correctness.
    ///
    /// This behaviour is correct.
    ///
    /// *The withdrawn validators*
    ///
    /// The withdrawn validators could have their balances deducted in any slot before slot
    /// Y - 1 and the execution layer sees the balance increase in the subsequent slot. Lets
    /// look at the "worst case scenario" where the validator withdrawal is processed in the
    /// slot Y - 1 (snapped slot) and see their balance increase (in execution layer) in slot
    /// Y -> block X. The ETH balance on the contract is snapped at block X meaning that
    /// even if the validator exits at the latest possible time it is paramount that the ETH
    /// balance on the execution layer is recorded in the next block. Correctly accounting
    /// for the withdrawn ETH.
    ///
    /// Worth mentioning if the validator exit is processed by the slot Y and balance increase
    /// seen on the execution layer on block X + 1 the withdrawal is ignored by both the
    /// validator balance verification as well as execution layer contract balance snap.
    ///
    /// This behaviour is correct.
    ///
    /// The validator balances on the beacon chain can then be proved with `verifyBalances`.
    /// This function is permissionless. The delay prevents callers from continually replacing
    /// snapshots before their balance proofs can be submitted.
    function snapBalances() external {
        uint64 currentTimestamp = SafeCast.toUint64(block.timestamp);
        require(
            snappedBalance.timestamp + SNAP_BALANCES_DELAY < currentTimestamp,
            "Snap too soon"
        );

        bytes32 blockRoot = BeaconRoots.parentBlockRoot(currentTimestamp);
        // Get the current ETH balance
        uint256 ethBalance = address(this).balance;

        // Store the snapped balance
        snappedBalance = Balances({
            blockRoot: blockRoot,
            timestamp: currentTimestamp,
            ethBalance: SafeCast.toUint128(ethBalance)
        });

        emit BalancesSnapped(blockRoot, ethBalance);
    }

    // A struct is used to avoid stack too deep errors
    struct BalanceProofs {
        // BeaconBlock.state.balances
        bytes32 balancesContainerRoot;
        bytes balancesContainerProof;
        // BeaconBlock.state.balances[validatorIndex]
        bytes32[] validatorBalanceLeaves;
        bytes[] validatorBalanceProofs;
    }

    struct PendingDepositProofs {
        bytes32 pendingDepositContainerRoot;
        bytes pendingDepositContainerProof;
        uint32[] pendingDepositIndexes;
        bytes[] pendingDepositProofs;
    }

    /// @notice Verifies the balances of all active validators on the beacon chain
    /// and checks each of the strategy's deposits are still to be processed by the beacon chain.
    /// @dev This function is permissionless; all supplied balances are verified against the snapped beacon block root.
    /// @param balanceProofs a `BalanceProofs` struct containing the following:
    /// - balancesContainerRoot: The merkle root of the balances container
    /// - balancesContainerProof: The merkle proof for the balances container to the beacon block root.
    ///    This is 9 witness hashes of 32 bytes each concatenated together starting from the leaf node.
    /// - validatorBalanceLeaves: Array of leaf nodes containing the validator balance with three other balances.
    /// - validatorBalanceProofs: Array of merkle proofs for the validator balance to the Balances container root.
    ///    This is 39 witness hashes of 32 bytes each concatenated together starting from the leaf node.
    /// @param pendingDepositProofs a `PendingDepositProofs` struct containing the following:
    /// - pendingDepositContainerRoot: The merkle root of the pending deposits list container
    /// - pendingDepositContainerProof: The merkle proof from the pending deposits list container
    ///     to the beacon block root.
    ///    This is 9 witness hashes of 32 bytes each concatenated together starting from the leaf node.
    /// - pendingDepositIndexes: Array of indexes in the pending deposits list container for each
    ///    of the strategy's deposits.
    /// - pendingDepositProofs: Array of merkle proofs for each strategy deposit in the
    ///    beacon chain's pending deposit list container to the pending deposits list container root.
    ///    These are 28 witness hashes of 32 bytes each concatenated together starting from the leaf node.
    // slither-disable-start reentrancy-no-eth
    function verifyBalances(
        BalanceProofs calldata balanceProofs,
        PendingDepositProofs calldata pendingDepositProofs
    ) external {
        // Load previously snapped balances for the given block root
        Balances memory balancesMem = snappedBalance;
        // Check the balances are the latest
        require(balancesMem.timestamp > 0, "No snapped balances");

        uint256 verifiedValidatorsCount = verifiedValidators.length;
        uint256 totalValidatorBalance = 0;
        uint256 depositsCount = depositList.length;

        // If there are no verified validators then we can skip the balance verification
        if (verifiedValidatorsCount > 0) {
            require(
                balanceProofs.validatorBalanceProofs.length ==
                    verifiedValidatorsCount,
                "Invalid balance proofs"
            );
            require(
                balanceProofs.validatorBalanceLeaves.length ==
                    verifiedValidatorsCount,
                "Invalid balance leaves"
            );
            // verify beaconBlock.state.balances root to beacon block root
            IBeaconProofs(BEACON_PROOFS).verifyBalancesContainer(
                balancesMem.blockRoot,
                balanceProofs.balancesContainerRoot,
                balanceProofs.balancesContainerProof
            );

            bytes32[]
                memory validatorHashesMem = _getPendingDepositValidatorHashes(
                    depositsCount
                );

            // for each validator in reverse order so we can pop off exited validators at the end
            for (uint256 i = verifiedValidatorsCount; i > 0; ) {
                --i;
                ValidatorData memory validatorDataMem = validator[
                    verifiedValidators[i]
                ];
                // verify validator's balance in beaconBlock.state.balances to the
                // beaconBlock.state.balances container root
                uint256 validatorBalanceGwei = IBeaconProofs(BEACON_PROOFS)
                    .verifyValidatorBalance(
                        balanceProofs.balancesContainerRoot,
                        balanceProofs.validatorBalanceLeaves[i],
                        balanceProofs.validatorBalanceProofs[i],
                        validatorDataMem.index
                    );

                // If the validator has exited and the balance is now zero
                if (validatorBalanceGwei == 0) {
                    // Check if there are any pending deposits to this validator
                    bool depositPending = false;
                    for (uint256 j = 0; j < validatorHashesMem.length; j++) {
                        if (validatorHashesMem[j] == verifiedValidators[i]) {
                            depositPending = true;
                            break;
                        }
                    }

                    // If validator has a pending deposit we can not remove due to
                    // the following situation:
                    //  - validator has a pending deposit
                    //  - validator has been slashed
                    //  - sweep cycle has withdrawn all ETH from the validator. Balance is 0
                    //  - beacon chain has processed the deposit and set the validator balance
                    //    to deposit amount
                    //  - if validator is no longer in the list of verifiedValidators its
                    //    balance will not be considered and be under-counted.
                    if (!depositPending) {
                        // Store the validator state as exited
                        // This could have been in VERIFIED, ACTIVE or EXITING state
                        validator[verifiedValidators[i]].state = ValidatorState
                            .EXITED;

                        // Remove the validator with a zero balance from the list of verified validators

                        // Reduce the count of verified validators which is the last index before the pop removes it.
                        verifiedValidatorsCount -= 1;

                        // Move the last validator that has already been verified to the current index.
                        // There's an extra SSTORE if i is the last active validator but that's fine,
                        // It's not a common case and the code is simpler this way.
                        verifiedValidators[i] = verifiedValidators[
                            verifiedValidatorsCount
                        ];
                        // Delete the last validator from the list
                        verifiedValidators.pop();
                    }

                    // The validator balance is zero so not need to add to totalValidatorBalance
                    continue;
                } else if (
                    validatorDataMem.state == ValidatorState.VERIFIED &&
                    validatorBalanceGwei > MIN_ACTIVATION_BALANCE_GWEI
                ) {
                    // Store the validator state as active. This does not necessarily mean the
                    // validator is active on the beacon chain yet. It just means the validator has
                    // enough balance that it can become active.
                    validator[verifiedValidators[i]].state = ValidatorState
                        .ACTIVE;
                }

                // convert Gwei balance to Wei and add to the total validator balance
                totalValidatorBalance += validatorBalanceGwei * 1 gwei;
            }
        }

        uint256 totalDepositsWei = 0;

        // If there are no deposits then we can skip the deposit verification.
        // This section is after the validator balance verifications so an exited validator will be marked
        // as EXITED before the deposits are verified. If there was a deposit to an exited validator
        // then the deposit can only be removed once the validator is fully exited.
        // It is possible that validator fully exits and a postponed deposit to an exited validator increases
        // its balance again. In such case the contract will erroneously consider a deposit applied before it
        // has been applied on the beacon chain showing a smaller than real `totalValidatorBalance`.
        if (depositsCount > 0) {
            require(
                pendingDepositProofs.pendingDepositProofs.length ==
                    depositsCount,
                "Invalid deposit proofs"
            );
            require(
                pendingDepositProofs.pendingDepositIndexes.length ==
                    depositsCount,
                "Invalid deposit indexes"
            );

            // Verify from the root of the pending deposit list container to the beacon block root
            IBeaconProofs(BEACON_PROOFS).verifyPendingDepositsContainer(
                balancesMem.blockRoot,
                pendingDepositProofs.pendingDepositContainerRoot,
                pendingDepositProofs.pendingDepositContainerProof
            );

            // For each staking strategy's deposit.
            for (uint256 i = 0; i < depositsCount; ++i) {
                bytes32 pendingDepositRoot = depositList[i];

                // Verify the strategy's deposit is still pending on the beacon chain.
                IBeaconProofs(BEACON_PROOFS).verifyPendingDeposit(
                    pendingDepositProofs.pendingDepositContainerRoot,
                    pendingDepositRoot,
                    pendingDepositProofs.pendingDepositProofs[i],
                    pendingDepositProofs.pendingDepositIndexes[i]
                );

                // Convert the deposit amount from Gwei to Wei and add to the total
                totalDepositsWei +=
                    uint256(deposits[pendingDepositRoot].amountGwei) *
                    1 gwei;
            }
        }

        // Store the verified balance in storage
        lastVerifiedEthBalance =
            totalDepositsWei +
            totalValidatorBalance +
            balancesMem.ethBalance;
        // Store the timestamp of the snapshot whose beacon chain data was successfully verified.
        lastVerifiedBalanceTimestamp = balancesMem.timestamp;
        // Reset the last snap timestamp so a new snapBalances has to be made
        snappedBalance.timestamp = 0;

        emit BalancesVerified(
            balancesMem.timestamp,
            totalDepositsWei,
            totalValidatorBalance,
            balancesMem.ethBalance
        );
    }

    // slither-disable-end reentrancy-no-eth

    /// @notice get a list of all validator hashes present in the pending deposits
    ///         list can have duplicate entries
    function _getPendingDepositValidatorHashes(uint256 depositsCount)
        internal
        view
        returns (bytes32[] memory validatorHashes)
    {
        validatorHashes = new bytes32[](depositsCount);
        for (uint256 i = 0; i < depositsCount; i++) {
            validatorHashes[i] = deposits[depositList[i]].pubKeyHash;
        }
    }

    function _setInitialDepositAmountWei(uint256 _initialDepositAmountWei)
        internal
    {
        require(_initialDepositAmountWei >= 1 ether, "Deposit too small");
        require(
            _initialDepositAmountWei <= MAX_INITIAL_DEPOSIT_AMOUNT_WEI,
            "Deposit too large"
        );

        initialDepositAmountWei = _initialDepositAmountWei;
        emit InitialDepositAmountChanged(_initialDepositAmountWei);
    }

    /// @notice Hash a validator public key using the Beacon Chain's format
    function _hashPubKey(bytes memory pubKey) internal pure returns (bytes32) {
        require(pubKey.length == 48, "Invalid public key");
        return sha256(abi.encodePacked(pubKey, bytes16(0)));
    }

    /**
     *
     *         WETH and ETH Accounting
     *
     */

    /// @dev Called when WETH is transferred out of the strategy so
    /// the strategy knows how much WETH it has on deposit.
    /// This is so it can emit the correct amount in the Deposit event in depositAll().
    function _transferWeth(uint256 _amount, address _recipient) internal {
        IERC20(WETH).safeTransfer(_recipient, _amount);

        // The min is required as more WETH can be withdrawn than deposited
        // as the strategy earns consensus and execution rewards.
        uint256 deductAmount = Math.min(_amount, depositedWethAccountedFor);
        depositedWethAccountedFor -= deductAmount;

        // No change in ETH balance so no need to snapshot the balances
    }

    /// @dev Converts ETH to WETH and updates the accounting.
    /// @param _ethAmount The amount of ETH in wei.
    function _convertEthToWeth(uint256 _ethAmount) internal {
        // slither-disable-next-line arbitrary-send-eth
        IWETH9(WETH).deposit{ value: _ethAmount }();

        depositedWethAccountedFor += _ethAmount;

        // Store the reduced ETH balance.
        // The ETH balance in this strategy contract can be more than the last verified ETH balance
        // due to partial withdrawals or full exits being processed by the beacon chain since the last snapBalances.
        // It can also happen from execution rewards (MEV) or ETH donations.
        lastVerifiedEthBalance -= Math.min(lastVerifiedEthBalance, _ethAmount);

        // The ETH balance was decreased to WETH so we need to invalidate the last balances snap.
        snappedBalance.timestamp = 0;
    }

    /// @dev Converts WETH to ETH and updates the accounting.
    /// @param _wethAmount The amount of WETH in wei.
    function _convertWethToEth(uint256 _wethAmount) internal {
        IWETH9(WETH).withdraw(_wethAmount);

        uint256 deductAmount = Math.min(_wethAmount, depositedWethAccountedFor);
        depositedWethAccountedFor -= deductAmount;

        // Store the increased ETH balance
        lastVerifiedEthBalance += _wethAmount;

        // The ETH balance was increased from WETH so we need to invalidate the last balances snap.
        snappedBalance.timestamp = 0;
    }

    /**
     *
     *             View Functions
     *
     */

    /// @notice Returns the number of deposits waiting to be verified as processed on the beacon chain,
    /// or deposits that have been verified to an exiting validator and is now waiting for the
    /// validator's balance to be swept.
    function depositListLength() external view returns (uint256) {
        return depositList.length;
    }

    /// @notice Returns the number of verified validators.
    function verifiedValidatorsLength() external view returns (uint256) {
        return verifiedValidators.length;
    }

    /// @notice Unlike other strategies, this does not deposit assets into the underlying platform.
    /// It just checks the asset is WETH and emits the Deposit event.
    /// To deposit WETH into validators, `stakeEth` must be used.
    /// @param _asset Address of the WETH token.
    /// @param _amount Amount of WETH that was transferred to the strategy by the vault.
    function deposit(address _asset, uint256 _amount)
        external
        override
        onlyVault
        nonReentrant
    {
        if (_asset != WETH) {
            revert UnsupportedAsset();
        }
        require(_amount > 0, "Must deposit something");

        // Account for the new WETH
        depositedWethAccountedFor += _amount;

        emit Deposit(_asset, address(0), _amount);
    }

    /// @notice Unlike other strategies, this does not deposit assets into the underlying platform.
    /// It just emits the Deposit event.
    /// To deposit WETH into validators, `stakeEth` must be used.
    function depositAll() external override onlyVault nonReentrant {
        uint256 wethBalance = IERC20(WETH).balanceOf(address(this));
        uint256 newWeth = wethBalance - depositedWethAccountedFor;

        if (newWeth > 0) {
            // Account for the new WETH
            depositedWethAccountedFor = wethBalance;

            emit Deposit(WETH, address(0), newWeth);
        }
    }

    /// @notice Withdraw ETH and WETH from this strategy contract.
    /// @param _recipient Address to receive withdrawn assets.
    /// @param _asset Address of the WETH token.
    /// @param _amount Amount of WETH to withdraw.
    function withdraw(
        address _recipient,
        address _asset,
        uint256 _amount
    ) external override nonReentrant {
        if (_asset != WETH) {
            revert UnsupportedAsset();
        }
        require(
            msg.sender == vaultAddress || msg.sender == validatorRegistrator,
            "Caller not Vault or Registrator"
        );

        _withdraw(_recipient, _amount, address(this).balance);
    }

    function _withdraw(
        address _recipient,
        uint256 _withdrawAmount,
        uint256 _ethBalance
    ) internal {
        require(_withdrawAmount > 0, "Must withdraw something");
        require(_recipient == vaultAddress, "Recipient not Vault");

        // Convert any ETH from validator partial withdrawals, exits
        // or execution rewards to WETH and do the necessary accounting.
        if (_ethBalance > 0) _convertEthToWeth(_ethBalance);

        // Transfer WETH to the recipient and do the necessary accounting.
        _transferWeth(_withdrawAmount, _recipient);

        emit Withdrawal(WETH, address(0), _withdrawAmount);
    }

    /// @notice Transfer all WETH deposits, ETH from validator withdrawals and ETH from
    /// execution rewards in this strategy to the vault.
    /// This does not withdraw from the validators. That has to be done separately with the
    /// `validatorWithdrawal` operation.
    function withdrawAll() external override onlyVaultOrGovernor nonReentrant {
        uint256 ethBalance = address(this).balance;
        uint256 withdrawAmount = IERC20(WETH).balanceOf(address(this)) +
            ethBalance;

        if (withdrawAmount > 0) {
            _withdraw(vaultAddress, withdrawAmount, ethBalance);
        }
    }

    /// @notice Accounts for all the assets managed by this strategy which includes:
    /// 1. The current WETH in this strategy contract
    /// 2. The last verified ETH balance, total deposits and total validator balances
    /// @param _asset      Address of WETH asset.
    /// @return balance    Total value in ETH
    function checkBalance(address _asset)
        external
        view
        override
        returns (uint256 balance)
    {
        if (_asset != WETH) {
            revert UnsupportedAsset();
        }

        // Load the last verified balance from the storage
        // and add to the latest WETH balance of this strategy.
        balance =
            lastVerifiedEthBalance +
            IWETH9(WETH).balanceOf(address(this));
    }

    /// @notice Returns bool indicating whether asset is supported by the strategy.
    /// @param _asset The address of the WETH token.
    function supportsAsset(address _asset) public view override returns (bool) {
        return _asset == WETH;
    }

    /// @notice Does nothing but needed as this function is abstract on InitializableAbstractStrategy
    function safeApproveAllTokens() public override {}

    /**
     * @notice We can accept ETH directly to this contract from anyone as it does not impact our accounting
     * like it did in the legacy NativeStakingStrategy.
     * The new ETH will be accounted for in `checkBalance` after the next snapBalances and verifyBalances txs.
     */
    receive() external payable {}

    /// @notice is not supported for this strategy as there is no platform token.
    function setPTokenAddress(address, address) external pure override {
        revert UnsupportedFunction();
    }

    /// @notice is not supported for this strategy as there is no platform token.
    function removePToken(uint256) external pure override {
        revert UnsupportedFunction();
    }

    /// @dev This strategy does not use a platform token like the old Aave and Compound strategies.
    function _abstractSetPToken(address _asset, address) internal override {}

    /// @dev Consensus rewards are compounded to the validator's balance instead of being
    /// swept to this strategy contract.
    /// Execution rewards from MEV and tx priority accumulate as ETH in this strategy contract.
    /// Withdrawals from validators also accumulate as ETH in this strategy contract.
    /// It's too complex to separate the rewards from withdrawals so this function is not implemented.
    /// Besides, ETH rewards are not sent to the Dripper any more. The Vault can now regulate
    /// the increase in assets.
    function _collectRewardTokens() internal pure override {
        revert UnsupportedFunction();
    }
}
