#!/usr/bin/env node

const { execSync } = require("child_process");
const { existsSync } = require("fs");
const path = require("path");
const os = require("os");

// ─── Argument parsing ────────────────────────────────────────────────────────

function parseArgs(argv) {
  const args = { base: "master", head: null, contracts: [] };

  for (let i = 2; i < argv.length; i++) {
    switch (argv[i]) {
      case "--contract":
        args.contracts = argv[++i].split(",").map((c) => c.trim());
        break;
      case "--base":
        args.base = argv[++i];
        break;
      case "--head":
        args.head = argv[++i];
        break;
      case "--help":
        console.log(
          [
            "Usage: node scripts/check-storage-layout.js --contract <Name[,Name2]> [--base <ref>] [--head <ref>]",
            "",
            "Options:",
            "  --contract  Contract name(s), comma-separated (required)",
            "  --base      Git ref for the old version (default: master)",
            "  --head      Git ref for the new version (default: current working tree)",
            "  --help      Show this help message",
          ].join("\n")
        );
        process.exit(0);
      default:
        console.error(`Unknown argument: ${argv[i]}`);
        process.exit(1);
    }
  }

  if (args.contracts.length === 0) {
    console.error("Error: --contract is required");
    process.exit(1);
  }

  return args;
}

// ─── Worktree helpers ────────────────────────────────────────────────────────

function createWorktree(ref) {
  const dir = path.join(
    os.tmpdir(),
    `storage-check-${ref.replace(/[^a-zA-Z0-9]/g, "-")}-${Date.now()}`
  );
  // --detach: without it, `git worktree add` refuses any branch that is already
  // checked out somewhere — which includes the default base ref, `master`.
  execSync(`git worktree add --detach "${dir}" "${ref}"`, {
    stdio: "pipe",
    cwd: path.resolve(__dirname, "../.."),
  });
  return dir;
}

function removeWorktree(dir) {
  try {
    execSync(`git worktree remove "${dir}" --force`, {
      stdio: "pipe",
      cwd: path.resolve(__dirname, "../.."),
    });
  } catch {
    // Best-effort cleanup
  }
}

// ─── Forge helpers ───────────────────────────────────────────────────────────

function installDeps(contractsDir) {
  console.log(`  Installing dependencies in ${contractsDir}...`);
  try {
    execSync("bash install-deps.sh", {
      cwd: contractsDir,
      stdio: "inherit",
      timeout: 120_000,
    });
  } catch {
    console.warn("  Warning: dependency install had issues, continuing...");
  }
}

// The working tree is used as-is for the head side, so its forge dependencies
// have to already be there. Fail with something actionable instead of letting
// `forge inspect` report a missing import.
function assertDepsInstalled(contractsDir) {
  if (existsSync(path.join(contractsDir, "dependencies"))) return;
  console.error(
    `Error: forge dependencies are missing in ${contractsDir}.\n` +
      `Run: bash install-deps.sh`
  );
  process.exit(1);
}

function forgeInspect(contractsDir, contractName) {
  // forge inspect compiles only the target contract + dependencies, not the whole repo
  const output = execSync(
    `forge inspect "${contractName}" storageLayout --json --force`,
    {
      cwd: contractsDir,
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
      timeout: 300_000,
    }
  );
  // forge may print tracing logs before the JSON — extract the JSON object
  const jsonStart = output.indexOf("{");
  if (jsonStart === -1) {
    throw new Error("No JSON found in forge inspect output");
  }
  return JSON.parse(output.slice(jsonStart));
}

function getLayout(contractsDir, contractName) {
  try {
    return forgeInspect(contractsDir, contractName);
  } catch (e) {
    console.error(`  Error: could not get storage layout for ${contractName}`);
    console.error(`  ${e.stderr || e.message}`);
    return null;
  }
}

// ─── Comparison logic ────────────────────────────────────────────────────────

function getTypeSize(layout, typeName) {
  const t = layout.types[typeName];
  return t ? parseInt(t.numberOfBytes, 10) : null;
}

function isGapVariable(entry) {
  // Any number of leading underscores. Sources are unified on `__gap` (plus a
  // legacy `_gap` in OUSD), but stay permissive so a reintroduced `___gap`
  // is still recognised as a gap rather than a removed variable.
  return /^_*gap$/.test(entry.label);
}

function gapSlotCount(layout, entry) {
  const t = layout.types[entry.type];
  if (!t) return 0;
  // Gap arrays are t_array(t_uint256)N_storage → N * 32 bytes / 32 = N slots
  return parseInt(t.numberOfBytes, 10) / 32;
}

function compareLayouts(oldLayout, newLayout) {
  const errors = [];
  const infos = [];

  const oldStorage = oldLayout.storage;
  const newStorage = newLayout.storage;

  // Build a map of slot+offset → entry for the new layout
  const newBySlotOffset = new Map();
  for (const entry of newStorage) {
    newBySlotOffset.set(`${entry.slot}:${entry.offset}`, entry);
  }

  // Check every old entry still exists at the same slot+offset with same type
  for (const oldEntry of oldStorage) {
    const key = `${oldEntry.slot}:${oldEntry.offset}`;
    const newEntry = newBySlotOffset.get(key);

    if (!newEntry) {
      // Might be a gap that was shrunk — check if it's a gap variable
      if (isGapVariable(oldEntry)) {
        // Check if the gap moved or shrunk (handled below)
        continue;
      }
      errors.push(
        `Variable "${oldEntry.label}" (${oldEntry.contract}) at slot ${oldEntry.slot} offset ${oldEntry.offset} was removed or shifted`
      );
      continue;
    }

    // Type must match (label/name can differ)
    if (oldEntry.type !== newEntry.type) {
      const oldSize = getTypeSize(oldLayout, oldEntry.type);
      const newSize = getTypeSize(newLayout, newEntry.type);

      // Gap replaced by a new variable — valid "carving from gap" pattern
      if (isGapVariable(oldEntry) && !isGapVariable(newEntry)) {
        const oldGapSlots = gapSlotCount(oldLayout, oldEntry);
        // Find the new gap in the new layout (should be right after the new variables)
        const newGap = newStorage.find(
          (e) =>
            isGapVariable(e) &&
            e.contract === oldEntry.contract &&
            parseInt(e.slot, 10) > parseInt(oldEntry.slot, 10)
        );
        if (newGap) {
          const newGapSlots = gapSlotCount(newLayout, newGap);
          const newGapStart = parseInt(newGap.slot, 10);
          const oldGapStart = parseInt(oldEntry.slot, 10);
          const slotsUsed = newGapStart - oldGapStart;
          if (slotsUsed + newGapSlots === oldGapSlots) {
            infos.push(
              `__gap (${oldEntry.contract}) reduced from ${oldGapSlots} to ${newGapSlots} slots (${slotsUsed} slot(s) used by new variables)`
            );
            continue;
          }
        }
        // If we can't find a matching shrunk gap, flag it
        infos.push(
          `Gap at slot ${oldEntry.slot} replaced by "${newEntry.label}" — verify gap was properly shrunk`
        );
        continue;
      }

      // Check if it's a gap being resized (same slot, both gaps)
      if (isGapVariable(oldEntry) && isGapVariable(newEntry)) {
        const oldGapSlots = gapSlotCount(oldLayout, oldEntry);
        const newGapSlots = gapSlotCount(newLayout, newEntry);
        if (newGapSlots < oldGapSlots) {
          infos.push(
            `__gap (${oldEntry.contract}) reduced from ${oldGapSlots} to ${newGapSlots} slots`
          );
          continue;
        } else if (newGapSlots > oldGapSlots) {
          errors.push(
            `__gap (${oldEntry.contract}) grew from ${oldGapSlots} to ${newGapSlots} slots — this is unexpected`
          );
          continue;
        }
      }

      errors.push(
        `Type mismatch at slot ${oldEntry.slot} offset ${oldEntry.offset}: ` +
          `"${oldEntry.label}" was ${oldEntry.type} (${oldSize} bytes), ` +
          `now "${newEntry.label}" is ${newEntry.type} (${newSize} bytes)`
      );
      continue;
    }

    // Name changed. A same-typed variable shifting into this slot looks exactly
    // like a rename, so only accept it when the new name retires the slot —
    // anything else is treated as a shift.
    if (oldEntry.label !== newEntry.label) {
      if (/deprecated/i.test(newEntry.label)) {
        infos.push(
          `Slot ${oldEntry.slot} deprecated: "${oldEntry.label}" → "${newEntry.label}"`
        );
      } else {
        errors.push(
          `Variable renamed at slot ${oldEntry.slot} offset ${oldEntry.offset}: ` +
            `"${oldEntry.label}" → "${newEntry.label}". Either this is a storage ` +
            `shift, or the slot is being retired and the new name must contain ` +
            `"deprecated".`
        );
      }
    }
  }

  // Variables occupying a slot the old layout never used. Whether they were
  // carved out of a gap or appended past the end, they displace nothing — any
  // placement that does displace something already errored above.
  const oldSlotOffsets = new Set(
    oldStorage.map((e) => `${e.slot}:${e.offset}`)
  );
  for (const newEntry of newStorage) {
    if (isGapVariable(newEntry)) continue;
    if (oldSlotOffsets.has(`${newEntry.slot}:${newEntry.offset}`)) continue;
    infos.push(
      `New variable "${newEntry.label}" (${newEntry.contract}) at slot ${newEntry.slot} offset ${newEntry.offset}`
    );
  }

  return { errors, infos };
}

// ─── Main ────────────────────────────────────────────────────────────────────

async function main() {
  const args = parseArgs(process.argv);

  console.log("Storage Layout Compatibility Check");
  console.log(`Base ref: ${args.base}`);
  if (args.head) console.log(`Head ref: ${args.head}`);
  console.log("─".repeat(40));
  console.log();

  const repoRoot = path.resolve(__dirname, "../..");
  const currentContractsDir = path.resolve(__dirname, "..");

  // ── Set up head (new version) ──

  let headContractsDir;
  let headWorktreeDir = null;

  if (args.head) {
    console.log(`Creating worktree for head ref (${args.head})...`);
    headWorktreeDir = createWorktree(args.head);
    headContractsDir = path.join(headWorktreeDir, "contracts");
    installDeps(headContractsDir);
  } else {
    headContractsDir = currentContractsDir;
    assertDepsInstalled(headContractsDir);
  }

  // ── Set up base (old version) in a worktree ──

  console.log(`Creating worktree for base ref (${args.base})...`);
  const baseWorktreeDir = createWorktree(args.base);
  const baseContractsDir = path.join(baseWorktreeDir, "contracts");
  installDeps(baseContractsDir);

  console.log();

  // ── Compare each contract ──

  let passed = 0;
  let failed = 0;

  for (const contractName of args.contracts) {
    console.log(`Checking ${contractName}...`);

    const oldLayout = getLayout(baseContractsDir, contractName);
    const newLayout = getLayout(headContractsDir, contractName);

    if (!oldLayout && !newLayout) {
      console.log(`  [SKIP] Could not get layout for either version\n`);
      continue;
    }
    if (!oldLayout) {
      console.log(`  [INFO] New contract (no layout in base ref)\n`);
      passed++;
      continue;
    }
    if (!newLayout) {
      console.log(`  [WARN] Contract removed in new version\n`);
      continue;
    }

    console.log(`  Old: ${oldLayout.storage.length} storage entries`);
    console.log(`  New: ${newLayout.storage.length} storage entries`);

    const { errors, infos } = compareLayouts(oldLayout, newLayout);

    if (infos.length > 0) {
      console.log();
      for (const info of infos) console.log(`  [INFO] ${info}`);
    }

    if (errors.length > 0) {
      console.log();
      for (const err of errors) console.log(`  [FAIL] ${err}`);
      failed++;
    } else {
      console.log(`\n  [PASS] No slot conflicts detected`);
      passed++;
    }

    console.log();
  }

  // ── Cleanup ──

  console.log("Cleaning up worktrees...");
  removeWorktree(baseWorktreeDir);
  if (headWorktreeDir) removeWorktree(headWorktreeDir);

  // ── Summary ──

  console.log();
  console.log("─".repeat(40));
  const total = passed + failed;
  if (failed > 0) {
    console.log(`Result: ${passed}/${total} passed, ${failed}/${total} FAILED`);
    process.exit(1);
  } else {
    console.log(`Result: ${passed}/${total} passed`);
    process.exit(0);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
