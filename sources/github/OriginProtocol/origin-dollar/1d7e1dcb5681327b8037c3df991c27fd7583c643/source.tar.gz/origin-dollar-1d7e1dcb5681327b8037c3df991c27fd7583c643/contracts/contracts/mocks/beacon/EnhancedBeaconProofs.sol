// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.0;

import { BeaconProofsLib } from "../../beacon/BeaconProofsLib.sol";
import { BeaconProofs } from "../../beacon/BeaconProofs.sol";

contract EnhancedBeaconProofs is BeaconProofs {
    function concatGenIndices(
        uint256 index1,
        uint256 height2,
        uint256 index2
    ) external pure returns (uint256 genIndex) {
        return BeaconProofsLib.concatGenIndices(index1, height2, index2);
    }

    function balanceAtIndex(bytes32 validatorBalanceLeaf, uint40 validatorIndex)
        external
        pure
        returns (uint256)
    {
        return
            BeaconProofsLib.balanceAtIndex(
                validatorBalanceLeaf,
                validatorIndex
            );
    }
}
