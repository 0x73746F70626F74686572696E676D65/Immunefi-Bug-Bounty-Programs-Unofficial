import { ousdProcessors } from 'ousd/processors/ousd'
import 'tsconfig-paths/register'

import { defineSquidProcessor } from '@originprotocol/squid-utils'
import * as exchangeRatesPostProcessor from '@shared/post-processors/exchange-rates'
import { createMorphoVaultApyProcessor } from '@templates/morpho/processor'
import { createOTokenActivityProcessor } from '@templates/otoken/activity-processor/activity-processor'
import { processStatus } from '@templates/processor-status'
import { createOTokenWithdrawalsProcessor } from '@templates/withdrawals'
import { WOUSD_ADDRESS, addresses } from '@utils/addresses'
import { DEFAULT_FIELDS } from '@utils/batch-proccesor-fields'
import { initProcessorFromDump } from '@utils/dumps'

import { ousdCurveProcessor } from './ousd/processors/curve'
import { erc20s } from './ousd/processors/erc20s'
import { morphoMarketStatesProcessor } from './ousd/processors/morpho-market-states'
import { ousdStrategiesProcessor } from './ousd/processors/strategies/strategies'

export const processor = defineSquidProcessor({
  stateSchema: 'ousd-processor',
  processors: [
    ...ousdProcessors,
    createOTokenActivityProcessor({
      from: 11590995,
      otokenAddress: addresses.ousd.address,
      wotokenAddress: WOUSD_ADDRESS,
      vaultAddress: addresses.ousd.vault,
      cowSwap: false,
    }),
    ousdStrategiesProcessor,
    createOTokenWithdrawalsProcessor({
      name: 'OUSD',
      oTokenAddress: addresses.ousd.address,
      oTokenVaultAddress: addresses.ousd.vault,
      from: 24477020,
    }),
    ousdCurveProcessor,
    morphoMarketStatesProcessor,
    createMorphoVaultApyProcessor({
      from: 24_736_000, // ~7 days before 2026-04-01
    }),
    ...erc20s(),
  ],
  postProcessors: [exchangeRatesPostProcessor, processStatus('ousd')],
  validators: [],
  fields: DEFAULT_FIELDS,
})
export default processor

if (require.main === module) {
  initProcessorFromDump(processor).catch((error) => {
    throw error
  })
}
