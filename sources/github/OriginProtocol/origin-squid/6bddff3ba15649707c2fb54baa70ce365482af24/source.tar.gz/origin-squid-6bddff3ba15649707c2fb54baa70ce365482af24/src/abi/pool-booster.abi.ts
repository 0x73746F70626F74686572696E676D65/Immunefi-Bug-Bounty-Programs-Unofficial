export const ABI_JSON = [
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_bribeContractOS",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "_bribeContractOther",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "_osToken",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_split",
                "type": "uint256"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "BribeExecuted",
        "type": "event"
    },
    {
        "inputs": [],
        "name": "MIN_BRIBE_AMOUNT",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "bribe",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "bribeContractOS",
        "outputs": [
            {
                "internalType": "contract IBribe",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "bribeContractOther",
        "outputs": [
            {
                "internalType": "contract IBribe",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "osToken",
        "outputs": [
            {
                "internalType": "contract IERC20",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "split",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    }
] as const
