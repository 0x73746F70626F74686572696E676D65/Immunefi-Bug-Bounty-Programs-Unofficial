import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, IntColumn as IntColumn_, Index as Index_, DateTimeColumn as DateTimeColumn_, StringColumn as StringColumn_, BigIntColumn as BigIntColumn_, FloatColumn as FloatColumn_} from "@subsquid/typeorm-store"

@Entity_()
export class ArmDailyStat {
    constructor(props?: Partial<ArmDailyStat>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Index_()
    @IntColumn_({nullable: false})
    chainId!: number

    @Index_()
    @DateTimeColumn_({nullable: false})
    timestamp!: Date

    @Index_()
    @IntColumn_({nullable: false})
    blockNumber!: number

    @Index_()
    @StringColumn_({nullable: false})
    date!: string

    @Index_()
    @StringColumn_({nullable: false})
    address!: string

    @BigIntColumn_({nullable: false})
    assets0!: bigint

    @BigIntColumn_({nullable: false})
    assets1!: bigint

    @BigIntColumn_({nullable: false})
    outstandingAssets1!: bigint

    @BigIntColumn_({nullable: false})
    marketAssets!: bigint

    @BigIntColumn_({nullable: false})
    feesAccrued!: bigint

    @BigIntColumn_({nullable: false})
    totalAssets!: bigint

    @BigIntColumn_({nullable: false})
    totalAssetsCap!: bigint

    @BigIntColumn_({nullable: false})
    totalSupply!: bigint

    @BigIntColumn_({nullable: false})
    assetsPerShare!: bigint

    @BigIntColumn_({nullable: false})
    totalDeposits!: bigint

    @BigIntColumn_({nullable: false})
    totalWithdrawals!: bigint

    @BigIntColumn_({nullable: false})
    totalWithdrawalsClaimed!: bigint

    @FloatColumn_({nullable: false})
    apr!: number

    @FloatColumn_({nullable: false})
    apy!: number

    @BigIntColumn_({nullable: false})
    incentiveYield!: bigint

    @FloatColumn_({nullable: false})
    incentiveApr!: number

    @FloatColumn_({nullable: false})
    incentiveApy!: number

    @BigIntColumn_({nullable: false})
    yield!: bigint

    @BigIntColumn_({nullable: false})
    fees!: bigint

    @BigIntColumn_({nullable: false})
    cumulativeYield!: bigint

    @BigIntColumn_({nullable: false})
    cumulativeFees!: bigint

    @FloatColumn_({nullable: false})
    rateUSD!: number

    @FloatColumn_({nullable: false})
    rateETH!: number

    @FloatColumn_({nullable: false})
    rateNative!: number

    @FloatColumn_({nullable: false})
    rateAsset1!: number

    @StringColumn_({array: true, nullable: false})
    assets!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetSymbols!: (string)[]

    @IntColumn_({array: true, nullable: false})
    assetDecimals!: (number)[]

    @StringColumn_({array: true, nullable: false})
    assetBalances!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetTotals!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetRates!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetRatesLiquidity!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetRatesUSD!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetRatesETH!: (string)[]

    @StringColumn_({array: true, nullable: false})
    assetRatesNative!: (string)[]

    @StringColumn_({array: true, nullable: false})
    outstandingAssets!: (string)[]

    @BigIntColumn_({nullable: false})
    marketShares!: bigint

    @BigIntColumn_({nullable: false})
    marketPricePerShare!: bigint

    @StringColumn_({nullable: false})
    activeMarket!: string
}
