import { coingeckoProcessor } from 'mainnet/processors/coingecko'
import { merklProcessor } from 'mainnet/processors/merkl'
import { notionProcessor } from 'mainnet/processors/notion'
import { ognBuybacks } from 'mainnet/processors/ogn-buybacks'
import { originArmProcessors } from 'mainnet/processors/origin-arms'
import { protocolSqlSimpleProcessor } from 'mainnet/processors/protocol/protocol-sql-simple'
import 'tsconfig-paths/register'
import { mainnet } from 'viem/chains'

import { defineSquidProcessor } from '@originprotocol/squid-utils'
import * as exchangeRates from '@shared/post-processors/exchange-rates'
import { ccip } from '@templates/ccip'
import { createESAddressYieldProcessor, createESTracker } from '@templates/exponential-staking'
import { createFRRSProcessor } from '@templates/fixed-rate-rewards-source'
import { createGovernanceProcessor } from '@templates/governance'
import { createPoolsProcessor } from '@templates/pools/pools'
import { processStatus } from '@templates/processor-status'
import { createTransactionProcessor } from '@templates/transactions'
import {
  OGN_ADDRESS,
  OGN_GOVERNANCE_ADDRESS,
  OGN_REWARDS_SOURCE_ADDRESS,
  OGV_GOVERNANCE_ADDRESS,
  XOGN_ADDRESS,
} from '@utils/addresses'
import { FIELDS_WITH_RECEIPTS_INFO } from '@utils/batch-proccesor-fields'
import { initProcessorFromDump } from '@utils/dumps'
import { startToastVacuumMonitor } from '@utils/toast-vacuum'

import * as dailyStats from './mainnet/post-processors/ogn-daily-stats'
import * as curve from './mainnet/processors/curve'
import { erc20s } from './mainnet/processors/erc20s'
import * as mainnetExchangeRates from './mainnet/processors/exchange-rates'
import * as legacyStaking from './mainnet/processors/legacy-staking'
import { nativeBalanceProcessor } from './mainnet/processors/native'
import * as nativeStaking from './mainnet/processors/native-staking'

export const processor = defineSquidProcessor({
  stateSchema: 'mainnet-processor',
  processors: [
    mainnetExchangeRates,
    ognBuybacks,
    nativeStaking,
    nativeBalanceProcessor,
    legacyStaking,
    curve,
    ccip({ chainId: 1 }),
    ...erc20s(),
    createGovernanceProcessor({ from: 15491391, address: OGV_GOVERNANCE_ADDRESS }),
    createGovernanceProcessor({ from: 20117923, address: OGN_GOVERNANCE_ADDRESS }),
    createESTracker({
      from: 19919745,
      address: XOGN_ADDRESS,
      assetAddress: OGN_ADDRESS,
      rewardsAddress: '0x7609c88e5880e934dd3a75bcfef44e31b1badb8b',
      yieldType: 'fixed',
    }),
    createESAddressYieldProcessor({ from: 19919745, address: XOGN_ADDRESS }),
    createFRRSProcessor({ from: 19917521, address: OGN_REWARDS_SOURCE_ADDRESS }),
    coingeckoProcessor,
    ...originArmProcessors,
    // Merkl reward campaigns created by Origin, with targets resolved via the Merkl API.
    merklProcessor,
    // Defender Relayer for Lido ARM
    createTransactionProcessor({ from: 18744591, address: ['0x39878253374355dbcc15c86458f084fb6f2d6de7'] }),
    createPoolsProcessor(mainnet.id),
    notionProcessor,
  ],
  postProcessors: [exchangeRates, dailyStats, processStatus('mainnet'), protocolSqlSimpleProcessor],
  validators: [],
  fields: FIELDS_WITH_RECEIPTS_INFO,
})
export default processor

if (require.main === module) {
  startToastVacuumMonitor()
  initProcessorFromDump(processor).catch((error) => {
    throw error
  })
}
