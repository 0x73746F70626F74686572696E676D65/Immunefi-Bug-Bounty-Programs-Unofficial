export const ABI_JSON = [
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "address",
                        "name": "platformAddress",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "vaultAddress",
                        "type": "address"
                    }
                ],
                "internalType": "struct InitializableAbstractStrategy.BaseStrategyConfig",
                "name": "_baseConfig",
                "type": "tuple"
            },
            {
                "internalType": "address",
                "name": "_wethAddress",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "_beaconChainDepositContract",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "_beaconProofs",
                "type": "address"
            },
            {
                "internalType": "uint64",
                "name": "_beaconGenesisTimestamp",
                "type": "uint64"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "inputs": [],
        "name": "InvalidFirstDepositAmount",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "NoFirstDeposit",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "NotRegistrator",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "NotRegistratorOrGovernor",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "UnsupportedAsset",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "UnsupportedFunction",
        "type": "error"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "blockRoot",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "ethBalance",
                "type": "uint256"
            }
        ],
        "name": "BalancesSnapped",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "uint64",
                "name": "timestamp",
                "type": "uint64"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "totalDepositsWei",
                "type": "uint256"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "totalValidatorBalance",
                "type": "uint256"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "ethBalance",
                "type": "uint256"
            }
        ],
        "name": "BalancesVerified",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "_pToken",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "_amount",
                "type": "uint256"
            }
        ],
        "name": "Deposit",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "pendingDepositRoot",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amountWei",
                "type": "uint256"
            }
        ],
        "name": "DepositVerified",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "pubKeyHash",
                "type": "bytes32"
            },
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "pendingDepositRoot",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "bytes",
                "name": "pubKey",
                "type": "bytes"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amountWei",
                "type": "uint256"
            }
        ],
        "name": "ETHStaked",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [],
        "name": "FirstDepositReset",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "previousGovernor",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "newGovernor",
                "type": "address"
            }
        ],
        "name": "GovernorshipTransferred",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "_oldHarvesterAddress",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "_newHarvesterAddress",
                "type": "address"
            }
        ],
        "name": "HarvesterAddressesUpdated",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amountWei",
                "type": "uint256"
            }
        ],
        "name": "InitialDepositAmountChanged",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "_pToken",
                "type": "address"
            }
        ],
        "name": "PTokenAdded",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "_pToken",
                "type": "address"
            }
        ],
        "name": "PTokenRemoved",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "account",
                "type": "address"
            }
        ],
        "name": "Paused",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "previousGovernor",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "newGovernor",
                "type": "address"
            }
        ],
        "name": "PendingGovernorshipTransfer",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "newAddress",
                "type": "address"
            }
        ],
        "name": "RegistratorChanged",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address[]",
                "name": "_oldAddresses",
                "type": "address[]"
            },
            {
                "indexed": false,
                "internalType": "address[]",
                "name": "_newAddresses",
                "type": "address[]"
            }
        ],
        "name": "RewardTokenAddressesUpdated",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "recipient",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "rewardToken",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "RewardTokenCollected",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "account",
                "type": "address"
            }
        ],
        "name": "Unpaused",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "pubKeyHash",
                "type": "bytes32"
            }
        ],
        "name": "ValidatorInvalid",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "pubKeyHash",
                "type": "bytes32"
            },
            {
                "indexed": true,
                "internalType": "uint40",
                "name": "validatorIndex",
                "type": "uint40"
            }
        ],
        "name": "ValidatorVerified",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "pubKeyHash",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amountWei",
                "type": "uint256"
            }
        ],
        "name": "ValidatorWithdraw",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "_pToken",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "_amount",
                "type": "uint256"
            }
        ],
        "name": "Withdrawal",
        "type": "event"
    },
    {
        "inputs": [],
        "name": "BEACON_PROOFS",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "SNAP_BALANCES_DELAY",
        "outputs": [
            {
                "internalType": "uint64",
                "name": "",
                "type": "uint64"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "name": "assetToPToken",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            }
        ],
        "name": "checkBalance",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "balance",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "claimGovernance",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "collectRewardTokens",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_amount",
                "type": "uint256"
            }
        ],
        "name": "deposit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "depositAll",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "depositList",
        "outputs": [
            {
                "internalType": "bytes32",
                "name": "",
                "type": "bytes32"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "depositListLength",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "depositedWethAccountedFor",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes32",
                "name": "",
                "type": "bytes32"
            }
        ],
        "name": "deposits",
        "outputs": [
            {
                "internalType": "bytes32",
                "name": "pubKeyHash",
                "type": "bytes32"
            },
            {
                "internalType": "uint64",
                "name": "amountGwei",
                "type": "uint64"
            },
            {
                "internalType": "uint64",
                "name": "slot",
                "type": "uint64"
            },
            {
                "internalType": "uint32",
                "name": "depositIndex",
                "type": "uint32"
            },
            {
                "internalType": "enum CompoundingValidatorStorage.DepositStatus",
                "name": "status",
                "type": "uint8"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "firstDeposit",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getRewardTokenAddresses",
        "outputs": [
            {
                "internalType": "address[]",
                "name": "",
                "type": "address[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "governor",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "harvesterAddress",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "initialDepositAmountWei",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address[]",
                "name": "_rewardTokenAddresses",
                "type": "address[]"
            },
            {
                "internalType": "address[]",
                "name": "_assets",
                "type": "address[]"
            },
            {
                "internalType": "address[]",
                "name": "_pTokens",
                "type": "address[]"
            },
            {
                "internalType": "uint256",
                "name": "_initialDepositAmountWei",
                "type": "uint256"
            }
        ],
        "name": "initialize",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "isGovernor",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "lastVerifiedEthBalance",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "pause",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "paused",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "platformAddress",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "removePToken",
        "outputs": [],
        "stateMutability": "pure",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "resetFirstDeposit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "rewardTokenAddresses",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "safeApproveAllTokens",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_harvesterAddress",
                "type": "address"
            }
        ],
        "name": "setHarvesterAddress",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "_initialDepositAmountWei",
                "type": "uint256"
            }
        ],
        "name": "setInitialDepositAmount",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "name": "setPTokenAddress",
        "outputs": [],
        "stateMutability": "pure",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_address",
                "type": "address"
            }
        ],
        "name": "setRegistrator",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address[]",
                "name": "_rewardTokenAddresses",
                "type": "address[]"
            }
        ],
        "name": "setRewardTokenAddresses",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "snapBalances",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "snappedBalance",
        "outputs": [
            {
                "internalType": "bytes32",
                "name": "blockRoot",
                "type": "bytes32"
            },
            {
                "internalType": "uint64",
                "name": "timestamp",
                "type": "uint64"
            },
            {
                "internalType": "uint128",
                "name": "ethBalance",
                "type": "uint128"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "bytes",
                        "name": "pubkey",
                        "type": "bytes"
                    },
                    {
                        "internalType": "bytes",
                        "name": "signature",
                        "type": "bytes"
                    },
                    {
                        "internalType": "bytes32",
                        "name": "depositDataRoot",
                        "type": "bytes32"
                    }
                ],
                "internalType": "struct CompoundingStakingStrategy.ValidatorStakeData",
                "name": "validatorStakeData",
                "type": "tuple"
            },
            {
                "internalType": "uint64",
                "name": "depositAmountGwei",
                "type": "uint64"
            }
        ],
        "name": "stakeEth",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            }
        ],
        "name": "supportsAsset",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_newGovernor",
                "type": "address"
            }
        ],
        "name": "transferGovernance",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_amount",
                "type": "uint256"
            }
        ],
        "name": "transferToken",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "unPause",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes32",
                "name": "",
                "type": "bytes32"
            }
        ],
        "name": "validator",
        "outputs": [
            {
                "internalType": "enum CompoundingValidatorStorage.ValidatorState",
                "name": "state",
                "type": "uint8"
            },
            {
                "internalType": "uint40",
                "name": "index",
                "type": "uint40"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "validatorRegistrator",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes",
                "name": "publicKey",
                "type": "bytes"
            },
            {
                "internalType": "uint64",
                "name": "amountGwei",
                "type": "uint64"
            }
        ],
        "name": "validatorWithdrawal",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "vaultAddress",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "verifiedValidators",
        "outputs": [
            {
                "internalType": "bytes32",
                "name": "",
                "type": "bytes32"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "verifiedValidatorsLength",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "bytes32",
                        "name": "balancesContainerRoot",
                        "type": "bytes32"
                    },
                    {
                        "internalType": "bytes",
                        "name": "balancesContainerProof",
                        "type": "bytes"
                    },
                    {
                        "internalType": "bytes32[]",
                        "name": "validatorBalanceLeaves",
                        "type": "bytes32[]"
                    },
                    {
                        "internalType": "bytes[]",
                        "name": "validatorBalanceProofs",
                        "type": "bytes[]"
                    }
                ],
                "internalType": "struct CompoundingStakingStrategy.BalanceProofs",
                "name": "balanceProofs",
                "type": "tuple"
            },
            {
                "components": [
                    {
                        "internalType": "bytes32",
                        "name": "pendingDepositContainerRoot",
                        "type": "bytes32"
                    },
                    {
                        "internalType": "bytes",
                        "name": "pendingDepositContainerProof",
                        "type": "bytes"
                    },
                    {
                        "internalType": "uint32[]",
                        "name": "pendingDepositIndexes",
                        "type": "uint32[]"
                    },
                    {
                        "internalType": "bytes[]",
                        "name": "pendingDepositProofs",
                        "type": "bytes[]"
                    }
                ],
                "internalType": "struct CompoundingStakingStrategy.PendingDepositProofs",
                "name": "pendingDepositProofs",
                "type": "tuple"
            }
        ],
        "name": "verifyBalances",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes32",
                "name": "pendingDepositRoot",
                "type": "bytes32"
            },
            {
                "internalType": "uint64",
                "name": "depositProcessedSlot",
                "type": "uint64"
            },
            {
                "components": [
                    {
                        "internalType": "uint64",
                        "name": "slot",
                        "type": "uint64"
                    },
                    {
                        "internalType": "bytes",
                        "name": "proof",
                        "type": "bytes"
                    }
                ],
                "internalType": "struct CompoundingStakingStrategy.FirstPendingDepositSlotProofData",
                "name": "firstPendingDeposit",
                "type": "tuple"
            },
            {
                "components": [
                    {
                        "internalType": "uint64",
                        "name": "withdrawableEpoch",
                        "type": "uint64"
                    },
                    {
                        "internalType": "bytes",
                        "name": "withdrawableEpochProof",
                        "type": "bytes"
                    }
                ],
                "internalType": "struct CompoundingStakingStrategy.StrategyValidatorProofData",
                "name": "strategyValidatorData",
                "type": "tuple"
            }
        ],
        "name": "verifyDeposit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "nextBlockTimestamp",
                "type": "uint64"
            },
            {
                "internalType": "uint40",
                "name": "validatorIndex",
                "type": "uint40"
            },
            {
                "internalType": "bytes32",
                "name": "pubKeyHash",
                "type": "bytes32"
            },
            {
                "internalType": "bytes32",
                "name": "withdrawalCredentials",
                "type": "bytes32"
            },
            {
                "internalType": "bytes",
                "name": "validatorPubKeyProof",
                "type": "bytes"
            }
        ],
        "name": "verifyValidator",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_recipient",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "_asset",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_amount",
                "type": "uint256"
            }
        ],
        "name": "withdraw",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "withdrawAll",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "stateMutability": "payable",
        "type": "receive"
    }
] as const
