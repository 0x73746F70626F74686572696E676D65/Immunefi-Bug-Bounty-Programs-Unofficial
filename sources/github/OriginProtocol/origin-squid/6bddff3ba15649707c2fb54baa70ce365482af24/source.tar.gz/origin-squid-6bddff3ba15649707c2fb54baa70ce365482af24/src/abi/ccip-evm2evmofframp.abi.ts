export const ABI_JSON = [
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "address",
                        "name": "commitStore",
                        "type": "address"
                    },
                    {
                        "internalType": "uint64",
                        "name": "chainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "uint64",
                        "name": "sourceChainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "address",
                        "name": "onRamp",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "prevOffRamp",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "armProxy",
                        "type": "address"
                    }
                ],
                "internalType": "struct EVM2EVMOffRamp.StaticConfig",
                "name": "staticConfig",
                "type": "tuple"
            },
            {
                "internalType": "contract IERC20[]",
                "name": "sourceTokens",
                "type": "address[]"
            },
            {
                "internalType": "contract IPool[]",
                "name": "pools",
                "type": "address[]"
            },
            {
                "components": [
                    {
                        "internalType": "bool",
                        "name": "isEnabled",
                        "type": "bool"
                    },
                    {
                        "internalType": "uint128",
                        "name": "capacity",
                        "type": "uint128"
                    },
                    {
                        "internalType": "uint128",
                        "name": "rate",
                        "type": "uint128"
                    }
                ],
                "internalType": "struct RateLimiter.Config",
                "name": "rateLimiterConfig",
                "type": "tuple"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "capacity",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "requested",
                "type": "uint256"
            }
        ],
        "name": "AggregateValueMaxCapacityExceeded",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "minWaitInSeconds",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "available",
                "type": "uint256"
            }
        ],
        "name": "AggregateValueRateLimitReached",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            }
        ],
        "name": "AlreadyAttempted",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            }
        ],
        "name": "AlreadyExecuted",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "BadARMSignal",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "BucketOverfilled",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "CanOnlySelfCall",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "CommitStoreAlreadyInUse",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "bytes32",
                "name": "expected",
                "type": "bytes32"
            },
            {
                "internalType": "bytes32",
                "name": "actual",
                "type": "bytes32"
            }
        ],
        "name": "ConfigDigestMismatch",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "EmptyReport",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "bytes",
                "name": "error",
                "type": "bytes"
            }
        ],
        "name": "ExecutionError",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "expected",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "actual",
                "type": "uint256"
            }
        ],
        "name": "ForkedChain",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "message",
                "type": "string"
            }
        ],
        "name": "InvalidConfig",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "index",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "newLimit",
                "type": "uint256"
            }
        ],
        "name": "InvalidManualExecutionGasLimit",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "InvalidMessageId",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            },
            {
                "internalType": "enum Internal.MessageExecutionState",
                "name": "newState",
                "type": "uint8"
            }
        ],
        "name": "InvalidNewState",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sourceChainSelector",
                "type": "uint64"
            }
        ],
        "name": "InvalidSourceChain",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "InvalidTokenPoolConfig",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "ManualExecutionGasLimitMismatch",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "ManualExecutionNotYetEnabled",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "maxSize",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "actualSize",
                "type": "uint256"
            }
        ],
        "name": "MessageTooLarge",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "OnlyCallableByAdminOrOwner",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "OracleCannotBeZeroAddress",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "PoolAlreadyAdded",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "PoolDoesNotExist",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "token",
                "type": "address"
            }
        ],
        "name": "PriceNotFoundForToken",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "bytes",
                "name": "error",
                "type": "bytes"
            }
        ],
        "name": "ReceiverError",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "RootNotCommitted",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            }
        ],
        "name": "TokenDataMismatch",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "bytes",
                "name": "error",
                "type": "bytes"
            }
        ],
        "name": "TokenHandlingError",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "capacity",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "requested",
                "type": "uint256"
            },
            {
                "internalType": "address",
                "name": "tokenAddress",
                "type": "address"
            }
        ],
        "name": "TokenMaxCapacityExceeded",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "TokenPoolMismatch",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "minWaitInSeconds",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "available",
                "type": "uint256"
            },
            {
                "internalType": "address",
                "name": "tokenAddress",
                "type": "address"
            }
        ],
        "name": "TokenRateLimitReached",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "UnauthorizedTransmitter",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "UnexpectedTokenData",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            }
        ],
        "name": "UnsupportedNumberOfTokens",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "contract IERC20",
                "name": "token",
                "type": "address"
            }
        ],
        "name": "UnsupportedToken",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "expected",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "actual",
                "type": "uint256"
            }
        ],
        "name": "WrongMessageLength",
        "type": "error"
    },
    {
        "inputs": [],
        "name": "ZeroAddressNotAllowed",
        "type": "error"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "newAdmin",
                "type": "address"
            }
        ],
        "name": "AdminSet",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "address",
                        "name": "commitStore",
                        "type": "address"
                    },
                    {
                        "internalType": "uint64",
                        "name": "chainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "uint64",
                        "name": "sourceChainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "address",
                        "name": "onRamp",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "prevOffRamp",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "armProxy",
                        "type": "address"
                    }
                ],
                "indexed": false,
                "internalType": "struct EVM2EVMOffRamp.StaticConfig",
                "name": "staticConfig",
                "type": "tuple"
            },
            {
                "components": [
                    {
                        "internalType": "uint32",
                        "name": "permissionLessExecutionThresholdSeconds",
                        "type": "uint32"
                    },
                    {
                        "internalType": "address",
                        "name": "router",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "priceRegistry",
                        "type": "address"
                    },
                    {
                        "internalType": "uint16",
                        "name": "maxNumberOfTokensPerMsg",
                        "type": "uint16"
                    },
                    {
                        "internalType": "uint32",
                        "name": "maxDataBytes",
                        "type": "uint32"
                    },
                    {
                        "internalType": "uint32",
                        "name": "maxPoolReleaseOrMintGas",
                        "type": "uint32"
                    }
                ],
                "indexed": false,
                "internalType": "struct EVM2EVMOffRamp.DynamicConfig",
                "name": "dynamicConfig",
                "type": "tuple"
            }
        ],
        "name": "ConfigSet",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "uint32",
                "name": "previousConfigBlockNumber",
                "type": "uint32"
            },
            {
                "indexed": false,
                "internalType": "bytes32",
                "name": "configDigest",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "uint64",
                "name": "configCount",
                "type": "uint64"
            },
            {
                "indexed": false,
                "internalType": "address[]",
                "name": "signers",
                "type": "address[]"
            },
            {
                "indexed": false,
                "internalType": "address[]",
                "name": "transmitters",
                "type": "address[]"
            },
            {
                "indexed": false,
                "internalType": "uint8",
                "name": "f",
                "type": "uint8"
            },
            {
                "indexed": false,
                "internalType": "bytes",
                "name": "onchainConfig",
                "type": "bytes"
            },
            {
                "indexed": false,
                "internalType": "uint64",
                "name": "offchainConfigVersion",
                "type": "uint64"
            },
            {
                "indexed": false,
                "internalType": "bytes",
                "name": "offchainConfig",
                "type": "bytes"
            }
        ],
        "name": "ConfigSet",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            },
            {
                "indexed": true,
                "internalType": "bytes32",
                "name": "messageId",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "enum Internal.MessageExecutionState",
                "name": "state",
                "type": "uint8"
            },
            {
                "indexed": false,
                "internalType": "bytes",
                "name": "returnData",
                "type": "bytes"
            }
        ],
        "name": "ExecutionStateChanged",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "from",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "to",
                "type": "address"
            }
        ],
        "name": "OwnershipTransferRequested",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "from",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "to",
                "type": "address"
            }
        ],
        "name": "OwnershipTransferred",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "token",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "pool",
                "type": "address"
            }
        ],
        "name": "PoolAdded",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "address",
                "name": "token",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "address",
                "name": "pool",
                "type": "address"
            }
        ],
        "name": "PoolRemoved",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "uint64",
                "name": "nonce",
                "type": "uint64"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "sender",
                "type": "address"
            }
        ],
        "name": "SkippedIncorrectNonce",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "uint64",
                "name": "nonce",
                "type": "uint64"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "sender",
                "type": "address"
            }
        ],
        "name": "SkippedSenderWithPreviousRampMessageInflight",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "bytes32",
                "name": "configDigest",
                "type": "bytes32"
            },
            {
                "indexed": false,
                "internalType": "uint32",
                "name": "epoch",
                "type": "uint32"
            }
        ],
        "name": "Transmitted",
        "type": "event"
    },
    {
        "inputs": [],
        "name": "acceptOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "address",
                        "name": "token",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "pool",
                        "type": "address"
                    }
                ],
                "internalType": "struct Internal.PoolUpdate[]",
                "name": "removes",
                "type": "tuple[]"
            },
            {
                "components": [
                    {
                        "internalType": "address",
                        "name": "token",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "pool",
                        "type": "address"
                    }
                ],
                "internalType": "struct Internal.PoolUpdate[]",
                "name": "adds",
                "type": "tuple[]"
            }
        ],
        "name": "applyPoolUpdates",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "bytes32",
                        "name": "messageId",
                        "type": "bytes32"
                    },
                    {
                        "internalType": "uint64",
                        "name": "sourceChainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "bytes",
                        "name": "sender",
                        "type": "bytes"
                    },
                    {
                        "internalType": "bytes",
                        "name": "data",
                        "type": "bytes"
                    },
                    {
                        "components": [
                            {
                                "internalType": "address",
                                "name": "token",
                                "type": "address"
                            },
                            {
                                "internalType": "uint256",
                                "name": "amount",
                                "type": "uint256"
                            }
                        ],
                        "internalType": "struct Client.EVMTokenAmount[]",
                        "name": "destTokenAmounts",
                        "type": "tuple[]"
                    }
                ],
                "internalType": "struct Client.Any2EVMMessage",
                "name": "",
                "type": "tuple"
            }
        ],
        "name": "ccipReceive",
        "outputs": [],
        "stateMutability": "pure",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "currentRateLimiterState",
        "outputs": [
            {
                "components": [
                    {
                        "internalType": "uint128",
                        "name": "tokens",
                        "type": "uint128"
                    },
                    {
                        "internalType": "uint32",
                        "name": "lastUpdated",
                        "type": "uint32"
                    },
                    {
                        "internalType": "bool",
                        "name": "isEnabled",
                        "type": "bool"
                    },
                    {
                        "internalType": "uint128",
                        "name": "capacity",
                        "type": "uint128"
                    },
                    {
                        "internalType": "uint128",
                        "name": "rate",
                        "type": "uint128"
                    }
                ],
                "internalType": "struct RateLimiter.TokenBucket",
                "name": "",
                "type": "tuple"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "uint64",
                        "name": "sourceChainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "address",
                        "name": "sender",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "receiver",
                        "type": "address"
                    },
                    {
                        "internalType": "uint64",
                        "name": "sequenceNumber",
                        "type": "uint64"
                    },
                    {
                        "internalType": "uint256",
                        "name": "gasLimit",
                        "type": "uint256"
                    },
                    {
                        "internalType": "bool",
                        "name": "strict",
                        "type": "bool"
                    },
                    {
                        "internalType": "uint64",
                        "name": "nonce",
                        "type": "uint64"
                    },
                    {
                        "internalType": "address",
                        "name": "feeToken",
                        "type": "address"
                    },
                    {
                        "internalType": "uint256",
                        "name": "feeTokenAmount",
                        "type": "uint256"
                    },
                    {
                        "internalType": "bytes",
                        "name": "data",
                        "type": "bytes"
                    },
                    {
                        "components": [
                            {
                                "internalType": "address",
                                "name": "token",
                                "type": "address"
                            },
                            {
                                "internalType": "uint256",
                                "name": "amount",
                                "type": "uint256"
                            }
                        ],
                        "internalType": "struct Client.EVMTokenAmount[]",
                        "name": "tokenAmounts",
                        "type": "tuple[]"
                    },
                    {
                        "internalType": "bytes[]",
                        "name": "sourceTokenData",
                        "type": "bytes[]"
                    },
                    {
                        "internalType": "bytes32",
                        "name": "messageId",
                        "type": "bytes32"
                    }
                ],
                "internalType": "struct Internal.EVM2EVMMessage",
                "name": "message",
                "type": "tuple"
            },
            {
                "internalType": "bytes[]",
                "name": "offchainTokenData",
                "type": "bytes[]"
            }
        ],
        "name": "executeSingleMessage",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "contract IERC20",
                "name": "sourceToken",
                "type": "address"
            }
        ],
        "name": "getDestinationToken",
        "outputs": [
            {
                "internalType": "contract IERC20",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getDestinationTokens",
        "outputs": [
            {
                "internalType": "contract IERC20[]",
                "name": "destTokens",
                "type": "address[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getDynamicConfig",
        "outputs": [
            {
                "components": [
                    {
                        "internalType": "uint32",
                        "name": "permissionLessExecutionThresholdSeconds",
                        "type": "uint32"
                    },
                    {
                        "internalType": "address",
                        "name": "router",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "priceRegistry",
                        "type": "address"
                    },
                    {
                        "internalType": "uint16",
                        "name": "maxNumberOfTokensPerMsg",
                        "type": "uint16"
                    },
                    {
                        "internalType": "uint32",
                        "name": "maxDataBytes",
                        "type": "uint32"
                    },
                    {
                        "internalType": "uint32",
                        "name": "maxPoolReleaseOrMintGas",
                        "type": "uint32"
                    }
                ],
                "internalType": "struct EVM2EVMOffRamp.DynamicConfig",
                "name": "",
                "type": "tuple"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint64",
                "name": "sequenceNumber",
                "type": "uint64"
            }
        ],
        "name": "getExecutionState",
        "outputs": [
            {
                "internalType": "enum Internal.MessageExecutionState",
                "name": "",
                "type": "uint8"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "contract IERC20",
                "name": "destToken",
                "type": "address"
            }
        ],
        "name": "getPoolByDestToken",
        "outputs": [
            {
                "internalType": "contract IPool",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "contract IERC20",
                "name": "sourceToken",
                "type": "address"
            }
        ],
        "name": "getPoolBySourceToken",
        "outputs": [
            {
                "internalType": "contract IPool",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "sender",
                "type": "address"
            }
        ],
        "name": "getSenderNonce",
        "outputs": [
            {
                "internalType": "uint64",
                "name": "nonce",
                "type": "uint64"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getStaticConfig",
        "outputs": [
            {
                "components": [
                    {
                        "internalType": "address",
                        "name": "commitStore",
                        "type": "address"
                    },
                    {
                        "internalType": "uint64",
                        "name": "chainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "uint64",
                        "name": "sourceChainSelector",
                        "type": "uint64"
                    },
                    {
                        "internalType": "address",
                        "name": "onRamp",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "prevOffRamp",
                        "type": "address"
                    },
                    {
                        "internalType": "address",
                        "name": "armProxy",
                        "type": "address"
                    }
                ],
                "internalType": "struct EVM2EVMOffRamp.StaticConfig",
                "name": "",
                "type": "tuple"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getSupportedTokens",
        "outputs": [
            {
                "internalType": "contract IERC20[]",
                "name": "sourceTokens",
                "type": "address[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getTokenLimitAdmin",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getTransmitters",
        "outputs": [
            {
                "internalType": "address[]",
                "name": "",
                "type": "address[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "latestConfigDetails",
        "outputs": [
            {
                "internalType": "uint32",
                "name": "configCount",
                "type": "uint32"
            },
            {
                "internalType": "uint32",
                "name": "blockNumber",
                "type": "uint32"
            },
            {
                "internalType": "bytes32",
                "name": "configDigest",
                "type": "bytes32"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "latestConfigDigestAndEpoch",
        "outputs": [
            {
                "internalType": "bool",
                "name": "scanLogs",
                "type": "bool"
            },
            {
                "internalType": "bytes32",
                "name": "configDigest",
                "type": "bytes32"
            },
            {
                "internalType": "uint32",
                "name": "epoch",
                "type": "uint32"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "components": [
                            {
                                "internalType": "uint64",
                                "name": "sourceChainSelector",
                                "type": "uint64"
                            },
                            {
                                "internalType": "address",
                                "name": "sender",
                                "type": "address"
                            },
                            {
                                "internalType": "address",
                                "name": "receiver",
                                "type": "address"
                            },
                            {
                                "internalType": "uint64",
                                "name": "sequenceNumber",
                                "type": "uint64"
                            },
                            {
                                "internalType": "uint256",
                                "name": "gasLimit",
                                "type": "uint256"
                            },
                            {
                                "internalType": "bool",
                                "name": "strict",
                                "type": "bool"
                            },
                            {
                                "internalType": "uint64",
                                "name": "nonce",
                                "type": "uint64"
                            },
                            {
                                "internalType": "address",
                                "name": "feeToken",
                                "type": "address"
                            },
                            {
                                "internalType": "uint256",
                                "name": "feeTokenAmount",
                                "type": "uint256"
                            },
                            {
                                "internalType": "bytes",
                                "name": "data",
                                "type": "bytes"
                            },
                            {
                                "components": [
                                    {
                                        "internalType": "address",
                                        "name": "token",
                                        "type": "address"
                                    },
                                    {
                                        "internalType": "uint256",
                                        "name": "amount",
                                        "type": "uint256"
                                    }
                                ],
                                "internalType": "struct Client.EVMTokenAmount[]",
                                "name": "tokenAmounts",
                                "type": "tuple[]"
                            },
                            {
                                "internalType": "bytes[]",
                                "name": "sourceTokenData",
                                "type": "bytes[]"
                            },
                            {
                                "internalType": "bytes32",
                                "name": "messageId",
                                "type": "bytes32"
                            }
                        ],
                        "internalType": "struct Internal.EVM2EVMMessage[]",
                        "name": "messages",
                        "type": "tuple[]"
                    },
                    {
                        "internalType": "bytes[][]",
                        "name": "offchainTokenData",
                        "type": "bytes[][]"
                    },
                    {
                        "internalType": "bytes32[]",
                        "name": "proofs",
                        "type": "bytes32[]"
                    },
                    {
                        "internalType": "uint256",
                        "name": "proofFlagBits",
                        "type": "uint256"
                    }
                ],
                "internalType": "struct Internal.ExecutionReport",
                "name": "report",
                "type": "tuple"
            },
            {
                "internalType": "uint256[]",
                "name": "gasLimitOverrides",
                "type": "uint256[]"
            }
        ],
        "name": "manuallyExecute",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "newAdmin",
                "type": "address"
            }
        ],
        "name": "setAdmin",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address[]",
                "name": "signers",
                "type": "address[]"
            },
            {
                "internalType": "address[]",
                "name": "transmitters",
                "type": "address[]"
            },
            {
                "internalType": "uint8",
                "name": "f",
                "type": "uint8"
            },
            {
                "internalType": "bytes",
                "name": "onchainConfig",
                "type": "bytes"
            },
            {
                "internalType": "uint64",
                "name": "offchainConfigVersion",
                "type": "uint64"
            },
            {
                "internalType": "bytes",
                "name": "offchainConfig",
                "type": "bytes"
            }
        ],
        "name": "setOCR2Config",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "components": [
                    {
                        "internalType": "bool",
                        "name": "isEnabled",
                        "type": "bool"
                    },
                    {
                        "internalType": "uint128",
                        "name": "capacity",
                        "type": "uint128"
                    },
                    {
                        "internalType": "uint128",
                        "name": "rate",
                        "type": "uint128"
                    }
                ],
                "internalType": "struct RateLimiter.Config",
                "name": "config",
                "type": "tuple"
            }
        ],
        "name": "setRateLimiterConfig",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "to",
                "type": "address"
            }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes32[3]",
                "name": "reportContext",
                "type": "bytes32[3]"
            },
            {
                "internalType": "bytes",
                "name": "report",
                "type": "bytes"
            },
            {
                "internalType": "bytes32[]",
                "name": "rs",
                "type": "bytes32[]"
            },
            {
                "internalType": "bytes32[]",
                "name": "ss",
                "type": "bytes32[]"
            },
            {
                "internalType": "bytes32",
                "name": "",
                "type": "bytes32"
            }
        ],
        "name": "transmit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "typeAndVersion",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    }
] as const
