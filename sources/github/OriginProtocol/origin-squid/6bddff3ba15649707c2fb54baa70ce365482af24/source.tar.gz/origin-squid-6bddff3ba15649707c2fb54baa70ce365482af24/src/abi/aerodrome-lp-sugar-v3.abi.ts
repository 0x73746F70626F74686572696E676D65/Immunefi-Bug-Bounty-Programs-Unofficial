export const ABI_JSON = [
    {
        "stateMutability": "nonpayable",
        "type": "constructor",
        "inputs": [
            {
                "name": "_voter",
                "type": "address"
            },
            {
                "name": "_registry",
                "type": "address"
            },
            {
                "name": "_convertor",
                "type": "address"
            },
            {
                "name": "_slipstream_helper",
                "type": "address"
            }
        ],
        "outputs": []
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "forSwaps",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "type",
                        "type": "int24"
                    },
                    {
                        "name": "token0",
                        "type": "address"
                    },
                    {
                        "name": "token1",
                        "type": "address"
                    },
                    {
                        "name": "factory",
                        "type": "address"
                    },
                    {
                        "name": "pool_fee",
                        "type": "uint256"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "tokens",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            },
            {
                "name": "_account",
                "type": "address"
            },
            {
                "name": "_addresses",
                "type": "address[]"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "token_address",
                        "type": "address"
                    },
                    {
                        "name": "symbol",
                        "type": "string"
                    },
                    {
                        "name": "decimals",
                        "type": "uint8"
                    },
                    {
                        "name": "account_balance",
                        "type": "uint256"
                    },
                    {
                        "name": "listed",
                        "type": "bool"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "all",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "symbol",
                        "type": "string"
                    },
                    {
                        "name": "decimals",
                        "type": "uint8"
                    },
                    {
                        "name": "liquidity",
                        "type": "uint256"
                    },
                    {
                        "name": "type",
                        "type": "int24"
                    },
                    {
                        "name": "tick",
                        "type": "int24"
                    },
                    {
                        "name": "sqrt_ratio",
                        "type": "uint160"
                    },
                    {
                        "name": "token0",
                        "type": "address"
                    },
                    {
                        "name": "reserve0",
                        "type": "uint256"
                    },
                    {
                        "name": "staked0",
                        "type": "uint256"
                    },
                    {
                        "name": "token1",
                        "type": "address"
                    },
                    {
                        "name": "reserve1",
                        "type": "uint256"
                    },
                    {
                        "name": "staked1",
                        "type": "uint256"
                    },
                    {
                        "name": "gauge",
                        "type": "address"
                    },
                    {
                        "name": "gauge_liquidity",
                        "type": "uint256"
                    },
                    {
                        "name": "gauge_alive",
                        "type": "bool"
                    },
                    {
                        "name": "fee",
                        "type": "address"
                    },
                    {
                        "name": "bribe",
                        "type": "address"
                    },
                    {
                        "name": "factory",
                        "type": "address"
                    },
                    {
                        "name": "emissions",
                        "type": "uint256"
                    },
                    {
                        "name": "emissions_token",
                        "type": "address"
                    },
                    {
                        "name": "pool_fee",
                        "type": "uint256"
                    },
                    {
                        "name": "unstaked_fee",
                        "type": "uint256"
                    },
                    {
                        "name": "token0_fees",
                        "type": "uint256"
                    },
                    {
                        "name": "token1_fees",
                        "type": "uint256"
                    },
                    {
                        "name": "nfpm",
                        "type": "address"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "byIndex",
        "inputs": [
            {
                "name": "_index",
                "type": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple",
                "components": [
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "symbol",
                        "type": "string"
                    },
                    {
                        "name": "decimals",
                        "type": "uint8"
                    },
                    {
                        "name": "liquidity",
                        "type": "uint256"
                    },
                    {
                        "name": "type",
                        "type": "int24"
                    },
                    {
                        "name": "tick",
                        "type": "int24"
                    },
                    {
                        "name": "sqrt_ratio",
                        "type": "uint160"
                    },
                    {
                        "name": "token0",
                        "type": "address"
                    },
                    {
                        "name": "reserve0",
                        "type": "uint256"
                    },
                    {
                        "name": "staked0",
                        "type": "uint256"
                    },
                    {
                        "name": "token1",
                        "type": "address"
                    },
                    {
                        "name": "reserve1",
                        "type": "uint256"
                    },
                    {
                        "name": "staked1",
                        "type": "uint256"
                    },
                    {
                        "name": "gauge",
                        "type": "address"
                    },
                    {
                        "name": "gauge_liquidity",
                        "type": "uint256"
                    },
                    {
                        "name": "gauge_alive",
                        "type": "bool"
                    },
                    {
                        "name": "fee",
                        "type": "address"
                    },
                    {
                        "name": "bribe",
                        "type": "address"
                    },
                    {
                        "name": "factory",
                        "type": "address"
                    },
                    {
                        "name": "emissions",
                        "type": "uint256"
                    },
                    {
                        "name": "emissions_token",
                        "type": "address"
                    },
                    {
                        "name": "pool_fee",
                        "type": "uint256"
                    },
                    {
                        "name": "unstaked_fee",
                        "type": "uint256"
                    },
                    {
                        "name": "token0_fees",
                        "type": "uint256"
                    },
                    {
                        "name": "token1_fees",
                        "type": "uint256"
                    },
                    {
                        "name": "nfpm",
                        "type": "address"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "positions",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            },
            {
                "name": "_account",
                "type": "address"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "id",
                        "type": "uint256"
                    },
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "liquidity",
                        "type": "uint256"
                    },
                    {
                        "name": "staked",
                        "type": "uint256"
                    },
                    {
                        "name": "amount0",
                        "type": "uint256"
                    },
                    {
                        "name": "amount1",
                        "type": "uint256"
                    },
                    {
                        "name": "staked0",
                        "type": "uint256"
                    },
                    {
                        "name": "staked1",
                        "type": "uint256"
                    },
                    {
                        "name": "unstaked_earned0",
                        "type": "uint256"
                    },
                    {
                        "name": "unstaked_earned1",
                        "type": "uint256"
                    },
                    {
                        "name": "emissions_earned",
                        "type": "uint256"
                    },
                    {
                        "name": "tick_lower",
                        "type": "int24"
                    },
                    {
                        "name": "tick_upper",
                        "type": "int24"
                    },
                    {
                        "name": "sqrt_ratio_lower",
                        "type": "uint160"
                    },
                    {
                        "name": "sqrt_ratio_upper",
                        "type": "uint160"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "positionsByFactory",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            },
            {
                "name": "_account",
                "type": "address"
            },
            {
                "name": "_factory",
                "type": "address"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "id",
                        "type": "uint256"
                    },
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "liquidity",
                        "type": "uint256"
                    },
                    {
                        "name": "staked",
                        "type": "uint256"
                    },
                    {
                        "name": "amount0",
                        "type": "uint256"
                    },
                    {
                        "name": "amount1",
                        "type": "uint256"
                    },
                    {
                        "name": "staked0",
                        "type": "uint256"
                    },
                    {
                        "name": "staked1",
                        "type": "uint256"
                    },
                    {
                        "name": "unstaked_earned0",
                        "type": "uint256"
                    },
                    {
                        "name": "unstaked_earned1",
                        "type": "uint256"
                    },
                    {
                        "name": "emissions_earned",
                        "type": "uint256"
                    },
                    {
                        "name": "tick_lower",
                        "type": "int24"
                    },
                    {
                        "name": "tick_upper",
                        "type": "int24"
                    },
                    {
                        "name": "sqrt_ratio_lower",
                        "type": "uint160"
                    },
                    {
                        "name": "sqrt_ratio_upper",
                        "type": "uint160"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "epochsLatest",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "ts",
                        "type": "uint256"
                    },
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "votes",
                        "type": "uint256"
                    },
                    {
                        "name": "emissions",
                        "type": "uint256"
                    },
                    {
                        "name": "bribes",
                        "type": "tuple[]",
                        "components": [
                            {
                                "name": "token",
                                "type": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint256"
                            }
                        ]
                    },
                    {
                        "name": "fees",
                        "type": "tuple[]",
                        "components": [
                            {
                                "name": "token",
                                "type": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint256"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "epochsByAddress",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            },
            {
                "name": "_address",
                "type": "address"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "ts",
                        "type": "uint256"
                    },
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "votes",
                        "type": "uint256"
                    },
                    {
                        "name": "emissions",
                        "type": "uint256"
                    },
                    {
                        "name": "bribes",
                        "type": "tuple[]",
                        "components": [
                            {
                                "name": "token",
                                "type": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint256"
                            }
                        ]
                    },
                    {
                        "name": "fees",
                        "type": "tuple[]",
                        "components": [
                            {
                                "name": "token",
                                "type": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint256"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "rewards",
        "inputs": [
            {
                "name": "_limit",
                "type": "uint256"
            },
            {
                "name": "_offset",
                "type": "uint256"
            },
            {
                "name": "_venft_id",
                "type": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "venft_id",
                        "type": "uint256"
                    },
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "amount",
                        "type": "uint256"
                    },
                    {
                        "name": "token",
                        "type": "address"
                    },
                    {
                        "name": "fee",
                        "type": "address"
                    },
                    {
                        "name": "bribe",
                        "type": "address"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "rewardsByAddress",
        "inputs": [
            {
                "name": "_venft_id",
                "type": "uint256"
            },
            {
                "name": "_pool",
                "type": "address"
            }
        ],
        "outputs": [
            {
                "name": "",
                "type": "tuple[]",
                "components": [
                    {
                        "name": "venft_id",
                        "type": "uint256"
                    },
                    {
                        "name": "lp",
                        "type": "address"
                    },
                    {
                        "name": "amount",
                        "type": "uint256"
                    },
                    {
                        "name": "token",
                        "type": "address"
                    },
                    {
                        "name": "fee",
                        "type": "address"
                    },
                    {
                        "name": "bribe",
                        "type": "address"
                    }
                ]
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_FACTORIES",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_POOLS",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_TOKENS",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_LPS",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_EPOCHS",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_REWARDS",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "MAX_POSITIONS",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "WEEK",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "registry",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "voter",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "convertor",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address"
            }
        ]
    },
    {
        "stateMutability": "view",
        "type": "function",
        "name": "cl_helper",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address"
            }
        ]
    }
] as const
