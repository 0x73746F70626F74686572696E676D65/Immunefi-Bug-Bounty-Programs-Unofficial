import 'tsconfig-paths/register'
import { base } from 'viem/chains'

import { defineSquidProcessor } from '@originprotocol/squid-utils'
import * as exchangeRatesPostProcessor from '@shared/post-processors/exchange-rates'
import { createMorphoVaultApyProcessor } from '@templates/morpho/processor'
import { createPoolsProcessor } from '@templates/pools/pools'
import { processStatus } from '@templates/processor-status'
import { DEFAULT_FIELDS } from '@utils/batch-proccesor-fields'
import { initProcessorFromDump } from '@utils/dumps'

import { baseERC20s, baseStrategiesProcessors, bridgedWoethStrategy } from './base'
import { aerodromeProcessors } from './base/aerodrome'
import * as exchangeRatesProcessor from './base/exchange-rates'

export const processor = defineSquidProcessor({
  chainId: base.id,
  stateSchema: 'base-processor',
  processors: [
    ...baseERC20s,
    ...baseStrategiesProcessors,
    ...aerodromeProcessors,
    bridgedWoethStrategy,
    exchangeRatesProcessor,
    createPoolsProcessor(base.id),
    createMorphoVaultApyProcessor({
      from: 43_839_000, // ~7 days before 2026-04-01
    }),
  ],
  postProcessors: [exchangeRatesPostProcessor, processStatus('base')],
  validators: [],
  fields: DEFAULT_FIELDS,
})

export default processor

if (require.main === module) {
  initProcessorFromDump(processor).catch((error) => {
    throw error
  })
}
