declare module "*.ttf"
