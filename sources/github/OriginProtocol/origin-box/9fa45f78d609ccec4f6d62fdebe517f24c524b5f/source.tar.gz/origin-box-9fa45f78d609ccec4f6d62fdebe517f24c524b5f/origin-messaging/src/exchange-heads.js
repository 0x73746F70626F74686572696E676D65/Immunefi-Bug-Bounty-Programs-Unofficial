'use strict'

import logger from './logger'

const Channel = require('ipfs-pubsub-1on1')

const getHeadsForDatabase = store => (store && store._oplog) ? store._oplog.heads : []

const exchangeHeads = async (ipfs, address, peer, getStore, getDirectConnection, onMessage, onChannelCreated) => {
  const _handleMessage = message => {
    const msg = JSON.parse(message.data)
    const { address, heads } = msg
    onMessage(address, heads)
  }

  let channel = getDirectConnection(peer)
  if (!channel) {
    try {
      logger.debug(`Create a channel to ${peer}`)
      channel = await Channel.open(ipfs, peer)
      channel.on('message', _handleMessage)
      logger.debug(`Channel created to ${peer} id ${channel._id}`)
      onChannelCreated(channel)
    } catch (e) {
      logger.error(e)
    }
  }

  // Wait for the direct channel to be fully connected
  await channel.connect()
  logger.debug(`Connected to ${peer}`)

  // Send the heads if we have any
  const heads = getHeadsForDatabase(getStore(address))
  logger.debug(
    `Send latest heads of '${address}':\n`,
    JSON.stringify(heads.map(e => e.hash), null, 2)
  )
  if (heads) {
    await channel.send(JSON.stringify({ address: address, heads: heads }))
  }

  return channel
}

module.exports = exchangeHeads
