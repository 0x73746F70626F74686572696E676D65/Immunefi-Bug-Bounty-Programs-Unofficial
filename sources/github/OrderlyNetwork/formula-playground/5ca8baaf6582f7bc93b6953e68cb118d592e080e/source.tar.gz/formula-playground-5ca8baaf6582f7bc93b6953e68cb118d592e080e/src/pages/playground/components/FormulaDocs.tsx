import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { useFormulaStore } from "@/store/formulaStore";
import { Markdown } from "@/components/common/Markdown";
import { useSpreadsheetStore } from "@/store/spreadsheetStore";

export function FormulaDocs() {
  const propFormula = useSpreadsheetStore((state) => state.currentFormula);
  const { formulaDefinitions, selectedFormulaId } = useFormulaStore();

  // Use prop formula if provided, otherwise fall back to store selection
  const selectedFormula =
    propFormula || formulaDefinitions.find((f) => f.id === selectedFormulaId);

  if (!selectedFormula) {
    return (
      <div className="h-full w-full flex items-center justify-center text-sm text-gray-500">
        Select a formula to view documentation
      </div>
    );
  }

  return (
    <ScrollArea className="h-full w-full p-4">
      <div className="space-y-4">
        <div className="space-y-3 text-sm text-gray-700">
          {selectedFormula.formula && (
            <>
              <div className="font-medium text-gray-900 mb-1">Formula</div>
              <p className="leading-6 bg-sky-100 p-2 rounded-md font-bold font-mono">
                {selectedFormula.formula}
              </p>
            </>
          )}
          {selectedFormula.description && (
            <Markdown content={selectedFormula.description} />
          )}
          {selectedFormula.tags && selectedFormula.tags.length > 0 && (
            <div>
              <div className="font-medium text-gray-900 mb-1">Tags</div>
              <div className="flex flex-wrap gap-1">
                {selectedFormula.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      {/* 添加横向滚动条支持 */}
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}
