"use client";
import { AlertTriangle, BookOpen, Divide } from "lucide-react";
import { useMemo } from "react";
import { useFormulaTabStore } from "@/store/formulaTabStore";
import {
  usePreArgsCheckStore,
  createPreArgsCheckMessageSelector,
} from "@/store/preArgsCheckStore";
import { cn } from "@/lib/utils";
import { Version } from "./version";

export function StatusBar() {
  const activeTab = useFormulaTabStore((state) => state.getActiveTab());
  const formulaId = activeTab?.id;

  // Method 1: Use helper function with useMemo to create a stable selector
  // This ensures re-render only when the specific formulaId's data changes
  // Zustand will only re-render when the selected value actually changes
  const latestMessage = usePreArgsCheckStore(
    useMemo(() => createPreArgsCheckMessageSelector(formulaId), [formulaId])
  );

  return (
    <div className="h-8 bg-gray-50 flex items-center justify-between px-2 text-xs select-none border-t border-gray-200">
      <div className="flex items-center flex-1">
        {latestMessage ? (
          <div
            className={cn(
              "flex items-center gap-1.5",
              latestMessage.message?.level === "warning"
                ? "text-amber-600"
                : "text-red-600"
            )}
          >
            <AlertTriangle className="h-3 w-3" />
            <span className="truncate">{latestMessage.message?.message}</span>
          </div>
        ) : (
          <div className="text-gray-500">
            <span>All required fields present</span>
          </div>
        )}
      </div>

      <div className="flex items-center h-full px-2 gap-4">
        <div className="flex items-center gap-1 text-gray-700">
          {/* <BookOpen size={12} /> */}
          <a
            href="https://deepwiki.com/OrderlyNetwork/js-sdk"
            target="_blank"
            className="hover:text-blue-600"
          >
            <span className="text-xs">DeepWiki</span>
          </a>
        </div>
        {/* <div className="w-[1px] h-1/3 bg-gray-200"></div> */}
        <div className="flex items-center gap-1 text-gray-700">
          <Version />
        </div>
      </div>
    </div>
  );
}
