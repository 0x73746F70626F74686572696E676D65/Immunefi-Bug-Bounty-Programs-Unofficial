import React, { useMemo, useState } from "react";
import { useSpreadsheetStore } from "@/store/spreadsheetStore";
import type { ColumnDef } from "@/types/spreadsheet";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  sanitizeJsonStringify,
  sanitizeErrorMessage,
} from "@/utils/sanitization";
import { Decimal } from "@orderly.network/utils";

export interface ResultCellProps {
  rowId: string;
  column: ColumnDef;
  onCellClick?: (rowId: string, colId: string) => void;
}

const ResultCell: React.FC<ResultCellProps> = ({
  rowId,
  column,
  onCellClick,
}) => {
  const [showErrorDetails, setShowErrorDetails] = useState(false);

  const currentFormula = useSpreadsheetStore((state) => state.currentFormula);
  const formulaId = currentFormula?.id || "default";

  // Direct state access for proper reactivity instead of using getter method
  const calculationResult = useSpreadsheetStore((state) => {
    const tabResults = state.tabCalculationResults[formulaId];
    return tabResults ? tabResults[rowId] : undefined;
  });

  const displayValue = useMemo(() => {
    if (typeof calculationResult === "undefined") return "";
    if (
      typeof calculationResult?.result === "object" &&
      calculationResult.result instanceof Decimal
    ) {
      return calculationResult.result.toString();
    }
    if (
      typeof calculationResult.result === "string" ||
      typeof calculationResult.result === "number" ||
      typeof calculationResult.result === "boolean"
    ) {
      return calculationResult.result;
    }
    return sanitizeJsonStringify(calculationResult.result);
  }, [calculationResult]);

  const handleClick = () => {
    onCellClick?.(rowId, column.id);
  };

  const handleErrorClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowErrorDetails(true);
  };

  const getTextClass = () => {
    if (calculationResult?.error)
      return "text-red-600 cursor-pointer hover:text-red-700";
    if (calculationResult?.result !== undefined) return "text-green-700";
    return "text-gray-400";
  };

  const getErrorDetails = () => {
    if (!calculationResult?.error) return null;

    return (
      <div className="space-y-3">
        <div>
          <h4 className="font-semibold text-sm text-red-600">Error Details</h4>
        </div>

        <div className="space-y-2">
          <div>
            <span className="text-xs font-medium text-gray-500">
              Error Message:
            </span>
            <p className="text-sm text-red-700 mt-1 p-2 bg-red-50 rounded border border-red-200">
              {sanitizeErrorMessage(calculationResult.error)}
            </p>
          </div>

          <div>
            <span className="text-xs font-medium text-gray-500">Row ID:</span>
            <p className="text-sm font-mono text-gray-700 mt-1">{rowId}</p>
          </div>

          <div>
            <span className="text-xs font-medium text-gray-500">Column:</span>
            <p className="text-sm text-gray-700 mt-1">
              {column.title || column.id}
            </p>
          </div>

          {calculationResult.executionTime && (
            <div>
              <span className="text-xs font-medium text-gray-500">
                Execution Time:
              </span>
              <p className="text-sm text-gray-700 mt-1">
                {calculationResult.executionTime}ms
              </p>
            </div>
          )}

          {calculationResult.isValid !== undefined && (
            <div>
              <span className="text-xs font-medium text-gray-500">
                Validation Status:
              </span>
              <p className="text-sm mt-1">
                <span
                  className={`inline-flex px-2 py-1 text-xs rounded-full ${
                    calculationResult.isValid
                      ? "bg-green-100 text-green-800"
                      : "bg-red-100 text-red-800"
                  }`}
                >
                  {calculationResult.isValid ? "Valid" : "Invalid"}
                </span>
              </p>
            </div>
          )}
        </div>

        <div className="text-xs text-gray-500 pt-2 border-t">
          Click anywhere to close
        </div>
      </div>
    );
  };

  return (
    <Popover open={showErrorDetails} onOpenChange={setShowErrorDetails}>
      <PopoverTrigger asChild>
        <div
          className={`w-full h-full px-2 flex items-center text-sm font-mono text-right justify-end ${getTextClass()}`}
          onClick={calculationResult?.error ? handleErrorClick : handleClick}
          title={
            calculationResult?.error
              ? "Click to see error details"
              : calculationResult?.executionTime
              ? `Execution time: ${calculationResult.executionTime}ms`
              : undefined
          }
        >
          {displayValue ?? "-"}
        </div>
      </PopoverTrigger>

      {calculationResult?.error && (
        <PopoverContent className="w-80" align="start" side="bottom">
          {getErrorDetails()}
        </PopoverContent>
      )}
    </Popover>
  );
};

export default ResultCell;
