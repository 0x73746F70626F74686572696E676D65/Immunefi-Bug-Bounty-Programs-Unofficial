// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.18;

/// @title AccountTypes library
/// @author Orderly_Rubick
library AccountTypes {
    struct PerpPosition {
        int128 positionQty;
        int128 costPosition;
        int128 lastSumUnitaryFundings;
        uint128 lastExecutedPrice;
        uint128 lastSettledPrice;
        uint128 averageEntryPrice;
        int128 openingCost;
        uint128 lastAdlPrice;
    }

    struct IsoPerpPosition {
        int128 positionQty;
        int128 costPosition;
        int128 lastSumUnitaryFundings;
        uint128 lastExecutedPrice;
        uint128 lastSettledPrice;
        uint128 averageEntryPrice;
        int128 openingCost;
        uint128 lastAdlPrice;
        // Multi-collateral margin support: tokenHash => margin amount
        mapping(bytes32 => int128) margins;
    }

    // account id, unique for each account, should be accountId -> {addr, brokerId}
    // and keccak256(addr, brokerID) == accountId
    struct Account {
        // user's broker id
        bytes32 brokerHash;
        // primary address
        address userAddress;
        // mapping symbol => balance
        mapping(bytes32 => int128) balances;
        // mapping symbol => totalFrozenBalance
        mapping(bytes32 => uint128) totalFrozenBalances;
        // mapping withdrawNonce => symbol => balance
        mapping(uint64 => mapping(bytes32 => uint128)) frozenBalances;
        // perp position
        mapping(bytes32 => PerpPosition) perpPositions;
        // lastwithdraw nonce
        uint64 lastWithdrawNonce;
        // last perp trade id
        uint64 lastPerpTradeId;
        // last engine event id
        uint64 lastEngineEventId;
        // @deprecated last deposit event id
        uint64 lastDepositEventId;
        // last deposit src chain id
        uint64 lastDepositSrcChainId;
        // last deposit src chain nonce
        uint64 lastDepositSrcChainNonce;
        // solana account public key
        bytes32 solAccountPubKey;
        // mapping trade symbol hash => IsoPerpPosition
        mapping(bytes32 => IsoPerpPosition) isoPerpPositions;
    }

    struct AccountDeposit {
        bytes32 accountId;
        bytes32 brokerHash;
        address userAddress;
        bytes32 tokenHash;
        uint256 srcChainId;
        uint128 tokenAmount;
        uint64 srcChainDepositNonce;
    }

    struct AccountDepositSol {
        bytes32 accountId;
        bytes32 brokerHash;
        bytes32 pubkey;
        bytes32 tokenHash;
        uint256 srcChainId;
        uint128 tokenAmount;
        uint64 srcChainDepositNonce;
    }

    // for accountWithdrawFinish
    struct AccountWithdraw {
        bytes32 accountId;
        address sender;
        address receiver;
        bytes32 brokerHash;
        bytes32 tokenHash;
        uint128 tokenAmount;
        uint128 fee;
        uint256 chainId;
        uint64 withdrawNonce;
    }

    struct AccountTokenBalances {
        // token hash
        bytes32 tokenHash;
        // balance & frozenBalance
        int128 balance;
        uint128 frozenBalance;
    }

    struct AccountBalanceSnapshot {
        bytes32 accountId;
        bytes32 brokerHash;
        address userAddress;
        AccountTokenBalances[] tokenBalances;
    }

    struct AccountPerpPositions {
        // symbol hash
        bytes32 symbolHash;
        // perp position
        int128 positionQty;
        int128 costPosition;
        int128 lastSumUnitaryFundings;
        uint128 lastExecutedPrice;
        uint128 lastSettledPrice;
        uint128 averageEntryPrice;
        int128 openingCost;
        uint128 lastAdlPrice;
    }


    // for batch get
    struct AccountSnapshot {
        bytes32 accountId;
        bytes32 brokerHash;
        address userAddress;
        uint64 lastWithdrawNonce;
        uint64 lastPerpTradeId;
        uint64 lastEngineEventId;
        uint64 lastDepositEventId;
        AccountTokenBalances[] tokenBalances;
        AccountPerpPositions[] perpPositions;
        uint64 lastDepositSrcChainId;
        uint64 lastDepositSrcChainNonce;
    }

    struct AccountMargins{
        bytes32 marginAssetHash;
        int128 margin;
    }

    struct AccountIsoPerpPositions {
        // symbol hash
        bytes32 symbolHash;
        // perp position
        int128 positionQty;
        int128 costPosition;
        int128 lastSumUnitaryFundings;
        uint128 lastExecutedPrice;
        uint128 lastSettledPrice;
        uint128 averageEntryPrice;
        int128 openingCost;
        uint128 lastAdlPrice;
        AccountMargins[] margins;
    }

    struct AccountSnapshotV3 {
        bytes32 accountId;
        bytes32 brokerHash;
        address userAddress;
        uint64 lastWithdrawNonce;
        uint64 lastPerpTradeId;
        uint64 lastEngineEventId;
        uint64 lastDepositEventId;
        AccountTokenBalances[] tokenBalances;
        AccountPerpPositions[] perpPositions;
        AccountIsoPerpPositions[] isoPerpPositions;
        uint64 lastDepositSrcChainId;
        uint64 lastDepositSrcChainNonce;
    }

    struct AccountDelegateSigner {
        uint256 chainId;
        address signer;
    }
}
