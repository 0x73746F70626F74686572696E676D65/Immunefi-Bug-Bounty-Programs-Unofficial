// SPDX-License-Identifier: Apache-2.0
pragma solidity 0.8.26;

import "openzeppelin-contracts-upgradeable/contracts/access/OwnableUpgradeable.sol";
import "./interface/ILedger.sol";
import "./dataLayout/OperatorManagerDataLayout.sol";
import "./interface/IOperatorManager.sol";
import "./interface/IOperatorManagerImplA.sol";
import "./interface/IOperatorManagerImplB.sol";
import "./library/Signature.sol";
import "./interface/IVaultManager.sol";


/// @title Operator call this manager for update data
/// @author Orderly_Rubick
/// @notice OperatorManager is responsible for executing engine tx, only called by operator.
/// @notice This contract should only have one in main-chain
contract OperatorManager is IOperatorManager, OwnableUpgradeable, OperatorManagerDataLayout {
    // Using Storage as OZ 5.0 does
    struct OperatorManagerStorage {
        // Because of EIP170 size limit, the implementation should be split to impl contracts
        address operatorManagerImplA;
        address operatorManagerImplB;
    }

    // keccak256(abi.encode(uint256(keccak256("orderly.OperatorManager")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant OperatorManagerStorageLocation =
        0x345b139f871c60106e8079566993e0e04dc2ba53b7750d838960a732fe9c5100;

    function _getOperatorManagerStorage() private pure returns (OperatorManagerStorage storage $) {
        assembly {
            $.slot := OperatorManagerStorageLocation
        }
    }

    /// @notice Require only operator can call
    modifier onlyOperator() {
        // Update: operatorManagerZipAddress is also allowed to call
        if (msg.sender != operatorAddress && msg.sender != operatorManagerZipAddress) revert OnlyOperatorCanCall();
        _;
    }

    /// @notice check non-zero address
    modifier nonZeroAddress(address _address) {
        if (_address == address(0)) revert AddressZero();
        _;
    }

    /// @notice Set the operator address
    function setOperator(address _operatorAddress) external override onlyOwner nonZeroAddress(_operatorAddress) {
        emit ChangeOperator(1, operatorAddress, _operatorAddress);
        operatorAddress = _operatorAddress;
    }

    /// @notice Set engine signature address for spot trade upload
    function setEngineSpotTradeUploadAddress(address _engineSpotTradeUploadAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_engineSpotTradeUploadAddress)
    {
        emit ChangeEngineUpload(1, engineSpotTradeUploadAddress, _engineSpotTradeUploadAddress);
        engineSpotTradeUploadAddress = _engineSpotTradeUploadAddress;
    }

    /// @notice Set engine signature address for perpetual future trade upload
    function setEnginePerpTradeUploadAddress(address _enginePerpTradeUploadAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_enginePerpTradeUploadAddress)
    {
        emit ChangeEngineUpload(2, enginePerpTradeUploadAddress, _enginePerpTradeUploadAddress);
        enginePerpTradeUploadAddress = _enginePerpTradeUploadAddress;
    }

    /// @notice Set engine signature address for event upload
    function setEngineEventUploadAddress(address _engineEventUploadAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_engineEventUploadAddress)
    {
        emit ChangeEngineUpload(3, engineEventUploadAddress, _engineEventUploadAddress);
        engineEventUploadAddress = _engineEventUploadAddress;
    }

    /// @notice Set engine signature address for market information upload
    function setEngineMarketUploadAddress(address _engineMarketUploadAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_engineMarketUploadAddress)
    {
        emit ChangeEngineUpload(4, engineMarketUploadAddress, _engineMarketUploadAddress);
        engineMarketUploadAddress = _engineMarketUploadAddress;
    }

    /// @notice Set engine signature address for rebalance upload
    function setEngineRebalanceUploadAddress(address _engineRebalanceUploadAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_engineRebalanceUploadAddress)
    {
        emit ChangeEngineUpload(5, engineRebalanceUploadAddress, _engineRebalanceUploadAddress);
        engineRebalanceUploadAddress = _engineRebalanceUploadAddress;
    }

    /// @notice Set the address of OperatorManagerZip contract
    function setOperatorManagerZipAddress(address _operatorManagerZipAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_operatorManagerZipAddress)
    {
        emit ChangeOperator(2, operatorManagerZipAddress, _operatorManagerZipAddress);
        operatorManagerZipAddress = _operatorManagerZipAddress;
    }

    /// @notice Set the address of ledger contract
    function setLedger(address _ledger) external override onlyOwner nonZeroAddress(_ledger) {
        emit ChangeLedger(address(ledger), _ledger);
        ledger = ILedger(_ledger);
    }

    /// @notice Set the address of market manager contract
    function setMarketManager(address _marketManagerAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_marketManagerAddress)
    {
        emit ChangeMarketManager(address(marketManager), _marketManagerAddress);
        marketManager = IMarketManager(_marketManagerAddress);
    }

    /// @notice Set the address of VaultManager for permissionless listing (setAllowedSymbolByOperator)
    function setVaultManager(address _vaultManager) external override onlyOwner nonZeroAddress(_vaultManager) {
        address oldVaultManager = address(vaultManager);
        vaultManager = IVaultManager(_vaultManager);
        emit SetVaultManager(oldVaultManager, _vaultManager);
    }

    /// @notice Set the CEFI signer address for permissionless listing (setAllowedSymbol signature verification)
    function setPermissionlessListingSignerAddress(address _permissionlessListingSignerAddress)
        external
        override
        onlyOwner
        nonZeroAddress(_permissionlessListingSignerAddress)
    { 
        emit SetPermissionlessListingSignerAddress(permissionlessListingSignerAddress, _permissionlessListingSignerAddress);
        permissionlessListingSignerAddress = _permissionlessListingSignerAddress;
    }

    /// @notice Set the address of operator manager impl A contract
    function setOperatorManagerImplA(address _operatorManagerImplA)
        external
        override
        onlyOwner
        nonZeroAddress(_operatorManagerImplA)
    {
        emit ChangeOperatorImplA(_getOperatorManagerStorage().operatorManagerImplA, _operatorManagerImplA);
        _getOperatorManagerStorage().operatorManagerImplA = _operatorManagerImplA;
    }

    /// @notice Set the address of operator manager impl B contract
    function setOperatorManagerImplB(address _operatorManagerImplB)
        external
        override
        onlyOwner
        nonZeroAddress(_operatorManagerImplB)
    {
        emit ChangeOperatorImplB(_getOperatorManagerStorage().operatorManagerImplB, _operatorManagerImplB);
        _getOperatorManagerStorage().operatorManagerImplB = _operatorManagerImplB;
    }

    constructor() {
        _disableInitializers();
    }

    function initialize() external override initializer {
        __Ownable_init();
        futuresUploadBatchId = 1;
        eventUploadBatchId = 1;
        lastOperatorInteraction = block.timestamp;
        // init all engine sign address
        // https://wootraders.atlassian.net/wiki/spaces/ORDER/pages/315785217/Orderly+V2+Keys+Smart+Contract
    }

    /// @notice Operator ping to update last operator interaction timestamp
    function operatorPing() external onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.operatorPing.selector),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    /// @notice Function for perpetual futures trade upload
    function futuresTradeUpload(PerpTypes.FuturesTradeUploadData calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.futuresTradeUpload.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    function futuresTradeUploadV3(PerpTypes.FuturesTradeUploadDataV3 calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.futuresTradeUploadV3.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    /// @notice Function for perpetual futures trade upload V4 (V3 + `isInsuranceAccount` flag per trade)
    function futuresTradeUploadV4(PerpTypes.FuturesTradeUploadDataV4 calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.futuresTradeUploadV4.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }


    /// @notice Function for event upload
    function eventUpload(EventTypes.EventUpload calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplB.eventUpload.selector, data),
            _getOperatorManagerStorage().operatorManagerImplB
        );
    }

    /// @notice Function for perpetual futures price upload
    function perpPriceUpload(MarketTypes.UploadPerpPrice calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.perpPriceUpload.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    
    /// @notice Permissionless listing: set allowed symbol by Operator with CEFI signature and sequenceId anti-replay.
    /// @param _symbolHash keccak256(symbol), e.g. PERP_BTC_USDC
    /// @param _allowed true to allow, false to disallow
    /// @param _sequenceId CEFI sequence id (must equal permissionlessListingSequenceId + 1)
    /// @param _chainId chain id (must equal block.chainid)
    /// @param _cefiSignature CEFI ECDSA signature over `keccak256(abi.encode(symbolHash, allowed, sequenceId, chainId))`
    function setAllowedSymbol(
        bytes32 _symbolHash,
        bool _allowed,
        uint64 _sequenceId,
        uint256 _chainId,
        bytes calldata _cefiSignature
    ) external override onlyOperator {
        if (address(vaultManager) == address(0)) revert VaultManagerNotSet();
        if (permissionlessListingSignerAddress == address(0)) revert PermissionlessListingSignerNotSet();
        if (_chainId != block.chainid) revert InvalidChainId(_chainId, block.chainid);

        uint64 expectedSequenceId = permissionlessListingSequenceId + 1;
        if (_sequenceId != expectedSequenceId) revert InvalidSequenceId(_sequenceId, expectedSequenceId);

        bool valid = Signature.setAllowedSymbolEncodeHashVerify(
            _symbolHash,
            _allowed,
            _sequenceId,
            _chainId,
            _cefiSignature,
            permissionlessListingSignerAddress
        );
        if (!valid) revert SignatureNotMatch();

        permissionlessListingSequenceId = _sequenceId;
        vaultManager.setAllowedSymbolByOperator(_symbolHash, _allowed);
        emit SetAllowedSymbolByOperator(_symbolHash, _allowed, _sequenceId);
    }

    /// @notice Function for sum unitary fundings upload
    function sumUnitaryFundingsUpload(MarketTypes.UploadSumUnitaryFundings calldata data)
        external
        override
        onlyOperator
    {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.sumUnitaryFundingsUpload.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    // @notice Function for rebalance burn upload
    function rebalanceBurnUpload(RebalanceTypes.RebalanceBurnUploadData calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.rebalanceBurnUpload.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    // @notice Function for rebalance mint upload
    function rebalanceMintUpload(RebalanceTypes.RebalanceMintUploadData calldata data) external override onlyOperator {
        _delegatecall(
            abi.encodeWithSelector(IOperatorManagerImplA.rebalanceMintUpload.selector, data),
            _getOperatorManagerStorage().operatorManagerImplA
        );
    }

    /// @notice Function to check if the last operator interaction timestamp is over 3 days
    function checkEngineDown() external view override returns (bool) {
        return (lastOperatorInteraction + 3 days < block.timestamp);
    }

    // inner function for delegatecall
    function _delegatecall(bytes memory data, address impl) private {
        (bool success, bytes memory returnData) = impl.delegatecall(data);
        if (!success) {
            if (returnData.length > 0) {
                assembly {
                    revert(add(32, returnData), mload(returnData))
                }
            } else {
                revert DelegatecallFail();
            }
        }
    }

    // @dev function to init the function selector for each bizType
    function initBizTypeToSelector() public onlyOwner {
        bizTypeToSelectors[uint8(Signature.BizType.Withdraw)] =  ILedger.executeWithdrawAction.selector;
        bizTypeToSelectors[uint8(Signature.BizType.Settlement)] =  ILedger.executeSettlement.selector;
        bizTypeToSelectors[uint8(Signature.BizType.Adl)] =  ILedger.executeAdl.selector;
        bizTypeToSelectors[uint8(Signature.BizType.Liquidation)] =  ILedger.executeLiquidation.selector;
        bizTypeToSelectors[uint8(Signature.BizType.FeeDistribution)] =  ILedger.executeFeeDistribution.selector;
        bizTypeToSelectors[uint8(Signature.BizType.DelegateSigner)] =  ILedger.executeDelegateSigner.selector;
        bizTypeToSelectors[uint8(Signature.BizType.DelegateWithdraw)] =  ILedger.executeDelegateWithdrawAction.selector;
        bizTypeToSelectors[uint8(Signature.BizType.AdlV2)] =  ILedger.executeAdlV2.selector;
        bizTypeToSelectors[uint8(Signature.BizType.LiquidationV2)] =  ILedger.executeLiquidationV2.selector;
        bizTypeToSelectors[uint8(Signature.BizType.WithdrawSol)] =  ILedger.executeWithdrawSolAction.selector;
        bizTypeToSelectors[uint8(Signature.BizType.Withdraw2Contract)] =  ILedger.executeWithdraw2Contract.selector;
        bizTypeToSelectors[uint8(Signature.BizType.BalanceTransfer)] =  ILedger.executeBalanceTransfer.selector;            
        bizTypeToSelectors[uint8(Signature.BizType.SwapResult)] =  ILedger.executeSwapResultUpload.selector;
        bizTypeToSelectors[uint8(Signature.BizType.Withdraw2ContractV2)] =  ILedger.executeWithdraw2ContractV2.selector;
        bizTypeToSelectors[uint8(Signature.BizType.SettlementV3)] =  ILedger.executeSettlementV3.selector;
        bizTypeToSelectors[uint8(Signature.BizType.AdlV3)] =  ILedger.executeAdlV3.selector;
        bizTypeToSelectors[uint8(Signature.BizType.LiquidationV3)] =  ILedger.executeLiquidationV3.selector;
        bizTypeToSelectors[uint8(Signature.BizType.MarginTransferV3)] =  ILedger.executeMarginTransferV3.selector;
    }

    function getOperatorManagerImpl() external view returns (address, address) {
        OperatorManagerStorage storage $ = _getOperatorManagerStorage();
        return ($.operatorManagerImplA, $.operatorManagerImplB);
    }
}
