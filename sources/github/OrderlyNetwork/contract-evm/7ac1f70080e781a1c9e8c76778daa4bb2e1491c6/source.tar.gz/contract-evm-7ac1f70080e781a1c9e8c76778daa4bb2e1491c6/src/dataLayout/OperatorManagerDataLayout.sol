// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.18;

import "openzeppelin-contracts-upgradeable/contracts/access/OwnableUpgradeable.sol";
import "../interface/ILedger.sol";
import "../interface/IMarketManager.sol";
import "../interface/IVaultManager.sol";


/// @title OperatorManager contract data layout
/// @author Orderly_Rubick
/// @notice DataLayout for OperatorManager contract, align with 50 slots
contract OperatorManagerDataLayout {
    // An EOA operator address
    address public operatorAddress;
    // The ledger Interface
    ILedger public ledger;
    // An increasing Id for the batch of perpetual futures trading upload from Operator
    uint64 public futuresUploadBatchId;
    // The market manager Interface
    IMarketManager public marketManager;
    // An increasing Id for the event upload from Operator
    uint64 public eventUploadBatchId;

    // The last operator interaction timestamp
    uint256 public lastOperatorInteraction;

    // The signature addresses of Engine
    address public engineSpotTradeUploadAddress;
    address public enginePerpTradeUploadAddress;
    address public engineEventUploadAddress;
    address public engineMarketUploadAddress;
    address public engineRebalanceUploadAddress;

    // For OperatorManagerZip contract, which calldata is zipped to reduce L1 gas cost
    address public operatorManagerZipAddress;

    mapping(uint8 => bytes4) public bizTypeToSelectors;
    
    // @Ray: add permissionless listing related data
    // The signer address of permissionless listing (CEFI setAllowedSymbol signer)
    address public permissionlessListingSignerAddress;
    uint64 public permissionlessListingSequenceId;

    // VaultManager for permissionless listing (setAllowedSymbolByOperator)
    IVaultManager public vaultManager;

    // The storage gap to prevent overwriting by proxy
    // __gap = 50 - 13 = 37
    uint256[37] private __gap;
}
