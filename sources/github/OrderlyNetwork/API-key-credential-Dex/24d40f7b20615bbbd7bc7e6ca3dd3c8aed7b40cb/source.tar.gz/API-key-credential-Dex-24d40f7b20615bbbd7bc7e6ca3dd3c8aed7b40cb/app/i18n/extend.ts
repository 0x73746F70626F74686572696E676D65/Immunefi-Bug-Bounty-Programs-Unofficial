export const extendMessages = {
  "extend.tradingRewards.description": "Trade with Orderly to earn ORDER",
  "extend.affiliate.tag": "40% Rebate",
  "extend.affiliate.description": "Earn more as a Orderly affiliate",
  "extend.staking": "Staking",
  "extend.staking.description": "Stake ORDER/esORDER to acquire VALOR",
  "extend.swap": "Swap",
  "extend.tradingPoints.points": "Points",
  "extend.tradingLeaderboard.leaderboard": "Leaderboard",
  "extend.tradingLeaderboard.campaigns": "Campaigns",
};

export type ExtendLocaleMessages = typeof extendMessages;
