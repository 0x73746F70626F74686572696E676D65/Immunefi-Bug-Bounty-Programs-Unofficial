from orderly_evm_connector.lib.utils import check_required_parameters
from orderly_evm_connector.lib.utils import check_enum_parameter
from orderly_evm_connector.lib.enums import TimeType


def get_market_trades(self, symbol: str, limit: int = None):
    """Market trades
    Limit: 10 requests per 1 second per IP address

    GET /v1/public/market_trades

    Get the latest market trades.

    Args:
        symbol(string)
    Optional Args:
        limit(number): N (default: 10)	Numbers of trades want to query.

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-market-trades
    """
    check_required_parameters([[symbol, "symbol"]])
    payload = {"symbol": symbol, "limit": limit}
    return self._request("GET", "/v1/public/market_trades", payload=payload)


def get_volume_statistics(self):
    """Volume statistics

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/volume/stats

    Get the latest volume statistics of Orderly and its associated brokers. Note that for broker volume, the volume is counted as the sum of the maker and taker volume, while for the full Orderly platform, the volume is the total amount matched on the platform (ie taker and maker are not double-counted.)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-builder-volume
    """
    return self._request("GET", "/v1/public/volume/stats")


def get_predicted_funding_rate_for_all_markets(self):
    """Get predicted funding rate for all markets

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/funding_rates

    Get predicted funding rates for all futures trading pairs.

    Get the : * last_funding_rate : latest hourly funding rate for all the markets for the last funding period (dt = 8h) * est_funding_rate : rolling average of all funding rates over the last 8 hours

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-predicted-funding-rates-for-all-markets
    """
    return self._request("GET", "/v1/public/funding_rates")


def get_predicted_funding_rate_for_one_market(self, symbol: str):
    """Get predicted funding rate for one market

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/funding_rate/:symbol

    Get latest funding rate for one market.

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-funding-rate-history-for-one-market
    """
    check_required_parameters([[symbol, "symbol"]])
    return self._request("GET", f"/v1/public/funding_rate/{symbol}")


def get_funding_rate_history_for_one_market(
    self,
    symbol: str,
    start_t: float = None,
    end_t: float = None,
    page: int = None,
    size: int = None,
):
    """Get funding rate history for one market

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/funding_rate_history

    Get funding rate history for one market.

    Args:
        symbol(string)
    Optional Args:
        start_t(timestamp): start time range that you wish to query, noted that the time stamp is a 13-digits timestamp.
        end_t(timestamp): end time range that you wish to query, noted that the time stamp is a 13-digits timestamp.
        page(number): N(default: 1)	the page you wish to query.
        size(number): Default: 60

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/private/get-funding-fee-history
    """
    check_required_parameters([[symbol, "symbol"]])
    payload = {
        "symbol": symbol,
        "start_t": start_t,
        "end_t": end_t,
        "page": page,
        "size": size,
    }
    return self._request("GET", "/v1/public/funding_rate_history", payload=payload)


def get_futures_info_for_all_markets(self):
    """Get futures info for all markets

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/futures

    Get basic futures information for all the markets.

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-market-info-for-all-symbols
    """
    return self._request("GET", "/v1/public/futures")


def get_futures_info_for_one_market(self, symbol: str):
    """Get futures for one market

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/futures/:symbol

    Get basic futures information for one market.

    Args:
        symbol(string)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-market-info-for-one-symbol
    """
    check_required_parameters([[symbol, "symbol"]])
    _uri = f"/v1/public/futures/{symbol}"
    return self._request("GET", _uri)


def get_tradingview_configuration(self, locale: str):
    """Get TradingView localized configuration info

    Limit: 10 requests per 1 second per IP address

    GET /v1/tv/config

    Args:
        locale(string)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-tradingview-localized-config-info
    """
    check_required_parameters([[locale, "locale"]])
    payload = {"locale": locale}
    return self._request("GET", "/v1/tv/config", payload=payload)


def get_tradingview_history_basrs(
    self, symbol: str, resolution: str, from_timestamp=0, to_timestamp=0
):
    """Get TradingView history bars

    Limit: 10 requests per 1 second per IP address

    GET /v1/tv/history

    Args:
        symbol(string)
        resolution(string)
        from(timestamp)
        to(timestamp)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-tradingview-history-bars

    """

    check_required_parameters(
        [
            [symbol, "symbol"],
            [resolution, "resolution"],
            [from_timestamp, "from_timestamp"],
            [to_timestamp, "to_timestamp"],
        ]
    )
    payload = {
        "symbol": symbol,
        "resolution": resolution,
        "from": from_timestamp,
        "to": to_timestamp,
    }
    return self._request("GET", "/v1/tv/history", payload=payload)


def get_tradingview_symbol_info(self, group: str):
    """Get TradingView symbol info

    Limit: 10 requests per 1 second per IP address

    GET /v1/tv/symbol_info

    Args:
        group(string)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-tradingview-symbol-info
    """
    check_required_parameters([[group, "group"]])
    payload = {"group": group}
    return self._request("GET", "/v1/tv/symbol_info", payload=payload)


def get_orderbook_snapshot(self, symbol: str, max_level: int = None):
    """[Private] Orderbook snapshot

    Limit: 10 requests per 1 second

    GET /v1/orderbook/:symbol

    Snapshot of the current orderbook. Price of asks/bids are in descending order.

    Optional Args:
        max_level(number): (default: 100)	the levels wish to show on both side.

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/private/orderbook-snapshot
    """

    check_required_parameters([[symbol, "symbol"]])
    payload = {"max_level": max_level}
    return self._sign_request("GET", f"/v1/orderbook/{symbol}", payload=payload)


def get_kline(self, symbol: str, type: str, limit: int = None):
    """Get kline
    Limit: 10 requests per 1 second

    GET /v1/kline

    Get the latest klines (OHLC) of the trading pairs.

    Args:
        symbol(string)
        type(enum): 1m/5m/15m/30m/1h/4h/12h/1d/1w/1mon/1y

    Optional Args:
        limit(number): Numbers of klines. Maximum of 1000 klines.

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/private/get-kline
    """
    check_required_parameters([[symbol, "symbol"], [type, "type"]])
    check_enum_parameter(f"_{type}", TimeType)
    payload = {"symbol": symbol, "type": type, "limit": limit}
    return self._sign_request("GET", "/v1/kline", payload=payload)


def get_market_info_funding_history(self):
    """Get Funding Rate for All Markets
    
    Limit: 10 requests per 1 second per IP address
    
    GET /v1/public/market_info/funding_history
    
    Return the funding rate history for all markets
    
    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-funding-rate-for-all-markets
    """
    return self._request("GET", "/v1/public/market_info/funding_history")


def get_market_info_history_charts(self, time_interval: str = None):
    """Get Historical Price List for All Symbols
    
    Limit: 10 requests per 1 second per IP address
    
    GET /v1/public/market_info/history_charts
    
    Return the close price for all symbols
    
    Optional Args:
        time_interval(string): Time interval
        
    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-historical-price-list-for-all-symbols
    """
    payload = {"time_interval": time_interval}
    return self._request("GET", "/v1/public/market_info/history_charts", payload=payload)


def get_market_info_price_changes(self):
    """Get Price Info for All Symbols
    
    Limit: 10 requests per 1 second per IP address
    
    GET /v1/public/market_info/price_changes
    
    Return the current price and the price 5m, 30m, 1h, 24h, 3d, 7d, 30d ago for all symbols
    
    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-price-info-for-all-symbols
    """
    return self._request("GET", "/v1/public/market_info/price_changes")


def get_market_info_traders_open_interests(self):
    """Get Open Interests for All Symbols
    
    Limit: 10 requests per 1 second per IP address
    
    GET /v1/public/market_info/traders_open_interests
    
    Return the long/short Open Interests for all symbols (mm accounts are excluded)
    
    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-open-interests-for-all-symbols
    """
    return self._request("GET", "/v1/public/market_info/traders_open_interests")


def get_symbol_info(self, symbol: str):
    """Get order rules per symbol

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/info/{symbol}

    Provides all the values for the rules that an order needs to fulfill to be placed
    successfully. Includes Price filter, Size filter, Min Notional filter, and
    Risk Exposure filter rules.

    Args:
        symbol(string): Symbol (e.g., PERP_BTC_USDC)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-order-rules
    """
    check_required_parameters([[symbol, "symbol"]])
    return self._request("GET", f"/v1/public/info/{symbol}")


def get_public_broker_order_enums(
    self,
    broker_id: str,
    symbol: str = None,
    enum_id: str = None,
    include_archived: bool = None,
):
    """List order enums for a broker (public)

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/broker/order_enums

    List order enums for a broker.

    Args:
        broker_id(string): Broker ID

    Optional Args:
        symbol(string): Filter by symbol
        enum_id(string): Filter by enum ID
        include_archived(boolean): Include archived enums

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-order-enums
    """
    check_required_parameters([[broker_id, "broker_id"]])
    payload = {
        "broker_id": broker_id,
        "symbol": symbol,
        "enum_id": enum_id,
        "include_archived": include_archived,
    }
    return self._request("GET", "/v1/public/broker/order_enums", payload=payload)


def get_public_broker_order_enum(self, broker_id: str, enum_id: str):
    """[Public] Get one order tag for a broker

    Limit: 10 requests per 1 second per IP address

    GET /v1/public/broker/order_enum

    Get a single order enum for a broker by its enum ID.

    Args:
        broker_id(string): Broker ID (required)
        enum_id(string): The enum ID to look up (required)
    """
    check_required_parameters([[broker_id, "broker_id"], [enum_id, "enum_id"]])
    payload = {"broker_id": broker_id, "enum_id": enum_id}
    return self._request("GET", "/v1/public/broker/order_enum", payload=payload)


def get_public_points_stages(self, broker_id: str, stage_id: int = None, status: str = None):
    """Get information about stages (public)

    Limit: 10 requests per 1 second per user per IP address

    GET /v1/public/points/stages

    Returns information about stages.

    Args:
        broker_id(string): Filter by Broker

    Optional Args:
        stage_id(number): Filter by specific Stage. Returns all if omitted.
        status(string): Filter by status (completed/active)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-points-stages
    """
    check_required_parameters([[broker_id, "broker_id"]])
    payload = {"broker_id": broker_id, "stage_id": stage_id, "status": status}
    return self._request("GET", "/v1/public/points/stages", payload=payload)


def get_public_points_rankings(self, stage: int, period: str, page: int = None, size: int = None):
    """Get stage rankings (public)

    Limit: 10 requests per 1 second per user per IP address

    GET /v1/public/points/rankings

    Returns the rankings for a specific stage.

    Args:
        stage(number): Filter by Stage
        period(string): Filter by period (all_time/last_week/this_week)

    Optional Args:
        page(number): Page number (default: 1)
        size(number): Items per page (default: 20)

    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-points-rankings
    """
    check_required_parameters([[stage, "stage"], [period, "period"]])
    payload = {"stage": stage, "period": period, "page": page, "size": size}
    return self._request("GET", "/v1/public/points/rankings", payload=payload)


def get_kline_history(self, symbol: str, resolution: str, from_timestamp: str = None,
                      to_timestamp: str = None, limit: int = None):
    """Get Kline History
    
    Limit: 5 request per 10 second per IP address
    
    GET /v1/tv/kline_history
    
    Get the historical klines of the specified symbol
    
    Args:
        symbol(string): Symbol name
        resolution(string): `1m/5m/15m/30m/1h/4h/12h/1d/1w/1mon`
        
    Optional Args:
        from_timestamp(string): From timestamp
        to_timestamp(string): To timestamp
        limit(int): Numbers of klines (max: 1000)
        
    https://orderly.network/docs/build-on-omnichain/evm-api/restful-api/public/get-kline-history
    """
    check_required_parameters([[symbol, "symbol"], [resolution, "resolution"]])
    payload = {
        "symbol": symbol,
        "resolution": resolution,
        "from": from_timestamp,
        "to": to_timestamp,
        "limit": limit
    }
    return self._sign_request("GET", "/v1/tv/kline_history", payload=payload)
