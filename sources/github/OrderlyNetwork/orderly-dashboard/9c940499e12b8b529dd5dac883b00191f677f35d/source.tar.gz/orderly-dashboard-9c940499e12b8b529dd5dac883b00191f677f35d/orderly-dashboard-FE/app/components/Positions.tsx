import {
  ClipboardCopyIcon,
  MixerHorizontalIcon,
  MagnifyingGlassIcon,
  Cross2Icon
} from '@radix-ui/react-icons';
import { Button, Popover, Table, Tooltip, Dialog } from '@radix-ui/themes';
import { Link } from '@remix-run/react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  PaginationState,
  useReactTable
} from '@tanstack/react-table';
import { useMemo, useState, FC, useCallback } from 'react';

import { Spinner } from '~/components';
import {
  useBrokers,
  useSymbols,
  useAllSymbols,
  getSymbolName,
  getSymbolBaseTick,
  getSymbolQuoteTick,
  getMaxFractionDigits,
  useSearchAddress
} from '~/hooks';
import { usePositions, PositionsParams } from '~/hooks/usePositions';
import { getBaseToken, getBroker } from '~/hooks/useSymbols';
import { PositionEntry, PositionsResponse } from '~/types/leaderboard';
import { base64UrlSafeEncode } from '~/util';
import { formatPriceByTick } from '~/utils/format';

const defaultVisibility = {
  account_id: false,
  address: true,
  broker_id: false,
  symbol: true,
  holding: true,
  total_realized_pnl: false,
  index_price: false,
  mark_price: true,
  holding_value: true,
  opening_cost: false,
  average_entry_price: true,
  un_realized_pnl: true
};

const addressPageVisibility = {
  rank: false,
  account_id: false,
  address: false,
  broker_id: false,
  symbol: true,
  holding: true,
  total_realized_pnl: false,
  index_price: false,
  mark_price: true,
  holding_value: true,
  opening_cost: false,
  average_entry_price: true,
  un_realized_pnl: true
};

interface PositionsProps {
  accountId?: string;
  hideFilters?: boolean;
  hideTitle?: boolean;
  hideQuickActions?: boolean;
}

export const Positions: FC<PositionsProps> = ({
  accountId,
  hideFilters = false,
  hideTitle = false,
  hideQuickActions = false
}) => {
  const [queryParams, setQueryParams] = useState<PositionsParams>({
    offset: 0,
    limit: 30,
    order_by: 'DESC',
    ...(accountId && { account_id: accountId })
  });

  const [accountIdInput, setAccountIdInput] = useState<string>('');
  const [addressInput, setAddressInput] = useState<string>('');
  const [showAddressModal, setShowAddressModal] = useState<boolean>(false);
  const [showClosedPositions, setShowClosedPositions] = useState<boolean>(false);
  const [searchedAddress, setSearchedAddress] = useState<string>('');

  const { addressData, loading: addressLoading } = useSearchAddress(searchedAddress || null);

  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 30
  });

  const { data, error, isLoading } = usePositions(queryParams);
  const { data: brokers } = useBrokers();
  const symbols = useSymbols();
  const allSymbols = useAllSymbols();

  const [previousData, setPreviousData] = useState<PositionsResponse | null>(null);

  useMemo(() => {
    if (data) {
      setPreviousData(data);
    }
  }, [data]);

  const displayData = isLoading && previousData ? previousData : data;

  const filteredData = useMemo(() => {
    if (!displayData) return displayData;

    if (!showClosedPositions) {
      return {
        ...displayData,
        rows: displayData.rows.filter((row) => parseFloat(row.holding) !== 0)
      };
    }

    return displayData;
  }, [displayData, showClosedPositions]);

  const hasClosedPositions = useMemo(() => {
    if (!displayData) return false;
    return displayData.rows.some((row) => parseFloat(row.holding) === 0);
  }, [displayData]);

  useMemo(() => {
    if (
      addressData &&
      addressData.length > 0 &&
      addressData.filter((account) => (account.perp_volume || 0) > 0).length > 0
    ) {
      setShowAddressModal(true);
    }
  }, [addressData]);

  const handleInputChange = useCallback((field: keyof PositionsParams, value: string | number) => {
    setQueryParams((prev) => ({
      ...prev,
      [field]: value,
      ...(field !== 'offset' && field !== 'limit' && { offset: 0 })
    }));
  }, []);

  const handleAccountIdChange = useCallback(
    (value: string) => {
      setAccountIdInput(value);
      handleInputChange('account_id', value);
    },
    [handleInputChange]
  );

  const formatNumber = useCallback(
    (value: string | number, symbolHash?: string, maxFractionDigitsOverride?: number) => {
      const numValue = typeof value === 'string' ? parseFloat(value) : value;
      const maxFractionDigits =
        maxFractionDigitsOverride ??
        (symbolHash ? getMaxFractionDigits(getSymbolBaseTick(symbolHash, symbols)) : 2);
      return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: maxFractionDigits
      }).format(numValue);
    },
    [symbols]
  );

  const formatNumberShort = (value: string | number) => {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      maximumFractionDigits: 3,
      minimumFractionDigits: 0
    }).format(numValue);
  };

  const formatAddress = (address: string | undefined) => {
    if (!address) return '-';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  const formatSymbol = useCallback(
    (symbolHash: string) => getSymbolName(symbolHash, symbols, allSymbols),
    [symbols, allSymbols]
  );

  const isValidAddress = (address: string): boolean => {
    const evmPattern = /^0x[a-fA-F0-9]{40}$/;
    const solPattern = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
    const accountIdPattern = /^0x[a-fA-F0-9]{64}$/;

    return evmPattern.test(address) || solPattern.test(address) || accountIdPattern.test(address);
  };

  const isAccountId = (address: string): boolean => {
    return /^0x[a-fA-F0-9]{64}$/.test(address);
  };

  const handleAddressChange = (value: string) => {
    setAddressInput(value);
    if (isValidAddress(value)) {
      if (isAccountId(value)) {
        handleAccountIdChange(value);
        setSearchedAddress('');
      } else {
        setSearchedAddress(value);
      }
    } else {
      setSearchedAddress('');
    }
  };

  const columns = useMemo<ColumnDef<PositionEntry>[]>(
    () => [
      {
        accessorKey: 'rank',
        header: 'Rank',
        cell: ({ row }) => {
          const index = row.index;
          const offset = queryParams.offset || 0;
          return offset + index + 1;
        },
        enableSorting: false
      },
      {
        accessorKey: 'address',
        header: 'Address',
        cell: ({ row }) =>
          row.original.address ? (
            <div className="flex items-center gap-1">
              <Link
                to={
                  row.original.broker_id
                    ? `/address/${row.original.address}?broker_id=${row.original.broker_id}`
                    : (() => {
                        const isSol = row.original.address.match(/^[0-9a-zA-Z]{43,44}$/);
                        if (isSol) {
                          return `/search?q=${base64UrlSafeEncode(row.original.address)}&chain_namespace=sol`;
                        } else {
                          return `/search?q=${row.original.address}&chain_namespace=evm`;
                        }
                      })()
                }
                className="font-address text-sm"
              >
                {formatAddress(row.original.address)}
              </Link>
              {!hideQuickActions && (
                <>
                  <Tooltip content="Copy address">
                    <ClipboardCopyIcon
                      className="w-3 h-3 text-gray-400 hover:text-white cursor-pointer"
                      onClick={() => navigator.clipboard.writeText(row.original.address)}
                    />
                  </Tooltip>
                  <Tooltip content="Filter by this address">
                    <MagnifyingGlassIcon
                      className="w-3 h-3 text-gray-400 hover:text-blue-400 cursor-pointer"
                      onClick={() => handleAccountIdChange(row.original.account_id)}
                    />
                  </Tooltip>
                </>
              )}
            </div>
          ) : (
            <span className="font-address text-sm">-</span>
          ),
        enableSorting: false
      },
      {
        accessorKey: 'account_id',
        header: 'Account ID',
        cell: ({ row }) =>
          row.original.account_id ? (
            <div className="flex items-center gap-1">
              <Link to={`/address/${row.original.account_id}`} className="font-address text-sm">
                {formatAddress(row.original.account_id)}
              </Link>
              {!hideQuickActions && (
                <>
                  <Tooltip content="Copy account ID">
                    <ClipboardCopyIcon
                      className="w-3 h-3 text-gray-400 hover:text-white cursor-pointer"
                      onClick={() => navigator.clipboard.writeText(row.original.account_id)}
                    />
                  </Tooltip>
                  <Tooltip content="Filter by this account ID">
                    <MagnifyingGlassIcon
                      className="w-3 h-3 text-gray-400 hover:text-blue-400 cursor-pointer"
                      onClick={() => handleAccountIdChange(row.original.account_id)}
                    />
                  </Tooltip>
                </>
              )}
            </div>
          ) : (
            <span className="font-address text-sm">-</span>
          ),
        enableSorting: false
      },
      {
        accessorKey: 'symbol',
        header: 'Symbol',
        cell: ({ row }) => {
          const symbol = formatSymbol(row.original.symbol_hash) || row.original.symbol;
          const baseToken = getBaseToken(symbol);
          const broker = getBroker(symbol);
          return (
            <div className="flex items-center gap-1.5">
              <span className="font-mono text-sm">{baseToken}</span>
              {broker && (
                <span
                  className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium leading-none"
                  style={{
                    background: 'rgba(156,117,255,0.15)',
                    color: '#D4B2FF',
                    border: '1px solid rgba(156,117,255,0.25)'
                  }}
                >
                  {broker}
                </span>
              )}
              {!hideQuickActions && (
                <Tooltip content="Filter by this symbol">
                  <MagnifyingGlassIcon
                    className="w-3 h-3 text-gray-400 hover:text-blue-400 cursor-pointer"
                    onClick={() => handleInputChange('symbol', row.original.symbol)}
                  />
                </Tooltip>
              )}
            </div>
          );
        },
        enableSorting: false
      },
      {
        accessorKey: 'holding',
        header: 'Holding',
        cell: ({ row }) => (
          <span style={{ color: parseFloat(row.original.holding) >= 0 ? '#00dea3' : '#FF6390' }}>
            {formatNumber(row.original.holding, row.original.symbol_hash)}
          </span>
        ),
        enableSorting: false
      },
      {
        accessorKey: 'holding_value',
        header: 'Holding Value',
        cell: ({ row }) => formatNumberShort(row.original.holding_value),
        enableSorting: false
      },
      {
        accessorKey: 'total_realized_pnl',
        header: (
          <Tooltip content="Aggregated realized PnL across all historical positions for this symbol">
            <span className="cursor-help">Realized PnL</span>
          </Tooltip>
        ) as unknown as string,
        cell: ({ row }) => (
          <span
            style={{
              color: parseFloat(row.original.total_realized_pnl) >= 0 ? '#00dea3' : '#FF6390'
            }}
          >
            {formatNumberShort(row.original.total_realized_pnl)}
          </span>
        ),
        enableSorting: false
      },
      {
        accessorKey: 'un_realized_pnl',
        header: 'Unrealized PnL',
        cell: ({ row }) => (
          <span
            style={{ color: parseFloat(row.original.un_realized_pnl) >= 0 ? '#00dea3' : '#FF6390' }}
          >
            {formatNumberShort(row.original.un_realized_pnl)}
          </span>
        ),
        enableSorting: false
      },
      {
        accessorKey: 'index_price',
        header: 'Index Price',
        cell: ({ row }) =>
          formatPriceByTick(
            row.original.index_price,
            getSymbolQuoteTick(row.original.symbol_hash, symbols)
          ),
        enableSorting: false
      },
      {
        accessorKey: 'mark_price',
        header: 'Mark Price',
        cell: ({ row }) =>
          formatPriceByTick(
            row.original.mark_price,
            getSymbolQuoteTick(row.original.symbol_hash, symbols)
          ),
        enableSorting: false
      },
      {
        accessorKey: 'average_entry_price',
        header: 'Avg Entry Price',
        cell: ({ row }) =>
          formatPriceByTick(
            row.original.average_entry_price,
            getSymbolQuoteTick(row.original.symbol_hash, symbols)
          ),
        enableSorting: false
      },
      {
        accessorKey: 'broker_id',
        header: 'Broker ID',
        cell: ({ row }) => (
          <div className="flex items-center gap-1">
            <span>{row.original.broker_id || '-'}</span>
            {!hideQuickActions && (
              <Tooltip content="Filter by this broker">
                <MagnifyingGlassIcon
                  className="w-3 h-3 text-gray-400 hover:text-blue-400 cursor-pointer"
                  onClick={() => handleInputChange('broker_id', row.original.broker_id)}
                />
              </Tooltip>
            )}
          </div>
        ),
        enableSorting: false
      }
    ],
    [
      queryParams.offset,
      hideQuickActions,
      handleAccountIdChange,
      formatSymbol,
      handleInputChange,
      formatNumber,
      symbols
    ]
  );

  const table = useReactTable<PositionEntry>({
    data: filteredData?.rows ?? [],
    columns,
    state: {
      pagination
    },
    initialState: {
      columnVisibility: hideQuickActions ? addressPageVisibility : defaultVisibility
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onPaginationChange: setPagination
  });

  const handlePageChange = (newOffset: number) => {
    setQueryParams((prev) => ({
      ...prev,
      offset: newOffset
    }));
  };

  const currentPage = Math.floor((queryParams.offset || 0) / (queryParams.limit || 30)) + 1;
  const hasMoreData = filteredData?.rows.length === (queryParams.limit || 30);

  if (error) {
    return (
      <div className="flex flex-col gap-4 flex-items-center [&>*]:w-full [&>*]:max-w-full lg:max-w-[50rem] px-2 sm:px-0">
        <h2 className="mb-2 text-lg sm:text-xl">Positions</h2>
        <div className="text-red-500">Error: {error.message}</div>
      </div>
    );
  }

  const renderPagination = () => {
    const limit = queryParams.limit || 30;
    const isPrevDisabled = !filteredData || (queryParams.offset || 0) <= 0;
    const isNextDisabled = !filteredData || !hasMoreData;

    const endPage = currentPage + (hasMoreData ? 2 : 0);
    const startPage = Math.max(1, endPage - 4);
    const pages = Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i);

    return (
      <div
        className="flex flex-row items-center justify-center gap-2 p-4 rounded-xl"
        style={{ background: '#130E1D' }}
      >
        {!isPrevDisabled && (
          <button
            onClick={() => handlePageChange((currentPage - 2) * limit)}
            style={{
              background: 'none',
              border: 'none',
              color: 'rgba(255,255,255,0.55)',
              cursor: 'pointer',
              fontSize: 18,
              padding: '0 4px',
              lineHeight: 1
            }}
          >
            {'<'}
          </button>
        )}

        {pages.map((page) => (
          <button
            key={page}
            onClick={() => handlePageChange((page - 1) * limit)}
            style={{
              width: 36,
              height: 36,
              borderRadius: 8,
              background: page === currentPage ? '#6700CE' : '#221E30',
              color: '#ffffff',
              border: 'none',
              cursor: page === currentPage ? 'default' : 'pointer',
              fontSize: 15,
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            {page}
          </button>
        ))}

        {!isNextDisabled && (
          <button
            onClick={() => handlePageChange(currentPage * limit)}
            style={{
              background: 'none',
              border: 'none',
              color: 'rgba(255,255,255,0.55)',
              cursor: 'pointer',
              fontSize: 18,
              padding: '0 4px',
              lineHeight: 1
            }}
          >
            {'>'}
          </button>
        )}

        <div className="flex items-center gap-2" style={{ marginLeft: 12 }}>
          <span style={{ color: 'rgba(255,255,255,0.45)', fontSize: 13 }}>Go to</span>
          <input
            type="number"
            defaultValue={currentPage}
            onChange={(e) => {
              const page = e.target.value ? Number(e.target.value) : 1;
              handlePageChange((page - 1) * limit);
            }}
            className="lb-input w-14 px-2 py-1 text-center text-sm"
            style={{ background: '#221E30', border: 'none' }}
            min="1"
          />
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4 sm:space-y-8 animate-fade-in flex flex-col align-center">
      {!hideTitle && (
        <div className="text-center space-y-2 sm:space-y-4">
          <h2 className="text-2xl font-bold text-white">Positions</h2>
          <p className="text-gray-300 max-w-3xl mx-auto">
            Track positions across different addresses, accounts, and brokers. View holding values,
            realized and unrealized PnL with customizable filters. Shows current position data for
            each symbol, including closed positions. Realized PnL is aggregated across all
            historical positions for each symbol.
          </p>
        </div>
      )}

      <div
        className="card w-full space-y-4 sm:space-y-6"
        style={{ background: '#130E1D', border: 'none' }}
      >
        {/* Filters Section */}
        {!hideFilters && (
          <div className="space-y-4 sm:space-y-6 w-full">
            {/* Additional Filters */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label htmlFor="broker-id" className="text-sm font-medium text-white">
                  Broker ID
                </label>
                <select
                  id="broker-id"
                  value={queryParams.broker_id || ''}
                  onChange={(e) => handleInputChange('broker_id', e.target.value)}
                  className="lb-input w-full"
                  style={{ background: '#221E30', border: 'none' }}
                >
                  <option value="">All brokers</option>
                  {brokers?.map((broker) => (
                    <option key={broker.broker_id} value={broker.broker_id}>
                      {broker.broker_name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label htmlFor="symbol-input" className="text-sm font-medium text-white">
                  Symbol
                </label>
                <select
                  id="symbol-input"
                  value={queryParams.symbol || ''}
                  onChange={(e) => handleInputChange('symbol', e.target.value)}
                  className="lb-input w-full"
                  style={{ background: '#221E30', border: 'none' }}
                >
                  <option value="">All symbols</option>
                  {symbols?.map((symbol) => {
                    const baseToken = getBaseToken(symbol.symbol);
                    const broker = getBroker(symbol.symbol);
                    return (
                      <option key={symbol.symbol} value={symbol.symbol}>
                        {broker ? `${baseToken} · ${broker}` : baseToken}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div className="space-y-2">
                <label htmlFor="address-input" className="text-sm font-medium text-white">
                  Address
                </label>
                <div className="relative">
                  <input
                    id="address-input"
                    type="text"
                    placeholder="Enter EVM/Solana address or Account ID"
                    value={addressInput}
                    onChange={(e) => handleAddressChange(e.target.value)}
                    className="lb-input w-full pr-10"
                    style={{ background: '#221E30', border: 'none' }}
                  />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    {addressLoading && <Spinner size="1rem" />}
                    {!addressLoading &&
                      searchedAddress &&
                      addressData &&
                      addressData.filter((account) => (account.perp_volume || 0) > 0).length ===
                        0 && <Cross2Icon className="w-4 h-4 text-red-400" />}
                  </div>
                </div>
              </div>
              {accountIdInput && (
                <div className="space-y-2">
                  <div className="text-sm font-medium text-white">Account ID Filter</div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={accountIdInput}
                      readOnly
                      className="lb-input flex-1 text-gray-300 cursor-not-allowed"
                      style={{ background: '#221E30', border: 'none' }}
                    />
                    <button
                      onClick={() => handleAccountIdChange('')}
                      className="btn btn-secondary px-3"
                    >
                      Clear
                    </button>
                  </div>
                </div>
              )}
              <div className="space-y-2" style={{ display: 'none' }}>
                <label htmlFor="account-id-input" className="text-sm font-medium text-white">
                  Account ID
                </label>
                <input
                  id="account-id-input"
                  type="text"
                  placeholder="Enter account ID"
                  value={accountIdInput}
                  onChange={(e) => {
                    handleAccountIdChange(e.target.value);
                  }}
                  className="lb-input w-full"
                  style={{ background: '#221E30', border: 'none' }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Table Section */}
        <div className="w-full">
          {!filteredData ? (
            <div className="flex justify-center py-12 w-full">
              <Spinner size="2.5rem" />
            </div>
          ) : (
            <div className="space-y-2">
              {/* Closed Positions Filter - always visible when closed positions exist */}
              {hasClosedPositions && (
                <div className="flex justify-start pb-0! p-3 sm:p-4">
                  <div className="flex items-center gap-2">
                    <input
                      id="show-closed-positions"
                      type="checkbox"
                      checked={showClosedPositions}
                      onChange={(e) => setShowClosedPositions(e.target.checked)}
                      className="rounded"
                    />
                    <label
                      htmlFor="show-closed-positions"
                      className="text-sm font-medium text-white"
                    >
                      Show closed positions
                    </label>
                  </div>
                </div>
              )}

              {filteredData.rows.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <p>
                    No {!showClosedPositions && hasClosedPositions ? 'open ' : ''}positions found
                    for the selected criteria.
                  </p>
                  {!showClosedPositions && hasClosedPositions && (
                    <p className="text-sm mt-1">
                      Enable &ldquo;Show closed positions&rdquo; above to view all positions.
                    </p>
                  )}
                </div>
              ) : (
                <>
                  {/* Column Filters */}
                  <div className="flex justify-start pb-0! p-3 sm:p-4">
                    <Popover.Root>
                      <Popover.Trigger className="w-auto">
                        <Button variant="soft" className="btn btn-secondary">
                          <MixerHorizontalIcon width="16" height="16" />
                          Column Filters
                        </Button>
                      </Popover.Trigger>
                      <Popover.Content
                        width="20rem"
                        maxHeight="26rem"
                        className="max-w-[90vw] card"
                      >
                        <div className="flex flex-col gap-2">
                          <div className="flex gap-2">
                            <Button
                              onClick={() => {
                                table.resetColumnVisibility();
                              }}
                              className="btn btn-primary"
                            >
                              Reset to default
                            </Button>
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={table.getIsAllColumnsVisible()}
                              onChange={table.getToggleAllColumnsVisibilityHandler()}
                              className="rounded"
                            />
                            <label htmlFor="toggle-all" className="text-sm text-white">
                              Toggle All
                            </label>
                          </div>
                          <hr className="w-full border-border-primary" />
                          {table.getAllLeafColumns().map((column) => {
                            return (
                              <div key={column.id} className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={column.getIsVisible()}
                                  onChange={column.getToggleVisibilityHandler()}
                                  className="rounded"
                                />
                                <label className="text-sm text-white">
                                  {
                                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                    flexRender(column.columnDef.header, undefined as any)
                                  }{' '}
                                  ({column.id})
                                </label>
                              </div>
                            );
                          })}
                        </div>
                      </Popover.Content>
                    </Popover.Root>
                  </div>

                  <div className="w-full overflow-x-auto relative">
                    {isLoading && (
                      <div className="absolute inset-0 bg-bg-overlay flex items-center justify-center z-10 rounded-xl">
                        <Spinner size="2rem" />
                      </div>
                    )}
                    <Table.Root className="w-full">
                      <Table.Header>
                        {table.getHeaderGroups().map((headerGroup) => (
                          <Table.Row
                            key={headerGroup.id}
                            className="border-b border-border-primary"
                          >
                            {headerGroup.headers.map((header) => (
                              <Table.ColumnHeaderCell
                                key={header.id}
                                colSpan={header.colSpan}
                                className="py-2 px-2 sm:py-4 sm:px-4"
                              >
                                {header.isPlaceholder ? null : (
                                  <div
                                    className={
                                      header.column.getCanSort()
                                        ? 'cursor-pointer select-none hover:text-primary-light transition-colors duration-150 text-sm font-medium'
                                        : 'text-sm font-medium'
                                    }
                                    onClick={header.column.getToggleSortingHandler()}
                                    onKeyDown={(ev) => {
                                      if (ev.key === 'Enter') {
                                        header.column.getToggleSortingHandler();
                                      }
                                    }}
                                    role="button"
                                    tabIndex={0}
                                  >
                                    {flexRender(
                                      header.column.columnDef.header,
                                      header.getContext()
                                    )}
                                    {{
                                      asc: ' 🔼',
                                      desc: ' 🔽'
                                    }[header.column.getIsSorted() as string] ?? null}
                                  </div>
                                )}
                              </Table.ColumnHeaderCell>
                            ))}
                          </Table.Row>
                        ))}
                      </Table.Header>

                      <Table.Body>
                        {table.getRowModel().rows.map((row, index) => (
                          <Table.Row
                            key={row.id}
                            className={`border-b border-border-primary hover:bg-bg-tertiary transition-colors duration-150 ${
                              index % 2 === 0 ? 'bg-bg-secondary' : 'bg-bg-primary'
                            }`}
                          >
                            {row.getVisibleCells().map((cell) => (
                              <Table.Cell
                                key={cell.id}
                                className="align-middle text-sm py-2 px-2 sm:py-3 sm:px-4"
                              >
                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                              </Table.Cell>
                            ))}
                          </Table.Row>
                        ))}
                      </Table.Body>
                    </Table.Root>
                  </div>

                  {renderPagination()}
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Address Search Modal */}
      <Dialog.Root open={showAddressModal} onOpenChange={setShowAddressModal}>
        <Dialog.Content className="card max-w-4xl w-full sm:w-[95vw] max-h-[90vh] mx-0 sm:mx-auto flex flex-col">
          <Dialog.Title className="text-lg sm:text-xl font-semibold text-white mb-4 break-all flex-shrink-0">
            Search Results for {addressInput}
          </Dialog.Title>

          {addressLoading ? (
            <div className="flex justify-center py-8 flex-1">
              <Spinner size="2rem" />
            </div>
          ) : addressData && addressData.length > 0 ? (
            <div className="flex flex-col flex-1 min-h-0">
              <p className="text-sm sm:text-base text-gray-300 mb-4 flex-shrink-0">
                Found {addressData.filter((account) => (account.perp_volume || 0) > 0).length}{' '}
                account(s) with trading volume
              </p>
              <div className="grid grid-cols-1 gap-3 overflow-y-auto flex-1">
                {addressData
                  .filter((account) => (account.perp_volume || 0) > 0)
                  .map((data) => (
                    <button
                      key={`${data.broker_id}-${data.account_id}`}
                      className="card p-3 sm:p-4 hover:bg-bg-tertiary transition-colors cursor-pointer text-left w-full"
                      onClick={() => {
                        handleAccountIdChange(data.account_id);
                        setShowAddressModal(false);
                      }}
                    >
                      <div className="space-y-2 sm:space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs sm:text-sm text-gray-400">Broker ID</span>
                          <span className="text-xs px-2 py-1 bg-primary rounded-full text-white">
                            {data.broker_id}
                          </span>
                        </div>
                        <div className="text-base sm:text-lg font-semibold text-white">
                          {data.broker_id}
                          {(() => {
                            const accountsForThisBroker = addressData.filter(
                              (account) => account.broker_id === data.broker_id
                            );
                            return accountsForThisBroker.length > 1 && data.user_type ? (
                              <span className="text-sm text-gray-400 ml-2 font-normal">
                                (
                                {data.user_type === 'MAIN'
                                  ? 'main'
                                  : data.user_type === 'SUB'
                                    ? 'sub'
                                    : data.user_type.toLowerCase()}
                                )
                              </span>
                            ) : null;
                          })()}
                        </div>
                        <div className="space-y-2">
                          <span className="text-xs sm:text-sm text-gray-400">Account ID</span>
                          <div className="font-address text-xs sm:text-sm bg-bg-primary p-2 rounded border border-border-primary break-all">
                            {data.account_id.substring(0, 7)}...{data.account_id.substr(-7)}
                          </div>
                        </div>
                        <div className="space-y-2 pt-2 border-t border-border-primary">
                          <div className="flex justify-between items-center">
                            <span className="text-xs sm:text-sm text-gray-400">Trading Volume</span>
                            <span className="text-xs sm:text-sm font-semibold text-white">
                              {formatNumberShort(data.perp_volume || 0)}
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-xs sm:text-sm text-gray-400">Realized PnL</span>
                            <span
                              className={`text-xs sm:text-sm font-semibold ${
                                (data.realized_pnl || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                              }`}
                            >
                              {formatNumberShort(data.realized_pnl || 0)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 flex-1">
              <div className="text-lg sm:text-xl text-gray-300 mb-2">No Results Found</div>
              <div className="text-sm sm:text-base text-gray-400">
                No accounts with trading volume found for this address
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 mt-6 flex-shrink-0">
            <button onClick={() => setShowAddressModal(false)} className="btn btn-secondary">
              Close
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Root>
    </div>
  );
};
