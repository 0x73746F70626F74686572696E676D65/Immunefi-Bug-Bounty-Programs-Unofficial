import useSWR from 'swr';

import { fetchDataApi } from '~/services/orderly';

function useFetch<T>(path: string) {
  return useSWR<T>(path, () => fetchDataApi<T>(path), {
    revalidateOnFocus: false,
    shouldRetryOnError: false
  });
}

// ── Types ─────────────────────────────────────────────────────────────────────

// /data/summary — returns auth session info only
export type DataSummary = {
  user_id?: number;
  username?: string;
  email?: string;
  mysql_source?: string;
  pg_source?: string;
  logs?: string[];
  [key: string]: unknown;
};

// /data/broker/liquidation_fees — requires broker_id query param
export type BrokerLiquidationFees = {
  success?: boolean;
  code?: number;
  message?: string;
  data?: null;
  [key: string]: unknown;
};

// /distributors/stats — direct array (no wrapper object)
export type DistributorRow = {
  'Distributor ID'?: string;
  'Distributor Type'?: string;
  'Distributor Name'?: string;
  'Number of Invitees'?: number;
  'Number of Graduated Invitees'?: number;
  'Total Revenue Share'?: number;
  '30D Revenue Share'?: number;
  '30D Invitee Volume'?: number;
  'Fee Tier'?: string;
  [key: string]: unknown;
};
export type DistributorStats = DistributorRow[];

// /distributors/invitees — direct array (no wrapper object)
export type DistributorInviteeRow = {
  'Date Invited'?: string;
  'Invitee DEX'?: string;
  'Distributor ID'?: string;
  is_orderly_one?: string;
  'DEX link'?: string;
  'DEX status'?: string;
  '30D Invitee Volume'?: number;
  '30D Revenue Share'?: number;
  [key: string]: unknown;
};
export type DistributorInvitees = DistributorInviteeRow[];

// /metrics/dex-users — per-broker current snapshot
export type DexUsersBroker = {
  broker_id?: string;
  broker_name?: string;
  dau?: number;
  dau_date?: string;
  dau_dod_pct?: number;
  wau?: number;
  wau_wow_pct?: number;
  mau?: number;
  mau_mom_pct?: number;
  total_users?: number;
  new_users_today?: number;
  new_users_7d?: number;
  new_users_30d?: number;
  [key: string]: unknown;
};
export type DexUsers = { data?: DexUsersBroker[] };

// /metrics/overview — weekly & monthly aggregates
export type OverviewPeriod = {
  week_start?: string;
  week_start_date?: string;
  week_end_date?: string;
  month_start?: string;
  month_start_date?: string;
  month_end_date?: string;
  avg_new_user?: number;
  avg_active_user?: number;
  avg_trading_volume?: number;
  avg_orderly_revenue?: number;
  [key: string]: unknown;
};
export type MetricsOverview = { weekly?: OverviewPeriod[]; monthly?: OverviewPeriod[] };

// /metrics/volume-segments — weekly by mm_retail type
export type VolumeSegmentRow = {
  week_start?: string;
  week_start_date?: string;
  week_end_date?: string;
  mm_retail?: string;
  volume?: number;
  pct?: number;
  [key: string]: unknown;
};
export type VolumeSegments = { weekly?: VolumeSegmentRow[] };

// /metrics/stake-users — weekly avg active stakers
export type StakeUsersWeek = {
  wk?: string;
  avg_active_stakers?: number;
  week_start?: string;
  week_end?: string;
  [key: string]: unknown;
};
export type StakeUsers = { weekly?: StakeUsersWeek[] };

// /metrics/stake-vs-supply — weekly ORDER staking vs circulating supply
export type StakeVsSupplyWeek = {
  wk?: string;
  stake_order?: number;
  circulating_supply?: number;
  stake_order_perc_avg?: number;
  week_start?: string;
  week_end?: string;
  wow_growth_rate_percent?: number;
  [key: string]: unknown;
};
export type StakeVsSupply = { weekly?: StakeVsSupplyWeek[] };

// /metrics/omnivault-tvl — weekly TVL per vault (in millions USD)
export type OmnivaultTvlRow = {
  wk?: string;
  vault_name?: string;
  avg_vault_tvl_m?: number;
  week_start?: string;
  week_end?: string;
  [key: string]: unknown;
};
export type OmnivaultTvl = { weekly?: OmnivaultTvlRow[] };

// /dashboard/orderly/by-broker — daily per-broker metrics
export type BrokerDailyRow = {
  date: string;
  broker_id: string;
  taker_volume: number;
  maker_volume: number;
  total_volume: number;
  active_users: number;
  broker_fee_usd: number;
  net_flow_usd: number;
  [key: string]: unknown;
};
export type BrokerDailyResponse = { rows: BrokerDailyRow[] };

// /dashboard/fund-flows/by-broker — daily per-broker fund flows
export type FundFlowBrokerRow = {
  date: string;
  broker_id: string;
  deposits_usd: number;
  withdrawals_usd: number;
  net_flow_usd: number;
  [key: string]: unknown;
};
export type FundFlowBrokerResponse = { rows: FundFlowBrokerRow[] };

// /dashboard/orderly/by-symbol/daily — daily per-symbol metrics
export type SymbolDailyRow = {
  date: string;
  symbol_type: string;
  symbol: string;
  liquidation_notional_usd?: number | null;
  token_balance?: number | null;
  tvl_usd?: number | null;
  [key: string]: unknown;
};
export type SymbolDailyResponse = { rows: SymbolDailyRow[] };

// /dashboard/orderly/funding-rates — 8h funding rates per perp symbol
export type FundingRateRow = {
  funding_time: string;
  symbol: string;
  funding_rate: number;
  [key: string]: unknown;
};
export type FundingRatesResponse = { rows: FundingRateRow[] };

// /dashboard/staking/daily — daily $ORDER staking metrics
export type StakingDailyRow = {
  date: string;
  staked_order: number;
  unstaked_order: number;
  net_staked_order: number;
  cumulative_staked_order: number;
  daily_active_addresses: number;
  cumulative_staker_addresses: number;
  current_valor_balance: number;
  total_burned_valor: number;
  total_emitted_valor: number;
  daily_burned_order: number;
  cumulative_burned_order: number;
  active_stakers_snapshot: number;
  daily_buyback_order: number;
  daily_buyback_usdc_spent: number;
  cumulative_buyback_order: number;
  cumulative_buyback_usdc_spent: number;
  [key: string]: unknown;
};
export type StakingDailyResponse = { rows: StakingDailyRow[] };

// /dashboard/fund-flows/by-chain — daily fund flows per chain
export type FundFlowChainRow = {
  date: string;
  chain: string;
  deposits_usd: number;
  withdrawals_usd: number;
  net_flow_usd: number;
  [key: string]: unknown;
};
export type FundFlowChainResponse = { rows: FundFlowChainRow[] };

// /dashboard/orderly/by-symbol/daily?symbol_type=perp — daily perp liquidations
export type PerpSymbolDailyRow = {
  date: string;
  symbol_type: string;
  symbol: string;
  liquidation_notional_usd: number | null;
  [key: string]: unknown;
};
export type PerpSymbolDailyResponse = { rows: PerpSymbolDailyRow[] };

// /dashboard/orderly/by-symbol/weekly — weekly per-symbol volume
export type SymbolWeeklyRow = {
  as_of_date: string;
  trade_week: string;
  symbol: string;
  volume_usd: number | null;
  listed_markets_count?: number | null;
  [key: string]: unknown;
};
export type SymbolWeeklyResponse = { rows: SymbolWeeklyRow[] };

// ── Hooks ─────────────────────────────────────────────────────────────────────

/** Build `start_date=YYYY-MM-DD&end_date=YYYY-MM-DD` for the last `days` days. */
function dateRangeQuery(days: number): string {
  const end = new Date();
  const start = new Date();
  start.setDate(start.getDate() - days);
  const fmt = (d: Date) => d.toISOString().slice(0, 10);
  return `start_date=${fmt(start)}&end_date=${fmt(end)}`;
}

export const useDataSummary = () => useFetch<DataSummary>('/orderly/api/v1/data/summary');

export const useBrokerLiquidationFees = () =>
  useFetch<BrokerLiquidationFees>('/orderly/api/v1/data/broker/liquidation_fees');

export const useDistributorStats = () =>
  useFetch<DistributorStats>('/orderly/api/v1/distributors/stats');

export const useDistributorInvitees = () =>
  useFetch<DistributorInvitees>('/orderly/api/v1/distributors/invitees');

export const useDexUsers = () => useFetch<DexUsers>('/orderly/api/v1/metrics/dex-users');

export const useMetricsOverview = () =>
  useFetch<MetricsOverview>('/orderly/api/v1/metrics/overview');

export const useVolumeSegments = () =>
  useFetch<VolumeSegments>('/orderly/api/v1/metrics/volume-segments');

export const useStakeUsers = () => useFetch<StakeUsers>('/orderly/api/v1/metrics/stake-users');

export const useStakeVsSupply = () =>
  useFetch<StakeVsSupply>('/orderly/api/v1/metrics/stake-vs-supply');

export const useOmnivaultTvl = () =>
  useFetch<OmnivaultTvl>('/orderly/api/v1/metrics/omnivault-tvl');

export const useBrokerDaily = (days = 30) =>
  useFetch<BrokerDailyResponse>(
    `/orderly/api/v1/dashboard/orderly/by-broker?exclude_zero_volume=true&${dateRangeQuery(days)}`
  );

export const useFundFlowsByBroker = (days = 30) =>
  useFetch<FundFlowBrokerResponse>(
    `/orderly/api/v1/dashboard/fund-flows/by-broker?${dateRangeQuery(days)}`
  );

export const useTokenTvl = (days = 30) =>
  useFetch<SymbolDailyResponse>(
    `/orderly/api/v1/dashboard/orderly/by-symbol/daily?symbol_type=token&${dateRangeQuery(days)}`
  );

export const useFundingRates = () =>
  useFetch<FundingRatesResponse>('/orderly/api/v1/dashboard/orderly/funding-rates');

export const useFundingRatesRange = (days: number = 30) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  const startDate = d.toISOString().slice(0, 10);
  return useFetch<FundingRatesResponse>(
    `/orderly/api/v1/dashboard/orderly/funding-rates?start_date=${startDate}`
  );
};

export const useStakingDaily = () =>
  useFetch<StakingDailyResponse>('/orderly/api/v1/dashboard/staking/daily');

export const useFundFlowsByChain = () =>
  useFetch<FundFlowChainResponse>('/orderly/api/v1/dashboard/fund-flows/by-chain');

export const usePerpLiquidations = () =>
  useFetch<PerpSymbolDailyResponse>(
    '/orderly/api/v1/dashboard/orderly/by-symbol/daily?symbol_type=perp'
  );

export const useSymbolWeekly = () =>
  useFetch<SymbolWeeklyResponse>('/orderly/api/v1/dashboard/orderly/by-symbol/weekly');
