import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
  type ChartData,
  type ChartOptions
} from 'chart.js';
import { FC, useRef } from 'react';
import { Line } from 'react-chartjs-2';

import { baseLineOpts, baseTooltipOpts, useChartReady } from '../shared/chartConfig';
import { fmtCompact, labelFromDate } from '../shared/formatters';

import type { MainDailyRow } from '~/types/dashboard';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Filler,
  Tooltip
);

export const NetFeesWidget: FC<{ rows: MainDailyRow[] }> = ({ rows }) => {
  const chartRef = useRef<ChartJS<'line'>>(null);
  useChartReady(chartRef);
  const sliced = [...rows.slice(0, 90)].reverse();
  const data = {
    labels: sliced.map((r) => labelFromDate(r.date)),
    datasets: [
      {
        type: 'bar' as const,
        label: 'Net Fees',
        data: sliced.map((r) => r.daily_revenue_usd),
        backgroundColor: 'rgba(156,117,255,0.8)',
        borderWidth: 0,
        borderRadius: 3,
        yAxisID: 'yNet',
        order: 2
      },
      {
        type: 'line' as const,
        label: 'Total',
        data: sliced.map((r) => r.cumulative_revenue_usd),
        fill: false,
        backgroundColor: 'rgba(52,211,153,0.12)',
        borderColor: '#00dea3',
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.35,
        yAxisID: 'yTotal',
        order: 1
      }
    ]
  };
  const options: ChartOptions<'line'> = {
    ...baseLineOpts,
    plugins: {
      legend: {
        display: true,
        position: 'top',
        align: 'end',
        labels: {
          color: 'rgba(255,255,255,0.5)',
          font: { size: 10 },
          boxWidth: 10,
          boxHeight: 10,
          borderRadius: 2,
          useBorderRadius: true,
          padding: 12
        }
      },
      tooltip: {
        ...baseTooltipOpts,
        callbacks: {
          label: (ctx) => {
            const label = ctx.dataset.label ?? '';
            return ` ${label}: ${fmtCompact(ctx.raw as number)}`;
          }
        }
      }
    },
    scales: {
      x: {
        ...baseLineOpts.scales?.x,
        ticks: {
          color: 'rgba(255,255,255,0.3)',
          font: { size: 10 },
          maxTicksLimit: 8,
          maxRotation: 0
        }
      },
      yNet: {
        position: 'left',
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: {
          color: 'rgba(156,117,255,0.6)',
          font: { size: 10 },
          callback: (v) => fmtCompact(v as number)
        }
      },
      yTotal: {
        position: 'right',
        grid: { drawOnChartArea: false },
        ticks: {
          color: 'rgba(52,211,153,0.6)',
          font: { size: 10 },
          callback: (v) => fmtCompact(v as number)
        }
      }
    }
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: 220, overflow: 'hidden' }}>
      <Line ref={chartRef} data={data as ChartData<'line'>} options={options} />
    </div>
  );
};
