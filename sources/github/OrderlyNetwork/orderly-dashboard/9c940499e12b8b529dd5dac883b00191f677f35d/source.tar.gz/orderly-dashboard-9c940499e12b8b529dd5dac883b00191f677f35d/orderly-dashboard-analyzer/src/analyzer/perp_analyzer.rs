use std::cmp::max;

use bigdecimal::BigDecimal;
use chrono::NaiveDateTime;
use std::ops::Div;

use orderly_dashboard_indexer::formats_external::trading_events::{MarginMode, Trade};

use crate::analyzer::analyzer_context::AnalyzeContext;
use crate::analyzer::calc::pnl_calc::RealizedPnl;
use crate::analyzer::{get_cost_position_prec, get_qty_prec, get_unitary_prec};
use crate::db::hourly_orderly_perp::HourlyOrderlyPerpKey;
use crate::db::hourly_user_perp::HourlyUserPerpKey;
use crate::db::user_info::get_user_info;
use crate::db::user_perp_summary::UserPerpSummaryKey;

const PERP_ANALYZER: &str = "perp-trade-analyzer";

pub async fn analyzer_perp_trade(
    trades: Vec<Trade>,
    pulled_block_height: i64,
    context: &mut AnalyzeContext,
    tx: Option<tokio::sync::mpsc::Sender<String>>,
    block_hour: NaiveDateTime,
) -> i64 {
    if trades.is_empty() {
        return 0;
    }
    let mut max_perp_trade_id = 0i64;
    let trade_len = trades.len();
    for perp_trade in trades {
        if let Some(tx) = &tx {
            tx.try_send(perp_trade.account_id.clone()).ok();
        }
        max_perp_trade_id = max(max_perp_trade_id, perp_trade.trade_id as i64);

        let trade_qty: BigDecimal = perp_trade.trade_qty.parse().unwrap();
        let fixed_qty = trade_qty.div(get_qty_prec());

        let trade_fee: BigDecimal = perp_trade.fee.parse().unwrap();
        let fixed_fee = trade_fee.div(get_cost_position_prec());

        let notional: BigDecimal = perp_trade.notional.parse().unwrap();
        let fixed_notional = notional.div(get_cost_position_prec());
        let quoted_diff = -fixed_notional.clone();
        let trade_hour = block_hour;

        // hourly_orderly
        let hour_orderly_perp_key = HourlyOrderlyPerpKey {
            symbol: perp_trade.symbol_hash.clone(),
            block_hour: trade_hour.clone(),
        };
        {
            let hourly_orderly_perp = context
                .get_hourly_orderly_perp(&hour_orderly_perp_key)
                .await;
            hourly_orderly_perp.new_trade(
                fixed_fee.clone(),
                (fixed_notional.clone()).abs(),
                pulled_block_height.clone(),
                perp_trade.side,
            );
        }

        //orderly_summary
        let perp_symbol = perp_trade.symbol_hash.clone();
        {
            let orderly_perp_summary = context.get_orderly_perp(&perp_symbol).await;
            orderly_perp_summary.new_trade(
                (fixed_fee.clone()).abs(),
                (fixed_notional.clone()).abs(),
                pulled_block_height.clone(),
                perp_trade.side,
            );
        }
        let user_perp_summary_key = UserPerpSummaryKey {
            account_id: perp_trade.account_id.clone(),
            symbol: perp_symbol.clone(),
        };
        tracing::info!(target:PERP_ANALYZER,"handle_perp_trade, pulled_block_height: {}, account_id: {}, symbol: {}, margin_mode: {:?}",pulled_block_height,perp_trade.account_id,perp_symbol,perp_trade.margin_mode);
        let (opening, new_user, pnl_diff) = if perp_trade.margin_mode.is_none()
            || perp_trade.margin_mode == Some(MarginMode::Cross)
        {
            //user_summary
            let user_perp_snap = context.get_user_perp(&user_perp_summary_key).await;
            #[cfg(not(test))]
            if user_perp_snap.broker_id.is_empty() {
                match get_user_info(perp_trade.account_id.clone()).await {
                    Ok(Some(user_info)) => {
                        user_perp_snap.broker_id = user_info.broker_id;
                        user_perp_snap.address = user_info.address;
                    }
                    Ok(None) => {}
                    Err(err) => {
                        tracing::warn!(
                            target: PERP_ANALYZER,
                            "failed to query user_info for account_id {}, err: {}",
                            perp_trade.account_id,
                            err
                        );
                    }
                }
            }

            let suf: BigDecimal = perp_trade.sum_unitary_fundings.parse().unwrap();

            // should no check and update log idx for charge funding fee
            user_perp_snap.charge_funding_fee(suf.div(get_unitary_prec()), pulled_block_height);
            let (open_cost_diff, pnl_diff) = RealizedPnl::calc_realized_pnl(
                fixed_qty.clone(),
                quoted_diff.clone(),
                user_perp_snap.holding.clone(),
                user_perp_snap.opening_cost.clone(),
            );
            let (opening, new_user) = user_perp_snap.new_trade(
                fixed_fee.clone(),
                fixed_notional.clone(),
                pulled_block_height.clone(),
                open_cost_diff.clone(),
                fixed_qty.clone(),
                pnl_diff.clone(),
            );
            (opening, new_user, pnl_diff)
        } else {
            //user_iso_summary
            let user_perp_snap = context
                .get_iso_user_perp(&user_perp_summary_key.clone())
                .await;

            let suf: BigDecimal = perp_trade.sum_unitary_fundings.parse().unwrap();

            // should no check and update log idx for charge funding fee
            user_perp_snap.charge_funding_fee(suf.div(get_unitary_prec()), pulled_block_height);
            let need_cal_avg = perp_trade.is_insurance_account != Some(true);
            let (open_cost_diff, pnl_diff) = if need_cal_avg {
                RealizedPnl::calc_realized_pnl(
                    fixed_qty.clone(),
                    quoted_diff.clone(),
                    user_perp_snap.holding.clone(),
                    user_perp_snap.opening_cost.clone(),
                )
            } else {
                (BigDecimal::from(0), BigDecimal::from(0))
            };
            let (opening, new_user) = user_perp_snap.new_trade(
                fixed_fee.clone(),
                fixed_notional.clone(),
                pulled_block_height.clone(),
                open_cost_diff.clone(),
                fixed_qty.clone(),
                pnl_diff.clone(),
            );
            if let Some(margin_from_cross) = perp_trade.margin_from_cross {
                let margin_from_cross: BigDecimal = margin_from_cross.parse().unwrap();
                if margin_from_cross > BigDecimal::from(0) {
                    if let Some(iso_margin_asset_hash) = &perp_trade.iso_margin_asset_hash {
                        user_perp_snap.margin_token = iso_margin_asset_hash.to_string();
                        user_perp_snap.margin_qty =
                            user_perp_snap.margin_qty.clone() + margin_from_cross;
                    }
                }
            }
            (opening, new_user, pnl_diff)
        };
        if opening {
            context
                .get_hourly_orderly_perp(&hour_orderly_perp_key)
                .await
                .new_opening();
        }
        if new_user {
            context
                .get_orderly_perp(&perp_symbol)
                .await
                .new_user(pulled_block_height);
        }
        // }

        //hourly_user
        {
            let hourly_user_perp_key = HourlyUserPerpKey {
                account_id: perp_trade.account_id.clone(),
                symbol: perp_trade.symbol_hash.clone(),
                block_hour: trade_hour.clone(),
            };

            let hourly_user_perp = context.get_hourly_user_perp(&hourly_user_perp_key).await;
            let new_hourly_user = hourly_user_perp.new_trade(
                fixed_fee,
                fixed_notional,
                pulled_block_height.clone(),
                pnl_diff,
            );

            if new_hourly_user {
                context
                    .get_hourly_orderly_perp(&hour_orderly_perp_key)
                    .await
                    .new_user();
            }
        }
    }

    tracing::info!(target:PERP_ANALYZER,"handle trade length: {}, max_perp_trade_id: {}", trade_len, max_perp_trade_id);
    return max_perp_trade_id;
}

#[cfg(test)]
mod tests {
    use std::str::FromStr;

    use super::{analyzer_perp_trade, AnalyzeContext, UserPerpSummaryKey};
    use crate::analyzer::{calc::USDC_HASH, tests::*};
    use bigdecimal::BigDecimal;

    use num_traits::FromPrimitive;
    use orderly_dashboard_indexer::formats_external::trading_events::PurchaseSide;
    use orderly_dashboard_indexer::formats_external::trading_events::Trade;

    const ALICE: &str = "0xa11ce";
    const BOB: &str = "0xb0b";

    #[actix_web::test]
    async fn test_perp_trades() {
        let mut context = AnalyzeContext::new_context();
        let block_time = 1748416430;

        let symbols = vec![
            SYMBOL_HASH_BTC_USDC.to_string(),
            SYMBOL_HASH_ETH_USDC.to_string(),
        ];
        let tokens = vec![TOKEN_HASH.to_string(), USDC_HASH.to_string()];
        let account_symbols = vec![
            (ALICE.to_string(), SYMBOL_HASH_BTC_USDC.to_string()),
            (ALICE.to_string(), SYMBOL_HASH_ETH_USDC.to_string()),
            (BOB.to_string(), SYMBOL_HASH_BTC_USDC.to_string()),
            (BOB.to_string(), SYMBOL_HASH_ETH_USDC.to_string()),
        ];
        let account_tokens = vec![
            (ALICE.to_string(), TOKEN_HASH.to_string()),
            (ALICE.to_string(), USDC_HASH.to_string()),
            (BOB.to_string(), TOKEN_HASH.to_string()),
            (BOB.to_string(), USDC_HASH.to_string()),
        ];

        context.init_orderly_context(block_time, symbols, tokens, account_symbols, account_tokens);
        let alice_eth_perp_key = UserPerpSummaryKey {
            account_id: ALICE.to_string(),
            symbol: SYMBOL_HASH_ETH_USDC.to_string(),
        };

        let bob_eth_perp_key = UserPerpSummaryKey {
            account_id: BOB.to_string(),
            symbol: SYMBOL_HASH_ETH_USDC.to_string(),
        };
        context.set_user_perp_cache(
            &alice_eth_perp_key,
            BigDecimal::from_i128(0).unwrap(),
            BigDecimal::from_i128(0).unwrap(),
            BigDecimal::from_i128(0).unwrap(),
            0.into(),
        );
        context.set_user_perp_cache(
            &bob_eth_perp_key,
            BigDecimal::from_i128(0).unwrap(),
            BigDecimal::from_i128(0).unwrap(),
            BigDecimal::from_i128(0).unwrap(),
            0.into(),
        );

        let trades = vec![
            Trade {
                account_id: ALICE.to_string(),
                symbol_hash: SYMBOL_HASH_ETH_USDC.to_string(),
                fee_asset_hash: TOKEN_HASH.to_string(),
                trade_qty: "-200000000".to_string(),
                notional: "-5000000".to_string(),
                executed_price: "250000000".to_string(),
                fee: "7500".to_string(),
                sum_unitary_fundings: "1000000000000001".to_string(),
                trade_id: 13,
                match_id: 1678975214714862536,
                timestamp: (block_time * 1000) as u64,
                side: PurchaseSide::Sell,
                margin_mode: None,
                margin_from_cross: None,
                iso_margin_asset_hash: None,
                is_insurance_account: None,
            },
            Trade {
                account_id: BOB.to_string(),
                symbol_hash: SYMBOL_HASH_ETH_USDC.to_string(),
                fee_asset_hash: TOKEN_HASH.to_string(),
                trade_qty: "200000000".to_string(),
                notional: "5000000".to_string(),
                executed_price: "250000000".to_string(),
                fee: "5000".to_string(),
                sum_unitary_fundings: "1000000000000001".to_string(),
                trade_id: 14,
                match_id: 1678975214714862536,
                timestamp: (block_time * 1000) as u64,
                side: PurchaseSide::Buy,
                margin_mode: None,
                margin_from_cross: None,
                iso_margin_asset_hash: None,
                is_insurance_account: None,
            },
        ];
        let block_number = 1000000;
        let block_hour = convert_block_hour(block_time);
        analyzer_perp_trade(trades, block_number, &mut context, None, block_hour).await;
        {
            let alice_eth = context.get_user_perp_cache(&alice_eth_perp_key);
            println!(
                "alice_eth.holding: {:?}, alice_eth.cost_position: {}",
                alice_eth.holding.to_string(),
                alice_eth.cost_position.to_string(),
            );
            assert_eq!(alice_eth.holding, BigDecimal::from(-2));
            // assertEq(positionA.costPosition, -4992500);
            assert_eq!(
                alice_eth.cost_position,
                BigDecimal::from_str("-4.992500").unwrap()
            );
        }

        {
            let bob_eth = context.get_user_perp_cache(&bob_eth_perp_key);
            assert_eq!(bob_eth.holding, BigDecimal::from(2));
            println!("bob_eth perp summary: {:?}", bob_eth);
        }

        let new_trade = Trade {
            account_id: ALICE.to_string(),
            symbol_hash: SYMBOL_HASH_ETH_USDC.to_string(),
            fee_asset_hash: TOKEN_HASH.to_string(),
            trade_qty: "0".to_string(),
            notional: "0".to_string(),
            executed_price: "250000000".to_string(),
            fee: "0".to_string(),
            sum_unitary_fundings: "5000000000000005".to_string(),
            trade_id: 15,
            match_id: 1678975214714862538,
            timestamp: (block_time * 1000) as u64,
            side: PurchaseSide::Sell,
            margin_mode: None,
            margin_from_cross: None,
            iso_margin_asset_hash: None,
            is_insurance_account: None,
        };
        let block_number = 1000000;
        analyzer_perp_trade(
            vec![new_trade],
            block_number,
            &mut context,
            None,
            block_hour,
        )
        .await;
        let alice_eth = context.get_user_perp_cache(&alice_eth_perp_key);
        println!(
            "after trade_id 15: alice_eth.holding: {:?}, alice_eth.cost_position: {}",
            alice_eth.holding.to_string(),
            alice_eth.cost_position.to_string(),
        );
    }
}
