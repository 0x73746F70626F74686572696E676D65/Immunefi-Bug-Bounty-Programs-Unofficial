-- This file should undo anything in `up.sql`
DROP TABLE IF EXISTS user_token_summary;