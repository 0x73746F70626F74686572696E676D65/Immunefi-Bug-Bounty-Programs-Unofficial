use std::{str::FromStr, time::Duration};

use bigdecimal::BigDecimal;
use chrono::NaiveDateTime;
use num_traits::FromPrimitive;

use crate::{
    client::list_market_infos,
    db::market_info::{create_or_update_market_infos, DBMarketInfo},
};

pub fn update_market_infos_task(base_url: String) {
    orderly_dashboard_indexer::runtime::spawn_future(async move {
        loop {
            if let Err(err) = upsert_market_infos(&base_url).await {
                tracing::warn!("upsert_market_infos failed with err: {}", err);
                tokio::time::sleep(Duration::from_secs(30)).await;
            } else {
                tokio::time::sleep(Duration::from_secs(60)).await;
            }
        }
        #[allow(unreachable_code)]
        Ok(())
    });
}

async fn upsert_market_infos(base_url: &str) -> anyhow::Result<()> {
    let data = list_market_infos(base_url).await?;
    if !data.success {
        return Err(anyhow::anyhow!(
            "list_collecteral_infos failed with info: {:?}",
            data
        ));
    }
    let timestamp = data.timestamp.unwrap_or_default();
    let data = data.data.unwrap_or_default();
    tracing::info!("market infos lens: {:?}", data.rows.len());
    let nsecs = timestamp % 1000 * 1_000_000;
    let update_time = NaiveDateTime::from_timestamp_opt(timestamp / 1000, nsecs as u32).unwrap();
    let market_infos = data
        .rows
        .into_iter()
        .map(|v| {
            DBMarketInfo::new(
                v.symbol,
                BigDecimal::from_str(&v.index_price.to_string()).unwrap(),
                BigDecimal::from_str(&v.mark_price.to_string()).unwrap(),
                BigDecimal::from_f64(v.sum_unitary_funding).unwrap(),
                BigDecimal::from_f64(v.open_interest).unwrap(),
                update_time,
            )
        })
        .collect::<Vec<_>>();
    let market_data_len = market_infos.len();
    create_or_update_market_infos(market_infos).await?;
    tracing::info!("create_or_update_market_infos len: {:?}", market_data_len);
    Ok(())
}
