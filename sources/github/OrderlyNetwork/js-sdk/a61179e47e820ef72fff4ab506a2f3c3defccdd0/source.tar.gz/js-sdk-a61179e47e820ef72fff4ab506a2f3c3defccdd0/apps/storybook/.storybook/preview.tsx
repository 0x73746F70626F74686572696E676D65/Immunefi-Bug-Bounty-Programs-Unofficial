import type { Preview } from "@storybook/react-vite";
import { withThemeBuilder } from "storybook-theme-tool/preview";
import { OrderlyProvider } from "../src/components/orderlyProvider";
import { customViewports } from "./screenSizes";
import {
  resolveToolbarThemeId,
  withOrderlyThemeToolbar,
} from "./withOrderlyThemeToolbar";
import "../src/playground/styles/fonts.css";
import "../src/tailwind.css";

const preview: Preview = {
  decorators: [
    (Story, context) => {
      return (
        <OrderlyProvider toolbarThemeId={resolveToolbarThemeId(context)}>
          <Story />
        </OrderlyProvider>
      );
    },
    withThemeBuilder,
    // Registers toolbar labels only; DOM attribute is owned by AppThemeProvider.
    withOrderlyThemeToolbar,
  ],
  // tags: ["autodocs"],
  parameters: {
    // custom background colors: http://localhost:6008/?path=/story/package-trading-leaderboard--campaign-leaderboard&globals=theme:custom
    // backgrounds: {
    //   options: [
    //     { name: "Dark", value: "rgb(var(--oui-color-base-10))" },
    //     { name: "Light", value: "rgb(255,255,255)" },
    //   ],
    //   default: "Dark",
    // },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
      // disable: true,
    },
    // actions: { disable: true },
    // interactions: { disable: true },

    a11y: {
      // 'todo' - show a11y violations in the test UI only
      // 'error' - fail CI on a11y violations
      // 'off' - skip a11y checks entirely
      test: "todo",
    },

    docs: {
      codePanel: true,
    },
    options: {
      storySort: {
        order: [
          "Overview",
          "Design Tokens",
          "Package",
          [
            "plugin-core",
            "trading",
            "portfolio",
            "markets",
            "affiliate",
            "trading-rewards",
            "trading-leaderboard",
            "wallet-connector-privy",
            "ui-scaffold",
            "ui-connector",
            "ui-chain-selector",
            "ui-order-entry",
            "ui-orders",
            "ui-positions",
            "ui-tpsl",
            "ui-transfer",
            "ui-share",
            "ui-leverage",
            "ui-tradingview",
            "i18n",
          ],
          "Base",
        ],
      },
    },
    viewport: {
      options: customViewports,
    },
  },
};

export default preview;
