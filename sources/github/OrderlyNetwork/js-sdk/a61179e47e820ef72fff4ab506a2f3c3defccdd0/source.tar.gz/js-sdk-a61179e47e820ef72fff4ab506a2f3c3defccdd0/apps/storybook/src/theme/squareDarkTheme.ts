export const SQUARE_DARK_THEME_CSS_VARS = {
  /* rounded */
  "--oui-rounded-sm": "0",
  "--oui-rounded": "0",
  "--oui-rounded-md": "0",
  "--oui-rounded-lg": "0",
  "--oui-rounded-xl": "0",
  "--oui-rounded-2xl": "0",
  "--oui-rounded-full": "0",
};

/**
 * @deprecated Renamed to `SQUARE_DARK_THEME_CSS_VARS`. Kept for backward
 * compatibility; remove in a future release.
 */
export const ROUNDLESS_THEME_CSS_VARS = SQUARE_DARK_THEME_CSS_VARS;
