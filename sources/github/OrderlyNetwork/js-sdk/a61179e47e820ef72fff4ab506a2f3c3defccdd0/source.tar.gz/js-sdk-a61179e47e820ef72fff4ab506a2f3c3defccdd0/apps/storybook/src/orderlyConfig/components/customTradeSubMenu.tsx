import React, { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router";
import { generatePath, useTranslation } from "@orderly.network/i18n";
import { SubMenuMarketsWidget } from "@orderly.network/markets";
import { API } from "@orderly.network/types";
import {
  EarnActiveIcon,
  EarnInactiveIcon,
  TradingActiveIcon,
  TradingInactiveIcon,
  MarketsActiveIcon,
  MarketsInactiveIcon,
} from "@orderly.network/ui";
import { useRouteContext } from "../../components/orderlyProvider/rounteProvider";
import { PathEnum } from "../../playground/constant";
import { DEFAULT_SYMBOL, updateSymbol } from "../../playground/storage";
import { MenuItemRow } from "./SubMenuComponents";

const RIGHT_SECTION_WRAPPER_CLASSNAME = [
  "oui-overflow-hidden",
  "oui-transition-[width,height] oui-duration-120 oui-ease-out",
  "data-[state=open]:oui-w-[280px] data-[state=closed]:oui-w-0",
  "data-[state=open]:oui-h-[423px] data-[state=closed]:oui-h-0",
  "data-[state=closed]:oui-pointer-events-none",
].join(" ");

const RIGHT_SECTION_ANIMATION_CLASSNAME = [
  "oui-origin-top-left",
  "data-[state=open]:oui-animate-in data-[state=closed]:oui-animate-out",
  "data-[state=open]:oui-fade-in-0 data-[state=closed]:oui-fade-out-0",
  "data-[state=open]:oui-zoom-in-95 data-[state=closed]:oui-zoom-out-95",
  "data-[state=open]:oui-slide-in-from-top-2",
  "data-[state=open]:oui-slide-in-from-left-2",
].join(" ");

const LeftSection = (props: {
  selectedTab: string;
  onSelect: (tab: string) => void;
  onSpotClick: () => void;
  onPerpsClick: () => void;
  onRWAClick: () => void;
  onHoverTab: (tab: "perps" | null) => void;
}) => {
  const {
    selectedTab,
    onSelect,
    onSpotClick,
    onPerpsClick,
    onRWAClick,
    onHoverTab,
  } = props;
  const { t } = useTranslation();

  const menus = [
    {
      key: "spot",
      activeIcon: <EarnActiveIcon size={20} />,
      inactiveIcon: <EarnInactiveIcon size={20} />,
      title: t("extend.spot"),
      description: t("extend.spot.description"),
      onClick: () => {
        onSelect("spot");
        onSpotClick();
      },
    },
    {
      key: "perps",
      activeIcon: <TradingActiveIcon size={20} />,
      inactiveIcon: <TradingInactiveIcon size={20} />,
      title: t("extend.perps"),
      description: t("extend.perps.description"),
      onClick: () => {
        onSelect("perps");
        onPerpsClick();
      },
      onMouseEnter: () => {
        onHoverTab("perps");
      },
    },
    {
      key: "rwa",
      activeIcon: <MarketsActiveIcon size={20} />,
      inactiveIcon: <MarketsInactiveIcon size={20} />,
      title: t("common.rwa"),
      description: t("common.rwa"),
      onClick: () => {
        onSelect("rwa");
        onRWAClick();
      },
    },
  ];

  return (
    <div className="oui-w-[240px] oui-flex-shrink-0 oui-rounded-lg">
      {menus.map((menu) => {
        const isActive = selectedTab === menu.key;
        return (
          <MenuItemRow
            key={menu.key}
            activeIcon={isActive ? menu.activeIcon : menu.inactiveIcon}
            title={menu.title}
            description={menu.description}
            onClick={menu.onClick}
            onMouseEnter={
              menu.onMouseEnter ??
              (() => {
                onHoverTab(null);
              })
            }
            isActive={isActive}
            showArrow={true}
          />
        );
      })}
    </div>
  );
};

const RightSection = (props: { className?: string }) => {
  const { className } = props;
  const params = useParams();

  const { onRouteChange } = useRouteContext();
  const [symbol, setSymbol] = useState<string>(params.symbol || DEFAULT_SYMBOL);

  useEffect(() => {
    const next = params.symbol || DEFAULT_SYMBOL;
    if (next !== symbol) setSymbol(next);
  }, [params.symbol]);

  useEffect(() => {
    updateSymbol(symbol);
  }, [symbol]);

  const onSymbolChange = useCallback(
    (data: API.Symbol) => {
      const nextSymbol = data.symbol;
      setSymbol(nextSymbol);
      onRouteChange({
        href: `${PathEnum.Perp}/${nextSymbol}`,
        name: "perps",
      });
    },
    [onRouteChange],
  );

  return (
    <div className={className}>
      <SubMenuMarketsWidget
        className="oui-rounded-md oui-p-2"
        symbol={symbol}
        onSymbolChange={onSymbolChange}
      />
    </div>
  );
};

export const customTradeSubMenuRender = () => {
  return () => {
    const [selectedTab, setSelectedTab] = useState("perps");
    const [hoverTab, setHoverTab] = useState<"perps" | null>(null);
    const { onRouteChange } = useRouteContext();
    const location = window.location;

    const handleSpotClick = () => {
      onRouteChange({
        href: PathEnum.Swap,
        name: "spot",
      });
    };

    const handlePerpsClick = () => {
      onRouteChange({ href: PathEnum.Perp, name: "perps" });
    };

    const handleRWAClick = () => {
      onRouteChange({ href: PathEnum.Rwa, name: "rwa" });
    };

    useEffect(() => {
      const pathname = location.pathname || "";
      if (pathname.includes(PathEnum.Swap)) setSelectedTab("spot");
      if (pathname.includes(PathEnum.Rwa)) setSelectedTab("rwa");
    }, [location.pathname]);

    const showPerpsRightSection =
      selectedTab === "perps" || hoverTab === "perps";
    const rightSectionState = showPerpsRightSection ? "open" : "closed";

    return (
      <div
        className="oui-flex oui-p-1 oui-bg-base-8 oui-rounded-lg oui-border oui-border-line-6"
        onMouseLeave={() => {
          setHoverTab(null);
        }}
      >
        <LeftSection
          selectedTab={selectedTab}
          onSelect={setSelectedTab}
          onSpotClick={handleSpotClick}
          onPerpsClick={handlePerpsClick}
          onRWAClick={handleRWAClick}
          onHoverTab={setHoverTab}
        />
        <div
          className={RIGHT_SECTION_WRAPPER_CLASSNAME}
          onMouseEnter={() => {
            setHoverTab("perps");
          }}
          data-state={rightSectionState}
        >
          <div
            className={RIGHT_SECTION_ANIMATION_CLASSNAME}
            data-state={rightSectionState}
          >
            <RightSection className="oui-w-[280px] oui-h-[423px] oui-ml-1" />
          </div>
        </div>
      </div>
    );
  };
};
