import type { BreakdownAdapter, FetchOptions } from "../../adapters/types";
import { CHAIN } from "../../helpers/chains";
import { getUniqStartOfTodayTimestamp } from "../../helpers/getUniSubgraphVolume";
import fetchURL from "../../utils/fetchURL";

// Template for broker-specific adapter using Orderly's broker API
// Brokers should replace "BROKER_ID" with their specific broker ID
const BROKER_ID = "BROKER_ID";
const apiEVM = `https://api.orderly.org/md/volume/builder/daily_stats?broker_id=${BROKER_ID}`;

type BrokerDailyStats = {
  date: string;
  dateString: string;
  createdAt: string;
  updatedAt: string;
  builderFee: string | number;
  takerVolume: string | number;
  makerVolume: string | number;
  activeUser: number;
};

// Since the API doesn't provide chain-specific breakdown, 
// brokers should select only ONE chain where their volume will be reported
// IMPORTANT: Select only ONE chain where your volume should be reported
const BROKER_CHAIN = CHAIN.ARBITRUM; // Change this to your chain
const START_DATE = "2023-10-26"; // Change this to your start date

// Reference of chains and their typical start dates:
// CHAIN.ARBITRUM - "2023-10-26"
// CHAIN.OPTIMISM - "2023-11-30"
// CHAIN.POLYGON - "2024-02-05"
// CHAIN.BASE - "2024-04-03"
// CHAIN.MANTLE - "2024-05-28"
// CHAIN.ETHEREUM - "2024-06-13"
// CHAIN.SEI - "2024-10-18"
// CHAIN.AVAX - "2024-11-07"
// CHAIN.SOLANA - "2024-11-29"
// CHAIN.MORPH - "2024-12-17"
// CHAIN.SONIC - "2024-12-31"
// CHAIN.BERACHAIN - "2025-03-07"
// CHAIN.STORY - "2025-03-07"
// CHAIN.MODE - "2025-03-19"

const fetchBrokerData = async (startOfDay: number) => {
  const allStats: BrokerDailyStats[] = await fetchURL(apiEVM);
  const cleanTimestamp = getUniqStartOfTodayTimestamp(
    new Date(startOfDay * 1000)
  );

  // Find the stats for the requested date
  const targetDate = new Date(startOfDay * 1000).toISOString().split('T')[0];
  const dailyStats = allStats.find(day => day.date.startsWith(targetDate));

  if (!dailyStats) {
    return {
      timestamp: cleanTimestamp,
      dailyVolume: "0",
      dailyFees: "0",
    };
  }

  // Convert string values to numbers if needed
  const takerVolume = typeof dailyStats.takerVolume === "string" 
    ? parseFloat(dailyStats.takerVolume) 
    : (dailyStats.takerVolume || 0);
  
  const makerVolume = typeof dailyStats.makerVolume === "string" 
    ? parseFloat(dailyStats.makerVolume) 
    : (dailyStats.makerVolume || 0);
  
  const builderFee = typeof dailyStats.builderFee === "string" 
    ? parseFloat(dailyStats.builderFee) 
    : (dailyStats.builderFee || 0);

  // Calculate total volume
  const totalVolume = takerVolume + makerVolume;
  
  return {
    timestamp: cleanTimestamp,
    dailyVolume: totalVolume.toString(),
    dailyFees: builderFee.toString(),
  };
};

const adapter: BreakdownAdapter = {
  breakdown: {
    // Replace "orderly-broker-template" with your unique broker identifier
    // This will be how your broker appears in DefiLlama
    "orderly-broker-template": {
      [BROKER_CHAIN]: {
        start: START_DATE,
        fetch: async (__t: number, _: any, { startOfDay }: FetchOptions) =>
          fetchBrokerData(startOfDay),
      }
    },
  },
};

export default adapter;
