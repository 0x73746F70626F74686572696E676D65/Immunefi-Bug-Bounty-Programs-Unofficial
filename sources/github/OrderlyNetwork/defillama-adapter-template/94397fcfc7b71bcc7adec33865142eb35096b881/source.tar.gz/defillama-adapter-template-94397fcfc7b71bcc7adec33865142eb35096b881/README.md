# Orderly Network Broker Adapter for DefiLlama

This template helps Orderly Network brokers easily integrate with DefiLlama to track and display their volume and fee metrics.

## Overview

This adapter fetches volume and fee data from the Orderly Network API for a specific broker and reports it to DefiLlama. The data will appear under your broker's name in DefiLlama's DEX volume rankings.

## Step-by-Step Integration Guide

### 1. Fork the DefiLlama repository

1. Visit https://github.com/DefiLlama/dimension-adapters
2. Click the "Fork" button in the top right corner
3. Clone your forked repository to your local machine:
   ```bash
   git clone https://github.com/YOUR_USERNAME/dimension-adapters.git
   cd dimension-adapters
   ```

### 2. Create a new adapter

1. Create a new directory for your broker adapter

2. Create an `index.ts` file in this directory and copy the template code manually from this repository.

3. Edit the `index.ts` file with your specific information:
   - Replace `BROKER_ID` with your actual broker ID from Orderly Network
   - Set `BROKER_CHAIN` to the chain where your volume should be reported
   - Update `START_DATE` to match when your broker started operations
   - Change `"orderly-broker-template"` to your unique identifier (e.g., `"orderly-broker-yourname"`)

### 3. Install dependencies

From the root of the repository:
```bash
npm install
```

### 4. Test your adapter

```bash
yarn test dexs orderly-broker-YOUR_BROKER_NAME
```

This should show your volume and fees data if everything is configured correctly.

### 5. Commit your changes

```bash
git add .
git commit -m "Add Orderly broker adapter for YOUR_BROKER_NAME"
git push origin master
```

### 6. Create a Pull Request

1. Go to your fork on GitHub
2. Click "Contribute" and then "Open pull request"
3. Set the base repository to `DefiLlama/dimension-adapters` and the base branch to `master`
4. Set your repository and branch as the compare
5. Click "Create pull request"
6. Fill in the PR template with relevant information:
   - Title: `Add Orderly broker adapter for YOUR_BROKER_NAME`
   - Description: Briefly explain that you're adding a new Orderly Network broker adapter and include any relevant information about your broker

## Additional Information

- **Chain Selection**: Since the API doesn't provide a chain breakdown, you must select a single chain where your volume will be reported. Choose the chain where most of your trading activity occurs.
- **Data Format**: The adapter reports both volume (combined maker and taker volume) and fees data.
- **Data Frequency**: DefiLlama typically updates metrics daily.
