module.exports = {
  ethereum: {
    owners: [
      '0xb03eDB668008459B3c6D948ab5Ab305581DbF69c',
      '0x3d79007ba1a68de986eb641a3c24d58a0c69587e',
      '0xF884B1bC1d91Cdf824e7f35D61EdfdB042c28C83',
      '0xAd8E5cEb7D77e10403Be8430717c515273c31b8d',
      '0x16572Dc0f727C7E3012baD8dbE6B2CE1Cdc31670',
      '0xD888d549B511CE54efFa084f33744a59D452C729',
      '0x2c02f34e06f75380844F928b0CBAb1265338Ae27'
    ],
  },
  bitcoin: 'biconomy',
  polygon: {
    owners: [
      '0x366ba28Ec89113454EA6e82bB606426e8cA22780'
    ],
  },
  tron: {
    owners: [
      'TEi2hVWDRMo61PAoi1Dwbn8hNXufkwEVyp'
    ]
  },
}
