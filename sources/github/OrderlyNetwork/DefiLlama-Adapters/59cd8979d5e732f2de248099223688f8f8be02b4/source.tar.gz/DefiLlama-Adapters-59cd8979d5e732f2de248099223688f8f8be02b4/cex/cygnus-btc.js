module.exports = {
  bitcoin: 'cygnus'
}
