module.exports = { bitcoin: 'btse' }
