module.exports = { bitcoin: 'silkroad' }
