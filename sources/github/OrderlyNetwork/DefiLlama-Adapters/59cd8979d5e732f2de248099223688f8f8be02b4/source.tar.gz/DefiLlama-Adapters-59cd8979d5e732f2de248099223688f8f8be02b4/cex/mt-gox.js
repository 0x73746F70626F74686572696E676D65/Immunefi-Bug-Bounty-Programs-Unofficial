module.exports = { bitcoin: 'mtGox' }
