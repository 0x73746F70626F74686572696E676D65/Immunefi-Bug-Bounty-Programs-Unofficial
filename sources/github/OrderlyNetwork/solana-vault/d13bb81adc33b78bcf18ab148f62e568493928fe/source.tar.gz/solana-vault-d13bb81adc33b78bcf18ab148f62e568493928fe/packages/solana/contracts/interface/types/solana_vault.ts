export type SolanaVault = {
  "version": "0.1.0",
  "name": "solana_vault",
  "instructions": [
    {
      "name": "setVault",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetVaultParams"
          }
        }
      ]
    },
    {
      "name": "deposit",
      "accounts": [
        {
          "name": "user",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "userTokenAccount",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "vaultTokenAccount",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "depositToken",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "enforcedOptions",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedBroker",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedToken",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "tokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "associatedTokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "depositParams",
          "type": {
            "defined": "DepositParams"
          }
        },
        {
          "name": "oappParams",
          "type": {
            "defined": "OAppSendParams"
          }
        }
      ],
      "returns": {
        "defined": "MessagingReceipt"
      }
    },
    {
      "name": "depositSol",
      "accounts": [
        {
          "name": "user",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "solVault",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "CHECKED: sol_vault is used for SOL deposit"
          ]
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "enforcedOptions",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedBroker",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedToken",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "depositParams",
          "type": {
            "defined": "DepositParams"
          }
        },
        {
          "name": "oappParams",
          "type": {
            "defined": "OAppSendParams"
          }
        }
      ],
      "returns": {
        "defined": "MessagingReceipt"
      }
    },
    {
      "name": "initOapp",
      "accounts": [
        {
          "name": "payer",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "lzReceiveTypes",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "accountList",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "InitOAppParams"
          }
        }
      ]
    },
    {
      "name": "setAccountList",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "lzReceiveTypes",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "accountsList",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetAccountListParams"
          }
        }
      ]
    },
    {
      "name": "setManagerRole",
      "accounts": [
        {
          "name": "owner",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetManagerRoleParams"
          }
        }
      ]
    },
    {
      "name": "setBroker",
      "accounts": [
        {
          "name": "brokerManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "allowedBroker",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetBrokerParams"
          }
        }
      ]
    },
    {
      "name": "setWithdrawBroker",
      "accounts": [
        {
          "name": "brokerManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "withdrawBroker",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetWithdrawBrokerParams"
          }
        }
      ]
    },
    {
      "name": "setToken",
      "accounts": [
        {
          "name": "tokenManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "allowedToken",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "mintAccount",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetTokenParams"
          }
        }
      ]
    },
    {
      "name": "setWithdrawToken",
      "accounts": [
        {
          "name": "tokenManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "withdrawToken",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "mintAccount",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetWithdrawTokenParams"
          }
        }
      ]
    },
    {
      "name": "setOrderDelivery",
      "accounts": [
        {
          "name": "owner",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetOrderDeliveryParams"
          }
        }
      ]
    },
    {
      "name": "oappQuote",
      "accounts": [
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "enforcedOptions",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "vaultAuthority",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "DepositParams"
          }
        }
      ],
      "returns": {
        "defined": "MessagingFee"
      }
    },
    {
      "name": "lzReceive",
      "accounts": [
        {
          "name": "payer",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "withdrawBrokerPda",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "withdrawTokenPda",
          "isMut": false,
          "isSigner": false,
          "docs": [
            "CHECK"
          ]
        },
        {
          "name": "tokenMint",
          "isMut": false,
          "isSigner": false,
          "docs": [
            "CHECK"
          ]
        },
        {
          "name": "receiver",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "CHECK"
          ]
        },
        {
          "name": "receiverTokenAccount",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "UNCHECKED"
          ]
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "vaultTokenAccount",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "solVault",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "CHECKED: sol_vault is used for SOL withdrawal"
          ]
        },
        {
          "name": "tokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "associatedTokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "eventAuthority",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "program",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "OAppLzReceiveParams"
          }
        }
      ]
    },
    {
      "name": "lzReceiveTypes",
      "accounts": [
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "accountList",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "OAppLzReceiveParams"
          }
        }
      ],
      "returns": {
        "vec": {
          "defined": "oapp::endpoint_cpi::LzAccount"
        }
      }
    },
    {
      "name": "setRateLimit",
      "accounts": [
        {
          "name": "admin",
          "isMut": false,
          "isSigner": true
        },
        {
          "name": "peer",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetRateLimitParams"
          }
        }
      ]
    },
    {
      "name": "setDelegate",
      "accounts": [
        {
          "name": "admin",
          "isMut": false,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetDelegateParams"
          }
        }
      ]
    },
    {
      "name": "transferAdmin",
      "accounts": [
        {
          "name": "admin",
          "isMut": false,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": true,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "TransferAdminParams"
          }
        }
      ]
    },
    {
      "name": "setPeer",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "peer",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetPeerParams"
          }
        }
      ]
    },
    {
      "name": "setEnforcedOptions",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "enforcedOptions",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetEnforcedOptionsParams"
          }
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "enforcedOptions",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "send",
            "type": "bytes"
          },
          {
            "name": "sendAndCall",
            "type": "bytes"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "oAppConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "endpointProgram",
            "type": "publicKey"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "admin",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "oAppLzReceiveTypesAccounts",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "oappConfig",
            "type": "publicKey"
          },
          {
            "name": "accountList",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "accountList",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "woofiProPda",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdcPda",
            "type": "publicKey"
          },
          {
            "name": "usdcMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdtPda",
            "type": "publicKey"
          },
          {
            "name": "usdtMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawWsolPda",
            "type": "publicKey"
          },
          {
            "name": "wsolMint",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "peer",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "address",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "rateLimiter",
            "type": {
              "option": {
                "defined": "RateLimiter"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "allowedBroker",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "allowedToken",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mintAccount",
            "type": "publicKey"
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenDecimals",
            "type": "u8"
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "managerRole",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "roleHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "vaultAuthority",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "bump",
            "docs": [
              "Bump seed for the vault authority PDA"
            ],
            "type": "u8"
          },
          {
            "name": "owner",
            "type": "publicKey"
          },
          {
            "name": "depositNonce",
            "type": "u64"
          },
          {
            "name": "orderDelivery",
            "type": "bool"
          },
          {
            "name": "inboundNonce",
            "type": "u64"
          },
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "solChainId",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "withdrawBroker",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerIndex",
            "type": "u16"
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "withdrawToken",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mintAccount",
            "type": "publicKey"
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenDecimals",
            "type": "u8"
          },
          {
            "name": "tokenIndex",
            "type": "u8"
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    }
  ],
  "types": [
    {
      "name": "VaultDepositParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "accountId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "userAddress",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "srcChainId",
            "type": "u128"
          },
          {
            "name": "tokenAmount",
            "type": "u128"
          },
          {
            "name": "srcChainDepositNonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "LzMessage",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "msgType",
            "type": "u8"
          },
          {
            "name": "payload",
            "type": "bytes"
          }
        ]
      }
    },
    {
      "name": "AccountWithdrawSol",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "sender",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "receiver",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerIndex",
            "type": "u16"
          },
          {
            "name": "tokenIndex",
            "type": "u8"
          },
          {
            "name": "tokenAmount",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": "u64"
          },
          {
            "name": "chainId",
            "type": "u64"
          },
          {
            "name": "withdrawNonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "VaultWithdrawParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "accountId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "sender",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "receiver",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenAmount",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": "u128"
          },
          {
            "name": "chainId",
            "type": "u128"
          },
          {
            "name": "withdrawNonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "InitOAppParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "admin",
            "type": "publicKey"
          },
          {
            "name": "accountList",
            "type": "publicKey"
          },
          {
            "name": "endpointProgram",
            "type": {
              "option": "publicKey"
            }
          }
        ]
      }
    },
    {
      "name": "OAppLzReceiveParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "srcEid",
            "type": "u32"
          },
          {
            "name": "sender",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "guid",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "message",
            "type": "bytes"
          },
          {
            "name": "extraData",
            "type": "bytes"
          }
        ]
      }
    },
    {
      "name": "MessagingFee",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nativeFee",
            "type": "u64"
          },
          {
            "name": "lzTokenFee",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "SetAccountListParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "woofiProPda",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdcPda",
            "type": "publicKey"
          },
          {
            "name": "usdcMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdtPda",
            "type": "publicKey"
          },
          {
            "name": "usdtMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawWsolPda",
            "type": "publicKey"
          },
          {
            "name": "wsolMint",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "SetDelegateParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "delegate",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "SetEnforcedOptionsParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "send",
            "type": "bytes"
          },
          {
            "name": "sendAndCall",
            "type": "bytes"
          }
        ]
      }
    },
    {
      "name": "SetPeerParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "peer",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "SetRateLimitParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "refillPerSecond",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "capacity",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "enabled",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "TransferAdminParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "admin",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "DepositParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "accountId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "userAddress",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "OAppSendParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nativeFee",
            "type": "u64"
          },
          {
            "name": "lzTokenFee",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "SetBrokerParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetManagerRoleParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "roleHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "managerAddress",
            "type": "publicKey"
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetOrderDeliveryParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "orderDelivery",
            "type": "bool"
          },
          {
            "name": "nonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "SetTokenParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mintAccount",
            "type": "publicKey"
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetVaultParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "publicKey"
          },
          {
            "name": "depositNonce",
            "type": "u64"
          },
          {
            "name": "orderDelivery",
            "type": "bool"
          },
          {
            "name": "inboundNonce",
            "type": "u64"
          },
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "solChainId",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "SetWithdrawBrokerParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerIndex",
            "type": "u16"
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetWithdrawTokenParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenIndex",
            "type": "u8"
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "RateLimiter",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "capacity",
            "type": "u64"
          },
          {
            "name": "tokens",
            "type": "u64"
          },
          {
            "name": "refillPerSecond",
            "type": "u64"
          },
          {
            "name": "lastRefillTime",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "OAppError",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "Unauthorized"
          },
          {
            "name": "InvalidSender"
          },
          {
            "name": "InvalidReceiver"
          },
          {
            "name": "InvalidOptions"
          },
          {
            "name": "InvalidEndpointProgram"
          },
          {
            "name": "RateLimitExceeded"
          },
          {
            "name": "WithdrawFailed"
          },
          {
            "name": "InvalidInboundNonce"
          },
          {
            "name": "InvalidReceiverTokenAccount"
          },
          {
            "name": "InvalidAdminTokenAccount"
          },
          {
            "name": "InvalidMessageType"
          },
          {
            "name": "InvalidTokenIndex"
          }
        ]
      }
    },
    {
      "name": "MsgType",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "Deposit"
          },
          {
            "name": "Withdraw"
          },
          {
            "name": "RebalanceBurn"
          },
          {
            "name": "RebalanceMint"
          }
        ]
      }
    }
  ],
  "events": [
    {
      "name": "SetAllowedBroker",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        }
      ]
    },
    {
      "name": "ResetAllowedBroker",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        }
      ]
    },
    {
      "name": "SetAllowedToken",
      "fields": [
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "ResetAllowedToken",
      "fields": [
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "SetWithdrawTokenIndex",
      "fields": [
        {
          "name": "tokenIndex",
          "type": "u8",
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "ResetWithdrawTokenIndex",
      "fields": [
        {
          "name": "tokenIndex",
          "type": "u8",
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "SetWithdrawBrokerEvent",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerIndex",
          "type": "u16",
          "index": false
        }
      ]
    },
    {
      "name": "ResetWithdrawBrokerEvent",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerIndex",
          "type": "u16",
          "index": false
        }
      ]
    },
    {
      "name": "SetManager",
      "fields": [
        {
          "name": "roleHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "managerAddress",
          "type": "publicKey",
          "index": false
        },
        {
          "name": "allowed",
          "type": "bool",
          "index": false
        }
      ]
    },
    {
      "name": "Deposited",
      "fields": [
        {
          "name": "user",
          "type": "publicKey",
          "index": false
        },
        {
          "name": "amount",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "Withdrawn",
      "fields": [
        {
          "name": "user",
          "type": "publicKey",
          "index": false
        },
        {
          "name": "amount",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "CreatedATA",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiverTokenAccount",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "VaultDeposited",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "userAddress",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "srcChainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "srcChainDepositNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "VaultWithdrawn",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "sender",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "fee",
          "type": "u128",
          "index": false
        },
        {
          "name": "chainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "FrozenWithdrawn",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "sender",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "fee",
          "type": "u128",
          "index": false
        },
        {
          "name": "chainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "WithdrawSolFailed",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "sender",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "fee",
          "type": "u128",
          "index": false
        },
        {
          "name": "chainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        },
        {
          "name": "reason",
          "type": "u8",
          "index": false
        }
      ]
    },
    {
      "name": "OAppSent",
      "fields": [
        {
          "name": "guid",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "dstEid",
          "type": "u32",
          "index": false
        }
      ]
    },
    {
      "name": "OAppReceived",
      "fields": [
        {
          "name": "guid",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "srcEid",
          "type": "u32",
          "index": false
        }
      ]
    }
  ],
  "errors": [
    {
      "code": 6000,
      "name": "InsufficientFunds",
      "msg": "Deposited funds are insufficient for withdrawal"
    },
    {
      "code": 6001,
      "name": "UserInfoBelongsToAnotherUser",
      "msg": "User info pda belongs to another user"
    },
    {
      "code": 6002,
      "name": "BrokerNotAllowed",
      "msg": "Broker is not allowed"
    },
    {
      "code": 6003,
      "name": "TokenNotAllowed",
      "msg": "Token is not allowed"
    },
    {
      "code": 6004,
      "name": "InvalidAccountId",
      "msg": "AccountId is invalid"
    },
    {
      "code": 6005,
      "name": "InvalidVaultOwner",
      "msg": "Vault owner is not the same as the payer"
    },
    {
      "code": 6006,
      "name": "ManagerRoleNotAllowed",
      "msg": "Manager role is not allowed"
    },
    {
      "code": 6007,
      "name": "ZeroDepositAmount",
      "msg": "Deposit amount must be greater than zero"
    },
    {
      "code": 6008,
      "name": "InsufficientWithdrawAmount",
      "msg": "Withdraw amount must be no less than withdraw fee"
    }
  ]
};

export const IDL: SolanaVault = {
  "version": "0.1.0",
  "name": "solana_vault",
  "instructions": [
    {
      "name": "setVault",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetVaultParams"
          }
        }
      ]
    },
    {
      "name": "deposit",
      "accounts": [
        {
          "name": "user",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "userTokenAccount",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "vaultTokenAccount",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "depositToken",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "enforcedOptions",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedBroker",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedToken",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "tokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "associatedTokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "depositParams",
          "type": {
            "defined": "DepositParams"
          }
        },
        {
          "name": "oappParams",
          "type": {
            "defined": "OAppSendParams"
          }
        }
      ],
      "returns": {
        "defined": "MessagingReceipt"
      }
    },
    {
      "name": "depositSol",
      "accounts": [
        {
          "name": "user",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "solVault",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "CHECKED: sol_vault is used for SOL deposit"
          ]
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "enforcedOptions",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedBroker",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "allowedToken",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "depositParams",
          "type": {
            "defined": "DepositParams"
          }
        },
        {
          "name": "oappParams",
          "type": {
            "defined": "OAppSendParams"
          }
        }
      ],
      "returns": {
        "defined": "MessagingReceipt"
      }
    },
    {
      "name": "initOapp",
      "accounts": [
        {
          "name": "payer",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "lzReceiveTypes",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "accountList",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "InitOAppParams"
          }
        }
      ]
    },
    {
      "name": "setAccountList",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "lzReceiveTypes",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "accountsList",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetAccountListParams"
          }
        }
      ]
    },
    {
      "name": "setManagerRole",
      "accounts": [
        {
          "name": "owner",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetManagerRoleParams"
          }
        }
      ]
    },
    {
      "name": "setBroker",
      "accounts": [
        {
          "name": "brokerManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "allowedBroker",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetBrokerParams"
          }
        }
      ]
    },
    {
      "name": "setWithdrawBroker",
      "accounts": [
        {
          "name": "brokerManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "withdrawBroker",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetWithdrawBrokerParams"
          }
        }
      ]
    },
    {
      "name": "setToken",
      "accounts": [
        {
          "name": "tokenManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "allowedToken",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "mintAccount",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetTokenParams"
          }
        }
      ]
    },
    {
      "name": "setWithdrawToken",
      "accounts": [
        {
          "name": "tokenManager",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "withdrawToken",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "managerRole",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "mintAccount",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetWithdrawTokenParams"
          }
        }
      ]
    },
    {
      "name": "setOrderDelivery",
      "accounts": [
        {
          "name": "owner",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetOrderDeliveryParams"
          }
        }
      ]
    },
    {
      "name": "oappQuote",
      "accounts": [
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "enforcedOptions",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "vaultAuthority",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "DepositParams"
          }
        }
      ],
      "returns": {
        "defined": "MessagingFee"
      }
    },
    {
      "name": "lzReceive",
      "accounts": [
        {
          "name": "payer",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "peer",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "withdrawBrokerPda",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "withdrawTokenPda",
          "isMut": false,
          "isSigner": false,
          "docs": [
            "CHECK"
          ]
        },
        {
          "name": "tokenMint",
          "isMut": false,
          "isSigner": false,
          "docs": [
            "CHECK"
          ]
        },
        {
          "name": "receiver",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "CHECK"
          ]
        },
        {
          "name": "receiverTokenAccount",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "UNCHECKED"
          ]
        },
        {
          "name": "vaultAuthority",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "vaultTokenAccount",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "solVault",
          "isMut": true,
          "isSigner": false,
          "docs": [
            "CHECKED: sol_vault is used for SOL withdrawal"
          ]
        },
        {
          "name": "tokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "associatedTokenProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "eventAuthority",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "program",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "OAppLzReceiveParams"
          }
        }
      ]
    },
    {
      "name": "lzReceiveTypes",
      "accounts": [
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "accountList",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "OAppLzReceiveParams"
          }
        }
      ],
      "returns": {
        "vec": {
          "defined": "oapp::endpoint_cpi::LzAccount"
        }
      }
    },
    {
      "name": "setRateLimit",
      "accounts": [
        {
          "name": "admin",
          "isMut": false,
          "isSigner": true
        },
        {
          "name": "peer",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetRateLimitParams"
          }
        }
      ]
    },
    {
      "name": "setDelegate",
      "accounts": [
        {
          "name": "admin",
          "isMut": false,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetDelegateParams"
          }
        }
      ]
    },
    {
      "name": "transferAdmin",
      "accounts": [
        {
          "name": "admin",
          "isMut": false,
          "isSigner": true
        },
        {
          "name": "oappConfig",
          "isMut": true,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "TransferAdminParams"
          }
        }
      ]
    },
    {
      "name": "setPeer",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "peer",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetPeerParams"
          }
        }
      ]
    },
    {
      "name": "setEnforcedOptions",
      "accounts": [
        {
          "name": "admin",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "enforcedOptions",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "oappConfig",
          "isMut": false,
          "isSigner": false
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "params",
          "type": {
            "defined": "SetEnforcedOptionsParams"
          }
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "enforcedOptions",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "send",
            "type": "bytes"
          },
          {
            "name": "sendAndCall",
            "type": "bytes"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "oAppConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "endpointProgram",
            "type": "publicKey"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "admin",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "oAppLzReceiveTypesAccounts",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "oappConfig",
            "type": "publicKey"
          },
          {
            "name": "accountList",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "accountList",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "woofiProPda",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdcPda",
            "type": "publicKey"
          },
          {
            "name": "usdcMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdtPda",
            "type": "publicKey"
          },
          {
            "name": "usdtMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawWsolPda",
            "type": "publicKey"
          },
          {
            "name": "wsolMint",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "peer",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "address",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "rateLimiter",
            "type": {
              "option": {
                "defined": "RateLimiter"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "allowedBroker",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "allowedToken",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mintAccount",
            "type": "publicKey"
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenDecimals",
            "type": "u8"
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "managerRole",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "roleHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "vaultAuthority",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "bump",
            "docs": [
              "Bump seed for the vault authority PDA"
            ],
            "type": "u8"
          },
          {
            "name": "owner",
            "type": "publicKey"
          },
          {
            "name": "depositNonce",
            "type": "u64"
          },
          {
            "name": "orderDelivery",
            "type": "bool"
          },
          {
            "name": "inboundNonce",
            "type": "u64"
          },
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "solChainId",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "withdrawBroker",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerIndex",
            "type": "u16"
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "withdrawToken",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mintAccount",
            "type": "publicKey"
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenDecimals",
            "type": "u8"
          },
          {
            "name": "tokenIndex",
            "type": "u8"
          },
          {
            "name": "allowed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    }
  ],
  "types": [
    {
      "name": "VaultDepositParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "accountId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "userAddress",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "srcChainId",
            "type": "u128"
          },
          {
            "name": "tokenAmount",
            "type": "u128"
          },
          {
            "name": "srcChainDepositNonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "LzMessage",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "msgType",
            "type": "u8"
          },
          {
            "name": "payload",
            "type": "bytes"
          }
        ]
      }
    },
    {
      "name": "AccountWithdrawSol",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "sender",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "receiver",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerIndex",
            "type": "u16"
          },
          {
            "name": "tokenIndex",
            "type": "u8"
          },
          {
            "name": "tokenAmount",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": "u64"
          },
          {
            "name": "chainId",
            "type": "u64"
          },
          {
            "name": "withdrawNonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "VaultWithdrawParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "accountId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "sender",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "receiver",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenAmount",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": "u128"
          },
          {
            "name": "chainId",
            "type": "u128"
          },
          {
            "name": "withdrawNonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "InitOAppParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "admin",
            "type": "publicKey"
          },
          {
            "name": "accountList",
            "type": "publicKey"
          },
          {
            "name": "endpointProgram",
            "type": {
              "option": "publicKey"
            }
          }
        ]
      }
    },
    {
      "name": "OAppLzReceiveParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "srcEid",
            "type": "u32"
          },
          {
            "name": "sender",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "guid",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "message",
            "type": "bytes"
          },
          {
            "name": "extraData",
            "type": "bytes"
          }
        ]
      }
    },
    {
      "name": "MessagingFee",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nativeFee",
            "type": "u64"
          },
          {
            "name": "lzTokenFee",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "SetAccountListParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "woofiProPda",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdcPda",
            "type": "publicKey"
          },
          {
            "name": "usdcMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawUsdtPda",
            "type": "publicKey"
          },
          {
            "name": "usdtMint",
            "type": "publicKey"
          },
          {
            "name": "withdrawWsolPda",
            "type": "publicKey"
          },
          {
            "name": "wsolMint",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "SetDelegateParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "delegate",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "SetEnforcedOptionsParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "send",
            "type": "bytes"
          },
          {
            "name": "sendAndCall",
            "type": "bytes"
          }
        ]
      }
    },
    {
      "name": "SetPeerParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "peer",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "SetRateLimitParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "refillPerSecond",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "capacity",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "enabled",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "TransferAdminParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "admin",
            "type": "publicKey"
          }
        ]
      }
    },
    {
      "name": "DepositParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "accountId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "userAddress",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "OAppSendParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nativeFee",
            "type": "u64"
          },
          {
            "name": "lzTokenFee",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "SetBrokerParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetManagerRoleParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "roleHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "managerAddress",
            "type": "publicKey"
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetOrderDeliveryParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "orderDelivery",
            "type": "bool"
          },
          {
            "name": "nonce",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "SetTokenParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mintAccount",
            "type": "publicKey"
          },
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetVaultParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "publicKey"
          },
          {
            "name": "depositNonce",
            "type": "u64"
          },
          {
            "name": "orderDelivery",
            "type": "bool"
          },
          {
            "name": "inboundNonce",
            "type": "u64"
          },
          {
            "name": "dstEid",
            "type": "u32"
          },
          {
            "name": "solChainId",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "SetWithdrawBrokerParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "brokerHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "brokerIndex",
            "type": "u16"
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "SetWithdrawTokenParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "tokenIndex",
            "type": "u8"
          },
          {
            "name": "allowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "RateLimiter",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "capacity",
            "type": "u64"
          },
          {
            "name": "tokens",
            "type": "u64"
          },
          {
            "name": "refillPerSecond",
            "type": "u64"
          },
          {
            "name": "lastRefillTime",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "OAppError",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "Unauthorized"
          },
          {
            "name": "InvalidSender"
          },
          {
            "name": "InvalidReceiver"
          },
          {
            "name": "InvalidOptions"
          },
          {
            "name": "InvalidEndpointProgram"
          },
          {
            "name": "RateLimitExceeded"
          },
          {
            "name": "WithdrawFailed"
          },
          {
            "name": "InvalidInboundNonce"
          },
          {
            "name": "InvalidReceiverTokenAccount"
          },
          {
            "name": "InvalidAdminTokenAccount"
          },
          {
            "name": "InvalidMessageType"
          },
          {
            "name": "InvalidTokenIndex"
          }
        ]
      }
    },
    {
      "name": "MsgType",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "Deposit"
          },
          {
            "name": "Withdraw"
          },
          {
            "name": "RebalanceBurn"
          },
          {
            "name": "RebalanceMint"
          }
        ]
      }
    }
  ],
  "events": [
    {
      "name": "SetAllowedBroker",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        }
      ]
    },
    {
      "name": "ResetAllowedBroker",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        }
      ]
    },
    {
      "name": "SetAllowedToken",
      "fields": [
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "ResetAllowedToken",
      "fields": [
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "SetWithdrawTokenIndex",
      "fields": [
        {
          "name": "tokenIndex",
          "type": "u8",
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "ResetWithdrawTokenIndex",
      "fields": [
        {
          "name": "tokenIndex",
          "type": "u8",
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "mintAccount",
          "type": "publicKey",
          "index": false
        }
      ]
    },
    {
      "name": "SetWithdrawBrokerEvent",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerIndex",
          "type": "u16",
          "index": false
        }
      ]
    },
    {
      "name": "ResetWithdrawBrokerEvent",
      "fields": [
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerIndex",
          "type": "u16",
          "index": false
        }
      ]
    },
    {
      "name": "SetManager",
      "fields": [
        {
          "name": "roleHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "managerAddress",
          "type": "publicKey",
          "index": false
        },
        {
          "name": "allowed",
          "type": "bool",
          "index": false
        }
      ]
    },
    {
      "name": "Deposited",
      "fields": [
        {
          "name": "user",
          "type": "publicKey",
          "index": false
        },
        {
          "name": "amount",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "Withdrawn",
      "fields": [
        {
          "name": "user",
          "type": "publicKey",
          "index": false
        },
        {
          "name": "amount",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "CreatedATA",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiverTokenAccount",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "VaultDeposited",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "userAddress",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "srcChainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "srcChainDepositNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "VaultWithdrawn",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "sender",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "fee",
          "type": "u128",
          "index": false
        },
        {
          "name": "chainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "FrozenWithdrawn",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "sender",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "fee",
          "type": "u128",
          "index": false
        },
        {
          "name": "chainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        }
      ]
    },
    {
      "name": "WithdrawSolFailed",
      "fields": [
        {
          "name": "accountId",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "sender",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "receiver",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "brokerHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenHash",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "tokenAmount",
          "type": "u64",
          "index": false
        },
        {
          "name": "fee",
          "type": "u128",
          "index": false
        },
        {
          "name": "chainId",
          "type": "u128",
          "index": false
        },
        {
          "name": "withdrawNonce",
          "type": "u64",
          "index": false
        },
        {
          "name": "reason",
          "type": "u8",
          "index": false
        }
      ]
    },
    {
      "name": "OAppSent",
      "fields": [
        {
          "name": "guid",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "dstEid",
          "type": "u32",
          "index": false
        }
      ]
    },
    {
      "name": "OAppReceived",
      "fields": [
        {
          "name": "guid",
          "type": {
            "array": [
              "u8",
              32
            ]
          },
          "index": false
        },
        {
          "name": "srcEid",
          "type": "u32",
          "index": false
        }
      ]
    }
  ],
  "errors": [
    {
      "code": 6000,
      "name": "InsufficientFunds",
      "msg": "Deposited funds are insufficient for withdrawal"
    },
    {
      "code": 6001,
      "name": "UserInfoBelongsToAnotherUser",
      "msg": "User info pda belongs to another user"
    },
    {
      "code": 6002,
      "name": "BrokerNotAllowed",
      "msg": "Broker is not allowed"
    },
    {
      "code": 6003,
      "name": "TokenNotAllowed",
      "msg": "Token is not allowed"
    },
    {
      "code": 6004,
      "name": "InvalidAccountId",
      "msg": "AccountId is invalid"
    },
    {
      "code": 6005,
      "name": "InvalidVaultOwner",
      "msg": "Vault owner is not the same as the payer"
    },
    {
      "code": 6006,
      "name": "ManagerRoleNotAllowed",
      "msg": "Manager role is not allowed"
    },
    {
      "code": 6007,
      "name": "ZeroDepositAmount",
      "msg": "Deposit amount must be greater than zero"
    },
    {
      "code": 6008,
      "name": "InsufficientWithdrawAmount",
      "msg": "Withdraw amount must be no less than withdraw fee"
    }
  ]
};
