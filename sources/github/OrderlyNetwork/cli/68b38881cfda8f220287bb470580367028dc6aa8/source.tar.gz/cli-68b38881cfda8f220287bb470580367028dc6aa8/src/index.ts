#!/usr/bin/env node
import { cac } from 'cac';
import kleur from 'kleur';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
function getVersion(): string {
  try {
    const pkg = JSON.parse(readFileSync(join(__dirname, '..', 'package.json'), 'utf8'));
    return pkg.version || '0.0.0';
  } catch {
    return '0.0.0';
  }
}
import { importKey, list, logout, show, exportKey, cleanup, revokeKey } from './commands/auth.js';
import {
  info,
  balance,
  statistics,
  limits,
  keyInfo,
  liquidations,
  feeTier,
} from './commands/account.js';
import {
  place,
  cancel,
  edit,
  cancelAll,
  listOrders,
  batchPlace,
  batchCancel,
  batchCancelByClientId,
  cancelByClientId,
  getOrder,
  orderTrades,
} from './commands/order.js';
import { listPositions, closePosition, positionHistory } from './commands/positions.js';
import {
  getPrice,
  getOrderbook,
  getSymbols,
  getKline,
  getMarketTrades,
  getFundingRates,
  getPriceChanges,
  getOpenInterest,
  getLiquidatedPositions,
  getSystemStatus,
} from './commands/market.js';
import { faucetUsdc } from './commands/faucet.js';
import {
  walletImport,
  walletList,
  walletShow,
  walletRemove,
  walletLogout,
  walletRegister,
  walletAddKey,
  walletCreate,
} from './commands/wallet.js';
import { getChains, getTokens, depositInfo, withdraw, assetHistory } from './commands/assets.js';
import { getOrSetLeverage } from './commands/leverage.js';
import { listTrades } from './commands/trades.js';
import {
  placeAlgoOrder,
  cancelAlgoOrder,
  cancelAllAlgoOrders,
  listAlgoOrders,
  editAlgoOrder,
  algoOrderTrades,
  getAlgoOrder,
  cancelAlgoOrderByClientId,
} from './commands/algo.js';
import { fundingHistory } from './commands/funding.js';
import { settlePnl, settlePnlHistory } from './commands/settle.js';
import { info as referralInfo } from './commands/referral.js';
import { distributionHistory, volumeStats } from './commands/stats.js';
import { inbox, inboxUnread } from './commands/notification.js';
import { brokerCreate, brokerStatus } from './commands/broker.js';
import { getDefaultNetwork } from './lib/config.js';
import { Network, WalletType } from './types.js';
import { OutputFormat, error, normalizeSymbol, normalizeOptionalSymbol } from './lib/output.js';

function findRawOption(optionName: string, hexOnly = true): string | undefined {
  for (let i = 0; i < process.argv.length - 1; i++) {
    if (process.argv[i] === `--${optionName}`) {
      const val = process.argv[i + 1];
      if (!hexOnly || val.startsWith('0x')) return val;
    }
    const pattern = hexOnly
      ? new RegExp(`^--${optionName}=(0x[a-fA-F0-9]+)$`)
      : new RegExp(`^--${optionName}=(.+)$`);
    const eqMatch = process.argv[i].match(pattern);
    if (eqMatch) return eqMatch[1];
  }
  return undefined;
}

function normalizeHexInput(
  value: unknown,
  optionName: string,
  label: string,
  example: string
): string | undefined {
  if (value === undefined || value === null) return findRawOption(optionName);
  const str = String(value);
  if (typeof value === 'number' || str.includes('e+') || str.includes('e-')) {
    const raw = findRawOption(optionName);
    if (raw) return raw;
    error(`Hex ${label} must be quoted to prevent parsing as numbers.`, [`Example: ${example}`]);
  }
  return str;
}

function normalizeAddress(address: unknown): string | undefined {
  return normalizeHexInput(
    address,
    'address',
    'addresses',
    '--address "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"'
  );
}

function requireAddress(address: unknown): string {
  const normalized = normalizeAddress(address);
  if (!normalized) error('Address is required.');
  return normalized;
}

function normalizeAccountId(accountId: unknown): string | undefined {
  return normalizeHexInput(
    accountId,
    'account',
    'account IDs',
    '--account "0x1e6b18f967e262ea4ee8a1efab67c578bcc45cdcfd435c15b6913dcf14d0217e"'
  );
}

function normalizeScope(scope: unknown): string | undefined {
  if (scope === undefined || scope === null) return findRawOption('scope', false);
  return String(scope);
}

const QUICK_START = `
${kleur.cyan().bold('QUICK START (Testnet)')}
${kleur.dim('─'.repeat(50))}

1. Create a new wallet:
   ${kleur.green('orderly wallet-create --type EVM')}

2. Register an Orderly account:
   ${kleur.green('orderly wallet-register --broker-id demo')}

3. Get test USDC (wait a few minutes for delivery):
   ${kleur.green('orderly faucet-usdc <address> --chain-id 421614')}

4. Add API key for trading:
   ${kleur.green('orderly wallet-add-key')}

5. Check balance:
   ${kleur.green('orderly account-balance')}

6. Place an order:
   ${kleur.green('orderly order-place PERP_ETH_USDC BUY MARKET 0.01')}
`;

const DESCRIPTION = `
${kleur.bold('Orderly Network CLI')}
${kleur.dim('Secure keychain-based trading CLI for Orderly Network')}

This CLI uses your OS keychain (Keychain/Credential Manager/libsecret) to store
private keys securely. Keys are NEVER exposed to AI context or logged.

${kleur.cyan().bold('SETUP FLOW')}
${kleur.dim('─'.repeat(50))}

${kleur.yellow('For new users:')}
  wallet-create    → Generate a new wallet (EVM or SOL)
  wallet-register  → Register wallet with Orderly (get account ID)
  wallet-add-key   → Generate & register Ed25519 API key for trading

${kleur.yellow('For existing Orderly users with API keys:')}
  auth-import      → Import existing Ed25519 API key directly

${kleur.cyan().bold('COMMANDS BY CATEGORY')}
${kleur.dim('─'.repeat(50))}

${kleur.yellow('Setup & Auth:')}
  wallet-create, wallet-import, wallet-list, wallet-show, wallet-remove
  wallet-register, wallet-add-key, wallet-revoke-key
  auth-import, auth-list, auth-show, auth-logout, auth-cleanup, auth-export-key

${kleur.yellow('Trading:')}
  order-place, order-cancel, order-edit, order-cancel-all, order-list
  order-get, order-cancel-by-client-id, order-trades
  batch-order-place, batch-order-cancel, batch-order-cancel-by-client-id
  algo-order-place, algo-order-cancel, algo-order-cancel-all, algo-order-edit, algo-order-list, algo-order-trades, algo-order-get, algo-order-cancel-by-client-id
  positions-list, positions-close, positions-history
  leverage, trades, funding-history

${kleur.yellow('Account:')}
  account-info, account-balance, account-statistics, account-limits
  key-info, fee-tier, account-liquidations

${kleur.yellow('Market Data:')}
  market-price, market-orderbook, market-trades, funding-rates, kline, symbols
  price-changes, open-interest, liquidated-positions, system-status

${kleur.yellow('Assets:')}
  chains, tokens, deposit-info, withdraw, asset-history

${kleur.yellow('PnL:')}
  settle-pnl, settle-pnl-history

${kleur.yellow('Referral:')}
  referral-info

${kleur.yellow('Stats & Notifications:')}
  distribution-history, volume-stats, notification-inbox, notification-unread

${kleur.yellow('Testnet Only:')}
  faucet-usdc

${kleur.yellow('Orderly One:')}
  broker-create
`;

const cli = cac('orderly');

cli
  .version(getVersion())
  .help(() => {
    const firstArg = process.argv[2];
    const hasSubcommand = firstArg && !firstArg.startsWith('-') && firstArg !== 'help';
    if (!hasSubcommand) {
      console.log(DESCRIPTION);
      console.log(QUICK_START);
    }
    console.log(kleur.bold('Global Options:'));
    console.log(kleur.dim('  --network <network>  Network: mainnet or testnet (default: testnet)'));
    console.log(kleur.dim('  --pretty             Pretty-print JSON output (2-space indent)'));
    console.log(kleur.dim('  --csv                Output as CSV instead of JSON (for list data)'));
    if (!hasSubcommand) {
      console.log('');
      console.log(kleur.dim('Run any command with --help for more details'));
      console.log(kleur.cyan('  orderly wallet-create --help'));
      console.log(kleur.cyan('  orderly order-place --help'));
    }
  })
  .option('--network <network>', 'Network: mainnet or testnet', {
    default: getDefaultNetwork(),
  })
  .option('--csv', 'Output as CSV instead of JSON (for list data)')
  .option('--pretty', 'Pretty-print JSON output (2-space indent)');

function getFormat(options: { csv?: boolean }): OutputFormat {
  return options.csv ? 'csv' : 'json';
}

// Wallet commands - Setup flow
cli
  .command('wallet-create', 'Create a new EVM or SOL wallet')
  .option('--type <type>', 'Wallet type: EVM or SOL (required in non-interactive mode)')
  .example('orderly wallet-create --type EVM')
  .example('orderly wallet-create --type SOL')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletCreate(options.type as WalletType, network);
  });

cli
  .command('wallet-import [private-key]', 'Import an existing wallet private key')
  .option('--type <type>', 'Wallet type: EVM or SOL (required in non-interactive mode)')
  .option('--address <address>', 'Wallet address (optional, derived from key)')
  .option(
    '--private-key <key>',
    'Private key (alternative to positional arg, for non-interactive use)'
  )
  .example('orderly wallet-import <private-key> --type EVM')
  .example('orderly wallet-import --private-key <key> --type SOL')
  .example('orderly wallet-import --type EVM')
  .action((privateKey, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletImport(
      options.type as WalletType,
      normalizeAddress(options.address),
      privateKey ?? options.privateKey,
      network
    );
  });

cli
  .command('wallet-list', 'List all stored wallets')
  .example('orderly wallet-list')
  .example('orderly wallet-list --network testnet')
  .action((options) => {
    const network = options.network as Network | undefined;
    void walletList(network, getFormat(options));
  });

cli
  .command(
    'wallet-show [address]',
    'Show wallet info (address required for AI/scripts, prompts if omitted)'
  )
  .example('orderly wallet-show')
  .example('orderly wallet-show 0x1234...')
  .action((address, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletShow(normalizeAddress(address), network, getFormat(options));
  });

cli
  .command(
    'wallet-remove [address]',
    'Remove wallet private key from keychain. WARNING: can cause permanent loss of access to dependent accounts.'
  )
  .option('--force', 'Skip confirmation prompt (required in non-interactive mode)')
  .example('orderly wallet-remove')
  .example('orderly wallet-remove 0x1234...')
  .example('orderly wallet-remove 0x1234... --force')
  .action((address, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletRemove(normalizeAddress(address), network, options.force === true);
  });

cli
  .command(
    'wallet-logout [address]',
    'Remove wallet from keychain (alias for wallet-remove)'
  )
  .action((address, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletLogout(normalizeAddress(address), network);
  });

cli
  .command('wallet-register', 'Register an Orderly account with your wallet (Step 2 of setup)')
  .option(
    '--broker-id <id>',
    'Broker ID, e.g., "demo" (required for AI/scripts, prompts if omitted)'
  )
  .option('--address <address>', 'Wallet address (required for AI/scripts, prompts if omitted)')
  .example('orderly wallet-register --broker-id demo')
  .example('orderly wallet-register --broker-id demo --address 0x1234...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletRegister(options.brokerId, normalizeAddress(options.address), network);
  });

cli
  .command('wallet-add-key', 'Add Orderly API key for trading (Step 3 of setup)')
  .option('--address <address>', 'Wallet address (required for AI/scripts, prompts if omitted)')
  .option('--scope <scope>', 'Key scopes: read,trading,asset (default: read,trading)')
  .option('--broker-id <id>', 'Broker ID (required when no API key stored for wallet)')
  .example('orderly wallet-add-key')
  .example('orderly wallet-add-key --scope read,trading')
  .example('orderly wallet-add-key --address "0x1234..." --broker-id demo --scope read,trading')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void walletAddKey(
      normalizeAddress(options.address),
      normalizeScope(options.scope),
      network,
      options.brokerId
    );
  });

cli
  .command(
    'wallet-revoke-key',
    [
      'Revoke the current Orderly API key (server-side + local keychain removal).',
      '',
      'WARNING: This permanently deactivates the key. You will lose ALL access',
      'to the account via this key. Use wallet-add-key to generate a new one after.',
    ].join('\n')
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .option('--force', 'Skip confirmation prompt (required in non-interactive mode)')
  .example('orderly wallet-revoke-key')
  .example('orderly wallet-revoke-key --account 0x1e6b...')
  .example('orderly wallet-revoke-key --account 0x1e6b... --force')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void revokeKey(normalizeAccountId(options.account), network, options.force === true);
  });

// Auth commands - For users with existing API keys
cli
  .command(
    'auth-import [private-key]',
    'Import existing Ed25519 API key (for users who already have one)'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly auth-import <base64-key> --account 12345')
  .action((privateKey, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void importKey(privateKey, normalizeAccountId(options.account), network);
  });

cli
  .command('auth-list', 'List all stored API keys (public keys only)')
  .option('--ids', 'Output only account IDs, one per line (for scripting/piping)')
  .example('orderly auth-list')
  .example('orderly auth-list --ids')
  .example('orderly auth-list --network testnet --ids')
  .action((options) => {
    const network = options.network as Network | undefined;
    void list(network, getFormat(options), options.ids || false);
  });

cli
  .command('auth-show', 'Show public key for an account')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly auth-show')
  .example('orderly auth-show --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void show(
      options.account ? normalizeAccountId(options.account) : undefined,
      network,
      getFormat(options)
    );
  });

cli
  .command('auth-logout [account-id]', 'Remove API key from keychain')
  .example('orderly auth-logout')
  .example('orderly auth-logout 12345')
  .action((accountId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void logout(accountId, network);
  });

cli
  .command('auth-cleanup', 'Remove all stored API keys for a network')
  .example('orderly auth-cleanup')
  .example('orderly auth-cleanup --network testnet')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cleanup(network);
  });

cli
  .command('auth-export-key [account-id]', 'Export Ed25519 private key (requires interactive TTY)')
  .example('orderly auth-export-key')
  .action((accountId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void exportKey(accountId, network);
  });

// Account commands
cli
  .command('account-info', 'Get account information')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly account-info')
  .example('orderly account-info --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void info(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('account-balance', 'Get account balances')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly account-balance')
  .example('orderly account-balance --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void balance(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command(
    'account-statistics',
    'Get account trading statistics (volume, fees, days since registration)'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly account-statistics')
  .example('orderly account-statistics --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void statistics(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command(
    'account-limits',
    'Get margin requirements and position limits.\n' +
      '  imr_factor: per-symbol factor used in initial margin calculation — IMR_i = max(1/max_leverage, base_imr, imr_factor * |notional|^0.8)\n' +
      '  max_notional: max position size in USD per symbol\n' +
      '  base_imr / base_mmr: minimum initial/maintenance margin ratios (shown with --symbol)\n' +
      '  base_mmr: threshold for liquidation — MMR_i = max(base_mmr, (base_mmr/base_imr) * imr_factor * |notional|^0.8)'
  )
  .option(
    '--symbol <symbol>',
    'Show limits for one symbol (includes base_imr, base_mmr, order rules)'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly account-limits')
  .example('orderly account-limits --symbol PERP_ETH_USDC')
  .example('orderly account-limits --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const sym = options.symbol ? normalizeOptionalSymbol(options.symbol as string) : undefined;
    void limits(normalizeAccountId(options.account), sym, network, getFormat(options));
  });

cli
  .command('key-info', 'Get registered API key info and scopes')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly key-info')
  .example('orderly key-info --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void keyInfo(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('fee-tier', 'Get current fee rates (futures, RWA, default)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly fee-tier')
  .example('orderly fee-tier --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void feeTier(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('account-liquidations', 'Get account liquidation history')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly account-liquidations')
  .example('orderly account-liquidations --symbol PERP_ETH_USDC')
  .example('orderly account-liquidations --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void liquidations(
      normalizeOptionalSymbol(options.symbol),
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

// Trading commands
cli
  .command('order-place <symbol> <side> [type] <quantity>', 'Place a new order')
  .usage(
    'order-place <symbol> <side> [type] <quantity>\n\n' +
      'Order types: MARKET, LIMIT, IOC, FOK, POST_ONLY, ASK, BID\n\n' +
      'If [type] is omitted, the short form is used — provide BID or ASK as <side>:\n' +
      '  BID → market buy (equivalent to BUY MARKET)\n' +
      '  ASK → market sell (equivalent to SELL MARKET)\n\n' +
      '  orderly order-place PERP_ETH_USDC BID 0.01\n' +
      '  orderly order-place PERP_ETH_USDC ASK 0.01\n\n' +
      'Side: BUY, SELL'
  )
  .option('--price <price>', 'Order price (required for LIMIT, IOC, FOK, POST_ONLY)')
  .option('--client-order-id <id>', 'Custom client order ID (optional)')
  .option('--reduce-only', 'Reduce-only order (can only reduce existing position, not open new)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-place PERP_ETH_USDC BUY MARKET 0.01')
  .example('orderly order-place PERP_ETH_USDC SELL LIMIT 0.01 --price 3500')
  .example('orderly order-place PERP_ETH_USDC BUY IOC 0.01 --price 2100')
  .example('orderly order-place PERP_ETH_USDC SELL FOK 0.01 --price 2100')
  .example('orderly order-place PERP_ETH_USDC BUY POST_ONLY 0.01 --price 2000')
  .example('# Short form (type omitted):')
  .example('orderly order-place PERP_ETH_USDC ASK 0.01')
  .example('orderly order-place PERP_ETH_USDC BID 0.01')
  .example('orderly order-place PERP_ETH_USDC BUY MARKET 0.01 --client-order-id my-order-123')
  .example('orderly order-place PERP_ETH_USDC SELL LIMIT 0.01 --price 3500 --reduce-only')
  .action((symbol, side, type, quantity, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    let resolvedSide: string = side;
    let resolvedType: string = type;
    let resolvedQuantity: string;
    if (quantity === undefined) {
      resolvedQuantity = type;
      resolvedType = side.toUpperCase();
      if (resolvedType === 'BID') {
        resolvedSide = 'BUY';
      } else if (resolvedType === 'ASK') {
        resolvedSide = 'SELL';
      } else {
        error(
          `Invalid short form. Use BID (market buy) or ASK (market sell), or provide all 4 args: <symbol> <side> <type> <quantity>`,
          [
            'Examples:',
            '  orderly order-place PERP_ETH_USDC BID 0.01',
            '  orderly order-place PERP_ETH_USDC BUY MARKET 0.01',
          ]
        );
        return;
      }
    } else {
      resolvedQuantity = quantity;
    }
    void place(
      normalizeSymbol(symbol),
      resolvedSide,
      resolvedType,
      resolvedQuantity,
      options.price,
      options.clientOrderId,
      options.reduceOnly === true,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('order-cancel <order-id>', 'Cancel an order')
  .option('--symbol <symbol>', 'Symbol of the order (auto-fetched if not provided)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-cancel 123456')
  .example('orderly order-cancel 123456 --symbol PERP_ETH_USDC')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cancel(
      orderId,
      normalizeOptionalSymbol(options.symbol),
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('order-edit <order-id>', 'Edit a pending order (only specify what to change)')
  .option('--symbol <symbol>', 'Symbol of the order (auto-fetched if not provided)')
  .option('--price <price>', 'New order price')
  .option('--quantity <quantity>', 'New order quantity')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-edit 123456 --price 3500')
  .example('orderly order-edit 123456 --quantity 0.02')
  .example('orderly order-edit 123456 --price 3500 --quantity 0.01')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void edit(
      orderId,
      normalizeOptionalSymbol(options.symbol),
      options.price,
      options.quantity,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('order-cancel-all', 'Cancel all orders')
  .option('--symbol <symbol>', 'Filter by symbol (optional)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-cancel-all')
  .example('orderly order-cancel-all --symbol PERP_ETH_USDC')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cancelAll(
      normalizeOptionalSymbol(options.symbol),
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('order-list', 'List orders (defaults to open/active orders)')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option(
    '--status <status>',
    'Filter by status. Individual: NEW, FILLED, CANCELLED, PARTIAL_FILLED, REJECTED. Bundled: INCOMPLETE (= NEW + PARTIAL_FILLED), COMPLETED (= FILLED + CANCELLED). Default: INCOMPLETE'
  )
  .option('--side <side>', 'Filter by side: BUY, SELL')
  .option('--order-type <type>', 'Filter by type: LIMIT, MARKET')
  .option(
    '--sort-by <sort>',
    'Sort: CREATED_TIME_ASC, CREATED_TIME_DESC, UPDATED_TIME_ASC, UPDATED_TIME_DESC'
  )
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25, max: 500)')
  .option('--all', 'Show all orders (overrides default INCOMPLETE filter)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-list')
  .example('orderly order-list --all')
  .example('orderly order-list --symbol PERP_ETH_USDC')
  .example('orderly order-list --status FILLED --symbol PERP_ETH_USDC')
  .example('orderly order-list --status COMPLETED')
  .example('orderly order-list --side BUY --order-type LIMIT')
  .example('orderly order-list --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    const status = options.status ?? (options.all ? undefined : 'INCOMPLETE');
    void listOrders(
      normalizeOptionalSymbol(options.symbol),
      status,
      options.side,
      options.orderType,
      options.sortBy,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('batch-order-place <orders>', 'Place multiple orders (max 10)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .usage(
    'batch-order-place <orders>\n\n' +
      'Each order object accepts these fields:\n\n' +
      '  CLI name              API name              Required  Description\n' +
      '  symbol                symbol                Yes       Trading pair (e.g. PERP_ETH_USDC)\n' +
      '  type                  order_type            Yes       LIMIT, MARKET, IOC, FOK, POST_ONLY, ASK, BID\n' +
      '  side                  side                  Yes       BUY or SELL\n' +
      '  quantity              order_quantity        Yes       Order quantity (positive number)\n' +
      '  price                 order_price           Cond.*    Order price (required for LIMIT, IOC, FOK, POST_ONLY)\n' +
      '  client_order_id       client_order_id       No        Custom ID, unique among open orders'
  )
  .example('# Using CLI-style field names (recommended):')
  .example(
    'orderly batch-order-place \'[{"symbol":"PERP_ETH_USDC","type":"LIMIT","side":"BUY","quantity":"0.01","price":"2000"}]\''
  )
  .example('# Using API field names (also accepted):')
  .example(
    'orderly batch-order-place \'[{"symbol":"PERP_ETH_USDC","order_type":"LIMIT","side":"BUY","order_quantity":"0.01","order_price":"2000"}]\''
  )
  .example('# From file:')
  .example('orderly batch-order-place orders.json')
  .action((orders, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void batchPlace(orders, normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('batch-order-cancel <...order-ids>', 'Cancel multiple orders by IDs')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly batch-order-cancel 123 456 789')
  .action((orderIds, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const ids = Array.isArray(orderIds) ? orderIds : [orderIds];
    void batchCancel(ids, normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command(
    'batch-order-cancel-by-client-id <...client-order-ids>',
    'Cancel multiple orders by client order IDs (max 10)'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly batch-order-cancel-by-client-id my-order-1 my-order-2 my-order-3')
  .action((clientOrderIds, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const ids = Array.isArray(clientOrderIds) ? clientOrderIds : [clientOrderIds];
    void batchCancelByClientId(
      ids,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command(
    'order-get [order-id]',
    'Get order details. Auto-detects numeric order ID vs client order ID'
  )
  .option('--client-order-id <id>', 'Explicitly look up by client order ID')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-get 123456')
  .example('orderly order-get my-order-123')
  .example('orderly order-get --client-order-id my-order-123')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getOrder(
      orderId,
      options.clientOrderId,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command(
    'order-cancel-by-client-id <client-order-id> <symbol>',
    'Cancel an order by client order ID'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-cancel-by-client-id my-order-123 PERP_ETH_USDC')
  .action((clientOrderId, symbol, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cancelByClientId(
      clientOrderId,
      normalizeSymbol(symbol),
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('order-trades <order-id>', 'Get trades for a specific order')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly order-trades 123456')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void orderTrades(orderId, normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('positions-list', 'List open positions')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly positions-list')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void listPositions(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('positions-close <symbol>', 'Close a position')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .option('--quantity <n>', 'Partial close quantity (default: full position)')
  .example('orderly positions-close PERP_ETH_USDC')
  .example('orderly positions-close PERP_ETH_USDC --quantity 0.005')
  .action((symbol, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const quantity = options.quantity !== undefined ? parseFloat(options.quantity) : undefined;
    void closePosition(
      normalizeSymbol(symbol),
      normalizeAccountId(options.account),
      network,
      getFormat(options),
      quantity
    );
  });

cli
  .command('market-orderbook <symbol>', 'Get orderbook snapshot')
  .option('--depth <n>', 'Number of price levels per side (default: all)')
  .example('orderly market-orderbook PERP_ETH_USDC')
  .example('orderly market-orderbook PERP_ETH_USDC --depth 10')
  .action((symbol, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const depth = options.depth != null ? parseInt(options.depth, 10) : undefined;
    void getOrderbook(normalizeSymbol(symbol), network, getFormat(options), depth);
  });

cli
  .command('positions-history', 'Get position history')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option('--start-time <timestamp>', 'Start timestamp (Unix ms)')
  .option('--end-time <timestamp>', 'End timestamp (Unix ms)')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly positions-history')
  .example('orderly positions-history --symbol PERP_ETH_USDC')
  .example('orderly positions-history --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const startT = options.startTime ? parseInt(options.startTime, 10) : undefined;
    const endT = options.endTime ? parseInt(options.endTime, 10) : undefined;
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void positionHistory(
      normalizeOptionalSymbol(options.symbol),
      startT,
      endT,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });
cli
  .command('leverage <symbol> [value]', 'Get or set leverage for a symbol')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly leverage PERP_ETH_USDC')
  .example('orderly leverage PERP_ETH_USDC 10')
  .action((symbol, value, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const leverageValue = value !== undefined ? parseFloat(value) : undefined;
    void getOrSetLeverage(
      normalizeSymbol(symbol),
      leverageValue,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('trades', 'Get trade history')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option('--start-time <timestamp>', 'Start timestamp (Unix ms)')
  .option('--end-time <timestamp>', 'End timestamp (Unix ms)')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25, max: 500)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly trades')
  .example('orderly trades --symbol PERP_ETH_USDC')
  .example('orderly trades --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const startT = options.startTime ? parseInt(options.startTime, 10) : undefined;
    const endT = options.endTime ? parseInt(options.endTime, 10) : undefined;
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void listTrades(
      normalizeOptionalSymbol(options.symbol),
      startT,
      endT,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command(
    'algo-order-place <symbol> <side> <algoType> <quantity>',
    [
      'Place an algo order.',
      '',
      'Valid algoTypes and their required flags:',
      '  STOP             --trigger-price',
      '  TP_SL            --tp-trigger-price and/or --sl-trigger-price',
      '  POSITIONAL_TP_SL --tp-trigger-price and/or --sl-trigger-price (quantity must be 0)',
      '  TRAILING_STOP    --callback-rate (1-15%)',
      '  BRACKET          --trigger-price + --tp-trigger-price and/or --sl-trigger-price',
      '',
      'Valid sides: BUY, SELL',
    ].join('\n')
  )
  .usage(
    [
      'algo-order-place <symbol> <side> <algoType> <quantity>',
      '',
      'Valid algoTypes and their required flags:',
      '  STOP             --trigger-price',
      '  TP_SL            --tp-trigger-price and/or --sl-trigger-price',
      '  POSITIONAL_TP_SL --tp-trigger-price and/or --sl-trigger-price (quantity must be 0)',
      '  TRAILING_STOP    --callback-rate (1-15%)',
      '  BRACKET          --trigger-price + --tp-trigger-price and/or --sl-trigger-price',
      '',
      'Valid sides: BUY, SELL',
    ].join('\n')
  )
  .option('--trigger-price <price>', 'Trigger price (required for STOP and BRACKET)')
  .option(
    '--callback-rate <rate>',
    'Trailing callback rate: 1-15 for percentage (e.g. 5 = 5%), or 0.01-0.15 as decimal. Required for TRAILING_STOP'
  )
  .option('--price <price>', 'Order price (for limit orders)')
  .option(
    '--tp-trigger-price <price>',
    'Take-profit trigger price (for TP_SL/POSITIONAL_TP_SL/BRACKET)'
  )
  .option('--tp-price <price>', 'Take-profit order price (optional, MARKET if not set)')
  .option(
    '--sl-trigger-price <price>',
    'Stop-loss trigger price (for TP_SL/POSITIONAL_TP_SL/BRACKET)'
  )
  .option('--sl-price <price>', 'Stop-loss order price (optional, MARKET if not set)')
  .option('--reduce-only', 'Reduce-only order (can only reduce existing position, not open new)')
  .option('--client-order-id <id>', 'Custom client order ID (optional)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-place PERP_ETH_USDC SELL STOP 0.01 --trigger-price 2000')
  .example(
    'orderly algo-order-place PERP_ETH_USDC SELL TP_SL 0.01 --tp-trigger-price 2500 --sl-trigger-price 1500'
  )
  .example(
    'orderly algo-order-place PERP_ETH_USDC SELL POSITIONAL_TP_SL 0 --tp-trigger-price 2500 --sl-trigger-price 1500'
  )
  .example('orderly algo-order-place PERP_ETH_USDC SELL TRAILING_STOP 0.01 --callback-rate 5')
  .example(
    'orderly algo-order-place PERP_ETH_USDC SELL BRACKET 0.01 --trigger-price 2300 --price 2300 --tp-trigger-price 2000 --sl-trigger-price 2500'
  )
  .action((symbol, side, algoType, quantity, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void placeAlgoOrder(
      normalizeSymbol(symbol),
      side,
      algoType,
      quantity,
      options.triggerPrice,
      options.callbackRate,
      options.price,
      options.tpTriggerPrice,
      options.tpPrice,
      options.slTriggerPrice,
      options.slPrice,
      options.reduceOnly,
      options.clientOrderId,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('algo-order-cancel <order-id>', 'Cancel an algo order')
  .option('--symbol <symbol>', 'Symbol of the order (auto-fetched if not provided)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-cancel 123456')
  .example('orderly algo-order-cancel 123456 --symbol PERP_ETH_USDC')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cancelAlgoOrder(
      orderId,
      normalizeOptionalSymbol(options.symbol),
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command(
    'algo-order-edit <order-id>',
    'Edit a pending algo order (only specify what to change: price, quantity, trigger-price, callback-rate)'
  )
  .option('--symbol <symbol>', 'Symbol of the order (auto-fetched if not provided)')
  .option('--price <price>', 'New order price')
  .option('--quantity <quantity>', 'New order quantity')
  .option('--trigger-price <price>', 'New trigger price')
  .option(
    '--callback-rate <rate>',
    'New callback rate: 1-15 for percentage, or 0.01-0.15 as decimal'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-edit 123456 --price 2500')
  .example('orderly algo-order-edit 123456 --quantity 0.02')
  .example('orderly algo-order-edit 123456 --trigger-price 1500')
  .example('orderly algo-order-edit 123456 --callback-rate 3')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void editAlgoOrder(
      orderId,
      normalizeOptionalSymbol(options.symbol),
      options.price,
      options.quantity,
      options.triggerPrice,
      options.callbackRate,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('algo-order-cancel-all', 'Cancel all algo orders')
  .option('--symbol <symbol>', 'Filter by symbol (optional)')
  .option('--algo-type <type>', 'Filter by algo type: STOP, TP_SL, TRAILING_STOP, BRACKET')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-cancel-all')
  .example('orderly algo-order-cancel-all --symbol PERP_ETH_USDC')
  .example('orderly algo-order-cancel-all --algo-type STOP')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cancelAllAlgoOrders(
      normalizeOptionalSymbol(options.symbol),
      options.algoType,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('algo-order-list', 'List algo orders (defaults to open/active orders)')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option(
    '--status <status>',
    'Filter by status. Individual: NEW, CANCELLED, PARTIAL_FILLED, FILLED, REJECTED. Bundled: INCOMPLETE (= NEW + PARTIAL_FILLED), COMPLETED (= FILLED + CANCELLED). Default: INCOMPLETE'
  )
  .option('--all', 'Show all orders (overrides default INCOMPLETE filter)')
  .option(
    '--algo-type <type>',
    'Filter by algo type: STOP, TP_SL, POSITIONAL_TP_SL, TRAILING_STOP, BRACKET'
  )
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25, max: 500)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-list')
  .example('orderly algo-order-list --all')
  .example('orderly algo-order-list --symbol PERP_ETH_USDC')
  .example('orderly algo-order-list --status COMPLETED')
  .example('orderly algo-order-list --algo-type STOP')
  .example('orderly algo-order-list --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    const status = options.status ?? (options.all ? undefined : 'INCOMPLETE');
    void listAlgoOrders(
      normalizeOptionalSymbol(options.symbol),
      status,
      page,
      size,
      options.algoType,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('algo-order-trades <order-id>', 'Get trades for a specific algo order')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-trades 123456')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void algoOrderTrades(orderId, normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('algo-order-get <order-id>', 'Get details for a specific algo order')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-get 123456')
  .action((orderId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getAlgoOrder(orderId, normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command(
    'algo-order-cancel-by-client-id <client-order-id> <symbol>',
    'Cancel an algo order by client order ID'
  )
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly algo-order-cancel-by-client-id my-algo-123 PERP_ETH_USDC')
  .action((clientOrderId, symbol, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void cancelAlgoOrderByClientId(
      clientOrderId,
      normalizeSymbol(symbol),
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('funding-history', 'Get funding fee history')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option('--start-time <timestamp>', 'Start timestamp (Unix ms)')
  .option('--end-time <timestamp>', 'End timestamp (Unix ms)')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly funding-history')
  .example('orderly funding-history --symbol PERP_ETH_USDC')
  .example('orderly funding-history --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const startT = options.startTime ? parseInt(options.startTime, 10) : undefined;
    const endT = options.endTime ? parseInt(options.endTime, 10) : undefined;
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void fundingHistory(
      normalizeOptionalSymbol(options.symbol),
      startT,
      endT,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('settle-pnl', 'Settle unrealized PnL into account balance')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly settle-pnl --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void settlePnl(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('settle-pnl-history', 'Get on-chain PnL settlement history')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly settle-pnl-history')
  .example('orderly settle-pnl-history --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void settlePnlHistory(
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('referral-info', 'Get referral information (referrer/referee stats and codes)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly referral-info')
  .example('orderly referral-info --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void referralInfo(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('distribution-history', 'Get broker fee and referral rebate history')
  .option('--status <status>', 'Filter by status: CREATED, SPLIT, COMPLETED')
  .option('--type <type>', 'Filter by type: BROKER_FEE, REFEREE_REBATE, REFERRER_REBATE')
  .option('--start-time <timestamp>', 'Start timestamp (Unix ms)')
  .option('--end-time <timestamp>', 'End timestamp (Unix ms)')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly distribution-history')
  .example('orderly distribution-history --type REFERRER_REBATE')
  .example('orderly distribution-history --status COMPLETED --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const startT = options.startTime ? parseInt(options.startTime, 10) : undefined;
    const endT = options.endTime ? parseInt(options.endTime, 10) : undefined;
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void distributionHistory(
      options.status,
      options.type,
      startT,
      endT,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('volume-stats', 'Get perp trading volume statistics (today, 1d, 7d, 30d, YTD, LTD)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly volume-stats')
  .example('orderly volume-stats --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void volumeStats(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('notification-inbox', 'List notification inbox messages')
  .option('--type <type>', 'Filter by type: TRADE or SYSTEM')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly notification-inbox')
  .example('orderly notification-inbox --type TRADE')
  .example('orderly notification-inbox --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void inbox(
      options.type,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

cli
  .command('notification-unread', 'Get unread notification count and messages')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly notification-unread')
  .example('orderly notification-unread --account 0x1e6b...')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void inboxUnread(normalizeAccountId(options.account), network, getFormat(options));
  });

cli
  .command('market-price <symbol>', 'Get current market price')
  .example('orderly market-price PERP_ETH_USDC')
  .example('orderly market-price PERP_BTC_USDC')
  .action((symbol, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getPrice(symbol, normalizeSymbol(symbol), network, getFormat(options));
  });

cli
  .command(
    'symbols',
    'List trading symbols. Default: compact list (symbol, pair, prices). Use --info for full order rules (lot size, min notional, price tick, etc.)'
  )
  .option(
    '--info',
    'Show detailed per-symbol order rules instead of compact list (calls /v1/public/info instead of /v1/public/futures)'
  )
  .example('orderly symbols')
  .example('orderly symbols --csv')
  .example('orderly symbols --info')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getSymbols(options.info, network, getFormat(options));
  });

cli
  .command(
    'kline <symbol> <type>',
    'Get candlestick/kline data. Valid intervals: 1m, 5m, 15m, 30m, 1h, 4h, 12h, 1d, 1w, 1mon'
  )
  .usage(
    'kline <symbol> <type>\n\n' +
      'Valid intervals: 1m, 5m, 15m, 30m, 1h, 4h, 12h, 1d, 1w, 1mon'
  )
  .option('--size <n>', 'Number of candles (default: 100, max: 1000)')
  .example('orderly kline PERP_ETH_USDC 1h')
  .example('orderly kline PERP_BTC_USDC 1d --size 30')
  .action((symbol, type, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const parsed = options.size != null ? parseInt(String(options.size), 10) : 100;
    if (isNaN(parsed) || parsed <= 0) {
      error(`Invalid --size value: "${options.size}". Must be a positive integer.`);
      return;
    }
    void getKline(normalizeSymbol(symbol), type, parsed, network, getFormat(options));
  });

cli
  .command('market-trades <symbol>', 'Get recent public trades')
  .option('--size <n>', 'Number of trades (default: 50)')
  .example('orderly market-trades PERP_ETH_USDC')
  .example('orderly market-trades PERP_BTC_USDC --size 20')
  .action((symbol, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const parsed = options.size != null ? parseInt(String(options.size), 10) : undefined;
    if (options.size != null && (isNaN(parsed!) || parsed! <= 0)) {
      error(`Invalid --size value: "${options.size}". Must be a positive integer.`);
      return;
    }
    void getMarketTrades(normalizeSymbol(symbol), parsed, network, getFormat(options));
  });

cli
  .command('funding-rates', 'Get public funding rates for all symbols (no auth required)')
  .option('--symbol <symbol>', 'Filter by symbol')
  .example('orderly funding-rates')
  .example('orderly funding-rates --symbol PERP_ETH_USDC')
  .example('orderly funding-rates --network mainnet')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getFundingRates(normalizeOptionalSymbol(options.symbol), network, getFormat(options));
  });

cli
  .command(
    'price-changes',
    'Get price changes for all symbols (5m, 30m, 1h, 24h, 7d, 30d) (no auth required)'
  )
  .example('orderly price-changes')
  .example('orderly price-changes --symbol PERP_ETH_USDC')
  .example('orderly price-changes --network mainnet')
  .option('--symbol <symbol>', 'Filter by symbol')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getPriceChanges(normalizeOptionalSymbol(options.symbol), network, getFormat(options));
  });

cli
  .command('open-interest', 'Get long/short open interest for all symbols (no auth required)')
  .option('--symbol <symbol>', 'Filter by symbol')
  .example('orderly open-interest')
  .example('orderly open-interest --symbol PERP_ETH_USDC')
  .example('orderly open-interest --network mainnet')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getOpenInterest(normalizeOptionalSymbol(options.symbol), network, getFormat(options));
  });

cli
  .command('liquidated-positions', 'Get public liquidated positions (no auth required)')
  .option('--symbol <symbol>', 'Filter by symbol')
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .example('orderly liquidated-positions')
  .example('orderly liquidated-positions --symbol PERP_ETH_USDC')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void getLiquidatedPositions(
      normalizeOptionalSymbol(options.symbol),
      page,
      size,
      network,
      getFormat(options)
    );
  });

cli
  .command('system-status', 'Get Orderly system maintenance status (no auth required)')
  .example('orderly system-status')
  .example('orderly system-status --network mainnet')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getSystemStatus(network, getFormat(options));
  });

// Testnet faucet
cli
  .command('faucet-usdc <address>', 'Get test USDC from faucet (testnet only)')
  .option(
    '--chain-id <id>',
    'Required. EVM: 421614 (Arbitrum Sepolia), 84532 (Base Sepolia). SOL: 901901901 (Devnet)'
  )
  .option('--broker-id <id>', 'Broker ID (default: demo)')
  .example('# EVM (Arbitrum Sepolia):')
  .example('orderly faucet-usdc 0x1234... --chain-id 421614')
  .example('orderly faucet-usdc 0x1234... --chain-id 421614 --broker-id demo')
  .example('# SOL (Devnet):')
  .example('orderly faucet-usdc <sol-address> --chain-id 901901901')
  .action((address, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const chainId = options.chainId ? String(options.chainId) : undefined;
    void faucetUsdc(
      requireAddress(address),
      chainId,
      network,
      getFormat(options),
      options.brokerId
    );
  });

// Broker ID creation
cli
  .command('broker-create [broker-id]', 'Create a broker ID via Orderly One')
  .option('--address <address>', 'EVM wallet address (prompts if not provided)')
  .option('--tx-hash <hash>', 'Payment tx hash (skip info, go straight to verify)')
  .option('--chain <chain>', 'Payment chain: ethereum, arbitrum, base')
  .option('--chain-id <id>', 'Chain ID: 1, 42161, 8453')
  .option('--payment-type <type>', 'Payment token: usdc, usdt, or order')
  .option('--maker-fee <bps>', 'Maker fee in basis points (-0.5 to 15)')
  .option('--taker-fee <bps>', 'Taker fee in basis points (3 to 15)')
  .option('--rwa-maker-fee <bps>', 'RWA maker fee in basis points (-0.5 to 15)')
  .option('--rwa-taker-fee <bps>', 'RWA taker fee in basis points (5 to 15)')
  .example('orderly broker-create')
  .example('orderly broker-create my-dex')
  .example('orderly broker-create my-dex --address 0x1234...')
  .example('# Direct verification after payment:')
  .example(
    'orderly broker-create my-dex --tx-hash 0xabc... --chain arbitrum --chain-id 42161 --payment-type usdc --maker-fee 0 --taker-fee 3 --rwa-maker-fee 0 --rwa-taker-fee 5'
  )
  .action((brokerId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const chainId = options.chainId ? parseInt(String(options.chainId), 10) : undefined;
    const makerFee = options.makerFee !== undefined ? parseFloat(String(options.makerFee)) : undefined;
    const takerFee = options.takerFee !== undefined ? parseFloat(String(options.takerFee)) : undefined;
    const rwaMakerFee = options.rwaMakerFee !== undefined ? parseFloat(String(options.rwaMakerFee)) : undefined;
    const rwaTakerFee = options.rwaTakerFee !== undefined ? parseFloat(String(options.rwaTakerFee)) : undefined;
    void brokerCreate(
      brokerId,
      normalizeAddress(options.address),
      normalizeHexInput(options.txHash, "tx-hash", "tx hashes", '--tx-hash "0xabc..."' ),
      options.chain,
      chainId,
      options.paymentType,
      makerFee,
      takerFee,
      rwaMakerFee,
      rwaTakerFee,
      network,
      getFormat(options)
    );
  });

cli
  .command("broker-status", "Show your DEX/broker status (requires EVM wallet)")
  .option("--address <address>", "EVM wallet address (prompts if not provided)")
  .example("orderly broker-status")
  .example("orderly broker-status --address 0x1234...")
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void brokerStatus(normalizeAddress(options.address), network, getFormat(options));
  });

// Asset commands
cli
  .command('chains', 'List supported chains (no auth required)')
  .option('--broker-id <id>', 'Filter chains by broker ID')
  .option('--verbose', 'Include broker_ids array for each chain')
  .example('orderly chains')
  .example('orderly chains --broker-id demo')
  .example('orderly chains --verbose')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getChains(network, getFormat(options), options.brokerId, options.verbose);
  });

cli
  .command('tokens', 'List supported tokens (no auth required)')
  .option('--verbose', 'Include chain_details array for each token')
  .example('orderly tokens')
  .example('orderly tokens --verbose')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    void getTokens(network, getFormat(options), options.verbose);
  });

cli
  .command('deposit-info <token> <chain-id>', 'Get deposit info for a token')
  .example('orderly deposit-info USDC 421614')
  .action((token, chainId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const format: OutputFormat = (options.csv as boolean) ? 'csv' : 'json';
    void depositInfo(token, Number(chainId), network, format);
  });

cli
  .command(
    'withdraw <token> <chain-id>',
    'Withdraw tokens (auto-signs with wallet key). Omit --receiver to withdraw to your own wallet address.'
  )
  .option('--receiver <address>', 'Destination address (defaults to your wallet address)')
  .option('--amount <amount>', 'Amount to withdraw (required, e.g. 10.5)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .option('--raw', 'Amount is in smallest units (default: false, use human-readable like 10.5)')
  .option(
    '--allow-cross-chain',
    'Allow cross-chain withdrawal (required when destination chain differs from deposit chain)'
  )
  .example('# Withdraw 10 USDC to your own wallet address')
  .example('orderly withdraw USDC 421614 --amount 10')
  .example('# Withdraw 10 USDC to a specific address')
  .example('orderly withdraw USDC 421614 --amount 10 --receiver 0x1234...')
  .example('# Withdraw to SOL chain (50 USDC)')
  .example('orderly withdraw USDC 901901901 --amount 50 --receiver <sol-address>')
  .example('# Use raw amount (10000000 = 10 USDC with 6 decimals)')
  .example('orderly withdraw USDC 421614 --amount 10000000 --raw --receiver 0x1234...')
  .example('# Withdraw to different chain (cross-chain)')
  .example('orderly withdraw USDC 84532 --amount 10 --receiver 0x1234... --allow-cross-chain')
  .action((token, chainId, options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    if (options.amount === undefined || options.amount === null) {
      error('Missing required option: --amount');
    }
    let receiver: string | undefined;
    if (options.receiver != null) {
      receiver = String(options.receiver);
      if (/^\d+(\.\d+)?(e\+?\d+)?$/i.test(receiver)) {
        const idx = process.argv.indexOf('--receiver');
        if (idx !== -1 && process.argv[idx + 1]) {
          receiver = process.argv[idx + 1];
        }
      }
    }
    void withdraw(
      token,
      String(options.amount),
      receiver,
      parseInt(chainId, 10),
      normalizeAccountId(options.account),
      network,
      options.raw,
      options.allowCrossChain,
      getFormat(options)
    );
  });

cli
  .command('asset-history', 'Get asset deposit/withdraw history')
  .option('--token <token>', 'Filter by token')
  .option('--side <side>', 'Filter by side: DEPOSIT or WITHDRAW')
  .option(
    '--status <status>',
    'Filter by status: NEW, CONFIRM, PROCESSING, COMPLETED, FAILED, PENDING_REBALANCE'
  )
  .option('--page <n>', 'Page number (default: 1)')
  .option('--size <n>', 'Page size (default: 25)')
  .option('--account <id>', 'Account ID (auto-resolves if single account)')
  .example('orderly asset-history')
  .example('orderly asset-history --side DEPOSIT')
  .example('orderly asset-history --status PROCESSING')
  .example('orderly asset-history --page 2 --size 50')
  .action((options) => {
    const network = (options.network as Network) || getDefaultNetwork();
    const page = options.page ? parseInt(options.page, 10) : undefined;
    const size = options.size ? parseInt(options.size, 10) : undefined;
    void assetHistory(
      options.token,
      options.side,
      options.status,
      page,
      size,
      normalizeAccountId(options.account),
      network,
      getFormat(options)
    );
  });

const rawArgs = process.argv.slice(2);

for (let i = 2; i < rawArgs.length; i++) {
  if (/^-\d+(\.\d+)?$/.test(rawArgs[i])) {
    console.error(
      `Error: Invalid argument "${rawArgs[i]}". Negative numbers look like CLI flags.\n` +
        `Use a positive value, or quote the value to avoid shell parsing issues.`
    );
    process.exit(1);
  }
}

try {
  cli.parse();

  if (rawArgs.length > 0 && !rawArgs[0].startsWith('-')) {
    const commandPart = rawArgs[0];
    const matched = cli.commands.some(
      (c) =>
        c.name === commandPart ||
        (Array.isArray(c.aliasNames) && c.aliasNames.includes(commandPart))
    );
    if (
      !matched &&
      commandPart !== 'help' &&
      !rawArgs.includes('--help') &&
      !rawArgs.includes('-h') &&
      !rawArgs.includes('--version') &&
      !rawArgs.includes('-v')
    ) {
      const { error: outputError } = await import('./lib/output.js');
      outputError(`Unknown command: ${commandPart}`, [
        `Run ${kleur.cyan('orderly --help')} to see available commands.`,
      ]);
      process.exit(1);
    }
  }
} catch (err) {
  if (err instanceof Error && err.name === 'CACError') {
    const message = err.message;
    const missingMatch = message.match(/missing required args for command `(.+)`/);
    if (missingMatch) {
      const commandName = missingMatch[1];
      error(`${message}`, [`Usage examples:`, `  orderly ${commandName} --help`]);
    }
    const unknownMatch = message.match(/Unknown option `(.+)`/);
    if (unknownMatch) {
      const flag = unknownMatch[1];
      const commandPart = rawArgs[0] || '';
      const hints: string[] = [];
      if (flag === '--account') {
        hints.push(`This command does not accept ${kleur.cyan('--account')}.`);
        const matchedCmd = cli.commands.find(
          (c) =>
            c.name === commandPart ||
            (Array.isArray(c.aliasNames) && c.aliasNames.includes(commandPart))
        );
        if (matchedCmd) {
          const hasAddress = matchedCmd.options.some((o: { name: string }) => o.name === 'address');
          if (hasAddress) {
            hints.push(`Did you mean ${kleur.cyan('--address <wallet-address>')}?`);
          }
          const hasAccountPos = matchedCmd.args.some(
            (a: { value: string }) => a.value === 'account-id' || a.value === 'account'
          );
          if (hasAccountPos) {
            hints.push(
              `This command takes account ID as a positional argument: ${kleur.cyan(`orderly ${commandPart} <account-id>`)}`
            );
          }
        }
      }
      if (hints.length === 0) {
        hints.push(`Run ${kleur.cyan(`orderly ${commandPart} --help`)} to see valid options.`);
      }
      error(message, hints);
    }
    error(message, [`Run ${kleur.cyan('orderly --help')} to see available commands.`]);
  }
  throw err;
}
