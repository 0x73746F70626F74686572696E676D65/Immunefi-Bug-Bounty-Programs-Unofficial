import { useMemo } from "react";
import { type RestrictedInfoOptions } from "@orderly.network/hooks";
import { useTranslation } from "@orderly.network/i18n";
import { AppLogos } from "@orderly.network/react-app";
import { TradingPageProps } from "@orderly.network/trading";
import { FooterProps, MainNavWidgetProps } from "@orderly.network/ui-scaffold";
import { OrderlyActiveIcon, OrderlyIcon } from "../components/icons/orderly";
import { PathEnum } from "../constant";

export type OrderlyConfig = {
  orderlyAppProvider: {
    appIcons: AppLogos;
    restrictedInfo?: RestrictedInfoOptions;
  };
  scaffold: {
    mainNavProps: MainNavWidgetProps;
    footerProps: FooterProps;
  };
  tradingPage: {
    tradingViewConfig: TradingPageProps["tradingViewConfig"];
    sharePnLConfig: TradingPageProps["sharePnLConfig"];
    referral?: any;
  };
};

const APP_ICONS: AppLogos = {
  main: {
    component: (
      <img
        alt="Orderly logo"
        src="/images/orderly-logo.svg"
        style={{ width: 100, height: 40 }}
      />
    ),
  },
  secondary: {
    img: "/images/orderly-logo-secondary.svg",
  },
};

const RESTRICTED_INFO: RestrictedInfoOptions = {
  enableDefault: true,
  customRestrictedIps: [],
  customRestrictedRegions: [],
};

const FOOTER_PROPS: FooterProps = {
  telegramUrl: "https://orderly.network",
  discordUrl: "https://discord.com/invite/orderlynetwork",
  twitterUrl: "https://twitter.com/OrderlyNetwork",
};

const TRADING_VIEW_CONFIG = {} as TradingPageProps["tradingViewConfig"];

const SHARE_PNL_CONFIG: TradingPageProps["sharePnLConfig"] = {
  backgroundImages: [
    "/images/pnl/poster_bg_1.png",
    "/images/pnl/poster_bg_2.png",
    "/images/pnl/poster_bg_3.png",
    "/images/pnl/poster_bg_4.png",
  ],
  color: "rgba(255, 255, 255, 0.98)",
  profitColor: "rgba(41, 223, 169, 1)",
  lossColor: "rgba(245, 97, 139, 1)",
  brandColor: "rgba(255, 255, 255, 0.98)",
  refLink: "https://orderly.network",
  refSlogan: "Orderly referral",
};

export const useOrderlyConfig = () => {
  const { t } = useTranslation();

  return useMemo<OrderlyConfig>(() => {
    return {
      scaffold: {
        mainNavProps: {
          mainMenus: [
            { name: t("common.trading"), href: PathEnum.Root },
            { name: t("common.portfolio"), href: PathEnum.Portfolio },
            { name: t("common.markets"), href: PathEnum.Markets },
            {
              name: t("tradingLeaderboard.leaderboard"),
              href: PathEnum.Leaderboard,
            },
            {
              name: t("tradingRewards.rewards"),
              href: PathEnum.Rewards,
              children: [
                {
                  name: t("common.affiliate"),
                  href: PathEnum.RewardsAffiliate,
                  tag: t("extend.affiliate.tag"),
                  description: t("extend.affiliate.description"),
                },
                {
                  name: t("extend.staking"),
                  href: "https://app.orderly.network/staking",
                  description: t("extend.staking.description"),
                  target: "_blank",
                  icon: <OrderlyIcon size={14} />,
                  activeIcon: <OrderlyActiveIcon size={14} />,
                },
              ],
            },
          ],
          initialMenu: PathEnum.Root,
        },
        footerProps: FOOTER_PROPS,
      },
      orderlyAppProvider: {
        appIcons: APP_ICONS,
        restrictedInfo: RESTRICTED_INFO,
      },
      tradingPage: {
        tradingViewConfig: TRADING_VIEW_CONFIG,
        sharePnLConfig: SHARE_PNL_CONFIG,
      },
    };
  }, [t]);
};
