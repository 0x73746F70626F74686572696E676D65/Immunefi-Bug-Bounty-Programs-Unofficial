const { ethers } = require("hardhat")
const deployment = require('../../../deployment.json');
const config = require('../../../config.json');
const { getAccountId, getStrategyProviderId, getVaultId } = require('../../utils/getId');
const { get } = require("http");

const broker = "0x95d85ced8adb371760e4b6437896a075632fbd6cefe699f8125a8bc1d9b19e5b"

async function main() {
    //!need to change with your env
    const env = "dev";

    const pvLedger = await ethers.getContractAt(
        "ProtocolVaultLedger",
        deployment[env].pvLedger
    )
    console.log("vault id:", getVaultId(deployment[env].protocolVault, broker)); //0x
    console.log("accountId: ", getAccountId("0xFae9CAF31EeD9f6480262808920dA03eb7f76E7E",broker)); //0xf9fdd8648d22ef32e665f03249fe52804bc181cca3a98e3a16d18b41e34bc8d1
    console.log("spId: ", getStrategyProviderId(deployment[env].protocolVault, deployment[env].allowedSP, broker));//0x652385add0dfdff0e87bee89a7a5e4818145a3e4844c300c7b82baa926d1f0f9
}

main()
