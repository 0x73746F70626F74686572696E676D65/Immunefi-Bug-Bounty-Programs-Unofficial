import "@nomicfoundation/hardhat-toolbox";
import "@openzeppelin/hardhat-upgrades";
import "@typechain/hardhat";
import "dotenv/config";
import "hardhat-deploy";
import "hardhat-deploy-ethers";
import "hardhat-contract-sizer";
import type { HardhatUserConfig } from "hardhat/config";
import { task } from "hardhat/config";

import "./scripts/tasks/deploy_to";
import "./scripts/tasks/verify_local";
import "./scripts/tasks/verify_etherscan";
import "./scripts/tasks/verify_hardhat";
import "./scripts/tasks/ledger_role_management";
import "./scripts/tasks/ledger_md";
import "./scripts/tasks/mdl1";
import "./scripts/tasks/ol_qa_setup";

task("accounts", "Prints the list of accounts", async (_args, hre) => {
  const accounts = await hre.ethers.getSigners();
  accounts.forEach(async account => console.info(account.address));
});

const accounts = {
  mnemonic: process.env.MNEMONIC || "test test test test test test test test test test test junk"
};

const config: HardhatUserConfig = {
  defaultNetwork: "hardhat",
  solidity: {
    version: "0.8.22",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  namedAccounts: {
    deployer: {
      default: 0
    },
    owner: {
      default: 0
    },
    user: {
      default: 1
    }
  },
  typechain: {
    outDir: "types",
    target: "ethers-v6"
  },
  paths: {
    artifacts: "artifacts",
    cache: "cache",
    deploy: "scripts/deploy",
    deployments: "deployments",
    imports: "imports",
    sources: "contracts",
    tests: "test"
  },
  networks: {
    localhost: {
      chainId: 31337,
      live: false,
      saveDeployments: true,
      tags: ["local"]
    },
    hardhat: {
      forking: {
        enabled: true,
        url: "https://api.avax.network/ext/bc/C/rpc",
        blockNumber: 6394745
      },
      allowUnlimitedContractSize: true,
      live: false,
      saveDeployments: true,
      tags: ["test", "local"]
    },
  },
  etherscan: {
    apiKey: {
    },
    customChains: [
    ]
  },
  external: {
    contracts: [
      {
        artifacts: "node_modules/@layerzerolabs/test-devtools-evm-hardhat/artifacts",
        deploy: "node_modules/@layerzerolabs/test-devtools-evm-hardhat/deploy"
      }
    ],
    deployments: {
      hardhat: ["external"]
    }
  },
  mocha: {
    // timeout: 100000000
  },
  gasReporter: {
    enabled: process.env.REPORT_GAS ? true : false
  },
  sourcify: {
    enabled: true
  }
};

export default config;
