---
name: Bug report
about: Create a report to help us improve
title: 'Fix [Subject of the issue]'
labels: 'bug'
assignees: ''

---

## Description

Describe your issue in as much detail as possible here.

## Your environment

* OS and version
* branch that causes this issue
* Device (Nano S, Nano X, Nano S+)

## Steps to reproduce

* Tell us how to reproduce this issue <br />
* Where the issue is, if you know <br />
* Which commands triggered the issue, if any

## Expected behaviour

Tell us what should happen

## Actual behaviour

Tell us what happens instead

## Logs

Please paste any logs here that demonstrate the issue, if they exist

## Proposed solution

If you have an idea of how to fix this issue, please write it down here, so we can begin discussing it
