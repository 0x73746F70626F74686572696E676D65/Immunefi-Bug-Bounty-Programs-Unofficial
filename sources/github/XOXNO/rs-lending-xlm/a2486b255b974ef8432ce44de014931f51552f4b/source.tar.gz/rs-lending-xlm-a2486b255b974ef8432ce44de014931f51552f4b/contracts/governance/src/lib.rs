//! Lending Governance contract: a timelocked, role-gated admin contract
//! that deploys and administers the controller and price aggregator
//! contracts.

#![no_std]

mod access;
mod api;
mod constants;
mod deploy;
mod events;
pub mod op;
mod storage;
mod timelock;
mod validate;

#[cfg(test)]
#[path = "../tests/flows.rs"]
mod tests;

#[cfg(test)]
#[path = "../tests/support.rs"]
mod test_support;

use soroban_sdk::{contract, contractmeta};

pub use crate::constants::{
    TIMELOCK_MAX_DELAY_LEDGERS, TIMELOCK_MIN_DELAY_LEDGERS, TIMELOCK_SENSITIVE_MIN_DELAY_LEDGERS,
};

pub use stellar_governance::timelock::OperationState;

contractmeta!(key = "name", val = "Lending Governance");
contractmeta!(key = "binver", val = env!("CARGO_PKG_VERSION"));
contractmeta!(
    key = "repo",
    val = "https://github.com/xoxno/rs-lending-xlm"
);

/// The governance contract. Owns the controller and price aggregator
/// contracts and gates their administration behind role-based access
/// control and a timelock.
#[contract]
pub struct Governance;
