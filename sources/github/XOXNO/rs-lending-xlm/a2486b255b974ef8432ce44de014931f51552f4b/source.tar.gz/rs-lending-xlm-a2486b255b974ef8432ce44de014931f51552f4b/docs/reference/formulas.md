# Formulas and rounding

This reference defines the units, rounding and arithmetic limits used to value
positions and settle funds. [Runtime invariants](invariants.md) identify the
operations that enforce each constraint.

Expressions use raw integers. `half_up`, `floor` and `ceil` apply to the entire
fraction; the pseudocode does not imply unchecked Rust multiplication.

## Units and arithmetic domain

| Quantity | Scale |
|---|---|
| Shares, indexes, asset values used by the rate engine, rates, utilization | RAY = 10^27 |
| USD values, prices per whole token, health factor | WAD = 10^18 |
| Risk ratios and fees | BPS = 10,000 |
| Transfers and accounting cash | Native token base units |
| Accrual time | Milliseconds; year = 31,556,926,000 ms |

Protocol boundaries require non-negative amounts; `Ray`, `Wad` and `Bps`
constructors do not enforce that restriction themselves. Multiply-divide uses
an `i128` fast path or an exact `I256` intermediate. Unrepresentable results
raise `MathOverflow`, except at explicit saturating sites; zero divisors raise
`DivisionByZero`.

Half-up multiply-divide requires non-negative operands and a positive divisor.
Raw floor and ceiling multiply-divide also support signed quotients. Decimal
upscaling uses checked `i128` arithmetic. Downscaling and division by a positive
integer support the signed extremes; signed half-up downscaling rounds exact
halves away from zero.

## Shares and token amounts

For an asset with `d` decimals, first normalize token units into RAY. Multiplying
shares by an index returns a RAY asset value, requiring a second conversion
before a token transfer:

```rust
let amount_ray = token_units * 10_i128.pow(27 - d); // exact, checked
let value_ray = round(shares_ray * index_ray / RAY);
let token_units = round(value_ray / 10_i128.pow(27 - d));
let shares_ray = round(amount_ray * RAY / index_ray);
```

| Boundary | Direction |
|---|---|
| Supply mint | floor |
| Partial withdrawal burn | ceil |
| Debt mint | ceil |
| Partial repayment burn | floor |
| Supply claim paid in tokens | floor at both conversion steps |
| Debt full-close amount | ceil at both conversion steps |
| Displayed balance | half-up at both conversion steps |

A withdrawal request of at least the half-up displayed supply balance burns all
supply shares and pays their floor-valued balance. A repayment of at least the
ceiled debt balance burns all debt shares and refunds the excess.

Positive supply and borrow amounts must mint shares. Positive net repayment
and gross withdrawal amounts must burn shares. A zero-share result reverts at
these boundaries.

### Same-asset net settlement

Net settlement offsets supply against debt without moving cash:

```rust
let overlap = min(request, min(floor(supply), ceil(debt)));
```

The overlap burns all shares on a side when it exhausts that side's conservative
value. Partial settlement ceils the supply-share burn and floors the debt-share
burn, each capped at the held shares. Positive settlement must burn shares on
both sides.

## Cash, supply, debt, and revenue

Revenue is a supply-share claim included in total supplied shares. Revenue
minting increases both totals equally; claiming revenue burns both equally.
Reclassifying seized collateral as revenue leaves total supply unchanged.
Tracked cash is a separate reserve balance that incidental token donations do
not increase.

### Backing and cash constraints

The market's backing check uses native units:

```rust
let shortfall = max(0, floor(supply_value) - (cash + ceil(debt_value)));
```

Addition and subtraction saturate. Supply entry rejects a positive shortfall.
Recapitalization credits at most that shortfall, refunds excess and mints no
shares.

Borrow draws must retain a 200 BPS liquidation buffer, rounded up from the
floored supplied token value. Borrow, user withdrawal and revenue claims
enforce the configured utilization ceiling; liquidation withdrawal skips it.
That gate divides ceiled debt value by floored supply value and rounds the
ratio up; debt against a zero floored supply value fails it.
Withdrawal, net settlement and revenue claims reject zero total supply with
outstanding debt. These checks apply at their respective boundaries; they do
not establish full backing after every mutation.

### Revenue payout

Payout is limited by cash and the floor-valued revenue claim:

```rust
let payout = min(cash, floor(revenue_value));
let burned = if payout == floor(revenue_value) { revenue_shares }
    else { ceil(revenue_shares * payout / floor(revenue_value)) };
```

The share-burn calculation applies to a positive payout. A positive payout
cannot burn zero shares.

## Rates and accrual

### Utilization and annual rates

Utilization divides half-up-valued debt by half-up-valued total supply:

```rust
let utilization_ray = half_up(debt_value_ray * RAY / supply_value_ray);
```

Zero supplied value gives zero utilization. Rate selection caps utilization at
one RAY. The annual borrow curve has three joined linear regions: base plus
slope1 up to mid utilization, slope2 up to optimal, then slope3 up to full
utilization. Each slope contribution uses half-up multiplication followed by
half-up division. The result cannot exceed the configured maximum, which is
limited to 200% APR.

Accrual uses the per-millisecond rate `per_ms`. Pool borrow and deposit rate
views return annual RAY fractions from stored indexes, without first accruing
or projecting them:

```rust
let per_ms = half_up(annual_borrow_rate_ray / 31_556_926_000);
let rate_x_util = half_up(utilization_ray * annual_borrow_rate_ray / RAY);
let deposit_apr_ray = half_up(rate_x_util * (BPS - reserve_factor_bps) / BPS);
```

Deposit APR has two rounding steps and is not an exact realized supplier return.
It is zero at zero utilization or an out-of-range reserve factor.

### Compounding and interest allocation

Accrual processes elapsed time in chunks of at most one year. Each chunk uses
its starting utilization and rate to approximate
`exp(per_ms * delta_ms / RAY)` through the eighth-order Taylor term, with
fixed-point half-up arithmetic. No elapsed time means no accrual. Index
projections and mutations use the same step calculation.

Borrower interest is the difference between half-up-valued debt at the new and
old borrow indexes. The reserve factor allocates a half-up protocol fee; the
remainder is supplier rewards.

The supply index floors the new total value divided by supplied shares, bounded
by the old index and the supply-index ceiling. Rewards not reflected in that
index change join the protocol reward. Revenue shares are floor-converted at
the new supply index and capped by remaining total-supply share headroom. This
last floor and cap can leave reward value unrepresented by revenue shares.
Exact conservation of booked supplier and revenue value is not guaranteed.

### Accrual cadence

Call cadence can change borrower cost. Each chunk holds its starting rate
constant; subsequent chunks recalculate utilization. Taylor truncation and
integer rounding also depend on how time is partitioned. A finer partition
does not generally guarantee the same result, a larger result or an exact
continuous-exponential bound.

## Valuation and health

A position uses one rounding direction at all three boundaries:

```rust
let asset_ray = round(shares_ray * index_ray / RAY);
let asset_wad = round(asset_ray / 1_000_000_000);
let value_usd_wad = round(asset_wad * price_wad / WAD);
```

Risk collateral floors all three valuation steps. Risk BPS weights convert
BPS→WAD half-up, then multiply that ratio into the floored position value with
floor rounding (`Bps::apply_to_wad_floor`). LTV weighting uses the position's
stored `min(LTV, liquidation_threshold)`; health weighting uses its stored
liquidation threshold. Risk debt rounds upward, while the separate debt display
rounds half-up. The unweighted collateral total also rounds half-up and is used
for liquidation proportions and dust eligibility.

```rust
let health_factor_wad = floor(weighted_collateral_wad * WAD / debt_wad);
```

Health factor saturates at `i128::MAX`; debt-free accounts use that sentinel.
Liquidation requires debt and health below one WAD. Risk-increasing actions
with debt remaining require debt within LTV collateral, health at least one
WAD and any configured minimum LTV collateral. Listing, cap and pause gates
also apply; [risk invariants](invariants.md#inv-risk-01) define their scope.

## Liquidation sizing and fees

Liquidation calculates a bonus, sizes repayment toward a target health factor,
then distributes seizure across collateral. The quote can differ from final
settlement because of rounding and measured token receipt.

### Bonus and target repayment

| Symbol | Meaning, in raw WAD |
|---|---|
| `D` | Risk-valued debt |
| `C` | Unweighted collateral |
| `W` | Liquidation-threshold-weighted collateral |
| `HF` | Health factor |
| `H` | Target health factor |
| `b` | Selected bonus converted from BPS |

The ratio `p` is the account's blended liquidation threshold. This pseudocode
shows each WAD rescaling and half-up rounding step. For the selected bonus,
the collateral-backed repayment limit and target repayment are:

```rust
let p = if C == 0 { 0 } else { half_up(W * WAD / C) };
let hf_bonus_cap_bps = floor(HF * BPS / p) - BPS; // only p > 0 and HF < WAD
let weighted_seizure = half_up(p * (WAD + b) / WAD);
let target_debt = half_up(H * D / WAD);
let backed_max = min(D, half_up(C * WAD / (WAD + b)));
let ideal = if H <= weighted_seizure || target_debt <= W { backed_max }
    else { min(backed_max, half_up((target_debt - W) * WAD / (H - weighted_seizure))) };
```

The base bonus averages the stored collateral bonuses by half-up-valued USD
weight, using half-up division and multiplication. It is bounded by
`floor(BPS * (BPS - t) / t)`, where
`t = clamp(ceil(p * BPS / WAD), 1, BPS)`. Zero `p` gives a zero threshold bonus
bound; zero collateral also gives a zero base bonus.

The configured curve ramps the base-to-maximum increment as health falls, then
applies its BPS factor `f`. `H` is the spoke's `liquidation_target_hf_wad` and
`K` is its `hf_for_max_bonus_wad`:

```rust
let s = if HF >= H { 0 } else { min(WAD, half_up((H - HF) * WAD / (H - K))) };
let curve = base + half_up(f * half_up((max - base) * s / WAD) / BPS);
```

The ramp starts at `H`, not at `HF = 1`. An account becomes liquidatable only
below `HF = 1`, so its first bonus is already about
`base + f * (max - base) * (H - 1) / (H - K)`. The maximum comes only from the
blended threshold, not from the listed `liquidation_bonus`: `LT = 6000` gives
`max = 6666`. With `H = 1.10`, `K = 0.80`, `f = 10000` and `base = 500`, the
bonus is about 2557 BPS just below `HF = 1` and 4611 BPS at `HF = 0.90`. Size
`H`, `K` and `f` from the bonus at `HF = 1` and at `K`, not from the listed
bonus. The [Liqvid bonus curve](runbooks/liqvid-listing-params.md#4-the-bonus-curve)
shows a full table.

The HF-preserving cap above limits the result. With a
positive `p`, insolvency or a cap below base bypasses the target formula:

```rust
let quote = if p > 0 && C < D { (min(D, floor(C * WAD / (WAD + base))), base) } // insolvent
    else if p > 0 && cap < base { (D, max(cap, 0)) } // band: D <= C < D * (1 + base)
    else { /* target formula at min(curve, cap), or at curve when p == 0 */ };
```

In the band the quote is the full debt at the cap, and any smaller payment is
accepted. A partial repayment `x` seizes `x * (1 + cap)`, at most `x * C / D`,
so `C / D` and the health factor do not fall; the BPS floor of the cap can
raise them slightly.

Insolvency is the exact unweighted comparison `C < D`. With positive `p`, the
insolvency branch quotes the repayment the collateral backs at the base bonus,
floored, so an offer above it is trimmed and the liquidator never pays more
than it seizes. On an insolvent account the trim rounds each kept leg down to
whole token units, so the kept
value never exceeds the quote. A leg whose kept amount rounds to zero is
dropped and its whole offer refunded; if no leg remains, `liquidate` reverts
with `InvalidPayments` (16) and the estimate shows a zero payment. This insolvency
branch does not promote the quote to full debt; bad-debt cleanup takes the unbacked
residue. With `p == 0`, the target formula and dust promotion below apply instead.

A partial seizure leg below 3 decimals takes whole token units only. When the
repayment covers the whole debt, the leg rounds up to the held balance and
the debt closes. Otherwise it rounds down: the dropped fraction's USD value,
divided by `1 + bonus` and floored, is trimmed from the repayment and
refunded, kept amounts rounding up, so the liquidator pays for the units it
receives, and a plan that then seizes nothing reverts with `InvalidPayments`
(16). Neither applies when an insolvent account's repayment reaches the
collateral-backed quote: that call seizes every unit. Such a leg is its
account's only supply position, so it is the whole collateral and the seizure
stays proportional, and an action that leaves debt needs at least 2 whole
units in it.

The controller can change a partial quote for such a leg. All of these
conditions must be true: the account is solvent (`C >= D`), the curve quote is
below `D`, the leg is the account's only supply position, and the leg holds at
least one whole unit. Let `U` be the WAD USD value of one whole unit, `b` the
bonus and `m = max(floor(U / 1e6), 1)` in raw WAD. Let `R` be the sum, over the
account's debt legs, of the USD value of one base unit of that debt token. `R`
is the per-leg ceiling rounding that a full close can record. The controller
applies the first rule that matches:

1. If `floor(U / (1 + b)) >= D + R`, the quote becomes `D`. The plan closes in
   full and the leg rounds up to one whole unit. The liquidator repays all
   debt and receives one unit.
2. If the curve quote seizes less than `U + m`, and
   `ceil((U + m) / (1 + b)) < D`, the quote rises to
   `ceil((U + m) / (1 + b))`. The seizure takes one unit. It refunds the
   margin that it does not seize, rounded down to whole debt-token units.
3. Otherwise the curve quote stays.

The raised quote is a ceiling, not a floor. A smaller offer is not raised. An
offer that backs less than one whole unit seizes nothing and reverts with
`InvalidPayments` (16). An offer between `U / (1 + b)` and the raised quote
still takes one unit. Size offers for such a leg from
`get_liquidation_estimate`, not from the curve formula.

The HF-preserving bonus cap keeps `1 + b <= C / D`, so the sale of one unit does
not lower `C / D`. Thus a solvent account whose only supply leg is below 3
decimals and holds a whole unit stays liquidatable below `HF = 1`, by a
one-unit sale or by a full close. There is one exception. While
`floor(U / (1 + b)) - R < D <= ceil((U + m) / (1 + b))`, neither rule 1 nor
rule 2 applies. If the curve quote then backs less than one unit, every offer
reverts until accrual or a price move ends that state.

A rule-1 full close pays the liquidator one unit worth `U` for `D`. Its
effective bonus is `U / D - 1`, not `b`. With `k` held units and liquidation
threshold `LT`, `HF < 1` gives `k * U * LT < D`, so the effective bonus is at
most about `1 / (k * LT) - 1`. The borrower loses `U - D * (1 + b)` above the
normal bonus. `bonus_rate_bps` in the estimate and `bonus_bps` in
`LiquidationEvent` show only `b`. A listing below 3 decimals has no liquidation
fee, so no protocol fee applies to that excess.

For positive `p`, `HF / p` approximates `C / D`, but `HF` floors and `p` rounds
half-up, so an account at
`C == D`, or a few raw WAD units above it, can compute a cap of `-1`. Such a
covered account takes the band quote with the cap clamped to zero. A full close
repays all of `D`, so no debt is left to socialize. Seizure floors to whole
token units, so it takes `C` less at most one token unit per collateral leg.
That unit stays with the account as collateral. Bad-debt cleanup does not
sweep it, because the account has no debt.

An ideal residual debt strictly between zero and $5 also promotes the quote to
full debt, without requiring full funding. A raised whole-unit quote is not
promoted to full debt, so it can leave debt below $5. Each input is capped at
its leg's ceiling-rounded debt, and the excess is listed as a refund. A partial quote
also trims the inputs above the quote from the last leg backward before tokens
are pulled, and execution pulls the trimmed amount. On a solvent account the
trim floors the refund, so the kept amount can round up by one token unit. A
full-debt quote trims nothing: the per-leg ceilings can exceed `D` by unit
rounding, and the repayment credits every unit of them. Execution then pulls
each merged offered amount and the pool refunds what exceeds each leg's debt,
which is exactly the listed refund. Neither a full-debt quote nor the target
health factor guarantees an executed full close after rounding or
under-delivery.

### Seizure and fees

Seizure is proportional to collateral value and capped at held value. The bonus
is the capped seizure minus the floor-divided uncapped principal, bounded below
by zero. A collateral cap below principal leaves no bonus to charge.

Partial seizure floors the token amount and seized shares. Full seizure uses
the half-up token amount to request a full pool withdrawal and takes the exact
held shares for Credit mode; the pool payout still floors the supply claim.
Bonus shares floor at the supply index and cannot exceed seized shares.
Zero-share or zero-token planned seizure legs are omitted.

Transfer fees apply BPS half-up to bonus RAY, then floor to token units. A
positive subunit fee becomes one unit. The fee is then capped at the whole
token units the pool pays above the principal:

```rust
let realised_excess = if paid_ray > base_ray {
    floor(paid_ray - base_ray)
} else { 0 };
let transfer_fee = min(bumped_fee, realised_excess);
```

`paid_ray` is the pool's gross payout and `base_ray` the uncapped principal,
both in RAY; `floor` rescales to token units. The planned transfer fee
therefore never takes the liquidator's leg below its principal; the payout
floor still can. Credit fees use the ceiling of bonus shares:

```rust
let credit_fee_shares = ceil(bonus_shares * fee_bps / BPS);
let credited_shares = seized_shares - credit_fee_shares;
```

Under-delivery floor-scales seizure amounts, transfer fees, seized shares and
bonus shares by measured/planned repayment USD. Credit fees are recomputed
from the scaled bonus shares.

Bad-debt cleanup has separate eligibility: ceil risk debt must exceed half-up
unweighted collateral, and permissionless cleanup requires collateral at or
below $5. Forced owner cleanup omits the collateral cap. See
[cleanup invariants](invariants.md#inv-liq-04) for authorization and account
deletion.

## Bad debt

Debt socialization lowers only the affected market's supply index. The debt
being removed is valued with a ceiled RAY multiplication. The write-down uses
half-up total supplied value, two floors, and a non-zero floor clamp:

```rust
let remaining_ray = total_supply_ray - min(bad_debt_ray, total_supply_ray);
let reduction_ray = floor(remaining_ray * RAY / total_supply_ray);
let new_supply_index = max(10_i128.pow(24),
    floor(old_supply_index * reduction_ray / RAY));
```

Zero supplied value makes the write-down a no-op. The two floors can impose
extra truncation on supply claims, including revenue, before the index clamp.
The non-zero floor can leave residual claims without backing. Supply then
fails the backing gate until recapitalization fills the shortfall. Eligibility
and account deletion follow the [cleanup rules](invariants.md#inv-liq-04).

<a id="numeric-limits"></a>

## Caps, fees, and numeric limits

A cap is in native token units. Entry compares stored scaled usage plus the
new scaled amount with the cap floor-converted at the current index. Zero cap
allows no positive exposure. Exits subtract usage without checking caps;
missing usage rows and zero exit deltas are no-ops. Cap→scaled conversion
saturates at `i128::MAX` (`calculate_scaled_cap`), so the entry check fails
open instead of trapping. A saturated scaled cap does not enforce the
configured asset-unit limit. An admitted cap saturates only at an index below
one RAY. Only a bad-debt write-down moves the supply index below one RAY; at
its floor (`RAY / 1000`), a supply cap above 1/1000 of the admitted maximum
saturates. The borrow index never falls below one RAY, so an admitted borrow
cap cannot saturate. Position conversion still rejects overflow.

Flash-loan and charged strategy fees are half-up BPS of principal, with a
minimum of one base unit for a positive rate. Flash position has no origination
fee; see [its settlement invariant](invariants.md#inv-strat-04).

| Bound | Consequence |
|---|---|
| Asset decimals 0..=18 | Exact token-to-RAY upscaling. Below 3: collateral only, no flash loans, no liquidation fee, its account's only supply position, at least 2 whole units while in debt |
| Both indexes initially RAY; ceiling 10^36 | 10^9 times initial index; protocol constants |
| Supply-index floor 10^24 | At most 1,000 times the shares minted at index one for the same deposit |
| Borrow APR maximum 2 RAY | 200% annual rate; not a bound on balance growth alone |
| Token-to-RAY input maximum `i128::MAX / 10^(27-d)` | About 170.14 billion whole tokens, before other limits |
| Deposit conversion at the supply-index floor | About 170.14 million whole tokens before scaled-share overflow |

The token-to-RAY maximum is also the admitted cap maximum. Accrued position
values and market totals must independently fit the RAY domain; valid caps and
bounded indexes do not guarantee that future accrual fits. Value overflow can
occur before the index ceiling and block repayment/withdrawal because those
operations accrue first. At the borrow-index ceiling, further accrual produces
no borrower interest. No dedicated ceiling alarm is emitted.

These are arithmetic limits, not recommended market sizes or deployment proofs.

### Liquidation fixture

These $5 repayment fixtures use ample collateral, selected USD prices and the
decimals, bonus and fee of one mainnet listing each. They illustrate native
arithmetic, excluding network fees and slippage. The prices are not live
quotes; four rows sit at their listing's `max_sanity_price_wad`. The results
do not guarantee profitability. The fixture tests also run each row at its
listing's `max_sanity_price_wad`. The fixture models at most two token-unit
rounding costs per collateral leg; that is not a universal execution bound.

| Collateral | Fixture USD price | Seized token units | Fee units | Profit USD (rounded) |
|---|---:|---:|---:|---:|
| SolvBTC | 120,000 | 4,541 | 45 | 0.3952 |
| xSolvBTCSolvBTC_LP | 12,000 | 4,583 | 41 | 0.4504 |
| SPIKOUKTBL | 1.48035816 | 358,021 | 2,431 | 0.264006 |
| XAUM | 6,000 | 900,000 | 6,666 | 0.360004 |
| XLM | 1 | 54,500,000 | 540,000 | 0.3960 |
| PYUSD | 1.05 | 49,047,619 | 142,857 | 0.1350 |
| USST | 1.0897 | 4.818e18 | 2.294e16 | 0.2250 |

## Sources

- [Fixed-point arithmetic](../../common/src/math/fp_core.rs) and [share conversion](../../common/src/rates/scaling.rs).
- [Rate curve](../../common/src/rates/curve.rs), [compounding](../../common/src/rates/compound.rs), [index and reward calculations](../../common/src/rates/index.rs), and [accrual projection](../../common/src/rates/simulate.rs).
- [Position valuation](../../common/src/rates/value.rs); [listing admission and shared checks](../../common/src/validation.rs); [post-pool risk gates](../../contracts/controller/src/risk/validation.rs).
- [Liquidation planning and fees](../../contracts/controller/src/positions/liquidation/math.rs), [liquidation curve](../../contracts/controller/src/positions/liquidation/curve.rs), and [liquidation fixtures](../../contracts/controller/tests/positions/liquidation_math.rs).
