#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
COV_OUT="$REPO_ROOT/target/coverage/fuzz"

DEFAULT_TARGETS=("fp_math" "rates_and_index")
TARGETS=("$@")
if [ ${#TARGETS[@]} -eq 0 ]; then
    TARGETS=("${DEFAULT_TARGETS[@]}")
fi

FUZZ_COV_TIME="${FUZZ_COV_TIME:-0}"
FUZZ_MAX_LEN="${FUZZ_MAX_LEN:-82}"
FUZZ_LEN_CONTROL="${FUZZ_LEN_CONTROL:-0}"
SANITIZER="${SANITIZER:-}"
BUILD_STD="${BUILD_STD:-}"

EXTRA_FLAGS=()
if [ -n "$SANITIZER" ]; then
    EXTRA_FLAGS+=("--sanitizer=$SANITIZER")
fi
if [ -n "$BUILD_STD" ]; then
    EXTRA_FLAGS+=("-Zbuild-std")
fi

SYSROOT="$(rustc +nightly --print sysroot)"
HOST_TRIPLE="$(rustc +nightly -vV | sed -n 's|host: ||p')"
SYSROOT_LLVM_COV="$SYSROOT/lib/rustlib/$HOST_TRIPLE/bin/llvm-cov"

if [ -x "$SYSROOT_LLVM_COV" ]; then
    LLVM_COV="$SYSROOT_LLVM_COV"
elif command -v llvm-cov >/dev/null 2>&1; then
    LLVM_COV="$(command -v llvm-cov)"
    echo "note: using system llvm-cov ($LLVM_COV)"
    echo "      for best results: rustup component add llvm-tools-preview --toolchain nightly"
else
    echo "error: llvm-cov not found" >&2
    echo "       run: rustup component add llvm-tools-preview --toolchain nightly" >&2
    echo "       or:  brew install llvm  (macOS)" >&2
    exit 1
fi

DEMANGLER_ARGS=()
if command -v rustfilt >/dev/null 2>&1; then
    DEMANGLER_ARGS=(-Xdemangler=rustfilt)
fi

IGNORE_REGEX='(\.rustup/|/\.cargo/|/rustc/|/tests/fuzz/|tests/test-harness/|/types/|events(\.rs|/)|contracts/controller/src/(governance|views)\.rs)'

focus_regex() {
    case "$1" in
        fp_math) echo '(^|/)math/fp_core\.rs|TOTAL' ;;
        fp_ops) echo '(^|/)math/fp(_core)?\.rs|TOTAL' ;;
        rates_and_index) echo '(^|/)rates/|(^|/)math/fp(_core)?\.rs|TOTAL' ;;
        flow_e2e) echo 'contracts/controller/src/(positions|strategies|storage|risk|account|markets|payments|context|config)|common/src/oracle|TOTAL' ;;
        flow_strategy) echo 'contracts/controller/src/(strategies|positions|risk|payments|context)|TOTAL' ;;
        pool_native) echo 'contracts/pool/src|common/src/(rates|math|validation)|TOTAL' ;;
        *) echo 'TOTAL' ;;
    esac
}

mkdir -p "$COV_OUT"

if [ ${#EXTRA_FLAGS[@]} -eq 0 ]; then
    FLAGS_DISPLAY="<none>"
else
    FLAGS_DISPLAY="${EXTRA_FLAGS[*]}"
fi

echo
echo "=============================================="
echo "  Fuzz coverage"
echo "  targets:   ${TARGETS[*]}"
echo "  pre-fuzz:  ${FUZZ_COV_TIME}s"
echo "  flags:     ${FLAGS_DISPLAY}"
echo "  output:    $COV_OUT"
echo "=============================================="

cd "$SCRIPT_DIR"

for target in "${TARGETS[@]}"; do
    echo
    echo "--- $target ---"
    mkdir -p "corpus/$target"

    if [ "$FUZZ_COV_TIME" -gt 0 ]; then
        echo "  [1/3] short fuzz run (${FUZZ_COV_TIME}s)"
        cargo +nightly fuzz run --fuzz-dir . "$target" "corpus/$target" "seeds/$target" \
            ${EXTRA_FLAGS[@]+"${EXTRA_FLAGS[@]}"} -- \
            -max_total_time="$FUZZ_COV_TIME" -max_len="$FUZZ_MAX_LEN" \
            -len_control="$FUZZ_LEN_CONTROL" 2>&1 | tail -20
    fi

    echo "  [2/3] coverage build + corpus replay"

    RUSTFLAGS="-Cunsafe-allow-abi-mismatch=sanitizer${RUSTFLAGS:+ }${RUSTFLAGS:-}" \
        cargo +nightly fuzz coverage --fuzz-dir . "$target" "corpus/$target" "seeds/$target" \
            ${EXTRA_FLAGS[@]+"${EXTRA_FLAGS[@]}"}

    profdata="coverage/$target/coverage.profdata"
    binary="target/$HOST_TRIPLE/coverage/$HOST_TRIPLE/release/$target"

    if [ ! -f "$profdata" ]; then
        echo "  error: $profdata not produced (corpus empty?)" >&2
        continue
    fi
    if [ ! -x "$binary" ]; then
        echo "  error: instrumented binary not found at $binary" >&2
        continue
    fi

    html_dir="$COV_OUT/$target"
    rm -rf "$html_dir"
    mkdir -p "$html_dir"

    echo "  [3/3] html + summary"
    "$LLVM_COV" show "$binary" \
        ${DEMANGLER_ARGS[@]+"${DEMANGLER_ARGS[@]}"} \
        -instr-profile="$profdata" \
        -ignore-filename-regex="$IGNORE_REGEX" \
        -show-line-counts-or-regions \
        -show-instantiations \
        -format=html \
        -output-dir="$html_dir" >/dev/null

    "$LLVM_COV" report "$binary" \
        ${DEMANGLER_ARGS[@]+"${DEMANGLER_ARGS[@]}"} \
        -instr-profile="$profdata" \
        -ignore-filename-regex="$IGNORE_REGEX" \
        | tee "$html_dir/summary.txt" >/dev/null

    echo "  focused summary"
    grep -E "$(focus_regex "$target")" "$html_dir/summary.txt" || tail -30 "$html_dir/summary.txt"
done

echo
echo "=============================================="
echo "  Open: $COV_OUT/<target>/index.html"
echo "=============================================="
