## Summary

One paragraph: what changed and why. Cite concrete modules or entrypoints
(e.g. "controller withdraw restamp", "pool interest index floor", "oracle
call-site policy").

## Risk Surface

**High-priority areas touched (check all that apply and explain):**
- [ ] Storage layout, keys, TTL/renewal, per-side maps (`SupplyPositions`/`BorrowPositions`), `HubAssetKey`, or `PoolKey` changes
- [ ] Oracle config, price resolution, tolerance, providers (Reflector/RedStone/Xoxno/Aquarius), sanity/staleness, or call-site policy
- [ ] Risk params, LTV/liquidation curves, caps, position limits, min-borrow-collateral, or spoke overrides
- [ ] Authorization, delegates, position managers, pause/freeze matrix, or governance/timelock/roles/upgrade
- [ ] Flash-loan or strategy reentrancy, callback surfaces, or balance-delta validation
- [ ] Pool accounting, cash, interest split, revenue, bad-debt socialization, or reserves
- [ ] Controller–pool–governance boundaries or `HubAssetKey` isolation
- [ ] Common math/rates/types, events (stable ABI), or interface/ABI changes
- [ ] WASM size, Soroban footprint (reads/writes/entries), compute, or resource usage (`make wasm-size-check`)
- [ ] Other (describe):

- Affected contracts/modules:
- Affected invariants (cite file:function or test):
- Specific impact (solvency, oracle, liquidation, flash-loan, storage, etc.):

See [CONTRIBUTING.md](../CONTRIBUTING.md), contract rustdoc, and
[`skills/xoxno-lending/SKILL.md`](../skills/xoxno-lending/SKILL.md).

## Verification

**Baseline (must pass):**
- [ ] `make fmt-check`
- [ ] `make clippy`
- [ ] `make build`, then `make test` (whole workspace)
- [ ] `make wasm-size-check`
- [ ] `make docs-check` / `make access-control-check`

**Protocol-sensitive changes — list exactly what was run and attach key results:**
- Certora profile(s) / rules (see `certora/profiles.json` and `certora/*/spec/README.*`):
- Fuzz target(s) + duration (`make fuzz` / `make fuzz-contract`):
- Proptest / mutants / other (Scout, miri, specific harness tests):

Re-run against the exact tree in this PR. See CONTRIBUTING.md.

## Operations & Downstream

- Deployment, WASM upgrade, or migration required:
- Configuration, role, cap, oracle, spoke, or governance follow-up (including timelock proposals):
- Keeper, indexer, configs, or off-chain impact (TTL, events, feeds):
- Breaking changes for users, liquidators, strategies, or integrators:

## Security

- [ ] This pull request does not disclose a vulnerability.
- [ ] Security-sensitive details, if any, were reported privately through `security@xoxno.com`.
