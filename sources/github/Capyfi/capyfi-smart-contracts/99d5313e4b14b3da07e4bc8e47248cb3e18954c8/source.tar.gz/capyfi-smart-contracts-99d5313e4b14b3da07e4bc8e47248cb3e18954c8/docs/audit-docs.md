# Capyfi - Audit Documentation

## 1. Overview

This repository is a fork of the **Compound V2 Protocol**. Our goal is to minimize changes to the original code while adding specific features for our deployment. This document provides:

1. A description of the **base version** (the Compound V2 commit we forked).  
2. An overview of **new features** added to the protocol.  
3. Instructions on **testing** and **deployment** scripts.  
4. Detailed analysis of the **whitelist functionality** added in this version.

Where possible, we have left original code and warnings intact to reduce diff size and make it clear exactly what changed.

---

## 2. Audit Scope

For this audit, we would like to prioritize the following areas:

1. **Ethereum Deployment Configuration**
   - Verification that the current Ethereum deployment is correctly configured
   - Confirmation that all necessary contracts are deployed and properly initialized
   - Validation that nothing is missing from the deployment that could impact security or functionality
   - Review of parameter settings across all contracts to ensure they align with intended behavior
   - Review ownership is set correctly to multi-sig address

2. **Whitelist Functionality Security**
   - Comprehensive review of the whitelist implementation to identify any potential vulnerabilities
   - Assessment of role-based access control implementation
   - Verification that whitelist bypass is not possible through any contract interactions
   - Evaluation of the integration between CToken operations and whitelist verification

These areas have been identified as critical to the security and proper functioning of the protocol in its production environment.

---

## 3. Repository & Branch Structure

We forked Compound V2 from the official Compound Finance repository (https://github.com/compound-finance/compound-protocol) at branch `master`, commit `a3214f67b73310d547e00fc578e8355911c9d376`.

We use a simple branch and tag structure:

1. **`v1.0` Tag**  
   - Contains the unmodified Compound V2 code up to the **last commit** we forked from the official repository.  
   - This state is tagged so we can reference the exact upstream version.

2. **`main` Branch**  
   - Contains all our modifications integrated into a single branch.
   - Main changes include:  
     - **Whitelist functionality** for restricted minting of tokens.
     - Setting `compAddress` to `address(0)` (unused).  
     - Adjusting `blocksPerYear` for 12-second block times to match ethereum block times.  
     - New tests, deployment scripts, and configuration for all modifications.
---

## 4. Changes Summary

Below is a high-level summary of the modifications from the original Compound code (`v1.0`) to our current implementation (`main`):

1. **Whitelist Functionality**
   - Added new whitelist contracts: `Whitelist.sol` and `WhitelistAccess.sol`.
   - Integrated whitelist checks in CToken contracts via the `_checkWhitelist` modifier.
   - Updated CToken interface to include whitelist-related functionality.
   - Added scripts and tests for whitelist functionality.

2. **Interest Rate Models**  
   - Adjusted `blocksPerYear` to `2628000` for an approximate 12-second block time to match ethereum block times.  

3. **Unused `compAddress`**  
   - Set `compAddress` to `address(0)` since COMP distribution is not used in our deployment.  

---

## 5. How to Review the Changes

The most significant changes in this implementation are the inclusion of the whitelist functionality. When reviewing the codebase, special attention should be given to:

1. The implementation of whitelist checks in CToken contracts
2. The role-based access control system in the Whitelist contract
3. The integration between CToken operations and whitelist verification

---

## 6. Warnings and Formatting

We intentionally **left most original warnings intact** to preserve upstream context and keep diffs minimal. Likewise, **the code is not auto-formatted** to match Compound's original style, helping to distinguish changes from stylistic modifications.

- **Why?** This approach makes it easier to identify intentional changes versus reformatting or linting differences.
- **Result:** You might see compiler warnings (e.g., about unused variables) that existed in the original code.

---

## 7. Testing & Validation

We use **Foundry** (Forge, Anvil, etc.) to compile and test the project. The main tasks are:

1. **Install Dependencies**  
   ```bash
   make install
   # or manually: forge install
   ```

2. **Build**  
   ```bash
   make build
   # or manually: forge build
   ```

3. **Test**  
   ```bash
   make test
   # or manually: forge test
   ```

New tests have been added for the whitelist logic. Extensive testing for the whitelist functionality can be found in:

- `test/unit/WhitelistTest.t.sol`: Tests for the `Whitelist` contract.
- `test/unit/CTokenWhitelistTest.sol`: Tests for CToken integration with whitelist functionality.
- `test/unit/CEtherTest.s.sol`: Tests for CEther with whitelist functionality.

---

## 8. Deployment Scripts

Foundry scripts in the `script/` directory handle contract deployment:

- **`DeployCapyfiProtocolAll.s.sol`**  
  Deploys or configures all core protocol contracts.

- **`DeployInterestRateModels.s.sol`**  
  Deploys interest rate models with the updated `blocksPerYear` parameter.

- **`DeployWhitelist.s.sol`**  
  Deploys the `Whitelist` contract.

- **`UpgradeWhitelist.s.sol`**  
  Upgrades an existing Whitelist proxy implementation.

You can check the `Makefile` for tasks like `make deploy-capyfi-protocol` or run scripts via Forge:

```bash
forge script script/DeployCapyfiProtocolAll.s.sol:DeployCapyfiProtocolAll 
```

Environment-specific data (e.g., RPC URLs, private keys) is stored in a `.env` file. Adjust these settings for test, staging, or production networks as needed.

---

## 9. Whitelist Implementation Details

The whitelist functionality adds permissioned access control to the minting of CTokens, restricting who can supply assets to the protocol. Below are the key components and modifications:

### 9.1 Whitelist Functionality Audit Scope

#### Overview
The whitelist feature restricts who can mint cTokens in the Capyfi protocol, allowing controlled access to the lending platform while maintaining unrestricted token transfers and redemptions.

#### Key Files and Lines

##### New Contracts
1. **WhitelistAccess.sol** - Interface for whitelist checks
   - Lines 7-23: Core interface definition with `isWhitelisted()` and `isActive()` methods

2. **Whitelist.sol** - Main whitelist implementation with UUPS upgradeability
   - Lines 16-18: Core role constants
   - Lines 81-113: Methods for adding/removing addresses from whitelist
   - Lines 57-77: Activation/deactivation controls

##### Modified Contracts
1. **CTokenInterfaces.sol**
   - Line 116: Added `WhitelistAccess public whitelist` storage variable
   - Line 210: Added `NewWhitelist` event
   - Line 241: Added `_setWhitelist()` interface method

2. **CToken.sol**
   - Lines 1027-1049: Added `_setWhitelist()` implementation
   - Lines 1181-1192: Added `_checkWhitelist` modifier
   - Line 387: Applied whitelist check to `mintInternal()` with `_checkWhitelist(msg.sender)`

3. **CErc20Delegator.sol**
   - Lines 414-424: Added delegation for whitelist methods

4. **CEther.sol**
   - Lines 44 & 119: Redundant whitelist checks at user-facing entry points

5. **ErrorReporter.sol**
   - Line 128: Added `SetWhitelistAdminOwnerCheck()` error

#### Security Boundaries

1. **Whitelist Enforcement Points:**
   - All minting operations are gated by whitelist checks in `mintInternal()`
   - No restrictions on transfers, redemptions, or other operations

2. **Admin Controls:**
   - Whitelist can be activated/deactivated by admin
   - Addresses can be added/removed from whitelist by admin
   - Whitelist contract can be upgraded via UUPS pattern

3. **Bypass Prevention:**
   - Double validation: whitelist must exist (`address(whitelist) != address(0)`) and be active (`whitelist.isActive()`)
   - All entry points to minting funnel through `mintInternal()` with whitelist checks


### 9.2 Core Whitelist Components

1. **`WhitelistAccess.sol`**
   - Abstract contract defining the whitelist interface
   - Provides two key functions:
     - `isWhitelisted(address)`: Checks if an address is whitelisted
     - `isActive()`: Determines if whitelist checks are enforced

2. **`Whitelist.sol`**
   - Implements the `WhitelistAccess` interface
   - Uses OpenZeppelin's AccessControlEnumerableUpgradeable for role management
   - Follows the UUPS upgradeability pattern for contract upgrades
   - Defines two main roles:
     - `DEFAULT_ADMIN_ROLE`: Can manage the whitelist and upgrade the contract
     - `WHITELISTED_ROLE`: Can interact with whitelisted functions
   - Features an activation/deactivation toggle to enable/disable all whitelist checks

### 9.3 CToken Integration

1. **`CToken.sol` Modifications**
   - Added a `whitelist` storage variable of type `WhitelistAccess`
   - Implemented `_setWhitelist(WhitelistAccess)` function accessible only to the admin
   - Added the `_checkWhitelist(address)` modifier to `mintInternal()` which serves as the central entry point for all minting operations

2. **Simplified Implementation**
   - Whitelist checks are performed once at the `mintInternal()` level
   - This avoids redundant checks and reduces gas costs
   - Ensures consistent whitelist enforcement across all entry points

### 9.4 Security Considerations

1. **Admin Control**
   - Whitelist admin has significant power over protocol access
   - Admin can add/remove users from the whitelist and activate/deactivate the entire system
   - Admin can upgrade the whitelist contract implementation

2. **Upgradeability**
   - Uses the UUPS proxy pattern for upgradeability
   - Implements proper storage gaps and initializer functions
   - Restricts upgrade capability to addresses with the `DEFAULT_ADMIN_ROLE`

3. **Whitelist Bypass Prevention**
   - The `_checkWhitelist` modifier is carefully implemented to check both:
     - If a whitelist contract exists (`address(whitelist) != address(0)`)
     - If the whitelist is active (`whitelist.isActive()`)
   - This ensures proper enforcement when needed while allowing disabling via either mechanism

4. **Non-Breaking Integration**
   - Whitelist checks only apply to minting operations
   - Existing balances and redemptions are unaffected by whitelist changes
   - Transfers between addresses work regardless of whitelist status

5. **Flexible Activation**
   - Whitelist can be disabled by setting it to `address(0)` or by calling `deactivate()`
   - This provides two separate mechanisms for emergency disabling

---

## 10. Deployment Verification

When auditing the Ethereum deployment, the following aspects should be verified:

1. **Contract Verification**
   - All deployed contracts should be verified on Etherscan
   - Implementation addresses for proxies should also be verified
   - Contract parameters should match those in deployment scripts (scripts/capyfi/config/ProdConfig.sol)

2. **Whitelist Configuration**
   - Verify the whitelist is properly initialized
   - Confirm the correct admin addresses have been assigned roles
   - Check if the whitelist is active (default state is active)

3. **Token Configuration**
   - Verify all tokens use the "ca" prefix consistently
   - Check collateral factors, interest rate models, and price oracle settings
   - Ensure price feeds are correctly configured in the oracle

4. **Access Control**
   - Verify admin addresses are secure and controlled by the proper entities
   - Check that the whitelist admin is properly configured

5. **Upgrade Capability**
   - Verify that upgrade functions are properly secured
   - Ensure that implementation contracts are initialized to prevent attacks

---

## 11. Ethereum Deployment Addresses

Below is the addressing scheme for the Ethereum deployment. Note that these addresses will be updated once the actual deployment is completed.

#### Core 

| Component       | Address                                         |
|-----------------|-------------------------------------------------|
| **Unitroller**  | `0x0b9af1fd73885aD52680A1aeAa7A3f17AC702afA`                                         |
| **Comptroller** | `0x00dc4965916e03A734190fA382633657c71f867E`                                         |
| **Oracle**      | `0xfbA2712d3bbcf32c6E0178a21955b61FE1FF424A`                                         |
| **Multisig**    | `0x6C15e4Bc44CC5674b1d7956D0e9596d2E509eD24`                                         |
| **Whitelist**   | `0x4B3535047C2B193Bc0c95ED2EF435A6BA6Dc2609`                                         |

#### Interest Rate Models

| Model                       | Address                                   |
|-----------------------------|-------------------------------------------|
| **iRM_UXD_Updateable**      | `0xf5FA0EA9C6b7bE2da713F8BDec9D35AAE289E5c0`                                   |
| **iRM_WETH_Updateable**     | `0x03c1cF154d621E0Fd7e2b88be3aE60CCf07Aca31`                                   |
| **iRM_LAC_Updateable**      | `0x254FCeeece1893c0A55bC7cF8A8a1C21cB05C29C`                                   |
| **iRM_WBTC_Updateable**     | `0xcA142dA9286D37211e7e04FEc59D1de5de86EF33`                                   |
| **iRM_USDT_Updateable**     | `0x5BeA6bE1DCcD0b5066842d42852e6302d7f668e8`                                   |
| **iRM_USDC_Updateable**     | `0xa6b02274f7B017C96d570bc2693119c90533E9c3`                                   |

#### cTokens

| cToken    | Address                                   |
|-----------|-------------------------------------------|
| **caUXD** | `0x98Ac8AC56d833bD69d34F909Ac15226772FAc9aa`                                   |
| **caETH** | `0x37DE57183491Fa9745d8Fa5DCd950f0c3a4645c9`                                   |
| **caLAC** | `0x0568F6cb5A0E84FACa107D02f81ddEB1803f3B50`                                   |
| **caWBTC**| `0xDa5928d59ECE82808Af2cbBE4f2872FeA8E12CD6`                                   |
| **caUSDT**| `0x0f864A3e50D1070adDE5100fd848446C0567362B`                                   |
| **caUSDC**| `0xc3aD34De18B59A24BD0877e454Fb924181F09C8f`                                   |

#### Underlying Tokens

| Token      | Address                                   |
|------------|-------------------------------------------|
| **uxd**    | `0x0f6011F7DBC40c17EcE894b1147f4ecfA712b600`                                   |
| **lac**    | `0x0Df3a853e4B604fC2ac0881E9Dc92db27fF7f51b`                                   |
| **wbtc**   | `0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599`                                   |
| **usdt**   | `0xdAC17F958D2ee523a2206206994597C13D831ec7`                                   |
| **usdc**   | `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`                                   |

---

## 12. Conclusion

**Key Points**:

1. We forked the final commit of **Compound V2** into **`v1.0`**.  
2. The **`main` branch** contains all our modifications including:
   - Core protocol adjustments for our environment
   - Whitelist functionality to control who can mint tokens

**Audit Priorities**:
1. **Ethereum Deployment Configuration** - Careful review of the deployment setup, parameters, and initialization to ensure nothing is misconfigured or missing.
2. **Whitelist Security** - Thorough examination of the whitelist functionality to verify its security, resistance to bypass attempts, and proper integration with the rest of the protocol.
