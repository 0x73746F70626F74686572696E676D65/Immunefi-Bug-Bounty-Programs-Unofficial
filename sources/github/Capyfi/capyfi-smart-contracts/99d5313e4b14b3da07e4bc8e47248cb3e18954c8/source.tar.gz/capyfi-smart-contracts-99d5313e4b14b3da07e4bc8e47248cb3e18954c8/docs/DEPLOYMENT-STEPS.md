# Capyfi Protocol Deployment Guide

This document outlines the step-by-step process for deploying the Capyfi protocol to different networks, including Ethereum mainnet, Sepolia testnet, and other supported networks.

## Prerequisites

Before deploying, ensure you have:

1. **Foundry** installed (`forge`, `cast`, `anvil`)  https://book.getfoundry.sh/getting-started/installation
2. **A wallet keystore file** with sufficient funds for the target network
3. **Environment variables** properly configured in your `.env` file
4. **Etherscan API key** for contract verification (for Ethereum mainnet and Sepolia)

## Environment Setup

Create a `.env` file based on the `.env.example` template and fill in the required values:

```
KEYSTORE_PATH=keys/key.json  # Path to your keystore file
KEYSTORE_PASSWORD=your_secure_password
ETHERSCAN_API_KEY=your_etherscan_api_key

# Ethereum Mainnet
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/your_infura_project_id
ETHEREUM_EXPLORER_URL=https://etherscan.io

```

build the project

```
forge build
```

To import your wallet into the keystore:

```
cast wallet import --interactive key.json --keystore-dir keys
```

Set the gasPrice

```
Set the gasPrice in the makefile in the network-args section for the ethereum network: --with-gas-price 2000000000 (2 gwei)
```

## Deployment Steps

#### Step 1: Deploy Core Protocol

This deploys the Unitroller, Comptroller, and PriceOracle contracts:

```bash
make deploy-core-protocol ARGS="--network ethereum"
```

Update the HelperConfig.s.sol (getEthereumConfig()) file with the new addresses.

output:

```
Unitroller deployed to: 0x123...
Comptroller deployed to: 0x456...
PriceOracle deployed to: 0x789...
```

#### Step 2: Deploy Interest Rate Models (Review the config/ProdConfig.sol file if needed)

In the ProdConfig.sol file, you will see the interest rate models parameters for each asset. Also set the MULTISIG_ADDRESS, that will be the owner of the interest rate models.

Individual interest rate model can be deployed with the following command:

Available tokens are: UXD, WETH, LAC, WBTC, USDT, USDC

```bash
make deploy-individual-irm ARGS="--network ethereum" TOKEN_SYMBOL=UXD
```

Or deploy all interest rate models at once, parameter for each asset are define in the ProdConfig.sol file:

```bash
make deploy-irm ARGS="--network ethereum"
```

Update the HelperConfig.s.sol (getEthereumConfig()) file with the new addresses.

output:

```
IRM_LAC_Updateable deployed to: 0x123...
IRM_USDC_Updateable deployed to: 0x456...
IRM_UXD_Updateable deployed to: 0x789...
IRM_WETH_Updateable deployed to: 0x101...
IRM_WBTC_Updateable deployed to: 0x102...
IRM_USDT_Updateable deployed to: 0x103...
```

#### Step 3: Deploy Individual CTokens (Review the config/ProdConfig.sol file and HelperConfig.s.sol file)

Deploy the different cTokens for each asset:
```bash
# Deploy lac token
make deploy-individual-ctoken TOKEN_SYMBOL=LAC ARGS="--network ethereum"

# Deploy cUSDC token
make deploy-individual-ctoken TOKEN_SYMBOL=USDC ARGS="--network ethereum"

# Deploy cUXD token
make deploy-individual-ctoken TOKEN_SYMBOL=UXD ARGS="--network ethereum"

# Deploy cWBTC token
make deploy-individual-ctoken TOKEN_SYMBOL=WBTC ARGS="--network ethereum"

# Deploy cUSDT token
make deploy-individual-ctoken TOKEN_SYMBOL=USDT ARGS="--network ethereum"

# Deploy cETH token
make deploy-ceth ARGS="--network ethereum"
```

Update the HelperConfig.s.sol (getEthereumConfig()) file with the new addresses.

output:

```
cUSDC deployed to: 0x123...
cUXD deployed to: 0x456...
cETH deployed to: 0x789...
cWBTC deployed to: 0x101...
cUSDT deployed to: 0x102...
cLAC deployed to: 0x103...
```

#### Step 4: Set token configuration for each cToken

For each cToken, you can use these individual configuration commands (recommended approach):

```bash
# Support market in the Comptroller
# This adds the cToken to the protocol
make support-market TOKEN_SYMBOL=WETH ARGS="--network ethereum"

# Set collateral factor
# This uses the collateral factor from the Config file
make set-collateral-factor TOKEN_SYMBOL=WETH ARGS="--network ethereum"

# Add Chainlink price oracle configuration
# This configures the price feed for the cToken using values from the Config file
make add-chainlink-oracle TOKEN_SYMBOL=WETH ARGS="--network ethereum"

# Set reserve factor
# This uses the reserve factor from the Config file
make set-reserve-factor TOKEN_SYMBOL=WETH ARGS="--network ethereum"
```

Alternatively, you can use the single configuration command:

```bash
make configure-ctoken TOKEN_SYMBOL=WETH ARGS="--network ethereum"
```

Each command automatically reads token configurations from:
- `HelperConfig.s.sol` for network-specific settings like Comptroller address
- `ProdConfig.sol` or `CustomConfig.sol` (based on network) for token-specific parameters

Note: If you need to use custom values for collateral factor or reserve factor, you should update them in the Config files before running these commands.

#### Step 5: query the deployment state

CompoundLens should be defined in the .env file as COMPOUND_LENS_ADDRESS=0xdCbDb7306c6Ff46f77B349188dC18cEd9DF30299

```bash
make query-deployment ARGS="--network ethereum"
```

Alternatively, you can deploy the CompoundLens contract manually and then use the command to query the deployment state:

```bash
make deploy-compound-lens ARGS="--network ethereum"
```