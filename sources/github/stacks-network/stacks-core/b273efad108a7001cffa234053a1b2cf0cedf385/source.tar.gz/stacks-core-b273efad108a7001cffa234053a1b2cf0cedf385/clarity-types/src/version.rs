// Copyright (C) 2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use std::fmt;
use std::str::FromStr;

use stacks_common::types::StacksEpochId;
use variant_count::VariantCount;

#[derive(Serialize, Deserialize, Clone, Copy, Debug, PartialEq, PartialOrd, VariantCount)]
pub enum ClarityVersion {
    Clarity1,
    Clarity2,
    Clarity3,
    Clarity4,
    Clarity5,
    Clarity6,
    Clarity7,
}

// Compile-time guard: if a new variant is added to the enum above without
// being appended to `ALL` (or vice-versa), this assertion will fail at
// `cargo build`, not just at test time. `VARIANT_COUNT` is provided by the
// `variant_count` derive.
//
// TODO: once `core::mem::variant_count` is stabilized (tracking issue:
// rust-lang/rust#73662), replace the `variant_count` crate dependency and
// the `#[derive(VariantCount)]` above with:
//   const _: () = assert!(ClarityVersion::ALL.len() == core::mem::variant_count::<ClarityVersion>());
const _: () = assert!(ClarityVersion::ALL.len() == ClarityVersion::VARIANT_COUNT);

impl fmt::Display for ClarityVersion {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ClarityVersion::Clarity1 => write!(f, "Clarity 1"),
            ClarityVersion::Clarity2 => write!(f, "Clarity 2"),
            ClarityVersion::Clarity3 => write!(f, "Clarity 3"),
            ClarityVersion::Clarity4 => write!(f, "Clarity 4"),
            ClarityVersion::Clarity5 => write!(f, "Clarity 5"),
            ClarityVersion::Clarity6 => write!(f, "Clarity 6"),
            ClarityVersion::Clarity7 => write!(f, "Clarity 7"),
        }
    }
}

impl ClarityVersion {
    /// The default version of the latest epoch, so it tracks
    /// `StacksEpochId::latest()` in both test and release builds.
    pub const fn latest() -> ClarityVersion {
        Self::default_for_epoch(StacksEpochId::latest())
    }

    pub const ALL: &'static [ClarityVersion] = &[
        ClarityVersion::Clarity1,
        ClarityVersion::Clarity2,
        ClarityVersion::Clarity3,
        ClarityVersion::Clarity4,
        ClarityVersion::Clarity5,
        ClarityVersion::Clarity6,
        ClarityVersion::Clarity7,
    ];

    /// Returns all [`ClarityVersion`] starting from the given `version` (inclusive)
    #[cfg(any(test, feature = "testing"))]
    pub fn since(version: ClarityVersion) -> &'static [ClarityVersion] {
        let idx = Self::ALL
            .iter()
            .position(|&v| v == version)
            .expect("version not found in ALL");

        &Self::ALL[idx..]
    }

    /// Returns all [`ClarityVersion`] up to the given `version` (inclusive)
    #[cfg(any(test, feature = "testing"))]
    pub fn up_to(version: ClarityVersion) -> &'static [ClarityVersion] {
        let idx = Self::ALL
            .iter()
            .position(|&v| v == version)
            .expect("version not found in ALL");

        &Self::ALL[..=idx]
    }

    pub const fn default_for_epoch(epoch_id: StacksEpochId) -> ClarityVersion {
        match epoch_id {
            // Unreachable for any Stacks block: Clarity does not exist yet.
            StacksEpochId::Epoch10 => {
                panic!("Epoch 1.0 predates Clarity; no default Clarity version")
            }
            StacksEpochId::Epoch20 => ClarityVersion::Clarity1,
            StacksEpochId::Epoch2_05 => ClarityVersion::Clarity1,
            StacksEpochId::Epoch21 => ClarityVersion::Clarity2,
            StacksEpochId::Epoch22 => ClarityVersion::Clarity2,
            StacksEpochId::Epoch23 => ClarityVersion::Clarity2,
            StacksEpochId::Epoch24 => ClarityVersion::Clarity2,
            StacksEpochId::Epoch25 => ClarityVersion::Clarity2,
            StacksEpochId::Epoch30 => ClarityVersion::Clarity3,
            StacksEpochId::Epoch31 => ClarityVersion::Clarity3,
            StacksEpochId::Epoch32 => ClarityVersion::Clarity3,
            StacksEpochId::Epoch33 => ClarityVersion::Clarity4,
            StacksEpochId::Epoch34 => ClarityVersion::Clarity5,
            StacksEpochId::Epoch40 => ClarityVersion::Clarity6,
            StacksEpochId::Epoch41 => ClarityVersion::Clarity7,
        }
    }

    pub fn supports_callables(&self) -> bool {
        self >= &ClarityVersion::Clarity2
    }

    pub fn uses_secp256r1_double_hashing(&self) -> bool {
        self <= &ClarityVersion::Clarity4
    }

    /// Beginning in Clarity 5, cost functions that call `logn` are ensured to
    /// always pass an argument greater than zero, to avoid hitting a runtime
    /// error during cost computation. After reviewing the usage, the only
    /// function that requires this protection is `from-consensus-buff?`, other
    /// cost functions that call `logn` are already protected from zeros.
    pub fn protects_logn_cost_fn(&self) -> bool {
        self >= &ClarityVersion::Clarity5
    }

    /// Beginning in Clarity 6, `concat` is variadic and accepts two or more
    /// arguments. Earlier versions require exactly two arguments.
    pub fn supports_variadic_concat(&self) -> bool {
        self >= &ClarityVersion::Clarity6
    }
}

impl FromStr for ClarityVersion {
    type Err = &'static str;

    fn from_str(version: &str) -> Result<ClarityVersion, &'static str> {
        let s = version.to_string().to_lowercase();
        if s == "clarity1" {
            Ok(ClarityVersion::Clarity1)
        } else if s == "clarity2" {
            Ok(ClarityVersion::Clarity2)
        } else if s == "clarity3" {
            Ok(ClarityVersion::Clarity3)
        } else if s == "clarity4" {
            Ok(ClarityVersion::Clarity4)
        } else if s == "clarity5" {
            Ok(ClarityVersion::Clarity5)
        } else if s == "clarity6" {
            Ok(ClarityVersion::Clarity6)
        } else if s == "clarity7" {
            Ok(ClarityVersion::Clarity7)
        } else {
            Err(
                "Invalid clarity version. Valid versions are: Clarity1, Clarity2, Clarity3, Clarity4, Clarity5, Clarity6, Clarity7.",
            )
        }
    }
}
