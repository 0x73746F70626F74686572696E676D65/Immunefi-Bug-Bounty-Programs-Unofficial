// Copyright (C) 2025-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
use std::io::Write;

use rstest::rstest;
use stacks_common::types::StacksEpochId;
use stacks_common::util::hash::hex_bytes;

use crate::errors::ClarityTypeError;
use crate::types::serialization::SerializationError;
use crate::types::{
    ASCIIData, CharType, MAX_VALUE_SIZE, PrincipalData, QualifiedContractIdentifier, SequenceData,
    StandardPrincipalData, TupleData, TupleTypeSignature, TypeSignature, Value,
};
use crate::{ClarityName, ContractName};

fn test_deser_ser(v: Value) {
    assert_eq!(
        &v,
        &Value::try_deserialize_hex(
            &v.serialize_to_hex().unwrap(),
            &TypeSignature::type_of(&v).unwrap(),
            false
        )
        .unwrap()
    );
    assert_eq!(
        &v,
        &Value::try_deserialize_hex_untyped(&v.serialize_to_hex().unwrap()).unwrap()
    );
    // test the serialized_size implementation
    assert_eq!(
        v.serialized_size().unwrap(),
        v.serialize_to_hex().unwrap().len() as u32 / 2,
        "serialized_size() should return the byte length of the serialization (half the length of the hex encoding)",
    );
}

fn test_bad_expectation(v: Value, e: TypeSignature) {
    assert!(matches!(
        Value::try_deserialize_hex(&v.serialize_to_hex().unwrap(), &e, false).unwrap_err(),
        SerializationError::DeserializeExpected(_)
    ));
}

#[test]
fn test_lists() {
    let list_list_int = Value::list_from(vec![
        Value::list_from(vec![Value::Int(1), Value::Int(2), Value::Int(3)]).unwrap(),
    ])
    .unwrap();
    test_deser_ser(list_list_int.clone());
    test_deser_ser(Value::list_from(vec![]).unwrap());
    test_bad_expectation(list_list_int.clone(), TypeSignature::BoolType);

    // make a list too large for the type itself!
    //   this describes a list of size 1+MAX_VALUE_SIZE of Value::Bool(true)'s
    let mut too_big = vec![3u8; 6 + MAX_VALUE_SIZE as usize];
    // list prefix
    too_big[0] = 11;
    // list length
    Write::write_all(
        &mut too_big.get_mut(1..5).unwrap(),
        &(1 + MAX_VALUE_SIZE).to_be_bytes(),
    )
    .unwrap();

    assert_eq!(
        Value::deserialize_read(&mut too_big.as_slice(), None, false).unwrap_err(),
        "Illegal list type".into()
    );

    // make a list that says it is longer than it is!
    //   this describes a list of size MAX_VALUE_SIZE of Value::Bool(true)'s, but is actually only 59 bools.
    let mut eof = vec![3u8; 64_usize];
    // list prefix
    eof[0] = 11;
    // list length
    Write::write_all(
        &mut eof.get_mut(1..5).unwrap(),
        &(MAX_VALUE_SIZE).to_be_bytes(),
    )
    .unwrap();

    /*
     * jude -- this should return an IOError
    assert_eq!(
        Value::deserialize_read(&mut eof.as_slice(), None).unwrap_err(),
        "Unexpected end of byte stream".into());
    */

    match Value::deserialize_read(&mut eof.as_slice(), None, false) {
        Ok(_) => panic!("Accidentally parsed truncated slice"),
        Err(eres) => match eres {
            SerializationError::IOError(ioe) => match ioe.err.kind() {
                std::io::ErrorKind::UnexpectedEof => {}
                _ => panic!("Invalid I/O error: {ioe:?}"),
            },
            _ => panic!("Invalid deserialize error: {eres:?}"),
        },
    }
}

#[test]
fn test_bools() {
    test_deser_ser(Value::Bool(false));
    test_deser_ser(Value::Bool(true));

    test_bad_expectation(Value::Bool(false), TypeSignature::IntType);
    test_bad_expectation(Value::Bool(true), TypeSignature::IntType);
}

#[test]
fn test_ints() {
    test_deser_ser(Value::Int(0));
    test_deser_ser(Value::Int(1));
    test_deser_ser(Value::Int(-1));
    test_deser_ser(Value::Int(i128::MAX));
    test_deser_ser(Value::Int(i128::MIN));

    test_bad_expectation(Value::Int(1), TypeSignature::UIntType);
}

#[test]
fn test_uints() {
    test_deser_ser(Value::UInt(0));
    test_deser_ser(Value::UInt(1));
    test_deser_ser(Value::UInt(u128::MAX));
    test_deser_ser(Value::UInt(u128::MIN));

    test_bad_expectation(Value::UInt(1), TypeSignature::IntType);
}

#[test]
fn test_opts() {
    test_deser_ser(Value::none());
    test_deser_ser(Value::some(Value::Int(15)).unwrap());

    test_bad_expectation(Value::none(), TypeSignature::IntType);
    test_bad_expectation(Value::some(Value::Int(15)).unwrap(), TypeSignature::IntType);
}

#[test]
fn test_resp() {
    test_deser_ser(Value::okay(Value::Int(15)).unwrap());
    test_deser_ser(Value::error(Value::Int(15)).unwrap());

    // Bad expected types.
    test_bad_expectation(Value::okay(Value::Int(15)).unwrap(), TypeSignature::IntType);
}

#[test]
fn test_buffs() {
    test_deser_ser(Value::buff_from(vec![0, 0, 0, 0]).unwrap());
    test_deser_ser(Value::buff_from(vec![0xde, 0xad, 0xbe, 0xef]).unwrap());
    test_deser_ser(Value::buff_from(vec![0, 0xde, 0xad, 0xbe, 0xef, 0]).unwrap());

    test_bad_expectation(
        Value::buff_from(vec![0, 0xde, 0xad, 0xbe, 0xef, 0]).unwrap(),
        TypeSignature::BoolType,
    );
}

#[test]
fn test_string_ascii() {
    test_deser_ser(Value::string_ascii_from_bytes(vec![61, 62, 63, 64]).unwrap());
}

#[test]
fn test_string_utf8() {
    test_deser_ser(Value::string_utf8_from_bytes(vec![61, 62, 63, 64]).unwrap());
    test_deser_ser(Value::string_utf8_from_bytes(vec![61, 62, 63, 240, 159, 164, 151]).unwrap());
}
#[test]
fn test_tuples() {
    let t_1 = Value::from(
        TupleData::from_data(vec![
            (ClarityName::from_literal("a"), Value::Int(1)),
            (ClarityName::from_literal("b"), Value::Int(1)),
        ])
        .unwrap(),
    );
    let t_0 = Value::from(
        TupleData::from_data(vec![
            (ClarityName::from_literal("b"), Value::Int(1)),
            (ClarityName::from_literal("a"), Value::Int(1)),
        ])
        .unwrap(),
    );
    let t_2 = Value::from(
        TupleData::from_data(vec![
            (ClarityName::from_literal("a"), Value::Int(1)),
            (ClarityName::from_literal("b"), Value::Bool(true)),
        ])
        .unwrap(),
    );
    let t_3 = Value::from(
        TupleData::from_data(vec![(ClarityName::from_literal("a"), Value::Int(1))]).unwrap(),
    );
    let t_4 = Value::from(
        TupleData::from_data(vec![
            (ClarityName::from_literal("a"), Value::Int(1)),
            (ClarityName::from_literal("c"), Value::Bool(true)),
        ])
        .unwrap(),
    );

    test_deser_ser(t_0.clone());
    test_deser_ser(t_1.clone());
    test_deser_ser(t_2.clone());
    test_deser_ser(t_3.clone());

    test_bad_expectation(t_0.clone(), TypeSignature::BoolType);

    // t_0 and t_1 are actually the same
    assert_eq!(
        Value::try_deserialize_hex(
            &t_1.serialize_to_hex().unwrap(),
            &TypeSignature::type_of(&t_0).unwrap(),
            false
        )
        .unwrap(),
        Value::try_deserialize_hex(
            &t_0.serialize_to_hex().unwrap(),
            &TypeSignature::type_of(&t_0).unwrap(),
            false
        )
        .unwrap()
    );

    // field number not equal to expectations
    assert!(matches!(
        Value::try_deserialize_hex(
            &t_3.serialize_to_hex().unwrap(),
            &TypeSignature::type_of(&t_1).unwrap(),
            false
        )
        .unwrap_err(),
        SerializationError::DeserializeExpected(_)
    ));

    // field type mismatch
    assert!(matches!(
        Value::try_deserialize_hex(
            &t_2.serialize_to_hex().unwrap(),
            &TypeSignature::type_of(&t_1).unwrap(),
            false
        )
        .unwrap_err(),
        SerializationError::DeserializeExpected(_)
    ));

    // field not-present in expected
    assert!(matches!(
        Value::try_deserialize_hex(
            &t_1.serialize_to_hex().unwrap(),
            &TypeSignature::type_of(&t_4).unwrap(),
            false
        )
        .unwrap_err(),
        SerializationError::DeserializeExpected(_)
    ));
}

/// `{a:int,b:int}` buffer with a duplicate `a` field (values 1 then 2).
const DUPLICATE_FIELDS: &str =
    "0c000000020161000000000000000000000000000000000101610000000000000000000000000000000002";
/// Like [`DUPLICATE_FIELDS`], plus a trailing unknown field `c`.
const DUPLICATE_WITH_UNKNOWN_FIELD: &str = "0c00000003016100000000000000000000000000000000010161000000000000000000000000000000000201630000000000000000000000000000000003";
/// The single-field `{a: 2}` tuple the duplicate buffers reduce to.
const REDUCED_TUPLE: &str = "0c0000000101610000000000000000000000000000000002";

#[derive(Clone, Copy, Debug)]
enum TupleInput {
    /// A canonical `{a: 1, b: 2}` tuple.
    WellFormed,
    /// `{a: 1, b: 2, c: 3}` - one field more than the expected type declares.
    Wider,
    /// A single-field `{a: 1}` tuple - one field fewer than declared.
    MissingField,
    /// Two fields both named `a` - the duplicate-key buffer.
    Duplicate,
    /// Two `a` fields plus an unknown `c` field.
    DuplicateWithUnknown,
    /// A canonical `{a: 1, b: 2}` tuple followed by one extra trailing byte.
    TrailingBytes,
    /// The duplicate-key tuple wrapped in an `optional`.
    NestedOptionDuplicate,
    /// The duplicate-key tuple nested as field `x` of an outer tuple.
    NestedTupleDuplicate,
}

/// Expected outcome of a single deserialization call.
#[derive(Clone, Copy, Debug)]
enum Expect {
    /// Succeeds, yielding the canonical `{a: 1, b: 2}` tuple.
    WellFormed,
    /// Succeeds, yielding the reduced single-field `{a: 2}` tuple.
    Reduced,
    /// Succeeds, yielding `(some {a: 2})`.
    NestedOptionReduced,
    /// Succeeds, yielding `{x: {a: 2}}`.
    NestedTupleReduced,
    /// Rejected because the wire field count does not match the declared type.
    ErrFieldCount,
    /// Rejected because a declared field was duplicated (strict construction).
    ErrIllegalTuple,
    /// Rejected because bytes remained after a complete value was read.
    ErrTrailingBytes,
}

fn well_formed_tuple() -> Value {
    Value::from(
        TupleData::from_data(vec![
            (ClarityName::from_literal("a"), Value::Int(1)),
            (ClarityName::from_literal("b"), Value::Int(2)),
        ])
        .unwrap(),
    )
}

fn tuple_case_input(input: TupleInput) -> (Vec<u8>, TypeSignature) {
    let flat_type = TypeSignature::type_of(&well_formed_tuple()).unwrap();
    match input {
        TupleInput::WellFormed => (well_formed_tuple().serialize_to_vec().unwrap(), flat_type),
        TupleInput::Wider => {
            let wider = Value::from(
                TupleData::from_data(vec![
                    (ClarityName::from_literal("a"), Value::Int(1)),
                    (ClarityName::from_literal("b"), Value::Int(2)),
                    (ClarityName::from_literal("c"), Value::Int(3)),
                ])
                .unwrap(),
            );
            (wider.serialize_to_vec().unwrap(), flat_type)
        }
        TupleInput::MissingField => {
            let single = Value::from(
                TupleData::from_data(vec![(ClarityName::from_literal("a"), Value::Int(1))])
                    .unwrap(),
            );
            (single.serialize_to_vec().unwrap(), flat_type)
        }
        TupleInput::Duplicate => (hex_bytes(DUPLICATE_FIELDS).unwrap(), flat_type),
        TupleInput::DuplicateWithUnknown => {
            (hex_bytes(DUPLICATE_WITH_UNKNOWN_FIELD).unwrap(), flat_type)
        }
        TupleInput::TrailingBytes => {
            let mut bytes = well_formed_tuple().serialize_to_vec().unwrap();
            bytes.push(0x00);
            (bytes, flat_type)
        }
        TupleInput::NestedOptionDuplicate => (
            hex_bytes(&format!("0a{DUPLICATE_FIELDS}")).unwrap(),
            TypeSignature::new_option(flat_type).unwrap(),
        ),
        TupleInput::NestedTupleDuplicate => {
            // `0x78` = field name "x"; its value is the inner duplicate tuple.
            let outer_type = TypeSignature::TupleType(
                TupleTypeSignature::try_from(vec![(ClarityName::from_literal("x"), flat_type)])
                    .unwrap(),
            );
            (
                hex_bytes(&format!("0c000000010178{DUPLICATE_FIELDS}")).unwrap(),
                outer_type,
            )
        }
    }
}

fn assert_deserialization_outcome(result: Result<Value, SerializationError>, expect: Expect) {
    match expect {
        Expect::WellFormed => assert_eq!(result.unwrap(), well_formed_tuple()),
        Expect::Reduced => assert_eq!(result.unwrap().serialize_to_hex().unwrap(), REDUCED_TUPLE),
        Expect::NestedOptionReduced => {
            assert_eq!(
                result.unwrap().serialize_to_hex().unwrap(),
                format!("0a{REDUCED_TUPLE}")
            )
        }
        Expect::NestedTupleReduced => {
            assert_eq!(
                result.unwrap().serialize_to_hex().unwrap(),
                format!("0c000000010178{REDUCED_TUPLE}")
            )
        }
        Expect::ErrFieldCount => assert!(
            matches!(result, Err(SerializationError::DeserializeExpected(_))),
            "expected a field-count rejection, got {result:?}"
        ),
        Expect::ErrIllegalTuple => assert!(
            matches!(result, Err(SerializationError::DeserializationFailure(_))),
            "expected a duplicate-field rejection, got {result:?}"
        ),
        Expect::ErrTrailingBytes => assert!(
            matches!(
                result,
                Err(SerializationError::LeftoverBytesInDeserialization)
            ),
            "expected a trailing-bytes rejection, got {result:?}"
        ),
    }
}

/// Strict tuple-field enforcement are gated to Epoch 4.1+.
#[rstest]
#[case::well_formed_unsanitized(TupleInput::WellFormed, StacksEpochId::Epoch21, Expect::WellFormed)]
#[case::well_formed_legacy_sanitized(
    TupleInput::WellFormed,
    StacksEpochId::Epoch40,
    Expect::WellFormed
)]
#[case::well_formed_strict(TupleInput::WellFormed, StacksEpochId::Epoch41, Expect::WellFormed)]
#[case::wider_unsanitized_rejected(
    TupleInput::Wider,
    StacksEpochId::Epoch21,
    Expect::ErrFieldCount
)]
#[case::wider_sanitized_away_legacy(TupleInput::Wider, StacksEpochId::Epoch40, Expect::WellFormed)]
#[case::wider_sanitized_away_strict(TupleInput::Wider, StacksEpochId::Epoch41, Expect::WellFormed)]
#[case::missing_field_unsanitized(
    TupleInput::MissingField,
    StacksEpochId::Epoch21,
    Expect::ErrFieldCount
)]
#[case::missing_field_strict(
    TupleInput::MissingField,
    StacksEpochId::Epoch41,
    Expect::ErrFieldCount
)]
#[case::duplicate_unsanitized_legacy(
    TupleInput::Duplicate,
    StacksEpochId::Epoch21,
    Expect::Reduced
)]
#[case::duplicate_sanitized_legacy(TupleInput::Duplicate, StacksEpochId::Epoch40, Expect::Reduced)]
#[case::duplicate_strict_rejected(
    TupleInput::Duplicate,
    StacksEpochId::Epoch41,
    Expect::ErrIllegalTuple
)]
#[case::duplicate_unknown_unsanitized(
    TupleInput::DuplicateWithUnknown,
    StacksEpochId::Epoch21,
    Expect::ErrFieldCount
)]
#[case::duplicate_unknown_sanitized_legacy(
    TupleInput::DuplicateWithUnknown,
    StacksEpochId::Epoch40,
    Expect::Reduced
)]
#[case::duplicate_unknown_strict_rejected(
    TupleInput::DuplicateWithUnknown,
    StacksEpochId::Epoch41,
    Expect::ErrIllegalTuple
)]
#[case::trailing_bytes_legacy(
    TupleInput::TrailingBytes,
    StacksEpochId::Epoch40,
    Expect::ErrTrailingBytes
)]
#[case::trailing_bytes_strict(
    TupleInput::TrailingBytes,
    StacksEpochId::Epoch41,
    Expect::ErrTrailingBytes
)]
#[case::nested_option_legacy(
    TupleInput::NestedOptionDuplicate,
    StacksEpochId::Epoch40,
    Expect::NestedOptionReduced
)]
#[case::nested_option_strict(
    TupleInput::NestedOptionDuplicate,
    StacksEpochId::Epoch41,
    Expect::ErrIllegalTuple
)]
#[case::nested_tuple_legacy(
    TupleInput::NestedTupleDuplicate,
    StacksEpochId::Epoch40,
    Expect::NestedTupleReduced
)]
#[case::nested_tuple_strict(
    TupleInput::NestedTupleDuplicate,
    StacksEpochId::Epoch41,
    Expect::ErrIllegalTuple
)]
fn typed_tuple_deserialization_epoch_gated(
    #[case] input: TupleInput,
    #[case] epoch: StacksEpochId,
    #[case] expect: Expect,
) {
    let (bytes, expected_type) = tuple_case_input(input);
    assert_deserialization_outcome(
        Value::try_deserialize_bytes_exact_at_epoch(&bytes, &expected_type, &epoch),
        expect,
    );
}

/// The hex entry point backing the DB read path shares the same epoch gate.
#[rstest]
#[case::legacy_sanitized(StacksEpochId::Epoch40, Expect::Reduced)]
#[case::strict_from_epoch41(StacksEpochId::Epoch41, Expect::ErrIllegalTuple)]
fn try_deserialize_hex_at_epoch_selects_tuple_field_handling(
    #[case] epoch: StacksEpochId,
    #[case] expect: Expect,
) {
    let expected_type = TypeSignature::type_of(&well_formed_tuple()).unwrap();
    assert_deserialization_outcome(
        Value::try_deserialize_hex_at_epoch(DUPLICATE_FIELDS, &expected_type, &epoch),
        expect,
    );
}

#[test]
fn test_vectors() {
    let tests = [
        ("1010", Err("Bad type prefix".into())),
        ("0000000000000000000000000000000001", Ok(Value::Int(1))),
        ("00ffffffffffffffffffffffffffffffff", Ok(Value::Int(-1))),
        ("0100000000000000000000000000000001", Ok(Value::UInt(1))),
        (
            "0200000004deadbeef",
            Ok(Value::buff_from(vec![0xde, 0xad, 0xbe, 0xef]).unwrap()),
        ),
        ("03", Ok(Value::Bool(true))),
        ("04", Ok(Value::Bool(false))),
        (
            "050011deadbeef11ababffff11deadbeef11ababffff",
            Ok(StandardPrincipalData::new(
                0x00,
                [
                    0x11, 0xde, 0xad, 0xbe, 0xef, 0x11, 0xab, 0xab, 0xff, 0xff, 0x11, 0xde, 0xad,
                    0xbe, 0xef, 0x11, 0xab, 0xab, 0xff, 0xff,
                ],
            )
            .unwrap()
            .into()),
        ),
        (
            "060011deadbeef11ababffff11deadbeef11ababffff0461626364",
            Ok(QualifiedContractIdentifier::new(
                StandardPrincipalData::new(
                    0x00,
                    [
                        0x11, 0xde, 0xad, 0xbe, 0xef, 0x11, 0xab, 0xab, 0xff, 0xff, 0x11, 0xde,
                        0xad, 0xbe, 0xef, 0x11, 0xab, 0xab, 0xff, 0xff,
                    ],
                )
                .unwrap(),
                ContractName::from_literal("abcd"),
            )
            .into()),
        ),
        (
            "0700ffffffffffffffffffffffffffffffff",
            Ok(Value::okay(Value::Int(-1)).unwrap()),
        ),
        (
            "0800ffffffffffffffffffffffffffffffff",
            Ok(Value::error(Value::Int(-1)).unwrap()),
        ),
        ("09", Ok(Value::none())),
        (
            "0a00ffffffffffffffffffffffffffffffff",
            Ok(Value::some(Value::Int(-1)).unwrap()),
        ),
        (
            "0b0000000400000000000000000000000000000000010000000000000000000000000000000002000000000000000000000000000000000300fffffffffffffffffffffffffffffffc",
            Ok(Value::list_from(vec![
                Value::Int(1),
                Value::Int(2),
                Value::Int(3),
                Value::Int(-4),
            ])
            .unwrap()),
        ),
        (
            "0c000000020362617a0906666f6f62617203",
            Ok(Value::from(
                TupleData::from_data(vec![
                    (ClarityName::from_literal("baz"), Value::none()),
                    (ClarityName::from_literal("foobar"), Value::Bool(true)),
                ])
                .unwrap(),
            )),
        ),
    ];

    for (test, expected) in tests.iter() {
        if let Ok(x) = expected {
            assert_eq!(test, &x.serialize_to_hex().unwrap());
        }
        assert_eq!(expected, &Value::try_deserialize_hex_untyped(test));
        assert_eq!(
            expected,
            &Value::try_deserialize_hex_untyped(&format!("0x{test}"))
        );
    }

    // test the serialized_size implementation
    for (test, expected) in tests.iter() {
        if let Ok(value) = expected {
            assert_eq!(
                value.serialized_size().unwrap(),
                test.len() as u32 / 2,
                "serialized_size() should return the byte length of the serialization (half the length of the hex encoding)",
            );
        }
    }
}

#[test]
fn try_deser_large_list() {
    let buff = vec![
        11, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    ];

    assert_eq!(
        Value::try_deserialize_bytes_untyped(&buff).unwrap_err(),
        SerializationError::DeserializationFailure("Illegal list type".to_string())
    );
}

#[test]
fn try_deser_large_tuple() {
    let buff = vec![
        12, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    ];

    assert_eq!(
        Value::try_deserialize_bytes_untyped(&buff).unwrap_err(),
        SerializationError::DeserializationFailure("Illegal tuple type".to_string())
    );
}

#[test]
fn try_overflow_stack() {
    let input = "08080808080808080808070707080807080808080808080708080808080708080707080707080807080808080808080708080808080708080707080708070807080808080808080708080808080708080708080808080808080807070807080808080808070808070707080807070808070808080808070808070708070807080808080808080707080708070807080708080808080808070808080808070808070808080808080808080707080708080808080807080807070708080707080807080808080807080807070807080708080808080808070708070808080808080708080707070808070708080807080807070708";
    assert_eq!(
        Err(ClarityTypeError::TypeSignatureTooDeep.into()),
        Value::try_deserialize_hex_untyped(input)
    );
}

#[test]
fn test_principals() {
    let issuer =
        PrincipalData::parse_standard_principal("SM2J6ZY48GV1EZ5V2V5RB9MP66SW86PYKKQVX8X0G")
            .unwrap();
    let standard_p = Value::from(issuer.clone());

    let contract_identifier =
        QualifiedContractIdentifier::new(issuer, ContractName::from_literal("foo"));
    let contract_p2 = Value::from(PrincipalData::Contract(contract_identifier));

    test_deser_ser(contract_p2.clone());
    test_deser_ser(standard_p.clone());

    test_bad_expectation(contract_p2, TypeSignature::BoolType);
    test_bad_expectation(standard_p, TypeSignature::BoolType);
}

#[test]
fn test_serialize_to_vec_returns_serialization_failure() {
    let value = Value::Sequence(SequenceData::String(CharType::ASCII(ASCIIData {
        data: vec![0; MAX_VALUE_SIZE as usize + 1],
    })));
    let err = value.serialize_to_vec().unwrap_err();
    assert_eq!(
        SerializationError::SerializationFailure(ClarityTypeError::ValueTooLarge.to_string()),
        err
    );
}

#[test]
fn test_serialize_to_hex_returns_serialization_failure() {
    let value = Value::Sequence(SequenceData::String(CharType::ASCII(ASCIIData {
        data: vec![0; MAX_VALUE_SIZE as usize + 1],
    })));
    let err = value.serialize_to_hex().unwrap_err();
    assert_eq!(
        SerializationError::SerializationFailure(ClarityTypeError::ValueTooLarge.to_string()),
        err
    );
}

/// Truncating after the first entry's value makes the unwind loop hit EOF
/// while reading the next key of a partially-filled tuple frame.
#[test]
fn test_tuple_truncated_at_next_key_errors() {
    let tuple = Value::from(
        TupleData::from_data(vec![
            (
                ClarityName::try_from("a".to_string()).unwrap(),
                Value::Bool(true),
            ),
            (
                ClarityName::try_from("b".to_string()).unwrap(),
                Value::Bool(false),
            ),
        ])
        .unwrap(),
    );
    let mut bytes = vec![];
    tuple.serialize_write(&mut bytes).unwrap();

    // tuple prefix (1) + entry count (4) + key "a" (1-byte len + 1) +
    // BoolTrue prefix (1) = 8 bytes; cut right before key "b".
    bytes.truncate(8);

    match Value::deserialize_read(&mut bytes.as_slice(), None, false) {
        Ok(value) => panic!("accidentally parsed truncated tuple: {value}"),
        Err(SerializationError::IOError(e)) => {
            assert_eq!(e.err.kind(), std::io::ErrorKind::UnexpectedEof);
        }
        Err(other) => panic!("expected IOError(UnexpectedEof), got {other:?}"),
    }
}
