// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
#[cfg(feature = "rusqlite")]
pub use sqlite::MemoryBackingStore;

pub use self::caching::ClarityExecutionCache;
pub use self::clarity_db::{
    BurnStateDB, ClarityDatabase, HeadersDB, NULL_BURN_STATE_DB, NULL_HEADER_DB,
    STORE_CONTRACT_SRC_INTERFACE, StoreType,
};
pub use self::clarity_store::{ClarityBackingStore, SpecialCaseHandler};
pub use self::key_value_wrapper::{RollbackWrapper, RollbackWrapperPersistedLog};
#[cfg(feature = "rusqlite")]
pub use self::sqlite::{DATA_TABLE_NAME, METADATA_TABLE_NAME, MetadataRow, SqliteConnection};
pub use self::structures::{
    ClarityDeserializable, ClaritySerializable, DataMapMetadata, DataVariableMetadata,
    FungibleTokenMetadata, NonFungibleTokenMetadata, STXBalance,
};

mod caching;
pub mod clarity_db;
pub mod clarity_store;
mod key_value_wrapper;
#[cfg(feature = "rusqlite")]
pub mod sqlite;
mod structures;
