(define-trait empty ())
