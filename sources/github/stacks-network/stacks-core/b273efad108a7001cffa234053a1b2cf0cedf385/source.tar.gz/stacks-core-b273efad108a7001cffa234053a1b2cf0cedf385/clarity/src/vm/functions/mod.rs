// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use stacks_common::types::StacksEpochId;

use crate::vm::Value::CallableContract;
use crate::vm::analysis::errors::CommonCheckErrorKind;
use crate::vm::callables::{CallableType, NativeHandle, cost_input_sized_vararg};
use crate::vm::contexts::{ExecutionState, InvocationContext};
use crate::vm::costs::cost_functions::ClarityCostFunction;
use crate::vm::costs::{CostTracker, MemoryConsumer, constants as cost_constants, runtime_cost};
use crate::vm::errors::{
    EarlyReturnError, RuntimeCheckErrorKind, SyntaxBindingError, SyntaxBindingErrorType,
    VmExecutionError, check_argument_count, check_arguments_at_least,
};
pub use crate::vm::functions::assets::stx_transfer_consolidated;
use crate::vm::representations::{ClarityName, SymbolicExpression, SymbolicExpressionType};
use crate::vm::types::{BuffData, PrincipalData, SequenceData, TypeSignature, Value};
use crate::vm::{LocalContext, eval, is_reserved};

macro_rules! switch_on_global_epoch {
    ($Name:ident ($Epoch2Version:ident, $Epoch205Version:ident)) => {
        pub fn $Name(
            args: &[SymbolicExpression],
            exec_state: &mut crate::vm::ExecutionState,
            invoke_ctx: &crate::vm::InvocationContext,
            context: &LocalContext,
        ) -> std::result::Result<Value, VmExecutionError> {
            if exec_state.epoch() == &StacksEpochId::Epoch10 {
                panic!("Executing Clarity method during Epoch 1.0, before Clarity")
            } else if exec_state.epoch() == &StacksEpochId::Epoch20 {
                $Epoch2Version(args, exec_state, invoke_ctx, context)
            } else {
                $Epoch205Version(args, exec_state, invoke_ctx, context)
            }
        }
    };
}

use super::errors::VmInternalError;
use crate::vm::ClarityVersion;

mod arithmetic;
mod assets;
pub(crate) mod bitcoin;
#[cfg(test)]
mod bitcoin_madhouse;
mod boolean;
mod conversions;
mod crypto;
mod database;
pub mod define;
mod options;
mod post_conditions;
pub mod principals;
mod sequences;
pub mod tuples;

define_versioned_named_enum_with_max!(NativeFunctions(ClarityVersion) {
    Add("+", ClarityVersion::Clarity1, None),
    Subtract("-", ClarityVersion::Clarity1, None),
    Multiply("*", ClarityVersion::Clarity1, None),
    Divide("/", ClarityVersion::Clarity1, None),
    CmpGeq(">=", ClarityVersion::Clarity1, None),
    CmpLeq("<=", ClarityVersion::Clarity1, None),
    CmpLess("<", ClarityVersion::Clarity1, None),
    CmpGreater(">", ClarityVersion::Clarity1, None),
    ToInt("to-int", ClarityVersion::Clarity1, None),
    ToUInt("to-uint", ClarityVersion::Clarity1, None),
    Modulo("mod", ClarityVersion::Clarity1, None),
    Power("pow", ClarityVersion::Clarity1, None),
    Sqrti("sqrti", ClarityVersion::Clarity1, None),
    Log2("log2", ClarityVersion::Clarity1, None),
    BitwiseXor("xor", ClarityVersion::Clarity1, None),
    And("and", ClarityVersion::Clarity1, None),
    Or("or", ClarityVersion::Clarity1, None),
    Not("not", ClarityVersion::Clarity1, None),
    Equals("is-eq", ClarityVersion::Clarity1, None),
    If("if", ClarityVersion::Clarity1, None),
    Let("let", ClarityVersion::Clarity1, None),
    Map("map", ClarityVersion::Clarity1, None),
    Fold("fold", ClarityVersion::Clarity1, None),
    Append("append", ClarityVersion::Clarity1, None),
    Concat("concat", ClarityVersion::Clarity1, None),
    AsMaxLen("as-max-len?", ClarityVersion::Clarity1, None),
    Len("len", ClarityVersion::Clarity1, None),
    ElementAt("element-at", ClarityVersion::Clarity1, None),
    ElementAtAlias("element-at?", ClarityVersion::Clarity2, None),
    IndexOf("index-of", ClarityVersion::Clarity1, None),
    IndexOfAlias("index-of?", ClarityVersion::Clarity2, None),
    BuffToIntLe("buff-to-int-le", ClarityVersion::Clarity2, None),
    BuffToUIntLe("buff-to-uint-le", ClarityVersion::Clarity2, None),
    BuffToIntBe("buff-to-int-be", ClarityVersion::Clarity2, None),
    BuffToUIntBe("buff-to-uint-be", ClarityVersion::Clarity2, None),
    IsStandard("is-standard", ClarityVersion::Clarity2, None),
    PrincipalDestruct("principal-destruct?", ClarityVersion::Clarity2, None),
    PrincipalConstruct("principal-construct?", ClarityVersion::Clarity2, None),
    StringToInt("string-to-int?", ClarityVersion::Clarity2, None),
    StringToUInt("string-to-uint?", ClarityVersion::Clarity2, None),
    IntToAscii("int-to-ascii", ClarityVersion::Clarity2, None),
    IntToUtf8("int-to-utf8", ClarityVersion::Clarity2, None),
    ListCons("list", ClarityVersion::Clarity1, None),
    FetchVar("var-get", ClarityVersion::Clarity1, None),
    SetVar("var-set", ClarityVersion::Clarity1, None),
    FetchEntry("map-get?", ClarityVersion::Clarity1, None),
    SetEntry("map-set", ClarityVersion::Clarity1, None),
    InsertEntry("map-insert", ClarityVersion::Clarity1, None),
    DeleteEntry("map-delete", ClarityVersion::Clarity1, None),
    TupleCons("tuple", ClarityVersion::Clarity1, None),
    TupleGet("get", ClarityVersion::Clarity1, None),
    TupleMerge("merge", ClarityVersion::Clarity1, None),
    Begin("begin", ClarityVersion::Clarity1, None),
    Hash160("hash160", ClarityVersion::Clarity1, None),
    Sha256("sha256", ClarityVersion::Clarity1, None),
    Sha512("sha512", ClarityVersion::Clarity1, None),
    Sha512Trunc256("sha512/256", ClarityVersion::Clarity1, None),
    Keccak256("keccak256", ClarityVersion::Clarity1, None),
    Secp256k1Recover("secp256k1-recover?", ClarityVersion::Clarity1, None),
    Secp256k1Verify("secp256k1-verify", ClarityVersion::Clarity1, None),
    Print("print", ClarityVersion::Clarity1, None),
    ContractCall("contract-call?", ClarityVersion::Clarity1, None),
    AsContract("as-contract", ClarityVersion::Clarity1, Some(ClarityVersion::Clarity3)),
    ContractOf("contract-of", ClarityVersion::Clarity1, None),
    PrincipalOf("principal-of?", ClarityVersion::Clarity1, None),
    AtBlock("at-block", ClarityVersion::Clarity1, Some(ClarityVersion::Clarity4)),
    GetBlockInfo("get-block-info?", ClarityVersion::Clarity1, Some(ClarityVersion::Clarity2)),
    GetBurnBlockInfo("get-burn-block-info?", ClarityVersion::Clarity2, None),
    ConsError("err", ClarityVersion::Clarity1, None),
    ConsOkay("ok", ClarityVersion::Clarity1, None),
    ConsSome("some", ClarityVersion::Clarity1, None),
    DefaultTo("default-to", ClarityVersion::Clarity1, None),
    Asserts("asserts!", ClarityVersion::Clarity1, None),
    UnwrapRet("unwrap!", ClarityVersion::Clarity1, None),
    UnwrapErrRet("unwrap-err!", ClarityVersion::Clarity1, None),
    Unwrap("unwrap-panic", ClarityVersion::Clarity1, None),
    UnwrapErr("unwrap-err-panic", ClarityVersion::Clarity1, None),
    Match("match", ClarityVersion::Clarity1, None),
    TryRet("try!", ClarityVersion::Clarity1, None),
    IsOkay("is-ok", ClarityVersion::Clarity1, None),
    IsNone("is-none", ClarityVersion::Clarity1, None),
    IsErr("is-err", ClarityVersion::Clarity1, None),
    IsSome("is-some", ClarityVersion::Clarity1, None),
    Filter("filter", ClarityVersion::Clarity1, None),
    GetTokenBalance("ft-get-balance", ClarityVersion::Clarity1, None),
    GetAssetOwner("nft-get-owner?", ClarityVersion::Clarity1, None),
    TransferToken("ft-transfer?", ClarityVersion::Clarity1, None),
    TransferAsset("nft-transfer?", ClarityVersion::Clarity1, None),
    MintAsset("nft-mint?", ClarityVersion::Clarity1, None),
    MintToken("ft-mint?", ClarityVersion::Clarity1, None),
    GetTokenSupply("ft-get-supply", ClarityVersion::Clarity1, None),
    BurnToken("ft-burn?", ClarityVersion::Clarity1, None),
    BurnAsset("nft-burn?", ClarityVersion::Clarity1, None),
    GetStxBalance("stx-get-balance", ClarityVersion::Clarity1, None),
    StxTransfer("stx-transfer?", ClarityVersion::Clarity1, None),
    StxTransferMemo("stx-transfer-memo?", ClarityVersion::Clarity2, None),
    StxBurn("stx-burn?", ClarityVersion::Clarity1, None),
    StxGetAccount("stx-account", ClarityVersion::Clarity2, None),
    BitwiseAnd("bit-and", ClarityVersion::Clarity2, None),
    BitwiseOr("bit-or", ClarityVersion::Clarity2, None),
    BitwiseNot("bit-not", ClarityVersion::Clarity2, None),
    BitwiseLShift("bit-shift-left", ClarityVersion::Clarity2, None),
    BitwiseRShift("bit-shift-right", ClarityVersion::Clarity2, None),
    BitwiseXor2("bit-xor", ClarityVersion::Clarity2, None),
    Slice("slice?", ClarityVersion::Clarity2, None),
    ToConsensusBuff("to-consensus-buff?", ClarityVersion::Clarity2, None),
    FromConsensusBuff("from-consensus-buff?", ClarityVersion::Clarity2, None),
    ReplaceAt("replace-at?", ClarityVersion::Clarity2, None),
    GetStacksBlockInfo("get-stacks-block-info?", ClarityVersion::Clarity3, None),
    GetTenureInfo("get-tenure-info?", ClarityVersion::Clarity3, None),
    ContractHash("contract-hash?", ClarityVersion::Clarity4, None),
    ToAscii("to-ascii?", ClarityVersion::Clarity4, None),
    RestrictAssets("restrict-assets?", ClarityVersion::Clarity4, None),
    AsContractSafe("as-contract?", ClarityVersion::Clarity4, None),
    AllowanceWithStx("with-stx", ClarityVersion::Clarity4, None),
    AllowanceWithFt("with-ft", ClarityVersion::Clarity4, None),
    AllowanceWithNft("with-nft", ClarityVersion::Clarity4, None),
    AllowanceWithStacking("with-stacking", ClarityVersion::Clarity4, Some(ClarityVersion::Clarity5)),
    AllowanceWithStaking("with-staking", ClarityVersion::Clarity6, None),
    AllowanceWithPox("with-pox", ClarityVersion::Clarity6, None),
    AllowanceAll("with-all-assets-unsafe", ClarityVersion::Clarity4, None),
    Secp256r1Verify("secp256r1-verify", ClarityVersion::Clarity4, None),
    VerifyMerkleProof("verify-merkle-proof", ClarityVersion::Clarity6, None),
    GetBitcoinTxOutput("get-bitcoin-tx-output?", ClarityVersion::Clarity6, None),
    Ed25519Verify("ed25519-verify", ClarityVersion::Clarity6, None),
    Secp256k1Decompress("secp256k1-decompress?", ClarityVersion::Clarity6, None),
});

///
/// Returns a callable for the given native function if it exists in the provided
///   ClarityVersion
///
pub fn lookup_reserved_functions(
    name: &str,
    version: &ClarityVersion,
) -> Option<CallableType<'static>> {
    use crate::vm::callables::BuiltinKind::{Native, Native205, Special};
    use crate::vm::functions::NativeFunctions::*;
    if let Some(native_function) = NativeFunctions::lookup_by_name_at_version(name, version) {
        // The Clarity source-level name (e.g. "+", "tuple", "fold") is uniform across all
        // builtins, so it is derived once here and attached to the wrapping `Builtin` below
        // rather than threaded through every match arm.
        let clarity_name = native_function.get_name_str();
        let kind = match native_function {
            Add => Native(
                "native_add",
                NativeHandle::MoreArg(&arithmetic::native_add),
                ClarityCostFunction::Add,
            ),
            Subtract => Native(
                "native_sub",
                NativeHandle::MoreArg(&arithmetic::native_sub),
                ClarityCostFunction::Sub,
            ),
            Multiply => Native(
                "native_mul",
                NativeHandle::MoreArg(&arithmetic::native_mul),
                ClarityCostFunction::Mul,
            ),
            Divide => Native(
                "native_div",
                NativeHandle::MoreArg(&arithmetic::native_div),
                ClarityCostFunction::Div,
            ),
            CmpGeq => Special("special_geq", &arithmetic::special_geq),
            CmpLeq => Special("special_leq", &arithmetic::special_leq),
            CmpLess => Special("special_le", &arithmetic::special_less),
            CmpGreater => Special("special_ge", &arithmetic::special_greater),
            ToUInt => Native(
                "native_to_uint",
                NativeHandle::SingleArg(&arithmetic::native_to_uint),
                ClarityCostFunction::IntCast,
            ),
            ToInt => Native(
                "native_to_int",
                NativeHandle::SingleArg(&arithmetic::native_to_int),
                ClarityCostFunction::IntCast,
            ),
            Modulo => Native(
                "native_mod",
                NativeHandle::DoubleArg(&arithmetic::native_mod),
                ClarityCostFunction::Mod,
            ),
            Power => Native(
                "native_pow",
                NativeHandle::DoubleArg(&arithmetic::native_pow),
                ClarityCostFunction::Pow,
            ),
            Sqrti => Native(
                "native_sqrti",
                NativeHandle::SingleArg(&arithmetic::native_sqrti),
                ClarityCostFunction::Sqrti,
            ),
            Log2 => Native(
                "native_log2",
                NativeHandle::SingleArg(&arithmetic::native_log2),
                ClarityCostFunction::Log2,
            ),
            BitwiseXor => Native(
                "native_xor",
                NativeHandle::DoubleArg(&arithmetic::native_xor),
                ClarityCostFunction::Xor,
            ),
            And => Special("special_and", &boolean::special_and),
            Or => Special("special_or", &boolean::special_or),
            Not => Native(
                "native_not",
                NativeHandle::SingleArg(&boolean::native_not),
                ClarityCostFunction::Not,
            ),
            Equals => Native205(
                "native_eq",
                NativeHandle::MoreArgEnv(&native_eq),
                ClarityCostFunction::Eq,
                &cost_input_sized_vararg,
            ),
            If => Special("special_if", &special_if),
            Let => Special("special_let", &special_let),
            FetchVar => Special("special_var-get", &database::special_fetch_variable),
            SetVar => Special("special_set-var", &database::special_set_variable),
            Map => Special("special_map", &sequences::special_map),
            Filter => Special("special_filter", &sequences::special_filter),
            BuffToIntLe => Native(
                "native_buff_to_int_le",
                NativeHandle::SingleArg(&conversions::native_buff_to_int_le),
                ClarityCostFunction::BuffToIntLe,
            ),
            BuffToUIntLe => Native(
                "native_buff_to_uint_le",
                NativeHandle::SingleArg(&conversions::native_buff_to_uint_le),
                ClarityCostFunction::BuffToUIntLe,
            ),
            BuffToIntBe => Native(
                "native_buff_to_int_be",
                NativeHandle::SingleArg(&conversions::native_buff_to_int_be),
                ClarityCostFunction::BuffToIntBe,
            ),
            BuffToUIntBe => Native(
                "native_buff_to_uint_be",
                NativeHandle::SingleArg(&conversions::native_buff_to_uint_be),
                ClarityCostFunction::BuffToUIntBe,
            ),
            StringToInt => Native(
                "native_string_to_int",
                NativeHandle::SingleArg(&conversions::native_string_to_int),
                ClarityCostFunction::StringToInt,
            ),
            StringToUInt => Native(
                "native_string_to_uint",
                NativeHandle::SingleArg(&conversions::native_string_to_uint),
                ClarityCostFunction::StringToUInt,
            ),
            IntToAscii => Native(
                "native_int_to_ascii",
                NativeHandle::SingleArg(&conversions::native_int_to_ascii),
                ClarityCostFunction::IntToAscii,
            ),
            IntToUtf8 => Native(
                "native_int_to_utf8",
                NativeHandle::SingleArg(&conversions::native_int_to_utf8),
                ClarityCostFunction::IntToUtf8,
            ),
            IsStandard => Special("special_is_standard", &principals::special_is_standard),
            PrincipalDestruct => Special(
                "special_principal_destruct",
                &principals::special_principal_destruct,
            ),
            PrincipalConstruct => Special(
                "special_principal_construct",
                &principals::special_principal_construct,
            ),
            Fold => Special("special_fold", &sequences::special_fold),
            Concat => Special("special_concat", &sequences::special_concat),
            AsMaxLen => Special("special_as_max_len", &sequences::special_as_max_len),
            Append => Special("special_append", &sequences::special_append),
            Len => Native(
                "native_len",
                NativeHandle::SingleArg(&sequences::native_len),
                ClarityCostFunction::Len,
            ),
            ElementAt | ElementAtAlias => Native(
                "native_element_at",
                NativeHandle::DoubleArg(&sequences::native_element_at),
                ClarityCostFunction::ElementAt,
            ),
            IndexOf | IndexOfAlias => Native205(
                "native_index_of",
                NativeHandle::DoubleArg(&sequences::native_index_of),
                ClarityCostFunction::IndexOf,
                &cost_input_sized_vararg,
            ),
            Slice => Special("special_slice", &sequences::special_slice),
            ListCons => Special("special_list_cons", &sequences::list_cons),
            FetchEntry => Special("special_map-get?", &database::special_fetch_entry),
            SetEntry => Special("special_set-entry", &database::special_set_entry),
            InsertEntry => Special("special_insert-entry", &database::special_insert_entry),
            DeleteEntry => Special("special_delete-entry", &database::special_delete_entry),
            TupleCons => Special("special_tuple", &tuples::tuple_cons),
            TupleGet => Special("special_get-tuple", &tuples::tuple_get),
            TupleMerge => Native205(
                "native_merge-tuple",
                NativeHandle::DoubleArg(&tuples::tuple_merge),
                ClarityCostFunction::TupleMerge,
                &cost_input_sized_vararg,
            ),
            Begin => Native(
                "native_begin",
                NativeHandle::MoreArg(&native_begin),
                ClarityCostFunction::Begin,
            ),
            Hash160 => Native205(
                "native_hash160",
                NativeHandle::SingleArg(&crypto::native_hash160),
                ClarityCostFunction::Hash160,
                &cost_input_sized_vararg,
            ),
            Sha256 => Native205(
                "native_sha256",
                NativeHandle::SingleArg(&crypto::native_sha256),
                ClarityCostFunction::Sha256,
                &cost_input_sized_vararg,
            ),
            Sha512 => Native205(
                "native_sha512",
                NativeHandle::SingleArg(&crypto::native_sha512),
                ClarityCostFunction::Sha512,
                &cost_input_sized_vararg,
            ),
            Sha512Trunc256 => Native205(
                "native_sha512trunc256",
                NativeHandle::SingleArg(&crypto::native_sha512trunc256),
                ClarityCostFunction::Sha512t256,
                &cost_input_sized_vararg,
            ),
            Keccak256 => Native205(
                "native_keccak256",
                NativeHandle::SingleArg(&crypto::native_keccak256),
                ClarityCostFunction::Keccak256,
                &cost_input_sized_vararg,
            ),
            Secp256k1Recover => Special(
                "native_secp256k1-recover",
                &crypto::special_secp256k1_recover,
            ),
            Secp256k1Verify => {
                Special("native_secp256k1-verify", &crypto::special_secp256k1_verify)
            }
            Print => Special("special_print", &special_print),
            ContractCall => Special("special_contract-call", &database::special_contract_call),
            AsContract => Special("special_as-contract", &special_as_contract),
            ContractOf => Special("special_contract-of", &special_contract_of),
            PrincipalOf => Special("special_principal-of", &crypto::special_principal_of),
            GetBlockInfo => Special("special_get_block_info", &database::special_get_block_info),
            GetBurnBlockInfo => Special(
                "special_get_burn_block_info",
                &database::special_get_burn_block_info,
            ),
            GetStacksBlockInfo => Special(
                "special_get_stacks_block_info",
                &database::special_get_stacks_block_info,
            ),
            GetTenureInfo => Special(
                "special_get_tenure_info",
                &database::special_get_tenure_info,
            ),
            ConsSome => Native(
                "native_some",
                NativeHandle::SingleArg(&options::native_some),
                ClarityCostFunction::SomeCons,
            ),
            ConsOkay => Native(
                "native_okay",
                NativeHandle::SingleArg(&options::native_okay),
                ClarityCostFunction::OkCons,
            ),
            ConsError => Native(
                "native_error",
                NativeHandle::SingleArg(&options::native_error),
                ClarityCostFunction::ErrCons,
            ),
            DefaultTo => Native(
                "native_default_to",
                NativeHandle::DoubleArg(&options::native_default_to),
                ClarityCostFunction::DefaultTo,
            ),
            Asserts => Special("special_asserts", &special_asserts),
            UnwrapRet => Native(
                "native_unwrap_ret",
                NativeHandle::DoubleArg(&options::native_unwrap_or_ret),
                ClarityCostFunction::UnwrapRet,
            ),
            UnwrapErrRet => Native(
                "native_unwrap_err_ret",
                NativeHandle::DoubleArg(&options::native_unwrap_err_or_ret),
                ClarityCostFunction::UnwrapErrOrRet,
            ),
            IsOkay => Native(
                "native_is_okay",
                NativeHandle::SingleArg(&options::native_is_okay),
                ClarityCostFunction::IsOkay,
            ),
            IsNone => Native(
                "native_is_none",
                NativeHandle::SingleArg(&options::native_is_none),
                ClarityCostFunction::IsNone,
            ),
            IsErr => Native(
                "native_is_err",
                NativeHandle::SingleArg(&options::native_is_err),
                ClarityCostFunction::IsErr,
            ),
            IsSome => Native(
                "native_is_some",
                NativeHandle::SingleArg(&options::native_is_some),
                ClarityCostFunction::IsSome,
            ),
            Unwrap => Native(
                "native_unwrap",
                NativeHandle::SingleArg(&options::native_unwrap),
                ClarityCostFunction::Unwrap,
            ),
            UnwrapErr => Native(
                "native_unwrap_err",
                NativeHandle::SingleArg(&options::native_unwrap_err),
                ClarityCostFunction::UnwrapErr,
            ),
            Match => Special("special_match", &options::special_match),
            TryRet => Native(
                "native_try_ret",
                NativeHandle::SingleArg(&options::native_try_ret),
                ClarityCostFunction::TryRet,
            ),
            MintAsset => Special("special_mint_asset", &assets::special_mint_asset),
            MintToken => Special("special_mint_token", &assets::special_mint_token),
            TransferAsset => Special("special_transfer_asset", &assets::special_transfer_asset),
            TransferToken => Special("special_transfer_token", &assets::special_transfer_token),
            GetTokenBalance => Special("special_get_balance", &assets::special_get_balance),
            GetAssetOwner => Special("special_get_owner", &assets::special_get_owner),
            BurnAsset => Special("special_burn_asset", &assets::special_burn_asset),
            BurnToken => Special("special_burn_token", &assets::special_burn_token),
            GetTokenSupply => Special(
                "special_get_token_supply",
                &assets::special_get_token_supply,
            ),
            AtBlock => Special("special_at_block", &database::special_at_block),
            GetStxBalance => Special("special_stx_balance", &assets::special_stx_balance),
            StxTransfer => Special("special_stx_transfer", &assets::special_stx_transfer),
            StxTransferMemo => Special(
                "special_stx_transfer_memo",
                &assets::special_stx_transfer_memo,
            ),
            StxBurn => Special("special_stx_burn", &assets::special_stx_burn),
            StxGetAccount => Special("stx_get_account", &assets::special_stx_account),
            ToConsensusBuff => Native205(
                "to_consensus_buff",
                NativeHandle::SingleArg(&conversions::to_consensus_buff),
                ClarityCostFunction::ToConsensusBuff,
                &cost_input_sized_vararg,
            ),
            FromConsensusBuff => Special("from_consensus_buff", &conversions::from_consensus_buff),
            ReplaceAt => Special("replace_at", &sequences::special_replace_at),
            BitwiseAnd => Native(
                "native_bitwise_and",
                NativeHandle::MoreArg(&arithmetic::native_bitwise_and),
                ClarityCostFunction::BitwiseAnd,
            ),
            BitwiseOr => Native(
                "native_bitwise_or",
                NativeHandle::MoreArg(&arithmetic::native_bitwise_or),
                ClarityCostFunction::BitwiseOr,
            ),
            BitwiseNot => Native(
                "native_bitwise_not",
                NativeHandle::SingleArg(&arithmetic::native_bitwise_not),
                ClarityCostFunction::BitwiseNot,
            ),
            BitwiseLShift => Native(
                "native_bitwise_left_shift",
                NativeHandle::DoubleArg(&arithmetic::native_bitwise_left_shift),
                ClarityCostFunction::BitwiseLShift,
            ),
            BitwiseRShift => Native(
                "native_bitwise_right_shift",
                NativeHandle::DoubleArg(&arithmetic::native_bitwise_right_shift),
                ClarityCostFunction::BitwiseRShift,
            ),
            BitwiseXor2 => Native(
                "native_bitwise_xor",
                NativeHandle::MoreArg(&arithmetic::native_bitwise_xor),
                ClarityCostFunction::Xor,
            ),
            ContractHash => Special("special_contract_hash", &database::special_contract_hash),
            ToAscii => Special("special_to_ascii", &conversions::special_to_ascii),
            RestrictAssets => Special(
                "special_restrict_assets",
                &post_conditions::special_restrict_assets,
            ),
            AsContractSafe => Special("special_as_contract", &post_conditions::special_as_contract),
            AllowanceWithStx
            | AllowanceWithFt
            | AllowanceWithNft
            | AllowanceWithStacking
            | AllowanceWithStaking
            | AllowanceWithPox
            | AllowanceAll => Special("special_allowance", &post_conditions::special_allowance),
            Secp256r1Verify => {
                Special("native_secp256r1-verify", &crypto::special_secp256r1_verify)
            }
            VerifyMerkleProof => Native205(
                "native_verify_merkle_proof",
                NativeHandle::MoreArg(&bitcoin::native_verify_merkle_proof),
                ClarityCostFunction::VerifyMerkleProof,
                &bitcoin::cost_input_verify_merkle_proof,
            ),
            GetBitcoinTxOutput => Native205(
                "native_get_bitcoin_tx_output",
                NativeHandle::DoubleArg(&bitcoin::native_get_bitcoin_tx_output),
                ClarityCostFunction::GetBitcoinTxOutput,
                &bitcoin::cost_input_get_bitcoin_tx_output,
            ),
            Ed25519Verify => Native205(
                "native_ed25519-verify",
                NativeHandle::MoreArg(&crypto::native_ed25519_verify),
                ClarityCostFunction::Ed25519verify,
                &crypto::cost_input_ed25519_verify,
            ),
            Secp256k1Decompress => Native(
                "native_secp256k1-decompress",
                NativeHandle::SingleArg(&crypto::native_secp256k1_decompress),
                ClarityCostFunction::Secp256k1decompress,
            ),
        };
        Some(CallableType::Builtin { clarity_name, kind })
    } else {
        None
    }
}

fn native_eq(
    args: Vec<Value>,
    exec_state: &mut ExecutionState,
    _invoke_ctx: &InvocationContext,
) -> Result<Value, VmExecutionError> {
    // TODO: this currently uses the derived equality checks of Value,
    //   however, that's probably not how we want to implement equality
    //   checks on the ::ListTypes

    if args.len() < 2 {
        Ok(Value::Bool(true))
    } else {
        let first = &args[0];
        // check types:
        let mut arg_type = TypeSignature::type_of(first)?;
        for x in args.iter() {
            arg_type = TypeSignature::least_supertype(
                exec_state.epoch(),
                &TypeSignature::type_of(x)?,
                &arg_type,
            )?;
            if x != first {
                return Ok(Value::Bool(false));
            }
        }
        Ok(Value::Bool(true))
    }
}

fn native_begin(mut args: Vec<Value>) -> Result<Value, VmExecutionError> {
    match args.pop() {
        Some(v) => Ok(v),
        None => {
            Err(RuntimeCheckErrorKind::Unreachable("Requires at least args: 1 got 0".into()).into())
        }
    }
}

fn special_print(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    let arg = args.first().ok_or_else(|| {
        VmInternalError::BadSymbolicRepresentation("Print should have an argument".into())
    })?;
    let input = eval(arg, exec_state, invoke_ctx, context)?;

    runtime_cost(
        ClarityCostFunction::Print,
        exec_state,
        input.as_ref().size()?,
    )?;

    if cfg!(feature = "developer-mode") {
        debug!("{}", input.as_ref());
    }

    let value = input.clone_with_cost(exec_state)?;
    exec_state.register_print_event(invoke_ctx, value.clone())?;
    Ok(value)
}

fn special_if(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(3, args)?;

    runtime_cost(ClarityCostFunction::If, exec_state, 0)?;
    // handle the conditional clause.
    let conditional = eval(&args[0], exec_state, invoke_ctx, context)?;
    match conditional.as_ref() {
        Value::Bool(result) => {
            if *result {
                eval(&args[1], exec_state, invoke_ctx, context)?.clone_with_cost(exec_state)
            } else {
                eval(&args[2], exec_state, invoke_ctx, context)?.clone_with_cost(exec_state)
            }
        }
        _ => Err(RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::BoolType),
            conditional.as_ref().to_error_string(),
        )
        .into()),
    }
}

fn special_asserts(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(2, args)?;

    runtime_cost(ClarityCostFunction::Asserts, exec_state, 0)?;
    // handle the conditional clause.
    let conditional = eval(&args[0], exec_state, invoke_ctx, context)?;

    match conditional.as_ref() {
        Value::Bool(result) => {
            if *result {
                conditional.clone_with_cost(exec_state)
            } else {
                let thrown =
                    eval(&args[1], exec_state, invoke_ctx, context)?.clone_with_cost(exec_state)?;
                Err(EarlyReturnError::AssertionFailed(Box::new(thrown)).into())
            }
        }
        _ => Err(RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::BoolType),
            conditional.as_ref().to_error_string(),
        )
        .into()),
    }
}

pub fn handle_binding_list<F, E>(
    bindings: &[SymbolicExpression],
    binding_error_type: SyntaxBindingErrorType,
    mut handler: F,
) -> std::result::Result<(), E>
where
    F: FnMut(&ClarityName, &SymbolicExpression) -> std::result::Result<(), E>,
    E: for<'a> From<(CommonCheckErrorKind, &'a SymbolicExpression)>,
{
    for (i, binding) in bindings.iter().enumerate() {
        let binding_expression = binding.match_list().ok_or_else(|| {
            (
                SyntaxBindingError::NotList(binding_error_type, i).into(),
                binding,
            )
        })?;
        if binding_expression.len() != 2 {
            return Err((
                SyntaxBindingError::InvalidLength(binding_error_type, i).into(),
                binding,
            )
                .into());
        }
        let var_name = binding_expression[0].match_atom().ok_or_else(|| {
            (
                SyntaxBindingError::NotAtom(binding_error_type, i).into(),
                &binding_expression[0],
            )
        })?;
        let var_sexp = &binding_expression[1];

        handler(var_name, var_sexp)?;
    }
    Ok(())
}

pub fn parse_eval_bindings(
    bindings: &[SymbolicExpression],
    binding_error_type: SyntaxBindingErrorType,
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Vec<(ClarityName, Value)>, VmExecutionError> {
    let mut result = Vec::with_capacity(bindings.len());

    handle_binding_list(
        bindings,
        binding_error_type,
        |var_name, var_sexp| -> Result<(), VmExecutionError> {
            let value =
                eval(var_sexp, exec_state, invoke_ctx, context)?.clone_with_cost(exec_state)?;
            result.push((var_name.clone(), value));
            Ok(())
        },
    )?;

    Ok(result)
}

fn special_let(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    // (let ((x 1) (y 2)) (+ x y)) -> 3
    // arg0 => binding list
    // arg1..n => body
    check_arguments_at_least(2, args)?;

    // parse and eval the bindings.
    let bindings = args[0]
        .match_list()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Bad let syntax".into()))?;

    runtime_cost(ClarityCostFunction::Let, exec_state, bindings.len())?;

    // create a new context.
    let mut inner_context = context.extend()?;

    let mut memory_use = 0;

    finally_drop_memory!( exec_state, memory_use; {
        handle_binding_list::<_, VmExecutionError>(bindings, SyntaxBindingErrorType::Let, |binding_name, var_sexp| {
            if is_reserved(binding_name, invoke_ctx.contract_context.get_clarity_version()) ||
                invoke_ctx.contract_context.lookup_function(binding_name).is_some() ||
                inner_context.lookup_variable(binding_name).is_some() {
                    return Err(RuntimeCheckErrorKind::NameAlreadyUsed(binding_name.clone().into()).into())
                }

            let binding_value = eval(var_sexp, exec_state, invoke_ctx, &inner_context)?;

            let bind_mem_use = binding_value.as_ref().get_memory_use()?;
            exec_state.add_memory(bind_mem_use)?;
            memory_use += bind_mem_use; // no check needed, b/c it's done in add_memory.
            let binding_value = binding_value.clone_with_cost(exec_state)?;
            if *invoke_ctx.contract_context.get_clarity_version() >= ClarityVersion::Clarity2 && let CallableContract(trait_data) = &binding_value {
                inner_context.callable_contracts.insert(binding_name.clone(), trait_data.clone());
            }
            inner_context.variables.insert(binding_name.clone(), binding_value);
            Ok(())
        })?;

        // evaluate the let-bodies
        let mut last_result = None;
        for body in args[1..].iter() {
            let body_result = eval(body, exec_state, invoke_ctx, &inner_context)?;
            last_result.replace(body_result);
        }
        // last_result should always be Some(...), because of the arg len check above.
        last_result.ok_or_else(|| VmExecutionError::from(VmInternalError::Expect("Failed to get let result".into())))?.clone_with_cost(exec_state)
    })
}

fn special_as_contract(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    // (as-contract (..))
    // arg0 => body
    check_argument_count(1, args)?;

    // in epoch 2.1 and later, this has a cost
    if *exec_state.epoch() >= StacksEpochId::Epoch21 {
        runtime_cost(ClarityCostFunction::AsContract, exec_state, 0)?;
    }

    // nest an environment.
    exec_state.add_memory(cost_constants::AS_CONTRACT_MEMORY)?;

    let contract_principal = invoke_ctx
        .contract_context
        .contract_identifier
        .clone()
        .into();
    let nested_view = invoke_ctx.with_principal(contract_principal);

    let result = eval(&args[0], exec_state, &nested_view, context);

    exec_state.drop_memory(cost_constants::AS_CONTRACT_MEMORY)?;

    result?.clone_with_cost(exec_state)
}

fn special_contract_of(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    _invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    // (contract-of (..))
    // arg0 => trait
    check_argument_count(1, args)?;

    runtime_cost(ClarityCostFunction::ContractOf, exec_state, 0)?;

    let contract_ref = match &args[0].expr {
        SymbolicExpressionType::Atom(contract_ref) => contract_ref,
        _ => {
            return Err(
                RuntimeCheckErrorKind::Unreachable("Contract of expects trait".into()).into(),
            );
        }
    };

    let contract_identifier = match context.lookup_callable_contract(contract_ref) {
        Some(trait_data) => {
            if !exec_state
                .global_context
                .database
                .has_contract(&trait_data.contract_identifier)
            {
                return Err(RuntimeCheckErrorKind::NoSuchContract(
                    trait_data.contract_identifier.to_string(),
                )
                .into());
            }

            &trait_data.contract_identifier
        }
        _ => {
            return Err(
                RuntimeCheckErrorKind::Unreachable("Contract of expects trait".into()).into(),
            );
        }
    };

    let contract_principal = Value::Principal(PrincipalData::Contract(contract_identifier.clone()));
    Ok(contract_principal)
}

/// Helper to coerce a Clarity buffer value into a fixed-size byte array.
pub fn buff_to_array<const N: usize>(value: &Value) -> Option<[u8; N]> {
    match value {
        Value::Sequence(SequenceData::Buffer(BuffData { data })) if data.len() == N => {
            let mut out = [0u8; N];
            out.copy_from_slice(data);
            Some(out)
        }
        _ => None,
    }
}

/// Helper to coerce a Clarity buffer value into a Vec<u8> if-and-only-if buff.len() <= max_size
pub fn buff_to_vec(value: &Value, max_size: usize) -> Option<Vec<u8>> {
    match value {
        Value::Sequence(SequenceData::Buffer(BuffData { data })) if data.len() <= max_size => {
            Some(data.clone())
        }
        _ => None,
    }
}

#[cfg(test)]
mod test {
    use clarity_types::ClarityName;
    use stacks_common::consts::CHAIN_ID_TESTNET;
    use stacks_common::types::StacksEpochId;

    use super::ClarityVersion;
    use crate::vm::analysis::errors::RuntimeCheckErrorKind;
    use crate::vm::contexts::{ExecutionState, InvocationContext};
    use crate::vm::costs::LimitedCostTracker;
    use crate::vm::database::MemoryBackingStore;
    use crate::vm::errors::VmExecutionError;
    use crate::vm::functions::database::{
        special_contract_call, special_get_burn_block_info, special_get_stacks_block_info,
        special_get_tenure_info,
    };
    use crate::vm::functions::{special_contract_of, special_let};
    use crate::vm::tests::test_clarity_versions;
    use crate::vm::types::QualifiedContractIdentifier;
    use crate::vm::{
        CallStack, ContractContext, GlobalContext, LocalContext, SymbolicExpression, Value,
    };

    /// Tests that if somehow we bypass static analysis checks, contract_of will return
    /// a ContractOfExpectsTrait for a poorly defined contract-of? call.
    #[apply(test_clarity_versions)]
    fn special_contract_of_expect_trait(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );
        // --- Non-atom argument: (list u1) ---
        let non_atom =
            SymbolicExpression::list(vec![SymbolicExpression::atom_value(Value::UInt(1))]);
        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err =
            special_contract_of(&[non_atom], &mut exec_state, &invoke_ctx, &context).unwrap_err();
        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "Contract of expects trait".into()
            ))
        );
    }

    /// Tests that if the argument is an atom but NOT a callable trait binding,
    /// contract_of returns ContractOfExpectsTrait at runtime.
    #[apply(test_clarity_versions)]
    fn special_contract_of_expect_trait_not_callable(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        // --- Atom argument, but NOT registered as a callable trait ---
        let atom = SymbolicExpression::atom(ClarityName::from_literal("not_a_trait"));

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        //  NO callable contracts added to LocalContext
        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err = special_contract_of(&[atom], &mut exec_state, &invoke_ctx, &context).unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "Contract of expects trait".into()
            ))
        );
    }

    #[apply(test_clarity_versions)]
    fn special_let_bad_syntax(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
        // Arg0 must be a list — we intentionally violate that
        let bad_bindings = SymbolicExpression::atom_value(Value::UInt(1));

        // Body expression (never reached)
        let body = SymbolicExpression::atom_value(Value::UInt(2));

        let args = vec![bad_bindings, body];

        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err = special_let(&args, &mut exec_state, &invoke_ctx, &context).unwrap_err();

        assert_eq!(
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "Bad let syntax".into()
            )),
            err
        );
    }

    #[apply(test_clarity_versions)]
    fn special_get_tenure_info_expect_property_name_non_atom(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        use crate::vm::analysis::errors::RuntimeCheckErrorKind;

        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        // First arg is NOT an atom
        let bad_property = SymbolicExpression::atom_value(Value::UInt(1));
        let height = SymbolicExpression::atom_value(Value::UInt(0));

        let args = vec![bad_property, height];

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err =
            special_get_tenure_info(&args, &mut exec_state, &invoke_ctx, &context).unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "Get tenure info expect property name".into()
            ))
        );
    }

    /// If we bypass static analysis and pass a non-atom as the property name to `get-burn-block-info?`,
    /// the runtime returns [`RuntimeCheckErrorKind::Unreachable`].
    #[apply(test_clarity_versions)]
    fn special_get_burn_block_info_expected_property_name(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        // Build INVALID property argument (non-atom)
        let bad_property = SymbolicExpression::atom_value(Value::UInt(1)); // must be an atom

        // Valid height argument
        let height = SymbolicExpression::atom_value(Value::UInt(0));

        let args = vec![bad_property, height];

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err =
            special_get_burn_block_info(&args, &mut exec_state, &invoke_ctx, &context).unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "Get block info expect property name".into()
            ))
        );
    }

    /// If we bypass static analysis and pass a non-atom to `get-stacks-block-info?`,
    /// the runtime returns [`RuntimeCheckErrorKind::Unreachable`].
    #[apply(test_clarity_versions)]
    fn special_get_stacks_block_info_expect_property_name_non_atom(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        // First arg is NOT an atom
        let bad_property = SymbolicExpression::atom_value(Value::UInt(1));
        let height = SymbolicExpression::atom_value(Value::UInt(0));

        let args = vec![bad_property, height];

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err = special_get_stacks_block_info(&args, &mut exec_state, &invoke_ctx, &context)
            .unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "Get stacks block info expect property name".into()
            ))
        );
    }

    /// If we bypass static analysis and pass an atom for a non existing property to `get-stacks-block-info?`,
    /// the runtime returns [`RuntimeCheckErrorKind::Unreachable`].
    #[apply(test_clarity_versions)]
    fn special_get_stacks_block_info_no_such_property(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        // Pass an Atom but NOT a valid stacks block info property
        let bad_property =
            SymbolicExpression::atom(ClarityName::from_literal("not-a-valid-stacks-prop"));

        let height = SymbolicExpression::atom_value(Value::UInt(0));

        let args = vec![bad_property, height];

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err = special_get_stacks_block_info(&args, &mut exec_state, &invoke_ctx, &context)
            .unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "No such stacks block info property: not-a-valid-stacks-prop".into()
            ))
        );
    }

    /// If we bypass static analysis and pass an atom for a non existing property to `get-burn-block-info?`,
    /// the runtime returns [`RuntimeCheckErrorKind::Unreachable`].
    #[apply(test_clarity_versions)]
    fn special_get_burn_block_info_no_such_property(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        // Atom But NOT a valid burn block info property
        let bad_property =
            SymbolicExpression::atom(ClarityName::from_literal("not-a-valid-burn-prop"));

        // Valid uint height to avoid TypeValueError
        let height = SymbolicExpression::atom_value(Value::UInt(0));

        let args = vec![bad_property, height];

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new();
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };

        let err =
            special_get_burn_block_info(&args, &mut exec_state, &invoke_ctx, &context).unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::Unreachable(
                "No such burn block info property: not-a-valid-burn-prop".into()
            ))
        );
    }

    #[apply(test_clarity_versions)]
    fn special_contract_call_expect_name_dynamic_not_callable(
        #[case] version: ClarityVersion,
        #[case] epoch: StacksEpochId,
    ) {
        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            epoch,
        );

        let contract_context =
            ContractContext::new(QualifiedContractIdentifier::transient(), version);

        let context = LocalContext::new(); // EMPTY — no callable_contracts
        let mut call_stack = CallStack::new();

        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };
        // (contract-call? unknown-contract foo)
        let args = vec![
            SymbolicExpression::atom(ClarityName::from_literal("unknown-contract")), // Atom, NOT registered
            SymbolicExpression::atom(ClarityName::from_literal("foo")), // Valid function name atom
        ];

        let err = special_contract_call(&args, &mut exec_state, &invoke_ctx, &context).unwrap_err();

        assert_eq!(
            err,
            VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::ContractCallExpectName)
        );
    }
}
