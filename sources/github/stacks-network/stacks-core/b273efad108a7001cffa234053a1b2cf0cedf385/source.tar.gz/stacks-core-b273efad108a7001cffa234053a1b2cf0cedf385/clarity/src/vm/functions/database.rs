// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use clarity_types::ClarityName;
use clarity_types::types::CallableData;
use stacks_common::bounded_format;
use stacks_common::consts::CHAIN_ID_TESTNET;
use stacks_common::types::StacksEpochId;
use stacks_common::types::chainstate::StacksBlockId;

use crate::vm::callables::DefineType;
use crate::vm::contexts::{ExecutionState, InvocationContext};
use crate::vm::costs::cost_functions::ClarityCostFunction;
use crate::vm::costs::{CostTracker, MemoryConsumer, constants as cost_constants, runtime_cost};
use crate::vm::errors::{
    RuntimeCheckErrorKind, RuntimeError, VmExecutionError, VmInternalError, check_argument_count,
    check_arguments_at_least,
};
use crate::vm::representations::{SymbolicExpression, SymbolicExpressionType};
use crate::vm::types::{
    BlockInfoProperty, BuffData, BurnBlockInfoProperty, PrincipalData, SequenceData,
    StacksBlockInfoProperty, TenureInfoProperty, TupleData, TypeSignature, Value,
};
use crate::vm::{ClarityVersion, LocalContext, eval};

switch_on_global_epoch!(special_fetch_variable(
    special_fetch_variable_v200,
    special_fetch_variable_v205
));
switch_on_global_epoch!(special_set_variable(
    special_set_variable_v200,
    special_set_variable_v205
));
switch_on_global_epoch!(special_fetch_entry(
    special_fetch_entry_v200,
    special_fetch_entry_v205
));
switch_on_global_epoch!(special_set_entry(
    special_set_entry_v200,
    special_set_entry_v205
));
switch_on_global_epoch!(special_insert_entry(
    special_insert_entry_v200,
    special_insert_entry_v205
));
switch_on_global_epoch!(special_delete_entry(
    special_delete_entry_v200,
    special_delete_entry_v205
));

pub fn special_contract_call(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_arguments_at_least(2, args)?;

    // the second part of the contract_call cost (i.e., the load contract cost)
    //   is checked in `execute_contract`, and the function _application_ cost
    //   is checked in callables::DefinedFunction::execute_apply.
    runtime_cost(ClarityCostFunction::ContractCall, exec_state, 0)?;

    let function_name = args[1]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;
    let rest_args_slice = &args[2..];
    let rest_args_len = rest_args_slice.len();
    let mut rest_args = Vec::with_capacity(rest_args_len);
    for arg in rest_args_slice.iter() {
        let evaluated_arg = eval(arg, exec_state, invoke_ctx, context)?;
        rest_args.push(SymbolicExpression::atom_value(
            evaluated_arg.clone_with_cost(exec_state)?,
        ));
    }

    let (contract_identifier, type_returns_constraint) = match &args[0].expr {
        SymbolicExpressionType::LiteralValue(Value::Principal(PrincipalData::Contract(
            contract_identifier,
        ))) => {
            // Static dispatch
            (contract_identifier.clone(), None)
        }
        SymbolicExpressionType::Atom(contract_ref) => {
            // First, check if the atom references a contract constant which is a callable
            let callable = invoke_ctx
                .contract_context
                .lookup_variable(contract_ref)
                .and_then(|value| {
                    if !invoke_ctx
                        .contract_context
                        .get_clarity_version()
                        .supports_callables()
                    {
                        return None;
                    }
                    if !exec_state.epoch().supports_call_with_constant() {
                        return None;
                    }
                    if invoke_ctx.contract_context.is_deploying {
                        return None;
                    }
                    let Value::Principal(PrincipalData::Contract(contract_identifier)) = value
                    else {
                        return None;
                    };
                    Some(CallableData {
                        contract_identifier: contract_identifier.clone(),
                        trait_identifier: None,
                    })
                })
                // If not, check if the atom references a callable variable
                .or_else(|| context.lookup_callable_contract(contract_ref).cloned());

            match callable {
                Some(CallableData {
                    contract_identifier,
                    trait_identifier: None,
                }) => {
                    // This is static dispatch via a callable variable (a constant or a contract
                    // principal bound to a `let` variable).
                    (contract_identifier.clone(), None)
                }
                Some(CallableData {
                    contract_identifier,
                    trait_identifier: Some(trait_identifier),
                }) => {
                    // Ensure that contract-call is used for inter-contract calls only
                    if contract_identifier == invoke_ctx.contract_context.contract_identifier {
                        return Err(RuntimeCheckErrorKind::CircularReference(vec![
                            contract_identifier.name.to_string(),
                        ])
                        .into());
                    }

                    let contract_to_check = exec_state
                        .global_context
                        .database
                        .get_contract(&contract_identifier)
                        .map_err(|_e| {
                            RuntimeCheckErrorKind::NoSuchContract(contract_identifier.to_string())
                        })?;

                    // Attempt to short circuit the dynamic dispatch checks:
                    // If the contract is explicitely implementing the trait with `impl-trait`,
                    // then we can simply rely on the analysis performed at publish time.
                    if contract_to_check.is_explicitly_implementing_trait(&trait_identifier) {
                        (contract_identifier.clone(), None)
                    } else {
                        // Load the contract that defines the trait.
                        let contract_defining_trait = exec_state
                            .global_context
                            .database
                            .get_contract(&trait_identifier.contract_identifier)
                            .map_err(|_e| {
                                RuntimeCheckErrorKind::NoSuchContract(
                                    trait_identifier.contract_identifier.to_string(),
                                )
                            })?;

                        // Retrieve the function that will be invoked
                        let function_to_check = contract_to_check
                            .lookup_function(function_name)
                            .ok_or_else(|| {
                                RuntimeCheckErrorKind::BadTraitImplementation(
                                    trait_identifier.name.to_string(),
                                    function_name.to_string(),
                                )
                            })?;

                        // Check read/write compatibility
                        if exec_state.global_context.is_read_only() {
                            return Err(RuntimeCheckErrorKind::Unreachable(
                                "Trait based contract call in read-only".into(),
                            )
                            .into());
                        }

                        // Check visibility
                        if function_to_check.define_type == DefineType::Private {
                            return Err(RuntimeCheckErrorKind::NoSuchPublicFunction(
                                contract_identifier.to_string(),
                                function_name.to_string(),
                            )
                            .into());
                        }

                        let expected_sig = function_to_check.check_trait_expectations(
                            exec_state.epoch(),
                            &contract_defining_trait,
                            &trait_identifier,
                        )?;
                        // Own the return type so the trait-defining contract is released here
                        // instead of staying loaded through the nested call.
                        (
                            contract_identifier.clone(),
                            Some(expected_sig.returns.clone()),
                        )
                    }
                }
                _ => return Err(RuntimeCheckErrorKind::ContractCallExpectName.into()),
            }
        }
        _ => return Err(RuntimeCheckErrorKind::ContractCallExpectName.into()),
    };

    let contract_principal = invoke_ctx
        .contract_context
        .contract_identifier
        .clone()
        .into();

    let nested_ctx = invoke_ctx.with_caller(contract_principal);
    let result = exec_state.execute_contract(
        &nested_ctx,
        &contract_identifier,
        function_name,
        &rest_args,
        false,
    )?;

    // sanitize contract-call outputs in epochs >= 2.4
    let result_type = TypeSignature::type_of(&result)?;
    let (result, _) = Value::sanitize_value(exec_state.epoch(), &result_type, result)
        .ok_or(RuntimeCheckErrorKind::CouldNotDetermineType)?;

    // Ensure that the expected type from the trait spec admits
    // the type of the value returned by the dynamic dispatch.
    if let Some(returns_type_signature) = type_returns_constraint {
        let actual_returns = TypeSignature::type_of(&result)?;
        if !returns_type_signature.admits_type(exec_state.epoch(), &actual_returns)? {
            return Err(RuntimeCheckErrorKind::ReturnTypesMustMatch(
                Box::new(returns_type_signature),
                Box::new(actual_returns),
            )
            .into());
        }
    }

    Ok(result)
}

pub fn special_fetch_variable_v200(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    _context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(1, args)?;

    let var_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_var
        .get(var_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such data variable: {var_name}"
        )))?;

    runtime_cost(
        ClarityCostFunction::FetchVar,
        exec_state,
        data_types.value_type.size()?,
    )?;

    let epoch = *exec_state.epoch();
    exec_state
        .global_context
        .database
        .lookup_variable(contract, var_name, data_types, &epoch)
}

/// The Stacks v205 version of fetch_variable uses the actual stored size of the
///  value as input to the cost tabulation. Otherwise identical to v200.
pub fn special_fetch_variable_v205(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    _context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(1, args)?;

    let var_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_var
        .get(var_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such data variable: {var_name}"
        )))?;

    let epoch = *exec_state.epoch();
    let result = exec_state
        .global_context
        .database
        .lookup_variable_with_size(contract, var_name, data_types, &epoch);

    let result_size = match &result {
        Ok(data) => data.serialized_byte_len,
        Err(_e) => data_types.value_type.size()?.into(),
    };

    runtime_cost(ClarityCostFunction::FetchVar, exec_state, result_size)?;

    result.map(|data| data.value)
}

pub fn special_set_variable_v200(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(2, args)?;

    let value = eval(&args[1], exec_state, invoke_ctx, context)?;

    let var_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_var
        .get(var_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such data variable: {var_name}"
        )))?;

    runtime_cost(
        ClarityCostFunction::SetVar,
        exec_state,
        data_types.value_type.size()?,
    )?;

    exec_state.add_memory(value.as_ref().get_memory_use()?)?;

    let value = value.clone_with_cost(exec_state)?;
    let epoch = *exec_state.epoch();
    exec_state
        .global_context
        .database
        .set_variable(contract, var_name, value, data_types, &epoch)
        .map(|data| data.value)
}

/// The Stacks v205 version of set_variable uses the actual stored size of the
///  value as input to the cost tabulation. Otherwise identical to v200.
pub fn special_set_variable_v205(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(2, args)?;

    let value = eval(&args[1], exec_state, invoke_ctx, context)?;

    let var_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_var
        .get(var_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such data variable: {var_name}"
        )))?;

    let value = value.clone_with_cost(exec_state)?;
    let epoch = *exec_state.epoch();
    let result = exec_state
        .global_context
        .database
        .set_variable(contract, var_name, value, data_types, &epoch);

    let result_size = match &result {
        Ok(data) => data.serialized_byte_len,
        Err(_e) => data_types.value_type.size()?.into(),
    };

    runtime_cost(ClarityCostFunction::SetVar, exec_state, result_size)?;

    exec_state.add_memory(result_size)?;

    result.map(|data| data.value)
}

pub fn special_fetch_entry_v200(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(2, args)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    runtime_cost(
        ClarityCostFunction::FetchEntry,
        exec_state,
        data_types.value_type.size()? + data_types.key_type.size()?,
    )?;

    let epoch = *exec_state.epoch();
    exec_state.global_context.database.fetch_entry(
        contract,
        map_name,
        key.as_ref(),
        data_types,
        &epoch,
    )
}

/// The Stacks v205 version of fetch_entry uses the actual stored size of the
///  value as input to the cost tabulation. Otherwise identical to v200.
pub fn special_fetch_entry_v205(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(2, args)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    let epoch = *exec_state.epoch();
    let result = exec_state.global_context.database.fetch_entry_with_size(
        contract,
        map_name,
        key.as_ref(),
        data_types,
        &epoch,
    );

    let result_size = match &result {
        Ok(data) => data.serialized_byte_len,
        Err(_e) => (data_types.value_type.size()? + data_types.key_type.size()?).into(),
    };

    runtime_cost(ClarityCostFunction::FetchEntry, exec_state, result_size)?;

    result.map(|data| data.value)
}

pub fn special_at_block(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if !exec_state.epoch().supports_at_block() {
        return Err(RuntimeCheckErrorKind::AtBlockUnavailable.into());
    }
    check_argument_count(2, args)?;

    runtime_cost(ClarityCostFunction::AtBlock, exec_state, 0)?;
    let value = eval(&args[0], exec_state, invoke_ctx, context)?;
    let bhh = match value.as_ref() {
        Value::Sequence(SequenceData::Buffer(BuffData { data })) => {
            if data.len() != 32 {
                return Err(RuntimeError::BadBlockHash(data.clone()).into());
            } else {
                StacksBlockId::from(data.as_slice())
            }
        }
        _ => {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(TypeSignature::BUFFER_32),
                value.as_ref().to_error_string(),
            )
            .into());
        }
    };

    exec_state.add_memory(cost_constants::AT_BLOCK_MEMORY)?;
    let result = exec_state
        .evaluate_at_block(bhh, &args[1], invoke_ctx, context)
        .and_then(|v| v.clone_with_cost(exec_state));
    exec_state.drop_memory(cost_constants::AT_BLOCK_MEMORY)?;

    result
}

pub fn special_set_entry_v200(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(3, args)?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let value = eval(&args[2], exec_state, invoke_ctx, context)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    runtime_cost(
        ClarityCostFunction::SetEntry,
        exec_state,
        data_types.value_type.size()? + data_types.key_type.size()?,
    )?;

    exec_state.add_memory(key.as_ref().get_memory_use()?)?;
    exec_state.add_memory(value.as_ref().get_memory_use()?)?;

    let key = key.clone_with_cost(exec_state)?;
    let value = value.clone_with_cost(exec_state)?;
    let epoch = *exec_state.epoch();
    exec_state
        .global_context
        .database
        .set_entry(contract, map_name, key, value, data_types, &epoch)
        .map(|data| data.value)
}

/// The Stacks v205 version of set_entry uses the actual stored size of the
///  value as input to the cost tabulation. Otherwise identical to v200.
pub fn special_set_entry_v205(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(3, args)?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let value = eval(&args[2], exec_state, invoke_ctx, context)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    let key = key.clone_with_cost(exec_state)?;
    let value = value.clone_with_cost(exec_state)?;
    let epoch = *exec_state.epoch();
    let result = exec_state
        .global_context
        .database
        .set_entry(contract, map_name, key, value, data_types, &epoch);

    let result_size = match &result {
        Ok(data) => data.serialized_byte_len,
        Err(_e) => (data_types.value_type.size()? + data_types.key_type.size()?).into(),
    };

    runtime_cost(ClarityCostFunction::SetEntry, exec_state, result_size)?;

    exec_state.add_memory(result_size)?;

    result.map(|data| data.value)
}

pub fn special_insert_entry_v200(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(3, args)?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let value = eval(&args[2], exec_state, invoke_ctx, context)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    runtime_cost(
        ClarityCostFunction::SetEntry,
        exec_state,
        data_types.value_type.size()? + data_types.key_type.size()?,
    )?;

    exec_state.add_memory(key.as_ref().get_memory_use()?)?;
    exec_state.add_memory(value.as_ref().get_memory_use()?)?;

    let epoch = *exec_state.epoch();

    let key = key.clone_with_cost(exec_state)?;
    let value = value.clone_with_cost(exec_state)?;
    exec_state
        .global_context
        .database
        .insert_entry(contract, map_name, key, value, data_types, &epoch)
        .map(|data| data.value)
}

/// The Stacks v205 version of insert_entry uses the actual stored size of the
///  value as input to the cost tabulation. Otherwise identical to v200.
pub fn special_insert_entry_v205(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(3, args)?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let value = eval(&args[2], exec_state, invoke_ctx, context)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    let key = key.clone_with_cost(exec_state)?;
    let value = value.clone_with_cost(exec_state)?;
    let epoch = *exec_state.epoch();
    let result = exec_state
        .global_context
        .database
        .insert_entry(contract, map_name, key, value, data_types, &epoch);

    let result_size = match &result {
        Ok(data) => data.serialized_byte_len,
        Err(_e) => (data_types.value_type.size()? + data_types.key_type.size()?).into(),
    };

    runtime_cost(ClarityCostFunction::SetEntry, exec_state, result_size)?;

    exec_state.add_memory(result_size)?;

    result.map(|data| data.value)
}

pub fn special_delete_entry_v200(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(2, args)?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    runtime_cost(
        ClarityCostFunction::SetEntry,
        exec_state,
        data_types.key_type.size()?,
    )?;

    exec_state.add_memory(key.as_ref().get_memory_use()?)?;

    let epoch = *exec_state.epoch();
    exec_state
        .global_context
        .database
        .delete_entry(contract, map_name, key.as_ref(), data_types, &epoch)
        .map(|data| data.value)
}

/// The Stacks v205 version of delete_entry uses the actual stored size of the
///  value as input to the cost tabulation. Otherwise identical to v200.
pub fn special_delete_entry_v205(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    if exec_state.global_context.is_read_only() {
        return Err(
            RuntimeCheckErrorKind::Unreachable("Write attempted in read-only".into()).into(),
        );
    }

    check_argument_count(2, args)?;

    let key = eval(&args[1], exec_state, invoke_ctx, context)?;

    let map_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable("Expected name".into()))?;

    let contract = &invoke_ctx.contract_context.contract_identifier;

    let data_types = invoke_ctx
        .contract_context
        .meta_data_map
        .get(map_name)
        .ok_or(RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such map: {map_name}"
        )))?;

    let epoch = *exec_state.epoch();
    let result = exec_state.global_context.database.delete_entry(
        contract,
        map_name,
        key.as_ref(),
        data_types,
        &epoch,
    );

    let result_size = match &result {
        Ok(data) => data.serialized_byte_len,
        Err(_e) => data_types.key_type.size()?.into(),
    };

    runtime_cost(ClarityCostFunction::SetEntry, exec_state, result_size)?;

    exec_state.add_memory(result_size)?;

    result.map(|data| data.value)
}

/// Handles the `get-block-info?` special function.
/// Interprets `args` as variables `[property-name, block-height]`, and returns
/// a property value determined by `property-name`:
/// - `id-header-hash` returns the index block hash at `block-height`
/// - `header-hash` returns the header hash at `block-height`
/// - `time` returns the burn block time of the block at `block-height`
/// - `vrf-seed` returns the VRF seed of the block at `block-height`
/// - `burnchain-header-hash` returns header hash of the burnchain block corresponding to `block-height`
/// - `miner-address` returns the address of the principal that mined the block at `block-height`
/// - `miner-spend-winner` returns the number of satoshis spent by the winning miner for the block at `block-height`
/// - `miner-spend-total` returns the total number of satoshis spent by all miners for the block at `block-height`
/// - `block-reward` returns the block reward for the block at `block-height`
///
/// # Errors:
/// - [`RuntimeCheckErrorKind`] cost errors (e.g., `CostOverflow`, `CostBalanceExceeded`) from [`runtime_cost`].
/// - [`RuntimeCheckErrorKind::IncorrectArgumentCount`] if there aren't 2 arguments.
/// - [`RuntimeCheckErrorKind::GetBlockInfoExpectPropertyName`] if `args[0]` isn't a ClarityName or isn't a valid [`BlockInfoProperty`].
/// - [`RuntimeCheckErrorKind::TypeValueError`] if `args[1]` doesn't evaluate to a `uint`.
/// - [`VmExecutionError`] propagated from [`eval`] when evaluating `args[1]`.
/// - [`VmInternalError`] from database operations when retrieving block information.
pub fn special_get_block_info(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    // (get-block-info? property-name block-height-uint)
    runtime_cost(ClarityCostFunction::BlockInfo, exec_state, 0)?;

    check_argument_count(2, args)?;

    // Handle the block property name input arg.
    let property_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable(
            "Get block info expect property name".into(),
        ))?;

    let version = invoke_ctx.contract_context.get_clarity_version();

    let block_info_prop = BlockInfoProperty::lookup_by_name_at_version(property_name, version)
        .ok_or(RuntimeCheckErrorKind::Unreachable(
            "Get block info expect property name".into(),
        ))?;

    // Handle the block-height input arg clause.
    let height_eval = eval(&args[1], exec_state, invoke_ctx, context)?;
    let height_value = match height_eval.as_ref() {
        Value::UInt(result) => Ok(*result),
        _ => Err(RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::UIntType),
            height_eval.as_ref().to_error_string(),
        )),
    }?;

    let height_value = match u32::try_from(height_value) {
        Ok(result) => result,
        _ => return Ok(Value::none()),
    };

    // interpret height as a tenure height IFF
    // * clarity version is less than Clarity3
    // * the evaluated epoch is geq 3.0
    // * we are not on (classic) primary testnet
    let interpret_height_as_tenure_height = invoke_ctx.contract_context.get_clarity_version()
        < &ClarityVersion::Clarity3
        && exec_state.global_context.epoch_id >= StacksEpochId::Epoch30
        && exec_state.global_context.chain_id != CHAIN_ID_TESTNET;

    let height_value = if !interpret_height_as_tenure_height {
        height_value
    } else {
        // interpretting height_value as a tenure height
        let height_opt = exec_state
            .global_context
            .database
            .get_block_height_for_tenure_height(height_value)?;
        match height_opt {
            Some(x) => x,
            None => return Ok(Value::none()),
        }
    };

    let current_block_height = exec_state
        .global_context
        .database
        .get_current_block_height();
    if height_value >= current_block_height {
        return Ok(Value::none());
    }

    let result = match block_info_prop {
        BlockInfoProperty::Time => {
            let block_time = exec_state
                .global_context
                .database
                .get_burn_block_time(height_value, None)?;
            Value::UInt(u128::from(block_time))
        }
        BlockInfoProperty::VrfSeed => {
            let vrf_seed = exec_state
                .global_context
                .database
                .get_block_vrf_seed(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: vrf_seed.as_bytes().to_vec(),
            }))
        }
        BlockInfoProperty::HeaderHash => {
            let header_hash = exec_state
                .global_context
                .database
                .get_block_header_hash(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: header_hash.as_bytes().to_vec(),
            }))
        }
        BlockInfoProperty::BurnchainHeaderHash => {
            let burnchain_header_hash = exec_state
                .global_context
                .database
                .get_burnchain_block_header_hash(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: burnchain_header_hash.as_bytes().to_vec(),
            }))
        }
        BlockInfoProperty::IdentityHeaderHash => {
            let id_header_hash = exec_state
                .global_context
                .database
                .get_index_block_header_hash(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: id_header_hash.as_bytes().to_vec(),
            }))
        }
        BlockInfoProperty::MinerAddress => {
            let miner_address = exec_state
                .global_context
                .database
                .get_miner_address(height_value)?;
            Value::from(miner_address)
        }
        BlockInfoProperty::MinerSpendWinner => {
            let winner_spend = exec_state
                .global_context
                .database
                .get_miner_spend_winner(height_value)?;
            Value::UInt(winner_spend)
        }
        BlockInfoProperty::MinerSpendTotal => {
            let total_spend = exec_state
                .global_context
                .database
                .get_miner_spend_total(height_value)?;
            Value::UInt(total_spend)
        }
        BlockInfoProperty::BlockReward => {
            // this is already an optional
            let block_reward_opt = exec_state
                .global_context
                .database
                .get_block_reward(height_value)?;
            return Ok(match block_reward_opt {
                Some(x) => Value::some(Value::UInt(x))?,
                None => Value::none(),
            });
        }
    };

    Ok(Value::some(result)?)
}

/// Handles the `get-burn-block-info?` special function.
/// Interprets `args` as variables `[property_name, burn_block_height]`, and returns
/// a property value determined by `property_name`:
/// - `header_hash` returns the burn block header hash at `burn_block_height`
/// - `pox_addrs` returns the list of PoX addresses paid out at `burn_block_height`
///
/// # Errors:
/// - [`RuntimeCheckErrorKind::IncorrectArgumentCount`] if there aren't 2 arguments.
/// - [`RuntimeCheckErrorKind::GetBlockInfoExpectPropertyName`] if `args[0]` isn't a ClarityName.
/// - [`RuntimeCheckErrorKind::NoSuchBurnBlockInfoProperty`] if `args[0]` isn't a [`BurnBlockInfoProperty`].
/// - [`RuntimeCheckErrorKind::TypeValueError`] if `args[1]` doesn't evaluate to a `uint`.
/// - [`RuntimeCheckErrorKind`] cost errors (e.g., `CostOverflow`, `CostBalanceExceeded`) from [`runtime_cost`].
/// - [`VmExecutionError`] propagated from [`eval`] when evaluating `args[1]`.
/// - [`VmInternalError`] from database operations or value construction failures.
pub fn special_get_burn_block_info(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    runtime_cost(ClarityCostFunction::GetBurnBlockInfo, exec_state, 0)?;

    check_argument_count(2, args)?;

    // Handle the block property name input arg.
    let property_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable(
            "Get block info expect property name".into(),
        ))?;

    let block_info_prop = BurnBlockInfoProperty::lookup_by_name(property_name).ok_or(
        RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such burn block info property: {property_name}"
        )),
    )?;

    // Handle the block-height input arg clause.
    let height_eval = eval(&args[1], exec_state, invoke_ctx, context)?;
    let height_value = match height_eval.as_ref() {
        Value::UInt(result) => *result,
        _ => {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(TypeSignature::UIntType),
                height_eval.as_ref().to_error_string(),
            )
            .into());
        }
    };

    // Note: We assume that we will not have a height bigger than u32::MAX.
    let height_value = match u32::try_from(height_value) {
        Ok(result) => result,
        _ => return Ok(Value::none()),
    };

    match block_info_prop {
        BurnBlockInfoProperty::HeaderHash => {
            let burnchain_header_hash_opt = exec_state
                .global_context
                .database
                .get_burnchain_block_header_hash_for_burnchain_height(height_value)?;

            match burnchain_header_hash_opt {
                Some(burnchain_header_hash) => Ok(Value::some(Value::Sequence(
                    SequenceData::Buffer(BuffData {
                        data: burnchain_header_hash.as_bytes().to_vec(),
                    }),
                ))?),
                None => Ok(Value::none()),
            }
        }
        BurnBlockInfoProperty::PoxAddrs => {
            let pox_addrs_and_payout = exec_state
                .global_context
                .database
                .get_pox_payout_addrs_for_burnchain_height(height_value)?;

            match pox_addrs_and_payout {
                Some((addrs, payout)) => Ok(Value::some(Value::Tuple(
                    TupleData::from_data(vec![
                        (
                            ClarityName::from_literal("addrs"),
                            Value::cons_list(
                                addrs.into_iter().map(Value::Tuple).collect(),
                                exec_state.epoch(),
                            )
                            .map_err(|_| {
                                VmInternalError::Expect(
                                    "FATAL: could not convert address list to Value".into(),
                                )
                            })?,
                        ),
                        (ClarityName::from_literal("payout"), Value::UInt(payout)),
                    ])
                    .map_err(|_| {
                        VmInternalError::Expect(
                            "FATAL: failed to build pox addrs and payout tuple".into(),
                        )
                    })?,
                ))
                .map_err(|_| VmInternalError::Expect("FATAL: could not build Some(..)".into()))?),
                None => Ok(Value::none()),
            }
        }
    }
}

/// Handles the `get-stacks-block-info?` special function.
/// Interprets `args` as variables `[property-name, block-height]`, and returns
/// a property value determined by `property-name`:
/// - `id-header-hash` returns the index block hash at `block-height`
/// - `header-hash` returns the header hash at `block-height`
/// - `time` returns the block time at `block-height`
///
/// # Errors:
/// - [`RuntimeCheckErrorKind::IncorrectArgumentCount`] if there aren't 2 arguments.
/// - [`RuntimeCheckErrorKind::Unreachable`] if `args[0]` isn't a ClarityName and a [`StacksBlockInfoProperty`].
/// - [`RuntimeCheckErrorKind::TypeValueError`] if `args[1]` doesn't evaluate to a `uint`.
/// - [`RuntimeCheckErrorKind`] cost errors (e.g., `CostOverflow`, `CostBalanceExceeded`) from [`runtime_cost`].
/// - [`VmExecutionError`] propagated from [`eval`] when evaluating `args[1]`.
/// - [`VmInternalError`] from database operations when retrieving block information.
pub fn special_get_stacks_block_info(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    // (get-stacks-block-info? property-name block-height-uint)
    runtime_cost(ClarityCostFunction::BlockInfo, exec_state, 0)?;

    check_argument_count(2, args)?;

    // Handle the block property name input arg.
    let property_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable(
            "Get stacks block info expect property name".into(),
        ))?;

    let block_info_prop = StacksBlockInfoProperty::lookup_by_name(property_name).ok_or(
        RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "No such stacks block info property: {property_name}"
        )),
    )?;

    // Handle the block-height input arg.
    let height_eval = eval(&args[1], exec_state, invoke_ctx, context)?;
    let height_value = match height_eval.as_ref() {
        Value::UInt(result) => Ok(*result),
        _ => Err(RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::UIntType),
            height_eval.as_ref().to_error_string(),
        )),
    }?;

    let Ok(height_value) = u32::try_from(height_value) else {
        return Ok(Value::none());
    };

    let current_block_height = exec_state
        .global_context
        .database
        .get_current_block_height();
    if height_value >= current_block_height {
        return Ok(Value::none());
    }

    let result = match block_info_prop {
        StacksBlockInfoProperty::Time => {
            let block_time = exec_state
                .global_context
                .database
                .get_block_time(height_value)?;
            Value::UInt(u128::from(block_time))
        }
        StacksBlockInfoProperty::HeaderHash => {
            let header_hash = exec_state
                .global_context
                .database
                .get_block_header_hash(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: header_hash.as_bytes().to_vec(),
            }))
        }
        StacksBlockInfoProperty::IndexHeaderHash => {
            let id_header_hash = exec_state
                .global_context
                .database
                .get_index_block_header_hash(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: id_header_hash.as_bytes().to_vec(),
            }))
        }
    };

    Ok(Value::some(result)?)
}

/// Handles the `get-tenure-info?` special function.
/// Interprets `args` as variables `[property-name, block-height]`, and returns
/// a property value determined by `property-name`:
/// - `time` returns the burn block time for the tenure of which `block-height` is a part
/// - `vrf-seed` returns the VRF seed for the tenure of which `block-height` is a part
/// - `burnchain-header-hash` returns header hash of the burnchain block corresponding to the tenure of which `block-height` is a part
/// - `miner-address` returns the address of the principal that mined the tenure of which `block-height` is a part
/// - `miner-spend-winner` returns the number of satoshis spent by the winning miner for the tenure of which `block-height` is a part
/// - `miner-spend-total` returns the total number of satoshis spent by all miners for the tenure of which `block-height` is a part
/// - `block-reward` returns the block reward for the tenure of which `block-height` is a part
///
/// # Errors:
/// - [`RuntimeCheckErrorKind::IncorrectArgumentCount`] if there aren't 2 arguments.
/// - [`RuntimeCheckErrorKind::GetTenureInfoExpectPropertyName`] if `args[0]` isn't a ClarityName or isn't a valid [`TenureInfoProperty`].
/// - [`RuntimeCheckErrorKind::TypeValueError`] if `args[1]` doesn't evaluate to a `uint`.
/// - [`RuntimeCheckErrorKind`] cost errors (e.g., `CostOverflow`, `CostBalanceExceeded`) from [`runtime_cost`].
/// - [`VmExecutionError`] propagated from [`eval`] when evaluating `args[1]`.
/// - [`VmInternalError`] from database operations when retrieving tenure information.
pub fn special_get_tenure_info(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    // (get-tenure-info? property-name block-height-uint)
    runtime_cost(ClarityCostFunction::BlockInfo, exec_state, 0)?;

    check_argument_count(2, args)?;

    // Handle the block property name input arg.
    let property_name = args[0]
        .match_atom()
        .ok_or(RuntimeCheckErrorKind::Unreachable(
            "Get tenure info expect property name".into(),
        ))?;

    let block_info_prop = TenureInfoProperty::lookup_by_name(property_name).ok_or(
        RuntimeCheckErrorKind::Unreachable("Get tenure info expect property name".into()),
    )?;

    // Handle the block-height input arg.
    let height_eval = eval(&args[1], exec_state, invoke_ctx, context)?;
    let height_value = match height_eval.as_ref() {
        Value::UInt(result) => Ok(*result),
        _ => Err(RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::UIntType),
            height_eval.as_ref().to_error_string(),
        )),
    }?;

    let Ok(height_value) = u32::try_from(height_value) else {
        return Ok(Value::none());
    };

    let current_height = exec_state
        .global_context
        .database
        .get_current_block_height();
    if height_value >= current_height {
        return Ok(Value::none());
    }

    let result = match block_info_prop {
        TenureInfoProperty::Time => {
            let block_time = exec_state
                .global_context
                .database
                .get_burn_block_time(height_value, None)?;
            Value::UInt(u128::from(block_time))
        }
        TenureInfoProperty::VrfSeed => {
            let vrf_seed = exec_state
                .global_context
                .database
                .get_block_vrf_seed(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: vrf_seed.as_bytes().to_vec(),
            }))
        }
        TenureInfoProperty::BurnchainHeaderHash => {
            let burnchain_header_hash = exec_state
                .global_context
                .database
                .get_burnchain_block_header_hash(height_value)?;
            Value::Sequence(SequenceData::Buffer(BuffData {
                data: burnchain_header_hash.as_bytes().to_vec(),
            }))
        }
        TenureInfoProperty::MinerAddress => {
            let miner_address = exec_state
                .global_context
                .database
                .get_miner_address(height_value)?;
            Value::from(miner_address)
        }
        TenureInfoProperty::MinerSpendWinner => {
            let winner_spend = exec_state
                .global_context
                .database
                .get_miner_spend_winner(height_value)?;
            Value::UInt(winner_spend)
        }
        TenureInfoProperty::MinerSpendTotal => {
            let total_spend = exec_state
                .global_context
                .database
                .get_miner_spend_total(height_value)?;
            Value::UInt(total_spend)
        }
        TenureInfoProperty::BlockReward => {
            // this is already an optional
            let block_reward_opt = exec_state
                .global_context
                .database
                .get_block_reward(height_value)?;
            return Ok(match block_reward_opt {
                Some(x) => Value::some(Value::UInt(x))?,
                None => Value::none(),
            });
        }
    };

    Ok(Value::some(result)?)
}

/// Handles the function `contract-hash?`
pub fn special_contract_hash(
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    check_argument_count(1, args)?;
    let contract_expr = args
        .first()
        .ok_or(RuntimeCheckErrorKind::IncorrectArgumentCount(1, 0))?;
    let contract_value = eval(contract_expr, exec_state, invoke_ctx, context)?;
    let contract_identifier = match contract_value.as_ref() {
        Value::Principal(PrincipalData::Standard(_)) => {
            // If the value is a standard principal, we return `(err u1)`.
            return Ok(Value::err_uint(1));
        }
        Value::Principal(PrincipalData::Contract(contract_identifier)) => contract_identifier,
        _ => {
            // If the value is not a principal, we return a RuntimeCheckErrorKind.
            return Err(RuntimeCheckErrorKind::ExpectedContractPrincipalValue(
                contract_value.as_ref().to_error_string(),
            )
            .into());
        }
    };

    runtime_cost(ClarityCostFunction::ContractHash, exec_state, 0)?;

    let Some(contract_hash) = exec_state
        .global_context
        .database
        .get_contract_hash(contract_identifier)?
    else {
        // If the contract does not exist, we return `(err u2)`.
        return Ok(Value::err_uint(2));
    };

    Ok(Value::okay(Value::buff_from(
        contract_hash.as_bytes().to_vec(),
    )?)?)
}
