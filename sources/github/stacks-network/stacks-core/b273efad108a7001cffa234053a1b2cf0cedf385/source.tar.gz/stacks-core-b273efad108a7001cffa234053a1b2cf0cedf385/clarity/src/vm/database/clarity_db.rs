// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use stacks_common::bounded_format;
use stacks_common::consts::{
    BITCOIN_REGTEST_FIRST_BLOCK_HASH, BITCOIN_REGTEST_FIRST_BLOCK_HEIGHT,
    BITCOIN_REGTEST_FIRST_BLOCK_TIMESTAMP, FIRST_BURNCHAIN_CONSENSUS_HASH, FIRST_STACKS_BLOCK_HASH,
    MINER_REWARD_MATURITY,
};
use stacks_common::types::chainstate::{
    BlockHeaderHash, BurnchainHeaderHash, ConsensusHash, SortitionId, StacksAddress, StacksBlockId,
    TrieHash, VRFSeed,
};
use stacks_common::types::{StacksEpoch as GenericStacksEpoch, StacksEpochId};
use stacks_common::util::hash::{Hash160, Sha512Trunc256Sum, to_hex};

use super::clarity_store::SpecialCaseHandler;
use super::key_value_wrapper::ValueResult;
use crate::vm::analysis::{AnalysisDatabase, ContractAnalysis};
use crate::vm::contexts::ContractContext;
use crate::vm::contracts::Contract;
use crate::vm::costs::{CostOverflowingMath, ExecutionCost};
use crate::vm::database::caching::{CachedContract, ClarityExecutionCache};
use crate::vm::database::structures::{
    ClarityDeserializable, ClaritySerializable, DataMapMetadata, DataVariableMetadata,
    FungibleTokenMetadata, NonFungibleTokenMetadata, STXBalance, STXBalanceSnapshot,
};
use crate::vm::database::{ClarityBackingStore, RollbackWrapper};
use crate::vm::errors::{RuntimeCheckErrorKind, RuntimeError, VmExecutionError, VmInternalError};
use crate::vm::representations::ClarityName;
use crate::vm::types::serialization::NONE_SERIALIZATION_LEN;
use crate::vm::types::{
    PrincipalData, QualifiedContractIdentifier, StandardPrincipalData, TupleData, TypeSignature,
    Value, byte_len_of_serialization,
};

pub const STORE_CONTRACT_SRC_INTERFACE: bool = true;
pub const TENURE_HEIGHT_KEY: &str = "_stx-data::tenure_height";
pub const CLARITY_STORAGE_BLOCK_TIME_KEY: &str = "_stx-data::clarity_storage::block_time";

pub type StacksEpoch = GenericStacksEpoch<ExecutionCost>;

#[derive(Debug, Clone, Copy)]
#[repr(u8)]
pub enum StoreType {
    DataMap = 0x00,
    Variable = 0x01,
    FungibleToken = 0x02,
    CirculatingSupply = 0x03,
    NonFungibleToken = 0x04,
    DataMapMeta = 0x05,
    VariableMeta = 0x06,
    FungibleTokenMeta = 0x07,
    NonFungibleTokenMeta = 0x08,
    Contract = 0x09,
    SimmedBlock = 0x10,
    SimmedBlockHeight = 0x11,
    Nonce = 0x12,
    STXBalance = 0x13,
    PoxSTXLockup = 0x14,
    PoxUnlockHeight = 0x15,
}

impl TryFrom<&str> for StoreType {
    type Error = String;

    fn try_from(value: &str) -> core::result::Result<Self, Self::Error> {
        use self::StoreType::*;

        let hex_value = value.parse::<u8>().map_err(|e| e.to_string())?;
        match hex_value {
            0x00 => Ok(DataMap),
            0x01 => Ok(Variable),
            0x02 => Ok(FungibleToken),
            0x03 => Ok(CirculatingSupply),
            0x04 => Ok(NonFungibleToken),
            0x05 => Ok(DataMapMeta),
            0x06 => Ok(VariableMeta),
            0x07 => Ok(FungibleTokenMeta),
            0x08 => Ok(NonFungibleTokenMeta),
            0x09 => Ok(Contract),
            0x10 => Ok(SimmedBlock),
            0x11 => Ok(SimmedBlockHeight),
            0x12 => Ok(Nonce),
            0x13 => Ok(STXBalance),
            0x14 => Ok(PoxSTXLockup),
            0x15 => Ok(PoxUnlockHeight),
            _ => Err("Invalid StoreType".into()),
        }
    }
}

pub enum ContractDataVarName {
    Contract,
    ContractSize,
    ContractSrc,
    ContractDataSize,
}

impl ContractDataVarName {
    pub fn as_str(&self) -> &str {
        match self {
            Self::Contract => "contract",
            Self::ContractSize => "contract-size",
            Self::ContractSrc => "contract-src",
            Self::ContractDataSize => "contract-data-size",
        }
    }

    pub fn metadata_key(&self) -> String {
        ClarityDatabase::make_metadata_key(StoreType::Contract, self.as_str())
    }
}

impl AsRef<str> for ContractDataVarName {
    fn as_ref(&self) -> &str {
        self.as_str()
    }
}

impl TryFrom<&str> for ContractDataVarName {
    type Error = String;

    fn try_from(value: &str) -> core::result::Result<Self, Self::Error> {
        use self::ContractDataVarName::*;
        match value {
            "contract" => Ok(Contract),
            "contract-size" => Ok(ContractSize),
            "contract-src" => Ok(ContractSrc),
            "contract-data-size" => Ok(ContractDataSize),
            _ => Err("Invalid ContractDataVarName".into()),
        }
    }
}

pub struct ClarityDatabase<'a> {
    pub store: RollbackWrapper<'a>,
    headers_db: &'a dyn HeadersDB,
    burn_state_db: &'a dyn BurnStateDB,
    /// Optional per-tx execution-cache container attached via [`Self::with_cache`].
    /// Exclusive borrow — the contained caches have no interior mutability, so the borrow
    /// checker enforces single-writer for the lifetime of this database.
    execution_cache: Option<&'a mut ClarityExecutionCache>,
}

pub trait HeadersDB {
    fn get_stacks_block_header_hash_for_block(
        &self,
        id_bhh: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<BlockHeaderHash>;
    fn get_burn_header_hash_for_block(&self, id_bhh: &StacksBlockId)
    -> Option<BurnchainHeaderHash>;
    fn get_consensus_hash_for_block(
        &self,
        id_bhh: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<ConsensusHash>;
    fn get_vrf_seed_for_block(
        &self,
        id_bhh: &StacksBlockId,
        tip: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<VRFSeed>;
    fn get_stacks_block_time_for_block(&self, id_bhh: &StacksBlockId) -> Option<u64>;
    fn get_burn_block_time_for_block(
        &self,
        id_bhh: &StacksBlockId,
        epoch: Option<&StacksEpochId>,
    ) -> Option<u64>;
    fn get_burn_block_height_for_block(&self, id_bhh: &StacksBlockId) -> Option<u32>;
    fn get_miner_address(
        &self,
        id_bhh: &StacksBlockId,
        tip: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<StacksAddress>;
    fn get_burnchain_tokens_spent_for_block(
        &self,
        id_bhh: &StacksBlockId,
        tip: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<u128>;
    fn get_burnchain_tokens_spent_for_winning_block(
        &self,
        id_bhh: &StacksBlockId,
        tip: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<u128>;
    fn get_tokens_earned_for_block(
        &self,
        id_bhh: &StacksBlockId,
        tip: &StacksBlockId,
        epoch: &StacksEpochId,
    ) -> Option<u128>;
    fn get_stacks_height_for_tenure_height(
        &self,
        tip: &StacksBlockId,
        tenure_height: u32,
    ) -> Option<u32>;
}

pub trait BurnStateDB {
    /// Get the burn chain height at the current tip.
    fn get_tip_burn_block_height(&self) -> Option<u32>;
    /// Get the sortition id for the current tip.
    fn get_tip_sortition_id(&self) -> Option<SortitionId>;

    fn get_v1_unlock_height(&self) -> u32;
    fn get_v2_unlock_height(&self) -> u32;
    fn get_v3_unlock_height(&self) -> u32;
    fn get_pox_3_activation_height(&self) -> u32;
    fn get_pox_4_activation_height(&self) -> u32;
    fn get_pox_5_activation_height(&self) -> u32;

    /// Returns the *burnchain block height* for the `sortition_id` is associated with.
    fn get_burn_block_height(&self, sortition_id: &SortitionId) -> Option<u32>;

    /// Returns the height of the burnchain when the Stacks chain started running.
    fn get_burn_start_height(&self) -> u32;

    fn get_pox_prepare_length(&self) -> u32;
    fn get_pox_reward_cycle_length(&self) -> u32;
    fn get_pox_rejection_fraction(&self) -> u64;

    /// Returns the burnchain header hash for the given burn block height, as queried from the given SortitionId.
    ///
    /// Returns Some if `self.get_burn_start_height() <= height < self.get_burn_block_height(sorition_id)`, and None otherwise.
    fn get_burn_header_hash(
        &self,
        height: u32,
        sortition_id: &SortitionId,
    ) -> Option<BurnchainHeaderHash>;

    /// Lookup a `SortitionId` keyed to a `ConsensusHash`.
    ///
    /// Returns None if no block found.
    fn get_sortition_id_from_consensus_hash(
        &self,
        consensus_hash: &ConsensusHash,
    ) -> Option<SortitionId>;

    /// The epoch is defined as by a start and end height. This returns
    /// the epoch enclosing `height`.
    fn get_stacks_epoch(&self, height: u32) -> Option<StacksEpoch>;
    fn get_stacks_epoch_by_epoch_id(&self, epoch_id: &StacksEpochId) -> Option<StacksEpoch>;

    /// Get the PoX payout addresses for a given burnchain block
    fn get_pox_payout_addrs(
        &self,
        height: u32,
        sortition_id: &SortitionId,
    ) -> Option<(Vec<TupleData>, u128)>;
}

pub struct NullHeadersDB {}
pub struct NullBurnStateDB {
    epoch: StacksEpochId,
}

pub const NULL_HEADER_DB: NullHeadersDB = NullHeadersDB {};
pub const NULL_BURN_STATE_DB: NullBurnStateDB = NullBurnStateDB {
    epoch: StacksEpochId::Epoch20,
};

impl HeadersDB for NullHeadersDB {
    fn get_burn_header_hash_for_block(
        &self,
        id_bhh: &StacksBlockId,
    ) -> Option<BurnchainHeaderHash> {
        if *id_bhh == StacksBlockId::new(&FIRST_BURNCHAIN_CONSENSUS_HASH, &FIRST_STACKS_BLOCK_HASH)
        {
            #[allow(clippy::unwrap_used)]
            let first_block_hash =
                BurnchainHeaderHash::from_hex(BITCOIN_REGTEST_FIRST_BLOCK_HASH).unwrap();
            Some(first_block_hash)
        } else {
            None
        }
    }
    fn get_vrf_seed_for_block(
        &self,
        _bhh: &StacksBlockId,
        _tip: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<VRFSeed> {
        None
    }
    fn get_stacks_block_header_hash_for_block(
        &self,
        id_bhh: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<BlockHeaderHash> {
        if *id_bhh == StacksBlockId::new(&FIRST_BURNCHAIN_CONSENSUS_HASH, &FIRST_STACKS_BLOCK_HASH)
        {
            Some(FIRST_STACKS_BLOCK_HASH)
        } else {
            None
        }
    }
    fn get_consensus_hash_for_block(
        &self,
        _id_bhh: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<ConsensusHash> {
        None
    }
    fn get_burn_block_time_for_block(
        &self,
        id_bhh: &StacksBlockId,
        _epoch: Option<&StacksEpochId>,
    ) -> Option<u64> {
        if *id_bhh == StacksBlockId::new(&FIRST_BURNCHAIN_CONSENSUS_HASH, &FIRST_STACKS_BLOCK_HASH)
        {
            Some(BITCOIN_REGTEST_FIRST_BLOCK_TIMESTAMP as u64)
        } else {
            None
        }
    }
    fn get_stacks_block_time_for_block(&self, _id_bhh: &StacksBlockId) -> Option<u64> {
        None
    }
    fn get_burn_block_height_for_block(&self, id_bhh: &StacksBlockId) -> Option<u32> {
        if *id_bhh == StacksBlockId::new(&FIRST_BURNCHAIN_CONSENSUS_HASH, &FIRST_STACKS_BLOCK_HASH)
        {
            Some(BITCOIN_REGTEST_FIRST_BLOCK_HEIGHT as u32)
        } else {
            Some(1)
        }
    }
    fn get_miner_address(
        &self,
        _id_bhh: &StacksBlockId,
        _tip: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<StacksAddress> {
        None
    }
    fn get_burnchain_tokens_spent_for_block(
        &self,
        _id_bhh: &StacksBlockId,
        _tip: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<u128> {
        None
    }
    fn get_burnchain_tokens_spent_for_winning_block(
        &self,
        _id_bhh: &StacksBlockId,
        _tip: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<u128> {
        None
    }
    fn get_tokens_earned_for_block(
        &self,
        _id_bhh: &StacksBlockId,
        _tip: &StacksBlockId,
        _epoch: &StacksEpochId,
    ) -> Option<u128> {
        None
    }
    fn get_stacks_height_for_tenure_height(
        &self,
        _tip: &StacksBlockId,
        _tenure_height: u32,
    ) -> Option<u32> {
        None
    }
}

#[allow(clippy::panic)]
impl BurnStateDB for NullBurnStateDB {
    fn get_tip_burn_block_height(&self) -> Option<u32> {
        Some(0)
    }

    fn get_tip_sortition_id(&self) -> Option<SortitionId> {
        None
    }

    fn get_burn_block_height(&self, _sortition_id: &SortitionId) -> Option<u32> {
        None
    }

    fn get_burn_start_height(&self) -> u32 {
        0
    }

    fn get_sortition_id_from_consensus_hash(
        &self,
        _consensus_hash: &ConsensusHash,
    ) -> Option<SortitionId> {
        None
    }

    fn get_burn_header_hash(
        &self,
        _height: u32,
        _sortition_id: &SortitionId,
    ) -> Option<BurnchainHeaderHash> {
        None
    }

    fn get_stacks_epoch(&self, _height: u32) -> Option<StacksEpoch> {
        Some(StacksEpoch {
            epoch_id: self.epoch,
            start_height: 0,
            end_height: u64::MAX,
            block_limit: ExecutionCost::max_value(),
            network_epoch: 0,
        })
    }
    fn get_stacks_epoch_by_epoch_id(&self, _epoch_id: &StacksEpochId) -> Option<StacksEpoch> {
        self.get_stacks_epoch(0)
    }

    fn get_v1_unlock_height(&self) -> u32 {
        u32::MAX
    }

    fn get_v2_unlock_height(&self) -> u32 {
        u32::MAX
    }

    fn get_v3_unlock_height(&self) -> u32 {
        u32::MAX
    }

    fn get_pox_3_activation_height(&self) -> u32 {
        u32::MAX
    }

    fn get_pox_4_activation_height(&self) -> u32 {
        u32::MAX
    }

    fn get_pox_5_activation_height(&self) -> u32 {
        u32::MAX
    }

    fn get_pox_prepare_length(&self) -> u32 {
        panic!("NullBurnStateDB should not return PoX info");
    }

    fn get_pox_reward_cycle_length(&self) -> u32 {
        panic!("NullBurnStateDB should not return PoX info");
    }

    fn get_pox_rejection_fraction(&self) -> u64 {
        panic!("NullBurnStateDB should not return PoX info");
    }
    fn get_pox_payout_addrs(
        &self,
        _height: u32,
        _sortition_id: &SortitionId,
    ) -> Option<(Vec<TupleData>, u128)> {
        None
    }
}

impl<'a> ClarityDatabase<'a> {
    pub fn new(
        store: &'a mut dyn ClarityBackingStore,
        headers_db: &'a dyn HeadersDB,
        burn_state_db: &'a dyn BurnStateDB,
    ) -> ClarityDatabase<'a> {
        ClarityDatabase {
            store: RollbackWrapper::new(store),
            headers_db,
            burn_state_db,
            execution_cache: None,
        }
    }

    pub fn new_with_rollback_wrapper(
        store: RollbackWrapper<'a>,
        headers_db: &'a dyn HeadersDB,
        burn_state_db: &'a dyn BurnStateDB,
    ) -> ClarityDatabase<'a> {
        ClarityDatabase {
            store,
            headers_db,
            burn_state_db,
            execution_cache: None,
        }
    }

    /// Attach a [`ClarityExecutionCache`] to this instance for the duration of its lifetime.
    pub fn with_cache(mut self, cache: &'a mut ClarityExecutionCache) -> Self {
        self.execution_cache = Some(cache);
        self
    }

    pub fn initialize(&mut self) {}

    pub fn is_stack_empty(&self) -> bool {
        self.store.depth() == 0
    }

    /// Nest the key-value wrapper instance
    pub fn begin(&mut self) {
        self.store.nest();
    }

    /// Commit current key-value wrapper layer
    pub fn commit(&mut self) -> Result<(), VmExecutionError> {
        self.store.commit().map_err(|e| e.into())
    }

    /// Drop current key-value wrapper layer
    pub fn roll_back(&mut self) -> Result<(), VmExecutionError> {
        self.store.rollback().map_err(|e| e.into())
    }

    pub fn set_block_hash(
        &mut self,
        bhh: StacksBlockId,
        query_pending_data: bool,
    ) -> Result<StacksBlockId, VmExecutionError> {
        self.store.set_block_hash(bhh, query_pending_data)
    }

    pub fn put_data<T: ClaritySerializable>(
        &mut self,
        key: &str,
        value: &T,
    ) -> Result<(), VmExecutionError> {
        self.store.put_data(key, &value.serialize())
    }

    /// Like `put()`, but returns the serialized byte size of the stored value
    pub fn put_data_with_size<T: ClaritySerializable>(
        &mut self,
        key: &str,
        value: &T,
    ) -> Result<u64, VmExecutionError> {
        let serialized = value.serialize();
        self.store.put_data(key, &serialized)?;
        Ok(byte_len_of_serialization(&serialized))
    }

    pub fn get_data<T>(&mut self, key: &str) -> Result<Option<T>, VmExecutionError>
    where
        T: ClarityDeserializable<T>,
    {
        self.store.get_data::<T>(key)
    }

    pub fn get_data_by_hash<T>(&mut self, hash: &TrieHash) -> Result<Option<T>, VmExecutionError>
    where
        T: ClarityDeserializable<T>,
    {
        self.store.get_data_by_hash::<T>(hash)
    }

    pub fn put_value(
        &mut self,
        key: &str,
        value: Value,
        epoch: &StacksEpochId,
    ) -> Result<(), VmExecutionError> {
        self.put_value_with_size(key, value, epoch)?;
        Ok(())
    }

    pub fn put_value_with_size(
        &mut self,
        key: &str,
        value: Value,
        epoch: &StacksEpochId,
    ) -> Result<u64, VmExecutionError> {
        let sanitize = epoch.value_sanitizing();
        let mut pre_sanitized_size = None;

        let serialized = if sanitize {
            let value_size = value
                .serialized_size()
                .map_err(|e| VmInternalError::Expect(e.to_string()))?
                as u64;

            let (sanitized_value, did_sanitize) =
                Value::sanitize_value(epoch, &TypeSignature::type_of(&value)?, value)
                    .ok_or(RuntimeCheckErrorKind::CouldNotDetermineType)?;
            // if data needed to be sanitized *charge* for the unsanitized cost
            if did_sanitize {
                pre_sanitized_size = Some(value_size);
            }
            sanitized_value
                .serialize_to_vec()
                .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?
        } else {
            value
                .serialize_to_vec()
                .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?
        };

        let size = serialized.len() as u64;
        let hex_serialized = to_hex(serialized.as_slice());
        self.store.put_data(key, &hex_serialized)?;

        Ok(pre_sanitized_size.unwrap_or(size))
    }

    pub fn get_value(
        &mut self,
        key: &str,
        expected: &TypeSignature,
        epoch: &StacksEpochId,
    ) -> Result<Option<ValueResult>, VmExecutionError> {
        self.store
            .get_value(key, expected, epoch)
            .map_err(|e| VmInternalError::DBError(e.to_string()).into())
    }

    pub fn get_data_with_proof<T>(
        &mut self,
        key: &str,
    ) -> Result<Option<(T, Vec<u8>)>, VmExecutionError>
    where
        T: ClarityDeserializable<T>,
    {
        self.store.get_data_with_proof(key)
    }

    pub fn get_data_with_proof_by_hash<T>(
        &mut self,
        hash: &TrieHash,
    ) -> Result<Option<(T, Vec<u8>)>, VmExecutionError>
    where
        T: ClarityDeserializable<T>,
    {
        self.store.get_data_with_proof_by_hash(hash)
    }

    pub fn make_key_for_trip(
        contract_identifier: &QualifiedContractIdentifier,
        data: StoreType,
        var_name: &str,
    ) -> String {
        format!("vm::{contract_identifier}::{}::{var_name}", data as u8)
    }

    pub fn make_metadata_key(data: StoreType, var_name: &str) -> String {
        format!("vm-metadata::{}::{var_name}", data as u8)
    }

    fn clarity_state_epoch_key() -> &'static str {
        "vm-epoch::epoch-version"
    }

    pub fn make_key_for_quad(
        contract_identifier: &QualifiedContractIdentifier,
        data: StoreType,
        var_name: &str,
        key_value: &str,
    ) -> String {
        format!(
            "vm::{contract_identifier}::{}::{var_name}::{key_value}",
            data as u8
        )
    }

    pub fn insert_contract_hash(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        contract_content: &str,
    ) -> Result<(), VmExecutionError> {
        let hash = Sha512Trunc256Sum::from_data(contract_content.as_bytes());
        self.store
            .prepare_for_contract_metadata(contract_identifier, hash)?;
        // insert contract-size
        let key = ClarityDatabase::make_metadata_key(
            StoreType::Contract,
            ContractDataVarName::ContractSize.as_str(),
        );
        self.insert_metadata(contract_identifier, &key, &(contract_content.len() as u64))?;

        // insert contract-src
        if STORE_CONTRACT_SRC_INTERFACE {
            let key = ClarityDatabase::make_metadata_key(
                StoreType::Contract,
                ContractDataVarName::ContractSrc.as_str(),
            );
            self.insert_metadata(contract_identifier, &key, &contract_content.to_string())?;
        }
        Ok(())
    }

    pub fn get_contract_src(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Option<String> {
        let key = ClarityDatabase::make_metadata_key(
            StoreType::Contract,
            ContractDataVarName::ContractSrc.as_str(),
        );
        self.fetch_metadata(contract_identifier, &key)
            .ok()
            .flatten()
    }

    pub fn get_contract_hash(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Result<Option<Sha512Trunc256Sum>, VmExecutionError> {
        self.store.get_contract_hash(contract_identifier)
    }

    pub fn set_metadata(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        key: &str,
        data: &str,
    ) -> Result<(), VmExecutionError> {
        self.store
            .insert_metadata(contract_identifier, key, data)
            .map_err(|e| e.into())
    }

    fn insert_metadata<T: ClaritySerializable>(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        key: &str,
        data: &T,
    ) -> Result<(), VmExecutionError> {
        if self.store.has_metadata_entry(contract_identifier, key) {
            Err(VmInternalError::Expect(format!(
                "Metadata entry '{key}' already exists for contract: {contract_identifier}"
            ))
            .into())
        } else {
            self.store
                .insert_metadata(contract_identifier, key, &data.serialize())
                .map_err(|e| e.into())
        }
    }

    fn fetch_metadata<T>(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        key: &str,
    ) -> Result<Option<T>, VmExecutionError>
    where
        T: ClarityDeserializable<T>,
    {
        let x_opt = self.store.get_metadata(contract_identifier, key)?;
        match x_opt {
            None => Ok(None),
            Some(x) => T::deserialize(&x).map(|out| Some(out)),
        }
    }

    pub fn fetch_metadata_manual<T>(
        &mut self,
        at_height: u32,
        contract_identifier: &QualifiedContractIdentifier,
        key: &str,
    ) -> Result<Option<T>, VmExecutionError>
    where
        T: ClarityDeserializable<T>,
    {
        let x_opt = self
            .store
            .get_metadata_manual(at_height, contract_identifier, key)?;
        match x_opt {
            None => Ok(None),
            Some(x) => T::deserialize(&x).map(|out| Some(out)),
        }
    }

    // load contract analysis stored by an analysis_db instance.
    //   in unit testing, where the interpreter is invoked without
    //   an analysis pass, this function will fail to find contract
    //   analysis data
    pub fn load_contract_analysis(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Result<Option<ContractAnalysis>, VmExecutionError> {
        self.store
            .get_metadata(contract_identifier, AnalysisDatabase::storage_key())
            // treat NoSuchContract error thrown by get_metadata as an Option::None --
            //    the analysis will propagate that as a StaticCheckError anyways.
            .ok()
            .flatten()
            .map(|x| ContractAnalysis::deserialize(&x))
            .transpose()
    }

    /// Read and sum the `contract-size` and `contract-data-size` metadata entries for the given
    /// contract, returning the total size for the contract as needed for `LoadContract` cost
    /// calculations.
    ///
    /// Reads through the rollback-aware metadata layer; does not consult or populate the cache.
    fn read_contract_size(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Result<u64, VmExecutionError> {
        let contract_size_key = ContractDataVarName::ContractSize.metadata_key();
        let contract_size: u64 = self
            .fetch_metadata(contract_identifier, &contract_size_key)?
            .ok_or_else(|| {
                VmInternalError::Expect(
            "Failed to read non-consensus contract metadata, even though contract exists in MARF."
        .into())
            })?;

        let data_size_key = ContractDataVarName::ContractDataSize.metadata_key();
        let data_size: u64 = self
            .fetch_metadata(contract_identifier, &data_size_key)?
            .ok_or_else(|| {
                VmInternalError::Expect(
            "Failed to read non-consensus contract metadata, even though contract exists in MARF."
        .into())
            })?;

        // u64 overflow is _checked_ on insert into contract-data-size
        Ok(data_size + contract_size)
    }

    /// `LoadContract` cost size (`contract_size + data_size`).
    ///
    /// When a cache is attached to this instance and the store isn't retargeted by e.g. `at-block`,
    /// this method attempts to serve values via a passive cache lookup. Cache hits do not update
    /// FIFO counters, and misses fall through to reading from the backing store.
    pub fn get_contract_size(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Result<u64, VmExecutionError> {
        if !self.store.is_retargeted()
            && let Some(cached) = self.peek_cached_contract(contract_identifier)
        {
            return Ok(cached.load_cost_size);
        }

        self.read_contract_size(contract_identifier)
    }

    /// used for adding the memory usage of `define-constant` variables.
    pub fn set_contract_data_size(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        data_size: u64,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_metadata_key(
            StoreType::Contract,
            ContractDataVarName::ContractSize.as_str(),
        );
        let contract_size: u64 =
            self.fetch_metadata(contract_identifier, &key)?
                .ok_or_else(|| {
                    VmInternalError::Expect(
            "Failed to read non-consensus contract metadata, even though contract exists in MARF."
        .into())
                })?;
        contract_size.cost_overflow_add(data_size)?;

        let key = ClarityDatabase::make_metadata_key(
            StoreType::Contract,
            ContractDataVarName::ContractDataSize.as_str(),
        );
        self.insert_metadata(contract_identifier, &key, &data_size)?;
        Ok(())
    }

    pub fn insert_contract(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        contract: Contract,
    ) -> Result<(), VmExecutionError> {
        let key = ContractDataVarName::Contract.metadata_key();

        self.insert_metadata(contract_identifier, &key, &*contract)?;
        Ok(())
    }

    pub fn has_contract(&mut self, contract_identifier: &QualifiedContractIdentifier) -> bool {
        let key = ClarityDatabase::make_metadata_key(
            StoreType::Contract,
            ContractDataVarName::Contract.as_str(),
        );
        self.store.has_metadata_entry(contract_identifier, &key)
    }

    /// Read and deserialize the contract blob from the backing store, canonicalizing its types to
    /// the current epoch.
    ///
    /// Reads through the rollback-aware metadata layer; does not consult or populate the contract
    /// cache.
    fn read_contract(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Result<Contract, VmExecutionError> {
        let contract_key = ContractDataVarName::Contract.metadata_key();
        let mut contract_context = self
            .fetch_metadata::<ContractContext>(contract_identifier, &contract_key)?
            .ok_or_else(|| {
                VmInternalError::Expect(
            "Failed to read non-consensus contract metadata, even though contract exists in MARF."
            .into())
            })?;

        let epoch = self.get_clarity_epoch_version()?;
        contract_context.canonicalize_types(&epoch)?;

        Ok(contract_context.into())
    }

    /// Check for any pending metadata writes to the metadata keys used for loading/materializing a
    /// [`Contract`] from the backing store and calculating its `LoadContract` costs.
    ///
    /// This is used for defensive checks in e.g. [`Self::get_contract`].
    fn has_pending_metadata_for_contract(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> bool {
        let contract_key = ContractDataVarName::Contract.metadata_key();
        let size_key = ContractDataVarName::ContractSize.metadata_key();
        let data_size_key = ContractDataVarName::ContractDataSize.metadata_key();

        self.store.has_pending_metadata(
            contract_identifier,
            &[&contract_key, &size_key, &data_size_key],
        )
    }

    /// Load a parsed contract, returning a canonicalized [`Contract`].
    ///
    /// Consults the attached cache when attached and the store is not retargeted; on a miss the
    /// contract is read from the backing store and inserted into the cache before being returned.
    ///
    /// The cache is bypassed entirely during `(at-block ...)` retargeting; those reads hit the
    /// backing store and are not cached, since they reflect a different chainstate view.
    ///
    /// Reads served from uncommitted pending metadata (e.g. a contract deployed earlier in the same
    /// rollback layer but not yet committed to the backing store) are not cached.
    pub fn get_contract(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
    ) -> Result<Contract, VmExecutionError> {
        let retargeted = self.store.is_retargeted();

        // Attempt to serve from cache ONLY if we are reading at chain tip (not retargeted).
        if !retargeted && let Some(entry) = self.cached_contract(contract_identifier) {
            return Ok(entry.contract.clone());
        }

        // Miss path: read from store, then (when applicable) populate the cache.
        let contract = self.read_contract(contract_identifier)?;

        // Defensive check: this is not expected on the ordinary contract-call path, but we include
        // it conservatively as this is a lower-level DB API which can be reached while a rollback
        // layer contains pending metadata (e.g., if the cache were ever reused across transaction
        // boundaries).
        let is_pending = self.has_pending_metadata_for_contract(contract_identifier);

        // Only populate the cache on reads at tip and when there are no pending writes to relevant
        // metadata keys.
        if !retargeted && !is_pending {
            let load_cost_size = self.read_contract_size(contract_identifier)?;

            self.cache_contract(
                contract_identifier.clone(),
                CachedContract {
                    contract: contract.clone(),
                    load_cost_size,
                },
            );
        }

        Ok(contract)
    }

    /// Borrow the cached contract entry for the provided [`QualifiedContractIdentifier`] if a cache
    /// is attached to this [`ClarityDatabase`] instance and the contract cache contains it.
    ///
    /// On cache hit, hit/miss counters are updated, but FIFO ordering is unchanged.
    ///
    /// Returns [`None`] if no cache is attached or the cache does not contain the entry.
    fn cached_contract(&mut self, id: &QualifiedContractIdentifier) -> Option<&CachedContract> {
        self.execution_cache.as_deref_mut()?.contracts.get(id)
    }

    /// Borrow the cached contract entry for the provided [`QualifiedContractIdentifier`] if a cache
    /// is attached to this [`ClarityDatabase`] instance, without altering FIFO counters.
    ///
    /// Returns [`None`] if no cache is attached or the cache does not contain the entry.
    fn peek_cached_contract(&self, id: &QualifiedContractIdentifier) -> Option<&CachedContract> {
        self.execution_cache.as_deref()?.contracts.peek(id)
    }

    /// Insert an entry into the cache if one is attached; otherwise this is a no-op.
    fn cache_contract(&mut self, id: QualifiedContractIdentifier, entry: CachedContract) {
        let weight = entry.load_cost_size;
        if let Some(cache) = self.execution_cache.as_deref_mut() {
            cache.contracts.insert(id, entry, weight);
        }
    }

    pub fn ustx_liquid_supply_key() -> &'static str {
        "_stx-data::ustx_liquid_supply"
    }

    /// Returns the epoch version currently applied in the stored Clarity state.
    /// Since Clarity did not exist in stacks 1.0, the lowest valid epoch ID is stacks 2.0.
    /// The instantiation of subsequent epochs may bump up the epoch version in the clarity DB if
    /// Clarity is updated in that epoch.
    pub fn get_clarity_epoch_version(&mut self) -> Result<StacksEpochId, VmExecutionError> {
        let out = match self.get_data(Self::clarity_state_epoch_key())? {
            Some(x) => u32::try_into(x).map_err(|_| {
                VmInternalError::Expect("Bad Clarity epoch version in stored Clarity state".into())
            })?,
            None => StacksEpochId::Epoch20,
        };
        Ok(out)
    }

    /// Should be called _after_ all of the epoch's initialization has been invoked
    pub fn set_clarity_epoch_version(
        &mut self,
        epoch: StacksEpochId,
    ) -> Result<(), VmExecutionError> {
        self.put_data(Self::clarity_state_epoch_key(), &(epoch as u32))
    }

    /// Setup block metadata at the beginning of a block
    /// This stores block-specific data that can be accessed during Clarity execution
    pub fn setup_block_metadata(
        &mut self,
        block_time: Option<u64>,
    ) -> Result<(), VmExecutionError> {
        let epoch = self.get_clarity_epoch_version()?;
        if epoch.uses_marfed_block_time() {
            let block_time = block_time.ok_or_else(|| {
                VmInternalError::Expect(
                    "FATAL: Marfed block time not provided to Clarity DB setup".into(),
                )
            })?;
            self.put_data(CLARITY_STORAGE_BLOCK_TIME_KEY, &block_time)?;
        }
        Ok(())
    }

    pub fn get_current_block_time(&mut self) -> Result<u64, VmExecutionError> {
        match self.get_data(CLARITY_STORAGE_BLOCK_TIME_KEY)? {
            Some(value) => Ok(value),
            None => Err(RuntimeError::BlockTimeNotAvailable.into()),
        }
    }

    /// Returns the _current_ total liquid ustx
    pub fn get_total_liquid_ustx(&mut self) -> Result<u128, VmExecutionError> {
        let epoch = self.get_clarity_epoch_version()?;
        Ok(self
            .get_value(
                ClarityDatabase::ustx_liquid_supply_key(),
                &TypeSignature::UIntType,
                &epoch,
            )
            .map_err(|_| {
                VmInternalError::Expect(
                    "FATAL: failed to load ustx_liquid_supply Clarity key".into(),
                )
            })?
            .map(|v| {
                v.value
                    .expect_u128()
                    .map_err(|_| VmInternalError::Expect("Expected u128".into()))
            })
            .transpose()?
            .unwrap_or(0))
    }

    fn set_ustx_liquid_supply(&mut self, set_to: u128) -> Result<(), VmExecutionError> {
        self.put_value(
            ClarityDatabase::ustx_liquid_supply_key(),
            Value::UInt(set_to),
            // okay to pin epoch, because ustx_liquid_supply does not need to sanitize
            &StacksEpochId::Epoch21,
        )
        .map_err(|_| {
            VmInternalError::Expect("FATAL: Failed to store STX liquid supply".into()).into()
        })
    }

    pub fn increment_ustx_liquid_supply(&mut self, incr_by: u128) -> Result<(), VmExecutionError> {
        let current = self.get_total_liquid_ustx()?;
        let next = current.checked_add(incr_by).ok_or_else(|| {
            error!("Overflowed `ustx-liquid-supply`");
            RuntimeError::ArithmeticOverflow
        })?;
        self.set_ustx_liquid_supply(next)?;
        Ok(())
    }

    pub fn decrement_ustx_liquid_supply(&mut self, decr_by: u128) -> Result<(), VmExecutionError> {
        let current = self.get_total_liquid_ustx()?;
        // This `ArithmeticUnderflow` is **unreachable** in normal Clarity execution.
        // The sender's balance is always checked first (`amount <= sender_balance`),
        // and `sender_balance <= current_supply` always holds.
        // Thus, `decr_by > current_supply` cannot occur.
        let next = current.checked_sub(decr_by).ok_or_else(|| {
            error!("`stx-burn?` accepted that reduces `ustx-liquid-supply` below 0");
            RuntimeError::ArithmeticUnderflow
        })?;
        self.set_ustx_liquid_supply(next)?;
        Ok(())
    }

    /// Returns the tenure height of the current block.
    pub fn get_tenure_height(&mut self) -> Result<u32, VmExecutionError> {
        if self.get_clarity_epoch_version()? < StacksEpochId::Epoch30 {
            // Before epoch 3.0, the tenure height was not stored in the
            // Clarity state. Instead, it was the same as the block height.
            return Ok(self.get_current_block_height());
        }

        self.get_data(TENURE_HEIGHT_KEY)?
            .ok_or_else(|| {
                VmInternalError::Expect("No tenure height in stored Clarity state".into()).into()
            })
            .and_then(|x| {
                u32::try_into(x).map_err(|_| {
                    VmInternalError::Expect("Bad tenure height in stored Clarity state".into())
                        .into()
                })
            })
    }

    /// Set the tenure height of the current block. In the first block of a new
    /// tenure, this height must be incremented before evaluating any
    /// transactions in the block.
    pub fn set_tenure_height(&mut self, height: u32) -> Result<(), VmExecutionError> {
        if self.get_clarity_epoch_version()? < StacksEpochId::Epoch30 {
            return Err(VmExecutionError::Internal(VmInternalError::Expect(
                "Setting tenure height in Clarity state is not supported before epoch 3.0".into(),
            )));
        }
        self.put_data(TENURE_HEIGHT_KEY, &height)
    }

    pub fn destroy(self) -> RollbackWrapper<'a> {
        self.store
    }

    pub fn is_in_regtest(&self) -> bool {
        cfg!(test)
    }
}

// Get block information

impl ClarityDatabase<'_> {
    /// Returns the ID of a *Stacks* block, by a *Stacks* block height.
    ///
    /// Fails if `block_height` >= the "currently" under construction Stacks block height.
    pub fn get_index_block_header_hash(
        &mut self,
        block_height: u32,
    ) -> Result<StacksBlockId, VmExecutionError> {
        self.store
            .get_block_header_hash(block_height)
            // the caller is responsible for ensuring that the block_height given
            //  is < current_block_height, so this should _always_ return a value.
            .ok_or_else(|| {
                VmInternalError::Expect(
                    "Block header hash must return for provided block height".into(),
                )
                .into()
            })
    }

    /// This is the height we are currently constructing. It comes from the MARF.
    pub fn get_current_block_height(&mut self) -> u32 {
        self.store.get_current_block_height()
    }

    /// The canonical evaluation tip (parent of the block being constructed), used to anchor
    /// immutable tenure-start reads (see `HeadersDB`) instead of a possibly-pruned historical block.
    fn eval_tip_block_id(&mut self) -> Result<StacksBlockId, VmExecutionError> {
        let current_height = self.get_current_block_height();
        self.get_index_block_header_hash(current_height.saturating_sub(1))
    }

    /// Return the height for PoX v1 -> v2 auto unlocks
    ///   from the burn state db
    pub fn get_v1_unlock_height(&self) -> u32 {
        self.burn_state_db.get_v1_unlock_height()
    }

    /// Return the height for PoX 3 activation from the burn state db
    pub fn get_pox_3_activation_height(&self) -> u32 {
        self.burn_state_db.get_pox_3_activation_height()
    }

    /// Return the height for PoX 4 activation from the burn state db
    pub fn get_pox_4_activation_height(&self) -> u32 {
        self.burn_state_db.get_pox_4_activation_height()
    }

    /// Return the height for PoX v2 -> v3 auto unlocks
    ///   from the burn state db
    pub fn get_v2_unlock_height(&mut self) -> Result<u32, VmExecutionError> {
        if self.get_clarity_epoch_version()? >= StacksEpochId::Epoch22 {
            Ok(self.burn_state_db.get_v2_unlock_height())
        } else {
            Ok(u32::MAX)
        }
    }

    /// Return the height for PoX v3 -> v4 auto unlocks
    ///   from the burn state db
    pub fn get_v3_unlock_height(&mut self) -> Result<u32, VmExecutionError> {
        if self.get_clarity_epoch_version()? >= StacksEpochId::Epoch25 {
            Ok(self.burn_state_db.get_v3_unlock_height())
        } else {
            Ok(u32::MAX)
        }
    }

    /// Return the height for PoX v4 -> v5 auto unlocks
    ///   from the burn state db
    pub fn get_v4_unlock_height(&mut self) -> Result<u32, VmExecutionError> {
        if self.get_clarity_epoch_version()? >= StacksEpochId::Epoch40 {
            Ok(self.burn_state_db.get_pox_5_activation_height())
        } else {
            Ok(u32::MAX)
        }
    }

    /// Return the block height for a given tenure height
    ///   if the block information is queryable for the tenure height.
    /// The block information for a given tenure height is queryable iff:
    ///  * `tenure_height` falls in 2.x, and `tenure_height` < `current_height`
    ///  * `tenure_height` falls in 3.x, and the first block of the tenure
    ///    at `tenure_height` has a stacks block height less than `current_height`
    ///
    /// If the block information isn't queryable, return `Ok(None)`
    pub fn get_block_height_for_tenure_height(
        &mut self,
        tenure_height: u32,
    ) -> Result<Option<u32>, VmExecutionError> {
        let current_tenure_height = self.get_tenure_height()?;
        if current_tenure_height < tenure_height {
            return Ok(None);
        }
        let current_height = self.get_current_block_height();
        if current_height <= tenure_height {
            return Ok(None);
        }
        // check if we're querying a 2.x block
        let id_bhh = self.get_index_block_header_hash(tenure_height)?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        if !epoch.uses_nakamoto_blocks() {
            return Ok(Some(tenure_height));
        }
        // query from the parent
        let query_tip = self.eval_tip_block_id()?;
        Ok(self
            .headers_db
            .get_stacks_height_for_tenure_height(&query_tip, tenure_height))
    }

    /// Get the last-known burnchain block height.
    /// Note that this is _not_ the burnchain height in which this block was mined!
    /// This is the burnchain block height of the parent of the Stacks block at the current Stacks
    /// block height (i.e. that returned by `get_index_block_header_hash` for
    /// `get_current_block_height`).
    pub fn get_current_burnchain_block_height(&mut self) -> Result<u32, VmExecutionError> {
        let cur_stacks_height = self.store.get_current_block_height();

        // Before epoch 3.0, we can only access the burn block associated with the last block
        if !self
            .get_clarity_epoch_version()?
            .clarity_uses_tip_burn_block()
        {
            if cur_stacks_height == 0 {
                return Ok(self.burn_state_db.get_burn_start_height());
            };
            // Safety note: normal subtraction is safe here, because we've already checked
            // that cur_stacks_height > 0.
            let last_mined_bhh = self.get_index_block_header_hash(cur_stacks_height - 1)?;

            self.get_burnchain_block_height(&last_mined_bhh)
                .ok_or_else(|| {
                    VmInternalError::Expect(format!(
                        "Block header hash '{last_mined_bhh}' must return for provided stacks block height {cur_stacks_height}"
                    ))
                    .into()
                })
        } else {
            // In epoch 3+, we can access the current burnchain block
            self.burn_state_db
                .get_tip_burn_block_height()
                .ok_or_else(|| {
                    VmInternalError::Expect("Failed to get burnchain tip height.".into()).into()
                })
        }
    }

    pub fn get_block_header_hash(
        &mut self,
        block_height: u32,
    ) -> Result<BlockHeaderHash, VmExecutionError> {
        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        self.headers_db
            .get_stacks_block_header_hash_for_block(&id_bhh, &epoch)
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()).into())
    }

    pub fn get_burn_block_time(
        &mut self,
        block_height: u32,
        id_bhh_opt: Option<StacksBlockId>,
    ) -> Result<u64, VmExecutionError> {
        let id_bhh = match id_bhh_opt {
            Some(x) => x,
            None => self.get_index_block_header_hash(block_height)?,
        };
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        self.headers_db
            .get_burn_block_time_for_block(&id_bhh, Some(&epoch))
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()).into())
    }

    pub fn get_block_time(&mut self, block_height: u32) -> Result<u64, VmExecutionError> {
        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        if !epoch.uses_nakamoto_blocks() {
            return self.get_burn_block_time(block_height, Some(id_bhh));
        }

        self.headers_db
            .get_stacks_block_time_for_block(&id_bhh)
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()).into())
    }

    pub fn get_burnchain_block_header_hash(
        &mut self,
        block_height: u32,
    ) -> Result<BurnchainHeaderHash, VmExecutionError> {
        let id_bhh = self.get_index_block_header_hash(block_height)?;
        self.headers_db
            .get_burn_header_hash_for_block(&id_bhh)
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()).into())
    }

    /// In Epoch 2.x:
    /// 1. Get the current Stacks tip height (which is in the process of being evaluated)
    /// 2. Get the parent block's StacksBlockId, which is SHA512-256(consensus_hash, block_hash).
    ///    This is the highest Stacks block in this fork whose consensus hash is known.
    /// 3. Resolve the parent StacksBlockId to its consensus hash
    /// 4. Resolve the consensus hash to the associated SortitionId
    ///    In Epoch 3+:
    /// 1. Get the SortitionId of the current Stacks tip
    fn get_sortition_id_for_stacks_tip(&mut self) -> Result<Option<SortitionId>, VmExecutionError> {
        if !self
            .get_clarity_epoch_version()?
            .clarity_uses_tip_burn_block()
        {
            let current_stacks_height = self.get_current_block_height();

            if current_stacks_height < 1 {
                // we are in the Stacks genesis block
                return Ok(None);
            }

            // this is the StacksBlockId of the last block evaluated in this fork
            let parent_id_bhh = self.get_index_block_header_hash(current_stacks_height - 1)?;
            let epoch = self.get_stacks_epoch_for_block(&parent_id_bhh)?;

            // infallible, since we always store the consensus hash with the StacksBlockId in the
            // headers DB
            let consensus_hash = self
                .headers_db
                .get_consensus_hash_for_block(&parent_id_bhh, &epoch)
                .ok_or_else(|| {
                    VmInternalError::Expect(format!(
                        "FATAL: no consensus hash found for StacksBlockId {parent_id_bhh}"
                    ))
                })?;

            // infallible, since every sortition has a consensus hash
            let sortition_id = self
                .burn_state_db
                .get_sortition_id_from_consensus_hash(&consensus_hash)
                .ok_or_else(|| {
                    VmInternalError::Expect(format!(
                        "FATAL: no SortitionID found for consensus hash {consensus_hash}"
                    ))
                })?;

            Ok(Some(sortition_id))
        } else {
            Ok(self.burn_state_db.get_tip_sortition_id())
        }
    }

    /// Fetch the burnchain block header hash for a given burnchain height.
    /// Because the burnchain can fork, we need to resolve the burnchain hash from the
    /// currently-evaluated Stacks chain tip.
    ///
    /// This way, the `BurnchainHeaderHash` returned is guaranteed to be on the burnchain fork
    /// that holds the currently-evaluated Stacks fork (even if it's not the canonical burnchain
    /// fork).
    pub fn get_burnchain_block_header_hash_for_burnchain_height(
        &mut self,
        burnchain_block_height: u32,
    ) -> Result<Option<BurnchainHeaderHash>, VmExecutionError> {
        let sortition_id = match self.get_sortition_id_for_stacks_tip()? {
            Some(x) => x,
            None => return Ok(None),
        };
        Ok(self
            .burn_state_db
            .get_burn_header_hash(burnchain_block_height, &sortition_id))
    }

    /// Get the PoX reward addresses and per-address payout for a given burnchain height.  Because the burnchain can fork,
    /// we need to resolve the PoX addresses from the currently-evaluated Stacks chain tip.
    pub fn get_pox_payout_addrs_for_burnchain_height(
        &mut self,
        burnchain_block_height: u32,
    ) -> Result<Option<(Vec<TupleData>, u128)>, VmExecutionError> {
        let sortition_id = match self.get_sortition_id_for_stacks_tip()? {
            Some(x) => x,
            None => return Ok(None),
        };
        Ok(self
            .burn_state_db
            .get_pox_payout_addrs(burnchain_block_height, &sortition_id))
    }

    pub fn get_burnchain_block_height(&self, id_bhh: &StacksBlockId) -> Option<u32> {
        self.headers_db.get_burn_block_height_for_block(id_bhh)
    }

    pub fn get_block_vrf_seed(&mut self, block_height: u32) -> Result<VRFSeed, VmExecutionError> {
        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let query_tip = self.eval_tip_block_id()?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        self.headers_db
            .get_vrf_seed_for_block(&id_bhh, &query_tip, &epoch)
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()).into())
    }

    pub fn get_miner_address(
        &mut self,
        block_height: u32,
    ) -> Result<StandardPrincipalData, VmExecutionError> {
        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let query_tip = self.eval_tip_block_id()?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        Ok(self
            .headers_db
            .get_miner_address(&id_bhh, &query_tip, &epoch)
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()))?
            .into())
    }

    pub fn get_miner_spend_winner(&mut self, block_height: u32) -> Result<u128, VmExecutionError> {
        if block_height == 0 {
            return Ok(0);
        }

        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let query_tip = self.eval_tip_block_id()?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        Ok(self
            .headers_db
            .get_burnchain_tokens_spent_for_winning_block(&id_bhh, &query_tip, &epoch)
            .ok_or_else(|| {
                VmInternalError::Expect(
                    "FATAL: no winning burnchain token spend record for block".into(),
                )
            })?)
    }

    pub fn get_miner_spend_total(&mut self, block_height: u32) -> Result<u128, VmExecutionError> {
        if block_height == 0 {
            return Ok(0);
        }

        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let query_tip = self.eval_tip_block_id()?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        Ok(self
            .headers_db
            .get_burnchain_tokens_spent_for_block(&id_bhh, &query_tip, &epoch)
            .ok_or_else(|| {
                VmInternalError::Expect(
                    "FATAL: no total burnchain token spend record for block".into(),
                )
            })?)
    }

    pub fn get_block_reward(
        &mut self,
        block_height: u32,
    ) -> Result<Option<u128>, VmExecutionError> {
        if block_height == 0 {
            return Ok(None);
        }

        let cur_height: u64 = self.get_current_block_height().into();

        // reward for the *child* of this block must have matured, since that determines the
        // streamed tx fee reward portion
        if ((block_height + 1) as u64) + MINER_REWARD_MATURITY >= cur_height {
            return Ok(None);
        }

        let id_bhh = self.get_index_block_header_hash(block_height)?;
        let query_tip = self.eval_tip_block_id()?;
        let epoch = self.get_stacks_epoch_for_block(&id_bhh)?;
        let reward: u128 = self
            .headers_db
            .get_tokens_earned_for_block(&id_bhh, &query_tip, &epoch)
            .ok_or_else(|| {
                VmInternalError::Expect("FATAL: matured block has no recorded reward".into())
            })?;

        Ok(Some(reward))
    }

    pub fn get_stx_btc_ops_processed(&mut self) -> Result<u64, VmExecutionError> {
        Ok(self
            .get_data("vm_pox::stx_btc_ops::processed_blocks")?
            .unwrap_or(0))
    }

    pub fn set_stx_btc_ops_processed(&mut self, processed: u64) -> Result<(), VmExecutionError> {
        self.put_data("vm_pox::stx_btc_ops::processed_blocks", &processed)
    }
}

// poison-microblock

impl ClarityDatabase<'_> {
    pub fn make_microblock_pubkey_height_key(pubkey_hash: &Hash160) -> String {
        format!("microblock-pubkey-hash::{pubkey_hash}")
    }

    pub fn make_microblock_poison_key(height: u32) -> String {
        format!("microblock-poison::{height}")
    }

    pub fn insert_microblock_pubkey_hash_height(
        &mut self,
        pubkey_hash: &Hash160,
        height: u32,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_microblock_pubkey_height_key(pubkey_hash);
        let value = format!("{height}");
        self.put_data(&key, &value)
    }

    pub fn get_cc_special_cases_handler(&self) -> Option<SpecialCaseHandler> {
        self.store.get_cc_special_cases_handler()
    }

    #[allow(clippy::unnecessary_fallible_conversions)]
    pub fn insert_microblock_poison(
        &mut self,
        height: u32,
        reporter: &StandardPrincipalData,
        seq: u16,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_microblock_poison_key(height);
        let value = Value::Tuple(
            TupleData::from_data(vec![
                (
                    ClarityName::try_from("reporter").map_err(|_| {
                        VmInternalError::Expect("BUG: valid string representation".into())
                    })?,
                    Value::Principal(PrincipalData::Standard(reporter.clone())),
                ),
                (
                    ClarityName::try_from("sequence").map_err(|_| {
                        VmInternalError::Expect("BUG: valid string representation".into())
                    })?,
                    Value::UInt(seq as u128),
                ),
            ])
            .map_err(|_| VmInternalError::Expect("BUG: valid tuple representation".into()))?,
        );
        let mut value_bytes = vec![];
        value.serialize_write(&mut value_bytes).map_err(|_| {
            VmInternalError::Expect("BUG: valid tuple representation did not serialize".into())
        })?;

        let value_str = to_hex(&value_bytes);
        self.put_data(&key, &value_str)
    }

    pub fn get_microblock_pubkey_hash_height(
        &mut self,
        pubkey_hash: &Hash160,
    ) -> Result<Option<u32>, VmExecutionError> {
        let key = ClarityDatabase::make_microblock_pubkey_height_key(pubkey_hash);
        self.get_data(&key)?
            .map(|height_str: String| {
                height_str.parse::<u32>().map_err(|_| {
                    VmInternalError::Expect(
                        "BUG: inserted non-u32 as height of microblock pubkey hash".into(),
                    )
                    .into()
                })
            })
            .transpose()
    }

    /// Returns (who-reported-the-poison-microblock, sequence-of-microblock-fork)
    pub fn get_microblock_poison_report(
        &mut self,
        height: u32,
    ) -> Result<Option<(StandardPrincipalData, u16)>, VmExecutionError> {
        let key = ClarityDatabase::make_microblock_poison_key(height);
        self.get_data(&key)?
            .map(|reporter_hex_str: String| {
                let reporter_value = Value::try_deserialize_hex_untyped(&reporter_hex_str)
                    .map_err(|_| {
                        VmInternalError::Expect(
                            "BUG: failed to decode serialized poison-microblock reporter".into(),
                        )
                    })?;
                let tuple_data = reporter_value
                    .expect_tuple()
                    .map_err(|_| VmInternalError::Expect("Expected tuple".into()))?;
                let reporter_value = tuple_data
                    .get("reporter")
                    .map_err(|_| {
                        VmInternalError::Expect(
                            "BUG: poison-microblock report has no 'reporter'".into(),
                        )
                    })?
                    .to_owned();
                let seq_value = tuple_data
                    .get("sequence")
                    .map_err(|_| {
                        VmInternalError::Expect(
                            "BUG: poison-microblock report has no 'sequence'".into(),
                        )
                    })?
                    .to_owned();

                let reporter_principal = reporter_value
                    .expect_principal()
                    .map_err(|_| VmInternalError::Expect("Expected principal".into()))?;
                let seq_u128 = seq_value
                    .expect_u128()
                    .map_err(|_| VmInternalError::Expect("Expected u128".into()))?;

                let seq: u16 = seq_u128
                    .try_into()
                    .map_err(|_| VmInternalError::Expect("BUG: seq exceeds u16 max".into()))?;
                if let PrincipalData::Standard(principal_data) = reporter_principal {
                    Ok((principal_data, seq))
                } else {
                    Err(VmInternalError::Expect(
                        "BUG: poison-microblock report principal is not a standard principal"
                            .into(),
                    )
                    .into())
                }
            })
            .transpose()
    }
}

// this is used so that things like load_map, load_var, load_nft, etc.
//   will throw NoSuchFoo errors instead of NoSuchContract errors.
fn map_no_contract_as_none<T>(
    res: Result<Option<T>, VmExecutionError>,
) -> Result<Option<T>, VmExecutionError> {
    res.or_else(|e| match e {
        VmExecutionError::RuntimeCheck(RuntimeCheckErrorKind::NoSuchContract(_)) => Ok(None),
        x => Err(x),
    })
}

// Variable Functions...
impl ClarityDatabase<'_> {
    pub fn create_variable(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
        value_type: TypeSignature,
    ) -> Result<DataVariableMetadata, VmExecutionError> {
        let variable_data = DataVariableMetadata { value_type };
        let key = ClarityDatabase::make_metadata_key(StoreType::VariableMeta, variable_name);

        self.insert_metadata(contract_identifier, &key, &variable_data)?;
        Ok(variable_data)
    }

    pub fn load_variable(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
    ) -> Result<DataVariableMetadata, VmExecutionError> {
        let key = ClarityDatabase::make_metadata_key(StoreType::VariableMeta, variable_name);

        map_no_contract_as_none(self.fetch_metadata(contract_identifier, &key))?.ok_or(
            RuntimeCheckErrorKind::Unreachable(bounded_format!(
                "No such data variable: {variable_name}"
            ))
            .into(),
        )
    }

    #[cfg(any(test, feature = "testing"))]
    pub fn set_variable_unknown_descriptor(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
        value: Value,
    ) -> Result<Value, VmExecutionError> {
        let epoch = self.get_clarity_epoch_version()?;
        let descriptor = self.load_variable(contract_identifier, variable_name)?;
        self.set_variable(
            contract_identifier,
            variable_name,
            value,
            &descriptor,
            &epoch,
        )
        .map(|data| data.value)
    }

    pub fn set_variable(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
        value: Value,
        variable_descriptor: &DataVariableMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        if !variable_descriptor
            .value_type
            .admits(&self.get_clarity_epoch_version()?, &value)?
        {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(variable_descriptor.value_type.clone()),
                value.to_error_string(),
            )
            .into());
        }

        let key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::Variable,
            variable_name,
        );

        let size = self.put_value_with_size(&key, value, epoch)?;

        Ok(ValueResult {
            value: Value::Bool(true),
            serialized_byte_len: size,
        })
    }

    pub fn lookup_variable_unknown_descriptor(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
        epoch: &StacksEpochId,
    ) -> Result<Value, VmExecutionError> {
        let descriptor = self.load_variable(contract_identifier, variable_name)?;
        self.lookup_variable(contract_identifier, variable_name, &descriptor, epoch)
    }

    pub fn lookup_variable(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
        variable_descriptor: &DataVariableMetadata,
        epoch: &StacksEpochId,
    ) -> Result<Value, VmExecutionError> {
        let key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::Variable,
            variable_name,
        );

        let result = self.get_value(&key, &variable_descriptor.value_type, epoch)?;

        match result {
            None => Ok(Value::none()),
            Some(data) => Ok(data.value),
        }
    }

    /// Same as lookup_variable, but returns the byte-size of the looked up
    ///  Clarity value as well as the value.
    pub fn lookup_variable_with_size(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        variable_name: &str,
        variable_descriptor: &DataVariableMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        let key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::Variable,
            variable_name,
        );

        let result = self.get_value(&key, &variable_descriptor.value_type, epoch)?;

        match result {
            None => Ok(ValueResult {
                value: Value::none(),
                serialized_byte_len: *NONE_SERIALIZATION_LEN,
            }),
            Some(data) => Ok(data),
        }
    }
}

// Data Map Functions
impl ClarityDatabase<'_> {
    pub fn create_map(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_type: TypeSignature,
        value_type: TypeSignature,
    ) -> Result<DataMapMetadata, VmExecutionError> {
        let data = DataMapMetadata {
            key_type,
            value_type,
        };

        let key = ClarityDatabase::make_metadata_key(StoreType::DataMapMeta, map_name);
        self.insert_metadata(contract_identifier, &key, &data)?;

        Ok(data)
    }

    pub fn load_map(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
    ) -> Result<DataMapMetadata, VmExecutionError> {
        let key = ClarityDatabase::make_metadata_key(StoreType::DataMapMeta, map_name);

        map_no_contract_as_none(self.fetch_metadata(contract_identifier, &key))?.ok_or(
            RuntimeCheckErrorKind::Unreachable(bounded_format!("No such map: {map_name}")).into(),
        )
    }

    pub fn make_key_for_data_map_entry(
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value: &Value,
    ) -> Result<String, VmExecutionError> {
        Ok(ClarityDatabase::make_key_for_data_map_entry_serialized(
            contract_identifier,
            map_name,
            &key_value
                .serialize_to_hex()
                .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?,
        ))
    }

    fn make_key_for_data_map_entry_serialized(
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value_serialized: &str,
    ) -> String {
        ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::DataMap,
            map_name,
            key_value_serialized,
        )
    }

    pub fn fetch_entry_unknown_descriptor(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value: &Value,
        epoch: &StacksEpochId,
    ) -> Result<Value, VmExecutionError> {
        let descriptor = self.load_map(contract_identifier, map_name)?;
        self.fetch_entry(contract_identifier, map_name, key_value, &descriptor, epoch)
    }

    /// Returns a Clarity optional type wrapping a found or not found result
    pub fn fetch_entry(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value: &Value,
        map_descriptor: &DataMapMetadata,
        epoch: &StacksEpochId,
    ) -> Result<Value, VmExecutionError> {
        if !map_descriptor
            .key_type
            .admits(&self.get_clarity_epoch_version()?, key_value)?
        {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(map_descriptor.key_type.clone()),
                key_value.to_error_string(),
            )
            .into());
        }

        let key =
            ClarityDatabase::make_key_for_data_map_entry(contract_identifier, map_name, key_value)?;

        let stored_type = TypeSignature::new_option(map_descriptor.value_type.clone())?;
        let result = self.get_value(&key, &stored_type, epoch)?;

        match result {
            None => Ok(Value::none()),
            Some(data) => Ok(data.value),
        }
    }

    pub fn fetch_entry_with_size(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value: &Value,
        map_descriptor: &DataMapMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        if !map_descriptor
            .key_type
            .admits(&self.get_clarity_epoch_version()?, key_value)?
        {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(map_descriptor.key_type.clone()),
                key_value.to_error_string(),
            )
            .into());
        }

        let key_serialized = key_value
            .serialize_to_hex()
            .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?;
        let key = ClarityDatabase::make_key_for_data_map_entry_serialized(
            contract_identifier,
            map_name,
            &key_serialized,
        );

        let stored_type = TypeSignature::new_option(map_descriptor.value_type.clone())?;
        let result = self.get_value(&key, &stored_type, epoch)?;

        match result {
            None => Ok(ValueResult {
                value: Value::none(),
                serialized_byte_len: byte_len_of_serialization(&key_serialized),
            }),
            Some(ValueResult {
                value,
                serialized_byte_len,
            }) => Ok(ValueResult {
                value,
                serialized_byte_len: serialized_byte_len
                    .checked_add(byte_len_of_serialization(&key_serialized))
                    .ok_or_else(|| {
                        VmInternalError::Expect("Overflowed Clarity key/value size".into())
                    })?,
            }),
        }
    }

    pub fn set_entry(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key: Value,
        value: Value,
        map_descriptor: &DataMapMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        self.inner_set_entry(
            contract_identifier,
            map_name,
            key,
            value,
            false,
            map_descriptor,
            epoch,
        )
    }

    pub fn set_entry_unknown_descriptor(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key: Value,
        value: Value,
        epoch: &StacksEpochId,
    ) -> Result<Value, VmExecutionError> {
        let descriptor = self.load_map(contract_identifier, map_name)?;
        self.set_entry(
            contract_identifier,
            map_name,
            key,
            value,
            &descriptor,
            epoch,
        )
        .map(|data| data.value)
    }

    pub fn insert_entry_unknown_descriptor(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key: Value,
        value: Value,
        epoch: &StacksEpochId,
    ) -> Result<Value, VmExecutionError> {
        let descriptor = self.load_map(contract_identifier, map_name)?;
        self.insert_entry(
            contract_identifier,
            map_name,
            key,
            value,
            &descriptor,
            epoch,
        )
        .map(|data| data.value)
    }

    pub fn insert_entry(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key: Value,
        value: Value,
        map_descriptor: &DataMapMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        self.inner_set_entry(
            contract_identifier,
            map_name,
            key,
            value,
            true,
            map_descriptor,
            epoch,
        )
    }

    fn data_map_entry_exists(
        &mut self,
        key: &str,
        expected_value: &TypeSignature,
        epoch: &StacksEpochId,
    ) -> Result<bool, VmExecutionError> {
        match self.get_value(key, expected_value, epoch)? {
            None => Ok(false),
            Some(value) => Ok(value.value != Value::none()),
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn inner_set_entry(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value: Value,
        value: Value,
        return_if_exists: bool,
        map_descriptor: &DataMapMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        if !map_descriptor
            .key_type
            .admits(&self.get_clarity_epoch_version()?, &key_value)?
        {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(map_descriptor.key_type.clone()),
                key_value.to_error_string(),
            )
            .into());
        }
        if !map_descriptor
            .value_type
            .admits(&self.get_clarity_epoch_version()?, &value)?
        {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(map_descriptor.value_type.clone()),
                value.to_error_string(),
            )
            .into());
        }

        let key_serialized = key_value
            .serialize_to_hex()
            .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?;
        let key_serialized_byte_len = byte_len_of_serialization(&key_serialized);
        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::DataMap,
            map_name,
            &key_serialized,
        );
        let stored_type = TypeSignature::new_option(map_descriptor.value_type.clone())?;

        if return_if_exists && self.data_map_entry_exists(&key, &stored_type, epoch)? {
            return Ok(ValueResult {
                value: Value::Bool(false),
                serialized_byte_len: key_serialized_byte_len,
            });
        }

        let placed_value = Value::some(value)?;
        let placed_size = self.put_value_with_size(&key, placed_value, epoch)?;

        Ok(ValueResult {
            value: Value::Bool(true),
            serialized_byte_len: key_serialized_byte_len
                .checked_add(placed_size)
                .ok_or_else(|| {
                    VmInternalError::Expect("Overflowed Clarity key/value size".into())
                })?,
        })
    }

    pub fn delete_entry(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        map_name: &str,
        key_value: &Value,
        map_descriptor: &DataMapMetadata,
        epoch: &StacksEpochId,
    ) -> Result<ValueResult, VmExecutionError> {
        if !map_descriptor
            .key_type
            .admits(&self.get_clarity_epoch_version()?, key_value)?
        {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(map_descriptor.key_type.clone()),
                key_value.to_error_string(),
            )
            .into());
        }

        let key_serialized = key_value
            .serialize_to_hex()
            .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?;
        let key_serialized_byte_len = byte_len_of_serialization(&key_serialized);
        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::DataMap,
            map_name,
            &key_serialized,
        );
        let stored_type = TypeSignature::new_option(map_descriptor.value_type.clone())?;
        if !self.data_map_entry_exists(&key, &stored_type, epoch)? {
            return Ok(ValueResult {
                value: Value::Bool(false),
                serialized_byte_len: key_serialized_byte_len,
            });
        }

        self.put_value(&key, Value::none(), epoch)?;

        Ok(ValueResult {
            value: Value::Bool(true),
            serialized_byte_len: key_serialized_byte_len
                .checked_add(*NONE_SERIALIZATION_LEN)
                .ok_or_else(|| {
                    VmInternalError::Expect("Overflowed Clarity key/value size".into())
                })?,
        })
    }
}

// Asset Functions

impl ClarityDatabase<'_> {
    pub fn create_fungible_token(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
        total_supply: &Option<u128>,
    ) -> Result<FungibleTokenMetadata, VmExecutionError> {
        let data = FungibleTokenMetadata {
            total_supply: *total_supply,
        };

        let key = ClarityDatabase::make_metadata_key(StoreType::FungibleTokenMeta, token_name);
        self.insert_metadata(contract_identifier, &key, &data)?;

        // total supply _is_ included in the consensus hash
        let supply_key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::CirculatingSupply,
            token_name,
        );
        self.put_data(&supply_key, &(0_u128))?;

        Ok(data)
    }

    pub fn load_ft(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
    ) -> Result<FungibleTokenMetadata, VmExecutionError> {
        let key = ClarityDatabase::make_metadata_key(StoreType::FungibleTokenMeta, token_name);

        map_no_contract_as_none(self.fetch_metadata(contract_identifier, &key))?.ok_or(
            RuntimeCheckErrorKind::Unreachable(bounded_format!("No such FT: {token_name}")).into(),
        )
    }

    pub fn create_non_fungible_token(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
        key_type: &TypeSignature,
    ) -> Result<NonFungibleTokenMetadata, VmExecutionError> {
        let data = NonFungibleTokenMetadata {
            key_type: key_type.clone(),
        };
        let key = ClarityDatabase::make_metadata_key(StoreType::NonFungibleTokenMeta, token_name);
        self.insert_metadata(contract_identifier, &key, &data)?;

        Ok(data)
    }

    fn load_nft(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
    ) -> Result<NonFungibleTokenMetadata, VmExecutionError> {
        let key = ClarityDatabase::make_metadata_key(StoreType::NonFungibleTokenMeta, token_name);

        map_no_contract_as_none(self.fetch_metadata(contract_identifier, &key))?.ok_or(
            RuntimeCheckErrorKind::Unreachable(bounded_format!("No such NFT: {token_name}")).into(),
        )
    }

    pub fn checked_increase_token_supply(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
        amount: u128,
        descriptor: &FungibleTokenMetadata,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::CirculatingSupply,
            token_name,
        );
        let current_supply: u128 = self.get_data(&key)?.ok_or_else(|| {
            VmInternalError::Expect("ERROR: Clarity VM failed to track token supply.".into())
        })?;

        let new_supply = current_supply
            .checked_add(amount)
            .ok_or(RuntimeError::ArithmeticOverflow)?;

        if let Some(total_supply) = descriptor.total_supply
            && new_supply > total_supply
        {
            return Err(RuntimeError::SupplyOverflow(new_supply, total_supply).into());
        }

        self.put_data(&key, &new_supply)
    }

    pub fn checked_decrease_token_supply(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
        amount: u128,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::CirculatingSupply,
            token_name,
        );
        let current_supply: u128 = self.get_data(&key)?.ok_or_else(|| {
            VmInternalError::Expect("ERROR: Clarity VM failed to track token supply.".into())
        })?;

        if amount > current_supply {
            // `SupplyUnderflow` is **unreachable** in normal Clarity execution:
            // the sender's balance is checked first (`amount <= sender_balance`),
            // and `sender_balance <= current_supply` always holds.
            // Thus, `amount > current_supply` cannot occur.
            return Err(RuntimeError::SupplyUnderflow(current_supply, amount).into());
        }

        let new_supply = current_supply - amount;

        self.put_data(&key, &new_supply)
    }

    pub fn get_ft_balance(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
        principal: &PrincipalData,
        descriptor: Option<&FungibleTokenMetadata>,
    ) -> Result<u128, VmExecutionError> {
        if descriptor.is_none() {
            self.load_ft(contract_identifier, token_name)?;
        }

        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::FungibleToken,
            token_name,
            &principal.serialize(),
        );

        let result = self.get_data(&key)?;
        match result {
            None => Ok(0),
            Some(balance) => Ok(balance),
        }
    }

    pub fn set_ft_balance(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
        principal: &PrincipalData,
        balance: u128,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::FungibleToken,
            token_name,
            &principal.serialize(),
        );
        self.put_data(&key, &balance)
    }

    pub fn get_ft_supply(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        token_name: &str,
    ) -> Result<u128, VmExecutionError> {
        let key = ClarityDatabase::make_key_for_trip(
            contract_identifier,
            StoreType::CirculatingSupply,
            token_name,
        );
        let supply = self.get_data(&key)?.ok_or_else(|| {
            VmInternalError::Expect("ERROR: Clarity VM failed to track token supply.".into())
        })?;
        Ok(supply)
    }

    pub fn get_nft_owner(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        asset_name: &str,
        asset: &Value,
        key_type: &TypeSignature,
    ) -> Result<PrincipalData, VmExecutionError> {
        if !key_type.admits(&self.get_clarity_epoch_version()?, asset)? {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(key_type.clone()),
                asset.to_error_string(),
            )
            .into());
        }

        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::NonFungibleToken,
            asset_name,
            &asset
                .serialize_to_hex()
                .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?,
        );

        let epoch = self.get_clarity_epoch_version()?;
        let value: Option<ValueResult> = self.get_value(
            &key,
            &TypeSignature::new_option(TypeSignature::PrincipalType)
                .map_err(|_| VmInternalError::Expect("Unexpected type failure".into()))?,
            &epoch,
        )?;
        let owner = match value {
            Some(owner) => owner
                .value
                .expect_optional()
                .map_err(|_| VmInternalError::Expect("Expected an optional".into()))?,
            None => return Err(RuntimeError::NoSuchToken.into()),
        };

        let principal = match owner {
            Some(value) => value
                .expect_principal()
                .map_err(|_| VmInternalError::Expect("Expected principal.".into()))?,
            None => return Err(RuntimeError::NoSuchToken.into()),
        };

        Ok(principal)
    }

    pub fn get_nft_key_type(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        asset_name: &str,
    ) -> Result<TypeSignature, VmExecutionError> {
        let descriptor = self.load_nft(contract_identifier, asset_name)?;
        Ok(descriptor.key_type)
    }

    pub fn set_nft_owner(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        asset_name: &str,
        asset: &Value,
        principal: &PrincipalData,
        key_type: &TypeSignature,
        epoch: &StacksEpochId,
    ) -> Result<(), VmExecutionError> {
        if !key_type.admits(&self.get_clarity_epoch_version()?, asset)? {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(key_type.clone()),
                asset.to_error_string(),
            )
            .into());
        }

        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::NonFungibleToken,
            asset_name,
            &asset
                .serialize_to_hex()
                .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?,
        );

        let value = Value::some(Value::Principal(principal.clone()))?;
        self.put_value(&key, value, epoch)?;

        Ok(())
    }

    pub fn burn_nft(
        &mut self,
        contract_identifier: &QualifiedContractIdentifier,
        asset_name: &str,
        asset: &Value,
        key_type: &TypeSignature,
        epoch: &StacksEpochId,
    ) -> Result<(), VmExecutionError> {
        if !key_type.admits(&self.get_clarity_epoch_version()?, asset)? {
            return Err(RuntimeCheckErrorKind::TypeValueError(
                Box::new(key_type.clone()),
                asset.to_error_string(),
            )
            .into());
        }

        let key = ClarityDatabase::make_key_for_quad(
            contract_identifier,
            StoreType::NonFungibleToken,
            asset_name,
            &asset
                .serialize_to_hex()
                .map_err(|_| VmInternalError::Expect("IOError filling byte buffer.".into()))?,
        );

        self.put_value(&key, Value::none(), epoch)?;
        Ok(())
    }
}

// load/store STX token state and account nonces
impl<'a> ClarityDatabase<'a> {
    fn make_key_for_account(principal: &PrincipalData, data: StoreType) -> String {
        format!("vm-account::{principal}::{}", data as u8)
    }

    pub fn make_key_for_account_balance(principal: &PrincipalData) -> String {
        ClarityDatabase::make_key_for_account(principal, StoreType::STXBalance)
    }

    pub fn make_key_for_account_nonce(principal: &PrincipalData) -> String {
        ClarityDatabase::make_key_for_account(principal, StoreType::Nonce)
    }

    pub fn make_key_for_account_stx_locked(principal: &PrincipalData) -> String {
        ClarityDatabase::make_key_for_account(principal, StoreType::PoxSTXLockup)
    }

    pub fn make_key_for_account_unlock_height(principal: &PrincipalData) -> String {
        ClarityDatabase::make_key_for_account(principal, StoreType::PoxUnlockHeight)
    }

    pub fn get_stx_balance_snapshot<'conn>(
        &'conn mut self,
        principal: &PrincipalData,
    ) -> Result<STXBalanceSnapshot<'a, 'conn>, VmExecutionError> {
        let stx_balance = self.get_account_stx_balance(principal)?;
        let cur_burn_height = u64::from(self.get_current_burnchain_block_height()?);

        test_debug!(
            "Balance of {principal} (raw={},locked={},unlock-height={},current-height={cur_burn_height}) is {} (has_unlockable_tokens_at_burn_block={})",
            stx_balance.amount_unlocked(),
            stx_balance.amount_locked(),
            stx_balance.unlock_height(),
            stx_balance.get_available_balance_at_burn_block(
                cur_burn_height,
                self.get_v1_unlock_height(),
                self.get_v2_unlock_height()?,
                self.get_v3_unlock_height()?,
                self.get_v4_unlock_height()?,
            )?,
            stx_balance.has_unlockable_tokens_at_burn_block(
                cur_burn_height,
                self.get_v1_unlock_height(),
                self.get_v2_unlock_height()?,
                self.get_v3_unlock_height()?,
                self.get_v4_unlock_height()?,
            )
        );

        Ok(STXBalanceSnapshot::new(
            principal,
            stx_balance,
            cur_burn_height,
            self,
        ))
    }

    pub fn get_stx_balance_snapshot_genesis<'conn>(
        &'conn mut self,
        principal: &PrincipalData,
    ) -> Result<STXBalanceSnapshot<'a, 'conn>, VmExecutionError> {
        let stx_balance = self.get_account_stx_balance(principal)?;
        let cur_burn_height = 0;

        test_debug!(
            "Balance of {principal} (raw={},locked={},unlock-height={},current-height={cur_burn_height}) is {} (has_unlockable_tokens_at_burn_block={})",
            stx_balance.amount_unlocked(),
            stx_balance.amount_locked(),
            stx_balance.unlock_height(),
            stx_balance.get_available_balance_at_burn_block(
                cur_burn_height,
                self.get_v1_unlock_height(),
                self.get_v2_unlock_height()?,
                self.get_v3_unlock_height()?,
                self.get_v4_unlock_height()?,
            )?,
            stx_balance.has_unlockable_tokens_at_burn_block(
                cur_burn_height,
                self.get_v1_unlock_height(),
                self.get_v2_unlock_height()?,
                self.get_v3_unlock_height()?,
                self.get_v4_unlock_height()?,
            )
        );

        Ok(STXBalanceSnapshot::new(
            principal,
            stx_balance,
            cur_burn_height,
            self,
        ))
    }

    pub fn get_account_stx_balance(
        &mut self,
        principal: &PrincipalData,
    ) -> Result<STXBalance, VmExecutionError> {
        let key = ClarityDatabase::make_key_for_account_balance(principal);
        debug!("Fetching account balance"; "principal" => %principal.to_string());
        let result = self.get_data(&key)?;
        Ok(result.unwrap_or_default())
    }

    pub fn get_account_nonce(
        &mut self,
        principal: &PrincipalData,
    ) -> Result<u64, VmExecutionError> {
        let key = ClarityDatabase::make_key_for_account_nonce(principal);
        let result = self.get_data(&key)?;
        Ok(result.unwrap_or_default())
    }

    pub fn set_account_nonce(
        &mut self,
        principal: &PrincipalData,
        nonce: u64,
    ) -> Result<(), VmExecutionError> {
        let key = ClarityDatabase::make_key_for_account_nonce(principal);
        self.put_data(&key, &nonce)
    }
}

// access burnchain state
impl ClarityDatabase<'_> {
    pub fn get_burn_block_height(&self, sortition_id: &SortitionId) -> Option<u32> {
        self.burn_state_db.get_burn_block_height(sortition_id)
    }

    /// This function obtains the stacks epoch version, which is based on the burn block height.
    /// Valid epochs include stacks 1.0, 2.0, 2.05, and so on.
    pub fn get_stacks_epoch(&self, height: u32) -> Option<StacksEpoch> {
        self.burn_state_db.get_stacks_epoch(height)
    }

    pub fn get_stacks_epoch_for_block(
        &self,
        id_bhh: &StacksBlockId,
    ) -> Result<StacksEpochId, VmExecutionError> {
        let burn_block = self.get_burnchain_block_height(id_bhh).ok_or_else(|| {
            VmInternalError::Expect(format!(
                "FATAL: no burnchain block height found for Stacks block {id_bhh}"
            ))
        })?;
        let epoch = self
            .get_stacks_epoch(burn_block)
            .ok_or_else(|| VmInternalError::Expect("Failed to get block data.".into()))?;
        Ok(epoch.epoch_id)
    }
}

#[test]
fn increment_ustx_liquid_supply_overflow() {
    use crate::vm::database::MemoryBackingStore;
    use crate::vm::errors::{RuntimeError, VmExecutionError};

    let mut store = MemoryBackingStore::new();
    let mut db = store.as_clarity_db();

    db.begin();
    // Set the liquid supply to one less than the max
    db.set_ustx_liquid_supply(u128::MAX - 1)
        .expect("Failed to set liquid supply");
    // Trust but verify.
    assert_eq!(
        db.get_total_liquid_ustx().unwrap(),
        u128::MAX - 1,
        "Supply should now be u128::MAX - 1"
    );

    db.increment_ustx_liquid_supply(1)
        .expect("Increment by 1 should succeed");

    // Trust but verify.
    assert_eq!(
        db.get_total_liquid_ustx().unwrap(),
        u128::MAX,
        "Supply should now be u128::MAX"
    );

    // Attempt to overflow
    let err = db.increment_ustx_liquid_supply(1).unwrap_err();
    assert!(matches!(
        err,
        VmExecutionError::Runtime(RuntimeError::ArithmeticOverflow, _)
    ));

    // Verify adding 0 doesn't overflow
    db.increment_ustx_liquid_supply(0)
        .expect("Increment by 0 should succeed");

    assert_eq!(db.get_total_liquid_ustx().unwrap(), u128::MAX);

    db.commit().unwrap();
}

#[test]
fn checked_decrease_token_supply_underflow() {
    use crate::vm::database::{MemoryBackingStore, StoreType};
    use crate::vm::errors::{RuntimeError, VmExecutionError};

    let mut store = MemoryBackingStore::new();
    let mut db = store.as_clarity_db();
    let contract_id = QualifiedContractIdentifier::transient();
    let token_name = "token".to_string();

    db.begin();

    // Set initial supply to 1000
    let key =
        ClarityDatabase::make_key_for_trip(&contract_id, StoreType::CirculatingSupply, &token_name);
    db.put_data(&key, &1000u128)
        .expect("Failed to set initial token supply");

    // Trust but verify.
    let current_supply: u128 = db.get_data(&key).unwrap().unwrap();
    assert_eq!(current_supply, 1000, "Initial supply should be 1000");

    // Decrease by 500: should succeed
    db.checked_decrease_token_supply(&contract_id, &token_name, 500)
        .expect("Decreasing by 500 should succeed");

    let new_supply: u128 = db.get_data(&key).unwrap().unwrap();
    assert_eq!(new_supply, 500, "Supply should now be 500");

    // Decrease by 0: should succeed (no change)
    db.checked_decrease_token_supply(&contract_id, &token_name, 0)
        .expect("Decreasing by 0 should succeed");
    let supply_after_zero: u128 = db.get_data(&key).unwrap().unwrap();
    assert_eq!(
        supply_after_zero, 500,
        "Supply should remain 500 after decreasing by 0"
    );

    // Attempt to decrease by 501; should trigger SupplyUnderflow
    let err = db
        .checked_decrease_token_supply(&contract_id, &token_name, 501)
        .unwrap_err();

    assert!(
        matches!(
            err,
            VmExecutionError::Runtime(RuntimeError::SupplyUnderflow(500, 501), _)
        ),
        "Expected SupplyUnderflow(500, 501), got: {err:?}"
    );

    // Supply should remain unchanged after failed underflow
    let final_supply: u128 = db.get_data(&key).unwrap().unwrap();
    assert_eq!(
        final_supply, 500,
        "Supply should not change after underflow error"
    );

    db.commit().unwrap();
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::vm::database::{MemoryBackingStore, StoreType};
    use crate::vm::version::ClarityVersion;

    /// Deploy a minimal stub contract under `id` in its own committed db transaction.
    #[track_caller]
    fn deploy_stub_contract(db: &mut ClarityDatabase, id: &QualifiedContractIdentifier) {
        db.begin();
        let contract = ContractContext::new(id.clone(), ClarityVersion::Clarity2).into();
        db.insert_contract_hash(id, "(define-public (noop) (ok true))")
            .expect("insert_contract_hash");
        db.set_contract_data_size(id, 0)
            .expect("set_contract_data_size");
        db.insert_contract(id, contract).expect("insert_contract");
        db.commit().expect("commit stub contract");
    }

    #[test]
    fn get_contract_populates_cache_on_miss() {
        let mut cache = ClarityExecutionCache::default();
        let mut store = MemoryBackingStore::new();
        let id = QualifiedContractIdentifier::local("cached").unwrap();

        // Deploy outside the cache attachment so the cache starts empty.
        deploy_stub_contract(&mut store.as_clarity_db(), &id);

        // Each `db` block scopes the exclusive borrow on `cache` so we can inspect counters
        // between calls.
        let first = {
            let mut db = store.as_clarity_db().with_cache(&mut cache);
            db.begin();
            let entry = db.get_contract(&id).expect("load contract");
            db.roll_back().unwrap();
            entry
        };
        assert_eq!(first.contract_identifier, id);
        assert_eq!(cache.contracts.misses(), 1);
        assert_eq!(cache.contracts.hits(), 0);

        let second = {
            let mut db = store.as_clarity_db().with_cache(&mut cache);
            db.begin();
            let entry = db.get_contract(&id).expect("cached load");
            db.roll_back().unwrap();
            entry
        };
        // Both `Contract`s should deref to the same underlying `ContractContext`, confirming the
        // cached entry's Arc was shared rather than deserialized fresh.
        assert!(
            std::ptr::eq(&*first, &*second),
            "second call should share the cached Arc, not a fresh deserialization",
        );
        assert_eq!(cache.contracts.hits(), 1);
        assert_eq!(cache.contracts.misses(), 1);
    }

    #[test]
    fn get_contract_load_cost_size_serves_from_cache() {
        let mut cache = ClarityExecutionCache::default();
        let mut store = MemoryBackingStore::new();
        let id = QualifiedContractIdentifier::local("size-cached").unwrap();
        deploy_stub_contract(&mut store.as_clarity_db(), &id);

        // Prime the cache via `get_contract`, then capture the expected size separately.
        let expected_size = {
            let mut db = store.as_clarity_db().with_cache(&mut cache);
            db.begin();
            let _contract = db.get_contract(&id).expect("prime cache");
            let s = db.read_contract_size(&id).unwrap();
            db.roll_back().unwrap();
            s
        };
        let counters_after_prime = (cache.contracts.hits(), cache.contracts.misses());

        // Subsequent `get_contract_size` must come from the cache, and being a passive `peek` it
        // must not bump hit/miss counters.
        let size = {
            let mut db = store.as_clarity_db().with_cache(&mut cache);
            db.begin();
            let s = db.get_contract_size(&id).expect("load_cost_size");
            db.roll_back().unwrap();
            s
        };
        assert_eq!(size, expected_size);
        assert_eq!(
            (cache.contracts.hits(), cache.contracts.misses()),
            counters_after_prime,
            "passive size lookup must not alter hit/miss counters",
        );
    }

    #[test]
    fn get_contract_load_cost_size_falls_back_without_cache() {
        let mut store = MemoryBackingStore::new();
        let id = QualifiedContractIdentifier::local("no-cache").unwrap();
        deploy_stub_contract(&mut store.as_clarity_db(), &id);

        let mut db = store.as_clarity_db();
        db.begin();
        let size = db.get_contract_size(&id).expect("load_cost_size");
        let expected = db.read_contract_size(&id).unwrap();
        assert_eq!(size, expected);
        db.roll_back().unwrap();
    }

    /// A contract deployed in an uncommitted rollback layer is visible via `get_contract` (pending
    /// metadata is served), but it must not be cached: if the surrounding context rolls back, a
    /// cached entry would point at a contract that no longer exists on the backing store, and the
    /// next lookup in the same tx would falsely succeed.
    #[test]
    fn get_contract_does_not_cache_pending_writes() {
        let mut cache = ClarityExecutionCache::default();
        let mut store = MemoryBackingStore::new();
        let id = QualifiedContractIdentifier::local("pending").unwrap();

        // Deploy + load inside a rollback layer, then discard the layer.
        {
            let mut db = store.as_clarity_db().with_cache(&mut cache);
            db.begin();
            let contract = ContractContext::new(id.clone(), ClarityVersion::Clarity2).into();
            db.insert_contract_hash(&id, "(define-public (noop) (ok true))")
                .expect("insert_contract_hash");
            db.set_contract_data_size(&id, 0)
                .expect("set_contract_data_size");
            db.insert_contract(&id, contract).expect("insert_contract");
            let _ = db
                .get_contract(&id)
                .expect("pending-state load should succeed via uncommitted metadata");
            db.roll_back().unwrap();
        }

        // The rolled-back contract must not be served from cache on a subsequent lookup. The
        // backing store also doesn't have it (the deploy was never committed), so the lookup must
        // error.
        {
            let mut db = store.as_clarity_db().with_cache(&mut cache);
            db.begin();
            let result = db.get_contract(&id);
            assert!(
                result.is_err(),
                "rolled-back contract must not be served from cache after rollback",
            );
            db.roll_back().unwrap();
        }
    }

    /// Guards that the DB read path applies the epoch gate, never returning a
    /// type-unsound tuple from Epoch 4.1.
    #[test]
    fn get_value_epoch_gates_typed_tuple_fields() {
        // `{a:int,b:int}` buffer with a duplicate `a` field; collapses to `{a: 2}`.
        const DUPLICATE_FIELDS: &str = "0c000000020161000000000000000000000000000000000101610000000000000000000000000000000002";
        const REDUCED_TUPLE: &str = "0c0000000101610000000000000000000000000000000002";

        let mut store = MemoryBackingStore::new();
        let mut db = store.as_clarity_db();
        db.begin();

        let contract = QualifiedContractIdentifier::transient();
        let key = ClarityDatabase::make_key_for_trip(&contract, StoreType::Variable, "corrupt");
        // Store raw bytes to bypass write-path sanitization and isolate the read path.
        db.put_data(&key, &DUPLICATE_FIELDS.to_string())
            .expect("failed to store raw value");

        let expected_type = TypeSignature::type_of(&Value::from(
            TupleData::from_data(vec![
                (ClarityName::from_literal("a"), Value::Int(1)),
                (ClarityName::from_literal("b"), Value::Int(2)),
            ])
            .unwrap(),
        ))
        .unwrap();

        // Pre-Epoch 4.1: historical handling reduces the duplicate to one field.
        // Epoch40 pins the activation boundary.
        for epoch in [StacksEpochId::Epoch34, StacksEpochId::Epoch40] {
            let legacy = db
                .get_value(&key, &expected_type, &epoch)
                .expect("legacy read should not error")
                .expect("value should be present");
            assert_eq!(legacy.value.serialize_to_hex().unwrap(), REDUCED_TUPLE);
        }

        // Epoch 4.1+: the read is rejected instead of returning a type-unsound tuple.
        let strict = db.get_value(&key, &expected_type, &StacksEpochId::Epoch41);
        assert!(
            strict.is_err(),
            "strict read should reject the malformed tuple, got {strict:?}"
        );

        db.commit().unwrap();
    }
}

#[test]
fn trigger_no_such_token_rust() {
    use crate::vm::database::MemoryBackingStore;
    use crate::vm::errors::{RuntimeError, VmExecutionError};
    // Set up a memory backing store and Clarity database
    let mut store = MemoryBackingStore::default();
    let mut db = store.as_clarity_db();

    db.begin();
    // Define a fake contract identifier
    let contract_id = QualifiedContractIdentifier::transient();

    // Simulate querying a non-existent NFT
    let asset_id = Value::Bool(false); // this token does not exist
    let asset_name = "test-nft";

    // Call get_nft_owner directly
    let err = db
        .get_nft_owner(
            &contract_id,
            asset_name,
            &asset_id,
            &TypeSignature::BoolType,
        )
        .unwrap_err();

    // Assert that it produces NoSuchToken
    assert!(
        matches!(err, VmExecutionError::Runtime(RuntimeError::NoSuchToken, _)),
        "Expected NoSuchToken. Got: {err}"
    );
}
