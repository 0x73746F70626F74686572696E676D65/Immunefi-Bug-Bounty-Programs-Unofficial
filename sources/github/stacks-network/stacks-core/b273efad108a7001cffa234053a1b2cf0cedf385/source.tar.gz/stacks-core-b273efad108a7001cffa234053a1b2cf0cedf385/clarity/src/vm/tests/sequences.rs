// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use pinny::tag;
use proptest::prelude::*;
use rstest::rstest;
use rstest_reuse::{self, *};
use stacks_common::bounded_format;
use stacks_common::types::StacksEpochId;
use stacks_common::util::hash::to_hex;

use crate::vm::analysis::type_checker::v2_1::MAX_FUNCTION_PARAMETERS;
use crate::vm::errors::{ClarityEvalError, RuntimeCheckErrorKind, VmExecutionError};
use crate::vm::tests::test_clarity_versions;
use crate::vm::types::TypeSignature::{self, BoolType, IntType, SequenceType, UIntType};
use crate::vm::types::signatures::SequenceSubtype::{self, BufferType, StringType};
use crate::vm::types::signatures::StringSubtype::ASCII;
use crate::vm::types::{BufferLength, ListTypeData, StringSubtype, StringUTF8Length, Value};
use crate::vm::{ClarityVersion, execute, execute_v2, execute_v6, execute_with_parameters};

#[test]
fn test_simple_list_admission() {
    let defines = "(define-private (square (x int)) (* x x))
         (define-private (square-list (x (list 4 int))) (map square x))";
    let t1 = format!("{defines} (square-list (list 1 2 3 4))");
    let t2 = format!("{defines} (square-list (list))");
    let t3 = format!("{defines} (square-list (list 1 2 3 4 5))");

    let expected = Value::list_from(vec![
        Value::Int(1),
        Value::Int(4),
        Value::Int(9),
        Value::Int(16),
    ])
    .unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        execute(&t2).unwrap().unwrap()
    );
    let err = execute(&t3).unwrap_err();
    assert!(match err {
        ClarityEvalError::Vm(VmExecutionError::RuntimeCheck(
            RuntimeCheckErrorKind::TypeValueError(_, _),
        )) => true,
        _ => {
            eprintln!("Expected TypeError, but found: {err:?}");
            false
        }
    });
}

#[test]
fn test_index_of() {
    let good = [
        "(index-of (list 1 2 3 4 5 4) 100)",
        "(index-of (list 1 2 3 4 5 4) 4)",
        "(index-of \"abcd\" \"a\")",
        "(index-of u\"abcd\" u\"a\")",
        "(index-of 0xfedb 0xdb)",
        "(index-of \"abcd\" \"\")",
        "(index-of u\"abcd\" u\"\")",
        "(index-of 0xfedb 0x)",
        "(index-of \"abcd\" \"z\")",
        "(index-of u\"abcd\" u\"e\")",
        "(index-of 0xfedb 0x01)",
    ];

    let expected = [
        "none",
        "(some u3)",
        "(some u0)",
        "(some u0)",
        "(some u1)",
        "none",
        "none",
        "none",
        "none",
        "none",
        "none",
    ];

    for (good_test, expected) in good.iter().zip(expected.iter()) {
        assert_eq!(
            expected,
            &format!("{}", execute(good_test).unwrap().unwrap())
        );
    }

    let bad = [
        "(index-of 3 \"a\")",
        "(index-of 0xfedb \"a\")",
        "(index-of u\"a\" \"a\")",
        "(index-of \"a\" u\"a\")",
    ];

    let bad_expected = [
        RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "Expected sequence: {}",
            TypeSignature::IntType
        )),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::BUFFER_MIN),
            execute("\"a\"").unwrap().unwrap().to_error_string(),
        ),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::STRING_UTF8_MIN),
            execute("\"a\"").unwrap().unwrap().to_error_string(),
        ),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::STRING_ASCII_MIN),
            execute("u\"a\"").unwrap().unwrap().to_error_string(),
        ),
    ];

    for (bad_test, expected) in bad.iter().zip(bad_expected.iter()) {
        match execute(bad_test).unwrap_err() {
            ClarityEvalError::Vm(VmExecutionError::RuntimeCheck(runtime_check_err)) => {
                assert_eq!(&runtime_check_err, expected);
            }
            _ => unreachable!("Should have raised unchecked errors"),
        }
    }
}

#[test]
fn test_element_at() {
    let good = [
        "(element-at (list 1 2 3 4 5) u100)",
        "(element-at \"abcd\" u100)",
        "(element-at 0xfedb u100)",
        "(element-at u\"abcd\" u100)",
        "(element-at (list 1 2 3 4 5) u0)",
        "(element-at (list 1 2 3 4 5) u1)",
        "(element-at \"abcd\" u1)",
        "(element-at 0xfedb u1)",
        "(element-at u\"abcd\" u1)",
    ];

    let expected = [
        "none",
        "none",
        "none",
        "none",
        "(some 1)",
        "(some 2)",
        "(some \"b\")",
        "(some 0xdb)",
        "(some u\"b\")",
    ];

    for (good_test, expected) in good.iter().zip(expected.iter()) {
        assert_eq!(
            expected,
            &format!("{}", execute(good_test).unwrap().unwrap())
        );
    }

    let bad = ["(element-at 3 u1)", "(element-at (list 1 2 3) 1)"];

    let bad_expected = [
        RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "Expected sequence: {}",
            TypeSignature::IntType
        )),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::UIntType),
            Value::Int(1).to_error_string(),
        ),
    ];

    for (bad_test, expected) in bad.iter().zip(bad_expected.iter()) {
        match execute(bad_test).unwrap_err() {
            ClarityEvalError::Vm(VmExecutionError::RuntimeCheck(runtime_check_err)) => {
                assert_eq!(&runtime_check_err, expected);
            }
            _ => unreachable!("Should have raised unchecked errors"),
        }
    }
}

#[test]
fn test_string_ascii_admission() {
    let defines = "(define-private (set-name (x (string-ascii 11))) x)";
    let t1 = format!("{defines} (set-name \"hello world\")");

    let expected = Value::string_ascii_from_bytes("hello world".into()).unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
}

#[test]
fn test_string_utf8_admission() {
    let defines = "(define-private (set-name (x (string-utf8 14))) x)";
    let t1 = format!("{defines} (set-name u\"my 2 \\u{{c2a2}} (cents)\")");

    let expected =
        Value::string_utf8_from_string_utf8_literal("my 2 \\u{c2a2} (cents)".into()).unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
}

#[test]
fn test_string_ascii_map() {
    let defines =
        "(define-private (replace-a-with-b (c (string-ascii 1))) (if (is-eq \"a\" c) \"b\" c))";
    let t1 = format!("{defines} (map replace-a-with-b \"ababab\")");

    let expected = Value::list_from(vec![
        Value::string_ascii_from_bytes("b".into()).unwrap(),
        Value::string_ascii_from_bytes("b".into()).unwrap(),
        Value::string_ascii_from_bytes("b".into()).unwrap(),
        Value::string_ascii_from_bytes("b".into()).unwrap(),
        Value::string_ascii_from_bytes("b".into()).unwrap(),
        Value::string_ascii_from_bytes("b".into()).unwrap(),
    ])
    .unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
}

#[test]
fn test_string_utf8_map() {
    let defines = "(define-private (replace-dog-with-fox (c (string-utf8 1))) (if (is-eq u\"\\u{1F436}\" c) u\"\\u{1F98A}\" c))";
    let t1 = format!("{defines} (map replace-dog-with-fox u\"fox \\u{{1F436}}\")");

    let expected = Value::list_from(vec![
        Value::string_utf8_from_bytes("f".into()).unwrap(),
        Value::string_utf8_from_bytes("o".into()).unwrap(),
        Value::string_utf8_from_bytes("x".into()).unwrap(),
        Value::string_utf8_from_bytes(" ".into()).unwrap(),
        Value::string_utf8_from_bytes("🦊".into()).unwrap(),
    ])
    .unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
}

#[test]
fn test_string_ascii_filter() {
    let defines = "(define-private (remove-a (c (string-ascii 1))) (not (is-eq \"a\" c)))";
    let t1 = format!("{defines} (filter remove-a \"ababab\")");

    let expected = Value::string_ascii_from_bytes("bbb".into()).unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
}

#[test]
fn test_string_utf8_filter() {
    let defines = "(define-private (keep-dog (c (string-utf8 1))) (is-eq u\"\\u{1F436}\" c))";
    let t1 = format!("{defines} (filter keep-dog u\"fox \\u{{1F98A}} \\u{{1F436}}\")");

    let expected = Value::string_utf8_from_bytes("🐶".into()).unwrap();

    assert_eq!(expected, execute(&t1).unwrap().unwrap());
}

#[test]
fn test_string_ascii_fold() {
    let test1 =
        "(define-private (merge-str (x (string-ascii 1)) (acc (string-ascii 5))) (concat acc x))
        (fold merge-str (list \"A\" \"B\" \"C\" \"D\" \"E\") \"\")";

    let expected = Value::string_ascii_from_bytes("ABCDE".into()).unwrap();

    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_string_utf8_fold() {
    let test1 =
        "(define-private (build-face-palm (x (string-utf8 1)) (acc (string-utf8 5))) (concat acc x))
         (fold build-face-palm (list u\"\\u{1F926}\" u\"\\u{1F3FC}\" u\"\\u{200D}\" u\"\\u{2642}\" u\"\\u{FE0F}\") u\"\")";

    let expected = Value::string_utf8_from_bytes("🤦🏼‍♂️".into()).unwrap();

    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_string_ascii_concat() {
    let test1 = "(concat (concat \"A\" \"B\") \"C\")";

    let expected = Value::string_ascii_from_bytes("ABC".into()).unwrap();

    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_string_utf8_concat() {
    let test1 = "(concat (concat (concat (concat u\"\\u{1F926}\" u\"\\u{1F3FC}\") u\"\\u{200D}\") u\"\\u{2642}\") u\"\\u{FE0F}\")";

    let expected = Value::string_utf8_from_bytes("🤦🏼‍♂️".into()).unwrap();

    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_string_ascii_get_len() {
    let test1 = "(len \"ABCDE\")";
    let expected = Value::UInt(5);
    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_string_utf8_get_len() {
    let test1 = "(len u\"ABCDE\\u{1F926}\\u{1F3FC}\\u{200D}\\u{2642}\\u{FE0F}\")";
    let expected = Value::UInt(10);
    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_string_ascii_max_len() {
    let tests = [
        "(as-max-len? \"ABC\" u3)",
        "(as-max-len? \"ABC\" u2)",
        "(as-max-len? \"ABC\" u4)",
    ];

    let expected = [
        Value::some(Value::string_ascii_from_bytes("ABC".into()).unwrap()).unwrap(),
        Value::none(),
        Value::some(Value::string_ascii_from_bytes("ABC".into()).unwrap()).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }
}

#[test]
fn test_string_utf8_max_len() {
    let tests = [
        "(as-max-len? u\"ABCDE\\u{1F926}\\u{1F3FC}\\u{200D}\\u{2642}\\u{FE0F}\" u10)",
        "(as-max-len? u\"ABCDE\\u{1F926}\\u{1F3FC}\\u{200D}\\u{2642}\\u{FE0F}\" u9)",
        "(as-max-len? u\"ABCDE\\u{1F926}\\u{1F3FC}\\u{200D}\\u{2642}\\u{FE0F}\" u11)",
    ];

    let expected = [
        Value::some(Value::string_utf8_from_bytes("ABCDE🤦🏼‍♂️".into()).unwrap()).unwrap(),
        Value::none(),
        Value::some(Value::string_utf8_from_bytes("ABCDE🤦🏼‍♂️".into()).unwrap()).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }
}

#[test]
fn test_simple_map_list() {
    let test1 = "(define-private (square (x int)) (* x x))
         (map square (list 1 2 3 4))";

    let expected = Value::list_from(vec![
        Value::Int(1),
        Value::Int(4),
        Value::Int(9),
        Value::Int(16),
    ])
    .unwrap();

    assert_eq!(expected, execute(test1).unwrap().unwrap());

    // let's test lists of lists.
    let test2 = "(define-private (multiply (x int) (acc int)) (* x acc))
                 (define-private (multiply-all (x (list 10 int))) (fold multiply x 1))
                 (map multiply-all (list (list 1 1 1) (list 2 2 1) (list 3 3) (list 2 2 2 2)))";
    assert_eq!(expected, execute(test2).unwrap().unwrap());

    // let's test empty lists.
    let test2 = "(define-private (double (x int)) (* x 2))
                 (map double (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        execute(test2).unwrap().unwrap()
    );
}

/// Fixed variadic `map` behavior, gated to **Epoch 4.0** (see `special_map_v400`).
///
/// Iteration stops at the length of the *shortest* input sequence, so any
/// empty input sequence yields an empty result.
///
/// The legacy (buggy) behavior for Epoch [2.0 .. 3.4]
/// is pinned in [`test_variadic_map_list_pre_epoch40`].
#[test]
fn test_variadic_map_list() {
    // User functions
    // - 1 sequence: 1 empty, result empty.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: 2 empties, result empty.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list) (list))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: 1 empty and 1 not, result empty.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list) (list 10 20))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 3 sequences: 1 empty in between, result empty.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list 1 2 3) (list) (list 10 20))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: same length 4, result contains 4 elements.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list 5 10 1 2) (list 5 2 30 3))";
    let expected = Value::list_from(vec![
        Value::Int(25),
        Value::Int(20),
        Value::Int(30),
        Value::Int(6),
    ])
    .unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: same length 4 with different int types, result contains 4 elements.
    let test = "(define-private (u+ (a uint) (b int)) (+ a (to-uint b)))
        (map u+ (list u5 u10 u1 u2) (list 5 2 30 3))";
    let expected = Value::list_from(vec![
        Value::UInt(10),
        Value::UInt(12),
        Value::UInt(31),
        Value::UInt(5),
    ])
    .unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // Native functions
    // - 1 sequence: 1 empty, result empty.
    let test = "(map + (list))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: 2 empties, result empty.
    let test = "(map + (list) (list))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: 1 empty and 1 not, result empty.
    let test = "(map + (list) (list 10 20))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 3 sequences: 1 empty in between, result empty.
    let test = "(map + (list 1 2 3) (list) (list 10 20))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: last is longer, result contains 2 elements.
    let test = "(map + (list 5 10) (list 5 2 30 3))";
    let expected = Value::list_from(vec![Value::Int(10), Value::Int(12)]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 3 sequences: last is the longest, result contains 2 elements.
    let test = "(map + (list 1 2) (list 10 20 30) (list 100 200 300 400))";
    let expected = Value::list_from(vec![Value::Int(111), Value::Int(222)]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 3 sequences: last is the shortest, result contains 1 element.
    let test = "(map + (list 1 2) (list 10 20 30) (list 100))";
    let expected = Value::list_from(vec![Value::Int(111)]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // Special Functions
    // - 1 sequence: 1 empty, result empty.
    let test = "(map > (list))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: 2 empties, result empty.
    let test = "(map > (list) (list))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: 1 empty and 1 not, result empty.
    let test = "(map > (list) (list 10 20))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 3 sequences: 1 empty in between, result empty.
    let test = "(map > (list 1 2 3) (list) (list 10 20))";
    let expected = Value::list_from(vec![]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());

    // - 2 sequences: last is longer, result contains 2 elements.
    let test = "(map > (list 1 10) (list 2 3 4 5))";
    let expected = Value::list_from(vec![Value::Bool(false), Value::Bool(true)]).unwrap();
    assert_eq!(expected, execute_v6(test).unwrap().unwrap());
}

/// Legacy variadic `map` behavior for Epoch 2.0 .. 3.4 (see `special_map_v200`).
///
/// This pins the *buggy* pre-Epoch-4.0 behavior for consensus compatibility.
/// The iteration does not stop at the shortest sequence when
/// an earlier/interleaved sequence is empty.
/// The result is that mixing an empty sequence with a non-empty one
/// either:
///   - produces a spurious non-empty result (using the wrong elements), or
///   - errors with `IncorrectArgumentCount` when a strict-arity function is
///     applied with too few arguments,
///
/// where the fixed Epoch 4.0 behavior would return an empty list. Cases without
/// an empty input sequence are unaffected and match the fixed behavior.
///
/// Runs at Epoch 3.4, the last epoch before the fix activates
/// (see [`test_variadic_map_list`]).
#[test]
fn test_variadic_map_list_pre_epoch40() {
    let exec = |program: &str| {
        execute_with_parameters(
            program,
            ClarityVersion::Clarity5,
            StacksEpochId::Epoch34,
            false,
        )
    };

    // === Cases that match the fixed Epoch 4.0 behavior (no empty input) ===

    // User functions
    // - 1 sequence: 1 empty, result empty.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        exec(test).unwrap().unwrap()
    );

    // - 2 sequences: 2 empties, result empty.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list) (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        exec(test).unwrap().unwrap()
    );

    // - 2 sequences: same length 4, result contains 4 elements.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list 5 10 1 2) (list 5 2 30 3))";
    let expected = Value::list_from(vec![
        Value::Int(25),
        Value::Int(20),
        Value::Int(30),
        Value::Int(6),
    ])
    .unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // - 2 sequences: same length 4 with different int types, result contains 4 elements.
    let test = "(define-private (u+ (a uint) (b int)) (+ a (to-uint b)))
        (map u+ (list u5 u10 u1 u2) (list 5 2 30 3))";
    let expected = Value::list_from(vec![
        Value::UInt(10),
        Value::UInt(12),
        Value::UInt(31),
        Value::UInt(5),
    ])
    .unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // Native functions
    let test = "(map + (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        exec(test).unwrap().unwrap()
    );

    let test = "(map + (list) (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        exec(test).unwrap().unwrap()
    );

    // - 2 sequences: last is longer, result contains 2 elements.
    let test = "(map + (list 5 10) (list 5 2 30 3))";
    let expected = Value::list_from(vec![Value::Int(10), Value::Int(12)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // - 3 sequences: last is the longest, result contains 2 elements.
    let test = "(map + (list 1 2) (list 10 20 30) (list 100 200 300 400))";
    let expected = Value::list_from(vec![Value::Int(111), Value::Int(222)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // - 3 sequences: last is the shortest, result contains 1 element.
    let test = "(map + (list 1 2) (list 10 20 30) (list 100))";
    let expected = Value::list_from(vec![Value::Int(111)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // Special Functions
    let test = "(map > (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        exec(test).unwrap().unwrap()
    );

    let test = "(map > (list) (list))";
    assert_eq!(
        Value::list_from(vec![]).unwrap(),
        exec(test).unwrap().unwrap()
    );

    // - 2 sequences: last is longer, result contains 2 elements.
    let test = "(map > (list 1 10) (list 2 3 4 5))";
    let expected = Value::list_from(vec![Value::Bool(false), Value::Bool(true)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // === Cases that DIVERGE from the fixed behavior (empty input sequence) ===
    // The fixed Epoch 4.0 behavior returns an empty list for all of these.

    // - 2 sequences (user fn): 1 empty and 1 not. The off-by-one applies the
    //   function with a single argument, so strict arity fails.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list) (list 10 20))";
    assert_eq!(
        exec(test).unwrap_err(),
        RuntimeCheckErrorKind::IncorrectArgumentCount(2, 1).into()
    );

    // - 3 sequences (user fn): 1 empty in between. A spurious 1-element list is
    //   produced from the first elements of the non-empty sequences.
    let test = "(define-private (area (w int) (h int)) (* w h))
        (map area (list 1 2 3) (list) (list 10 20))";
    let expected = Value::list_from(vec![Value::Int(10)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // - 2 sequences (native +): 1 empty and 1 not. `(+ 10)` = 10, spuriously.
    let test = "(map + (list) (list 10 20))";
    let expected = Value::list_from(vec![Value::Int(10)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // - 3 sequences (native +): 1 empty in between. `(+ 1 10)` = 11, spuriously.
    let test = "(map + (list 1 2 3) (list) (list 10 20))";
    let expected = Value::list_from(vec![Value::Int(11)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());

    // - 2 sequences (special >): 1 empty and 1 not. `>` requires 2 args.
    let test = "(map > (list) (list 10 20))";
    assert_eq!(
        exec(test).unwrap_err(),
        RuntimeCheckErrorKind::IncorrectArgumentCount(2, 1).into()
    );

    // - 3 sequences (special >): 1 empty in between. `(> 1 10)` = false, spuriously.
    let test = "(map > (list 1 2 3) (list) (list 10 20))";
    let expected = Value::list_from(vec![Value::Bool(false)]).unwrap();
    assert_eq!(expected, exec(test).unwrap().unwrap());
}

#[test]
fn test_simple_map_append() {
    let tests = [
        "(append (list 1 2) 6)",
        "(append (list) 1)",
        "(append (append (list) 1) 2)",
    ];

    let expected = [
        Value::list_from(vec![Value::Int(1), Value::Int(2), Value::Int(6)]).unwrap(),
        Value::list_from(vec![Value::Int(1)]).unwrap(),
        Value::list_from(vec![Value::Int(1), Value::Int(2)]).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }

    assert_eq!(
        execute("(append (append (list) 1) u2)").unwrap_err(),
        RuntimeCheckErrorKind::TypeError(Box::new(IntType), Box::new(UIntType)).into()
    );
}

#[test]
fn test_slice_list() {
    let tests = [
        "(slice? (list 2 3 4 5 6 7 8) u0 u3)",
        "(slice? (list u0 u1 u2 u3 u4) u3 u2)",
        "(slice? (list 2 3 4 5 6 7 8) u0 u0)",
        "(slice? (list u2 u3 u4 u5 u6 u7 u8) u3 u5)",
        "(slice? (list u2 u3 u4 u5 u6 u7 u8) u1 u11)",
    ];

    let expected = [
        Value::some(Value::list_from(vec![Value::Int(2), Value::Int(3), Value::Int(4)]).unwrap())
            .unwrap(),
        Value::none(),
        Value::some(Value::list_from(vec![]).unwrap()).unwrap(),
        Value::some(Value::list_from(vec![Value::UInt(5), Value::UInt(6)]).unwrap()).unwrap(),
        Value::none(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }
}

#[test]
fn test_slice_buff() {
    let tests = [
        "(slice? 0x000102030405 u0 u3)",
        "(slice? 0x000102030405 u3 u3)",
        "(slice? 0x000102030405 u3 u6)",
        "(slice? 0x000102030405 u3 u10)",
        "(slice? 0x000102030405 u10 u3)",
        "(slice? 0x u2 u3)",
    ];

    let expected = [
        Value::some(Value::buff_from(vec![0, 1, 2]).unwrap()).unwrap(),
        Value::some(Value::buff_from(vec![]).unwrap()).unwrap(),
        Value::some(Value::buff_from(vec![3, 4, 5]).unwrap()).unwrap(),
        Value::none(),
        Value::none(),
        Value::none(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }
}

#[test]
fn test_slice_ascii() {
    let tests = [
        "(slice? \"blockstack\" u0 u5)",
        "(slice? \"blockstack\" u5 u10)",
        "(slice? \"blockstack\" u5 u5)",
        "(slice? \"blockstack\" u5 u0)",
        "(slice? \"blockstack\" u11 u3)",
        "(slice? \"\" u0 u3)",
    ];

    let expected = [
        Value::some(Value::string_ascii_from_bytes("block".into()).unwrap()).unwrap(),
        Value::some(Value::string_ascii_from_bytes("stack".into()).unwrap()).unwrap(),
        Value::some(Value::string_ascii_from_bytes("".into()).unwrap()).unwrap(),
        Value::none(),
        Value::none(),
        Value::none(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }
}

#[test]
fn test_slice_utf8() {
    let tests = [
        "(slice? u\"hello \\u{1F98A}\" u0 u5)",
        "(slice? u\"hello \\u{1F98A}\" u6 u7)",
        "(slice? u\"hello \\u{1F98A}\" u6 u6)",
        "(slice? u\"hello \\u{1F98A}\" u11 u4)",
        "(slice? u\"\" u0 u3)",
    ];

    let expected = [
        Value::some(Value::string_utf8_from_bytes("hello".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("🦊".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("".into()).unwrap()).unwrap(),
        Value::none(),
        Value::none(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }
}

#[test]
fn test_slice_type_errors() {
    let bad_type_error = RuntimeCheckErrorKind::Unreachable("Bad type construction".into()).into();
    assert_eq!(execute_v2("(slice? 3 u0 u1)").unwrap_err(), bad_type_error);

    assert_eq!(
        execute_v2("(slice? (list 1 2 3) 0 u1)").unwrap_err(),
        bad_type_error
    );

    assert_eq!(
        execute_v2("(slice? (list 1 2 3) u0 1)").unwrap_err(),
        bad_type_error
    );
}

#[test]
fn test_simple_list_concat() {
    let tests = [
        "(concat (list 1 2) (list 4 8))",
        "(concat (list 1) (list 4 8))",
        "(concat (list 1 9 0) (list))",
        "(concat (list) (list))",
        "(concat (list (list 1) (list 2)) (list (list 3)))",
    ];

    let expected = [
        Value::list_from(vec![
            Value::Int(1),
            Value::Int(2),
            Value::Int(4),
            Value::Int(8),
        ])
        .unwrap(),
        Value::list_from(vec![Value::Int(1), Value::Int(4), Value::Int(8)]).unwrap(),
        Value::list_from(vec![Value::Int(1), Value::Int(9), Value::Int(0)]).unwrap(),
        Value::list_from(vec![]).unwrap(),
        Value::list_from(vec![
            Value::list_from(vec![Value::Int(1)]).unwrap(),
            Value::list_from(vec![Value::Int(2)]).unwrap(),
            Value::list_from(vec![Value::Int(3)]).unwrap(),
        ])
        .unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }

    assert_eq!(
        execute("(concat (list 1) (list u4 u8))").unwrap_err(),
        RuntimeCheckErrorKind::TypeError(
            Box::new(TypeSignature::IntType),
            Box::new(TypeSignature::UIntType)
        )
        .into()
    );

    assert_eq!(
        execute("(concat (list 1) 3)").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "Expected sequence: {}",
            TypeSignature::IntType
        ))
        .into()
    );

    assert_eq!(
        execute("(concat (list 1) \"1\")").unwrap_err(),
        RuntimeCheckErrorKind::TypeError(
            Box::new(SequenceType(SequenceSubtype::ListType(
                ListTypeData::new_list(TypeSignature::IntType, 1).unwrap()
            ))),
            Box::new(TypeSignature::STRING_ASCII_MIN)
        )
        .into()
    );
}

#[test]
fn test_simple_buff_concat() {
    let tests = [
        "(concat 0x303132 0x3334)",
        "(concat 0x00 0x00)",
        "(concat 0x00 0x31)",
        "(concat 0x31 0x00)",
    ];

    let expected = [
        Value::buff_from(vec![48, 49, 50, 51, 52]).unwrap(),
        Value::buff_from(vec![0, 0]).unwrap(),
        Value::buff_from(vec![0, 49]).unwrap(),
        Value::buff_from(vec![49, 0]).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }

    assert_eq!(
        execute("(concat 0x31 3)").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!(
            "Expected sequence: {}",
            TypeSignature::IntType
        ))
        .into()
    );

    assert_eq!(
        execute("(concat 0x31 (list 1))").unwrap_err(),
        RuntimeCheckErrorKind::TypeError(
            Box::new(TypeSignature::BUFFER_MIN),
            Box::new(TypeSignature::SequenceType(SequenceSubtype::ListType(
                ListTypeData::new_list(TypeSignature::IntType, 1).unwrap()
            )))
        )
        .into()
    );
}

/// Variadic `concat` was introduced in Clarity 6 / Epoch 4.0. Earlier versions
/// require exactly 2 arguments. These tests exercise both the new variadic
/// runtime behavior and the version gate.
#[test]
fn test_variadic_concat_buff() {
    // Variadic over buffers
    assert_eq!(
        Value::buff_from(vec![0x01, 0x02, 0x03, 0x04, 0x05, 0x06]).unwrap(),
        execute_v6("(concat 0x01 0x02 0x03 0x04 0x05 0x06)")
            .unwrap()
            .unwrap()
    );
    assert_eq!(
        Value::buff_from(vec![0xaa, 0xbb, 0xcc]).unwrap(),
        execute_v6("(concat 0xaa 0xbb 0xcc)").unwrap().unwrap()
    );
    // 2-arg case is unchanged
    assert_eq!(
        Value::buff_from(vec![0x30, 0x31, 0x32, 0x33, 0x34]).unwrap(),
        execute_v6("(concat 0x303132 0x3334)").unwrap().unwrap()
    );
}

#[test]
fn test_variadic_concat_string_ascii() {
    assert_eq!(
        execute_v6("(concat \"Hello \" \"Stacks \" \"World!\")")
            .unwrap()
            .unwrap(),
        execute_v6("\"Hello Stacks World!\"").unwrap().unwrap()
    );
}

#[test]
fn test_variadic_concat_string_utf8() {
    // Existing test_string_utf8_concat builds the same emoji from 5 binary
    // concats — here we do it in one variadic call to verify the v400 path
    // preserves UTF-8 semantics.
    let variadic =
        "(concat u\"\\u{1F926}\" u\"\\u{1F3FC}\" u\"\\u{200D}\" u\"\\u{2642}\" u\"\\u{FE0F}\")";
    let expected = Value::string_utf8_from_bytes("🤦🏼‍♂️".into()).unwrap();
    assert_eq!(expected, execute_v6(variadic).unwrap().unwrap());
}

#[test]
fn test_variadic_concat_list() {
    let expected = Value::list_from(vec![
        Value::Int(1),
        Value::Int(2),
        Value::Int(3),
        Value::Int(4),
        Value::Int(5),
        Value::Int(6),
    ])
    .unwrap();
    assert_eq!(
        expected,
        execute_v6("(concat (list 1 2) (list 3 4) (list 5 6))")
            .unwrap()
            .unwrap()
    );
}

#[test]
fn test_variadic_concat_nested_list() {
    // Lists of lists exercise the recursive `least_supertype` path during
    // type checking and the recursive sequence-concat at runtime.
    let expected = Value::list_from(vec![
        Value::list_from(vec![Value::Int(1)]).unwrap(),
        Value::list_from(vec![Value::Int(2)]).unwrap(),
        Value::list_from(vec![Value::Int(3)]).unwrap(),
    ])
    .unwrap();
    assert_eq!(
        expected,
        execute_v6("(concat (list (list 1)) (list (list 2)) (list (list 3)))")
            .unwrap()
            .unwrap()
    );
}

#[test]
fn test_variadic_concat_many_args() {
    // 16 args — exercises the two-pass loop with a non-trivial N, including
    // the pre-reserve path on the accumulator. With per-step cost charging
    // this would have charged ~O(N^2) cost; with the two-pass linear-cost
    // approach we charge O(total_len) once.
    let snippet = "(concat \
        0x01 0x02 0x03 0x04 0x05 0x06 0x07 0x08 \
        0x09 0x0a 0x0b 0x0c 0x0d 0x0e 0x0f 0x10)";
    let expected = Value::buff_from((1u8..=16).collect()).unwrap();
    assert_eq!(expected, execute_v6(snippet).unwrap().unwrap());
}

#[test]
fn test_variadic_concat_empty_sequences() {
    // Empty sequences in any position should be transparent. This regression-
    // guards the fold against any path that special-cases empty inputs.
    assert_eq!(
        Value::buff_from(vec![0x01, 0x02]).unwrap(),
        execute_v6("(concat 0x 0x01 0x 0x02 0x)").unwrap().unwrap()
    );
    assert_eq!(
        Value::list_from(vec![Value::Int(1), Value::Int(2)]).unwrap(),
        execute_v6("(concat (list) (list 1) (list) (list 2) (list))")
            .unwrap()
            .unwrap()
    );
}

#[test]
fn test_variadic_concat_arity_rejected() {
    // 0 args
    let err = format!("{:?}", execute_v6("(concat)").unwrap_err());
    assert!(
        err.contains("Requires at least args: 2 got 0"),
        "expected an arity error for (concat), got: {err}"
    );

    // 1 arg
    let err = format!("{:?}", execute_v6("(concat 0xaa)").unwrap_err());
    assert!(
        err.contains("Requires at least args: 2 got 1"),
        "expected an arity error for (concat x), got: {err}"
    );
}

#[test]
fn test_variadic_concat_mixed_types_rejected() {
    // Concatenating a buffer onto a list shouldn't type-check.
    let err = execute_v6("(concat 0x01 (list 2))").unwrap_err();
    let err_str = format!("{err:?}");
    assert!(
        err_str.contains("TypeError")
            || err_str.contains("ExpectedSequence")
            || err_str.contains("Expected sequence"),
        "expected a type error mixing buff and list, got: {err_str}"
    );
}

#[test]
fn test_variadic_concat_rejected_pre_clarity_6() {
    // A Clarity 1 contract at any pre-Clarity-6 epoch should be rejected at
    // analysis time when it passes more than two args to `concat`.
    let err = execute("(concat 0x01 0x02 0x03)").unwrap_err();
    let err_str = format!("{err:?}");
    assert!(
        err_str.contains("IncorrectArgumentCount") || err_str.contains("ArgumentCount"),
        "expected an argument-count error, got: {err_str}"
    );

    // Same for Clarity 2 at Epoch 2.1.
    let err = execute_v2("(concat 0x01 0x02 0x03)").unwrap_err();
    let err_str = format!("{err:?}");
    assert!(
        err_str.contains("IncorrectArgumentCount") || err_str.contains("ArgumentCount"),
        "expected an argument-count error under v2, got: {err_str}"
    );
}

#[test]
fn test_simple_list_replace_at() {
    let tests = [
        "(replace-at? (list 1 2) u1 4)",
        "(replace-at? (list 1) u0 10)",
        "(replace-at? (list 1 9 0 5) u3 6)",
        "(replace-at? (list 4 5 6 7 8) u2 11)",
        "(replace-at? (list (list 1) (list 2)) u0 (list 33))",
        "(replace-at? (list (list 1 2) (list 3 4)) u0 (list 0))",
        "(replace-at? (list (list 1 2 3)) u0 (list 0))",
    ];

    let expected = [
        Value::some(Value::list_from(vec![Value::Int(1), Value::Int(4)]).unwrap()).unwrap(),
        Value::some(Value::list_from(vec![Value::Int(10)]).unwrap()).unwrap(),
        Value::some(
            Value::list_from(vec![
                Value::Int(1),
                Value::Int(9),
                Value::Int(0),
                Value::Int(6),
            ])
            .unwrap(),
        )
        .unwrap(),
        Value::some(
            Value::list_from(vec![
                Value::Int(4),
                Value::Int(5),
                Value::Int(11),
                Value::Int(7),
                Value::Int(8),
            ])
            .unwrap(),
        )
        .unwrap(),
        Value::some(
            Value::list_from(vec![
                Value::list_from(vec![Value::Int(33)]).unwrap(),
                Value::list_from(vec![Value::Int(2)]).unwrap(),
            ])
            .unwrap(),
        )
        .unwrap(),
        Value::some(
            Value::list_from(vec![
                Value::list_from(vec![Value::Int(0)]).unwrap(),
                Value::list_from(vec![Value::Int(3), Value::Int(4)]).unwrap(),
            ])
            .unwrap(),
        )
        .unwrap(),
        Value::some(
            Value::list_from(vec![Value::list_from(vec![Value::Int(0)]).unwrap()]).unwrap(),
        )
        .unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }

    let bad_tests = [
        // index is out of bounds
        "(replace-at? (list 1 2) u3 4)",
        // the sequence is length 0, so the index is out of bounds
        "(replace-at? (list) u0 6)",
    ];

    let bad_expected = [Value::none(), Value::none()];

    for (bad_test, bad_expected) in bad_tests.iter().zip(bad_expected.iter()) {
        assert_eq!(bad_expected.clone(), execute_v2(bad_test).unwrap().unwrap());
    }

    // The sequence input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? 0 u0 (list 0))").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!("Expected sequence: {IntType}")).into()
    );

    // The type of the index should be uint.
    assert_eq!(
        execute_v2("(replace-at? (list 1) 0 0)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(Box::new(UIntType), Value::Int(0).to_error_string())
            .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? (list 2 3) u0 true)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(IntType),
            Value::Bool(true).to_error_string()
        )
        .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? (list 2 3) u0 0x00)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(IntType),
            Value::buff_from_byte(0).to_error_string()
        )
        .into()
    );
}

#[test]
fn test_simple_buff_replace_at() {
    let tests = [
        "(replace-at? 0x3031 u1 0x44)",
        "(replace-at? 0x00 u0 0x11)",
        "(replace-at? 0x00112233 u3 0x44)",
        "(replace-at? 0x00112233 u1 0x44)",
    ];

    let expected = [
        Value::some(Value::buff_from(vec![48, 68]).unwrap()).unwrap(),
        Value::some(Value::buff_from(vec![17]).unwrap()).unwrap(),
        Value::some(Value::buff_from(vec![0, 17, 34, 68]).unwrap()).unwrap(),
        Value::some(Value::buff_from(vec![0, 68, 34, 51]).unwrap()).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }

    let bad_tests = [
        // index is out of bounds
        "(replace-at? 0x0022 u3 0x44)",
        // the sequence is length 0, so the index is out of bounds
        "(replace-at? 0x u0 0x11)",
    ];

    let bad_expected = [Value::none(), Value::none()];

    for (bad_test, bad_expected) in bad_tests.iter().zip(bad_expected.iter()) {
        assert_eq!(bad_expected.clone(), execute_v2(bad_test).unwrap().unwrap());
    }

    // The sequence input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? 33 u0 0x00)").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!("Expected sequence: {IntType}")).into()
    );

    // The type of the index should be uint.
    assert_eq!(
        execute_v2("(replace-at? 0x002244 0 0x99)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(Box::new(UIntType), Value::Int(0).to_error_string())
            .into()
    );

    // The element input has the wrong type
    let buff_len = BufferLength::try_from(1u32).unwrap();
    assert_eq!(
        execute_v2("(replace-at? 0x445522 u0 55)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(SequenceType(BufferType(buff_len.clone()))),
            Value::Int(55).to_error_string()
        )
        .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? 0x445522 u0 (list 5))").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(SequenceType(BufferType(buff_len.clone()))),
            Value::list_from(vec![Value::Int(5)])
                .unwrap()
                .to_error_string()
        )
        .into()
    );

    // The element input has the wrong type (not length 1)
    assert_eq!(
        execute_v2("(replace-at? 0x445522 u0 0x0044)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(SequenceType(BufferType(buff_len))),
            Value::buff_from(vec![0, 68]).unwrap().to_error_string()
        )
        .into()
    );
}

#[test]
fn test_simple_string_ascii_replace_at() {
    let tests = [
        "(replace-at? \"ab\" u1 \"c\")",
        "(replace-at? \"a\" u0 \"c\")",
        "(replace-at? \"abcd\" u3 \"e\")",
        "(replace-at? \"abcd\" u1 \"e\")",
    ];

    let expected = [
        Value::some(Value::string_ascii_from_bytes("ac".into()).unwrap()).unwrap(),
        Value::some(Value::string_ascii_from_bytes("c".into()).unwrap()).unwrap(),
        Value::some(Value::string_ascii_from_bytes("abce".into()).unwrap()).unwrap(),
        Value::some(Value::string_ascii_from_bytes("aecd".into()).unwrap()).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }

    let bad_tests = [
        // index is out of bounds
        "(replace-at? \"ab\" u3 \"c\")",
        // the sequence is length 0, so the index is out of bounds
        "(replace-at? \"\" u0 \"a\")",
    ];

    let bad_expected = [Value::none(), Value::none()];

    for (bad_test, bad_expected) in bad_tests.iter().zip(bad_expected.iter()) {
        assert_eq!(bad_expected.clone(), execute_v2(bad_test).unwrap().unwrap());
    }

    // The sequence input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? 33 u0 \"c\")").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!("Expected sequence: {IntType}")).into()
    );

    // The type of the index should be uint.
    assert_eq!(
        execute_v2("(replace-at? \"abc\" 0 \"c\")").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(Box::new(UIntType), Value::Int(0).to_error_string())
            .into()
    );

    // The element input has the wrong type
    let buff_len = BufferLength::try_from(1u32).unwrap();
    assert_eq!(
        execute_v2("(replace-at? \"abc\" u0 55)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(SequenceType(StringType(ASCII(buff_len.clone())))),
            Value::Int(55).to_error_string()
        )
        .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? \"abc\" u0 0x00)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(SequenceType(StringType(ASCII(buff_len.clone())))),
            Value::buff_from_byte(0).to_error_string()
        )
        .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? \"abc\" u0 \"de\")").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(SequenceType(StringType(ASCII(buff_len)))),
            Value::string_ascii_from_bytes("de".into())
                .unwrap()
                .to_error_string()
        )
        .into()
    );
}

#[test]
fn test_simple_string_utf8_replace_at() {
    let tests = [
        "(replace-at? u\"ab\" u1 u\"c\")",
        "(replace-at? u\"a\" u0 u\"c\")",
        "(replace-at? u\"abcd\" u3 u\"e\")",
        "(replace-at? u\"abcd\" u1 u\"e\")",
        "(replace-at? u\"hello\\u{1F98A}\" u5 u\"e\")",
        "(replace-at? u\"hello\\u{1F98A}\" u2 u\"e\")",
    ];

    let expected = [
        Value::some(Value::string_utf8_from_bytes("ac".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("c".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("abce".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("aecd".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("helloe".into()).unwrap()).unwrap(),
        Value::some(Value::string_utf8_from_bytes("heelo🦊".into()).unwrap()).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute_v2(test).unwrap().unwrap());
    }

    let bad_tests = [
        // index is out of bounds
        "(replace-at? u\"ab\" u3 u\"c\")",
        // the sequence is length 0, so the index is out of bounds
        "(replace-at? u\"\" u0 u\"a\")",
    ];

    let bad_expected = [Value::none(), Value::none()];

    for (bad_test, bad_expected) in bad_tests.iter().zip(bad_expected.iter()) {
        assert_eq!(bad_expected.clone(), execute_v2(bad_test).unwrap().unwrap());
    }

    // The sequence input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? 33 u0 u\"c\")").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!("Expected sequence: {IntType}")).into()
    );

    // The type of the index should be uint.
    assert_eq!(
        execute_v2("(replace-at? u\"abc\" 0 u\"c\")").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(Box::new(UIntType), Value::Int(0).to_error_string())
            .into()
    );

    // The element input has the wrong type
    let str_len = StringUTF8Length::try_from(1u32).unwrap();
    assert_eq!(
        execute_v2("(replace-at? u\"abc\" u0 55)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::SequenceType(StringType(
                StringSubtype::UTF8(str_len.clone())
            ))),
            Value::Int(55).to_error_string()
        )
        .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? u\"abc\" u0 0x00)").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::SequenceType(StringType(
                StringSubtype::UTF8(str_len.clone())
            ))),
            Value::buff_from_byte(0).to_error_string()
        )
        .into()
    );

    // The element input has the wrong type
    assert_eq!(
        execute_v2("(replace-at? u\"abc\" u0 u\"de\")").unwrap_err(),
        RuntimeCheckErrorKind::TypeValueError(
            Box::new(TypeSignature::SequenceType(StringType(
                StringSubtype::UTF8(str_len)
            ))),
            Value::string_utf8_from_string_utf8_literal("de".to_string())
                .unwrap()
                .to_error_string()
        )
        .into()
    );
}

/// A zero-length `replace-at?` element raises `SequenceElementArityMismatch` in
/// every epoch; it is rejectable (block-invalidating) before 4.1 and an ordinary
/// includable failure after. Lists are exempt in all epochs.
#[rstest]
#[case::epoch21(ClarityVersion::Clarity2, StacksEpochId::Epoch21, true)]
#[case::epoch40(ClarityVersion::Clarity6, StacksEpochId::Epoch40, true)]
#[case::epoch41(ClarityVersion::latest(), StacksEpochId::Epoch41, false)]
fn test_replace_at_empty_element(
    #[case] version: ClarityVersion,
    #[case] epoch: StacksEpochId,
    #[case] expect_rejectable: bool,
) {
    let exec = |program: &str| execute_with_parameters(program, version, epoch, false);

    let arity_mismatch: ClarityEvalError = RuntimeCheckErrorKind::SequenceElementArityMismatch {
        expected: 1,
        found: 0,
    }
    .into();
    for snippet in [
        "(replace-at? 0x0102 u0 0x)",
        "(replace-at? \"ab\" u0 \"\")",
        "(replace-at? u\"ab\" u0 u\"\")",
        // A non-literal `(buff 1)`-typed expression holding an empty value hits
        // the same check.
        "(replace-at? 0x0102 u0 (unwrap-panic (as-max-len? 0x u1)))",
    ] {
        assert_eq!(exec(snippet).unwrap_err(), arity_mismatch);
    }

    // Same error in every epoch; only the disposition flips at 4.1.
    let ClarityEvalError::Vm(VmExecutionError::RuntimeCheck(kind)) =
        exec("(replace-at? 0x0102 u0 0x)").unwrap_err()
    else {
        panic!("expected a runtime check error");
    };
    assert_eq!(kind.rejectable_in_epoch(epoch), expect_rejectable);

    // An out-of-bounds index still returns `none` before the element is checked.
    assert_eq!(
        exec("(replace-at? 0x0102 u5 0x)").unwrap().unwrap(),
        Value::none()
    );

    // A too-long element raises the same `TypeValueError` in every epoch.
    let too_long: ClarityEvalError = RuntimeCheckErrorKind::TypeValueError(
        Box::new(SequenceType(BufferType(
            BufferLength::try_from(1u32).unwrap(),
        ))),
        Value::buff_from(vec![0, 68]).unwrap().to_error_string(),
    )
    .into();
    assert_eq!(
        exec("(replace-at? 0x445522 u0 0x0044)").unwrap_err(),
        too_long
    );

    // Lists are exempt from the arity check: an empty list element is valid.
    let expected_list = Value::some(
        Value::list_from(vec![
            Value::list_from(vec![]).unwrap(),
            Value::list_from(vec![Value::Int(2)]).unwrap(),
        ])
        .unwrap(),
    )
    .unwrap();
    assert_eq!(
        exec("(replace-at? (list (list 1) (list 2)) u0 (list))")
            .unwrap()
            .unwrap(),
        expected_list
    );
}

#[test]
fn test_simple_buff_assert_max_len() {
    let tests = [
        "(as-max-len? 0x313233 u3)",
        "(as-max-len? 0x313233 u2)",
        "(as-max-len? 0x313233 u5)",
    ];

    let expected = [
        Value::some(Value::buff_from(vec![49, 50, 51]).unwrap()).unwrap(),
        Value::none(),
        Value::some(Value::buff_from(vec![49, 50, 51]).unwrap()).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }

    assert_eq!(
        execute("(as-max-len? 0x313233)").unwrap_err(),
        RuntimeCheckErrorKind::IncorrectArgumentCount(2, 1).into()
    );

    assert_eq!(
        execute("(as-max-len? 0x313233 3)").unwrap_err(),
        RuntimeCheckErrorKind::TypeError(Box::new(UIntType), Box::new(IntType)).into()
    );

    assert_eq!(
        execute("(as-max-len? 1 u3)").unwrap_err(),
        RuntimeCheckErrorKind::Unreachable(bounded_format!("Expected sequence: {IntType}")).into()
    );

    assert_eq!(
        execute("(as-max-len? 0x313233 0x31)").unwrap_err(),
        RuntimeCheckErrorKind::TypeError(
            Box::new(UIntType),
            Box::new(SequenceType(SequenceSubtype::BufferType(
                1_u32.try_into().unwrap()
            )))
        )
        .into()
    );
}

#[test]
fn test_simple_list_assert_max_len() {
    let tests = [
        "(as-max-len? (list 1 2 3) u3)",
        "(as-max-len? (list 1 2 3) u2)",
        "(as-max-len? (list 1 2 3) u5)",
    ];

    let expected = [
        Value::some(Value::list_from(vec![Value::Int(1), Value::Int(2), Value::Int(3)]).unwrap())
            .unwrap(),
        Value::none(),
        Value::some(Value::list_from(vec![Value::Int(1), Value::Int(2), Value::Int(3)]).unwrap())
            .unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }
}

#[test]
fn test_simple_map_buffer() {
    let test1 = "(define-private (incr (x (buff 1))) 0x31)
         (map incr 0x30303030)";

    let expected = Value::list_from(vec![
        Value::buff_from(vec![49]).unwrap(),
        Value::buff_from(vec![49]).unwrap(),
        Value::buff_from(vec![49]).unwrap(),
        Value::buff_from(vec![49]).unwrap(),
    ])
    .unwrap();
    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_simple_filter_list() {
    let test1 = "(define-private (test (x int)) (is-eq 0 (mod x 2)))
                 (filter test (list 1 2 3 4 5))";

    let bad_tests = [
        "(filter 123 (list 123))",   // must have function name supplied
        "(filter not (list 123) 3)", // must be 2 args
        "(filter +)",                // must be 2 args
        "(filter not false)",        // must supply list
        "(filter - (list 1 2 3))",
    ]; // must return bool

    let expected = Value::list_from(vec![Value::Int(2), Value::Int(4)]).unwrap();

    assert_eq!(expected, execute(test1).unwrap().unwrap());

    for t in bad_tests.iter() {
        execute(t).unwrap_err();
    }
}

#[test]
fn test_simple_filter_buffer() {
    let test1 = "(define-private (test (x (buff 1))) (not (is-eq x 0x30)))
                 (filter test 0x303030313233)";

    let expected = Value::buff_from(vec![49, 50, 51]).unwrap();
    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_list_tuple_admission() {
    let test = "(define-private (bufferize (x int)) (if (is-eq x 1) 0x616263 0x6162))
         (define-private (tuplize (x int))
           (tuple (value (bufferize x))))
         (map tuplize (list 0 1 0 1 0 1))";

    let expected_type = "(list (tuple (value 0x303132))
               (tuple (value 0x303132))
               (tuple (value 0x303132))
               (tuple (value 0x303132))
               (tuple (value 0x303132))
               (tuple (value 0x303132)))";

    let not_expected_type = "(list (tuple (value 0x3031))
               (tuple (value 0x3032))
               (tuple (value 0x3132))
               (tuple (value 0x3132))
               (tuple (value 0x3031))
               (tuple (value 0x3032)))";

    let result_type = TypeSignature::type_of(&execute(test).unwrap().unwrap()).unwrap();
    let expected_type = TypeSignature::type_of(&execute(expected_type).unwrap().unwrap()).unwrap();
    let testing_value = &execute(not_expected_type).unwrap().unwrap();
    let not_expected_type = TypeSignature::type_of(testing_value).unwrap();

    assert_eq!(expected_type, result_type);
    assert!(not_expected_type != result_type);
    assert!(
        result_type
            .admits(&StacksEpochId::Epoch21, testing_value)
            .unwrap()
    );
}

#[test]
fn test_simple_folds_list() {
    let test1 = "(define-private (multiply-all (x int) (acc int)) (* x acc))
         (fold multiply-all (list 1 2 3 4) 1)";

    let expected = Value::Int(24);

    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_simple_folds_string() {
    let tests =
        ["(define-private (get-len (x (string-ascii 1)) (acc int)) (+ acc 1))
         (fold get-len \"blockstack\" 0)",
        "(define-private (get-slice (x (string-ascii 1)) (acc (tuple (limit uint) (cursor uint) (data (string-ascii 10)))))
            (if (< (get cursor acc) (get limit acc))
                (let ((data (default-to (get data acc) (as-max-len? (concat (get data acc) x) u10))))
                    (tuple (limit (get limit acc)) (cursor (+ u1 (get cursor acc))) (data data)))
                acc))
        (get data (fold get-slice \"0123456789\" (tuple (limit u5) (cursor u0) (data \"\"))))"];

    let expected = [
        Value::Int(10),
        Value::string_ascii_from_bytes(vec![48, 49, 50, 51, 52]).unwrap(),
    ];

    for (test, expected) in tests.iter().zip(expected.iter()) {
        assert_eq!(expected.clone(), execute(test).unwrap().unwrap());
    }
}

#[test]
fn test_native_len() {
    let test1 = "(len (list 1 2 3 4))";
    let expected = Value::UInt(4);
    assert_eq!(expected, execute(test1).unwrap().unwrap());
}

#[test]
fn test_buff_len() {
    let test1 = "(len \"blockstack\")";
    let expected = Value::UInt(10);
    assert_eq!(expected, execute(test1).unwrap().unwrap());

    let test2 = "(len 0x)";
    let expected = Value::UInt(0);
    assert_eq!(expected, execute(test2).unwrap().unwrap());
}

#[apply(test_clarity_versions)]
fn test_construct_bad_list(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    use crate::vm::types::TypeSignatureExt as _;

    let test1 = "(list 1 2 3 true)";
    assert_eq!(
        execute(test1).unwrap_err(),
        RuntimeCheckErrorKind::TypeError(Box::new(IntType), Box::new(BoolType)).into()
    );

    let test2 = "(define-private (bad-function (x int)) (if (is-eq x 1) true x))
                 (map bad-function (list 0 1 2 3))";
    assert_eq!(
        execute(test2).unwrap_err(),
        RuntimeCheckErrorKind::TypeError(Box::new(IntType), Box::new(BoolType)).into()
    );

    let bad_2d_list = "(list (list 1 2 3) (list true false true))";
    let bad_high_order_list = "(list (list 1 2 3) (list (list 1 2 3)))";

    assert_eq!(
        execute(bad_2d_list).unwrap_err(),
        RuntimeCheckErrorKind::TypeError(Box::new(IntType), Box::new(BoolType)).into()
    );
    assert_eq!(
        execute(bad_high_order_list).unwrap_err(),
        RuntimeCheckErrorKind::TypeError(
            Box::new(IntType),
            Box::new(TypeSignature::from_string("(list 3 int)", version, epoch))
        )
        .into()
    );
}

#[test]
fn test_eval_func_arg_panic() {
    let test1 = "(fold (lambda (x y) (* x y)) (list 1 2 3 4) 1)";
    let e: ClarityEvalError = RuntimeCheckErrorKind::Unreachable("Expected name".into()).into();
    assert_eq!(e, execute(test1).unwrap_err());

    let test2 = "(map (lambda (x) (* x x)) (list 1 2 3 4))";
    let e: ClarityEvalError = RuntimeCheckErrorKind::Unreachable("Expected name".into()).into();
    assert_eq!(e, execute(test2).unwrap_err());

    let test3 = "(map square (list 1 2 3 4) 2)";
    let e: ClarityEvalError = RuntimeCheckErrorKind::UndefinedFunction("square".to_string()).into();
    assert_eq!(e, execute(test3).unwrap_err());

    let test4 = "(define-private (multiply-all (x int) (acc int)) (* x acc))
         (fold multiply-all (list 1 2 3 4))";
    let e: ClarityEvalError = RuntimeCheckErrorKind::IncorrectArgumentCount(3, 2).into();
    assert_eq!(e, execute(test4).unwrap_err());

    let test5 = "(map + (list 1 2 3 4) 2)";
    let e: ClarityEvalError =
        RuntimeCheckErrorKind::Unreachable(bounded_format!("Expected sequence: {IntType}")).into();
    assert_eq!(e, execute(test5).unwrap_err());
}

#[test]
fn test_expected_list_application() {
    // append expects (list, element)
    // first argument is NOT a list
    let test1 = "(append u1 u2)";
    let e: ClarityEvalError =
        RuntimeCheckErrorKind::Unreachable("Expected list application".into()).into();
    assert_eq!(e, execute(test1).unwrap_err());
}

#[test]
fn test_map_with_special_functions() {
    // special function: >=
    let test = "(map >= (list 3 1 2) (list 1 2 2))";
    let expected = Value::list_from(vec![
        Value::Bool(true),  // (>= 3 1)
        Value::Bool(false), // (>= 1 2)
        Value::Bool(true),  // (>= 2 2)
    ])
    .unwrap();
    assert_eq!(expected, execute(test).unwrap().unwrap());

    // special function: <=
    let test = "(map <= (list 3 1 2) (list 1 2 2))";
    let expected = Value::list_from(vec![
        Value::Bool(false), // (<= 3 1)
        Value::Bool(true),  // (<= 1 2)
        Value::Bool(true),  // (<= 2 2)
    ])
    .unwrap();
    assert_eq!(expected, execute(test).unwrap().unwrap());

    // special function: <
    let test = "(map < (list 1 5 2) (list 3 3 3))";
    let expected = Value::list_from(vec![
        Value::Bool(true),  // (< 1 3)
        Value::Bool(false), // (< 5 3)
        Value::Bool(true),  // (< 2 3)
    ])
    .unwrap();
    assert_eq!(expected, execute(test).unwrap().unwrap());

    // special function: >
    let test = "(map > (list 5 1 3) (list 3 3 3))";
    let expected = Value::list_from(vec![
        Value::Bool(true),  // (> 5 3)
        Value::Bool(false), // (> 1 3)
        Value::Bool(false), // (> 3 3)
    ])
    .unwrap();
    assert_eq!(expected, execute(test).unwrap().unwrap());
}

#[test]
fn test_fold_with_special_functions() {
    // special function: and
    //   step 1: (and true true) => true
    //   step 2: (and false true) => false
    let test = "(fold and (list true false) true)";
    assert_eq!(Value::Bool(false), execute(test).unwrap().unwrap());

    // special function: or
    //   step 1: (or false false) => false
    //   step 2: (or true false) => true
    let test = "(fold or (list false true) false)";
    assert_eq!(Value::Bool(true), execute(test).unwrap().unwrap());

    // Comparison SpecialFunctions (>=, <=, <, >) return bool so they can't
    // fold over multi-element lists (type mismatch after step 1). Verify
    // they work for a single-element list where only one step executes.

    // special function: >=
    let test = "(fold >= (list 3) 1)";
    assert_eq!(Value::Bool(true), execute(test).unwrap().unwrap());

    // special function: <=
    let test = "(fold <= (list 1) 3)";
    assert_eq!(Value::Bool(true), execute(test).unwrap().unwrap());

    // special function: <
    let test = "(fold < (list 1) 3)";
    assert_eq!(Value::Bool(true), execute(test).unwrap().unwrap());

    // special function: >
    let test = "(fold > (list 3) 1)";
    assert_eq!(Value::Bool(true), execute(test).unwrap().unwrap());
}

#[test]
fn test_filter_with_special_functions() {
    // special function: and
    //   keeps elements where (and elem) => true
    let test = "(filter and (list true false true false))";
    let expected = Value::list_from(vec![Value::Bool(true), Value::Bool(true)]).unwrap();
    assert_eq!(expected, execute(test).unwrap().unwrap());

    // special function: or
    //   keeps elements where (or elem) => true
    let test = "(filter or (list false true false true))";
    let expected = Value::list_from(vec![Value::Bool(true), Value::Bool(true)]).unwrap();
    assert_eq!(expected, execute(test).unwrap().unwrap());
}

// =============================================================================
// Property tests for variadic `concat` (Clarity 6 / Epoch 4.0+).
//
// Each test generates `2..=MAX_FUNCTION_PARAMETERS` args of one sequence kind
// with random data, builds the variadic `(concat a1 a2 ... aN)` snippet, and
// verifies the result equals the byte/char/element-wise concatenation of all
// args computed in Rust. This exercises both the two-pass evaluation in
// `special_concat_v400` (phase 1 sum, phase 2 reserve+concat) and the
// type-checker fold in `check_special_concat`.
//
// Per-arg lengths are kept small so that the combined result fits comfortably
// below the `MAX_VALUE_SIZE` ceiling even at `MAX_FUNCTION_PARAMETERS` args.
// =============================================================================

/// Random bytes for a buffer arg.
fn buff_chunk_strategy() -> impl Strategy<Value = Vec<u8>> {
    prop::collection::vec(any::<u8>(), 0..=32)
}

/// Printable-ASCII bytes (`0x20..=0x7E`) excluding `"` and `\`, which need
/// escaping in a Clarity string literal.
///
/// Callers sample from this set directly rather than `prop_filter`-ing the full
/// range: a per-byte filter rejects `"`/`\` ~2% of the time, and with many
/// bytes per case the cumulative local rejects blow past proptest's cap under
/// high case counts (aborting the run).
fn allowed_ascii_bytes() -> Vec<u8> {
    (0x20u8..=0x7Eu8)
        .filter(|b| *b != b'"' && *b != b'\\')
        .collect()
}

/// Random printable-ASCII bytes (no `"` or `\`) for a string-ascii arg.
fn ascii_chunk_strategy() -> impl Strategy<Value = Vec<u8>> {
    prop::collection::vec(prop::sample::select(allowed_ascii_bytes()), 0..=32)
}

/// Random Unicode chars (printable ASCII + BMP + emoji) for a string-utf8 arg.
fn utf8_chunk_strategy() -> impl Strategy<Value = Vec<char>> {
    prop::collection::vec(
        prop_oneof![
            // Printable ASCII excluding `"` and `\`
            prop::sample::select(allowed_ascii_bytes()).prop_map(|b| b as char),
            // BMP non-control non-surrogate codepoints
            (0xA1u32..=0xD7FF).prop_filter_map("valid bmp char", |n| {
                char::from_u32(n).filter(|c| !c.is_control())
            }),
            // Emoji range
            (0x1F300u32..=0x1F6FFu32).prop_filter_map("valid emoji", char::from_u32),
        ],
        0..=16,
    )
}

/// Random uints for a `(list uint)` arg.
fn uint_list_chunk_strategy() -> impl Strategy<Value = Vec<u128>> {
    prop::collection::vec(any::<u128>(), 0..=8)
}

/// Format raw bytes as a Clarity ASCII string literal.
fn ascii_to_clarity_literal(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() + 2);
    s.push('"');
    for &b in bytes {
        // Strategy already filters out `"` and `\`, so every byte is a
        // printable ASCII char that needs no escaping.
        s.push(b as char);
    }
    s.push('"');
    s
}

/// Format a sequence of chars as a Clarity UTF-8 string literal.
fn utf8_chars_to_clarity_literal(chars: &[char]) -> String {
    let mut s = String::from("u\"");
    for &c in chars {
        if c.is_ascii() && c != '"' && c != '\\' && !c.is_control() {
            s.push(c);
        } else {
            s.push_str(&format!("\\u{{{:X}}}", c as u32));
        }
    }
    s.push('"');
    s
}

/// Format a uint list as a Clarity list literal. Empty lists use `(list)`
/// which is valid syntax and combines correctly via the type checker's
/// supertype path.
fn uint_list_to_clarity_literal(items: &[u128]) -> String {
    if items.is_empty() {
        "(list)".to_string()
    } else {
        let body = items
            .iter()
            .map(|u| format!("u{u}"))
            .collect::<Vec<_>>()
            .join(" ");
        format!("(list {body})")
    }
}

proptest! {
    /// Variadic buffer concat: result is the byte-wise concatenation of args.
    #[tag(t_prop)]
    #[test]
    fn prop_variadic_concat_buff(
        chunks in prop::collection::vec(buff_chunk_strategy(), 2..=MAX_FUNCTION_PARAMETERS),
    ) {
        let snippets: Vec<String> = chunks
            .iter()
            .map(|bytes| format!("0x{}", to_hex(bytes)))
            .collect();
        let snippet = format!("(concat {})", snippets.join(" "));

        let result = execute_v6(&snippet)
            .map_err(|e| TestCaseError::fail(format!("execute_v6 failed: {e:?}")))?
            .ok_or_else(|| TestCaseError::fail("no return value"))?;
        let expected_bytes: Vec<u8> = chunks.into_iter().flatten().collect();
        let expected = Value::buff_from(expected_bytes)
            .map_err(|e| TestCaseError::fail(format!("buff_from failed: {e:?}")))?;
        prop_assert_eq!(result, expected);
    }

    /// Variadic string-ascii concat: result is the byte-wise concatenation.
    #[tag(t_prop)]
    #[test]
    fn prop_variadic_concat_string_ascii(
        chunks in prop::collection::vec(ascii_chunk_strategy(), 2..=MAX_FUNCTION_PARAMETERS),
    ) {
        let snippets: Vec<String> = chunks.iter().map(|b| ascii_to_clarity_literal(b)).collect();
        let snippet = format!("(concat {})", snippets.join(" "));

        let result = execute_v6(&snippet)
            .map_err(|e| TestCaseError::fail(format!("execute_v6 failed: {e:?}")))?
            .ok_or_else(|| TestCaseError::fail("no return value"))?;
        let expected_bytes: Vec<u8> = chunks.into_iter().flatten().collect();
        let expected = Value::string_ascii_from_bytes(expected_bytes)
            .map_err(|e| TestCaseError::fail(format!("string_ascii_from_bytes failed: {e:?}")))?;
        prop_assert_eq!(result, expected);
    }

    /// Variadic string-utf8 concat: result is the char-wise concatenation.
    /// Exercises ASCII, BMP, and supplementary plane (emoji) codepoints.
    #[tag(t_prop)]
    #[test]
    fn prop_variadic_concat_string_utf8(
        chunks in prop::collection::vec(utf8_chunk_strategy(), 2..=MAX_FUNCTION_PARAMETERS),
    ) {
        let snippets: Vec<String> = chunks.iter().map(|cs| utf8_chars_to_clarity_literal(cs)).collect();
        let snippet = format!("(concat {})", snippets.join(" "));

        let result = execute_v6(&snippet)
            .map_err(|e| TestCaseError::fail(format!("execute_v6 failed: {e:?}")))?
            .ok_or_else(|| TestCaseError::fail("no return value"))?;
        let combined: String = chunks.into_iter().flatten().collect();
        let expected = Value::string_utf8_from_bytes(combined.into_bytes())
            .map_err(|e| TestCaseError::fail(format!("string_utf8_from_bytes failed: {e:?}")))?;
        prop_assert_eq!(result, expected);
    }

    /// Variadic list concat: result is the element-wise concatenation. All
    /// args have homogeneous element type `uint`, including empty lists which
    /// must combine cleanly via the type checker's supertype path.
    #[tag(t_prop)]
    #[test]
    fn prop_variadic_concat_list_uint(
        chunks in prop::collection::vec(uint_list_chunk_strategy(), 2..=MAX_FUNCTION_PARAMETERS),
    ) {
        let snippets: Vec<String> = chunks.iter().map(|l| uint_list_to_clarity_literal(l)).collect();
        let snippet = format!("(concat {})", snippets.join(" "));

        let result = execute_v6(&snippet)
            .map_err(|e| TestCaseError::fail(format!("execute_v6 failed: {e:?}")))?
            .ok_or_else(|| TestCaseError::fail("no return value"))?;
        let expected_values: Vec<Value> = chunks.into_iter().flatten().map(Value::UInt).collect();
        let expected = Value::list_from(expected_values)
            .map_err(|e| TestCaseError::fail(format!("list_from failed: {e:?}")))?;
        prop_assert_eq!(result, expected);
    }
}
