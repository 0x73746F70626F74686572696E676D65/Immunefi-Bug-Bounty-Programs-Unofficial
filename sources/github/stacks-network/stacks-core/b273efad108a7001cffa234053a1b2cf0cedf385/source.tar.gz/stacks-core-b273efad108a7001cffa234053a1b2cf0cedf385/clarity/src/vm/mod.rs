// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
pub mod diagnostic;
pub mod errors;

#[macro_use]
pub mod costs;

pub mod types;

pub mod contracts;

pub mod ast;
pub mod contexts;
pub mod database;
pub mod hooks;
pub mod representations;

pub mod callables;
pub mod functions;
pub mod resource_limiter;
pub mod variables;

pub mod analysis;
pub mod docs;
pub mod version;

pub mod events;

#[cfg(feature = "rusqlite")]
pub mod tooling;

#[cfg(any(test, feature = "testing"))]
pub mod tests;

#[cfg(any(test, feature = "testing"))]
pub mod test_util;

pub mod clarity;

use std::collections::BTreeMap;

pub use clarity_types::max_call_stack_depth_for_epoch;
use stacks_common::bounded_format;
use stacks_common::types::StacksEpochId;

use self::analysis::ContractAnalysis;
use self::ast::ContractAST;
use self::costs::ExecutionCost;
use self::diagnostic::Diagnostic;
use crate::vm::callables::{BuiltinKind, CallableType, FunctionIdentifier};
pub use crate::vm::contexts::{CallStack, ContractContext, LocalContext, MAX_CONTEXT_DEPTH};
use crate::vm::contexts::{ExecutionState, GlobalContext, InvocationContext};
use crate::vm::costs::cost_functions::ClarityCostFunction;
use crate::vm::costs::{
    CostOverflowingMath, CostTracker, LimitedCostTracker, MemoryConsumer, runtime_cost,
};
// publish the non-generic StacksEpoch form for use throughout module
pub use crate::vm::database::clarity_db::StacksEpoch;
#[cfg(any(test, feature = "testing"))]
use crate::vm::errors::ClarityEvalError;
use crate::vm::errors::{RuntimeCheckErrorKind, RuntimeError, VmExecutionError, VmInternalError};
use crate::vm::events::StacksTransactionEvent;
use crate::vm::functions::define::DefineResult;
pub use crate::vm::functions::stx_transfer_consolidated;
use crate::vm::hooks::{CallArguments, CallTraceFrame, EvalHookNotifier as _};
pub use crate::vm::representations::{
    ClarityName, ContractName, SymbolicExpression, SymbolicExpressionType,
};
#[cfg(any(test, feature = "testing"))]
use crate::vm::resource_limiter::ResourceBudget;
use crate::vm::resource_limiter::ResourceLimitExceeded;
pub use crate::vm::types::Value;
use crate::vm::types::{PrincipalData, TypeSignature};
pub use crate::vm::version::ClarityVersion;

/// A wrapper for variable value references that prevents accidental cloning.
/// Only explicit clone_with_cost is allowed. Do not implement Clone or Copy for this type.
#[derive(Debug, PartialEq)]
pub enum ValueRef<'a> {
    Borrowed(&'a Value),
    Owned(Value),
}

impl AsRef<Value> for ValueRef<'_> {
    fn as_ref(&self) -> &Value {
        match self {
            ValueRef::Borrowed(r) => r,
            ValueRef::Owned(o) => o,
        }
    }
}
impl<'a> ValueRef<'a> {
    pub fn clone_with_cost<T: CostTracker>(
        self,
        tracker: &mut T,
    ) -> Result<Value, VmExecutionError> {
        match self {
            ValueRef::Borrowed(r) => {
                runtime_cost(ClarityCostFunction::LookupVariableSize, tracker, r.size()?)?;
                Ok(r.clone())
            }
            ValueRef::Owned(o) => Ok(o),
        }
    }
}

#[derive(Debug, Clone)]
pub struct ParsedContract {
    pub contract_identifier: String,
    pub code: String,
    pub function_args: BTreeMap<String, Vec<String>>,
    pub ast: ContractAST,
    pub analysis: ContractAnalysis,
}

#[derive(Debug, Clone)]
pub struct ContractEvaluationResult {
    pub result: Option<Value>,
    pub contract: ParsedContract,
}

#[derive(Debug, Clone)]
pub struct SnippetEvaluationResult {
    pub result: Value,
}

#[derive(Debug, Clone)]
#[allow(clippy::large_enum_variant)]
pub enum EvaluationResult {
    Contract(ContractEvaluationResult),
    Snippet(SnippetEvaluationResult),
}

#[derive(Debug, Clone)]
pub struct ExecutionResult {
    pub result: EvaluationResult,
    pub events: Vec<StacksTransactionEvent>,
    pub cost: Option<CostSynthesis>,
    pub diagnostics: Vec<Diagnostic>,
}

#[derive(Clone, Debug, Serialize)]
pub struct CostSynthesis {
    pub total: ExecutionCost,
    pub limit: ExecutionCost,
    pub memory: u64,
    pub memory_limit: u64,
}

impl CostSynthesis {
    pub fn from_cost_tracker(cost_tracker: &LimitedCostTracker) -> CostSynthesis {
        CostSynthesis {
            total: cost_tracker.get_total(),
            limit: cost_tracker.get_limit(),
            memory: cost_tracker.get_memory(),
            memory_limit: cost_tracker.get_memory_limit(),
        }
    }
}

fn lookup_variable<'a>(
    name: &str,
    exec_state: &mut ExecutionState,
    invoke_ctx: &'a InvocationContext,
    context: &'a LocalContext,
) -> Result<ValueRef<'a>, VmExecutionError> {
    if name.starts_with(char::is_numeric) || name.starts_with('\'') {
        return Err(VmInternalError::BadSymbolicRepresentation(format!(
            "Unexpected variable name: {name}"
        ))
        .into());
    }
    if let Some(value) = variables::lookup_reserved_variable(name, exec_state, invoke_ctx)? {
        return Ok(ValueRef::Owned(value));
    };
    runtime_cost(
        ClarityCostFunction::LookupVariableDepth,
        exec_state,
        context.depth(),
    )?;
    if let Some(value) = context.lookup_variable(name) {
        let value = ValueRef::Borrowed(value);
        if exec_state.epoch().uses_pre_sanitized_variables() {
            // If the epoch supports value refs, we can return a borrowed reference to the variable without cloning.
            return Ok(value);
        } else {
            // Epochs that don't support borrowed refs must clone and pay the cost every time.
            return Ok(ValueRef::Owned(value.clone_with_cost(exec_state)?));
        }
    }
    if let Some(value) = invoke_ctx.contract_context.lookup_variable(name) {
        let value = ValueRef::Borrowed(value);
        if exec_state.epoch().uses_pre_sanitized_variables() {
            // Variables were sanitized at load time by canonicalize_types.
            // Borrow directly.
            return Ok(value);
        }
        // Variables were not sanitized at load time, so we need to sanitize them
        // now before returning and pay for the clone.
        let value = value.clone_with_cost(exec_state)?;
        let (value, _) =
            Value::sanitize_value(exec_state.epoch(), &TypeSignature::type_of(&value)?, value)
                .ok_or(RuntimeCheckErrorKind::CouldNotDetermineType)?;
        return Ok(ValueRef::Owned(value));
    }
    if let Some(callable_data) = context.lookup_callable_contract(name) {
        let value = if invoke_ctx.contract_context.get_clarity_version() < &ClarityVersion::Clarity2
        {
            callable_data.contract_identifier.clone().into()
        } else {
            Value::CallableContract(callable_data.clone())
        };
        return Ok(ValueRef::Owned(value));
    }
    Err(RuntimeCheckErrorKind::Unreachable(bounded_format!("Undefined variable: {name}")).into())
}

/// Resolves `name` to a builtin, or to a user function borrowed from the contract context.
/// Charges the `LookupFunction` cost, unlike `ContractContext::lookup_function`, and fails
/// with `UndefinedFunction` when neither matches.
pub fn lookup_function<'a>(
    name: &str,
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext<'a>,
) -> Result<CallableType<'a>, VmExecutionError> {
    runtime_cost(ClarityCostFunction::LookupFunction, exec_state, 0)?;

    if let Some(result) = functions::lookup_reserved_functions(
        name,
        invoke_ctx.contract_context.get_clarity_version(),
    ) {
        Ok(result)
    } else {
        let user_function = invoke_ctx
            .contract_context
            .lookup_function(name)
            .ok_or_else(|| RuntimeCheckErrorKind::UndefinedFunction(name.to_string()))?;
        Ok(CallableType::UserFunction(user_function))
    }
}

fn add_stack_trace(result: &mut Result<Value, VmExecutionError>, exec_state: &mut ExecutionState) {
    if let Err(VmExecutionError::Runtime(_, stack_trace)) = result
        && stack_trace.is_none()
    {
        stack_trace.replace(exec_state.call_stack.make_stack_trace());
    }
}

/// Validates recursion and stack-depth invariants common to both [`apply`] and
/// [`apply_evaluated`], returning the function's identifier and whether recursion is tracked.
#[inline]
fn check_call_preconditions(
    function: &CallableType<'_>,
    exec_state: &ExecutionState,
) -> Result<(FunctionIdentifier, bool), VmExecutionError> {
    // Aaron: in non-debug executions, we shouldn't track a full call-stack.
    //        only enough to do recursion detection.
    let identifier = function.get_identifier();
    let track_recursion = matches!(function, CallableType::UserFunction(_));
    if track_recursion && exec_state.call_stack.contains(&identifier) {
        return Err(RuntimeCheckErrorKind::CircularReference(vec![identifier.to_string()]).into());
    }
    if exec_state.call_stack.depth() >= max_call_stack_depth_for_epoch(*exec_state.epoch()) {
        return Err(RuntimeError::MaxStackDepthReached.into());
    }
    Ok((identifier, track_recursion))
}

/// Dispatches a pre-evaluated argument list to a non-special [`CallableType`], handling
/// call-stack bookkeeping, cost charging, and memory cleanup.
///
/// Both [`apply`] and [`apply_evaluated`] converge here after preparing their arguments.
/// `used_memory` is the total already charged via [`ExecutionState::add_memory`] for the
/// argument values; it is released before returning.
fn dispatch_args(
    function: &CallableType<'_>,
    identifier: FunctionIdentifier,
    track_recursion: bool,
    args: Vec<Value>,
    used_memory: u64,
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
) -> Result<Value, VmExecutionError> {
    exec_state.call_stack.insert(&identifier, track_recursion);

    // Scope `?` to callable execution so the common cleanup below always runs.
    let mut resp = (|| -> Result<Value, VmExecutionError> {
        match function {
            // Built-ins (Native)
            CallableType::Builtin {
                kind: BuiltinKind::Native(_, function, cost_function),
                ..
            } => {
                runtime_cost(cost_function.clone(), exec_state, args.len())
                    .map_err(VmExecutionError::from)?;
                function.apply(args, exec_state, invoke_ctx)
            }

            // Built-ins (Native 2.05+)
            CallableType::Builtin {
                kind: BuiltinKind::Native205(_, function, cost_function, cost_input_handle),
                ..
            } => {
                let cost_input = if exec_state.epoch() >= &StacksEpochId::Epoch2_05 {
                    cost_input_handle(args.as_slice())?
                } else {
                    args.len() as u64
                };

                runtime_cost(cost_function.clone(), exec_state, cost_input)
                    .map_err(VmExecutionError::from)?;
                function.apply(args, exec_state, invoke_ctx)
            }

            // User-defined functions (Clarity)
            CallableType::UserFunction(function) => function.apply(&args, exec_state, invoke_ctx),

            // Special functions evaluate their own arguments and are dispatched directly in
            // `apply`/`apply_evaluated`, so they never reach `dispatch_args`.
            CallableType::Builtin {
                kind: BuiltinKind::Special(..),
                ..
            } => Err(VmInternalError::Expect("Should be unreachable.".into()).into()),
        }
    })();

    add_stack_trace(&mut resp, exec_state);
    exec_state.drop_memory(used_memory)?;
    exec_state.call_stack.remove(&identifier, track_recursion)?;

    resp
}

/// Evaluates unevaluated arguments and dispatches them to a [`CallableType`].
///
/// Each [`SymbolicExpression`] in `args` is evaluated (via [`eval`]) and charged for memory.
/// The resulting [`Value`]s are then dispatched through [`dispatch_args`] to the appropriate
/// callable variant (builtin or user-defined).
///
/// For [`BuiltinKind::Special`] functions, `args` are passed unevaluated — the special
/// function is responsible for evaluating its own arguments (e.g., short-circuiting in `and`/`or`).
///
/// Enforces recursion detection and max stack-depth limits before dispatch.
pub fn apply(
    function: &CallableType<'_>,
    args: &[SymbolicExpression],
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    let (identifier, track_recursion) = check_call_preconditions(function, exec_state)?;
    let call_hook = CallTraceFrame::when(exec_state.has_eval_hooks(), || {
        function.call_trace_hook(invoke_ctx)
    });

    if let CallableType::Builtin {
        kind: BuiltinKind::Special(_, function),
        ..
    } = function
    {
        exec_state.call_stack.insert(&identifier, track_recursion);
        call_hook.begin(exec_state, invoke_ctx, CallArguments::Expressions(args));
        let mut resp = function(args, exec_state, invoke_ctx, context);
        call_hook.finish(exec_state, invoke_ctx, &resp);
        add_stack_trace(&mut resp, exec_state);
        exec_state.call_stack.remove(&identifier, track_recursion)?;
        return resp;
    }

    call_hook.begin(exec_state, invoke_ctx, CallArguments::Expressions(args));

    macro_rules! return_call_error {
        ($err:expr) => {{
            let resp = Err($err);
            call_hook.finish(exec_state, invoke_ctx, &resp);
            return resp;
        }};
    }

    let mut used_memory = 0;
    let mut evaluated_args = Vec::with_capacity(args.len());
    exec_state.call_stack.incr_apply_depth();
    for (arg_index, arg_x) in args.iter().enumerate() {
        let arg_value = match eval(arg_x, exec_state, invoke_ctx, context)
            .and_then(|v| v.clone_with_cost(exec_state))
        {
            Ok(x) => x,
            Err(e) => {
                let err = match exec_state.drop_memory(used_memory) {
                    Ok(()) => e,
                    Err(drop_err) => drop_err.into(),
                };
                exec_state.call_stack.decr_apply_depth();
                return_call_error!(err);
            }
        };
        let arg_use = match arg_value.get_memory_use() {
            Ok(x) => x,
            Err(e) => {
                let err = match exec_state.drop_memory(used_memory) {
                    Ok(()) => e.into(),
                    Err(drop_err) => drop_err.into(),
                };
                exec_state.call_stack.decr_apply_depth();
                return_call_error!(err);
            }
        };
        match exec_state.add_memory(arg_use) {
            Ok(_x) => {}
            Err(e) => {
                let err = match exec_state.drop_memory(used_memory) {
                    Ok(()) => e.into(),
                    Err(drop_err) => drop_err.into(),
                };
                exec_state.call_stack.decr_apply_depth();
                return_call_error!(err);
            }
        };
        used_memory += arg_use;
        call_hook.did_evaluate_argument(exec_state, invoke_ctx, arg_index, &arg_value);
        evaluated_args.push(arg_value);
    }
    exec_state.call_stack.decr_apply_depth();

    let resp = dispatch_args(
        function,
        identifier,
        track_recursion,
        evaluated_args,
        used_memory,
        exec_state,
        invoke_ctx,
    );
    call_hook.finish(exec_state, invoke_ctx, &resp);
    resp
}

/// Like [`apply`], but takes pre-evaluated [`Value`]s, skipping the `eval` + `clone_with_cost`
/// round-trip for every argument.
///
/// `fold`, `map`, and `filter` already have the element values as owned `Value`s; wrapping
/// them in `SymbolicExpression::atom_value` just to have `eval` clone them back out wastes N
/// allocations per step.  This function performs the same recursion/stack/memory bookkeeping
/// as `apply` while bypassing the eval pass entirely.
///
/// For [`BuiltinKind::Special`] functions (e.g. comparison operators `>=`, `<=`, `<`, `>`,
/// or boolean operators `and`, `or`), the values are wrapped back into
/// `SymbolicExpression::atom_value` so the special function can evaluate them normally
/// with `eval`.
pub fn apply_evaluated(
    function: &CallableType<'_>,
    args: Vec<Value>,
    exec_state: &mut ExecutionState,
    invoke_ctx: &InvocationContext,
    context: &LocalContext,
) -> Result<Value, VmExecutionError> {
    let (identifier, track_recursion) = check_call_preconditions(function, exec_state)?;
    let call_hook = CallTraceFrame::when(exec_state.has_eval_hooks(), || {
        function.call_trace_hook(invoke_ctx)
    });

    // `BuiltinKind::Special` functions require unevaluated SymbolicExpressions. They evaluate their own
    // arguments (e.g. short-circuit in `and`/`or`). Wrap the pre-evaluated Values back
    // into atom_value expressions so the special function dispatch works correctly.
    // This path is hit when built-in operators like >=, <=, <, >, and, or are used as
    // step functions in fold/map/filter. Note: In this case it works like `apply`.
    if let CallableType::Builtin {
        kind: BuiltinKind::Special(_, function),
        ..
    } = function
    {
        call_hook.begin(exec_state, invoke_ctx, CallArguments::Values(&args));
        call_hook.did_evaluate_arguments(exec_state, invoke_ctx, &args);
        let sym_args: Vec<SymbolicExpression> = args
            .into_iter()
            .map(SymbolicExpression::atom_value)
            .collect();
        exec_state.call_stack.insert(&identifier, track_recursion);
        let mut resp = function(&sym_args, exec_state, invoke_ctx, context);
        call_hook.finish(exec_state, invoke_ctx, &resp);
        add_stack_trace(&mut resp, exec_state);
        exec_state.call_stack.remove(&identifier, track_recursion)?;
        return resp;
    }

    call_hook.begin(exec_state, invoke_ctx, CallArguments::Values(&args));
    call_hook.did_evaluate_arguments(exec_state, invoke_ctx, &args);

    macro_rules! return_call_error {
        ($err:expr) => {{
            let resp = Err($err);
            call_hook.finish(exec_state, invoke_ctx, &resp);
            return resp;
        }};
    }

    let mut used_memory = 0;
    exec_state.call_stack.incr_apply_depth();
    for arg in args.iter() {
        let arg_use = match arg.get_memory_use() {
            Ok(x) => x,
            Err(e) => {
                let err = match exec_state.drop_memory(used_memory) {
                    Ok(()) => e.into(),
                    Err(drop_err) => drop_err.into(),
                };
                exec_state.call_stack.decr_apply_depth();
                return_call_error!(err);
            }
        };
        match exec_state.add_memory(arg_use) {
            Ok(_) => {}
            Err(e) => {
                let err = match exec_state.drop_memory(used_memory) {
                    Ok(()) => e.into(),
                    Err(drop_err) => drop_err.into(),
                };
                exec_state.call_stack.decr_apply_depth();
                return_call_error!(err);
            }
        };
        used_memory += arg_use;
    }
    exec_state.call_stack.decr_apply_depth();

    let resp = dispatch_args(
        function,
        identifier,
        track_recursion,
        args,
        used_memory,
        exec_state,
        invoke_ctx,
    );
    call_hook.finish(exec_state, invoke_ctx, &resp);
    resp
}

/// Check for interpreter-level violations of the resource limits
/// (execution time limit or excessive heap allocations).
fn check_interpreter_resource_usage(
    global_context: &GlobalContext,
) -> Result<(), VmExecutionError> {
    global_context
        .execution_resource_limiter
        .check_not_exceeded()
        .map_err(|err| match err {
            ResourceLimitExceeded::MaxDurationExceeded(s) => {
                RuntimeCheckErrorKind::ExecutionResourceBudgetExceeded(format!(
                    "Evaluation took too much time: {s}"
                ))
                .into()
            }
            ResourceLimitExceeded::MaxAllocationExceeded(s) => {
                RuntimeCheckErrorKind::ExecutionResourceBudgetExceeded(format!(
                    "Evaluation used too much memory: {s}"
                ))
                .into()
            }
        })
}

pub fn eval<'a>(
    exp: &'a SymbolicExpression,
    exec_state: &mut ExecutionState,
    invoke_ctx: &'a InvocationContext,
    context: &'a LocalContext,
) -> Result<ValueRef<'a>, VmExecutionError> {
    use crate::vm::representations::SymbolicExpressionType::{
        Atom, AtomValue, Field, List, LiteralValue, TraitReference,
    };

    check_interpreter_resource_usage(exec_state.global_context)?;

    exec_state.notify_will_begin_eval(invoke_ctx, context, exp);

    let res = match &exp.expr {
        AtomValue(value) | LiteralValue(value) => Ok(ValueRef::Owned(value.clone())),
        Atom(value) => lookup_variable(value, exec_state, invoke_ctx, context),
        List(children) => {
            let (function_variable, rest) =
                children
                    .split_first()
                    .ok_or(RuntimeCheckErrorKind::Unreachable(
                        "Non functional application".into(),
                    ))?;

            let function_name =
                function_variable
                    .match_atom()
                    .ok_or(RuntimeCheckErrorKind::Unreachable(
                        "Bad function name".into(),
                    ))?;
            let f = lookup_function(function_name, exec_state, invoke_ctx)?;
            apply(&f, rest, exec_state, invoke_ctx, context).map(ValueRef::Owned)
        }
        TraitReference(_, _) | Field(_) => {
            return Err(VmInternalError::BadSymbolicRepresentation(
                "Unexpected trait reference".into(),
            )
            .into());
        }
    };

    exec_state.notify_did_finish_eval(invoke_ctx, context, exp, &res);

    res
}

pub fn is_reserved(name: &str, version: &ClarityVersion) -> bool {
    functions::lookup_reserved_functions(name, version).is_some()
        || variables::is_reserved_name(name, version)
}

/// Reserved at `version` but free in an earlier one, so a legacy trait may
/// carry it as a method name. From Epoch 4.1 a public/read-only function may
/// take such a name to implement that method, else old traits would be
/// unimplementable at the only deployable version; the native still wins every
/// reference where one exists. Enforced by `TraitChecker` at analysis.
pub fn is_shadowable_reserved(name: &str, version: &ClarityVersion) -> bool {
    is_reserved(name, version)
        && ClarityVersion::ALL
            .iter()
            .filter(|v| *v < version)
            .any(|v| !is_reserved(name, v))
}

/// This function evaluates a list of expressions, sharing a global context.
/// It returns the final evaluated result.
/// Used for the initialization of a new contract.
pub fn eval_all(
    expressions: &[SymbolicExpression],
    contract_context: &mut ContractContext,
    global_context: &mut GlobalContext,
    sponsor: Option<PrincipalData>,
) -> Result<Option<Value>, VmExecutionError> {
    let mut last_executed = None;
    let context = LocalContext::new();
    let mut total_memory_use = 0;

    let publisher: PrincipalData = contract_context.contract_identifier.issuer.clone().into();

    finally_drop_memory!(global_context, total_memory_use; {
        for exp in expressions {
            let try_define = global_context.execute(|context| {
                let mut call_stack = CallStack::new();
                let mut exec_state = ExecutionState {
                    global_context: context,
                    call_stack: &mut call_stack,
                };
                let invoke_ctx = InvocationContext {
                    contract_context,
                    sender: Some(publisher.clone()),
                    caller: Some(publisher.clone()),
                    sponsor: sponsor.clone(),
                };
                functions::define::evaluate_define(exp, &mut exec_state, &invoke_ctx)
            })?;
            match try_define {
                DefineResult::Variable(name, value) => {
                    runtime_cost(ClarityCostFunction::BindName, global_context, 0)?;
                    let value_memory_use = value.get_memory_use()?;
                    global_context.add_memory(value_memory_use)?;
                    total_memory_use += value_memory_use;

                    contract_context.variables.insert(name, value);
                },
                DefineResult::Function(name, value) => {
                    runtime_cost(ClarityCostFunction::BindName, global_context, 0)?;

                    contract_context.functions.insert(name, value);
                },
                DefineResult::PersistedVariable(name, value_type, value) => {
                    runtime_cost(ClarityCostFunction::CreateVar, global_context, value_type.size()?)?;
                    contract_context.persisted_names.insert(name.clone());

                    global_context.add_memory(value_type.type_size()
                                              .map_err(|_| VmInternalError::Expect("Type size should be realizable".into()))?.into())?;

                    global_context.add_memory(value.size()?.into())?;

                    let data_type = global_context.database.create_variable(&contract_context.contract_identifier, &name, value_type)?;
                    global_context.database.set_variable(&contract_context.contract_identifier, &name, value, &data_type, &global_context.epoch_id)?;

                    contract_context.meta_data_var.insert(name, data_type);
                },
                DefineResult::Map(name, key_type, value_type) => {
                    runtime_cost(ClarityCostFunction::CreateMap, global_context,
                                  u64::from(key_type.size()?).cost_overflow_add(
                                      u64::from(value_type.size()?))?)?;
                    contract_context.persisted_names.insert(name.clone());

                    global_context.add_memory(key_type.type_size()
                                              .map_err(|_| VmInternalError::Expect("Type size should be realizable".into()))?.into())?;
                    global_context.add_memory(value_type.type_size()
                                              .map_err(|_| VmInternalError::Expect("Type size should be realizable".into()))?.into())?;

                    let data_type = global_context.database.create_map(&contract_context.contract_identifier, &name, key_type, value_type)?;

                    contract_context.meta_data_map.insert(name, data_type);
                },
                DefineResult::FungibleToken(name, total_supply) => {
                    runtime_cost(ClarityCostFunction::CreateFt, global_context, 0)?;
                    contract_context.persisted_names.insert(name.clone());

                    global_context.add_memory(TypeSignature::UIntType.type_size()
                                              .map_err(|_| VmInternalError::Expect("Type size should be realizable".into()))?.into())?;

                    let data_type = global_context.database.create_fungible_token(&contract_context.contract_identifier, &name, &total_supply)?;

                    contract_context.meta_ft.insert(name, data_type);
                },
                DefineResult::NonFungibleAsset(name, asset_type) => {
                    runtime_cost(ClarityCostFunction::CreateNft, global_context, asset_type.size()?)?;
                    contract_context.persisted_names.insert(name.clone());

                    global_context.add_memory(asset_type.type_size()
                                              .map_err(|_| VmInternalError::Expect("Type size should be realizable".into()))?.into())?;

                    let data_type = global_context.database.create_non_fungible_token(&contract_context.contract_identifier, &name, &asset_type)?;

                    contract_context.meta_nft.insert(name, data_type);
                },
                DefineResult::Trait(name, trait_type) => {
                    contract_context.defined_traits.insert(name, trait_type);
                },
                DefineResult::UseTrait(_name, _trait_identifier) => {},
                DefineResult::ImplTrait(trait_identifier) => {
                    contract_context.implemented_traits.insert(trait_identifier);
                },
                DefineResult::NoDefine => {
                    // not a define function, evaluate normally.
                    global_context.execute(|global_context| {
                        let mut call_stack = CallStack::new();
                        let mut exec_state = ExecutionState {
                            global_context,
                            call_stack: &mut call_stack,
                        };
                        let invoke_ctx = InvocationContext {
                            contract_context,
                            sender: Some(publisher.clone()),
                            caller: Some(publisher.clone()),
                            sponsor: sponsor.clone(),
                        };
                        let result = eval(exp, &mut exec_state, &invoke_ctx, &context)?.clone_with_cost(&mut exec_state)?;
                        last_executed = Some(result);
                        Ok(())
                    })?;
                }
            }
        }

        contract_context.data_size = total_memory_use;
        Ok(last_executed)
    })
}

/// Run provided program in a brand new environment, with a transient, empty
/// database. Only used for testing
/// This method executes the program in Epoch 2.0 *and* Epoch 2.05 and asserts
/// that the result is the same before returning the result
#[cfg(any(test, feature = "testing"))]
pub fn execute_on_network(
    program: &str,
    use_mainnet: bool,
) -> Result<Option<Value>, ClarityEvalError> {
    let epoch_200_result = execute_with_parameters(
        program,
        ClarityVersion::Clarity2,
        StacksEpochId::Epoch20,
        use_mainnet,
    );
    let epoch_205_result = execute_with_parameters(
        program,
        ClarityVersion::Clarity2,
        StacksEpochId::Epoch2_05,
        use_mainnet,
    );

    assert_eq!(
        epoch_200_result, epoch_205_result,
        "Epoch 2.0 and 2.05 should have same execution result, but did not for program `{program}`"
    );
    epoch_205_result
}

/// Runs `program` in a test environment with the provided parameters and calls
/// the provided functions before and after execution.
#[cfg(any(test, feature = "testing"))]
pub fn execute_with_parameters_and_call_in_global_context<F, G>(
    program: &str,
    clarity_version: ClarityVersion,
    epoch: StacksEpochId,
    use_mainnet: bool,
    sender: clarity_types::types::StandardPrincipalData,
    mut before_function: F,
    mut after_function: G,
) -> Result<Option<Value>, ClarityEvalError>
where
    F: FnMut(&mut GlobalContext) -> Result<(), VmExecutionError>,
    G: FnMut(&mut GlobalContext) -> Result<(), VmExecutionError>,
{
    use crate::vm::database::MemoryBackingStore;
    use crate::vm::tests::test_only_mainnet_to_chain_id;
    use crate::vm::types::QualifiedContractIdentifier;

    let contract_id =
        QualifiedContractIdentifier::new(sender, ContractName::from_literal("contract"));
    let mut contract_context = ContractContext::new(contract_id.clone(), clarity_version);
    let mut marf = MemoryBackingStore::new();
    let conn = marf.as_clarity_db();
    let chain_id = test_only_mainnet_to_chain_id(use_mainnet);
    let mut global_context = GlobalContext::new(
        use_mainnet,
        chain_id,
        conn,
        LimitedCostTracker::new_free(),
        epoch,
    );

    let parsed = ast::build_ast(
        &contract_id,
        program,
        &mut global_context.cost_track,
        clarity_version,
        epoch,
    )?
    .expressions;

    global_context
        .execute(|g| {
            before_function(g)?;
            let res = eval_all(&parsed, &mut contract_context, g, None);
            after_function(g)?;
            res
        })
        .map_err(ClarityEvalError::from)
}

#[cfg(any(test, feature = "testing"))]
pub fn execute_with_parameters(
    program: &str,
    clarity_version: ClarityVersion,
    epoch: StacksEpochId,
    use_mainnet: bool,
) -> Result<Option<Value>, ClarityEvalError> {
    execute_with_parameters_and_call_in_global_context(
        program,
        clarity_version,
        epoch,
        use_mainnet,
        clarity_types::types::StandardPrincipalData::transient(),
        |_| Ok(()),
        |_| Ok(()),
    )
}

/// Execute for test with `version`, Epoch20, testnet.
#[cfg(any(test, feature = "testing"))]
pub fn execute_against_version(
    program: &str,
    version: ClarityVersion,
) -> Result<Option<Value>, ClarityEvalError> {
    execute_with_parameters(program, version, StacksEpochId::Epoch20, false)
}

/// Execute for test in Clarity1, Epoch20, testnet.
#[cfg(any(test, feature = "testing"))]
pub fn execute(program: &str) -> Result<Option<Value>, ClarityEvalError> {
    execute_with_parameters(
        program,
        ClarityVersion::Clarity1,
        StacksEpochId::Epoch20,
        false,
    )
}

/// Execute for test in Clarity1, Epoch20, testnet.
#[cfg(any(test, feature = "testing"))]
pub fn execute_with_limited_execution_time(
    program: &str,
    max_execution_time: std::time::Duration,
) -> Result<Option<Value>, ClarityEvalError> {
    execute_with_parameters_and_call_in_global_context(
        program,
        ClarityVersion::Clarity1,
        StacksEpochId::Epoch20,
        false,
        clarity_types::types::StandardPrincipalData::transient(),
        |g| {
            let budget = ResourceBudget::new().with_max_duration(Some(max_execution_time));
            g.set_execution_resource_limiter(budget.start_tracking());
            Ok(())
        },
        |_| Ok(()),
    )
}

/// Execute for test in Clarity2, Epoch21, testnet.
#[cfg(any(test, feature = "testing"))]
pub fn execute_v2(program: &str) -> Result<Option<Value>, ClarityEvalError> {
    execute_with_parameters(
        program,
        ClarityVersion::Clarity2,
        StacksEpochId::Epoch21,
        false,
    )
}

/// Execute for test in Clarity6, Epoch40, testnet.
#[cfg(any(test, feature = "testing"))]
pub fn execute_v6(program: &str) -> Result<Option<Value>, ClarityEvalError> {
    execute_with_parameters(
        program,
        ClarityVersion::Clarity6,
        StacksEpochId::Epoch40,
        false,
    )
}

#[cfg(test)]
mod test {
    use clarity_types::ClarityName;
    use stacks_common::consts::CHAIN_ID_TESTNET;
    use stacks_common::types::StacksEpochId;

    use super::ClarityVersion;
    use crate::vm::callables::{DefineType, DefinedFunction};
    use crate::vm::contexts::{ExecutionState, InvocationContext};
    use crate::vm::costs::LimitedCostTracker;
    use crate::vm::database::MemoryBackingStore;
    use crate::vm::types::{QualifiedContractIdentifier, TypeSignature};
    use crate::vm::{
        CallStack, ContractContext, GlobalContext, LocalContext, SymbolicExpression, Value,
        ValueRef, eval,
    };

    #[test]
    fn test_simple_user_function() {
        //
        //  test program:
        //  (define (do_work x) (+ 5 x))
        //  (define a 59)
        //  (do_work a)
        //
        let content = [SymbolicExpression::list(vec![
            SymbolicExpression::atom(ClarityName::from_literal("do_work")),
            SymbolicExpression::atom(ClarityName::from_literal("a")),
        ])];

        let func_body = SymbolicExpression::list(vec![
            SymbolicExpression::atom(ClarityName::from_literal("+")),
            SymbolicExpression::atom_value(Value::Int(5)),
            SymbolicExpression::atom(ClarityName::from_literal("x")),
        ]);

        let func_args = vec![(ClarityName::from_literal("x"), TypeSignature::IntType)];
        let user_function = DefinedFunction::new(
            func_args,
            func_body,
            DefineType::Private,
            &ClarityName::from_literal("do_work"),
            "",
        );

        let context = LocalContext::new();
        let mut contract_context = ContractContext::new(
            QualifiedContractIdentifier::transient(),
            ClarityVersion::Clarity1,
        );

        let mut marf = MemoryBackingStore::new();
        let mut global_context = GlobalContext::new(
            false,
            CHAIN_ID_TESTNET,
            marf.as_clarity_db(),
            LimitedCostTracker::new_free(),
            StacksEpochId::Epoch2_05,
        );

        contract_context
            .variables
            .insert(ClarityName::from_literal("a"), Value::Int(59));
        contract_context
            .functions
            .insert(ClarityName::from_literal("do_work"), user_function);

        let mut call_stack = CallStack::new();
        let mut exec_state = ExecutionState {
            global_context: &mut global_context,
            call_stack: &mut call_stack,
        };
        let invoke_ctx = InvocationContext {
            contract_context: &contract_context,
            sender: None,
            caller: None,
            sponsor: None,
        };
        assert_eq!(
            Ok(ValueRef::Owned(Value::Int(64))),
            eval(&content[0], &mut exec_state, &invoke_ctx, &context)
        );
    }
}
