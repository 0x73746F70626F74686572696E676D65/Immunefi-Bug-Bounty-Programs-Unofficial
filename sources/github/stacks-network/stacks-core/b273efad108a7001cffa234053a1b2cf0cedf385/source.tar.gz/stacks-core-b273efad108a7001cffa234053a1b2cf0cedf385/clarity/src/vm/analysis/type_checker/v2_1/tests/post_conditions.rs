// Copyright (C) 2025-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use clarity_types::representations::MAX_STRING_LEN;
use clarity_types::types::TypeSignature;
use stacks_common::types::StacksEpochId;

use crate::vm::ClarityVersion;
use crate::vm::analysis::errors::StaticCheckErrorKind;
use crate::vm::analysis::type_checker::v2_1::natives::post_conditions::{
    MAX_ALLOWANCES, MAX_NFT_IDENTIFIERS,
};
use crate::vm::analysis::type_checker::v2_1::tests::type_check_helper_version;
use crate::vm::tests::test_clarity_versions;

/// Test type-checking for `restrict-assets?` expressions
#[apply(test_clarity_versions)]
fn test_restrict_assets(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // simple
        (
            "(restrict-assets? tx-sender ((with-stx u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // literal asset owner
        (
            "(restrict-assets? 'SM3VDXK3WZZSA84XXFKAFAF15NNZX32CTSG82JFQ4 ((with-stx u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // literal asset owner with contract id
        (
            "(restrict-assets? 'SM3VDXK3WZZSA84XXFKAFAF15NNZX32CTSG82JFQ4.sbtc-token ((with-stx u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable asset owner
        (
            "(let ((p tx-sender))
                (restrict-assets? p ((with-stx u1000)) true))",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // no allowances
        (
            "(restrict-assets? tx-sender () true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // multiple allowances
        (
            "(restrict-assets? tx-sender ((with-stx u1000) (with-ft .token \"foo\" u5000) (with-nft .token \"foo\" (list 0x01))) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // multiple body expressions
        (
            "(restrict-assets? tx-sender ((with-stx u1000)) (+ u1 u2) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];
    let bad = [
        // with-all-assets-unsafe
        (
            "(restrict-assets? tx-sender ((with-all-assets-unsafe)) true)",
            StaticCheckErrorKind::WithAllAllowanceNotAllowed,
        ),
        // no asset-owner
        (
            "(restrict-assets? ((with-stx u5000)) true)",
            StaticCheckErrorKind::RequiresAtLeastArguments(3, 2),
        ),
        // no asset-owner, 3 args
        (
            "(restrict-assets? ((with-stx u5000)) true true)",
            StaticCheckErrorKind::ExpectedListOfAllowances("restrict-assets?".into(), 2),
        ),
        // bad asset-owner type
        (
            "(restrict-assets? u100 ((with-stx u5000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::PrincipalType.into(),
                TypeSignature::UIntType.into(),
            ),
        ),
        // no allowances
        (
            "(restrict-assets? tx-sender true)",
            StaticCheckErrorKind::RequiresAtLeastArguments(3, 2),
        ),
        // allowance not in list
        (
            "(restrict-assets? tx-sender (with-stx u1) true)",
            StaticCheckErrorKind::ExpectedListApplication,
        ),
        // other value in place of allowance list
        (
            "(restrict-assets? tx-sender u1 true)",
            StaticCheckErrorKind::ExpectedListOfAllowances("restrict-assets?".into(), 2),
        ),
        // non-allowance in allowance list
        (
            "(restrict-assets? tx-sender (u1) true)",
            StaticCheckErrorKind::ExpectedListApplication,
        ),
        // empty list in allowance list
        (
            "(restrict-assets? tx-sender (()) true)",
            StaticCheckErrorKind::ExpectedListApplication,
        ),
        // list with literal in allowance list
        (
            "(restrict-assets? tx-sender ((123)) true)",
            StaticCheckErrorKind::NonFunctionApplication,
        ),
        // non-allowance function in allowance list
        (
            "(restrict-assets? tx-sender ((foo)) true)",
            StaticCheckErrorKind::ExpectedAllowanceExpr("foo".into()),
        ),
        // no body expressions
        (
            "(restrict-assets? tx-sender ((with-stx u5000)))",
            StaticCheckErrorKind::RequiresAtLeastArguments(3, 2),
        ),
        // unhandled response in only body expression
        (
            "(restrict-assets? tx-sender ((with-stx u1000)) (err u1))",
            StaticCheckErrorKind::UncheckedIntermediaryResponses,
        ),
        // unhandled response in last body expression
        (
            "(restrict-assets? tx-sender ((with-stx u1000)) true (err u1))",
            StaticCheckErrorKind::UncheckedIntermediaryResponses,
        ),
        // unhandled response in other body expression
        (
            "(restrict-assets? tx-sender ((with-stx u1000)) (err u1) true)",
            StaticCheckErrorKind::UncheckedIntermediaryResponses,
        ),
        // too many allowances
        (
            &format!(
                "(restrict-assets? tx-sender ({} ) true)",
                std::iter::repeat_n("(with-stx u1)", 130)
                    .collect::<Vec<_>>()
                    .join(" ")
            ),
            StaticCheckErrorKind::TooManyAllowances(MAX_ALLOWANCES, 130),
        ),
        // different error types thrown from body expressions
        (
            "(define-public (test)
              (restrict-assets? tx-sender ()
                (try! (if true (ok true) (err u1)))
                (try! (if true (ok 1) (err 2)))
                u0
               )
            )",
            StaticCheckErrorKind::ReturnTypesMustMatch(
                TypeSignature::new_response(TypeSignature::NoType, TypeSignature::UIntType)
                    .unwrap()
                    .into(),
                TypeSignature::new_response(TypeSignature::NoType, TypeSignature::IntType)
                    .unwrap()
                    .into(),
            ),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            // restrict-assets? is only available in Clarity 4+
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            // restrict-assets? is only available in Clarity 4+
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}

/// Test type-checking for `as-contract?` expressions
#[apply(test_clarity_versions)]
fn test_as_contract(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // simple
        (
            "(as-contract? ((with-stx u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // no allowances
        (
            "(as-contract? () true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // multiple allowances
        (
            "(as-contract? ((with-stx u1000) (with-ft .token \"foo\" u5000) (with-nft .token \"foo\" (list 0x01))) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // multiple body expressions
        (
            "(as-contract? ((with-stx u1000)) (+ u1 u2) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // with-all-assets-unsafe
        (
            "(as-contract? ((with-all-assets-unsafe)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];
    let bad = [
        // no allowances
        (
            "(as-contract? true)",
            StaticCheckErrorKind::RequiresAtLeastArguments(2, 1),
        ),
        // allowance not in list
        (
            "(as-contract? (with-stx u1) true)",
            StaticCheckErrorKind::ExpectedListApplication,
        ),
        // other value in place of allowance list
        (
            "(as-contract? u1 true)",
            StaticCheckErrorKind::ExpectedListOfAllowances("as-contract?".into(), 1),
        ),
        // non-allowance in allowance list
        (
            "(as-contract? (u1) true)",
            StaticCheckErrorKind::ExpectedListApplication,
        ),
        // empty list in allowance list
        (
            "(as-contract? (()) true)",
            StaticCheckErrorKind::ExpectedListApplication,
        ),
        // list with literal in allowance list
        (
            "(as-contract? ((123)) true)",
            StaticCheckErrorKind::NonFunctionApplication,
        ),
        // non-allowance function in allowance list
        (
            "(as-contract? ((foo)) true)",
            StaticCheckErrorKind::ExpectedAllowanceExpr("foo".into()),
        ),
        // no body expressions
        (
            "(as-contract? ((with-stx u5000)))",
            StaticCheckErrorKind::RequiresAtLeastArguments(2, 1),
        ),
        // unhandled response in only body expression
        (
            "(as-contract? ((with-stx u1000)) (err u1))",
            StaticCheckErrorKind::UncheckedIntermediaryResponses,
        ),
        // unhandled response in last body expression
        (
            "(as-contract? ((with-stx u1000)) true (err u1))",
            StaticCheckErrorKind::UncheckedIntermediaryResponses,
        ),
        // unhandled response in other body expression
        (
            "(as-contract? ((with-stx u1000)) (err u1) true)",
            StaticCheckErrorKind::UncheckedIntermediaryResponses,
        ),
        // other allowances together with with-all-assets-unsafe (first)
        (
            "(as-contract? ((with-all-assets-unsafe) (with-stx u1000)) true)",
            StaticCheckErrorKind::WithAllAllowanceNotAlone,
        ),
        // other allowances together with with-all-assets-unsafe (second)
        (
            "(as-contract? ((with-stx u1000) (with-all-assets-unsafe)) true)",
            StaticCheckErrorKind::WithAllAllowanceNotAlone,
        ),
        // too many allowances
        (
            &format!(
                "(as-contract? ({} ) true)",
                std::iter::repeat_n("(with-stx u1)", 130)
                    .collect::<Vec<_>>()
                    .join(" ")
            ),
            StaticCheckErrorKind::TooManyAllowances(MAX_ALLOWANCES, 130),
        ),
        // different error types thrown from body expressions
        (
            "(define-public (test)
              (as-contract? ()
                (try! (if true (ok true) (err u1)))
                (try! (if true (ok 1) (err 2)))
                u0
               )
            )",
            StaticCheckErrorKind::ReturnTypesMustMatch(
                TypeSignature::new_response(TypeSignature::NoType, TypeSignature::UIntType)
                    .unwrap()
                    .into(),
                TypeSignature::new_response(TypeSignature::NoType, TypeSignature::IntType)
                    .unwrap()
                    .into(),
            ),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            // as-contract? is only available in Clarity 4+
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("as-contract?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}"
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}"
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            // as-contract? is only available in Clarity 4+
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("as-contract?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}"
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}"
            );
        }
    }
}

/// Test type-checking for `with-stx` allowance expressions
#[apply(test_clarity_versions)]
fn test_with_stx_allowance(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // basic usage
        (
            "(restrict-assets? tx-sender ((with-stx u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // zero amount
        (
            "(restrict-assets? tx-sender ((with-stx u0)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // large amount
        (
            "(restrict-assets? tx-sender ((with-stx u340282366920938463463374607431768211455)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable amount
        (
            "(let ((amount u1000)) (restrict-assets? tx-sender ((with-stx amount)) true))",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // no arguments
        (
            "(restrict-assets? tx-sender ((with-stx)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(1, 0),
        ),
        // too many arguments
        (
            "(restrict-assets? tx-sender ((with-stx u1000 u2000)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(1, 2),
        ),
        // wrong type - string instead of uint
        (
            r#"(restrict-assets? tx-sender ((with-stx "1000")) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::new_ascii_type_checked(4).into(),
            ),
        ),
        // wrong type - int instead of uint
        (
            "(restrict-assets? tx-sender ((with-stx 1000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::IntType.into(),
            ),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}"
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}"
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}"
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}"
            );
        }
    }
}

/// Test type-checking for `with-ft` allowance expressions
#[apply(test_clarity_versions)]
fn test_with_ft_allowance(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // basic usage with shortcut contract principal
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "token-name" u1000)) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // full literal principal
        (
            r#"(restrict-assets? tx-sender ((with-ft 'SM3VDXK3WZZSA84XXFKAFAF15NNZX32CTSG82JFQ4.token "token-name" u1000)) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable principal
        (
            r#"(let ((contract .token)) (restrict-assets? tx-sender ((with-ft contract "token-name" u1000)) true))"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable token name
        (
            r#"(let ((name "token-name")) (restrict-assets? tx-sender ((with-ft .token name u1000)) true))"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable amount
        (
            r#"(let ((amount u1000)) (restrict-assets? tx-sender ((with-ft .token "token-name" amount)) true))"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // "*" token name
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "*" u1000)) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // empty token name
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "" u1000)) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // no arguments
        (
            "(restrict-assets? tx-sender ((with-ft)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(3, 0),
        ),
        // one argument
        (
            "(restrict-assets? tx-sender ((with-ft .token)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(3, 1),
        ),
        // two arguments
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "token-name")) true)"#,
            StaticCheckErrorKind::IncorrectArgumentCount(3, 2),
        ),
        // too many arguments
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "token-name" u1000 u2000)) true)"#,
            StaticCheckErrorKind::IncorrectArgumentCount(3, 4),
        ),
        // wrong type for contract-id - uint instead of principal
        (
            r#"(restrict-assets? tx-sender ((with-ft u123 "token-name" u1000)) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::PrincipalType.into(),
                TypeSignature::UIntType.into(),
            ),
        ),
        // wrong type for token-name - uint instead of string
        (
            "(restrict-assets? tx-sender ((with-ft .token u123 u1000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::new_ascii_type_checked(MAX_STRING_LEN as u32).into(),
                TypeSignature::UIntType.into(),
            ),
        ),
        // wrong type for amount - string instead of uint
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "token-name" "1000")) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::new_ascii_type_checked(4).into(),
            ),
        ),
        // wrong type for amount - int instead of uint
        (
            r#"(restrict-assets? tx-sender ((with-ft .token "token-name" 1000)) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::IntType.into(),
            ),
        ),
        // too long token name (longer than 128 chars)
        (
            "(restrict-assets? tx-sender ((with-ft .token \"this-token-name-is-way-too-long-to-be-valid-because-it-has-more-than-one-hundred-and-twenty-eight-characters-in-it-so-it-is-not-a-valid-token-name\" u1000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::new_ascii_type_checked(MAX_STRING_LEN as u32).into(),
                TypeSignature::new_ascii_type_checked(146u32).into(),
            ),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}

/// Test type-checking for `with-nft` allowance expressions
#[apply(test_clarity_versions)]
fn test_with_nft_allowance(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // basic usage with shortcut contract principal
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "token-name" (list u1000))) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // full literal principal
        (
            r#"(restrict-assets? tx-sender ((with-ft 'SM3VDXK3WZZSA84XXFKAFAF15NNZX32CTSG82JFQ4.token "token-name" u1000)) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable principal
        (
            r#"(let ((contract .token)) (restrict-assets? tx-sender ((with-nft contract "token-name" (list u1000))) true))"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable token name
        (
            r#"(let ((name "token-name")) (restrict-assets? tx-sender ((with-nft .token name (list u1000))) true))"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // "*" token name
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "*" (list u1000))) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // empty token name
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "" (list u1000))) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // string asset-id
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "token-name" (list "asset-123"))) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // buffer asset-id
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "token-name" (list 0x0123456789))) true)"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable asset-id
        (
            r#"(let ((asset-id (list u123))) (restrict-assets? tx-sender ((with-nft .token "token-name" asset-id)) true))"#,
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // no arguments
        (
            "(restrict-assets? tx-sender ((with-nft)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(3, 0),
        ),
        // one argument
        (
            "(restrict-assets? tx-sender ((with-nft .token)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(3, 1),
        ),
        // two arguments
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "token-name")) true)"#,
            StaticCheckErrorKind::IncorrectArgumentCount(3, 2),
        ),
        // too many arguments
        (
            r#"(restrict-assets? tx-sender ((with-nft .token "token-name" (list u123) (list u456))) true)"#,
            StaticCheckErrorKind::IncorrectArgumentCount(3, 4),
        ),
        // wrong type for contract-id - uint instead of principal
        (
            r#"(restrict-assets? tx-sender ((with-nft u123 "token-name" (list u456))) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::PrincipalType.into(),
                TypeSignature::UIntType.into(),
            ),
        ),
        // wrong type for token-name - uint instead of string
        (
            "(restrict-assets? tx-sender ((with-nft .token u123 (list u456))) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::new_ascii_type_checked(MAX_STRING_LEN as u32).into(),
                TypeSignature::UIntType.into(),
            ),
        ),
        // too long token name (longer than 128 chars)
        (
            "(restrict-assets? tx-sender ((with-ft .token \"this-token-name-is-way-too-long-to-be-valid-because-it-has-more-than-one-hundred-and-twenty-eight-characters-in-it-so-it-is-not-a-valid-token-name\" u1000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::new_ascii_type_checked(MAX_STRING_LEN as u32).into(),
                TypeSignature::new_ascii_type_checked(146u32).into(),
            ),
        ),
        // too many identifiers (more than 128)
        (
            &format!(
                "(restrict-assets? tx-sender ((with-nft .token \"token-name\" (list {}))) true)",
                std::iter::repeat_n("u1", 130).collect::<Vec<_>>().join(" ")
            ),
            StaticCheckErrorKind::MaxIdentifierLengthExceeded(MAX_NFT_IDENTIFIERS, 130),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}

/// Test type-checking for `with-stacking` allowance expressions
#[apply(test_clarity_versions)]
fn test_with_stacking_allowance(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // basic usage
        (
            "(restrict-assets? tx-sender ((with-stacking u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // zero amount
        (
            "(restrict-assets? tx-sender ((with-stacking u0)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable amount
        (
            "(let ((amount u1000)) (restrict-assets? tx-sender ((with-stacking amount)) true))",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // no arguments
        (
            "(restrict-assets? tx-sender ((with-stacking)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(1, 0),
        ),
        // too many arguments
        (
            "(restrict-assets? tx-sender ((with-stacking u1000 u2000)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(1, 2),
        ),
        // wrong type - string instead of uint
        (
            r#"(restrict-assets? tx-sender ((with-stacking "1000")) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::new_ascii_type_checked(4).into(),
            ),
        ),
        // wrong type - int instead of uint
        (
            "(restrict-assets? tx-sender ((with-stacking 1000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::IntType.into(),
            ),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            // `restrict-assets?` itself does not exist before Clarity 4.
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else if version >= ClarityVersion::Clarity6 {
            // `with-stacking` was renamed to `with-staking` in Clarity 6.
            assert_eq!(
                StaticCheckErrorKind::ExpectedAllowanceExpr("with-stacking".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else if version >= ClarityVersion::Clarity6 {
            assert_eq!(
                StaticCheckErrorKind::ExpectedAllowanceExpr("with-stacking".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}

/// Test type-checking for `with-staking` allowance expressions (the Clarity 6+
/// spelling of `with-stacking`).
#[apply(test_clarity_versions)]
fn test_with_staking_allowance(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // basic usage
        (
            "(restrict-assets? tx-sender ((with-staking u1000)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // zero amount
        (
            "(restrict-assets? tx-sender ((with-staking u0)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
        // variable amount
        (
            "(let ((amount u1000)) (restrict-assets? tx-sender ((with-staking amount)) true))",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // no arguments
        (
            "(restrict-assets? tx-sender ((with-staking)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(1, 0),
        ),
        // too many arguments
        (
            "(restrict-assets? tx-sender ((with-staking u1000 u2000)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(1, 2),
        ),
        // wrong type - string instead of uint
        (
            r#"(restrict-assets? tx-sender ((with-staking "1000")) true)"#,
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::new_ascii_type_checked(4).into(),
            ),
        ),
        // wrong type - int instead of uint
        (
            "(restrict-assets? tx-sender ((with-staking 1000)) true)",
            StaticCheckErrorKind::TypeError(
                TypeSignature::UIntType.into(),
                TypeSignature::IntType.into(),
            ),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            // `restrict-assets?` itself does not exist before Clarity 4.
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else if version < ClarityVersion::Clarity6 {
            // `with-staking` was introduced in Clarity 6; before that the
            // allowance was spelled `with-stacking`.
            assert_eq!(
                StaticCheckErrorKind::ExpectedAllowanceExpr("with-staking".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else if version < ClarityVersion::Clarity6 {
            assert_eq!(
                StaticCheckErrorKind::ExpectedAllowanceExpr("with-staking".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}

/// Test type-checking for `with-pox` allowance expressions
#[apply(test_clarity_versions)]
fn test_with_pox_allowance(#[case] version: ClarityVersion, #[case] epoch: StacksEpochId) {
    let good = [
        // basic usage (no arguments)
        (
            "(restrict-assets? tx-sender ((with-pox)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // too many arguments
        (
            "(restrict-assets? tx-sender ((with-pox u1000)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(0, 1),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            // `restrict-assets?` itself does not exist before Clarity 4.
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else if version < ClarityVersion::Clarity6 {
            // `restrict-assets?` exists, but `with-pox` was added in
            // Clarity 6, so it is not a recognized allowance expression yet.
            assert_eq!(
                StaticCheckErrorKind::ExpectedAllowanceExpr("with-pox".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else if version < ClarityVersion::Clarity6 {
            assert_eq!(
                StaticCheckErrorKind::ExpectedAllowanceExpr("with-pox".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}

/// Test type-checking for `with-all-assets-unsafe` allowance expressions
#[apply(test_clarity_versions)]
fn test_with_all_assets_unsafe_allowance(
    #[case] version: ClarityVersion,
    #[case] epoch: StacksEpochId,
) {
    let good = [
        // basic usage
        (
            "(as-contract? ((with-all-assets-unsafe)) true)",
            TypeSignature::new_response(TypeSignature::BoolType, TypeSignature::UIntType).unwrap(),
        ),
    ];

    let bad = [
        // with-all-assets-unsafe in restrict-assets? (not allowed)
        (
            "(restrict-assets? tx-sender ((with-all-assets-unsafe)) true)",
            StaticCheckErrorKind::WithAllAllowanceNotAllowed,
        ),
        // with-all-assets-unsafe with arguments (should take 0)
        (
            "(restrict-assets? tx-sender ((with-all-assets-unsafe u123)) true)",
            StaticCheckErrorKind::IncorrectArgumentCount(0, 1),
        ),
    ];

    for (code, expected_type) in &good {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("as-contract?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_type,
                &type_check_helper_version(code, version, epoch).unwrap(),
                "{code}",
            );
        }
    }

    for (code, expected_err) in &bad {
        if version < ClarityVersion::Clarity4 {
            assert_eq!(
                StaticCheckErrorKind::UnknownFunction("restrict-assets?".to_string()),
                *type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err,
                "{code}",
            );
        } else {
            assert_eq!(
                expected_err,
                type_check_helper_version(code, version, epoch)
                    .unwrap_err()
                    .err
                    .as_ref(),
                "{code}",
            );
        }
    }
}
