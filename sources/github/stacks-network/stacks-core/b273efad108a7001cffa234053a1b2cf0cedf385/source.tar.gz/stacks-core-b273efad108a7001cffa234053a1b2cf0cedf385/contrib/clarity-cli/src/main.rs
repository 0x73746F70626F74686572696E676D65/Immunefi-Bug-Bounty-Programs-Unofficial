// Copyright (C) 2013-2020 Blockstack PBC, a public benefit corporation
// Copyright (C) 2020 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

use std::path::PathBuf;
use std::process;

use clap::{Parser, Subcommand};
use clarity::vm::types::{PrincipalData, QualifiedContractIdentifier};
use clarity::vm::{ClarityVersion, SymbolicExpression};
use clarity_cli::{
    DEFAULT_CLI_EPOCH, execute_check, execute_eval, execute_eval_at_block,
    execute_eval_at_chaintip, execute_eval_raw, execute_execute, execute_generate_address,
    execute_initialize, execute_launch, execute_repl, friendly_expect, friendly_expect_opt,
    read_file_or_stdin, read_optional_file_or_stdin, vm_execute_in_epoch,
};
use stacks_common::types::StacksEpochId;

/// Parse epoch string to StacksEpochId
fn parse_epoch(epoch_str: Option<&String>) -> StacksEpochId {
    if let Some(s) = epoch_str {
        friendly_expect(s.parse::<StacksEpochId>(), &format!("Invalid epoch: {s}"))
    } else {
        DEFAULT_CLI_EPOCH
    }
}

/// Parse clarity_version string. Defaults to version for epoch if not specified.
fn parse_clarity_version(cv_str: Option<&String>, epoch: StacksEpochId) -> ClarityVersion {
    if let Some(s) = cv_str {
        friendly_expect(
            s.parse::<ClarityVersion>(),
            &format!("Invalid clarity version: {s}"),
        )
    } else {
        ClarityVersion::default_for_epoch(epoch)
    }
}

/// Parse allocations from JSON file or stdin
fn parse_allocations(allocations_file: &Option<PathBuf>) -> Vec<(PrincipalData, u64)> {
    if let Some(filename) = allocations_file {
        let json_in = read_file_or_stdin(filename.to_str().expect("Invalid UTF-8 in path"));
        friendly_expect(
            clarity_cli::parse_allocations_json(&json_in),
            "Failed to parse allocations file",
        )
    } else {
        vec![]
    }
}

#[derive(Parser)]
#[command(name = "clarity-cli")]
#[command(about = "Clarity smart contract command-line interface", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Initialize a local VM state database
    #[command(name = "initialize")]
    Initialize {
        /// Use testnet bootcode and block-limits instead of mainnet
        #[arg(long)]
        testnet: bool,

        /// Stacks epoch to use
        #[arg(long)]
        epoch: Option<String>,

        /// Path to VM state database
        #[arg(value_name = "DB_PATH")]
        db_path: PathBuf,

        /// Initial allocations JSON file (or "-" for stdin)
        #[arg(value_name = "ALLOCATIONS_FILE")]
        allocations_file: Option<PathBuf>,
    },

    /// Generate a random Stacks public address
    #[command(name = "generate-address")]
    GenerateAddress,

    /// Typecheck a potential contract definition
    #[command(name = "check")]
    Check {
        /// Contract source file (or "-" for stdin)
        #[arg(value_name = "CONTRACT_FILE")]
        contract_file: PathBuf,

        /// Contract identifier
        #[arg(long)]
        contract_id: Option<String>,

        /// Output contract analysis
        #[arg(long)]
        output_analysis: bool,

        /// Output cost information
        #[arg(long)]
        costs: bool,

        /// Use testnet configuration
        #[arg(long)]
        testnet: bool,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Path to VM state database (optional; if omitted, uses in-memory analysis)
        #[arg(value_name = "DB_PATH")]
        db_path: Option<PathBuf>,
    },

    /// Typecheck and evaluate expressions in a stdin/stdout loop
    #[command(name = "repl")]
    Repl {
        /// Use testnet configuration
        #[arg(long)]
        testnet: bool,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,
    },

    /// Typecheck and evaluate an expression without a contract or database context.
    ///
    /// Stdin examples:
    ///
    ///   echo "(+ 1 2)" | clarity-cli eval-raw
    ///
    ///   clarity-cli eval-raw <<< "(+ 1 2)"
    #[command(name = "eval-raw")]
    EvalRaw {
        /// Use testnet configuration
        #[arg(long)]
        testnet: bool,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Program file (or "-" for stdin; if omitted, reads from stdin)
        #[arg(value_name = "PROGRAM_FILE")]
        program_file: Option<PathBuf>,
    },

    /// Evaluate (in read-only mode) a program in a given contract context.
    ///
    /// Stdin examples:
    ///
    ///   echo "(+ 1 2)" | clarity-cli eval ...
    ///
    ///   clarity-cli eval ... <<< "(+ 1 2)"
    #[command(name = "eval")]
    Eval {
        /// Output cost information
        #[arg(long)]
        costs: bool,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Contract identifier
        #[arg(value_name = "CONTRACT_ID")]
        contract_id: String,

        /// Path to VM state database
        #[arg(value_name = "DB_PATH")]
        db_path: PathBuf,

        /// Program file (or "-" for stdin; if omitted, reads from stdin)
        #[arg(value_name = "PROGRAM_FILE")]
        program_file: Option<PathBuf>,
    },

    /// Like eval, but does not advance to a new block.
    ///
    /// Stdin examples:
    ///
    ///   echo "(+ 1 2)" | clarity-cli eval-at-chaintip ...
    ///
    ///   clarity-cli eval-at-chaintip ... <<< "(+ 1 2)"
    #[command(name = "eval-at-chaintip")]
    EvalAtChaintip {
        /// Output cost information
        #[arg(long)]
        costs: bool,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Contract identifier
        #[arg(value_name = "CONTRACT_ID")]
        contract_id: String,

        /// Path to VM state database
        #[arg(value_name = "DB_PATH")]
        db_path: PathBuf,

        /// Program file (or "-" for stdin; if omitted, reads from stdin)
        #[arg(value_name = "PROGRAM_FILE")]
        program_file: Option<PathBuf>,
    },

    /// Like eval-at-chaintip, but accepts an index-block-hash to evaluate at.
    ///
    /// Stdin examples:
    ///
    ///   echo "(+ 1 2)" | clarity-cli eval-at-block ...
    ///
    ///   clarity-cli eval-at-block ... <<< "(+ 1 2)"
    #[command(name = "eval-at-block")]
    EvalAtBlock {
        /// Output cost information
        #[arg(long)]
        costs: bool,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Index block hash
        #[arg(value_name = "INDEX_BLOCK_HASH")]
        index_block_hash: String,

        /// Contract identifier
        #[arg(value_name = "CONTRACT_ID")]
        contract_id: String,

        /// Path to VM/clarity directory
        #[arg(value_name = "VM_DIR")]
        vm_dir: PathBuf,

        /// Program file (or "-" for stdin; if omitted, reads from stdin)
        #[arg(value_name = "PROGRAM_FILE")]
        program_file: Option<PathBuf>,
    },

    /// Deploy a new contract in the local state database
    #[command(name = "launch")]
    Launch {
        /// Output cost information
        #[arg(long)]
        costs: bool,

        /// Output asset changes
        #[arg(long)]
        assets: bool,

        /// Output contract analysis
        #[arg(long)]
        output_analysis: bool,

        /// Contract identifier
        #[arg(value_name = "CONTRACT_ID")]
        contract_id: String,

        /// Contract definition file (or "-" for stdin)
        #[arg(value_name = "CONTRACT_FILE")]
        contract_file: PathBuf,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Path to VM state database
        #[arg(value_name = "DB_PATH")]
        db_path: PathBuf,
    },

    /// Execute a public function of a defined contract.
    ///
    /// Arguments must be valid Clarity values (e.g., "u10" for uint, "'ST1..." for principal).
    /// Note: Principals require the Clarity quote prefix (').
    #[command(name = "execute")]
    Execute {
        /// Output cost information
        #[arg(long)]
        costs: bool,

        /// Output asset changes
        #[arg(long)]
        assets: bool,

        /// Clarity version
        #[arg(long)]
        clarity_version: Option<String>,

        /// Stacks epoch
        #[arg(long)]
        epoch: Option<String>,

        /// Contract identifier
        #[arg(value_name = "CONTRACT_ID")]
        contract_id: String,

        /// Public function name
        #[arg(value_name = "FUNCTION_NAME")]
        function_name: String,

        /// Sender address
        #[arg(value_name = "SENDER")]
        sender: String,

        /// Path to VM state database
        #[arg(value_name = "DB_PATH")]
        db_path: PathBuf,

        /// Function arguments
        #[arg(value_name = "ARGS")]
        args: Vec<String>,
    },
}

fn main() {
    let cli = Cli::parse();

    let (exit_code, output) = match &cli.command {
        Commands::GenerateAddress => execute_generate_address(),

        Commands::Initialize {
            testnet,
            epoch,
            db_path,
            allocations_file,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let mainnet = !testnet;
            let allocations = parse_allocations(allocations_file);
            let db_name = db_path.to_str().expect("Invalid UTF-8 in db_path");

            execute_initialize(db_name, mainnet, epoch_id, allocations)
        }

        Commands::Check {
            contract_file,
            contract_id,
            output_analysis,
            costs,
            testnet,
            clarity_version,
            epoch,
            db_path,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);
            let mainnet = !testnet;

            let content = read_file_or_stdin(
                contract_file
                    .to_str()
                    .expect("Invalid UTF-8 in contract_file"),
            );

            let cid = if let Some(cid_str) = contract_id {
                friendly_expect(
                    QualifiedContractIdentifier::parse(cid_str),
                    &format!("Error parsing contract identifier '{cid_str}'"),
                )
            } else {
                QualifiedContractIdentifier::transient()
            };

            let db_path_str = db_path
                .as_ref()
                .map(|p| p.to_str().expect("Invalid UTF-8 in db_path"));

            execute_check(
                &content,
                &cid,
                *output_analysis,
                *costs,
                mainnet,
                clarity_ver,
                epoch_id,
                db_path_str,
                *testnet,
            )
        }

        Commands::Repl {
            testnet,
            epoch,
            clarity_version,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);
            let mainnet = !testnet;
            execute_repl(mainnet, epoch_id, clarity_ver)
        }

        Commands::EvalRaw {
            testnet,
            epoch,
            clarity_version,
            program_file,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);
            let mainnet = !testnet;

            let content = read_optional_file_or_stdin(program_file.as_ref());

            execute_eval_raw(&content, mainnet, epoch_id, clarity_ver)
        }

        Commands::Eval {
            costs,
            epoch,
            clarity_version,
            contract_id,
            program_file,
            db_path,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);

            let cid = friendly_expect(
                QualifiedContractIdentifier::parse(contract_id),
                "Failed to parse contract identifier",
            );

            let content = read_optional_file_or_stdin(program_file.as_ref());

            let db_path_str = db_path.to_str().expect("Invalid UTF-8 in db_path");

            execute_eval(&cid, &content, *costs, epoch_id, clarity_ver, db_path_str)
        }

        Commands::EvalAtChaintip {
            costs,
            epoch,
            clarity_version,
            contract_id,
            program_file,
            db_path,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);

            let cid = friendly_expect(
                QualifiedContractIdentifier::parse(contract_id),
                "Failed to parse contract identifier",
            );

            let content = read_optional_file_or_stdin(program_file.as_ref());

            let db_path_str = db_path.to_str().expect("Invalid UTF-8 in db_path");

            execute_eval_at_chaintip(&cid, &content, *costs, epoch_id, clarity_ver, db_path_str)
        }

        Commands::EvalAtBlock {
            costs,
            epoch,
            index_block_hash,
            contract_id,
            program_file,
            clarity_version,
            vm_dir,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);

            let cid = friendly_expect(
                QualifiedContractIdentifier::parse(contract_id),
                "Failed to parse contract identifier",
            );

            let content = read_optional_file_or_stdin(program_file.as_ref());

            let vm_dir_str = vm_dir.to_str().expect("Invalid UTF-8 in vm_dir");

            execute_eval_at_block(
                index_block_hash,
                &cid,
                &content,
                *costs,
                epoch_id,
                clarity_ver,
                vm_dir_str,
            )
        }

        Commands::Launch {
            costs,
            assets,
            output_analysis,
            contract_id,
            contract_file,
            clarity_version,
            epoch,
            db_path,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);

            let cid = friendly_expect(
                QualifiedContractIdentifier::parse(contract_id),
                "Failed to parse contract identifier",
            );

            let contract_src_file = contract_file
                .to_str()
                .expect("Invalid UTF-8 in contract_file");
            let contract_content = read_file_or_stdin(contract_src_file);

            let db_path_str = db_path.to_str().expect("Invalid UTF-8 in db_path");

            execute_launch(
                &cid,
                &contract_content,
                *costs,
                *assets,
                *output_analysis,
                epoch_id,
                clarity_ver,
                db_path_str,
            )
        }

        Commands::Execute {
            costs,
            assets,
            clarity_version,
            epoch,
            db_path,
            contract_id,
            function_name,
            sender,
            args: fn_args,
        } => {
            let epoch_id = parse_epoch(epoch.as_ref());
            let clarity_ver = parse_clarity_version(clarity_version.as_ref(), epoch_id);

            let cid = friendly_expect(
                QualifiedContractIdentifier::parse(contract_id),
                "Failed to parse contract identifier",
            );

            let sender_principal = PrincipalData::Standard(friendly_expect(
                PrincipalData::parse_standard_principal(sender),
                &format!("Unexpected result parsing sender {sender}"),
            ));

            let arguments: Vec<_> = fn_args
                .iter()
                .map(|argument| {
                    let argument_parsed = friendly_expect(
                        vm_execute_in_epoch(argument, clarity_ver, epoch_id),
                        &format!("Error parsing argument '{argument}'"),
                    );
                    let argument_value = friendly_expect_opt(
                        argument_parsed,
                        &format!("Failed to parse a value from the argument '{argument}'"),
                    );
                    SymbolicExpression::atom_value(argument_value)
                })
                .collect();

            let db_path_str = db_path.to_str().expect("Invalid UTF-8 in db_path");

            execute_execute(
                db_path_str,
                &cid,
                function_name,
                sender_principal,
                &arguments,
                *costs,
                *assets,
                epoch_id,
            )
        }
    };

    // Output JSON result if present
    if let Some(json_output) = output {
        println!("{}", serde_json::to_string(&json_output).unwrap());
    }

    process::exit(exit_code);
}

#[cfg(test)]
mod tests {
    use clap::CommandFactory;

    use super::*;

    /// Validates the clap CLI structure has no configuration errors
    #[test]
    fn verify_cli_structure() {
        Cli::command().debug_assert();
    }

    /// Tests that variadic arguments after positional args are collected correctly.
    #[test]
    fn test_execute_variadic_args() {
        let cli = Cli::try_parse_from([
            "clarity-cli",
            "execute",
            "ST1.contract",
            "transfer",
            "ST1SENDER",
            "/tmp/db",
            "u100",
            "'ST1RECIPIENT",
            "(list u1 u2 u3)",
        ])
        .unwrap();
        match cli.command {
            Commands::Execute { args, .. } => {
                assert_eq!(args, vec!["u100", "'ST1RECIPIENT", "(list u1 u2 u3)"]);
            }
            _ => panic!("Expected Execute command"),
        }
    }

    /// Tests that commands with many required positional args fail appropriately
    /// when args are missing. Execute has the most complex arg structure.
    #[test]
    fn test_execute_missing_required_args() {
        assert!(Cli::try_parse_from(["clarity-cli", "execute"]).is_err());
        assert!(Cli::try_parse_from(["clarity-cli", "execute", "ST1.contract"]).is_err());
        assert!(Cli::try_parse_from(["clarity-cli", "execute", "ST1.contract", "func"]).is_err());
        assert!(
            Cli::try_parse_from(["clarity-cli", "execute", "ST1.contract", "func", "SENDER"])
                .is_err()
        );
    }

    /// Tests that launch (another command with multiple required args) validates correctly
    #[test]
    fn test_launch_missing_required_args() {
        assert!(Cli::try_parse_from(["clarity-cli", "launch"]).is_err());
        assert!(Cli::try_parse_from(["clarity-cli", "launch", "ST1.contract"]).is_err());
        assert!(
            Cli::try_parse_from(["clarity-cli", "launch", "ST1.contract", "file.clar"]).is_err()
        );
    }

    /// Verifies unknown subcommands are rejected
    #[test]
    fn test_unknown_command_rejected() {
        assert!(Cli::try_parse_from(["clarity-cli", "unknown-command"]).is_err());
    }

    /// Verifies running with no subcommand is rejected
    #[test]
    fn test_no_command_rejected() {
        assert!(Cli::try_parse_from(["clarity-cli"]).is_err());
    }
}
