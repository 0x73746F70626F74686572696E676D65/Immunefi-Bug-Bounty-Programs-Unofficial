// Copyright (C) 2025-2026 Stacks Open Internet Foundation
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#[macro_use]
extern crate stacks_common;

use clap::Parser;
use clarity::consts::CHAIN_ID_MAINNET;
use clarity::types::StacksEpochId;
use clarity::types::chainstate::StacksPrivateKey;
use clarity_cli::{DEFAULT_CLI_EPOCH, read_file_or_stdin, read_file_or_stdin_bytes, vm_execute};
use stacks_common::alloc_tracker::TrackingAllocator;
use stacks_inspect::cli::{Cli, Command};
use stacks_inspect::{
    CommonOpts, command_contract_hash, command_replay_mock_mining, command_try_mine,
    command_validate_block,
};
use stackslib::chainstate::stacks::miner::BlockBuilderSettings;
use stackslib::chainstate::stacks::{
    CoinbasePayload, StacksBlock, StacksBlockBuilder, StacksMicroblock, StacksTransaction,
    StacksTransactionSigner, TransactionAnchorMode, TransactionAuth,
    TransactionAuthVerificationMode, TransactionPayload, TransactionVersion,
};
use stackslib::config::{Config, ConfigFile};
#[cfg(not(any(target_os = "macos", target_os = "windows", target_arch = "arm")))]
use tikv_jemallocator::Jemalloc;

#[cfg(not(any(target_os = "macos", target_os = "windows", target_arch = "arm")))]
#[global_allocator]
static GLOBAL: TrackingAllocator<Jemalloc> = TrackingAllocator { inner: Jemalloc };

#[cfg(any(target_os = "macos", target_os = "windows", target_arch = "arm"))]
#[global_allocator]
static GLOBAL: TrackingAllocator<std::alloc::System> = TrackingAllocator {
    inner: std::alloc::System,
};

use std::collections::{BTreeMap, HashMap};
use std::fs::File;
use std::io::BufReader;
use std::io::prelude::*;
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::time::{Duration, Instant};
use std::{fs, io, process};

use libstackerdb::StackerDBChunkData;
use rusqlite::{Error as SqliteError, OpenFlags, params};
use serde_json::{Value, json};
use stacks_common::codec::{StacksMessageCodec, read_next};
use stacks_common::types::MempoolCollectionBehavior;
use stacks_common::types::chainstate::{
    BlockHeaderHash, BurnchainHeaderHash, StacksAddress, StacksBlockId,
};
use stacks_common::types::net::{PeerAddress, PeerHost};
use stacks_common::types::sqlite::NO_PARAMS;
use stacks_common::util::get_epoch_time_ms;
use stacks_common::util::hash::{Hash160, hex_bytes, to_hex};
use stacks_common::util::retry::LogReader;
use stacks_common::util::secp256k1::{Secp256k1PrivateKey, Secp256k1PublicKey};
use stacks_common::util::vrf::VRFProof;
use stackslib::burnchains::bitcoin::{BitcoinNetworkType, spv};
use stackslib::burnchains::db::BurnchainDB;
use stackslib::burnchains::{Address, Burnchain, PoxConstants};
use stackslib::chainstate::burn::db::sortdb::{
    PoxAnchorSelection, SortitionDB, SortitionHandle, get_block_commit_by_txid,
};
use stackslib::chainstate::burn::operations::BlockstackOperationType;
use stackslib::chainstate::burn::{BlockSnapshot, ConsensusHash};
use stackslib::chainstate::coordinator::{OnChainRewardSetProvider, get_reward_cycle_info};
use stackslib::chainstate::nakamoto::{NakamotoBlock, NakamotoChainState};
use stackslib::chainstate::stacks::StacksBlockHeader;
use stackslib::chainstate::stacks::db::{
    StacksAccount, StacksBlockHeaderTypes, StacksChainState, StacksHeaderInfo,
};
use stackslib::chainstate::stacks::index::marf::{MARF, MARFOpenOpts, MarfConnection};
use stackslib::clarity::vm::ClarityVersion;
use stackslib::clarity::vm::costs::ExecutionCost;
use stackslib::clarity::vm::types::StacksAddressExtensions;
use stackslib::core::MemPoolDB;
use stackslib::cost_estimates::UnitEstimator;
use stackslib::cost_estimates::metrics::UnitMetric;
use stackslib::net::api::getinfo::RPCPeerInfoData;
use stackslib::net::db::LocalPeer;
use stackslib::net::httpcore::{StacksHttpRequest, send_http_request};
use stackslib::net::p2p::PeerNetwork;
use stackslib::net::{GetNakamotoInvData, HandshakeData, StacksMessage, StacksMessageType};
use stackslib::util_lib::db::sqlite_open;
use stackslib::util_lib::strings::UrlString;

struct P2PSession {
    pub local_peer: LocalPeer,
    peer_info: RPCPeerInfoData,
    burn_block_hash: BurnchainHeaderHash,
    stable_burn_block_hash: BurnchainHeaderHash,
    tcp_socket: TcpStream,
    seq: u32,
}

impl P2PSession {
    /// Make a StacksMessage.  Sign it and set a sequence number.
    fn make_peer_message(&mut self, payload: StacksMessageType) -> Result<StacksMessage, String> {
        let mut msg = StacksMessage::new(
            self.peer_info.peer_version,
            self.peer_info.network_id,
            self.peer_info.burn_block_height,
            &self.burn_block_hash,
            self.peer_info.stable_burn_block_height,
            &self.stable_burn_block_hash,
            payload,
        );

        msg.sign(self.seq, &self.local_peer.private_key)
            .map_err(|e| format!("Failed to sign message {msg:?}: {e:?}"))?;
        self.seq = self.seq.wrapping_add(1);

        Ok(msg)
    }

    /// Send a p2p message.
    /// Returns error text on failure.
    fn send_peer_message(&mut self, msg: StacksMessage) -> Result<(), String> {
        msg.consensus_serialize(&mut self.tcp_socket)
            .map_err(|e| format!("Failed to send message {msg:?}: {e:?}"))
    }

    /// Receive a p2p message.
    /// Returns error text on failure.
    fn recv_peer_message(&mut self) -> Result<StacksMessage, String> {
        let msg: StacksMessage = read_next(&mut self.tcp_socket)
            .map_err(|e| format!("Failed to receive message: {e:?}"))?;
        Ok(msg)
    }

    /// Begin a p2p session.
    /// Synthesizes a LocalPeer from the remote peer's responses to /v2/info and /v2/pox.
    /// Performs the initial handshake for you.
    ///
    /// Returns the session handle on success.
    /// Returns error text on failure.
    pub fn begin(peer_addr: SocketAddr, data_port: u16) -> Result<Self, String> {
        let mut data_addr = peer_addr;
        data_addr.set_port(data_port);

        // get /v2/info
        let peer_info = send_http_request(
            &format!("{}", data_addr.ip()),
            data_addr.port(),
            StacksHttpRequest::new_getinfo(PeerHost::from(data_addr), None)
                .with_header("Connection".to_string(), "close".to_string()),
            Duration::from_secs(60),
        )
        .map_err(|e| format!("Failed to query /v2/info: {e:?}"))?
        .decode_peer_info()
        .map_err(|e| format!("Failed to decode response from /v2/info: {e:?}"))?;

        // convert `pox_consensus` and `stable_pox_consensus` into their respective burn block
        // hashes
        let sort_info = send_http_request(
            &format!("{}", data_addr.ip()),
            data_addr.port(),
            StacksHttpRequest::new_get_sortition_consensus(
                PeerHost::from(data_addr),
                &peer_info.pox_consensus,
            )
            .with_header("Connection".to_string(), "close".to_string()),
            Duration::from_secs(60),
        )
        .map_err(|e| format!("Failed to query /v3/sortitions: {e:?}"))?
        .decode_sortition_info()
        .map_err(|e| format!("Failed to decode response from /v3/sortitions: {e:?}"))?
        .pop()
        .ok_or_else(|| format!("No sortition returned for {}", peer_info.pox_consensus))?;

        let stable_sort_info = send_http_request(
            &format!("{}", data_addr.ip()),
            data_addr.port(),
            StacksHttpRequest::new_get_sortition_consensus(
                PeerHost::from(data_addr),
                &peer_info.stable_pox_consensus,
            )
            .with_header("Connection".to_string(), "close".to_string()),
            Duration::from_secs(60),
        )
        .map_err(|e| format!("Failed to query stable /v3/sortitions: {e:?}"))?
        .decode_sortition_info()
        .map_err(|e| format!("Failed to decode response from stable /v3/sortitions: {e:?}",))?
        .pop()
        .ok_or_else(|| {
            format!(
                "No sortition returned for {}",
                peer_info.stable_pox_consensus
            )
        })?;

        let burn_block_hash = sort_info.burn_block_hash;
        let stable_burn_block_hash = stable_sort_info.burn_block_hash;

        let local_peer = LocalPeer::new(
            peer_info.network_id,
            peer_info.parent_network_id,
            PeerAddress::from_socketaddr(&peer_addr),
            peer_addr.port(),
            Some(StacksPrivateKey::random()),
            u64::MAX,
            UrlString::try_from(format!("http://127.0.0.1:{data_port}",)).unwrap(),
            vec![],
        );

        let tcp_socket = TcpStream::connect(peer_addr)
            .map_err(|e| format!("Failed to open {peer_addr:?}: {e:?}"))?;

        let mut session = Self {
            local_peer,
            peer_info,
            burn_block_hash,
            stable_burn_block_hash,
            tcp_socket,
            seq: 0,
        };

        // perform the handshake
        let handshake_data =
            StacksMessageType::Handshake(HandshakeData::from_local_peer(&session.local_peer));
        let handshake = session.make_peer_message(handshake_data)?;
        session.send_peer_message(handshake)?;

        let resp = session.recv_peer_message()?;
        match resp.payload {
            StacksMessageType::HandshakeAccept(..)
            | StacksMessageType::StackerDBHandshakeAccept(..) => {}
            x => {
                return Err(format!(
                    "Peer returned unexpected message (expected HandshakeAccept variant): {x:?}",
                ));
            }
        }

        Ok(session)
    }
}

fn open_nakamoto_chainstate_dbs(
    chainstate_dir: &str,
    network: &str,
) -> (SortitionDB, StacksChainState) {
    let (mainnet, chain_id, pox_constants, dirname) = match network {
        "mainnet" => (
            true,
            CHAIN_ID_MAINNET,
            PoxConstants::mainnet_default(),
            network,
        ),
        "krypton" => (
            false,
            0x80000100,
            PoxConstants::nakamoto_testnet_default(),
            network,
        ),
        "naka3" => (
            false,
            0x80000000,
            PoxConstants::new(
                20,
                5,
                3,
                100,
                0,
                u64::MAX,
                u64::MAX,
                104,
                105,
                106,
                107,
                108,
            ),
            "nakamoto-neon",
        ),
        _ => {
            panic!("Unrecognized network name '{network}'");
        }
    };

    let chain_state_path = format!("{chainstate_dir}/{dirname}/chainstate/");
    let sort_db_path = format!("{chainstate_dir}/{dirname}/burnchain/sortition/");

    let sort_db = SortitionDB::open(&sort_db_path, true, pox_constants, None)
        .unwrap_or_else(|_| panic!("Failed to open {sort_db_path}"));

    let (chain_state, _) = StacksChainState::open(mainnet, chain_id, &chain_state_path, None)
        .expect("Failed to open stacks chain state");

    (sort_db, chain_state)
}

/// Look up `addr`'s account as of the Stacks block `tip`.
fn get_nakamoto_account(
    chain_state: &mut StacksChainState,
    sort_db: &SortitionDB,
    addr: &StacksAddress,
    tip: &StacksHeaderInfo,
) -> Option<StacksAccount> {
    let snapshot = SortitionDB::get_block_snapshot_consensus(sort_db.conn(), &tip.consensus_hash)
        .expect("Failed to query the sortition DB")?;
    chain_state.with_read_only_clarity_tx(
        &sort_db.index_handle(&snapshot.sortition_id),
        &tip.index_block_hash(),
        |clarity_conn| StacksChainState::get_account(clarity_conn, &addr.to_account_principal()),
    )
}

fn check_nakamoto_network(network: &str) {
    if network != "mainnet" && network != "krypton" && network != "naka3" {
        eprintln!("Unknown network '{network}': only support 'mainnet', 'krypton', or 'naka3'");
        process::exit(1);
    }
}

fn build_common_opts(cli: &Cli) -> CommonOpts {
    let mut opts = CommonOpts::default();

    // Handle --config option
    if let Some(ref config_path) = cli.config {
        let config_file = ConfigFile::from_path(config_path).unwrap_or_else(|e| {
            panic!("Failed to read '{config_path}' as stacks-node config: {e}")
        });
        let config = Config::from_config_file(config_file, false)
            .unwrap_or_else(|e| panic!("Failed to convert config file into node config: {e}"));
        // Install the config-driven process-wide state (the pox-5 sBTC contract and admin
        // overrides) exactly as the node's run loop does, so that a replay which crosses the
        // Epoch 4.0 boundary instantiates the same pox-5 body as the chain being replayed.
        config.apply_runtime_state();
        opts.config.replace(config);
    }

    // Handle --network-config option
    if let Some(ref network) = cli.network_config {
        let config_file = match network.to_lowercase().as_str() {
            "helium" => ConfigFile::helium(),
            "mainnet" => ConfigFile::mainnet(),
            "mocknet" => ConfigFile::mocknet(),
            "xenon" => ConfigFile::xenon(),
            other => {
                eprintln!("Unknown network choice `{other}`");
                process::exit(1);
            }
        };
        let config = Config::from_config_file(config_file, false)
            .unwrap_or_else(|e| panic!("Failed to convert config file into node config: {e}"));
        // Install the config-driven process-wide state (the pox-5 sBTC contract and admin
        // overrides) exactly as the node's run loop does, so that a replay which crosses the
        // Epoch 4.0 boundary instantiates the same pox-5 body as the chain being replayed.
        config.apply_runtime_state();
        opts.config.replace(config);
    }

    opts
}

#[cfg_attr(test, mutants::skip)]
fn main() {
    let cli = Cli::parse();
    let common_opts = build_common_opts(&cli);

    match cli.command {
        // Decode Commands
        Command::DecodeBitcoinHeader {
            block_height,
            headers_path,
            testnet,
            regtest,
        } => {
            if regtest && testnet {
                // Don't allow both
                eprintln!("Cannot specify both --testnet and --regtest");
                process::exit(1);
            }

            let mode = if testnet {
                BitcoinNetworkType::Testnet
            } else if regtest {
                BitcoinNetworkType::Regtest
            } else {
                BitcoinNetworkType::Mainnet
            };

            let spv_client =
                spv::SpvClient::new(&headers_path, 0, Some(block_height), mode, false, false)
                    .expect("FATAL: could not instantiate SPV client");
            match spv_client
                .read_block_header(block_height)
                .expect("FATAL: could not read block header database")
            {
                Some(header) => {
                    println!("{header:#?}");
                    process::exit(0);
                }
                None => {
                    eprintln!("Failed to read header");
                    process::exit(1);
                }
            }
        }

        Command::DecodeTx { tx_input, file } => {
            let tx_str = if file {
                read_file_or_stdin(&tx_input).trim().to_string()
            } else {
                // Treat as hex string directly
                tx_input.clone()
            };
            let tx_bytes = hex_bytes(&tx_str)
                .map_err(|_e| {
                    eprintln!("Failed to decode transaction: must be a hex string");
                    process::exit(1);
                })
                .unwrap();

            let mut cursor = io::Cursor::new(&tx_bytes);
            let mut debug_cursor = LogReader::from_reader(&mut cursor);

            let tx = StacksTransaction::consensus_deserialize(&mut debug_cursor)
                .map_err(|e| {
                    eprintln!("Failed to decode transaction: {e:?}");
                    eprintln!("Bytes consumed:");
                    for buf in debug_cursor.log().iter() {
                        eprintln!("  {}", to_hex(buf));
                    }
                    process::exit(1);
                })
                .unwrap();

            let verified_strict = tx.verify(TransactionAuthVerificationMode::EnforceLowS);
            if verified_strict.is_ok() {
                println!("Verified: {:#?}", verified_strict);
            } else {
                let verified_lenient = tx.verify(TransactionAuthVerificationMode::AllowHighS);
                println!("Verified: {:#?}", verified_lenient);
                if verified_lenient.is_ok() {
                    println!("WARNING: Transaction signature has high-S");
                }
            }
            let address = tx.auth.origin().get_address(tx.is_mainnet());
            println!("Address: {address}");

            println!("{tx:#?}");
            process::exit(0);
        }

        Command::DecodeBlock { block_path } => {
            let block_data = read_file_or_stdin_bytes(&block_path);

            let block = StacksBlock::consensus_deserialize(&mut io::Cursor::new(&block_data))
                .map_err(|_e| {
                    eprintln!("Failed to decode block");
                    process::exit(1);
                })
                .unwrap();

            println!("{block:#?}");
            process::exit(0);
        }

        Command::DecodeNakamotoBlock { block_input, file } => {
            let block_hex = if file {
                read_file_or_stdin(&block_input).trim().to_string()
            } else {
                // Treat as hex string directly
                block_input.clone()
            };
            let block_data =
                hex_bytes(&block_hex).unwrap_or_else(|_| panic!("Failed to decode hex"));
            let block = NakamotoBlock::consensus_deserialize(&mut io::Cursor::new(&block_data))
                .map_err(|_e| {
                    eprintln!("Failed to decode block");
                    process::exit(1);
                })
                .unwrap();

            println!("{block:#?}");
            process::exit(0);
        }

        Command::DecodeNetMessage { message_data, file } => {
            let buf = if file {
                read_file_or_stdin_bytes(&message_data)
            } else {
                // Parse as JSON array of bytes
                let data: serde_json::Value = serde_json::from_str(message_data.as_str()).unwrap();
                let data_array = data.as_array().unwrap();
                let mut buf = vec![];
                for elem in data_array {
                    buf.push(elem.as_u64().unwrap() as u8);
                }
                buf
            };
            match read_next::<StacksMessage, _>(&mut &buf[..]) {
                Ok(msg) => {
                    println!("{msg:#?}");
                    process::exit(0);
                }
                Err(_) => {
                    let ptr = &mut &buf[..];
                    let mut debug_cursor = LogReader::from_reader(ptr);
                    let _ = read_next::<StacksMessage, _>(&mut debug_cursor);
                    process::exit(1);
                }
            }
        }

        Command::DecodeMicroblocks { microblocks_path } => {
            let mblock_data = read_file_or_stdin_bytes(&microblocks_path);

            let mut cursor = io::Cursor::new(&mblock_data);
            let mut debug_cursor = LogReader::from_reader(&mut cursor);
            let mblocks: Vec<StacksMicroblock> = Vec::consensus_deserialize(&mut debug_cursor)
                .map_err(|e| {
                    eprintln!("Failed to decode microblocks: {e:?}");
                    eprintln!("Bytes consumed:");
                    for buf in debug_cursor.log().iter() {
                        eprintln!("  {}", to_hex(buf));
                    }
                    process::exit(1);
                })
                .unwrap();

            println!("{mblocks:#?}");
            process::exit(0);
        }

        // MARF/Database Commands
        Command::HeaderIndexedGet {
            block_id_hash,
            key,
            state_dir,
            marf_path,
            data_db_path,
        } => {
            // Determine paths based on provided options
            let (marf_path, db_path) = match (state_dir, marf_path, data_db_path) {
                (Some(dir), None, None) => {
                    // State directory mode: auto-derive paths
                    (
                        format!("{dir}/vm/index.sqlite"),
                        format!("{dir}/vm/index.sqlite"),
                    )
                }
                (None, Some(m), Some(d)) => {
                    // Explicit paths mode
                    (m, d)
                }
                (None, None, None) => {
                    eprintln!(
                        "Error: provide either --state-dir OR both --marf-path and --data-db-path"
                    );
                    process::exit(1);
                }
                (Some(_), Some(_), _) | (Some(_), _, Some(_)) => {
                    eprintln!(
                        "Error: --state-dir cannot be combined with --marf-path or --data-db-path"
                    );
                    process::exit(1);
                }
                (None, Some(_), None) | (None, None, Some(_)) => {
                    eprintln!("Error: --marf-path and --data-db-path must be provided together");
                    process::exit(1);
                }
            };

            if fs::metadata(&marf_path).is_err() {
                eprintln!("No such file or directory: {marf_path}");
                process::exit(1);
            }

            if fs::metadata(&db_path).is_err() {
                eprintln!("No such file or directory: {db_path}");
                process::exit(1);
            }

            let marf_bhh = StacksBlockId::from_hex(&block_id_hash).expect("Bad MARF block hash");
            let mut marf_opts = MARFOpenOpts::default();
            marf_opts.external_blobs = true;
            let mut marf = MARF::from_path(&marf_path, marf_opts).expect("Failed to open MARF");
            let value_opt = marf.get(&marf_bhh, &key).expect("Failed to read MARF");

            if let Some(value) = value_opt {
                let conn = sqlite_open(&db_path, OpenFlags::SQLITE_OPEN_READ_ONLY, false)
                    .expect("Failed to open DB");
                let args = params![&value.to_hex()];
                let res: Result<String, SqliteError> = conn.query_row_and_then(
                    "SELECT value FROM __fork_storage WHERE value_hash = ?1",
                    args,
                    |row| {
                        let s: String = row.get_unwrap(0);
                        Ok(s)
                    },
                );

                let row = res
                    .unwrap_or_else(|_| panic!("Failed to query DB for MARF value hash {value}"));
                println!("{row}");
            } else {
                println!("(undefined)");
            }

            process::exit(0);
        }

        Command::MarfGet {
            marf_path,
            tip_hash,
            consensus_hash,
            key,
        } => {
            let tip = BlockHeaderHash::from_hex(&tip_hash).unwrap();
            let consensustip = ConsensusHash::from_hex(&consensus_hash).unwrap();
            let itip = StacksBlockHeader::make_index_block_hash(&consensustip, &tip);

            let mut marf_opts = MARFOpenOpts::default();
            marf_opts.external_blobs = true;
            let mut marf = MARF::from_path(&marf_path, marf_opts).unwrap();
            let res = marf.get(&itip, &key).expect("MARF error.");
            match res {
                Some(x) => println!("{x}"),
                None => println!("None"),
            };
            process::exit(0);
        }

        Command::GetAncestors {
            db_path,
            block_hash,
            consensus_hash,
        } => {
            let tip = BlockHeaderHash::from_hex(&block_hash).unwrap();
            let consensus = ConsensusHash::from_hex(&consensus_hash).unwrap();

            let conn = sqlite_open(&db_path, OpenFlags::SQLITE_OPEN_READ_ONLY, false).unwrap();
            let mut cur_consensus = consensus.clone();
            let mut cur_tip = tip.clone();
            loop {
                println!("{cur_consensus}, {cur_tip}");
                let (next_consensus, next_tip) = match conn.query_row(
                    "SELECT parent_consensus_hash, parent_anchored_block_hash FROM staging_blocks WHERE anchored_block_hash = ? AND consensus_hash = ?",
                    params![cur_tip, cur_consensus],
                    |row| Ok((row.get_unwrap(0), row.get_unwrap(1))),
                ) {
                    Ok(x) => x,
                    Err(e) => {
                        match e {
                            SqliteError::QueryReturnedNoRows => {}
                            e => {
                                eprintln!("SQL Error: {e}");
                            }
                        }
                        break;
                    }
                };
                cur_consensus = next_consensus;
                cur_tip = next_tip;
            }
            process::exit(0);
        }

        Command::DeserializeDb {
            db_path,
            byte_prefix,
        } => {
            let conn = sqlite_open(&db_path, OpenFlags::SQLITE_OPEN_READ_ONLY, false).unwrap();
            let query = format!("SELECT value FROM data_table WHERE key LIKE \"{byte_prefix}%\"");
            let mut stmt = conn.prepare(&query).unwrap();
            let mut rows = stmt.query(NO_PARAMS).unwrap();
            while let Ok(Some(row)) = rows.next() {
                let val_string: String = row.get(0).unwrap();
                let clarity_value =
                    match clarity::vm::Value::try_deserialize_hex_untyped(&val_string) {
                        Ok(x) => x,
                        Err(_e) => continue,
                    };
                println!("{val_string} => {clarity_value}");
            }

            process::exit(0);
        }

        Command::CheckDeserData { check_file } => {
            let file = File::open(&check_file).unwrap();
            for (line_no, line) in io::BufReader::new(file).lines().enumerate() {
                let line_no = line_no + 1;
                let line = line.unwrap().trim().to_string();

                if line_no % 100000 == 0 {
                    println!("{line_no}...");
                }

                if line.is_empty() {
                    continue;
                }

                let vals: Vec<_> = line.split(" => ").map(|x| x.trim()).collect();
                let hex_string = &vals[0];
                let expected_value_display = &vals[1];
                let value = clarity::vm::Value::try_deserialize_hex_untyped(hex_string).unwrap();
                assert_eq!(&value.to_string(), expected_value_display);
            }

            process::exit(0);
        }

        // Nakamoto Commands
        Command::GetNakamotoTip {
            chainstate_dir,
            network,
        } => {
            check_nakamoto_network(&network);
            let (sort_db, chain_state) = open_nakamoto_chainstate_dbs(&chainstate_dir, &network);

            let header = NakamotoChainState::get_canonical_block_header(chain_state.db(), &sort_db)
                .unwrap()
                .unwrap();
            println!("{}", header.index_block_hash());
            process::exit(0);
        }

        Command::GetAccount {
            chainstate_dir,
            network,
            address,
            chain_tip,
        } => {
            let addr = StacksAddress::from_string(&address).unwrap();
            let chain_tip_id: Option<StacksBlockId> =
                chain_tip.map(|tip| StacksBlockId::from_hex(&tip).unwrap());

            check_nakamoto_network(&network);
            let (sort_db, mut chain_state) =
                open_nakamoto_chainstate_dbs(&chainstate_dir, &network);

            let chain_tip_header = chain_tip_id
                .map(|tip| {
                    NakamotoChainState::get_block_header_nakamoto(chain_state.db(), &tip)
                        .unwrap()
                        .unwrap()
                })
                .unwrap_or_else(|| {
                    NakamotoChainState::get_canonical_block_header(chain_state.db(), &sort_db)
                        .unwrap()
                        .unwrap()
                });

            let account =
                get_nakamoto_account(&mut chain_state, &sort_db, &addr, &chain_tip_header)
                    .expect("Failed to load the account at the chain tip");
            println!("{account:#?}");
            process::exit(0);
        }

        Command::GetNakamotoInv {
            peer_addr,
            data_port,
            consensus_hash,
        } => {
            let peer_socket: SocketAddr = peer_addr.to_socket_addrs().unwrap().next().unwrap();
            let ch = ConsensusHash::from_hex(&consensus_hash).unwrap();

            let mut session = P2PSession::begin(peer_socket, data_port).unwrap();

            let get_nakamoto_inv =
                StacksMessageType::GetNakamotoInv(GetNakamotoInvData { consensus_hash: ch });

            let msg = session.make_peer_message(get_nakamoto_inv).unwrap();
            session.send_peer_message(msg).unwrap();
            let resp = session.recv_peer_message().unwrap();

            let StacksMessageType::NakamotoInv(inv) = &resp.payload else {
                panic!("Got spurious message: {resp:?}");
            };

            println!("{inv:?}");
            process::exit(0);
        }

        // Chain State Commands
        Command::GetTenure {
            chain_state_dir,
            block_hash,
        } => {
            let index_block_hash = StacksBlockId::from_hex(&block_hash).unwrap();
            let chain_state_path = format!("{}/mainnet/chainstate/", chain_state_dir);

            let (chainstate, _) =
                StacksChainState::open(true, CHAIN_ID_MAINNET, &chain_state_path, None).unwrap();

            let (consensus_hash, block_hash) = chainstate
                .get_block_header_hashes(&index_block_hash)
                .unwrap()
                .expect("FATAL: no such block");
            let mut block_info =
                StacksChainState::load_staging_block_info(chainstate.db(), &index_block_hash)
                    .unwrap()
                    .expect("No such block");
            block_info.block_data = StacksChainState::load_block_bytes(
                &chainstate.blocks_path,
                &consensus_hash,
                &block_hash,
            )
            .unwrap()
            .expect("No such block");

            let block =
                StacksBlock::consensus_deserialize(&mut io::Cursor::new(&block_info.block_data))
                    .map_err(|_e| {
                        eprintln!("Failed to decode block");
                        process::exit(1);
                    })
                    .unwrap();

            let microblocks =
                StacksChainState::find_parent_microblock_stream(chainstate.db(), &block_info)
                    .unwrap()
                    .unwrap_or_default();

            let mut mblock_report = vec![];
            for mblock in microblocks.iter() {
                let mut tx_report = vec![];
                for tx in mblock.txs.iter() {
                    tx_report.push(json!({
                        "txid": format!("{}", tx.txid()),
                        "fee": format!("{}", tx.get_tx_fee()),
                        "tx": to_hex(&tx.serialize_to_vec()).to_string(),
                    }));
                }
                mblock_report.push(json!({
                    "microblock": format!("{}", mblock.block_hash()),
                    "txs": tx_report
                }));
            }

            let mut block_tx_report = vec![];
            for tx in block.txs.iter() {
                block_tx_report.push(json!({
                    "txid": format!("{}", tx.txid()),
                    "fee": format!("{}", tx.get_tx_fee()),
                    "tx": to_hex(&tx.serialize_to_vec()).to_string()
                }));
            }

            let report = json!({
                "block": {
                    "block_id": format!("{}", index_block_hash),
                    "block_hash": format!("{}", block.block_hash()),
                    "height": format!("{}", block.header.total_work.work),
                    "txs": block_tx_report
                },
                "microblocks": mblock_report
            });

            println!("{report}");
            process::exit(0);
        }

        Command::GetBlockInventory { working_dir } => {
            let sort_db_path = format!("{}/mainnet/burnchain/sortition", working_dir);
            let chain_state_path = format!("{}/mainnet/chainstate/", working_dir);

            let sort_db =
                SortitionDB::open(&sort_db_path, false, PoxConstants::mainnet_default(), None)
                    .unwrap_or_else(|_| panic!("Failed to open {sort_db_path}"));
            let chain_id = CHAIN_ID_MAINNET;
            let (chain_state, _) = StacksChainState::open(true, chain_id, &chain_state_path, None)
                .expect("Failed to open stacks chain state");
            let chain_tip = SortitionDB::get_canonical_burn_chain_tip(sort_db.conn())
                .expect("Failed to get sortition chain tip");

            let start = Instant::now();

            let header_hashes = {
                let ic = sort_db.index_conn();
                ic.get_stacks_header_hashes(2100, &chain_tip.consensus_hash, &HashMap::new())
                    .unwrap()
            };

            println!("Fetched header hashes in {}", start.elapsed().as_secs_f32());
            let start = Instant::now();

            let block_inv = chain_state.get_blocks_inventory(&header_hashes).unwrap();
            println!("Fetched block inv in {}", start.elapsed().as_secs_f32());
            println!("{block_inv:?}");

            println!("Done!");
            process::exit(0);
        }

        Command::CanDownloadMicroblock { working_dir } => {
            let sort_db_path = format!("{}/mainnet/burnchain/sortition", working_dir);
            let chain_state_path = format!("{}/mainnet/chainstate/", working_dir);

            let sort_db =
                SortitionDB::open(&sort_db_path, false, PoxConstants::mainnet_default(), None)
                    .unwrap_or_else(|_| panic!("Failed to open {sort_db_path}"));
            let chain_id = CHAIN_ID_MAINNET;
            let (chain_state, _) = StacksChainState::open(true, chain_id, &chain_state_path, None)
                .expect("Failed to open stacks chain state");
            let chain_tip = SortitionDB::get_canonical_burn_chain_tip(sort_db.conn())
                .expect("Failed to get sortition chain tip");

            let start = Instant::now();
            let local_peer = LocalPeer::new(
                0,
                0,
                PeerAddress::from_ipv4(127, 0, 0, 1),
                0,
                None,
                0,
                UrlString::from_literal("abc"),
                vec![],
            );

            let header_hashes = {
                let ic = sort_db.index_conn();
                ic.get_stacks_header_hashes(2100, &chain_tip.consensus_hash, &HashMap::new())
                    .unwrap()
            };

            println!("Fetched header hashes in {}", start.elapsed().as_secs_f32());

            let start = Instant::now();
            let mut total_load_headers = 0;

            for (consensus_hash, block_hash_opt) in header_hashes.iter() {
                let block_hash = match block_hash_opt {
                    Some(b) => b,
                    None => continue,
                };

                let index_block_hash =
                    StacksBlockHeader::make_index_block_hash(consensus_hash, block_hash);
                let start_load_header = get_epoch_time_ms();
                let parent_header_opt = {
                    let child_block_info = match StacksChainState::load_staging_block_info(
                        chain_state.db(),
                        &index_block_hash,
                    ) {
                        Ok(Some(hdr)) => hdr,
                        _ => {
                            debug!("No such block: {index_block_hash:?}");
                            continue;
                        }
                    };

                    match StacksChainState::load_block_header(
                        &chain_state.blocks_path,
                        &child_block_info.parent_consensus_hash,
                        &child_block_info.parent_anchored_block_hash,
                    ) {
                        Ok(header_opt) => {
                            header_opt.map(|hdr| (hdr, child_block_info.parent_consensus_hash))
                        }
                        Err(_) => {
                            debug!(
                                "{local_peer:?}: Do not have parent of anchored block {consensus_hash}/{block_hash} yet, so cannot ask for the microblocks it produced"
                            );
                            continue;
                        }
                    }
                };

                let end_load_header = get_epoch_time_ms();
                total_load_headers += end_load_header.saturating_sub(start_load_header);

                if let Some((parent_header, parent_consensus_hash)) = parent_header_opt {
                    PeerNetwork::can_download_microblock_stream(
                        &local_peer,
                        &chain_state,
                        &parent_consensus_hash,
                        &parent_header.block_hash(),
                        consensus_hash,
                        block_hash,
                    )
                    .unwrap();
                } else {
                    continue;
                }
            }

            println!(
                "Checked can_download in {} (headers load took {total_load_headers}ms)",
                start.elapsed().as_secs_f32(),
            );

            println!("Done!");
            process::exit(0);
        }

        // Mining Commands
        Command::TryMine(args) => {
            command_try_mine(&args, common_opts.config.as_ref());
            process::exit(0);
        }

        Command::TipMine {
            working_dir,
            event_log,
            mine_tip_height,
            max_txns,
        } => {
            tip_mine(&working_dir, &event_log, mine_tip_height, max_txns);
        }

        Command::ReplayMockMining(args) => {
            command_replay_mock_mining(&args, common_opts.config.as_ref());
            process::exit(0);
        }

        // Validation Commands
        Command::ValidateBlock(args) => {
            command_validate_block(&args, common_opts.config.as_ref());
            process::exit(0);
        }

        // Utility Commands
        Command::PeerPubKey { local_peer_seed } => {
            let local_seed =
                hex_bytes(&local_peer_seed).expect("Failed to parse hex input local-peer-seed");
            let node_privkey = Secp256k1PrivateKey::from_seed(&local_seed);
            let pubkey = Secp256k1PublicKey::from_private(&node_privkey).to_hex();
            println!("{pubkey}");
            process::exit(0);
        }

        Command::Docgen => {
            println!(
                "{}",
                stackslib::clarity::vm::docs::make_json_api_reference()
            );
            process::exit(0);
        }

        Command::DocgenBoot => {
            println!(
                "{}",
                stackslib::chainstate::stacks::boot::docs::make_json_boot_contracts_reference()
            );
            process::exit(0);
        }

        Command::DumpConsts => {
            dump_consts();
        }

        Command::ContractHash(args) => {
            command_contract_hash(&args, common_opts.config.as_ref());
            process::exit(0);
        }

        Command::PostStackerDb {
            slot_id,
            slot_version,
            private_key,
            data,
        } => {
            let data_bytes = if data == "-" || std::path::Path::new(&data).exists() {
                read_file_or_stdin_bytes(&data)
            } else {
                // Use the argument directly as data
                data.as_bytes().to_vec()
            };

            let privkey =
                StacksPrivateKey::from_hex(&private_key).expect("Failed to parse private key");
            let mut chunk = StackerDBChunkData::new(slot_id, slot_version, data_bytes);
            chunk.sign(&privkey).unwrap();
            println!("{}", serde_json::to_string(&chunk).unwrap());
            process::exit(0);
        }

        Command::ExecProgram { program_file } => {
            let program: String = fs::read_to_string(&program_file)
                .unwrap_or_else(|_| panic!("Error reading file: {}", program_file));
            let clarity_version = ClarityVersion::default_for_epoch(DEFAULT_CLI_EPOCH);
            match vm_execute(&program, clarity_version) {
                Ok(Some(result)) => println!("{result}"),
                Ok(None) => println!(),
                Err(error) => {
                    panic!("Program Execution Error: \n{error}");
                }
            }
            process::exit(0);
        }

        // PoX/Sortition Commands
        Command::EvaluatePoxAnchor {
            sortition_db_path,
            start_height,
            end_height,
        } => {
            let end_height = end_height.unwrap_or(start_height);

            let sort_db = SortitionDB::open(
                &sortition_db_path,
                false,
                PoxConstants::mainnet_default(),
                None,
            )
            .unwrap_or_else(|_| panic!("Failed to open {}", sortition_db_path));
            let chain_tip = SortitionDB::get_canonical_sortition_tip(sort_db.conn())
                .expect("Failed to get sortition chain tip");
            let sort_conn = sort_db.index_handle(&chain_tip);

            let mut results = vec![];

            for eval_height in start_height..(1 + end_height) {
                if (sort_conn.context.first_block_height + 100) >= eval_height {
                    eprintln!("Block height too low to evaluate");
                    process::exit(1);
                }

                let eval_tip =
                    SortitionDB::get_ancestor_snapshot(&sort_conn, eval_height, &chain_tip)
                        .expect("Failed to get chain tip to evaluate at")
                        .expect("Failed to get chain tip to evaluate at");

                let pox_consts = PoxConstants::mainnet_default();

                let result = sort_conn
                    .get_chosen_pox_anchor_check_position(
                        &eval_tip.burn_header_hash,
                        &pox_consts,
                        false,
                    )
                    .expect("Failed to compute PoX cycle");

                match result {
                    PoxAnchorSelection::Selected { confirmations, .. } => {
                        results.push((eval_height, true, confirmations))
                    }
                    PoxAnchorSelection::NotSelected { max_confirmations } => {
                        results.push((eval_height, false, max_confirmations))
                    }
                };
            }

            println!("Block height, Would select anchor, Anchor agreement");
            for r in results.iter() {
                println!("{}, {}, {}", r.0, r.1, r.2);
            }

            process::exit(0);
        }

        Command::AnalyzeSortitionMev {
            burnchain_db_path,
            sortition_db_path,
            chainstate_path,
            start_height,
            end_height,
            advantages,
        } => {
            analyze_sortition_mev(
                &burnchain_db_path,
                &sortition_db_path,
                &chainstate_path,
                start_height,
                end_height,
                &advantages,
            );
        }
    }
}

#[cfg_attr(test, mutants::skip)]
pub fn dump_consts() {
    use stacks_common::consts;
    let json_out = json!({
        "miner_reward_maturity": consts::MINER_REWARD_MATURITY,
        "chain_id_mainnet": consts::CHAIN_ID_MAINNET,
        "chain_id_signet": consts::CHAIN_ID_SIGNET,
        "chain_id_testnet": consts::CHAIN_ID_TESTNET,
        "signer_slots_per_user": consts::SIGNER_SLOTS_PER_USER,
        "network_id_mainnet": consts::NETWORK_ID_MAINNET,
        "network_id_testnet": consts::NETWORK_ID_TESTNET,
        "microstacks_per_stacks": consts::MICROSTACKS_PER_STACKS,
        "stacks_epoch_max": consts::STACKS_EPOCH_MAX,
        "peer_version_mainnet_major": consts::PEER_VERSION_MAINNET_MAJOR,
        "peer_version_testnet_major": consts::PEER_VERSION_TESTNET_MAJOR,
    });
    println!("{}", serde_json::to_string_pretty(&json_out).unwrap());
    process::exit(0);
}

#[cfg_attr(test, mutants::skip)]
pub fn tip_mine(working_dir: &str, event_log: &str, mine_tip_height: u64, max_txns: u64) {
    let burnchain_path = format!("{}/mainnet/burnchain", working_dir);
    let sort_db_path = format!("{}/mainnet/burnchain/sortition", working_dir);
    let chain_state_path = format!("{}/mainnet/chainstate/", working_dir);

    let events_file = event_log;
    let mine_max_txns = max_txns;

    let sort_db = SortitionDB::open(&sort_db_path, false, PoxConstants::mainnet_default(), None)
        .unwrap_or_else(|_| panic!("Failed to open {sort_db_path}"));
    let chain_id = CHAIN_ID_MAINNET;
    let mut chain_state = StacksChainState::open(true, chain_id, &chain_state_path, None)
        .expect("Failed to open stacks chain state")
        .0;
    let chain_tip = SortitionDB::get_canonical_burn_chain_tip(sort_db.conn())
        .expect("Failed to get sortition chain tip");

    let estimator = Box::new(UnitEstimator);
    let metric = Box::new(UnitMetric);

    let mut mempool_db = MemPoolDB::open(true, chain_id, &chain_state_path, estimator, metric)
        .expect("Failed to open mempool db");

    info!("Clearing mempool");
    let min_height = u32::MAX as u64;
    mempool_db
        .garbage_collect(min_height, &MempoolCollectionBehavior::ByStacksHeight, None)
        .unwrap();

    let header_tip = NakamotoChainState::get_canonical_block_header(chain_state.db(), &sort_db)
        .unwrap()
        .unwrap();

    // Find ancestor block
    let mut stacks_header = header_tip.to_owned();
    loop {
        let parent_block_id = match stacks_header.anchored_header {
            StacksBlockHeaderTypes::Nakamoto(ref nakamoto_header) => {
                nakamoto_header.parent_block_id.clone()
            }
            StacksBlockHeaderTypes::Epoch2(ref epoch2_header) => {
                let block_info = StacksChainState::load_staging_block(
                    chain_state.db(),
                    &chain_state.blocks_path,
                    &stacks_header.consensus_hash,
                    &epoch2_header.block_hash(),
                )
                .unwrap()
                .unwrap();
                StacksBlockId::new(
                    &block_info.parent_consensus_hash,
                    &epoch2_header.parent_block,
                )
            }
        };

        let stacks_parent_header =
            NakamotoChainState::get_block_header(chain_state.db(), &parent_block_id)
                .unwrap()
                .unwrap();
        if stacks_parent_header.anchored_header.height() < mine_tip_height {
            break;
        }
        stacks_header = stacks_parent_header;
    }
    info!(
        "Found stacks_chain_tip with height {}",
        header_tip.anchored_header.height()
    );
    info!(
        "Mining off parent block with height {}",
        header_tip.anchored_header.height()
    );

    info!("Submitting up to {mine_max_txns} transactions to the mempool");
    let mut found_block_height = false;
    let mut parsed_tx_count = 0;
    let mut submit_tx_count = 0;
    let events_file = File::open(events_file).expect("Unable to open file");
    let events_reader = BufReader::new(events_file);
    'outer: for line in events_reader.lines() {
        let line_json: Value = serde_json::from_str(&line.unwrap()).unwrap();
        let path = line_json["path"].as_str().unwrap();
        let payload = &line_json["payload"];
        match path {
            "new_block" => {
                let payload = payload.as_object().unwrap();
                let block_height = payload["block_height"].as_u64().unwrap();
                if !found_block_height && block_height >= mine_tip_height {
                    found_block_height = true;
                    info!("Found target block height {block_height}");
                }
                info!(
                    "Found new_block height {block_height} parsed_tx_count {parsed_tx_count} submit_tx_count {submit_tx_count}"
                );
            }
            "new_mempool_tx" => {
                let payload = payload.as_array().unwrap();
                for item in payload {
                    let raw_tx_hex = item.as_str().unwrap();
                    let raw_tx_bytes = hex_bytes(&raw_tx_hex[2..]).unwrap();
                    let mut cursor = io::Cursor::new(&raw_tx_bytes);
                    let raw_tx = StacksTransaction::consensus_deserialize(&mut cursor).unwrap();
                    if found_block_height {
                        if submit_tx_count >= mine_max_txns {
                            info!("Reached mine_max_txns {submit_tx_count}");
                            break 'outer;
                        }
                        let result = mempool_db.submit(
                            &mut chain_state,
                            &sort_db,
                            &stacks_header.consensus_hash,
                            &stacks_header.anchored_header.block_hash(),
                            &raw_tx,
                            None,
                            &ExecutionCost::max_value(),
                            &StacksEpochId::Epoch20,
                        );
                        parsed_tx_count += 1;
                        if result.is_ok() {
                            submit_tx_count += 1;
                        }
                    }
                }
            }
            _ => {}
        };
    }
    info!("Parsed {parsed_tx_count} transactions");
    info!("Submitted {submit_tx_count} transactions into the mempool");

    info!("Mining a block");

    let start = get_epoch_time_ms();

    let parent_header = NakamotoChainState::get_block_header(
        chain_state.db(),
        &StacksBlockId::new(
            &stacks_header.consensus_hash,
            &stacks_header.anchored_header.block_hash(),
        ),
    )
    .expect("Failed to load chain tip header info")
    .expect("Failed to load chain tip header info");

    let sk = StacksPrivateKey::random();
    let mut tx_auth = TransactionAuth::from_p2pkh(&sk).unwrap();
    tx_auth.set_origin_nonce(0);

    let mut coinbase_tx = StacksTransaction::new(
        TransactionVersion::Mainnet,
        tx_auth,
        TransactionPayload::Coinbase(CoinbasePayload([0u8; 32]), None, None),
    );

    coinbase_tx.chain_id = chain_id;
    coinbase_tx.anchor_mode = TransactionAnchorMode::OnChainOnly;
    let mut tx_signer = StacksTransactionSigner::new(&coinbase_tx);
    tx_signer.sign_origin(&sk).unwrap();
    let coinbase_tx = tx_signer.get_tx().unwrap();

    let settings = BlockBuilderSettings::max_value();

    let result = StacksBlockBuilder::build_anchored_block(
        &chain_state,
        &sort_db.index_handle_at_tip(),
        &mut mempool_db,
        &parent_header,
        chain_tip.total_burn,
        &VRFProof::empty(),
        &Hash160([0; 20]),
        &coinbase_tx,
        settings,
        None,
        &Burnchain::new(&burnchain_path, "bitcoin", "main", None).unwrap(),
    );

    let stop = get_epoch_time_ms();

    println!(
        "{} mined block @ height = {} off of {} ({}/{}) in {}ms.",
        if result.is_ok() {
            "Successfully"
        } else {
            "Failed to"
        },
        parent_header.stacks_block_height + 1,
        StacksBlockHeader::make_index_block_hash(
            &parent_header.consensus_hash,
            &parent_header.anchored_header.block_hash()
        ),
        parent_header.consensus_hash,
        parent_header.anchored_header.block_hash(),
        stop.saturating_sub(start),
    );

    if let Ok((block, execution_cost, size)) = result {
        let mut total_fees = 0;
        for tx in block.txs.iter() {
            total_fees += tx.get_tx_fee();
        }
        println!(
            "Block {}: {total_fees} uSTX, {size} bytes, cost {execution_cost:?}",
            block.block_hash(),
        );
    }

    process::exit(0);
}

/// Perform an analysis of the anti-MEV algorithm in epoch 3.0, vis-a-vis the status quo.
/// Results are printed to stdout.
/// Exits with 0 on success, and 1 on failure.
fn analyze_sortition_mev(
    burnchaindb_path: &str,
    sortdb_path: &str,
    chainstate_path: &str,
    start_height: u64,
    end_height: u64,
    advantage_pairs: &[String],
) {
    // Parse advantages from pairs: MINER BURN MINER BURN ...
    let mut advantages = HashMap::new();
    let mut i = 0;
    while i + 1 < advantage_pairs.len() {
        let miner = advantage_pairs[i].clone();
        let burn: u64 = advantage_pairs[i + 1]
            .parse()
            .expect("advantage burn must be a valid u64");
        advantages.insert(miner, burn);
        i += 2;
    }

    let mut sortdb =
        SortitionDB::open(sortdb_path, true, PoxConstants::mainnet_default(), None).unwrap();
    sortdb.dryrun = true;
    let burnchain = Burnchain::new(burnchaindb_path, "bitcoin", "mainnet", None).unwrap();
    let burnchaindb = BurnchainDB::connect(burnchaindb_path, &burnchain, true).unwrap();
    let (mut chainstate, _) =
        StacksChainState::open(true, 0x00000001, chainstate_path, None).unwrap();

    let mut wins_epoch2 = BTreeMap::new();
    let mut wins_epoch3 = BTreeMap::new();

    for height in start_height..end_height {
        debug!("Get ancestor snapshots for {height}");
        let (tip_sort_id, parent_ancestor_sn, ancestor_sn) = {
            let mut sort_tx = sortdb.tx_begin_at_tip();
            let tip_sort_id = sort_tx.tip();
            let ancestor_sn = sort_tx
                .get_block_snapshot_by_height(height)
                .unwrap()
                .unwrap();
            let parent_ancestor_sn = sort_tx
                .get_block_snapshot_by_height(height - 1)
                .unwrap()
                .unwrap();
            (tip_sort_id, parent_ancestor_sn, ancestor_sn)
        };

        let mut burn_block =
            BurnchainDB::get_burnchain_block(burnchaindb.conn(), &ancestor_sn.burn_header_hash)
                .unwrap();

        debug!(
            "Get reward cycle info at {}",
            burn_block.header.block_height
        );
        let rc_info_opt = get_reward_cycle_info(
            burn_block.header.block_height,
            &burn_block.header.parent_block_hash,
            &tip_sort_id,
            &burnchain,
            &mut chainstate,
            &mut sortdb,
            &OnChainRewardSetProvider::new(),
        )
        .unwrap();

        let mut ops = burn_block.ops.clone();
        for op in ops.iter_mut() {
            if let BlockstackOperationType::LeaderBlockCommit(op) = op
                && let Some(extra_burn) = advantages.get(&op.apparent_sender.to_string())
            {
                debug!(
                    "Miner {} gets {extra_burn} extra burn fee",
                    &op.apparent_sender.to_string()
                );
                op.burn_fee += *extra_burn;
            }
        }
        burn_block.ops = ops;

        debug!("Re-evaluate sortition at height {height}");
        let (next_sn, state_transition) = sortdb
            .evaluate_sortition(
                true,
                &burn_block.header,
                burn_block.ops.clone(),
                &burnchain,
                &tip_sort_id,
                rc_info_opt,
                |_, _| (),
            )
            .unwrap();

        assert_eq!(next_sn.block_height, ancestor_sn.block_height);
        assert_eq!(next_sn.burn_header_hash, ancestor_sn.burn_header_hash);

        let mut sort_tx = sortdb.tx_begin_at_tip();
        let tip_pox_id = sort_tx.get_pox_id().unwrap();
        let next_sn_nakamoto = BlockSnapshot::make_snapshot_in_epoch(
            true,
            &mut sort_tx,
            &burnchain,
            &ancestor_sn.sortition_id,
            &tip_pox_id,
            &parent_ancestor_sn,
            &burn_block.header,
            &state_transition,
            0,
            StacksEpochId::Epoch30,
        )
        .unwrap();

        assert_eq!(next_sn.block_height, next_sn_nakamoto.block_height);
        assert_eq!(next_sn.burn_header_hash, next_sn_nakamoto.burn_header_hash);

        let winner_epoch2 = get_block_commit_by_txid(
            &sort_tx,
            &ancestor_sn.sortition_id,
            &next_sn.winning_block_txid,
        )
        .unwrap()
        .map(|cmt| format!("{:?}", cmt.apparent_sender.to_string()))
        .unwrap_or("(null)".to_string());

        let winner_epoch3 = get_block_commit_by_txid(
            &sort_tx,
            &ancestor_sn.sortition_id,
            &next_sn_nakamoto.winning_block_txid,
        )
        .unwrap()
        .map(|cmt| format!("{:?}", cmt.apparent_sender.to_string()))
        .unwrap_or("(null)".to_string());

        wins_epoch2.insert(
            (next_sn.block_height, next_sn.burn_header_hash),
            winner_epoch2,
        );
        wins_epoch3.insert(
            (
                next_sn_nakamoto.block_height,
                next_sn_nakamoto.burn_header_hash,
            ),
            winner_epoch3,
        );
    }

    let mut all_wins_epoch2 = BTreeMap::new();
    let mut all_wins_epoch3 = BTreeMap::new();

    println!("Wins epoch 2");
    println!("------------");
    println!("height,burn_header_hash,winner");
    for ((height, bhh), winner) in wins_epoch2.iter() {
        println!("{height},{bhh},{winner}");
        if let Some(cnt) = all_wins_epoch2.get_mut(winner) {
            *cnt += 1;
        } else {
            all_wins_epoch2.insert(winner, 1);
        }
    }

    println!("------------");
    println!("Wins epoch 3");
    println!("------------");
    println!("height,burn_header_hash,winner");
    for ((height, bhh), winner) in wins_epoch3.iter() {
        println!("{height},{bhh},{winner}");
        if let Some(cnt) = all_wins_epoch3.get_mut(winner) {
            *cnt += 1;
        } else {
            all_wins_epoch3.insert(winner, 1);
        }
    }

    println!("---------------");
    println!("Differences");
    println!("---------------");
    println!("height,burn_header_hash,winner_epoch2,winner_epoch3");
    for ((height, bhh), winner) in wins_epoch2.iter() {
        let Some(epoch3_winner) = wins_epoch3.get(&(*height, bhh.clone())) else {
            continue;
        };
        if epoch3_winner != winner {
            println!("{height},{bhh},{winner},{epoch3_winner}");
        }
    }

    println!("---------------");
    println!("All epoch2 wins");
    println!("---------------");
    println!("miner,count");
    for (winner, count) in all_wins_epoch2.iter() {
        println!("{winner},{count}");
    }

    println!("---------------");
    println!("All epoch3 wins");
    println!("---------------");
    println!("miner,count,degradation");
    for (winner, count) in all_wins_epoch3.into_iter() {
        let degradation = (count as f64)
            / (all_wins_epoch2
                .get(winner)
                .map(|cnt| *cnt as f64)
                .unwrap_or(0.00000000000001f64));
        println!("{winner},{count},{degradation}");
    }

    process::exit(0);
}
