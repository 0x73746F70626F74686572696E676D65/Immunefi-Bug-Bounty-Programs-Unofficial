{
  description = "stacks-core";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixpkgs-unstable";
    systems.url = "github:nix-systems/default";

    flake-utils = {
      url = "github:numtide/flake-utils";
      inputs.systems.follows = "systems";
    };

    rust-overlay = {
      url = "github:oxalica/rust-overlay";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    crane = {
      url = "github:ipetkov/crane";
    };

  };

  outputs =
    {
      nixpkgs,
      flake-utils,
      rust-overlay,
      crane,
      ...
    }:
    flake-utils.lib.eachSystem (
      builtins.filter (system: system != "x86_64-darwin") flake-utils.lib.defaultSystems
    ) (
      system:
      let
        overlays = [ (import rust-overlay) ];
        pkgs = import nixpkgs { inherit system overlays; };

        inherit (pkgs) lib;

        toolchain = pkgs.rust-bin.fromRustupToolchainFile ../../rust-toolchain.toml;
        craneLib = ((crane.mkLib pkgs).overrideToolchain toolchain).overrideScope (
          final: prev: {
            downloadCargoPackageFromGit =
              args:
              let
                drv = prev.downloadCargoPackageFromGit args;
                # The pinned stacks-core git dep at this rev has readme = "README.md"
                # in stackslib/Cargo.toml but the file doesn't exist. Rust 1.94+
                # errors on `cargo package -l` for missing readmes.
                # TODO: remove this override when the pinned dep moves to a revision which no longer
                # has invalid 'readme' keys.
                needsPatch =
                  args.git == "https://github.com/stacks-network/stacks-core.git"
                  && args.rev == "ecaaf5c4d397a691e5155eef01b59ddfeaba4ddd";
              in
              if needsPatch then
                drv.overrideAttrs (old: {
                  preInstall = (old.preInstall or "") + ''
                    find . -name Cargo.toml | while read -r toml; do
                      readme=$(sed -n 's/^readme *= *"\(.*\)"/\1/p' "$toml")
                      if [ -n "$readme" ] && [ ! -f "$(dirname "$toml")/$readme" ]; then
                        touch "$(dirname "$toml")/$readme"
                      fi
                    done
                  '';
                })
              else
                drv;
          }
        );

        name = "stacks-core";

        cargoWorkspace = (builtins.fromTOML (builtins.readFile ../../Cargo.toml)).workspace;
        # Keep the source fileset in sync with Cargo's workspace declarations.
        workspaceCrates = map (crate: ../.. + "/${crate}") cargoWorkspace.members;

        version = cargoWorkspace.package.version;

        # Common arguments can be set here to avoid repeating them later
        commonArgs = {
          strictDeps = true;

          buildInputs = lib.optionals pkgs.stdenv.isDarwin [
            # Darwin specific inputs
          ];
        };

        # Build *just* the cargo dependencies, so we can reuse
        # all of that work (e.g. via cachix) when running in CI
        cargoArtifacts = craneLib.buildDepsOnly (
          commonArgs
          // {
            inherit version;
            pname = name;
            src = fileSetForCrate ../..;
          }
        );

        individualCrateArgs = commonArgs // {
          inherit cargoArtifacts;

          # NB: we disable tests since we'll run them all via cargo-nextest
          doCheck = false;
        };

        # TODO: Return minimum fileSets per each crate
        fileSetForCrate =
          crate:
          lib.fileset.toSource {
            root = ../..;
            fileset = lib.fileset.unions (
              [
                ../../Cargo.toml
                ../../Cargo.lock
                #
                ../../stx-genesis/name_zonefiles.txt
                ../../stx-genesis/name_zonefiles.txt.sha256
                ../../stx-genesis/name_zonefiles-test.txt
                ../../stx-genesis/name_zonefiles-test.txt.sha256
                ../../stx-genesis/chainstate.txt
                ../../stx-genesis/chainstate.txt.sha256
                ../../stx-genesis/chainstate-test.txt
                ../../stx-genesis/chainstate-test.txt.sha256
                #
                (craneLib.fileset.commonCargoSources crate)
                #
                (lib.fileset.fileFilter (file: file.hasExt "clar") ../..)
                # clarity-types includes this file in its crate-level documentation.
                ../../clarity-types/README.md
              ]
              ++ map craneLib.fileset.commonCargoSources workspaceCrates
            );
          };

        stacks-signer = craneLib.buildPackage (
          individualCrateArgs
          // rec {
            inherit version;
            pname = "stacks-signer";
            cargoFeatures = "--features monitoring_prom";
            cargoExtraArgs = "${cargoFeatures} -p ${pname}";
            src = fileSetForCrate ../../stacks-signer;
          }
        );

        # Build the actual crate itself, reusing the dependency
        # artifacts from above.
        stacks-core = craneLib.buildPackage (
          commonArgs
          // rec {
            inherit version cargoArtifacts;
            doCheck = false;
            pname = name;
            cargoFeatures = "--features monitoring_prom,slog_json";
            cargoExtraArgs = "${cargoFeatures}";
            src = fileSetForCrate ../..;
          }
        );

        stacks-inspect = craneLib.buildPackage (
          individualCrateArgs
          // rec {
            inherit version;
            pname = "stacks-inspect";
            cargoExtraArgs = "-p ${pname}";
            src = fileSetForCrate ../../contrib/stacks-inspect;
          }
        );

        stacks-cli = craneLib.buildPackage (
          individualCrateArgs
          // rec {
            inherit version;
            pname = "stacks-cli";
            cargoExtraArgs = "-p ${pname}";
            src = fileSetForCrate ../../contrib/stacks-cli;
          }
        );

        clarity-cli = craneLib.buildPackage (
          individualCrateArgs
          // rec {
            inherit version;
            pname = "clarity-cli";
            cargoExtraArgs = "-p ${pname}";
            src = fileSetForCrate ../../contrib/clarity-cli;
          }
        );

        marf-squash = craneLib.buildPackage (
          individualCrateArgs
          // rec {
            inherit version;
            pname = "marf-squash";
            cargoExtraArgs = "-p ${pname}";
            src = fileSetForCrate ../../contrib/marf-squash;
          }
        );

        stacks-node-app = {
          type = "app";
          program = "${stacks-core}/bin/stacks-node";
          meta = with lib; {
            license = licenses.gpl3;
            platforms = platforms.all;
            description = "The Stacks blockchain implementation.";
            homepage = "https://stacks.co";
          };
        };

        stacks-signer-app = {
          type = "app";
          program = "${stacks-signer}/bin/stacks-signer";
          meta = with lib; {
            license = licenses.gpl3;
            platforms = platforms.all;
            description = "Signer for the Stacks blockchain implementation.";
            homepage = "https://stacks.co";
          };
        };
      in
      with pkgs;
      {
        packages = {
          inherit
            stacks-signer
            stacks-core
            stacks-cli
            clarity-cli
            stacks-inspect
            marf-squash
            ;
          default = stacks-core;
        };

        apps = {
          stacks-node = stacks-node-app;
          default = stacks-node-app;
          stacks-signer = stacks-signer-app;
        };

        checks = {
          workspaceCheck = craneLib.buildPackage (
            commonArgs
            // rec {
              inherit version cargoArtifacts;
              cargoBuildCommand = "cargo check --workspace";
              doCheck = false;
              pname = name;
              cargoFeatures = "--features monitoring_prom,slog_json";
              cargoExtraArgs = "${cargoFeatures}";
              src = fileSetForCrate ../..;
            }
          );
        };

        devShells.default = craneLib.devShell {
          RUSTFMT = "${toolchain}/bin/rustfmt";
          GREETING = "Welcome, stacks-core developer!";
          shellHook = ''
            echo $GREETING

            echo "Setting a few options that will help you when running tests:"
            set -x
            ulimit -n 10240
            set +x
          '';

          packages = [
            rust-analyzer
            bitcoind
            cargo-nextest
          ]
          ++ lib.optionals pkgs.stdenv.isDarwin [ ];
        };
      }
    );
}
