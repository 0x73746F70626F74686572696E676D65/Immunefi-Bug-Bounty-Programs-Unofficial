import { beforeEach, expect, test } from 'vitest';
import {
  signerManager,
  signerManagerErrors,
  pox5,
  initPox5,
  registerSignerManager,
  deployTestSigner,
  sbtc,
  sbtcBalance,
  makePoxAddrCalldata,
} from './pox-5-helpers';
import { filterEvents, rov, txErr, txOk } from '@clarigen/test';
import { hex } from '@scure/base';
import { accounts, project } from '../clarigen-types';
import { mineUntil, stxToUStx } from '../test-helpers';
import { Cl, serializeCV } from '@stacks/transactions';
import {
  CoreNodeEventType,
  cvToValue,
  err,
  projectFactory,
} from '@clarigen/core';

const contracts = projectFactory(project, 'simnet');
const sbtcRegistry = contracts.sbtcRegistry;

const REWARD_CYCLE_LENGTH = 100n;
const HALF_CYCLE_LENGTH = REWARD_CYCLE_LENGTH / 2n;
const BASIS_POINTS = 10000n;

const deployer = accounts.deployer.address;
const alice = accounts.wallet_1.address;
const bob = accounts.wallet_2.address;
const charlie = accounts.wallet_3.address;
const dave = accounts.wallet_4.address;

beforeEach(() => {
  initPox5();
  registerSignerManager();
});

function reserveRewards(rewards: bigint) {
  return (rewards * pox5.constants.RESERVE_RATIO) / BASIS_POINTS;
}

function stxRewards(rewards: bigint) {
  return rewards - reserveRewards(rewards);
}

function setupTwoStakers() {
  const stake = stxToUStx(50_000);
  txOk(
    pox5.stake({
      signerManager: signerManager.identifier,
      amountUstx: stake,
      numCycles: 2n,
      startBurnHt: simnet.burnBlockHeight,
      signerCalldata: null,
    }),
    alice,
  );
  txOk(
    pox5.stake({
      signerManager: signerManager.identifier,
      amountUstx: stake,
      numCycles: 2n,
      startBurnHt: simnet.burnBlockHeight,
      signerCalldata: null,
    }),
    bob,
  );
}

function setupStaker(staker: string, signerCalldata: Uint8Array | null = null) {
  txOk(
    pox5.stake({
      signerManager: signerManager.identifier,
      amountUstx: stxToUStx(50_000),
      numCycles: 2n,
      startBurnHt: simnet.burnBlockHeight,
      signerCalldata,
    }),
    staker,
  );
}

function setupStakerWithAmount(
  staker: string,
  amountUstx: bigint,
  signerCalldata: Uint8Array | null = null,
) {
  txOk(
    pox5.stake({
      signerManager: signerManager.identifier,
      amountUstx,
      numCycles: 2n,
      startBurnHt: simnet.burnBlockHeight,
      signerCalldata,
    }),
    staker,
  );
}

function calculateAndClaimSignerRewards(rewards: bigint, height: bigint) {
  txOk(
    sbtc.transfer({
      recipient: pox5.identifier,
      amount: rewards,
      sender: deployer,
      memo: null,
    }),
    deployer,
  );
  mineUntil(height);
  txOk(pox5.calculateRewards([]), deployer);
  txOk(signerManager.claimRewards([], 1n), deployer);
}

test('validate-stake! errors when not called by the pox-5 contract', () => {
  // Calling the callback directly (contract-caller is a standard principal,
  // not .pox-5) must be rejected.
  const { calldata } = makePoxAddrCalldata();
  expect(
    txErr(
      signerManager.validateStake_x({
        staker: alice,
        firstIndex: 0n,
        numIndexes: 1n,
        amountUstx: stxToUStx(50_000),
        amountSats: 0n,
        isBond: false,
        signerCalldata: calldata,
      }),
      alice,
    ).value,
  ).toBe(signerManagerErrors.ERR_UNAUTHORIZED_CALLER);

  // The rejected call must not have written a pox-addr for the staker.
  expect(rov(signerManager.getPoxAddr(alice))).toBeNull();
});

test('a third party cannot hijack a staker pox-addr via a direct validate-stake! call', () => {
  // Alice legitimately stakes through pox-5 with no L1 pox-addr.
  setupStaker(alice);
  expect(rov(signerManager.getPoxAddr(alice))).toBeNull();

  // Bob attempts to register his own pox-addr against Alice's principal by
  // invoking the callback directly. This would redirect Alice's L1 rewards
  // to Bob's BTC address if the guard were missing.
  const { calldata } = makePoxAddrCalldata();
  expect(
    txErr(
      signerManager.validateStake_x({
        staker: alice,
        firstIndex: 0n,
        numIndexes: 1n,
        amountUstx: stxToUStx(50_000),
        amountSats: 0n,
        isBond: false,
        signerCalldata: calldata,
      }),
      bob,
    ).value,
  ).toBe(signerManagerErrors.ERR_UNAUTHORIZED_CALLER);
  expect(rov(signerManager.getPoxAddr(alice))).toBeNull();
});

test('signers have pox-addr saved from calldata when provided', () => {
  const { poxAddr, calldata, maxFee } = makePoxAddrCalldata();
  txOk(
    pox5.stake({
      signerManager: signerManager.identifier,
      amountUstx: 100000000n,
      numCycles: 1n,
      startBurnHt: simnet.burnBlockHeight,
      signerCalldata: calldata,
    }),
    alice,
  );
  expect(rov(signerManager.getPoxAddr(alice))?.poxAddr).toEqual(poxAddr);
  expect(rov(signerManager.getPoxAddr(alice))?.maxFee).toEqual(maxFee);
});

test('only admins can update fees and fees must be less than max bips', () => {
  expect(txErr(signerManager.updateFees(1000n), alice).value).toBe(
    signerManagerErrors.ERR_UNAUTHORIZED_ADMIN,
  );
  expect(txErr(signerManager.updateFees(10000n), deployer).value).toBe(
    signerManagerErrors.ERR_INVALID_FEES_BIPS,
  );
  expect(txErr(signerManager.updateFees(10001n), deployer).value).toBe(
    signerManagerErrors.ERR_INVALID_FEES_BIPS,
  );
  txOk(signerManager.updateFees(9999n), deployer);
});

test('staking rejects malformed pox-addr calldata', () => {
  const calldata = hex.decode(
    serializeCV(
      Cl.tuple({
        'pox-addr': Cl.tuple({
          version: Cl.buffer(new Uint8Array([0])),
          hashbytes: Cl.buffer(new Uint8Array(32)),
        }),
        'max-fee': Cl.uint(100n),
      }),
    ),
  );

  expect(
    txErr(
      pox5.stake({
        signerManager: signerManager.identifier,
        amountUstx: 100000000n,
        numCycles: 1n,
        startBurnHt: simnet.burnBlockHeight,
        signerCalldata: calldata,
      }),
      alice,
    ).value,
  ).toBe(signerManagerErrors.ERR_INVALID_POX_ADDR);
  expect(rov(signerManager.getPoxAddr(alice))).toBeNull();
});

test('fees are deducted from newly earned staker rewards', () => {
  const rewards = 2000n;
  const grossPerStaker = stxRewards(rewards) / 2n;
  const fee = grossPerStaker / 10n;

  txOk(signerManager.updateFees(1000n), deployer);
  setupTwoStakers();
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  expect(rov(signerManager.getEarnedStakerRewards(alice, 1n, null))).toEqual({
    earned: grossPerStaker - fee,
    fees: fee,
  });
  expect(rov(signerManager.getEarnedStakerRewards(bob, 1n, null))).toEqual({
    earned: grossPerStaker - fee,
    fees: fee,
  });
});

test('uneven multi-staker rewards conserve gross, fees, and residual dust', () => {
  const rewards = 2000n;
  const aliceStake = stxToUStx(50_000);
  const bobStake = stxToUStx(30_000);
  const charlieStake = stxToUStx(20_001);

  txOk(signerManager.updateFees(1000n), deployer);
  setupStakerWithAmount(alice, aliceStake);
  setupStakerWithAmount(bob, bobStake);
  setupStakerWithAmount(charlie, charlieStake);
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  const grossClaimedBySigner = rov(signerManager.getUnclaimedStakerRewards());
  const aliceRewards = rov(
    signerManager.getEarnedStakerRewards(alice, 1n, null),
  );
  const bobRewards = rov(signerManager.getEarnedStakerRewards(bob, 1n, null));
  const charlieRewards = rov(
    signerManager.getEarnedStakerRewards(charlie, 1n, null),
  );
  const grossAlice = aliceRewards.earned + aliceRewards.fees;
  const grossBob = bobRewards.earned + bobRewards.fees;
  const grossCharlie = charlieRewards.earned + charlieRewards.fees;
  const totalGross = grossAlice + grossBob + grossCharlie;
  const residualDust = grossClaimedBySigner - totalGross;

  expect(aliceRewards).toEqual({ earned: 765n, fees: 84n });
  expect(bobRewards).toEqual({ earned: 459n, fees: 50n });
  expect(charlieRewards).toEqual({ earned: 306n, fees: 34n });
  expect(grossClaimedBySigner).toBe(1699n);
  expect(residualDust).toBe(1n);

  const aliceBalance = sbtcBalance(alice);
  const bobBalance = sbtcBalance(bob);
  const charlieBalance = sbtcBalance(charlie);
  txOk(signerManager.claimStakerRewards(alice, 1n, null), alice);
  txOk(signerManager.claimStakerRewards(bob, 1n, null), bob);
  txOk(signerManager.claimStakerRewards(charlie, 1n, null), charlie);

  expect(sbtcBalance(alice)).toBe(aliceBalance + aliceRewards.earned);
  expect(sbtcBalance(bob)).toBe(bobBalance + bobRewards.earned);
  expect(sbtcBalance(charlie)).toBe(charlieBalance + charlieRewards.earned);
  expect(rov(signerManager.getEarnedFees())).toBe(
    aliceRewards.fees + bobRewards.fees + charlieRewards.fees,
  );
  expect(rov(signerManager.getUnclaimedStakerRewards())).toBe(residualDust);
  expect(sbtcBalance(signerManager.identifier)).toBe(
    rov(signerManager.getEarnedFees()) + residualDust,
  );

  expect(txErr(signerManager.sweepFeeRefunds(dave), deployer).value).toBe(
    signerManagerErrors.ERR_NO_REFUNDS,
  );

  txOk(signerManager.updateAdmin(dave, true), deployer);
  expect(txErr(signerManager.sweepFeeRefunds(dave), dave).value).toBe(
    signerManagerErrors.ERR_NO_REFUNDS,
  );

  const deployerBalance = sbtcBalance(deployer);
  const fees = rov(signerManager.getEarnedFees());
  txOk(
    signerManager.withdrawFees({ amount: fees, recipient: deployer }),
    deployer,
  );
  expect(sbtcBalance(deployer)).toBe(deployerBalance + fees);
  expect(rov(signerManager.getEarnedFees())).toBe(0n);
  expect(sbtcBalance(signerManager.identifier)).toBe(residualDust);
  expect(txErr(signerManager.sweepFeeRefunds(dave), dave).value).toBe(
    signerManagerErrors.ERR_NO_REFUNDS,
  );
});

test('claiming staker rewards transfers net rewards after fees', () => {
  const rewards = 2000n;
  const grossPerStaker = stxRewards(rewards) / 2n;
  const netRewards = grossPerStaker - grossPerStaker / 10n;

  txOk(signerManager.updateFees(1000n), deployer);
  setupTwoStakers();
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  const aliceBalance = sbtcBalance(alice);
  const claim = txOk(signerManager.claimStakerRewards(alice, 1n, null), alice);

  // No pox-addr, so the staker is paid directly in sBTC and no L1 withdrawal
  // is initiated; the return carries `none` for the request-id.
  expect(claim.value).toStrictEqual({
    earned: netRewards,
    withdrawalRequest: null,
  });
  const [transfer] = filterEvents(
    claim.events,
    CoreNodeEventType.FtTransferEvent,
  );
  const printEvent = filterEvents(
    claim.events,
    CoreNodeEventType.ContractEvent,
  ).find((e) => e.data.contract_identifier === signerManager.identifier)!;
  const printData = cvToValue<{
    topic: string;
    amountSats: bigint;
    l1Withdrawal: null;
    staker: string;
    rewardCycle: bigint;
    bondIndex: null;
  }>(printEvent.data.value);

  expect(transfer.data.sender).toBe(signerManager.identifier);
  expect(transfer.data.recipient).toBe(alice);
  expect(transfer.data.amount).toBe(netRewards.toString());
  expect(printData).toEqual({
    topic: 'claim-staker-rewards',
    amountSats: netRewards,
    l1Withdrawal: null,
    staker: alice,
    rewardCycle: 1n,
    bondIndex: null,
  });
  expect(sbtcBalance(alice)).toBe(aliceBalance + netRewards);
  expect(rov(signerManager.getEarnedStakerRewards(alice, 1n, null))).toEqual({
    earned: 0n,
    fees: 0n,
  });
});

test('admins can withdraw accrued fees', () => {
  const rewards = 2000n;
  const grossPerStaker = stxRewards(rewards) / 2n;
  const fee = grossPerStaker / 10n;

  txOk(signerManager.updateFees(1000n), deployer);
  setupTwoStakers();
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );
  txOk(signerManager.claimStakerRewards(alice, 1n, null), alice);
  txOk(signerManager.claimStakerRewards(bob, 1n, null), bob);

  expect(rov(signerManager.getEarnedFees())).toBe(fee * 2n);
  expect(
    txErr(
      signerManager.withdrawFees({ amount: 1n, recipient: deployer }),
      alice,
    ).value,
  ).toBe(signerManagerErrors.ERR_UNAUTHORIZED_ADMIN);
  expect(
    txErr(
      signerManager.withdrawFees({
        amount: fee * 2n + 1n,
        recipient: deployer,
      }),
      deployer,
    ).value,
  ).toBe(signerManagerErrors.ERR_INSUFFICIENT_FEES);

  const deployerBalance = sbtcBalance(deployer);
  const withdraw = txOk(
    signerManager.withdrawFees({ amount: fee, recipient: deployer }),
    deployer,
  );
  const [transfer] = filterEvents(
    withdraw.events,
    CoreNodeEventType.FtTransferEvent,
  );

  expect(withdraw.value).toBe(fee);
  expect(transfer.data.sender).toBe(signerManager.identifier);
  expect(transfer.data.recipient).toBe(deployer);
  expect(transfer.data.amount).toBe(fee.toString());
  expect(sbtcBalance(deployer)).toBe(deployerBalance + fee);
  expect(rov(signerManager.getEarnedFees())).toBe(fee);
});

test('bond rewards remain claimable from old signer after staker changes signers', () => {
  const bondIndex = 0n;
  const aliceSats = 480000n;
  const rewards = 1200n;
  const signer2 = deployTestSigner(
    'bond-update-manager-claim-signer-2',
  ).identifier;

  txOk(
    pox5.setupBond({
      bondIndex,
      targetRate: 1500n,
      stxValueRatio: 10n,
      minUstxRatio: 100n,
      earlyUnlockBytes: new Uint8Array(),
      allowlist: [{ maxSats: aliceSats, staker: alice }],
    }),
    deployer,
  );
  txOk(
    pox5.registerForBond({
      bondIndex,
      signerManager: signerManager.identifier,
      amountUstx: stxToUStx(50_000),
      btcLockup: err(aliceSats),
      signerCalldata: null,
    }),
    alice,
  );
  txOk(
    sbtc.transfer({
      recipient: pox5.identifier,
      amount: rewards,
      sender: deployer,
      memo: null,
    }),
    deployer,
  );

  mineUntil(rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH);
  txOk(pox5.calculateRewards([bondIndex]), deployer);

  txOk(
    pox5.updateBondRegistration({
      signerManager: signer2,
      oldSignerManager: signerManager.identifier,
      signerCalldata: null,
    }),
    alice,
  );
  expect(
    rov(
      pox5.getStakerSharesStakedForCycle(
        alice,
        1n,
        bondIndex,
        signerManager.identifier,
      ),
    ),
  ).toBe(aliceSats);
  expect(
    rov(pox5.getStakerSharesStakedForCycle(alice, 1n, bondIndex, signer2)),
  ).toBe(0n);
  expect(
    rov(
      pox5.getStakerSharesStakedForCycle(
        alice,
        2n,
        bondIndex,
        signerManager.identifier,
      ),
    ),
  ).toBe(0n);
  expect(
    rov(
      pox5.getStakerUnclaimedRewardsForCycle(
        signerManager.identifier,
        1n,
        bondIndex,
        alice,
      ),
    ),
  ).toBe(rewards);

  txOk(signerManager.claimRewards([bondIndex], 1n), deployer);

  const aliceBalance = sbtcBalance(alice);
  txOk(signerManager.claimStakerRewards(alice, 1n, bondIndex), alice);
  expect(sbtcBalance(alice)).toBe(aliceBalance + rewards);
  expect(
    rov(signerManager.getEarnedStakerRewards(alice, 1n, bondIndex)),
  ).toEqual({
    earned: 0n,
    fees: 0n,
  });
});

test('staker reward claim before signer reward pull returns no claimable rewards', () => {
  const bondIndex = 0n;
  const aliceSats = 480000n;
  const rewards = 1200n;

  txOk(
    pox5.setupBond({
      bondIndex,
      targetRate: 1500n,
      stxValueRatio: 10n,
      minUstxRatio: 100n,
      earlyUnlockBytes: new Uint8Array(),
      allowlist: [{ maxSats: aliceSats, staker: alice }],
    }),
    deployer,
  );
  txOk(
    pox5.registerForBond({
      bondIndex,
      signerManager: signerManager.identifier,
      amountUstx: stxToUStx(50_000),
      btcLockup: err(aliceSats),
      signerCalldata: null,
    }),
    alice,
  );
  txOk(
    sbtc.transfer({
      recipient: pox5.identifier,
      amount: rewards,
      sender: deployer,
      memo: null,
    }),
    deployer,
  );

  mineUntil(rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH);
  txOk(pox5.calculateRewards([bondIndex]), deployer);
  txOk(
    pox5.unstakeSbtc({
      signerManager: signerManager.identifier,
      amountToWithdrawalSats: aliceSats,
    }),
    alice,
  );
  txOk(
    sbtc.transfer({
      recipient: signerManager.identifier,
      amount: 1n,
      sender: deployer,
      memo: null,
    }),
    deployer,
  );

  expect(
    txErr(signerManager.claimStakerRewards(alice, 1n, bondIndex), bob).value,
  ).toBe(signerManagerErrors.ERR_NO_CLAIMABLE_REWARDS);

  txOk(signerManager.claimRewards([bondIndex], 1n), deployer);
  txOk(signerManager.claimStakerRewards(alice, 1n, bondIndex), bob);
});

test('claiming staker rewards with pox-addr initiates a withdrawal request', () => {
  const rewards = 2000n;
  const grossPerStaker = stxRewards(rewards) / 2n;
  const maxFee = 100n;
  const { poxAddr, calldata } = makePoxAddrCalldata({ maxFee });

  setupStaker(alice, calldata);
  setupStaker(bob);
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  const aliceBalance = sbtcBalance(alice);
  const claim = txOk(signerManager.claimStakerRewards(alice, 1n, null), bob);
  const transfers = filterEvents(
    claim.events,
    CoreNodeEventType.FtTransferEvent,
  );
  const printEvent = filterEvents(
    claim.events,
    CoreNodeEventType.ContractEvent,
  ).find((e) => e.data.contract_identifier === signerManager.identifier)!;
  const printData = cvToValue<{
    topic: string;
    amountSats: bigint;
    l1Withdrawal: {
      poxAddr: { version: Uint8Array; hashbytes: Uint8Array };
      amount: bigint;
      maxFee: bigint;
      withdrawalRequest: bigint;
    };
    staker: string;
    rewardCycle: bigint;
    bondIndex: null;
  }>(printEvent.data.value);

  expect(transfers).toHaveLength(0);
  expect(sbtcBalance(alice)).toBe(aliceBalance);
  expect(printData).toEqual({
    topic: 'claim-staker-rewards',
    amountSats: grossPerStaker,
    l1Withdrawal: {
      poxAddr,
      amount: grossPerStaker - maxFee,
      maxFee,
      withdrawalRequest: 1n,
    },
    staker: alice,
    rewardCycle: 1n,
    bondIndex: null,
  });
  const withdrawalRequest = rov(sbtcRegistry.getWithdrawalRequest(1n))!;
  expect(withdrawalRequest.amount).toBe(grossPerStaker - maxFee);
  expect(withdrawalRequest.maxFee).toBe(maxFee);
  expect(withdrawalRequest.recipient).toStrictEqual(poxAddr);
  expect(withdrawalRequest.sender).toBe(signerManager.identifier);
  expect(withdrawalRequest.status).toBe(null);
  expect(rov(signerManager.getWithdrawalRequestStaker(1n))).toBe(alice);
  expect(rov(signerManager.getEarnedStakerRewards(alice, 1n, null))).toEqual({
    earned: 0n,
    fees: 0n,
  });
});

test('claiming all rewards with pox-addr leaves room for withdrawal max-fee', () => {
  const rewards = 2000n;
  const earned = stxRewards(rewards);
  const maxFee = 100n;
  const { calldata } = makePoxAddrCalldata({ maxFee });

  setupStaker(alice, calldata);
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  const claim = txOk(signerManager.claimStakerRewards(alice, 1n, null), bob);

  // Since a pox-addr is set, the payout is routed to an sBTC withdrawal, and
  // the request-id starts at 1 in this test's simnet.
  expect(claim.value).toStrictEqual({ earned, withdrawalRequest: 1n });
});

test('claiming staker rewards with pox-addr errors when earned is less than max-fee', () => {
  const rewards = 600n;
  const earned = stxRewards(rewards);
  const maxFee = earned + 1n;
  const { calldata } = makePoxAddrCalldata({ maxFee });

  setupStaker(alice, calldata);
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  expect(
    txErr(signerManager.claimStakerRewards(alice, 1n, null), bob).value,
  ).toBe(signerManagerErrors.ERR_NO_CLAIMABLE_REWARDS);
});

test('fee changes do not apply retroactively to an already recorded cycle', () => {
  const rewards = 2000n;
  const grossAfterTwoCalculations = stxRewards(rewards * 2n) / 2n;
  const fee = grossAfterTwoCalculations / 10n;

  txOk(signerManager.updateFees(1000n), deployer);
  setupTwoStakers();
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );
  expect(rov(signerManager.getEarnedStakerRewards(alice, 1n, null))).toEqual({
    earned: 765n,
    fees: 85n,
  });

  txOk(signerManager.updateFees(5000n), deployer);
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(2n)),
  );

  expect(rov(signerManager.getEarnedStakerRewards(alice, 1n, null))).toEqual({
    earned: grossAfterTwoCalculations - fee,
    fees: fee,
  });
});

test('already claimed rewards are not affected by later fee changes', () => {
  const rewards = 2000n;

  txOk(signerManager.updateFees(1000n), deployer);
  setupTwoStakers();
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(1n)) + HALF_CYCLE_LENGTH,
  );

  const aliceBalance = sbtcBalance(alice);
  txOk(signerManager.claimStakerRewards(alice, 1n, null), alice);

  txOk(signerManager.updateFees(5000n), deployer);
  calculateAndClaimSignerRewards(
    rewards,
    rov(pox5.rewardCycleToBurnHeight(2n)),
  );

  expect(rov(signerManager.getEarnedStakerRewards(alice, 1n, null))).toEqual({
    earned: 765n,
    fees: 85n,
  });
  txOk(signerManager.claimStakerRewards(alice, 1n, null), alice);
  expect(sbtcBalance(alice)).toBe(aliceBalance + 765n + 765n);
});
