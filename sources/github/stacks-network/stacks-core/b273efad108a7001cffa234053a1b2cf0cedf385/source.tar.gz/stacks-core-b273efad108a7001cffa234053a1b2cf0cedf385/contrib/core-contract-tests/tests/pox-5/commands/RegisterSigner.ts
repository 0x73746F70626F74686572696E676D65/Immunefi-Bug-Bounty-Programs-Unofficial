import fc from 'fast-check';
import type { Model, Real } from './types';
import {
  candidateSignerIds,
  getWalletNameByAddress,
  grantKey,
  logCommand,
  refreshModel,
  usedGrantKey,
} from './utils';
import { rov } from '@clarigen/test';
import { expect } from 'vitest';
import { pox5, registerSigner, testSignerHandle } from '../pox-5-helpers';

export const RegisterSigner = (accounts: Real['accounts']) =>
  fc
    .record({
      caller: fc.constantFrom(...Object.values(accounts).map((x) => x.address)),
      signer: fc.constantFrom(...candidateSignerIds),
      seed: fc.uint8Array({ minLength: 48, maxLength: 48 }),
      authId: fc.bigInt({ min: 1n, max: 1_000_000_000n }),
    })
    .map((r) => {
      return {
        check: (model: Readonly<Model>) =>
          model.deployedSigners.has(r.signer) && !model.signers.has(r.signer),
        run: (model: Model, real: Real) => {
          refreshModel(model, real);

          // Arrange
          const signerId = r.signer;
          const signerManager = testSignerHandle(signerId);
          const bitcoinHeightBefore = real.network.burnBlockHeight;
          const stacksHeightBefore = real.network.stacksBlockHeight;

          // Act
          const { signerKey } = registerSigner({
            signerManager,
            caller: r.caller,
            seed: r.seed,
            authId: r.authId,
          });

          // Assert
          expect(rov(pox5.getSignerInfo(signerId))).toEqual(signerKey);

          // Update model: register-self consumed the (key, manager, auth-id)
          // grant for replay protection yet left it live for verification.
          model.signers.set(signerId, { signerKey });
          model.usedGrants.add(usedGrantKey(signerKey, signerId, r.authId));
          model.activeGrants.add(grantKey(signerKey, signerId));

          logCommand({
            sender: getWalletNameByAddress(r.caller),
            action: 'register-signer',
            value: signerId,
            bitcoinHeightBefore,
            stacksHeightBefore,
          });
        },
        toString: () =>
          `register-signer(${getWalletNameByAddress(r.caller)}, ${r.signer.split('.').pop()})`,
      };
    });
