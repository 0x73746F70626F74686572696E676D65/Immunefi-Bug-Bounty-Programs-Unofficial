use starknet::ContractAddress;
pub type RoleId = felt252;

// Role                |   Role Admin
// ----------------------------------------
// GOVERNANCE_ADMIN    |   GOVERNANCE_ADMIN
// UPGRADE_GOVERNOR    |   GOVERNANCE_ADMIN
// UPGRADE_AGENT       |   APP_ROLE_ADMIN
// APP_ROLE_ADMIN      |   GOVERNANCE_ADMIN
// APP_GOVERNOR        |   APP_ROLE_ADMIN
// OPERATOR            |   APP_ROLE_ADMIN
// TOKEN_ADMIN         |   APP_ROLE_ADMIN
// SECURITY_ADMIN      |   SECURITY_ADMIN
// SECURITY_AGENT      |   SECURITY_ADMIN.
// SECURITY_GOVERNOR   |   SECURITY_ADMIN.

// int.from_bytes(Web3.keccak(text="ROLE_APP_GOVERNOR"), "big") & MASK_250 .
pub const APP_GOVERNOR: RoleId = 0xd2ead78c620e94b02d0a996e99298c59ddccfa1d8a0149080ac3a20de06068;

// int.from_bytes(Web3.keccak(text="ROLE_APP_ROLE_ADMIN"), "big") & MASK_250 .
pub const APP_ROLE_ADMIN: RoleId =
    0x3e615638e0b79444a70f8c695bf8f2a47033bf1cf95691ec3130f64939cee99;

// int.from_bytes(Web3.keccak(text="ROLE_GOVERNANCE_ADMIN"), "big") & MASK_250 .
pub const GOVERNANCE_ADMIN: RoleId =
    0x3711c9d994faf6055172091cb841fd4831aa743e6f3315163b06a122c841846;

// int.from_bytes(Web3.keccak(text="ROLE_OPERATOR"), "big") & MASK_250 .
pub const OPERATOR: RoleId = 0x023edb77f7c8cc9e38e8afe78954f703aeeda7fffe014eeb6e56ea84e62f6da7;

// int.from_bytes(Web3.keccak(text="ROLE_TOKEN_ADMIN"), "big") & MASK_250 .
pub const TOKEN_ADMIN: RoleId = 0x0128d63adbf6b09002c26caf55c47e2f26635807e3ef1b027218aa74c8d61a3e;

// int.from_bytes(Web3.keccak(text="ROLE_UPGRADE_AGENT"), "big") & MASK_250 .
pub const UPGRADE_AGENT: RoleId = 0x1d8034a6db21585e9d97ca912eb8113361e6858f64c45c9b321a4d01e949484;

// int.from_bytes(Web3.keccak(text="ROLE_UPGRADE_GOVERNOR"), "big") & MASK_250 .
pub const UPGRADE_GOVERNOR: RoleId =
    0x251e864ca2a080f55bce5da2452e8cfcafdbc951a3e7fff5023d558452ec228;

// int.from_bytes(Web3.keccak(text="ROLE_SECURITY_ADMIN"), "big") & MASK_250 .
pub const SECURITY_ADMIN: RoleId =
    0x26bd110619d11cfdfc28e281df893bc24828e89177318e9dbd860cdaedeb6b3;

// int.from_bytes(Web3.keccak(text="ROLE_SECURITY_AGENT"), "big") & MASK_250 .
pub const SECURITY_AGENT: RoleId =
    0x37693ba312785932d430dccf0f56ffedd0aa7c0f8b6da2cc4530c2717689b96;

// int.from_bytes(Web3.keccak(text="ROLE_SECURITY_GOVERNOR"), "big") & MASK_250 .
pub const SECURITY_GOVERNOR: RoleId =
    0xa5a83e9807e87f281d865ab54b7b0ed2f7f4bbfef73888810ca16e95e734eb;

#[starknet::interface]
pub trait IRoles<TContractState> {
    fn is_app_governor(self: @TContractState, account: ContractAddress) -> bool;
    fn is_app_role_admin(self: @TContractState, account: ContractAddress) -> bool;
    fn is_governance_admin(self: @TContractState, account: ContractAddress) -> bool;
    fn is_operator(self: @TContractState, account: ContractAddress) -> bool;
    fn is_token_admin(self: @TContractState, account: ContractAddress) -> bool;
    fn is_upgrade_agent(self: @TContractState, account: ContractAddress) -> bool;
    fn is_upgrade_governor(self: @TContractState, account: ContractAddress) -> bool;
    fn is_security_admin(self: @TContractState, account: ContractAddress) -> bool;
    fn is_security_agent(self: @TContractState, account: ContractAddress) -> bool;
    fn is_security_governor(self: @TContractState, account: ContractAddress) -> bool;
    fn register_app_governor(ref self: TContractState, account: ContractAddress);
    fn remove_app_governor(ref self: TContractState, account: ContractAddress);
    fn register_app_role_admin(ref self: TContractState, account: ContractAddress);
    fn remove_app_role_admin(ref self: TContractState, account: ContractAddress);
    fn register_governance_admin(ref self: TContractState, account: ContractAddress);
    fn remove_governance_admin(ref self: TContractState, account: ContractAddress);
    fn register_operator(ref self: TContractState, account: ContractAddress);
    fn remove_operator(ref self: TContractState, account: ContractAddress);
    fn register_token_admin(ref self: TContractState, account: ContractAddress);
    fn remove_token_admin(ref self: TContractState, account: ContractAddress);
    fn register_upgrade_agent(ref self: TContractState, account: ContractAddress);
    fn remove_upgrade_agent(ref self: TContractState, account: ContractAddress);
    fn register_upgrade_governor(ref self: TContractState, account: ContractAddress);
    fn remove_upgrade_governor(ref self: TContractState, account: ContractAddress);
    fn register_security_admin(ref self: TContractState, account: ContractAddress);
    fn remove_security_admin(ref self: TContractState, account: ContractAddress);
    fn register_security_agent(ref self: TContractState, account: ContractAddress);
    fn remove_security_agent(ref self: TContractState, account: ContractAddress);
    fn register_security_governor(ref self: TContractState, account: ContractAddress);
    fn remove_security_governor(ref self: TContractState, account: ContractAddress);
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct AppGovernorAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct AppGovernorRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}
#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct AppRoleAdminAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct AppRoleAdminRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct GovernanceAdminAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct GovernanceAdminRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct OperatorAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct SecurityAgentAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct SecurityAgentRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct SecurityGovernorAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct SecurityGovernorRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct SecurityAdminAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct SecurityAdminRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct OperatorRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct TokenAdminAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct TokenAdminRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct UpgradeGovernorAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct UpgradeGovernorRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct UpgradeAgentAdded {
    pub added_account: ContractAddress,
    pub added_by: ContractAddress,
}

#[derive(Copy, Drop, PartialEq, starknet::Event)]
pub(crate) struct UpgradeAgentRemoved {
    pub removed_account: ContractAddress,
    pub removed_by: ContractAddress,
}

// ─── CommonRoles types
// ──────────────────────────────────

#[derive(Copy, Drop, PartialEq)]
pub enum Role {
    AppGovernor,
    AppRoleAdmin,
    GovernanceAdmin,
    Operator,
    TokenAdmin,
    UpgradeAgent,
    UpgradeGovernor,
    SecurityAdmin,
    SecurityAgent,
    SecurityGovernor,
}

pub impl RoleSerde of Serde<Role> {
    fn serialize(self: @Role, ref output: Array<felt252>) {
        let role_id: RoleId = (*self).into();
        role_id.serialize(ref output);
    }

    fn deserialize(ref serialized: Span<felt252>) -> Option<Role> {
        let role_id: RoleId = Serde::deserialize(ref serialized)?;
        if role_id == APP_GOVERNOR {
            return Option::Some(Role::AppGovernor);
        }
        if role_id == APP_ROLE_ADMIN {
            return Option::Some(Role::AppRoleAdmin);
        }
        if role_id == GOVERNANCE_ADMIN {
            return Option::Some(Role::GovernanceAdmin);
        }
        if role_id == OPERATOR {
            return Option::Some(Role::Operator);
        }
        if role_id == TOKEN_ADMIN {
            return Option::Some(Role::TokenAdmin);
        }
        if role_id == UPGRADE_AGENT {
            return Option::Some(Role::UpgradeAgent);
        }
        if role_id == UPGRADE_GOVERNOR {
            return Option::Some(Role::UpgradeGovernor);
        }
        if role_id == SECURITY_ADMIN {
            return Option::Some(Role::SecurityAdmin);
        }
        if role_id == SECURITY_AGENT {
            return Option::Some(Role::SecurityAgent);
        }
        if role_id == SECURITY_GOVERNOR {
            return Option::Some(Role::SecurityGovernor);
        }
        Option::None
    }
}

pub impl RoleIntoRoleId of Into<Role, RoleId> {
    fn into(self: Role) -> RoleId {
        match self {
            Role::AppGovernor => APP_GOVERNOR,
            Role::AppRoleAdmin => APP_ROLE_ADMIN,
            Role::GovernanceAdmin => GOVERNANCE_ADMIN,
            Role::Operator => OPERATOR,
            Role::TokenAdmin => TOKEN_ADMIN,
            Role::UpgradeAgent => UPGRADE_AGENT,
            Role::UpgradeGovernor => UPGRADE_GOVERNOR,
            Role::SecurityAdmin => SECURITY_ADMIN,
            Role::SecurityAgent => SECURITY_AGENT,
            Role::SecurityGovernor => SECURITY_GOVERNOR,
        }
    }
}

pub fn is_renounceable(role: Role) -> bool {
    match role {
        Role::AppGovernor => true,
        Role::AppRoleAdmin => true,
        Role::GovernanceAdmin => false,
        Role::Operator => true,
        Role::TokenAdmin => true,
        Role::UpgradeAgent => true,
        Role::UpgradeGovernor => true,
        Role::SecurityAdmin => false,
        Role::SecurityAgent => true,
        Role::SecurityGovernor => true,
    }
}

#[starknet::interface]
pub trait ICommonRoles<TState> {
    fn grant_role(ref self: TState, role: Role, account: ContractAddress);
    fn revoke_role(ref self: TState, role: Role, account: ContractAddress);
    fn has_role(self: @TState, role: Role, account: ContractAddress) -> bool;
    fn renounce(ref self: TState, role: Role);
    // Always present — rescue path for contracts upgrading from legacy role storage.
    fn reclaim_legacy_roles(ref self: TState);
    fn reclaim_legacy_roles_for_accounts(ref self: TState, accounts: Span<ContractAddress>);
    fn disable_legacy_role_reclaim(ref self: TState);
}

// ─── Category-scoped role interfaces ─────

#[starknet::interface]
pub trait ISecurityRoles<TState> {
    fn is_security_admin(self: @TState, account: ContractAddress) -> bool;
    fn register_security_admin(ref self: TState, account: ContractAddress);
    fn remove_security_admin(ref self: TState, account: ContractAddress);
    fn is_security_agent(self: @TState, account: ContractAddress) -> bool;
    fn register_security_agent(ref self: TState, account: ContractAddress);
    fn remove_security_agent(ref self: TState, account: ContractAddress);
    fn is_security_governor(self: @TState, account: ContractAddress) -> bool;
    fn register_security_governor(ref self: TState, account: ContractAddress);
    fn remove_security_governor(ref self: TState, account: ContractAddress);
}

#[starknet::interface]
pub trait IGovernanceRoles<TState> {
    fn is_governance_admin(self: @TState, account: ContractAddress) -> bool;
    fn register_governance_admin(ref self: TState, account: ContractAddress);
    fn remove_governance_admin(ref self: TState, account: ContractAddress);
    fn is_app_role_admin(self: @TState, account: ContractAddress) -> bool;
    fn register_app_role_admin(ref self: TState, account: ContractAddress);
    fn remove_app_role_admin(ref self: TState, account: ContractAddress);
    fn is_upgrade_governor(self: @TState, account: ContractAddress) -> bool;
    fn register_upgrade_governor(ref self: TState, account: ContractAddress);
    fn remove_upgrade_governor(ref self: TState, account: ContractAddress);
    fn is_upgrade_agent(self: @TState, account: ContractAddress) -> bool;
    fn register_upgrade_agent(ref self: TState, account: ContractAddress);
    fn remove_upgrade_agent(ref self: TState, account: ContractAddress);
}

#[starknet::interface]
pub trait IAppRoles<TState> {
    fn is_app_governor(self: @TState, account: ContractAddress) -> bool;
    fn register_app_governor(ref self: TState, account: ContractAddress);
    fn remove_app_governor(ref self: TState, account: ContractAddress);
    fn is_operator(self: @TState, account: ContractAddress) -> bool;
    fn register_operator(ref self: TState, account: ContractAddress);
    fn remove_operator(ref self: TState, account: ContractAddress);
    fn is_token_admin(self: @TState, account: ContractAddress) -> bool;
    fn register_token_admin(ref self: TState, account: ContractAddress);
    fn remove_token_admin(ref self: TState, account: ContractAddress);
}
