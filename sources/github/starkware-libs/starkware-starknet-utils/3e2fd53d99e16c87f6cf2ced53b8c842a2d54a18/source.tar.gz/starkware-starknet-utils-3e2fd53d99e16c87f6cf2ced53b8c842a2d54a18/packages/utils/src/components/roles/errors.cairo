use starkware_utils::errors::{Describable, ErrorDisplay};

#[derive(Drop)]
pub enum AccessErrors {
    INVALID_MINTER,
    INVALID_TOKEN,
    CALLER_MISSING_ROLE,
    ZERO_ADDRESS,
    ALREADY_INITIALIZED,
    ZERO_ADDRESS_GOV_ADMIN,
    ONLY_APP_GOVERNOR,
    ONLY_OPERATOR,
    ONLY_TOKEN_ADMIN,
    ONLY_UPGRADE_GOVERNOR,
    ONLY_UPGRADER,
    ONLY_SECURITY_ADMIN,
    ONLY_SECURITY_AGENT,
    ONLY_SECURITY_GOVERNOR,
    ONLY_MINTER,
    ONLY_SELF_CAN_RENOUNCE,
    ROLE_CANNOT_BE_RENOUNCED,
    MISSING_ROLE,
    LEGACY_ROLE_RECLAIM_DISABLED,
}

impl DescribableError of Describable<AccessErrors> {
    fn describe(self: @AccessErrors) -> ByteArray {
        match self {
            AccessErrors::INVALID_MINTER => "INVALID_MINTER_ADDRESS",
            AccessErrors::INVALID_TOKEN => "INVALID_TOKEN_ADDRESS",
            AccessErrors::CALLER_MISSING_ROLE => "CALLER_IS_MISSING_ROLE",
            AccessErrors::ZERO_ADDRESS => "INVALID_ZERO_ACCOUNT_ADDRESS",
            AccessErrors::ALREADY_INITIALIZED => "ROLES_ALREADY_INITIALIZED",
            AccessErrors::ZERO_ADDRESS_GOV_ADMIN => "INVALID_ZERO_ADDRESS_GOV_ADMIN",
            AccessErrors::ONLY_APP_GOVERNOR => "ONLY_APP_GOVERNOR",
            AccessErrors::ONLY_OPERATOR => "ONLY_OPERATOR",
            AccessErrors::ONLY_TOKEN_ADMIN => "ONLY_TOKEN_ADMIN",
            AccessErrors::ONLY_UPGRADE_GOVERNOR => "ONLY_UPGRADE_GOVERNOR",
            AccessErrors::ONLY_UPGRADER => "ONLY_UPGRADER",
            AccessErrors::ONLY_SECURITY_ADMIN => "ONLY_SECURITY_ADMIN",
            AccessErrors::ONLY_SECURITY_AGENT => "ONLY_SECURITY_AGENT",
            AccessErrors::ONLY_SECURITY_GOVERNOR => "ONLY_SECURITY_GOVERNOR",
            AccessErrors::ONLY_MINTER => "MINTER_ONLY",
            AccessErrors::ONLY_SELF_CAN_RENOUNCE => "ONLY_SELF_CAN_RENOUNCE",
            AccessErrors::ROLE_CANNOT_BE_RENOUNCED => "ROLE_CANNOT_BE_RENOUNCED",
            AccessErrors::MISSING_ROLE => "Caller is missing role",
            AccessErrors::LEGACY_ROLE_RECLAIM_DISABLED => "LEGACY_ROLE_RECLAIM_DISABLED",
        }
    }
}
