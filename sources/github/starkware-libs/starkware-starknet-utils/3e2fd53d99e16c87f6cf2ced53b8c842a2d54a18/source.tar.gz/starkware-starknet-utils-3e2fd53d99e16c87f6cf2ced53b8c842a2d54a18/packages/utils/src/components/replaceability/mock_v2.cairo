// Variant of `ReplaceabilityMock` with a class hash distinctly different than `mock.cairo`.
#[starknet::contract]
pub(crate) mod ReplaceabilityMockV2 {
    use CommonRolesComponent::InternalTrait as CommonRolesInternalTrait;
    use openzeppelin::access::accesscontrol::AccessControlComponent;
    use openzeppelin::introspection::src5::SRC5Component;
    use starknet::ContractAddress;
    use starknet::storage::StoragePointerWriteAccess;
    use starkware_utils::components::common_roles::CommonRolesComponent;
    use starkware_utils::components::replaceability::ReplaceabilityComponent;
    use starkware_utils::components::replaceability::ReplaceabilityComponent::InternalReplaceabilityTrait;

    component!(path: ReplaceabilityComponent, storage: replaceability, event: ReplaceabilityEvent);
    component!(path: CommonRolesComponent, storage: common_roles, event: CommonRolesEvent);
    component!(path: AccessControlComponent, storage: accesscontrol, event: AccessControlEvent);
    component!(path: SRC5Component, storage: src5, event: SRC5Event);

    #[storage]
    struct Storage {
        #[substorage(v0)]
        replaceability: ReplaceabilityComponent::Storage,
        #[substorage(v0)]
        common_roles: CommonRolesComponent::Storage,
        #[substorage(v0)]
        accesscontrol: AccessControlComponent::Storage,
        #[substorage(v0)]
        src5: SRC5Component::Storage,
        // Extra field to produce a different class hash from ReplaceabilityMock.
        _v2_marker: bool,
    }

    #[event]
    #[derive(Drop, starknet::Event)]
    pub(crate) enum Event {
        ReplaceabilityEvent: ReplaceabilityComponent::Event,
        CommonRolesEvent: CommonRolesComponent::Event,
        AccessControlEvent: AccessControlComponent::Event,
        SRC5Event: SRC5Component::Event,
    }

    #[constructor]
    fn constructor(ref self: ContractState, upgrade_delay: u64, governance_admin: ContractAddress) {
        self.common_roles.initialize(:governance_admin);
        self.replaceability.initialize(:upgrade_delay);
        // Make good use of the extra field.
        self._v2_marker.write(true);
    }

    #[abi(embed_v0)]
    impl ReplaceabilityImpl =
        ReplaceabilityComponent::ReplaceabilityImpl<ContractState>;

    #[abi(embed_v0)]
    impl CommonRolesImpl = CommonRolesComponent::CommonRolesImpl<ContractState>;
}
