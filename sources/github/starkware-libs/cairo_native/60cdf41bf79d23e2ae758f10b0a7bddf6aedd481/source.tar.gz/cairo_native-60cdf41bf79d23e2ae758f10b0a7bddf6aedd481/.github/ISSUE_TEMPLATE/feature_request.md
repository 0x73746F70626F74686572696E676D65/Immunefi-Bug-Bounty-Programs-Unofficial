---
name: Feature request
about: Suggest a feature for this project
title: ''
labels: ''
assignees: ''

---

**Is your related to a Starknet project? **

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.


**Additional context**
Add any other context or screenshots about the feature request here.
