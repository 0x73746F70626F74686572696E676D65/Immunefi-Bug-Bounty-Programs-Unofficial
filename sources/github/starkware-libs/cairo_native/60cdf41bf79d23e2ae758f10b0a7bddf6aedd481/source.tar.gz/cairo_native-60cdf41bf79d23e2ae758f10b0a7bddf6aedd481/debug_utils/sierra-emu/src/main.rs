use self::args::CmdArgs;
use cairo_lang_compiler::{
    compile_prepared_db, db::RootDatabase, project::setup_project, CompilerConfig,
};
use cairo_lang_filesystem::ids::CrateInput;
use clap::Parser;
use sierra_emu::run_program;
use std::{fs::File, io::stdout};
use tracing::{info, Level};
use tracing_subscriber::{EnvFilter, FmtSubscriber};

mod args;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = CmdArgs::parse();

    tracing::subscriber::set_global_default(
        FmtSubscriber::builder()
            .with_env_filter(EnvFilter::from_default_env())
            .with_max_level(Level::TRACE)
            .finish(),
    )?;

    let mut db = RootDatabase::builder().detect_corelib().build()?;
    let main_crate_ids = {
        let main_crate_inputs =
            setup_project(&mut db, &args.program).expect("failed to setup project");
        CrateInput::into_crate_ids(&db, main_crate_inputs)
    };

    let program = compile_prepared_db(
        &db,
        main_crate_ids,
        CompilerConfig {
            replace_ids: true,
            ..Default::default()
        },
    )?
    .program;

    info!("Running the program.");
    let trace = run_program(
        program.into(),
        args.entry_point,
        args.args,
        args.available_gas.unwrap_or_default(),
    );

    match args.output {
        Some(path) => serde_json::to_writer(File::create(path)?, &trace)?,
        None => serde_json::to_writer(stdout().lock(), &trace)?,
    };

    Ok(())
}

#[cfg(test)]
mod test {
    use std::path::Path;

    use cairo_lang_compiler::CompilerConfig;
    use cairo_lang_lowering::utils::InliningStrategy;
    use cairo_lang_starknet::compile::compile_path;
    use sierra_emu::{starknet::StubSyscallHandler, ContractExecutionResult, VirtualMachine};

    #[test]
    fn test_contract() {
        let path = Path::new("programs/hello_starknet.cairo");

        let contract = compile_path(
            path,
            None,
            CompilerConfig {
                replace_ids: true,
                ..Default::default()
            },
            InliningStrategy::Default,
        )
        .unwrap();

        let extracted = contract.extract_sierra_program(false).unwrap();

        let entry_point = contract.entry_points_by_type.external.first().unwrap();

        let mut vm = VirtualMachine::new_starknet(
            extracted.program.clone().into(),
            &contract.entry_points_by_type,
            extracted.sierra_version,
        );

        let calldata = [2.into()];
        let initial_gas = 1000000;

        let syscall_handler = &mut StubSyscallHandler::default();

        // Set the VM at the contract entrypoint
        vm.call_contract(
            entry_point.selector.clone().into(),
            initial_gas,
            calldata,
            None,
        );

        // Run all the steps generating a program execution trace. (Not to be confused with a proof trace)
        let _trace = vm.run_with_trace(syscall_handler);

        // let trace_str = serde_json::to_string_pretty(&trace).unwrap();
        // std::fs::write("contract_trace.json", trace_str).unwrap();
    }

    #[test]
    fn test_contract_constructor() {
        let path = Path::new("programs/hello_starknet.cairo");

        let contract = compile_path(
            path,
            None,
            CompilerConfig {
                replace_ids: true,
                ..Default::default()
            },
            InliningStrategy::Default,
        )
        .unwrap();

        let extracted = contract.extract_sierra_program(false).unwrap();

        let entry_point = contract.entry_points_by_type.constructor.first().unwrap();

        let mut vm = VirtualMachine::new_starknet(
            extracted.program.clone().into(),
            &contract.entry_points_by_type,
            extracted.sierra_version,
        );

        let calldata = [2.into()];
        let initial_gas = 1000000;

        let syscall_handler = &mut StubSyscallHandler::default();
        vm.call_contract(
            entry_point.selector.clone().into(),
            initial_gas,
            calldata,
            None,
        );

        let trace = vm.run_with_trace(syscall_handler);

        assert!(!syscall_handler.storage.is_empty());

        let result = ContractExecutionResult::from_trace(&trace).unwrap();
        assert!(!result.failure_flag);
        assert_eq!(result.return_values.len(), 0);
        assert_eq!(result.error_msg, None);

        // let trace_str = serde_json::to_string_pretty(&trace).unwrap();
        // std::fs::write("contract_trace.json", trace_str).unwrap();
    }
}
