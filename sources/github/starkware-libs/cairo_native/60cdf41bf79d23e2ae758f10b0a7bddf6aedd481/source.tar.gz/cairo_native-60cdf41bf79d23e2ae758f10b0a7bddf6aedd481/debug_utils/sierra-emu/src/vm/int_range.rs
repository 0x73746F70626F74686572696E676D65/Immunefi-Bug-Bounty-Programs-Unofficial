use cairo_lang_sierra::{
    extensions::{
        core::{CoreLibfunc, CoreType, CoreTypeConcrete},
        lib_func::SignatureOnlyConcreteLibfunc,
        range::IntRangeConcreteLibfunc,
        ConcreteLibfunc,
    },
    program_registry::ProgramRegistry,
};
use num_bigint::BigInt;
use smallvec::smallvec;

use crate::{
    utils::{get_numeric_args_as_bigints, get_value_from_integer},
    Value,
};

use super::EvalAction;

pub fn eval(
    registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    selector: &IntRangeConcreteLibfunc,
    args: Vec<Value>,
) -> EvalAction {
    match selector {
        IntRangeConcreteLibfunc::TryNew(info) => eval_try_new(registry, info, args),
        IntRangeConcreteLibfunc::PopFront(info) => eval_pop_front(registry, info, args),
    }
}

fn eval_try_new(
    registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    info: &SignatureOnlyConcreteLibfunc,
    args: Vec<Value>,
) -> EvalAction {
    let range_check @ Value::Unit: Value = args[0].clone() else {
        panic!()
    };
    let [x, y]: [BigInt; 2] = get_numeric_args_as_bigints(&args[1..]).try_into().unwrap();

    let int_ty_id = &info.param_signatures()[1].ty;

    // if x >= y then the range is not valid and we return [y, y) (empty range)
    if x < y {
        let x = get_value_from_integer(registry, int_ty_id, x);
        let y = get_value_from_integer(registry, int_ty_id, y);
        EvalAction::NormalBranch(
            0,
            smallvec![
                range_check,
                Value::IntRange {
                    x: Box::new(x),
                    y: Box::new(y),
                }
            ],
        )
    } else {
        let y = get_value_from_integer(registry, int_ty_id, y);
        EvalAction::NormalBranch(
            1,
            smallvec![
                range_check,
                Value::IntRange {
                    x: Box::new(y.clone()),
                    y: Box::new(y),
                }
            ],
        )
    }
}

fn eval_pop_front(
    registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    info: &SignatureOnlyConcreteLibfunc,
    args: Vec<Value>,
) -> EvalAction {
    let [Value::IntRange { x, y }]: [Value; 1] = args.try_into().unwrap() else {
        panic!()
    };
    let [x, y]: [BigInt; 2] = get_numeric_args_as_bigints(&[*x, *y]).try_into().unwrap();
    let int_ty_id = match registry.get_type(&info.param_signatures()[0].ty).unwrap() {
        CoreTypeConcrete::IntRange(info) => &info.ty,
        _ => panic!(),
    };

    if x < y {
        let x_plus_1 = get_value_from_integer(registry, int_ty_id, &x + 1);
        let x = get_value_from_integer(registry, int_ty_id, x);
        let y = get_value_from_integer(registry, int_ty_id, y);
        EvalAction::NormalBranch(
            1,
            smallvec![
                Value::IntRange {
                    x: Box::new(x_plus_1),
                    y: Box::new(y)
                },
                x
            ],
        )
    } else {
        EvalAction::NormalBranch(0, smallvec![])
    }
}
