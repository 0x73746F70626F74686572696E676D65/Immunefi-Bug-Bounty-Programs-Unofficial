//! # `u256`-related libfuncs

use super::{increment_builtin_counter_by, LibfuncHelper};
use crate::{
    error::Result,
    metadata::{
        runtime_bindings::{ExtendedEuclideanWidth, RuntimeBindingsMeta},
        MetadataStorage,
    },
    utils::ProgramRegistryExt,
};
use cairo_lang_sierra::{
    extensions::{
        core::{CoreLibfunc, CoreType},
        int::unsigned256::Uint256Concrete,
        lib_func::SignatureOnlyConcreteLibfunc,
        ConcreteLibfunc,
    },
    program_registry::ProgramRegistry,
};
use melior::{
    dialect::{
        arith::{self, CmpiPredicate},
        cf, llvm,
    },
    helpers::{BuiltinBlockExt, LlvmBlockExt},
    ir::{
        attribute::{DenseI64ArrayAttribute, IntegerAttribute},
        r#type::IntegerType,
        Block, BlockLike, Location, Value,
    },
    Context,
};

/// Select and call the correct libfunc builder function from the selector.
pub fn build<'ctx, 'this>(
    context: &'ctx Context,
    registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    entry: &'this Block<'ctx>,
    location: Location<'ctx>,
    helper: &LibfuncHelper<'ctx, 'this>,
    metadata: &mut MetadataStorage,
    selector: &Uint256Concrete,
) -> Result<()> {
    match selector {
        Uint256Concrete::Divmod(info) => {
            build_divmod(context, registry, entry, location, helper, metadata, info)
        }
        Uint256Concrete::IsZero(info) => {
            build_is_zero(context, registry, entry, location, helper, metadata, info)
        }
        Uint256Concrete::SquareRoot(info) => {
            build_square_root(context, registry, entry, location, helper, metadata, info)
        }
        Uint256Concrete::InvModN(info) => build_u256_guarantee_inv_mod_n(
            context, registry, entry, location, helper, metadata, info,
        ),
    }
}

/// Generate MLIR operations for the `u256_safe_divmod` libfunc.
pub fn build_divmod<'ctx, 'this>(
    context: &'ctx Context,
    registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    entry: &'this Block<'ctx>,
    location: Location<'ctx>,
    helper: &LibfuncHelper<'ctx, 'this>,
    metadata: &mut MetadataStorage,
    info: &SignatureOnlyConcreteLibfunc,
) -> Result<()> {
    // The sierra-to-casm compiler uses the range check builtin a total of 6 times.
    // https://github.com/starkware-libs/cairo/blob/v2.12.0-dev.1/crates/cairo-lang-sierra-to-casm/src/invocations/int/unsigned256.rs?plain=1#L47
    let range_check =
        super::increment_builtin_counter_by(context, entry, location, entry.arg(0)?, 6)?;

    let i128_ty = IntegerType::new(context, 128).into();
    let i256_ty = IntegerType::new(context, 256).into();

    let guarantee_type = registry.build_type(
        context,
        helper,
        metadata,
        info.output_types().next().unwrap().nth(3).unwrap(),
    )?;

    let lhs_struct: Value = entry.arg(1)?;
    let rhs_struct: Value = entry.arg(2)?;

    let lhs_lo = entry
        .append_operation(llvm::extract_value(
            context,
            lhs_struct,
            DenseI64ArrayAttribute::new(context, &[0]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let lhs_hi = entry
        .append_operation(llvm::extract_value(
            context,
            lhs_struct,
            DenseI64ArrayAttribute::new(context, &[1]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let rhs_lo = entry
        .append_operation(llvm::extract_value(
            context,
            rhs_struct,
            DenseI64ArrayAttribute::new(context, &[0]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let rhs_hi = entry
        .append_operation(llvm::extract_value(
            context,
            rhs_struct,
            DenseI64ArrayAttribute::new(context, &[1]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();

    let lhs_lo = entry
        .append_operation(arith::extui(lhs_lo, i256_ty, location))
        .result(0)?
        .into();
    let lhs_hi = entry
        .append_operation(arith::extui(lhs_hi, i256_ty, location))
        .result(0)?
        .into();
    let rhs_lo = entry
        .append_operation(arith::extui(rhs_lo, i256_ty, location))
        .result(0)?
        .into();
    let rhs_hi = entry
        .append_operation(arith::extui(rhs_hi, i256_ty, location))
        .result(0)?
        .into();

    let k128 = entry
        .append_operation(arith::constant(
            context,
            IntegerAttribute::new(i256_ty, 128).into(),
            location,
        ))
        .result(0)?
        .into();
    let lhs_hi = entry
        .append_operation(arith::shli(lhs_hi, k128, location))
        .result(0)?
        .into();
    let rhs_hi = entry
        .append_operation(arith::shli(rhs_hi, k128, location))
        .result(0)?
        .into();

    let lhs = entry
        .append_operation(arith::ori(lhs_hi, lhs_lo, location))
        .result(0)?
        .into();
    let rhs = entry
        .append_operation(arith::ori(rhs_hi, rhs_lo, location))
        .result(0)?
        .into();

    let result_div = entry
        .append_operation(arith::divui(lhs, rhs, location))
        .result(0)?
        .into();
    let result_rem = entry
        .append_operation(arith::remui(lhs, rhs, location))
        .result(0)?
        .into();

    let result_div_lo = entry
        .append_operation(arith::trunci(result_div, i128_ty, location))
        .result(0)?
        .into();
    let result_div_hi = entry
        .append_operation(arith::shrui(result_div, k128, location))
        .result(0)?
        .into();
    let result_div_hi = entry
        .append_operation(arith::trunci(result_div_hi, i128_ty, location))
        .result(0)?
        .into();

    let result_rem_lo = entry
        .append_operation(arith::trunci(result_rem, i128_ty, location))
        .result(0)?
        .into();
    let result_rem_hi = entry
        .append_operation(arith::shrui(result_rem, k128, location))
        .result(0)?
        .into();
    let result_rem_hi = entry
        .append_operation(arith::trunci(result_rem_hi, i128_ty, location))
        .result(0)?
        .into();

    let result_div = entry
        .append_operation(llvm::undef(
            llvm::r#type::r#struct(context, &[i128_ty, i128_ty], false),
            location,
        ))
        .result(0)?
        .into();
    let result_div = entry
        .append_operation(llvm::insert_value(
            context,
            result_div,
            DenseI64ArrayAttribute::new(context, &[0]),
            result_div_lo,
            location,
        ))
        .result(0)?
        .into();
    let result_div = entry
        .append_operation(llvm::insert_value(
            context,
            result_div,
            DenseI64ArrayAttribute::new(context, &[1]),
            result_div_hi,
            location,
        ))
        .result(0)?
        .into();

    let result_rem = entry
        .append_operation(llvm::undef(
            llvm::r#type::r#struct(context, &[i128_ty, i128_ty], false),
            location,
        ))
        .result(0)?
        .into();
    let result_rem = entry
        .append_operation(llvm::insert_value(
            context,
            result_rem,
            DenseI64ArrayAttribute::new(context, &[0]),
            result_rem_lo,
            location,
        ))
        .result(0)?
        .into();
    let result_rem = entry
        .append_operation(llvm::insert_value(
            context,
            result_rem,
            DenseI64ArrayAttribute::new(context, &[1]),
            result_rem_hi,
            location,
        ))
        .result(0)?
        .into();

    let op = entry.append_operation(llvm::undef(guarantee_type, location));
    let guarantee = op.result(0)?.into();

    helper.br(
        entry,
        0,
        &[range_check, result_div, result_rem, guarantee],
        location,
    )
}

/// Generate MLIR operations for the `u256_is_zero` libfunc.
pub fn build_is_zero<'ctx, 'this>(
    context: &'ctx Context,
    _registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    entry: &'this Block<'ctx>,
    location: Location<'ctx>,
    helper: &LibfuncHelper<'ctx, 'this>,
    _metadata: &mut MetadataStorage,
    _info: &SignatureOnlyConcreteLibfunc,
) -> Result<()> {
    let i128_ty = IntegerType::new(context, 128).into();

    let val_struct = entry.arg(0)?;
    let val_lo = entry
        .append_operation(llvm::extract_value(
            context,
            val_struct,
            DenseI64ArrayAttribute::new(context, &[0]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let val_hi = entry
        .append_operation(llvm::extract_value(
            context,
            val_struct,
            DenseI64ArrayAttribute::new(context, &[1]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();

    let k0 = entry
        .append_operation(arith::constant(
            context,
            IntegerAttribute::new(i128_ty, 0).into(),
            location,
        ))
        .result(0)?
        .into();
    let val_lo_is_zero = entry
        .append_operation(arith::cmpi(
            context,
            CmpiPredicate::Eq,
            val_lo,
            k0,
            location,
        ))
        .result(0)?
        .into();
    let val_hi_is_zero = entry
        .append_operation(arith::cmpi(
            context,
            CmpiPredicate::Eq,
            val_hi,
            k0,
            location,
        ))
        .result(0)?
        .into();

    let val_is_zero = entry
        .append_operation(arith::andi(val_lo_is_zero, val_hi_is_zero, location))
        .result(0)?
        .into();

    helper.cond_br(
        context,
        entry,
        val_is_zero,
        [0, 1],
        [&[], &[val_struct]],
        location,
    )
}

/// Generate MLIR operations for the `u256_sqrt` libfunc.
pub fn build_square_root<'ctx, 'this>(
    context: &'ctx Context,
    _registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    entry: &'this Block<'ctx>,
    location: Location<'ctx>,
    helper: &LibfuncHelper<'ctx, 'this>,
    metadata: &mut MetadataStorage,
    _info: &SignatureOnlyConcreteLibfunc,
) -> Result<()> {
    // The sierra-to-casm compiler uses the range check builtin a total of 7 times.
    // https://github.com/starkware-libs/cairo/blob/v2.12.0-dev.1/crates/cairo-lang-sierra-to-casm/src/invocations/int/unsigned256.rs?plain=1#L189
    let range_check =
        super::increment_builtin_counter_by(context, entry, location, entry.arg(0)?, 7)?;

    let i128_ty = IntegerType::new(context, 128).into();

    let arg_struct = entry.arg(1)?;
    let arg_lo = entry
        .append_operation(llvm::extract_value(
            context,
            arg_struct,
            DenseI64ArrayAttribute::new(context, &[0]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let arg_hi = entry
        .append_operation(llvm::extract_value(
            context,
            arg_struct,
            DenseI64ArrayAttribute::new(context, &[1]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();

    // The square root is computed by a Rust runtime function taking the low and
    // high 128-bit limbs; it returns the result already fitting in 128 bits.
    let runtime_bindings = metadata.get_or_insert_with(RuntimeBindingsMeta::default);
    let result = runtime_bindings.u256_square_root(
        context,
        helper.module,
        entry,
        location,
        arg_lo,
        arg_hi,
    )?;

    helper.br(entry, 0, &[range_check, result], location)
}

/// Generate MLIR operations for the `u256_guarantee_inv_mod_n` libfunc.
pub fn build_u256_guarantee_inv_mod_n<'ctx, 'this>(
    context: &'ctx Context,
    registry: &ProgramRegistry<CoreType, CoreLibfunc>,
    entry: &'this Block<'ctx>,
    location: Location<'ctx>,
    helper: &LibfuncHelper<'ctx, 'this>,
    metadata: &mut MetadataStorage,
    info: &SignatureOnlyConcreteLibfunc,
) -> Result<()> {
    let i128_ty = IntegerType::new(context, 128).into();
    let i256_ty = IntegerType::new(context, 256).into();

    let lhs_struct = entry.arg(1)?;
    let lhs_lo = entry
        .append_operation(llvm::extract_value(
            context,
            lhs_struct,
            DenseI64ArrayAttribute::new(context, &[0]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let lhs_hi = entry
        .append_operation(llvm::extract_value(
            context,
            lhs_struct,
            DenseI64ArrayAttribute::new(context, &[1]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();

    let rhs_struct = entry.arg(2)?;
    let rhs_lo = entry
        .append_operation(llvm::extract_value(
            context,
            rhs_struct,
            DenseI64ArrayAttribute::new(context, &[0]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();
    let rhs_hi = entry
        .append_operation(llvm::extract_value(
            context,
            rhs_struct,
            DenseI64ArrayAttribute::new(context, &[1]),
            i128_ty,
            location,
        ))
        .result(0)?
        .into();

    let lhs_lo = entry
        .append_operation(arith::extui(lhs_lo, i256_ty, location))
        .result(0)?
        .into();
    let lhs_hi = entry
        .append_operation(arith::extui(lhs_hi, i256_ty, location))
        .result(0)?
        .into();

    let rhs_lo = entry
        .append_operation(arith::extui(rhs_lo, i256_ty, location))
        .result(0)?
        .into();
    let rhs_hi = entry
        .append_operation(arith::extui(rhs_hi, i256_ty, location))
        .result(0)?
        .into();

    let k128 = entry
        .append_operation(arith::constant(
            context,
            IntegerAttribute::new(i256_ty, 128).into(),
            location,
        ))
        .result(0)?
        .into();
    let lhs_hi = entry
        .append_operation(arith::shli(lhs_hi, k128, location))
        .result(0)?
        .into();
    let rhs_hi = entry
        .append_operation(arith::shli(rhs_hi, k128, location))
        .result(0)?
        .into();

    let lhs = entry
        .append_operation(arith::ori(lhs_hi, lhs_lo, location))
        .result(0)?
        .into();
    let rhs = entry
        .append_operation(arith::ori(rhs_hi, rhs_lo, location))
        .result(0)?
        .into();

    let k0 = entry
        .append_operation(arith::constant(
            context,
            IntegerAttribute::new(i256_ty, 0).into(),
            location,
        ))
        .result(0)?
        .into();
    let k1 = entry
        .append_operation(arith::constant(
            context,
            IntegerAttribute::new(i256_ty, 1).into(),
            location,
        ))
        .result(0)?
        .into();

    // `a` (= lhs) is not constrained to be non-zero by the signature
    // `u256_guarantee_inv_mod_n(a, n: NonZero<u256>)`, and the extended Euclidean loop
    // below divides by the current divisor (initially `a`) on its first iteration, so
    // `a == 0` would be a udiv-by-zero (UB at the LLVM IR level). Since gcd(0, n) = n has
    // no inverse, short-circuit the whole calculation when `a == 0` and branch straight to
    // the "no inverse" output, matching casm_vm's U256InvModN hint. The range check builtin
    // is incremented 7 times on this path, same as the regular not-invertible branch.
    let guarantee_type = registry.build_type(
        context,
        helper,
        metadata,
        info.output_types().next().unwrap().nth(2).unwrap(),
    )?;
    let range_check = entry.arg(0)?;

    // The "no inverse" branch (output index 1) is reached from two places: the `a == 0`
    // short-circuit below and the regular `gcd != 1` exit of the Euclidean loop. The
    // LibfuncHelper reuses the values passed to `br`/`cond_br` directly in the shared
    // landing block, so they must dominate it. We therefore build them here in the entry
    // block (a common dominator of both predecessors): an `undef` guarantee and the range
    // check incremented 7 times.
    let guarantee = entry
        .append_operation(llvm::undef(guarantee_type, location))
        .result(0)?
        .into();
    let range_check_no_inverse =
        increment_builtin_counter_by(context, entry, location, range_check, 7)?;

    let lhs_is_zero = entry
        .append_operation(arith::cmpi(context, CmpiPredicate::Eq, lhs, k0, location))
        .result(0)?
        .into();
    let no_inverse_block = helper.append_block(Block::new(&[]));
    let compute_block = helper.append_block(Block::new(&[]));
    entry.append_operation(cf::cond_br(
        context,
        lhs_is_zero,
        no_inverse_block,
        compute_block,
        &[],
        &[],
        location,
    ));

    helper.br(
        no_inverse_block,
        1,
        &[range_check_no_inverse, guarantee, guarantee],
        location,
    )?;

    // `a != 0`: the inverse may exist, so run the extended Euclidean algorithm. From here
    // on everything is emitted into `compute_block` instead of the original entry block.
    let entry = compute_block;

    // The extended Euclidean algorithm is built as a separate `no_inline` MLIR
    // function (shared with the u31/u252/u384 variants) rather than inlined here.
    // It returns a struct `{ gcd, inv }`, where `inv` is the Bézout coefficient of
    // `lhs` already reduced into `[0, rhs)` — i.e. the modular inverse of `lhs`
    // modulo `rhs` whenever the gcd is 1.
    let runtime_bindings = metadata.get_or_insert_with(RuntimeBindingsMeta::default);
    let egcd_result = runtime_bindings.extended_euclidean_algorithm(
        context,
        helper.module,
        entry,
        location,
        [lhs, rhs],
        ExtendedEuclideanWidth::U256,
    )?;

    let gcd = entry.extract_value(context, location, egcd_result, i256_ty, 0)?;
    let inv = entry.extract_value(context, location, egcd_result, i256_ty, 1)?;

    // `build_egcd_function` reduces the Bézout coefficient into `[0, rhs)` relying on the
    // invariant `|coeff| <= rhs / 2`, which holds for every modulus except `rhs == 1` (where
    // the trivial coefficient `1` is not `< 1`). A final unsigned remainder reduces that case
    // back to `0` (matching the VM, where everything is `0` modulo `1`) and is a no-op otherwise.
    let inv = entry
        .append_operation(arith::remui(inv, rhs, location))
        .result(0)?
        .into();

    let inv_lo = entry
        .append_operation(arith::trunci(inv, i128_ty, location))
        .result(0)?
        .into();
    let inv_hi = entry
        .append_operation(arith::shrui(inv, k128, location))
        .result(0)?
        .into();
    let inv_hi = entry
        .append_operation(arith::trunci(inv_hi, i128_ty, location))
        .result(0)?
        .into();

    let return_ty = registry.build_type(
        context,
        helper,
        metadata,
        info.output_types().next().unwrap().nth(1).unwrap(),
    )?;
    let result_inv = entry
        .append_operation(llvm::undef(return_ty, location))
        .result(0)?
        .into();
    let result_inv = entry
        .append_operation(llvm::insert_value(
            context,
            result_inv,
            DenseI64ArrayAttribute::new(context, &[0]),
            inv_lo,
            location,
        ))
        .result(0)?
        .into();
    let result_inv = entry
        .append_operation(llvm::insert_value(
            context,
            result_inv,
            DenseI64ArrayAttribute::new(context, &[1]),
            inv_hi,
            location,
        ))
        .result(0)?
        .into();

    let lhs_is_invertible = entry
        .append_operation(arith::cmpi(context, CmpiPredicate::Eq, gcd, k1, location))
        .result(0)?
        .into();
    let inv_not_zero = entry
        .append_operation(arith::cmpi(context, CmpiPredicate::Ne, inv, k0, location))
        .result(0)?
        .into();
    let inverse_exists_and_is_not_zero = entry
        .append_operation(arith::andi(lhs_is_invertible, inv_not_zero, location))
        .result(0)?
        .into();

    // The sierra-to-casm compiler uses the range check builtin a total of 9 times if the inverse is
    // not equal to 0 and lhs is invertible. Otherwise it will be used 7 times (handled by
    // `range_check_no_inverse`, computed in the entry block).
    // https://github.com/starkware-libs/cairo/blob/v2.12.0-dev.1/crates/cairo-lang-sierra-to-casm/src/invocations/int/unsigned256.rs#L21
    let range_check_inverse =
        increment_builtin_counter_by(context, entry, location, range_check, 9)?;

    helper.cond_br(
        context,
        entry,
        inverse_exists_and_is_not_zero,
        [0, 1],
        [
            &[
                range_check_inverse,
                result_inv,
                guarantee,
                guarantee,
                guarantee,
                guarantee,
                guarantee,
                guarantee,
                guarantee,
                guarantee,
            ],
            &[range_check_no_inverse, guarantee, guarantee],
        ],
        location,
    )
}

#[cfg(test)]
mod test {
    use crate::{
        jit_enum, jit_panic, jit_struct,
        utils::testing::{get_compiled_program, run_program_assert_output},
        values::Value,
    };
    use num_bigint::BigUint;
    use num_traits::One;
    use starknet_types_core::felt::Felt;
    use std::ops::Shl;

    fn u256(value: BigUint) -> Value {
        assert!(value.bits() <= 256);
        jit_struct!(
            Value::Uint128((&value & &u128::MAX.into()).try_into().unwrap()),
            Value::Uint128(((&value >> 128u32) & &u128::MAX.into()).try_into().unwrap()),
        )
    }

    #[test]
    fn u256_is_zero() {
        let program = get_compiled_program("programs/libfuncs/u256_is_zero");
        run_program_assert_output(
            &program,
            "run_test",
            &[u256(0u32.into())],
            jit_enum!(1, jit_struct!()),
        );
        run_program_assert_output(
            &program,
            "run_test",
            &[u256(1u32.into())],
            jit_enum!(0, jit_struct!()),
        );
        run_program_assert_output(
            &program,
            "run_test",
            &[u256(BigUint::one() << 128u32)],
            jit_enum!(0, jit_struct!()),
        );
        run_program_assert_output(
            &program,
            "run_test",
            &[u256((BigUint::one() << 128u32) + 1u32)],
            jit_enum!(0, jit_struct!()),
        );
    }

    #[test]
    fn u256_safe_divmod() {
        let program = get_compiled_program("programs/libfuncs/u256_safe_divmod");
        #[track_caller]
        fn run(
            program: &(String, cairo_lang_sierra::program::Program),
            lhs: (u128, u128),
            rhs: (u128, u128),
            result: Value,
        ) {
            run_program_assert_output(
                program,
                "run_test",
                &[
                    jit_struct!(lhs.1.into(), lhs.0.into()),
                    jit_struct!(rhs.1.into(), rhs.0.into()),
                ],
                result,
            )
        }

        let u256_is_zero = Felt::from_bytes_be_slice(b"Division by 0");
        let max_value = 0xFFFFFFFF_FFFFFFFF_FFFFFFFF_FFFFFFFFu128;

        run(&program, (0, 0), (0, 0), jit_panic!(u256_is_zero));
        run(
            &program,
            (0, 0),
            (0, 1),
            jit_enum!(
                0,
                jit_struct!(jit_struct!(
                    jit_struct!(0u128.into(), 0u128.into()),
                    jit_struct!(0u128.into(), 0u128.into()),
                ))
            ),
        );
        run(
            &program,
            (0, 0),
            (max_value, max_value),
            jit_enum!(
                0,
                jit_struct!(jit_struct!(
                    jit_struct!(0u128.into(), 0u128.into()),
                    jit_struct!(0u128.into(), 0u128.into()),
                ))
            ),
        );

        run(&program, (0, 1), (0, 0), jit_panic!(u256_is_zero));
        run(
            &program,
            (0, 1),
            (0, 1),
            jit_enum!(
                0,
                jit_struct!(jit_struct!(
                    jit_struct!(1u128.into(), 0u128.into()),
                    jit_struct!(0u128.into(), 0u128.into()),
                ))
            ),
        );
        run(
            &program,
            (0, 1),
            (max_value, max_value),
            jit_enum!(
                0,
                jit_struct!(jit_struct!(
                    jit_struct!(0u128.into(), 0u128.into()),
                    jit_struct!(1u128.into(), 0u128.into()),
                ))
            ),
        );
        run(
            &program,
            (max_value, max_value),
            (0, 0),
            jit_panic!(u256_is_zero),
        );

        run(
            &program,
            (max_value, max_value),
            (0, 1),
            jit_enum!(
                0,
                jit_struct!(jit_struct!(
                    jit_struct!(max_value.into(), max_value.into()),
                    jit_struct!(0u128.into(), 0u128.into()),
                ))
            ),
        );
        run(
            &program,
            (max_value, max_value),
            (max_value, max_value),
            jit_enum!(
                0,
                jit_struct!(jit_struct!(
                    jit_struct!(1u128.into(), 0u128.into()),
                    jit_struct!(0u128.into(), 0u128.into()),
                ))
            ),
        );
    }

    #[test]
    fn u256_sqrt() {
        let program = get_compiled_program("programs/libfuncs/u256_sqrt");
        #[track_caller]
        fn run(
            program: &(String, cairo_lang_sierra::program::Program),
            value: (u128, u128),
            result: Value,
        ) {
            run_program_assert_output(
                program,
                "run_test",
                &[jit_struct!(value.1.into(), value.0.into())],
                result,
            )
        }

        run(&program, (0u128, 0u128), 0u128.into());
        run(&program, (0u128, 1u128), 1u128.into());
        run(&program, (u128::MAX, u128::MAX), u128::MAX.into());

        for i in 0..u128::BITS {
            let x = 1u128 << i;
            let y: u128 = BigUint::from(x)
                .sqrt()
                .try_into()
                .expect("should always fit into a u128");

            run(&program, (0, x), y.into());
        }

        for i in 0..u128::BITS {
            let x = 1u128 << i;
            let y: u128 = BigUint::from(x)
                .shl(128usize)
                .sqrt()
                .try_into()
                .expect("should always fit into a u128");

            run(&program, (x, 0), y.into());
        }
    }

    #[test]
    fn u256_inv_mod_n() {
        let program = get_compiled_program("programs/libfuncs/u256_inv_mod_n");
        #[track_caller]
        fn run(
            program: &(String, cairo_lang_sierra::program::Program),
            a: (u128, u128),
            n: (u128, u128),
            result: Value,
        ) {
            run_program_assert_output(
                program,
                "run_test",
                &[
                    jit_struct!(a.0.into(), a.1.into()),
                    jit_struct!(n.0.into(), n.1.into()),
                ],
                result,
            )
        }

        let none = jit_enum!(1, jit_struct!());

        // Not invertible.
        run(&program, (0, 0), (0, 0), none.clone());
        run(&program, (1, 0), (1, 0), none.clone());
        run(&program, (0, 0), (1, 0), none.clone());
        run(&program, (0, 0), (7, 0), none.clone());
        run(&program, (3, 0), (6, 0), none.clone());
        run(&program, (4, 0), (6, 0), none.clone());
        run(&program, (8, 0), (4, 0), none.clone());
        run(&program, (8, 0), (24, 0), none.clone());
        run(
            &program,
            (
                112713230461650448610759614893138283713,
                311795268193434200766998031144865279193,
            ),
            (
                214442144331145623175443765631916854552,
                85683151001472364977354294776284843870,
            ),
            none.clone(),
        );
        run(
            &program,
            (
                138560372230216185616572678448146427468,
                178030013799389090502578959553486954963,
            ),
            (
                299456334380503763038201670272353657683,
                285941620966047830312853638602560712796,
            ),
            none,
        );

        // Invertible.
        run(
            &program,
            (5, 0),
            (24, 0),
            jit_enum!(0, jit_struct!(5u128.into(), 0u128.into())),
        );
        run(
            &program,
            (29, 0),
            (24, 0),
            jit_enum!(0, jit_struct!(5u128.into(), 0u128.into())),
        );
        run(
            &program,
            (1, 0),
            (24, 0),
            jit_enum!(0, jit_struct!(1u128.into(), 0u128.into())),
        );
        run(
            &program,
            (1, 0),
            (5, 0),
            jit_enum!(0, jit_struct!(1u128.into(), 0u128.into())),
        );
        run(
            &program,
            (2, 0),
            (5, 0),
            jit_enum!(0, jit_struct!(3u128.into(), 0u128.into())),
        );
        // Modulus close to 2^255: the inverse spans the full u256 range, exercising the
        // egcd reduction for large moduli.
        run(
            &program,
            (3, 0),
            (
                0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF67,
                0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF,
            ),
            jit_enum!(
                0,
                jit_struct!(
                    226854911280625642308916404954512140920u128.into(),
                    56713727820156410577229101238628035242u128.into()
                )
            ),
        );
    }
}
