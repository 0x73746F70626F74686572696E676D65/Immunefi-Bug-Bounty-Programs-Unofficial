use anyhow::Context;
use cairo_native::statistics::Statistics;
use std::fs;
use std::path::PathBuf;

use cairo_lang_sierra::program::Program;
use cairo_lang_starknet_classes::compiler_version::VersionId;
use cairo_lang_starknet_classes::contract_class::ContractClass;
use cairo_native::executor::AotContractExecutor;
use clap::Parser;

/// Given a Sierra file (as saved in Starknet's contract tree), extracts the sierra_program from
/// felts into readable Sierra code, compiles it to native, and saves the result to the given output
/// path.
#[derive(Parser, Debug)]
#[clap(version, verbatim_doc_comment)]
struct Args {
    /// The path of the Sierra file to compile.
    path: PathBuf,
    /// Optimization level, Valid: 0, 1, 2, 3. Values higher than 3 are considered as 3.
    #[arg(short = 'O', long, default_value_t = 0)]
    opt_level: u8,
    /// The output file path.
    output: PathBuf,

    #[arg(long)]
    /// Output path for compilation statistics
    stats: Option<PathBuf>,
}

fn main() -> anyhow::Result<()> {
    let args = Args::parse();
    let (contract_class, sierra_program, sierra_version) =
        load_sierra_program_from_file(&args.path)?;

    let mut stats_with_path = args.stats.map(|path| (Statistics::default(), path));
    let stats = stats_with_path.as_mut().map(|v| &mut v.0);

    AotContractExecutor::new_into(
        &sierra_program,
        &contract_class.entry_points_by_type,
        sierra_version,
        args.output.clone(),
        args.opt_level.into(),
        stats,
    )
    .context("Error compiling Sierra program.")?
    .with_context(|| format!("Failed to take lock on path {}", args.output.display()))?;

    if let Some((stats, path)) = stats_with_path {
        fs::write(path.with_extension("json"), serde_json::to_string(&stats)?)?;
    }

    Ok(())
}

/// Given a Sierra file path, loads the contract class from it, extracts the sierra version from the
/// first 3 felts of the compressed sierra_program, and extracts the compressed sierra_program into
/// readable sierra code.
fn load_sierra_program_from_file(
    path: &PathBuf,
) -> anyhow::Result<(ContractClass, Program, VersionId)> {
    let raw_contract_class = std::fs::read_to_string(path).context("Error reading Sierra file.")?;

    let contract_class: ContractClass = serde_json::from_str(&raw_contract_class)
        .context("Error deserializing Sierra file into contract class.")?;

    let extracted = contract_class
        .extract_sierra_program(false)
        .context("Error extracting Sierra program from contract class.")?;

    Ok((
        contract_class.clone(),
        extracted.program,
        extracted.sierra_version,
    ))
}
