use anyhow::anyhow;
use serde_json::json;
use starknet_rs_accounts::{Account, ExecutionEncoding, SingleOwnerAccount};
use starknet_rs_core::types::Felt;

use crate::common::background_devnet::BackgroundDevnet;
use crate::common::constants::{
    CHAIN_ID, PREDEPLOYED_ACCOUNT_ADDRESS, PREDEPLOYED_ACCOUNT_INITIAL_BALANCE,
};
use crate::common::utils::{FeeUnit, get_simple_contract_artifacts};
use crate::{assert_eq_prop, assert_prop};

static DUMMY_ADDRESS: &str = "0x42";
static DUMMY_AMOUNT: u128 = 42;

async fn increase_balance_happy_path(
    address: &str,
    init_amount: u128,
    mint_amount: u128,
    unit: FeeUnit,
) -> Result<(), anyhow::Error> {
    let devnet = BackgroundDevnet::spawn().await.expect("Could not start Devnet");

    let mut resp_body: serde_json::Value = devnet
        .send_custom_rpc(
            "devnet_mint",
            json!({
                "address": address,
                "amount": mint_amount,
                "unit": unit,
            }),
        )
        .await?;

    // tx hash is not constant so we just assert its general form
    let tx_hash_value = resp_body["tx_hash"].take();
    let tx_hash = tx_hash_value
        .as_str()
        .ok_or(anyhow!("failed to parse transaction hash"))?
        .starts_with("0x");
    assert_prop!(tx_hash, "Transaction hash does not start with '0x'")?;

    let final_balance = Felt::from(init_amount) + Felt::from(mint_amount);
    let expected_resp_body = json!({
        "new_balance": final_balance.to_biguint().to_string(),
        "unit": unit,
        "tx_hash": null
    });
    assert_eq_prop!(resp_body, expected_resp_body)?;

    let new_balance =
        devnet.get_balance_latest(&Felt::from_hex_unchecked(address), unit).await.unwrap();
    assert_eq_prop!(final_balance, new_balance)
}

#[tokio::test]
async fn increase_balance_of_undeployed_address_wei() {
    increase_balance_happy_path(DUMMY_ADDRESS, 0, DUMMY_AMOUNT, FeeUnit::Wei).await.unwrap();
}

#[tokio::test]
async fn increase_balance_of_undeployed_address_fri() {
    increase_balance_happy_path(DUMMY_ADDRESS, 0, DUMMY_AMOUNT, FeeUnit::Fri).await.unwrap();
}

#[tokio::test]
async fn increase_balance_of_undeployed_address_unit_not_specified() {
    let devnet = BackgroundDevnet::spawn().await.expect("Could not start Devnet");

    let unit_not_specified = json!({ "address": DUMMY_ADDRESS, "amount": DUMMY_AMOUNT });
    let mut resp_body: serde_json::Value =
        devnet.send_custom_rpc("devnet_mint", unit_not_specified).await.unwrap();

    let tx_hash_value = resp_body["tx_hash"].take();

    // tx hash is not constant so we later just assert its general form
    assert_eq!(
        resp_body,
        json!({
            "new_balance": DUMMY_AMOUNT.to_string(),
            "unit": "FRI",
            "tx_hash": null
        })
    );

    assert!(tx_hash_value.as_str().unwrap().starts_with("0x"));
}

#[tokio::test]
async fn increase_balance_of_predeployed_account() {
    increase_balance_happy_path(
        PREDEPLOYED_ACCOUNT_ADDRESS,
        PREDEPLOYED_ACCOUNT_INITIAL_BALANCE,
        DUMMY_AMOUNT,
        FeeUnit::Wei,
    )
    .await
    .unwrap()
}

#[tokio::test]
async fn increase_balance_of_predeployed_account_u256() {
    increase_balance_happy_path(
        PREDEPLOYED_ACCOUNT_ADDRESS,
        PREDEPLOYED_ACCOUNT_INITIAL_BALANCE,
        u128::MAX,
        FeeUnit::Wei,
    )
    .await
    .unwrap()
}

#[tokio::test]
async fn execute_v3_transaction_with_strk_token() {
    let devnet = BackgroundDevnet::spawn_with_additional_args(&["--initial-balance", "0"])
        .await
        .expect("Could not start Devnet");

    let (signer, account_address) = devnet.get_first_predeployed_account().await;
    let predeployed_account = SingleOwnerAccount::new(
        &devnet.json_rpc_client,
        signer,
        account_address,
        CHAIN_ID,
        ExecutionEncoding::New,
    );

    let (contract_class, casm_hash) = get_simple_contract_artifacts();
    let declare_result = predeployed_account
        .declare_v3(std::sync::Arc::new(contract_class.clone()), casm_hash)
        .send()
        .await;

    assert!(declare_result.is_err());
    // 3. mint some FRI to the account
    // Note: FeeUnit::Fri should be used for STRK tokens in this implementation
    devnet.mint_unit(account_address, 1_000_000_000_000_000_000_000, FeeUnit::Fri).await;

    let fri_balance = devnet.get_balance_latest(&account_address, FeeUnit::Fri).await.unwrap();
    assert!(fri_balance > Felt::ZERO, "FRI balance should be positive after minting");

    let declare_result =
        predeployed_account.declare_v3(std::sync::Arc::new(contract_class), casm_hash).send().await;

    assert!(declare_result.is_ok(), "Declare transaction should succeed after minting FRI tokens");
}

async fn reject_bad_minting_request(json_body: serde_json::Value) {
    let devnet = BackgroundDevnet::spawn().await.unwrap();
    let rpc_error = devnet.send_custom_rpc("devnet_mint", json_body).await.unwrap_err();
    assert_eq!(rpc_error.code, -32602, "Checking status of {rpc_error:?}");
}

#[tokio::test]
async fn reject_unknown_unit() {
    reject_bad_minting_request(json!({
        "address": DUMMY_ADDRESS,
        "amount": DUMMY_AMOUNT,
        "unit": "Satoshi"
    }))
    .await;
}

#[tokio::test]
async fn reject_negative_amount() {
    reject_bad_minting_request(json!({ "address": DUMMY_ADDRESS, "amount": -1 })).await;
}

#[tokio::test]
async fn reject_missing_address() {
    reject_bad_minting_request(json!({ "amount": DUMMY_AMOUNT })).await;
}

#[tokio::test]
async fn reject_missing_amount() {
    reject_bad_minting_request(json!({ "address": DUMMY_ADDRESS })).await;
}

async fn reject_bad_json_rpc_request(devnet: &BackgroundDevnet, body: serde_json::Value) {
    let rpc_error = devnet.send_custom_rpc("devnet_getAccountBalance", body).await.unwrap_err();
    assert_eq!(rpc_error.code, -32602);
}

#[tokio::test]
async fn reject_if_no_params_when_querying() {
    let devnet = BackgroundDevnet::spawn().await.unwrap();
    reject_bad_json_rpc_request(&devnet, json!({})).await;
}

#[tokio::test]
async fn reject_missing_address_when_querying() {
    let devnet = BackgroundDevnet::spawn().await.unwrap();
    reject_bad_json_rpc_request(&devnet, json!({ "unit": "FRI" })).await;
}

#[tokio::test]
async fn reject_invalid_unit_when_querying() {
    let devnet = BackgroundDevnet::spawn().await.unwrap();
    reject_bad_json_rpc_request(&devnet, json!({ "address": "0x1", "unit": "INVALID" })).await;
}

#[tokio::test]
async fn test_overflow_behavior() {
    let devnet = BackgroundDevnet::spawn().await.unwrap();

    // Sending a random too big value to a random address
    let mint_err = devnet
        .send_custom_rpc(
            "devnet_mint",
            serde_json::from_str(r#"{
                "address": "0x1",
                "amount": 72370055773322622139731865630429942408293740416025352524660990004945706024960, 
                "unit": "FRI"
            }"#).unwrap()
        )
        .await
        .unwrap_err();

    // The complete error also contains the tx hash, which cannot be asserted in a stable way.
    assert_eq!(
        (
            mint_err.code,
            mint_err.message,
            mint_err.data.unwrap()["revert_reason"].as_str().unwrap()
        ),
        (
            -1,
            "Minting reverted".into(),
            "The requested minting amount overflows the token contract's total_supply."
        )
    );
}
