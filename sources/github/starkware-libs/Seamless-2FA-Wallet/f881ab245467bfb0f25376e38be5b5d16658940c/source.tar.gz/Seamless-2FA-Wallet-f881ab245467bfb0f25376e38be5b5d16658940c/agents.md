# Agents Design Document

> **Purpose**: This file is the single source of truth for the design, plan, and status
> of the Seamless 2FA Wallet. Every agent (human or AI) working on this repo MUST read
> this file before making changes and MUST update it when the design evolves.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Repo State](#2-repo-state)
3. [Architecture](#3-architecture)
4. [Transaction Flow](#4-transaction-flow)
5. [Whitelist Policy](#5-whitelist-policy)
6. [Signer Roles & Policy Modes](#6-signer-roles--policy-modes)
7. [Pending Transaction Lifecycle](#7-pending-transaction-lifecycle)
8. [Replay Protection](#8-replay-protection)
9. [Open Design Decisions](#9-open-design-decisions)
10. [Prior Agent Recommendations](#10-prior-agent-recommendations)
11. [Implementation Plan](#11-implementation-plan)
12. [Agent Guidelines](#12-agent-guidelines)
13. [Changelog](#13-changelog)

---

## 1. Project Overview

A **Starknet account abstraction contract** that holds funds and enforces a
configurable 2FA policy. The contract supports **asynchronous multisig**: when a
transaction requires multiple signers, the first signer submits the transaction,
the contract stores it, and subsequent signers submit the same transaction
independently until the required threshold is met.

The contract has two operational dimensions:

- **Whitelist policy** — a configurable set of rules that determines which
  transactions are "safe" and can be executed with fewer signatures.
- **Signer policy** — configurable roles that determine which signers can
  authorize which kinds of transactions. Two modes are supported (chosen at
  deployment time).

---

## 2. Repo State

| Path | Status | Description |
|------|--------|-------------|
| `README.md` | Ready | Team-facing project overview |
| `Scarb.toml` | Ready | Scarb 2.13.1, starknet, openzeppelin deps |
| `docs/architecture.md` | Ready | Full technical architecture with diagrams |
| `docs/decisions.md` | Ready | Design decision log (decided, undecided, deferred) |
| `src/lib.cairo` | Scaffold | Declares `account` (missing) and `whitelist` modules |
| `src/whitelist.cairo` | Partial | `BypassRule` struct defined |
| `src/account.cairo` | **Missing** | Core account contract — not yet created |
| `tests/test_contract.cairo` | Template | Default snforge template, not adapted yet |

---

## 3. Architecture

### 3.1 Contract: `TwoFactorAccount`

A single account abstraction contract implementing the Starknet account interface.
It holds funds and gates every outgoing transaction through its signing and
whitelisting policies.

### 3.2 Storage (conceptual)

```
# ── Signer lists ──────────────────────────────────────────────
signers_whitelist : Map<felt252, bool>     # pubkeys allowed for whitelisted txs
signers_full      : Map<felt252, bool>     # pubkeys allowed for any tx
policy_mode       : u8                     # 0 = threshold mode, 1 = role mode

# ── Whitelist rules ───────────────────────────────────────────
whitelist_rules   : Map<u64, WhitelistRule>
rule_count        : u64

# ── Pending transactions ─────────────────────────────────────
pending_sigs      : Map<felt252, Map<felt252, bool>>  # tx_hash -> (pubkey -> signed)
pending_sig_count : Map<felt252, u64>                 # tx_hash -> number of sigs so far
```

### 3.3 High-Level Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    TwoFactorAccount                         │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────────┐ │
│  │ Signer       │  │ Whitelist    │  │ Pending Tx        │ │
│  │ Registry     │  │ Policy       │  │ Store             │ │
│  │              │  │              │  │                   │ │
│  │ • whitelist  │  │ • rules[]    │  │ • tx_hash → sigs  │ │
│  │   signers    │  │ • is_match() │  │ • sig_count       │ │
│  │ • full       │  │              │  │                   │ │
│  │   signers    │  │              │  │                   │ │
│  │ • policy     │  │              │  │                   │ │
│  │   mode       │  │              │  │                   │ │
│  └──────┬───────┘  └──────┬───────┘  └────────┬──────────┘ │
│         │                 │                    │            │
│         └────────┬────────┴────────────────────┘            │
│                  │                                          │
│          ┌───────▼────────┐                                 │
│          │  Transaction   │                                 │
│          │  Router        │                                 │
│          │                │                                 │
│          │  validate()    │                                 │
│          │  execute()     │                                 │
│          │  is_enough_    │                                 │
│          │   signers()    │                                 │
│          └────────────────┘                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. Transaction Flow

This is the core logic of the contract. Every incoming transaction follows the
same path.

### 4.1 Flow Diagram

```
Signer sends Tx
       │
       ▼
┌──────────────┐
│  __validate__ │
│  verify sig   │──── invalid sig ──▶ REJECT
│  of sender    │
└──────┬───────┘
       │ valid sig
       ▼
┌──────────────────┐     yes    ┌──────────────────────────┐
│ Is Tx whitelisted?├──────────▶│ Is sender on the approved│
└──────┬───────────┘            │ list for whitelisted Txs?│
       │ no                     └──────┬───────────────────┘
       │                               │
       │                          yes  │  no
       │                           │   │
       │                           │   ▼
       │                           │  REJECT
       │                           │
       │                           ▼
       │                     ┌──────────┐
       │                     │ EXECUTE  │
       │                     │ immediately│
       │                     └──────────┘
       │
       ▼
┌─────────────────────┐
│ is_enough_signers() │
│ (check pending sigs │
│  + current sig)     │
└──────┬──────────────┘
       │
  yes  │  no
   │   │
   │   ▼
   │  ┌────────────────────────────┐
   │  │ Store sig in pending map   │
   │  │ (tx_hash → signer pubkey)  │
   │  │                            │
   │  │ Emit event:                │
   │  │   TransactionPending {     │
   │  │     tx_hash,               │
   │  │     calldata,              │
   │  │     signer,                │
   │  │     sigs_so_far,           │
   │  │     sigs_required          │
   │  │   }                        │
   │  └────────────────────────────┘
   │
   ▼
┌──────────┐
│ EXECUTE  │
│ the Tx   │
└──────────┘
```

### 4.2 Step-by-Step

1. **Signature validation** — `__validate__` receives the transaction. It verifies
   that the sender's signature is valid against a known public key (any key in
   either signer list).

2. **Whitelist check** — The contract checks the transaction's calls against the
   whitelist rules.

3. **If whitelisted** — The contract verifies the sender is on the approved
   signers list for whitelisted transactions. If yes, execute immediately. If the
   sender is not on that list, reject.

4. **If not whitelisted** — The contract calls `is_enough_signers()`. This
   function looks at how many valid signatures have been collected for this
   specific transaction (including the current one) and compares against the
   required threshold.

5. **If enough signers** — Execute the transaction.

6. **If not enough signers** — Store the current signer's signature in a map
   keyed by the transaction hash. Emit an event containing the **full calldata**
   of the transaction so that other signers can see what they are being asked to
   sign.

7. **Subsequent signers** — Another signer sees the emitted event, reviews the
   transaction, and sends the **exact same transaction** to the contract. The
   contract goes through the identical code path: validate signature, check
   whitelist (still not whitelisted), record signature, call
   `is_enough_signers()`. There is no separate "approve" function — every signer
   uses the same entry point and the contract just counts signatures.

---

## 5. Whitelist Policy

The whitelist is a set of rules. A transaction is considered whitelisted if its
calls match at least one rule. The whitelist policy is **configurable** — rules
can be added and removed by authorized signers.

### 5.1 WhitelistRule (current struct)

```
WhitelistRule {
    to:         ContractAddress,  // target contract (0 = any)
    selector:   felt252,          // function selector (0 = any)
    max_amount: u256,             // amount cap (0 = no cap / unlimited)
}
```

### 5.2 Matching

A call matches a rule when all non-zero fields in the rule match the
corresponding field in the call. Zero-valued fields act as wildcards.

### 5.3 Multicall Policy

If a transaction contains multiple calls (a multicall), **every call** must match
at least one whitelist rule for the transaction to be considered whitelisted. A
single non-matching call makes the entire transaction non-whitelisted.

---

## 6. Signer Roles & Policy Modes

The contract maintains **two signer lists** and supports **two policy modes**,
chosen at deployment.

### 6.1 Signer Lists

| List | Name | Description |
|------|------|-------------|
| **Whitelist signers** | `signers_whitelist` | Can sign whitelisted transactions for immediate execution |
| **Full signers** | `signers_full` | Can sign any transaction (whitelisted or not) |

A key can appear in both lists.

### 6.2 Policy Mode 0: Threshold Mode

This is the **asynchronous multisig** mode described in the transaction flow.

- **Whitelisted Tx**: Any signer from `signers_whitelist` can execute immediately
  with a single signature.
- **Non-whitelisted Tx**: Requires signatures from multiple signers (from either
  list). The first signer proposes, subsequent signers confirm by sending the same
  transaction. `is_enough_signers()` determines the threshold.

```
┌─────────────────────────────────────────────┐
│           THRESHOLD MODE                    │
│                                             │
│  Whitelisted Tx:                            │
│    signers_whitelist member → execute       │
│                                             │
│  Non-whitelisted Tx:                        │
│    any signer proposes                      │
│        ↓                                    │
│    is_enough_signers()?                     │
│        yes → execute                        │
│        no  → store, emit, wait for more     │
│                                             │
│  Threshold draws from BOTH signer lists.    │
└─────────────────────────────────────────────┘
```

### 6.3 Policy Mode 1: Role-Based Mode

This mode creates a hard separation between the two lists:

- **Whitelist signers ("easy signers")** — Can *only* execute whitelisted
  transactions. They cannot propose or approve non-whitelisted transactions.
- **Full signers ("hard signers")** — Can execute *any* transaction with a single
  signature. These are expected to be cold wallets or highly secured keys.

```
┌─────────────────────────────────────────────┐
│           ROLE-BASED MODE                   │
│                                             │
│  Whitelisted Tx:                            │
│    signers_whitelist member → execute       │
│    signers_full member      → execute       │
│                                             │
│  Non-whitelisted Tx:                        │
│    signers_whitelist member → REJECT        │
│    signers_full member      → execute       │
│                                             │
│  No pending transactions needed.            │
│  Full signers are trusted completely.       │
└─────────────────────────────────────────────┘
```

This mode is useful when the "hard signers" are cold wallets that the user is
confident will not be compromised. It simplifies the flow: there is no
asynchronous pending state, just a strict access control split.

### 6.4 Mode Comparison

| Aspect | Mode 0 (Threshold) | Mode 1 (Role-Based) |
|--------|-------------------|---------------------|
| Non-whitelisted Tx | Needs N signers asynchronously | Needs 1 full signer |
| Pending Tx storage | Yes | No |
| Event-driven approval | Yes | No |
| Cold wallet role | Co-approver | Sole authority for unrestricted Txs |
| Trust model | Distributed trust | Full trust in hard signers |

---

## 7. Pending Transaction Lifecycle

> Applies only to **Policy Mode 0 (Threshold Mode)**.

### 7.1 Unified Path

There is no distinction between "proposing" and "approving." Every signer sends
the **exact same transaction** and goes through the **exact same code path**:

1. `__validate__` verifies the sender's signature.
2. The transaction is not whitelisted (otherwise it would have executed already).
3. The contract records the signature: `pending_sigs[tx_hash][signer_pubkey] = true`.
4. The contract calls `is_enough_signers()`.
5. If threshold met → execute the transaction and clean up pending state.
6. If not → emit `TransactionPending` event with full calldata so other signers
   can see it and decide whether to send the same transaction.

The contract does not know or care which signer goes first. It simply counts
valid signatures per tx_hash. The first signer to push it over the threshold
triggers execution.

### 7.2 State Diagram

```
                    ┌──────────┐
                    │          │
    first signer    │ PENDING  │◄─── not enough signers yet
    proposes ──────▶│          │
                    └────┬─────┘
                         │
              another signer sends same Tx
                         │
                         ▼
                  ┌──────────────┐
                  │is_enough_    │
                  │  signers()?  │
                  └──────┬───────┘
                         │
                    yes  │  no
                     │   │
                     │   └──── back to PENDING
                     ▼
                ┌──────────┐
                │ EXECUTED │
                └──────────┘
```

---

## 8. Replay Protection

Replay attacks are prevented by the **nonce** parameter that is part of every
Starknet transaction. The nonce is:

- Included in the transaction hash computation.
- Enforced at the protocol level — a nonce cannot be reused for the same account.

This means:

- A previously signed transaction cannot be re-submitted, because its nonce has
  already been consumed.
- The pending transaction map is keyed by tx_hash, which includes the nonce, so
  each pending entry is unique to a specific transaction instance.
- An attacker cannot take a co-signer's approval for one transaction and apply it
  to a different one — the tx_hash would differ.

---

## 9. Open Design Decisions

These need to be resolved before or during implementation. Update this section
as decisions are made.

### 9.1 Escape Hatch (Guardian / Signer Loss)

**Status: UNDECIDED**

What happens if a signer's key is lost or compromised?

| Option | Pros | Cons |
|--------|------|------|
| Time-locked escape | Recoverable | Compromised key gets a window |
| Social recovery | Flexible | Adds complexity |
| No escape | Simple | Risky |

### 9.2 Calldata Amount Inspection

**Status: UNDECIDED**

How to interpret `max_amount` in whitelist rules — fixed calldata position,
per-selector schema, or defer to v2.

### 9.3 Daily / Rate Limits

**Status: UNDECIDED**

Should whitelist rules support daily spending limits or rate limits?

### 9.4 Session Keys

**Status: DEFERRED**

Temporary scoped keys. Deferred to v2.

### 9.5 Rule Expiry

**Status: UNDECIDED**

Should `WhitelistRule` include an `expiry` timestamp field?

### 9.6 Threshold Configuration (Mode 0)

**Status: UNDECIDED**

What is the threshold for `is_enough_signers()` in threshold mode? Options:

- Fixed at 2-of-N
- Configurable at deployment (K-of-N)
- Configurable per-rule (different thresholds for different tx types)

### 9.7 Pending Tx Expiry / Cancellation

**Status: UNDECIDED**

Can pending transactions expire or be cancelled? If so, by whom and after how
long?

### 9.8 Admin Operations

**Status: UNDECIDED**

How are signer list changes, whitelist rule changes, and policy changes
authorized? These are the most sensitive operations.

---

## 10. Prior Agent Recommendations

> These are suggestions from the initial design session (2026-02-17, Claude).
> They were made against an earlier synchronous-multisig design. Some still apply
> to the current asynchronous design; some may need re-evaluation. They are
> **not decisions** — the project owner should accept, reject, or modify each one.

### 10.1 On Escape Hatch (re: 9.1)

**Recommendation: Time-locked escape.**

A 7-day owner-initiated escape that the guardian can cancel at any time during the
window. Both directions should be supported: either party can escape the other.

### 10.2 On Calldata Amount Inspection (re: 9.2)

**Recommendation: Drop `max_amount` from v1, add it in v2.**

Calldata layout varies per contract/function. Ship v1 with `(to, selector)` only.

### 10.3 On Daily / Rate Limits (re: 9.3)

**Recommendation: Defer to v2.** Gas and complexity cost not justified for MVP.

### 10.4 On Session Keys (re: 9.4)

**Recommendation: Defer to v2**, but keep the rule struct extensible.

### 10.5 On Rule Expiry (re: 9.5)

**Recommendation: Include `expiry: u64` from v1.** Nearly free, high UX value.

### 10.6 On Multicall Tainting

**Recommendation: One non-matching call taints the entire batch.** Only safe default.

### 10.7 On Admin Function Security

**Recommendation:** Admin selectors (add/remove rules, change signers) should
never be whitelistable. A compromised easy-signer must not be able to escalate
their own permissions.

### 10.8 General

- Emit events for every state change.
- Implement SRC-6 (`isValidSignature`) for dapp compatibility.
- Decide on upgradeability and document the stance explicitly.

---

## 11. Implementation Plan

### Phase 1 — Core Account (MVP)

- [ ] Create `src/account.cairo` with storage, constructor, `__validate__`, `__execute__`
- [ ] Signer registry (two lists, policy mode flag)
- [ ] Whitelist matching logic in `src/whitelist.cairo`
- [ ] Whitelisted Tx path: verify signer is on whitelist signers list, execute
- [ ] Non-whitelisted Tx path: `is_enough_signers()` check
- [ ] Pending transaction storage and signature accumulation (unified path — no separate propose/approve)
- [ ] `TransactionPending` event emission with full calldata
- [ ] Both policy modes (threshold + role-based)
- [ ] Unit tests with snforge

### Phase 2 — Hardening

- [ ] Escape hatch mechanism (once 9.1 is resolved)
- [ ] `max_amount` calldata inspection (once 9.2 is resolved)
- [ ] Rule expiry timestamps (once 9.5 is resolved)
- [ ] Pending Tx expiry / cancellation (once 9.7 is resolved)
- [ ] Admin operation authorization (once 9.8 is resolved)
- [ ] Event emission for all state changes
- [ ] Edge case auditing (reentrancy, multicall, nonce races)

### Phase 3 — Extensions

- [ ] Daily / rate limits on whitelist rules
- [ ] Session key support
- [ ] SRC-5 / SRC-6 introspection and signature validation
- [ ] SDK / client-side helpers for monitoring events and submitting approvals

---

## 12. Agent Guidelines

### Before Working

1. Read this entire file.
2. Check [Repo State](#2-repo-state) to understand what exists.
3. Check [Open Design Decisions](#9-open-design-decisions) — do not make unilateral
   decisions on UNDECIDED items without flagging them to the user.

### While Working

1. Keep code consistent with the architecture described here.
2. If you add/remove/modify a module, update [Repo State](#2-repo-state).
3. If you resolve a design decision, update its status to **DECIDED** and record
   the rationale.

### After Working

1. Update the [Changelog](#13-changelog) with a dated summary of what changed.
2. Ensure [Implementation Plan](#11-implementation-plan) checkboxes reflect current
   progress.
3. If new open questions emerged, add them to
   [Open Design Decisions](#9-open-design-decisions).

---

## 13. Changelog

| Date | Agent | Summary |
|------|-------|---------|
| 2026-02-17 | Claude | Initial design document created with synchronous multisig model. |
| 2026-02-17 | Claude | Added agent recommendations section for all open design decisions. |
| 2026-02-17 | Claude | **Major redesign.** Rewrote document to reflect asynchronous multisig model: single-signer proposal → pending storage → event emission → second signer approval. Added two policy modes (threshold vs role-based), pending transaction lifecycle, replay protection section, flow diagrams, component diagram, and state diagram. Moved prior recommendations to section 10. Added new open decisions for threshold config, pending tx expiry, and admin operations. |
| 2026-02-17 | Claude | Created `README.md`, `docs/architecture.md`, and `docs/decisions.md`. README gives team-facing overview. Architecture doc has full technical design with diagrams. Decisions doc is a structured log of all decided (D-001 through D-007), undecided (D-008 through D-014), and deferred (D-015 through D-017) design points. |
| 2026-02-17 | Claude | Added D-008 to `docs/decisions.md`: On-Chain vs Off-Chain Signature Coordination. Documents the Starknet AA constraints (`__validate__` is read-only, nonce consumption, tx_hash divergence) that conflict with the original on-chain pending model. Presents two options (on-chain adapted vs off-chain coordination) with full flow diagrams, tradeoff tables, and impact analysis. Marked D-001, D-002, D-006, D-007 as superseded pending this decision. Renumbered subsequent entries. |
