# Architecture

This document describes the technical architecture of the Seamless 2FA Wallet.

---

## Contract Overview

The system is a single **Starknet account abstraction contract**
(`TwoFactorAccount`) that:

- Holds funds (ETH, ERC-20 tokens, etc.)
- Implements the Starknet account interface (`__validate__`, `__execute__`)
- Gates every outgoing transaction through a configurable signing and
  whitelisting policy

There are no external helper contracts. All logic lives in one deployable unit.

---

## Components

The contract is composed of three internal subsystems:

```
┌─────────────────────────────────────────────────────────────┐
│                    TwoFactorAccount                         │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────────┐ │
│  │ Signer       │  │ Whitelist    │  │ Pending Tx        │ │
│  │ Registry     │  │ Policy       │  │ Store             │ │
│  │              │  │              │  │                   │ │
│  │ • whitelist  │  │ • rules[]    │  │ • tx_hash → sigs  │ │
│  │   signers    │  │ • is_match() │  │ • sig_count       │ │
│  │ • full       │  │              │  │                   │ │
│  │   signers    │  │              │  │                   │ │
│  │ • policy     │  │              │  │                   │ │
│  │   mode       │  │              │  │                   │ │
│  └──────┬───────┘  └──────┬───────┘  └────────┬──────────┘ │
│         │                 │                    │            │
│         └────────┬────────┴────────────────────┘            │
│                  │                                          │
│          ┌───────▼────────┐                                 │
│          │  Transaction   │                                 │
│          │  Router        │                                 │
│          │                │                                 │
│          │  validate()    │                                 │
│          │  execute()     │                                 │
│          │  is_enough_    │                                 │
│          │   signers()    │                                 │
│          └────────────────┘                                 │
└─────────────────────────────────────────────────────────────┘
```

### 1. Signer Registry

Manages two distinct signer lists and a policy mode flag.

| Storage field | Type | Purpose |
|---------------|------|---------|
| `signers_whitelist` | `Map<felt252, bool>` | Public keys authorized for whitelisted transactions |
| `signers_full` | `Map<felt252, bool>` | Public keys authorized for any transaction |
| `policy_mode` | `u8` | `0` = threshold mode, `1` = role-based mode |

A public key may appear in both lists.

### 2. Whitelist Policy

A set of rules that define which transactions are considered "safe" and can
execute with fewer signatures.

| Storage field | Type | Purpose |
|---------------|------|---------|
| `whitelist_rules` | `Map<u64, WhitelistRule>` | Rule ID to rule mapping |
| `rule_count` | `u64` | Auto-incrementing rule ID counter |

**WhitelistRule struct:**

```
WhitelistRule {
    to:         ContractAddress,  // target contract (0 = any)
    selector:   felt252,          // function selector (0 = any)
    max_amount: u256,             // amount cap (0 = unlimited)
}
```

Zero-valued fields act as wildcards. A call matches a rule when every non-zero
field in the rule matches the corresponding field in the call.

**Multicall policy:** If a transaction contains multiple calls, every call must
match at least one rule for the transaction to be considered whitelisted. One
non-matching call makes the entire batch non-whitelisted.

### 3. Pending Transaction Store

Tracks accumulated signatures for non-whitelisted transactions that have not yet
reached the required signer threshold. Only used in threshold mode (mode 0).

| Storage field | Type | Purpose |
|---------------|------|---------|
| `pending_sigs` | `Map<felt252, Map<felt252, bool>>` | `tx_hash → (pubkey → signed)` |
| `pending_sig_count` | `Map<felt252, u64>` | `tx_hash → number of signatures so far` |

---

## Transaction Flow

Every transaction — regardless of who sends it or what it does — follows the
same code path. There is no separate "propose" or "approve" function.

### Flow Diagram

```
Signer sends Tx
       │
       ▼
┌──────────────┐
│  __validate__ │
│  verify sig   │──── invalid sig ──▶ REJECT
│  of sender    │
└──────┬───────┘
       │ valid sig
       ▼
┌──────────────────┐     yes    ┌──────────────────────────┐
│ Is Tx whitelisted?├──────────▶│ Is sender on the approved│
└──────┬───────────┘            │ list for whitelisted Txs?│
       │ no                     └──────┬───────────────────┘
       │                               │
       │                          yes  │  no
       │                           │   │
       │                           │   ▼
       │                           │  REJECT
       │                           │
       │                           ▼
       │                     ┌──────────┐
       │                     │ EXECUTE  │
       │                     │ immediately│
       │                     └──────────┘
       │
       ▼
┌─────────────────────┐
│ is_enough_signers() │
│ (check pending sigs │
│  + current sig)     │
└──────┬──────────────┘
       │
  yes  │  no
   │   │
   │   ▼
   │  ┌────────────────────────────┐
   │  │ Store sig in pending map   │
   │  │ (tx_hash → signer pubkey)  │
   │  │                            │
   │  │ Emit event:                │
   │  │   TransactionPending {     │
   │  │     tx_hash,               │
   │  │     calldata,              │
   │  │     signer,                │
   │  │     sigs_so_far,           │
   │  │     sigs_required          │
   │  │   }                        │
   │  └────────────────────────────┘
   │
   ▼
┌──────────┐
│ EXECUTE  │
│ the Tx   │
└──────────┘
```

### Step-by-Step

1. **Signature validation** — `__validate__` verifies the sender's signature
   against a known public key from either signer list.

2. **Whitelist check** — The contract matches the transaction's calls against
   all whitelist rules.

3. **Whitelisted path** — The sender must be in `signers_whitelist` (or
   `signers_full`). If so, execute immediately. Otherwise reject.

4. **Non-whitelisted path** — The contract records the sender's signature for
   this `tx_hash` and calls `is_enough_signers()`.

5. **Enough signers** — Execute the transaction, clean up pending state.

6. **Not enough signers** — Emit a `TransactionPending` event with the full
   calldata. The transaction is stored, waiting for more signers.

7. **Subsequent signers** — See the event, send the exact same transaction.
   Same code path runs again. Once `is_enough_signers()` passes, it executes.

---

## Policy Modes

### Mode 0: Threshold

```
┌─────────────────────────────────────────────┐
│           THRESHOLD MODE                    │
│                                             │
│  Whitelisted Tx:                            │
│    signers_whitelist member → execute       │
│                                             │
│  Non-whitelisted Tx:                        │
│    any recognized signer sends Tx           │
│        ↓                                    │
│    is_enough_signers()?                     │
│        yes → execute                        │
│        no  → store sig, emit, wait          │
│                                             │
│  Threshold draws from BOTH signer lists.    │
└─────────────────────────────────────────────┘
```

Non-whitelisted transactions accumulate signatures asynchronously. Any signer
from either list can contribute a signature. Execution happens when the count
reaches the configured threshold.

### Mode 1: Role-Based

```
┌─────────────────────────────────────────────┐
│           ROLE-BASED MODE                   │
│                                             │
│  Whitelisted Tx:                            │
│    signers_whitelist member → execute       │
│    signers_full member      → execute       │
│                                             │
│  Non-whitelisted Tx:                        │
│    signers_whitelist member → REJECT        │
│    signers_full member      → execute       │
│                                             │
│  No pending state. No event-driven flow.    │
│  Full signers are trusted completely.       │
└─────────────────────────────────────────────┘
```

A strict access-control split. "Easy signers" are limited to whitelisted
operations. "Hard signers" (expected to be cold wallets) can do anything with a
single signature.

### Comparison

| Aspect | Threshold (Mode 0) | Role-Based (Mode 1) |
|--------|---------------------|----------------------|
| Non-whitelisted Tx | N signers, async | 1 full signer |
| Pending Tx storage | Yes | No |
| Event-driven flow | Yes | No |
| Cold wallet role | Co-approver among many | Sole authority |
| Trust model | Distributed | Full trust in hard signers |

---

## Pending Transaction Lifecycle

> Applies only to threshold mode (mode 0).

### State Diagram

```
                    ┌──────────┐
                    │          │
   signer sends Tx  │ PENDING  │◄─── not enough signers yet
   ────────────────▶│          │
                    └────┬─────┘
                         │
              another signer sends same Tx
              (identical code path)
                         │
                         ▼
                  ┌──────────────┐
                  │is_enough_    │
                  │  signers()?  │
                  └──────┬───────┘
                         │
                    yes  │  no
                     │   │
                     │   └──── back to PENDING
                     ▼
                ┌──────────┐
                │ EXECUTED │
                └──────────┘
```

Every signer goes through the same unified path. The contract stores
`pending_sigs[tx_hash][pubkey] = true` and increments the count. When the count
meets the threshold, execution is triggered by whichever signer pushed it over.

---

## Replay Protection

Starknet transactions include a **nonce** that is:

- Part of the transaction hash computation
- Enforced at the protocol level (cannot reuse a nonce for the same account)

This guarantees:

- A consumed transaction cannot be re-submitted
- Each pending `tx_hash` is unique to a specific transaction instance
- Signatures for one transaction cannot be applied to another

---

## Modules

| Module | File | Responsibility |
|--------|------|----------------|
| `account` | `src/account.cairo` | Contract storage, `__validate__`, `__execute__`, signer registry, `is_enough_signers()`, admin functions |
| `whitelist` | `src/whitelist.cairo` | `WhitelistRule` struct, rule matching logic |

---

## Events

| Event | Emitted When | Payload |
|-------|-------------|---------|
| `TransactionPending` | A non-whitelisted Tx doesn't have enough signers yet | `tx_hash`, full `calldata`, `signer` pubkey, `sigs_so_far`, `sigs_required` |

Additional events for admin operations (rule changes, signer changes) are
planned but not yet specified — see [decisions.md](decisions.md).
