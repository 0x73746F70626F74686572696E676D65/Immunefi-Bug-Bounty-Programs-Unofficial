/// A bypass rule that allows single-signature (owner-only) execution.
///
/// When a transaction's outer call matches a rule, the guardian co-signature
/// is not required. Fields set to zero act as wildcards:
///   - `to == 0`       -> matches any target address
///   - `selector == 0`  -> matches any selector
///   - `max_amount == 0` -> no transfer-amount cap (unlimited)
#[derive(Copy, Drop, Serde, Hash, starknet::Store, PartialEq)]
pub struct BypassRule {
    /// Target contract address (0 = any).
    pub to: starknet::ContractAddress,
    /// Function selector (0 = any).
    pub selector: felt252,
    /// Maximum `amount` field that may appear in calldata (0 = unlimited).
    /// Interpretation is application-specific; for ERC-20 transfers this would
    /// be the token amount.  The wallet checks `calldata[2] <= max_amount`
    /// when `max_amount != 0` and the calldata is long enough.
    pub max_amount: u256,
}
