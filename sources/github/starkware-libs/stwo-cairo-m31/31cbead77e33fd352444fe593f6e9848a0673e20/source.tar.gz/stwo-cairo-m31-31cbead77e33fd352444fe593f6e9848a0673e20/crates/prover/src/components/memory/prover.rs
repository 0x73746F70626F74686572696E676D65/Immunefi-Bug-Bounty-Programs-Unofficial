use itertools::Itertools;
use num_traits::Zero;
use stwo_prover::constraint_framework::logup::LogupTraceGenerator;
use stwo_prover::constraint_framework::Relation;
use stwo_prover::core::backend::simd::column::BaseColumn;
use stwo_prover::core::backend::simd::m31::{PackedBaseField, PackedM31, LOG_N_LANES, N_LANES};
use stwo_prover::core::backend::simd::qm31::{PackedQM31, PackedSecureField};
use stwo_prover::core::backend::simd::SimdBackend;
use stwo_prover::core::backend::{Col, Column};
use stwo_prover::core::fields::m31::{BaseField, M31};
use stwo_prover::core::fields::qm31::QM31;
use stwo_prover::core::pcs::TreeBuilder;
use stwo_prover::core::poly::circle::{CanonicCoset, CircleEvaluation};
use stwo_prover::core::poly::BitReversedOrder;
use stwo_prover::core::vcs::blake2_merkle::Blake2sMerkleChannel;

use super::component::{
    Claim, InteractionClaim, MULTIPLICITY_COLUMN_OFFSET, N_ADDR_AND_VALUE_COLUMNS, N_COLUMNS,
};
use crate::components::memory::MEMORY_ADDRESS_BOUND;
use crate::input::mem::{Memory, MemoryValue};
use crate::relations::MemoryRelation;

#[derive(Debug)]
pub struct ClaimGenerator {
    pub values: Vec<MemoryValue>,
    pub multiplicities: Vec<u32>,
}
impl ClaimGenerator {
    pub fn new(mem: &Memory) -> Self {
        let values = (0..mem.address_to_value_index.len())
            .map(|addr| mem.get(addr as u32))
            .collect_vec();
        let size = values.len();
        let multiplicities = vec![0; size];

        Self {
            values,
            multiplicities,
        }
    }

    pub fn deduce_output(&self, input: PackedM31) -> PackedSecureField {
        let indices = input.to_array().map(|i| usize::try_from(i.0).unwrap());
        PackedSecureField::from_array(indices.map(|i| self.values[i].0))
    }

    pub fn add_inputs(&mut self, memory_index: usize) {
        self.multiplicities[memory_index] += 1;
    }

    pub fn add_inputs_simd(&mut self, inputs: &PackedM31) {
        let memory_ids = inputs.to_array();
        for memory_id in memory_ids {
            self.add_inputs(usize::try_from(memory_id.0).unwrap());
        }
    }

    pub fn write_trace(
        self,
        tree_builder: &mut TreeBuilder<'_, '_, SimdBackend, Blake2sMerkleChannel>,
    ) -> (Claim, InteractionClaimGenerator) {
        let size = self.values.len().next_power_of_two();
        let mut trace = (0..N_COLUMNS)
            .map(|_| Col::<SimdBackend, BaseField>::zeros(size))
            .collect_vec();
        let mut values = self.values;
        let mut mults = self.multiplicities;
        values.resize(size, MemoryValue(QM31::zero()));
        mults.resize(size, 0);
        assert!(size <= MEMORY_ADDRESS_BOUND);
        let packed_values = values
            .into_iter()
            .map(|v| v.0)
            .array_chunks::<N_LANES>()
            .map(PackedQM31::from_array);

        let inc = PackedBaseField::from_array(std::array::from_fn(|i| {
            M31::from_u32_unchecked((i) as u32)
        }));
        for (i, values) in packed_values.enumerate() {
            // TODO(AlonH): Either create a constant column for the addresses and remove it from
            // here or add constraints to the column here.
            trace[0].data[i] =
                PackedM31::broadcast(M31::from_u32_unchecked((i * N_LANES) as u32)) + inc;
            for (j, value) in values.into_packed_m31s().into_iter().enumerate() {
                trace[j + 1].data[i] = value;
            }
        }
        trace[MULTIPLICITY_COLUMN_OFFSET] =
            BaseColumn::from_iter(mults.into_iter().map(BaseField::from_u32_unchecked));
        // Lookup data.
        let ids_and_values: [Vec<PackedM31>; N_ADDR_AND_VALUE_COLUMNS] = trace
            [0..N_ADDR_AND_VALUE_COLUMNS]
            .iter()
            .map(|col| col.data.clone())
            .collect_vec()
            .try_into()
            .unwrap();
        let multiplicities = trace[MULTIPLICITY_COLUMN_OFFSET].data.clone();

        // Extend trace.
        let log_address_bound = size.checked_ilog2().unwrap();
        let domain = CanonicCoset::new(log_address_bound).circle_domain();
        let trace = trace
            .into_iter()
            .map(|eval| CircleEvaluation::<SimdBackend, _, BitReversedOrder>::new(domain, eval))
            .collect_vec();
        tree_builder.extend_evals(trace);

        (
            Claim {
                log_size: log_address_bound,
            },
            InteractionClaimGenerator {
                ids_and_values,
                multiplicities,
            },
        )
    }
}

#[derive(Debug)]
pub struct InteractionClaimGenerator {
    pub ids_and_values: [Vec<PackedM31>; N_ADDR_AND_VALUE_COLUMNS],
    pub multiplicities: Vec<PackedM31>,
}
impl InteractionClaimGenerator {
    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            ids_and_values: std::array::from_fn(|_| Vec::with_capacity(capacity)),
            multiplicities: Vec::with_capacity(capacity),
        }
    }

    pub fn write_interaction_trace(
        &self,
        tree_builder: &mut TreeBuilder<'_, '_, SimdBackend, Blake2sMerkleChannel>,
        lookup_elements: &MemoryRelation,
    ) -> InteractionClaim {
        let log_size = self.ids_and_values[0].len().ilog2() + LOG_N_LANES;
        let mut logup_gen = LogupTraceGenerator::new(log_size);
        let mut col_gen = logup_gen.new_col();

        // Lookup values columns.
        for vec_row in 0..1 << (log_size - LOG_N_LANES) {
            let values: [PackedM31; N_ADDR_AND_VALUE_COLUMNS] =
                std::array::from_fn(|i| self.ids_and_values[i][vec_row]);
            let denom: PackedSecureField = lookup_elements.combine(&values);
            col_gen.write_frac(vec_row, (-self.multiplicities[vec_row]).into(), denom);
        }
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();
        tree_builder.extend_evals(trace);

        InteractionClaim { claimed_sum }
    }
}
