use instructions::Instructions;
use mem::Memory;
use serde::{Deserialize, Serialize};

pub mod instructions;
pub mod mem;
pub mod plain;
pub mod vm_import;

pub const N_REGISTERS: usize = 3;

// Externally provided inputs.
#[derive(Debug)]
pub struct CairoInput {
    pub instructions: Instructions,
    pub memory: Memory,
    pub public_mem_addresses: Vec<u32>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SegmentAddrs {
    pub begin_addr: u32,
    pub end_addr: u32,
}

impl SegmentAddrs {
    pub fn addresses(&self) -> Vec<u32> {
        (self.begin_addr..self.end_addr).collect()
    }
}
