import {
  RevertedTransactionReceiptResponse,
  SuccessfulTransactionReceiptResponse,
} from '../../provider/types/index.type';

// Keep these for backward compatibility
export type TransactionStatusReceiptSets = {
  SUCCEEDED: SuccessfulTransactionReceiptResponse;
  REVERTED: RevertedTransactionReceiptResponse;
  // TODO: there should be no ERROR case in library flow as fetch would throw on error before it could be read by Helper
  ERROR: Error;
};
export type TransactionReceiptStatus = keyof TransactionStatusReceiptSets;

export type TransactionReceiptValue = TransactionStatusReceiptSets[TransactionReceiptStatus];

export type TransactionReceiptCallbacksDefined = {
  [key in TransactionReceiptStatus]: (response: TransactionStatusReceiptSets[key]) => void;
};

export type TransactionReceiptCallbacksDefault = Partial<TransactionReceiptCallbacksDefined> & {
  _: () => void;
};

export type TransactionReceiptCallbacks =
  | TransactionReceiptCallbacksDefined
  | TransactionReceiptCallbacksDefault;

// Transaction receipt types with helpers - clean, consolidated definitions
export type SuccessfulTransactionReceiptResponseHelper = SuccessfulTransactionReceiptResponse & {
  readonly statusReceipt: 'SUCCEEDED';
  readonly value: SuccessfulTransactionReceiptResponse;
  match(callbacks: TransactionReceiptCallbacks): void;
  // @ts-ignore - docs
  isSuccess(): this is SuccessfulTransactionReceiptResponseHelper;
  // @ts-ignore - docs
  isReverted(): this is RevertedTransactionReceiptResponseHelper;
  // @ts-ignore - docs
  isError(): this is ErrorReceiptResponseHelper;
};

export type RevertedTransactionReceiptResponseHelper = RevertedTransactionReceiptResponse & {
  readonly statusReceipt: 'REVERTED';
  readonly value: RevertedTransactionReceiptResponse;
  match(callbacks: TransactionReceiptCallbacks): void;
  // @ts-ignore - docs
  isSuccess(): this is SuccessfulTransactionReceiptResponseHelper;
  // @ts-ignore - docs
  isReverted(): this is RevertedTransactionReceiptResponseHelper;
  // @ts-ignore - docs
  isError(): this is ErrorReceiptResponseHelper;
};

export type ErrorReceiptResponseHelper = {
  readonly statusReceipt: 'ERROR';
  readonly value: Error;
  match(callbacks: TransactionReceiptCallbacks): void;
  // @ts-ignore - docs
  isSuccess(): this is SuccessfulTransactionReceiptResponseHelper;
  // @ts-ignore - docs
  isReverted(): this is RevertedTransactionReceiptResponseHelper;
  // @ts-ignore - docs
  isError(): this is ErrorReceiptResponseHelper;
};

export type GetTransactionReceiptResponse =
  | SuccessfulTransactionReceiptResponseHelper
  | RevertedTransactionReceiptResponseHelper
  | ErrorReceiptResponseHelper;
