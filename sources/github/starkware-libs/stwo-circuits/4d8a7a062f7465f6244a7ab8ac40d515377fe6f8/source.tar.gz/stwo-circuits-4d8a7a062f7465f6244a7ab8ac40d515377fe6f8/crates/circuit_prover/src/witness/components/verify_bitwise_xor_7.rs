#![allow(unused_parens)]
use crate::circuit_air::components::verify_bitwise_xor_7::{
    Claim, InteractionClaim, LOG_SIZE, N_TRACE_COLUMNS,
};
use crate::witness::components::prelude::*;

pub type InputType = [M31; 3];
pub type PackedInputType = [PackedM31; 3];

pub struct ClaimGenerator {
    pub mults: [AtomicMultiplicityColumn; 1],
    input_to_row: HashMap<[M31; 3], usize>,
    preprocessed_trace: Arc<PreProcessedTrace>,
}

impl ClaimGenerator {
    pub fn new(preprocessed_trace: Arc<PreProcessedTrace>) -> Self {
        let mults = from_fn(|_| AtomicMultiplicityColumn::new(1 << LOG_SIZE));
        let column_ids = [
            PreProcessedColumnId { id: "bitwise_xor_7_0".to_owned() },
            PreProcessedColumnId { id: "bitwise_xor_7_1".to_owned() },
            PreProcessedColumnId { id: "bitwise_xor_7_2".to_owned() },
        ];

        Self {
            mults,
            input_to_row: make_input_to_row(&preprocessed_trace, column_ids),
            preprocessed_trace,
        }
    }

    pub fn write_trace(
        self,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let mults = self.mults.into_iter().map(|v| v.into_simd_vec()).collect::<Vec<_>>();

        let (trace, lookup_data) = write_trace_simd(&self.preprocessed_trace, mults);

        (trace, Claim {}, InteractionClaimGenerator { lookup_data })
    }

    pub fn add_input(&self, input: &InputType, relation_index: usize) {
        self.mults[relation_index]
            .increase_at((*self.input_to_row.get(input).unwrap()).try_into().unwrap());
    }

    pub fn add_packed_inputs(&self, packed_inputs: &[PackedInputType], relation_index: usize) {
        packed_inputs.into_par_iter().for_each(|packed_input| {
            packed_input.unpack().into_iter().for_each(|input| {
                self.add_input(&input, relation_index);
            });
        });
    }
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    preprocessed_trace: &PreProcessedTrace,
    mults: Vec<Vec<PackedM31>>,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData) {
    let log_n_packed_rows = LOG_SIZE - LOG_N_LANES;
    let (mut trace, mut lookup_data) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(LOG_SIZE),
            LookupData::uninitialized(log_n_packed_rows),
        )
    };

    let relation_id = PackedM31::broadcast(M31::from(62225763));
    let bitwise_xor_7_0 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "bitwise_xor_7_0".to_owned() });
    let bitwise_xor_7_1 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "bitwise_xor_7_1".to_owned() });
    let bitwise_xor_7_2 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "bitwise_xor_7_2".to_owned() });
    let bitwise_xor_7_0 = pack_preprocessed_column(bitwise_xor_7_0);
    let bitwise_xor_7_1 = pack_preprocessed_column(bitwise_xor_7_1);
    let bitwise_xor_7_2 = pack_preprocessed_column(bitwise_xor_7_2);

    (trace.par_iter_mut(), lookup_data.par_iter_mut()).into_par_iter().enumerate().for_each(
        |(row_index, (row, lookup_data))| {
            let bitwise_xor_7_0 = bitwise_xor_7_0[row_index];
            let bitwise_xor_7_1 = bitwise_xor_7_1[row_index];
            let bitwise_xor_7_2 = bitwise_xor_7_2[row_index];
            *lookup_data.verify_bitwise_xor_7_0 =
                [relation_id, bitwise_xor_7_0, bitwise_xor_7_1, bitwise_xor_7_2];
            let mult = &mults[0];
            let mult_at_row = *mult.get(row_index).unwrap_or(&PackedM31::zero());
            *row[0] = mult_at_row;
            *lookup_data.mults_0 = mult_at_row;
        },
    );

    (trace, lookup_data)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    verify_bitwise_xor_7_0: Vec<[PackedM31; 4]>,
    mults_0: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(LOG_SIZE) };

        // Sum last logup term.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_bitwise_xor_7_0,
            self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values, mults_0)| {
                let denom = common_lookup_elements.combine(values);
                writer.write_frac(-PackedQM31::one() * mults_0, denom);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
