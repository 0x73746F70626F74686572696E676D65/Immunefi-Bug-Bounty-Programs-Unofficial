// This file was created by the AIR team.

use subroutines::bitwise_xor_num_bits_8::BitwiseXorNumBits8;
use subroutines::bitwise_xor_num_bits_8_b::BitwiseXorNumBits8B;
use subroutines::split_16_low_part_size_8::Split16LowPartSize8;

use crate::circuit_air::components::prelude::*;

#[derive(Copy, Clone)]
pub struct XorRot32R16 {}

impl XorRot32R16 {
    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    #[allow(clippy::unused_unit)]
    #[allow(unused_variables)]
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate<E: EvalAtRow>(
        [
            xor_rot_32_r_16_input_limb_0,
            xor_rot_32_r_16_input_limb_1,
            xor_rot_32_r_16_input_limb_2,
            xor_rot_32_r_16_input_limb_3,
        ]: [E::F; 4],
        enabler: E::F,
        ms_8_bits_col0: E::F,
        ms_8_bits_col1: E::F,
        ms_8_bits_col2: E::F,
        ms_8_bits_col3: E::F,
        xor_col4: E::F,
        xor_col5: E::F,
        xor_col6: E::F,
        xor_col7: E::F,
        common_lookup_elements: &relations::CommonLookupElements,
        eval: &mut E,
    ) -> [E::F; 2] {
        let M31_256 = E::F::from(M31::from(256));

        let [split_16_low_part_size_8_output_tmp_6b1a8_1_limb_0] = Split16LowPartSize8::evaluate(
            [xor_rot_32_r_16_input_limb_0.clone()],
            enabler.clone(),
            ms_8_bits_col0.clone(),
            common_lookup_elements,
            eval,
        );
        let [split_16_low_part_size_8_output_tmp_6b1a8_3_limb_0] = Split16LowPartSize8::evaluate(
            [xor_rot_32_r_16_input_limb_1.clone()],
            enabler.clone(),
            ms_8_bits_col1.clone(),
            common_lookup_elements,
            eval,
        );
        let [split_16_low_part_size_8_output_tmp_6b1a8_5_limb_0] = Split16LowPartSize8::evaluate(
            [xor_rot_32_r_16_input_limb_2.clone()],
            enabler.clone(),
            ms_8_bits_col2.clone(),
            common_lookup_elements,
            eval,
        );
        let [split_16_low_part_size_8_output_tmp_6b1a8_7_limb_0] = Split16LowPartSize8::evaluate(
            [xor_rot_32_r_16_input_limb_3.clone()],
            enabler.clone(),
            ms_8_bits_col3.clone(),
            common_lookup_elements,
            eval,
        );
        BitwiseXorNumBits8::evaluate(
            [
                split_16_low_part_size_8_output_tmp_6b1a8_1_limb_0.clone(),
                split_16_low_part_size_8_output_tmp_6b1a8_5_limb_0.clone(),
            ],
            enabler.clone(),
            xor_col4.clone(),
            common_lookup_elements,
            eval,
        );
        BitwiseXorNumBits8::evaluate(
            [ms_8_bits_col0.clone(), ms_8_bits_col2.clone()],
            enabler.clone(),
            xor_col5.clone(),
            common_lookup_elements,
            eval,
        );
        BitwiseXorNumBits8B::evaluate(
            [
                split_16_low_part_size_8_output_tmp_6b1a8_3_limb_0.clone(),
                split_16_low_part_size_8_output_tmp_6b1a8_7_limb_0.clone(),
            ],
            enabler.clone(),
            xor_col6.clone(),
            common_lookup_elements,
            eval,
        );
        BitwiseXorNumBits8B::evaluate(
            [ms_8_bits_col1.clone(), ms_8_bits_col3.clone()],
            enabler.clone(),
            xor_col7.clone(),
            common_lookup_elements,
            eval,
        );
        let xor_rot_16_output_tmp_6b1a8_16_limb_0 =
            eval.add_intermediate((xor_col6.clone() + (xor_col7.clone() * M31_256.clone())));
        let xor_rot_16_output_tmp_6b1a8_16_limb_1 =
            eval.add_intermediate((xor_col4.clone() + (xor_col5.clone() * M31_256.clone())));
        [
            xor_rot_16_output_tmp_6b1a8_16_limb_0.clone(),
            xor_rot_16_output_tmp_6b1a8_16_limb_1.clone(),
        ]
    }
}
