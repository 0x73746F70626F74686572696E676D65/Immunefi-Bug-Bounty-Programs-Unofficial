# STWO Circuits — Circuit-Based STARK Prover & Verifier

STWO Circuits is StarkWare's circuit-based STARK prover and verifier built on top of the
[stwo](https://github.com/starkware-libs/stwo) core proof system. It provides a circuit DSL
for defining arithmetic constraints using gates, generates STARK proofs for Cairo CPU
execution traces, and includes a standalone STARK verifier. The
[stwo-cairo](https://github.com/starkware-libs/stwo-cairo) repo provides the Cairo-specific
prover/verifier that this repo depends on for Cairo AIR definitions and trace handling.
Soundness bugs are catastrophic and irreversible — an accepted invalid proof or
rejected valid proof is a protocol failure with no recovery path.

See the [Circle STARKs paper](https://eprint.iacr.org/2024/278) for the underlying proof system.

## Priority Contract

All agent behavior is governed by this hierarchy. No exception, no override.

1. **SOUNDNESS & SECURITY** — Cryptographic correctness is absolute.
2. **PRODUCTION QUALITY** — All tests pass. All gates hold. No guardrail bypassed.
3. **PERFORMANCE** — Prover performance is a correctness property. Regressions block.

## Stack

| Layer | Technology | Notes |
|-------|-----------|-------|
| Language | Rust nightly-2025-06-23 | See `rust-toolchain.toml` |
| Edition | Rust 2024 | All crates |
| Field | Mersenne31 (M31) prime p = 2^31 - 1 | CM31, QM31 extension tower |
| Proof system | Circle STARKs (via [stwo](https://github.com/starkware-libs/stwo)) | FRI-based, circle group C(F_p) |
| Cairo AIR | [stwo-cairo](https://github.com/starkware-libs/stwo-cairo) | Cairo CPU AIR and prover |
| Hash function | Blake2s | Used in Blake circuit components and Merkle commitments |
| Test runner | cargo test | `circuit-prover` and `stwo` compiled at opt-level 3 in test profile |
| CI | GitHub Actions | See `.github/workflows/ci.yaml` |
| Stable compat | Verifier crates must compile on stable |

## Workspace Structure

```
crates/
  circuits/                        Circuit DSL — gates, variables, context
    src/
      context.rs                   Circuit building context with variable management
      ops.rs                       Arithmetic operations (add, sub, mul, div, guess)
      ivalue.rs                    Field element abstractions (QM31, M31)
      blake.rs                     Blake2s hashing within circuits
      simd.rs                      SIMD vectorization utilities
      eval!() macro                DSL for arithmetic expressions

  circuit_verifier/                [SOUNDNESS-CRITICAL] Circuit constraint definitions
    src/
      components/                  [AIR-GENERATED] constraint evaluators for 15 circuit components (Eq, QM31Ops, Blake*, XOR*, RangeCheck*)
        subroutines/               [AIR-GENERATED] subroutine evaluators

  circuit_common/                  Shared types, preprocessing, circuit parameters
    src/
      CircuitParams               Configuration: trace sizes, blake gates, output addresses
      PreprocessedCircuit          Circuit preprocessing logic
      finalize.rs                  Circuit finalization and validation

  circuit_prover/                  [SOUNDNESS-CRITICAL] STARK proof generation
    src/
      prover.rs                   prove_circuit() — main proving entry point
      circuit_air/                Circuit constraint definitions in rust
        components/               15 circuit components (Eq, QM31Ops, Blake*, XOR*, RangeCheck*)
          subroutines/            Generated subroutine evaluators
      witness/                    Trace and interaction trace generation

  circuit_serialize/               Proof serialization/deserialization

  stark_verifier/                  [SOUNDNESS-CRITICAL] STARK proof verification
    src/
      fri.rs                      [SOUNDNESS-CRITICAL] FRI protocol verification
      oods.rs                     [SOUNDNESS-CRITICAL] Out-of-domain sampling
      merkle.rs                   [SECURITY-CRITICAL] Blake2s Merkle authentication
      statement.rs                Statement trait for verification

  stark_verifier_examples/         Example verifiers and test utilities

  cairo_verifier/                  [SOUNDNESS-CRITICAL] Cairo constraint definitions
    src/
      components/                 [AIR-GENERATED] 50+ opcode/builtin witness generators
        subroutines/              [AIR-GENERATED] subroutine evaluators
      all_components.rs           [AIR-GENERATED] Component registry
      privacy.rs                  Privacy-related circuit logic
      statement.rs                Cairo AIR statement definition
      verify.rs                   Cairo AIR verification entry point

scripts/
  clippy.sh                       Clippy (all features, warnings denied)
  rust_fmt.sh                     Rust formatting

test_data/
  all_opcode_components/           Proof fixture for opcode component tests
  privacy/                         Privacy circuit test data (bootloader, proofs, params)
```

## Auto-Generated Code

Many files in `crates/circuit_prover/src/circuit_air/components/`, `crates/circuit_verifier/src/components/`,
and `crates/cairo_verifier/src/components/` are generated by the
[stwo-air-infra](https://github.com/starkware-libs/stwo-air-infra) repository.
These files are marked with `// This file was created by the AIR team.`
Do not manually modify generated files — changes will be overwritten on next generation.

## Commands

```bash
# Build
cargo build

# Test (circuit-prover and stwo use opt-level 3 in test profile)
cargo test

# Clippy
scripts/clippy.sh

# Format
scripts/rust_fmt.sh --check          # Check only
scripts/rust_fmt.sh                  # Auto-format

# Doc (warnings denied)
RUSTDOCFLAGS="-Dwarnings" cargo doc --document-private-items --no-deps --all-features

# Verifier stable check (STABLE_VERSION in .github/workflows/ci.yaml is the source of truth)
RUSTUP_TOOLCHAIN=<stable> cargo check --workspace \
  --exclude circuit-prover --exclude circuits-stark-verifier-examples

# Unused dependency check
cargo machete
```

### CI Jobs

See `.github/workflows/ci.yaml`. The full list:

- **format** — `scripts/rust_fmt.sh --check`
- **clippy** — `scripts/clippy.sh`
- **doc** — `cargo doc` with `-Dwarnings`
- **run-tests** — `cargo test --release` -- Always run test in release mode
- **verifier-stable** — verifier compiles on stable Rust
- **machete** — detect unused dependencies

## Mathematical Context

This project implements a circuit-based STARK proving system on top of the stwo core library.
The circuit DSL (`circuits` crate) allows defining arithmetic constraints using gates (Add,
Sub, Mul, etc.) which are compiled into an AIR (Algebraic Intermediate Representation). The
prover generates STARK proofs using FRI over the Mersenne31 field with CM31/QM31 extensions.
The verifier independently validates proofs using FRI decommitment, out-of-domain sampling,
and Merkle authentication paths.

The `cairo_verifier` crate integrates with the Cairo CPU AIR from stwo-cairo, enabling
proving and verification of Cairo program execution. This includes privacy-preserving circuit
verification features.

**Key references:**
- [Circle STARKs paper](https://eprint.iacr.org/2024/278)
- [Cairo paper](https://eprint.iacr.org/2021/1063)
- [STWO Whitepaper](https://github.com/starkware-libs/stwo/blob/dev/.agents/papers/llm/Stwo_Whitepaper.llm.md)

## Operation Boundaries

### Forbidden (NEVER do these)

- Modify constraint definitions, field arithmetic, FRI parameters, Fiat-Shamir
  channel, verifier logic, or commitment scheme without human approval
- Disable, bypass, or weaken any test, lint, or CI gate
- Manually edit files marked `// This file was created by the AIR team.`
- Accept a paper-code divergence as "probably fine" without documentation and review
- Reduce security parameters (blowup factor, query count, grinding bits)

### Supervised (state intent, get approval)

Before modifying ANY [SOUNDNESS-CRITICAL] or [SECURITY-CRITICAL] file:

1. Identify the paper section or stwo core component governing the logic
2. State the mathematical invariant the change must preserve
3. State how the change preserves it
4. Identify the test that will verify this
5. Get explicit human approval
6. After the change: verify all tests pass

### Autonomous (proceed freely)

- Read any file
- Add tests
- Fix lint, clippy, formatting
- Add documentation
- Add benchmarks
- Refactor within a module without changing external interface or math behavior

### Merge/Rebase Conflicts in Proof Fixtures

Dispatch a subagent to resolve all merge/rebase conflicts. Proof/fixture files
(`test_data/**/*.bin`, serialized proof JSON like `cairo1_proof.json`) are generated
artifacts, so a merged version is meaningless — the subagent must resolve those by taking
the old (base) version rather than hand-merging. After it returns, ask the user whether to
regenerate; only if yes, regenerate (e.g. with `FIX_PROOF=1`) and let the regression tests
confirm.

## Key Architectural Decisions

1. **Gate-based circuit DSL**: The `circuits` crate provides a builder pattern centered on
   `Context<Value>`, `Var`, and the `Gate` trait. A `Context` holds the circuit structure
   (list of gates) alongside optional concrete `QM31` values for each variable. When `Value`
   is `NoValue` you build just the circuit topology; when `Value` is `QM31` you also
   compute witness values as you go. The `eval!()` macro provides concise inline arithmetic:
   `eval!(ctx, ((a) * (b)) - (c))`.

2. **Gate types and the `Gate` trait**: Every gate implements `Gate` with three methods:
   `check()` (validates the constraint against concrete values), `uses()` (input variables),
   and `yields()` (output variables). The built-in gate types are:
   - **Add / Sub / Mul** — standard field arithmetic, each with two inputs and one output.
   - **PointwiseMul** — component-wise multiplication of the four M31 limbs inside a QM31,
     bypassing extension-field multiplication.
   - **Eq** — equality constraint between two variables. Yields nothing (both inputs are uses).
   - **Blake** — Blake2s hash gate: takes a vector of input words plus a byte-length and
     produces two output QM31 values.
   - **Permutation** — enforces that two variable lists are equal as multi-sets. Used when
     an operation reorders values (e.g., shuffling Blake state words) and the prover needs to
     prove the output is a permutation of the input without fixing the order.
   - **Output** — marks a variable as a public output of the circuit. Uses but does not yield.

3. **Yield / use invariant and `guess()`**: Soundness of the lookup argument requires that
   every variable appears **exactly once** as a yield across all gates. Arithmetic gates
   (Add, Sub, Mul, PointwiseMul) yield their output; Eq and Output yield nothing.
   `guess()` introduces an unconstrained prover-provided variable (used for division witnesses,
   external inputs, constants, etc.). Because guessed variables are not yielded by any gate,
   `finalize_guessed_vars()` adds a trivial `x + 0 = x` gate for each, ensuring the
   single-yield invariant holds. The `check_yields()` method verifies this invariant.
   `check_vars_used()` is a complementary sanity check ensuring no variable is silently
   dropped — every variable must be consumed by at least one gate or explicitly marked unused.

4. **Circuit components**: The `circuit_verifier` and `circuit_prover` crates define components for Eq, QM31Ops,
   Blake (Gate, Round, RoundSigma, G, Output), XOR verification (TripleXor32,
   VerifyBitwiseXor at 4/7/8/9/12 bits), and range checks (RangeCheck15, RangeCheck16) —
   each implementing constraint evaluation and interaction via the logup protocol.

5. **AIR code generation**: Component constraint evaluators and subroutines in `circuit_prover/src/circuit_air/`
   and `cairo_verifier/src/` are generated by stwo-air-infra. Manual edits to generated files will be lost.

6. **Stable Rust compatibility**: All crates except `circuit-prover` and
   `circuits-stark-verifier-examples` must compile on stable Rust (see the Commands
   section for the pinned version). This is enforced by CI.

7. **Optimized test profile**: `circuit-prover` and `stwo` are compiled at opt-level 3 even
   in the test profile to keep Blake-related tests performant.

8. **Circuit finalization and preprocessing**: The `circuit_common` crate bridges the circuit
   DSL and the prover. `finalize_context()` prepares a circuit for proving by hashing all
   constants (via Blake) and adding their hash as public outputs, then padding the Eq, QM31Ops,
   and Blake components to power-of-two sizes (minimum `N_LANES=16`). `add_zk_blinding()`
   injects random values into the QM31Ops and Eq traces to achieve zero-knowledge.
   `PreprocessedCircuit::preprocess_circuit()` then builds the fixed preprocessed trace. 
   The resulting `PreProcessedTrace` and `CircuitParams` are then passed to the
   prover unchanged.

## Key Metrics

The two primary metrics for this project are **prover time** (dominated by witness generation)
and **proof size**.

### Prover Time

Prover time is the wall-clock duration of `prove_circuit()` in `circuit_prover/src/prover.rs`.
The pipeline is:

1. **Witness generation** (`write_trace()` in `circuit_prover/src/witness/trace.rs`) —
   generates base traces for all circuit components. This is heavily parallelized using
   `rayon` and `std::thread::scope`, with SIMD vectorization (N_LANES=16 M31 values per
   register via `portable_simd`). ClaimGenerator initialization spawns parallel threads,
   and trace writing proceeds in multiple `rayon::join` stages.
2. **Interaction trace** (`write_interaction_trace()`) — computes logup interaction traces
   for all components.
3. **STARK proving** (`prove_ex()` from stwo core) — FRI commitment, Merkle tree
   construction, and query generation.

There is currently no built-in timing instrumentation in the codebase. To measure prover
time, wrap `prove_circuit()` calls with `std::time::Instant` or use an external profiler.
Because `circuit-prover` and `stwo` are compiled at opt-level 3 even in the test profile,
test-time measurements approximate release performance.

Performance regressions are treated as blocking issues (see Priority Contract).

### Proof Size

Proof size is measured in `u32` elements (multiply by 4 for bytes). The `ProofInfo` struct
in `stark_verifier/src/proof.rs` computes a full size breakdown from a `ProofConfig` without
needing an actual proof:

```rust
let info = ProofInfo::from_config(&config);
println!("{info}");          // human-readable breakdown
let total_bytes = info.total_bytes();
```

The proof size decomposes into:

| Component | Description | Scaling |
|-----------|-------------|---------|
| `fixed` | Channel salt, 4 roots, nonces | Constant (44 u32s) |
| `claim` | Packed enable bits, log sizes, claimed sums | O(n_components) |
| `oods` | Out-of-domain evaluations | O(n_columns) |
| `fri_commitments` | One hash per FRI layer | O(log(trace_size)) |
| `fri_last_layer` | QM31 coefficients | O(2^log_n_last_layer_coefs) |
| `eval_samples` | M31 samples at queried positions | O(n_columns * n_queries) |
| `eval_auth` | Merkle auth paths for eval domain | O(n_queries * log(eval_domain)) |
| `fri_auth` | Merkle auth paths for FRI layers | O(n_queries * sum(layer_depths)) |
| `fri_witness` | Coset values per FRI fold step | O(n_queries * sum(2^step)) |

The per-query components (`eval_samples`, `eval_auth`, `fri_auth`, `fri_witness`) dominate
for typical configurations. Reducing `n_queries` shrinks the proof but lowers security;
increasing `fold_step` reduces FRI auth path size at the cost of larger FRI witnesses.
