// This file was created by the AIR team.

#![allow(unused_parens)]
use cairo_air::components::blake_round_sigma::{
    Claim, InteractionClaim, LOG_SIZE, N_TRACE_COLUMNS,
};

use crate::witness::prelude::*;

pub type InputType = [M31; 1];
pub type PackedInputType = [PackedM31; 1];

pub struct ClaimGenerator {
    pub mults: [AtomicMultiplicityColumn; 1],
    input_to_row: HashMap<[M31; 1], usize>,
    preprocessed_trace: Arc<PreProcessedTrace>,
}

impl ClaimGenerator {
    pub fn new(preprocessed_trace: Arc<PreProcessedTrace>) -> Self {
        let mults = from_fn(|_| AtomicMultiplicityColumn::new(1 << LOG_SIZE));
        let column_ids = [PreProcessedColumnId { id: "seq_4".to_owned() }];

        Self {
            mults,
            input_to_row: make_input_to_row(&preprocessed_trace, column_ids),
            preprocessed_trace,
        }
    }

    pub fn write_trace(
        self,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let mults = self.mults.into_iter().map(|v| v.into_simd_vec()).collect::<Vec<_>>();

        let (trace, lookup_data) = write_trace_simd(&self.preprocessed_trace, mults);

        (trace, Claim {}, InteractionClaimGenerator { lookup_data })
    }
}

impl AddInputs for ClaimGenerator {
    type PackedInputType = PackedInputType;
    type InputType = InputType;

    fn add_packed_inputs(&self, packed_inputs: &[PackedInputType], relation_index: usize) {
        packed_inputs.into_par_iter().for_each(|packed_input| {
            for input in packed_input.unpack() {
                self.add_input(&input, relation_index);
            }
        });
    }
    fn add_input(&self, input: &InputType, relation_index: usize) {
        self.mults[relation_index]
            .increase_at((*self.input_to_row.get(input).unwrap()).try_into().unwrap());
    }
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    preprocessed_trace: &PreProcessedTrace,
    mults: Vec<Vec<PackedM31>>,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData) {
    let log_n_packed_rows = LOG_SIZE - LOG_N_LANES;
    let (mut trace, mut lookup_data) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(LOG_SIZE),
            LookupData::uninitialized(log_n_packed_rows),
        )
    };

    let M31_1805967942 = PackedM31::broadcast(M31::from(1805967942));
    let seq_4 = preprocessed_trace.get_column(&PreProcessedColumnId { id: "seq_4".to_owned() });
    let blake_sigma_0 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_0".to_owned() });
    let blake_sigma_1 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_1".to_owned() });
    let blake_sigma_2 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_2".to_owned() });
    let blake_sigma_3 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_3".to_owned() });
    let blake_sigma_4 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_4".to_owned() });
    let blake_sigma_5 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_5".to_owned() });
    let blake_sigma_6 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_6".to_owned() });
    let blake_sigma_7 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_7".to_owned() });
    let blake_sigma_8 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_8".to_owned() });
    let blake_sigma_9 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_9".to_owned() });
    let blake_sigma_10 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_10".to_owned() });
    let blake_sigma_11 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_11".to_owned() });
    let blake_sigma_12 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_12".to_owned() });
    let blake_sigma_13 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_13".to_owned() });
    let blake_sigma_14 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_14".to_owned() });
    let blake_sigma_15 =
        preprocessed_trace.get_column(&PreProcessedColumnId { id: "blake_sigma_15".to_owned() });

    (trace.par_iter_mut(), lookup_data.par_iter_mut()).into_par_iter().enumerate().for_each(
        |(row_index, (row, lookup_data))| {
            let seq_4 = seq_4.packed_at(row_index);
            let blake_sigma_0 = blake_sigma_0.packed_at(row_index);
            let blake_sigma_1 = blake_sigma_1.packed_at(row_index);
            let blake_sigma_2 = blake_sigma_2.packed_at(row_index);
            let blake_sigma_3 = blake_sigma_3.packed_at(row_index);
            let blake_sigma_4 = blake_sigma_4.packed_at(row_index);
            let blake_sigma_5 = blake_sigma_5.packed_at(row_index);
            let blake_sigma_6 = blake_sigma_6.packed_at(row_index);
            let blake_sigma_7 = blake_sigma_7.packed_at(row_index);
            let blake_sigma_8 = blake_sigma_8.packed_at(row_index);
            let blake_sigma_9 = blake_sigma_9.packed_at(row_index);
            let blake_sigma_10 = blake_sigma_10.packed_at(row_index);
            let blake_sigma_11 = blake_sigma_11.packed_at(row_index);
            let blake_sigma_12 = blake_sigma_12.packed_at(row_index);
            let blake_sigma_13 = blake_sigma_13.packed_at(row_index);
            let blake_sigma_14 = blake_sigma_14.packed_at(row_index);
            let blake_sigma_15 = blake_sigma_15.packed_at(row_index);
            let multiplicity_0_col0 = *mults[0].get(row_index).unwrap_or(&PackedM31::zero());
            *row[0] = multiplicity_0_col0;
            *lookup_data.blake_round_sigma_0 = [
                M31_1805967942,
                seq_4,
                blake_sigma_0,
                blake_sigma_1,
                blake_sigma_2,
                blake_sigma_3,
                blake_sigma_4,
                blake_sigma_5,
                blake_sigma_6,
                blake_sigma_7,
                blake_sigma_8,
                blake_sigma_9,
                blake_sigma_10,
                blake_sigma_11,
                blake_sigma_12,
                blake_sigma_13,
                blake_sigma_14,
                blake_sigma_15,
            ];
            *lookup_data.mults_0 = multiplicity_0_col0;
        },
    );

    (trace, lookup_data)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    blake_round_sigma_0: Vec<[PackedM31; 18]>,
    mults_0: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(LOG_SIZE) };

        // Sum last logup term.
        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(), &self.lookup_data.blake_round_sigma_0, self.lookup_data.mults_0)
            .into_par_iter()
            .for_each(|(writer, values, mult)| {
                let denom = common_lookup_elements.combine(values);
                writer.write_frac((-mult).into(), denom);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
