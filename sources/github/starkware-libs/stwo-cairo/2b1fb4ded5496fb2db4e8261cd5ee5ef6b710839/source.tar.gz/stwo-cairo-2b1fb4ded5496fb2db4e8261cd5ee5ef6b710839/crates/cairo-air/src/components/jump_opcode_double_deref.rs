// This file was created by the AIR team.

use subroutines::decode_instruction_11364::DecodeInstruction11364;
use subroutines::read_positive_num_bits_29::ReadPositiveNumBits29;

use crate::components::prelude::*;

pub const N_TRACE_COLUMNS: usize = 21;
pub const RELATION_USES_PER_ROW: [RelationUse; 4] = [
    RelationUse { relation_id: "MemoryAddressToId", uses: 2 },
    RelationUse { relation_id: "MemoryIdToBig", uses: 2 },
    RelationUse { relation_id: "Opcodes", uses: 1 },
    RelationUse { relation_id: "VerifyInstruction", uses: 1 },
];

pub struct Eval {
    pub claim: Claim,
    pub common_lookup_elements: relations::CommonLookupElements,
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct Claim {
    pub log_size: u32,
}
impl Claim {
    pub fn log_sizes(&self) -> TreeVec<Vec<u32>> {
        let trace_log_sizes = vec![self.log_size; N_TRACE_COLUMNS];
        let interaction_log_sizes = vec![self.log_size; SECURE_EXTENSION_DEGREE * 4];
        TreeVec::new(vec![trace_log_sizes, interaction_log_sizes])
    }
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct InteractionClaim {
    pub claimed_sum: SecureField,
}

pub type Component = FrameworkComponent<Eval>;

impl FrameworkEval for Eval {
    fn log_size(&self) -> u32 {
        self.claim.log_size
    }

    fn max_constraint_log_degree_bound(&self) -> u32 {
        self.log_size() + 1
    }

    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    fn evaluate<E: EvalAtRow>(&self, mut eval: E) -> E {
        let M31_1 = E::F::from(M31::from(1));
        let M31_134217728 = E::F::from(M31::from(134217728));
        let M31_262144 = E::F::from(M31::from(262144));
        let M31_428564188 = E::F::from(M31::from(428564188));
        let M31_512 = E::F::from(M31::from(512));
        let enabler_col0 = eval.next_trace_mask();
        let input_pc_col1 = eval.next_trace_mask();
        let input_ap_col2 = eval.next_trace_mask();
        let input_fp_col3 = eval.next_trace_mask();
        let offset1_col4 = eval.next_trace_mask();
        let offset2_col5 = eval.next_trace_mask();
        let op0_base_fp_col6 = eval.next_trace_mask();
        let ap_update_add_1_col7 = eval.next_trace_mask();
        let mem0_base_col8 = eval.next_trace_mask();
        let mem1_base_id_col9 = eval.next_trace_mask();
        let mem1_base_limb_0_col10 = eval.next_trace_mask();
        let mem1_base_limb_1_col11 = eval.next_trace_mask();
        let mem1_base_limb_2_col12 = eval.next_trace_mask();
        let mem1_base_limb_3_col13 = eval.next_trace_mask();
        let partial_limb_msb_col14 = eval.next_trace_mask();
        let next_pc_id_col15 = eval.next_trace_mask();
        let next_pc_limb_0_col16 = eval.next_trace_mask();
        let next_pc_limb_1_col17 = eval.next_trace_mask();
        let next_pc_limb_2_col18 = eval.next_trace_mask();
        let next_pc_limb_3_col19 = eval.next_trace_mask();
        let partial_limb_msb_col20 = eval.next_trace_mask();

        // Enabler is a bit.
        eval.add_constraint(((enabler_col0.clone() * enabler_col0.clone()) - enabler_col0.clone()));
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [
            decode_instruction_11364_output_tmp_b5a8f_6_offset1,
            decode_instruction_11364_output_tmp_b5a8f_6_offset2,
        ] = DecodeInstruction11364::evaluate(
            [input_pc_col1.clone()],
            enabler_col0.clone(),
            offset1_col4.clone(),
            offset2_col5.clone(),
            op0_base_fp_col6.clone(),
            ap_update_add_1_col7.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        // mem0_base.
        eval.add_constraint(
            (mem0_base_col8.clone()
                - ((op0_base_fp_col6.clone() * input_fp_col3.clone())
                    + ((M31_1.clone() - op0_base_fp_col6.clone()) * input_ap_col2.clone()))),
        );
        ReadPositiveNumBits29::evaluate(
            [(mem0_base_col8.clone()
                + decode_instruction_11364_output_tmp_b5a8f_6_offset1.clone())],
            enabler_col0.clone(),
            mem1_base_id_col9.clone(),
            mem1_base_limb_0_col10.clone(),
            mem1_base_limb_1_col11.clone(),
            mem1_base_limb_2_col12.clone(),
            mem1_base_limb_3_col13.clone(),
            partial_limb_msb_col14.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        ReadPositiveNumBits29::evaluate(
            [((((mem1_base_limb_0_col10.clone()
                + (mem1_base_limb_1_col11.clone() * M31_512.clone()))
                + (mem1_base_limb_2_col12.clone() * M31_262144.clone()))
                + (mem1_base_limb_3_col13.clone() * M31_134217728.clone()))
                + decode_instruction_11364_output_tmp_b5a8f_6_offset2.clone())],
            enabler_col0.clone(),
            next_pc_id_col15.clone(),
            next_pc_limb_0_col16.clone(),
            next_pc_limb_1_col17.clone(),
            next_pc_limb_2_col18.clone(),
            next_pc_limb_3_col19.clone(),
            partial_limb_msb_col20.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                input_pc_col1.clone(),
                input_ap_col2.clone(),
                input_fp_col3.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                (((next_pc_limb_0_col16.clone()
                    + (next_pc_limb_1_col17.clone() * M31_512.clone()))
                    + (next_pc_limb_2_col18.clone() * M31_262144.clone()))
                    + (next_pc_limb_3_col19.clone() * M31_134217728.clone())),
                (input_ap_col2.clone() + ap_update_add_1_col7.clone()),
                input_fp_col3.clone(),
            ],
        ));

        eval.finalize_logup_in_pairs();
        eval
    }
}

#[cfg(test)]
mod tests {
    use num_traits::Zero;
    use rand::rngs::SmallRng;
    use rand::{Rng, SeedableRng};
    use stwo::core::fields::qm31::QM31;
    use stwo_constraint_framework::expr::ExprEvaluator;

    use super::*;

    #[test]
    fn jump_opcode_double_deref_constraints_regression() {
        let mut rng = SmallRng::seed_from_u64(0);
        let eval = Eval {
            claim: Claim { log_size: 4 },
            common_lookup_elements: relations::CommonLookupElements::dummy(),
        };
        let expr_eval = eval.evaluate(ExprEvaluator::new());
        let assignment = expr_eval.random_assignment();

        let mut sum = QM31::zero();
        for c in expr_eval.constraints {
            sum += c.assign(&assignment) * rng.random::<QM31>();
        }

        constraints_regression_test_values::JUMP_OPCODE_DOUBLE_DEREF.assert_debug_eq(&sum);
    }
}
