// This file was created by the AIR team.

#![allow(unused_parens)]
use cairo_air::components::poseidon_aggregator::{Claim, InteractionClaim, N_TRACE_COLUMNS};

use crate::witness::components::{
    cube_252, memory_id_to_big, poseidon_3_partial_rounds_chain, poseidon_full_round_chain,
    range_check_3_3_3_3_3, range_check_4_4, range_check_4_4_4_4, range_check_252_width_27,
};
use crate::witness::prelude::*;

pub type InputType = ([M31; 3], [M31; 3]);
pub type PackedInputType = ([PackedM31; 3], [PackedM31; 3]);

#[derive(Default)]
pub struct ClaimGenerator {
    pub mults: DashMap<InputType, AtomicU32>,
}

impl ClaimGenerator {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn write_trace(
        self,
        memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
        poseidon_full_round_chain_state: &poseidon_full_round_chain::ClaimGenerator,
        range_check_252_width_27_state: &range_check_252_width_27::ClaimGenerator,
        cube_252_state: &cube_252::ClaimGenerator,
        range_check_3_3_3_3_3_state: &range_check_3_3_3_3_3::ClaimGenerator,
        range_check_4_4_4_4_state: &range_check_4_4_4_4::ClaimGenerator,
        range_check_4_4_state: &range_check_4_4::ClaimGenerator,
        poseidon_3_partial_rounds_chain_state: &poseidon_3_partial_rounds_chain::ClaimGenerator,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let mut inputs_mults = self
            .mults
            .iter()
            .map(|entry| (*entry.key(), M31(entry.value().load(Ordering::Relaxed))))
            .collect::<Vec<_>>();

        inputs_mults.sort_by_key(|(input, _)| input.0);

        let (mut inputs, mut mults) = inputs_mults.into_iter().unzip::<_, _, Vec<_>, Vec<_>>();

        let n_active_rows = inputs.len();
        assert_ne!(n_active_rows, 0);
        let size = std::cmp::max(n_active_rows.next_power_of_two(), N_LANES);
        let log_size = size.ilog2();

        inputs.resize(size, *inputs.first().unwrap());
        mults.resize(size, M31::zero());

        let packed_inputs = pack_values(&inputs);
        let packed_mults = pack_values(&mults);

        let (trace, lookup_data, sub_component_inputs) = write_trace_simd(
            packed_inputs,
            vec![packed_mults],
            memory_id_to_big_state,
            poseidon_full_round_chain_state,
            range_check_252_width_27_state,
            cube_252_state,
            range_check_3_3_3_3_3_state,
            range_check_4_4_4_4_state,
            range_check_4_4_state,
            poseidon_3_partial_rounds_chain_state,
        );
        for inputs in sub_component_inputs.memory_id_to_big {
            add_inputs(memory_id_to_big_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.poseidon_full_round_chain {
            add_inputs(poseidon_full_round_chain_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.range_check_252_width_27 {
            add_inputs(range_check_252_width_27_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.cube_252 {
            add_inputs(cube_252_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.range_check_3_3_3_3_3 {
            add_inputs(range_check_3_3_3_3_3_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.range_check_4_4_4_4 {
            add_inputs(range_check_4_4_4_4_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.range_check_4_4 {
            add_inputs(range_check_4_4_state, &inputs, size, 0);
        }
        for inputs in sub_component_inputs.poseidon_3_partial_rounds_chain {
            add_inputs(poseidon_3_partial_rounds_chain_state, &inputs, size, 0);
        }

        (trace, Claim { log_size }, InteractionClaimGenerator { log_size, lookup_data })
    }
}

impl AddInputs for ClaimGenerator {
    type PackedInputType = PackedInputType;
    type InputType = InputType;

    fn add_packed_inputs(&self, packed_inputs: &[PackedInputType], _relation_index: usize) {
        let merged: HashMap<InputType, u32> = packed_inputs
            .par_iter()
            .flat_map(|p| p.unpack())
            .fold_with(HashMap::new(), |mut local, input| {
                *local.entry(input).or_insert(0) += 1;
                local
            })
            .reduce(HashMap::new, |mut a, b| {
                for (k, v) in b {
                    *a.entry(k).or_insert(0) += v;
                }
                a
            });

        for (k, v) in merged {
            self.mults
                .entry(k)
                .or_insert_with(|| AtomicU32::new(0))
                .fetch_add(v, Ordering::Relaxed);
        }
    }
    fn add_input(&self, input: &InputType, _relation_index: usize) {
        self.mults
            .entry(*input)
            .or_insert_with(|| AtomicU32::new(0))
            .fetch_add(1, Ordering::Relaxed);
    }
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct SubComponentInputs {
    memory_id_to_big: [Vec<memory_id_to_big::PackedInputType>; 6],
    poseidon_full_round_chain: [Vec<poseidon_full_round_chain::PackedInputType>; 8],
    range_check_252_width_27: [Vec<range_check_252_width_27::PackedInputType>; 2],
    cube_252: [Vec<cube_252::PackedInputType>; 2],
    range_check_3_3_3_3_3: [Vec<range_check_3_3_3_3_3::PackedInputType>; 2],
    range_check_4_4_4_4: [Vec<range_check_4_4_4_4::PackedInputType>; 6],
    range_check_4_4: [Vec<range_check_4_4::PackedInputType>; 3],
    poseidon_3_partial_rounds_chain: [Vec<poseidon_3_partial_rounds_chain::PackedInputType>; 27],
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    inputs: Vec<PackedInputType>,
    mults: Vec<Vec<PackedM31>>,
    memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
    poseidon_full_round_chain_state: &poseidon_full_round_chain::ClaimGenerator,
    range_check_252_width_27_state: &range_check_252_width_27::ClaimGenerator,
    cube_252_state: &cube_252::ClaimGenerator,
    range_check_3_3_3_3_3_state: &range_check_3_3_3_3_3::ClaimGenerator,
    range_check_4_4_4_4_state: &range_check_4_4_4_4::ClaimGenerator,
    range_check_4_4_state: &range_check_4_4::ClaimGenerator,
    poseidon_3_partial_rounds_chain_state: &poseidon_3_partial_rounds_chain::ClaimGenerator,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData, SubComponentInputs) {
    let log_n_packed_rows = inputs.len().ilog2();
    let log_size = log_n_packed_rows + LOG_N_LANES;
    let (mut trace, mut lookup_data, mut sub_component_inputs) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(log_size),
            LookupData::uninitialized(log_n_packed_rows),
            SubComponentInputs::uninitialized(log_n_packed_rows),
        )
    };

    let Felt252_0_0_0_0 = PackedFelt252::broadcast(Felt252::from([0, 0, 0, 0]));
    let Felt252_1_0_0_0 = PackedFelt252::broadcast(Felt252::from([1, 0, 0, 0]));
    let Felt252_10310704347937391837_5874215448258336115_2880320859071049537_45350836576946303 =
        PackedFelt252::broadcast(Felt252::from([
            10310704347937391837,
            5874215448258336115,
            2880320859071049537,
            45350836576946303,
        ]));
    let Felt252_10931822301410252833_1475756362763989377_3378552166684303673_348229636055909092 =
        PackedFelt252::broadcast(Felt252::from([
            10931822301410252833,
            1475756362763989377,
            3378552166684303673,
            348229636055909092,
        ]));
    let Felt252_11041071929982523380_7503192613203831446_4943121247101232560_560497091765764140 =
        PackedFelt252::broadcast(Felt252::from([
            11041071929982523380,
            7503192613203831446,
            4943121247101232560,
            560497091765764140,
        ]));
    let Felt252_16477292399064058052_4441744911417641572_18431044672185975386_252894828082060025 =
        PackedFelt252::broadcast(Felt252::from([
            16477292399064058052,
            4441744911417641572,
            18431044672185975386,
            252894828082060025,
        ]));
    let Felt252_2_0_0_0 = PackedFelt252::broadcast(Felt252::from([2, 0, 0, 0]));
    let Felt252_3969818800901670911_10562874008078701503_14906396266795319764_223312371439046257 =
        PackedFelt252::broadcast(Felt252::from([
            3969818800901670911,
            10562874008078701503,
            14906396266795319764,
            223312371439046257,
        ]));
    let Felt252_4_0_0_0 = PackedFelt252::broadcast(Felt252::from([4, 0, 0, 0]));
    let Felt252_8794894655201903369_3219077422080798056_16714934791572408267_262217499501479120 =
        PackedFelt252::broadcast(Felt252::from([
            8794894655201903369,
            3219077422080798056,
            16714934791572408267,
            262217499501479120,
        ]));
    let Felt252_9275160746813554287_16541205595039575623_4169650429605064889_470088886057789987 =
        PackedFelt252::broadcast(Felt252::from([
            9275160746813554287,
            16541205595039575623,
            4169650429605064889,
            470088886057789987,
        ]));
    let M31_0 = PackedM31::broadcast(M31::from(0));
    let M31_1 = PackedM31::broadcast(M31::from(1));
    let M31_10 = PackedM31::broadcast(M31::from(10));
    let M31_102193642 = PackedM31::broadcast(M31::from(102193642));
    let M31_1027333874 = PackedM31::broadcast(M31::from(1027333874));
    let M31_103094260 = PackedM31::broadcast(M31::from(103094260));
    let M31_108487870 = PackedM31::broadcast(M31::from(108487870));
    let M31_1090315331 = PackedM31::broadcast(M31::from(1090315331));
    let M31_11 = PackedM31::broadcast(M31::from(11));
    let M31_112479959 = PackedM31::broadcast(M31::from(112479959));
    let M31_112795138 = PackedM31::broadcast(M31::from(112795138));
    let M31_116986206 = PackedM31::broadcast(M31::from(116986206));
    let M31_117420501 = PackedM31::broadcast(M31::from(117420501));
    let M31_119023582 = PackedM31::broadcast(M31::from(119023582));
    let M31_12 = PackedM31::broadcast(M31::from(12));
    let M31_120369218 = PackedM31::broadcast(M31::from(120369218));
    let M31_121146754 = PackedM31::broadcast(M31::from(121146754));
    let M31_121657377 = PackedM31::broadcast(M31::from(121657377));
    let M31_122233508 = PackedM31::broadcast(M31::from(122233508));
    let M31_129717753 = PackedM31::broadcast(M31::from(129717753));
    let M31_13 = PackedM31::broadcast(M31::from(13));
    let M31_130418270 = PackedM31::broadcast(M31::from(130418270));
    let M31_133303902 = PackedM31::broadcast(M31::from(133303902));
    let M31_134217729 = PackedM31::broadcast(M31::from(134217729));
    let M31_1343313504 = PackedM31::broadcast(M31::from(1343313504));
    let M31_136 = PackedM31::broadcast(M31::from(136));
    let M31_14 = PackedM31::broadcast(M31::from(14));
    let M31_1480369132 = PackedM31::broadcast(M31::from(1480369132));
    let M31_15 = PackedM31::broadcast(M31::from(15));
    let M31_1551892206 = PackedM31::broadcast(M31::from(1551892206));
    let M31_16 = PackedM31::broadcast(M31::from(16));
    let M31_16173996 = PackedM31::broadcast(M31::from(16173996));
    let M31_1651211826 = PackedM31::broadcast(M31::from(1651211826));
    let M31_1662111297 = PackedM31::broadcast(M31::from(1662111297));
    let M31_17 = PackedM31::broadcast(M31::from(17));
    let M31_18 = PackedM31::broadcast(M31::from(18));
    let M31_18765944 = PackedM31::broadcast(M31::from(18765944));
    let M31_19 = PackedM31::broadcast(M31::from(19));
    let M31_19292069 = PackedM31::broadcast(M31::from(19292069));
    let M31_1987997202 = PackedM31::broadcast(M31::from(1987997202));
    let M31_2 = PackedM31::broadcast(M31::from(2));
    let M31_20 = PackedM31::broadcast(M31::from(20));
    let M31_21 = PackedM31::broadcast(M31::from(21));
    let M31_22 = PackedM31::broadcast(M31::from(22));
    let M31_22899501 = PackedM31::broadcast(M31::from(22899501));
    let M31_23 = PackedM31::broadcast(M31::from(23));
    let M31_24 = PackedM31::broadcast(M31::from(24));
    let M31_25 = PackedM31::broadcast(M31::from(25));
    let M31_26 = PackedM31::broadcast(M31::from(26));
    let M31_262144 = PackedM31::broadcast(M31::from(262144));
    let M31_27 = PackedM31::broadcast(M31::from(27));
    let M31_28 = PackedM31::broadcast(M31::from(28));
    let M31_28820206 = PackedM31::broadcast(M31::from(28820206));
    let M31_29 = PackedM31::broadcast(M31::from(29));
    let M31_3 = PackedM31::broadcast(M31::from(3));
    let M31_30 = PackedM31::broadcast(M31::from(30));
    let M31_31 = PackedM31::broadcast(M31::from(31));
    let M31_32 = PackedM31::broadcast(M31::from(32));
    let M31_33 = PackedM31::broadcast(M31::from(33));
    let M31_33413160 = PackedM31::broadcast(M31::from(33413160));
    let M31_33439011 = PackedM31::broadcast(M31::from(33439011));
    let M31_34 = PackedM31::broadcast(M31::from(34));
    let M31_35 = PackedM31::broadcast(M31::from(35));
    let M31_36279186 = PackedM31::broadcast(M31::from(36279186));
    let M31_4 = PackedM31::broadcast(M31::from(4));
    let M31_402653187 = PackedM31::broadcast(M31::from(402653187));
    let M31_40454143 = PackedM31::broadcast(M31::from(40454143));
    let M31_41224388 = PackedM31::broadcast(M31::from(41224388));
    let M31_41320857 = PackedM31::broadcast(M31::from(41320857));
    let M31_44781849 = PackedM31::broadcast(M31::from(44781849));
    let M31_44848225 = PackedM31::broadcast(M31::from(44848225));
    let M31_45351266 = PackedM31::broadcast(M31::from(45351266));
    let M31_45553283 = PackedM31::broadcast(M31::from(45553283));
    let M31_48193339 = PackedM31::broadcast(M31::from(48193339));
    let M31_48383197 = PackedM31::broadcast(M31::from(48383197));
    let M31_4883209 = PackedM31::broadcast(M31::from(4883209));
    let M31_48945103 = PackedM31::broadcast(M31::from(48945103));
    let M31_49157069 = PackedM31::broadcast(M31::from(49157069));
    let M31_49554771 = PackedM31::broadcast(M31::from(49554771));
    let M31_4974792 = PackedM31::broadcast(M31::from(4974792));
    let M31_5 = PackedM31::broadcast(M31::from(5));
    let M31_502259093 = PackedM31::broadcast(M31::from(502259093));
    let M31_50468641 = PackedM31::broadcast(M31::from(50468641));
    let M31_50758155 = PackedM31::broadcast(M31::from(50758155));
    let M31_512 = PackedM31::broadcast(M31::from(512));
    let M31_54415179 = PackedM31::broadcast(M31::from(54415179));
    let M31_55508188 = PackedM31::broadcast(M31::from(55508188));
    let M31_55955004 = PackedM31::broadcast(M31::from(55955004));
    let M31_58475513 = PackedM31::broadcast(M31::from(58475513));
    let M31_59852719 = PackedM31::broadcast(M31::from(59852719));
    let M31_6 = PackedM31::broadcast(M31::from(6));
    let M31_60124463 = PackedM31::broadcast(M31::from(60124463));
    let M31_60709090 = PackedM31::broadcast(M31::from(60709090));
    let M31_62360091 = PackedM31::broadcast(M31::from(62360091));
    let M31_62439890 = PackedM31::broadcast(M31::from(62439890));
    let M31_65659846 = PackedM31::broadcast(M31::from(65659846));
    let M31_68491350 = PackedM31::broadcast(M31::from(68491350));
    let M31_7 = PackedM31::broadcast(M31::from(7));
    let M31_72285071 = PackedM31::broadcast(M31::from(72285071));
    let M31_74972783 = PackedM31::broadcast(M31::from(74972783));
    let M31_75104388 = PackedM31::broadcast(M31::from(75104388));
    let M31_77099918 = PackedM31::broadcast(M31::from(77099918));
    let M31_78826183 = PackedM31::broadcast(M31::from(78826183));
    let M31_79012328 = PackedM31::broadcast(M31::from(79012328));
    let M31_8 = PackedM31::broadcast(M31::from(8));
    let M31_8192 = PackedM31::broadcast(M31::from(8192));
    let M31_86573645 = PackedM31::broadcast(M31::from(86573645));
    let M31_88680813 = PackedM31::broadcast(M31::from(88680813));
    let M31_9 = PackedM31::broadcast(M31::from(9));
    let M31_90391646 = PackedM31::broadcast(M31::from(90391646));
    let M31_90842759 = PackedM31::broadcast(M31::from(90842759));
    let M31_91013252 = PackedM31::broadcast(M31::from(91013252));
    let M31_94624323 = PackedM31::broadcast(M31::from(94624323));
    let M31_95050340 = PackedM31::broadcast(M31::from(95050340));
    let seq = Seq::new(log_size);

    (trace.par_iter_mut(),
    lookup_data.par_iter_mut(),sub_component_inputs.par_iter_mut(),inputs.into_par_iter(),)
    .into_par_iter()
    .enumerate()
    .for_each(
        |(row_index,(row, lookup_data,sub_component_inputs,poseidon_aggregator_input,))| {
            let seq = seq.packed_at(row_index);let multiplicity_0_col0 = *mults[0].get(row_index).unwrap_or(&PackedM31::zero());
            *row[0] = multiplicity_0_col0;let input_limb_0_col1 = poseidon_aggregator_input.0[0];
            *row[1] = input_limb_0_col1;let input_limb_1_col2 = poseidon_aggregator_input.0[1];
            *row[2] = input_limb_1_col2;let input_limb_2_col3 = poseidon_aggregator_input.0[2];
            *row[3] = input_limb_2_col3;let input_limb_3_col4 = poseidon_aggregator_input.1[0];
            *row[4] = input_limb_3_col4;let input_limb_4_col5 = poseidon_aggregator_input.1[1];
            *row[5] = input_limb_4_col5;let input_limb_5_col6 = poseidon_aggregator_input.1[2];
            *row[6] = input_limb_5_col6;

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_3806f_0 = memory_id_to_big_state.deduce_output(input_limb_0_col1);let value_limb_0_col7 = memory_id_to_big_value_tmp_3806f_0.get_m31(0);
            *row[7] = value_limb_0_col7;let value_limb_1_col8 = memory_id_to_big_value_tmp_3806f_0.get_m31(1);
            *row[8] = value_limb_1_col8;let value_limb_2_col9 = memory_id_to_big_value_tmp_3806f_0.get_m31(2);
            *row[9] = value_limb_2_col9;let value_limb_3_col10 = memory_id_to_big_value_tmp_3806f_0.get_m31(3);
            *row[10] = value_limb_3_col10;let value_limb_4_col11 = memory_id_to_big_value_tmp_3806f_0.get_m31(4);
            *row[11] = value_limb_4_col11;let value_limb_5_col12 = memory_id_to_big_value_tmp_3806f_0.get_m31(5);
            *row[12] = value_limb_5_col12;let value_limb_6_col13 = memory_id_to_big_value_tmp_3806f_0.get_m31(6);
            *row[13] = value_limb_6_col13;let value_limb_7_col14 = memory_id_to_big_value_tmp_3806f_0.get_m31(7);
            *row[14] = value_limb_7_col14;let value_limb_8_col15 = memory_id_to_big_value_tmp_3806f_0.get_m31(8);
            *row[15] = value_limb_8_col15;let value_limb_9_col16 = memory_id_to_big_value_tmp_3806f_0.get_m31(9);
            *row[16] = value_limb_9_col16;let value_limb_10_col17 = memory_id_to_big_value_tmp_3806f_0.get_m31(10);
            *row[17] = value_limb_10_col17;let value_limb_11_col18 = memory_id_to_big_value_tmp_3806f_0.get_m31(11);
            *row[18] = value_limb_11_col18;let value_limb_12_col19 = memory_id_to_big_value_tmp_3806f_0.get_m31(12);
            *row[19] = value_limb_12_col19;let value_limb_13_col20 = memory_id_to_big_value_tmp_3806f_0.get_m31(13);
            *row[20] = value_limb_13_col20;let value_limb_14_col21 = memory_id_to_big_value_tmp_3806f_0.get_m31(14);
            *row[21] = value_limb_14_col21;let value_limb_15_col22 = memory_id_to_big_value_tmp_3806f_0.get_m31(15);
            *row[22] = value_limb_15_col22;let value_limb_16_col23 = memory_id_to_big_value_tmp_3806f_0.get_m31(16);
            *row[23] = value_limb_16_col23;let value_limb_17_col24 = memory_id_to_big_value_tmp_3806f_0.get_m31(17);
            *row[24] = value_limb_17_col24;let value_limb_18_col25 = memory_id_to_big_value_tmp_3806f_0.get_m31(18);
            *row[25] = value_limb_18_col25;let value_limb_19_col26 = memory_id_to_big_value_tmp_3806f_0.get_m31(19);
            *row[26] = value_limb_19_col26;let value_limb_20_col27 = memory_id_to_big_value_tmp_3806f_0.get_m31(20);
            *row[27] = value_limb_20_col27;let value_limb_21_col28 = memory_id_to_big_value_tmp_3806f_0.get_m31(21);
            *row[28] = value_limb_21_col28;let value_limb_22_col29 = memory_id_to_big_value_tmp_3806f_0.get_m31(22);
            *row[29] = value_limb_22_col29;let value_limb_23_col30 = memory_id_to_big_value_tmp_3806f_0.get_m31(23);
            *row[30] = value_limb_23_col30;let value_limb_24_col31 = memory_id_to_big_value_tmp_3806f_0.get_m31(24);
            *row[31] = value_limb_24_col31;let value_limb_25_col32 = memory_id_to_big_value_tmp_3806f_0.get_m31(25);
            *row[32] = value_limb_25_col32;let value_limb_26_col33 = memory_id_to_big_value_tmp_3806f_0.get_m31(26);
            *row[33] = value_limb_26_col33;let value_limb_27_col34 = memory_id_to_big_value_tmp_3806f_0.get_m31(27);
            *row[34] = value_limb_27_col34;*sub_component_inputs.memory_id_to_big[0] =
                input_limb_0_col1;
            *lookup_data.memory_id_to_big_0 = [M31_1662111297, input_limb_0_col1, value_limb_0_col7, value_limb_1_col8, value_limb_2_col9, value_limb_3_col10, value_limb_4_col11, value_limb_5_col12, value_limb_6_col13, value_limb_7_col14, value_limb_8_col15, value_limb_9_col16, value_limb_10_col17, value_limb_11_col18, value_limb_12_col19, value_limb_13_col20, value_limb_14_col21, value_limb_15_col22, value_limb_16_col23, value_limb_17_col24, value_limb_18_col25, value_limb_19_col26, value_limb_20_col27, value_limb_21_col28, value_limb_22_col29, value_limb_23_col30, value_limb_24_col31, value_limb_25_col32, value_limb_26_col33, value_limb_27_col34];let read_positive_known_id_num_bits_252_output_tmp_3806f_1 = PackedFelt252::from_limbs([value_limb_0_col7, value_limb_1_col8, value_limb_2_col9, value_limb_3_col10, value_limb_4_col11, value_limb_5_col12, value_limb_6_col13, value_limb_7_col14, value_limb_8_col15, value_limb_9_col16, value_limb_10_col17, value_limb_11_col18, value_limb_12_col19, value_limb_13_col20, value_limb_14_col21, value_limb_15_col22, value_limb_16_col23, value_limb_17_col24, value_limb_18_col25, value_limb_19_col26, value_limb_20_col27, value_limb_21_col28, value_limb_22_col29, value_limb_23_col30, value_limb_24_col31, value_limb_25_col32, value_limb_26_col33, value_limb_27_col34]);

            let packed_input_state_0_tmp_3806f_2 = PackedFelt252Width27::from_limbs([((((value_limb_0_col7) + (((value_limb_1_col8) * (M31_512))))) + (((value_limb_2_col9) * (M31_262144)))), ((((value_limb_3_col10) + (((value_limb_4_col11) * (M31_512))))) + (((value_limb_5_col12) * (M31_262144)))), ((((value_limb_6_col13) + (((value_limb_7_col14) * (M31_512))))) + (((value_limb_8_col15) * (M31_262144)))), ((((value_limb_9_col16) + (((value_limb_10_col17) * (M31_512))))) + (((value_limb_11_col18) * (M31_262144)))), ((((value_limb_12_col19) + (((value_limb_13_col20) * (M31_512))))) + (((value_limb_14_col21) * (M31_262144)))), ((((value_limb_15_col22) + (((value_limb_16_col23) * (M31_512))))) + (((value_limb_17_col24) * (M31_262144)))), ((((value_limb_18_col25) + (((value_limb_19_col26) * (M31_512))))) + (((value_limb_20_col27) * (M31_262144)))), ((((value_limb_21_col28) + (((value_limb_22_col29) * (M31_512))))) + (((value_limb_23_col30) * (M31_262144)))), ((((value_limb_24_col31) + (((value_limb_25_col32) * (M31_512))))) + (((value_limb_26_col33) * (M31_262144)))), value_limb_27_col34]);

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_3806f_3 = memory_id_to_big_state.deduce_output(input_limb_1_col2);let value_limb_0_col35 = memory_id_to_big_value_tmp_3806f_3.get_m31(0);
            *row[35] = value_limb_0_col35;let value_limb_1_col36 = memory_id_to_big_value_tmp_3806f_3.get_m31(1);
            *row[36] = value_limb_1_col36;let value_limb_2_col37 = memory_id_to_big_value_tmp_3806f_3.get_m31(2);
            *row[37] = value_limb_2_col37;let value_limb_3_col38 = memory_id_to_big_value_tmp_3806f_3.get_m31(3);
            *row[38] = value_limb_3_col38;let value_limb_4_col39 = memory_id_to_big_value_tmp_3806f_3.get_m31(4);
            *row[39] = value_limb_4_col39;let value_limb_5_col40 = memory_id_to_big_value_tmp_3806f_3.get_m31(5);
            *row[40] = value_limb_5_col40;let value_limb_6_col41 = memory_id_to_big_value_tmp_3806f_3.get_m31(6);
            *row[41] = value_limb_6_col41;let value_limb_7_col42 = memory_id_to_big_value_tmp_3806f_3.get_m31(7);
            *row[42] = value_limb_7_col42;let value_limb_8_col43 = memory_id_to_big_value_tmp_3806f_3.get_m31(8);
            *row[43] = value_limb_8_col43;let value_limb_9_col44 = memory_id_to_big_value_tmp_3806f_3.get_m31(9);
            *row[44] = value_limb_9_col44;let value_limb_10_col45 = memory_id_to_big_value_tmp_3806f_3.get_m31(10);
            *row[45] = value_limb_10_col45;let value_limb_11_col46 = memory_id_to_big_value_tmp_3806f_3.get_m31(11);
            *row[46] = value_limb_11_col46;let value_limb_12_col47 = memory_id_to_big_value_tmp_3806f_3.get_m31(12);
            *row[47] = value_limb_12_col47;let value_limb_13_col48 = memory_id_to_big_value_tmp_3806f_3.get_m31(13);
            *row[48] = value_limb_13_col48;let value_limb_14_col49 = memory_id_to_big_value_tmp_3806f_3.get_m31(14);
            *row[49] = value_limb_14_col49;let value_limb_15_col50 = memory_id_to_big_value_tmp_3806f_3.get_m31(15);
            *row[50] = value_limb_15_col50;let value_limb_16_col51 = memory_id_to_big_value_tmp_3806f_3.get_m31(16);
            *row[51] = value_limb_16_col51;let value_limb_17_col52 = memory_id_to_big_value_tmp_3806f_3.get_m31(17);
            *row[52] = value_limb_17_col52;let value_limb_18_col53 = memory_id_to_big_value_tmp_3806f_3.get_m31(18);
            *row[53] = value_limb_18_col53;let value_limb_19_col54 = memory_id_to_big_value_tmp_3806f_3.get_m31(19);
            *row[54] = value_limb_19_col54;let value_limb_20_col55 = memory_id_to_big_value_tmp_3806f_3.get_m31(20);
            *row[55] = value_limb_20_col55;let value_limb_21_col56 = memory_id_to_big_value_tmp_3806f_3.get_m31(21);
            *row[56] = value_limb_21_col56;let value_limb_22_col57 = memory_id_to_big_value_tmp_3806f_3.get_m31(22);
            *row[57] = value_limb_22_col57;let value_limb_23_col58 = memory_id_to_big_value_tmp_3806f_3.get_m31(23);
            *row[58] = value_limb_23_col58;let value_limb_24_col59 = memory_id_to_big_value_tmp_3806f_3.get_m31(24);
            *row[59] = value_limb_24_col59;let value_limb_25_col60 = memory_id_to_big_value_tmp_3806f_3.get_m31(25);
            *row[60] = value_limb_25_col60;let value_limb_26_col61 = memory_id_to_big_value_tmp_3806f_3.get_m31(26);
            *row[61] = value_limb_26_col61;let value_limb_27_col62 = memory_id_to_big_value_tmp_3806f_3.get_m31(27);
            *row[62] = value_limb_27_col62;*sub_component_inputs.memory_id_to_big[1] =
                input_limb_1_col2;
            *lookup_data.memory_id_to_big_1 = [M31_1662111297, input_limb_1_col2, value_limb_0_col35, value_limb_1_col36, value_limb_2_col37, value_limb_3_col38, value_limb_4_col39, value_limb_5_col40, value_limb_6_col41, value_limb_7_col42, value_limb_8_col43, value_limb_9_col44, value_limb_10_col45, value_limb_11_col46, value_limb_12_col47, value_limb_13_col48, value_limb_14_col49, value_limb_15_col50, value_limb_16_col51, value_limb_17_col52, value_limb_18_col53, value_limb_19_col54, value_limb_20_col55, value_limb_21_col56, value_limb_22_col57, value_limb_23_col58, value_limb_24_col59, value_limb_25_col60, value_limb_26_col61, value_limb_27_col62];let read_positive_known_id_num_bits_252_output_tmp_3806f_4 = PackedFelt252::from_limbs([value_limb_0_col35, value_limb_1_col36, value_limb_2_col37, value_limb_3_col38, value_limb_4_col39, value_limb_5_col40, value_limb_6_col41, value_limb_7_col42, value_limb_8_col43, value_limb_9_col44, value_limb_10_col45, value_limb_11_col46, value_limb_12_col47, value_limb_13_col48, value_limb_14_col49, value_limb_15_col50, value_limb_16_col51, value_limb_17_col52, value_limb_18_col53, value_limb_19_col54, value_limb_20_col55, value_limb_21_col56, value_limb_22_col57, value_limb_23_col58, value_limb_24_col59, value_limb_25_col60, value_limb_26_col61, value_limb_27_col62]);

            let packed_input_state_1_tmp_3806f_5 = PackedFelt252Width27::from_limbs([((((value_limb_0_col35) + (((value_limb_1_col36) * (M31_512))))) + (((value_limb_2_col37) * (M31_262144)))), ((((value_limb_3_col38) + (((value_limb_4_col39) * (M31_512))))) + (((value_limb_5_col40) * (M31_262144)))), ((((value_limb_6_col41) + (((value_limb_7_col42) * (M31_512))))) + (((value_limb_8_col43) * (M31_262144)))), ((((value_limb_9_col44) + (((value_limb_10_col45) * (M31_512))))) + (((value_limb_11_col46) * (M31_262144)))), ((((value_limb_12_col47) + (((value_limb_13_col48) * (M31_512))))) + (((value_limb_14_col49) * (M31_262144)))), ((((value_limb_15_col50) + (((value_limb_16_col51) * (M31_512))))) + (((value_limb_17_col52) * (M31_262144)))), ((((value_limb_18_col53) + (((value_limb_19_col54) * (M31_512))))) + (((value_limb_20_col55) * (M31_262144)))), ((((value_limb_21_col56) + (((value_limb_22_col57) * (M31_512))))) + (((value_limb_23_col58) * (M31_262144)))), ((((value_limb_24_col59) + (((value_limb_25_col60) * (M31_512))))) + (((value_limb_26_col61) * (M31_262144)))), value_limb_27_col62]);

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_3806f_6 = memory_id_to_big_state.deduce_output(input_limb_2_col3);let value_limb_0_col63 = memory_id_to_big_value_tmp_3806f_6.get_m31(0);
            *row[63] = value_limb_0_col63;let value_limb_1_col64 = memory_id_to_big_value_tmp_3806f_6.get_m31(1);
            *row[64] = value_limb_1_col64;let value_limb_2_col65 = memory_id_to_big_value_tmp_3806f_6.get_m31(2);
            *row[65] = value_limb_2_col65;let value_limb_3_col66 = memory_id_to_big_value_tmp_3806f_6.get_m31(3);
            *row[66] = value_limb_3_col66;let value_limb_4_col67 = memory_id_to_big_value_tmp_3806f_6.get_m31(4);
            *row[67] = value_limb_4_col67;let value_limb_5_col68 = memory_id_to_big_value_tmp_3806f_6.get_m31(5);
            *row[68] = value_limb_5_col68;let value_limb_6_col69 = memory_id_to_big_value_tmp_3806f_6.get_m31(6);
            *row[69] = value_limb_6_col69;let value_limb_7_col70 = memory_id_to_big_value_tmp_3806f_6.get_m31(7);
            *row[70] = value_limb_7_col70;let value_limb_8_col71 = memory_id_to_big_value_tmp_3806f_6.get_m31(8);
            *row[71] = value_limb_8_col71;let value_limb_9_col72 = memory_id_to_big_value_tmp_3806f_6.get_m31(9);
            *row[72] = value_limb_9_col72;let value_limb_10_col73 = memory_id_to_big_value_tmp_3806f_6.get_m31(10);
            *row[73] = value_limb_10_col73;let value_limb_11_col74 = memory_id_to_big_value_tmp_3806f_6.get_m31(11);
            *row[74] = value_limb_11_col74;let value_limb_12_col75 = memory_id_to_big_value_tmp_3806f_6.get_m31(12);
            *row[75] = value_limb_12_col75;let value_limb_13_col76 = memory_id_to_big_value_tmp_3806f_6.get_m31(13);
            *row[76] = value_limb_13_col76;let value_limb_14_col77 = memory_id_to_big_value_tmp_3806f_6.get_m31(14);
            *row[77] = value_limb_14_col77;let value_limb_15_col78 = memory_id_to_big_value_tmp_3806f_6.get_m31(15);
            *row[78] = value_limb_15_col78;let value_limb_16_col79 = memory_id_to_big_value_tmp_3806f_6.get_m31(16);
            *row[79] = value_limb_16_col79;let value_limb_17_col80 = memory_id_to_big_value_tmp_3806f_6.get_m31(17);
            *row[80] = value_limb_17_col80;let value_limb_18_col81 = memory_id_to_big_value_tmp_3806f_6.get_m31(18);
            *row[81] = value_limb_18_col81;let value_limb_19_col82 = memory_id_to_big_value_tmp_3806f_6.get_m31(19);
            *row[82] = value_limb_19_col82;let value_limb_20_col83 = memory_id_to_big_value_tmp_3806f_6.get_m31(20);
            *row[83] = value_limb_20_col83;let value_limb_21_col84 = memory_id_to_big_value_tmp_3806f_6.get_m31(21);
            *row[84] = value_limb_21_col84;let value_limb_22_col85 = memory_id_to_big_value_tmp_3806f_6.get_m31(22);
            *row[85] = value_limb_22_col85;let value_limb_23_col86 = memory_id_to_big_value_tmp_3806f_6.get_m31(23);
            *row[86] = value_limb_23_col86;let value_limb_24_col87 = memory_id_to_big_value_tmp_3806f_6.get_m31(24);
            *row[87] = value_limb_24_col87;let value_limb_25_col88 = memory_id_to_big_value_tmp_3806f_6.get_m31(25);
            *row[88] = value_limb_25_col88;let value_limb_26_col89 = memory_id_to_big_value_tmp_3806f_6.get_m31(26);
            *row[89] = value_limb_26_col89;let value_limb_27_col90 = memory_id_to_big_value_tmp_3806f_6.get_m31(27);
            *row[90] = value_limb_27_col90;*sub_component_inputs.memory_id_to_big[2] =
                input_limb_2_col3;
            *lookup_data.memory_id_to_big_2 = [M31_1662111297, input_limb_2_col3, value_limb_0_col63, value_limb_1_col64, value_limb_2_col65, value_limb_3_col66, value_limb_4_col67, value_limb_5_col68, value_limb_6_col69, value_limb_7_col70, value_limb_8_col71, value_limb_9_col72, value_limb_10_col73, value_limb_11_col74, value_limb_12_col75, value_limb_13_col76, value_limb_14_col77, value_limb_15_col78, value_limb_16_col79, value_limb_17_col80, value_limb_18_col81, value_limb_19_col82, value_limb_20_col83, value_limb_21_col84, value_limb_22_col85, value_limb_23_col86, value_limb_24_col87, value_limb_25_col88, value_limb_26_col89, value_limb_27_col90];let read_positive_known_id_num_bits_252_output_tmp_3806f_7 = PackedFelt252::from_limbs([value_limb_0_col63, value_limb_1_col64, value_limb_2_col65, value_limb_3_col66, value_limb_4_col67, value_limb_5_col68, value_limb_6_col69, value_limb_7_col70, value_limb_8_col71, value_limb_9_col72, value_limb_10_col73, value_limb_11_col74, value_limb_12_col75, value_limb_13_col76, value_limb_14_col77, value_limb_15_col78, value_limb_16_col79, value_limb_17_col80, value_limb_18_col81, value_limb_19_col82, value_limb_20_col83, value_limb_21_col84, value_limb_22_col85, value_limb_23_col86, value_limb_24_col87, value_limb_25_col88, value_limb_26_col89, value_limb_27_col90]);

            let packed_input_state_2_tmp_3806f_8 = PackedFelt252Width27::from_limbs([((((value_limb_0_col63) + (((value_limb_1_col64) * (M31_512))))) + (((value_limb_2_col65) * (M31_262144)))), ((((value_limb_3_col66) + (((value_limb_4_col67) * (M31_512))))) + (((value_limb_5_col68) * (M31_262144)))), ((((value_limb_6_col69) + (((value_limb_7_col70) * (M31_512))))) + (((value_limb_8_col71) * (M31_262144)))), ((((value_limb_9_col72) + (((value_limb_10_col73) * (M31_512))))) + (((value_limb_11_col74) * (M31_262144)))), ((((value_limb_12_col75) + (((value_limb_13_col76) * (M31_512))))) + (((value_limb_14_col77) * (M31_262144)))), ((((value_limb_15_col78) + (((value_limb_16_col79) * (M31_512))))) + (((value_limb_17_col80) * (M31_262144)))), ((((value_limb_18_col81) + (((value_limb_19_col82) * (M31_512))))) + (((value_limb_20_col83) * (M31_262144)))), ((((value_limb_21_col84) + (((value_limb_22_col85) * (M31_512))))) + (((value_limb_23_col86) * (M31_262144)))), ((((value_limb_24_col87) + (((value_limb_25_col88) * (M31_512))))) + (((value_limb_26_col89) * (M31_262144)))), value_limb_27_col90]);

            // Poseidon Hades Permutation.

            // Linear Combination N 2 Coefs 1 1.

            let combination_tmp_3806f_9 = PackedFelt252Width27::from_packed_felt252(((((Felt252_0_0_0_0) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(packed_input_state_0_tmp_3806f_2)))))) + (Felt252_9275160746813554287_16541205595039575623_4169650429605064889_470088886057789987)));let combination_limb_0_col91 = combination_tmp_3806f_9.get_m31(0);
            *row[91] = combination_limb_0_col91;let combination_limb_1_col92 = combination_tmp_3806f_9.get_m31(1);
            *row[92] = combination_limb_1_col92;let combination_limb_2_col93 = combination_tmp_3806f_9.get_m31(2);
            *row[93] = combination_limb_2_col93;let combination_limb_3_col94 = combination_tmp_3806f_9.get_m31(3);
            *row[94] = combination_limb_3_col94;let combination_limb_4_col95 = combination_tmp_3806f_9.get_m31(4);
            *row[95] = combination_limb_4_col95;let combination_limb_5_col96 = combination_tmp_3806f_9.get_m31(5);
            *row[96] = combination_limb_5_col96;let combination_limb_6_col97 = combination_tmp_3806f_9.get_m31(6);
            *row[97] = combination_limb_6_col97;let combination_limb_7_col98 = combination_tmp_3806f_9.get_m31(7);
            *row[98] = combination_limb_7_col98;let combination_limb_8_col99 = combination_tmp_3806f_9.get_m31(8);
            *row[99] = combination_limb_8_col99;let combination_limb_9_col100 = combination_tmp_3806f_9.get_m31(9);
            *row[100] = combination_limb_9_col100;let biased_limb_accumulator_u32_tmp_3806f_10 = PackedUInt32::from_m31(((((((packed_input_state_0_tmp_3806f_2.get_m31(0)) + (M31_74972783))) - (combination_limb_0_col91))) + (M31_134217729)));let p_coef_col101 = ((biased_limb_accumulator_u32_tmp_3806f_10.low().as_m31()) - (M31_1));
            *row[101] = p_coef_col101;let carry_0_tmp_3806f_11 = ((((((((packed_input_state_0_tmp_3806f_2.get_m31(0)) + (M31_74972783))) - (combination_limb_0_col91))) - (p_coef_col101))) * (M31_16));let carry_1_tmp_3806f_12 = ((((((((carry_0_tmp_3806f_11) + (packed_input_state_0_tmp_3806f_2.get_m31(1)))) + (M31_117420501))) - (combination_limb_1_col92))) * (M31_16));let carry_2_tmp_3806f_13 = ((((((((carry_1_tmp_3806f_12) + (packed_input_state_0_tmp_3806f_2.get_m31(2)))) + (M31_112795138))) - (combination_limb_2_col93))) * (M31_16));let carry_3_tmp_3806f_14 = ((((((((carry_2_tmp_3806f_13) + (packed_input_state_0_tmp_3806f_2.get_m31(3)))) + (M31_91013252))) - (combination_limb_3_col94))) * (M31_16));let carry_4_tmp_3806f_15 = ((((((((carry_3_tmp_3806f_14) + (packed_input_state_0_tmp_3806f_2.get_m31(4)))) + (M31_60709090))) - (combination_limb_4_col95))) * (M31_16));let carry_5_tmp_3806f_16 = ((((((((carry_4_tmp_3806f_15) + (packed_input_state_0_tmp_3806f_2.get_m31(5)))) + (M31_44848225))) - (combination_limb_5_col96))) * (M31_16));let carry_6_tmp_3806f_17 = ((((((((carry_5_tmp_3806f_16) + (packed_input_state_0_tmp_3806f_2.get_m31(6)))) + (M31_108487870))) - (combination_limb_6_col97))) * (M31_16));let carry_7_tmp_3806f_18 = ((((((((((carry_6_tmp_3806f_17) + (packed_input_state_0_tmp_3806f_2.get_m31(7)))) + (M31_44781849))) - (combination_limb_7_col98))) - (((p_coef_col101) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_19 = ((((((((carry_7_tmp_3806f_18) + (packed_input_state_0_tmp_3806f_2.get_m31(8)))) + (M31_102193642))) - (combination_limb_8_col99))) * (M31_16));let linear_combination_n_2_coefs_1_1_output_tmp_3806f_29 = combination_tmp_3806f_9;

            // Linear Combination N 2 Coefs 1 1.

            let combination_tmp_3806f_30 = PackedFelt252Width27::from_packed_felt252(((((Felt252_0_0_0_0) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(packed_input_state_1_tmp_3806f_5)))))) + (Felt252_16477292399064058052_4441744911417641572_18431044672185975386_252894828082060025)));let combination_limb_0_col102 = combination_tmp_3806f_30.get_m31(0);
            *row[102] = combination_limb_0_col102;let combination_limb_1_col103 = combination_tmp_3806f_30.get_m31(1);
            *row[103] = combination_limb_1_col103;let combination_limb_2_col104 = combination_tmp_3806f_30.get_m31(2);
            *row[104] = combination_limb_2_col104;let combination_limb_3_col105 = combination_tmp_3806f_30.get_m31(3);
            *row[105] = combination_limb_3_col105;let combination_limb_4_col106 = combination_tmp_3806f_30.get_m31(4);
            *row[106] = combination_limb_4_col106;let combination_limb_5_col107 = combination_tmp_3806f_30.get_m31(5);
            *row[107] = combination_limb_5_col107;let combination_limb_6_col108 = combination_tmp_3806f_30.get_m31(6);
            *row[108] = combination_limb_6_col108;let combination_limb_7_col109 = combination_tmp_3806f_30.get_m31(7);
            *row[109] = combination_limb_7_col109;let combination_limb_8_col110 = combination_tmp_3806f_30.get_m31(8);
            *row[110] = combination_limb_8_col110;let combination_limb_9_col111 = combination_tmp_3806f_30.get_m31(9);
            *row[111] = combination_limb_9_col111;let biased_limb_accumulator_u32_tmp_3806f_31 = PackedUInt32::from_m31(((((((packed_input_state_1_tmp_3806f_5.get_m31(0)) + (M31_41224388))) - (combination_limb_0_col102))) + (M31_134217729)));let p_coef_col112 = ((biased_limb_accumulator_u32_tmp_3806f_31.low().as_m31()) - (M31_1));
            *row[112] = p_coef_col112;let carry_0_tmp_3806f_32 = ((((((((packed_input_state_1_tmp_3806f_5.get_m31(0)) + (M31_41224388))) - (combination_limb_0_col102))) - (p_coef_col112))) * (M31_16));let carry_1_tmp_3806f_33 = ((((((((carry_0_tmp_3806f_32) + (packed_input_state_1_tmp_3806f_5.get_m31(1)))) + (M31_90391646))) - (combination_limb_1_col103))) * (M31_16));let carry_2_tmp_3806f_34 = ((((((((carry_1_tmp_3806f_33) + (packed_input_state_1_tmp_3806f_5.get_m31(2)))) + (M31_36279186))) - (combination_limb_2_col104))) * (M31_16));let carry_3_tmp_3806f_35 = ((((((((carry_2_tmp_3806f_34) + (packed_input_state_1_tmp_3806f_5.get_m31(3)))) + (M31_129717753))) - (combination_limb_3_col105))) * (M31_16));let carry_4_tmp_3806f_36 = ((((((((carry_3_tmp_3806f_35) + (packed_input_state_1_tmp_3806f_5.get_m31(4)))) + (M31_94624323))) - (combination_limb_4_col106))) * (M31_16));let carry_5_tmp_3806f_37 = ((((((((carry_4_tmp_3806f_36) + (packed_input_state_1_tmp_3806f_5.get_m31(5)))) + (M31_75104388))) - (combination_limb_5_col107))) * (M31_16));let carry_6_tmp_3806f_38 = ((((((((carry_5_tmp_3806f_37) + (packed_input_state_1_tmp_3806f_5.get_m31(6)))) + (M31_133303902))) - (combination_limb_6_col108))) * (M31_16));let carry_7_tmp_3806f_39 = ((((((((((carry_6_tmp_3806f_38) + (packed_input_state_1_tmp_3806f_5.get_m31(7)))) + (M31_48945103))) - (combination_limb_7_col109))) - (((p_coef_col112) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_40 = ((((((((carry_7_tmp_3806f_39) + (packed_input_state_1_tmp_3806f_5.get_m31(8)))) + (M31_41320857))) - (combination_limb_8_col110))) * (M31_16));let linear_combination_n_2_coefs_1_1_output_tmp_3806f_50 = combination_tmp_3806f_30;

            // Linear Combination N 2 Coefs 1 1.

            let combination_tmp_3806f_51 = PackedFelt252Width27::from_packed_felt252(((((Felt252_0_0_0_0) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(packed_input_state_2_tmp_3806f_8)))))) + (Felt252_8794894655201903369_3219077422080798056_16714934791572408267_262217499501479120)));let combination_limb_0_col113 = combination_tmp_3806f_51.get_m31(0);
            *row[113] = combination_limb_0_col113;let combination_limb_1_col114 = combination_tmp_3806f_51.get_m31(1);
            *row[114] = combination_limb_1_col114;let combination_limb_2_col115 = combination_tmp_3806f_51.get_m31(2);
            *row[115] = combination_limb_2_col115;let combination_limb_3_col116 = combination_tmp_3806f_51.get_m31(3);
            *row[116] = combination_limb_3_col116;let combination_limb_4_col117 = combination_tmp_3806f_51.get_m31(4);
            *row[117] = combination_limb_4_col117;let combination_limb_5_col118 = combination_tmp_3806f_51.get_m31(5);
            *row[118] = combination_limb_5_col118;let combination_limb_6_col119 = combination_tmp_3806f_51.get_m31(6);
            *row[119] = combination_limb_6_col119;let combination_limb_7_col120 = combination_tmp_3806f_51.get_m31(7);
            *row[120] = combination_limb_7_col120;let combination_limb_8_col121 = combination_tmp_3806f_51.get_m31(8);
            *row[121] = combination_limb_8_col121;let combination_limb_9_col122 = combination_tmp_3806f_51.get_m31(9);
            *row[122] = combination_limb_9_col122;let biased_limb_accumulator_u32_tmp_3806f_52 = PackedUInt32::from_m31(((((((packed_input_state_2_tmp_3806f_8.get_m31(0)) + (M31_4883209))) - (combination_limb_0_col113))) + (M31_134217729)));let p_coef_col123 = ((biased_limb_accumulator_u32_tmp_3806f_52.low().as_m31()) - (M31_1));
            *row[123] = p_coef_col123;let carry_0_tmp_3806f_53 = ((((((((packed_input_state_2_tmp_3806f_8.get_m31(0)) + (M31_4883209))) - (combination_limb_0_col113))) - (p_coef_col123))) * (M31_16));let carry_1_tmp_3806f_54 = ((((((((carry_0_tmp_3806f_53) + (packed_input_state_2_tmp_3806f_8.get_m31(1)))) + (M31_28820206))) - (combination_limb_1_col114))) * (M31_16));let carry_2_tmp_3806f_55 = ((((((((carry_1_tmp_3806f_54) + (packed_input_state_2_tmp_3806f_8.get_m31(2)))) + (M31_79012328))) - (combination_limb_2_col115))) * (M31_16));let carry_3_tmp_3806f_56 = ((((((((carry_2_tmp_3806f_55) + (packed_input_state_2_tmp_3806f_8.get_m31(3)))) + (M31_49157069))) - (combination_limb_3_col116))) * (M31_16));let carry_4_tmp_3806f_57 = ((((((((carry_3_tmp_3806f_56) + (packed_input_state_2_tmp_3806f_8.get_m31(4)))) + (M31_78826183))) - (combination_limb_4_col117))) * (M31_16));let carry_5_tmp_3806f_58 = ((((((((carry_4_tmp_3806f_57) + (packed_input_state_2_tmp_3806f_8.get_m31(5)))) + (M31_72285071))) - (combination_limb_5_col118))) * (M31_16));let carry_6_tmp_3806f_59 = ((((((((carry_5_tmp_3806f_58) + (packed_input_state_2_tmp_3806f_8.get_m31(6)))) + (M31_33413160))) - (combination_limb_6_col119))) * (M31_16));let carry_7_tmp_3806f_60 = ((((((((((carry_6_tmp_3806f_59) + (packed_input_state_2_tmp_3806f_8.get_m31(7)))) + (M31_90842759))) - (combination_limb_7_col120))) - (((p_coef_col123) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_61 = ((((((((carry_7_tmp_3806f_60) + (packed_input_state_2_tmp_3806f_8.get_m31(8)))) + (M31_60124463))) - (combination_limb_8_col121))) * (M31_16));let linear_combination_n_2_coefs_1_1_output_tmp_3806f_71 = combination_tmp_3806f_51;

            let poseidon_full_round_chain_chain_tmp_tmp_3806f_72 = ((seq) * (M31_2));*lookup_data.poseidon_full_round_chain_3 = [M31_1480369132, poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_0, combination_limb_0_col91, combination_limb_1_col92, combination_limb_2_col93, combination_limb_3_col94, combination_limb_4_col95, combination_limb_5_col96, combination_limb_6_col97, combination_limb_7_col98, combination_limb_8_col99, combination_limb_9_col100, combination_limb_0_col102, combination_limb_1_col103, combination_limb_2_col104, combination_limb_3_col105, combination_limb_4_col106, combination_limb_5_col107, combination_limb_6_col108, combination_limb_7_col109, combination_limb_8_col110, combination_limb_9_col111, combination_limb_0_col113, combination_limb_1_col114, combination_limb_2_col115, combination_limb_3_col116, combination_limb_4_col117, combination_limb_5_col118, combination_limb_6_col119, combination_limb_7_col120, combination_limb_8_col121, combination_limb_9_col122];*sub_component_inputs.poseidon_full_round_chain[0] =
                (poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_0, [linear_combination_n_2_coefs_1_1_output_tmp_3806f_29, linear_combination_n_2_coefs_1_1_output_tmp_3806f_50, linear_combination_n_2_coefs_1_1_output_tmp_3806f_71]);
            let poseidon_full_round_chain_output_round_0_tmp_3806f_73 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_0, [linear_combination_n_2_coefs_1_1_output_tmp_3806f_29, linear_combination_n_2_coefs_1_1_output_tmp_3806f_50, linear_combination_n_2_coefs_1_1_output_tmp_3806f_71]));*sub_component_inputs.poseidon_full_round_chain[1] =
                (poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_1, [poseidon_full_round_chain_output_round_0_tmp_3806f_73.2[0], poseidon_full_round_chain_output_round_0_tmp_3806f_73.2[1], poseidon_full_round_chain_output_round_0_tmp_3806f_73.2[2]]);
            let poseidon_full_round_chain_output_round_1_tmp_3806f_74 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_1, [poseidon_full_round_chain_output_round_0_tmp_3806f_73.2[0], poseidon_full_round_chain_output_round_0_tmp_3806f_73.2[1], poseidon_full_round_chain_output_round_0_tmp_3806f_73.2[2]]));*sub_component_inputs.poseidon_full_round_chain[2] =
                (poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_2, [poseidon_full_round_chain_output_round_1_tmp_3806f_74.2[0], poseidon_full_round_chain_output_round_1_tmp_3806f_74.2[1], poseidon_full_round_chain_output_round_1_tmp_3806f_74.2[2]]);
            let poseidon_full_round_chain_output_round_2_tmp_3806f_75 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_2, [poseidon_full_round_chain_output_round_1_tmp_3806f_74.2[0], poseidon_full_round_chain_output_round_1_tmp_3806f_74.2[1], poseidon_full_round_chain_output_round_1_tmp_3806f_74.2[2]]));*sub_component_inputs.poseidon_full_round_chain[3] =
                (poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_3, [poseidon_full_round_chain_output_round_2_tmp_3806f_75.2[0], poseidon_full_round_chain_output_round_2_tmp_3806f_75.2[1], poseidon_full_round_chain_output_round_2_tmp_3806f_75.2[2]]);
            let poseidon_full_round_chain_output_round_3_tmp_3806f_76 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_3, [poseidon_full_round_chain_output_round_2_tmp_3806f_75.2[0], poseidon_full_round_chain_output_round_2_tmp_3806f_75.2[1], poseidon_full_round_chain_output_round_2_tmp_3806f_75.2[2]]));let poseidon_full_round_chain_output_limb_0_col124 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(0);
            *row[124] = poseidon_full_round_chain_output_limb_0_col124;let poseidon_full_round_chain_output_limb_1_col125 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(1);
            *row[125] = poseidon_full_round_chain_output_limb_1_col125;let poseidon_full_round_chain_output_limb_2_col126 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(2);
            *row[126] = poseidon_full_round_chain_output_limb_2_col126;let poseidon_full_round_chain_output_limb_3_col127 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(3);
            *row[127] = poseidon_full_round_chain_output_limb_3_col127;let poseidon_full_round_chain_output_limb_4_col128 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(4);
            *row[128] = poseidon_full_round_chain_output_limb_4_col128;let poseidon_full_round_chain_output_limb_5_col129 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(5);
            *row[129] = poseidon_full_round_chain_output_limb_5_col129;let poseidon_full_round_chain_output_limb_6_col130 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(6);
            *row[130] = poseidon_full_round_chain_output_limb_6_col130;let poseidon_full_round_chain_output_limb_7_col131 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(7);
            *row[131] = poseidon_full_round_chain_output_limb_7_col131;let poseidon_full_round_chain_output_limb_8_col132 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(8);
            *row[132] = poseidon_full_round_chain_output_limb_8_col132;let poseidon_full_round_chain_output_limb_9_col133 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0].get_m31(9);
            *row[133] = poseidon_full_round_chain_output_limb_9_col133;let poseidon_full_round_chain_output_limb_10_col134 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(0);
            *row[134] = poseidon_full_round_chain_output_limb_10_col134;let poseidon_full_round_chain_output_limb_11_col135 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(1);
            *row[135] = poseidon_full_round_chain_output_limb_11_col135;let poseidon_full_round_chain_output_limb_12_col136 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(2);
            *row[136] = poseidon_full_round_chain_output_limb_12_col136;let poseidon_full_round_chain_output_limb_13_col137 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(3);
            *row[137] = poseidon_full_round_chain_output_limb_13_col137;let poseidon_full_round_chain_output_limb_14_col138 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(4);
            *row[138] = poseidon_full_round_chain_output_limb_14_col138;let poseidon_full_round_chain_output_limb_15_col139 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(5);
            *row[139] = poseidon_full_round_chain_output_limb_15_col139;let poseidon_full_round_chain_output_limb_16_col140 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(6);
            *row[140] = poseidon_full_round_chain_output_limb_16_col140;let poseidon_full_round_chain_output_limb_17_col141 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(7);
            *row[141] = poseidon_full_round_chain_output_limb_17_col141;let poseidon_full_round_chain_output_limb_18_col142 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(8);
            *row[142] = poseidon_full_round_chain_output_limb_18_col142;let poseidon_full_round_chain_output_limb_19_col143 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1].get_m31(9);
            *row[143] = poseidon_full_round_chain_output_limb_19_col143;let poseidon_full_round_chain_output_limb_20_col144 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(0);
            *row[144] = poseidon_full_round_chain_output_limb_20_col144;let poseidon_full_round_chain_output_limb_21_col145 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(1);
            *row[145] = poseidon_full_round_chain_output_limb_21_col145;let poseidon_full_round_chain_output_limb_22_col146 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(2);
            *row[146] = poseidon_full_round_chain_output_limb_22_col146;let poseidon_full_round_chain_output_limb_23_col147 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(3);
            *row[147] = poseidon_full_round_chain_output_limb_23_col147;let poseidon_full_round_chain_output_limb_24_col148 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(4);
            *row[148] = poseidon_full_round_chain_output_limb_24_col148;let poseidon_full_round_chain_output_limb_25_col149 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(5);
            *row[149] = poseidon_full_round_chain_output_limb_25_col149;let poseidon_full_round_chain_output_limb_26_col150 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(6);
            *row[150] = poseidon_full_round_chain_output_limb_26_col150;let poseidon_full_round_chain_output_limb_27_col151 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(7);
            *row[151] = poseidon_full_round_chain_output_limb_27_col151;let poseidon_full_round_chain_output_limb_28_col152 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(8);
            *row[152] = poseidon_full_round_chain_output_limb_28_col152;let poseidon_full_round_chain_output_limb_29_col153 = poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2].get_m31(9);
            *row[153] = poseidon_full_round_chain_output_limb_29_col153;*lookup_data.poseidon_full_round_chain_4 = [M31_1480369132, poseidon_full_round_chain_chain_tmp_tmp_3806f_72, M31_4, poseidon_full_round_chain_output_limb_0_col124, poseidon_full_round_chain_output_limb_1_col125, poseidon_full_round_chain_output_limb_2_col126, poseidon_full_round_chain_output_limb_3_col127, poseidon_full_round_chain_output_limb_4_col128, poseidon_full_round_chain_output_limb_5_col129, poseidon_full_round_chain_output_limb_6_col130, poseidon_full_round_chain_output_limb_7_col131, poseidon_full_round_chain_output_limb_8_col132, poseidon_full_round_chain_output_limb_9_col133, poseidon_full_round_chain_output_limb_10_col134, poseidon_full_round_chain_output_limb_11_col135, poseidon_full_round_chain_output_limb_12_col136, poseidon_full_round_chain_output_limb_13_col137, poseidon_full_round_chain_output_limb_14_col138, poseidon_full_round_chain_output_limb_15_col139, poseidon_full_round_chain_output_limb_16_col140, poseidon_full_round_chain_output_limb_17_col141, poseidon_full_round_chain_output_limb_18_col142, poseidon_full_round_chain_output_limb_19_col143, poseidon_full_round_chain_output_limb_20_col144, poseidon_full_round_chain_output_limb_21_col145, poseidon_full_round_chain_output_limb_22_col146, poseidon_full_round_chain_output_limb_23_col147, poseidon_full_round_chain_output_limb_24_col148, poseidon_full_round_chain_output_limb_25_col149, poseidon_full_round_chain_output_limb_26_col150, poseidon_full_round_chain_output_limb_27_col151, poseidon_full_round_chain_output_limb_28_col152, poseidon_full_round_chain_output_limb_29_col153];*sub_component_inputs.range_check_252_width_27[0] =
                poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0];
            *lookup_data.range_check_252_width_27_5 = [M31_1090315331, poseidon_full_round_chain_output_limb_0_col124, poseidon_full_round_chain_output_limb_1_col125, poseidon_full_round_chain_output_limb_2_col126, poseidon_full_round_chain_output_limb_3_col127, poseidon_full_round_chain_output_limb_4_col128, poseidon_full_round_chain_output_limb_5_col129, poseidon_full_round_chain_output_limb_6_col130, poseidon_full_round_chain_output_limb_7_col131, poseidon_full_round_chain_output_limb_8_col132, poseidon_full_round_chain_output_limb_9_col133];*sub_component_inputs.range_check_252_width_27[1] =
                poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1];
            *lookup_data.range_check_252_width_27_6 = [M31_1090315331, poseidon_full_round_chain_output_limb_10_col134, poseidon_full_round_chain_output_limb_11_col135, poseidon_full_round_chain_output_limb_12_col136, poseidon_full_round_chain_output_limb_13_col137, poseidon_full_round_chain_output_limb_14_col138, poseidon_full_round_chain_output_limb_15_col139, poseidon_full_round_chain_output_limb_16_col140, poseidon_full_round_chain_output_limb_17_col141, poseidon_full_round_chain_output_limb_18_col142, poseidon_full_round_chain_output_limb_19_col143];*sub_component_inputs.cube_252[0] =
                poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2];
            let cube_252_output_tmp_3806f_77 = PackedCube252::deduce_output(poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[2]);let cube_252_output_limb_0_col154 = cube_252_output_tmp_3806f_77.get_m31(0);
            *row[154] = cube_252_output_limb_0_col154;let cube_252_output_limb_1_col155 = cube_252_output_tmp_3806f_77.get_m31(1);
            *row[155] = cube_252_output_limb_1_col155;let cube_252_output_limb_2_col156 = cube_252_output_tmp_3806f_77.get_m31(2);
            *row[156] = cube_252_output_limb_2_col156;let cube_252_output_limb_3_col157 = cube_252_output_tmp_3806f_77.get_m31(3);
            *row[157] = cube_252_output_limb_3_col157;let cube_252_output_limb_4_col158 = cube_252_output_tmp_3806f_77.get_m31(4);
            *row[158] = cube_252_output_limb_4_col158;let cube_252_output_limb_5_col159 = cube_252_output_tmp_3806f_77.get_m31(5);
            *row[159] = cube_252_output_limb_5_col159;let cube_252_output_limb_6_col160 = cube_252_output_tmp_3806f_77.get_m31(6);
            *row[160] = cube_252_output_limb_6_col160;let cube_252_output_limb_7_col161 = cube_252_output_tmp_3806f_77.get_m31(7);
            *row[161] = cube_252_output_limb_7_col161;let cube_252_output_limb_8_col162 = cube_252_output_tmp_3806f_77.get_m31(8);
            *row[162] = cube_252_output_limb_8_col162;let cube_252_output_limb_9_col163 = cube_252_output_tmp_3806f_77.get_m31(9);
            *row[163] = cube_252_output_limb_9_col163;*lookup_data.cube_252_7 = [M31_1987997202, poseidon_full_round_chain_output_limb_20_col144, poseidon_full_round_chain_output_limb_21_col145, poseidon_full_round_chain_output_limb_22_col146, poseidon_full_round_chain_output_limb_23_col147, poseidon_full_round_chain_output_limb_24_col148, poseidon_full_round_chain_output_limb_25_col149, poseidon_full_round_chain_output_limb_26_col150, poseidon_full_round_chain_output_limb_27_col151, poseidon_full_round_chain_output_limb_28_col152, poseidon_full_round_chain_output_limb_29_col153, cube_252_output_limb_0_col154, cube_252_output_limb_1_col155, cube_252_output_limb_2_col156, cube_252_output_limb_3_col157, cube_252_output_limb_4_col158, cube_252_output_limb_5_col159, cube_252_output_limb_6_col160, cube_252_output_limb_7_col161, cube_252_output_limb_8_col162, cube_252_output_limb_9_col163];

            // Linear Combination N 4 Coefs 1 1 M 2 1.

            let combination_tmp_3806f_78 = PackedFelt252Width27::from_packed_felt252(((((((((Felt252_0_0_0_0) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0])))))) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[1])))))) - (((Felt252_2_0_0_0) * (PackedFelt252::from_packed_felt252width27(cube_252_output_tmp_3806f_77)))))) + (Felt252_11041071929982523380_7503192613203831446_4943121247101232560_560497091765764140)));let combination_limb_0_col164 = combination_tmp_3806f_78.get_m31(0);
            *row[164] = combination_limb_0_col164;let combination_limb_1_col165 = combination_tmp_3806f_78.get_m31(1);
            *row[165] = combination_limb_1_col165;let combination_limb_2_col166 = combination_tmp_3806f_78.get_m31(2);
            *row[166] = combination_limb_2_col166;let combination_limb_3_col167 = combination_tmp_3806f_78.get_m31(3);
            *row[167] = combination_limb_3_col167;let combination_limb_4_col168 = combination_tmp_3806f_78.get_m31(4);
            *row[168] = combination_limb_4_col168;let combination_limb_5_col169 = combination_tmp_3806f_78.get_m31(5);
            *row[169] = combination_limb_5_col169;let combination_limb_6_col170 = combination_tmp_3806f_78.get_m31(6);
            *row[170] = combination_limb_6_col170;let combination_limb_7_col171 = combination_tmp_3806f_78.get_m31(7);
            *row[171] = combination_limb_7_col171;let combination_limb_8_col172 = combination_tmp_3806f_78.get_m31(8);
            *row[172] = combination_limb_8_col172;let combination_limb_9_col173 = combination_tmp_3806f_78.get_m31(9);
            *row[173] = combination_limb_9_col173;let biased_limb_accumulator_u32_tmp_3806f_79 = PackedUInt32::from_m31(((((((((((poseidon_full_round_chain_output_limb_0_col124) + (poseidon_full_round_chain_output_limb_10_col134))) - (((M31_2) * (cube_252_output_limb_0_col154))))) + (M31_103094260))) - (combination_limb_0_col164))) + (M31_402653187)));let p_coef_col174 = ((biased_limb_accumulator_u32_tmp_3806f_79.low().as_m31()) - (M31_3));
            *row[174] = p_coef_col174;let carry_0_tmp_3806f_80 = ((((((((((((poseidon_full_round_chain_output_limb_0_col124) + (poseidon_full_round_chain_output_limb_10_col134))) - (((M31_2) * (cube_252_output_limb_0_col154))))) + (M31_103094260))) - (combination_limb_0_col164))) - (p_coef_col174))) * (M31_16));let carry_1_tmp_3806f_81 = ((((((((((((carry_0_tmp_3806f_80) + (poseidon_full_round_chain_output_limb_1_col125))) + (poseidon_full_round_chain_output_limb_11_col135))) - (((M31_2) * (cube_252_output_limb_1_col155))))) + (M31_121146754))) - (combination_limb_1_col165))) * (M31_16));let carry_2_tmp_3806f_82 = ((((((((((((carry_1_tmp_3806f_81) + (poseidon_full_round_chain_output_limb_2_col126))) + (poseidon_full_round_chain_output_limb_12_col136))) - (((M31_2) * (cube_252_output_limb_2_col156))))) + (M31_95050340))) - (combination_limb_2_col166))) * (M31_16));let carry_3_tmp_3806f_83 = ((((((((((((carry_2_tmp_3806f_82) + (poseidon_full_round_chain_output_limb_3_col127))) + (poseidon_full_round_chain_output_limb_13_col137))) - (((M31_2) * (cube_252_output_limb_3_col157))))) + (M31_16173996))) - (combination_limb_3_col167))) * (M31_16));let carry_4_tmp_3806f_84 = ((((((((((((carry_3_tmp_3806f_83) + (poseidon_full_round_chain_output_limb_4_col128))) + (poseidon_full_round_chain_output_limb_14_col138))) - (((M31_2) * (cube_252_output_limb_4_col158))))) + (M31_50758155))) - (combination_limb_4_col168))) * (M31_16));let carry_5_tmp_3806f_85 = ((((((((((((carry_4_tmp_3806f_84) + (poseidon_full_round_chain_output_limb_5_col129))) + (poseidon_full_round_chain_output_limb_15_col139))) - (((M31_2) * (cube_252_output_limb_5_col159))))) + (M31_54415179))) - (combination_limb_5_col169))) * (M31_16));let carry_6_tmp_3806f_86 = ((((((((((((carry_5_tmp_3806f_85) + (poseidon_full_round_chain_output_limb_6_col130))) + (poseidon_full_round_chain_output_limb_16_col140))) - (((M31_2) * (cube_252_output_limb_6_col160))))) + (M31_19292069))) - (combination_limb_6_col170))) * (M31_16));let carry_7_tmp_3806f_87 = ((((((((((((((carry_6_tmp_3806f_86) + (poseidon_full_round_chain_output_limb_7_col131))) + (poseidon_full_round_chain_output_limb_17_col141))) - (((M31_2) * (cube_252_output_limb_7_col161))))) + (M31_45351266))) - (combination_limb_7_col171))) - (((p_coef_col174) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_88 = ((((((((((((carry_7_tmp_3806f_87) + (poseidon_full_round_chain_output_limb_8_col132))) + (poseidon_full_round_chain_output_limb_18_col142))) - (((M31_2) * (cube_252_output_limb_8_col162))))) + (M31_122233508))) - (combination_limb_8_col172))) * (M31_16));*sub_component_inputs.range_check_3_3_3_3_3[0] =
                [((p_coef_col174) + (M31_3)), ((carry_0_tmp_3806f_80) + (M31_3)), ((carry_1_tmp_3806f_81) + (M31_3)), ((carry_2_tmp_3806f_82) + (M31_3)), ((carry_3_tmp_3806f_83) + (M31_3))];
            *lookup_data.range_check_3_3_3_3_3_8 = [M31_502259093, ((p_coef_col174) + (M31_3)), ((carry_0_tmp_3806f_80) + (M31_3)), ((carry_1_tmp_3806f_81) + (M31_3)), ((carry_2_tmp_3806f_82) + (M31_3)), ((carry_3_tmp_3806f_83) + (M31_3))];*sub_component_inputs.range_check_3_3_3_3_3[1] =
                [((carry_4_tmp_3806f_84) + (M31_3)), ((carry_5_tmp_3806f_85) + (M31_3)), ((carry_6_tmp_3806f_86) + (M31_3)), ((carry_7_tmp_3806f_87) + (M31_3)), ((carry_8_tmp_3806f_88) + (M31_3))];
            *lookup_data.range_check_3_3_3_3_3_9 = [M31_502259093, ((carry_4_tmp_3806f_84) + (M31_3)), ((carry_5_tmp_3806f_85) + (M31_3)), ((carry_6_tmp_3806f_86) + (M31_3)), ((carry_7_tmp_3806f_87) + (M31_3)), ((carry_8_tmp_3806f_88) + (M31_3))];let linear_combination_n_4_coefs_1_1_m2_1_output_tmp_3806f_89 = combination_tmp_3806f_78;

            *sub_component_inputs.cube_252[1] =
                linear_combination_n_4_coefs_1_1_m2_1_output_tmp_3806f_89;
            let cube_252_output_tmp_3806f_90 = PackedCube252::deduce_output(linear_combination_n_4_coefs_1_1_m2_1_output_tmp_3806f_89);let cube_252_output_limb_0_col175 = cube_252_output_tmp_3806f_90.get_m31(0);
            *row[175] = cube_252_output_limb_0_col175;let cube_252_output_limb_1_col176 = cube_252_output_tmp_3806f_90.get_m31(1);
            *row[176] = cube_252_output_limb_1_col176;let cube_252_output_limb_2_col177 = cube_252_output_tmp_3806f_90.get_m31(2);
            *row[177] = cube_252_output_limb_2_col177;let cube_252_output_limb_3_col178 = cube_252_output_tmp_3806f_90.get_m31(3);
            *row[178] = cube_252_output_limb_3_col178;let cube_252_output_limb_4_col179 = cube_252_output_tmp_3806f_90.get_m31(4);
            *row[179] = cube_252_output_limb_4_col179;let cube_252_output_limb_5_col180 = cube_252_output_tmp_3806f_90.get_m31(5);
            *row[180] = cube_252_output_limb_5_col180;let cube_252_output_limb_6_col181 = cube_252_output_tmp_3806f_90.get_m31(6);
            *row[181] = cube_252_output_limb_6_col181;let cube_252_output_limb_7_col182 = cube_252_output_tmp_3806f_90.get_m31(7);
            *row[182] = cube_252_output_limb_7_col182;let cube_252_output_limb_8_col183 = cube_252_output_tmp_3806f_90.get_m31(8);
            *row[183] = cube_252_output_limb_8_col183;let cube_252_output_limb_9_col184 = cube_252_output_tmp_3806f_90.get_m31(9);
            *row[184] = cube_252_output_limb_9_col184;*lookup_data.cube_252_10 = [M31_1987997202, combination_limb_0_col164, combination_limb_1_col165, combination_limb_2_col166, combination_limb_3_col167, combination_limb_4_col168, combination_limb_5_col169, combination_limb_6_col170, combination_limb_7_col171, combination_limb_8_col172, combination_limb_9_col173, cube_252_output_limb_0_col175, cube_252_output_limb_1_col176, cube_252_output_limb_2_col177, cube_252_output_limb_3_col178, cube_252_output_limb_4_col179, cube_252_output_limb_5_col180, cube_252_output_limb_6_col181, cube_252_output_limb_7_col182, cube_252_output_limb_8_col183, cube_252_output_limb_9_col184];

            // Linear Combination N 4 Coefs 4 2 M 2 1.

            let combination_tmp_3806f_91 = PackedFelt252Width27::from_packed_felt252(((((((((Felt252_0_0_0_0) + (((Felt252_4_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_full_round_chain_output_round_3_tmp_3806f_76.2[0])))))) + (((Felt252_2_0_0_0) * (PackedFelt252::from_packed_felt252width27(cube_252_output_tmp_3806f_77)))))) - (((Felt252_2_0_0_0) * (PackedFelt252::from_packed_felt252width27(cube_252_output_tmp_3806f_90)))))) + (Felt252_10931822301410252833_1475756362763989377_3378552166684303673_348229636055909092)));let combination_limb_0_col185 = combination_tmp_3806f_91.get_m31(0);
            *row[185] = combination_limb_0_col185;let combination_limb_1_col186 = combination_tmp_3806f_91.get_m31(1);
            *row[186] = combination_limb_1_col186;let combination_limb_2_col187 = combination_tmp_3806f_91.get_m31(2);
            *row[187] = combination_limb_2_col187;let combination_limb_3_col188 = combination_tmp_3806f_91.get_m31(3);
            *row[188] = combination_limb_3_col188;let combination_limb_4_col189 = combination_tmp_3806f_91.get_m31(4);
            *row[189] = combination_limb_4_col189;let combination_limb_5_col190 = combination_tmp_3806f_91.get_m31(5);
            *row[190] = combination_limb_5_col190;let combination_limb_6_col191 = combination_tmp_3806f_91.get_m31(6);
            *row[191] = combination_limb_6_col191;let combination_limb_7_col192 = combination_tmp_3806f_91.get_m31(7);
            *row[192] = combination_limb_7_col192;let combination_limb_8_col193 = combination_tmp_3806f_91.get_m31(8);
            *row[193] = combination_limb_8_col193;let combination_limb_9_col194 = combination_tmp_3806f_91.get_m31(9);
            *row[194] = combination_limb_9_col194;let biased_limb_accumulator_u32_tmp_3806f_92 = PackedUInt32::from_m31(((((((((((((M31_4) * (poseidon_full_round_chain_output_limb_0_col124))) + (((M31_2) * (cube_252_output_limb_0_col154))))) - (((M31_2) * (cube_252_output_limb_0_col175))))) + (M31_121657377))) - (combination_limb_0_col185))) + (M31_402653187)));let p_coef_col195 = ((biased_limb_accumulator_u32_tmp_3806f_92.low().as_m31()) - (M31_3));
            *row[195] = p_coef_col195;let carry_0_tmp_3806f_93 = ((((((((((((((M31_4) * (poseidon_full_round_chain_output_limb_0_col124))) + (((M31_2) * (cube_252_output_limb_0_col154))))) - (((M31_2) * (cube_252_output_limb_0_col175))))) + (M31_121657377))) - (combination_limb_0_col185))) - (p_coef_col195))) * (M31_16));let carry_1_tmp_3806f_94 = ((((((((((((carry_0_tmp_3806f_93) + (((M31_4) * (poseidon_full_round_chain_output_limb_1_col125))))) + (((M31_2) * (cube_252_output_limb_1_col155))))) - (((M31_2) * (cube_252_output_limb_1_col176))))) + (M31_112479959))) - (combination_limb_1_col186))) * (M31_16));let carry_2_tmp_3806f_95 = ((((((((((((carry_1_tmp_3806f_94) + (((M31_4) * (poseidon_full_round_chain_output_limb_2_col126))))) + (((M31_2) * (cube_252_output_limb_2_col156))))) - (((M31_2) * (cube_252_output_limb_2_col177))))) + (M31_130418270))) - (combination_limb_2_col187))) * (M31_16));let carry_3_tmp_3806f_96 = ((((((((((((carry_2_tmp_3806f_95) + (((M31_4) * (poseidon_full_round_chain_output_limb_3_col127))))) + (((M31_2) * (cube_252_output_limb_3_col157))))) - (((M31_2) * (cube_252_output_limb_3_col178))))) + (M31_4974792))) - (combination_limb_3_col188))) * (M31_16));let carry_4_tmp_3806f_97 = ((((((((((((carry_3_tmp_3806f_96) + (((M31_4) * (poseidon_full_round_chain_output_limb_4_col128))))) + (((M31_2) * (cube_252_output_limb_4_col158))))) - (((M31_2) * (cube_252_output_limb_4_col179))))) + (M31_59852719))) - (combination_limb_4_col189))) * (M31_16));let carry_5_tmp_3806f_98 = ((((((((((((carry_4_tmp_3806f_97) + (((M31_4) * (poseidon_full_round_chain_output_limb_5_col129))))) + (((M31_2) * (cube_252_output_limb_5_col159))))) - (((M31_2) * (cube_252_output_limb_5_col180))))) + (M31_120369218))) - (combination_limb_5_col190))) * (M31_16));let carry_6_tmp_3806f_99 = ((((((((((((carry_5_tmp_3806f_98) + (((M31_4) * (poseidon_full_round_chain_output_limb_6_col130))))) + (((M31_2) * (cube_252_output_limb_6_col160))))) - (((M31_2) * (cube_252_output_limb_6_col181))))) + (M31_62439890))) - (combination_limb_6_col191))) * (M31_16));let carry_7_tmp_3806f_100 = ((((((((((((((carry_6_tmp_3806f_99) + (((M31_4) * (poseidon_full_round_chain_output_limb_7_col131))))) + (((M31_2) * (cube_252_output_limb_7_col161))))) - (((M31_2) * (cube_252_output_limb_7_col182))))) + (M31_50468641))) - (combination_limb_7_col192))) - (((p_coef_col195) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_101 = ((((((((((((carry_7_tmp_3806f_100) + (((M31_4) * (poseidon_full_round_chain_output_limb_8_col132))))) + (((M31_2) * (cube_252_output_limb_8_col162))))) - (((M31_2) * (cube_252_output_limb_8_col183))))) + (M31_86573645))) - (combination_limb_8_col193))) * (M31_16));*sub_component_inputs.range_check_4_4_4_4[0] =
                [((p_coef_col195) + (M31_3)), ((carry_0_tmp_3806f_93) + (M31_3)), ((carry_1_tmp_3806f_94) + (M31_3)), ((carry_2_tmp_3806f_95) + (M31_3))];
            *lookup_data.range_check_4_4_4_4_11 = [M31_1027333874, ((p_coef_col195) + (M31_3)), ((carry_0_tmp_3806f_93) + (M31_3)), ((carry_1_tmp_3806f_94) + (M31_3)), ((carry_2_tmp_3806f_95) + (M31_3))];*sub_component_inputs.range_check_4_4_4_4[1] =
                [((carry_3_tmp_3806f_96) + (M31_3)), ((carry_4_tmp_3806f_97) + (M31_3)), ((carry_5_tmp_3806f_98) + (M31_3)), ((carry_6_tmp_3806f_99) + (M31_3))];
            *lookup_data.range_check_4_4_4_4_12 = [M31_1027333874, ((carry_3_tmp_3806f_96) + (M31_3)), ((carry_4_tmp_3806f_97) + (M31_3)), ((carry_5_tmp_3806f_98) + (M31_3)), ((carry_6_tmp_3806f_99) + (M31_3))];*sub_component_inputs.range_check_4_4[0] =
                [((carry_7_tmp_3806f_100) + (M31_3)), ((carry_8_tmp_3806f_101) + (M31_3))];
            *lookup_data.range_check_4_4_13 = [M31_1651211826, ((carry_7_tmp_3806f_100) + (M31_3)), ((carry_8_tmp_3806f_101) + (M31_3))];let linear_combination_n_4_coefs_4_2_m2_1_output_tmp_3806f_102 = combination_tmp_3806f_91;

            *lookup_data.poseidon_3_partial_rounds_chain_14 = [M31_1343313504, seq, M31_4, cube_252_output_limb_0_col154, cube_252_output_limb_1_col155, cube_252_output_limb_2_col156, cube_252_output_limb_3_col157, cube_252_output_limb_4_col158, cube_252_output_limb_5_col159, cube_252_output_limb_6_col160, cube_252_output_limb_7_col161, cube_252_output_limb_8_col162, cube_252_output_limb_9_col163, combination_limb_0_col164, combination_limb_1_col165, combination_limb_2_col166, combination_limb_3_col167, combination_limb_4_col168, combination_limb_5_col169, combination_limb_6_col170, combination_limb_7_col171, combination_limb_8_col172, combination_limb_9_col173, cube_252_output_limb_0_col175, cube_252_output_limb_1_col176, cube_252_output_limb_2_col177, cube_252_output_limb_3_col178, cube_252_output_limb_4_col179, cube_252_output_limb_5_col180, cube_252_output_limb_6_col181, cube_252_output_limb_7_col182, cube_252_output_limb_8_col183, cube_252_output_limb_9_col184, combination_limb_0_col185, combination_limb_1_col186, combination_limb_2_col187, combination_limb_3_col188, combination_limb_4_col189, combination_limb_5_col190, combination_limb_6_col191, combination_limb_7_col192, combination_limb_8_col193, combination_limb_9_col194];*sub_component_inputs.poseidon_3_partial_rounds_chain[0] =
                (seq, M31_4, [cube_252_output_tmp_3806f_77, linear_combination_n_4_coefs_1_1_m2_1_output_tmp_3806f_89, cube_252_output_tmp_3806f_90, linear_combination_n_4_coefs_4_2_m2_1_output_tmp_3806f_102]);
            let poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_4, [cube_252_output_tmp_3806f_77, linear_combination_n_4_coefs_1_1_m2_1_output_tmp_3806f_89, cube_252_output_tmp_3806f_90, linear_combination_n_4_coefs_4_2_m2_1_output_tmp_3806f_102]));*sub_component_inputs.poseidon_3_partial_rounds_chain[1] =
                (seq, M31_5, [poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[0], poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[1], poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[2], poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_5, [poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[0], poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[1], poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[2], poseidon_3_partial_rounds_chain_output_round_4_tmp_3806f_104.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[2] =
                (seq, M31_6, [poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[0], poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[1], poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[2], poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_6, [poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[0], poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[1], poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[2], poseidon_3_partial_rounds_chain_output_round_5_tmp_3806f_105.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[3] =
                (seq, M31_7, [poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[0], poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[1], poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[2], poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_7, [poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[0], poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[1], poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[2], poseidon_3_partial_rounds_chain_output_round_6_tmp_3806f_106.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[4] =
                (seq, M31_8, [poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[0], poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[1], poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[2], poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_8, [poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[0], poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[1], poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[2], poseidon_3_partial_rounds_chain_output_round_7_tmp_3806f_107.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[5] =
                (seq, M31_9, [poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[0], poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[1], poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[2], poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_9, [poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[0], poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[1], poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[2], poseidon_3_partial_rounds_chain_output_round_8_tmp_3806f_108.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[6] =
                (seq, M31_10, [poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[0], poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[1], poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[2], poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_10, [poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[0], poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[1], poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[2], poseidon_3_partial_rounds_chain_output_round_9_tmp_3806f_109.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[7] =
                (seq, M31_11, [poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[0], poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[1], poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[2], poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_11, [poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[0], poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[1], poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[2], poseidon_3_partial_rounds_chain_output_round_10_tmp_3806f_110.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[8] =
                (seq, M31_12, [poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[0], poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[1], poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[2], poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_12, [poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[0], poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[1], poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[2], poseidon_3_partial_rounds_chain_output_round_11_tmp_3806f_111.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[9] =
                (seq, M31_13, [poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[0], poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[1], poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[2], poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_13, [poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[0], poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[1], poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[2], poseidon_3_partial_rounds_chain_output_round_12_tmp_3806f_112.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[10] =
                (seq, M31_14, [poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[0], poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[1], poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[2], poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_14, [poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[0], poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[1], poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[2], poseidon_3_partial_rounds_chain_output_round_13_tmp_3806f_113.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[11] =
                (seq, M31_15, [poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[0], poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[1], poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[2], poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_15, [poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[0], poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[1], poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[2], poseidon_3_partial_rounds_chain_output_round_14_tmp_3806f_114.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[12] =
                (seq, M31_16, [poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[0], poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[1], poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[2], poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_16, [poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[0], poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[1], poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[2], poseidon_3_partial_rounds_chain_output_round_15_tmp_3806f_115.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[13] =
                (seq, M31_17, [poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[0], poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[1], poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[2], poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_17, [poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[0], poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[1], poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[2], poseidon_3_partial_rounds_chain_output_round_16_tmp_3806f_116.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[14] =
                (seq, M31_18, [poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[0], poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[1], poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[2], poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_18, [poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[0], poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[1], poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[2], poseidon_3_partial_rounds_chain_output_round_17_tmp_3806f_117.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[15] =
                (seq, M31_19, [poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[0], poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[1], poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[2], poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_19, [poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[0], poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[1], poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[2], poseidon_3_partial_rounds_chain_output_round_18_tmp_3806f_118.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[16] =
                (seq, M31_20, [poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[0], poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[1], poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[2], poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_20, [poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[0], poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[1], poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[2], poseidon_3_partial_rounds_chain_output_round_19_tmp_3806f_119.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[17] =
                (seq, M31_21, [poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[0], poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[1], poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[2], poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_21, [poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[0], poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[1], poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[2], poseidon_3_partial_rounds_chain_output_round_20_tmp_3806f_120.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[18] =
                (seq, M31_22, [poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[0], poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[1], poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[2], poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_22, [poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[0], poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[1], poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[2], poseidon_3_partial_rounds_chain_output_round_21_tmp_3806f_121.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[19] =
                (seq, M31_23, [poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[0], poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[1], poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[2], poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_23, [poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[0], poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[1], poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[2], poseidon_3_partial_rounds_chain_output_round_22_tmp_3806f_122.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[20] =
                (seq, M31_24, [poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[0], poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[1], poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[2], poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_24, [poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[0], poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[1], poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[2], poseidon_3_partial_rounds_chain_output_round_23_tmp_3806f_123.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[21] =
                (seq, M31_25, [poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[0], poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[1], poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[2], poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_25, [poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[0], poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[1], poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[2], poseidon_3_partial_rounds_chain_output_round_24_tmp_3806f_124.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[22] =
                (seq, M31_26, [poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[0], poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[1], poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[2], poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_26, [poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[0], poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[1], poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[2], poseidon_3_partial_rounds_chain_output_round_25_tmp_3806f_125.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[23] =
                (seq, M31_27, [poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[0], poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[1], poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[2], poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_27, [poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[0], poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[1], poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[2], poseidon_3_partial_rounds_chain_output_round_26_tmp_3806f_126.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[24] =
                (seq, M31_28, [poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[0], poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[1], poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[2], poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_28, [poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[0], poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[1], poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[2], poseidon_3_partial_rounds_chain_output_round_27_tmp_3806f_127.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[25] =
                (seq, M31_29, [poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[0], poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[1], poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[2], poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_29, [poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[0], poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[1], poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[2], poseidon_3_partial_rounds_chain_output_round_28_tmp_3806f_128.2[3]]));*sub_component_inputs.poseidon_3_partial_rounds_chain[26] =
                (seq, M31_30, [poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[0], poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[1], poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[2], poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[3]]);
            let poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130 = PackedPoseidon3PartialRoundsChain::deduce_output((seq, M31_30, [poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[0], poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[1], poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[2], poseidon_3_partial_rounds_chain_output_round_29_tmp_3806f_129.2[3]]));let poseidon_3_partial_rounds_chain_output_limb_0_col196 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(0);
            *row[196] = poseidon_3_partial_rounds_chain_output_limb_0_col196;let poseidon_3_partial_rounds_chain_output_limb_1_col197 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(1);
            *row[197] = poseidon_3_partial_rounds_chain_output_limb_1_col197;let poseidon_3_partial_rounds_chain_output_limb_2_col198 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(2);
            *row[198] = poseidon_3_partial_rounds_chain_output_limb_2_col198;let poseidon_3_partial_rounds_chain_output_limb_3_col199 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(3);
            *row[199] = poseidon_3_partial_rounds_chain_output_limb_3_col199;let poseidon_3_partial_rounds_chain_output_limb_4_col200 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(4);
            *row[200] = poseidon_3_partial_rounds_chain_output_limb_4_col200;let poseidon_3_partial_rounds_chain_output_limb_5_col201 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(5);
            *row[201] = poseidon_3_partial_rounds_chain_output_limb_5_col201;let poseidon_3_partial_rounds_chain_output_limb_6_col202 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(6);
            *row[202] = poseidon_3_partial_rounds_chain_output_limb_6_col202;let poseidon_3_partial_rounds_chain_output_limb_7_col203 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(7);
            *row[203] = poseidon_3_partial_rounds_chain_output_limb_7_col203;let poseidon_3_partial_rounds_chain_output_limb_8_col204 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(8);
            *row[204] = poseidon_3_partial_rounds_chain_output_limb_8_col204;let poseidon_3_partial_rounds_chain_output_limb_9_col205 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0].get_m31(9);
            *row[205] = poseidon_3_partial_rounds_chain_output_limb_9_col205;let poseidon_3_partial_rounds_chain_output_limb_10_col206 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(0);
            *row[206] = poseidon_3_partial_rounds_chain_output_limb_10_col206;let poseidon_3_partial_rounds_chain_output_limb_11_col207 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(1);
            *row[207] = poseidon_3_partial_rounds_chain_output_limb_11_col207;let poseidon_3_partial_rounds_chain_output_limb_12_col208 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(2);
            *row[208] = poseidon_3_partial_rounds_chain_output_limb_12_col208;let poseidon_3_partial_rounds_chain_output_limb_13_col209 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(3);
            *row[209] = poseidon_3_partial_rounds_chain_output_limb_13_col209;let poseidon_3_partial_rounds_chain_output_limb_14_col210 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(4);
            *row[210] = poseidon_3_partial_rounds_chain_output_limb_14_col210;let poseidon_3_partial_rounds_chain_output_limb_15_col211 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(5);
            *row[211] = poseidon_3_partial_rounds_chain_output_limb_15_col211;let poseidon_3_partial_rounds_chain_output_limb_16_col212 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(6);
            *row[212] = poseidon_3_partial_rounds_chain_output_limb_16_col212;let poseidon_3_partial_rounds_chain_output_limb_17_col213 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(7);
            *row[213] = poseidon_3_partial_rounds_chain_output_limb_17_col213;let poseidon_3_partial_rounds_chain_output_limb_18_col214 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(8);
            *row[214] = poseidon_3_partial_rounds_chain_output_limb_18_col214;let poseidon_3_partial_rounds_chain_output_limb_19_col215 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1].get_m31(9);
            *row[215] = poseidon_3_partial_rounds_chain_output_limb_19_col215;let poseidon_3_partial_rounds_chain_output_limb_20_col216 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(0);
            *row[216] = poseidon_3_partial_rounds_chain_output_limb_20_col216;let poseidon_3_partial_rounds_chain_output_limb_21_col217 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(1);
            *row[217] = poseidon_3_partial_rounds_chain_output_limb_21_col217;let poseidon_3_partial_rounds_chain_output_limb_22_col218 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(2);
            *row[218] = poseidon_3_partial_rounds_chain_output_limb_22_col218;let poseidon_3_partial_rounds_chain_output_limb_23_col219 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(3);
            *row[219] = poseidon_3_partial_rounds_chain_output_limb_23_col219;let poseidon_3_partial_rounds_chain_output_limb_24_col220 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(4);
            *row[220] = poseidon_3_partial_rounds_chain_output_limb_24_col220;let poseidon_3_partial_rounds_chain_output_limb_25_col221 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(5);
            *row[221] = poseidon_3_partial_rounds_chain_output_limb_25_col221;let poseidon_3_partial_rounds_chain_output_limb_26_col222 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(6);
            *row[222] = poseidon_3_partial_rounds_chain_output_limb_26_col222;let poseidon_3_partial_rounds_chain_output_limb_27_col223 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(7);
            *row[223] = poseidon_3_partial_rounds_chain_output_limb_27_col223;let poseidon_3_partial_rounds_chain_output_limb_28_col224 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(8);
            *row[224] = poseidon_3_partial_rounds_chain_output_limb_28_col224;let poseidon_3_partial_rounds_chain_output_limb_29_col225 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2].get_m31(9);
            *row[225] = poseidon_3_partial_rounds_chain_output_limb_29_col225;let poseidon_3_partial_rounds_chain_output_limb_30_col226 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(0);
            *row[226] = poseidon_3_partial_rounds_chain_output_limb_30_col226;let poseidon_3_partial_rounds_chain_output_limb_31_col227 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(1);
            *row[227] = poseidon_3_partial_rounds_chain_output_limb_31_col227;let poseidon_3_partial_rounds_chain_output_limb_32_col228 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(2);
            *row[228] = poseidon_3_partial_rounds_chain_output_limb_32_col228;let poseidon_3_partial_rounds_chain_output_limb_33_col229 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(3);
            *row[229] = poseidon_3_partial_rounds_chain_output_limb_33_col229;let poseidon_3_partial_rounds_chain_output_limb_34_col230 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(4);
            *row[230] = poseidon_3_partial_rounds_chain_output_limb_34_col230;let poseidon_3_partial_rounds_chain_output_limb_35_col231 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(5);
            *row[231] = poseidon_3_partial_rounds_chain_output_limb_35_col231;let poseidon_3_partial_rounds_chain_output_limb_36_col232 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(6);
            *row[232] = poseidon_3_partial_rounds_chain_output_limb_36_col232;let poseidon_3_partial_rounds_chain_output_limb_37_col233 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(7);
            *row[233] = poseidon_3_partial_rounds_chain_output_limb_37_col233;let poseidon_3_partial_rounds_chain_output_limb_38_col234 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(8);
            *row[234] = poseidon_3_partial_rounds_chain_output_limb_38_col234;let poseidon_3_partial_rounds_chain_output_limb_39_col235 = poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3].get_m31(9);
            *row[235] = poseidon_3_partial_rounds_chain_output_limb_39_col235;*lookup_data.poseidon_3_partial_rounds_chain_15 = [M31_1343313504, seq, M31_31, poseidon_3_partial_rounds_chain_output_limb_0_col196, poseidon_3_partial_rounds_chain_output_limb_1_col197, poseidon_3_partial_rounds_chain_output_limb_2_col198, poseidon_3_partial_rounds_chain_output_limb_3_col199, poseidon_3_partial_rounds_chain_output_limb_4_col200, poseidon_3_partial_rounds_chain_output_limb_5_col201, poseidon_3_partial_rounds_chain_output_limb_6_col202, poseidon_3_partial_rounds_chain_output_limb_7_col203, poseidon_3_partial_rounds_chain_output_limb_8_col204, poseidon_3_partial_rounds_chain_output_limb_9_col205, poseidon_3_partial_rounds_chain_output_limb_10_col206, poseidon_3_partial_rounds_chain_output_limb_11_col207, poseidon_3_partial_rounds_chain_output_limb_12_col208, poseidon_3_partial_rounds_chain_output_limb_13_col209, poseidon_3_partial_rounds_chain_output_limb_14_col210, poseidon_3_partial_rounds_chain_output_limb_15_col211, poseidon_3_partial_rounds_chain_output_limb_16_col212, poseidon_3_partial_rounds_chain_output_limb_17_col213, poseidon_3_partial_rounds_chain_output_limb_18_col214, poseidon_3_partial_rounds_chain_output_limb_19_col215, poseidon_3_partial_rounds_chain_output_limb_20_col216, poseidon_3_partial_rounds_chain_output_limb_21_col217, poseidon_3_partial_rounds_chain_output_limb_22_col218, poseidon_3_partial_rounds_chain_output_limb_23_col219, poseidon_3_partial_rounds_chain_output_limb_24_col220, poseidon_3_partial_rounds_chain_output_limb_25_col221, poseidon_3_partial_rounds_chain_output_limb_26_col222, poseidon_3_partial_rounds_chain_output_limb_27_col223, poseidon_3_partial_rounds_chain_output_limb_28_col224, poseidon_3_partial_rounds_chain_output_limb_29_col225, poseidon_3_partial_rounds_chain_output_limb_30_col226, poseidon_3_partial_rounds_chain_output_limb_31_col227, poseidon_3_partial_rounds_chain_output_limb_32_col228, poseidon_3_partial_rounds_chain_output_limb_33_col229, poseidon_3_partial_rounds_chain_output_limb_34_col230, poseidon_3_partial_rounds_chain_output_limb_35_col231, poseidon_3_partial_rounds_chain_output_limb_36_col232, poseidon_3_partial_rounds_chain_output_limb_37_col233, poseidon_3_partial_rounds_chain_output_limb_38_col234, poseidon_3_partial_rounds_chain_output_limb_39_col235];

            // Linear Combination N 4 Coefs 4 2 1 1.

            let combination_tmp_3806f_131 = PackedFelt252Width27::from_packed_felt252(((((((((Felt252_0_0_0_0) + (((Felt252_4_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[0])))))) + (((Felt252_2_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[1])))))) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2])))))) + (Felt252_3969818800901670911_10562874008078701503_14906396266795319764_223312371439046257)));let combination_limb_0_col236 = combination_tmp_3806f_131.get_m31(0);
            *row[236] = combination_limb_0_col236;let combination_limb_1_col237 = combination_tmp_3806f_131.get_m31(1);
            *row[237] = combination_limb_1_col237;let combination_limb_2_col238 = combination_tmp_3806f_131.get_m31(2);
            *row[238] = combination_limb_2_col238;let combination_limb_3_col239 = combination_tmp_3806f_131.get_m31(3);
            *row[239] = combination_limb_3_col239;let combination_limb_4_col240 = combination_tmp_3806f_131.get_m31(4);
            *row[240] = combination_limb_4_col240;let combination_limb_5_col241 = combination_tmp_3806f_131.get_m31(5);
            *row[241] = combination_limb_5_col241;let combination_limb_6_col242 = combination_tmp_3806f_131.get_m31(6);
            *row[242] = combination_limb_6_col242;let combination_limb_7_col243 = combination_tmp_3806f_131.get_m31(7);
            *row[243] = combination_limb_7_col243;let combination_limb_8_col244 = combination_tmp_3806f_131.get_m31(8);
            *row[244] = combination_limb_8_col244;let combination_limb_9_col245 = combination_tmp_3806f_131.get_m31(9);
            *row[245] = combination_limb_9_col245;let biased_limb_accumulator_u32_tmp_3806f_132 = PackedUInt32::from_m31(((((((((((((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_0_col196))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_10_col206))))) + (poseidon_3_partial_rounds_chain_output_limb_20_col216))) + (M31_40454143))) - (combination_limb_0_col236))) + (M31_134217729)));let p_coef_col246 = ((biased_limb_accumulator_u32_tmp_3806f_132.low().as_m31()) - (M31_1));
            *row[246] = p_coef_col246;let carry_0_tmp_3806f_133 = ((((((((((((((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_0_col196))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_10_col206))))) + (poseidon_3_partial_rounds_chain_output_limb_20_col216))) + (M31_40454143))) - (combination_limb_0_col236))) - (p_coef_col246))) * (M31_16));let carry_1_tmp_3806f_134 = ((((((((((((carry_0_tmp_3806f_133) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_1_col197))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_11_col207))))) + (poseidon_3_partial_rounds_chain_output_limb_21_col217))) + (M31_49554771))) - (combination_limb_1_col237))) * (M31_16));let carry_2_tmp_3806f_135 = ((((((((((((carry_1_tmp_3806f_134) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_2_col198))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_12_col208))))) + (poseidon_3_partial_rounds_chain_output_limb_22_col218))) + (M31_55508188))) - (combination_limb_2_col238))) * (M31_16));let carry_3_tmp_3806f_136 = ((((((((((((carry_2_tmp_3806f_135) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_3_col199))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_13_col209))))) + (poseidon_3_partial_rounds_chain_output_limb_23_col219))) + (M31_116986206))) - (combination_limb_3_col239))) * (M31_16));let carry_4_tmp_3806f_137 = ((((((((((((carry_3_tmp_3806f_136) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_4_col200))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_14_col210))))) + (poseidon_3_partial_rounds_chain_output_limb_24_col220))) + (M31_88680813))) - (combination_limb_4_col240))) * (M31_16));let carry_5_tmp_3806f_138 = ((((((((((((carry_4_tmp_3806f_137) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_5_col201))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_15_col211))))) + (poseidon_3_partial_rounds_chain_output_limb_25_col221))) + (M31_45553283))) - (combination_limb_5_col241))) * (M31_16));let carry_6_tmp_3806f_139 = ((((((((((((carry_5_tmp_3806f_138) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_6_col202))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_16_col212))))) + (poseidon_3_partial_rounds_chain_output_limb_26_col222))) + (M31_62360091))) - (combination_limb_6_col242))) * (M31_16));let carry_7_tmp_3806f_140 = ((((((((((((((carry_6_tmp_3806f_139) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_7_col203))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_17_col213))))) + (poseidon_3_partial_rounds_chain_output_limb_27_col223))) + (M31_77099918))) - (combination_limb_7_col243))) - (((p_coef_col246) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_141 = ((((((((((((carry_7_tmp_3806f_140) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_8_col204))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_18_col214))))) + (poseidon_3_partial_rounds_chain_output_limb_28_col224))) + (M31_22899501))) - (combination_limb_8_col244))) * (M31_16));*sub_component_inputs.range_check_4_4_4_4[2] =
                [((p_coef_col246) + (M31_1)), ((carry_0_tmp_3806f_133) + (M31_1)), ((carry_1_tmp_3806f_134) + (M31_1)), ((carry_2_tmp_3806f_135) + (M31_1))];
            *lookup_data.range_check_4_4_4_4_16 = [M31_1027333874, ((p_coef_col246) + (M31_1)), ((carry_0_tmp_3806f_133) + (M31_1)), ((carry_1_tmp_3806f_134) + (M31_1)), ((carry_2_tmp_3806f_135) + (M31_1))];*sub_component_inputs.range_check_4_4_4_4[3] =
                [((carry_3_tmp_3806f_136) + (M31_1)), ((carry_4_tmp_3806f_137) + (M31_1)), ((carry_5_tmp_3806f_138) + (M31_1)), ((carry_6_tmp_3806f_139) + (M31_1))];
            *lookup_data.range_check_4_4_4_4_17 = [M31_1027333874, ((carry_3_tmp_3806f_136) + (M31_1)), ((carry_4_tmp_3806f_137) + (M31_1)), ((carry_5_tmp_3806f_138) + (M31_1)), ((carry_6_tmp_3806f_139) + (M31_1))];*sub_component_inputs.range_check_4_4[1] =
                [((carry_7_tmp_3806f_140) + (M31_1)), ((carry_8_tmp_3806f_141) + (M31_1))];
            *lookup_data.range_check_4_4_18 = [M31_1651211826, ((carry_7_tmp_3806f_140) + (M31_1)), ((carry_8_tmp_3806f_141) + (M31_1))];let linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_142 = combination_tmp_3806f_131;

            // Linear Combination N 4 Coefs 4 2 1 1.

            let combination_tmp_3806f_143 = PackedFelt252Width27::from_packed_felt252(((((((((Felt252_0_0_0_0) + (((Felt252_4_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[2])))))) + (((Felt252_2_0_0_0) * (PackedFelt252::from_packed_felt252width27(poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3])))))) + (((Felt252_1_0_0_0) * (PackedFelt252::from_packed_felt252width27(linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_142)))))) + (Felt252_10310704347937391837_5874215448258336115_2880320859071049537_45350836576946303)));let combination_limb_0_col247 = combination_tmp_3806f_143.get_m31(0);
            *row[247] = combination_limb_0_col247;let combination_limb_1_col248 = combination_tmp_3806f_143.get_m31(1);
            *row[248] = combination_limb_1_col248;let combination_limb_2_col249 = combination_tmp_3806f_143.get_m31(2);
            *row[249] = combination_limb_2_col249;let combination_limb_3_col250 = combination_tmp_3806f_143.get_m31(3);
            *row[250] = combination_limb_3_col250;let combination_limb_4_col251 = combination_tmp_3806f_143.get_m31(4);
            *row[251] = combination_limb_4_col251;let combination_limb_5_col252 = combination_tmp_3806f_143.get_m31(5);
            *row[252] = combination_limb_5_col252;let combination_limb_6_col253 = combination_tmp_3806f_143.get_m31(6);
            *row[253] = combination_limb_6_col253;let combination_limb_7_col254 = combination_tmp_3806f_143.get_m31(7);
            *row[254] = combination_limb_7_col254;let combination_limb_8_col255 = combination_tmp_3806f_143.get_m31(8);
            *row[255] = combination_limb_8_col255;let combination_limb_9_col256 = combination_tmp_3806f_143.get_m31(9);
            *row[256] = combination_limb_9_col256;let biased_limb_accumulator_u32_tmp_3806f_144 = PackedUInt32::from_m31(((((((((((((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_20_col216))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_30_col226))))) + (combination_limb_0_col236))) + (M31_48383197))) - (combination_limb_0_col247))) + (M31_134217729)));let p_coef_col257 = ((biased_limb_accumulator_u32_tmp_3806f_144.low().as_m31()) - (M31_1));
            *row[257] = p_coef_col257;let carry_0_tmp_3806f_145 = ((((((((((((((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_20_col216))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_30_col226))))) + (combination_limb_0_col236))) + (M31_48383197))) - (combination_limb_0_col247))) - (p_coef_col257))) * (M31_16));let carry_1_tmp_3806f_146 = ((((((((((((carry_0_tmp_3806f_145) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_21_col217))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_31_col227))))) + (combination_limb_1_col237))) + (M31_48193339))) - (combination_limb_1_col248))) * (M31_16));let carry_2_tmp_3806f_147 = ((((((((((((carry_1_tmp_3806f_146) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_22_col218))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_32_col228))))) + (combination_limb_2_col238))) + (M31_55955004))) - (combination_limb_2_col249))) * (M31_16));let carry_3_tmp_3806f_148 = ((((((((((((carry_2_tmp_3806f_147) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_23_col219))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_33_col229))))) + (combination_limb_3_col239))) + (M31_65659846))) - (combination_limb_3_col250))) * (M31_16));let carry_4_tmp_3806f_149 = ((((((((((((carry_3_tmp_3806f_148) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_24_col220))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_34_col230))))) + (combination_limb_4_col240))) + (M31_68491350))) - (combination_limb_4_col251))) * (M31_16));let carry_5_tmp_3806f_150 = ((((((((((((carry_4_tmp_3806f_149) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_25_col221))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_35_col231))))) + (combination_limb_5_col241))) + (M31_119023582))) - (combination_limb_5_col252))) * (M31_16));let carry_6_tmp_3806f_151 = ((((((((((((carry_5_tmp_3806f_150) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_26_col222))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_36_col232))))) + (combination_limb_6_col242))) + (M31_33439011))) - (combination_limb_6_col253))) * (M31_16));let carry_7_tmp_3806f_152 = ((((((((((((((carry_6_tmp_3806f_151) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_27_col223))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_37_col233))))) + (combination_limb_7_col243))) + (M31_58475513))) - (combination_limb_7_col254))) - (((p_coef_col257) * (M31_136))))) * (M31_16));let carry_8_tmp_3806f_153 = ((((((((((((carry_7_tmp_3806f_152) + (((M31_4) * (poseidon_3_partial_rounds_chain_output_limb_28_col224))))) + (((M31_2) * (poseidon_3_partial_rounds_chain_output_limb_38_col234))))) + (combination_limb_8_col244))) + (M31_18765944))) - (combination_limb_8_col255))) * (M31_16));*sub_component_inputs.range_check_4_4_4_4[4] =
                [((p_coef_col257) + (M31_1)), ((carry_0_tmp_3806f_145) + (M31_1)), ((carry_1_tmp_3806f_146) + (M31_1)), ((carry_2_tmp_3806f_147) + (M31_1))];
            *lookup_data.range_check_4_4_4_4_19 = [M31_1027333874, ((p_coef_col257) + (M31_1)), ((carry_0_tmp_3806f_145) + (M31_1)), ((carry_1_tmp_3806f_146) + (M31_1)), ((carry_2_tmp_3806f_147) + (M31_1))];*sub_component_inputs.range_check_4_4_4_4[5] =
                [((carry_3_tmp_3806f_148) + (M31_1)), ((carry_4_tmp_3806f_149) + (M31_1)), ((carry_5_tmp_3806f_150) + (M31_1)), ((carry_6_tmp_3806f_151) + (M31_1))];
            *lookup_data.range_check_4_4_4_4_20 = [M31_1027333874, ((carry_3_tmp_3806f_148) + (M31_1)), ((carry_4_tmp_3806f_149) + (M31_1)), ((carry_5_tmp_3806f_150) + (M31_1)), ((carry_6_tmp_3806f_151) + (M31_1))];*sub_component_inputs.range_check_4_4[2] =
                [((carry_7_tmp_3806f_152) + (M31_1)), ((carry_8_tmp_3806f_153) + (M31_1))];
            *lookup_data.range_check_4_4_21 = [M31_1651211826, ((carry_7_tmp_3806f_152) + (M31_1)), ((carry_8_tmp_3806f_153) + (M31_1))];let linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_154 = combination_tmp_3806f_143;

            let poseidon_full_round_chain_chain_id_tmp_3806f_155 = ((poseidon_full_round_chain_chain_tmp_tmp_3806f_72) + (M31_1));*lookup_data.poseidon_full_round_chain_22 = [M31_1480369132, poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_31, combination_limb_0_col247, combination_limb_1_col248, combination_limb_2_col249, combination_limb_3_col250, combination_limb_4_col251, combination_limb_5_col252, combination_limb_6_col253, combination_limb_7_col254, combination_limb_8_col255, combination_limb_9_col256, combination_limb_0_col236, combination_limb_1_col237, combination_limb_2_col238, combination_limb_3_col239, combination_limb_4_col240, combination_limb_5_col241, combination_limb_6_col242, combination_limb_7_col243, combination_limb_8_col244, combination_limb_9_col245, poseidon_3_partial_rounds_chain_output_limb_30_col226, poseidon_3_partial_rounds_chain_output_limb_31_col227, poseidon_3_partial_rounds_chain_output_limb_32_col228, poseidon_3_partial_rounds_chain_output_limb_33_col229, poseidon_3_partial_rounds_chain_output_limb_34_col230, poseidon_3_partial_rounds_chain_output_limb_35_col231, poseidon_3_partial_rounds_chain_output_limb_36_col232, poseidon_3_partial_rounds_chain_output_limb_37_col233, poseidon_3_partial_rounds_chain_output_limb_38_col234, poseidon_3_partial_rounds_chain_output_limb_39_col235];*sub_component_inputs.poseidon_full_round_chain[4] =
                (poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_31, [linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_154, linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_142, poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3]]);
            let poseidon_full_round_chain_output_round_31_tmp_3806f_156 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_31, [linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_154, linear_combination_n_4_coefs_4_2_1_1_output_tmp_3806f_142, poseidon_3_partial_rounds_chain_output_round_30_tmp_3806f_130.2[3]]));*sub_component_inputs.poseidon_full_round_chain[5] =
                (poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_32, [poseidon_full_round_chain_output_round_31_tmp_3806f_156.2[0], poseidon_full_round_chain_output_round_31_tmp_3806f_156.2[1], poseidon_full_round_chain_output_round_31_tmp_3806f_156.2[2]]);
            let poseidon_full_round_chain_output_round_32_tmp_3806f_157 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_32, [poseidon_full_round_chain_output_round_31_tmp_3806f_156.2[0], poseidon_full_round_chain_output_round_31_tmp_3806f_156.2[1], poseidon_full_round_chain_output_round_31_tmp_3806f_156.2[2]]));*sub_component_inputs.poseidon_full_round_chain[6] =
                (poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_33, [poseidon_full_round_chain_output_round_32_tmp_3806f_157.2[0], poseidon_full_round_chain_output_round_32_tmp_3806f_157.2[1], poseidon_full_round_chain_output_round_32_tmp_3806f_157.2[2]]);
            let poseidon_full_round_chain_output_round_33_tmp_3806f_158 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_33, [poseidon_full_round_chain_output_round_32_tmp_3806f_157.2[0], poseidon_full_round_chain_output_round_32_tmp_3806f_157.2[1], poseidon_full_round_chain_output_round_32_tmp_3806f_157.2[2]]));*sub_component_inputs.poseidon_full_round_chain[7] =
                (poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_34, [poseidon_full_round_chain_output_round_33_tmp_3806f_158.2[0], poseidon_full_round_chain_output_round_33_tmp_3806f_158.2[1], poseidon_full_round_chain_output_round_33_tmp_3806f_158.2[2]]);
            let poseidon_full_round_chain_output_round_34_tmp_3806f_159 = PackedPoseidonFullRoundChain::deduce_output((poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_34, [poseidon_full_round_chain_output_round_33_tmp_3806f_158.2[0], poseidon_full_round_chain_output_round_33_tmp_3806f_158.2[1], poseidon_full_round_chain_output_round_33_tmp_3806f_158.2[2]]));let poseidon_full_round_chain_output_limb_0_col258 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(0);
            *row[258] = poseidon_full_round_chain_output_limb_0_col258;let poseidon_full_round_chain_output_limb_1_col259 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(1);
            *row[259] = poseidon_full_round_chain_output_limb_1_col259;let poseidon_full_round_chain_output_limb_2_col260 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(2);
            *row[260] = poseidon_full_round_chain_output_limb_2_col260;let poseidon_full_round_chain_output_limb_3_col261 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(3);
            *row[261] = poseidon_full_round_chain_output_limb_3_col261;let poseidon_full_round_chain_output_limb_4_col262 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(4);
            *row[262] = poseidon_full_round_chain_output_limb_4_col262;let poseidon_full_round_chain_output_limb_5_col263 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(5);
            *row[263] = poseidon_full_round_chain_output_limb_5_col263;let poseidon_full_round_chain_output_limb_6_col264 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(6);
            *row[264] = poseidon_full_round_chain_output_limb_6_col264;let poseidon_full_round_chain_output_limb_7_col265 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(7);
            *row[265] = poseidon_full_round_chain_output_limb_7_col265;let poseidon_full_round_chain_output_limb_8_col266 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(8);
            *row[266] = poseidon_full_round_chain_output_limb_8_col266;let poseidon_full_round_chain_output_limb_9_col267 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0].get_m31(9);
            *row[267] = poseidon_full_round_chain_output_limb_9_col267;let poseidon_full_round_chain_output_limb_10_col268 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(0);
            *row[268] = poseidon_full_round_chain_output_limb_10_col268;let poseidon_full_round_chain_output_limb_11_col269 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(1);
            *row[269] = poseidon_full_round_chain_output_limb_11_col269;let poseidon_full_round_chain_output_limb_12_col270 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(2);
            *row[270] = poseidon_full_round_chain_output_limb_12_col270;let poseidon_full_round_chain_output_limb_13_col271 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(3);
            *row[271] = poseidon_full_round_chain_output_limb_13_col271;let poseidon_full_round_chain_output_limb_14_col272 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(4);
            *row[272] = poseidon_full_round_chain_output_limb_14_col272;let poseidon_full_round_chain_output_limb_15_col273 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(5);
            *row[273] = poseidon_full_round_chain_output_limb_15_col273;let poseidon_full_round_chain_output_limb_16_col274 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(6);
            *row[274] = poseidon_full_round_chain_output_limb_16_col274;let poseidon_full_round_chain_output_limb_17_col275 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(7);
            *row[275] = poseidon_full_round_chain_output_limb_17_col275;let poseidon_full_round_chain_output_limb_18_col276 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(8);
            *row[276] = poseidon_full_round_chain_output_limb_18_col276;let poseidon_full_round_chain_output_limb_19_col277 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1].get_m31(9);
            *row[277] = poseidon_full_round_chain_output_limb_19_col277;let poseidon_full_round_chain_output_limb_20_col278 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(0);
            *row[278] = poseidon_full_round_chain_output_limb_20_col278;let poseidon_full_round_chain_output_limb_21_col279 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(1);
            *row[279] = poseidon_full_round_chain_output_limb_21_col279;let poseidon_full_round_chain_output_limb_22_col280 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(2);
            *row[280] = poseidon_full_round_chain_output_limb_22_col280;let poseidon_full_round_chain_output_limb_23_col281 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(3);
            *row[281] = poseidon_full_round_chain_output_limb_23_col281;let poseidon_full_round_chain_output_limb_24_col282 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(4);
            *row[282] = poseidon_full_round_chain_output_limb_24_col282;let poseidon_full_round_chain_output_limb_25_col283 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(5);
            *row[283] = poseidon_full_round_chain_output_limb_25_col283;let poseidon_full_round_chain_output_limb_26_col284 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(6);
            *row[284] = poseidon_full_round_chain_output_limb_26_col284;let poseidon_full_round_chain_output_limb_27_col285 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(7);
            *row[285] = poseidon_full_round_chain_output_limb_27_col285;let poseidon_full_round_chain_output_limb_28_col286 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(8);
            *row[286] = poseidon_full_round_chain_output_limb_28_col286;let poseidon_full_round_chain_output_limb_29_col287 = poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2].get_m31(9);
            *row[287] = poseidon_full_round_chain_output_limb_29_col287;*lookup_data.poseidon_full_round_chain_23 = [M31_1480369132, poseidon_full_round_chain_chain_id_tmp_3806f_155, M31_35, poseidon_full_round_chain_output_limb_0_col258, poseidon_full_round_chain_output_limb_1_col259, poseidon_full_round_chain_output_limb_2_col260, poseidon_full_round_chain_output_limb_3_col261, poseidon_full_round_chain_output_limb_4_col262, poseidon_full_round_chain_output_limb_5_col263, poseidon_full_round_chain_output_limb_6_col264, poseidon_full_round_chain_output_limb_7_col265, poseidon_full_round_chain_output_limb_8_col266, poseidon_full_round_chain_output_limb_9_col267, poseidon_full_round_chain_output_limb_10_col268, poseidon_full_round_chain_output_limb_11_col269, poseidon_full_round_chain_output_limb_12_col270, poseidon_full_round_chain_output_limb_13_col271, poseidon_full_round_chain_output_limb_14_col272, poseidon_full_round_chain_output_limb_15_col273, poseidon_full_round_chain_output_limb_16_col274, poseidon_full_round_chain_output_limb_17_col275, poseidon_full_round_chain_output_limb_18_col276, poseidon_full_round_chain_output_limb_19_col277, poseidon_full_round_chain_output_limb_20_col278, poseidon_full_round_chain_output_limb_21_col279, poseidon_full_round_chain_output_limb_22_col280, poseidon_full_round_chain_output_limb_23_col281, poseidon_full_round_chain_output_limb_24_col282, poseidon_full_round_chain_output_limb_25_col283, poseidon_full_round_chain_output_limb_26_col284, poseidon_full_round_chain_output_limb_27_col285, poseidon_full_round_chain_output_limb_28_col286, poseidon_full_round_chain_output_limb_29_col287];let poseidon_hades_permutation_output_tmp_3806f_160 = [poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[0], poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[1], poseidon_full_round_chain_output_round_34_tmp_3806f_159.2[2]];

            // Felt 252 Unpack From 27.

            let input_as_felt252_tmp_3806f_161 = PackedFelt252::from_packed_felt252width27(poseidon_hades_permutation_output_tmp_3806f_160[0]);let unpacked_limb_0_col288 = input_as_felt252_tmp_3806f_161.get_m31(0);
            *row[288] = unpacked_limb_0_col288;let unpacked_limb_1_col289 = input_as_felt252_tmp_3806f_161.get_m31(1);
            *row[289] = unpacked_limb_1_col289;let unpacked_limb_3_col290 = input_as_felt252_tmp_3806f_161.get_m31(3);
            *row[290] = unpacked_limb_3_col290;let unpacked_limb_4_col291 = input_as_felt252_tmp_3806f_161.get_m31(4);
            *row[291] = unpacked_limb_4_col291;let unpacked_limb_6_col292 = input_as_felt252_tmp_3806f_161.get_m31(6);
            *row[292] = unpacked_limb_6_col292;let unpacked_limb_7_col293 = input_as_felt252_tmp_3806f_161.get_m31(7);
            *row[293] = unpacked_limb_7_col293;let unpacked_limb_9_col294 = input_as_felt252_tmp_3806f_161.get_m31(9);
            *row[294] = unpacked_limb_9_col294;let unpacked_limb_10_col295 = input_as_felt252_tmp_3806f_161.get_m31(10);
            *row[295] = unpacked_limb_10_col295;let unpacked_limb_12_col296 = input_as_felt252_tmp_3806f_161.get_m31(12);
            *row[296] = unpacked_limb_12_col296;let unpacked_limb_13_col297 = input_as_felt252_tmp_3806f_161.get_m31(13);
            *row[297] = unpacked_limb_13_col297;let unpacked_limb_15_col298 = input_as_felt252_tmp_3806f_161.get_m31(15);
            *row[298] = unpacked_limb_15_col298;let unpacked_limb_16_col299 = input_as_felt252_tmp_3806f_161.get_m31(16);
            *row[299] = unpacked_limb_16_col299;let unpacked_limb_18_col300 = input_as_felt252_tmp_3806f_161.get_m31(18);
            *row[300] = unpacked_limb_18_col300;let unpacked_limb_19_col301 = input_as_felt252_tmp_3806f_161.get_m31(19);
            *row[301] = unpacked_limb_19_col301;let unpacked_limb_21_col302 = input_as_felt252_tmp_3806f_161.get_m31(21);
            *row[302] = unpacked_limb_21_col302;let unpacked_limb_22_col303 = input_as_felt252_tmp_3806f_161.get_m31(22);
            *row[303] = unpacked_limb_22_col303;let unpacked_limb_24_col304 = input_as_felt252_tmp_3806f_161.get_m31(24);
            *row[304] = unpacked_limb_24_col304;let unpacked_limb_25_col305 = input_as_felt252_tmp_3806f_161.get_m31(25);
            *row[305] = unpacked_limb_25_col305;let felt_252_unpack_from_27_output_tmp_3806f_162 = PackedFelt252::from_limbs([unpacked_limb_0_col288, unpacked_limb_1_col289, ((((((poseidon_full_round_chain_output_limb_0_col258) - (unpacked_limb_0_col288))) - (((unpacked_limb_1_col289) * (M31_512))))) * (M31_8192)), unpacked_limb_3_col290, unpacked_limb_4_col291, ((((((poseidon_full_round_chain_output_limb_1_col259) - (unpacked_limb_3_col290))) - (((unpacked_limb_4_col291) * (M31_512))))) * (M31_8192)), unpacked_limb_6_col292, unpacked_limb_7_col293, ((((((poseidon_full_round_chain_output_limb_2_col260) - (unpacked_limb_6_col292))) - (((unpacked_limb_7_col293) * (M31_512))))) * (M31_8192)), unpacked_limb_9_col294, unpacked_limb_10_col295, ((((((poseidon_full_round_chain_output_limb_3_col261) - (unpacked_limb_9_col294))) - (((unpacked_limb_10_col295) * (M31_512))))) * (M31_8192)), unpacked_limb_12_col296, unpacked_limb_13_col297, ((((((poseidon_full_round_chain_output_limb_4_col262) - (unpacked_limb_12_col296))) - (((unpacked_limb_13_col297) * (M31_512))))) * (M31_8192)), unpacked_limb_15_col298, unpacked_limb_16_col299, ((((((poseidon_full_round_chain_output_limb_5_col263) - (unpacked_limb_15_col298))) - (((unpacked_limb_16_col299) * (M31_512))))) * (M31_8192)), unpacked_limb_18_col300, unpacked_limb_19_col301, ((((((poseidon_full_round_chain_output_limb_6_col264) - (unpacked_limb_18_col300))) - (((unpacked_limb_19_col301) * (M31_512))))) * (M31_8192)), unpacked_limb_21_col302, unpacked_limb_22_col303, ((((((poseidon_full_round_chain_output_limb_7_col265) - (unpacked_limb_21_col302))) - (((unpacked_limb_22_col303) * (M31_512))))) * (M31_8192)), unpacked_limb_24_col304, unpacked_limb_25_col305, ((((((poseidon_full_round_chain_output_limb_8_col266) - (unpacked_limb_24_col304))) - (((unpacked_limb_25_col305) * (M31_512))))) * (M31_8192)), poseidon_full_round_chain_output_limb_9_col267]);

            *sub_component_inputs.memory_id_to_big[3] =
                input_limb_3_col4;
            *lookup_data.memory_id_to_big_24 = [M31_1662111297, input_limb_3_col4, unpacked_limb_0_col288, unpacked_limb_1_col289, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(2), unpacked_limb_3_col290, unpacked_limb_4_col291, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(5), unpacked_limb_6_col292, unpacked_limb_7_col293, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(8), unpacked_limb_9_col294, unpacked_limb_10_col295, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(11), unpacked_limb_12_col296, unpacked_limb_13_col297, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(14), unpacked_limb_15_col298, unpacked_limb_16_col299, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(17), unpacked_limb_18_col300, unpacked_limb_19_col301, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(20), unpacked_limb_21_col302, unpacked_limb_22_col303, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(23), unpacked_limb_24_col304, unpacked_limb_25_col305, felt_252_unpack_from_27_output_tmp_3806f_162.get_m31(26), poseidon_full_round_chain_output_limb_9_col267];

            // Felt 252 Unpack From 27.

            let input_as_felt252_tmp_3806f_163 = PackedFelt252::from_packed_felt252width27(poseidon_hades_permutation_output_tmp_3806f_160[1]);let unpacked_limb_0_col306 = input_as_felt252_tmp_3806f_163.get_m31(0);
            *row[306] = unpacked_limb_0_col306;let unpacked_limb_1_col307 = input_as_felt252_tmp_3806f_163.get_m31(1);
            *row[307] = unpacked_limb_1_col307;let unpacked_limb_3_col308 = input_as_felt252_tmp_3806f_163.get_m31(3);
            *row[308] = unpacked_limb_3_col308;let unpacked_limb_4_col309 = input_as_felt252_tmp_3806f_163.get_m31(4);
            *row[309] = unpacked_limb_4_col309;let unpacked_limb_6_col310 = input_as_felt252_tmp_3806f_163.get_m31(6);
            *row[310] = unpacked_limb_6_col310;let unpacked_limb_7_col311 = input_as_felt252_tmp_3806f_163.get_m31(7);
            *row[311] = unpacked_limb_7_col311;let unpacked_limb_9_col312 = input_as_felt252_tmp_3806f_163.get_m31(9);
            *row[312] = unpacked_limb_9_col312;let unpacked_limb_10_col313 = input_as_felt252_tmp_3806f_163.get_m31(10);
            *row[313] = unpacked_limb_10_col313;let unpacked_limb_12_col314 = input_as_felt252_tmp_3806f_163.get_m31(12);
            *row[314] = unpacked_limb_12_col314;let unpacked_limb_13_col315 = input_as_felt252_tmp_3806f_163.get_m31(13);
            *row[315] = unpacked_limb_13_col315;let unpacked_limb_15_col316 = input_as_felt252_tmp_3806f_163.get_m31(15);
            *row[316] = unpacked_limb_15_col316;let unpacked_limb_16_col317 = input_as_felt252_tmp_3806f_163.get_m31(16);
            *row[317] = unpacked_limb_16_col317;let unpacked_limb_18_col318 = input_as_felt252_tmp_3806f_163.get_m31(18);
            *row[318] = unpacked_limb_18_col318;let unpacked_limb_19_col319 = input_as_felt252_tmp_3806f_163.get_m31(19);
            *row[319] = unpacked_limb_19_col319;let unpacked_limb_21_col320 = input_as_felt252_tmp_3806f_163.get_m31(21);
            *row[320] = unpacked_limb_21_col320;let unpacked_limb_22_col321 = input_as_felt252_tmp_3806f_163.get_m31(22);
            *row[321] = unpacked_limb_22_col321;let unpacked_limb_24_col322 = input_as_felt252_tmp_3806f_163.get_m31(24);
            *row[322] = unpacked_limb_24_col322;let unpacked_limb_25_col323 = input_as_felt252_tmp_3806f_163.get_m31(25);
            *row[323] = unpacked_limb_25_col323;let felt_252_unpack_from_27_output_tmp_3806f_164 = PackedFelt252::from_limbs([unpacked_limb_0_col306, unpacked_limb_1_col307, ((((((poseidon_full_round_chain_output_limb_10_col268) - (unpacked_limb_0_col306))) - (((unpacked_limb_1_col307) * (M31_512))))) * (M31_8192)), unpacked_limb_3_col308, unpacked_limb_4_col309, ((((((poseidon_full_round_chain_output_limb_11_col269) - (unpacked_limb_3_col308))) - (((unpacked_limb_4_col309) * (M31_512))))) * (M31_8192)), unpacked_limb_6_col310, unpacked_limb_7_col311, ((((((poseidon_full_round_chain_output_limb_12_col270) - (unpacked_limb_6_col310))) - (((unpacked_limb_7_col311) * (M31_512))))) * (M31_8192)), unpacked_limb_9_col312, unpacked_limb_10_col313, ((((((poseidon_full_round_chain_output_limb_13_col271) - (unpacked_limb_9_col312))) - (((unpacked_limb_10_col313) * (M31_512))))) * (M31_8192)), unpacked_limb_12_col314, unpacked_limb_13_col315, ((((((poseidon_full_round_chain_output_limb_14_col272) - (unpacked_limb_12_col314))) - (((unpacked_limb_13_col315) * (M31_512))))) * (M31_8192)), unpacked_limb_15_col316, unpacked_limb_16_col317, ((((((poseidon_full_round_chain_output_limb_15_col273) - (unpacked_limb_15_col316))) - (((unpacked_limb_16_col317) * (M31_512))))) * (M31_8192)), unpacked_limb_18_col318, unpacked_limb_19_col319, ((((((poseidon_full_round_chain_output_limb_16_col274) - (unpacked_limb_18_col318))) - (((unpacked_limb_19_col319) * (M31_512))))) * (M31_8192)), unpacked_limb_21_col320, unpacked_limb_22_col321, ((((((poseidon_full_round_chain_output_limb_17_col275) - (unpacked_limb_21_col320))) - (((unpacked_limb_22_col321) * (M31_512))))) * (M31_8192)), unpacked_limb_24_col322, unpacked_limb_25_col323, ((((((poseidon_full_round_chain_output_limb_18_col276) - (unpacked_limb_24_col322))) - (((unpacked_limb_25_col323) * (M31_512))))) * (M31_8192)), poseidon_full_round_chain_output_limb_19_col277]);

            *sub_component_inputs.memory_id_to_big[4] =
                input_limb_4_col5;
            *lookup_data.memory_id_to_big_25 = [M31_1662111297, input_limb_4_col5, unpacked_limb_0_col306, unpacked_limb_1_col307, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(2), unpacked_limb_3_col308, unpacked_limb_4_col309, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(5), unpacked_limb_6_col310, unpacked_limb_7_col311, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(8), unpacked_limb_9_col312, unpacked_limb_10_col313, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(11), unpacked_limb_12_col314, unpacked_limb_13_col315, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(14), unpacked_limb_15_col316, unpacked_limb_16_col317, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(17), unpacked_limb_18_col318, unpacked_limb_19_col319, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(20), unpacked_limb_21_col320, unpacked_limb_22_col321, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(23), unpacked_limb_24_col322, unpacked_limb_25_col323, felt_252_unpack_from_27_output_tmp_3806f_164.get_m31(26), poseidon_full_round_chain_output_limb_19_col277];

            // Felt 252 Unpack From 27.

            let input_as_felt252_tmp_3806f_165 = PackedFelt252::from_packed_felt252width27(poseidon_hades_permutation_output_tmp_3806f_160[2]);let unpacked_limb_0_col324 = input_as_felt252_tmp_3806f_165.get_m31(0);
            *row[324] = unpacked_limb_0_col324;let unpacked_limb_1_col325 = input_as_felt252_tmp_3806f_165.get_m31(1);
            *row[325] = unpacked_limb_1_col325;let unpacked_limb_3_col326 = input_as_felt252_tmp_3806f_165.get_m31(3);
            *row[326] = unpacked_limb_3_col326;let unpacked_limb_4_col327 = input_as_felt252_tmp_3806f_165.get_m31(4);
            *row[327] = unpacked_limb_4_col327;let unpacked_limb_6_col328 = input_as_felt252_tmp_3806f_165.get_m31(6);
            *row[328] = unpacked_limb_6_col328;let unpacked_limb_7_col329 = input_as_felt252_tmp_3806f_165.get_m31(7);
            *row[329] = unpacked_limb_7_col329;let unpacked_limb_9_col330 = input_as_felt252_tmp_3806f_165.get_m31(9);
            *row[330] = unpacked_limb_9_col330;let unpacked_limb_10_col331 = input_as_felt252_tmp_3806f_165.get_m31(10);
            *row[331] = unpacked_limb_10_col331;let unpacked_limb_12_col332 = input_as_felt252_tmp_3806f_165.get_m31(12);
            *row[332] = unpacked_limb_12_col332;let unpacked_limb_13_col333 = input_as_felt252_tmp_3806f_165.get_m31(13);
            *row[333] = unpacked_limb_13_col333;let unpacked_limb_15_col334 = input_as_felt252_tmp_3806f_165.get_m31(15);
            *row[334] = unpacked_limb_15_col334;let unpacked_limb_16_col335 = input_as_felt252_tmp_3806f_165.get_m31(16);
            *row[335] = unpacked_limb_16_col335;let unpacked_limb_18_col336 = input_as_felt252_tmp_3806f_165.get_m31(18);
            *row[336] = unpacked_limb_18_col336;let unpacked_limb_19_col337 = input_as_felt252_tmp_3806f_165.get_m31(19);
            *row[337] = unpacked_limb_19_col337;let unpacked_limb_21_col338 = input_as_felt252_tmp_3806f_165.get_m31(21);
            *row[338] = unpacked_limb_21_col338;let unpacked_limb_22_col339 = input_as_felt252_tmp_3806f_165.get_m31(22);
            *row[339] = unpacked_limb_22_col339;let unpacked_limb_24_col340 = input_as_felt252_tmp_3806f_165.get_m31(24);
            *row[340] = unpacked_limb_24_col340;let unpacked_limb_25_col341 = input_as_felt252_tmp_3806f_165.get_m31(25);
            *row[341] = unpacked_limb_25_col341;let felt_252_unpack_from_27_output_tmp_3806f_166 = PackedFelt252::from_limbs([unpacked_limb_0_col324, unpacked_limb_1_col325, ((((((poseidon_full_round_chain_output_limb_20_col278) - (unpacked_limb_0_col324))) - (((unpacked_limb_1_col325) * (M31_512))))) * (M31_8192)), unpacked_limb_3_col326, unpacked_limb_4_col327, ((((((poseidon_full_round_chain_output_limb_21_col279) - (unpacked_limb_3_col326))) - (((unpacked_limb_4_col327) * (M31_512))))) * (M31_8192)), unpacked_limb_6_col328, unpacked_limb_7_col329, ((((((poseidon_full_round_chain_output_limb_22_col280) - (unpacked_limb_6_col328))) - (((unpacked_limb_7_col329) * (M31_512))))) * (M31_8192)), unpacked_limb_9_col330, unpacked_limb_10_col331, ((((((poseidon_full_round_chain_output_limb_23_col281) - (unpacked_limb_9_col330))) - (((unpacked_limb_10_col331) * (M31_512))))) * (M31_8192)), unpacked_limb_12_col332, unpacked_limb_13_col333, ((((((poseidon_full_round_chain_output_limb_24_col282) - (unpacked_limb_12_col332))) - (((unpacked_limb_13_col333) * (M31_512))))) * (M31_8192)), unpacked_limb_15_col334, unpacked_limb_16_col335, ((((((poseidon_full_round_chain_output_limb_25_col283) - (unpacked_limb_15_col334))) - (((unpacked_limb_16_col335) * (M31_512))))) * (M31_8192)), unpacked_limb_18_col336, unpacked_limb_19_col337, ((((((poseidon_full_round_chain_output_limb_26_col284) - (unpacked_limb_18_col336))) - (((unpacked_limb_19_col337) * (M31_512))))) * (M31_8192)), unpacked_limb_21_col338, unpacked_limb_22_col339, ((((((poseidon_full_round_chain_output_limb_27_col285) - (unpacked_limb_21_col338))) - (((unpacked_limb_22_col339) * (M31_512))))) * (M31_8192)), unpacked_limb_24_col340, unpacked_limb_25_col341, ((((((poseidon_full_round_chain_output_limb_28_col286) - (unpacked_limb_24_col340))) - (((unpacked_limb_25_col341) * (M31_512))))) * (M31_8192)), poseidon_full_round_chain_output_limb_29_col287]);

            *sub_component_inputs.memory_id_to_big[5] =
                input_limb_5_col6;
            *lookup_data.memory_id_to_big_26 = [M31_1662111297, input_limb_5_col6, unpacked_limb_0_col324, unpacked_limb_1_col325, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(2), unpacked_limb_3_col326, unpacked_limb_4_col327, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(5), unpacked_limb_6_col328, unpacked_limb_7_col329, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(8), unpacked_limb_9_col330, unpacked_limb_10_col331, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(11), unpacked_limb_12_col332, unpacked_limb_13_col333, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(14), unpacked_limb_15_col334, unpacked_limb_16_col335, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(17), unpacked_limb_18_col336, unpacked_limb_19_col337, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(20), unpacked_limb_21_col338, unpacked_limb_22_col339, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(23), unpacked_limb_24_col340, unpacked_limb_25_col341, felt_252_unpack_from_27_output_tmp_3806f_166.get_m31(26), poseidon_full_round_chain_output_limb_29_col287];*lookup_data.poseidon_aggregator_27 = [M31_1551892206, input_limb_0_col1, input_limb_1_col2, input_limb_2_col3, input_limb_3_col4, input_limb_4_col5, input_limb_5_col6];*lookup_data.mults_0 = M31_1;*lookup_data.mults_1 = multiplicity_0_col0;
        });

    (trace, lookup_data, sub_component_inputs)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    memory_id_to_big_0: Vec<[PackedM31; 30]>,
    memory_id_to_big_1: Vec<[PackedM31; 30]>,
    memory_id_to_big_2: Vec<[PackedM31; 30]>,
    poseidon_full_round_chain_3: Vec<[PackedM31; 33]>,
    poseidon_full_round_chain_4: Vec<[PackedM31; 33]>,
    range_check_252_width_27_5: Vec<[PackedM31; 11]>,
    range_check_252_width_27_6: Vec<[PackedM31; 11]>,
    cube_252_7: Vec<[PackedM31; 21]>,
    range_check_3_3_3_3_3_8: Vec<[PackedM31; 6]>,
    range_check_3_3_3_3_3_9: Vec<[PackedM31; 6]>,
    cube_252_10: Vec<[PackedM31; 21]>,
    range_check_4_4_4_4_11: Vec<[PackedM31; 5]>,
    range_check_4_4_4_4_12: Vec<[PackedM31; 5]>,
    range_check_4_4_13: Vec<[PackedM31; 3]>,
    poseidon_3_partial_rounds_chain_14: Vec<[PackedM31; 43]>,
    poseidon_3_partial_rounds_chain_15: Vec<[PackedM31; 43]>,
    range_check_4_4_4_4_16: Vec<[PackedM31; 5]>,
    range_check_4_4_4_4_17: Vec<[PackedM31; 5]>,
    range_check_4_4_18: Vec<[PackedM31; 3]>,
    range_check_4_4_4_4_19: Vec<[PackedM31; 5]>,
    range_check_4_4_4_4_20: Vec<[PackedM31; 5]>,
    range_check_4_4_21: Vec<[PackedM31; 3]>,
    poseidon_full_round_chain_22: Vec<[PackedM31; 33]>,
    poseidon_full_round_chain_23: Vec<[PackedM31; 33]>,
    memory_id_to_big_24: Vec<[PackedM31; 30]>,
    memory_id_to_big_25: Vec<[PackedM31; 30]>,
    memory_id_to_big_26: Vec<[PackedM31; 30]>,
    poseidon_aggregator_27: Vec<[PackedM31; 7]>,
    mults_0: Vec<PackedM31>,
    mults_1: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    log_size: u32,
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(self.log_size) };

        // Sum logup terms in pairs.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_0,
            &self.lookup_data.memory_id_to_big_1,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_2,
            &self.lookup_data.poseidon_full_round_chain_3,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom1 * *mult0 - denom0 * *mult1, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.poseidon_full_round_chain_4,
            &self.lookup_data.range_check_252_width_27_5,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_252_width_27_6,
            &self.lookup_data.cube_252_7,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_3_3_3_3_3_8,
            &self.lookup_data.range_check_3_3_3_3_3_9,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.cube_252_10,
            &self.lookup_data.range_check_4_4_4_4_11,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_4_4_4_4_12,
            &self.lookup_data.range_check_4_4_13,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.poseidon_3_partial_rounds_chain_14,
            &self.lookup_data.poseidon_3_partial_rounds_chain_15,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 - denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_4_4_4_4_16,
            &self.lookup_data.range_check_4_4_4_4_17,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_4_4_18,
            &self.lookup_data.range_check_4_4_4_4_19,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_4_4_4_4_20,
            &self.lookup_data.range_check_4_4_21,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.poseidon_full_round_chain_22,
            &self.lookup_data.poseidon_full_round_chain_23,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 - denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_24,
            &self.lookup_data.memory_id_to_big_25,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_26,
            &self.lookup_data.poseidon_aggregator_27,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_1,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom1 * *mult0 - denom0 * *mult1, denom0 * denom1);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
