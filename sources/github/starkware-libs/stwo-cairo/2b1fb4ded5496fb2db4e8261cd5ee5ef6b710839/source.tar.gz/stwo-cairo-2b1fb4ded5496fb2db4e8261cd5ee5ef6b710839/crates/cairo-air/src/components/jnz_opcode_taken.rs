// This file was created by the AIR team.

use subroutines::decode_instruction_ad440::DecodeInstructionAd440;
use subroutines::read_positive_num_bits_252::ReadPositiveNumBits252;
use subroutines::read_small::ReadSmall;

use crate::components::prelude::*;

pub const N_TRACE_COLUMNS: usize = 47;
pub const RELATION_USES_PER_ROW: [RelationUse; 4] = [
    RelationUse { relation_id: "MemoryAddressToId", uses: 2 },
    RelationUse { relation_id: "MemoryIdToBig", uses: 2 },
    RelationUse { relation_id: "Opcodes", uses: 1 },
    RelationUse { relation_id: "VerifyInstruction", uses: 1 },
];

pub struct Eval {
    pub claim: Claim,
    pub common_lookup_elements: relations::CommonLookupElements,
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct Claim {
    pub log_size: u32,
}
impl Claim {
    pub fn log_sizes(&self) -> TreeVec<Vec<u32>> {
        let trace_log_sizes = vec![self.log_size; N_TRACE_COLUMNS];
        let interaction_log_sizes = vec![self.log_size; SECURE_EXTENSION_DEGREE * 4];
        TreeVec::new(vec![trace_log_sizes, interaction_log_sizes])
    }
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct InteractionClaim {
    pub claimed_sum: SecureField,
}

pub type Component = FrameworkComponent<Eval>;

impl FrameworkEval for Eval {
    fn log_size(&self) -> u32 {
        self.claim.log_size
    }

    fn max_constraint_log_degree_bound(&self) -> u32 {
        self.log_size() + 1
    }

    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    fn evaluate<E: EvalAtRow>(&self, mut eval: E) -> E {
        let M31_1 = E::F::from(M31::from(1));
        let M31_136 = E::F::from(M31::from(136));
        let M31_256 = E::F::from(M31::from(256));
        let M31_428564188 = E::F::from(M31::from(428564188));
        let enabler_col0 = eval.next_trace_mask();
        let input_pc_col1 = eval.next_trace_mask();
        let input_ap_col2 = eval.next_trace_mask();
        let input_fp_col3 = eval.next_trace_mask();
        let offset0_col4 = eval.next_trace_mask();
        let dst_base_fp_col5 = eval.next_trace_mask();
        let ap_update_add_1_col6 = eval.next_trace_mask();
        let mem_dst_base_col7 = eval.next_trace_mask();
        let dst_id_col8 = eval.next_trace_mask();
        let dst_limb_0_col9 = eval.next_trace_mask();
        let dst_limb_1_col10 = eval.next_trace_mask();
        let dst_limb_2_col11 = eval.next_trace_mask();
        let dst_limb_3_col12 = eval.next_trace_mask();
        let dst_limb_4_col13 = eval.next_trace_mask();
        let dst_limb_5_col14 = eval.next_trace_mask();
        let dst_limb_6_col15 = eval.next_trace_mask();
        let dst_limb_7_col16 = eval.next_trace_mask();
        let dst_limb_8_col17 = eval.next_trace_mask();
        let dst_limb_9_col18 = eval.next_trace_mask();
        let dst_limb_10_col19 = eval.next_trace_mask();
        let dst_limb_11_col20 = eval.next_trace_mask();
        let dst_limb_12_col21 = eval.next_trace_mask();
        let dst_limb_13_col22 = eval.next_trace_mask();
        let dst_limb_14_col23 = eval.next_trace_mask();
        let dst_limb_15_col24 = eval.next_trace_mask();
        let dst_limb_16_col25 = eval.next_trace_mask();
        let dst_limb_17_col26 = eval.next_trace_mask();
        let dst_limb_18_col27 = eval.next_trace_mask();
        let dst_limb_19_col28 = eval.next_trace_mask();
        let dst_limb_20_col29 = eval.next_trace_mask();
        let dst_limb_21_col30 = eval.next_trace_mask();
        let dst_limb_22_col31 = eval.next_trace_mask();
        let dst_limb_23_col32 = eval.next_trace_mask();
        let dst_limb_24_col33 = eval.next_trace_mask();
        let dst_limb_25_col34 = eval.next_trace_mask();
        let dst_limb_26_col35 = eval.next_trace_mask();
        let dst_limb_27_col36 = eval.next_trace_mask();
        let dst_sum_inv_col37 = eval.next_trace_mask();
        let dst_sum_squares_inv_col38 = eval.next_trace_mask();
        let next_pc_id_col39 = eval.next_trace_mask();
        let msb_col40 = eval.next_trace_mask();
        let mid_limbs_set_col41 = eval.next_trace_mask();
        let next_pc_limb_0_col42 = eval.next_trace_mask();
        let next_pc_limb_1_col43 = eval.next_trace_mask();
        let next_pc_limb_2_col44 = eval.next_trace_mask();
        let remainder_bits_col45 = eval.next_trace_mask();
        let partial_limb_msb_col46 = eval.next_trace_mask();

        // Enabler is a bit.
        eval.add_constraint(((enabler_col0.clone() * enabler_col0.clone()) - enabler_col0.clone()));
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [decode_instruction_ad440_output_tmp_7f087_5_offset0] =
            DecodeInstructionAd440::evaluate(
                [input_pc_col1.clone()],
                enabler_col0.clone(),
                offset0_col4.clone(),
                dst_base_fp_col5.clone(),
                ap_update_add_1_col6.clone(),
                &self.common_lookup_elements,
                &mut eval,
            );
        // mem_dst_base.
        eval.add_constraint(
            (mem_dst_base_col7.clone()
                - ((dst_base_fp_col5.clone() * input_fp_col3.clone())
                    + ((M31_1.clone() - dst_base_fp_col5.clone()) * input_ap_col2.clone()))),
        );
        ReadPositiveNumBits252::evaluate(
            [(mem_dst_base_col7.clone()
                + decode_instruction_ad440_output_tmp_7f087_5_offset0.clone())],
            enabler_col0.clone(),
            dst_id_col8.clone(),
            dst_limb_0_col9.clone(),
            dst_limb_1_col10.clone(),
            dst_limb_2_col11.clone(),
            dst_limb_3_col12.clone(),
            dst_limb_4_col13.clone(),
            dst_limb_5_col14.clone(),
            dst_limb_6_col15.clone(),
            dst_limb_7_col16.clone(),
            dst_limb_8_col17.clone(),
            dst_limb_9_col18.clone(),
            dst_limb_10_col19.clone(),
            dst_limb_11_col20.clone(),
            dst_limb_12_col21.clone(),
            dst_limb_13_col22.clone(),
            dst_limb_14_col23.clone(),
            dst_limb_15_col24.clone(),
            dst_limb_16_col25.clone(),
            dst_limb_17_col26.clone(),
            dst_limb_18_col27.clone(),
            dst_limb_19_col28.clone(),
            dst_limb_20_col29.clone(),
            dst_limb_21_col30.clone(),
            dst_limb_22_col31.clone(),
            dst_limb_23_col32.clone(),
            dst_limb_24_col33.clone(),
            dst_limb_25_col34.clone(),
            dst_limb_26_col35.clone(),
            dst_limb_27_col36.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        let dst_sum_p_zero_tmp_7f087_11 = eval.add_intermediate(
            ((((((((((((((((((((((((dst_limb_1_col10.clone()
                + dst_limb_2_col11.clone())
                + dst_limb_3_col12.clone())
                + dst_limb_4_col13.clone())
                + dst_limb_5_col14.clone())
                + dst_limb_6_col15.clone())
                + dst_limb_7_col16.clone())
                + dst_limb_8_col17.clone())
                + dst_limb_9_col18.clone())
                + dst_limb_10_col19.clone())
                + dst_limb_11_col20.clone())
                + dst_limb_12_col21.clone())
                + dst_limb_13_col22.clone())
                + dst_limb_14_col23.clone())
                + dst_limb_15_col24.clone())
                + dst_limb_16_col25.clone())
                + dst_limb_17_col26.clone())
                + dst_limb_18_col27.clone())
                + dst_limb_19_col28.clone())
                + dst_limb_20_col29.clone())
                + dst_limb_22_col31.clone())
                + dst_limb_23_col32.clone())
                + dst_limb_24_col33.clone())
                + dst_limb_25_col34.clone())
                + dst_limb_26_col35.clone()),
        );
        // dst doesn't equal 0.
        eval.add_constraint(
            (((dst_sum_p_zero_tmp_7f087_11.clone()
                + ((dst_limb_0_col9.clone() + dst_limb_21_col30.clone())
                    + dst_limb_27_col36.clone()))
                * dst_sum_inv_col37.clone())
                - M31_1.clone()),
        );
        let diff_from_p_tmp_7f087_12 =
            eval.add_intermediate((dst_limb_0_col9.clone() - M31_1.clone()));
        let diff_from_p_tmp_7f087_13 =
            eval.add_intermediate((dst_limb_21_col30.clone() - M31_136.clone()));
        let diff_from_p_tmp_7f087_14 =
            eval.add_intermediate((dst_limb_27_col36.clone() - M31_256.clone()));
        // dst doesn't equal P.
        eval.add_constraint(
            (((dst_sum_p_zero_tmp_7f087_11.clone()
                + (((diff_from_p_tmp_7f087_12.clone() * diff_from_p_tmp_7f087_12.clone())
                    + (diff_from_p_tmp_7f087_13.clone() * diff_from_p_tmp_7f087_13.clone()))
                    + (diff_from_p_tmp_7f087_14.clone() * diff_from_p_tmp_7f087_14.clone())))
                * dst_sum_squares_inv_col38.clone())
                - M31_1.clone()),
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [read_small_output_tmp_7f087_24_limb_0] = ReadSmall::evaluate(
            [(input_pc_col1.clone() + M31_1.clone())],
            enabler_col0.clone(),
            next_pc_id_col39.clone(),
            msb_col40.clone(),
            mid_limbs_set_col41.clone(),
            next_pc_limb_0_col42.clone(),
            next_pc_limb_1_col43.clone(),
            next_pc_limb_2_col44.clone(),
            remainder_bits_col45.clone(),
            partial_limb_msb_col46.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                input_pc_col1.clone(),
                input_ap_col2.clone(),
                input_fp_col3.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                (input_pc_col1.clone() + read_small_output_tmp_7f087_24_limb_0.clone()),
                (input_ap_col2.clone() + ap_update_add_1_col6.clone()),
                input_fp_col3.clone(),
            ],
        ));

        eval.finalize_logup_in_pairs();
        eval
    }
}

#[cfg(test)]
mod tests {
    use num_traits::Zero;
    use rand::rngs::SmallRng;
    use rand::{Rng, SeedableRng};
    use stwo::core::fields::qm31::QM31;
    use stwo_constraint_framework::expr::ExprEvaluator;

    use super::*;

    #[test]
    fn jnz_opcode_taken_constraints_regression() {
        let mut rng = SmallRng::seed_from_u64(0);
        let eval = Eval {
            claim: Claim { log_size: 4 },
            common_lookup_elements: relations::CommonLookupElements::dummy(),
        };
        let expr_eval = eval.evaluate(ExprEvaluator::new());
        let assignment = expr_eval.random_assignment();

        let mut sum = QM31::zero();
        for c in expr_eval.constraints {
            sum += c.assign(&assignment) * rng.random::<QM31>();
        }

        constraints_regression_test_values::JNZ_OPCODE_TAKEN.assert_debug_eq(&sum);
    }
}
