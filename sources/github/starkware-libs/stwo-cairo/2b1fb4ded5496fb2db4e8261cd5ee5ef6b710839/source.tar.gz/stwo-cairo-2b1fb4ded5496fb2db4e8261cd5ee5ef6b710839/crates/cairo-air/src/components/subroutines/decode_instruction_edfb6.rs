// This file was created by the AIR team.

use crate::components::prelude::*;

#[derive(Copy, Clone)]
pub struct DecodeInstructionEdfb6 {}

impl DecodeInstructionEdfb6 {
    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    #[allow(clippy::unused_unit)]
    #[allow(unused_variables)]
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate<E: EvalAtRow>(
        [decode_instruction_edfb6_input_pc]: [E::F; 1],
        enabler: E::F,
        offset2_col0: E::F,
        op1_base_fp_col1: E::F,
        common_lookup_elements: &relations::CommonLookupElements,
        eval: &mut E,
    ) -> [E::F; 2] {
        let M31_1 = E::F::from(M31::from(1));
        let M31_128 = E::F::from(M31::from(128));
        let M31_1719106205 = E::F::from(M31::from(1719106205));
        let M31_32768 = E::F::from(M31::from(32768));
        let M31_32769 = E::F::from(M31::from(32769));
        let M31_64 = E::F::from(M31::from(64));
        let M31_66 = E::F::from(M31::from(66));

        // Flag op1_base_fp is a bit.
        eval.add_constraint(
            (op1_base_fp_col1.clone() * (M31_1.clone() - op1_base_fp_col1.clone())),
        );
        eval.add_to_relation(RelationEntry::new(
            common_lookup_elements,
            E::EF::from(enabler.clone()),
            &[
                M31_1719106205.clone(),
                decode_instruction_edfb6_input_pc.clone(),
                M31_32768.clone(),
                M31_32769.clone(),
                offset2_col0.clone(),
                ((op1_base_fp_col1.clone() * M31_64.clone())
                    + ((M31_1.clone() - op1_base_fp_col1.clone()) * M31_128.clone())),
                M31_66.clone(),
            ],
        ));

        [(offset2_col0.clone() - M31_32768.clone()), (M31_1.clone() - op1_base_fp_col1.clone())]
    }
}
