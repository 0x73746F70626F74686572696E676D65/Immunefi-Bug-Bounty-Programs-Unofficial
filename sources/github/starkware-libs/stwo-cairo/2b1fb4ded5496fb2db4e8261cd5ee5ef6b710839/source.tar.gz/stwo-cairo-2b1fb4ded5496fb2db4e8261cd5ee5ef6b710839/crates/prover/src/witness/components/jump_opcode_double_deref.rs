// This file was created by the AIR team.

#![allow(unused_parens)]
use cairo_air::components::jump_opcode_double_deref::{Claim, InteractionClaim, N_TRACE_COLUMNS};

use crate::witness::components::{memory_address_to_id, memory_id_to_big, verify_instruction};
use crate::witness::prelude::*;

pub type InputType = CasmState;
pub type PackedInputType = PackedCasmState;

#[derive(Default)]
pub struct ClaimGenerator {
    pub inputs: Vec<InputType>,
}

impl ClaimGenerator {
    pub fn new(inputs: Vec<InputType>) -> Self {
        Self { inputs }
    }

    pub fn write_trace(
        mut self,
        memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
        memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
        verify_instruction_state: &verify_instruction::ClaimGenerator,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let n_active_rows = self.inputs.len();
        assert_ne!(n_active_rows, 0);
        let size = std::cmp::max(n_active_rows.next_power_of_two(), N_LANES);
        let log_size = size.ilog2();
        self.inputs.resize(size, *self.inputs.first().unwrap());
        let packed_inputs = pack_values(&self.inputs);

        let (trace, lookup_data, sub_component_inputs) = write_trace_simd(
            packed_inputs,
            n_active_rows,
            memory_address_to_id_state,
            memory_id_to_big_state,
            verify_instruction_state,
        );
        for inputs in sub_component_inputs.verify_instruction {
            add_inputs(verify_instruction_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.memory_address_to_id {
            add_inputs(memory_address_to_id_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.memory_id_to_big {
            add_inputs(memory_id_to_big_state, &inputs, n_active_rows, 0);
        }

        (trace, Claim { log_size }, InteractionClaimGenerator { log_size, lookup_data })
    }
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct SubComponentInputs {
    verify_instruction: [Vec<verify_instruction::PackedInputType>; 1],
    memory_address_to_id: [Vec<memory_address_to_id::PackedInputType>; 2],
    memory_id_to_big: [Vec<memory_id_to_big::PackedInputType>; 2],
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    inputs: Vec<PackedInputType>,
    n_rows: usize,
    memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
    memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
    verify_instruction_state: &verify_instruction::ClaimGenerator,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData, SubComponentInputs) {
    let log_n_packed_rows = inputs.len().ilog2();
    let log_size = log_n_packed_rows + LOG_N_LANES;
    let (mut trace, mut lookup_data, mut sub_component_inputs) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(log_size),
            LookupData::uninitialized(log_n_packed_rows),
            SubComponentInputs::uninitialized(log_n_packed_rows),
        )
    };

    let M31_0 = PackedM31::broadcast(M31::from(0));
    let M31_1 = PackedM31::broadcast(M31::from(1));
    let M31_134217728 = PackedM31::broadcast(M31::from(134217728));
    let M31_1444891767 = PackedM31::broadcast(M31::from(1444891767));
    let M31_16 = PackedM31::broadcast(M31::from(16));
    let M31_1662111297 = PackedM31::broadcast(M31::from(1662111297));
    let M31_1719106205 = PackedM31::broadcast(M31::from(1719106205));
    let M31_2 = PackedM31::broadcast(M31::from(2));
    let M31_2147483646 = PackedM31::broadcast(M31::from(2147483646));
    let M31_262144 = PackedM31::broadcast(M31::from(262144));
    let M31_32 = PackedM31::broadcast(M31::from(32));
    let M31_32767 = PackedM31::broadcast(M31::from(32767));
    let M31_32768 = PackedM31::broadcast(M31::from(32768));
    let M31_428564188 = PackedM31::broadcast(M31::from(428564188));
    let M31_512 = PackedM31::broadcast(M31::from(512));
    let M31_8 = PackedM31::broadcast(M31::from(8));
    let UInt16_1 = PackedUInt16::broadcast(UInt16::from(1));
    let UInt16_11 = PackedUInt16::broadcast(UInt16::from(11));
    let UInt16_13 = PackedUInt16::broadcast(UInt16::from(13));
    let UInt16_2 = PackedUInt16::broadcast(UInt16::from(2));
    let UInt16_3 = PackedUInt16::broadcast(UInt16::from(3));
    let UInt16_31 = PackedUInt16::broadcast(UInt16::from(31));
    let UInt16_4 = PackedUInt16::broadcast(UInt16::from(4));
    let UInt16_5 = PackedUInt16::broadcast(UInt16::from(5));
    let UInt16_6 = PackedUInt16::broadcast(UInt16::from(6));
    let UInt16_7 = PackedUInt16::broadcast(UInt16::from(7));
    let enabler_col = Enabler::new(n_rows);

    (
        trace.par_iter_mut(),
        lookup_data.par_iter_mut(),
        sub_component_inputs.par_iter_mut(),
        inputs.into_par_iter(),
    )
        .into_par_iter()
        .enumerate()
        .for_each(
            |(
                row_index,
                (row, lookup_data, sub_component_inputs, jump_opcode_double_deref_input),
            )| {
                let enabler_col0 = enabler_col.packed_at(row_index);
                *row[0] = enabler_col0;
                let input_pc_col1 = jump_opcode_double_deref_input.pc;
                *row[1] = input_pc_col1;
                let input_ap_col2 = jump_opcode_double_deref_input.ap;
                *row[2] = input_ap_col2;
                let input_fp_col3 = jump_opcode_double_deref_input.fp;
                *row[3] = input_fp_col3;

                // Decode Instruction.

                let memory_address_to_id_value_tmp_b5a8f_0 =
                    memory_address_to_id_state.deduce_output(input_pc_col1);
                let memory_id_to_big_value_tmp_b5a8f_1 =
                    memory_id_to_big_state.deduce_output(memory_address_to_id_value_tmp_b5a8f_0);
                let offset1_tmp_b5a8f_2 =
                    ((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_b5a8f_1.get_m31(1)))
                        >> (UInt16_7))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_b5a8f_1.get_m31(2),
                        )) << (UInt16_2)))
                        + (((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_b5a8f_1.get_m31(3),
                        )) & (UInt16_31))
                            << (UInt16_11)));
                let offset1_col4 = offset1_tmp_b5a8f_2.as_m31();
                *row[4] = offset1_col4;
                let offset2_tmp_b5a8f_3 =
                    ((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_b5a8f_1.get_m31(3)))
                        >> (UInt16_5))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_b5a8f_1.get_m31(4),
                        )) << (UInt16_4)))
                        + (((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_b5a8f_1.get_m31(5),
                        )) & (UInt16_7))
                            << (UInt16_13)));
                let offset2_col5 = offset2_tmp_b5a8f_3.as_m31();
                *row[5] = offset2_col5;
                let op0_base_fp_tmp_b5a8f_4 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_b5a8f_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_b5a8f_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_1))
                        & (UInt16_1));
                let op0_base_fp_col6 = op0_base_fp_tmp_b5a8f_4.as_m31();
                *row[6] = op0_base_fp_col6;
                let ap_update_add_1_tmp_b5a8f_5 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_b5a8f_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_b5a8f_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_11))
                        & (UInt16_1));
                let ap_update_add_1_col7 = ap_update_add_1_tmp_b5a8f_5.as_m31();
                *row[7] = ap_update_add_1_col7;
                *sub_component_inputs.verify_instruction[0] = (
                    input_pc_col1,
                    [M31_32767, offset1_col4, offset2_col5],
                    [
                        ((M31_8) + ((op0_base_fp_col6) * (M31_16))),
                        ((M31_2) + ((ap_update_add_1_col7) * (M31_32))),
                    ],
                    M31_0,
                );
                *lookup_data.verify_instruction_0 = [
                    M31_1719106205,
                    input_pc_col1,
                    M31_32767,
                    offset1_col4,
                    offset2_col5,
                    ((M31_8) + ((op0_base_fp_col6) * (M31_16))),
                    ((M31_2) + ((ap_update_add_1_col7) * (M31_32))),
                    M31_0,
                ];
                let decode_instruction_11364_output_tmp_b5a8f_6 = (
                    [
                        M31_2147483646,
                        ((offset1_col4) - (M31_32768)),
                        ((offset2_col5) - (M31_32768)),
                    ],
                    [
                        M31_1,
                        op0_base_fp_col6,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_1,
                        M31_0,
                        M31_0,
                        M31_0,
                        ap_update_add_1_col7,
                        M31_0,
                        M31_0,
                        M31_0,
                    ],
                    M31_0,
                );

                let mem0_base_col8 = (((op0_base_fp_col6) * (input_fp_col3))
                    + (((M31_1) - (op0_base_fp_col6)) * (input_ap_col2)));
                *row[8] = mem0_base_col8;

                // Read Positive Num Bits 29.

                // Read Id.

                let memory_address_to_id_value_tmp_b5a8f_7 = memory_address_to_id_state
                    .deduce_output(
                        ((mem0_base_col8) + (decode_instruction_11364_output_tmp_b5a8f_6.0[1])),
                    );
                let mem1_base_id_col9 = memory_address_to_id_value_tmp_b5a8f_7;
                *row[9] = mem1_base_id_col9;
                *sub_component_inputs.memory_address_to_id[0] =
                    ((mem0_base_col8) + (decode_instruction_11364_output_tmp_b5a8f_6.0[1]));
                *lookup_data.memory_address_to_id_1 = [
                    M31_1444891767,
                    ((mem0_base_col8) + (decode_instruction_11364_output_tmp_b5a8f_6.0[1])),
                    mem1_base_id_col9,
                ];

                // Read Positive Known Id Num Bits 29.

                let memory_id_to_big_value_tmp_b5a8f_9 =
                    memory_id_to_big_state.deduce_output(mem1_base_id_col9);
                let mem1_base_limb_0_col10 = memory_id_to_big_value_tmp_b5a8f_9.get_m31(0);
                *row[10] = mem1_base_limb_0_col10;
                let mem1_base_limb_1_col11 = memory_id_to_big_value_tmp_b5a8f_9.get_m31(1);
                *row[11] = mem1_base_limb_1_col11;
                let mem1_base_limb_2_col12 = memory_id_to_big_value_tmp_b5a8f_9.get_m31(2);
                *row[12] = mem1_base_limb_2_col12;
                let mem1_base_limb_3_col13 = memory_id_to_big_value_tmp_b5a8f_9.get_m31(3);
                *row[13] = mem1_base_limb_3_col13;

                // Range Check Last Limb Bits In Ms Limb 2.

                // Cond Range Check 2.

                let partial_limb_msb_tmp_b5a8f_10 =
                    (((PackedUInt16::from_m31(mem1_base_limb_3_col13)) & (UInt16_2)) >> (UInt16_1));
                let partial_limb_msb_col14 = partial_limb_msb_tmp_b5a8f_10.as_m31();
                *row[14] = partial_limb_msb_col14;

                *sub_component_inputs.memory_id_to_big[0] = mem1_base_id_col9;
                *lookup_data.memory_id_to_big_2 = [
                    M31_1662111297,
                    mem1_base_id_col9,
                    mem1_base_limb_0_col10,
                    mem1_base_limb_1_col11,
                    mem1_base_limb_2_col12,
                    mem1_base_limb_3_col13,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                ];
                let read_positive_known_id_num_bits_29_output_tmp_b5a8f_12 =
                    PackedFelt252::from_limbs([
                        mem1_base_limb_0_col10,
                        mem1_base_limb_1_col11,
                        mem1_base_limb_2_col12,
                        mem1_base_limb_3_col13,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                    ]);

                let read_positive_num_bits_29_output_tmp_b5a8f_13 =
                    (read_positive_known_id_num_bits_29_output_tmp_b5a8f_12, mem1_base_id_col9);

                // Read Positive Num Bits 29.

                // Read Id.

                let memory_address_to_id_value_tmp_b5a8f_14 = memory_address_to_id_state
                    .deduce_output(
                        (((((mem1_base_limb_0_col10) + ((mem1_base_limb_1_col11) * (M31_512)))
                            + ((mem1_base_limb_2_col12) * (M31_262144)))
                            + ((mem1_base_limb_3_col13) * (M31_134217728)))
                            + (decode_instruction_11364_output_tmp_b5a8f_6.0[2])),
                    );
                let next_pc_id_col15 = memory_address_to_id_value_tmp_b5a8f_14;
                *row[15] = next_pc_id_col15;
                *sub_component_inputs.memory_address_to_id[1] = (((((mem1_base_limb_0_col10)
                    + ((mem1_base_limb_1_col11) * (M31_512)))
                    + ((mem1_base_limb_2_col12) * (M31_262144)))
                    + ((mem1_base_limb_3_col13) * (M31_134217728)))
                    + (decode_instruction_11364_output_tmp_b5a8f_6.0[2]));
                *lookup_data.memory_address_to_id_3 = [
                    M31_1444891767,
                    (((((mem1_base_limb_0_col10) + ((mem1_base_limb_1_col11) * (M31_512)))
                        + ((mem1_base_limb_2_col12) * (M31_262144)))
                        + ((mem1_base_limb_3_col13) * (M31_134217728)))
                        + (decode_instruction_11364_output_tmp_b5a8f_6.0[2])),
                    next_pc_id_col15,
                ];

                // Read Positive Known Id Num Bits 29.

                let memory_id_to_big_value_tmp_b5a8f_16 =
                    memory_id_to_big_state.deduce_output(next_pc_id_col15);
                let next_pc_limb_0_col16 = memory_id_to_big_value_tmp_b5a8f_16.get_m31(0);
                *row[16] = next_pc_limb_0_col16;
                let next_pc_limb_1_col17 = memory_id_to_big_value_tmp_b5a8f_16.get_m31(1);
                *row[17] = next_pc_limb_1_col17;
                let next_pc_limb_2_col18 = memory_id_to_big_value_tmp_b5a8f_16.get_m31(2);
                *row[18] = next_pc_limb_2_col18;
                let next_pc_limb_3_col19 = memory_id_to_big_value_tmp_b5a8f_16.get_m31(3);
                *row[19] = next_pc_limb_3_col19;

                // Range Check Last Limb Bits In Ms Limb 2.

                // Cond Range Check 2.

                let partial_limb_msb_tmp_b5a8f_17 =
                    (((PackedUInt16::from_m31(next_pc_limb_3_col19)) & (UInt16_2)) >> (UInt16_1));
                let partial_limb_msb_col20 = partial_limb_msb_tmp_b5a8f_17.as_m31();
                *row[20] = partial_limb_msb_col20;

                *sub_component_inputs.memory_id_to_big[1] = next_pc_id_col15;
                *lookup_data.memory_id_to_big_4 = [
                    M31_1662111297,
                    next_pc_id_col15,
                    next_pc_limb_0_col16,
                    next_pc_limb_1_col17,
                    next_pc_limb_2_col18,
                    next_pc_limb_3_col19,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                ];
                let read_positive_known_id_num_bits_29_output_tmp_b5a8f_19 =
                    PackedFelt252::from_limbs([
                        next_pc_limb_0_col16,
                        next_pc_limb_1_col17,
                        next_pc_limb_2_col18,
                        next_pc_limb_3_col19,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                    ]);

                let read_positive_num_bits_29_output_tmp_b5a8f_20 =
                    (read_positive_known_id_num_bits_29_output_tmp_b5a8f_19, next_pc_id_col15);

                *lookup_data.opcodes_5 =
                    [M31_428564188, input_pc_col1, input_ap_col2, input_fp_col3];
                *lookup_data.opcodes_6 = [
                    M31_428564188,
                    ((((next_pc_limb_0_col16) + ((next_pc_limb_1_col17) * (M31_512)))
                        + ((next_pc_limb_2_col18) * (M31_262144)))
                        + ((next_pc_limb_3_col19) * (M31_134217728))),
                    ((input_ap_col2) + (ap_update_add_1_col7)),
                    input_fp_col3,
                ];
                *lookup_data.mults_0 = enabler_col0;
            },
        );

    (trace, lookup_data, sub_component_inputs)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    verify_instruction_0: Vec<[PackedM31; 8]>,
    memory_address_to_id_1: Vec<[PackedM31; 3]>,
    memory_id_to_big_2: Vec<[PackedM31; 30]>,
    memory_address_to_id_3: Vec<[PackedM31; 3]>,
    memory_id_to_big_4: Vec<[PackedM31; 30]>,
    opcodes_5: Vec<[PackedM31; 4]>,
    opcodes_6: Vec<[PackedM31; 4]>,
    mults_0: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    log_size: u32,
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(self.log_size) };

        // Sum logup terms in pairs.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_instruction_0,
            &self.lookup_data.memory_address_to_id_1,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_2,
            &self.lookup_data.memory_address_to_id_3,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_4,
            &self.lookup_data.opcodes_5,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        // Sum last logup term.
        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(), &self.lookup_data.opcodes_6, self.lookup_data.mults_0)
            .into_par_iter()
            .for_each(|(writer, values, mult)| {
                let denom = common_lookup_elements.combine(values);
                writer.write_frac((-mult).into(), denom);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
