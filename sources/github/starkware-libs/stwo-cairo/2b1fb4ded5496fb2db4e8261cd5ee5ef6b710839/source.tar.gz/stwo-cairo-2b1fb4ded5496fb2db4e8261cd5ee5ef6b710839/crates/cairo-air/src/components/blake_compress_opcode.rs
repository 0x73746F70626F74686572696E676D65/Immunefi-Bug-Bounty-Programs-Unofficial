// This file was created by the AIR team.

use subroutines::create_blake_output::CreateBlakeOutput;
use subroutines::create_blake_round_input::CreateBlakeRoundInput;
use subroutines::decode_blake_opcode::DecodeBlakeOpcode;
use subroutines::verify_u_32::VerifyU32;

use crate::components::prelude::*;

pub const N_TRACE_COLUMNS: usize = 174;
pub const RELATION_USES_PER_ROW: [RelationUse; 8] = [
    RelationUse { relation_id: "BlakeRound", uses: 1 },
    RelationUse { relation_id: "MemoryAddressToId", uses: 20 },
    RelationUse { relation_id: "MemoryIdToBig", uses: 20 },
    RelationUse { relation_id: "Opcodes", uses: 1 },
    RelationUse { relation_id: "RangeCheck_7_2_5", uses: 17 },
    RelationUse { relation_id: "TripleXor32", uses: 8 },
    RelationUse { relation_id: "VerifyBitwiseXor_8", uses: 4 },
    RelationUse { relation_id: "VerifyInstruction", uses: 1 },
];

pub struct Eval {
    pub claim: Claim,
    pub common_lookup_elements: relations::CommonLookupElements,
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct Claim {
    pub log_size: u32,
}
impl Claim {
    pub fn log_sizes(&self) -> TreeVec<Vec<u32>> {
        let trace_log_sizes = vec![self.log_size; N_TRACE_COLUMNS];
        let interaction_log_sizes = vec![self.log_size; SECURE_EXTENSION_DEGREE * 37];
        TreeVec::new(vec![trace_log_sizes, interaction_log_sizes])
    }
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct InteractionClaim {
    pub claimed_sum: SecureField,
}

pub type Component = FrameworkComponent<Eval>;

impl FrameworkEval for Eval {
    fn log_size(&self) -> u32 {
        self.claim.log_size
    }

    fn max_constraint_log_degree_bound(&self) -> u32 {
        self.log_size() + 1
    }

    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    fn evaluate<E: EvalAtRow>(&self, mut eval: E) -> E {
        let M31_0 = E::F::from(M31::from(0));
        let M31_1 = E::F::from(M31::from(1));
        let M31_10 = E::F::from(M31::from(10));
        let M31_15470 = E::F::from(M31::from(15470));
        let M31_2 = E::F::from(M31::from(2));
        let M31_23520 = E::F::from(M31::from(23520));
        let M31_26764 = E::F::from(M31::from(26764));
        let M31_27145 = E::F::from(M31::from(27145));
        let M31_3 = E::F::from(M31::from(3));
        let M31_39685 = E::F::from(M31::from(39685));
        let M31_4 = E::F::from(M31::from(4));
        let M31_40528774 = E::F::from(M31::from(40528774));
        let M31_42319 = E::F::from(M31::from(42319));
        let M31_428564188 = E::F::from(M31::from(428564188));
        let M31_44677 = E::F::from(M31::from(44677));
        let M31_47975 = E::F::from(M31::from(47975));
        let M31_5 = E::F::from(M31::from(5));
        let M31_52505 = E::F::from(M31::from(52505));
        let M31_58983 = E::F::from(M31::from(58983));
        let M31_6 = E::F::from(M31::from(6));
        let M31_62322 = E::F::from(M31::from(62322));
        let M31_62778 = E::F::from(M31::from(62778));
        let M31_7 = E::F::from(M31::from(7));
        let seq = eval.get_preprocessed_column(Seq::new(self.log_size()).id());
        let enabler_col0 = eval.next_trace_mask();
        let input_pc_col1 = eval.next_trace_mask();
        let input_ap_col2 = eval.next_trace_mask();
        let input_fp_col3 = eval.next_trace_mask();
        let offset0_col4 = eval.next_trace_mask();
        let offset1_col5 = eval.next_trace_mask();
        let offset2_col6 = eval.next_trace_mask();
        let dst_base_fp_col7 = eval.next_trace_mask();
        let op0_base_fp_col8 = eval.next_trace_mask();
        let op1_base_fp_col9 = eval.next_trace_mask();
        let ap_update_add_1_col10 = eval.next_trace_mask();
        let opcode_extension_col11 = eval.next_trace_mask();
        let mem0_base_col12 = eval.next_trace_mask();
        let op0_id_col13 = eval.next_trace_mask();
        let op0_limb_0_col14 = eval.next_trace_mask();
        let op0_limb_1_col15 = eval.next_trace_mask();
        let op0_limb_2_col16 = eval.next_trace_mask();
        let op0_limb_3_col17 = eval.next_trace_mask();
        let partial_limb_msb_col18 = eval.next_trace_mask();
        let mem1_base_col19 = eval.next_trace_mask();
        let op1_id_col20 = eval.next_trace_mask();
        let op1_limb_0_col21 = eval.next_trace_mask();
        let op1_limb_1_col22 = eval.next_trace_mask();
        let op1_limb_2_col23 = eval.next_trace_mask();
        let op1_limb_3_col24 = eval.next_trace_mask();
        let partial_limb_msb_col25 = eval.next_trace_mask();
        let ap_id_col26 = eval.next_trace_mask();
        let ap_limb_0_col27 = eval.next_trace_mask();
        let ap_limb_1_col28 = eval.next_trace_mask();
        let ap_limb_2_col29 = eval.next_trace_mask();
        let ap_limb_3_col30 = eval.next_trace_mask();
        let partial_limb_msb_col31 = eval.next_trace_mask();
        let mem_dst_base_col32 = eval.next_trace_mask();
        let low_16_bits_col33 = eval.next_trace_mask();
        let high_16_bits_col34 = eval.next_trace_mask();
        let low_7_ms_bits_col35 = eval.next_trace_mask();
        let high_14_ms_bits_col36 = eval.next_trace_mask();
        let high_5_ms_bits_col37 = eval.next_trace_mask();
        let dst_id_col38 = eval.next_trace_mask();
        let low_16_bits_col39 = eval.next_trace_mask();
        let high_16_bits_col40 = eval.next_trace_mask();
        let low_7_ms_bits_col41 = eval.next_trace_mask();
        let high_14_ms_bits_col42 = eval.next_trace_mask();
        let high_5_ms_bits_col43 = eval.next_trace_mask();
        let state_0_id_col44 = eval.next_trace_mask();
        let low_16_bits_col45 = eval.next_trace_mask();
        let high_16_bits_col46 = eval.next_trace_mask();
        let low_7_ms_bits_col47 = eval.next_trace_mask();
        let high_14_ms_bits_col48 = eval.next_trace_mask();
        let high_5_ms_bits_col49 = eval.next_trace_mask();
        let state_1_id_col50 = eval.next_trace_mask();
        let low_16_bits_col51 = eval.next_trace_mask();
        let high_16_bits_col52 = eval.next_trace_mask();
        let low_7_ms_bits_col53 = eval.next_trace_mask();
        let high_14_ms_bits_col54 = eval.next_trace_mask();
        let high_5_ms_bits_col55 = eval.next_trace_mask();
        let state_2_id_col56 = eval.next_trace_mask();
        let low_16_bits_col57 = eval.next_trace_mask();
        let high_16_bits_col58 = eval.next_trace_mask();
        let low_7_ms_bits_col59 = eval.next_trace_mask();
        let high_14_ms_bits_col60 = eval.next_trace_mask();
        let high_5_ms_bits_col61 = eval.next_trace_mask();
        let state_3_id_col62 = eval.next_trace_mask();
        let low_16_bits_col63 = eval.next_trace_mask();
        let high_16_bits_col64 = eval.next_trace_mask();
        let low_7_ms_bits_col65 = eval.next_trace_mask();
        let high_14_ms_bits_col66 = eval.next_trace_mask();
        let high_5_ms_bits_col67 = eval.next_trace_mask();
        let state_4_id_col68 = eval.next_trace_mask();
        let low_16_bits_col69 = eval.next_trace_mask();
        let high_16_bits_col70 = eval.next_trace_mask();
        let low_7_ms_bits_col71 = eval.next_trace_mask();
        let high_14_ms_bits_col72 = eval.next_trace_mask();
        let high_5_ms_bits_col73 = eval.next_trace_mask();
        let state_5_id_col74 = eval.next_trace_mask();
        let low_16_bits_col75 = eval.next_trace_mask();
        let high_16_bits_col76 = eval.next_trace_mask();
        let low_7_ms_bits_col77 = eval.next_trace_mask();
        let high_14_ms_bits_col78 = eval.next_trace_mask();
        let high_5_ms_bits_col79 = eval.next_trace_mask();
        let state_6_id_col80 = eval.next_trace_mask();
        let low_16_bits_col81 = eval.next_trace_mask();
        let high_16_bits_col82 = eval.next_trace_mask();
        let low_7_ms_bits_col83 = eval.next_trace_mask();
        let high_14_ms_bits_col84 = eval.next_trace_mask();
        let high_5_ms_bits_col85 = eval.next_trace_mask();
        let state_7_id_col86 = eval.next_trace_mask();
        let ms_8_bits_col87 = eval.next_trace_mask();
        let ms_8_bits_col88 = eval.next_trace_mask();
        let xor_col89 = eval.next_trace_mask();
        let xor_col90 = eval.next_trace_mask();
        let xor_col91 = eval.next_trace_mask();
        let xor_col92 = eval.next_trace_mask();
        let blake_round_output_limb_0_col93 = eval.next_trace_mask();
        let blake_round_output_limb_1_col94 = eval.next_trace_mask();
        let blake_round_output_limb_2_col95 = eval.next_trace_mask();
        let blake_round_output_limb_3_col96 = eval.next_trace_mask();
        let blake_round_output_limb_4_col97 = eval.next_trace_mask();
        let blake_round_output_limb_5_col98 = eval.next_trace_mask();
        let blake_round_output_limb_6_col99 = eval.next_trace_mask();
        let blake_round_output_limb_7_col100 = eval.next_trace_mask();
        let blake_round_output_limb_8_col101 = eval.next_trace_mask();
        let blake_round_output_limb_9_col102 = eval.next_trace_mask();
        let blake_round_output_limb_10_col103 = eval.next_trace_mask();
        let blake_round_output_limb_11_col104 = eval.next_trace_mask();
        let blake_round_output_limb_12_col105 = eval.next_trace_mask();
        let blake_round_output_limb_13_col106 = eval.next_trace_mask();
        let blake_round_output_limb_14_col107 = eval.next_trace_mask();
        let blake_round_output_limb_15_col108 = eval.next_trace_mask();
        let blake_round_output_limb_16_col109 = eval.next_trace_mask();
        let blake_round_output_limb_17_col110 = eval.next_trace_mask();
        let blake_round_output_limb_18_col111 = eval.next_trace_mask();
        let blake_round_output_limb_19_col112 = eval.next_trace_mask();
        let blake_round_output_limb_20_col113 = eval.next_trace_mask();
        let blake_round_output_limb_21_col114 = eval.next_trace_mask();
        let blake_round_output_limb_22_col115 = eval.next_trace_mask();
        let blake_round_output_limb_23_col116 = eval.next_trace_mask();
        let blake_round_output_limb_24_col117 = eval.next_trace_mask();
        let blake_round_output_limb_25_col118 = eval.next_trace_mask();
        let blake_round_output_limb_26_col119 = eval.next_trace_mask();
        let blake_round_output_limb_27_col120 = eval.next_trace_mask();
        let blake_round_output_limb_28_col121 = eval.next_trace_mask();
        let blake_round_output_limb_29_col122 = eval.next_trace_mask();
        let blake_round_output_limb_30_col123 = eval.next_trace_mask();
        let blake_round_output_limb_31_col124 = eval.next_trace_mask();
        let blake_round_output_limb_32_col125 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col126 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col127 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col128 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col129 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col130 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col131 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col132 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col133 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col134 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col135 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col136 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col137 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col138 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col139 = eval.next_trace_mask();
        let triple_xor_32_output_limb_0_col140 = eval.next_trace_mask();
        let triple_xor_32_output_limb_1_col141 = eval.next_trace_mask();
        let low_7_ms_bits_col142 = eval.next_trace_mask();
        let high_14_ms_bits_col143 = eval.next_trace_mask();
        let high_5_ms_bits_col144 = eval.next_trace_mask();
        let new_state_0_id_col145 = eval.next_trace_mask();
        let low_7_ms_bits_col146 = eval.next_trace_mask();
        let high_14_ms_bits_col147 = eval.next_trace_mask();
        let high_5_ms_bits_col148 = eval.next_trace_mask();
        let new_state_1_id_col149 = eval.next_trace_mask();
        let low_7_ms_bits_col150 = eval.next_trace_mask();
        let high_14_ms_bits_col151 = eval.next_trace_mask();
        let high_5_ms_bits_col152 = eval.next_trace_mask();
        let new_state_2_id_col153 = eval.next_trace_mask();
        let low_7_ms_bits_col154 = eval.next_trace_mask();
        let high_14_ms_bits_col155 = eval.next_trace_mask();
        let high_5_ms_bits_col156 = eval.next_trace_mask();
        let new_state_3_id_col157 = eval.next_trace_mask();
        let low_7_ms_bits_col158 = eval.next_trace_mask();
        let high_14_ms_bits_col159 = eval.next_trace_mask();
        let high_5_ms_bits_col160 = eval.next_trace_mask();
        let new_state_4_id_col161 = eval.next_trace_mask();
        let low_7_ms_bits_col162 = eval.next_trace_mask();
        let high_14_ms_bits_col163 = eval.next_trace_mask();
        let high_5_ms_bits_col164 = eval.next_trace_mask();
        let new_state_5_id_col165 = eval.next_trace_mask();
        let low_7_ms_bits_col166 = eval.next_trace_mask();
        let high_14_ms_bits_col167 = eval.next_trace_mask();
        let high_5_ms_bits_col168 = eval.next_trace_mask();
        let new_state_6_id_col169 = eval.next_trace_mask();
        let low_7_ms_bits_col170 = eval.next_trace_mask();
        let high_14_ms_bits_col171 = eval.next_trace_mask();
        let high_5_ms_bits_col172 = eval.next_trace_mask();
        let new_state_7_id_col173 = eval.next_trace_mask();

        // Enabler is a bit.
        eval.add_constraint(((enabler_col0.clone() * enabler_col0.clone()) - enabler_col0.clone()));
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [
            decode_blake_opcode_output_tmp_40cd9_42_limb_0,
            decode_blake_opcode_output_tmp_40cd9_42_limb_1,
            decode_blake_opcode_output_tmp_40cd9_42_limb_2,
            decode_blake_opcode_output_tmp_40cd9_42_limb_6,
        ] = DecodeBlakeOpcode::evaluate(
            [input_pc_col1.clone(), input_ap_col2.clone(), input_fp_col3.clone()],
            enabler_col0.clone(),
            offset0_col4.clone(),
            offset1_col5.clone(),
            offset2_col6.clone(),
            dst_base_fp_col7.clone(),
            op0_base_fp_col8.clone(),
            op1_base_fp_col9.clone(),
            ap_update_add_1_col10.clone(),
            opcode_extension_col11.clone(),
            mem0_base_col12.clone(),
            op0_id_col13.clone(),
            op0_limb_0_col14.clone(),
            op0_limb_1_col15.clone(),
            op0_limb_2_col16.clone(),
            op0_limb_3_col17.clone(),
            partial_limb_msb_col18.clone(),
            mem1_base_col19.clone(),
            op1_id_col20.clone(),
            op1_limb_0_col21.clone(),
            op1_limb_1_col22.clone(),
            op1_limb_2_col23.clone(),
            op1_limb_3_col24.clone(),
            partial_limb_msb_col25.clone(),
            ap_id_col26.clone(),
            ap_limb_0_col27.clone(),
            ap_limb_1_col28.clone(),
            ap_limb_2_col29.clone(),
            ap_limb_3_col30.clone(),
            partial_limb_msb_col31.clone(),
            mem_dst_base_col32.clone(),
            low_16_bits_col33.clone(),
            high_16_bits_col34.clone(),
            low_7_ms_bits_col35.clone(),
            high_14_ms_bits_col36.clone(),
            high_5_ms_bits_col37.clone(),
            dst_id_col38.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [
            create_blake_round_input_output_tmp_40cd9_143_limb_24,
            create_blake_round_input_output_tmp_40cd9_143_limb_25,
            create_blake_round_input_output_tmp_40cd9_143_limb_28,
            create_blake_round_input_output_tmp_40cd9_143_limb_29,
        ] = CreateBlakeRoundInput::evaluate(
            [
                decode_blake_opcode_output_tmp_40cd9_42_limb_0.clone(),
                low_16_bits_col33.clone(),
                high_16_bits_col34.clone(),
                decode_blake_opcode_output_tmp_40cd9_42_limb_6.clone(),
            ],
            enabler_col0.clone(),
            low_16_bits_col39.clone(),
            high_16_bits_col40.clone(),
            low_7_ms_bits_col41.clone(),
            high_14_ms_bits_col42.clone(),
            high_5_ms_bits_col43.clone(),
            state_0_id_col44.clone(),
            low_16_bits_col45.clone(),
            high_16_bits_col46.clone(),
            low_7_ms_bits_col47.clone(),
            high_14_ms_bits_col48.clone(),
            high_5_ms_bits_col49.clone(),
            state_1_id_col50.clone(),
            low_16_bits_col51.clone(),
            high_16_bits_col52.clone(),
            low_7_ms_bits_col53.clone(),
            high_14_ms_bits_col54.clone(),
            high_5_ms_bits_col55.clone(),
            state_2_id_col56.clone(),
            low_16_bits_col57.clone(),
            high_16_bits_col58.clone(),
            low_7_ms_bits_col59.clone(),
            high_14_ms_bits_col60.clone(),
            high_5_ms_bits_col61.clone(),
            state_3_id_col62.clone(),
            low_16_bits_col63.clone(),
            high_16_bits_col64.clone(),
            low_7_ms_bits_col65.clone(),
            high_14_ms_bits_col66.clone(),
            high_5_ms_bits_col67.clone(),
            state_4_id_col68.clone(),
            low_16_bits_col69.clone(),
            high_16_bits_col70.clone(),
            low_7_ms_bits_col71.clone(),
            high_14_ms_bits_col72.clone(),
            high_5_ms_bits_col73.clone(),
            state_5_id_col74.clone(),
            low_16_bits_col75.clone(),
            high_16_bits_col76.clone(),
            low_7_ms_bits_col77.clone(),
            high_14_ms_bits_col78.clone(),
            high_5_ms_bits_col79.clone(),
            state_6_id_col80.clone(),
            low_16_bits_col81.clone(),
            high_16_bits_col82.clone(),
            low_7_ms_bits_col83.clone(),
            high_14_ms_bits_col84.clone(),
            high_5_ms_bits_col85.clone(),
            state_7_id_col86.clone(),
            ms_8_bits_col87.clone(),
            ms_8_bits_col88.clone(),
            xor_col89.clone(),
            xor_col90.clone(),
            xor_col91.clone(),
            xor_col92.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_40528774.clone(),
                seq.clone(),
                M31_0.clone(),
                low_16_bits_col39.clone(),
                high_16_bits_col40.clone(),
                low_16_bits_col45.clone(),
                high_16_bits_col46.clone(),
                low_16_bits_col51.clone(),
                high_16_bits_col52.clone(),
                low_16_bits_col57.clone(),
                high_16_bits_col58.clone(),
                low_16_bits_col63.clone(),
                high_16_bits_col64.clone(),
                low_16_bits_col69.clone(),
                high_16_bits_col70.clone(),
                low_16_bits_col75.clone(),
                high_16_bits_col76.clone(),
                low_16_bits_col81.clone(),
                high_16_bits_col82.clone(),
                M31_58983.clone(),
                M31_27145.clone(),
                M31_44677.clone(),
                M31_47975.clone(),
                M31_62322.clone(),
                M31_15470.clone(),
                M31_62778.clone(),
                M31_42319.clone(),
                create_blake_round_input_output_tmp_40cd9_143_limb_24.clone(),
                create_blake_round_input_output_tmp_40cd9_143_limb_25.clone(),
                M31_26764.clone(),
                M31_39685.clone(),
                create_blake_round_input_output_tmp_40cd9_143_limb_28.clone(),
                create_blake_round_input_output_tmp_40cd9_143_limb_29.clone(),
                M31_52505.clone(),
                M31_23520.clone(),
                decode_blake_opcode_output_tmp_40cd9_42_limb_1.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_40528774.clone(),
                seq.clone(),
                M31_10.clone(),
                blake_round_output_limb_0_col93.clone(),
                blake_round_output_limb_1_col94.clone(),
                blake_round_output_limb_2_col95.clone(),
                blake_round_output_limb_3_col96.clone(),
                blake_round_output_limb_4_col97.clone(),
                blake_round_output_limb_5_col98.clone(),
                blake_round_output_limb_6_col99.clone(),
                blake_round_output_limb_7_col100.clone(),
                blake_round_output_limb_8_col101.clone(),
                blake_round_output_limb_9_col102.clone(),
                blake_round_output_limb_10_col103.clone(),
                blake_round_output_limb_11_col104.clone(),
                blake_round_output_limb_12_col105.clone(),
                blake_round_output_limb_13_col106.clone(),
                blake_round_output_limb_14_col107.clone(),
                blake_round_output_limb_15_col108.clone(),
                blake_round_output_limb_16_col109.clone(),
                blake_round_output_limb_17_col110.clone(),
                blake_round_output_limb_18_col111.clone(),
                blake_round_output_limb_19_col112.clone(),
                blake_round_output_limb_20_col113.clone(),
                blake_round_output_limb_21_col114.clone(),
                blake_round_output_limb_22_col115.clone(),
                blake_round_output_limb_23_col116.clone(),
                blake_round_output_limb_24_col117.clone(),
                blake_round_output_limb_25_col118.clone(),
                blake_round_output_limb_26_col119.clone(),
                blake_round_output_limb_27_col120.clone(),
                blake_round_output_limb_28_col121.clone(),
                blake_round_output_limb_29_col122.clone(),
                blake_round_output_limb_30_col123.clone(),
                blake_round_output_limb_31_col124.clone(),
                blake_round_output_limb_32_col125.clone(),
            ],
        ));

        CreateBlakeOutput::evaluate(
            [
                low_16_bits_col39.clone(),
                high_16_bits_col40.clone(),
                low_16_bits_col45.clone(),
                high_16_bits_col46.clone(),
                low_16_bits_col51.clone(),
                high_16_bits_col52.clone(),
                low_16_bits_col57.clone(),
                high_16_bits_col58.clone(),
                low_16_bits_col63.clone(),
                high_16_bits_col64.clone(),
                low_16_bits_col69.clone(),
                high_16_bits_col70.clone(),
                low_16_bits_col75.clone(),
                high_16_bits_col76.clone(),
                low_16_bits_col81.clone(),
                high_16_bits_col82.clone(),
                blake_round_output_limb_0_col93.clone(),
                blake_round_output_limb_1_col94.clone(),
                blake_round_output_limb_2_col95.clone(),
                blake_round_output_limb_3_col96.clone(),
                blake_round_output_limb_4_col97.clone(),
                blake_round_output_limb_5_col98.clone(),
                blake_round_output_limb_6_col99.clone(),
                blake_round_output_limb_7_col100.clone(),
                blake_round_output_limb_8_col101.clone(),
                blake_round_output_limb_9_col102.clone(),
                blake_round_output_limb_10_col103.clone(),
                blake_round_output_limb_11_col104.clone(),
                blake_round_output_limb_12_col105.clone(),
                blake_round_output_limb_13_col106.clone(),
                blake_round_output_limb_14_col107.clone(),
                blake_round_output_limb_15_col108.clone(),
                blake_round_output_limb_16_col109.clone(),
                blake_round_output_limb_17_col110.clone(),
                blake_round_output_limb_18_col111.clone(),
                blake_round_output_limb_19_col112.clone(),
                blake_round_output_limb_20_col113.clone(),
                blake_round_output_limb_21_col114.clone(),
                blake_round_output_limb_22_col115.clone(),
                blake_round_output_limb_23_col116.clone(),
                blake_round_output_limb_24_col117.clone(),
                blake_round_output_limb_25_col118.clone(),
                blake_round_output_limb_26_col119.clone(),
                blake_round_output_limb_27_col120.clone(),
                blake_round_output_limb_28_col121.clone(),
                blake_round_output_limb_29_col122.clone(),
                blake_round_output_limb_30_col123.clone(),
                blake_round_output_limb_31_col124.clone(),
            ],
            enabler_col0.clone(),
            triple_xor_32_output_limb_0_col126.clone(),
            triple_xor_32_output_limb_1_col127.clone(),
            triple_xor_32_output_limb_0_col128.clone(),
            triple_xor_32_output_limb_1_col129.clone(),
            triple_xor_32_output_limb_0_col130.clone(),
            triple_xor_32_output_limb_1_col131.clone(),
            triple_xor_32_output_limb_0_col132.clone(),
            triple_xor_32_output_limb_1_col133.clone(),
            triple_xor_32_output_limb_0_col134.clone(),
            triple_xor_32_output_limb_1_col135.clone(),
            triple_xor_32_output_limb_0_col136.clone(),
            triple_xor_32_output_limb_1_col137.clone(),
            triple_xor_32_output_limb_0_col138.clone(),
            triple_xor_32_output_limb_1_col139.clone(),
            triple_xor_32_output_limb_0_col140.clone(),
            triple_xor_32_output_limb_1_col141.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone(),
                triple_xor_32_output_limb_0_col126.clone(),
                triple_xor_32_output_limb_1_col127.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col142.clone(),
            high_14_ms_bits_col143.clone(),
            high_5_ms_bits_col144.clone(),
            new_state_0_id_col145.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_1.clone()),
                triple_xor_32_output_limb_0_col128.clone(),
                triple_xor_32_output_limb_1_col129.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col146.clone(),
            high_14_ms_bits_col147.clone(),
            high_5_ms_bits_col148.clone(),
            new_state_1_id_col149.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_2.clone()),
                triple_xor_32_output_limb_0_col130.clone(),
                triple_xor_32_output_limb_1_col131.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col150.clone(),
            high_14_ms_bits_col151.clone(),
            high_5_ms_bits_col152.clone(),
            new_state_2_id_col153.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_3.clone()),
                triple_xor_32_output_limb_0_col132.clone(),
                triple_xor_32_output_limb_1_col133.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col154.clone(),
            high_14_ms_bits_col155.clone(),
            high_5_ms_bits_col156.clone(),
            new_state_3_id_col157.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_4.clone()),
                triple_xor_32_output_limb_0_col134.clone(),
                triple_xor_32_output_limb_1_col135.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col158.clone(),
            high_14_ms_bits_col159.clone(),
            high_5_ms_bits_col160.clone(),
            new_state_4_id_col161.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_5.clone()),
                triple_xor_32_output_limb_0_col136.clone(),
                triple_xor_32_output_limb_1_col137.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col162.clone(),
            high_14_ms_bits_col163.clone(),
            high_5_ms_bits_col164.clone(),
            new_state_5_id_col165.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_6.clone()),
                triple_xor_32_output_limb_0_col138.clone(),
                triple_xor_32_output_limb_1_col139.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col166.clone(),
            high_14_ms_bits_col167.clone(),
            high_5_ms_bits_col168.clone(),
            new_state_6_id_col169.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyU32::evaluate(
            [
                (decode_blake_opcode_output_tmp_40cd9_42_limb_2.clone() + M31_7.clone()),
                triple_xor_32_output_limb_0_col140.clone(),
                triple_xor_32_output_limb_1_col141.clone(),
            ],
            enabler_col0.clone(),
            low_7_ms_bits_col170.clone(),
            high_14_ms_bits_col171.clone(),
            high_5_ms_bits_col172.clone(),
            new_state_7_id_col173.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                input_pc_col1.clone(),
                input_ap_col2.clone(),
                input_fp_col3.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                (input_pc_col1.clone() + M31_1.clone()),
                (input_ap_col2.clone() + ap_update_add_1_col10.clone()),
                input_fp_col3.clone(),
            ],
        ));

        eval.finalize_logup_in_pairs();
        eval
    }
}

#[cfg(test)]
mod tests {
    use num_traits::Zero;
    use rand::rngs::SmallRng;
    use rand::{Rng, SeedableRng};
    use stwo::core::fields::qm31::QM31;
    use stwo_constraint_framework::expr::ExprEvaluator;

    use super::*;

    #[test]
    fn blake_compress_opcode_constraints_regression() {
        let mut rng = SmallRng::seed_from_u64(0);
        let eval = Eval {
            claim: Claim { log_size: 4 },
            common_lookup_elements: relations::CommonLookupElements::dummy(),
        };
        let expr_eval = eval.evaluate(ExprEvaluator::new());
        let assignment = expr_eval.random_assignment();

        let mut sum = QM31::zero();
        for c in expr_eval.constraints {
            sum += c.assign(&assignment) * rng.random::<QM31>();
        }

        constraints_regression_test_values::BLAKE_COMPRESS_OPCODE.assert_debug_eq(&sum);
    }
}
