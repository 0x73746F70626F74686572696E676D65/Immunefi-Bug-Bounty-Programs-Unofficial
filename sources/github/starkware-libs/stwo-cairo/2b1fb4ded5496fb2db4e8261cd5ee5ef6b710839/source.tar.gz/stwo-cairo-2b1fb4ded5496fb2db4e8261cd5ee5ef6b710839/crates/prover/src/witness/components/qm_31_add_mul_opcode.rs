// This file was created by the AIR team.

#![allow(unused_parens)]
use cairo_air::components::qm_31_add_mul_opcode::{Claim, InteractionClaim, N_TRACE_COLUMNS};

use crate::witness::components::{
    memory_address_to_id, memory_id_to_big, range_check_4_4_4_4, verify_instruction,
};
use crate::witness::prelude::*;

pub type InputType = CasmState;
pub type PackedInputType = PackedCasmState;

#[derive(Default)]
pub struct ClaimGenerator {
    pub inputs: Vec<InputType>,
}

impl ClaimGenerator {
    pub fn new(inputs: Vec<InputType>) -> Self {
        Self { inputs }
    }

    pub fn write_trace(
        mut self,
        memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
        memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
        verify_instruction_state: &verify_instruction::ClaimGenerator,
        range_check_4_4_4_4_state: &range_check_4_4_4_4::ClaimGenerator,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let n_active_rows = self.inputs.len();
        assert_ne!(n_active_rows, 0);
        let size = std::cmp::max(n_active_rows.next_power_of_two(), N_LANES);
        let log_size = size.ilog2();
        self.inputs.resize(size, *self.inputs.first().unwrap());
        let packed_inputs = pack_values(&self.inputs);

        let (trace, lookup_data, sub_component_inputs) = write_trace_simd(
            packed_inputs,
            n_active_rows,
            memory_address_to_id_state,
            memory_id_to_big_state,
            verify_instruction_state,
            range_check_4_4_4_4_state,
        );
        for inputs in sub_component_inputs.verify_instruction {
            add_inputs(verify_instruction_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.memory_address_to_id {
            add_inputs(memory_address_to_id_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.memory_id_to_big {
            add_inputs(memory_id_to_big_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.range_check_4_4_4_4 {
            add_inputs(range_check_4_4_4_4_state, &inputs, n_active_rows, 0);
        }

        (trace, Claim { log_size }, InteractionClaimGenerator { log_size, lookup_data })
    }
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct SubComponentInputs {
    verify_instruction: [Vec<verify_instruction::PackedInputType>; 1],
    memory_address_to_id: [Vec<memory_address_to_id::PackedInputType>; 3],
    memory_id_to_big: [Vec<memory_id_to_big::PackedInputType>; 3],
    range_check_4_4_4_4: [Vec<range_check_4_4_4_4::PackedInputType>; 3],
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    inputs: Vec<PackedInputType>,
    n_rows: usize,
    memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
    memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
    verify_instruction_state: &verify_instruction::ClaimGenerator,
    range_check_4_4_4_4_state: &range_check_4_4_4_4::ClaimGenerator,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData, SubComponentInputs) {
    let log_n_packed_rows = inputs.len().ilog2();
    let log_size = log_n_packed_rows + LOG_N_LANES;
    let (mut trace, mut lookup_data, mut sub_component_inputs) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(log_size),
            LookupData::uninitialized(log_n_packed_rows),
            SubComponentInputs::uninitialized(log_n_packed_rows),
        )
    };

    let M31_0 = PackedM31::broadcast(M31::from(0));
    let M31_1 = PackedM31::broadcast(M31::from(1));
    let M31_1027333874 = PackedM31::broadcast(M31::from(1027333874));
    let M31_128 = PackedM31::broadcast(M31::from(128));
    let M31_134217728 = PackedM31::broadcast(M31::from(134217728));
    let M31_1444891767 = PackedM31::broadcast(M31::from(1444891767));
    let M31_1548 = PackedM31::broadcast(M31::from(1548));
    let M31_16 = PackedM31::broadcast(M31::from(16));
    let M31_1662111297 = PackedM31::broadcast(M31::from(1662111297));
    let M31_1719106205 = PackedM31::broadcast(M31::from(1719106205));
    let M31_256 = PackedM31::broadcast(M31::from(256));
    let M31_262144 = PackedM31::broadcast(M31::from(262144));
    let M31_3 = PackedM31::broadcast(M31::from(3));
    let M31_32 = PackedM31::broadcast(M31::from(32));
    let M31_32768 = PackedM31::broadcast(M31::from(32768));
    let M31_428564188 = PackedM31::broadcast(M31::from(428564188));
    let M31_512 = PackedM31::broadcast(M31::from(512));
    let M31_64 = PackedM31::broadcast(M31::from(64));
    let M31_8 = PackedM31::broadcast(M31::from(8));
    let UInt16_0 = PackedUInt16::broadcast(UInt16::from(0));
    let UInt16_1 = PackedUInt16::broadcast(UInt16::from(1));
    let UInt16_11 = PackedUInt16::broadcast(UInt16::from(11));
    let UInt16_127 = PackedUInt16::broadcast(UInt16::from(127));
    let UInt16_13 = PackedUInt16::broadcast(UInt16::from(13));
    let UInt16_2 = PackedUInt16::broadcast(UInt16::from(2));
    let UInt16_3 = PackedUInt16::broadcast(UInt16::from(3));
    let UInt16_31 = PackedUInt16::broadcast(UInt16::from(31));
    let UInt16_4 = PackedUInt16::broadcast(UInt16::from(4));
    let UInt16_5 = PackedUInt16::broadcast(UInt16::from(5));
    let UInt16_6 = PackedUInt16::broadcast(UInt16::from(6));
    let UInt16_7 = PackedUInt16::broadcast(UInt16::from(7));
    let UInt16_9 = PackedUInt16::broadcast(UInt16::from(9));
    let enabler_col = Enabler::new(n_rows);

    (
        trace.par_iter_mut(),
        lookup_data.par_iter_mut(),
        sub_component_inputs.par_iter_mut(),
        inputs.into_par_iter(),
    )
        .into_par_iter()
        .enumerate()
        .for_each(
            |(row_index, (row, lookup_data, sub_component_inputs, qm_31_add_mul_opcode_input))| {
                let enabler_col0 = enabler_col.packed_at(row_index);
                *row[0] = enabler_col0;
                let input_pc_col1 = qm_31_add_mul_opcode_input.pc;
                *row[1] = input_pc_col1;
                let input_ap_col2 = qm_31_add_mul_opcode_input.ap;
                *row[2] = input_ap_col2;
                let input_fp_col3 = qm_31_add_mul_opcode_input.fp;
                *row[3] = input_fp_col3;

                // Decode Instruction.

                let memory_address_to_id_value_tmp_48ee6_0 =
                    memory_address_to_id_state.deduce_output(input_pc_col1);
                let memory_id_to_big_value_tmp_48ee6_1 =
                    memory_id_to_big_state.deduce_output(memory_address_to_id_value_tmp_48ee6_0);
                let offset0_tmp_48ee6_2 =
                    ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(0)))
                        + (((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(1),
                        )) & (UInt16_127))
                            << (UInt16_9)));
                let offset0_col4 = offset0_tmp_48ee6_2.as_m31();
                *row[4] = offset0_col4;
                let offset1_tmp_48ee6_3 =
                    ((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(1)))
                        >> (UInt16_7))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(2),
                        )) << (UInt16_2)))
                        + (((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(3),
                        )) & (UInt16_31))
                            << (UInt16_11)));
                let offset1_col5 = offset1_tmp_48ee6_3.as_m31();
                *row[5] = offset1_col5;
                let offset2_tmp_48ee6_4 =
                    ((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(3)))
                        >> (UInt16_5))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(4),
                        )) << (UInt16_4)))
                        + (((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(5),
                        )) & (UInt16_7))
                            << (UInt16_13)));
                let offset2_col6 = offset2_tmp_48ee6_4.as_m31();
                *row[6] = offset2_col6;
                let dst_base_fp_tmp_48ee6_5 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_0))
                        & (UInt16_1));
                let dst_base_fp_col7 = dst_base_fp_tmp_48ee6_5.as_m31();
                *row[7] = dst_base_fp_col7;
                let op0_base_fp_tmp_48ee6_6 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_1))
                        & (UInt16_1));
                let op0_base_fp_col8 = op0_base_fp_tmp_48ee6_6.as_m31();
                *row[8] = op0_base_fp_col8;
                let op1_imm_tmp_48ee6_7 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_2))
                        & (UInt16_1));
                let op1_imm_col9 = op1_imm_tmp_48ee6_7.as_m31();
                *row[9] = op1_imm_col9;
                let op1_base_fp_tmp_48ee6_8 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_3))
                        & (UInt16_1));
                let op1_base_fp_col10 = op1_base_fp_tmp_48ee6_8.as_m31();
                *row[10] = op1_base_fp_col10;
                let op1_base_ap_tmp_48ee6_9 = (((M31_1) - (op1_imm_col9)) - (op1_base_fp_col10));
                let res_add_tmp_48ee6_10 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_5))
                        & (UInt16_1));
                let res_add_col11 = res_add_tmp_48ee6_10.as_m31();
                *row[11] = res_add_col11;
                let ap_update_add_1_tmp_48ee6_11 =
                    (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_48ee6_1.get_m31(5)))
                        >> (UInt16_3))
                        + ((PackedUInt16::from_m31(
                            memory_id_to_big_value_tmp_48ee6_1.get_m31(6),
                        )) << (UInt16_6)))
                        >> (UInt16_11))
                        & (UInt16_1));
                let ap_update_add_1_col12 = ap_update_add_1_tmp_48ee6_11.as_m31();
                *row[12] = ap_update_add_1_col12;
                *sub_component_inputs.verify_instruction[0] = (
                    input_pc_col1,
                    [offset0_col4, offset1_col5, offset2_col6],
                    [
                        (((((((dst_base_fp_col7) * (M31_8)) + ((op0_base_fp_col8) * (M31_16)))
                            + ((op1_imm_col9) * (M31_32)))
                            + ((op1_base_fp_col10) * (M31_64)))
                            + ((op1_base_ap_tmp_48ee6_9) * (M31_128)))
                            + ((res_add_col11) * (M31_256))),
                        ((((M31_1) - (res_add_col11)) + ((ap_update_add_1_col12) * (M31_32)))
                            + (M31_256)),
                    ],
                    M31_3,
                );
                *lookup_data.verify_instruction_0 = [
                    M31_1719106205,
                    input_pc_col1,
                    offset0_col4,
                    offset1_col5,
                    offset2_col6,
                    (((((((dst_base_fp_col7) * (M31_8)) + ((op0_base_fp_col8) * (M31_16)))
                        + ((op1_imm_col9) * (M31_32)))
                        + ((op1_base_fp_col10) * (M31_64)))
                        + ((op1_base_ap_tmp_48ee6_9) * (M31_128)))
                        + ((res_add_col11) * (M31_256))),
                    ((((M31_1) - (res_add_col11)) + ((ap_update_add_1_col12) * (M31_32)))
                        + (M31_256)),
                    M31_3,
                ];
                let decode_instruction_c67a5_output_tmp_48ee6_12 = (
                    [
                        ((offset0_col4) - (M31_32768)),
                        ((offset1_col5) - (M31_32768)),
                        ((offset2_col6) - (M31_32768)),
                    ],
                    [
                        dst_base_fp_col7,
                        op0_base_fp_col8,
                        op1_imm_col9,
                        op1_base_fp_col10,
                        op1_base_ap_tmp_48ee6_9,
                        res_add_col11,
                        ((M31_1) - (res_add_col11)),
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        ap_update_add_1_col12,
                        M31_0,
                        M31_0,
                        M31_1,
                    ],
                    M31_3,
                );

                let mem_dst_base_col13 = (((dst_base_fp_col7) * (input_fp_col3))
                    + (((M31_1) - (dst_base_fp_col7)) * (input_ap_col2)));
                *row[13] = mem_dst_base_col13;
                let mem0_base_col14 = (((op0_base_fp_col8) * (input_fp_col3))
                    + (((M31_1) - (op0_base_fp_col8)) * (input_ap_col2)));
                *row[14] = mem0_base_col14;
                let mem1_base_col15 = ((((op1_base_fp_col10) * (input_fp_col3))
                    + ((decode_instruction_c67a5_output_tmp_48ee6_12.1[4]) * (input_ap_col2)))
                    + ((op1_imm_col9) * (input_pc_col1)));
                *row[15] = mem1_base_col15;

                // Qm 31 Read Reduced.

                // Read Positive Num Bits 144.

                // Read Id.

                let memory_address_to_id_value_tmp_48ee6_13 = memory_address_to_id_state
                    .deduce_output(
                        ((mem_dst_base_col13)
                            + (decode_instruction_c67a5_output_tmp_48ee6_12.0[0])),
                    );
                let dst_id_col16 = memory_address_to_id_value_tmp_48ee6_13;
                *row[16] = dst_id_col16;
                *sub_component_inputs.memory_address_to_id[0] =
                    ((mem_dst_base_col13) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[0]));
                *lookup_data.memory_address_to_id_1 = [
                    M31_1444891767,
                    ((mem_dst_base_col13) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[0])),
                    dst_id_col16,
                ];

                // Read Positive Known Id Num Bits 144.

                let memory_id_to_big_value_tmp_48ee6_15 =
                    memory_id_to_big_state.deduce_output(dst_id_col16);
                let dst_limb_0_col17 = memory_id_to_big_value_tmp_48ee6_15.get_m31(0);
                *row[17] = dst_limb_0_col17;
                let dst_limb_1_col18 = memory_id_to_big_value_tmp_48ee6_15.get_m31(1);
                *row[18] = dst_limb_1_col18;
                let dst_limb_2_col19 = memory_id_to_big_value_tmp_48ee6_15.get_m31(2);
                *row[19] = dst_limb_2_col19;
                let dst_limb_3_col20 = memory_id_to_big_value_tmp_48ee6_15.get_m31(3);
                *row[20] = dst_limb_3_col20;
                let dst_limb_4_col21 = memory_id_to_big_value_tmp_48ee6_15.get_m31(4);
                *row[21] = dst_limb_4_col21;
                let dst_limb_5_col22 = memory_id_to_big_value_tmp_48ee6_15.get_m31(5);
                *row[22] = dst_limb_5_col22;
                let dst_limb_6_col23 = memory_id_to_big_value_tmp_48ee6_15.get_m31(6);
                *row[23] = dst_limb_6_col23;
                let dst_limb_7_col24 = memory_id_to_big_value_tmp_48ee6_15.get_m31(7);
                *row[24] = dst_limb_7_col24;
                let dst_limb_8_col25 = memory_id_to_big_value_tmp_48ee6_15.get_m31(8);
                *row[25] = dst_limb_8_col25;
                let dst_limb_9_col26 = memory_id_to_big_value_tmp_48ee6_15.get_m31(9);
                *row[26] = dst_limb_9_col26;
                let dst_limb_10_col27 = memory_id_to_big_value_tmp_48ee6_15.get_m31(10);
                *row[27] = dst_limb_10_col27;
                let dst_limb_11_col28 = memory_id_to_big_value_tmp_48ee6_15.get_m31(11);
                *row[28] = dst_limb_11_col28;
                let dst_limb_12_col29 = memory_id_to_big_value_tmp_48ee6_15.get_m31(12);
                *row[29] = dst_limb_12_col29;
                let dst_limb_13_col30 = memory_id_to_big_value_tmp_48ee6_15.get_m31(13);
                *row[30] = dst_limb_13_col30;
                let dst_limb_14_col31 = memory_id_to_big_value_tmp_48ee6_15.get_m31(14);
                *row[31] = dst_limb_14_col31;
                let dst_limb_15_col32 = memory_id_to_big_value_tmp_48ee6_15.get_m31(15);
                *row[32] = dst_limb_15_col32;
                *sub_component_inputs.memory_id_to_big[0] = dst_id_col16;
                *lookup_data.memory_id_to_big_2 = [
                    M31_1662111297,
                    dst_id_col16,
                    dst_limb_0_col17,
                    dst_limb_1_col18,
                    dst_limb_2_col19,
                    dst_limb_3_col20,
                    dst_limb_4_col21,
                    dst_limb_5_col22,
                    dst_limb_6_col23,
                    dst_limb_7_col24,
                    dst_limb_8_col25,
                    dst_limb_9_col26,
                    dst_limb_10_col27,
                    dst_limb_11_col28,
                    dst_limb_12_col29,
                    dst_limb_13_col30,
                    dst_limb_14_col31,
                    dst_limb_15_col32,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                ];
                let read_positive_known_id_num_bits_144_output_tmp_48ee6_16 =
                    PackedFelt252::from_limbs([
                        dst_limb_0_col17,
                        dst_limb_1_col18,
                        dst_limb_2_col19,
                        dst_limb_3_col20,
                        dst_limb_4_col21,
                        dst_limb_5_col22,
                        dst_limb_6_col23,
                        dst_limb_7_col24,
                        dst_limb_8_col25,
                        dst_limb_9_col26,
                        dst_limb_10_col27,
                        dst_limb_11_col28,
                        dst_limb_12_col29,
                        dst_limb_13_col30,
                        dst_limb_14_col31,
                        dst_limb_15_col32,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                    ]);

                let read_positive_num_bits_144_output_tmp_48ee6_17 =
                    (read_positive_known_id_num_bits_144_output_tmp_48ee6_16, dst_id_col16);

                *sub_component_inputs.range_check_4_4_4_4[0] =
                    [dst_limb_3_col20, dst_limb_7_col24, dst_limb_11_col28, dst_limb_15_col32];
                *lookup_data.range_check_4_4_4_4_3 = [
                    M31_1027333874,
                    dst_limb_3_col20,
                    dst_limb_7_col24,
                    dst_limb_11_col28,
                    dst_limb_15_col32,
                ];
                let dst_delta_ab_inv_col33 = ((((((dst_limb_0_col17) + (dst_limb_1_col18))
                    + (dst_limb_2_col19))
                    + (dst_limb_3_col20))
                    - (M31_1548))
                    * (((((dst_limb_4_col21) + (dst_limb_5_col22)) + (dst_limb_6_col23))
                        + (dst_limb_7_col24))
                        - (M31_1548)))
                    .inverse();
                *row[33] = dst_delta_ab_inv_col33;
                let dst_delta_cd_inv_col34 = ((((((dst_limb_8_col25) + (dst_limb_9_col26))
                    + (dst_limb_10_col27))
                    + (dst_limb_11_col28))
                    - (M31_1548))
                    * (((((dst_limb_12_col29) + (dst_limb_13_col30)) + (dst_limb_14_col31))
                        + (dst_limb_15_col32))
                        - (M31_1548)))
                    .inverse();
                *row[34] = dst_delta_cd_inv_col34;
                let qm_31_read_reduced_output_tmp_48ee6_18 = (
                    [
                        ((((dst_limb_0_col17) + ((dst_limb_1_col18) * (M31_512)))
                            + ((dst_limb_2_col19) * (M31_262144)))
                            + ((dst_limb_3_col20) * (M31_134217728))),
                        ((((dst_limb_4_col21) + ((dst_limb_5_col22) * (M31_512)))
                            + ((dst_limb_6_col23) * (M31_262144)))
                            + ((dst_limb_7_col24) * (M31_134217728))),
                        ((((dst_limb_8_col25) + ((dst_limb_9_col26) * (M31_512)))
                            + ((dst_limb_10_col27) * (M31_262144)))
                            + ((dst_limb_11_col28) * (M31_134217728))),
                        ((((dst_limb_12_col29) + ((dst_limb_13_col30) * (M31_512)))
                            + ((dst_limb_14_col31) * (M31_262144)))
                            + ((dst_limb_15_col32) * (M31_134217728))),
                    ],
                    dst_id_col16,
                );

                // Qm 31 Read Reduced.

                // Read Positive Num Bits 144.

                // Read Id.

                let memory_address_to_id_value_tmp_48ee6_19 = memory_address_to_id_state
                    .deduce_output(
                        ((mem0_base_col14) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[1])),
                    );
                let op0_id_col35 = memory_address_to_id_value_tmp_48ee6_19;
                *row[35] = op0_id_col35;
                *sub_component_inputs.memory_address_to_id[1] =
                    ((mem0_base_col14) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[1]));
                *lookup_data.memory_address_to_id_4 = [
                    M31_1444891767,
                    ((mem0_base_col14) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[1])),
                    op0_id_col35,
                ];

                // Read Positive Known Id Num Bits 144.

                let memory_id_to_big_value_tmp_48ee6_21 =
                    memory_id_to_big_state.deduce_output(op0_id_col35);
                let op0_limb_0_col36 = memory_id_to_big_value_tmp_48ee6_21.get_m31(0);
                *row[36] = op0_limb_0_col36;
                let op0_limb_1_col37 = memory_id_to_big_value_tmp_48ee6_21.get_m31(1);
                *row[37] = op0_limb_1_col37;
                let op0_limb_2_col38 = memory_id_to_big_value_tmp_48ee6_21.get_m31(2);
                *row[38] = op0_limb_2_col38;
                let op0_limb_3_col39 = memory_id_to_big_value_tmp_48ee6_21.get_m31(3);
                *row[39] = op0_limb_3_col39;
                let op0_limb_4_col40 = memory_id_to_big_value_tmp_48ee6_21.get_m31(4);
                *row[40] = op0_limb_4_col40;
                let op0_limb_5_col41 = memory_id_to_big_value_tmp_48ee6_21.get_m31(5);
                *row[41] = op0_limb_5_col41;
                let op0_limb_6_col42 = memory_id_to_big_value_tmp_48ee6_21.get_m31(6);
                *row[42] = op0_limb_6_col42;
                let op0_limb_7_col43 = memory_id_to_big_value_tmp_48ee6_21.get_m31(7);
                *row[43] = op0_limb_7_col43;
                let op0_limb_8_col44 = memory_id_to_big_value_tmp_48ee6_21.get_m31(8);
                *row[44] = op0_limb_8_col44;
                let op0_limb_9_col45 = memory_id_to_big_value_tmp_48ee6_21.get_m31(9);
                *row[45] = op0_limb_9_col45;
                let op0_limb_10_col46 = memory_id_to_big_value_tmp_48ee6_21.get_m31(10);
                *row[46] = op0_limb_10_col46;
                let op0_limb_11_col47 = memory_id_to_big_value_tmp_48ee6_21.get_m31(11);
                *row[47] = op0_limb_11_col47;
                let op0_limb_12_col48 = memory_id_to_big_value_tmp_48ee6_21.get_m31(12);
                *row[48] = op0_limb_12_col48;
                let op0_limb_13_col49 = memory_id_to_big_value_tmp_48ee6_21.get_m31(13);
                *row[49] = op0_limb_13_col49;
                let op0_limb_14_col50 = memory_id_to_big_value_tmp_48ee6_21.get_m31(14);
                *row[50] = op0_limb_14_col50;
                let op0_limb_15_col51 = memory_id_to_big_value_tmp_48ee6_21.get_m31(15);
                *row[51] = op0_limb_15_col51;
                *sub_component_inputs.memory_id_to_big[1] = op0_id_col35;
                *lookup_data.memory_id_to_big_5 = [
                    M31_1662111297,
                    op0_id_col35,
                    op0_limb_0_col36,
                    op0_limb_1_col37,
                    op0_limb_2_col38,
                    op0_limb_3_col39,
                    op0_limb_4_col40,
                    op0_limb_5_col41,
                    op0_limb_6_col42,
                    op0_limb_7_col43,
                    op0_limb_8_col44,
                    op0_limb_9_col45,
                    op0_limb_10_col46,
                    op0_limb_11_col47,
                    op0_limb_12_col48,
                    op0_limb_13_col49,
                    op0_limb_14_col50,
                    op0_limb_15_col51,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                ];
                let read_positive_known_id_num_bits_144_output_tmp_48ee6_22 =
                    PackedFelt252::from_limbs([
                        op0_limb_0_col36,
                        op0_limb_1_col37,
                        op0_limb_2_col38,
                        op0_limb_3_col39,
                        op0_limb_4_col40,
                        op0_limb_5_col41,
                        op0_limb_6_col42,
                        op0_limb_7_col43,
                        op0_limb_8_col44,
                        op0_limb_9_col45,
                        op0_limb_10_col46,
                        op0_limb_11_col47,
                        op0_limb_12_col48,
                        op0_limb_13_col49,
                        op0_limb_14_col50,
                        op0_limb_15_col51,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                    ]);

                let read_positive_num_bits_144_output_tmp_48ee6_23 =
                    (read_positive_known_id_num_bits_144_output_tmp_48ee6_22, op0_id_col35);

                *sub_component_inputs.range_check_4_4_4_4[1] =
                    [op0_limb_3_col39, op0_limb_7_col43, op0_limb_11_col47, op0_limb_15_col51];
                *lookup_data.range_check_4_4_4_4_6 = [
                    M31_1027333874,
                    op0_limb_3_col39,
                    op0_limb_7_col43,
                    op0_limb_11_col47,
                    op0_limb_15_col51,
                ];
                let op0_delta_ab_inv_col52 = ((((((op0_limb_0_col36) + (op0_limb_1_col37))
                    + (op0_limb_2_col38))
                    + (op0_limb_3_col39))
                    - (M31_1548))
                    * (((((op0_limb_4_col40) + (op0_limb_5_col41)) + (op0_limb_6_col42))
                        + (op0_limb_7_col43))
                        - (M31_1548)))
                    .inverse();
                *row[52] = op0_delta_ab_inv_col52;
                let op0_delta_cd_inv_col53 = ((((((op0_limb_8_col44) + (op0_limb_9_col45))
                    + (op0_limb_10_col46))
                    + (op0_limb_11_col47))
                    - (M31_1548))
                    * (((((op0_limb_12_col48) + (op0_limb_13_col49)) + (op0_limb_14_col50))
                        + (op0_limb_15_col51))
                        - (M31_1548)))
                    .inverse();
                *row[53] = op0_delta_cd_inv_col53;
                let qm_31_read_reduced_output_tmp_48ee6_24 = (
                    [
                        ((((op0_limb_0_col36) + ((op0_limb_1_col37) * (M31_512)))
                            + ((op0_limb_2_col38) * (M31_262144)))
                            + ((op0_limb_3_col39) * (M31_134217728))),
                        ((((op0_limb_4_col40) + ((op0_limb_5_col41) * (M31_512)))
                            + ((op0_limb_6_col42) * (M31_262144)))
                            + ((op0_limb_7_col43) * (M31_134217728))),
                        ((((op0_limb_8_col44) + ((op0_limb_9_col45) * (M31_512)))
                            + ((op0_limb_10_col46) * (M31_262144)))
                            + ((op0_limb_11_col47) * (M31_134217728))),
                        ((((op0_limb_12_col48) + ((op0_limb_13_col49) * (M31_512)))
                            + ((op0_limb_14_col50) * (M31_262144)))
                            + ((op0_limb_15_col51) * (M31_134217728))),
                    ],
                    op0_id_col35,
                );

                // Qm 31 Read Reduced.

                // Read Positive Num Bits 144.

                // Read Id.

                let memory_address_to_id_value_tmp_48ee6_25 = memory_address_to_id_state
                    .deduce_output(
                        ((mem1_base_col15) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[2])),
                    );
                let op1_id_col54 = memory_address_to_id_value_tmp_48ee6_25;
                *row[54] = op1_id_col54;
                *sub_component_inputs.memory_address_to_id[2] =
                    ((mem1_base_col15) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[2]));
                *lookup_data.memory_address_to_id_7 = [
                    M31_1444891767,
                    ((mem1_base_col15) + (decode_instruction_c67a5_output_tmp_48ee6_12.0[2])),
                    op1_id_col54,
                ];

                // Read Positive Known Id Num Bits 144.

                let memory_id_to_big_value_tmp_48ee6_27 =
                    memory_id_to_big_state.deduce_output(op1_id_col54);
                let op1_limb_0_col55 = memory_id_to_big_value_tmp_48ee6_27.get_m31(0);
                *row[55] = op1_limb_0_col55;
                let op1_limb_1_col56 = memory_id_to_big_value_tmp_48ee6_27.get_m31(1);
                *row[56] = op1_limb_1_col56;
                let op1_limb_2_col57 = memory_id_to_big_value_tmp_48ee6_27.get_m31(2);
                *row[57] = op1_limb_2_col57;
                let op1_limb_3_col58 = memory_id_to_big_value_tmp_48ee6_27.get_m31(3);
                *row[58] = op1_limb_3_col58;
                let op1_limb_4_col59 = memory_id_to_big_value_tmp_48ee6_27.get_m31(4);
                *row[59] = op1_limb_4_col59;
                let op1_limb_5_col60 = memory_id_to_big_value_tmp_48ee6_27.get_m31(5);
                *row[60] = op1_limb_5_col60;
                let op1_limb_6_col61 = memory_id_to_big_value_tmp_48ee6_27.get_m31(6);
                *row[61] = op1_limb_6_col61;
                let op1_limb_7_col62 = memory_id_to_big_value_tmp_48ee6_27.get_m31(7);
                *row[62] = op1_limb_7_col62;
                let op1_limb_8_col63 = memory_id_to_big_value_tmp_48ee6_27.get_m31(8);
                *row[63] = op1_limb_8_col63;
                let op1_limb_9_col64 = memory_id_to_big_value_tmp_48ee6_27.get_m31(9);
                *row[64] = op1_limb_9_col64;
                let op1_limb_10_col65 = memory_id_to_big_value_tmp_48ee6_27.get_m31(10);
                *row[65] = op1_limb_10_col65;
                let op1_limb_11_col66 = memory_id_to_big_value_tmp_48ee6_27.get_m31(11);
                *row[66] = op1_limb_11_col66;
                let op1_limb_12_col67 = memory_id_to_big_value_tmp_48ee6_27.get_m31(12);
                *row[67] = op1_limb_12_col67;
                let op1_limb_13_col68 = memory_id_to_big_value_tmp_48ee6_27.get_m31(13);
                *row[68] = op1_limb_13_col68;
                let op1_limb_14_col69 = memory_id_to_big_value_tmp_48ee6_27.get_m31(14);
                *row[69] = op1_limb_14_col69;
                let op1_limb_15_col70 = memory_id_to_big_value_tmp_48ee6_27.get_m31(15);
                *row[70] = op1_limb_15_col70;
                *sub_component_inputs.memory_id_to_big[2] = op1_id_col54;
                *lookup_data.memory_id_to_big_8 = [
                    M31_1662111297,
                    op1_id_col54,
                    op1_limb_0_col55,
                    op1_limb_1_col56,
                    op1_limb_2_col57,
                    op1_limb_3_col58,
                    op1_limb_4_col59,
                    op1_limb_5_col60,
                    op1_limb_6_col61,
                    op1_limb_7_col62,
                    op1_limb_8_col63,
                    op1_limb_9_col64,
                    op1_limb_10_col65,
                    op1_limb_11_col66,
                    op1_limb_12_col67,
                    op1_limb_13_col68,
                    op1_limb_14_col69,
                    op1_limb_15_col70,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                ];
                let read_positive_known_id_num_bits_144_output_tmp_48ee6_28 =
                    PackedFelt252::from_limbs([
                        op1_limb_0_col55,
                        op1_limb_1_col56,
                        op1_limb_2_col57,
                        op1_limb_3_col58,
                        op1_limb_4_col59,
                        op1_limb_5_col60,
                        op1_limb_6_col61,
                        op1_limb_7_col62,
                        op1_limb_8_col63,
                        op1_limb_9_col64,
                        op1_limb_10_col65,
                        op1_limb_11_col66,
                        op1_limb_12_col67,
                        op1_limb_13_col68,
                        op1_limb_14_col69,
                        op1_limb_15_col70,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                        M31_0,
                    ]);

                let read_positive_num_bits_144_output_tmp_48ee6_29 =
                    (read_positive_known_id_num_bits_144_output_tmp_48ee6_28, op1_id_col54);

                *sub_component_inputs.range_check_4_4_4_4[2] =
                    [op1_limb_3_col58, op1_limb_7_col62, op1_limb_11_col66, op1_limb_15_col70];
                *lookup_data.range_check_4_4_4_4_9 = [
                    M31_1027333874,
                    op1_limb_3_col58,
                    op1_limb_7_col62,
                    op1_limb_11_col66,
                    op1_limb_15_col70,
                ];
                let op1_delta_ab_inv_col71 = ((((((op1_limb_0_col55) + (op1_limb_1_col56))
                    + (op1_limb_2_col57))
                    + (op1_limb_3_col58))
                    - (M31_1548))
                    * (((((op1_limb_4_col59) + (op1_limb_5_col60)) + (op1_limb_6_col61))
                        + (op1_limb_7_col62))
                        - (M31_1548)))
                    .inverse();
                *row[71] = op1_delta_ab_inv_col71;
                let op1_delta_cd_inv_col72 = ((((((op1_limb_8_col63) + (op1_limb_9_col64))
                    + (op1_limb_10_col65))
                    + (op1_limb_11_col66))
                    - (M31_1548))
                    * (((((op1_limb_12_col67) + (op1_limb_13_col68)) + (op1_limb_14_col69))
                        + (op1_limb_15_col70))
                        - (M31_1548)))
                    .inverse();
                *row[72] = op1_delta_cd_inv_col72;
                let qm_31_read_reduced_output_tmp_48ee6_30 = (
                    [
                        ((((op1_limb_0_col55) + ((op1_limb_1_col56) * (M31_512)))
                            + ((op1_limb_2_col57) * (M31_262144)))
                            + ((op1_limb_3_col58) * (M31_134217728))),
                        ((((op1_limb_4_col59) + ((op1_limb_5_col60) * (M31_512)))
                            + ((op1_limb_6_col61) * (M31_262144)))
                            + ((op1_limb_7_col62) * (M31_134217728))),
                        ((((op1_limb_8_col63) + ((op1_limb_9_col64) * (M31_512)))
                            + ((op1_limb_10_col65) * (M31_262144)))
                            + ((op1_limb_11_col66) * (M31_134217728))),
                        ((((op1_limb_12_col67) + ((op1_limb_13_col68) * (M31_512)))
                            + ((op1_limb_14_col69) * (M31_262144)))
                            + ((op1_limb_15_col70) * (M31_134217728))),
                    ],
                    op1_id_col54,
                );

                *lookup_data.opcodes_10 =
                    [M31_428564188, input_pc_col1, input_ap_col2, input_fp_col3];
                *lookup_data.opcodes_11 = [
                    M31_428564188,
                    (((input_pc_col1) + (M31_1)) + (op1_imm_col9)),
                    ((input_ap_col2) + (ap_update_add_1_col12)),
                    input_fp_col3,
                ];
                *lookup_data.mults_0 = enabler_col0;
            },
        );

    (trace, lookup_data, sub_component_inputs)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    verify_instruction_0: Vec<[PackedM31; 8]>,
    memory_address_to_id_1: Vec<[PackedM31; 3]>,
    memory_id_to_big_2: Vec<[PackedM31; 30]>,
    range_check_4_4_4_4_3: Vec<[PackedM31; 5]>,
    memory_address_to_id_4: Vec<[PackedM31; 3]>,
    memory_id_to_big_5: Vec<[PackedM31; 30]>,
    range_check_4_4_4_4_6: Vec<[PackedM31; 5]>,
    memory_address_to_id_7: Vec<[PackedM31; 3]>,
    memory_id_to_big_8: Vec<[PackedM31; 30]>,
    range_check_4_4_4_4_9: Vec<[PackedM31; 5]>,
    opcodes_10: Vec<[PackedM31; 4]>,
    opcodes_11: Vec<[PackedM31; 4]>,
    mults_0: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    log_size: u32,
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(self.log_size) };

        // Sum logup terms in pairs.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_instruction_0,
            &self.lookup_data.memory_address_to_id_1,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_2,
            &self.lookup_data.range_check_4_4_4_4_3,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_address_to_id_4,
            &self.lookup_data.memory_id_to_big_5,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_4_4_4_4_6,
            &self.lookup_data.memory_address_to_id_7,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_8,
            &self.lookup_data.range_check_4_4_4_4_9,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.opcodes_10,
            &self.lookup_data.opcodes_11,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom1 * *mult0 - denom0 * *mult1, denom0 * denom1);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
