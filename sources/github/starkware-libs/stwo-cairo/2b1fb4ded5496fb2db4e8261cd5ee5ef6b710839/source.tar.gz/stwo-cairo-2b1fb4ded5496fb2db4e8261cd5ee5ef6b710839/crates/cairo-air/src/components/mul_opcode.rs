// This file was created by the AIR team.

use subroutines::decode_instruction_c630b::DecodeInstructionC630B;
use subroutines::read_positive_num_bits_252::ReadPositiveNumBits252;
use subroutines::verify_mul_252::VerifyMul252;

use crate::components::prelude::*;

pub const N_TRACE_COLUMNS: usize = 130;
pub const RELATION_USES_PER_ROW: [RelationUse; 12] = [
    RelationUse { relation_id: "MemoryAddressToId", uses: 3 },
    RelationUse { relation_id: "MemoryIdToBig", uses: 3 },
    RelationUse { relation_id: "Opcodes", uses: 1 },
    RelationUse { relation_id: "RangeCheck_20", uses: 4 },
    RelationUse { relation_id: "RangeCheck_20_B", uses: 4 },
    RelationUse { relation_id: "RangeCheck_20_C", uses: 4 },
    RelationUse { relation_id: "RangeCheck_20_D", uses: 4 },
    RelationUse { relation_id: "RangeCheck_20_E", uses: 3 },
    RelationUse { relation_id: "RangeCheck_20_F", uses: 3 },
    RelationUse { relation_id: "RangeCheck_20_G", uses: 3 },
    RelationUse { relation_id: "RangeCheck_20_H", uses: 3 },
    RelationUse { relation_id: "VerifyInstruction", uses: 1 },
];

pub struct Eval {
    pub claim: Claim,
    pub common_lookup_elements: relations::CommonLookupElements,
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct Claim {
    pub log_size: u32,
}
impl Claim {
    pub fn log_sizes(&self) -> TreeVec<Vec<u32>> {
        let trace_log_sizes = vec![self.log_size; N_TRACE_COLUMNS];
        let interaction_log_sizes = vec![self.log_size; SECURE_EXTENSION_DEGREE * 19];
        TreeVec::new(vec![trace_log_sizes, interaction_log_sizes])
    }
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct InteractionClaim {
    pub claimed_sum: SecureField,
}

pub type Component = FrameworkComponent<Eval>;

impl FrameworkEval for Eval {
    fn log_size(&self) -> u32 {
        self.claim.log_size
    }

    fn max_constraint_log_degree_bound(&self) -> u32 {
        self.log_size() + 1
    }

    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    fn evaluate<E: EvalAtRow>(&self, mut eval: E) -> E {
        let M31_1 = E::F::from(M31::from(1));
        let M31_428564188 = E::F::from(M31::from(428564188));
        let enabler_col0 = eval.next_trace_mask();
        let input_pc_col1 = eval.next_trace_mask();
        let input_ap_col2 = eval.next_trace_mask();
        let input_fp_col3 = eval.next_trace_mask();
        let offset0_col4 = eval.next_trace_mask();
        let offset1_col5 = eval.next_trace_mask();
        let offset2_col6 = eval.next_trace_mask();
        let dst_base_fp_col7 = eval.next_trace_mask();
        let op0_base_fp_col8 = eval.next_trace_mask();
        let op1_imm_col9 = eval.next_trace_mask();
        let op1_base_fp_col10 = eval.next_trace_mask();
        let ap_update_add_1_col11 = eval.next_trace_mask();
        let mem_dst_base_col12 = eval.next_trace_mask();
        let mem0_base_col13 = eval.next_trace_mask();
        let mem1_base_col14 = eval.next_trace_mask();
        let dst_id_col15 = eval.next_trace_mask();
        let dst_limb_0_col16 = eval.next_trace_mask();
        let dst_limb_1_col17 = eval.next_trace_mask();
        let dst_limb_2_col18 = eval.next_trace_mask();
        let dst_limb_3_col19 = eval.next_trace_mask();
        let dst_limb_4_col20 = eval.next_trace_mask();
        let dst_limb_5_col21 = eval.next_trace_mask();
        let dst_limb_6_col22 = eval.next_trace_mask();
        let dst_limb_7_col23 = eval.next_trace_mask();
        let dst_limb_8_col24 = eval.next_trace_mask();
        let dst_limb_9_col25 = eval.next_trace_mask();
        let dst_limb_10_col26 = eval.next_trace_mask();
        let dst_limb_11_col27 = eval.next_trace_mask();
        let dst_limb_12_col28 = eval.next_trace_mask();
        let dst_limb_13_col29 = eval.next_trace_mask();
        let dst_limb_14_col30 = eval.next_trace_mask();
        let dst_limb_15_col31 = eval.next_trace_mask();
        let dst_limb_16_col32 = eval.next_trace_mask();
        let dst_limb_17_col33 = eval.next_trace_mask();
        let dst_limb_18_col34 = eval.next_trace_mask();
        let dst_limb_19_col35 = eval.next_trace_mask();
        let dst_limb_20_col36 = eval.next_trace_mask();
        let dst_limb_21_col37 = eval.next_trace_mask();
        let dst_limb_22_col38 = eval.next_trace_mask();
        let dst_limb_23_col39 = eval.next_trace_mask();
        let dst_limb_24_col40 = eval.next_trace_mask();
        let dst_limb_25_col41 = eval.next_trace_mask();
        let dst_limb_26_col42 = eval.next_trace_mask();
        let dst_limb_27_col43 = eval.next_trace_mask();
        let op0_id_col44 = eval.next_trace_mask();
        let op0_limb_0_col45 = eval.next_trace_mask();
        let op0_limb_1_col46 = eval.next_trace_mask();
        let op0_limb_2_col47 = eval.next_trace_mask();
        let op0_limb_3_col48 = eval.next_trace_mask();
        let op0_limb_4_col49 = eval.next_trace_mask();
        let op0_limb_5_col50 = eval.next_trace_mask();
        let op0_limb_6_col51 = eval.next_trace_mask();
        let op0_limb_7_col52 = eval.next_trace_mask();
        let op0_limb_8_col53 = eval.next_trace_mask();
        let op0_limb_9_col54 = eval.next_trace_mask();
        let op0_limb_10_col55 = eval.next_trace_mask();
        let op0_limb_11_col56 = eval.next_trace_mask();
        let op0_limb_12_col57 = eval.next_trace_mask();
        let op0_limb_13_col58 = eval.next_trace_mask();
        let op0_limb_14_col59 = eval.next_trace_mask();
        let op0_limb_15_col60 = eval.next_trace_mask();
        let op0_limb_16_col61 = eval.next_trace_mask();
        let op0_limb_17_col62 = eval.next_trace_mask();
        let op0_limb_18_col63 = eval.next_trace_mask();
        let op0_limb_19_col64 = eval.next_trace_mask();
        let op0_limb_20_col65 = eval.next_trace_mask();
        let op0_limb_21_col66 = eval.next_trace_mask();
        let op0_limb_22_col67 = eval.next_trace_mask();
        let op0_limb_23_col68 = eval.next_trace_mask();
        let op0_limb_24_col69 = eval.next_trace_mask();
        let op0_limb_25_col70 = eval.next_trace_mask();
        let op0_limb_26_col71 = eval.next_trace_mask();
        let op0_limb_27_col72 = eval.next_trace_mask();
        let op1_id_col73 = eval.next_trace_mask();
        let op1_limb_0_col74 = eval.next_trace_mask();
        let op1_limb_1_col75 = eval.next_trace_mask();
        let op1_limb_2_col76 = eval.next_trace_mask();
        let op1_limb_3_col77 = eval.next_trace_mask();
        let op1_limb_4_col78 = eval.next_trace_mask();
        let op1_limb_5_col79 = eval.next_trace_mask();
        let op1_limb_6_col80 = eval.next_trace_mask();
        let op1_limb_7_col81 = eval.next_trace_mask();
        let op1_limb_8_col82 = eval.next_trace_mask();
        let op1_limb_9_col83 = eval.next_trace_mask();
        let op1_limb_10_col84 = eval.next_trace_mask();
        let op1_limb_11_col85 = eval.next_trace_mask();
        let op1_limb_12_col86 = eval.next_trace_mask();
        let op1_limb_13_col87 = eval.next_trace_mask();
        let op1_limb_14_col88 = eval.next_trace_mask();
        let op1_limb_15_col89 = eval.next_trace_mask();
        let op1_limb_16_col90 = eval.next_trace_mask();
        let op1_limb_17_col91 = eval.next_trace_mask();
        let op1_limb_18_col92 = eval.next_trace_mask();
        let op1_limb_19_col93 = eval.next_trace_mask();
        let op1_limb_20_col94 = eval.next_trace_mask();
        let op1_limb_21_col95 = eval.next_trace_mask();
        let op1_limb_22_col96 = eval.next_trace_mask();
        let op1_limb_23_col97 = eval.next_trace_mask();
        let op1_limb_24_col98 = eval.next_trace_mask();
        let op1_limb_25_col99 = eval.next_trace_mask();
        let op1_limb_26_col100 = eval.next_trace_mask();
        let op1_limb_27_col101 = eval.next_trace_mask();
        let k_col102 = eval.next_trace_mask();
        let carry_0_col103 = eval.next_trace_mask();
        let carry_1_col104 = eval.next_trace_mask();
        let carry_2_col105 = eval.next_trace_mask();
        let carry_3_col106 = eval.next_trace_mask();
        let carry_4_col107 = eval.next_trace_mask();
        let carry_5_col108 = eval.next_trace_mask();
        let carry_6_col109 = eval.next_trace_mask();
        let carry_7_col110 = eval.next_trace_mask();
        let carry_8_col111 = eval.next_trace_mask();
        let carry_9_col112 = eval.next_trace_mask();
        let carry_10_col113 = eval.next_trace_mask();
        let carry_11_col114 = eval.next_trace_mask();
        let carry_12_col115 = eval.next_trace_mask();
        let carry_13_col116 = eval.next_trace_mask();
        let carry_14_col117 = eval.next_trace_mask();
        let carry_15_col118 = eval.next_trace_mask();
        let carry_16_col119 = eval.next_trace_mask();
        let carry_17_col120 = eval.next_trace_mask();
        let carry_18_col121 = eval.next_trace_mask();
        let carry_19_col122 = eval.next_trace_mask();
        let carry_20_col123 = eval.next_trace_mask();
        let carry_21_col124 = eval.next_trace_mask();
        let carry_22_col125 = eval.next_trace_mask();
        let carry_23_col126 = eval.next_trace_mask();
        let carry_24_col127 = eval.next_trace_mask();
        let carry_25_col128 = eval.next_trace_mask();
        let carry_26_col129 = eval.next_trace_mask();

        // Enabler is a bit.
        eval.add_constraint(((enabler_col0.clone() * enabler_col0.clone()) - enabler_col0.clone()));
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [
            decode_instruction_c630b_output_tmp_93be2_11_offset0,
            decode_instruction_c630b_output_tmp_93be2_11_offset1,
            decode_instruction_c630b_output_tmp_93be2_11_offset2,
            decode_instruction_c630b_output_tmp_93be2_11_op1_base_ap,
        ] = DecodeInstructionC630B::evaluate(
            [input_pc_col1.clone()],
            enabler_col0.clone(),
            offset0_col4.clone(),
            offset1_col5.clone(),
            offset2_col6.clone(),
            dst_base_fp_col7.clone(),
            op0_base_fp_col8.clone(),
            op1_imm_col9.clone(),
            op1_base_fp_col10.clone(),
            ap_update_add_1_col11.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        // if imm then offset2 is 1.
        eval.add_constraint(
            (op1_imm_col9.clone()
                * (M31_1.clone() - decode_instruction_c630b_output_tmp_93be2_11_offset2.clone())),
        );
        // mem_dst_base.
        eval.add_constraint(
            (mem_dst_base_col12.clone()
                - ((dst_base_fp_col7.clone() * input_fp_col3.clone())
                    + ((M31_1.clone() - dst_base_fp_col7.clone()) * input_ap_col2.clone()))),
        );
        // mem0_base.
        eval.add_constraint(
            (mem0_base_col13.clone()
                - ((op0_base_fp_col8.clone() * input_fp_col3.clone())
                    + ((M31_1.clone() - op0_base_fp_col8.clone()) * input_ap_col2.clone()))),
        );
        // mem1_base.
        eval.add_constraint(
            (mem1_base_col14.clone()
                - (((op1_imm_col9.clone() * input_pc_col1.clone())
                    + (op1_base_fp_col10.clone() * input_fp_col3.clone()))
                    + (decode_instruction_c630b_output_tmp_93be2_11_op1_base_ap.clone()
                        * input_ap_col2.clone()))),
        );
        ReadPositiveNumBits252::evaluate(
            [(mem_dst_base_col12.clone()
                + decode_instruction_c630b_output_tmp_93be2_11_offset0.clone())],
            enabler_col0.clone(),
            dst_id_col15.clone(),
            dst_limb_0_col16.clone(),
            dst_limb_1_col17.clone(),
            dst_limb_2_col18.clone(),
            dst_limb_3_col19.clone(),
            dst_limb_4_col20.clone(),
            dst_limb_5_col21.clone(),
            dst_limb_6_col22.clone(),
            dst_limb_7_col23.clone(),
            dst_limb_8_col24.clone(),
            dst_limb_9_col25.clone(),
            dst_limb_10_col26.clone(),
            dst_limb_11_col27.clone(),
            dst_limb_12_col28.clone(),
            dst_limb_13_col29.clone(),
            dst_limb_14_col30.clone(),
            dst_limb_15_col31.clone(),
            dst_limb_16_col32.clone(),
            dst_limb_17_col33.clone(),
            dst_limb_18_col34.clone(),
            dst_limb_19_col35.clone(),
            dst_limb_20_col36.clone(),
            dst_limb_21_col37.clone(),
            dst_limb_22_col38.clone(),
            dst_limb_23_col39.clone(),
            dst_limb_24_col40.clone(),
            dst_limb_25_col41.clone(),
            dst_limb_26_col42.clone(),
            dst_limb_27_col43.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        ReadPositiveNumBits252::evaluate(
            [(mem0_base_col13.clone()
                + decode_instruction_c630b_output_tmp_93be2_11_offset1.clone())],
            enabler_col0.clone(),
            op0_id_col44.clone(),
            op0_limb_0_col45.clone(),
            op0_limb_1_col46.clone(),
            op0_limb_2_col47.clone(),
            op0_limb_3_col48.clone(),
            op0_limb_4_col49.clone(),
            op0_limb_5_col50.clone(),
            op0_limb_6_col51.clone(),
            op0_limb_7_col52.clone(),
            op0_limb_8_col53.clone(),
            op0_limb_9_col54.clone(),
            op0_limb_10_col55.clone(),
            op0_limb_11_col56.clone(),
            op0_limb_12_col57.clone(),
            op0_limb_13_col58.clone(),
            op0_limb_14_col59.clone(),
            op0_limb_15_col60.clone(),
            op0_limb_16_col61.clone(),
            op0_limb_17_col62.clone(),
            op0_limb_18_col63.clone(),
            op0_limb_19_col64.clone(),
            op0_limb_20_col65.clone(),
            op0_limb_21_col66.clone(),
            op0_limb_22_col67.clone(),
            op0_limb_23_col68.clone(),
            op0_limb_24_col69.clone(),
            op0_limb_25_col70.clone(),
            op0_limb_26_col71.clone(),
            op0_limb_27_col72.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        ReadPositiveNumBits252::evaluate(
            [(mem1_base_col14.clone()
                + decode_instruction_c630b_output_tmp_93be2_11_offset2.clone())],
            enabler_col0.clone(),
            op1_id_col73.clone(),
            op1_limb_0_col74.clone(),
            op1_limb_1_col75.clone(),
            op1_limb_2_col76.clone(),
            op1_limb_3_col77.clone(),
            op1_limb_4_col78.clone(),
            op1_limb_5_col79.clone(),
            op1_limb_6_col80.clone(),
            op1_limb_7_col81.clone(),
            op1_limb_8_col82.clone(),
            op1_limb_9_col83.clone(),
            op1_limb_10_col84.clone(),
            op1_limb_11_col85.clone(),
            op1_limb_12_col86.clone(),
            op1_limb_13_col87.clone(),
            op1_limb_14_col88.clone(),
            op1_limb_15_col89.clone(),
            op1_limb_16_col90.clone(),
            op1_limb_17_col91.clone(),
            op1_limb_18_col92.clone(),
            op1_limb_19_col93.clone(),
            op1_limb_20_col94.clone(),
            op1_limb_21_col95.clone(),
            op1_limb_22_col96.clone(),
            op1_limb_23_col97.clone(),
            op1_limb_24_col98.clone(),
            op1_limb_25_col99.clone(),
            op1_limb_26_col100.clone(),
            op1_limb_27_col101.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        VerifyMul252::evaluate(
            [
                op0_limb_0_col45.clone(),
                op0_limb_1_col46.clone(),
                op0_limb_2_col47.clone(),
                op0_limb_3_col48.clone(),
                op0_limb_4_col49.clone(),
                op0_limb_5_col50.clone(),
                op0_limb_6_col51.clone(),
                op0_limb_7_col52.clone(),
                op0_limb_8_col53.clone(),
                op0_limb_9_col54.clone(),
                op0_limb_10_col55.clone(),
                op0_limb_11_col56.clone(),
                op0_limb_12_col57.clone(),
                op0_limb_13_col58.clone(),
                op0_limb_14_col59.clone(),
                op0_limb_15_col60.clone(),
                op0_limb_16_col61.clone(),
                op0_limb_17_col62.clone(),
                op0_limb_18_col63.clone(),
                op0_limb_19_col64.clone(),
                op0_limb_20_col65.clone(),
                op0_limb_21_col66.clone(),
                op0_limb_22_col67.clone(),
                op0_limb_23_col68.clone(),
                op0_limb_24_col69.clone(),
                op0_limb_25_col70.clone(),
                op0_limb_26_col71.clone(),
                op0_limb_27_col72.clone(),
                op1_limb_0_col74.clone(),
                op1_limb_1_col75.clone(),
                op1_limb_2_col76.clone(),
                op1_limb_3_col77.clone(),
                op1_limb_4_col78.clone(),
                op1_limb_5_col79.clone(),
                op1_limb_6_col80.clone(),
                op1_limb_7_col81.clone(),
                op1_limb_8_col82.clone(),
                op1_limb_9_col83.clone(),
                op1_limb_10_col84.clone(),
                op1_limb_11_col85.clone(),
                op1_limb_12_col86.clone(),
                op1_limb_13_col87.clone(),
                op1_limb_14_col88.clone(),
                op1_limb_15_col89.clone(),
                op1_limb_16_col90.clone(),
                op1_limb_17_col91.clone(),
                op1_limb_18_col92.clone(),
                op1_limb_19_col93.clone(),
                op1_limb_20_col94.clone(),
                op1_limb_21_col95.clone(),
                op1_limb_22_col96.clone(),
                op1_limb_23_col97.clone(),
                op1_limb_24_col98.clone(),
                op1_limb_25_col99.clone(),
                op1_limb_26_col100.clone(),
                op1_limb_27_col101.clone(),
                dst_limb_0_col16.clone(),
                dst_limb_1_col17.clone(),
                dst_limb_2_col18.clone(),
                dst_limb_3_col19.clone(),
                dst_limb_4_col20.clone(),
                dst_limb_5_col21.clone(),
                dst_limb_6_col22.clone(),
                dst_limb_7_col23.clone(),
                dst_limb_8_col24.clone(),
                dst_limb_9_col25.clone(),
                dst_limb_10_col26.clone(),
                dst_limb_11_col27.clone(),
                dst_limb_12_col28.clone(),
                dst_limb_13_col29.clone(),
                dst_limb_14_col30.clone(),
                dst_limb_15_col31.clone(),
                dst_limb_16_col32.clone(),
                dst_limb_17_col33.clone(),
                dst_limb_18_col34.clone(),
                dst_limb_19_col35.clone(),
                dst_limb_20_col36.clone(),
                dst_limb_21_col37.clone(),
                dst_limb_22_col38.clone(),
                dst_limb_23_col39.clone(),
                dst_limb_24_col40.clone(),
                dst_limb_25_col41.clone(),
                dst_limb_26_col42.clone(),
                dst_limb_27_col43.clone(),
            ],
            enabler_col0.clone(),
            k_col102.clone(),
            carry_0_col103.clone(),
            carry_1_col104.clone(),
            carry_2_col105.clone(),
            carry_3_col106.clone(),
            carry_4_col107.clone(),
            carry_5_col108.clone(),
            carry_6_col109.clone(),
            carry_7_col110.clone(),
            carry_8_col111.clone(),
            carry_9_col112.clone(),
            carry_10_col113.clone(),
            carry_11_col114.clone(),
            carry_12_col115.clone(),
            carry_13_col116.clone(),
            carry_14_col117.clone(),
            carry_15_col118.clone(),
            carry_16_col119.clone(),
            carry_17_col120.clone(),
            carry_18_col121.clone(),
            carry_19_col122.clone(),
            carry_20_col123.clone(),
            carry_21_col124.clone(),
            carry_22_col125.clone(),
            carry_23_col126.clone(),
            carry_24_col127.clone(),
            carry_25_col128.clone(),
            carry_26_col129.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                input_pc_col1.clone(),
                input_ap_col2.clone(),
                input_fp_col3.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_428564188.clone(),
                ((input_pc_col1.clone() + M31_1.clone()) + op1_imm_col9.clone()),
                (input_ap_col2.clone() + ap_update_add_1_col11.clone()),
                input_fp_col3.clone(),
            ],
        ));

        eval.finalize_logup_in_pairs();
        eval
    }
}

#[cfg(test)]
mod tests {
    use num_traits::Zero;
    use rand::rngs::SmallRng;
    use rand::{Rng, SeedableRng};
    use stwo::core::fields::qm31::QM31;
    use stwo_constraint_framework::expr::ExprEvaluator;

    use super::*;

    #[test]
    fn mul_opcode_constraints_regression() {
        let mut rng = SmallRng::seed_from_u64(0);
        let eval = Eval {
            claim: Claim { log_size: 4 },
            common_lookup_elements: relations::CommonLookupElements::dummy(),
        };
        let expr_eval = eval.evaluate(ExprEvaluator::new());
        let assignment = expr_eval.random_assignment();

        let mut sum = QM31::zero();
        for c in expr_eval.constraints {
            sum += c.assign(&assignment) * rng.random::<QM31>();
        }

        constraints_regression_test_values::MUL_OPCODE.assert_debug_eq(&sum);
    }
}
