// This file was created by the AIR team.

use subroutines::read_id::ReadId;

use crate::components::prelude::*;

#[derive(Copy, Clone)]
pub struct MemVerify {}

impl MemVerify {
    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    #[allow(clippy::unused_unit)]
    #[allow(unused_variables)]
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate<E: EvalAtRow>(
        [
            mem_verify_input_address,
            mem_verify_input_value_limb_0,
            mem_verify_input_value_limb_1,
            mem_verify_input_value_limb_2,
            mem_verify_input_value_limb_3,
            mem_verify_input_value_limb_4,
            mem_verify_input_value_limb_5,
            mem_verify_input_value_limb_6,
            mem_verify_input_value_limb_7,
            mem_verify_input_value_limb_8,
            mem_verify_input_value_limb_9,
            mem_verify_input_value_limb_10,
            mem_verify_input_value_limb_11,
            mem_verify_input_value_limb_12,
            mem_verify_input_value_limb_13,
            mem_verify_input_value_limb_14,
            mem_verify_input_value_limb_15,
            mem_verify_input_value_limb_16,
            mem_verify_input_value_limb_17,
            mem_verify_input_value_limb_18,
            mem_verify_input_value_limb_19,
            mem_verify_input_value_limb_20,
            mem_verify_input_value_limb_21,
            mem_verify_input_value_limb_22,
            mem_verify_input_value_limb_23,
            mem_verify_input_value_limb_24,
            mem_verify_input_value_limb_25,
            mem_verify_input_value_limb_26,
            mem_verify_input_value_limb_27,
        ]: [E::F; 29],
        enabler: E::F,
        id_col0: E::F,
        common_lookup_elements: &relations::CommonLookupElements,
        eval: &mut E,
    ) -> [E::F; 0] {
        let M31_1662111297 = E::F::from(M31::from(1662111297));

        ReadId::evaluate(
            [mem_verify_input_address.clone()],
            enabler.clone(),
            id_col0.clone(),
            common_lookup_elements,
            eval,
        );
        eval.add_to_relation(RelationEntry::new(
            common_lookup_elements,
            E::EF::from(enabler.clone()),
            &[
                M31_1662111297.clone(),
                id_col0.clone(),
                mem_verify_input_value_limb_0.clone(),
                mem_verify_input_value_limb_1.clone(),
                mem_verify_input_value_limb_2.clone(),
                mem_verify_input_value_limb_3.clone(),
                mem_verify_input_value_limb_4.clone(),
                mem_verify_input_value_limb_5.clone(),
                mem_verify_input_value_limb_6.clone(),
                mem_verify_input_value_limb_7.clone(),
                mem_verify_input_value_limb_8.clone(),
                mem_verify_input_value_limb_9.clone(),
                mem_verify_input_value_limb_10.clone(),
                mem_verify_input_value_limb_11.clone(),
                mem_verify_input_value_limb_12.clone(),
                mem_verify_input_value_limb_13.clone(),
                mem_verify_input_value_limb_14.clone(),
                mem_verify_input_value_limb_15.clone(),
                mem_verify_input_value_limb_16.clone(),
                mem_verify_input_value_limb_17.clone(),
                mem_verify_input_value_limb_18.clone(),
                mem_verify_input_value_limb_19.clone(),
                mem_verify_input_value_limb_20.clone(),
                mem_verify_input_value_limb_21.clone(),
                mem_verify_input_value_limb_22.clone(),
                mem_verify_input_value_limb_23.clone(),
                mem_verify_input_value_limb_24.clone(),
                mem_verify_input_value_limb_25.clone(),
                mem_verify_input_value_limb_26.clone(),
                mem_verify_input_value_limb_27.clone(),
            ],
        ));

        []
    }
}
