// This file was created by the AIR team.

#![allow(unused_parens)]#![cfg_attr(rustfmt, rustfmt_skip)]
use crate::witness::prelude::*;
use cairo_air::components::generic_opcode::{Claim, InteractionClaim, N_TRACE_COLUMNS};
use crate::witness::components::memory_address_to_id;use crate::witness::components::memory_id_to_big;use crate::witness::components::verify_instruction;use crate::witness::components::range_check_9_9;use crate::witness::components::range_check_20;use crate::witness::components::range_check_18;use crate::witness::components::range_check_11;

pub type InputType = CasmState;
pub type PackedInputType = PackedCasmState;

#[derive(Default)]
pub struct ClaimGenerator {
    pub inputs: Vec<InputType>,
}



impl ClaimGenerator {
    pub fn new(inputs: Vec<InputType>) -> Self {
        Self { inputs }
    }

    pub fn write_trace(
        mut self,
        memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
verify_instruction_state: &verify_instruction::ClaimGenerator,
range_check_9_9_state: &range_check_9_9::ClaimGenerator,
range_check_20_state: &range_check_20::ClaimGenerator,
range_check_18_state: &range_check_18::ClaimGenerator,
range_check_11_state: &range_check_11::ClaimGenerator,

    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator)
    {
        let n_active_rows = self.inputs.len();
        assert_ne!(n_active_rows, 0);
        let size = std::cmp::max(n_active_rows.next_power_of_two(), N_LANES);
        let log_size = size.ilog2();
        self.inputs.resize(size, *self.inputs.first().unwrap());
        let packed_inputs = pack_values(&self.inputs);

        let (trace, lookup_data, sub_component_inputs) =
            write_trace_simd(packed_inputs,n_active_rows,memory_address_to_id_state,memory_id_to_big_state,verify_instruction_state,range_check_9_9_state,range_check_20_state,range_check_18_state,range_check_11_state,);
        for inputs in sub_component_inputs.verify_instruction {add_inputs(verify_instruction_state, &inputs, n_active_rows, 0);};for inputs in sub_component_inputs.memory_address_to_id {add_inputs(memory_address_to_id_state, &inputs, n_active_rows, 0);};for inputs in sub_component_inputs.memory_id_to_big {add_inputs(memory_id_to_big_state, &inputs, n_active_rows, 0);};for inputs in sub_component_inputs.range_check_9_9 {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 0);};for inputs in sub_component_inputs.range_check_9_9_b {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 1);};for inputs in sub_component_inputs.range_check_9_9_c {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 2);};for inputs in sub_component_inputs.range_check_9_9_d {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 3);};for inputs in sub_component_inputs.range_check_9_9_e {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 4);};for inputs in sub_component_inputs.range_check_9_9_f {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 5);};for inputs in sub_component_inputs.range_check_9_9_g {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 6);};for inputs in sub_component_inputs.range_check_9_9_h {add_inputs(range_check_9_9_state, &inputs, n_active_rows, 7);};for inputs in sub_component_inputs.range_check_20 {add_inputs(range_check_20_state, &inputs, n_active_rows, 0);};for inputs in sub_component_inputs.range_check_20_b {add_inputs(range_check_20_state, &inputs, n_active_rows, 1);};for inputs in sub_component_inputs.range_check_20_c {add_inputs(range_check_20_state, &inputs, n_active_rows, 2);};for inputs in sub_component_inputs.range_check_20_d {add_inputs(range_check_20_state, &inputs, n_active_rows, 3);};for inputs in sub_component_inputs.range_check_20_e {add_inputs(range_check_20_state, &inputs, n_active_rows, 4);};for inputs in sub_component_inputs.range_check_20_f {add_inputs(range_check_20_state, &inputs, n_active_rows, 5);};for inputs in sub_component_inputs.range_check_20_g {add_inputs(range_check_20_state, &inputs, n_active_rows, 6);};for inputs in sub_component_inputs.range_check_20_h {add_inputs(range_check_20_state, &inputs, n_active_rows, 7);};for inputs in sub_component_inputs.range_check_18 {add_inputs(range_check_18_state, &inputs, n_active_rows, 0);};for inputs in sub_component_inputs.range_check_11 {add_inputs(range_check_11_state, &inputs, n_active_rows, 0);};

        (trace,
        Claim {
            log_size,
        },
        InteractionClaimGenerator {
            log_size,
            lookup_data,
        },
        )
    }
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct SubComponentInputs {
    verify_instruction: [Vec<verify_instruction::PackedInputType>; 1],memory_address_to_id: [Vec<memory_address_to_id::PackedInputType>; 3],memory_id_to_big: [Vec<memory_id_to_big::PackedInputType>; 3],range_check_9_9: [Vec<range_check_9_9::PackedInputType>; 4],range_check_9_9_b: [Vec<range_check_9_9::PackedInputType>; 4],range_check_9_9_c: [Vec<range_check_9_9::PackedInputType>; 4],range_check_9_9_d: [Vec<range_check_9_9::PackedInputType>; 4],range_check_9_9_e: [Vec<range_check_9_9::PackedInputType>; 4],range_check_9_9_f: [Vec<range_check_9_9::PackedInputType>; 4],range_check_9_9_g: [Vec<range_check_9_9::PackedInputType>; 2],range_check_9_9_h: [Vec<range_check_9_9::PackedInputType>; 2],range_check_20: [Vec<range_check_20::PackedInputType>; 4],range_check_20_b: [Vec<range_check_20::PackedInputType>; 4],range_check_20_c: [Vec<range_check_20::PackedInputType>; 4],range_check_20_d: [Vec<range_check_20::PackedInputType>; 4],range_check_20_e: [Vec<range_check_20::PackedInputType>; 3],range_check_20_f: [Vec<range_check_20::PackedInputType>; 3],range_check_20_g: [Vec<range_check_20::PackedInputType>; 3],range_check_20_h: [Vec<range_check_20::PackedInputType>; 3],range_check_18: [Vec<range_check_18::PackedInputType>; 1],range_check_11: [Vec<range_check_11::PackedInputType>; 1],
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    inputs: Vec<PackedInputType>,n_rows: usize,memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
verify_instruction_state: &verify_instruction::ClaimGenerator,
range_check_9_9_state: &range_check_9_9::ClaimGenerator,
range_check_20_state: &range_check_20::ClaimGenerator,
range_check_18_state: &range_check_18::ClaimGenerator,
range_check_11_state: &range_check_11::ClaimGenerator,

) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData,SubComponentInputs,) {
    let log_n_packed_rows = inputs.len().ilog2();
    let log_size = log_n_packed_rows + LOG_N_LANES;
    let (mut trace, mut lookup_data,mut sub_component_inputs,) = unsafe {
        (ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(log_size),
        LookupData::uninitialized(log_n_packed_rows),SubComponentInputs::uninitialized(log_n_packed_rows),)
    };

    let M31_0 = PackedM31::broadcast(
        M31::from(0)
    );let M31_1 = PackedM31::broadcast(
        M31::from(1)
    );let M31_1048576 = PackedM31::broadcast(
        M31::from(1048576)
    );let M31_1109051422 = PackedM31::broadcast(
        M31::from(1109051422)
    );let M31_128 = PackedM31::broadcast(
        M31::from(128)
    );let M31_134217728 = PackedM31::broadcast(
        M31::from(134217728)
    );let M31_136 = PackedM31::broadcast(
        M31::from(136)
    );let M31_1410849886 = PackedM31::broadcast(
        M31::from(1410849886)
    );let M31_1444891767 = PackedM31::broadcast(
        M31::from(1444891767)
    );let M31_16 = PackedM31::broadcast(
        M31::from(16)
    );let M31_1662111297 = PackedM31::broadcast(
        M31::from(1662111297)
    );let M31_1719106205 = PackedM31::broadcast(
        M31::from(1719106205)
    );let M31_1813904000 = PackedM31::broadcast(
        M31::from(1813904000)
    );let M31_1830681619 = PackedM31::broadcast(
        M31::from(1830681619)
    );let M31_1847459238 = PackedM31::broadcast(
        M31::from(1847459238)
    );let M31_1864236857 = PackedM31::broadcast(
        M31::from(1864236857)
    );let M31_1881014476 = PackedM31::broadcast(
        M31::from(1881014476)
    );let M31_1897792095 = PackedM31::broadcast(
        M31::from(1897792095)
    );let M31_2 = PackedM31::broadcast(
        M31::from(2)
    );let M31_2065568285 = PackedM31::broadcast(
        M31::from(2065568285)
    );let M31_256 = PackedM31::broadcast(
        M31::from(256)
    );let M31_262144 = PackedM31::broadcast(
        M31::from(262144)
    );let M31_32 = PackedM31::broadcast(
        M31::from(32)
    );let M31_32768 = PackedM31::broadcast(
        M31::from(32768)
    );let M31_4 = PackedM31::broadcast(
        M31::from(4)
    );let M31_4194304 = PackedM31::broadcast(
        M31::from(4194304)
    );let M31_428564188 = PackedM31::broadcast(
        M31::from(428564188)
    );let M31_447122465 = PackedM31::broadcast(
        M31::from(447122465)
    );let M31_463900084 = PackedM31::broadcast(
        M31::from(463900084)
    );let M31_480677703 = PackedM31::broadcast(
        M31::from(480677703)
    );let M31_497455322 = PackedM31::broadcast(
        M31::from(497455322)
    );let M31_508 = PackedM31::broadcast(
        M31::from(508)
    );let M31_511 = PackedM31::broadcast(
        M31::from(511)
    );let M31_512 = PackedM31::broadcast(
        M31::from(512)
    );let M31_514232941 = PackedM31::broadcast(
        M31::from(514232941)
    );let M31_517791011 = PackedM31::broadcast(
        M31::from(517791011)
    );let M31_524288 = PackedM31::broadcast(
        M31::from(524288)
    );let M31_531010560 = PackedM31::broadcast(
        M31::from(531010560)
    );let M31_536870912 = PackedM31::broadcast(
        M31::from(536870912)
    );let M31_64 = PackedM31::broadcast(
        M31::from(64)
    );let M31_65536 = PackedM31::broadcast(
        M31::from(65536)
    );let M31_682009131 = PackedM31::broadcast(
        M31::from(682009131)
    );let M31_8 = PackedM31::broadcast(
        M31::from(8)
    );let M31_991608089 = PackedM31::broadcast(
        M31::from(991608089)
    );let UInt16_0 = PackedUInt16::broadcast(
        UInt16::from(0)
    );let UInt16_1 = PackedUInt16::broadcast(
        UInt16::from(1)
    );let UInt16_10 = PackedUInt16::broadcast(
        UInt16::from(10)
    );let UInt16_11 = PackedUInt16::broadcast(
        UInt16::from(11)
    );let UInt16_12 = PackedUInt16::broadcast(
        UInt16::from(12)
    );let UInt16_127 = PackedUInt16::broadcast(
        UInt16::from(127)
    );let UInt16_13 = PackedUInt16::broadcast(
        UInt16::from(13)
    );let UInt16_14 = PackedUInt16::broadcast(
        UInt16::from(14)
    );let UInt16_2 = PackedUInt16::broadcast(
        UInt16::from(2)
    );let UInt16_3 = PackedUInt16::broadcast(
        UInt16::from(3)
    );let UInt16_31 = PackedUInt16::broadcast(
        UInt16::from(31)
    );let UInt16_4 = PackedUInt16::broadcast(
        UInt16::from(4)
    );let UInt16_5 = PackedUInt16::broadcast(
        UInt16::from(5)
    );let UInt16_6 = PackedUInt16::broadcast(
        UInt16::from(6)
    );let UInt16_7 = PackedUInt16::broadcast(
        UInt16::from(7)
    );let UInt16_8 = PackedUInt16::broadcast(
        UInt16::from(8)
    );let UInt16_9 = PackedUInt16::broadcast(
        UInt16::from(9)
    );let UInt32_131072 = PackedUInt32::broadcast(
        UInt32::from(131072)
    );let UInt32_2047 = PackedUInt32::broadcast(
        UInt32::from(2047)
    );let UInt32_262143 = PackedUInt32::broadcast(
        UInt32::from(262143)
    );let UInt32_511 = PackedUInt32::broadcast(
        UInt32::from(511)
    );let UInt32_9 = PackedUInt32::broadcast(
        UInt32::from(9)
    );
    let enabler_col = Enabler::new(n_rows);

    (trace.par_iter_mut(),
    lookup_data.par_iter_mut(),sub_component_inputs.par_iter_mut(),inputs.into_par_iter(),)
    .into_par_iter()
    .enumerate()
    .for_each(
        |(row_index,(row, lookup_data,sub_component_inputs,generic_opcode_input,))| {
            let enabler_col0 = enabler_col.packed_at(row_index);
            *row[0] = enabler_col0;let input_pc_col1 = generic_opcode_input.pc;
            *row[1] = input_pc_col1;let input_ap_col2 = generic_opcode_input.ap;
            *row[2] = input_ap_col2;let input_fp_col3 = generic_opcode_input.fp;
            *row[3] = input_fp_col3;

            // Decode Generic Instruction.

            // Decode Instruction.

            let memory_address_to_id_value_tmp_c8168_0 = memory_address_to_id_state.deduce_output(input_pc_col1);let memory_id_to_big_value_tmp_c8168_1 = memory_id_to_big_state.deduce_output(memory_address_to_id_value_tmp_c8168_0);let offset0_tmp_c8168_2 = ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(0))) + (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(1))) & (UInt16_127))) << (UInt16_9))));let offset0_col4 = offset0_tmp_c8168_2.as_m31();
            *row[4] = offset0_col4;let offset1_tmp_c8168_3 = ((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(1))) >> (UInt16_7))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(2))) << (UInt16_2))))) + (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(3))) & (UInt16_31))) << (UInt16_11))));let offset1_col5 = offset1_tmp_c8168_3.as_m31();
            *row[5] = offset1_col5;let offset2_tmp_c8168_4 = ((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(3))) >> (UInt16_5))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(4))) << (UInt16_4))))) + (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) & (UInt16_7))) << (UInt16_13))));let offset2_col6 = offset2_tmp_c8168_4.as_m31();
            *row[6] = offset2_col6;let dst_base_fp_tmp_c8168_5 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_0))) & (UInt16_1));let dst_base_fp_col7 = dst_base_fp_tmp_c8168_5.as_m31();
            *row[7] = dst_base_fp_col7;let op0_base_fp_tmp_c8168_6 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_1))) & (UInt16_1));let op0_base_fp_col8 = op0_base_fp_tmp_c8168_6.as_m31();
            *row[8] = op0_base_fp_col8;let op1_imm_tmp_c8168_7 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_2))) & (UInt16_1));let op1_imm_col9 = op1_imm_tmp_c8168_7.as_m31();
            *row[9] = op1_imm_col9;let op1_base_fp_tmp_c8168_8 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_3))) & (UInt16_1));let op1_base_fp_col10 = op1_base_fp_tmp_c8168_8.as_m31();
            *row[10] = op1_base_fp_col10;let op1_base_ap_tmp_c8168_9 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_4))) & (UInt16_1));let op1_base_ap_col11 = op1_base_ap_tmp_c8168_9.as_m31();
            *row[11] = op1_base_ap_col11;let res_add_tmp_c8168_10 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_5))) & (UInt16_1));let res_add_col12 = res_add_tmp_c8168_10.as_m31();
            *row[12] = res_add_col12;let res_mul_tmp_c8168_11 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_6))) & (UInt16_1));let res_mul_col13 = res_mul_tmp_c8168_11.as_m31();
            *row[13] = res_mul_col13;let pc_update_jump_tmp_c8168_12 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_7))) & (UInt16_1));let pc_update_jump_col14 = pc_update_jump_tmp_c8168_12.as_m31();
            *row[14] = pc_update_jump_col14;let pc_update_jump_rel_tmp_c8168_13 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_8))) & (UInt16_1));let pc_update_jump_rel_col15 = pc_update_jump_rel_tmp_c8168_13.as_m31();
            *row[15] = pc_update_jump_rel_col15;let pc_update_jnz_tmp_c8168_14 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_9))) & (UInt16_1));let pc_update_jnz_col16 = pc_update_jnz_tmp_c8168_14.as_m31();
            *row[16] = pc_update_jnz_col16;let ap_update_add_tmp_c8168_15 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_10))) & (UInt16_1));let ap_update_add_col17 = ap_update_add_tmp_c8168_15.as_m31();
            *row[17] = ap_update_add_col17;let ap_update_add_1_tmp_c8168_16 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_11))) & (UInt16_1));let ap_update_add_1_col18 = ap_update_add_1_tmp_c8168_16.as_m31();
            *row[18] = ap_update_add_1_col18;let opcode_call_tmp_c8168_17 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_12))) & (UInt16_1));let opcode_call_col19 = opcode_call_tmp_c8168_17.as_m31();
            *row[19] = opcode_call_col19;let opcode_ret_tmp_c8168_18 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_13))) & (UInt16_1));let opcode_ret_col20 = opcode_ret_tmp_c8168_18.as_m31();
            *row[20] = opcode_ret_col20;let opcode_assert_eq_tmp_c8168_19 = ((((((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(5))) >> (UInt16_3))) + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_c8168_1.get_m31(6))) << (UInt16_6))))) >> (UInt16_14))) & (UInt16_1));let opcode_assert_eq_col21 = opcode_assert_eq_tmp_c8168_19.as_m31();
            *row[21] = opcode_assert_eq_col21;*sub_component_inputs.verify_instruction[0] =
                (input_pc_col1, [offset0_col4, offset1_col5, offset2_col6], [((((((((((((dst_base_fp_col7) * (M31_8))) + (((op0_base_fp_col8) * (M31_16))))) + (((op1_imm_col9) * (M31_32))))) + (((op1_base_fp_col10) * (M31_64))))) + (((op1_base_ap_col11) * (M31_128))))) + (((res_add_col12) * (M31_256)))), ((((((((((((((((res_mul_col13) + (((pc_update_jump_col14) * (M31_2))))) + (((pc_update_jump_rel_col15) * (M31_4))))) + (((pc_update_jnz_col16) * (M31_8))))) + (((ap_update_add_col17) * (M31_16))))) + (((ap_update_add_1_col18) * (M31_32))))) + (((opcode_call_col19) * (M31_64))))) + (((opcode_ret_col20) * (M31_128))))) + (((opcode_assert_eq_col21) * (M31_256))))], M31_0);
            *lookup_data.verify_instruction_0 = [M31_1719106205, input_pc_col1, offset0_col4, offset1_col5, offset2_col6, ((((((((((((dst_base_fp_col7) * (M31_8))) + (((op0_base_fp_col8) * (M31_16))))) + (((op1_imm_col9) * (M31_32))))) + (((op1_base_fp_col10) * (M31_64))))) + (((op1_base_ap_col11) * (M31_128))))) + (((res_add_col12) * (M31_256)))), ((((((((((((((((res_mul_col13) + (((pc_update_jump_col14) * (M31_2))))) + (((pc_update_jump_rel_col15) * (M31_4))))) + (((pc_update_jnz_col16) * (M31_8))))) + (((ap_update_add_col17) * (M31_16))))) + (((ap_update_add_1_col18) * (M31_32))))) + (((opcode_call_col19) * (M31_64))))) + (((opcode_ret_col20) * (M31_128))))) + (((opcode_assert_eq_col21) * (M31_256)))), M31_0];let decode_instruction_a1c8b_output_tmp_c8168_20 = ([((offset0_col4) - (M31_32768)), ((offset1_col5) - (M31_32768)), ((offset2_col6) - (M31_32768))], [dst_base_fp_col7, op0_base_fp_col8, op1_imm_col9, op1_base_fp_col10, op1_base_ap_col11, res_add_col12, res_mul_col13, pc_update_jump_col14, pc_update_jump_rel_col15, pc_update_jnz_col16, ap_update_add_col17, ap_update_add_1_col18, opcode_call_col19, opcode_ret_col20, opcode_assert_eq_col21], M31_0);

            let op1_base_op0_tmp_c8168_21 = ((((((M31_1) - (op1_imm_col9))) - (op1_base_fp_col10))) - (op1_base_ap_col11));let res_op1_tmp_c8168_22 = ((((((M31_1) - (res_add_col12))) - (res_mul_col13))) - (pc_update_jnz_col16));let pc_update_regular_tmp_c8168_23 = ((((((M31_1) - (pc_update_jump_col14))) - (pc_update_jump_rel_col15))) - (pc_update_jnz_col16));let ap_update_regular_tmp_c8168_24 = ((((((M31_1) - (ap_update_add_col17))) - (ap_update_add_1_col18))) - (opcode_call_col19));let fp_update_regular_tmp_c8168_25 = ((((M31_1) - (opcode_call_col19))) - (opcode_ret_col20));let decode_generic_instruction_output_tmp_c8168_26 = ([dst_base_fp_col7, op0_base_fp_col8, op1_imm_col9, op1_base_fp_col10, op1_base_ap_col11, res_add_col12, res_mul_col13, pc_update_jump_col14, pc_update_jump_rel_col15, pc_update_jnz_col16, ap_update_add_col17, ap_update_add_1_col18, opcode_call_col19, opcode_ret_col20, opcode_assert_eq_col21, op1_base_op0_tmp_c8168_21, res_op1_tmp_c8168_22, pc_update_regular_tmp_c8168_23, fp_update_regular_tmp_c8168_25, ((M31_1) + (op1_imm_col9))], [decode_instruction_a1c8b_output_tmp_c8168_20.0[0], decode_instruction_a1c8b_output_tmp_c8168_20.0[1], decode_instruction_a1c8b_output_tmp_c8168_20.0[2]]);

            // Eval Operands.

            let dst_src_col22 = ((((dst_base_fp_col7) * (input_fp_col3))) + (((((M31_1) - (dst_base_fp_col7))) * (input_ap_col2))));
            *row[22] = dst_src_col22;

            // Read Positive Num Bits 252.

            // Read Id.

            let memory_address_to_id_value_tmp_c8168_27 = memory_address_to_id_state.deduce_output(((dst_src_col22) + (decode_generic_instruction_output_tmp_c8168_26.1[0])));let dst_id_col23 = memory_address_to_id_value_tmp_c8168_27;
            *row[23] = dst_id_col23;*sub_component_inputs.memory_address_to_id[0] =
                ((dst_src_col22) + (decode_generic_instruction_output_tmp_c8168_26.1[0]));
            *lookup_data.memory_address_to_id_1 = [M31_1444891767, ((dst_src_col22) + (decode_generic_instruction_output_tmp_c8168_26.1[0])), dst_id_col23];

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_c8168_29 = memory_id_to_big_state.deduce_output(dst_id_col23);let dst_limb_0_col24 = memory_id_to_big_value_tmp_c8168_29.get_m31(0);
            *row[24] = dst_limb_0_col24;let dst_limb_1_col25 = memory_id_to_big_value_tmp_c8168_29.get_m31(1);
            *row[25] = dst_limb_1_col25;let dst_limb_2_col26 = memory_id_to_big_value_tmp_c8168_29.get_m31(2);
            *row[26] = dst_limb_2_col26;let dst_limb_3_col27 = memory_id_to_big_value_tmp_c8168_29.get_m31(3);
            *row[27] = dst_limb_3_col27;let dst_limb_4_col28 = memory_id_to_big_value_tmp_c8168_29.get_m31(4);
            *row[28] = dst_limb_4_col28;let dst_limb_5_col29 = memory_id_to_big_value_tmp_c8168_29.get_m31(5);
            *row[29] = dst_limb_5_col29;let dst_limb_6_col30 = memory_id_to_big_value_tmp_c8168_29.get_m31(6);
            *row[30] = dst_limb_6_col30;let dst_limb_7_col31 = memory_id_to_big_value_tmp_c8168_29.get_m31(7);
            *row[31] = dst_limb_7_col31;let dst_limb_8_col32 = memory_id_to_big_value_tmp_c8168_29.get_m31(8);
            *row[32] = dst_limb_8_col32;let dst_limb_9_col33 = memory_id_to_big_value_tmp_c8168_29.get_m31(9);
            *row[33] = dst_limb_9_col33;let dst_limb_10_col34 = memory_id_to_big_value_tmp_c8168_29.get_m31(10);
            *row[34] = dst_limb_10_col34;let dst_limb_11_col35 = memory_id_to_big_value_tmp_c8168_29.get_m31(11);
            *row[35] = dst_limb_11_col35;let dst_limb_12_col36 = memory_id_to_big_value_tmp_c8168_29.get_m31(12);
            *row[36] = dst_limb_12_col36;let dst_limb_13_col37 = memory_id_to_big_value_tmp_c8168_29.get_m31(13);
            *row[37] = dst_limb_13_col37;let dst_limb_14_col38 = memory_id_to_big_value_tmp_c8168_29.get_m31(14);
            *row[38] = dst_limb_14_col38;let dst_limb_15_col39 = memory_id_to_big_value_tmp_c8168_29.get_m31(15);
            *row[39] = dst_limb_15_col39;let dst_limb_16_col40 = memory_id_to_big_value_tmp_c8168_29.get_m31(16);
            *row[40] = dst_limb_16_col40;let dst_limb_17_col41 = memory_id_to_big_value_tmp_c8168_29.get_m31(17);
            *row[41] = dst_limb_17_col41;let dst_limb_18_col42 = memory_id_to_big_value_tmp_c8168_29.get_m31(18);
            *row[42] = dst_limb_18_col42;let dst_limb_19_col43 = memory_id_to_big_value_tmp_c8168_29.get_m31(19);
            *row[43] = dst_limb_19_col43;let dst_limb_20_col44 = memory_id_to_big_value_tmp_c8168_29.get_m31(20);
            *row[44] = dst_limb_20_col44;let dst_limb_21_col45 = memory_id_to_big_value_tmp_c8168_29.get_m31(21);
            *row[45] = dst_limb_21_col45;let dst_limb_22_col46 = memory_id_to_big_value_tmp_c8168_29.get_m31(22);
            *row[46] = dst_limb_22_col46;let dst_limb_23_col47 = memory_id_to_big_value_tmp_c8168_29.get_m31(23);
            *row[47] = dst_limb_23_col47;let dst_limb_24_col48 = memory_id_to_big_value_tmp_c8168_29.get_m31(24);
            *row[48] = dst_limb_24_col48;let dst_limb_25_col49 = memory_id_to_big_value_tmp_c8168_29.get_m31(25);
            *row[49] = dst_limb_25_col49;let dst_limb_26_col50 = memory_id_to_big_value_tmp_c8168_29.get_m31(26);
            *row[50] = dst_limb_26_col50;let dst_limb_27_col51 = memory_id_to_big_value_tmp_c8168_29.get_m31(27);
            *row[51] = dst_limb_27_col51;*sub_component_inputs.memory_id_to_big[0] =
                dst_id_col23;
            *lookup_data.memory_id_to_big_2 = [M31_1662111297, dst_id_col23, dst_limb_0_col24, dst_limb_1_col25, dst_limb_2_col26, dst_limb_3_col27, dst_limb_4_col28, dst_limb_5_col29, dst_limb_6_col30, dst_limb_7_col31, dst_limb_8_col32, dst_limb_9_col33, dst_limb_10_col34, dst_limb_11_col35, dst_limb_12_col36, dst_limb_13_col37, dst_limb_14_col38, dst_limb_15_col39, dst_limb_16_col40, dst_limb_17_col41, dst_limb_18_col42, dst_limb_19_col43, dst_limb_20_col44, dst_limb_21_col45, dst_limb_22_col46, dst_limb_23_col47, dst_limb_24_col48, dst_limb_25_col49, dst_limb_26_col50, dst_limb_27_col51];let read_positive_known_id_num_bits_252_output_tmp_c8168_30 = PackedFelt252::from_limbs([dst_limb_0_col24, dst_limb_1_col25, dst_limb_2_col26, dst_limb_3_col27, dst_limb_4_col28, dst_limb_5_col29, dst_limb_6_col30, dst_limb_7_col31, dst_limb_8_col32, dst_limb_9_col33, dst_limb_10_col34, dst_limb_11_col35, dst_limb_12_col36, dst_limb_13_col37, dst_limb_14_col38, dst_limb_15_col39, dst_limb_16_col40, dst_limb_17_col41, dst_limb_18_col42, dst_limb_19_col43, dst_limb_20_col44, dst_limb_21_col45, dst_limb_22_col46, dst_limb_23_col47, dst_limb_24_col48, dst_limb_25_col49, dst_limb_26_col50, dst_limb_27_col51]);

            let read_positive_num_bits_252_output_tmp_c8168_31 = (read_positive_known_id_num_bits_252_output_tmp_c8168_30, dst_id_col23);

            let op0_src_col52 = ((((op0_base_fp_col8) * (input_fp_col3))) + (((((M31_1) - (op0_base_fp_col8))) * (input_ap_col2))));
            *row[52] = op0_src_col52;

            // Read Positive Num Bits 252.

            // Read Id.

            let memory_address_to_id_value_tmp_c8168_32 = memory_address_to_id_state.deduce_output(((op0_src_col52) + (decode_generic_instruction_output_tmp_c8168_26.1[1])));let op0_id_col53 = memory_address_to_id_value_tmp_c8168_32;
            *row[53] = op0_id_col53;*sub_component_inputs.memory_address_to_id[1] =
                ((op0_src_col52) + (decode_generic_instruction_output_tmp_c8168_26.1[1]));
            *lookup_data.memory_address_to_id_3 = [M31_1444891767, ((op0_src_col52) + (decode_generic_instruction_output_tmp_c8168_26.1[1])), op0_id_col53];

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_c8168_34 = memory_id_to_big_state.deduce_output(op0_id_col53);let op0_limb_0_col54 = memory_id_to_big_value_tmp_c8168_34.get_m31(0);
            *row[54] = op0_limb_0_col54;let op0_limb_1_col55 = memory_id_to_big_value_tmp_c8168_34.get_m31(1);
            *row[55] = op0_limb_1_col55;let op0_limb_2_col56 = memory_id_to_big_value_tmp_c8168_34.get_m31(2);
            *row[56] = op0_limb_2_col56;let op0_limb_3_col57 = memory_id_to_big_value_tmp_c8168_34.get_m31(3);
            *row[57] = op0_limb_3_col57;let op0_limb_4_col58 = memory_id_to_big_value_tmp_c8168_34.get_m31(4);
            *row[58] = op0_limb_4_col58;let op0_limb_5_col59 = memory_id_to_big_value_tmp_c8168_34.get_m31(5);
            *row[59] = op0_limb_5_col59;let op0_limb_6_col60 = memory_id_to_big_value_tmp_c8168_34.get_m31(6);
            *row[60] = op0_limb_6_col60;let op0_limb_7_col61 = memory_id_to_big_value_tmp_c8168_34.get_m31(7);
            *row[61] = op0_limb_7_col61;let op0_limb_8_col62 = memory_id_to_big_value_tmp_c8168_34.get_m31(8);
            *row[62] = op0_limb_8_col62;let op0_limb_9_col63 = memory_id_to_big_value_tmp_c8168_34.get_m31(9);
            *row[63] = op0_limb_9_col63;let op0_limb_10_col64 = memory_id_to_big_value_tmp_c8168_34.get_m31(10);
            *row[64] = op0_limb_10_col64;let op0_limb_11_col65 = memory_id_to_big_value_tmp_c8168_34.get_m31(11);
            *row[65] = op0_limb_11_col65;let op0_limb_12_col66 = memory_id_to_big_value_tmp_c8168_34.get_m31(12);
            *row[66] = op0_limb_12_col66;let op0_limb_13_col67 = memory_id_to_big_value_tmp_c8168_34.get_m31(13);
            *row[67] = op0_limb_13_col67;let op0_limb_14_col68 = memory_id_to_big_value_tmp_c8168_34.get_m31(14);
            *row[68] = op0_limb_14_col68;let op0_limb_15_col69 = memory_id_to_big_value_tmp_c8168_34.get_m31(15);
            *row[69] = op0_limb_15_col69;let op0_limb_16_col70 = memory_id_to_big_value_tmp_c8168_34.get_m31(16);
            *row[70] = op0_limb_16_col70;let op0_limb_17_col71 = memory_id_to_big_value_tmp_c8168_34.get_m31(17);
            *row[71] = op0_limb_17_col71;let op0_limb_18_col72 = memory_id_to_big_value_tmp_c8168_34.get_m31(18);
            *row[72] = op0_limb_18_col72;let op0_limb_19_col73 = memory_id_to_big_value_tmp_c8168_34.get_m31(19);
            *row[73] = op0_limb_19_col73;let op0_limb_20_col74 = memory_id_to_big_value_tmp_c8168_34.get_m31(20);
            *row[74] = op0_limb_20_col74;let op0_limb_21_col75 = memory_id_to_big_value_tmp_c8168_34.get_m31(21);
            *row[75] = op0_limb_21_col75;let op0_limb_22_col76 = memory_id_to_big_value_tmp_c8168_34.get_m31(22);
            *row[76] = op0_limb_22_col76;let op0_limb_23_col77 = memory_id_to_big_value_tmp_c8168_34.get_m31(23);
            *row[77] = op0_limb_23_col77;let op0_limb_24_col78 = memory_id_to_big_value_tmp_c8168_34.get_m31(24);
            *row[78] = op0_limb_24_col78;let op0_limb_25_col79 = memory_id_to_big_value_tmp_c8168_34.get_m31(25);
            *row[79] = op0_limb_25_col79;let op0_limb_26_col80 = memory_id_to_big_value_tmp_c8168_34.get_m31(26);
            *row[80] = op0_limb_26_col80;let op0_limb_27_col81 = memory_id_to_big_value_tmp_c8168_34.get_m31(27);
            *row[81] = op0_limb_27_col81;*sub_component_inputs.memory_id_to_big[1] =
                op0_id_col53;
            *lookup_data.memory_id_to_big_4 = [M31_1662111297, op0_id_col53, op0_limb_0_col54, op0_limb_1_col55, op0_limb_2_col56, op0_limb_3_col57, op0_limb_4_col58, op0_limb_5_col59, op0_limb_6_col60, op0_limb_7_col61, op0_limb_8_col62, op0_limb_9_col63, op0_limb_10_col64, op0_limb_11_col65, op0_limb_12_col66, op0_limb_13_col67, op0_limb_14_col68, op0_limb_15_col69, op0_limb_16_col70, op0_limb_17_col71, op0_limb_18_col72, op0_limb_19_col73, op0_limb_20_col74, op0_limb_21_col75, op0_limb_22_col76, op0_limb_23_col77, op0_limb_24_col78, op0_limb_25_col79, op0_limb_26_col80, op0_limb_27_col81];let read_positive_known_id_num_bits_252_output_tmp_c8168_35 = PackedFelt252::from_limbs([op0_limb_0_col54, op0_limb_1_col55, op0_limb_2_col56, op0_limb_3_col57, op0_limb_4_col58, op0_limb_5_col59, op0_limb_6_col60, op0_limb_7_col61, op0_limb_8_col62, op0_limb_9_col63, op0_limb_10_col64, op0_limb_11_col65, op0_limb_12_col66, op0_limb_13_col67, op0_limb_14_col68, op0_limb_15_col69, op0_limb_16_col70, op0_limb_17_col71, op0_limb_18_col72, op0_limb_19_col73, op0_limb_20_col74, op0_limb_21_col75, op0_limb_22_col76, op0_limb_23_col77, op0_limb_24_col78, op0_limb_25_col79, op0_limb_26_col80, op0_limb_27_col81]);

            let read_positive_num_bits_252_output_tmp_c8168_36 = (read_positive_known_id_num_bits_252_output_tmp_c8168_35, op0_id_col53);

            // Cond Felt 252 As Addr.

            // Cond Range Check 2.

            let partial_limb_msb_tmp_c8168_37 = ((((PackedUInt16::from_m31(op0_limb_3_col57)) & (UInt16_2))) >> (UInt16_1));let partial_limb_msb_col82 = partial_limb_msb_tmp_c8168_37.as_m31();
            *row[82] = partial_limb_msb_col82;

            let cond_felt_252_as_addr_output_tmp_c8168_39 = ((((((op0_limb_0_col54) + (((op0_limb_1_col55) * (M31_512))))) + (((op0_limb_2_col56) * (M31_262144))))) + (((op0_limb_3_col57) * (M31_134217728))));

            let op1_src_col83 = ((((((((op1_base_fp_col10) * (input_fp_col3))) + (((op1_base_ap_col11) * (input_ap_col2))))) + (((op1_imm_col9) * (input_pc_col1))))) + (((decode_generic_instruction_output_tmp_c8168_26.0[15]) * (cond_felt_252_as_addr_output_tmp_c8168_39))));
            *row[83] = op1_src_col83;

            // Read Positive Num Bits 252.

            // Read Id.

            let memory_address_to_id_value_tmp_c8168_40 = memory_address_to_id_state.deduce_output(((op1_src_col83) + (decode_generic_instruction_output_tmp_c8168_26.1[2])));let op1_id_col84 = memory_address_to_id_value_tmp_c8168_40;
            *row[84] = op1_id_col84;*sub_component_inputs.memory_address_to_id[2] =
                ((op1_src_col83) + (decode_generic_instruction_output_tmp_c8168_26.1[2]));
            *lookup_data.memory_address_to_id_5 = [M31_1444891767, ((op1_src_col83) + (decode_generic_instruction_output_tmp_c8168_26.1[2])), op1_id_col84];

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_c8168_42 = memory_id_to_big_state.deduce_output(op1_id_col84);let op1_limb_0_col85 = memory_id_to_big_value_tmp_c8168_42.get_m31(0);
            *row[85] = op1_limb_0_col85;let op1_limb_1_col86 = memory_id_to_big_value_tmp_c8168_42.get_m31(1);
            *row[86] = op1_limb_1_col86;let op1_limb_2_col87 = memory_id_to_big_value_tmp_c8168_42.get_m31(2);
            *row[87] = op1_limb_2_col87;let op1_limb_3_col88 = memory_id_to_big_value_tmp_c8168_42.get_m31(3);
            *row[88] = op1_limb_3_col88;let op1_limb_4_col89 = memory_id_to_big_value_tmp_c8168_42.get_m31(4);
            *row[89] = op1_limb_4_col89;let op1_limb_5_col90 = memory_id_to_big_value_tmp_c8168_42.get_m31(5);
            *row[90] = op1_limb_5_col90;let op1_limb_6_col91 = memory_id_to_big_value_tmp_c8168_42.get_m31(6);
            *row[91] = op1_limb_6_col91;let op1_limb_7_col92 = memory_id_to_big_value_tmp_c8168_42.get_m31(7);
            *row[92] = op1_limb_7_col92;let op1_limb_8_col93 = memory_id_to_big_value_tmp_c8168_42.get_m31(8);
            *row[93] = op1_limb_8_col93;let op1_limb_9_col94 = memory_id_to_big_value_tmp_c8168_42.get_m31(9);
            *row[94] = op1_limb_9_col94;let op1_limb_10_col95 = memory_id_to_big_value_tmp_c8168_42.get_m31(10);
            *row[95] = op1_limb_10_col95;let op1_limb_11_col96 = memory_id_to_big_value_tmp_c8168_42.get_m31(11);
            *row[96] = op1_limb_11_col96;let op1_limb_12_col97 = memory_id_to_big_value_tmp_c8168_42.get_m31(12);
            *row[97] = op1_limb_12_col97;let op1_limb_13_col98 = memory_id_to_big_value_tmp_c8168_42.get_m31(13);
            *row[98] = op1_limb_13_col98;let op1_limb_14_col99 = memory_id_to_big_value_tmp_c8168_42.get_m31(14);
            *row[99] = op1_limb_14_col99;let op1_limb_15_col100 = memory_id_to_big_value_tmp_c8168_42.get_m31(15);
            *row[100] = op1_limb_15_col100;let op1_limb_16_col101 = memory_id_to_big_value_tmp_c8168_42.get_m31(16);
            *row[101] = op1_limb_16_col101;let op1_limb_17_col102 = memory_id_to_big_value_tmp_c8168_42.get_m31(17);
            *row[102] = op1_limb_17_col102;let op1_limb_18_col103 = memory_id_to_big_value_tmp_c8168_42.get_m31(18);
            *row[103] = op1_limb_18_col103;let op1_limb_19_col104 = memory_id_to_big_value_tmp_c8168_42.get_m31(19);
            *row[104] = op1_limb_19_col104;let op1_limb_20_col105 = memory_id_to_big_value_tmp_c8168_42.get_m31(20);
            *row[105] = op1_limb_20_col105;let op1_limb_21_col106 = memory_id_to_big_value_tmp_c8168_42.get_m31(21);
            *row[106] = op1_limb_21_col106;let op1_limb_22_col107 = memory_id_to_big_value_tmp_c8168_42.get_m31(22);
            *row[107] = op1_limb_22_col107;let op1_limb_23_col108 = memory_id_to_big_value_tmp_c8168_42.get_m31(23);
            *row[108] = op1_limb_23_col108;let op1_limb_24_col109 = memory_id_to_big_value_tmp_c8168_42.get_m31(24);
            *row[109] = op1_limb_24_col109;let op1_limb_25_col110 = memory_id_to_big_value_tmp_c8168_42.get_m31(25);
            *row[110] = op1_limb_25_col110;let op1_limb_26_col111 = memory_id_to_big_value_tmp_c8168_42.get_m31(26);
            *row[111] = op1_limb_26_col111;let op1_limb_27_col112 = memory_id_to_big_value_tmp_c8168_42.get_m31(27);
            *row[112] = op1_limb_27_col112;*sub_component_inputs.memory_id_to_big[2] =
                op1_id_col84;
            *lookup_data.memory_id_to_big_6 = [M31_1662111297, op1_id_col84, op1_limb_0_col85, op1_limb_1_col86, op1_limb_2_col87, op1_limb_3_col88, op1_limb_4_col89, op1_limb_5_col90, op1_limb_6_col91, op1_limb_7_col92, op1_limb_8_col93, op1_limb_9_col94, op1_limb_10_col95, op1_limb_11_col96, op1_limb_12_col97, op1_limb_13_col98, op1_limb_14_col99, op1_limb_15_col100, op1_limb_16_col101, op1_limb_17_col102, op1_limb_18_col103, op1_limb_19_col104, op1_limb_20_col105, op1_limb_21_col106, op1_limb_22_col107, op1_limb_23_col108, op1_limb_24_col109, op1_limb_25_col110, op1_limb_26_col111, op1_limb_27_col112];let read_positive_known_id_num_bits_252_output_tmp_c8168_43 = PackedFelt252::from_limbs([op1_limb_0_col85, op1_limb_1_col86, op1_limb_2_col87, op1_limb_3_col88, op1_limb_4_col89, op1_limb_5_col90, op1_limb_6_col91, op1_limb_7_col92, op1_limb_8_col93, op1_limb_9_col94, op1_limb_10_col95, op1_limb_11_col96, op1_limb_12_col97, op1_limb_13_col98, op1_limb_14_col99, op1_limb_15_col100, op1_limb_16_col101, op1_limb_17_col102, op1_limb_18_col103, op1_limb_19_col104, op1_limb_20_col105, op1_limb_21_col106, op1_limb_22_col107, op1_limb_23_col108, op1_limb_24_col109, op1_limb_25_col110, op1_limb_26_col111, op1_limb_27_col112]);

            let read_positive_num_bits_252_output_tmp_c8168_44 = (read_positive_known_id_num_bits_252_output_tmp_c8168_43, op1_id_col84);

            // Add 252.

            let add_res_tmp_c8168_45 = ((read_positive_num_bits_252_output_tmp_c8168_36.0) + (read_positive_num_bits_252_output_tmp_c8168_44.0));let add_res_limb_0_col113 = add_res_tmp_c8168_45.get_m31(0);
            *row[113] = add_res_limb_0_col113;let add_res_limb_1_col114 = add_res_tmp_c8168_45.get_m31(1);
            *row[114] = add_res_limb_1_col114;let add_res_limb_2_col115 = add_res_tmp_c8168_45.get_m31(2);
            *row[115] = add_res_limb_2_col115;let add_res_limb_3_col116 = add_res_tmp_c8168_45.get_m31(3);
            *row[116] = add_res_limb_3_col116;let add_res_limb_4_col117 = add_res_tmp_c8168_45.get_m31(4);
            *row[117] = add_res_limb_4_col117;let add_res_limb_5_col118 = add_res_tmp_c8168_45.get_m31(5);
            *row[118] = add_res_limb_5_col118;let add_res_limb_6_col119 = add_res_tmp_c8168_45.get_m31(6);
            *row[119] = add_res_limb_6_col119;let add_res_limb_7_col120 = add_res_tmp_c8168_45.get_m31(7);
            *row[120] = add_res_limb_7_col120;let add_res_limb_8_col121 = add_res_tmp_c8168_45.get_m31(8);
            *row[121] = add_res_limb_8_col121;let add_res_limb_9_col122 = add_res_tmp_c8168_45.get_m31(9);
            *row[122] = add_res_limb_9_col122;let add_res_limb_10_col123 = add_res_tmp_c8168_45.get_m31(10);
            *row[123] = add_res_limb_10_col123;let add_res_limb_11_col124 = add_res_tmp_c8168_45.get_m31(11);
            *row[124] = add_res_limb_11_col124;let add_res_limb_12_col125 = add_res_tmp_c8168_45.get_m31(12);
            *row[125] = add_res_limb_12_col125;let add_res_limb_13_col126 = add_res_tmp_c8168_45.get_m31(13);
            *row[126] = add_res_limb_13_col126;let add_res_limb_14_col127 = add_res_tmp_c8168_45.get_m31(14);
            *row[127] = add_res_limb_14_col127;let add_res_limb_15_col128 = add_res_tmp_c8168_45.get_m31(15);
            *row[128] = add_res_limb_15_col128;let add_res_limb_16_col129 = add_res_tmp_c8168_45.get_m31(16);
            *row[129] = add_res_limb_16_col129;let add_res_limb_17_col130 = add_res_tmp_c8168_45.get_m31(17);
            *row[130] = add_res_limb_17_col130;let add_res_limb_18_col131 = add_res_tmp_c8168_45.get_m31(18);
            *row[131] = add_res_limb_18_col131;let add_res_limb_19_col132 = add_res_tmp_c8168_45.get_m31(19);
            *row[132] = add_res_limb_19_col132;let add_res_limb_20_col133 = add_res_tmp_c8168_45.get_m31(20);
            *row[133] = add_res_limb_20_col133;let add_res_limb_21_col134 = add_res_tmp_c8168_45.get_m31(21);
            *row[134] = add_res_limb_21_col134;let add_res_limb_22_col135 = add_res_tmp_c8168_45.get_m31(22);
            *row[135] = add_res_limb_22_col135;let add_res_limb_23_col136 = add_res_tmp_c8168_45.get_m31(23);
            *row[136] = add_res_limb_23_col136;let add_res_limb_24_col137 = add_res_tmp_c8168_45.get_m31(24);
            *row[137] = add_res_limb_24_col137;let add_res_limb_25_col138 = add_res_tmp_c8168_45.get_m31(25);
            *row[138] = add_res_limb_25_col138;let add_res_limb_26_col139 = add_res_tmp_c8168_45.get_m31(26);
            *row[139] = add_res_limb_26_col139;let add_res_limb_27_col140 = add_res_tmp_c8168_45.get_m31(27);
            *row[140] = add_res_limb_27_col140;

            // Range Check Mem Value N 28.

            *sub_component_inputs.range_check_9_9[0] =
                [add_res_limb_0_col113, add_res_limb_1_col114];
            *lookup_data.range_check_9_9_7 = [M31_517791011, add_res_limb_0_col113, add_res_limb_1_col114];*sub_component_inputs.range_check_9_9_b[0] =
                [add_res_limb_2_col115, add_res_limb_3_col116];
            *lookup_data.range_check_9_9_b_8 = [M31_1897792095, add_res_limb_2_col115, add_res_limb_3_col116];*sub_component_inputs.range_check_9_9_c[0] =
                [add_res_limb_4_col117, add_res_limb_5_col118];
            *lookup_data.range_check_9_9_c_9 = [M31_1881014476, add_res_limb_4_col117, add_res_limb_5_col118];*sub_component_inputs.range_check_9_9_d[0] =
                [add_res_limb_6_col119, add_res_limb_7_col120];
            *lookup_data.range_check_9_9_d_10 = [M31_1864236857, add_res_limb_6_col119, add_res_limb_7_col120];*sub_component_inputs.range_check_9_9_e[0] =
                [add_res_limb_8_col121, add_res_limb_9_col122];
            *lookup_data.range_check_9_9_e_11 = [M31_1847459238, add_res_limb_8_col121, add_res_limb_9_col122];*sub_component_inputs.range_check_9_9_f[0] =
                [add_res_limb_10_col123, add_res_limb_11_col124];
            *lookup_data.range_check_9_9_f_12 = [M31_1830681619, add_res_limb_10_col123, add_res_limb_11_col124];*sub_component_inputs.range_check_9_9_g[0] =
                [add_res_limb_12_col125, add_res_limb_13_col126];
            *lookup_data.range_check_9_9_g_13 = [M31_1813904000, add_res_limb_12_col125, add_res_limb_13_col126];*sub_component_inputs.range_check_9_9_h[0] =
                [add_res_limb_14_col127, add_res_limb_15_col128];
            *lookup_data.range_check_9_9_h_14 = [M31_2065568285, add_res_limb_14_col127, add_res_limb_15_col128];*sub_component_inputs.range_check_9_9[1] =
                [add_res_limb_16_col129, add_res_limb_17_col130];
            *lookup_data.range_check_9_9_15 = [M31_517791011, add_res_limb_16_col129, add_res_limb_17_col130];*sub_component_inputs.range_check_9_9_b[1] =
                [add_res_limb_18_col131, add_res_limb_19_col132];
            *lookup_data.range_check_9_9_b_16 = [M31_1897792095, add_res_limb_18_col131, add_res_limb_19_col132];*sub_component_inputs.range_check_9_9_c[1] =
                [add_res_limb_20_col133, add_res_limb_21_col134];
            *lookup_data.range_check_9_9_c_17 = [M31_1881014476, add_res_limb_20_col133, add_res_limb_21_col134];*sub_component_inputs.range_check_9_9_d[1] =
                [add_res_limb_22_col135, add_res_limb_23_col136];
            *lookup_data.range_check_9_9_d_18 = [M31_1864236857, add_res_limb_22_col135, add_res_limb_23_col136];*sub_component_inputs.range_check_9_9_e[1] =
                [add_res_limb_24_col137, add_res_limb_25_col138];
            *lookup_data.range_check_9_9_e_19 = [M31_1847459238, add_res_limb_24_col137, add_res_limb_25_col138];*sub_component_inputs.range_check_9_9_f[1] =
                [add_res_limb_26_col139, add_res_limb_27_col140];
            *lookup_data.range_check_9_9_f_20 = [M31_1830681619, add_res_limb_26_col139, add_res_limb_27_col140];

            // Verify Add 252.

            let sub_p_bit_tmp_c8168_46 = ((UInt16_1) & (((((PackedUInt16::from_m31(op0_limb_0_col54)) ^ (PackedUInt16::from_m31(op1_limb_0_col85)))) ^ (PackedUInt16::from_m31(add_res_limb_0_col113)))));let sub_p_bit_col141 = sub_p_bit_tmp_c8168_46.as_m31();
            *row[141] = sub_p_bit_col141;

            let add_252_output_tmp_c8168_56 = add_res_tmp_c8168_45;

            // Mul 252.

            let mul_res_tmp_c8168_57 = ((read_positive_num_bits_252_output_tmp_c8168_36.0) * (read_positive_num_bits_252_output_tmp_c8168_44.0));let mul_res_limb_0_col142 = mul_res_tmp_c8168_57.get_m31(0);
            *row[142] = mul_res_limb_0_col142;let mul_res_limb_1_col143 = mul_res_tmp_c8168_57.get_m31(1);
            *row[143] = mul_res_limb_1_col143;let mul_res_limb_2_col144 = mul_res_tmp_c8168_57.get_m31(2);
            *row[144] = mul_res_limb_2_col144;let mul_res_limb_3_col145 = mul_res_tmp_c8168_57.get_m31(3);
            *row[145] = mul_res_limb_3_col145;let mul_res_limb_4_col146 = mul_res_tmp_c8168_57.get_m31(4);
            *row[146] = mul_res_limb_4_col146;let mul_res_limb_5_col147 = mul_res_tmp_c8168_57.get_m31(5);
            *row[147] = mul_res_limb_5_col147;let mul_res_limb_6_col148 = mul_res_tmp_c8168_57.get_m31(6);
            *row[148] = mul_res_limb_6_col148;let mul_res_limb_7_col149 = mul_res_tmp_c8168_57.get_m31(7);
            *row[149] = mul_res_limb_7_col149;let mul_res_limb_8_col150 = mul_res_tmp_c8168_57.get_m31(8);
            *row[150] = mul_res_limb_8_col150;let mul_res_limb_9_col151 = mul_res_tmp_c8168_57.get_m31(9);
            *row[151] = mul_res_limb_9_col151;let mul_res_limb_10_col152 = mul_res_tmp_c8168_57.get_m31(10);
            *row[152] = mul_res_limb_10_col152;let mul_res_limb_11_col153 = mul_res_tmp_c8168_57.get_m31(11);
            *row[153] = mul_res_limb_11_col153;let mul_res_limb_12_col154 = mul_res_tmp_c8168_57.get_m31(12);
            *row[154] = mul_res_limb_12_col154;let mul_res_limb_13_col155 = mul_res_tmp_c8168_57.get_m31(13);
            *row[155] = mul_res_limb_13_col155;let mul_res_limb_14_col156 = mul_res_tmp_c8168_57.get_m31(14);
            *row[156] = mul_res_limb_14_col156;let mul_res_limb_15_col157 = mul_res_tmp_c8168_57.get_m31(15);
            *row[157] = mul_res_limb_15_col157;let mul_res_limb_16_col158 = mul_res_tmp_c8168_57.get_m31(16);
            *row[158] = mul_res_limb_16_col158;let mul_res_limb_17_col159 = mul_res_tmp_c8168_57.get_m31(17);
            *row[159] = mul_res_limb_17_col159;let mul_res_limb_18_col160 = mul_res_tmp_c8168_57.get_m31(18);
            *row[160] = mul_res_limb_18_col160;let mul_res_limb_19_col161 = mul_res_tmp_c8168_57.get_m31(19);
            *row[161] = mul_res_limb_19_col161;let mul_res_limb_20_col162 = mul_res_tmp_c8168_57.get_m31(20);
            *row[162] = mul_res_limb_20_col162;let mul_res_limb_21_col163 = mul_res_tmp_c8168_57.get_m31(21);
            *row[163] = mul_res_limb_21_col163;let mul_res_limb_22_col164 = mul_res_tmp_c8168_57.get_m31(22);
            *row[164] = mul_res_limb_22_col164;let mul_res_limb_23_col165 = mul_res_tmp_c8168_57.get_m31(23);
            *row[165] = mul_res_limb_23_col165;let mul_res_limb_24_col166 = mul_res_tmp_c8168_57.get_m31(24);
            *row[166] = mul_res_limb_24_col166;let mul_res_limb_25_col167 = mul_res_tmp_c8168_57.get_m31(25);
            *row[167] = mul_res_limb_25_col167;let mul_res_limb_26_col168 = mul_res_tmp_c8168_57.get_m31(26);
            *row[168] = mul_res_limb_26_col168;let mul_res_limb_27_col169 = mul_res_tmp_c8168_57.get_m31(27);
            *row[169] = mul_res_limb_27_col169;

            // Range Check Mem Value N 28.

            *sub_component_inputs.range_check_9_9[2] =
                [mul_res_limb_0_col142, mul_res_limb_1_col143];
            *lookup_data.range_check_9_9_21 = [M31_517791011, mul_res_limb_0_col142, mul_res_limb_1_col143];*sub_component_inputs.range_check_9_9_b[2] =
                [mul_res_limb_2_col144, mul_res_limb_3_col145];
            *lookup_data.range_check_9_9_b_22 = [M31_1897792095, mul_res_limb_2_col144, mul_res_limb_3_col145];*sub_component_inputs.range_check_9_9_c[2] =
                [mul_res_limb_4_col146, mul_res_limb_5_col147];
            *lookup_data.range_check_9_9_c_23 = [M31_1881014476, mul_res_limb_4_col146, mul_res_limb_5_col147];*sub_component_inputs.range_check_9_9_d[2] =
                [mul_res_limb_6_col148, mul_res_limb_7_col149];
            *lookup_data.range_check_9_9_d_24 = [M31_1864236857, mul_res_limb_6_col148, mul_res_limb_7_col149];*sub_component_inputs.range_check_9_9_e[2] =
                [mul_res_limb_8_col150, mul_res_limb_9_col151];
            *lookup_data.range_check_9_9_e_25 = [M31_1847459238, mul_res_limb_8_col150, mul_res_limb_9_col151];*sub_component_inputs.range_check_9_9_f[2] =
                [mul_res_limb_10_col152, mul_res_limb_11_col153];
            *lookup_data.range_check_9_9_f_26 = [M31_1830681619, mul_res_limb_10_col152, mul_res_limb_11_col153];*sub_component_inputs.range_check_9_9_g[1] =
                [mul_res_limb_12_col154, mul_res_limb_13_col155];
            *lookup_data.range_check_9_9_g_27 = [M31_1813904000, mul_res_limb_12_col154, mul_res_limb_13_col155];*sub_component_inputs.range_check_9_9_h[1] =
                [mul_res_limb_14_col156, mul_res_limb_15_col157];
            *lookup_data.range_check_9_9_h_28 = [M31_2065568285, mul_res_limb_14_col156, mul_res_limb_15_col157];*sub_component_inputs.range_check_9_9[3] =
                [mul_res_limb_16_col158, mul_res_limb_17_col159];
            *lookup_data.range_check_9_9_29 = [M31_517791011, mul_res_limb_16_col158, mul_res_limb_17_col159];*sub_component_inputs.range_check_9_9_b[3] =
                [mul_res_limb_18_col160, mul_res_limb_19_col161];
            *lookup_data.range_check_9_9_b_30 = [M31_1897792095, mul_res_limb_18_col160, mul_res_limb_19_col161];*sub_component_inputs.range_check_9_9_c[3] =
                [mul_res_limb_20_col162, mul_res_limb_21_col163];
            *lookup_data.range_check_9_9_c_31 = [M31_1881014476, mul_res_limb_20_col162, mul_res_limb_21_col163];*sub_component_inputs.range_check_9_9_d[3] =
                [mul_res_limb_22_col164, mul_res_limb_23_col165];
            *lookup_data.range_check_9_9_d_32 = [M31_1864236857, mul_res_limb_22_col164, mul_res_limb_23_col165];*sub_component_inputs.range_check_9_9_e[3] =
                [mul_res_limb_24_col166, mul_res_limb_25_col167];
            *lookup_data.range_check_9_9_e_33 = [M31_1847459238, mul_res_limb_24_col166, mul_res_limb_25_col167];*sub_component_inputs.range_check_9_9_f[3] =
                [mul_res_limb_26_col168, mul_res_limb_27_col169];
            *lookup_data.range_check_9_9_f_34 = [M31_1830681619, mul_res_limb_26_col168, mul_res_limb_27_col169];

            // Verify Mul 252.

            // Double Karatsuba F 0 Fc 6.

            // Single Karatsuba N 7.

            let z0_tmp_c8168_58 = [((op0_limb_0_col54) * (op1_limb_0_col85)), ((((op0_limb_0_col54) * (op1_limb_1_col86))) + (((op0_limb_1_col55) * (op1_limb_0_col85)))), ((((((op0_limb_0_col54) * (op1_limb_2_col87))) + (((op0_limb_1_col55) * (op1_limb_1_col86))))) + (((op0_limb_2_col56) * (op1_limb_0_col85)))), ((((((((op0_limb_0_col54) * (op1_limb_3_col88))) + (((op0_limb_1_col55) * (op1_limb_2_col87))))) + (((op0_limb_2_col56) * (op1_limb_1_col86))))) + (((op0_limb_3_col57) * (op1_limb_0_col85)))), ((((((((((op0_limb_0_col54) * (op1_limb_4_col89))) + (((op0_limb_1_col55) * (op1_limb_3_col88))))) + (((op0_limb_2_col56) * (op1_limb_2_col87))))) + (((op0_limb_3_col57) * (op1_limb_1_col86))))) + (((op0_limb_4_col58) * (op1_limb_0_col85)))), ((((((((((((op0_limb_0_col54) * (op1_limb_5_col90))) + (((op0_limb_1_col55) * (op1_limb_4_col89))))) + (((op0_limb_2_col56) * (op1_limb_3_col88))))) + (((op0_limb_3_col57) * (op1_limb_2_col87))))) + (((op0_limb_4_col58) * (op1_limb_1_col86))))) + (((op0_limb_5_col59) * (op1_limb_0_col85)))), ((((((((((((((op0_limb_0_col54) * (op1_limb_6_col91))) + (((op0_limb_1_col55) * (op1_limb_5_col90))))) + (((op0_limb_2_col56) * (op1_limb_4_col89))))) + (((op0_limb_3_col57) * (op1_limb_3_col88))))) + (((op0_limb_4_col58) * (op1_limb_2_col87))))) + (((op0_limb_5_col59) * (op1_limb_1_col86))))) + (((op0_limb_6_col60) * (op1_limb_0_col85)))), ((((((((((((op0_limb_1_col55) * (op1_limb_6_col91))) + (((op0_limb_2_col56) * (op1_limb_5_col90))))) + (((op0_limb_3_col57) * (op1_limb_4_col89))))) + (((op0_limb_4_col58) * (op1_limb_3_col88))))) + (((op0_limb_5_col59) * (op1_limb_2_col87))))) + (((op0_limb_6_col60) * (op1_limb_1_col86)))), ((((((((((op0_limb_2_col56) * (op1_limb_6_col91))) + (((op0_limb_3_col57) * (op1_limb_5_col90))))) + (((op0_limb_4_col58) * (op1_limb_4_col89))))) + (((op0_limb_5_col59) * (op1_limb_3_col88))))) + (((op0_limb_6_col60) * (op1_limb_2_col87)))), ((((((((op0_limb_3_col57) * (op1_limb_6_col91))) + (((op0_limb_4_col58) * (op1_limb_5_col90))))) + (((op0_limb_5_col59) * (op1_limb_4_col89))))) + (((op0_limb_6_col60) * (op1_limb_3_col88)))), ((((((op0_limb_4_col58) * (op1_limb_6_col91))) + (((op0_limb_5_col59) * (op1_limb_5_col90))))) + (((op0_limb_6_col60) * (op1_limb_4_col89)))), ((((op0_limb_5_col59) * (op1_limb_6_col91))) + (((op0_limb_6_col60) * (op1_limb_5_col90)))), ((op0_limb_6_col60) * (op1_limb_6_col91))];let z2_tmp_c8168_59 = [((op0_limb_7_col61) * (op1_limb_7_col92)), ((((op0_limb_7_col61) * (op1_limb_8_col93))) + (((op0_limb_8_col62) * (op1_limb_7_col92)))), ((((((op0_limb_7_col61) * (op1_limb_9_col94))) + (((op0_limb_8_col62) * (op1_limb_8_col93))))) + (((op0_limb_9_col63) * (op1_limb_7_col92)))), ((((((((op0_limb_7_col61) * (op1_limb_10_col95))) + (((op0_limb_8_col62) * (op1_limb_9_col94))))) + (((op0_limb_9_col63) * (op1_limb_8_col93))))) + (((op0_limb_10_col64) * (op1_limb_7_col92)))), ((((((((((op0_limb_7_col61) * (op1_limb_11_col96))) + (((op0_limb_8_col62) * (op1_limb_10_col95))))) + (((op0_limb_9_col63) * (op1_limb_9_col94))))) + (((op0_limb_10_col64) * (op1_limb_8_col93))))) + (((op0_limb_11_col65) * (op1_limb_7_col92)))), ((((((((((((op0_limb_7_col61) * (op1_limb_12_col97))) + (((op0_limb_8_col62) * (op1_limb_11_col96))))) + (((op0_limb_9_col63) * (op1_limb_10_col95))))) + (((op0_limb_10_col64) * (op1_limb_9_col94))))) + (((op0_limb_11_col65) * (op1_limb_8_col93))))) + (((op0_limb_12_col66) * (op1_limb_7_col92)))), ((((((((((((((op0_limb_7_col61) * (op1_limb_13_col98))) + (((op0_limb_8_col62) * (op1_limb_12_col97))))) + (((op0_limb_9_col63) * (op1_limb_11_col96))))) + (((op0_limb_10_col64) * (op1_limb_10_col95))))) + (((op0_limb_11_col65) * (op1_limb_9_col94))))) + (((op0_limb_12_col66) * (op1_limb_8_col93))))) + (((op0_limb_13_col67) * (op1_limb_7_col92)))), ((((((((((((op0_limb_8_col62) * (op1_limb_13_col98))) + (((op0_limb_9_col63) * (op1_limb_12_col97))))) + (((op0_limb_10_col64) * (op1_limb_11_col96))))) + (((op0_limb_11_col65) * (op1_limb_10_col95))))) + (((op0_limb_12_col66) * (op1_limb_9_col94))))) + (((op0_limb_13_col67) * (op1_limb_8_col93)))), ((((((((((op0_limb_9_col63) * (op1_limb_13_col98))) + (((op0_limb_10_col64) * (op1_limb_12_col97))))) + (((op0_limb_11_col65) * (op1_limb_11_col96))))) + (((op0_limb_12_col66) * (op1_limb_10_col95))))) + (((op0_limb_13_col67) * (op1_limb_9_col94)))), ((((((((op0_limb_10_col64) * (op1_limb_13_col98))) + (((op0_limb_11_col65) * (op1_limb_12_col97))))) + (((op0_limb_12_col66) * (op1_limb_11_col96))))) + (((op0_limb_13_col67) * (op1_limb_10_col95)))), ((((((op0_limb_11_col65) * (op1_limb_13_col98))) + (((op0_limb_12_col66) * (op1_limb_12_col97))))) + (((op0_limb_13_col67) * (op1_limb_11_col96)))), ((((op0_limb_12_col66) * (op1_limb_13_col98))) + (((op0_limb_13_col67) * (op1_limb_12_col97)))), ((op0_limb_13_col67) * (op1_limb_13_col98))];let x_sum_tmp_c8168_60 = [((op0_limb_0_col54) + (op0_limb_7_col61)), ((op0_limb_1_col55) + (op0_limb_8_col62)), ((op0_limb_2_col56) + (op0_limb_9_col63)), ((op0_limb_3_col57) + (op0_limb_10_col64)), ((op0_limb_4_col58) + (op0_limb_11_col65)), ((op0_limb_5_col59) + (op0_limb_12_col66)), ((op0_limb_6_col60) + (op0_limb_13_col67))];let y_sum_tmp_c8168_61 = [((op1_limb_0_col85) + (op1_limb_7_col92)), ((op1_limb_1_col86) + (op1_limb_8_col93)), ((op1_limb_2_col87) + (op1_limb_9_col94)), ((op1_limb_3_col88) + (op1_limb_10_col95)), ((op1_limb_4_col89) + (op1_limb_11_col96)), ((op1_limb_5_col90) + (op1_limb_12_col97)), ((op1_limb_6_col91) + (op1_limb_13_col98))];let single_karatsuba_n_7_output_tmp_c8168_62 = [z0_tmp_c8168_58[0], z0_tmp_c8168_58[1], z0_tmp_c8168_58[2], z0_tmp_c8168_58[3], z0_tmp_c8168_58[4], z0_tmp_c8168_58[5], z0_tmp_c8168_58[6], ((z0_tmp_c8168_58[7]) + (((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[0]))) - (z0_tmp_c8168_58[0]))) - (z2_tmp_c8168_59[0])))), ((z0_tmp_c8168_58[8]) + (((((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[1]))) + (((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[0]))))) - (z0_tmp_c8168_58[1]))) - (z2_tmp_c8168_59[1])))), ((z0_tmp_c8168_58[9]) + (((((((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[2]))) + (((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[1]))))) + (((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[0]))))) - (z0_tmp_c8168_58[2]))) - (z2_tmp_c8168_59[2])))), ((z0_tmp_c8168_58[10]) + (((((((((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[3]))) + (((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[2]))))) + (((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[1]))))) + (((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[0]))))) - (z0_tmp_c8168_58[3]))) - (z2_tmp_c8168_59[3])))), ((z0_tmp_c8168_58[11]) + (((((((((((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[4]))) + (((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[3]))))) + (((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[2]))))) + (((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[1]))))) + (((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[0]))))) - (z0_tmp_c8168_58[4]))) - (z2_tmp_c8168_59[4])))), ((z0_tmp_c8168_58[12]) + (((((((((((((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[5]))) + (((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[4]))))) + (((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[3]))))) + (((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[2]))))) + (((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[1]))))) + (((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[0]))))) - (z0_tmp_c8168_58[5]))) - (z2_tmp_c8168_59[5])))), ((((((((((((((((((x_sum_tmp_c8168_60[0]) * (y_sum_tmp_c8168_61[6]))) + (((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[5]))))) + (((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[4]))))) + (((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[3]))))) + (((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[2]))))) + (((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[1]))))) + (((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[0]))))) - (z0_tmp_c8168_58[6]))) - (z2_tmp_c8168_59[6])), ((z2_tmp_c8168_59[0]) + (((((((((((((((((x_sum_tmp_c8168_60[1]) * (y_sum_tmp_c8168_61[6]))) + (((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[5]))))) + (((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[4]))))) + (((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[3]))))) + (((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[2]))))) + (((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[1]))))) - (z0_tmp_c8168_58[7]))) - (z2_tmp_c8168_59[7])))), ((z2_tmp_c8168_59[1]) + (((((((((((((((x_sum_tmp_c8168_60[2]) * (y_sum_tmp_c8168_61[6]))) + (((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[5]))))) + (((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[4]))))) + (((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[3]))))) + (((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[2]))))) - (z0_tmp_c8168_58[8]))) - (z2_tmp_c8168_59[8])))), ((z2_tmp_c8168_59[2]) + (((((((((((((x_sum_tmp_c8168_60[3]) * (y_sum_tmp_c8168_61[6]))) + (((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[5]))))) + (((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[4]))))) + (((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[3]))))) - (z0_tmp_c8168_58[9]))) - (z2_tmp_c8168_59[9])))), ((z2_tmp_c8168_59[3]) + (((((((((((x_sum_tmp_c8168_60[4]) * (y_sum_tmp_c8168_61[6]))) + (((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[5]))))) + (((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[4]))))) - (z0_tmp_c8168_58[10]))) - (z2_tmp_c8168_59[10])))), ((z2_tmp_c8168_59[4]) + (((((((((x_sum_tmp_c8168_60[5]) * (y_sum_tmp_c8168_61[6]))) + (((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[5]))))) - (z0_tmp_c8168_58[11]))) - (z2_tmp_c8168_59[11])))), ((z2_tmp_c8168_59[5]) + (((((((x_sum_tmp_c8168_60[6]) * (y_sum_tmp_c8168_61[6]))) - (z0_tmp_c8168_58[12]))) - (z2_tmp_c8168_59[12])))), z2_tmp_c8168_59[6], z2_tmp_c8168_59[7], z2_tmp_c8168_59[8], z2_tmp_c8168_59[9], z2_tmp_c8168_59[10], z2_tmp_c8168_59[11], z2_tmp_c8168_59[12]];

            // Single Karatsuba N 7.

            let z0_tmp_c8168_63 = [((op0_limb_14_col68) * (op1_limb_14_col99)), ((((op0_limb_14_col68) * (op1_limb_15_col100))) + (((op0_limb_15_col69) * (op1_limb_14_col99)))), ((((((op0_limb_14_col68) * (op1_limb_16_col101))) + (((op0_limb_15_col69) * (op1_limb_15_col100))))) + (((op0_limb_16_col70) * (op1_limb_14_col99)))), ((((((((op0_limb_14_col68) * (op1_limb_17_col102))) + (((op0_limb_15_col69) * (op1_limb_16_col101))))) + (((op0_limb_16_col70) * (op1_limb_15_col100))))) + (((op0_limb_17_col71) * (op1_limb_14_col99)))), ((((((((((op0_limb_14_col68) * (op1_limb_18_col103))) + (((op0_limb_15_col69) * (op1_limb_17_col102))))) + (((op0_limb_16_col70) * (op1_limb_16_col101))))) + (((op0_limb_17_col71) * (op1_limb_15_col100))))) + (((op0_limb_18_col72) * (op1_limb_14_col99)))), ((((((((((((op0_limb_14_col68) * (op1_limb_19_col104))) + (((op0_limb_15_col69) * (op1_limb_18_col103))))) + (((op0_limb_16_col70) * (op1_limb_17_col102))))) + (((op0_limb_17_col71) * (op1_limb_16_col101))))) + (((op0_limb_18_col72) * (op1_limb_15_col100))))) + (((op0_limb_19_col73) * (op1_limb_14_col99)))), ((((((((((((((op0_limb_14_col68) * (op1_limb_20_col105))) + (((op0_limb_15_col69) * (op1_limb_19_col104))))) + (((op0_limb_16_col70) * (op1_limb_18_col103))))) + (((op0_limb_17_col71) * (op1_limb_17_col102))))) + (((op0_limb_18_col72) * (op1_limb_16_col101))))) + (((op0_limb_19_col73) * (op1_limb_15_col100))))) + (((op0_limb_20_col74) * (op1_limb_14_col99)))), ((((((((((((op0_limb_15_col69) * (op1_limb_20_col105))) + (((op0_limb_16_col70) * (op1_limb_19_col104))))) + (((op0_limb_17_col71) * (op1_limb_18_col103))))) + (((op0_limb_18_col72) * (op1_limb_17_col102))))) + (((op0_limb_19_col73) * (op1_limb_16_col101))))) + (((op0_limb_20_col74) * (op1_limb_15_col100)))), ((((((((((op0_limb_16_col70) * (op1_limb_20_col105))) + (((op0_limb_17_col71) * (op1_limb_19_col104))))) + (((op0_limb_18_col72) * (op1_limb_18_col103))))) + (((op0_limb_19_col73) * (op1_limb_17_col102))))) + (((op0_limb_20_col74) * (op1_limb_16_col101)))), ((((((((op0_limb_17_col71) * (op1_limb_20_col105))) + (((op0_limb_18_col72) * (op1_limb_19_col104))))) + (((op0_limb_19_col73) * (op1_limb_18_col103))))) + (((op0_limb_20_col74) * (op1_limb_17_col102)))), ((((((op0_limb_18_col72) * (op1_limb_20_col105))) + (((op0_limb_19_col73) * (op1_limb_19_col104))))) + (((op0_limb_20_col74) * (op1_limb_18_col103)))), ((((op0_limb_19_col73) * (op1_limb_20_col105))) + (((op0_limb_20_col74) * (op1_limb_19_col104)))), ((op0_limb_20_col74) * (op1_limb_20_col105))];let z2_tmp_c8168_64 = [((op0_limb_21_col75) * (op1_limb_21_col106)), ((((op0_limb_21_col75) * (op1_limb_22_col107))) + (((op0_limb_22_col76) * (op1_limb_21_col106)))), ((((((op0_limb_21_col75) * (op1_limb_23_col108))) + (((op0_limb_22_col76) * (op1_limb_22_col107))))) + (((op0_limb_23_col77) * (op1_limb_21_col106)))), ((((((((op0_limb_21_col75) * (op1_limb_24_col109))) + (((op0_limb_22_col76) * (op1_limb_23_col108))))) + (((op0_limb_23_col77) * (op1_limb_22_col107))))) + (((op0_limb_24_col78) * (op1_limb_21_col106)))), ((((((((((op0_limb_21_col75) * (op1_limb_25_col110))) + (((op0_limb_22_col76) * (op1_limb_24_col109))))) + (((op0_limb_23_col77) * (op1_limb_23_col108))))) + (((op0_limb_24_col78) * (op1_limb_22_col107))))) + (((op0_limb_25_col79) * (op1_limb_21_col106)))), ((((((((((((op0_limb_21_col75) * (op1_limb_26_col111))) + (((op0_limb_22_col76) * (op1_limb_25_col110))))) + (((op0_limb_23_col77) * (op1_limb_24_col109))))) + (((op0_limb_24_col78) * (op1_limb_23_col108))))) + (((op0_limb_25_col79) * (op1_limb_22_col107))))) + (((op0_limb_26_col80) * (op1_limb_21_col106)))), ((((((((((((((op0_limb_21_col75) * (op1_limb_27_col112))) + (((op0_limb_22_col76) * (op1_limb_26_col111))))) + (((op0_limb_23_col77) * (op1_limb_25_col110))))) + (((op0_limb_24_col78) * (op1_limb_24_col109))))) + (((op0_limb_25_col79) * (op1_limb_23_col108))))) + (((op0_limb_26_col80) * (op1_limb_22_col107))))) + (((op0_limb_27_col81) * (op1_limb_21_col106)))), ((((((((((((op0_limb_22_col76) * (op1_limb_27_col112))) + (((op0_limb_23_col77) * (op1_limb_26_col111))))) + (((op0_limb_24_col78) * (op1_limb_25_col110))))) + (((op0_limb_25_col79) * (op1_limb_24_col109))))) + (((op0_limb_26_col80) * (op1_limb_23_col108))))) + (((op0_limb_27_col81) * (op1_limb_22_col107)))), ((((((((((op0_limb_23_col77) * (op1_limb_27_col112))) + (((op0_limb_24_col78) * (op1_limb_26_col111))))) + (((op0_limb_25_col79) * (op1_limb_25_col110))))) + (((op0_limb_26_col80) * (op1_limb_24_col109))))) + (((op0_limb_27_col81) * (op1_limb_23_col108)))), ((((((((op0_limb_24_col78) * (op1_limb_27_col112))) + (((op0_limb_25_col79) * (op1_limb_26_col111))))) + (((op0_limb_26_col80) * (op1_limb_25_col110))))) + (((op0_limb_27_col81) * (op1_limb_24_col109)))), ((((((op0_limb_25_col79) * (op1_limb_27_col112))) + (((op0_limb_26_col80) * (op1_limb_26_col111))))) + (((op0_limb_27_col81) * (op1_limb_25_col110)))), ((((op0_limb_26_col80) * (op1_limb_27_col112))) + (((op0_limb_27_col81) * (op1_limb_26_col111)))), ((op0_limb_27_col81) * (op1_limb_27_col112))];let x_sum_tmp_c8168_65 = [((op0_limb_14_col68) + (op0_limb_21_col75)), ((op0_limb_15_col69) + (op0_limb_22_col76)), ((op0_limb_16_col70) + (op0_limb_23_col77)), ((op0_limb_17_col71) + (op0_limb_24_col78)), ((op0_limb_18_col72) + (op0_limb_25_col79)), ((op0_limb_19_col73) + (op0_limb_26_col80)), ((op0_limb_20_col74) + (op0_limb_27_col81))];let y_sum_tmp_c8168_66 = [((op1_limb_14_col99) + (op1_limb_21_col106)), ((op1_limb_15_col100) + (op1_limb_22_col107)), ((op1_limb_16_col101) + (op1_limb_23_col108)), ((op1_limb_17_col102) + (op1_limb_24_col109)), ((op1_limb_18_col103) + (op1_limb_25_col110)), ((op1_limb_19_col104) + (op1_limb_26_col111)), ((op1_limb_20_col105) + (op1_limb_27_col112))];let single_karatsuba_n_7_output_tmp_c8168_67 = [z0_tmp_c8168_63[0], z0_tmp_c8168_63[1], z0_tmp_c8168_63[2], z0_tmp_c8168_63[3], z0_tmp_c8168_63[4], z0_tmp_c8168_63[5], z0_tmp_c8168_63[6], ((z0_tmp_c8168_63[7]) + (((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[0]))) - (z0_tmp_c8168_63[0]))) - (z2_tmp_c8168_64[0])))), ((z0_tmp_c8168_63[8]) + (((((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[1]))) + (((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[0]))))) - (z0_tmp_c8168_63[1]))) - (z2_tmp_c8168_64[1])))), ((z0_tmp_c8168_63[9]) + (((((((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[2]))) + (((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[1]))))) + (((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[0]))))) - (z0_tmp_c8168_63[2]))) - (z2_tmp_c8168_64[2])))), ((z0_tmp_c8168_63[10]) + (((((((((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[3]))) + (((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[2]))))) + (((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[1]))))) + (((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[0]))))) - (z0_tmp_c8168_63[3]))) - (z2_tmp_c8168_64[3])))), ((z0_tmp_c8168_63[11]) + (((((((((((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[4]))) + (((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[3]))))) + (((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[2]))))) + (((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[1]))))) + (((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[0]))))) - (z0_tmp_c8168_63[4]))) - (z2_tmp_c8168_64[4])))), ((z0_tmp_c8168_63[12]) + (((((((((((((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[5]))) + (((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[4]))))) + (((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[3]))))) + (((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[2]))))) + (((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[1]))))) + (((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[0]))))) - (z0_tmp_c8168_63[5]))) - (z2_tmp_c8168_64[5])))), ((((((((((((((((((x_sum_tmp_c8168_65[0]) * (y_sum_tmp_c8168_66[6]))) + (((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[5]))))) + (((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[4]))))) + (((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[3]))))) + (((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[2]))))) + (((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[1]))))) + (((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[0]))))) - (z0_tmp_c8168_63[6]))) - (z2_tmp_c8168_64[6])), ((z2_tmp_c8168_64[0]) + (((((((((((((((((x_sum_tmp_c8168_65[1]) * (y_sum_tmp_c8168_66[6]))) + (((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[5]))))) + (((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[4]))))) + (((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[3]))))) + (((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[2]))))) + (((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[1]))))) - (z0_tmp_c8168_63[7]))) - (z2_tmp_c8168_64[7])))), ((z2_tmp_c8168_64[1]) + (((((((((((((((x_sum_tmp_c8168_65[2]) * (y_sum_tmp_c8168_66[6]))) + (((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[5]))))) + (((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[4]))))) + (((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[3]))))) + (((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[2]))))) - (z0_tmp_c8168_63[8]))) - (z2_tmp_c8168_64[8])))), ((z2_tmp_c8168_64[2]) + (((((((((((((x_sum_tmp_c8168_65[3]) * (y_sum_tmp_c8168_66[6]))) + (((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[5]))))) + (((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[4]))))) + (((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[3]))))) - (z0_tmp_c8168_63[9]))) - (z2_tmp_c8168_64[9])))), ((z2_tmp_c8168_64[3]) + (((((((((((x_sum_tmp_c8168_65[4]) * (y_sum_tmp_c8168_66[6]))) + (((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[5]))))) + (((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[4]))))) - (z0_tmp_c8168_63[10]))) - (z2_tmp_c8168_64[10])))), ((z2_tmp_c8168_64[4]) + (((((((((x_sum_tmp_c8168_65[5]) * (y_sum_tmp_c8168_66[6]))) + (((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[5]))))) - (z0_tmp_c8168_63[11]))) - (z2_tmp_c8168_64[11])))), ((z2_tmp_c8168_64[5]) + (((((((x_sum_tmp_c8168_65[6]) * (y_sum_tmp_c8168_66[6]))) - (z0_tmp_c8168_63[12]))) - (z2_tmp_c8168_64[12])))), z2_tmp_c8168_64[6], z2_tmp_c8168_64[7], z2_tmp_c8168_64[8], z2_tmp_c8168_64[9], z2_tmp_c8168_64[10], z2_tmp_c8168_64[11], z2_tmp_c8168_64[12]];

            let x_sum_tmp_c8168_68 = [((op0_limb_0_col54) + (op0_limb_14_col68)), ((op0_limb_1_col55) + (op0_limb_15_col69)), ((op0_limb_2_col56) + (op0_limb_16_col70)), ((op0_limb_3_col57) + (op0_limb_17_col71)), ((op0_limb_4_col58) + (op0_limb_18_col72)), ((op0_limb_5_col59) + (op0_limb_19_col73)), ((op0_limb_6_col60) + (op0_limb_20_col74)), ((op0_limb_7_col61) + (op0_limb_21_col75)), ((op0_limb_8_col62) + (op0_limb_22_col76)), ((op0_limb_9_col63) + (op0_limb_23_col77)), ((op0_limb_10_col64) + (op0_limb_24_col78)), ((op0_limb_11_col65) + (op0_limb_25_col79)), ((op0_limb_12_col66) + (op0_limb_26_col80)), ((op0_limb_13_col67) + (op0_limb_27_col81))];let y_sum_tmp_c8168_69 = [((op1_limb_0_col85) + (op1_limb_14_col99)), ((op1_limb_1_col86) + (op1_limb_15_col100)), ((op1_limb_2_col87) + (op1_limb_16_col101)), ((op1_limb_3_col88) + (op1_limb_17_col102)), ((op1_limb_4_col89) + (op1_limb_18_col103)), ((op1_limb_5_col90) + (op1_limb_19_col104)), ((op1_limb_6_col91) + (op1_limb_20_col105)), ((op1_limb_7_col92) + (op1_limb_21_col106)), ((op1_limb_8_col93) + (op1_limb_22_col107)), ((op1_limb_9_col94) + (op1_limb_23_col108)), ((op1_limb_10_col95) + (op1_limb_24_col109)), ((op1_limb_11_col96) + (op1_limb_25_col110)), ((op1_limb_12_col97) + (op1_limb_26_col111)), ((op1_limb_13_col98) + (op1_limb_27_col112))];

            // Single Karatsuba N 7.

            let z0_tmp_c8168_70 = [((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[0])), ((((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[1]))) + (((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[0])))), ((((((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[2]))) + (((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[1]))))) + (((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[0])))), ((((((((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[3]))) + (((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[2]))))) + (((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[1]))))) + (((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[0])))), ((((((((((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[4]))) + (((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[3]))))) + (((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[2]))))) + (((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[1]))))) + (((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[0])))), ((((((((((((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[5]))) + (((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[4]))))) + (((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[3]))))) + (((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[2]))))) + (((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[1]))))) + (((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[0])))), ((((((((((((((x_sum_tmp_c8168_68[0]) * (y_sum_tmp_c8168_69[6]))) + (((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[5]))))) + (((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[4]))))) + (((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[3]))))) + (((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[2]))))) + (((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[1]))))) + (((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[0])))), ((((((((((((x_sum_tmp_c8168_68[1]) * (y_sum_tmp_c8168_69[6]))) + (((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[5]))))) + (((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[4]))))) + (((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[3]))))) + (((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[2]))))) + (((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[1])))), ((((((((((x_sum_tmp_c8168_68[2]) * (y_sum_tmp_c8168_69[6]))) + (((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[5]))))) + (((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[4]))))) + (((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[3]))))) + (((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[2])))), ((((((((x_sum_tmp_c8168_68[3]) * (y_sum_tmp_c8168_69[6]))) + (((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[5]))))) + (((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[4]))))) + (((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[3])))), ((((((x_sum_tmp_c8168_68[4]) * (y_sum_tmp_c8168_69[6]))) + (((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[5]))))) + (((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[4])))), ((((x_sum_tmp_c8168_68[5]) * (y_sum_tmp_c8168_69[6]))) + (((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[5])))), ((x_sum_tmp_c8168_68[6]) * (y_sum_tmp_c8168_69[6]))];let z2_tmp_c8168_71 = [((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[7])), ((((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[8]))) + (((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[7])))), ((((((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[9]))) + (((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[8]))))) + (((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[7])))), ((((((((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[10]))) + (((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[9]))))) + (((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[8]))))) + (((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[7])))), ((((((((((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[11]))) + (((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[10]))))) + (((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[9]))))) + (((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[8]))))) + (((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[7])))), ((((((((((((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[12]))) + (((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[11]))))) + (((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[10]))))) + (((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[9]))))) + (((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[8]))))) + (((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[7])))), ((((((((((((((x_sum_tmp_c8168_68[7]) * (y_sum_tmp_c8168_69[13]))) + (((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[12]))))) + (((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[11]))))) + (((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[10]))))) + (((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[9]))))) + (((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[8]))))) + (((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[7])))), ((((((((((((x_sum_tmp_c8168_68[8]) * (y_sum_tmp_c8168_69[13]))) + (((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[12]))))) + (((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[11]))))) + (((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[10]))))) + (((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[9]))))) + (((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[8])))), ((((((((((x_sum_tmp_c8168_68[9]) * (y_sum_tmp_c8168_69[13]))) + (((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[12]))))) + (((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[11]))))) + (((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[10]))))) + (((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[9])))), ((((((((x_sum_tmp_c8168_68[10]) * (y_sum_tmp_c8168_69[13]))) + (((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[12]))))) + (((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[11]))))) + (((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[10])))), ((((((x_sum_tmp_c8168_68[11]) * (y_sum_tmp_c8168_69[13]))) + (((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[12]))))) + (((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[11])))), ((((x_sum_tmp_c8168_68[12]) * (y_sum_tmp_c8168_69[13]))) + (((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[12])))), ((x_sum_tmp_c8168_68[13]) * (y_sum_tmp_c8168_69[13]))];let x_sum_tmp_c8168_72 = [((x_sum_tmp_c8168_68[0]) + (x_sum_tmp_c8168_68[7])), ((x_sum_tmp_c8168_68[1]) + (x_sum_tmp_c8168_68[8])), ((x_sum_tmp_c8168_68[2]) + (x_sum_tmp_c8168_68[9])), ((x_sum_tmp_c8168_68[3]) + (x_sum_tmp_c8168_68[10])), ((x_sum_tmp_c8168_68[4]) + (x_sum_tmp_c8168_68[11])), ((x_sum_tmp_c8168_68[5]) + (x_sum_tmp_c8168_68[12])), ((x_sum_tmp_c8168_68[6]) + (x_sum_tmp_c8168_68[13]))];let y_sum_tmp_c8168_73 = [((y_sum_tmp_c8168_69[0]) + (y_sum_tmp_c8168_69[7])), ((y_sum_tmp_c8168_69[1]) + (y_sum_tmp_c8168_69[8])), ((y_sum_tmp_c8168_69[2]) + (y_sum_tmp_c8168_69[9])), ((y_sum_tmp_c8168_69[3]) + (y_sum_tmp_c8168_69[10])), ((y_sum_tmp_c8168_69[4]) + (y_sum_tmp_c8168_69[11])), ((y_sum_tmp_c8168_69[5]) + (y_sum_tmp_c8168_69[12])), ((y_sum_tmp_c8168_69[6]) + (y_sum_tmp_c8168_69[13]))];let single_karatsuba_n_7_output_tmp_c8168_74 = [z0_tmp_c8168_70[0], z0_tmp_c8168_70[1], z0_tmp_c8168_70[2], z0_tmp_c8168_70[3], z0_tmp_c8168_70[4], z0_tmp_c8168_70[5], z0_tmp_c8168_70[6], ((z0_tmp_c8168_70[7]) + (((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[0]))) - (z0_tmp_c8168_70[0]))) - (z2_tmp_c8168_71[0])))), ((z0_tmp_c8168_70[8]) + (((((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[1]))) + (((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[0]))))) - (z0_tmp_c8168_70[1]))) - (z2_tmp_c8168_71[1])))), ((z0_tmp_c8168_70[9]) + (((((((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[2]))) + (((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[1]))))) + (((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[0]))))) - (z0_tmp_c8168_70[2]))) - (z2_tmp_c8168_71[2])))), ((z0_tmp_c8168_70[10]) + (((((((((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[3]))) + (((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[2]))))) + (((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[1]))))) + (((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[0]))))) - (z0_tmp_c8168_70[3]))) - (z2_tmp_c8168_71[3])))), ((z0_tmp_c8168_70[11]) + (((((((((((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[4]))) + (((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[3]))))) + (((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[2]))))) + (((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[1]))))) + (((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[0]))))) - (z0_tmp_c8168_70[4]))) - (z2_tmp_c8168_71[4])))), ((z0_tmp_c8168_70[12]) + (((((((((((((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[5]))) + (((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[4]))))) + (((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[3]))))) + (((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[2]))))) + (((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[1]))))) + (((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[0]))))) - (z0_tmp_c8168_70[5]))) - (z2_tmp_c8168_71[5])))), ((((((((((((((((((x_sum_tmp_c8168_72[0]) * (y_sum_tmp_c8168_73[6]))) + (((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[5]))))) + (((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[4]))))) + (((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[3]))))) + (((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[2]))))) + (((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[1]))))) + (((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[0]))))) - (z0_tmp_c8168_70[6]))) - (z2_tmp_c8168_71[6])), ((z2_tmp_c8168_71[0]) + (((((((((((((((((x_sum_tmp_c8168_72[1]) * (y_sum_tmp_c8168_73[6]))) + (((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[5]))))) + (((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[4]))))) + (((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[3]))))) + (((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[2]))))) + (((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[1]))))) - (z0_tmp_c8168_70[7]))) - (z2_tmp_c8168_71[7])))), ((z2_tmp_c8168_71[1]) + (((((((((((((((x_sum_tmp_c8168_72[2]) * (y_sum_tmp_c8168_73[6]))) + (((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[5]))))) + (((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[4]))))) + (((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[3]))))) + (((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[2]))))) - (z0_tmp_c8168_70[8]))) - (z2_tmp_c8168_71[8])))), ((z2_tmp_c8168_71[2]) + (((((((((((((x_sum_tmp_c8168_72[3]) * (y_sum_tmp_c8168_73[6]))) + (((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[5]))))) + (((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[4]))))) + (((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[3]))))) - (z0_tmp_c8168_70[9]))) - (z2_tmp_c8168_71[9])))), ((z2_tmp_c8168_71[3]) + (((((((((((x_sum_tmp_c8168_72[4]) * (y_sum_tmp_c8168_73[6]))) + (((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[5]))))) + (((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[4]))))) - (z0_tmp_c8168_70[10]))) - (z2_tmp_c8168_71[10])))), ((z2_tmp_c8168_71[4]) + (((((((((x_sum_tmp_c8168_72[5]) * (y_sum_tmp_c8168_73[6]))) + (((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[5]))))) - (z0_tmp_c8168_70[11]))) - (z2_tmp_c8168_71[11])))), ((z2_tmp_c8168_71[5]) + (((((((x_sum_tmp_c8168_72[6]) * (y_sum_tmp_c8168_73[6]))) - (z0_tmp_c8168_70[12]))) - (z2_tmp_c8168_71[12])))), z2_tmp_c8168_71[6], z2_tmp_c8168_71[7], z2_tmp_c8168_71[8], z2_tmp_c8168_71[9], z2_tmp_c8168_71[10], z2_tmp_c8168_71[11], z2_tmp_c8168_71[12]];

            let double_karatsuba_f0fc6_output_tmp_c8168_75 = [single_karatsuba_n_7_output_tmp_c8168_62[0], single_karatsuba_n_7_output_tmp_c8168_62[1], single_karatsuba_n_7_output_tmp_c8168_62[2], single_karatsuba_n_7_output_tmp_c8168_62[3], single_karatsuba_n_7_output_tmp_c8168_62[4], single_karatsuba_n_7_output_tmp_c8168_62[5], single_karatsuba_n_7_output_tmp_c8168_62[6], single_karatsuba_n_7_output_tmp_c8168_62[7], single_karatsuba_n_7_output_tmp_c8168_62[8], single_karatsuba_n_7_output_tmp_c8168_62[9], single_karatsuba_n_7_output_tmp_c8168_62[10], single_karatsuba_n_7_output_tmp_c8168_62[11], single_karatsuba_n_7_output_tmp_c8168_62[12], single_karatsuba_n_7_output_tmp_c8168_62[13], ((single_karatsuba_n_7_output_tmp_c8168_62[14]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[0]) - (single_karatsuba_n_7_output_tmp_c8168_62[0]))) - (single_karatsuba_n_7_output_tmp_c8168_67[0])))), ((single_karatsuba_n_7_output_tmp_c8168_62[15]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[1]) - (single_karatsuba_n_7_output_tmp_c8168_62[1]))) - (single_karatsuba_n_7_output_tmp_c8168_67[1])))), ((single_karatsuba_n_7_output_tmp_c8168_62[16]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[2]) - (single_karatsuba_n_7_output_tmp_c8168_62[2]))) - (single_karatsuba_n_7_output_tmp_c8168_67[2])))), ((single_karatsuba_n_7_output_tmp_c8168_62[17]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[3]) - (single_karatsuba_n_7_output_tmp_c8168_62[3]))) - (single_karatsuba_n_7_output_tmp_c8168_67[3])))), ((single_karatsuba_n_7_output_tmp_c8168_62[18]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[4]) - (single_karatsuba_n_7_output_tmp_c8168_62[4]))) - (single_karatsuba_n_7_output_tmp_c8168_67[4])))), ((single_karatsuba_n_7_output_tmp_c8168_62[19]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[5]) - (single_karatsuba_n_7_output_tmp_c8168_62[5]))) - (single_karatsuba_n_7_output_tmp_c8168_67[5])))), ((single_karatsuba_n_7_output_tmp_c8168_62[20]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[6]) - (single_karatsuba_n_7_output_tmp_c8168_62[6]))) - (single_karatsuba_n_7_output_tmp_c8168_67[6])))), ((single_karatsuba_n_7_output_tmp_c8168_62[21]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[7]) - (single_karatsuba_n_7_output_tmp_c8168_62[7]))) - (single_karatsuba_n_7_output_tmp_c8168_67[7])))), ((single_karatsuba_n_7_output_tmp_c8168_62[22]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[8]) - (single_karatsuba_n_7_output_tmp_c8168_62[8]))) - (single_karatsuba_n_7_output_tmp_c8168_67[8])))), ((single_karatsuba_n_7_output_tmp_c8168_62[23]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[9]) - (single_karatsuba_n_7_output_tmp_c8168_62[9]))) - (single_karatsuba_n_7_output_tmp_c8168_67[9])))), ((single_karatsuba_n_7_output_tmp_c8168_62[24]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[10]) - (single_karatsuba_n_7_output_tmp_c8168_62[10]))) - (single_karatsuba_n_7_output_tmp_c8168_67[10])))), ((single_karatsuba_n_7_output_tmp_c8168_62[25]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[11]) - (single_karatsuba_n_7_output_tmp_c8168_62[11]))) - (single_karatsuba_n_7_output_tmp_c8168_67[11])))), ((single_karatsuba_n_7_output_tmp_c8168_62[26]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[12]) - (single_karatsuba_n_7_output_tmp_c8168_62[12]))) - (single_karatsuba_n_7_output_tmp_c8168_67[12])))), ((((single_karatsuba_n_7_output_tmp_c8168_74[13]) - (single_karatsuba_n_7_output_tmp_c8168_62[13]))) - (single_karatsuba_n_7_output_tmp_c8168_67[13])), ((single_karatsuba_n_7_output_tmp_c8168_67[0]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[14]) - (single_karatsuba_n_7_output_tmp_c8168_62[14]))) - (single_karatsuba_n_7_output_tmp_c8168_67[14])))), ((single_karatsuba_n_7_output_tmp_c8168_67[1]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[15]) - (single_karatsuba_n_7_output_tmp_c8168_62[15]))) - (single_karatsuba_n_7_output_tmp_c8168_67[15])))), ((single_karatsuba_n_7_output_tmp_c8168_67[2]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[16]) - (single_karatsuba_n_7_output_tmp_c8168_62[16]))) - (single_karatsuba_n_7_output_tmp_c8168_67[16])))), ((single_karatsuba_n_7_output_tmp_c8168_67[3]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[17]) - (single_karatsuba_n_7_output_tmp_c8168_62[17]))) - (single_karatsuba_n_7_output_tmp_c8168_67[17])))), ((single_karatsuba_n_7_output_tmp_c8168_67[4]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[18]) - (single_karatsuba_n_7_output_tmp_c8168_62[18]))) - (single_karatsuba_n_7_output_tmp_c8168_67[18])))), ((single_karatsuba_n_7_output_tmp_c8168_67[5]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[19]) - (single_karatsuba_n_7_output_tmp_c8168_62[19]))) - (single_karatsuba_n_7_output_tmp_c8168_67[19])))), ((single_karatsuba_n_7_output_tmp_c8168_67[6]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[20]) - (single_karatsuba_n_7_output_tmp_c8168_62[20]))) - (single_karatsuba_n_7_output_tmp_c8168_67[20])))), ((single_karatsuba_n_7_output_tmp_c8168_67[7]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[21]) - (single_karatsuba_n_7_output_tmp_c8168_62[21]))) - (single_karatsuba_n_7_output_tmp_c8168_67[21])))), ((single_karatsuba_n_7_output_tmp_c8168_67[8]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[22]) - (single_karatsuba_n_7_output_tmp_c8168_62[22]))) - (single_karatsuba_n_7_output_tmp_c8168_67[22])))), ((single_karatsuba_n_7_output_tmp_c8168_67[9]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[23]) - (single_karatsuba_n_7_output_tmp_c8168_62[23]))) - (single_karatsuba_n_7_output_tmp_c8168_67[23])))), ((single_karatsuba_n_7_output_tmp_c8168_67[10]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[24]) - (single_karatsuba_n_7_output_tmp_c8168_62[24]))) - (single_karatsuba_n_7_output_tmp_c8168_67[24])))), ((single_karatsuba_n_7_output_tmp_c8168_67[11]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[25]) - (single_karatsuba_n_7_output_tmp_c8168_62[25]))) - (single_karatsuba_n_7_output_tmp_c8168_67[25])))), ((single_karatsuba_n_7_output_tmp_c8168_67[12]) + (((((single_karatsuba_n_7_output_tmp_c8168_74[26]) - (single_karatsuba_n_7_output_tmp_c8168_62[26]))) - (single_karatsuba_n_7_output_tmp_c8168_67[26])))), single_karatsuba_n_7_output_tmp_c8168_67[13], single_karatsuba_n_7_output_tmp_c8168_67[14], single_karatsuba_n_7_output_tmp_c8168_67[15], single_karatsuba_n_7_output_tmp_c8168_67[16], single_karatsuba_n_7_output_tmp_c8168_67[17], single_karatsuba_n_7_output_tmp_c8168_67[18], single_karatsuba_n_7_output_tmp_c8168_67[19], single_karatsuba_n_7_output_tmp_c8168_67[20], single_karatsuba_n_7_output_tmp_c8168_67[21], single_karatsuba_n_7_output_tmp_c8168_67[22], single_karatsuba_n_7_output_tmp_c8168_67[23], single_karatsuba_n_7_output_tmp_c8168_67[24], single_karatsuba_n_7_output_tmp_c8168_67[25], single_karatsuba_n_7_output_tmp_c8168_67[26]];

            let conv_tmp_c8168_76 = [((double_karatsuba_f0fc6_output_tmp_c8168_75[0]) - (mul_res_limb_0_col142)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[1]) - (mul_res_limb_1_col143)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[2]) - (mul_res_limb_2_col144)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[3]) - (mul_res_limb_3_col145)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[4]) - (mul_res_limb_4_col146)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[5]) - (mul_res_limb_5_col147)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[6]) - (mul_res_limb_6_col148)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[7]) - (mul_res_limb_7_col149)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[8]) - (mul_res_limb_8_col150)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[9]) - (mul_res_limb_9_col151)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[10]) - (mul_res_limb_10_col152)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[11]) - (mul_res_limb_11_col153)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[12]) - (mul_res_limb_12_col154)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[13]) - (mul_res_limb_13_col155)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[14]) - (mul_res_limb_14_col156)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[15]) - (mul_res_limb_15_col157)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[16]) - (mul_res_limb_16_col158)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[17]) - (mul_res_limb_17_col159)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[18]) - (mul_res_limb_18_col160)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[19]) - (mul_res_limb_19_col161)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[20]) - (mul_res_limb_20_col162)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[21]) - (mul_res_limb_21_col163)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[22]) - (mul_res_limb_22_col164)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[23]) - (mul_res_limb_23_col165)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[24]) - (mul_res_limb_24_col166)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[25]) - (mul_res_limb_25_col167)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[26]) - (mul_res_limb_26_col168)), ((double_karatsuba_f0fc6_output_tmp_c8168_75[27]) - (mul_res_limb_27_col169)), double_karatsuba_f0fc6_output_tmp_c8168_75[28], double_karatsuba_f0fc6_output_tmp_c8168_75[29], double_karatsuba_f0fc6_output_tmp_c8168_75[30], double_karatsuba_f0fc6_output_tmp_c8168_75[31], double_karatsuba_f0fc6_output_tmp_c8168_75[32], double_karatsuba_f0fc6_output_tmp_c8168_75[33], double_karatsuba_f0fc6_output_tmp_c8168_75[34], double_karatsuba_f0fc6_output_tmp_c8168_75[35], double_karatsuba_f0fc6_output_tmp_c8168_75[36], double_karatsuba_f0fc6_output_tmp_c8168_75[37], double_karatsuba_f0fc6_output_tmp_c8168_75[38], double_karatsuba_f0fc6_output_tmp_c8168_75[39], double_karatsuba_f0fc6_output_tmp_c8168_75[40], double_karatsuba_f0fc6_output_tmp_c8168_75[41], double_karatsuba_f0fc6_output_tmp_c8168_75[42], double_karatsuba_f0fc6_output_tmp_c8168_75[43], double_karatsuba_f0fc6_output_tmp_c8168_75[44], double_karatsuba_f0fc6_output_tmp_c8168_75[45], double_karatsuba_f0fc6_output_tmp_c8168_75[46], double_karatsuba_f0fc6_output_tmp_c8168_75[47], double_karatsuba_f0fc6_output_tmp_c8168_75[48], double_karatsuba_f0fc6_output_tmp_c8168_75[49], double_karatsuba_f0fc6_output_tmp_c8168_75[50], double_karatsuba_f0fc6_output_tmp_c8168_75[51], double_karatsuba_f0fc6_output_tmp_c8168_75[52], double_karatsuba_f0fc6_output_tmp_c8168_75[53], double_karatsuba_f0fc6_output_tmp_c8168_75[54]];let conv_mod_tmp_c8168_77 = [((((((M31_32) * (conv_tmp_c8168_76[0]))) - (((M31_4) * (conv_tmp_c8168_76[21]))))) + (((M31_8) * (conv_tmp_c8168_76[49])))), ((((((conv_tmp_c8168_76[0]) + (((M31_32) * (conv_tmp_c8168_76[1]))))) - (((M31_4) * (conv_tmp_c8168_76[22]))))) + (((M31_8) * (conv_tmp_c8168_76[50])))), ((((((conv_tmp_c8168_76[1]) + (((M31_32) * (conv_tmp_c8168_76[2]))))) - (((M31_4) * (conv_tmp_c8168_76[23]))))) + (((M31_8) * (conv_tmp_c8168_76[51])))), ((((((conv_tmp_c8168_76[2]) + (((M31_32) * (conv_tmp_c8168_76[3]))))) - (((M31_4) * (conv_tmp_c8168_76[24]))))) + (((M31_8) * (conv_tmp_c8168_76[52])))), ((((((conv_tmp_c8168_76[3]) + (((M31_32) * (conv_tmp_c8168_76[4]))))) - (((M31_4) * (conv_tmp_c8168_76[25]))))) + (((M31_8) * (conv_tmp_c8168_76[53])))), ((((((conv_tmp_c8168_76[4]) + (((M31_32) * (conv_tmp_c8168_76[5]))))) - (((M31_4) * (conv_tmp_c8168_76[26]))))) + (((M31_8) * (conv_tmp_c8168_76[54])))), ((((conv_tmp_c8168_76[5]) + (((M31_32) * (conv_tmp_c8168_76[6]))))) - (((M31_4) * (conv_tmp_c8168_76[27])))), ((((((((M31_2) * (conv_tmp_c8168_76[0]))) + (conv_tmp_c8168_76[6]))) + (((M31_32) * (conv_tmp_c8168_76[7]))))) - (((M31_4) * (conv_tmp_c8168_76[28])))), ((((((((M31_2) * (conv_tmp_c8168_76[1]))) + (conv_tmp_c8168_76[7]))) + (((M31_32) * (conv_tmp_c8168_76[8]))))) - (((M31_4) * (conv_tmp_c8168_76[29])))), ((((((((M31_2) * (conv_tmp_c8168_76[2]))) + (conv_tmp_c8168_76[8]))) + (((M31_32) * (conv_tmp_c8168_76[9]))))) - (((M31_4) * (conv_tmp_c8168_76[30])))), ((((((((M31_2) * (conv_tmp_c8168_76[3]))) + (conv_tmp_c8168_76[9]))) + (((M31_32) * (conv_tmp_c8168_76[10]))))) - (((M31_4) * (conv_tmp_c8168_76[31])))), ((((((((M31_2) * (conv_tmp_c8168_76[4]))) + (conv_tmp_c8168_76[10]))) + (((M31_32) * (conv_tmp_c8168_76[11]))))) - (((M31_4) * (conv_tmp_c8168_76[32])))), ((((((((M31_2) * (conv_tmp_c8168_76[5]))) + (conv_tmp_c8168_76[11]))) + (((M31_32) * (conv_tmp_c8168_76[12]))))) - (((M31_4) * (conv_tmp_c8168_76[33])))), ((((((((M31_2) * (conv_tmp_c8168_76[6]))) + (conv_tmp_c8168_76[12]))) + (((M31_32) * (conv_tmp_c8168_76[13]))))) - (((M31_4) * (conv_tmp_c8168_76[34])))), ((((((((M31_2) * (conv_tmp_c8168_76[7]))) + (conv_tmp_c8168_76[13]))) + (((M31_32) * (conv_tmp_c8168_76[14]))))) - (((M31_4) * (conv_tmp_c8168_76[35])))), ((((((((M31_2) * (conv_tmp_c8168_76[8]))) + (conv_tmp_c8168_76[14]))) + (((M31_32) * (conv_tmp_c8168_76[15]))))) - (((M31_4) * (conv_tmp_c8168_76[36])))), ((((((((M31_2) * (conv_tmp_c8168_76[9]))) + (conv_tmp_c8168_76[15]))) + (((M31_32) * (conv_tmp_c8168_76[16]))))) - (((M31_4) * (conv_tmp_c8168_76[37])))), ((((((((M31_2) * (conv_tmp_c8168_76[10]))) + (conv_tmp_c8168_76[16]))) + (((M31_32) * (conv_tmp_c8168_76[17]))))) - (((M31_4) * (conv_tmp_c8168_76[38])))), ((((((((M31_2) * (conv_tmp_c8168_76[11]))) + (conv_tmp_c8168_76[17]))) + (((M31_32) * (conv_tmp_c8168_76[18]))))) - (((M31_4) * (conv_tmp_c8168_76[39])))), ((((((((M31_2) * (conv_tmp_c8168_76[12]))) + (conv_tmp_c8168_76[18]))) + (((M31_32) * (conv_tmp_c8168_76[19]))))) - (((M31_4) * (conv_tmp_c8168_76[40])))), ((((((((M31_2) * (conv_tmp_c8168_76[13]))) + (conv_tmp_c8168_76[19]))) + (((M31_32) * (conv_tmp_c8168_76[20]))))) - (((M31_4) * (conv_tmp_c8168_76[41])))), ((((((((M31_2) * (conv_tmp_c8168_76[14]))) + (conv_tmp_c8168_76[20]))) - (((M31_4) * (conv_tmp_c8168_76[42]))))) + (((M31_64) * (conv_tmp_c8168_76[49])))), ((((((((M31_2) * (conv_tmp_c8168_76[15]))) - (((M31_4) * (conv_tmp_c8168_76[43]))))) + (((M31_2) * (conv_tmp_c8168_76[49]))))) + (((M31_64) * (conv_tmp_c8168_76[50])))), ((((((((M31_2) * (conv_tmp_c8168_76[16]))) - (((M31_4) * (conv_tmp_c8168_76[44]))))) + (((M31_2) * (conv_tmp_c8168_76[50]))))) + (((M31_64) * (conv_tmp_c8168_76[51])))), ((((((((M31_2) * (conv_tmp_c8168_76[17]))) - (((M31_4) * (conv_tmp_c8168_76[45]))))) + (((M31_2) * (conv_tmp_c8168_76[51]))))) + (((M31_64) * (conv_tmp_c8168_76[52])))), ((((((((M31_2) * (conv_tmp_c8168_76[18]))) - (((M31_4) * (conv_tmp_c8168_76[46]))))) + (((M31_2) * (conv_tmp_c8168_76[52]))))) + (((M31_64) * (conv_tmp_c8168_76[53])))), ((((((((M31_2) * (conv_tmp_c8168_76[19]))) - (((M31_4) * (conv_tmp_c8168_76[47]))))) + (((M31_2) * (conv_tmp_c8168_76[53]))))) + (((M31_64) * (conv_tmp_c8168_76[54])))), ((((((M31_2) * (conv_tmp_c8168_76[20]))) - (((M31_4) * (conv_tmp_c8168_76[48]))))) + (((M31_2) * (conv_tmp_c8168_76[54]))))];let k_mod_2_18_biased_tmp_c8168_78 = ((((((PackedUInt32::from_m31(((conv_mod_tmp_c8168_77[0]) + (M31_134217728)))) + (((((PackedUInt32::from_m31(((conv_mod_tmp_c8168_77[1]) + (M31_134217728)))) & (UInt32_511))) << (UInt32_9))))) + (UInt32_131072))) & (UInt32_262143));let k_col170 = ((k_mod_2_18_biased_tmp_c8168_78.low().as_m31()) + (((((k_mod_2_18_biased_tmp_c8168_78.high().as_m31()) - (M31_2))) * (M31_65536))));
            *row[170] = k_col170;*sub_component_inputs.range_check_20[0] =
                [((k_col170) + (M31_524288))];
            *lookup_data.range_check_20_35 = [M31_1410849886, ((k_col170) + (M31_524288))];let carry_0_col171 = ((((conv_mod_tmp_c8168_77[0]) - (k_col170))) * (M31_4194304));
            *row[171] = carry_0_col171;*sub_component_inputs.range_check_20_b[0] =
                [((carry_0_col171) + (M31_524288))];
            *lookup_data.range_check_20_b_36 = [M31_514232941, ((carry_0_col171) + (M31_524288))];let carry_1_col172 = ((((conv_mod_tmp_c8168_77[1]) + (carry_0_col171))) * (M31_4194304));
            *row[172] = carry_1_col172;*sub_component_inputs.range_check_20_c[0] =
                [((carry_1_col172) + (M31_524288))];
            *lookup_data.range_check_20_c_37 = [M31_531010560, ((carry_1_col172) + (M31_524288))];let carry_2_col173 = ((((conv_mod_tmp_c8168_77[2]) + (carry_1_col172))) * (M31_4194304));
            *row[173] = carry_2_col173;*sub_component_inputs.range_check_20_d[0] =
                [((carry_2_col173) + (M31_524288))];
            *lookup_data.range_check_20_d_38 = [M31_480677703, ((carry_2_col173) + (M31_524288))];let carry_3_col174 = ((((conv_mod_tmp_c8168_77[3]) + (carry_2_col173))) * (M31_4194304));
            *row[174] = carry_3_col174;*sub_component_inputs.range_check_20_e[0] =
                [((carry_3_col174) + (M31_524288))];
            *lookup_data.range_check_20_e_39 = [M31_497455322, ((carry_3_col174) + (M31_524288))];let carry_4_col175 = ((((conv_mod_tmp_c8168_77[4]) + (carry_3_col174))) * (M31_4194304));
            *row[175] = carry_4_col175;*sub_component_inputs.range_check_20_f[0] =
                [((carry_4_col175) + (M31_524288))];
            *lookup_data.range_check_20_f_40 = [M31_447122465, ((carry_4_col175) + (M31_524288))];let carry_5_col176 = ((((conv_mod_tmp_c8168_77[5]) + (carry_4_col175))) * (M31_4194304));
            *row[176] = carry_5_col176;*sub_component_inputs.range_check_20_g[0] =
                [((carry_5_col176) + (M31_524288))];
            *lookup_data.range_check_20_g_41 = [M31_463900084, ((carry_5_col176) + (M31_524288))];let carry_6_col177 = ((((conv_mod_tmp_c8168_77[6]) + (carry_5_col176))) * (M31_4194304));
            *row[177] = carry_6_col177;*sub_component_inputs.range_check_20_h[0] =
                [((carry_6_col177) + (M31_524288))];
            *lookup_data.range_check_20_h_42 = [M31_682009131, ((carry_6_col177) + (M31_524288))];let carry_7_col178 = ((((conv_mod_tmp_c8168_77[7]) + (carry_6_col177))) * (M31_4194304));
            *row[178] = carry_7_col178;*sub_component_inputs.range_check_20[1] =
                [((carry_7_col178) + (M31_524288))];
            *lookup_data.range_check_20_43 = [M31_1410849886, ((carry_7_col178) + (M31_524288))];let carry_8_col179 = ((((conv_mod_tmp_c8168_77[8]) + (carry_7_col178))) * (M31_4194304));
            *row[179] = carry_8_col179;*sub_component_inputs.range_check_20_b[1] =
                [((carry_8_col179) + (M31_524288))];
            *lookup_data.range_check_20_b_44 = [M31_514232941, ((carry_8_col179) + (M31_524288))];let carry_9_col180 = ((((conv_mod_tmp_c8168_77[9]) + (carry_8_col179))) * (M31_4194304));
            *row[180] = carry_9_col180;*sub_component_inputs.range_check_20_c[1] =
                [((carry_9_col180) + (M31_524288))];
            *lookup_data.range_check_20_c_45 = [M31_531010560, ((carry_9_col180) + (M31_524288))];let carry_10_col181 = ((((conv_mod_tmp_c8168_77[10]) + (carry_9_col180))) * (M31_4194304));
            *row[181] = carry_10_col181;*sub_component_inputs.range_check_20_d[1] =
                [((carry_10_col181) + (M31_524288))];
            *lookup_data.range_check_20_d_46 = [M31_480677703, ((carry_10_col181) + (M31_524288))];let carry_11_col182 = ((((conv_mod_tmp_c8168_77[11]) + (carry_10_col181))) * (M31_4194304));
            *row[182] = carry_11_col182;*sub_component_inputs.range_check_20_e[1] =
                [((carry_11_col182) + (M31_524288))];
            *lookup_data.range_check_20_e_47 = [M31_497455322, ((carry_11_col182) + (M31_524288))];let carry_12_col183 = ((((conv_mod_tmp_c8168_77[12]) + (carry_11_col182))) * (M31_4194304));
            *row[183] = carry_12_col183;*sub_component_inputs.range_check_20_f[1] =
                [((carry_12_col183) + (M31_524288))];
            *lookup_data.range_check_20_f_48 = [M31_447122465, ((carry_12_col183) + (M31_524288))];let carry_13_col184 = ((((conv_mod_tmp_c8168_77[13]) + (carry_12_col183))) * (M31_4194304));
            *row[184] = carry_13_col184;*sub_component_inputs.range_check_20_g[1] =
                [((carry_13_col184) + (M31_524288))];
            *lookup_data.range_check_20_g_49 = [M31_463900084, ((carry_13_col184) + (M31_524288))];let carry_14_col185 = ((((conv_mod_tmp_c8168_77[14]) + (carry_13_col184))) * (M31_4194304));
            *row[185] = carry_14_col185;*sub_component_inputs.range_check_20_h[1] =
                [((carry_14_col185) + (M31_524288))];
            *lookup_data.range_check_20_h_50 = [M31_682009131, ((carry_14_col185) + (M31_524288))];let carry_15_col186 = ((((conv_mod_tmp_c8168_77[15]) + (carry_14_col185))) * (M31_4194304));
            *row[186] = carry_15_col186;*sub_component_inputs.range_check_20[2] =
                [((carry_15_col186) + (M31_524288))];
            *lookup_data.range_check_20_51 = [M31_1410849886, ((carry_15_col186) + (M31_524288))];let carry_16_col187 = ((((conv_mod_tmp_c8168_77[16]) + (carry_15_col186))) * (M31_4194304));
            *row[187] = carry_16_col187;*sub_component_inputs.range_check_20_b[2] =
                [((carry_16_col187) + (M31_524288))];
            *lookup_data.range_check_20_b_52 = [M31_514232941, ((carry_16_col187) + (M31_524288))];let carry_17_col188 = ((((conv_mod_tmp_c8168_77[17]) + (carry_16_col187))) * (M31_4194304));
            *row[188] = carry_17_col188;*sub_component_inputs.range_check_20_c[2] =
                [((carry_17_col188) + (M31_524288))];
            *lookup_data.range_check_20_c_53 = [M31_531010560, ((carry_17_col188) + (M31_524288))];let carry_18_col189 = ((((conv_mod_tmp_c8168_77[18]) + (carry_17_col188))) * (M31_4194304));
            *row[189] = carry_18_col189;*sub_component_inputs.range_check_20_d[2] =
                [((carry_18_col189) + (M31_524288))];
            *lookup_data.range_check_20_d_54 = [M31_480677703, ((carry_18_col189) + (M31_524288))];let carry_19_col190 = ((((conv_mod_tmp_c8168_77[19]) + (carry_18_col189))) * (M31_4194304));
            *row[190] = carry_19_col190;*sub_component_inputs.range_check_20_e[2] =
                [((carry_19_col190) + (M31_524288))];
            *lookup_data.range_check_20_e_55 = [M31_497455322, ((carry_19_col190) + (M31_524288))];let carry_20_col191 = ((((conv_mod_tmp_c8168_77[20]) + (carry_19_col190))) * (M31_4194304));
            *row[191] = carry_20_col191;*sub_component_inputs.range_check_20_f[2] =
                [((carry_20_col191) + (M31_524288))];
            *lookup_data.range_check_20_f_56 = [M31_447122465, ((carry_20_col191) + (M31_524288))];let carry_21_col192 = ((((((conv_mod_tmp_c8168_77[21]) - (((M31_136) * (k_col170))))) + (carry_20_col191))) * (M31_4194304));
            *row[192] = carry_21_col192;*sub_component_inputs.range_check_20_g[2] =
                [((carry_21_col192) + (M31_524288))];
            *lookup_data.range_check_20_g_57 = [M31_463900084, ((carry_21_col192) + (M31_524288))];let carry_22_col193 = ((((conv_mod_tmp_c8168_77[22]) + (carry_21_col192))) * (M31_4194304));
            *row[193] = carry_22_col193;*sub_component_inputs.range_check_20_h[2] =
                [((carry_22_col193) + (M31_524288))];
            *lookup_data.range_check_20_h_58 = [M31_682009131, ((carry_22_col193) + (M31_524288))];let carry_23_col194 = ((((conv_mod_tmp_c8168_77[23]) + (carry_22_col193))) * (M31_4194304));
            *row[194] = carry_23_col194;*sub_component_inputs.range_check_20[3] =
                [((carry_23_col194) + (M31_524288))];
            *lookup_data.range_check_20_59 = [M31_1410849886, ((carry_23_col194) + (M31_524288))];let carry_24_col195 = ((((conv_mod_tmp_c8168_77[24]) + (carry_23_col194))) * (M31_4194304));
            *row[195] = carry_24_col195;*sub_component_inputs.range_check_20_b[3] =
                [((carry_24_col195) + (M31_524288))];
            *lookup_data.range_check_20_b_60 = [M31_514232941, ((carry_24_col195) + (M31_524288))];let carry_25_col196 = ((((conv_mod_tmp_c8168_77[25]) + (carry_24_col195))) * (M31_4194304));
            *row[196] = carry_25_col196;*sub_component_inputs.range_check_20_c[3] =
                [((carry_25_col196) + (M31_524288))];
            *lookup_data.range_check_20_c_61 = [M31_531010560, ((carry_25_col196) + (M31_524288))];let carry_26_col197 = ((((conv_mod_tmp_c8168_77[26]) + (carry_25_col196))) * (M31_4194304));
            *row[197] = carry_26_col197;*sub_component_inputs.range_check_20_d[3] =
                [((carry_26_col197) + (M31_524288))];
            *lookup_data.range_check_20_d_62 = [M31_480677703, ((carry_26_col197) + (M31_524288))];

            let mul_252_output_tmp_c8168_79 = mul_res_tmp_c8168_57;

            let res_tmp_c8168_80 = ((((((PackedFelt252::from_m31(decode_generic_instruction_output_tmp_c8168_26.0[16])) * (read_positive_num_bits_252_output_tmp_c8168_44.0))) + (((PackedFelt252::from_m31(res_mul_col13)) * (mul_252_output_tmp_c8168_79))))) + (((PackedFelt252::from_m31(res_add_col12)) * (add_252_output_tmp_c8168_56))));let res_limb_0_col198 = res_tmp_c8168_80.get_m31(0);
            *row[198] = res_limb_0_col198;let res_limb_1_col199 = res_tmp_c8168_80.get_m31(1);
            *row[199] = res_limb_1_col199;let res_limb_2_col200 = res_tmp_c8168_80.get_m31(2);
            *row[200] = res_limb_2_col200;let res_limb_3_col201 = res_tmp_c8168_80.get_m31(3);
            *row[201] = res_limb_3_col201;let res_limb_4_col202 = res_tmp_c8168_80.get_m31(4);
            *row[202] = res_limb_4_col202;let res_limb_5_col203 = res_tmp_c8168_80.get_m31(5);
            *row[203] = res_limb_5_col203;let res_limb_6_col204 = res_tmp_c8168_80.get_m31(6);
            *row[204] = res_limb_6_col204;let res_limb_7_col205 = res_tmp_c8168_80.get_m31(7);
            *row[205] = res_limb_7_col205;let res_limb_8_col206 = res_tmp_c8168_80.get_m31(8);
            *row[206] = res_limb_8_col206;let res_limb_9_col207 = res_tmp_c8168_80.get_m31(9);
            *row[207] = res_limb_9_col207;let res_limb_10_col208 = res_tmp_c8168_80.get_m31(10);
            *row[208] = res_limb_10_col208;let res_limb_11_col209 = res_tmp_c8168_80.get_m31(11);
            *row[209] = res_limb_11_col209;let res_limb_12_col210 = res_tmp_c8168_80.get_m31(12);
            *row[210] = res_limb_12_col210;let res_limb_13_col211 = res_tmp_c8168_80.get_m31(13);
            *row[211] = res_limb_13_col211;let res_limb_14_col212 = res_tmp_c8168_80.get_m31(14);
            *row[212] = res_limb_14_col212;let res_limb_15_col213 = res_tmp_c8168_80.get_m31(15);
            *row[213] = res_limb_15_col213;let res_limb_16_col214 = res_tmp_c8168_80.get_m31(16);
            *row[214] = res_limb_16_col214;let res_limb_17_col215 = res_tmp_c8168_80.get_m31(17);
            *row[215] = res_limb_17_col215;let res_limb_18_col216 = res_tmp_c8168_80.get_m31(18);
            *row[216] = res_limb_18_col216;let res_limb_19_col217 = res_tmp_c8168_80.get_m31(19);
            *row[217] = res_limb_19_col217;let res_limb_20_col218 = res_tmp_c8168_80.get_m31(20);
            *row[218] = res_limb_20_col218;let res_limb_21_col219 = res_tmp_c8168_80.get_m31(21);
            *row[219] = res_limb_21_col219;let res_limb_22_col220 = res_tmp_c8168_80.get_m31(22);
            *row[220] = res_limb_22_col220;let res_limb_23_col221 = res_tmp_c8168_80.get_m31(23);
            *row[221] = res_limb_23_col221;let res_limb_24_col222 = res_tmp_c8168_80.get_m31(24);
            *row[222] = res_limb_24_col222;let res_limb_25_col223 = res_tmp_c8168_80.get_m31(25);
            *row[223] = res_limb_25_col223;let res_limb_26_col224 = res_tmp_c8168_80.get_m31(26);
            *row[224] = res_limb_26_col224;let res_limb_27_col225 = res_tmp_c8168_80.get_m31(27);
            *row[225] = res_limb_27_col225;let eval_operands_output_tmp_c8168_82 = [read_positive_num_bits_252_output_tmp_c8168_31.0, read_positive_num_bits_252_output_tmp_c8168_36.0, read_positive_num_bits_252_output_tmp_c8168_44.0, res_tmp_c8168_80];

            // Handle Opcodes.

            // Cond Felt 252 As Addr.

            // Cond Range Check 2.

            let partial_limb_msb_tmp_c8168_83 = ((((PackedUInt16::from_m31(dst_limb_3_col27)) & (UInt16_2))) >> (UInt16_1));let partial_limb_msb_col226 = partial_limb_msb_tmp_c8168_83.as_m31();
            *row[226] = partial_limb_msb_col226;

            let cond_felt_252_as_addr_output_tmp_c8168_85 = ((((((dst_limb_0_col24) + (((dst_limb_1_col25) * (M31_512))))) + (((dst_limb_2_col26) * (M31_262144))))) + (((dst_limb_3_col27) * (M31_134217728))));

            // Cond Felt 252 As Addr.

            // Cond Range Check 2.

            let partial_limb_msb_tmp_c8168_86 = ((((PackedUInt16::from_m31(op0_limb_3_col57)) & (UInt16_2))) >> (UInt16_1));let partial_limb_msb_col227 = partial_limb_msb_tmp_c8168_86.as_m31();
            *row[227] = partial_limb_msb_col227;

            let cond_felt_252_as_addr_output_tmp_c8168_88 = ((((((op0_limb_0_col54) + (((op0_limb_1_col55) * (M31_512))))) + (((op0_limb_2_col56) * (M31_262144))))) + (((op0_limb_3_col57) * (M31_134217728))));

            // Update Registers.

            // Cond Felt 252 As Addr.

            // Cond Range Check 2.

            let partial_limb_msb_tmp_c8168_89 = ((((PackedUInt16::from_m31(dst_limb_3_col27)) & (UInt16_2))) >> (UInt16_1));let partial_limb_msb_col228 = partial_limb_msb_tmp_c8168_89.as_m31();
            *row[228] = partial_limb_msb_col228;

            let cond_felt_252_as_addr_output_tmp_c8168_91 = ((((((dst_limb_0_col24) + (((dst_limb_1_col25) * (M31_512))))) + (((dst_limb_2_col26) * (M31_262144))))) + (((dst_limb_3_col27) * (M31_134217728))));

            // Cond Felt 252 As Rel Imm.

            // Decode Small Sign.

            let msb_tmp_c8168_92 = res_limb_27_col225.eq(M31_256);let msb_col229 = msb_tmp_c8168_92.as_m31();
            *row[229] = msb_col229;let mid_limbs_set_tmp_c8168_93 = ((res_limb_20_col218.eq(M31_511)) & (msb_tmp_c8168_92));let mid_limbs_set_col230 = mid_limbs_set_tmp_c8168_93.as_m31();
            *row[230] = mid_limbs_set_col230;let decode_small_sign_output_tmp_c8168_94 = [msb_col229, mid_limbs_set_col230, ((mid_limbs_set_col230) * (M31_508)), ((mid_limbs_set_col230) * (M31_511)), ((((msb_col229) * (M31_136))) - (mid_limbs_set_col230)), ((msb_col229) * (M31_256))];

            let remainder_bits_tmp_c8168_95 = ((res_limb_3_col201) - (decode_small_sign_output_tmp_c8168_94[2]));

            // Cond Range Check 2.

            let partial_limb_msb_tmp_c8168_96 = ((((PackedUInt16::from_m31(remainder_bits_tmp_c8168_95)) & (UInt16_2))) >> (UInt16_1));let partial_limb_msb_col231 = partial_limb_msb_tmp_c8168_96.as_m31();
            *row[231] = partial_limb_msb_col231;

            let cond_felt_252_as_rel_imm_output_tmp_c8168_98 = ((((((((((res_limb_0_col198) + (((res_limb_1_col199) * (M31_512))))) + (((res_limb_2_col200) * (M31_262144))))) + (((remainder_bits_tmp_c8168_95) * (M31_134217728))))) - (msb_col229))) - (((M31_536870912) * (mid_limbs_set_col230))));

            let diff_from_p_tmp_c8168_99 = ((dst_limb_0_col24) - (M31_1));let diff_from_p_tmp_c8168_100 = ((dst_limb_21_col45) - (M31_136));let diff_from_p_tmp_c8168_101 = ((dst_limb_27_col51) - (M31_256));let dst_sum_squares_inv_col232 = ((((((((((((((((((((((((((((((((((((((((((((((((((((((((diff_from_p_tmp_c8168_99) * (diff_from_p_tmp_c8168_99))) + (dst_limb_1_col25))) + (dst_limb_2_col26))) + (dst_limb_3_col27))) + (dst_limb_4_col28))) + (dst_limb_5_col29))) + (dst_limb_6_col30))) + (dst_limb_7_col31))) + (dst_limb_8_col32))) + (dst_limb_9_col33))) + (dst_limb_10_col34))) + (dst_limb_11_col35))) + (dst_limb_12_col36))) + (dst_limb_13_col37))) + (dst_limb_14_col38))) + (dst_limb_15_col39))) + (dst_limb_16_col40))) + (dst_limb_17_col41))) + (dst_limb_18_col42))) + (dst_limb_19_col43))) + (dst_limb_20_col44))) + (((diff_from_p_tmp_c8168_100) * (diff_from_p_tmp_c8168_100))))) + (dst_limb_22_col46))) + (dst_limb_23_col47))) + (dst_limb_24_col48))) + (dst_limb_25_col49))) + (dst_limb_26_col50))) + (((diff_from_p_tmp_c8168_101) * (diff_from_p_tmp_c8168_101)))).inverse();
            *row[232] = dst_sum_squares_inv_col232;let dst_sum_tmp_c8168_102 = ((((((((((((((((((((((((((((((((((((((((((((((((((((((dst_limb_0_col24) + (dst_limb_1_col25))) + (dst_limb_2_col26))) + (dst_limb_3_col27))) + (dst_limb_4_col28))) + (dst_limb_5_col29))) + (dst_limb_6_col30))) + (dst_limb_7_col31))) + (dst_limb_8_col32))) + (dst_limb_9_col33))) + (dst_limb_10_col34))) + (dst_limb_11_col35))) + (dst_limb_12_col36))) + (dst_limb_13_col37))) + (dst_limb_14_col38))) + (dst_limb_15_col39))) + (dst_limb_16_col40))) + (dst_limb_17_col41))) + (dst_limb_18_col42))) + (dst_limb_19_col43))) + (dst_limb_20_col44))) + (dst_limb_21_col45))) + (dst_limb_22_col46))) + (dst_limb_23_col47))) + (dst_limb_24_col48))) + (dst_limb_25_col49))) + (dst_limb_26_col50))) + (dst_limb_27_col51));let dst_is_zero_tmp_c8168_103 = dst_sum_tmp_c8168_102.eq(M31_0);let dst_sum_inv_col233 = ((dst_sum_tmp_c8168_102) + (dst_is_zero_tmp_c8168_103.as_m31())).inverse();
            *row[233] = dst_sum_inv_col233;let op1_as_rel_imm_cond_col234 = ((pc_update_jnz_col16) * (dst_sum_tmp_c8168_102));
            *row[234] = op1_as_rel_imm_cond_col234;

            // Cond Felt 252 As Rel Imm.

            // Decode Small Sign.

            let msb_tmp_c8168_104 = op1_limb_27_col112.eq(M31_256);let msb_col235 = msb_tmp_c8168_104.as_m31();
            *row[235] = msb_col235;let mid_limbs_set_tmp_c8168_105 = ((op1_limb_20_col105.eq(M31_511)) & (msb_tmp_c8168_104));let mid_limbs_set_col236 = mid_limbs_set_tmp_c8168_105.as_m31();
            *row[236] = mid_limbs_set_col236;let decode_small_sign_output_tmp_c8168_106 = [msb_col235, mid_limbs_set_col236, ((mid_limbs_set_col236) * (M31_508)), ((mid_limbs_set_col236) * (M31_511)), ((((msb_col235) * (M31_136))) - (mid_limbs_set_col236)), ((msb_col235) * (M31_256))];

            let remainder_bits_tmp_c8168_107 = ((op1_limb_3_col88) - (decode_small_sign_output_tmp_c8168_106[2]));

            // Cond Range Check 2.

            let partial_limb_msb_tmp_c8168_108 = ((((PackedUInt16::from_m31(remainder_bits_tmp_c8168_107)) & (UInt16_2))) >> (UInt16_1));let partial_limb_msb_col237 = partial_limb_msb_tmp_c8168_108.as_m31();
            *row[237] = partial_limb_msb_col237;

            let cond_felt_252_as_rel_imm_output_tmp_c8168_110 = ((((((((((op1_limb_0_col85) + (((op1_limb_1_col86) * (M31_512))))) + (((op1_limb_2_col87) * (M31_262144))))) + (((remainder_bits_tmp_c8168_107) * (M31_134217728))))) - (msb_col235))) - (((M31_536870912) * (mid_limbs_set_col236))));

            let next_pc_jnz_col238 = ((((dst_is_zero_tmp_c8168_103.as_m31()) * (((input_pc_col1) + (decode_generic_instruction_output_tmp_c8168_26.0[19]))))) + (((((M31_1) - (dst_is_zero_tmp_c8168_103.as_m31()))) * (((input_pc_col1) + (cond_felt_252_as_rel_imm_output_tmp_c8168_110))))));
            *row[238] = next_pc_jnz_col238;let next_pc_col239 = ((((((((decode_generic_instruction_output_tmp_c8168_26.0[17]) * (((input_pc_col1) + (decode_generic_instruction_output_tmp_c8168_26.0[19]))))) + (((pc_update_jump_col14) * (cond_felt_252_as_rel_imm_output_tmp_c8168_98))))) + (((pc_update_jump_rel_col15) * (((input_pc_col1) + (cond_felt_252_as_rel_imm_output_tmp_c8168_98))))))) + (((pc_update_jnz_col16) * (next_pc_jnz_col238))));
            *row[239] = next_pc_col239;let next_ap_col240 = ((((((input_ap_col2) + (((ap_update_add_col17) * (cond_felt_252_as_rel_imm_output_tmp_c8168_98))))) + (ap_update_add_1_col18))) + (((opcode_call_col19) * (M31_2))));
            *row[240] = next_ap_col240;

            // Range Check 29.

            let range_check_29_bot11bits_u32_tmp_c8168_111 = ((PackedUInt32::from_m31(next_ap_col240)) & (UInt32_2047));let range_check_29_bot11bits_col241 = range_check_29_bot11bits_u32_tmp_c8168_111.low().as_m31();
            *row[241] = range_check_29_bot11bits_col241;*sub_component_inputs.range_check_18[0] =
                [((((next_ap_col240) - (range_check_29_bot11bits_col241))) * (M31_1048576))];
            *lookup_data.range_check_18_63 = [M31_1109051422, ((((next_ap_col240) - (range_check_29_bot11bits_col241))) * (M31_1048576))];*sub_component_inputs.range_check_11[0] =
                [range_check_29_bot11bits_col241];
            *lookup_data.range_check_11_64 = [M31_991608089, range_check_29_bot11bits_col241];

            let next_fp_col242 = ((((((decode_generic_instruction_output_tmp_c8168_26.0[18]) * (input_fp_col3))) + (((opcode_ret_col20) * (cond_felt_252_as_addr_output_tmp_c8168_91))))) + (((opcode_call_col19) * (((input_ap_col2) + (M31_2))))));
            *row[242] = next_fp_col242;let update_registers_output_tmp_c8168_112 = PackedCasmState {
    pc: next_pc_col239, ap: next_ap_col240, fp: next_fp_col242,
};

            *lookup_data.opcodes_65 = [M31_428564188, input_pc_col1, input_ap_col2, input_fp_col3];*lookup_data.opcodes_66 = [M31_428564188, next_pc_col239, next_ap_col240, next_fp_col242];*lookup_data.mults_0 = enabler_col0;
        });

    (trace, lookup_data,sub_component_inputs,)
}

#[derive(Uninitialized,IterMut, ParIterMut)]
struct LookupData
{verify_instruction_0: Vec<[PackedM31; 8]>,memory_address_to_id_1: Vec<[PackedM31; 3]>,memory_id_to_big_2: Vec<[PackedM31; 30]>,memory_address_to_id_3: Vec<[PackedM31; 3]>,memory_id_to_big_4: Vec<[PackedM31; 30]>,memory_address_to_id_5: Vec<[PackedM31; 3]>,memory_id_to_big_6: Vec<[PackedM31; 30]>,range_check_9_9_7: Vec<[PackedM31; 3]>,range_check_9_9_b_8: Vec<[PackedM31; 3]>,range_check_9_9_c_9: Vec<[PackedM31; 3]>,range_check_9_9_d_10: Vec<[PackedM31; 3]>,range_check_9_9_e_11: Vec<[PackedM31; 3]>,range_check_9_9_f_12: Vec<[PackedM31; 3]>,range_check_9_9_g_13: Vec<[PackedM31; 3]>,range_check_9_9_h_14: Vec<[PackedM31; 3]>,range_check_9_9_15: Vec<[PackedM31; 3]>,range_check_9_9_b_16: Vec<[PackedM31; 3]>,range_check_9_9_c_17: Vec<[PackedM31; 3]>,range_check_9_9_d_18: Vec<[PackedM31; 3]>,range_check_9_9_e_19: Vec<[PackedM31; 3]>,range_check_9_9_f_20: Vec<[PackedM31; 3]>,range_check_9_9_21: Vec<[PackedM31; 3]>,range_check_9_9_b_22: Vec<[PackedM31; 3]>,range_check_9_9_c_23: Vec<[PackedM31; 3]>,range_check_9_9_d_24: Vec<[PackedM31; 3]>,range_check_9_9_e_25: Vec<[PackedM31; 3]>,range_check_9_9_f_26: Vec<[PackedM31; 3]>,range_check_9_9_g_27: Vec<[PackedM31; 3]>,range_check_9_9_h_28: Vec<[PackedM31; 3]>,range_check_9_9_29: Vec<[PackedM31; 3]>,range_check_9_9_b_30: Vec<[PackedM31; 3]>,range_check_9_9_c_31: Vec<[PackedM31; 3]>,range_check_9_9_d_32: Vec<[PackedM31; 3]>,range_check_9_9_e_33: Vec<[PackedM31; 3]>,range_check_9_9_f_34: Vec<[PackedM31; 3]>,range_check_20_35: Vec<[PackedM31; 2]>,range_check_20_b_36: Vec<[PackedM31; 2]>,range_check_20_c_37: Vec<[PackedM31; 2]>,range_check_20_d_38: Vec<[PackedM31; 2]>,range_check_20_e_39: Vec<[PackedM31; 2]>,range_check_20_f_40: Vec<[PackedM31; 2]>,range_check_20_g_41: Vec<[PackedM31; 2]>,range_check_20_h_42: Vec<[PackedM31; 2]>,range_check_20_43: Vec<[PackedM31; 2]>,range_check_20_b_44: Vec<[PackedM31; 2]>,range_check_20_c_45: Vec<[PackedM31; 2]>,range_check_20_d_46: Vec<[PackedM31; 2]>,range_check_20_e_47: Vec<[PackedM31; 2]>,range_check_20_f_48: Vec<[PackedM31; 2]>,range_check_20_g_49: Vec<[PackedM31; 2]>,range_check_20_h_50: Vec<[PackedM31; 2]>,range_check_20_51: Vec<[PackedM31; 2]>,range_check_20_b_52: Vec<[PackedM31; 2]>,range_check_20_c_53: Vec<[PackedM31; 2]>,range_check_20_d_54: Vec<[PackedM31; 2]>,range_check_20_e_55: Vec<[PackedM31; 2]>,range_check_20_f_56: Vec<[PackedM31; 2]>,range_check_20_g_57: Vec<[PackedM31; 2]>,range_check_20_h_58: Vec<[PackedM31; 2]>,range_check_20_59: Vec<[PackedM31; 2]>,range_check_20_b_60: Vec<[PackedM31; 2]>,range_check_20_c_61: Vec<[PackedM31; 2]>,range_check_20_d_62: Vec<[PackedM31; 2]>,range_check_18_63: Vec<[PackedM31; 2]>,range_check_11_64: Vec<[PackedM31; 2]>,opcodes_65: Vec<[PackedM31; 4]>,opcodes_66: Vec<[PackedM31; 4]>,mults_0: Vec<PackedM31>,}

pub struct InteractionClaimGenerator {
    log_size: u32,
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {

    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim)
    {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(self.log_size) };

        //Sum logup terms in pairs.
let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.verify_instruction_0,
        &self.lookup_data.memory_address_to_id_1
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.memory_id_to_big_2,
        &self.lookup_data.memory_address_to_id_3
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.memory_id_to_big_4,
        &self.lookup_data.memory_address_to_id_5
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.memory_id_to_big_6,
        &self.lookup_data.range_check_9_9_7
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_b_8,
        &self.lookup_data.range_check_9_9_c_9
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_d_10,
        &self.lookup_data.range_check_9_9_e_11
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_f_12,
        &self.lookup_data.range_check_9_9_g_13
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_h_14,
        &self.lookup_data.range_check_9_9_15
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_b_16,
        &self.lookup_data.range_check_9_9_c_17
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_d_18,
        &self.lookup_data.range_check_9_9_e_19
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_f_20,
        &self.lookup_data.range_check_9_9_21
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_b_22,
        &self.lookup_data.range_check_9_9_c_23
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_d_24,
        &self.lookup_data.range_check_9_9_e_25
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_f_26,
        &self.lookup_data.range_check_9_9_g_27
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_h_28,
        &self.lookup_data.range_check_9_9_29
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_b_30,
        &self.lookup_data.range_check_9_9_c_31
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_d_32,
        &self.lookup_data.range_check_9_9_e_33
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_9_9_f_34,
        &self.lookup_data.range_check_20_35
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_b_36,
        &self.lookup_data.range_check_20_c_37
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_d_38,
        &self.lookup_data.range_check_20_e_39
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_f_40,
        &self.lookup_data.range_check_20_g_41
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_h_42,
        &self.lookup_data.range_check_20_43
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_b_44,
        &self.lookup_data.range_check_20_c_45
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_d_46,
        &self.lookup_data.range_check_20_e_47
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_f_48,
        &self.lookup_data.range_check_20_g_49
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_h_50,
        &self.lookup_data.range_check_20_51
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_b_52,
        &self.lookup_data.range_check_20_c_53
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_d_54,
        &self.lookup_data.range_check_20_e_55
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_f_56,
        &self.lookup_data.range_check_20_g_57
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_h_58,
        &self.lookup_data.range_check_20_59
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_b_60,
        &self.lookup_data.range_check_20_c_61
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_20_d_62,
        &self.lookup_data.range_check_18_63
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(),
        &self.lookup_data.range_check_11_64,
        &self.lookup_data.opcodes_65
        , &self.lookup_data.mults_0,
        &self.lookup_data.mults_0)
            .into_par_iter().for_each(|(writer,
            values0,
            values1,
            mult0,
            mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        //Sum last logup term.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.opcodes_66
            , self.lookup_data.mults_0
        )
            .into_par_iter().for_each(|(writer, values, mult)| {
            let denom =
                common_lookup_elements.combine(values);
            writer.write_frac(
                (-mult).into(),
                denom
            );
        });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim {
            claimed_sum,
        },)
    }
}