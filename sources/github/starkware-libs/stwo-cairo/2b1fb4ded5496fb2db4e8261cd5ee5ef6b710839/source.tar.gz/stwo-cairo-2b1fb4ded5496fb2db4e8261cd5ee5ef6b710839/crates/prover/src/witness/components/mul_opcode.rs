// This file was created by the AIR team.

#![allow(unused_parens)]
use cairo_air::components::mul_opcode::{Claim, InteractionClaim, N_TRACE_COLUMNS};

use crate::witness::components::{
    memory_address_to_id, memory_id_to_big, range_check_20, verify_instruction,
};
use crate::witness::prelude::*;

pub type InputType = CasmState;
pub type PackedInputType = PackedCasmState;

#[derive(Default)]
pub struct ClaimGenerator {
    pub inputs: Vec<InputType>,
}

impl ClaimGenerator {
    pub fn new(inputs: Vec<InputType>) -> Self {
        Self { inputs }
    }

    pub fn write_trace(
        mut self,
        memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
        memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
        verify_instruction_state: &verify_instruction::ClaimGenerator,
        range_check_20_state: &range_check_20::ClaimGenerator,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let n_active_rows = self.inputs.len();
        assert_ne!(n_active_rows, 0);
        let size = std::cmp::max(n_active_rows.next_power_of_two(), N_LANES);
        let log_size = size.ilog2();
        self.inputs.resize(size, *self.inputs.first().unwrap());
        let packed_inputs = pack_values(&self.inputs);

        let (trace, lookup_data, sub_component_inputs) = write_trace_simd(
            packed_inputs,
            n_active_rows,
            memory_address_to_id_state,
            memory_id_to_big_state,
            verify_instruction_state,
            range_check_20_state,
        );
        for inputs in sub_component_inputs.verify_instruction {
            add_inputs(verify_instruction_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.memory_address_to_id {
            add_inputs(memory_address_to_id_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.memory_id_to_big {
            add_inputs(memory_id_to_big_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.range_check_20 {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.range_check_20_b {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 1);
        }
        for inputs in sub_component_inputs.range_check_20_c {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 2);
        }
        for inputs in sub_component_inputs.range_check_20_d {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 3);
        }
        for inputs in sub_component_inputs.range_check_20_e {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 4);
        }
        for inputs in sub_component_inputs.range_check_20_f {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 5);
        }
        for inputs in sub_component_inputs.range_check_20_g {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 6);
        }
        for inputs in sub_component_inputs.range_check_20_h {
            add_inputs(range_check_20_state, &inputs, n_active_rows, 7);
        }

        (trace, Claim { log_size }, InteractionClaimGenerator { log_size, lookup_data })
    }
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct SubComponentInputs {
    verify_instruction: [Vec<verify_instruction::PackedInputType>; 1],
    memory_address_to_id: [Vec<memory_address_to_id::PackedInputType>; 3],
    memory_id_to_big: [Vec<memory_id_to_big::PackedInputType>; 3],
    range_check_20: [Vec<range_check_20::PackedInputType>; 4],
    range_check_20_b: [Vec<range_check_20::PackedInputType>; 4],
    range_check_20_c: [Vec<range_check_20::PackedInputType>; 4],
    range_check_20_d: [Vec<range_check_20::PackedInputType>; 4],
    range_check_20_e: [Vec<range_check_20::PackedInputType>; 3],
    range_check_20_f: [Vec<range_check_20::PackedInputType>; 3],
    range_check_20_g: [Vec<range_check_20::PackedInputType>; 3],
    range_check_20_h: [Vec<range_check_20::PackedInputType>; 3],
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    inputs: Vec<PackedInputType>,
    n_rows: usize,
    memory_address_to_id_state: &memory_address_to_id::ClaimGenerator,
    memory_id_to_big_state: &memory_id_to_big::ClaimGenerator,
    verify_instruction_state: &verify_instruction::ClaimGenerator,
    range_check_20_state: &range_check_20::ClaimGenerator,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData, SubComponentInputs) {
    let log_n_packed_rows = inputs.len().ilog2();
    let log_size = log_n_packed_rows + LOG_N_LANES;
    let (mut trace, mut lookup_data, mut sub_component_inputs) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(log_size),
            LookupData::uninitialized(log_n_packed_rows),
            SubComponentInputs::uninitialized(log_n_packed_rows),
        )
    };

    let M31_0 = PackedM31::broadcast(M31::from(0));
    let M31_1 = PackedM31::broadcast(M31::from(1));
    let M31_128 = PackedM31::broadcast(M31::from(128));
    let M31_134217728 = PackedM31::broadcast(M31::from(134217728));
    let M31_136 = PackedM31::broadcast(M31::from(136));
    let M31_1410849886 = PackedM31::broadcast(M31::from(1410849886));
    let M31_1444891767 = PackedM31::broadcast(M31::from(1444891767));
    let M31_16 = PackedM31::broadcast(M31::from(16));
    let M31_1662111297 = PackedM31::broadcast(M31::from(1662111297));
    let M31_1719106205 = PackedM31::broadcast(M31::from(1719106205));
    let M31_2 = PackedM31::broadcast(M31::from(2));
    let M31_256 = PackedM31::broadcast(M31::from(256));
    let M31_32 = PackedM31::broadcast(M31::from(32));
    let M31_32768 = PackedM31::broadcast(M31::from(32768));
    let M31_4 = PackedM31::broadcast(M31::from(4));
    let M31_4194304 = PackedM31::broadcast(M31::from(4194304));
    let M31_428564188 = PackedM31::broadcast(M31::from(428564188));
    let M31_447122465 = PackedM31::broadcast(M31::from(447122465));
    let M31_463900084 = PackedM31::broadcast(M31::from(463900084));
    let M31_480677703 = PackedM31::broadcast(M31::from(480677703));
    let M31_497455322 = PackedM31::broadcast(M31::from(497455322));
    let M31_514232941 = PackedM31::broadcast(M31::from(514232941));
    let M31_524288 = PackedM31::broadcast(M31::from(524288));
    let M31_531010560 = PackedM31::broadcast(M31::from(531010560));
    let M31_64 = PackedM31::broadcast(M31::from(64));
    let M31_65536 = PackedM31::broadcast(M31::from(65536));
    let M31_682009131 = PackedM31::broadcast(M31::from(682009131));
    let M31_8 = PackedM31::broadcast(M31::from(8));
    let UInt16_0 = PackedUInt16::broadcast(UInt16::from(0));
    let UInt16_1 = PackedUInt16::broadcast(UInt16::from(1));
    let UInt16_11 = PackedUInt16::broadcast(UInt16::from(11));
    let UInt16_127 = PackedUInt16::broadcast(UInt16::from(127));
    let UInt16_13 = PackedUInt16::broadcast(UInt16::from(13));
    let UInt16_2 = PackedUInt16::broadcast(UInt16::from(2));
    let UInt16_3 = PackedUInt16::broadcast(UInt16::from(3));
    let UInt16_31 = PackedUInt16::broadcast(UInt16::from(31));
    let UInt16_4 = PackedUInt16::broadcast(UInt16::from(4));
    let UInt16_5 = PackedUInt16::broadcast(UInt16::from(5));
    let UInt16_6 = PackedUInt16::broadcast(UInt16::from(6));
    let UInt16_7 = PackedUInt16::broadcast(UInt16::from(7));
    let UInt16_9 = PackedUInt16::broadcast(UInt16::from(9));
    let UInt32_131072 = PackedUInt32::broadcast(UInt32::from(131072));
    let UInt32_262143 = PackedUInt32::broadcast(UInt32::from(262143));
    let UInt32_511 = PackedUInt32::broadcast(UInt32::from(511));
    let UInt32_9 = PackedUInt32::broadcast(UInt32::from(9));
    let enabler_col = Enabler::new(n_rows);

    (
        trace.par_iter_mut(),
        lookup_data.par_iter_mut(),
        sub_component_inputs.par_iter_mut(),
        inputs.into_par_iter(),
    )
        .into_par_iter()
        .enumerate()
        .for_each(|(row_index, (row, lookup_data, sub_component_inputs, mul_opcode_input))| {
            let enabler_col0 = enabler_col.packed_at(row_index);
            *row[0] = enabler_col0;
            let input_pc_col1 = mul_opcode_input.pc;
            *row[1] = input_pc_col1;
            let input_ap_col2 = mul_opcode_input.ap;
            *row[2] = input_ap_col2;
            let input_fp_col3 = mul_opcode_input.fp;
            *row[3] = input_fp_col3;

            // Decode Instruction.

            let memory_address_to_id_value_tmp_93be2_0 =
                memory_address_to_id_state.deduce_output(input_pc_col1);
            let memory_id_to_big_value_tmp_93be2_1 =
                memory_id_to_big_state.deduce_output(memory_address_to_id_value_tmp_93be2_0);
            let offset0_tmp_93be2_2 =
                ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(0)))
                    + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(1)))
                        & (UInt16_127))
                        << (UInt16_9)));
            let offset0_col4 = offset0_tmp_93be2_2.as_m31();
            *row[4] = offset0_col4;
            let offset1_tmp_93be2_3 =
                ((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(1)))
                    >> (UInt16_7))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(2)))
                        << (UInt16_2)))
                    + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(3)))
                        & (UInt16_31))
                        << (UInt16_11)));
            let offset1_col5 = offset1_tmp_93be2_3.as_m31();
            *row[5] = offset1_col5;
            let offset2_tmp_93be2_4 =
                ((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(3)))
                    >> (UInt16_5))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(4)))
                        << (UInt16_4)))
                    + (((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(5)))
                        & (UInt16_7))
                        << (UInt16_13)));
            let offset2_col6 = offset2_tmp_93be2_4.as_m31();
            *row[6] = offset2_col6;
            let dst_base_fp_tmp_93be2_5 =
                (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(5)))
                    >> (UInt16_3))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(6)))
                        << (UInt16_6)))
                    >> (UInt16_0))
                    & (UInt16_1));
            let dst_base_fp_col7 = dst_base_fp_tmp_93be2_5.as_m31();
            *row[7] = dst_base_fp_col7;
            let op0_base_fp_tmp_93be2_6 =
                (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(5)))
                    >> (UInt16_3))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(6)))
                        << (UInt16_6)))
                    >> (UInt16_1))
                    & (UInt16_1));
            let op0_base_fp_col8 = op0_base_fp_tmp_93be2_6.as_m31();
            *row[8] = op0_base_fp_col8;
            let op1_imm_tmp_93be2_7 =
                (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(5)))
                    >> (UInt16_3))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(6)))
                        << (UInt16_6)))
                    >> (UInt16_2))
                    & (UInt16_1));
            let op1_imm_col9 = op1_imm_tmp_93be2_7.as_m31();
            *row[9] = op1_imm_col9;
            let op1_base_fp_tmp_93be2_8 =
                (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(5)))
                    >> (UInt16_3))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(6)))
                        << (UInt16_6)))
                    >> (UInt16_3))
                    & (UInt16_1));
            let op1_base_fp_col10 = op1_base_fp_tmp_93be2_8.as_m31();
            *row[10] = op1_base_fp_col10;
            let op1_base_ap_tmp_93be2_9 = (((M31_1) - (op1_imm_col9)) - (op1_base_fp_col10));
            let ap_update_add_1_tmp_93be2_10 =
                (((((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(5)))
                    >> (UInt16_3))
                    + ((PackedUInt16::from_m31(memory_id_to_big_value_tmp_93be2_1.get_m31(6)))
                        << (UInt16_6)))
                    >> (UInt16_11))
                    & (UInt16_1));
            let ap_update_add_1_col11 = ap_update_add_1_tmp_93be2_10.as_m31();
            *row[11] = ap_update_add_1_col11;
            *sub_component_inputs.verify_instruction[0] = (
                input_pc_col1,
                [offset0_col4, offset1_col5, offset2_col6],
                [
                    ((((((dst_base_fp_col7) * (M31_8)) + ((op0_base_fp_col8) * (M31_16)))
                        + ((op1_imm_col9) * (M31_32)))
                        + ((op1_base_fp_col10) * (M31_64)))
                        + ((op1_base_ap_tmp_93be2_9) * (M31_128))),
                    (((M31_1) + ((ap_update_add_1_col11) * (M31_32))) + (M31_256)),
                ],
                M31_0,
            );
            *lookup_data.verify_instruction_0 = [
                M31_1719106205,
                input_pc_col1,
                offset0_col4,
                offset1_col5,
                offset2_col6,
                ((((((dst_base_fp_col7) * (M31_8)) + ((op0_base_fp_col8) * (M31_16)))
                    + ((op1_imm_col9) * (M31_32)))
                    + ((op1_base_fp_col10) * (M31_64)))
                    + ((op1_base_ap_tmp_93be2_9) * (M31_128))),
                (((M31_1) + ((ap_update_add_1_col11) * (M31_32))) + (M31_256)),
                M31_0,
            ];
            let decode_instruction_c630b_output_tmp_93be2_11 = (
                [
                    ((offset0_col4) - (M31_32768)),
                    ((offset1_col5) - (M31_32768)),
                    ((offset2_col6) - (M31_32768)),
                ],
                [
                    dst_base_fp_col7,
                    op0_base_fp_col8,
                    op1_imm_col9,
                    op1_base_fp_col10,
                    op1_base_ap_tmp_93be2_9,
                    M31_0,
                    M31_1,
                    M31_0,
                    M31_0,
                    M31_0,
                    M31_0,
                    ap_update_add_1_col11,
                    M31_0,
                    M31_0,
                    M31_1,
                ],
                M31_0,
            );

            let mem_dst_base_col12 = (((dst_base_fp_col7) * (input_fp_col3))
                + (((M31_1) - (dst_base_fp_col7)) * (input_ap_col2)));
            *row[12] = mem_dst_base_col12;
            let mem0_base_col13 = (((op0_base_fp_col8) * (input_fp_col3))
                + (((M31_1) - (op0_base_fp_col8)) * (input_ap_col2)));
            *row[13] = mem0_base_col13;
            let mem1_base_col14 = ((((op1_imm_col9) * (input_pc_col1))
                + ((op1_base_fp_col10) * (input_fp_col3)))
                + ((decode_instruction_c630b_output_tmp_93be2_11.1[4]) * (input_ap_col2)));
            *row[14] = mem1_base_col14;

            // Read Positive Num Bits 252.

            // Read Id.

            let memory_address_to_id_value_tmp_93be2_12 = memory_address_to_id_state.deduce_output(
                ((mem_dst_base_col12) + (decode_instruction_c630b_output_tmp_93be2_11.0[0])),
            );
            let dst_id_col15 = memory_address_to_id_value_tmp_93be2_12;
            *row[15] = dst_id_col15;
            *sub_component_inputs.memory_address_to_id[0] =
                ((mem_dst_base_col12) + (decode_instruction_c630b_output_tmp_93be2_11.0[0]));
            *lookup_data.memory_address_to_id_1 = [
                M31_1444891767,
                ((mem_dst_base_col12) + (decode_instruction_c630b_output_tmp_93be2_11.0[0])),
                dst_id_col15,
            ];

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_93be2_14 =
                memory_id_to_big_state.deduce_output(dst_id_col15);
            let dst_limb_0_col16 = memory_id_to_big_value_tmp_93be2_14.get_m31(0);
            *row[16] = dst_limb_0_col16;
            let dst_limb_1_col17 = memory_id_to_big_value_tmp_93be2_14.get_m31(1);
            *row[17] = dst_limb_1_col17;
            let dst_limb_2_col18 = memory_id_to_big_value_tmp_93be2_14.get_m31(2);
            *row[18] = dst_limb_2_col18;
            let dst_limb_3_col19 = memory_id_to_big_value_tmp_93be2_14.get_m31(3);
            *row[19] = dst_limb_3_col19;
            let dst_limb_4_col20 = memory_id_to_big_value_tmp_93be2_14.get_m31(4);
            *row[20] = dst_limb_4_col20;
            let dst_limb_5_col21 = memory_id_to_big_value_tmp_93be2_14.get_m31(5);
            *row[21] = dst_limb_5_col21;
            let dst_limb_6_col22 = memory_id_to_big_value_tmp_93be2_14.get_m31(6);
            *row[22] = dst_limb_6_col22;
            let dst_limb_7_col23 = memory_id_to_big_value_tmp_93be2_14.get_m31(7);
            *row[23] = dst_limb_7_col23;
            let dst_limb_8_col24 = memory_id_to_big_value_tmp_93be2_14.get_m31(8);
            *row[24] = dst_limb_8_col24;
            let dst_limb_9_col25 = memory_id_to_big_value_tmp_93be2_14.get_m31(9);
            *row[25] = dst_limb_9_col25;
            let dst_limb_10_col26 = memory_id_to_big_value_tmp_93be2_14.get_m31(10);
            *row[26] = dst_limb_10_col26;
            let dst_limb_11_col27 = memory_id_to_big_value_tmp_93be2_14.get_m31(11);
            *row[27] = dst_limb_11_col27;
            let dst_limb_12_col28 = memory_id_to_big_value_tmp_93be2_14.get_m31(12);
            *row[28] = dst_limb_12_col28;
            let dst_limb_13_col29 = memory_id_to_big_value_tmp_93be2_14.get_m31(13);
            *row[29] = dst_limb_13_col29;
            let dst_limb_14_col30 = memory_id_to_big_value_tmp_93be2_14.get_m31(14);
            *row[30] = dst_limb_14_col30;
            let dst_limb_15_col31 = memory_id_to_big_value_tmp_93be2_14.get_m31(15);
            *row[31] = dst_limb_15_col31;
            let dst_limb_16_col32 = memory_id_to_big_value_tmp_93be2_14.get_m31(16);
            *row[32] = dst_limb_16_col32;
            let dst_limb_17_col33 = memory_id_to_big_value_tmp_93be2_14.get_m31(17);
            *row[33] = dst_limb_17_col33;
            let dst_limb_18_col34 = memory_id_to_big_value_tmp_93be2_14.get_m31(18);
            *row[34] = dst_limb_18_col34;
            let dst_limb_19_col35 = memory_id_to_big_value_tmp_93be2_14.get_m31(19);
            *row[35] = dst_limb_19_col35;
            let dst_limb_20_col36 = memory_id_to_big_value_tmp_93be2_14.get_m31(20);
            *row[36] = dst_limb_20_col36;
            let dst_limb_21_col37 = memory_id_to_big_value_tmp_93be2_14.get_m31(21);
            *row[37] = dst_limb_21_col37;
            let dst_limb_22_col38 = memory_id_to_big_value_tmp_93be2_14.get_m31(22);
            *row[38] = dst_limb_22_col38;
            let dst_limb_23_col39 = memory_id_to_big_value_tmp_93be2_14.get_m31(23);
            *row[39] = dst_limb_23_col39;
            let dst_limb_24_col40 = memory_id_to_big_value_tmp_93be2_14.get_m31(24);
            *row[40] = dst_limb_24_col40;
            let dst_limb_25_col41 = memory_id_to_big_value_tmp_93be2_14.get_m31(25);
            *row[41] = dst_limb_25_col41;
            let dst_limb_26_col42 = memory_id_to_big_value_tmp_93be2_14.get_m31(26);
            *row[42] = dst_limb_26_col42;
            let dst_limb_27_col43 = memory_id_to_big_value_tmp_93be2_14.get_m31(27);
            *row[43] = dst_limb_27_col43;
            *sub_component_inputs.memory_id_to_big[0] = dst_id_col15;
            *lookup_data.memory_id_to_big_2 = [
                M31_1662111297,
                dst_id_col15,
                dst_limb_0_col16,
                dst_limb_1_col17,
                dst_limb_2_col18,
                dst_limb_3_col19,
                dst_limb_4_col20,
                dst_limb_5_col21,
                dst_limb_6_col22,
                dst_limb_7_col23,
                dst_limb_8_col24,
                dst_limb_9_col25,
                dst_limb_10_col26,
                dst_limb_11_col27,
                dst_limb_12_col28,
                dst_limb_13_col29,
                dst_limb_14_col30,
                dst_limb_15_col31,
                dst_limb_16_col32,
                dst_limb_17_col33,
                dst_limb_18_col34,
                dst_limb_19_col35,
                dst_limb_20_col36,
                dst_limb_21_col37,
                dst_limb_22_col38,
                dst_limb_23_col39,
                dst_limb_24_col40,
                dst_limb_25_col41,
                dst_limb_26_col42,
                dst_limb_27_col43,
            ];
            let read_positive_known_id_num_bits_252_output_tmp_93be2_15 =
                PackedFelt252::from_limbs([
                    dst_limb_0_col16,
                    dst_limb_1_col17,
                    dst_limb_2_col18,
                    dst_limb_3_col19,
                    dst_limb_4_col20,
                    dst_limb_5_col21,
                    dst_limb_6_col22,
                    dst_limb_7_col23,
                    dst_limb_8_col24,
                    dst_limb_9_col25,
                    dst_limb_10_col26,
                    dst_limb_11_col27,
                    dst_limb_12_col28,
                    dst_limb_13_col29,
                    dst_limb_14_col30,
                    dst_limb_15_col31,
                    dst_limb_16_col32,
                    dst_limb_17_col33,
                    dst_limb_18_col34,
                    dst_limb_19_col35,
                    dst_limb_20_col36,
                    dst_limb_21_col37,
                    dst_limb_22_col38,
                    dst_limb_23_col39,
                    dst_limb_24_col40,
                    dst_limb_25_col41,
                    dst_limb_26_col42,
                    dst_limb_27_col43,
                ]);

            let read_positive_num_bits_252_output_tmp_93be2_16 =
                (read_positive_known_id_num_bits_252_output_tmp_93be2_15, dst_id_col15);

            // Read Positive Num Bits 252.

            // Read Id.

            let memory_address_to_id_value_tmp_93be2_17 = memory_address_to_id_state.deduce_output(
                ((mem0_base_col13) + (decode_instruction_c630b_output_tmp_93be2_11.0[1])),
            );
            let op0_id_col44 = memory_address_to_id_value_tmp_93be2_17;
            *row[44] = op0_id_col44;
            *sub_component_inputs.memory_address_to_id[1] =
                ((mem0_base_col13) + (decode_instruction_c630b_output_tmp_93be2_11.0[1]));
            *lookup_data.memory_address_to_id_3 = [
                M31_1444891767,
                ((mem0_base_col13) + (decode_instruction_c630b_output_tmp_93be2_11.0[1])),
                op0_id_col44,
            ];

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_93be2_19 =
                memory_id_to_big_state.deduce_output(op0_id_col44);
            let op0_limb_0_col45 = memory_id_to_big_value_tmp_93be2_19.get_m31(0);
            *row[45] = op0_limb_0_col45;
            let op0_limb_1_col46 = memory_id_to_big_value_tmp_93be2_19.get_m31(1);
            *row[46] = op0_limb_1_col46;
            let op0_limb_2_col47 = memory_id_to_big_value_tmp_93be2_19.get_m31(2);
            *row[47] = op0_limb_2_col47;
            let op0_limb_3_col48 = memory_id_to_big_value_tmp_93be2_19.get_m31(3);
            *row[48] = op0_limb_3_col48;
            let op0_limb_4_col49 = memory_id_to_big_value_tmp_93be2_19.get_m31(4);
            *row[49] = op0_limb_4_col49;
            let op0_limb_5_col50 = memory_id_to_big_value_tmp_93be2_19.get_m31(5);
            *row[50] = op0_limb_5_col50;
            let op0_limb_6_col51 = memory_id_to_big_value_tmp_93be2_19.get_m31(6);
            *row[51] = op0_limb_6_col51;
            let op0_limb_7_col52 = memory_id_to_big_value_tmp_93be2_19.get_m31(7);
            *row[52] = op0_limb_7_col52;
            let op0_limb_8_col53 = memory_id_to_big_value_tmp_93be2_19.get_m31(8);
            *row[53] = op0_limb_8_col53;
            let op0_limb_9_col54 = memory_id_to_big_value_tmp_93be2_19.get_m31(9);
            *row[54] = op0_limb_9_col54;
            let op0_limb_10_col55 = memory_id_to_big_value_tmp_93be2_19.get_m31(10);
            *row[55] = op0_limb_10_col55;
            let op0_limb_11_col56 = memory_id_to_big_value_tmp_93be2_19.get_m31(11);
            *row[56] = op0_limb_11_col56;
            let op0_limb_12_col57 = memory_id_to_big_value_tmp_93be2_19.get_m31(12);
            *row[57] = op0_limb_12_col57;
            let op0_limb_13_col58 = memory_id_to_big_value_tmp_93be2_19.get_m31(13);
            *row[58] = op0_limb_13_col58;
            let op0_limb_14_col59 = memory_id_to_big_value_tmp_93be2_19.get_m31(14);
            *row[59] = op0_limb_14_col59;
            let op0_limb_15_col60 = memory_id_to_big_value_tmp_93be2_19.get_m31(15);
            *row[60] = op0_limb_15_col60;
            let op0_limb_16_col61 = memory_id_to_big_value_tmp_93be2_19.get_m31(16);
            *row[61] = op0_limb_16_col61;
            let op0_limb_17_col62 = memory_id_to_big_value_tmp_93be2_19.get_m31(17);
            *row[62] = op0_limb_17_col62;
            let op0_limb_18_col63 = memory_id_to_big_value_tmp_93be2_19.get_m31(18);
            *row[63] = op0_limb_18_col63;
            let op0_limb_19_col64 = memory_id_to_big_value_tmp_93be2_19.get_m31(19);
            *row[64] = op0_limb_19_col64;
            let op0_limb_20_col65 = memory_id_to_big_value_tmp_93be2_19.get_m31(20);
            *row[65] = op0_limb_20_col65;
            let op0_limb_21_col66 = memory_id_to_big_value_tmp_93be2_19.get_m31(21);
            *row[66] = op0_limb_21_col66;
            let op0_limb_22_col67 = memory_id_to_big_value_tmp_93be2_19.get_m31(22);
            *row[67] = op0_limb_22_col67;
            let op0_limb_23_col68 = memory_id_to_big_value_tmp_93be2_19.get_m31(23);
            *row[68] = op0_limb_23_col68;
            let op0_limb_24_col69 = memory_id_to_big_value_tmp_93be2_19.get_m31(24);
            *row[69] = op0_limb_24_col69;
            let op0_limb_25_col70 = memory_id_to_big_value_tmp_93be2_19.get_m31(25);
            *row[70] = op0_limb_25_col70;
            let op0_limb_26_col71 = memory_id_to_big_value_tmp_93be2_19.get_m31(26);
            *row[71] = op0_limb_26_col71;
            let op0_limb_27_col72 = memory_id_to_big_value_tmp_93be2_19.get_m31(27);
            *row[72] = op0_limb_27_col72;
            *sub_component_inputs.memory_id_to_big[1] = op0_id_col44;
            *lookup_data.memory_id_to_big_4 = [
                M31_1662111297,
                op0_id_col44,
                op0_limb_0_col45,
                op0_limb_1_col46,
                op0_limb_2_col47,
                op0_limb_3_col48,
                op0_limb_4_col49,
                op0_limb_5_col50,
                op0_limb_6_col51,
                op0_limb_7_col52,
                op0_limb_8_col53,
                op0_limb_9_col54,
                op0_limb_10_col55,
                op0_limb_11_col56,
                op0_limb_12_col57,
                op0_limb_13_col58,
                op0_limb_14_col59,
                op0_limb_15_col60,
                op0_limb_16_col61,
                op0_limb_17_col62,
                op0_limb_18_col63,
                op0_limb_19_col64,
                op0_limb_20_col65,
                op0_limb_21_col66,
                op0_limb_22_col67,
                op0_limb_23_col68,
                op0_limb_24_col69,
                op0_limb_25_col70,
                op0_limb_26_col71,
                op0_limb_27_col72,
            ];
            let read_positive_known_id_num_bits_252_output_tmp_93be2_20 =
                PackedFelt252::from_limbs([
                    op0_limb_0_col45,
                    op0_limb_1_col46,
                    op0_limb_2_col47,
                    op0_limb_3_col48,
                    op0_limb_4_col49,
                    op0_limb_5_col50,
                    op0_limb_6_col51,
                    op0_limb_7_col52,
                    op0_limb_8_col53,
                    op0_limb_9_col54,
                    op0_limb_10_col55,
                    op0_limb_11_col56,
                    op0_limb_12_col57,
                    op0_limb_13_col58,
                    op0_limb_14_col59,
                    op0_limb_15_col60,
                    op0_limb_16_col61,
                    op0_limb_17_col62,
                    op0_limb_18_col63,
                    op0_limb_19_col64,
                    op0_limb_20_col65,
                    op0_limb_21_col66,
                    op0_limb_22_col67,
                    op0_limb_23_col68,
                    op0_limb_24_col69,
                    op0_limb_25_col70,
                    op0_limb_26_col71,
                    op0_limb_27_col72,
                ]);

            let read_positive_num_bits_252_output_tmp_93be2_21 =
                (read_positive_known_id_num_bits_252_output_tmp_93be2_20, op0_id_col44);

            // Read Positive Num Bits 252.

            // Read Id.

            let memory_address_to_id_value_tmp_93be2_22 = memory_address_to_id_state.deduce_output(
                ((mem1_base_col14) + (decode_instruction_c630b_output_tmp_93be2_11.0[2])),
            );
            let op1_id_col73 = memory_address_to_id_value_tmp_93be2_22;
            *row[73] = op1_id_col73;
            *sub_component_inputs.memory_address_to_id[2] =
                ((mem1_base_col14) + (decode_instruction_c630b_output_tmp_93be2_11.0[2]));
            *lookup_data.memory_address_to_id_5 = [
                M31_1444891767,
                ((mem1_base_col14) + (decode_instruction_c630b_output_tmp_93be2_11.0[2])),
                op1_id_col73,
            ];

            // Read Positive Known Id Num Bits 252.

            let memory_id_to_big_value_tmp_93be2_24 =
                memory_id_to_big_state.deduce_output(op1_id_col73);
            let op1_limb_0_col74 = memory_id_to_big_value_tmp_93be2_24.get_m31(0);
            *row[74] = op1_limb_0_col74;
            let op1_limb_1_col75 = memory_id_to_big_value_tmp_93be2_24.get_m31(1);
            *row[75] = op1_limb_1_col75;
            let op1_limb_2_col76 = memory_id_to_big_value_tmp_93be2_24.get_m31(2);
            *row[76] = op1_limb_2_col76;
            let op1_limb_3_col77 = memory_id_to_big_value_tmp_93be2_24.get_m31(3);
            *row[77] = op1_limb_3_col77;
            let op1_limb_4_col78 = memory_id_to_big_value_tmp_93be2_24.get_m31(4);
            *row[78] = op1_limb_4_col78;
            let op1_limb_5_col79 = memory_id_to_big_value_tmp_93be2_24.get_m31(5);
            *row[79] = op1_limb_5_col79;
            let op1_limb_6_col80 = memory_id_to_big_value_tmp_93be2_24.get_m31(6);
            *row[80] = op1_limb_6_col80;
            let op1_limb_7_col81 = memory_id_to_big_value_tmp_93be2_24.get_m31(7);
            *row[81] = op1_limb_7_col81;
            let op1_limb_8_col82 = memory_id_to_big_value_tmp_93be2_24.get_m31(8);
            *row[82] = op1_limb_8_col82;
            let op1_limb_9_col83 = memory_id_to_big_value_tmp_93be2_24.get_m31(9);
            *row[83] = op1_limb_9_col83;
            let op1_limb_10_col84 = memory_id_to_big_value_tmp_93be2_24.get_m31(10);
            *row[84] = op1_limb_10_col84;
            let op1_limb_11_col85 = memory_id_to_big_value_tmp_93be2_24.get_m31(11);
            *row[85] = op1_limb_11_col85;
            let op1_limb_12_col86 = memory_id_to_big_value_tmp_93be2_24.get_m31(12);
            *row[86] = op1_limb_12_col86;
            let op1_limb_13_col87 = memory_id_to_big_value_tmp_93be2_24.get_m31(13);
            *row[87] = op1_limb_13_col87;
            let op1_limb_14_col88 = memory_id_to_big_value_tmp_93be2_24.get_m31(14);
            *row[88] = op1_limb_14_col88;
            let op1_limb_15_col89 = memory_id_to_big_value_tmp_93be2_24.get_m31(15);
            *row[89] = op1_limb_15_col89;
            let op1_limb_16_col90 = memory_id_to_big_value_tmp_93be2_24.get_m31(16);
            *row[90] = op1_limb_16_col90;
            let op1_limb_17_col91 = memory_id_to_big_value_tmp_93be2_24.get_m31(17);
            *row[91] = op1_limb_17_col91;
            let op1_limb_18_col92 = memory_id_to_big_value_tmp_93be2_24.get_m31(18);
            *row[92] = op1_limb_18_col92;
            let op1_limb_19_col93 = memory_id_to_big_value_tmp_93be2_24.get_m31(19);
            *row[93] = op1_limb_19_col93;
            let op1_limb_20_col94 = memory_id_to_big_value_tmp_93be2_24.get_m31(20);
            *row[94] = op1_limb_20_col94;
            let op1_limb_21_col95 = memory_id_to_big_value_tmp_93be2_24.get_m31(21);
            *row[95] = op1_limb_21_col95;
            let op1_limb_22_col96 = memory_id_to_big_value_tmp_93be2_24.get_m31(22);
            *row[96] = op1_limb_22_col96;
            let op1_limb_23_col97 = memory_id_to_big_value_tmp_93be2_24.get_m31(23);
            *row[97] = op1_limb_23_col97;
            let op1_limb_24_col98 = memory_id_to_big_value_tmp_93be2_24.get_m31(24);
            *row[98] = op1_limb_24_col98;
            let op1_limb_25_col99 = memory_id_to_big_value_tmp_93be2_24.get_m31(25);
            *row[99] = op1_limb_25_col99;
            let op1_limb_26_col100 = memory_id_to_big_value_tmp_93be2_24.get_m31(26);
            *row[100] = op1_limb_26_col100;
            let op1_limb_27_col101 = memory_id_to_big_value_tmp_93be2_24.get_m31(27);
            *row[101] = op1_limb_27_col101;
            *sub_component_inputs.memory_id_to_big[2] = op1_id_col73;
            *lookup_data.memory_id_to_big_6 = [
                M31_1662111297,
                op1_id_col73,
                op1_limb_0_col74,
                op1_limb_1_col75,
                op1_limb_2_col76,
                op1_limb_3_col77,
                op1_limb_4_col78,
                op1_limb_5_col79,
                op1_limb_6_col80,
                op1_limb_7_col81,
                op1_limb_8_col82,
                op1_limb_9_col83,
                op1_limb_10_col84,
                op1_limb_11_col85,
                op1_limb_12_col86,
                op1_limb_13_col87,
                op1_limb_14_col88,
                op1_limb_15_col89,
                op1_limb_16_col90,
                op1_limb_17_col91,
                op1_limb_18_col92,
                op1_limb_19_col93,
                op1_limb_20_col94,
                op1_limb_21_col95,
                op1_limb_22_col96,
                op1_limb_23_col97,
                op1_limb_24_col98,
                op1_limb_25_col99,
                op1_limb_26_col100,
                op1_limb_27_col101,
            ];
            let read_positive_known_id_num_bits_252_output_tmp_93be2_25 =
                PackedFelt252::from_limbs([
                    op1_limb_0_col74,
                    op1_limb_1_col75,
                    op1_limb_2_col76,
                    op1_limb_3_col77,
                    op1_limb_4_col78,
                    op1_limb_5_col79,
                    op1_limb_6_col80,
                    op1_limb_7_col81,
                    op1_limb_8_col82,
                    op1_limb_9_col83,
                    op1_limb_10_col84,
                    op1_limb_11_col85,
                    op1_limb_12_col86,
                    op1_limb_13_col87,
                    op1_limb_14_col88,
                    op1_limb_15_col89,
                    op1_limb_16_col90,
                    op1_limb_17_col91,
                    op1_limb_18_col92,
                    op1_limb_19_col93,
                    op1_limb_20_col94,
                    op1_limb_21_col95,
                    op1_limb_22_col96,
                    op1_limb_23_col97,
                    op1_limb_24_col98,
                    op1_limb_25_col99,
                    op1_limb_26_col100,
                    op1_limb_27_col101,
                ]);

            let read_positive_num_bits_252_output_tmp_93be2_26 =
                (read_positive_known_id_num_bits_252_output_tmp_93be2_25, op1_id_col73);

            // Verify Mul 252.

            // Double Karatsuba F 0 Fc 6.

            // Single Karatsuba N 7.

            let z0_tmp_93be2_27 = [
                ((op0_limb_0_col45) * (op1_limb_0_col74)),
                (((op0_limb_0_col45) * (op1_limb_1_col75))
                    + ((op0_limb_1_col46) * (op1_limb_0_col74))),
                ((((op0_limb_0_col45) * (op1_limb_2_col76))
                    + ((op0_limb_1_col46) * (op1_limb_1_col75)))
                    + ((op0_limb_2_col47) * (op1_limb_0_col74))),
                (((((op0_limb_0_col45) * (op1_limb_3_col77))
                    + ((op0_limb_1_col46) * (op1_limb_2_col76)))
                    + ((op0_limb_2_col47) * (op1_limb_1_col75)))
                    + ((op0_limb_3_col48) * (op1_limb_0_col74))),
                ((((((op0_limb_0_col45) * (op1_limb_4_col78))
                    + ((op0_limb_1_col46) * (op1_limb_3_col77)))
                    + ((op0_limb_2_col47) * (op1_limb_2_col76)))
                    + ((op0_limb_3_col48) * (op1_limb_1_col75)))
                    + ((op0_limb_4_col49) * (op1_limb_0_col74))),
                (((((((op0_limb_0_col45) * (op1_limb_5_col79))
                    + ((op0_limb_1_col46) * (op1_limb_4_col78)))
                    + ((op0_limb_2_col47) * (op1_limb_3_col77)))
                    + ((op0_limb_3_col48) * (op1_limb_2_col76)))
                    + ((op0_limb_4_col49) * (op1_limb_1_col75)))
                    + ((op0_limb_5_col50) * (op1_limb_0_col74))),
                ((((((((op0_limb_0_col45) * (op1_limb_6_col80))
                    + ((op0_limb_1_col46) * (op1_limb_5_col79)))
                    + ((op0_limb_2_col47) * (op1_limb_4_col78)))
                    + ((op0_limb_3_col48) * (op1_limb_3_col77)))
                    + ((op0_limb_4_col49) * (op1_limb_2_col76)))
                    + ((op0_limb_5_col50) * (op1_limb_1_col75)))
                    + ((op0_limb_6_col51) * (op1_limb_0_col74))),
                (((((((op0_limb_1_col46) * (op1_limb_6_col80))
                    + ((op0_limb_2_col47) * (op1_limb_5_col79)))
                    + ((op0_limb_3_col48) * (op1_limb_4_col78)))
                    + ((op0_limb_4_col49) * (op1_limb_3_col77)))
                    + ((op0_limb_5_col50) * (op1_limb_2_col76)))
                    + ((op0_limb_6_col51) * (op1_limb_1_col75))),
                ((((((op0_limb_2_col47) * (op1_limb_6_col80))
                    + ((op0_limb_3_col48) * (op1_limb_5_col79)))
                    + ((op0_limb_4_col49) * (op1_limb_4_col78)))
                    + ((op0_limb_5_col50) * (op1_limb_3_col77)))
                    + ((op0_limb_6_col51) * (op1_limb_2_col76))),
                (((((op0_limb_3_col48) * (op1_limb_6_col80))
                    + ((op0_limb_4_col49) * (op1_limb_5_col79)))
                    + ((op0_limb_5_col50) * (op1_limb_4_col78)))
                    + ((op0_limb_6_col51) * (op1_limb_3_col77))),
                ((((op0_limb_4_col49) * (op1_limb_6_col80))
                    + ((op0_limb_5_col50) * (op1_limb_5_col79)))
                    + ((op0_limb_6_col51) * (op1_limb_4_col78))),
                (((op0_limb_5_col50) * (op1_limb_6_col80))
                    + ((op0_limb_6_col51) * (op1_limb_5_col79))),
                ((op0_limb_6_col51) * (op1_limb_6_col80)),
            ];
            let z2_tmp_93be2_28 = [
                ((op0_limb_7_col52) * (op1_limb_7_col81)),
                (((op0_limb_7_col52) * (op1_limb_8_col82))
                    + ((op0_limb_8_col53) * (op1_limb_7_col81))),
                ((((op0_limb_7_col52) * (op1_limb_9_col83))
                    + ((op0_limb_8_col53) * (op1_limb_8_col82)))
                    + ((op0_limb_9_col54) * (op1_limb_7_col81))),
                (((((op0_limb_7_col52) * (op1_limb_10_col84))
                    + ((op0_limb_8_col53) * (op1_limb_9_col83)))
                    + ((op0_limb_9_col54) * (op1_limb_8_col82)))
                    + ((op0_limb_10_col55) * (op1_limb_7_col81))),
                ((((((op0_limb_7_col52) * (op1_limb_11_col85))
                    + ((op0_limb_8_col53) * (op1_limb_10_col84)))
                    + ((op0_limb_9_col54) * (op1_limb_9_col83)))
                    + ((op0_limb_10_col55) * (op1_limb_8_col82)))
                    + ((op0_limb_11_col56) * (op1_limb_7_col81))),
                (((((((op0_limb_7_col52) * (op1_limb_12_col86))
                    + ((op0_limb_8_col53) * (op1_limb_11_col85)))
                    + ((op0_limb_9_col54) * (op1_limb_10_col84)))
                    + ((op0_limb_10_col55) * (op1_limb_9_col83)))
                    + ((op0_limb_11_col56) * (op1_limb_8_col82)))
                    + ((op0_limb_12_col57) * (op1_limb_7_col81))),
                ((((((((op0_limb_7_col52) * (op1_limb_13_col87))
                    + ((op0_limb_8_col53) * (op1_limb_12_col86)))
                    + ((op0_limb_9_col54) * (op1_limb_11_col85)))
                    + ((op0_limb_10_col55) * (op1_limb_10_col84)))
                    + ((op0_limb_11_col56) * (op1_limb_9_col83)))
                    + ((op0_limb_12_col57) * (op1_limb_8_col82)))
                    + ((op0_limb_13_col58) * (op1_limb_7_col81))),
                (((((((op0_limb_8_col53) * (op1_limb_13_col87))
                    + ((op0_limb_9_col54) * (op1_limb_12_col86)))
                    + ((op0_limb_10_col55) * (op1_limb_11_col85)))
                    + ((op0_limb_11_col56) * (op1_limb_10_col84)))
                    + ((op0_limb_12_col57) * (op1_limb_9_col83)))
                    + ((op0_limb_13_col58) * (op1_limb_8_col82))),
                ((((((op0_limb_9_col54) * (op1_limb_13_col87))
                    + ((op0_limb_10_col55) * (op1_limb_12_col86)))
                    + ((op0_limb_11_col56) * (op1_limb_11_col85)))
                    + ((op0_limb_12_col57) * (op1_limb_10_col84)))
                    + ((op0_limb_13_col58) * (op1_limb_9_col83))),
                (((((op0_limb_10_col55) * (op1_limb_13_col87))
                    + ((op0_limb_11_col56) * (op1_limb_12_col86)))
                    + ((op0_limb_12_col57) * (op1_limb_11_col85)))
                    + ((op0_limb_13_col58) * (op1_limb_10_col84))),
                ((((op0_limb_11_col56) * (op1_limb_13_col87))
                    + ((op0_limb_12_col57) * (op1_limb_12_col86)))
                    + ((op0_limb_13_col58) * (op1_limb_11_col85))),
                (((op0_limb_12_col57) * (op1_limb_13_col87))
                    + ((op0_limb_13_col58) * (op1_limb_12_col86))),
                ((op0_limb_13_col58) * (op1_limb_13_col87)),
            ];
            let x_sum_tmp_93be2_29 = [
                ((op0_limb_0_col45) + (op0_limb_7_col52)),
                ((op0_limb_1_col46) + (op0_limb_8_col53)),
                ((op0_limb_2_col47) + (op0_limb_9_col54)),
                ((op0_limb_3_col48) + (op0_limb_10_col55)),
                ((op0_limb_4_col49) + (op0_limb_11_col56)),
                ((op0_limb_5_col50) + (op0_limb_12_col57)),
                ((op0_limb_6_col51) + (op0_limb_13_col58)),
            ];
            let y_sum_tmp_93be2_30 = [
                ((op1_limb_0_col74) + (op1_limb_7_col81)),
                ((op1_limb_1_col75) + (op1_limb_8_col82)),
                ((op1_limb_2_col76) + (op1_limb_9_col83)),
                ((op1_limb_3_col77) + (op1_limb_10_col84)),
                ((op1_limb_4_col78) + (op1_limb_11_col85)),
                ((op1_limb_5_col79) + (op1_limb_12_col86)),
                ((op1_limb_6_col80) + (op1_limb_13_col87)),
            ];
            let single_karatsuba_n_7_output_tmp_93be2_31 = [
                z0_tmp_93be2_27[0],
                z0_tmp_93be2_27[1],
                z0_tmp_93be2_27[2],
                z0_tmp_93be2_27[3],
                z0_tmp_93be2_27[4],
                z0_tmp_93be2_27[5],
                z0_tmp_93be2_27[6],
                ((z0_tmp_93be2_27[7])
                    + ((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[0]))
                        - (z0_tmp_93be2_27[0]))
                        - (z2_tmp_93be2_28[0]))),
                ((z0_tmp_93be2_27[8])
                    + (((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[1]))
                        + ((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[0])))
                        - (z0_tmp_93be2_27[1]))
                        - (z2_tmp_93be2_28[1]))),
                ((z0_tmp_93be2_27[9])
                    + ((((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[2]))
                        + ((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[1])))
                        + ((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[0])))
                        - (z0_tmp_93be2_27[2]))
                        - (z2_tmp_93be2_28[2]))),
                ((z0_tmp_93be2_27[10])
                    + (((((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[3]))
                        + ((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[2])))
                        + ((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[1])))
                        + ((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[0])))
                        - (z0_tmp_93be2_27[3]))
                        - (z2_tmp_93be2_28[3]))),
                ((z0_tmp_93be2_27[11])
                    + ((((((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[4]))
                        + ((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[3])))
                        + ((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[2])))
                        + ((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[1])))
                        + ((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[0])))
                        - (z0_tmp_93be2_27[4]))
                        - (z2_tmp_93be2_28[4]))),
                ((z0_tmp_93be2_27[12])
                    + (((((((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[5]))
                        + ((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[4])))
                        + ((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[3])))
                        + ((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[2])))
                        + ((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[1])))
                        + ((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[0])))
                        - (z0_tmp_93be2_27[5]))
                        - (z2_tmp_93be2_28[5]))),
                ((((((((((x_sum_tmp_93be2_29[0]) * (y_sum_tmp_93be2_30[6]))
                    + ((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[5])))
                    + ((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[4])))
                    + ((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[3])))
                    + ((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[2])))
                    + ((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[1])))
                    + ((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[0])))
                    - (z0_tmp_93be2_27[6]))
                    - (z2_tmp_93be2_28[6])),
                ((z2_tmp_93be2_28[0])
                    + (((((((((x_sum_tmp_93be2_29[1]) * (y_sum_tmp_93be2_30[6]))
                        + ((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[5])))
                        + ((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[4])))
                        + ((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[3])))
                        + ((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[2])))
                        + ((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[1])))
                        - (z0_tmp_93be2_27[7]))
                        - (z2_tmp_93be2_28[7]))),
                ((z2_tmp_93be2_28[1])
                    + ((((((((x_sum_tmp_93be2_29[2]) * (y_sum_tmp_93be2_30[6]))
                        + ((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[5])))
                        + ((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[4])))
                        + ((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[3])))
                        + ((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[2])))
                        - (z0_tmp_93be2_27[8]))
                        - (z2_tmp_93be2_28[8]))),
                ((z2_tmp_93be2_28[2])
                    + (((((((x_sum_tmp_93be2_29[3]) * (y_sum_tmp_93be2_30[6]))
                        + ((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[5])))
                        + ((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[4])))
                        + ((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[3])))
                        - (z0_tmp_93be2_27[9]))
                        - (z2_tmp_93be2_28[9]))),
                ((z2_tmp_93be2_28[3])
                    + ((((((x_sum_tmp_93be2_29[4]) * (y_sum_tmp_93be2_30[6]))
                        + ((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[5])))
                        + ((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[4])))
                        - (z0_tmp_93be2_27[10]))
                        - (z2_tmp_93be2_28[10]))),
                ((z2_tmp_93be2_28[4])
                    + (((((x_sum_tmp_93be2_29[5]) * (y_sum_tmp_93be2_30[6]))
                        + ((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[5])))
                        - (z0_tmp_93be2_27[11]))
                        - (z2_tmp_93be2_28[11]))),
                ((z2_tmp_93be2_28[5])
                    + ((((x_sum_tmp_93be2_29[6]) * (y_sum_tmp_93be2_30[6]))
                        - (z0_tmp_93be2_27[12]))
                        - (z2_tmp_93be2_28[12]))),
                z2_tmp_93be2_28[6],
                z2_tmp_93be2_28[7],
                z2_tmp_93be2_28[8],
                z2_tmp_93be2_28[9],
                z2_tmp_93be2_28[10],
                z2_tmp_93be2_28[11],
                z2_tmp_93be2_28[12],
            ];

            // Single Karatsuba N 7.

            let z0_tmp_93be2_32 = [
                ((op0_limb_14_col59) * (op1_limb_14_col88)),
                (((op0_limb_14_col59) * (op1_limb_15_col89))
                    + ((op0_limb_15_col60) * (op1_limb_14_col88))),
                ((((op0_limb_14_col59) * (op1_limb_16_col90))
                    + ((op0_limb_15_col60) * (op1_limb_15_col89)))
                    + ((op0_limb_16_col61) * (op1_limb_14_col88))),
                (((((op0_limb_14_col59) * (op1_limb_17_col91))
                    + ((op0_limb_15_col60) * (op1_limb_16_col90)))
                    + ((op0_limb_16_col61) * (op1_limb_15_col89)))
                    + ((op0_limb_17_col62) * (op1_limb_14_col88))),
                ((((((op0_limb_14_col59) * (op1_limb_18_col92))
                    + ((op0_limb_15_col60) * (op1_limb_17_col91)))
                    + ((op0_limb_16_col61) * (op1_limb_16_col90)))
                    + ((op0_limb_17_col62) * (op1_limb_15_col89)))
                    + ((op0_limb_18_col63) * (op1_limb_14_col88))),
                (((((((op0_limb_14_col59) * (op1_limb_19_col93))
                    + ((op0_limb_15_col60) * (op1_limb_18_col92)))
                    + ((op0_limb_16_col61) * (op1_limb_17_col91)))
                    + ((op0_limb_17_col62) * (op1_limb_16_col90)))
                    + ((op0_limb_18_col63) * (op1_limb_15_col89)))
                    + ((op0_limb_19_col64) * (op1_limb_14_col88))),
                ((((((((op0_limb_14_col59) * (op1_limb_20_col94))
                    + ((op0_limb_15_col60) * (op1_limb_19_col93)))
                    + ((op0_limb_16_col61) * (op1_limb_18_col92)))
                    + ((op0_limb_17_col62) * (op1_limb_17_col91)))
                    + ((op0_limb_18_col63) * (op1_limb_16_col90)))
                    + ((op0_limb_19_col64) * (op1_limb_15_col89)))
                    + ((op0_limb_20_col65) * (op1_limb_14_col88))),
                (((((((op0_limb_15_col60) * (op1_limb_20_col94))
                    + ((op0_limb_16_col61) * (op1_limb_19_col93)))
                    + ((op0_limb_17_col62) * (op1_limb_18_col92)))
                    + ((op0_limb_18_col63) * (op1_limb_17_col91)))
                    + ((op0_limb_19_col64) * (op1_limb_16_col90)))
                    + ((op0_limb_20_col65) * (op1_limb_15_col89))),
                ((((((op0_limb_16_col61) * (op1_limb_20_col94))
                    + ((op0_limb_17_col62) * (op1_limb_19_col93)))
                    + ((op0_limb_18_col63) * (op1_limb_18_col92)))
                    + ((op0_limb_19_col64) * (op1_limb_17_col91)))
                    + ((op0_limb_20_col65) * (op1_limb_16_col90))),
                (((((op0_limb_17_col62) * (op1_limb_20_col94))
                    + ((op0_limb_18_col63) * (op1_limb_19_col93)))
                    + ((op0_limb_19_col64) * (op1_limb_18_col92)))
                    + ((op0_limb_20_col65) * (op1_limb_17_col91))),
                ((((op0_limb_18_col63) * (op1_limb_20_col94))
                    + ((op0_limb_19_col64) * (op1_limb_19_col93)))
                    + ((op0_limb_20_col65) * (op1_limb_18_col92))),
                (((op0_limb_19_col64) * (op1_limb_20_col94))
                    + ((op0_limb_20_col65) * (op1_limb_19_col93))),
                ((op0_limb_20_col65) * (op1_limb_20_col94)),
            ];
            let z2_tmp_93be2_33 = [
                ((op0_limb_21_col66) * (op1_limb_21_col95)),
                (((op0_limb_21_col66) * (op1_limb_22_col96))
                    + ((op0_limb_22_col67) * (op1_limb_21_col95))),
                ((((op0_limb_21_col66) * (op1_limb_23_col97))
                    + ((op0_limb_22_col67) * (op1_limb_22_col96)))
                    + ((op0_limb_23_col68) * (op1_limb_21_col95))),
                (((((op0_limb_21_col66) * (op1_limb_24_col98))
                    + ((op0_limb_22_col67) * (op1_limb_23_col97)))
                    + ((op0_limb_23_col68) * (op1_limb_22_col96)))
                    + ((op0_limb_24_col69) * (op1_limb_21_col95))),
                ((((((op0_limb_21_col66) * (op1_limb_25_col99))
                    + ((op0_limb_22_col67) * (op1_limb_24_col98)))
                    + ((op0_limb_23_col68) * (op1_limb_23_col97)))
                    + ((op0_limb_24_col69) * (op1_limb_22_col96)))
                    + ((op0_limb_25_col70) * (op1_limb_21_col95))),
                (((((((op0_limb_21_col66) * (op1_limb_26_col100))
                    + ((op0_limb_22_col67) * (op1_limb_25_col99)))
                    + ((op0_limb_23_col68) * (op1_limb_24_col98)))
                    + ((op0_limb_24_col69) * (op1_limb_23_col97)))
                    + ((op0_limb_25_col70) * (op1_limb_22_col96)))
                    + ((op0_limb_26_col71) * (op1_limb_21_col95))),
                ((((((((op0_limb_21_col66) * (op1_limb_27_col101))
                    + ((op0_limb_22_col67) * (op1_limb_26_col100)))
                    + ((op0_limb_23_col68) * (op1_limb_25_col99)))
                    + ((op0_limb_24_col69) * (op1_limb_24_col98)))
                    + ((op0_limb_25_col70) * (op1_limb_23_col97)))
                    + ((op0_limb_26_col71) * (op1_limb_22_col96)))
                    + ((op0_limb_27_col72) * (op1_limb_21_col95))),
                (((((((op0_limb_22_col67) * (op1_limb_27_col101))
                    + ((op0_limb_23_col68) * (op1_limb_26_col100)))
                    + ((op0_limb_24_col69) * (op1_limb_25_col99)))
                    + ((op0_limb_25_col70) * (op1_limb_24_col98)))
                    + ((op0_limb_26_col71) * (op1_limb_23_col97)))
                    + ((op0_limb_27_col72) * (op1_limb_22_col96))),
                ((((((op0_limb_23_col68) * (op1_limb_27_col101))
                    + ((op0_limb_24_col69) * (op1_limb_26_col100)))
                    + ((op0_limb_25_col70) * (op1_limb_25_col99)))
                    + ((op0_limb_26_col71) * (op1_limb_24_col98)))
                    + ((op0_limb_27_col72) * (op1_limb_23_col97))),
                (((((op0_limb_24_col69) * (op1_limb_27_col101))
                    + ((op0_limb_25_col70) * (op1_limb_26_col100)))
                    + ((op0_limb_26_col71) * (op1_limb_25_col99)))
                    + ((op0_limb_27_col72) * (op1_limb_24_col98))),
                ((((op0_limb_25_col70) * (op1_limb_27_col101))
                    + ((op0_limb_26_col71) * (op1_limb_26_col100)))
                    + ((op0_limb_27_col72) * (op1_limb_25_col99))),
                (((op0_limb_26_col71) * (op1_limb_27_col101))
                    + ((op0_limb_27_col72) * (op1_limb_26_col100))),
                ((op0_limb_27_col72) * (op1_limb_27_col101)),
            ];
            let x_sum_tmp_93be2_34 = [
                ((op0_limb_14_col59) + (op0_limb_21_col66)),
                ((op0_limb_15_col60) + (op0_limb_22_col67)),
                ((op0_limb_16_col61) + (op0_limb_23_col68)),
                ((op0_limb_17_col62) + (op0_limb_24_col69)),
                ((op0_limb_18_col63) + (op0_limb_25_col70)),
                ((op0_limb_19_col64) + (op0_limb_26_col71)),
                ((op0_limb_20_col65) + (op0_limb_27_col72)),
            ];
            let y_sum_tmp_93be2_35 = [
                ((op1_limb_14_col88) + (op1_limb_21_col95)),
                ((op1_limb_15_col89) + (op1_limb_22_col96)),
                ((op1_limb_16_col90) + (op1_limb_23_col97)),
                ((op1_limb_17_col91) + (op1_limb_24_col98)),
                ((op1_limb_18_col92) + (op1_limb_25_col99)),
                ((op1_limb_19_col93) + (op1_limb_26_col100)),
                ((op1_limb_20_col94) + (op1_limb_27_col101)),
            ];
            let single_karatsuba_n_7_output_tmp_93be2_36 = [
                z0_tmp_93be2_32[0],
                z0_tmp_93be2_32[1],
                z0_tmp_93be2_32[2],
                z0_tmp_93be2_32[3],
                z0_tmp_93be2_32[4],
                z0_tmp_93be2_32[5],
                z0_tmp_93be2_32[6],
                ((z0_tmp_93be2_32[7])
                    + ((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[0]))
                        - (z0_tmp_93be2_32[0]))
                        - (z2_tmp_93be2_33[0]))),
                ((z0_tmp_93be2_32[8])
                    + (((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[1]))
                        + ((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[0])))
                        - (z0_tmp_93be2_32[1]))
                        - (z2_tmp_93be2_33[1]))),
                ((z0_tmp_93be2_32[9])
                    + ((((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[2]))
                        + ((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[1])))
                        + ((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[0])))
                        - (z0_tmp_93be2_32[2]))
                        - (z2_tmp_93be2_33[2]))),
                ((z0_tmp_93be2_32[10])
                    + (((((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[3]))
                        + ((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[2])))
                        + ((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[1])))
                        + ((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[0])))
                        - (z0_tmp_93be2_32[3]))
                        - (z2_tmp_93be2_33[3]))),
                ((z0_tmp_93be2_32[11])
                    + ((((((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[4]))
                        + ((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[3])))
                        + ((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[2])))
                        + ((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[1])))
                        + ((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[0])))
                        - (z0_tmp_93be2_32[4]))
                        - (z2_tmp_93be2_33[4]))),
                ((z0_tmp_93be2_32[12])
                    + (((((((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[5]))
                        + ((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[4])))
                        + ((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[3])))
                        + ((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[2])))
                        + ((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[1])))
                        + ((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[0])))
                        - (z0_tmp_93be2_32[5]))
                        - (z2_tmp_93be2_33[5]))),
                ((((((((((x_sum_tmp_93be2_34[0]) * (y_sum_tmp_93be2_35[6]))
                    + ((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[5])))
                    + ((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[4])))
                    + ((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[3])))
                    + ((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[2])))
                    + ((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[1])))
                    + ((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[0])))
                    - (z0_tmp_93be2_32[6]))
                    - (z2_tmp_93be2_33[6])),
                ((z2_tmp_93be2_33[0])
                    + (((((((((x_sum_tmp_93be2_34[1]) * (y_sum_tmp_93be2_35[6]))
                        + ((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[5])))
                        + ((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[4])))
                        + ((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[3])))
                        + ((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[2])))
                        + ((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[1])))
                        - (z0_tmp_93be2_32[7]))
                        - (z2_tmp_93be2_33[7]))),
                ((z2_tmp_93be2_33[1])
                    + ((((((((x_sum_tmp_93be2_34[2]) * (y_sum_tmp_93be2_35[6]))
                        + ((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[5])))
                        + ((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[4])))
                        + ((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[3])))
                        + ((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[2])))
                        - (z0_tmp_93be2_32[8]))
                        - (z2_tmp_93be2_33[8]))),
                ((z2_tmp_93be2_33[2])
                    + (((((((x_sum_tmp_93be2_34[3]) * (y_sum_tmp_93be2_35[6]))
                        + ((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[5])))
                        + ((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[4])))
                        + ((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[3])))
                        - (z0_tmp_93be2_32[9]))
                        - (z2_tmp_93be2_33[9]))),
                ((z2_tmp_93be2_33[3])
                    + ((((((x_sum_tmp_93be2_34[4]) * (y_sum_tmp_93be2_35[6]))
                        + ((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[5])))
                        + ((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[4])))
                        - (z0_tmp_93be2_32[10]))
                        - (z2_tmp_93be2_33[10]))),
                ((z2_tmp_93be2_33[4])
                    + (((((x_sum_tmp_93be2_34[5]) * (y_sum_tmp_93be2_35[6]))
                        + ((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[5])))
                        - (z0_tmp_93be2_32[11]))
                        - (z2_tmp_93be2_33[11]))),
                ((z2_tmp_93be2_33[5])
                    + ((((x_sum_tmp_93be2_34[6]) * (y_sum_tmp_93be2_35[6]))
                        - (z0_tmp_93be2_32[12]))
                        - (z2_tmp_93be2_33[12]))),
                z2_tmp_93be2_33[6],
                z2_tmp_93be2_33[7],
                z2_tmp_93be2_33[8],
                z2_tmp_93be2_33[9],
                z2_tmp_93be2_33[10],
                z2_tmp_93be2_33[11],
                z2_tmp_93be2_33[12],
            ];

            let x_sum_tmp_93be2_37 = [
                ((op0_limb_0_col45) + (op0_limb_14_col59)),
                ((op0_limb_1_col46) + (op0_limb_15_col60)),
                ((op0_limb_2_col47) + (op0_limb_16_col61)),
                ((op0_limb_3_col48) + (op0_limb_17_col62)),
                ((op0_limb_4_col49) + (op0_limb_18_col63)),
                ((op0_limb_5_col50) + (op0_limb_19_col64)),
                ((op0_limb_6_col51) + (op0_limb_20_col65)),
                ((op0_limb_7_col52) + (op0_limb_21_col66)),
                ((op0_limb_8_col53) + (op0_limb_22_col67)),
                ((op0_limb_9_col54) + (op0_limb_23_col68)),
                ((op0_limb_10_col55) + (op0_limb_24_col69)),
                ((op0_limb_11_col56) + (op0_limb_25_col70)),
                ((op0_limb_12_col57) + (op0_limb_26_col71)),
                ((op0_limb_13_col58) + (op0_limb_27_col72)),
            ];
            let y_sum_tmp_93be2_38 = [
                ((op1_limb_0_col74) + (op1_limb_14_col88)),
                ((op1_limb_1_col75) + (op1_limb_15_col89)),
                ((op1_limb_2_col76) + (op1_limb_16_col90)),
                ((op1_limb_3_col77) + (op1_limb_17_col91)),
                ((op1_limb_4_col78) + (op1_limb_18_col92)),
                ((op1_limb_5_col79) + (op1_limb_19_col93)),
                ((op1_limb_6_col80) + (op1_limb_20_col94)),
                ((op1_limb_7_col81) + (op1_limb_21_col95)),
                ((op1_limb_8_col82) + (op1_limb_22_col96)),
                ((op1_limb_9_col83) + (op1_limb_23_col97)),
                ((op1_limb_10_col84) + (op1_limb_24_col98)),
                ((op1_limb_11_col85) + (op1_limb_25_col99)),
                ((op1_limb_12_col86) + (op1_limb_26_col100)),
                ((op1_limb_13_col87) + (op1_limb_27_col101)),
            ];

            // Single Karatsuba N 7.

            let z0_tmp_93be2_39 = [
                ((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[0])),
                (((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[1]))
                    + ((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[0]))),
                ((((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[2]))
                    + ((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[1])))
                    + ((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[0]))),
                (((((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[3]))
                    + ((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[2])))
                    + ((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[1])))
                    + ((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[0]))),
                ((((((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[4]))
                    + ((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[3])))
                    + ((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[2])))
                    + ((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[1])))
                    + ((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[0]))),
                (((((((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[5]))
                    + ((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[4])))
                    + ((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[3])))
                    + ((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[2])))
                    + ((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[1])))
                    + ((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[0]))),
                ((((((((x_sum_tmp_93be2_37[0]) * (y_sum_tmp_93be2_38[6]))
                    + ((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[5])))
                    + ((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[4])))
                    + ((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[3])))
                    + ((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[2])))
                    + ((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[1])))
                    + ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[0]))),
                (((((((x_sum_tmp_93be2_37[1]) * (y_sum_tmp_93be2_38[6]))
                    + ((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[5])))
                    + ((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[4])))
                    + ((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[3])))
                    + ((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[2])))
                    + ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[1]))),
                ((((((x_sum_tmp_93be2_37[2]) * (y_sum_tmp_93be2_38[6]))
                    + ((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[5])))
                    + ((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[4])))
                    + ((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[3])))
                    + ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[2]))),
                (((((x_sum_tmp_93be2_37[3]) * (y_sum_tmp_93be2_38[6]))
                    + ((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[5])))
                    + ((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[4])))
                    + ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[3]))),
                ((((x_sum_tmp_93be2_37[4]) * (y_sum_tmp_93be2_38[6]))
                    + ((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[5])))
                    + ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[4]))),
                (((x_sum_tmp_93be2_37[5]) * (y_sum_tmp_93be2_38[6]))
                    + ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[5]))),
                ((x_sum_tmp_93be2_37[6]) * (y_sum_tmp_93be2_38[6])),
            ];
            let z2_tmp_93be2_40 = [
                ((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[7])),
                (((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[8]))
                    + ((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[7]))),
                ((((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[9]))
                    + ((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[8])))
                    + ((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[7]))),
                (((((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[10]))
                    + ((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[9])))
                    + ((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[8])))
                    + ((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[7]))),
                ((((((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[11]))
                    + ((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[10])))
                    + ((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[9])))
                    + ((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[8])))
                    + ((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[7]))),
                (((((((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[12]))
                    + ((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[11])))
                    + ((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[10])))
                    + ((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[9])))
                    + ((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[8])))
                    + ((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[7]))),
                ((((((((x_sum_tmp_93be2_37[7]) * (y_sum_tmp_93be2_38[13]))
                    + ((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[12])))
                    + ((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[11])))
                    + ((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[10])))
                    + ((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[9])))
                    + ((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[8])))
                    + ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[7]))),
                (((((((x_sum_tmp_93be2_37[8]) * (y_sum_tmp_93be2_38[13]))
                    + ((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[12])))
                    + ((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[11])))
                    + ((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[10])))
                    + ((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[9])))
                    + ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[8]))),
                ((((((x_sum_tmp_93be2_37[9]) * (y_sum_tmp_93be2_38[13]))
                    + ((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[12])))
                    + ((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[11])))
                    + ((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[10])))
                    + ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[9]))),
                (((((x_sum_tmp_93be2_37[10]) * (y_sum_tmp_93be2_38[13]))
                    + ((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[12])))
                    + ((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[11])))
                    + ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[10]))),
                ((((x_sum_tmp_93be2_37[11]) * (y_sum_tmp_93be2_38[13]))
                    + ((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[12])))
                    + ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[11]))),
                (((x_sum_tmp_93be2_37[12]) * (y_sum_tmp_93be2_38[13]))
                    + ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[12]))),
                ((x_sum_tmp_93be2_37[13]) * (y_sum_tmp_93be2_38[13])),
            ];
            let x_sum_tmp_93be2_41 = [
                ((x_sum_tmp_93be2_37[0]) + (x_sum_tmp_93be2_37[7])),
                ((x_sum_tmp_93be2_37[1]) + (x_sum_tmp_93be2_37[8])),
                ((x_sum_tmp_93be2_37[2]) + (x_sum_tmp_93be2_37[9])),
                ((x_sum_tmp_93be2_37[3]) + (x_sum_tmp_93be2_37[10])),
                ((x_sum_tmp_93be2_37[4]) + (x_sum_tmp_93be2_37[11])),
                ((x_sum_tmp_93be2_37[5]) + (x_sum_tmp_93be2_37[12])),
                ((x_sum_tmp_93be2_37[6]) + (x_sum_tmp_93be2_37[13])),
            ];
            let y_sum_tmp_93be2_42 = [
                ((y_sum_tmp_93be2_38[0]) + (y_sum_tmp_93be2_38[7])),
                ((y_sum_tmp_93be2_38[1]) + (y_sum_tmp_93be2_38[8])),
                ((y_sum_tmp_93be2_38[2]) + (y_sum_tmp_93be2_38[9])),
                ((y_sum_tmp_93be2_38[3]) + (y_sum_tmp_93be2_38[10])),
                ((y_sum_tmp_93be2_38[4]) + (y_sum_tmp_93be2_38[11])),
                ((y_sum_tmp_93be2_38[5]) + (y_sum_tmp_93be2_38[12])),
                ((y_sum_tmp_93be2_38[6]) + (y_sum_tmp_93be2_38[13])),
            ];
            let single_karatsuba_n_7_output_tmp_93be2_43 = [
                z0_tmp_93be2_39[0],
                z0_tmp_93be2_39[1],
                z0_tmp_93be2_39[2],
                z0_tmp_93be2_39[3],
                z0_tmp_93be2_39[4],
                z0_tmp_93be2_39[5],
                z0_tmp_93be2_39[6],
                ((z0_tmp_93be2_39[7])
                    + ((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[0]))
                        - (z0_tmp_93be2_39[0]))
                        - (z2_tmp_93be2_40[0]))),
                ((z0_tmp_93be2_39[8])
                    + (((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[1]))
                        + ((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[0])))
                        - (z0_tmp_93be2_39[1]))
                        - (z2_tmp_93be2_40[1]))),
                ((z0_tmp_93be2_39[9])
                    + ((((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[2]))
                        + ((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[1])))
                        + ((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[0])))
                        - (z0_tmp_93be2_39[2]))
                        - (z2_tmp_93be2_40[2]))),
                ((z0_tmp_93be2_39[10])
                    + (((((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[3]))
                        + ((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[2])))
                        + ((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[1])))
                        + ((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[0])))
                        - (z0_tmp_93be2_39[3]))
                        - (z2_tmp_93be2_40[3]))),
                ((z0_tmp_93be2_39[11])
                    + ((((((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[4]))
                        + ((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[3])))
                        + ((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[2])))
                        + ((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[1])))
                        + ((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[0])))
                        - (z0_tmp_93be2_39[4]))
                        - (z2_tmp_93be2_40[4]))),
                ((z0_tmp_93be2_39[12])
                    + (((((((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[5]))
                        + ((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[4])))
                        + ((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[3])))
                        + ((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[2])))
                        + ((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[1])))
                        + ((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[0])))
                        - (z0_tmp_93be2_39[5]))
                        - (z2_tmp_93be2_40[5]))),
                ((((((((((x_sum_tmp_93be2_41[0]) * (y_sum_tmp_93be2_42[6]))
                    + ((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[5])))
                    + ((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[4])))
                    + ((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[3])))
                    + ((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[2])))
                    + ((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[1])))
                    + ((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[0])))
                    - (z0_tmp_93be2_39[6]))
                    - (z2_tmp_93be2_40[6])),
                ((z2_tmp_93be2_40[0])
                    + (((((((((x_sum_tmp_93be2_41[1]) * (y_sum_tmp_93be2_42[6]))
                        + ((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[5])))
                        + ((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[4])))
                        + ((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[3])))
                        + ((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[2])))
                        + ((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[1])))
                        - (z0_tmp_93be2_39[7]))
                        - (z2_tmp_93be2_40[7]))),
                ((z2_tmp_93be2_40[1])
                    + ((((((((x_sum_tmp_93be2_41[2]) * (y_sum_tmp_93be2_42[6]))
                        + ((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[5])))
                        + ((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[4])))
                        + ((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[3])))
                        + ((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[2])))
                        - (z0_tmp_93be2_39[8]))
                        - (z2_tmp_93be2_40[8]))),
                ((z2_tmp_93be2_40[2])
                    + (((((((x_sum_tmp_93be2_41[3]) * (y_sum_tmp_93be2_42[6]))
                        + ((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[5])))
                        + ((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[4])))
                        + ((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[3])))
                        - (z0_tmp_93be2_39[9]))
                        - (z2_tmp_93be2_40[9]))),
                ((z2_tmp_93be2_40[3])
                    + ((((((x_sum_tmp_93be2_41[4]) * (y_sum_tmp_93be2_42[6]))
                        + ((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[5])))
                        + ((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[4])))
                        - (z0_tmp_93be2_39[10]))
                        - (z2_tmp_93be2_40[10]))),
                ((z2_tmp_93be2_40[4])
                    + (((((x_sum_tmp_93be2_41[5]) * (y_sum_tmp_93be2_42[6]))
                        + ((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[5])))
                        - (z0_tmp_93be2_39[11]))
                        - (z2_tmp_93be2_40[11]))),
                ((z2_tmp_93be2_40[5])
                    + ((((x_sum_tmp_93be2_41[6]) * (y_sum_tmp_93be2_42[6]))
                        - (z0_tmp_93be2_39[12]))
                        - (z2_tmp_93be2_40[12]))),
                z2_tmp_93be2_40[6],
                z2_tmp_93be2_40[7],
                z2_tmp_93be2_40[8],
                z2_tmp_93be2_40[9],
                z2_tmp_93be2_40[10],
                z2_tmp_93be2_40[11],
                z2_tmp_93be2_40[12],
            ];

            let double_karatsuba_f0fc6_output_tmp_93be2_44 = [
                single_karatsuba_n_7_output_tmp_93be2_31[0],
                single_karatsuba_n_7_output_tmp_93be2_31[1],
                single_karatsuba_n_7_output_tmp_93be2_31[2],
                single_karatsuba_n_7_output_tmp_93be2_31[3],
                single_karatsuba_n_7_output_tmp_93be2_31[4],
                single_karatsuba_n_7_output_tmp_93be2_31[5],
                single_karatsuba_n_7_output_tmp_93be2_31[6],
                single_karatsuba_n_7_output_tmp_93be2_31[7],
                single_karatsuba_n_7_output_tmp_93be2_31[8],
                single_karatsuba_n_7_output_tmp_93be2_31[9],
                single_karatsuba_n_7_output_tmp_93be2_31[10],
                single_karatsuba_n_7_output_tmp_93be2_31[11],
                single_karatsuba_n_7_output_tmp_93be2_31[12],
                single_karatsuba_n_7_output_tmp_93be2_31[13],
                ((single_karatsuba_n_7_output_tmp_93be2_31[14])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[0])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[0]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[0]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[15])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[1])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[1]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[1]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[16])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[2])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[2]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[2]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[17])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[3])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[3]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[3]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[18])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[4])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[4]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[4]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[19])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[5])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[5]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[5]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[20])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[6])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[6]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[6]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[21])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[7])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[7]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[7]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[22])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[8])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[8]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[8]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[23])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[9])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[9]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[9]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[24])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[10])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[10]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[10]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[25])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[11])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[11]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[11]))),
                ((single_karatsuba_n_7_output_tmp_93be2_31[26])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[12])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[12]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[12]))),
                (((single_karatsuba_n_7_output_tmp_93be2_43[13])
                    - (single_karatsuba_n_7_output_tmp_93be2_31[13]))
                    - (single_karatsuba_n_7_output_tmp_93be2_36[13])),
                ((single_karatsuba_n_7_output_tmp_93be2_36[0])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[14])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[14]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[14]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[1])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[15])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[15]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[15]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[2])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[16])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[16]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[16]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[3])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[17])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[17]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[17]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[4])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[18])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[18]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[18]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[5])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[19])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[19]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[19]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[6])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[20])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[20]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[20]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[7])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[21])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[21]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[21]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[8])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[22])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[22]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[22]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[9])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[23])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[23]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[23]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[10])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[24])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[24]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[24]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[11])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[25])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[25]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[25]))),
                ((single_karatsuba_n_7_output_tmp_93be2_36[12])
                    + (((single_karatsuba_n_7_output_tmp_93be2_43[26])
                        - (single_karatsuba_n_7_output_tmp_93be2_31[26]))
                        - (single_karatsuba_n_7_output_tmp_93be2_36[26]))),
                single_karatsuba_n_7_output_tmp_93be2_36[13],
                single_karatsuba_n_7_output_tmp_93be2_36[14],
                single_karatsuba_n_7_output_tmp_93be2_36[15],
                single_karatsuba_n_7_output_tmp_93be2_36[16],
                single_karatsuba_n_7_output_tmp_93be2_36[17],
                single_karatsuba_n_7_output_tmp_93be2_36[18],
                single_karatsuba_n_7_output_tmp_93be2_36[19],
                single_karatsuba_n_7_output_tmp_93be2_36[20],
                single_karatsuba_n_7_output_tmp_93be2_36[21],
                single_karatsuba_n_7_output_tmp_93be2_36[22],
                single_karatsuba_n_7_output_tmp_93be2_36[23],
                single_karatsuba_n_7_output_tmp_93be2_36[24],
                single_karatsuba_n_7_output_tmp_93be2_36[25],
                single_karatsuba_n_7_output_tmp_93be2_36[26],
            ];

            let conv_tmp_93be2_45 = [
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[0]) - (dst_limb_0_col16)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[1]) - (dst_limb_1_col17)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[2]) - (dst_limb_2_col18)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[3]) - (dst_limb_3_col19)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[4]) - (dst_limb_4_col20)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[5]) - (dst_limb_5_col21)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[6]) - (dst_limb_6_col22)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[7]) - (dst_limb_7_col23)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[8]) - (dst_limb_8_col24)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[9]) - (dst_limb_9_col25)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[10]) - (dst_limb_10_col26)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[11]) - (dst_limb_11_col27)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[12]) - (dst_limb_12_col28)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[13]) - (dst_limb_13_col29)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[14]) - (dst_limb_14_col30)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[15]) - (dst_limb_15_col31)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[16]) - (dst_limb_16_col32)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[17]) - (dst_limb_17_col33)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[18]) - (dst_limb_18_col34)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[19]) - (dst_limb_19_col35)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[20]) - (dst_limb_20_col36)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[21]) - (dst_limb_21_col37)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[22]) - (dst_limb_22_col38)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[23]) - (dst_limb_23_col39)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[24]) - (dst_limb_24_col40)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[25]) - (dst_limb_25_col41)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[26]) - (dst_limb_26_col42)),
                ((double_karatsuba_f0fc6_output_tmp_93be2_44[27]) - (dst_limb_27_col43)),
                double_karatsuba_f0fc6_output_tmp_93be2_44[28],
                double_karatsuba_f0fc6_output_tmp_93be2_44[29],
                double_karatsuba_f0fc6_output_tmp_93be2_44[30],
                double_karatsuba_f0fc6_output_tmp_93be2_44[31],
                double_karatsuba_f0fc6_output_tmp_93be2_44[32],
                double_karatsuba_f0fc6_output_tmp_93be2_44[33],
                double_karatsuba_f0fc6_output_tmp_93be2_44[34],
                double_karatsuba_f0fc6_output_tmp_93be2_44[35],
                double_karatsuba_f0fc6_output_tmp_93be2_44[36],
                double_karatsuba_f0fc6_output_tmp_93be2_44[37],
                double_karatsuba_f0fc6_output_tmp_93be2_44[38],
                double_karatsuba_f0fc6_output_tmp_93be2_44[39],
                double_karatsuba_f0fc6_output_tmp_93be2_44[40],
                double_karatsuba_f0fc6_output_tmp_93be2_44[41],
                double_karatsuba_f0fc6_output_tmp_93be2_44[42],
                double_karatsuba_f0fc6_output_tmp_93be2_44[43],
                double_karatsuba_f0fc6_output_tmp_93be2_44[44],
                double_karatsuba_f0fc6_output_tmp_93be2_44[45],
                double_karatsuba_f0fc6_output_tmp_93be2_44[46],
                double_karatsuba_f0fc6_output_tmp_93be2_44[47],
                double_karatsuba_f0fc6_output_tmp_93be2_44[48],
                double_karatsuba_f0fc6_output_tmp_93be2_44[49],
                double_karatsuba_f0fc6_output_tmp_93be2_44[50],
                double_karatsuba_f0fc6_output_tmp_93be2_44[51],
                double_karatsuba_f0fc6_output_tmp_93be2_44[52],
                double_karatsuba_f0fc6_output_tmp_93be2_44[53],
                double_karatsuba_f0fc6_output_tmp_93be2_44[54],
            ];
            let conv_mod_tmp_93be2_46 = [
                ((((M31_32) * (conv_tmp_93be2_45[0])) - ((M31_4) * (conv_tmp_93be2_45[21])))
                    + ((M31_8) * (conv_tmp_93be2_45[49]))),
                ((((conv_tmp_93be2_45[0]) + ((M31_32) * (conv_tmp_93be2_45[1])))
                    - ((M31_4) * (conv_tmp_93be2_45[22])))
                    + ((M31_8) * (conv_tmp_93be2_45[50]))),
                ((((conv_tmp_93be2_45[1]) + ((M31_32) * (conv_tmp_93be2_45[2])))
                    - ((M31_4) * (conv_tmp_93be2_45[23])))
                    + ((M31_8) * (conv_tmp_93be2_45[51]))),
                ((((conv_tmp_93be2_45[2]) + ((M31_32) * (conv_tmp_93be2_45[3])))
                    - ((M31_4) * (conv_tmp_93be2_45[24])))
                    + ((M31_8) * (conv_tmp_93be2_45[52]))),
                ((((conv_tmp_93be2_45[3]) + ((M31_32) * (conv_tmp_93be2_45[4])))
                    - ((M31_4) * (conv_tmp_93be2_45[25])))
                    + ((M31_8) * (conv_tmp_93be2_45[53]))),
                ((((conv_tmp_93be2_45[4]) + ((M31_32) * (conv_tmp_93be2_45[5])))
                    - ((M31_4) * (conv_tmp_93be2_45[26])))
                    + ((M31_8) * (conv_tmp_93be2_45[54]))),
                (((conv_tmp_93be2_45[5]) + ((M31_32) * (conv_tmp_93be2_45[6])))
                    - ((M31_4) * (conv_tmp_93be2_45[27]))),
                (((((M31_2) * (conv_tmp_93be2_45[0])) + (conv_tmp_93be2_45[6]))
                    + ((M31_32) * (conv_tmp_93be2_45[7])))
                    - ((M31_4) * (conv_tmp_93be2_45[28]))),
                (((((M31_2) * (conv_tmp_93be2_45[1])) + (conv_tmp_93be2_45[7]))
                    + ((M31_32) * (conv_tmp_93be2_45[8])))
                    - ((M31_4) * (conv_tmp_93be2_45[29]))),
                (((((M31_2) * (conv_tmp_93be2_45[2])) + (conv_tmp_93be2_45[8]))
                    + ((M31_32) * (conv_tmp_93be2_45[9])))
                    - ((M31_4) * (conv_tmp_93be2_45[30]))),
                (((((M31_2) * (conv_tmp_93be2_45[3])) + (conv_tmp_93be2_45[9]))
                    + ((M31_32) * (conv_tmp_93be2_45[10])))
                    - ((M31_4) * (conv_tmp_93be2_45[31]))),
                (((((M31_2) * (conv_tmp_93be2_45[4])) + (conv_tmp_93be2_45[10]))
                    + ((M31_32) * (conv_tmp_93be2_45[11])))
                    - ((M31_4) * (conv_tmp_93be2_45[32]))),
                (((((M31_2) * (conv_tmp_93be2_45[5])) + (conv_tmp_93be2_45[11]))
                    + ((M31_32) * (conv_tmp_93be2_45[12])))
                    - ((M31_4) * (conv_tmp_93be2_45[33]))),
                (((((M31_2) * (conv_tmp_93be2_45[6])) + (conv_tmp_93be2_45[12]))
                    + ((M31_32) * (conv_tmp_93be2_45[13])))
                    - ((M31_4) * (conv_tmp_93be2_45[34]))),
                (((((M31_2) * (conv_tmp_93be2_45[7])) + (conv_tmp_93be2_45[13]))
                    + ((M31_32) * (conv_tmp_93be2_45[14])))
                    - ((M31_4) * (conv_tmp_93be2_45[35]))),
                (((((M31_2) * (conv_tmp_93be2_45[8])) + (conv_tmp_93be2_45[14]))
                    + ((M31_32) * (conv_tmp_93be2_45[15])))
                    - ((M31_4) * (conv_tmp_93be2_45[36]))),
                (((((M31_2) * (conv_tmp_93be2_45[9])) + (conv_tmp_93be2_45[15]))
                    + ((M31_32) * (conv_tmp_93be2_45[16])))
                    - ((M31_4) * (conv_tmp_93be2_45[37]))),
                (((((M31_2) * (conv_tmp_93be2_45[10])) + (conv_tmp_93be2_45[16]))
                    + ((M31_32) * (conv_tmp_93be2_45[17])))
                    - ((M31_4) * (conv_tmp_93be2_45[38]))),
                (((((M31_2) * (conv_tmp_93be2_45[11])) + (conv_tmp_93be2_45[17]))
                    + ((M31_32) * (conv_tmp_93be2_45[18])))
                    - ((M31_4) * (conv_tmp_93be2_45[39]))),
                (((((M31_2) * (conv_tmp_93be2_45[12])) + (conv_tmp_93be2_45[18]))
                    + ((M31_32) * (conv_tmp_93be2_45[19])))
                    - ((M31_4) * (conv_tmp_93be2_45[40]))),
                (((((M31_2) * (conv_tmp_93be2_45[13])) + (conv_tmp_93be2_45[19]))
                    + ((M31_32) * (conv_tmp_93be2_45[20])))
                    - ((M31_4) * (conv_tmp_93be2_45[41]))),
                (((((M31_2) * (conv_tmp_93be2_45[14])) + (conv_tmp_93be2_45[20]))
                    - ((M31_4) * (conv_tmp_93be2_45[42])))
                    + ((M31_64) * (conv_tmp_93be2_45[49]))),
                (((((M31_2) * (conv_tmp_93be2_45[15])) - ((M31_4) * (conv_tmp_93be2_45[43])))
                    + ((M31_2) * (conv_tmp_93be2_45[49])))
                    + ((M31_64) * (conv_tmp_93be2_45[50]))),
                (((((M31_2) * (conv_tmp_93be2_45[16])) - ((M31_4) * (conv_tmp_93be2_45[44])))
                    + ((M31_2) * (conv_tmp_93be2_45[50])))
                    + ((M31_64) * (conv_tmp_93be2_45[51]))),
                (((((M31_2) * (conv_tmp_93be2_45[17])) - ((M31_4) * (conv_tmp_93be2_45[45])))
                    + ((M31_2) * (conv_tmp_93be2_45[51])))
                    + ((M31_64) * (conv_tmp_93be2_45[52]))),
                (((((M31_2) * (conv_tmp_93be2_45[18])) - ((M31_4) * (conv_tmp_93be2_45[46])))
                    + ((M31_2) * (conv_tmp_93be2_45[52])))
                    + ((M31_64) * (conv_tmp_93be2_45[53]))),
                (((((M31_2) * (conv_tmp_93be2_45[19])) - ((M31_4) * (conv_tmp_93be2_45[47])))
                    + ((M31_2) * (conv_tmp_93be2_45[53])))
                    + ((M31_64) * (conv_tmp_93be2_45[54]))),
                ((((M31_2) * (conv_tmp_93be2_45[20])) - ((M31_4) * (conv_tmp_93be2_45[48])))
                    + ((M31_2) * (conv_tmp_93be2_45[54]))),
            ];
            let k_mod_2_18_biased_tmp_93be2_47 =
                ((((PackedUInt32::from_m31(((conv_mod_tmp_93be2_46[0]) + (M31_134217728))))
                    + (((PackedUInt32::from_m31(
                        ((conv_mod_tmp_93be2_46[1]) + (M31_134217728)),
                    )) & (UInt32_511))
                        << (UInt32_9)))
                    + (UInt32_131072))
                    & (UInt32_262143));
            let k_col102 = ((k_mod_2_18_biased_tmp_93be2_47.low().as_m31())
                + (((k_mod_2_18_biased_tmp_93be2_47.high().as_m31()) - (M31_2)) * (M31_65536)));
            *row[102] = k_col102;
            *sub_component_inputs.range_check_20[0] = [((k_col102) + (M31_524288))];
            *lookup_data.range_check_20_7 = [M31_1410849886, ((k_col102) + (M31_524288))];
            let carry_0_col103 = (((conv_mod_tmp_93be2_46[0]) - (k_col102)) * (M31_4194304));
            *row[103] = carry_0_col103;
            *sub_component_inputs.range_check_20_b[0] = [((carry_0_col103) + (M31_524288))];
            *lookup_data.range_check_20_b_8 = [M31_514232941, ((carry_0_col103) + (M31_524288))];
            let carry_1_col104 = (((conv_mod_tmp_93be2_46[1]) + (carry_0_col103)) * (M31_4194304));
            *row[104] = carry_1_col104;
            *sub_component_inputs.range_check_20_c[0] = [((carry_1_col104) + (M31_524288))];
            *lookup_data.range_check_20_c_9 = [M31_531010560, ((carry_1_col104) + (M31_524288))];
            let carry_2_col105 = (((conv_mod_tmp_93be2_46[2]) + (carry_1_col104)) * (M31_4194304));
            *row[105] = carry_2_col105;
            *sub_component_inputs.range_check_20_d[0] = [((carry_2_col105) + (M31_524288))];
            *lookup_data.range_check_20_d_10 = [M31_480677703, ((carry_2_col105) + (M31_524288))];
            let carry_3_col106 = (((conv_mod_tmp_93be2_46[3]) + (carry_2_col105)) * (M31_4194304));
            *row[106] = carry_3_col106;
            *sub_component_inputs.range_check_20_e[0] = [((carry_3_col106) + (M31_524288))];
            *lookup_data.range_check_20_e_11 = [M31_497455322, ((carry_3_col106) + (M31_524288))];
            let carry_4_col107 = (((conv_mod_tmp_93be2_46[4]) + (carry_3_col106)) * (M31_4194304));
            *row[107] = carry_4_col107;
            *sub_component_inputs.range_check_20_f[0] = [((carry_4_col107) + (M31_524288))];
            *lookup_data.range_check_20_f_12 = [M31_447122465, ((carry_4_col107) + (M31_524288))];
            let carry_5_col108 = (((conv_mod_tmp_93be2_46[5]) + (carry_4_col107)) * (M31_4194304));
            *row[108] = carry_5_col108;
            *sub_component_inputs.range_check_20_g[0] = [((carry_5_col108) + (M31_524288))];
            *lookup_data.range_check_20_g_13 = [M31_463900084, ((carry_5_col108) + (M31_524288))];
            let carry_6_col109 = (((conv_mod_tmp_93be2_46[6]) + (carry_5_col108)) * (M31_4194304));
            *row[109] = carry_6_col109;
            *sub_component_inputs.range_check_20_h[0] = [((carry_6_col109) + (M31_524288))];
            *lookup_data.range_check_20_h_14 = [M31_682009131, ((carry_6_col109) + (M31_524288))];
            let carry_7_col110 = (((conv_mod_tmp_93be2_46[7]) + (carry_6_col109)) * (M31_4194304));
            *row[110] = carry_7_col110;
            *sub_component_inputs.range_check_20[1] = [((carry_7_col110) + (M31_524288))];
            *lookup_data.range_check_20_15 = [M31_1410849886, ((carry_7_col110) + (M31_524288))];
            let carry_8_col111 = (((conv_mod_tmp_93be2_46[8]) + (carry_7_col110)) * (M31_4194304));
            *row[111] = carry_8_col111;
            *sub_component_inputs.range_check_20_b[1] = [((carry_8_col111) + (M31_524288))];
            *lookup_data.range_check_20_b_16 = [M31_514232941, ((carry_8_col111) + (M31_524288))];
            let carry_9_col112 = (((conv_mod_tmp_93be2_46[9]) + (carry_8_col111)) * (M31_4194304));
            *row[112] = carry_9_col112;
            *sub_component_inputs.range_check_20_c[1] = [((carry_9_col112) + (M31_524288))];
            *lookup_data.range_check_20_c_17 = [M31_531010560, ((carry_9_col112) + (M31_524288))];
            let carry_10_col113 =
                (((conv_mod_tmp_93be2_46[10]) + (carry_9_col112)) * (M31_4194304));
            *row[113] = carry_10_col113;
            *sub_component_inputs.range_check_20_d[1] = [((carry_10_col113) + (M31_524288))];
            *lookup_data.range_check_20_d_18 = [M31_480677703, ((carry_10_col113) + (M31_524288))];
            let carry_11_col114 =
                (((conv_mod_tmp_93be2_46[11]) + (carry_10_col113)) * (M31_4194304));
            *row[114] = carry_11_col114;
            *sub_component_inputs.range_check_20_e[1] = [((carry_11_col114) + (M31_524288))];
            *lookup_data.range_check_20_e_19 = [M31_497455322, ((carry_11_col114) + (M31_524288))];
            let carry_12_col115 =
                (((conv_mod_tmp_93be2_46[12]) + (carry_11_col114)) * (M31_4194304));
            *row[115] = carry_12_col115;
            *sub_component_inputs.range_check_20_f[1] = [((carry_12_col115) + (M31_524288))];
            *lookup_data.range_check_20_f_20 = [M31_447122465, ((carry_12_col115) + (M31_524288))];
            let carry_13_col116 =
                (((conv_mod_tmp_93be2_46[13]) + (carry_12_col115)) * (M31_4194304));
            *row[116] = carry_13_col116;
            *sub_component_inputs.range_check_20_g[1] = [((carry_13_col116) + (M31_524288))];
            *lookup_data.range_check_20_g_21 = [M31_463900084, ((carry_13_col116) + (M31_524288))];
            let carry_14_col117 =
                (((conv_mod_tmp_93be2_46[14]) + (carry_13_col116)) * (M31_4194304));
            *row[117] = carry_14_col117;
            *sub_component_inputs.range_check_20_h[1] = [((carry_14_col117) + (M31_524288))];
            *lookup_data.range_check_20_h_22 = [M31_682009131, ((carry_14_col117) + (M31_524288))];
            let carry_15_col118 =
                (((conv_mod_tmp_93be2_46[15]) + (carry_14_col117)) * (M31_4194304));
            *row[118] = carry_15_col118;
            *sub_component_inputs.range_check_20[2] = [((carry_15_col118) + (M31_524288))];
            *lookup_data.range_check_20_23 = [M31_1410849886, ((carry_15_col118) + (M31_524288))];
            let carry_16_col119 =
                (((conv_mod_tmp_93be2_46[16]) + (carry_15_col118)) * (M31_4194304));
            *row[119] = carry_16_col119;
            *sub_component_inputs.range_check_20_b[2] = [((carry_16_col119) + (M31_524288))];
            *lookup_data.range_check_20_b_24 = [M31_514232941, ((carry_16_col119) + (M31_524288))];
            let carry_17_col120 =
                (((conv_mod_tmp_93be2_46[17]) + (carry_16_col119)) * (M31_4194304));
            *row[120] = carry_17_col120;
            *sub_component_inputs.range_check_20_c[2] = [((carry_17_col120) + (M31_524288))];
            *lookup_data.range_check_20_c_25 = [M31_531010560, ((carry_17_col120) + (M31_524288))];
            let carry_18_col121 =
                (((conv_mod_tmp_93be2_46[18]) + (carry_17_col120)) * (M31_4194304));
            *row[121] = carry_18_col121;
            *sub_component_inputs.range_check_20_d[2] = [((carry_18_col121) + (M31_524288))];
            *lookup_data.range_check_20_d_26 = [M31_480677703, ((carry_18_col121) + (M31_524288))];
            let carry_19_col122 =
                (((conv_mod_tmp_93be2_46[19]) + (carry_18_col121)) * (M31_4194304));
            *row[122] = carry_19_col122;
            *sub_component_inputs.range_check_20_e[2] = [((carry_19_col122) + (M31_524288))];
            *lookup_data.range_check_20_e_27 = [M31_497455322, ((carry_19_col122) + (M31_524288))];
            let carry_20_col123 =
                (((conv_mod_tmp_93be2_46[20]) + (carry_19_col122)) * (M31_4194304));
            *row[123] = carry_20_col123;
            *sub_component_inputs.range_check_20_f[2] = [((carry_20_col123) + (M31_524288))];
            *lookup_data.range_check_20_f_28 = [M31_447122465, ((carry_20_col123) + (M31_524288))];
            let carry_21_col124 = ((((conv_mod_tmp_93be2_46[21]) - ((M31_136) * (k_col102)))
                + (carry_20_col123))
                * (M31_4194304));
            *row[124] = carry_21_col124;
            *sub_component_inputs.range_check_20_g[2] = [((carry_21_col124) + (M31_524288))];
            *lookup_data.range_check_20_g_29 = [M31_463900084, ((carry_21_col124) + (M31_524288))];
            let carry_22_col125 =
                (((conv_mod_tmp_93be2_46[22]) + (carry_21_col124)) * (M31_4194304));
            *row[125] = carry_22_col125;
            *sub_component_inputs.range_check_20_h[2] = [((carry_22_col125) + (M31_524288))];
            *lookup_data.range_check_20_h_30 = [M31_682009131, ((carry_22_col125) + (M31_524288))];
            let carry_23_col126 =
                (((conv_mod_tmp_93be2_46[23]) + (carry_22_col125)) * (M31_4194304));
            *row[126] = carry_23_col126;
            *sub_component_inputs.range_check_20[3] = [((carry_23_col126) + (M31_524288))];
            *lookup_data.range_check_20_31 = [M31_1410849886, ((carry_23_col126) + (M31_524288))];
            let carry_24_col127 =
                (((conv_mod_tmp_93be2_46[24]) + (carry_23_col126)) * (M31_4194304));
            *row[127] = carry_24_col127;
            *sub_component_inputs.range_check_20_b[3] = [((carry_24_col127) + (M31_524288))];
            *lookup_data.range_check_20_b_32 = [M31_514232941, ((carry_24_col127) + (M31_524288))];
            let carry_25_col128 =
                (((conv_mod_tmp_93be2_46[25]) + (carry_24_col127)) * (M31_4194304));
            *row[128] = carry_25_col128;
            *sub_component_inputs.range_check_20_c[3] = [((carry_25_col128) + (M31_524288))];
            *lookup_data.range_check_20_c_33 = [M31_531010560, ((carry_25_col128) + (M31_524288))];
            let carry_26_col129 =
                (((conv_mod_tmp_93be2_46[26]) + (carry_25_col128)) * (M31_4194304));
            *row[129] = carry_26_col129;
            *sub_component_inputs.range_check_20_d[3] = [((carry_26_col129) + (M31_524288))];
            *lookup_data.range_check_20_d_34 = [M31_480677703, ((carry_26_col129) + (M31_524288))];

            *lookup_data.opcodes_35 = [M31_428564188, input_pc_col1, input_ap_col2, input_fp_col3];
            *lookup_data.opcodes_36 = [
                M31_428564188,
                (((input_pc_col1) + (M31_1)) + (op1_imm_col9)),
                ((input_ap_col2) + (ap_update_add_1_col11)),
                input_fp_col3,
            ];
            *lookup_data.mults_0 = enabler_col0;
        });

    (trace, lookup_data, sub_component_inputs)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    verify_instruction_0: Vec<[PackedM31; 8]>,
    memory_address_to_id_1: Vec<[PackedM31; 3]>,
    memory_id_to_big_2: Vec<[PackedM31; 30]>,
    memory_address_to_id_3: Vec<[PackedM31; 3]>,
    memory_id_to_big_4: Vec<[PackedM31; 30]>,
    memory_address_to_id_5: Vec<[PackedM31; 3]>,
    memory_id_to_big_6: Vec<[PackedM31; 30]>,
    range_check_20_7: Vec<[PackedM31; 2]>,
    range_check_20_b_8: Vec<[PackedM31; 2]>,
    range_check_20_c_9: Vec<[PackedM31; 2]>,
    range_check_20_d_10: Vec<[PackedM31; 2]>,
    range_check_20_e_11: Vec<[PackedM31; 2]>,
    range_check_20_f_12: Vec<[PackedM31; 2]>,
    range_check_20_g_13: Vec<[PackedM31; 2]>,
    range_check_20_h_14: Vec<[PackedM31; 2]>,
    range_check_20_15: Vec<[PackedM31; 2]>,
    range_check_20_b_16: Vec<[PackedM31; 2]>,
    range_check_20_c_17: Vec<[PackedM31; 2]>,
    range_check_20_d_18: Vec<[PackedM31; 2]>,
    range_check_20_e_19: Vec<[PackedM31; 2]>,
    range_check_20_f_20: Vec<[PackedM31; 2]>,
    range_check_20_g_21: Vec<[PackedM31; 2]>,
    range_check_20_h_22: Vec<[PackedM31; 2]>,
    range_check_20_23: Vec<[PackedM31; 2]>,
    range_check_20_b_24: Vec<[PackedM31; 2]>,
    range_check_20_c_25: Vec<[PackedM31; 2]>,
    range_check_20_d_26: Vec<[PackedM31; 2]>,
    range_check_20_e_27: Vec<[PackedM31; 2]>,
    range_check_20_f_28: Vec<[PackedM31; 2]>,
    range_check_20_g_29: Vec<[PackedM31; 2]>,
    range_check_20_h_30: Vec<[PackedM31; 2]>,
    range_check_20_31: Vec<[PackedM31; 2]>,
    range_check_20_b_32: Vec<[PackedM31; 2]>,
    range_check_20_c_33: Vec<[PackedM31; 2]>,
    range_check_20_d_34: Vec<[PackedM31; 2]>,
    opcodes_35: Vec<[PackedM31; 4]>,
    opcodes_36: Vec<[PackedM31; 4]>,
    mults_0: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    log_size: u32,
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(self.log_size) };

        // Sum logup terms in pairs.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_instruction_0,
            &self.lookup_data.memory_address_to_id_1,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_2,
            &self.lookup_data.memory_address_to_id_3,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_4,
            &self.lookup_data.memory_address_to_id_5,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.memory_id_to_big_6,
            &self.lookup_data.range_check_20_7,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_b_8,
            &self.lookup_data.range_check_20_c_9,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_d_10,
            &self.lookup_data.range_check_20_e_11,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_f_12,
            &self.lookup_data.range_check_20_g_13,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_h_14,
            &self.lookup_data.range_check_20_15,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_b_16,
            &self.lookup_data.range_check_20_c_17,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_d_18,
            &self.lookup_data.range_check_20_e_19,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_f_20,
            &self.lookup_data.range_check_20_g_21,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_h_22,
            &self.lookup_data.range_check_20_23,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_b_24,
            &self.lookup_data.range_check_20_c_25,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_d_26,
            &self.lookup_data.range_check_20_e_27,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_f_28,
            &self.lookup_data.range_check_20_g_29,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_h_30,
            &self.lookup_data.range_check_20_31,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_b_32,
            &self.lookup_data.range_check_20_c_33,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.range_check_20_d_34,
            &self.lookup_data.opcodes_35,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        // Sum last logup term.
        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(), &self.lookup_data.opcodes_36, self.lookup_data.mults_0)
            .into_par_iter()
            .for_each(|(writer, values, mult)| {
                let denom = common_lookup_elements.combine(values);
                writer.write_frac((-mult).into(), denom);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
