pub mod add_ap_opcode;
pub mod add_mod_builtin;
pub mod add_opcode;
pub mod add_opcode_small;
pub mod assert_eq_opcode;
pub mod assert_eq_opcode_double_deref;
pub mod assert_eq_opcode_imm;
pub mod bitwise_builtin;
pub mod blake_compress_opcode;
pub mod blake_g;
pub mod blake_round;
pub mod blake_round_sigma;
pub mod call_opcode_abs;
pub mod call_opcode_rel_imm;
pub mod cube_252;
pub mod ec_op_builtin;
pub mod generic_opcode;
pub mod jnz_opcode_non_taken;
pub mod jnz_opcode_taken;
pub mod jump_opcode_abs;
pub mod jump_opcode_double_deref;
pub mod jump_opcode_rel;
pub mod jump_opcode_rel_imm;
pub mod memory_address_to_id;
pub mod memory_id_to_big;
pub mod memory_id_to_small;
pub mod mul_mod_builtin;
pub mod mul_opcode;
pub mod mul_opcode_small;
pub mod partial_ec_mul_generic;
pub mod partial_ec_mul_window_bits_18;
pub mod partial_ec_mul_window_bits_9;
pub mod pedersen_aggregator_window_bits_18;
pub mod pedersen_aggregator_window_bits_9;
pub mod pedersen_builtin;
pub mod pedersen_builtin_narrow_windows;
pub mod pedersen_points_table_window_bits_18;
pub mod pedersen_points_table_window_bits_9;
pub mod poseidon_3_partial_rounds_chain;
pub mod poseidon_aggregator;
pub mod poseidon_builtin;
pub mod poseidon_full_round_chain;
pub mod poseidon_round_keys;
pub mod qm_31_add_mul_opcode;
pub mod range_check96_builtin;
pub mod range_check_11;
pub mod range_check_12;
pub mod range_check_18;
pub mod range_check_20;
pub mod range_check_252_width_27;
pub mod range_check_3_3_3_3_3;
pub mod range_check_3_6_6_3;
pub mod range_check_4_3;
pub mod range_check_4_4;
pub mod range_check_4_4_4_4;
pub mod range_check_6;
pub mod range_check_7_2_5;
pub mod range_check_8;
pub mod range_check_9_9;
pub mod range_check_builtin;
pub mod ret_opcode;
pub mod triple_xor_32;
pub mod verify_bitwise_xor_12;
pub mod verify_bitwise_xor_4;
pub mod verify_bitwise_xor_7;
pub mod verify_bitwise_xor_8;
pub mod verify_bitwise_xor_9;
pub mod verify_instruction;

pub(crate) mod prelude;
pub(crate) mod subroutines;

use itertools::Itertools;
use stwo_constraint_framework::{FrameworkComponent, FrameworkEval};

#[cfg(test)]
pub mod constraints_regression_test_values;

// TODO(Ohad): move somewhere else.
pub(crate) fn indented_component_display<E: FrameworkEval>(
    component: &FrameworkComponent<E>,
) -> String {
    let component_display = &format!("\n{component}");
    component_display.lines().map(|line| format!("\t{line}")).join("\n")
}
