// This file was created by the AIR team.

use crate::components::prelude::*;

#[derive(Copy, Clone)]
pub struct DecodeInstructionA4D88 {}

impl DecodeInstructionA4D88 {
    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    #[allow(clippy::unused_unit)]
    #[allow(unused_variables)]
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate<E: EvalAtRow>(
        [decode_instruction_a4d88_input_pc]: [E::F; 1],
        enabler: E::F,
        common_lookup_elements: &relations::CommonLookupElements,
        eval: &mut E,
    ) -> [E::F; 0] {
        let M31_130 = E::F::from(M31::from(130));
        let M31_1719106205 = E::F::from(M31::from(1719106205));
        let M31_32766 = E::F::from(M31::from(32766));
        let M31_32767 = E::F::from(M31::from(32767));
        let M31_88 = E::F::from(M31::from(88));

        eval.add_to_relation(RelationEntry::new(
            common_lookup_elements,
            E::EF::from(enabler.clone()),
            &[
                M31_1719106205.clone(),
                decode_instruction_a4d88_input_pc.clone(),
                M31_32766.clone(),
                M31_32767.clone(),
                M31_32767.clone(),
                M31_88.clone(),
                M31_130.clone(),
            ],
        ));

        []
    }
}
