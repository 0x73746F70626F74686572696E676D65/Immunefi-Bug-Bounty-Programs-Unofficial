// This file was created by the AIR team.

use subroutines::linear_combination_n_4_coefs_1_1_m2_1::LinearCombinationN4Coefs11M21;
use subroutines::linear_combination_n_4_coefs_1_m1_1_1::LinearCombinationN4Coefs1M111;
use subroutines::linear_combination_n_4_coefs_3_1_1_1::LinearCombinationN4Coefs3111;

use crate::components::prelude::*;

pub const N_TRACE_COLUMNS: usize = 126;
pub const RELATION_USES_PER_ROW: [RelationUse; 4] = [
    RelationUse { relation_id: "Cube252", uses: 3 },
    RelationUse { relation_id: "PoseidonFullRoundChain", uses: 1 },
    RelationUse { relation_id: "PoseidonRoundKeys", uses: 1 },
    RelationUse { relation_id: "RangeCheck_3_3_3_3_3", uses: 6 },
];

pub struct Eval {
    pub claim: Claim,
    pub common_lookup_elements: relations::CommonLookupElements,
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct Claim {
    pub log_size: u32,
}
impl Claim {
    pub fn log_sizes(&self) -> TreeVec<Vec<u32>> {
        let trace_log_sizes = vec![self.log_size; N_TRACE_COLUMNS];
        let interaction_log_sizes = vec![self.log_size; SECURE_EXTENSION_DEGREE * 6];
        TreeVec::new(vec![trace_log_sizes, interaction_log_sizes])
    }
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct InteractionClaim {
    pub claimed_sum: SecureField,
}

pub type Component = FrameworkComponent<Eval>;

impl FrameworkEval for Eval {
    fn log_size(&self) -> u32 {
        self.claim.log_size
    }

    fn max_constraint_log_degree_bound(&self) -> u32 {
        self.log_size() + 1
    }

    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    fn evaluate<E: EvalAtRow>(&self, mut eval: E) -> E {
        let M31_1 = E::F::from(M31::from(1));
        let M31_1024310512 = E::F::from(M31::from(1024310512));
        let M31_1480369132 = E::F::from(M31::from(1480369132));
        let M31_1987997202 = E::F::from(M31::from(1987997202));
        let enabler_col0 = eval.next_trace_mask();
        let input_limb_0_col1 = eval.next_trace_mask();
        let input_limb_1_col2 = eval.next_trace_mask();
        let input_limb_2_col3 = eval.next_trace_mask();
        let input_limb_3_col4 = eval.next_trace_mask();
        let input_limb_4_col5 = eval.next_trace_mask();
        let input_limb_5_col6 = eval.next_trace_mask();
        let input_limb_6_col7 = eval.next_trace_mask();
        let input_limb_7_col8 = eval.next_trace_mask();
        let input_limb_8_col9 = eval.next_trace_mask();
        let input_limb_9_col10 = eval.next_trace_mask();
        let input_limb_10_col11 = eval.next_trace_mask();
        let input_limb_11_col12 = eval.next_trace_mask();
        let input_limb_12_col13 = eval.next_trace_mask();
        let input_limb_13_col14 = eval.next_trace_mask();
        let input_limb_14_col15 = eval.next_trace_mask();
        let input_limb_15_col16 = eval.next_trace_mask();
        let input_limb_16_col17 = eval.next_trace_mask();
        let input_limb_17_col18 = eval.next_trace_mask();
        let input_limb_18_col19 = eval.next_trace_mask();
        let input_limb_19_col20 = eval.next_trace_mask();
        let input_limb_20_col21 = eval.next_trace_mask();
        let input_limb_21_col22 = eval.next_trace_mask();
        let input_limb_22_col23 = eval.next_trace_mask();
        let input_limb_23_col24 = eval.next_trace_mask();
        let input_limb_24_col25 = eval.next_trace_mask();
        let input_limb_25_col26 = eval.next_trace_mask();
        let input_limb_26_col27 = eval.next_trace_mask();
        let input_limb_27_col28 = eval.next_trace_mask();
        let input_limb_28_col29 = eval.next_trace_mask();
        let input_limb_29_col30 = eval.next_trace_mask();
        let input_limb_30_col31 = eval.next_trace_mask();
        let input_limb_31_col32 = eval.next_trace_mask();
        let cube_252_output_limb_0_col33 = eval.next_trace_mask();
        let cube_252_output_limb_1_col34 = eval.next_trace_mask();
        let cube_252_output_limb_2_col35 = eval.next_trace_mask();
        let cube_252_output_limb_3_col36 = eval.next_trace_mask();
        let cube_252_output_limb_4_col37 = eval.next_trace_mask();
        let cube_252_output_limb_5_col38 = eval.next_trace_mask();
        let cube_252_output_limb_6_col39 = eval.next_trace_mask();
        let cube_252_output_limb_7_col40 = eval.next_trace_mask();
        let cube_252_output_limb_8_col41 = eval.next_trace_mask();
        let cube_252_output_limb_9_col42 = eval.next_trace_mask();
        let cube_252_output_limb_0_col43 = eval.next_trace_mask();
        let cube_252_output_limb_1_col44 = eval.next_trace_mask();
        let cube_252_output_limb_2_col45 = eval.next_trace_mask();
        let cube_252_output_limb_3_col46 = eval.next_trace_mask();
        let cube_252_output_limb_4_col47 = eval.next_trace_mask();
        let cube_252_output_limb_5_col48 = eval.next_trace_mask();
        let cube_252_output_limb_6_col49 = eval.next_trace_mask();
        let cube_252_output_limb_7_col50 = eval.next_trace_mask();
        let cube_252_output_limb_8_col51 = eval.next_trace_mask();
        let cube_252_output_limb_9_col52 = eval.next_trace_mask();
        let cube_252_output_limb_0_col53 = eval.next_trace_mask();
        let cube_252_output_limb_1_col54 = eval.next_trace_mask();
        let cube_252_output_limb_2_col55 = eval.next_trace_mask();
        let cube_252_output_limb_3_col56 = eval.next_trace_mask();
        let cube_252_output_limb_4_col57 = eval.next_trace_mask();
        let cube_252_output_limb_5_col58 = eval.next_trace_mask();
        let cube_252_output_limb_6_col59 = eval.next_trace_mask();
        let cube_252_output_limb_7_col60 = eval.next_trace_mask();
        let cube_252_output_limb_8_col61 = eval.next_trace_mask();
        let cube_252_output_limb_9_col62 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_0_col63 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_1_col64 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_2_col65 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_3_col66 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_4_col67 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_5_col68 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_6_col69 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_7_col70 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_8_col71 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_9_col72 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_10_col73 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_11_col74 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_12_col75 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_13_col76 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_14_col77 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_15_col78 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_16_col79 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_17_col80 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_18_col81 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_19_col82 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_20_col83 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_21_col84 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_22_col85 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_23_col86 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_24_col87 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_25_col88 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_26_col89 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_27_col90 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_28_col91 = eval.next_trace_mask();
        let poseidon_round_keys_output_limb_29_col92 = eval.next_trace_mask();
        let combination_limb_0_col93 = eval.next_trace_mask();
        let combination_limb_1_col94 = eval.next_trace_mask();
        let combination_limb_2_col95 = eval.next_trace_mask();
        let combination_limb_3_col96 = eval.next_trace_mask();
        let combination_limb_4_col97 = eval.next_trace_mask();
        let combination_limb_5_col98 = eval.next_trace_mask();
        let combination_limb_6_col99 = eval.next_trace_mask();
        let combination_limb_7_col100 = eval.next_trace_mask();
        let combination_limb_8_col101 = eval.next_trace_mask();
        let combination_limb_9_col102 = eval.next_trace_mask();
        let p_coef_col103 = eval.next_trace_mask();
        let combination_limb_0_col104 = eval.next_trace_mask();
        let combination_limb_1_col105 = eval.next_trace_mask();
        let combination_limb_2_col106 = eval.next_trace_mask();
        let combination_limb_3_col107 = eval.next_trace_mask();
        let combination_limb_4_col108 = eval.next_trace_mask();
        let combination_limb_5_col109 = eval.next_trace_mask();
        let combination_limb_6_col110 = eval.next_trace_mask();
        let combination_limb_7_col111 = eval.next_trace_mask();
        let combination_limb_8_col112 = eval.next_trace_mask();
        let combination_limb_9_col113 = eval.next_trace_mask();
        let p_coef_col114 = eval.next_trace_mask();
        let combination_limb_0_col115 = eval.next_trace_mask();
        let combination_limb_1_col116 = eval.next_trace_mask();
        let combination_limb_2_col117 = eval.next_trace_mask();
        let combination_limb_3_col118 = eval.next_trace_mask();
        let combination_limb_4_col119 = eval.next_trace_mask();
        let combination_limb_5_col120 = eval.next_trace_mask();
        let combination_limb_6_col121 = eval.next_trace_mask();
        let combination_limb_7_col122 = eval.next_trace_mask();
        let combination_limb_8_col123 = eval.next_trace_mask();
        let combination_limb_9_col124 = eval.next_trace_mask();
        let p_coef_col125 = eval.next_trace_mask();

        // Enabler is a bit.
        eval.add_constraint(((enabler_col0.clone() * enabler_col0.clone()) - enabler_col0.clone()));
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_1987997202.clone(),
                input_limb_2_col3.clone(),
                input_limb_3_col4.clone(),
                input_limb_4_col5.clone(),
                input_limb_5_col6.clone(),
                input_limb_6_col7.clone(),
                input_limb_7_col8.clone(),
                input_limb_8_col9.clone(),
                input_limb_9_col10.clone(),
                input_limb_10_col11.clone(),
                input_limb_11_col12.clone(),
                cube_252_output_limb_0_col33.clone(),
                cube_252_output_limb_1_col34.clone(),
                cube_252_output_limb_2_col35.clone(),
                cube_252_output_limb_3_col36.clone(),
                cube_252_output_limb_4_col37.clone(),
                cube_252_output_limb_5_col38.clone(),
                cube_252_output_limb_6_col39.clone(),
                cube_252_output_limb_7_col40.clone(),
                cube_252_output_limb_8_col41.clone(),
                cube_252_output_limb_9_col42.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_1987997202.clone(),
                input_limb_12_col13.clone(),
                input_limb_13_col14.clone(),
                input_limb_14_col15.clone(),
                input_limb_15_col16.clone(),
                input_limb_16_col17.clone(),
                input_limb_17_col18.clone(),
                input_limb_18_col19.clone(),
                input_limb_19_col20.clone(),
                input_limb_20_col21.clone(),
                input_limb_21_col22.clone(),
                cube_252_output_limb_0_col43.clone(),
                cube_252_output_limb_1_col44.clone(),
                cube_252_output_limb_2_col45.clone(),
                cube_252_output_limb_3_col46.clone(),
                cube_252_output_limb_4_col47.clone(),
                cube_252_output_limb_5_col48.clone(),
                cube_252_output_limb_6_col49.clone(),
                cube_252_output_limb_7_col50.clone(),
                cube_252_output_limb_8_col51.clone(),
                cube_252_output_limb_9_col52.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_1987997202.clone(),
                input_limb_22_col23.clone(),
                input_limb_23_col24.clone(),
                input_limb_24_col25.clone(),
                input_limb_25_col26.clone(),
                input_limb_26_col27.clone(),
                input_limb_27_col28.clone(),
                input_limb_28_col29.clone(),
                input_limb_29_col30.clone(),
                input_limb_30_col31.clone(),
                input_limb_31_col32.clone(),
                cube_252_output_limb_0_col53.clone(),
                cube_252_output_limb_1_col54.clone(),
                cube_252_output_limb_2_col55.clone(),
                cube_252_output_limb_3_col56.clone(),
                cube_252_output_limb_4_col57.clone(),
                cube_252_output_limb_5_col58.clone(),
                cube_252_output_limb_6_col59.clone(),
                cube_252_output_limb_7_col60.clone(),
                cube_252_output_limb_8_col61.clone(),
                cube_252_output_limb_9_col62.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_1024310512.clone(),
                input_limb_1_col2.clone(),
                poseidon_round_keys_output_limb_0_col63.clone(),
                poseidon_round_keys_output_limb_1_col64.clone(),
                poseidon_round_keys_output_limb_2_col65.clone(),
                poseidon_round_keys_output_limb_3_col66.clone(),
                poseidon_round_keys_output_limb_4_col67.clone(),
                poseidon_round_keys_output_limb_5_col68.clone(),
                poseidon_round_keys_output_limb_6_col69.clone(),
                poseidon_round_keys_output_limb_7_col70.clone(),
                poseidon_round_keys_output_limb_8_col71.clone(),
                poseidon_round_keys_output_limb_9_col72.clone(),
                poseidon_round_keys_output_limb_10_col73.clone(),
                poseidon_round_keys_output_limb_11_col74.clone(),
                poseidon_round_keys_output_limb_12_col75.clone(),
                poseidon_round_keys_output_limb_13_col76.clone(),
                poseidon_round_keys_output_limb_14_col77.clone(),
                poseidon_round_keys_output_limb_15_col78.clone(),
                poseidon_round_keys_output_limb_16_col79.clone(),
                poseidon_round_keys_output_limb_17_col80.clone(),
                poseidon_round_keys_output_limb_18_col81.clone(),
                poseidon_round_keys_output_limb_19_col82.clone(),
                poseidon_round_keys_output_limb_20_col83.clone(),
                poseidon_round_keys_output_limb_21_col84.clone(),
                poseidon_round_keys_output_limb_22_col85.clone(),
                poseidon_round_keys_output_limb_23_col86.clone(),
                poseidon_round_keys_output_limb_24_col87.clone(),
                poseidon_round_keys_output_limb_25_col88.clone(),
                poseidon_round_keys_output_limb_26_col89.clone(),
                poseidon_round_keys_output_limb_27_col90.clone(),
                poseidon_round_keys_output_limb_28_col91.clone(),
                poseidon_round_keys_output_limb_29_col92.clone(),
            ],
        ));

        LinearCombinationN4Coefs3111::evaluate(
            [
                cube_252_output_limb_0_col33.clone(),
                cube_252_output_limb_1_col34.clone(),
                cube_252_output_limb_2_col35.clone(),
                cube_252_output_limb_3_col36.clone(),
                cube_252_output_limb_4_col37.clone(),
                cube_252_output_limb_5_col38.clone(),
                cube_252_output_limb_6_col39.clone(),
                cube_252_output_limb_7_col40.clone(),
                cube_252_output_limb_8_col41.clone(),
                cube_252_output_limb_9_col42.clone(),
                cube_252_output_limb_0_col43.clone(),
                cube_252_output_limb_1_col44.clone(),
                cube_252_output_limb_2_col45.clone(),
                cube_252_output_limb_3_col46.clone(),
                cube_252_output_limb_4_col47.clone(),
                cube_252_output_limb_5_col48.clone(),
                cube_252_output_limb_6_col49.clone(),
                cube_252_output_limb_7_col50.clone(),
                cube_252_output_limb_8_col51.clone(),
                cube_252_output_limb_9_col52.clone(),
                cube_252_output_limb_0_col53.clone(),
                cube_252_output_limb_1_col54.clone(),
                cube_252_output_limb_2_col55.clone(),
                cube_252_output_limb_3_col56.clone(),
                cube_252_output_limb_4_col57.clone(),
                cube_252_output_limb_5_col58.clone(),
                cube_252_output_limb_6_col59.clone(),
                cube_252_output_limb_7_col60.clone(),
                cube_252_output_limb_8_col61.clone(),
                cube_252_output_limb_9_col62.clone(),
                poseidon_round_keys_output_limb_0_col63.clone(),
                poseidon_round_keys_output_limb_1_col64.clone(),
                poseidon_round_keys_output_limb_2_col65.clone(),
                poseidon_round_keys_output_limb_3_col66.clone(),
                poseidon_round_keys_output_limb_4_col67.clone(),
                poseidon_round_keys_output_limb_5_col68.clone(),
                poseidon_round_keys_output_limb_6_col69.clone(),
                poseidon_round_keys_output_limb_7_col70.clone(),
                poseidon_round_keys_output_limb_8_col71.clone(),
                poseidon_round_keys_output_limb_9_col72.clone(),
            ],
            enabler_col0.clone(),
            combination_limb_0_col93.clone(),
            combination_limb_1_col94.clone(),
            combination_limb_2_col95.clone(),
            combination_limb_3_col96.clone(),
            combination_limb_4_col97.clone(),
            combination_limb_5_col98.clone(),
            combination_limb_6_col99.clone(),
            combination_limb_7_col100.clone(),
            combination_limb_8_col101.clone(),
            combination_limb_9_col102.clone(),
            p_coef_col103.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        LinearCombinationN4Coefs1M111::evaluate(
            [
                cube_252_output_limb_0_col33.clone(),
                cube_252_output_limb_1_col34.clone(),
                cube_252_output_limb_2_col35.clone(),
                cube_252_output_limb_3_col36.clone(),
                cube_252_output_limb_4_col37.clone(),
                cube_252_output_limb_5_col38.clone(),
                cube_252_output_limb_6_col39.clone(),
                cube_252_output_limb_7_col40.clone(),
                cube_252_output_limb_8_col41.clone(),
                cube_252_output_limb_9_col42.clone(),
                cube_252_output_limb_0_col43.clone(),
                cube_252_output_limb_1_col44.clone(),
                cube_252_output_limb_2_col45.clone(),
                cube_252_output_limb_3_col46.clone(),
                cube_252_output_limb_4_col47.clone(),
                cube_252_output_limb_5_col48.clone(),
                cube_252_output_limb_6_col49.clone(),
                cube_252_output_limb_7_col50.clone(),
                cube_252_output_limb_8_col51.clone(),
                cube_252_output_limb_9_col52.clone(),
                cube_252_output_limb_0_col53.clone(),
                cube_252_output_limb_1_col54.clone(),
                cube_252_output_limb_2_col55.clone(),
                cube_252_output_limb_3_col56.clone(),
                cube_252_output_limb_4_col57.clone(),
                cube_252_output_limb_5_col58.clone(),
                cube_252_output_limb_6_col59.clone(),
                cube_252_output_limb_7_col60.clone(),
                cube_252_output_limb_8_col61.clone(),
                cube_252_output_limb_9_col62.clone(),
                poseidon_round_keys_output_limb_10_col73.clone(),
                poseidon_round_keys_output_limb_11_col74.clone(),
                poseidon_round_keys_output_limb_12_col75.clone(),
                poseidon_round_keys_output_limb_13_col76.clone(),
                poseidon_round_keys_output_limb_14_col77.clone(),
                poseidon_round_keys_output_limb_15_col78.clone(),
                poseidon_round_keys_output_limb_16_col79.clone(),
                poseidon_round_keys_output_limb_17_col80.clone(),
                poseidon_round_keys_output_limb_18_col81.clone(),
                poseidon_round_keys_output_limb_19_col82.clone(),
            ],
            enabler_col0.clone(),
            combination_limb_0_col104.clone(),
            combination_limb_1_col105.clone(),
            combination_limb_2_col106.clone(),
            combination_limb_3_col107.clone(),
            combination_limb_4_col108.clone(),
            combination_limb_5_col109.clone(),
            combination_limb_6_col110.clone(),
            combination_limb_7_col111.clone(),
            combination_limb_8_col112.clone(),
            combination_limb_9_col113.clone(),
            p_coef_col114.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        LinearCombinationN4Coefs11M21::evaluate(
            [
                cube_252_output_limb_0_col33.clone(),
                cube_252_output_limb_1_col34.clone(),
                cube_252_output_limb_2_col35.clone(),
                cube_252_output_limb_3_col36.clone(),
                cube_252_output_limb_4_col37.clone(),
                cube_252_output_limb_5_col38.clone(),
                cube_252_output_limb_6_col39.clone(),
                cube_252_output_limb_7_col40.clone(),
                cube_252_output_limb_8_col41.clone(),
                cube_252_output_limb_9_col42.clone(),
                cube_252_output_limb_0_col43.clone(),
                cube_252_output_limb_1_col44.clone(),
                cube_252_output_limb_2_col45.clone(),
                cube_252_output_limb_3_col46.clone(),
                cube_252_output_limb_4_col47.clone(),
                cube_252_output_limb_5_col48.clone(),
                cube_252_output_limb_6_col49.clone(),
                cube_252_output_limb_7_col50.clone(),
                cube_252_output_limb_8_col51.clone(),
                cube_252_output_limb_9_col52.clone(),
                cube_252_output_limb_0_col53.clone(),
                cube_252_output_limb_1_col54.clone(),
                cube_252_output_limb_2_col55.clone(),
                cube_252_output_limb_3_col56.clone(),
                cube_252_output_limb_4_col57.clone(),
                cube_252_output_limb_5_col58.clone(),
                cube_252_output_limb_6_col59.clone(),
                cube_252_output_limb_7_col60.clone(),
                cube_252_output_limb_8_col61.clone(),
                cube_252_output_limb_9_col62.clone(),
                poseidon_round_keys_output_limb_20_col83.clone(),
                poseidon_round_keys_output_limb_21_col84.clone(),
                poseidon_round_keys_output_limb_22_col85.clone(),
                poseidon_round_keys_output_limb_23_col86.clone(),
                poseidon_round_keys_output_limb_24_col87.clone(),
                poseidon_round_keys_output_limb_25_col88.clone(),
                poseidon_round_keys_output_limb_26_col89.clone(),
                poseidon_round_keys_output_limb_27_col90.clone(),
                poseidon_round_keys_output_limb_28_col91.clone(),
                poseidon_round_keys_output_limb_29_col92.clone(),
            ],
            enabler_col0.clone(),
            combination_limb_0_col115.clone(),
            combination_limb_1_col116.clone(),
            combination_limb_2_col117.clone(),
            combination_limb_3_col118.clone(),
            combination_limb_4_col119.clone(),
            combination_limb_5_col120.clone(),
            combination_limb_6_col121.clone(),
            combination_limb_7_col122.clone(),
            combination_limb_8_col123.clone(),
            combination_limb_9_col124.clone(),
            p_coef_col125.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            E::EF::from(enabler_col0.clone()),
            &[
                M31_1480369132.clone(),
                input_limb_0_col1.clone(),
                input_limb_1_col2.clone(),
                input_limb_2_col3.clone(),
                input_limb_3_col4.clone(),
                input_limb_4_col5.clone(),
                input_limb_5_col6.clone(),
                input_limb_6_col7.clone(),
                input_limb_7_col8.clone(),
                input_limb_8_col9.clone(),
                input_limb_9_col10.clone(),
                input_limb_10_col11.clone(),
                input_limb_11_col12.clone(),
                input_limb_12_col13.clone(),
                input_limb_13_col14.clone(),
                input_limb_14_col15.clone(),
                input_limb_15_col16.clone(),
                input_limb_16_col17.clone(),
                input_limb_17_col18.clone(),
                input_limb_18_col19.clone(),
                input_limb_19_col20.clone(),
                input_limb_20_col21.clone(),
                input_limb_21_col22.clone(),
                input_limb_22_col23.clone(),
                input_limb_23_col24.clone(),
                input_limb_24_col25.clone(),
                input_limb_25_col26.clone(),
                input_limb_26_col27.clone(),
                input_limb_27_col28.clone(),
                input_limb_28_col29.clone(),
                input_limb_29_col30.clone(),
                input_limb_30_col31.clone(),
                input_limb_31_col32.clone(),
            ],
        ));

        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_1480369132.clone(),
                input_limb_0_col1.clone(),
                (input_limb_1_col2.clone() + M31_1.clone()),
                combination_limb_0_col93.clone(),
                combination_limb_1_col94.clone(),
                combination_limb_2_col95.clone(),
                combination_limb_3_col96.clone(),
                combination_limb_4_col97.clone(),
                combination_limb_5_col98.clone(),
                combination_limb_6_col99.clone(),
                combination_limb_7_col100.clone(),
                combination_limb_8_col101.clone(),
                combination_limb_9_col102.clone(),
                combination_limb_0_col104.clone(),
                combination_limb_1_col105.clone(),
                combination_limb_2_col106.clone(),
                combination_limb_3_col107.clone(),
                combination_limb_4_col108.clone(),
                combination_limb_5_col109.clone(),
                combination_limb_6_col110.clone(),
                combination_limb_7_col111.clone(),
                combination_limb_8_col112.clone(),
                combination_limb_9_col113.clone(),
                combination_limb_0_col115.clone(),
                combination_limb_1_col116.clone(),
                combination_limb_2_col117.clone(),
                combination_limb_3_col118.clone(),
                combination_limb_4_col119.clone(),
                combination_limb_5_col120.clone(),
                combination_limb_6_col121.clone(),
                combination_limb_7_col122.clone(),
                combination_limb_8_col123.clone(),
                combination_limb_9_col124.clone(),
            ],
        ));

        eval.finalize_logup_in_pairs();
        eval
    }
}

#[cfg(test)]
mod tests {
    use num_traits::Zero;
    use rand::rngs::SmallRng;
    use rand::{Rng, SeedableRng};
    use stwo::core::fields::qm31::QM31;
    use stwo_constraint_framework::expr::ExprEvaluator;

    use super::*;

    #[test]
    fn poseidon_full_round_chain_constraints_regression() {
        let mut rng = SmallRng::seed_from_u64(0);
        let eval = Eval {
            claim: Claim { log_size: 4 },
            common_lookup_elements: relations::CommonLookupElements::dummy(),
        };
        let expr_eval = eval.evaluate(ExprEvaluator::new());
        let assignment = expr_eval.random_assignment();

        let mut sum = QM31::zero();
        for c in expr_eval.constraints {
            sum += c.assign(&assignment) * rng.random::<QM31>();
        }

        constraints_regression_test_values::POSEIDON_FULL_ROUND_CHAIN.assert_debug_eq(&sum);
    }
}
