// This file was created by the AIR team.

use crate::components::prelude::*;

#[derive(Copy, Clone)]
pub struct DecodeInstruction11364 {}

impl DecodeInstruction11364 {
    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    #[allow(clippy::unused_unit)]
    #[allow(unused_variables)]
    #[allow(clippy::too_many_arguments)]
    pub fn evaluate<E: EvalAtRow>(
        [decode_instruction_11364_input_pc]: [E::F; 1],
        enabler: E::F,
        offset1_col0: E::F,
        offset2_col1: E::F,
        op0_base_fp_col2: E::F,
        ap_update_add_1_col3: E::F,
        common_lookup_elements: &relations::CommonLookupElements,
        eval: &mut E,
    ) -> [E::F; 2] {
        let M31_1 = E::F::from(M31::from(1));
        let M31_16 = E::F::from(M31::from(16));
        let M31_1719106205 = E::F::from(M31::from(1719106205));
        let M31_2 = E::F::from(M31::from(2));
        let M31_32 = E::F::from(M31::from(32));
        let M31_32767 = E::F::from(M31::from(32767));
        let M31_32768 = E::F::from(M31::from(32768));
        let M31_8 = E::F::from(M31::from(8));

        // Flag op0_base_fp is a bit.
        eval.add_constraint(
            (op0_base_fp_col2.clone() * (M31_1.clone() - op0_base_fp_col2.clone())),
        );
        // Flag ap_update_add_1 is a bit.
        eval.add_constraint(
            (ap_update_add_1_col3.clone() * (M31_1.clone() - ap_update_add_1_col3.clone())),
        );
        eval.add_to_relation(RelationEntry::new(
            common_lookup_elements,
            E::EF::from(enabler.clone()),
            &[
                M31_1719106205.clone(),
                decode_instruction_11364_input_pc.clone(),
                M31_32767.clone(),
                offset1_col0.clone(),
                offset2_col1.clone(),
                (M31_8.clone() + (op0_base_fp_col2.clone() * M31_16.clone())),
                (M31_2.clone() + (ap_update_add_1_col3.clone() * M31_32.clone())),
            ],
        ));

        [(offset1_col0.clone() - M31_32768.clone()), (offset2_col1.clone() - M31_32768.clone())]
    }
}
