// This file was created by the AIR team.

use subroutines::bitwise_xor_num_bits_8::BitwiseXorNumBits8;
use subroutines::bitwise_xor_num_bits_8_b::BitwiseXorNumBits8B;
use subroutines::split_16_low_part_size_8::Split16LowPartSize8;

use crate::components::prelude::*;

pub const N_TRACE_COLUMNS: usize = 21;
pub const RELATION_USES_PER_ROW: [RelationUse; 2] = [
    RelationUse { relation_id: "VerifyBitwiseXor_8", uses: 4 },
    RelationUse { relation_id: "VerifyBitwiseXor_8_B", uses: 4 },
];

pub struct Eval {
    pub claim: Claim,
    pub common_lookup_elements: relations::CommonLookupElements,
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct Claim {
    pub log_size: u32,
}
impl Claim {
    pub fn log_sizes(&self) -> TreeVec<Vec<u32>> {
        let trace_log_sizes = vec![self.log_size; N_TRACE_COLUMNS];
        let interaction_log_sizes = vec![self.log_size; SECURE_EXTENSION_DEGREE * 5];
        TreeVec::new(vec![trace_log_sizes, interaction_log_sizes])
    }
}

#[derive(Copy, Clone, Serialize, Deserialize, CairoSerialize, CairoDeserialize)]
pub struct InteractionClaim {
    pub claimed_sum: SecureField,
}

pub type Component = FrameworkComponent<Eval>;

impl FrameworkEval for Eval {
    fn log_size(&self) -> u32 {
        self.claim.log_size
    }

    fn max_constraint_log_degree_bound(&self) -> u32 {
        self.log_size() + 1
    }

    #[allow(unused_parens)]
    #[allow(clippy::double_parens)]
    #[allow(non_snake_case)]
    fn evaluate<E: EvalAtRow>(&self, mut eval: E) -> E {
        let M31_256 = E::F::from(M31::from(256));
        let M31_990559919 = E::F::from(M31::from(990559919));
        let enabler_col0 = eval.next_trace_mask();
        let input_limb_0_col1 = eval.next_trace_mask();
        let input_limb_1_col2 = eval.next_trace_mask();
        let input_limb_2_col3 = eval.next_trace_mask();
        let input_limb_3_col4 = eval.next_trace_mask();
        let input_limb_4_col5 = eval.next_trace_mask();
        let input_limb_5_col6 = eval.next_trace_mask();
        let ms_8_bits_col7 = eval.next_trace_mask();
        let ms_8_bits_col8 = eval.next_trace_mask();
        let ms_8_bits_col9 = eval.next_trace_mask();
        let ms_8_bits_col10 = eval.next_trace_mask();
        let ms_8_bits_col11 = eval.next_trace_mask();
        let ms_8_bits_col12 = eval.next_trace_mask();
        let xor_col13 = eval.next_trace_mask();
        let xor_col14 = eval.next_trace_mask();
        let xor_col15 = eval.next_trace_mask();
        let xor_col16 = eval.next_trace_mask();
        let xor_col17 = eval.next_trace_mask();
        let xor_col18 = eval.next_trace_mask();
        let xor_col19 = eval.next_trace_mask();
        let xor_col20 = eval.next_trace_mask();

        // Enabler is a bit.
        eval.add_constraint(((enabler_col0.clone() * enabler_col0.clone()) - enabler_col0.clone()));
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [split_16_low_part_size_8_output_tmp_6e2d1_1_limb_0] = Split16LowPartSize8::evaluate(
            [input_limb_0_col1.clone()],
            enabler_col0.clone(),
            ms_8_bits_col7.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [split_16_low_part_size_8_output_tmp_6e2d1_3_limb_0] = Split16LowPartSize8::evaluate(
            [input_limb_1_col2.clone()],
            enabler_col0.clone(),
            ms_8_bits_col8.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [split_16_low_part_size_8_output_tmp_6e2d1_5_limb_0] = Split16LowPartSize8::evaluate(
            [input_limb_2_col3.clone()],
            enabler_col0.clone(),
            ms_8_bits_col9.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [split_16_low_part_size_8_output_tmp_6e2d1_7_limb_0] = Split16LowPartSize8::evaluate(
            [input_limb_3_col4.clone()],
            enabler_col0.clone(),
            ms_8_bits_col10.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [split_16_low_part_size_8_output_tmp_6e2d1_9_limb_0] = Split16LowPartSize8::evaluate(
            [input_limb_4_col5.clone()],
            enabler_col0.clone(),
            ms_8_bits_col11.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        #[allow(clippy::unused_unit)]
        #[allow(unused_variables)]
        let [split_16_low_part_size_8_output_tmp_6e2d1_11_limb_0] = Split16LowPartSize8::evaluate(
            [input_limb_5_col6.clone()],
            enabler_col0.clone(),
            ms_8_bits_col12.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8::evaluate(
            [
                split_16_low_part_size_8_output_tmp_6e2d1_1_limb_0.clone(),
                split_16_low_part_size_8_output_tmp_6e2d1_5_limb_0.clone(),
            ],
            enabler_col0.clone(),
            xor_col13.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8::evaluate(
            [xor_col13.clone(), split_16_low_part_size_8_output_tmp_6e2d1_9_limb_0.clone()],
            enabler_col0.clone(),
            xor_col14.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8::evaluate(
            [ms_8_bits_col7.clone(), ms_8_bits_col9.clone()],
            enabler_col0.clone(),
            xor_col15.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8::evaluate(
            [xor_col15.clone(), ms_8_bits_col11.clone()],
            enabler_col0.clone(),
            xor_col16.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8B::evaluate(
            [
                split_16_low_part_size_8_output_tmp_6e2d1_3_limb_0.clone(),
                split_16_low_part_size_8_output_tmp_6e2d1_7_limb_0.clone(),
            ],
            enabler_col0.clone(),
            xor_col17.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8B::evaluate(
            [xor_col17.clone(), split_16_low_part_size_8_output_tmp_6e2d1_11_limb_0.clone()],
            enabler_col0.clone(),
            xor_col18.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8B::evaluate(
            [ms_8_bits_col8.clone(), ms_8_bits_col10.clone()],
            enabler_col0.clone(),
            xor_col19.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        BitwiseXorNumBits8B::evaluate(
            [xor_col19.clone(), ms_8_bits_col12.clone()],
            enabler_col0.clone(),
            xor_col20.clone(),
            &self.common_lookup_elements,
            &mut eval,
        );
        let triple_xor32_output_tmp_6e2d1_28_limb_0 =
            eval.add_intermediate((xor_col14.clone() + (xor_col16.clone() * M31_256.clone())));
        let triple_xor32_output_tmp_6e2d1_28_limb_1 =
            eval.add_intermediate((xor_col18.clone() + (xor_col20.clone() * M31_256.clone())));
        eval.add_to_relation(RelationEntry::new(
            &self.common_lookup_elements,
            -E::EF::from(enabler_col0.clone()),
            &[
                M31_990559919.clone(),
                input_limb_0_col1.clone(),
                input_limb_1_col2.clone(),
                input_limb_2_col3.clone(),
                input_limb_3_col4.clone(),
                input_limb_4_col5.clone(),
                input_limb_5_col6.clone(),
                triple_xor32_output_tmp_6e2d1_28_limb_0.clone(),
                triple_xor32_output_tmp_6e2d1_28_limb_1.clone(),
            ],
        ));

        eval.finalize_logup_in_pairs();
        eval
    }
}

#[cfg(test)]
mod tests {
    use num_traits::Zero;
    use rand::rngs::SmallRng;
    use rand::{Rng, SeedableRng};
    use stwo::core::fields::qm31::QM31;
    use stwo_constraint_framework::expr::ExprEvaluator;

    use super::*;

    #[test]
    fn triple_xor_32_constraints_regression() {
        let mut rng = SmallRng::seed_from_u64(0);
        let eval = Eval {
            claim: Claim { log_size: 4 },
            common_lookup_elements: relations::CommonLookupElements::dummy(),
        };
        let expr_eval = eval.evaluate(ExprEvaluator::new());
        let assignment = expr_eval.random_assignment();

        let mut sum = QM31::zero();
        for c in expr_eval.constraints {
            sum += c.assign(&assignment) * rng.random::<QM31>();
        }

        constraints_regression_test_values::TRIPLE_XOR_32.assert_debug_eq(&sum);
    }
}
