// This file was created by the AIR team.

#![allow(unused_parens)]
use cairo_air::components::triple_xor_32::{Claim, InteractionClaim, N_TRACE_COLUMNS};

use crate::witness::components::verify_bitwise_xor_8;
use crate::witness::prelude::*;

pub type InputType = [UInt32; 3];
pub type PackedInputType = [PackedUInt32; 3];

#[derive(Default)]
pub struct ClaimGenerator {
    pub packed_inputs: Mutex<Vec<PackedInputType>>,
    pub remainder_inputs: Mutex<Vec<InputType>>,
}

impl ClaimGenerator {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn write_trace(
        self,
        verify_bitwise_xor_8_state: &verify_bitwise_xor_8::ClaimGenerator,
    ) -> (ComponentTrace<N_TRACE_COLUMNS>, Claim, InteractionClaimGenerator) {
        let mut packed_inputs = self.packed_inputs.into_inner().unwrap();
        let remainder_inputs = self.remainder_inputs.into_inner().unwrap();
        let n_active_rows = packed_inputs.len() * N_LANES + remainder_inputs.len();
        add_remainder(&mut packed_inputs, &remainder_inputs);
        assert!(!packed_inputs.is_empty());
        let n_vec_rows = packed_inputs.len();
        let packed_size = n_vec_rows.next_power_of_two();
        let log_size = packed_size.ilog2() + LOG_N_LANES;
        packed_inputs.resize(packed_size, *packed_inputs.first().unwrap());

        let (trace, lookup_data, sub_component_inputs) =
            write_trace_simd(packed_inputs, n_active_rows, verify_bitwise_xor_8_state);
        for inputs in sub_component_inputs.verify_bitwise_xor_8 {
            add_inputs(verify_bitwise_xor_8_state, &inputs, n_active_rows, 0);
        }
        for inputs in sub_component_inputs.verify_bitwise_xor_8_b {
            add_inputs(verify_bitwise_xor_8_state, &inputs, n_active_rows, 1);
        }

        (trace, Claim { log_size }, InteractionClaimGenerator { log_size, lookup_data })
    }
}

impl AddInputs for ClaimGenerator {
    type PackedInputType = PackedInputType;
    type InputType = InputType;

    fn add_packed_inputs(&self, inputs: &[PackedInputType], _relation_index: usize) {
        self.packed_inputs.lock().unwrap().extend(inputs);
    }
    fn add_input(&self, input: &InputType, _relation_index: usize) {
        self.remainder_inputs.lock().unwrap().push(*input);
    }
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct SubComponentInputs {
    verify_bitwise_xor_8: [Vec<verify_bitwise_xor_8::PackedInputType>; 4],
    verify_bitwise_xor_8_b: [Vec<verify_bitwise_xor_8::PackedInputType>; 4],
}

#[allow(clippy::useless_conversion)]
#[allow(unused_variables)]
#[allow(clippy::double_parens)]
#[allow(non_snake_case)]
fn write_trace_simd(
    inputs: Vec<PackedInputType>,
    n_rows: usize,
    verify_bitwise_xor_8_state: &verify_bitwise_xor_8::ClaimGenerator,
) -> (ComponentTrace<N_TRACE_COLUMNS>, LookupData, SubComponentInputs) {
    let log_n_packed_rows = inputs.len().ilog2();
    let log_size = log_n_packed_rows + LOG_N_LANES;
    let (mut trace, mut lookup_data, mut sub_component_inputs) = unsafe {
        (
            ComponentTrace::<N_TRACE_COLUMNS>::uninitialized(log_size),
            LookupData::uninitialized(log_n_packed_rows),
            SubComponentInputs::uninitialized(log_n_packed_rows),
        )
    };

    let M31_112558620 = PackedM31::broadcast(M31::from(112558620));
    let M31_256 = PackedM31::broadcast(M31::from(256));
    let M31_521092554 = PackedM31::broadcast(M31::from(521092554));
    let M31_990559919 = PackedM31::broadcast(M31::from(990559919));
    let UInt16_8 = PackedUInt16::broadcast(UInt16::from(8));
    let enabler_col = Enabler::new(n_rows);

    (
        trace.par_iter_mut(),
        lookup_data.par_iter_mut(),
        sub_component_inputs.par_iter_mut(),
        inputs.into_par_iter(),
    )
        .into_par_iter()
        .enumerate()
        .for_each(
            |(row_index, (row, lookup_data, sub_component_inputs, triple_xor_32_input))| {
                let enabler_col0 = enabler_col.packed_at(row_index);
                *row[0] = enabler_col0;
                let input_limb_0_col1 = triple_xor_32_input[0].low().as_m31();
                *row[1] = input_limb_0_col1;
                let input_limb_1_col2 = triple_xor_32_input[0].high().as_m31();
                *row[2] = input_limb_1_col2;
                let input_limb_2_col3 = triple_xor_32_input[1].low().as_m31();
                *row[3] = input_limb_2_col3;
                let input_limb_3_col4 = triple_xor_32_input[1].high().as_m31();
                *row[4] = input_limb_3_col4;
                let input_limb_4_col5 = triple_xor_32_input[2].low().as_m31();
                *row[5] = input_limb_4_col5;
                let input_limb_5_col6 = triple_xor_32_input[2].high().as_m31();
                *row[6] = input_limb_5_col6;

                // Split 16 Low Part Size 8.

                let ms_8_bits_tmp_6e2d1_0 = ((triple_xor_32_input[0].low()) >> (UInt16_8));
                let ms_8_bits_col7 = ms_8_bits_tmp_6e2d1_0.as_m31();
                *row[7] = ms_8_bits_col7;
                let split_16_low_part_size_8_output_tmp_6e2d1_1 =
                    [((input_limb_0_col1) - ((ms_8_bits_col7) * (M31_256))), ms_8_bits_col7];

                // Split 16 Low Part Size 8.

                let ms_8_bits_tmp_6e2d1_2 = ((triple_xor_32_input[0].high()) >> (UInt16_8));
                let ms_8_bits_col8 = ms_8_bits_tmp_6e2d1_2.as_m31();
                *row[8] = ms_8_bits_col8;
                let split_16_low_part_size_8_output_tmp_6e2d1_3 =
                    [((input_limb_1_col2) - ((ms_8_bits_col8) * (M31_256))), ms_8_bits_col8];

                // Split 16 Low Part Size 8.

                let ms_8_bits_tmp_6e2d1_4 = ((triple_xor_32_input[1].low()) >> (UInt16_8));
                let ms_8_bits_col9 = ms_8_bits_tmp_6e2d1_4.as_m31();
                *row[9] = ms_8_bits_col9;
                let split_16_low_part_size_8_output_tmp_6e2d1_5 =
                    [((input_limb_2_col3) - ((ms_8_bits_col9) * (M31_256))), ms_8_bits_col9];

                // Split 16 Low Part Size 8.

                let ms_8_bits_tmp_6e2d1_6 = ((triple_xor_32_input[1].high()) >> (UInt16_8));
                let ms_8_bits_col10 = ms_8_bits_tmp_6e2d1_6.as_m31();
                *row[10] = ms_8_bits_col10;
                let split_16_low_part_size_8_output_tmp_6e2d1_7 =
                    [((input_limb_3_col4) - ((ms_8_bits_col10) * (M31_256))), ms_8_bits_col10];

                // Split 16 Low Part Size 8.

                let ms_8_bits_tmp_6e2d1_8 = ((triple_xor_32_input[2].low()) >> (UInt16_8));
                let ms_8_bits_col11 = ms_8_bits_tmp_6e2d1_8.as_m31();
                *row[11] = ms_8_bits_col11;
                let split_16_low_part_size_8_output_tmp_6e2d1_9 =
                    [((input_limb_4_col5) - ((ms_8_bits_col11) * (M31_256))), ms_8_bits_col11];

                // Split 16 Low Part Size 8.

                let ms_8_bits_tmp_6e2d1_10 = ((triple_xor_32_input[2].high()) >> (UInt16_8));
                let ms_8_bits_col12 = ms_8_bits_tmp_6e2d1_10.as_m31();
                *row[12] = ms_8_bits_col12;
                let split_16_low_part_size_8_output_tmp_6e2d1_11 =
                    [((input_limb_5_col6) - ((ms_8_bits_col12) * (M31_256))), ms_8_bits_col12];

                // Bitwise Xor Num Bits 8.

                let xor_tmp_6e2d1_12 =
                    ((PackedUInt16::from_m31(split_16_low_part_size_8_output_tmp_6e2d1_1[0]))
                        ^ (PackedUInt16::from_m31(split_16_low_part_size_8_output_tmp_6e2d1_5[0])));
                let xor_col13 = xor_tmp_6e2d1_12.as_m31();
                *row[13] = xor_col13;
                *sub_component_inputs.verify_bitwise_xor_8[0] = [
                    split_16_low_part_size_8_output_tmp_6e2d1_1[0],
                    split_16_low_part_size_8_output_tmp_6e2d1_5[0],
                    xor_col13,
                ];
                *lookup_data.verify_bitwise_xor_8_0 = [
                    M31_112558620,
                    split_16_low_part_size_8_output_tmp_6e2d1_1[0],
                    split_16_low_part_size_8_output_tmp_6e2d1_5[0],
                    xor_col13,
                ];

                // Bitwise Xor Num Bits 8.

                let xor_tmp_6e2d1_14 = ((PackedUInt16::from_m31(xor_col13))
                    ^ (PackedUInt16::from_m31(split_16_low_part_size_8_output_tmp_6e2d1_9[0])));
                let xor_col14 = xor_tmp_6e2d1_14.as_m31();
                *row[14] = xor_col14;
                *sub_component_inputs.verify_bitwise_xor_8[1] =
                    [xor_col13, split_16_low_part_size_8_output_tmp_6e2d1_9[0], xor_col14];
                *lookup_data.verify_bitwise_xor_8_1 = [
                    M31_112558620,
                    xor_col13,
                    split_16_low_part_size_8_output_tmp_6e2d1_9[0],
                    xor_col14,
                ];

                // Bitwise Xor Num Bits 8.

                let xor_tmp_6e2d1_16 = ((PackedUInt16::from_m31(ms_8_bits_col7))
                    ^ (PackedUInt16::from_m31(ms_8_bits_col9)));
                let xor_col15 = xor_tmp_6e2d1_16.as_m31();
                *row[15] = xor_col15;
                *sub_component_inputs.verify_bitwise_xor_8[2] =
                    [ms_8_bits_col7, ms_8_bits_col9, xor_col15];
                *lookup_data.verify_bitwise_xor_8_2 =
                    [M31_112558620, ms_8_bits_col7, ms_8_bits_col9, xor_col15];

                // Bitwise Xor Num Bits 8.

                let xor_tmp_6e2d1_18 = ((PackedUInt16::from_m31(xor_col15))
                    ^ (PackedUInt16::from_m31(ms_8_bits_col11)));
                let xor_col16 = xor_tmp_6e2d1_18.as_m31();
                *row[16] = xor_col16;
                *sub_component_inputs.verify_bitwise_xor_8[3] =
                    [xor_col15, ms_8_bits_col11, xor_col16];
                *lookup_data.verify_bitwise_xor_8_3 =
                    [M31_112558620, xor_col15, ms_8_bits_col11, xor_col16];

                // Bitwise Xor Num Bits 8 B.

                let xor_tmp_6e2d1_20 =
                    ((PackedUInt16::from_m31(split_16_low_part_size_8_output_tmp_6e2d1_3[0]))
                        ^ (PackedUInt16::from_m31(split_16_low_part_size_8_output_tmp_6e2d1_7[0])));
                let xor_col17 = xor_tmp_6e2d1_20.as_m31();
                *row[17] = xor_col17;
                *sub_component_inputs.verify_bitwise_xor_8_b[0] = [
                    split_16_low_part_size_8_output_tmp_6e2d1_3[0],
                    split_16_low_part_size_8_output_tmp_6e2d1_7[0],
                    xor_col17,
                ];
                *lookup_data.verify_bitwise_xor_8_b_4 = [
                    M31_521092554,
                    split_16_low_part_size_8_output_tmp_6e2d1_3[0],
                    split_16_low_part_size_8_output_tmp_6e2d1_7[0],
                    xor_col17,
                ];

                // Bitwise Xor Num Bits 8 B.

                let xor_tmp_6e2d1_22 = ((PackedUInt16::from_m31(xor_col17))
                    ^ (PackedUInt16::from_m31(split_16_low_part_size_8_output_tmp_6e2d1_11[0])));
                let xor_col18 = xor_tmp_6e2d1_22.as_m31();
                *row[18] = xor_col18;
                *sub_component_inputs.verify_bitwise_xor_8_b[1] =
                    [xor_col17, split_16_low_part_size_8_output_tmp_6e2d1_11[0], xor_col18];
                *lookup_data.verify_bitwise_xor_8_b_5 = [
                    M31_521092554,
                    xor_col17,
                    split_16_low_part_size_8_output_tmp_6e2d1_11[0],
                    xor_col18,
                ];

                // Bitwise Xor Num Bits 8 B.

                let xor_tmp_6e2d1_24 = ((PackedUInt16::from_m31(ms_8_bits_col8))
                    ^ (PackedUInt16::from_m31(ms_8_bits_col10)));
                let xor_col19 = xor_tmp_6e2d1_24.as_m31();
                *row[19] = xor_col19;
                *sub_component_inputs.verify_bitwise_xor_8_b[2] =
                    [ms_8_bits_col8, ms_8_bits_col10, xor_col19];
                *lookup_data.verify_bitwise_xor_8_b_6 =
                    [M31_521092554, ms_8_bits_col8, ms_8_bits_col10, xor_col19];

                // Bitwise Xor Num Bits 8 B.

                let xor_tmp_6e2d1_26 = ((PackedUInt16::from_m31(xor_col19))
                    ^ (PackedUInt16::from_m31(ms_8_bits_col12)));
                let xor_col20 = xor_tmp_6e2d1_26.as_m31();
                *row[20] = xor_col20;
                *sub_component_inputs.verify_bitwise_xor_8_b[3] =
                    [xor_col19, ms_8_bits_col12, xor_col20];
                *lookup_data.verify_bitwise_xor_8_b_7 =
                    [M31_521092554, xor_col19, ms_8_bits_col12, xor_col20];

                let triple_xor32_output_tmp_6e2d1_28 = PackedUInt32::from_limbs([
                    ((xor_col14) + ((xor_col16) * (M31_256))),
                    ((xor_col18) + ((xor_col20) * (M31_256))),
                ]);
                *lookup_data.triple_xor_32_8 = [
                    M31_990559919,
                    input_limb_0_col1,
                    input_limb_1_col2,
                    input_limb_2_col3,
                    input_limb_3_col4,
                    input_limb_4_col5,
                    input_limb_5_col6,
                    triple_xor32_output_tmp_6e2d1_28.low().as_m31(),
                    triple_xor32_output_tmp_6e2d1_28.high().as_m31(),
                ];
                *lookup_data.mults_0 = enabler_col0;
            },
        );

    (trace, lookup_data, sub_component_inputs)
}

#[derive(Uninitialized, IterMut, ParIterMut)]
struct LookupData {
    verify_bitwise_xor_8_0: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_1: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_2: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_3: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_b_4: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_b_5: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_b_6: Vec<[PackedM31; 4]>,
    verify_bitwise_xor_8_b_7: Vec<[PackedM31; 4]>,
    triple_xor_32_8: Vec<[PackedM31; 9]>,
    mults_0: Vec<PackedM31>,
}

pub struct InteractionClaimGenerator {
    log_size: u32,
    lookup_data: LookupData,
}
impl InteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        common_lookup_elements: &relations::CommonLookupElements,
    ) -> (Vec<CircleEvaluation<SimdBackend, M31, BitReversedOrder>>, InteractionClaim) {
        let mut logup_gen = unsafe { LogupTraceGenerator::uninitialized(self.log_size) };

        // Sum logup terms in pairs.
        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_bitwise_xor_8_0,
            &self.lookup_data.verify_bitwise_xor_8_1,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_bitwise_xor_8_2,
            &self.lookup_data.verify_bitwise_xor_8_3,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_bitwise_xor_8_b_4,
            &self.lookup_data.verify_bitwise_xor_8_b_5,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        let mut col_gen = logup_gen.new_col();
        (
            col_gen.par_iter_mut(),
            &self.lookup_data.verify_bitwise_xor_8_b_6,
            &self.lookup_data.verify_bitwise_xor_8_b_7,
            &self.lookup_data.mults_0,
            &self.lookup_data.mults_0,
        )
            .into_par_iter()
            .for_each(|(writer, values0, values1, mult0, mult1)| {
                let denom0: PackedQM31 = common_lookup_elements.combine(values0);
                let denom1: PackedQM31 = common_lookup_elements.combine(values1);
                writer.write_frac(denom0 * *mult1 + denom1 * *mult0, denom0 * denom1);
            });
        col_gen.finalize_col();

        // Sum last logup term.
        let mut col_gen = logup_gen.new_col();
        (col_gen.par_iter_mut(), &self.lookup_data.triple_xor_32_8, self.lookup_data.mults_0)
            .into_par_iter()
            .for_each(|(writer, values, mult)| {
                let denom = common_lookup_elements.combine(values);
                writer.write_frac((-mult).into(), denom);
            });
        col_gen.finalize_col();

        let (trace, claimed_sum) = logup_gen.finalize_last();

        (trace, InteractionClaim { claimed_sum })
    }
}
