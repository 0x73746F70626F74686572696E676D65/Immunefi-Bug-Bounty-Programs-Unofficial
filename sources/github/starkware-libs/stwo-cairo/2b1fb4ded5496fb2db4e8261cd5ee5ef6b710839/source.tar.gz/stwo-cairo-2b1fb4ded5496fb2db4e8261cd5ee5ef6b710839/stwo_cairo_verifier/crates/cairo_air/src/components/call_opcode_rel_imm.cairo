// This file was created by the AIR team.

use crate::components::subroutines::decode_instruction_e4e14::decode_instruction_e4e14_evaluate;
use crate::components::subroutines::read_positive_num_bits_29::read_positive_num_bits_29_evaluate;
use crate::components::subroutines::read_small::read_small_evaluate;
use crate::prelude::*;

pub const N_TRACE_COLUMNS: usize = 24;
pub const N_INTERACTION_COLUMNS: usize = 20;
pub const RELATION_USES_PER_ROW: [(felt252, u32); 4] = [
    ('VerifyInstruction', 1), ('MemoryAddressToId', 3), ('MemoryIdToBig', 3), ('Opcodes', 1),
];

#[derive(Drop, Serde, Copy)]
pub struct Claim {
    pub log_size: u32,
}

pub impl ClaimImpl of ClaimTrait<Claim> {
    fn log_sizes(self: @Claim) -> TreeArray<Span<u32>> {
        let log_size = *(self.log_size);
        let preprocessed_log_sizes = array![log_size].span();
        let trace_log_sizes = [log_size; N_TRACE_COLUMNS].span();
        let interaction_log_sizes = [log_size; N_INTERACTION_COLUMNS].span();
        array![preprocessed_log_sizes, trace_log_sizes, interaction_log_sizes]
    }

    fn mix_into(self: @Claim, ref channel: Channel) {
        channel.mix_u64((*(self.log_size)).into());
    }

    fn accumulate_relation_uses(self: @Claim, ref relation_uses: RelationUsesDict) {
        accumulate_relation_uses(ref relation_uses, RELATION_USES_PER_ROW.span(), *self.log_size);
    }
}


#[derive(Drop)]
pub struct Component {
    pub claim: Claim,
    pub claimed_sum: QM31,
    pub common_lookup_elements: CommonLookupElements,
}

pub impl NewComponentImpl of NewComponent<Component> {
    type Claim = Claim;

    fn new(
        claim: @Claim, claimed_sum: QM31, common_lookup_elements: @CommonLookupElements,
    ) -> Component {
        Component {
            claim: *claim, claimed_sum, common_lookup_elements: common_lookup_elements.clone(),
        }
    }
}

pub impl AirComponentImpl of AirComponent<Component> {
    fn evaluate_constraints_at_point(
        self: @Component,
        ref sum: QM31,
        ref preprocessed_mask_values: PreprocessedMaskValues,
        ref trace_mask_values: ColumnSpan<Span<QM31>>,
        ref interaction_trace_mask_values: ColumnSpan<Span<QM31>>,
        random_coeff: QM31,
        public_params: Span<u32>,
    ) {
        let log_size = *(self.claim.log_size);
        let claimed_sum = *self.claimed_sum;
        let column_size = m31(pow2(log_size));
        let mut verify_instruction_sum_0: QM31 = Zero::zero();
        let mut numerator_0: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_1: QM31 = Zero::zero();
        let mut numerator_1: QM31 = Zero::zero();
        let mut memory_id_to_big_sum_2: QM31 = Zero::zero();
        let mut numerator_2: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_3: QM31 = Zero::zero();
        let mut numerator_3: QM31 = Zero::zero();
        let mut memory_id_to_big_sum_4: QM31 = Zero::zero();
        let mut numerator_4: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_5: QM31 = Zero::zero();
        let mut numerator_5: QM31 = Zero::zero();
        let mut memory_id_to_big_sum_6: QM31 = Zero::zero();
        let mut numerator_6: QM31 = Zero::zero();
        let mut opcodes_sum_7: QM31 = Zero::zero();
        let mut numerator_7: QM31 = Zero::zero();
        let mut opcodes_sum_8: QM31 = Zero::zero();
        let mut numerator_8: QM31 = Zero::zero();

        let [
            enabler_col0,
            input_pc_col1,
            input_ap_col2,
            input_fp_col3,
            stored_fp_id_col4,
            stored_fp_limb_0_col5,
            stored_fp_limb_1_col6,
            stored_fp_limb_2_col7,
            stored_fp_limb_3_col8,
            partial_limb_msb_col9,
            stored_ret_pc_id_col10,
            stored_ret_pc_limb_0_col11,
            stored_ret_pc_limb_1_col12,
            stored_ret_pc_limb_2_col13,
            stored_ret_pc_limb_3_col14,
            partial_limb_msb_col15,
            distance_to_next_pc_id_col16,
            msb_col17,
            mid_limbs_set_col18,
            distance_to_next_pc_limb_0_col19,
            distance_to_next_pc_limb_1_col20,
            distance_to_next_pc_limb_2_col21,
            remainder_bits_col22,
            partial_limb_msb_col23,
        ]: [Span<QM31>; 24] =
            (*trace_mask_values
            .multi_pop_front()
            .unwrap())
            .unbox();
        let [enabler_col0]: [QM31; 1] = (*enabler_col0.try_into().unwrap()).unbox();
        let [input_pc_col1]: [QM31; 1] = (*input_pc_col1.try_into().unwrap()).unbox();
        let [input_ap_col2]: [QM31; 1] = (*input_ap_col2.try_into().unwrap()).unbox();
        let [input_fp_col3]: [QM31; 1] = (*input_fp_col3.try_into().unwrap()).unbox();
        let [stored_fp_id_col4]: [QM31; 1] = (*stored_fp_id_col4.try_into().unwrap()).unbox();
        let [stored_fp_limb_0_col5]: [QM31; 1] = (*stored_fp_limb_0_col5.try_into().unwrap())
            .unbox();
        let [stored_fp_limb_1_col6]: [QM31; 1] = (*stored_fp_limb_1_col6.try_into().unwrap())
            .unbox();
        let [stored_fp_limb_2_col7]: [QM31; 1] = (*stored_fp_limb_2_col7.try_into().unwrap())
            .unbox();
        let [stored_fp_limb_3_col8]: [QM31; 1] = (*stored_fp_limb_3_col8.try_into().unwrap())
            .unbox();
        let [partial_limb_msb_col9]: [QM31; 1] = (*partial_limb_msb_col9.try_into().unwrap())
            .unbox();
        let [stored_ret_pc_id_col10]: [QM31; 1] = (*stored_ret_pc_id_col10.try_into().unwrap())
            .unbox();
        let [stored_ret_pc_limb_0_col11]: [QM31; 1] = (*stored_ret_pc_limb_0_col11
            .try_into()
            .unwrap())
            .unbox();
        let [stored_ret_pc_limb_1_col12]: [QM31; 1] = (*stored_ret_pc_limb_1_col12
            .try_into()
            .unwrap())
            .unbox();
        let [stored_ret_pc_limb_2_col13]: [QM31; 1] = (*stored_ret_pc_limb_2_col13
            .try_into()
            .unwrap())
            .unbox();
        let [stored_ret_pc_limb_3_col14]: [QM31; 1] = (*stored_ret_pc_limb_3_col14
            .try_into()
            .unwrap())
            .unbox();
        let [partial_limb_msb_col15]: [QM31; 1] = (*partial_limb_msb_col15.try_into().unwrap())
            .unbox();
        let [distance_to_next_pc_id_col16]: [QM31; 1] = (*distance_to_next_pc_id_col16
            .try_into()
            .unwrap())
            .unbox();
        let [msb_col17]: [QM31; 1] = (*msb_col17.try_into().unwrap()).unbox();
        let [mid_limbs_set_col18]: [QM31; 1] = (*mid_limbs_set_col18.try_into().unwrap()).unbox();
        let [distance_to_next_pc_limb_0_col19]: [QM31; 1] = (*distance_to_next_pc_limb_0_col19
            .try_into()
            .unwrap())
            .unbox();
        let [distance_to_next_pc_limb_1_col20]: [QM31; 1] = (*distance_to_next_pc_limb_1_col20
            .try_into()
            .unwrap())
            .unbox();
        let [distance_to_next_pc_limb_2_col21]: [QM31; 1] = (*distance_to_next_pc_limb_2_col21
            .try_into()
            .unwrap())
            .unbox();
        let [remainder_bits_col22]: [QM31; 1] = (*remainder_bits_col22.try_into().unwrap()).unbox();
        let [partial_limb_msb_col23]: [QM31; 1] = (*partial_limb_msb_col23.try_into().unwrap())
            .unbox();

        core::internal::revoke_ap_tracking();

        // Constraint - Enabler is a bit
        let constraint_quotient = (((enabler_col0 * enabler_col0) - enabler_col0));
        sum = sum * random_coeff + constraint_quotient;
        decode_instruction_e4e14_evaluate(
            input_pc_col1,
            enabler_col0,
            self.common_lookup_elements,
            ref verify_instruction_sum_0,
            ref numerator_0,
            ref sum,
            random_coeff,
        );
        read_positive_num_bits_29_evaluate(
            input_ap_col2,
            enabler_col0,
            stored_fp_id_col4,
            stored_fp_limb_0_col5,
            stored_fp_limb_1_col6,
            stored_fp_limb_2_col7,
            stored_fp_limb_3_col8,
            partial_limb_msb_col9,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_1,
            ref numerator_1,
            ref memory_id_to_big_sum_2,
            ref numerator_2,
            ref sum,
            random_coeff,
        );

        // Constraint - [ap] = fp
        let constraint_quotient = (((((stored_fp_limb_0_col5
            + (stored_fp_limb_1_col6 * qm31_const::<512, 0, 0, 0>()))
            + (stored_fp_limb_2_col7 * qm31_const::<262144, 0, 0, 0>()))
            + (stored_fp_limb_3_col8 * qm31_const::<134217728, 0, 0, 0>()))
            - input_fp_col3));
        sum = sum * random_coeff + constraint_quotient;
        read_positive_num_bits_29_evaluate(
            (input_ap_col2 + qm31_const::<1, 0, 0, 0>()),
            enabler_col0,
            stored_ret_pc_id_col10,
            stored_ret_pc_limb_0_col11,
            stored_ret_pc_limb_1_col12,
            stored_ret_pc_limb_2_col13,
            stored_ret_pc_limb_3_col14,
            partial_limb_msb_col15,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_3,
            ref numerator_3,
            ref memory_id_to_big_sum_4,
            ref numerator_4,
            ref sum,
            random_coeff,
        );

        // Constraint - [ap+1] = return_pc
        let constraint_quotient = (((((stored_ret_pc_limb_0_col11
            + (stored_ret_pc_limb_1_col12 * qm31_const::<512, 0, 0, 0>()))
            + (stored_ret_pc_limb_2_col13 * qm31_const::<262144, 0, 0, 0>()))
            + (stored_ret_pc_limb_3_col14 * qm31_const::<134217728, 0, 0, 0>()))
            - (input_pc_col1 + qm31_const::<2, 0, 0, 0>())));
        sum = sum * random_coeff + constraint_quotient;
        let read_small_output_tmp_82d62_26_limb_0: QM31 = read_small_evaluate(
            (input_pc_col1 + qm31_const::<1, 0, 0, 0>()),
            enabler_col0,
            distance_to_next_pc_id_col16,
            msb_col17,
            mid_limbs_set_col18,
            distance_to_next_pc_limb_0_col19,
            distance_to_next_pc_limb_1_col20,
            distance_to_next_pc_limb_2_col21,
            remainder_bits_col22,
            partial_limb_msb_col23,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_5,
            ref numerator_5,
            ref memory_id_to_big_sum_6,
            ref numerator_6,
            ref sum,
            random_coeff,
        );

        opcodes_sum_7 = self
            .common_lookup_elements
            .combine_qm31(
                [qm31_const::<428564188, 0, 0, 0>(), input_pc_col1, input_ap_col2, input_fp_col3]
                    .span(),
            );
        numerator_7 = enabler_col0;

        opcodes_sum_8 = self
            .common_lookup_elements
            .combine_qm31(
                [
                    qm31_const::<428564188, 0, 0, 0>(),
                    (input_pc_col1 + read_small_output_tmp_82d62_26_limb_0),
                    (input_ap_col2 + qm31_const::<2, 0, 0, 0>()),
                    (input_ap_col2 + qm31_const::<2, 0, 0, 0>()),
                ]
                    .span(),
            );
        numerator_8 = enabler_col0;

        lookup_constraints(
            ref sum,
            random_coeff,
            claimed_sum,
            numerator_0,
            numerator_1,
            numerator_2,
            numerator_3,
            numerator_4,
            numerator_5,
            numerator_6,
            numerator_7,
            numerator_8,
            column_size,
            ref interaction_trace_mask_values,
            verify_instruction_sum_0,
            memory_address_to_id_sum_1,
            memory_id_to_big_sum_2,
            memory_address_to_id_sum_3,
            memory_id_to_big_sum_4,
            memory_address_to_id_sum_5,
            memory_id_to_big_sum_6,
            opcodes_sum_7,
            opcodes_sum_8,
        );
    }
}


fn lookup_constraints(
    ref sum: QM31,
    random_coeff: QM31,
    claimed_sum: QM31,
    numerator_0: QM31,
    numerator_1: QM31,
    numerator_2: QM31,
    numerator_3: QM31,
    numerator_4: QM31,
    numerator_5: QM31,
    numerator_6: QM31,
    numerator_7: QM31,
    numerator_8: QM31,
    column_size: M31,
    ref interaction_trace_mask_values: ColumnSpan<Span<QM31>>,
    verify_instruction_sum_0: QM31,
    memory_address_to_id_sum_1: QM31,
    memory_id_to_big_sum_2: QM31,
    memory_address_to_id_sum_3: QM31,
    memory_id_to_big_sum_4: QM31,
    memory_address_to_id_sum_5: QM31,
    memory_id_to_big_sum_6: QM31,
    opcodes_sum_7: QM31,
    opcodes_sum_8: QM31,
) {
    let [
        trace_2_col0,
        trace_2_col1,
        trace_2_col2,
        trace_2_col3,
        trace_2_col4,
        trace_2_col5,
        trace_2_col6,
        trace_2_col7,
        trace_2_col8,
        trace_2_col9,
        trace_2_col10,
        trace_2_col11,
        trace_2_col12,
        trace_2_col13,
        trace_2_col14,
        trace_2_col15,
        trace_2_col16,
        trace_2_col17,
        trace_2_col18,
        trace_2_col19,
    ]: [Span<QM31>; 20] =
        (*interaction_trace_mask_values
        .multi_pop_front()
        .unwrap())
        .unbox();

    let [trace_2_col0]: [QM31; 1] = (*trace_2_col0.try_into().unwrap()).unbox();
    let [trace_2_col1]: [QM31; 1] = (*trace_2_col1.try_into().unwrap()).unbox();
    let [trace_2_col2]: [QM31; 1] = (*trace_2_col2.try_into().unwrap()).unbox();
    let [trace_2_col3]: [QM31; 1] = (*trace_2_col3.try_into().unwrap()).unbox();
    let [trace_2_col4]: [QM31; 1] = (*trace_2_col4.try_into().unwrap()).unbox();
    let [trace_2_col5]: [QM31; 1] = (*trace_2_col5.try_into().unwrap()).unbox();
    let [trace_2_col6]: [QM31; 1] = (*trace_2_col6.try_into().unwrap()).unbox();
    let [trace_2_col7]: [QM31; 1] = (*trace_2_col7.try_into().unwrap()).unbox();
    let [trace_2_col8]: [QM31; 1] = (*trace_2_col8.try_into().unwrap()).unbox();
    let [trace_2_col9]: [QM31; 1] = (*trace_2_col9.try_into().unwrap()).unbox();
    let [trace_2_col10]: [QM31; 1] = (*trace_2_col10.try_into().unwrap()).unbox();
    let [trace_2_col11]: [QM31; 1] = (*trace_2_col11.try_into().unwrap()).unbox();
    let [trace_2_col12]: [QM31; 1] = (*trace_2_col12.try_into().unwrap()).unbox();
    let [trace_2_col13]: [QM31; 1] = (*trace_2_col13.try_into().unwrap()).unbox();
    let [trace_2_col14]: [QM31; 1] = (*trace_2_col14.try_into().unwrap()).unbox();
    let [trace_2_col15]: [QM31; 1] = (*trace_2_col15.try_into().unwrap()).unbox();
    let [trace_2_col16_neg1, trace_2_col16]: [QM31; 2] = (*trace_2_col16.try_into().unwrap())
        .unbox();
    let [trace_2_col17_neg1, trace_2_col17]: [QM31; 2] = (*trace_2_col17.try_into().unwrap())
        .unbox();
    let [trace_2_col18_neg1, trace_2_col18]: [QM31; 2] = (*trace_2_col18.try_into().unwrap())
        .unbox();
    let [trace_2_col19_neg1, trace_2_col19]: [QM31; 2] = (*trace_2_col19.try_into().unwrap())
        .unbox();

    core::internal::revoke_ap_tracking();

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col0, trace_2_col1, trace_2_col2, trace_2_col3],
    ))
        * verify_instruction_sum_0
        * memory_address_to_id_sum_1)
        - (verify_instruction_sum_0 * numerator_1)
        - (memory_address_to_id_sum_1 * numerator_0));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col4, trace_2_col5, trace_2_col6, trace_2_col7],
    )
        - QM31Impl::from_partial_evals([trace_2_col0, trace_2_col1, trace_2_col2, trace_2_col3]))
        * memory_id_to_big_sum_2
        * memory_address_to_id_sum_3)
        - (memory_id_to_big_sum_2 * numerator_3)
        - (memory_address_to_id_sum_3 * numerator_2));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col8, trace_2_col9, trace_2_col10, trace_2_col11],
    )
        - QM31Impl::from_partial_evals([trace_2_col4, trace_2_col5, trace_2_col6, trace_2_col7]))
        * memory_id_to_big_sum_4
        * memory_address_to_id_sum_5)
        - (memory_id_to_big_sum_4 * numerator_5)
        - (memory_address_to_id_sum_5 * numerator_4));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col12, trace_2_col13, trace_2_col14, trace_2_col15],
    )
        - QM31Impl::from_partial_evals([trace_2_col8, trace_2_col9, trace_2_col10, trace_2_col11]))
        * memory_id_to_big_sum_6
        * opcodes_sum_7)
        - (memory_id_to_big_sum_6 * numerator_7)
        - (opcodes_sum_7 * numerator_6));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col16, trace_2_col17, trace_2_col18, trace_2_col19],
    )
        - QM31Impl::from_partial_evals([trace_2_col12, trace_2_col13, trace_2_col14, trace_2_col15])
        - QM31Impl::from_partial_evals(
            [trace_2_col16_neg1, trace_2_col17_neg1, trace_2_col18_neg1, trace_2_col19_neg1],
        )
        + (claimed_sum * (column_size.inverse().into())))
        * opcodes_sum_8)
        + numerator_8);
    sum = sum * random_coeff + constraint_quotient;
}
#[cfg(and(test, feature: "qm31_opcode"))]
mod tests {
    use core::array::ArrayImpl;
    use core::num::traits::Zero;
    use stwo_constraint_framework::AirComponent;
    #[allow(unused_imports)]
    use stwo_constraint_framework::test_utils::{make_interaction_trace, preprocessed_mask_add};
    #[allow(unused_imports)]
    use stwo_constraint_framework::{
        LookupElementsTrait, PreprocessedMaskValues, PreprocessedMaskValuesTrait,
    };
    use stwo_verifier_core::fields::qm31::{QM31, QM31Impl, QM31Trait, qm31_const};
    use crate::components::sample_evaluations::*;
    #[allow(unused_imports)]
    use crate::preprocessed_columns::*;
    use super::{Claim, Component};

    #[test]
    fn test_evaluation_result() {
        let component = Component {
            claim: Claim { log_size: 15 },
            claimed_sum: qm31_const::<1398335417, 314974026, 1722107152, 821933968>(),
            common_lookup_elements: LookupElementsTrait::from_z_alpha(
                qm31_const::<445623802, 202571636, 1360224996, 131355117>(),
                qm31_const::<476823935, 939223384, 62486082, 122423602>(),
            ),
        };
        let public_params = [].span();
        let mut sum: QM31 = Zero::zero();

        let mut preprocessed_trace = PreprocessedMaskValues { values: Default::default() };

        let mut trace_columns = [
            [qm31_const::<1659099300, 905558730, 651199673, 1375009625>()].span(),
            [qm31_const::<1591990121, 771341002, 584090809, 1375009625>()].span(),
            [qm31_const::<1793317658, 1173994186, 785417401, 1375009625>()].span(),
            [qm31_const::<1726208479, 1039776458, 718308537, 1375009625>()].span(),
            [qm31_const::<1390662584, 368687818, 382764217, 1375009625>()].span(),
            [qm31_const::<1323553405, 234470090, 315655353, 1375009625>()].span(),
            [qm31_const::<1524880942, 637123274, 516981945, 1375009625>()].span(),
            [qm31_const::<1457771763, 502905546, 449873081, 1375009625>()].span(),
            [qm31_const::<48489085, 1979300555, 1188070585, 1375009625>()].span(),
            [qm31_const::<2128863553, 1845082826, 1120961721, 1375009625>()].span(),
            [qm31_const::<1852335767, 645078115, 2059236183, 343880121>()].span(),
            [qm31_const::<1919444946, 779295843, 2126345047, 343880121>()].span(),
            [qm31_const::<1986554125, 913513571, 45970264, 343880122>()].span(),
            [qm31_const::<2053663304, 1047731299, 113079128, 343880122>()].span(),
            [qm31_const::<1583899051, 108207203, 1790800727, 343880121>()].span(),
            [qm31_const::<1651008230, 242424931, 1857909591, 343880121>()].span(),
            [qm31_const::<1718117409, 376642659, 1925018455, 343880121>()].span(),
            [qm31_const::<1785226588, 510860387, 1992127319, 343880121>()].span(),
            [qm31_const::<1315462335, 1718819938, 1522365270, 343880121>()].span(),
            [qm31_const::<1382571514, 1853037666, 1589474134, 343880121>()].span(),
            [qm31_const::<1986820986, 913513739, 45970432, 343880178>()].span(),
            [qm31_const::<1919711807, 779296011, 2126345215, 343880177>()].span(),
            [qm31_const::<2121039344, 1181949195, 180188160, 343880178>()].span(),
            [qm31_const::<2053930165, 1047731467, 113079296, 343880178>()].span(),
        ]
            .span();
        let interaction_values = array![
            qm31_const::<1005168032, 79980996, 1847888101, 1941984119>(),
            qm31_const::<1072277211, 214198724, 1914996965, 1941984119>(),
            qm31_const::<1139386390, 348416452, 1982105829, 1941984119>(),
            qm31_const::<1206495569, 482634180, 2049214693, 1941984119>(),
            qm31_const::<736731316, 1690593731, 1579452644, 1941984119>(),
        ];
        let mut interaction_columns = make_interaction_trace(
            interaction_values, qm31_const::<1115374022, 1127856551, 489657863, 643630026>(),
        );
        component
            .evaluate_constraints_at_point(
                ref sum,
                ref preprocessed_trace,
                ref trace_columns,
                ref interaction_columns,
                qm31_const::<474642921, 876336632, 1911695779, 974600512>(),
                public_params,
            );
        preprocessed_trace.validate_usage();
        assert_eq!(sum, QM31Trait::from_fixed_array(CALL_OPCODE_REL_IMM_SAMPLE_EVAL_RESULT))
    }
}
