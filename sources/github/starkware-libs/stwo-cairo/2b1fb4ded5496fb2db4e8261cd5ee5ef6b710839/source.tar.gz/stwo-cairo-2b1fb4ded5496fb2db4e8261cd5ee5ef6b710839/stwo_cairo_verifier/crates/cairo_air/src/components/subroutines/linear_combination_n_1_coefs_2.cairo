// This file was created by the AIR team.

use crate::prelude::*;


pub fn linear_combination_n_1_coefs_2_evaluate(
    input: [QM31; 10],
    enabler: QM31,
    combination_limb_0_col0: QM31,
    combination_limb_1_col1: QM31,
    combination_limb_2_col2: QM31,
    combination_limb_3_col3: QM31,
    combination_limb_4_col4: QM31,
    combination_limb_5_col5: QM31,
    combination_limb_6_col6: QM31,
    combination_limb_7_col7: QM31,
    combination_limb_8_col8: QM31,
    combination_limb_9_col9: QM31,
    p_coef_col10: QM31,
    common_lookup_elements: @CommonLookupElements,
    ref sum: QM31,
    random_coeff: QM31,
) -> [QM31; 0] {
    let [
        linear_combination_n_1_coefs_2_input_limb_0,
        linear_combination_n_1_coefs_2_input_limb_1,
        linear_combination_n_1_coefs_2_input_limb_2,
        linear_combination_n_1_coefs_2_input_limb_3,
        linear_combination_n_1_coefs_2_input_limb_4,
        linear_combination_n_1_coefs_2_input_limb_5,
        linear_combination_n_1_coefs_2_input_limb_6,
        linear_combination_n_1_coefs_2_input_limb_7,
        linear_combination_n_1_coefs_2_input_limb_8,
        linear_combination_n_1_coefs_2_input_limb_9,
    ] =
        input;
    let carry_0_tmp_e3263_2: QM31 = ((((qm31_const::<2, 0, 0, 0>()
        * linear_combination_n_1_coefs_2_input_limb_0)
        - combination_limb_0_col0)
        - p_coef_col10)
        * qm31_const::<16, 0, 0, 0>());
    let carry_1_tmp_e3263_3: QM31 = (((carry_0_tmp_e3263_2
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_1))
        - combination_limb_1_col1)
        * qm31_const::<16, 0, 0, 0>());
    let carry_2_tmp_e3263_4: QM31 = (((carry_1_tmp_e3263_3
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_2))
        - combination_limb_2_col2)
        * qm31_const::<16, 0, 0, 0>());
    let carry_3_tmp_e3263_5: QM31 = (((carry_2_tmp_e3263_4
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_3))
        - combination_limb_3_col3)
        * qm31_const::<16, 0, 0, 0>());
    let carry_4_tmp_e3263_6: QM31 = (((carry_3_tmp_e3263_5
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_4))
        - combination_limb_4_col4)
        * qm31_const::<16, 0, 0, 0>());
    let carry_5_tmp_e3263_7: QM31 = (((carry_4_tmp_e3263_6
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_5))
        - combination_limb_5_col5)
        * qm31_const::<16, 0, 0, 0>());
    let carry_6_tmp_e3263_8: QM31 = (((carry_5_tmp_e3263_7
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_6))
        - combination_limb_6_col6)
        * qm31_const::<16, 0, 0, 0>());
    let carry_7_tmp_e3263_9: QM31 = ((((carry_6_tmp_e3263_8
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_7))
        - combination_limb_7_col7)
        - (p_coef_col10 * qm31_const::<136, 0, 0, 0>()))
        * qm31_const::<16, 0, 0, 0>());
    let carry_8_tmp_e3263_10: QM31 = (((carry_7_tmp_e3263_9
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_8))
        - combination_limb_8_col8)
        * qm31_const::<16, 0, 0, 0>());

    // Constraint - final limb constraint
    let constraint_quotient = ((((carry_8_tmp_e3263_10
        + (qm31_const::<2, 0, 0, 0>() * linear_combination_n_1_coefs_2_input_limb_9))
        - combination_limb_9_col9)
        - (p_coef_col10 * qm31_const::<256, 0, 0, 0>())));
    sum = sum * random_coeff + constraint_quotient;

    // Constraint - carry constraint 0
    let constraint_quotient = ((((p_coef_col10 * p_coef_col10) * p_coef_col10) - p_coef_col10));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_1_tmp_e3263_11: QM31 = carry_0_tmp_e3263_2;

    // Constraint - carry constraint 1
    let constraint_quotient = ((((biased_carry_1_tmp_e3263_11 * biased_carry_1_tmp_e3263_11)
        * biased_carry_1_tmp_e3263_11)
        - biased_carry_1_tmp_e3263_11));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_2_tmp_e3263_12: QM31 = carry_1_tmp_e3263_3;

    // Constraint - carry constraint 2
    let constraint_quotient = ((((biased_carry_2_tmp_e3263_12 * biased_carry_2_tmp_e3263_12)
        * biased_carry_2_tmp_e3263_12)
        - biased_carry_2_tmp_e3263_12));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_3_tmp_e3263_13: QM31 = carry_2_tmp_e3263_4;

    // Constraint - carry constraint 3
    let constraint_quotient = ((((biased_carry_3_tmp_e3263_13 * biased_carry_3_tmp_e3263_13)
        * biased_carry_3_tmp_e3263_13)
        - biased_carry_3_tmp_e3263_13));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_4_tmp_e3263_14: QM31 = carry_3_tmp_e3263_5;

    // Constraint - carry constraint 4
    let constraint_quotient = ((((biased_carry_4_tmp_e3263_14 * biased_carry_4_tmp_e3263_14)
        * biased_carry_4_tmp_e3263_14)
        - biased_carry_4_tmp_e3263_14));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_5_tmp_e3263_15: QM31 = carry_4_tmp_e3263_6;

    // Constraint - carry constraint 5
    let constraint_quotient = ((((biased_carry_5_tmp_e3263_15 * biased_carry_5_tmp_e3263_15)
        * biased_carry_5_tmp_e3263_15)
        - biased_carry_5_tmp_e3263_15));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_6_tmp_e3263_16: QM31 = carry_5_tmp_e3263_7;

    // Constraint - carry constraint 6
    let constraint_quotient = ((((biased_carry_6_tmp_e3263_16 * biased_carry_6_tmp_e3263_16)
        * biased_carry_6_tmp_e3263_16)
        - biased_carry_6_tmp_e3263_16));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_7_tmp_e3263_17: QM31 = carry_6_tmp_e3263_8;

    // Constraint - carry constraint 7
    let constraint_quotient = ((((biased_carry_7_tmp_e3263_17 * biased_carry_7_tmp_e3263_17)
        * biased_carry_7_tmp_e3263_17)
        - biased_carry_7_tmp_e3263_17));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_8_tmp_e3263_18: QM31 = carry_7_tmp_e3263_9;

    // Constraint - carry constraint 8
    let constraint_quotient = ((((biased_carry_8_tmp_e3263_18 * biased_carry_8_tmp_e3263_18)
        * biased_carry_8_tmp_e3263_18)
        - biased_carry_8_tmp_e3263_18));
    sum = sum * random_coeff + constraint_quotient;
    let biased_carry_9_tmp_e3263_19: QM31 = carry_8_tmp_e3263_10;

    // Constraint - carry constraint 9
    let constraint_quotient = ((((biased_carry_9_tmp_e3263_19 * biased_carry_9_tmp_e3263_19)
        * biased_carry_9_tmp_e3263_19)
        - biased_carry_9_tmp_e3263_19));
    sum = sum * random_coeff + constraint_quotient;

    []
}
