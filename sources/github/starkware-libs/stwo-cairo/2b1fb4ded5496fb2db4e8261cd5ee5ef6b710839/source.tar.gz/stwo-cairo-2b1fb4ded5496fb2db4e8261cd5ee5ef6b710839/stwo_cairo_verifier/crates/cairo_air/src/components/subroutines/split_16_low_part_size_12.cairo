// This file was created by the AIR team.

use crate::prelude::*;


pub fn split_16_low_part_size_12_evaluate(
    input: QM31,
    enabler: QM31,
    ms_4_bits_col0: QM31,
    common_lookup_elements: @CommonLookupElements,
    ref sum: QM31,
    random_coeff: QM31,
) -> QM31 {
    let split_16_low_part_size_12_input = input;

    (split_16_low_part_size_12_input - (ms_4_bits_col0 * qm31_const::<4096, 0, 0, 0>()))
}
