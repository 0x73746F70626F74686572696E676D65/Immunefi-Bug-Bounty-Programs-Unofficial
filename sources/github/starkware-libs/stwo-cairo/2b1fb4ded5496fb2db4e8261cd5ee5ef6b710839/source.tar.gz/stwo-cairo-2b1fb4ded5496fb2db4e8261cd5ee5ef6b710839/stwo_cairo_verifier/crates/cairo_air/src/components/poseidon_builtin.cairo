// This file was created by the AIR team.

use crate::components::subroutines::read_id::read_id_evaluate;
use crate::prelude::*;

pub const N_TRACE_COLUMNS: usize = 6;
pub const N_INTERACTION_COLUMNS: usize = 16;
pub const RELATION_USES_PER_ROW: [(felt252, u32); 2] = [
    ('MemoryAddressToId', 6), ('PoseidonAggregator', 1),
];

#[derive(Drop, Serde, Copy)]
pub struct Claim {
    pub log_size: u32,
}

pub impl ClaimImpl of ClaimTrait<Claim> {
    fn log_sizes(self: @Claim) -> TreeArray<Span<u32>> {
        let log_size = *(self.log_size);
        let preprocessed_log_sizes = array![log_size].span();
        let trace_log_sizes = [log_size; N_TRACE_COLUMNS].span();
        let interaction_log_sizes = [log_size; N_INTERACTION_COLUMNS].span();
        array![preprocessed_log_sizes, trace_log_sizes, interaction_log_sizes]
    }

    fn mix_into(self: @Claim, ref channel: Channel) {
        channel.mix_u64((*(self.log_size)).into());
    }

    fn accumulate_relation_uses(self: @Claim, ref relation_uses: RelationUsesDict) {
        accumulate_relation_uses(ref relation_uses, RELATION_USES_PER_ROW.span(), *self.log_size);
    }
}


#[derive(Drop)]
pub struct Component {
    pub claim: Claim,
    pub claimed_sum: QM31,
    pub common_lookup_elements: CommonLookupElements,
}

pub impl NewComponentImpl of NewComponent<Component> {
    type Claim = Claim;

    fn new(
        claim: @Claim, claimed_sum: QM31, common_lookup_elements: @CommonLookupElements,
    ) -> Component {
        Component {
            claim: *claim, claimed_sum, common_lookup_elements: common_lookup_elements.clone(),
        }
    }
}

pub impl AirComponentImpl of AirComponent<Component> {
    fn evaluate_constraints_at_point(
        self: @Component,
        ref sum: QM31,
        ref preprocessed_mask_values: PreprocessedMaskValues,
        ref trace_mask_values: ColumnSpan<Span<QM31>>,
        ref interaction_trace_mask_values: ColumnSpan<Span<QM31>>,
        random_coeff: QM31,
        public_params: Span<u32>,
    ) {
        let log_size = *(self.claim.log_size);
        let claimed_sum = *self.claimed_sum;
        let column_size = m31(pow2(log_size));
        let poseidon_builtin_segment_start: QM31 = (TryInto::<
            u32, M31,
        >::try_into((*public_params[0]))
            .unwrap())
            .into();
        let mut memory_address_to_id_sum_0: QM31 = Zero::zero();
        let mut numerator_0: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_1: QM31 = Zero::zero();
        let mut numerator_1: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_2: QM31 = Zero::zero();
        let mut numerator_2: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_3: QM31 = Zero::zero();
        let mut numerator_3: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_4: QM31 = Zero::zero();
        let mut numerator_4: QM31 = Zero::zero();
        let mut memory_address_to_id_sum_5: QM31 = Zero::zero();
        let mut numerator_5: QM31 = Zero::zero();
        let mut poseidon_aggregator_sum_6: QM31 = Zero::zero();
        let mut numerator_6: QM31 = Zero::zero();
        let seq = preprocessed_mask_values
            .get_and_mark_used(seq_column_idx(*(self.claim.log_size)));

        let [
            input_state_0_id_col0,
            input_state_1_id_col1,
            input_state_2_id_col2,
            output_state_0_id_col3,
            output_state_1_id_col4,
            output_state_2_id_col5,
        ]: [Span<QM31>; 6] =
            (*trace_mask_values
            .multi_pop_front()
            .unwrap())
            .unbox();
        let [input_state_0_id_col0]: [QM31; 1] = (*input_state_0_id_col0.try_into().unwrap())
            .unbox();
        let [input_state_1_id_col1]: [QM31; 1] = (*input_state_1_id_col1.try_into().unwrap())
            .unbox();
        let [input_state_2_id_col2]: [QM31; 1] = (*input_state_2_id_col2.try_into().unwrap())
            .unbox();
        let [output_state_0_id_col3]: [QM31; 1] = (*output_state_0_id_col3.try_into().unwrap())
            .unbox();
        let [output_state_1_id_col4]: [QM31; 1] = (*output_state_1_id_col4.try_into().unwrap())
            .unbox();
        let [output_state_2_id_col5]: [QM31; 1] = (*output_state_2_id_col5.try_into().unwrap())
            .unbox();

        core::internal::revoke_ap_tracking();

        let instance_addr_tmp_a172e_0: QM31 = ((seq * qm31_const::<6, 0, 0, 0>())
            + poseidon_builtin_segment_start);
        read_id_evaluate(
            instance_addr_tmp_a172e_0,
            qm31_const::<1, 0, 0, 0>(),
            input_state_0_id_col0,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_0,
            ref numerator_0,
            ref sum,
            random_coeff,
        );
        read_id_evaluate(
            (instance_addr_tmp_a172e_0 + qm31_const::<1, 0, 0, 0>()),
            qm31_const::<1, 0, 0, 0>(),
            input_state_1_id_col1,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_1,
            ref numerator_1,
            ref sum,
            random_coeff,
        );
        read_id_evaluate(
            (instance_addr_tmp_a172e_0 + qm31_const::<2, 0, 0, 0>()),
            qm31_const::<1, 0, 0, 0>(),
            input_state_2_id_col2,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_2,
            ref numerator_2,
            ref sum,
            random_coeff,
        );
        read_id_evaluate(
            (instance_addr_tmp_a172e_0 + qm31_const::<3, 0, 0, 0>()),
            qm31_const::<1, 0, 0, 0>(),
            output_state_0_id_col3,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_3,
            ref numerator_3,
            ref sum,
            random_coeff,
        );
        read_id_evaluate(
            (instance_addr_tmp_a172e_0 + qm31_const::<4, 0, 0, 0>()),
            qm31_const::<1, 0, 0, 0>(),
            output_state_1_id_col4,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_4,
            ref numerator_4,
            ref sum,
            random_coeff,
        );
        read_id_evaluate(
            (instance_addr_tmp_a172e_0 + qm31_const::<5, 0, 0, 0>()),
            qm31_const::<1, 0, 0, 0>(),
            output_state_2_id_col5,
            self.common_lookup_elements,
            ref memory_address_to_id_sum_5,
            ref numerator_5,
            ref sum,
            random_coeff,
        );

        poseidon_aggregator_sum_6 = self
            .common_lookup_elements
            .combine_qm31(
                [
                    qm31_const::<1551892206, 0, 0, 0>(), input_state_0_id_col0,
                    input_state_1_id_col1, input_state_2_id_col2, output_state_0_id_col3,
                    output_state_1_id_col4, output_state_2_id_col5,
                ]
                    .span(),
            );
        numerator_6 = qm31_const::<1, 0, 0, 0>();

        lookup_constraints(
            ref sum,
            random_coeff,
            claimed_sum,
            numerator_0,
            numerator_1,
            numerator_2,
            numerator_3,
            numerator_4,
            numerator_5,
            numerator_6,
            column_size,
            ref interaction_trace_mask_values,
            memory_address_to_id_sum_0,
            memory_address_to_id_sum_1,
            memory_address_to_id_sum_2,
            memory_address_to_id_sum_3,
            memory_address_to_id_sum_4,
            memory_address_to_id_sum_5,
            poseidon_aggregator_sum_6,
        );
    }
}


fn lookup_constraints(
    ref sum: QM31,
    random_coeff: QM31,
    claimed_sum: QM31,
    numerator_0: QM31,
    numerator_1: QM31,
    numerator_2: QM31,
    numerator_3: QM31,
    numerator_4: QM31,
    numerator_5: QM31,
    numerator_6: QM31,
    column_size: M31,
    ref interaction_trace_mask_values: ColumnSpan<Span<QM31>>,
    memory_address_to_id_sum_0: QM31,
    memory_address_to_id_sum_1: QM31,
    memory_address_to_id_sum_2: QM31,
    memory_address_to_id_sum_3: QM31,
    memory_address_to_id_sum_4: QM31,
    memory_address_to_id_sum_5: QM31,
    poseidon_aggregator_sum_6: QM31,
) {
    let [
        trace_2_col0,
        trace_2_col1,
        trace_2_col2,
        trace_2_col3,
        trace_2_col4,
        trace_2_col5,
        trace_2_col6,
        trace_2_col7,
        trace_2_col8,
        trace_2_col9,
        trace_2_col10,
        trace_2_col11,
        trace_2_col12,
        trace_2_col13,
        trace_2_col14,
        trace_2_col15,
    ]: [Span<QM31>; 16] =
        (*interaction_trace_mask_values
        .multi_pop_front()
        .unwrap())
        .unbox();

    let [trace_2_col0]: [QM31; 1] = (*trace_2_col0.try_into().unwrap()).unbox();
    let [trace_2_col1]: [QM31; 1] = (*trace_2_col1.try_into().unwrap()).unbox();
    let [trace_2_col2]: [QM31; 1] = (*trace_2_col2.try_into().unwrap()).unbox();
    let [trace_2_col3]: [QM31; 1] = (*trace_2_col3.try_into().unwrap()).unbox();
    let [trace_2_col4]: [QM31; 1] = (*trace_2_col4.try_into().unwrap()).unbox();
    let [trace_2_col5]: [QM31; 1] = (*trace_2_col5.try_into().unwrap()).unbox();
    let [trace_2_col6]: [QM31; 1] = (*trace_2_col6.try_into().unwrap()).unbox();
    let [trace_2_col7]: [QM31; 1] = (*trace_2_col7.try_into().unwrap()).unbox();
    let [trace_2_col8]: [QM31; 1] = (*trace_2_col8.try_into().unwrap()).unbox();
    let [trace_2_col9]: [QM31; 1] = (*trace_2_col9.try_into().unwrap()).unbox();
    let [trace_2_col10]: [QM31; 1] = (*trace_2_col10.try_into().unwrap()).unbox();
    let [trace_2_col11]: [QM31; 1] = (*trace_2_col11.try_into().unwrap()).unbox();
    let [trace_2_col12_neg1, trace_2_col12]: [QM31; 2] = (*trace_2_col12.try_into().unwrap())
        .unbox();
    let [trace_2_col13_neg1, trace_2_col13]: [QM31; 2] = (*trace_2_col13.try_into().unwrap())
        .unbox();
    let [trace_2_col14_neg1, trace_2_col14]: [QM31; 2] = (*trace_2_col14.try_into().unwrap())
        .unbox();
    let [trace_2_col15_neg1, trace_2_col15]: [QM31; 2] = (*trace_2_col15.try_into().unwrap())
        .unbox();

    core::internal::revoke_ap_tracking();

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col0, trace_2_col1, trace_2_col2, trace_2_col3],
    ))
        * memory_address_to_id_sum_0
        * memory_address_to_id_sum_1)
        - (memory_address_to_id_sum_0 * numerator_1)
        - (memory_address_to_id_sum_1 * numerator_0));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col4, trace_2_col5, trace_2_col6, trace_2_col7],
    )
        - QM31Impl::from_partial_evals([trace_2_col0, trace_2_col1, trace_2_col2, trace_2_col3]))
        * memory_address_to_id_sum_2
        * memory_address_to_id_sum_3)
        - (memory_address_to_id_sum_2 * numerator_3)
        - (memory_address_to_id_sum_3 * numerator_2));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col8, trace_2_col9, trace_2_col10, trace_2_col11],
    )
        - QM31Impl::from_partial_evals([trace_2_col4, trace_2_col5, trace_2_col6, trace_2_col7]))
        * memory_address_to_id_sum_4
        * memory_address_to_id_sum_5)
        - (memory_address_to_id_sum_4 * numerator_5)
        - (memory_address_to_id_sum_5 * numerator_4));
    sum = sum * random_coeff + constraint_quotient;

    let constraint_quotient = (((QM31Impl::from_partial_evals(
        [trace_2_col12, trace_2_col13, trace_2_col14, trace_2_col15],
    )
        - QM31Impl::from_partial_evals([trace_2_col8, trace_2_col9, trace_2_col10, trace_2_col11])
        - QM31Impl::from_partial_evals(
            [trace_2_col12_neg1, trace_2_col13_neg1, trace_2_col14_neg1, trace_2_col15_neg1],
        )
        + (claimed_sum * (column_size.inverse().into())))
        * poseidon_aggregator_sum_6)
        - numerator_6);
    sum = sum * random_coeff + constraint_quotient;
}
#[cfg(and(test, feature: "qm31_opcode"))]
mod tests {
    use core::array::ArrayImpl;
    use core::num::traits::Zero;
    use stwo_constraint_framework::AirComponent;
    #[allow(unused_imports)]
    use stwo_constraint_framework::test_utils::{make_interaction_trace, preprocessed_mask_add};
    #[allow(unused_imports)]
    use stwo_constraint_framework::{
        LookupElementsTrait, PreprocessedMaskValues, PreprocessedMaskValuesTrait,
    };
    use stwo_verifier_core::fields::qm31::{QM31, QM31Impl, QM31Trait, qm31_const};
    use crate::components::sample_evaluations::*;
    #[allow(unused_imports)]
    use crate::preprocessed_columns::*;
    use super::{Claim, Component};

    #[test]
    fn test_evaluation_result() {
        let component = Component {
            claim: Claim { log_size: 15 },
            claimed_sum: qm31_const::<1398335417, 314974026, 1722107152, 821933968>(),
            common_lookup_elements: LookupElementsTrait::from_z_alpha(
                qm31_const::<445623802, 202571636, 1360224996, 131355117>(),
                qm31_const::<476823935, 939223384, 62486082, 122423602>(),
            ),
        };
        let public_params = [1782572470].span();
        let mut sum: QM31 = Zero::zero();

        let mut preprocessed_trace = PreprocessedMaskValues { values: Default::default() };
        let mut preprocessed_trace = preprocessed_mask_add(
            preprocessed_trace,
            seq_column_idx(component.claim.log_size),
            qm31_const::<735272696, 1215403647, 795393303, 879304430>(),
        );

        let mut trace_columns = [
            [qm31_const::<1659099300, 905558730, 651199673, 1375009625>()].span(),
            [qm31_const::<1591990121, 771341002, 584090809, 1375009625>()].span(),
            [qm31_const::<1793317658, 1173994186, 785417401, 1375009625>()].span(),
            [qm31_const::<1726208479, 1039776458, 718308537, 1375009625>()].span(),
            [qm31_const::<1390662584, 368687818, 382764217, 1375009625>()].span(),
            [qm31_const::<1323553405, 234470090, 315655353, 1375009625>()].span(),
        ]
            .span();
        let interaction_values = array![
            qm31_const::<1005168032, 79980996, 1847888101, 1941984119>(),
            qm31_const::<1072277211, 214198724, 1914996965, 1941984119>(),
            qm31_const::<1139386390, 348416452, 1982105829, 1941984119>(),
            qm31_const::<1206495569, 482634180, 2049214693, 1941984119>(),
        ];
        let mut interaction_columns = make_interaction_trace(
            interaction_values, qm31_const::<1115374022, 1127856551, 489657863, 643630026>(),
        );
        component
            .evaluate_constraints_at_point(
                ref sum,
                ref preprocessed_trace,
                ref trace_columns,
                ref interaction_columns,
                qm31_const::<474642921, 876336632, 1911695779, 974600512>(),
                public_params,
            );
        preprocessed_trace.validate_usage();
        assert_eq!(sum, QM31Trait::from_fixed_array(POSEIDON_BUILTIN_SAMPLE_EVAL_RESULT))
    }
}
