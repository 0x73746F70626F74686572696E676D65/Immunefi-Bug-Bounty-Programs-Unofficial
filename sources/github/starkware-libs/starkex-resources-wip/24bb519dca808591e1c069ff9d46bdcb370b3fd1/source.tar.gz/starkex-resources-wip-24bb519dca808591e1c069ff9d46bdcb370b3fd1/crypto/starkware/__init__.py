# Mark the package as a namespace package.
__import__('pkg_resources').declare_namespace(__name__)
