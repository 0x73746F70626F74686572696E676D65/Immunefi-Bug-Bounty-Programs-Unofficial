use cairo_lang_syntax::node::SyntaxNode;
use cairo_lang_syntax::node::green::GreenNodeDetails;
use cairo_lang_syntax::node::kind::SyntaxKind;
use colored::{ColoredString, Colorize};
use salsa::Database;

struct ColoredPrinter<'a> {
    db: &'a dyn Database,
    /// Whether to also print empty and missing tokens/nodes.
    verbose: bool,
    result: String,
}
impl ColoredPrinter<'_> {
    fn print(&mut self, syntax_node: &SyntaxNode<'_>) {
        let node = syntax_node.green_node(self.db);
        match &node.details {
            GreenNodeDetails::Token(text) => {
                if self.verbose && node.kind == SyntaxKind::TokenMissing {
                    self.result.push_str(&format!("{}", "<m>".red()));
                } else {
                    self.result.push_str(&set_color(text.long(self.db), node.kind).to_string());
                }
            }
            GreenNodeDetails::Node { .. } => {
                if self.verbose && node.kind.is_missing() {
                    self.result.push_str(&format!("{}", "<m>".red()));
                } else if self.verbose && is_empty_kind(node.kind) {
                    self.result.push_str(&format!("{}", "<e>".red()));
                } else {
                    for child in syntax_node.get_children(self.db).iter() {
                        self.print(child);
                    }
                }
            }
        }
    }
}

// TODO(yuval): Move to SyntaxKind.
pub fn is_empty_kind(kind: SyntaxKind) -> bool {
    matches!(
        kind,
        SyntaxKind::OptionStructArgExprEmpty
            | SyntaxKind::OptionTypeClauseEmpty
            | SyntaxKind::OptionReturnTypeClauseEmpty
            | SyntaxKind::OptionTerminalSemicolonEmpty
            | SyntaxKind::OptionTerminalColonColonEmpty
            | SyntaxKind::OptionWrappedGenericParamListEmpty
    )
}

fn set_color(text: &str, kind: SyntaxKind) -> ColoredString {
    // TODO(yuval): use tags on SyntaxKind
    match kind {
        SyntaxKind::TokenIdentifier => text.truecolor(255, 255, 100), // Yellow
        SyntaxKind::TokenPlus
        | SyntaxKind::TokenMinus
        | SyntaxKind::TokenMul
        | SyntaxKind::TokenDiv
        | SyntaxKind::TokenMod
        | SyntaxKind::TokenDot => text.bright_magenta(),
        SyntaxKind::TokenLiteralNumber
        | SyntaxKind::TokenFalse
        | SyntaxKind::TokenTrue
        | SyntaxKind::TokenShortString
        | SyntaxKind::TokenString => text.bright_cyan(),
        SyntaxKind::TokenExtern
        | SyntaxKind::TokenType
        | SyntaxKind::TokenFunction
        | SyntaxKind::TokenModule
        | SyntaxKind::TokenEnum
        | SyntaxKind::TokenStruct
        | SyntaxKind::TokenTrait
        | SyntaxKind::TokenMacro
        | SyntaxKind::TokenConst
        | SyntaxKind::TokenPub
        | SyntaxKind::TokenImpl => text.bright_blue(),
        SyntaxKind::TokenOf
        | SyntaxKind::TokenLet
        | SyntaxKind::TokenReturn
        | SyntaxKind::TokenMatch
        | SyntaxKind::TokenIf
        | SyntaxKind::TokenElse
        | SyntaxKind::TokenWhile
        | SyntaxKind::TokenFor
        | SyntaxKind::TokenLoop
        | SyntaxKind::TokenContinue
        | SyntaxKind::TokenBreak
        | SyntaxKind::TokenUse
        | SyntaxKind::TokenAs
        | SyntaxKind::TokenImplicits
        | SyntaxKind::TokenRef
        | SyntaxKind::TokenMut
        | SyntaxKind::TokenNoPanic => text.bright_blue(),
        SyntaxKind::TokenArrow
        | SyntaxKind::TokenMatchArrow
        | SyntaxKind::TokenColon
        | SyntaxKind::TokenColonColon
        | SyntaxKind::TokenDotDot
        | SyntaxKind::TokenDotDotEq
        | SyntaxKind::TokenSemicolon
        | SyntaxKind::TokenAnd
        | SyntaxKind::TokenAndAnd
        | SyntaxKind::TokenOr
        | SyntaxKind::TokenOrOr
        | SyntaxKind::TokenXor
        | SyntaxKind::TokenNot
        | SyntaxKind::TokenQuestionMark
        | SyntaxKind::TokenUnderscore
        | SyntaxKind::TokenAt
        | SyntaxKind::TokenBitNot
        | SyntaxKind::TokenDollar
        | SyntaxKind::TokenHash => text.truecolor(255, 180, 255), // Pink
        SyntaxKind::TokenEq
        | SyntaxKind::TokenEqEq
        | SyntaxKind::TokenGE
        | SyntaxKind::TokenGT
        | SyntaxKind::TokenLE
        | SyntaxKind::TokenLT
        | SyntaxKind::TokenPlusEq
        | SyntaxKind::TokenMinusEq
        | SyntaxKind::TokenMulEq
        | SyntaxKind::TokenDivEq
        | SyntaxKind::TokenModEq
        | SyntaxKind::TokenNeq => {
            text.truecolor(255, 165, 0) // Orange
        }
        SyntaxKind::TokenLBrace
        | SyntaxKind::TokenRBrace
        | SyntaxKind::TokenLBrack
        | SyntaxKind::TokenRBrack
        | SyntaxKind::TokenLParen
        | SyntaxKind::TokenRParen
        | SyntaxKind::TokenComma => text.clear(),
        SyntaxKind::TokenEndOfFile => text.clear(),
        SyntaxKind::TokenBadCharacters => text.red(),
        SyntaxKind::TokenMissing => text.clear(),
        SyntaxKind::TokenSkipped => text.on_red(), // red background
        SyntaxKind::TokenSingleLineComment
        | SyntaxKind::TokenSingleLineDocComment
        | SyntaxKind::TokenSingleLineInnerComment
        | SyntaxKind::TokenWhitespace
        | SyntaxKind::TokenNewline
        | SyntaxKind::TokenEmpty => text.clear(),
        // TODO(orizi): Make exhaustive.
        _ => text.clear(),
    }
}

pub fn print_colored(db: &dyn Database, syntax_root: &SyntaxNode<'_>, verbose: bool) -> String {
    let mut printer = ColoredPrinter { db, verbose, result: Default::default() };
    printer.print(syntax_root);
    printer.result
}
