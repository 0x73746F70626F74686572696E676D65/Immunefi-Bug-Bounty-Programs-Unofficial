pub trait StringLiteral<T>;
