use perpetuals::core::types::asset::AssetId;
use perpetuals::core::types::position::PositionId;
use starknet::ContractAddress;
use starkware_utils::signature::stark::Signature;
use starkware_utils::time::time::Timestamp;

#[derive(Debug, Drop, PartialEq, starknet::Event)]
pub struct WithdrawRequest {
    #[key]
    pub position_id: PositionId,
    #[key]
    pub recipient: ContractAddress,
    pub collateral_id: AssetId,
    pub amount: u64,
    pub expiration: Timestamp,
    #[key]
    pub withdraw_request_hash: felt252,
    pub salt: felt252,
}

#[derive(Debug, Drop, PartialEq, starknet::Event)]
pub struct Withdraw {
    #[key]
    pub position_id: PositionId,
    #[key]
    pub recipient: ContractAddress,
    pub collateral_id: AssetId,
    pub token_address: ContractAddress,
    pub amount: u64,
    pub expiration: Timestamp,
    #[key]
    pub withdraw_request_hash: felt252,
    pub salt: felt252,
    pub interest_amount: i64,
}

#[derive(Debug, Drop, PartialEq, starknet::Event)]
pub struct ForcedWithdraw {
    #[key]
    pub position_id: PositionId,
    #[key]
    pub recipient: ContractAddress,
    pub collateral_id: AssetId,
    pub token_address: ContractAddress,
    pub amount: u64,
    pub expiration: Timestamp,
    #[key]
    pub forced_withdraw_request_hash: felt252,
    pub salt: felt252,
}

#[starknet::interface]
pub trait IWithdrawalManager<TContractState> {
    fn withdraw_request(
        ref self: TContractState,
        signature: Signature,
        collateral_id: AssetId,
        recipient: ContractAddress,
        position_id: PositionId,
        amount: u64,
        expiration: Timestamp,
        salt: felt252,
    );
    fn withdraw(
        ref self: TContractState,
        collateral_id: AssetId,
        recipient: ContractAddress,
        position_id: PositionId,
        amount: u64,
        expiration: Timestamp,
        salt: felt252,
        interest_amount: i64,
    );
    fn forced_withdraw(
        ref self: TContractState,
        collateral_id: AssetId,
        recipient: ContractAddress,
        position_id: PositionId,
        amount: u64,
        expiration: Timestamp,
        salt: felt252,
    );
}

#[starknet::contract]
pub(crate) mod WithdrawalManager {
    use core::num::traits::Zero;
    use openzeppelin::access::accesscontrol::AccessControlComponent;
    use openzeppelin::interfaces::erc20::{IERC20Dispatcher, IERC20DispatcherTrait};
    use openzeppelin::introspection::src5::SRC5Component;
    use perpetuals::core::components::assets::AssetsComponent;
    use perpetuals::core::components::assets::AssetsComponent::InternalImpl as AssetsInternal;
    use perpetuals::core::components::assets::errors::{ASSET_NOT_EXISTS, CANNOT_WITHDRAW_SYNTHETIC};
    use perpetuals::core::components::assets::interface::IAssets;
    use perpetuals::core::components::deposit::Deposit::InternalImpl as DepositInternal;
    use perpetuals::core::components::exchange_time::ExchangeTimeComponent;
    use perpetuals::core::components::fulfillment::fulfillment::Fulfillement as FulfillmentComponent;
    use perpetuals::core::components::operator_nonce::OperatorNonceComponent;
    use perpetuals::core::components::operator_nonce::OperatorNonceComponent::InternalImpl as OperatorNonceInternal;
    use perpetuals::core::components::positions::Positions as PositionsComponent;
    use perpetuals::core::components::positions::Positions::InternalTrait as PositionsInternal;
    use perpetuals::core::components::snip::SNIP12MetadataImpl;
    use perpetuals::core::errors::{
        AMOUNT_OVERFLOW, FORCED_WAIT_REQUIRED, INVALID_ZERO_AMOUNT, SIGNED_TX_EXPIRED,
        TRANSFER_FAILED,
    };
    use perpetuals::core::types::asset::AssetId;
    use perpetuals::core::types::asset::synthetic::SyntheticTrait;
    use perpetuals::core::types::balance::BalanceImpl;
    use perpetuals::core::types::position::{Position, PositionDiff, PositionId, PositionTrait};
    use perpetuals::core::types::price::PriceImpl;
    use perpetuals::core::types::withdraw::{ForcedWithdrawArgs, WithdrawArgs};
    use starknet::ContractAddress;
    use starknet::storage::{
        Mutable, StorageAsPointer, StoragePath, StoragePathEntry, StoragePointerReadAccess,
    };
    use starkware_utils::components::pausable::PausableComponent;
    use starkware_utils::components::pausable::PausableComponent::InternalImpl as PausableInternal;
    use starkware_utils::components::request_approvals::RequestApprovalsComponent;
    use starkware_utils::components::request_approvals::RequestApprovalsComponent::InternalTrait as RequestApprovalsInternal;
    use starkware_utils::components::roles::RolesComponent;
    use starkware_utils::hash::message_hash::OffchainMessageHash;
    use starkware_utils::signature::stark::HashType;
    use starkware_utils::storage::iterable_map::{
        IterableMapIntoIterImpl, IterableMapReadAccessImpl, IterableMapWriteAccessImpl,
    };
    use starkware_utils::time::time::{Time, TimeDelta, validate_expiration};
    use crate::core::components::external_components::interface::EXTERNAL_COMPONENT_WITHDRAWALS;
    use crate::core::components::external_components::named_component::ITypedComponent;
    use crate::core::components::vaults::vaults::{IVaults, Vaults as VaultsComponent};
    use crate::core::types::asset::synthetic::AssetType;
    use super::{
        ForcedWithdraw, IWithdrawalManager, Signature, Timestamp, Withdraw, WithdrawRequest,
    };

    impl SnipImpl = SNIP12MetadataImpl;

    #[event]
    #[derive(Drop, starknet::Event)]
    pub enum Event {
        Withdraw: Withdraw,
        WithdrawRequest: WithdrawRequest,
        ForcedWithdraw: ForcedWithdraw,
        #[flat]
        FulfillmentEvent: FulfillmentComponent::Event,
        #[flat]
        PausableEvent: PausableComponent::Event,
        #[flat]
        OperatorNonceEvent: OperatorNonceComponent::Event,
        #[flat]
        AssetsEvent: AssetsComponent::Event,
        #[flat]
        PositionsEvent: PositionsComponent::Event,
        #[flat]
        RequestApprovalsEvent: RequestApprovalsComponent::Event,
        #[flat]
        SRC5Event: SRC5Component::Event,
        #[flat]
        AccessControlEvent: AccessControlComponent::Event,
        #[flat]
        RolesEvent: RolesComponent::Event,
        #[flat]
        VaultsEvent: VaultsComponent::Event,
        #[flat]
        ExchangeTimeEvent: ExchangeTimeComponent::Event,
    }

    #[storage]
    pub struct Storage {
        #[substorage(v0)]
        accesscontrol: AccessControlComponent::Storage,
        #[substorage(v0)]
        operator_nonce: OperatorNonceComponent::Storage,
        #[substorage(v0)]
        pausable: PausableComponent::Storage,
        #[substorage(v0)]
        pub roles: RolesComponent::Storage,
        #[substorage(v0)]
        #[allow(starknet::colliding_storage_paths)]
        pub assets: AssetsComponent::Storage,
        #[substorage(v0)]
        pub positions: PositionsComponent::Storage,
        #[substorage(v0)]
        pub fulfillment_tracking: FulfillmentComponent::Storage,
        #[substorage(v0)]
        src5: SRC5Component::Storage,
        #[substorage(v0)]
        pub request_approvals: RequestApprovalsComponent::Storage,
        #[substorage(v0)]
        pub vaults: VaultsComponent::Storage,
        #[substorage(v0)]
        exchange_time: ExchangeTimeComponent::Storage,
        // Timelock before forced actions can be executed.
        forced_action_timelock: TimeDelta,
        // Cost for executing forced actions.
        premium_cost: u64,
    }

    component!(path: FulfillmentComponent, storage: fulfillment_tracking, event: FulfillmentEvent);
    component!(path: PausableComponent, storage: pausable, event: PausableEvent);
    component!(path: OperatorNonceComponent, storage: operator_nonce, event: OperatorNonceEvent);
    component!(path: AssetsComponent, storage: assets, event: AssetsEvent);
    component!(path: PositionsComponent, storage: positions, event: PositionsEvent);
    component!(path: RolesComponent, storage: roles, event: RolesEvent);
    component!(path: SRC5Component, storage: src5, event: SRC5Event);
    component!(path: AccessControlComponent, storage: accesscontrol, event: AccessControlEvent);
    component!(
        path: RequestApprovalsComponent, storage: request_approvals, event: RequestApprovalsEvent,
    );
    component!(path: VaultsComponent, storage: vaults, event: VaultsEvent);
    component!(path: ExchangeTimeComponent, storage: exchange_time, event: ExchangeTimeEvent);

    #[abi(embed_v0)]
    impl TypedComponent of ITypedComponent<ContractState> {
        fn component_type(ref self: ContractState) -> felt252 {
            EXTERNAL_COMPONENT_WITHDRAWALS
        }
    }

    #[abi(embed_v0)]
    impl WithdrawalManagerImpl of IWithdrawalManager<ContractState> {
        fn withdraw_request(
            ref self: ContractState,
            signature: Signature,
            collateral_id: AssetId,
            recipient: ContractAddress,
            position_id: PositionId,
            amount: u64,
            expiration: Timestamp,
            salt: felt252,
        ) {
            let position = self.positions.get_position_snapshot(:position_id);
            assert(amount.is_non_zero(), INVALID_ZERO_AMOUNT);
            let owner_account = if (position.owner_protection_enabled.read()) {
                position.get_owner_account()
            } else {
                Option::None
            };
            let hash = self
                .request_approvals
                .register_approval(
                    owner_account: owner_account,
                    public_key: position.get_owner_public_key(),
                    :signature,
                    args: WithdrawArgs {
                        position_id, salt, expiration, collateral_id, amount, recipient,
                    },
                );
            self
                .emit(
                    WithdrawRequest {
                        position_id,
                        recipient,
                        collateral_id,
                        amount,
                        expiration,
                        withdraw_request_hash: hash,
                        salt,
                    },
                );
        }

        fn withdraw(
            ref self: ContractState,
            collateral_id: AssetId,
            recipient: starknet::ContractAddress,
            position_id: PositionId,
            amount: u64,
            expiration: super::Timestamp,
            salt: felt252,
            interest_amount: i64,
        ) {
            let position = self.positions.get_position_mut(:position_id);

            let (hash, token_address) = self
                ._withdraw(
                    :recipient,
                    :position_id,
                    :amount,
                    :expiration,
                    :salt,
                    :position,
                    :collateral_id,
                    :interest_amount,
                );

            self
                .emit(
                    Withdraw {
                        position_id,
                        recipient,
                        collateral_id,
                        token_address,
                        amount,
                        expiration,
                        withdraw_request_hash: hash,
                        salt,
                        interest_amount,
                    },
                );
        }

        fn forced_withdraw(
            ref self: ContractState,
            collateral_id: AssetId,
            recipient: ContractAddress,
            position_id: PositionId,
            amount: u64,
            expiration: Timestamp,
            salt: felt252,
        ) {
            let position = self.positions.get_position_mut(:position_id);
            let public_key = position.into().get_owner_public_key();

            // Calculate forced withdraw hash
            let withdraw_args = WithdrawArgs {
                position_id, salt, expiration, collateral_id, amount, recipient,
            };
            let withdraw_args_hash = withdraw_args.get_message_hash(:public_key);

            let (request_time, forced_withdraw_request_hash) = self
                .request_approvals
                .consume_forced_approved_request(
                    args: ForcedWithdrawArgs { withdraw_args_hash }, :public_key,
                );

            let now = Time::now();
            let forced_action_timelock = self.forced_action_timelock.read();
            assert(request_time.add(forced_action_timelock) <= now, FORCED_WAIT_REQUIRED);

            let (_, token_address) = self
                ._withdraw(
                    :recipient,
                    :position_id,
                    :amount,
                    :expiration,
                    :salt,
                    :position,
                    :collateral_id,
                    interest_amount: 0,
                );

            self
                .emit(
                    ForcedWithdraw {
                        position_id,
                        recipient,
                        collateral_id,
                        token_address,
                        amount,
                        expiration,
                        forced_withdraw_request_hash,
                        salt,
                    },
                );
        }
    }

    #[generate_trait]
    impl PrivateImpl of PrivateTrait {
        fn _withdraw(
            ref self: ContractState,
            recipient: ContractAddress,
            position_id: PositionId,
            amount: u64,
            expiration: Timestamp,
            salt: felt252,
            position: StoragePath<Mutable<Position>>,
            collateral_id: AssetId,
            interest_amount: i64,
        ) -> (HashType, ContractAddress) {
            assert!(!self.vaults.is_vault_position(position_id), "VAULT_CANNOT_WITHDRAW");
            validate_expiration(expiration: expiration, err: SIGNED_TX_EXPIRED);

            let hash = self
                .request_approvals
                .consume_approved_request(
                    args: WithdrawArgs {
                        position_id, salt, expiration, collateral_id, amount, recipient,
                    },
                    public_key: position.into().get_owner_public_key(),
                );

            self
                .positions
                .verify_and_update_interest_range(
                    :position, :position_id, interest_amount: interest_amount,
                );

            /// Validations - Fundamentals:
            let (position_diff, quantum, token_contract) = if collateral_id != self
                .assets
                .get_base_collateral_id() {
                let entry = (@self).assets.asset_config.entry(collateral_id).as_ptr();
                assert(SyntheticTrait::is_some_config(entry), ASSET_NOT_EXISTS);
                assert(
                    SyntheticTrait::at_asset_type(entry) != AssetType::SYNTHETIC,
                    CANNOT_WITHDRAW_SYNTHETIC,
                );
                let negative_amount: i64 = -amount.try_into().expect(AMOUNT_OVERFLOW);
                self
                    .positions
                    ._validate_asset_shrink_non_negative(
                        position: position.into(), asset_id: collateral_id, amount: negative_amount,
                    );
                (
                    PositionDiff {
                        collateral_diff: interest_amount.into(),
                        asset_diff: Some((collateral_id, negative_amount.into())),
                    },
                    SyntheticTrait::at_quantum(entry),
                    IERC20Dispatcher { contract_address: SyntheticTrait::at_token_contract(entry) },
                )
            } else {
                (
                    PositionDiff {
                        collateral_diff: interest_amount.into() - amount.into(),
                        asset_diff: Option::None,
                    },
                    self.assets.get_collateral_quantum(),
                    self.assets.get_base_collateral_token_contract(),
                )
            };
            self
                .positions
                .validate_healthy_or_healthier_position(
                    :position_id,
                    position: position.into(),
                    :position_diff,
                    tvtr_before: Default::default(),
                );

            self.positions.apply_diff(:position_id, :position_diff);
            let withdraw_unquantized_amount = quantum * amount;
            assert(
                token_contract.transfer(:recipient, amount: withdraw_unquantized_amount.into()),
                TRANSFER_FAILED,
            );

            (hash, token_contract.contract_address)
        }
    }
}
