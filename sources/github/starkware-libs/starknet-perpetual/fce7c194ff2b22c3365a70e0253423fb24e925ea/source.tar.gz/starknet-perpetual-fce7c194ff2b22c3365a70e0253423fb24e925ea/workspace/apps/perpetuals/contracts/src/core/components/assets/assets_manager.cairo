use perpetuals::core::types::asset::AssetId;
use starknet::ContractAddress;
use starkware_utils::signature::stark::PublicKey;
use starkware_utils::storage::iterable_map::{
    IterableMapIntoIterImpl, IterableMapReadAccessImpl, IterableMapWriteAccessImpl,
};

#[starknet::interface]
pub trait IAssetsExternal<TContractState> {
    fn add_oracle_to_asset(
        ref self: TContractState,
        asset_id: AssetId,
        oracle_public_key: PublicKey,
        oracle_name: felt252,
        asset_name: felt252,
    );
    fn add_synthetic_asset(
        ref self: TContractState,
        asset_id: AssetId,
        risk_factor_tiers: Span<u16>,
        risk_factor_first_tier_boundary: u128,
        risk_factor_tier_size: u128,
        quorum: u8,
        resolution_factor: u64,
    );
    fn add_vault_collateral_asset(
        ref self: TContractState,
        asset_id: AssetId,
        erc20_contract_address: ContractAddress,
        quantum: u64,
        risk_factor: u16,
        quorum: u8,
    );
    fn add_spot_asset(
        ref self: TContractState,
        asset_id: AssetId,
        erc20_contract_address: ContractAddress,
        quantum: u64,
        resolution_factor: u64,
        risk_factor: u16,
        quorum: u8,
    );
    fn update_asset_risk_factor(
        ref self: TContractState,
        asset_id: AssetId,
        risk_factor_tiers: Span<u16>,
        risk_factor_first_tier_boundary: u128,
        risk_factor_tier_size: u128,
    );
    fn update_asset_risk_factor_request(
        ref self: TContractState,
        asset_id: AssetId,
        risk_factor_tiers: Span<u16>,
        risk_factor_first_tier_boundary: u128,
        risk_factor_tier_size: u128,
    );
    fn deactivate_synthetic(ref self: TContractState, synthetic_id: AssetId);
    fn remove_oracle_from_asset(
        ref self: TContractState, asset_id: AssetId, oracle_public_key: PublicKey,
    );
    fn update_asset_quorum(ref self: TContractState, asset_id: AssetId, quorum: u8);

    // View functions
    fn get_max_price_interval(self: @TContractState) -> starkware_utils::time::time::TimeDelta;
    fn get_max_funding_interval(self: @TContractState) -> starkware_utils::time::time::TimeDelta;
    fn get_max_oracle_price_validity(
        self: @TContractState,
    ) -> starkware_utils::time::time::TimeDelta;
    fn get_max_funding_rate(self: @TContractState) -> u32;
}

#[starknet::contract]
pub(crate) mod AssetsManager {
    use core::hash::{HashStateExTrait, HashStateTrait};
    use core::num::traits::{Pow, Zero};
    use core::panic_with_felt252;
    use core::poseidon::PoseidonTrait;
    use openzeppelin::access::accesscontrol::AccessControlComponent;
    use openzeppelin::interfaces::erc20::{IERC20MetadataDispatcher, IERC20MetadataDispatcherTrait};
    use openzeppelin::introspection::src5::SRC5Component;
    use perpetuals::core::components::assets::AssetsComponent;
    use perpetuals::core::components::operator_nonce::OperatorNonceComponent;
    use perpetuals::core::types::asset::synthetic::{AssetType, SyntheticTrait};
    use perpetuals::core::types::asset::{AssetId, AssetStatus};
    use perpetuals::core::types::risk_factor::RiskFactorTrait;
    use starknet::storage::{
        MutableVecTrait, StorageAsPointer, StorageMapReadAccess, StorageMapWriteAccess,
        StoragePathEntry, StoragePointerReadAccess, StoragePointerWriteAccess,
    };
    use starknet::{ContractAddress, SyscallResultTrait};
    use starkware_utils::components::pausable::PausableComponent;
    use starkware_utils::components::roles::RolesComponent;
    use starkware_utils::constants::{TWO_POW_128, TWO_POW_40};
    use starkware_utils::signature::stark::{HashType, PublicKey};
    use starkware_utils::storage::iterable_map::{
        IterableMapIntoIterImpl, IterableMapReadAccessImpl, IterableMapTrait,
        IterableMapWriteAccessImpl,
    };
    use starkware_utils::storage::utils::SubFromStorage;
    use starkware_utils::time::time::TimeDelta;
    use crate::core::components::assets::errors::{
        ASSET_NAME_TOO_LONG, ASSET_REGISTERED_AS_COLLATERAL, ASSET_TOKEN_ADDRESS_USED,
        INACTIVE_ASSET, INVALID_NON_SYNTHETIC_RF_TIERS, INVALID_SAME_QUORUM,
        INVALID_SPOT_RF_BOUNDARY, INVALID_SPOT_RF_TIER_SIZE, INVALID_ZERO_ASSET_ID,
        INVALID_ZERO_ASSET_NAME, INVALID_ZERO_ORACLE_NAME, INVALID_ZERO_PUBLIC_KEY,
        INVALID_ZERO_QUORUM, INVALID_ZERO_RF_FIRST_BOUNDRY, INVALID_ZERO_RF_TIERS_LEN,
        INVALID_ZERO_RF_TIER_SIZE, NOT_SYNTHETIC, ORACLE_ALREADY_EXISTS, ORACLE_NAME_TOO_LONG,
        ORACLE_NOT_EXISTS, RF_REQUEST_MISMATCH, RF_REQUEST_NOT_FOUND, SYNTHETIC_NOT_ACTIVE,
        SYNTHETIC_NOT_EXISTS, UNSORTED_RISK_FACTOR_TIERS,
    };
    use crate::core::components::assets::events;
    use crate::core::components::external_components::interface::EXTERNAL_COMPONENT_ASSETS;
    use crate::core::components::external_components::named_component::ITypedComponent;
    use crate::core::types::asset::synthetic::MAX_U128;
    use crate::core::types::price::SN_PERPS_SCALE;
    use super::IAssetsExternal;
    use super::super::interface::IAssets;

    #[event]
    #[derive(Drop, starknet::Event)]
    pub enum Event {
        #[flat]
        PausableEvent: PausableComponent::Event,
        #[flat]
        OperatorNonceEvent: OperatorNonceComponent::Event,
        #[flat]
        AccessControlEvent: AccessControlComponent::Event,
        #[flat]
        SRC5Event: SRC5Component::Event,
        #[flat]
        RolesEvent: RolesComponent::Event,
        #[flat]
        AssetsEvent: AssetsComponent::Event,
        OracleAdded: events::OracleAdded,
        SyntheticAdded: events::SyntheticAdded,
        AssetChanged: events::AssetChanged,
        SpotAssetAdded: events::SpotAssetAdded,
        OracleRemoved: events::OracleRemoved,
        AssetQuorumUpdated: events::AssetQuorumUpdated,
        SyntheticAssetDeactivated: events::SyntheticAssetDeactivated,
        RiskFactorRequest: events::RiskFactorRequest,
    }

    #[storage]
    pub struct Storage {
        #[substorage(v0)]
        accesscontrol: AccessControlComponent::Storage,
        #[substorage(v0)]
        operator_nonce: OperatorNonceComponent::Storage,
        #[substorage(v0)]
        pausable: PausableComponent::Storage,
        #[substorage(v0)]
        pub roles: RolesComponent::Storage,
        #[substorage(v0)]
        src5: SRC5Component::Storage,
        #[substorage(v0)]
        #[allow(starknet::colliding_storage_paths)]
        pub assets: AssetsComponent::Storage,
    }

    component!(path: PausableComponent, storage: pausable, event: PausableEvent);
    component!(path: OperatorNonceComponent, storage: operator_nonce, event: OperatorNonceEvent);
    component!(path: RolesComponent, storage: roles, event: RolesEvent);
    component!(path: SRC5Component, storage: src5, event: SRC5Event);
    component!(path: AccessControlComponent, storage: accesscontrol, event: AccessControlEvent);
    component!(path: AssetsComponent, storage: assets, event: AssetsEvent);


    #[abi(embed_v0)]
    impl TypedComponent of ITypedComponent<ContractState> {
        fn component_type(ref self: ContractState) -> felt252 {
            EXTERNAL_COMPONENT_ASSETS
        }
    }

    #[abi(embed_v0)]
    impl AssetsManagerImpl of IAssetsExternal<ContractState> {
        /// Add oracle to a synthetic asset.
        fn add_oracle_to_asset(
            ref self: ContractState,
            asset_id: AssetId,
            oracle_public_key: PublicKey,
            oracle_name: felt252,
            asset_name: felt252,
        ) {
            let asset_config = self.assets.asset_config.read(asset_id).expect(SYNTHETIC_NOT_EXISTS);
            assert(asset_config.status != AssetStatus::INACTIVE, INACTIVE_ASSET);

            // Validate the oracle does not exist.
            let asset_oracle_entry = self
                .assets
                .asset_oracle
                .entry(asset_id)
                .entry(oracle_public_key);
            let asset_oracle_data = asset_oracle_entry.read();
            assert(asset_oracle_data.is_zero(), ORACLE_ALREADY_EXISTS);

            assert(oracle_public_key.is_non_zero(), INVALID_ZERO_PUBLIC_KEY);
            assert(asset_name.is_non_zero(), INVALID_ZERO_ASSET_NAME);
            assert(oracle_name.is_non_zero(), INVALID_ZERO_ORACLE_NAME);

            // Validate the size of the oracle name.
            if let Option::Some(oracle_name) = oracle_name.try_into() {
                assert(oracle_name < TWO_POW_40, ORACLE_NAME_TOO_LONG);
            } else {
                panic_with_felt252(ORACLE_NAME_TOO_LONG);
            }

            // Validate the size of the asset name.
            assert(asset_name.into() < TWO_POW_128, ASSET_NAME_TOO_LONG);

            // Add the oracle to the asset.
            let shifted_asset_name = TWO_POW_40.into() * asset_name;
            asset_oracle_entry.write(shifted_asset_name + oracle_name);

            self.emit(events::OracleAdded { asset_id, asset_name, oracle_public_key, oracle_name });
        }

        fn add_synthetic_asset(
            ref self: ContractState,
            asset_id: AssetId,
            risk_factor_tiers: Span<u16>,
            risk_factor_first_tier_boundary: u128,
            risk_factor_tier_size: u128,
            quorum: u8,
            resolution_factor: u64,
        ) {
            assert(self.assets.asset_config.read(asset_id).is_none(), 'SYNTHETIC_ALREADY_EXISTS');
            if let Option::Some(collateral_id) = self.assets.collateral_id.read() {
                assert(collateral_id != asset_id, ASSET_REGISTERED_AS_COLLATERAL);
            }

            assert(asset_id.is_non_zero(), 'INVALID_ZERO_ASSET_ID');
            assert(risk_factor_tiers.len().is_non_zero(), 'INVALID_ZERO_RF_TIERS_LEN');
            assert(risk_factor_first_tier_boundary.is_non_zero(), 'INVALID_ZERO_RF_FIRST_BOUNDRY');
            // risk_factor_tier_size can be zero only if the boundary is infinite. Means all the
            // values would be mapped to the same risk factor value.
            assert(
                risk_factor_tier_size.is_non_zero() || risk_factor_first_tier_boundary == MAX_U128,
                INVALID_ZERO_RF_TIER_SIZE,
            );
            assert(quorum.is_non_zero(), 'INVALID_ZERO_QUORUM');
            assert(resolution_factor.is_non_zero(), 'INVALID_ZERO_RESOLUTION_FACTOR');

            let asset_config = SyntheticTrait::synthetic(
                AssetStatus::PENDING,
                risk_factor_first_tier_boundary,
                risk_factor_tier_size,
                quorum,
                resolution_factor,
            );

            self.assets.asset_config.write(asset_id, Option::Some(asset_config));

            self.assets.timely_data.write(asset_id, Default::default());

            let mut prev_risk_factor = 0_u16;
            for risk_factor in risk_factor_tiers {
                assert(prev_risk_factor < *risk_factor, UNSORTED_RISK_FACTOR_TIERS);
                self
                    .assets
                    .risk_factor_tiers
                    .entry(asset_id)
                    .push(RiskFactorTrait::new(*risk_factor));
                prev_risk_factor = *risk_factor;
            }

            self
                .emit(
                    events::SyntheticAdded {
                        asset_id,
                        risk_factor_tiers,
                        risk_factor_first_tier_boundary,
                        risk_factor_tier_size,
                        resolution_factor,
                        quorum,
                    },
                )
        }

        fn add_vault_collateral_asset(
            ref self: ContractState,
            asset_id: AssetId,
            erc20_contract_address: ContractAddress,
            quantum: u64,
            risk_factor: u16,
            quorum: u8,
        ) {
            assert(quantum == 1, 'INVALID_SHARE_QUANTUM');
            let erc20Contract = IERC20MetadataDispatcher {
                contract_address: erc20_contract_address,
            };
            let underlying_decimals = erc20Contract.decimals();
            let underlying_resolution = 10_u128.pow(underlying_decimals.into());
            assert(underlying_resolution == SN_PERPS_SCALE, 'INVALID_UNDERLYING');
            let calculated_resolution: u64 = (10_u256.pow(underlying_decimals.into())
                / quantum.into())
                .try_into()
                .unwrap();
            assert(
                calculated_resolution == SN_PERPS_SCALE.try_into().unwrap(),
                'INVALID_SHARE_RESOLUTION',
            );

            assert(self.assets.asset_config.read(asset_id).is_none(), 'SYNTHETIC_ALREADY_EXISTS');
            if let Option::Some(collateral_id) = self.assets.collateral_id.read() {
                assert(collateral_id != asset_id, ASSET_REGISTERED_AS_COLLATERAL);
            }

            assert(asset_id.is_non_zero(), 'INVALID_ZERO_ASSET_ID');
            assert(quorum.is_non_zero(), 'INVALID_ZERO_QUORUM');

            // Check that the contract address is unique
            self._assert_contract_address_unique(checked_address: erc20_contract_address);

            let asset_config = SyntheticTrait::vault_share(
                AssetStatus::PENDING,
                quorum,
                calculated_resolution,
                quantum,
                erc20_contract_address,
            );

            self.assets.asset_config.write(asset_id, Option::Some(asset_config));

            self.assets.timely_data.write(asset_id, Default::default());

            self.assets.risk_factor_tiers.entry(asset_id).push(RiskFactorTrait::new(risk_factor));

            self
                .emit(
                    events::SpotAssetAdded {
                        asset_id,
                        risk_factor,
                        resolution_factor: calculated_resolution,
                        quorum,
                        contract_address: erc20_contract_address,
                        quantum,
                    },
                );
        }

        fn add_spot_asset(
            ref self: ContractState,
            asset_id: AssetId,
            erc20_contract_address: ContractAddress,
            quantum: u64,
            resolution_factor: u64,
            risk_factor: u16,
            quorum: u8,
        ) {
            let class_hash = starknet::syscalls::get_class_hash_at_syscall(erc20_contract_address)
                .unwrap_syscall();
            assert(class_hash.is_non_zero(), 'UNDEPLOYED_ADDRESS');
            assert(quantum.is_non_zero(), 'INVALID_SPOT_QUANTUM');
            assert(resolution_factor.is_non_zero(), 'INVALID_ZERO_RESOLUTION_FACTOR');
            assert(asset_id.is_non_zero(), 'INVALID_ZERO_ASSET_ID');
            assert(quorum.is_non_zero(), 'INVALID_ZERO_QUORUM');

            assert(self.assets.asset_config.read(asset_id).is_none(), 'ASSET_ALREADY_EXISTS');
            if let Option::Some(collateral_id) = self.assets.collateral_id.read() {
                assert(collateral_id != asset_id, ASSET_REGISTERED_AS_COLLATERAL);
            }

            // Check that the contract address is unique
            self._assert_contract_address_unique(checked_address: erc20_contract_address);

            let asset_config = SyntheticTrait::spot(
                AssetStatus::PENDING, quorum, resolution_factor, quantum, erc20_contract_address,
            );

            self.assets.asset_config.write(asset_id, Option::Some(asset_config));

            self.assets.timely_data.write(asset_id, Default::default());

            self.assets.risk_factor_tiers.entry(asset_id).push(RiskFactorTrait::new(risk_factor));

            self
                .emit(
                    events::SpotAssetAdded {
                        asset_id,
                        risk_factor,
                        resolution_factor,
                        quorum,
                        contract_address: erc20_contract_address,
                        quantum,
                    },
                );
        }

        /// Update asset risk factors.
        /// Validations:
        /// - Only the operator can call this function, cause it must be sequenced.
        /// (Liqudation may fail if submitted out of order)
        /// - Each risk factor in risk_factor_tiers is less or equal to 1000.
        /// - After update postitions risk must be the same or lower.
        /// - Non-synthetic assets must have exactly 1 risk factor tier.
        /// - A matching governor request must exist from `update_asset_risk_factor_request`.
        ///   The request parameters must exactly match the provided parameters.
        ///
        /// Execution:
        /// - Validate that a matching request exists and clear it.
        /// - Clear existing risk factor tiers.
        /// - Update the asset configuration.
        /// - Emit event.
        fn update_asset_risk_factor(
            ref self: ContractState,
            asset_id: AssetId,
            risk_factor_tiers: Span<u16>,
            risk_factor_first_tier_boundary: u128,
            risk_factor_tier_size: u128,
        ) {
            // Input Validation
            assert(asset_id.is_non_zero(), INVALID_ZERO_ASSET_ID);
            assert(risk_factor_tiers.len().is_non_zero(), INVALID_ZERO_RF_TIERS_LEN);
            assert(risk_factor_first_tier_boundary.is_non_zero(), INVALID_ZERO_RF_FIRST_BOUNDRY);
            // risk_factor_tier_size can be zero only if the boundary is infinite. Means all the
            // values would be mapped to the same risk factor value.
            assert(
                risk_factor_tier_size.is_non_zero() || risk_factor_first_tier_boundary == MAX_U128,
                INVALID_ZERO_RF_TIER_SIZE,
            );

            if let Option::Some(collateral_id) = self.assets.collateral_id.read() {
                assert(collateral_id != asset_id, ASSET_REGISTERED_AS_COLLATERAL);
            }

            let old_asset_config = self.assets.get_asset_config(asset_id);
            // Validate that non-synthetic assets have exactly 1 risk factor tier.
            if old_asset_config.asset_type != AssetType::SYNTHETIC {
                assert(risk_factor_tiers.len() == 1, INVALID_NON_SYNTHETIC_RF_TIERS);
                assert(risk_factor_first_tier_boundary == MAX_U128, INVALID_SPOT_RF_BOUNDARY);
                assert(risk_factor_tier_size.is_zero(), INVALID_SPOT_RF_TIER_SIZE);
            }

            let stored_hash = self.assets.risk_factor_request_hash.read();
            assert(stored_hash.is_non_zero(), RF_REQUEST_NOT_FOUND);

            // Compute hash of provided parameters and verify it matches the stored hash
            let computed_hash = risk_factor_request_hash(
                asset_id, risk_factor_tiers, risk_factor_first_tier_boundary, risk_factor_tier_size,
            );
            assert(computed_hash == stored_hash, RF_REQUEST_MISMATCH);

            // Clear request after validation
            self.assets.risk_factor_request_hash.write(Zero::zero());

            // Clear and update risk factor tiers
            let entry = self.assets.risk_factor_tiers.entry(asset_id);
            while true {
                if entry.pop().is_none() {
                    break;
                }
            }

            // Apply Update to Storage
            let mut updated_config = old_asset_config;
            updated_config.risk_factor_tier_size = risk_factor_tier_size;
            updated_config.risk_factor_first_tier_boundary = risk_factor_first_tier_boundary;
            self.assets.asset_config.write(asset_id, Option::Some(updated_config));

            let mut prev_risk_factor = 0_u16;
            for risk_factor in risk_factor_tiers {
                assert(prev_risk_factor < *risk_factor, UNSORTED_RISK_FACTOR_TIERS);
                entry.push(RiskFactorTrait::new(*risk_factor));
                prev_risk_factor = *risk_factor;
            }

            // Emit Event
            self
                .emit(
                    events::AssetChanged {
                        asset_id,
                        risk_factor_tiers,
                        risk_factor_first_tier_boundary,
                        risk_factor_tier_size,
                        resolution_factor: updated_config.resolution_factor,
                        quorum: updated_config.quorum,
                    },
                );
        }

        /// Request an in asset risk factors.
        /// Validations:
        /// - Only the app governor can call this function.
        ///
        /// Execution:
        /// - Store the requested risk factor parameters.
        /// - Emit event.
        fn update_asset_risk_factor_request(
            ref self: ContractState,
            asset_id: AssetId,
            risk_factor_tiers: Span<u16>,
            risk_factor_first_tier_boundary: u128,
            risk_factor_tier_size: u128,
        ) {
            // Validations are done in update_asset_risk_factor function.

            // Compute and store the hash of the request parameters
            let request_hash = risk_factor_request_hash(
                asset_id, risk_factor_tiers, risk_factor_first_tier_boundary, risk_factor_tier_size,
            );
            self.assets.risk_factor_request_hash.write(request_hash);

            self
                .emit(
                    events::RiskFactorRequest {
                        asset_id,
                        risk_factor_tiers,
                        risk_factor_first_tier_boundary,
                        risk_factor_tier_size,
                    },
                );
        }

        fn deactivate_synthetic(ref self: ContractState, synthetic_id: AssetId) {
            let mut config = self
                .assets
                .asset_config
                .read(synthetic_id)
                .expect(SYNTHETIC_NOT_EXISTS);
            assert(config.status == AssetStatus::ACTIVE, SYNTHETIC_NOT_ACTIVE);
            assert(config.asset_type == AssetType::SYNTHETIC, NOT_SYNTHETIC);
            config.status = AssetStatus::INACTIVE;
            self.assets.asset_config.write(synthetic_id, Option::Some(config));
            self.assets.num_of_active_synthetic_assets.sub_and_write(1);

            self.emit(events::SyntheticAssetDeactivated { asset_id: synthetic_id });
        }

        fn remove_oracle_from_asset(
            ref self: ContractState, asset_id: AssetId, oracle_public_key: PublicKey,
        ) {
            // Validate the oracle exists.
            let asset_oracle_entry = self
                .assets
                .asset_oracle
                .entry(asset_id)
                .entry(oracle_public_key);
            assert(asset_oracle_entry.read().is_non_zero(), ORACLE_NOT_EXISTS);
            asset_oracle_entry.write(Zero::zero());
            self.emit(events::OracleRemoved { asset_id, oracle_public_key });
        }

        fn update_asset_quorum(ref self: ContractState, asset_id: AssetId, quorum: u8) {
            let mut asset_config = self
                .assets
                .asset_config
                .read(asset_id)
                .expect(SYNTHETIC_NOT_EXISTS);
            assert(asset_config.status != AssetStatus::INACTIVE, INACTIVE_ASSET);
            assert(quorum.is_non_zero(), INVALID_ZERO_QUORUM);
            let old_quorum = asset_config.quorum;
            assert(old_quorum != quorum, INVALID_SAME_QUORUM);
            asset_config.quorum = quorum;
            self.assets.asset_config.write(asset_id, Option::Some(asset_config));
            self.emit(events::AssetQuorumUpdated { asset_id, new_quorum: quorum, old_quorum });
        }

        fn get_max_price_interval(self: @ContractState) -> TimeDelta {
            self.assets.max_price_interval.read()
        }

        fn get_max_funding_interval(self: @ContractState) -> TimeDelta {
            self.assets.max_funding_interval.read()
        }

        fn get_max_oracle_price_validity(self: @ContractState) -> TimeDelta {
            self.assets.max_oracle_price_validity.read()
        }

        fn get_max_funding_rate(self: @ContractState) -> u32 {
            self.assets.max_funding_rate.read()
        }
    }

    #[generate_trait]
    impl PrivateImpl of PrivateTrait {
        /// Assert that the contract address is not already used by any asset.
        /// Iterates over all assets and checks if any asset uses the given contract address.
        fn _assert_contract_address_unique(
            ref self: ContractState, checked_address: ContractAddress,
        ) {
            // First check if the contract address is the base collateral token contract address.
            assert(
                self
                    .assets
                    .get_base_collateral_token_contract()
                    .contract_address != checked_address,
                ASSET_TOKEN_ADDRESS_USED,
            );

            let mut timely_data_key_iter = self.assets.timely_data.keys_iter();
            while let Option::Some(asset_id) = timely_data_key_iter.next() {
                let asset_id = asset_id.read();
                let entry = (@self).assets.asset_config.entry(asset_id).as_ptr();
                if let Some(asset_type) = SyntheticTrait::get_asset_type(entry) {
                    if asset_type != AssetType::SYNTHETIC {
                        // Check if this asset has a contract address
                        assert(
                            SyntheticTrait::at_token_contract(entry) != checked_address,
                            ASSET_TOKEN_ADDRESS_USED,
                        );
                    }
                }
            }
        }
    }

    /// Compute hash of risk factor request parameters
    pub fn risk_factor_request_hash(
        asset_id: AssetId,
        risk_factor_tiers: Span<u16>,
        risk_factor_first_tier_boundary: u128,
        risk_factor_tier_size: u128,
    ) -> HashType {
        let mut hash_state = PoseidonTrait::new();
        hash_state = hash_state.update_with(value: asset_id);
        hash_state = hash_state.update_with(value: risk_factor_first_tier_boundary);
        hash_state = hash_state.update_with(value: risk_factor_tier_size);
        hash_state = hash_state.update_with(value: risk_factor_tiers.len());
        for tier in risk_factor_tiers {
            hash_state = hash_state.update_with(value: *tier);
        }
        hash_state.finalize()
    }
}

