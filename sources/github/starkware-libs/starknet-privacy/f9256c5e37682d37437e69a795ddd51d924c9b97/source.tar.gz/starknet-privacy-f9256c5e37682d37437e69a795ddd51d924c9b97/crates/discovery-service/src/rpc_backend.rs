//! RPC-based implementation of the storage interface and chain state.

use std::sync::Arc;

use async_trait::async_trait;
use discovery_core::events_backend::RawEventAccess;
use discovery_core::storage_backend::{
    RawStorageAccess, StorageBackend, StorageError, StorageSnapshot,
};
use serde::{de::DeserializeOwned, Serialize};
use starknet_core::types::{
    requests::GetStorageAtRequest, AddressFilter, BlockId, BlockStatus, BlockTag,
    BlockWithTxHashes, EmittedEvent, EventFilter, Felt, GetStorageAtResult,
    MaybePreConfirmedBlockWithTxHashes, StarknetError, StorageKey, StorageResponseFlag,
    StorageResult,
};
use starknet_providers::{
    jsonrpc::{
        HttpTransport, HttpTransportError, JsonRpcClient, JsonRpcMethod, JsonRpcResponse,
        JsonRpcTransport,
    },
    Provider, ProviderError, ProviderRequestData, ProviderResponseData,
};
use thiserror::Error;
use tokio::sync::{RwLock, Semaphore, SemaphorePermit};
use url::Url;

use crate::chain_state::{ChainHead, ChainState, ChainStateError};
use crate::config::RpcConfig;

/// Errors specific to the RPC backend.
#[derive(Debug, Error)]
pub enum RpcBackendError {
    /// Failed to build the HTTP client.
    #[error("failed to build HTTP client: {0}")]
    HttpClientBuild(#[source] reqwest::Error),
    /// Invalid RPC URL.
    #[error("invalid RPC URL: {0}")]
    InvalidUrl(#[source] url::ParseError),
    /// RPC request failed.
    #[error("RPC request failed: {0}")]
    Request(String),
    /// Unexpected response type from batch request.
    #[error("unexpected response type from batch request")]
    UnexpectedResponseType,
    /// A zero request limit would leave the backend unable to issue any call.
    #[error("max_concurrent_requests must be greater than zero")]
    InvalidMaxConcurrentRequests,
}

impl From<RpcBackendError> for StorageError {
    fn from(err: RpcBackendError) -> Self {
        StorageError::Backend(Box::new(err))
    }
}

/// [`JsonRpcTransport`] wrapper that caps how many JSON-RPC calls may be in
/// flight against the node at any moment.
///
/// Must stay at the transport layer: a `reqwest` connector layer gates only
/// connection establishment, so requests served by a pooled connection bypass it.
///
/// A permit covers exactly one HTTP round trip, so multi-round-trip operations
/// (`starknet_getEvents` pagination, chunked batch reads) release between calls.
struct LimitedTransport {
    transport: HttpTransport,
    request_permits: Semaphore,
}

impl LimitedTransport {
    /// Wraps `transport`, allowing at most `max_concurrent_requests` outbound
    /// JSON-RPC calls at a time.
    fn new(transport: HttpTransport, max_concurrent_requests: usize) -> Self {
        Self {
            transport,
            request_permits: Semaphore::new(max_concurrent_requests),
        }
    }

    /// Takes a permit for one outbound round trip. `request_permits` is private
    /// and never closed, so acquiring cannot fail.
    async fn acquire_request_permit(&self) -> SemaphorePermit<'_> {
        self.request_permits
            .acquire()
            .await
            .expect("request permits are never closed")
    }
}

#[async_trait]
impl JsonRpcTransport for LimitedTransport {
    type Error = HttpTransportError;

    async fn send_request<P, R>(
        &self,
        method: JsonRpcMethod,
        params: P,
    ) -> Result<JsonRpcResponse<R>, Self::Error>
    where
        P: Serialize + Send + Sync,
        R: DeserializeOwned + Send,
    {
        let _permit = self.acquire_request_permit().await;
        self.transport.send_request(method, params).await
    }

    async fn send_requests<R>(
        &self,
        requests: R,
    ) -> Result<Vec<JsonRpcResponse<serde_json::Value>>, Self::Error>
    where
        R: AsRef<[ProviderRequestData]> + Send + Sync,
    {
        let _permit = self.acquire_request_permit().await;
        self.transport.send_requests(requests).await
    }
}

/// Inner state shared across clones of RpcBackend.
struct RpcBackendInner {
    provider: JsonRpcClient<LimitedTransport>,
    head: RwLock<Option<ChainHead>>,
    max_batch_size: usize,
    event_page_size: usize,
}

/// RPC-based storage backend that reads from a StarkNet node via JSON-RPC.
///
/// This backend is cheaply cloneable and uses a connection pool with
/// configurable concurrency limits. Cloned instances share the same
/// underlying connection pool and request limiter.
#[derive(Clone)]
pub struct RpcBackend {
    inner: Arc<RpcBackendInner>,
}

impl RpcBackend {
    /// Creates a new RPC backend with the given configuration.
    ///
    /// Fails when `config.max_concurrent_requests` is zero, which would admit no
    /// outbound calls at all.
    pub fn new(config: RpcConfig) -> Result<Self, RpcBackendError> {
        if config.max_concurrent_requests == 0 {
            return Err(RpcBackendError::InvalidMaxConcurrentRequests);
        }

        let rpc_url = Url::parse(&config.url).map_err(RpcBackendError::InvalidUrl)?;

        let client = reqwest::Client::builder()
            .connect_timeout(config.connect_timeout)
            .timeout(config.request_timeout)
            .pool_max_idle_per_host(config.max_idle_per_host)
            .build()
            .map_err(RpcBackendError::HttpClientBuild)?;

        let transport = LimitedTransport::new(
            HttpTransport::new_with_client(rpc_url, client),
            config.max_concurrent_requests,
        );
        let provider = JsonRpcClient::new(transport);

        Ok(Self {
            inner: Arc::new(RpcBackendInner {
                provider,
                head: RwLock::new(None),
                max_batch_size: config.max_batch_size,
                event_page_size: config.event_page_size,
            }),
        })
    }
}

#[async_trait]
impl StorageBackend for RpcBackend {
    type Snapshot = RpcSnapshot;

    async fn snapshot(
        &self,
        contract_address: Felt,
        block_id: Option<BlockId>,
    ) -> Result<Self::Snapshot, StorageError> {
        let block_id = block_id.unwrap_or(BlockId::Tag(BlockTag::Latest));
        let block_number = self.resolve_block_number(block_id).await?;
        Ok(RpcSnapshot {
            backend: self.clone(),
            contract_address,
            block_id,
            block_number,
        })
    }
}

impl RpcBackend {
    /// Resolves a `BlockId` to a concrete block number for snapshot pinning.
    ///
    /// `Number(n)` returns `n` directly; every other variant (`Tag(_)` or
    /// `Hash(_)`) is resolved authoritatively via `get_block_with_tx_hashes`,
    /// which returns either a `Block` or `PreConfirmedBlock` variant — both
    /// carry `block_number`. RPC errors propagate.
    async fn resolve_block_number(&self, block_id: BlockId) -> Result<u64, StorageError> {
        if let BlockId::Number(n) = block_id {
            return Ok(n);
        }
        let block = self
            .inner
            .provider
            .get_block_with_tx_hashes(block_id)
            .await
            .map_err(|e| RpcBackendError::Request(e.to_string()))?;
        Ok(match block {
            MaybePreConfirmedBlockWithTxHashes::Block(b) => b.block_number,
            MaybePreConfirmedBlockWithTxHashes::PreConfirmedBlock(b) => b.block_number,
        })
    }
}

/// Snapshot of storage at a specific block, accessed via RPC.
#[derive(Clone)]
pub struct RpcSnapshot {
    backend: RpcBackend,
    contract_address: Felt,
    block_id: BlockId,
    block_number: u64,
}

impl RpcSnapshot {
    /// Builds and sends a batch `get_storage_at` request for the given slots,
    /// optionally including response flags (e.g. `IncludeLastUpdateBlock`).
    async fn send_batch_storage_request(
        &self,
        slots: &[Felt],
        response_flags: Option<Vec<StorageResponseFlag>>,
    ) -> Result<Vec<ProviderResponseData>, StorageError> {
        let contract_address = self.contract_address;

        let requests: Vec<ProviderRequestData> = slots
            .iter()
            .map(|&slot| {
                ProviderRequestData::GetStorageAt(GetStorageAtRequest {
                    contract_address,
                    key: StorageKey(format!("{slot:#x}")),
                    block_id: self.block_id,
                    response_flags: response_flags.clone(),
                })
            })
            .collect();

        self.backend
            .inner
            .provider
            .batch_requests(&requests)
            .await
            .map_err(|e| match &e {
                ProviderError::StarknetError(StarknetError::ContractNotFound) => {
                    StorageError::ContractNotFound
                }
                _ => StorageError::from(RpcBackendError::Request(e.to_string())),
            })
    }

    /// Executes a batch `get_storage_at` request (values only).
    async fn batch_read(&self, slots: &[Felt]) -> Result<Vec<Felt>, StorageError> {
        self.send_batch_storage_request(slots, None)
            .await?
            .into_iter()
            .map(|resp| match resp {
                ProviderResponseData::GetStorageAt(result) => Ok(result.value()),
                _ => Err(RpcBackendError::UnexpectedResponseType.into()),
            })
            .collect()
    }

    /// Executes a batch `get_storage_at` request with `IncludeLastUpdateBlock` flag.
    async fn batch_read_with_block(
        &self,
        slots: &[Felt],
    ) -> Result<Vec<StorageResult>, StorageError> {
        let flags = vec![StorageResponseFlag::IncludeLastUpdateBlock];
        self.send_batch_storage_request(slots, Some(flags))
            .await?
            .into_iter()
            .map(|resp| match resp {
                ProviderResponseData::GetStorageAt(GetStorageAtResult::ValueWithMetadata(
                    result,
                )) => Ok(result),
                _ => Err(RpcBackendError::UnexpectedResponseType.into()),
            })
            .collect()
    }
}

#[async_trait]
impl RawStorageAccess for RpcSnapshot {
    async fn read_slot(&self, slot: Felt) -> Result<Felt, StorageError> {
        self.backend
            .inner
            .provider
            .get_storage_at(self.contract_address, slot, self.block_id, None)
            .await
            .map(|result| result.value())
            .map_err(|e| match &e {
                ProviderError::StarknetError(StarknetError::ContractNotFound) => {
                    StorageError::ContractNotFound
                }
                _ => RpcBackendError::Request(e.to_string()).into(),
            })
    }

    async fn read_slots(&self, slots: Vec<Felt>) -> Result<Vec<Felt>, StorageError> {
        if slots.is_empty() {
            return Ok(vec![]);
        }
        if slots.len() == 1 {
            return Ok(vec![self.read_slot(slots[0]).await?]);
        }

        let mut results = Vec::with_capacity(slots.len());
        for chunk in slots.chunks(self.backend.inner.max_batch_size) {
            let chunk_results = self.batch_read(chunk).await?;
            results.extend(chunk_results);
        }
        Ok(results)
    }

    async fn read_slots_with_block(
        &self,
        slots: Vec<Felt>,
    ) -> Result<Vec<StorageResult>, StorageError> {
        if slots.is_empty() {
            return Ok(vec![]);
        }

        let mut results = Vec::with_capacity(slots.len());
        for chunk in slots.chunks(self.backend.inner.max_batch_size) {
            let chunk_results = self.batch_read_with_block(chunk).await?;
            results.extend(chunk_results);
        }
        Ok(results)
    }
}

#[async_trait]
impl RawEventAccess for RpcSnapshot {
    async fn get_events(
        &self,
        keys: &[Vec<Felt>],
        from_block: BlockId,
        to_block: BlockId,
    ) -> Result<Vec<EmittedEvent>, StorageError> {
        // TODO: history queries spanning a large block range bottleneck here
        // on an unbounded `starknet_getEvents` scan against the node. Pre-index
        // privacy-pool events (at minimum withdrawals, which drive the history
        // feed) locally so history can be served from our own store instead of
        // re-querying the RPC on every request.

        // Strip trailing empty key vecs — they mean "wildcard" in our trait but
        // some RPC implementations (e.g. devnet) treat them as "match nothing".
        let trimmed_keys: Vec<Vec<Felt>> = {
            let end = keys
                .iter()
                .rposition(|v| !v.is_empty())
                .map_or(0, |i| i + 1);
            keys[..end].to_vec()
        };

        let filter = EventFilter {
            from_block: Some(from_block),
            to_block: Some(to_block),
            address: Some(AddressFilter::Single(self.contract_address)),
            keys: if trimmed_keys.is_empty() {
                None
            } else {
                Some(trimmed_keys)
            },
        };

        let mut all_events = Vec::new();
        let mut continuation_token = None;

        loop {
            let page = self
                .backend
                .inner
                .provider
                .get_events(
                    filter.clone(),
                    continuation_token,
                    self.backend.inner.event_page_size as u64,
                )
                .await
                .map_err(|e| RpcBackendError::Request(e.to_string()))?;

            all_events.reserve(page.events.len());
            all_events.extend(page.events);

            match page.continuation_token {
                Some(token) => continuation_token = Some(token),
                None => break,
            }
        }

        patch_pre_confirmed_block_number(self.block_number, &mut all_events);

        Ok(all_events)
    }

    fn block_id(&self) -> BlockId {
        self.block_id
    }

    fn block_number(&self) -> u64 {
        self.block_number
    }
}

/// TODO: Pathfinder workaround — pre-confirmed events are returned with
/// `block_number: None`. Fill the gap using the snapshot's resolved block
/// number (which is `cached_head + 1` when the snapshot is pinned to
/// `Tag(PreConfirmed)`). Remove once
/// <https://github.com/equilibriumco/pathfinder/pull/3348> is included in a
/// Pathfinder release and rolled out across RPC providers.
fn patch_pre_confirmed_block_number(snapshot_block_number: u64, events: &mut [EmittedEvent]) {
    for event in events.iter_mut() {
        if event.block_number.is_none() {
            event.block_number = Some(snapshot_block_number);
        }
    }
}

#[async_trait]
impl ChainState for RpcBackend {
    async fn get_head(&self) -> Option<ChainHead> {
        if let Some(head) = *self.inner.head.read().await {
            return Some(head);
        }

        // Fallback: fetch latest block via RPC when WS subscription hasn't
        // provided a head yet (e.g. WS not available on the node).
        let block = self
            .inner
            .provider
            .get_block_with_tx_hashes(BlockId::Tag(BlockTag::Latest))
            .await
            .ok()?;

        match block {
            MaybePreConfirmedBlockWithTxHashes::Block(head) => Some(ChainHead {
                block_number: head.block_number,
                block_hash: head.block_hash,
                timestamp: head.timestamp,
            }),
            MaybePreConfirmedBlockWithTxHashes::PreConfirmedBlock(_) => None,
        }
    }

    async fn set_head(&self, head: ChainHead) {
        *self.inner.head.write().await = Some(head);
    }

    async fn is_canonical(&self, block_hash: Felt) -> Result<bool, ChainStateError> {
        // Two round trips: a height addresses exactly one block, so hash ->
        // height -> hash decides canonicity where knowing the hash cannot.
        let block = match self.block_by_id(BlockId::Hash(block_hash)).await? {
            Some(block) => block,
            None => return Ok(false),
        };
        // Except once the block is final: an L1-accepted block had its state
        // update finalized on Ethereum, so no reorg can replace it and the
        // second round trip cannot change the answer.
        if block.status == BlockStatus::AcceptedOnL1 {
            return Ok(true);
        }
        Ok(self
            .block_by_id(BlockId::Number(block.block_number))
            .await?
            .is_some_and(|candidate| candidate.block_hash == block_hash))
    }
}

impl RpcBackend {
    /// Fetches the accepted block `block_id` addresses, or `None` when the node
    /// has no such block. A pre-confirmed block is `None`: it carries no hash.
    async fn block_by_id(
        &self,
        block_id: BlockId,
    ) -> Result<Option<BlockWithTxHashes>, ChainStateError> {
        match self.inner.provider.get_block_with_tx_hashes(block_id).await {
            Ok(MaybePreConfirmedBlockWithTxHashes::Block(block)) => Ok(Some(block)),
            Ok(MaybePreConfirmedBlockWithTxHashes::PreConfirmedBlock(_)) => Ok(None),
            Err(ProviderError::StarknetError(StarknetError::BlockNotFound)) => Ok(None),
            Err(error) => Err(ChainStateError::RpcError(error)),
        }
    }
}

#[async_trait]
impl StorageSnapshot for RpcSnapshot {
    fn contract_address(&self) -> Felt {
        self.contract_address
    }

    fn block_id(&self) -> BlockId {
        self.block_id
    }
}
