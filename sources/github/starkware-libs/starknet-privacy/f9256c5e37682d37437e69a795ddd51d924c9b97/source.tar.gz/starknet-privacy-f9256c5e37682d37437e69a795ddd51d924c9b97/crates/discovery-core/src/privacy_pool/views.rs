//! Privacy contract view methods and blanket implementation.

use async_trait::async_trait;
use num_traits::ToPrimitive;
use starknet_types_core::felt::Felt;

use super::storage_slots;
use super::types::{EncChannelInfo, EncOutgoingChannelInfo, EncPrivateKey, EncSubchannelInfo};
use crate::storage_backend::{RawStorageAccess, StorageError};
use starknet_core::types::StorageResult;

/// Privacy contract view methods.
#[async_trait]
pub trait IViews: Send + Sync {
    /// Checks if a channel with the given marker exists.
    async fn channel_exists(&self, channel_marker: Felt) -> Result<bool, StorageError>;

    /// Returns the number of channels for a recipient.
    async fn get_num_of_channels(&self, recipient_addr: Felt) -> Result<u64, StorageError>;

    /// Returns channel info for a recipient at the given index.
    async fn get_channel_info(
        &self,
        recipient_addr: Felt,
        channel_index: u64,
    ) -> Result<EncChannelInfo, StorageError> {
        self.get_channel_info_batch(recipient_addr, channel_index, 1)
            .await
            .map(|channels| {
                channels
                    .first()
                    .copied()
                    .ok_or(StorageError::SlotCountMismatch)
            })?
    }

    /// Checks if a subchannel with the given marker exists.
    async fn subchannel_exists(&self, subchannel_marker: Felt) -> Result<bool, StorageError>;

    /// Returns encrypted subchannel info for the given id.
    async fn get_subchannel_info(
        &self,
        subchannel_id: Felt,
    ) -> Result<EncSubchannelInfo, StorageError>;

    /// Returns encrypted outgoing channel info for the given outgoing channel id.
    async fn get_outgoing_channel_info(
        &self,
        outgoing_channel_id: Felt,
    ) -> Result<EncOutgoingChannelInfo, StorageError>;

    /// Returns the note value with its last-update block number for the given note ID.
    async fn get_note_with_block(&self, note_id: Felt) -> Result<StorageResult, StorageError> {
        self.get_notes_batch_with_block(&[note_id])
            .await?
            .into_iter()
            .next()
            .ok_or(StorageError::SlotCountMismatch)
    }

    /// Checks if a nullifier exists.
    async fn nullifier_exists(&self, nullifier: Felt) -> Result<bool, StorageError> {
        self.nullifier_exists_batch(&[nullifier])
            .await
            .map(|exists| {
                exists
                    .first()
                    .copied()
                    .ok_or(StorageError::SlotCountMismatch)
            })?
    }

    /// Returns a user's public viewing key.
    async fn get_public_key(&self, user_addr: Felt) -> Result<Felt, StorageError> {
        self.get_public_keys_batch(&[user_addr])
            .await
            .map(|keys| keys.first().copied().ok_or(StorageError::SlotCountMismatch))?
    }

    /// Returns a user's encrypted private key.
    async fn get_enc_private_key(&self, user_addr: Felt) -> Result<EncPrivateKey, StorageError>;

    /// Returns the auditor public key.
    async fn get_auditor_public_key(&self) -> Result<Felt, StorageError>;

    /// Batch-reads channel info for `count` consecutive channels starting at `start_index`.
    ///
    /// Returns a `Vec<EncChannelInfo>` of length `count`, fetched in a single `read_slots` call.
    async fn get_channel_info_batch(
        &self,
        recipient_addr: Felt,
        start_index: u64,
        count: usize,
    ) -> Result<Vec<EncChannelInfo>, StorageError>;

    /// Batch-reads public keys for the given addresses.
    ///
    /// Returns a `Vec<Felt>` matching the input length. Zero = unregistered.
    async fn get_public_keys_batch(&self, addrs: &[Felt]) -> Result<Vec<Felt>, StorageError>;

    /// Batch-checks nullifier existence for the given nullifiers.
    ///
    /// Returns a `Vec<bool>` matching the input length. `true` = spent.
    async fn nullifier_exists_batch(&self, nullifiers: &[Felt]) -> Result<Vec<bool>, StorageError>;

    /// Batch-reads note values with their last-update block numbers.
    async fn get_notes_batch_with_block(
        &self,
        note_ids: &[Felt],
    ) -> Result<Vec<StorageResult>, StorageError>;

    /// Returns a user's public key with its last-update block number.
    async fn get_public_key_with_block(
        &self,
        user_addr: Felt,
    ) -> Result<StorageResult, StorageError>;
}

/// Blanket implementation of `IViews` for any type implementing `RawStorageAccess`.
#[async_trait]
impl<T: RawStorageAccess> IViews for T {
    #[tracing::instrument(name = "channel_exists", level = "debug", skip(self))]
    async fn channel_exists(&self, channel_marker: Felt) -> Result<bool, StorageError> {
        let slot = storage_slots::channel_exists(channel_marker);
        let value = self.read_slot(slot).await?;
        Ok(value != Felt::ZERO)
    }

    #[tracing::instrument(name = "get_num_of_channels", level = "debug", skip(self))]
    async fn get_num_of_channels(&self, recipient_addr: Felt) -> Result<u64, StorageError> {
        // Channels are stored as a vector in contract storage.
        // The base slot contains the vector length (number of channels).
        let slot = storage_slots::recipient_channels_base(recipient_addr);
        let value = self.read_slot(slot).await?;
        value.to_u64().ok_or(StorageError::CastToU64Error(value))
    }

    #[tracing::instrument(name = "subchannel_exists", level = "debug", skip(self))]
    async fn subchannel_exists(&self, subchannel_marker: Felt) -> Result<bool, StorageError> {
        let slot = storage_slots::subchannel_exists(subchannel_marker);
        let value = self.read_slot(slot).await?;
        Ok(value != Felt::ZERO)
    }

    #[tracing::instrument(name = "get_subchannel_info", level = "debug", skip(self))]
    async fn get_subchannel_info(
        &self,
        subchannel_id: Felt,
    ) -> Result<EncSubchannelInfo, StorageError> {
        let slots = storage_slots::subchannel_tokens(subchannel_id);
        let values = self.read_slots(slots.to_vec()).await?;
        Ok(EncSubchannelInfo {
            salt: values[0],
            enc_token: values[1],
        })
    }

    #[tracing::instrument(name = "get_outgoing_channel_info", level = "debug", skip(self))]
    async fn get_outgoing_channel_info(
        &self,
        outgoing_channel_id: Felt,
    ) -> Result<EncOutgoingChannelInfo, StorageError> {
        let slots = storage_slots::outgoing_channels(outgoing_channel_id);
        let values = self.read_slots(slots.to_vec()).await?;
        Ok(EncOutgoingChannelInfo {
            salt: values[0],
            enc_recipient_addr: values[1],
        })
    }

    #[tracing::instrument(name = "get_enc_private_key", level = "debug", skip(self))]
    async fn get_enc_private_key(&self, user_addr: Felt) -> Result<EncPrivateKey, StorageError> {
        let slots = storage_slots::enc_private_key(user_addr);
        let values = self.read_slots(slots.to_vec()).await?;
        Ok(EncPrivateKey {
            auditor_public_key: values[0],
            ephemeral_pubkey: values[1],
            enc_private_key: values[2],
        })
    }

    #[tracing::instrument(name = "get_auditor_public_key", level = "debug", skip(self))]
    async fn get_auditor_public_key(&self) -> Result<Felt, StorageError> {
        let slot = storage_slots::auditor_public_key();
        self.read_slot(slot).await
    }

    #[tracing::instrument(
        name = "get_channel_info_batch",
        level = "debug",
        skip(self),
        fields(count)
    )]
    async fn get_channel_info_batch(
        &self,
        recipient_addr: Felt,
        start_index: u64,
        count: usize,
    ) -> Result<Vec<EncChannelInfo>, StorageError> {
        let mut slots = Vec::with_capacity(count * 3);
        for channel_offset in 0..count {
            let channel_index = start_index + channel_offset as u64;
            let channel_slots =
                storage_slots::recipient_channels_element(recipient_addr, channel_index);
            slots.extend(channel_slots.to_vec());
        }
        let values = self.read_slots(slots).await?;
        let mut result = Vec::with_capacity(count);
        for &[ephemeral_pubkey, enc_channel_key, enc_sender_addr] in values.as_chunks::<3>().0 {
            result.push(EncChannelInfo {
                ephemeral_pubkey,
                enc_channel_key,
                enc_sender_addr,
            });
        }
        Ok(result)
    }

    #[tracing::instrument(
        name = "get_public_keys_batch",
        level = "debug",
        skip(self, addrs),
        fields(count = addrs.len())
    )]
    async fn get_public_keys_batch(&self, addrs: &[Felt]) -> Result<Vec<Felt>, StorageError> {
        let slots: Vec<_> = addrs
            .iter()
            .map(|&addr| storage_slots::public_key(addr))
            .collect();
        let values = self.read_slots(slots).await?;
        Ok(values)
    }

    #[tracing::instrument(
        name = "nullifier_exists_batch",
        level = "debug",
        skip(self, nullifiers),
        fields(count = nullifiers.len())
    )]
    async fn nullifier_exists_batch(&self, nullifiers: &[Felt]) -> Result<Vec<bool>, StorageError> {
        let slots: Vec<_> = nullifiers
            .iter()
            .map(|&nul| storage_slots::nullifiers(nul))
            .collect();
        let values = self.read_slots(slots).await?;
        Ok(values.iter().map(|v| *v != Felt::ZERO).collect())
    }

    #[tracing::instrument(
        name = "get_notes_batch_with_block",
        level = "debug",
        skip(self, note_ids),
        fields(count = note_ids.len())
    )]
    async fn get_notes_batch_with_block(
        &self,
        note_ids: &[Felt],
    ) -> Result<Vec<StorageResult>, StorageError> {
        let slots: Vec<_> = note_ids
            .iter()
            .map(|&nid| storage_slots::notes(nid))
            .collect();
        self.read_slots_with_block(slots).await
    }

    #[tracing::instrument(name = "get_public_key_with_block", level = "debug", skip(self))]
    async fn get_public_key_with_block(
        &self,
        user_addr: Felt,
    ) -> Result<StorageResult, StorageError> {
        let slot = storage_slots::public_key(user_addr);
        let results = self.read_slots_with_block(vec![slot]).await?;
        results
            .into_iter()
            .next()
            .ok_or(StorageError::SlotCountMismatch)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::storage_backend::MockBackend;

    /// Each channel occupies 3 consecutive slots read as one flat batch, so the decoder maps
    /// values back to fields by position. Distinct per-field values catch a positional swap.
    #[tokio::test]
    async fn test_channel_info_batch_maps_slots_to_fields_by_position() {
        let recipient_addr = Felt::from(0xa11ce_u64);
        let start_index = 7;
        let num_channels = 2;

        let mut backend = MockBackend::empty();
        let mut expected_channels = Vec::with_capacity(num_channels);
        for channel_offset in 0..num_channels {
            let channel_slots = storage_slots::recipient_channels_element(
                recipient_addr,
                start_index + channel_offset as u64,
            );
            let channel_info = EncChannelInfo {
                ephemeral_pubkey: Felt::from(100 + channel_offset),
                enc_channel_key: Felt::from(200 + channel_offset),
                enc_sender_addr: Felt::from(300 + channel_offset),
            };
            backend.insert(
                channel_slots.ephemeral_pubkey,
                channel_info.ephemeral_pubkey,
            );
            backend.insert(channel_slots.enc_channel_key, channel_info.enc_channel_key);
            backend.insert(channel_slots.enc_sender_addr, channel_info.enc_sender_addr);
            expected_channels.push(channel_info);
        }

        let channels = backend
            .get_channel_info_batch(recipient_addr, start_index, num_channels)
            .await
            .unwrap();

        assert_eq!(channels, expected_channels);
    }
}
