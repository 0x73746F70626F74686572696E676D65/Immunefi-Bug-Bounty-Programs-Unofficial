//! RPC backend integration tests.
//!
//! ## Running tests
//!
//! ```sh
//! cargo test -p discovery-service --test test_rpc_backend
//! ```
//!
//! ## Updating snapshots
//!
//! When expected values change, update snapshots with:
//! ```sh
//! UPDATE_EXPECT=1 cargo test -p discovery-service --test test_rpc_backend
//! ```

mod common;

use common::{setup_devnet_with_dump, DevnetClient, DevnetConfig};
use discovery_core::privacy_pool::events::{IEvents, PrivacyPoolEventContent};
use discovery_core::privacy_pool::storage_slots;
use discovery_core::privacy_pool::views::IViews;
use discovery_core::storage_backend::{RawStorageAccess, StorageBackend};
use discovery_service::chain_state::ChainState;
use discovery_service::config::RpcConfig;
use discovery_service::rpc_backend::RpcBackend;
use expect_test::expect;
use starknet_core::types::Felt;

#[tokio::test]
async fn test_public_key_lookup() {
    let (devnet, metadata) = setup_devnet_with_dump().await;

    let rpc_config = RpcConfig {
        url: devnet.rpc_url(),
        ..Default::default()
    };
    let backend = RpcBackend::new(rpc_config).unwrap();

    let snapshot = backend
        .snapshot(metadata.contract_address, None)
        .await
        .unwrap();

    // Alice should have a registered public key
    let alice_pubkey = snapshot
        .get_public_key(metadata.alice_address)
        .await
        .unwrap();
    expect![[r#"
        0x07913e4dbbc06e873598f6e0bb0076449079fbdd951650c7f7a258d1c6b6a82d
    "#]]
    .assert_eq(&format!("{:#066x}\n", alice_pubkey));

    // Random address should have no public key (zero)
    let random_pubkey = snapshot
        .get_public_key(Felt::from_hex("0xdeadbeef").unwrap())
        .await
        .unwrap();
    assert_eq!(random_pubkey, Felt::ZERO);
}

#[tokio::test]
async fn test_block_events() {
    let (devnet, metadata) = setup_devnet_with_dump().await;

    let backend = RpcBackend::new(RpcConfig {
        url: devnet.rpc_url(),
        ..Default::default()
    })
    .unwrap();
    let head_block = backend.get_head().await.unwrap().block_number;
    let snapshot = backend
        .snapshot(metadata.contract_address, None)
        .await
        .unwrap();

    // Collect all events across all blocks in the devnet fixture.
    let mut all_events = Vec::new();
    for block_number in 0..=head_block {
        let events = snapshot
            .get_block_events(starknet_core::types::BlockId::Number(block_number))
            .await
            .unwrap();
        all_events.extend(events);
    }

    // Devnet scenario: deposit 100 + transfer 50 to Bob, then Bob withdraws 50.
    // Expected events: 1 Deposit, 2 EncNoteCreated, 1 Withdrawal (at minimum).
    let deposit_count = all_events
        .iter()
        .filter(|e| matches!(e.content, PrivacyPoolEventContent::Deposit(_)))
        .count();
    let withdrawal_count = all_events
        .iter()
        .filter(|e| matches!(e.content, PrivacyPoolEventContent::Withdrawal(_)))
        .count();
    let note_created_count = all_events
        .iter()
        .filter(|e| matches!(e.content, PrivacyPoolEventContent::EncNoteCreated(_)))
        .count();

    assert!(deposit_count >= 1, "expected at least 1 Deposit event");
    assert!(
        withdrawal_count >= 1,
        "expected at least 1 Withdrawal event"
    );
    assert!(
        note_created_count >= 2,
        "expected at least 2 EncNoteCreated events"
    );
}

#[tokio::test]
async fn test_withdrawal_events() {
    let (devnet, metadata) = setup_devnet_with_dump().await;

    let backend = RpcBackend::new(RpcConfig {
        url: devnet.rpc_url(),
        ..Default::default()
    })
    .unwrap();
    let head_block = backend.get_head().await.unwrap().block_number;
    let snapshot = backend
        .snapshot(metadata.contract_address, None)
        .await
        .unwrap();

    let withdrawals = snapshot
        .get_withdrawal_events(
            metadata.bob_address,
            starknet_core::types::BlockId::Number(0),
            starknet_core::types::BlockId::Number(head_block),
        )
        .await
        .unwrap();

    assert_eq!(withdrawals.len(), 1);
    let PrivacyPoolEventContent::Withdrawal(withdrawal) = &withdrawals[0].content else {
        panic!("expected Withdrawal event");
    };
    assert_eq!(withdrawal.to_address, metadata.bob_address);
    assert_eq!(withdrawal.token, metadata.strk_token);
    assert_eq!(withdrawal.amount, 50);
}

#[tokio::test]
async fn test_withdrawal_events_empty_for_non_recipient() {
    let (devnet, metadata) = setup_devnet_with_dump().await;

    let backend = RpcBackend::new(RpcConfig {
        url: devnet.rpc_url(),
        ..Default::default()
    })
    .unwrap();
    let head_block = backend.get_head().await.unwrap().block_number;
    let snapshot = backend
        .snapshot(metadata.contract_address, None)
        .await
        .unwrap();

    // Alice is not a withdrawal recipient in the devnet scenario
    let withdrawals = snapshot
        .get_withdrawal_events(
            metadata.alice_address,
            starknet_core::types::BlockId::Number(0),
            starknet_core::types::BlockId::Number(head_block),
        )
        .await
        .unwrap();

    assert!(withdrawals.is_empty());
}

/// A block that left the chain must be reported non-canonical against real devnet.
///
/// This cannot separate canonicity from existence: devnet drops an aborted block
/// rather than keeping it addressable, and its `--lite-mode` hashes are derived
/// from the block number, so a replacement at the vacated height would reuse the
/// same hash. The retained-orphan case is covered in
/// `test_chain_state_canonicity.rs`; do not cite this test for it.
#[tokio::test]
async fn test_aborted_block_is_not_canonical() {
    let devnet = DevnetClient::spawn(DevnetConfig {
        full_state_archive: true,
        ..Default::default()
    })
    .expect("Failed to spawn devnet");

    let backend = RpcBackend::new(RpcConfig {
        url: devnet.rpc_url(),
        ..Default::default()
    })
    .unwrap();

    devnet.create_block().await.unwrap();
    let aborted_block_hash_text = devnet.create_block().await.unwrap();
    let aborted_block_hash = Felt::from_hex(&aborted_block_hash_text).unwrap();

    assert!(
        backend.is_canonical(aborted_block_hash).await.unwrap(),
        "a block the chain currently carries is canonical"
    );

    devnet
        .abort_blocks(&aborted_block_hash_text)
        .await
        .expect("devnet should abort blocks");

    assert!(
        !backend.is_canonical(aborted_block_hash).await.unwrap(),
        "a block the chain no longer carries is not canonical"
    );
}

#[tokio::test]
async fn test_read_slots_with_block() {
    let (devnet, metadata) = setup_devnet_with_dump().await;

    let rpc_config = RpcConfig {
        url: devnet.rpc_url(),
        ..Default::default()
    };
    let backend = RpcBackend::new(rpc_config).unwrap();
    let snapshot = backend
        .snapshot(metadata.contract_address, None)
        .await
        .unwrap();

    // Query a slot known to be written during fixture generation (Alice's public key)
    let alice_pubkey_slot = storage_slots::public_key(metadata.alice_address);
    // Query a slot that was never written (random address)
    let unset_slot = storage_slots::public_key(Felt::from_hex("0xdeadbeef").unwrap());

    let results = snapshot
        .read_slots_with_block(vec![alice_pubkey_slot, unset_slot])
        .await
        .unwrap();

    // Written slot: non-zero value and block_number > 0
    expect![[r#"
        0x07913e4dbbc06e873598f6e0bb0076449079fbdd951650c7f7a258d1c6b6a82d
    "#]]
    .assert_eq(&format!("{:#066x}\n", results[0].value));
    assert!(
        results[0].last_update_block > 0,
        "written slot should have non-zero last_update_block"
    );

    // Unset slot: zero value and last_update_block == 0
    assert_eq!(results[1].value, Felt::ZERO);
    assert_eq!(results[1].last_update_block, 0);
}
