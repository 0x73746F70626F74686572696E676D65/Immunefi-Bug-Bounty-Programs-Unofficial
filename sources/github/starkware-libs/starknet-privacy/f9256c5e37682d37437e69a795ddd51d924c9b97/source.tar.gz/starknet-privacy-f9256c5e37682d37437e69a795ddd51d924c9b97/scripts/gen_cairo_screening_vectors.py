#!/usr/bin/env python3
"""Renders fixtures/screening-vectors.json into the Cairo data module
packages/privacy/src/tests/screening_vectors.cairo (generated — never hand-edit).

Usage:
    scripts/gen_cairo_screening_vectors.py
"""

import json
import os

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIXTURE_PATH = os.path.join(REPO_ROOT, "fixtures", "screening-vectors.json")
OUTPUT_PATH = os.path.join(
    REPO_ROOT, "packages", "privacy", "src", "tests", "screening_vectors.cairo"
)

CAIRO_PREFIX = """\
// @generated from fixtures/screening-vectors.json by
// scripts/gen_cairo_screening_vectors.py — DO NOT EDIT, regenerate instead.

#[derive(Drop)]
pub struct ScreeningVector {
    pub chain_id: felt252,
    pub depositor: felt252,
    pub issued_at: u64,
    pub signer_public_key: felt252,
    pub message_hash: felt252,
    pub sig_r: felt252,
    pub sig_s: felt252,
}

pub fn screening_vectors() -> Array<ScreeningVector> {
    array![
"""

CAIRO_SUFFIX = """\
    ]
}
"""


def to_cairo_hex(hex_string: str) -> str:
    return hex(int(hex_string, 16))


def render_vector(vector: dict, signer_public_key: str) -> str:
    """Renders one vector in the exact shape `scarb fmt` produces (8-space struct
    indent, 12-space fields, trailing commas) so the generated file is
    byte-idempotent without a separate format pass."""
    field_values = [
        ("chain_id", to_cairo_hex(vector["chain_id"])),
        ("depositor", to_cairo_hex(vector["depositor"])),
        ("issued_at", str(vector["issued_at"])),
        ("signer_public_key", signer_public_key),
        ("message_hash", to_cairo_hex(vector["message_hash"])),
        ("sig_r", to_cairo_hex(vector["sig_r"])),
        ("sig_s", to_cairo_hex(vector["sig_s"])),
    ]
    field_lines = "\n".join(f"            {name}: {value}," for name, value in field_values)
    return f"        ScreeningVector {{\n{field_lines}\n        }},"


def main() -> None:
    fixture = json.load(open(FIXTURE_PATH))
    signer_public_key = to_cairo_hex(fixture["signer_public_key"])
    rows = "\n".join(render_vector(vector, signer_public_key) for vector in fixture["vectors"])
    # newline="\n" keeps the committed module LF-only on Windows too.
    open(OUTPUT_PATH, "w", newline="\n").write(f"{CAIRO_PREFIX}{rows}\n{CAIRO_SUFFIX}")
    print(f"wrote {len(fixture['vectors'])} vectors -> {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
