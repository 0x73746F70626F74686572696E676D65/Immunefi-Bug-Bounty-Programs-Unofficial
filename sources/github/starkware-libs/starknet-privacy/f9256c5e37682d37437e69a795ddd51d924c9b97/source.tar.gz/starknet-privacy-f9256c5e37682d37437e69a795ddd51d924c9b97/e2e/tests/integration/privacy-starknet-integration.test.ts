import { describe, it, expect, beforeAll } from "vitest";
import {
  Account,
  RpcProvider,
  OutsideExecutionVersion,
  type constants,
  type OutsideExecutionOptions,
} from "starknet";
import { IndexerDiscoveryProvider } from "@starkware-libs/starknet-privacy-sdk/testing";
import {
  createPrivateTransfers,
  ProvingServiceProofProvider,
  SetupRequirement,
  type HistoryTransaction,
} from "@starkware-libs/starknet-privacy-sdk";
import { declarePoolClass } from "../../src/harness.js";
import { accountOn } from "../../src/utils.js";

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required env var: ${name}`);
  return value;
}

interface AccountEntry {
  name: string;
  address: string;
  privateKey: string;
  viewingKey: string;
  admin?: boolean;
}

const RPC = requireEnv("VITE_RPC_URL");
const INDEXER_URL = requireEnv("VITE_INDEXER_URL");
const TOKEN = requireEnv("VITE_TOKEN_ADDRESS");
const CHAIN_ID = requireEnv("VITE_CHAIN_ID") as constants.StarknetChainId;
const COMPLIANCE_PUBLIC_KEY = requireEnv("VITE_COMPLIANCE_PUBLIC_KEY");
const PROVING_SERVICE_URL = requireEnv("VITE_PROVING_SERVICE_URL");
const accounts: AccountEntry[] = JSON.parse(requireEnv("ACCOUNTS"));
function findAccount(name: string): AccountEntry {
  const entry = accounts.find(
    (account) => account.name.toLowerCase() === name.toLowerCase(),
  );
  if (!entry)
    throw new Error(`Account "${name}" not found in ACCOUNTS env var`);
  return entry;
}
function findAdmin(): AccountEntry {
  const entry = accounts.find((a) => a.admin);
  if (!entry)
    throw new Error("No admin account (admin: true) found in ACCOUNTS");
  return entry;
}
const admin = findAdmin();
const alice = findAccount("alice");

describe("Privacy StarkNet integration", () => {
  let discovery: IndexerDiscoveryProvider;
  let node: RpcProvider;
  let adminAccount: Account;
  let aliceAccount: Account;
  let poolAddress: string;

  beforeAll(async () => {
    node = new RpcProvider({ nodeUrl: RPC });
    adminAccount = accountOn(node, {
      address: admin.address,
      signer: admin.privateKey,
      cairoVersion: "1",
    });
    aliceAccount = accountOn(node, {
      address: alice.address,
      signer: alice.privateKey,
      cairoVersion: "1",
    });

    // Verify RPC connectivity before proceeding
    console.log("[debug] RPC endpoint:", RPC);
    try {
      const chainId = await node.getChainId();
      console.log("[debug] RPC connected, chain:", chainId);
    } catch (error) {
      console.error("[debug] RPC connectivity failed:", RPC, error);
      throw error;
    }

    // Declare the contract class (no-op if already declared), then deploy
    const poolClassHash = await declarePoolClass(adminAccount);

    const deploymentSalt = `0x${Date.now().toString(16)}`;
    const constructorCalldata = [admin.address, COMPLIANCE_PUBLIC_KEY, "450"];
    console.log(
      "[debug] deploying fresh privacy pool with salt:",
      deploymentSalt,
    );

    console.log("[debug] estimating deploy fee...");
    const deployFee = await adminAccount.estimateDeployFee({
      classHash: poolClassHash,
      constructorCalldata,
      salt: deploymentSalt,
    });
    console.log("[debug] deploy fee estimated, submitting tx...");
    const deployResult = await adminAccount.deployContract(
      {
        classHash: poolClassHash,
        constructorCalldata,
        salt: deploymentSalt,
      },
      {
        tip: 0n,
        resourceBounds: deployFee.resourceBounds,
      },
    );
    console.log("[debug] deploy tx submitted:", deployResult.transaction_hash);
    console.log("[debug] waiting for deploy receipt...");
    const deployReceipt = await node.waitForTransaction(
      deployResult.transaction_hash,
    );
    if (!deployReceipt.isSuccess()) {
      console.error(
        "[debug] deploy FAILED:",
        JSON.stringify(deployReceipt, null, 2),
      );
      throw new Error("Privacy pool deployment failed");
    }
    poolAddress = deployResult.contract_address;
    console.log("[debug] privacy pool deployed at:", poolAddress);

    discovery = new IndexerDiscoveryProvider(INDEXER_URL, poolAddress, {
      ohttp: true,
    });
  }, 300_000);

  it("preflight returns a valid SetupRequirement", async () => {
    const requirement = await discovery.discoverRequirement(
      BigInt(alice.address),
      BigInt(alice.viewingKey),
      BigInt(alice.address),
      BigInt(TOKEN),
    );
    console.log(
      "[debug] preflight requirement:",
      SetupRequirement[requirement],
      `(${requirement})`,
    );
    expect(requirement).toBeGreaterThanOrEqual(SetupRequirement.Register);
    expect(requirement).toBeLessThanOrEqual(SetupRequirement.Ready);
  });

  it("deposit with auto-register", async () => {
    const log = (msg: string) =>
      console.log(`[${new Date().toISOString()}] ${msg}`);

    const transfers = createPrivateTransfers({
      account: aliceAccount,
      viewingKeyProvider: {
        getViewingKey: async () => BigInt(alice.viewingKey),
      },
      provingProvider: new ProvingServiceProofProvider(
        PROVING_SERVICE_URL,
        CHAIN_ID,
        { ohttp: true },
      ),
      discoveryProvider: discovery,
      poolContractAddress: poolAddress,
    });

    // Mint tokens to Alice (admin is the minter)
    log("estimating mint fee...");
    const mintCall = {
      contractAddress: TOKEN,
      entrypoint: "permissionedMint",
      calldata: [alice.address, "100", "0"],
    };
    const mintFee = await adminAccount.estimateInvokeFee(mintCall);
    log("submitting mint tx...");
    const mintTx = await adminAccount.execute(mintCall, {
      tip: 0n,
      resourceBounds: mintFee.resourceBounds,
    });
    log(`mint tx: ${mintTx.transaction_hash}, waiting...`);
    const mintReceipt = await node.waitForTransaction(mintTx.transaction_hash);
    log(`mint ${mintReceipt.isSuccess() ? "OK" : "FAILED"}`);

    // Approve pool to spend Alice's tokens
    log("estimating approve fee...");
    const approveCall = {
      contractAddress: TOKEN,
      entrypoint: "approve",
      calldata: [poolAddress, "100", "0"],
    };
    const approveFee = await aliceAccount.estimateInvokeFee(approveCall);
    log("submitting approve tx...");
    const approveTx = await aliceAccount.execute(approveCall, {
      tip: 0n,
      resourceBounds: approveFee.resourceBounds,
    });
    log(`approve tx: ${approveTx.transaction_hash}, waiting...`);
    const approveReceipt = await node.waitForTransaction(
      approveTx.transaction_hash,
    );
    log(`approve ${approveReceipt.isSuccess() ? "OK" : "FAILED"}`);

    // Deposit 100 tokens — SDK checks state internally and registers if needed
    const latestBlockNumber = await node.getBlockNumber();
    const provingBlockId = latestBlockNumber - 10;
    log(
      `building deposit: block=${latestBlockNumber}, provingBlock=${provingBlockId}`,
    );
    const { callAndProof } = await transfers
      .build({
        autoRegister: true,
        autoSetup: true,
        autoDiscover: { notes: "refresh", channels: "refresh" },
      })
      .with(TOKEN, (t) => t.deposit({ amount: 100n }))
      .surplusTo(alice.address)
      .execute({ provingBlockId });
    log(
      `SDK execute() done, proofFacts=${callAndProof.proof.proofFacts?.length ?? 0} elements`,
    );

    // Save proof data for isolated testing
    const { writeFileSync } = await import("fs");
    writeFileSync(
      "/tmp/proof-debug.json",
      JSON.stringify(
        {
          proofFacts: callAndProof.proof.proofFacts,
          proof: callAndProof.proof.data,
          call: callAndProof.call,
          poolAddress,
          adminAddress: admin.address,
          aliceAddress: alice.address,
        },
        null,
        2,
      ),
    );
    log("saved proof data to /tmp/proof-debug.json");

    // Submit via outside execution (admin submits on behalf of Alice).
    const now_seconds = Math.floor(Date.now() / 1000);
    const callOptions: OutsideExecutionOptions = {
      caller: admin.address,
      execute_after: now_seconds - 3600,
      execute_before: now_seconds + 3600,
    };
    log("building outside transaction...");
    const outsideTransaction = await aliceAccount.getOutsideTransaction(
      callOptions,
      callAndProof.call,
      OutsideExecutionVersion.V2,
    );
    log("submitting executeFromOutside...");
    const executeTx = await adminAccount.executeFromOutside(
      outsideTransaction,
      {
        tip: 0n,
        proofFacts: callAndProof.proof.proofFacts,
        proof: callAndProof.proof.data,
      },
    );
    log(`executeFromOutside tx: ${executeTx.transaction_hash}, waiting...`);
    const receipt = await node.waitForTransaction(executeTx.transaction_hash);
    log(`receipt: ${receipt.isSuccess() ? "SUCCESS" : "REVERTED"}`);
    if (!receipt.isSuccess()) {
      console.error("Transaction reverted:", JSON.stringify(receipt, null, 2));
    }
    expect(receipt.isSuccess()).toBe(true);
  }, 300_000);

  it("fetches history after deposit", async () => {
    const aliceAddress = BigInt(alice.address);
    const aliceViewingKey = BigInt(alice.viewingKey);

    // Poll until the indexer has processed the deposit block
    const deadline = Date.now() + 90_000;
    let notesResult = await discovery.discoverNotes(
      aliceAddress,
      aliceViewingKey,
    );
    while (notesResult.notes.size === 0) {
      if (Date.now() > deadline)
        throw new Error("Timeout waiting for indexer to process deposit");
      await new Promise((resolve) => setTimeout(resolve, 3000));
      notesResult = await discovery.discoverNotes(
        aliceAddress,
        aliceViewingKey,
      );
    }

    const { channels } = await discovery.discoverChannels(
      aliceAddress,
      aliceViewingKey,
      "all",
    );

    const historyPage = await discovery.fetchHistory(
      aliceAddress,
      notesResult.cursor,
      { channels },
      { maxTransactions: 10 },
    );

    expect(historyPage.blockRef).toBeDefined();
    expect(historyPage.transactions.length).toBeGreaterThan(0);

    const allDeposits = historyPage.transactions.flatMap(
      (transaction) => transaction.deposits,
    );
    expect(
      allDeposits.find(
        (deposit) => deposit.amount === 100n && deposit.token === BigInt(TOKEN),
      ),
    ).toBeDefined();
  }, 300_000);

  it("paginates history", async () => {
    const aliceAddress = BigInt(alice.address);
    const aliceViewingKey = BigInt(alice.viewingKey);

    const { cursor: notesCursor } = await discovery.discoverNotes(
      aliceAddress,
      aliceViewingKey,
    );
    const { channels } = await discovery.discoverChannels(
      aliceAddress,
      aliceViewingKey,
      "all",
    );
    const channelCursor = { channels };

    const allTransactions: HistoryTransaction[] = [];
    const firstPage = await discovery.fetchHistory(
      aliceAddress,
      notesCursor,
      channelCursor,
      { maxTransactions: 1 },
    );
    allTransactions.push(...firstPage.transactions);

    let historyCursor = firstPage.cursor;
    let blockIdentifier = firstPage.blockRef;
    const MAX_PAGES = 5;
    let pageCount = 1;

    while (!historyCursor.historyComplete && pageCount < MAX_PAGES) {
      const page = await discovery.fetchHistory(
        aliceAddress,
        notesCursor,
        channelCursor,
        { maxTransactions: 1, historyCursor, blockIdentifier },
      );
      allTransactions.push(...page.transactions);
      historyCursor = page.cursor;
      blockIdentifier = page.blockRef;
      pageCount++;
    }

    expect(allTransactions.length).toBeGreaterThan(0);

    const allDeposits = allTransactions.flatMap(
      (transaction) => transaction.deposits,
    );
    expect(
      allDeposits.find(
        (deposit) => deposit.amount === 100n && deposit.token === BigInt(TOKEN),
      ),
    ).toBeDefined();
  }, 300_000);

  it("history works with pre_confirmed block ref", async () => {
    const aliceAddress = BigInt(alice.address);
    const aliceViewingKey = BigInt(alice.viewingKey);

    const notesResult = await discovery.discoverNotes(
      aliceAddress,
      aliceViewingKey,
    );
    const { channels } = await discovery.discoverChannels(
      aliceAddress,
      aliceViewingKey,
      "all",
    );

    const page = await discovery.fetchHistory(
      aliceAddress,
      notesResult.cursor,
      { channels },
      { maxTransactions: 5, blockIdentifier: "pre_confirmed" },
    );

    expect(page.blockRef).toBeDefined();
    // Fresh pool may have no transactions — just verify the call succeeds
    // with a pre_confirmed tag (no 503 or deserialization errors).
    expect(page.transactions).toBeDefined();
  }, 300_000);
});
