// @generated from fixtures/screening-vectors.json by
// scripts/gen_cairo_screening_vectors.py — DO NOT EDIT, regenerate instead.

#[derive(Drop)]
pub struct ScreeningVector {
    pub chain_id: felt252,
    pub depositor: felt252,
    pub issued_at: u64,
    pub signer_public_key: felt252,
    pub message_hash: felt252,
    pub sig_r: felt252,
    pub sig_s: felt252,
}

pub fn screening_vectors() -> Array<ScreeningVector> {
    array![
        ScreeningVector {
            chain_id: 0x54455354,
            depositor: 0x1234,
            issued_at: 1700000000,
            signer_public_key: 0x7f1fff02c3801d82c9b233faefb45f99631c4c85a3325b785884e38ee56ae46,
            message_hash: 0x67b37a2ba91ebf69df6da224d2dfd87b8839c2f7143f2e9fc1bfe2fc7fb746,
            sig_r: 0x22ed8b6e747fa2178001e036376d0771d87080ac911888b67227804041ab6da,
            sig_s: 0x11926cad35e3531bd146b6cc8ad8e3795e7011bd1cdc6b8fe2ded0f2038f6fc,
        },
        ScreeningVector {
            chain_id: 0x534e5f5345504f4c4941,
            depositor: 0x49d36570d4e46f48e99674bd3fcc84644ddd6b96f7c741b1562b82f9e004dc7,
            issued_at: 1716579600,
            signer_public_key: 0x7f1fff02c3801d82c9b233faefb45f99631c4c85a3325b785884e38ee56ae46,
            message_hash: 0x7e976ef67d7e9b0ed475a4b2b0296e6a4bd3875c17ed3b6f28a9539c3d87cbc,
            sig_r: 0xab0ca95b821ea0de5720239a51742b5a86273559e99e962581fbb16b6f9d97,
            sig_s: 0x1f09a3c83a48976ab060358eff680d7668e783a657592351b440149b62dcbd5,
        },
        ScreeningVector {
            chain_id: 0x534e5f4d41494e,
            depositor: 0x6f3a1e2c5d40b9a78e2417b3c2d1e0f00112233445566778899aabbccddeeff,
            issued_at: 1716580000,
            signer_public_key: 0x7f1fff02c3801d82c9b233faefb45f99631c4c85a3325b785884e38ee56ae46,
            message_hash: 0x138e535fa83119950c459da6fd90ae6de0b107e721788f7cfcc79228d629573,
            sig_r: 0x6b0749ffbb89003be47d5d066c0ddec92afece450f84081316e265d2b4d94ea,
            sig_s: 0x49f9c8993647ba11d9c7b0ff3f77b42dcf813d9636aba71848a9f702f79ab67,
        },
    ]
}
