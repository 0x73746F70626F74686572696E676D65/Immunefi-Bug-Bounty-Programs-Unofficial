use core::num::traits::Zero;
use core::poseidon::poseidon_hash_span;
use privacy::actions::{ServerAction, WriteOnceInput};
use privacy::hashes::hash;
use privacy::objects::OpenNoteDeposit;
use privacy::tests::utils_for_tests::{
    Test, decrypt_channel_info, decrypt_enc_user_addr, decrypt_private_key,
    decrypt_subchannel_token,
};
use privacy::utils::constants::{OPEN_NOTE_SALT, TWO_POW_120};
use privacy::utils::{
    _encrypt_note_amount, compute_message_hash, decode_note_amount, decrypt_note_amount,
    derive_public_key, deserialize_invoke_return_data, enc_note_packed_value, encrypt_channel_info,
    encrypt_private_key, encrypt_subchannel_info, encrypt_user_addr, open_note, pack,
    to_write_once_action, unify_address, unpack,
};
use snforge_std::{get_class_hash, map_entry_address};
use starknet::{ClassHash, ContractAddress};
use starkware_utils::constants::{MAX_U128, MAX_U32, TWO_POW_128};

#[test]
fn test_encrypt_private_key_decrypt() {
    let private_key = hash(['PRIVATE_KEY'].span());
    let random = hash(['RANDOM'].span());
    let auditor_private_key = hash(['AUDITOR_PRIVATE_KEY'].span());
    let auditor_public_key = derive_public_key(private_key: auditor_private_key);
    let enc_private_key = encrypt_private_key(
        ephemeral_secret: random, :auditor_public_key, :private_key,
    );
    let dec_private_key = decrypt_private_key(:enc_private_key, :auditor_private_key);
    assert_eq!(dec_private_key, private_key);
}

#[test]
fn test_encrypt_user_addr_decrypt() {
    let user_addr = hash(['USER_ADDR'].span()).try_into().unwrap();
    let random = hash(['RANDOM'].span());
    let auditor_private_key = hash(['AUDITOR_PRIVATE_KEY'].span());
    let auditor_public_key = derive_public_key(private_key: auditor_private_key);
    let enc_user_addr = encrypt_user_addr(
        ephemeral_secret: random, :auditor_public_key, :user_addr,
    );
    let dec_user_addr = decrypt_enc_user_addr(:enc_user_addr, :auditor_private_key);
    assert_eq!(dec_user_addr, user_addr);
}

#[test]
fn test_encrypt_channel_info_decrypt() {
    let channel_key = hash(['CHANNEL_KEY'].span());
    let sender_addr = hash(['SENDER_ADDR'].span()).try_into().unwrap();
    let random = hash(['RANDOM'].span());
    let recipient_private_key = hash(['RECIPIENT_PRIVATE_KEY'].span());
    let recipient_public_key = derive_public_key(private_key: recipient_private_key);
    let enc_channel_info = encrypt_channel_info(
        ephemeral_secret: random, :recipient_public_key, :channel_key, :sender_addr,
    );
    let (dec_channel_key, dec_sender_addr) = decrypt_channel_info(
        :enc_channel_info, :recipient_private_key,
    );
    assert_eq!(dec_channel_key, channel_key);
    assert_eq!(dec_sender_addr, sender_addr);
}

#[test]
fn test_encrypt_subchannel_info_decrypt() {
    let channel_key = hash(['CHANNEL_KEY'].span());
    let index_u256: u256 = hash(['INDEX'].span()).into();
    let index: usize = (index_u256 % MAX_U32.into()).try_into().unwrap();
    let token = hash(['TOKEN'].span()).try_into().unwrap();
    let salt = hash(['SALT'].span());
    let enc_subchannel_info = encrypt_subchannel_info(:channel_key, :index, :token, :salt);
    let dec_token = decrypt_subchannel_token(:enc_subchannel_info, :channel_key, :index);
    assert_eq!(dec_token, token);
}

#[test]
fn test_encrypt_decrypt_note_amount() {
    let amounts = [1, 123456789, MAX_U128];
    let mut nonce = 0;
    for amount in amounts.span() {
        nonce += 1;
        let channel_key = hash(['CHANNEL_KEY', nonce.into()].span());
        nonce += 1;
        let salt_120_bits_u256: u256 = hash(['SALT', nonce.into()].span())
            .into() % TWO_POW_120
            .into();
        let salt_120_bits: u128 = salt_120_bits_u256.try_into().unwrap();
        nonce += 1;
        let token: ContractAddress = hash(['TOKEN', nonce.into()].span()).try_into().unwrap();
        nonce += 1;
        let index_u256: u256 = hash(['INDEX', nonce.into()].span()).into();
        let index: usize = (index_u256 % MAX_U32.into()).try_into().unwrap();
        let enc_amount = _encrypt_note_amount(
            :channel_key, :token, :index, salt: salt_120_bits, amount: *amount,
        );
        let dec_amount = decrypt_note_amount(
            :enc_amount, salt: salt_120_bits, :channel_key, :token, :index,
        );
        assert_eq!(dec_amount, *amount);
    }
}

#[test]
fn test_enc_note_packed_value_decode_note_amount() {
    let amounts = [1, 123456789, MAX_U128];
    let mut nonce = 0;
    for amount in amounts.span() {
        nonce += 1;
        let channel_key = hash(['CHANNEL_KEY', nonce.into()].span());
        nonce += 1;
        let salt_120_bits_u256: u256 = hash(['SALT', nonce.into()].span())
            .into() % TWO_POW_120
            .into();
        let salt_120_bits: u128 = salt_120_bits_u256.try_into().unwrap();
        nonce += 1;
        let token: ContractAddress = hash(['TOKEN', nonce.into()].span()).try_into().unwrap();
        nonce += 1;
        let index_u256: u256 = hash(['INDEX', nonce.into()].span()).into();
        let index: usize = (index_u256 % MAX_U32.into()).try_into().unwrap();
        let packed_value = enc_note_packed_value(
            :channel_key, :token, :index, salt: salt_120_bits, amount: *amount,
        );
        let dec_amount = decode_note_amount(:packed_value, :channel_key, :token, :index);
        assert_eq!(dec_amount, *amount);
    }
}

#[test]
fn test_open_note_packed_value_decode_note_amount() {
    let amounts = [1, 123456789, MAX_U128];
    let mut nonce = 0;
    for amount in amounts.span() {
        nonce += 1;
        let token: ContractAddress = hash(['TOKEN', nonce.into()].span()).try_into().unwrap();
        let note = open_note(:token);
        let dec_amount = decode_note_amount(
            packed_value: note.packed_value, channel_key: Zero::zero(), :token, index: Zero::zero(),
        );
        assert_eq!(dec_amount, Zero::zero());
        let packed_value_with_amount = pack(value_1: OPEN_NOTE_SALT, value_2: *amount);
        let dec_amount_with_amount = decode_note_amount(
            packed_value: packed_value_with_amount,
            channel_key: Zero::zero(),
            :token,
            index: Zero::zero(),
        );
        assert_eq!(dec_amount_with_amount, *amount);
    }
}

#[test]
fn test_open_note() {
    let token = 'TOKEN'.try_into().unwrap();
    let note = open_note(:token);
    let (salt, amount) = unpack(note.packed_value);
    assert_eq!(salt, OPEN_NOTE_SALT);
    assert_eq!(amount, 0);
    assert_eq!(note.token, token);
}

#[test]
fn test_pack_unpack() {
    let max_120_bits: u128 = TWO_POW_120.try_into().unwrap() - 1;
    let max_u128: u128 = (TWO_POW_128 - 1).try_into().unwrap();
    let values: [(u128, u128); 4] = [
        (1, 1), (1, max_u128), (max_120_bits, 1), (max_120_bits, max_u128),
    ];
    for (value_1, value_2) in values.span() {
        let packed_value = pack(value_1: (*value_1).into(), value_2: *value_2);
        let (unpacked_value_1, unpacked_value_2) = unpack(:packed_value);
        assert_eq!(unpacked_value_1, *value_1);
        assert_eq!(unpacked_value_2, *value_2);
    }
}

#[test]
fn test_pack_unpack_random() {
    let mut nonce = 0;
    for _ in 0..100_u32 {
        nonce += 1;
        let value_1_120_bits_u256: u256 = hash(['VALUE_1', nonce.into()].span())
            .into() % TWO_POW_120
            .into();
        let value_1_120_bits: u128 = value_1_120_bits_u256.try_into().unwrap();
        nonce += 1;
        let value_2_128_bits: u128 = (hash(['VALUE_2', nonce.into()].span()).into() % TWO_POW_128)
            .try_into()
            .unwrap();
        let packed_value = pack(value_1: value_1_120_bits, value_2: value_2_128_bits);
        let (unpacked_value_1, unpacked_value_2) = unpack(:packed_value);
        assert_eq!(unpacked_value_1, value_1_120_bits);
        assert_eq!(unpacked_value_2, value_2_128_bits);
    }
}

#[test]
fn test_decode_note_amount_open_note() {
    let amounts = [1_u128, 123456789, MAX_U128];
    let channel_key = hash(['CHANNEL_KEY'].span());
    let token: ContractAddress = hash(['TOKEN'].span()).try_into().unwrap();
    let index: usize = 0;
    for amount in amounts.span() {
        let packed_value = pack(value_1: OPEN_NOTE_SALT, value_2: *amount);
        let decoded_amount = decode_note_amount(:packed_value, :channel_key, :token, :index);
        assert_eq!(decoded_amount, *amount);
    }
}

#[test]
fn test_decode_note_amount_open_note_empty() {
    let channel_key = hash(['CHANNEL_KEY'].span());
    let token: ContractAddress = hash(['TOKEN'].span()).try_into().unwrap();
    let index: usize = 0;
    let packed_value = pack(value_1: OPEN_NOTE_SALT, value_2: 0);
    decode_note_amount(:packed_value, :channel_key, :token, :index);
}

#[test]
fn test_to_write_once_action_felt() {
    let value = 'VALUE';
    let key = 'KEY';
    let storage_address = map_entry_address(map_selector: selector!("value"), keys: [key].span());
    let action = to_write_once_action(:storage_address, :value);
    assert_eq!(
        action, ServerAction::WriteOnce(WriteOnceInput { storage_address, value: [value].span() }),
    );
}

#[test]
fn test_compute_message_hash_depends_on_class_hash() {
    let test: Test = Default::default();
    let contract_address = test.privacy.address;
    let storage_address = map_entry_address(
        map_selector: selector!("test_key"), keys: ['MSG_HASH_TEST'].span(),
    );
    let action = to_write_once_action(:storage_address, value: 'VALUE');
    let actions = [action].span();

    // Valid hash from the util (reads class hash from chain).
    let hash_from_util = compute_message_hash(:actions, :contract_address);

    let real_class_hash = get_class_hash(:contract_address);

    // Manually build valid hash: same structure as compute_message_hash.
    let mut l1_data_valid = array![contract_address.into(), Zero::zero()];
    let mut real_payload = array![];
    real_class_hash.serialize(ref real_payload);
    actions.serialize(ref real_payload);
    real_payload.serialize(ref l1_data_valid);
    let hash_manual_valid = poseidon_hash_span(l1_data_valid.span());

    // Manually build invalid hash: zero class hash instead of real.
    let mut l1_data_invalid = array![contract_address.into(), Zero::zero()];
    let mut invalid_payload = array![];
    let zero_class_hash: ClassHash = Zero::zero();
    zero_class_hash.serialize(ref invalid_payload);
    actions.serialize(ref invalid_payload);
    invalid_payload.serialize(ref l1_data_invalid);
    let hash_manual_invalid = poseidon_hash_span(l1_data_invalid.span());

    assert_eq!(hash_from_util, hash_manual_valid);
    assert_ne!(hash_from_util, hash_manual_invalid);
}

#[test]
fn test_deserialize_invoke_return_data_without_addresses() {
    let deposits = [sample_open_note_deposit()].span();
    let mut return_data: Array<felt252> = array![];
    deposits.serialize(ref return_data);

    let (deserialized_deposits, associated_addresses) = deserialize_invoke_return_data(
        return_data.span(),
    );
    assert_eq!(deserialized_deposits, deposits);
    assert_eq!(associated_addresses, None);
}

#[test]
fn test_deserialize_invoke_return_data_with_addresses() {
    let deposits = [sample_open_note_deposit()].span();
    let addresses: Span<ContractAddress> = ['AN_ADDRESS'.try_into().unwrap()].span();
    let mut return_data: Array<felt252> = array![];
    deposits.serialize(ref return_data);
    addresses.serialize(ref return_data);

    let (deserialized_deposits, associated_addresses) = deserialize_invoke_return_data(
        return_data.span(),
    );
    assert_eq!(deserialized_deposits, deposits);
    assert_eq!(associated_addresses, Some(addresses));
}

#[test]
#[should_panic(expected: 'INVALID_ASSOCIATED_ADDRESSES')]
fn test_deserialize_invoke_return_data_rejects_a_malformed_address_span() {
    let deposits = [sample_open_note_deposit()].span();
    let mut return_data: Array<felt252> = array![];
    deposits.serialize(ref return_data);
    // A length prefix promising more addresses than follow.
    return_data.append(2);
    return_data.append('AN_ADDRESS');

    deserialize_invoke_return_data(return_data.span());
}

#[test]
#[should_panic(expected: 'INVALID_INVOKE_RETURN_DATA')]
fn test_deserialize_invoke_return_data_rejects_data_after_the_addresses() {
    let deposits = [sample_open_note_deposit()].span();
    let addresses: Span<ContractAddress> = ['AN_ADDRESS'.try_into().unwrap()].span();
    let mut return_data: Array<felt252> = array![];
    deposits.serialize(ref return_data);
    addresses.serialize(ref return_data);
    return_data.append('EXTRA');

    deserialize_invoke_return_data(return_data.span());
}

fn sample_open_note_deposit() -> OpenNoteDeposit {
    OpenNoteDeposit { note_id: 'NOTE_ID', token: 'TOKEN'.try_into().unwrap(), amount: 1_000_000 }
}

#[test]
fn test_unify_address_records_first_screening_subject() {
    let address: ContractAddress = hash(['SCREENING_SUBJECT'].span()).try_into().unwrap();
    let mut screening_subject: Option<ContractAddress> = None;
    unify_address(ref screening_subject, reference: address);
    assert_eq!(screening_subject, Some(address));
}

#[test]
fn test_unify_address_dedups_same_screening_subject() {
    let address: ContractAddress = hash(['SCREENING_SUBJECT'].span()).try_into().unwrap();
    let mut screening_subject: Option<ContractAddress> = None;
    unify_address(ref screening_subject, reference: address);
    unify_address(ref screening_subject, reference: address);
    assert_eq!(screening_subject, Some(address));
}

#[test]
#[should_panic(expected: 'MULTIPLE_SCREENING_SUBJECTS')]
fn test_unify_address_rejects_distinct_screening_subject() {
    let address: ContractAddress = hash(['SCREENING_SUBJECT'].span()).try_into().unwrap();
    let other_address: ContractAddress = hash(['OTHER_SCREENING_SUBJECT'].span())
        .try_into()
        .unwrap();
    let mut screening_subject: Option<ContractAddress> = None;
    unify_address(ref screening_subject, reference: address);
    unify_address(ref screening_subject, reference: other_address);
}
