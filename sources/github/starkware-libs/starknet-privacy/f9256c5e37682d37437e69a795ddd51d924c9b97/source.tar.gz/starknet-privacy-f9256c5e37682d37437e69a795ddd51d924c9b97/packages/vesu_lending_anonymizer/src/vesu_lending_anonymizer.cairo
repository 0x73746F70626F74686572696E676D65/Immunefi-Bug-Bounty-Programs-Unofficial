//! Vesu lending anonymizer for privacy-preserving deposit and withdraw operations.
//!
//! Integrates with [Vesu](https://vesu.xyz), a permissionless lending protocol on Starknet that
//! uses ERC-4626 / SNIP-22 compatible tokenized vaults. Each pool is a vault: depositing underlying
//! assets mints share tokens; withdrawing burns shares and returns underlying.
//!
//! ## Contract call details
//!
//! **Deposit** (underlying → shares): Calls `deposit(assets: u256, receiver: ContractAddress)` on
//! the vault (`out_token`). The vault pulls `in_token` (underlying) from the caller after prior
//! approval.
//!
//! **Withdraw** (shares → underlying): Calls `redeem(shares: u256, receiver: ContractAddress,
//! owner: ContractAddress)` on the vault (`in_token`), burning the given share count from `owner`
//! and sending the corresponding underlying to `receiver`.

use privacy::objects::OpenNoteDeposit;
use starknet::ContractAddress;

/// Interface for the Vesu vToken contract, copied here only to build a dispatcher; the canonical
/// interface and its semantics are documented upstream.
///
/// Reference: [vToken docs](https://docs.vesu.xyz/developers/core/vtoken#deposit--withdraw)
#[starknet::interface]
pub trait IVToken<T> {
    fn deposit(ref self: T, assets: u256, receiver: ContractAddress) -> u256;
    fn redeem(ref self: T, shares: u256, receiver: ContractAddress, owner: ContractAddress) -> u256;
}

/// Lending operation to perform on a Vesu vault.
#[derive(Serde, Copy, Drop, PartialEq, Debug)]
pub enum LendingOperation {
    Deposit,
    Withdraw,
}

#[starknet::interface]
pub trait IVesuLendingAnonymizer<T> {
    /// Executes a lending operation on the VESU lending pool.
    ///
    /// Can be called by the privacy contract via the
    /// [`INVOKE_SELECTOR`](privacy::utils::constants::INVOKE_SELECTOR) selector.
    ///
    /// #### Parameters
    /// - `operation` ([`LendingOperation`](LendingOperation)) - `Deposit` (supply underlying,
    /// receive vToken shares) or `Withdraw` (redeem vToken shares, receive underlying).
    /// - `in_token` (`ContractAddress`) - The token that flows from the anonymizer into the Vesu
    /// vault: the underlying on Deposit, the vToken on Withdraw.
    /// - `out_token` (`ContractAddress`) - The token that flows out of the Vesu vault back to the
    /// anonymizer: the vToken on Deposit, the underlying on Withdraw.
    /// - `amount` (`u256`) - On Deposit, the amount of underlying to supply; on Withdraw, the
    /// number of vToken shares to redeem.
    /// - `note_id` (`felt252`) - The identifier of the open note to deposit the output to.
    ///
    /// #### Returns
    /// - ([`Span<OpenNoteDeposit>`](privacy::objects::OpenNoteDeposit)) - span of deposits for the
    /// privacy contract to apply.
    ///
    /// #### Preconditions
    /// - `in_token` must not be zero.
    /// - `out_token` must not be zero.
    /// - `amount` must not be zero.
    /// - `in_token` must not be equal to `out_token`.
    /// - The contract must have sufficient input token balance.
    /// - On deposit, `out_token` must be a Vesu Token contract.
    /// - On withdraw, `in_token` must be a Vesu Token contract.
    ///
    /// #### Flow
    /// 1. If operation is Deposit, approves the Vesu Token contract to spend `amount` of
    /// `in_token`.
    /// 2. Records output token balance, calls the corresponding lending function, calculates
    /// received amount.
    /// 3. Approves the caller (privacy contract) to transfer the received output funds.
    /// 4. Returns (note_id, out_token, out_amount).
    // TODO: consider renaming `in_token`/`out_token` to e.g. `spend_token`/`receive_token`.
    fn privacy_invoke(
        ref self: T,
        operation: LendingOperation,
        in_token: ContractAddress,
        out_token: ContractAddress,
        amount: u256,
        note_id: felt252,
    ) -> Span<OpenNoteDeposit>;
}

/// Error codes for Vesu lending operations.
pub mod errors {
    pub const ZERO_IN_TOKEN: felt252 = 'ZERO_IN_TOKEN';
    pub const ZERO_OUT_TOKEN: felt252 = 'ZERO_OUT_TOKEN';
    pub const ZERO_AMOUNT: felt252 = 'ZERO_AMOUNT';
    pub const TOKENS_EQUAL: felt252 = 'TOKENS_EQUAL';
    pub const RECEIVED_AMOUNT_OVERFLOW: felt252 = 'RECEIVED_AMOUNT_OVERFLOW';
    pub const ZERO_OUT_AMOUNT: felt252 = 'ZERO_OUT_AMOUNT';
}

/// Vesu lending anonymizer contract that performs Vesu deposit/withdraw on behalf of the privacy
/// contract.
#[starknet::contract]
pub mod VesuLendingAnonymizer {
    use core::num::traits::Zero;
    use openzeppelin::interfaces::token::erc20::{IERC20Dispatcher, IERC20DispatcherTrait};
    use privacy::objects::OpenNoteDeposit;
    use starknet::{ContractAddress, get_caller_address, get_contract_address};
    use super::{
        IVTokenDispatcher, IVTokenDispatcherTrait, IVesuLendingAnonymizer, LendingOperation, errors,
    };

    #[storage]
    struct Storage {}

    #[constructor]
    fn constructor(ref self: ContractState) {}

    #[abi(embed_v0)]
    pub impl VesuLendingAnonymizerImpl of IVesuLendingAnonymizer<ContractState> {
        fn privacy_invoke(
            ref self: ContractState,
            operation: LendingOperation,
            in_token: ContractAddress,
            out_token: ContractAddress,
            amount: u256,
            note_id: felt252,
        ) -> Span<OpenNoteDeposit> {
            assert(in_token.is_non_zero(), errors::ZERO_IN_TOKEN);
            assert(out_token.is_non_zero(), errors::ZERO_OUT_TOKEN);
            assert(amount.is_non_zero(), errors::ZERO_AMOUNT);
            assert(in_token != out_token, errors::TOKENS_EQUAL);

            let self_addr = get_contract_address();
            let privacy_addr = get_caller_address();
            let in_erc20 = IERC20Dispatcher { contract_address: in_token };
            let out_erc20 = IERC20Dispatcher { contract_address: out_token };

            // Get output token balance before operation.
            let balance_before = out_erc20.balance_of(account: self_addr);

            // Execute operation.
            // Return value (minted/burned shares) is ignored.
            match operation {
                LendingOperation::Deposit => {
                    // Approve Vesu Token contract to spend `amount` of `in_token`.
                    in_erc20.approve(spender: out_token, :amount);
                    IVTokenDispatcher { contract_address: out_token }
                        .deposit(assets: amount, receiver: self_addr)
                },
                LendingOperation::Withdraw => {
                    // `amount` is the vToken share count to redeem.
                    IVTokenDispatcher { contract_address: in_token }
                        .redeem(shares: amount, receiver: self_addr, owner: self_addr)
                },
            }

            // Assert output amount is correct.
            let balance_after = out_erc20.balance_of(account: self_addr);
            let out_amount: u128 = (balance_after - balance_before)
                .try_into()
                .expect(errors::RECEIVED_AMOUNT_OVERFLOW);
            assert(out_amount.is_non_zero(), errors::ZERO_OUT_AMOUNT);

            // Approve caller (privacy contract) to transfer received output funds.
            out_erc20.approve(spender: privacy_addr, amount: out_amount.into());

            // Returns deposit to open note input.
            [OpenNoteDeposit { note_id, token: out_token, amount: out_amount }].span()
        }
    }
}
