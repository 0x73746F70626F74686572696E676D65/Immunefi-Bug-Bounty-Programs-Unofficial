use core::hash::HashStateTrait;
use core::num::traits::{Bounded, Zero};
use core::poseidon::PoseidonTrait;
use privacy::objects::OpenNoteDeposit;
use shadow_account_anonymizer::shadow_account_anonymizer::ShadowAccountAnonymizer::ShadowAccountDeployed;
use shadow_account_anonymizer::shadow_account_anonymizer::{
    CollectPolicy, IShadowAccountAnonymizerDispatcherTrait, IShadowAccountAnonymizerSafeDispatcher,
    IShadowAccountAnonymizerSafeDispatcherTrait, MAX_SCAN_RANGE, OpenNote, ShadowAccountInfo,
    commitment_from_partial, errors, partial_commitment,
};
use shadow_account_anonymizer::tests::test_utils::{
    Components, ComponentsTrait, GOVERNANCE_ADMIN, PRIVACY, anonymizer_disp, declare_primer,
    deploy_components, deploy_shadow_account_anonymizer, deploy_token, transfer_to_caller_call,
};
use snforge_std::{
    ContractClassTrait, DeclareResultTrait, EventSpyTrait, EventsFilterTrait, TokenTrait, declare,
    spy_events,
};
use starknet::account::Call;
use starknet::syscalls::call_contract_syscall;
use starknet::{ContractAddress, SyscallResult, SyscallResultTrait};
use starkware_accounts::shadow_account::{IShadowAccountDispatcher, IShadowAccountDispatcherTrait};
use starkware_utils_testing::test_utils::{
    TokenHelperTrait, assert_expected_event_emitted, assert_panic_with_felt_error,
    cheat_caller_address_once,
};

const AMOUNT: u128 = 1_000_000;
const NOTE_ID: felt252 = 'NOTE_ID';

/// Resolves the `('USER', 'DAPP', nonce)` shadow account via the range view.
fn shadow_account_info(anonymizer: ContractAddress, nonce: u64) -> ShadowAccountInfo {
    let infos = anonymizer_disp(anonymizer)
        .get_shadow_accounts(partial_commitment('USER', 'DAPP'), nonce, nonce + 1, false);
    *infos[0]
}

#[test]
fn test_get_privacy_contract() {
    let anonymizer = deploy_shadow_account_anonymizer();
    assert_eq!(anonymizer_disp(anonymizer).get_privacy_contract(), PRIVACY);
}

#[test]
fn test_get_shadow_account_class_hash() {
    let anonymizer = deploy_shadow_account_anonymizer();
    let expected = *declare("ShadowAccount").unwrap_syscall().contract_class().class_hash;
    assert_eq!(anonymizer_disp(anonymizer).get_shadow_account_class_hash(), expected);
}

#[test]
fn test_get_shadow_account_unknown_identity_commitment_is_zero() {
    let anonymizer = deploy_shadow_account_anonymizer();
    assert!(anonymizer_disp(anonymizer).get_shadow_account('UNKNOWN').is_zero());
}

/// `get_shadow_account` reports only what is stored, so an undeployed commitment reads back as
/// zero. The address such a commitment *would* deploy to comes from the range view instead, which
/// `test_get_shadow_accounts_computed_address_matches_deploy` covers.
#[test]
fn test_undeployed_shadow_account_has_no_stored_address() {
    let anonymizer = deploy_shadow_account_anonymizer();
    let commitment = commitment_from_partial(partial_commitment('USER', 'DAPP'), 0);

    assert!(!shadow_account_info(anonymizer, 0).is_deployed);
    assert!(anonymizer_disp(anonymizer).get_shadow_account(commitment).is_zero());
}

#[test]
fn test_privacy_compute_is_two_stage_poseidon() {
    let anonymizer = deploy_shadow_account_anonymizer();
    let identity_commitment = anonymizer_disp(anonymizer).privacy_compute('USER', 'DAPP', 7);
    // Two-stage: hash(hash(identity_key, dapp_name), nonce).
    let expected_partial = PoseidonTrait::new().update('USER').update('DAPP').finalize();
    let expected = PoseidonTrait::new().update(expected_partial).update(7).finalize();
    assert_eq!(identity_commitment, expected);
    // The exported helpers reproduce each stage.
    assert_eq!(partial_commitment('USER', 'DAPP'), expected_partial);
    assert_eq!(commitment_from_partial(expected_partial, 7), expected);
}

#[test]
fn test_privacy_compute_is_deterministic_and_distinct() {
    let anonymizer = anonymizer_disp(deploy_shadow_account_anonymizer());
    let base = anonymizer.privacy_compute('USER', 'DAPP', 1);
    // Deterministic for the same inputs.
    assert_eq!(base, anonymizer.privacy_compute('USER', 'DAPP', 1));
    // Each input affects the identity commitment.
    assert_ne!(base, anonymizer.privacy_compute('OTHER', 'DAPP', 1));
    assert_ne!(base, anonymizer.privacy_compute('USER', 'OTHER', 1));
    assert_ne!(base, anonymizer.privacy_compute('USER', 'DAPP', 2));
}

#[test]
fn test_invoke_executes_and_collects_open_note() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    // Fund the dapp so the shadow account-driven call pays the shadow account `AMOUNT`.
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);

    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All },
            ]
                .span(),
        );

    // One deposit returned, matching the collected token/amount.
    assert_eq!(deposits.len(), 1);
    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, AMOUNT);

    let shadow_account = shadow_account_info(components.anonymizer, 1).address;
    assert!(shadow_account.is_non_zero());
    // Funds flowed dapp -> shadow account -> anonymizer, and the privacy contract is approved to
    // pull.
    assert_eq!(components.token.balance_of(components.mock_dapp), 0);
    assert_eq!(components.token.balance_of(shadow_account), 0);
    assert_eq!(components.token.balance_of(components.anonymizer), AMOUNT.into());
    assert_eq!(components.token.allowance(components.anonymizer, PRIVACY), AMOUNT.into());
}

#[test]
fn test_deploy_emits_shadow_account_deployed_event() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let identity_commitment = anonymizer.privacy_compute('USER', 'DAPP', 1);

    // The first invoke deploys the shadow account and emits the event.
    let mut spy = spy_events();
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());
    let shadow_account = anonymizer.get_shadow_account(identity_commitment);
    let expected_event = ShadowAccountDeployed { identity_commitment, shadow_account };
    let events = spy.get_events().emitted_by(contract_address: components.anonymizer).events;
    assert_eq!(events.len(), 1);
    assert_expected_event_emitted(
        spied_event: events[0],
        :expected_event,
        expected_event_selector: @selector!("ShadowAccountDeployed"),
        expected_event_name: "ShadowAccountDeployed",
    );

    // A second invoke reuses the shadow account, so no new deployment event is emitted.
    let mut spy = spy_events();
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());
    let events = spy.get_events().emitted_by(contract_address: components.anonymizer).events;
    assert_eq!(events.len(), 0);
}

#[test]
#[feature("safe_dispatcher")]
fn test_invoke_only_privacy_contract() {
    let components = deploy_components();
    // No caller cheat: the caller is the test contract, not the privacy contract.
    let safe = IShadowAccountAnonymizerSafeDispatcher { contract_address: components.anonymizer };
    let result = safe
        .privacy_invoke_with_computation(
            identity_commitment: 0, calls: array![], open_notes: array![].span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::UNAUTHORIZED_CALLER);
}

#[test]
fn test_collects_multiple_open_notes() {
    let components = deploy_components();
    let token_a = components.token;
    let token_b = deploy_token();
    let addr_a = token_a.contract_address();
    let addr_b = token_b.contract_address();
    assert!(addr_a != addr_b);
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    let amount_a: u128 = 1_000_000;
    let amount_b: u128 = 2_500_000;
    token_a.supply(address: components.mock_dapp, amount: amount_a);
    token_b.supply(address: components.mock_dapp, amount: amount_b);

    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![
                transfer_to_caller_call(components.mock_dapp, addr_a, amount_a),
                transfer_to_caller_call(components.mock_dapp, addr_b, amount_b),
            ],
            open_notes: array![
                OpenNote { note_id: 'NOTE_A', token: addr_a, collect_policy: CollectPolicy::All },
                OpenNote { note_id: 'NOTE_B', token: addr_b, collect_policy: CollectPolicy::All },
            ]
                .span(),
        );

    // One deposit per note, each carrying its own token/amount.
    assert_eq!(deposits.len(), 2);
    let OpenNoteDeposit { note_id: id_a, token: tok_a, amount: amt_a } = *deposits[0];
    assert_eq!(id_a, 'NOTE_A');
    assert_eq!(tok_a, addr_a);
    assert_eq!(amt_a, amount_a);
    let OpenNoteDeposit { note_id: id_b, token: tok_b, amount: amt_b } = *deposits[1];
    assert_eq!(id_b, 'NOTE_B');
    assert_eq!(tok_b, addr_b);
    assert_eq!(amt_b, amount_b);

    assert_eq!(token_a.balance_of(components.mock_dapp), 0);
    assert_eq!(token_b.balance_of(components.mock_dapp), 0);
    assert_eq!(token_a.balance_of(components.anonymizer), amount_a.into());
    assert_eq!(token_b.balance_of(components.anonymizer), amount_b.into());
    assert_eq!(token_a.allowance(components.anonymizer, PRIVACY), amount_a.into());
    assert_eq!(token_b.allowance(components.anonymizer, PRIVACY), amount_b.into());
}

#[test]
fn test_multiple_invokes_run_in_one_call() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    let first: u128 = 700_000;
    let second: u128 = 300_000;
    components.token.supply(address: components.mock_dapp, amount: first + second);

    // Two calls in one interaction; both run as the shadow account and their output is combined.
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![
                transfer_to_caller_call(components.mock_dapp, token, first),
                transfer_to_caller_call(components.mock_dapp, token, second),
            ],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All },
            ]
                .span(),
        );

    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, first + second);
    assert_eq!(components.token.balance_of(components.anonymizer), (first + second).into());
}

#[test]
fn test_invoke_but_not_collect() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    components.token.supply(address: components.mock_dapp, amount: AMOUNT);

    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![].span(),
        );
    assert_eq!(deposits.len(), 0);
    assert_eq!(components.token.balance_of(components.anonymizer), 0);
    let shadow_account = shadow_account_info(components.anonymizer, 1).address;
    assert_eq!(components.token.balance_of(shadow_account), AMOUNT.into());
}

#[test]
fn test_deployed_shadow_account_owned_by_anonymizer() {
    let components = deploy_components();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());

    let shadow_account = shadow_account_info(components.anonymizer, 1).address;
    // The anonymizer is the shadow account's deployer, so it is the only authorized controller.
    assert_eq!(
        IShadowAccountDispatcher { contract_address: shadow_account }.owner(),
        components.anonymizer,
    );
}

#[test]
fn test_shadow_account_is_reused_per_identity_commitment() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let identity_commitment_a = anonymizer.privacy_compute('USER', 'DAPP', 1);
    let identity_commitment_b = anonymizer.privacy_compute('USER', 'DAPP', 2);
    let no_notes = array![].span();

    components
        .invoke(identity_commitment: identity_commitment_a, calls: array![], open_notes: no_notes);
    let shadow_account_a = shadow_account_info(components.anonymizer, 1);
    assert!(shadow_account_a.is_deployed);

    // Same identity commitment reuses the same shadow account (no redeploy).
    components
        .invoke(identity_commitment: identity_commitment_a, calls: array![], open_notes: no_notes);
    assert_eq!(shadow_account_info(components.anonymizer, 1).address, shadow_account_a.address);

    // A different identity commitment gets a distinct shadow account.
    components
        .invoke(identity_commitment: identity_commitment_b, calls: array![], open_notes: no_notes);
    let shadow_account_b = shadow_account_info(components.anonymizer, 2);
    assert!(shadow_account_b.is_deployed);
    assert!(shadow_account_b.address != shadow_account_a.address);
}

#[test]
fn test_collects_full_balance_including_preexisting() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    // Deploy the shadow account (empty invoke) so we can give it a pre-existing balance.
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());
    let shadow_account = shadow_account_info(components.anonymizer, 1).address;
    let preexisting: u128 = 500_000;
    components.token.supply(address: shadow_account, amount: preexisting);

    // The interaction adds `AMOUNT` on top of the pre-existing balance.
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All },
            ]
                .span(),
        );

    // The full balance is collected: pre-existing plus the amount added by the interaction.
    let total = preexisting + AMOUNT;
    assert_eq!(deposits.len(), 1);
    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, total);
    assert_eq!(components.token.balance_of(components.mock_dapp), 0);
    assert_eq!(components.token.balance_of(shadow_account), 0);
    assert_eq!(components.token.balance_of(components.anonymizer), total.into());
    assert_eq!(components.token.allowance(components.anonymizer, PRIVACY), total.into());
}

#[test]
#[feature("safe_dispatcher")]
fn test_zero_balance_reverts() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);
    let safe = IShadowAccountAnonymizerSafeDispatcher { contract_address: components.anonymizer };
    let open_note_all = OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All };
    let calls = array![];

    // Deploy the shadow account (empty invoke) first.
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());

    // All with zero balance.
    cheat_caller_address_once(contract_address: components.anonymizer, caller_address: PRIVACY);
    let result = safe
        .privacy_invoke_with_computation(
            :identity_commitment, :calls, open_notes: array![open_note_all].span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::ZERO_BALANCE);

    // Diff with zero balance.
    let open_note_diff = OpenNote { collect_policy: CollectPolicy::Diff, ..open_note_all };
    cheat_caller_address_once(contract_address: components.anonymizer, caller_address: PRIVACY);
    let result = safe
        .privacy_invoke_with_computation(
            :identity_commitment, calls: array![], open_notes: array![open_note_diff].span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::ZERO_BALANCE);

    // Zero diff with non-zero balance.
    let shadow_account = anonymizer_disp(components.anonymizer)
        .get_shadow_account(identity_commitment);
    let preexisting: u128 = 500_000;
    components.token.supply(address: shadow_account, amount: preexisting);
    cheat_caller_address_once(contract_address: components.anonymizer, caller_address: PRIVACY);
    let result = safe
        .privacy_invoke_with_computation(
            :identity_commitment, calls: array![], open_notes: array![open_note_diff].span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::ZERO_BALANCE);

    // Exact with zero balance.
    let open_note_exact = OpenNote { collect_policy: CollectPolicy::Exact(0), ..open_note_all };
    cheat_caller_address_once(contract_address: components.anonymizer, caller_address: PRIVACY);
    let result = safe
        .privacy_invoke_with_computation(
            :identity_commitment, calls: array![], open_notes: array![open_note_exact].span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::ZERO_BALANCE);
}

#[test]
#[feature("safe_dispatcher")]
fn test_collects_remaining_balance_after_invoke_transfers_out() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    // Deploy and pre-fund the shadow account.
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());
    let shadow_account = shadow_account_info(components.anonymizer, 1).address;
    let preexisting: u128 = 1_000_000;
    components.token.supply(address: shadow_account, amount: preexisting);

    // The invoke makes the shadow account send some tokens out; only the remainder is collected.
    let sink: ContractAddress = 'SINK'.try_into().unwrap();
    let sent: u128 = 300_000;
    let transfer = Call {
        to: token,
        selector: selector!("transfer"),
        calldata: array![sink.into(), sent.into(), 0].span(),
    };
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All },
            ]
                .span(),
        );

    // The balance left after the outbound transfer is collected; funds sent out are not recovered.
    let remaining = preexisting - sent;
    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, remaining);
    assert_eq!(components.token.balance_of(shadow_account), 0);
    assert_eq!(components.token.balance_of(components.anonymizer), remaining.into());
    assert_eq!(components.token.balance_of(sink), sent.into());

    // Try to collect with diff policy.
    components.token.supply(address: shadow_account, amount: preexisting);
    let safe = IShadowAccountAnonymizerSafeDispatcher { contract_address: components.anonymizer };
    cheat_caller_address_once(contract_address: components.anonymizer, caller_address: PRIVACY);
    let result = safe
        .privacy_invoke_with_computation(
            :identity_commitment,
            calls: array![transfer],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::Diff },
            ]
                .span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::NEGATIVE_DIFF);
}

#[test]
fn test_collect_diff_takes_only_interaction_gain() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    // When no pre-existing balance, `Diff` collects everything.
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::Diff },
            ]
                .span(),
        );
    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, AMOUNT);
    let shadow_account = anonymizer_disp(components.anonymizer)
        .get_shadow_account(identity_commitment);
    assert_eq!(components.token.balance_of(shadow_account), 0);
    assert_eq!(components.token.balance_of(components.anonymizer), AMOUNT.into());
    assert_eq!(components.token.allowance(components.anonymizer, PRIVACY), AMOUNT.into());

    // Fund the shadow account with a pre-existing balance that `Diff` must leave untouched.
    let preexisting: u128 = 500_000;
    components.token.supply(address: shadow_account, amount: preexisting);

    // The interaction adds `AMOUNT`; `Diff` collects only that gain.
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::Diff },
            ]
                .span(),
        );

    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, AMOUNT);
    // Only the interaction gain is collected; the pre-existing balance stays in the shadow account.
    assert_eq!(components.token.balance_of(shadow_account), preexisting.into());
    assert_eq!(components.token.balance_of(components.anonymizer), 2 * AMOUNT.into());
    assert_eq!(components.token.allowance(components.anonymizer, PRIVACY), AMOUNT.into());
}

#[test]
#[feature("safe_dispatcher")]
fn test_collect_exact_policy() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    // The interaction pays the shadow account `AMOUNT`; `Exact` collects only part of it.
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);
    let exact: u128 = 400_000;
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::Exact(exact) },
            ]
                .span(),
        );

    let shadow_account = anonymizer_disp(components.anonymizer)
        .get_shadow_account(identity_commitment);
    assert_eq!(deposits.len(), 1);
    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, exact);
    // Only `exact` is collected; the rest of the interaction payout stays in the shadow account.
    let remaining = AMOUNT - exact;
    assert_eq!(components.token.balance_of(shadow_account), remaining.into());
    assert_eq!(components.token.balance_of(components.anonymizer), exact.into());
    assert_eq!(components.token.allowance(components.anonymizer, PRIVACY), exact.into());

    // Test collect exact remaining balance.
    let deposits = components
        .invoke(
            :identity_commitment,
            calls: array![],
            open_notes: array![
                OpenNote {
                    note_id: NOTE_ID, token, collect_policy: CollectPolicy::Exact(remaining),
                },
            ]
                .span(),
        );
    assert_eq!(deposits.len(), 1);
    let OpenNoteDeposit { note_id, token: deposit_token, amount } = *deposits[0];
    assert_eq!(note_id, NOTE_ID);
    assert_eq!(deposit_token, token);
    assert_eq!(amount, remaining);
    assert_eq!(components.token.balance_of(shadow_account), 0);
    assert_eq!(components.token.balance_of(components.anonymizer), remaining.into() + exact.into());
    assert_eq!(components.token.allowance(components.anonymizer, PRIVACY), remaining.into());

    // Try to collect exceeding balance.
    cheat_caller_address_once(contract_address: components.anonymizer, caller_address: PRIVACY);
    let safe = IShadowAccountAnonymizerSafeDispatcher { contract_address: components.anonymizer };
    let result = safe
        .privacy_invoke_with_computation(
            :identity_commitment,
            calls: array![],
            open_notes: array![
                OpenNote {
                    note_id: NOTE_ID, token, collect_policy: CollectPolicy::Exact(remaining),
                },
            ]
                .span(),
        );
    assert_panic_with_felt_error(:result, expected_error: errors::INSUFFICIENT_BALANCE);
}

#[test]
#[should_panic(expected: 'AMOUNT_OVERFLOW')]
fn test_collected_amount_overflow() {
    let components = deploy_components();
    let token = components.token.contract_address();
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', 1);

    // Fund the dapp with `u128::MAX + 1` (two supplies, since `supply` takes a u128).
    let max = Bounded::<u128>::MAX;
    components.token.supply(address: components.mock_dapp, amount: max);
    components.token.supply(address: components.mock_dapp, amount: 1);

    // Two pay-outs add `u128::MAX + 1` to the shadow account, so the collected delta overflows
    // u128.
    components
        .invoke(
            :identity_commitment,
            calls: array![
                transfer_to_caller_call(components.mock_dapp, token, max),
                transfer_to_caller_call(components.mock_dapp, token, 1),
            ],
            open_notes: array![
                OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All },
            ]
                .span(),
        );
}

/// Deploys the shadow account for `('USER', 'DAPP', nonce)` via an empty invoke.
fn deploy_nonce(components: Components, nonce: u64) {
    let identity_commitment = anonymizer_disp(components.anonymizer)
        .privacy_compute('USER', 'DAPP', nonce.into());
    components.invoke(:identity_commitment, calls: array![], open_notes: array![].span());
}

#[test]
fn test_get_shadow_accounts_resolves_deployed_and_undeployed() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let partial = partial_commitment('USER', 'DAPP');
    deploy_nonce(components, 0);
    deploy_nonce(components, 1);

    // Nonce 2 is undeployed; the view resolves every nonce in range with an is_deployed flag.
    let infos = anonymizer.get_shadow_accounts(partial, 0, 3, false);
    assert_eq!(infos.len(), 3);
    assert_eq!((*infos[0]).nonce, 0);
    assert!((*infos[0]).is_deployed);
    assert!((*infos[1]).is_deployed);
    let undeployed = *infos[2];
    assert_eq!(undeployed.nonce, 2);
    assert!(!undeployed.is_deployed);
    // Even undeployed, it resolves to the deterministic address it would deploy to.
    assert!(undeployed.address.is_non_zero());
}

#[test]
fn test_get_shadow_accounts_until_undeployed_returns_deployed_prefix() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let partial = partial_commitment('USER', 'DAPP');
    deploy_nonce(components, 0);
    deploy_nonce(components, 1);

    // Nonce 2 is the first gap, so until_undeployed returns nonces 0 and 1 and stops there.
    let infos = anonymizer.get_shadow_accounts(partial, 0, 5, true);
    assert_eq!(infos.len(), 2);
    assert_eq!((*infos[0]).nonce, 0);
    assert_eq!((*infos[1]).nonce, 1);
}

#[test]
fn test_get_shadow_accounts_until_undeployed_on_leading_gap_is_empty() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let partial = partial_commitment('USER', 'DAPP');

    // The range's first nonce is undeployed, so the deployed prefix is empty.
    let infos = anonymizer.get_shadow_accounts(partial, 0, 5, true);
    assert_eq!(infos.len(), 0);
}

#[test]
fn test_get_shadow_accounts_computed_address_matches_deploy() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let partial = partial_commitment('USER', 'DAPP');

    let before = *anonymizer.get_shadow_accounts(partial, 0, 1, false)[0];
    assert!(!before.is_deployed);
    deploy_nonce(components, 0);
    let after = *anonymizer.get_shadow_accounts(partial, 0, 1, false)[0];
    assert!(after.is_deployed);
    // The address computed before deployment matches the actual on-chain deploy address.
    assert_eq!(before.address, after.address);
}

#[test]
fn test_get_shadow_accounts_scopes_by_dapp_and_nonce() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let dapp = anonymizer.get_shadow_accounts(partial_commitment('USER', 'DAPP'), 0, 2, false);
    let nonce0 = *dapp[0];
    let nonce1 = *dapp[1];
    let other_dapp = *anonymizer
        .get_shadow_accounts(partial_commitment('USER', 'OTHER'), 0, 1, false)[0];
    assert!(nonce0.address != nonce1.address);
    assert!(nonce0.address != other_dapp.address);
}

#[test]
fn test_get_shadow_accounts_from_start_nonce() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let partial = partial_commitment('USER', 'DAPP');
    deploy_nonce(components, 0);
    deploy_nonce(components, 1);

    // Scanning from nonce 1 skips nonce 0; entries carry their own nonce.
    let infos = anonymizer.get_shadow_accounts(partial, 1, 3, false);
    assert_eq!(infos.len(), 2);
    assert_eq!((*infos[0]).nonce, 1);
    assert!((*infos[0]).is_deployed);
    assert_eq!((*infos[1]).nonce, 2);
    assert!(!(*infos[1]).is_deployed);
}

#[test]
fn test_get_shadow_accounts_empty_range() {
    let components = deploy_components();
    let infos = anonymizer_disp(components.anonymizer)
        .get_shadow_accounts(partial_commitment('USER', 'DAPP'), 5, 5, false);
    assert_eq!(infos.len(), 0);
}

#[test]
#[should_panic(expected: 'RANGE_TOO_LARGE')]
fn test_get_shadow_accounts_range_too_large_reverts() {
    let components = deploy_components();
    anonymizer_disp(components.anonymizer)
        .get_shadow_accounts(partial_commitment('USER', 'DAPP'), 0, MAX_SCAN_RANGE + 1, false);
}

#[test]
#[should_panic(expected: 'INVALID_RANGE')]
fn test_get_shadow_accounts_inverted_range_reverts() {
    let components = deploy_components();
    anonymizer_disp(components.anonymizer)
        .get_shadow_accounts(partial_commitment('USER', 'DAPP'), 5, 3, false);
}

/// A single open note collecting the shadow account's whole `token` balance.
fn collect_all_note(token: ContractAddress) -> Span<OpenNote> {
    array![OpenNote { note_id: NOTE_ID, token, collect_policy: CollectPolicy::All }].span()
}

/// The calldata the privacy contract calls `privacy_invoke_with_computation` with.
fn invoke_calldata(
    identity_commitment: felt252, calls: Array<Call>, open_notes: Span<OpenNote>,
) -> Span<felt252> {
    let mut calldata = array![identity_commitment];
    calls.serialize(ref calldata);
    open_notes.serialize(ref calldata);
    calldata.span()
}

/// Runs the invoke over a raw syscall, the way the privacy contract does, and hands back its
/// undecoded return data.
fn invoke_return_data(
    anonymizer: ContractAddress, invoke_calldata: Span<felt252>,
) -> SyscallResult<Span<felt252>> {
    cheat_caller_address_once(contract_address: anonymizer, caller_address: PRIVACY);
    call_contract_syscall(
        address: anonymizer,
        entry_point_selector: selector!("privacy_invoke_with_computation"),
        calldata: invoke_calldata,
    )
}

#[test]
fn test_invoke_returns_the_shadow_account_it_ran_through() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let token = components.token.contract_address();
    let identity_commitment = anonymizer.privacy_compute('USER', 'DAPP', 1);
    // The address is known before the account exists, so an attestation can be minted ahead of the
    // interaction.
    let predicted = shadow_account_info(components.anonymizer, 1).address;
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);

    let (deposits, associated_addresses) = components
        .invoke_returning_addresses(
            :identity_commitment,
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: collect_all_note(token),
        );

    assert_eq!(deposits.len(), 1);
    assert_eq!(associated_addresses.len(), 1);
    // The funds passed through this account, and it is the one the prediction pointed at.
    assert_eq!(*associated_addresses[0], anonymizer.get_shadow_account(identity_commitment));
    assert_eq!(*associated_addresses[0], predicted);
}

#[test]
fn test_invoke_without_open_notes_returns_no_address() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let token = components.token.contract_address();
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);

    // An interaction settling no note funds no deposit, so it returns no address. The dapp call
    // still runs, and whatever it leaves in the shadow account goes uncollected.
    let (deposits, associated_addresses) = components
        .invoke_returning_addresses(
            identity_commitment: anonymizer.privacy_compute('USER', 'DAPP', 1),
            calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
            open_notes: array![].span(),
        );

    assert!(deposits.is_empty());
    assert!(associated_addresses.is_empty());
}

#[test]
fn test_invoke_return_data_is_the_deposits_then_the_addresses() {
    let components = deploy_components();
    let anonymizer = anonymizer_disp(components.anonymizer);
    let token = components.token.contract_address();
    let identity_commitment = anonymizer.privacy_compute('USER', 'DAPP', 1);
    components.token.supply(address: components.mock_dapp, amount: AMOUNT);
    let calldata = invoke_calldata(
        identity_commitment,
        calls: array![transfer_to_caller_call(components.mock_dapp, token, AMOUNT)],
        open_notes: collect_all_note(token),
    );

    // The privacy contract deserializes the deposits, then the addresses, and rejects anything left
    // over. Read the raw return data in that order to pin the layout it depends on.
    let mut return_data = invoke_return_data(components.anonymizer, calldata).unwrap_syscall();
    let deposits: Span<OpenNoteDeposit> = Serde::deserialize(ref return_data).unwrap();
    let associated_addresses: Span<ContractAddress> = Serde::deserialize(ref return_data).unwrap();
    assert!(return_data.is_empty());
    assert_eq!(deposits.len(), 1);
    assert_eq!(associated_addresses.len(), 1);
    assert_eq!(*associated_addresses[0], anonymizer.get_shadow_account(identity_commitment));
}


/// A committed cross-language vector. The SDK's `shadow-account-address` test derives the same
/// felts from the same inputs, so the off-chain derivation cannot drift from the contract's. This
/// test deploys the anonymizer at the vector's own address and goes through its entry points, so
/// the expected felts pin the deployed contract rather than restate its recipe.
#[test]
fn test_shadow_account_derivation_matches_the_committed_vector() {
    let anonymizer_address: ContractAddress = 0x444.try_into().unwrap();
    declare_primer();
    let shadow_account_class_hash = *declare("ShadowAccount")
        .unwrap_syscall()
        .contract_class()
        .class_hash;
    declare("ShadowAccountAnonymizer")
        .unwrap_syscall()
        .contract_class()
        .deploy_at(
            @array![PRIVACY.into(), shadow_account_class_hash.into(), GOVERNANCE_ADMIN.into()],
            anonymizer_address,
        )
        .unwrap_syscall();
    let anonymizer = anonymizer_disp(anonymizer_address);

    let partial = partial_commitment(identity_key: 0x111, dapp_name: 0x222);
    assert_eq!(partial, 0xdbb320724c2f71919310007cc2ee821e9b234b98535d24dae197124c2ef4fb);

    let commitment = anonymizer.privacy_compute(identity_key: 0x111, dapp_name: 0x222, nonce: 0x3);
    assert_eq!(commitment, 0x418bf56bebf218ffa365531394e68b3336a9557b5b8be8ad6a21f44e79833b);

    let shadow_accounts = anonymizer
        .get_shadow_accounts(
            partial_commitment: partial, start_nonce: 3, end_nonce: 4, until_undeployed: false,
        );
    assert_eq!(
        *shadow_accounts[0].address,
        0x5e1a753154c6cbb012b819c0362921b7040df54b90bb9241f54e7d946cf9708.try_into().unwrap(),
    );
}
