from yattag import Doc
import json
import pathlib
import argparse
import inflection
from argparse import ArgumentParser
from typing import NamedTuple

import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd
import seaborn as sns
import numpy as np
from pandas import DataFrame

sns.set_palette("deep")
sns.set_color_codes("deep")
mpl.rcParams["figure.figsize"] = [16 * 0.8, 9 * 0.8]


class Args(NamedTuple):
    native_data: pathlib.Path
    vm_data: pathlib.Path
    output_dir: pathlib.Path
    display: bool


arg_parser = ArgumentParser()
arg_parser.add_argument("native_data", type=pathlib.Path)
arg_parser.add_argument("vm_data", type=pathlib.Path)
arg_parser.add_argument("--output-dir", type=pathlib.Path)
arg_parser.add_argument(
    "--display", action=argparse.BooleanOptionalAction, default=True
)


args: Args = arg_parser.parse_args()  # type: ignore

if args.output_dir:
    args.output_dir.mkdir(parents=True, exist_ok=True)

#############
# UTILITIES #
#############


def format_hash(class_hash):
    return f"{class_hash[:6]}..."


# A list of all the figures generated. Used to generate a final report.
OUTPUT_FIGURES = []


# Saves the current figure to the output directory, deriving the file name from
# the given title. Adds the figure data to `OUTPUT_FIGURES`, which can then be
# used to generate a report with all the figures.
def save_figure(title, description=""):
    if args.output_dir:
        stem = inflection.parameterize(title)
        name = f"{stem}.svg"
        OUTPUT_FIGURES.append(
            {
                title: title,
                name: name,
                description: description,
            }
        )
        plt.savefig(args.output_dir.joinpath(name))


# Saves the current dataframe to the output directory, deriving the file name
# from the given title.
def save_csv(data, title, *to_csv_args, **to_csv_kwargs):
    if args.output_dir:
        stem = inflection.parameterize(title)
        name = f"{stem}.csv"
        data.to_csv(args.output_dir.joinpath(name), *to_csv_args, **to_csv_kwargs)


##############
# PROCESSING #
##############


def load_data(path):
    raw_json = json.load(open(path))

    df_txs = pd.DataFrame(raw_json["transactions"])
    df_calls = pd.DataFrame(raw_json["calls"])

    info = pd.Series(raw_json["info"])
    info["memory"] = round(int(info["memory"]) / 2**30, 2)
    info.rename(
        {
            "date": "Date",
            "block_start": "Block Start",
            "block_end": "Block End",
            "block": "Block",
            "tx": "Tx",
            "net": "Net",
            "laps": "Laps",
            "mode": "Mode",
            "native_profile": "Native Profile",
            "rust_profile": "Rust Profile",
            "cairo_native_version": "Cairo Native Version",
            "sequencer_version": "Sequencer Version",
            "os": "OS",
            "arch": "Arch",
            "cpu": "CPU",
            "memory": "Memory (GiB)",
        },
        inplace=True,
    )
    info["Minimum sierra version for sierra gas"] = "0.0.0"

    return df_txs, df_calls, info


df_txs_native, df_calls_native, native_info = load_data(args.native_data)
df_txs_vm, df_calls_vm, vm_info = load_data(args.vm_data)

# Assert Native and VM tx execution coincide.
assert (df_txs_native.index == df_txs_vm.index).all()
assert (df_txs_native["tx_hash"] == df_txs_vm["tx_hash"]).all()
assert (df_txs_native["block_number"] == df_txs_vm["block_number"]).all()
assert (df_txs_native["gas_consumed"] == df_txs_vm["gas_consumed"]).all()
assert (df_txs_native["steps"] == df_txs_vm["steps"]).all()
assert (df_txs_native["failed"] == df_txs_vm["failed"]).all()

# Assert Native and VM call execution coincide.
assert (df_calls_native.index == df_calls_vm.index).all()
assert (df_calls_native["tx_hash"] == df_calls_vm["tx_hash"]).all()
assert (df_calls_native["class_hash"] == df_calls_vm["class_hash"]).all()
assert (df_calls_native["selector"] == df_calls_vm["selector"]).all()
assert (df_calls_native["gas_consumed"] == df_calls_vm["gas_consumed"]).all()
assert (df_calls_native["steps"] == df_calls_vm["steps"]).all()

# merge transactions into single dataframe
df_txs = pd.merge(
    df_txs_native,
    df_txs_vm.drop(
        [
            "tx_hash",
            "block_number",
            "gas_consumed",
            "steps",
            "failed",
        ],
        axis=1,
    ),
    left_index=True,
    right_index=True,
    suffixes=("_native", "_vm"),
)
# merge steps into gas_consumed
df_txs["gas_consumed"] += df_txs["steps"] * 100
df_txs = df_txs.drop("steps", axis=1)
# calculate speedup
df_txs["speedup"] = df_txs["time_ns_vm"] / df_txs["time_ns_native"]

# print(df_txs.info())
# -------------------------
# Column              Dtype
# -------------------------
# tx_hash             object
# block_number        int64
# gas_consumed        int64
# failed              bool
# time_ns_native      int64
# time_ns_vm          int64
# speedup             float64

# merge calls into single dataframe
df_calls: DataFrame = pd.concat([df_calls_native, df_calls_vm])
# drop calls with no time
df_calls = df_calls[df_calls["time_ns"] != 0]  # type: ignore
# merge steps into gas_consumed
df_calls["gas_consumed"] += df_calls["steps"] * 100
df_calls = df_calls.drop("steps", axis=1)
# calculate throughput - note that gigagas/s and gas/ns are equivalent units.
df_calls["throughput"] = df_calls["gas_consumed"] / df_calls["time_ns"]
# derive executor from cairo native flag
df_calls["executor"] = df_calls["cairo_native"].replace({True: "native", False: "vm"})
df_calls = df_calls.drop("cairo_native", axis=1)

# print(df_calls.info())
# -------------------
# Column        Dtype
# -------------------
# tx_hash       object
# class_hash    object
# selector      object
# time_ns       int64
# gas_consumed  int64
# executor      object
# throughput    float64

############
# PLOTTING #
############


def plot_tx_speedup(df_txs: DataFrame):
    _, ax = plt.subplots()

    sns.boxplot(ax=ax, data=df_txs, x="speedup", showfliers=False, width=0.5)
    ax.set_xlabel("Tx Speedup Ratio")
    ax.set_title("Tx Speedup Distribution")

    total_speedup = df_txs["time_ns_vm"].sum() / df_txs["time_ns_native"].sum()
    mean_speedup = df_txs["speedup"].mean()
    median_speedup = df_txs["speedup"].quantile(0.5)
    stddev_speedup = df_txs["speedup"].std()

    ax.text(
        0.01,
        0.99,
        "\n".join(
            [
                f"Total Execution Speedup: {total_speedup:.2f}",
                f"Mean: {mean_speedup:.2f}",
                f"Median: {median_speedup:.2f}",
                f"Std Dev: {stddev_speedup:.2f}",
            ]
        ),
        transform=ax.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="left",
    )

    save_figure(
        "Tx Speedup Distribution",
        "Calculates the distribution of speedup by transactions. The total execution speedup is calculated as the total Cairo VM time, divided by the total Cairo Native time.",
    )


def plot_time_by_class(df_calls: DataFrame):
    df: DataFrame = (
        df_calls.groupby(["executor", "class_hash"])
        .aggregate(
            mean_time=("time_ns", "mean"),
            total_time=("time_ns", "sum"),
        )
        .unstack("executor")
    )  # type: ignore

    # flatten multi index
    df.columns = df.columns.map("_".join)

    # drop rows for which we don't have any Native samples
    df = df.dropna(axis=0, subset=[("mean_time_native"), ("mean_time_vm")])

    # sort so that the legend doesn't cover the bars
    df = df.nlargest(columns="total_time_vm", n=40)
    df.sort_values(["mean_time_vm"], ascending=[False], inplace=True)

    df["speedup"] = df["mean_time_vm"] / df["mean_time_native"]

    _, (ax1, ax2) = plt.subplots(1, 2)
    sns.barplot(
        ax=ax1,
        y="class_hash",
        x="mean_time_vm",
        data=df,
        formatter=format_hash,
        label="VM Execution Time",
        color="r",
    )
    sns.barplot(
        ax=ax1,
        y="class_hash",
        x="mean_time_native",
        data=df,
        formatter=format_hash,
        label="Native Execution Time",
        color="b",
    )
    ax1.set_xscale("log", base=2)
    ax1.set_xlabel("Mean Time (ns)")
    ax1.set_ylabel("Class Hash")
    ax1.set_title("Mean time by Contract Class")

    sns.barplot(
        ax=ax2,
        y="class_hash",
        x="speedup",
        data=df,
        formatter=format_hash,
        label="Speedup",
        color="b",
    )
    ax2.set_title("Speedup by Contract Class")
    ax2.set_ylabel("")
    ax2.set_xscale("log", base=2)
    ax2.set_xlabel("Speedup Ratio")

    save_figure(
        "Execution Time by Contract Class",
        "Compares execution time of most common contract classes.",
    )
    save_csv(df, "Execution Time By Contract Class")


def plot_time_by_gas(df_calls: DataFrame):
    _, ax = plt.subplots()

    df_native = df_calls.loc[df_calls["executor"] == "native"]
    df_vm = df_calls.loc[df_calls["executor"] == "vm"]

    native_gas_consumed = df_native["gas_consumed"]
    native_time_ns = df_native["time_ns"]
    vm_gas_consumed = df_vm["gas_consumed"]
    vm_time_ns = df_vm["time_ns"]

    # The range is to wide, so we apply log to see the full range.
    native_gas_consumed = np.log10(native_gas_consumed)
    native_time_ns = np.log10(native_time_ns)
    vm_gas_consumed = np.log10(vm_gas_consumed)
    vm_time_ns = np.log10(vm_time_ns)

    sns.histplot(
        ax=ax,
        x=native_gas_consumed,
        y=native_time_ns,
        color="b",
        binwidth=1 / 8,
    )
    sns.regplot(
        ax=ax,
        x=native_gas_consumed,
        y=native_time_ns,
        scatter=False,
        color="b",
        label="Native",
    )
    sns.histplot(
        ax=ax,
        x=vm_gas_consumed,
        y=vm_time_ns,
        color="r",
        binwidth=1 / 8,
    )
    sns.regplot(
        ax=ax,
        x=vm_gas_consumed,
        y=vm_time_ns,
        scatter=False,
        color="r",
        label="VM",
    )

    ax.legend()

    # Format the axis to show the normal values, not the log ones.
    def unlog10(x, _):
        return f"{10**x:.0e}"

    ax.set_xlabel("Gas Consumed")
    ax.set_ylabel("Execution Time (ns)")
    ax.get_xaxis().set_major_formatter(unlog10)
    ax.get_yaxis().set_major_formatter(unlog10)

    ax.set_title("Execution Time by Gas Usage")

    save_figure(
        "Execution Time by Gas Usage",
        "Compares call execution time with gas usage. The scale is in log-log.",
    )


def plot_call_throughput(df_calls):
    fig, (ax1, ax2) = plt.subplots(1, 2)

    df_native = df_calls.loc[df_calls["executor"] == "native"]
    df_vm = df_calls.loc[df_calls["executor"] == "vm"]

    sns.boxplot(ax=ax1, data=df_native, x="throughput", showfliers=False, width=0.5)
    ax1.set_title("Native Throughput (gigagas/s)")
    ax1.set_xlabel("Throughput (gigagas/s)")

    sns.boxplot(ax=ax2, data=df_vm, x="throughput", showfliers=False, width=0.5)
    ax2.set_title("VM Throughput (gigagas/s)")
    ax2.set_xlabel("Throughput (gigagas/s)")

    native_total_throughput = (
        df_native["gas_consumed"].sum() / df_native["time_ns"].sum()
    )
    native_mean_throughput = df_native["throughput"].mean()
    native_median_throughput = df_native["throughput"].quantile(0.5)
    native_stddev_throughput = df_native["throughput"].std()

    vm_total_throughput = df_vm["gas_consumed"].sum() / df_vm["time_ns"].sum()
    vm_mean_throughput = df_vm["throughput"].mean()
    vm_median_throughput = df_vm["throughput"].quantile(0.5)
    vm_stddev_throughput = df_vm["throughput"].std()

    ax1.text(
        0.01,
        0.99,
        "\n".join(
            [
                f"Total Execution Throughput: {native_total_throughput:.2f}",
                f"Mean: {native_mean_throughput:.2f}",
                f"Median: {native_median_throughput:.2f}",
                f"Std Dev: {native_stddev_throughput:.2f}",
            ]
        ),
        transform=ax1.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="left",
    )
    ax2.text(
        0.01,
        0.99,
        "\n".join(
            [
                f"Total Execution Throughput: {vm_total_throughput:.2f}",
                f"Mean: {vm_mean_throughput:.2f}",
                f"Median: {vm_median_throughput:.2f}",
                f"Std Dev: {vm_stddev_throughput:.2f}",
            ]
        ),
        transform=ax2.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="left",
    )

    fig.suptitle("Call Throughput Distribution")

    save_figure(
        "Call Throughput Distribution",
        "Calculates the distribution of Native and VM throughput by contract calls.",
    )


def plot_block_speedup(df_txs: DataFrame):
    fig, ax = plt.subplots()

    df_blocks: DataFrame = df_txs.groupby("block_number").aggregate(
        **{
            "time_ns_native": ("time_ns_native", "sum"),
            "time_ns_vm": ("time_ns_vm", "sum"),
            "gas_consumed": ("gas_consumed", "sum"),
        }
    )  # type: ignore
    df_blocks["speedup"] = df_blocks["time_ns_vm"] / df_blocks["time_ns_native"]

    sns.boxplot(ax=ax, data=df_blocks, x="speedup", showfliers=False, width=0.5)
    ax.set_xlabel("Blocks Speedup Ratio")
    ax.set_title("Block Speedup Distribution")

    total_speedup = df_blocks["time_ns_vm"].sum() / df_blocks["time_ns_native"].sum()
    mean_speedup = df_blocks["speedup"].mean()
    median_speedup = df_blocks["speedup"].quantile(0.5)
    stddev_speedup = df_blocks["speedup"].std()
    ax.text(
        0.01,
        0.99,
        "\n".join(
            [
                f"Total Execution Speedup: {total_speedup:.2f}",
                f"Mean: {mean_speedup:.2f}",
                f"Median: {median_speedup:.2f}",
                f"Std Dev: {stddev_speedup:.2f}",
            ]
        ),
        transform=ax.transAxes,
        fontsize=12,
        verticalalignment="top",
        horizontalalignment="left",
    )

    save_csv(df_blocks, "Blocks")
    save_figure(
        "Block Speedup Distribution",
        "Calculates the distribution of speedup by blocks. The total execution speedup is calculated as the total Cairo VM time, divided by the total Cairo Native time.",
    )


plot_call_throughput(df_calls)
plot_time_by_gas(df_calls)
plot_time_by_class(df_calls)
plot_tx_speedup(df_txs)
plot_block_speedup(df_txs)

if args.output_dir:
    doc, tag, text = Doc().tagtext()

    def generate_info(doc, info):
        with tag("ul"):
            for k, v in info.items():
                with tag("li"):
                    doc.line("b", str(k))
                    text(": ", v)

    def generate_body(doc):
        doc, tag, text = doc.tagtext()

        doc.line("h1", "Execution Benchmark Report")

        doc.line("h2", "Cairo Native Execution Info")
        generate_info(doc, native_info)

        doc.line("h2", "Cairo VM Execution Info")
        generate_info(doc, vm_info)

        if native_info["Block Start"] == "":
            doc.line("h2", "Transactions")
            with tag("ul"):
                for tx in df_txs["tx_hash"].unique():
                    doc.line("li", tx)

        # Force line break after info
        with tag("div", style="page-break-after: always"):
            pass

        doc.line("h2", "Figures")
        OUTPUT_FIGURES.reverse()
        for title, name, description in OUTPUT_FIGURES:
            doc.line("h3", title)
            text(description)
            doc.stag("img", src=name)

    with tag("html"):
        with tag("head"):
            # Add minimal styling
            with tag("style"):
                doc.asis("""
                   body {
                        margin: 40px auto;
                        max-width: 21cm;
                        line-height: 1.6;
                        font-family: sans-serif;
                        padding: 0 10px;
                    }
                    img {
                        max-width: 100%;
                        height: auto;
                    }
                """)

        with tag("body"):
            generate_body(doc)

    args.output_dir.joinpath("report.html").write_text(doc.getvalue())

if args.display:
    plt.show()
