// Copyright 2023 StarkWare Industries Ltd.
//
// Licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.starkware.co/open-source-license/
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions
// and limitations under the License.

#include <map>
#include <utility>

#include "starkware/math/math.h"
#include "starkware/utils/task_manager.h"

namespace starkware {

template <typename FieldElementT>
std::unique_ptr<CompositionPolynomial> FibonacciAir<FieldElementT, 0>::CreateCompositionPolynomial(
    const FieldElement& trace_generator, const ConstFieldElementSpan& random_coefficients) const {
  Builder builder(kNumPeriodicColumns);
  const FieldElementT& gen = trace_generator.As<FieldElementT>();

  const std::vector<uint64_t> point_exponents = {uint64_t(trace_length_)};
  const std::vector<uint64_t> gen_exponents = {
      uint64_t((trace_length_) - (1)), uint64_t(fibonacci_claim_index_)};

  return builder.BuildUniquePtr(
      UseOwned(this), gen, trace_length_, random_coefficients.As<FieldElementT>(), point_exponents,
      BatchPow(gen, gen_exponents));
}

template <typename FieldElementT>
std::vector<std::vector<FieldElementT>>
FibonacciAir<FieldElementT, 0>::PrecomputeDomainEvalsOnCoset(
    const FieldElementT& point, const FieldElementT& generator,
    gsl::span<const uint64_t> point_exponents,
    gsl::span<const FieldElementT> shifts) const {
  const std::vector<FieldElementT> strict_point_powers = BatchPow(point, point_exponents);
  const std::vector<FieldElementT> gen_powers = BatchPow(generator, point_exponents);

  // point_powers[i][j] is the evaluation of the ith power at its jth point.
  // The index j runs until the order of the domain (beyond we'd cycle back to point_powers[i][0]).
  std::vector<std::vector<FieldElementT>> point_powers(point_exponents.size());
  for (size_t i = 0; i < point_exponents.size(); ++i) {
    uint64_t size = point_exponents[i] == 0 ? 0 : SafeDiv(trace_length_, point_exponents[i]);
    auto& vec = point_powers[i];
    auto power = strict_point_powers[i];
    vec.reserve(size);
    if (size > 0) {
      vec.push_back(power);
    }
    for (size_t j = 1; j < size; ++j) {
      power *= gen_powers[i];
      vec.push_back(power);
    }
  }

  TaskManager& task_manager = TaskManager::GetInstance();
  constexpr size_t kPeriodUpperBound = 4194305;
  constexpr size_t kTaskSize = 1024;
  size_t period;

  std::vector<std::vector<FieldElementT>> precomp_domains = {
      FieldElementT::UninitializedVector(1),
  };

  period = 1;
  ASSERT_RELEASE(period < kPeriodUpperBound, "Precomp evals: large dynamic size.");
  task_manager.ParallelFor(
      period,
      [&](const TaskInfo& task_info) {
        for (size_t i = task_info.start_idx; i < task_info.end_idx; ++i) {
          precomp_domains[0][i] = (point_powers[0][i & (0)]) - (FieldElementT::One());
        }
      },
      period, kTaskSize);
  return precomp_domains;
}

template <typename FieldElementT>
FractionFieldElement<FieldElementT> FibonacciAir<FieldElementT, 0>::ConstraintsEval(
    gsl::span<const FieldElementT> neighbors, gsl::span<const FieldElementT> periodic_columns,
    gsl::span<const FieldElementT> random_coefficients, const FieldElementT& point,
    gsl::span<const FieldElementT> shifts, gsl::span<const FieldElementT> precomp_domains) const {
  ASSERT_VERIFIER(shifts.size() == 2, "shifts should contain 2 elements.");

  // domain0 = point^trace_length - 1.
  const FieldElementT& domain0 = precomp_domains[0];
  // domain1 = point - gen^(trace_length - 1).
  const FieldElementT& domain1 = (point) - (shifts[0]);
  // domain2 = point - 1.
  const FieldElementT& domain2 = (point) - (FieldElementT::One());
  // domain3 = point - gen^fibonacci_claim_index.
  const FieldElementT& domain3 = (point) - (shifts[1]);

  ASSERT_VERIFIER(neighbors.size() == 4, "neighbors should contain 4 elements.");

  const FieldElementT& x_row0 = neighbors[kXRow0Neighbor];
  const FieldElementT& x_row1 = neighbors[kXRow1Neighbor];
  const FieldElementT& y_row0 = neighbors[kYRow0Neighbor];
  const FieldElementT& y_row1 = neighbors[kYRow1Neighbor];

  ASSERT_VERIFIER(periodic_columns.empty(), "periodic_columns should be empty.");

  FractionFieldElement<FieldElementT> res(FieldElementT::Zero());
  {
    // Compute a sum of constraints with denominator = domain0.
    FieldElementT outer_sum = FieldElementT::Zero();

    {
      // Compute a sum of constraints with numerator = domain1.
      FieldElementT inner_sum = FieldElementT::Zero();
      {
        // Constraint expression for state_copy:
        const FieldElementT constraint = (x_row1) - (y_row0);
        inner_sum += random_coefficients[0] * constraint;
      }
      {
        // Constraint expression for step:
        const FieldElementT constraint = (y_row1) - ((y_row0) + (x_row0));
        inner_sum += random_coefficients[1] * constraint;
      }
      outer_sum += inner_sum * domain1;
    }
    res += FractionFieldElement<FieldElementT>(outer_sum, domain0);
  }

  {
    // Compute a sum of constraints with denominator = domain2.
    FieldElementT outer_sum = FieldElementT::Zero();

    {
      // Compute a sum of constraints with numerator = FieldElementT::One().
      FieldElementT inner_sum = FieldElementT::Zero();
      {
        // Constraint expression for init_x:
        const FieldElementT constraint = (x_row0) - (FieldElementT::One());
        inner_sum += random_coefficients[2] * constraint;
      }
      outer_sum += inner_sum;  // domain == FieldElementT::One()
    }
    res += FractionFieldElement<FieldElementT>(outer_sum, domain2);
  }

  {
    // Compute a sum of constraints with denominator = domain3.
    FieldElementT outer_sum = FieldElementT::Zero();

    {
      // Compute a sum of constraints with numerator = FieldElementT::One().
      FieldElementT inner_sum = FieldElementT::Zero();
      {
        // Constraint expression for verify_res:
        const FieldElementT constraint = (x_row0) - (claimed_fib_);
        inner_sum += random_coefficients[3] * constraint;
      }
      outer_sum += inner_sum;  // domain == FieldElementT::One()
    }
    res += FractionFieldElement<FieldElementT>(outer_sum, domain3);
  }
  return res;
}

template <typename FieldElementT>
std::vector<FieldElementT> FibonacciAir<FieldElementT, 0>::DomainEvalsAtPoint(
    gsl::span<const FieldElementT> point_powers,
    gsl::span<const FieldElementT> shifts) const {
  const FieldElementT& point = point_powers[0];
  const FieldElementT& domain0 = (point_powers[1]) - (FieldElementT::One());
  return {
      domain0,
  };
}

template <typename FieldElementT>
std::vector<uint64_t> FibonacciAir<FieldElementT, 0>::ParseDynamicParams(
    const std::map<std::string, uint64_t>& params) const {
  std::vector<uint64_t> result;

  ASSERT_RELEASE(params.size() == kNumDynamicParams, "Inconsistent dynamic data.");
  result.reserve(kNumDynamicParams);
  return result;
}

template <typename FieldElementT>
TraceGenerationContext FibonacciAir<FieldElementT, 0>::GetTraceGenerationContext() const {
  TraceGenerationContext ctx;

  ASSERT_RELEASE(IsPowerOfTwo(trace_length_), "Dimension should be a power of 2.");

  ASSERT_RELEASE(((trace_length_) - (1)) >= (0), "Offset must be smaller than trace length.");

  ASSERT_RELEASE((trace_length_) >= (0), "Index should be non negative.");

  return ctx;
}

template <typename FieldElementT>
std::vector<std::pair<int64_t, uint64_t>> FibonacciAir<FieldElementT, 0>::GetMask() const {
  std::vector<std::pair<int64_t, uint64_t>> mask;

  mask.reserve(4);
  mask.emplace_back(0, kXColumn);
  mask.emplace_back(1, kXColumn);
  mask.emplace_back(0, kYColumn);
  mask.emplace_back(1, kYColumn);

  return mask;
}

}  // namespace starkware
