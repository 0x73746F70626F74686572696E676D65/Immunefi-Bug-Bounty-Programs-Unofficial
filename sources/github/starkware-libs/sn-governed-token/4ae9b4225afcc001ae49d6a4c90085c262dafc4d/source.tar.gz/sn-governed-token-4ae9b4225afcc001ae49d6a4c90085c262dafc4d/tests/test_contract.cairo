use openzeppelin::token::erc20::interface::{IERC20Dispatcher, IERC20DispatcherTrait};
use sn_governed_token::token;
use snforge_std::{
    ContractClassTrait, DeclareResultTrait, EventSpyAssertionsTrait, declare, spy_events,
};
use starknet::ContractAddress;
use starkware_utils::components::blocklist::interface::{
    IBlocklistDispatcher, IBlocklistDispatcherTrait,
};
use starkware_utils::components::pausable::interface::{
    IPausableDispatcher, IPausableDispatcherTrait,
};
use starkware_utils::interfaces::mintable_token::{
    IMintableTokenDispatcher, IMintableTokenDispatcherTrait,
};
use starkware_utils_testing::constants as testing_constants;
use starkware_utils_testing::constants::{GOVERNANCE_ADMIN, SECURITY_ADMIN, TOKEN_ADMIN};
use starkware_utils_testing::test_utils::{cheat_caller_address_once, set_default_roles};

const USER: ContractAddress = 'USER'.try_into().unwrap();

const UPGRADE_DELAY: u64 = 0;
const DECIMALS: u8 = 18;

fn deploy_token_contract() -> ContractAddress {
    let contract = *declare("token").unwrap().contract_class();
    let mut calldata = ArrayTrait::new();
    GOVERNANCE_ADMIN.serialize(ref calldata);
    UPGRADE_DELAY.serialize(ref calldata);
    let name: ByteArray = "STRK";
    let symbol: ByteArray = "STRK";
    name.serialize(ref calldata);
    symbol.serialize(ref calldata);
    DECIMALS.serialize(ref calldata);
    let (contract_address, _) = contract.deploy(@calldata).unwrap();
    set_default_roles(contract: contract_address, governance_admin: GOVERNANCE_ADMIN);
    contract_address
}


#[test]
fn test_mint() {
    let contract_address = deploy_token_contract();
    let erc20 = IERC20Dispatcher { contract_address };
    let mintable = IMintableTokenDispatcher { contract_address };
    let balance = erc20.balance_of(testing_constants::TOKEN_ADMIN);
    assert_eq!(0, balance);
    let total_supply = erc20.total_supply();
    assert_eq!(0, total_supply);
    cheat_caller_address_once(contract_address, testing_constants::TOKEN_ADMIN);
    mintable.permissioned_mint(testing_constants::DUMMY_ADDRESS, 1000);
    let balance = erc20.balance_of(testing_constants::DUMMY_ADDRESS);
    assert_eq!(1000, balance);
    let total_supply = erc20.total_supply();
    assert_eq!(1000, total_supply);
}

#[test]
fn test_burn() {
    let contract_address = deploy_token_contract();
    let erc20 = IERC20Dispatcher { contract_address };
    let mintable = IMintableTokenDispatcher { contract_address };
    cheat_caller_address_once(contract_address, testing_constants::TOKEN_ADMIN);
    mintable.permissioned_mint(testing_constants::DUMMY_ADDRESS, 1000);
    let balance = erc20.balance_of(testing_constants::DUMMY_ADDRESS);
    assert_eq!(1000, balance);
    let total_supply = erc20.total_supply();
    assert_eq!(1000, total_supply);
    cheat_caller_address_once(contract_address, testing_constants::TOKEN_ADMIN);
    mintable.permissioned_burn(testing_constants::DUMMY_ADDRESS, 1000);
    let balance = erc20.balance_of(testing_constants::DUMMY_ADDRESS);
    assert_eq!(0, balance);
    let total_supply = erc20.total_supply();
    assert_eq!(0, total_supply);
}

#[test]
#[should_panic(expected: "ONLY_TOKEN_ADMIN")]
fn test_burn_caller_not_token_admin() {
    let contract_address = deploy_token_contract();
    let mintable = IMintableTokenDispatcher { contract_address };
    mintable.permissioned_burn(testing_constants::DUMMY_ADDRESS, 1000);
}

#[test]
#[should_panic(expected: 'PAUSED')]
fn test_paused() {
    let contract_address = deploy_token_contract();
    let mintable = IMintableTokenDispatcher { contract_address };
    let pausable = IPausableDispatcher { contract_address };
    cheat_caller_address_once(contract_address, testing_constants::SECURITY_AGENT);
    pausable.pause();
    cheat_caller_address_once(contract_address, testing_constants::TOKEN_ADMIN);
    mintable.permissioned_mint(testing_constants::DUMMY_ADDRESS, 1000);
}

#[test]
#[should_panic(expected: "ONLY_TOKEN_ADMIN")]
fn test_invalid_minter() {
    let contract_address = deploy_token_contract();
    let mintable = IMintableTokenDispatcher { contract_address };
    mintable.permissioned_mint(testing_constants::DUMMY_ADDRESS, 1000);
}

#[test]
fn test_add_to_blocklist_by_security_admin() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    let mut spy = spy_events();
    blocklist.add_to_blocklist(USER);
    assert!(blocklist.is_blocklisted(USER), "User should be blocklisted");
    spy
        .assert_emitted(
            @array![
                (
                    blocklist.contract_address,
                    token::Event::BlocklistEvent(
                        starkware_utils::components::blocklist::blocklist::blocklist::Event::Blocklisted(
                            starkware_utils::components::blocklist::events::Blocklisted {
                                account: USER, caller: SECURITY_ADMIN,
                            },
                        ),
                    ),
                ),
            ],
        );
}

#[test]
fn test_remove_from_blocklist_by_security_admin() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.add_to_blocklist(USER);
    assert!(blocklist.is_blocklisted(USER), "User should be blocklisted");
    let mut spy = spy_events();
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.remove_from_blocklist(USER);
    assert!(!blocklist.is_blocklisted(USER), "User should not be blocklisted");
    spy
        .assert_emitted(
            @array![
                (
                    blocklist.contract_address,
                    token::Event::BlocklistEvent(
                        starkware_utils::components::blocklist::blocklist::blocklist::Event::Unblocklisted(
                            starkware_utils::components::blocklist::events::Unblocklisted {
                                account: USER, caller: SECURITY_ADMIN,
                            },
                        ),
                    ),
                ),
            ],
        );
}

#[test]
fn test_is_blocklisted() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.add_to_blocklist(USER);
    assert!(blocklist.is_blocklisted(USER), "User should be blocklisted");
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.remove_from_blocklist(USER);
    assert!(!blocklist.is_blocklisted(USER), "User should not be blocklisted");
}

#[test]
#[should_panic(expected: "ONLY_SECURITY_ADMIN")]
fn test_add_to_blocklist_wrong_role_panics() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, USER);
    blocklist.add_to_blocklist(USER);
}

#[test]
#[should_panic(expected: "ONLY_SECURITY_ADMIN")]
fn test_remove_from_blocklist_wrong_role_panics() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.add_to_blocklist(USER);
    cheat_caller_address_once(contract_address, USER);
    blocklist.remove_from_blocklist(USER);
}


#[test]
#[should_panic(expected: "BLOCKLISTED: 1431520594")]
fn test_token_mint_to_blocked_account_panics() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.add_to_blocklist(USER);
    assert!(blocklist.is_blocklisted(USER), "User should be blocklisted");
    cheat_caller_address_once(contract_address, TOKEN_ADMIN);
    let mintable_token = IMintableTokenDispatcher { contract_address };
    mintable_token.permissioned_mint(USER, 100);
}

#[test]
#[should_panic(expected: "BLOCKLISTED: 1431520594")]
fn test_token_transfer_from_blocked_account_panics() {
    let contract_address = deploy_token_contract();
    let blocklist = IBlocklistDispatcher { contract_address };
    cheat_caller_address_once(contract_address, SECURITY_ADMIN);
    blocklist.add_to_blocklist(USER);
    assert!(blocklist.is_blocklisted(USER), "User should be blocklisted");
    let token = IERC20Dispatcher { contract_address };
    cheat_caller_address_once(contract_address, USER);
    token.transfer(USER, 100);
}
