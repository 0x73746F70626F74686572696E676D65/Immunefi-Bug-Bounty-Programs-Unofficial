<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/starknet-dark.png">
  <source media="(prefers-color-scheme: light)" srcset="assets/starknet-light.png">
  <img alt="Your logo" src="assets/starknet-light.png">
</picture>
</div>

<div align="center">

[![License: Apache2.0](https://img.shields.io/badge/License-Apache2.0-green.svg)](LICENSE)

</div>

# Starknet Governed Token

## Content

- [Overview](#overview)
- [Dependencies](#dependencies)
- [Installation](#installation)
- [Getting help](#getting-help)
- [Build and Test](#build-and-test)
- [Security](#security)

## Overview

This repo contains a simple governed-token implementation on Starknet.
It includes the following features:

1. An ERC20 token implementation.
2. Upgradable.
3. Minting and burning of the governed-token using a `token_admin` account role.
4. Blocklist - a list of addresses that are not allowed to get any updates of the token.
5. Pause/Unpause functionality.

## Dependencies

- Cairo dependencies such as [Scarb](https://docs.swmansion.com/scarb/) and [Starknet foundry](https://foundry-rs.github.io/starknet-foundry/index.html) - install using [starkup](https://github.com/software-mansion/starkup).

## Installation

Clone the repo and from within the projects root folder run:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.starkup.dev | sh
```

## Getting help

Reach out to the maintainer at any of the following:

- [GitHub Discussions](https://github.com/starkware-libs/sn-governed-token/discussions)
- Contact options listed on this [GitHub profile](https://github.com/starkware-libs)

## Build and Test

Build the contracts from the repo root:

```bash
scarb build
```

To run the tests, execute:

```bash
scarb test
```

## Security

Starknet Governed Token follows good practices of security, but 100% security cannot be assured. Starknet Governed Token is provided "as is" without any warranty. Use at your own risk.

For more information and to report security issues, please refer to our [security documentation](https://github.com/starkware-libs/sn-governed-token/blob/main/docs/SECURITY.md).
