use std::iter;

use criterion::{BatchSize, Criterion, black_box, criterion_group, criterion_main};
use rand::rngs::SmallRng;
use rand::{Rng, SeedableRng};
use stwo::core::fields::m31::BaseField;
use stwo::core::poly::circle::CanonicCoset;
use stwo::core::vcs_lifted::blake2_merkle::Blake2sMerkleChannel;
use stwo::prover::CommitmentTreeProver;
use stwo::prover::backend::simd::SimdBackend;
use stwo::prover::backend::{BackendForChannel, CpuBackend};
use stwo::prover::mempool::BaseColumnPool;
use stwo::prover::poly::BitReversedOrder;
use stwo::prover::poly::circle::CircleEvaluation;
use stwo::prover::poly::twiddles::TwiddleTree;

const LOG_COSET_SIZE: u32 = 20;
const LOG_BLOWUP_FACTOR: u32 = 1;
const N_POLYS: usize = 16;

fn benched_fn<B: BackendForChannel<Blake2sMerkleChannel>>(
    evals: Vec<CircleEvaluation<B, BaseField, BitReversedOrder>>,
    twiddles: &TwiddleTree<B>,
) {
    let polys = evals.into_iter().map(|eval| eval.interpolate_with_twiddles(twiddles)).collect();

    CommitmentTreeProver::<B, Blake2sMerkleChannel>::new(
        polys,
        LOG_BLOWUP_FACTOR,
        twiddles,
        false,
        0,
        &BaseColumnPool::new(),
    );
}

fn bench_pcs<B: BackendForChannel<Blake2sMerkleChannel>>(c: &mut Criterion, id: &str) {
    let small_domain = CanonicCoset::new(LOG_COSET_SIZE);
    let big_domain = CanonicCoset::new(LOG_COSET_SIZE + LOG_BLOWUP_FACTOR);
    let twiddles = B::precompute_twiddles(big_domain.half_coset());
    let mut rng = SmallRng::seed_from_u64(0);

    let evals: Vec<CircleEvaluation<B, BaseField, BitReversedOrder>> = iter::repeat_with(|| {
        CircleEvaluation::new(
            small_domain.circle_domain(),
            (0..1 << LOG_COSET_SIZE).map(|_| rng.random()).collect(),
        )
    })
    .take(N_POLYS)
    .collect();

    c.bench_function(&format!("{id} polynomial commitment 2^{LOG_COSET_SIZE}"), |b| {
        b.iter_batched(
            || evals.clone(),
            |evals| benched_fn::<B>(black_box(evals), black_box(&twiddles)),
            BatchSize::LargeInput,
        );
    });
}

fn pcs_benches(c: &mut Criterion) {
    bench_pcs::<SimdBackend>(c, "simd");
    bench_pcs::<CpuBackend>(c, "cpu");
}

criterion_group!(
    name = benches;
    config = Criterion::default().sample_size(10);
    targets = pcs_benches);
criterion_main!(benches);
