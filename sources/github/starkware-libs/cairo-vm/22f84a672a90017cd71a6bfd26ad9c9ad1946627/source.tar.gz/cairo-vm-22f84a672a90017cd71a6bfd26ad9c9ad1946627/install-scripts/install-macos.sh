#!/usr/bin/env bash
set -ex

# Install Rust and Cargo
curl https://sh.rustup.rs -sSf | sh -s -- -y
source "$HOME/.cargo/env"

# Make sure Rust has been installed correctly
rustc --version

# Install pyenv
brew install pyenv

# install gmp
brew install --force gmp
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Make sure uv has been installed correctly
uv --version

make deps-macos
