//! Computes per-component sizes for the CANONICAL preprocessed trace config, across a range of
//! verified trace sizes, and writes them as text. For each trace size it reports two circuits:
//! the leaf-prover verifier circuit (which verifies one Cairo proof), and the multiverifier circuit
//! (which verifies two proofs of that leaf verifier circuit).

use std::path::PathBuf;
use std::process::ExitCode;
use std::sync::Arc;

use cairo_air::verifier::INTERACTION_POW_BITS;
use circuit_cairo_verifier::privacy::get_pcs_config;
use circuit_cairo_verifier::statement::MEMORY_VALUES_LIMBS;
use circuit_cairo_verifier::verify::{CairoVerifierConfig, build_cairo_verifier_circuit};
use circuit_common::N_RESERVED;
use circuit_common::finalize::{ComponentSizes, compute_padded_sizes, qm31_ops_n_rows};
use circuit_common::preprocessed::PreprocessedCircuit;
use circuit_multiverifier::verify::{
    MultiverifierInput, SharedConfig, build_multiverifier_circuit,
};
use circuit_verifier::statement::{
    INTERACTION_POW_BITS as CIRCUIT_INTERACTION_POW_BITS, all_circuit_components,
    circuit_component_log_sizes,
};
use circuits::blake::HashValue;
use circuits::context::FinalizedContext;
use circuits::ivalue::NoValue;
use circuits_stark_verifier::proof::{ProofConfig, empty_proof};
use clap::Parser;
use leaf_prover::consts::DISABLED_COMPONENTS_CANONICAL_PREPROCESSED;
use leaf_prover::prove_leaf::{LeafVerifierComponents, leaf_verifier_components};
use stwo_cairo_common::preprocessed_columns::preprocessed_trace::PreProcessedTraceVariant;
use stwo_cairo_common::prover_types::cpu::M31;
use stwo_cairo_prover::stwo::core::pcs::PcsConfig;
use stwo_cairo_utils::binary_utils::run_binary;

#[derive(Parser)]
struct Args {
    /// Path to write the output to. If omitted, prints to stdout.
    #[clap(long)]
    output_path: Option<PathBuf>,
    /// Smallest verified trace log size to measure (inclusive). A canonical Cairo trace commits
    /// its preprocessed sequence columns at `MAX_SEQUENCE_LOG_SIZE = 25`, so a real canonical
    /// leaf proof has `log_trace_size >= 25`.
    #[clap(long)]
    min_trace_log_size: u32,
    /// Largest verified trace log size to measure (inclusive).
    #[clap(long)]
    max_trace_log_size: u32,
    /// Log blowup factor of the verified Cairo proof (1, 2, or 3), passed to `get_pcs_config`.
    #[clap(long = "log_blowup_factor", default_value_t = 1)]
    log_blowup_factor: u32,
}

/// The fraction (as a percentage) of the padded (power-of-two) component that is actually used.
fn usage_percent(size: usize, padded_size: usize) -> f64 {
    100.0 * size as f64 / padded_size as f64
}

/// The raw (non-padded) row count of each AIR component.
struct RawSizes {
    eq: usize,
    qm31_ops: usize,
    m31_to_u32: usize,
    triple_xor: usize,
    blake_g_gate: usize,
}

/// One line with each component's padded log size and usage (fraction of the padded power-of-two
/// that the non-padded rows fill).
fn format_sizes(raw: &RawSizes, padded: &ComponentSizes) -> String {
    let component = |name: &str, raw_size: usize, padded_size: usize| {
        format!(
            "{name}:(log: {}, usage = {:.0}%)",
            padded_size.ilog2(),
            usage_percent(raw_size, padded_size),
        )
    };
    format!(
        "{} {} {} {} {}",
        component("eq", raw.eq, padded.eq),
        component("qm31_ops", raw.qm31_ops, padded.qm31_ops),
        component("m31_to_u32", raw.m31_to_u32, padded.m31_to_u32),
        component("triple_xor", raw.triple_xor, padded.triple_xor),
        component("blake_g_gate", raw.blake_g_gate, padded.blake_g_gate),
    )
}

/// Builds the leaf-prover verifier circuit topology (with the CANONICAL preprocessed trace and its
/// component set) for a verified Cairo proof whose trace has the given log size. The result is a
/// `NoValue` context (topology only; no witness values).
fn build_leaf_verifier_context(
    trace_log_size: u32,
    log_blowup_factor: u32,
) -> FinalizedContext<NoValue> {
    let preprocessed_trace_variant = PreProcessedTraceVariant::Canonical;

    // The Cairo-proof PCS config the leaf prover uses (canonical preprocessed).
    let pcs_config = get_pcs_config(trace_log_size, log_blowup_factor);

    let LeafVerifierComponents { components: cairo_components, enabled_bits } =
        leaf_verifier_components(&DISABLED_COMPONENTS_CANONICAL_PREPROCESSED);

    let proof_config = ProofConfig::new(
        &cairo_components,
        preprocessed_trace_variant.n_columns(),
        &pcs_config,
        INTERACTION_POW_BITS,
    );

    // TODO(ilya): Use a real program for the circuit construction.
    // Pass a dummy program for the circuit construction.
    let program: Arc<[[M31; MEMORY_VALUES_LIMBS]]> =
        std::iter::repeat_n([M31::from(0u32); MEMORY_VALUES_LIMBS], 128).collect();

    let verifier_config = CairoVerifierConfig {
        proof_config,
        enabled_bits,
        program,
        preprocessed_root: [0u32; 8].into(),
        preprocessed_trace_variant,
    };

    build_cairo_verifier_circuit(&verifier_config)
}

/// Builds the multiverifier circuit topology that verifies two proofs of `preprocessed_leaf`.
///
/// Mirrors `circuit_multiverifier`'s test-only `get_preprocessed_multiverifier_from_circuit`:
/// the multiverifier is fed two empty (zero-valued) proofs of the leaf circuit, which is enough to
/// build the `NoValue` topology and measure its component sizes. No target padding is applied so
/// the reported sizes are the raw ones. `pcs_config` must be the leaf proof's config; its
/// `min_lifting_log_size` must equal `preprocessed_leaf.trace_log_size + log_blowup_factor`.
fn build_multiverifier_context(
    preprocessed_leaf: &PreprocessedCircuit,
    pcs_config: PcsConfig,
) -> FinalizedContext<NoValue> {
    let preprocessed_column_log_sizes = preprocessed_leaf.preprocessed_trace.log_sizes();

    // `ProofConfig` expects the components in ascending log-size order.
    let mut components = all_circuit_components::<NoValue>();
    let log_sizes = circuit_component_log_sizes(&components, &preprocessed_column_log_sizes);
    components.sort_by(|a, _, b, _| log_sizes[*a].cmp(&log_sizes[*b]));

    let proof_config = ProofConfig::new(
        &components,
        preprocessed_leaf.preprocessed_trace.n_columns(),
        &pcs_config,
        CIRCUIT_INTERACTION_POW_BITS,
    );
    let shared_config = SharedConfig {
        pcs_config,
        preprocessed_column_log_sizes,
        proof_config: proof_config.clone(),
    };
    let empty_input = || MultiverifierInput {
        proof: empty_proof(&proof_config),
        preprocessed_root: HashValue::from([0u32; 8]),
        output_values: [0u32; N_RESERVED],
    };
    build_multiverifier_circuit::<NoValue>(empty_input(), empty_input(), &shared_config)
}

/// Non-padded row counts and padded sizes of a circuit context's AIR components.
fn component_sizes(context: &FinalizedContext<NoValue>) -> (RawSizes, ComponentSizes) {
    let padded = compute_padded_sizes(context);

    // Non-padded row counts, mirroring `compute_padded_sizes` before its power-of-two rounding.
    let circuit = context.circuit();
    let qm31_ops = qm31_ops_n_rows(circuit);
    let raw = RawSizes {
        eq: circuit.eq.len(),
        qm31_ops,
        m31_to_u32: circuit.m31_to_u32.len(),
        triple_xor: circuit.triple_xor.len(),
        blake_g_gate: circuit.blake_g_gate.len(),
    };

    (raw, padded)
}

/// Builds the leaf verifier circuit for the given verified trace log size and returns its
/// component sizes.
fn leaf_component_sizes(trace_log_size: u32, log_blowup_factor: u32) -> (RawSizes, ComponentSizes) {
    let context = build_leaf_verifier_context(trace_log_size, log_blowup_factor);
    component_sizes(&context)
}

/// Builds the multiverifier circuit that verifies two proofs of the leaf verifier circuit for the
/// given verified trace log size, and returns its component sizes.
fn multiverifier_component_sizes(
    trace_log_size: u32,
    log_blowup_factor: u32,
) -> (RawSizes, ComponentSizes) {
    let mut leaf_context = build_leaf_verifier_context(trace_log_size, log_blowup_factor);

    // The multiverifier verifies proofs of the (preprocessed) leaf circuit, proven at the leaf
    // circuit's own trace log size.
    let preprocessed_leaf = PreprocessedCircuit::preprocess_circuit(&mut leaf_context);
    let multiverifier_pcs_config =
        get_pcs_config(preprocessed_leaf.trace_log_size, log_blowup_factor);
    let multiverifier_context =
        build_multiverifier_context(&preprocessed_leaf, multiverifier_pcs_config);
    component_sizes(&multiverifier_context)
}

fn main() -> ExitCode {
    run_binary(run, "circuit_params")
}

fn run() -> Result<(), String> {
    let args = Args::parse();

    // The leaf verifier circuit's size grows with the verified trace size, so it's reported for
    // every trace log size in the range, under a `leaf:` header. The multiverifier verifies proofs
    // of the leaf circuit; we only report it for the largest leaf (`max_trace_log_size`), which
    // bounds the multiverifier size across the range.
    let leaf_lines: Vec<String> = (args.min_trace_log_size..=args.max_trace_log_size)
        .map(|trace_log_size| {
            let (raw, padded) = leaf_component_sizes(trace_log_size, args.log_blowup_factor);
            format!("{}: {}", trace_log_size, format_sizes(&raw, &padded))
        })
        .collect();
    let leaf_section = format!("leaf:\n{}", leaf_lines.join("\n"));

    // We report a single multiverifier line, as the multiverifier is about the same for all trace
    // log sizes.
    let (mv_raw, mv_padded) =
        multiverifier_component_sizes(args.max_trace_log_size, args.log_blowup_factor);
    let multiverifier_line = format!("multiverifier:\n{}", format_sizes(&mv_raw, &mv_padded,));

    let output = format!("{leaf_section}\n\n{multiverifier_line}");

    match args.output_path {
        Some(path) => std::fs::write(&path, format!("{output}\n"))
            .map_err(|err| format!("Cannot write output to {}: {err}", path.display()))?,
        None => println!("{output}"),
    }
    Ok(())
}
