## [0.1.0](https://github.com/starkware-libs/starkex-js/compare/v0.0.6...v0.1.0) (2022-09-18)


### 🧩 Features

* **2847512314:** Add Stark Error Code ([#16](https://github.com/starkware-libs/starkex-js/issues/16)) ([b276cda](https://github.com/starkware-libs/starkex-js/commit/b276cdae756e01461252472e5b5e7cc348e4e1e1))
* **2847512320:** adjust numeric types ([#20](https://github.com/starkware-libs/starkex-js/issues/20)) ([37550b7](https://github.com/starkware-libs/starkex-js/commit/37550b7d1d1a858e8a3afe93c0ecfe06e8419978))
* **3075511177:** support multi-transaction ([#21](https://github.com/starkware-libs/starkex-js/issues/21)) ([d788a18](https://github.com/starkware-libs/starkex-js/commit/d788a1823c0d2786250c915c1bf9891683a2478b))
* **3127780111:** drop support for availability gateway ([#25](https://github.com/starkware-libs/starkex-js/issues/25)) ([bf8bbcf](https://github.com/starkware-libs/starkex-js/commit/bf8bbcf4da9c2d3f528662c0014c91e31f142fcf))
* **3127791831:** dynamic versioning ([#27](https://github.com/starkware-libs/starkex-js/issues/27)) ([935dd55](https://github.com/starkware-libs/starkex-js/commit/935dd552ffa3a3790d1c107b024d4c8a51c6e337))
* **3200394536:** gateway - add mark_transaction_for_replacement support ([#29](https://github.com/starkware-libs/starkex-js/issues/29)) ([da402e7](https://github.com/starkware-libs/starkex-js/commit/da402e71d3764a5364f807fadb923c71aba67c29))
* **3202221738:** feeder gateway - add v4.5 capabilities ([#26](https://github.com/starkware-libs/starkex-js/issues/26)) ([a6b5975](https://github.com/starkware-libs/starkex-js/commit/a6b59755ffb1d46c82495f6cb05275a4ee8a33dc))


### 📚 Docs

* generate v4.5 canary docs ([#33](https://github.com/starkware-libs/starkex-js/issues/33)) ([b8c2d71](https://github.com/starkware-libs/starkex-js/commit/b8c2d7120779a835c76ae3ff08c7a5b6edca6422))

## [0.1.0-dev.7](https://github.com/starkware-libs/starkex-js/compare/v0.1.0-dev.6...v0.1.0-dev.7) (2022-09-08)


### 🧩 Features

* **3200394536:** gateway - add mark_transaction_for_replacement support ([#29](https://github.com/starkware-libs/starkex-js/issues/29)) ([da402e7](https://github.com/starkware-libs/starkex-js/commit/da402e71d3764a5364f807fadb923c71aba67c29))

## [0.1.0-dev.6](https://github.com/starkware-libs/starkex-js/compare/v0.1.0-dev.5...v0.1.0-dev.6) (2022-09-08)


### 🧩 Features

* **3127791831:** dynamic versioning ([#27](https://github.com/starkware-libs/starkex-js/issues/27)) ([935dd55](https://github.com/starkware-libs/starkex-js/commit/935dd552ffa3a3790d1c107b024d4c8a51c6e337))

## [0.1.0-dev.5](https://github.com/starkware-libs/starkex-js/compare/v0.1.0-dev.4...v0.1.0-dev.5) (2022-09-08)


### 🧩 Features

* **3202221738:** feeder gateway - add v4.5 capabilities ([#26](https://github.com/starkware-libs/starkex-js/issues/26)) ([a6b5975](https://github.com/starkware-libs/starkex-js/commit/a6b59755ffb1d46c82495f6cb05275a4ee8a33dc))

## [0.1.0-dev.4](https://github.com/starkware-libs/starkex-js/compare/v0.1.0-dev.3...v0.1.0-dev.4) (2022-09-08)


### 🧩 Features

* **3127780111:** drop support for availability gateway ([#25](https://github.com/starkware-libs/starkex-js/issues/25)) ([bf8bbcf](https://github.com/starkware-libs/starkex-js/commit/bf8bbcf4da9c2d3f528662c0014c91e31f142fcf))

## [0.1.0-dev.3](https://github.com/starkware-libs/starkex-js/compare/v0.1.0-dev.2...v0.1.0-dev.3) (2022-09-06)


### 🧩 Features

* **3075511177:** support multi-transaction ([#21](https://github.com/starkware-libs/starkex-js/issues/21)) ([d788a18](https://github.com/starkware-libs/starkex-js/commit/d788a1823c0d2786250c915c1bf9891683a2478b))

## [0.1.0-dev.2](https://github.com/starkware-libs/starkex-js/compare/v0.1.0-dev.1...v0.1.0-dev.2) (2022-09-05)


### 🧩 Features

* **2847512320:** adjust numeric types ([#20](https://github.com/starkware-libs/starkex-js/issues/20)) ([37550b7](https://github.com/starkware-libs/starkex-js/commit/37550b7d1d1a858e8a3afe93c0ecfe06e8419978))

## [0.1.0-dev.1](https://github.com/starkware-libs/starkex-js/compare/v0.0.6...v0.1.0-dev.1) (2022-09-05)


### 🧩 Features

* **2847512314:** Add Stark Error Code ([#16](https://github.com/starkware-libs/starkex-js/issues/16)) ([b276cda](https://github.com/starkware-libs/starkex-js/commit/b276cdae756e01461252472e5b5e7cc348e4e1e1))

# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.6](https://github.com/starkware-libs/starkex-js/compare/v0.0.6-0...v0.0.6) (2022-01-31)

### [0.0.5](https://github.com/starkware-libs/starkex-js/compare/v0.0.4...v0.0.5) (2021-12-05)

### [0.0.4](https://github.com/starkware-libs/starkex-js/compare/v0.0.3...v0.0.4) (2021-11-24)

### Bug Fixes

- **gateway:** caller is not aware of the sent txId ([#10](https://github.com/starkware-libs/starkex-js/issues/10)) ([cb9862d](https://github.com/starkware-libs/starkex-js/commit/cb9862d687998deec928b8068bd8d1e69c0a90f4))

### [0.0.3](https://github.com/starkware-libs/starkex-js/compare/v0.0.2...v0.0.3) (2021-10-20)

### [0.0.2](https://github.com/starkware-libs/starkex-js/compare/v0.0.1...v0.0.2) (2021-10-20)

### Bug Fixes

- README.md ([#5](https://github.com/starkware-libs/starkex-js/issues/5)) ([89a0901](https://github.com/starkware-libs/starkex-js/commit/89a0901fd0f9bef8a810413d3b8cc292e5706e48))

### 0.0.1 (2021-10-11)

### Features

- add jenkins support ([#3](https://github.com/starkware-libs/starkex-js/issues/3)) ([8a56bd4](https://github.com/starkware-libs/starkex-js/commit/8a56bd46aa39163fd618c1935fe487cec1c90504))
- starkex sdk ([#2](https://github.com/starkware-libs/starkex-js/issues/2)) ([faaa213](https://github.com/starkware-libs/starkex-js/commit/faaa2138feae74599a344c60bd49df6fef122017))
