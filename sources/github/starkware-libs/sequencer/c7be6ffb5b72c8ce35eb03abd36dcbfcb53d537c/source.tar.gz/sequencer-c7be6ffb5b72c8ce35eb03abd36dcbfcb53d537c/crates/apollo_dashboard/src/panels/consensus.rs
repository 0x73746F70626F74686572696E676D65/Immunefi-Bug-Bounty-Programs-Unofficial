use apollo_batcher::metrics::{
    LABEL_NAME_PRECONFIRMED_BLOCK_WRITE_FAILURE_REASON,
    PRECONFIRMED_BLOCK_WRITE_FAILURE,
    PRECONFIRMED_BLOCK_WRITTEN,
};
use apollo_consensus::metrics::{
    CONSENSUS_BLOCK_NUMBER,
    CONSENSUS_BUILD_PROPOSAL_FAILED,
    CONSENSUS_BUILD_PROPOSAL_TOTAL,
    CONSENSUS_CONFLICTING_VOTES,
    CONSENSUS_DECISIONS_REACHED_AS_PROPOSER,
    CONSENSUS_DECISIONS_REACHED_BY_CONSENSUS,
    CONSENSUS_DECISIONS_REACHED_BY_SYNC,
    CONSENSUS_INBOUND_PEER_EVICTED,
    CONSENSUS_INBOUND_STREAM_BUFFER_FULL,
    CONSENSUS_INBOUND_STREAM_EVICTED,
    CONSENSUS_INBOUND_STREAM_FINISHED,
    CONSENSUS_INBOUND_STREAM_STARTED,
    CONSENSUS_OUTBOUND_STREAM_FINISHED,
    CONSENSUS_OUTBOUND_STREAM_STARTED,
    CONSENSUS_PROPOSALS_ACCEPTED_FOR_VALIDATION,
    CONSENSUS_PROPOSALS_INVALID,
    CONSENSUS_PROPOSALS_RECEIVED,
    CONSENSUS_PROPOSALS_VALIDATED,
    CONSENSUS_ROUND,
    CONSENSUS_ROUND_ABOVE_ZERO,
    CONSENSUS_ROUND_ADVANCES,
    CONSENSUS_TIMEOUTS,
    LABEL_NAME_TIMEOUT_TYPE,
};
use apollo_consensus_manager::metrics::{
    CONSENSUS_NETWORK_EVENTS,
    CONSENSUS_NUM_CONNECTED_PEERS,
    CONSENSUS_PING_LATENCY,
    CONSENSUS_PROPOSALS_DROPPED_MESSAGE_SIZE,
    CONSENSUS_PROPOSALS_NUM_DROPPED_MESSAGES,
    CONSENSUS_PROPOSALS_NUM_RECEIVED_MESSAGES,
    CONSENSUS_PROPOSALS_NUM_SENT_MESSAGES,
    CONSENSUS_PROPOSALS_RECEIVED_MESSAGE_SIZE,
    CONSENSUS_PROPOSALS_SENT_MESSAGE_SIZE,
    CONSENSUS_VOTES_DROPPED_MESSAGE_SIZE,
    CONSENSUS_VOTES_NUM_DROPPED_MESSAGES,
    CONSENSUS_VOTES_NUM_RECEIVED_MESSAGES,
    CONSENSUS_VOTES_NUM_SENT_MESSAGES,
    CONSENSUS_VOTES_RECEIVED_MESSAGE_SIZE,
    CONSENSUS_VOTES_SENT_MESSAGE_SIZE,
};
use apollo_consensus_orchestrator::metrics::{
    CENDE_LAST_PREPARED_BLOB_BLOCK_NUMBER,
    CENDE_WRITE_BLOB_FAILURE,
    CENDE_WRITE_BLOB_SUCCESS,
    CENDE_WRITE_PREV_HEIGHT_BLOB_LATENCY,
    CONSENSUS_BUILD_PROPOSAL_FAILURE,
    CONSENSUS_L2_GAS_PRICE,
    CONSENSUS_L2_GAS_PRICE_CLAMPED,
    CONSENSUS_VALIDATE_PROPOSAL_FAILURE,
    LABEL_BUILD_PROPOSAL_FAILURE_REASON,
    LABEL_CENDE_FAILURE_REASON,
    LABEL_L2_GAS_PRICE_CLAMP_BOUND,
    LABEL_VALIDATE_PROPOSAL_FAILURE_REASON,
    SNIP35_FEE_ACTUAL_FRI,
    SNIP35_FEE_PROPOSAL_FRI,
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM,
    SNIP35_FEE_TARGET_ATTO_USD,
    SNIP35_FEE_TARGET_FRI,
};
use apollo_l1_gas_price::metrics::{
    EXCHANGE_RATE_ORACLE_ERROR_COUNT,
    EXCHANGE_RATE_ORACLE_LAST_SUCCESS_TIMESTAMP_SECONDS,
    EXCHANGE_RATE_ORACLE_RATE,
    EXCHANGE_RATE_ORACLE_SUCCESS_COUNT,
};
use apollo_l1_gas_price_types::{CurrencyPair, LABEL_NAME_CURRENCY_PAIR};
use apollo_metrics::metrics::MetricQueryName;
use apollo_network::metrics::{LABEL_NAME_BROADCAST_DROP_REASON, LABEL_NAME_EVENT_TYPE};
use apollo_state_sync_metrics::metrics::STATE_SYNC_CLASS_MANAGER_MARKER;
use apollo_transaction_converter::metrics::CONSENSUS_PROOF_MANAGER_STORE_LATENCY;

use crate::dashboard::Row;
use crate::panel::{traffic_light_thresholds, Panel, PanelType, Unit};
use crate::query_builder::{
    increase,
    increase_with_label,
    seconds_since_last_timestamp_with_label,
    sum_by_label,
    sum_increase_with_label,
    with_label,
    DisplayMethod,
    DEFAULT_DURATION,
    RANGE_DURATION,
};

// The key events that are relevant to the consensus panel.
const CONSENSUS_KEY_EVENTS_LOG_QUERY: &str =
    "\"START_HEIGHT:\" OR \"START_ROUND\" OR textPayload=~\"DECISION_REACHED\" OR \
     \"PROPOSAL_FAILED\" OR \"Proposal succeeded\" OR \"Applying Timeout\" OR \"Accepting\" OR \
     \"Broadcasting\"";

pub(crate) fn get_panel_consensus_block_number() -> Panel {
    Panel::new(
        "Consensus Height",
        "The block height the node is currently working on",
        CONSENSUS_BLOCK_NUMBER.get_name_with_filter().to_string(),
        PanelType::Stat,
    )
    .with_log_query(
        "\"START_HEIGHT: running consensus for height\" OR \"Start building proposal\" OR \"Start \
         validating proposal\"",
    )
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

pub(crate) fn get_panel_consensus_block_number_diff_from_sync() -> Panel {
    Panel::new(
        "Consensus Height Diff From Sync",
        "The difference between the consensus height and the sync height",
        format!(
            "({} - {})",
            CONSENSUS_BLOCK_NUMBER.get_name_with_filter(),
            STATE_SYNC_CLASS_MANAGER_MARKER.get_name_with_filter()
        ),
        PanelType::TimeSeries,
    )
    .with_log_query("\"State sync is not ready\" OR \"to fetch retrospective block hash\"")
}

pub(crate) fn get_panel_consensus_round() -> Panel {
    Panel::new(
        "Consensus Round",
        "The round the node is currently working on. Round 0 is the happy path; persistently \
         non-zero rounds indicate consensus difficulty (missing proposals, timeouts, divergence).",
        CONSENSUS_ROUND.get_name_with_filter().to_string(),
        PanelType::TimeSeries,
    )
    .with_absolute_thresholds(traffic_light_thresholds(1.0, 3.0))
    .with_log_query("\"START_ROUND\" OR \"PROPOSAL_FAILED\" OR textPayload=~\"DECISION_REACHED\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

pub(crate) fn get_panel_consensus_round_advanced() -> Panel {
    Panel::new(
        "Consensus Round Advanced",
        format!(
            "The number of times the consensus round advanced (counter is increased whenever \
             round > 0) ({DEFAULT_DURATION} window)",
        ),
        increase(&CONSENSUS_ROUND_ADVANCES, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("\"START_ROUND\" OR \"PROPOSAL_FAILED\" OR textPayload=~\"DECISION_REACHED\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_round_above_zero() -> Panel {
    Panel::new(
        "Consensus Round Above Zero",
        "Occurrences where the consensus round was greater than zero, over the displayed time \
         range",
        format!(
            "{m} - ({m} @ start())",
            m = CONSENSUS_ROUND_ABOVE_ZERO.get_name_with_filter().to_string()
        ),
        PanelType::TimeSeries,
    )
    .with_log_query("\"START_ROUND\" OR \"PROPOSAL_FAILED\" OR textPayload=~\"DECISION_REACHED\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_decisions_reached_by_consensus() -> Panel {
    Panel::new(
        "Decisions Reached By Consensus",
        format!("The number of decisions reached by way of consensus ({DEFAULT_DURATION} window)",),
        increase(&CONSENSUS_DECISIONS_REACHED_BY_CONSENSUS, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("DECISION_REACHED: Decision reached for round")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_decisions_reached_by_sync() -> Panel {
    Panel::new(
        "Decisions Reached By Sync",
        format!("The number of decisions reached by way of sync ({DEFAULT_DURATION} window)",),
        increase(&CONSENSUS_DECISIONS_REACHED_BY_SYNC, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("Decision learned via sync protocol.")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_proposals_received() -> Panel {
    Panel::new(
        "Proposal Validation: Number of Received Proposals",
        format!("The number of proposals received from the network ({DEFAULT_DURATION} window)",),
        increase(&CONSENSUS_PROPOSALS_RECEIVED, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
}

fn get_panel_consensus_proposals_acceptance_rate() -> Panel {
    Panel::new(
        "Proposal Validation: Acceptance Rate (%)",
        format!(
            "Percentage of received proposals accepted for validation ({DEFAULT_DURATION} window).",
        ),
        format!(
            "{} / {}",
            increase(&CONSENSUS_PROPOSALS_ACCEPTED_FOR_VALIDATION, DEFAULT_DURATION),
            increase(&CONSENSUS_PROPOSALS_RECEIVED, DEFAULT_DURATION),
        ),
        PanelType::TimeSeries,
    )
    .with_unit(Unit::PercentUnit)
}

fn get_panel_consensus_proposals_validated() -> Panel {
    Panel::new(
        "Proposal Validation: Number of Validated Proposals",
        format!(
            "The number of proposals received and validated successfully ({DEFAULT_DURATION} \
             window)",
        ),
        increase(&CONSENSUS_PROPOSALS_VALIDATED, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("\"Validated proposal.\" OR \"PROPOSAL_FAILED\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_proposals_invalid() -> Panel {
    Panel::new(
        "Proposal Validation: Number of Invalid Proposals",
        format!(
            "The number of proposals received and failed validation ({DEFAULT_DURATION} window)",
        ),
        increase(&CONSENSUS_PROPOSALS_INVALID, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("\"Validated proposal.\" OR \"PROPOSAL_FAILED\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_validate_proposal_failure() -> Panel {
    Panel::new(
        "Proposal Validation: Proposal Failure by Reason",
        "The number of validate proposal failures (over the selected time range)",
        sum_by_label(
            &CONSENSUS_VALIDATE_PROPOSAL_FAILURE,
            LABEL_VALIDATE_PROPOSAL_FAILURE_REASON,
            DisplayMethod::Increase(RANGE_DURATION),
            true,
        ),
        PanelType::Stat,
    )
    .with_log_query("PROPOSAL_FAILED: Proposal failed as validator")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_build_proposal_total() -> Panel {
    Panel::new(
        "Proposal Build: Number of Proposals Started",
        format!("The number of proposals that started building ({DEFAULT_DURATION} window)",),
        increase(&CONSENSUS_BUILD_PROPOSAL_TOTAL, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
}

fn get_panel_consensus_build_proposal_failed() -> Panel {
    Panel::new(
        "Proposal Build: Number of Proposals Failed",
        format!("The number of proposals that failed to be built ({DEFAULT_DURATION} window)",),
        increase(&CONSENSUS_BUILD_PROPOSAL_FAILED, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
}

fn get_panel_build_proposal_failure() -> Panel {
    Panel::new(
        "Proposal Build: Proposal Failure by Reason",
        "The number of build proposal failures (over the selected time range)",
        sum_by_label(
            &CONSENSUS_BUILD_PROPOSAL_FAILURE,
            LABEL_BUILD_PROPOSAL_FAILURE_REASON,
            DisplayMethod::Increase(RANGE_DURATION),
            true,
        ),
        PanelType::Stat,
    )
    .with_log_query("PROPOSAL_FAILED: Proposal failed as proposer")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_timeouts_by_type() -> Panel {
    Panel::new(
        "Consensus Timeouts By Type",
        format!(
            "The number of times consensus has timed out by type ({DEFAULT_DURATION} window). \n- \
             TimeoutPropose: as proposer, didn’t finish building in time; as validator, either \
             didn’t receive the proposal or didn’t finish validation in time.\n- TimeoutPrevote: \
             the node voted and received a quorum of prevotes, but not on the same value.\n- \
             TimeoutPrecommit: didn’t finish validation but quorum of precommits received, or it \
             finished but no decision reached."
        ),
        sum_by_label(
            &CONSENSUS_TIMEOUTS,
            LABEL_NAME_TIMEOUT_TYPE,
            DisplayMethod::Increase(DEFAULT_DURATION),
            false,
        ),
        PanelType::TimeSeries,
    )
    .with_log_query("Applying Timeout")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_proof_manager_store_latency() -> Panel {
    Panel::from_hist(
        &CONSENSUS_PROOF_MANAGER_STORE_LATENCY,
        "Consensus Proof Manager Store Latency",
        "The time it takes to store a proof in the proof manager during proposal validation",
    )
    .with_unit(Unit::Seconds)
}

fn get_panel_consensus_l2_gas_price() -> Panel {
    Panel::new(
        "L2 Gas Price (GFri)",
        "L2 gas price in GFri calculated in an accepted proposal",
        format!("{} / 1e9", CONSENSUS_L2_GAS_PRICE.get_name_with_filter()),
        PanelType::TimeSeries,
    )
}

fn get_panel_consensus_l2_gas_price_clamped() -> Panel {
    Panel::new(
        "L2 Gas Price Clamped By Bound",
        format!(
            "The number of blocks whose computed L2 gas price was pulled to a bound \
             ({DEFAULT_DURATION} window). The minimum series ticks throughout an ordinary ramp \
             towards the SNIP-35 floor; the maximum series is the one that signals trouble"
        ),
        sum_by_label(
            &CONSENSUS_L2_GAS_PRICE_CLAMPED,
            LABEL_L2_GAS_PRICE_CLAMP_BOUND,
            DisplayMethod::Increase(DEFAULT_DURATION),
            false,
        ),
        PanelType::TimeSeries,
    )
    .with_log_query("\"maximum gas price\" OR \"below minimum gas price\"")
}

fn get_panel_cende_last_prepared_blob_block_number() -> Panel {
    Panel::new(
        "Last Prepared Blob Block Number",
        "The block number that is ready to be sent to Cende in the next height",
        CENDE_LAST_PREPARED_BLOB_BLOCK_NUMBER.get_name_with_filter().to_string(),
        PanelType::Stat,
    )
    .with_log_query("Blob for block number")
}

fn get_panel_cende_write_prev_height_blob_latency() -> Panel {
    Panel::from_hist(
        &CENDE_WRITE_PREV_HEIGHT_BLOB_LATENCY,
        "Write Blob Latency",
        "The time it takes to write the blob to Cende",
    )
    .with_unit(Unit::Seconds)
}

fn get_panel_cende_write_blob_success() -> Panel {
    let query_expression = [
        "\"Blob for block number\"",
        "\"Writing blob to Aerospike\"",
        "\"transactions was written to Aerospike\"",
    ]
    .join(" OR ");

    Panel::new(
        "Write Blob Success",
        format!("The number of successful blob writes to Cende ({DEFAULT_DURATION} window)"),
        increase(&CENDE_WRITE_BLOB_SUCCESS, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query(query_expression)
}

fn get_panel_cende_write_blob_failure() -> Panel {
    Panel::new(
        "Write Blob Failure by Reason",
        format!("The number of failed blob writes to Cende ({} window)", DEFAULT_DURATION),
        sum_by_label(
            &CENDE_WRITE_BLOB_FAILURE,
            LABEL_CENDE_FAILURE_REASON,
            DisplayMethod::Increase(DEFAULT_DURATION),
            false,
        ),
        PanelType::TimeSeries,
    )
    .with_log_query("CENDE_FAILURE")
}

fn get_panel_cende_write_preconfirmed_block() -> Panel {
    Panel::new(
        "Write Preconfirmed Block Success",
        format!(
            "The number of successful writes to Cende for preconfirmed blocks ({DEFAULT_DURATION} \
             window). Each preconfirmed block may involve multiple writes.",
        ),
        increase(&PRECONFIRMED_BLOCK_WRITTEN, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("write_pre_confirmed_block request succeeded.")
}

fn get_panel_cende_write_preconfirmed_block_failure() -> Panel {
    let query_expression = [
        "\"write_pre_confirmed_block request failed\"",
        "\"Failed to send write_pre_confirmed_block request to Cende recorder\"",
    ]
    .join(" OR ");

    Panel::new(
        "Write Preconfirmed Block Failure by Reason",
        format!(
            "The number of failed writes to Cende for preconfirmed blocks ({DEFAULT_DURATION} \
             window)",
        ),
        sum_by_label(
            &PRECONFIRMED_BLOCK_WRITE_FAILURE,
            LABEL_NAME_PRECONFIRMED_BLOCK_WRITE_FAILURE_REASON,
            DisplayMethod::Increase(DEFAULT_DURATION),
            true,
        ),
        PanelType::TimeSeries,
    )
    .with_log_query(query_expression)
}

fn get_panel_consensus_num_connected_peers() -> Panel {
    Panel::new(
        "Number of Connected Peers",
        "The number of connected peers in Consensus P2P",
        CONSENSUS_NUM_CONNECTED_PEERS.get_name_with_filter().to_string(),
        PanelType::Stat,
    )
    .with_log_query("network_manager")
}

fn get_panel_consensus_votes_num_sent_messages() -> Panel {
    Panel::new(
        "Consensus Votes Number of Sent Messages",
        "The increase in the number of vote messages sent by consensus p2p (over the selected \
         time range)",
        increase(&CONSENSUS_VOTES_NUM_SENT_MESSAGES, "$__range"),
        PanelType::Stat,
    )
}

fn get_panel_consensus_votes_sent_message_size() -> Panel {
    Panel::from_hist(
        &CONSENSUS_VOTES_SENT_MESSAGE_SIZE,
        "Consensus Votes Sent Message Size MB/sec",
        "The rate of MB per second sent by the consensus p2p component over the Votes topic",
    )
    .with_unit(Unit::MB)
}

fn get_panel_consensus_votes_num_received_messages() -> Panel {
    Panel::new(
        "Consensus Votes Number of Received Messages",
        "The increase in the number of vote messages received by consensus p2p (over the selected \
         time range)",
        increase(&CONSENSUS_VOTES_NUM_RECEIVED_MESSAGES, "$__range"),
        PanelType::Stat,
    )
}

fn get_panel_consensus_votes_received_message_size() -> Panel {
    Panel::from_hist(
        &CONSENSUS_VOTES_RECEIVED_MESSAGE_SIZE,
        "Consensus Votes Received Message Size MB/sec",
        "The rate of MB per second received by the consensus p2p component over the Votes topic",
    )
    .with_unit(Unit::MB)
}

fn get_panel_consensus_proposals_num_sent_messages() -> Panel {
    Panel::new(
        "Consensus Proposals Number of Sent Messages",
        "The increase in the number of proposal messages sent by consensus p2p (over the selected \
         time range)",
        increase(&CONSENSUS_PROPOSALS_NUM_SENT_MESSAGES, "$__range"),
        PanelType::Stat,
    )
}

fn get_panel_consensus_proposals_sent_message_size() -> Panel {
    Panel::from_hist(
        &CONSENSUS_PROPOSALS_SENT_MESSAGE_SIZE,
        "Consensus Proposals Sent Message Size MB/sec",
        "The rate of MB per second sent by the consensus p2p component over the Proposals topic",
    )
    .with_unit(Unit::MB)
}

fn get_panel_consensus_proposals_num_received_messages() -> Panel {
    Panel::new(
        "Consensus Proposals Number of Received Messages",
        "The increase in the number of proposal messages received by consensus p2p (over the \
         selected time range)",
        increase(&CONSENSUS_PROPOSALS_NUM_RECEIVED_MESSAGES, "$__range"),
        PanelType::Stat,
    )
}

fn get_panel_consensus_proposals_received_message_size() -> Panel {
    Panel::from_hist(
        &CONSENSUS_PROPOSALS_RECEIVED_MESSAGE_SIZE,
        "Consensus Proposals Received Message Size MB/sec",
        "The rate of MB per second received by the consensus p2p component over the Proposals \
         topic",
    )
    .with_unit(Unit::MB)
}

fn get_panel_consensus_conflicting_votes() -> Panel {
    Panel::new(
        "Consensus Conflicting Votes",
        "The increase in the number of conflicting votes (over the selected time range)",
        increase(&CONSENSUS_CONFLICTING_VOTES, "$__range"),
        PanelType::Stat,
    )
}

fn get_panel_consensus_network_events_by_type() -> Panel {
    Panel::new(
        "Consensus Network Events By Type",
        "Network events received by consensus p2p, by event type (over the selected time range)",
        sum_by_label(
            &CONSENSUS_NETWORK_EVENTS,
            LABEL_NAME_EVENT_TYPE,
            DisplayMethod::Increase(RANGE_DURATION),
            true,
        ),
        PanelType::Stat,
    )
}

fn get_panel_consensus_votes_dropped_messages_by_reason() -> Panel {
    Panel::new(
        "Consensus Votes Dropped Messages By Reason",
        "The number of dropped consensus votes messages, by reason (over the selected time range)",
        sum_by_label(
            &CONSENSUS_VOTES_NUM_DROPPED_MESSAGES,
            LABEL_NAME_BROADCAST_DROP_REASON,
            DisplayMethod::Increase(RANGE_DURATION),
            true,
        ),
        PanelType::Stat,
    )
}

fn get_panel_consensus_votes_dropped_message_size() -> Panel {
    Panel::from_hist(
        &CONSENSUS_VOTES_DROPPED_MESSAGE_SIZE,
        "Consensus Votes Dropped Message Size Bytes/sec",
        "The rate of MB per second dropped by the consensus p2p component over the Votes topic",
    )
    .with_unit(Unit::MB)
}

fn get_panel_consensus_proposals_dropped_messages_by_reason() -> Panel {
    Panel::new(
        "Consensus Proposals Dropped Messages By Reason",
        "The number of dropped consensus proposals messages, by reason (over the selected time \
         range)",
        sum_by_label(
            &CONSENSUS_PROPOSALS_NUM_DROPPED_MESSAGES,
            LABEL_NAME_BROADCAST_DROP_REASON,
            DisplayMethod::Increase(RANGE_DURATION),
            true,
        ),
        PanelType::Stat,
    )
}

fn get_panel_consensus_proposals_dropped_message_size() -> Panel {
    Panel::from_hist(
        &CONSENSUS_PROPOSALS_DROPPED_MESSAGE_SIZE,
        "Consensus Proposals Dropped Message Size MB/sec",
        "The rate of MB per second dropped by the consensus p2p component over the Proposals topic",
    )
    .with_unit(Unit::MB)
}

fn get_panel_consensus_ping_latency() -> Panel {
    Panel::from_hist(
        &CONSENSUS_PING_LATENCY,
        "Ping Latency",
        "The ping latency distribution for consensus p2p connections",
    )
    .with_unit(Unit::Seconds)
}

fn get_panel_consensus_decisions_reached_as_proposer() -> Panel {
    Panel::new(
        "Consensus Decisions Reached As Proposer",
        format!(
            "The number of rounds with decision reached where this node is the proposer \
             ({DEFAULT_DURATION} window)",
        ),
        increase(&CONSENSUS_DECISIONS_REACHED_AS_PROPOSER, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("\"Building proposal\" OR \"BATCHER_FIN_PROPOSER\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

pub(crate) fn get_panel_consensus_decisions_reached_as_proposer_counter() -> Panel {
    Panel::new(
        "Consensus Decisions Reached As Proposer Counter",
        "The number of rounds with decision reached where this node is the proposer, from last \
         restart",
        CONSENSUS_DECISIONS_REACHED_AS_PROPOSER.get_name_with_filter().to_string(),
        PanelType::Stat,
    )
    .with_log_query("\"Building proposal\" OR \"BATCHER_FIN_PROPOSER\"")
    .with_log_comment(CONSENSUS_KEY_EVENTS_LOG_QUERY)
}

fn get_panel_consensus_inbound_peer_evicted() -> Panel {
    Panel::new(
        "Inbound Peer Evicted",
        format!(
            "The number of inbound peers evicted from the stream handler LRU cache \
             ({DEFAULT_DURATION} window)",
        ),
        increase(&CONSENSUS_INBOUND_PEER_EVICTED, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
}

fn get_panel_consensus_inbound_stream_buffer_full() -> Panel {
    Panel::new(
        "Inbound Stream Buffer Full",
        format!(
            "The number of inbound streams dropped due to full message buffer ({DEFAULT_DURATION} \
             window)",
        ),
        increase(&CONSENSUS_INBOUND_STREAM_BUFFER_FULL, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
}

fn get_panel_consensus_inbound_stream_evicted() -> Panel {
    Panel::new(
        "Inbound Stream Evicted",
        format!(
            "The number of inbound streams evicted due to cache capacity ({DEFAULT_DURATION} \
             window)",
        ),
        increase(&CONSENSUS_INBOUND_STREAM_EVICTED, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
}

fn get_panel_consensus_inbound_stream_success_ratio() -> Panel {
    Panel::new(
        "Inbound Stream Success Ratio (%)",
        format!("Inbound stream success ratio: finished/started ({DEFAULT_DURATION} window)",),
        format!(
            "{} / {}",
            increase(&CONSENSUS_INBOUND_STREAM_FINISHED, DEFAULT_DURATION),
            increase(&CONSENSUS_INBOUND_STREAM_STARTED, DEFAULT_DURATION),
        ),
        PanelType::TimeSeries,
    )
    .with_unit(Unit::PercentUnit)
}

fn get_panel_consensus_outbound_stream_success_ratio() -> Panel {
    Panel::new(
        "Outbound Stream Success Ratio (%)",
        format!("Outbound stream success ratio: finished/started ({DEFAULT_DURATION} window)",),
        format!(
            "{} / {}",
            increase(&CONSENSUS_OUTBOUND_STREAM_FINISHED, DEFAULT_DURATION),
            increase(&CONSENSUS_OUTBOUND_STREAM_STARTED, DEFAULT_DURATION),
        ),
        PanelType::TimeSeries,
    )
    .with_unit(Unit::PercentUnit)
}

pub(crate) fn get_consensus_row() -> Row {
    Row::new(
        "Consensus",
        vec![
            get_panel_consensus_block_number(),
            get_panel_consensus_round(),
            get_panel_consensus_round_advanced(),
            get_panel_consensus_round_above_zero(),
            get_panel_consensus_block_number_diff_from_sync(),
            get_panel_consensus_decisions_reached_as_proposer(),
            get_panel_consensus_decisions_reached_by_consensus(),
            get_panel_consensus_decisions_reached_by_sync(),
            get_panel_consensus_build_proposal_total(),
            get_panel_consensus_build_proposal_failed(),
            get_panel_build_proposal_failure(),
            get_panel_consensus_proposals_received(),
            get_panel_consensus_proposals_acceptance_rate(),
            get_panel_consensus_proposals_validated(),
            get_panel_consensus_proposals_invalid(),
            get_panel_validate_proposal_failure(),
            get_panel_consensus_proof_manager_store_latency(),
            get_panel_consensus_timeouts_by_type(),
            get_panel_consensus_l2_gas_price(),
            get_panel_consensus_l2_gas_price_clamped(),
        ],
    )
}

pub(crate) fn get_consensus_streams_row() -> Row {
    Row::new(
        "Consensus Streams",
        vec![
            get_panel_consensus_outbound_stream_success_ratio(),
            get_panel_consensus_inbound_stream_success_ratio(),
            get_panel_consensus_inbound_stream_evicted(),
            get_panel_consensus_inbound_peer_evicted(),
            get_panel_consensus_inbound_stream_buffer_full(),
        ],
    )
}

pub(crate) fn get_cende_row() -> Row {
    Row::new(
        "Cende",
        vec![
            get_panel_cende_write_blob_success(),
            get_panel_cende_write_blob_failure(),
            get_panel_cende_write_prev_height_blob_latency(),
            get_panel_cende_last_prepared_blob_block_number(),
            get_panel_cende_write_preconfirmed_block(),
            get_panel_cende_write_preconfirmed_block_failure(),
        ],
    )
}

fn get_panel_snip35_fee_actual() -> Panel {
    Panel::new(
        "Fee Actual (GFri)",
        "Median of recent fee_proposals over the sliding window, in GFri",
        format!("{} / 1e9", SNIP35_FEE_ACTUAL_FRI.get_name_with_filter()),
        PanelType::TimeSeries,
    )
}

fn get_panel_snip35_fee_proposal() -> Panel {
    Panel::new(
        "Fee Proposal (GFri)",
        "fee_proposal this node published in the latest block, in GFri",
        format!("{} / 1e9", SNIP35_FEE_PROPOSAL_FRI.get_name_with_filter()),
        PanelType::TimeSeries,
    )
}

fn get_panel_snip35_fee_target() -> Panel {
    Panel::new(
        "Fee Target (GFri)",
        "fee_target computed from the STRK/USD oracle, in GFri",
        format!("{} / 1e9", SNIP35_FEE_TARGET_FRI.get_name_with_filter()),
        PanelType::TimeSeries,
    )
}

fn get_panel_snip35_fee_target_above_maximum() -> Panel {
    Panel::new(
        "Fee Target Above Maximum",
        format!(
            "The number of blocks whose oracle-derived fee_target exceeded the L2 gas price \
             maximum ({DEFAULT_DURATION} window)"
        ),
        increase(&SNIP35_FEE_TARGET_ABOVE_MAXIMUM, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("\"exceeds the L2 gas price maximum\"")
}

fn get_panel_snip35_fee_target_atto_usd() -> Panel {
    Panel::new(
        "Fee Target (USD per 1B L2 gas)",
        "Configured target USD cost per 1 billion L2 gas units (raw metric is atto-USD per L2 \
         gas; atto-USD / 1e9 = USD per 1B L2 gas)",
        format!("{} / 1e9", SNIP35_FEE_TARGET_ATTO_USD.get_name_with_filter()),
        PanelType::Stat,
    )
}

fn get_panel_snip35_strk_usd_rate() -> Panel {
    Panel::new(
        "STRK/USD Rate (USD)",
        "STRK/USD rate from the oracle, in USD (raw value has 18 decimals)",
        format!(
            "{} / 1e18",
            with_label(
                &EXCHANGE_RATE_ORACLE_RATE,
                LABEL_NAME_CURRENCY_PAIR,
                CurrencyPair::StrkUsd.into()
            )
        ),
        PanelType::TimeSeries,
    )
}

fn get_panel_snip35_strk_usd_error_count() -> Panel {
    Panel::new(
        "STRK/USD Rate Query Error Count by Error Type",
        format!(
            "The number of times the STRK→USD rate query failed, split by error type \
             ({DEFAULT_DURATION} window)"
        ),
        increase_with_label(
            &EXCHANGE_RATE_ORACLE_ERROR_COUNT,
            LABEL_NAME_CURRENCY_PAIR,
            CurrencyPair::StrkUsd.into(),
            DEFAULT_DURATION,
            true,
        ),
        PanelType::TimeSeries,
    )
    .with_log_query(
        "\"Failed to resolve query to\" OR \"Timeout when resolving query to\" OR \"Query failed \
         to join handle for timestamp\"",
    )
}

fn get_panel_snip35_strk_usd_total_error_count() -> Panel {
    Panel::new(
        "STRK/USD Rate Query Total Error Count",
        format!(
            "The number of times the STRK→USD rate query failed, summed over error types \
             ({DEFAULT_DURATION} window). The error count alert thresholds this sum."
        ),
        sum_increase_with_label(
            &EXCHANGE_RATE_ORACLE_ERROR_COUNT,
            LABEL_NAME_CURRENCY_PAIR,
            CurrencyPair::StrkUsd.into(),
            DEFAULT_DURATION,
        ),
        PanelType::TimeSeries,
    )
}

fn get_panel_snip35_strk_usd_success_count() -> Panel {
    Panel::new(
        "STRK/USD Rate Query Success (Binary)",
        "Indicates whether the STRK→USD rate query succeeded (1m window)",
        format!(
            "changes({}[1m])",
            with_label(
                &EXCHANGE_RATE_ORACLE_SUCCESS_COUNT,
                LABEL_NAME_CURRENCY_PAIR,
                CurrencyPair::StrkUsd.into()
            )
        ),
        PanelType::TimeSeries,
    )
    .with_log_query("Caching conversion rate for timestamp")
}

fn get_panel_snip35_strk_usd_seconds_since_last_successful_update() -> Panel {
    Panel::new(
        "Seconds Since Last Successful STRK→USD Rate Update",
        "The number of seconds since the last successful STRK→USD rate update (assuming there was \
         an update in the last 12 hours).",
        seconds_since_last_timestamp_with_label(
            &EXCHANGE_RATE_ORACLE_LAST_SUCCESS_TIMESTAMP_SECONDS,
            LABEL_NAME_CURRENCY_PAIR,
            CurrencyPair::StrkUsd.into(),
        ),
        PanelType::TimeSeries,
    )
    .with_unit(Unit::Seconds)
    .with_absolute_thresholds(traffic_light_thresholds(1200.0, 1800.0))
}

pub(crate) fn get_snip35_row() -> Row {
    Row::new(
        "Dynamic Gas Price (SNIP-35)",
        vec![
            get_panel_snip35_fee_actual(),
            get_panel_snip35_fee_proposal(),
            get_panel_snip35_fee_target(),
            get_panel_snip35_fee_target_above_maximum(),
            get_panel_snip35_fee_target_atto_usd(),
            get_panel_snip35_strk_usd_rate(),
            get_panel_snip35_strk_usd_success_count(),
            get_panel_snip35_strk_usd_error_count(),
            get_panel_snip35_strk_usd_total_error_count(),
            get_panel_snip35_strk_usd_seconds_since_last_successful_update(),
        ],
    )
}

pub(crate) fn get_consensus_p2p_row() -> Row {
    Row::new(
        "Consensus P2P",
        vec![
            get_panel_consensus_num_connected_peers(),
            get_panel_consensus_proposals_sent_message_size(),
            get_panel_consensus_proposals_received_message_size(),
            get_panel_consensus_proposals_dropped_message_size(),
            get_panel_consensus_proposals_num_sent_messages(),
            get_panel_consensus_proposals_num_received_messages(),
            get_panel_consensus_proposals_dropped_messages_by_reason(),
            get_panel_consensus_votes_sent_message_size(),
            get_panel_consensus_votes_received_message_size(),
            get_panel_consensus_votes_dropped_message_size(),
            get_panel_consensus_votes_num_sent_messages(),
            get_panel_consensus_votes_num_received_messages(),
            get_panel_consensus_votes_dropped_messages_by_reason(),
            get_panel_consensus_conflicting_votes(),
            get_panel_consensus_network_events_by_type(),
            get_panel_consensus_ping_latency(),
        ],
    )
}
