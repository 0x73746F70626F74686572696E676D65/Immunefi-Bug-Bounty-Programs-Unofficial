use std::collections::{HashMap, HashSet};
use std::future::Future;
use std::net::{Ipv4Addr, SocketAddr};
use std::panic;
use std::time::Duration;

use apollo_base_layer_tests::anvil_base_layer::AnvilBaseLayer;
use apollo_deployments::deployment_definitions::ComponentConfigInService;
use apollo_deployments::service::{NodeService, NodeType};
use apollo_http_server::test_utils::HttpTestClient;
use apollo_infra_utils::dumping::serialize_to_file;
use apollo_infra_utils::test_utils::{AvailablePortsGenerator, TestIdentifier};
use apollo_infra_utils::tracing::{CustomLogger, TraceLevel};
use apollo_l1_gas_price_config::config::{ExchangeRateOracleConfig, L1GasPriceScraperConfig};
use apollo_monitoring_endpoint::test_utils::MonitoringClient;
use apollo_monitoring_endpoint_config::config::MonitoringEndpointConfig;
use apollo_network::network_manager::test_utils::create_connected_network_configs;
use apollo_node::test_utils::node_runner::{get_node_executable_path, spawn_run_node};
use apollo_node_config::component_execution_config::{
    ActiveComponentExecutionConfig,
    ReactiveComponentExecutionConfig,
};
use apollo_node_config::config_utils::DeploymentBaseAppConfig;
use apollo_node_config::definitions::ConfigPointersMap;
use apollo_node_config::node_config::SequencerNodeConfig;
use apollo_storage::storage_reader_server_test_utils::send_storage_reader_http_request;
use apollo_storage::storage_reader_types::{StorageReaderRequest, StorageReaderResponse};
use apollo_storage::{MarkerKind, StorageConfig};
use apollo_test_utils::send_request;
use blockifier::bouncer::BouncerWeights;
use blockifier::context::ChainInfo;
use futures::future::join_all;
use futures::TryFutureExt;
use mempool_test_utils::starknet_api_test_utils::{
    contract_class,
    AccountId,
    MultiAccountTransactionGenerator,
};
use papyrus_base_layer::ethereum_base_layer_contract::EthereumBaseLayerConfig;
use papyrus_base_layer::test_utils::anvil_mine_blocks;
use starknet_api::block::{BlockHash, BlockNumber};
use starknet_api::core::{ChainId, Nonce, StateDiffCommitment};
use starknet_api::execution_resources::GasAmount;
use starknet_api::rpc_transaction::RpcTransaction;
use starknet_api::state::SierraContractClass;
use starknet_api::transaction::TransactionHash;
use tokio::join;
use tokio::time::{sleep, timeout, Instant};
use tokio_util::task::AbortOnDropHandle;
use tracing::{info, instrument};

use crate::executable_setup::{ExecutableSetup, NodeExecutableId};
use crate::monitoring_utils::{
    assert_no_reverted_txs,
    await_batcher_block,
    await_block,
    await_sync_block,
    await_txs_accepted,
    get_consensus_decisions_reached,
    sequencer_num_accepted_txs,
    verify_txs_accepted,
};
use crate::node_component_configs::{
    create_consolidated_component_configs,
    create_distributed_component_configs,
    create_hybrid_component_configs,
};
use crate::sequencer_simulator_utils::SequencerSimulator;
use crate::state_reader::{proof_flow_chain_info, PresetTestContracts, StorageTestHandles};
use crate::storage::{get_integration_test_storage, CustomPaths};
use crate::utils::{
    create_consensus_manager_configs_from_network_configs,
    create_integration_test_tx_generator,
    create_mempool_p2p_configs,
    create_node_config,
    create_state_sync_configs,
    send_consensus_txs,
    send_message_to_l2_and_calculate_tx_hash,
    set_validator_id,
    spawn_local_eth_to_strk_oracle,
    spawn_local_success_recorder,
    ConsensusTxs,
    DeclareTx,
    DeployAndInvokeTxs,
    NodeDescriptor,
    TestScenario,
    TEST_SCENARIO_TIMEOUT,
    TIME_BETWEEN_CHECKS,
};

pub const DEFAULT_SENDER_ACCOUNT: AccountId = 0;
pub const BLOCK_TO_WAIT_FOR_DEPLOY_AND_INVOKE: BlockNumber = BlockNumber(4);
pub const BLOCK_TO_WAIT_FOR_DECLARE: BlockNumber =
    BlockNumber(BLOCK_TO_WAIT_FOR_DEPLOY_AND_INVOKE.0 + 10);

pub const HTTP_PORT_ARG: &str = "http-port";
pub const MONITORING_PORT_ARG: &str = "monitoring-port";

const ALLOW_BOOTSTRAP_TXS: bool = false;
// TODO(Tsabary,NoamSp): consider reducing the number of attempts.
const AWAIT_ALIVE_INTERVAL_MS: u64 = 100;
const AWAIT_ALIVE_ATTEMPTS: usize = 2500;

fn block_max_capacity_gas() -> GasAmount {
    BouncerWeights::default().proving_gas
}

pub struct NodeSetup {
    node_type: NodeType,
    executables: HashMap<NodeService, ExecutableSetup>,

    // Client for adding transactions to the sequencer node. `None` for validation-only nodes,
    // which have no HTTP server or gateway.
    pub add_tx_http_client: Option<HttpTestClient>,

    // Handles for the storage files, maintained so the files are not deleted. Since
    // these are only maintained to avoid dropping the handles, private visibility suffices, and
    // as such, the '#[allow(dead_code)]' attributes are used to suppress the warning.
    #[allow(dead_code)]
    storage_handles: StorageTestHandles,
}

fn get_executable_by_component(
    node_type: NodeType,
    executables: &HashMap<NodeService, ExecutableSetup>,
    component: ComponentConfigInService,
) -> &ExecutableSetup {
    executables
        .get(
            &node_type
                .get_services_of_components(component.clone())
                .into_iter()
                .next()
                .unwrap_or_else(|| {
                    panic!("Expected at least one executable with component {:?}", component)
                }),
        )
        .unwrap()
}

impl NodeSetup {
    pub fn new(
        node_type: NodeType,
        executables: HashMap<NodeService, ExecutableSetup>,
        storage_handles: StorageTestHandles,
    ) -> Self {
        let add_tx_http_client = get_executable_by_component(
            node_type,
            &executables,
            ComponentConfigInService::HttpServer,
        )
        .base_app_config
        .get_config()
        .http_server_config
        .as_ref()
        .map(|config| {
            let (ip, port) = config.ip_and_port();
            HttpTestClient::new(SocketAddr::new(ip, port))
        });

        Self { node_type, executables, add_tx_http_client, storage_handles }
    }

    async fn send_rpc_tx_fn(&self, rpc_tx: RpcTransaction) -> TransactionHash {
        self.add_tx_http_client
            .as_ref()
            .expect("Cannot send transactions to a validation-only node: no HTTP server")
            .assert_add_tx_success(rpc_tx)
            .await
    }

    pub fn batcher_monitoring_client(&self) -> &MonitoringClient {
        &self.get_batcher().monitoring_client
    }

    pub fn state_sync_monitoring_client(&self) -> &MonitoringClient {
        &self.get_state_sync().monitoring_client
    }

    pub fn consensus_manager_monitoring_client(&self) -> &MonitoringClient {
        &self.get_consensus_manager().monitoring_client
    }

    pub fn get_executable_by_service(&self, service: NodeService) -> &ExecutableSetup {
        self.executables
            .get(&service)
            .unwrap_or_else(|| panic!("Executable service {service:?} does not exist."))
    }

    pub fn get_executables(&self) -> impl ExactSizeIterator<Item = &ExecutableSetup> {
        self.executables.values()
    }

    fn get_executables_mut(&mut self) -> impl ExactSizeIterator<Item = &mut ExecutableSetup> {
        self.executables.values_mut()
    }

    pub fn generate_simulator_ports_json(&self, path: &str) {
        let (_, http_port) = self
            .get_http_server()
            .get_config()
            .http_server_config
            .as_ref()
            .expect("Should have http server config")
            .ip_and_port();
        let json_data = serde_json::json!({
            HTTP_PORT_ARG: http_port,
            MONITORING_PORT_ARG: self.get_batcher().get_config().monitoring_endpoint_config.as_ref().expect("Should have monitoring endpoint config").port
        });
        serialize_to_file(&json_data, path);
    }

    pub fn get_batcher(&self) -> &ExecutableSetup {
        get_executable_by_component(
            self.node_type,
            &self.executables,
            ComponentConfigInService::Batcher,
        )
    }

    pub fn get_http_server(&self) -> &ExecutableSetup {
        get_executable_by_component(
            self.node_type,
            &self.executables,
            ComponentConfigInService::HttpServer,
        )
    }

    pub fn get_state_sync(&self) -> &ExecutableSetup {
        get_executable_by_component(
            self.node_type,
            &self.executables,
            ComponentConfigInService::StateSync,
        )
    }

    pub fn get_consensus_manager(&self) -> &ExecutableSetup {
        get_executable_by_component(
            self.node_type,
            &self.executables,
            ComponentConfigInService::ConsensusManager,
        )
    }

    fn batcher_storage_reader_server_addr(&self) -> SocketAddr {
        let batcher_config = self
            .get_batcher()
            .get_config()
            .batcher_config
            .as_ref()
            .expect("No executable with a set batcher.");
        let static_config = &batcher_config.static_config.storage_reader_server_static_config;
        SocketAddr::from((static_config.ip, static_config.port))
    }

    pub async fn send_batcher_storage_reader_request(
        &self,
        request: StorageReaderRequest,
    ) -> StorageReaderResponse {
        send_storage_reader_http_request(self.batcher_storage_reader_server_addr(), &request).await
    }

    pub async fn get_global_root_height(&self) -> BlockNumber {
        self.get_marker(MarkerKind::GlobalRoot).await
    }

    pub async fn get_state_marker(&self) -> BlockNumber {
        self.get_marker(MarkerKind::State).await
    }

    async fn get_marker(&self, marker_kind: MarkerKind) -> BlockNumber {
        let response = self
            .send_batcher_storage_reader_request(StorageReaderRequest::Markers(marker_kind))
            .await;
        match response {
            StorageReaderResponse::Markers(block_number) => block_number,
            other => panic!("Expected Markers response, got: {other:?}"),
        }
    }

    pub fn run_service(&self, service: NodeService) -> AbortOnDropHandle<()> {
        let executable_setup = self.get_executable_by_service(service);
        spawn_run_node(
            vec![executable_setup.node_config_path.clone()],
            executable_setup.node_executable_id.clone().into(),
        )
    }

    pub fn run(self) -> RunningNode {
        let executable_handles = self
            .executables
            .iter()
            .map(|(service, executable)| {
                (
                    *service,
                    spawn_run_node(
                        vec![executable.node_config_path.clone()],
                        executable.node_executable_id.clone().into(),
                    ),
                )
            })
            .collect::<HashMap<NodeService, AbortOnDropHandle<()>>>();

        RunningNode { node_setup: self, executable_handles }
    }
    pub fn get_node_index(&self) -> Option<usize> {
        self.get_executables()
            .next()
            .map(|executable| executable.node_executable_id.get_node_index())
    }

    pub fn get_l1_gas_price_scraper_config(&self) -> L1GasPriceScraperConfig {
        get_executable_by_component(
            self.node_type,
            &self.executables,
            ComponentConfigInService::L1GasPriceScraper,
        )
        .get_config()
        .l1_gas_price_scraper_config
        .clone()
        .expect("No executable with a set l1 gas price scraper config.")
    }

    pub fn get_base_layer_config(&self) -> EthereumBaseLayerConfig {
        get_executable_by_component(
            self.node_type,
            &self.executables,
            ComponentConfigInService::BaseLayer,
        )
        .get_config()
        .base_layer_config
        .clone()
        .expect("No executable with a set base layer config.")
    }
}

pub struct RunningNode {
    node_setup: NodeSetup,
    executable_handles: HashMap<NodeService, AbortOnDropHandle<()>>,
}

impl RunningNode {
    async fn await_alive(&self, interval: u64, max_attempts: usize) {
        self.propagate_executable_panic();
        let await_alive_tasks = self.node_setup.get_executables().map(|executable| {
            let result = executable.monitoring_client.await_alive(interval, max_attempts);
            result.unwrap_or_else(|_| {
                panic!("Executable {:?} should be alive.", executable.node_executable_id)
            })
        });

        join_all(await_alive_tasks).await;
    }

    fn propagate_executable_panic(&self) {
        for handle in self.executable_handles.values() {
            // A finished handle implies a running node executable has panicked.
            if handle.is_finished() {
                // Panic, dropping all other handles, which should drop.
                panic!("A running node executable has unexpectedly panicked.");
            }
        }
    }

    pub fn shutdown_service(&mut self, service: NodeService) {
        let handle = self.executable_handles.remove(&service).unwrap_or_else(|| {
            panic!("Service {service:?} does not exist in the running executables map.")
        });
        assert!(!handle.is_finished(), "Handle should still be running.");
        handle.abort();
    }

    pub fn get_node_index(&self) -> usize {
        self.node_setup.get_node_index().unwrap()
    }
}

pub struct IntegrationTestManager {
    node_indices: HashSet<usize>,
    idle_nodes: HashMap<usize, NodeSetup>,
    running_nodes: HashMap<usize, RunningNode>,
    tx_generator: MultiAccountTransactionGenerator,
    // Ethereum base layer coupled with an Anvil server instance, the server is dropped when the
    // instance is dropped.
    anvil_base_layer: AnvilBaseLayer,
}

impl IntegrationTestManager {
    pub async fn new(
        node_descriptors: Vec<NodeDescriptor>,
        custom_paths: Option<CustomPaths>,
        test_unique_id: TestIdentifier,
    ) -> Self {
        let tx_generator = create_integration_test_tx_generator();

        let (sequencers_setup, node_indices) = get_sequencer_setup_configs(
            &tx_generator,
            node_descriptors,
            custom_paths,
            test_unique_id,
        )
        .await;

        let l1_gas_price_scraper_config =
            sequencers_setup.first().unwrap().get_l1_gas_price_scraper_config();
        let anvil_base_layer_config = sequencers_setup.first().unwrap().get_base_layer_config();

        // TODO(guyn): consider saving the port as a part of the base layer config, not just (or
        // instead of) in the url.
        let mut anvil_base_layer = AnvilBaseLayer::new(
            Some(1),
            Some(
                anvil_base_layer_config
                    .ordered_l1_endpoint_urls
                    .first()
                    .unwrap()
                    .peek_secret()
                    .port()
                    .unwrap(),
            ),
        )
        .await;
        // Make sure to update the rest of the config to match what comes from the sequencer setup.
        anvil_base_layer.ethereum_base_layer.config = anvil_base_layer_config;

        // Send some transactions to L1 so it has a history of blocks to scrape gas prices from.
        let num_blocks_needed_on_l1 = l1_gas_price_scraper_config.number_of_blocks_for_mean
            + l1_gas_price_scraper_config.finality;
        anvil_mine_blocks(
            anvil_base_layer.ethereum_base_layer.config.clone(),
            num_blocks_needed_on_l1,
        )
        .await;

        let idle_nodes = create_map(sequencers_setup, |node| node.get_node_index());
        let running_nodes = HashMap::new();

        Self { node_indices, idle_nodes, running_nodes, tx_generator, anvil_base_layer }
    }

    pub fn get_idle_nodes(&self) -> &HashMap<usize, NodeSetup> {
        &self.idle_nodes
    }

    pub fn get_node_type(&self, node_idx: usize) -> NodeType {
        let node_setup = self
            .idle_nodes
            .get(&node_idx)
            .or_else(|| self.running_nodes.get(&node_idx).map(|node| &node.node_setup))
            .unwrap_or_else(|| panic!("Node {node_idx} does not exist in idle or running nodes."));
        node_setup.node_type
    }

    pub fn tx_generator(&self) -> &MultiAccountTransactionGenerator {
        &self.tx_generator
    }

    pub fn tx_generator_mut(&mut self) -> &mut MultiAccountTransactionGenerator {
        &mut self.tx_generator
    }

    pub async fn run_nodes(&mut self, nodes_to_run: HashSet<usize>) {
        info!("Checking that the sequencer node executable is present.");
        get_node_executable_path();
        info!("Running nodes: {nodes_to_run:?}.");

        // TODO(Tsabary): run these in parallel.
        nodes_to_run.into_iter().for_each(|index| {
            let node_setup = self
                .idle_nodes
                .remove(&index)
                .unwrap_or_else(|| panic!("Node {index} does not exist in idle_nodes."));
            info!("Running node {index}.");
            let running_node = node_setup.run();
            assert!(
                self.running_nodes.insert(index, running_node).is_none(),
                "Node {index} is already in the running map."
            );
        });

        // Wait for the nodes to start
        self.await_alive(AWAIT_ALIVE_INTERVAL_MS, AWAIT_ALIVE_ATTEMPTS).await;
    }

    pub async fn run_node_services(
        &mut self,
        nodes_services_to_run: HashMap<usize, Vec<NodeService>>,
    ) {
        get_node_executable_path();
        info!("Rerunning shut-down services for specified nodes: {nodes_services_to_run:?}.");

        // Assert no service is already running before spawning anything. Checking up-front avoids
        // silently overwriting an existing AbortOnDropHandle (which would abort the running
        // service) and avoids spawning any processes when the call is invalid.
        for (&node_index, services) in &nodes_services_to_run {
            let running_node = self
                .running_nodes
                .get(&node_index)
                .unwrap_or_else(|| panic!("Node {node_index} is not in the running map."));
            for &service in services {
                assert!(
                    !running_node.executable_handles.contains_key(&service),
                    "Service {service:?} is already running for node {node_index}."
                );
            }
        }

        // Spawn all services up-front. NodeSetup::run_service only needs &self, so all
        // spawns can be issued before any handle is inserted into the map.
        let new_handles: Vec<(usize, NodeService, AbortOnDropHandle<()>)> = nodes_services_to_run
            .iter()
            .flat_map(|(&node_index, services)| {
                let node_setup = &self
                    .running_nodes
                    .get(&node_index)
                    .unwrap_or_else(|| panic!("Node {node_index} is not in the running map."))
                    .node_setup;
                services
                    .iter()
                    .map(move |&service| (node_index, service, node_setup.run_service(service)))
            })
            .collect();

        for (node_index, service, handle) in new_handles {
            self.running_nodes
                .get_mut(&node_index)
                .unwrap_or_else(|| panic!("Node {node_index} is not in the running map."))
                .executable_handles
                .insert(service, handle);
        }

        // Wait for the rerun executables to start
        self.await_alive(AWAIT_ALIVE_INTERVAL_MS, AWAIT_ALIVE_ATTEMPTS).await;
    }

    pub fn modify_config_idle_nodes<F>(
        &mut self,
        nodes_to_modify_config: HashSet<usize>,
        modify_config_fn: F,
    ) where
        F: Fn(&mut SequencerNodeConfig) + Copy,
    {
        info!("Modifying specified nodes config.");

        nodes_to_modify_config.into_iter().for_each(|node_index| {
            let node_setup = self
                .idle_nodes
                .get_mut(&node_index)
                .unwrap_or_else(|| panic!("Node {node_index} does not exist in idle_nodes."));
            node_setup.get_executables_mut().for_each(|executable| {
                info!("Modifying {} config.", executable.node_executable_id);
                executable.modify_config(modify_config_fn);
            });
        });
    }

    pub fn modify_config_pointers_idle_nodes<F>(
        &mut self,
        nodes_to_modify_config_pointers: HashSet<usize>,
        modify_config_pointers_fn: F,
    ) where
        F: Fn(&mut ConfigPointersMap) + Copy,
    {
        info!("Modifying specified nodes config pointers.");

        nodes_to_modify_config_pointers.into_iter().for_each(|node_index| {
            let node_setup = self
                .idle_nodes
                .get_mut(&node_index)
                .unwrap_or_else(|| panic!("Node {node_index} does not exist in idle_nodes."));
            node_setup.get_executables_mut().for_each(|executable| {
                info!("Modifying {} config pointers.", executable.node_executable_id);
                executable.modify_config_pointers(modify_config_pointers_fn);
            });
        });
    }

    pub async fn await_revert_all_running_nodes(
        &self,
        expected_block_number: BlockNumber,
        timeout_duration: Duration,
        interval_ms: u64,
        max_attempts: usize,
    ) {
        info!("Waiting for all idle nodes to finish reverting.");
        let condition =
            |&latest_block_number: &BlockNumber| latest_block_number == expected_block_number;

        let await_reverted_tasks = self.running_nodes.values().map(|running_node| async {
            let running_node_setup = &running_node.node_setup;
            let batcher_logger = CustomLogger::new(
                TraceLevel::Info,
                Some(format!(
                    "Waiting for batcher to reach block {expected_block_number} in sequencer {}.",
                    running_node_setup.get_node_index().unwrap()
                )),
            );

            // TODO(noamsp): rename batcher index/monitoringClient or use sync
            // index/monitoringClient
            let sync_logger = CustomLogger::new(
                TraceLevel::Info,
                Some(format!(
                    "Waiting for state sync to reach block {expected_block_number} in sequencer \
                     {}.",
                    running_node_setup.get_node_index().unwrap()
                )),
            );

            join!(
                await_batcher_block(
                    interval_ms,
                    condition,
                    max_attempts,
                    running_node_setup.batcher_monitoring_client(),
                    batcher_logger,
                ),
                await_sync_block(
                    interval_ms,
                    condition,
                    max_attempts,
                    running_node_setup.state_sync_monitoring_client(),
                    sync_logger,
                )
            )
        });

        tokio::time::timeout(timeout_duration, join_all(await_reverted_tasks))
            .await
            .expect("Running Nodes should be reverted.");

        info!(
            "All running nodes have been reverted successfully to block number \
             {expected_block_number}."
        );
    }

    pub fn get_node_indices(&self) -> HashSet<usize> {
        self.node_indices.clone()
    }

    pub fn get_running_node_indices(&self) -> HashSet<usize> {
        self.running_nodes.keys().cloned().collect()
    }

    pub fn shutdown_node_services(
        &mut self,
        node_services_to_shutdown: HashMap<usize, Vec<NodeService>>,
    ) {
        node_services_to_shutdown.into_iter().for_each(|(node_index, node_services)| {
            let running_node = self
                .running_nodes
                .get_mut(&node_index)
                .unwrap_or_else(|| panic!("Node {node_index} is not in the running map."));

            for service in node_services {
                running_node.shutdown_service(service);
                info!("Node {node_index} service {service:?} has been shut down.");
            }
        });
    }

    pub async fn shutdown_nodes(&mut self, nodes_to_shutdown: HashSet<usize>) {
        let mut all_handles: Vec<AbortOnDropHandle<()>> = Vec::new();

        for index in nodes_to_shutdown {
            let running_node = self
                .running_nodes
                .remove(&index)
                .unwrap_or_else(|| panic!("Node {index} is not in the running map."));
            // TODO(Tsabary): should this function call `shutdown_node_services` per node as well?
            let RunningNode { node_setup, executable_handles } = running_node;
            let handles: Vec<AbortOnDropHandle<()>> = executable_handles.into_values().collect();
            for handle in &handles {
                assert!(!handle.is_finished(), "Node {index} should still be running.");
                handle.abort();
            }
            assert!(
                self.idle_nodes.insert(index, node_setup).is_none(),
                "Node {index} is already in the idle map."
            );
            info!("Node {index} has been aborted and should shut down soon.");
            all_handles.extend(handles);
        }

        // Wait for all tasks to be cancelled. When each task is cancelled its Child process handle
        // is dropped, which triggers kill_on_drop and sends SIGKILL to the child process.
        let results = tokio::time::timeout(Duration::from_secs(10), join_all(all_handles))
            .await
            .expect("Node tasks did not cancel within timeout.");

        // Assert that all tasks were cancelled. Any shutdown for any other reason should be
        // considered a bug.
        for result in results {
            match result {
                Err(e) if e.is_cancelled() => {}
                Ok(()) => panic!("A node task exited before shutdown — node may have crashed."),
                Err(e) => panic!("A node task failed during shutdown: {e:?}"),
            }
        }
        info!("All nodes have been shut down.");

        // Brief pause to let the OS release ports after SIGKILL before new processes bind them.
        sleep(Duration::from_millis(100)).await;
    }

    pub async fn send_deploy_and_invoke_txs_and_verify(&mut self) {
        self.test_and_verify(
            DeployAndInvokeTxs,
            DEFAULT_SENDER_ACCOUNT,
            BLOCK_TO_WAIT_FOR_DEPLOY_AND_INVOKE,
        )
        .await;
    }

    #[instrument(skip(self))]
    pub async fn send_txs_and_verify(
        &mut self,
        n_invoke_txs: usize,
        n_l1_handler_txs: usize,
        wait_for_block: BlockNumber,
    ) {
        info!(
            "Sending {} invoke + {} l1handler txs and waiting for block {}.",
            n_invoke_txs, n_l1_handler_txs, wait_for_block
        );
        self.test_and_verify(
            ConsensusTxs { n_invoke_txs, n_l1_handler_txs },
            DEFAULT_SENDER_ACCOUNT,
            wait_for_block,
        )
        .await;
        self.rpc_verify_last_block(wait_for_block).await;
    }

    /// Create a simulator that's connected to the http server of a node.
    pub fn create_simulator(&self) -> SequencerSimulator {
        // Always connect to node 0 (the consolidated node) which is never shut down during tests.
        let node_setup = self.get_node_setup(Some(0));
        let http_server = node_setup.get_http_server();
        let (_, http_server_port) = http_server
            .get_config()
            .http_server_config
            .as_ref()
            .expect("No executable with a set http server.")
            .ip_and_port();
        let localhost_url = format!("http://{}", Ipv4Addr::LOCALHOST);
        let monitoring_port = http_server
            .get_config()
            .monitoring_endpoint_config
            .as_ref()
            .expect("Should have a monitoring endpoint config")
            .port;

        SequencerSimulator::new(&localhost_url, http_server_port, &localhost_url, monitoring_port)
    }

    #[instrument(skip(self))]
    pub async fn send_declare_txs_and_verify(&mut self) {
        info!("Sending a declare tx and waiting for block {}.", BLOCK_TO_WAIT_FOR_DECLARE);
        self.test_and_verify(DeclareTx, DEFAULT_SENDER_ACCOUNT, BLOCK_TO_WAIT_FOR_DECLARE).await;
        self.rpc_verify_class_declared(BLOCK_TO_WAIT_FOR_DECLARE).await;
    }

    pub async fn await_txs_accepted_on_all_running_nodes(&mut self, target_n_txs: usize) {
        self.perform_action_on_all_running_nodes(|running_node| {
            let monitoring_client = running_node.node_setup.state_sync_monitoring_client();
            await_txs_accepted(monitoring_client, running_node.get_node_index(), target_n_txs)
        })
        .await;
    }

    /// This function tests and verifies the integration of the transaction flow.
    ///
    /// # Parameters
    /// - `expected_initial_value`: The initial amount of batched transactions. This represents the
    ///   starting state before any transactions are sent.
    /// - `n_txs`: The number of transactions that will be sent during the test. After the test
    ///   completes, the nonce in the batcher's storage is expected to be `expected_initial_value +
    ///   n_txs`.
    /// - `tx_generator`: A transaction generator used to create transactions for testing.
    /// - `sender_account`: The ID of the account sending the transactions.
    /// - `expected_block_number`: The block number up to which execution should be awaited.
    ///
    /// The function verifies the initial state, runs the test with the given number of
    /// transactions, waits for execution to complete, and then verifies the final state.
    pub async fn test_and_verify(
        &mut self,
        test_scenario: impl TestScenario,
        sender_account: AccountId,
        wait_for_block: BlockNumber,
    ) {
        self.verify_txs_accepted_on_all_running_nodes(sender_account).await;
        self.run_integration_test_simulator(&test_scenario, sender_account).await;
        self.await_block_on_all_running_nodes(wait_for_block).await;
        self.verify_txs_accepted_on_all_running_nodes(sender_account).await;
        self.assert_no_reverted_txs_on_all_running_nodes().await;
    }

    async fn await_alive(&self, interval: u64, max_attempts: usize) {
        let await_alive_tasks =
            self.running_nodes.values().map(|node| node.await_alive(interval, max_attempts));

        join_all(await_alive_tasks).await;
    }

    // Get a node setup. If node_index is Some(x), get node x (checking idle first, then running).
    // If node_index is None, get the first available node, preferring idle nodes first.
    fn get_node_setup(&self, node_index: Option<usize>) -> &NodeSetup {
        match node_index {
            Some(index) => self
                .idle_nodes
                .get(&index)
                .or_else(|| self.running_nodes.get(&index).map(|node| &node.node_setup))
                .unwrap_or_else(|| panic!("Node {index} does not exist in idle or running nodes")),
            None => self
                .idle_nodes
                .values()
                .next()
                .or_else(|| self.running_nodes.values().next().map(|node| &node.node_setup))
                .expect("There should be at least one running or idle node"),
        }
    }

    fn get_rpc_server_socket(&self) -> SocketAddr {
        let node_setup = self.get_node_setup(None);

        let state_sync_config =
            node_setup.get_state_sync().get_config().clone().state_sync_config.unwrap();
        SocketAddr::from((
            state_sync_config.static_config.rpc_config.ip,
            state_sync_config.static_config.rpc_config.port,
        ))
    }

    // Verify with JSON RPC server if the last block is the expected one.
    async fn rpc_verify_last_block(&self, expected_block: BlockNumber) {
        info!("Verifying last block number by JSON RPC server.");

        let server_address = self.get_rpc_server_socket();
        let res = send_request(server_address, "starknet_blockNumber", "", "V0_8").await;
        if let Some(block_number) = res.get("result").and_then(|result| result.as_u64()) {
            assert!(
                block_number >= expected_block.0,
                "JSON RPC server -> Block number mismatch: expected greater or equal than {}, got \
                 {}.",
                expected_block.0,
                block_number
            );
        } else {
            info!("JSON RPC server -> Received: {:?}", res);
            panic!(
                "JSON RPC server -> Failed to extract block number: 'result' field is missing or \
                 not a valid u64."
            );
        }
    }

    // Verify with JSON RPC server that class is declare transaction was successful.
    async fn rpc_verify_class_declared(&self, expected_block: BlockNumber) {
        info!("Verifying class declaration by JSON RPC server.");

        let server_address = self.get_rpc_server_socket();
        let declared_contract_class = contract_class();
        let class_hash = declared_contract_class.calculate_class_hash();
        let params = format!(
            r#"{{"block_number": {}}}, "0x{}""#,
            expected_block,
            hex::encode(class_hash.0.to_bytes_be())
        );

        info!(
            "rpc_verify_class_declared: server_addrerss: {}, class_version: {},  params {}",
            server_address, declared_contract_class.contract_class_version, params
        );

        let res = send_request(server_address, "starknet_getClass", params.as_str(), "V0_8").await;
        if let Some(received_contract_class) = res.get("result") {
            let contract_class: SierraContractClass =
                serde_json::from_value(received_contract_class.clone())
                    .expect("Failed to convert received contract class to SierraContractClass");
            assert_eq!(
                contract_class, declared_contract_class,
                "JSON RPC server -> Contract Class mismatch.",
            );
        } else {
            panic!("JSON RPC server -> Failed to get class");
        }
    }

    async fn run_integration_test_simulator(
        &mut self,
        test_scenario: &impl TestScenario,
        sender_account: AccountId,
    ) {
        info!("Running integration test simulator.");
        let chain_id = self.chain_id();
        let send_l1_handler_tx_fn = &mut |l1_handler_tx| {
            send_message_to_l2_and_calculate_tx_hash(
                l1_handler_tx,
                &self.anvil_base_layer,
                &chain_id,
            )
        };
        let send_rpc_tx_fn = &mut |rpc_tx| async {
            let node_0_setup = self
                .idle_nodes
                .get(&0)
                .or_else(|| self.running_nodes.get(&0).map(|node| &node.node_setup))
                .expect("Node 0 should be running.");
            node_0_setup.send_rpc_tx_fn(rpc_tx).await
        };

        send_consensus_txs(
            &mut self.tx_generator,
            sender_account,
            test_scenario,
            send_rpc_tx_fn,
            send_l1_handler_tx_fn,
        )
        .await;
    }

    /// Waits until all running nodes reach the specified block number.
    /// Queries the batcher and state sync metrics to verify progress.
    pub async fn await_block_on_all_running_nodes(&self, expected_block_number: BlockNumber) {
        self.perform_action_on_all_running_nodes(|running_node| {
            let node_setup = &running_node.node_setup;
            let batcher_monitoring_client = node_setup.batcher_monitoring_client();
            let state_sync_monitoring_client = node_setup.state_sync_monitoring_client();
            await_block(
                batcher_monitoring_client,
                state_sync_monitoring_client,
                expected_block_number,
                running_node.get_node_index(),
            )
        })
        .await;
    }

    pub async fn get_consensus_manager_monitoring_client_for_running_node(
        &self,
        node_idx: usize,
    ) -> &MonitoringClient {
        let running_node = self.running_nodes.get(&node_idx).expect("Running node should exist");
        &running_node.node_setup.consensus_manager_monitoring_client()
    }

    pub async fn await_sync_block_on_all_running_nodes(
        &mut self,
        expected_block_number: BlockNumber,
    ) {
        let condition =
            |&latest_block_number: &BlockNumber| latest_block_number >= expected_block_number;

        self.perform_action_on_all_running_nodes(|running_node| async move {
            let node_setup = &running_node.node_setup;
            let monitoring_client = node_setup.batcher_monitoring_client();
            let expected_height = expected_block_number.unchecked_next();

            let logger = CustomLogger::new(
                TraceLevel::Info,
                Some(format!(
                    "Waiting for sync height metric to reach block {expected_height} in sequencer \
                     {}.",
                    running_node.get_node_index(),
                )),
            );
            await_sync_block(5000, condition, 50, monitoring_client, logger).await.unwrap();
        })
        .await;
    }

    async fn verify_txs_accepted_on_all_running_nodes(&self, sender_account: AccountId) {
        // We use state syncs processed txs metric via its monitoring client to verify that the
        // transactions were accepted.
        let account = self.tx_generator.account_with_id(sender_account);
        let expected_n_accepted_account_txs = nonce_to_usize(account.get_nonce());
        let expected_n_l1_handler_txs = self.tx_generator.n_l1_txs();
        let expected_n_accepted_txs = expected_n_accepted_account_txs + expected_n_l1_handler_txs;

        self.perform_action_on_all_running_nodes(|running_node| {
            // We use state syncs processed txs metric via its monitoring client to verify that the
            // transactions were accepted.
            let monitoring_client = running_node.node_setup.state_sync_monitoring_client();
            verify_txs_accepted(
                monitoring_client,
                running_node.get_node_index(),
                expected_n_accepted_txs,
            )
        })
        .await;
    }

    async fn perform_action_on_running_nodes<'a, F, Fut, R>(
        &'a self,
        node_indices: HashSet<usize>,
        f: F,
    ) -> HashMap<usize, R>
    where
        F: Fn(&'a RunningNode) -> Fut,
        Fut: Future<Output = R> + 'a,
    {
        let futures = node_indices.into_iter().map(|node_idx| {
            let running_node =
                self.running_nodes.get(&node_idx).expect("Running node should exist");
            running_node.propagate_executable_panic();
            let fut = f(running_node);
            async move { (node_idx, fut.await) }
        });
        join_all(futures).await.into_iter().collect()
    }

    async fn perform_action_on_all_running_nodes<'a, F, Fut, R>(&'a self, f: F) -> HashMap<usize, R>
    where
        F: Fn(&'a RunningNode) -> Fut,
        Fut: Future<Output = R> + 'a,
    {
        let running_node_indices = self.get_running_node_indices();
        self.perform_action_on_running_nodes(running_node_indices, f).await
    }

    pub fn chain_id(&self) -> ChainId {
        // TODO(Arni): Get the chain ID from a shared canonic location.
        let node_setup = self.get_node_setup(None);

        node_setup
            .get_batcher()
            .get_config()
            .batcher_config
            .as_ref()
            .expect("No executable with a set batcher.")
            .static_config
            .block_builder_config
            .chain_info
            .chain_id
            .clone()
    }

    /// This function returns the number of accepted transactions on the running nodes specified by
    /// the given node indices.
    /// It queries the state sync monitoring client to get the latest value of the processed txs
    /// metric.
    pub async fn get_num_accepted_txs_on_running_nodes(
        &self,
        node_indices: &HashSet<usize>,
    ) -> HashMap<usize, usize> {
        self.perform_action_on_running_nodes(node_indices.clone(), |running_node| async {
            let monitoring_client = running_node.node_setup.state_sync_monitoring_client();
            sequencer_num_accepted_txs(monitoring_client).await
        })
        .await
    }

    /// This function returns the number of accepted transactions on all running nodes.
    pub async fn get_num_accepted_txs_on_all_running_nodes(&self) -> HashMap<usize, usize> {
        self.get_num_accepted_txs_on_running_nodes(&self.get_running_node_indices()).await
    }

    pub async fn assert_no_reverted_txs_on_all_running_nodes(&self) {
        self.perform_action_on_all_running_nodes(|running_node| async move {
            let sequencer_idx = running_node.get_node_index();
            let monitoring_client = running_node.node_setup.batcher_monitoring_client();
            assert_no_reverted_txs(monitoring_client, sequencer_idx).await;
        })
        .await;
    }

    // Verifies that all specified running nodes processed more transactions since the last check.
    // Takes a mutable reference to a mapping of the number of transactions processed by each node
    // at the previous check, and updates it with the current number of transactions.
    // TODO(lev): Use the run_until util fn instead of the loop.
    // TODO(lev): rename to assert/await instead of poll.
    pub async fn poll_running_nodes_received_more_txs(
        &self,
        timeout: Duration,
        node_indices: &HashSet<usize>,
    ) {
        let prev_txs = self.get_num_accepted_txs_on_running_nodes(node_indices).await;

        let start = Instant::now();
        let mut done: bool = false;
        // TODO(lev): remove the done variable by returning if the condition is met, and panicking
        // if timeout is reached.
        while start.elapsed() < timeout && !done {
            sleep(Duration::from_secs(1)).await;
            done = self.check_running_nodes_received_more_txs(&prev_txs, node_indices).await;
        }

        if !done {
            panic!(
                "Not all specified running nodes processed more transactions in the last {} \
                 seconds",
                timeout.as_secs()
            );
        }
    }

    /// Verifies that all running nodes processed more transactions since the last check.
    // TODO(lev): rename to assert/await instead of poll.
    pub async fn poll_all_running_nodes_received_more_txs(&self, timeout: Duration) {
        let node_indices = self.get_running_node_indices();
        self.poll_running_nodes_received_more_txs(timeout, &node_indices).await;
    }

    /// Checks if all specified running nodes have processed more transactions than before.
    async fn check_running_nodes_received_more_txs(
        &self,
        prev_txs: &HashMap<usize, usize>,
        node_indices: &HashSet<usize>,
    ) -> bool {
        let curr_txs = self.get_num_accepted_txs_on_running_nodes(node_indices).await;
        for (node_idx, curr_n_processed) in curr_txs {
            if curr_n_processed <= *prev_txs.get(&node_idx).expect("Num txs not found") {
                return false;
            }
        }
        true
    }

    // TODO(lev): Make a polling function that receives as args a condition function and a timeout.
    // Then we can use it in both poll_... functions.

    /// Verifies that the node with the given index reaches consensus decisions after being
    /// restarted.
    pub async fn poll_node_reaches_consensus_decisions_after_restart(
        &self,
        node_idx: usize,
        timeout: Duration,
    ) {
        let consensus_monitoring_client =
            self.get_consensus_manager_monitoring_client_for_running_node(node_idx).await;
        let prev_decisions_reached =
            get_consensus_decisions_reached(consensus_monitoring_client).await;
        let mut curr_decisions_reached = prev_decisions_reached;
        let start = Instant::now();
        while start.elapsed() < timeout {
            sleep(Duration::from_secs(1)).await;
            // TODO(lev): We should use a more efficient metrics to be sure that restarted node
            // integrated back in reaching consensus.
            curr_decisions_reached =
                get_consensus_decisions_reached(consensus_monitoring_client).await;
            // TODO(lev): Use as_secs_f64 instead of as_secs.
            if curr_decisions_reached > prev_decisions_reached + 1 {
                info!(
                    "Verifying node is reaching consensus decisions after restart finished in {} \
                     seconds",
                    start.elapsed().as_secs()
                );
                return;
            }
        }
        info!(
            "Consensus decisions reached: previous - {}, current - {}",
            prev_decisions_reached, curr_decisions_reached
        );
        panic!(
            "Node {node_idx} did not reach consensus decisions after restart in the last {} \
             seconds",
            timeout.as_secs()
        );
    }

    async fn get_max_state_marker(&self) -> BlockNumber {
        let state_markers: HashMap<usize, BlockNumber> = self
            .perform_action_on_all_running_nodes(|running_node| async move {
                running_node.node_setup.get_state_marker().await
            })
            .await;
        *state_markers.values().max().expect("Should have at least one running node.")
    }

    /// Verifies the block hash calculation flow across all running nodes.
    ///
    /// 1. Determines target block N - uses the provided target block number if provided, otherwise
    ///    uses the max state marker across all running nodes.
    /// 2. Waits for the global root marker to reach N on all running nodes.
    /// 3. Retrieves the block hash of block N-1 from each running node via the storage reader
    ///    server.
    /// 4. Asserts that all running nodes agree on the block hash.
    pub async fn verify_block_hash_across_all_running_nodes(
        &self,
        optional_target_block_number: Option<BlockNumber>,
    ) {
        info!("Verifying block hash flow across all running nodes.");

        // Step 1: Get the max state marker across all running nodes. If a target block number is
        // provided, use it instead of the max state marker.
        let target_block_number = match optional_target_block_number {
            Some(block_number) => block_number,
            None => self.get_max_state_marker().await,
        };
        info!("Target block number: {target_block_number}.");

        // Step 2: Wait for global root marker to cover up to target_block_number on all nodes.
        info!(
            "Waiting for global root marker to reach {target_block_number} on all running nodes."
        );
        self.perform_action_on_all_running_nodes(|running_node| async move {
            let node_index = running_node.get_node_index();
            let mut global_root_height = running_node.node_setup.get_global_root_height().await;
            timeout(TEST_SCENARIO_TIMEOUT, async {
                while global_root_height < target_block_number {
                    sleep(TIME_BETWEEN_CHECKS).await;
                    global_root_height = running_node.node_setup.get_global_root_height().await;
                }
            })
            .await
            .unwrap_or_else(|_| {
                panic!(
                    "Timed out waiting for global root marker to reach {target_block_number} on \
                     sequencer {node_index}. Actual: {global_root_height}."
                )
            });
        })
        .await;

        // Step 3: Get block hash for target_block_number - 1 from each running node via the
        // storage reader server.
        let block_to_check = target_block_number
            .prev()
            .unwrap_or_else(|| panic!("At least one block should exist for hash verification."));
        info!("Verifying block hash for block {block_to_check} across all running nodes.");

        let block_hashes: HashMap<usize, BlockHash> = self
            .perform_action_on_all_running_nodes(|running_node| async move {
                let response = running_node
                    .node_setup
                    .send_batcher_storage_reader_request(StorageReaderRequest::BlockHash(
                        block_to_check,
                    ))
                    .await;
                match response {
                    StorageReaderResponse::BlockHash(block_hash) => block_hash,
                    other => panic!("Expected BlockHash response, got: {other:?}"),
                }
            })
            .await;

        // Step 4: Assert all block hashes are the same.
        let hash_values: Vec<&BlockHash> = block_hashes.values().collect();
        assert!(hash_values.len() >= 2, "Expected at least two nodes.");
        assert!(
            hash_values.windows(2).all(|w| w[0] == w[1]),
            "Not all nodes agree on the block hash for block {block_to_check}: {block_hashes:?}"
        );

        info!(
            "Block hash verification passed for block {block_to_check}. All {} running nodes \
             agree on hash.",
            block_hashes.len()
        );
    }
}

pub fn nonce_to_usize(nonce: Nonce) -> usize {
    let prefixed_hex = nonce.0.to_hex_string();
    let unprefixed_hex = prefixed_hex.split_once("0x").unwrap().1;
    usize::from_str_radix(unprefixed_hex, 16).unwrap()
}

async fn get_sequencer_setup_configs(
    tx_generator: &MultiAccountTransactionGenerator,
    node_descriptors: Vec<NodeDescriptor>,
    custom_paths: Option<CustomPaths>,
    test_unique_id: TestIdentifier,
) -> (Vec<NodeSetup>, HashSet<usize>) {
    let mut available_ports_generator = AvailablePortsGenerator::new(test_unique_id.into());

    let mut node_component_configs = Vec::with_capacity(node_descriptors.len());
    for descriptor in &node_descriptors {
        let mut node_component_config = match descriptor.node_type {
            NodeType::Consolidated => create_consolidated_component_configs(),
            NodeType::Hybrid => create_hybrid_component_configs(&mut available_ports_generator),
            NodeType::Distributed => {
                create_distributed_component_configs(&mut available_ports_generator)
            }
        };
        if descriptor.validation_only {
            for component_config in node_component_config.values_mut() {
                component_config.gateway = ReactiveComponentExecutionConfig::disabled();
                component_config.http_server = ActiveComponentExecutionConfig::disabled();
                component_config.mempool = ReactiveComponentExecutionConfig::disabled();
                component_config.mempool_p2p = ReactiveComponentExecutionConfig::disabled();
            }
        }
        node_component_configs.push((node_component_config, descriptor.node_type));
    }

    info!("Creating node configurations.");
    let is_proof_flow = matches!(test_unique_id, TestIdentifier::ProofFlowIntegrationTest);
    let chain_info =
        if is_proof_flow { proof_flow_chain_info() } else { ChainInfo::create_for_testing() };
    let accounts = tx_generator.accounts();
    let component_configs_len = node_component_configs.len();

    // TODO(Nadin): Refactor to avoid directly mutating vectors

    let mut consensus_manager_ports = available_ports_generator
        .next()
        .expect("Failed to get an AvailablePorts instance for consensus manager configs");

    // TODO(Nadin): pass recorder_url to this function to avoid mutating the resulting configs.
    let can_propose_flags: Vec<bool> =
        node_descriptors.iter().map(|d| !d.validation_only).collect();
    let mut consensus_manager_configs = create_consensus_manager_configs_from_network_configs(
        create_connected_network_configs(
            consensus_manager_ports.get_next_ports(component_configs_len),
        ),
        component_configs_len,
        &chain_info.chain_id,
        &can_propose_flags,
    );

    let node_indices: HashSet<usize> = (0..component_configs_len).collect();

    // TODO(Nadin): define the test storage here and pass it to the create_state_sync_configs and to
    // the ExecutableSetup
    let mut state_sync_ports = available_ports_generator
        .next()
        .expect("Failed to get an AvailablePorts instance for state sync configs");
    let mut state_sync_configs = create_state_sync_configs(
        StorageConfig::default(),
        state_sync_ports.get_next_ports(component_configs_len),
        state_sync_ports.get_next_ports(component_configs_len),
        state_sync_ports.get_next_ports(component_configs_len),
    );

    let mut mempool_p2p_ports = available_ports_generator
        .next()
        .expect("Failed to get an AvailablePorts instance for mempool p2p configs");
    let mut mempool_p2p_configs = create_mempool_p2p_configs(
        chain_info.chain_id.clone(),
        mempool_p2p_ports.get_next_ports(component_configs_len),
    );

    let mut base_layer_ports = available_ports_generator
        .next()
        .expect("Failed to get an AvailablePorts instance for base layer config");
    let base_layer_config =
        AnvilBaseLayer::config(AnvilBaseLayer::url_static(base_layer_ports.get_next_port()));

    let mut nodes = Vec::new();

    // TODO(tsabary): Move these to the start of the test and propagate their values when relevant.
    // All nodes use the same recorder_url and eth_to_strk_oracle_url.
    let (recorder_url, _join_handle) =
        spawn_local_success_recorder(base_layer_ports.get_next_port());
    let (eth_to_strk_oracle_url, _join_handle_eth_to_strk_oracle) =
        spawn_local_eth_to_strk_oracle(base_layer_ports.get_next_port());

    // Create nodes.
    for (node_index, (node_component_config, node_type)) in
        node_component_configs.into_iter().enumerate()
    {
        let mut config_available_ports = available_ports_generator
            .next()
            .expect("Failed to get an AvailablePorts instance for node configs");
        let mut executables = HashMap::new();

        let mut consensus_manager_config = consensus_manager_configs.remove(0);
        let mempool_p2p_config = mempool_p2p_configs.remove(0);
        let state_sync_config = state_sync_configs.remove(0);

        consensus_manager_config.cende_config.recorder_url = recorder_url.clone();
        let eth_to_strk_oracle_config = ExchangeRateOracleConfig {
            url_header_list: Some(vec![eth_to_strk_oracle_url.clone().into()]),
            ..Default::default()
        };
        // Reuse the same dummy oracle endpoint for STRK/USD; the handler returns a constant.
        let strk_to_usd_oracle_config = ExchangeRateOracleConfig {
            url_header_list: Some(vec![eth_to_strk_oracle_url.clone().into()]),
            ..Default::default()
        };

        let validator_id = set_validator_id(&mut consensus_manager_config, node_index);
        let chain_info = chain_info.clone();

        let preset_test_contracts = PresetTestContracts::new();
        let initial_state_diff_commitment = is_proof_flow.then(StateDiffCommitment::default);
        let storage_setup = get_integration_test_storage(
            node_index,
            custom_paths.clone(),
            accounts.to_vec(),
            &chain_info,
            preset_test_contracts,
            initial_state_diff_commitment,
        );

        // Per node, create the executables constituting it.
        for (node_service, executable_component_config) in node_component_config.into_iter() {
            // Set a monitoring endpoint for each executable.
            let monitoring_endpoint_config = MonitoringEndpointConfig {
                port: config_available_ports.get_next_port(),
                ..Default::default()
            };

            let (config, config_pointers_map) = create_node_config(
                &mut config_available_ports,
                chain_info.clone(),
                storage_setup.storage_config.clone(),
                state_sync_config.clone(),
                consensus_manager_config.clone(),
                eth_to_strk_oracle_config.clone(),
                strk_to_usd_oracle_config.clone(),
                mempool_p2p_config.clone(),
                monitoring_endpoint_config,
                executable_component_config.clone(),
                base_layer_config.clone(),
                block_max_capacity_gas(),
                validator_id,
                ALLOW_BOOTSTRAP_TXS,
                node_descriptors[node_index].validation_only,
                !is_proof_flow,
            );

            let base_app_config = DeploymentBaseAppConfig::new(config, config_pointers_map);

            let node_executable_id = NodeExecutableId::new(
                node_index,
                format!("{node_service:?}").to_lowercase().replace(['('], "_").replace([')'], ""),
            );
            let exec_config_path =
                custom_paths.as_ref().and_then(|paths| paths.get_config_path(&node_executable_id));

            executables.insert(
                node_service,
                ExecutableSetup::new(base_app_config, node_executable_id, exec_config_path).await,
            );
        }

        nodes.push(NodeSetup::new(node_type, executables, storage_setup.storage_handles));
    }

    (nodes, node_indices)
}

fn create_map<T, K, F>(items: Vec<T>, key_extractor: F) -> HashMap<K, T>
where
    F: Fn(&T) -> Option<K>,
    K: std::hash::Hash + Eq,
{
    items.into_iter().filter_map(|item| key_extractor(&item).map(|key| (key, item))).collect()
}
