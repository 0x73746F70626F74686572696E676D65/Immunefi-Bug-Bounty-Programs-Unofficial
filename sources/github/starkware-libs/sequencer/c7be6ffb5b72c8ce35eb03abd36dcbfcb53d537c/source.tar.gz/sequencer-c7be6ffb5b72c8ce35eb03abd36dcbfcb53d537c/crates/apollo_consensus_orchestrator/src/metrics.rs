use apollo_metrics::{define_metrics, generate_permutation_labels};
use apollo_transaction_converter::metrics::CONSENSUS_PROOF_MANAGER_STORE_LATENCY;
use strum::{EnumIter, IntoStaticStr, VariantNames};

use crate::build_proposal::BuildProposalFailureReasonLabelValue;
use crate::validate_proposal::ValidateProposalFailureReasonLabelValue;

define_metrics!(
    ConsensusOrchestrator => {
        MetricGauge { CONSENSUS_NUM_BATCHES_IN_PROPOSAL, "consensus_num_batches_in_proposal", "The number of transaction batches in a valid proposal received" },
        MetricGauge { CONSENSUS_NUM_TXS_IN_PROPOSAL, "consensus_num_txs_in_proposal", "The total number of individual transactions in a valid proposal received" },
        MetricCounter { CONSENSUS_PROPOSAL_FIN_MISMATCH, "consensus_proposal_fin_mismatch", "The number of times the proposal fin commitment mismatched the batcher-built commitment", init = 0 },
        // TODO(guyn): remove these 3 metrics.
        MetricCounter { CONSENSUS_ETH_TO_FRI_RATE_MISMATCH, "consensus_eth_to_fri_rate_mismatch", "The number of times the eth to fri rate in a proposal does not match the value expected by this validator", init = 0 },
        MetricCounter { CONSENSUS_L1_GAS_MISMATCH, "consensus_l1_gas_mismatch", "The number of times the L1 gas in a proposal does not match the value expected by this validator", init = 0 },
        MetricCounter { CONSENSUS_L1_DATA_GAS_MISMATCH, "consensus_l1_data_gas_mismatch", "The number of times the L1 data gas in a proposal does not match the value expected by this validator", init = 0 },
        MetricGauge { CONSENSUS_L2_GAS_PRICE, "consensus_l2_gas_price", "The L2 gas price calculated in an accepted proposal" },
        MetricGauge { CONSENSUS_L2_GAS_PRICE_AT_MINIMUM, "consensus_l2_gas_price_at_minimum", "1 when the accepted L2 gas price is clamped at the configured minimum (min_l2_gas_price_per_height, or the versioned-constants min_gas_price fallback), else 0" },
        // Counter, not gauge: a gauge resets to 0 on restart, hiding clamps that already occurred.
        LabeledMetricCounter { CONSENSUS_L2_GAS_PRICE_CLAMPED, "consensus_l2_gas_price_clamped", "Number of times a clamp bound the computed next L2 gas price. `minimum`: the previous price was below the effective minimum, i.e. still ramping up towards the floor. A price at or above the floor is not counted, even when the floor raised it; see consensus_l2_gas_price_at_minimum. `maximum`: bound by the ceiling, including when only the SNIP-35 floor was clipped, in which case the published price can be below the ceiling", init = 0, labels = L2_GAS_PRICE_CLAMP_BOUND },
        MetricCounter { CONSENSUS_L1_GAS_PRICE_PROVIDER_ERROR, "consensus_l1_gas_price_provider_error", "Number of times the context got an error when querying the L1 gas price provider", init=0},
        MetricCounter { CONSENSUS_RETROSPECTIVE_BLOCK_HASH_MISMATCH, "consensus_retrospective_block_hash_mismatch", "Number of times the retrospective block hashes of the state sync and the batcher mismatched", init=0},


        // Cende metrics
        MetricGauge { CENDE_LAST_PREPARED_BLOB_BLOCK_NUMBER, "cende_last_prepared_blob_block_number", "The blob block number that cende knows. That means the sequencer can be the proposer only if the current height is greater by one than this value." },
        MetricHistogram { CENDE_PREPARE_BLOB_FOR_NEXT_HEIGHT_LATENCY, "cende_prepare_blob_for_next_height_latency", "The time it takes to prepare the blob for the next height, i.e create the blob object." },
        // TODO(dvir): consider to differ the case when the blob was already written, that will prevent using the `sequencer_latency_histogram` attribute.
        // TODO(dvir): add a counter for successful blob writes and failed blob writes.
        MetricHistogram { CENDE_WRITE_PREV_HEIGHT_BLOB_LATENCY, "cende_write_prev_height_blob_latency", "Be careful with this metric, if the blob was already written by another request, the latency is much lower since writing to Aerospike is not needed." },
        MetricCounter { CENDE_WRITE_BLOB_SUCCESS , "cende_write_blob_success", "The number of successful blob writes to Aerospike", init = 0 },
        LabeledMetricCounter { CENDE_WRITE_BLOB_FAILURE , "cende_write_blob_failure", "The number of failed blob writes to Aerospike", init = 0, labels = CENDE_WRITE_BLOB_FAILURE_REASON },

        // Proposal build failure metrics
        LabeledMetricCounter { CONSENSUS_BUILD_PROPOSAL_FAILURE , "consensus_build_proposal_failure", "Number of failures while building a proposal", init = 0, labels = BUILD_PROPOSAL_FAILURE_REASON },
        // Proposal validation failure metrics
        LabeledMetricCounter { CONSENSUS_VALIDATE_PROPOSAL_FAILURE , "consensus_validate_proposal_failure", "Number of failures while validating a proposal", init = 0, labels = VALIDATE_PROPOSAL_FAILURE_REASON },

        // SNIP-35 dynamic gas pricing metrics.
        // STRK/USD rate metrics are in `apollo_l1_gas_price`.
        MetricGauge { SNIP35_FEE_ACTUAL_FRI, "snip35_fee_actual_fri", "The current fee_actual (median of recent fee_proposals sliding window), in Fri" },
        MetricGauge { SNIP35_FEE_PROPOSAL_FRI, "snip35_fee_proposal_fri", "The fee_proposal this node published in the latest block, in Fri" },
        MetricGauge { SNIP35_FEE_TARGET_FRI, "snip35_fee_target_fri", "The fee_target computed from the STRK/USD oracle, in Fri" },
        MetricGauge { SNIP35_FEE_TARGET_ATTO_USD, "snip35_fee_target_atto_usd", "Configured target USD cost per L2 gas unit, in atto-USD" },
        // [Temporary comment] The increment site arrives with the fee-proposal band clamp, which
        // is deferred to `main`, so this counter stays at zero on this lineage.
        MetricCounter { SNIP35_FEE_TARGET_ABOVE_MAXIMUM, "snip35_fee_target_above_maximum", "Number of blocks whose oracle-derived fee_target exceeded the L2 gas price maximum. Excludes targets from the override_l2_gas_price_fri operator pin", init = 0 },
    }
);

pub const LABEL_L2_GAS_PRICE_CLAMP_BOUND: &str = "l2_gas_price_clamp_bound";

// Which bound a clamp applied: the effective minimum in force, or the `l2_gas_price_cap` ceiling.
#[derive(IntoStaticStr, EnumIter, VariantNames)]
#[strum(serialize_all = "snake_case")]
pub enum L2GasPriceClampBound {
    Minimum,
    Maximum,
}

generate_permutation_labels! {
    L2_GAS_PRICE_CLAMP_BOUND,
    (LABEL_L2_GAS_PRICE_CLAMP_BOUND, L2GasPriceClampBound),
}

pub(crate) fn record_l2_gas_price_clamped(bound: L2GasPriceClampBound) {
    CONSENSUS_L2_GAS_PRICE_CLAMPED.increment(1, &[(LABEL_L2_GAS_PRICE_CLAMP_BOUND, bound.into())]);
}

pub const LABEL_CENDE_FAILURE_REASON: &str = "cende_write_failure_reason";

#[derive(IntoStaticStr, EnumIter, VariantNames)]
#[strum(serialize_all = "snake_case")]
pub(crate) enum CendeWriteFailureReason {
    CommunicationError,
    CendeRecorderError,
    NoLatestBlockFromRecorder,
    RecorderAheadOfProposalHeight,
    HeightMismatch,
}

generate_permutation_labels! {
    CENDE_WRITE_BLOB_FAILURE_REASON,
    (LABEL_CENDE_FAILURE_REASON, CendeWriteFailureReason),
}

pub(crate) fn record_write_failure(reason: CendeWriteFailureReason) {
    CENDE_WRITE_BLOB_FAILURE.increment(1, &[(LABEL_CENDE_FAILURE_REASON, reason.into())]);
}

// Build proposal failure reasons
pub const LABEL_BUILD_PROPOSAL_FAILURE_REASON: &str = "build_proposal_failure_reason";

generate_permutation_labels! {
    BUILD_PROPOSAL_FAILURE_REASON,
    (LABEL_BUILD_PROPOSAL_FAILURE_REASON, BuildProposalFailureReasonLabelValue),
}

pub(crate) fn record_build_proposal_failure(reason: BuildProposalFailureReasonLabelValue) {
    CONSENSUS_BUILD_PROPOSAL_FAILURE
        .increment(1, &[(LABEL_BUILD_PROPOSAL_FAILURE_REASON, reason.into())]);
}

// Validate proposal failure reasons
pub const LABEL_VALIDATE_PROPOSAL_FAILURE_REASON: &str = "validate_proposal_failure_reason";

generate_permutation_labels! {
    VALIDATE_PROPOSAL_FAILURE_REASON,
    (LABEL_VALIDATE_PROPOSAL_FAILURE_REASON, ValidateProposalFailureReasonLabelValue),
}

pub(crate) fn record_validate_proposal_failure(reason: ValidateProposalFailureReasonLabelValue) {
    CONSENSUS_VALIDATE_PROPOSAL_FAILURE
        .increment(1, &[(LABEL_VALIDATE_PROPOSAL_FAILURE_REASON, reason.into())]);
}

pub(crate) fn register_metrics() {
    CONSENSUS_NUM_BATCHES_IN_PROPOSAL.register();
    CONSENSUS_NUM_TXS_IN_PROPOSAL.register();
    CONSENSUS_PROPOSAL_FIN_MISMATCH.register();
    CONSENSUS_ETH_TO_FRI_RATE_MISMATCH.register();
    CONSENSUS_L1_GAS_MISMATCH.register();
    CONSENSUS_L1_DATA_GAS_MISMATCH.register();
    CONSENSUS_L2_GAS_PRICE.register();
    CONSENSUS_L2_GAS_PRICE_AT_MINIMUM.register();
    CONSENSUS_L2_GAS_PRICE_CLAMPED.register();
    CONSENSUS_L1_GAS_PRICE_PROVIDER_ERROR.register();
    CONSENSUS_RETROSPECTIVE_BLOCK_HASH_MISMATCH.register();
    CENDE_LAST_PREPARED_BLOB_BLOCK_NUMBER.register();
    CENDE_PREPARE_BLOB_FOR_NEXT_HEIGHT_LATENCY.register();
    CENDE_WRITE_PREV_HEIGHT_BLOB_LATENCY.register();
    CENDE_WRITE_BLOB_SUCCESS.register();
    CENDE_WRITE_BLOB_FAILURE.register();
    CONSENSUS_BUILD_PROPOSAL_FAILURE.register();
    CONSENSUS_VALIDATE_PROPOSAL_FAILURE.register();
    CONSENSUS_PROOF_MANAGER_STORE_LATENCY.register();
    SNIP35_FEE_ACTUAL_FRI.register();
    SNIP35_FEE_PROPOSAL_FRI.register();
    SNIP35_FEE_TARGET_FRI.register();
    SNIP35_FEE_TARGET_ATTO_USD.register();
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM.register();
}
