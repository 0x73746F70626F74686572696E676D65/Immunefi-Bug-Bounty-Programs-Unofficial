use std::collections::HashSet;
use std::fs::File;
use std::sync::{Arc, LazyLock};

use apollo_config::dumping::SerializeConfig;
use apollo_config::loading::load_and_process_config;
use apollo_gateway_config::config::{
    GatewayConfig,
    GatewayStaticConfig,
    ProofArchiveWriterConfig,
    StatefulTransactionValidatorConfig,
    StatelessTransactionValidatorConfig,
};
use apollo_gateway_types::deprecated_gateway_error::{
    KnownStarknetErrorCode,
    StarknetError,
    StarknetErrorCode,
};
use apollo_gateway_types::gateway_types::{
    DeclareGatewayOutput,
    DeployAccountGatewayOutput,
    GatewayOutput,
    InvokeGatewayOutput,
};
use apollo_mempool_types::communication::{
    AddTransactionArgsWrapper,
    MempoolClientError,
    MempoolClientResult,
    MockMempoolClient,
};
use apollo_mempool_types::errors::MempoolError;
use apollo_mempool_types::mempool_types::{AccountState, AddTransactionArgs, ValidationArgs};
use apollo_metrics::metrics::HistogramValue;
use apollo_network_types::network_types::BroadcastedMessageMetadata;
use apollo_test_utils::{get_rng, GetTestInstance};
use apollo_transaction_converter::{
    MockTransactionConverterTrait,
    TransactionConverterError,
    TransactionConverterResult,
    VerificationHandle,
};
use blockifier::blockifier::config::ContractClassManagerConfig;
use blockifier::context::ChainInfo;
use blockifier::test_utils::initial_test_state::fund_account;
use blockifier::test_utils::{
    create_valid_proof_facts_for_testing,
    generate_block_hash_storage_updates,
};
use blockifier_test_utils::cairo_versions::{CairoVersion, RunnableCairo1};
use blockifier_test_utils::calldata::create_trivial_calldata;
use blockifier_test_utils::contracts::FeatureContract;
use clap::Command;
use mempool_test_utils::starknet_api_test_utils::{contract_class, declare_tx};
use metrics_exporter_prometheus::PrometheusBuilder;
use mockall::predicate::eq;
use rstest::{fixture, rstest};
use starknet_api::core::{ClassHash, ContractAddress, Nonce};
use starknet_api::executable_transaction::AccountTransaction;
use starknet_api::rpc_transaction::{
    InternalRpcTransaction,
    RpcDeclareTransaction,
    RpcInvokeTransaction,
    RpcTransaction,
    RpcTransactionLabelValue,
};
use starknet_api::test_utils::declare::{
    default_compiled_contract_class,
    DeclareTxArgsWithContractClass,
};
use starknet_api::test_utils::deploy_account::DeployAccountTxArgs;
use starknet_api::test_utils::invoke::{executable_invoke_tx, InvokeTxArgs};
use starknet_api::test_utils::{
    valid_resource_bounds_for_testing,
    TestingTxArgs,
    CHAIN_ID_FOR_TESTS,
    VALID_ACCOUNT_BALANCE,
};
use starknet_api::transaction::fields::{Proof, ProofFacts, TransactionSignature};
use starknet_api::transaction::TransactionHash;
use starknet_api::{
    contract_address,
    declare_tx_args,
    deploy_account_tx_args,
    invoke_tx_args,
    nonce,
};
use starknet_proof_verifier::VerifyProofError;
use starknet_types_core::felt::Felt;
use strum::VariantNames;
use tempfile::TempDir;

use crate::errors::{GatewayResult, StatelessTransactionValidatorError};
use crate::gateway::GenericGateway;
use crate::metrics::{
    register_metrics,
    GatewayMetricHandle,
    SourceLabelValue,
    GATEWAY_ADD_TX_LATENCY,
    GATEWAY_PRIVATE_TRANSACTIONS_RECEIVED,
    GATEWAY_PROOF_ARCHIVE_WRITE_FAILURE,
    GATEWAY_TRANSACTIONS_FAILED,
    GATEWAY_TRANSACTIONS_RECEIVED,
    GATEWAY_TRANSACTIONS_SENT_TO_MEMPOOL,
    LABEL_NAME_SOURCE,
    LABEL_NAME_TX_TYPE,
};
use crate::proof_archive_writer::{MockProofArchiveWriterTrait, ProofArchiveError};
use crate::state_reader_test_utils::{local_test_state_reader_factory, TestStateReaderFactory};
use crate::stateful_transaction_validator::{
    MockStatefulTransactionValidatorFactoryTrait,
    MockStatefulTransactionValidatorTrait,
    StatefulTransactionValidatorFactory,
};
use crate::stateless_transaction_validator::MockStatelessTransactionValidatorTrait;

#[fixture]
fn mock_stateful_transaction_validator() -> MockStatefulTransactionValidatorTrait {
    MockStatefulTransactionValidatorTrait::new()
}

#[fixture]
fn mock_stateful_transaction_validator_factory() -> MockStatefulTransactionValidatorFactoryTrait {
    MockStatefulTransactionValidatorFactoryTrait::new()
}

#[fixture]
fn mock_stateless_transaction_validator() -> MockStatelessTransactionValidatorTrait {
    let mut mock_stateless_transaction_validator = MockStatelessTransactionValidatorTrait::new();
    mock_stateless_transaction_validator.expect_validate().return_once(|_| Ok(()));
    mock_stateless_transaction_validator
}

#[fixture]
fn mock_dependencies() -> MockDependencies {
    let config = GatewayConfig {
        static_config: GatewayStaticConfig {
            stateless_tx_validator_config: StatelessTransactionValidatorConfig::default(),
            stateful_tx_validator_config: StatefulTransactionValidatorConfig::default(),
            contract_class_manager_config: ContractClassManagerConfig::default(),
            chain_info: ChainInfo::create_for_testing(),
            block_declare: false,
            authorized_declarer_accounts: None,
            max_concurrent_declare_compilations: 5,
            proof_archive_writer_config: ProofArchiveWriterConfig::default(),
        },
        ..Default::default()
    };
    let state_reader_factory =
        local_test_state_reader_factory(CairoVersion::Cairo1(RunnableCairo1::Casm), true);
    let mock_mempool_client = MockMempoolClient::new();
    let mock_transaction_converter = MockTransactionConverterTrait::new();
    let mock_stateless_transaction_validator = mock_stateless_transaction_validator();
    let mock_proof_archive_writer = MockProofArchiveWriterTrait::new();
    MockDependencies {
        config,
        state_reader_factory,
        mock_mempool_client,
        mock_transaction_converter,
        mock_stateless_transaction_validator,
        mock_proof_archive_writer,
    }
}

struct MockDependencies {
    config: GatewayConfig,
    state_reader_factory: TestStateReaderFactory,
    mock_mempool_client: MockMempoolClient,
    mock_transaction_converter: MockTransactionConverterTrait,
    mock_stateless_transaction_validator: MockStatelessTransactionValidatorTrait,
    mock_proof_archive_writer: MockProofArchiveWriterTrait,
}

impl MockDependencies {
    fn gateway(
        self,
    ) -> GenericGateway<
        MockStatelessTransactionValidatorTrait,
        MockTransactionConverterTrait,
        StatefulTransactionValidatorFactory<TestStateReaderFactory>,
    > {
        register_metrics();
        GenericGateway::new(
            self.config,
            Arc::new(self.state_reader_factory),
            Arc::new(self.mock_mempool_client),
            Arc::new(self.mock_transaction_converter),
            Arc::new(self.mock_stateless_transaction_validator),
            Arc::new(self.mock_proof_archive_writer),
        )
    }

    fn expect_add_tx(&mut self, args: AddTransactionArgsWrapper, result: MempoolClientResult<()>) {
        self.mock_mempool_client.expect_add_tx().once().with(eq(args)).return_once(|_| result);
    }

    fn expect_validate_tx(&mut self, args: ValidationArgs, result: MempoolClientResult<()>) {
        self.mock_mempool_client.expect_validate_tx().once().with(eq(args)).return_once(|_| result);
    }

    fn expect_store_proof(&mut self, proof_facts: ProofFacts, proof: Proof) {
        self.mock_transaction_converter
            .expect_store_proof_in_proof_manager()
            .once()
            .with(eq(proof_facts), eq(proof))
            .returning(|_, _| Ok(std::time::Duration::ZERO));
    }

    fn expect_set_proof(
        &mut self,
        proof_facts: ProofFacts,
        proof: Proof,
        result: Result<(), ProofArchiveError>,
    ) {
        self.mock_proof_archive_writer
            .expect_set_proof()
            .once()
            .with(eq(proof_facts), eq(proof))
            .return_once(|_, _| result);
    }
}

fn account_contract() -> FeatureContract {
    FeatureContract::AccountWithoutValidations(CairoVersion::Cairo1(RunnableCairo1::Casm))
}

fn invoke_args() -> InvokeTxArgs {
    invoke_args_impl(ProofFacts::default(), Proof::default())
}

fn invoke_args_with_client_side_proving() -> InvokeTxArgs {
    invoke_args_impl(create_valid_proof_facts_for_testing(), Proof::proof_for_testing())
}

fn invoke_args_impl(proof_facts: ProofFacts, proof: Proof) -> InvokeTxArgs {
    let cairo_version = CairoVersion::Cairo1(RunnableCairo1::Casm);
    let test_contract = FeatureContract::TestContract(cairo_version);
    let mut args = invoke_tx_args!(
        resource_bounds: valid_resource_bounds_for_testing(),
        sender_address: account_contract().get_instance_address(0),
        calldata: create_trivial_calldata(test_contract.get_instance_address(0)),
        proof_facts,
        proof,
    );
    let internal_tx = args.get_internal_tx();
    args.tx_hash = internal_tx.tx.calculate_transaction_hash(&CHAIN_ID_FOR_TESTS).unwrap();
    args
}

/// Make a deploy account transaction with a default salt.
fn deploy_account_args() -> DeployAccountTxArgs {
    let mut args = deploy_account_tx_args!(
        class_hash: account_contract().get_class_hash(),
        resource_bounds: valid_resource_bounds_for_testing(),
    );
    let internal_tx = args.get_internal_tx();
    args.tx_hash = internal_tx.tx.calculate_transaction_hash(&CHAIN_ID_FOR_TESTS).unwrap();
    args
}

fn declare_args() -> DeclareTxArgsWithContractClass {
    let contract_class = contract_class();
    let mut args = DeclareTxArgsWithContractClass {
        args: declare_tx_args!(
            signature: TransactionSignature(vec![Felt::ZERO].into()),
            sender_address: account_contract().get_instance_address(0),
            resource_bounds: valid_resource_bounds_for_testing(),
            class_hash: contract_class.calculate_class_hash(),
            compiled_class_hash: default_compiled_contract_class().compiled_class_hash(),
        ),
        contract_class,
    };
    let internal_tx = args.get_internal_tx();
    args.args.tx_hash = internal_tx.tx.calculate_transaction_hash(&CHAIN_ID_FOR_TESTS).unwrap();
    args
}

fn setup_transaction_converter_mock(
    mock_transaction_converter: &mut MockTransactionConverterTrait,
    tx_args: &impl TestingTxArgs,
) {
    let rpc_tx = tx_args.get_rpc_tx();
    let internal_tx = tx_args.get_internal_tx();

    // Create verification handle if the transaction has proof facts.
    let verification_handle = match rpc_tx {
        RpcTransaction::Invoke(RpcInvokeTransaction::V3(ref invoke_tx))
            if !invoke_tx.proof_facts.is_empty() =>
        {
            // Create a simple task that just returns Ok (verification is mocked).
            let verification_task = tokio::spawn(async { Ok(()) });
            Some(VerificationHandle {
                proof_facts: invoke_tx.proof_facts.clone(),
                proof: invoke_tx.proof.clone(),
                verification_task,
            })
        }
        _ => None,
    };

    mock_transaction_converter
        .expect_convert_rpc_tx_to_internal_rpc_tx()
        .once()
        .with(eq(rpc_tx))
        .return_once(move |_| Ok((internal_tx, verification_handle)));

    let internal_tx = tx_args.get_internal_tx();
    let executable_tx = tx_args.get_executable_tx();
    mock_transaction_converter
        .expect_convert_internal_rpc_tx_to_executable_tx()
        .once()
        .with(eq(internal_tx))
        .return_once(move |_| Ok(executable_tx));
}

fn setup_transaction_converter_mock_with_failed_verification(
    mock_transaction_converter: &mut MockTransactionConverterTrait,
    tx_args: &impl TestingTxArgs,
) {
    let rpc_tx = tx_args.get_rpc_tx();
    let internal_tx = tx_args.get_internal_tx();

    // Create verification handle if the transaction has proof facts.
    let verification_handle = match rpc_tx {
        RpcTransaction::Invoke(RpcInvokeTransaction::V3(ref invoke_tx))
            if !invoke_tx.proof_facts.is_empty() =>
        {
            // Create a task that returns a proof verification error.
            let verification_task = tokio::spawn(async {
                Err(TransactionConverterError::ProofVerificationError(
                    VerifyProofError::Verification("test error".to_string()),
                ))
            });
            Some(VerificationHandle {
                proof_facts: invoke_tx.proof_facts.clone(),
                proof: invoke_tx.proof.clone(),
                verification_task,
            })
        }
        _ => None,
    };

    mock_transaction_converter
        .expect_convert_rpc_tx_to_internal_rpc_tx()
        .once()
        .with(eq(rpc_tx))
        .return_once(move |_| Ok((internal_tx, verification_handle)));

    // Note: Unlike in the successful case, we don't set up
    // expect_convert_internal_rpc_tx_to_executable_tx because the verification failure will
    // cause an early return before that conversion happens.
}

fn check_positive_add_tx_result(tx_args: impl TestingTxArgs, result: GatewayOutput) {
    let rpc_tx = tx_args.get_rpc_tx();
    let expected_internal_tx = tx_args.get_internal_tx();
    let tx_hash = expected_internal_tx.tx_hash();
    assert_eq!(
        result,
        match rpc_tx {
            RpcTransaction::Declare(RpcDeclareTransaction::V3(tx)) => {
                GatewayOutput::Declare(DeclareGatewayOutput::new(
                    tx_hash,
                    tx.contract_class.calculate_class_hash(),
                ))
            }
            RpcTransaction::DeployAccount(_) => {
                let address = expected_internal_tx.contract_address();
                GatewayOutput::DeployAccount(DeployAccountGatewayOutput::new(tx_hash, address))
            }
            RpcTransaction::Invoke(_) => GatewayOutput::Invoke(InvokeGatewayOutput::new(tx_hash)),
        }
    );
}

static P2P_MESSAGE_METADATA: LazyLock<Option<BroadcastedMessageMetadata>> =
    LazyLock::new(|| Some(BroadcastedMessageMetadata::get_test_instance(&mut get_rng())));
fn p2p_message_metadata() -> Option<BroadcastedMessageMetadata> {
    P2P_MESSAGE_METADATA.clone()
}

async fn setup_mock_state(
    mock_dependencies: &mut MockDependencies,
    tx_args: &impl TestingTxArgs,
    expected_mempool_result: Result<(), MempoolClientError>,
    expected_proof_archive_result: Result<(), ProofArchiveError>,
    p2p_message_metadata: Option<BroadcastedMessageMetadata>,
) {
    let input_tx = tx_args.get_rpc_tx();
    let expected_internal_tx = tx_args.get_internal_tx();

    setup_transaction_converter_mock(&mut mock_dependencies.mock_transaction_converter, tx_args);

    // Setup state: fund account and store proof block hash if needed.
    let state_reader =
        &mut mock_dependencies.state_reader_factory.state_reader.blockifier_state_reader;
    let address = expected_internal_tx.contract_address();
    fund_account(
        &mock_dependencies.config.static_config.chain_info,
        address,
        VALID_ACCOUNT_BALANCE,
        state_reader,
    );

    let block_hash_state_maps = generate_block_hash_storage_updates();
    state_reader.storage_view.extend(block_hash_state_maps.storage);

    // If the transaction has proof facts, expect set_proof to be called on the proof manager and
    // the proof archive writer (non-P2P transactions only).
    let is_p2p = p2p_message_metadata.is_some();
    let proof_archive_will_succeed = expected_proof_archive_result.is_ok();
    if let RpcTransaction::Invoke(RpcInvokeTransaction::V3(ref invoke_tx)) = input_tx {
        if !invoke_tx.proof_facts.is_empty() {
            mock_dependencies
                .expect_store_proof(invoke_tx.proof_facts.clone(), invoke_tx.proof.clone());
            if !is_p2p {
                mock_dependencies.expect_set_proof(
                    invoke_tx.proof_facts.clone(),
                    invoke_tx.proof.clone(),
                    expected_proof_archive_result,
                );
            }
        }
    }

    let mempool_add_tx_args = AddTransactionArgs {
        tx: expected_internal_tx.clone(),
        account_state: AccountState { address, nonce: *input_tx.nonce() },
    };
    let validation_args = ValidationArgs::from(&mempool_add_tx_args);
    // On the P2P path no GCS write is attempted, so the archive result is irrelevant to whether
    // the tx is forwarded to the mempool.
    if is_p2p || proof_archive_will_succeed {
        mock_dependencies.expect_add_tx(
            AddTransactionArgsWrapper {
                args: mempool_add_tx_args,
                p2p_message_metadata: p2p_message_metadata.clone(),
            },
            expected_mempool_result,
        );
    } else {
        // When archive fails the gateway must not forward the tx to the mempool.
        mock_dependencies.mock_mempool_client.expect_add_tx().never();
    }

    mock_dependencies.expect_validate_tx(validation_args, Ok(()))
}

struct AddTxResults {
    result: GatewayResult<GatewayOutput>,
    metric_handle_for_queries: GatewayMetricHandle,
    metrics: String,
}

async fn run_add_tx_and_extract_metrics(
    mock_dependencies: MockDependencies,
    tx_args: &impl TestingTxArgs,
    p2p_message_metadata: Option<BroadcastedMessageMetadata>,
) -> AddTxResults {
    let recorder = PrometheusBuilder::new().build_recorder();
    let _recorder_guard = metrics::set_default_local_recorder(&recorder);

    let input_tx = tx_args.get_rpc_tx();
    let gateway = mock_dependencies.gateway();
    let result = gateway.add_tx(input_tx.clone(), p2p_message_metadata.clone()).await;

    let metric_handle_for_queries = GatewayMetricHandle::new(&input_tx, &p2p_message_metadata);
    let metrics = recorder.handle().render();

    AddTxResults { result, metric_handle_for_queries, metrics }
}

// Gateway spec errors tests.
// TODO(Arni): Add tests for all the error cases. Check the response (use `into_response` on the
// result of `add_tx`).
// TODO(shahak): Test that when an error occurs in handle_request, then it returns the given p2p
// metadata.
// TODO(AlonH): add test with Some broadcasted message metadata
#[rstest]
#[case::tx_with_duplicate_tx_hash(
    Err(MempoolClientError::MempoolError(MempoolError::DuplicateTransaction { tx_hash: TransactionHash::default() })),
    StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::DuplicatedTransaction)
)]
#[case::tx_with_duplicate_nonce(
    Err(MempoolClientError::MempoolError(MempoolError::DuplicateNonce { address: ContractAddress::default(), nonce: Nonce::default() })),
    StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::InvalidTransactionNonce)
)]
#[case::tx_with_nonce_too_old(
    Err(MempoolClientError::MempoolError(MempoolError::NonceTooOld { address: ContractAddress::default(), tx_nonce: Nonce::default(), account_nonce: nonce!(1) })),
    StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::InvalidTransactionNonce)
)]
#[case::tx_with_nonce_too_large(
    Err(MempoolClientError::MempoolError(MempoolError::NonceTooLarge(Nonce::default()))),
    StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.NONCE_TOO_LARGE".to_string())
)]
#[tokio::test]
async fn test_add_tx_negative(
    mut mock_dependencies: MockDependencies,
    #[values(invoke_args(), deploy_account_args(), declare_args())] tx_args: impl TestingTxArgs,
    #[case] expected_mempool_result: Result<(), MempoolClientError>,
    #[case] expected_error_code: StarknetErrorCode,
) {
    setup_mock_state(
        &mut mock_dependencies,
        &tx_args,
        expected_mempool_result,
        Ok(()),
        p2p_message_metadata(),
    )
    .await;

    let AddTxResults { result, metric_handle_for_queries, metrics } =
        run_add_tx_and_extract_metrics(mock_dependencies, &tx_args, p2p_message_metadata()).await;

    assert_eq!(
        metric_handle_for_queries.get_metric_value(GATEWAY_TRANSACTIONS_RECEIVED, &metrics),
        1
    );
    assert_eq!(
        metric_handle_for_queries.get_metric_value(GATEWAY_TRANSACTIONS_FAILED, &metrics),
        1
    );
    assert_eq!(result.unwrap_err().code, expected_error_code);
}

#[rstest]
#[tokio::test]
async fn test_add_tx_positive(
    mut mock_dependencies: MockDependencies,
    #[values(
        invoke_args(),
        invoke_args_with_client_side_proving(),
        deploy_account_args(),
        declare_args()
    )]
    tx_args: impl TestingTxArgs,
    #[values(None, p2p_message_metadata())] p2p_message_metadata: Option<
        BroadcastedMessageMetadata,
    >,
) {
    setup_mock_state(
        &mut mock_dependencies,
        &tx_args,
        Ok(()),
        Ok(()),
        p2p_message_metadata.clone(),
    )
    .await;

    let AddTxResults { result, metric_handle_for_queries, metrics } =
        run_add_tx_and_extract_metrics(mock_dependencies, &tx_args, p2p_message_metadata).await;

    assert_eq!(
        metric_handle_for_queries.get_metric_value(GATEWAY_TRANSACTIONS_RECEIVED, &metrics),
        1
    );
    assert_eq!(
        metric_handle_for_queries.get_metric_value(GATEWAY_TRANSACTIONS_SENT_TO_MEMPOOL, &metrics),
        1
    );
    check_positive_add_tx_result(tx_args, result.unwrap());
}

#[rstest]
#[tokio::test]
async fn test_add_tx_fails_when_proof_archive_write_fails(mut mock_dependencies: MockDependencies) {
    let tx_args = invoke_args_with_client_side_proving();
    let expected_proof_archive_result: Result<(), ProofArchiveError> =
        Err(ProofArchiveError::WriteError("failed upload".to_string()));
    let p2p_message_metadata: Option<BroadcastedMessageMetadata> = None;
    setup_mock_state(
        &mut mock_dependencies,
        &tx_args,
        Ok(()),
        expected_proof_archive_result,
        p2p_message_metadata,
    )
    .await;

    let AddTxResults { result, metrics, .. } =
        run_add_tx_and_extract_metrics(mock_dependencies, &tx_args, None).await;
    assert!(result.unwrap_err().is_internal());
    assert_eq!(GATEWAY_PROOF_ARCHIVE_WRITE_FAILURE.parse_numeric_metric::<u64>(&metrics), Some(1),);
}

#[rstest]
#[tokio::test]
async fn test_private_transaction_counter(mut mock_dependencies: MockDependencies) {
    let private_tx_args = invoke_args_with_client_side_proving();
    setup_mock_state(&mut mock_dependencies, &private_tx_args, Ok(()), Ok(()), None).await;
    let AddTxResults { metrics, .. } =
        run_add_tx_and_extract_metrics(mock_dependencies, &private_tx_args, None).await;
    assert_eq!(
        GATEWAY_PRIVATE_TRANSACTIONS_RECEIVED.parse_numeric_metric::<u64>(&metrics),
        Some(1)
    );
}

#[rstest]
#[tokio::test]
async fn test_public_transaction_does_not_increment_private_counter(
    mut mock_dependencies: MockDependencies,
) {
    let public_tx_args = invoke_args();
    setup_mock_state(&mut mock_dependencies, &public_tx_args, Ok(()), Ok(()), None).await;
    let AddTxResults { metrics, .. } =
        run_add_tx_and_extract_metrics(mock_dependencies, &public_tx_args, None).await;
    assert_eq!(
        GATEWAY_PRIVATE_TRANSACTIONS_RECEIVED.parse_numeric_metric::<u64>(&metrics),
        Some(0)
    );
}

#[rstest]
#[tokio::test]
async fn test_add_tx_fails_when_proof_verification_fails(mut mock_dependencies: MockDependencies) {
    let tx_args = invoke_args_with_client_side_proving();

    // Setup transaction converter mock that returns a failing verification task.
    setup_transaction_converter_mock_with_failed_verification(
        &mut mock_dependencies.mock_transaction_converter,
        &tx_args,
    );

    // Setup state: fund account and store proof block hash.
    let state_reader =
        &mut mock_dependencies.state_reader_factory.state_reader.blockifier_state_reader;
    let address = tx_args.get_internal_tx().contract_address();
    fund_account(
        &mock_dependencies.config.static_config.chain_info,
        address,
        VALID_ACCOUNT_BALANCE,
        state_reader,
    );

    let block_hash_state_maps = generate_block_hash_storage_updates();
    state_reader.storage_view.extend(block_hash_state_maps.storage);

    // Run add_tx and verify it fails.
    let AddTxResults { result, metric_handle_for_queries, metrics } =
        run_add_tx_and_extract_metrics(mock_dependencies, &tx_args, p2p_message_metadata()).await;

    // Assert the transaction was received but failed.
    assert_eq!(
        metric_handle_for_queries.get_metric_value(GATEWAY_TRANSACTIONS_RECEIVED, &metrics),
        1
    );
    assert_eq!(
        metric_handle_for_queries.get_metric_value(GATEWAY_TRANSACTIONS_FAILED, &metrics),
        1
    );

    // Assert the error is an internal error due to proof verification failure.
    let error = result.unwrap_err();
    assert_eq!(error.code, StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::InvalidProof));
    assert_eq!(error.message, "Proof verification error: Proof verification failed: test error");
}

#[rstest]
#[case::rpc_to_internal_fails(
    Err(TransactionConverterError::ClassNotFound { class_hash: ClassHash::default() }),
    // This value is never used because the first step already fails. Provided a valid executable tx to satisfy the signature.
    Ok(executable_invoke_tx(invoke_args())),
)]
#[case::internal_to_executable_fails(
    Ok((invoke_args().get_internal_tx(), None)),
    Err(TransactionConverterError::ClassNotFound { class_hash: ClassHash::default() })
)]
#[tokio::test]
async fn test_transaction_converter_error(
    #[case] expect_internal_rpc_tx_result: TransactionConverterResult<(
        InternalRpcTransaction,
        Option<VerificationHandle>,
    )>,
    #[case] expect_executable_tx_result: TransactionConverterResult<AccountTransaction>,
    mut mock_dependencies: MockDependencies,
) {
    mock_dependencies.mock_mempool_client.expect_add_tx().never();
    mock_dependencies
        .mock_transaction_converter
        .expect_convert_rpc_tx_to_internal_rpc_tx()
        .return_once(|_| expect_internal_rpc_tx_result);
    mock_dependencies
        .mock_transaction_converter
        .expect_convert_internal_rpc_tx_to_executable_tx()
        .return_once(|_| expect_executable_tx_result);

    let gateway = mock_dependencies.gateway();

    let err = gateway.add_tx(declare_tx(), None).await.unwrap_err();

    // All TransactionConverter errors are mapped to InternalError.
    assert_eq!(
        err.code,
        StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.InternalError".into())
    );
}

#[rstest]
#[tokio::test]
async fn test_block_declare_config(mut mock_dependencies: MockDependencies) {
    mock_dependencies.config.static_config.block_declare = true;
    let gateway = mock_dependencies.gateway();

    let result = gateway.add_tx(declare_tx(), None).await;
    let expected_code = StarknetErrorCode::UnknownErrorCode(
        "StarknetErrorCode.BLOCKED_TRANSACTION_TYPE".to_string(),
    );
    assert_eq!(result.unwrap_err().code, expected_code);
}

#[rstest]
#[tokio::test(flavor = "multi_thread")]
async fn test_declare_compilation_concurrency_limit(mut mock_dependencies: MockDependencies) {
    mock_dependencies.config.static_config.max_concurrent_declare_compilations = 1;

    // Both declares run stateless validation, so replace the fixture's single-call mock with one
    // that accepts repeated calls.
    let mut mock_stateless_transaction_validator = MockStatelessTransactionValidatorTrait::new();
    mock_stateless_transaction_validator.expect_validate().returning(|_| Ok(()));
    mock_dependencies.mock_stateless_transaction_validator = mock_stateless_transaction_validator;

    // The first declare's conversion performs the Sierra-to-CASM compilation while holding the
    // single permit. Make that conversion block so the second declare arrives while the permit is
    // still held: `compilation_started_sender` signals that the permit is held, and the conversion
    // then parks on `release_compilation_receiver` until the test lets it finish.
    let (compilation_started_sender, compilation_started_receiver) =
        tokio::sync::oneshot::channel();
    let (release_compilation_sender, release_compilation_receiver) = std::sync::mpsc::channel();
    mock_dependencies
        .mock_transaction_converter
        .expect_convert_rpc_tx_to_internal_rpc_tx()
        .return_once(move |_| {
            compilation_started_sender.send(()).unwrap();
            release_compilation_receiver.recv().unwrap();
            // Fail the conversion so the first declare short-circuits here instead of running the
            // full admission path; its outcome is irrelevant, so the specific error is arbitrary.
            Err(TransactionConverterError::ClassNotFound { class_hash: ClassHash::default() })
        });

    let gateway = Arc::new(mock_dependencies.gateway());

    // Spawn the first declare and wait until it holds the permit inside compilation.
    let first_declare_task = {
        let gateway = gateway.clone();
        tokio::spawn(async move { gateway.add_tx(declare_tx(), None).await })
    };
    compilation_started_receiver.await.unwrap();

    // The second declare cannot acquire a permit and must be rejected immediately.
    let second_declare_error = gateway.add_tx(declare_tx(), None).await.unwrap_err();
    assert_eq!(
        second_declare_error.code,
        StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::TransactionLimitExceeded)
    );

    // Release the first declare so its task and the blocked worker thread can wind down.
    release_compilation_sender.send(()).unwrap();
    let _ = first_declare_task.await;
}

#[test]
fn test_register_metrics() {
    let recorder = PrometheusBuilder::new().build_recorder();
    let _recorder_guard = metrics::set_default_local_recorder(&recorder);
    register_metrics();
    let metrics = recorder.handle().render();
    for tx_type in RpcTransactionLabelValue::VARIANTS {
        for source in SourceLabelValue::VARIANTS {
            let labels: &[(&str, &str); 2] =
                &[(LABEL_NAME_TX_TYPE, tx_type), (LABEL_NAME_SOURCE, source)];

            // TODO(Tsabary): replace with assert_exists when available.
            assert_eq!(
                GATEWAY_TRANSACTIONS_RECEIVED
                    .parse_numeric_metric::<u64>(&metrics, labels)
                    .unwrap(),
                0
            );
            assert_eq!(
                GATEWAY_TRANSACTIONS_FAILED.parse_numeric_metric::<u64>(&metrics, labels).unwrap(),
                0
            );
            assert_eq!(
                GATEWAY_TRANSACTIONS_SENT_TO_MEMPOOL
                    .parse_numeric_metric::<u64>(&metrics, labels)
                    .unwrap(),
                0
            );
            GATEWAY_ADD_TX_LATENCY.assert_eq(&metrics, &HistogramValue::default());
        }
    }
    assert_eq!(
        GATEWAY_PRIVATE_TRANSACTIONS_RECEIVED.parse_numeric_metric::<u64>(&metrics),
        Some(0)
    );
}

#[rstest]
#[tokio::test]
async fn test_unauthorized_declare_config(mut mock_dependencies: MockDependencies) {
    let authorized_address = contract_address!("0x1");
    mock_dependencies.config.static_config.authorized_declarer_accounts =
        Some(vec![authorized_address]);

    let gateway = mock_dependencies.gateway();
    let rpc_declare_tx = declare_tx();

    // Ensure the sender address is different from the authorized address.
    assert_ne!(
        rpc_declare_tx.calculate_sender_address().unwrap(),
        authorized_address,
        "Sender address should not be authorized"
    );

    let gateway_output_code_error = gateway.add_tx(rpc_declare_tx, None).await.unwrap_err().code;
    let expected_code_error =
        StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::UnauthorizedDeclare);

    assert_eq!(gateway_output_code_error, expected_code_error);
}

#[rstest]
#[case::two_addresses(
    Some(vec![
        contract_address!("0x1"),
        contract_address!("0x2"),
    ])
)]
#[case::one_address(
    Some(vec![
        contract_address!("0x1"),
    ])
)]
#[case::none(None)]
fn test_full_cycle_dump_deserialize_authorized_declarer_accounts(
    #[case] authorized_declarer_accounts: Option<Vec<ContractAddress>>,
) {
    let original_config = GatewayConfig {
        static_config: GatewayStaticConfig { authorized_declarer_accounts, ..Default::default() },
        ..Default::default()
    };

    // Create a temporary file to dump the config.
    let file_path = TempDir::new().unwrap().path().join("config.json");
    original_config.dump_to_file(&vec![], &HashSet::new(), file_path.to_str().unwrap()).unwrap();

    // Load the config from the dumped config file.
    let loaded_config = load_and_process_config::<GatewayConfig>(
        File::open(file_path).unwrap(), // Config file to load.
        Command::new(""),               // Unused CLI context.
        vec![],                         // No override CLI args.
        false,                          // Use schema defaults.
    )
    .unwrap();

    assert_eq!(loaded_config, original_config);
}

#[rstest]
#[case::validate_failure(StarknetErrorCode::KnownErrorCode(
    KnownStarknetErrorCode::ValidateFailure
))]
#[case::invalid_nonce(StarknetErrorCode::KnownErrorCode(
    KnownStarknetErrorCode::InvalidTransactionNonce
))]
#[case::gas_price_too_low(
    StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.GAS_PRICE_TOO_LOW".into())
)]
#[case::internal_error(
    StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.InternalError".into())
)]
#[tokio::test]
async fn add_tx_returns_error_when_extract_state_nonce_and_run_validations_fails(
    #[case] error_code: StarknetErrorCode,
    mut mock_stateful_transaction_validator: MockStatefulTransactionValidatorTrait,
    mut mock_stateful_transaction_validator_factory: MockStatefulTransactionValidatorFactoryTrait,
    mut mock_dependencies: MockDependencies,
) {
    let expected_error = StarknetError {
        code: error_code.clone(),
        message: "placeholder".into(), // Message is not checked
    };

    mock_stateful_transaction_validator
        .expect_extract_state_nonce_and_run_validations()
        .return_once(|_, _| Err(expected_error));

    mock_stateful_transaction_validator_factory
        .expect_instantiate_validator()
        .return_once(|_| Ok(Box::new(mock_stateful_transaction_validator)));

    let tx_args = invoke_args();
    setup_transaction_converter_mock(&mut mock_dependencies.mock_transaction_converter, &tx_args);
    let gateway = GenericGateway::<
        MockStatelessTransactionValidatorTrait,
        MockTransactionConverterTrait,
        MockStatefulTransactionValidatorFactoryTrait,
    > {
        config: Arc::new(mock_dependencies.config),
        stateless_tx_validator: Arc::new(mock_dependencies.mock_stateless_transaction_validator),
        stateful_tx_validator_factory: Arc::new(mock_stateful_transaction_validator_factory),
        mempool_client: Arc::new(mock_dependencies.mock_mempool_client),
        transaction_converter: Arc::new(mock_dependencies.mock_transaction_converter),
        proof_archive_writer: Arc::new(mock_dependencies.mock_proof_archive_writer),
        declare_compilation_semaphore: Arc::new(tokio::sync::Semaphore::new(5)),
    };

    let result = gateway.add_tx(tx_args.get_rpc_tx(), None).await;

    assert!(result.is_err());
    assert_eq!(result.unwrap_err().code, error_code);
}

#[rstest]
#[tokio::test]
async fn stateless_transaction_validator_error(mut mock_dependencies: MockDependencies) {
    let arbitrary_validation_error = Err(StatelessTransactionValidatorError::SignatureTooLong {
        signature_length: 5001,
        max_signature_length: 4000,
    });
    let error_code =
        StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.SIGNATURE_TOO_LONG".into());
    let mut mock_stateless_transaction_validator = MockStatelessTransactionValidatorTrait::new();
    mock_stateless_transaction_validator
        .expect_validate()
        .return_once(|_| arbitrary_validation_error);
    mock_dependencies.mock_stateless_transaction_validator = mock_stateless_transaction_validator;
    let gateway = mock_dependencies.gateway();
    let result = gateway.add_tx(invoke_args().get_rpc_tx(), None).await;

    assert!(result.is_err());
    assert_eq!(result.unwrap_err().code, error_code);
}

#[rstest]
#[tokio::test]
async fn add_tx_returns_error_when_instantiating_validator_fails(
    mut mock_stateful_transaction_validator_factory: MockStatefulTransactionValidatorFactoryTrait,
    mut mock_dependencies: MockDependencies,
) {
    let error_code = StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.InternalError".into());
    let expected_error = StarknetError {
        code: error_code.clone(),
        message: "placeholder".into(), // Message is not checked
    };
    mock_stateful_transaction_validator_factory
        .expect_instantiate_validator()
        .return_once(|_| Err(expected_error));

    let tx_args = invoke_args();
    setup_transaction_converter_mock(&mut mock_dependencies.mock_transaction_converter, &tx_args);
    let gateway = GenericGateway::<
        MockStatelessTransactionValidatorTrait,
        MockTransactionConverterTrait,
        MockStatefulTransactionValidatorFactoryTrait,
    > {
        config: Arc::new(mock_dependencies.config),
        stateless_tx_validator: Arc::new(mock_dependencies.mock_stateless_transaction_validator),
        stateful_tx_validator_factory: Arc::new(mock_stateful_transaction_validator_factory),
        mempool_client: Arc::new(mock_dependencies.mock_mempool_client),
        transaction_converter: Arc::new(mock_dependencies.mock_transaction_converter),
        proof_archive_writer: Arc::new(mock_dependencies.mock_proof_archive_writer),
        declare_compilation_semaphore: Arc::new(tokio::sync::Semaphore::new(5)),
    };

    let result = gateway.add_tx(tx_args.get_rpc_tx(), None).await;

    assert!(result.is_err());
    assert_eq!(result.unwrap_err().code, error_code);
}
