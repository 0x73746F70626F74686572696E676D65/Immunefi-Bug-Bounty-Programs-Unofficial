use std::io::Write;
use std::sync::Arc;

use apollo_gateway_types::communication::{GatewayClientError, MockGatewayClient};
use apollo_gateway_types::deprecated_gateway_error::{
    KnownStarknetErrorCode,
    StarknetError,
    StarknetErrorCode,
};
use apollo_gateway_types::errors::GatewayError;
use apollo_gateway_types::gateway_types::{
    DeclareGatewayOutput,
    DeployAccountGatewayOutput,
    GatewayOutput,
    InvokeGatewayOutput,
};
use apollo_http_server_config::config::HttpServerDynamicConfig;
use apollo_infra::component_client::ClientError;
use apollo_proc_macros::unique_u16;
use axum::body::Bytes;
use axum::response::{IntoResponse, Response};
use axum::{Extension, Json};
use http::StatusCode;
use http_body_util::BodyExt;
use rstest::rstest;
use serde_json::Value;
use starknet_api::test_utils::read_json_file;
use starknet_api::transaction::TransactionHash;
use starknet_api::{class_hash, contract_address, tx_hash};
use starknet_types_core::felt::Felt;
use tokio::sync::watch;
use tracing_test::traced_test;

use crate::errors::HttpServerError;
use crate::http_server::{is_ready, AppState, CLIENT_REGION_HEADER};
use crate::test_utils::{
    deprecated_gateway_declare_tx,
    deprecated_gateway_deploy_account_tx,
    deprecated_gateway_invoke_tx,
    deprecated_gateway_invoke_tx_client_side_proving,
    get_mock_config_manager_client,
    rpc_invoke_tx,
    GatewayTransaction,
    HttpClientServerSetupBuilder,
    TransactionSerialization,
};

const DEPRECATED_GATEWAY_INVOKE_TX_RESPONSE_JSON_PATH: &str =
    "expected_gateway_response/invoke_gateway_output.json";
const DEPRECATED_GATEWAY_DECLARE_TX_RESPONSE_JSON_PATH: &str =
    "expected_gateway_response/declare_gateway_output.json";
const DEPRECATED_GATEWAY_DEPLOY_ACCOUNT_TX_RESPONSE_JSON_PATH: &str =
    "expected_gateway_response/deploy_account_gateway_output.json";

const EXPECTED_TX_HASH: TransactionHash = TransactionHash(Felt::ONE);

// The http_server is oblivious to the GateWayOutput type, so we always return invoke.
fn default_gateway_output() -> GatewayOutput {
    GatewayOutput::Invoke(InvokeGatewayOutput::new(EXPECTED_TX_HASH))
}

#[rstest]
#[case::invoke(
    GatewayOutput::Invoke(InvokeGatewayOutput::new(tx_hash!(1_u64))),
    DEPRECATED_GATEWAY_INVOKE_TX_RESPONSE_JSON_PATH,
)]
#[case::declare(
    GatewayOutput::Declare(DeclareGatewayOutput::new(tx_hash!(1_u64), class_hash!(2_u64))),
    DEPRECATED_GATEWAY_DECLARE_TX_RESPONSE_JSON_PATH,

)]
#[case::deploy_account(
    GatewayOutput::DeployAccount(DeployAccountGatewayOutput::new(
        tx_hash!(1_u64),
        contract_address!(3_u64)
    )),
    DEPRECATED_GATEWAY_DEPLOY_ACCOUNT_TX_RESPONSE_JSON_PATH,
)]
#[tokio::test]
async fn gateway_output_json_conversion(
    #[case] gateway_output: GatewayOutput,
    #[case] expected_serialized_response_path: &str,
) {
    let response = Json(gateway_output).into_response();

    let status_code = response.status();
    let response_bytes = &to_bytes(response).await;

    assert_eq!(status_code, StatusCode::OK, "{response_bytes:?}");
    let gateway_response: GatewayOutput = serde_json::from_slice(response_bytes).unwrap();

    let expected_gateway_response = read_json_file(expected_serialized_response_path);
    assert_eq!(gateway_response, expected_gateway_response);
}

async fn to_bytes(res: Response) -> Bytes {
    res.into_body().collect().await.unwrap().to_bytes()
}

/// Test that an HTTP server with a `allow_new_txs = false` config rejects new transactions.
#[rstest]
#[tokio::test]
async fn allow_new_txs() {
    let tx = rpc_invoke_tx();

    let http_client = HttpClientServerSetupBuilder::new(unique_u16!())
        .with_mock_config_manager_client(get_mock_config_manager_client(false))
        .build()
        .await;

    // Send a transaction to the server.
    let response = http_client.add_tx(tx.clone()).await;
    let status = response.status();
    assert_eq!(status, StatusCode::SERVICE_UNAVAILABLE, "{status:?}");
}

#[tokio::test]
async fn is_ready_reflects_accept_new_txs() {
    let (tx, dynamic_config_rx) =
        watch::channel(HttpServerDynamicConfig { accept_new_txs: true, ..Default::default() });
    let app_state =
        AppState { gateway_client: Arc::new(MockGatewayClient::new()), dynamic_config_rx };

    // Clone AppState to mirror how axum's Extension extractor hands a clone to each request:
    // updates to the watch channel must still be observed through the cloned receiver.
    let (status, _) = is_ready(Extension(app_state.clone())).await;
    assert_eq!(status, StatusCode::OK);

    tx.send(HttpServerDynamicConfig { accept_new_txs: false, ..Default::default() }).unwrap();
    let (status, _) = is_ready(Extension(app_state.clone())).await;
    assert_eq!(status, StatusCode::SERVICE_UNAVAILABLE);

    tx.send(HttpServerDynamicConfig { accept_new_txs: true, ..Default::default() }).unwrap();
    let (status, _) = is_ready(Extension(app_state)).await;
    assert_eq!(status, StatusCode::OK);
}

#[tokio::test]
async fn error_into_response() {
    let error = HttpServerError::DeserializationError(
        serde_json::from_str::<serde_json::Value>("invalid json").unwrap_err(),
    );
    let response = error.into_response();

    let status = response.status();
    let body = to_bytes(response).await;
    let json: Value = serde_json::from_slice(&body).unwrap();

    assert!(!status.is_success(), "{status:?}");
    assert_eq!(
        json.get("code").unwrap(),
        &serde_json::to_value(&KnownStarknetErrorCode::MalformedRequest).unwrap()
    );
}

#[traced_test]
#[rstest]
#[case::add_deprecated_gateway_tx(unique_u16!(), deprecated_gateway_invoke_tx())]
#[case::add_rpc_tx(unique_u16!(), rpc_invoke_tx())]
#[tokio::test]
/// Test that when an add transaction HTTP request is sent to the server, the region of the http
/// request is recorded to the info log.
async fn record_region_test(#[case] index: u16, #[case] tx: impl GatewayTransaction) {
    let mut mock_gateway_client = MockGatewayClient::new();
    // Set the successful response.
    let tx_hash_1 = TransactionHash(Felt::ONE);
    let tx_hash_2 = TransactionHash(Felt::TWO);
    mock_gateway_client
        .expect_add_tx()
        .times(1)
        .return_const(Ok(GatewayOutput::Invoke(InvokeGatewayOutput::new(tx_hash_1))));
    mock_gateway_client
        .expect_add_tx()
        .times(1)
        .return_const(Ok(GatewayOutput::Invoke(InvokeGatewayOutput::new(tx_hash_2))));

    // TODO(Yael): avoid the hardcoded node offset index, consider dynamic allocation.
    let http_client = HttpClientServerSetupBuilder::new(index)
        .with_mock_gateway_client(mock_gateway_client)
        .build()
        .await;

    // Send a transaction to the server, without a region.
    http_client.add_tx(tx.clone()).await;
    assert!(logs_contain(
        format!("Recorded transaction transaction_hash={} region={}", tx_hash_1, "N/A").as_str()
    ));

    // Send transaction to the server, with a region.
    let region = "test";
    http_client.add_tx_with_headers(tx, [(CLIENT_REGION_HEADER, region)]).await;
    assert!(logs_contain(
        format!("Recorded transaction transaction_hash={tx_hash_2} region={region}").as_str()
    ));
}

#[traced_test]
#[rstest]
#[case::add_deprecated_gateway_tx(unique_u16!(), deprecated_gateway_invoke_tx())]
#[case::add_rpc_tx(unique_u16!(), rpc_invoke_tx())]
#[tokio::test]
/// Test that when an "add_tx" HTTP request is sent to the server, and it fails in the Gateway, no
/// record of the region is logged.
async fn record_region_gateway_failing_tx(#[case] index: u16, #[case] tx: impl GatewayTransaction) {
    let mut mock_gateway_client = MockGatewayClient::new();
    // Set the failed response.
    mock_gateway_client.expect_add_tx().times(1).return_const(Err(
        GatewayClientError::ClientError(ClientError::UnexpectedResponse(
            "mock response".to_string(),
        )),
    ));

    let http_client = HttpClientServerSetupBuilder::new(index)
        .with_mock_gateway_client(mock_gateway_client)
        .build()
        .await;

    // Send a transaction to the server.
    http_client.add_tx(tx).await;
    assert!(!logs_contain("Recorded transaction transaction_hash="));
}

#[rstest]
#[case::add_deprecated_gateway_invoke(unique_u16!(), deprecated_gateway_invoke_tx())]
#[case::add_deprecated_gateway_invoke_client_side_proving(
    unique_u16!(),
    deprecated_gateway_invoke_tx_client_side_proving()
)]
#[case::add_deprecated_gateway_deploy_account(unique_u16!(), deprecated_gateway_deploy_account_tx())]
#[case::add_deprecated_gateway_declare(unique_u16!(), deprecated_gateway_declare_tx())]
#[case::add_rpc_invoke(unique_u16!(), rpc_invoke_tx())]
#[tokio::test]
async fn test_response(#[case] index: u16, #[case] tx: impl GatewayTransaction) {
    let mut mock_gateway_client = MockGatewayClient::new();

    // Set the successful response.
    mock_gateway_client.expect_add_tx().times(1).return_const(Ok(default_gateway_output()));

    // Set the failed response.
    let expected_error = StarknetError {
        // The error code needs to be mapped to a BAD_REQUEST response (status code 400).
        code: StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::ClassAlreadyDeclared),
        message: "Arbitrary".to_string(),
    };
    let expected_err_str = serde_json::to_string(&expected_error).unwrap();
    mock_gateway_client.expect_add_tx().times(1).return_const(Err(
        GatewayClientError::GatewayError(GatewayError::DeprecatedGatewayError {
            source: expected_error,
            p2p_message_metadata: None,
        }),
    ));

    let expected_internal_err = GatewayClientError::ClientError(ClientError::UnexpectedResponse(
        "mock response".to_string(),
    ));

    // Set the failed Gateway ClientError response.
    let expected_gateway_client_err_str = serde_json::to_string(
        &StarknetError::internal_with_logging("mock", expected_internal_err.clone()),
    )
    .unwrap();

    mock_gateway_client.expect_add_tx().times(1).return_const(Err(
        // The error code needs to be mapped to a INTERNAL_SERVER_ERROR response (status code 500).
        expected_internal_err,
    ));

    let http_client = HttpClientServerSetupBuilder::new(index)
        .with_mock_gateway_client(mock_gateway_client)
        .build()
        .await;

    // Test a successful response.
    let tx_hash = http_client.assert_add_tx_success(tx.clone()).await;
    assert_eq!(tx_hash, EXPECTED_TX_HASH);

    // Test a failed bad request response.
    let error_str = http_client.assert_add_tx_error(tx.clone(), StatusCode::BAD_REQUEST).await;
    assert_eq!(error_str, expected_err_str);

    // Test a failed internal server error response.
    let error_str = http_client.assert_add_tx_error(tx, StatusCode::INTERNAL_SERVER_ERROR).await;
    assert_eq!(error_str, expected_gateway_client_err_str);
}

#[rstest]
#[case::missing_version(
    unique_u16!(),
    None,
    StarknetError {
        code: StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::MalformedRequest),
        message: "Missing version field".to_string(),
    }
)]
#[case::bad_version(
    unique_u16!(),
    Some("bad version"),
    StarknetError {
        code: StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::MalformedRequest),
        //Note: whitespaces are removed when parsing malformed tx jsons
        message: "Version field is not a valid hex string: badversion".to_string(),
    }
)]
#[case::old_version(
    unique_u16!(),
    Some("0x1"),
    StarknetError {
        code: StarknetErrorCode::KnownErrorCode(
            KnownStarknetErrorCode::InvalidTransactionVersion,
        ),
        message: "Transaction version 1 is not supported. Supported versions: [3].".to_string(),
    },
)]
#[case::newer_version(
    unique_u16!(),
    Some("0x4"),
    StarknetError {
        code: StarknetErrorCode::KnownErrorCode(
            KnownStarknetErrorCode::InvalidTransactionVersion,
        ),
        message: "Transaction version 4 is not supported. Supported versions: [3].".to_string(),
    }
)]
#[tokio::test]
async fn test_unsupported_tx_version(
    #[case] index: u16,
    #[case] version: Option<&str>,
    #[case] expected_err: StarknetError,
) {
    // Set the tx version to the given version.
    let mut tx_json =
        TransactionSerialization(serde_json::to_value(deprecated_gateway_invoke_tx()).unwrap());
    let as_object = tx_json.0.as_object_mut().unwrap();
    if let Some(version) = version {
        as_object.insert("version".to_string(), Value::String(version.to_string())).unwrap();
    } else {
        as_object.remove("version").unwrap();
    }

    let http_client = HttpClientServerSetupBuilder::new(index).build().await;

    let serialized_err = http_client.assert_add_tx_error(tx_json, StatusCode::BAD_REQUEST).await;
    let starknet_error = serde_json::from_str::<StarknetError>(&serialized_err).unwrap();
    assert_eq!(starknet_error, expected_err);
}

#[tokio::test]
async fn sanitizing_error_message() {
    // Set the tx version to be a problematic text.
    let mut tx_json =
        TransactionSerialization(serde_json::to_value(deprecated_gateway_invoke_tx()).unwrap());
    let tx_object = tx_json.0.as_object_mut().unwrap();
    let malicious_version: &'static str =
        "<script>alert(1)\n</script>'`[](){}_!@#$%^&*+=~\"'`[](){}_!@#$%^&*+=~";
    tx_object.insert("version".to_string(), Value::String(malicious_version.to_string())).unwrap();

    let http_client = HttpClientServerSetupBuilder::new(unique_u16!()).build().await;

    let serialized_err = http_client.assert_add_tx_error(tx_json, StatusCode::BAD_REQUEST).await;
    let starknet_error: StarknetError =
        serde_json::from_str(&serialized_err).expect("Expected valid StarknetError JSON");

    assert_eq!(
        starknet_error.code,
        StarknetErrorCode::KnownErrorCode(KnownStarknetErrorCode::MalformedRequest)
    );

    // Make sure the original payload is NOT included directly.
    assert!(
        !starknet_error.message.contains("<script>"),
        "Message should not contain unescaped script tag"
    );

    // Make sure it is escaped correctly.
    assert!(
        starknet_error.message.contains(" script alert(1) n  script ''[](){}_            "),
        "Escaped message not found. This is the returned error message: {}",
        starknet_error.message
    );
}

#[rstest]
#[case::add_deprecated_gateway_tx_happy_flow(
    unique_u16!(), deprecated_gateway_invoke_tx(), 1024, StatusCode::OK
)]
#[case::add_rpc_tx_happy_flow(
    unique_u16!(), rpc_invoke_tx(), 1024, StatusCode::OK
)]
#[case::add_deprecated_gateway_tx_too_large(
    unique_u16!(), deprecated_gateway_invoke_tx(), 16, StatusCode::PAYLOAD_TOO_LARGE
)]
#[case::add_rpc_tx_too_large(
    unique_u16!(), rpc_invoke_tx(), 16, StatusCode::PAYLOAD_TOO_LARGE
)]
#[tokio::test]
async fn request_body_size_limit_enforced(
    #[case] index: u16,
    #[case] tx: impl GatewayTransaction,
    #[case] max_request_body_size: usize,
    #[case] expected_status: StatusCode,
) {
    let mut mock_gateway_client = MockGatewayClient::new();
    if expected_status == StatusCode::OK {
        mock_gateway_client.expect_add_tx().times(1).return_const(Ok(default_gateway_output()));
    }
    let http_client = HttpClientServerSetupBuilder::new(index)
        .with_max_request_body_size(max_request_body_size)
        .with_mock_gateway_client(mock_gateway_client)
        .build()
        .await;
    let response = http_client.add_tx(tx).await;
    assert_eq!(response.status(), expected_status, "Unexpected status: {}", response.status());
}

#[tokio::test]
async fn zstd_compressed_request_decompression() {
    let mut mock_gateway_client = MockGatewayClient::new();
    mock_gateway_client.expect_add_tx().times(1).return_const(Ok(default_gateway_output()));

    let http_client = HttpClientServerSetupBuilder::new(unique_u16!())
        .with_mock_gateway_client(mock_gateway_client)
        .build()
        .await;

    let tx_json = serde_json::to_string(&rpc_invoke_tx()).unwrap();
    let mut encoder = zstd::stream::write::Encoder::new(Vec::new(), 0).unwrap();
    encoder.write_all(tx_json.as_bytes()).unwrap();
    let compressed_body = encoder.finish().unwrap();

    let response = http_client.add_rpc_tx_with_zstd(compressed_body).await;

    assert_eq!(response.status(), StatusCode::OK, "Request should be decompressed and handled");
    let response_body = response.text().await.unwrap();
    let gateway_output: GatewayOutput =
        serde_json::from_str(&response_body).expect("Response should be valid GatewayOutput");
    assert_eq!(gateway_output.transaction_hash(), EXPECTED_TX_HASH);
}

#[tokio::test]
async fn zstd_compressed_request_too_large() {
    let tx_json = serde_json::to_string(&rpc_invoke_tx()).unwrap();
    let mut encoder = zstd::stream::write::Encoder::new(Vec::new(), 0).unwrap();
    encoder.write_all(tx_json.as_bytes()).unwrap();
    let compressed_body = encoder.finish().unwrap();

    let http_client = HttpClientServerSetupBuilder::new(unique_u16!())
        .with_max_request_body_size(compressed_body.len() - 1)
        .build()
        .await;

    let response = http_client.add_rpc_tx_with_zstd(compressed_body).await;

    assert_eq!(response.status(), StatusCode::PAYLOAD_TOO_LARGE);
}

#[tokio::test]
async fn zstd_decompressed_request_too_large() {
    // 10 KB of repeated bytes — compresses to ~50 bytes with zstd.
    let large_body = vec![b'a'; 10 * 1024];
    let mut encoder = zstd::stream::write::Encoder::new(Vec::new(), 0).unwrap();
    encoder.write_all(&large_body).unwrap();
    let compressed_body = encoder.finish().unwrap();

    // Limit between compressed size and decompressed size.
    // compressed_body is ~50 bytes; decompressed is 10240 bytes.
    let max_request_body_size = large_body.len() - 1;
    assert!(compressed_body.len() < max_request_body_size);

    let http_client = HttpClientServerSetupBuilder::new(unique_u16!())
        .with_max_request_body_size(max_request_body_size)
        .build()
        .await;

    let response = http_client.add_rpc_tx_with_zstd(compressed_body).await;

    assert_eq!(response.status(), StatusCode::PAYLOAD_TOO_LARGE);
}
