//! This module contains the configuration for consensus, including the `ConsensusConfig` struct.
//! The configuration includes parameters such as the validator ID, the network topic of the
//! consensus, and the starting block height.

use std::time::Duration;

use apollo_config::converters::{
    deserialize_float_seconds_to_duration,
    deserialize_seconds_to_duration,
    serialize_duration_as_float_seconds,
    serialize_duration_as_seconds,
};
use apollo_protobuf::consensus::DEFAULT_VALIDATOR_ID;
use apollo_storage::db::DbConfig;
use apollo_storage::{StorageConfig, StorageScope};
use serde::{Deserialize, Serialize};
use starknet_api::block::BlockNumber;
use validator::Validate;

use crate::ValidatorId;

#[cfg(test)]
#[path = "config_test.rs"]
mod config_test;

/// Dynamic configuration for consensus that can change at runtime.
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq, Validate)]
pub struct ConsensusDynamicConfig {
    /// The validator ID of the node.
    pub validator_id: ValidatorId,
    /// Timeouts configuration for consensus.
    pub timeouts: TimeoutsConfig,
    /// The duration (seconds) between sync attempts.
    #[serde(
        deserialize_with = "deserialize_float_seconds_to_duration",
        serialize_with = "serialize_duration_as_float_seconds"
    )]
    pub sync_retry_interval: Duration,
    /// Future message limits configuration.
    pub future_msg_limit: FutureMsgLimitsConfig,
    /// If the network tip is more than this many blocks above the node's current height, the node
    /// is considered far behind and keeps syncing instead of proposing. Must be in the range
    /// [5, 1000].
    #[validate(range(min = 5, max = 1000))]
    pub far_behind_proposal_threshold: u64,
    /// When true, require the virtual proposer to have voted in favor before reaching a decision.
    pub require_virtual_proposer_vote: bool,
    /// If set, the node participates in consensus up to and including this height, then stops.
    pub stop_at_height: Option<BlockNumber>,
}

/// Static configuration for consensus that doesn't change during runtime.
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq, Validate)]
pub struct ConsensusStaticConfig {
    /// The delay (seconds) before starting consensus to give time for network peering.
    #[serde(
        deserialize_with = "deserialize_seconds_to_duration",
        serialize_with = "serialize_duration_as_seconds"
    )]
    pub startup_delay: Duration,
    /// Config for the storage used to write/read consensus state.
    #[validate(nested)]
    pub storage_config: StorageConfig,
    /// If true, skips check that we didn't vote on this height.
    pub skip_last_voted_height_check: bool,
}

/// Configuration for consensus containing both static and dynamic configs.
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq, Validate)]
pub struct ConsensusConfig {
    #[validate(nested)]
    pub dynamic_config: ConsensusDynamicConfig,
    #[validate(nested)]
    pub static_config: ConsensusStaticConfig,
}

impl Default for ConsensusDynamicConfig {
    fn default() -> Self {
        Self {
            validator_id: ValidatorId::from(DEFAULT_VALIDATOR_ID),
            timeouts: TimeoutsConfig::default(),
            sync_retry_interval: Duration::from_secs_f64(1.0),
            future_msg_limit: FutureMsgLimitsConfig::default(),
            far_behind_proposal_threshold: 30,
            require_virtual_proposer_vote: false,
            stop_at_height: None,
        }
    }
}

impl Default for ConsensusStaticConfig {
    fn default() -> Self {
        Self {
            startup_delay: Duration::from_secs(5),
            storage_config: StorageConfig {
                db_config: DbConfig {
                    path_prefix: "/data/consensus".into(),
                    enforce_file_exists: false,
                    ..Default::default()
                },
                scope: StorageScope::StateOnly,
                ..Default::default()
            },
            skip_last_voted_height_check: false,
        }
    }
}

impl ConsensusConfig {
    // TODO(Nadin): create a generic trait for this
    pub fn from_parts(
        dynamic_config: ConsensusDynamicConfig,
        static_config: ConsensusStaticConfig,
    ) -> Self {
        Self { dynamic_config, static_config }
    }
}

impl Default for ConsensusConfig {
    fn default() -> Self {
        Self::from_parts(ConsensusDynamicConfig::default(), ConsensusStaticConfig::default())
    }
}

/// A single timeout definition with base, per-round delta, and a maximum duration.
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
pub struct Timeout {
    /// The base timeout (seconds).
    #[serde(
        deserialize_with = "deserialize_float_seconds_to_duration",
        serialize_with = "serialize_duration_as_float_seconds"
    )]
    base: Duration,
    /// The per-round delta added to the timeout (seconds).
    #[serde(
        deserialize_with = "deserialize_float_seconds_to_duration",
        serialize_with = "serialize_duration_as_float_seconds"
    )]
    delta: Duration,
    /// The maximum timeout duration (seconds).
    #[serde(
        deserialize_with = "deserialize_float_seconds_to_duration",
        serialize_with = "serialize_duration_as_float_seconds"
    )]
    max: Duration,
}

impl Timeout {
    pub fn new(base: Duration, delta: Duration, max: Duration) -> Self {
        Self { base, delta, max }
    }
    /// Scale the timeout by the given factor.
    fn scale_by(&mut self, factor: f64) {
        self.base = self.base.mul_f64(factor);
        self.delta = self.delta.mul_f64(factor);
        self.max = self.max.mul_f64(factor);
    }

    /// Compute the timeout for the given round: min(base + round * delta, max).
    fn get_timeout(&self, round: u32) -> Duration {
        (self.base + self.delta.saturating_mul(round)).min(self.max)
    }
}

/// Configuration for consensus timeouts.
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
pub struct TimeoutsConfig {
    /// Proposal timeout configuration.
    proposal: Timeout,
    /// Prevote timeout configuration.
    prevote: Timeout,
    /// Precommit timeout configuration.
    precommit: Timeout,
}

impl Default for TimeoutsConfig {
    fn default() -> Self {
        Self {
            proposal: Timeout {
                base: Duration::from_secs_f64(9.1),
                delta: Duration::from_secs_f64(0.0),
                max: Duration::from_secs_f64(15.0),
            },
            prevote: Timeout {
                base: Duration::from_secs_f64(0.3),
                delta: Duration::from_secs_f64(0.1),
                max: Duration::from_secs_f64(1.0),
            },
            precommit: Timeout {
                base: Duration::from_secs_f64(1.0),
                delta: Duration::from_secs_f64(0.5),
                max: Duration::from_secs_f64(5.0),
            },
        }
    }
}

impl TimeoutsConfig {
    pub fn new(proposal: Timeout, prevote: Timeout, precommit: Timeout) -> Self {
        Self { proposal, prevote, precommit }
    }
    /// Scale all timeouts by the given factor.
    pub fn scale_by(&mut self, factor: f64) {
        self.proposal.scale_by(factor);
        self.prevote.scale_by(factor);
        self.precommit.scale_by(factor);
    }
    pub fn get_proposal_timeout(&self, round: u32) -> Duration {
        self.proposal.get_timeout(round)
    }
    pub fn get_prevote_timeout(&self, round: u32) -> Duration {
        self.prevote.get_timeout(round)
    }
    pub fn get_precommit_timeout(&self, round: u32) -> Duration {
        self.precommit.get_timeout(round)
    }
}

/// Configuration for future message limits.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, Validate, PartialEq)]
pub struct FutureMsgLimitsConfig {
    /// How many heights in the future should we cache.
    pub future_height_limit: u32,
    /// How many rounds in the future (for current height) should we cache.
    pub future_round_limit: u32,
    /// How many rounds should we cache for future heights.
    pub future_height_round_limit: u32,
}

impl Default for FutureMsgLimitsConfig {
    fn default() -> Self {
        Self { future_height_limit: 10, future_round_limit: 10, future_height_round_limit: 1 }
    }
}

/// Configuration for the `StreamHandler`.
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
pub struct StreamHandlerConfig {
    /// The capacity of the channel buffer for stream messages.
    pub channel_buffer_capacity: usize,
    /// The maximum number of peers that can send inbound messages.
    pub max_peers: usize,
    /// The maximum number of streams that can be open at the same time, per peer.
    pub max_streams: usize,
    /// The maximum number of messages for each stream that can be buffered.
    pub max_message_buffer_size: usize,
}

impl Default for StreamHandlerConfig {
    fn default() -> Self {
        Self {
            channel_buffer_capacity: 1000,
            max_peers: 100,
            max_streams: 100,
            max_message_buffer_size: 1000,
        }
    }
}
