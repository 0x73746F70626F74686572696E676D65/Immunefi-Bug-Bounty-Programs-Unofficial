#[cfg(test)]
mod cende_test;
mod central_objects;
#[cfg(any(feature = "testing", test))]
pub mod python_compat;

use std::sync::Arc;

use apollo_class_manager_types::{ClassManagerClientError, SharedClassManagerClient};
use apollo_consensus::types::ProposalCommitment;
use apollo_consensus_orchestrator_config::config::CendeConfig;
use apollo_proc_macros::sequencer_latency_histogram;
use async_trait::async_trait;
use blockifier::abi::constants::STORED_BLOCK_HASH_BUFFER;
use blockifier::blockifier::transaction_executor::CompiledClassHashesForMigration;
use blockifier::blockifier_versioned_constants::VersionedConstants;
use blockifier::bouncer::{BouncerWeights, CasmHashComputationData};
use blockifier::state::accessed_keys::AccessedKeys;
use blockifier::state::cached_state::{CommitmentStateDiff, StateMaps};
use blockifier::transaction::objects::TransactionExecutionInfo;
use central_objects::{
    process_transactions,
    CentralBlockInfo,
    CentralBouncerWeights,
    CentralCasmContractClassEntry,
    CentralCasmHashComputationData,
    CentralCompiledClassHashesForMigration,
    CentralCompressedStateDiff,
    CentralFeeMarketInfo,
    CentralFeeProposalInfo,
    CentralSierraContractClassEntry,
    CentralStateDiff,
    CentralTransactionWritten,
};
use const_format::concatcp;
#[cfg(test)]
use mockall::automock;
use reqwest::Response;
use reqwest_middleware::{ClientBuilder, ClientWithMiddleware, RequestBuilder};
use reqwest_retry::policies::ExponentialBackoff;
use reqwest_retry::{Jitter, RetryTransientMiddleware};
use serde::de::DeserializeOwned;
use serde::{Deserialize, Serialize};
use shared_execution_objects::central_objects::CentralTransactionExecutionInfo;
use starknet_api::block::{BlockHashAndNumber, BlockInfo, BlockNumber, StarknetVersion};
use starknet_api::block_hash::block_hash_calculator::BlockHeaderCommitments;
use starknet_api::consensus_transaction::InternalConsensusTransaction;
use starknet_api::core::ClassHash;
use starknet_api::state::ThinStateDiff;
use starknet_api::transaction::fields::{snos_block_number_from_proof_facts, ProofFacts};
use starknet_api::versioned_constants_logic::VersionedConstantsTrait;
use starknet_committer::patricia_merkle_tree::types::CompressedStateCommitmentInfos;
use tokio::sync::Mutex;
use tokio::task::{self, JoinHandle};
use tracing::{info, warn, Instrument};
use url::Url;

use crate::dynamic_gas_price::FeeProposalInfo;
use crate::fee_market::FeeMarketInfo;
use crate::metrics::{
    record_write_failure,
    CendeWriteFailureReason,
    CENDE_LAST_PREPARED_BLOB_BLOCK_NUMBER,
    CENDE_LAST_STATE_COMMITMENT_INFOS_BLOCK_NUMBER,
    CENDE_PREPARE_BLOB_FOR_NEXT_HEIGHT_LATENCY,
    CENDE_WRITE_BLOB_SUCCESS,
    CENDE_WRITE_PREV_HEIGHT_BLOB_LATENCY,
};

#[derive(thiserror::Error, Debug)]
pub enum CendeAmbassadorError {
    #[error(transparent)]
    ClassManagerError(#[from] ClassManagerClientError),
    #[error("Class of hash: {class_hash} not found")]
    ClassNotFound { class_hash: ClassHash },
    #[error(transparent)]
    StarknetApiError(#[from] starknet_api::StarknetApiError),
    #[error("Recorder request to {path} failed: {message}")]
    RecorderRequestFailed { path: String, message: String },
}

/// Number of recent block hashes to include in the blob.
pub(crate) const N_BLOCK_HASHES_BACK_IN_BLOB: u64 = STORED_BLOCK_HASH_BUFFER;

pub type CendeAmbassadorResult<T> = Result<T, CendeAmbassadorError>;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct StateCommitmentInfosAndNumber {
    pub state_commitment_infos: CompressedStateCommitmentInfos,
    pub block_number: BlockNumber,
}

/// A chunk of all the data to write to Aersopike.
#[cfg_attr(any(feature = "testing", test), derive(Deserialize, PartialEq))]
#[derive(Debug, Serialize)]
pub struct AerospikeBlob {
    block_number: BlockNumber,
    state_diff: CentralStateDiff,
    // The batcher may return a `None` compressed state diff if it is disabled in the
    // configuration.
    compressed_state_diff: Option<CentralCompressedStateDiff>,
    bouncer_weights: CentralBouncerWeights,
    fee_market_info: CentralFeeMarketInfo,
    fee_proposal_info: CentralFeeProposalInfo,
    transactions: Vec<CentralTransactionWritten>,
    execution_infos: Vec<CentralTransactionExecutionInfo>,
    contract_classes: Vec<CentralSierraContractClassEntry>,
    compiled_classes: Vec<CentralCasmContractClassEntry>,
    casm_hash_computation_data_sierra_gas: CentralCasmHashComputationData,
    casm_hash_computation_data_proving_gas: CentralCasmHashComputationData,
    compiled_class_hashes_for_migration: CentralCompiledClassHashesForMigration,
    proposal_commitment: ProposalCommitment,
    parent_proposal_commitment: Option<ProposalCommitment>,
    recent_block_hashes: Vec<BlockHashAndNumber>,
    recent_state_commitment_infos: Vec<StateCommitmentInfosAndNumber>,
    initial_reads: StateMaps,
    block_hash_commitments: BlockHeaderCommitments,
}

#[cfg_attr(test, automock)]
#[async_trait]
pub trait CendeContext: Send + Sync {
    /// Write the previous height blob to Aerospike. Returns a cell with an inner boolean indicating
    /// whether the write was successful.
    /// `current_height` is the height of the block that is built when calling this function.
    /// This function should return false if the previous height blob is not available.
    fn write_prev_height_blob(&self, current_height: BlockNumber) -> JoinHandle<bool>;

    // Prepares the previous height blob that will be written in the next height.
    async fn prepare_blob_for_next_height(
        &self,
        blob_parameters: BlobParameters,
    ) -> CendeAmbassadorResult<()>;

    /// The recorder's commitment infos height offset: the first height whose commitment infos the
    /// recorder has not stored yet.
    /// `Ok(None)` when the recorder has stored nothing; `Err` on query failure.
    async fn commitment_infos_height_offset(&self) -> CendeAmbassadorResult<Option<BlockNumber>>;

    /// Fetches the raw per-block data, from which the caller computes the block's accessed keys.
    /// Returns `None` when the recorder does not have the block.
    async fn get_accessed_keys_input(
        &self,
        block_number: BlockNumber,
    ) -> CendeAmbassadorResult<Option<BlockAccessedKeysData>>;
}

/// The raw per-block data the recorder returns from `get_accessed_keys_input`. The caller computes
/// the block's `AccessedKeys` from this, with data it already holds for a synced block.
#[derive(Debug, Deserialize)]
pub struct BlockAccessedKeysData {
    /// One entry per transaction, in the block's order; empty when the transaction carries no
    /// proof facts. When a transaction includes a client-side proof, its proof facts name the
    /// block whose state the proof is verified against, and the Starknet OS reads that block's
    /// hash from the block hash table; the accessed-keys computation includes the corresponding
    /// block hash table entry.
    pub(crate) proof_facts: Vec<ProofFacts>,
    /// One execution info per transaction.
    pub(crate) execution_infos: Vec<CentralTransactionExecutionInfo>,
}

impl BlockAccessedKeysData {
    /// Computes the block's `AccessedKeys` from the recorder-supplied proof facts and execution
    /// infos, the synced block's `state_diff`, and the latest versioned constants. Mirrors
    /// `AccessedKeys::new`, but sources the call infos from the central execution infos.
    pub fn compute_accessed_keys(&self, state_diff: &CommitmentStateDiff) -> AccessedKeys {
        let proof_facts_block_numbers: Vec<BlockNumber> =
            self.proof_facts.iter().filter_map(snos_block_number_from_proof_facts).collect();
        AccessedKeys::from_call_infos(
            self.execution_infos.iter().flat_map(|execution_info| execution_info.call_info_iter()),
            &proof_facts_block_numbers,
            state_diff,
            VersionedConstants::latest_constants(),
        )
    }
}

#[derive(Clone)]
pub struct CendeAmbassador {
    // TODO(dvir): consider creating enum varaiant instead of the `Option<AerospikeBlob>`.
    // `None` indicates that there is no blob to write, and therefore, the node can't be the
    // proposer.
    prev_height_blob: Arc<Mutex<Option<Arc<AerospikeBlob>>>>,
    write_blob_url: Url,
    get_latest_received_block_url: Url,
    commitment_infos_height_offset_url: Url,
    get_accessed_keys_input_url: Url,
    client: ClientWithMiddleware,
    class_manager: SharedClassManagerClient,
}

/// The endpoint prefix shared by all recorder paths.
const RECORDER_PREFIX: &str = "/cende_recorder";
/// The path to write blob in the Recorder.
pub const RECORDER_WRITE_BLOB_PATH: &str = concatcp!(RECORDER_PREFIX, "/write_blob");
/// The path to get the latest received block from the Recorder (the next block that will be written
/// to DB. returns null when no blocks exist).
pub const RECORDER_GET_LATEST_RECEIVED_BLOCK_PATH: &str =
    concatcp!(RECORDER_PREFIX, "/get_latest_received_block");
/// The path to get the recorder's commitment infos height offset (the first height whose commitment
/// infos the recorder has not stored yet). Returns null when the recorder has stored nothing.
pub const RECORDER_GET_COMMITMENT_INFOS_HEIGHT_OFFSET_PATH: &str =
    concatcp!(RECORDER_PREFIX, "/get_witness_height_offset");
/// The path to fetch accessed keys from the Recorder.
pub const RECORDER_GET_ACCESSED_KEYS_INPUT_PATH: &str =
    concatcp!(RECORDER_PREFIX, "/get_accessed_keys_input");

#[derive(Debug, Deserialize)]
struct BlockNumberResponse {
    block_number: Option<u64>,
}

impl CendeAmbassador {
    pub fn new(cende_config: CendeConfig, class_manager: SharedClassManagerClient) -> Self {
        let retry_policy = ExponentialBackoff::builder()
            .retry_bounds(cende_config.min_retry_interval_ms, cende_config.max_retry_interval_ms)
            .jitter(Jitter::None)
            .build_with_total_retry_duration(cende_config.max_retry_duration_secs);

        CendeAmbassador {
            prev_height_blob: Arc::new(Mutex::new(None)),
            write_blob_url: cende_config
                .recorder_url
                .join(RECORDER_WRITE_BLOB_PATH)
                .expect("Failed to construct write blob URL"),
            get_latest_received_block_url: cende_config
                .recorder_url
                .join(RECORDER_GET_LATEST_RECEIVED_BLOCK_PATH)
                .expect("Failed to construct get latest received block URL"),
            commitment_infos_height_offset_url: cende_config
                .recorder_url
                .join(RECORDER_GET_COMMITMENT_INFOS_HEIGHT_OFFSET_PATH)
                .expect("Failed to construct get commitment infos height offset URL"),
            get_accessed_keys_input_url: cende_config
                .recorder_url
                .join(RECORDER_GET_ACCESSED_KEYS_INPUT_PATH)
                .expect("Failed to construct get accessed keys URL"),
            // Bound each attempt by the max retry interval. Without a per-attempt timeout
            // `RetryTransientMiddleware` only retries attempts that *return* a transient error, so
            // a request that hangs against a slow recorder would block until the build deadline
            // instead of being retried. Capping an attempt at the backoff's upper bound turns such
            // a hang into a timeout error the retry policy can act on, while leaving room for
            // multiple attempts within `max_retry_duration_secs`.
            client: ClientBuilder::new(
                reqwest::Client::builder()
                    .timeout(cende_config.max_retry_interval_ms)
                    .build()
                    .expect("Failed to build cende recorder client"),
            )
            .with(RetryTransientMiddleware::new_with_policy(retry_policy))
            .build(),
            class_manager,
        }
    }
}

/// Returns whether the previous block exists at cende for  the current height.
async fn previous_height_exists_at_cende_recorder(
    client: ClientWithMiddleware,
    url: Url,
    current_height: BlockNumber,
) -> bool {
    // No previous block needed for height 0.
    if current_height == BlockNumber(0) {
        info!("Block 0 has no previous block. Proceeding.");
        return true;
    }

    let latest_received_block =
        match fetch_block_number(&client, &url, RECORDER_GET_LATEST_RECEIVED_BLOCK_PATH).await {
            Ok(block_number) => block_number,
            Err(e) => {
                warn!("Failed to fetch latest received block from recorder: {e}");
                None
            }
        };

    // No latest received block, so no previous block.
    let Some(latest) = latest_received_block else {
        warn!("CENDE_FAILURE: Cende does not have previous block for height {current_height}.");
        record_write_failure(CendeWriteFailureReason::NoLatestBlockFromRecorder);
        return false;
    };

    // Cende has a block at or above the current height, fail the round.
    if latest >= current_height {
        warn!(
            "Cende ahead of proposal height {current_height} (cende at {latest}). Cannot proceed \
             with this round."
        );
        record_write_failure(CendeWriteFailureReason::RecorderAheadOfProposalHeight);
        return false;
    }

    // Has previous block.
    let prev = current_height.prev().unwrap();
    if latest >= prev {
        info!("Cende already has previous block for height {current_height}. Skipping write.");
        return true;
    }

    // Highly unlikely: Cende behind previous block. Warn for debugging, no metric.
    warn!(
        "CENDE_FAILURE: Cende behind prev for height {current_height} (cende latest={latest}). \
         Cannot proceed."
    );
    false
}

/// Sends a GET request to a recorder endpoint that responds with a nullable block number.
async fn fetch_block_number(
    client: &ClientWithMiddleware,
    url: &Url,
    path: &str,
) -> CendeAmbassadorResult<Option<BlockNumber>> {
    let parsed: BlockNumberResponse = send_recorder_get(client.get(url.as_str()), path).await?;
    Ok(parsed.block_number.map(BlockNumber))
}

/// Sends `request` to a recorder GET endpoint and deserializes the JSON body into `T`, mapping
/// transport, non-success status, and parse failures to `RecorderRequestFailed`. `path` is used
/// only for diagnostics.
async fn send_recorder_get<T: DeserializeOwned>(
    request: RequestBuilder,
    path: &str,
) -> CendeAmbassadorResult<T> {
    let recorder_error = |message: String| CendeAmbassadorError::RecorderRequestFailed {
        path: path.to_string(),
        message,
    };

    let response =
        request.send().await.map_err(|e| recorder_error(format!("request failed: {e}")))?;

    if !response.status().is_success() {
        let status = response.status();
        let body = response.text().await.unwrap_or_else(|_| "unparseable".to_string());
        return Err(recorder_error(format!("returned error status {status}: {body}")));
    }

    response.json::<T>().await.map_err(|e| recorder_error(format!("failed to parse response: {e}")))
}

#[async_trait]
impl CendeContext for CendeAmbassador {
    fn write_prev_height_blob(&self, current_height: BlockNumber) -> JoinHandle<bool> {
        info!("Start writing to Aerospike previous height blob for height {current_height}.");

        let prev_height_blob = self.prev_height_blob.clone();
        let request_builder = self.client.post(self.write_blob_url.clone());
        let client = self.client.clone();
        let get_latest_url = self.get_latest_received_block_url.clone();

        task::spawn(
            async move {
                let prev_blob: Option<Arc<AerospikeBlob>> = {
                    let guard = prev_height_blob.lock().await;
                    (*guard).clone()
                };

                let Some(blob) = prev_blob else {
                    return previous_height_exists_at_cende_recorder(
                        client,
                        get_latest_url,
                        current_height,
                    )
                    .await;
                };

                if blob.block_number.0 >= current_height.0 {
                    panic!(
                        "Blob block number is greater than or equal to the current height. That \
                         means cende has a blob of height that hasn't reached a consensus."
                    )
                }

                // Can happen in case the consensus got a block from the state sync and due to that
                // did not update the cende ambassador in `decision_reached` function.
                if blob.block_number.0 + 1 != current_height.0 {
                    warn!(
                        "CENDE_FAILURE: Mismatch blob block number and height, can't write blob \
                         to Aerospike. Blob block number {}, height {current_height}",
                        blob.block_number
                    );
                    record_write_failure(CendeWriteFailureReason::HeightMismatch);
                    return false;
                }

                info!("Writing blob to Aerospike.");
                return send_write_blob(request_builder, blob.as_ref()).await;
            }
            .instrument(tracing::debug_span!("cende write_prev_height_blob height")),
        )
    }

    #[sequencer_latency_histogram(CENDE_PREPARE_BLOB_FOR_NEXT_HEIGHT_LATENCY, false)]
    async fn prepare_blob_for_next_height(
        &self,
        blob_parameters: BlobParameters,
    ) -> CendeAmbassadorResult<()> {
        // TODO(dvir): as optimization, call the `into` and other preperation when writing to AS.
        let block_number = blob_parameters.block_info.block_number;
        *self.prev_height_blob.lock().await = Some(Arc::new(
            AerospikeBlob::from_blob_parameters_and_class_manager(
                blob_parameters,
                self.class_manager.clone(),
            )
            .await?,
        ));
        info!("Blob for block number {block_number} is ready.");
        CENDE_LAST_PREPARED_BLOB_BLOCK_NUMBER.set_lossy(block_number.0);
        Ok(())
    }
    async fn commitment_infos_height_offset(&self) -> CendeAmbassadorResult<Option<BlockNumber>> {
        fetch_block_number(
            &self.client,
            &self.commitment_infos_height_offset_url,
            RECORDER_GET_COMMITMENT_INFOS_HEIGHT_OFFSET_PATH,
        )
        .await
    }

    async fn get_accessed_keys_input(
        &self,
        block_number: BlockNumber,
    ) -> CendeAmbassadorResult<Option<BlockAccessedKeysData>> {
        // The recorder responds with `null` when it has no data stored for the block.
        send_recorder_get(
            self.client
                .get(self.get_accessed_keys_input_url.as_str())
                .query(&[("block_number", block_number.0)]),
            RECORDER_GET_ACCESSED_KEYS_INPUT_PATH,
        )
        .await
    }
}

#[sequencer_latency_histogram(CENDE_WRITE_PREV_HEIGHT_BLOB_LATENCY, false)]
async fn send_write_blob(request_builder: RequestBuilder, blob: &AerospikeBlob) -> bool {
    // TODO(dvir): use compression to reduce the size of the blob in the network.
    match request_builder.json(blob).send().await {
        Ok(response) => {
            if response.status().is_success() {
                info!(
                    "Blob with block number {} and {} transactions was written to Aerospike \
                     successfully.",
                    blob.block_number,
                    blob.transactions.len(),
                );
                print_write_blob_response(response).await;
                CENDE_WRITE_BLOB_SUCCESS.increment(1);
                if let Some(last_state_commitment_infos) = blob.recent_state_commitment_infos.last()
                {
                    CENDE_LAST_STATE_COMMITMENT_INFOS_BLOCK_NUMBER
                        .set_lossy(last_state_commitment_infos.block_number.0);
                }
                true
            } else {
                warn!(
                    "CENDE_FAILURE: The recorder failed to write blob with block number {}. \
                     Status code: {}. Response: {}",
                    blob.block_number,
                    response.status(),
                    response.text().await.unwrap_or("Unparsable response".to_owned()),
                );
                record_write_failure(CendeWriteFailureReason::CendeRecorderError);
                false
            }
        }
        Err(err) => {
            // TODO(dvir): try to test this case.
            warn!("CENDE_FAILURE: Failed to send a request to the recorder. Error: {err}");
            record_write_failure(CendeWriteFailureReason::CommunicationError);
            false
        }
    }
}

async fn print_write_blob_response(response: Response) {
    info!("write blob response status code: {}", response.status());
    if let Ok(text) = response.text().await {
        info!("write blob response text: {text}");
    } else {
        info!("Failed to get response text.");
    }
}

#[derive(Debug)]
pub struct InternalTransactionWithReceipt {
    pub transaction: InternalConsensusTransaction,
    pub execution_info: TransactionExecutionInfo,
}

#[derive(Debug, Default)]
pub struct BlobParameters {
    pub block_info: BlockInfo,
    // The version stamped on the proposal (the replayed network's version in Echonet mode).
    pub starknet_version: StarknetVersion,
    pub state_diff: ThinStateDiff,
    pub compressed_state_diff: Option<CommitmentStateDiff>,
    pub bouncer_weights: BouncerWeights,
    pub fee_market_info: FeeMarketInfo,
    pub fee_proposal_info: FeeProposalInfo,
    pub transactions_with_execution_infos: Vec<InternalTransactionWithReceipt>,
    pub casm_hash_computation_data_sierra_gas: CasmHashComputationData,
    pub casm_hash_computation_data_proving_gas: CasmHashComputationData,
    // TODO(dvir): consider passing the execution_infos from the batcher as a string that
    // serialized in the correct format from the batcher.
    pub compiled_class_hashes_for_migration: CompiledClassHashesForMigration,
    pub proposal_commitment: ProposalCommitment,
    pub parent_proposal_commitment: Option<ProposalCommitment>,
    pub recent_block_hashes: Vec<BlockHashAndNumber>,
    pub recent_state_commitment_infos: Vec<StateCommitmentInfosAndNumber>,
    pub initial_reads: StateMaps,
    pub block_hash_commitments: BlockHeaderCommitments,
}

impl AerospikeBlob {
    pub async fn from_blob_parameters_and_class_manager(
        blob_parameters: BlobParameters,
        class_manager: SharedClassManagerClient,
    ) -> CendeAmbassadorResult<Self> {
        let block_number = blob_parameters.block_info.block_number;
        let block_timestamp = blob_parameters.block_info.block_timestamp.0;

        let block_info =
            CentralBlockInfo::from((blob_parameters.block_info, blob_parameters.starknet_version));
        let state_diff = CentralStateDiff::from((blob_parameters.state_diff, block_info.clone()));
        let compressed_state_diff =
            blob_parameters.compressed_state_diff.map(|compressed_state_diff| {
                CentralStateDiff::from((compressed_state_diff, block_info))
            });

        let (blob_transactions, blob_exec_infos): (
            Vec<InternalConsensusTransaction>,
            Vec<TransactionExecutionInfo>,
        ) = blob_parameters
            .transactions_with_execution_infos
            .into_iter()
            .map(|tx_with_exec_info| {
                (tx_with_exec_info.transaction, tx_with_exec_info.execution_info)
            })
            .unzip();

        let (central_transactions, contract_classes, compiled_classes) =
            process_transactions(class_manager, blob_transactions, block_timestamp).await?;

        let execution_infos =
            blob_exec_infos.into_iter().map(CentralTransactionExecutionInfo::from).collect();

        Ok(AerospikeBlob {
            block_number,
            state_diff,
            compressed_state_diff,
            bouncer_weights: blob_parameters.bouncer_weights.into(),
            fee_market_info: blob_parameters.fee_market_info,
            fee_proposal_info: blob_parameters.fee_proposal_info,
            transactions: central_transactions,
            execution_infos,
            contract_classes,
            compiled_classes,
            casm_hash_computation_data_sierra_gas: blob_parameters
                .casm_hash_computation_data_sierra_gas,
            casm_hash_computation_data_proving_gas: blob_parameters
                .casm_hash_computation_data_proving_gas,
            compiled_class_hashes_for_migration: blob_parameters
                .compiled_class_hashes_for_migration,
            proposal_commitment: blob_parameters.proposal_commitment,
            parent_proposal_commitment: blob_parameters.parent_proposal_commitment,
            recent_block_hashes: blob_parameters.recent_block_hashes,
            recent_state_commitment_infos: blob_parameters.recent_state_commitment_infos,
            initial_reads: blob_parameters.initial_reads,
            block_hash_commitments: blob_parameters.block_hash_commitments,
        })
    }
}
