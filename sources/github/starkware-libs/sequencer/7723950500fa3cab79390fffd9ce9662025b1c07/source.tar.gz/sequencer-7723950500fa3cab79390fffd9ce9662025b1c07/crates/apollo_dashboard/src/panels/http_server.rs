use apollo_http_server::metrics::{
    ADDED_TRANSACTIONS_DEPRECATED_ERROR,
    ADDED_TRANSACTIONS_FAILURE,
    ADDED_TRANSACTIONS_INTERNAL_ERROR,
    ADDED_TRANSACTIONS_SUCCESS,
    ADDED_TRANSACTIONS_TOTAL,
    HTTP_SERVER_ADD_TX_LATENCY,
    LAST_RECEIVED_TRANSACTION_TIMESTAMP_SECONDS,
};
use apollo_metrics::metrics::MetricQueryName;

use crate::dashboard::Row;
use crate::panel::{traffic_light_thresholds, Panel, PanelType, Unit};
use crate::query_builder::{increase, seconds_since_last_timestamp, DEFAULT_DURATION};

fn get_panel_total_transactions_received() -> Panel {
    Panel::new(
        "Transactions Received",
        format!("Number of transactions received ({DEFAULT_DURATION} window)"),
        increase(&ADDED_TRANSACTIONS_TOTAL, DEFAULT_DURATION),
        PanelType::TimeSeries,
    )
    .with_log_query("\"ADD_TX_START\"")
}
fn get_panel_transaction_success_rate() -> Panel {
    // TODO(MatanL): use Panel::ratio_time_series
    Panel::new(
        "Transaction Success Rate",
        format!(
            "The ratio of transactions successfully added to the gateway ({DEFAULT_DURATION} \
             window)",
        ),
        format!(
            "{s} / clamp_min(({s} + {f}), 1)",
            s = increase(&ADDED_TRANSACTIONS_SUCCESS, DEFAULT_DURATION),
            f = increase(&ADDED_TRANSACTIONS_FAILURE, DEFAULT_DURATION),
        ),
        PanelType::TimeSeries,
    )
    .with_unit(Unit::PercentUnit)
    .with_log_query("\"Recorded transaction\"")
}
pub(crate) fn get_panel_http_server_transactions_received_rate() -> Panel {
    Panel::new(
        "HTTP Server Transactions Received Rate (TPS)",
        "The rate of transactions received by the HTTP Server (1m window)",
        format!("rate({}[1m])", ADDED_TRANSACTIONS_TOTAL.get_name_with_filter()),
        PanelType::TimeSeries,
    )
}
pub(crate) fn get_panel_http_server_added_transactions_success_rate() -> Panel {
    Panel::new(
        "HTTP Server Added Transactions Success Rate (TPS)",
        "The rate of successfully added transactions to the HTTP Servers combined (1m window)",
        format!("sum(rate({}[1m]))", ADDED_TRANSACTIONS_SUCCESS.get_name_with_filter()),
        PanelType::TimeSeries,
    )
}
fn get_panel_http_add_tx_latency() -> Panel {
    Panel::from_hist(
        &HTTP_SERVER_ADD_TX_LATENCY,
        "HTTP Server Add Tx Latency",
        "The time it takes to add a transaction to the HTTP Server",
    )
    .with_unit(Unit::Seconds)
}

fn get_panel_transactions_failed_by_reason() -> Panel {
    Panel::new(
        "Transactions Failed to Be Added (By Reason)",
        "Number of transactions that failed to be added by reason (10m window)",
        vec![
            format!(
                "sum(increase({}[10m]))",
                ADDED_TRANSACTIONS_INTERNAL_ERROR.get_name_with_filter()
            ),
            format!(
                "sum(increase({}[10m]))",
                ADDED_TRANSACTIONS_DEPRECATED_ERROR.get_name_with_filter()
            ),
        ],
        PanelType::TimeSeries,
    )
    .with_legends(vec!["internal error", "deprecated error"])
}

pub(crate) fn get_panel_http_server_seconds_since_last_transaction() -> Panel {
    Panel::new(
        "Seconds Since Last Received Transaction",
        "The number of seconds since the last transaction was received by the HTTP server \
         (assuming there was a transaction in the last 12 hours)",
        seconds_since_last_timestamp(&LAST_RECEIVED_TRANSACTION_TIMESTAMP_SECONDS),
        PanelType::TimeSeries,
    )
    .with_unit(Unit::Seconds)
    .with_absolute_thresholds(traffic_light_thresholds(10.0, 60.0))
}

pub(crate) fn get_http_server_row() -> Row {
    Row::new(
        "HTTP Server",
        vec![
            get_panel_http_server_transactions_received_rate(),
            get_panel_total_transactions_received(),
            get_panel_transaction_success_rate(),
            get_panel_transactions_failed_by_reason(),
            get_panel_http_add_tx_latency(),
            get_panel_http_server_seconds_since_last_transaction(),
        ],
    )
}
