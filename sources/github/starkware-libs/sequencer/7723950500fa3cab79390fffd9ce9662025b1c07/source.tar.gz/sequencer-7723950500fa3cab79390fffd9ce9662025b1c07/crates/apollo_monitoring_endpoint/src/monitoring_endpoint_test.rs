use std::collections::HashMap;
use std::net::IpAddr;
use std::sync::Arc;
use std::thread::sleep;
use std::time::Duration;

use apollo_infra::metrics::{metrics_recorder, MetricsConfig};
use apollo_l1_events_types::{L1EventsProviderSnapshot, MockL1EventsProviderClient};
use apollo_mempool_types::communication::MockMempoolClient;
use apollo_mempool_types::mempool_types::{
    MempoolSnapshot,
    MempoolStateSnapshot,
    TransactionQueueSnapshot,
};
use apollo_monitoring_endpoint_config::config::{
    MonitoringEndpointConfig,
    MONITORING_ENDPOINT_DEFAULT_IP,
    MONITORING_ENDPOINT_DEFAULT_PORT,
    MONITORING_ENDPOINT_DEFAULT_SNAPSHOT_TIMEOUT_MILLIS,
};
use axum::response::Response;
use axum::Router;
use http::StatusCode;
use http_body_util::BodyExt;
use hyper_util::client::legacy::Client;
use hyper_util::rt::TokioExecutor;
use metrics::{counter, describe_counter};
use pretty_assertions::assert_eq;
use serde_json::{from_slice, to_value, Value};
use starknet_api::block::{BlockNumber, GasPrice};
use starknet_api::core::{ContractAddress, Nonce};
use starknet_api::{nonce, tx_hash};
use tokio::spawn;
use tokio::task::yield_now;
use tower::util::ServiceExt;

use crate::monitoring_endpoint::{
    create_monitoring_endpoint,
    get_l1_events_provider_snapshot,
    mempool_snapshot,
    MonitoringEndpoint,
    ALIVE,
    L1_EVENTS_PROVIDER_SNAPSHOT,
    MEMPOOL_SNAPSHOT,
    METRICS,
    READY,
    SET_LOG_LEVEL,
    VERSION,
};
use crate::test_utils::{build_post_request, build_request};

const TEST_VERSION: &str = "1.2.3-dev";
const SNAPSHOT_TIMEOUT_MILLIS: u64 = 10;
const SNAPSHOT_TASK_TIME: u64 = SNAPSHOT_TIMEOUT_MILLIS * 50; // Should be longer than the timeout.

// Note: the metrics recorder is installed globally, causing tests to conflict when run in parallel.
// Most tests do not require it, and as such, use the following disabling config.
const CONFIG_WITHOUT_METRICS: MonitoringEndpointConfig = MonitoringEndpointConfig {
    ip: MONITORING_ENDPOINT_DEFAULT_IP,
    port: MONITORING_ENDPOINT_DEFAULT_PORT,
    snapshot_timeout_millis: MONITORING_ENDPOINT_DEFAULT_SNAPSHOT_TIMEOUT_MILLIS,
};

fn setup_monitoring_endpoint(config: Option<MonitoringEndpointConfig>) -> MonitoringEndpoint {
    let config = config.unwrap_or(CONFIG_WITHOUT_METRICS);
    create_monitoring_endpoint(config, TEST_VERSION, None, None, None)
}

async fn request_app(app: Router, method: &str) -> Response {
    app.oneshot(build_request(&IpAddr::from([0, 0, 0, 0]), 0, method)).await.unwrap()
}

async fn request_post_app(app: Router, method: &str) -> Response {
    app.oneshot(build_post_request(&IpAddr::from([0, 0, 0, 0]), 0, method)).await.unwrap()
}

#[tokio::test]
async fn node_version() {
    let response = request_app(setup_monitoring_endpoint(None).app(), VERSION).await;
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    assert_eq!(&body[..], TEST_VERSION.as_bytes());
}

#[tokio::test]
async fn alive_endpoint() {
    let response = request_app(setup_monitoring_endpoint(None).app(), ALIVE).await;
    assert_eq!(response.status(), StatusCode::OK);
}

#[tokio::test]
async fn ready_endpoint() {
    let response = request_app(setup_monitoring_endpoint(None).app(), READY).await;
    assert_eq!(response.status(), StatusCode::OK);
}

#[tokio::test]
async fn set_log_level_valid() {
    let app = setup_monitoring_endpoint(None).app();
    let crate_name = "apollo_monitoring_endpoint";
    let level = "debug";
    let method = format!("{SET_LOG_LEVEL}/{crate_name}/{level}");
    let response = request_post_app(app, &method).await;
    assert_eq!(response.status(), StatusCode::OK);
}

#[tokio::test]
async fn set_log_level_invalid_level() {
    let app = setup_monitoring_endpoint(None).app();
    let crate_name = "apollo_monitoring_endpoint";
    let invalid_level = "foobar";
    let method = format!("{SET_LOG_LEVEL}/{crate_name}/{invalid_level}");
    let response = request_post_app(app, &method).await;
    assert_eq!(response.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn with_metrics() {
    let config = MonitoringEndpointConfig::default();
    let metrics_config = MetricsConfig { collect_metrics: true, collect_profiling_metrics: false };
    let prometheus_handle = metrics_recorder(metrics_config);
    let app = create_monitoring_endpoint(config, TEST_VERSION, prometheus_handle, None, None).app();

    // Register a metric.
    let metric_name = "metric_name";
    let metric_help = "metric_help";
    let metric_value = 8224;
    counter!(metric_name).absolute(metric_value);
    describe_counter!(metric_name, metric_help);
    let response = request_app(app, METRICS).await;
    assert_eq!(response.status(), StatusCode::OK);
    let body_bytes = response.into_body().collect().await.unwrap().to_bytes();
    let body_string = String::from_utf8(body_bytes.to_vec()).unwrap();
    let expected_prefix = format!(
        "# HELP {metric_name} {metric_help}\n# TYPE {metric_name} counter\n{metric_name} \
         {metric_value}\n\n"
    );
    assert!(
        body_string.contains(&expected_prefix),
        "body_string: {body_string}, expected_prefix: {expected_prefix}"
    );
}

#[tokio::test]
async fn without_metrics() {
    let app = setup_monitoring_endpoint(None).app();
    let response = request_app(app, METRICS).await;
    assert_eq!(response.status(), StatusCode::METHOD_NOT_ALLOWED);
}

#[tokio::test]
async fn endpoint_as_server() {
    spawn(async move { setup_monitoring_endpoint(None).run().await });
    yield_now().await;

    let MonitoringEndpointConfig { ip, port, .. } = MonitoringEndpointConfig::default();

    let client = Client::builder(TokioExecutor::new()).build_http();

    let response = client.request(build_request(&ip, port, VERSION)).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    assert_eq!(&body[..], TEST_VERSION.as_bytes());
}

fn setup_monitoring_endpoint_with_mempool_client() -> MonitoringEndpoint {
    let mut mock_mempool_client = MockMempoolClient::new();
    mock_mempool_client.expect_get_mempool_snapshot().returning(|| Ok(expected_mempool_snapshot()));
    let shared_mock_mempool_client = Arc::new(mock_mempool_client);

    create_monitoring_endpoint(
        CONFIG_WITHOUT_METRICS,
        TEST_VERSION,
        None,
        Some(shared_mock_mempool_client),
        None,
    )
}

fn create_hash_map(i: u32, j: u32) -> HashMap<ContractAddress, Nonce> {
    let contract_addresses = (i..i + 2).map(ContractAddress::from).collect::<Vec<_>>();
    let nonces = (j..j + 2).map(|n| nonce!(n)).collect::<Vec<_>>();

    contract_addresses.into_iter().zip(nonces).collect()
}

fn expected_mempool_snapshot() -> MempoolSnapshot {
    let expected_chronological_hashes = (1..10).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_delayed_declares = (10..15).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_transaction_queue = TransactionQueueSnapshot {
        gas_price_threshold: GasPrice(1),
        priority_queue: (1..5).map(|i| tx_hash!(i)).collect::<Vec<_>>(),
        pending_queue: (5..10).map(|i| tx_hash!(i)).collect::<Vec<_>>(),
    };
    let mempool_state =
        MempoolStateSnapshot { committed: create_hash_map(1, 3), staged: create_hash_map(5, 7) };
    MempoolSnapshot {
        transactions: expected_chronological_hashes,
        delayed_declares: expected_delayed_declares,
        transaction_queue: expected_transaction_queue,
        mempool_state,
    }
}

#[tokio::test]
async fn mempool_snapshot_expected_values() {
    let app = setup_monitoring_endpoint_with_mempool_client().app();

    let response = request_app(app, MEMPOOL_SNAPSHOT).await;
    assert_eq!(response.status(), StatusCode::OK);
    let body_bytes = response.into_body().collect().await.unwrap().to_bytes();

    let expected_json =
        to_value(expected_mempool_snapshot()).expect("Failed to serialize MempoolSnapshot");
    let received_json: Value = from_slice(&body_bytes).expect("Failed to parse JSON string");

    assert_eq!(expected_json, received_json);
}

#[tokio::test]
async fn mempool_not_present() {
    let app = setup_monitoring_endpoint(None).app();
    let response = request_app(app, MEMPOOL_SNAPSHOT).await;
    assert_eq!(response.status(), StatusCode::METHOD_NOT_ALLOWED);
}

fn setup_monitoring_endpoint_with_l1_events_provider_client() -> MonitoringEndpoint {
    let mut l1_events_provider_client = MockL1EventsProviderClient::new();
    l1_events_provider_client
        .expect_get_l1_events_provider_snapshot()
        .returning(|| Ok(expected_l1_events_provider_snapshot()));
    let shared_mock_l1_events_provider_client = Arc::new(l1_events_provider_client);

    create_monitoring_endpoint(
        CONFIG_WITHOUT_METRICS,
        TEST_VERSION,
        None,
        None,
        Some(shared_mock_l1_events_provider_client),
    )
}

fn expected_l1_events_provider_snapshot() -> L1EventsProviderSnapshot {
    let expected_uncommitted_hashes = (1..10).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_uncommitted_staged_hashes = (1..2).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_rejected_hashes = (10..15).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_rejected_staged_hashes = (10..12).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_committed_hashes = (15..20).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_cancellation_started_on_l2 = (20..25).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_cancelled_on_l2 = (25..30).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_consumed = (30..35).map(|i| tx_hash!(i)).collect::<Vec<_>>();
    let expected_number_of_txs_in_records = 35;
    let l1_events_provider_state = String::from("Validate");
    let current_height = BlockNumber(1);
    L1EventsProviderSnapshot {
        uncommitted_transactions: expected_uncommitted_hashes,
        uncommitted_staged_transactions: expected_uncommitted_staged_hashes,
        rejected_transactions: expected_rejected_hashes,
        rejected_staged_transactions: expected_rejected_staged_hashes,
        committed_transactions: expected_committed_hashes,
        cancellation_started_on_l2: expected_cancellation_started_on_l2,
        cancelled_on_l2: expected_cancelled_on_l2,
        consumed: expected_consumed,
        number_of_txs_in_records: expected_number_of_txs_in_records,
        l1_events_provider_state,
        current_height,
    }
}

#[tokio::test]
async fn l1_events_provider_snapshot() {
    let app = setup_monitoring_endpoint_with_l1_events_provider_client().app();

    let response = request_app(app, L1_EVENTS_PROVIDER_SNAPSHOT).await;
    assert_eq!(response.status(), StatusCode::OK);
    let body_bytes = response.into_body().collect().await.unwrap().to_bytes();

    let expected_json = to_value(expected_l1_events_provider_snapshot())
        .expect("Failed to serialize L1EventsProviderSnapshot");
    let received_json: Value = from_slice(&body_bytes).expect("Failed to parse JSON string");

    assert_eq!(expected_json, received_json);
}

#[tokio::test]
async fn l1_events_provider_not_present() {
    let app = setup_monitoring_endpoint(None).app();
    let response = request_app(app, L1_EVENTS_PROVIDER_SNAPSHOT).await;
    assert_eq!(response.status(), StatusCode::METHOD_NOT_ALLOWED);
}

// Uses a multi threaded setup as two threads are required: one executing the mock mempool behavior,
// and the other monitoring the timeout.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mempool_snapshot_timeout() {
    // Set a mock mempool client that will sleep longer than the timeout.
    let mut mock_mempool_client = MockMempoolClient::new();
    mock_mempool_client.expect_get_mempool_snapshot().returning(|| {
        sleep(Duration::from_millis(SNAPSHOT_TASK_TIME));
        Ok(expected_mempool_snapshot())
    });
    let result = mempool_snapshot(
        Some(Arc::new(mock_mempool_client)),
        Duration::from_millis(SNAPSHOT_TIMEOUT_MILLIS),
    )
    .await;
    assert_eq!(result.unwrap_err(), StatusCode::GATEWAY_TIMEOUT);
}

// Uses a multi threaded setup as two threads are required: one executing the mock mempool behavior,
// and the other monitoring the timeout.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn l1_events_provider_snapshot_timeout() {
    // Set a mock l1 events provider client that will sleep longer than the timeout.
    let mut mock_l1_events_provider_client = MockL1EventsProviderClient::new();
    mock_l1_events_provider_client.expect_get_l1_events_provider_snapshot().returning(|| {
        sleep(Duration::from_millis(SNAPSHOT_TASK_TIME));
        Ok(expected_l1_events_provider_snapshot())
    });
    let result = get_l1_events_provider_snapshot(
        Some(Arc::new(mock_l1_events_provider_client)),
        Duration::from_millis(SNAPSHOT_TIMEOUT_MILLIS),
    )
    .await;
    assert_eq!(result.unwrap_err(), StatusCode::GATEWAY_TIMEOUT);
}
