use std::collections::btree_map::Entry;
use std::collections::BTreeMap;
use std::ops::{Deref, Sub};

use apollo_l1_events_config::config::TransactionManagerConfig;
use apollo_l1_events_types::{InvalidValidationStatus, ValidationStatus};
use starknet_api::block::{BlockTimestamp, UnixTimestamp};
use starknet_api::executable_transaction::L1HandlerTransaction;
use starknet_api::transaction::TransactionHash;
use tracing::{debug, info, warn};

use crate::metrics::{
    L1_MESSAGE_PROVIDER_NUM_PENDING_TXS,
    L1_MESSAGE_PROVIDER_OLDEST_PENDING_TX_L1_TIMESTAMP_SECONDS,
    L1_MESSAGE_SCRAPER_L1_HANDLER_TX_COUNT,
};
use crate::transaction_record::{
    Records,
    TransactionPayload,
    TransactionRecord,
    TransactionRecordPolicy,
    TransactionState,
};

#[cfg(test)]
#[path = "transaction_manager_tests.rs"]
mod transaction_manager_tests;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TransactionManager {
    /// Storage of all l1 handler transactions --- keeps transactions until they can be safely
    /// removed, like when they are consumed on L1, or fully cancelled on L1.
    pub records: Records,
    pub config: TransactionManagerConfig,
    /// Ordered lexicographically by scraping moment timestamp, then order-of-arrival for
    /// identical timestamps, also at any point the staged transactions are a prefix of the
    /// structure under this order.
    /// Invariant: contains all hashes of transactions that are proposable, and only them.
    /// Invarariant 2: Once removed from this index, a transaction will never be proposed again.
    proposable_index: BTreeMap<UnixTimestamp, Vec<TransactionHash>>,
    /// Generation counter used to prevent double usage of an l1 handler transaction in a single
    /// block.
    /// Calling `get_txs` or `validate_tx` tags the touched transactions with the current block
    /// counter, so that further calls will know not to touch them again.
    /// At the start and end (commit) of every block, the counter is incremented, thus "unstaging"
    /// all tagged transactions from the previous block attempt.
    // TODO(Gilad): remove "for rejected" from name when uncommitted is migrated to records DS.
    current_staging_epoch: StagingEpoch,
    /// All consumed transactions that are waiting to be removed from the transaction manager.
    /// Invariant: Ordered lexicographically by the block timestamp where they were marked as
    /// consumed, then order-of-arrival for identical timestamps.
    /// Invariant 2: A transaction is in the queue iff it is in the records and marked as consumed.
    consumed_queue: BTreeMap<BlockTimestamp, Vec<TransactionHash>>,
}

impl TransactionManager {
    pub fn new(config: TransactionManagerConfig) -> Self {
        Self {
            config,
            records: Default::default(),
            proposable_index: Default::default(),
            current_staging_epoch: StagingEpoch::new(),
            consumed_queue: Default::default(),
        }
    }

    pub fn start_block(&mut self) {
        self.rollback_staging();
    }

    // TODO(Arni): use created_at_block_timestamp in addition to scrape_timestamp.
    pub fn get_txs(&mut self, n_txs: usize, now: u64) -> Vec<L1HandlerTransaction> {
        // Oldest        Now.sub(timelock)     Newest       Now
        //  |<---  passed  --->|                 |           |
        //  |<--- cooldown --->|                 |           |
        // t-------------------------------------------------->
        let cutoff = now.saturating_sub(self.config.l1_handler_proposal_cooldown_seconds.as_secs());
        let past_cooldown_txs = self.proposable_index.range(..cutoff);

        // Linear scan, but we expect this to be a small number of transactions (< 10 roughly).
        let unstaged_tx_hashes: Vec<_> = past_cooldown_txs
            .flat_map(|(_timestamp, tx_hashes)| tx_hashes.iter())
            .skip_while(|&&tx_hash| self.is_staged(tx_hash))
            .take(n_txs)
            .copied()
            .collect();

        for &tx_hash in unstaged_tx_hashes.iter() {
            let record = self.records.get(&tx_hash).expect("transaction should exist");
            assert_eq!(
                record.state,
                TransactionState::Pending,
                "Transaction {tx_hash} has state {:?}. Only Pending transactions should be in the \
                 proposable index.",
                record.state
            );
        }

        let mut txs = Vec::with_capacity(n_txs);
        let current_staging_epoch = self.current_staging_epoch; // borrow-checker constraint.
        for tx_hash in unstaged_tx_hashes {
            let newly_staged =
                self.with_record(tx_hash, |record| record.try_mark_staged(current_staging_epoch));
            assert_eq!(
                newly_staged,
                Some(true),
                "Inconsistent storage state: indexed l1 handler {tx_hash} is not in storage or \
                 wasn't marked as staged."
            );

            txs.push(self.records[&tx_hash].get_unchecked().clone());
        }
        txs
    }

    pub fn validate_tx(&mut self, tx_hash: TransactionHash, unix_now: u64) -> ValidationStatus {
        let current_staging_epoch_cloned = self.current_staging_epoch;

        let policy = TransactionRecordPolicy {
            cancellation_timelock: self.config.l1_handler_cancellation_timelock_seconds,
        };

        let validation_status = self.with_record(tx_hash, |record| {
            // If the current time affects the state, update state now.
            record.update_time_based_state(unix_now, policy);
            if !record.is_validatable() {
                match record.state {
                    TransactionState::Committed => {
                        InvalidValidationStatus::AlreadyIncludedOnL2.into()
                    }
                    TransactionState::CancelledOnL2 => {
                        InvalidValidationStatus::CancelledOnL2.into()
                    }
                    TransactionState::Consumed => InvalidValidationStatus::ConsumedOnL1.into(),
                    _ => unreachable!(),
                }
            } else if record.try_mark_staged(current_staging_epoch_cloned) {
                ValidationStatus::Validated
            } else {
                InvalidValidationStatus::AlreadyIncludedInProposedBlock.into()
            }
        });

        validation_status.unwrap_or(InvalidValidationStatus::NotFound.into())
    }

    pub fn commit_txs(
        &mut self,
        committed_txs: &[TransactionHash],
        rejected_txs: &[TransactionHash],
    ) {
        self.rollback_staging();

        for &tx_hash in committed_txs {
            self.create_record_if_not_exist(tx_hash);
            self.with_record(tx_hash, |r| r.mark_committed()).unwrap();
        }
        for &tx_hash in rejected_txs {
            self.with_record(tx_hash, |r| r.mark_rejected()).expect(
                "Rejected L1 handler tx has no record. Unreachable: all L1 handler txs in a \
                 committed block were validated as known (validation rejects unknown hashes), \
                 sync commits with empty rejected_txs, and records are only removed via L1 \
                 cancellation/consumption, which can't race a block.",
            );
        }
    }

    /// Adds a transaction to the transaction manager, return true if the transaction was
    /// successfully added. If the transaction is occupied or already had its hash stored as
    /// committed, it will not be added, and false will be returned.
    // Note: if only the committed hash was known, the transaction will "fill in the blank" in the
    // committed txs storage, to account for commit-before-add tx scenario.
    pub fn add_tx(
        &mut self,
        tx: L1HandlerTransaction,
        block_timestamp: BlockTimestamp,
        scrape_timestamp: UnixTimestamp,
    ) {
        let tx_hash = tx.tx_hash;
        // If exists, return false and do nothing. If not, create the record as a HashOnly payload.
        let is_new_record = self.create_record_if_not_exist(tx_hash);
        // Replace a HashOnly payload with a Full payload. Do not update a Full payload.
        // A hash only payload can come from catching up from state sync, and then updated by
        // add_events from the scraper. However, if we get the same full tx twice (from the scraper)
        // it could indicate a double-scrape, and may cause the tx to be re-added to the proposable
        // index.
        self.with_record(tx_hash, move |record| match &record.tx {
            TransactionPayload::HashOnly(_) => {
                if !is_new_record {
                    info!(
                        "Transaction {tx_hash} already exists as a HashOnly payload. It was \
                         probably gotten via state sync component, and is now updated with a Full \
                         payload."
                    );
                }
                record.tx.set(tx, block_timestamp, scrape_timestamp);
                // Counts the HashOnly -> Full transition, regardless of whether the HashOnly
                // was just created here or pre-existed from state sync.
                L1_MESSAGE_SCRAPER_L1_HANDLER_TX_COUNT.increment(1);
            }
            TransactionPayload::Full { tx: _, created_at_block_timestamp: _, scrape_timestamp } => {
                warn!(
                    "Transaction {tx_hash} already exists as a Full payload, scraped at \
                     {scrape_timestamp}. This could indicate a double scrape. Ignoring the new \
                     transaction."
                );
            }
        });
    }

    pub fn request_cancellation(
        &mut self,
        tx_hash: TransactionHash,
        block_timestamp: BlockTimestamp,
    ) -> Option<BlockTimestamp> {
        self.with_record(tx_hash, |r| r.mark_cancellation_request(block_timestamp)).expect(
            "Should not be possible to request cancellation for non-existent transaction {tx_hash}",
        )
    }

    pub fn finalize_cancellation(&mut self, tx_hash: TransactionHash) {
        let Some(record) = self.records.get(&tx_hash) else {
            info!(
                "Attempted to finalize cancellation for non-existent transaction: {tx_hash}. This \
                 can happen if the transaction was too old to be scraped (e.g. it was created \
                 before we started scraping)."
            );
            return;
        };

        // Regardless of the state of the tx in the record, if we get the cancellation event from
        // the L1 contract, we delete this tx from the records and from the proposable index, even
        // if it was Pending and ready to be proposed (which is not supposed to happen, hence the
        // warning).
        if record.state != TransactionState::CancellationStartedOnL2 {
            warn!(
                "Attempted to finalize cancellation for transaction {tx_hash} that is not in the \
                 cancellation started on L2 state, but in the {:?} state.",
                record.state
            );
        }
        // This will also call maintain_indices to remove the tx from the proposable index.
        self.with_record(tx_hash, |r| r.mark_cancellation_finalized_on_l1());
        self.records.remove(&tx_hash);
    }

    pub fn consume_tx(
        &mut self,
        tx_hash: TransactionHash,
        consumed_at: BlockTimestamp,
        unix_now: u64,
    ) -> Result<(), BlockTimestamp> {
        self.clear_old_tx_from_consumed_queue(unix_now);

        let Some(record) = self.records.get(&tx_hash) else {
            debug!(
                "Attempted to consume an unknown transaction: {tx_hash}. This can happen if the \
                 transaction was too old to be scraped (e.g. it was created before we started \
                 scraping)."
            );
            return Ok(());
        };

        // Double consumption is a bug.
        if let Some(previously_consumed_at) = record.get_consumed_at_timestamp() {
            return Err(previously_consumed_at);
        }

        // Mark the transaction as consumed.
        self.with_record(tx_hash, |record| record.mark_consumed(consumed_at));
        Ok(())
    }

    pub fn clear_old_tx_from_consumed_queue(&mut self, unix_now: u64) {
        let cutoff =
            unix_now.saturating_sub(self.config.l1_handler_consumption_timelock_seconds.as_secs());
        let still_timelocked = self.consumed_queue.split_off(&BlockTimestamp(cutoff));
        let passed_timelock = std::mem::replace(&mut self.consumed_queue, still_timelocked);
        for tx_hashes in passed_timelock.values() {
            for tx_hash in tx_hashes {
                self.records.remove(tx_hash);
            }
        }
    }

    pub fn is_committed(&self, tx_hash: TransactionHash) -> bool {
        self.records.get(&tx_hash).is_some_and(|record| record.is_committed())
    }

    pub fn exists(&self, tx_hash: TransactionHash) -> bool {
        self.records.contains_key(&tx_hash)
    }

    // The snapshot is not sorted. This is to optimize for performance. This is because the
    // Records::remove method uses swap_remove instead of shift_remove for better performance,
    // which can change the order of remaining elements. If sorting is needed, change
    // Records::remove to use shift_remove instead of swap_remove.
    pub(crate) fn snapshot(&self) -> TransactionManagerSnapshot {
        let mut snapshot = TransactionManagerSnapshot::default();

        for (&tx_hash, record) in self.records.iter() {
            match record.state {
                TransactionState::Rejected => {
                    snapshot.rejected.push(tx_hash);
                    if self.is_staged(tx_hash) {
                        snapshot.rejected_staged.push(tx_hash);
                    }
                }
                TransactionState::Committed => {
                    snapshot.committed.push(tx_hash);
                }
                TransactionState::Pending => {
                    snapshot.uncommitted.push(tx_hash);
                    if self.is_staged(tx_hash) {
                        snapshot.uncommitted_staged.push(tx_hash);
                    }
                }
                TransactionState::CancellationStartedOnL2 => {
                    snapshot.cancellation_started_on_l2.push(tx_hash);
                }
                TransactionState::CancelledOnL2 => {
                    snapshot.cancelled_on_l2.push(tx_hash);
                }
                // This should never happen, fully cancelled txs are removed from the transaction
                // manager.
                TransactionState::CancellationFinalizedOnL1 => {
                    panic!(
                        "This should never happen, fully cancelled txs are removed from the \
                         transaction manager."
                    );
                }
                TransactionState::Consumed => {
                    snapshot.consumed.push(tx_hash);
                }
            }
        }
        snapshot.proposable_index = self.proposable_index.clone();
        snapshot
    }

    fn with_record<F, R>(&mut self, hash: TransactionHash, f: F) -> Option<R>
    where
        F: FnOnce(&mut TransactionRecord) -> R,
    {
        let record = self.records.get_mut_unchecked(hash)?;
        let result = f(record);
        self.maintain_indices(hash);
        Some(result)
    }

    fn create_record_if_not_exist(&mut self, hash: TransactionHash) -> bool {
        self.records.insert(hash, TransactionRecord::new(hash.into()))
    }

    fn is_staged(&self, tx_hash: TransactionHash) -> bool {
        self.records
            .get(&tx_hash)
            .is_some_and(|record| record.is_staged(self.current_staging_epoch))
    }

    fn rollback_staging(&mut self) {
        self.current_staging_epoch = self.current_staging_epoch.increment();
    }

    /// The L1 block timestamp of the oldest pending (proposable, uncommitted) L1 handler tx, or
    /// `None` when none are pending. Scans the proposable index (expected to hold few transactions)
    /// for the minimal L1 emission timestamp, rather than relying on scrape order.
    fn oldest_pending_l1_block_timestamp(&self) -> Option<BlockTimestamp> {
        self.proposable_index
            .values()
            .flatten()
            .filter_map(|tx_hash| self.records.get(tx_hash)?.tx.created_at_block_timestamp())
            .min()
    }

    // Update `proposable_index` and `consumed_queue` indices with this transaction.
    fn maintain_indices(&mut self, hash: TransactionHash) {
        if let Some(record) = self.records.get(&hash) {
            let TransactionPayload::Full { scrape_timestamp, .. } = record.tx else {
                // We haven't scraped this tx yet, so it isn't indexed.
                return;
            };

            let tx_hash = hash;
            // Check if we need to add this tx to the proposable index.
            if record.is_proposable() {
                // Assumption: txs will only be added to the index once, on arrival, so this
                // preserves arrival order.
                let tx_hashes = self.proposable_index.entry(scrape_timestamp).or_default();
                if !tx_hashes.contains(&tx_hash) {
                    tx_hashes.push(tx_hash);
                }
            } else {
                // This tx needs to be removed from the proposable index if it was on it.
                // Remove from the vec for this timestamp, and drop the entry if it becomes empty.
                match self.proposable_index.entry(scrape_timestamp) {
                    Entry::Occupied(mut entry) => {
                        let tx_hashes = entry.get_mut();
                        if let Some(index_in_vec) = tx_hashes.iter().position(|&h| h == tx_hash) {
                            tx_hashes.remove(index_in_vec);
                            if tx_hashes.is_empty() {
                                entry.remove();
                            }
                        }
                    }
                    Entry::Vacant(_) => {}
                }
            }

            let num_pending_txs = self.proposable_index.len();
            L1_MESSAGE_PROVIDER_NUM_PENDING_TXS.set_lossy(num_pending_txs);

            // Export the oldest pending tx's L1 block timestamp so an alert can fire when a single
            // L1 handler waits on L1 for too long without being committed to L2. We export the
            // timestamp (not the age) so the alert can compute `time() - timestamp` and have the
            // age grow correctly even while the provider is idle. 0 means nothing is
            // pending.
            let oldest_pending_tx_timestamp = self
                .oldest_pending_l1_block_timestamp()
                .map(|timestamp| timestamp.0)
                .unwrap_or_default();
            L1_MESSAGE_PROVIDER_OLDEST_PENDING_TX_L1_TIMESTAMP_SECONDS
                .set_lossy(oldest_pending_tx_timestamp);

            // If this tx was consumed, add it to the consumed queue.
            if let Some(consumed_at) = record.get_consumed_at_timestamp() {
                self.consumed_queue.entry(consumed_at).or_default().push(tx_hash);
            }
        }
    }

    #[cfg(any(feature = "testing", test))]
    pub fn create_for_testing(
        records: Records,
        proposable_index: BTreeMap<UnixTimestamp, Vec<TransactionHash>>,
        current_epoch: StagingEpoch,
        config: TransactionManagerConfig,
        consumed_queue: BTreeMap<BlockTimestamp, Vec<TransactionHash>>,
    ) -> Self {
        Self {
            records,
            proposable_index,
            current_staging_epoch: current_epoch,
            config,
            consumed_queue,
        }
    }
}

impl Default for TransactionManager {
    // Note that new will init the epoch at 1, not 0, this is because a 0 epoch in the transaction
    // manager will make new transactions automatically staged by default in the first block.
    fn default() -> Self {
        Self::new(TransactionManagerConfig::default())
    }
}
#[derive(Debug, Default)]
pub(crate) struct TransactionManagerSnapshot {
    pub uncommitted: Vec<TransactionHash>,
    pub uncommitted_staged: Vec<TransactionHash>,
    pub rejected: Vec<TransactionHash>,
    pub rejected_staged: Vec<TransactionHash>,
    pub committed: Vec<TransactionHash>,
    pub cancellation_started_on_l2: Vec<TransactionHash>,
    // NOTE: transition from cancellation-started into cancelled state is done LAZILY only when
    // validation requests are processed against a record.
    pub cancelled_on_l2: Vec<TransactionHash>,
    // NOTE: consumed transactions are removed from the transaction manager LAZILY only when the
    // next consume_tx request is processed (and the timelock has passed).
    pub consumed: Vec<TransactionHash>,
    pub proposable_index: BTreeMap<UnixTimestamp, Vec<TransactionHash>>,
}

#[cfg(any(test, feature = "testing"))]
impl TransactionManagerSnapshot {
    pub fn is_empty(&self) -> bool {
        self.uncommitted.is_empty()
            && self.uncommitted_staged.is_empty()
            && self.rejected.is_empty()
            && self.rejected_staged.is_empty()
            && self.committed.is_empty()
            && self.cancellation_started_on_l2.is_empty()
            && self.cancelled_on_l2.is_empty()
            && self.consumed.is_empty()
            && self.proposable_index.is_empty()
    }
}

// Invariant: Monotone-increasing.
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord)]
pub struct StagingEpoch(u128);

impl StagingEpoch {
    /// Note: initialized to 1, since new l1 handler transactions are initialized with epoch 0 ---
    /// this ensures all new transactions are stageable.
    pub fn new() -> Self {
        Self(1)
    }

    pub fn increment(&mut self) -> Self {
        Self(self.0 + 1)
    }

    pub fn decrement(&mut self) -> Self {
        Self(self.0 - 1)
    }
}

impl Deref for StagingEpoch {
    type Target = u128;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl From<u128> for StagingEpoch {
    fn from(value: u128) -> Self {
        Self(value)
    }
}

impl Sub<u128> for StagingEpoch {
    type Output = StagingEpoch;

    fn sub(self, rhs: u128) -> Self::Output {
        Self(self.0 - rhs)
    }
}
