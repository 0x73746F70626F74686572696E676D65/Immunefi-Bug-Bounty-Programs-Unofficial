use std::collections::{HashMap, VecDeque};
use std::sync::Arc;

use apollo_config::behavior_mode::BehaviorMode;
use apollo_mempool_config::config::{MempoolConfig, MempoolDynamicConfig};
use apollo_mempool_types::errors::MempoolError;
use apollo_mempool_types::mempool_types::{
    AccountState,
    AddTransactionArgs,
    CommitBlockArgs,
    MempoolResult,
    MempoolSnapshot,
    MempoolStateSnapshot,
    TxBlockMetadata,
    ValidationArgs,
};
use apollo_time::time::{Clock, DateTime};
use indexmap::IndexSet;
use rand::{rng, RngExt};
use starknet_api::block::GasPrice;
use starknet_api::core::{ContractAddress, Nonce};
use starknet_api::rpc_transaction::{
    InternalRpcTransaction,
    InternalRpcTransactionLabelValue,
    InternalRpcTransactionWithoutTxHash,
};
use starknet_api::transaction::fields::Tip;
use starknet_api::transaction::TransactionHash;
use tracing::{debug, info, instrument, trace, warn};

use crate::fee_transaction_queue::FeeTransactionQueue;
use crate::fifo_transaction_queue::FifoTransactionQueue;
use crate::metrics::{
    metric_count_committed_txs,
    metric_count_evicted_txs,
    metric_count_expired_txs,
    metric_count_rejected_txs,
    metric_set_get_txs_size,
    LABEL_NAME_TX_TYPE,
    MEMPOOL_ACCOUNTS_WITH_GAP,
    MEMPOOL_DELAYED_DECLARES_SIZE,
    MEMPOOL_PENDING_QUEUE_SIZE,
    MEMPOOL_POOL_SIZE,
    MEMPOOL_PRIORITY_QUEUE_SIZE,
    MEMPOOL_STUCK_TXS,
    MEMPOOL_TOTAL_SIZE_BYTES,
    MEMPOOL_TRANSACTIONS_RECEIVED,
};
use crate::transaction_pool::TransactionPool;
use crate::transaction_queue_trait::{BlockMetadata, RewindData, TransactionQueueTrait};
use crate::utils::try_increment_nonce;

#[cfg(test)]
#[path = "fee_mempool_test.rs"]
pub mod fee_mempool_test;

#[cfg(test)]
#[path = "mempool_flow_tests.rs"]
pub mod mempool_flow_tests;

type AddressToNonce = HashMap<ContractAddress, Nonce>;
type AccountsWithGap = IndexSet<ContractAddress>;

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
struct CommitHistory {
    commits: VecDeque<AddressToNonce>,
}

impl CommitHistory {
    fn new(capacity: usize) -> Self {
        CommitHistory { commits: std::iter::repeat_n(AddressToNonce::new(), capacity).collect() }
    }

    fn push(&mut self, commit: AddressToNonce) -> AddressToNonce {
        let removed_commit = self.commits.pop_front();
        self.commits.push_back(commit);
        removed_commit.expect("Commit history should be initialized with capacity.")
    }
}

/// Represents the state tracked by the mempool.
/// It is partitioned into categories, each serving a distinct role in the lifecycle of transaction
/// management.
#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub struct MempoolState {
    /// Records recent commit_block events to preserve the committed nonces of the latest blocks.
    commit_history: CommitHistory,
    /// Finalized nonces committed in blocks.
    committed: AddressToNonce,
    /// Provisionally incremented nonces during block creation.
    staged: AddressToNonce,
}

impl MempoolState {
    fn new(committed_nonce_retention_block_count: usize) -> Self {
        MempoolState {
            commit_history: CommitHistory::new(committed_nonce_retention_block_count),
            committed: HashMap::new(),
            staged: HashMap::new(),
        }
    }

    /// Returns the most updated Nonce (including staged) for the address. If no value is found for
    /// address, incoming_account_nonce is returned.
    fn resolve_nonce(&self, address: ContractAddress, incoming_account_nonce: Nonce) -> Nonce {
        self.staged
            .get(&address)
            .or_else(|| self.committed.get(&address))
            .copied()
            .unwrap_or(incoming_account_nonce)
    }

    fn contains_account(&self, address: ContractAddress) -> bool {
        self.staged.contains_key(&address) || self.committed.contains_key(&address)
    }

    fn stage(&mut self, tx_reference: &TransactionReference) -> MempoolResult<()> {
        let next_nonce = try_increment_nonce(tx_reference.nonce)?;
        if let Some(existing_nonce) = self.staged.insert(tx_reference.address, next_nonce) {
            assert_eq!(
                try_increment_nonce(existing_nonce)?,
                next_nonce,
                "Staged nonce should be an increment of an existing nonce."
            );
        }

        Ok(())
    }

    /// Updates the committed nonces, and returns the addresses which need to be rewinded (i.e.
    /// addressed which were staged but did not make to the commit).
    fn commit(&mut self, address_to_nonce: AddressToNonce) -> Vec<ContractAddress> {
        let addresses_to_rewind: Vec<_> = self
            .staged
            .keys()
            .filter(|&key| !address_to_nonce.contains_key(key))
            .copied()
            .collect();

        self.committed.extend(address_to_nonce.clone());
        self.staged.clear();

        // Add the commit event to the history.
        // If an old event has been removed (due to history size limit), delete the associated
        // committed nonces.
        let removed_commit = self.commit_history.push(address_to_nonce);
        for (address, removed_nonce) in removed_commit {
            let last_committed_nonce = *self
                .committed
                .get(&address)
                .expect("Account in commit history must appear in the committed nonces.");
            if last_committed_nonce == removed_nonce {
                self.committed.remove(&address);
            }
        }

        addresses_to_rewind
    }

    fn validate_incoming_tx(
        &self,
        tx_reference: TransactionReference,
        incoming_account_nonce: Nonce,
    ) -> MempoolResult<()> {
        let TransactionReference { address, nonce: tx_nonce, .. } = tx_reference;
        let account_nonce = self.resolve_nonce(address, incoming_account_nonce);
        if tx_nonce < account_nonce {
            return Err(MempoolError::NonceTooOld { address, tx_nonce, account_nonce });
        }

        Ok(())
    }

    fn validate_commitment(&self, address: ContractAddress, next_nonce: Nonce) {
        // FIXME: Remove after first POC.
        // If commit_block wants to decrease the stored account nonce this can mean one of two
        // things:
        // 1. this is a reorg, which should be handled by a dedicated TBD mechanism and not inside
        //    commit_block
        // 2. the stored nonce originated from add_tx, so should be treated as tentative due to
        //    possible races with the gateway; these types of nonces should be tagged somehow so
        //    that commit_block can override them. Regardless, in the first POC this cannot happen
        //    because the GW nonces are always 1.
        if let Some(&committed_nonce) = self.committed.get(&address) {
            assert!(committed_nonce <= next_nonce, "NOT SUPPORTED YET {address:?} {next_nonce:?}.")
        }
    }

    pub fn state_snapshot(&self) -> MempoolStateSnapshot {
        MempoolStateSnapshot { committed: self.committed.clone(), staged: self.staged.clone() }
    }
}

// A queue to hold transactions that are waiting to be added to the tx pool.
struct AddTransactionQueue {
    elements: VecDeque<(DateTime, AddTransactionArgs)>,
    // Keeps track of the total size of the transactions in this queue.
    size_in_bytes: u64,
}

impl AddTransactionQueue {
    fn new() -> Self {
        AddTransactionQueue { elements: VecDeque::new(), size_in_bytes: 0 }
    }

    fn push_back(&mut self, submission_time: DateTime, args: AddTransactionArgs) {
        self.size_in_bytes = self
            .size_in_bytes
            .checked_add(args.tx.total_bytes())
            .expect("Overflow when adding a transaction to AddTransactionQueue.");
        self.elements.push_back((submission_time, args));
    }

    fn pop_front(&mut self) -> Option<(DateTime, AddTransactionArgs)> {
        let removed_element = self.elements.pop_front();
        if let Some((_, args)) = &removed_element {
            self.size_in_bytes = self
                .size_in_bytes
                .checked_sub(args.tx.total_bytes())
                .expect("Underflow when removing a transaction from AddTransactionQueue.");
        }
        removed_element
    }

    fn front(&self) -> Option<&(DateTime, AddTransactionArgs)> {
        self.elements.front()
    }

    fn contains(&self, contract_address: ContractAddress, nonce: Nonce) -> bool {
        self.elements.iter().any(|(_, tx_args)| {
            let tx = &tx_args.tx;
            tx.contract_address() == contract_address && tx.nonce() == nonce
        })
    }

    fn len(&self) -> usize {
        self.elements.len()
    }

    fn size_in_bytes(&self) -> u64 {
        self.size_in_bytes
    }
}

pub struct Mempool {
    pub(crate) config: MempoolConfig,
    // TODO(AlonH): add docstring explaining visibility and coupling of the fields.
    // Declare transactions that are waiting to be added to the tx pool after a delay.
    delayed_declares: AddTransactionQueue,
    // All transactions currently held in the mempool (excluding the delayed declares).
    tx_pool: TransactionPool,
    // Transactions eligible for sequencing.
    tx_queue: Box<dyn TransactionQueueTrait>,
    // Accounts whose lowest transaction nonce is greater than the account nonce, which are
    // therefore candidates for eviction.
    accounts_with_gap: AccountsWithGap,
    // Total number of transactions in the pool that belong to accounts in `accounts_with_gap`.
    // Maintained incrementally to allow O(1) metric reporting.
    n_stuck_txs: usize,
    state: MempoolState,
    clock: Arc<dyn Clock>,
}

impl Mempool {
    pub fn new(config: MempoolConfig, clock: Arc<dyn Clock>) -> Self {
        // Select queue type based on behavior_mode.
        // In Echonet mode, use FIFO queue; otherwise use fee-based priority queue.
        let tx_queue: Box<dyn TransactionQueueTrait> = match config.static_config.behavior_mode {
            BehaviorMode::Echonet => Box::new(FifoTransactionQueue::new()),
            BehaviorMode::Starknet => Box::new(FeeTransactionQueue::default()),
        };

        Mempool {
            config: config.clone(),
            delayed_declares: AddTransactionQueue::new(),
            tx_pool: TransactionPool::new(clock.clone()),
            tx_queue,
            accounts_with_gap: AccountsWithGap::new(),
            n_stuck_txs: 0,
            state: MempoolState::new(config.static_config.committed_nonce_retention_block_count),
            clock,
        }
    }

    pub(crate) fn is_fifo(&self) -> bool {
        matches!(self.config.static_config.behavior_mode, BehaviorMode::Echonet)
    }

    pub(crate) fn resolve_block_metadata(&mut self) -> BlockMetadata {
        if !self.is_fifo() {
            let timestamp = self.clock.unix_now();
            debug!("Mempool resolve_block_metadata (Fee): timestamp={}", timestamp);
            return BlockMetadata { timestamp, block_number: None };
        }

        self.tx_queue.resolve_metadata()
    }

    pub(crate) fn update_tx_block_metadata(
        &mut self,
        tx_hash: TransactionHash,
        metadata: TxBlockMetadata,
    ) {
        if !self.is_fifo() {
            panic!(
                "Update tx block metadata called for tx {} in non-echonet mode, this should never \
                 happen.",
                tx_hash
            );
        }
        self.tx_queue.update_tx_block_metadata(tx_hash, metadata);
    }

    /// Returns an iterator of the current eligible transactions for sequencing, ordered by their
    /// priority.
    pub fn iter(&self) -> impl Iterator<Item = &TransactionReference> {
        self.tx_queue.iter_over_ready_txs()
    }

    /// Retrieves up to `n_txs` transactions with the highest priority from the mempool.
    /// Transactions are guaranteed to be unique across calls until the block in-progress is
    /// created.
    // TODO(AlonH): Consider renaming to `pop_txs` to be more consistent with the standard library.
    #[instrument(skip(self), err(level = "debug"))]
    pub fn get_txs(&mut self, n_txs: usize) -> MempoolResult<Vec<InternalRpcTransaction>> {
        // All transactions are enqueued in FIFO mode.
        if !self.is_fifo() {
            self.add_ready_declares();
        }
        let mut eligible_tx_references: Vec<TransactionReference> = Vec::with_capacity(n_txs);
        let mut n_remaining_txs = n_txs;

        let mut account_nonce_updates = AddressToNonce::new();
        while n_remaining_txs > 0 && self.tx_queue.has_ready_txs() {
            let chunk = self.tx_queue.pop_ready_chunk(n_remaining_txs);

            let (valid_txs, expired_txs_updates) = self.prune_expired_nonqueued_txs(chunk);
            account_nonce_updates.extend(expired_txs_updates);

            // In FIFO mode, all transactions are already enqueued. In fee-priority mode,
            // we need to enqueue the next eligible transaction for each address.
            if !self.is_fifo() {
                self.enqueue_next_eligible_txs(&valid_txs)?;
            }

            n_remaining_txs -= valid_txs.len();
            eligible_tx_references.extend(valid_txs);
        }

        // Update the mempool state with the given transactions' nonces.
        for tx_reference in &eligible_tx_references {
            self.state.stage(tx_reference)?;
        }

        let n_returned_txs = eligible_tx_references.len();
        if n_returned_txs != 0 {
            info!("Returned {n_returned_txs} out of {n_txs} transactions, ready for sequencing.");
            debug!(
                "Returned mempool txs: {:?}",
                eligible_tx_references.iter().map(|tx| tx.tx_hash).collect::<Vec<_>>()
            );
            // Mark these txs as "taken for batching" (returned by `get_txs`). The
            // `TRANSACTION_TIME_SPENT_UNTIL_BATCHED` metric is recorded only once they actually
            // commit (to avoid counting txs that were returned by `get_txs` but ultimately not
            // included).
            let now = self.clock.now();
            for tx_ref in &eligible_tx_references {
                self.tx_pool.mark_taken_for_batching(tx_ref.tx_hash, now);
            }
        }

        metric_set_get_txs_size(n_returned_txs);
        self.update_accounts_with_gap(account_nonce_updates);
        self.update_state_metrics();

        Ok(eligible_tx_references
            .iter()
            .map(|tx_reference| {
                self.tx_pool
                    .get_by_tx_hash(tx_reference.tx_hash)
                    .expect("Transaction hash from queue must appear in pool.")
            })
            .cloned() // Soft-delete: return without deleting from mempool.
            .collect())
    }

    /// Perform validation-only of an incoming transaction (without changing the state).
    #[instrument(
        level = "debug",
        skip(self, args),
        fields( // Log subset of (informative) fields.
            tx_nonce = %args.tx_nonce,
            tx_hash = %args.tx_hash,
            tx_tip = %args.tip,
            tx_max_l2_gas_price = %args.max_l2_gas_price,
            address = %args.address
        ),
        err(level = "debug"))
    ]
    pub fn validate_tx(&mut self, args: ValidationArgs) -> MempoolResult<()> {
        let tx_reference = (&args).into();
        self.validate_incoming_tx(tx_reference, args.account_nonce)?;
        self.validate_fee_escalation(tx_reference)?;

        Ok(())
    }

    /// Validates an incoming transaction and handles fee escalation.
    fn add_tx_validations(
        &mut self,
        tx_reference: TransactionReference,
        tx: &InternalRpcTransaction,
        account_nonce: Nonce,
    ) -> MempoolResult<()> {
        self.validate_incoming_tx(tx_reference, account_nonce)?;
        let replaced_tx_reference = self.validate_fee_escalation(tx_reference)?;

        // The replaced transaction is still pooled, so its bytes still count toward
        // `size_in_bytes()`. Credit what its removal will free: a same-size bump nets to zero (no
        // overflow handling), and a larger replacement only needs room for the delta, consistent
        // with how a fresh next-nonce transaction is treated. The removal happens only after
        // capacity is confirmed below, so a rejected incoming transaction never strands the
        // account.
        let freed_bytes = replaced_tx_reference.map_or(0, |reference| {
            self.tx_pool
                .get_by_tx_hash(reference.tx_hash)
                .expect("Replacement target from pool must exist.")
                .total_bytes()
        });

        if self.exceeds_capacity(tx, freed_bytes) {
            self.handle_capacity_overflow(tx, account_nonce, freed_bytes)?;
        }

        // Capacity is confirmed: this is the final, infallible mutation before the incoming
        // transaction is inserted by the caller.
        if let Some(existing_tx_reference) = replaced_tx_reference {
            self.remove_replaced_tx(existing_tx_reference);
        }

        Ok(())
    }

    fn log_add_tx_error(&self, err: &MempoolError, args: &AddTransactionArgs) {
        match err {
            MempoolError::DuplicateTransaction { .. }
            | MempoolError::DuplicateNonce { .. }
            | MempoolError::NonceTooOld { .. } => {
                // These error variants are not informative and they spam the logs.
            }
            _ => {
                debug!(
                    tx_nonce = %args.tx.nonce(),
                    tx_hash = %args.tx.tx_hash,
                    tx_tip = %args.tx.tip(),
                    tx_max_l2_gas_price = %args.tx.resource_bounds().l2_gas.max_price_per_unit,
                    account_state = %args.account_state,
                    "{err}"
                );
            }
        }
    }

    /// Adds a new transaction to the mempool.
    #[instrument(
        level = "debug",
        skip(self, args),
        fields( // Log subset of (informative) fields.
            tx_nonce = %args.tx.nonce(),
            tx_hash = %args.tx.tx_hash,
            tx_tip = %args.tx.tip(),
            tx_max_l2_gas_price = %args.tx.resource_bounds().l2_gas.max_price_per_unit,
            account_state = %args.account_state
        ),
        err(level = "debug")
    )]
    pub fn add_tx(&mut self, args: AddTransactionArgs) -> MempoolResult<()> {
        // First remove old transactions from the pool.
        let mut account_nonce_updates = self.remove_expired_txs();
        if !self.is_fifo() {
            self.add_ready_declares();
        }

        let tx_reference = TransactionReference::new(&args.tx);
        self.add_tx_validations(tx_reference, &args.tx, args.account_state.nonce)
            .inspect_err(|err| self.log_add_tx_error(err, &args))?;

        MEMPOOL_TRANSACTIONS_RECEIVED.increment(
            1,
            &[(LABEL_NAME_TX_TYPE, InternalRpcTransactionLabelValue::from(&args.tx.tx).into())],
        );

        // May override a removed queued nonce with the received account nonce or the account's
        // state nonce.
        account_nonce_updates.insert(
            args.account_state.address,
            self.state.resolve_nonce(args.account_state.address, args.account_state.nonce),
        );

        let should_delay_declare =
            matches!(&args.tx.tx, InternalRpcTransactionWithoutTxHash::Declare(_))
                && !self.is_fifo();
        if should_delay_declare {
            self.delayed_declares.push_back(self.clock.now(), args);
        } else {
            self.add_tx_inner(args);
        }

        self.update_accounts_with_gap(account_nonce_updates);
        self.update_state_metrics();
        Ok(())
    }

    fn insert_to_tx_queue(&mut self, tx_reference: TransactionReference) {
        self.tx_queue.insert(tx_reference, self.config.static_config.validate_resource_bounds);
    }

    fn rewind_txs(
        &mut self,
        addresses_to_rewind: Vec<ContractAddress>,
        address_to_nonce: &AddressToNonce,
        rejected_tx_hashes: &IndexSet<TransactionHash>,
    ) -> IndexSet<TransactionHash> {
        if self.is_fifo() {
            self.tx_queue.rewind_txs(RewindData::Fifo {
                committed_nonces: address_to_nonce,
                rejected_tx_hashes,
            })
        } else {
            let next_txs_by_address = addresses_to_rewind
                .iter()
                .filter_map(|&address| {
                    self.tx_pool
                        .account_txs_sorted_by_nonce(address)
                        .next()
                        .map(|tx_reference| (address, *tx_reference))
                })
                .collect::<HashMap<ContractAddress, TransactionReference>>();
            self.tx_queue.rewind_txs(RewindData::FeePriority {
                next_txs_by_address: &next_txs_by_address,
                validate_resource_bounds: self.config.static_config.validate_resource_bounds,
            })
        }
    }

    fn remove_rejected_txs(
        &mut self,
        rejected_tx_hashes: IndexSet<TransactionHash>,
        rewound_tx_hashes: &IndexSet<TransactionHash>,
    ) -> AddressToNonce {
        if !rejected_tx_hashes.is_empty() {
            debug!("Removed rejected transactions from mempool: {:?}", rejected_tx_hashes);
        }
        let mut rejected_txs_counter = 0;
        let mut account_nonce_updates = AddressToNonce::new();

        for tx_hash in rejected_tx_hashes {
            // In FIFO mode, if a rejected transaction was rewound, skip removal (keep in pool and
            // queue). Otherwise, remove it from both pool and queue.
            if rewound_tx_hashes.contains(&tx_hash) {
                continue;
            }

            if let Ok(tx) = self.tx_pool.remove(tx_hash) {
                self.tx_queue.remove_by_address(tx.contract_address());
                rejected_txs_counter += 1;
                self.decrement_stuck_txs_if_gap_account(tx.contract_address(), 1);
                account_nonce_updates
                    .entry(tx.contract_address())
                    .and_modify(|nonce| *nonce = (*nonce).min(tx.nonce()))
                    .or_insert(tx.nonce());
            } else {
                continue; // Transaction hash unknown to mempool, from a different node.
            }

            // TODO(clean_accounts): remove address with no transactions left after a block cycle /
            // TTL.
        }
        metric_count_rejected_txs(rejected_txs_counter);
        account_nonce_updates
    }

    fn add_tx_inner(&mut self, args: AddTransactionArgs) {
        let AddTransactionArgs { tx, account_state } = args;
        info!("Adding transaction to mempool.");
        trace!("{tx:#?}");

        let tx_reference = TransactionReference::new(&tx);

        // Pre-count this tx as stuck; update_accounts_with_gap will correct the count if this tx
        // resolves the gap.
        if self.accounts_with_gap.contains(&account_state.address) {
            self.n_stuck_txs += 1;
        }

        self.tx_pool
            .insert(tx)
            .expect("Duplicate transactions should cause an error during the validation stage.");

        let AccountState { address, nonce: incoming_account_nonce } = account_state;
        let account_nonce = self.state.resolve_nonce(address, incoming_account_nonce);

        if self.is_fifo() {
            // FIFO mode: add all transactions to the queue immediately, regardless of nonce.
            // Keep all transactions from the same address in the queue.
            self.insert_to_tx_queue(tx_reference);
        } else if tx_reference.nonce == account_nonce {
            // Fee mode: only add transactions with matching account nonce.
            // Remove queued transactions the account might have. This includes old nonce
            // transactions that have become obsolete; those with an equal nonce should
            // already have been removed via fee escalation (`remove_replaced_tx`).
            self.tx_queue.remove_by_address(address);
            self.insert_to_tx_queue(tx_reference);
        }
    }

    fn add_ready_declares(&mut self) {
        let now = self.clock.now();
        while let Some((submission_time, _args)) = self.delayed_declares.front() {
            if now - self.config.static_config.declare_delay < *submission_time {
                break;
            }
            let (_submission_time, args) =
                self.delayed_declares.pop_front().expect("Delay declare should exist.");
            self.add_tx_inner(args);
        }
        self.update_state_metrics();
    }

    /// Update the mempool's internal state according to the committed block (resolves nonce gaps,
    /// updates account balances).
    #[instrument(skip(self, args))]
    pub fn commit_block(&mut self, args: CommitBlockArgs) {
        let CommitBlockArgs { address_to_nonce, rejected_tx_hashes } = args;
        debug!(
            "Committing block with {} addresses and {} rejected tx to the mempool.",
            address_to_nonce.len(),
            rejected_tx_hashes.len()
        );

        let mut committed_nonce_updates = AddressToNonce::new();
        // Align mempool data to committed nonces.
        for (&address, &next_nonce) in &address_to_nonce {
            self.validate_commitment(address, next_nonce);
            committed_nonce_updates.insert(address, next_nonce);

            // Remove out-of-date transactions, if any.
            // Note: In FIFO mode, get_nonce returns None (committed txs were already popped from
            // queue during get_txs), so this cleanup is skipped.
            if self
                .tx_queue
                .get_nonce(address)
                .is_some_and(|queued_nonce| queued_nonce != next_nonce)
            {
                assert!(
                    self.tx_queue.remove_by_address(address),
                    "Expected to remove address from queue."
                );
            }

            // Remove from pool.
            let n_removed_txs = self.tx_pool.remove_up_to_nonce_when_committed(address, next_nonce);
            metric_count_committed_txs(n_removed_txs);
            self.decrement_stuck_txs_if_gap_account(address, n_removed_txs);

            // Close nonce gap, if exists.
            // In FIFO mode, we handle gap filling when rewinding transactions.
            if !self.is_fifo() && self.tx_queue.get_nonce(address).is_none() {
                if let Some(tx_reference) =
                    self.tx_pool.get_by_address_and_nonce(address, next_nonce)
                {
                    self.insert_to_tx_queue(tx_reference);
                }
            }
        }

        // Commit block and rewind nonces of addresses that were not included in block.
        let addresses_to_rewind = self.state.commit(address_to_nonce.clone());

        let rewound_tx_hashes =
            self.rewind_txs(addresses_to_rewind, &address_to_nonce, &rejected_tx_hashes);
        debug!("Aligned mempool to committed nonces.");

        // Remove rejected transactions from the mempool.
        let mut account_nonce_updates =
            self.remove_rejected_txs(rejected_tx_hashes, &rewound_tx_hashes);

        // Committed nonces should overwrite rejected transactions.
        account_nonce_updates.extend(committed_nonce_updates);

        self.update_accounts_with_gap(account_nonce_updates);
        self.update_state_metrics();
    }

    pub fn account_tx_in_pool_or_recent_block(&self, account_address: ContractAddress) -> bool {
        self.state.contains_account(account_address)
            || self.tx_pool.contains_account(account_address)
    }

    fn validate_incoming_tx(
        &self,
        tx_reference: TransactionReference,
        incoming_account_nonce: Nonce,
    ) -> MempoolResult<()> {
        if self.tx_pool.get_by_tx_hash(tx_reference.tx_hash).is_ok() {
            return Err(MempoolError::DuplicateTransaction { tx_hash: tx_reference.tx_hash });
        }
        self.state.validate_incoming_tx(tx_reference, incoming_account_nonce)
    }

    /// Validates that the given transaction does not front run a delayed declare. This means in
    /// particular that no fee escalation can occur to a declare that is being delayed.
    fn validate_no_delayed_declare_front_run(
        &self,
        tx_reference: TransactionReference,
    ) -> MempoolResult<()> {
        if self.delayed_declares.contains(tx_reference.address, tx_reference.nonce) {
            return Err(MempoolError::DuplicateNonce {
                address: tx_reference.address,
                nonce: tx_reference.nonce,
            });
        }
        Ok(())
    }

    pub(crate) fn update_dynamic_config(&mut self, mempool_dynamic_config: MempoolDynamicConfig) {
        self.config.dynamic_config = mempool_dynamic_config;
    }

    fn validate_commitment(&self, address: ContractAddress, next_nonce: Nonce) {
        self.state.validate_commitment(address, next_nonce);
    }

    /// Updates the gas price threshold for transactions that are eligible for sequencing.
    pub fn update_gas_price(&mut self, threshold: GasPrice) {
        self.tx_queue.update_gas_price_threshold(threshold);
        self.update_state_metrics();
    }

    fn enqueue_next_eligible_txs(&mut self, txs: &[TransactionReference]) -> MempoolResult<()> {
        for tx in txs {
            let current_account_state = AccountState { address: tx.address, nonce: tx.nonce };

            if let Some(next_tx_reference) =
                self.tx_pool.get_next_eligible_tx(current_account_state)?
            {
                self.insert_to_tx_queue(next_tx_reference);
            }
        }

        Ok(())
    }

    /// Validates whether the incoming transaction may replace an existing one at the same
    /// `(address, nonce)` via fee escalation, without mutating any state. Returns the existing
    /// transaction to be replaced when a valid replacement exists, `None` when there is nothing to
    /// replace, or an error when a replacement is present but not permitted.
    fn validate_fee_escalation(
        &self,
        incoming_tx_reference: TransactionReference,
    ) -> MempoolResult<Option<TransactionReference>> {
        let TransactionReference { address, nonce, .. } = incoming_tx_reference;

        self.validate_no_delayed_declare_front_run(incoming_tx_reference)?;

        if !self.config.static_config.enable_fee_escalation {
            if self.tx_pool.get_by_address_and_nonce(address, nonce).is_some() {
                return Err(MempoolError::DuplicateNonce { address, nonce });
            };

            return Ok(None);
        }

        let Some(existing_tx_reference) = self.tx_pool.get_by_address_and_nonce(address, nonce)
        else {
            // Replacement irrelevant: no existing transaction with the same nonce for address.
            return Ok(None);
        };

        if !self.should_replace_tx(&existing_tx_reference, &incoming_tx_reference) {
            info!(
                "{existing_tx_reference} was not replaced by {incoming_tx_reference} due to \
                 insufficient fee escalation."
            );
            // TODO(Elin): consider adding a more specific error type / message.
            return Err(MempoolError::DuplicateNonce { address, nonce });
        }

        Ok(Some(existing_tx_reference))
    }

    /// Removes the existing transaction that is being replaced via fee escalation. Must be called
    /// only after the incoming replacement is guaranteed to be admitted, so the account is never
    /// left without a transaction at this nonce.
    fn remove_replaced_tx(&mut self, existing_tx_reference: TransactionReference) {
        debug!("{existing_tx_reference} is being replaced via fee escalation.");

        self.tx_queue.remove_txs(&[existing_tx_reference]);
        self.tx_pool
            .remove(existing_tx_reference.tx_hash)
            .expect("Transaction hash from pool must exist.");
        self.decrement_stuck_txs_if_gap_account(existing_tx_reference.address, 1);
    }

    fn should_replace_tx(
        &self,
        existing_tx: &TransactionReference,
        incoming_tx: &TransactionReference,
    ) -> bool {
        let [existing_tip, incoming_tip] =
            [existing_tx, incoming_tx].map(|tx| u128::from(tx.tip.0));
        let [existing_max_l2_gas_price, incoming_max_l2_gas_price] =
            [existing_tx, incoming_tx].map(|tx| tx.max_l2_gas_price.0);

        self.increased_enough(existing_tip, incoming_tip)
            && self.increased_enough(existing_max_l2_gas_price, incoming_max_l2_gas_price)
    }

    fn increased_enough(&self, existing_value: u128, incoming_value: u128) -> bool {
        let percentage = u128::from(self.config.static_config.fee_escalation_percentage);

        // Round up the required increase so any positive percentage always demands a strictly
        // higher fee, even for small values.
        let Some(escalation_qualified_value) = existing_value
            .checked_mul(percentage)
            .map(|scaled| scaled.div_ceil(100))
            .and_then(|required_increase| existing_value.checked_add(required_increase))
        else {
            // Overflow occurred during calculation; reject the transaction.
            return false;
        };

        incoming_value >= escalation_qualified_value
    }

    #[instrument(skip_all, parent = None)]
    fn log_and_count_expired_txs(&self, expired_txs: &[TransactionReference]) {
        if !expired_txs.is_empty() {
            metric_count_expired_txs(expired_txs.len());
            info!(
                "Removed expired transactions: {:?}",
                expired_txs.iter().map(|tx| tx.tx_hash).collect::<Vec<_>>()
            );
        }
    }

    fn remove_expired_txs(&mut self) -> AddressToNonce {
        let removed_txs = self
            .tx_pool
            .remove_txs_older_than(self.config.dynamic_config.transaction_ttl, &self.state.staged);

        for tx_ref in &removed_txs {
            self.decrement_stuck_txs_if_gap_account(tx_ref.address, 1);
        }

        // Drop gap accounts that expiry left with no pool txs. Their stuck txs are non-queued, so
        // the queued-tx map returned below never re-evaluates them; without this they
        // linger in `accounts_with_gap` (accounts_with_gap > 0 while stuck_txs == 0). Runs
        // after the decrement loop above: removing an account from the set early would make
        // its per-tx stuck decrements no-op.
        for tx_ref in &removed_txs {
            if !self.tx_pool.contains_account(tx_ref.address) {
                self.remove_from_accounts_with_gap(tx_ref.address);
            }
        }

        let queued_txs = self.tx_queue.remove_txs(&removed_txs);

        self.log_and_count_expired_txs(&removed_txs);
        self.update_state_metrics();
        queued_txs
            .into_iter()
            .map(|tx| (tx.address, self.state.resolve_nonce(tx.address, tx.nonce)))
            .collect::<AddressToNonce>()
    }

    /// Given a chunk of transactions, removes from the pool those that are old, and returns the
    /// remaining valid ones.
    /// Note: This function assumes that the given transactions were already removed from the queue.
    fn prune_expired_nonqueued_txs(
        &mut self,
        txs: Vec<TransactionReference>,
    ) -> (Vec<TransactionReference>, AddressToNonce) {
        // Divide the chunk into transactions that are old and no longer valid and those that
        // remain valid.
        let submission_cutoff_time = self.clock.now() - self.config.dynamic_config.transaction_ttl;
        let (old_txs, valid_txs): (Vec<_>, Vec<_>) = txs.into_iter().partition(|tx| {
            let submission_id = self
                .tx_pool
                .get_submission_id(tx.tx_hash)
                .expect("Transaction hash from queue must appear in pool.");
            submission_id.submission_time < submission_cutoff_time
        });

        // Remove old transactions from the pool.
        // Also remove from queue internals (relevant for FIFO staged rewind tracking).
        let _ = self.tx_queue.remove_txs(&old_txs);
        self.log_and_count_expired_txs(&old_txs);
        let account_nonce_updates: AddressToNonce = old_txs
            .into_iter()
            .map(|tx| {
                self.tx_pool
                    .remove(tx.tx_hash)
                    .expect("Transaction hash from queue must appear in pool.");
                self.decrement_stuck_txs_if_gap_account(tx.address, 1);
                (tx.address, self.state.resolve_nonce(tx.address, tx.nonce))
            })
            .collect();

        (valid_txs, account_nonce_updates)
    }

    pub fn mempool_snapshot(&self) -> MempoolResult<MempoolSnapshot> {
        Ok(MempoolSnapshot {
            transactions: self.tx_pool.chronological_txs_hashes(),
            delayed_declares: self
                .delayed_declares
                .elements
                .iter()
                .map(|(_, args)| args.tx.tx_hash)
                .collect(),
            transaction_queue: self.tx_queue.queue_snapshot(),
            mempool_state: self.state.state_snapshot(),
        })
    }

    fn size_in_bytes(&self) -> u64 {
        self.tx_pool.size_in_bytes() + self.delayed_declares.size_in_bytes()
    }

    fn decrement_stuck_txs_if_gap_account(&mut self, address: ContractAddress, n: usize) {
        if self.accounts_with_gap.contains(&address) {
            self.n_stuck_txs = self.n_stuck_txs.saturating_sub(n);
        }
    }

    // Removes address from the gap-account set and deducts its remaining pool txs from
    // n_stuck_txs. No-op if the address was not tracked.
    fn remove_from_accounts_with_gap(&mut self, address: ContractAddress) {
        if self.accounts_with_gap.swap_remove(&address) {
            self.n_stuck_txs =
                self.n_stuck_txs.saturating_sub(self.tx_pool.n_txs_for_address(address));
        }
    }

    // Returns true if adding the given transaction would exceed the mempool capacity, after
    // crediting `freed_bytes` that an accompanying removal (e.g. a fee-escalation replacement)
    // will free. `freed_bytes` is 0 when there is no such removal.
    fn exceeds_capacity(&self, tx: &InternalRpcTransaction, freed_bytes: u64) -> bool {
        // The to-be-removed transaction is still counted in `size_in_bytes()` here, so subtract
        // what its removal frees. `saturating_sub` guards the (impossible) underflow defensively.
        (self.size_in_bytes() + tx.total_bytes()).saturating_sub(freed_bytes)
            > self.config.static_config.capacity_in_bytes
    }

    fn update_accounts_with_gap(&mut self, address_to_nonce: AddressToNonce) {
        for (address, account_nonce) in address_to_nonce {
            // If a delayed declare transaction exists at the account nonce, it is next to execute,
            // so no gap exists.
            if self.delayed_declares.contains(address, account_nonce) {
                self.remove_from_accounts_with_gap(address);
                continue;
            }

            // Gap exists when lowest transaction nonce is higher than account nonce.
            let gap_exists = match self.tx_pool.get_lowest_nonce(address) {
                Some(lowest_nonce) => account_nonce < lowest_nonce,
                None => false, // No transactions for the account, so no gap.
            };

            // Update the eviction tracking set accordingly.
            if gap_exists {
                if self.accounts_with_gap.insert(address) {
                    // Newly entered gap: all current pool txs for this account are now stuck.
                    let n_stuck = self.tx_pool.n_txs_for_address(address);
                    self.n_stuck_txs += n_stuck;
                    warn!(
                        "Account {address} has a nonce gap; {n_stuck} transaction(s) are now \
                         stuck."
                    );
                }
                // Stayed in gap: per-tx deltas were already applied at add/remove sites.
            } else {
                // Left gap: remaining pool txs for this account are no longer stuck.
                self.remove_from_accounts_with_gap(address);
            }
        }
    }

    pub fn get_evictable_account(&self) -> Option<ContractAddress> {
        let len = self.accounts_with_gap.len();
        if len == 0 {
            return None;
        }
        let random_index = rng().random_range(0..len);
        self.accounts_with_gap.get_index(random_index).copied()
    }

    // Attempts to make space for a new transaction by evicting existing transactions.
    // Returns true if enough space was freed, false otherwise.
    pub fn try_make_space(&mut self, required_space: u64) -> bool {
        let mut total_space_freed = 0;
        let mut evicted_txs = Vec::new();

        while total_space_freed < required_space {
            let Some(address) = self.get_evictable_account() else {
                break;
            };

            let txs: Vec<_> = self.tx_pool.account_txs_sorted_by_nonce(address).copied().collect();
            for tx_ref in txs.iter().rev() {
                let tx = self
                    .tx_pool
                    .remove(tx_ref.tx_hash)
                    .expect("Transaction must exist in the pool.");
                total_space_freed += tx.total_bytes();
                evicted_txs.push(*tx_ref);
                metric_count_evicted_txs(1);
                self.decrement_stuck_txs_if_gap_account(address, 1);
                if total_space_freed >= required_space {
                    break;
                }
            }

            // Clean up if account is now empty.
            if !self.tx_pool.contains_account(address) {
                self.accounts_with_gap.swap_remove(&address);
            }
        }

        // Keep the queue consistent with the pool: the evicted txs were removed from the pool, so
        // drop their (now-orphaned) queue references too. In fee mode gap accounts are never
        // queued, so this is a no-op there; in Echonet/FIFO mode they are, and skipping this leaves
        // a dangling reference that panics the next `get_txs`.
        self.tx_queue.remove_txs(&evicted_txs);

        total_space_freed >= required_space
    }

    fn handle_capacity_overflow(
        &mut self,
        tx: &InternalRpcTransaction,
        account_nonce: Nonce,
        freed_bytes: u64,
    ) -> Result<(), MempoolError> {
        let address = tx.contract_address();

        let account_has_gap = self.accounts_with_gap.contains(&address);
        let account_has_txs = self.tx_pool.contains_account(address);
        let closing_gap = tx.nonce() == account_nonce;
        let creating_gap = (account_has_gap || !account_has_txs) && !closing_gap;

        // Only the net growth must be evicted: an accompanying replacement removal frees
        // `freed_bytes` (0 when there is no replacement).
        let required_space = tx.total_bytes().saturating_sub(freed_bytes);
        if !creating_gap && self.try_make_space(required_space) {
            return Ok(());
        }

        Err(MempoolError::MempoolFull)
    }

    #[cfg(test)]
    fn content(&self) -> MempoolContent {
        MempoolContent {
            tx_pool: self.tx_pool.tx_pool(),
            priority_txs: self.tx_queue.iter_over_ready_txs().cloned().collect(),
            pending_txs: self.tx_queue.pending_txs(),
        }
    }

    #[cfg(test)]
    fn accounts_with_gap(&self) -> &AccountsWithGap {
        &self.accounts_with_gap
    }

    #[cfg(test)]
    pub(crate) fn n_stuck_txs(&self) -> usize {
        self.n_stuck_txs
    }

    fn update_state_metrics(&self) {
        MEMPOOL_POOL_SIZE.set_lossy(self.tx_pool.len());
        MEMPOOL_PRIORITY_QUEUE_SIZE.set_lossy(self.tx_queue.priority_queue_len());
        MEMPOOL_PENDING_QUEUE_SIZE.set_lossy(self.tx_queue.pending_queue_len());
        MEMPOOL_DELAYED_DECLARES_SIZE.set_lossy(self.delayed_declares.len());
        MEMPOOL_TOTAL_SIZE_BYTES.set_lossy(self.size_in_bytes());
        MEMPOOL_ACCOUNTS_WITH_GAP.set_lossy(self.accounts_with_gap.len());
        MEMPOOL_STUCK_TXS.set_lossy(self.n_stuck_txs);
    }
}

#[cfg(test)]
#[derive(Debug, Default, PartialEq, Eq)]
struct MempoolContent {
    tx_pool: HashMap<TransactionHash, InternalRpcTransaction>,
    priority_txs: Vec<TransactionReference>,
    pending_txs: Vec<TransactionReference>,
}

/// Provides a lightweight representation of a transaction for mempool usage (e.g., excluding
/// execution fields).
/// TODO(Mohammad): rename this struct to `ThinTransaction` once that name
/// becomes available, to better reflect its purpose and usage.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TransactionReference {
    pub address: ContractAddress,
    pub nonce: Nonce,
    pub tx_hash: TransactionHash,
    pub tip: Tip,
    pub max_l2_gas_price: GasPrice,
}

impl TransactionReference {
    pub fn new(tx: &InternalRpcTransaction) -> Self {
        TransactionReference {
            address: tx.contract_address(),
            nonce: tx.nonce(),
            tx_hash: tx.tx_hash(),
            tip: tx.tip(),
            max_l2_gas_price: tx.resource_bounds().l2_gas.max_price_per_unit,
        }
    }
}

impl From<&ValidationArgs> for TransactionReference {
    fn from(args: &ValidationArgs) -> Self {
        TransactionReference {
            address: args.address,
            nonce: args.tx_nonce,
            tx_hash: args.tx_hash,
            tip: args.tip,
            max_l2_gas_price: args.max_l2_gas_price,
        }
    }
}

impl std::fmt::Display for TransactionReference {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let TransactionReference { address, nonce, tx_hash, tip, max_l2_gas_price } = self;
        write!(
            f,
            "TransactionReference {{ address: {address}, nonce: {nonce}, tx_hash: {tx_hash}, tip: \
             {tip}, max_l2_gas_price: {max_l2_gas_price} }}"
        )
    }
}
