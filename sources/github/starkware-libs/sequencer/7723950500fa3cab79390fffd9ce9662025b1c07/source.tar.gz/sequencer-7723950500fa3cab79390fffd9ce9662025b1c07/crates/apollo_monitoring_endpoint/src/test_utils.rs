use std::fmt::Debug;
use std::net::{IpAddr, SocketAddr};
use std::str::FromStr;

use anyhow::Result;
use apollo_infra_utils::run_until::run_until;
use apollo_infra_utils::tracing::{CustomLogger, TraceLevel};
use apollo_metrics::test_utils::parse_numeric_metric;
use axum::body::Body;
use axum::http::Request;
use http_body_util::BodyExt;
use hyper_util::client::legacy::connect::HttpConnector;
use hyper_util::client::legacy::Client;
use hyper_util::rt::TokioExecutor;
use num_traits::Num;
use thiserror::Error;
use tracing::info;

use crate::monitoring_endpoint::{ALIVE, METRICS, MONITORING_PREFIX};

#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum MonitoringClientError {
    #[error("Failed to connect, error details: {}", connection_error)]
    ConnectionError { connection_error: String },
    #[error("Erroneous status: {}", status)]
    ResponseStatusError { status: String },
    #[error("Missing metric name: {}", metric_name)]
    MetricNotFound { metric_name: String },
}

/// Client for querying 'alive' status of an http server.
pub struct MonitoringClient {
    socket: SocketAddr,
    client: Client<HttpConnector, Body>,
}

impl MonitoringClient {
    pub fn new(socket: SocketAddr) -> Self {
        let client = Client::builder(TokioExecutor::new()).build_http();
        Self { socket, client }
    }

    /// Returns 'true' if the server is 'alive'.
    async fn query_alive(&self) -> bool {
        info!("Querying the node for aliveness.");

        self.client
            .request(build_request(&self.socket.ip(), self.socket.port(), ALIVE))
            .await
            .is_ok_and(|response| response.status().is_success())
    }

    /// Blocks until 'alive', up to a maximum number of query attempts. Returns 'Ok(())' if the
    /// target is alive, otherwise 'Err(())'.
    pub async fn await_alive(&self, interval: u64, max_attempts: usize) -> Result<(), ()> {
        let condition = |node_is_alive: &bool| *node_is_alive;
        let query_alive_closure = || async move { self.query_alive().await };

        let logger =
            CustomLogger::new(TraceLevel::Info, Some("Waiting for node to be alive".to_string()));

        run_until(interval, max_attempts, query_alive_closure, condition, Some(logger))
            .await
            .ok_or(())
            .map(|_| ())
    }

    pub async fn get_metrics(&self) -> Result<String, MonitoringClientError> {
        let interval_ms = 200;
        let max_attempts = 25;

        let logger =
            CustomLogger::new(TraceLevel::Info, Some("Polling metrics endpoint".to_string()));

        let result = run_until(
            interval_ms,
            max_attempts,
            || async {
                self.client
                    .request(build_request(&self.socket.ip(), self.socket.port(), METRICS))
                    .await
            },
            |response_result| response_result.as_ref().is_ok_and(|res| res.status().is_success()),
            Some(logger),
        )
        .await;

        match result {
            Some(Ok(response)) => {
                // Parse the response body.
                let body_bytes = response.into_body().collect().await.unwrap().to_bytes();
                Ok(String::from_utf8(body_bytes.to_vec()).unwrap())
            }
            Some(Err(err)) => {
                Err(MonitoringClientError::ConnectionError { connection_error: err.to_string() })
            }
            None => Err(MonitoringClientError::ResponseStatusError {
                status: "Timeout or condition not met".into(),
            }),
        }
    }

    // TODO(Yael/Tsabary): add labels support
    pub async fn get_metric<T: Num + FromStr + Send + Debug + 'static>(
        &self,
        metric_name: &str,
    ) -> Result<T, MonitoringClientError> {
        // Todo(Tsabary): consider if these should be configurable.
        const INTERVAL_MS: u64 = 10;
        const MAX_ATTEMPTS: usize = 25;

        let logger = CustomLogger::new(
            TraceLevel::Info,
            Some(format!("Polling for metric '{}'", metric_name)),
        );

        // Todo(Tsabary): consider changing `run_until` to return a `Result` instead of an `Option`.
        let result = run_until(
            INTERVAL_MS,
            MAX_ATTEMPTS,
            || async {
                let body_string = self.get_metrics().await?;
                parse_numeric_metric::<T>(&body_string, metric_name, None).ok_or(
                    MonitoringClientError::MetricNotFound { metric_name: metric_name.to_string() },
                )
            },
            |result: &Result<T, MonitoringClientError>| result.is_ok(),
            Some(logger),
        )
        .await;

        result.unwrap_or(Err(MonitoringClientError::MetricNotFound {
            metric_name: metric_name.to_string(),
        }))
    }
}

pub(crate) fn build_request(ip: &IpAddr, port: u16, method: &str) -> Request<Body> {
    Request::builder()
        .uri(format!("http://{ip}:{port}/{MONITORING_PREFIX}/{method}").as_str())
        .body(Body::empty())
        .unwrap()
}

pub fn build_post_request(ip: &IpAddr, port: u16, method: &str) -> Request<Body> {
    Request::builder()
        .method("POST")
        .uri(format!("http://{ip}:{port}/{MONITORING_PREFIX}/{method}").as_str())
        .body(Body::empty())
        .unwrap()
}
