use std::collections::HashSet;

use apollo_consensus::metrics::IS_OBSERVER;
use apollo_metrics::metrics::MetricQueryName;
use serde::ser::SerializeStruct;
use serde::{Serialize, Serializer};
use strum::{EnumIter, IntoEnumIterator};

use crate::alert_placeholders::{
    ComparisonValueOrPlaceholder,
    ExpressionOrExpressionWithPlaceholder,
    SeverityValueOrPlaceholder,
};

pub(crate) const PENDING_DURATION_DEFAULT: &str = "30s";
pub(crate) const SECS_IN_MIN: u64 = 60;

/// Alerts to be configured in the dashboard.
#[derive(Debug)]
pub struct Alerts {
    alerts: Vec<Alert>,
}

impl Alerts {
    pub(crate) fn new(alerts: Vec<Alert>) -> Self {
        // Validate that there are no duplicate alert names.
        alerts
            .iter()
            .map(|alert| alert.name.as_str())
            .try_fold(HashSet::new(), |mut set, name| set.insert(name).then_some(set).ok_or(name))
            .unwrap_or_else(|duplicate| panic!("Duplicate alert name found: {duplicate}"));

        // Validate that there are no duplicate placeholder names across all alerts.
        alerts
            .iter()
            .flat_map(|alert| alert.get_placeholder_names().iter())
            .try_fold(HashSet::new(), |mut set, name| {
                set.insert(name.clone()).then_some(set).ok_or(name)
            })
            .unwrap_or_else(|duplicate| {
                panic!("Duplicate placeholder name found across alerts: {duplicate}")
            });

        // Sort alerts lexicographically by name within each group so the JSON output is stable.
        let mut alerts = alerts;
        alerts.sort_by(|a, b| a.alert_group.cmp(&b.alert_group).then(a.name.cmp(&b.name)));

        Self { alerts }
    }
}

impl Serialize for Alerts {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        #[derive(Serialize)]
        struct GroupDef {
            name: EvaluationRate,
            #[serde(rename = "intervalSec")]
            interval_sec: u64,
        }
        impl GroupDef {
            fn new(rate: EvaluationRate) -> Self {
                Self { interval_sec: rate.interval_sec(), name: rate }
            }
        }

        let groups: Vec<GroupDef> = EvaluationRate::iter().map(GroupDef::new).collect();

        let mut state = serializer.serialize_struct("Alerts", 2)?;
        state.serialize_field("groups", &groups)?;
        state.serialize_field("alerts", &self.alerts)?;
        state.end()
    }
}

#[derive(Debug, Serialize)]
pub(crate) enum AlertSeverity {
    /// Critical issues that demand immediate attention. These are high-impact incidents that
    /// affect the system's availability.
    #[serde(rename = "p1")]
    Sos,
    /// Standard alerts for production issues that require attention around the clock but are not
    /// as time-sensitive as SOS alerts.
    #[serde(rename = "p2")]
    Regular,
    /// Important alerts that do not require overnight attention. These are delayed during night
    /// hours to reduce unnecessary off-hours noise.
    #[serde(rename = "p3")]
    DayOnly,
    /// Alerts that are only triggered during official business hours. These do not trigger during
    /// holidays.
    #[serde(rename = "p4")]
    WorkingHours,
    /// Non-critical alerts, meant purely for information. These are not intended to wake anyone up
    /// and are monitored only by the development team.
    #[serde(rename = "p5")]
    Informational,
}

#[derive(Debug, Serialize)]
pub(crate) enum AlertComparisonOp {
    #[serde(rename = "gt")]
    GreaterThan,
    #[serde(rename = "lt")]
    LessThan,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum AlertLogicalOp {
    And,
}

/// Defines the condition to trigger the alert.
#[derive(Debug)]
pub(crate) struct AlertCondition {
    // The comparison operator to use when comparing the expression to the value.
    comparison_op: AlertComparisonOp,
    // The value to compare the expression to.
    comparison_value: ComparisonValueOrPlaceholder,
    // The logical operator between this condition and other conditions.
    // TODO(Yael): Consider moving this field to the be one per alert to avoid ambiguity when
    // trying to use a combination of `and` and `or` operators.
    logical_op: AlertLogicalOp,
}

impl AlertCondition {
    pub(crate) fn new(
        comparison_op: AlertComparisonOp,
        comparison_value: impl Into<ComparisonValueOrPlaceholder>,
        logical_op: AlertLogicalOp,
    ) -> Self {
        Self { comparison_op, comparison_value: comparison_value.into(), logical_op }
    }

    pub(crate) fn get_comparison_value_placeholder_name(&self) -> Option<String> {
        match &self.comparison_value {
            ComparisonValueOrPlaceholder::Placeholder(_) => {
                self.comparison_value.unique_alert_placeholder_name()
            }
            ComparisonValueOrPlaceholder::ConcreteValue(_) => None,
        }
    }
}

impl Serialize for AlertCondition {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut state = serializer.serialize_struct("AlertCondition", 4)?;

        state.serialize_field(
            "evaluator",
            &serde_json::json!({
                "params": [self.comparison_value],
                "type": self.comparison_op
            }),
        )?;

        state.serialize_field(
            "operator",
            &serde_json::json!({
                "type": self.logical_op
            }),
        )?;

        state.serialize_field(
            "reducer",
            &serde_json::json!({
                "params": [],
                "type": "avg"
            }),
        )?;

        state.serialize_field("type", "query")?;

        state.end()
    }
}

/// Determines which Grafana rule group an alert belongs to, which controls its evaluation
/// rate — the cadence at which Grafana checks the alert condition.
///
/// Variants are ordered alphabetically by their serialized name so that deriving `Ord` produces
/// the same stable sort used when grouping alerts in the JSON output.
#[derive(Debug, EnumIter, Eq, Ord, PartialEq, PartialOrd, Serialize)]
pub(crate) enum EvaluationRate {
    /// Evaluated every 30 seconds. The default cadence for most production alerts.
    #[serde(rename = "evaluation_rate_default")]
    Default,
    /// Evaluated every 10 seconds. For critical infrastructure state that must be detected
    /// near-immediately (e.g., pod readiness).
    #[serde(rename = "evaluation_rate_high")]
    High,
    /// Evaluated every 60 seconds. Reserved for low-urgency background checks.
    #[serde(rename = "evaluation_rate_low")]
    Low,
}

impl EvaluationRate {
    pub(crate) fn interval_sec(&self) -> u64 {
        match self {
            Self::High => 10,
            Self::Default => 30,
            Self::Low => 60,
        }
    }
}

/// Describes the properties of an alert defined in grafana.
#[derive(Debug, Serialize)]
pub(crate) struct Alert {
    // The name of the alert.
    name: String,
    // The title that will be displayed.
    title: String,
    // The evaluation group this alert belongs to, which sets its check interval.
    #[serde(rename = "ruleGroup")]
    alert_group: EvaluationRate,
    // The expression to evaluate for the alert.
    expr: ExpressionOrExpressionWithPlaceholder,
    // The conditions that must be met for the alert to be triggered.
    conditions: Vec<AlertCondition>,
    // The time duration for which the alert conditions must be true before an alert is triggered.
    #[serde(rename = "for")]
    pending_duration: String,
    // The severity level of the alert.
    severity: SeverityValueOrPlaceholder,
    #[serde(skip)]
    placeholder_names: HashSet<String>,
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) enum ObserverApplicability {
    Applicable,
    NotApplicable,
}

impl Alert {
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn new(
        name: impl ToString,
        title: impl ToString,
        alert_group: EvaluationRate,
        expr: impl Into<ExpressionOrExpressionWithPlaceholder>,
        conditions: Vec<AlertCondition>,
        pending_duration: impl ToString,
        severity: impl Into<SeverityValueOrPlaceholder>,
        observer_applicable: ObserverApplicability,
    ) -> Self {
        let severity = severity.into();

        // Collect all placeholder names from the conditions and severity field.
        let severity_placeholder = severity.unique_alert_placeholder_name();

        // Extract the expression and the placeholder names from the expression field.
        let expr = expr.into();
        let expr_placeholder_names = expr.unique_alert_placeholder_name();

        // Validate there are no duplicate placeholder names.
        let placeholder_names = conditions
            .iter()
            .filter_map(|condition| condition.get_comparison_value_placeholder_name())
            .chain(severity_placeholder)
            .chain(expr_placeholder_names.into_iter().flatten())
            .try_fold(HashSet::new(), |mut set, name| {
                set.insert(name.clone()).then_some(set).ok_or(name)
            })
            .unwrap_or_else(|duplicate| panic!("Duplicate placeholder name found: {duplicate}"));

        // Encode the observer-applicability directly into the expression, so the alert condition
        // itself filters out observer nodes.
        let expr = match observer_applicable {
            ObserverApplicability::Applicable => expr,
            ObserverApplicability::NotApplicable => {
                ExpressionOrExpressionWithPlaceholder::ConcreteValue(format!(
                    // `and on()` ignores label sets so the unlabeled scalar produced by
                    // aggregations like sum() still matches the pod-labeled is_observer series.
                    "({}) and on() ({} == 0)",
                    expr.to_alert_promql(),
                    IS_OBSERVER.get_name_with_filter(),
                ))
            }
        };

        Self {
            name: name.to_string(),
            title: title.to_string(),
            alert_group,
            expr,
            conditions,
            pending_duration: pending_duration.to_string(),
            severity,
            placeholder_names,
        }
    }

    /// Keeps the rule defined when its series are absent, so a scrape gap leaves the alert in
    /// `Normal` instead of raising a notifying `DatasourceNoData`. The fallback is appended after
    /// the observer guard, which would otherwise erase it once `is_observer` goes stale in the
    /// same gap. `value` must be `>=` the alert threshold, or the rule fires permanently. The
    /// expression must aggregate away its labels, or `or` cannot suppress the fallback while data
    /// is present.
    pub(crate) fn with_no_data_fallback(mut self, value: f64) -> Self {
        self.expr = ExpressionOrExpressionWithPlaceholder::ConcreteValue(format!(
            "({}) or vector({})",
            self.expr.to_alert_promql(),
            value
        ));
        self
    }

    pub(crate) fn get_placeholder_names(&self) -> &HashSet<String> {
        &self.placeholder_names
    }
}
