use apollo_batcher::metrics::{
    BATCHER_CLASS_CACHE_METRICS,
    BATCHER_VIEW_CALL_CLASS_CACHE_METRICS,
    L2_GAS_IN_LAST_BLOCK,
    NUM_TRANSACTION_IN_BLOCK,
    PROVING_GAS_IN_LAST_BLOCK,
    SIERRA_GAS_IN_LAST_BLOCK,
};
use apollo_gateway::metrics::GATEWAY_CLASS_CACHE_METRICS;
use apollo_metrics::metrics::MetricQueryName;
use blockifier::metrics::{
    CacheMetrics,
    BLOCKIFIER_METRIC_RATE_DURATION,
    BLOCKS_FULL_BY_RESOURCE,
    CALLS_RUNNING_NATIVE,
    LABEL_NAME_BLOCK_FULL_RESOURCE,
    NATIVE_CLASS_RETURNED,
    NATIVE_COMPILATION_ERROR,
    TOTAL_CALLS,
};

use crate::dashboard::Row;
use crate::panel::{Panel, PanelType};
use crate::query_builder::{sum_by_label, DisplayMethod, DEFAULT_DURATION};

const DENOMINATOR_DIVISOR_FOR_READABILITY: f64 = 1_000_000_000.0;

/// `source` names the reader the metrics count, since one scope may have several: the batcher
/// counts block production and view calls separately over the same cache.
fn get_panel_blockifier_state_reader_class_cache_miss_ratio(
    class_cache_metrics: &CacheMetrics,
    source: &str,
) -> Panel {
    class_cache_metrics.validate_scope();

    let name = format!("Class Cache Miss in {source}");
    let description = format!(
        "The ratio of cache misses when requesting compiled classes from the Blockifier State \
         Reader in {source}"
    );
    Panel::ratio_time_series(
        name.as_str(),
        description.as_str(),
        class_cache_metrics.misses(),
        &[class_cache_metrics.misses(), class_cache_metrics.hits()],
        BLOCKIFIER_METRIC_RATE_DURATION,
    )
}

fn get_panel_blockifier_state_reader_native_class_returned_ratio() -> Panel {
    let name = "Native Class Returned Ratio in Batcher";
    let description = "The ratio of Native classes returned by the Blockifier in Batcher";
    // `NATIVE_CLASS_RETURNED` counts every class the batcher's state readers return, so the
    // denominator sums the cache traffic of all of them.
    Panel::ratio_time_series(
        name,
        description,
        &NATIVE_CLASS_RETURNED,
        &[
            BATCHER_CLASS_CACHE_METRICS.misses(),
            BATCHER_CLASS_CACHE_METRICS.hits(),
            BATCHER_VIEW_CALL_CLASS_CACHE_METRICS.misses(),
            BATCHER_VIEW_CALL_CLASS_CACHE_METRICS.hits(),
        ],
        BLOCKIFIER_METRIC_RATE_DURATION,
    )
}

fn get_panel_native_compilation_error() -> Panel {
    Panel::new(
        "Native compilation error count",
        "Count of the number of times there was a native compilation error",
        NATIVE_COMPILATION_ERROR.get_name_with_filter().to_string(),
        PanelType::Stat,
    )
}

fn get_panel_native_execution_ratio() -> Panel {
    Panel::ratio_time_series(
        "Native Execution Ratio",
        "The ratio of calls running Cairo Native in the Blockifier",
        &CALLS_RUNNING_NATIVE,
        &[&TOTAL_CALLS],
        BLOCKIFIER_METRIC_RATE_DURATION,
    )
}

fn get_panel_blocks_full_by_resource() -> Panel {
    Panel::new(
        "Blocks Full By Resource",
        format!("Number of blocks closed on each bouncer resource ({} window)", DEFAULT_DURATION),
        sum_by_label(
            &BLOCKS_FULL_BY_RESOURCE,
            LABEL_NAME_BLOCK_FULL_RESOURCE,
            DisplayMethod::Increase(DEFAULT_DURATION),
            false,
        ),
        PanelType::Stat,
    )
}

fn get_panel_transactions_per_block() -> Panel {
    Panel::from_hist(
        &NUM_TRANSACTION_IN_BLOCK,
        "Transactions Per Block",
        "The number of transactions per block",
    )
}

fn get_panel_sierra_gas_in_last_block() -> Panel {
    Panel::new(
        "Average Sierra Gas Usage in Block",
        "The average sierra gas usage in block (10m window)",
        format!(
            "avg_over_time({}[10m])/{}",
            SIERRA_GAS_IN_LAST_BLOCK.get_name_with_filter(),
            DENOMINATOR_DIVISOR_FOR_READABILITY
        ),
        PanelType::TimeSeries,
    )
}

fn get_panel_proving_gas_in_last_block() -> Panel {
    Panel::new(
        "Average Proving Gas Usage in Block",
        "The average proving gas usage in block (10m window)",
        format!(
            "avg_over_time({}[10m])/{}",
            PROVING_GAS_IN_LAST_BLOCK.get_name_with_filter(),
            DENOMINATOR_DIVISOR_FOR_READABILITY
        ),
        PanelType::TimeSeries,
    )
}

fn get_panel_l2_gas_used_in_last_block() -> Panel {
    Panel::new(
        "Average L2 Gas Usage in Block",
        "The average L2 gas usage in block (10m window)",
        format!(
            "avg_over_time({}[10m])/{}",
            L2_GAS_IN_LAST_BLOCK.get_name_with_filter(),
            DENOMINATOR_DIVISOR_FOR_READABILITY
        ),
        PanelType::TimeSeries,
    )
}

pub(crate) fn get_blockifier_row() -> Row {
    Row::new(
        "Blockifier",
        vec![
            get_panel_blockifier_state_reader_class_cache_miss_ratio(
                &BATCHER_CLASS_CACHE_METRICS,
                "Batcher",
            ),
            // TODO(Arni): Add native class returned ratio for gateway
            get_panel_blockifier_state_reader_native_class_returned_ratio(),
            get_panel_blockifier_state_reader_class_cache_miss_ratio(
                &GATEWAY_CLASS_CACHE_METRICS,
                "Gateway",
            ),
            get_panel_blockifier_state_reader_class_cache_miss_ratio(
                &BATCHER_VIEW_CALL_CLASS_CACHE_METRICS,
                "Batcher View Calls",
            ),
            get_panel_native_compilation_error(),
            get_panel_native_execution_ratio(),
            get_panel_blocks_full_by_resource(),
            get_panel_transactions_per_block(),
            get_panel_sierra_gas_in_last_block(),
            get_panel_proving_gas_in_last_block(),
            get_panel_l2_gas_used_in_last_block(),
        ],
    )
}
