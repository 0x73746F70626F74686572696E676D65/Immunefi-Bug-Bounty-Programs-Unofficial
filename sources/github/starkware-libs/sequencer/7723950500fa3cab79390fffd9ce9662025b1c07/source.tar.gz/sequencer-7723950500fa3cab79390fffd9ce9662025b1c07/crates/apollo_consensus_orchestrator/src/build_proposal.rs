#[cfg(test)]
#[path = "build_proposal_test.rs"]
mod build_proposal_test;
use std::borrow::BorrowMut;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use apollo_batcher_types::batcher_types::{
    FinishedProposalInfo,
    GetProposalContent,
    GetProposalContentInput,
    ProposalId,
    ProposeBlockInput,
};
use apollo_batcher_types::communication::{BatcherClient, BatcherClientError};
use apollo_consensus::types::{ProposalCommitment, Round};
use apollo_consensus_orchestrator_config::config::PricePerHeight;
use apollo_l1_gas_price_types::errors::{ExchangeRateOracleClientError, L1GasPriceClientError};
use apollo_protobuf::consensus::{
    BuildParam,
    CommitmentParts,
    L2GasInfo,
    ProposalFin,
    ProposalFinPayload,
    ProposalInit,
    ProposalPart,
    TransactionBatch,
};
use apollo_time::time::{Clock, DateTime};
use apollo_transaction_converter::TransactionConverterError;
use starknet_api::block::{GasPrice, ReplayBlockMetadata};
use starknet_api::consensus_transaction::InternalConsensusTransaction;
use starknet_api::core::ContractAddress;
use starknet_api::data_availability::L1DataAvailabilityMode;
use starknet_api::transaction::TransactionHash;
use starknet_api::versioned_constants_logic::effective_starknet_version;
use starknet_api::StarknetApiError;
use strum::{EnumDiscriminants, EnumIter, IntoStaticStr, VariantNames};
use tokio_util::sync::CancellationToken;
use tokio_util::task::AbortOnDropHandle;
use tracing::{debug, info, trace, warn};

use crate::dynamic_gas_price::proposal_commitment_from;
use crate::fee_market::calculate_next_l2_gas_price_for_fin;
use crate::sequencer_consensus_context::{BuiltProposals, SequencerConsensusContextDeps};
use crate::utils::{
    convert_to_sn_api_block_info,
    expected_version_constant_commitment,
    get_l1_prices_in_fri_and_wei,
    truncate_to_executed_txs,
    verify_retrospective_state_commitment_infos,
    wait_for_retrospective_block_hash,
    GasPriceParams,
    L1PricesInFri,
    L1PricesInWei,
    PreviousProposalInitInfo,
    RetrospectiveBlockHashError,
    RetrospectiveStateCommitmentInfosError,
    StreamSender,
};

// Minimal wait time that avoids an immediate timeout.
const MIN_WAIT_DURATION: Duration = Duration::from_millis(1);
pub(crate) struct ProposalBuildArguments {
    pub deps: SequencerConsensusContextDeps,
    pub batcher_deadline: DateTime,
    pub build_param: BuildParam,
    pub l1_da_mode: L1DataAvailabilityMode,
    pub stream_sender: StreamSender,
    pub gas_price_params: GasPriceParams,
    pub valid_proposals: Arc<Mutex<BuiltProposals>>,
    pub proposal_id: ProposalId,
    pub cende_write_success: AbortOnDropHandle<bool>,
    pub l2_gas_price: GasPrice,
    pub builder_address: ContractAddress,
    pub cancel_token: CancellationToken,
    pub previous_proposal_init: Option<PreviousProposalInitInfo>,
    pub proposal_round: Round,
    pub retrospective_block_hash_deadline: DateTime,
    pub retrospective_block_hash_retry_interval_millis: Duration,
    // If true (Echonet mode), build the proposal from the replayed block's metadata (timestamp
    // and gas prices) instead of the clock and the gas price provider.
    pub override_block_metadata: bool,
    pub override_l2_gas_price_fri: Option<u128>,
    pub min_l2_gas_price_per_height: Vec<PricePerHeight>,
    pub compare_retrospective_block_hash: bool,
    /// Proposer's fee_proposal for this block.
    pub fee_proposal: GasPrice,
    /// Current fee_actual from the sliding window.
    pub fee_actual: Option<GasPrice>,
}

type BuildProposalResult<T> = Result<T, BuildProposalError>;

#[derive(Debug, thiserror::Error, EnumDiscriminants)]
#[strum_discriminants(
    name(BuildProposalFailureReasonLabelValue),
    derive(IntoStaticStr, EnumIter, VariantNames),
    strum(serialize_all = "snake_case")
)]
pub(crate) enum BuildProposalError {
    #[error("Batcher error: {0}")]
    Batcher(String, BatcherClientError),
    #[error(transparent)]
    RetrospectiveBlockHashError(#[from] RetrospectiveBlockHashError),
    #[error(transparent)]
    RetrospectiveStateCommitmentInfosError(#[from] RetrospectiveStateCommitmentInfosError),
    #[error("Failed to send proposal part: {0}")]
    SendError(String),
    #[error("ExchangeRateOracle error: {0}")]
    ExchangeRateOracle(#[from] ExchangeRateOracleClientError),
    #[error("L1GasPriceProvider error: {0}")]
    L1GasPriceProvider(#[from] L1GasPriceClientError),
    #[error("Proposal interrupted.")]
    Interrupted,
    // TODO(shahak): Add the CENDE_FAILURE warn logs into the error and erase them.
    #[error(
        "Writing blob to Aerospike failed. {0}. For more info search CENDE_FAILURE in the logs"
    )]
    CendeWriteError(String),
    #[error("Failed to convert transactions: {0}")]
    TransactionConverterError(#[from] TransactionConverterError),
    #[error("ProposalInit conversion error: {0}")]
    ProposalInitConversion(#[from] StarknetApiError),
}

// Handles building a new proposal without blocking consensus:
pub(crate) async fn build_proposal(
    mut args: ProposalBuildArguments,
) -> BuildProposalResult<ProposalCommitment> {
    let init = initiate_build(&mut args).await?;

    args.stream_sender
        .send(ProposalPart::Init(init.clone()))
        .await
        .map_err(|e| BuildProposalError::SendError(format!("Failed to send init: {e:?}")))?;

    let (proposal_commitment, content, finished_info) = get_proposal_content(&mut args).await?;

    // Update valid_proposals before sending fin to avoid a race condition
    // with `repropose` being called before `valid_proposals` is updated.
    let mut valid_proposals = args.valid_proposals.lock().expect("Lock was poisoned");
    valid_proposals.insert_proposal(init, content, &args.proposal_id, finished_info);
    Ok(proposal_commitment)
}

async fn get_proposal_metadata(
    override_block_metadata: bool,
    batcher: &dyn BatcherClient,
    clock: &dyn Clock,
) -> ReplayBlockMetadata {
    if override_block_metadata {
        match batcher.start_round().await {
            Ok(block_metadata) => return block_metadata,
            Err(err) => {
                warn!(
                    "Failed to get block metadata from batcher, falling back to the clock \
                     timestamp and zero gas prices: {err:?}"
                );
            }
        }
    }
    ReplayBlockMetadata { timestamp: clock.unix_now(), ..Default::default() }
}

async fn initiate_build(args: &mut ProposalBuildArguments) -> BuildProposalResult<ProposalInit> {
    let proposal_metadata = get_proposal_metadata(
        args.override_block_metadata,
        args.deps.batcher.as_ref(),
        args.deps.clock.as_ref(),
    )
    .await;
    let timestamp = proposal_metadata.timestamp;
    let (l1_prices_fri, l1_prices_wei, l2_gas_price_fri) = if args.override_block_metadata {
        info!(
            "Building proposal for height {} from replayed block metadata: {proposal_metadata:?}",
            args.build_param.height,
        );
        (
            L1PricesInFri {
                l1_gas_price: proposal_metadata.l1_gas_price_fri,
                l1_data_gas_price: proposal_metadata.l1_data_gas_price_fri,
            },
            L1PricesInWei {
                l1_gas_price: proposal_metadata.l1_gas_price_wei,
                l1_data_gas_price: proposal_metadata.l1_data_gas_price_wei,
            },
            proposal_metadata.l2_gas_price_fri,
        )
    } else {
        let (l1_prices_fri, l1_prices_wei) = get_l1_prices_in_fri_and_wei(
            args.deps.l1_gas_price_provider.clone(),
            timestamp,
            args.previous_proposal_init.as_ref(),
            &args.gas_price_params,
        )
        .await;
        (l1_prices_fri, l1_prices_wei, args.l2_gas_price)
    };
    let init = ProposalInit {
        height: args.build_param.height,
        round: args.build_param.round,
        valid_round: args.build_param.valid_round,
        proposer: args.build_param.proposer,
        builder: args.builder_address,
        timestamp,
        l1_da_mode: args.l1_da_mode,
        l2_gas_price_fri,
        l1_gas_price_wei: l1_prices_wei.l1_gas_price,
        l1_data_gas_price_wei: l1_prices_wei.l1_data_gas_price,
        l1_gas_price_fri: l1_prices_fri.l1_gas_price,
        l1_data_gas_price_fri: l1_prices_fri.l1_data_gas_price,
        starknet_version: effective_starknet_version(),
        // TODO(Asmaa): Put the real value once we have it.
        // Sentinel until then; see `expected_version_constant_commitment` for why this is the
        // single source of truth shared with the validator.
        version_constant_commitment: expected_version_constant_commitment(),
        fee_proposal_fri: Some(args.fee_proposal),
    };

    let retrospective_block_hash = wait_for_retrospective_block_hash(
        args.deps.batcher.clone(),
        args.deps.state_sync_client.clone(),
        &init,
        args.deps.clock.as_ref(),
        args.retrospective_block_hash_deadline,
        args.retrospective_block_hash_retry_interval_millis,
        args.compare_retrospective_block_hash,
    )
    .await?;

    // Make sure the blob of this height will carry the next height's retrospective commitment
    // infos.
    verify_retrospective_state_commitment_infos(
        args.deps.batcher.as_ref(),
        args.deps.cende_ambassador.as_ref(),
        init.height,
    )
    .await?;

    let build_proposal_input = ProposeBlockInput {
        proposal_id: args.proposal_id,
        deadline: args.batcher_deadline,
        retrospective_block_hash,
        block_info: convert_to_sn_api_block_info(&init)?,
        proposal_round: args.proposal_round,
    };
    debug!("Initiating build proposal: {build_proposal_input:?}");
    args.deps.batcher.propose_block(build_proposal_input.clone()).await.map_err(|err| {
        BuildProposalError::Batcher(
            format!("Failed to initiate build proposal {build_proposal_input:?}."),
            err,
        )
    })?;
    Ok(init)
}
/// 1. Receive chunks of content from the batcher.
/// 2. Forward these to the stream handler to be streamed out to the network.
/// 3. Once finished, receive the commitment from the batcher.
async fn get_proposal_content(
    args: &mut ProposalBuildArguments,
) -> BuildProposalResult<(
    ProposalCommitment,
    Vec<Vec<InternalConsensusTransaction>>,
    FinishedProposalInfo,
)> {
    let mut content = Vec::new();
    loop {
        if args.cancel_token.is_cancelled() {
            return Err(BuildProposalError::Interrupted);
        }
        // We currently want one part of the node failing to cause all components to fail. If this
        // changes, we can simply return None and consider this as a failed proposal which consensus
        // should support.
        let response = args
            .deps
            .batcher
            .get_proposal_content(GetProposalContentInput { proposal_id: args.proposal_id })
            .await
            .map_err(|err| {
                BuildProposalError::Batcher(
                    format!("Failed to get proposal content for proposal_id {}.", args.proposal_id),
                    err,
                )
            })?;

        match response.content {
            GetProposalContent::Txs(txs) => {
                content.push(txs.clone());
                // TODO(matan): Make sure this isn't too large for a single proto message.
                debug!(
                    hashes = ?txs.iter().map(|tx| tx.tx_hash()).collect::<Vec<TransactionHash>>(),
                    "Sending transaction batch with {} txs.",
                    txs.len()
                );
                let transactions = futures::future::join_all(txs.into_iter().map(|tx| {
                    args.deps
                        .transaction_converter
                        .convert_internal_consensus_tx_to_consensus_tx(tx)
                }))
                .await
                .into_iter()
                .collect::<Result<Vec<_>, _>>()?;

                trace!(?transactions, "Sending transaction batch with {} txs.", transactions.len());
                args.stream_sender
                    .send(ProposalPart::Transactions(TransactionBatch { transactions }))
                    .await
                    .map_err(|e| {
                        BuildProposalError::SendError(format!(
                            "Failed to send transaction batch: {e:?}"
                        ))
                    })?;
            }
            GetProposalContent::Finished(info) => {
                let proposal_commitment = proposal_commitment_from(
                    info.proposal_commitment.partial_block_hash,
                    Some(args.fee_proposal),
                );
                content = truncate_to_executed_txs(&mut content, info.final_n_executed_txs);

                info!(
                    ?proposal_commitment,
                    num_txs = info.final_n_executed_txs,
                    "Finished building proposal",
                );
                if info.final_n_executed_txs == 0 {
                    warn!("Built an empty proposal.");
                }

                // If the blob writing operation to Aerospike doesn't return a success status, we
                // can't finish the proposal. Must wait for it at least until batcher_timeout is
                // reached.
                let remaining_duration = (args.batcher_deadline - args.deps.clock.now())
                    .to_std()
                    .unwrap_or_default()
                    .max(MIN_WAIT_DURATION); // Ensure we wait at least 1 ms to avoid immediate timeout.
                match tokio::time::timeout(
                    remaining_duration,
                    args.cende_write_success.borrow_mut(),
                )
                .await
                {
                    Err(_) => {
                        return Err(BuildProposalError::CendeWriteError(
                            "Writing blob to Aerospike didn't return in time.".to_string(),
                        ));
                    }
                    Ok(Ok(true)) => {
                        info!("Writing blob to Aerospike completed successfully.");
                    }
                    Ok(Ok(false)) => {
                        return Err(BuildProposalError::CendeWriteError(
                            "Writing blob to Aerospike failed.".to_string(),
                        ));
                    }
                    Ok(Err(e)) => {
                        return Err(BuildProposalError::CendeWriteError(e.to_string()));
                    }
                }

                let executed_transaction_count: u64 = info
                    .final_n_executed_txs
                    .try_into()
                    .expect("Number of executed transactions should fit in u64");
                let next_l2_gas_price = calculate_next_l2_gas_price_for_fin(
                    args.l2_gas_price,
                    args.build_param.height,
                    info.l2_gas_used,
                    args.override_l2_gas_price_fri,
                    &args.min_l2_gas_price_per_height,
                    args.fee_actual,
                )
                .published_price;
                let fin_payload = ProposalFinPayload {
                    commitment_parts: CommitmentParts::from(&info),
                    l2_gas_info: L2GasInfo {
                        next_l2_gas_price_fri: next_l2_gas_price,
                        l2_gas_used: info.l2_gas_used,
                    },
                };
                let fin = ProposalFin {
                    proposal_commitment,
                    executed_transaction_count,
                    fin_payload: Some(fin_payload),
                };
                info!("Sending fin={fin:?}");
                args.stream_sender.send(ProposalPart::Fin(fin)).await.map_err(|e| {
                    BuildProposalError::SendError(format!("Failed to send proposal fin: {e:?}"))
                })?;
                return Ok((proposal_commitment, content, info));
            }
        }
    }
}
