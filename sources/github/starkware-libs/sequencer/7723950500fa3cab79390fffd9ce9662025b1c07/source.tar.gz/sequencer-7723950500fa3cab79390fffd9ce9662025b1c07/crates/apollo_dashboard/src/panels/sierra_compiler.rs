use apollo_class_manager::metrics::{CLASS_SIZES, N_CLASSES};
use apollo_compile_to_casm::metrics::COMPILATION_DURATION;

use crate::dashboard::Row;
use crate::panel::{Panel, PanelType, Unit};
use crate::query_builder::{sum_by_label, DisplayMethod, DEFAULT_DURATION};

// Class compilation is a rare event, so we use a longer histogram range to capture enough data
// points.
const HISTOGRAM_RANGE: &str = "2h";

fn get_panel_compilation_duration() -> Panel {
    Panel::from_hist_with_range(
        &COMPILATION_DURATION,
        "Compile to Casm Compilation Duration",
        "Server-side compilation of Sierra to Casm duration",
        HISTOGRAM_RANGE,
    )
    .with_unit(Unit::Seconds)
}
fn get_panel_n_classes() -> Panel {
    Panel::new(
        "Number of Classes",
        format!(
            "Number of classes, labeled by type (regular, deprecated) ({DEFAULT_DURATION} window)"
        ),
        sum_by_label(&N_CLASSES, "class_type", DisplayMethod::Increase(DEFAULT_DURATION), false),
        PanelType::Stat,
    )
}
fn get_panel_class_sizes() -> Panel {
    Panel::from_labeled_hist(
        &CLASS_SIZES,
        "Class Sizes",
        "Size of the classes in bytes, labeled by type (sierra, casm, deprecated casm)",
        HISTOGRAM_RANGE,
    )
    .with_unit(Unit::MB)
}

pub(crate) fn get_compile_to_casm_row() -> Row {
    Row::new(
        "Class Manager",
        vec![get_panel_compilation_duration(), get_panel_n_classes(), get_panel_class_sizes()],
    )
}
