use apollo_config::converters::{
    serialize_optional_list_with_url_and_headers,
    serialize_optional_vec_u8,
    serialize_slice,
    UrlAndHeaders,
};
use serde::{Serialize, Serializer};
use url::Url;

#[derive(Serialize)]
pub struct SecretsConfigOverride {
    #[serde(
        rename = "base_layer_config.ordered_l1_endpoint_urls",
        serialize_with = "serialize_slice_wrapper"
    )]
    base_layer_config_ordered_l1_endpoint_urls: Vec<Url>,
    #[serde(
        rename = "consensus_manager_config.network_config.secret_key",
        serialize_with = "serialize_optional_vec_u8_wrapper"
    )]
    consensus_manager_config_network_config_secret_key: Option<Vec<u8>>,
    #[serde(
        rename = "l1_gas_price_provider_config.eth_to_strk_oracle_config.url_header_list",
        serialize_with = "serialize_optional_list_with_url_and_headers_wrapper"
    )]
    l1_gas_price_provider_config_config_eth_to_strk_oracle_config_url_header_list:
        Option<Vec<UrlAndHeaders>>,
    #[serde(
        rename = "l1_gas_price_provider_config.strk_to_usd_oracle_config.url_header_list",
        serialize_with = "serialize_optional_list_with_url_and_headers_wrapper"
    )]
    l1_gas_price_provider_config_config_strk_to_usd_oracle_config_url_header_list:
        Option<Vec<UrlAndHeaders>>,
    #[serde(
        rename = "mempool_p2p_config.network_config.secret_key",
        serialize_with = "serialize_optional_vec_u8_wrapper"
    )]
    mempool_p2p_config_network_config_secret_key: Option<Vec<u8>>,
    #[serde(rename = "state_sync_config.static_config.central_sync_client_config.\
                      central_source_config.http_headers")]
    state_sync_config_central_sync_client_config_central_source_config_http_headers: String,
    #[serde(
        rename = "state_sync_config.static_config.network_config.secret_key",
        serialize_with = "serialize_optional_vec_u8_wrapper"
    )]
    state_sync_config_network_config_secret_key: Option<Vec<u8>>,
}

impl Default for SecretsConfigOverride {
    fn default() -> Self {
        Self {
            base_layer_config_ordered_l1_endpoint_urls: vec![
                Url::parse("https://arbitrary.ordered_l1_endpoint_1.url").unwrap(),
                Url::parse("https://arbitrary.ordered_l1_endpoint_2.url").unwrap(),
            ],
            consensus_manager_config_network_config_secret_key: None,
            l1_gas_price_provider_config_config_eth_to_strk_oracle_config_url_header_list: Some(
                vec![UrlAndHeaders {
                    url: Url::parse("https://arbitrary.eth_to_strk_oracle.url").unwrap(),
                    headers: Default::default(),
                }],
            ),
            l1_gas_price_provider_config_config_strk_to_usd_oracle_config_url_header_list: Some(
                vec![UrlAndHeaders {
                    url: Url::parse("https://arbitrary.strk_to_usd_oracle.url").unwrap(),
                    headers: Default::default(),
                }],
            ),
            mempool_p2p_config_network_config_secret_key: None,
            state_sync_config_central_sync_client_config_central_source_config_http_headers: ""
                .to_string(),
            state_sync_config_network_config_secret_key: None,
        }
    }
}

// Wrapper function for the custom `serialize_optional_list_with_url_and_headers` function, to be
// compatible with serde's `serialize_with` attribute. It first applies the custom serialization
// logic to convert the optional list of `UrlAndHeaders` into a `String`, and then serializes that
// string.
fn serialize_optional_list_with_url_and_headers_wrapper<S>(
    list: &Option<Vec<UrlAndHeaders>>,
    serializer: S,
) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    // Call the implemented custom serialization function
    let s = serialize_optional_list_with_url_and_headers(list);
    // Serialize the returned String
    serializer.serialize_str(&s)
}

// Wrapper function for the custom `serialize_slice` function, to be compatible with serde's
// `serialize_with` attribute. It first applies the custom serialization logic to convert the slice
// of `Url` into a `String`, and then serializes that string.
fn serialize_slice_wrapper<S>(urls: &[Url], serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    // Call the implemented custom serialization function
    let s = serialize_slice(urls);
    // Serialize the returned String
    serializer.serialize_str(&s)
}

// Wrapper function for the custom `serialize_optional_vec_u8` function, to be compatible with
// serde's `serialize_with` attribute. It first applies the custom serialization logic to convert
// the optional u8 vector into a `String`, and then serializes that string.
pub fn serialize_optional_vec_u8_wrapper<S>(
    value: &Option<Vec<u8>>,
    serializer: S,
) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    // Call the implemented custom serialization function
    let s = serialize_optional_vec_u8(value);
    // Serialize the returned String
    serializer.serialize_str(&s)
}
