use std::future::ready;
use std::sync::{Arc, LazyLock, Mutex, OnceLock};
use std::time::Duration;

use apollo_batcher_types::batcher_types::{
    FinishProposalInput,
    FinishProposalStatus,
    FinishedProposalInfo,
    FinishedProposalInfoWithoutParent,
    GetProposalContent,
    GetProposalContentResponse,
    ProposalCommitment,
    ProposalId,
    ProposeBlockInput,
    SendTxsForProposalInput,
    SendTxsForProposalStatus,
    ValidateBlockInput,
};
use apollo_batcher_types::communication::{BatcherClientError, MockBatcherClient};
use apollo_batcher_types::errors::BatcherError;
use apollo_class_manager_types::EmptyClassManagerClient;
use apollo_consensus::types::Round;
use apollo_consensus_orchestrator_config::config::{
    ContextConfig,
    ContextStaticConfig,
    PricePerHeight,
};
use apollo_l1_gas_price_types::{MockL1GasPriceProviderClient, PriceInfo};
use apollo_network::network_manager::test_utils::{
    mock_register_broadcast_topic,
    BroadcastNetworkMock,
    TestSubscriberChannels,
};
use apollo_network::network_manager::{BroadcastTopicChannels, BroadcastTopicClient};
use apollo_proof_manager_types::MockProofManagerClient;
use apollo_protobuf::consensus::{
    BuildParam,
    HeightAndRound,
    ProposalCommitment as ProtoProposalCommitment,
    ProposalFin,
    ProposalInit,
    ProposalPart,
    TransactionBatch,
    Vote,
};
use apollo_state_sync_types::communication::MockStateSyncClient;
use apollo_state_sync_types::state_sync_types::SyncBlock;
use apollo_time::time::{Clock, DateTime, DefaultClock};
use apollo_transaction_converter::{
    MockTransactionConverterTrait,
    TransactionConverter,
    TransactionConverterTrait,
};
use apollo_versioned_constants::VersionedConstants;
use futures::channel::mpsc;
use futures::executor::block_on;
use futures::SinkExt;
use mockall::Sequence;
use starknet_api::block::{
    BlockNumber,
    GasPrice,
    TEMP_ETH_BLOB_GAS_FEE_IN_WEI,
    TEMP_ETH_GAS_FEE_IN_WEI,
};
use starknet_api::block_hash::block_hash_calculator::{BlockHeaderCommitments, PartialBlockHash};
use starknet_api::consensus_transaction::{ConsensusTransaction, InternalConsensusTransaction};
use starknet_api::core::{ChainId, ContractAddress, Nonce};
use starknet_api::data_availability::L1DataAvailabilityMode;
use starknet_api::execution_resources::GasAmount;
use starknet_api::felt;
use starknet_api::hash::StarkHash;
use starknet_api::test_utils::invoke::{rpc_invoke_tx, InvokeTxArgs};
use starknet_api::versioned_constants_logic::VersionedConstantsTrait;
use tokio_util::sync::CancellationToken;
use tokio_util::task::AbortOnDropHandle;

use crate::build_proposal::ProposalBuildArguments;
use crate::cende::MockCendeContext;
use crate::dynamic_gas_price::proposal_commitment_from;
use crate::sequencer_consensus_context::{
    BuiltProposals,
    SequencerConsensusContext,
    SequencerConsensusContextDeps,
};
use crate::utils::{make_gas_price_params, GasPriceParams, PreviousProposalInitInfo, StreamSender};

pub(crate) const TIMEOUT: Duration = Duration::from_millis(1200);
pub(crate) const CHANNEL_SIZE: usize = 5000;
pub(crate) const PARTIAL_BLOCK_HASH: PartialBlockHash = PartialBlockHash(StarkHash::ZERO);
pub(crate) const CHAIN_ID: ChainId = ChainId::Mainnet;

// In order for gas price in ETH to be greater than 0 (required) we must have large enough
// values here.
pub(crate) const ETH_TO_FRI_RATE: u128 = 2 * u128::pow(10, 18);

// A STRK/USD rate that yields an in-bounds fee target in proposal-building tests
// where the specific value doesn't matter.
pub(crate) const DEFAULT_STRK_TO_USD_RATE: u128 = 300_000_000_000_000_000;

// L2 gas price minimum for the ceiling tests, and the ceiling it implies. Spelled out rather than
// derived, so `test_price_constants_match_the_shipped_values` catches a change in the shipped
// minimum or multiplier.
pub(crate) const TEST_MIN_L2_GAS_PRICE: GasPrice = GasPrice(8_000_000_000);
pub(crate) const TEST_MAX_L2_GAS_PRICE: GasPrice = GasPrice(80_000_000_000);

// A ceiling no band can reach, for cases where the cap is not under test.
pub(crate) const INERT_MAX_L2_GAS_PRICE: GasPrice = GasPrice(u128::MAX);

pub(crate) static TX_BATCH: LazyLock<Vec<ConsensusTransaction>> =
    LazyLock::new(|| (0..3).map(generate_invoke_tx).collect());

// TODO(Einat): Add client side proving transactions.
pub(crate) static INTERNAL_TX_BATCH: LazyLock<Vec<InternalConsensusTransaction>> =
    LazyLock::new(|| {
        // TODO(shahak): Use MockTransactionConverter instead.
        static TRANSACTION_CONVERTER: LazyLock<TransactionConverter> = LazyLock::new(|| {
            TransactionConverter::new(
                Arc::new(EmptyClassManagerClient),
                Arc::new(MockProofManagerClient::new()),
                CHAIN_ID,
            )
        });
        TX_BATCH
            .iter()
            .cloned()
            .map(|tx| {
                let (internal_tx, _) = block_on(
                    TRANSACTION_CONVERTER.convert_consensus_tx_to_internal_consensus_tx(tx),
                )
                .unwrap();
                internal_tx
            })
            .collect()
    });

pub(crate) struct TestDeps {
    pub transaction_converter: MockTransactionConverterTrait,
    pub state_sync_client: MockStateSyncClient,
    pub batcher: MockBatcherClient,
    pub cende_ambassador: MockCendeContext,
    pub l1_gas_price_provider: MockL1GasPriceProviderClient,
    pub clock: Arc<dyn Clock>,
    pub outbound_proposal_sender: mpsc::Sender<(HeightAndRound, mpsc::Receiver<ProposalPart>)>,
    pub vote_broadcast_client: BroadcastTopicClient<Vote>,
}

impl From<TestDeps> for SequencerConsensusContextDeps {
    fn from(deps: TestDeps) -> Self {
        SequencerConsensusContextDeps {
            transaction_converter: Arc::new(deps.transaction_converter),
            state_sync_client: Arc::new(deps.state_sync_client),
            batcher: Arc::new(deps.batcher),
            cende_ambassador: Arc::new(deps.cende_ambassador),
            l1_gas_price_provider: Arc::new(deps.l1_gas_price_provider),
            clock: deps.clock,
            outbound_proposal_sender: deps.outbound_proposal_sender,
            vote_broadcast_client: deps.vote_broadcast_client,
            config_manager_client: None,
        }
    }
}

pub struct SetupDepsArgs {
    pub start_block_number: BlockNumber,
    pub n_executed_txs_count: usize,
    pub number_of_times: usize,
    pub expect_start_height: bool,
    pub l2_gas_used: Option<GasAmount>,
}

impl Default for SetupDepsArgs {
    fn default() -> Self {
        Self {
            start_block_number: BlockNumber(0),
            n_executed_txs_count: INTERNAL_TX_BATCH.len(),
            number_of_times: 1,
            expect_start_height: true,
            l2_gas_used: None,
        }
    }
}

impl TestDeps {
    pub(crate) fn setup_default_expectations(&mut self) {
        self.setup_default_transaction_converter();
        self.setup_default_cende_ambassador();
        self.setup_default_gas_price_provider();
        self.setup_default_state_sync_get_block();
    }

    pub(crate) fn setup_deps_for_build(&mut self, args: SetupDepsArgs) {
        assert!(args.n_executed_txs_count <= INTERNAL_TX_BATCH.len());
        let mut block_number = args.start_block_number;
        self.setup_default_expectations();
        let proposal_id = Arc::new(OnceLock::new());
        let mut seq = Sequence::new();

        for _ in 0..args.number_of_times {
            let proposal_id_clone = Arc::clone(&proposal_id);
            if args.expect_start_height {
                self.batcher
                    .expect_start_height()
                    .times(1)
                    .in_sequence(&mut seq)
                    .withf(move |input| input.height == block_number)
                    .return_const(Ok(()));
            }
            self.batcher.expect_propose_block().times(1).in_sequence(&mut seq).returning(
                move |input: ProposeBlockInput| {
                    proposal_id_clone.set(input.proposal_id).unwrap();
                    Ok(())
                },
            );
            let proposal_id_clone = Arc::clone(&proposal_id);
            self.batcher
                .expect_get_proposal_content()
                .times(1)
                .in_sequence(&mut seq)
                .withf(move |input| input.proposal_id == *proposal_id_clone.get().unwrap())
                .returning(move |_input| {
                    Ok(GetProposalContentResponse {
                        content: GetProposalContent::Txs(INTERNAL_TX_BATCH.clone()),
                    })
                });
            let proposal_id_clone = Arc::clone(&proposal_id);
            self.batcher
                .expect_get_proposal_content()
                .times(1)
                .in_sequence(&mut seq)
                .withf(move |input| input.proposal_id == *proposal_id_clone.get().unwrap())
                .returning(move |_input| {
                    Ok(GetProposalContentResponse {
                        content: GetProposalContent::Finished(FinishedProposalInfo {
                            artifact: FinishedProposalInfoWithoutParent {
                                proposal_commitment: ProposalCommitment {
                                    partial_block_hash: PARTIAL_BLOCK_HASH,
                                },
                                final_n_executed_txs: args.n_executed_txs_count,
                                block_header_commitments: BlockHeaderCommitments::default(),
                                l2_gas_used: args.l2_gas_used.unwrap_or_default(),
                            },
                            parent_proposal_commitment: None,
                        }),
                    })
                });
            block_number = block_number.unchecked_next();
        }
        self.setup_default_batcher_get_block_hash();
    }

    pub(crate) fn setup_deps_for_validate(&mut self, args: SetupDepsArgs) {
        let mut block_number = args.start_block_number;
        assert!(args.n_executed_txs_count <= INTERNAL_TX_BATCH.len());
        self.setup_default_expectations();
        let mut seq = Sequence::new();
        for _ in 0..args.number_of_times {
            let proposal_id = Arc::new(OnceLock::new());
            if args.expect_start_height {
                self.batcher
                    .expect_start_height()
                    .times(1)
                    .in_sequence(&mut seq)
                    .withf(move |input| input.height == block_number)
                    .return_const(Ok(()));
            }

            let proposal_id_clone = Arc::clone(&proposal_id);
            self.batcher.expect_validate_block().times(1).in_sequence(&mut seq).returning(
                move |input: ValidateBlockInput| {
                    proposal_id_clone.set(input.proposal_id).unwrap();
                    Ok(())
                },
            );

            let proposal_id_clone = Arc::clone(&proposal_id);
            self.batcher
                .expect_send_txs_for_proposal()
                .times(1)
                .in_sequence(&mut seq)
                .withf(move |input| input.proposal_id == *proposal_id_clone.get().unwrap())
                .returning(move |input: SendTxsForProposalInput| {
                    let txs = input.txs;
                    assert_eq!(txs, INTERNAL_TX_BATCH.clone());
                    Ok(SendTxsForProposalStatus::Processing)
                });
            let proposal_id_clone = Arc::clone(&proposal_id);

            self.batcher
                .expect_finish_proposal()
                .times(1)
                .in_sequence(&mut seq)
                .withf(move |input| input.proposal_id == *proposal_id_clone.get().unwrap())
                .returning(move |input: FinishProposalInput| {
                    assert_eq!(input.final_n_executed_txs, args.n_executed_txs_count);
                    Ok(FinishProposalStatus::Finished(FinishedProposalInfo {
                        artifact: FinishedProposalInfoWithoutParent {
                            proposal_commitment: ProposalCommitment {
                                partial_block_hash: PARTIAL_BLOCK_HASH,
                            },
                            final_n_executed_txs: args.n_executed_txs_count,
                            block_header_commitments: BlockHeaderCommitments::default(),
                            l2_gas_used: GasAmount::default(),
                        },
                        parent_proposal_commitment: None,
                    }))
                });
            block_number = block_number.unchecked_next();
        }
        self.setup_default_batcher_get_block_hash();
    }

    pub(crate) fn setup_default_transaction_converter(&mut self) {
        for (tx, internal_tx) in TX_BATCH.iter().zip(INTERNAL_TX_BATCH.iter()) {
            self.transaction_converter
                .expect_convert_internal_consensus_tx_to_consensus_tx()
                .withf(move |tx| tx == internal_tx)
                .returning(|_| Ok(tx.clone()));
            self.transaction_converter
                .expect_convert_consensus_tx_to_internal_consensus_tx()
                .withf(move |internal_tx| internal_tx == tx)
                // TODO(Einat): Add verification handle when client-side proving is tested in the validate proposal test.
                .returning(|_| Ok((internal_tx.clone(), None)));
        }
    }

    pub(crate) fn setup_default_cende_ambassador(&mut self) {
        self.cende_ambassador
            .expect_write_prev_height_blob()
            .return_once(|_height| tokio::spawn(ready(true)));
        // Default: cende recorder reports nothing stored → send from genesis. Delta tests
        // override this.
        self.cende_ambassador.expect_commitment_infos_height_offset().returning(|| Ok(None));
    }

    pub(crate) fn setup_default_gas_price_provider(&mut self) {
        self.l1_gas_price_provider.expect_get_price_info().return_const(Ok(PriceInfo {
            base_fee_per_gas: GasPrice(TEMP_ETH_GAS_FEE_IN_WEI),
            blob_fee: GasPrice(TEMP_ETH_BLOB_GAS_FEE_IN_WEI),
        }));
        self.l1_gas_price_provider.expect_get_rate().return_const(Ok(ETH_TO_FRI_RATE));
        self.l1_gas_price_provider
            .expect_get_strk_to_usd_rate()
            .return_const(Ok(DEFAULT_STRK_TO_USD_RATE));
    }

    fn setup_default_state_sync_get_block(&mut self) {
        self.state_sync_client.expect_get_block().returning(|_| Ok(SyncBlock::default()));
    }

    pub(crate) fn setup_default_batcher_get_block_hash(&mut self) {
        self.batcher.expect_get_block_hash().returning(|block_number| {
            Err(BatcherClientError::BatcherError(BatcherError::BlockHashNotFound(block_number)))
        });
        self.batcher.expect_has_state_commitment_infos().returning(|_block_number| Ok(false));
        self.batcher.expect_get_state_commitment_infos().returning(|_block_number| Ok(None));
    }

    pub(crate) fn build_context(self) -> SequencerConsensusContext {
        self.build_context_with_config(ContextConfig {
            static_config: ContextStaticConfig {
                proposal_buffer_size: CHANNEL_SIZE,
                chain_id: CHAIN_ID,
                ..Default::default()
            },
            ..Default::default()
        })
    }

    pub(crate) fn build_context_with_config(
        self,
        config: ContextConfig,
    ) -> SequencerConsensusContext {
        SequencerConsensusContext::new(config, self.into())
    }
}

pub(crate) fn create_test_and_network_deps() -> (TestDeps, NetworkDependencies) {
    let (outbound_proposal_sender, outbound_proposal_receiver) =
        mpsc::channel::<(HeightAndRound, mpsc::Receiver<ProposalPart>)>(CHANNEL_SIZE);

    let TestSubscriberChannels { mock_network: mock_vote_network, subscriber_channels } =
        mock_register_broadcast_topic().expect("Failed to create mock network");
    let BroadcastTopicChannels { broadcast_topic_client: votes_topic_client, .. } =
        subscriber_channels;

    let transaction_converter = MockTransactionConverterTrait::new();
    let state_sync_client = MockStateSyncClient::new();
    let batcher = MockBatcherClient::new();
    let cende_ambassador = MockCendeContext::new();
    let l1_gas_price_provider = MockL1GasPriceProviderClient::new();
    let clock = Arc::new(DefaultClock);

    let test_deps = TestDeps {
        transaction_converter,
        state_sync_client,
        batcher,
        cende_ambassador,
        l1_gas_price_provider,
        clock,
        outbound_proposal_sender,
        vote_broadcast_client: votes_topic_client,
    };

    let network_deps =
        NetworkDependencies { _vote_network: mock_vote_network, outbound_proposal_receiver };

    (test_deps, network_deps)
}

pub(crate) fn generate_invoke_tx(nonce: u8) -> ConsensusTransaction {
    ConsensusTransaction::RpcTransaction(rpc_invoke_tx(InvokeTxArgs {
        nonce: Nonce(felt!(nonce)),
        ..Default::default()
    }))
}

pub(crate) fn proposal_init(height: BlockNumber, round: u32) -> ProposalInit {
    let context_config = ContextConfig::default();
    let l1_gas_price_wei =
        GasPrice(TEMP_ETH_GAS_FEE_IN_WEI + context_config.dynamic_config.l1_gas_tip_wei);
    let l1_data_gas_price_wei = GasPrice(
        TEMP_ETH_BLOB_GAS_FEE_IN_WEI
            * context_config.dynamic_config.l1_data_gas_price_multiplier_ppt
            / 1000,
    );
    let l1_gas_price_fri =
        l1_gas_price_wei.wei_to_fri(ETH_TO_FRI_RATE).expect("L1 gas price must be non-zero");
    let l1_data_gas_price_fri = l1_data_gas_price_wei
        .wei_to_fri(ETH_TO_FRI_RATE)
        .expect("L1 data gas price must be non-zero");
    ProposalInit {
        height,
        round,
        valid_round: None,
        proposer: Default::default(),
        timestamp: chrono::Utc::now().timestamp().try_into().expect("Timestamp conversion failed"),
        builder: Default::default(),
        l1_da_mode: L1DataAvailabilityMode::Blob,
        l2_gas_price_fri: VersionedConstants::latest_constants().min_gas_price,
        l1_gas_price_fri,
        l1_data_gas_price_fri,
        l1_gas_price_wei,
        l1_data_gas_price_wei,
        starknet_version: starknet_api::block::StarknetVersion::LATEST,
        version_constant_commitment: Default::default(),
        // Required because LATEST >= V0_14_3. Match the proposer's default-fallback
        // fee_proposal.
        fee_proposal_fri: Some(GasPrice(8_000_000_000)),
    }
}

// Send the given block info, some txs, the number of txs, and the fin, returning the
// content_receiver.
pub(crate) async fn send_proposal_to_validator_context(
    context: &mut SequencerConsensusContext,
) -> mpsc::Receiver<ProposalPart> {
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.get_config().static_config.proposal_buffer_size);
    content_sender
        .send(ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() }))
        .await
        .unwrap();
    // Match the validator's computed commitment: `proposal_init` emits
    // `fee_proposal_fri = Some(8 gwei)` (the default-test fee_proposal value), and the
    // validator chains that into the proposal commitment via `proposal_commitment_from`.
    let expected_commitment =
        proposal_commitment_from(PARTIAL_BLOCK_HASH, Some(GasPrice(8_000_000_000)));
    content_sender
        .send(ProposalPart::Fin(ProposalFin {
            proposal_commitment: ProtoProposalCommitment(expected_commitment.0),
            executed_transaction_count: INTERNAL_TX_BATCH.len().try_into().unwrap(),
            fin_payload: None,
        }))
        .await
        .unwrap();
    content_sender.close_channel();
    content_receiver
}

// Structs which aren't utilized but should not be dropped.
pub(crate) struct NetworkDependencies {
    _vote_network: BroadcastNetworkMock<Vote>,
    pub outbound_proposal_receiver: mpsc::Receiver<(HeightAndRound, mpsc::Receiver<ProposalPart>)>,
}

// TODO(Dafna): Remove this struct and use ProposalBuildArguments directly.
pub(crate) struct TestProposalBuildArguments {
    pub deps: TestDeps,
    pub batcher_deadline: DateTime,
    pub build_param: BuildParam,
    pub l1_da_mode: L1DataAvailabilityMode,
    pub stream_sender: StreamSender,
    pub gas_price_params: GasPriceParams,
    pub valid_proposals: Arc<Mutex<BuiltProposals>>,
    pub proposal_id: ProposalId,
    pub cende_write_success: AbortOnDropHandle<bool>,
    pub l2_gas_price: GasPrice,
    pub builder_address: ContractAddress,
    pub cancel_token: CancellationToken,
    pub previous_proposal_init: Option<PreviousProposalInitInfo>,
    pub proposal_round: Round,
    pub retrospective_block_hash_deadline: DateTime,
    pub retrospective_block_hash_retry_interval_millis: Duration,
    pub override_block_metadata: bool,
    pub override_l2_gas_price_fri: Option<u128>,
    pub min_l2_gas_price_per_height: Vec<PricePerHeight>,
    pub compare_retrospective_block_hash: bool,
}

impl From<TestProposalBuildArguments> for ProposalBuildArguments {
    fn from(args: TestProposalBuildArguments) -> Self {
        ProposalBuildArguments {
            deps: args.deps.into(),
            batcher_deadline: args.batcher_deadline,
            build_param: args.build_param,
            l1_da_mode: args.l1_da_mode,
            stream_sender: args.stream_sender,
            gas_price_params: args.gas_price_params,
            valid_proposals: args.valid_proposals,
            proposal_id: args.proposal_id,
            cende_write_success: args.cende_write_success,
            l2_gas_price: args.l2_gas_price,
            builder_address: args.builder_address,
            cancel_token: args.cancel_token,
            previous_proposal_init: args.previous_proposal_init,
            proposal_round: args.proposal_round,
            retrospective_block_hash_deadline: args.retrospective_block_hash_deadline,
            retrospective_block_hash_retry_interval_millis: args
                .retrospective_block_hash_retry_interval_millis,
            override_block_metadata: args.override_block_metadata,
            override_l2_gas_price_fri: args.override_l2_gas_price_fri,
            min_l2_gas_price_per_height: args.min_l2_gas_price_per_height,
            compare_retrospective_block_hash: args.compare_retrospective_block_hash,
            fee_proposal: GasPrice::default(),
            fee_actual: None,
        }
    }
}

pub(crate) fn create_proposal_build_arguments()
-> (TestProposalBuildArguments, mpsc::Receiver<ProposalPart>) {
    let (mut deps, _) = create_test_and_network_deps();
    deps.setup_default_expectations();
    let time_now = deps.clock.now();
    let batcher_deadline = time_now + TIMEOUT;
    let retrospective_block_hash_deadline = time_now + TIMEOUT.mul_f32(0.1);
    let retrospective_block_hash_retry_interval_millis = Duration::from_millis(25);
    let build_param = BuildParam::default();
    let l1_da_mode = L1DataAvailabilityMode::Calldata;
    let (proposal_sender, proposal_receiver) = mpsc::channel::<ProposalPart>(CHANNEL_SIZE);
    let stream_sender = StreamSender { proposal_sender };
    let context_config = ContextConfig::default();

    let gas_price_params = make_gas_price_params(&context_config.dynamic_config);
    let valid_proposals = Arc::new(Mutex::new(BuiltProposals::new()));
    let proposal_id = ProposalId(1);
    let cende_write_success = AbortOnDropHandle::new(tokio::spawn(async { true }));
    let l2_gas_price = VersionedConstants::latest_constants().min_gas_price;
    let builder_address = ContractAddress::default();
    let cancel_token = CancellationToken::new();
    let previous_proposal_init = None;
    let proposal_round = 0;
    let override_block_metadata = false;

    (
        TestProposalBuildArguments {
            deps,
            batcher_deadline,
            build_param,
            l1_da_mode,
            stream_sender,
            gas_price_params,
            valid_proposals,
            proposal_id,
            cende_write_success,
            l2_gas_price,
            builder_address,
            cancel_token,
            previous_proposal_init,
            proposal_round,
            retrospective_block_hash_deadline,
            retrospective_block_hash_retry_interval_millis,
            override_block_metadata,
            override_l2_gas_price_fri: None,
            min_l2_gas_price_per_height: vec![],
            compare_retrospective_block_hash: true,
        },
        proposal_receiver,
    )
}
