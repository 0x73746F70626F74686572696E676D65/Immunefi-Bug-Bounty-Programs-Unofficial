use std::collections::BTreeMap;
use std::future::ready;
use std::sync::{Arc, LazyLock};
use std::time::Duration;

use apollo_batcher_types::batcher_types::{
    CentralObjects,
    DecisionReachedResponse,
    FinishProposalStatus,
    FinishedProposalInfo,
    FinishedProposalInfoWithoutParent,
    ProposalCommitment as BatcherProposalCommitment,
    SendTxsForProposalStatus,
};
use apollo_batcher_types::communication::{BatcherClientError, BatcherClientResult};
use apollo_batcher_types::errors::BatcherError;
use apollo_config_manager_types::communication::MockConfigManagerClient;
use apollo_consensus::types::{ConsensusContext, Round};
use apollo_consensus_orchestrator_config::config::{
    ContextConfig,
    ContextDynamicConfig,
    ContextStaticConfig,
    PricePerHeight,
};
use apollo_l1_gas_price_types::errors::{
    ExchangeRateOracleClientError,
    L1GasPriceClientError,
    L1GasPriceProviderError,
};
use apollo_l1_gas_price_types::{MockL1GasPriceProviderClient, PriceInfo};
use apollo_protobuf::consensus::{
    BuildParam,
    CommitmentParts,
    L2GasInfo,
    ProposalCommitment,
    ProposalFin,
    ProposalFinPayload,
    ProposalPart,
    TransactionBatch,
};
use apollo_state_sync_types::communication::StateSyncClientError;
use apollo_state_sync_types::errors::StateSyncError;
use apollo_state_sync_types::state_sync_types::SyncBlock;
use apollo_time::time::MockClock;
use apollo_versioned_constants::VersionedConstants;
use chrono::{TimeZone, Utc};
use futures::channel::mpsc;
use futures::channel::oneshot::Canceled;
use futures::future::pending;
use futures::{FutureExt, SinkExt, StreamExt};
use metrics_exporter_prometheus::PrometheusBuilder;
use rstest::rstest;
use starknet_api::block::{
    BlockHash,
    BlockHeaderWithoutHash,
    BlockNumber,
    GasPrice,
    StarknetVersion,
    TEMP_ETH_BLOB_GAS_FEE_IN_WEI,
    TEMP_ETH_GAS_FEE_IN_WEI,
    WEI_PER_ETH,
};
use starknet_api::block_hash::block_hash_calculator::BlockHeaderCommitments;
use starknet_api::execution_resources::GasAmount;
use starknet_api::hash::StarkHash;
use starknet_api::state::ThinStateDiff;
use starknet_api::versioned_constants_logic::VersionedConstantsTrait;
use starknet_committer::patricia_merkle_tree::types::{
    CompressedPayload,
    CompressedStateCommitmentInfos,
    STATE_COMMITMENT_INFOS_VERSION,
};
use tracing_test::traced_test;

use crate::cende::{
    BlockAccessedKeysData,
    CendeAmbassadorError,
    MockCendeContext,
    StateCommitmentInfosAndNumber,
    N_BLOCK_HASHES_BACK_IN_BLOB,
};
use crate::dynamic_gas_price::proposal_commitment_from;
use crate::metrics::{
    CONSENSUS_L2_GAS_PRICE,
    CONSENSUS_L2_GAS_PRICE_AT_MINIMUM,
    CONSENSUS_L2_GAS_PRICE_CLAMPED,
    LABEL_L2_GAS_PRICE_CLAMP_BOUND,
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM,
};
use crate::sequencer_consensus_context::{
    SequencerConsensusContext,
    SequencerConsensusContextDeps,
};
use crate::test_utils::{
    create_test_and_network_deps,
    proposal_init,
    send_proposal_to_validator_context,
    SetupDepsArgs,
    CHAIN_ID,
    CHANNEL_SIZE,
    ETH_TO_FRI_RATE,
    INTERNAL_TX_BATCH,
    PARTIAL_BLOCK_HASH,
    TEST_MAX_L2_GAS_PRICE,
    TEST_MIN_L2_GAS_PRICE,
    TIMEOUT,
    TX_BATCH,
};

/// Expected L2GasInfo when build_proposal runs with test defaults (min gas price, l2_gas_used 0).
fn expected_l2_gas_info_for_build_proposal_defaults() -> L2GasInfo {
    L2GasInfo {
        next_l2_gas_price_fri: VersionedConstants::latest_constants().min_gas_price,
        l2_gas_used: GasAmount(0),
    }
}
use crate::dynamic_gas_price::compute_fee_actual;
use crate::utils::{apply_fee_transformations, make_gas_price_params};

static TEST_PROPOSAL_COMMITMENT: LazyLock<ProposalCommitment> = LazyLock::new(|| {
    // Default test setup: empty fee_proposals_window → `compute_fee_actual` returns `None` →
    // `compute_proposer_fee_proposal` falls back to `self.l2_gas_price` (default
    // `min_gas_price` = 8 gwei = 8_000_000_000 FRI). The orchestrator chains this value into
    // the proposal commitment via `proposal_commitment_from`. The `proposal_init` test helper
    // produces an init with `fee_proposal_fri = Some(8 gwei)` to match what the proposer emits.
    proposal_commitment_from(PARTIAL_BLOCK_HASH, Some(GasPrice(8_000_000_000)))
});
const HEIGHT_0: BlockNumber = BlockNumber(0);
const HEIGHT_1: BlockNumber = BlockNumber(1);

// Use heights < 10 to avoid triggering the height-10 block-hash mapping code path (not tested
// here). Use non-zero height because height 0 always skips the write without querying the recorder.
const HEIGHT_FOR_WRITE_TESTS: BlockNumber = BlockNumber(8);
const TARGET_ATTO_USD_PER_L2_GAS: u128 = 3_000_000_000;

const ROUND_0: Round = 0;
const ROUND_1: Round = 1;

#[tokio::test]
async fn cancelled_proposal_aborts() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();

    deps.batcher.expect_propose_block().times(1).return_const(Ok(()));
    deps.batcher.expect_start_height().times(1).return_const(Ok(()));

    let mut context = deps.build_context();
    let fin_receiver = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap();

    // Now we intrrupt the proposal and verify that the fin_receiever is dropped.
    context.set_height_and_round(HEIGHT_0, ROUND_1).await.unwrap();

    assert_eq!(fin_receiver.await, Err(Canceled));
}

#[tokio::test]
async fn validate_proposal_success() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_deps_for_validate(SetupDepsArgs::default());
    let mut context = deps.build_context();

    // Initialize the context for a specific height, starting with round 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();
    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT, content_receiver)
        .await;
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);
}

#[rstest]
#[case::execute_all_txs(true)]
#[case::dont_execute_last_tx(false)]
#[tokio::test]
async fn validate_then_repropose(#[case] execute_all_txs: bool) {
    // Receive a proposal. Then re-retrieve it.
    let (mut deps, mut network) = create_test_and_network_deps();
    let executed_transactions = match execute_all_txs {
        true => TX_BATCH.to_vec(),
        false => TX_BATCH.iter().take(TX_BATCH.len() - 1).cloned().collect(),
    };
    let n_executed_txs_count = executed_transactions.len();
    deps.setup_deps_for_validate(SetupDepsArgs { n_executed_txs_count, ..Default::default() });

    const TIMESTAMP: u64 = 123456;
    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(|_| Ok(DecisionReachedResponse::default()));
    deps.state_sync_client.expect_add_new_block().times(1).return_once(move |proposal_init| {
        assert_eq!(
            proposal_init.block_header_without_hash.timestamp.0, TIMESTAMP,
            "add_new_block should be called with timestamp from initial proposal (unchanged \
             during reproposal for commitment consistency)"
        );
        Ok(())
    });
    deps.cende_ambassador.expect_prepare_blob_for_next_height().return_once(|_| Ok(()));

    let mut context = deps.build_context();

    // Initialize the context for a specific height, starting with round 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();

    // Receive a valid proposal. Use timestamp matching MockClock so validation passes.
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    let mut init = proposal_init(HEIGHT_0, ROUND_0);
    init.timestamp = TIMESTAMP;
    let transactions =
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() });
    content_sender.send(transactions.clone()).await.unwrap();
    let fin = ProposalPart::Fin(ProposalFin {
        proposal_commitment: *TEST_PROPOSAL_COMMITMENT,
        executed_transaction_count: n_executed_txs_count.try_into().unwrap(),
        fin_payload: Some(ProposalFinPayload {
            commitment_parts: CommitmentParts::default(),
            l2_gas_info: expected_l2_gas_info_for_build_proposal_defaults(),
        }),
    });
    content_sender.send(fin.clone()).await.unwrap();
    let fin_receiver = context.validate_proposal(init.clone(), TIMEOUT, content_receiver).await;
    content_sender.close_channel();
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);

    let build_param =
        BuildParam { round: ROUND_1, valid_round: Some(ROUND_0), ..Default::default() };
    context.repropose(*TEST_PROPOSAL_COMMITMENT, build_param).await;
    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    // Reproposal sends init with updated round, proposer, valid_round.
    let mut expected_init = init;
    expected_init.round = ROUND_1;
    expected_init.proposer = build_param.proposer;
    expected_init.valid_round = build_param.valid_round;
    assert_eq!(receiver.next().await.unwrap(), ProposalPart::Init(expected_init));
    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Transactions(TransactionBatch { transactions: executed_transactions })
    );
    assert_eq!(receiver.next().await.unwrap(), fin);
    assert!(receiver.next().await.is_none());

    // Verify decision_reached uses the updated init (from reproposal round) for finalize.
    context.decision_reached(HEIGHT_0, ROUND_1, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();
}

#[tokio::test]
async fn validate_then_build_then_decision_reached_round_0_uses_round_0_init() {
    // Scenario: validate round 0 with init timestamp X, build round 1 with clock returning Y
    // (different from X), decision_reached(round 0). State sync must receive timestamp
    // X (from round 0 init), not Y (from round 1 build).
    let (mut deps, mut network) = create_test_and_network_deps();
    deps.setup_deps_for_validate(SetupDepsArgs::default());
    deps.setup_deps_for_build(SetupDepsArgs { expect_start_height: false, ..Default::default() });

    const TIMESTAMP_ROUND_0: u64 = 123456;
    const TIMESTAMP_ROUND_1: u64 = 789012; // Different from round 0

    let mut clock = MockClock::new();
    clock.expect_unix_now().return_const(TIMESTAMP_ROUND_1);
    clock
        .expect_now()
        .return_const(Utc.timestamp_opt(TIMESTAMP_ROUND_1.try_into().unwrap(), 0).unwrap());
    deps.clock = Arc::new(clock);

    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(|_| Ok(DecisionReachedResponse::default()));
    deps.state_sync_client.expect_add_new_block().times(1).return_once(move |sync_block| {
        assert_eq!(
            sync_block.block_header_without_hash.timestamp.0, TIMESTAMP_ROUND_0,
            "add_new_block should be called with timestamp from round 0 validation (X), not from \
             round 1 build (Y)"
        );
        Ok(())
    });
    deps.cende_ambassador.expect_prepare_blob_for_next_height().return_once(|_| Ok(()));

    let mut context = deps.build_context();

    // Round 0: validate with init timestamp TIMESTAMP_ROUND_0
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    let mut init = proposal_init(HEIGHT_0, ROUND_0);
    init.timestamp = TIMESTAMP_ROUND_0;
    let transactions =
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() });
    content_sender.send(transactions.clone()).await.unwrap();
    let fin = ProposalPart::Fin(ProposalFin {
        proposal_commitment: *TEST_PROPOSAL_COMMITMENT,
        executed_transaction_count: TX_BATCH.len().try_into().unwrap(),
        fin_payload: None,
    });
    content_sender.send(fin.clone()).await.unwrap();
    let fin_receiver = context.validate_proposal(init, TIMEOUT, content_receiver).await;
    content_sender.close_channel();
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);

    // Round 1: build - clock returns TIMESTAMP_ROUND_1 (different from TIMESTAMP_ROUND_0)
    let build_param = BuildParam { round: ROUND_1, ..Default::default() };
    let fin_receiver = context.build_proposal(build_param, TIMEOUT).await.unwrap();

    // Build sends proposal with TIMESTAMP_ROUND_1 from clock
    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    let part = receiver.next().await.unwrap();
    let ProposalPart::Init(build_init) = part else {
        panic!("Expected Init part");
    };
    assert_eq!(build_init.timestamp, TIMESTAMP_ROUND_1);
    let _txs = receiver.next().await.unwrap();
    let _fin = receiver.next().await.unwrap();
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);

    // Decision reached for round 0 - state_sync should receive TIMESTAMP_ROUND_0
    context.decision_reached(HEIGHT_0, ROUND_0, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();
}

#[tokio::test]
async fn proposals_from_different_rounds() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_deps_for_validate(SetupDepsArgs::default());
    let mut context = deps.build_context();
    // Initialize the context for a specific height, starting with round 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();
    context.set_height_and_round(HEIGHT_0, ROUND_1).await.unwrap();

    // Proposal parts sent in the proposals.
    let prop_part_txs =
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() });
    let prop_part_fin = ProposalPart::Fin(ProposalFin {
        proposal_commitment: *TEST_PROPOSAL_COMMITMENT,
        executed_transaction_count: INTERNAL_TX_BATCH.len().try_into().unwrap(),
        fin_payload: Some(ProposalFinPayload::default()),
    });

    // The proposal from the past round is ignored.
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    content_sender.send(prop_part_txs.clone()).await.unwrap();

    let fin_receiver_past_round = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT, content_receiver)
        .await;
    // No fin was sent, channel remains open.
    assert!(fin_receiver_past_round.await.is_err());

    // The proposal from the current round should be validated.
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    content_sender.send(prop_part_txs.clone()).await.unwrap();
    content_sender.send(prop_part_fin.clone()).await.unwrap();
    let fin_receiver_curr_round = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_1), TIMEOUT, content_receiver)
        .await;
    assert_eq!(fin_receiver_curr_round.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);

    // The proposal from the future round should not be processed.
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    content_sender.send(prop_part_txs.clone()).await.unwrap();
    content_sender.send(prop_part_fin.clone()).await.unwrap();
    let fin_receiver_future_round =
        context.validate_proposal(proposal_init(HEIGHT_0, 2), TIMEOUT, content_receiver).await;
    content_sender.close_channel();
    // Even with sending fin and closing the channel.
    assert!(fin_receiver_future_round.now_or_never().is_none());
}

// Regression test: a round skip (e.g. round 1 times out) must not strand a queued future
// proposal nor permanently poison the queue. Previously the round comparison in
// set_height_and_round was inverted, so a queued proposal for a skipped past round caused an
// early return that halted consensus liveness for the height.
#[tokio::test]
async fn skipped_round_does_not_block_future_proposal() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_deps_for_validate(SetupDepsArgs::default());
    let mut context = deps.build_context();
    // Initialize the context for a specific height, starting with round 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();

    let prop_part_txs =
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() });
    let prop_part_fin = ProposalPart::Fin(ProposalFin {
        proposal_commitment: *TEST_PROPOSAL_COMMITMENT,
        executed_transaction_count: INTERNAL_TX_BATCH.len().try_into().unwrap(),
        fin_payload: Some(ProposalFinPayload::default()),
    });

    // Queue a proposal for round 1 (a future round while we are at round 0).
    let (mut content_sender_round_1, content_receiver_round_1) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    content_sender_round_1.send(prop_part_txs.clone()).await.unwrap();
    let fin_receiver_round_1 = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_1), TIMEOUT, content_receiver_round_1)
        .await;

    // Queue a proposal for round 2 (also a future round while we are at round 0).
    let (mut content_sender_round_2, content_receiver_round_2) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    content_sender_round_2.send(prop_part_txs.clone()).await.unwrap();
    content_sender_round_2.send(prop_part_fin.clone()).await.unwrap();
    let fin_receiver_round_2 = context
        .validate_proposal(proposal_init(HEIGHT_0, 2), TIMEOUT, content_receiver_round_2)
        .await;

    // Advance directly to round 2, skipping round 1 (e.g. round 1 timed out).
    context.set_height_and_round(HEIGHT_0, 2).await.unwrap();

    // The skipped round-1 proposal is discarded; its fin sender is dropped.
    assert!(fin_receiver_round_1.await.is_err());
    // The round-2 proposal is found in the queue and validated, proving the skipped past round
    // did not poison the queue.
    assert_eq!(fin_receiver_round_2.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);
}

#[tokio::test]
async fn interrupt_active_proposal() {
    let (mut deps, _network) = create_test_and_network_deps();
    // This test validates two proposals: round 0 (interrupted) and round 1 (successful)
    deps.setup_default_expectations();

    // Expect 2 validate_block calls (one for each round)
    deps.batcher.expect_validate_block().times(2).returning(|_| Ok(()));
    deps.batcher.expect_start_height().withf(|input| input.height == HEIGHT_0).return_const(Ok(()));

    // Round 0: Will be interrupted and send Abort
    deps.batcher.expect_abort_proposal().times(1).returning(|_| Ok(()));

    // Round 1: Will send Txs then Finish
    deps.batcher.expect_send_txs_for_proposal().times(1).returning(|input| {
        let txs = input.txs;
        assert_eq!(txs, *INTERNAL_TX_BATCH);
        Ok(SendTxsForProposalStatus::Processing)
    });
    deps.batcher.expect_finish_proposal().times(1).returning(|input| {
        assert_eq!(input.final_n_executed_txs, INTERNAL_TX_BATCH.len());
        Ok(FinishProposalStatus::Finished(FinishedProposalInfo {
            artifact: FinishedProposalInfoWithoutParent {
                proposal_commitment: BatcherProposalCommitment {
                    partial_block_hash: PARTIAL_BLOCK_HASH,
                },
                final_n_executed_txs: 0,
                block_header_commitments: BlockHeaderCommitments::default(),
                l2_gas_used: GasAmount::default(),
            },
            parent_proposal_commitment: None,
        }))
    });

    let mut context = deps.build_context();
    // Initialize the context for a specific height, starting with round 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();

    // Keep the sender open, as closing it or sending Fin would cause the validate to complete
    // without needing interrupt.
    let (mut _content_sender_0, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    let fin_receiver_0 = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT, content_receiver)
        .await;

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver_1 = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_1), TIMEOUT, content_receiver)
        .await;
    // Move the context to the next round.
    context.set_height_and_round(HEIGHT_0, ROUND_1).await.unwrap();

    // Interrupt active proposal.
    assert!(fin_receiver_0.await.is_err());
    assert_eq!(fin_receiver_1.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);
}

#[tokio::test]
async fn build_proposal() {
    let before: u64 =
        chrono::Utc::now().timestamp().try_into().expect("Timestamp conversion failed");
    let (mut deps, mut network) = create_test_and_network_deps();
    deps.setup_deps_for_build(SetupDepsArgs::default());
    let mut context = deps.build_context();
    let fin_receiver = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap();
    // Test proposal parts.
    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    let part = receiver.next().await.unwrap();
    let after: u64 =
        chrono::Utc::now().timestamp().try_into().expect("Timestamp conversion failed");
    let ProposalPart::Init(info) = part else {
        panic!("Expected ProposalPart::Init");
    };
    assert!(info.timestamp >= before && info.timestamp <= after);
    let expected_proposal_commitment =
        proposal_commitment_from(PARTIAL_BLOCK_HASH, info.fee_proposal_fri);
    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() })
    );
    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Fin(ProposalFin {
            proposal_commitment: expected_proposal_commitment,
            executed_transaction_count: INTERNAL_TX_BATCH.len().try_into().unwrap(),
            fin_payload: Some(ProposalFinPayload {
                commitment_parts: CommitmentParts::default(),
                l2_gas_info: expected_l2_gas_info_for_build_proposal_defaults(),
            }),
        })
    );
    assert!(receiver.next().await.is_none());
    assert_eq!(fin_receiver.await.unwrap(), expected_proposal_commitment);
}

#[tokio::test]
async fn build_proposal_cende_failure() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_deps_for_build(SetupDepsArgs {
        start_block_number: HEIGHT_FOR_WRITE_TESTS,
        ..Default::default()
    });
    let mut mock_cende_context = MockCendeContext::new();
    mock_cende_context
        .expect_write_prev_height_blob()
        .times(1)
        .return_once(|_height| tokio::spawn(ready(false)));
    deps.cende_ambassador = mock_cende_context;
    let mut context = deps.build_context();

    let fin_receiver = context
        .build_proposal(
            BuildParam { height: HEIGHT_FOR_WRITE_TESTS, ..Default::default() },
            TIMEOUT,
        )
        .await
        .unwrap();
    assert_eq!(fin_receiver.await, Err(Canceled));
}

#[tokio::test]
async fn build_proposal_cende_incomplete() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_deps_for_build(SetupDepsArgs {
        start_block_number: HEIGHT_FOR_WRITE_TESTS,
        ..Default::default()
    });
    let mut mock_cende_context = MockCendeContext::new();
    mock_cende_context
        .expect_write_prev_height_blob()
        .times(1)
        .return_once(|_height| tokio::spawn(pending()));
    deps.cende_ambassador = mock_cende_context;
    let mut context = deps.build_context();

    let fin_receiver = context
        .build_proposal(
            BuildParam { height: HEIGHT_FOR_WRITE_TESTS, ..Default::default() },
            TIMEOUT,
        )
        .await
        .unwrap();
    assert_eq!(fin_receiver.await, Err(Canceled));
}

#[rstest]
#[case::proposer(true)]
#[case::validator(false)]
#[tokio::test]
async fn batcher_not_ready(#[case] proposer: bool) {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();
    deps.batcher.expect_start_height().times(1).return_const(Ok(()));
    if proposer {
        deps.batcher
            .expect_propose_block()
            .times(1)
            .return_const(Err(BatcherClientError::BatcherError(BatcherError::NotReady)));
    } else {
        deps.batcher
            .expect_validate_block()
            .times(1)
            .return_const(Err(BatcherClientError::BatcherError(BatcherError::NotReady)));
    }
    let mut context = deps.build_context();
    context.set_height_and_round(BlockNumber::default(), ROUND_0).await.unwrap();

    if proposer {
        let fin_receiver = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap();
        assert_eq!(fin_receiver.await, Err(Canceled));
    } else {
        let (_content_sender, content_receiver) =
            mpsc::channel(context.config.static_config.proposal_buffer_size);

        let fin_receiver = context
            .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT, content_receiver)
            .await;
        assert_eq!(fin_receiver.await, Err(Canceled));
    }
}

#[rstest]
#[case::execute_all_txs(true)]
#[case::dont_execute_last_tx(false)]
#[tokio::test]
async fn propose_then_repropose(#[case] execute_all_txs: bool) {
    let (mut deps, mut network) = create_test_and_network_deps();
    let transactions = match execute_all_txs {
        true => TX_BATCH.to_vec(),
        false => TX_BATCH.iter().take(TX_BATCH.len() - 1).cloned().collect(),
    };
    deps.setup_deps_for_build(SetupDepsArgs {
        n_executed_txs_count: transactions.len(),
        ..Default::default()
    });

    const TIMESTAMP: u64 = 123456;
    let mut clock = MockClock::new();
    clock.expect_unix_now().return_const(TIMESTAMP);
    clock.expect_now().return_const(Utc.timestamp_opt(TIMESTAMP.try_into().unwrap(), 0).unwrap());
    deps.clock = Arc::new(clock);

    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(|_| Ok(DecisionReachedResponse::default()));
    deps.state_sync_client.expect_add_new_block().times(1).return_once(move |proposal_init| {
        assert_eq!(
            proposal_init.block_header_without_hash.timestamp.0, TIMESTAMP,
            "add_new_block should be called with timestamp from initial proposal (unchanged \
             during reproposal for commitment consistency)"
        );
        Ok(())
    });
    deps.cende_ambassador.expect_prepare_blob_for_next_height().return_once(|_| Ok(()));

    let mut context = deps.build_context();
    // Build proposal.
    let fin_receiver = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap();
    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    // Receive the proposal parts.
    let ProposalPart::Init(original_init) = receiver.next().await.unwrap() else {
        panic!("Expected Init part");
    };
    let _txs = receiver.next().await.unwrap();
    let fin = receiver.next().await.unwrap();
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);

    // Re-propose.
    let build_param =
        BuildParam { round: ROUND_1, valid_round: Some(ROUND_0), ..Default::default() };
    context.repropose(*TEST_PROPOSAL_COMMITMENT, build_param).await;
    // Re-propose sends the same proposal content but with updated init (round, proposer,
    // valid_round).
    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    let mut expected_init = original_init;
    expected_init.round = ROUND_1;
    expected_init.proposer = build_param.proposer;
    expected_init.valid_round = build_param.valid_round;
    assert_eq!(receiver.next().await.unwrap(), ProposalPart::Init(expected_init));

    let reproposed_txs = ProposalPart::Transactions(TransactionBatch { transactions });
    assert_eq!(receiver.next().await.unwrap(), reproposed_txs);

    assert_eq!(receiver.next().await.unwrap(), fin);
    assert!(receiver.next().await.is_none());

    // Verify decision_reached uses the updated init (from reproposal round) for finalize.
    context.decision_reached(HEIGHT_0, ROUND_1, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();
}

// M-27: a reproposal must be tracked in `active_proposal` like build/validate, so that advancing
// the round cancels and tears down the (possibly in-flight) reproposal task instead of leaving it
// detached and re-converting transactions for a superseded round.
#[tokio::test]
async fn repropose_is_tracked_and_cancelled_on_round_change() {
    let (mut deps, mut network) = create_test_and_network_deps();
    deps.setup_deps_for_build(SetupDepsArgs {
        n_executed_txs_count: TX_BATCH.len(),
        ..Default::default()
    });

    const TIMESTAMP: u64 = 123456;
    let mut clock = MockClock::new();
    clock.expect_unix_now().return_const(TIMESTAMP);
    clock.expect_now().return_const(Utc.timestamp_opt(TIMESTAMP.try_into().unwrap(), 0).unwrap());
    deps.clock = Arc::new(clock);

    // A buffer of 1 guarantees the reproposal task parks mid-stream (after Init, before Fin) since
    // its output stream is never drained, letting us observe that cancellation tears it down while
    // it is still in flight.
    let mut context = deps.build_context_with_config(ContextConfig {
        static_config: ContextStaticConfig {
            proposal_buffer_size: 1,
            chain_id: CHAIN_ID,
            ..Default::default()
        },
        ..Default::default()
    });

    // Build a proposal at round 0 and drain it so the stored proposal exists and the build task
    // completes.
    let fin_receiver = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap();
    let (_, mut build_receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    while build_receiver.next().await.is_some() {}
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);

    // Advance to round 1: interrupts the finished build and clears the active-proposal slot.
    context.set_height_and_round(HEIGHT_0, ROUND_1).await.unwrap();
    assert!(context.active_proposal.is_none(), "build task should be cleared after round change");

    // Re-propose round 0's content at round 1, without draining the stream so the task stays in
    // flight (parked once the single-slot buffer fills).
    let build_param =
        BuildParam { round: ROUND_1, valid_round: Some(ROUND_0), ..Default::default() };
    context.repropose(*TEST_PROPOSAL_COMMITMENT, build_param).await;
    let (_, mut reproposal_receiver) = network.outbound_proposal_receiver.next().await.unwrap();
    assert!(
        context.active_proposal.is_some(),
        "reproposal task must be tracked in active_proposal"
    );

    // Advancing the round must cancel and await the in-flight reproposal task. If the task were not
    // cancel-aware, interrupt_active_proposal would hang here on the parked stream send.
    context.set_height_and_round(HEIGHT_0, ROUND_1 + 1).await.unwrap();
    assert!(
        context.active_proposal.is_none(),
        "reproposal task should be cleared after round change"
    );

    // The cancelled task dropped its stream sender before reaching Fin, so the abandoned stream for
    // the superseded round closes without ever delivering a Fin part.
    let mut saw_fin = false;
    while let Some(part) = reproposal_receiver.next().await {
        saw_fin |= matches!(part, ProposalPart::Fin(_));
    }
    assert!(!saw_fin, "cancelled reproposal must not deliver a Fin for the superseded round");
}

#[tokio::test]
async fn gas_price_fri_out_of_range() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();

    deps.batcher
        .expect_start_height()
        .times(1)
        .withf(|input| input.height == HEIGHT_0)
        .return_const(Ok(()));
    let mut context = deps.build_context();
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();
    let (_content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    // Receive a block info with l1_gas_price_fri that is outside the margin of error.
    let mut init_1 = proposal_init(HEIGHT_0, ROUND_0);
    init_1.l1_gas_price_fri = init_1.l1_gas_price_fri.checked_mul_u128(2).unwrap();
    // Use a large enough timeout to ensure fin_receiver was canceled due to invalid init,
    // not due to a timeout.
    let fin_receiver = context.validate_proposal(init_1, TIMEOUT * 100, content_receiver).await;
    assert_eq!(fin_receiver.await, Err(Canceled));

    // Do the same for data gas price.
    let (mut content_sender, content_receiver) =
        mpsc::channel(context.config.static_config.proposal_buffer_size);
    let mut init_2 = proposal_init(HEIGHT_0, ROUND_0);
    init_2.l1_data_gas_price_fri = init_2.l1_data_gas_price_fri.checked_mul_u128(2).unwrap();
    content_sender.send(ProposalPart::Init(init_2).clone()).await.unwrap();
    // Use a large enough timeout to ensure fin_receiver was canceled due to invalid init,
    // not due to a timeout.
    let fin_receiver = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT * 100, content_receiver)
        .await;
    assert_eq!(fin_receiver.await, Err(Canceled));
    // TODO(guyn): How to check that the rejection is due to the l1_gas_price_fri mismatch?
}

#[rstest]
#[case::maximum(true)]
#[case::minimum(false)]
#[tokio::test]
async fn gas_price_limits(#[case] maximum: bool) {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_deps_for_validate(SetupDepsArgs::default());
    let context_config = ContextDynamicConfig::default();
    let min_gas_price = context_config.min_l1_gas_price_wei;
    let min_data_price = context_config.min_l1_data_gas_price_wei;
    let max_gas_price = context_config.max_l1_gas_price_wei;
    let max_data_price = context_config.max_l1_data_gas_price_wei;

    let measured_price = if maximum {
        // Take the higher maximum price and go much higher than that.
        // If we don't go much higher, the l1_data_gas_price_multiplier will
        // lower the data gas price below the clamp limit.
        std::cmp::max(max_gas_price, max_data_price) * 100
    } else {
        0
    };
    let mut l1_gas_price_provider = MockL1GasPriceProviderClient::new();
    l1_gas_price_provider.expect_get_rate().returning(|_| Ok(ETH_TO_FRI_RATE));
    l1_gas_price_provider.expect_get_price_info().returning(move |_| {
        Ok(PriceInfo {
            base_fee_per_gas: GasPrice(measured_price),
            blob_fee: GasPrice(measured_price),
        })
    });

    deps.l1_gas_price_provider = l1_gas_price_provider;
    let mut context = deps.build_context();

    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();

    let mut init = proposal_init(HEIGHT_0, ROUND_0);

    if maximum {
        // Set the gas price to the maximum value.
        init.l1_gas_price_wei = GasPrice(max_gas_price);
        init.l1_data_gas_price_wei = GasPrice(max_data_price);
        init.l1_gas_price_fri = init.l1_gas_price_wei.wei_to_fri(ETH_TO_FRI_RATE).unwrap();
        init.l1_data_gas_price_fri =
            init.l1_data_gas_price_wei.wei_to_fri(ETH_TO_FRI_RATE).unwrap();
    } else {
        // Set the gas price to the minimum value.
        init.l1_gas_price_wei = GasPrice(min_gas_price);
        init.l1_data_gas_price_wei = GasPrice(min_data_price);
        init.l1_gas_price_fri = init.l1_gas_price_wei.wei_to_fri(ETH_TO_FRI_RATE).unwrap();
        init.l1_data_gas_price_fri =
            init.l1_data_gas_price_wei.wei_to_fri(ETH_TO_FRI_RATE).unwrap();
    }

    // Send transactions and then fin.
    let content_receiver = send_proposal_to_validator_context(&mut context).await;

    // Even though we used the minimum/maximum gas price, not the values we gave the provider,
    // the proposal should be still be valid due to the clamping of limit prices.
    let fin_receiver = context.validate_proposal(init, TIMEOUT, content_receiver).await;
    assert_eq!(fin_receiver.await, Ok(*TEST_PROPOSAL_COMMITMENT));
}

#[tokio::test]
async fn decision_reached_sends_correct_values() {
    let (mut deps, _network) = create_test_and_network_deps();

    let recorder = PrometheusBuilder::new().build_recorder();
    let _recorder_guard = metrics::set_default_local_recorder(&recorder);
    // We need to create a valid proposal to call decision_reached on.
    //
    // 1. Build proposal setup starts.
    deps.setup_deps_for_build(SetupDepsArgs::default());

    const BLOCK_TIME_STAMP_SECONDS: u64 = 123456;
    let mut clock = MockClock::new();
    clock.expect_unix_now().return_const(BLOCK_TIME_STAMP_SECONDS);
    clock
        .expect_now()
        .return_const(Utc.timestamp_opt(BLOCK_TIME_STAMP_SECONDS.try_into().unwrap(), 0).unwrap());
    deps.clock = Arc::new(clock);

    // 2. Decision reached setup starts.
    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(move |_| Ok(DecisionReachedResponse::default()));

    // This is the actual part of the test that checks the values are correct.
    // TODO(guy.f): Add expectations and validations for all the other values being written.
    deps.state_sync_client.expect_add_new_block().times(1).return_once(|proposal_init| {
        assert_eq!(proposal_init.block_header_without_hash.timestamp.0, BLOCK_TIME_STAMP_SECONDS);
        Ok(())
    });

    deps.cende_ambassador
        .expect_prepare_blob_for_next_height()
        // TODO(guy.f): Verify the values sent here are correct.
        .return_once(|_height| Ok(()));

    let mut context = deps.build_context();

    // This sets up the required state for the test, prior to running the code being tested.
    let _fin = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap().await;
    // At this point we should have a valid proposal in the context which contains the timestamp.

    context.decision_reached(HEIGHT_0, ROUND_0, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();

    let metrics = recorder.handle().render();
    CONSENSUS_L2_GAS_PRICE
        .assert_eq(&metrics, VersionedConstants::latest_constants().min_gas_price.0);
    // The price landed at the configured minimum (empty `min_l2_gas_price_per_height` → the
    // versioned-constants fallback), so the "at minimum" gauge must report 1.
    CONSENSUS_L2_GAS_PRICE_AT_MINIMUM.assert_eq(&metrics, 1);
}

// A proposer computes the next price twice for the same block, once for the fin and once at
// decision time. The clamp counter must move once, so that it stays comparable with a validator's.
#[tokio::test]
async fn clamped_l2_gas_price_counts_once_per_committed_block() {
    let (mut deps, _network) = create_test_and_network_deps();

    let recorder = PrometheusBuilder::new().build_recorder();
    let _recorder_guard = metrics::set_default_local_recorder(&recorder);
    CONSENSUS_L2_GAS_PRICE_CLAMPED.register();

    // A full block at the ceiling drives the EIP-1559 result above it.
    deps.setup_deps_for_build(SetupDepsArgs {
        l2_gas_used: Some(VersionedConstants::latest_constants().max_block_size),
        ..Default::default()
    });
    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(move |_| Ok(DecisionReachedResponse::default()));
    deps.state_sync_client.expect_add_new_block().times(1).return_once(|_| Ok(()));
    deps.cende_ambassador.expect_prepare_blob_for_next_height().return_once(|_height| Ok(()));

    let mut context = deps.build_context();
    context.l2_gas_price = TEST_MAX_L2_GAS_PRICE;
    // `fee_proposals_window` is empty, so the proposer's `fee_proposal_fri` is `l2_gas_price`.
    let proposal_commitment =
        proposal_commitment_from(PARTIAL_BLOCK_HASH, Some(TEST_MAX_L2_GAS_PRICE));

    let _fin = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap().await;
    context.decision_reached(HEIGHT_0, ROUND_0, proposal_commitment, false).await.unwrap();

    assert_eq!(context.l2_gas_price, TEST_MAX_L2_GAS_PRICE);
    CONSENSUS_L2_GAS_PRICE_CLAMPED.assert_eq(
        &recorder.handle().render(),
        1,
        &[(LABEL_L2_GAS_PRICE_CLAMP_BOUND, "maximum")],
    );
}

// The blob's `parent_proposal_commitment` must bind the parent block's `fee_proposal_fri`, which
// is read from `fee_proposals_window`. Build/decide at HEIGHT_1 so the parent (HEIGHT_0) exists,
// seed the window with a parent fee distinct from the current block's, and assert the blob carries
// the V0_14_3 commitment `Poseidon(partial_block_hash, parent_fee_proposal)`.
#[tokio::test]
async fn blob_parent_proposal_commitment_binds_parent_fee_proposal() {
    const PARENT_FEE_PROPOSAL: GasPrice = GasPrice(5_000_000_000);

    let (mut deps, _network) = create_test_and_network_deps();

    deps.setup_deps_for_build(SetupDepsArgs { start_block_number: HEIGHT_1, ..Default::default() });

    deps.batcher.expect_decision_reached().times(1).return_once(move |_| {
        Ok(DecisionReachedResponse {
            central_objects: CentralObjects {
                parent_proposal_commitment: Some(BatcherProposalCommitment {
                    partial_block_hash: PARTIAL_BLOCK_HASH,
                }),
                ..Default::default()
            },
            ..Default::default()
        })
    });

    deps.state_sync_client.expect_add_new_block().times(1).return_once(|_| Ok(()));

    let expected_parent_commitment =
        proposal_commitment_from(PARTIAL_BLOCK_HASH, Some(PARENT_FEE_PROPOSAL));
    deps.cende_ambassador.expect_prepare_blob_for_next_height().times(1).return_once(
        move |params| {
            assert_eq!(params.proposal_commitment, *TEST_PROPOSAL_COMMITMENT);
            assert_eq!(params.parent_proposal_commitment, Some(expected_parent_commitment));
            Ok(())
        },
    );

    let mut context = deps.build_context();

    let _fin = context
        .build_proposal(BuildParam { height: HEIGHT_1, ..Default::default() }, TIMEOUT)
        .await
        .unwrap()
        .await;
    // Seed the parent fee after building, so the current block still uses the default fee_proposal.
    context.fee_proposals_window.insert(HEIGHT_0, Some(PARENT_FEE_PROPOSAL));

    context.decision_reached(HEIGHT_1, ROUND_0, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();
}

#[tokio::test]
async fn decision_reached_attaches_state_commitment_infos_to_blob() {
    let (mut deps, _network) = create_test_and_network_deps();

    // The batcher serves the compressed witness; the orchestrator forwards it verbatim.
    let state_commitment_infos = default_state_commitment_infos();

    let returned_infos = state_commitment_infos.clone();
    deps.batcher
        .expect_get_state_commitment_infos()
        .times(1)
        .return_once(move |_| Ok(Some(returned_infos)));

    deps.setup_deps_for_build(SetupDepsArgs::default());
    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(|_| Ok(DecisionReachedResponse::default()));
    deps.state_sync_client.expect_add_new_block().times(1).return_once(|_| Ok(()));

    deps.cende_ambassador.expect_prepare_blob_for_next_height().times(1).return_once(
        move |blob_parameters| {
            assert_eq!(
                blob_parameters.recent_state_commitment_infos,
                vec![StateCommitmentInfosAndNumber {
                    state_commitment_infos,
                    block_number: HEIGHT_0
                }]
            );
            Ok(())
        },
    );

    let mut context = deps.build_context();
    let _fin = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap().await;
    context.decision_reached(HEIGHT_0, ROUND_0, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();
}
// When `send_empty_state_commitment_infos_only` is enabled, the same heights are sent, each
// carrying an empty object; the batcher is only asked whether it has the infos, never for their
// content.
#[tokio::test]
async fn collect_recent_state_commitment_infos_sends_empty_objects_when_configured() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.batcher
        .expect_get_state_commitment_infos()
        .returning(|_| panic!("stored state commitment infos must not be read"));
    deps.batcher
        .expect_has_state_commitment_infos()
        .returning(|block_number| Ok((90..=100).contains(&block_number.0)));
    deps.cende_ambassador
        .expect_commitment_infos_height_offset()
        .times(1)
        .return_once(|| Ok(Some(BlockNumber(98))));

    let context = deps.build_context_with_config(ContextConfig {
        static_config: ContextStaticConfig {
            chain_id: CHAIN_ID,
            send_empty_state_commitment_infos_only: true,
            ..Default::default()
        },
        ..Default::default()
    });
    let collected = context.collect_recent_state_commitment_infos(BlockNumber(100)).await.unwrap();
    let expected: Vec<_> = (98..=100)
        .map(|height| StateCommitmentInfosAndNumber {
            state_commitment_infos: CompressedStateCommitmentInfos {
                version: STATE_COMMITMENT_INFOS_VERSION,
                payload: CompressedPayload(Vec::new()),
            },
            block_number: BlockNumber(height),
        })
        .collect();
    assert_eq!(collected, expected);
}

fn default_state_commitment_infos() -> CompressedStateCommitmentInfos {
    CompressedStateCommitmentInfos {
        version: STATE_COMMITMENT_INFOS_VERSION,
        payload: CompressedPayload(b"compressed-state-commitment-infos".to_vec()),
    }
}

fn sync_block_with_version(starknet_version: StarknetVersion) -> SyncBlock {
    SyncBlock {
        block_header_without_hash: BlockHeaderWithoutHash {
            starknet_version,
            ..Default::default()
        },
        ..Default::default()
    }
}

/// Returns the block numbers `collect_recent_state_commitment_infos` sends for `height` when the
/// cende recorder reports `offset`, the batcher only has stored commitment infos for heights in
/// `committed_heights` (reporting `None` for the rest), and the chain upgraded to the first
/// version with state commitment infos at `first_upgraded_height`.
async fn collected_heights_for(
    height: BlockNumber,
    cende_offset: Option<BlockNumber>,
    committed_heights: Vec<u64>,
    first_upgraded_height: u64,
) -> Vec<u64> {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.batcher.expect_get_state_commitment_infos().returning(move |block_number| {
        Ok(committed_heights.contains(&block_number.0).then(default_state_commitment_infos))
    });
    deps.state_sync_client.expect_get_block().returning(move |block_number| {
        Ok(sync_block_with_version(if block_number.0 < first_upgraded_height {
            StarknetVersion::V0_14_3
        } else {
            StarknetVersion::V0_14_4
        }))
    });
    deps.cende_ambassador
        .expect_commitment_infos_height_offset()
        .times(1)
        .return_once(move || Ok(cende_offset));

    let context = deps.build_context();
    context
        .collect_recent_state_commitment_infos(height)
        .await
        .expect("offset query should succeed")
        .iter()
        .map(|info| info.block_number.0)
        .collect()
}

// `height` is fixed at 100; each case sets the cende recorder's reported offset (its next
// produced block), the heights the batcher has stored commitment infos for (a `None` from the
// batcher marks a gap in the stored witnesses), the first height whose Starknet version has
// state commitment infos, and the block numbers we expect to send.
#[rstest]
#[case::delta_above_cende_recorder(Some(BlockNumber(98)), (90..=100).collect(), 0, vec![98, 99, 100])]
#[case::single_new_block(Some(BlockNumber(100)), (90..=100).collect(), 0, vec![100])]
#[case::fallback_window_when_cende_recorder_empty(None, (90..=100).collect(), 0, (90..=99).collect())]
#[case::nothing_when_cende_recorder_caught_up(Some(BlockNumber(101)), (90..=100).collect(), 0, vec![])]
#[case::empty_cende_recorder_stops_at_trailing_gap(None, (90..=95).collect(), 0, (90..=95).collect())]
#[case::non_empty_cende_recorder_stops_at_middle_gap(Some(BlockNumber(90)), (90..=92).chain(95..=100).collect(), 0, (90..=92).collect())]
// Only the fallback window of an empty cende recorder can reach blocks below the upgrade height;
// those have no commitment infos by design and are skipped wherever they appear in it. A recorder
// that reported an offset has already stored commitment infos, so a missing object there is a real
// gap and the version is never consulted.
#[case::empty_cende_recorder_skips_pre_upgrade_blocks(None, (93..=100).collect(), 93, (93..=100).collect())]
#[case::non_empty_cende_recorder_breaks_on_first_gap(Some(BlockNumber(90)), (93..=100).collect(), 93, vec![])]
#[case::all_blocks_predate_the_upgrade(None, vec![], 200, vec![])]
// A block at or above the upgrade height whose commitment infos are missing ends the collection,
// even while the leading pre-upgrade blocks were skipped.
#[case::breaks_on_the_first_missing_upgraded_block(None, (94..=100).collect(), 93, vec![])]
#[case::breaks_on_a_gap_above_the_upgrade_height(None, (93..=95).chain(98..=100).collect(), 93, (93..=95).collect())]
#[tokio::test]
async fn collect_recent_state_commitment_infos_sends_expected_delta(
    #[case] cende_offset: Option<BlockNumber>,
    #[case] committed_heights: Vec<u64>,
    #[case] first_upgraded_height: u64,
    #[case] expected: Vec<u64>,
) {
    let height = BlockNumber(100);
    let heights =
        collected_heights_for(height, cende_offset, committed_heights, first_upgraded_height).await;
    assert_eq!(heights, expected);
}

// A cende recorder that reported an offset has already stored commitment infos, so no block in
// that window can predate the upgrade; the version must not be queried at all there.
#[tokio::test]
async fn collect_recent_state_commitment_infos_skips_the_version_query_when_the_recorder_is_not_empty()
 {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.batcher.expect_get_state_commitment_infos().returning(|_| Ok(None));
    deps.state_sync_client.expect_get_block().never();
    deps.cende_ambassador
        .expect_commitment_infos_height_offset()
        .times(1)
        .return_once(|| Ok(Some(BlockNumber(90))));

    let context = deps.build_context();
    let collected = context.collect_recent_state_commitment_infos(BlockNumber(100)).await.unwrap();
    assert!(collected.is_empty(), "expected the gap at height 90 to end the collection");
}

// An unreadable Starknet version must not be taken as "predates the upgrade", or a real gap would
// be skipped and every remaining height re-sent on every block.
#[tokio::test]
async fn collect_recent_state_commitment_infos_stops_when_the_block_version_is_unknown() {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.batcher
        .expect_get_state_commitment_infos()
        .returning(|block_number| Ok((block_number.0 >= 95).then(default_state_commitment_infos)));
    deps.state_sync_client.expect_get_block().returning(|block_number| {
        Err(StateSyncClientError::StateSyncError(StateSyncError::BlockNotFound(block_number)))
    });
    deps.cende_ambassador.expect_commitment_infos_height_offset().times(1).return_once(|| Ok(None));

    let context = deps.build_context();
    let collected = context.collect_recent_state_commitment_infos(BlockNumber(100)).await.unwrap();
    assert!(
        collected.is_empty(),
        "expected the collection to stop at height 90, got {collected:?}"
    );
}
#[tokio::test]
async fn collect_recent_state_commitment_infos_errors_on_offset_query_failure() {
    // A failed offset query must propagate, not silently fall back to genesis.
    let (mut deps, _network) = create_test_and_network_deps();
    deps.batcher
        .expect_get_state_commitment_infos()
        .returning(|_| Ok(Some(default_state_commitment_infos())));
    deps.cende_ambassador.expect_commitment_infos_height_offset().times(1).return_once(|| {
        Err(CendeAmbassadorError::RecorderRequestFailed {
            path: "get_witness_height_offset".to_string(),
            message: "request failed".to_string(),
        })
    });

    let context = deps.build_context();
    let result = context.collect_recent_state_commitment_infos(BlockNumber(100)).await;
    assert!(
        matches!(&result, Err(CendeAmbassadorError::RecorderRequestFailed { .. })),
        "expected the offset query error to propagate, got {result:?}"
    );
}

#[traced_test]
#[rstest]
#[case::batcher_has_infos(Ok(true), "has the state commitment infos of the stop height 100")]
#[case::batcher_missing_infos(
    Ok(false),
    "Stopping at height 100, but the batcher has no state commitment infos for it"
)]
#[case::check_fails(
    Err(BatcherClientError::BatcherError(BatcherError::InternalError)),
    "Failed to check whether the batcher has the state commitment infos of the stop height 100"
)]
#[tokio::test]
async fn state_commitment_infos_check_at_stop_height_logs_storage_status(
    #[case] has_infos_result: BatcherClientResult<bool>,
    #[case] expected_log: &str,
) {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.batcher
        .expect_has_state_commitment_infos()
        .withf(|block_number| block_number.0 == 100)
        .times(1)
        .return_once(move |_| has_infos_result);

    let context = deps.build_context();
    context.warn_on_missing_state_commitment_infos_at_stop_height(BlockNumber(100)).await;
    assert!(logs_contain(expected_log), "expected a log containing: {expected_log}");
}

/// Verify that when `stop_at_height` is set and decision is reached at that height:
/// 1. `wait_for_block_hash` retries until the batcher has computed the hash.
/// 2. The blob contains the block hash of that height.
/// 3. `write_prev_height_blob` is called immediately (not during next round proposal).
#[tokio::test]
async fn decision_reached_at_stop_height_writes_blob_immediately() {
    const STOP_HEIGHT: BlockNumber = BlockNumber(20);
    // The hash of block n is BlockHash(n), giving each block a distinct, predictable hash.
    let block_hash_fn = |n: u64| BlockHash(StarkHash::from(n));

    let (mut deps, _network) = create_test_and_network_deps();

    // Expectations added BEFORE setup_deps_for_validate so they are matched first (FIFO).

    // Heights 10–19: already committed; get_block_hash returns immediately for both the
    // retrospective_block_hash check (called during validate_proposal) and
    // collect_recent_block_hashes (called during finalize_decision).
    deps.batcher
        .expect_get_block_hash()
        .withf(|n| n.0 >= 10 && n.0 < STOP_HEIGHT.0)
        .returning(move |n| Ok(block_hash_fn(n.0)));

    // The retrospective_block_hash logic also queries state_sync for block 10.
    deps.state_sync_client
        .expect_get_block_hash()
        .withf(|n| n.0 == 10)
        .return_once(move |n| Ok(block_hash_fn(n.0)));

    // Height STOP_HEIGHT: first 2 calls return BlockHashNotFound (batcher not yet ready),
    // then all subsequent calls succeed — covering both wait_for_block_hash (3rd call)
    // and the collect_recent_block_hashes pass.
    deps.batcher
        .expect_get_block_hash()
        .withf(move |n| *n == STOP_HEIGHT)
        .times(2)
        .returning(|n| Err(BatcherClientError::BatcherError(BatcherError::BlockHashNotFound(n))));
    deps.batcher
        .expect_get_block_hash()
        .withf(move |n| *n == STOP_HEIGHT)
        .returning(move |n| Ok(block_hash_fn(n.0)));

    // write_prev_height_blob must be called immediately after decision, with height STOP_HEIGHT+1.
    deps.cende_ambassador
        .expect_write_prev_height_blob()
        .withf(move |h| *h == STOP_HEIGHT.unchecked_next())
        .times(1)
        .return_once(|_| tokio::spawn(ready(true)));

    // Once the block hash wait is over, the stop-height check queries the batcher for the stop
    // height's state commitment infos.
    deps.batcher
        .expect_has_state_commitment_infos()
        .withf(move |block_number| *block_number == STOP_HEIGHT)
        .times(1)
        .returning(|_| Ok(true));

    deps.setup_deps_for_validate(SetupDepsArgs {
        start_block_number: STOP_HEIGHT,
        ..Default::default()
    });

    deps.batcher
        .expect_decision_reached()
        .times(1)
        .return_once(|_| Ok(DecisionReachedResponse::default()));

    deps.state_sync_client.expect_add_new_block().times(1).return_once(|_| Ok(()));

    // Verify the blob contains the block hash of the stop height.
    deps.cende_ambassador.expect_prepare_blob_for_next_height().times(1).return_once(
        move |params| {
            assert_eq!(
                params.recent_block_hashes.len(),
                usize::try_from(N_BLOCK_HASHES_BACK_IN_BLOB + 1).unwrap()
            );
            assert!(
                params.recent_block_hashes.last().is_some_and(
                    |bhn| bhn.number == STOP_HEIGHT && bhn.hash == block_hash_fn(STOP_HEIGHT.0)
                ),
                "Blob's recent_block_hashes should include block {STOP_HEIGHT}'s hash"
            );
            Ok(())
        },
    );

    let mut context = deps.build_context();
    // Make wait_for_block_hash retries instant so the test doesn't sleep 500ms per retry.
    context.config.static_config.retrospective_block_hash_retry_interval_millis =
        Duration::from_millis(10);

    context.set_height_and_round(STOP_HEIGHT, ROUND_0).await.unwrap();

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context
        .validate_proposal(proposal_init(STOP_HEIGHT, ROUND_0), TIMEOUT, content_receiver)
        .await;
    let proposal_commitment = fin_receiver.await.unwrap();

    context.decision_reached(STOP_HEIGHT, ROUND_0, proposal_commitment, true).await.unwrap();
}

#[rstest]
#[case::l1_price_oracle_failure(true)]
#[case::eth_to_strk_rate_oracle_failure(false)]
#[tokio::test]
async fn oracle_fails_on_startup(#[case] l1_oracle_failure: bool) {
    let (mut deps, mut network) = create_test_and_network_deps();
    deps.setup_deps_for_build(SetupDepsArgs::default());

    if l1_oracle_failure {
        let mut l1_prices_oracle_client = MockL1GasPriceProviderClient::new();
        l1_prices_oracle_client.expect_get_rate().returning(|_| Ok(ETH_TO_FRI_RATE));
        l1_prices_oracle_client.expect_get_price_info().times(1).return_const(Err(
            L1GasPriceClientError::L1GasPriceProviderError(
                // random error, these parameters don't mean anything
                L1GasPriceProviderError::UnexpectedBlockNumberError { expected: 0, found: 1 },
            ),
        ));
        deps.l1_gas_price_provider = l1_prices_oracle_client;
    } else {
        let mut l1_prices_oracle_client = MockL1GasPriceProviderClient::new();
        l1_prices_oracle_client.expect_get_price_info().returning(|_| {
            Ok(PriceInfo {
                base_fee_per_gas: GasPrice(TEMP_ETH_GAS_FEE_IN_WEI),
                blob_fee: GasPrice(TEMP_ETH_BLOB_GAS_FEE_IN_WEI),
            })
        });
        l1_prices_oracle_client.expect_get_rate().times(1).return_once(|_| {
            Err(L1GasPriceClientError::ExchangeRateOracleClientError(
                ExchangeRateOracleClientError::MissingFieldError("".to_string(), "".to_string()),
            ))
        });
        deps.l1_gas_price_provider = l1_prices_oracle_client;
    }

    let mut context = deps.build_context();

    let build_param = BuildParam::default();

    let fin_receiver = context.build_proposal(build_param, TIMEOUT).await.unwrap();

    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();

    let part = receiver.next().await.unwrap();
    let ProposalPart::Init(info) = part else {
        panic!("Expected ProposalPart::Init");
    };

    let default_context_config = ContextDynamicConfig::default();
    // Despite the l1_gas_price_provider being set up not to fail, we still expect the default
    // values because eth_to_strk_rate_oracle_client failed.
    assert_eq!(info.l1_gas_price_wei.0, default_context_config.min_l1_gas_price_wei);
    assert_eq!(info.l1_data_gas_price_wei.0, default_context_config.min_l1_data_gas_price_wei);

    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() })
    );
    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Fin(ProposalFin {
            proposal_commitment: *TEST_PROPOSAL_COMMITMENT,
            executed_transaction_count: INTERNAL_TX_BATCH.len().try_into().unwrap(),
            fin_payload: Some(ProposalFinPayload {
                commitment_parts: CommitmentParts::default(),
                l2_gas_info: expected_l2_gas_info_for_build_proposal_defaults(),
            }),
        })
    );
    assert!(receiver.next().await.is_none());
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);
}

#[rstest]
#[case::l1_price_oracle_failure(true)]
#[case::eth_to_strk_rate_oracle_failure(false)]
#[tokio::test]
async fn oracle_fails_on_second_block(#[case] l1_oracle_failure: bool) {
    let (mut deps, mut network) = create_test_and_network_deps();
    // Validate block number 0, call decision_reached to save the previous block info (block 0), and
    // attempt to build_proposal on block number 1.
    deps.setup_deps_for_validate(SetupDepsArgs::default());
    deps.setup_deps_for_build(SetupDepsArgs { start_block_number: HEIGHT_1, ..Default::default() });

    // set up batcher decision_reached
    deps.batcher.expect_decision_reached().times(1).return_once(|_| {
        Ok(DecisionReachedResponse {
            state_diff: ThinStateDiff::default(),
            central_objects: CentralObjects::default(),
        })
    });

    // required for decision reached flow
    deps.state_sync_client.expect_add_new_block().times(1).return_once(|_| Ok(()));
    deps.cende_ambassador.expect_prepare_blob_for_next_height().times(1).return_once(|_| Ok(()));

    // set the oracle to succeed on first block and fail on second
    if l1_oracle_failure {
        let mut l1_prices_oracle_client = MockL1GasPriceProviderClient::new();
        l1_prices_oracle_client.expect_get_rate().returning(|_| Ok(ETH_TO_FRI_RATE));
        l1_prices_oracle_client.expect_get_price_info().times(1).return_const(Ok(PriceInfo {
            base_fee_per_gas: GasPrice(TEMP_ETH_GAS_FEE_IN_WEI),
            blob_fee: GasPrice(TEMP_ETH_BLOB_GAS_FEE_IN_WEI),
        }));
        l1_prices_oracle_client.expect_get_price_info().times(1).return_const(Err(
            L1GasPriceClientError::L1GasPriceProviderError(
                // random error, these parameters don't mean anything
                L1GasPriceProviderError::UnexpectedBlockNumberError { expected: 0, found: 1 },
            ),
        ));
        deps.l1_gas_price_provider = l1_prices_oracle_client;
    } else {
        let mut l1_prices_oracle_client = MockL1GasPriceProviderClient::new();
        // Make sure the L1 gas price always returns with good values.
        l1_prices_oracle_client.expect_get_price_info().returning(|_| {
            Ok(PriceInfo {
                base_fee_per_gas: GasPrice(TEMP_ETH_GAS_FEE_IN_WEI),
                blob_fee: GasPrice(TEMP_ETH_BLOB_GAS_FEE_IN_WEI),
            })
        });
        // Set the eth_to_fri_rate to succeed on first block and fail on second.
        l1_prices_oracle_client.expect_get_rate().times(1).return_once(|_| Ok(ETH_TO_FRI_RATE));
        // Set the eth_to_fri_rate to fail on second block.
        l1_prices_oracle_client.expect_get_rate().times(1).return_once(|_| {
            Err(L1GasPriceClientError::ExchangeRateOracleClientError(
                ExchangeRateOracleClientError::MissingFieldError("".to_string(), "".to_string()),
            ))
        });
        deps.l1_gas_price_provider = l1_prices_oracle_client;
    }

    let mut context = deps.build_context();

    // Validate block number 0.

    // Initialize the context for a specific height, starting with round 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT, content_receiver)
        .await;
    let proposal_commitment = fin_receiver.await.unwrap();
    assert_eq!(proposal_commitment, *TEST_PROPOSAL_COMMITMENT);

    // Decision reached

    context.decision_reached(HEIGHT_0, ROUND_0, proposal_commitment, false).await.unwrap();

    // Build proposal for block number 1.
    let build_param = BuildParam { height: HEIGHT_1, ..Default::default() };

    let fin_receiver = context.build_proposal(build_param, TIMEOUT).await.unwrap();

    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();

    let part = receiver.next().await.unwrap();
    let ProposalPart::Init(info) = part else {
        panic!("Expected ProposalPart::Init");
    };
    assert_eq!(info.height, HEIGHT_1);

    let previous_init = proposal_init(HEIGHT_0, ROUND_0);

    assert_eq!(info.l1_gas_price_wei, previous_init.l1_gas_price_wei);
    assert_eq!(info.l1_data_gas_price_wei, previous_init.l1_data_gas_price_wei);
    assert_eq!(info.l1_gas_price_fri, previous_init.l1_gas_price_fri);
    assert_eq!(info.l1_data_gas_price_fri, previous_init.l1_data_gas_price_fri);

    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Transactions(TransactionBatch { transactions: TX_BATCH.to_vec() })
    );
    assert_eq!(
        receiver.next().await.unwrap(),
        ProposalPart::Fin(ProposalFin {
            proposal_commitment: *TEST_PROPOSAL_COMMITMENT,
            executed_transaction_count: INTERNAL_TX_BATCH.len().try_into().unwrap(),
            fin_payload: Some(ProposalFinPayload {
                commitment_parts: CommitmentParts::default(),
                l2_gas_info: expected_l2_gas_info_for_build_proposal_defaults(),
            }),
        })
    );
    assert!(receiver.next().await.is_none());
    assert_eq!(fin_receiver.await.unwrap(), *TEST_PROPOSAL_COMMITMENT);
}

// L2 gas is a bit above the minimum gas price.
const ODDLY_SPECIFIC_L2_GAS_PRICE: u128 = 9999999999;
const ODDLY_SPECIFIC_L1_GAS_PRICE: u128 = 1234567890;
const ODDLY_SPECIFIC_L1_DATA_GAS_PRICE: u128 = 987654321;
const ODDLY_SPECIFIC_CONVERSION_RATE: u128 = 12345678901234567890;

// If we use low numbers for fri/wei we have to make sure the conversion (eth to fri) and eth-to-wei
// factor (wei to eth) don't go below zero in either direction. Typically the gas price (in
// particular the data gas price) can be as low as 1, so the eth-to-fri rate must be above 10^18.
// That also means that the L2 gas (in fri) must be bigger than the ratio of the conversion rate and
// the eth-to-wei factor. Must use a large enough number that conversion to wei works
const LOW_OVERRIDE_L2_GAS_PRICE: u128 = 25; // FRI
// Must be larger than 10 since ETH_TO_WEI is 10^18 and LOW_OVERRIDE_CONVERSION_RATE is 10^19
const LOW_OVERRIDE_L1_GAS_PRICE: u128 = 100; // FRI
const LOW_OVERRIDE_L1_DATA_GAS_PRICE: u128 = 100; // FRI
// ETH_TO_FRI_RATE must be larger/equal to 10^18 (wei to eth conversion factor)
const LOW_OVERRIDE_CONVERSION_RATE: u128 = u128::pow(10, 19);

// If we use really low L2 gas price, the block will fail to build.
const LOW_OVERRIDE_L2_GAS_PRICE_FAIL: u128 = 1; // FRI

#[rstest]
#[case::dont_override_prices(None, None, None, None, true)]
#[case::override_l2_gas_price(Some(ODDLY_SPECIFIC_L2_GAS_PRICE), None, None, None, true)]
#[case::override_l1_gas_price(None, Some(ODDLY_SPECIFIC_L1_GAS_PRICE), None, None, true)]
#[case::override_l1_data_gas_price(None, None, Some(ODDLY_SPECIFIC_L1_DATA_GAS_PRICE), None, true)]
#[case::override_eth_to_strk_rate(None, None, None, Some(ODDLY_SPECIFIC_CONVERSION_RATE), true)]
#[case::override_all_prices(
    Some(ODDLY_SPECIFIC_L2_GAS_PRICE),
    Some(ODDLY_SPECIFIC_L1_GAS_PRICE),
    Some(ODDLY_SPECIFIC_L1_DATA_GAS_PRICE),
    None,
    true
)]
#[case::override_everything(
    Some(ODDLY_SPECIFIC_L2_GAS_PRICE),
    Some(ODDLY_SPECIFIC_L1_GAS_PRICE),
    Some(ODDLY_SPECIFIC_L1_DATA_GAS_PRICE),
    Some(ODDLY_SPECIFIC_CONVERSION_RATE),
    true
)]
#[case::low_overrides(
    Some(LOW_OVERRIDE_L2_GAS_PRICE),
    Some(LOW_OVERRIDE_L1_GAS_PRICE),
    Some(LOW_OVERRIDE_L1_DATA_GAS_PRICE),
    Some(LOW_OVERRIDE_CONVERSION_RATE),
    true
)]
#[case::low_l2_gas_price_fail(
    Some(LOW_OVERRIDE_L2_GAS_PRICE_FAIL),
    None,
    None,
    Some(LOW_OVERRIDE_CONVERSION_RATE),
    false
)]
#[tokio::test]
async fn override_prices_behavior(
    #[case] override_l2_gas_price_fri: Option<u128>,
    #[case] override_l1_gas_price_fri: Option<u128>,
    #[case] override_l1_data_gas_price_fri: Option<u128>,
    #[case] override_eth_to_fri_rate: Option<u128>,
    #[case] build_success: bool,
) {
    // Use high gas usage to ensure the L2 gas price is high.
    let high_l2_gas_used = VersionedConstants::latest_constants().max_block_size;

    let (mut deps, _network) = create_test_and_network_deps();

    // Setup dependencies and mocks.
    #[allow(clippy::as_conversions)]
    deps.setup_deps_for_build(SetupDepsArgs {
        number_of_times: build_success as usize,
        l2_gas_used: Some(high_l2_gas_used),
        ..Default::default()
    });
    if !build_success {
        // We use number_of_times equal zero in this case, but we still expect the start height to
        // be called.
        deps.batcher.expect_start_height().times(1).return_once(|_| Ok(()));
    }
    deps.batcher.expect_decision_reached().return_once(move |_| {
        Ok(DecisionReachedResponse {
            state_diff: ThinStateDiff::default(),
            central_objects: CentralObjects::default(),
        })
    });

    deps.state_sync_client.expect_add_new_block().return_once(|_| Ok(()));
    deps.cende_ambassador.expect_prepare_blob_for_next_height().return_once(|_| Ok(()));

    let context_config = ContextConfig {
        dynamic_config: ContextDynamicConfig {
            override_l2_gas_price_fri,
            override_l1_gas_price_fri,
            override_l1_data_gas_price_fri,
            override_eth_to_fri_rate,
            ..Default::default()
        },
        ..Default::default()
    };
    let mut context = deps.build_context();
    context.config = context_config;

    let min_gas_price = VersionedConstants::latest_constants().min_gas_price.0;
    let gas_price_params = make_gas_price_params(&context.config.dynamic_config);
    let mut expected_l1_prices = PriceInfo {
        base_fee_per_gas: GasPrice(TEMP_ETH_GAS_FEE_IN_WEI),
        blob_fee: GasPrice(TEMP_ETH_BLOB_GAS_FEE_IN_WEI),
    };
    apply_fee_transformations(&mut expected_l1_prices, &gas_price_params);

    // Run proposal and decision logic.
    let fin_result = context.build_proposal(BuildParam::default(), TIMEOUT).await.unwrap().await;

    // In cases where we expect the batcher to fail the block build.
    if build_success {
        assert!(fin_result.is_ok(), "Expected build to succeed, but got error: {:?}", fin_result);
    } else {
        // The build fails because the L2 gas price in wei we get, after using the eth/fri rate we
        // calculated from the block info, is zero.
        assert!(fin_result.is_err(), "Expected build to fail, but got success: {:?}", fin_result);
        return;
    }

    context.decision_reached(HEIGHT_0, ROUND_0, *TEST_PROPOSAL_COMMITMENT, false).await.unwrap();

    let actual_l2_gas_price = context.l2_gas_price.0;

    let previous_block = context.previous_proposal_init.clone().unwrap();
    let actual_l1_gas_price = previous_block.l1_prices_fri.l1_gas_price.0;
    let actual_l1_data_gas_price = previous_block.l1_prices_fri.l1_data_gas_price.0;
    let actual_conversion_rate = previous_block
        .l1_prices_fri
        .l1_gas_price
        .0
        .checked_mul(WEI_PER_ETH)
        .unwrap()
        .checked_div(previous_block.l1_prices_wei.l1_gas_price.0)
        .unwrap();

    let expected_wei_to_fri_rate = override_eth_to_fri_rate.unwrap_or(ETH_TO_FRI_RATE);
    let expected_l1_gas_price_fri = GasPrice(expected_l1_prices.base_fee_per_gas.0)
        .wei_to_fri(expected_wei_to_fri_rate)
        .unwrap()
        .0;
    let expected_l1_data_gas_price_fri =
        GasPrice(expected_l1_prices.blob_fee.0).wei_to_fri(expected_wei_to_fri_rate).unwrap().0;

    if let Some(override_l2_gas_price) = override_l2_gas_price_fri {
        // In this case the L2 gas price must match the given override.
        assert_eq!(
            actual_l2_gas_price, override_l2_gas_price,
            "Mismatch in L2 gas price. Actual: {actual_l2_gas_price} expected (override) l2 gas \
             price: {override_l2_gas_price}.",
        );
    } else {
        // In this case the regular L2 gas calculation takes place, and gives a higher price.
        assert!(
            actual_l2_gas_price > min_gas_price,
            "Mismatch in L2 gas price. Actual: {actual_l2_gas_price} expected (minimum) l2 gas \
             price: {min_gas_price} due to high usage (EIP-1559).",
        );
    }

    if let Some(override_l1_gas_price) = override_l1_gas_price_fri {
        assert_eq!(
            actual_l1_gas_price, override_l1_gas_price,
            "Mismatch in L1 gas price. Actual: {actual_l1_gas_price} expected (override) l1 gas \
             price: {override_l1_gas_price}.",
        );
    } else {
        assert_eq!(
            actual_l1_gas_price, expected_l1_gas_price_fri,
            "Mismatch in L1 gas price. Actual: {actual_l1_gas_price} expected l1 gas price: \
             {expected_l1_gas_price_fri} (after conversion from wei to FRI).",
        );
    }

    if let Some(override_l1_data_gas_price) = override_l1_data_gas_price_fri {
        assert_eq!(
            actual_l1_data_gas_price, override_l1_data_gas_price,
            "Mismatch in L1 data gas price. Actual: {actual_l1_data_gas_price} expected \
             (override) l1 data gas price: {override_l1_data_gas_price}.",
        );
    } else {
        assert_eq!(
            actual_l1_data_gas_price, expected_l1_data_gas_price_fri,
            "Mismatch in L1 data gas price. Actual: {actual_l1_data_gas_price} expected l1 data \
             gas price: {expected_l1_data_gas_price_fri} (after conversion from wei to FRI).",
        );
    }

    // Conversion rate is recreated by comparing wei and fri prices, so it is affected by rounding
    // errors.
    if let Some(override_eth_to_fri_rate) = override_eth_to_fri_rate {
        assert!(
            almost_equal(actual_conversion_rate, override_eth_to_fri_rate),
            "Mismatch in conversion rate. Actual: {actual_conversion_rate}. expected conversion \
             rate: {override_eth_to_fri_rate}",
        );
    }
}

/// Check that two numbers are within 0.1% of each other.
fn almost_equal(a: u128, b: u128) -> bool {
    a.abs_diff(b) < a / 1000
}

#[tokio::test]
async fn change_gas_price_overrides() {
    let (mut deps, mut network) = create_test_and_network_deps();

    // Validate two blocks, between the first and the second we will change the gas price overrides.
    // After the second block we do another round with another dynamic config change.
    // Finally, we start a new round as proposer, with a third dynamic config change before it
    // starts.
    deps.setup_deps_for_validate(SetupDepsArgs { number_of_times: 2, ..Default::default() });
    deps.setup_deps_for_validate(SetupDepsArgs {
        number_of_times: 1,
        expect_start_height: false,
        start_block_number: BlockNumber(2),
        ..Default::default()
    });
    deps.setup_deps_for_build(SetupDepsArgs {
        start_block_number: BlockNumber(2),
        ..Default::default()
    });

    deps.batcher.expect_decision_reached().times(2).returning(|_| {
        Ok(DecisionReachedResponse {
            state_diff: ThinStateDiff::default(),
            central_objects: CentralObjects::default(),
        })
    });

    // required for decision reached flow
    deps.state_sync_client.expect_add_new_block().times(2).returning(|_| Ok(()));
    deps.cende_ambassador.expect_prepare_blob_for_next_height().times(2).returning(|_| Ok(()));

    let mut context = deps.build_context();

    // Validate block number 0.
    context.set_height_and_round(HEIGHT_0, ROUND_0).await.unwrap();

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context
        .validate_proposal(proposal_init(HEIGHT_0, ROUND_0), TIMEOUT, content_receiver)
        .await;

    let proposal_commitment = fin_receiver.await.unwrap();
    assert_eq!(proposal_commitment, *TEST_PROPOSAL_COMMITMENT);

    context.decision_reached(HEIGHT_0, ROUND_0, proposal_commitment, false).await.unwrap();

    let new_dynamic_config = ContextDynamicConfig {
        override_l2_gas_price_fri: Some(ODDLY_SPECIFIC_L2_GAS_PRICE),
        ..Default::default()
    };
    let config_manager_client = make_config_manager_client(new_dynamic_config);
    context.deps.config_manager_client = Some(Arc::new(config_manager_client));

    // Validate block number 1, round 0.
    context.set_height_and_round(HEIGHT_1, ROUND_0).await.unwrap();

    // This should fail, since the gas price is different from the input block info.
    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context
        .validate_proposal(proposal_init(HEIGHT_1, ROUND_0), TIMEOUT, content_receiver)
        .await;
    let proposal_commitment = fin_receiver.await.unwrap_err();
    assert!(matches!(proposal_commitment, Canceled));

    // Modify the incoming init to make sure it matches the overrides. Now it passes.
    let mut modified_init = proposal_init(HEIGHT_1, ROUND_0);
    modified_init.l2_gas_price_fri = GasPrice(ODDLY_SPECIFIC_L2_GAS_PRICE);

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context.validate_proposal(modified_init, TIMEOUT, content_receiver).await;
    let proposal_commitment = fin_receiver.await.unwrap();
    assert_eq!(proposal_commitment, *TEST_PROPOSAL_COMMITMENT);

    // Validate block number 1, round 1.
    let new_dynamic_config = ContextDynamicConfig {
        override_l1_data_gas_price_fri: Some(ODDLY_SPECIFIC_L1_DATA_GAS_PRICE),
        ..Default::default()
    };
    let config_manager_client = make_config_manager_client(new_dynamic_config);
    context.deps.config_manager_client = Some(Arc::new(config_manager_client));

    // This should fail, as we have changed the config, without updating the block info.
    context.set_height_and_round(HEIGHT_1, ROUND_1).await.unwrap();

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context
        .validate_proposal(proposal_init(HEIGHT_1, ROUND_1), TIMEOUT, content_receiver)
        .await;
    let proposal_commitment = fin_receiver.await.unwrap_err();
    assert!(matches!(proposal_commitment, Canceled));

    // Add the new overrides so validation passes. The override sets the FRI value; the
    // validator recomputes WEI via fri_to_wei(ETH_TO_FRI_RATE), so the proposed init must
    // mirror that conversion to stay within the WEI margin too.
    let mut modified_init = proposal_init(HEIGHT_1, ROUND_1);
    modified_init.l1_data_gas_price_fri = GasPrice(ODDLY_SPECIFIC_L1_DATA_GAS_PRICE);
    modified_init.l1_data_gas_price_wei =
        GasPrice(ODDLY_SPECIFIC_L1_DATA_GAS_PRICE).fri_to_wei(ETH_TO_FRI_RATE).unwrap();

    let content_receiver = send_proposal_to_validator_context(&mut context).await;
    let fin_receiver = context.validate_proposal(modified_init, TIMEOUT, content_receiver).await;
    let proposal_commitment = fin_receiver.await.unwrap();
    assert_eq!(proposal_commitment, *TEST_PROPOSAL_COMMITMENT);

    context.decision_reached(HEIGHT_1, ROUND_1, proposal_commitment, false).await.unwrap();

    // Now build a proposal for height 2.
    let new_dynamic_config = ContextDynamicConfig {
        override_eth_to_fri_rate: Some(ODDLY_SPECIFIC_CONVERSION_RATE),
        ..Default::default()
    };
    let config_manager_client = make_config_manager_client(new_dynamic_config);
    context.deps.config_manager_client = Some(Arc::new(config_manager_client));

    let fin_receiver = context
        .build_proposal(BuildParam { height: BlockNumber(2), ..Default::default() }, TIMEOUT)
        .await
        .unwrap()
        .await
        .unwrap();

    assert_eq!(fin_receiver, *TEST_PROPOSAL_COMMITMENT);
    let (_, mut receiver) = network.outbound_proposal_receiver.next().await.unwrap();

    let part = receiver.next().await.unwrap();
    let ProposalPart::Init(_) = part else {
        panic!("Expected ProposalPart::Init");
    };
}

fn make_config_manager_client(provider_config: ContextDynamicConfig) -> MockConfigManagerClient {
    let mut config_manager_client = MockConfigManagerClient::new();
    config_manager_client
        .expect_get_context_dynamic_config()
        .returning(move || Ok(provider_config.clone()));
    config_manager_client.expect_set_node_dynamic_config().returning(|_| Ok(()));
    config_manager_client
}

// Flow: dynamic config changes the min gas price per height while the node is running.
// Config updates do not immediately overwrite current gas price; they take effect on the
// next block gas-price calculation, which updates gradually.
#[tokio::test]
async fn test_dynamic_config_updates_min_gas_price() {
    // Test constants
    const INITIAL_CONFIG_HEIGHT: u64 = 100;
    const INITIAL_CONFIG_MIN_PRICE: u128 = 10_000_000_000;
    const NEW_CONFIG_HEIGHT: u64 = 200;
    const NEW_CONFIG_MIN_PRICE: u128 = 20_000_000_000;

    const INITIAL_HEIGHT: u64 = 150; // Node is already running at this height
    const TEST_HEIGHT: u64 = 250; // Move to this height with updated config
    const CURRENT_GAS_PRICE: u128 = 15_000_000_000; // Below new minimum

    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();

    // Create a mock config manager client that will return dynamic config
    let mut mock_config_manager = MockConfigManagerClient::new();

    // Mock expects get_context_dynamic_config to be called once (when moving to new height)
    // This is called inside set_height_and_round() -> update_dynamic_config() ->
    // client.get_context_dynamic_config()

    // Config returns updated min price at NEW_CONFIG_HEIGHT
    mock_config_manager.expect_get_context_dynamic_config().times(1).returning(move || {
        Ok(ContextDynamicConfig {
            min_l2_gas_price_per_height: vec![
                PricePerHeight { height: INITIAL_CONFIG_HEIGHT, price: INITIAL_CONFIG_MIN_PRICE },
                PricePerHeight { height: NEW_CONFIG_HEIGHT, price: NEW_CONFIG_MIN_PRICE },
            ],
            ..Default::default()
        })
    });

    // Setup batcher expectation for one height
    // set_height_and_round() calls batcher.start_height() to notify the batcher
    deps.batcher.expect_start_height().times(1).returning(|_| Ok(()));

    // Convert TestDeps to SequencerConsensusContextDeps and add config manager
    let mut context_deps: SequencerConsensusContextDeps = deps.into();
    context_deps.config_manager_client = Some(Arc::new(mock_config_manager));

    let mut context = SequencerConsensusContext::new(
        ContextConfig {
            static_config: ContextStaticConfig {
                proposal_buffer_size: CHANNEL_SIZE,
                chain_id: CHAIN_ID,
                ..Default::default()
            },
            dynamic_config: ContextDynamicConfig { ..Default::default() },
        },
        context_deps,
    );

    // Simulate node already running: set current_height to make context "already initialized"
    context.current_height = Some(BlockNumber(INITIAL_HEIGHT));
    context.l2_gas_price = GasPrice(INITIAL_CONFIG_MIN_PRICE);

    // Move to TEST_HEIGHT with updated config
    context.set_height_and_round(BlockNumber(TEST_HEIGHT), ROUND_0).await.unwrap();

    // Verify dynamic config was updated
    assert_eq!(context.config.dynamic_config.min_l2_gas_price_per_height.len(), 2);
    assert_eq!(
        context.config.dynamic_config.min_l2_gas_price_per_height[1].price,
        NEW_CONFIG_MIN_PRICE
    );

    // Set gas price below new minimum to simulate being below the updated config
    context.l2_gas_price = GasPrice(CURRENT_GAS_PRICE);

    // Simulate gas price update with new config in effect
    context.update_l2_gas_price(BlockNumber(TEST_HEIGHT), GasAmount(1000));

    // Gas price should have increased gradually towards new minimum
    // Formula: new_price = min(price + price/333, min_gas_price)
    // Starting at CURRENT_GAS_PRICE (15 Gwei)
    // max_increase = 15_000_000_000 / 333 = 45_045_045
    // expected = 15_000_000_000 + 45_045_045 = 15_045_045_045
    const MIN_GAS_PRICE_INCREASE_DENOMINATOR: u128 = 333;
    let expected_price =
        CURRENT_GAS_PRICE + (CURRENT_GAS_PRICE / MIN_GAS_PRICE_INCREASE_DENOMINATOR);
    let expected_price = expected_price.min(NEW_CONFIG_MIN_PRICE);

    let actual_price = context.l2_gas_price.0;
    assert_eq!(
        actual_price, expected_price,
        "Gas price should be exactly {} (15 Gwei + 15/333), got {}",
        expected_price, actual_price
    );
}

// Flow: node starts processing without syncing first (e.g., after revert or sync unavailable).
// Gas price begins at versioned-constants fallback, then bootstrap enforces the configured
// minimum for the current height.
#[tokio::test]
async fn test_first_height_uses_configured_min_l2_gas_price_for_height() {
    const CONFIG_HEIGHT_1: u64 = 100;
    const CONFIG_PRICE_1: u128 = 10_000_000_000;
    const CONFIG_HEIGHT_2: u64 = 200;
    const CONFIG_PRICE_2: u128 = 20_000_000_000;
    const STARTUP_HEIGHT: u64 = 250;
    const LOW_STARTUP_PRICE: u128 = 8_000_000_000;

    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();
    deps.batcher.expect_start_height().times(1).returning(|_| Ok(()));

    let mut context = deps.build_context();
    context.l2_gas_price = GasPrice(LOW_STARTUP_PRICE);
    context.config.dynamic_config.min_l2_gas_price_per_height = vec![
        PricePerHeight { height: CONFIG_HEIGHT_1, price: CONFIG_PRICE_1 },
        PricePerHeight { height: CONFIG_HEIGHT_2, price: CONFIG_PRICE_2 },
    ];

    // First set_height_and_round call on this new context instance.
    context.set_height_and_round(BlockNumber(STARTUP_HEIGHT), ROUND_0).await.unwrap();

    // Height 250 is after config height 200, so gas price should initialize to CONFIG_PRICE_2.
    assert_eq!(context.l2_gas_price, GasPrice(CONFIG_PRICE_2));
}

// Flow: sync provides next_l2_gas_price at height 200, but config defines a higher
// minimum starting at height 250. At height 200, the synced value is kept.
// Later at height 250, config minimum is applied gradually.
#[tokio::test]
async fn test_first_height_keeps_sync_provided_l2_gas_price() {
    const SYNC_HEIGHT: BlockNumber = BlockNumber(200);
    const LATER_HEIGHT: BlockNumber = BlockNumber(250);
    const SYNCED_NEXT_L2_GAS_PRICE: u128 = 20_000_000_000;
    const CONFIG_MIN_PRICE_AT_250: u128 = 25_000_000_000;

    let (mut deps, _network) = create_test_and_network_deps();
    // Specific get_block expectation must be registered before setup_default_expectations, which
    // installs a catch-all handler.
    deps.state_sync_client.expect_get_block().times(1).return_once(|height| {
        let mut sync_block = SyncBlock::default();
        sync_block.block_header_without_hash.block_number = height;
        sync_block.block_header_without_hash.next_l2_gas_price = GasPrice(SYNCED_NEXT_L2_GAS_PRICE);
        Ok(sync_block)
    });
    deps.setup_default_expectations();
    deps.batcher.expect_add_sync_block().times(1).return_once(|_, _| Ok(()));
    deps.batcher.expect_start_height().times(2).returning(|_| Ok(()));

    let mut context = deps.build_context();
    context.config.dynamic_config.min_l2_gas_price_per_height =
        vec![PricePerHeight { height: 250, price: CONFIG_MIN_PRICE_AT_250 }];

    // Sync succeeds at height 200, l2_gas_price is taken from synced next_l2_gas_price.
    assert!(context.try_sync(SYNC_HEIGHT).await);
    assert_eq!(context.l2_gas_price, GasPrice(SYNCED_NEXT_L2_GAS_PRICE));

    // First height initialization at 200: synced value is kept.
    context.set_height_and_round(SYNC_HEIGHT, ROUND_0).await.unwrap();
    assert_eq!(context.l2_gas_price, GasPrice(SYNCED_NEXT_L2_GAS_PRICE));

    // Move to height 250 where config min applies
    context.set_height_and_round(LATER_HEIGHT, ROUND_0).await.unwrap();
    // Bootstrap doesn't run (not first height anymore), price still 20g
    assert_eq!(context.l2_gas_price, GasPrice(SYNCED_NEXT_L2_GAS_PRICE));

    // Subsequent block should gradually increase toward CONFIG_MIN_PRICE_AT_250
    context.update_l2_gas_price(LATER_HEIGHT, GasAmount(1000));

    const MIN_GAS_PRICE_INCREASE_DENOMINATOR: u128 = 333;
    let expected_price =
        SYNCED_NEXT_L2_GAS_PRICE + (SYNCED_NEXT_L2_GAS_PRICE / MIN_GAS_PRICE_INCREASE_DENOMINATOR);
    assert_eq!(
        context.l2_gas_price.0, expected_price,
        "Gas price should be {} (20 Gwei + 20/333), got {}",
        expected_price, context.l2_gas_price.0
    );
}

// Distinct value per height so map equality verifies identity, not just key set.
fn window_of(heights: impl IntoIterator<Item = u64>) -> BTreeMap<BlockNumber, Option<GasPrice>> {
    heights.into_iter().map(|h| (BlockNumber(h), Some(GasPrice(u128::from(h))))).collect()
}

#[rstest]
// fee_proposal_window_size = 10, prune at 110: cutoff = 100, keep heights >= 100.
#[case::drops_entries_below_cutoff(window_of(90..=110), BlockNumber(110), window_of(100..=110))]
#[case::empty_when_all_entries_below_cutoff(window_of([50, 60, 70]), BlockNumber(200), window_of([]))]
// `current_height < fee_proposal_window_size`: cutoff would underflow; saturating_sub clamps
// to 0, so every entry is retained.
#[case::saturates_at_zero_when_height_below_window(window_of(0..=2), BlockNumber(5), window_of(0..=2))]
#[case::no_op_when_all_entries_within_window(window_of(105..=110), BlockNumber(110), window_of(105..=110))]
fn test_prune_fee_proposals_window(
    #[case] initial_window: BTreeMap<BlockNumber, Option<GasPrice>>,
    #[case] current_height: BlockNumber,
    #[case] expected_window: BTreeMap<BlockNumber, Option<GasPrice>>,
) {
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();
    let mut context = deps.build_context();
    context.fee_proposals_window = initial_window;
    context.prune_fee_proposals_window(current_height);
    assert_eq!(context.fee_proposals_window, expected_window);
}

// `initialize_fee_proposals_window` reads `[start_height - WINDOW, start_height)` from state_sync
// and records each block's `fee_proposal_fri`. `expected_window` is the mapping the test asserts;
// the mock answers `get_block(h)` from the same map. Genesis case (`start_height < WINDOW_SIZE`)
// is exercised by a smaller window: the bootstrap range collapses to `[0, start_height)`.
#[rstest]
#[case::all_some(BlockNumber(100), window_of(90..100))]
// v0.14.2 era: every block recorded with `fee_proposal_fri = None`.
#[case::all_none(BlockNumber(100), (90u64..100).map(|h| (BlockNumber(h), None)).collect())]
// Transition: heights < 95 are pre-V0_14_3 (None), heights >= 95 are V0_14_3+ (Some).
#[case::mixed_transition(
    BlockNumber(100),
    (90u64..100)
        .map(|h| (BlockNumber(h), (h >= 95).then(|| GasPrice(u128::from(h)))))
        .collect(),
)]
#[case::genesis_collapses_range(BlockNumber(3), window_of(0..3))]
#[tokio::test]
async fn test_initialize_fee_proposals_window(
    #[case] start_height: BlockNumber,
    #[case] expected_window: BTreeMap<BlockNumber, Option<GasPrice>>,
) {
    let mock_window = expected_window.clone();
    let (mut deps, _network) = create_test_and_network_deps();
    deps.state_sync_client.expect_get_block().times(expected_window.len()).returning(
        move |height| {
            let mut sync_block = SyncBlock::default();
            sync_block.block_header_without_hash.block_number = height;
            sync_block.block_header_without_hash.fee_proposal_fri =
                *mock_window.get(&height).unwrap();
            Ok(sync_block)
        },
    );
    deps.setup_default_expectations();

    let mut context = deps.build_context();
    context.initialize_fee_proposals_window(start_height).await.unwrap();
    assert_eq!(context.fee_proposals_window, expected_window);
}

#[derive(Clone)]
enum OracleBehavior {
    /// Provider returns `Ok(rate)` for the STRK/USD query.
    Ok(u128),
    /// Provider returns `Err(_)` for the STRK/USD query.
    Err,
}

// fee_actual = 10 gwei => margin bounds [9_980_039_920, 10_020_000_000].
#[rstest]
#[case::no_fee_actual_freezes_at_l2_gas_price(
    None,
    OracleBehavior::Ok(0),
    GasPrice(7_000_000_000),
    GasPrice(7_000_000_000)
)]
#[case::oracle_zero_rate_freezes_at_fee_actual(
    Some(GasPrice(10_000_000_000)),
    OracleBehavior::Ok(0),
    GasPrice(7_000_000_000),
    GasPrice(10_000_000_000)
)]
#[case::oracle_err_freezes_at_fee_actual(
    Some(GasPrice(10_000_000_000)),
    OracleBehavior::Err,
    GasPrice(7_000_000_000),
    GasPrice(10_000_000_000)
)]
#[case::oracle_target_in_bounds_returns_target(
    Some(GasPrice(10_000_000_000)),
    OracleBehavior::Ok(300_000_000_000_000_000),
    GasPrice(7_000_000_000),
    GasPrice(10_000_000_000)
)]
#[case::oracle_target_above_clamps_to_upper(
    Some(GasPrice(10_000_000_000)),
    OracleBehavior::Ok(1),
    GasPrice(7_000_000_000),
    GasPrice(10_020_000_000)
)]
#[case::oracle_target_below_clamps_to_lower(
    Some(GasPrice(10_000_000_000)),
    OracleBehavior::Ok(1_000_000_000_000_000_000_000),
    GasPrice(7_000_000_000),
    GasPrice(9_980_039_920)
)]
#[tokio::test]
async fn test_compute_proposer_fee_proposal(
    #[case] fee_actual: Option<GasPrice>,
    #[case] oracle_behavior: OracleBehavior,
    #[case] l2_gas_price: GasPrice,
    #[case] expected_fee_proposal: GasPrice,
) {
    let (mut deps, _network) = create_test_and_network_deps();
    // Register the specific strk_to_usd_rate expectation BEFORE setup_default_expectations so
    // the catch-all default installed there does not shadow it (mockall matches oldest first).
    match oracle_behavior {
        OracleBehavior::Ok(rate) => {
            deps.l1_gas_price_provider.expect_get_strk_to_usd_rate().returning(move |_| Ok(rate));
        }
        OracleBehavior::Err => {
            deps.l1_gas_price_provider.expect_get_strk_to_usd_rate().returning(|_| {
                Err(L1GasPriceClientError::ExchangeRateOracleClientError(
                    ExchangeRateOracleClientError::RequestError("test".to_string()),
                ))
            });
        }
    }
    deps.setup_default_expectations();

    let mut context = deps.build_context();
    context.l2_gas_price = l2_gas_price;
    let proposal = context
        .compute_proposer_fee_proposal(BlockNumber(0), fee_actual, 0, TARGET_ATTO_USD_PER_L2_GAS)
        .await;
    assert_eq!(proposal, expected_fee_proposal);
}

#[tokio::test]
async fn test_oracle_target_above_the_ceiling_caps_the_band_and_counts() {
    let recorder = PrometheusBuilder::new().build_recorder();
    let _recorder_guard = metrics::set_default_local_recorder(&recorder);
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM.register();

    let (mut deps, _network) = create_test_and_network_deps();
    // A rate of 1 atto-USD per STRK drives the oracle-derived target far above the ceiling.
    // Registered before `setup_default_expectations` so the catch-all default does not shadow it.
    deps.l1_gas_price_provider.expect_get_strk_to_usd_rate().returning(|_| Ok(1));
    deps.setup_default_expectations();
    let mut context = deps.build_context();
    context.config.dynamic_config.min_l2_gas_price_per_height =
        vec![PricePerHeight { height: 0, price: TEST_MIN_L2_GAS_PRICE.0 }];

    let proposal = context
        .compute_proposer_fee_proposal(
            BlockNumber(0),
            Some(TEST_MAX_L2_GAS_PRICE),
            0,
            TARGET_ATTO_USD_PER_L2_GAS,
        )
        .await;

    // The margin band's upper edge before capping is 80_160_000_000.
    assert_eq!(proposal, TEST_MAX_L2_GAS_PRICE);
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM.assert_eq(&recorder.handle().render(), 1);
}

#[tokio::test]
async fn test_operator_override_above_the_ceiling_is_not_oracle_drift() {
    // The pin is excluded from `snip35_fee_target_above_maximum`.
    let recorder = PrometheusBuilder::new().build_recorder();
    let _recorder_guard = metrics::set_default_local_recorder(&recorder);
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM.register();

    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();
    let mut context = deps.build_context();
    context.config.dynamic_config.min_l2_gas_price_per_height =
        vec![PricePerHeight { height: 0, price: TEST_MIN_L2_GAS_PRICE.0 }];
    context.config.dynamic_config.override_l2_gas_price_fri = Some(TEST_MAX_L2_GAS_PRICE.0 * 2);

    let proposal = context
        .compute_proposer_fee_proposal(
            BlockNumber(0),
            Some(TEST_MAX_L2_GAS_PRICE),
            0,
            TARGET_ATTO_USD_PER_L2_GAS,
        )
        .await;

    // The ceiling still caps the published proposal; only the attribution changes.
    assert_eq!(proposal, TEST_MAX_L2_GAS_PRICE);
    SNIP35_FEE_TARGET_ABOVE_MAXIMUM.assert_eq(&recorder.handle().render(), 0);
}

#[tokio::test]
async fn test_partial_window_freezes_at_an_uncapped_l2_gas_price() {
    // Pins the deliberate exclusion of the `fee_actual == None` path from the cap: the validator
    // skips the band check without `fee_actual`, so this is not coverage of the cap itself.
    let (mut deps, _network) = create_test_and_network_deps();
    deps.setup_default_expectations();
    let mut context = deps.build_context();
    let above_the_ceiling = GasPrice(TEST_MAX_L2_GAS_PRICE.0 * 2);
    context.l2_gas_price = above_the_ceiling;

    let proposal = context
        .compute_proposer_fee_proposal(BlockNumber(0), None, 0, TARGET_ATTO_USD_PER_L2_GAS)
        .await;

    assert_eq!(proposal, above_the_ceiling);
}

#[tokio::test]
async fn test_compute_proposer_fee_proposal_converges_to_oracle_target() {
    // (strk_usd_rate, fee_target, n_blocks_until_convergence_with_buffer).
    // 75 gwei bootstrap -> 100 gwei target at +33% reaches by block ~795.
    // 100 gwei -> 60 gwei at -40% reaches by block ~1410.
    let phases: [(u128, GasPrice, u64); 2] = [
        (30_000_000_000_000_000, GasPrice(100_000_000_000), 800),
        (50_000_000_000_000_000, GasPrice(60_000_000_000), 1420),
    ];

    let (mut deps, _network) = create_test_and_network_deps();
    // Register per-phase strk_to_usd_rate expectations BEFORE setup_default_expectations so they
    // are not shadowed by the catch-all default (mockall matches oldest first).
    let mut seq = mockall::Sequence::new();
    for &(rate, _, n_blocks) in &phases {
        deps.l1_gas_price_provider
            .expect_get_strk_to_usd_rate()
            .times(usize::try_from(n_blocks).unwrap())
            .in_sequence(&mut seq)
            .returning(move |_| Ok(rate));
    }
    deps.setup_default_expectations();
    let mut context = deps.build_context();
    // Mainnet's configured minimum puts the cap at 150 gwei; the 8 gwei fallback would cap below
    // this scenario's targets.
    context.config.dynamic_config.min_l2_gas_price_per_height =
        vec![PricePerHeight { height: 0, price: 15_000_000_000 }];

    // Bootstrap the window with 75 gwei (the $0.04 target).
    let window_size = VersionedConstants::latest_constants().fee_proposal_window_size;
    for h in 0..window_size {
        context.record_fee_proposal(BlockNumber(h), Some(GasPrice(75_000_000_000)));
    }

    let mut height = window_size;
    for (phase_idx, (_, fee_target, n_blocks)) in phases.into_iter().enumerate() {
        for _ in 0..n_blocks {
            let h = BlockNumber(height);
            let fee_actual = compute_fee_actual(&context.fee_proposals_window, h, window_size)
                .expect("window stays complete across the loop");
            let proposal = context
                .compute_proposer_fee_proposal(h, Some(fee_actual), 0, TARGET_ATTO_USD_PER_L2_GAS)
                .await;
            context.record_fee_proposal(h, Some(proposal));
            height += 1;
        }
        let final_fee_actual =
            compute_fee_actual(&context.fee_proposals_window, BlockNumber(height), window_size)
                .expect("window stays complete across the loop");
        assert_eq!(
            final_fee_actual, fee_target,
            "phase {phase_idx}: fee_actual did not reach fee_target after {n_blocks} blocks",
        );
    }
}

// When `fetch_accessed_keys_from_centralized` is enabled, `try_sync` fetches the block's accessed
// keys from the recorder and forwards them to the batcher's `add_sync_block`.
#[tokio::test]
async fn try_sync_forwards_accessed_keys_from_centralized() {
    const SYNC_HEIGHT: BlockNumber = BlockNumber(7);

    let (mut deps, _network) = create_test_and_network_deps();
    // Specific get_block expectation must be registered before setup_default_expectations, which
    // installs a catch-all handler.
    deps.state_sync_client.expect_get_block().times(1).return_once(|height| {
        let mut sync_block = SyncBlock::default();
        sync_block.block_header_without_hash.block_number = height;
        Ok(sync_block)
    });
    deps.setup_default_expectations();

    // The recorder returns the block's proof facts and execution infos; `try_sync` computes the
    // accessed keys from them (plus the synced block's state diff and the latest versioned
    // constants) and forwards them to `add_sync_block`. Empty data exercises the
    // fetch -> compute -> forward path.
    let block_data = BlockAccessedKeysData { proof_facts: vec![], execution_infos: vec![] };
    deps.cende_ambassador
        .expect_get_accessed_keys_input()
        .times(1)
        .withf(|block_number| *block_number == SYNC_HEIGHT)
        .return_once(move |_| Ok(Some(block_data)));
    deps.batcher
        .expect_add_sync_block()
        .times(1)
        .withf(|_sync_block, accessed_keys| accessed_keys.is_some())
        .return_once(|_, _| Ok(()));

    let mut context = deps.build_context_with_config(ContextConfig {
        static_config: ContextStaticConfig {
            chain_id: CHAIN_ID,
            fetch_accessed_keys_from_centralized: true,
            ..Default::default()
        },
        ..Default::default()
    });

    assert!(context.try_sync(SYNC_HEIGHT).await);
}

// When `fetch_accessed_keys_from_centralized` is enabled, the recorder may not yet have the
// synced block's accessed-keys data (e.g. it lags behind state sync, or is unavailable). This is
// data from a remote, network-reachable service, not a programmer invariant, so `try_sync` must
// fail the attempt gracefully (allowing the caller to retry) instead of panicking the node.
#[tokio::test]
async fn try_sync_fails_gracefully_when_recorder_has_no_accessed_keys() {
    const SYNC_HEIGHT: BlockNumber = BlockNumber(7);

    let (mut deps, _network) = create_test_and_network_deps();
    // Specific get_block expectation must be registered before setup_default_expectations, which
    // installs a catch-all handler.
    deps.state_sync_client.expect_get_block().times(1).return_once(|height| {
        let mut sync_block = SyncBlock::default();
        sync_block.block_header_without_hash.block_number = height;
        Ok(sync_block)
    });
    deps.setup_default_expectations();

    deps.cende_ambassador.expect_get_accessed_keys_input().times(1).return_once(|_| Ok(None));
    deps.batcher.expect_add_sync_block().times(0);

    let mut context = deps.build_context_with_config(ContextConfig {
        static_config: ContextStaticConfig {
            chain_id: CHAIN_ID,
            fetch_accessed_keys_from_centralized: true,
            ..Default::default()
        },
        ..Default::default()
    });

    assert!(!context.try_sync(SYNC_HEIGHT).await);
}

// With the opt-in disabled (the default), `try_sync` must not query the recorder and passes `None`
// accessed keys to the batcher.
#[tokio::test]
async fn try_sync_skips_accessed_keys_when_disabled() {
    const SYNC_HEIGHT: BlockNumber = BlockNumber(7);

    let (mut deps, _network) = create_test_and_network_deps();
    deps.state_sync_client.expect_get_block().times(1).return_once(|height| {
        let mut sync_block = SyncBlock::default();
        sync_block.block_header_without_hash.block_number = height;
        Ok(sync_block)
    });
    deps.setup_default_expectations();

    deps.cende_ambassador.expect_get_accessed_keys_input().times(0);
    deps.batcher
        .expect_add_sync_block()
        .times(1)
        .withf(|_sync_block, accessed_keys| accessed_keys.is_none())
        .return_once(|_, _| Ok(()));

    let mut context = deps.build_context();

    assert!(context.try_sync(SYNC_HEIGHT).await);
}
