#![cfg(any(test, feature = "testing"))]
mod utils;

use std::str::FromStr;

use alloy::consensus::Header as HeaderInner;
use alloy::primitives::{
    keccak256,
    BlockHash,
    Bytes,
    Log as LogInner,
    LogData,
    TxHash,
    B256,
    U256,
};
use alloy::providers::{Provider, ProviderBuilder};
use alloy::rpc::types::{Block, BlockTransactions, Header, Log};
use alloy::transports::mock::Asserter;
use apollo_l1_events::event_identifiers_to_track;
use assert_matches::assert_matches;
use papyrus_base_layer::ethereum_base_layer_contract::{
    EthereumBaseLayerConfig,
    EthereumBaseLayerContract,
    EthereumBaseLayerError,
};
use papyrus_base_layer::test_utils::{
    DEFAULT_ANVIL_L1_ACCOUNT_ADDRESS,
    DEFAULT_ANVIL_L1_DEPLOYED_ADDRESS,
};
use papyrus_base_layer::{BaseLayerContract, L1Event};
use utils::{L1_CONTRACT_ADDRESS, L2_ENTRY_POINT};

// This test requires that we do some manual work to produce the logs we expect to get from the
// Starknet L1 contract. The reason we don't just post events to L1 and have them scraped is that
// some of the log types don't correspond to actions we can just do to the base layer, like marking
// a tx as consumed on L2 (which requires a state update). We also don't know which additional logs
// may be added to the list of filtered logs, which is the point of this test (to protect against
// future additions). So we leave it to anyone that adds that new message from L1 to L2 to also make
// an example log and post it as part of the test, to make sure it is properly parsed all the way up
// to the provider.

const FAKE_HASH: &str = "0x1234567890123456789012345678901234567890123456789012345678901234";

#[tokio::test]
async fn all_event_types_must_be_filtered_and_parsed() {
    // Setup.
    // Make a mock L1
    let asserter = Asserter::new();
    let provider = ProviderBuilder::new().connect_mocked_client(asserter.clone());

    let mut base_layer = EthereumBaseLayerContract::new_with_provider(
        EthereumBaseLayerConfig::default(),
        provider.root().clone(),
    );

    // We can just return the same block all the time, it will only affect the timestamps.
    let dummy_block: Block<B256, Header> = dummy_block();

    // Put together the log that corresponds to each type of event in event_identifiers_to_track().
    // Then filter them one at a time. If any iteration doesn't return an event, it means we fail to
    // filter for it. If any iteration returns an error, we know something is wrong.
    // TODO(guyn): add the scraper and provider parsing.
    let mut block_number = 1;
    let filters = event_identifiers_to_track();

    let mut expected_logs = Vec::with_capacity(filters.len());

    // This log is for LOG_MESSAGE_TO_L2_EVENT_IDENTIFIER (must check that this is the first log in
    // filters)
    let expected_message_to_l2_log = encode_message_into_log(
        filters[0],
        block_number,
        &[U256::from(15), U256::from(202)],
        U256::from(127),
        Some(U256::from(420)),
    );
    block_number += 1;
    asserter.push_success(&vec![expected_message_to_l2_log.clone()]);
    expected_logs.push(expected_message_to_l2_log);
    asserter.push_success(&dummy_block);

    // This log is for MESSAGE_TO_L2_CANCELLATION_STARTED_EVENT_IDENTIFIER (must check that this is
    // the second log in filters)
    let expected_message_to_l2_cancellation_started_log = encode_message_into_log(
        filters[1],
        block_number,
        &[U256::from(1), U256::from(2)],
        U256::from(0),
        None,
    );
    block_number += 1;
    asserter.push_success(&vec![expected_message_to_l2_cancellation_started_log.clone()]);
    expected_logs.push(expected_message_to_l2_cancellation_started_log);
    asserter.push_success(&dummy_block);

    // This log is for MESSAGE_TO_L2_CANCELED_EVENT_IDENTIFIER (must check that this is the third
    // log in filters)
    let expected_message_to_l2_canceled_log = encode_message_into_log(
        filters[2],
        block_number,
        &[U256::from(1), U256::from(2)],
        U256::from(0),
        None,
    );
    block_number += 1;
    asserter.push_success(&vec![expected_message_to_l2_canceled_log.clone()]);
    expected_logs.push(expected_message_to_l2_canceled_log);
    asserter.push_success(&dummy_block);

    // This log is for CONSUMED_MESSAGE_TO_L2_EVENT_IDENTIFIER (must check that this is the fourth
    // log in filters)
    let expected_consumed_message_to_l2_log = encode_message_into_log(
        filters[3],
        block_number,
        &[U256::from(1), U256::from(2)],
        U256::from(0),
        Some(U256::from(1)),
    );
    block_number += 1;
    asserter.push_success(&vec![expected_consumed_message_to_l2_log.clone()]);
    expected_logs.push(expected_consumed_message_to_l2_log);
    asserter.push_success(&dummy_block);

    // If new log types are needed, they must be added here.

    // Check that each event type has a corresponding log.
    for filter in filters {
        // Only filter for one event at a time, to make sure we trigger on all events.
        let events = base_layer.events(0..=block_number, &[filter]).await.unwrap_or_else(|_| {
            panic!("should succeed in getting events for filter: {:?}", filter)
        });
        assert!(events.len() == 1, "Expected 1 event for filter: {:?}", filter);
    }
}

#[tokio::test]
async fn cannot_parse_log_message_to_l1() {
    // Setup.
    // Make a mock L1
    let asserter = Asserter::new();
    let provider = ProviderBuilder::new().connect_mocked_client(asserter.clone());

    let mut base_layer = EthereumBaseLayerContract::new_with_provider(
        EthereumBaseLayerConfig::default(),
        provider.root().clone(),
    );

    // We can just return the same block all the time, it will only affect the timestamps.
    let dummy_block: Block<B256, Header> = dummy_block();

    // This log is for LogMessageToL1 event.
    let expected_message_to_l1_log =
        encode_log_message_to_l1_log(&[U256::from(15), U256::from(202)]);
    asserter.push_success(&vec![expected_message_to_l1_log.clone()]);
    // asserter.push_success(&Vec::<Log>::new());
    asserter.push_success(&dummy_block);

    let result = base_layer.events(0..=1, event_identifiers_to_track()).await;

    assert!(result.is_err(), "expected error");
    assert_matches!(
        result,
        Err(EthereumBaseLayerError::TypeError(alloy::sol_types::Error::InvalidLog { .. }))
    );
}

// Logs that share a block resolve their timestamp with a single block-header fetch, not one per
// log. The mock is given exactly one block response for three same-block logs, so a per-log fetch
// would exhaust the queue and fail.
#[tokio::test]
async fn many_logs_in_one_block_fetch_the_block_header_once() {
    let asserter = Asserter::new();
    let provider = ProviderBuilder::new().connect_mocked_client(asserter.clone());
    let mut base_layer = EthereumBaseLayerContract::new_with_provider(
        EthereumBaseLayerConfig::default(),
        provider.root().clone(),
    );

    let filters = event_identifiers_to_track();
    let shared_block_number = 5;
    let logs: Vec<Log> = (0..3)
        .map(|nonce| {
            encode_message_into_log(
                filters[0],
                shared_block_number,
                &[U256::from(15), U256::from(202)],
                U256::from(nonce),
                Some(U256::from(420)),
            )
        })
        .collect();

    asserter.push_success(&logs);
    // Exactly one block response for the three same-block logs.
    asserter.push_success(&dummy_block::<B256>());

    let events = base_layer
        .events(0..=shared_block_number, &[filters[0]])
        .await
        .expect("one block fetch should satisfy all same-block logs");
    assert_eq!(events.len(), 3);
}

// When the log carries `blockTimestamp`, no block-header fetch is issued at all: no block response
// is queued, so any fetch would exhaust the queue and fail. The event carries the log's own
// timestamp.
#[tokio::test]
async fn log_block_timestamp_skips_the_block_header_fetch() {
    let asserter = Asserter::new();
    let provider = ProviderBuilder::new().connect_mocked_client(asserter.clone());
    let mut base_layer = EthereumBaseLayerContract::new_with_provider(
        EthereumBaseLayerConfig::default(),
        provider.root().clone(),
    );

    let filters = event_identifiers_to_track();
    let block_number = 7;
    let expected_timestamp = 987654321;
    let mut log = encode_message_into_log(
        filters[0],
        block_number,
        &[U256::from(15), U256::from(202)],
        U256::from(127),
        Some(U256::from(420)),
    );
    log.block_timestamp = Some(expected_timestamp);

    asserter.push_success(&vec![log]);
    // Deliberately no block response queued.

    let events = base_layer
        .events(0..=block_number, &[filters[0]])
        .await
        .expect("timestamp on the log should avoid any block fetch");
    assert_matches!(
        &events[0],
        L1Event::LogMessageToL2 { block_timestamp, .. } if block_timestamp.0 == expected_timestamp
    );
}

fn dummy_block<T>() -> Block<T, Header> {
    Block {
        header: Header {
            hash: BlockHash::from_str(FAKE_HASH).unwrap(),
            inner: HeaderInner { number: 3, base_fee_per_gas: Some(5), ..Default::default() },
            total_difficulty: None,
            size: None,
        },
        transactions: BlockTransactions::<T>::default(),
        uncles: vec![],
        withdrawals: None,
    }
}

// Each function signature is hashed using keccak256 to get the selector.
// For example, LogMessageToL2(address,uint256,uint256,uint256[],uint256,uint256)
// becomes "db80dd488acf86d17c747445b0eabb5d57c541d3bd7b6b87af987858e5066b2b".
fn filter_to_hash(filter: &str) -> String {
    format!("{:x}", keccak256(filter.as_bytes()))
}

/// Encodes the non-indexed parameters of LogMessageToL2 event data.
/// Parameters: (payload: uint256[], nonce: uint256, fee: uint256)
///
/// ABI encoding for tuple (uint256[], uint256, uint256):
/// - Offset to array (32 bytes)
/// - nonce value (32 bytes)
/// - fee value (32 bytes)
/// - Array length (32 bytes)
/// - Array elements (32 bytes each)
fn encode_log_message_to_l2_data(payload: &[U256], nonce: U256, fee: U256) -> Bytes {
    // Instead of the payload array data, we only put in the head section the offset to where the
    // data will be stored. This would be 3 words from the start of the head (offset, nonce, fee =
    // 96 bytes = 0x60).
    let offset = U256::from(96u64);

    let mut encoded = Vec::new();
    // Offset to the array data (96 bytes).
    encoded.extend_from_slice(&offset.to_be_bytes::<32>());
    // nonce.
    encoded.extend_from_slice(&nonce.to_be_bytes::<32>());
    // fee.
    encoded.extend_from_slice(&fee.to_be_bytes::<32>());
    // Tail section has the payload array data only. It starts with the length of the array.
    let array_len = U256::from(payload.len());
    encoded.extend_from_slice(&array_len.to_be_bytes::<32>());
    // Finally, write the array elements.
    for item in payload {
        encoded.extend_from_slice(&item.to_be_bytes::<32>());
    }

    Bytes::from(encoded)
}

// Same as above, but for the other event types (that don't include a fee).
fn encode_other_event_data(payload: &[U256], nonce: U256) -> Bytes {
    // Instead of the payload array data, we only put in the head section the offset to where the
    // data will be stored. This would be 2 words from the start of the head (offset, nonce = 64
    // bytes = 0x40).
    let offset = U256::from(64u64);

    let mut encoded = Vec::new();
    // Offset to the array data (96 bytes).
    encoded.extend_from_slice(&offset.to_be_bytes::<32>());
    // nonce.
    encoded.extend_from_slice(&nonce.to_be_bytes::<32>());
    // Tail section has the payload array data only. It starts with the length of the array.
    let array_len = U256::from(payload.len());
    encoded.extend_from_slice(&array_len.to_be_bytes::<32>());
    // Finally, write the array elements.
    for item in payload {
        encoded.extend_from_slice(&item.to_be_bytes::<32>());
    }

    Bytes::from(encoded)
}

fn encode_message_into_log(
    selector: &str,
    block_number: u64,
    payload: &[U256],
    nonce: U256,
    fee: Option<U256>,
) -> Log {
    // Add zero padding to the address to make it 32 bytes
    let starknet_address = DEFAULT_ANVIL_L1_ACCOUNT_ADDRESS.to_bigint().to_str_radix(16);
    let starknet_address = format!("{:0>64}", starknet_address);

    let encoded_data = match fee {
        Some(fee) => encode_log_message_to_l2_data(payload, nonce, fee),
        None => encode_other_event_data(payload, nonce),
    };
    Log {
        inner: LogInner {
            address: DEFAULT_ANVIL_L1_DEPLOYED_ADDRESS.parse().unwrap(),
            data: LogData::new_unchecked(
                vec![
                    filter_to_hash(selector).parse().unwrap(),
                    starknet_address.parse().unwrap(),
                    U256::from(L1_CONTRACT_ADDRESS).into(),
                    U256::from(L2_ENTRY_POINT).into(),
                ],
                encoded_data,
            ),
        },
        block_hash: Some(BlockHash::from_str(FAKE_HASH).unwrap()),
        block_number: Some(block_number),
        block_timestamp: None,
        transaction_hash: Some(TxHash::from_str(FAKE_HASH).unwrap()),
        transaction_index: Some(block_number + 1),
        log_index: Some(block_number + 2),
        removed: false,
    }
}

// Generate a LogMessageToL1 log (which we do not filter on).
fn encode_log_message_to_l1_log(payload: &[U256]) -> Log {
    let selector = "LogMessageToL1(address,uint256[],uint256,uint256)";
    let block_number = 1;
    let starknet_address = DEFAULT_ANVIL_L1_ACCOUNT_ADDRESS.to_bigint().to_str_radix(16);
    let starknet_address = format!("{:0>64}", starknet_address);

    let offset = U256::from(32u64);

    let mut encoded = Vec::new();
    // Offset to the array data (96 bytes).
    encoded.extend_from_slice(&offset.to_be_bytes::<32>());

    // Tail section has the payload array data only. It starts with the length of the array.
    let array_len = U256::from(payload.len());
    encoded.extend_from_slice(&array_len.to_be_bytes::<32>());
    // Finally, write the array elements.
    for item in payload {
        encoded.extend_from_slice(&item.to_be_bytes::<32>());
    }

    let log_data = Bytes::from(encoded);

    Log {
        inner: LogInner {
            address: DEFAULT_ANVIL_L1_DEPLOYED_ADDRESS.parse().unwrap(),
            data: LogData::new_unchecked(
                vec![
                    filter_to_hash(selector).parse().unwrap(),
                    starknet_address.parse().unwrap(),
                    U256::from(L1_CONTRACT_ADDRESS).into(),
                ],
                log_data,
            ),
        },
        block_hash: Some(BlockHash::from_str(FAKE_HASH).unwrap()),
        block_number: Some(block_number),
        block_timestamp: None,
        transaction_hash: Some(TxHash::from_str(FAKE_HASH).unwrap()),
        transaction_index: Some(block_number + 1),
        log_index: Some(block_number + 2),
        removed: false,
    }
}
