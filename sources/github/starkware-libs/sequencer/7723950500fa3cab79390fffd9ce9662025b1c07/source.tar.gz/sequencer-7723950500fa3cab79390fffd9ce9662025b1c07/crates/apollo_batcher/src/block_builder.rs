use std::cmp::min;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::time::Duration;

use apollo_batcher_config::config::BlockBuilderConfig;
use apollo_batcher_types::batcher_types::ProposalCommitment;
use apollo_class_manager_types::SharedClassManagerClient;
use apollo_infra_utils::tracing::LogCompatibleToStringExt;
use apollo_proof_manager_types::SharedProofManagerClient;
use apollo_state_reader::apollo_state::{ApolloReader, ClassReader};
use apollo_storage::StorageReader;
use apollo_transaction_converter::{
    TransactionConverter,
    TransactionConverterError,
    TransactionConverterResult,
    TransactionConverterTrait,
};
use async_trait::async_trait;
use blockifier::blockifier::concurrent_transaction_executor::ConcurrentTransactionExecutor;
use blockifier::blockifier::config::NativeClassesWhitelist;
use blockifier::blockifier::transaction_executor::{
    BlockExecutionSummary,
    CompiledClassHashesForMigration,
    TransactionExecutionOutput,
    TransactionExecutorError as BlockifierTransactionExecutorError,
    TransactionExecutorResult,
};
use blockifier::blockifier_versioned_constants::VersionedConstants;
use blockifier::bouncer::{BouncerWeights, CasmHashComputationData};
use blockifier::concurrency::worker_pool::WorkerPool;
use blockifier::context::BlockContext;
use blockifier::state::cached_state::{CachedState, CommitmentStateDiff, StateMaps};
use blockifier::state::contract_class_manager::ContractClassManager;
use blockifier::state::errors::StateError;
use blockifier::state::state_reader_and_contract_manager::StateReaderAndContractManager;
use blockifier::transaction::objects::TransactionExecutionInfo;
use blockifier::transaction::transaction_execution::Transaction as BlockifierTransaction;
use indexmap::{IndexMap, IndexSet};
#[cfg(test)]
use mockall::automock;
use starknet_api::block::{BlockHashAndNumber, BlockInfo, BlockNumber};
use starknet_api::block_hash::block_hash_calculator::{
    calculate_block_commitments,
    BlockCommitmentsMeasurements,
    PartialBlockHash,
    PartialBlockHashComponents,
    TransactionHashingData,
};
use starknet_api::consensus_transaction::InternalConsensusTransaction;
use starknet_api::core::{ContractAddress, Nonce};
use starknet_api::data_availability::L1DataAvailabilityMode;
use starknet_api::execution_resources::GasAmount;
use starknet_api::rpc_transaction::InternalRpcTransactionWithoutTxHash;
use starknet_api::state::ThinStateDiff;
use starknet_api::transaction::fields::{snos_block_number_from_proof_facts, TransactionSignature};
use starknet_api::transaction::{TransactionHash, TransactionOffsetInBlock};
use thiserror::Error;
use tokio::sync::mpsc::error::TrySendError;
use tokio::sync::{Mutex, MutexGuard};
use tokio::task::spawn_blocking;
use tracing::{debug, error, info, trace, warn};

use crate::block_builder::FailOnErrorCause::L1HandlerTransactionValidationFailed;
use crate::cende_client_types::{StarknetClientStateDiff, StarknetClientTransactionReceipt};
use crate::metrics::{
    record_block_close_reason,
    BlockCloseReason,
    BATCHER_CLASS_CACHE_METRICS,
    BLOCK_COMMITMENT_MEASUREMENTS_COUNT,
    EVENT_COMMITMENT_COUNT,
    EVENT_COMMITMENT_LATENCY,
    PROPOSER_DEFERRED_TXS,
    RECEIPT_COMMITMENT_LATENCY,
    STATE_DIFF_COMMITMENT_LATENCY,
    STATE_DIFF_LENGTH,
    TX_COMMITMENT_COUNT,
    TX_COMMITMENT_LATENCY,
    VALIDATOR_WASTED_TXS,
};
use crate::pre_confirmed_block_writer::PreconfirmedTxSender;
use crate::transaction_executor::TransactionExecutorTrait;
use crate::transaction_provider::{TransactionProvider, TransactionProviderError};

#[derive(Debug, Error)]
pub enum BlockBuilderError {
    #[error(transparent)]
    BlockifierStateError(#[from] StateError),
    #[error(transparent)]
    ExecutorError(#[from] BlockifierTransactionExecutorError),
    #[error(transparent)]
    GetTransactionError(#[from] TransactionProviderError),
    #[error(transparent)]
    StreamTransactionsError(
        #[from] Box<tokio::sync::mpsc::error::SendError<InternalConsensusTransaction>>,
    ),
    #[error(transparent)]
    FailOnError(FailOnErrorCause),
    #[error("The block builder was aborted.")]
    Aborted,
    #[error(transparent)]
    TransactionConverterError(#[from] TransactionConverterError),
}

pub type BlockBuilderResult<T> = Result<T, BlockBuilderError>;

#[derive(Debug, Error)]
pub enum FailOnErrorCause {
    #[error("Block is full")]
    BlockFull,
    #[error("Deadline has been reached")]
    DeadlineReached,
    #[error("Transaction failed: {0}")]
    TransactionFailed(BlockifierTransactionExecutorError),
    #[error("L1 Handler transaction validation failed: {0}")]
    L1HandlerTransactionValidationFailed(TransactionProviderError),
    #[error("Duplicate transaction hash in proposal: {0}")]
    DuplicateTransaction(TransactionHash),
}

enum AddTxsToExecutorResult {
    NoNewTxs,
    NewTxs,
}

#[cfg_attr(test, derive(Clone))]
#[derive(Debug, PartialEq)]
pub struct BlockExecutionArtifacts {
    // Note: The execution_infos must be ordered to match the order of the transactions in the
    // block.
    pub execution_data: BlockTransactionExecutionData,
    pub commitment_state_diff: CommitmentStateDiff,
    pub compressed_state_diff: Option<CommitmentStateDiff>,
    pub initial_reads: StateMaps,
    pub bouncer_weights: BouncerWeights,
    pub l2_gas_used: GasAmount,
    pub casm_hash_computation_data_sierra_gas: CasmHashComputationData,
    pub casm_hash_computation_data_proving_gas: CasmHashComputationData,
    pub compiled_class_hashes_for_migration: CompiledClassHashesForMigration,
    // The number of transactions executed by the proposer out of the transactions that were sent.
    // This value includes rejected transactions.
    pub final_n_executed_txs: usize,
    partial_block_hash_components: PartialBlockHashComponents,
}

impl BlockExecutionArtifacts {
    pub async fn new(
        block_summary: BlockExecutionSummary,
        execution_data: BlockTransactionExecutionData,
        final_n_executed_txs: usize,
    ) -> Self {
        let BlockExecutionSummary {
            state_diff: commitment_state_diff,
            compressed_state_diff,
            initial_reads,
            bouncer_weights,
            casm_hash_computation_data_sierra_gas,
            casm_hash_computation_data_proving_gas,
            compiled_class_hashes_for_migration,
            block_info,
        } = block_summary;
        let l1_da_mode = L1DataAvailabilityMode::from_use_kzg_da(block_info.use_kzg_da);
        let transactions_data =
            prepare_txs_hashing_data(&execution_data.execution_infos_and_signatures);
        // TODO(Ayelet): Remove the clones.
        let (header_commitments, measurements) = calculate_block_commitments(
            &transactions_data,
            ThinStateDiff::from(commitment_state_diff.clone()),
            l1_da_mode,
            &block_info.starknet_version,
        )
        .await;
        record_and_log_block_commitment_measurements(block_info.block_number, measurements);
        let partial_block_hash_components =
            PartialBlockHashComponents::new(&block_info, header_commitments);
        let l2_gas_used = execution_data.l2_gas_used();
        Self {
            execution_data,
            commitment_state_diff,
            compressed_state_diff,
            initial_reads,
            bouncer_weights,
            l2_gas_used,
            casm_hash_computation_data_sierra_gas,
            casm_hash_computation_data_proving_gas,
            compiled_class_hashes_for_migration,
            final_n_executed_txs,
            partial_block_hash_components,
        }
    }

    pub fn address_to_nonce(&self) -> HashMap<ContractAddress, Nonce> {
        HashMap::from_iter(
            self.commitment_state_diff
                .address_to_nonce
                .iter()
                .map(|(address, nonce)| (*address, *nonce)),
        )
    }

    pub fn tx_hashes(&self) -> HashSet<TransactionHash> {
        HashSet::from_iter(self.execution_data.execution_infos_and_signatures.keys().copied())
    }

    pub fn thin_state_diff(&self) -> ThinStateDiff {
        // TODO(Ayelet): Remove the clones.
        ThinStateDiff::from(self.commitment_state_diff.clone())
    }

    pub fn commitment(&self) -> ProposalCommitment {
        ProposalCommitment {
            partial_block_hash: PartialBlockHash::from_partial_block_hash_components(
                &self.partial_block_hash_components,
            )
            .expect("Unable to calculate the proposal commitment"),
        }
    }

    /// Returns the [PartialBlockHashComponents] based on the execution artifacts.
    pub fn partial_block_hash_components(&self) -> PartialBlockHashComponents {
        self.partial_block_hash_components.clone()
    }
}

fn prepare_txs_hashing_data(
    transactions: &IndexMap<
        TransactionHash,
        (TransactionExecutionInfo, Option<TransactionSignature>),
    >,
) -> Vec<TransactionHashingData> {
    transactions
        .iter()
        .map(|(hash, (info, optional_signature))| TransactionHashingData {
            transaction_hash: *hash,
            transaction_output: info.output_for_hashing(),
            transaction_signature: optional_signature.clone().unwrap_or_default(),
        })
        .collect()
}

/// The BlockBuilderTrait is responsible for building a new block from transactions provided by the
/// tx_provider. The block building will stop at time deadline.
/// The transactions that were added to the block will be streamed to the output_content_sender.
#[cfg_attr(test, automock)]
#[async_trait]
pub trait BlockBuilderTrait: Send {
    async fn build_block(&mut self) -> BlockBuilderResult<BlockExecutionArtifacts>;
}

pub struct BlockBuilderExecutionParams {
    pub deadline: tokio::time::Instant,
    pub is_validator: bool,
    pub proposer_idle_detection_delay: Duration,
    pub n_concurrent_txs: usize,
    pub tx_polling_interval_millis: u64,
    pub results_polling_interval_millis: u64,
}

pub struct BlockBuilder {
    // TODO(Yael 14/10/2024): make the executor thread safe and delete this mutex.
    executor: Arc<Mutex<dyn TransactionExecutorTrait>>,
    tx_provider: Box<dyn TransactionProvider>,
    output_content_sender: Option<tokio::sync::mpsc::UnboundedSender<InternalConsensusTransaction>>,
    /// The sender is utilized only during block proposal and not during block validation.
    pre_confirmed_tx_sender: Option<PreconfirmedTxSender>,
    abort_signal_receiver: tokio::sync::oneshot::Receiver<()>,
    transaction_converter: TransactionConverter,
    /// The number of transactions whose execution is completed.
    n_executed_txs: usize,
    /// The transactions whose execution started.
    block_txs: Vec<InternalConsensusTransaction>,
    execution_data: BlockTransactionExecutionData,

    execution_params: BlockBuilderExecutionParams,

    /// Timestamp when block building started.
    block_building_start: tokio::time::Instant,
}

impl BlockBuilder {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        executor: impl TransactionExecutorTrait + 'static,
        tx_provider: Box<dyn TransactionProvider>,
        output_content_sender: Option<
            tokio::sync::mpsc::UnboundedSender<InternalConsensusTransaction>,
        >,
        pre_confirmed_tx_sender: Option<PreconfirmedTxSender>,
        abort_signal_receiver: tokio::sync::oneshot::Receiver<()>,
        transaction_converter: TransactionConverter,
        execution_params: BlockBuilderExecutionParams,
    ) -> Self {
        let executor = Arc::new(Mutex::new(executor));
        Self {
            executor,
            tx_provider,
            output_content_sender,
            pre_confirmed_tx_sender,
            abort_signal_receiver,
            transaction_converter,
            n_executed_txs: 0,
            block_txs: Vec::new(),
            execution_data: BlockTransactionExecutionData::default(),
            execution_params,
            block_building_start: tokio::time::Instant::now(),
        }
    }
}

#[async_trait]
impl BlockBuilderTrait for BlockBuilder {
    async fn build_block(&mut self) -> BlockBuilderResult<BlockExecutionArtifacts> {
        let res = self.build_block_inner().await;
        if res.is_err() {
            let executor = self.executor.clone();
            spawn_blocking(move || {
                let mut locked_executor = executor.blocking_lock();
                locked_executor.abort_block();
            })
            .await
            .expect("Aborting block should succeed.");
        }
        res
    }
}

impl BlockBuilder {
    async fn build_block_inner(&mut self) -> BlockBuilderResult<BlockExecutionArtifacts> {
        let mut final_n_executed_txs: Option<usize> = None;
        // Poll the mempool at most every `tx_polling_interval`, independently of the faster
        // results-collection wake-ups (see `sleep`).
        let tx_polling_interval =
            Duration::from_millis(self.execution_params.tx_polling_interval_millis);
        let mut next_mempool_poll_at = tokio::time::Instant::now();
        while !self.finished_block_txs(final_n_executed_txs) {
            if tokio::time::Instant::now() >= self.execution_params.deadline {
                info!("Block builder deadline reached.");
                if self.execution_params.is_validator {
                    return Err(BlockBuilderError::FailOnError(FailOnErrorCause::DeadlineReached));
                }
                record_block_close_reason(BlockCloseReason::Deadline);
                break;
            }

            if self.should_finish_due_to_timeout_while_propose() {
                let now = tokio::time::Instant::now();
                let time_since_start = now.duration_since(self.block_building_start);
                info!(
                    "No transactions are being executed and {:?} passed since block building \
                     started (timeout is set to {:?}), finishing block building.",
                    time_since_start, self.execution_params.proposer_idle_detection_delay,
                );
                record_block_close_reason(BlockCloseReason::IdleExecutionTimeout);
                break;
            }
            if final_n_executed_txs.is_none() {
                if let Some(res) = self.tx_provider.get_final_n_executed_txs().await {
                    info!("Received final number of transactions in block proposal: {res}.");
                    final_n_executed_txs = Some(res);
                }
            }
            if self.abort_signal_receiver.try_recv().is_ok() {
                info!("Received abort signal. Aborting block builder.");
                return Err(BlockBuilderError::Aborted);
            }

            self.handle_executed_txs().await?;

            // Check if the block is full. This is only relevant in propose mode.
            // In validate mode, this is ignored and we simply wait for the proposer to send the
            // final number of transactions in the block.
            let executor = self.executor.clone();
            if !self.execution_params.is_validator
                && spawn_blocking(move || lock_executor(&executor).is_done())
                    .await
                    .expect("Checking completion should succeed.")
            {
                // Call `handle_executed_txs()` once more to get the last results.
                self.handle_executed_txs().await?;
                info!("Block is full.");
                record_block_close_reason(BlockCloseReason::FullBlock);
                break;
            }

            let now = tokio::time::Instant::now();
            if now >= next_mempool_poll_at {
                match self.add_txs_to_executor().await? {
                    // Keep draining while txs are flowing: re-poll next iteration without sleeping.
                    AddTxsToExecutorResult::NewTxs => continue,
                    AddTxsToExecutorResult::NoNewTxs => {
                        next_mempool_poll_at = now + tx_polling_interval;
                    }
                }
            }
            self.sleep(now, next_mempool_poll_at).await;
        }

        // The final number of transactions to consider for the block.
        // Proposer: this is the number of transactions that were executed.
        // Validator: the number of transactions we got from the proposer.
        let final_n_executed_txs_nonopt = if self.execution_params.is_validator {
            final_n_executed_txs.expect("final_n_executed_txs must be set in validate mode.")
        } else {
            assert!(
                final_n_executed_txs.is_none(),
                "final_n_executed_txs must be None in propose mode."
            );
            self.n_executed_txs
        };

        if self.execution_params.is_validator {
            // Validator wasted txs: executed locally but not included in final block.
            let wasted = self.n_executed_txs.saturating_sub(final_n_executed_txs_nonopt);
            VALIDATOR_WASTED_TXS.set_lossy(wasted);
        } else {
            // Proposer deferred txs: started but not executed by end of proposal.
            let not_executed = self.block_txs.len().saturating_sub(self.n_executed_txs);
            PROPOSER_DEFERRED_TXS.set_lossy(not_executed);
        }
        info!(
            "Finished building block as {}. Started executing {} transactions. Finished executing \
             {} transactions. Final number of transactions (as set by the proposer): {}.",
            if self.execution_params.is_validator { "validator" } else { "proposer" },
            self.block_txs.len(),
            self.n_executed_txs,
            final_n_executed_txs_nonopt,
        );
        // Sanity check to avoid panic and skip logging if numbers aren't aligned. Empty blocks are
        // skipped too: on Mainnet most blocks carry no transactions, and this line would report
        // three empty lists for each of them.
        if !self.block_txs.is_empty()
            && final_n_executed_txs_nonopt <= self.n_executed_txs
            && self.n_executed_txs <= self.block_txs.len()
        {
            debug!(
                "Finished building block as {}. Transaction hashes: included in block: {:?}, \
                 proposer excluded but we executed: {:?}, not finished executing: {:?}",
                if self.execution_params.is_validator { "validator" } else { "proposer" },
                self.block_txs[0..final_n_executed_txs_nonopt]
                    .iter()
                    .map(|tx| tx.tx_hash())
                    .collect::<Vec<_>>(),
                self.block_txs[final_n_executed_txs_nonopt..self.n_executed_txs]
                    .iter()
                    .map(|tx| tx.tx_hash())
                    .collect::<Vec<_>>(),
                self.block_txs[self.n_executed_txs..]
                    .iter()
                    .map(|tx| tx.tx_hash())
                    .collect::<Vec<_>>(),
            );
        }

        // Move a clone of the executor into the lambda function.
        let executor = self.executor.clone();
        let block_summary = spawn_blocking(move || {
            lock_executor(&executor).close_block(final_n_executed_txs_nonopt)
        })
        .await
        .expect("Failed to spawn blocking executor task.")?;

        let mut execution_data = std::mem::take(&mut self.execution_data);
        if let Some(final_n_executed_txs) = final_n_executed_txs {
            // Remove the transactions that were executed, but eventually not included in the block.
            // This can happen if the proposer sends some transactions but closes the block before
            // including them, while the validator already executed those transactions.
            let remove_tx_hashes: Vec<TransactionHash> =
                self.block_txs[final_n_executed_txs..].iter().map(|tx| tx.tx_hash()).collect();
            execution_data.remove_last_txs(&remove_tx_hashes);
        }
        Ok(BlockExecutionArtifacts::new(block_summary, execution_data, final_n_executed_txs_nonopt)
            .await)
    }

    /// Returns the number of transactions that are currently being executed by the executor.
    fn n_txs_in_progress(&self) -> usize {
        self.block_txs.len() - self.n_executed_txs
    }

    /// Returns `true` if all the txs in the block were executed. This function always returns
    /// `false` in propose mode.
    fn finished_block_txs(&self, final_n_executed_txs: Option<usize>) -> bool {
        if let Some(final_n_executed_txs) = final_n_executed_txs {
            self.n_executed_txs >= final_n_executed_txs
        } else {
            // final_n_executed_txs is not known yet, so the block is not finished.
            false
        }
    }

    /// Adds new transactions (if there are any) from `tx_provider` to the executor.
    ///
    /// Returns whether new transactions were added and whether the transaction stream is exhausted
    /// (this can only happen in validator mode).
    async fn add_txs_to_executor(&mut self) -> BlockBuilderResult<AddTxsToExecutorResult> {
        // Restrict the number of transactions to fetch such that the number of transactions in
        // progress is at most `n_concurrent_txs`.
        let n_concurrent_txs = self.execution_params.n_concurrent_txs;
        let n_txs_to_fetch = n_concurrent_txs - min(self.n_txs_in_progress(), n_concurrent_txs);

        if n_txs_to_fetch == 0 {
            return Ok(AddTxsToExecutorResult::NoNewTxs);
        }

        let next_txs = match self.tx_provider.get_txs(n_txs_to_fetch).await {
            Err(e @ TransactionProviderError::L1HandlerTransactionValidationFailed { .. })
                if self.execution_params.is_validator =>
            {
                warn!("Failed to validate L1 Handler transaction: {:?}", e);
                return Err(BlockBuilderError::FailOnError(L1HandlerTransactionValidationFailed(
                    e,
                )));
            }
            Err(err) => {
                error!("Failed to get transactions from the transaction provider: {:?}", err);
                return Err(err.into());
            }
            Ok(result) => result,
        };

        if next_txs.is_empty() {
            return Ok(AddTxsToExecutorResult::NoNewTxs);
        }

        let n_txs = next_txs.len();
        let block_txs_start = self.block_txs.len();
        debug!(
            "Got {} transactions from the transaction provider (aggregated: {}).",
            n_txs,
            block_txs_start + n_txs
        );

        self.block_txs.extend(next_txs);

        let tx_convert_futures = self.block_txs[block_txs_start..]
            .iter()
            .map(|tx| convert_to_executable_blockifier_tx(&self.transaction_converter, tx.clone()));
        let executor_input_chunk = futures::future::try_join_all(tx_convert_futures).await?;

        // Start the execution of the transactions on the worker pool.
        trace!("Starting execution of {} transactions.", n_txs);
        let executor = self.executor.clone();
        spawn_blocking(move || {
            lock_executor(&executor).add_txs_to_block(executor_input_chunk.as_slice())
        })
        .await
        .expect("Adding txs to block should succeed.");

        if let Some(output_content_sender) = &self.output_content_sender {
            // Send the transactions to the validators.
            // Only reached in proposal flow.
            for tx in &self.block_txs[block_txs_start..] {
                output_content_sender.send(tx.clone()).map_err(Box::new)?;
            }
        }

        Ok(AddTxsToExecutorResult::NewTxs)
    }

    /// Handles the transactions that were executed so far by the executor.
    async fn handle_executed_txs(&mut self) -> BlockBuilderResult<()> {
        let executor = self.executor.clone();
        let results = spawn_blocking(move || lock_executor(&executor).get_new_results())
            .await
            .expect("Getting new results should succeed.");

        if results.is_empty() {
            return Ok(());
        }

        let old_n_executed_txs = self.n_executed_txs;
        self.n_executed_txs += results.len();

        info!(
            "Finished execution of {} transactions (aggregated: {}).",
            results.len(),
            self.n_executed_txs
        );

        collect_execution_results_and_stream_txs(
            &self.block_txs[old_n_executed_txs..self.n_executed_txs],
            results,
            &mut self.execution_data,
            &mut self.pre_confirmed_tx_sender,
        )
        .await
    }

    fn should_finish_due_to_timeout_while_propose(&self) -> bool {
        if self.execution_params.is_validator {
            return false;
        };
        if self.n_txs_in_progress() > 0 {
            return false;
        };
        let now = tokio::time::Instant::now();
        let time_since_start = now.duration_since(self.block_building_start);
        time_since_start >= self.execution_params.proposer_idle_detection_delay
    }

    async fn sleep(
        &mut self,
        now: tokio::time::Instant,
        next_mempool_poll_at: tokio::time::Instant,
    ) {
        let interval = tokio::time::Duration::from_millis(if self.n_txs_in_progress() > 0 {
            self.execution_params.results_polling_interval_millis
        } else {
            self.execution_params.tx_polling_interval_millis
        });
        let wake_at = (now + interval).min(next_mempool_poll_at);
        tokio::time::sleep_until(wake_at).await;
    }
}

// TODO(Tsabary): consider converting this to an async function and calling spawn_blocking
// internally.
fn lock_executor(
    executor: &Arc<Mutex<dyn TransactionExecutorTrait>>,
) -> MutexGuard<'_, dyn TransactionExecutorTrait> {
    executor.try_lock().expect("Only a single task should use the executor.")
}

async fn convert_to_executable_blockifier_tx(
    transaction_converter: &TransactionConverter,
    tx: InternalConsensusTransaction,
) -> TransactionConverterResult<BlockifierTransaction> {
    let executable_tx =
        transaction_converter.convert_internal_consensus_tx_to_executable_tx(tx).await?;
    Ok(BlockifierTransaction::new_for_sequencing(executable_tx))
}

async fn collect_execution_results_and_stream_txs(
    tx_chunk: &[InternalConsensusTransaction],
    results: Vec<TransactionExecutorResult<TransactionExecutionOutput>>,
    execution_data: &mut BlockTransactionExecutionData,
    pre_confirmed_tx_sender: &mut Option<PreconfirmedTxSender>,
) -> BlockBuilderResult<()> {
    assert!(
        results.len() == tx_chunk.len(),
        "The number of results match the number of transactions."
    );

    for (input_tx, result) in tx_chunk.iter().zip(results) {
        let optional_l1_handler_tx =
            if let InternalConsensusTransaction::L1Handler(l1_handler_tx) = input_tx {
                Some(l1_handler_tx.tx.clone())
            } else {
                None
            };
        let tx_hash = input_tx.tx_hash();

        // Insert the tx_hash into the appropriate collection if it's an L1_Handler transaction.
        if let InternalConsensusTransaction::L1Handler(_) = input_tx {
            let is_new_entry = execution_data.consumed_l1_handler_tx_hashes.insert(tx_hash);
            // Unlike the duplicate account/RPC hashes handled below, a duplicate L1 handler hash is
            // never valid input: it signals a batcher-cache or l1-provider fault, possibly
            // reorg-producing. Keep it a hard invariant.
            assert!(is_new_entry, "Duplicate L1 handler transaction hash: {tx_hash}.");
        }

        // Check for duplicates in both the executed and rejected collections.
        if execution_data.execution_infos_and_signatures.contains_key(&tx_hash)
            || execution_data.rejected_tx_hashes.contains(&tx_hash)
        {
            return Err(BlockBuilderError::FailOnError(FailOnErrorCause::DuplicateTransaction(
                tx_hash,
            )));
        }

        match result {
            Ok((tx_execution_info, state_maps)) => {
                if let Some(ref revert_error) = tx_execution_info.revert_error {
                    warn!(
                        "Transaction {} is reverted during execution while still accepted. Revert \
                         Error: {}",
                        input_tx.tx_hash(),
                        revert_error,
                    );
                }
                let (tx_index, _) = execution_data.execution_infos_and_signatures.insert_full(
                    tx_hash,
                    (tx_execution_info, input_tx.tx_signature_for_commitment()),
                );

                if let Some(block_number) = proof_facts_block_number(input_tx) {
                    execution_data.proof_facts_block_numbers.insert(tx_hash, block_number);
                }

                // Skip sending the pre confirmed executed transactions, receipts and state diffs
                // during validation flow or if the channel was closed. In validate flow
                // pre_confirmed_tx_sender is None.
                if let Some(pre_confirmed_sender) = pre_confirmed_tx_sender {
                    let tx_receipt = StarknetClientTransactionReceipt::from((
                        tx_hash,
                        TransactionOffsetInBlock(tx_index),
                        // TODO(noamsp): Consider using tx_execution_info and moving the line that
                        // consumes it below this (if it doesn't change functionality).
                        &execution_data.execution_infos_and_signatures[&tx_hash].0,
                        optional_l1_handler_tx,
                    ));

                    let tx_state_diff = StarknetClientStateDiff::from(state_maps).0;

                    let result = pre_confirmed_sender.try_send((
                        input_tx.clone(),
                        tx_receipt,
                        tx_state_diff,
                    ));

                    match result {
                        Ok(_) => {}
                        Err(TrySendError::Closed(_)) => {
                            warn!(
                                "Preconfirmed block writer channel was closed. Skipping to send \
                                 further preconfirmed transactions."
                            );
                            *pre_confirmed_tx_sender = None;
                        }
                        Err(err) => {
                            warn!("Sending data to preconfirmed block writer failed: {:?}", err);
                        }
                    }
                }
            }
            Err(err) => {
                info!(
                    "Transaction {} failed to execute with error: {}.",
                    tx_hash,
                    err.log_compatible_to_string()
                );
                execution_data.rejected_tx_hashes.insert(tx_hash);
            }
        }
    }

    Ok(())
}

pub struct BlockMetadata {
    pub block_info: BlockInfo,
    pub retrospective_block_hash: Option<BlockHashAndNumber>,
}

// Type definitions for the abort channel required to abort the block builder.
pub type AbortSignalSender = tokio::sync::oneshot::Sender<()>;
pub type ApolloStateReaderAndContractManager = StateReaderAndContractManager<ApolloReader>;
pub type BatcherWorkerPool = Arc<WorkerPool<CachedState<ApolloStateReaderAndContractManager>>>;

/// The BlockBuilderFactoryTrait is responsible for creating a new block builder.
#[cfg_attr(test, automock)]
pub trait BlockBuilderFactoryTrait: Send + Sync {
    // TODO(noamsp): Investigate and remove this clippy warning.
    #[allow(clippy::too_many_arguments)]
    fn create_block_builder(
        &self,
        block_metadata: BlockMetadata,
        execution_params: BlockBuilderExecutionParams,
        native_classes_whitelist: NativeClassesWhitelist,
        tx_provider: Box<dyn TransactionProvider>,
        output_content_sender: Option<
            tokio::sync::mpsc::UnboundedSender<InternalConsensusTransaction>,
        >,
        pre_confirmed_tx_sender: Option<PreconfirmedTxSender>,
        runtime: tokio::runtime::Handle,
    ) -> BlockBuilderResult<(Box<dyn BlockBuilderTrait>, AbortSignalSender)>;
}

pub struct BlockBuilderFactory {
    pub block_builder_config: BlockBuilderConfig,
    pub storage_reader: StorageReader,
    pub contract_class_manager: ContractClassManager,
    pub class_manager_client: SharedClassManagerClient,
    pub proof_manager_client: SharedProofManagerClient,
    pub worker_pool: BatcherWorkerPool,
}

impl BlockBuilderFactory {
    // TODO(noamsp): Investigate and remove this clippy warning.
    fn preprocess_and_create_transaction_executor(
        &self,
        block_metadata: BlockMetadata,
        native_classes_whitelist: NativeClassesWhitelist,
        runtime: tokio::runtime::Handle,
    ) -> BlockBuilderResult<ConcurrentTransactionExecutor<ApolloStateReaderAndContractManager>>
    {
        trace!(
            "preprocess and create transaction executor for block {}",
            block_metadata.block_info.block_number
        );
        let height = block_metadata.block_info.block_number;
        let block_builder_config = self.block_builder_config.clone();
        let versioned_constants = VersionedConstants::get_versioned_constants(
            block_builder_config.versioned_constants_overrides,
        );
        let block_context = BlockContext::new(
            block_metadata.block_info,
            block_builder_config.chain_info,
            versioned_constants,
            block_builder_config.bouncer_config,
        );

        // Block production has no per-call deadline to bound this against; leave it unbounded, as
        // before.
        let class_reader = Some(ClassReader {
            reader: self.class_manager_client.clone(),
            runtime,
            deadline: None,
        });
        let apollo_reader =
            ApolloReader::new_with_class_reader(self.storage_reader.clone(), height, class_reader);
        let state_reader = StateReaderAndContractManager::new_with_native_classes_whitelist(
            apollo_reader,
            self.contract_class_manager.clone(),
            native_classes_whitelist,
            Some(BATCHER_CLASS_CACHE_METRICS),
        );

        let executor = ConcurrentTransactionExecutor::start_block(
            state_reader,
            block_context,
            block_metadata.retrospective_block_hash,
            self.worker_pool.clone(),
            None,
        )?;

        Ok(executor)
    }
}

impl BlockBuilderFactoryTrait for BlockBuilderFactory {
    fn create_block_builder(
        &self,
        block_metadata: BlockMetadata,
        execution_params: BlockBuilderExecutionParams,
        native_classes_whitelist: NativeClassesWhitelist,
        tx_provider: Box<dyn TransactionProvider>,
        output_content_sender: Option<
            tokio::sync::mpsc::UnboundedSender<InternalConsensusTransaction>,
        >,
        pre_confirmed_tx_sender: Option<PreconfirmedTxSender>,
        runtime: tokio::runtime::Handle,
    ) -> BlockBuilderResult<(Box<dyn BlockBuilderTrait>, AbortSignalSender)> {
        let executor = self.preprocess_and_create_transaction_executor(
            block_metadata,
            native_classes_whitelist,
            runtime,
        )?;
        let (abort_signal_sender, abort_signal_receiver) = tokio::sync::oneshot::channel();
        let transaction_converter = TransactionConverter::new(
            self.class_manager_client.clone(),
            self.proof_manager_client.clone(),
            self.block_builder_config.chain_info.chain_id.clone(),
        );
        let block_builder = Box::new(BlockBuilder::new(
            executor,
            tx_provider,
            output_content_sender,
            pre_confirmed_tx_sender,
            abort_signal_receiver,
            transaction_converter,
            execution_params,
        ));
        Ok((block_builder, abort_signal_sender))
    }
}

/// Supplementary information for use by downstream services.
#[cfg_attr(test, derive(Clone))]
#[derive(Debug, Default, PartialEq)]
pub struct BlockTransactionExecutionData {
    // The transaction signatures are needed for block hash calculation; it is optional as
    // l1-handler transactions do not have signatures.
    // TODO(Nimrod): Consider refactoring it to a struct.
    pub execution_infos_and_signatures:
        IndexMap<TransactionHash, (TransactionExecutionInfo, Option<TransactionSignature>)>,
    pub rejected_tx_hashes: IndexSet<TransactionHash>,
    pub consumed_l1_handler_tx_hashes: IndexSet<TransactionHash>,
    /// For each successfully executed proof-carrying transaction (SNIP36), maps the block hash
    /// that the proof was verified against to its block number. Used by the batcher to derive
    /// accessed-key entries on `BLOCK_HASH_TABLE_ADDRESS`.
    pub proof_facts_block_numbers: IndexMap<TransactionHash, BlockNumber>,
}

impl BlockTransactionExecutionData {
    /// Removes the last txs with the given hashes from the execution data.
    fn remove_last_txs(&mut self, tx_hashes: &[TransactionHash]) {
        for tx_hash in tx_hashes.iter().rev() {
            remove_last_map(&mut self.execution_infos_and_signatures, tx_hash);
            remove_last_set(&mut self.rejected_tx_hashes, tx_hash);
            remove_last_set(&mut self.consumed_l1_handler_tx_hashes, tx_hash);
            remove_last_map(&mut self.proof_facts_block_numbers, tx_hash);
        }
    }

    pub(crate) fn l2_gas_used(&self) -> GasAmount {
        let mut res = GasAmount::ZERO;
        for (execution_info, _) in self.execution_infos_and_signatures.values() {
            res =
                res.checked_add(execution_info.receipt.gas.l2_gas).expect("Total L2 gas overflow.");
        }

        res
    }
}

/// Removes the tx_hash from the map, if it exists.
/// Verifies that the removed transaction is the last one in the map.
fn remove_last_map<V>(map: &mut IndexMap<TransactionHash, V>, tx_hash: &TransactionHash) {
    if let Some((idx, _, _)) = map.swap_remove_full(tx_hash) {
        assert_eq!(idx, map.len(), "The removed txs must be the last ones.");
    }
}

/// Removes the tx_hash from the set, if it exists.
/// Verifies that the removed transaction is the last one in the set.
fn remove_last_set(set: &mut IndexSet<TransactionHash>, tx_hash: &TransactionHash) {
    if let Some((idx, _)) = set.swap_remove_full(tx_hash) {
        assert_eq!(idx, set.len(), "The removed txs must be the last ones.");
    }
}

/// If the transaction includes an SNIP36 proof, returns the block number whose state will be used
/// to verify the proof against. Otherwise returns `None`.
fn proof_facts_block_number(tx: &InternalConsensusTransaction) -> Option<BlockNumber> {
    let InternalConsensusTransaction::RpcTransaction(rpc) = tx else { return None };
    let InternalRpcTransactionWithoutTxHash::Invoke(invoke) = &rpc.tx else { return None };
    snos_block_number_from_proof_facts(&invoke.proof_facts)
}

fn record_and_log_block_commitment_measurements(
    height: BlockNumber,
    measurements: BlockCommitmentsMeasurements,
) {
    let usize_to_u64_warn_msg = "Conversion from usize to u64 should not fail.";

    // Record the measurements.
    BLOCK_COMMITMENT_MEASUREMENTS_COUNT.increment(1);

    let tx_commitment_latency =
        convert_microseconds_to_u64(measurements.transaction_commitment_duration);
    let n_txs = u64::try_from(measurements.n_txs).expect(usize_to_u64_warn_msg);
    TX_COMMITMENT_LATENCY.increment(tx_commitment_latency);
    TX_COMMITMENT_COUNT.increment(n_txs);

    let event_commitment_latency =
        convert_microseconds_to_u64(measurements.event_commitment_duration);
    let n_events = u64::try_from(measurements.n_events).expect(usize_to_u64_warn_msg);
    EVENT_COMMITMENT_LATENCY.increment(event_commitment_latency);
    EVENT_COMMITMENT_COUNT.increment(n_events);

    let receipt_commitment_latency =
        convert_microseconds_to_u64(measurements.receipt_commitment_duration);
    RECEIPT_COMMITMENT_LATENCY.increment(receipt_commitment_latency);

    let state_diff_commitment_latency =
        convert_microseconds_to_u64(measurements.state_diff_commitment_duration);
    let state_diff_length =
        u64::try_from(measurements.state_diff_length).expect(usize_to_u64_warn_msg);
    STATE_DIFF_COMMITMENT_LATENCY.increment(state_diff_commitment_latency);
    STATE_DIFF_LENGTH.increment(state_diff_length);

    // Log the measurements.
    let height = height.0;
    let tx_commitment_per_tx_latency_string = tx_commitment_latency
        .checked_div(n_txs)
        .map_or("?".to_string(), |latency| format!("{latency} µs"));
    let event_commitment_per_event_latency_string = event_commitment_latency
        .checked_div(n_events)
        .map_or("?".to_string(), |latency| format!("{latency} µs"));
    let state_diff_commitment_per_state_diff_length_latency_string = state_diff_commitment_latency
        .checked_div(state_diff_length)
        .map_or("?".to_string(), |latency| format!("{latency} µs"));

    debug!(
        "Block {height} commitments latencies: tx/event/receipt/state_diff in µs: \
         {tx_commitment_latency}/{event_commitment_latency}/{receipt_commitment_latency}/\
         {state_diff_commitment_latency}, tx commitment per tx: \
         {tx_commitment_per_tx_latency_string}, event commitment per event: \
         {event_commitment_per_event_latency_string}, state diff commitment per state diff \
         length: {state_diff_commitment_per_state_diff_length_latency_string}",
    );
}

fn convert_microseconds_to_u64(duration: Duration) -> u64 {
    u64::try_from(duration.as_micros()).unwrap_or_else(|_| {
        warn!("Failed to convert duration microseconds to u64.");
        0
    })
}
