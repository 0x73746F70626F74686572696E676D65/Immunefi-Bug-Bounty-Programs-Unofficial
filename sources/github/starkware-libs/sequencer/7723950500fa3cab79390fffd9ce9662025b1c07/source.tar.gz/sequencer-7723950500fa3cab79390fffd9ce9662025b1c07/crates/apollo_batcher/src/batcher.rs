use std::collections::HashMap;
use std::fmt::Write;
use std::sync::Arc;
use std::time::{Duration, Instant};

use apollo_batcher_config::config::{
    BatcherConfig,
    BatcherDynamicConfig,
    FirstBlockWithPartialBlockHash,
};
use apollo_batcher_types::batcher_types::{
    BatcherResult,
    CallContractInput,
    CallContractOutput,
    CentralObjects,
    DecisionReachedInput,
    DecisionReachedResponse,
    FinishProposalInput,
    FinishProposalStatus,
    FinishedProposalInfo,
    FinishedProposalInfoWithoutParent,
    GetHeightResponse,
    GetProposalContent,
    GetProposalContentInput,
    GetProposalContentResponse,
    ProposalCommitment,
    ProposalId,
    ProposalStatus,
    ProposeBlockInput,
    RevertBlockInput,
    SendTxsForProposalInput,
    SendTxsForProposalStatus,
    StartHeightInput,
    ValidateBlockInput,
};
use apollo_batcher_types::errors::BatcherError;
use apollo_class_manager_types::SharedClassManagerClient;
use apollo_committer_types::committer_types::RevertBlockResponse;
use apollo_committer_types::communication::SharedCommitterClient;
use apollo_config_manager_types::communication::SharedConfigManagerClient;
use apollo_infra::component_definitions::{default_component_start_fn, ComponentStarter};
use apollo_l1_events_types::errors::{L1EventsProviderClientError, L1EventsProviderError};
use apollo_l1_events_types::{SessionState, SharedL1EventsProviderClient};
use apollo_mempool_types::communication::SharedMempoolClient;
use apollo_mempool_types::mempool_types::CommitBlockArgs;
use apollo_proof_manager_types::SharedProofManagerClient;
use apollo_reverts::revert_block;
use apollo_state_reader::apollo_state::{ApolloReader, ClassReader};
use apollo_state_sync_types::state_sync_types::SyncBlock;
use apollo_storage::accessed_keys::{
    AccessedKeys,
    AccessedKeysStorageReader,
    AccessedKeysStorageWriter,
};
use apollo_storage::block_hash::{BlockHashStorageReader, BlockHashStorageWriter};
use apollo_storage::global_root::{GlobalRootStorageReader, GlobalRootStorageWriter};
use apollo_storage::global_root_marker::{
    GlobalRootMarkerStorageReader,
    GlobalRootMarkerStorageWriter,
};
use apollo_storage::metrics::BATCHER_STORAGE_OPEN_READ_TRANSACTIONS;
use apollo_storage::partial_block_hash::{
    PartialBlockHashComponentsStorageReader,
    PartialBlockHashComponentsStorageWriter,
};
use apollo_storage::state::{StateStorageReader, StateStorageWriter};
use apollo_storage::state_commitment_infos::{
    CompressedStateCommitmentInfos,
    StateCommitmentInfosStorageReader,
    StateCommitmentInfosStorageWriter,
};
use apollo_storage::storage_reader_server::{
    DynamicConfigError,
    DynamicConfigProvider,
    ServerConfig,
    SharedDynamicConfigProvider,
    StorageReaderServerDynamicConfig,
};
use apollo_storage::storage_reader_types::{
    GenericStorageReaderServerHandler,
    StorageReaderRequest,
    StorageReaderResponse,
};
use apollo_storage::{
    open_storage_with_metric_and_server,
    StorageError,
    StorageReader,
    StorageResult,
    StorageWriter,
};
use async_trait::async_trait;
use blockifier::blockifier::config::NativeClassesWhitelist;
use blockifier::blockifier_versioned_constants::VersionedConstants;
use blockifier::bouncer::BouncerConfig;
use blockifier::concurrency::worker_pool::WorkerPool;
use blockifier::context::BlockContext;
use blockifier::execution::entry_point::call_view_entry_point;
use blockifier::state::contract_class_manager::ContractClassManager;
use blockifier::state::state_api::StateReader;
use blockifier::state::state_reader_and_contract_manager::StateReaderAndContractManager;
use blockifier::transaction::objects::TransactionExecutionInfo;
use futures::FutureExt;
use indexmap::{IndexMap, IndexSet};
#[cfg(test)]
use mockall::automock;
use starknet_api::block::{
    BlockHash,
    BlockInfo,
    BlockNumber,
    GasPrice,
    GasPriceVector,
    GasPrices,
    NonzeroGasPrice,
    ReplayBlockMetadata,
};
use starknet_api::block_hash::block_hash_calculator::{
    extract_l1_da_mode_from_concatenated_counts,
    PartialBlockHash,
    PartialBlockHashComponents,
};
use starknet_api::consensus_transaction::InternalConsensusTransaction;
use starknet_api::core::{ContractAddress, GlobalRoot, Nonce, StateDiffCommitment};
use starknet_api::state::{StateNumber, ThinStateDiff};
use starknet_api::transaction::fields::Calldata;
use starknet_api::transaction::TransactionHash;
use tokio::sync::{Mutex, Semaphore};
use tokio::task::AbortHandle;
use tracing::{debug, error, info, instrument, trace, warn, Instrument};
use validator::Validate;

use crate::block_builder::{
    BlockBuilderError,
    BlockBuilderExecutionParams,
    BlockBuilderFactory,
    BlockBuilderFactoryTrait,
    BlockBuilderTrait,
    BlockExecutionArtifacts,
    BlockMetadata,
};
use crate::cende_client_types::CendeBlockMetadata;
use crate::commitment_manager::commitment_manager_impl::{
    ApolloCommitmentManager,
    CommitmentManager,
};
use crate::commitment_manager::types::RevertTaskOutput;
use crate::metrics::{
    register_metrics,
    ProposalMetricsHandle,
    BATCHED_TRANSACTIONS,
    BATCHER_L1_EVENTS_PROVIDER_ERRORS,
    BATCHER_VIEW_CALL_CLASS_CACHE_METRICS,
    BUILDING_HEIGHT,
    GLOBAL_ROOT_HEIGHT,
    L2_GAS_IN_LAST_BLOCK,
    LAST_BATCHED_BLOCK_HEIGHT,
    LAST_PROPOSED_BLOCK_HEIGHT,
    LAST_SYNCED_BLOCK_HEIGHT,
    NUM_TRANSACTION_IN_BLOCK,
    PROVING_GAS_IN_LAST_BLOCK,
    REJECTED_TRANSACTIONS,
    REJECTED_VIEW_CALLS,
    REVERTED_BLOCKS,
    REVERTED_TRANSACTIONS,
    SIERRA_GAS_IN_LAST_BLOCK,
    SYNCED_TRANSACTIONS,
};
use crate::pre_confirmed_block_writer::{
    PreconfirmedBlockWriterFactory,
    PreconfirmedBlockWriterFactoryTrait,
    PreconfirmedBlockWriterTrait,
};
use crate::pre_confirmed_cende_client::PreconfirmedCendeClientTrait;
use crate::transaction_provider::{
    ProposeTransactionProvider,
    TxProviderPhase,
    ValidateTransactionProvider,
};
use crate::utils::{
    deadline_as_instant,
    proposal_status_from,
    verify_block_input,
    ProposalResult,
    ProposalTask,
};

type OutputStreamReceiver = tokio::sync::mpsc::UnboundedReceiver<InternalConsensusTransaction>;
type InputStreamSender = tokio::sync::mpsc::Sender<InternalConsensusTransaction>;

/// Maximal number of felts a view entry point call may return, about 3.2 MB at 32 bytes per felt.
/// Far above the largest legitimate reader (the staking contract's staker list, a few felts per
/// staker), and small enough to stay cheap to serialize over the batcher's remote server boundary.
///
/// Bounds the top-level return value only.
pub(crate) const MAX_VIEW_CALL_RETDATA_LENGTH: usize = 100_000;

/// Maximal number of view calls that may occupy tokio blocking threads at once.
///
/// The node runs on a bare `#[tokio::main]` runtime, so the blocking pool holds tokio's default of
/// 512 threads, and `spawn_blocking` beyond that queues instead of failing. Block production shares
/// that pool (block_builder execution and block hash computation), as do the gateway's stateful
/// validator and the transaction converter, so view calls, a non-critical read path, get a small
/// slice of it: 32 slots is under 7% of the pool, leaving block production unaffected even when
/// every view call slot is stuck. A view call that a caller abandoned keeps its thread parked until
/// execution ends, so this is also the cap on how many such threads can pile up.
pub(crate) const MAX_CONCURRENT_VIEW_CALLS: usize = 32;

/// Reason returned when all view call slots are taken. Names no internal component, since it
/// reaches external callers.
pub(crate) const TOO_MANY_VIEW_CALLS_REASON: &str =
    "Too many concurrent contract calls. Try again later.";

#[cfg_attr(test, apollo_proc_macros::upgrade_fields_visibility(pub(crate)))]
pub struct Batcher {
    pub config: BatcherConfig,
    pub storage_reader: Arc<dyn BatcherStorageReader>,
    /// Factory for creating state readers used to execute view calls (e.g. call_contract).
    view_state_reader_factory: Box<dyn ViewStateReaderFactory>,
    /// Caps how many view calls may occupy tokio blocking threads at once. A permit is held by the
    /// blocking task itself, so it is returned only when the execution really ends.
    view_call_semaphore: Arc<Semaphore>,
    pub storage_writer: Box<dyn BatcherStorageWriter>,
    pub committer_client: SharedCommitterClient,
    pub l1_events_provider_client: SharedL1EventsProviderClient,
    pub mempool_client: Option<SharedMempoolClient>,
    pub config_manager_client: SharedConfigManagerClient,

    /// Used to create block builders.
    /// Using the factory pattern to allow for easier testing.
    block_builder_factory: Box<dyn BlockBuilderFactoryTrait>,

    /// Used to create pre-confirmed block writers.
    pre_confirmed_block_writer_factory: Box<dyn PreconfirmedBlockWriterFactoryTrait>,

    /// The height that the batcher is currently working on.
    /// All proposals are considered to be at this height.
    active_height: Option<BlockNumber>,

    /// The block proposal that is currently being built, if any.
    /// At any given time, there can be only one proposal being actively executed (either proposed
    /// or validated).
    active_proposal: Arc<Mutex<Option<ProposalId>>>,
    active_proposal_task: Option<ProposalTask>,

    /// Holds all the proposals that completed execution in the current height.
    executed_proposals: Arc<Mutex<HashMap<ProposalId, ProposalResult<BlockExecutionArtifacts>>>>,

    /// The propose blocks transaction streams, used to stream out the proposal transactions.
    /// Each stream is kept until all the transactions are streamed out, or a new height is
    /// started.
    propose_tx_streams: HashMap<ProposalId, OutputStreamReceiver>,

    /// The validate blocks transaction streams, used to stream in the transactions to validate.
    /// Each stream is kept until proposal finalization/abort is received, or a new height is
    /// started.
    validate_tx_streams: HashMap<ProposalId, InputStreamSender>,

    /// Number of proposals made since coming online.
    proposals_counter: u64,

    /// The proposal commitment of the previous height.
    /// This is returned by the decision_reached function.
    prev_proposal_commitment: Option<(BlockNumber, ProposalCommitment)>,

    commitment_manager: ApolloCommitmentManager,

    /// Keep alive to maintain the storage reader server running.
    #[allow(dead_code)]
    storage_reader_server_handle: AbortHandle,
}

impl Batcher {
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn new(
        config: BatcherConfig,
        storage_reader: Arc<dyn BatcherStorageReader>,
        view_state_reader_factory: Box<dyn ViewStateReaderFactory>,
        storage_writer: Box<dyn BatcherStorageWriter>,
        committer_client: SharedCommitterClient,
        l1_events_provider_client: SharedL1EventsProviderClient,
        mempool_client: Option<SharedMempoolClient>,
        config_manager_client: SharedConfigManagerClient,
        block_builder_factory: Box<dyn BlockBuilderFactoryTrait>,
        pre_confirmed_block_writer_factory: Box<dyn PreconfirmedBlockWriterFactoryTrait>,
        commitment_manager: ApolloCommitmentManager,
        storage_reader_server_handle: AbortHandle,
    ) -> Self {
        assert!(
            config.static_config.validation_only == mempool_client.is_none(),
            "validation_only={} but mempool_client is {}",
            config.static_config.validation_only,
            if mempool_client.is_none() { "None" } else { "Some" }
        );
        Self {
            config,
            storage_reader,
            view_state_reader_factory,
            view_call_semaphore: Arc::new(Semaphore::new(MAX_CONCURRENT_VIEW_CALLS)),
            storage_writer,
            committer_client,
            l1_events_provider_client,
            mempool_client,
            config_manager_client,
            block_builder_factory,
            pre_confirmed_block_writer_factory,
            active_height: None,
            active_proposal: Arc::new(Mutex::new(None)),
            active_proposal_task: None,
            executed_proposals: Arc::new(Mutex::new(HashMap::new())),
            propose_tx_streams: HashMap::new(),
            validate_tx_streams: HashMap::new(),
            // Allow the first few proposals to be without L1 txs while system starts up.
            proposals_counter: 1,
            prev_proposal_commitment: None,
            commitment_manager,
            storage_reader_server_handle,
        }
    }

    /// Returns the latest versioned constants with the batcher's configured overrides applied.
    fn versioned_constants(&self) -> VersionedConstants {
        VersionedConstants::get_versioned_constants(
            self.config.static_config.block_builder_config.versioned_constants_overrides.clone(),
        )
    }

    pub(crate) fn update_dynamic_config(&mut self, dynamic_config: BatcherDynamicConfig) {
        let candidate =
            BatcherConfig { static_config: self.config.static_config.clone(), dynamic_config };
        if let Err(errors) = candidate.validate() {
            warn!(
                "Dynamic config update rejected due to validation errors: {errors}. Keeping \
                 previous config."
            );
            return;
        }
        self.config = candidate;
    }

    #[instrument(skip(self), err)]
    pub async fn start_height(&mut self, input: StartHeightInput) -> BatcherResult<()> {
        if self.active_height == Some(input.height) {
            return Err(BatcherError::HeightInProgress);
        }

        let storage_height = self.get_height_from_storage()?;
        if storage_height != input.height {
            return Err(BatcherError::StorageHeightMarkerMismatch {
                marker_height: storage_height,
                requested_height: input.height,
            });
        }

        self.abort_active_height().await;

        info!("Starting to work on height {}.", input.height);
        self.active_height = Some(input.height);

        Ok(())
    }

    // TODO(Rotem): Once the fallback option to state sync is removed - remove
    // `retrospective_block_hash` from the input and get it from storage instead.
    #[instrument(skip(self), err)]
    pub async fn propose_block(
        &mut self,
        propose_block_input: ProposeBlockInput,
    ) -> BatcherResult<()> {
        if self.config.static_config.validation_only {
            return Err(BatcherError::ProposingNotSupported);
        }
        let block_number = propose_block_input.block_info.block_number;
        let proposal_metrics_handle = ProposalMetricsHandle::new();
        let active_height = self.active_height.ok_or(BatcherError::NoActiveHeight)?;
        verify_block_input(
            active_height,
            block_number,
            propose_block_input.retrospective_block_hash,
        )?;

        let mempool_client = self
            .mempool_client
            .as_ref()
            .expect("Mempool client must be present in non-validation-only mode.");

        // TODO(yair): extract function for the following calls, use join_all.
        info!(
            "Notifying the mempool we start to work on block {}, round {}.",
            block_number, propose_block_input.proposal_round
        );
        mempool_client.commit_block(CommitBlockArgs::default()).await.map_err(|err| {
            error!(
                "Mempool is not ready to start proposal {}: {}.",
                propose_block_input.proposal_id, err
            );
            BatcherError::NotReady
        })?;
        info!(
            "Updating gas price for block {}, round {} in Mempool client",
            block_number, propose_block_input.proposal_round
        );
        mempool_client
            .update_gas_price(
                propose_block_input.block_info.gas_prices.strk_gas_prices.l2_gas_price.get(),
            )
            .await
            .map_err(|err| {
                error!("Failed to update gas price in mempool: {}", err);
                BatcherError::InternalError
            })?;
        // Ignore errors. If start_block fails, then subsequent calls to l1 provider will fail on
        // out of session and l1 provider will restart and bootstrap again.
        let _ = self
            .l1_events_provider_client
            .start_block(SessionState::Propose, propose_block_input.block_info.block_number)
            .await
            .inspect_err(|err| {
                error!(
                    "L1 provider is not ready to start proposing block {}: {}. ",
                    propose_block_input.block_info.block_number, err
                );
                BATCHER_L1_EVENTS_PROVIDER_ERRORS.increment(1);
            });

        let start_phase = if self
            .proposals_counter
            .is_multiple_of(self.config.static_config.propose_l1_txs_every)
        {
            TxProviderPhase::L1
        } else {
            TxProviderPhase::Mempool
        };
        let tx_provider = ProposeTransactionProvider::new(
            mempool_client.clone(),
            self.l1_events_provider_client.clone(),
            self.config.static_config.max_l1_handler_txs_per_block_proposal,
            propose_block_input.block_info.block_number,
            start_phase,
        );

        // A channel to receive the transactions included in the proposed block.
        let (output_tx_sender, output_tx_receiver) = tokio::sync::mpsc::unbounded_channel();

        let cende_block_metadata = CendeBlockMetadata::new(propose_block_input.block_info.clone());
        let (pre_confirmed_block_writer, pre_confirmed_tx_sender) =
            self.pre_confirmed_block_writer_factory.create(
                propose_block_input.block_info.block_number,
                propose_block_input.proposal_round,
                cende_block_metadata,
            );

        let (block_builder, abort_signal_sender) = self
            .block_builder_factory
            .create_block_builder(
                BlockMetadata {
                    block_info: propose_block_input.block_info,
                    retrospective_block_hash: propose_block_input.retrospective_block_hash,
                },
                BlockBuilderExecutionParams {
                    deadline: deadline_as_instant(propose_block_input.deadline)?,
                    is_validator: false,
                    proposer_idle_detection_delay: self
                        .config
                        .dynamic_config
                        .proposer_idle_detection_delay_millis,
                    n_concurrent_txs: self.config.dynamic_config.n_concurrent_txs,
                    tx_polling_interval_millis: self
                        .config
                        .dynamic_config
                        .tx_polling_interval_millis,
                    results_polling_interval_millis: self
                        .config
                        .dynamic_config
                        .results_polling_interval_millis,
                },
                self.config.dynamic_config.native_classes_whitelist.clone(),
                Box::new(tx_provider),
                Some(output_tx_sender),
                Some(pre_confirmed_tx_sender),
                tokio::runtime::Handle::current(),
            )
            .map_err(|err| {
                error!("Failed to get block builder: {}", err);
                BatcherError::InternalError
            })?;

        self.spawn_proposal(
            propose_block_input.proposal_id,
            block_builder,
            abort_signal_sender,
            None,
            Some(pre_confirmed_block_writer),
            proposal_metrics_handle,
        )
        .await?;

        let proposal_already_exists =
            self.propose_tx_streams.insert(propose_block_input.proposal_id, output_tx_receiver);
        assert!(
            proposal_already_exists.is_none(),
            "Proposal {} already exists. This should have been checked when spawning the proposal.",
            propose_block_input.proposal_id
        );
        LAST_PROPOSED_BLOCK_HEIGHT.set_lossy(block_number.0);
        self.proposals_counter += 1;
        Ok(())
    }

    #[instrument(skip(self), err)]
    pub async fn validate_block(
        &mut self,
        validate_block_input: ValidateBlockInput,
    ) -> BatcherResult<()> {
        let proposal_metrics_handle = ProposalMetricsHandle::new();
        let active_height = self.active_height.ok_or(BatcherError::NoActiveHeight)?;
        verify_block_input(
            active_height,
            validate_block_input.block_info.block_number,
            validate_block_input.retrospective_block_hash,
        )?;

        // Ignore errors. If start_block fails, then subsequent calls to l1 provider will fail on
        // out of session and l1 provider will restart and bootstrap again.
        let _ = self
            .l1_events_provider_client
            .start_block(SessionState::Validate, validate_block_input.block_info.block_number)
            .await
            .inspect_err(|err| {
                error!(
                    "L1 provider is not ready to start validating block {}: {}. ",
                    validate_block_input.block_info.block_number, err
                );
                BATCHER_L1_EVENTS_PROVIDER_ERRORS.increment(1);
            });

        // A channel to send the transactions to include in the block being validated.
        let (input_tx_sender, input_tx_receiver) =
            tokio::sync::mpsc::channel(self.config.static_config.input_stream_content_buffer_size);
        let (final_n_executed_txs_sender, final_n_executed_txs_receiver) =
            tokio::sync::oneshot::channel();

        let tx_provider = ValidateTransactionProvider::new(
            input_tx_receiver,
            final_n_executed_txs_receiver,
            self.l1_events_provider_client.clone(),
            validate_block_input.block_info.block_number,
        );
        let (block_builder, abort_signal_sender) = self
            .block_builder_factory
            .create_block_builder(
                BlockMetadata {
                    block_info: validate_block_input.block_info,
                    retrospective_block_hash: validate_block_input.retrospective_block_hash,
                },
                BlockBuilderExecutionParams {
                    deadline: deadline_as_instant(validate_block_input.deadline)?,
                    is_validator: true,
                    proposer_idle_detection_delay: self
                        .config
                        .dynamic_config
                        .proposer_idle_detection_delay_millis,
                    n_concurrent_txs: self.config.dynamic_config.n_concurrent_txs,
                    tx_polling_interval_millis: self
                        .config
                        .dynamic_config
                        .validate_tx_polling_interval_millis,
                    results_polling_interval_millis: self
                        .config
                        .dynamic_config
                        .results_polling_interval_millis,
                },
                self.config.dynamic_config.native_classes_whitelist.clone(),
                Box::new(tx_provider),
                None,
                None,
                tokio::runtime::Handle::current(),
            )
            .map_err(|err| {
                error!("Failed to get block builder: {}", err);
                BatcherError::InternalError
            })?;

        self.spawn_proposal(
            validate_block_input.proposal_id,
            block_builder,
            abort_signal_sender,
            Some(final_n_executed_txs_sender),
            None,
            proposal_metrics_handle,
        )
        .await?;

        let validation_already_exists =
            self.validate_tx_streams.insert(validate_block_input.proposal_id, input_tx_sender);
        assert!(
            validation_already_exists.is_none(),
            "Proposal {} already exists. This should have been checked when spawning the proposal.",
            validate_block_input.proposal_id
        );

        Ok(())
    }

    /// Clear all the proposals from the previous height.
    #[cfg_attr(any(test, feature = "testing"), apollo_proc_macros::make_visibility(pub))]
    async fn abort_active_height(&mut self) {
        self.abort_active_proposal().await;
        self.executed_proposals.lock().await.clear();
        self.propose_tx_streams.clear();
        self.validate_tx_streams.clear();
        self.active_height = None;
    }

    #[instrument(skip(self), err)]
    pub async fn send_txs_for_proposal(
        &mut self,
        send_txs_for_proposal_input: SendTxsForProposalInput,
    ) -> BatcherResult<SendTxsForProposalStatus> {
        let SendTxsForProposalInput { proposal_id, txs: new_txs } = send_txs_for_proposal_input;
        self.ensure_validate_proposal_exists(proposal_id)?;

        if self.is_active(proposal_id).await {
            // The proposal is active. Send transactions through the tx provider.
            let tx_provider_sender = &self
                .validate_tx_streams
                .get(&proposal_id)
                .expect("Expecting tx_provider_sender to exist during batching.");
            for tx in new_txs {
                tx_provider_sender.send(tx).await.map_err(|err| {
                    error!("Failed to send transaction to the tx provider: {}", err);
                    BatcherError::InternalError
                })?;
            }
            return Ok(SendTxsForProposalStatus::Processing);
        }

        // The proposal is no longer active, cannot accept more transactions.
        let proposal_result =
            self.get_completed_proposal_result(proposal_id).await?.expect("Proposal should exist.");
        match proposal_result {
            Ok(_) => panic!("Proposal finished validation before all transactions were sent."),
            Err(err) => match proposal_status_from(err)? {
                ProposalStatus::InvalidProposal(err) => {
                    Ok(SendTxsForProposalStatus::InvalidProposal(err))
                }
                status => {
                    error!("Unexpected batcher status for send txs for proposal: {status:?}");
                    Err(BatcherError::InternalError)
                }
            },
        }
    }

    #[instrument(skip(self), err)]
    pub async fn finish_proposal(
        &mut self,
        finish_proposal_input: FinishProposalInput,
    ) -> BatcherResult<FinishProposalStatus> {
        let FinishProposalInput { proposal_id, final_n_executed_txs } = finish_proposal_input;
        self.ensure_validate_proposal_exists(proposal_id)?;

        info!(
            "BATCHER_FIN_VALIDATOR: Finish proposal for {}. n_txs: {}",
            proposal_id, final_n_executed_txs
        );

        self.validate_tx_streams.remove(&proposal_id).expect("validate tx stream should exist.");
        if self.is_active(proposal_id).await {
            self.await_active_proposal(final_n_executed_txs).await?;
        }

        let proposal_result =
            self.get_completed_proposal_result(proposal_id).await?.expect("Proposal should exist.");
        let response = match proposal_result {
            Ok(info) => FinishProposalStatus::Finished(info),
            Err(err) => match proposal_status_from(err)? {
                ProposalStatus::InvalidProposal(err) => FinishProposalStatus::InvalidProposal(err),
                status => {
                    error!("Unexpected batcher status for finish proposal: {status:?}");
                    return Err(BatcherError::InternalError);
                }
            },
        };
        Ok(response)
    }

    #[instrument(skip(self), err)]
    pub async fn abort_proposal(&mut self, proposal_id: ProposalId) -> BatcherResult<()> {
        self.ensure_validate_proposal_exists(proposal_id)?;

        if self.is_active(proposal_id).await {
            self.abort_active_proposal().await;

            let proposal_already_exists = self
                .executed_proposals
                .lock()
                .await
                .insert(proposal_id, Err(Arc::new(BlockBuilderError::Aborted)));
            assert!(proposal_already_exists.is_none(), "Duplicate proposal: {proposal_id}.");
        }
        self.validate_tx_streams.remove(&proposal_id);
        Ok(())
    }

    fn ensure_validate_proposal_exists(&self, proposal_id: ProposalId) -> BatcherResult<()> {
        if self.validate_tx_streams.contains_key(&proposal_id) {
            Ok(())
        } else {
            Err(BatcherError::ProposalNotFound { proposal_id })
        }
    }

    fn get_height_from_storage(&self) -> BatcherResult<BlockNumber> {
        self.storage_reader.state_diff_height().map_err(|err| {
            error!("Failed to get height from storage: {}", err);
            BatcherError::InternalError
        })
    }

    /// Returns the block info of the given committed block. Sourced from its block hash components
    /// rather than its header, because nothing writes headers to the batcher's storage.
    pub(crate) fn get_block_info(&self, block_number: BlockNumber) -> BatcherResult<BlockInfo> {
        let block_hash_components = self
            .storage_reader
            .get_partial_block_hash_components(block_number)
            .map_err(|err| {
                warn!(
                    "Failed to get the block hash components of committed block {block_number}: \
                     {err}"
                );
                BatcherError::InternalError
            })?
            .ok_or_else(|| {
                // Only a block committed before block hash components existed lacks them.
                warn!("Committed block {block_number} has no block hash components stored.");
                BatcherError::ContractCallFailed {
                    reason: format!(
                        "No block info stored for committed block {block_number}, so no block \
                         context can be built for it."
                    ),
                }
            })?;

        // A price of zero is floored rather than rejected: it would fail a view call, which charges
        // no fee, over a price it never spends.
        let convert_price = |price: GasPrice| -> NonzeroGasPrice {
            NonzeroGasPrice::new(price).unwrap_or(NonzeroGasPrice::MIN)
        };

        Ok(BlockInfo {
            block_number: block_hash_components.block_number,
            block_timestamp: block_hash_components.timestamp,
            sequencer_address: block_hash_components.sequencer.0,
            gas_prices: GasPrices {
                eth_gas_prices: GasPriceVector {
                    l1_gas_price: convert_price(block_hash_components.l1_gas_price.price_in_wei),
                    l1_data_gas_price: convert_price(
                        block_hash_components.l1_data_gas_price.price_in_wei,
                    ),
                    l2_gas_price: convert_price(block_hash_components.l2_gas_price.price_in_wei),
                },
                strk_gas_prices: GasPriceVector {
                    l1_gas_price: convert_price(block_hash_components.l1_gas_price.price_in_fri),
                    l1_data_gas_price: convert_price(
                        block_hash_components.l1_data_gas_price.price_in_fri,
                    ),
                    l2_gas_price: convert_price(block_hash_components.l2_gas_price.price_in_fri),
                },
            },
            use_kzg_da: extract_l1_da_mode_from_concatenated_counts(
                &block_hash_components.header_commitments.concatenated_counts,
            )
            .is_use_kzg_da(),
            starknet_version: block_hash_components.starknet_version,
        })
    }

    #[instrument(skip(self), err)]
    pub async fn get_height(&self) -> BatcherResult<GetHeightResponse> {
        let height = self.get_height_from_storage()?;
        Ok(GetHeightResponse { height })
    }

    /// Starts a new proposer round: aborts the previous round's proposal (the proposer flow has
    /// no other round-transition hook), rewinds any staged txs it left in the mempool, and
    /// returns the metadata for the block about to be built.
    #[instrument(skip(self), err)]
    pub async fn start_round(&mut self) -> BatcherResult<ReplayBlockMetadata> {
        self.abort_active_proposal().await;

        let mempool_client = self.mempool_client.as_ref().expect(
            "Mempool client must be present in non-validation-only mode. Unreachable code when \
             validation-only mode is enabled.",
        );
        // The rewind is a no-op in the normal flow, and repeated idempotently by propose_block.
        mempool_client.commit_block(CommitBlockArgs::default()).await.map_err(|err| {
            error!("Mempool is not ready to start a new round: {err}");
            BatcherError::NotReady
        })?;
        mempool_client.resolve_block_metadata().await.map_err(|err| {
            error!("Failed to get block metadata from mempool: {err}");
            BatcherError::InternalError
        })
    }

    #[instrument(skip(self), err)]
    pub async fn call_contract(
        &self,
        input: CallContractInput,
    ) -> BatcherResult<CallContractOutput> {
        // Acquired before any storage access or state reader setup, so a call rejected under load
        // costs nothing beyond the semaphore check.
        let view_call_permit =
            self.view_call_semaphore.clone().try_acquire_owned().map_err(|_| {
                REJECTED_VIEW_CALLS.increment(1);
                warn!(
                    "Rejecting view call, all {MAX_CONCURRENT_VIEW_CALLS} view call slots are \
                     taken."
                );
                BatcherError::ContractCallFailed { reason: TOO_MANY_VIEW_CALLS_REASON.to_string() }
            })?;

        let height = self.get_height_from_storage()?;

        // Get the block info for the latest committed block.
        let block_info = match height.prev() {
            None => BlockInfo::default(),
            Some(last_committed_block) => self.get_block_info(last_committed_block)?,
        };

        let state_reader = self.view_state_reader_factory.create(
            height,
            self.config.dynamic_config.native_classes_whitelist.clone(),
            tokio::runtime::Handle::current(),
            self.config.dynamic_config.view_call_timeout_millis,
        );
        let block_context = BlockContext::new(
            block_info,
            self.config.static_config.block_builder_config.chain_info.clone(),
            self.versioned_constants(),
            BouncerConfig::max(),
        );

        let call_task = tokio::task::spawn_blocking(move || {
            // Owned by the blocking task, so the slot is freed only when the execution ends. A
            // caller that stops waiting (the view call timeout, a dropped connection) must not
            // free a slot that a still-parked thread occupies.
            let _view_call_permit = view_call_permit;
            call_view_entry_point(
                state_reader,
                Arc::new(block_context),
                input.contract_address,
                &input.entry_point,
                Calldata::from(input.calldata),
            )
            .map(|call_info| call_info.execution.retdata.0)
        });

        // Timing out releases the batcher's request slot but does not cancel the blocking task,
        // which runs to completion on its own thread. The class manager request the task blocks
        // on is itself bounded by this same timeout (passed into the state reader above), so a
        // stalled class manager cannot pin that thread past this window and starve the blocking
        // thread pool block production also depends on.
        let view_call_timeout = self.config.dynamic_config.view_call_timeout_millis;
        let retdata = tokio::time::timeout(view_call_timeout, call_task)
            .await
            .map_err(|_| {
                error!("View call timed out after {view_call_timeout:?}.");
                BatcherError::ContractCallFailed {
                    reason: format!(
                        "Call timed out after {} seconds.",
                        view_call_timeout.as_secs()
                    ),
                }
            })?
            .map_err(|err| {
                error!("Failed to spawn blocking task for call_contract: {err}");
                BatcherError::InternalError
            })?
            .map_err(|err| BatcherError::ContractCallFailed { reason: err.to_string() })?;

        validate_retdata_length(retdata.len())?;

        Ok(CallContractOutput { retdata })
    }

    #[instrument(skip(self), err)]
    pub async fn get_proposal_content(
        &mut self,
        get_proposal_content_input: GetProposalContentInput,
    ) -> BatcherResult<GetProposalContentResponse> {
        let proposal_id = get_proposal_content_input.proposal_id;

        let tx_stream = &mut self
            .propose_tx_streams
            .get_mut(&proposal_id)
            .ok_or(BatcherError::ProposalNotFound { proposal_id })?;

        // Blocking until we have some txs to stream or the proposal is done.
        let mut txs = Vec::new();
        let n_executed_txs = tx_stream
            .recv_many(&mut txs, self.config.static_config.outstream_content_buffer_size)
            .await;

        if n_executed_txs != 0 {
            debug!("Streaming {} txs", n_executed_txs);
            return Ok(GetProposalContentResponse { content: GetProposalContent::Txs(txs) });
        }

        // Finished streaming all the transactions.
        self.propose_tx_streams.remove(&proposal_id);
        let finished_proposal_info = self
            .get_completed_proposal_result(proposal_id)
            .await?
            .expect("Proposal should exist.")
            .map_err(|err| {
                error!("Failed to get commitment: {}", err);
                BatcherError::InternalError
            })?;
        info!(
            "BATCHER_FIN_PROPOSER: Finished building proposal {proposal_id} with {} transactions.",
            finished_proposal_info.final_n_executed_txs
        );
        Ok(GetProposalContentResponse {
            content: GetProposalContent::Finished(finished_proposal_info),
        })
    }

    #[instrument(skip(self, sync_block, accessed_keys), err)]
    pub async fn add_sync_block(
        &mut self,
        sync_block: SyncBlock,
        accessed_keys: Option<AccessedKeys>,
    ) -> BatcherResult<()> {
        trace!("Received sync block: {:?}", sync_block);
        // TODO(AlonH): Use additional data from the sync block.
        let SyncBlock {
            state_diff,
            account_transaction_hashes,
            l1_transaction_hashes,
            block_header_without_hash,
            block_header_commitments,
        } = sync_block;
        let block_number = block_header_without_hash.block_number;

        let height = self.get_height_from_storage()?;
        if height != block_number {
            return Err(BatcherError::StorageHeightMarkerMismatch {
                marker_height: height,
                requested_height: block_number,
            });
        }

        if let Some(height) = self.active_height {
            info!("Aborting all work on height {} due to state sync.", height);
            self.abort_active_height().await;
        }

        let address_to_nonce = state_diff.nonces.iter().map(|(k, v)| (*k, *v)).collect();

        let storage_commitment_block_hash = if block_header_without_hash
            .starknet_version
            .has_partial_block_hash_components()
        {
            self.maybe_handle_first_block_with_partial_block_hash(
                block_header_without_hash.parent_hash,
                block_number,
            )
            .map_err(|err| {
                error!("Error handling block number {block_number} with partial block hash: {err}");
                BatcherError::InternalError
            })?;
            match block_header_commitments {
                Some(header_commitments) => {
                    StorageCommitmentBlockHash::Partial(PartialBlockHashComponents {
                        header_commitments,
                        block_number,
                        l1_gas_price: block_header_without_hash.l1_gas_price,
                        l1_data_gas_price: block_header_without_hash.l1_data_gas_price,
                        l2_gas_price: block_header_without_hash.l2_gas_price,
                        sequencer: block_header_without_hash.sequencer,
                        timestamp: block_header_without_hash.timestamp,
                        starknet_version: block_header_without_hash.starknet_version,
                    })
                }
                None => return Err(BatcherError::MissingHeaderCommitments { block_number }),
            }
        } else {
            let first_block_with_partial_block_hash_number = self
                .config
                .static_config
                .first_block_with_partial_block_hash
                .as_ref()
                .expect(
                    "Since an old block was learned via sync, first block with partial block hash \
                     components should be configured.",
                )
                .block_number;
            assert!(
                height < first_block_with_partial_block_hash_number,
                "Height {height} is at least the first block configured to include a partial hash \
                 ({first_block_with_partial_block_hash_number}) but does not include one.",
            );
            StorageCommitmentBlockHash::ParentHash(block_header_without_hash.parent_hash)
        };

        let optional_state_diff_commitment = match &storage_commitment_block_hash {
            StorageCommitmentBlockHash::ParentHash(_) => None,
            StorageCommitmentBlockHash::Partial(PartialBlockHashComponents {
                ref header_commitments,
                ..
            }) => Some(header_commitments.state_diff_commitment),
        };

        self.commit_proposal_and_block(
            height,
            state_diff.clone(),
            address_to_nonce,
            l1_transaction_hashes.iter().copied().collect(),
            Default::default(),
            storage_commitment_block_hash,
            accessed_keys.as_ref(),
        )
        .await?;

        self.write_commitment_results_and_add_new_task(
            height,
            state_diff,
            optional_state_diff_commitment,
            accessed_keys,
        )
        .await?;

        LAST_SYNCED_BLOCK_HEIGHT.set_lossy(block_number.0);
        SYNCED_TRANSACTIONS.increment(
            (account_transaction_hashes.len() + l1_transaction_hashes.len()).try_into().unwrap(),
        );
        Ok(())
    }

    #[instrument(skip(self), err)]
    pub async fn decision_reached(
        &mut self,
        input: DecisionReachedInput,
    ) -> BatcherResult<DecisionReachedResponse> {
        let height = self.active_height.ok_or(BatcherError::NoActiveHeight)?;

        let proposal_id = input.proposal_id;
        let proposal_result = self.executed_proposals.lock().await.remove(&proposal_id);
        let block_execution_artifacts = proposal_result
            .ok_or(BatcherError::ExecutedProposalNotFound { proposal_id })?
            .map_err(|err| {
                error!("Failed to get block execution artifacts: {}", err);
                BatcherError::InternalError
            })?;
        let state_diff = block_execution_artifacts.thin_state_diff();
        let n_txs = u64::try_from(block_execution_artifacts.tx_hashes().len())
            .expect("Number of transactions should fit in u64");
        let n_rejected_txs =
            u64::try_from(block_execution_artifacts.execution_data.rejected_tx_hashes.len())
                .expect("Number of rejected transactions should fit in u64");
        let n_reverted_count = u64::try_from(
            block_execution_artifacts
                .execution_data
                .execution_infos_and_signatures
                .values()
                .filter(|(info, _)| info.revert_error.is_some())
                .count(),
        )
        .expect("Number of reverted transactions should fit in u64");
        let partial_block_hash_components =
            block_execution_artifacts.partial_block_hash_components();
        let state_diff_commitment =
            partial_block_hash_components.header_commitments.state_diff_commitment;
        let parent_proposal_commitment = self.get_parent_proposal_commitment(height)?;
        let accessed_keys = self.build_block_accessed_keys(&block_execution_artifacts);

        self.commit_proposal_and_block(
            height,
            state_diff.clone(),
            block_execution_artifacts.address_to_nonce(),
            block_execution_artifacts.execution_data.consumed_l1_handler_tx_hashes,
            block_execution_artifacts.execution_data.rejected_tx_hashes,
            StorageCommitmentBlockHash::Partial(partial_block_hash_components),
            Some(&accessed_keys),
        )
        .await?;

        let (tx_hashes, tx_execution_infos): (Vec<TransactionHash>, Vec<TransactionExecutionInfo>) =
            block_execution_artifacts
                .execution_data
                .execution_infos_and_signatures
                .into_iter()
                .map(|(tx_hash, (info, _))| (tx_hash, info))
                .unzip();

        // The OS only needs the read values for the keys it accesses; drop the extra reads (e.g.
        // reverted-tx reads).
        let initial_reads = {
            let mut initial_reads = block_execution_artifacts.initial_reads;
            initial_reads.trim_to_accessed_keys(&accessed_keys);
            initial_reads
        };

        self.write_commitment_results_and_add_new_task(
            height,
            state_diff.clone(), // TODO(Nimrod): Remove the clone here.
            Some(state_diff_commitment),
            Some(accessed_keys),
        )
        .await?;

        let execution_infos = tx_hashes.into_iter().zip(tx_execution_infos.into_iter()).collect();

        LAST_BATCHED_BLOCK_HEIGHT.set_lossy(height.0);
        BATCHED_TRANSACTIONS.increment(n_txs);
        REJECTED_TRANSACTIONS.increment(n_rejected_txs);
        REVERTED_TRANSACTIONS.increment(n_reverted_count);
        NUM_TRANSACTION_IN_BLOCK.record_lossy(n_txs);
        SIERRA_GAS_IN_LAST_BLOCK.set_lossy(block_execution_artifacts.bouncer_weights.sierra_gas.0);
        PROVING_GAS_IN_LAST_BLOCK
            .set_lossy(block_execution_artifacts.bouncer_weights.proving_gas.0);
        L2_GAS_IN_LAST_BLOCK.set_lossy(block_execution_artifacts.l2_gas_used.0);

        Ok(DecisionReachedResponse {
            state_diff,
            central_objects: CentralObjects {
                execution_infos,
                bouncer_weights: block_execution_artifacts.bouncer_weights,
                compressed_state_diff: block_execution_artifacts.compressed_state_diff,
                casm_hash_computation_data_sierra_gas: block_execution_artifacts
                    .casm_hash_computation_data_sierra_gas,
                casm_hash_computation_data_proving_gas: block_execution_artifacts
                    .casm_hash_computation_data_proving_gas,
                compiled_class_hashes_for_migration: block_execution_artifacts
                    .compiled_class_hashes_for_migration,
                parent_proposal_commitment,
                initial_reads,
            },
        })
    }

    /// Builds the accessed keys for the block.
    fn build_block_accessed_keys(
        &self,
        block_execution_artifacts: &BlockExecutionArtifacts,
    ) -> AccessedKeys {
        AccessedKeys::new(
            block_execution_artifacts
                .execution_data
                .execution_infos_and_signatures
                .values()
                .map(|(execution_info, _signature)| execution_info),
            block_execution_artifacts.execution_data.proof_facts_block_numbers.values(),
            &block_execution_artifacts.commitment_state_diff,
            &self.versioned_constants(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    async fn commit_proposal_and_block(
        &mut self,
        height: BlockNumber,
        state_diff: ThinStateDiff,
        address_to_nonce: HashMap<ContractAddress, Nonce>,
        consumed_l1_handler_tx_hashes: IndexSet<TransactionHash>,
        rejected_tx_hashes: IndexSet<TransactionHash>,
        storage_commitment_block_hash: StorageCommitmentBlockHash,
        accessed_keys: Option<&AccessedKeys>,
    ) -> BatcherResult<()> {
        info!(
            "Committing block at height {} and notifying mempool & L1 event provider of the block.",
            height
        );
        trace!("Rejected transactions: {:#?}, State diff: {:#?}.", rejected_tx_hashes, state_diff);

        // Proposal commitment is the the partial block hash when it's available, and None
        // otherwise. The commitment is computed here to set the prev_proposal_commitment cache. As
        // this cache is only used for blocks obtained through the decision_reached flow, it can
        // be None for old (pre 0.13.2) blocks.
        let proposal_commitment = match &storage_commitment_block_hash {
            StorageCommitmentBlockHash::Partial(components) => Some((
                height,
                ProposalCommitment {
                    partial_block_hash: PartialBlockHash::from_partial_block_hash_components(
                        components,
                    )
                    .map_err(|e| {
                        error!("Failed to compute partial block hash: {}", e);
                        BatcherError::InternalError
                    })?,
                },
            )),
            StorageCommitmentBlockHash::ParentHash(_) => None,
        };

        // Commit the proposal to the storage.
        self.storage_writer
            .commit_proposal(height, state_diff, storage_commitment_block_hash, accessed_keys)
            .map_err(|err| {
                error!("Failed to commit proposal to storage: {}", err);
                BatcherError::InternalError
            })?;
        info!("Successfully committed proposal for block {} to storage.", height);

        self.prev_proposal_commitment = proposal_commitment;

        // Notify the L1 provider of the new block.
        let rejected_l1_handler_tx_hashes = rejected_tx_hashes
            .iter()
            .copied()
            .filter(|tx_hash| consumed_l1_handler_tx_hashes.contains(tx_hash))
            .collect();

        let l1_events_provider_result = self
            .l1_events_provider_client
            .commit_block(consumed_l1_handler_tx_hashes, rejected_l1_handler_tx_hashes, height)
            .await;

        // Return error if the commit to the L1 provider failed.
        if let Err(err) = l1_events_provider_result {
            match err {
                L1EventsProviderClientError::L1EventsProviderError(
                    L1EventsProviderError::UnexpectedHeight { expected_height, got },
                ) => {
                    error!(
                        "Unexpected height while committing block in L1 provider: expected={:?}, \
                         got={:?}",
                        expected_height, got
                    );
                }
                other_err => {
                    error!(
                        "Unexpected error while committing block in L1 provider: {:?}",
                        other_err
                    );
                }
            }
            BATCHER_L1_EVENTS_PROVIDER_ERRORS.increment(1);
        }

        // Notify the mempool of the new block (skipped in validation-only mode).
        if let Some(mempool_client) = &self.mempool_client {
            let mempool_result = mempool_client
                .commit_block(CommitBlockArgs { address_to_nonce, rejected_tx_hashes })
                .await;
            if let Err(mempool_err) = mempool_result {
                // Recoverable error, mempool won't be updated with the new block.
                error!("Failed to commit block to mempool: {}", mempool_err);
            }
        }

        BUILDING_HEIGHT.increment(1);
        Ok(())
    }

    async fn is_active(&self, proposal_id: ProposalId) -> bool {
        *self.active_proposal.lock().await == Some(proposal_id)
    }

    // Sets a new active proposal task.
    // Fails if there is another proposal being currently generated, or a proposal with the same ID
    // already exists.
    async fn set_active_proposal(&mut self, proposal_id: ProposalId) -> BatcherResult<()> {
        if self.executed_proposals.lock().await.contains_key(&proposal_id) {
            return Err(BatcherError::ProposalAlreadyExists { proposal_id });
        }

        let mut active_proposal = self.active_proposal.lock().await;
        if let Some(active_proposal_id) = *active_proposal {
            return Err(BatcherError::AnotherProposalInProgress {
                active_proposal_id,
                new_proposal_id: proposal_id,
            });
        }

        // The caller logs the same proposal id at info immediately after this returns.
        trace!("Set proposal {} as the one being generated.", proposal_id);
        *active_proposal = Some(proposal_id);
        Ok(())
    }

    // Starts a new block proposal generation task for the given proposal_id.
    // Uses the given block_builder to generate the proposal.
    async fn spawn_proposal(
        &mut self,
        proposal_id: ProposalId,
        mut block_builder: Box<dyn BlockBuilderTrait>,
        abort_signal_sender: tokio::sync::oneshot::Sender<()>,
        final_n_executed_txs_sender: Option<tokio::sync::oneshot::Sender<usize>>,
        pre_confirmed_block_writer: Option<Box<dyn PreconfirmedBlockWriterTrait>>,
        mut proposal_metrics_handle: ProposalMetricsHandle,
    ) -> BatcherResult<()> {
        self.set_active_proposal(proposal_id).await?;
        info!("Starting generation of a new proposal with id {}.", proposal_id);

        let active_proposal = self.active_proposal.clone();
        let executed_proposals = self.executed_proposals.clone();

        let execution_join_handle = tokio::spawn(
            async move {
                let result = match block_builder.build_block().await {
                    Ok(artifacts) => {
                        proposal_metrics_handle.set_succeeded();
                        Ok(artifacts)
                    }
                    Err(BlockBuilderError::Aborted) => {
                        proposal_metrics_handle.set_aborted();
                        Err(BlockBuilderError::Aborted)
                    }
                    Err(e) => Err(e),
                }
                .map_err(Arc::new);

                // The proposal is done, clear the active proposal.
                // Keep the proposal result only if it is the same as the active proposal.
                // The active proposal might have changed if this proposal was aborted.
                let mut active_proposal = active_proposal.lock().await;
                if *active_proposal == Some(proposal_id) {
                    active_proposal.take();

                    log_txs_execution_result(proposal_id, &result);

                    let proposal_already_exists =
                        executed_proposals.lock().await.insert(proposal_id, result);
                    assert!(
                        proposal_already_exists.is_none(),
                        "Duplicate proposal: {proposal_id}."
                    );
                }
            }
            .in_current_span(),
        );

        let writer_join_handle =
            pre_confirmed_block_writer.map(|mut pre_confirmed_block_writer| {
                tokio::spawn(async move {
                    pre_confirmed_block_writer.run().await;
                })
            });

        self.active_proposal_task = Some(ProposalTask {
            abort_signal_sender,
            final_n_executed_txs_sender,
            execution_join_handle,
            writer_join_handle,
        });
        Ok(())
    }

    // Returns a completed proposal result, either its FinishedProposalInfo or an error if the
    // proposal failed. If the proposal doesn't exist, or it's still active, returns None.
    async fn get_completed_proposal_result(
        &self,
        proposal_id: ProposalId,
    ) -> BatcherResult<Option<ProposalResult<FinishedProposalInfo>>> {
        let guard = self.executed_proposals.lock().await;
        let artifact_derived = match guard.get(&proposal_id) {
            Some(Ok(artifacts)) => finished_proposal_info_from_artifacts(artifacts),
            Some(Err(e)) => return Ok(Some(Err(e.clone()))),
            None => return Ok(None),
        };
        let parent_proposal_commitment = match self.active_height {
            None => None,
            Some(height) => self.get_parent_proposal_commitment(height)?,
        };
        Ok(Some(Ok(FinishedProposalInfo::new(artifact_derived, parent_proposal_commitment))))
    }

    // Ends the current active proposal.
    // This call is non-blocking.
    async fn abort_active_proposal(&mut self) {
        self.active_proposal.lock().await.take();
        if let Some(proposal_task) = self.active_proposal_task.take() {
            proposal_task.abort_signal_sender.send(()).ok();
        }
    }

    /// If the optional configuration
    /// [`apollo_batcher_config::config::BatcherStaticConfig::first_block_with_partial_block_hash`]
    /// is set, and the given height is the first block with partial block hash components, we
    /// will set the parent hash of this block and verify the configured value.
    /// Assumption: we call this function only for new blocks.
    fn maybe_handle_first_block_with_partial_block_hash(
        &mut self,
        parent_block_hash_from_sync: BlockHash,
        height: BlockNumber,
    ) -> StorageResult<()> {
        let Some(FirstBlockWithPartialBlockHash { block_number, parent_block_hash, .. }) =
            self.config.static_config.first_block_with_partial_block_hash.as_ref()
        else {
            // No config is set, nothing to do.
            return Ok(());
        };
        assert!(
            height >= *block_number,
            "Block number {height} is a new block but is older than the configured first block \
             with partial block hash components {block_number}"
        );
        if height > *block_number {
            // Config is set but given height is not the first new block - nothing to do.
            return Ok(());
        }
        // Sanity check: verify that the parent block hash from sync matches the configured one.
        assert_eq!(
            *parent_block_hash, parent_block_hash_from_sync,
            "The parent block hash from sync ({parent_block_hash_from_sync:?}) does not match the \
             configured parent block hash ({parent_block_hash:?}) of the first new block"
        );

        info!(
            "The first block with partial block hash components ({block_number}) has been \
             reached. Subsequent blocks will include partial block hash components."
        );

        // Set the parent hash of the first block with partial block hash components.
        let parent_block_number = block_number
            .prev()
            .expect("First block with partial block hash should not be the genesis block.");
        self.storage_writer.set_block_hash(parent_block_number, *parent_block_hash)
    }

    pub async fn await_active_proposal(
        &mut self,
        final_n_executed_txs: usize,
    ) -> BatcherResult<()> {
        if let Some(ProposalTask {
            execution_join_handle,
            writer_join_handle,
            final_n_executed_txs_sender,
            ..
        }) = self.active_proposal_task.take()
        {
            if let Some(final_n_executed_txs_sender) = final_n_executed_txs_sender {
                final_n_executed_txs_sender.send(final_n_executed_txs).map_err(|err| {
                    error!(
                        "Failed to send final_n_executed_txs ({final_n_executed_txs}) to the tx \
                         provider: {}",
                        err
                    );
                    BatcherError::InternalError
                })?;
            }

            let writer_future = writer_join_handle
                .map(FutureExt::boxed)
                .unwrap_or_else(|| futures::future::ready(Ok(())).boxed());
            let _ = tokio::join!(execution_join_handle, writer_future);
        }

        Ok(())
    }

    #[instrument(skip(self), err)]
    // This function will panic if there is a storage failure to revert the block.
    pub async fn revert_block(&mut self, input: RevertBlockInput) -> BatcherResult<()> {
        info!("Reverting block at height {}.", input.height);
        let height = self.get_height_from_storage()?.prev().ok_or(
            BatcherError::StorageHeightMarkerMismatch {
                marker_height: BlockNumber(0),
                requested_height: input.height,
            },
        )?;

        if height != input.height {
            return Err(BatcherError::StorageHeightMarkerMismatch {
                marker_height: height.unchecked_next(),
                requested_height: input.height,
            });
        }

        if let Some(height) = self.active_height {
            info!("Aborting all work on height {} due to a revert request.", height);
            self.abort_active_height().await;
        }

        // Wait for the revert commitment to be completed before reverting the storage.
        self.revert_commitment(height).await;

        self.storage_writer.revert_block(height);
        BUILDING_HEIGHT.decrement(1);
        GLOBAL_ROOT_HEIGHT.decrement(1);
        REVERTED_BLOCKS.increment(1);
        Ok(())
    }

    // Returns the proposal commitment of the previous height.
    // NOTE: Assumes that the previous height was committed to the storage.
    fn get_parent_proposal_commitment(
        &self,
        height: BlockNumber,
    ) -> BatcherResult<Option<ProposalCommitment>> {
        let Some(prev_height) = height.prev() else {
            // This is the first block, so there is no parent proposal commitment.
            return Ok(None);
        };

        match self.prev_proposal_commitment {
            Some((h, commitment)) => {
                assert_eq!(h, prev_height, "Unexpected height of parent_proposal_commitment.");
                Ok(Some(commitment))
            }
            None => {
                // Parent proposal commitment is not cached. Read partial block hash
                // components from storage and compute the partial block hash.
                let (_, components) = self
                    .storage_reader
                    .get_parent_hash_and_partial_block_hash_components(prev_height)
                    .map_err(|err| {
                        error!(
                            "Failed to read partial block hash components for previous height \
                             {prev_height}: {}",
                            err
                        );
                        BatcherError::InternalError
                    })?;
                let components =
                    components.expect("Missing partial block hash components for previous height.");

                Ok(Some(ProposalCommitment {
                    partial_block_hash: PartialBlockHash::from_partial_block_hash_components(
                        &components,
                    )
                    .map_err(|e| {
                        error!("Failed to compute partial block hash: {}", e);
                        BatcherError::InternalError
                    })?,
                }))
            }
        }
    }

    /// Reverts the commitment for the given height.
    /// Adds a revert task to the commitment manager channel and waits for the result.
    /// Writes commitment results to storage and handles the revert task result.
    async fn revert_commitment(&mut self, height: BlockNumber) {
        let reversed_state_diff = self
            .storage_reader
            .reversed_state_diff(height)
            .expect("Failed to get reversed state diff from storage.");
        self.commitment_manager
            .add_revert_task(
                height,
                reversed_state_diff,
                &self.config.static_config.first_block_with_partial_block_hash,
                self.storage_reader.clone(),
                &mut self.storage_writer,
            )
            .await
            .expect("Failed to add revert task to commitment manager.");
        let (commitment_results, revert_task_result) =
            self.commitment_manager.wait_for_revert_result().await;
        self.commitment_manager
            .write_commitment_results_to_storage(
                commitment_results,
                &self.config.static_config.first_block_with_partial_block_hash,
                self.storage_reader.clone(),
                &mut self.storage_writer,
            )
            .expect("Failed to write commitment results to storage.");

        info!("Revert task result: {revert_task_result:?}");
        self.validate_revert_task_result(revert_task_result, height).await;
        info!("Reverted commitment for height {height}.");
    }

    async fn validate_revert_task_result(
        &self,
        revert_task_output: RevertTaskOutput,
        request_height_to_revert: BlockNumber,
    ) {
        assert_eq!(
            revert_task_output.height, request_height_to_revert,
            "The task output height does not match the request height."
        );

        match revert_task_output.response {
            RevertBlockResponse::RevertedTo(global_root)
            | RevertBlockResponse::AlreadyReverted(global_root) => {
                // Verify the global root matches the stored global root.
                let new_latest_height = revert_task_output
                    .height
                    .prev()
                    .expect("Can't revert before the genesis block.");
                let stored_global_root = self
                    .storage_reader
                    .global_root(new_latest_height)
                    .expect("Failed to get global root from storage.")
                    .unwrap_or_else(|| {
                        panic!("Global root is not set for height {new_latest_height}.")
                    });
                assert_eq!(
                    global_root, stored_global_root,
                    "The given global root does not match the stored global root for height \
                     {new_latest_height}."
                );
            }
            RevertBlockResponse::Uncommitted => {}
        }
    }

    pub fn get_block_hash(&mut self, block_number: BlockNumber) -> BatcherResult<BlockHash> {
        self.get_commitment_results_and_write_to_storage()?;
        let cache = &mut self.commitment_manager.recent_block_hashes_cache;

        // Try to get the block hash from the cache.
        if let Some(block_hash) = cache.get(&block_number) {
            return Ok(*block_hash);
        }

        // If the block hash is not in the cache, fetch it from storage.
        info!("Block hash of block {block_number} not found in cache, fetching from storage.");
        // TODO(Nimrod): Consider adding block-hashes cache misses metric.
        let block_hash = self
            .storage_reader
            .get_block_hash(block_number)
            .map_err(|err| {
                error!("Failed to get block hash from storage: {err}");
                BatcherError::InternalError
            })?
            .ok_or(BatcherError::BlockHashNotFound(block_number))?;
        cache.put(block_number, block_hash);
        Ok(block_hash)
    }

    pub fn get_state_commitment_infos(
        &self,
        block_number: BlockNumber,
    ) -> BatcherResult<Option<CompressedStateCommitmentInfos>> {
        self.storage_reader.get_state_commitment_infos(block_number).map_err(|err| {
            error!("Failed to get state commitment infos from storage: {err}");
            BatcherError::InternalError
        })
    }

    pub fn has_state_commitment_infos(&self, block_number: BlockNumber) -> BatcherResult<bool> {
        self.storage_reader.has_state_commitment_infos(block_number).map_err(|err| {
            error!("Failed to check state commitment infos existence in storage: {err}");
            BatcherError::InternalError
        })
    }

    fn get_commitment_results_and_write_to_storage(&mut self) -> BatcherResult<()> {
        self.commitment_manager
            .get_commitment_results_and_write_to_storage(
                &self.config.static_config.first_block_with_partial_block_hash,
                self.storage_reader.clone(),
                &mut self.storage_writer,
            )
            .map_err(|err| {
                error!("Failed to get commitment results and write to storage: {err}");
                BatcherError::InternalError
            })?;
        Ok(())
    }

    async fn write_commitment_results_and_add_new_task(
        &mut self,
        height: BlockNumber,
        state_diff: ThinStateDiff,
        optional_state_diff_commitment: Option<StateDiffCommitment>,
        accessed_keys: Option<AccessedKeys>,
    ) -> BatcherResult<()> {
        self.get_commitment_results_and_write_to_storage()?;
        self.commitment_manager
            .add_commitment_task(
                height,
                state_diff,
                optional_state_diff_commitment,
                &self.config.static_config.first_block_with_partial_block_hash,
                self.storage_reader.clone(),
                &mut self.storage_writer,
                accessed_keys,
            )
            .await
            .expect("The commitment offset unexpectedly doesn't match the given block height.");
        Ok(())
    }
}

/// Rejects a view call whose return value is too large to hand back to the caller.
pub(crate) fn validate_retdata_length(retdata_length: usize) -> BatcherResult<()> {
    if retdata_length > MAX_VIEW_CALL_RETDATA_LENGTH {
        return Err(BatcherError::ContractCallFailed {
            reason: format!(
                "Returned {retdata_length} felts, exceeding the limit of \
                 {MAX_VIEW_CALL_RETDATA_LENGTH}."
            ),
        });
    }
    Ok(())
}

/// Logs the result of the transactions execution in the proposal.
fn log_txs_execution_result(
    proposal_id: ProposalId,
    result: &Result<BlockExecutionArtifacts, Arc<BlockBuilderError>>,
) {
    if let Ok(block_artifacts) = result {
        let execution_infos = block_artifacts
            .execution_data
            .execution_infos_and_signatures
            .iter()
            .map(|(tx_hash, (info, _sig))| (tx_hash, info));
        let rejected_hashes = &block_artifacts.execution_data.rejected_tx_hashes;

        // Estimate capacity: base message + (hash + status) per transaction
        // TransactionHash is 66 chars (0x + 64 hex), status is ~12 chars, separator is 4 chars
        // Total per transaction: ~82 chars
        const CHARS_PER_TX: usize = 82;
        const BASE_CAPACITY: usize = 80; // Base message length
        let total_txs = execution_infos.len() + rejected_hashes.len();
        let estimated_capacity = BASE_CAPACITY + total_txs * CHARS_PER_TX;

        let mut log_msg = String::with_capacity(estimated_capacity);
        let _ = write!(
            &mut log_msg,
            "Finished generating proposal {} with {} transactions",
            proposal_id,
            execution_infos.len(),
        );

        for (tx_hash, info) in execution_infos {
            let status = if info.revert_error.is_some() { "Reverted" } else { "Successful" };
            let _ = write!(&mut log_msg, ", {tx_hash}: {status}");
        }

        for tx_hash in rejected_hashes {
            let _ = write!(&mut log_msg, ", {tx_hash}: Rejected");
        }

        info!("{}", log_msg);
    }
}

struct BatcherDynamicConfigProvider {
    config_manager_client: SharedConfigManagerClient,
}

#[async_trait]
impl DynamicConfigProvider for BatcherDynamicConfigProvider {
    async fn get_storage_reader_dynamic_config(
        &self,
    ) -> Result<StorageReaderServerDynamicConfig, DynamicConfigError> {
        let config = self
            .config_manager_client
            .get_batcher_dynamic_config()
            .await
            .map_err(|e| DynamicConfigError(e.to_string()))?;
        Ok(config.storage_reader_server_dynamic_config)
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn create_batcher(
    config: BatcherConfig,
    committer_client: SharedCommitterClient,
    mempool_client: Option<SharedMempoolClient>,
    l1_events_provider_client: SharedL1EventsProviderClient,
    class_manager_client: SharedClassManagerClient,
    pre_confirmed_cende_client: Arc<dyn PreconfirmedCendeClientTrait>,
    proof_manager_client: SharedProofManagerClient,
    config_manager_client: SharedConfigManagerClient,
) -> Batcher {
    let storage_reader_server_config = ServerConfig {
        static_config: config.static_config.storage_reader_server_static_config.clone(),
        dynamic_config: config.dynamic_config.storage_reader_server_dynamic_config.clone(),
    };
    let dynamic_config_provider: SharedDynamicConfigProvider =
        Arc::new(BatcherDynamicConfigProvider {
            config_manager_client: config_manager_client.clone(),
        });
    let (storage_reader, storage_writer, storage_reader_server) =
        open_storage_with_metric_and_server::<
            GenericStorageReaderServerHandler,
            StorageReaderRequest,
            StorageReaderResponse,
        >(
            config.static_config.storage.clone(),
            &BATCHER_STORAGE_OPEN_READ_TRANSACTIONS,
            storage_reader_server_config,
            dynamic_config_provider,
        )
        .expect("Failed to open batcher's storage");

    let storage_reader_server_handle = storage_reader_server.spawn();

    let execute_config = &config.static_config.block_builder_config.execute_config;
    let worker_pool = Arc::new(WorkerPool::start(execute_config));
    let pre_confirmed_block_writer_factory = Box::new(PreconfirmedBlockWriterFactory {
        config: config.static_config.pre_confirmed_block_writer_config,
        cende_client: pre_confirmed_cende_client,
    });
    // Block production and view calls share one class cache.
    let contract_class_manager =
        ContractClassManager::start(config.static_config.contract_class_manager_config.clone());
    let block_builder_factory = Box::new(BlockBuilderFactory {
        block_builder_config: config.static_config.block_builder_config.clone(),
        storage_reader: storage_reader.clone(),
        contract_class_manager: contract_class_manager.clone(),
        class_manager_client: class_manager_client.clone(),
        proof_manager_client,
        worker_pool,
    });
    let view_state_reader_factory = Box::new(StorageViewStateReaderFactory {
        storage_reader: storage_reader.clone(),
        contract_class_manager,
        class_manager_client,
    });
    let storage_reader = Arc::new(storage_reader);
    let storage_writer = Box::new(storage_writer);

    let commitment_manager = CommitmentManager::create_commitment_manager(
        &config.static_config.commitment_manager_config,
        storage_reader.clone(),
        committer_client.clone(),
    )
    .await;

    Batcher::new(
        config,
        storage_reader,
        view_state_reader_factory,
        storage_writer,
        committer_client,
        l1_events_provider_client,
        mempool_client,
        config_manager_client,
        block_builder_factory,
        pre_confirmed_block_writer_factory,
        commitment_manager,
        storage_reader_server_handle,
    )
}

#[cfg_attr(test, automock)]
pub trait BatcherStorageReader: Send + Sync {
    /// Returns the next height for which the batcher stores state diff for.
    /// This is the next height the batcher should work on (during validate/proposal).
    fn state_diff_height(&self) -> StorageResult<BlockNumber>;

    /// Returns the first height the committer has finished calculating commitments for.
    fn global_root_height(&self) -> StorageResult<BlockNumber>;

    fn global_root(&self, height: BlockNumber) -> StorageResult<Option<GlobalRoot>>;

    fn get_state_diff(&self, height: BlockNumber) -> StorageResult<Option<ThinStateDiff>>;

    /// Returns the state diff that undoes the state diff at the given height.
    /// Ignores deprecated_declared_classes.
    fn reversed_state_diff(
        &self,
        height: BlockNumber,
    ) -> apollo_storage::StorageResult<ThinStateDiff>;

    fn get_block_hash(&self, height: BlockNumber) -> StorageResult<Option<BlockHash>>;

    fn get_state_commitment_infos(
        &self,
        height: BlockNumber,
    ) -> StorageResult<Option<CompressedStateCommitmentInfos>>;

    /// Returns whether the state commitment infos for the given height are stored.
    fn has_state_commitment_infos(&self, height: BlockNumber) -> StorageResult<bool>;

    fn get_parent_hash_and_partial_block_hash_components(
        &self,
        height: BlockNumber,
    ) -> StorageResult<(Option<BlockHash>, Option<PartialBlockHashComponents>)>;

    fn get_accessed_keys(&self, height: BlockNumber) -> StorageResult<Option<AccessedKeys>>;

    fn get_partial_block_hash_components(
        &self,
        height: BlockNumber,
    ) -> StorageResult<Option<PartialBlockHashComponents>>;
}

impl BatcherStorageReader for StorageReader {
    fn state_diff_height(&self) -> StorageResult<BlockNumber> {
        self.begin_ro_txn()?.get_state_marker()
    }

    fn global_root_height(&self) -> StorageResult<BlockNumber> {
        self.begin_ro_txn()?.get_global_root_marker()
    }

    fn global_root(&self, height: BlockNumber) -> StorageResult<Option<GlobalRoot>> {
        self.begin_ro_txn()?.get_global_root(&height)
    }

    fn get_state_diff(&self, height: BlockNumber) -> StorageResult<Option<ThinStateDiff>> {
        self.begin_ro_txn()?.get_state_diff(height)
    }

    fn reversed_state_diff(
        &self,
        height: BlockNumber,
    ) -> apollo_storage::StorageResult<ThinStateDiff> {
        let state_target = StateNumber::right_before_block(height);
        let txn = self.begin_ro_txn()?;

        let ThinStateDiff {
            deployed_contracts,
            storage_diffs,
            class_hash_to_compiled_class_hash,
            nonces,
            ..
        } = txn.get_state_diff(height)?.ok_or_else(|| StorageError::MissingObject {
            object_name: "state diff".to_string(),
            height,
        })?;

        let state_reader = txn.get_state_reader()?;

        // In the following maps, set empty values to zero.
        let mut reversed_deployed_contracts = IndexMap::new();
        for contract_address in deployed_contracts.keys() {
            let class_hash =
                state_reader.get_class_hash_at(state_target, contract_address)?.unwrap_or_default();
            reversed_deployed_contracts.insert(*contract_address, class_hash);
        }

        let mut reversed_storage_diffs = IndexMap::new();
        for (contract_address, contract_diffs) in storage_diffs {
            let mut reversed_contract_diffs = IndexMap::new();
            for key in contract_diffs.keys() {
                let value = state_reader.get_storage_at(state_target, &contract_address, key)?;
                reversed_contract_diffs.insert(*key, value);
            }
            reversed_storage_diffs.insert(contract_address, reversed_contract_diffs);
        }

        let mut reversed_class_hash_to_compiled_class_hash = IndexMap::new();
        for class_hash in class_hash_to_compiled_class_hash.keys() {
            let compiled_class_hash = state_reader
                .get_compiled_class_hash_at(state_target, class_hash)?
                .unwrap_or_default();
            reversed_class_hash_to_compiled_class_hash.insert(*class_hash, compiled_class_hash);
        }

        let mut reversed_nonces = IndexMap::new();
        for contract_address in nonces.keys() {
            let nonce =
                state_reader.get_nonce_at(state_target, contract_address)?.unwrap_or_default();
            reversed_nonces.insert(*contract_address, nonce);
        }

        Ok(ThinStateDiff {
            deployed_contracts: reversed_deployed_contracts,
            storage_diffs: reversed_storage_diffs,
            class_hash_to_compiled_class_hash: reversed_class_hash_to_compiled_class_hash,
            nonces: reversed_nonces,
            deprecated_declared_classes: Default::default(),
        })
    }

    fn get_block_hash(&self, height: BlockNumber) -> StorageResult<Option<BlockHash>> {
        self.begin_ro_txn()?.get_block_hash(&height)
    }

    fn get_state_commitment_infos(
        &self,
        height: BlockNumber,
    ) -> StorageResult<Option<CompressedStateCommitmentInfos>> {
        self.begin_ro_txn()?.get_state_commitment_infos(height)
    }

    fn has_state_commitment_infos(&self, height: BlockNumber) -> StorageResult<bool> {
        self.begin_ro_txn()?.has_state_commitment_infos(height)
    }

    fn get_parent_hash_and_partial_block_hash_components(
        &self,
        height: BlockNumber,
    ) -> StorageResult<(Option<BlockHash>, Option<PartialBlockHashComponents>)> {
        let txn = self.begin_ro_txn()?;
        let parent_hash = match height.prev() {
            None => Some(BlockHash::GENESIS_PARENT_HASH),
            Some(parent_height) => txn.get_block_hash(&parent_height)?,
        };
        let partial_block_hash_components = txn.get_partial_block_hash_components(&height)?;
        Ok((parent_hash, partial_block_hash_components))
    }

    fn get_partial_block_hash_components(
        &self,
        height: BlockNumber,
    ) -> StorageResult<Option<PartialBlockHashComponents>> {
        self.begin_ro_txn()?.get_partial_block_hash_components(&height)
    }

    fn get_accessed_keys(&self, height: BlockNumber) -> StorageResult<Option<AccessedKeys>> {
        self.begin_ro_txn()?.get_accessed_keys(height)
    }
}

#[cfg_attr(test, automock)]
pub trait BatcherStorageWriter: Send + Sync {
    // Automock requires a named lifetime for references nested in generics, while clippy flags
    // it as needless.
    #[allow(clippy::needless_lifetimes)]
    fn commit_proposal<'a>(
        &mut self,
        height: BlockNumber,
        state_diff: ThinStateDiff,
        storage_commitment_block_hash: StorageCommitmentBlockHash,
        accessed_keys: Option<&'a AccessedKeys>,
    ) -> StorageResult<()>;

    fn revert_block(&mut self, height: BlockNumber);

    /// Sets the global root and block hash (unless it's None) for the given height, and persists
    /// the commitment infos (when present) in the same transaction.
    /// Increments the block hash marker by 1.
    /// Block hash is optional because for old blocks, the block hash was set separately.
    /// Commitment infos are optional for blocks that doesn't come from decision_reached flow.
    fn set_global_root_and_block_hash(
        &mut self,
        height: BlockNumber,
        global_root: GlobalRoot,
        block_hash: Option<BlockHash>,
        state_commitment_infos: Option<CompressedStateCommitmentInfos>,
    ) -> StorageResult<()>;

    fn set_block_hash(&mut self, height: BlockNumber, block_hash: BlockHash) -> StorageResult<()>;
}

impl BatcherStorageWriter for StorageWriter {
    // See the lifetime explanation on the trait method.
    #[allow(clippy::needless_lifetimes)]
    fn commit_proposal<'a>(
        &mut self,
        height: BlockNumber,
        state_diff: ThinStateDiff,
        storage_commitment_block_hash: StorageCommitmentBlockHash,
        accessed_keys: Option<&'a AccessedKeys>,
    ) -> StorageResult<()> {
        // TODO(AlonH): write casms.
        let mut txn = self.begin_rw_txn()?.append_state_diff(height, state_diff)?;
        match storage_commitment_block_hash {
            StorageCommitmentBlockHash::ParentHash(parent_block_hash) => {
                if let Some(parent_block_number) = height.prev() {
                    txn = txn.set_block_hash(&parent_block_number, parent_block_hash)?
                }
            }
            StorageCommitmentBlockHash::Partial(partial_block_hash_components) => {
                txn =
                    txn.set_partial_block_hash_components(&height, &partial_block_hash_components)?
            }
        }
        if let Some(accessed_keys) = accessed_keys {
            txn = txn.append_accessed_keys(height, accessed_keys)?;
        }
        txn.commit()
    }

    // This function will panic if there is a storage failure to revert the block.
    fn revert_block(&mut self, height: BlockNumber) {
        revert_block(self, height);
    }

    fn set_global_root_and_block_hash(
        &mut self,
        height: BlockNumber,
        global_root: GlobalRoot,
        block_hash: Option<BlockHash>,
        state_commitment_infos: Option<CompressedStateCommitmentInfos>,
    ) -> StorageResult<()> {
        info!(
            "Setting global root and block hash for height {height}. Root: {global_root:?}, Block \
             hash: {block_hash:?}, compressed commitment infos byte length: {:?}.",
            state_commitment_infos
                .as_ref()
                .map(|state_commitment_infos| state_commitment_infos.payload.0.len())
        );
        let mut txn = self
            .begin_rw_txn()?
            .set_global_root(&height, global_root)?
            .checked_increment_global_root_marker(height)?;
        if let Some(block_hash) = block_hash {
            txn = txn.set_block_hash(&height, block_hash)?;
        }
        if let Some(state_commitment_infos) = state_commitment_infos {
            txn = txn.append_state_commitment_infos(height, &state_commitment_infos)?;
        }
        txn.commit()
    }

    fn set_block_hash(&mut self, height: BlockNumber, block_hash: BlockHash) -> StorageResult<()> {
        self.begin_rw_txn()?.set_block_hash(&height, block_hash)?.commit()
    }
}

/// Factory for creating state readers used to execute view calls (e.g. call_contract).
/// Using the factory pattern allows tests to inject in-memory state readers without requiring
/// real storage infrastructure.
#[cfg_attr(test, automock)]
pub trait ViewStateReaderFactory: Send + Sync {
    /// `native_classes_whitelist` gates which classes may execute under Cairo native, and must be
    /// the one block production runs with, so a view call returns what a block would compute.
    /// The reader blocks on the class manager through `runtime`, from the blocking task the view
    /// call runs in; `class_manager_request_timeout` bounds the reader's total time waiting on
    /// the class manager (not each individual request), so a stalled class manager cannot pin the
    /// blocking task's thread past the view call's own timeout.
    fn create(
        &self,
        block_number: BlockNumber,
        native_classes_whitelist: NativeClassesWhitelist,
        runtime: tokio::runtime::Handle,
        class_manager_request_timeout: Duration,
    ) -> Box<dyn StateReader + Send>;
}

pub(crate) struct StorageViewStateReaderFactory {
    pub(crate) storage_reader: StorageReader,
    pub(crate) contract_class_manager: ContractClassManager,
    pub(crate) class_manager_client: SharedClassManagerClient,
}

impl ViewStateReaderFactory for StorageViewStateReaderFactory {
    fn create(
        &self,
        block_number: BlockNumber,
        native_classes_whitelist: NativeClassesWhitelist,
        runtime: tokio::runtime::Handle,
        class_manager_request_timeout: Duration,
    ) -> Box<dyn StateReader + Send> {
        // The batcher's storage records class declarations but never writes the definitions, so a
        // class is only readable through the class manager.
        // The deadline is computed once here rather than passing the duration into `ClassReader`,
        // so a class hash that takes several class manager requests (Casm and Sierra) is still
        // bounded by a single `class_manager_request_timeout`, not a multiple of it.
        let class_reader = Some(ClassReader {
            reader: self.class_manager_client.clone(),
            runtime,
            deadline: Some(Instant::now() + class_manager_request_timeout),
        });
        let apollo_reader = ApolloReader::new_with_class_reader(
            self.storage_reader.clone(),
            block_number,
            class_reader,
        );
        // The class cache is shared with block production, so a view call fetches and compiles only
        // the classes neither has seen yet. Its hits and misses are counted apart from block
        // production's, which view calls would otherwise dominate.
        Box::new(StateReaderAndContractManager::new_with_native_classes_whitelist(
            apollo_reader,
            self.contract_class_manager.clone(),
            native_classes_whitelist,
            Some(BATCHER_VIEW_CALL_CLASS_CACHE_METRICS),
        ))
    }
}

#[async_trait]
impl ComponentStarter for Batcher {
    async fn start(&mut self) {
        default_component_start_fn::<Self>().await;
        let storage_height = self
            .storage_reader
            .state_diff_height()
            .expect("Failed to get height from storage during batcher creation.");

        let global_root_height = self
            .storage_reader
            .global_root_height()
            .expect("Failed to get global roots height from storage during batcher creation.");

        register_metrics(storage_height, global_root_height);

        self.commitment_manager
            .add_missing_commitment_tasks(
                storage_height,
                &self.config,
                self.storage_reader.clone(),
                &mut self.storage_writer,
            )
            .await;
    }
}

/// When committing a block into storage, in `commit_proposal_and_block`, we either set the
/// parent hash for old blocks (pre 0.13.2) coming from sync, or the partial block hash components
/// for new blocks.
#[derive(Debug, PartialEq)]
pub enum StorageCommitmentBlockHash {
    ParentHash(BlockHash),
    Partial(PartialBlockHashComponents),
}

/// Builds the artifact-derived part of [`FinishedProposalInfo`]. Pass the result to
/// [`FinishedProposalInfo::new`] with the parent commitment.
pub(crate) fn finished_proposal_info_from_artifacts(
    artifacts: &BlockExecutionArtifacts,
) -> FinishedProposalInfoWithoutParent {
    FinishedProposalInfoWithoutParent {
        proposal_commitment: artifacts.commitment(),
        final_n_executed_txs: artifacts.final_n_executed_txs,
        block_header_commitments: artifacts.partial_block_hash_components().header_commitments,
        l2_gas_used: artifacts.l2_gas_used,
    }
}
