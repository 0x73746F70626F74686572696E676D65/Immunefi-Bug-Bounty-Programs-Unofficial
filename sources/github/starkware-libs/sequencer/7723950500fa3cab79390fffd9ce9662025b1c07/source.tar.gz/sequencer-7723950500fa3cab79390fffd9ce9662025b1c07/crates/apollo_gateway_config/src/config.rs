use apollo_config::behavior_mode::BehaviorMode;
use blockifier::blockifier::config::{ContractClassManagerConfig, NativeClassesWhitelist};
use blockifier::blockifier_versioned_constants::VersionedConstantsOverrides;
use blockifier::context::ChainInfo;
use serde::{Deserialize, Serialize};
use starknet_api::core::{ContractAddress, Nonce};
use starknet_types_core::felt::Felt;
use url::Url;
use validator::Validate;

use crate::compiler_version::VersionId;

const DEFAULT_BUCKET_NAME: &str = "proof-archive";

// Compiling a declared Sierra class to CASM is CPU- and memory-intensive, and it happens during
// transaction ingestion before the transaction's signature and balance are verified. Bound the
// number of compilations running concurrently to protect the node from resource exhaustion.
//
// Derivation: compilations are served by the sierracompiler instances, so the safe per-gateway
// bound is the sierracompiler fleet's headroom divided across the gateway fleet, i.e.
// `per_instance_capacity * num_sierracompiler_instances / num_gateway_instances`. Observed
// sierracompiler usage per compilation is small (memory spike ~0.75% of an instance), so a single
// instance can absorb many concurrent compilations. 40 stays well within that envelope while still
// capping the blast radius of a declare flood; retune via the formula above if the
// sierracompiler/gateway instance ratio or per-instance capacity changes.
const DEFAULT_MAX_CONCURRENT_DECLARE_COMPILATIONS: usize = 40;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize, Validate)]
pub struct GatewayStaticConfig {
    #[validate(nested)]
    pub stateless_tx_validator_config: StatelessTransactionValidatorConfig,
    #[validate(nested)]
    pub stateful_tx_validator_config: StatefulTransactionValidatorConfig,
    #[validate(nested)]
    pub contract_class_manager_config: ContractClassManagerConfig,
    pub chain_info: ChainInfo,
    pub block_declare: bool,
    pub authorized_declarer_accounts: Option<Vec<ContractAddress>>,
    /// Maximum number of Sierra-to-CASM compilations (triggered by declare transactions) allowed
    /// to run concurrently. Declares that arrive while this limit is reached are rejected
    /// immediately rather than queued.
    #[validate(range(min = 1))]
    pub max_concurrent_declare_compilations: usize,
    pub proof_archive_writer_config: ProofArchiveWriterConfig,
    pub behavior_mode: BehaviorMode,
    pub recorder_url: Url,
}

impl Default for GatewayStaticConfig {
    fn default() -> Self {
        Self {
            stateless_tx_validator_config: StatelessTransactionValidatorConfig::default(),
            stateful_tx_validator_config: StatefulTransactionValidatorConfig::default(),
            contract_class_manager_config: ContractClassManagerConfig {
                contract_cache_size: 300,
                ..Default::default()
            },
            chain_info: ChainInfo::default(),
            block_declare: false,
            authorized_declarer_accounts: None,
            max_concurrent_declare_compilations: DEFAULT_MAX_CONCURRENT_DECLARE_COMPILATIONS,
            proof_archive_writer_config: ProofArchiveWriterConfig::default(),
            behavior_mode: BehaviorMode::default(),
            recorder_url: "https://recorder_url"
                .parse()
                .expect("recorder_url must be a valid Recorder URL"),
        }
    }
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize, Validate)]
pub struct GatewayConfig {
    #[validate(nested)]
    pub dynamic_config: GatewayDynamicConfig,
    #[validate(nested)]
    pub static_config: GatewayStaticConfig,
}

impl GatewayConfig {
    pub fn is_authorized_declarer(&self, declarer_address: &ContractAddress) -> bool {
        match &self.static_config.authorized_declarer_accounts {
            Some(allowed_accounts) => allowed_accounts.contains(declarer_address),
            None => true,
        }
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize, Validate)]
pub struct GatewayDynamicConfig {
    pub native_classes_whitelist: NativeClassesWhitelist,
}

impl Default for GatewayDynamicConfig {
    fn default() -> Self {
        Self { native_classes_whitelist: NativeClassesWhitelist::All }
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize, Validate)]
pub struct StatelessTransactionValidatorConfig {
    // If true, ensures that at least one resource bound (L1, L2, or L1 data) is greater than zero.
    pub validate_resource_bounds: bool,
    // TODO(AlonH): Remove the `min_gas_price` field from this struct and use the one from the
    // versioned constants.
    pub min_gas_price: u128,
    pub max_l2_gas_amount: u64,
    pub max_calldata_length: usize,
    pub max_signature_length: usize,
    pub max_proof_size: usize,

    // Declare txs specific config.
    pub max_contract_bytecode_size: usize,
    pub max_contract_class_object_size: usize,
    pub min_sierra_version: VersionId,
    pub max_sierra_version: VersionId,

    // If true, allows transactions with non-empty proof_facts or proof fields.
    pub allow_client_side_proving: bool,
    // If true, allows proofs stamped with proof version V1.
    pub allow_proof_version_v1: bool,
    // If true, allows proofs stamped with proof version V2.
    pub allow_proof_version_v2: bool,
}

impl Default for StatelessTransactionValidatorConfig {
    fn default() -> Self {
        StatelessTransactionValidatorConfig {
            validate_resource_bounds: true,
            min_gas_price: 8_000_000_000,
            max_l2_gas_amount: 1_210_000_000,
            max_calldata_length: 5000,
            max_signature_length: 4000,
            max_contract_bytecode_size: 81920,
            max_contract_class_object_size: 4089446,
            min_sierra_version: VersionId::new(1, 1, 0),
            max_sierra_version: VersionId::new(1, 9, usize::MAX),
            allow_client_side_proving: true,
            allow_proof_version_v1: false,
            allow_proof_version_v2: true,
            max_proof_size: 480000,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, Validate, PartialEq)]
pub struct StatefulTransactionValidatorConfig {
    // If true, ensures the max L2 gas price exceeds (a configurable percentage of) the base gas
    // price of the previous block.
    pub validate_resource_bounds: bool,
    pub max_allowed_nonce_gap: u32,
    pub reject_future_declare_txs: bool,
    pub max_nonce_for_validation_skip: Nonce,
    pub versioned_constants_overrides: Option<VersionedConstantsOverrides>,
    // Minimum gas price as percentage of threshold to accept transactions.
    pub min_gas_price_percentage: u8, // E.g., 80 to require 80% of threshold.
}

impl Default for StatefulTransactionValidatorConfig {
    fn default() -> Self {
        StatefulTransactionValidatorConfig {
            validate_resource_bounds: true,
            max_allowed_nonce_gap: 200,
            reject_future_declare_txs: true,
            max_nonce_for_validation_skip: Nonce(Felt::ONE),
            min_gas_price_percentage: 100,
            versioned_constants_overrides: None,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct ProofArchiveWriterConfig {
    pub bucket_name: String,
}

impl Default for ProofArchiveWriterConfig {
    fn default() -> Self {
        Self { bucket_name: DEFAULT_BUCKET_NAME.to_string() }
    }
}

#[cfg(any(feature = "testing", test))]
impl ProofArchiveWriterConfig {
    pub fn create_for_testing() -> Self {
        // Use empty bucket name for tests to trigger mock proof writer.
        Self { bucket_name: String::new() }
    }
}
