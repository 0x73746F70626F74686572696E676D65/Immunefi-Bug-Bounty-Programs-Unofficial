use std::net::Ipv4Addr;
use std::ops::RangeInclusive;
use std::process::Command;
use std::time::Duration;

use alloy::node_bindings::NodeError as AnvilError;
use alloy::primitives::{I256, U256};
use alloy::providers::{DynProvider, Provider, ProviderBuilder};
use alloy::rpc::types::TransactionReceipt;
use alloy::sol;
use alloy::sol_types::SolValue;
use apollo_config::secrets::Sensitive;
use async_trait::async_trait;
use colored::*;
use papyrus_base_layer::ethereum_base_layer_contract::{
    EthereumBaseLayerConfig,
    EthereumBaseLayerContract,
    EthereumBaseLayerError,
    Starknet,
    StarknetL1Contract,
};
use papyrus_base_layer::{
    BaseLayerContract,
    L1BlockHeader,
    L1BlockNumber,
    L1BlockReference,
    L1Event,
};
use starknet_api::block::BlockHashAndNumber;
use starknet_api::hash::StarkHash;
use starknet_api::transaction::L1HandlerTransaction;
use tracing::info;
use url::Url;

/// Initialize an anvil instance under the default port and deploy the Starknet contract.
///
/// Usage: use this in cargo integration tests (tests under `tests/` dir), which ensure
/// sequential execution of tests and only one instance of Anvil running at once. Using Anvil in
/// unit tests is not supported and is discouraged, since unit tests should not need to run a whole
/// L1 (and they are parallelized, which creates port issues). For unit tests, prefer using
/// `ProviderBuilder::new().on_mocked_client` to mock L1.
#[derive(Debug)]
pub struct AnvilBaseLayer {
    pub anvil_provider: DynProvider,
    pub ethereum_base_layer: EthereumBaseLayerContract,
    pub port: u16,
}

impl AnvilBaseLayer {
    pub const DEFAULT_ANVIL_L1_ACCOUNT_ADDRESS: StarkHash =
        StarkHash::from_hex_unchecked("0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266");
    const DEFAULT_ANVIL_PORT: u16 = 8545;
    const DEFAULT_ANVIL_L1_DEPLOYED_ADDRESS: &str = "0x5fbdb2315678afecb367f032d93f642f64180aa3";

    /// Note: if you have port conflicts, you might have a zombie anvil instance
    /// running, but that should be impossible if using through this service, you probably have a
    /// manually triggered Anvil instance somewhere in your shell.
    pub async fn new(block_time: Option<u64>, port: Option<u16>) -> Self {
        let is_unit_test = cfg!(test);
        if is_unit_test {
            panic!(
                "Don't use Anvil in unit tests, only in integration tests defined in the \
                 integration tests crate. For unit tests, mock l1 using `alloy`'s mocked_provider \
                 interface."
            );
        }

        let error_message = format!(
"\n{}\n{}\n",
"Anvil binary not found!".bold().red(),
"Install instructions (for local development):\n
Execute from within a directory that's included in PATH, like ~/.local/bin:\n
curl -L \
 https://github.com/foundry-rs/foundry/releases/download/v1.5.1/foundry_v1.5.1_linux_amd64.tar.gz \
 | tar -xz --wildcards 'anvil'".yellow()
        );

        // We don't further inspect the output as it is irrelevant to the spawn check.
        let _output = Command::new("anvil").arg("--version").output().unwrap_or_else(|error| {
            if error.to_string().contains("No such file or directory") {
                panic!("{error_message}")
            } else {
                panic!("Failed anvil version check: {error:?}")
            }
        });
        let port = port.unwrap_or(Self::DEFAULT_ANVIL_PORT);
        let anvil_client = ProviderBuilder::new()
            .connect_anvil_with_wallet_and_config(|anvil| {
                let anvil = anvil.port(port);
                if let Some(block_time) = block_time { anvil.block_time(block_time) } else { anvil }
            })
            .unwrap_or_else(|error| match error {
                AnvilError::SpawnError(e)
                    if e.to_string().contains("No such file or directory") =>
                {
                    panic!("{error_message}")
                }
                _ => panic!("Failed to spawn Anvil: {}", error.to_string().red()),
            });

        info!("Deploying Starknet contract to Anvil with port: {}", port);
        let mut retries = 0;
        for _ in 0..100 {
            let result = Starknet::deploy(anvil_client.clone()).await;
            if result.is_ok() {
                break;
            }
            retries += 1;
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
        Starknet::deploy(anvil_client.clone()).await.unwrap_or_else(|error| {
            panic!(
                "Failed to deploy Starknet contract to Anvil on port {port} after {retries} \
                 retries: {error:?}"
            );
        });
        let config = Self::config(Self::url_static(port));
        let root_client = anvil_client.root().clone();

        let anvil_base_layer = Self {
            anvil_provider: anvil_client.erased(),
            ethereum_base_layer: EthereumBaseLayerContract::new_with_provider(config, root_client),
            port,
        };
        anvil_base_layer.initialize_mocked_starknet_contract().await;

        anvil_base_layer
    }

    pub async fn send_message_to_l2(
        &self,
        l1_handler: &L1HandlerTransaction,
    ) -> TransactionReceipt {
        send_message_to_l2(&self.ethereum_base_layer.contract, l1_handler).await
    }

    pub fn url(&self) -> Url {
        Self::url_static(self.port)
    }

    pub fn url_static(port: u16) -> Url {
        format!("http://{}:{port}", Ipv4Addr::LOCALHOST).parse().unwrap()
    }

    pub fn config(url: Url) -> EthereumBaseLayerConfig {
        EthereumBaseLayerConfig {
            starknet_contract_address: Self::DEFAULT_ANVIL_L1_DEPLOYED_ADDRESS.parse().unwrap(),
            ordered_l1_endpoint_urls: vec![url.into()],
            ..Default::default()
        }
    }

    pub async fn update_mocked_starknet_contract_state(
        &self,
        update: MockedStateUpdate,
    ) -> Result<(), EthereumBaseLayerError> {
        // Size out output in the starknet contract, most of these aren't checked in the mock.
        let mut output = vec![U256::from(0); starknet_output::HEADER_SIZE + 2];

        output[starknet_output::PREV_BLOCK_NUMBER_OFFSET] = U256::from(update.new_block_number - 1);
        output[starknet_output::NEW_BLOCK_NUMBER_OFFSET] = U256::from(update.new_block_number);
        output[starknet_output::PREV_BLOCK_HASH_OFFSET] = U256::from(update.prev_block_hash);
        output[starknet_output::NEW_BLOCK_HASH_OFFSET] = U256::from(update.new_block_hash);

        // Run eth_call first, which simulates the tx and returns errors, unlike eth_send which
        // executes without returning errors or output from the contract.
        // Note: if this fails and this is the first state update, make sure to set the previous
        // block number as 1 and the previous block hash as 0, as documented in the contract
        // initializer.
        self.ethereum_base_layer
            .contract
            .updateState(output.clone(), Default::default())
            .call()
            .await?;

        self.ethereum_base_layer
            .contract
            .updateState(output, Default::default())
            .send()
            .await
            .unwrap()
            .get_receipt()
            .await
            .unwrap();

        Ok(())
    }

    /// Initialize the mocked Starknet contract with default test values and first block number and
    /// hash as 1.
    ///
    /// Other values are boilerplate to match the offsets in the Starknet solidity contract, a
    /// better mock can remove those as well.
    /// NOTE: right now this is coupled with the conditionally compiled mocked starknet account at
    /// EthereumBaseLayer; It'd be best if it could be included here instead, but this seems
    /// nontrivial without duplicating EthereumBaseLayer, which is self-defeating for a test.
    async fn initialize_mocked_starknet_contract(&self) {
        let init_data = InitializeData {
            programHash: U256::from(1),
            configHash: U256::from(1),
            initialState: StateUpdate {
                blockNumber: I256::from_dec_str("1").unwrap(),
                ..Default::default()
            },
            ..Default::default()
        };

        let encoded_data = init_data.abi_encode();
        let builder = self.ethereum_base_layer.contract.initializeMock(encoded_data.into());
        builder.send().await.unwrap().get_receipt().await.unwrap();
    }
}

#[async_trait]
impl BaseLayerContract for AnvilBaseLayer {
    type Error = EthereumBaseLayerError;

    async fn get_proved_block_at(
        &mut self,
        l1_block: L1BlockNumber,
    ) -> Result<BlockHashAndNumber, Self::Error> {
        self.ethereum_base_layer.get_proved_block_at(l1_block).await
    }

    async fn latest_l1_block_number(&mut self) -> Result<L1BlockNumber, Self::Error> {
        self.ethereum_base_layer.latest_l1_block_number().await
    }

    async fn l1_block_at(
        &mut self,
        block_number: L1BlockNumber,
    ) -> Result<Option<L1BlockReference>, Self::Error> {
        self.ethereum_base_layer.l1_block_at(block_number).await
    }

    async fn events<'a>(
        &'a mut self,
        block_range: RangeInclusive<L1BlockNumber>,
        event_identifiers: &'a [&'a str],
    ) -> Result<Vec<L1Event>, Self::Error> {
        self.ethereum_base_layer.events(block_range, event_identifiers).await
    }

    async fn get_block_header(
        &mut self,
        block_number: L1BlockNumber,
    ) -> Result<Option<L1BlockHeader>, Self::Error> {
        self.ethereum_base_layer.get_block_header(block_number).await
    }

    async fn get_block_header_immutable(
        &self,
        block_number: L1BlockNumber,
    ) -> Result<Option<L1BlockHeader>, Self::Error> {
        self.ethereum_base_layer.get_block_header_immutable(block_number).await
    }

    // TODO(Arni): Consider deleting this function from the trait.
    async fn get_url(&self) -> Result<Sensitive<Url>, Self::Error> {
        Ok(self.ethereum_base_layer.url_iterator.get_current_url())
    }

    async fn set_provider_url(&mut self, _url: Sensitive<Url>) -> Result<(), Self::Error> {
        unimplemented!("Anvil base layer is tied to a an Anvil server, url is fixed.")
    }

    async fn cycle_provider_url(&mut self) -> Result<(), Self::Error> {
        unimplemented!("Anvil base layer is tied to a an Anvil server, url is fixed.")
    }

    async fn reset_provider_url_to_primary(&mut self) -> Result<(), Self::Error> {
        unimplemented!("Anvil base layer is tied to a an Anvil server, url is fixed.")
    }

    // Anvil is tied to a single fixed URL, so it is always on its only (primary) endpoint.
    async fn is_at_primary(&self) -> Result<bool, Self::Error> {
        Ok(true)
    }
}

/// Converts a given [L1 handler transaction](starknet_api::transaction::L1HandlerTransaction)
/// to match the interface of the given [starknet l1 contract](StarknetL1Contract), and
/// triggers the L1 entry point, which sends the message to L2.
pub async fn send_message_to_l2(
    starknet_core_contract: &StarknetL1Contract,
    l1_handler: &L1HandlerTransaction,
) -> TransactionReceipt {
    const PAID_FEE_ON_L1: U256 = U256::from_be_slice(b"paid"); // Arbitrary value.

    let l2_contract_address = l1_handler.contract_address.0.key().to_hex_string().parse().unwrap();
    let l2_entry_point = l1_handler.entry_point_selector.0.to_hex_string().parse().unwrap();

    // The calldata of an L1 handler transaction consists of the L1 sender address followed by
    // the transaction payload. We remove the sender address to extract the message
    // payload.
    let payload =
        l1_handler.calldata.0[1..].iter().map(|x| x.to_hex_string().parse().unwrap()).collect();
    let msg = starknet_core_contract.sendMessageToL2(l2_contract_address, l2_entry_point, payload);

    msg
        // Sets a non-zero fee to be paid on L1.
        .value(PAID_FEE_ON_L1)
        // Sends the transaction to the Starknet L1 contract. For debugging purposes, replace
        // `.send()` with `.call_raw()` to retrieve detailed error messages from L1.
        .send().await.expect("Transaction submission to Starknet L1 contract failed.")
        // Waits until the transaction is received on L1 and then fetches its receipt.
        .get_receipt().await.expect("Transaction was not received on L1 or receipt retrieval failed.")
}

pub struct MockedStateUpdate {
    pub new_block_number: u64,
    pub new_block_hash: u64,
    // Consider caching and auto-filling this for better UX.
    pub prev_block_hash: u64,
}

// The following structures are used with a mocked version of the Starknet L1 contract.
// This mocked contract (starknet_for_testing.json) differs from the production contract:
// - Includes an `initializeMock` function that bypasses governance requirements.
// - The `updateState` function doesn't require special permissions.
// - Removed a bunch of checks and functionality not necessary and that was difficult to mock,and
//   that are not called from the sequencer at this time.
// - Used exclusively for integration testing with Anvil.
sol! {
    #[derive(Debug, Default)]
    struct StateUpdate {
        uint256 globalRoot;
        int256 blockNumber;
        uint256 blockHash;
    }

    #[derive(Debug, Default)]
    struct InitializeData {
        uint256 programHash;
        uint256 aggregatorProgramHash;
        address verifier;
        uint256 configHash;
        StateUpdate initialState;
    }
}

/// Output offsets from the Starknet solidity contract. These correspond to `StarknetOutput`,
/// defined in the public `Output.sol` contract. These are the only offsets for values currently
/// used in the starknet contract mock, if more are needed, which isn't likely, grab the offsets
/// from Output.sol.
mod starknet_output {
    pub const PREV_BLOCK_NUMBER_OFFSET: usize = 2;
    pub const NEW_BLOCK_NUMBER_OFFSET: usize = 3;
    pub const PREV_BLOCK_HASH_OFFSET: usize = 4;
    pub const NEW_BLOCK_HASH_OFFSET: usize = 5;
    pub const HEADER_SIZE: usize = 10;
}
