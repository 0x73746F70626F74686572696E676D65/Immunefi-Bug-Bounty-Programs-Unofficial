#![cfg(any(test, feature = "testing"))]
#![allow(dead_code)]
use std::error::Error;
use std::fmt::Debug;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use std::task::Poll;
use std::time::Duration;

use alloy::primitives::{Uint, U256};
use apollo_base_layer_tests::anvil_base_layer::AnvilBaseLayer;
use apollo_infra::component_client::LocalComponentClient;
use apollo_infra::component_definitions::{ComponentStarter, RequestWrapper};
use apollo_infra::component_server::{
    ComponentServerStarter,
    LocalComponentServer,
    LocalServerConfig,
};
use apollo_infra_utils::test_utils::{AvailablePortsGenerator, TestIdentifier};
use apollo_l1_events::l1_events_provider::L1EventsProvider;
use apollo_l1_events::l1_scraper::L1EventsScraper;
use apollo_l1_events::metrics::L1_EVENTS_INFRA_METRICS;
use apollo_l1_events::{event_identifiers_to_track, L1EventsProviderConfig};
use apollo_l1_events_config::config::L1EventsScraperConfig;
use apollo_l1_events_types::{
    Event,
    L1EventsProviderClient,
    L1EventsProviderRequest,
    L1EventsProviderResponse,
    ProviderState,
};
use apollo_state_sync_types::communication::MockStateSyncClient;
use apollo_state_sync_types::state_sync_types::SyncBlock;
use apollo_time::time::Clock;
use chrono::{DateTime, Duration as ChronoDur, Utc};
use futures::{poll, FutureExt};
use papyrus_base_layer::ethereum_base_layer_contract::Starknet::LogMessageToL2;
use papyrus_base_layer::test_utils::anvil_mine_blocks;
use papyrus_base_layer::{BaseLayerContract, L1BlockHash, L1BlockNumber, L1BlockReference};
use starknet_api::block::{BlockNumber, BlockTimestamp};
use starknet_api::core::ChainId;
use starknet_api::transaction::TransactionHash;
use tokio::sync::mpsc::channel;
use tokio::time::Instant;

pub(crate) const ROUND_TO_SEC_MARGIN_DURATION: Duration = Duration::from_secs(1);
pub(crate) const POLLING_INTERVAL_DURATION: Duration = Duration::from_secs(10);
pub(crate) const COOLDOWN_DURATION: Duration = Duration::from_secs(30);
pub(crate) const TIMELOCK_DURATION: Duration = Duration::from_secs(30);
pub(crate) const WAIT_FOR_ASYNC_PROCESSING_DURATION: Duration = Duration::from_millis(50);
const NUMBER_OF_BLOCKS_TO_MINE: u64 = 100;
pub(crate) const CHAIN_ID: ChainId = ChainId::Mainnet;
pub(crate) const L1_CONTRACT_ADDRESS: u64 = 1;
pub(crate) const L2_ENTRY_POINT: u64 = 34;
pub(crate) const CALL_DATA: &[u8] = &[1_u8, 2_u8];
pub(crate) const CALL_DATA_2: &[u8] = &[3_u8, 4_u8];

const START_L1_BLOCK: L1BlockReference = L1BlockReference { number: 0, hash: L1BlockHash([0; 32]) };
const START_L1_BLOCK_NUMBER: L1BlockNumber = START_L1_BLOCK.number;
pub(crate) const TARGET_L2_HEIGHT: BlockNumber = BlockNumber(1);

fn convert_call_data_to_u256(call_data: &[u8]) -> Vec<Uint<256, 4>> {
    call_data.iter().map(|x| U256::from(*x)).collect()
}

/// Setup an anvil base layer with some blocks on it.
// Need to allow dead code as this is only used in some of the test crates.
#[allow(dead_code)]
pub(crate) async fn setup_anvil_base_layer() -> AnvilBaseLayer {
    let mut ports_gen =
        AvailablePortsGenerator::new(TestIdentifier::L1EventsProviderUnitTests.into());
    let mut available_ports = ports_gen
        .next()
        .expect("Failed to get an AvailablePorts instance for L1 provider unit tests");
    let mut base_layer = AnvilBaseLayer::new(None, Some(available_ports.get_next_port())).await;
    anvil_mine_blocks(base_layer.ethereum_base_layer.config.clone(), NUMBER_OF_BLOCKS_TO_MINE)
        .await;
    // We use a really long timeout because in the tests we sometimes advance the fake time by large
    // jumps (e.g., when the runtime yields, tokio moves the fake time to the next pending timer).
    base_layer.ethereum_base_layer.config.timeout_millis = Duration::from_secs(10000);
    base_layer
}

/// Set up the scraper and provider, return a provider client.
pub(crate) async fn setup_scraper_and_provider<
    T: BaseLayerContract<Error = E> + Send + Sync + Debug + 'static,
    E: Error + Send + Sync + Debug + 'static,
>(
    base_layer: T,
    l1_events_scraper_config: Option<L1EventsScraperConfig>,
) -> LocalComponentClient<L1EventsProviderRequest, L1EventsProviderResponse> {
    let fake_clock = Arc::new(TokioLinkedClock::new());

    // Setup the state sync client.
    let mut state_sync_client = MockStateSyncClient::default();
    state_sync_client.expect_get_block().returning(move |_| Ok(SyncBlock::default()));

    // Set up the L1 provider client and server.
    // This channel connects the L1EventsProvider client to the server.
    let (tx, rx) = channel::<RequestWrapper<L1EventsProviderRequest, L1EventsProviderResponse>>(32);

    // Create the provider client.
    let l1_events_provider_client =
        LocalComponentClient::new(tx, L1_EVENTS_INFRA_METRICS.get_local_client_metrics());

    // L1 provider setup.
    let l1_events_provider_config = L1EventsProviderConfig {
        l1_handler_proposal_cooldown_seconds: COOLDOWN_DURATION,
        l1_handler_cancellation_timelock_seconds: TIMELOCK_DURATION,
        l1_handler_consumption_timelock_seconds: TIMELOCK_DURATION,
        ..Default::default()
    };
    let l1_events_provider = L1EventsProvider::new(
        l1_events_provider_config,
        Arc::new(l1_events_provider_client.clone()),
        Arc::new(state_sync_client),
        Some(fake_clock.clone()),
    );
    // Create the server.
    let mut l1_events_provider_server = LocalComponentServer::new(
        l1_events_provider,
        &LocalServerConfig::default(),
        rx,
        L1_EVENTS_INFRA_METRICS.get_local_server_metrics(),
    );
    // Start the server:
    tokio::spawn(async move {
        l1_events_provider_server.start().await;
    });

    // Set up the L1 scraper and run it as a server.
    let l1_events_scraper_config =
        l1_events_scraper_config.unwrap_or_else(|| L1EventsScraperConfig {
            polling_interval_seconds: POLLING_INTERVAL_DURATION,
            chain_id: CHAIN_ID,
            ..Default::default()
        });
    let mut scraper = L1EventsScraper::new(
        l1_events_scraper_config,
        Arc::new(l1_events_provider_client.clone()),
        base_layer,
        event_identifiers_to_track(),
    )
    .await
    .expect("Should be able to create the scraper");

    scraper.clock = fake_clock.clone();

    // Run the scraper in a separate task.
    tokio::spawn(async move {
        scraper.start().await;
    });

    // Loop around until the provider becomes initialized.
    for _ in 0..100 {
        let state = l1_events_provider_client.get_provider_state().await.unwrap();
        if state == ProviderState::Pending {
            break;
        }
        tokio::time::sleep(WAIT_FOR_ASYNC_PROCESSING_DURATION).await;
    }

    tokio::spawn(async {
        loop {
            // This tiny sleep keeps the runtime from ever being fully idle
            tokio::time::sleep(std::time::Duration::from_millis(1)).await;
        }
    });

    // Start the L1 provider's catching up process up to the target L2 height
    let expect_error =
        l1_events_provider_client.commit_block([].into(), [].into(), TARGET_L2_HEIGHT).await;
    assert!(expect_error.is_err());

    l1_events_provider_client
}

/// Send a message from L1 to L2 and return the transaction hash on L2.
// Need to allow dead code as this is only used in some of the test crates.
#[allow(dead_code)]
pub(crate) async fn send_message_from_l1_to_l2(
    base_layer: &mut AnvilBaseLayer,
    call_data: &[u8],
) -> (TransactionHash, Uint<256, 4>) {
    let last_l1_block_number =
        base_layer.ethereum_base_layer.latest_l1_block_number().await.unwrap();
    assert!(last_l1_block_number > START_L1_BLOCK_NUMBER + NUMBER_OF_BLOCKS_TO_MINE);

    // Send message from L1 to L2.
    let contract = &base_layer.ethereum_base_layer.contract;
    let call_data = convert_call_data_to_u256(call_data);
    let fee = 1_u8;
    let message_to_l2 = contract
        .sendMessageToL2(U256::from(L1_CONTRACT_ADDRESS), U256::from(L2_ENTRY_POINT), call_data)
        .value(U256::from(fee));
    let receipt = message_to_l2.send().await.unwrap().get_receipt().await.unwrap();

    let message_to_l2_event = receipt
        .decoded_log::<LogMessageToL2>()
        .expect("Failed to decode LogMessageToL2 event from transaction receipt");
    let nonce = message_to_l2_event.nonce;
    let message_timestamp = base_layer
        .get_block_header(receipt.block_number.unwrap())
        .await
        .unwrap()
        .unwrap()
        .timestamp;
    assert!(message_timestamp > BlockTimestamp(0));

    // Make sure the L1 event was posted to Anvil
    let last_l1_block_number =
        base_layer.ethereum_base_layer.latest_l1_block_number().await.unwrap();
    assert!(last_l1_block_number > START_L1_BLOCK_NUMBER + NUMBER_OF_BLOCKS_TO_MINE);
    let event_filter = event_identifiers_to_track();
    let mut events = base_layer
        .ethereum_base_layer
        .events(
            // Include last block with message.
            START_L1_BLOCK_NUMBER..=last_l1_block_number + 1,
            event_filter,
        )
        .await
        .unwrap();
    assert!(!events.is_empty());
    let l1_event = events.pop().unwrap();

    // Convert the L1 event to an Apollo event, so we can get the L2 hash.
    let l1_event_converted =
        apollo_l1_events_types::Event::from_l1_event(&CHAIN_ID, l1_event, message_timestamp.0)
            .unwrap();
    let Event::L1HandlerTransaction { l1_handler_tx, .. } = l1_event_converted else {
        panic!("L1 event converted is not a L1 handler transaction");
    };
    (l1_handler_tx.tx_hash, nonce)
}

// Need to allow dead code as this is only used in some of the test crates.
#[allow(dead_code)]
pub(crate) async fn send_cancellation_request(
    base_layer: &AnvilBaseLayer,
    call_data: &[u8],
    nonce: Uint<256, 4>,
) {
    let contract = &base_layer.ethereum_base_layer.contract;
    let call_data = convert_call_data_to_u256(call_data);
    let cancellation_request = contract.startL1ToL2MessageCancellation(
        U256::from(L1_CONTRACT_ADDRESS),
        U256::from(L2_ENTRY_POINT),
        call_data,
        nonce,
    );
    // let _receipt = cancellation_request.send().await.unwrap().get_receipt().await.unwrap();
    let mut fut = cancellation_request.send().boxed();
    let _output = fake_wait_for_future(fut.as_mut()).await;
    // If you need the receipt, put _output.get_receipt().boxed() into a new future and send that to
    // another fake_wait_for_future.
}

// Need to allow dead code as this is only used in some of the test crates.
#[allow(dead_code)]
pub(crate) async fn send_cancellation_finalization(
    base_layer: &AnvilBaseLayer,
    call_data: &[u8],
    nonce: Uint<256, 4>,
) {
    let contract = &base_layer.ethereum_base_layer.contract;
    let call_data = convert_call_data_to_u256(call_data);
    let cancellation_finalization = contract.cancelL1ToL2Message(
        U256::from(L1_CONTRACT_ADDRESS),
        U256::from(L2_ENTRY_POINT),
        call_data,
        nonce,
    );
    let mut fut = cancellation_finalization.send().boxed();
    let _output = fake_wait_for_future(fut.as_mut()).await;
    // If you need the receipt, put _output.get_receipt().boxed() into a new future and send that to
    // another fake_wait_for_future.
}

pub(crate) async fn fake_wait_for_future<T>(
    mut fut: Pin<&mut (dyn Future<Output = T> + Send)>,
) -> T {
    loop {
        match poll!(fut.as_mut()) {
            Poll::Ready(v) => break v,
            Poll::Pending => tokio::time::advance(Duration::from_millis(1)).await,
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct TokioLinkedClock {
    anchor_instant: Instant,
    anchor_datetime: DateTime<Utc>,
}

impl TokioLinkedClock {
    /// Anchor `now()` to the current real UTC time and the current Tokio instant.
    pub fn new() -> Self {
        Self { anchor_instant: Instant::now(), anchor_datetime: Utc::now() }
    }

    /// Compute UTC "now" as: anchor_datetime + (TokioInstant::now() - anchor_instant)
    fn utc_now(&self) -> DateTime<Utc> {
        let elapsed = Instant::now().saturating_duration_since(self.anchor_instant);
        self.anchor_datetime + ChronoDur::from_std(elapsed).unwrap()
    }
}

impl Clock for TokioLinkedClock {
    fn now(&self) -> DateTime<Utc> {
        self.utc_now()
    }
}
