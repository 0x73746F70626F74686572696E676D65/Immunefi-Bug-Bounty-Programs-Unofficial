use std::io::{stdout, Result as IoResult, Write};
use std::str::FromStr;

use time::macros::format_description;
use tokio::sync::OnceCell;
use tracing::metadata::LevelFilter;
use tracing::warn;
use tracing_subscriber::filter::Directive;
use tracing_subscriber::fmt::time::UtcTime;
use tracing_subscriber::prelude::*;
use tracing_subscriber::{fmt, reload, EnvFilter};

// Renames the "error" key to "message" in a JSON object, if present.
// If "message" already exists, leaves the object unchanged.
pub(crate) fn rename_error_to_message(buf: &[u8]) -> Option<Vec<u8>> {
    let mut obj: serde_json::Map<String, serde_json::Value> = serde_json::from_slice(buf).ok()?;
    if !obj.contains_key("message") {
        if let Some(v) = obj.remove("error") {
            obj.insert("message".into(), v);
        }
    }
    let mut out = serde_json::to_vec(&obj).ok()?;
    out.push(b'\n');
    Some(out)
}

// Wraps any writer to rename the "error" JSON key to "message" in log output.
// This is used because #[instrument(...,err)] emits errors in the "error" field.
pub(crate) struct ErrorToMessageWriter<W>(pub(crate) W);

impl<W: Write> Write for ErrorToMessageWriter<W> {
    fn write(&mut self, buf: &[u8]) -> IoResult<usize> {
        let len = buf.len();
        let output = rename_error_to_message(buf).unwrap_or_else(|| buf.to_vec());
        self.0.write_all(&output)?;
        Ok(len)
    }

    fn flush(&mut self) -> IoResult<()> {
        self.0.flush()
    }
}

// Crates we always keep at INFO regardless of operator-supplied spec.
const QUIET_LIBS: &[&str] = &[
    "alloy_provider",
    "alloy_rpc_client",
    "alloy_transport_http",
    "futures-util",
    "h2",
    "hickory_proto",
    "hickory_resolver",
    "hickory-proto",
    "hickory-resolver",
    "hyper_util",
    "hyper",
    "libp2p-gossipsub",
    "libp2p",
    "multistream_select",
    "netlink_proto",
    "reqwest",
    "yamux",
];

const DEFAULT_LEVEL: LevelFilter = LevelFilter::INFO;
pub(crate) type ReloadHandle = reload::Handle<EnvFilter, tracing_subscriber::Registry>;

// Define a OnceCell to ensure the configuration is initialized only once
static TRACING_INITIALIZED: OnceCell<ReloadHandle> = OnceCell::const_new();

/// Creates the JSON fmt layer with ErrorToMessageWriter wrapping.
pub(crate) fn create_fmt_layer<S, F, W>(make_writer: F) -> impl tracing_subscriber::Layer<S>
where
    S: tracing::Subscriber + for<'a> tracing_subscriber::registry::LookupSpan<'a>,
    F: Fn() -> W + Clone + Send + Sync + 'static,
    W: Write + 'static,
{
    // Use default time formatting with sub-second precision limited to three digits.
    let time_format =
        format_description!("[year]-[month]-[day]T[hour]:[minute]:[second].[subsecond digits:3]Z");
    let timer = UtcTime::new(time_format);

    fmt::layer()
        .json()
        .with_writer(make_writer)
        .map_writer(|w| move || ErrorToMessageWriter(w()))
        .with_timer(timer)
        .with_target(false) // No module name.
        // Instead, file name and line number.
        .with_file(true)
        .with_line_number(true)
        // `spans` already holds the whole span list, with the current span as its last element,
        // so also emitting `span` duplicates that data on every single log entry.
        .with_current_span(false)
        .flatten_event(true)
}

pub async fn configure_tracing() -> ReloadHandle {
    let reload_handle = TRACING_INITIALIZED
        .get_or_init(|| async {
            let fmt_layer = create_fmt_layer(stdout);

            let level_filter_layer = QUIET_LIBS.iter().fold(
                EnvFilter::builder().with_default_directive(DEFAULT_LEVEL.into()).from_env_lossy(),
                |layer, lib| layer.add_directive(format!("{lib}=info").parse().unwrap()),
            );

            // Wrap the EnvFilter in a reloadable layer so that it can be updated at runtime.
            let (filtered_layer, reload_handle) = reload::Layer::new(level_filter_layer);

            // This sets a single subscriber to all of the threads. We may want to implement
            // different subscriber for some threads and use set_global_default instead
            // of init.
            tracing_subscriber::registry().with(filtered_layer).with(fmt_layer).init();
            tracing::info!("Tracing has been successfully initialized.");

            reload_handle
        })
        .await;

    reload_handle.clone()
}

pub fn set_log_level(handle: &ReloadHandle, crate_name: &str, level: LevelFilter) {
    if let Ok(directive) = Directive::from_str(&format!("{crate_name}={level}")) {
        let _ = handle.modify(|filter| {
            *filter = std::mem::take(filter).add_directive(directive);
        });
    } else {
        warn!("{crate_name}: ignored invalid log-level directive");
    }
}

pub fn get_log_directives(handle: &ReloadHandle) -> Result<String, reload::Error> {
    handle.with_current(|f| f.to_string())
}
