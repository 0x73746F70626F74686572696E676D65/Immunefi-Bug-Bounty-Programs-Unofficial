#![cfg(any(test, feature = "testing"))]
mod utils;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

use apollo_l1_events_types::{L1EventsProviderClient, SessionState, ValidationStatus};
use apollo_time::time::Clock;
use papyrus_base_layer::{
    L1BlockHash,
    L1BlockNumber,
    L1BlockReference,
    L1Event,
    MockBaseLayerContract,
};
use starknet_api::block::{BlockNumber, BlockTimestamp};
use starknet_api::core::{ContractAddress, EntryPointSelector, Nonce};
use starknet_api::transaction::fields::{Calldata, Fee};
use starknet_api::transaction::{L1HandlerTransaction, TransactionVersion};
use starknet_types_core::felt::Felt;
use utils::{
    setup_scraper_and_provider,
    TokioLinkedClock,
    CALL_DATA,
    L1_CONTRACT_ADDRESS,
    L2_ENTRY_POINT,
    POLLING_INTERVAL_DURATION,
    ROUND_TO_SEC_MARGIN_DURATION,
    TARGET_L2_HEIGHT,
    TIMELOCK_DURATION,
};

fn block_from_number(number: L1BlockNumber) -> L1BlockReference {
    L1BlockReference { number, hash: L1BlockHash::default() }
}

fn block_timestamp(clock: Arc<TokioLinkedClock>, offset: u64) -> BlockTimestamp {
    BlockTimestamp(clock.unix_now() + offset)
}

#[tokio::test]
async fn l1_handler_tx_consumed_txs() {
    // Setup.
    let fake_clock = Arc::new(TokioLinkedClock::new());
    const OFFSET: u64 = 10;
    // Make a transaction to send from L1 to L2.
    let call_data: Vec<Felt> = CALL_DATA.iter().map(|x| Felt::from(*x)).collect();
    let l1_handler_tx = L1HandlerTransaction {
        version: TransactionVersion::default(),
        nonce: Nonce::default(),
        contract_address: ContractAddress::from(L1_CONTRACT_ADDRESS),
        entry_point_selector: EntryPointSelector(Felt::from(L2_ENTRY_POINT)),
        calldata: Calldata(call_data.into()),
    };

    // We will first send this message.
    let message_to_l2_event = L1Event::LogMessageToL2 {
        tx: l1_handler_tx.clone(),
        fee: Fee::default(),
        l1_tx_hash: None,
        block_timestamp: block_timestamp(fake_clock.clone(), 0),
    };
    // On the next time we scrape, we would find the consumed event.
    let message_consumed_event = L1Event::ConsumedMessageToL2 {
        tx: l1_handler_tx,
        timestamp: block_timestamp(fake_clock.clone(), OFFSET),
    };
    // This consumed event is sent only to trigger deletion on the provider records.
    let message_consumed_event_2 = L1Event::ConsumedMessageToL2 {
        tx: L1HandlerTransaction::default(),
        timestamp: block_timestamp(fake_clock.clone(), OFFSET * 2),
    };

    // Setup the base layer. Using a mock because we cannot actively cause a tx to be consumed
    // without a state update.
    let mut base_layer = MockBaseLayerContract::new();
    // The latest_l1_block and l1_block_at are used internally by the scraper.
    let current_l1_block_number = Arc::new(AtomicU64::new(1));
    let current_l1_block_number_clone = current_l1_block_number.clone();
    base_layer
        .expect_latest_l1_block_number()
        .returning(move || Ok(current_l1_block_number_clone.load(Ordering::Relaxed)));
    base_layer
        .expect_l1_block_at()
        .returning(move |block_number| Ok(Some(block_from_number(block_number))));

    // First we get the message sent. Then we get the consumed event (should be scraped on the
    // second iteration of the scraper loop). On the third iteration, we get the second consumed
    // event (to trigger deletion on the provider records).
    let all_events = [
        message_to_l2_event.clone(),
        message_consumed_event.clone(),
        message_consumed_event_2.clone(),
    ];
    base_layer.expect_events().returning(move |range, _identifiers| {
        // Subtract one because event at place 0 is for block number 1, etc.
        let start = usize::try_from(*range.start()).unwrap_or(0).saturating_sub(1);
        let end_exclusive = usize::try_from(*range.end()).unwrap_or(0).min(all_events.len());
        Ok(all_events[start..end_exclusive].to_vec())
    });

    let l1_events_provider_client = setup_scraper_and_provider(base_layer, None).await;

    tokio::time::pause();
    let snapshot = l1_events_provider_client.get_l1_events_provider_snapshot().await.unwrap();
    assert!(!snapshot.uncommitted_transactions.is_empty());
    assert_eq!(snapshot.number_of_txs_in_records, 1);
    let l2_hash = snapshot.uncommitted_transactions[0];

    // Test.
    let next_block_height = BlockNumber(TARGET_L2_HEIGHT.0 + 1);

    // Check that we can validate this message.
    l1_events_provider_client.start_block(SessionState::Validate, next_block_height).await.unwrap();
    assert_eq!(
        l1_events_provider_client.validate(l2_hash, next_block_height).await.unwrap(),
        ValidationStatus::Validated
    );

    // Block number 2 is created.
    current_l1_block_number.store(2, Ordering::Relaxed);
    // Sleep at least one second more than the polling interval to make sure we are not failing due
    // to fractional seconds. After the polling interval passes, the transaction should be
    // consumed.
    tokio::time::advance(POLLING_INTERVAL_DURATION + ROUND_TO_SEC_MARGIN_DURATION).await;

    for _i in 0..100 {
        let snapshot = l1_events_provider_client.get_l1_events_provider_snapshot().await.unwrap();
        // The transaction is consumed, but still in the records.
        if !snapshot.consumed.is_empty() {
            break;
        }
        tokio::time::sleep(Duration::from_millis(1)).await;
    }

    let snapshot = l1_events_provider_client.get_l1_events_provider_snapshot().await.unwrap();
    // The transaction is consumed, but still in the records.
    assert!(!snapshot.consumed.is_empty());
    assert_eq!(snapshot.number_of_txs_in_records, 1);

    // Block number 3 is created.
    current_l1_block_number.store(3, Ordering::Relaxed);
    // Wait again to make sure the consumption timelock has passed, allowing a deletion to occur.
    tokio::time::advance(TIMELOCK_DURATION + ROUND_TO_SEC_MARGIN_DURATION).await;

    // Scraping the second consumed event triggers a deletion of the transaction from the records.
    for _i in 0..100 {
        let snapshot = l1_events_provider_client.get_l1_events_provider_snapshot().await.unwrap();
        if snapshot.consumed.is_empty() {
            break;
        }
        tokio::time::sleep(Duration::from_millis(1)).await;
    }

    let snapshot = l1_events_provider_client.get_l1_events_provider_snapshot().await.unwrap();
    assert!(snapshot.consumed.is_empty());
    assert_eq!(snapshot.number_of_txs_in_records, 0);
}
