use std::fmt::Display;

#[cfg(any(feature = "testing", test))]
use enum_iterator::Sequence;
use serde::de::Error;
use serde::{Deserialize, Deserializer, Serialize};
use starknet_api::transaction::fields::TransactionSignature;
use tracing::error;

/// Error codes returned by the starknet gateway.
#[derive(Clone, Debug, Deserialize, Serialize, Eq, PartialEq)]
#[serde(untagged)]
pub enum StarknetErrorCode {
    #[serde(deserialize_with = "deserialize_unknown_error_code")]
    UnknownErrorCode(String),
    KnownErrorCode(KnownStarknetErrorCode),
}

// This struct is needed because #[serde(other)] supports only unit variants and because
// #[serde(field_identifier)] doesn't work with serializable types.
// The issue requesting that #[serde(other)] will deserialize the variant with the unknown tag's
// content is: https://github.com/serde-rs/serde/issues/1701
#[derive(Clone, Debug, Deserialize, Serialize, Eq, PartialEq)]
#[cfg_attr(any(test, feature = "testing"), derive(Sequence))]
pub enum KnownStarknetErrorCode {
    #[serde(rename = "StarknetErrorCode.UNDECLARED_CLASS")]
    UndeclaredClass,
    #[serde(rename = "StarknetErrorCode.BLOCK_NOT_FOUND")]
    BlockNotFound,
    #[serde(rename = "StarkErrorCode.MALFORMED_REQUEST")]
    MalformedRequest,
    #[serde(rename = "StarknetErrorCode.OUT_OF_RANGE_CLASS_HASH")]
    OutOfRangeClassHash,
    #[serde(rename = "StarknetErrorCode.CLASS_ALREADY_DECLARED")]
    ClassAlreadyDeclared,
    #[serde(rename = "StarknetErrorCode.COMPILATION_FAILED")]
    CompilationFailed,
    #[serde(rename = "StarknetErrorCode.CONTRACT_BYTECODE_SIZE_TOO_LARGE")]
    ContractBytecodeSizeTooLarge,
    #[serde(rename = "StarknetErrorCode.CONTRACT_CLASS_OBJECT_SIZE_TOO_LARGE")]
    ContractClassObjectSizeTooLarge,
    #[serde(rename = "StarknetErrorCode.DUPLICATED_TRANSACTION")]
    DuplicatedTransaction,
    #[serde(rename = "StarknetErrorCode.ENTRY_POINT_NOT_FOUND_IN_CONTRACT")]
    EntryPointNotFoundInContract,
    #[serde(rename = "StarknetErrorCode.INSUFFICIENT_ACCOUNT_BALANCE")]
    InsufficientAccountBalance,
    #[serde(rename = "StarknetErrorCode.INSUFFICIENT_MAX_FEE")]
    InsufficientMaxFee,
    #[serde(rename = "StarknetErrorCode.INVALID_COMPILED_CLASS_HASH")]
    InvalidCompiledClassHash,
    #[serde(rename = "StarknetErrorCode.INVALID_CONTRACT_CLASS_VERSION")]
    InvalidContractClassVersion,
    #[serde(rename = "StarknetErrorCode.INVALID_TRANSACTION_NONCE")]
    InvalidTransactionNonce,
    #[serde(rename = "StarknetErrorCode.INVALID_TRANSACTION_VERSION")]
    InvalidTransactionVersion,
    #[serde(rename = "StarknetErrorCode.VALIDATE_FAILURE")]
    ValidateFailure,
    #[serde(rename = "StarknetErrorCode.TRANSACTION_LIMIT_EXCEEDED")]
    TransactionLimitExceeded,
    #[serde(rename = "StarknetErrorCode.UNAUTHORIZED_DECLARE")]
    UnauthorizedDeclare,
    #[serde(rename = "StarknetErrorCode.INVALID_PROOF")]
    InvalidProof,
}

/// A client error wrapping error codes returned by the starknet gateway.
#[derive(thiserror::Error, Clone, Debug, Deserialize, Serialize, Eq, PartialEq)]
pub struct StarknetError {
    pub code: StarknetErrorCode,
    pub message: String,
}

impl StarknetError {
    pub fn internal_with_logging(log_message: &str, err: impl std::error::Error) -> Self {
        error!("Internal error: {log_message}: {err}.");
        Self { code: Self::internal_error_code(), message: "Internal error".to_string() }
    }

    pub fn internal_with_signature_logging(
        log_message: impl Display,
        tx_signature: &TransactionSignature,
        err: impl std::error::Error,
    ) -> Self {
        let log_message = format!("{log_message}: Transaction signature: {tx_signature:?}");
        Self::internal_with_logging(&log_message, err)
    }

    pub fn is_internal(&self) -> bool {
        self.code == Self::internal_error_code()
    }

    /// Returned when the gateway is already running its maximum number of concurrent declare
    /// compilations and rejects an additional declare rather than queueing it.
    pub fn too_many_concurrent_declare_compilations() -> Self {
        Self {
            code: StarknetErrorCode::KnownErrorCode(
                KnownStarknetErrorCode::TransactionLimitExceeded,
            ),
            message: "Too many declare transactions are being compiled concurrently. Please retry \
                      later."
                .to_string(),
        }
    }

    fn internal_error_code() -> StarknetErrorCode {
        StarknetErrorCode::UnknownErrorCode("StarknetErrorCode.InternalError".to_string())
    }
}

impl std::fmt::Display for StarknetError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{self:?}")
    }
}

impl From<starknet_api::StarknetApiError> for StarknetError {
    fn from(e: starknet_api::StarknetApiError) -> Self {
        StarknetError::internal_with_logging("Starknet API error", e)
    }
}

pub fn deserialize_unknown_error_code<'de, D>(de: D) -> Result<String, D::Error>
where
    D: Deserializer<'de>,
{
    let string: String = Deserialize::deserialize(de)?;
    let string_as_json = format!("\"{string}\"");
    match serde_json::from_str::<KnownStarknetErrorCode>(&string_as_json) {
        Ok(_) => Err(D::Error::custom(
            "Trying to serialize a known Starknet error code into UnknownErrorCode",
        )),
        Err(json_err) => {
            if json_err.is_data() {
                return Ok(string);
            }
            Err(D::Error::custom(json_err))
        }
    }
}
