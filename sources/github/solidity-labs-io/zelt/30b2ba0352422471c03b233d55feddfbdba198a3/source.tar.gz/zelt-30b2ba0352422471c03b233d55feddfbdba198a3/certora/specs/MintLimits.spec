/// 1 munging --- change solidity code to write spec
/// 2 helpers --- exposing additional things and behaviors you don't have access to
/// 3 harnessing --- add solidity code to expose variables and make it play nice with the prover

methods {
    /// envfree
    function bufferCap(address)                                 external returns (uint256) envfree;
    function midPoint(address)                                  external returns (uint112) envfree;
    function rateLimitPerSecond(address)                        external returns (uint256) envfree;
    function MAX_RATE_LIMIT_PER_SECOND()                        external returns (uint128) envfree;
    function lastBufferUsedTime(address)                        external returns (uint32) envfree;
    function bufferStored(address)                              external returns (uint112) envfree;
    /// env
    function removeLimit(address bridge)                        external;
    function removeLimits(address[] memory bridges)             external;
    function sync(address)                                      external;
    function addLimits(MintLimits.RateLimitMidPointInfo[] memory limits)   external;
    function addLimit(MintLimits.RateLimitMidPointInfo memory newLimit)    external;
}

function uint32Max() returns uint256 {
    return 2 ^ 32 - 1;
}

function uint112Max() returns uint256 {
    return 2 ^ 112 - 1;
}

function absDelta(mathint a, mathint b) returns mathint {
    if (a > b) {
        return a - b;
    }

    return b - a;
}

/// State Transitions

/// if depleting, amount <= buffer()
/// after depletion, buffer() == buffer() - amount
/// - lastBufferUsedTime == block.timestamp if amount != 0
/// - bufferStored == buffer()


/// if replenishing
/// - lastBufferUsedTime == block.timestamp if amount != 0 && bufferCap != newBuffer
/// - bufferStored() <= bufferCap

/// ----------------------
/// ----- Invariants -----
/// ----------------------

/// 1). buffer() <= bufferCap
/// 2). bufferStored <= bufferCap
/// 3). rateLimitPerSecond <= MAX_RATE_LIMIT_PER_SECOND
/// 4). midpoint < bufferCap
/// 5). midpoint == bufferCap / 2
/// 6). always converges on midpoint over time with non zero rate limit
/// 7). buffer <= uint112Max
/// 8). bufferCap <= uint112Max
/// 9). lastBufferUsedTime updated when non view function is called, when:
///      - buffer is ne midpoint
///      - lastBufferUsedTime != block.timestamp
/// 10). bufferStored changes when non view function is called, when:
/////       1. rate limit ne 0
/////       2. buffer != midpoint
/////       3. lastBufferUsedTime != block.timestamp
/// 11). deplete: buffer -= amount
/// 12). replenish: buffer += amount
/// 13). setBufferCap: bufferStored <= bufferCap, (already covered by invariant #2)

/// 1). buffer() <= bufferCap
/// buffer must be non zero for this to work
invariant bufferLteBufferCap(env e, address limit)
    (bufferCap(limit) != 0) => (buffer(e, limit) <= assert_uint256(bufferCap(limit))) {
        preserved {
            requireInvariant midPointLtBufferCap(limit);
            requireInvariant bufferStoredLteBufferCap(e, limit);
        }
    }

/// 2). bufferStored <= bufferCap
/// if buffercap is non-zero, bufferStored <= bufferCap
invariant bufferStoredLteBufferCap(env e, address limit)
    (bufferCap(limit) > 0) => (to_mathint(bufferStored(limit)) <= to_mathint(bufferCap(limit))) {
        preserved {
            requireInvariant midPointLtBufferCap(limit);
        }
    }

/// 3). rateLimitPerSecond <= MAX_RATE_LIMIT_PER_SECOND
invariant maxRateLimitPerSecond(address limit)
    to_mathint(rateLimitPerSecond(limit)) <= to_mathint(MAX_RATE_LIMIT_PER_SECOND());

/// 4). midpoint < bufferCap
invariant midPointLtBufferCap(address limit)
    (bufferCap(limit) > 0) => assert_uint256(midPoint(limit)) < bufferCap(limit) {
        preserved {
            requireInvariant midPointHalfBufferCap(limit);
        }
    }

/// 5). midpoint == bufferCap / 2
invariant midPointHalfBufferCap(address limit)
    to_mathint(midPoint(limit)) == to_mathint(bufferCap(limit)) / 2;

/// 7). buffer <= uint112Max
invariant bufferLteUint112(env e, address limit)
    to_mathint(buffer(e, limit)) <= to_mathint(uint112Max());

/// 8). bufferCap <= uint112Max
invariant bufferCapLteUint112(address limit)
    to_mathint(bufferCap(limit)) <= to_mathint(uint112Max());

/// -------------------
/// ------ Rules ------
/// -------------------

/// last buffer used time monotonically increasing
rule lastBufferUsedTimeCorrectlyUpdated(env e, method f, address limit) filtered {
    f -> !f.isView &&
    f.selector != sig:removeLimit(address).selector &&
    f.selector != sig:removeLimits(address[] memory).selector
} {
    require ((2 ^ 32) - 1) >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1

    calldataarg args;

    uint256 lastBufferUsedTimePre = lastBufferUsedTime(limit);
    require to_mathint(lastBufferUsedTimePre) <= to_mathint(e.block.timestamp);

    f(e, args);

    uint256 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePre != lastBufferUsedTimePost =>
     lastBufferUsedTimePre <= lastBufferUsedTimePost,
     "incorrect state transition";

    assert lastBufferUsedTimePre != lastBufferUsedTimePost =>
     to_mathint(lastBufferUsedTimePost) <= to_mathint(e.block.timestamp),
     "incorrect post timestamp set, cannot be in the future";
}

/// buffer does not change
rule noStateChanges(env e, method f, address limit)
filtered {
    f ->
    f.selector != sig:sync(address).selector &&
    f.selector != sig:setBufferCap(address, uint112).selector &&
    f.selector != sig:setRateLimitPerSecond(address, uint128).selector &&
    f.selector != sig:replenishBuffer(address, uint256).selector &&
    f.selector != sig:depleteBuffer(address, uint256).selector &&
    f.selector != sig:removeLimit(address).selector &&
    f.selector != sig:removeLimits(address[] memory).selector &&
    f.selector != sig:addLimits(MintLimits.RateLimitMidPointInfo[] memory).selector &&
    f.selector != sig:addLimit(MintLimits.RateLimitMidPointInfo).selector
} {
    calldataarg args;

    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);
    uint112 bufferStoredPre = bufferStored(limit);
    uint256 lastBufferPre = buffer(e, limit);

    f(e, args);

    assert lastBufferUsedTimePre == lastBufferUsedTime(limit), "last buffer used time state change";
    assert bufferStoredPre == bufferStored(limit), "last buffer stored state change";
    assert lastBufferPre == buffer(e, limit), "buffer state change";
}

rule timePassingBufferConvergesOnMidpoint(env e1, env e2, address limit) {
    mathint lastBufferEnv1 = to_mathint(buffer(e1, limit));
    mathint lastBufferEnv2 = to_mathint(buffer(e2, limit));

    /// e2 is ahead of e1
    /// only allow e2 timestamps less than or equal to 2^32 - 1
    /// last buffer used time is less than or equal to e1 timestamp
    /// lastBufferUsedTime <= e1 < e2 <= 2^32 - 1
    /// buffers cannot be the same
    /// midpoint is half of buffer cap
    /// buffer converges on midpoint if midpoint is half of buffer cap, and rate limit is non zero
    assert (
        (lastBufferEnv1 != lastBufferEnv2) &&
        (e2.block.timestamp <= uint32Max()) &&
        (e1.block.timestamp < e2.block.timestamp) &&
        (lastBufferUsedTime(limit) < assert_uint32(e1.block.timestamp)) &&
        to_mathint(midPoint(limit)) == (to_mathint(bufferCap(limit)) / 2) &&
        rateLimitPerSecond(limit) != 0
    ) => (absDelta(lastBufferEnv1, midPoint(limit)) > absDelta(lastBufferEnv2, midPoint(limit))),
     "buffer not converging on midpoint";
}

rule lastBufferUsedTimeAlwaysMonotonicallyIncreasingDeplete(env e, uint256 amount, address limit) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    depleteBuffer(e,limit, amount);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre,
     "buffer used time incorrect, should be greater than pre";
}

rule lastBufferUsedTimeAlwaysMonotonicallyIncreasingReplenish(env e, uint256 amount, address limit) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    replenishBuffer(e, limit, amount);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre, "buffer used time incorrect, should be greater than pre";
}

rule lastBufferUsedTimeMonotonicallyIncreasingSync(env e, address limit) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);
    uint256 bufferPre = buffer(e, limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    sync(e, limit);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre, "buffer used time incorrect, should be greater than pre";
}

rule lastBufferUsedTimeMonotonicallyIncreasingDepleteBuffer(env e, address limit, uint256 amount) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    depleteBuffer(e, limit, amount);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre, "buffer used time incorrect, should be greater than pre";
}

rule lastBufferUsedTimeMonotonicallyIncreasingReplenishBuffer(env e, address limit, uint256 amount) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    replenishBuffer(e, limit, amount);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre, "buffer used time incorrect, should be greater than pre";
}

rule lastBufferUsedTimeMonotonicallyIncreasingSetBufferCap(env e, address limit, uint112 newBufferCap) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    setBufferCap(e, limit, newBufferCap);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre, "buffer used time incorrect, should be greater than pre";
}

rule lastBufferUsedTimeMonotonicallyIncreasingSetRateLimitPerSecond(env e, address limit, uint128 newRateLimitPerSecond) {
    uint32 lastBufferUsedTimePre = lastBufferUsedTime(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTimePre) < to_mathint(e.block.timestamp);

    setRateLimitPerSecond(e, limit, newRateLimitPerSecond);

    uint32 lastBufferUsedTimePost = lastBufferUsedTime(limit);

    assert lastBufferUsedTimePost > lastBufferUsedTimePre, "buffer used time incorrect, should be greater than pre";
}

/// buffer converges on midpoint when calling sync
rule bufferStoredConvergesOnMidpointSync(env e, address limit) {
    uint112 bufferStoredPre = bufferStored(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTime(limit)) < to_mathint(e.block.timestamp);
    require rateLimitPerSecond(limit) != 0; /// ensure rate limit is non zero so that buffer changes
    require buffer(e, limit) != assert_uint256(midPoint(limit));

    sync(e, limit);

    uint112 bufferStoredPost = bufferStored(limit);

    assert absDelta(bufferStoredPre, midPoint(limit)) > absDelta(bufferStoredPost, midPoint(limit)), "buffer stored not converging on midpoint";
}

/// buffer converges on midpoint when setting rate limit per second
rule bufferStoredConvergesOnMidpointSetRateLimitPerSecond(env e, address limit, uint128 rateLimitPerSecond) {
    uint112 bufferStoredPre = bufferStored(limit);

    require uint32Max() >= e.block.timestamp; /// only allow timestamps less than or equal to 2^32 - 1
    require to_mathint(lastBufferUsedTime(limit)) < to_mathint(e.block.timestamp);
    require rateLimitPerSecond(limit) != 0; /// ensure rate limit is non zero so that buffer changes
    require buffer(e, limit) != assert_uint256(midPoint(limit));

    setRateLimitPerSecond(e, limit, rateLimitPerSecond);

    uint112 bufferStoredPost = bufferStored(limit);

    assert absDelta(bufferStoredPre, midPoint(limit)) > absDelta(bufferStoredPost, midPoint(limit)), "buffer stored not converging on midpoint";
}

/// only depletes or replenishes atomically when depleting or replenishing buffer
rule bufferUpdatesDeplete(env e, uint256 amount, address limit) {
    mathint bufferPre = to_mathint(buffer(e, limit));

    depleteBuffer(e, limit, amount);

    mathint bufferPost = to_mathint(buffer(e, limit));

    assert (bufferPre - amount) == bufferPost, "buffer not decreased on replenish";
    assert (uint32Max() >= e.block.timestamp) => 
     (assert_uint256(lastBufferUsedTime(limit)) == e.block.timestamp),
     "last buffer used time not updated";
}

/// only depletes or replenishes atomically when depleting or replenishing buffer
rule bufferUpdatesReplenish(env e, uint256 amount, address limit) {
    mathint bufferPre = to_mathint(buffer(e, limit));

    replenishBuffer(e, limit, amount);

    mathint bufferPost = to_mathint(buffer(e, limit));

    assert (bufferPre + amount) == bufferPost, "buffer not increased on replenish";
    assert (uint32Max() >= e.block.timestamp) => 
     (assert_uint256(lastBufferUsedTime(limit)) == e.block.timestamp),
     "last buffer used time not updated";
}
