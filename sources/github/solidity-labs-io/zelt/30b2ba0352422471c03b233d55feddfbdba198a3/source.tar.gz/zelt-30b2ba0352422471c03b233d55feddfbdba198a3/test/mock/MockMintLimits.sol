pragma solidity 0.8.19;

import {MintLimits} from "@zelt-src/impl/MintLimits.sol";
import {RateLimitedMidpointLibrary} from "@zelt-src/lib/RateLimitedMidpointLibrary.sol";
import {RateLimitMidPoint, RateLimitMidpointCommonLibrary} from "@zelt-src/lib/RateLimitMidpointCommonLibrary.sol";

contract MockMintLimits is MintLimits {
    using RateLimitMidpointCommonLibrary for RateLimitMidPoint;
    using RateLimitedMidpointLibrary for RateLimitMidPoint;

    /// @notice the maximum rate limit per second for any address
    uint128 public constant MAX_RATE_LIMIT_PER_SECOND = 1_000 * 1e18;

    /// @notice the minimum buffer cap, non inclusive
    uint112 public constant MIN_BUFFER_CAP = 10_000_000 * 1e18;

    function depleteBuffer(address from, uint256 amount) external {
        _depleteBuffer(from, amount);
    }

    function replenishBuffer(address from, uint256 amount) external {
        _replenishBuffer(from, amount);
    }

    /// @notice add a new limit to the set
    /// @param newLimit the new limit to add
    function addLimit(RateLimitMidPointInfo memory newLimit) external {
        _addLimit(newLimit);
    }

    /// @notice add new limit to the set
    /// @param newLimits the new limits to add
    function addLimits(RateLimitMidPointInfo[] memory newLimits) external {
        _addLimits(newLimits);
    }

    /// @notice remove a bridge from the currently active bridges
    /// deleting its buffer stored, buffer cap, mid point and last
    /// buffer used time
    /// @param bridge the bridge to remove
    function removeLimit(address bridge) external {
        _removeLimit(bridge);
    }

    /// @notice remove a set of bridges from the currently active bridges
    /// deleting its buffer stored, buffer cap, mid point and last
    /// buffer used time
    /// @param bridges the bridges to remove
    function removeLimits(address[] memory bridges) external {
        _removeLimits(bridges);
    }

    /// @dev can only be called if the address already has a buffer cap
    /// @notice conform to the xERC20 setLimits interface
    /// @param bridge the address we are setting the limits of
    /// @param newBufferCap the new buffer cap, uint112 max for unlimited
    function setBufferCap(address bridge, uint112 newBufferCap) external {
        _setBufferCap(bridge, newBufferCap);
    }

    /// @dev can only be called if the address already has a buffer cap
    /// @notice set rate limit per second for an address
    /// @param bridge the address we are setting the limits of
    /// @param newRateLimitPerSecond the new rate limit per second
    function setRateLimitPerSecond(
        address bridge,
        uint128 newRateLimitPerSecond
    ) external {
        _setRateLimitPerSecond(bridge, newRateLimitPerSecond);
    }

    /// @notice sync the buffer for the address
    function sync(address from) external {
        rateLimits[from].sync();
    }

    /// @notice the amount the buffer replenishes towards the midpoint per second
    /// @param from address to get rate limit for
    function midPoint(address from) public view returns (uint112) {
        return rateLimits[from].midPoint;
    }

    /// @notice the last buffer stored value
    function bufferStored(address from) public view returns (uint112) {
        return rateLimits[from].bufferStored;
    }

    /// @notice the last buffer used time for the address
    function lastBufferUsedTime(address from) public view returns (uint32) {
        return rateLimits[from].lastBufferUsedTime;
    }

    /// @notice the maximum rate limit per second allowed in any address
    /// must be overridden by child contract
    function maxRateLimitPerSecond() public pure override returns (uint128) {
        return MAX_RATE_LIMIT_PER_SECOND;
    }

    /// @notice the minimum buffer cap, non inclusive
    /// must be overridden by child contract
    function minBufferCap() public pure override returns (uint112) {
        return MIN_BUFFER_CAP;
    }
}
