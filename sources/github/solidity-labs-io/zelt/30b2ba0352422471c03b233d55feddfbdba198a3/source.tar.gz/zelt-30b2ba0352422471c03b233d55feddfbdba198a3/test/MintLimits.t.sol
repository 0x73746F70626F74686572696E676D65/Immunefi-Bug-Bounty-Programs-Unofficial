pragma solidity =0.8.19;

import {Math} from "@zelt-src/util/Math.sol";

import "@forge-std/Test.sol";

import {MintLimits} from "@zelt-src/impl/MintLimits.sol";
import {RateLimited} from "@zelt-src/impl/RateLimited.sol";
import {MockMintLimits} from "@zelt-test/mock/MockMintLimits.sol";

contract UnitTestMintLimits is Test {
    /// @notice event emitted when buffer cap is updated
    event BufferCapUpdate(uint256 oldBufferCap, uint256 newBufferCap);

    /// @notice event emitted when rate limit per second is updated
    event RateLimitPerSecondUpdate(
        uint256 oldRateLimitPerSecond,
        uint256 newRateLimitPerSecond
    );

    /// @notice event emitted when buffer gets eaten into
    event BufferUsed(uint256 amountUsed, uint256 bufferRemaining);

    /// @notice event emitted when buffer gets replenished
    event BufferReplenished(uint256 amountReplenished, uint256 bufferRemaining);

    /// @notice rate limited v2 contract
    MockMintLimits rlm;

    /// @notice maximum rate limit per second in RateLimitedV2
    uint256 private constant maxRateLimitPerSecond = 1_000 * 1e18;

    /// @notice rate limit per second in RateLimitedV2
    uint128 private constant rateLimitPerSecond = 1_000 * 1e18;

    /// @notice 2x min buffer cap in MintLimits
    uint112 private constant bufferCap = 20_000_000 * 1e18;

    function setUp() public {
        rlm = new MockMintLimits();
        rlm.addLimit(
            MintLimits.RateLimitMidPointInfo(
                bufferCap,
                rateLimitPerSecond,
                address(this)
            )
        );
    }

    function testSetup() public {
        assertEq(
            rlm.bufferCap(address(this)),
            bufferCap,
            "buffercap set incorrectly"
        );
        assertEq(
            rlm.rateLimitPerSecond(address(this)),
            rateLimitPerSecond,
            "rate limit per second set incorrectly"
        );
        assertEq(
            rlm.MAX_RATE_LIMIT_PER_SECOND(),
            maxRateLimitPerSecond,
            "max rate limit per second set incorrectly"
        );

        /// buffer cap starts off at midpoint
        assertEq(
            rlm.buffer(address(this)),
            bufferCap / 2,
            "buffer set incorrectly"
        ); /// buffer has not been depleted
        assertEq(
            rlm.midPoint(address(this)),
            bufferCap / 2,
            "midpoint should be half of bufferCap"
        );
    }

    function testDepleteBuffer(uint128 amountToPull, uint16 warpAmount) public {
        if (amountToPull > rlm.midPoint(address(this))) {
            vm.expectRevert("RateLimited: rate limit hit");
            rlm.depleteBuffer(address(this), amountToPull);
        } else {
            amountToPull = uint128(
                _bound(amountToPull, 1, rlm.buffer(address(this)))
            );

            uint256 startingBuffer = rlm.buffer(address(this));
            vm.expectEmit(true, false, false, true, address(rlm));
            emit BufferUsed(amountToPull, startingBuffer - amountToPull);
            rlm.depleteBuffer(address(this), amountToPull);

            uint256 endingBuffer = rlm.buffer(address(this));

            assertEq(
                endingBuffer,
                rlm.midPoint(address(this)) - amountToPull,
                "incorrect ending buffer"
            );
            assertEq(
                block.timestamp,
                rlm.lastBufferUsedTime(address(this)),
                "incorrect time after depleting buffer"
            );

            vm.warp(block.timestamp + warpAmount);

            uint256 accruedBuffer = warpAmount * rateLimitPerSecond;
            uint256 expectedBuffer = Math.min(
                endingBuffer + accruedBuffer,
                rlm.midPoint(address(this))
            );
            assertEq(
                expectedBuffer,
                rlm.buffer(address(this)),
                "incorrect buffer after warp"
            );
        }
    }

    function testReplenishBuffer(
        uint128 amountToReplenish,
        uint16 warpAmount
    ) public {
        rlm.depleteBuffer(address(this), rlm.buffer(address(this))); /// fully exhaust buffer
        assertEq(rlm.buffer(address(this)), 0, "buffer should be empty");

        amountToReplenish = uint128(
            _bound(
                amountToReplenish,
                1,
                rlm.bufferCap(address(this)) - rlm.buffer(address(this))
            )
        ); /// can only replenish up to remaining buffer left

        vm.expectEmit(true, false, false, true, address(rlm));
        emit BufferReplenished(amountToReplenish, amountToReplenish);

        rlm.replenishBuffer(address(this), amountToReplenish);
        assertEq(
            rlm.buffer(address(this)),
            amountToReplenish,
            "incorrect buffer after replenishing"
        );
        assertEq(
            block.timestamp,
            rlm.lastBufferUsedTime(address(this)),
            "incorrect time after replenishing"
        );

        uint256 startingBufferBeforeWarp = rlm.buffer(address(this));

        vm.warp(block.timestamp + uint256(warpAmount));

        uint256 accruedBuffer = warpAmount * rateLimitPerSecond;
        uint256 expectedBuffer = rlm.midPoint(address(this)); /// start off at midpoint, so if no assignment, we are at correct point
        uint256 midPoint = rlm.midPoint(address(this));

        //// depletion

        //// t0 | ---------------- | ----------------- |
        ////                       ^

        //// t0 | ---------------- | ----------------- |
        ////    ^

        /// scenario A

        //// replenish
        //// t0 | ---------------- | ----------------- |
        ////               ^

        //// t1 | ---------------- | ----------------- |
        ////                    ^

        /// scenario B

        //// replenish
        //// t0 | ---------------- | ----------------- |
        ////                                ^

        //// t1 | ---------------- | ----------------- |
        ////                         ^

        /// scenario C

        //// replenish
        //// t0 | ---------------- | ----------------- |
        ////                                ^

        //// t1 | ---------------- | ----------------- |
        ////                    ^ X -- gets set to midpoint

        //// B
        //// t0 = startingBufferBeforeWarp
        //// if started at greater than midpoint, then subtract accrued buffer
        if (startingBufferBeforeWarp > midPoint) {
            if (
                startingBufferBeforeWarp >= accruedBuffer &&
                startingBufferBeforeWarp - accruedBuffer > midPoint /// handle scenario C
            ) {
                expectedBuffer = startingBufferBeforeWarp - accruedBuffer;
            }
            //// A
        } else if (startingBufferBeforeWarp < midPoint) {
            expectedBuffer = startingBufferBeforeWarp + accruedBuffer > midPoint
                ? midPoint
                : startingBufferBeforeWarp + accruedBuffer;
        }

        assertEq(
            expectedBuffer,
            rlm.buffer(address(this)),
            "incorrect buffer at end time"
        );
    }

    function testDepleteThenReplenishBuffer(
        uint128 amountToDeplete,
        uint128 amountToReplenish,
        uint16 warpAmount
    ) public {
        amountToDeplete = uint128(
            _bound(amountToDeplete, 1, rlm.buffer(address(this)) - 100)
        ); /// can only deplete full buffer
        amountToReplenish = uint128(
            _bound(
                amountToReplenish,
                1,
                rlm.buffer(address(this)) - amountToDeplete
            )
        ); /// can only replenish up to bufferCap
        rlm.depleteBuffer(address(this), amountToDeplete); /// deplete buffer
        assertEq(
            rlm.buffer(address(this)),
            rlm.midPoint(address(this)) - amountToDeplete,
            "incorrect buffer after depletion"
        );

        rlm.replenishBuffer(address(this), amountToReplenish);

        assertEq(
            rlm.buffer(address(this)),
            rlm.midPoint(address(this)) - amountToDeplete + amountToReplenish,
            "incorrect buffer after deplete and replenish"
        );
        assertEq(
            block.timestamp,
            rlm.lastBufferUsedTime(address(this)),
            "last buffer used time incorrect"
        );

        uint256 startingBufferBeforeWarp = rlm.buffer(address(this));

        vm.warp(block.timestamp + uint256(warpAmount));

        uint256 accruedBuffer = warpAmount * rateLimitPerSecond;
        uint256 expectedBuffer = rlm.midPoint(address(this)); /// start off at midpoint, so if no assignment, we are at correct point
        uint256 midPoint = rlm.midPoint(address(this));

        if (startingBufferBeforeWarp > midPoint) {
            if (
                startingBufferBeforeWarp >= accruedBuffer &&
                startingBufferBeforeWarp - accruedBuffer > midPoint /// handle scenario C
            ) {
                expectedBuffer = startingBufferBeforeWarp - accruedBuffer;
            }
            //// A
        } else if (startingBufferBeforeWarp < midPoint) {
            expectedBuffer = startingBufferBeforeWarp + accruedBuffer > midPoint
                ? midPoint
                : startingBufferBeforeWarp + accruedBuffer;
        }

        assertEq(
            expectedBuffer,
            rlm.buffer(address(this)),
            "incorrect buffer at end time"
        );
    }

    function testReplenish(uint128 amountToReplenish) public {
        amountToReplenish = uint128(
            _bound(amountToReplenish, 1, rlm.bufferCap(address(this)) / 2)
        );
        rlm.replenishBuffer(address(this), amountToReplenish);
        assertEq(
            rlm.buffer(address(this)),
            rlm.midPoint(address(this)) + amountToReplenish,
            "incorrect buffer after replenishing"
        );
        assertEq(
            block.timestamp,
            rlm.lastBufferUsedTime(address(this)),
            "incorrect timestamp after replenishing"
        );
    }

    function testReplenishOverBufferCapFails() public {
        uint256 amountToReplenish = rlm.bufferCap(address(this)) + 1;
        vm.expectRevert("RateLimited: buffer cap overflow");
        rlm.replenishBuffer(address(this), amountToReplenish);
    }

    function testDepleteMoreThanBufferFails() public {
        uint256 depleteAmount = rlm.buffer(address(this)) + 1;
        vm.expectRevert("RateLimited: rate limit hit");
        rlm.depleteBuffer(address(this), depleteAmount);
    }

    function testCanUpdateRateLimitPerSecond() public {
        uint128 newRateLimitPerSecond = 100e18;

        rlm.setRateLimitPerSecond(address(this), newRateLimitPerSecond);

        assertEq(
            rlm.rateLimitPerSecond(address(this)),
            newRateLimitPerSecond,
            "incorrect rate limit per second"
        );
    }

    function testCanUpdateBufferCap() public {
        uint112 newBuffer = 14_000_000 * 1e18;
        uint112 bufferStored = rlm.bufferStored(address(this));

        rlm.setBufferCap(address(this), newBuffer); /// in this scenario, buffer is full, so only depletes are possible

        assertEq(
            rlm.bufferCap(address(this)),
            newBuffer,
            "incorrect buffer cap"
        );
        assertEq(
            rlm.midPoint(address(this)),
            newBuffer / 2,
            "incorrect midpoint"
        );
        assertEq(
            rlm.bufferStored(address(this)),
            bufferStored,
            "incorrect buffer stored, should not change"
        );
    }

    function testCanSync() public {
        rlm.sync(address(this));

        assertEq(
            rlm.bufferCap(address(this)),
            bufferCap,
            "incorrect buffer cap"
        );
        assertEq(
            rlm.midPoint(address(this)),
            bufferCap / 2,
            "incorrect midpoint"
        );
        assertEq(
            rlm.bufferStored(address(this)),
            bufferCap / 2,
            "incorrect buffer stored"
        );
    }
}
