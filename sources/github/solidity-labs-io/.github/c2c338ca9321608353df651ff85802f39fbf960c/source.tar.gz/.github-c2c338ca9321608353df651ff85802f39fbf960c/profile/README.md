# Solidity Labs

Solidity Labs is the leading boutique smart contract development agency.

## About

We build and review smart contract systems on Ethereum and other blockchains. Our team of experienced engineers and researchers has a track record of delivering secure and reliable systems.

We have successfully built over eight greenfield smart contract protocols, collectively securing over $2b in TVL.

## Open Source

We are committed to contributing to the security of the community and the ecosystem. Our open source governance security tool, [forge proposal simulator](https://github.com/solidity-labs-io/forge-proposal-simulator) tool helps projects secure their most privileged roles. See the [security checklist](https://github.com/solidity-labs-io/code-review-checklist) and [security](https://medium.com/@elliotfriedman3/a-security-stack-4aedd8617e8b) [stack](https://medium.com/@elliotfriedman3/a-security-stack-part-2-aaacbbf77346) for a list of security considerations when building smart contract systems.

## Service Offerings

### Governance Safety

Governance can be tough, especially for on-chain organizations whose proposals must go through a lengthy voting and time lock period.

There have been many examples of calldata being incorrect, metamorphic malicious contracts, and damage or losses caused by the unexpected in this novel category.

Our governance proposal reviews remove uncertainty and help secure your organization onchain.

### Architecture

Getting the architecture of a smart contract protocol right decreases the attack surface, and minimizes the chances of security incidents.

Our team can help you build a more secure smart contract system by making the right tradeoffs before cutting code.

### Engineering

Our team of experts can help you go from idea to implementation using cutting edge verification techniques. Our unique approach to testing and design helps reduce ambiguities and security issues through threat modeling, testing, formal verification and rigorous review of specifications, code and tests.

Each system is different and requires different tools and methodology. We have expertise in formal verification, fuzz, unit, integration, and invariant testing to increase your project's security. Our writings on the security [stack](https://medium.com/@elliotfriedman3/a-security-stack-part-2-aaacbbf77346) contain an in-depth guide to our approach. 
