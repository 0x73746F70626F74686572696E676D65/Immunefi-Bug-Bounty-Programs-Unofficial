// config: line_length = 160
// config: bracket_spacing = true
contract ContractDefinition is Contract1, Contract2, Contract3, Contract4, Contract5 { }

// comment 7
contract SampleContract {
    // spaced comment 1

    // spaced comment 2
    // that spans multiple lines

    // comment 8
    constructor() { /* comment 9 */ } // comment 10

    // comment 11
    function max( /* comment 13 */
        uint256 arg1,
        uint256 /* comment 14 */ arg2,
        uint256 /* comment 15 */
    )
        // comment 16
        external /* comment 17 */
        pure
        returns (uint256)
    // comment 18
    {
        // comment 19
        return arg1 > arg2 ? arg1 : arg2;
    }
}

// comment 20
contract /* comment 21 */ ExampleContract is /* comment 22 */ SampleContract { }

contract ERC20DecimalsMock is ERC20 {
    uint8 private immutable _decimals;

    constructor(string memory name_, string memory symbol_, uint8 decimals_) ERC20(name_, symbol_) {
        _decimals = decimals_;
    }
}

contract SomeContract is
    ERC165Upgradeable, // 1 inherited component
    ISomeContract // 4 inherited components
{ }

contract AnotherContract is
    Adminable, /* 1 inherited components */
    UUPSUpgradeable /* 1 inherited component */
{ }

contract WithLayoutAndBase layout at 69 is Base { }
