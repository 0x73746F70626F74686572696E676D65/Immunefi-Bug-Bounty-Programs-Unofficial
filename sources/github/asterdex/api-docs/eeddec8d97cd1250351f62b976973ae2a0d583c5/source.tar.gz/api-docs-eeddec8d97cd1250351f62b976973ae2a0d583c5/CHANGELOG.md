# Changelog

## 2026-08-31

### Changed

#### Spot V3 / Futures V3 authentication requirement: main wallet deposit required

Starting **2026-09-01 00:00 UTC**, all authenticated V3 API endpoints will only be accessible once the main wallet linked to the Aster account has completed a deposit. This applies to endpoints requiring identity authentication, including account, order, trade, and other USER_DATA / TRADE endpoints.

Not affected by this change:
- Agent Wallet create / query / update / delete endpoints
- Builder create / authorize / query / update / delete endpoints
- Public market data endpoints requiring no authentication

Until the main wallet has completed a deposit, affected authenticated V3 requests may fail with:
```json
{"code":-5050,"msg":"This function can only be used after deposit"}
```

Added the new `-5050 DEPOSIT_REQUIRED` error code to the Spot V3 and Futures V3 API references (EN and CN, mainnet and testnet).

---

## 2026-07-16

### Changed

#### `GET /fapi/v3/builder/approvedUserList` — Get Builder Approved User List: added pagination

Added `endTime`, `page`, and `limit` parameters (limit defaults to `100`, max `1000`). The response is now a paginated object (`rows`, `total`, `currentPage`, `totalPages`, `pageSize`, `hasMore`) instead of a bare array; the per-record fields (`userAddress`, `builderAddress`, `maxFeeRate`, `builderName`, `approveTime`) are unchanged, now nested under `rows[]`.

Documented in EN and CN futures API references.

---

## 2026-07-07

### Added

#### `DELETE /fapi/v3/guardedCancelOrder` and `DELETE /fapi/v3/guardedBatchOrders` — Cancel Order / Cancel Multiple Orders (Guarded)

Added guarded variants of the existing cancel endpoints, intended for orders placed/authorized on-chain — the on-chain nonce associated with each order guards against duplicate or out-of-order cancellation. Require `signer`, `nonce`, and `signature`; other request parameters and the response schema are identical to `DELETE /fapi/v3/order` and `DELETE /fapi/v3/batchOrders` respectively.

Documented in EN and CN, mainnet and testnet futures API references.

---

## 2026-07-03

### Added

#### `GET /fapi/v3/builder/userTrades` — Get Builder Trades

New USER_DATA endpoint (weight 5) returning the paginated trade history of users trading under the caller's builder code, with `startTime`/`endTime`/`page`/`limit` filters.

#### `GET /fapi/v3/builder/approvedUserList` — Get Builder Approved User List

New USER_DATA endpoint (weight 5) returning the list of users who have approved the caller's address as their builder, with an optional `startTime` filter.

---

## 2026-06-30

### Changed

#### `POST /fapi/v3/placeStrategyOrder` — Place Strategy Order: added `builder` and `feeRate` parameters

Added two optional top-level parameters:
- `builder` (STRING, optional) — Builder address
- `feeRate` (DECIMAL, optional) — Custom fee rate

---

## 2026-05-26

### Added

#### Prediction API Testnet Documentation / 预测市场 API 测试网文档

Added full API reference documentation for the Prediction API on testnet (`https://papi.asterdex-testnet.com`), covering:

- **Market data**: `GET /api/v3/prediction/ping`, `GET /api/v3/prediction/time`, `GET /api/v3/prediction/exchangeInfo`, depth, trades, klines, tickers, best order book
- **Trading**: `POST /api/v3/order` (Place order), `DELETE /api/v3/order` (Cancel order), `GET /api/v3/order`, open orders, all orders, cancel all open orders
- **Prediction market**: mint (`POST /api/v3/prediction/mint`), burn (`POST /api/v3/prediction/burn`), positions (`GET /api/v3/prediction/positionRisk`), position history, settlement history
- **Account**: perp-spot transfer, withdraw fee, withdraw, account info, trade history
- **WebSocket streams**: trades, klines, tickers, order book depth (limited & incremental), listen key lifecycle, `ACCOUNT_UPDATE` payload

Documentation available in both English (`V3(Recommended)/EN/aster-finance-prediction-api-tesetnet.md`) and Chinese (`V3(Recommended)/中文/aster-finance-prediction-api-testnet.md`).

---

## 2026-05-21

### Added

#### `POST /aster-chain/v3/transfer` — Transfer to Address / 转账至地址

A new WITHDRAW-authenticated endpoint for transferring assets to another registered Aster Chain user address. Returns `transferId`, `asset`, `amount`, `toAddress`, `timestamp`, and `status`.

#### STP Mode APIs / 自成交防止模式接口

- `POST /fapi/v3/stpMode` — Change STP Mode / 更改STP模式 (TRADE, weight 1)
- `GET /fapi/v3/stpMode` — Get Current STP Mode / 查询STP模式 (USER_DATA, weight 30)

Supports `EXPIRE_TAKER`, `EXPIRE_MAKER`, `EXPIRE_BOTH`. Added `stpMode` optional parameter to `POST /fapi/v3/order` for per-order STP override.


### Added

#### `POST /fapi/v3/stpMode` — Change STP Mode / 更改STP模式

A new TRADE endpoint that sets the account-level **Self-Trade Prevention (STP) mode** applied to all orders by default. Accepted values: `EXPIRE_TAKER`, `EXPIRE_MAKER`, `EXPIRE_BOTH`.

#### `GET /fapi/v3/stpMode` — Get Current STP Mode / 查询STP模式

A new USER_DATA endpoint that returns the account's current STP mode.

### Changed

#### `POST /fapi/v3/order` — New Order: added optional `stpMode` parameter

Added `stpMode` (ENUM, optional) to the place-order parameter list. When specified, it overrides the account-level STP default for that individual order.

---

## 2026-05-20

### Added

#### Strategy Order APIs / 策略订单接口

- `POST /fapi/v3/placeStrategyOrder` — Place Strategy Order / 策略下单
- `POST /fapi/v3/updateStrategyOrder` — Update Strategy Order / 更新策略订单
- `GET /fapi/v3/strategyOrder` — Query Strategy Open Order / 查询策略当前挂单
- `GET /fapi/v3/strategyOrder/history` — Query Strategy History Order / 查询策略历史订单

Supports OTO, OCO, and OTOCO strategy types.

---

## 2026-05-19

### Added

#### `POST /fapi/v3/chase` — Place Chase Order / 下追单

A new public endpoint that **places a BBO-pegged GTX limit order with automatic price tracking**. The strategy service polls each tick and re-pegs the order to `bid1 − chaseOffset` (BUY) or `ask1 + chaseOffset` (SELL). The chase auto-cancels when the market moves beyond `maxChaseOffset` from the original BBO. Supports `quantityUnit` (`BASE` / `QUOTE`), and optional `maxChaseOffset` in `ABSOLUTE` or `PERCENTAGE` units.

### Changed

#### `PUT /fapi/v3/order` — Modify Order: clarified BBO-pegged behavior

Added a note that BBO-pegged orders (placed with `pegPriceType = COUNTERPARTY_1 / QUEUE_1`) cannot have their price re-resolved via plain modify — to continuously track the BBO use a Chase order (`POST /fapi/v3/chase`).

---

## 2026-05-12

### Added

#### `POST /fapi/v3/registerAndApproveAgent` — Register and Approve Agent / 注册并授权 Agent

A new public endpoint that **registers an API agent account and grants trading/withdrawal permissions in a single atomic call**.

---

## 2025-xx-xx

### Added

#### `POST /fapi/v3/asset/migrateUser` — Migrate User Assets / 用户资产迁移

#### `GET /fapi/v3/asset/migrateUser/history` — Migrate User Assets History / 用户资产迁移历史
