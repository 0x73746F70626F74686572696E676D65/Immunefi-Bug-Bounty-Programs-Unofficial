// SPDX-License-Identifier: GPL-2.0-or-later

pragma solidity ^0.8.24;

import { AggregatorV3Interface } from "@chainlink/contracts/src/v0.8/shared/interfaces/AggregatorV3Interface.sol";
import { IERC20Metadata } from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import { IRateProvider } from "@balancer-labs/v3-interfaces/contracts/solidity-utils/helpers/IRateProvider.sol";
import { ISequencerUptimeFeed } from "@balancer-labs/v3-interfaces/contracts/oracles/ISequencerUptimeFeed.sol";
import { ILPOracleBase } from "@balancer-labs/v3-interfaces/contracts/oracles/ILPOracleBase.sol";
import { IWeightedPool } from "@balancer-labs/v3-interfaces/contracts/pool-weighted/IWeightedPool.sol";
import { RateProviderMock } from "@balancer-labs/v3-vault/contracts/test/RateProviderMock.sol";
import { IBasePool } from "@balancer-labs/v3-interfaces/contracts/vault/IBasePool.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import { WeightedPoolFactory } from "@balancer-labs/v3-pool-weighted/contracts/WeightedPoolFactory.sol";
import { CastingHelpers } from "@balancer-labs/v3-solidity-utils/contracts/helpers/CastingHelpers.sol";
import { InputHelpers } from "@balancer-labs/v3-solidity-utils/contracts/helpers/InputHelpers.sol";
import { ArrayHelpers } from "@balancer-labs/v3-solidity-utils/contracts/test/ArrayHelpers.sol";
import {
    WeightedPoolContractsDeployer
} from "@balancer-labs/v3-pool-weighted/test/foundry/utils/WeightedPoolContractsDeployer.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";

import { WeightedLPOracleMock } from "../../contracts/test/WeightedLPOracleMock.sol";
import { BaseLPOracleTest } from "./utils/BaseLPOracleTest.sol";
import { LPOracleBase } from "../../contracts/LPOracleBase.sol";
import { FeedMock } from "../../contracts/test/FeedMock.sol";

contract WeightedLPOracleTest is BaseLPOracleTest, WeightedPoolContractsDeployer {
    using FixedPoint for uint256;
    using CastingHelpers for address[];
    using ArrayHelpers for *;

    uint256 constant MAX_TOKENS = 8;
    uint256 constant MIN_WEIGHT = 1e16; // 1%

    event Log(address indexed value);
    event LogUint(uint256 indexed value);

    WeightedPoolFactory weightedPoolFactory;
    uint256 poolCreationNonce;

    function setUp() public virtual override {
        super.setUp();

        weightedPoolFactory = deployWeightedPoolFactory(IVault(address(vault)), 365 days, "Factory v1", "Pool v1");
    }

    // From BaseLPOracleTest
    function getMaxTokens() public pure virtual override returns (uint256) {
        return MAX_TOKENS;
    }

    // Override from BaseLPOracleTest
    function createOracle(uint256 numTokens) public override returns (IBasePool) {
        (IWeightedPool pool, ) = createAndInitPool(numTokens);
        (oracle, feeds) = deployOracle(pool);

        return pool;
    }

    function deployOracle(
        IWeightedPool pool
    ) internal virtual returns (LPOracleBase oracle, AggregatorV3Interface[] memory feeds) {
        (IERC20[] memory tokens, , , ) = vault.getPoolTokenInfo(address(pool));

        feeds = new AggregatorV3Interface[](tokens.length);

        for (uint256 i = 0; i < tokens.length; i++) {
            feeds[i] = AggregatorV3Interface(address(new FeedMock(IERC20Metadata(address(tokens[i])).decimals())));
        }

        oracle = new WeightedLPOracleMock(
            IVault(address(vault)),
            pool,
            feeds,
            uptimeFeed,
            UPTIME_RESYNC_WINDOW,
            shouldUseBlockTimeForOldestFeedUpdate,
            shouldRevertIfVaultUnlocked,
            VERSION
        );
    }

    function createAndInitPool() internal returns (IWeightedPool) {
        (IWeightedPool pool, ) = createAndInitPool(2);
        return pool;
    }

    function createAndInitPool(uint256 totalTokens) internal returns (IWeightedPool, uint256[] memory weights) {
        weights = new uint256[](totalTokens);
        address[] memory _tokens = new address[](totalTokens);
        uint256[] memory poolInitAmounts = new uint256[](totalTokens);

        uint256 lastIndex = totalTokens - 1;
        weights[lastIndex] = FixedPoint.ONE;
        for (uint256 i = 0; i < totalTokens; i++) {
            _tokens[i] = address(sortedTokens[i]);
            poolInitAmounts[i] = poolInitAmount;

            if (i == lastIndex) {
                break;
            }

            weights[i] = FixedPoint.ONE / totalTokens;
            weights[lastIndex] -= weights[i];
        }

        return (createAndInitPool(_tokens, poolInitAmounts, weights), weights);
    }

    function createAndInitPool(
        address[] memory _tokens,
        uint256[] memory initAmounts,
        uint256[] memory weights
    ) internal returns (IWeightedPool) {
        return createAndInitPool(initAmounts, weights, vault.buildTokenConfig(_tokens.asIERC20()));
    }

    function createAndInitPool(
        uint256[] memory initAmounts,
        uint256[] memory weights,
        TokenConfig[] memory tokenConfigs
    ) internal returns (IWeightedPool) {
        string memory name = "Weighted Pool Test";
        string memory symbol = "WEIGHTED-TEST";

        PoolRoleAccounts memory roleAccounts;

        address newPool = weightedPoolFactory.create(
            name,
            symbol,
            tokenConfigs,
            weights,
            roleAccounts,
            DEFAULT_SWAP_FEE_PERCENTAGE,
            address(0),
            true,
            false,
            bytes32(poolCreationNonce++)
        );

        vm.startPrank(lp);
        _initPool(newPool, initAmounts, 0);
        vm.stopPrank();

        _setSwapFeePercentage(newPool, 0);

        return IWeightedPool(newPool);
    }

    function testDescription() public {
        IWeightedPool pool = createAndInitPool();
        (LPOracleBase oracle, ) = deployOracle(pool);

        assertEq(oracle.description(), "WEIGHTED-TEST/USD", "Description does not match");
    }

    /**
     * forge-config: default.fuzz.runs = 10
     * forge-config: intense.fuzz.runs = 50
     */
    function testGetWeights__Fuzz(uint256 totalTokens) public {
        totalTokens = bound(totalTokens, MIN_TOKENS, getMaxTokens());

        (IWeightedPool pool, uint256[] memory weights) = createAndInitPool(totalTokens);
        (LPOracleBase _oracle, ) = deployOracle(pool);
        WeightedLPOracleMock oracle = WeightedLPOracleMock(address(_oracle));

        uint256[] memory returnedWeights = oracle.getWeights();
        assertEq(returnedWeights.length, weights.length, "Weights length mismatch");

        for (uint256 i = 0; i < weights.length; i++) {
            assertEq(weights[i], returnedWeights[i], "Weight does not match");
        }
    }

    function testCalculateTVLAfterSwap() public {
        IWeightedPool pool = createAndInitPool(
            [address(dai), address(usdc)].toMemoryArray(),
            [poolInitAmount, poolInitAmount].toMemoryArray(),
            [50e16, uint256(50e16)].toMemoryArray() // 50% weight for each token
        );

        (LPOracleBase oracle, ) = deployOracle(pool);
        int256[] memory prices = [int256(1e18), int256(1e18)].toMemoryArray();

        uint256 tvlBefore = oracle.computeTVLGivenPrices(prices);

        uint256 swapAmount = poolInitAmount / 10;

        vm.prank(lp);
        router.swapSingleTokenExactIn(address(pool), dai, usdc, swapAmount, 0, MAX_UINT256, false, bytes(""));

        uint256 tvlAfter = oracle.computeTVLGivenPrices(prices);

        assertApproxEqAbs(tvlAfter, tvlBefore, 1e3, "TVL should not change after swap");
    }

    function testCalculateTVLAfterSwapWithRates() public {
        TokenConfig[] memory tokenConfigs = new TokenConfig[](2);
        IERC20[] memory tokens = InputHelpers.sortTokens([address(usdc), address(dai)].toMemoryArray().asIERC20());
        for (uint256 i = 0; i < tokens.length; i++) {
            tokenConfigs[i].token = tokens[i];
            tokenConfigs[i].tokenType = TokenType.WITH_RATE;
            RateProviderMock rateProvider = new RateProviderMock();
            rateProvider.mockRate(1e18 + (1 + i) * 1e17);
            tokenConfigs[i].rateProvider = IRateProvider(address(rateProvider));
        }

        IWeightedPool pool = createAndInitPool(
            [poolInitAmount, poolInitAmount].toMemoryArray(),
            [uint256(50e16), uint256(50e16)].toMemoryArray(), // 50% weight for each token
            tokenConfigs
        );

        (LPOracleBase oracle, ) = deployOracle(pool);
        int256[] memory prices = [int256(1e18), int256(1e18)].toMemoryArray();

        uint256 tvlBefore = oracle.computeTVLGivenPrices(prices);

        uint256 swapAmount = poolInitAmount / 10;

        vm.prank(lp);
        router.swapSingleTokenExactIn(address(pool), dai, usdc, swapAmount, 0, MAX_UINT256, false, bytes(""));

        uint256 tvlAfter = oracle.computeTVLGivenPrices(prices);

        assertApproxEqAbs(tvlAfter, tvlBefore, 4e3, "TVL should not change after swap");
    }

    struct OracleResults {
        uint256[] weights;
        uint256[] answers;
        uint256[] updateTimestamps;
    }

    function testLatestRoundData__Fuzz(
        uint256 totalTokens,
        uint256[MAX_TOKENS] memory weightsRaw,
        uint256[MAX_TOKENS] memory poolInitAmountsRaw,
        uint256[MAX_TOKENS] memory answersRaw,
        uint256[MAX_TOKENS] memory updateTimestampsRaw,
        bool useBlockTimeForOldestFeedUpdate
    ) public {
        totalTokens = bound(totalTokens, MIN_TOKENS, getMaxTokens());
        // Set in test for oracle deployment.
        shouldUseBlockTimeForOldestFeedUpdate = useBlockTimeForOldestFeedUpdate;

        address[] memory _tokens = new address[](totalTokens);
        uint256[] memory poolInitAmounts = new uint256[](totalTokens);

        OracleResults memory results = OracleResults({
            weights: new uint256[](totalTokens),
            answers: new uint256[](totalTokens),
            updateTimestamps: new uint256[](totalTokens)
        });

        uint256 updateTimestamp = useBlockTimeForOldestFeedUpdate ? block.timestamp : MAX_UINT256;
        {
            uint256 restWeight = FixedPoint.ONE;
            for (uint256 i = 0; i < totalTokens; i++) {
                _tokens[i] = address(sortedTokens[i]);
                poolInitAmounts[i] = bound(
                    poolInitAmountsRaw[i],
                    defaultAccountBalance() / 10,
                    defaultAccountBalance()
                );
                results.answers[i] = bound(answersRaw[i], 1, MAX_UINT128 / 10);
                results.updateTimestamps[i] = block.timestamp - bound(updateTimestampsRaw[i], 1, 100);

                if (useBlockTimeForOldestFeedUpdate == false && results.updateTimestamps[i] < updateTimestamp) {
                    updateTimestamp = results.updateTimestamps[i];
                }

                if (i == totalTokens - 1) {
                    results.weights[i] = restWeight;
                } else {
                    uint256 maxWeight = restWeight / (totalTokens - i);
                    results.weights[i] = bound(weightsRaw[i], MIN_WEIGHT, maxWeight);
                    restWeight -= results.weights[i];
                }
            }
        }

        IWeightedPool pool = createAndInitPool(_tokens, poolInitAmounts, results.weights);
        (LPOracleBase oracle, AggregatorV3Interface[] memory feeds) = deployOracle(pool);

        for (uint256 i = 0; i < totalTokens; i++) {
            FeedMock(address(feeds[i])).setLastRoundData(results.answers[i], results.updateTimestamps[i]);
        }

        uint256[] memory lastBalancesLiveScaled18 = vault.getCurrentLiveBalances(address(pool));

        uint256 _totalTokens = totalTokens;
        uint256 expectedTVL = FixedPoint.ONE;
        for (uint256 i = 0; i < _totalTokens; i++) {
            uint256 price = results.answers[i] * oracle.getFeedTokenDecimalScalingFactors()[i];
            expectedTVL = expectedTVL.mulDown(uint256(price).divDown(results.weights[i]).powDown(results.weights[i]));
        }
        expectedTVL = expectedTVL.mulDown(pool.computeInvariant(lastBalancesLiveScaled18, Rounding.ROUND_DOWN));

        (
            uint80 roundId,
            int256 lpPrice,
            uint256 startedAt,
            uint256 returnedUpdateTimestamp,
            uint80 answeredInRound
        ) = oracle.latestRoundData();

        assertEq(uint256(roundId), 0, "Round ID does not match");
        assertEq(uint256(lpPrice), expectedTVL.divUp(IERC20(address(pool)).totalSupply()), "LP price does not match");
        assertEq(startedAt, 0, "Started at does not match");
        assertEq(returnedUpdateTimestamp, updateTimestamp, "Update timestamp does not match");
        assertEq(answeredInRound, 0, "Answered in round does not match");
    }

    function _createValidOracle() internal virtual override returns (LPOracleBase) {
        uint256 numTokens = 2;

        uint256[] memory answers = new uint256[](numTokens);
        uint256[] memory updateTimestamps = new uint256[](numTokens);
        for (uint256 i = 0; i < 2; i++) {
            answers[i] = 1e18;
            updateTimestamps[i] = block.timestamp;
        }

        IWeightedPool pool = createAndInitPool();
        (LPOracleBase oracle, AggregatorV3Interface[] memory feeds) = deployOracle(pool);

        for (uint256 i = 0; i < numTokens; i++) {
            FeedMock(address(feeds[i])).setLastRoundData(answers[i], updateTimestamps[i]);
        }

        return LPOracleBase(oracle);
    }
}
