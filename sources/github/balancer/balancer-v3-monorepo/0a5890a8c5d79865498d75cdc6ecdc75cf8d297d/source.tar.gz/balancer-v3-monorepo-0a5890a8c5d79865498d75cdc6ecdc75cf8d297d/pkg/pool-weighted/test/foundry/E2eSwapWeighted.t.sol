// SPDX-License-Identifier: GPL-3.0-or-later

pragma solidity ^0.8.24;

import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import { IBasePool } from "@balancer-labs/v3-interfaces/contracts/vault/IBasePool.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import { E2eSwapTest, E2eTestState, SwapLimits } from "@balancer-labs/v3-vault/test/foundry/E2eSwap.t.sol";
import { CastingHelpers } from "@balancer-labs/v3-solidity-utils/contracts/helpers/CastingHelpers.sol";
import { ArrayHelpers } from "@balancer-labs/v3-solidity-utils/contracts/test/ArrayHelpers.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";

import { WeightedPoolContractsDeployer } from "./utils/WeightedPoolContractsDeployer.sol";
import { WeightedPoolMock } from "../../contracts/test/WeightedPoolMock.sol";
import { WeightedPool } from "../../contracts/WeightedPool.sol";

contract E2eSwapWeightedTest is E2eSwapTest, WeightedPoolContractsDeployer {
    using ArrayHelpers for *;
    using CastingHelpers for address[];
    using FixedPoint for uint256;

    string internal constant POOL_VERSION = "Pool v1";
    uint256 internal constant DEFAULT_SWAP_FEE = 1e16; // 1%

    uint256 internal poolCreationNonce;

    function setUp() public override {
        E2eSwapTest.setUp();

        // Set swap fees to min swap fee percentage.
        vault.manualSetStaticSwapFeePercentage(pool, IBasePool(pool).getMinimumSwapFeePercentage());

        E2eTestState memory state = _getTestState();
        vm.prank(state.poolCreator);
        // Weighted pools may be drained if there are no lp fees. So, set the creator fee to 99% to add some lp fee
        // back to the pool and ensure the invariant doesn't decrease.
        feeController.setPoolCreatorSwapFeePercentage(pool, 99e16);
    }

    function setUpVariables(E2eTestState memory state) internal view override returns (E2eTestState memory) {
        state.sender = lp;
        state.poolCreator = lp;

        state.amountInExactInOutError = 0.001e16;
        // 0.0001% max swap fee.
        state.minPoolSwapFeePercentage = 1e12;
        // 10% max swap fee.
        state.maxPoolSwapFeePercentage = 10e16; // 10%

        return state;
    }

    function computeSwapLimits() internal view override returns (SwapLimits memory swapLimits) {
        swapLimits.minTokenA = poolInitAmountTokenA / 1e3;
        swapLimits.minTokenB = poolInitAmountTokenB / 1e3;

        // Divide init amount by 10 to make sure weighted math ratios are respected (Cannot trade more than 30% of pool
        // balance).
        swapLimits.maxTokenA = poolInitAmountTokenA / 10;
        swapLimits.maxTokenB = poolInitAmountTokenB / 10;
    }

    function fuzzPoolState(
        uint256[POOL_SPECIFIC_PARAMS_SIZE] memory params,
        E2eTestState memory state
    ) internal override returns (E2eTestState memory) {
        uint256 weightTokenA = params[0];
        weightTokenA = bound(weightTokenA, 0.1e16, 99.9e16);

        uint256[] memory newPoolBalances = _setPoolBalancesWithDifferentWeights(weightTokenA);
        (state.swapLimits.minTokenA, state.swapLimits.maxTokenA) = _setSwapLimitsExactIn(
            newPoolBalances,
            state.swapLimits.minTokenA
        );
        (state.swapLimits.minTokenB, state.swapLimits.maxTokenB) = _setSwapLimitsExactOut(
            newPoolBalances,
            state.swapLimits.minTokenB
        );

        // Weighted Pool has rounding errors when token decimals are different, so the number below fixes the test
        // `testExactInRepeatExactOutVariableFeesSpecific__Fuzz`. The farther the weights are from 50/50, the bigger
        // the error.
        state.exactInOutDecimalsErrorMultiplier = 2000;

        return state;
    }

    function _setSwapLimitsExactIn(
        uint256[] memory poolBalancesRaw,
        uint256 currentMinSwapAmountTokenA
    ) private view returns (uint256 minSwapAmountTokenA, uint256 maxSwapAmountTokenA) {
        // Since tokens can have different decimals and amountIn is in relation to tokenA, normalize tokenB liquidity.
        uint256 normalizedLiquidityTokenB = (poolBalancesRaw[tokenBIdx] * (10 ** decimalsTokenA)) /
            (10 ** decimalsTokenB);

        // 25% of tokenA or tokenB liquidity, the lowest value, to make sure the swap is executed.
        maxSwapAmountTokenA =
            (
                poolBalancesRaw[tokenAIdx] > normalizedLiquidityTokenB
                    ? normalizedLiquidityTokenB
                    : poolBalancesRaw[tokenAIdx]
            ) /
            4;
        // Makes sure minSwapAmount is smaller than maxSwapAmount.
        minSwapAmountTokenA = Math.min(currentMinSwapAmountTokenA, maxSwapAmountTokenA);
    }

    function _setSwapLimitsExactOut(
        uint256[] memory poolBalancesRaw,
        uint256 currentMinSwapAmountTokenB
    ) private view returns (uint256 minSwapAmountTokenB, uint256 maxSwapAmountTokenB) {
        // Since tokens can have different decimals and amountOut is in relation to tokenB, normalize tokenA liquidity.
        uint256 normalizedLiquidityTokenA = (poolBalancesRaw[tokenAIdx] * (10 ** decimalsTokenB)) /
            (10 ** decimalsTokenA);

        // 25% of tokenA or tokenB liquidity, the lowest value, to make sure the swap is executed.
        maxSwapAmountTokenB =
            (
                normalizedLiquidityTokenA > poolBalancesRaw[tokenBIdx]
                    ? poolBalancesRaw[tokenBIdx]
                    : normalizedLiquidityTokenA
            ) /
            4;
        // Makes sure minSwapAmount is smaller than maxSwapAmount.
        minSwapAmountTokenB = Math.min(currentMinSwapAmountTokenB, maxSwapAmountTokenB);
    }

    function testSwapSymmetry__Fuzz(uint256 tokenAAmountIn, uint256 weightTokenA, uint256 swapFeePercentage) public {
        E2eTestState memory $ = _getTestState();
        weightTokenA = bound(weightTokenA, 1e16, 99e16);
        swapFeePercentage = bound(swapFeePercentage, $.minPoolSwapFeePercentage, $.maxPoolSwapFeePercentage);
        _setSwapFeePercentage(pool, swapFeePercentage);

        uint256[] memory newPoolBalances = _setPoolBalancesWithDifferentWeights(weightTokenA);

        // Since tokens can have different decimals and amountOut is in relation to tokenB, normalize tokenA liquidity.
        uint256 normalizedLiquidityTokenA = (newPoolBalances[tokenAIdx] * (10 ** decimalsTokenB)) /
            (10 ** decimalsTokenA);

        // Cap amount in to lowest normalized liquidity * 25%
        tokenAAmountIn = bound(
            tokenAAmountIn,
            1e15,
            Math.min(normalizedLiquidityTokenA, newPoolBalances[tokenBIdx]) / 4
        );

        uint256 snapshotId = vm.snapshotState();

        vm.prank(alice);
        uint256 amountOut = router.swapSingleTokenExactIn(
            pool,
            tokenA,
            tokenB,
            tokenAAmountIn,
            0,
            MAX_UINT256,
            false,
            bytes("")
        );

        vm.revertToState(snapshotId);

        vm.prank(alice);
        uint256 amountIn = router.swapSingleTokenExactOut(
            pool,
            tokenA,
            tokenB,
            amountOut,
            MAX_UINT128,
            MAX_UINT256,
            false,
            bytes("")
        );

        // An ExactIn swap with `DEFAULT_AMOUNT` tokenIn returned `amountOut` tokenOut.
        // Since Exact_In and Exact_Out are symmetrical, an ExactOut swap with `amountOut` tokenOut should return the
        // same amount of tokenIn.
        assertApproxEqRel(amountIn, tokenAAmountIn, 0.00001e16, "Swap fees are not symmetric for ExactIn and ExactOut");
    }

    function createPoolFactory() internal override returns (address) {
        return address(deployWeightedPoolFactory(IVault(address(vault)), 365 days, "Factory v1", POOL_VERSION));
    }

    /**
     * @notice Creates and initializes a weighted pool with a setter for weights, so weights can be changed without
     * initializing the pool again. This pool is used by E2eSwapTest tests.
     */
    function _createPool(
        address[] memory tokens,
        string memory label
    ) internal override returns (address newPool, bytes memory poolArgs) {
        string memory name = "50/50 Weighted Pool";
        string memory symbol = "50_50WP";

        LiquidityManagement memory liquidityManagement;
        PoolRoleAccounts memory roleAccounts;
        roleAccounts.poolCreator = lp;

        uint256[] memory minTokenBalances = new uint256[](tokens.length);
        for (uint256 i = 0; i < tokens.length; ++i) {
            minTokenBalances[i] = _getMinTokenBalance(tokens[i]);
        }

        newPool = address(
            deployWeightedPoolMock(
                WeightedPool.NewPoolParams({
                    name: name,
                    symbol: symbol,
                    numTokens: tokens.length,
                    normalizedWeights: [uint256(50e16), uint256(50e16)].toMemoryArray(),
                    version: POOL_VERSION,
                    minTokenBalances: minTokenBalances
                }),
                vault
            )
        );
        vm.label(newPool, label);

        vault.registerPool(
            newPool,
            vault.buildTokenConfig(tokens.asIERC20()),
            DEFAULT_SWAP_FEE,
            0,
            false,
            roleAccounts,
            address(0),
            liquidityManagement
        );

        poolArgs = abi.encode(
            WeightedPool.NewPoolParams({
                name: name,
                symbol: symbol,
                numTokens: tokens.length,
                normalizedWeights: [uint256(50e16), uint256(50e16)].toMemoryArray(),
                version: POOL_VERSION,
                minTokenBalances: minTokenBalances
            }),
            vault
        );
    }

    function _setPoolBalancesWithDifferentWeights(
        uint256 weightTokenA
    ) private returns (uint256[] memory newPoolBalances) {
        uint256[2] memory newWeights;
        newWeights[tokenAIdx] = weightTokenA;
        newWeights[tokenBIdx] = FixedPoint.ONE - weightTokenA;

        WeightedPoolMock(pool).setNormalizedWeights(newWeights);

        newPoolBalances = new uint256[](2);
        // This operation will change the invariant of the pool, but what matters is the proportion of each token.
        newPoolBalances[tokenAIdx] = (poolInitAmountTokenA).mulDown(newWeights[tokenAIdx]);
        newPoolBalances[tokenBIdx] = (poolInitAmountTokenB).mulDown(newWeights[tokenBIdx]);

        // Rate is 1, so we just need to compare 18 with token decimals to scale each liquidity accordingly.
        uint256[] memory newPoolBalanceLiveScaled18 = new uint256[](2);
        newPoolBalanceLiveScaled18[tokenAIdx] = newPoolBalances[tokenAIdx] * 10 ** (18 - decimalsTokenA);
        newPoolBalanceLiveScaled18[tokenBIdx] = newPoolBalances[tokenBIdx] * 10 ** (18 - decimalsTokenB);

        (IERC20[] memory tokens, , , ) = vault.getPoolTokenInfo(pool);
        // liveBalances = rawBalances because rate is 1 and both tokens are 18 decimals.
        vault.manualSetPoolTokensAndBalances(pool, tokens, newPoolBalances, newPoolBalanceLiveScaled18);
    }

    function _calculatePoolInvariant(
        address poolToCalculate,
        Rounding rounding
    ) private view returns (uint256 invariant) {
        (, , , uint256[] memory lastBalancesLiveScaled18) = vault.getPoolTokenInfo(poolToCalculate);
        return IBasePool(poolToCalculate).computeInvariant(lastBalancesLiveScaled18, rounding);
    }
}
