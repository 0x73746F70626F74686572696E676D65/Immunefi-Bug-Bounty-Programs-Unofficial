// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import { IRateProvider } from "@balancer-labs/v3-interfaces/contracts/solidity-utils/helpers/IRateProvider.sol";
import { IPoolInfo } from "@balancer-labs/v3-interfaces/contracts/pool-utils/IPoolInfo.sol";

import { BaseVaultTest } from "@balancer-labs/v3-vault/test/foundry/utils/BaseVaultTest.sol";

import { Gyro2ClpPoolDeployer } from "./utils/Gyro2ClpPoolDeployer.sol";

contract SwapSmoke2CLPTest is BaseVaultTest, Gyro2ClpPoolDeployer {
    function setUp() public virtual override {
        BaseVaultTest.setUp();
    }

    function _createPool(
        address[] memory tokens,
        string memory label
    ) internal override returns (address, bytes memory) {
        IRateProvider[] memory rateProviders = new IRateProvider[](tokens.length);
        return createGyro2ClpPool(tokens, rateProviders, label, vault, lp);
    }

    function testSwapExactInAndExactOutSmoke() public {
        IERC20[] memory ts = IPoolInfo(pool).getTokens();
        IERC20 token0 = ts[0];
        IERC20 token1 = ts[1];

        vm.startPrank(lp);
        uint256 outAmt = router.swapSingleTokenExactIn(
            pool,
            token0,
            token1,
            1e18,
            0,
            type(uint256).max,
            false,
            bytes("")
        );
        assertGt(outAmt, 0);

        // Exact out in the opposite direction to hit the other swap kind too.
        uint256 inAmt = router.swapSingleTokenExactOut(
            pool,
            token1,
            token0,
            1e15,
            type(uint256).max,
            type(uint256).max,
            false,
            bytes("")
        );
        assertGt(inAmt, 0);
        vm.stopPrank();
    }
}
