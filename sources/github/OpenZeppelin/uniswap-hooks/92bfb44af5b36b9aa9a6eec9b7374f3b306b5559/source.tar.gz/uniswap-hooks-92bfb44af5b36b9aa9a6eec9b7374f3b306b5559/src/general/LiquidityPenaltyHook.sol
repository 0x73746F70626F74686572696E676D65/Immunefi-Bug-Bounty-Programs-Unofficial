// SPDX-License-Identifier: MIT
// OpenZeppelin Uniswap Hooks (last updated v1.2.0) (src/general/LiquidityPenaltyHook.sol)

pragma solidity ^0.8.26;

// External imports
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Position} from "@uniswap/v4-core/src/libraries/Position.sol";
import {SafeCast} from "@uniswap/v4-core/src/libraries/SafeCast.sol";
import {StateLibrary} from "@uniswap/v4-core/src/libraries/StateLibrary.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";
import {PoolId} from "@uniswap/v4-core/src/types/PoolId.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {ModifyLiquidityParams} from "@uniswap/v4-core/src/types/PoolOperation.sol";
import {BalanceDelta, BalanceDeltaLibrary, toBalanceDelta} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
// Internal imports
import {BaseHook} from "../base/BaseHook.sol";
import {CurrencySettler} from "../utils/CurrencySettler.sol";

/**
 * @dev Just-in-Time (JIT) liquidity provisioning resistant hook.
 *
 * This hook disincentivizes JIT attacks by penalizing LP fee collection during {_afterRemoveLiquidity},
 * and disabling it during {_afterAddLiquidity} if liquidity was recently added to the position.
 * The penalty is donated to the pool's liquidity providers in range at the time of removal.
 *
 * See {_calculateLiquidityPenalty} for penalty calculation.
 *
 * NOTE: If a long term liquidity provider adds liquidity continuously, a pause of `blockNumberOffset`
 * before removing will be needed if `feesAccrued` collection is intended, in order to avoid getting
 * penalized by the JIT protection mechanism.
 *
 * WARNING: The penalty is donated to all liquidity in range at removal, including liquidity the remover controls,
 * such as the rest of the same position after a partial removal, other positions, or a secondary account. That
 * liquidity receives its pro-rata share and can collect it without penalty once `blockNumberOffset` has passed.
 * The share grows as the pool gets thinner, so low liquidity pools and long-tail assets may still be vulnerable.
 * Larger values of `blockNumberOffset` are recommended in those cases to decrease the profitability of the attack.
 *
 * WARNING: This is experimental software and is provided on an "as is" and "as available" basis. We do
 * not give any warranties and will not be liable for any losses incurred through any use of this code
 * base.
 *
 * _Available since v0.1.1_
 */
abstract contract LiquidityPenaltyHook is BaseHook {
    using CurrencySettler for Currency;
    using StateLibrary for IPoolManager;
    using SafeCast for uint256;

    /**
     * @dev The hook was attempted to be constructed with a `blockNumberOffset` lower than `MIN_BLOCK_NUMBER_OFFSET`.
     */
    error BlockNumberOffsetTooLow();

    /**
     * @dev A penalty was attempted to be applied and donated to LP's in range, but there aren't any.
     */
    error NoLiquidityToReceiveDonation();

    /**
     * @dev The minimum value for the {blockNumberOffset}.
     */
    uint48 public constant MIN_BLOCK_NUMBER_OFFSET = 1;

    /**
     * @dev The minimum time window (in blocks) that must pass after adding liquidity before it can be
     * removed without any penalty. During this period, JIT attacks are deterred through fee withholding
     * and penalties. Higher values provide stronger JIT protection but may discourage legitimate LPs.
     */
    uint48 public immutable blockNumberOffset;

    /**
     * @dev Tracks the `lastAddedLiquidityBlock` for a liquidity position.
     */
    mapping(PoolId poolId => mapping(bytes32 positionKey => uint48 blockNumber)) private _lastAddedLiquidityBlock;

    /**
     * @dev Tracks the `withheldFees` for a liquidity position.
     */
    mapping(PoolId poolId => mapping(bytes32 positionKey => BalanceDelta delta)) private _withheldFees;

    /**
     * @dev Sets the {getBlockNumberOffset} and the {poolManager} address.
     */
    constructor(uint48 _blockNumberOffset) {
        if (_blockNumberOffset < MIN_BLOCK_NUMBER_OFFSET) revert BlockNumberOffsetTooLow();
        blockNumberOffset = _blockNumberOffset;
    }

    /**
     * @dev Tracks `lastAddedLiquidityBlock` and withholds `feeDelta` if liquidity was recently added within
     * the `blockNumberOffset` period.
     *
     * See {_afterRemoveLiquidity} for claiming the withheld fees back.
     */
    function _afterAddLiquidity(
        address sender,
        PoolKey calldata key,
        ModifyLiquidityParams calldata params,
        BalanceDelta, /* delta */
        BalanceDelta feeDelta,
        bytes calldata
    ) internal virtual override returns (bytes4, BalanceDelta) {
        PoolId poolId = key.toId();
        bytes32 positionKey = Position.calculatePositionKey(sender, params.tickLower, params.tickUpper, params.salt);

        // If liquidity was added recently within the `blockNumberOffset`, retain the feeDelta in this hook.
        if (_getBlockNumber() - getLastAddedLiquidityBlock(poolId, positionKey) < blockNumberOffset) {
            _updateLastAddedLiquidityBlock(poolId, positionKey);
            _takeFeesToHook(key, positionKey, feeDelta);

            return (this.afterAddLiquidity.selector, feeDelta);
        }

        _updateLastAddedLiquidityBlock(poolId, positionKey);

        return (this.afterAddLiquidity.selector, BalanceDeltaLibrary.ZERO_DELTA);
    }

    /**
     * @dev Penalizes the collection of any existing LP `feesDelta` and `withheldFees` after liquidity removal if
     * liquidity was recently added to the position.
     *
     * NOTE: The penalty is applied on both `withheldFees` and `feeDelta` equally.
     * Therefore, regardless of how many times liquidity was added to the position within the `blockNumberOffset` period,
     * all accrued fees are penalized as if the liquidity was added only once during that period. This ensures that
     * splitting liquidity additions within the `blockNumberOffset` period does not reduce or increase the penalty.
     *
     * IMPORTANT: The penalty is donated to the pool's liquidity providers in range at the time of liquidity removal,
     * which may be different from the liquidity providers in range at the time of liquidity addition.
     *
     * NOTE: Fresh and withheld fees are returned in a single `int128` delta. In the unlikely case that they sum above
     * `type(int128).max` in one currency, the removal reverts.
     */
    function _afterRemoveLiquidity(
        address sender,
        PoolKey calldata key,
        ModifyLiquidityParams calldata params,
        BalanceDelta, /* delta */
        BalanceDelta feeDelta,
        bytes calldata
    ) internal virtual override returns (bytes4, BalanceDelta) {
        PoolId poolId = key.toId();
        bytes32 positionKey = Position.calculatePositionKey(sender, params.tickLower, params.tickUpper, params.salt);

        // Receive back the `withheldFees` retained during previous liquidity additions within the `blockNumberOffset`.
        BalanceDelta withheldFees = _settleFeesFromHook(key, positionKey);

        // The total fees accrued by the LP are the sum of the `feeDelta` plus the `withheldFees`.
        BalanceDelta totalFees = feeDelta + withheldFees;

        // cache lastAddedLiquidity in memory
        uint48 lastAddedLiquidityBlock = getLastAddedLiquidityBlock(poolId, positionKey);

        if (
            _getBlockNumber() - lastAddedLiquidityBlock < blockNumberOffset
                && totalFees != BalanceDeltaLibrary.ZERO_DELTA
        ) {
            BalanceDelta liquidityPenalty = _calculateLiquidityPenalty(totalFees, lastAddedLiquidityBlock);

            // If there is a penalty to be applied but there are no active liquidity positions in range to
            // receive the donation, then the liquidity removal is not possible and the offset must be awaited.
            if (poolManager.getLiquidity(poolId) == 0) revert NoLiquidityToReceiveDonation();

            poolManager.donate(
                key, uint256(int256(liquidityPenalty.amount0())), uint256(int256(liquidityPenalty.amount1())), ""
            );

            return (this.afterRemoveLiquidity.selector, liquidityPenalty - withheldFees);
        }

        // If the liquidity removal was not penalized, return the withheld fees if any.
        if (withheldFees != BalanceDeltaLibrary.ZERO_DELTA) {
            BalanceDelta returnDelta = toBalanceDelta(-withheldFees.amount0(), -withheldFees.amount1());
            return (this.afterRemoveLiquidity.selector, returnDelta);
        }

        return (this.afterRemoveLiquidity.selector, BalanceDeltaLibrary.ZERO_DELTA);
    }

    /**
     * @dev Returns the current block number.
     *
     * NOTE: Consider overriding this function on chains where `block.number` does not advance once per block.
     */
    function _getBlockNumber() internal view virtual returns (uint48) {
        return uint48(block.number);
    }

    /**
     * @dev Updates the `lastAddedLiquidityBlock` for a liquidity position.
     */
    function _updateLastAddedLiquidityBlock(PoolId poolId, bytes32 positionKey) internal virtual {
        _lastAddedLiquidityBlock[poolId][positionKey] = _getBlockNumber();
    }

    /**
     * @dev Takes `feeDelta` from a liquidity position as `withheldFees` into this hook.
     */
    function _takeFeesToHook(PoolKey calldata key, bytes32 positionKey, BalanceDelta feeDelta) internal virtual {
        PoolId poolId = key.toId();

        _withheldFees[poolId][positionKey] = _withheldFees[poolId][positionKey] + feeDelta;

        key.currency0.take(poolManager, address(this), uint256(uint128(feeDelta.amount0())), true);
        key.currency1.take(poolManager, address(this), uint256(uint128(feeDelta.amount1())), true);
    }

    /**
     * @dev Returns `withheldFees` from this hook to the liquidity provider.
     */
    function _settleFeesFromHook(PoolKey calldata key, bytes32 positionKey)
        internal
        virtual
        returns (BalanceDelta withheldFees)
    {
        PoolId poolId = key.toId();

        withheldFees = getWithheldFees(poolId, positionKey);

        // Reset the `withheldFees`.
        _withheldFees[poolId][positionKey] = BalanceDeltaLibrary.ZERO_DELTA;

        // Settle the `withheldFees` for the liquidity position.
        if (withheldFees.amount0() > 0) {
            key.currency0.settle(poolManager, address(this), uint256(uint128(withheldFees.amount0())), true);
        }
        if (withheldFees.amount1() > 0) {
            key.currency1.settle(poolManager, address(this), uint256(uint128(withheldFees.amount1())), true);
        }
    }

    /**
     * @dev Calculates the penalty to be applied to JIT liquidity provisioning.
     *
     * The penalty is calculated as a linear function of the block number difference between the `lastAddedLiquidityBlock` and the `currentBlockNumber`.
     *
     * The used formula is:
     *
     * liquidityPenalty = feeDelta * ( 1 - (currentBlockNumber - lastAddedLiquidityBlock) / blockNumberOffset)
     *
     * As a result, the penalty is 100% at the same block where liquidity was last added and zero after the `blockNumberOffset` block time window.
     *
     * NOTE: The penalty rounds up, so any nonzero fee within the window bears at least one unit of penalty.
     *
     * NOTE: Won't overflow if `currentBlockNumber - lastAddedLiquidityBlock < blockNumberOffset` is verified prior to calling this function.
     */
    function _calculateLiquidityPenalty(BalanceDelta feeDelta, uint48 lastAddedLiquidityBlock)
        internal
        virtual
        returns (BalanceDelta liquidityPenalty)
    {
        uint48 currentBlockNumber = _getBlockNumber();

        unchecked {
            uint256 amount0LiquidityPenalty = Math.mulDiv(
                SafeCast.toUint128(feeDelta.amount0()),
                blockNumberOffset - (currentBlockNumber - lastAddedLiquidityBlock), // won't overflow.
                blockNumberOffset,
                Math.Rounding.Ceil
            );
            uint256 amount1LiquidityPenalty = Math.mulDiv(
                SafeCast.toUint128(feeDelta.amount1()),
                blockNumberOffset - (currentBlockNumber - lastAddedLiquidityBlock), // won't overflow.
                blockNumberOffset,
                Math.Rounding.Ceil
            );

            // Although the amounts are returned as uint256, they must fit in int128, since they are fee rewards.
            liquidityPenalty = toBalanceDelta(amount0LiquidityPenalty.toInt128(), amount1LiquidityPenalty.toInt128());
        }
    }

    /**
     * @dev Tracks the `lastAddedLiquidityBlock` for a liquidity position.
     *
     * `lastAddedLiquidityBlock` is the block number when liquidity was last added to the position.
     */
    function getLastAddedLiquidityBlock(PoolId poolId, bytes32 positionKey) public view virtual returns (uint48) {
        return _lastAddedLiquidityBlock[poolId][positionKey];
    }

    /**
     * @dev Returns the `withheldFees` for a liquidity position.
     *
     * `withheldFees` are UniswapV4's `feesAccrued` retained by this hook during liquidity addition if liquidity
     * has been recently added within the `blockNumberOffset` block time window, with the purpose of disabling fee
     * collection during JIT liquidity provisioning attacks. See {_afterRemoveLiquidity} for claiming the fees back.
     */
    function getWithheldFees(PoolId poolId, bytes32 positionKey) public view virtual returns (BalanceDelta) {
        return _withheldFees[poolId][positionKey];
    }

    /**
     * @dev Set the hooks permissions, specifically `afterAddLiquidity`, `afterAddLiquidityReturnDelta`, `afterRemoveLiquidity` and `afterRemoveLiquidityReturnDelta`.
     */
    function getHookPermissions() public pure virtual override returns (Hooks.Permissions memory permissions) {
        return Hooks.Permissions({
            beforeInitialize: false,
            afterInitialize: false,
            beforeAddLiquidity: false,
            afterAddLiquidity: true,
            beforeRemoveLiquidity: false,
            afterRemoveLiquidity: true,
            beforeSwap: false,
            afterSwap: false,
            beforeDonate: false,
            afterDonate: false,
            beforeSwapReturnDelta: false,
            afterSwapReturnDelta: false,
            afterAddLiquidityReturnDelta: true,
            afterRemoveLiquidityReturnDelta: true
        });
    }
}
