//! # Fixed-Point Math Library
//!
//! Provides utilities for precise fixed-point arithmetic operations in Soroban
//! smart contracts.
//!
//! ## Design Overview
//!
//! The library exposes free functions for `i128` and `I256` fixed-point
//! multiplication and division, in both panicking and checked variants:
//!
//! - **Panicking variants** (e.g. [`i128_fixed_point::mul_div_with_rounding`]):
//!   panic with [`SorobanFixedPointError::Overflow`] when the result overflows,
//!   and with a native arithmetic panic when dividing by zero.
//! - **Checked variants** (e.g.
//!   [`i128_fixed_point::checked_mul_div_with_rounding`]): return `None` on
//!   error for graceful handling, including when the intermediate `x * y`
//!   multiplication overflows.
//!
//! ### Phantom Overflow Handling
//!
//! For `i128` operations, intermediate multiplication overflow is handled
//! transparently: when `x * y` overflows `i128`, the calculation is retried
//! using `I256` as an intermediate type and scaled back to `i128` if the final
//! result fits. This is called *phantom overflow handling*.
//!
//! `I256` operations do **not** apply phantom overflow handling — doing so
//! would require a custom `I512` type. Overflowing two large `I256` values is
//! considered rare enough in practice that this trade-off is acceptable.
//!
//! ## Structure
//!
//! - [`i128_fixed_point`]: Module containing free functions for `i128`
//!   fixed-point multiplication and division.
//! - [`i256_fixed_point`]: Module containing free functions for `I256`
//!   fixed-point multiplication and division.
//! - [`wad`]: Fixed-point decimal number type with 18 decimal places.
//! - [`Rounding`]: Enum to specify rounding direction (floor, ceil, truncate).
//! - [`SorobanFixedPointError`]: Error codes emitted by panicking variants.
//!
//! ## Notes
//!
//! Based on the Soroban fixed-point mathematics library.
//! Original implementation: <https://github.com/script3/soroban-fixed-point-math>

mod exp_ln;
pub mod i128_fixed_point;
pub mod i256_fixed_point;
pub mod wad;

#[cfg(test)]
mod test;

use soroban_sdk::{contracterror, contracttype};

// ################## ERRORS ##################

#[contracterror]
#[derive(Copy, Clone, Debug, Eq, PartialEq, PartialOrd, Ord)]
#[repr(u32)]
pub enum SorobanFixedPointError {
    /// Arithmetic overflow occurred
    Overflow = 1500,
    /// Division by zero
    DivisionByZero = 1501,
    /// Base is outside the valid domain (e.g. `ln(x)` for `x <= 0`,
    /// or `powf(x, y)` with non-positive `x` combined with float exponent).
    InvalidBase = 1502,
}

/// Rounding direction for division operations
#[contracttype]
pub enum Rounding {
    /// Round toward negative infinity (down)
    Floor,
    /// Round toward positive infinity (up)
    Ceil,
    /// Round toward zero (truncation)
    Truncate,
}
