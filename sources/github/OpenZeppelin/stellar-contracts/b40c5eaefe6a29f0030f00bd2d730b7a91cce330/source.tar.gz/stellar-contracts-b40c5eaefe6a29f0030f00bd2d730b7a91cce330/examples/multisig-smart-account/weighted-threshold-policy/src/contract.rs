use soroban_sdk::{auth::Context, contract, contractimpl, Address, Env, Map, Vec};
use stellar_accounts::{
    policies::{weighted_threshold, Policy},
    smart_account::{ContextRule, Signer},
};

#[contract]
pub struct WeightedThresholdPolicyContract;

#[contractimpl]
impl Policy for WeightedThresholdPolicyContract {
    type AccountParams = weighted_threshold::WeightedThresholdAccountParams;

    fn enforce(
        e: &Env,
        context: Context,
        authenticated_signers: Vec<Signer>,
        context_rule: ContextRule,
        smart_account: Address,
    ) {
        weighted_threshold::enforce(
            e,
            &context,
            &authenticated_signers,
            &context_rule,
            &smart_account,
        )
    }

    fn install(
        e: &Env,
        install_params: Self::AccountParams,
        context_rule: ContextRule,
        smart_account: Address,
    ) {
        weighted_threshold::install(e, &install_params, &context_rule, &smart_account)
    }

    fn uninstall(e: &Env, context_rule: ContextRule, smart_account: Address) {
        weighted_threshold::uninstall(e, &context_rule, &smart_account)
    }
}

#[contractimpl]
impl WeightedThresholdPolicyContract {
    pub fn get_threshold(e: &Env, context_rule_id: u32, smart_account: Address) -> u32 {
        weighted_threshold::get_threshold(e, context_rule_id, &smart_account)
    }

    pub fn get_signer_weights(
        e: &Env,
        context_rule: ContextRule,
        smart_account: Address,
    ) -> Map<Signer, u32> {
        weighted_threshold::get_signer_weights(e, &context_rule, &smart_account)
    }

    pub fn set_threshold(
        e: Env,
        threshold: u32,
        context_rule: ContextRule,
        smart_account: Address,
    ) {
        weighted_threshold::set_threshold(&e, threshold, &context_rule, &smart_account)
    }

    pub fn set_signer_weight(
        e: Env,
        signer: Signer,
        weight: u32,
        context_rule: ContextRule,
        smart_account: Address,
    ) {
        weighted_threshold::set_signer_weight(&e, &signer, weight, &context_rule, &smart_account)
    }
}
