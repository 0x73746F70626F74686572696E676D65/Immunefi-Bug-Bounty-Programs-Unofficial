extern crate std;

use soroban_sdk::{
    contract, contractimpl, contracttype, testutils::Address as _, vec, Address, Env, IntoVal,
    String, Val, Vec,
};
use stellar_tokens::rwa::{
    compliance::{AccountSnapshot, TransferKind},
    identity_registry_storage::{
        CountryData, CountryDataManager, CountryRelation, IdentityRegistryStorage,
        IndividualCountryRelation, OrganizationCountryRelation,
    },
    utils::token_binder::TokenBinder,
};

use crate::contract::{CountryAllowContract, CountryAllowContractClient};

/// This module ignores balance and frozen amounts, so they are left at zero.
fn snap(address: &Address) -> AccountSnapshot {
    AccountSnapshot { address: address.clone(), balance: 0, frozen: 0 }
}

fn create_client<'a>(
    e: &Env,
    admin: &Address,
    manager: &Address,
) -> CountryAllowContractClient<'a> {
    let address = e.register(CountryAllowContract, (admin, manager));
    CountryAllowContractClient::new(e, &address)
}

#[contract]
struct MockIRSContract;

#[contracttype]
#[derive(Clone)]
enum MockIRSStorageKey {
    Identity(Address),
    CountryEntries(Address),
}

#[contractimpl]
impl TokenBinder for MockIRSContract {
    fn linked_tokens(e: &Env) -> Vec<Address> {
        Vec::new(e)
    }

    fn bind_token(_e: &Env, _token: Address, _operator: Address) {
        unreachable!("bind_token is not used in these tests");
    }

    fn unbind_token(_e: &Env, _token: Address, _operator: Address) {
        unreachable!("unbind_token is not used in these tests");
    }
}

#[contractimpl]
impl IdentityRegistryStorage for MockIRSContract {
    fn add_identity(
        _e: &Env,
        _account: Address,
        _identity: Address,
        _country_data_list: Vec<Val>,
        _operator: Address,
    ) {
        unreachable!("add_identity is not used in these tests");
    }

    fn remove_identity(_e: &Env, _account: Address, _operator: Address) {
        unreachable!("remove_identity is not used in these tests");
    }

    fn recover_identity(
        _e: &Env,
        _old_account: Address,
        _new_account: Address,
        _operator: Address,
    ) {
        unreachable!("recover_identity is not used in these tests");
    }

    fn stored_identity(e: &Env, account: Address) -> Address {
        e.storage()
            .persistent()
            .get(&MockIRSStorageKey::Identity(account.clone()))
            .unwrap_or(account)
    }
}

#[contractimpl]
impl CountryDataManager for MockIRSContract {
    fn add_country_data_entries(
        _e: &Env,
        _account: Address,
        _country_data_list: Vec<Val>,
        _operator: Address,
    ) {
        unreachable!("add_country_data_entries is not used in these tests");
    }

    fn modify_country_data(
        _e: &Env,
        _account: Address,
        _index: u32,
        _country_data: Val,
        _operator: Address,
    ) {
        unreachable!("modify_country_data is not used in these tests");
    }

    fn delete_country_data(_e: &Env, _account: Address, _index: u32, _operator: Address) {
        unreachable!("delete_country_data is not used in these tests");
    }

    fn get_country_data_entries(e: &Env, account: Address) -> Vec<Val> {
        let entries: Vec<CountryData> = e
            .storage()
            .persistent()
            .get(&MockIRSStorageKey::CountryEntries(account))
            .unwrap_or_else(|| Vec::new(e));

        Vec::from_iter(e, entries.iter().map(|entry| entry.into_val(e)))
    }
}

#[contractimpl]
impl MockIRSContract {
    pub fn set_country_data_entries(e: &Env, account: Address, entries: Vec<CountryData>) {
        e.storage().persistent().set(&MockIRSStorageKey::CountryEntries(account), &entries);
    }
}

fn individual_country(code: u32) -> CountryData {
    CountryData {
        country: CountryRelation::Individual(IndividualCountryRelation::Residence(code)),
        metadata: None,
    }
}

fn organization_country(code: u32) -> CountryData {
    CountryData {
        country: CountryRelation::Organization(OrganizationCountryRelation::OperatingJurisdiction(
            code,
        )),
        metadata: None,
    }
}

#[test]
fn add_and_remove_allowed_country_work() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    assert!(!client.is_country_allowed(&token, &276));

    client.add_allowed_country(&token, &276, &manager);
    assert!(client.is_country_allowed(&token, &276));

    client.remove_allowed_country(&token, &276, &manager);
    assert!(!client.is_country_allowed(&token, &276));
}

#[test]
fn batch_allow_and_disallow_countries_work() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    client.batch_allow_countries(&token, &vec![&e, 250u32, 276u32], &manager);
    assert!(client.is_country_allowed(&token, &250));
    assert!(client.is_country_allowed(&token, &276));

    client.batch_disallow_countries(&token, &vec![&e, 250u32], &manager);
    assert!(!client.is_country_allowed(&token, &250));
    assert!(client.is_country_allowed(&token, &276));
}

#[test]
fn name_returns_module_identifier() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    assert_eq!(client.name(), String::from_str(&e, "CountryAllowModule"));
}

#[test]
fn set_and_get_compliance_address_round_trip() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let compliance = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    client.set_compliance_address(&token, &compliance, &admin);

    assert_eq!(client.get_compliance_address(&token), compliance);
}

#[test]
fn set_compliance_address_requires_admin_auth() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let compliance = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    client.set_compliance_address(&token, &compliance, &admin);

    let auths = e.auths();
    assert_eq!(auths.len(), 1);
    let (addr, _) = &auths[0];
    assert_eq!(addr, &admin);
}

#[test]
#[should_panic(expected = "Error(Contract, #398)")]
fn get_compliance_address_panics_when_not_configured() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    let _ = client.get_compliance_address(&token);
}

#[test]
fn set_identity_registry_storage_requires_manager_auth() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let irs = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    client.set_identity_registry_storage(&token, &irs, &manager);

    let auths = e.auths();
    assert_eq!(auths.len(), 1);
    let (addr, _) = &auths[0];
    assert_eq!(addr, &manager);
}

#[test]
fn add_allowed_country_requires_manager_auth() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    client.add_allowed_country(&token, &276, &manager);

    let auths = e.auths();
    assert_eq!(auths.len(), 1);
    let (addr, _) = &auths[0];
    assert_eq!(addr, &manager);
}

#[test]
#[should_panic(expected = "Error(Contract, #396)")]
fn on_transfer_panics_when_irs_not_configured() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let from = Address::generate(&e);
    let to = Address::generate(&e);
    let token = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    client.on_transfer(&snap(&from), &snap(&to), &100_i128, &TransferKind::Standard, &token);
}

#[test]
fn hooks_pass_for_allowed_recipient() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let from = Address::generate(&e);
    let token = Address::generate(&e);
    let allowed_to = Address::generate(&e);
    let amount = 100_i128;
    let client = create_client(&e, &admin, &manager);
    let irs_id = e.register(MockIRSContract, ());
    let irs = MockIRSContractClient::new(&e, &irs_id);

    irs.set_country_data_entries(
        &allowed_to,
        &vec![&e, individual_country(250), organization_country(276)],
    );

    client.set_identity_registry_storage(&token, &irs_id, &manager);
    client.add_allowed_country(&token, &276, &manager);

    client.on_transfer(&snap(&from), &snap(&allowed_to), &amount, &TransferKind::Standard, &token);
    client.on_created(&snap(&allowed_to), &amount, &token);
}

#[test]
#[should_panic(expected = "Error(Contract, #404)")]
fn on_transfer_panics_for_disallowed_recipient() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let from = Address::generate(&e);
    let token = Address::generate(&e);
    let disallowed_to = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);
    let irs_id = e.register(MockIRSContract, ());
    let irs = MockIRSContractClient::new(&e, &irs_id);

    irs.set_country_data_entries(&disallowed_to, &vec![&e, individual_country(250)]);

    client.set_identity_registry_storage(&token, &irs_id, &manager);
    client.add_allowed_country(&token, &276, &manager);

    client.on_transfer(
        &snap(&from),
        &snap(&disallowed_to),
        &100_i128,
        &TransferKind::Standard,
        &token,
    );
}

#[test]
#[should_panic(expected = "Error(Contract, #404)")]
fn on_created_panics_for_disallowed_recipient() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let token = Address::generate(&e);
    let disallowed_to = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);
    let irs_id = e.register(MockIRSContract, ());
    let irs = MockIRSContractClient::new(&e, &irs_id);

    irs.set_country_data_entries(&disallowed_to, &vec![&e, individual_country(250)]);

    client.set_identity_registry_storage(&token, &irs_id, &manager);
    client.add_allowed_country(&token, &276, &manager);

    client.on_created(&snap(&disallowed_to), &100_i128, &token);
}

#[test]
fn on_transfer_forced_is_exempt_from_policy() {
    let e = Env::default();
    e.mock_all_auths();
    let admin = Address::generate(&e);
    let manager = Address::generate(&e);
    let from = Address::generate(&e);
    let to = Address::generate(&e);
    let token = Address::generate(&e);
    let client = create_client(&e, &admin, &manager);

    // No IRS configured and no allowlist: a standard transfer would panic,
    // but a forced one passes through untouched.
    client.on_transfer(&snap(&from), &snap(&to), &100_i128, &TransferKind::Forced, &token);
}
