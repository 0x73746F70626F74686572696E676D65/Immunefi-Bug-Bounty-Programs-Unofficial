// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.6.0) (token/ERC20/extensions/ERC20Crosschain.sol)

pragma solidity ^0.8.26;

import {BridgeFungibleUpgradeable} from "../../../crosschain/bridges/abstract/BridgeFungibleUpgradeable.sol";
import {ERC20Upgradeable} from "../ERC20Upgradeable.sol";
import {Initializable} from "@openzeppelin/contracts/proxy/utils/Initializable.sol";

/**
 * @dev Extension of {ERC20} that makes it natively cross-chain using the ERC-7786 based {BridgeFungible}.
 *
 * This extension makes the token compatible with counterparts on other chains, which can be:
 * * {ERC20Crosschain} instances,
 * * {ERC20} instances that are bridged using {BridgeERC20},
 * * {ERC20Bridgeable} instances that are bridged using {BridgeERC7802}.
 *
 * It is mostly equivalent to inheriting from both {ERC20Bridgeable} and {BridgeERC7802}, and configuring them such
 * that:
 * * `token` (on the {BridgeERC7802} side) is `address(this)`,
 * * `_checkTokenBridge` (on the {ERC20Bridgeable} side) is implemented such that it only accepts self-calls.
 */
// slither-disable-next-line locked-ether
abstract contract ERC20CrosschainUpgradeable is Initializable, ERC20Upgradeable, BridgeFungibleUpgradeable {
    function __ERC20Crosschain_init() internal onlyInitializing {
    }

    function __ERC20Crosschain_init_unchained() internal onlyInitializing {
    }
    /// @dev Variant of {crosschainTransfer} that allows an authorized account (using ERC20 allowance) to operate on `from`'s assets.
    function crosschainTransferFrom(address from, bytes memory to, uint256 amount) public virtual returns (bytes32) {
        _spendAllowance(from, _msgSender(), amount);
        return _crosschainTransfer(from, to, amount);
    }

    /// @dev "Locking" tokens is achieved through burning
    function _onSend(address from, uint256 amount) internal virtual override {
        _burn(from, amount);
    }

    /// @dev "Unlocking" tokens is achieved through minting
    function _onReceive(address to, uint256 amount) internal virtual override {
        _mint(to, amount);
    }
}
