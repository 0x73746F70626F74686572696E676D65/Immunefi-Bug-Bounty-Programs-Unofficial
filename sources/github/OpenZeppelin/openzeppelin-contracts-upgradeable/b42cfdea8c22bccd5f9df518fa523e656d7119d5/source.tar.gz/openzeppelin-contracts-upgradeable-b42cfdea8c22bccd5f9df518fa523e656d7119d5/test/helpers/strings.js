// Capitalize the first char of a string
// Example: capitalize('uint256') → 'Uint256'
export const capitalize = str => str.charAt(0).toUpperCase() + str.slice(1);
