import { callAndGetResult } from '../../../helpers/event';
import { INTERFACE_IDS, INVALID_ID } from '../../../helpers/interface';
import { FhevmType } from '@fhevm/hardhat-plugin';
import { anyValue } from '@nomicfoundation/hardhat-chai-matchers/withArgs';
import { expect } from 'chai';
import { AddressLike, BytesLike } from 'ethers';
import { ethers, fhevm } from 'hardhat';

const transferEventSignature = 'ConfidentialTransfer(address,address,bytes32)';
const adminRole = ethers.ZeroHash;
const agentRole = ethers.id('AGENT_ROLE');

const fixture = async () => {
  const [admin, agent1, agent2, recipient, anyone, holder, ...others] = await ethers.getSigners();
  const token = await ethers.deployContract('ERC7984RwaMock', ['name', 'symbol', 'uri', admin.address]);
  await token.connect(admin).addAgent(agent1);
  token.connect(anyone);
  return { token, admin, agent1, agent2, recipient, anyone, holder, others };
};

describe('ERC7984Rwa', function () {
  describe('ERC165', async function () {
    it('should support interface', async function () {
      const { token } = await fixture();
      await expect(token.supportsInterface(INTERFACE_IDS.ERC7984)).to.eventually.be.true;
      await expect(token.supportsInterface(INTERFACE_IDS.ERC7984ERC20Wrapper)).to.eventually.be.false;
      await expect(token.supportsInterface(INTERFACE_IDS.ERC7984RWA)).to.eventually.be.true;
    });

    it('should not support interface', async function () {
      const { token } = await fixture();
      await expect(token.supportsInterface(INVALID_ID)).to.eventually.be.false;
    });
  });

  describe('Pausable', async function () {
    it('should pause & unpause', async function () {
      const { token, agent1 } = await fixture();
      expect(await token.paused()).is.false;
      await token.connect(agent1).pause();
      expect(await token.paused()).is.true;
      await token.connect(agent1).unpause();
      expect(await token.paused()).is.false;
    });

    it('should not pause if not agent', async function () {
      const { token, anyone } = await fixture();
      await expect(token.connect(anyone).pause())
        .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
        .withArgs(anyone.address, agentRole);
    });

    it('should not unpause if not agent', async function () {
      const { token, anyone } = await fixture();
      await expect(token.connect(anyone).unpause())
        .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
        .withArgs(anyone.address, agentRole);
    });
  });

  describe('Roles', async function () {
    it('should check admin', async function () {
      const { token, admin, anyone } = await fixture();
      expect(await token.isAdmin(admin)).is.true;
      expect(await token.isAdmin(anyone)).is.false;
    });

    it('should check/add/remove agent', async function () {
      const { token, admin, agent2 } = await fixture();
      expect(await token.isAgent(agent2)).is.false;
      await token.connect(admin).addAgent(agent2);
      expect(await token.isAgent(agent2)).is.true;
      await token.connect(admin).removeAgent(agent2);
      expect(await token.isAgent(agent2)).is.false;
    });

    it('should not add agent if not admin', async function () {
      const { token, agent1, anyone } = await fixture();
      await expect(token.connect(anyone).addAgent(agent1))
        .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
        .withArgs(anyone.address, adminRole);
    });

    it('should not remove agent if not admin', async function () {
      const { token, agent1, anyone } = await fixture();
      await expect(token.connect(anyone).removeAgent(agent1))
        .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
        .withArgs(anyone.address, adminRole);
    });
  });

  describe('ERC7984Restricted', async function () {
    it('should block & unblock', async function () {
      const { token, agent1, recipient } = await fixture();
      await expect(token.canTransact(recipient)).to.eventually.be.true;
      await token.connect(agent1).blockUser(recipient);
      await expect(token.canTransact(recipient)).to.eventually.be.false;
      await token.connect(agent1).unblockUser(recipient);
      await expect(token.canTransact(recipient)).to.eventually.be.true;
    });

    for (const arg of [true, false]) {
      it(`should not ${arg ? 'block' : 'unblock'} if not agent`, async function () {
        const { token, anyone } = await fixture();
        await expect(token.connect(anyone)[arg ? 'blockUser' : 'unblockUser'](anyone))
          .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
          .withArgs(anyone.address, agentRole);
      });
    }
  });

  describe('ERC7984Freezable', async function () {
    for (let withProof of [false, true]) {
      it(`should set and get confidential frozen ${withProof ? 'with proof' : ''}`, async function () {
        const { token, agent1, recipient } = await fixture();
        const amount = 100;
        let params = [recipient.address] as unknown as [
          account: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), agent1.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(agent1).createEncryptedAmount(amount);
          params.push(await token.connect(agent1).createEncryptedAmount.staticCall(amount));
        }
        await expect(
          await token
            .connect(agent1)
            [withProof ? 'setConfidentialFrozen(address,bytes32,bytes)' : 'setConfidentialFrozen(address,bytes32)'](
              ...params,
            ),
        ).to.emit(token, 'TokensFrozen');
        const frozenHandle = await token.confidentialFrozen(recipient.address);
        expect(frozenHandle).to.equal(ethers.hexlify(params[1]));
      });
    }

    for (let withProof of [false, true]) {
      it(`should not set confidential frozen ${withProof ? 'with proof' : ''} if not agent`, async function () {
        const { token, recipient, anyone } = await fixture();
        const amount = 100;
        let params = [recipient.address] as unknown as [
          account: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), anyone.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(anyone).createEncryptedAmount(amount);
          params.push(await token.connect(anyone).createEncryptedAmount.staticCall(amount));
        }
        await expect(
          token
            .connect(anyone)
            [withProof ? 'setConfidentialFrozen(address,bytes32,bytes)' : 'setConfidentialFrozen(address,bytes32)'](
              ...params,
            ),
        )
          .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
          .withArgs(anyone.address, agentRole);
      });
    }

    it(`should not set confidential frozen if amount not allowed`, async function () {
      const { token, recipient, agent1, anyone } = await fixture();
      const amount = 200;
      await token.connect(anyone).createEncryptedAmount(amount);
      const encryptedAmount = await token.connect(anyone).createEncryptedAmount.staticCall(amount);
      await expect(token.connect(agent1)['setConfidentialFrozen(address,bytes32)'](recipient.address, encryptedAmount))
        .to.be.revertedWithCustomError(token, 'ERC7984UnauthorizedUseOfEncryptedAmount')
        .withArgs(encryptedAmount, agent1.address);
    });
  });

  describe('Mintable', async function () {
    for (const withProof of [true, false]) {
      it(`should mint ${withProof ? 'with proof' : ''}`, async function () {
        const { agent1, recipient, token } = await fixture();
        const amount = 100;
        let params = [recipient.address] as unknown as [
          account: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), agent1.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(agent1).createEncryptedAmount(amount);
          params.push(await token.connect(agent1).createEncryptedAmount.staticCall(amount));
        }
        const [, , transferredHandle] = await callAndGetResult(
          token
            .connect(agent1)
            [withProof ? 'confidentialMint(address,bytes32,bytes)' : 'confidentialMint(address,bytes32)'](...params),
          transferEventSignature,
        );
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, await token.getAddress(), recipient),
        ).to.eventually.equal(amount);
        const balanceHandle = await token.confidentialBalanceOf(recipient);
        await token.connect(agent1).getHandleAllowance(balanceHandle, agent1, true);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, balanceHandle, await token.getAddress(), agent1),
        ).to.eventually.equal(amount);
      });
    }

    for (let withProof of [false, true]) {
      it(`should not mint ${withProof ? 'with proof' : ''} if not agent`, async function () {
        const { token, recipient, anyone } = await fixture();
        const amount = 100;
        let params = [recipient.address] as unknown as [
          account: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), anyone.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(anyone).createEncryptedAmount(amount);
          params.push(await token.connect(anyone).createEncryptedAmount.staticCall(amount));
        }
        await expect(
          token
            .connect(anyone)
            [withProof ? 'confidentialMint(address,bytes32,bytes)' : 'confidentialMint(address,bytes32)'](...params),
        )
          .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
          .withArgs(anyone.address, agentRole);
      });
    }

    it(`should not mint if amount not allowed`, async function () {
      const { token, recipient, agent1, anyone } = await fixture();
      const amount = 200;
      await token.connect(anyone).createEncryptedAmount(amount);
      const encryptedAmount = await token.connect(anyone).createEncryptedAmount.staticCall(amount);
      await expect(token.connect(agent1)['confidentialMint(address,bytes32)'](recipient.address, encryptedAmount))
        .to.be.revertedWithCustomError(token, 'ERC7984UnauthorizedUseOfEncryptedAmount')
        .withArgs(encryptedAmount, agent1.address);
    });

    it('should not mint if paused', async function () {
      const { token, agent1, recipient } = await fixture();
      await token.connect(agent1).pause();
      const encryptedInput = await fhevm
        .createEncryptedInput(await token.getAddress(), agent1.address)
        .add64(100)
        .encrypt();
      await expect(
        token
          .connect(agent1)
          ['confidentialMint(address,bytes32,bytes)'](recipient, encryptedInput.handles[0], encryptedInput.inputProof),
      ).to.be.revertedWithCustomError(token, 'EnforcedPause');
    });
  });

  describe('Burnable', async function () {
    for (const withProof of [true, false]) {
      it(`should burn agent ${withProof ? 'with proof' : ''}`, async function () {
        const { agent1, recipient, token } = await fixture();
        const encryptedInput = await fhevm
          .createEncryptedInput(await token.getAddress(), agent1.address)
          .add64(100)
          .encrypt();
        await token
          .connect(agent1)
          ['confidentialMint(address,bytes32,bytes)'](recipient, encryptedInput.handles[0], encryptedInput.inputProof);
        const balanceBeforeHandle = await token.confidentialBalanceOf(recipient);
        await token.connect(agent1).getHandleAllowance(balanceBeforeHandle, agent1, true);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, balanceBeforeHandle, await token.getAddress(), agent1),
        ).to.eventually.greaterThan(0);
        const amount = 100;
        let params = [recipient.address] as unknown as [
          account: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), agent1.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(agent1).createEncryptedAmount(amount);
          params.push(await token.connect(agent1).createEncryptedAmount.staticCall(amount));
        }
        const [, , transferredHandle] = await callAndGetResult(
          token
            .connect(agent1)
            [withProof ? 'confidentialBurn(address,bytes32,bytes)' : 'confidentialBurn(address,bytes32)'](...params),
          transferEventSignature,
        );
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, await token.getAddress(), recipient),
        ).to.eventually.equal(amount);
        const balanceHandle = await token.confidentialBalanceOf(recipient);
        await token.connect(agent1).getHandleAllowance(balanceHandle, agent1, true);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, balanceHandle, await token.getAddress(), agent1),
        ).to.eventually.equal(0);
      });
    }

    for (let withProof of [false, true]) {
      it(`should not burn ${withProof ? 'with proof' : ''} if not agent`, async function () {
        const { token, recipient, anyone } = await fixture();
        const amount = 100;
        let params = [recipient.address] as unknown as [
          account: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), anyone.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(anyone).createEncryptedAmount(amount);
          params.push(await token.connect(anyone).createEncryptedAmount.staticCall(amount));
        }
        await expect(
          token
            .connect(anyone)
            [withProof ? 'confidentialBurn(address,bytes32,bytes)' : 'confidentialBurn(address,bytes32)'](...params),
        )
          .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
          .withArgs(anyone.address, agentRole);
      });
    }

    it(`should not burn if amount not allowed`, async function () {
      const { token, recipient, agent1, anyone } = await fixture();
      const amount = 200;
      await token.connect(anyone).createEncryptedAmount(amount);
      const encryptedAmount = await token.connect(anyone).createEncryptedAmount.staticCall(amount);
      await expect(token.connect(agent1)['confidentialBurn(address,bytes32)'](recipient.address, encryptedAmount))
        .to.be.revertedWithCustomError(token, 'ERC7984UnauthorizedUseOfEncryptedAmount')
        .withArgs(encryptedAmount, agent1.address);
    });

    it('should not burn if paused', async function () {
      const { token, agent1, recipient } = await fixture();
      await token.connect(agent1).pause();
      const encryptedInput = await fhevm
        .createEncryptedInput(await token.getAddress(), agent1.address)
        .add64(100)
        .encrypt();
      await expect(
        token
          .connect(agent1)
          ['confidentialBurn(address,bytes32,bytes)'](recipient, encryptedInput.handles[0], encryptedInput.inputProof),
      ).to.be.revertedWithCustomError(token, 'EnforcedPause');
    });
  });

  describe('Force transfer', async function () {
    for (const withProof of [true, false]) {
      it(`should force transfer${withProof ? ' with proof' : ''}`, async function () {
        const { agent1, recipient, anyone, token } = await fixture();
        await token['$_mint(address,uint64)'](recipient, 100);
        const amount = 25;
        let params = [recipient.address, anyone.address] as unknown as [
          from: AddressLike,
          to: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), agent1.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(agent1).createEncryptedAmount(amount);
          params.push(await token.connect(agent1).createEncryptedAmount.staticCall(amount));
        }
        await token.connect(agent1).pause();
        await token.connect(agent1).blockUser(recipient);
        const tx = token
          .connect(agent1)
          [
            withProof
              ? 'forceConfidentialTransferFrom(address,address,bytes32,bytes)'
              : 'forceConfidentialTransferFrom(address,address,bytes32)'
          ](...params);
        const [from, to, transferredHandle] = await callAndGetResult(tx, transferEventSignature);
        expect(from).to.equal(recipient.address);
        expect(to).to.equal(anyone.address);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, await token.getAddress(), anyone),
        ).to.eventually.equal(amount);
        const balanceHandle = await token.confidentialBalanceOf(recipient);
        await token.connect(agent1).getHandleAllowance(balanceHandle, agent1, true);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, balanceHandle, await token.getAddress(), agent1),
        ).to.eventually.equal(75);
      });
    }

    for (const withProof of [true, false]) {
      it(`should not force transfer frozen funds ${withProof ? 'with proof' : ''}`, async function () {
        const { agent1, recipient, anyone, token } = await fixture();
        await token['$_mint(address,uint64)'](recipient, 100);
        // set frozen (only 20 available but about to force transfer 25)
        await token.$_setConfidentialFrozen(recipient, 80);
        const amount = 25;
        let params = [recipient.address, anyone.address] as unknown as [
          from: AddressLike,
          to: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), agent1.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(agent1).createEncryptedAmount(amount);
          params.push(await token.connect(agent1).createEncryptedAmount.staticCall(amount));
        }
        const [from, to, transferredHandle] = await callAndGetResult(
          token
            .connect(agent1)
            [
              withProof
                ? 'forceConfidentialTransferFrom(address,address,bytes32,bytes)'
                : 'forceConfidentialTransferFrom(address,address,bytes32)'
            ](...params),
          transferEventSignature,
        );
        expect(from).to.equal(recipient.address);
        expect(to).to.equal(anyone.address);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, await token.getAddress(), recipient),
        ).to.eventually.equal(0);

        const balanceHandle = await token.confidentialBalanceOf(recipient);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, balanceHandle, await token.getAddress(), recipient),
        ).to.eventually.equal(100);

        const frozenHandle = await token.confidentialFrozen(recipient);
        await expect(
          fhevm.userDecryptEuint(FhevmType.euint64, frozenHandle, await token.getAddress(), recipient),
        ).to.eventually.equal(80);
      });
    }

    for (let withProof of [false, true]) {
      it(`should not force transfer ${withProof ? 'with proof' : ''} if not agent`, async function () {
        const { token, recipient, anyone } = await fixture();
        const amount = 100;
        let params = [recipient.address, anyone.address] as unknown as [
          from: AddressLike,
          to: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), anyone.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(anyone).createEncryptedAmount(amount);
          params.push(await token.connect(anyone).createEncryptedAmount.staticCall(amount));
        }
        await expect(
          token
            .connect(anyone)
            [
              withProof
                ? 'forceConfidentialTransferFrom(address,address,bytes32,bytes)'
                : 'forceConfidentialTransferFrom(address,address,bytes32)'
            ](...params),
        )
          .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
          .withArgs(anyone.address, agentRole);
      });
    }

    it('should not force transfer if amount not allowed', async function () {
      const { token, recipient, agent1, anyone } = await fixture();
      const amount = 200;
      await token.connect(anyone).createEncryptedAmount(amount);
      const encryptedAmount = await token.connect(anyone).createEncryptedAmount.staticCall(amount);
      await expect(
        token
          .connect(agent1)
          ['forceConfidentialTransferFrom(address,address,bytes32)'](
            recipient.address,
            anyone.address,
            encryptedAmount,
          ),
      )
        .to.be.revertedWithCustomError(token, 'ERC7984UnauthorizedUseOfEncryptedAmount')
        .withArgs(encryptedAmount, agent1.address);
    });

    for (const withProof of [true, false]) {
      it(`should force transfer if receiver blocked ${withProof ? 'with proof' : ''}`, async function () {
        const { token, agent1, recipient, anyone } = await fixture();
        let params = [recipient.address, anyone.address] as unknown as [
          from: AddressLike,
          to: AddressLike,
          encryptedAmount: BytesLike,
          inputProof: BytesLike,
        ];
        const amount = 100;
        if (withProof) {
          const { handles, inputProof } = await fhevm
            .createEncryptedInput(await token.getAddress(), agent1.address)
            .add64(amount)
            .encrypt();
          params.push(handles[0], inputProof);
        } else {
          await token.connect(agent1).createEncryptedAmount(amount);
          params.push(await token.connect(agent1).createEncryptedAmount.staticCall(amount));
        }
        await token.connect(agent1).blockUser(anyone);
        await token
          .connect(agent1)
          [
            withProof
              ? 'forceConfidentialTransferFrom(address,address,bytes32,bytes)'
              : 'forceConfidentialTransferFrom(address,address,bytes32)'
          ](...params);
      });
    }
  });

  describe('Transfer', async function () {
    it('should transfer', async function () {
      const { token, agent1, recipient, anyone } = await fixture();
      await token['$_mint(address,uint64)'](recipient, 100);
      // set frozen (50 available and about to transfer 25)
      await token.$_setConfidentialFrozen(recipient, 50);
      const amount = 25;
      const encryptedTransferValueInput = await fhevm
        .createEncryptedInput(await token.getAddress(), recipient.address)
        .add64(amount)
        .encrypt();
      const tx = token
        .connect(recipient)
        ['confidentialTransfer(address,bytes32,bytes)'](
          anyone,
          encryptedTransferValueInput.handles[0],
          encryptedTransferValueInput.inputProof,
        );
      const [from, to, transferredHandle] = await callAndGetResult(tx, transferEventSignature);
      expect(from).equal(recipient.address);
      expect(to).equal(anyone.address);
      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, await token.getAddress(), anyone),
      ).to.eventually.equal(amount);
      await expect(
        fhevm.userDecryptEuint(
          FhevmType.euint64,
          await token.confidentialBalanceOf(anyone),
          await token.getAddress(),
          anyone,
        ),
      ).to.eventually.equal(amount);
      await expect(
        fhevm.userDecryptEuint(
          FhevmType.euint64,
          await token.confidentialBalanceOf(recipient),
          await token.getAddress(),
          recipient,
        ),
      ).to.eventually.equal(75);
    });

    it('should not transfer if paused', async function () {
      const { token, agent1, recipient, anyone } = await fixture();
      const encryptedTransferValueInput = await fhevm
        .createEncryptedInput(await token.getAddress(), recipient.address)
        .add64(25)
        .encrypt();
      await token.connect(agent1).pause();
      await expect(
        token
          .connect(recipient)
          ['confidentialTransfer(address,bytes32,bytes)'](
            anyone,
            encryptedTransferValueInput.handles[0],
            encryptedTransferValueInput.inputProof,
          ),
      ).to.be.revertedWithCustomError(token, 'EnforcedPause');
    });

    it('should not transfer if frozen', async function () {
      const { token, agent1, recipient, anyone } = await fixture();
      await token['$_mint(address,uint64)'](recipient, 100);
      // set frozen (20 available but about to transfer 25)
      await token.$_setConfidentialFrozen(recipient, 80);
      const encryptedTransferValueInput = await fhevm
        .createEncryptedInput(await token.getAddress(), recipient.address)
        .add64(25)
        .encrypt();
      const [, , transferredHandle] = await callAndGetResult(
        token
          .connect(recipient)
          ['confidentialTransfer(address,bytes32,bytes)'](
            anyone,
            encryptedTransferValueInput.handles[0],
            encryptedTransferValueInput.inputProof,
          ),
        transferEventSignature,
      );
      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, await token.getAddress(), anyone),
      ).to.eventually.equal(0);
      // Balance is unchanged
      await expect(
        fhevm.userDecryptEuint(
          FhevmType.euint64,
          await token.confidentialBalanceOf(recipient),
          await token.getAddress(),
          recipient,
        ),
      ).to.eventually.equal(100);
    });

    for (const arg of [true, false]) {
      it(`should not transfer if ${arg ? 'sender' : 'receiver'} blocked `, async function () {
        const { token, agent1, recipient, anyone } = await fixture();
        const account = arg ? recipient : anyone;
        const encryptedInput = await fhevm
          .createEncryptedInput(await token.getAddress(), recipient.address)
          .add64(25)
          .encrypt();
        await token.connect(agent1).blockUser(account);

        await expect(
          token
            .connect(recipient)
            ['confidentialTransfer(address,bytes32,bytes)'](
              anyone,
              encryptedInput.handles[0],
              encryptedInput.inputProof,
            ),
        )
          .to.be.revertedWithCustomError(token, 'UserRestricted')
          .withArgs(account);
      });
    }
  });

  describe('Recover', function () {
    it('should be gated to agents', async function () {
      const { token, anyone, others, recipient } = await fixture();
      await expect(token.connect(anyone).recoverAddress(recipient, others[0]))
        .to.be.revertedWithCustomError(token, 'AccessControlUnauthorizedAccount')
        .withArgs(anyone.address, agentRole);
    });

    it('should fail if lost and new accounts are the same', async function () {
      const { token, recipient, agent1 } = await fixture();
      await expect(token.connect(agent1).recoverAddress(recipient, recipient)).to.be.revertedWithCustomError(
        token,
        'ERC7984RwaSelfRecoveryNotAllowed',
      );
    });

    it('should emit recovered event', async function () {
      const { token, anyone, recipient, agent1 } = await fixture();
      await token['$_mint(address,uint64)'](recipient, 100);
      await expect(token.connect(agent1).recoverAddress(recipient, anyone))
        .to.emit(token, 'TokensRecovered')
        .withArgs(recipient, anyone, anyValue);

      const [, , amount] = (await token.queryFilter(token.filters.TokensRecovered()))[0].args;
      await expect(fhevm.userDecryptEuint(FhevmType.euint64, amount, token, agent1)).to.eventually.eq(100);
    });

    it('should transfer frozen tokens', async function () {
      const { token, anyone, recipient, agent1 } = await fixture();
      await token['$_mint(address,uint64)'](recipient, 100);

      await token.$_setConfidentialFrozen(recipient, 50);

      await token.connect(agent1).recoverAddress(recipient, anyone);

      const transferEvent = (await token.queryFilter(token.filters.ConfidentialTransfer()))[1];
      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, transferEvent.args[2], token.target, anyone),
      ).to.eventually.eq(100);
    });

    it('should pass on frozen amounts', async function () {
      const { token, anyone, recipient, agent1 } = await fixture();
      await token['$_mint(address,uint64)'](recipient, 100);

      await token.$_setConfidentialFrozen(recipient, 50);

      const logs = (await (await token.connect(agent1).recoverAddress(recipient, anyone)).wait())!.logs;

      const tokensFrozenTopic = ethers.id('TokensFrozen(address,bytes32)');
      const rescuedAccountFreezeEvents = logs.filter(
        log =>
          log.address == token.target &&
          log.topics[0] == tokensFrozenTopic &&
          log.topics[1] == ethers.AbiCoder.defaultAbiCoder().encode(['address'], [recipient.address]),
      );

      expect(rescuedAccountFreezeEvents[0].data).to.eq(ethers.ZeroHash);
      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, rescuedAccountFreezeEvents[1].data, token.target, recipient),
      ).to.eventually.eq(0);

      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, await token.confidentialFrozen(anyone), token.target, anyone),
      ).to.eventually.eq(50);
    });

    it('should add to existing frozen value', async function () {
      const { token, holder, recipient, agent1 } = await fixture();

      await token['$_mint(address,uint64)'](holder, 100);
      await token['$_mint(address,uint64)'](recipient, 50);

      await token.$_setConfidentialFrozen(holder, 20);
      await token.$_setConfidentialFrozen(recipient, 50);

      await token.connect(agent1).recoverAddress(holder, recipient);

      const recipientFrozenAmount = await token.confidentialFrozen(recipient);
      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, recipientFrozenAmount, token.target, recipient),
      ).to.eventually.eq(70);
    });

    it('should block new account if lost account is blocked', async function () {
      const { token, anyone, recipient, agent1 } = await fixture();
      await token['$_mint(address,uint64)'](recipient, 100);
      await token.connect(agent1).blockUser(recipient);

      await expect(token.canTransact(anyone)).to.eventually.be.true;

      await token.connect(agent1).recoverAddress(recipient, anyone);

      await expect(token.canTransact(anyone)).to.eventually.be.false;
    });

    it('should retain frozen value if recovery fails', async function () {
      const { token, anyone, recipient, agent1 } = await fixture();

      await token['$_mint(address,uint64)'](recipient, 100);
      await token.$_setConfidentialFrozen(recipient, 50);

      await token.setFailTransfer(true);

      await token.connect(agent1).recoverAddress(recipient, anyone);

      const recipientFrozenAmount = await token.confidentialFrozen(recipient);
      const anyoneFrozenAmount = await token.confidentialFrozen(anyone);

      const recipientBalance = await token.confidentialBalanceOf(recipient);

      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, recipientFrozenAmount, token.target, recipient),
      ).to.eventually.eq(50);
      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, anyoneFrozenAmount, token.target, anyone),
      ).to.eventually.eq(0);

      await expect(
        fhevm.userDecryptEuint(FhevmType.euint64, recipientBalance, token.target, recipient),
      ).to.eventually.eq(100);
    });
  });

  describe('Multicall', async function () {
    it('should atomically unfreeze and force transfer', async function () {
      const { token, agent1, holder, recipient } = await fixture();
      const balance = 100;
      const transferAmount = 75;

      await token['$_mint(address,uint64)'](holder, balance);
      // Freeze all tokens on the from account so even a force transfer would otherwise move 0 tokens
      await token.$_setConfidentialFrozen(holder, balance);
      // Pause the contract; force transfer bypasses the pause check, but a regular transfer would not
      await token.connect(agent1).pause();
      expect(await token.paused()).to.be.true;

      // Encrypted inputs are bound to msg.sender (agent1). Multicall uses delegatecall so msg.sender
      // is preserved inside each sub-call, and the proofs remain valid.
      const unfreezeInput = await fhevm
        .createEncryptedInput(await token.getAddress(), agent1.address)
        .add64(25)
        .encrypt();
      const transferInput = await fhevm
        .createEncryptedInput(await token.getAddress(), agent1.address)
        .add64(transferAmount)
        .encrypt();

      const unfreezeData = token.interface.encodeFunctionData('setConfidentialFrozen(address,bytes32,bytes)', [
        holder.address,
        unfreezeInput.handles[0],
        unfreezeInput.inputProof,
      ]);
      const forceTransferData = token.interface.encodeFunctionData(
        'forceConfidentialTransferFrom(address,address,bytes32,bytes)',
        [holder.address, recipient.address, transferInput.handles[0], transferInput.inputProof],
      );

      const tx = token.connect(agent1).multicall([unfreezeData, forceTransferData]);
      const [, , transferredHandle] = await callAndGetResult(tx, transferEventSignature);
      await expect(fhevm.userDecryptEuint(FhevmType.euint64, transferredHandle, token, recipient)).to.eventually.equal(
        transferAmount,
      );
    });
  });
});
