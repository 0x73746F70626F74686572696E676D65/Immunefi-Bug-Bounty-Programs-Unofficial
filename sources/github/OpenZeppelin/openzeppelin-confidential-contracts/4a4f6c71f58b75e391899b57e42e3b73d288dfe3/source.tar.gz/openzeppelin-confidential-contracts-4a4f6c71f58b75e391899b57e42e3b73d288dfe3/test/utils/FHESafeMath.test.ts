import { FHESafeMathMock } from '../../types/contracts/mocks/utils/FHESafeMathMock';
import { callAndGetResult } from '../helpers/event';
import { FhevmType } from '@fhevm/hardhat-plugin';
import { HardhatEthersSigner } from '@nomicfoundation/hardhat-ethers/signers';
import { expect } from 'chai';
import { BigNumberish } from 'ethers';
import { ethers, fhevm } from 'hardhat';

const MaxUint64 = BigInt('0xffffffffffffffff');
const handleCreatedSignature = 'HandleCreated(bytes32)';
const resultComputedSignature = 'ResultComputed(bytes32,bytes32)';
const saturatedResultComputedSignature = 'SaturatedResultComputed(bytes32)';
let fheSafeMath: FHESafeMathMock;
let account: HardhatEthersSigner;

describe('FHESafeMath', function () {
  beforeEach(async function () {
    fheSafeMath = (await ethers.deployContract('FHESafeMathMock')) as any as FHESafeMathMock;
    [account] = await ethers.getSigners();
  });

  describe('try increase', function () {
    for (const args of [
      // a + b = c & success
      [undefined, undefined, undefined, true],
      [undefined, 0, 0, true],
      [undefined, 1, 1, true],
      [0, undefined, 0, true],
      [1, undefined, 1, true],
      [MaxUint64, 0, MaxUint64, true],
      [0, MaxUint64, MaxUint64, true],
      [MaxUint64, 1, MaxUint64, false],
      [1, MaxUint64, 1, false],
    ]) {
      it(`${args[0]} + ${args[1]} = ${args[2]} & ${args[3] ? 'success' : 'failure'}`, async function () {
        const [a, b, c, expected] = args as [number, number, number, boolean];
        const [handleA] =
          a !== undefined
            ? await callAndGetResult(fheSafeMath.createHandle(a), handleCreatedSignature)
            : [ethers.ZeroHash];
        const [handleB] =
          b !== undefined
            ? await callAndGetResult(fheSafeMath.createHandle(b), handleCreatedSignature)
            : [ethers.ZeroHash];
        const [success, updated] = await callAndGetResult(
          fheSafeMath.tryIncrease(handleA, handleB),
          resultComputedSignature,
        );
        await expect(fhevm.userDecryptEbool(success, fheSafeMath.target, account)).to.eventually.equal(expected);
        if (c !== undefined) {
          await expect(
            fhevm.userDecryptEuint(FhevmType.euint64, updated, fheSafeMath.target, account),
          ).to.eventually.equal(c);
        } else {
          expect(updated).to.eq(ethers.ZeroHash);
        }
      });
    }
  });

  describe('try decrease', function () {
    for (const args of [
      // a - b = c & success
      [undefined, undefined, undefined, true],
      [undefined, 0, 0, true],
      [0, undefined, 0, true],
      [1, 1, 0, true],
      [undefined, 1, 0, false],
      [0, 1, 0, false],
    ]) {
      it(`${args[0]} - ${args[1]} = ${args[2]} & ${args[3] ? 'success' : 'failure'}`, async function () {
        const [a, b, c, expected] = args as [number, number, number, boolean];
        const [handleA] =
          a !== undefined
            ? await callAndGetResult(fheSafeMath.createHandle(a), handleCreatedSignature)
            : [ethers.ZeroHash];
        const [handleB] =
          b !== undefined
            ? await callAndGetResult(fheSafeMath.createHandle(b), handleCreatedSignature)
            : [ethers.ZeroHash];
        const [success, updated] = await callAndGetResult(
          fheSafeMath.tryDecrease(handleA, handleB),
          resultComputedSignature,
        );
        if (c !== undefined) {
          await expect(
            fhevm.userDecryptEuint(FhevmType.euint64, updated, fheSafeMath.target, account),
          ).to.eventually.equal(c);
        } else {
          expect(updated).to.eq(ethers.ZeroHash);
        }
        await expect(fhevm.userDecryptEbool(success, fheSafeMath.target, account)).to.eventually.equal(expected);
      });
    }
  });

  const addArgsOptions: [BigNumberish | undefined, BigNumberish | undefined, BigNumberish | undefined, boolean][] = [
    // a + b = c & success
    [undefined, undefined, undefined, true],
    [undefined, 1, 1, true],
    [1, undefined, 1, true],
    [1, 1, 2, true],
    [0, 1, 1, true],
    [0, MaxUint64, MaxUint64, true],
    [1, MaxUint64, 0, false],
    [MaxUint64 - 1n, 2, 0, false],
    [MaxUint64, MaxUint64, 0, false],
  ];
  const subArgsOptions: [BigNumberish | undefined, BigNumberish | undefined, BigNumberish | undefined, boolean][] = [
    // a - b = c & success
    [undefined, undefined, undefined, true],
    [undefined, 0, 0, true],
    [0, undefined, 0, true],
    [1, 1, 0, true],
    [1, undefined, 1, true],
    [undefined, 1, 0, false],
    [0, 1, 0, false],
    [MaxUint64, MaxUint64, 0, true],
  ];

  for (const params of [
    {
      functionSignature: 'tryAdd(bytes32,bytes32)',
      argsOptions: addArgsOptions,
      operation: '+',
    },
    {
      functionSignature: 'trySub(bytes32,bytes32)',
      argsOptions: subArgsOptions,
      operation: '-',
    },
  ]) {
    describe(`try ${params.functionSignature.startsWith('tryAdd') ? 'add' : 'sub'}`, function () {
      for (const args of params.argsOptions) {
        it(`${args[0]} ${params.operation} ${args[1]} = ${args[2]} & ${
          args[3] ? 'success' : 'failure'
        }`, async function () {
          const [a, b, c, expected] = args;
          const [handleA] =
            a !== undefined
              ? await callAndGetResult(fheSafeMath.createHandle(a), handleCreatedSignature)
              : [ethers.ZeroHash];
          const [handleB] =
            b !== undefined
              ? await callAndGetResult(fheSafeMath.createHandle(b), handleCreatedSignature)
              : [ethers.ZeroHash];
          const [success, updated] = await callAndGetResult(
            (fheSafeMath as any)[params.functionSignature](handleA, handleB),
            resultComputedSignature,
          );
          if (c !== undefined) {
            await expect(
              fhevm.userDecryptEuint(FhevmType.euint64, updated, fheSafeMath.target, account),
            ).to.eventually.equal(c);
          } else {
            expect(updated).to.eq(ethers.ZeroHash);
          }
          await expect(fhevm.userDecryptEbool(success, fheSafeMath.target, account)).to.eventually.equal(expected);
        });
      }
    });
  }

  const saturatingAddArgsOptions: [BigNumberish | undefined, BigNumberish | undefined, BigNumberish | undefined][] = [
    // a + b = c (saturating at MaxUint64)
    [undefined, undefined, undefined],
    [undefined, 0, 0],
    [undefined, 1, 1],
    [0, undefined, 0],
    [1, undefined, 1],
    [0, 0, 0],
    [1, 1, 2],
    [MaxUint64, 0, MaxUint64],
    [0, MaxUint64, MaxUint64],
    [MaxUint64, 1, MaxUint64],
    [1, MaxUint64, MaxUint64],
    [MaxUint64 - 1n, 2, MaxUint64],
    [MaxUint64, MaxUint64, MaxUint64],
  ];

  const saturatingSubArgsOptions: [BigNumberish | undefined, BigNumberish | undefined, BigNumberish | undefined][] = [
    // a - b = c (saturating at 0)
    [undefined, undefined, 0],
    [undefined, 0, 0],
    [0, undefined, 0],
    [1, undefined, 1],
    [0, 0, 0],
    [1, 1, 0],
    [5, 3, 2],
    [0, 1, 0],
    [3, 5, 0],
    [MaxUint64, 0, MaxUint64],
    [MaxUint64, 1, MaxUint64 - 1n],
    [MaxUint64, MaxUint64, 0],
    [0, MaxUint64, 0],
    [1, MaxUint64, 0],
  ];

  for (const params of [
    {
      functionSignature: 'saturatingAdd(bytes32,bytes32)',
      argsOptions: saturatingAddArgsOptions,
      operation: '+',
    },
    {
      functionSignature: 'saturatingSub(bytes32,bytes32)',
      argsOptions: saturatingSubArgsOptions,
      operation: '-',
    },
  ]) {
    describe(`saturating ${params.functionSignature.startsWith('saturatingAdd') ? 'add' : 'sub'}`, function () {
      for (const args of params.argsOptions) {
        it(`${args[0]} ${params.operation} ${args[1]} = ${args[2]}`, async function () {
          const [a, b, c] = args;
          const [handleA] =
            a !== undefined
              ? await callAndGetResult(fheSafeMath.createHandle(a), handleCreatedSignature)
              : [ethers.ZeroHash];
          const [handleB] =
            b !== undefined
              ? await callAndGetResult(fheSafeMath.createHandle(b), handleCreatedSignature)
              : [ethers.ZeroHash];
          const [result] = await callAndGetResult(
            (fheSafeMath as any)[params.functionSignature](handleA, handleB),
            saturatedResultComputedSignature,
          );
          if (c !== undefined) {
            await expect(
              fhevm.userDecryptEuint(FhevmType.euint64, result, fheSafeMath.target, account),
            ).to.eventually.equal(c);
          } else {
            expect(result).to.eq(ethers.ZeroHash);
          }
        });
      }
    });
  }
});
