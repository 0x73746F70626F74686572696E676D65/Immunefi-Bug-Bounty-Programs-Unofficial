// SPDX-License-Identifier: MIT

pragma solidity ^0.8.27;

import {FHE, euint64, externalEuint64} from "@fhevm/solidity/lib/FHE.sol";
import {ERC7984Freezable} from "../../../../token/ERC7984/extensions/ERC7984Freezable.sol";
import {HandleAccessManager} from "../../../../utils/HandleAccessManager.sol";
import {ERC7984Mock} from "../ERC7984Mock.sol";

contract ERC7984FreezableMock is ERC7984Mock, ERC7984Freezable, HandleAccessManager {
    constructor(string memory name, string memory symbol, string memory tokenUri) ERC7984Mock(name, symbol, tokenUri) {}

    function _update(
        address from,
        address to,
        euint64 amount
    ) internal virtual override(ERC7984Mock, ERC7984Freezable) returns (euint64) {
        return super._update(from, to, amount);
    }

    // solhint-disable-next-line func-name-mixedcase
    function $_setConfidentialFrozen(
        address account,
        externalEuint64 encryptedAmount,
        bytes calldata inputProof
    ) public virtual {
        _setConfidentialFrozen(account, FHE.fromExternal(encryptedAmount, inputProof));
    }

    function confidentialAvailableAccess(address account) public {
        euint64 available = _confidentialAvailable(account);
        FHE.allowThis(available);
        getHandleAllowance(euint64.unwrap(available), account, true);
    }

    function _validateHandleAllowance(bytes32) internal pure override returns (bool) {
        return true;
    }
}
