import "./Styles.scss";

import React from "react";

interface StatusData {
    status: string;
}

interface StatusLabels {
    SIGN?: string;
    QUEUING?: string;
    QUEUED?: string;
    CONFIRMING?: string;
    SUCCESS?: string;
    ERROR?: string;
    [key: string]: string | undefined;
}

interface TXStatusProps {
    statusData: StatusData;
    statusLabels: StatusLabels;
}

type StepType = "SIGN" | "QUEUING" | "QUEUED" | "SUCCESS";

export default function TXStatus({
    statusData,
    statusLabels,
}: TXStatusProps): JSX.Element {
    const { status } = statusData;

    // List of steps in order
    const steps: StepType[] = ["SIGN", "QUEUING", "QUEUED", "SUCCESS"];

    // Get the index of the current step
    const stepIndex: number = steps.indexOf(status as StepType);

    // Mapping of statuses to icon classes
    const statusIcons: { [key: string]: string } = {
        SIGN: "icon-tx-signWallet",
        QUEUING: "icon-operation-tx-queuing",
        QUEUED: "icon-operation-tx-queued",
        CONFIRMING: "tx-status-icon-CONFIRMING",
        SUCCESS: "tx-status-icon-CONFIRMED",
        ERROR: "tx-status-icon-FAILED",
    };

    return (
        <div className="tx-container">
            {/* Handle SUCCESS case */}
            {status === "SUCCESS" ? (
                <div className="tx-success">
                    <div
                        className={`tx-success__icon tx-feedback-icon ${statusIcons[status] || "icon-waiting"} tx-status-icon-CONFIRMED`}
                    ></div>
                    <span className="tx-success__message">
                        {statusLabels.SUCCESS || "Transaction successful!"}
                    </span>
                </div>
            ) : status === "ERROR" ? (
                /* Handle ERROR case */
                <div className="tx-error">
                    <div
                        className={`tx-error__icon tx-feedback-icon ${statusIcons[status] || "icon-waiting"}`}
                    ></div>
                    <span className="tx-error__message">
                        {statusLabels.ERROR || "Transaction failed"}
                    </span>
                </div>
            ) : (
                /* Default case: Show step-by-step progress */
                <div className="txSteps-container">
                    {steps.map((step: StepType, index: number) => {
                        const label: string = statusLabels[step] || step;
                        const [done, checked] =
                            index < stepIndex
                                ? ["done", "checkChecked"]
                                : index == stepIndex
                                  ? ["doing", "inProgress"]
                                  : ["todo", "checkUnchecked"];

                        return (
                            <div
                                key={step}
                                className={`stepRow txSteps--${done}`}
                                data-testid={`step-${step}-${index}-${done}`}
                            >
                                <div
                                    className={`txSteps__icon icon-tx-${checked}`}
                                ></div>
                                {label}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
