import { useEffect, useState } from "react";

export type Theme = "light" | "dark";

interface UseThemeResult {
    theme: Theme;
    toggleTheme: () => void;
}

const useTheme = (): UseThemeResult => {
    const [theme, setTheme] = useState<Theme>(() => {
        // Verificar si el tema está guardado en localStorage
        const root = document.querySelector(":root");
        let defaulTheme: Theme = "light";
        if (root) {
            const cssTheme = getComputedStyle(root)
                .getPropertyValue("--default-theme")
                .split('"')
                .join("");
            if (cssTheme === "light" || cssTheme === "dark") {
                defaulTheme = cssTheme;
            }
        }
        const storedTheme = localStorage.getItem("preferredColorScheme");
        if (storedTheme === "light" || storedTheme === "dark") {
            return storedTheme;
        }
        return defaulTheme;
    });

    useEffect(() => {
        // Aplicar el tema al atributo `data-theme` del elemento `html`
        document.documentElement.setAttribute("data-theme", theme);
        // Guardar la preferencia en localStorage
        localStorage.setItem("preferredColorScheme", theme);
    }, [theme]);

    const toggleTheme = () => {
        setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
    };

    return { theme, toggleTheme };
};

export default useTheme;
