import "../InputAmount/Styles.scss";

import { Input } from "antd";
import React, { useCallback, useEffect, useState } from "react";
import { checksumAddress } from "viem";

import { ALLOWED_CHAIN } from "../../constants/chain";
import { useWalletContext } from "../../context/Wallet";
import {
    ConvertAmount,
    TokenBalance,
    TokenSettings,
} from "../../helpers/currencies";
import { tokenExchange } from "../../helpers/exchange";
import { fromWei, toBigIntPrecision } from "../../helpers/precision";
import { useProjectTranslation } from "../../helpers/translations";
import ModalConfirmSend from "../Modals/ConfirmSend";
import { PrecisionNumbers } from "../PrecisionNumbers";
import TokenAmountInput from "../TokenAmountInput";

const QUICK_ACTIONS = [25, 50, 75, 100];

export default function Send(): JSX.Element {
    const { t, i18n } = useProjectTranslation();

    const {
        contractProtocolStatus,
        userBalance,
        userBaseCoinBalance,
        priceProvider,
    } = useWalletContext();

    const tokenSend: string[] = tokenExchange();
    // Add Token Govern
    tokenSend.push("TG");
    // Add custom tokens from REACT_APP_CONTRACT_PRICE_PROVIDER_CUSTOM
    const ppCustomRaw = import.meta.env
        .REACT_APP_CONTRACT_PRICE_PROVIDER_CUSTOM as string | undefined;
    if (ppCustomRaw) {
        for (const entry of ppCustomRaw.split(",")) {
            const pair = entry.trim().split(":")[0]?.trim() ?? "";
            const slashIdx = pair.indexOf("/");
            const name = slashIdx > 0 ? pair.slice(0, slashIdx) : pair;
            if (name) tokenSend.push(`CUSTOM_${name}`);
        }
    }
    // Add Coinbase support at index 0
    tokenSend.splice(0, 0, "COINBASE");

    const defaultTokenSend: string = tokenSend[0];
    const [currencyYouSend, setCurrencyYouSend] =
        useState<string>(defaultTokenSend);

    const [amountYouSend, setAmountYouSend] = useState<string>("");
    const [destinationAddress, setDestinationAddress] = useState<string>("");
    const [caIndex, setCAIndex] = useState<number>(0);

    const [inputValidationErrorText, setInputValidationErrorText] =
        useState<string>("");
    const [
        inputValidationAddressErrorText,
        setInputValidationAddressErrorText,
    ] = useState<string>("");
    const [inputValidationError, setInputValidationError] =
        useState<boolean>(true);

    const onChangeCurrencyYouSend = (newCurrencyYouExchange: string): void => {
        onClear();

        let caIndex: number = 0;
        const aCurrencyYouSend: string[] = newCurrencyYouExchange.split("_");
        switch (aCurrencyYouSend[0]) {
            case "CA":
                caIndex = parseInt(aCurrencyYouSend[1]);
                break;
            case "TC":
                caIndex = parseInt(aCurrencyYouSend[1]);
                break;
            case "TP":
                caIndex = 0;
                break;
        }

        setCAIndex(caIndex);
        setCurrencyYouSend(newCurrencyYouExchange);
    };

    const onClear = (): void => {
        setAmountYouSend("");
        setDestinationAddress("");
        setInputValidationErrorText("");
        setInputValidationAddressErrorText("");
        setInputValidationError(true);
    };

    const onValidate = useCallback((): void => {
        let amountInputError: boolean = false;
        let addressInputError: boolean = false;

        // 1. User Send Token Validation
        const totalBalance: bigint = TokenBalance(
            userBalance,
            currencyYouSend,
            userBaseCoinBalance?.balance
                ? { balance: userBaseCoinBalance.balance }
                : undefined
        );
        const amountYouSendBig: bigint = toBigIntPrecision(amountYouSend);

        if (!amountYouSend || amountYouSendBig === 0n) {
            amountInputError = true;
        } else if (amountYouSendBig > totalBalance) {
            setInputValidationErrorText(t("send.infoNoBalance"));
            amountInputError = true;
        } else if (amountYouSendBig < 0n) {
            setInputValidationErrorText(t("send.infoNoNegativeValues"));
            amountInputError = true;
        }

        // 2. Input address valid
        let addressChecksumWarning: boolean = false;
        if (!destinationAddress) {
            addressInputError = true;
        } else if (!/^0x[0-9a-fA-F]{40}$/.test(destinationAddress)) {
            setInputValidationAddressErrorText(t("send.infoAddressInvalid"));
            addressInputError = true;
        } else {
            // For mixed-case addresses, warn if EIP-1191 checksum doesn't match,
            // but still allow the operation to proceed.
            // All-lowercase / all-uppercase addresses carry no checksum claim and are accepted as-is.
            const hex = destinationAddress.slice(2);
            const hasMixedCase = /[A-F]/.test(hex) && /[a-f]/.test(hex);
            if (hasMixedCase) {
                const addr = destinationAddress as `0x${string}`;
                if (
                    destinationAddress !==
                    checksumAddress(addr, ALLOWED_CHAIN.id)
                ) {
                    addressChecksumWarning = true;
                }
            }
        }

        if (!amountInputError) {
            setInputValidationErrorText("");
        }

        if (addressChecksumWarning) {
            setInputValidationAddressErrorText(
                t("send.infoAddressChecksumInvalid")
            );
        } else if (!addressInputError) {
            setInputValidationAddressErrorText("");
        }

        setInputValidationError(amountInputError || addressInputError);
    }, [
        amountYouSend,
        currencyYouSend,
        destinationAddress,
        userBalance,
        userBaseCoinBalance,
        t,
    ]);

    useEffect(() => {
        setAmountYouSend(amountYouSend);
    }, [amountYouSend]);

    useEffect(() => {
        onValidate();
    }, [amountYouSend, destinationAddress, onValidate]);

    const onChangeAmountYouSend = (
        newAmount: string | number,
        isPriceOnly: boolean = false
    ): void => {
        if (!isPriceOnly) {
            setAmountYouSend(newAmount.toString());
        }

        let caIndex: number = 0;
        const aCurrencyYouSend: string[] = currencyYouSend.split("_");
        switch (aCurrencyYouSend[0]) {
            case "CA":
                caIndex = parseInt(aCurrencyYouSend[1]);
                break;
            case "TC":
                caIndex = parseInt(aCurrencyYouSend[1]);
                break;
            case "TP":
                caIndex = 0;
                break;
        }

        setCAIndex(caIndex);
    };

    const onChangeDestinationAddress = (
        event: React.ChangeEvent<HTMLInputElement>
    ): void => {
        setDestinationAddress(event.target.value);
    };

    const setAddTotalAvailable = (): void => {
        const totalYouSendWei: bigint = TokenBalance(
            userBalance,
            currencyYouSend,
            userBaseCoinBalance?.balance
                ? { balance: userBaseCoinBalance.balance }
                : undefined
        );
        const totalYouSend = fromWei(
            totalYouSendWei,
            TokenSettings(currencyYouSend).decimals
        );
        setAmountYouSend(totalYouSend.toString());

        onChangeAmountYouSend(totalYouSend, true);
    };

    const onQuickActionSend = (percentage: number): void => {
        const totalYouSendWei = TokenBalance(
            userBalance,
            currencyYouSend,
            userBaseCoinBalance?.balance
                ? { balance: userBaseCoinBalance.balance }
                : undefined
        );
        const partialYouSend = fromWei(
            (totalYouSendWei * BigInt(percentage)) / 100n,
            TokenSettings(currencyYouSend).decimals
        );
        onChangeAmountYouSend(partialYouSend.toString());
    };

    const sendingUSD: bigint = (() => {
        if (currencyYouSend.split("_")[0] === "CUSTOM") {
            const tokenName = currencyYouSend.replace(/^CUSTOM_/, "");
            const price = priceProvider.data?.[`${tokenName}/USD`]?.[0] ?? 0n;
            const amt = toBigIntPrecision(amountYouSend);
            return price > 0n ? (amt * price) / 10n ** 18n : 0n;
        }
        return ConvertAmount(
            contractProtocolStatus,
            currencyYouSend,
            "USD",
            toBigIntPrecision(amountYouSend),
            caIndex
        );
    })();

    return (
        <div>
            <div className="sectionSend__Content">
                <div className="inputFields">
                    <div
                        className="tokenSelector"
                        data-testid="send-input-token"
                    >
                        <TokenAmountInput
                            testId="send-input-amount"
                            inputValue={amountYouSend.toString()}
                            placeholder={"0.0"}
                            onValueChange={onChangeAmountYouSend}
                            validateError={inputValidationErrorText !== ""}
                            feedbackMessage={
                                inputValidationErrorText || undefined
                            }
                            feedbackState="negative"
                            preserveSpaceWhenNoFeedback
                            balanceValue={PrecisionNumbers({
                                amount: TokenBalance(
                                    userBalance,
                                    currencyYouSend,
                                    userBaseCoinBalance?.balance
                                        ? {
                                              balance:
                                                  userBaseCoinBalance.balance,
                                          }
                                        : undefined
                                ),
                                token: TokenSettings(currencyYouSend),
                                decimals:
                                    TokenSettings(currencyYouSend)
                                        .visibleDecimals,
                                i18n: i18n,
                                compact: true,
                            })}
                            onMaxClick={setAddTotalAvailable}
                            label={t("send.labelSending")}
                            balanceLabel={t("send.labelBalance")}
                            action="send"
                            currencyOptions={tokenSend}
                            selectorTestId="send-input-token-popup"
                            tokenSelectable
                            selectedTokenValue={currencyYouSend}
                            onTokenSelect={onChangeCurrencyYouSend}
                            quickActions={QUICK_ACTIONS.filter(
                                (percentage) => percentage !== 100
                            )}
                            onQuickActionClick={onQuickActionSend}
                        />
                    </div>
                    <div className="tx-direction">
                        <div className="icon-arrow-down"></div>
                    </div>
                    <div className="tokenSelector">
                        <div className="amountInput">
                            <div className="amountInput__infoBar">
                                <div className="captionOLD amountInput__label">
                                    {t("send.labelDestination")}
                                </div>
                            </div>
                            <Input
                                data-testid="send-input-destination"
                                type="text"
                                placeholder={t("send.placeholder")}
                                className="input-addressOLD amountInput__value "
                                value={destinationAddress}
                                onChange={onChangeDestinationAddress}
                            />
                        </div>
                        <div className="amountInput__feedback amountInput__feedback--error">
                            {inputValidationAddressErrorText}
                        </div>
                    </div>
                </div>
            </div>
            <div className="cta-container">
                <div className="cta-info-group">
                    <div className="cta-info-summary">
                        <span className={"token_exchange"}>
                            {t("send.sendingSummary")}
                        </span>
                        <span className={"symbol"}>
                            {t("send.sendingSign")}
                        </span>
                        {sendingUSD.toString() !== "NaN" ? (
                            <span className={"token_receive_label"}>
                                {PrecisionNumbers({
                                    amount: sendingUSD,
                                    token: TokenSettings("CA_0"),
                                    decimals: 2,
                                    i18n: i18n,
                                    compact: true,
                                })}
                            </span>
                        ) : (
                            <span>0</span>
                        )}
                        <span className={"token_receive_name"}>
                            {" "}
                            {t("send.sendingCurrency")}
                        </span>
                    </div>
                </div>

                <div className="cta-options-group">
                    <ModalConfirmSend
                        currencyYouExchange={currencyYouSend}
                        exchangingUSD={sendingUSD}
                        amountYouExchange={amountYouSend}
                        destinationAddress={destinationAddress}
                        onClear={onClear}
                        inputValidationError={inputValidationError}
                        caIndex={caIndex}
                    />
                </div>
            </div>
        </div>
    );
}
