import {
    simulateContract,
    waitForTransactionReceipt,
    writeContract,
} from "@wagmi/core";
import { type Abi, type TransactionReceipt } from "viem";

import settings from "../settings";
import type {
    InterfaceContext,
    OnReceipt,
    OnTransaction,
} from "../types/wallets";
import { config } from "../wagmiConfig";
import {
    mintTCandTP as mintTCandTP_,
    redeemTC as redeemTC_,
    redeemTCandTP as redeemTCandTP_,
    redeemTP as redeemTP_,
    swapTCforTP as swapTCforTP_,
    swapTPforTC as swapTPforTC_,
    swapTPforTP as swapTPforTP_,
} from "./moc-core";
import { getExecutionFee } from "./utils";

const mintTC = async (
    interfaceContext: InterfaceContext,
    caIndex: number,
    qTC: bigint,
    limitAmount: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Mint Collateral token with CA coinbase
    const {
        address,
        contracts,
        contractProtocolStatus,
        userBalance,
        publicClient,
    } = interfaceContext;

    const vendorAddress = (import.meta.env
        .REACT_APP_ENVIRONMENT_VENDOR_ADDRESS ||
        "0x0000000000000000000000000000000000000000") as `0x${string}`;

    // Verifications
    if (!address) throw new Error("Address not found");
    if (!publicClient) throw new Error("Public client not found");
    if (!contracts) throw new Error("Contracts not found");
    if (!contracts.Moc) throw new Error("Moc not found");
    if (!contracts.Moc[caIndex])
        throw new Error(`Moc not found for ${caIndex}`);
    if (!userBalance.data) throw new Error("User balance not found");
    if (!userBalance.data.CA) throw new Error("CA not found");
    if (!contractProtocolStatus.data)
        throw new Error("Contract protocol status not found");
    if (!contractProtocolStatus.data[caIndex])
        throw new Error(`Contract protocol status not found for ${caIndex}`);

    const MoCContract = contracts.Moc[caIndex];

    // Verifications
    // User have sufficient reserve to pay?
    /*console.warn(
        `To mint ${qTC} ${
            (settings.tokens.TC[caIndex] as TokenConfig).name
        } you need > ${limitAmount.toString()} ${
            (settings.tokens.CA[caIndex] as TokenConfig).name
        } in your balance`
    );*/
    const userReserveBalance = userBalance.data.CA[caIndex].balance;
    if (limitAmount > userReserveBalance)
        throw new Error(
            `Insufficient ${(settings.tokens.CA[caIndex]).name} balance`
        );

    // Allowance    reserveAllowance
    /*console.warn(
        `Allowance: To mint ${qTC} ${
            (settings.tokens.TC[caIndex] as TokenConfig).name
        } you need > ${limitAmount.toString()} ${
            (settings.tokens.CA[caIndex] as TokenConfig).name
        } in your spendable balance`
    );*/
    /*
    const userSpendableBalance = new BigNumber(
        fromContractPrecisionDecimals(
            userBalanceData.CA[caIndex].allowance,
            settings.tokens.CA[caIndex].decimals
        )
    );
    if (limitAmount.gt(userSpendableBalance))
        throw new Error(
            'Insufficient spendable balance... please make an allowance to the MoC contract'
        );
    */

    const configParams: {
        address: `0x${string}`;
        abi: Abi;
        functionName: string;
        args: readonly unknown[];
        account: `0x${string}`;
        value?: bigint;
    } = {
        address: MoCContract.address,
        abi: MoCContract.abi as Abi,
        functionName: "mintTC",
        args: [qTC, address, vendorAddress] as const,
        account: address,
    };

    const executionFee = await getExecutionFee(
        publicClient,
        contractProtocolStatus.data[caIndex].tcMintExecCost +
            contractProtocolStatus.data[caIndex].priceUpdatesCost,
        0
    );

    if (executionFee > 0n) {
        configParams.value = executionFee;
    }

    const { request } = await simulateContract(config, configParams);

    // Send transaction
    const txHash = await writeContract(config, request);
    if (onTransaction) onTransaction(txHash);

    const receipt = await waitForTransactionReceipt(config, { hash: txHash });

    if (onReceipt) onReceipt(receipt);

    return receipt;
};

const redeemTC = async (
    interfaceContext: InterfaceContext,
    caIndex: number,
    qTC: bigint,
    limitAmount: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Redeem Collateral token receiving CA support vendors
    return redeemTC_(
        interfaceContext,
        caIndex,
        qTC,
        limitAmount,
        onTransaction,
        onReceipt
    );
};

const mintTP = async (
    interfaceContext: InterfaceContext,
    caIndex: number,
    tpIndex: number,
    qTP: bigint,
    limitAmount: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Mint pegged token with collateral coinbase
    const {
        address,
        contracts,
        contractProtocolStatus,
        userBalance,
        publicClient,
    } = interfaceContext;

    const vendorAddress = (import.meta.env
        .REACT_APP_ENVIRONMENT_VENDOR_ADDRESS ||
        "0x0000000000000000000000000000000000000000") as `0x${string}`;

    // Verifications
    if (!address) throw new Error("Address not found");
    if (!publicClient) throw new Error("Public client not found");
    if (!contracts) throw new Error("Contracts not found");
    if (!contracts.Moc) throw new Error("Moc not found");
    if (!contracts.Moc[caIndex])
        throw new Error(`Moc not found for ${caIndex}`);
    if (!contracts.TP) throw new Error("TP not found");
    if (!contracts.TP[tpIndex]) throw new Error(`TP not found for ${tpIndex}`);
    if (!userBalance.data) throw new Error("User balance not found");
    if (!userBalance.data.CA) throw new Error("CA not found");
    if (!contractProtocolStatus.data)
        throw new Error("Contract protocol status not found");
    if (!contractProtocolStatus.data[caIndex])
        throw new Error(`Contract protocol status not found for ${caIndex}`);

    const MoCContract = contracts.Moc[caIndex];
    const tpAddress = contracts.TP[tpIndex].address;

    // Verifications

    // User have sufficient reserve to pay?
    /*console.warn(
        `To mint ${qTP} ${
            (settings.tokens.TP[tpIndex] as TokenConfig).name
        } you need > ${limitAmount.toString()} ${
            (settings.tokens.CA[caIndex] as TokenConfig).name
        } in your balance`
    );*/
    const userReserveBalance = userBalance.data.CA[caIndex].balance;
    if (limitAmount > userReserveBalance)
        throw new Error(
            `Insufficient ${(settings.tokens.CA[caIndex]).name} balance`
        );

    // Allowance
    /*console.warn(
        `Allowance: To mint ${qTP} ${
            (settings.tokens.TP[tpIndex] as TokenConfig).name
        } you need > ${limitAmount.toString()} ${
            (settings.tokens.CA[caIndex] as TokenConfig).name
        } in your spendable balance`
    );*/
    /*
    const userSpendableBalance = new BigNumber(
        fromContractPrecisionDecimals(
            userBalanceData.CA[caIndex].allowance,
            settings.tokens.CA[caIndex].decimals
        )
    );
    if (limitAmount.gt(userSpendableBalance))
        throw new Error(
            'Insufficient spendable balance... please make an allowance to the MoC contract'
        );

     */

    // There are sufficient PEGGED in the contracts to mint?
    const tpAvailableToMint =
        contractProtocolStatus.data[caIndex].getTPAvailableToMint[tpIndex];

    if (qTP > tpAvailableToMint)
        throw new Error(
            `Insufficient ${(settings.tokens.TP[tpIndex]).name} available to mint`
        );

    const configParams: {
        address: `0x${string}`;
        abi: Abi;
        functionName: string;
        args: readonly unknown[];
        account: `0x${string}`;
        value?: bigint;
    } = {
        address: MoCContract.address,
        abi: MoCContract.abi as Abi,
        functionName: "mintTP",
        args: [tpAddress, qTP, address, vendorAddress] as const,
        account: address,
    };

    const executionFee = await getExecutionFee(
        publicClient,
        contractProtocolStatus.data[caIndex].tpMintExecCost +
            contractProtocolStatus.data[caIndex].priceUpdatesCost,
        0
    );

    if (executionFee > 0n) {
        configParams.value = executionFee + limitAmount;
    }

    const { request } = await simulateContract(config, configParams);

    // Send transaction
    const txHash = await writeContract(config, request);
    if (onTransaction) onTransaction(txHash);

    const receipt = await waitForTransactionReceipt(config, { hash: txHash });

    if (onReceipt) onReceipt(receipt);

    return receipt;
};

const redeemTP = async (
    interfaceContext: InterfaceContext,
    caIndex: number,
    tpIndex: number,
    qTP: bigint,
    limitAmount: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Redeem pegged token receiving CA support vendor
    return redeemTP_(
        interfaceContext,
        caIndex,
        tpIndex,
        qTP,
        limitAmount,
        onTransaction,
        onReceipt
    );
};

const swapTPforTP = async (
    interfaceContext: InterfaceContext,
    iFromTP: number,
    iToTP: number,
    qTP: bigint,
    caIndex: number,
    limitAmount: bigint,
    qAssetMaxFees: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Swap pegged token for another pegged token
    return swapTPforTP_(
        interfaceContext,
        iFromTP,
        iToTP,
        qTP,
        caIndex,
        limitAmount,
        qAssetMaxFees,
        onTransaction,
        onReceipt
    );
};

const swapTCforTP = async (
    interfaceContext: InterfaceContext,
    tpIndex: number,
    qTC: bigint,
    caIndex: number,
    limitAmount: bigint,
    qAssetMaxFees: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Swap collateral token for pegged token
    return swapTCforTP_(
        interfaceContext,
        tpIndex,
        qTC,
        caIndex,
        limitAmount,
        qAssetMaxFees,
        onTransaction,
        onReceipt
    );
};

const swapTPforTC = async (
    interfaceContext: InterfaceContext,
    tpIndex: number,
    qTP: bigint,
    caIndex: number,
    limitAmount: bigint,
    qAssetMaxFees: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Swap pegged token for collateral token
    return swapTPforTC_(
        interfaceContext,
        tpIndex,
        qTP,
        caIndex,
        limitAmount,
        qAssetMaxFees,
        onTransaction,
        onReceipt
    );
};

const mintTCandTP = async (
    interfaceContext: InterfaceContext,
    caIndex: number,
    tpIndex: number,
    qTP: bigint,
    limitAmount: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Mint collateral token and pegged token
    return mintTCandTP_(
        interfaceContext,
        caIndex,
        tpIndex,
        qTP,
        limitAmount,
        onTransaction,
        onReceipt
    );
};

const redeemTCandTP = async (
    interfaceContext: InterfaceContext,
    caIndex: number,
    tpIndex: number,
    qTC: bigint,
    qTP: bigint,
    limitAmount: bigint,
    onTransaction: OnTransaction,
    onReceipt: OnReceipt
): Promise<TransactionReceipt | undefined> => {
    // Redeem collateral token and pegged token
    return redeemTCandTP_(
        interfaceContext,
        caIndex,
        tpIndex,
        qTC,
        qTP,
        limitAmount,
        onTransaction,
        onReceipt
    );
};

export {
    mintTC,
    mintTCandTP,
    mintTP,
    redeemTC,
    redeemTCandTP,
    redeemTP,
    swapTCforTP,
    swapTPforTC,
    swapTPforTP,
};
