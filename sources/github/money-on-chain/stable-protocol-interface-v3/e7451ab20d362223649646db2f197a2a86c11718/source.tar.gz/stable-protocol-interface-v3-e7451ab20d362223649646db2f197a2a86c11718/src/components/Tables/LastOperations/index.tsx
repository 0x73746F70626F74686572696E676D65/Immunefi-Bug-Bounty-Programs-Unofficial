import "./Styles.scss";

import { DownCircleOutlined, UpCircleOutlined } from "@ant-design/icons";
import { Modal, Skeleton, Table } from "antd";
import React, {
    Fragment,
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import Moment from "react-moment";

import { useWalletContext } from "../../../context/Wallet";
import { TokenSettings } from "../../../helpers/currencies";
import date from "../../../helpers/date";
import { wadDiv } from "../../../helpers/precision";
import { useProjectTranslation } from "../../../helpers/translations";
import api from "../../../services/api";
import { API_OPERATIONS_BASE } from "../../../services/apiConfig";
import settings from "../../../settings";
import type { TokenConfig } from "../../../types/hooks";
import AboutQueue from "../../Modals/AboutQueue";
import { PrecisionNumbers } from "../../PrecisionNumbers";
import RowDetailMobile from "../RowDetailMobile";

// Type definitions
interface LastOperationsProps {
    token: string;
}

interface DetailPriceData {
    value: bigint | null;
    currency: string | null;
    token: TokenConfig | null;
}

interface DetailData {
    event: string;
    created: React.ReactNode;
    gas_used: string | number;
    oper_id: string | number | null;
    confirmation: React.ReactNode | string;
    recipient: React.ReactNode | string;
    status: string;
    error_code: string | number;
    block: string | number;
    executed_tx_hash: string;
    executed_tx_hash_truncate: string;
    fee: React.ReactNode | string;
    recipient_truncate: string;
    tx_hash: string;
    tx_hash_truncate: string;
    msg: string;
    reason: string;
    price: DetailPriceData | null;
    price_another_token: DetailPriceData | null;
    exchange?: {
        action?: string;
        amount: string | number;
        name: string;
        title: string;
    };
    receive?: {
        action?: string;
        amount: string | number;
        name: string;
        title: string;
    };
}

interface OperationData {
    _id: string;
    operation: string;
    operId_: number | null;
    bucket_index: number;
    executed?: {
        qAC_?: string;
        qACmax?: string;
        qTC_?: string;
        qTC?: string;
        qTP_?: string;
        qTPfrom_?: string;
        qTPto_?: string;
        qACmin?: string;
        qFeeToken_?: string;
        qFeeTokenVendorMarkup_?: string;
        qACfee_?: string;
        qACVendorMarkup_?: string;
        tpIndex_?: number;
        tpFromIndex_?: number;
        tpToIndex_?: number;
        blockNumber?: number;
        qACtoRedeemTC_?: string;
        qACtoRedeemTP_?: string;
        qACtoMintTC_?: string;
        qACtoMintTP_?: string;
    };
    params?: {
        qAC_?: string;
        qACmax?: string;
        qTC_?: string;
        qTC?: string;
        qTP?: string;
        qTPmin?: string;
        qACmin?: string;
        tpIndex_?: number;
        tpFromIndex?: number;
        tpToIndex?: number;
        recipient?: string;
        amount?: string;
        token?: string;
        sender?: string;
        hash?: string;
        blockNumber?: number;
    };
    status: number;
    createdAt: string;
    lastUpdatedAt: string;
    confirmationTime?: string;
    blockNumber?: number;
    hash?: string;
    gas_fee?: string;
    gasFeeRBTC?: string;
    gas?: string;
    gasPrice?: string;
    gasUsed?: string;
    errorCode_?: string;
    msg_?: string;
    reason_?: string;
    tokenInvolved?: string;
}

interface ApiResponse {
    operations: OperationData[];
    total: number;
}

interface TokenExchangeResult {
    exchange: {
        action?: string;
        amount: string | number;
        name: string;
        token: unknown;
        icon: string;
        title: string;
    };
    receive: {
        action?: string;
        amount: string | number | undefined;
        name: string;
        token: unknown;
        icon: string;
        title: string;
    };
    another: {
        action?: string;
        amount: string | number | undefined;
        name: string;
        token: unknown;
        icon: string;
        title: string;
    };
}

interface TableRowData {
    key: string;
    info: string;
    exchange: React.ReactNode;
    receive: React.ReactNode;
    another: React.ReactNode;
    date: React.ReactNode;
    status: React.ReactNode;
    detail: DetailData;
    renderRow: React.ReactNode;
    description: React.ReactNode;
}

interface ExpandIconProps {
    expanded: boolean;
    onClick: () => void;
}

export default function LastOperations(props: LastOperationsProps) {
    const { token } = props;
    const [current, setCurrent] = useState(1);
    const { t, i18n, ns } = useProjectTranslation();
    const { isConnected, address, blockNumber } = useWalletContext();
    const [ready, setReady] = useState(false);

    // Reset initial load flag when wallet disconnects or address changes
    useEffect(() => {
        if (!isConnected || !address) {
            hasInitialLoadRef.current = false;
            setReady(false);
        }
    }, [isConnected, address]);
    /*useEffect(() => {
        if (auth.contractStatusData) {
            setReady(true);
        }
    }, [auth]);*/

    //const { accountData = {} as any } = auth;
    const [dataJson, setDataJson] = useState<ApiResponse>({
        operations: [],
        total: 0,
    });
    const [totalTable, setTotalTable] = useState(0);
    // Fixed page size — the per-page selector was removed from the pagination UI.
    const pageSize = 10;
    //const [loadingSke, setLoadingSke] = useState(true);
    const [queueModal, setQueueModal] = useState(false);
    const lastOperationsHeight = getComputedStyle(
        document.querySelector(":root") as Element
    )
        .getPropertyValue("--lastOperationsHeight")
        .split('"')
        .join("");
    /*const timeSke = 1500;*/

    // Ref to track if a request is in progress to prevent overlapping calls
    const isLoadingRef = useRef<boolean>(false);
    // Ref to track if initial load has happened
    const hasInitialLoadRef = useRef<boolean>(false);
    // Refs to store current values to avoid recreating callback
    const currentRef = useRef(current);
    const pageSizeRef = useRef(pageSize);
    const isConnectedRef = useRef(isConnected);
    const addressRef = useRef(address);
    const blockNumberRef = useRef(blockNumber);

    // Update refs when values change
    useEffect(() => {
        currentRef.current = current;
    }, [current]);
    useEffect(() => {
        pageSizeRef.current = pageSize;
    }, [pageSize]);
    useEffect(() => {
        isConnectedRef.current = isConnected;
    }, [isConnected]);
    useEffect(() => {
        addressRef.current = address;
    }, [address]);
    useEffect(() => {
        blockNumberRef.current = blockNumber;
    }, [blockNumber]);

    const fetchTransactions = useCallback((isPolling = false) => {
        if (
            isConnectedRef.current &&
            blockNumberRef.current &&
            addressRef.current &&
            !isLoadingRef.current
        ) {
            isLoadingRef.current = true;
            if (!API_OPERATIONS_BASE) {
                console.error(
                    "[LastOperations] API_OPERATIONS_BASE is not configured or failed allowlist validation"
                );
                isLoadingRef.current = false;
                hasInitialLoadRef.current = true;
                setReady(true);
                return;
            }
            const skip = (currentRef.current - 1) * pageSizeRef.current;

            const url = new URL(API_OPERATIONS_BASE);
            url.pathname = "/v1/operations/list/";
            url.search = new URLSearchParams({
                recipient: addressRef.current || "",
                limit: String(pageSizeRef.current),
                skip: String(skip),
            }).toString();

            api("get", url.toString())
                .then((response: unknown) => {
                    const typedResponse = response as ApiResponse;
                    setDataJson(typedResponse);
                    setTotalTable(typedResponse.total);
                    setReady(true);
                    if (!isPolling) {
                        hasInitialLoadRef.current = true;
                    }
                })
                .catch((error) => {
                    console.error(error);
                    // Don't set ready to false on error, keep showing existing data
                })
                .finally(() => {
                    isLoadingRef.current = false;
                });
        }
    }, []); // Empty deps - using refs for all values
    // #section Operation detail custom expand function
    const [expandedKeys, setExpandedKeys] = useState<string[]>([]);

    // Expansion / Contraction
    const handleExpand = useCallback(
        (expanded: boolean, record: { key: string }) => {
            setExpandedKeys((prevKeys) => {
                return expanded
                    ? [...prevKeys, record.key]
                    : prevKeys.filter((key) => key !== record.key);
            });
        },
        []
    );

    // Expansion Icon
    const ExpandIcon: React.FC<ExpandIconProps> = ({ expanded, onClick }) => (
        <div onClick={onClick} style={{ cursor: "pointer" }}>
            {expanded ? <UpCircleOutlined /> : <DownCircleOutlined />}
        </div>
    );

    // #endsection Operation detail custom expand function

    const columns = [
        {
            dataIndex: "renderRow",
            // width: 200,
            hidden: false,
        },
    ].filter((item) => !item.hidden);

    const getDetailsLayoutClass = useCallback((event: string) => {
        if (event === "TCandTPRedeem") {
            return "LastOp__group__details--two-one-split";
        }

        if (event === "TCandTPMint") {
            return "LastOp__group__details--one-two-split";
        }

        if (event === "Transfer") {
            return "LastOp__group__details--one-two-merged";
        }

        return "LastOp__group__details--single-single";
    }, []);

    // Initial load - immediate, no delay
    useEffect(() => {
        if (
            isConnected &&
            blockNumber &&
            address &&
            !hasInitialLoadRef.current
        ) {
            fetchTransactions(false);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isConnected, blockNumber, address]);

    // Polling - only after initial load, with interval
    useEffect(() => {
        if (!isConnected || !blockNumber || !address) {
            return;
        }

        let intervalId: NodeJS.Timeout | null = null;
        let checkTimeoutId: NodeJS.Timeout | null = null;

        // Wait for initial load before starting polling
        const startPolling = () => {
            if (hasInitialLoadRef.current) {
                // Poll every 20 seconds
                intervalId = setInterval(() => {
                    fetchTransactions(true);
                }, 20000);
            } else {
                // Check again after a short delay if initial load hasn't happened
                checkTimeoutId = setTimeout(startPolling, 100);
            }
        };

        checkTimeoutId = setTimeout(startPolling, 100);

        return () => {
            if (checkTimeoutId) clearTimeout(checkTimeoutId);
            if (intervalId) clearInterval(intervalId);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isConnected, blockNumber, address]);

    // Reload when page or pageSize changes
    useEffect(() => {
        if (
            isConnected &&
            blockNumber &&
            address &&
            hasInitialLoadRef.current
        ) {
            fetchTransactions(false);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [current, pageSize, isConnected, blockNumber, address]);

    const onChange = (page: number) => {
        if (isConnected) {
            setCurrent(page);
        }
    };

    const getTokenInfo = useCallback((token: string) => {
        if (token === "FeeToken") {
            return {
                name: settings.tokens.TF[0].name,
                token: settings.tokens.TF[0],
            };
        }
        const match = token.match(/^(CA|TC|TP)_(\d+)$/);
        if (match) {
            const [, prefix, indexStr] = match;
            const index = parseInt(indexStr, 10);
            const arr =
                prefix === "CA"
                    ? (settings.tokens.CA)
                    : prefix === "TC"
                      ? settings.tokens.TC
                      : settings.tokens.TP;
            const tokenConfig = arr[index];
            if (!tokenConfig) return undefined;
            return {
                name: tokenConfig?.name || "",
                token: tokenConfig,
            };
        }
        console.warn("UNRECOGNIZED TOKEN: " + token);
        return undefined;
    }, []);

    const tokenExchange = useCallback(
        (row_operation: OperationData): TokenExchangeResult | undefined => {
            let status = "";
            if (row_operation.executed) {
                status = "executed";
            } else if (row_operation.params) {
                status = "params";
            }

            const caIndex = row_operation.bucket_index ?? 0;

            if (!status) {
                return {
                    exchange: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title: t("operations.actions.exchanged"),
                    },
                    receive: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token:
                            row_operation["operation"] === "TCandTPMint"
                                ? (settings.tokens.TC)[caIndex]
                                : (settings.tokens.TP)[
                                      caIndex
                                  ],
                        icon:
                            row_operation["operation"] === "TCandTPMint"
                                ? `TC_${caIndex}`
                                : `TP_${caIndex}`,
                        title:
                            row_operation["operation"] === "TCandTPMint"
                                ? t("operations.actions.received")
                                : t("operations.actions.exchanged"),
                    },
                };
            }

            if (row_operation.operation === "TCMint") {
                return {
                    exchange: {
                        action: "TCMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qAC_ || 0
                                : row_operation.params?.qACmax || 0,
                        name:
                            (settings.tokens.CA)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TCMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTC_ || 0
                                : row_operation.params?.qTC || 0,
                        name: settings.tokens.TC[caIndex].name,
                        token: settings.tokens.TC[caIndex],
                        icon: `TC_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TC)[caIndex],
                        icon: `TC_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation.operation === "TCRedeem") {
                return {
                    exchange: {
                        action: "TCRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTC_ || 0
                                : row_operation.params?.qTC || 0,
                        name: settings.tokens.TC[caIndex].name,
                        token: settings.tokens.TC[caIndex],
                        icon: `TC_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TCRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qAC_ || 0
                                : row_operation.params?.qACmin || 0,
                        name:
                            (settings.tokens.CA)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TP)[caIndex],
                        icon: `TP_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation["operation"] === "TPMint") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                let tp_index =
                    statusData?.tpIndex_ ||
                    (statusData as { tpIndex?: number })?.tpIndex;
                if (tp_index === undefined) tp_index = 0;

                return {
                    exchange: {
                        action: "TPMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qAC_ || 0
                                : row_operation.params?.qACmax || 0,
                        name:
                            (settings.tokens.CA)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TPMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTP_ || 0
                                : row_operation.params?.qTP || 0,
                        name: settings.tokens.TP[tp_index].name,
                        token: settings.tokens.TP[tp_index],
                        icon: `TP_${tp_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TC)[caIndex],
                        icon: `TC_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation["operation"] === "TPRedeem") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                let tp_index =
                    statusData?.tpIndex_ ||
                    (statusData as { tpIndex?: number })?.tpIndex;
                if (tp_index === undefined) tp_index = 0;

                return {
                    exchange: {
                        action: "TPRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTP_ || 0
                                : row_operation.params?.qTP || 0,
                        name: settings.tokens.TP[tp_index].name,
                        token: settings.tokens.TP[tp_index],
                        icon: `TP_${tp_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TPRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qAC_ || 0
                                : row_operation.params?.qACmin || 0,
                        name:
                            (settings.tokens.CA)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TC)[caIndex],
                        icon: `TC_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation["operation"] === "TPSwapForTP") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                const sd = statusData as
                    | {
                          tpFromIndex_?: number;
                          tpFromIndex?: number;
                          tpToIndex_?: number;
                          tpToIndex?: number;
                      }
                    | undefined;
                const tp_from_index: number =
                    sd?.tpFromIndex_ ?? sd?.tpFromIndex ?? 0;
                const tp_to_index: number =
                    sd?.tpToIndex_ ?? sd?.tpToIndex ?? 0;

                return {
                    exchange: {
                        action: "TPSwapForTP",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTPfrom_ || 0
                                : row_operation.params?.qTP || 0,
                        name: settings.tokens.TP[tp_from_index].name,
                        token: settings.tokens.TP[tp_from_index],
                        icon: `TP_${tp_from_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TPSwapForTP",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTPto_
                                : undefined,
                        name: settings.tokens.TP[tp_to_index].name,
                        token: settings.tokens.TP[tp_to_index],
                        icon: `TP_${tp_to_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TC)[caIndex],
                        icon: `TC_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation["operation"] === "TCSwapForTP") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                let tp_index =
                    statusData?.tpIndex_ ||
                    (statusData as { tpIndex?: number })?.tpIndex;
                if (tp_index === undefined) tp_index = 0;

                return {
                    exchange: {
                        action: "TCSwapForTP",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTC_ || 0
                                : row_operation.params?.qTC || 0,
                        name: settings.tokens.TC[caIndex].name,
                        token: settings.tokens.TC[caIndex],
                        icon: `TC_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TCSwapForTP",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTP_ || 0
                                : row_operation.params?.qTPmin || 0,
                        name: settings.tokens.TP[tp_index].name,
                        token: settings.tokens.TP[tp_index],
                        icon: `TP_${tp_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TC)[caIndex],
                        icon: `TC_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation["operation"] === "TPSwapForTC") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                let tp_index =
                    statusData?.tpIndex_ ||
                    (statusData as { tpIndex?: number })?.tpIndex;
                if (tp_index === undefined) tp_index = 0;

                return {
                    exchange: {
                        action: "TPSwapForTC",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTP_ || 0
                                : row_operation.params?.qTP || 0,
                        name: settings.tokens.TP[tp_index].name,
                        token: settings.tokens.TP[tp_index],
                        icon: `TP_${tp_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TPSwapForTC",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTC_ || 0
                                : row_operation.params?.qTC || 0,
                        name: settings.tokens.TC[caIndex].name,
                        token: settings.tokens.TC[caIndex],
                        icon: `TC_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TP)[caIndex],
                        icon: `TP_${caIndex}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation["operation"] === "TCandTPRedeem") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                let tp_index =
                    statusData?.tpIndex_ ||
                    (statusData as { tpIndex?: number })?.tpIndex;
                if (tp_index === undefined) tp_index = 0;

                return {
                    exchange: {
                        action: "TCandTPRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTC_ || 0
                                : row_operation.params?.qTC || 0,
                        name:
                            (settings.tokens.TC)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.TC)[caIndex],
                        icon: `TC_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TCandTPRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qAC_ || 0
                                : row_operation.params?.qACmin || 0,
                        name:
                            (settings.tokens.CA)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        action: "TCandTPRedeem",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTP_ || 0
                                : row_operation.params?.qTP || 0,
                        name: settings.tokens.TP[tp_index].name,
                        token: settings.tokens.TP[tp_index],
                        icon: `TP_${tp_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                };
            } else if (row_operation["operation"] === "TCandTPMint") {
                const statusData =
                    status === "executed"
                        ? row_operation.executed
                        : row_operation.params;
                let tp_index =
                    statusData?.tpIndex_ ||
                    (statusData as { tpIndex?: number })?.tpIndex;
                if (tp_index === undefined) tp_index = 0;

                return {
                    exchange: {
                        action: "TCandTPMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qAC_ || 0
                                : row_operation.params?.qACmax || 0,
                        name:
                            (settings.tokens.CA)[caIndex]
                                ?.name || "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.exchanged")
                                : t("operations.actions.exchanging"),
                    },
                    receive: {
                        action: "TCandTPMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTP_ || 0
                                : row_operation.params?.qTP || 0,
                        name: settings.tokens.TP[tp_index].name,
                        token: settings.tokens.TP[tp_index],
                        icon: `TP_${tp_index}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                    another: {
                        action: "TCandTPMint",
                        amount:
                            status === "executed"
                                ? row_operation.executed?.qTC_
                                : row_operation.params?.qTC,
                        name: settings.tokens.TC[caIndex].name,
                        token: settings.tokens.TC[caIndex],
                        icon: `TC_${caIndex}`,
                        title:
                            status === "executed"
                                ? t("operations.actions.received")
                                : t("operations.actions.receiving"),
                    },
                };
            } else if (row_operation.operation === "Transfer") {
                const tokenParam = row_operation.params?.token;
                if (!tokenParam) return undefined;

                const token_info = getTokenInfo(tokenParam);
                if (!token_info) return undefined;

                return {
                    exchange: {
                        action: "Transfer",
                        amount: row_operation.params?.amount || 0,
                        name: token_info.name,
                        token: token_info.token,
                        icon: tokenParam,
                        title:
                            status === "executed"
                                ? "TRANSFERRED"
                                : t("operations.actions.transfer"),
                    },
                    receive: {
                        action: "Transfer",
                        amount: row_operation.params?.amount || 0,
                        name: token_info.name,
                        token: token_info.token,
                        icon: tokenParam,
                        title:
                            status === "executed"
                                ? "TRANSFERRED"
                                : t("operations.actions.transfer"),
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.TC)[0],
                        icon: `TC_${0}`,
                        title: t("operations.actions.received"),
                    },
                };
            } else if (row_operation.operation === "ERROR") {
                return {
                    exchange: {
                        action: "Error",
                        amount: 0,
                        name: "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title: "Revert",
                    },
                    receive: {
                        action: "Error",
                        amount: 0,
                        name: "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title: "Revert",
                    },
                    another: {
                        amount: 0,
                        name: "",
                        token: (settings.tokens.CA)[caIndex],
                        icon: `CA_${caIndex}`,
                        title: "Revert",
                    },
                };
            } else {
                console.warn("CAN'T OPERATE: " + row_operation.operation);
                return undefined;
            }
        },
        [t, getTokenInfo]
    );
    const getErrorMessage = useCallback(
        (error: string | number | null | undefined): string => {
            switch (error) {
                case "qAC below minimum required":
                    return `${t("operations.errors.qACBelow1")} ${token} ${t("operations.errors.qACBelow2")}`;
                case "Insufficient qac sent":
                    return ` ${t("operations.errors.insufficientQAC1")} ${(settings.tokens.CA)[0]?.name || ""} ${t("operations.errors.insufficientQAC2")}`;
                case "Low coverage":
                    return t("operations.errors.lowCoverage");
                case "Invalid Flux Capacitor Operation":
                    return t("operations.errors.fluxCapacitor");
                case "":
                    return t("operations.errors.noMessage");
                case " ":
                    return t("operations.errors.noMessage");
                case 0:
                    return t("operations.errors.noMessage");
                case "null":
                    return t("operations.errors.noMessage");
                default:
                    return String(error);
            }
        },
        [t, token]
    );
    const TruncatedAddress = useCallback((address: string, length = 6) => {
        if (!address) return "";

        return (
            address.substring(0, length + 2) +
            "…" +
            address.substring(address.length - length)
        );
    }, []);
    const getFee = useCallback(
        (row_operation: OperationData) => {
            const fee: {
                amount: bigint;
                token: string | null;
                decimals: number;
            } = { amount: 0n, token: null, decimals: 18 };
            const caIndex = row_operation["bucket_index"] ?? 0;

            if (
                row_operation["executed"] &&
                row_operation["executed"]["qFeeToken_"]
            ) {
                const qFeeToken = BigInt(
                    row_operation["executed"]["qFeeToken_"]
                );
                const qFeeTokenVendorMarkup = BigInt(
                    row_operation["executed"]["qFeeTokenVendorMarkup_"] || "0"
                );

                fee["amount"] = qFeeToken + qFeeTokenVendorMarkup;
                fee["token"] = "TF";
                fee["decimals"] = settings.tokens.TF[0].decimals;
            }

            if (
                row_operation["executed"] &&
                row_operation["executed"]["qACfee_"] &&
                fee["amount"] === 0n
            ) {
                const qACfee = BigInt(row_operation["executed"]["qACfee_"]);

                const qACVendorMarkup = BigInt(
                    row_operation["executed"]["qACVendorMarkup_"] || "0"
                );

                fee["amount"] = qACfee + qACVendorMarkup;
                fee["token"] = `CA_${caIndex}`;
                fee["decimals"] =
                    (settings.tokens.CA)[caIndex]?.decimals ||
                    18;
            }

            if (fee["amount"] > 0n) {
                return (
                    <div className="LastOp__expanded__fee">
                        {/* <span className="value"> */}
                        {PrecisionNumbers({
                            amount: fee["amount"],
                            token: TokenSettings(fee["token"] || ""),
                            decimals: 6,
                            i18n: i18n,
                            compact: true,
                        })}
                        {/* </span> */}
                        <span className="token">
                            {"  "}
                            {"  "}
                            {t(`exchange.tokens.${fee["token"]}.abbr`, {
                                ns: ns,
                            })}{" "}
                        </span>
                    </div>
                );
            } else {
                return "--";
            }
        },
        [i18n, t, ns]
    );
    const getPrice = useCallback(
        (row_operation: OperationData) => {
            let value: bigint | null = null;
            let currency: string | null = null;
            const caIndex = row_operation["bucket_index"] ?? 0;
            const row_executed = row_operation.executed;
            let exchangeTokenName: string | null = null;
            let receiveTokenName: string | null = null;
            let token: TokenConfig | null = null;
            if (
                row_operation["operation"] === "TPMint" &&
                row_executed &&
                row_executed.qTP_ &&
                row_executed.qAC_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.TP)[
                    tp_index
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTP_),
                    BigInt(row_executed.qAC_),
                    "halfUp"
                );
                currency = `${exchangeTokenName}/${receiveTokenName}`;
                token = (settings.tokens.TP)[tp_index];
            } else if (
                row_operation["operation"] === "TPRedeem" &&
                row_executed &&
                row_executed.qTP_ &&
                row_executed.qAC_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.TP)[
                    tp_index
                ]?.name;
                receiveTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTP_),
                    BigInt(row_executed.qAC_),
                    "halfUp"
                );
                currency = `${receiveTokenName}/${exchangeTokenName}`;
                token = (settings.tokens.CA)[caIndex];
            } else if (
                row_operation["operation"] === "TCMint" &&
                row_executed &&
                row_executed.qTC_ &&
                row_executed.qAC_
            ) {
                exchangeTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.TC)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTC_),
                    BigInt(row_executed.qAC_),
                    "halfUp"
                );
                currency = `${exchangeTokenName}/${receiveTokenName}`;
                token = (settings.tokens.TC)[caIndex];
            } else if (
                row_operation["operation"] === "TCRedeem" &&
                row_executed &&
                row_executed.qTC_ &&
                row_executed.qAC_
            ) {
                exchangeTokenName = (settings.tokens.TC)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTC_),
                    BigInt(row_executed.qAC_),
                    "halfUp"
                );
                currency = `${receiveTokenName}/${exchangeTokenName}`;
                token = (settings.tokens.CA)[caIndex];
            } else if (
                row_operation["operation"] === "TPSwapForTP" &&
                row_executed &&
                row_executed.qTPfrom_ &&
                row_executed.qTPto_
            ) {
                const sd = row_executed as
                    | {
                          tpFromIndex_?: number;
                          tpFromIndex?: number;
                          tpToIndex_?: number;
                          tpToIndex?: number;
                      }
                    | undefined;
                const tp_from_index: number =
                    sd?.tpFromIndex_ ?? sd?.tpFromIndex ?? 0;
                const tp_to_index: number =
                    sd?.tpToIndex_ ?? sd?.tpToIndex ?? 0;
                exchangeTokenName = (settings.tokens.TP)[
                    tp_from_index
                ]?.name;
                receiveTokenName = (settings.tokens.TP)[
                    tp_to_index
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTPfrom_),
                    BigInt(row_executed.qTPto_),
                    "halfUp"
                );
                currency = `${exchangeTokenName}/${receiveTokenName}`;
                token = (settings.tokens.TP)[tp_from_index];
            } else if (
                row_operation["operation"] === "TCSwapForTP" &&
                row_executed &&
                row_executed.qTC_ &&
                row_executed.qTP_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.TC)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.TP)[
                    tp_index
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTP_),
                    BigInt(row_executed.qTC_),
                    "halfUp"
                );
                currency = `${exchangeTokenName}/${receiveTokenName}`;
                token = (settings.tokens.TP)[tp_index];
            } else if (
                row_operation["operation"] === "TPSwapForTC" &&
                row_executed &&
                row_executed.qTP_ &&
                row_executed.qTC_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.TP)[
                    tp_index
                ]?.name;
                receiveTokenName = (settings.tokens.TC)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTP_),
                    BigInt(row_executed.qTC_),
                    "halfUp"
                );
                currency = `${receiveTokenName}/${exchangeTokenName}`;
                token = (settings.tokens.TC)[caIndex];
            } else if (
                row_operation["operation"] === "TCandTPRedeem" &&
                row_executed &&
                row_executed.qTC_ &&
                row_executed.qACtoRedeemTC_
            ) {
                exchangeTokenName = (settings.tokens.TC)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTC_),
                    BigInt(row_executed.qACtoRedeemTC_),
                    "halfUp"
                );
                currency = `${receiveTokenName}/${exchangeTokenName}`;
                token = (settings.tokens.CA)[caIndex];
            } else if (
                row_operation["operation"] === "TCandTPMint" &&
                row_executed &&
                row_executed.qACtoMintTP_ &&
                row_executed.qTP_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.TP)[
                    tp_index
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTP_),
                    BigInt(row_executed.qACtoMintTP_),
                    "halfUp"
                );
                currency = `${exchangeTokenName}/${receiveTokenName}`;
                token = (settings.tokens.TP)[tp_index];
            }
            return { value, currency, token };
        },
        []
    );
    const getPriceAnotherToken = useCallback(
        (row_operation: OperationData) => {
            let value: bigint | null = null;
            let currency: string | null = null;
            const caIndex = row_operation["bucket_index"] ?? 0;
            const row_executed = row_operation.executed;
            let exchangeTokenName: string | null = null;
            let receiveTokenName: string | null = null;
            let token: TokenConfig | null = null;
            if (
                row_operation["operation"] === "TCandTPRedeem" &&
                row_executed &&
                row_executed.qTP_ &&
                row_executed.qACtoRedeemTP_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.TP)[
                    tp_index
                ]?.name;
                receiveTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTP_),
                    BigInt(row_executed.qACtoRedeemTP_),
                    "halfUp"
                );
                currency = `${receiveTokenName}/${exchangeTokenName}`;
                token = (settings.tokens.CA)[caIndex];
            } else if (
                row_operation["operation"] === "TCandTPMint" &&
                row_executed &&
                row_executed.qACtoMintTC_ &&
                row_executed.qTC_
            ) {
                let tp_index =
                    row_executed?.tpIndex_ ||
                    (row_executed as { tpIndex?: number })?.tpIndex;
                tp_index = tp_index ?? 0;
                exchangeTokenName = (settings.tokens.TC)[
                    caIndex
                ]?.name;
                receiveTokenName = (settings.tokens.CA)[
                    caIndex
                ]?.name;
                value = wadDiv(
                    BigInt(row_executed.qTC_),
                    BigInt(row_executed.qACtoMintTC_),
                    "halfUp"
                );
                currency = `${receiveTokenName}/${exchangeTokenName}`;
                token = (settings.tokens.TC)[caIndex];
            }
            return { value, currency, token };
        },
        []
    );
    const getTransferAction = useCallback(
        (row_operation: OperationData) => {
            if (
                row_operation.params?.sender?.toLowerCase() ===
                address?.toLowerCase()
            ) {
                return t("operations.actions.destination");
            } else {
                return t("operations.actions.origin");
            }
        },
        [t, address]
    );
    const getTransferAddress = useCallback(
        (row_operation: OperationData) => {
            if (
                row_operation.params?.sender?.toLowerCase() ===
                address?.toLowerCase()
            ) {
                // return truncateAddress(row_operation['params']['recipient'].toLowerCase())
                return row_operation.params?.recipient?.toLowerCase() || "";
            } else {
                //return truncateAddress(row_operation['params']['sender'].toLowerCase())
                return row_operation.params?.sender?.toLowerCase() || "";
            }
        },
        [address]
    );
    const getStatus = useCallback(
        (row_operation: OperationData) => {
            const confirmedBlocks = BigInt(10);
            switch (row_operation["status"]) {
                case -4:
                    return t("operations.actions.statusFailed");
                case -3:
                    return t("operations.actions.statusFailed");
                case -2:
                    return t("operations.actions.statusFailed");
                case -1:
                    return t("operations.actions.statusFailed");
                case 0:
                    if (
                        row_operation["params"] &&
                        BigInt(blockNumber || 0) <
                            BigInt(
                                row_operation["params"]["blockNumber"] || 0
                            ) +
                                confirmedBlocks
                    )
                        return t("operations.actions.statusQueuing");
                    else return t("operations.actions.statusQueued");
                case 1:
                    if (
                        row_operation["executed"] &&
                        BigInt(blockNumber || 0) <
                            BigInt(
                                row_operation["executed"]["blockNumber"] || 0
                            ) +
                                confirmedBlocks
                    )
                        return t("operations.actions.statusConfirming");
                    else if (
                        row_operation["operation"] === "Transfer" &&
                        BigInt(blockNumber || 0) <
                            BigInt(row_operation["blockNumber"] || 0) +
                                confirmedBlocks
                    )
                        return t("operations.actions.statusConfirming");
                    else return t("operations.actions.statusConfirmed");
                default:
                    return t("operations.actions.statusFailed");
            }
        },
        [t, blockNumber]
    );
    const setStatusIcon = useCallback(
        (status: string) => {
            switch (status) {
                case t("operations.actions.statusQueuing"):
                    return "QUEUING";
                case t("operations.actions.statusQueued"):
                    return "QUEUED";
                case t("operations.actions.statusConfirming"):
                    return "CONFIRMING";
                case t("operations.actions.statusConfirmed"):
                    return "CONFIRMED";
                case t("operations.actions.statusFailed"):
                    return "FAILED";
                default:
                    return "FAILED";
            }
        },
        [t]
    );
    const getAsset = useCallback((name: string) => {
        if (name === "FeeToken") {
            return {
                image: <div className="icon-token-tf icon-token-modif" />,
                color: "color-token-tf",
                txt: "TF",
            };
        }
        const match = name.match(/^(CA|TC|TP)_(\d+)$/);
        if (match) {
            const [, prefix, index] = match;
            const prefixLower = prefix.toLowerCase();
            const iconClass = `icon-token-${prefixLower}_${index} icon-token-modif`;
            const color =
                prefix === "CA"
                    ? "color-token-tp"
                    : prefix === "TC"
                      ? "color-token-tc"
                      : "color-token-tc";
            return {
                image: <div className={iconClass} />,
                color,
                txt: prefix,
            };
        }
        console.warn("UNRECOGNIZED TOKEN: " + name);
        return {
            image: (
                <div
                    className="icon-token-MOC"
                    style={{ display: "block", margin: "auto" }}
                />
            ),
            color: "color-token-tp",
            txt: "TP",
        };
    }, []);
    // Memoize the processed table data to avoid recalculating on every render
    const processedData = useMemo(() => {
        /*******************************sort descending by block number and then by operID***********************************/
        // Create a copy to avoid mutating the original array
        let sortedOperations: OperationData[] = [];
        if (dataJson.operations !== undefined) {
            sortedOperations = [...dataJson.operations].sort((a, b) => {
                if (a.blockNumber !== b.blockNumber) {
                    return (b.blockNumber || 0) - (a.blockNumber || 0);
                }
                if (a.operId_ !== null && b.operId_ !== null) {
                    return b.operId_ - a.operId_;
                }
                if (a.operId_ === null) {
                    return 1;
                }
                if (b.operId_ === null) {
                    return -1;
                }
                return 0;
            });
        }
        /*******************************filter by type (token)***********************************/
        const pre_datas: OperationData[] = sortedOperations.filter((data_j) => {
            return token !== "all" ? data_j.tokenInvolved === token : true;
        });

        const received_row: TableRowData[] = [];
        pre_datas.forEach((data) => {
            const token = tokenExchange(data);
            if (!token) return;

            const detail = {
                event: data["operation"],
                oper_id: data["operId_"],
                exchange: token.exchange,
                receive: token.receive,
                created: (
                    <span>
                        <Moment
                            format={
                                i18n.language === "en"
                                    ? date.DATE_EN
                                    : date.DATE_ES
                            }
                        >
                            {data["createdAt"]}
                        </Moment>
                    </span>
                ),
                confirmation: data["confirmationTime"] ? (
                    <span>
                        <Moment
                            format={
                                i18n.language === "en"
                                    ? date.DATE_EN
                                    : date.DATE_ES
                            }
                        >
                            {data["confirmationTime"]}
                        </Moment>
                    </span>
                ) : (
                    "--"
                ),
                recipient:
                    data.params?.recipient !== "--"
                        ? data.params?.recipient || ""
                        : "--",
                recipient_truncate:
                    data.params?.recipient !== "--"
                        ? TruncatedAddress(data.params?.recipient || "") || "--"
                        : "--",
                block: data["blockNumber"] || "--",
                tx_hash_truncate: TruncatedAddress(data["hash"] || "") || "--",
                tx_hash: data["hash"] || "--",
                gas_fee: data["gas_fee"] || data["gasFeeRBTC"] || "--",
                gas: data["gas"] || "--",
                gas_price: data["gasPrice"] || "--",
                gas_used: data["gasUsed"] || "--",
                error_code: data["errorCode_"] || "--",
                msg:
                    getErrorMessage(data["msg_"]) ||
                    t("operations.errors.noMessage"),
                reason: data["reason_"] || "--",
                executed_tx_hash_truncate:
                    TruncatedAddress(data.params?.hash || "") || "--",
                executed_tx_hash: data.params?.hash || "--",
                status: getStatus(data) || "--",
                fee: getFee(data) || "--",
                price: getPrice(data),
                price_another_token: getPriceAnotherToken(data),
            };

            received_row.push({
                key: data._id,
                info: "",
                exchange: (
                    <>
                        {token.receive.action !== "Error" && (
                            <Fragment>
                                <div className="lastOp__detail__item">
                                    <div className="">
                                        <div className="lastOp__detail__label">
                                            {token.exchange.title}
                                        </div>
                                        <div
                                            className="table-amount"
                                            data-testid="last-op-exchange-amount"
                                        >
                                            {(() => {
                                                const exchangeToken = token
                                                    .exchange
                                                    .token as TokenConfig;
                                                return (
                                                    <PrecisionNumbers
                                                        amount={BigInt(
                                                            token.exchange
                                                                .amount
                                                        )}
                                                        token={exchangeToken}
                                                        decimals={
                                                            exchangeToken ===
                                                            undefined
                                                                ? 2
                                                                : (exchangeToken.visibleDecimals ??
                                                                  2)
                                                        }
                                                        i18n={i18n}
                                                        compact={true}
                                                    />
                                                );
                                            })()}
                                        </div>
                                    </div>
                                    <div className="lastOp__detail__token__container">
                                        {getAsset(token.exchange.icon).image}
                                        <div className="lastOp__detail__token__ticker">
                                            {token.exchange.name}
                                        </div>
                                    </div>
                                </div>
                            </Fragment>
                        )}
                        {token.receive.action === "Error" && (
                            <Fragment>
                                <div>
                                    <div className="table-event-name">
                                        {token.exchange.title}
                                    </div>
                                    <div className="table-amount">--</div>
                                </div>
                                <div className="table-icon-name"></div>
                            </Fragment>
                        )}
                    </>
                ),
                receive: (
                    <>
                        {token.receive.action !== "Transfer" &&
                            token.receive.action !== "Error" && (
                                <Fragment>
                                    <div className="lastOp__detail__item">
                                        <div className="lastOpe_from_container">
                                            <div className="lastOp__detail__label">
                                                {token.receive.title}
                                            </div>
                                            <div
                                                className="lastOp__detail__amount"
                                                data-testid="last-op-receive-amount"
                                            >
                                                {(() => {
                                                    const receiveToken = token
                                                        .receive
                                                        .token as TokenConfig;
                                                    return token.receive
                                                        .amount === undefined
                                                        ? "--"
                                                        : PrecisionNumbers({
                                                              amount: BigInt(
                                                                  token.receive
                                                                      .amount
                                                              ),
                                                              token: receiveToken,
                                                              decimals:
                                                                  receiveToken ===
                                                                  undefined
                                                                      ? 2
                                                                      : (receiveToken.visibleDecimals ??
                                                                        2),
                                                              i18n: i18n,
                                                              compact: true,
                                                          });
                                                })()}
                                            </div>
                                        </div>
                                        <div className="lastOp__detail__token__container">
                                            {getAsset(token.receive.icon).image}
                                            <div className="lastOp__detail__token__ticker">
                                                {token.receive.name}
                                            </div>
                                        </div>
                                    </div>
                                </Fragment>
                            )}
                        {token.receive.action === "Transfer" && (
                            <Fragment>
                                <div className="lastOp__detail__item--double">
                                    <div className="lastOp__detail__transfer">
                                        <div className="lastOp__detail__label">
                                            {getTransferAction(data)}
                                        </div>
                                        <div className="lastOp__detail__address">
                                            {getTransferAddress(data)}
                                        </div>
                                    </div>
                                </div>
                            </Fragment>
                        )}
                        {token.receive.action === "Error" && (
                            <Fragment>
                                <div>
                                    <div className="lastOp__detail__label">
                                        {token.receive.title}
                                    </div>
                                    <br></br>
                                    <div className="table-amount"> -- </div>
                                </div>
                                <div className="table-icon-name"></div>
                            </Fragment>
                        )}
                    </>
                ),
                another: (
                    <>
                        {token.another.action !== "Transfer" &&
                            token.another.action !== "Error" && (
                                <Fragment>
                                    <div className="lastOp__detail__item">
                                        <div className="lastOpe_from_container">
                                            <div className="lastOp__detail__label">
                                                {token.another.title}
                                            </div>
                                            <div
                                                className="lastOp__detail__amount"
                                                data-testid="last-op-another-amount"
                                            >
                                                {(() => {
                                                    const receiveToken = token
                                                        .another
                                                        .token as TokenConfig;
                                                    return token.another
                                                        .amount === undefined
                                                        ? "--"
                                                        : PrecisionNumbers({
                                                              amount: BigInt(
                                                                  token.another
                                                                      .amount
                                                              ),
                                                              token: receiveToken,
                                                              decimals:
                                                                  receiveToken ===
                                                                  undefined
                                                                      ? 2
                                                                      : (receiveToken.visibleDecimals ??
                                                                        2),
                                                              i18n: i18n,
                                                              compact: true,
                                                          });
                                                })()}
                                            </div>
                                        </div>
                                        <div className="lastOp__detail__token__container">
                                            {getAsset(token.another.icon).image}
                                            <div className="lastOp__detail__token__ticker">
                                                {token.another.name}
                                            </div>
                                        </div>
                                    </div>
                                </Fragment>
                            )}
                        {token.another.action === "Transfer" && (
                            <Fragment>
                                <div className="lastOp__detail__item--double">
                                    <div className="lastOp__detail__transfer">
                                        <div className="lastOp__detail__label">
                                            {getTransferAction(data)}
                                        </div>
                                        <div className="lastOp__detail__address">
                                            {getTransferAddress(data)}
                                        </div>
                                    </div>
                                </div>
                            </Fragment>
                        )}
                        {token.another.action === "Error" && (
                            <Fragment>
                                <div>
                                    <div className="lastOp__detail__label">
                                        {token.another.title}
                                    </div>
                                    <br></br>
                                    <div className="table-amount"> -- </div>
                                </div>
                                <div className="table-icon-name"></div>
                            </Fragment>
                        )}
                    </>
                ),
                date: (
                    <div className="lastOp__date__container">
                        <div className="lastOp__detail__label">
                            {t("operations.columns.date")}
                        </div>
                        <div className="lastOp__detail__date">
                            {new Date(data["lastUpdatedAt"])
                                .toLocaleString("sv-SE", {
                                    year: "numeric",
                                    month: "2-digit",
                                    day: "2-digit",
                                    hour: "2-digit",
                                    minute: "2-digit",
                                    hour12: false,
                                })
                                .replace(",", "")}
                        </div>
                    </div>
                ),
                status: (
                    <Fragment>
                        <div
                            className={`tx-status-icon-${setStatusIcon(getStatus(data))}`}
                        />
                        <div
                            className={`table-status-icon ${getStatus(data) === t("operations.actions.statusFailed") && "table-status-icon-red"}`}
                        >
                            {getStatus(data)}
                        </div>
                    </Fragment>
                ),
                detail: detail || "--",
                renderRow: <></>,
                description: <></>,
            } as TableRowData);
        });

        const data: TableRowData[] = [];
        received_row.forEach((element) => {
            data.push({
                renderRow: (
                    <div className="lastOp__row">
                        <div className="LastOp__expand-collapse">
                            <ExpandIcon
                                expanded={expandedKeys.includes(element.key)}
                                onClick={() =>
                                    handleExpand(
                                        !expandedKeys.includes(element.key),
                                        element
                                    )
                                }
                            />
                        </div>

                        <div
                            className={`LastOp__group__details ${getDetailsLayoutClass(element.detail.event)}`}
                        >
                            <div className="LastOp__divider LastOp__divider--details-start"></div>
                            {element.detail.event === "ERROR" ? (
                                <div className="LastOp__revert">
                                    <span className="table-amount">
                                        {t(
                                            "operations.errors.failedBeforeExecution"
                                        )}
                                    </span>
                                </div>
                            ) : (
                                <>
                                    <div className="LastOp__origin">
                                        {element.exchange}
                                        {element.detail.event ===
                                            "TCandTPRedeem" && (
                                            <>
                                                <div className="LastOp__divider LastOp__divider--opaciti"></div>
                                                {element.another}
                                            </>
                                        )}
                                    </div>

                                    <div className="LastOp__divider LastOp__divider--details-middle"></div>
                                    <div className="LastOp__destination">
                                        {element.receive}
                                        {element.detail.event ===
                                            "TCandTPMint" && (
                                            <>
                                                <div className="LastOp__divider LastOp__divider--opaciti"></div>
                                                {element.another}
                                            </>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>
                        <div className="LastOp__group__dateStatus">
                            <div className="LastOp__divider"></div>
                            <div className="lastOp__date">{element.date}</div>
                            <div className="LastOp__divider"></div>
                            <div className="lastOp__status">
                                {element.status}
                            </div>
                        </div>
                    </div>
                ),
                key: element.key,
                info: "",
                description: (
                    <RowDetailMobile
                        detail={
                            element.detail as unknown as Parameters<
                                typeof RowDetailMobile
                            >[0]["detail"]
                        }
                    />
                ),
            } as TableRowData);
        });

        return data;
    }, [
        dataJson.operations,
        token,
        i18n,
        t,
        expandedKeys,
        getErrorMessage,
        getFee,
        getStatus,
        getTransferAction,
        getTransferAddress,
        handleExpand,
        setStatusIcon,
        tokenExchange,
        TruncatedAddress,
        getAsset,
        getDetailsLayoutClass,
        getPrice,
        getPriceAnotherToken,
    ]);

    const tableColumns = useMemo(
        () => (columns || []).map((item) => ({ ...item })),
        [columns]
    );
    /*useEffect(() => {
        setTimeout(() => setLoadingSke(false), timeSke);
    }, [auth]);*/
    const showModal = () => {
        setQueueModal(true);
    };
    const hideModal = () => {
        setQueueModal(false);
    };

    return (
        <>
            <div className="title layout-card-title">
                <h1 className="title-last-operations .layout-card-title">
                    {t(`operations.sectionTitle`, { ns: ns })}
                </h1>
                <div className="aboutQueue__button" onClick={showModal}>
                    {t(`operations.aboutQueue.button`, { ns: ns })}
                    <div className="logo-queue"></div>
                </div>
                {queueModal && (
                    <Modal
                        title={t("operations.aboutQueue.title", { ns: ns })}
                        width={505}
                        open={true}
                        onCancel={hideModal}
                        footer={null}
                        closable={false}
                        className="aboutQueue__modal ModalAccount "
                        centered={true}
                        maskStyle={{}}
                    >
                        <AboutQueue hideModal={hideModal} />
                    </Modal>
                )}
            </div>
            {ready || processedData.length > 0 ? (
                <>
                    <Table
                        data-testid="last-operations-table"
                        className={
                            "vertical-middle custom-border-spacing-table custom-table"
                        }
                        showHeader={false}
                        expandable={{
                            expandedRowKeys: expandedKeys,
                            onExpand: handleExpand,
                            expandedRowRender: (record) => (
                                <div className="table-expanded-row">
                                    {record.description}
                                </div>
                            ),
                            expandIconColumnIndex: -1, // Hide default expansion icon cell
                        }}
                        pagination={{
                            pageSize: pageSize,
                            position: ["bottomRight"],
                            defaultCurrent: 1,
                            onChange: onChange,
                            total: totalTable,
                            showSizeChanger: false,
                        }}
                        columns={tableColumns}
                        dataSource={
                            isConnected == true ? processedData : undefined
                        }
                        onRow={(_record, index) => ({
                            "data-testid": `last-operations-row-${index ?? 0}`,
                        } as React.HTMLAttributes<HTMLTableRowElement>)}
                        scroll={{ y: lastOperationsHeight }}
                        style={{}}
                        loading={!ready && processedData.length === 0}
                    />
                </>
            ) : (
                <Skeleton active={true} paragraph={{ rows: 4 }}></Skeleton>
            )}
        </>
    );
}
