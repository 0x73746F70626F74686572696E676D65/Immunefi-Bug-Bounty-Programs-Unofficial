import { useMemo } from "react";

import { normalizeToBigInt } from "../helpers/precision";
import settings from "../settings";
import type {
    ContractInfo,
    DContracts,
    MultiCallErrorResult,
    MultiCallInput,
} from "../types/hooks";
import type { OnchainPricesResult } from "../types/status";
import { useMultiCall } from "./useMulticall";

function isPeekResult(result: unknown): result is [string | bigint, boolean] {
    return (
        Array.isArray(result) &&
        result.length >= 2 &&
        (typeof result[0] === "string" || typeof result[0] === "bigint") &&
        typeof result[1] === "boolean"
    );
}

// peek() calls revert outright when a price provider rejects the caller
// (e.g. an access-controlled feed that only whitelists the real Moc bucket
// contract) — that's a permanent revert, not a transient error, so every
// consumer must still get the [price, valid] tuple shape it expects rather
// than the generic `null` fallback for non-scalar resultTypes.
const onErrorGetInvalidPeek = (): MultiCallErrorResult => {
    return { value: [0n, false] };
};

/**
 * React hook that wraps useMultiCall3 to fetch contract status data.
 * Builds the call array with useMemo so it remains stable between renders.
 */
export function useOnchainPrices(
    contracts?: DContracts,
    refetchInterval = 30_000
): OnchainPricesResult {
    const callsRequests = useMemo(() => {
        if (!contracts) return [];

        // Voting project does not use this hook
        if (import.meta.env.REACT_APP_ENVIRONMENT_APP_PROJECT === "voting")
            return [];

        const callRequest: MultiCallInput[] = [];

        let PP_TP: ContractInfo | undefined;
        let PP_CA: ContractInfo | undefined;
        let PP_FeeToken: ContractInfo | undefined;

        for (let ca = 0; ca < settings.tokens.CA.length; ca++) {
            // CA prices
            PP_CA = contracts.PP_CA?.[ca];
            if (!PP_CA) continue;
            PP_FeeToken = contracts.PP_FeeToken?.[ca];
            if (!PP_FeeToken) continue;

            callRequest.push({
                contract: PP_CA,
                functionName: "peek",
                args: [],
                resultType: [
                    {
                        internalType: "bytes32",
                        name: "",
                        type: "bytes32",
                    },
                    {
                        internalType: "bool",
                        name: "",
                        type: "bool",
                    },
                ],
                keys: [ca, "CA"],
                transform: (result: unknown) => {
                    if (!isPeekResult(result)) return [null, false];
                    return [normalizeToBigInt(result[0]), result[1]];
                },
                onError: onErrorGetInvalidPeek,
            });

            // TP prices
            let tpAddress: string;
            for (let tp = 0; tp < settings.tokens.TP.length; tp++) {
                const tpContract = contracts.TP?.[tp];
                const ppTpContract = contracts.PP_TP?.[ca]?.[tp];
                if (!tpContract || !ppTpContract) continue;

                tpAddress = tpContract.address;
                PP_TP = ppTpContract;

                callRequest.push({
                    contract: PP_TP,
                    functionName: "peek",
                    args: [],
                    resultType: [
                        {
                            internalType: "bytes32",
                            name: "",
                            type: "bytes32",
                        },
                        {
                            internalType: "bool",
                            name: "",
                            type: "bool",
                        },
                    ],
                    keys: [ca, "TP", tp],
                    transform: (result: unknown) => {
                        if (!isPeekResult(result)) return [null, false];
                        return [normalizeToBigInt(result[0]), result[1]];
                    },
                    onError: onErrorGetInvalidPeek,
                });
            }

            // TF prices
            callRequest.push({
                contract: PP_FeeToken,
                functionName: "peek",
                args: [],
                resultType: [
                    {
                        internalType: "bytes32",
                        name: "",
                        type: "bytes32",
                    },
                    {
                        internalType: "bool",
                        name: "",
                        type: "bool",
                    },
                ],
                keys: [ca, "TF"],
                transform: (result: unknown) => {
                    const tuple = result as [string, boolean];
                    return [normalizeToBigInt(tuple[0]), tuple[1]];
                },
                onError: onErrorGetInvalidPeek,
            });

            if (contracts.PP_COINBASE) {
                callRequest.push({
                    contract: contracts.PP_COINBASE,
                    functionName: "peek",
                    args: [],
                    resultType: [
                        {
                            internalType: "bytes32",
                            name: "",
                            type: "bytes32",
                        },
                        {
                            internalType: "bool",
                            name: "",
                            type: "bool",
                        },
                    ],
                    keys: [ca, "COINBASE"],
                    transform: (result: unknown) => {
                        if (!isPeekResult(result)) return [null, false];
                        return [normalizeToBigInt(result[0]), result[1]];
                    },
                    onError: onErrorGetInvalidPeek,
                });
            }
        }

        return callRequest;
    }, [contracts]);

    // Pass callsRequests into your multicall hook (safe: it's a hook calling a hook)
    const multicallState = useMultiCall(callsRequests, {
        refetchInterval: refetchInterval,
        enabled: callsRequests.length > 0,
        scopeKey: ["onChainPrices"].join(":"),
    });

    return multicallState as unknown as OnchainPricesResult;
}
