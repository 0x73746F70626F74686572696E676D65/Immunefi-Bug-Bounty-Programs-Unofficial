from pymongo import ASCENDING, DESCENDING
import os
import json

from web3 import Web3

from .base.main import ConnectionHelperMongo
from .base.token import ERC20Token
from .tasks_manager import TasksManager
from .logger import log
from .contracts import Multicall2, MocMultiCollateralGuard, MocCARC20, MocCACoinbase, MocQueue, \
    OMOCDelayMachine, OMOCIncentiveV2, OMOCSupporters, OMOCVestingFactory, \
    OMOCVotingMachine, OMOCIRegistry, OMOCOracleManager, OMOCCoinPairPrice, \
    OMOCTasksRunner, OMOCTaskTriggerOrder, MocLendingManager
from .scan_raw_transactions import ScanRawTxs
from .scan_logs_transactions import ScanLogsTransactions
from .scan_transactions_status import ScanTxStatus

__VERSION__ = '4.3.13'

log.info("Starting Protocol Indexer version {0}".format(__VERSION__))


# Every collection an OMOC event handler in events.py may write. Every write
# there is an upsert on id_event, plus a legacy hash-only-doc existence check
# on hash - without indexes on both, insert throughput decays as each
# collection grows (moved here from scripts/backfill_omoc.py so the live
# indexer's own startup gets these too, not just a backfill run).
OMOC_EVENT_COLLECTIONS = [
    "event_IncentiveV2_ClaimOK",
    "event_VestingFactory_VestingCreated",
    "event_DelayMachine_PaymentCancel",
    "event_DelayMachine_PaymentDeposit",
    "event_DelayMachine_PaymentWithdraw",
    "event_Supporters_AddStake",
    "event_Supporters_CancelEarnings",
    "event_Supporters_PayEarnings",
    "event_Supporters_Withdraw",
    "event_Supporters_WithdrawStake",
    "event_VotingMachine_PreVoteEvent",
    "event_VotingMachine_VoteEvent",
    "event_VotingMachine_PreVoteStepEvent",
    "event_VotingMachine_VoteStepEvent",
    "event_VotingMachine_AcceptedStepEvent",
    "event_VotingMachine_UnregisterEvent",
    "event_OracleManager_OracleRegistered",
    "event_OracleManager_OracleStakeAdded",
    "event_OracleManager_OracleSubscribed",
    "event_OracleManager_OracleUnsubscribed",
    "event_OracleManager_OracleRemoved",
    "event_CoinPairPrice_PricePublished",
    "event_CoinPairPrice_EmergencyPricePublished",
    "event_CoinPairPrice_ForcedPriceQueryModeSet",
    "event_CoinPairPrice_OracleRewardTransfer",
    "event_CoinPairPrice_NewRound",
    "event_CoinPairPrice_OracleAutoUnsubscribed",
    "event_TasksRunner_TaskExecuted",
    "event_TaskTriggerOrder_TriggerOrdersReverted",
    "omoc_operations",
]


def read_omoc_json_file(filename=None):
    """ Read Json File """

    if not filename:
        filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'omoc.json')

    with open(filename) as f:
        options = json.load(f)

    return options


class StableIndexerTasks(TasksManager):

    def __init__(self, config):

        TasksManager.__init__(self)

        self.config = config
        self.connection_helper = ConnectionHelperMongo(config)

        self.contracts_loaded = dict()
        self.contracts_addresses = dict()
        self.filter_contracts_addresses = dict()

        # load contracts
        self.load_contracts()

        if 'IRegistry' in self.contracts_addresses:
            self.create_omoc_mongo_index()

        # Add tasks
        self.schedule_tasks()

    def load_contracts(self):
        """ Get contract address to use later """

        log.info("Loading contracts...")
        log.info("Getting addresses from Main Contract...")

        self.contracts_loaded["Multicall2"] = Multicall2(
            self.connection_helper.connection_manager,
            contract_address=self.config['addresses']['Multicall2'])

        log.info("MocMultiCollateralGuard using address: %s" % self.config['addresses']['MocMultiCollateralGuard'])
        # MocMultiCollateralGuard
        self.contracts_loaded["MocMultiCollateralGuard"] = MocMultiCollateralGuard(
            self.connection_helper.connection_manager,
            contract_address=self.config['addresses']['MocMultiCollateralGuard'])
        self.contracts_addresses['MocMultiCollateralGuard'] = self.contracts_loaded[
            "MocMultiCollateralGuard"].address().lower()

        # Reading MoC Buckets from Multi collateral Guard
        self.contracts_loaded['Moc'] = list()
        self.contracts_loaded["CA"] = list()
        self.contracts_loaded["TC"] = list()
        self.contracts_loaded["MocQueue"] = list()

        self.contracts_addresses['Moc'] = list()
        self.contracts_addresses['CA'] = list()
        self.contracts_addresses['TC'] = list()
        self.contracts_addresses['MocQueue'] = list()

        for ca_index, ca in enumerate(self.config['collateral']):
            # get bucket address from guard
            moc_bucket_address = self.contracts_loaded["MocMultiCollateralGuard"].buckets(ca_index)

            contract_interface = MocCACoinbase
            if ca['type'] == 'rc20':
                contract_interface = MocCARC20

            log.info("MoC Bucket ({0}) using address: {1}".format(ca['name'], moc_bucket_address))

            moc_bucket = contract_interface(
                self.connection_helper.connection_manager,
                contract_address=moc_bucket_address)
            self.contracts_loaded['Moc'].append(moc_bucket)
            self.contracts_addresses['Moc'].append(moc_bucket.address().lower())

            if ca['type']  == 'rc20':
                ca_token_address = moc_bucket.ac_token()
                log.info("({0}) Collateral {1} using address: {2}".format(ca['name'], self.config["collateral"][0]["name"], ca_token_address))
                ca_token = ERC20Token(
                    self.connection_helper.connection_manager,
                    contract_address=ca_token_address)
                self.contracts_loaded["CA"].append(ca_token)
                self.contracts_addresses['CA'].append(ca_token_address.lower())

            # MocQueue
            moc_queue_addr = moc_bucket.moc_queue()
            log.info("({0}) MocQueue using address: {1}".format(ca['name'], moc_queue_addr.lower()))
            self.contracts_loaded["MocQueue"].append(MocQueue(
                self.connection_helper.connection_manager,
                self.config,
                contract_address=moc_queue_addr))
            self.contracts_addresses['MocQueue'].append(moc_queue_addr.lower())

            # Token TC
            tc_token_addr = moc_bucket.tc_token()
            log.info("({0}) TC {1} using address: {2}".format(ca['name'], self.config["collateralToken"][0]["name"], tc_token_addr.lower()))
            self.contracts_loaded["TC"].append(ERC20Token(
                self.connection_helper.connection_manager,
                contract_address=tc_token_addr))
            self.contracts_addresses['TC'].append(tc_token_addr.lower())

        # TP Token Pegged
        # In multi-collateral we have the assumption that all collateral
        # have the same TPs, this why only watch the first collateral only
        self.contracts_loaded["TP"] = list()
        self.contracts_addresses['TP'] = list()
        bucket_index = 0
        for tp_i, tp in enumerate(self.config['pegged']):
            tp_address = self.contracts_loaded["Moc"][bucket_index].tp_tokens(tp_i)
            if not tp_address:
                continue
            log.info("TP {0} using address: {1}".format(self.config["pegged"][0]["name"], tp_address.lower()))
            self.contracts_loaded["TP"].append(
                ERC20Token(
                    self.connection_helper.connection_manager,
                    contract_address=tp_address)
            )
            self.contracts_addresses['TP'].append(tp_address.lower())

        # FeeToken
        # NOTE: In multi-collateral we have the assumption that all collateral
        # have the same FeeToken, this why only watch the first collateral only

        bucket_index = 0
        fee_token_address = self.contracts_loaded["Moc"][bucket_index].fee_token()
        log.info("Fee Token {0} using address: {1}".format(self.config["feeToken"][0]["name"], fee_token_address.lower()))
        self.contracts_loaded["FeeToken"] = ERC20Token(
            self.connection_helper.connection_manager,
            contract_address=fee_token_address)
        self.contracts_addresses['FeeToken'] = self.contracts_loaded["FeeToken"].address().lower()

        # OMOC

        omoc = read_omoc_json_file()

        # IRegistry
        log.info("IRegistry using address: {0}".format(self.config['addresses']['IRegistry'].lower()))
        self.contracts_loaded["IRegistry"] = OMOCIRegistry(
            self.connection_helper.connection_manager,
            self.config,
            contract_address=self.config['addresses']['IRegistry'])
        self.contracts_addresses['IRegistry'] = self.contracts_loaded["IRegistry"].address().lower()

        # Getting addresses from Registry
        self.contracts_addresses['DelayMachine'] = self.contracts_loaded["IRegistry"].sc.functions.getAddress(
            omoc['RegistryConstants']['MOC_DELAY_MACHINE']).call().lower()
        self.contracts_addresses['Supporters'] = self.contracts_loaded["IRegistry"].sc.functions.getAddress(
            omoc['RegistryConstants']['SUPPORTERS_ADDR']).call().lower()
        self.contracts_addresses['VestingFactory'] = self.contracts_loaded["IRegistry"].sc.functions.getAddress(
            omoc['RegistryConstants']['MOC_VESTING_MACHINE']).call().lower()
        self.contracts_addresses['VotingMachine'] = self.contracts_loaded["IRegistry"].sc.functions.getAddress(
            omoc['RegistryConstants']['MOC_VOTING_MACHINE']).call().lower()
        self.contracts_addresses['StakingMachine'] = self.contracts_loaded["IRegistry"].sc.functions.getAddress(
            omoc['RegistryConstants']['MOC_STAKING_MACHINE']).call().lower()

        # IncentiveV2
        if self.config['addresses'].get('IncentiveV2'):
            log.info("IncentiveV2 using address: {0}".format(self.config['addresses']['IncentiveV2'].lower()))
            self.contracts_loaded["IncentiveV2"] = OMOCIncentiveV2(
                self.connection_helper.connection_manager,
                self.config,
                contract_address=self.config['addresses']['IncentiveV2'])
            self.contracts_addresses['IncentiveV2'] = self.contracts_loaded["IncentiveV2"].address().lower()

        # TasksRunner (optional): no registry constant published, address comes from config
        if self.config['addresses'].get('TasksRunner'):
            log.info("TasksRunner using address: {0}".format(self.config['addresses']['TasksRunner'].lower()))
            self.contracts_loaded["TasksRunner"] = OMOCTasksRunner(
                self.connection_helper.connection_manager,
                self.config,
                contract_address=self.config['addresses']['TasksRunner'])
            self.contracts_addresses['TasksRunner'] = self.contracts_loaded["TasksRunner"].address().lower()

        # TaskTriggerOrder (optional): a mocFlow task run by TasksRunner, address comes from config
        if self.config['addresses'].get('TaskTriggerOrder'):
            log.info("TaskTriggerOrder using address: {0}".format(self.config['addresses']['TaskTriggerOrder'].lower()))
            self.contracts_loaded["TaskTriggerOrder"] = OMOCTaskTriggerOrder(
                self.connection_helper.connection_manager,
                self.config,
                contract_address=self.config['addresses']['TaskTriggerOrder'])
            self.contracts_addresses['TaskTriggerOrder'] = self.contracts_loaded["TaskTriggerOrder"].address().lower()

        # DelayMachine
        log.info("DelayMachine using address: {0}".format(self.contracts_addresses['DelayMachine'].lower()))
        self.contracts_loaded["DelayMachine"] = OMOCDelayMachine(
            self.connection_helper.connection_manager,
            self.config,
            contract_address=self.contracts_addresses['DelayMachine'])

        # Supporters
        log.info("Supporters using address: {0}".format(self.contracts_addresses['Supporters'].lower()))
        self.contracts_loaded["Supporters"] = OMOCSupporters(
            self.connection_helper.connection_manager,
            self.config,
            contract_address=self.contracts_addresses['Supporters'])

        # VestingFactory
        log.info("VestingFactory using address: {0}".format(self.contracts_addresses['VestingFactory'].lower()))
        self.contracts_loaded["VestingFactory"] = OMOCVestingFactory(
            self.connection_helper.connection_manager,
            self.config,
            contract_address=self.contracts_addresses['VestingFactory'])

        # VotingMachine
        log.info("VotingMachine using address: {0}".format(self.contracts_addresses['VotingMachine'].lower()))
        self.contracts_loaded["VotingMachine"] = OMOCVotingMachine(
            self.connection_helper.connection_manager,
            self.config,
            contract_address=self.contracts_addresses['VotingMachine'])
        self.contracts_addresses['VotingMachine'] = self.contracts_loaded["VotingMachine"].address().lower()

        # MocLendingManager (optional — only loaded when address is provided in config)
        if self.config['addresses'].get('MocLendingManager'):
            lending_address = self.config['addresses']['MocLendingManager']
            log.info("MocLendingManager using address: {0}".format(lending_address.lower()))
            self.contracts_loaded["MocLendingManager"] = MocLendingManager(
                self.connection_helper.connection_manager,
                contract_address=lending_address)
            self.contracts_addresses['MocLendingManager'] = self.contracts_loaded[
                "MocLendingManager"].address().lower()

        # OracleManager
        oracle_manager_address = self.contracts_loaded["IRegistry"].sc.functions.getAddress(
            omoc['RegistryConstants']['ORACLE_MANAGER_ADDR']).call().lower()
        log.info("OracleManager using address: {0}".format(oracle_manager_address))
        self.contracts_loaded["OracleManager"] = OMOCOracleManager(
            self.connection_helper.connection_manager,
            self.config,
            contract_address=oracle_manager_address)
        self.contracts_addresses['OracleManager'] = oracle_manager_address

        # CoinPairPrice: one contract per registered coin pair
        self.contracts_loaded["CoinPairPrice"] = list()
        self.contracts_addresses['CoinPairPrice'] = list()
        self.contracts_coin_pairs = list()

        zero_address = '0x0000000000000000000000000000000000000000'
        coin_pair_count = self.contracts_loaded["OracleManager"].coin_pair_count()
        for i in range(coin_pair_count):
            coin_pair = self.contracts_loaded["OracleManager"].coin_pair_at_index(i)
            cp_address = self.contracts_loaded["OracleManager"].contract_address_of(coin_pair).lower()
            if cp_address == zero_address:
                # deleted coin pair
                continue
            try:
                coin_pair_name = Web3.to_text(coin_pair).rstrip('\x00')
            except Exception:
                coin_pair_name = coin_pair.hex() if hasattr(coin_pair, 'hex') else str(coin_pair)
            log.info("CoinPairPrice ({0}) using address: {1}".format(coin_pair_name, cp_address))
            cp_contract = OMOCCoinPairPrice(
                self.connection_helper.connection_manager,
                self.config,
                contract_address=cp_address)
            cp_contract.coin_pair = coin_pair_name
            self.contracts_loaded["CoinPairPrice"].append(cp_contract)
            self.contracts_addresses['CoinPairPrice'].append(cp_address)
            self.contracts_coin_pairs.append(coin_pair_name)

        self.filter_contracts_addresses = []
        for k, v in self.contracts_addresses.items():
            if isinstance(v, list):
                for v2 in v:
                    self.filter_contracts_addresses.append(v2.lower())
            elif isinstance(v, str):
                self.filter_contracts_addresses.append(v.lower())
            else:
                raise Exception("Filter address not recognize!")

        for white_address in self.config['contracts_white_list']:
            self.filter_contracts_addresses.append(white_address.lower())

    def create_core_mongo_index(self):
        """Indexes for the core (non-OMOC) collections: operations / raw_transactions.

        Deliberately NOT called from __init__ - scripts/backfill_omoc.py also
        constructs a StableIndexerTasks, and its whole premise is that it never
        touches operations / raw_transactions / moc_indexer. Only
        app_run_indexer.py (the live indexer's actual entry point) calls this."""

        # Operations collection
        index_map = [('operId_', DESCENDING)]
        self.connection_helper.create_index('operations', index_map, unique=False)

        index_map = [('createdAt', DESCENDING)]
        self.connection_helper.create_index('operations', index_map, unique=False)

        # Lending user operations collection
        self.connection_helper.create_index('lending_user_operations', [('id_event', ASCENDING)], unique=True)
        self.connection_helper.create_index('lending_user_operations', [('user', ASCENDING), ('blockNumber', DESCENDING), ('_id', DESCENDING)], unique=False)
        self.connection_helper.create_index('lending_user_operations', [('blockNumber', DESCENDING), ('_id', DESCENDING)], unique=False)
        self.connection_helper.create_index('lending_user_operations', [('operId', ASCENDING)], unique=False)

        # Lending event collections: id_event / hash back the indexer's upserts,
        # blockNumber (alone and paired with each API filter field) backs the
        # API listings sorted by blockNumber desc.
        lending_filter_fields = {
            'event_Lending_Deposit': ['user', 'recipient'],
            'event_Lending_Withdraw': ['user', 'recipient'],
            'event_Lending_AddACtoVault': ['user', 'recipient'],
            'event_Lending_RemoveACfromVault': ['user', 'recipient'],
            'event_Lending_Borrow': ['user', 'recipient'],
            'event_Lending_Repay': ['user', 'recipient'],
            'event_Lending_RepayWithAC': ['user'],
            'event_Lending_Liquidate': ['user', 'liquidator'],
            'event_Lending_TPInjection': [],
            'event_Lending_OperationQueued': ['user', 'recipient'],
            'event_Lending_OperationError': ['operId'],
            'event_Lending_OperationExecuted': ['operId'],
        }
        for collection_name, filter_fields in lending_filter_fields.items():
            self.connection_helper.create_index(collection_name, [('id_event', ASCENDING)], unique=False)
            self.connection_helper.create_index(collection_name, [('hash', ASCENDING)], unique=False)
            self.connection_helper.create_index(collection_name, [('blockNumber', DESCENDING), ('_id', DESCENDING)], unique=False)
            for field in filter_fields:
                self.connection_helper.create_index(
                    collection_name, [(field, ASCENDING), ('blockNumber', DESCENDING), ('_id', DESCENDING)], unique=False)

        # Case-insensitive address lookups (API's operations_list $or: params.{recipient,sender}
        # and executed.{recipient_,sender_} - stored checksummed, queried lowercased) require
        # the index to carry the same collation as the query, or Mongo falls back to a full
        # collection scan.
        address_collation = {"locale": "en", "strength": 2}

        index_map = [('params.recipient', ASCENDING)]
        self.connection_helper.create_index(
            'operations', index_map, unique=False, collation=address_collation)

        index_map = [('params.sender', ASCENDING)]
        self.connection_helper.create_index(
            'operations', index_map, unique=False, collation=address_collation)

        index_map = [('executed.recipient_', ASCENDING)]
        self.connection_helper.create_index(
            'operations', index_map, unique=False, collation=address_collation)

        index_map = [('executed.sender_', ASCENDING)]
        self.connection_helper.create_index(
            'operations', index_map, unique=False, collation=address_collation)

        # API's queued_opers filters on status + operation with no index on either.
        index_map = [('status', ASCENDING), ('operation', ASCENDING)]
        self.connection_helper.create_index('operations', index_map, unique=False)

        # Raw transactions collection: hash lookups (dedup / status checks) were
        # doing a full collection scan.
        index_map = [('hash', ASCENDING)]
        self.connection_helper.create_index('raw_transactions', index_map, unique=False)

        # scan_logs_transactions.py's scan_events_txs(): find({"processed": False},
        # sort=[("blockNumber", 1)]) polls this exact filter+sort shape forever,
        # whether or not there's anything left to process - without this compound,
        # every poll full-scans the collection to return nothing.
        index_map = [('processed', ASCENDING), ('blockNumber', ASCENDING)]
        self.connection_helper.create_index('raw_transactions', index_map, unique=False)

    def create_omoc_mongo_index(self):
        """Indexes for the OMOC event collections - safe for both the live indexer
        and the backfill script to ensure, since both legitimately write these."""

        address_collation = {"locale": "en", "strength": 2}

        # OMOC address-filtered API lookups (api/routers/omoc.py): same checksummed-vs-lowercased
        # mismatch as operations above, same collation requirement.
        index_map = [('holder', ASCENDING)]
        self.connection_helper.create_index(
            'event_VestingFactory_VestingCreated', index_map, unique=False, collation=address_collation)

        index_map = [('recipient', ASCENDING)]
        self.connection_helper.create_index(
            'event_IncentiveV2_ClaimOK', index_map, unique=False, collation=address_collation)

        # Write-side idempotency for every OMOC event collection (id_event is the
        # upsert key, hash backs the legacy-doc cleanup check) - see
        # OMOC_EVENT_COLLECTIONS above.
        for name in OMOC_EVENT_COLLECTIONS:
            self.connection_helper.create_index(name, [('id_event', ASCENDING)], unique=False)
            self.connection_helper.create_index(name, [('hash', ASCENDING)], unique=False)

    def schedule_tasks(self):

        log.info("Starting adding indexer tasks...")

        # set max workers
        self.max_workers = 1

        # 1. Scan Raw Transactions
        if 'scan_raw_transactions' in self.config['tasks']:
            log.info("Jobs add: 1. Scan Raw Transactions")
            interval = self.config['tasks']['scan_raw_transactions']['interval']
            scan_raw_txs = ScanRawTxs(self.config, self.connection_helper, self.filter_contracts_addresses)
            self.add_task(scan_raw_txs.on_task,
                          args=[],
                          wait=interval,
                          timeout=180,
                          task_name='1. Scan Raw Transactions')

        # 2. Scan Logs Txs
        if 'scan_logs' in self.config['tasks']:
            log.info("Jobs add: 2. Scan Logs Transactions")
            interval = self.config['tasks']['scan_logs']['interval']
            scan_logs_txs = ScanLogsTransactions(
                self.config,
                self.connection_helper,
                self.contracts_loaded,
                self.contracts_addresses,
                self.filter_contracts_addresses)
            self.add_task(scan_logs_txs.on_task,
                          args=[],
                          wait=interval,
                          timeout=180,
                          task_name='2. Scan Logs Transactions')

        # 3. Scan TX Status
        if 'scan_tx_status' in self.config['tasks']:
            log.info("Jobs add: 3. Scan Transactions Status")
            interval = self.config['tasks']['scan_tx_status']['interval']
            scan_tx_status = ScanTxStatus(self.config, self.connection_helper)
            self.add_task(scan_tx_status.on_task,
                          args=[],
                          wait=interval,
                          timeout=180,
                          task_name='3. Scan Transactions Status')

        # 4. Scan Raw Transactions Confirming
        if 'scan_raw_transactions_confirming' in self.config['tasks']:
            log.info("Jobs add: 4. Scan Raw Transactions Confirming")
            interval = self.config['tasks']['scan_raw_transactions_confirming']['interval']
            scan_raw_txs_confirming = ScanRawTxs(self.config, self.connection_helper, self.filter_contracts_addresses)
            self.add_task(scan_raw_txs_confirming.on_task_confirming,
                          args=[],
                          wait=interval,
                          timeout=180,
                          task_name='4. Scan Raw Transactions Confirming')

        # 5. Scan Raw Transactions History
        if 'scan_raw_transactions_history' in self.config['tasks']:
            log.info("Jobs add: 5. Scan Raw Transactions History")
            interval = self.config['tasks']['scan_raw_transactions_history']['interval']
            scan_raw_txs_history = ScanRawTxs(self.config, self.connection_helper,
                                                 self.filter_contracts_addresses)
            self.add_task(scan_raw_txs_history.on_task_history,
                          args=[],
                          wait=interval,
                          timeout=180,
                          task_name='5. Scan Raw Transactions History')

        # Set max tasks
        self.max_tasks = len(self.tasks)
