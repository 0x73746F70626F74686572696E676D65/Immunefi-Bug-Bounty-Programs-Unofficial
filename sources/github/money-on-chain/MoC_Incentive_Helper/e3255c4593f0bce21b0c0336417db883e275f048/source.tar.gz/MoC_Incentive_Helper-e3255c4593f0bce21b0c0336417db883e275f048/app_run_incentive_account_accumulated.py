import os
import json

from incentive_helper.main import IncentiveHelper


def options_from_config(filename=None):
    """ Options from file config.json """

    if not filename:
        filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'config.json')

    with open(filename) as f:
        options = json.load(f)

    return options


if __name__ == '__main__':

    config = options_from_config()

    # override config default
    if 'APP_CONFIG' in os.environ:
        config = json.loads(os.environ['APP_CONFIG'])

    # override mongo uri from env
    if 'APP_MONGO_URI' in os.environ:
        config['mongo']['uri'] = os.environ['APP_MONGO_URI']

    # override mongo db from env
    if 'APP_MONGO_DB' in os.environ:
        config['mongo']['db'] = os.environ['APP_MONGO_DB']

    # override connection uri from env
    if 'APP_CONNECTION_URI' in os.environ:
        config['uri'] = os.environ['APP_CONNECTION_URI']

    filter_info = dict()
    # note: incentive_accumulated() aggregates ALL accounts in the reward program,
    # it does not filter by a single account
    filter_info['date_from'] = '2020-01-01 00:00:00'
    filter_info['date_end'] = '2026-12-31 23:59:59'

    config['path_report'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'report')

    report = IncentiveHelper(config)
    report.report_incentive_accumulated(filter_info)
