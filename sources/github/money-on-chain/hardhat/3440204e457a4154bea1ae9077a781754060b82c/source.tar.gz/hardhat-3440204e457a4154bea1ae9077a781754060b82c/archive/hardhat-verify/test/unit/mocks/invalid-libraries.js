module.exports = ["SomeLibraryAddress", "AnotherLibraryAddress"];
