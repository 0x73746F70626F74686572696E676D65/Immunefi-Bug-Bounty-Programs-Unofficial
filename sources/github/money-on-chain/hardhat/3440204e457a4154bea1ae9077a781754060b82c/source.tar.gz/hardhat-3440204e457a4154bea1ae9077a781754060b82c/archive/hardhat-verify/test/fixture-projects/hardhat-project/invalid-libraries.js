module.exports = {
  SomeLibrary: "notAnAddress",
};
