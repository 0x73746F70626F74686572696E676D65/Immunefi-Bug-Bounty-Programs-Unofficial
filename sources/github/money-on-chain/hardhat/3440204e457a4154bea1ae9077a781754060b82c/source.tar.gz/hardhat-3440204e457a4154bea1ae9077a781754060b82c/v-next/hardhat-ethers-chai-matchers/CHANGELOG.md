# @nomicfoundation/hardhat-ethers-chai-matchers

## 3.0.0

### Major Changes

- 29cc141: First release of Hardhat 3!
