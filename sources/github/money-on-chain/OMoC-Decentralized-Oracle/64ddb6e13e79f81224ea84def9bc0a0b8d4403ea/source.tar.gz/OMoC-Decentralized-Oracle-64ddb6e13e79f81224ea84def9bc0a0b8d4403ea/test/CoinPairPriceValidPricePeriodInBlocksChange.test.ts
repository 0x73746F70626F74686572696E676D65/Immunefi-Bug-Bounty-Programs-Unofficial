import { network } from 'hardhat';
import { initContractsWithCoinPairs } from '../src/helpers.js';
import { Deployer } from 'ts-test-helpers';

describe('CoinPairPriceValidPricePeriodInBlocksChange', function () {
    it('Should succeed execute call', async function () {
        const { viem } = await network.create();
        const deployer = await Deployer.default(viem);
        const accounts = await viem.getWalletClients();
        const contracts = await initContractsWithCoinPairs(deployer, accounts[8], 3n, 10n ** 18n);

        const change = await deployer.deploy('CoinPairPriceValidPricePeriodInBlocksChange', [
            contracts.coinPairPriceBTCUSD.address,
            10n,
        ]);

        await contracts.governor.execute(change);
    });
});
