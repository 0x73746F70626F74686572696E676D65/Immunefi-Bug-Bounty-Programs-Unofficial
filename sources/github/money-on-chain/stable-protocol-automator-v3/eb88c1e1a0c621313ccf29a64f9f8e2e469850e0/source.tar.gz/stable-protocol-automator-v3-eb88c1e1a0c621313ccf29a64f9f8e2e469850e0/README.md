# Stable Protocol Automator v3 (Multicollateral)

### Warning: This is only for version 3 of the main contracts.

| Project              | Version | V3 | 
|----------------------|---------|----|
| MOC (Money on Chain) | V1      | ❌  |
| ROC (RIF on Chain)   | V3      | ✅  |


This is a backend executor jobs. Periodic tasks that runs different jobs, 
that call the contracts and asks if they are ready to execute it. This jobs 
run async of the app, and call directly to the contract through node. 

### Currents tasks

 1. Contract calculate EMA if it's the time
 2. Contract run settlement if it's the time
 3. Pay TC Holders Interest if it's the time
 4. Oracle Compute: Check expiration of price in Oracle.
 5. Run Commission Splitter if need it
 6. Run Commission Splitter V3 if need it
 7. Run BufferToken liquidate/flush if need it
 8. Trigger Reverse Auction Orders if ready
 9. Refresh AC Balance

Optional settings:

`max_fee_per_gas` and `max_priority_fee_per_gas` can be set at the top level of the config to send EIP-1559 style transactions.

`tasks.refresh_ac_balance.balance_threshold` sets the minimum unaccounted AC balance required before sending `refreshACBalance()`. The value is expressed in raw token units and defaults to `0`.

`tasks.commission_splitters_v3` configures one or more `CommissionSplitterV3`-style contracts that expose the same `split()` entrypoint as the v2 splitters. Use this for splitter contracts that collect TC interest, such as the RIF bucket interest splitter. Each entry uses the same shape as `tasks.commission_splitters`.

`tasks.buffers` configures one or more `BufferToken` contracts. For each configured entry, the automator calls `isLiquidable()` and sends `liquidate()` when the buffer-level threshold is met. Otherwise it inspects every output via `getNumOutputs()` and calls `flush(i)` for any output where `isFlushable(i)` is true.

Example entry:

```json
{
  "interval": 20,
  "wait_timeout": 240,
  "gas_limit": 1000000,
  "address": "0xYourBufferTokenAddress"
}
```

`tasks.reverse_auctions` configures one or more `MocReverseAuction` contracts. For each configured entry, the automator calls `readyToTriggerOrders()` and, when true, executes `triggerOrders()`.

For ROC-style fee flows, configure every reverse auction leg explicitly. In practice this usually means one auction that routes back into the RIF bucket and one auction that routes back into the DOC bucket, plus any other fee-flow auctions that should be triggered by the automator.

Example entry:

```json
{
  "interval": 20,
  "wait_timeout": 240,
  "gas_limit": 1000000,
  "address": "0xYourMocReverseAuctionAddress"
}
```

For multicollateral buckets, the automator treats `uint256.max` time spans as explicit disable sentinels for settlement, EMA calculation, and TC interest payment. This prevents contracts configured with that sentinel from being executed continuously because of timestamp wraparound in on-chain scheduling.
 
### Usage

**Requirement and installation**
 
*  We need Python 3.10+

Install libraries

`pip install -r requirements.txt`

**Usage**

Select settings from environments/ and copy to ./config.json 

**Run**

Copy the example env file and fill in your values:

```
cp .env.example .env
```

Edit `.env`:

```
ACCOUNT_PK_SECRET=<your private key>

# Optional: override the RPC node URL from config.json
APP_CONNECTION_URI=https://public-node.rsk.co
```

Then run:

```
set -a && source .env && set +a
python ./app_run_automator.py
```

**Usage Docker**

Build, change path to correct environment:

```
docker build -t automator_v3 -f Dockerfile --build-arg CONFIG=./environments/production/roc-mainnet/config.json .
```

Run using the env file:

```
docker run -d \
  --name automator_1 \
  --env-file .env \
  automator_v3
```
