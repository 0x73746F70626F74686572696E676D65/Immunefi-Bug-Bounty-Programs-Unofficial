import os
import json

from automator.tasks import AutomatorTasks


def options_from_config(filename=None):
    """ Options from file config.json """

    if not filename:
        filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'config.json')

    with open(filename) as f:
        options = json.load(f)

    return options


if __name__ == '__main__':

    try:
        config = options_from_config()
    except FileNotFoundError as e:
        raise SystemExit("Config file not found: {}".format(e))

    # override config default
    if 'APP_CONFIG' in os.environ:
        try:
            config = json.loads(os.environ['APP_CONFIG'])
        except json.JSONDecodeError as e:
            raise SystemExit("APP_CONFIG contains invalid JSON: {}".format(e))

    # override connection uri from env
    if 'APP_CONNECTION_URI' in os.environ:
        config['uri'] = os.environ['APP_CONNECTION_URI']

    moc_tasks = AutomatorTasks(config)
    moc_tasks.start_loop()
