"""
                    GNU AFFERO GENERAL PUBLIC LICENSE
                       Version 3, 19 November 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

 THIS IS A PART OF MONEY ON CHAIN PACKAGE
 by Martin Mulone (martin.mulone@moneyonchain.com)

"""

import os
import logging
from web3.types import BlockIdentifier

from .base.contracts import Contract


def _estimate_or_send(sc_function, connection_manager, args, kwargs):
    """Call estimate_gas or send the real transaction depending on kwargs flags."""
    estimate_gas = kwargs.pop('estimate_gas', False)
    from_address = kwargs.pop('from_address', None)

    if estimate_gas:
        return sc_function(*args).estimate_gas({'from': from_address})

    return connection_manager.send_function_transaction(sc_function, *args, **kwargs)


class MocCARC20(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'MocCARC20'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/MocCARC20.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def update_emas(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.updateEmas, self.connection_manager, args, kwargs)

    def execute_settlement(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.execSettlement, self.connection_manager, args, kwargs)

    def tc_holders_interest_payment(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.tcHoldersInterestPayment, self.connection_manager, args, kwargs)

    def refresh_ac_balance(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.refreshACBalance, self.connection_manager, args, kwargs)

    def ac_balance_collateral_bag(self):
        return self.sc.functions.nACcb().call()

    def ac_token(self):
        return self.sc.functions.acToken().call()

    def locked_in_pending(self):
        return self.sc.functions.qACLockedInPending().call()

    def tp_tokens(self, index):
        return self.sc.functions.tpTokens(index).call()

    def pegged_token_index(self, tp_address):
        return self.sc.functions.peggedTokenIndex(tp_address).call()

    def peg_container(self, index):
        return self.sc.functions.pegContainer(index).call()


class MocCACoinbase(MocCARC20):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'MocCACoinbase'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/MocCACoinbase.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()


class MoCMedianizer(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'MoCMedianizer'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/MoCMedianizer.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def poke(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.poke, self.connection_manager, args, kwargs)


class PriceProvider(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'PriceProvider'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/MoCMedianizer.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def peek(self):
        return self.sc.functions.peek().call()


class CommissionSplitter(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'CommissionSplitter'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/CommissionSplitter.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def split(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.split, self.connection_manager, args, kwargs)


class BufferToken(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'BufferToken'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/BufferToken.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def get_num_outputs(self):
        return self.sc.functions.getNumOutputs().call()

    def is_liquidable(self):
        return self.sc.functions.isLiquidable().call()

    def is_flushable(self, index):
        return self.sc.functions.isFlushable(index).call()

    def liquidate(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.liquidate, self.connection_manager, args, kwargs)

    def flush(self, *args, **kwargs):
        return _estimate_or_send(
            self.sc.functions.flush, self.connection_manager, args, kwargs)


class MocMultiCollateralGuard(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'MocMultiCollateralGuard'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/MocMultiCollateralGuard.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def buckets(self, index):
        return self.sc.functions.buckets(index).call()

    def ac_coinbase_price_provider(self, moc_bucket):
        return self.sc.functions.acCoinbasePriceProvider(moc_bucket).call()


class MocReverseAuction(Contract):

    log = logging.getLogger()
    precision = 10 ** 18

    contract_name = 'MocReverseAuction'
    contract_abi = Contract.content_abi_file(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'abi/MocReverseAuction.abi'))

    def __init__(self, connection_manager, contract_address=None, contract_abi=None, contract_bin=None):

        super().__init__(connection_manager,
                         contract_address=contract_address,
                         contract_abi=contract_abi,
                         contract_bin=contract_bin)

        # finally load the contract
        self.load_contract()

    def ready_to_trigger_orders(self):
        return self.sc.functions.readyToTriggerOrders().call()

    def trigger_orders(
            self,
            *args,
            **kwargs):

        simulation = False
        if 'simulation' in kwargs:
            if kwargs['simulation']:
                simulation = True
            kwargs.pop('simulation')

        if simulation:
            result = self.sc.functions.triggerOrders(*args).call(**kwargs)
        else:
            result = self.connection_manager.send_function_transaction(
                self.sc.functions.triggerOrders,
                *args,
                **kwargs
            )

        return result
