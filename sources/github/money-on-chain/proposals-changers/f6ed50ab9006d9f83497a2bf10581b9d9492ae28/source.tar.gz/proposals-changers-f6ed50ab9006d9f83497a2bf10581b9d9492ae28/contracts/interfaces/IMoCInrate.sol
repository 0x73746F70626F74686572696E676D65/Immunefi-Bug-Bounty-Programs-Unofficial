// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.24;

/// @notice Minimal interface for the MoCInrate contract (only methods used by changers)
interface IMoCInrate {
  function setBitProRate(uint256 newBitProRate) external;
  function setBitProInterestAddress(address payable newBitProInterestAddress) external;
  function setCommissionRateByTxType(uint8 txType, uint256 value) external;
  function bitProRate() external view returns (uint256);
  function getBitProInterestAddress() external view returns (address payable);
  function commissionRatesByTxType(uint8 txType) external view returns (uint256);
  function governor() external view returns (address);
}
