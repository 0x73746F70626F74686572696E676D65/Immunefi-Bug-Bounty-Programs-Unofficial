// hardhat.config.js (ESM)
//import 'dotenv/config';

import hardhatEthers from "@nomicfoundation/hardhat-ethers";
import hardhatToolboxMochaEthers from "@nomicfoundation/hardhat-toolbox-mocha-ethers";
import hardhatVerify from "@nomicfoundation/hardhat-verify";
import { configVariable } from "hardhat/config";

import { config as dotenvConfig } from "dotenv";

dotenvConfig();

export default {
  plugins: [hardhatEthers, hardhatToolboxMochaEthers, hardhatVerify],
  solidity: {
    splitTestsCompilation: true,
    npmFilesToBuild: [
      "@moc/main/contracts/collateral/rc20/MocCARC20.sol",
      "@moc/main/contracts/interfaces/IDataProvider.sol",
      "@moc/rbtc/contracts/MoC.sol",
      "@moc/rbtc/contracts/MoCState.sol",
      "@moc/rbtc/contracts/MoCInrate.sol",
      "@moc/rbtc/contracts/MoCBProxManager.sol",
      "@moc/rbtc/contracts/base/MoCConnector.sol",
      "@moc/roc/contracts/providers/FCMaxAbsoluteOpProvider.sol",
      "@moc/roc/contracts/providers/FCMaxOpDifferenceProvider.sol",
      "@moc/roc/contracts/providers/DataProvider.sol",
      "@moc/flow/contracts/BufferCoinbase.sol",
      "@moc/flow/contracts/Coiner.sol",
      "@moc/oracles/contracts/Supporters.sol",
      "@moc/oracles/contracts/CoinPairPrice.sol",
      "@moc/oracles/contracts/TasksRunner.sol",
      "@moc/main/contracts/auxiliary/MocReverseAuction.sol",
      "@moc/main/contracts/governance/InterimGovernor.sol",
      "@moc/oracles/contracts/tasks/mocFlow/buffer/TaskFlush.sol",
      "@moc/oracles/contracts/tasks/mocFlow/buffer/TaskLiquidate.sol",
      "@moc/oracles/contracts/tasks/mocFlow/reverseAuction/TaskTriggerOrder.sol",
      "@moc/lending/contracts/swappers/MocSwapperCoreV1.sol",
      "@moc/lending/contracts/adapters/MocAdapterV1.sol",
      "@moc/lending/contracts/MocLendingManager.sol",
      "@moc/lending/contracts/MocLendingReader.sol",
      "@moc/lending/contracts/TPInjector.sol",
      "@moc/price-oracle-interfaces/contracts/PriceProviderInverse.sol",
      "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol",
      "@openzeppelin/contracts/proxy/transparent/TransparentUpgradeableProxy.sol",
      "@moc/voting/contracts/VotingMachine.sol",
    ],
    compilers: [
      {
        version: "0.5.8",
        settings: {
          optimizer: { enabled: true, runs: 200 },
        },
      },
      {
        version: "0.5.17",
        settings: {
          evmVersion: "byzantium",
          optimizer: { enabled: true, runs: 200 },
          libraries: {
            "@moc/rbtc/contracts/MoCHelperLib.sol": {
              MoCHelperLib:
                process.env.MOC_HELPER_LIB || "0x592b84710955C9561008D137a5403E1dd9A222D8",
            },
          },
        },
      },
      {
        version: "0.6.12",
        settings: { optimizer: { enabled: true, runs: 200 } },
      },
      {
        version: "0.7.6",
        settings: { optimizer: { enabled: true, runs: 200 } },
      },
      {
        version: "0.8.24",
        settings: {
          optimizer: {
            enabled: true,
            runs: 200,
            details: {
              yulDetails: {
                optimizerSteps:
                  "dhfoDgvulfnTUtnIf[xa[r]EscLMcCTUtTOntnfDIulLculVcul[j]Tpeulxa[rul]xa[r]cLgvifCTUca[r]LSsTOtfDnca[r]Iulc]jmul[jul]VcTOculjmul",
              },
            },
          },
          viaIR: true,
          evmVersion: "london",
          outputSelection: {
            "*": {
              "*": ["storageLayout"],
            },
          },
        },
      },
    ],
  },
  networks: {
    // Red local/embebida (opcional)
    hardhat: {
      type: "edr-simulated",
      forking: {
        url: configVariable("FORK_URL"), // <- needit
        blockNumber: process.env.FORK_BLOCK ? Number(process.env.FORK_BLOCK) : undefined,
        // headers y timeout optional if you use a public RPC that sometimes delays:
        // httpHeaders: { /* ... */ },
        // timeout: 120000,
      },
    },
    localhost: {
      type: "http",
      url: "http://127.0.0.1:8545",
      chainId: 31337,
    },
    // RSK Testnet (HTTP RPC)
    rskAlphaTestnet: {
      type: "http",
      url: configVariable("RPC_URL_RSK_TESTNET"),
      chainId: 31,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
      // gasPrice: 60000000n, // optional (wei)
    },

    // RSK Testnet (HTTP RPC)
    rskTestnet: {
      type: "http",
      url: configVariable("RPC_URL_RSK_TESTNET"),
      chainId: 31,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
      // gasPrice: 60000000n, // optional (wei)
    },

    // RSK Mainnet (HTTP RPC)
    rskMainnet: {
      type: "http",
      url: configVariable("RPC_URL_RSK_MAINNET"),
      chainId: 30,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
  },
  verify: {
    // Rootstock explorer is still experimental
    // as it needs extra parameters obtained from the website
    // to interact with the nextjs app.
    rootstockExplorer: {
      enabled: false,
    },
    blockscout: {
      enabled: true,
    },
    etherscan: {
      enabled: false,
      apiKey: process.env.ETHERSCAN_API_KEY ?? "unused",
    },
  },
  chainDescriptors: {
    31: {
      name: "Rootstock Testnet",
      blockExplorers: {
        etherscan: {
          url: "",
          apiUrl: "",
        },
        blockscout: {
          name: "Rootstock Testnet Blockscout",
          url: "https://rootstock-testnet.blockscout.com",
          apiUrl: "https://rootstock-testnet.blockscout.com/api",
        },
      },
    },
    30: {
      name: "Rootstock Mainnet",
      blockExplorers: {
        etherscan: {
          url: "",
          apiUrl: "",
        },
        blockscout: {
          name: "Rootstock Blockscout",
          url: "https://rootstock.blockscout.com",
          apiUrl: "https://rootstock.blockscout.com/api",
        },
      },
    },
  },
  ignition: {
    blockPollingInterval: 5000,
    timeBeforeBumpingFees: 120000,
    maxFeeBumps: 10,
    requiredConfirmations: 1,
    maxUnconfirmedTxs: 1,
  },
  test: {
    solidity: {
      ffi: true,
      fsPermissions: {
        readDirectory: ["./out", "./test", "./ignition"],
      },
    },
  },
};
