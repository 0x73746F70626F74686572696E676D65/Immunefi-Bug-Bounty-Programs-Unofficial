#!/usr/bin/env bash

NODO_DIRECTORY="${HOME}/nodo-dir/money-on-chain/"
GANACHE_PORT=8545

# Exit script as soon as a command fails.
set -o errexit

# Executes cleanup function at script exit.
trap cleanup EXIT

cleanup() {
  # Kill the ganache instance that we started (if we started one and if it's still running).
  if [ -n "$ganache_pid" ] && ps -p $ganache_pid > /dev/null; then
    kill -9 $ganache_pid
  fi
}

ganache_running() {
  nc -z localhost "$GANACHE_PORT"
}

start_ganache() {
  # We define 11 accounts with balance 1M ether, needed for high-value tests.
  local accounts=(
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501200,100000000000000000000000000"
    --account="0x4acf63dfb862d97ac1a1518483447c6f40ef0a10d978b812a8a31277551d6cc7,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501202,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501203,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501204,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501205,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501206,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501207,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501208,100000000000000000000000000"
    --account="0x2bdd21761a483f71054e14f5b827213567971c676928d9a1808cbfa4b7501209,100000000000000000000000000"
    --account="0x423576A6FAD7EAFD4D6039D847A0ADD4A15BAE6C65658C24C1FE248BF80BF3A2,100000000000000000000000000"
    --account="0xe27bea17bfb8f9309733f8996b4990af06c3526fd54f3eec398ec80677f71165,100000000000000000000000000"
  )
  if [ ! -d "$NODO_DIRECTORY" ]; then
    mkdir -p "$NODO_DIRECTORY"
  fi

  if [ "$TESTING" = true ]; then
    node_modules/.bin/ganache-cli --gasLimit 0xfffffffffff --port "$GANACHE_PORT" -i 1564754684494 --allowUnlimitedContractSize --accounts 10 --defaultBalanceEther 100000000000000000
  else
    node_modules/.bin/ganache-cli --db "$NODO_DIRECTORY" --gasLimit 0xfffffffffff "${accounts[@]}" -i 1564754684494 --allowUnlimitedContractSize --port $GANACHE_PORT
  fi

  ganache_pid=$!
}

if ganache_running; then
  echo "Using existing ganache instance"
else
  echo "Starting our own ganache instance!!!"
  start_ganache
fi

ganache-cli --version
truffle version
