import { batches } from "@nomicfoundation/ignition-core";
import type { Future, IgnitionModule } from "@nomicfoundation/ignition-core";

/** Adds dependency barriers so Ignition executes futures in bounded groups. */
export function batchModule<T extends IgnitionModule>(module: T, groupSize = 8): T {
  if (!Number.isInteger(groupSize) || groupSize < 1) {
    throw new Error(`groupSize must be a positive integer, received ${groupSize}`);
  }
  const byId = new Map<string, Future>();
  const collect = (current: IgnitionModule) => {
    for (const future of current.futures) byId.set(future.id, future);
    for (const submodule of current.submodules) collect(submodule);
  };
  collect(module);
  const groups: Future[][] = [];
  for (const naturalBatch of batches(module)) {
    const futures = naturalBatch.map(id => byId.get(id)).filter((future): future is Future => future !== undefined);
    for (let index = 0; index < futures.length; index += groupSize) groups.push(futures.slice(index, index + groupSize));
  }
  for (let groupIndex = 1; groupIndex < groups.length; groupIndex++) {
    for (const future of groups[groupIndex]) {
      for (const dependency of groups[groupIndex - 1]) future.dependencies.add(dependency);
    }
  }
  return module;
}
