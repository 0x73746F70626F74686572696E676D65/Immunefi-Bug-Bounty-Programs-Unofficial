import type {
  IgnitionModuleBuilder,
  ContractFuture,
  CallableContractFuture,
  ArgumentType,
} from "@nomicfoundation/ignition-core";
import { keccak256, stringToBytes } from "viem";

export const encodeAsKeyName = (value: string) => keccak256(stringToBytes(value));

export const encodedRegistryKeyName = (name: RegistryKeyName): string => encodeAsKeyName(registryKeys[name].key);

export type RegistryValue = ContractFuture<string>[] | ContractFuture<string> | readonly [bigint, bigint]; // tuple is the type of decimal values;

export function makeCallsSettingRegistryValues(
  m: IgnitionModuleBuilder,
  registry: CallableContractFuture<string>,
  values: Partial<Record<RegistryKeyName, RegistryValue>>,
) {
  const calls = [];

  for (const [registryKey, value] of Object.entries(values) as Array<[RegistryKeyName, RegistryValue]>) {
    const meta = registryKeys[registryKey];
    const key = encodeAsKeyName(meta.key);
    const id = `set_registry_${key}`.replace(/[^a-zA-Z0-9]+/g, "_");

    const methodName = meta.type === "AddressArray" ? "pushAddressArray" : `set${meta.type}`;

    const params =
      meta.type === "Decimal"
        ? ([key, ...(value as readonly [bigint, bigint])] as ArgumentType[])
        : ([key, value] as ArgumentType[]);

    calls.push(m.call(registry, methodName, params, { id }));
  }

  return calls;
}

export const registryKeys = {
  MOC_PROJECT_VERSION: { key: "moc.project.version", type: "String" },
  MOC_TOKEN: { key: "moc.token", type: "Address" },
  MOC_DELAY_MACHINE: { key: "moc.delay-machine", type: "Address" },
  MOC_STAKING_MACHINE: { key: "moc.staking-machine", type: "Address" },
  MOC_VESTING_MACHINE: { key: "moc.vesting-machine", type: "Address" },
  MOC_VETO_MACHINE: { key: "moc.veto-machine", type: "Address" },
  MOC_VOTING_MACHINE: { key: "moc.voting-machine", type: "Address" },
  MOC_UPGRADE_DELEGATOR: { key: "moc.upgrade-delegator", type: "Address" },
  MOC_PRICE_PROVIDER_REGISTRY: { key: "moc.price-provider-registy", type: "Address" },
  MOC_MULTI_COLLATERAL_GUARD: { key: "moc.multi-collateral-guard", type: "Address" },

  // Voting machine parameter keys.
  MOC_VOTING_MACHINE_MIN_STAKE: { key: "moc.voting-machine.minStake", type: "Uint" },
  MOC_VOTING_MACHINE_PRE_VOTE_EXPIRATION_TIME_DELTA: {
    key: "moc.voting-machine.preVoteExpirationTimeDelta",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_MAX_PRE_PROPOSALS: {
    key: "moc.voting-machine.maxPreProposals",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_PRE_VOTE_MIN_PCT_TO_WIN: {
    key: "moc.voting-machine.preVoteMinPCToWin",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_VOTE_MIN_PCT_TO_VETO: {
    key: "moc.voting-machine.voteMinPctToVeto",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_VOTE_MIN_PCT_FOR_QUORUM: {
    key: "moc.voting-machine.voteMinPctForQuorum",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_VOTE_MIN_PCT_TO_ACCEPT: {
    key: "moc.voting-machine.voteMinPctToAccept",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_PCT_PRECISION: {
    key: "moc.voting-machine.PCTPrecision",
    type: "Uint",
  },
  MOC_VOTING_MACHINE_VOTING_TIME_DELTA: {
    key: "moc.voting-machine.votingTimeDelta",
    type: "Uint",
  },

  // Oracles legacy.
  ORACLE_MANAGER_ADDR: { key: "MOC_ORACLE\\1\\ORACLE_MANAGER_ADDR", type: "Address" },
  SUPPORTERS_ADDR: { key: "MOC_ORACLE\\1\\SUPPORTERS_ADDR", type: "Address" },
  INFO_ADDR: { key: "MOC_ORACLE\\1\\INFO_ADDR", type: "Address" },
  ORACLE_PRICE_FETCH_RATE: { key: "MOC_ORACLE\\1\\ORACLE_PRICE_FETCH_RATE", type: "Uint" },
  ORACLE_BLOCKCHAIN_INFO_INTERVAL: {
    key: "MOC_ORACLE\\1\\ORACLE_BLOCKCHAIN_INFO_INTERVAL",
    type: "Uint",
  },
  ORACLE_COIN_PAIR_LOOP_TASK_INTERVAL: {
    key: "MOC_ORACLE\\1\\ORACLE_COIN_PAIR_LOOP_TASK_INTERVAL",
    type: "Uint",
  },
  ORACLE_MAIN_LOOP_TASK_INTERVAL: {
    key: "MOC_ORACLE\\1\\ORACLE_MAIN_LOOP_TASK_INTERVAL",
    type: "Uint",
  },
  ORACLE_PRICE_REJECT_DELTA_PCT: {
    key: "MOC_ORACLE\\1\\ORACLE_PRICE_REJECT_DELTA_PCT",
    type: "Decimal",
  },
  ORACLE_CONFIGURATION_TASK_INTERVAL: {
    key: "MOC_ORACLE\\1\\ORACLE_CONFIGURATION_TASK_INTERVAL",
    type: "Uint",
  },
  ORACLE_GATHER_SIGNATURE_TIMEOUT: {
    key: "MOC_ORACLE\\1\\ORACLE_GATHER_SIGNATURE_TIMEOUT",
    type: "Uint",
  },
  ORACLE_MAIN_EXECUTOR_TASK_INTERVAL: {
    key: "MOC_ORACLE\\1\\ORACLE_MAIN_EXECUTOR_TASK_INTERVAL",
    type: "Uint",
  },
  SCHEDULER_POOL_DELAY: { key: "MOC_ORACLE\\1\\SCHEDULER_POOL_DELAY", type: "Uint" },
  SCHEDULER_ROUND_DELAY: { key: "MOC_ORACLE\\1\\SCHEDULER_ROUND_DELAY", type: "Uint" },
  ORACLE_PRICE_DIGITS: { key: "MOC_ORACLE\\1\\ORACLE_PRICE_DIGITS", type: "Uint" },
  ORACLE_QUEUE_LEN: { key: "MOC_ORACLE\\1\\ORACLE_QUEUE_LEN", type: "Uint" },
  MESSAGE_VERSION: { key: "MOC_ORACLE\\1\\MESSAGE_VERSION", type: "Uint" },
  ORACLE_PRICE_DELTA_PCT: { key: "MOC_ORACLE\\1\\ORACLE_PRICE_DELTA_PCT", type: "Decimal" },
  ORACLE_PRICE_PUBLISH_BLOCKS: {
    key: "MOC_ORACLE\\1\\ORACLE_PRICE_PUBLISH_BLOCKS",
    type: "Uint",
  },
  ORACLE_ENTERING_FALLBACKS_AMOUNTS: {
    key: "MOC_ORACLE\\1\\ORACLE_ENTERING_FALLBACKS_AMOUNTS",
    type: "Bytes",
  },
  ORACLE_TRIGGER_VALID_PUBLICATION_BLOCKS: {
    key: "MOC_ORACLE\\1\\ORACLE_TRIGGER_VALID_PUBLICATION_BLOCKS",
    type: "Uint",
  },
  ORACLE_MIN_ORACLES_PER_ROUND: {
    key: "MOC_ORACLE\\1\\ORACLE_MIN_ORACLES_PER_ROUND",
    type: "Uint",
  },

  // Flow
  MOC_FLOW_BUFFERS: { key: "MOC_FLOW\\1\\BUFFERS", type: "AddressArray" },
  MOC_FLOW_DRIPPERS: { key: "MOC_FLOW\\1\\DRIPPERS", type: "AddressArray" },
  MOC_FLOW_COINERS: { key: "MOC_FLOW\\1\\COINERS", type: "AddressArray" },
  MOC_FLOW_REVERSE_AUCTIONS: { key: "MOC_FLOW\\1\\REVERSE_AUCTIONS", type: "AddressArray" },
} as const;

export type RegistryKeysDefinition = typeof registryKeys;
export type RegistryKeyName = keyof RegistryKeysDefinition;
