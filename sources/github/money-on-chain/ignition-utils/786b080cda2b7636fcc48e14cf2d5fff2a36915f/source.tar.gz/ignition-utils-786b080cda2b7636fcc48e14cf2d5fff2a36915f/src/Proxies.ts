/**
 * Our governance for upgrades use TransparentProxies, which are deprecated.
 * But movig forward we want to use UUPS, these helpers encapsulate the right versions of both
 */

import {
  ArgumentType,
  CallableContractFuture,
  ContractFuture,
  ContractOptions,
  IgnitionModuleBuilder,
} from "@nomicfoundation/ignition-core";

export interface ProxyResult {
  // implementation future (points to the impl and has impl ABI)
  impl: ContractFuture<string>;
  // proxy future (points at proxy, and has proxy abi)
  proxy: CallableContractFuture<string>;
  // Use this one to call impl methods in the proxy.
  at: CallableContractFuture<string>;
}

const PROXY_ADMIN_CONTRACT = "@openzeppelin/contracts/proxy/transparent/ProxyAdmin.sol:ProxyAdmin";

function toIgnitionIdPart(value: string): string {
  return value.replace(/[^A-Za-z0-9_]/g, "_");
}

/*
  Helper class for building an ignition call to create a ProxyAdmin
  and further calls to deploy Transparent proxies that have it as their admin.
*/
export class TransparentProxyAdminHelper {
  constructor(
    private readonly m: IgnitionModuleBuilder,
    public readonly proxyAdmin: CallableContractFuture<string>,
    public readonly suffix?: string,
  ) {}

  static withNewAdmin(m: IgnitionModuleBuilder, suffix?: string): TransparentProxyAdminHelper {
    const newAdmin = m.contract(PROXY_ADMIN_CONTRACT, undefined, {
      id: `NewProxyAdmin_${suffix}`,
    });
    return new TransparentProxyAdminHelper(m, newAdmin, suffix);
  }

  static withAdmin(m: IgnitionModuleBuilder, adminAddress: string, suffix?: string): TransparentProxyAdminHelper {
    const admin = m.contractAt(PROXY_ADMIN_CONTRACT, adminAddress, {
      id: `ExistingProxyAdmin_${suffix}`,
    });
    return new TransparentProxyAdminHelper(m, admin, suffix);
  }

  deploy = (
    artifact: string,
    args?: ArgumentType[],
    initializer?: string,
    localSuffix?: string,
    after?: ContractOptions["after"],
  ): ProxyResult => {
    const id = [toIgnitionIdPart(artifact), this.suffix, localSuffix].filter(x => x).join("__");
    const impl = this.m.contract(artifact, [], { id: `${id}_Implementation`, after });

    const method = initializer ?? "initialize";
    const data = args && args.length > 0 ? this.m.encodeFunctionCall(impl, method, args) : "0x";

    const proxy = this.m.contract("TransparentUpgradeableProxy", [impl, this.proxyAdmin, data], {
      id: `${id}_Proxy`,
    });

    const at = this.m.contractAt(artifact, proxy, { id });
    return { impl, proxy, at };
  };
}

/*
  Deploy a UUPS proxy (ERC1967Proxy) with optional initializer.
*/
export function deployUUPSProxy(
  m: IgnitionModuleBuilder,
  artifact: string,
  args?: ArgumentType[],
  initializer?: string,
  suffix: string = "",
): ProxyResult {
  const id = `${toIgnitionIdPart(artifact)}_${suffix}`;
  const impl = m.contract(artifact, [], { id: `${id}_Implementation` });

  const method = initializer ?? "initialize";
  const data = args && args.length > 0 ? m.encodeFunctionCall(impl, method, args) : "0x";

  const proxy = m.contract("ERC1967Proxy", [impl, data], { id: `${id}Proxy` });
  const at = m.contractAt(artifact, proxy, { id });
  return { impl, proxy, at };
}
