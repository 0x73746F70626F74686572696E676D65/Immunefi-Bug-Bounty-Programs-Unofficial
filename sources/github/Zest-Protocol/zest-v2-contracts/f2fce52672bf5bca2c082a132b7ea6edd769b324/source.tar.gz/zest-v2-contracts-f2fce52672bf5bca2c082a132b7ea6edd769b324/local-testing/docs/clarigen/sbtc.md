
# sbtc

[`sbtc.clar`](../../contracts/utility/token/sbtc.clar)



**Public functions:**

- [`transfer`](#transfer)
- [`mint`](#mint)

**Read-only functions:**

- [`get-name`](#get-name)
- [`get-symbol`](#get-symbol)
- [`get-decimals`](#get-decimals)
- [`get-balance`](#get-balance)
- [`get-balance-available`](#get-balance-available)
- [`get-total-supply`](#get-total-supply)
- [`get-token-uri`](#get-token-uri)

**Private functions:**



**Maps**



**Variables**

- [`token-name`](#token-name)
- [`token-symbol`](#token-symbol)
- [`token-uri`](#token-uri)
- [`token-decimals`](#token-decimals)

**Constants**

- [`err-unauthorised`](#err-unauthorised)
- [`err-not-token-owner`](#err-not-token-owner)
- [`deployer`](#deployer)


## Functions

### transfer

[View in file](../../contracts/utility/token/sbtc.clar#L17)

`(define-public (transfer ((amount uint) (sender principal) (recipient principal) (memo (optional (buff 34)))) (response bool uint))`



<details>
  <summary>Source code:</summary>

```clarity
(define-public (transfer (amount uint) (sender principal) (recipient principal) (memo (optional (buff 34))))
  (begin
    (asserts! (or (is-eq tx-sender sender) (is-eq contract-caller sender)) err-not-token-owner)
    (ft-transfer? sbtc amount sender recipient)
  )
)
```
</details>


**Parameters:**

| Name | Type | 
| --- | --- | 
| amount | uint |
| sender | principal |
| recipient | principal |
| memo | (optional (buff 34)) |

### get-name

[View in file](../../contracts/utility/token/sbtc.clar#L24)

`(define-read-only (get-name () (response (string-ascii 32) none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-name)
  (ok (var-get token-name))
)
```
</details>




### get-symbol

[View in file](../../contracts/utility/token/sbtc.clar#L28)

`(define-read-only (get-symbol () (response (string-ascii 10) none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-symbol)
  (ok (var-get token-symbol))
)
```
</details>




### get-decimals

[View in file](../../contracts/utility/token/sbtc.clar#L32)

`(define-read-only (get-decimals () (response uint none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-decimals)
  (ok (var-get token-decimals))
)
```
</details>




### get-balance

[View in file](../../contracts/utility/token/sbtc.clar#L36)

`(define-read-only (get-balance ((who principal)) (response uint none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-balance (who principal))
  (ok (+ (ft-get-balance sbtc who) (ft-get-balance sBTC-locked who)))
)
```
</details>


**Parameters:**

| Name | Type | 
| --- | --- | 
| who | principal |

### get-balance-available

[View in file](../../contracts/utility/token/sbtc.clar#L40)

`(define-read-only (get-balance-available ((who principal)) (response uint none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-balance-available (who principal))
	(ok (ft-get-balance sbtc who))
)
```
</details>


**Parameters:**

| Name | Type | 
| --- | --- | 
| who | principal |

### get-total-supply

[View in file](../../contracts/utility/token/sbtc.clar#L44)

`(define-read-only (get-total-supply () (response uint none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-total-supply)
  (ok (+ (ft-get-supply sbtc) (ft-get-supply sBTC-locked)))
)
```
</details>




### get-token-uri

[View in file](../../contracts/utility/token/sbtc.clar#L48)

`(define-read-only (get-token-uri () (response (optional (string-utf8 256)) none))`



<details>
  <summary>Source code:</summary>

```clarity
(define-read-only (get-token-uri)
  (ok (var-get token-uri))
)
```
</details>




### mint

[View in file](../../contracts/utility/token/sbtc.clar#L52)

`(define-public (mint ((amount uint) (recipient principal)) (response bool uint))`



<details>
  <summary>Source code:</summary>

```clarity
(define-public (mint (amount uint) (recipient principal))
  (begin
    (asserts! (is-eq tx-sender deployer) err-unauthorised)
    (ft-mint? sbtc amount recipient)
  )
)
```
</details>


**Parameters:**

| Name | Type | 
| --- | --- | 
| amount | uint |
| recipient | principal |

## Maps



## Variables

### token-name

(string-ascii 32)



```clarity
(define-data-var token-name (string-ascii 32) "sbtc")
```

[View in file](../../contracts/utility/token/sbtc.clar#L9)

### token-symbol

(string-ascii 10)



```clarity
(define-data-var token-symbol (string-ascii 10) "sbtc")
```

[View in file](../../contracts/utility/token/sbtc.clar#L10)

### token-uri

(optional (string-utf8 256))



```clarity
(define-data-var token-uri (optional (string-utf8 256)) none)
```

[View in file](../../contracts/utility/token/sbtc.clar#L11)

### token-decimals

uint



```clarity
(define-data-var token-decimals uint u8)
```

[View in file](../../contracts/utility/token/sbtc.clar#L12)

## Constants

### err-unauthorised





```clarity
(define-constant err-unauthorised (err u3000))
```

[View in file](../../contracts/utility/token/sbtc.clar#L3)

### err-not-token-owner





```clarity
(define-constant err-not-token-owner (err u4))
```

[View in file](../../contracts/utility/token/sbtc.clar#L4)

### deployer





```clarity
(define-constant deployer tx-sender)
```

[View in file](../../contracts/utility/token/sbtc.clar#L14)
  