import * as __0_1_0 from "./0_1_0/index.js";
import * as __1_0_0 from "./1_0_0/index.js";
import * as __1_1_0 from "./1_1_0/index.js";
import * as __1_3_1 from "./1_3_1/index.js";
import * as __2_0_0 from "./2_0_0/index.js";

const _0_1_0 = {
  NttManager: {
    connect: __0_1_0.NttManager__factory.connect,
  },
  NttTransceiver: {
    connect: __0_1_0.WormholeTransceiver__factory.connect,
  },
};

const _1_0_0 = {
  NttManager: {
    connect: __1_0_0.NttManager__factory.connect,
  },
  NttTransceiver: {
    connect: __1_0_0.WormholeTransceiver__factory.connect,
  },
};

const _1_1_0 = {
  NttManager: {
    connect: __1_1_0.NttManager__factory.connect,
  },
  NttTransceiver: {
    connect: __1_1_0.WormholeTransceiver__factory.connect,
  },
};

const _1_3_1 = {
  NttManager: {
    connect: __1_3_1.NttManager__factory.connect,
  },
  NttTransceiver: {
    connect: __1_3_1.WormholeTransceiver__factory.connect,
  },
};

const _2_0_0 = {
  NttManager: {
    connect: __2_0_0.NttManager__factory.connect,
  },
  NttTransceiver: {
    connect: __2_0_0.WormholeTransceiver__factory.connect,
  },
};

export { _0_1_0, _1_0_0, _1_1_0, _1_3_1, _2_0_0 };
