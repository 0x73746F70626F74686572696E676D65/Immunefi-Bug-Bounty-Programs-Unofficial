#![cfg(feature = "test-sbf")]
#![feature(type_changing_struct_update)]

use anchor_lang::{system_program::System, Id};
use example_native_token_transfers::error::NTTError;
use ntt_messages::mode::Mode;
use solana_program_test::*;
use solana_sdk::{instruction::InstructionError, signer::Signer, transaction::TransactionError};
use test_utils::{
    common::submit::Submittable,
    helpers::{assert_threshold, assert_transceiver_id, setup},
    sdk::{
        accounts::good_ntt,
        instructions::admin::{
            deregister_transceiver, register_transceiver, set_threshold, DeregisterTransceiver,
            RegisterTransceiver, SetThreshold,
        },
        transceivers::accounts::{good_ntt_transceiver, NTTTransceiverAccounts},
    },
};
use wormhole_svm_definitions::solana::{POST_MESSAGE_SHIM_PROGRAM_ID, VERIFY_VAA_SHIM_PROGRAM_ID};

#[tokio::test]
async fn test_invalid_transceiver() {
    let (mut ctx, test_data) = setup(Mode::Locking).await;

    // try registering system program
    let err = register_transceiver(
        &good_ntt,
        RegisterTransceiver {
            payer: ctx.payer.pubkey(),
            owner: test_data.program_owner.pubkey(),
            transceiver: System::id(),
        },
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap_err();
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(
            0,
            InstructionError::Custom(NTTError::InvalidTransceiverProgram.into())
        )
    );
}

#[tokio::test]
async fn test_reregister_all_transceivers() {
    let (mut ctx, test_data) = setup(Mode::Locking).await;

    // Transceivers are expected to be executable which requires them to be added on setup
    // Thus, we pass all available executable program IDs as dummy_transceivers
    let dummy_transceivers = vec![
        example_native_token_transfers::ID,
        wormhole_anchor_sdk::wormhole::program::Wormhole::id(),
        POST_MESSAGE_SHIM_PROGRAM_ID,
        VERIFY_VAA_SHIM_PROGRAM_ID,
    ];
    let num_dummy_transceivers: u8 = dummy_transceivers.len().try_into().unwrap();

    // register dummy transceivers
    for (idx, transceiver) in dummy_transceivers.iter().enumerate() {
        register_transceiver(
            &good_ntt,
            RegisterTransceiver {
                payer: ctx.payer.pubkey(),
                owner: test_data.program_owner.pubkey(),
                transceiver: *transceiver,
            },
        )
        .submit_with_signers(&[&test_data.program_owner], &mut ctx)
        .await
        .unwrap();
        assert_transceiver_id(&good_ntt, &mut ctx, transceiver, idx as u8 + 1).await;
    }

    // set threshold = 1 (for ntt_transceiver) + num_dummy_transceivers
    set_threshold(
        &good_ntt,
        SetThreshold {
            owner: test_data.program_owner.pubkey(),
        },
        1 + num_dummy_transceivers,
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap();

    // deregister dummy transceivers
    for (idx, transceiver) in dummy_transceivers.iter().enumerate() {
        deregister_transceiver(
            &good_ntt,
            DeregisterTransceiver {
                owner: test_data.program_owner.pubkey(),
                transceiver: *transceiver,
            },
        )
        .submit_with_signers(&[&test_data.program_owner], &mut ctx)
        .await
        .unwrap();
        // assert threshold decreases
        assert_threshold(&good_ntt, &mut ctx, num_dummy_transceivers - idx as u8).await;
    }

    // reregister dummy transceiver
    for (idx, transceiver) in dummy_transceivers.iter().enumerate() {
        register_transceiver(
            &good_ntt,
            RegisterTransceiver {
                payer: ctx.payer.pubkey(),
                owner: test_data.program_owner.pubkey(),
                transceiver: *transceiver,
            },
        )
        .submit_with_signers(&[&test_data.program_owner], &mut ctx)
        .await
        .unwrap();
        // assert transceiver_id and threshold are retained
        assert_transceiver_id(&good_ntt, &mut ctx, transceiver, idx as u8 + 1).await;
        assert_threshold(&good_ntt, &mut ctx, 1).await;
    }

    // reregister standalone transceiver
    register_transceiver(
        &good_ntt,
        RegisterTransceiver {
            payer: ctx.payer.pubkey(),
            owner: test_data.program_owner.pubkey(),
            transceiver: good_ntt_transceiver.program(),
        },
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap();
    // assert transceiver_id and threshold are retained
    assert_transceiver_id(&good_ntt, &mut ctx, &good_ntt_transceiver.program(), 0).await;
    assert_threshold(&good_ntt, &mut ctx, 1).await;
}

#[tokio::test]
async fn test_deregister_last_enabled_transceiver() {
    let (mut ctx, test_data) = setup(Mode::Locking).await;

    // attempt to deregister only enabled transceiver (standalone transceiver)
    let err = deregister_transceiver(
        &good_ntt,
        DeregisterTransceiver {
            owner: test_data.program_owner.pubkey(),
            transceiver: good_ntt_transceiver.program(),
        },
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap_err();
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(
            0,
            InstructionError::Custom(NTTError::ZeroThreshold.into())
        )
    );

    // register arbitrary executable program as dummy transceiver
    let dummy_transceiver = wormhole_anchor_sdk::wormhole::program::Wormhole::id();
    register_transceiver(
        &good_ntt,
        RegisterTransceiver {
            payer: ctx.payer.pubkey(),
            owner: test_data.program_owner.pubkey(),
            transceiver: dummy_transceiver,
        },
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap();

    // deregister standalone transceiver
    deregister_transceiver(
        &good_ntt,
        DeregisterTransceiver {
            owner: test_data.program_owner.pubkey(),
            transceiver: good_ntt_transceiver.program(),
        },
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap();

    // attempt to deregister last enabled transceiver (dummy transceiver)
    let err = deregister_transceiver(
        &good_ntt,
        DeregisterTransceiver {
            owner: test_data.program_owner.pubkey(),
            transceiver: dummy_transceiver,
        },
    )
    .submit_with_signers(&[&test_data.program_owner], &mut ctx)
    .await
    .unwrap_err();
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(
            0,
            InstructionError::Custom(NTTError::ZeroThreshold.into())
        )
    );
}
