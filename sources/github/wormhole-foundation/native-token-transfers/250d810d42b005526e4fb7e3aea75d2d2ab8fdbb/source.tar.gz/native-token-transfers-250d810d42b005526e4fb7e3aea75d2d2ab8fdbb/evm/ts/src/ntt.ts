import {
  Chain,
  Network,
  encoding,
  nativeChainIds,
  toChainId,
} from "@wormhole-foundation/sdk-base";
import {
  AccountAddress,
  ChainAddress,
  ChainsConfig,
  Contracts,
  canonicalAddress,
  serialize,
  toUniversal,
  universalAddress,
} from "@wormhole-foundation/sdk-definitions";
import type {
  AnyEvmAddress,
  EvmChains,
  EvmPlatformType,
} from "@wormhole-foundation/sdk-evm";
import {
  EvmAddress,
  EvmPlatform,
  EvmUnsignedTransaction,
  addChainId,
  addFrom,
} from "@wormhole-foundation/sdk-evm";
import "@wormhole-foundation/sdk-evm-core";

import {
  decodeTrimmedAmount,
  EncodedTrimmedAmount,
  EvmNttTransceiver,
  Ntt,
  NttTransceiver,
  untrim,
  WormholeNttTransceiver,
} from "@wormhole-foundation/sdk-definitions-ntt";
import { Contract, type Provider, type TransactionRequest } from "ethers";
import {
  NttBindings,
  NttManagerBindings,
  NttTransceiverBindings,
  loadAbiVersion,
} from "./bindings.js";

export class EvmNttWormholeTranceiver<N extends Network, C extends EvmChains>
  implements
    WormholeNttTransceiver<N, C>,
    EvmNttTransceiver<N, C, WormholeNttTransceiver.VAA>
{
  transceiver: NttTransceiverBindings.NttTransceiver;
  /** The on-chain registered index for this transceiver in the NttManager's TransceiverRegistry. */
  registeredIndex: number = 0;
  constructor(
    readonly manager: EvmNtt<N, C>,
    readonly address: string,
    abiBindings: NttBindings
  ) {
    this.transceiver = abiBindings.NttTransceiver.connect(
      address,
      manager.provider
    );
  }

  async getTransceiverType(): Promise<string> {
    // NOTE: We hardcode the type here as transceiver type is only available for versions >1.1.0
    // For those versions, we can return `this.transceiver.getTransceiverType()` directly
    return "wormhole";
  }

  async getAddress(): Promise<ChainAddress<C>> {
    return {
      chain: this.manager.chain,
      address: toUniversal(this.manager.chain, this.address),
    };
  }

  encodeFlags(flags: { skipRelay: boolean }): Uint8Array {
    return new Uint8Array([flags.skipRelay ? 1 : 0]);
  }

  async *setPeer<P extends Chain>(
    peer: ChainAddress<P>
  ): AsyncGenerator<EvmUnsignedTransaction<N, C>> {
    const coreBridge = new Contract(
      this.manager.contracts.coreBridge!,
      ["function messageFee() public view returns (uint256)"],
      this.manager.provider
    );
    const messageFee = await coreBridge.getFunction("messageFee").staticCall();
    const tx = await this.transceiver.setWormholePeer.populateTransaction(
      toChainId(peer.chain),
      universalAddress(peer)
    );
    yield this.manager.createUnsignedTx(
      {
        ...tx,
        value: messageFee,
      },
      "WormholeTransceiver.registerPeer"
    );
  }

  async getPauser(): Promise<AccountAddress<C> | null> {
    const pauser = await this.transceiver.pauser();
    return new EvmAddress(pauser) as AccountAddress<C>;
  }

  async *setPauser(pauser: AccountAddress<C>) {
    const canonicalPauser = canonicalAddress({
      chain: this.manager.chain,
      address: pauser,
    });
    const tx =
      await this.transceiver.transferPauserCapability.populateTransaction(
        canonicalPauser
      );
    yield this.manager.createUnsignedTx(tx, "WormholeTransceiver.setPauser");
  }

  async getPeer<C extends Chain>(chain: C): Promise<ChainAddress<C> | null> {
    const peer = await this.transceiver.getWormholePeer(toChainId(chain));
    const peerAddress = encoding.hex.decode(peer);
    const zeroAddress = new Uint8Array(32);
    if (encoding.bytes.equals(zeroAddress, peerAddress)) {
      return null;
    }

    return {
      chain: chain,
      address: toUniversal(chain, peerAddress),
    };
  }

  async isEvmChain(chain: Chain): Promise<boolean> {
    if (!("isWormholeEvmChain" in this.transceiver)) return false;
    return await this.transceiver.isWormholeEvmChain(toChainId(chain));
  }

  async *setIsEvmChain(chain: Chain, isEvm: boolean) {
    if (!("setIsWormholeEvmChain" in this.transceiver)) {
      throw new Error(
        "setIsWormholeEvmChain is not supported by this ABI version"
      );
    }
    const tx = await this.transceiver.setIsWormholeEvmChain.populateTransaction(
      toChainId(chain),
      isEvm
    );
    yield this.manager.createUnsignedTx(
      tx,
      "WormholeTransceiver.setIsEvmChain"
    );
  }

  async *receive(attestation: WormholeNttTransceiver.VAA) {
    const tx = await this.transceiver.receiveMessage.populateTransaction(
      serialize(attestation)
    );
    yield this.manager.createUnsignedTx(
      tx,
      "WormholeTransceiver.receiveMessage"
    );
  }
}

export class EvmNtt<N extends Network, C extends EvmChains>
  implements Ntt<N, C>
{
  tokenAddress: string;
  readonly chainId: bigint;
  manager: NttManagerBindings.NttManager;
  xcvrs: EvmNttWormholeTranceiver<N, C>[];
  managerAddress: string;
  private _transceiverIndicesInitialized = false;

  constructor(
    readonly network: N,
    readonly chain: C,
    readonly provider: Provider,
    readonly contracts: Contracts & { ntt?: Ntt.Contracts },
    readonly version: string = "1.0.0"
  ) {
    if (!contracts.ntt) throw new Error("No Ntt Contracts provided");

    this.chainId = nativeChainIds.networkChainToNativeChainId.get(
      network,
      chain
    ) as bigint;

    this.tokenAddress = contracts.ntt.token;
    this.managerAddress = contracts.ntt.manager;

    const abiBindings = loadAbiVersion(this.version);

    this.manager = abiBindings.NttManager.connect(
      contracts.ntt.manager,
      this.provider
    );

    this.xcvrs = [];
    const configuredTransceivers = contracts.ntt.transceiver;
    if (
      configuredTransceivers &&
      typeof configuredTransceivers === "object" &&
      "wormhole" in configuredTransceivers &&
      configuredTransceivers["wormhole"]
    ) {
      const transceiverTypes = [
        "wormhole", // wormhole xcvr should be ix 0
        ...Object.keys(configuredTransceivers).filter(
          (transceiverType) => transceiverType !== "wormhole"
        ),
      ];
      transceiverTypes.map((transceiverType) => {
        // we currently only support wormhole transceivers
        if (transceiverType !== "wormhole") {
          throw new Error(`Unsupported transceiver type: ${transceiverType}`);
        }

        // Enable more Transceivers here
        this.xcvrs.push(
          new EvmNttWormholeTranceiver(
            this,
            configuredTransceivers[transceiverType]!,
            abiBindings!
          )
        );
      });
    }
  }

  /**
   * Fetches on-chain registered indices for each transceiver via getTransceiverInfo()
   * and caches them on the xcvr objects. This is needed because the on-chain registered
   * index may differ from the SDK array position (e.g. after removing and re-adding
   * a transceiver, the new one gets a higher index since indices are monotonically
   * increasing and never reused).
   */
  async initTransceiverIndices(): Promise<void> {
    if (this._transceiverIndicesInitialized) return;

    try {
      if (!("getTransceiverInfo" in this.manager)) {
        // getTransceiverInfo not available on ABI < 1.0.0, fall back to default (0)
        this._transceiverIndicesInitialized = true;
        return;
      }

      const transceiverInfos = await this.manager.getTransceiverInfo();
      const transceiverAddresses = await this.manager.getTransceivers();

      // Both arrays are ordered the same way (enabled transceivers list)
      for (const xcvr of this.xcvrs) {
        const addrIndex = transceiverAddresses.findIndex(
          (addr: string) => addr.toLowerCase() === xcvr.address.toLowerCase()
        );
        if (addrIndex !== -1 && addrIndex < transceiverInfos.length) {
          xcvr.registeredIndex = Number(transceiverInfos[addrIndex]!.index);
        }
      }
      this._transceiverIndicesInitialized = true;
    } catch {
      // Do not mark initialized on failure: retry on next call so transient
      // RPC/provider errors don't permanently pin indices to default 0.
    }
  }

  async getTransceiver(ix: number): Promise<NttTransceiver<N, C, any> | null> {
    // TODO: should we make an RPC call here, or just trust that the xcvrs are set up correctly?
    return this.xcvrs[ix] || null;
  }

  async getMode(): Promise<Ntt.Mode> {
    const mode: bigint = await this.manager.getMode();
    return mode === 0n ? "locking" : "burning";
  }

  async isPaused(): Promise<boolean> {
    return await this.manager.isPaused();
  }

  async *pause() {
    const tx = await this.manager.pause.populateTransaction();
    yield this.createUnsignedTx(tx, "Ntt.pause");
  }

  async *unpause() {
    const tx = await this.manager.unpause.populateTransaction();
    yield this.createUnsignedTx(tx, "Ntt.unpause");
  }

  async getOwner(): Promise<AccountAddress<C>> {
    return new EvmAddress(await this.manager.owner()) as AccountAddress<C>;
  }

  async getPauser(): Promise<AccountAddress<C> | null> {
    return new EvmAddress(await this.manager.pauser()) as AccountAddress<C>;
  }

  async *setOwner(owner: AnyEvmAddress) {
    const canonicalOwner = new EvmAddress(owner).toString();
    const tx =
      await this.manager.transferOwnership.populateTransaction(canonicalOwner);
    yield this.createUnsignedTx(tx, "Ntt.setOwner");
  }

  async *setPauser(pauser: AnyEvmAddress) {
    const canonicalPauser = new EvmAddress(pauser).toString();
    const tx =
      await this.manager.transferPauserCapability.populateTransaction(
        canonicalPauser
      );
    yield this.createUnsignedTx(tx, "Ntt.setPauser");
  }

  async getThreshold(): Promise<number> {
    return Number(await this.manager.getThreshold());
  }

  async *setThreshold(threshold: number, payer?: AccountAddress<EvmChains>) {
    const tx = await this.manager.setThreshold.populateTransaction(threshold);
    yield this.createUnsignedTx(tx, "Ntt.setThreshold");
  }

  async getIsExecuted(attestation: Ntt.Attestation): Promise<boolean> {
    const payload = attestation.payload;
    const isExecuted = await this.manager.isMessageExecuted(
      Ntt.messageDigest(attestation.emitterChain, payload["nttManagerPayload"])
    );
    if (!isExecuted) return false;
    // Also check that the transfer is not queued for it to be considered complete
    return !(await this.getIsTransferInboundQueued(attestation));
  }

  async getIsTransferInboundQueued(
    attestation: Ntt.Attestation
  ): Promise<boolean> {
    const payload = attestation.payload;
    return (
      (await this.getInboundQueuedTransfer(
        attestation.emitterChain,
        payload["nttManagerPayload"]
      )) !== null
    );
  }

  getIsApproved(attestation: Ntt.Attestation): Promise<boolean> {
    const payload = attestation.payload;
    return this.manager.isMessageApproved(
      Ntt.messageDigest(attestation.emitterChain, payload["nttManagerPayload"])
    );
  }

  async getTokenDecimals(): Promise<number> {
    return await EvmPlatform.getDecimals(
      this.network,
      this.chain,
      this.provider,
      this.tokenAddress
    );
  }

  async getPeer<C extends Chain>(chain: C): Promise<Ntt.Peer<C> | null> {
    const peer = await this.manager.getPeer(toChainId(chain));
    const peerAddress = encoding.hex.decode(peer.peerAddress);
    const zeroAddress = new Uint8Array(32);
    if (encoding.bytes.equals(zeroAddress, peerAddress)) {
      return null;
    }

    return {
      address: { chain: chain, address: toUniversal(chain, peerAddress) },
      tokenDecimals: Number(peer.tokenDecimals),
      inboundLimit: await this.getInboundLimit(chain),
    };
  }

  static async fromRpc<N extends Network>(
    provider: Provider,
    config: ChainsConfig<N, EvmPlatformType>
  ): Promise<EvmNtt<N, EvmChains>> {
    const [network, chain] = await EvmPlatform.chainFromRpc(provider);
    const conf = config[chain]!;
    if (conf.network !== network)
      throw new Error(`Network mismatch: ${conf.network} != ${network}`);

    const version = await EvmNtt.getVersion(provider, conf.contracts);
    const ntt = new EvmNtt(
      network as N,
      chain,
      provider,
      conf.contracts,
      version
    );
    await ntt.initTransceiverIndices();
    return ntt;
  }

  encodeOptions(options: Ntt.TransferOptions): Ntt.TransceiverInstruction[] {
    const ixs: Ntt.TransceiverInstruction[] = [];

    for (const xcvr of this.xcvrs) {
      ixs.push({
        index: xcvr.registeredIndex,
        payload: xcvr.encodeFlags({
          skipRelay: !options.automatic,
        }),
      });
    }

    // On-chain parseTransceiverInstructions requires strictly increasing indices
    ixs.sort((a, b) => a.index - b.index);

    return ixs;
  }

  static async getVersion(
    provider: Provider,
    contracts: Contracts & { ntt?: Ntt.Contracts }
  ) {
    const contract = new Contract(
      contracts.ntt!.manager,
      ["function NTT_MANAGER_VERSION() public view returns (string)"],
      provider
    );
    try {
      const abiVersion = await contract
        .getFunction("NTT_MANAGER_VERSION")
        .staticCall();
      if (!abiVersion) {
        throw new Error("NTT_MANAGER_VERSION not found");
      }
      return abiVersion;
    } catch (e) {
      console.error(
        `Failed to get NTT_MANAGER_VERSION from contract ${
          contracts.ntt?.manager
        } on ${(await provider.getNetwork()).name}`
      );
      throw e;
    }
  }

  async getCustodyAddress() {
    return this.managerAddress;
  }

  async quoteDeliveryPrice(
    dstChain: Chain,
    options: Ntt.TransferOptions
  ): Promise<bigint> {
    await this.initTransceiverIndices();

    // Bypass the manager's quoteDeliveryPrice because it has a bug: it sizes the
    // transceiver instructions array using enabledTransceivers.length instead of
    // numRegisteredTransceivers, causing an out-of-bounds access when the active
    // transceiver's registered index >= number of enabled transceivers.
    // Instead, we call each transceiver's quoteDeliveryPrice directly.
    const instructions = this.encodeOptions(options);
    let totalPrice = 0n;

    for (const xcvr of this.xcvrs) {
      const ix = instructions.find((i) => i.index === xcvr.registeredIndex);
      const instruction = ix ?? {
        index: xcvr.registeredIndex,
        payload: new Uint8Array(),
      };
      const price = await xcvr.transceiver.quoteDeliveryPrice(
        toChainId(dstChain),
        instruction
      );
      totalPrice += price;
    }

    return totalPrice;
  }

  async *setPeer(
    peer: ChainAddress<C>,
    tokenDecimals: number,
    inboundLimit: bigint
  ) {
    const tx = await this.manager.setPeer.populateTransaction(
      toChainId(peer.chain),
      universalAddress(peer),
      tokenDecimals,
      inboundLimit
    );
    yield this.createUnsignedTx(tx, "Ntt.setPeer");
  }

  async *setWormholeTransceiverPeer(peer: ChainAddress<C>) {
    yield* this.setTransceiverPeer(0, peer);
  }

  async *setTransceiverPeer(ix: number, peer: ChainAddress<C>) {
    if (ix >= this.xcvrs.length) {
      throw new Error("Transceiver not found");
    }
    yield* this.xcvrs[ix]!.setPeer(peer);
  }

  async *transfer(
    sender: AccountAddress<C>,
    amount: bigint,
    destination: ChainAddress,
    options: Ntt.TransferOptions
  ): AsyncGenerator<EvmUnsignedTransaction<N, C>> {
    const senderAddress = new EvmAddress(sender).toString();

    // Note: these flags are indexed by transceiver index
    const totalPrice = await this.quoteDeliveryPrice(
      destination.chain,
      options
    );

    if (options.wrapNative) {
      yield this.wrapNative(sender, amount);
    }

    const approveTx = await this.approve(sender, amount);
    if (approveTx) {
      yield approveTx;
    }

    const receiver = universalAddress(destination);
    const txReq = await this.manager
      .getFunction("transfer(uint256,uint16,bytes32,bytes32,bool,bytes)")
      .populateTransaction(
        amount,
        toChainId(destination.chain),
        receiver,
        receiver,
        options.queue,
        Ntt.encodeTransceiverInstructions(this.encodeOptions(options)),
        { value: totalPrice }
      );

    yield this.createUnsignedTx(addFrom(txReq, senderAddress), "Ntt.transfer");
  }

  async wrapNative(sender: AccountAddress<C>, amount: bigint) {
    const senderAddress = new EvmAddress(sender).toString();

    // TODO: the contract should handle this for us
    const wrappedNative = new Contract(this.tokenAddress, [
      "function deposit() public payable",
    ]);

    const txReq = await wrappedNative
      .getFunction("deposit")
      .populateTransaction({ value: amount });

    return this.createUnsignedTx(addFrom(txReq, senderAddress), "Ntt.Deposit");
  }

  async approve(sender: AccountAddress<C>, amount: bigint) {
    const senderAddress = new EvmAddress(sender).toString();

    const tokenContract = EvmPlatform.getTokenImplementation(
      this.provider,
      this.tokenAddress
    );

    const allowance = await tokenContract.allowance(
      senderAddress,
      this.managerAddress
    );
    if (allowance < amount) {
      const txReq = await tokenContract.approve.populateTransaction(
        this.managerAddress,
        amount
      );

      return this.createUnsignedTx(
        addFrom(txReq, senderAddress),
        "Ntt.Approve"
      );
    }
  }

  // TODO: should this be some map of idx to transceiver?
  async *redeem(attestations: Ntt.Attestation[]) {
    if (attestations.length !== this.xcvrs.length)
      throw new Error(
        "Not enough attestations for the registered Transceivers"
      );

    for (const idx in this.xcvrs) {
      const xcvr = this.xcvrs[idx]!;
      const attestation = attestations[idx];
      if (attestation?.payloadName !== "WormholeTransfer") {
        // TODO: support standard relayer attestations
        // which must be submitted to the delivery provider
        throw new Error("Invalid attestation type for redeem");
      }
      yield* xcvr.receive(attestation);
    }
  }

  async getCurrentOutboundCapacity(): Promise<bigint> {
    return await this.manager.getCurrentOutboundCapacity();
  }

  async getOutboundLimit(): Promise<bigint> {
    const encoded: EncodedTrimmedAmount = (
      await this.manager.getOutboundLimitParams()
    ).limit;
    const trimmedAmount = decodeTrimmedAmount(encoded);
    const tokenDecimals = await this.getTokenDecimals();

    return untrim(trimmedAmount, tokenDecimals);
  }

  async *setOutboundLimit(limit: bigint) {
    const tx = await this.manager.setOutboundLimit.populateTransaction(limit);
    yield this.createUnsignedTx(tx, "Ntt.setOutboundLimit");
  }

  async getCurrentInboundCapacity(fromChain: Chain): Promise<bigint> {
    return await this.manager.getCurrentInboundCapacity(toChainId(fromChain));
  }

  async getInboundLimit(fromChain: Chain): Promise<bigint> {
    const encoded: EncodedTrimmedAmount = (
      await this.manager.getInboundLimitParams(toChainId(fromChain))
    ).limit;
    const trimmedAmount = decodeTrimmedAmount(encoded);
    const tokenDecimals = await this.getTokenDecimals();

    return untrim(trimmedAmount, tokenDecimals);
  }

  async *setInboundLimit(fromChain: Chain, limit: bigint) {
    const tx = await this.manager.setInboundLimit.populateTransaction(
      limit,
      toChainId(fromChain)
    );
    yield this.createUnsignedTx(tx, "Ntt.setInboundLimit");
  }

  async getRateLimitDuration(): Promise<bigint> {
    return await this.manager.rateLimitDuration();
  }

  async getInboundQueuedTransfer(
    fromChain: Chain,
    transceiverMessage: Ntt.Message
  ): Promise<Ntt.InboundQueuedTransfer<C> | null> {
    const queuedTransfer = await this.manager.getInboundQueuedTransfer(
      Ntt.messageDigest(fromChain, transceiverMessage)
    );
    if (queuedTransfer.txTimestamp > 0n) {
      const { recipient, amount, txTimestamp } = queuedTransfer;
      const duration = await this.getRateLimitDuration();
      return {
        recipient: new EvmAddress(recipient) as AccountAddress<C>,
        amount: amount,
        rateLimitExpiryTimestamp: Number(txTimestamp + duration),
      };
    }
    return null;
  }

  async *completeInboundQueuedTransfer(
    fromChain: Chain,
    transceiverMessage: Ntt.Message,
    payer?: AccountAddress<C>
  ) {
    const tx =
      await this.manager.completeInboundQueuedTransfer.populateTransaction(
        Ntt.messageDigest(fromChain, transceiverMessage)
      );
    yield this.createUnsignedTx(tx, "Ntt.completeInboundQueuedTransfer");
  }

  async verifyAddresses(): Promise<Partial<Ntt.Contracts> | null> {
    const local: Partial<Ntt.Contracts> = {
      manager: this.managerAddress,
      token: this.tokenAddress,
      transceiver: {
        ...(this.xcvrs.length > 0 && { wormhole: this.xcvrs[0]!.address }),
      },
      // TODO: what about the quoter?
    };

    // Match the on-chain wormhole transceiver by address rather than assuming
    // it is at array index 0, since enabled transceiver ordering can change
    // after remove/re-add operations.
    const enabledTransceivers = await this.manager.getTransceivers();
    let wormholeTransceiverAddr: string | undefined;
    for (const xcvr of this.xcvrs) {
      wormholeTransceiverAddr = enabledTransceivers.find(
        (addr: string) => addr.toLowerCase() === xcvr.address.toLowerCase()
      );
      if (wormholeTransceiverAddr) break;
    }
    // Backward-compatible fallback for manager-only discovery flows (e.g. CLI pull):
    // if no local xcvr is configured, default to the first enabled transceiver.
    if (!wormholeTransceiverAddr && enabledTransceivers.length > 0) {
      wormholeTransceiverAddr = enabledTransceivers[0];
    }

    const remote: Partial<Ntt.Contracts> = {
      manager: this.managerAddress,
      token: await this.manager.token(),
      transceiver: {
        ...(wormholeTransceiverAddr && { wormhole: wormholeTransceiverAddr }),
      },
    };

    const deleteMatching = (a: any, b: any) => {
      for (const k in a) {
        if (typeof a[k] === "object") {
          deleteMatching(a[k], b[k]);
          if (Object.keys(a[k]).length === 0) delete a[k];
        } else if (a[k] === b[k]) {
          delete a[k];
        }
      }
    };

    deleteMatching(remote, local);

    return Object.keys(remote).length > 0 ? remote : null;
  }

  createUnsignedTx(
    txReq: TransactionRequest,
    description: string,
    parallelizable: boolean = false
  ): EvmUnsignedTransaction<N, C> {
    return new EvmUnsignedTransaction(
      addChainId(txReq, this.chainId),
      this.network,
      this.chain,
      description,
      parallelizable
    );
  }
}
