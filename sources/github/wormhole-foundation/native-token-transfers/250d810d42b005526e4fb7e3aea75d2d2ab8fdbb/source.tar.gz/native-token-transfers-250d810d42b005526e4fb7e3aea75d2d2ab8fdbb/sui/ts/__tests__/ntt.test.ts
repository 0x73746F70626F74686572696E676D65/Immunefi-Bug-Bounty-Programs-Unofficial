import { jest } from "@jest/globals";
import {
  mockSuiClient,
  mockNttState,
  mockSuiObject,
  mockAdminCap,
  mockCoinMetadata,
  mockPeerData,
  mockPeerDynamicField,
  mockTransceiverState,
  mockTransceiverPeerData,
  mockDynamicFields,
  mockTransceiverInfo,
  mockAttestation,
  TEST_ADDRESSES,
  TEST_CONTRACTS,
} from "./mocks.js";

// Mock the serialize function. Under native-ESM jest, jest.mock does not hoist,
// so use unstable_mockModule + dynamic import of the consumer.
// `serialize` is mocked via the unstable_mockModule below so that
// `addRedeemCall` does not fail at VAA serialization, allowing the redeem test
// to fail at `serializeLayout(nativeTokenTransferLayout, ...)` as intended.
const actualDefinitions = (await import(
  "@wormhole-foundation/sdk-definitions"
)) as any;

jest.unstable_mockModule("@wormhole-foundation/sdk-definitions", () => ({
  __esModule: true,
  ...actualDefinitions,
  serialize: jest.fn(() => new Uint8Array([1, 2, 3, 4, 5])), // Mock VAA bytes
}));

// Mock SuiGraphQLClient with a default implementation that can be overridden
const mockQuery = jest.fn<any>().mockResolvedValue({
  data: {
    objects: {
      nodes: [
        {
          address:
            "0x9876543210987654321098765432109876543210987654321098765432109876",
        },
      ],
    },
  },
});

jest.unstable_mockModule("@mysten/sui/graphql", () => ({
  SuiGraphQLClient: jest.fn().mockImplementation(() => ({
    query: mockQuery,
  })),
}));

// Dynamically import the module under test after the mocks are registered.
const { SuiNtt } = await import("../src/ntt.js");

describe("SuiNtt", () => {
  let suiNtt: InstanceType<typeof SuiNtt<"Testnet", "Sui">>;
  let mockClient: jest.Mocked<any>;

  beforeEach(() => {
    mockClient = mockSuiClient();
    suiNtt = new SuiNtt("Testnet", "Sui", mockClient, {
      ntt: TEST_CONTRACTS.ntt,
      coreBridge: TEST_CONTRACTS.coreBridge,
    });
  });

  // ========== ADMIN FUNCTIONS ==========
  describe("Admin Functions", () => {
    describe("setThreshold", () => {
      const newThreshold = 5;

      beforeEach(() => {
        // Mock admin cap and package ID retrieval
        mockClient.getObject
          .mockResolvedValueOnce(
            mockNttState({
              adminCapId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            })
          )
          .mockResolvedValueOnce(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          );
      });

      it("should create setThreshold transaction with correct parameters", async () => {
        const txGenerator = suiNtt.setThreshold(newThreshold);
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Set Threshold");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });

      it("should require admin cap for threshold changes", async () => {
        // Create a fresh instance to avoid cached adminCapId
        const freshMockClient = mockSuiClient();
        const freshSuiNtt = new SuiNtt("Testnet", "Sui", freshMockClient, {
          ntt: TEST_CONTRACTS.ntt,
          coreBridge: TEST_CONTRACTS.coreBridge,
        });

        // Mock admin cap not found
        freshMockClient.getObject.mockResolvedValueOnce(
          mockNttState({ adminCapId: null })
        );

        const txGenerator = freshSuiNtt.setThreshold(3);
        await expect(txGenerator.next()).rejects.toThrow(
          "AdminCap ID not found in NTT state"
        );
      });
    });
  });

  // ========== CORE STATE FUNCTIONS ==========
  describe("Core State Functions", () => {
    describe("getMode", () => {
      it("should return locking mode for default state", async () => {
        mockClient.getObject.mockResolvedValue(mockNttState());

        const mode = await suiNtt.getMode();
        expect(mode).toBe("locking");
      });

      it("should return burning mode when configured", async () => {
        mockClient.getObject.mockResolvedValue(
          mockNttState({ mode: "Burning" })
        );

        const mode = await suiNtt.getMode();
        expect(mode).toBe("burning");
      });

      it("should throw error when state fetch fails", async () => {
        mockClient.getObject.mockResolvedValue({ object: null });

        await expect(suiNtt.getMode()).rejects.toThrow(
          "Failed to fetch NTT state object"
        );
      });
    });

    describe("getThreshold", () => {
      it("should return threshold value from state", async () => {
        mockClient.getObject.mockResolvedValue(
          mockNttState({ threshold: "3" })
        );

        const threshold = await suiNtt.getThreshold();
        expect(threshold).toBe(3);
      });
    });

    describe("getAdminCapId", () => {
      it("should return admin cap ID from state", async () => {
        const state = mockNttState({
          adminCapId:
            "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
        });
        mockClient.getObject.mockResolvedValue(state);

        const adminCapId = await suiNtt.getAdminCapId();
        expect(adminCapId).toBe(
          "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
        );
      });

      it("should throw error when admin cap ID not found", async () => {
        const state = mockNttState({ adminCapId: null });
        mockClient.getObject.mockResolvedValue(state);

        await expect(suiNtt.getAdminCapId()).rejects.toThrow(
          "AdminCap ID not found in NTT state"
        );
      });
    });

    describe("getOwner", () => {
      it("should return owner address from AdminCap", async () => {
        const state = mockNttState({
          adminCapId:
            "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
        });
        mockClient.getObject
          .mockResolvedValueOnce(state)
          .mockResolvedValueOnce(mockAdminCap(TEST_ADDRESSES.ADMIN));

        const owner = await suiNtt.getOwner();
        expect(owner).toBe(TEST_ADDRESSES.ADMIN);
      });

      it("should throw error when AdminCap not found", async () => {
        const state = mockNttState({
          adminCapId:
            "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
        });
        mockClient.getObject
          .mockResolvedValueOnce(state)
          .mockResolvedValueOnce({ object: null });

        await expect(suiNtt.getOwner()).rejects.toThrow(
          "Failed to get AdminCap owner: Error: Could not fetch AdminCap owner information"
        );
      });
    });

    describe("getPackageId", () => {
      it("should extract package ID from state object type", async () => {
        const packageId =
          "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef";
        mockClient.getObject.mockResolvedValue(
          mockSuiObject(`${packageId}::ntt::State<0x2::sui::SUI>`, {})
        );

        const result = await suiNtt.getPackageId();
        expect(result).toBe(packageId);
      });

      it("should throw error when state fetch fails", async () => {
        mockClient.getObject.mockResolvedValue({ object: null });

        await expect(suiNtt.getPackageId()).rejects.toThrow(
          "Failed to fetch state object"
        );
      });
    });

    describe("getTokenDecimals", () => {
      it("should return 9 for SUI token", async () => {
        mockClient.getCoinMetadata.mockResolvedValue(mockCoinMetadata(9));

        const decimals = await suiNtt.getTokenDecimals();
        expect(decimals).toBe(9);
      });

      it("should throw error for non-SUI tokens", async () => {
        const customSuiNtt = new SuiNtt("Testnet", "Sui", mockClient, {
          ntt: {
            ...TEST_CONTRACTS.ntt,
            token: "0xabc::custom::TOKEN",
          },
          coreBridge: TEST_CONTRACTS.coreBridge,
        });

        mockClient.getCoinMetadata.mockResolvedValue({ coinMetadata: null });

        await expect(customSuiNtt.getTokenDecimals()).rejects.toThrow(
          "CoinMetadata not found for 0xabc::custom::TOKEN"
        );
      });
    });
  });

  // ========== RATE LIMITING FUNCTIONS ==========
  describe("Rate Limiting Functions", () => {
    describe("getCurrentOutboundCapacity", () => {
      it("should return current outbound capacity", async () => {
        mockClient.getObject.mockResolvedValue(mockNttState());

        const capacity = await suiNtt.getCurrentOutboundCapacity();
        expect(capacity).toBeGreaterThanOrEqual(0n);
      });
    });

    describe("getOutboundLimit", () => {
      it("should return outbound limit from state", async () => {
        mockClient.getObject.mockResolvedValue(
          mockNttState({ outboundLimit: "1000000000000" })
        );

        const limit = await suiNtt.getOutboundLimit();
        expect(limit).toBe(1000000000000n);
      });
    });

    describe("setOutboundLimit", () => {
      const newLimit = 2000000000000n;

      beforeEach(() => {
        mockClient.getObject
          .mockResolvedValueOnce(
            mockNttState({
              adminCapId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            })
          )
          .mockResolvedValueOnce(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          );
      });

      it("should create setOutboundLimit transaction", async () => {
        const txGenerator = suiNtt.setOutboundLimit(newLimit);
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Set Outbound Limit");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });
    });

    describe("setInboundLimit", () => {
      const newLimit = 2000000000000n;

      beforeEach(() => {
        // Mock existing peer data:
        //  - getAdminCapId (state)
        //  - getPackageId (state)
        //  - getPeer: getNttState (state) -> getDynamicField -> getObject(peer)
        //  - wormhole package ID (state)
        mockClient.getObject
          .mockResolvedValueOnce(
            mockNttState({
              adminCapId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            })
          ) // getAdminCapId
          .mockResolvedValueOnce(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          ) // getPackageId
          .mockResolvedValueOnce(mockNttState()) // getPeer state fetch
          .mockResolvedValueOnce(mockPeerData()) // getPeer peer field object
          .mockResolvedValueOnce(mockSuiObject("0xwormhole::state::State", {})); // wormhole package ID

        mockClient.getDynamicField.mockResolvedValue(mockPeerDynamicField());
      });

      it("should create setInboundLimit transaction with existing peer", async () => {
        const txGenerator = suiNtt.setInboundLimit("Ethereum", newLimit);
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Set Inbound Limit");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });

      it("should throw error when peer doesn't exist", async () => {
        mockClient.getDynamicField.mockRejectedValue(new Error("not found"));

        const txGenerator = suiNtt.setInboundLimit("Ethereum", newLimit);
        await expect(txGenerator.next()).rejects.toThrow(
          "No peer found for chain Ethereum. Set up the peer first using setPeer."
        );
      });
    });
  });

  // ========== PEER MANAGEMENT FUNCTIONS ==========
  describe("Peer Management Functions", () => {
    describe("getPeer", () => {
      beforeEach(() => {
        // getNttState (state) then peer field object
        mockClient.getObject
          .mockResolvedValueOnce(mockNttState())
          .mockResolvedValueOnce(mockPeerData());
      });

      it("should return peer data for existing peer", async () => {
        mockClient.getDynamicField.mockResolvedValue(mockPeerDynamicField());

        const peer = await suiNtt.getPeer("Ethereum");

        expect(peer).not.toBeNull();
        expect(peer?.address.chain).toBe("Ethereum");
        expect(peer?.tokenDecimals).toBe(6);
        expect(peer?.inboundLimit).toBe(500000000000n);

        expect(mockClient.getDynamicField).toHaveBeenCalledWith(
          expect.objectContaining({
            parentId: "mock-peers-table-id",
            name: expect.objectContaining({
              type: "u16",
              bcs: expect.anything(),
            }),
          })
        );
      });

      it("should return null for non-existent peer", async () => {
        mockClient.getDynamicField.mockRejectedValue(new Error("not found"));

        const peer = await suiNtt.getPeer("Ethereum");
        expect(peer).toBeNull();
      });

      it("should throw error when state fetch fails", async () => {
        mockClient.getObject.mockReset();
        mockClient.getObject.mockResolvedValue({ object: null });

        await expect(suiNtt.getPeer("Ethereum")).rejects.toThrow(
          "Failed to fetch NTT state object"
        );
      });
    });

    describe("setPeer", () => {
      const peerAddress = {
        chain: "Ethereum" as const,
        address: {
          toUint8Array: () => new Uint8Array(32).fill(1),
        },
      } as any;
      const tokenDecimals = 6;
      const inboundLimit = 1000000n;

      beforeEach(() => {
        // Mock required state and objects
        mockClient.getObject
          .mockResolvedValueOnce(
            mockNttState({
              adminCapId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            })
          ) // getAdminCapId
          .mockResolvedValueOnce(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          ) // getPackageId
          .mockResolvedValueOnce(mockSuiObject("0xwormhole::state::State", {})); // wormhole package ID
      });

      it("should create setPeer transaction with correct parameters", async () => {
        const txGenerator = suiNtt.setPeer(
          peerAddress,
          tokenDecimals,
          inboundLimit
        );
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Set Peer");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });

      it("should throw error when address conversion fails", async () => {
        const invalidPeer = {
          chain: "Ethereum" as const,
          address: {
            toUint8Array: () => {
              throw new Error("Address conversion failed");
            },
          },
        } as any;

        const txGenerator = suiNtt.setPeer(
          invalidPeer,
          tokenDecimals,
          inboundLimit
        );
        await expect(txGenerator.next()).rejects.toThrow(
          "Address conversion failed"
        );
      });
    });

    describe("getTransceiverPeer", () => {
      beforeEach(() => {
        // transceiver state object then transceiver peer field object
        mockClient.getObject
          .mockResolvedValueOnce({
            object: {
              json: {
                peers: {
                  id: "transceiver-peers-table-id",
                },
              },
            },
          })
          .mockResolvedValueOnce(mockTransceiverPeerData());
      });

      it("should return transceiver peer for existing peer", async () => {
        mockClient.getDynamicField.mockResolvedValue(mockPeerDynamicField());

        const peer = await suiNtt.getTransceiverPeer(0, "Ethereum");

        expect(peer).not.toBeNull();
        expect(peer?.chain).toBe("Ethereum");
      });

      it("should return null for non-supported transceiver index", async () => {
        const peer = await suiNtt.getTransceiverPeer(1, "Ethereum");
        expect(peer).toBeNull();
      });

      it("should return null for non-existent peer", async () => {
        mockClient.getDynamicField.mockRejectedValue(new Error("not found"));

        const peer = await suiNtt.getTransceiverPeer(0, "Ethereum");
        expect(peer).toBeNull();
      });
    });

    describe("setTransceiverPeer", () => {
      const peerAddress = {
        chain: "Ethereum" as const,
        address: {
          toUint8Array: () => new Uint8Array(32).fill(1),
        },
      } as any;

      beforeEach(() => {
        // Mock transceiver state
        mockClient.getObject
          .mockResolvedValueOnce(
            mockSuiObject("0xtransceiver::package::State", {})
          ) // package ID extraction
          .mockResolvedValueOnce(
            mockSuiObject("TransceiverState", {
              admin_cap_id:
                "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
            })
          ) // transceiver state
          .mockResolvedValueOnce(mockNttState()) // getPackageId
          .mockResolvedValueOnce(mockSuiObject("0xwormhole::state::State", {})); // wormhole package ID
      });

      it("should create setTransceiverPeer transaction", async () => {
        // Mock the complex setTransceiverPeer implementation directly
        const mockTxGenerator = {
          async *[Symbol.asyncIterator]() {
            yield {
              description: "Set Transceiver Peer",
              network: "Testnet",
              chain: "Sui",
              parallelizable: false,
              transaction: {},
            };
          },
        };

        jest
          .spyOn(suiNtt, "setTransceiverPeer")
          .mockReturnValue(mockTxGenerator as any);

        const txGenerator = suiNtt.setTransceiverPeer(0, peerAddress);
        const { value: unsignedTx } =
          await txGenerator[Symbol.asyncIterator]().next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Set Transceiver Peer");
      });

      it("should throw error for unsupported transceiver index", async () => {
        const txGenerator = suiNtt.setTransceiverPeer(1, peerAddress);
        await expect(txGenerator.next()).rejects.toThrow(
          "Only transceiver index 0 (wormhole) is currently supported"
        );
      });

      it("should throw error when wormhole transceiver not found", async () => {
        const suiNttWithoutTransceiver = new SuiNtt(
          "Testnet",
          "Sui",
          mockClient,
          {
            ntt: {
              ...TEST_CONTRACTS.ntt,
              transceiver: {},
            },
            coreBridge: TEST_CONTRACTS.coreBridge,
          }
        );

        const txGenerator = suiNttWithoutTransceiver.setTransceiverPeer(
          0,
          peerAddress
        );
        await expect(txGenerator.next()).rejects.toThrow(
          "Wormhole transceiver not found in contracts"
        );
      });
    });
  });

  // ========== TRANSCEIVER MANAGEMENT FUNCTIONS ==========
  describe("Transceiver Management Functions", () => {
    describe("getTransceiver", () => {
      it("should return wormhole transceiver for index 0", async () => {
        const transceiver = await suiNtt.getTransceiver(0);

        expect(transceiver).not.toBeNull();
        expect(typeof transceiver?.getTransceiverType).toBe("function");
        expect(typeof transceiver?.getAddress).toBe("function");
        expect(typeof transceiver?.setPeer).toBe("function");
        expect(typeof transceiver?.getPeer).toBe("function");
      });

      it("should return null for non-supported transceiver index", async () => {
        const transceiver = await suiNtt.getTransceiver(1);
        expect(transceiver).toBeNull();
      });

      it("should return null when wormhole transceiver not configured", async () => {
        const suiNttWithoutTransceiver = new SuiNtt(
          "Testnet",
          "Sui",
          mockClient,
          {
            ntt: {
              ...TEST_CONTRACTS.ntt,
              transceiver: {},
            },
            coreBridge: TEST_CONTRACTS.coreBridge,
          }
        );

        const transceiver = await suiNttWithoutTransceiver.getTransceiver(0);
        expect(transceiver).toBeNull();
      });

      describe("transceiver interface", () => {
        let transceiver: any;

        beforeEach(async () => {
          transceiver = await suiNtt.getTransceiver(0);
        });

        it("should return correct transceiver type", async () => {
          const type = await transceiver.getTransceiverType();
          expect(type).toBe("wormhole");
        });

        it("should return transceiver address", async () => {
          mockClient.getObject.mockResolvedValue(mockTransceiverState());

          const address = await transceiver.getAddress();

          expect(address).toBeDefined();
          expect(address.chain).toBe("Sui");
          expect(address.address).toBeDefined();
        });

        it("should handle setPeer delegation", async () => {
          const peerAddress = {
            chain: "Ethereum" as const,
            address: {
              toUint8Array: () => new Uint8Array(32).fill(1),
            },
          };

          // Mock the setTransceiverPeer method directly to avoid complex mock setup
          const mockTxGenerator = {
            async *[Symbol.asyncIterator]() {
              yield {
                description: "Set Transceiver Peer",
                network: "Testnet",
                chain: "Sui",
                parallelizable: false,
                transaction: {},
              };
            },
          };

          jest
            .spyOn(suiNtt, "setTransceiverPeer")
            .mockReturnValue(mockTxGenerator as any);

          const txGenerator = transceiver.setPeer(peerAddress);
          const { value: unsignedTx } =
            await txGenerator[Symbol.asyncIterator]().next();

          expect(unsignedTx).toBeDefined();
          expect(unsignedTx.description).toBe("Set Transceiver Peer");
        });

        it("should handle getPeer delegation", async () => {
          // transceiver state object then transceiver peer field object
          mockClient.getObject
            .mockResolvedValueOnce(mockTransceiverState())
            .mockResolvedValueOnce(mockTransceiverPeerData());
          mockClient.getDynamicField.mockResolvedValue(mockPeerDynamicField());

          const peer = await transceiver.getPeer("Ethereum");

          expect(peer).not.toBeNull();
          expect(peer.chain).toBe("Ethereum");
        });
      });
    });

    describe("verifyAddresses", () => {
      beforeEach(() => {
        mockClient.listDynamicFields.mockResolvedValue(mockDynamicFields());
        // first getObject -> NTT state; subsequent -> transceiver info / token type
        mockClient.getObject
          .mockResolvedValueOnce(mockNttState())
          .mockResolvedValue(mockTransceiverInfo());
      });

      it("should verify NTT contracts and discover transceivers", async () => {
        const result = await suiNtt.verifyAddresses();

        // Should return differences or null if everything matches
        expect(result).toBeDefined();
      });

      it("should handle state object fetch failure", async () => {
        mockClient.getObject.mockReset();
        mockClient.getObject.mockResolvedValue({ object: null });

        const result = await suiNtt.verifyAddresses();
        expect(result).toBeNull();
      });

      it("should return null when addresses match local config", async () => {
        // Mock exact match scenario
        const transceiverInfo = mockTransceiverInfo();
        transceiverInfo.object.json.value.state_object_id = TEST_CONTRACTS.ntt
          .transceiver?.wormhole as string;

        mockClient.getObject.mockReset();
        mockClient.getObject
          .mockResolvedValueOnce(mockNttState()) // state object
          .mockResolvedValueOnce(mockNttState()) // extractTokenTypeFromSuiState
          .mockResolvedValueOnce(transceiverInfo); // matching transceiver info

        const result = await suiNtt.verifyAddresses();

        // Should return null when everything matches
        expect(result).toBeNull();
      });
    });
  });

  // ========== TRANSFER OPERATIONS ==========
  describe("Transfer Operations", () => {
    describe("transfer", () => {
      const transferAmount = 1000000000n; // 1 SUI in lamports
      const sender = TEST_ADDRESSES.USER;
      const destination = {
        chain: "Ethereum" as const,
        address: {
          toUint8Array: () => new Uint8Array(32).fill(1),
          toUniversalAddress: () => ({
            toUint8Array: () => new Uint8Array(32).fill(1),
          }),
        },
      } as any;
      const options = { queue: false };

      beforeEach(() => {
        // Mock coin metadata query
        mockClient.getCoinMetadata.mockResolvedValue(mockCoinMetadata());

        // Mock listCoins for non-native token transfers (gRPC-shaped result
        // consumed by SuiPlatform.getCoins, which reads `objects[].{type,objectId}`)
        mockClient.listCoins.mockResolvedValue({
          objects: [
            {
              type: "0xabc::custom::TOKEN",
              objectId: "0xmockcoin123",
            },
          ],
          cursor: null,
          hasNextPage: false,
        });

        // Mock listDynamicFields for getWormholePackageId
        mockClient.listDynamicFields.mockResolvedValue({
          dynamicFields: [
            {
              name: { type: "CurrentPackage" },
              fieldId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            },
          ],
          cursor: null,
          hasNextPage: false,
        });

        // Mock getObject for multiple different object IDs (gRPC: params.objectId)
        mockClient.getObject.mockImplementation((params: any) => {
          if (
            params.objectId ===
            "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
          ) {
            // Mock for CurrentPackage object in getWormholePackageId
            return Promise.resolve(
              mockSuiObject("CurrentPackage", {
                value: {
                  package:
                    "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
                },
              })
            );
          } else if (
            params.objectId === TEST_CONTRACTS.ntt.transceiver.wormhole
          ) {
            // Mock for transceiver state object (getPackageIdFromObject)
            return Promise.resolve(
              mockSuiObject(
                "0xfedcba0987654321fedcba0987654321fedcba0987654321fedcba0987654321::wormhole_transceiver::State",
                {}
              )
            );
          }
          // Default mock for NTT manager state
          return Promise.resolve(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          );
        });
      });

      it("should create transfer transaction with correct parameters", async () => {
        const txGenerator = suiNtt.transfer(
          sender as any,
          transferAmount,
          destination,
          options
        );
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("NTT Transfer");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });

      it("should throw error when coin metadata not found", async () => {
        // Mock GraphQL to return no results
        mockQuery.mockResolvedValueOnce({
          data: {
            objects: {
              nodes: [],
            },
          },
        });

        const txGenerator = suiNtt.transfer(
          sender as any,
          transferAmount,
          destination,
          options
        );
        await expect(txGenerator.next()).rejects.toThrow(
          "CoinMetadata object not found for type 0x2::sui::SUI"
        );
      });

      it("should create transfer transaction for custom tokens", async () => {
        // Mock GraphQL to return a valid CoinMetadata ID for custom token
        mockQuery.mockResolvedValueOnce({
          data: {
            objects: {
              nodes: [
                {
                  address:
                    "0x9876543210987654321098765432109876543210987654321098765432109876",
                },
              ],
            },
          },
        });

        const customSuiNtt = new SuiNtt("Testnet", "Sui", mockClient, {
          ntt: {
            ...TEST_CONTRACTS.ntt,
            token: "0xabc::custom::TOKEN",
          },
          coreBridge: TEST_CONTRACTS.coreBridge,
        });

        const txGenerator = customSuiNtt.transfer(
          sender as any,
          transferAmount,
          destination,
          options
        );
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("NTT Transfer");
      });
    });

    describe("redeem", () => {
      it("should create redeem transaction skeleton", async () => {
        const attestation = mockAttestation();
        const payer = TEST_ADDRESSES.USER;

        // Mock the necessary API calls in the order they'll be called
        const packageId =
          "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef";
        const wormholePackageId = "0xwormhole123";

        // Reset all mocks to ensure clean state
        jest.clearAllMocks();

        // Mock getObject based on what object ID is being requested
        mockClient.getObject.mockImplementation((params: any) => {
          if (params.objectId === TEST_CONTRACTS.ntt.manager) {
            // Mock for NTT state object for getNttCommonPackageId / getPackageId
            return Promise.resolve(
              mockSuiObject(`${packageId}::ntt::State<0x2::sui::SUI>`, {})
            );
          } else if (
            params.objectId === TEST_CONTRACTS.ntt.transceiver.wormhole
          ) {
            // Mock for transceiver state object
            return Promise.resolve(
              mockSuiObject(`${packageId}::wormhole_transceiver::State`, {})
            );
          } else if (
            params.objectId ===
            "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
          ) {
            // Mock for CurrentPackage object (from listDynamicFields)
            return Promise.resolve(
              mockSuiObject("CurrentPackage", {
                value: {
                  package: wormholePackageId,
                },
              })
            );
          } else {
            // Fallback mock
            return Promise.resolve(
              mockSuiObject(`${packageId}::ntt::State<0x2::sui::SUI>`, {})
            );
          }
        });

        // Mock the ntt-common package derivation (movePackageService.getDatatype)
        // so that the failure happens at serialization, not at package
        // derivation. Shape mirrors the gRPC DatatypeDescriptor / OpenSignatureBody:
        // a UnaryCall-like `{ response: { datatype } }` where field types carry a
        // `typeName` plus nested `typeParameterInstantiation` children.
        mockClient.movePackageService.getDatatype.mockResolvedValue({
          response: {
            datatype: {
              fields: [
                {
                  name: "inbox",
                  position: 0,
                  type: {
                    typeName: "0xnttcommon123::inbox::Inbox",
                    typeParameterInstantiation: [
                      {
                        typeName:
                          "0xnttcommon123::ntt_manager_message::NttManagerMessage",
                        typeParameterInstantiation: [
                          {
                            typeName:
                              "0xnttcommon123::native_token_transfer::NativeTokenTransfer",
                            typeParameterInstantiation: [],
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        });

        mockClient.getCoinMetadata.mockResolvedValue({
          coinMetadata: { id: "0xcoin123", decimals: 9 },
        });

        // Mock Wormhole core bridge dynamic fields for getWormholePackageId
        mockClient.listDynamicFields.mockResolvedValue({
          dynamicFields: [
            {
              name: { type: "CurrentPackage" },
              fieldId:
                "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
            },
          ],
          hasNextPage: false,
          cursor: null,
        });

        const txGenerator = suiNtt.redeem([attestation], payer as any);

        // Expect the operation to fail due to invalid payload format in test mock
        await expect(txGenerator.next()).rejects.toThrow(
          "Failed to serialize native token transfer payload"
        );
      });
    });

    describe("pause", () => {
      beforeEach(() => {
        // Mock admin cap and package ID retrieval
        mockClient.getObject
          .mockResolvedValueOnce(
            mockNttState({
              adminCapId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            })
          )
          .mockResolvedValueOnce(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          );
      });

      it("should create pause transaction", async () => {
        const txGenerator = suiNtt.pause();
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Pause Contract");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });
    });

    describe("unpause", () => {
      beforeEach(() => {
        // Mock admin cap and package ID retrieval
        mockClient.getObject
          .mockResolvedValueOnce(
            mockNttState({
              adminCapId:
                "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            })
          )
          .mockResolvedValueOnce(
            mockSuiObject(
              "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef::ntt::State",
              {}
            )
          );
      });

      it("should create unpause transaction", async () => {
        const txGenerator = suiNtt.unpause();
        const { value: unsignedTx } = await txGenerator.next();

        expect(unsignedTx).toBeDefined();
        expect(unsignedTx.description).toBe("Unpause Contract");
        expect(unsignedTx.network).toBe("Testnet");
        expect(unsignedTx.chain).toBe("Sui");
      });
    });

    describe("isPaused", () => {
      it("should return false when contract is not paused", async () => {
        const state = mockNttState({ paused: false });
        mockClient.getObject.mockResolvedValue(state);

        const isPaused = await suiNtt.isPaused();
        expect(isPaused).toBe(false);
      });

      it("should return true when contract is paused", async () => {
        const state = mockNttState({ paused: true });
        mockClient.getObject.mockResolvedValue(state);

        const isPaused = await suiNtt.isPaused();
        expect(isPaused).toBe(true);
      });
    });
  });
});
