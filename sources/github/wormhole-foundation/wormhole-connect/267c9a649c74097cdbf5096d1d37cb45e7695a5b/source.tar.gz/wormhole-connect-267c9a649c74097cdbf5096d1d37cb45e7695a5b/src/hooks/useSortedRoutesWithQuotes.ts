import { useMemo } from 'react';
import type { amount, Chain, routes } from '@wormhole-foundation/sdk';
import useFetchQuotes from 'hooks/useFetchQuotes';
import config from 'config';
import useFetchSupportedRoutes from './useFetchSupportedRoutes';
import type { Token } from 'config/tokens';
import type { WalletData } from 'store/wallet';

type Quote = routes.Quote<
  routes.Options,
  routes.ValidatedTransferParams<routes.Options>
>;

export type RouteWithQuote = {
  route: string;
  quote: Quote;
};

type HookReturn = {
  allSupportedRoutes: string[];
  sortedRoutes: string[];
  sortedRoutesWithQuotes: RouteWithQuote[];
  quotes: ReturnType<typeof useFetchQuotes>['quotes'];
  failedQuotes: ReturnType<typeof useFetchQuotes>['failedQuotes'];
  isFetching: boolean;
};

interface UseSortedRoutesWithQuotesArgs {
  amount?: amount.Amount;
  fromChain?: Chain;
  toChain?: Chain;
  preferredRouteName?: string;
  toNativeToken: number;
  sourceToken?: Token;
  destToken?: Token;
  sendingWallet: WalletData;
  receivingWallet: WalletData;
}

export const useSortedRoutesWithQuotes = ({
  amount,
  fromChain,
  toChain,
  preferredRouteName,
  toNativeToken,
  sourceToken,
  destToken,
  sendingWallet,
  receivingWallet,
}: UseSortedRoutesWithQuotesArgs): HookReturn => {
  const { supportedRoutes, isFetching: isFetchingSupportedRoutes } =
    useFetchSupportedRoutes({
      fromChain,
      toChain,
      sourceToken,
      destToken,
      toNativeToken,
      receivingWallet,
    });

  const quoteParams = useMemo(
    () => ({
      amount,
      sourceChain: fromChain,
      sourceToken,
      destChain: toChain,
      destToken,
      nativeGas: toNativeToken,
      sender: sendingWallet?.address,
      recipient: receivingWallet?.address,
    }),
    [
      amount,
      fromChain,
      sourceToken,
      destToken,
      toChain,
      toNativeToken,
      sendingWallet?.address,
      receivingWallet?.address,
    ],
  );

  const { quotes, failedQuotes, isFetchingQuotes } = useFetchQuotes(
    supportedRoutes,
    quoteParams,
  );

  const routesWithQuotes = useMemo(() => {
    return supportedRoutes
      .map((route) => {
        const quote = quotes[route];
        if (quote?.success) {
          return {
            route,
            quote,
          };
        } else {
          return undefined;
        }
      })
      .filter(Boolean) as RouteWithQuote[];
    // Safe to cast, as falsy values are filtered
  }, [supportedRoutes, quotes]);

  // Only routes with quotes are sorted.
  const sortedRoutesWithQuotes = useMemo(() => {
    const sortPriority = config.ui.routeSortPriority || 'fastest';

    return routesWithQuotes.sort((routeA, routeB) => {
      const routeConfigA = config.routes.get(routeA.route);
      const routeConfigB = config.routes.get(routeB.route);

      // Prioritize preferred route to avoid flickering the UI
      // when the preferred route gets autoselected
      if (preferredRouteName) {
        if (routeA.route === preferredRouteName) {
          return -1;
        } else if (routeB.route === preferredRouteName) {
          return 1;
        }
      }

      if (sortPriority === 'cheapest') {
        // 1. Sort by destination amount (cheapest/best output first)
        const destAmountA = BigInt(routeA.quote.destinationToken.amount.amount);
        const destAmountB = BigInt(routeB.quote.destinationToken.amount.amount);
        const amountDiff = Number(destAmountB - destAmountA);
        if (amountDiff !== 0) {
          return amountDiff;
        }

        // 2. If amounts are the same, prioritize automatic routes
        if (routeConfigA.AUTOMATIC_DEPOSIT && !routeConfigB.AUTOMATIC_DEPOSIT) {
          return -1;
        } else if (
          !routeConfigA.AUTOMATIC_DEPOSIT &&
          routeConfigB.AUTOMATIC_DEPOSIT
        ) {
          return 1;
        }

        // 3. If still tied, sort by ETA (fastest first)
        const etaA = routeA.quote.eta ?? Infinity;
        const etaB = routeB.quote.eta ?? Infinity;
        return etaA - etaB;
      } else {
        // Default: 'fastest' sorting
        // 1. Sort by ETA (fastest first)
        const etaA = routeA.quote.eta ?? Infinity;
        const etaB = routeB.quote.eta ?? Infinity;
        if (etaA !== etaB) {
          return etaA - etaB;
        }

        // 2. If ETA is the same, prioritize automatic routes
        if (routeConfigA.AUTOMATIC_DEPOSIT && !routeConfigB.AUTOMATIC_DEPOSIT) {
          return -1;
        } else if (
          !routeConfigA.AUTOMATIC_DEPOSIT &&
          routeConfigB.AUTOMATIC_DEPOSIT
        ) {
          return 1;
        }

        // 3. If still tied, compare destination token amounts
        const destAmountA = BigInt(routeA.quote.destinationToken.amount.amount);
        const destAmountB = BigInt(routeB.quote.destinationToken.amount.amount);
        // Note: Sort callback return strictly expects Number
        // Returning BigInt results in TypeError
        return Number(destAmountB - destAmountA);
      }
    });
  }, [preferredRouteName, routesWithQuotes]);

  const sortedRoutes = useMemo(
    () => sortedRoutesWithQuotes.map((r) => r.route),
    [sortedRoutesWithQuotes],
  );

  return useMemo(
    () => ({
      allSupportedRoutes: supportedRoutes,
      sortedRoutes,
      sortedRoutesWithQuotes,
      quotes,
      failedQuotes,
      isFetching: isFetchingSupportedRoutes || isFetchingQuotes,
    }),
    [
      supportedRoutes,
      sortedRoutes,
      sortedRoutesWithQuotes,
      quotes,
      failedQuotes,
      isFetchingSupportedRoutes,
      isFetchingQuotes,
    ],
  );
};
