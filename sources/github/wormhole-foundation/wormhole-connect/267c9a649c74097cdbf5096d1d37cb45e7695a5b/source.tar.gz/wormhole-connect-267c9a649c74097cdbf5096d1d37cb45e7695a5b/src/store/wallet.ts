import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import type { Platform } from '@wormhole-foundation/sdk';
import { TransferWallet } from 'utils/wallet';
import { ReadOnlyWallet } from 'utils/wallet/ReadOnlyWallet';

export type WalletData = {
  type: Platform | undefined;
  address: string;
  currentAddress: string;
  error: string;
  icon?: string; // the wallet's icon encoded as a base64 string
  name: string;
};

export interface WalletState {
  sending: WalletData;
  receiving: WalletData;
}

const NO_WALLET: WalletData = {
  address: '',
  type: undefined,
  currentAddress: '',
  error: '',
  icon: undefined,
  name: '',
};

const initialState: WalletState = {
  sending: NO_WALLET,
  receiving: NO_WALLET,
};

export type ConnectPayload = {
  address: string;
  type: Platform;
  icon?: string;
  name: string;
};

export const walletSlice = createSlice({
  name: 'wallet',
  initialState,
  reducers: {
    connectWallet: (
      state: WalletState,
      { payload }: PayloadAction<ConnectPayload>,
    ) => {
      state.sending.address = payload.address;
      state.sending.currentAddress = payload.address;
      state.sending.type = payload.type;
      state.sending.name = payload.name;
      state.sending.error = '';
      state.sending.icon = payload.icon;
    },
    connectReceivingWallet: (
      state: WalletState,
      { payload }: PayloadAction<ConnectPayload>,
    ) => {
      state.receiving.address = payload.address;
      state.receiving.currentAddress = payload.address;
      state.receiving.type = payload.type;
      state.receiving.name = payload.name;
      state.receiving.error = '';
      state.receiving.icon = payload.icon;
    },
    clearWallet: (
      state: WalletState,
      { payload }: PayloadAction<TransferWallet>,
    ) => {
      state[payload] = NO_WALLET;
    },
    setWalletError: (
      state: WalletState,
      { payload }: PayloadAction<{ type: TransferWallet; error: string }>,
    ) => {
      const { type, error } = payload;
      state[type].error = error;
    },
    clearWallets: (state: WalletState) => {
      Object.keys(state).forEach((key) => {
        // @ts-ignore
        state[key] = initialState[key];
      });
    },
    swapWallets: (state: WalletState) => {
      const tmp = state.sending;
      state.sending = state.receiving;
      state.receiving = tmp;

      // If the new sending wallet is a ReadOnlyWallet,
      // disconnect it since it can't be used for signing
      if (state.sending.name === ReadOnlyWallet.NAME) {
        state[TransferWallet.SENDING] = NO_WALLET;
      }
    },
  },
});

export const {
  connectWallet,
  connectReceivingWallet,
  clearWallet,
  setWalletError,
  clearWallets,
  swapWallets,
} = walletSlice.actions;

export default walletSlice.reducer;
