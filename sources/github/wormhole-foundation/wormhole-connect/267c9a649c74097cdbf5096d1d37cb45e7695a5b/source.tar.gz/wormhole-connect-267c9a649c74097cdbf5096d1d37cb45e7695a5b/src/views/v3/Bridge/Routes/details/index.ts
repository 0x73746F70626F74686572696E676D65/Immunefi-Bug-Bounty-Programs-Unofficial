export { default } from './RouteDetails';
