import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useMediaQuery, useTheme } from '@mui/material';
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import Stack from '@mui/material/Stack';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import CopyIcon from '@mui/icons-material/ContentCopy';
import DoneIcon from '@mui/icons-material/Done';
import { amount as sdkAmount } from '@wormhole-foundation/sdk';
import type { Chain } from '@wormhole-foundation/sdk';

import AlertBannerV3 from 'components/v3/AlertBanner';
import Button from 'components/v3/Button';
import FooterNavBar from 'components/FooterNavBar';
import config from 'config';
import type { Token } from 'config/tokens';
import { useTokens } from 'contexts/TokensContext';
import useComputeDestinationTokens from 'hooks/useComputeDestinationTokens';
import { useSortedRoutesWithQuotes } from 'hooks/useSortedRoutesWithQuotes';
import { useAmountValidation } from 'hooks/useAmountValidation';
import useConfirmTransaction from 'hooks/useConfirmTransaction';
import { useGetTokens } from 'hooks/useGetTokens';
import useGetTokenBalances from 'hooks/useGetTokenBalances';
import { useWalletCompatibility } from 'hooks/useWalletCompatibility';
import useConnectToLastUsedWallet from 'hooks/useConnectToLastUsedWallet';
import { useAutoEnableGasDropOff } from 'hooks/useAutoEnableGasDropoff';
import PoweredByIcon from 'icons/PoweredBy';
import type { RootState } from 'store';
import {
  selectFromChain,
  selectToChain,
  setToken,
  setDestToken,
  setTransferRoute,
  clearToken,
  clearDestToken,
  setAmount,
} from 'store/transferInput';
import { copyTextToClipboard } from 'utils';
import { isTransferValid, useValidate } from 'utils/transferValidation';
import { TransferWallet } from 'utils/wallet';
import { getFilteredChains } from 'utils/sdkv2';
import { applyTokenWhitelist } from 'utils/tokenListUtils';
import WalletConnector from 'views/v3/Bridge/WalletConnector';
import AssetPicker from 'views/v3/Bridge/AssetPicker';
import Routes from 'views/v3/Bridge/Routes';
import SwapInputs from 'views/v3/Bridge/SwapInputs';
import BridgeTitle from 'views/v3/Bridge/BridgeTitle';
import AmountValidationError from './AmountValidationError';
import TxHistory from '../TxHistory';
import { setToNativeToken } from 'store/relay';
import { FormContent } from 'components/v3/FormContent';

export type BridgeProps = {
  showHistory?: boolean;
};

function Bridge(props: BridgeProps) {
  const theme: any = useTheme();
  const dispatch = useDispatch();

  const [showHistory, setShowHistory] = useState(props.showHistory ?? false);
  const [hasUserManuallyChangedGas, setHasUserManuallyChangedGas] =
    useState(false);

  const { lastTokenCacheUpdate } = useTokens();
  const [errorCopied, setErrorCopied] = useState(false);

  const mobile = useMediaQuery(theme.breakpoints.down('sm'));

  const popoverAnchorRef = useRef<HTMLElement>(null);

  const styles = useMemo(
    () => ({
      bridgeContent: {
        margin: 'auto',
        maxWidth: '488px',
      },
      doneIcon: {
        fontSize: '14px',
        color: theme.palette.success.main,
      },
      copyIcon: {
        fontSize: '14px',
      },
      ctaContainer: {
        width: '100%',
      },
    }),
    [theme.palette.success.main],
  );

  // Connected wallets, if any
  const { sending: sendingWallet, receiving: receivingWallet } = useSelector(
    (state: RootState) => state.wallet,
  );

  const {
    fromChain: sourceChain,
    toChain: destChain,
    route,
    preferredRouteName,
    amount,
    toNativeToken,
    isTransactionInProgress,
    validations,
  } = useSelector((state: RootState) => ({
    ...state.transferInput,
    ...state.relay,
  }));

  const { sourceToken, destToken } = useGetTokens();
  const isSameChainSwap = sourceChain === destChain;

  const {
    allSupportedRoutes,
    sortedRoutes,
    sortedRoutesWithQuotes,
    quotes,
    failedQuotes,
    isFetching: isFetchingQuotes,
  } = useSortedRoutesWithQuotes({
    amount,
    fromChain: sourceChain,
    toChain: destChain,
    preferredRouteName,
    sourceToken,
    destToken,
    toNativeToken,
    sendingWallet,
    receivingWallet,
  });

  const { isFetching: isFetchingSupportedDestTokens, supportedDestTokens } =
    useComputeDestinationTokens({
      sourceChain,
      destChain,
      sourceToken,
    });

  const {
    error: txError,
    errorInternal: txErrorInternal,
    info: txInfo,
    onConfirm,
  } = useConfirmTransaction({ quotes });

  // Set selectedRoute if the route is auto-selected
  // After the auto-selection, we set selectedRoute when user clicks on a route in the list
  useEffect(() => {
    if (sortedRoutesWithQuotes.length === 0) {
      dispatch(setTransferRoute(''));
    } else {
      const preferredRoute = sortedRoutesWithQuotes.find(
        (route) => route.route === preferredRouteName,
      );
      const autoselectedRoute =
        route ?? preferredRoute?.route ?? sortedRoutesWithQuotes[0].route;

      const isSelectedRouteValid =
        sortedRoutesWithQuotes.findIndex((r) => r.route === autoselectedRoute) >
        -1;

      if (!isSelectedRouteValid) {
        dispatch(setTransferRoute(''));
      }

      // If no route is autoselected or we already have a valid selected route,
      // we should avoid overwriting it
      if (!autoselectedRoute || (route && isSelectedRouteValid)) {
        return;
      }

      const routeData = sortedRoutesWithQuotes?.find(
        (rs) => rs.route === autoselectedRoute,
      );

      if (routeData) dispatch(setTransferRoute(routeData.route));
    }
  }, [preferredRouteName, route, sortedRoutesWithQuotes, dispatch]);

  // Connect to any previously used wallets for the selected networks
  const { isConnecting: isConnectingWallet } = useConnectToLastUsedWallet(
    sourceChain,
    destChain,
    sendingWallet,
    receivingWallet,
  );

  // Call to initiate transfer inputs validations
  useValidate();

  // Get input validation result
  const isValid = useMemo(() => isTransferValid(validations), [validations]);

  // All supported chains from the given configuration and any custom override
  const supportedChains = useMemo(
    () => config.routes.allSupportedChains(),
    // Disabled because we're using the global cache and we have to monitor values that aren't directly used in this hook
    // Include config.routes to ensure updates when routes change dynamically (e.g., NTT config loading)
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [config.chains, config.routes],
  );

  const sourceTokens = useMemo(() => {
    if (sourceChain) {
      const allTokens = config.tokens.getAllForChain(sourceChain);
      const chainConfig = config.chains[sourceChain];
      return chainConfig
        ? applyTokenWhitelist(allTokens, chainConfig)
        : allTokens;
    } else {
      return [];
    }
    // Disabled because we're using the global cache and we have to monitor values that aren't directly used in this hook
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceChain, lastTokenCacheUpdate]);

  // Supported chains for the source network
  const supportedSourceChains = useMemo(() => {
    return getFilteredChains(supportedChains, destChain, true);
  }, [destChain, supportedChains]);

  // Supported chains for the destination network
  const supportedDestChains = useMemo(() => {
    return getFilteredChains(supportedChains, sourceChain);
  }, [sourceChain, supportedChains]);

  // Build balance requests for source and destination
  const sourceBalanceRequest = useMemo(() => {
    if (sourceChain && sendingWallet?.address) {
      return {
        chain: sourceChain,
        wallet: sendingWallet,
        tokens: sourceTokens,
      };
    }
    return undefined;
  }, [sourceChain, sendingWallet, sourceTokens]);

  const destBalanceRequest = useMemo(() => {
    if (destChain && receivingWallet?.address) {
      const allTokens = config.tokens.getAllForChain(destChain);
      const chainConfig = config.chains[destChain];
      const tokens = chainConfig
        ? applyTokenWhitelist(allTokens, chainConfig)
        : allTokens;
      return {
        chain: destChain,
        wallet: receivingWallet,
        tokens,
      };
    }
    return undefined;
  }, [destChain, receivingWallet]);

  const balances = useGetTokenBalances({
    source: sourceBalanceRequest,
    destination: destBalanceRequest,
  });

  // Reset manual gas change flag on destination chain change
  useEffect(() => {
    setHasUserManuallyChangedGas(false);
  }, [destChain]);

  // Auto-set nativeGas when destination native balance is zero
  // and user has not manually changed gas setting
  useAutoEnableGasDropOff({
    route,
    destChain,
    receivingWalletAddress: receivingWallet?.address,
    destinationBalances: balances.destination.balances,
    hasUserManuallyChangedGas,
    currentToNativeToken: toNativeToken,
    isFetchingBalances: balances.isFetching,
    allowedChains: config.ui.autoEnableGasDropOffChains,
  });

  // Validate amount
  const amountValidation = useAmountValidation({
    balance: sourceToken
      ? balances.source.balances[sourceToken.key]?.balance
      : null,
    routes: allSupportedRoutes,
    quotes,
    failedQuotes,
    tokenSymbol: sourceToken?.symbol ?? '',
    isLoading: balances.isFetching || isFetchingQuotes,
    disabled: !sourceChain || !sourceToken,
  });

  // Handlers for source asset picker
  const handleSourceChainChange = useCallback(
    (value: Chain) => {
      selectFromChain(dispatch, value, sendingWallet);
      dispatch(clearToken());
      dispatch(setToNativeToken(0));
    },
    [dispatch, sendingWallet],
  );

  const handleSourceTokenChange = useCallback(
    (value: Token) => {
      dispatch(setToken(value.tuple));
      dispatch(setToNativeToken(0));
      dispatch(setAmount(''));
    },
    [dispatch],
  );

  // Handlers for destination asset picker
  const handleDestChainChange = useCallback(
    (value: Chain) => {
      selectToChain(dispatch, value, receivingWallet);
      dispatch(clearDestToken());
      dispatch(setToNativeToken(0));
    },
    [dispatch, receivingWallet],
  );

  const handleDestTokenChange = useCallback(
    (value: Token) => {
      dispatch(setDestToken(value.tuple));
      dispatch(setToNativeToken(0));
    },
    [dispatch],
  );

  // Quote result for destination picker
  const destQuoteResult = quotes && route ? quotes[route] : undefined;

  // Handler for history toggle
  const handleHistoryToggle = useCallback(() => {
    setShowHistory((value) => {
      // Log event when opening history
      if (!value) {
        config.triggerEvent({
          type: 'history.load',
          details: {
            wallet: sendingWallet?.address,
          },
        });
      }
      return !value;
    });
  }, [sendingWallet?.address]);
  // Handler for route change
  const handleRouteChange = useCallback(
    (r: string) => {
      dispatch(setTransferRoute(r));
    },
    [dispatch],
  );

  // Handler for manual gas changes
  const handleManualGasChange = useCallback(() => {
    setHasUserManuallyChangedGas(true);
  }, []);

  // Determine which wallet connector to show
  const walletConnectorProps = useMemo(() => {
    if (sendingWallet?.address && receivingWallet?.address) {
      return null;
    }
    if (sendingWallet?.address && !receivingWallet?.address) {
      return {
        disabled: !destChain,
        side: 'destination' as const,
        type: TransferWallet.RECEIVING,
      };
    }
    return {
      disabled: !sourceChain,
      side: 'source' as const,
      type: TransferWallet.SENDING,
    };
  }, [
    sendingWallet?.address,
    receivingWallet?.address,
    destChain,
    sourceChain,
  ]);

  const { isCompatible: isWalletCompatible } = useWalletCompatibility({
    sendingWallet,
    receivingWallet,
    sourceChain,
    destChain,
    routes: sortedRoutes,
  });

  const transactionError = useMemo(() => {
    if (!txError) {
      return null;
    }

    return (
      <Box sx={{ marginBottom: 2 }}>
        <AlertBannerV3 error testId="send-error-message">
          {txError}
        </AlertBannerV3>
        {txErrorInternal && txErrorInternal.message && config.ui.getHelpUrl ? (
          <Typography fontSize={14} sx={{ marginTop: 1 }}>
            Having trouble?{' '}
            <a
              href="#"
              onClick={() => {
                copyTextToClipboard(txErrorInternal.message);
                setErrorCopied(true);
                setTimeout(() => setErrorCopied(false), 3000);
              }}
            >
              Copy the error logs{' '}
              {errorCopied ? (
                <DoneIcon sx={styles.doneIcon} />
              ) : (
                <CopyIcon sx={styles.copyIcon} />
              )}
            </a>
            {' and '}
            <a href={config.ui.getHelpUrl} target="_blank" rel="noreferrer">
              ask for help
            </a>
            .
          </Typography>
        ) : null}
      </Box>
    );
  }, [styles.copyIcon, styles.doneIcon, errorCopied, txError, txErrorInternal]);

  const transactionInfo = useMemo(() => {
    if (!txInfo) {
      return null;
    }

    return <AlertBannerV3>{txInfo}</AlertBannerV3>;
  }, [txInfo]);

  const hasEnteredAmount = amount && sdkAmount.whole(amount) > 0;
  const hasConnectedWallets = sendingWallet.address && receivingWallet.address;

  const confirmTransactionDisabled =
    !sourceChain ||
    !sourceToken ||
    !destChain ||
    !destToken ||
    !hasConnectedWallets ||
    !isWalletCompatible ||
    !route ||
    !isValid ||
    isFetchingQuotes ||
    !hasEnteredAmount ||
    isTransactionInProgress ||
    !!amountValidation.error;

  // Review transaction button is shown only when everything is ready
  const confirmTransactionButton = useMemo(() => {
    return (
      <Button
        disabled={confirmTransactionDisabled}
        data-testid="confirm-transaction-button"
        aria-label="Confirm transaction"
        variant="primary"
        onClick={() => onConfirm()}
      >
        {isTransactionInProgress ? (
          <Typography
            display="flex"
            alignItems="center"
            gap={1}
            textTransform="none"
          >
            <CircularProgress color="inherit" size={16} thickness={4} />
            {mobile ? 'Preparing' : 'Preparing transaction'}
          </Typography>
        ) : !isTransactionInProgress && isFetchingQuotes ? (
          <Typography
            display="flex"
            alignItems="center"
            gap={1}
            textTransform="none"
          >
            <CircularProgress color="inherit" size={16} thickness={4} />
            {mobile ? 'Refreshing' : 'Refreshing quote'}
          </Typography>
        ) : (
          <Typography textTransform="none">
            {mobile ? 'Confirm' : 'Confirm transaction'}
          </Typography>
        )}
      </Button>
    );
  }, [
    confirmTransactionDisabled,
    isTransactionInProgress,
    mobile,
    isFetchingQuotes,
    onConfirm,
  ]);

  // Show routes only when we have source and destination assets and an amount
  const showRoutes = hasEnteredAmount && sourceToken && destToken;

  const confirmButtonTooltip =
    !sourceChain || !sourceToken
      ? 'Please select a source asset'
      : !destChain || !destToken
      ? 'Please select a destination asset'
      : !hasEnteredAmount
      ? 'Please enter an amount'
      : isFetchingQuotes
      ? 'Loading quotes...'
      : !route
      ? 'Please select a quote'
      : '';

  const bridgeContent = (
    <>
      <BridgeTitle
        showHistory={showHistory}
        onToggleHistory={handleHistoryToggle}
        isTransactionInProgress={isTransactionInProgress}
        isWalletConnected={!!sendingWallet?.address}
      />
      {showHistory ? (
        <TxHistory />
      ) : (
        <>
          <Stack sx={{ gap: '4px', position: 'relative' }}>
            {/* Source asset picker */}
            <Box ref={popoverAnchorRef}>
              <AssetPicker
                chain={sourceChain}
                chainList={supportedSourceChains}
                token={sourceToken}
                destToken={destToken}
                tokenList={sourceTokens}
                setChain={handleSourceChainChange}
                setToken={handleSourceTokenChange}
                wallet={sendingWallet}
                isSameChainSwap={isSameChainSwap}
                isSource={true}
                isTransactionInProgress={isTransactionInProgress}
                dataTestId="source-asset-picker"
                isConnectingWallet={isConnectingWallet}
                balances={balances.source.balances}
                isFetchingBalances={balances.isFetching}
                anchorEl={popoverAnchorRef.current}
                amountValidation={amountValidation}
              />
            </Box>
            {/* Swap source/destination assets button */}
            {!config.ui.hideSwapInputs && <SwapInputs />}
            {/* Destination asset picker */}
            <AssetPicker
              chain={destChain}
              chainList={supportedDestChains}
              token={destToken}
              sourceToken={sourceToken}
              tokenList={supportedDestTokens}
              isFetchingQuotes={isFetchingQuotes}
              isFetchingTokens={
                supportedDestTokens.length === 0 &&
                isFetchingSupportedDestTokens
              }
              setChain={handleDestChainChange}
              setToken={handleDestTokenChange}
              wallet={receivingWallet}
              isSameChainSwap={isSameChainSwap}
              isSource={false}
              isTransactionInProgress={isTransactionInProgress}
              dataTestId="dest-asset-picker"
              isConnectingWallet={isConnectingWallet}
              balances={balances.destination.balances}
              isFetchingBalances={balances.isFetching}
              quote={destQuoteResult?.success ? destQuoteResult : undefined}
              anchorEl={popoverAnchorRef.current}
            />
          </Stack>
          <Box component="span" sx={styles.ctaContainer}>
            {hasConnectedWallets ? (
              <Tooltip title={confirmButtonTooltip}>
                <span>{confirmTransactionButton}</span>
              </Tooltip>
            ) : walletConnectorProps ? (
              <WalletConnector {...walletConnectorProps} />
            ) : null}
          </Box>
          {transactionError}
          {transactionInfo}
          <AmountValidationError validation={amountValidation} />
        </>
      )}
    </>
  );

  return (
    <Box sx={{ ...styles.bridgeContent }}>
      <FormContent>{bridgeContent}</FormContent>
      {!showHistory && (
        <Box sx={{ marginTop: '12px', width: '100%' }}>
          {showRoutes && (
            <Routes
              routes={sortedRoutes}
              selectedRoute={route}
              onRouteChange={handleRouteChange}
              quotes={quotes}
              isLoading={isFetchingQuotes}
              onManualGasChange={handleManualGasChange}
            />
          )}
        </Box>
      )}
      {config.ui.showFooter && (
        <>
          <PoweredByIcon color={theme.palette.text.primary} />
          <FooterNavBar />
        </>
      )}
    </Box>
  );
}

export default React.memo(Bridge);
