import { amount as sdkAmount } from '@wormhole-foundation/sdk';
import { useMemo } from 'react';
import { useSelector } from 'react-redux';
import type { QuoteResult } from 'routes/operator';
import type { RootState } from 'store';
import { formatMinAmount } from 'utils/formatNumber';
import { isMinAmountError } from 'utils/sdkv2';

export type AmountValidationResult = {
  error?: string;
  warning?: string;
  info?: string;
};

type Props = {
  balance?: sdkAmount.Amount | null;
  routes: string[];
  quotes: Record<string, QuoteResult | undefined>;
  failedQuotes: Record<string, QuoteResult | undefined>;
  tokenSymbol: string;
  isLoading: boolean;
  disabled?: boolean;
};

export const useAmountValidation = (props: Props): AmountValidationResult => {
  const { amount } = useSelector((state: RootState) => state.transferInput);

  // Min amount available
  const minAmount = useMemo(
    () =>
      Object.values(props.failedQuotes).reduce((minAmount, quoteResult) => {
        if (quoteResult?.success) {
          return minAmount;
        }

        if (!isMinAmountError(quoteResult?.error)) {
          return minAmount;
        }

        if (!minAmount) {
          return quoteResult.error.min;
        }

        const minAmountNum = BigInt(quoteResult.error.min.amount);
        const existingMin = BigInt(minAmount.amount);
        if (minAmountNum < existingMin) {
          return quoteResult.error.min;
        } else {
          return minAmount;
        }
      }, undefined as sdkAmount.Amount | undefined),
    [props.failedQuotes],
  );

  const allRoutesFailed = useMemo(() => {
    return (
      Object.keys(props.quotes).length === 0 &&
      Object.keys(props.failedQuotes).length > 0
    );
  }, [props.quotes, props.failedQuotes]);

  // Don't show errors when no amount is set or it's loading
  if (!amount || props.disabled) {
    return {};
  }

  // Balance errors
  if (props.balance) {
    if (sdkAmount.units(amount) > sdkAmount.units(props.balance)) {
      return {
        error: 'Amount exceeds available balance.',
      };
    }
  }

  if (allRoutesFailed) {
    if (minAmount) {
      const formattedAmount = formatMinAmount(minAmount);
      return {
        error: `Amount too small (min ~${formattedAmount} ${props.tokenSymbol})`,
      };
    } else {
      return {
        error: 'No route available.',
      };
    }
  }

  // MinQuote warnings information
  if (minAmount) {
    const formattedAmount = formatMinAmount(minAmount);
    return {
      info: `More routes available for ${formattedAmount} ${props.tokenSymbol} or more.`,
    };
  }

  return {};
};
