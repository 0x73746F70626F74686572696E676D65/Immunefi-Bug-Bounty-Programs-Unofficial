import { getWormholeContextV2 } from 'config';
import type { RelayerFee } from 'store/relay';
import type {
  Chain,
  AttestedTransferReceipt,
  RedeemedTransferReceipt,
  DestinationQueuedTransferReceipt,
  CompletedTransferReceipt,
  TokenBridge,
  Network,
  routes,
  CircleTransfer,
  ChainContext,
  ExecutorTokenBridge,
  TokenId,
} from '@wormhole-foundation/sdk';
import {
  Wormhole,
  amount,
  circle,
  nativeTokenId,
  TBTCBridge,
} from '@wormhole-foundation/sdk';
import type { NttRoute } from '@wormhole-foundation/sdk-route-ntt';
import type { MultiTokenNttRoute } from '@wormhole-foundation/sdk-route-ntt';
import type { CCTPv2ExecutorRoute } from '@wormhole-labs/cctp-executor-route';
import type { BaseBridgeExecutorRoute } from '@wormhole-labs/base-bridge-executor-route';
import { Connection } from '@solana/web3.js';
import { PublicKey } from '@solana/web3.js';
import * as splToken from '@solana/spl-token';
import config from 'config';
import { WORMSCAN } from 'config/constants';
import type { TokenTuple } from 'config/tokens';
import type { Token } from 'config/tokens';
import { isExecutorRoute } from 'utils';
import { isHyperCoreChain } from './hypercore';
import { isSvmChain } from './solana';

// Used to represent an initiated transfer. Primarily for the Redeem view.
export interface TransferInfo {
  // Transaction hash
  sendTx: string;

  // Stringified addresses
  sender?: string;
  recipient: string;

  amount: amount.Amount;

  toChain: Chain;
  fromChain: Chain;

  // Source token address
  tokenAddress: string;
  token: TokenTuple;
  tokenDecimals: number;

  // Destination token
  receivedToken: TokenTuple;
  receiveAmount?: amount.Amount;
  relayerFee?: RelayerFee;

  // Amount of native gas being received, in destination gas token units
  receiveNativeAmount?: amount.Amount;

  // ETA for the route this transfer was initiated on
  eta?: number;
}

export type ExplorerInfo = {
  url: string;
  name: string;
};

export function getWormholescanExplorerInfo(txHash: string): ExplorerInfo {
  return {
    url: `${WORMSCAN}tx/${txHash}${config.isMainnet ? '' : '?network=TESTNET'}`,
    name: 'Wormholescan',
  };
}

export function getAxelarscanExplorerInfo(txHash: string): ExplorerInfo {
  return {
    url: `https://${
      config.isMainnet ? '' : 'testnet.'
    }axelarscan.io/gmp/${txHash}`,
    name: 'Axelarscan',
  };
}

// List of chains that we use the USDC.range explorer for
// TODO Remove once Wormholescan explorer supports these chains
const rangeExplorerChains: Array<Chain> = ['Linea', 'Sonic'];

// TODO SDKV2 add a way for the Route interface to offer this
export function getExplorerInfos(
  route: string | routes.Route<Network>,
  txHash: string,
  fromChain: Chain,
  toChain: Chain,
): Array<ExplorerInfo> {
  const routeName =
    typeof route === 'string'
      ? route
      : (route.constructor as routes.RouteConstructor).meta.name;

  if (routeName.startsWith('MayanSwap')) {
    return [
      {
        url: `https://explorer.mayan.finance/swap/${txHash}`,
        name: 'Mayan Explorer',
      },
    ];
  } else if (routeName === 'LiFi') {
    return [
      {
        url: `https://scan.li.fi/tx/${txHash}`,
        name: 'Li.Fi SCAN',
      },
    ];
  } else if (routeName.includes('MonadBridge')) {
    return [
      getWormholescanExplorerInfo(txHash),
      getAxelarscanExplorerInfo(txHash),
    ];
  } else if (
    isExecutorRoute(routeName) &&
    (rangeExplorerChains.includes(fromChain) ||
      rangeExplorerChains.includes(toChain))
  ) {
    // TODO Remove once Wormholescan explorer supports chains in rangeExplorerChains
    // USDC.range supports Mainnet only
    return [
      {
        url: config.isMainnet
          ? `https://usdc.range.org/usdc/status/${txHash}`
          : '',
        name: 'USDC.range Explorer',
      },
    ];
  } else if (routeName === 'BaseBridgeRoute') {
    // Base Bridge transactions are not indexed on Wormholescan yet
    return [];
  } else {
    return [getWormholescanExplorerInfo(txHash)];
  }
}

type ReceiptWithAttestation<AT> =
  | AttestedTransferReceipt<AT>
  | RedeemedTransferReceipt<AT>
  | DestinationQueuedTransferReceipt<AT>
  | CompletedTransferReceipt<AT>;

// `parseReceipt` is used when we resume a transaction to get the transaction details
// from the VAA. Each protocol has different data in its VAAs and this parses them
// into the common internal format used by Connect: `TransferInfo`
//
// TODO SDKV2 this should probably not live in Connect.
// SDKV2 should provide a TransferInfo type and Routes should each be able to
// parse their own attestation into this type.
//
// Connect should never have to look inside of an attestation - that's too low-level.
export async function parseReceipt(
  route: string,
  receipt: ReceiptWithAttestation<any>,
  getOrFetchToken: (tokenId: TokenId) => Promise<Token | undefined>,
): Promise<TransferInfo | null> {
  switch (route) {
    case 'ManualTokenBridge':
      return await parseTokenBridgeReceipt(
        receipt as ReceiptWithAttestation<TokenBridge.TransferVAA>,
      );
    case 'TokenBridgeExecutorRoute':
      return await parseExecutorTokenBridgeReceipt(
        receipt as ReceiptWithAttestation<ExecutorTokenBridge.VAA>,
      );
    case 'ManualCCTP':
      return await parseCCTPReceipt(
        receipt as ReceiptWithAttestation<CircleTransfer.CircleAttestationReceipt>,
      );
    case 'ManualNtt':
    case 'NttExecutorRoute':
      return parseNttReceipt(
        receipt as ReceiptWithAttestation<NttRoute.ManualAttestationReceipt> & {
          params: NttRoute.ValidatedParams;
        },
      );
    case 'ManualTBTC':
      return parseTBTCReceipt(
        receipt as ReceiptWithAttestation<TBTCBridge.VAA>,
      );
    case 'CCTPv2StandardExecutorRoute':
    case 'CCTPv2FastExecutorRoute':
      return parseCCTPv2Receipt(
        receipt as ReceiptWithAttestation<CCTPv2ExecutorRoute.Attestation>,
      );
    case 'MonadBridgeManualRoute':
    case 'MonadBridgeExecutorRoute':
      return await parseMultiTokenNttReceipt(
        receipt as ReceiptWithAttestation<MultiTokenNttRoute.AttestationReceipt> & {
          params: MultiTokenNttRoute.ValidatedParams;
        },
        getOrFetchToken,
      );
    case 'BaseBridgeRoute':
      return parseBaseBridgeReceipt(
        receipt as ReceiptWithAttestation<BaseBridgeExecutorRoute.Attestation>,
      );
    default:
      throw new Error(`Unknown route type ${route}`);
  }
}

const parseTokenBridgeReceipt = async (
  receipt: ReceiptWithAttestation<TokenBridge.TransferVAA>,
): Promise<TransferInfo> => {
  const txData: Partial<TransferInfo> = {
    toChain: receipt.to,
    fromChain: receipt.from,
  };

  if ('originTxs' in receipt && receipt.originTxs.length > 0) {
    txData.sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  /* @ts-ignore */
  // TODO typescript is complaining about the second attestation property not existing when it does
  const { payload } = receipt.attestation.attestation;

  if (!payload.token) {
    throw new Error(`Attestation is missing token.`);
  }

  if (payload.token) {
    const wh = await getWormholeContextV2();
    const fromChain = wh.getChain(receipt.from);
    const toChain = wh.getChain(receipt.to);

    const sourceToken = await getTokenBridgeToken(fromChain, payload.token);
    if (!sourceToken) throw new Error(`Unknown source token`);

    const destinationToken = await getTokenBridgeToken(toChain, payload.token);
    if (!destinationToken) throw new Error(`Unknown destination token`);

    txData.tokenDecimals = sourceToken.decimals;
    txData.amount = amount.fromBaseUnits(
      payload.token.amount,
      // VAAs are truncated to a max of 8 decimal places
      Math.min(8, sourceToken.decimals),
    );
    txData.tokenAddress = sourceToken.address.toString();
    txData.token = sourceToken.tuple;
    txData.receivedToken = destinationToken.tuple;
    txData.receiveAmount = txData.amount;
  }

  if (payload.to) {
    if (isSvmChain(receipt.to)) {
      const rpcUrl = config.rpcs[receipt.to];
      if (!rpcUrl) {
        throw new Error(`Missing ${receipt.to} RPC`);
      }
      // the recipient on the VAA is the ATA
      const ata = payload.to.address.toNative(receipt.to).toString();
      const connection = new Connection(rpcUrl);
      try {
        const account = await splToken.getAccount(
          connection,
          new PublicKey(ata),
        );
        txData.recipient = account.owner.toBase58();
      } catch (e) {
        console.error(e);
        txData.recipient = ata;
      }
    } else {
      txData.recipient = payload.to.address.toNative(receipt.to).toString();
    }
  }

  return txData as TransferInfo;
};

const parseExecutorTokenBridgeReceipt = async (
  receipt: ReceiptWithAttestation<ExecutorTokenBridge.VAA>,
): Promise<TransferInfo> => {
  const txData = await parseTokenBridgeReceipt(
    // This is fine since the VAA type is transfer with payload
    receipt as unknown as ReceiptWithAttestation<TokenBridge.TransferVAA>,
  );

  txData.recipient =
    // @ts-ignore
    receipt.attestation.attestation.payload.payload.targetRecipient
      .toNative(txData.toChain)
      .toString();

  return txData;
};

const parseCCTPReceipt = async (
  receipt: ReceiptWithAttestation<CircleTransfer.CircleAttestationReceipt>,
): Promise<TransferInfo> => {
  const txData: Partial<TransferInfo> = {
    toChain: receipt.to,
    fromChain: receipt.from,
  };

  if ('originTxs' in receipt && receipt.originTxs.length > 0) {
    txData.sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  if (!receipt.attestation.attestation) {
    throw new Error(`Missing Circle attestation`);
  }

  const { payload } = receipt.attestation.attestation.message;

  const sourceTokenId = Wormhole.tokenId(
    receipt.from,
    receipt.from === 'Sui'
      ? // The `burnToken` from Sui is the keccak256 hash of the USDC token address,
        // so we need to override it with the actual USDC address
        circle.usdcContract.get(config.network, receipt.from)!
      : payload.burnToken.toNative(receipt.from).toString(),
  );
  const usdcLegacy = config.tokens.get(sourceTokenId);

  if (!usdcLegacy) {
    throw new Error(`Couldn't find USDC for source chain`);
  }

  txData.tokenAddress = sourceTokenId.address.toString();
  txData.token = usdcLegacy.tuple;
  txData.tokenDecimals = usdcLegacy.decimals;
  txData.amount = amount.fromBaseUnits(payload.amount, usdcLegacy.decimals);
  txData.receiveAmount = txData.amount;

  txData.sender = payload.messageSender.toNative(receipt.from).toString();
  if (isSvmChain(receipt.to)) {
    const rpcUrl = config.rpcs[receipt.to];
    if (!rpcUrl) {
      throw new Error(`Missing ${receipt.to} RPC`);
    }
    // the recipient on the VAA is the ATA
    const ata = payload.mintRecipient.toNative(receipt.to).toString();
    const connection = new Connection(rpcUrl);
    try {
      const account = await splToken.getAccount(connection, new PublicKey(ata));
      txData.recipient = account.owner.toBase58();
    } catch (e) {
      console.error(e);
      txData.recipient = ata;
    }
  } else {
    txData.recipient = payload.mintRecipient.toNative(receipt.to).toString();
  }

  // The attestation doesn't have the destination token address, but we can deduce which it is
  // just based off the destination chain
  if (txData.toChain) {
    const usdcContract = circle.usdcContract.get(
      config.network,
      txData.toChain,
    );
    if (!usdcContract) {
      throw new Error(`Couldn't find USDC for destination chain`);
    }
    const destinationUsdcLegacy = config.tokens.get(
      txData.toChain,
      usdcContract,
    );
    if (!destinationUsdcLegacy) {
      throw new Error(`Couldn't find USDC for destination chain`);
    }

    txData.receivedToken = destinationUsdcLegacy.tuple;
  }

  return txData as TransferInfo;
};

const parseNttReceipt = (
  receipt: ReceiptWithAttestation<
    NttRoute.ManualAttestationReceipt | NttRoute.AutomaticAttestationReceipt
  > & {
    params: NttRoute.ValidatedParams;
  },
): TransferInfo => {
  let sendTx = '';
  if ('originTxs' in receipt && receipt.originTxs.length > 0) {
    sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  const srcTokenIdV2 = Wormhole.tokenId(
    receipt.from,
    receipt.params.normalizedParams.sourceContracts.token,
  );
  const srcToken = config.tokens.get(srcTokenIdV2);
  if (!srcToken) {
    // This is a token Connect is not aware of
    throw new Error('Unknown src token');
  }

  const dstTokenIdV2 = Wormhole.tokenId(
    receipt.to,
    receipt.params.normalizedParams.destinationContracts.token,
  );
  const dstToken = config.tokens.get(dstTokenIdV2);
  if (!dstToken) {
    // This is a token Connect is not aware of
    throw new Error('Unknown dst token');
  }

  const { attestation } = receipt.attestation;
  const { payload } =
    attestation.payloadName === 'WormholeTransfer'
      ? attestation
      : attestation.payload;
  const { trimmedAmount } = payload.nttManagerPayload.payload;
  const amt = amount.fromBaseUnits(
    trimmedAmount.amount,
    trimmedAmount.decimals,
  );
  return {
    toChain: receipt.to,
    fromChain: receipt.from,
    sendTx,
    sender: payload.nttManagerPayload.sender.toNative(receipt.from).toString(),
    recipient: payload.nttManagerPayload.payload.recipientAddress
      .toNative(receipt.to)
      .toString(),
    amount: amt,
    tokenAddress: srcToken.tokenId!.address.toString(),
    token: srcToken.tuple,
    tokenDecimals: trimmedAmount.decimals,
    receivedToken: dstToken.tuple,
    receiveAmount: amt,
    relayerFee: undefined, // TODO: how to get?
  };
};

const parseTBTCReceipt = async (
  receipt: ReceiptWithAttestation<TBTCBridge.VAA>,
): Promise<TransferInfo> => {
  const txData: Partial<TransferInfo> = {
    toChain: receipt.to,
    fromChain: receipt.from,
  };

  if ('originTxs' in receipt && receipt.originTxs.length > 0) {
    txData.sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  /* @ts-ignore */
  // TODO typescript is complaining about the second attestation property not existing when it does
  const { payload } = receipt.attestation.attestation;

  if (!payload.token) {
    throw new Error(`Attestation is missing token.`);
  }

  const wh = await getWormholeContextV2();
  const fromChain = wh.getChain(receipt.from);
  const toChain = wh.getChain(receipt.to);

  const getToken = async (context: ChainContext<Network>, token: any) => {
    const nativeTbtc = TBTCBridge.getNativeTbtcToken(context.chain);
    if (nativeTbtc) {
      return config.tokens.get(nativeTbtc);
    }

    return await getTokenBridgeToken(context, token);
  };

  const sourceToken = await getToken(fromChain, payload.token);
  if (!sourceToken) throw new Error(`Unknown source token`);

  const destinationToken = await getToken(toChain, payload.token);
  if (!destinationToken) throw new Error(`Unknown destination token`);

  txData.tokenDecimals = sourceToken.decimals;
  txData.amount = amount.fromBaseUnits(
    payload.token.amount,
    // VAAs are truncated to a max of 8 decimal places
    Math.min(8, sourceToken.decimals),
  );
  txData.tokenAddress = sourceToken.address.toString();
  txData.token = sourceToken.tuple;
  txData.receivedToken = destinationToken.tuple;
  txData.receiveAmount = txData.amount;

  // payload3 or normal token bridge transfer
  txData.recipient = (payload.payload?.recipient ?? payload.to.address)
    .toNative(receipt.to)
    .toString();

  return txData as TransferInfo;
};

const parseCCTPv2Receipt = async (
  receipt: ReceiptWithAttestation<CCTPv2ExecutorRoute.Attestation>,
): Promise<TransferInfo> => {
  const txData: Partial<TransferInfo> = {
    toChain: receipt.to,
    fromChain: receipt.from,
  };

  if ('originTxs' in receipt && receipt.originTxs.length > 0) {
    txData.sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  if (!receipt.attestation.attestation) {
    throw new Error(`Missing Circle attestation`);
  }

  const { messageBody } = receipt.attestation.attestation.message;

  const sourceTokenId = Wormhole.tokenId(
    receipt.from,
    messageBody.burnToken.toNative(receipt.from).toString(),
  );
  const sourceToken = config.tokens.get(sourceTokenId);

  if (!sourceToken) {
    throw new Error(`Couldn't find USDC for source chain`);
  }

  txData.tokenAddress = sourceTokenId.address.toString();
  txData.token = sourceToken.tuple;
  txData.tokenDecimals = sourceToken.decimals;
  txData.amount = amount.fromBaseUnits(
    messageBody.amount,
    sourceToken.decimals,
  );
  txData.receiveAmount = txData.amount;

  // NOTE: the sender is the shim contract, not the user's wallet
  // so don't set that here

  if (isSvmChain(receipt.to)) {
    const rpcUrl = config.rpcs[receipt.to];
    if (!rpcUrl) {
      throw new Error(`Missing ${receipt.to} RPC`);
    }
    // the recipient on the VAA is the ATA
    const ata = messageBody.mintRecipient.toNative(receipt.to).toString();
    const connection = new Connection(rpcUrl);
    try {
      const account = await splToken.getAccount(connection, new PublicKey(ata));
      txData.recipient = account.owner.toBase58();
    } catch (e) {
      console.error(e);
      txData.recipient = ata;
    }
  } else {
    txData.recipient = messageBody.mintRecipient
      .toNative(receipt.to)
      .toString();
  }

  // The attestation doesn't have the destination token address, but we can deduce which it is
  // just based off the destination chain
  if (txData.toChain) {
    const usdcContract = circle.usdcContract.get(
      config.network,
      txData.toChain,
    );
    if (!usdcContract) {
      throw new Error(`Couldn't find USDC for destination chain`);
    }
    const destinationToken = config.tokens.get(txData.toChain, usdcContract);
    if (!destinationToken) {
      throw new Error(`Couldn't find USDC for destination chain`);
    }

    txData.receivedToken = destinationToken.tuple;
  }

  return txData as TransferInfo;
};

const parseBaseBridgeReceipt = async (
  receipt: ReceiptWithAttestation<BaseBridgeExecutorRoute.Attestation>,
): Promise<TransferInfo> => {
  let sendTx = '';
  if ('originTxs' in receipt && receipt.originTxs.length > 0) {
    sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  const { transferInfo } = receipt.attestation;
  if (!transferInfo) {
    throw new Error('BaseBridgeRoute attestation missing metadata');
  }

  const sourceToken = config.tokens.get(receipt.from, transferInfo.localToken);
  if (!sourceToken) {
    throw new Error(
      `Unknown source token: ${transferInfo.localChain} on ${receipt.from}`,
    );
  }

  const destToken = config.tokens.get(receipt.to, transferInfo.remoteToken);
  if (!destToken) {
    throw new Error(
      `Unknown destination token: ${transferInfo.remoteToken} on ${receipt.to}`,
    );
  }

  const amt = amount.fromBaseUnits(transferInfo.amount, sourceToken.decimals);

  let recipient = transferInfo.to;
  if (isSvmChain(receipt.to)) {
    const rpcUrl = config.rpcs[receipt.to];
    if (!rpcUrl) {
      throw new Error(`Missing ${receipt.to} RPC`);
    }
    // The recipient is the ATA, get the owner
    const connection = new Connection(rpcUrl);
    try {
      const mint = new PublicKey(transferInfo.remoteToken);
      const ata = new PublicKey(transferInfo.to);
      const tokenAccount = await connection.getAccountInfo(mint);
      if (tokenAccount) {
        recipient = (
          await splToken.getAccount(
            connection,
            ata,
            'confirmed',
            tokenAccount.owner,
          )
        ).owner.toBase58();
      }
    } catch (e) {
      console.error(e);
    }
  }

  return {
    toChain: receipt.to,
    fromChain: receipt.from,
    sendTx,
    sender: undefined,
    recipient,
    amount: amt,
    tokenAddress: sourceToken.address.toString(),
    token: sourceToken.tuple,
    tokenDecimals: sourceToken.decimals,
    receivedToken: destToken.tuple,
    receiveAmount: amt,
  };
};

const parseMultiTokenNttReceipt = async (
  receipt: ReceiptWithAttestation<MultiTokenNttRoute.AttestationReceipt> & {
    params: MultiTokenNttRoute.ValidatedParams;
  },
  getOrFetchToken: (tokenId: TokenId) => Promise<Token | undefined>,
): Promise<TransferInfo> => {
  let sendTx = '';
  if (receipt.originTxs?.length > 0) {
    sendTx = receipt.originTxs[receipt.originTxs.length - 1].txid;
  } else {
    throw new Error("Can't find txid in receipt");
  }

  // The source and destination tokens may not be in the token cache
  // so add them if they don't exist
  const srcToken = await getOrFetchToken(
    receipt.params.normalizedParams.sourceTokenId,
  );
  if (!srcToken) {
    throw new Error('Unable to fetch source token');
  }

  const dstToken = await getOrFetchToken(
    receipt.params.normalizedParams.destinationTokenId,
  );
  if (!dstToken) {
    throw new Error('Unable to fetch destination token');
  }

  const { attestation } = receipt.attestation;
  const { nttManagerPayload } = attestation.payload;
  const trimmedAmount = nttManagerPayload.payload.data.trimmedAmount;
  const amt = amount.fromBaseUnits(
    trimmedAmount.amount,
    trimmedAmount.decimals,
  );

  return {
    toChain: receipt.to,
    fromChain: receipt.from,
    sendTx,
    sender: undefined, // not available in the VAA
    recipient: nttManagerPayload.payload.data.to
      .toNative(receipt.to)
      .toString(),
    amount: amt,
    tokenAddress: srcToken.tokenId.address.toString(),
    token: srcToken.tuple,
    tokenDecimals: trimmedAmount.decimals,
    receivedToken: dstToken.tuple,
    receiveAmount: amt,
  };
};

const isAmount = (amount: any): amount is amount.Amount => {
  return (
    typeof amount === 'object' &&
    typeof amount.amount === 'string' &&
    typeof amount.decimals === 'number'
  );
};

// Warning: any changes to this function can make TS unhappy
export const isMinAmountError = (
  error?: Error,
): error is routes.MinAmountError => {
  const unsafeCastError = error as routes.MinAmountError;
  return isAmount(unsafeCastError?.min);
};

const getTokenBridgeToken = async (
  context: ChainContext<Network>,
  token: any,
) => {
  const tb = await context.getTokenBridge();
  const { chain } = context;

  const tokenAddress =
    token.chain === chain
      ? await tb.getTokenNativeAddress(token.chain, token.address)
      : await tb.getWrappedAsset({
          chain: token.chain,
          address: token.address,
        });

  const wrappedNative = await tb.getWrappedNative();

  const tokenId =
    wrappedNative && wrappedNative.toString() === tokenAddress.toString()
      ? nativeTokenId(chain)
      : Wormhole.tokenId(chain, tokenAddress.toString());

  return config.tokens.get(tokenId);
};

export function getFilteredChains(
  supportedChains: Array<Chain>,
  chainToOmit: Chain | undefined,
  isSource = false,
) {
  const shouldOmit = chainToOmit
    ? !config.routes.isSameChainSwapSupported(chainToOmit)
    : false;

  return config.chainsArr.filter((chain) => {
    /*
      If we see more exceptions being added like this, a better solution would be to update the route
      interface in the sdk to have explicit `supportedSourceChains()` and `supportedDestinationChains()`
      function where routes can specify it directly. Current `supportedChains()` doesn't suffice.
    */
    if (isSource && isHyperCoreChain(chain.sdkName)) {
      return false;
    }

    if (!supportedChains.includes(chain.sdkName)) {
      return false;
    }

    if (typeof config.isChainSupportedHandler === 'function') {
      const type = isSource ? 'source' : 'destination';

      if (
        !config.isChainSupportedHandler(
          chain.sdkName,
          type,
          config.network,
          chainToOmit,
        )
      ) {
        return false;
      }
    }

    const isChainOmitted = shouldOmit && chainToOmit === chain.sdkName;
    return !isChainOmitted;
  });
}
