---
name: Bug report
about: Submit a bug ticket if you have an integration issue. If you're a user, check out the Wormhole Discord server below for faster assistance.
title: "[Bug]"
labels: ["integration-support"]
assignees: ''
---
<!--- Fill out the fields if you're an integrator. -->
<!--- Check if this is already reported in another issue -->
## Description and context
<!--- Provide a detailed description of the problem to expedite the process. -->


## Steps to reproduce
<!--- Describe what happened step by step. -->
<!--- If applicable, provide a link to a live example or include code to reproduce. -->

1.
2.
3.

## Experienced behavior
<!--- Describe what happened after the last step. -->
<!--- If applicable, paste a screenshot of your console log. -->


## Expected behavior
<!--- Describe what was expected to happen instead. -->


## Solution recommendation
<!--- Not mandatory, but feel free to recommend a way fix the issue. -->

