'use client';

import WormholeConnect, {
    type config,
  } from '@wormhole-foundation/wormhole-connect';
import {
  nttExecutorRoute,
} from '@wormhole-foundation/wormhole-connect/ntt';

const wormholeConfig: config.WormholeConnectConfig = {
  network: 'Mainnet',
  chains: ['Solana', 'Monad'],
  tokens: ['WSV'],
  ui: {
    title: 'Wormhole NTT UI',
    defaultInputs: {
      source: {
        chain: 'Solana',
        token: 'WSV',
      },
      destination: {
        chain: 'Monad',
        token: 'WSV',
      },
    },
    // walletConnectProjectId: '', 
  },
  // TODO: use a private RPC for mainnet
  // rpcs: {
  //   Solana: 'https://mainnet.helius-rpc.com/?api-key=$KEY',
  // },
  routes: [
    nttExecutorRoute({
      ntt: {
        tokens: {
          WSV_NTT: [
            {
              chain: 'Solana',
              manager: 'nMxHx1o8GUg2pv99y8JAQb5RyWNqDWixbxWCaBcurQx',
              token: '2vLDzr7hUpLFHQotmR8EPcMTWczZUwCK31aefAzumkmv',
              transceiver: [
                {
                  address: 'AjL3f9FMHJ8VkNUHZqLYxa5aFy3aTN6LUWMv4qmdf5PN',
                  type: 'wormhole',
                },
              ],
            },
            {
              chain: 'Monad',
              manager: '0xaE02Ff9C3781C5BA295c522fB469B87Dc5EE9205',
              token: '0xb8dccDA8C166172159F029eb003d5479687452bD',
              transceiver: [
                {
                  address: '0xF4Af1Eac8995766b54210b179A837E3D59a9F146',
                  type: 'wormhole',
                },
              ],
            },
          ],
        },
      },
    }),
  ],
  tokensConfig: {
    WSVsol: {
      symbol: 'WSV',
      tokenId: {
        chain: 'Solana',
        address: '2vLDzr7hUpLFHQotmR8EPcMTWczZUwCK31aefAzumkmv'
      },
      icon: 'https://wormhole.com/token.png',
      decimals: 9
    },
    WSVmon: {
      symbol: 'WSV',
      tokenId: {
        chain: 'Monad',
        address: '0xb8dccDA8C166172159F029eb003d5479687452bD'
      },
      icon: 'https://wormhole.com/token.png',
      decimals: 9
    }
  }
}

export default function Home() {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      padding: '20px'
    }}>
      <div style={{ width: '100%', maxWidth: '480px' }}>
        <WormholeConnect 
          config={wormholeConfig} 
          theme={{ mode: 'dark', primary: '#78c4b6' }} 
        />
      </div>
    </div>
  )
} 