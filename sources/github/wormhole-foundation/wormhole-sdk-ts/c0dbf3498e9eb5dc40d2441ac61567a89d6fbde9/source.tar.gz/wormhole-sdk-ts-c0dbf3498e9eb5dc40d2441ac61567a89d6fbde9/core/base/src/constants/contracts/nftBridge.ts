import type { MapLevels } from "./../../utils/index.js";
import type { Network } from "../networks.js";
import type { Chain } from "../chains.js";

// prettier-ignore
export const nftBridgeContracts = [[
  "Mainnet", [
    ["Solana",    "WnFt12ZrnzZrFZkt2xsNsaNWoQribnuQ5B5FrDbwDhD"],
    ["Ethereum",  "0x6FFd7EdE62328b3Af38FCD61461Bbfc52F5651fE"],
    ["Bsc",       "0x5a58505a96D1dbf8dF91cB21B54419FC36e93fdE"],
    ["Polygon",   "0x90BBd86a6Fe93D3bc3ed6335935447E75fAb7fCf"],
    ["Avalanche", "0xf7B6737Ca9c4e08aE573F75A97B73D7a813f5De5"],
    ["Klaytn",    "0x3c3c561757BAa0b78c5C025CdEAa4ee24C1dFfEf"],
    ["Celo",      "0xA6A377d75ca5c9052c9a77ED1e865Cc25Bd97bf3"],
    ["Aptos",     "0x1bdffae984043833ed7fe223f7af7a3f8902d04129b14f801823e64827da7130"],
    ["Moonbeam",  "0x453cfbe096c0f8d763e8c5f24b441097d577bde2"],
    ["Arbitrum",  "0x3dD14D553cFD986EAC8e3bddF629d82073e188c8"],
    ["Base",      "0xDA3adC6621B2677BEf9aD26598e6939CF0D92f88"],
    ["Optimism",  "0xfE8cD454b4A1CA468B57D79c0cc77Ef5B6f64585"],
  ]], [
  "Testnet", [
    ["Solana",          "2rHhojZ7hpu1zA91nvZmT8TqWWvMcKmmNBCr2mKTtMq4"],
    ["Ethereum",        "0xD8E4C2DbDd2e2bd8F1336EA691dBFF6952B1a6eB"],
    ["Bsc",             "0xcD16E5613EF35599dc82B24Cb45B5A93D779f1EE"],
    ["Polygon",         "0x51a02d0dcb5e52F5b92bdAA38FA013C91c7309A9"],
    ["Avalanche",       "0xD601BAf2EEE3C028344471684F6b27E789D9075D"],
    ["Klaytn",          "0x94c994fC51c13101062958b567e743f1a04432dE"],
    ["Celo",            "0xaCD8190F647a31E56A656748bC30F69259f245Db"],
    ["Moonbeam",        "0x98A0F4B96972b32Fcb3BD03cAeB66A44a6aB9Edb"],
    ["Arbitrum",        "0xEe3dB83916Ccdc3593b734F7F2d16D630F39F1D0"],
    ["Optimism",        "0x23908A62110e21C04F3A4e011d24F901F911744A"],
    ["Base",            "0xF681d1cc5F25a3694E348e7975d7564Aa581db59"],
    ["Sepolia",         "0x6a0B52ac198e4870e5F3797d5B403838a5bbFD99"],
    ["Aptos",           "0x1bdffae984043833ed7fe223f7af7a3f8902d04129b14f801823e64827da7130"],
    ["ArbitrumSepolia", "0x23908A62110e21C04F3A4e011d24F901F911744A"],
    ["BaseSepolia",     "0x268557122Ffd64c85750d630b716471118F323c8"],
    ["OptimismSepolia", "0x27812285fbe85BA1DF242929B906B31EE3dd1b9f"],
    ["Holesky",         "0xc8941d483c45eF8FB72E4d1F9dDE089C95fF8171"],
    ["PolygonSepolia",  "0x23908A62110e21C04F3A4e011d24F901F911744A"],
  ]], [
  "Devnet", [
    ["Solana",    "NFTWqJR8YnRVqPDvTJrYuLrQDitTG5AScqbeghi4zSA"],
    ["Ethereum",  "0x26b4afb60d6c903165150c6f0aa14f8016be4aec"],
    ["Bsc",       "0x26b4afb60d6c903165150c6f0aa14f8016be4aec"],
    ["Aptos",     "0x46da3d4c569388af61f951bdd1153f4c875f90c2991f6b2d0a38e2161a40852c"],
  ]],
] as const satisfies MapLevels<[Network, Chain, string]>;
