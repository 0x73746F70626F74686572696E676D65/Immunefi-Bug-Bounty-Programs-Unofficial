import type { MapLevel } from "./../utils/index.js";
import { constMap } from "./../utils/index.js";
import type { Chain } from "./chains.js";
import type { Platform } from "./platforms.js";

// prettier-ignore
const nativeDecimalEntries = [
  ["Evm",         18],
  ["Solana",       9],
  ["Sui",          9],
  ["Aptos",        8],
  ["Cosmwasm",     6],
  ["Algorand",     6],
  ["Btc",          8],
  ["Near",        12],
  ["Stacks",       6],
  ["Xrpl",         6],
] as const satisfies MapLevel<Platform, number>;

/** Number of decimals for the native token on a given platform */
export const nativeDecimals = constMap(nativeDecimalEntries);

// prettier-ignore
// Chain-specific overrides for native token decimals (takes precedence over platform default)
const nativeDecimalOverrideEntries = [
  ["Tempo", 6], // pathUSD native token
] as const satisfies MapLevel<Chain, number>;

/** Chain-specific native token decimal overrides */
export const nativeDecimalOverrides = constMap(nativeDecimalOverrideEntries);
