import bs58 from "bs58";

// ---------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------

export function validateAddress(address: string, label: string): void {
  if (!address || !address.match(/^0x[0-9a-fA-F]{40}$/)) {
    throw new Error(
      `Invalid ${label}: "${address}" - must be a 0x-prefixed 40-character hex string`
    );
  }
}

export function validateRequiredString(value: string, label: string): void {
  if (!value || !value.trim()) {
    throw new Error(`Invalid ${label}: value is required`);
  }
}

export function validateRpcUrl(url: string, label: string): void {
  validateRequiredString(url, label);

  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error(`Invalid ${label}: "${url}" - must be a valid URL`);
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error(
      `Invalid ${label}: "${url}" - must use http or https`
    );
  }
}

export function validateNetwork(network: string, label: string): void {
  if (network !== "Mainnet" && network !== "Testnet") {
    throw new Error(
      `Invalid ${label}: "${network}" - must be "Mainnet" or "Testnet"`
    );
  }
}

export function validateEvmChainId(chainId: string, label: string): void {
  if (!chainId.match(/^\d+$/)) {
    throw new Error(
      `Invalid ${label}: "${chainId}" - must be a numeric string`
    );
  }

  const parsed = Number(chainId);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(
      `Invalid ${label}: "${chainId}" - must be a positive safe integer`
    );
  }
}

export function validateLimit(limit: string, label: string): void {
  if (!limit || !limit.match(/^\d+$/)) {
    throw new Error(
      `Invalid ${label}: "${limit}" - must be a numeric string in base units`
    );
  }
  if (BigInt(limit) === 0n) {
    console.warn(`Warning: ${label} is 0 - this will block all transfers`);
  }
}

export function validateSolanaAddress(address: string, label: string): void {
  let bytes: Uint8Array;
  try {
    bytes = bs58.decode(address);
  } catch {
    throw new Error(
      `Invalid ${label}: "${address}" - must be a valid base58-encoded Solana address`
    );
  }
  if (bytes.length !== 32) {
    throw new Error(
      `Invalid ${label}: "${address}" - decoded to ${bytes.length} bytes, expected 32`
    );
  }
}

export function validateTokenDecimals(decimals: number, label: string): void {
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 255) {
    throw new Error(
      `Invalid ${label}: ${decimals} - must be an integer between 0 and 255`
    );
  }
}

// ---------------------------------------------------------------------------
// String helpers
// ---------------------------------------------------------------------------

export function slugify(name: string): string {
  return name.toLowerCase().replace(/\s+/g, "-");
}
