import { createSafeBatch } from "../utils/safeBatchBuilder";

describe("createSafeBatch", () => {
  it("creates a valid batch structure", () => {
    const batch = createSafeBatch({
      chainId: "11155111",
      name: "Test Batch",
      description: "A test batch",
      safeAddress: "0x1234567890123456789012345678901234567890",
      transactions: [],
    });

    expect(batch.version).toBe("1.0");
    expect(batch.chainId).toBe("11155111");
    expect(batch.meta.name).toBe("Test Batch");
    expect(batch.meta.description).toBe("A test batch");
    expect(batch.meta.createdFromSafeAddress).toBe(
      "0x1234567890123456789012345678901234567890"
    );
    expect(batch.createdAt).toBeGreaterThan(0);
    expect(batch.transactions).toEqual([]);
  });

  it("handles missing optional fields", () => {
    const batch = createSafeBatch({
      chainId: "1",
      name: "Minimal",
      transactions: [],
    });

    expect(batch.meta.description).toBeUndefined();
    expect(batch.meta.createdFromSafeAddress).toBeUndefined();
  });
});
