import * as fs from "fs";
import * as path from "path";
import {
  validateAddress,
  validateEvmChainId,
  validateLimit,
  validateNetwork,
  validateRequiredString,
  validateRpcUrl,
  validateTokenDecimals,
  slugify,
} from "../utils/encoding";
import { createSafeBatch } from "../utils/safeBatchBuilder";
import { createNttClient, extractSafeTx, toUniversal } from "../utils/nttClient";

interface ChainConfig {
  name: string;
  rpcUrl: string;
  wormholeChain: string;
  evmChainId: string;
  safeAddress: string;
  nttManager: string;
  wormholeTransceiver: string;
  tokenDecimals: number;
  inboundLimit: string;
}

interface ExtendConfig {
  network: string;
  existingChain: ChainConfig;
  newChain: ChainConfig;
}

function writeBatchFile(filePath: string, batch: object): void {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(batch, null, 2) + "\n");
}

async function main(): Promise<void> {
  const configPath = path.resolve(
    __dirname,
    "../config/extendToEvmChain.json"
  );

  if (!fs.existsSync(configPath)) {
    console.error(
      "Config not found. Copy the example config and fill in your values:"
    );
    console.error(
      "  cp src/config/extendToEvmChain.example.json src/config/extendToEvmChain.json"
    );
    process.exit(1);
  }

  const config: ExtendConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
  const { network, existingChain, newChain } = config;

  // --- Validation ---
  validateNetwork(network, "network");

  for (const [label, chain] of [
    ["existingChain", existingChain],
    ["newChain", newChain],
  ] as const) {
    validateRequiredString(chain.name, `${label}.name`);
    validateRpcUrl(chain.rpcUrl, `${label}.rpcUrl`);
    validateRequiredString(chain.wormholeChain, `${label}.wormholeChain`);
    validateEvmChainId(chain.evmChainId, `${label}.evmChainId`);
    validateAddress(chain.safeAddress, `${label}.safeAddress`);
    validateAddress(chain.nttManager, `${label}.nttManager`);
    validateAddress(chain.wormholeTransceiver, `${label}.wormholeTransceiver`);
    validateTokenDecimals(chain.tokenDecimals, `${label}.tokenDecimals`);
    validateLimit(chain.inboundLimit, `${label}.inboundLimit`);
  }

  if (existingChain.wormholeChain === newChain.wormholeChain) {
    console.warn(
      `Warning: existingChain and newChain have the same wormholeChain (${existingChain.wormholeChain}). This is likely a misconfiguration.`
    );
  }

  const outputDir = path.resolve(__dirname, "../../output");

  // --- Generate batch for EXISTING chain (register the new chain as peer) ---
  const existingNtt = await createNttClient({
    rpcUrl: existingChain.rpcUrl,
    network,
    wormholeChain: existingChain.wormholeChain,
    manager: existingChain.nttManager,
    transceiver: existingChain.wormholeTransceiver,
  });

  const newManagerPeer = {
    chain: newChain.wormholeChain,
    address: toUniversal(newChain.wormholeChain as any, newChain.nttManager),
  } as any;
  const newTransceiverPeer = {
    chain: newChain.wormholeChain,
    address: toUniversal(
      newChain.wormholeChain as any,
      newChain.wormholeTransceiver
    ),
  } as any;

  const existingChainTxs = [
    await extractSafeTx(
      existingNtt.setPeer(
        newManagerPeer,
        newChain.tokenDecimals,
        BigInt(existingChain.inboundLimit)
      ),
      existingNtt.manager
    ),
    await extractSafeTx(
      existingNtt.setTransceiverPeer(0, newTransceiverPeer),
      existingNtt.xcvrs[0]!.transceiver
    ),
  ];

  const existingChainBatch = createSafeBatch({
    chainId: existingChain.evmChainId,
    name: `Register NTT Peer: ${newChain.name} on ${existingChain.name}`,
    description: [
      `Register ${newChain.name} as an NTT peer on ${existingChain.name}.`,
      `Transactions:`,
      `  1. NttManager.setPeer - Register remote manager and set inbound limit to ${existingChain.inboundLimit}`,
      `  2. WormholeTransceiver.setWormholePeer - Register remote transceiver`,
    ].join("\n"),
    safeAddress: existingChain.safeAddress,
    transactions: existingChainTxs,
  });

  const existingChainFile = path.join(
    outputDir,
    `register-peer-${slugify(newChain.name)}-on-${slugify(existingChain.name)}.json`
  );
  writeBatchFile(existingChainFile, existingChainBatch);
  console.log(`\nGenerated batch for ${existingChain.name}:`);
  console.log(`  File: ${existingChainFile}`);
  console.log(`  Safe: ${existingChain.safeAddress}`);
  console.log(`  Transactions (${existingChainTxs.length}):`);
  console.log(
    `    - NttManager.setPeer - register ${newChain.name} as peer on NTT Manager (${existingChain.nttManager})`
  );
  console.log(
    `    - WormholeTransceiver.setWormholePeer - register ${newChain.name} transceiver on Transceiver (${existingChain.wormholeTransceiver})`
  );

  // --- Generate batch for NEW chain (register the existing chain as peer) ---
  const newNtt = await createNttClient({
    rpcUrl: newChain.rpcUrl,
    network,
    wormholeChain: newChain.wormholeChain,
    manager: newChain.nttManager,
    transceiver: newChain.wormholeTransceiver,
  });

  const existingManagerPeer = {
    chain: existingChain.wormholeChain,
    address: toUniversal(
      existingChain.wormholeChain as any,
      existingChain.nttManager
    ),
  } as any;
  const existingTransceiverPeer = {
    chain: existingChain.wormholeChain,
    address: toUniversal(
      existingChain.wormholeChain as any,
      existingChain.wormholeTransceiver
    ),
  } as any;

  const newChainTxs = [
    await extractSafeTx(
      newNtt.setPeer(
        existingManagerPeer,
        existingChain.tokenDecimals,
        BigInt(newChain.inboundLimit)
      ),
      newNtt.manager
    ),
    await extractSafeTx(
      newNtt.setTransceiverPeer(0, existingTransceiverPeer),
      newNtt.xcvrs[0]!.transceiver
    ),
  ];

  const newChainBatch = createSafeBatch({
    chainId: newChain.evmChainId,
    name: `Register NTT Peer: ${existingChain.name} on ${newChain.name}`,
    description: [
      `Register ${existingChain.name} as an NTT peer on ${newChain.name}.`,
      `Transactions:`,
      `  1. NttManager.setPeer - Register remote manager and set inbound limit to ${newChain.inboundLimit}`,
      `  2. WormholeTransceiver.setWormholePeer - Register remote transceiver`,
    ].join("\n"),
    safeAddress: newChain.safeAddress,
    transactions: newChainTxs,
  });

  const newChainFile = path.join(
    outputDir,
    `register-peer-${slugify(existingChain.name)}-on-${slugify(newChain.name)}.json`
  );
  writeBatchFile(newChainFile, newChainBatch);
  console.log(`\nGenerated batch for ${newChain.name}:`);
  console.log(`  File: ${newChainFile}`);
  console.log(`  Safe: ${newChain.safeAddress}`);
  console.log(`  Transactions (${newChainTxs.length}):`);
  console.log(
    `    - NttManager.setPeer - register ${existingChain.name} as peer on NTT Manager (${newChain.nttManager})`
  );
  console.log(
    `    - WormholeTransceiver.setWormholePeer - register ${existingChain.name} transceiver on Transceiver (${newChain.wormholeTransceiver})`
  );

  console.log("\n---");
  console.log("Next steps:");
  console.log(
    "  1. Import each JSON file into the Safe Transaction Builder on the corresponding chain"
  );
  console.log("  2. Review the decoded transactions in the Safe UI");
  console.log("  3. Submit and collect signatures from other Safe owners");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
