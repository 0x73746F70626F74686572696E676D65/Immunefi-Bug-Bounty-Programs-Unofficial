import * as fs from "fs";
import * as path from "path";
import {
  validateAddress,
  validateEvmChainId,
  validateLimit,
  validateNetwork,
  validateRequiredString,
  validateRpcUrl,
  validateSolanaAddress,
  validateTokenDecimals,
  slugify,
} from "../utils/encoding";
import { createSafeBatch } from "../utils/safeBatchBuilder";
import { createNttClient, extractSafeTx, toUniversal } from "../utils/nttClient";

interface EvmChainConfig {
  name: string;
  rpcUrl: string;
  wormholeChain: string;
  evmChainId: string;
  safeAddress: string;
  nttManager: string;
  wormholeTransceiver: string;
  inboundLimit: string;
}

interface SvmChainConfig {
  name: string;
  wormholeChain: string;
  nttManager: string;
  wormholeTransceiver: string;
  tokenDecimals: number;
}

interface ExtendToSvmConfig {
  network: string;
  evmChain: EvmChainConfig;
  svmChain: SvmChainConfig;
}

async function main(): Promise<void> {
  const configPath = path.resolve(
    __dirname,
    "../config/extendToSvmChain.json"
  );

  if (!fs.existsSync(configPath)) {
    console.error(
      "Config not found. Copy the example config and fill in your values:"
    );
    console.error(
      "  cp src/config/extendToSvmChain.example.json src/config/extendToSvmChain.json"
    );
    process.exit(1);
  }

  const config: ExtendToSvmConfig = JSON.parse(
    fs.readFileSync(configPath, "utf-8")
  );
  const { network, evmChain, svmChain } = config;

  // --- Validation ---
  validateNetwork(network, "network");
  validateRequiredString(evmChain.name, "evmChain.name");
  validateRpcUrl(evmChain.rpcUrl, "evmChain.rpcUrl");
  validateRequiredString(evmChain.wormholeChain, "evmChain.wormholeChain");
  validateEvmChainId(evmChain.evmChainId, "evmChain.evmChainId");
  validateAddress(evmChain.safeAddress, "evmChain.safeAddress");
  validateAddress(evmChain.nttManager, "evmChain.nttManager");
  validateAddress(evmChain.wormholeTransceiver, "evmChain.wormholeTransceiver");
  validateLimit(evmChain.inboundLimit, "evmChain.inboundLimit");
  validateRequiredString(svmChain.name, "svmChain.name");
  validateRequiredString(svmChain.wormholeChain, "svmChain.wormholeChain");
  validateSolanaAddress(svmChain.nttManager, "svmChain.nttManager");
  validateSolanaAddress(
    svmChain.wormholeTransceiver,
    "svmChain.wormholeTransceiver"
  );
  validateTokenDecimals(svmChain.tokenDecimals, "svmChain.tokenDecimals");

  const ntt = await createNttClient({
    rpcUrl: evmChain.rpcUrl,
    network,
    wormholeChain: evmChain.wormholeChain,
    manager: evmChain.nttManager,
    transceiver: evmChain.wormholeTransceiver,
  });

  const svmManagerPeer = {
    chain: svmChain.wormholeChain,
    address: toUniversal(svmChain.wormholeChain as any, svmChain.nttManager),
  } as any;
  const svmTransceiverPeer = {
    chain: svmChain.wormholeChain,
    address: toUniversal(
      svmChain.wormholeChain as any,
      svmChain.wormholeTransceiver
    ),
  } as any;

  const transactions = [
    await extractSafeTx(
      ntt.setPeer(
        svmManagerPeer,
        svmChain.tokenDecimals,
        BigInt(evmChain.inboundLimit)
      ),
      ntt.manager
    ),
    await extractSafeTx(
      ntt.setTransceiverPeer(0, svmTransceiverPeer),
      ntt.xcvrs[0]!.transceiver
    ),
  ];

  const batch = createSafeBatch({
    chainId: evmChain.evmChainId,
    name: `Register NTT Peer: ${svmChain.name} on ${evmChain.name}`,
    description: [
      `Register ${svmChain.name} as an NTT peer on ${evmChain.name}.`,
      `Transactions:`,
      `  1. NttManager.setPeer - Register SVM manager and set inbound limit to ${evmChain.inboundLimit}`,
      `  2. WormholeTransceiver.setWormholePeer - Register SVM transceiver`,
    ].join("\n"),
    safeAddress: evmChain.safeAddress,
    transactions,
  });

  const outputDir = path.resolve(__dirname, "../../output");
  fs.mkdirSync(outputDir, { recursive: true });

  const outputFile = path.join(
    outputDir,
    `register-peer-${slugify(svmChain.name)}-on-${slugify(evmChain.name)}.json`
  );
  fs.writeFileSync(outputFile, JSON.stringify(batch, null, 2) + "\n");

  console.log(`\nGenerated batch for ${evmChain.name}:`);
  console.log(`  File: ${outputFile}`);
  console.log(`  Safe: ${evmChain.safeAddress}`);
  console.log(`  Transactions (${transactions.length}):`);
  console.log(
    `    - NttManager.setPeer - register ${svmChain.name} as peer on NTT Manager (${evmChain.nttManager})`
  );
  console.log(
    `    - WormholeTransceiver.setWormholePeer - register ${svmChain.name} transceiver on Transceiver (${evmChain.wormholeTransceiver})`
  );

  console.log("\n---");
  console.log("Next steps:");
  console.log(
    "  1. Import the JSON file into the Safe Transaction Builder on the EVM chain"
  );
  console.log("  2. Review the decoded transactions in the Safe UI");
  console.log("  3. Submit and collect signatures from other Safe owners");
  console.log(
    `  4. Register the EVM peer on ${svmChain.name} using the Solana multisig tools`
  );
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
