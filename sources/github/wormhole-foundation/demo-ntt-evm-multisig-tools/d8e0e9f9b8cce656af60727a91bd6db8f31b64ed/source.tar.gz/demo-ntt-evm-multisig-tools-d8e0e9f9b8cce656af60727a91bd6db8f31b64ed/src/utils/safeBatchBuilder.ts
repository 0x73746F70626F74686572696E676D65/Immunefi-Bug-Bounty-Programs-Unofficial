export interface SafeBatchFile {
  version: string;
  chainId: string;
  createdAt: number;
  meta: {
    name: string;
    description?: string;
    txBuilderVersion?: string;
    createdFromSafeAddress?: string;
  };
  transactions: SafeBatchTransaction[];
}

export interface SafeBatchTransaction {
  to: string;
  value: string;
  data: string;
  contractMethod?: {
    inputs: { internalType: string; name: string; type: string }[];
    name: string;
    payable: boolean;
  };
  contractInputsValues?: Record<string, string>;
}

/**
 * Creates a Safe Transaction Builder batch file.
 */
export function createSafeBatch(params: {
  chainId: string;
  name: string;
  description?: string;
  safeAddress?: string;
  transactions: SafeBatchTransaction[];
}): SafeBatchFile {
  return {
    version: "1.0",
    chainId: params.chainId,
    createdAt: Math.floor(Date.now() / 1000),
    meta: {
      name: params.name,
      description: params.description,
      txBuilderVersion: "1.16.5",
      createdFromSafeAddress: params.safeAddress,
    },
    transactions: params.transactions,
  };
}
