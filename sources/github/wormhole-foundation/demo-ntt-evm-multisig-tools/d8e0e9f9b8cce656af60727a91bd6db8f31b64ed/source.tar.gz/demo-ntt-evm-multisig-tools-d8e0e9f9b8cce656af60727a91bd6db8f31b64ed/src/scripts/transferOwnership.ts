import * as fs from "fs";
import * as path from "path";
import {
  validateAddress,
  validateEvmChainId,
  validateNetwork,
  validateRequiredString,
  validateRpcUrl,
  slugify,
} from "../utils/encoding";
import { createSafeBatch } from "../utils/safeBatchBuilder";
import { createNttClient, extractSafeTx } from "../utils/nttClient";

interface TransferOwnershipConfig {
  network: string;
  chain: {
    name: string;
    rpcUrl: string;
    wormholeChain: string;
    evmChainId: string;
    safeAddress: string;
    nttManager: string;
    wormholeTransceiver: string;
  };
  newOwner: string;
}

async function main(): Promise<void> {
  const configPath =
    process.argv[2] ||
    path.resolve(__dirname, "../config/transferOwnership.json");

  if (!fs.existsSync(configPath)) {
    console.error(
      "Config not found. Copy the example config and fill in your values:"
    );
    console.error(
      "  cp src/config/transferOwnership.example.json src/config/transferOwnership.json"
    );
    process.exit(1);
  }

  const config: TransferOwnershipConfig = JSON.parse(
    fs.readFileSync(configPath, "utf-8")
  );
  const { network, chain, newOwner } = config;

  // --- Validation ---
  validateNetwork(network, "network");
  validateRequiredString(chain.name, "chain.name");
  validateRpcUrl(chain.rpcUrl, "chain.rpcUrl");
  validateRequiredString(chain.wormholeChain, "chain.wormholeChain");
  validateEvmChainId(chain.evmChainId, "chain.evmChainId");
  validateAddress(chain.safeAddress, "chain.safeAddress");
  validateAddress(chain.nttManager, "chain.nttManager");
  validateAddress(chain.wormholeTransceiver, "chain.wormholeTransceiver");
  validateAddress(newOwner, "newOwner");

  if (newOwner === "0x0000000000000000000000000000000000000000") {
    console.warn(
      "Warning: newOwner is the zero address. This will renounce ownership permanently."
    );
  }

  const ntt = await createNttClient({
    rpcUrl: chain.rpcUrl,
    network,
    wormholeChain: chain.wormholeChain,
    manager: chain.nttManager,
    transceiver: chain.wormholeTransceiver,
  });

  const tx = await extractSafeTx(ntt.setOwner(newOwner), ntt.manager);

  const batch = createSafeBatch({
    chainId: chain.evmChainId,
    name: `Transfer NTT Ownership on ${chain.name}`,
    description: `Transfer ownership of the NTT Manager on ${chain.name} to ${newOwner}.\nNote: This also transfers ownership of all registered transceivers.`,
    safeAddress: chain.safeAddress,
    transactions: [tx],
  });

  const outputDir = path.resolve(__dirname, "../../output");
  fs.mkdirSync(outputDir, { recursive: true });

  const outputFile = path.join(
    outputDir,
    `transfer-ownership-${slugify(chain.name)}.json`
  );
  fs.writeFileSync(outputFile, JSON.stringify(batch, null, 2) + "\n");

  console.log(`\nGenerated batch for ${chain.name}:`);
  console.log(`  File: ${outputFile}`);
  console.log(`  NTT Manager: ${chain.nttManager}`);
  console.log(`  New owner: ${newOwner}`);
  console.log(
    "\n  Warning: This transfers ownership of the NTT Manager AND all registered transceivers."
  );
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
