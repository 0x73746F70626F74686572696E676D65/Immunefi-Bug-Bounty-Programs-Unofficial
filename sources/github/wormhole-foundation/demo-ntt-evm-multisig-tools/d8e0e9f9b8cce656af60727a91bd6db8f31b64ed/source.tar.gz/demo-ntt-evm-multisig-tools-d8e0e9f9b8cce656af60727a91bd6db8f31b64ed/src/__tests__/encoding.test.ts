import {
  validateAddress,
  validateEvmChainId,
  validateLimit,
  validateNetwork,
  validateRequiredString,
  validateRpcUrl,
  validateSolanaAddress,
  validateTokenDecimals,
  slugify,
} from "../utils/encoding";

describe("validateAddress", () => {
  it("accepts valid addresses", () => {
    expect(() =>
      validateAddress("0x1234567890123456789012345678901234567890", "test")
    ).not.toThrow();
  });

  it("rejects empty string", () => {
    expect(() => validateAddress("", "test")).toThrow("Invalid test");
  });

  it("rejects address without 0x prefix", () => {
    expect(() =>
      validateAddress("1234567890123456789012345678901234567890", "test")
    ).toThrow("Invalid test");
  });

  it("rejects address with wrong length", () => {
    expect(() => validateAddress("0x1234", "test")).toThrow("Invalid test");
  });

  it("rejects non-hex characters", () => {
    expect(() =>
      validateAddress("0xGGGG567890123456789012345678901234567890", "test")
    ).toThrow("Invalid test");
  });
});

describe("validateRequiredString", () => {
  it("accepts non-empty strings", () => {
    expect(() => validateRequiredString("Sepolia", "test")).not.toThrow();
  });

  it("rejects empty strings", () => {
    expect(() => validateRequiredString("", "test")).toThrow("Invalid test");
  });
});

describe("validateRpcUrl", () => {
  it("accepts valid http urls", () => {
    expect(() =>
      validateRpcUrl("https://ethereum-sepolia-rpc.publicnode.com", "test")
    ).not.toThrow();
  });

  it("rejects invalid urls", () => {
    expect(() => validateRpcUrl("not-a-url", "test")).toThrow("Invalid test");
  });

  it("rejects non-http protocols", () => {
    expect(() => validateRpcUrl("ws://localhost:8545", "test")).toThrow(
      "Invalid test"
    );
  });
});

describe("validateNetwork", () => {
  it("accepts supported networks", () => {
    expect(() => validateNetwork("Mainnet", "test")).not.toThrow();
    expect(() => validateNetwork("Testnet", "test")).not.toThrow();
  });

  it("rejects unsupported networks", () => {
    expect(() => validateNetwork("Devnet", "test")).toThrow("Invalid test");
  });
});

describe("validateEvmChainId", () => {
  it("accepts numeric chain id strings", () => {
    expect(() => validateEvmChainId("11155111", "test")).not.toThrow();
  });

  it("rejects non-numeric chain id strings", () => {
    expect(() => validateEvmChainId("sepolia", "test")).toThrow(
      "Invalid test"
    );
  });
});

describe("validateSolanaAddress", () => {
  it("accepts valid Solana addresses", () => {
    expect(() =>
      validateSolanaAddress(
        "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
        "test"
      )
    ).not.toThrow();
  });

  it("rejects invalid base58", () => {
    expect(() =>
      validateSolanaAddress("0xinvalidaddress", "test")
    ).toThrow("Invalid test");
  });

  it("rejects too-short addresses", () => {
    expect(() => validateSolanaAddress("abc", "test")).toThrow("Invalid test");
  });
});

describe("validateLimit", () => {
  it("accepts valid numeric strings", () => {
    expect(() =>
      validateLimit("1000000000000000000000", "test")
    ).not.toThrow();
  });

  it("rejects empty string", () => {
    expect(() => validateLimit("", "test")).toThrow("Invalid test");
  });

  it("rejects non-numeric strings", () => {
    expect(() => validateLimit("abc", "test")).toThrow("Invalid test");
  });

  it("rejects negative numbers", () => {
    expect(() => validateLimit("-100", "test")).toThrow("Invalid test");
  });

  it("rejects decimal numbers", () => {
    expect(() => validateLimit("100.5", "test")).toThrow("Invalid test");
  });

  it("warns on zero limit", () => {
    const warnSpy = jest.spyOn(console, "warn").mockImplementation();
    validateLimit("0", "test");
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining("is 0"));
    warnSpy.mockRestore();
  });
});

describe("validateTokenDecimals", () => {
  it("accepts uint8 decimals", () => {
    expect(() => validateTokenDecimals(18, "test")).not.toThrow();
  });

  it("rejects negative values", () => {
    expect(() => validateTokenDecimals(-1, "test")).toThrow("Invalid test");
  });

  it("rejects values above uint8 max", () => {
    expect(() => validateTokenDecimals(256, "test")).toThrow("Invalid test");
  });
});

describe("slugify", () => {
  it("lowercases and replaces spaces with dashes", () => {
    expect(slugify("Ethereum Sepolia")).toBe("ethereum-sepolia");
  });

  it("handles multiple spaces", () => {
    expect(slugify("Base  Sepolia")).toBe("base-sepolia");
  });

  it("handles already slugified strings", () => {
    expect(slugify("solana")).toBe("solana");
  });
});
