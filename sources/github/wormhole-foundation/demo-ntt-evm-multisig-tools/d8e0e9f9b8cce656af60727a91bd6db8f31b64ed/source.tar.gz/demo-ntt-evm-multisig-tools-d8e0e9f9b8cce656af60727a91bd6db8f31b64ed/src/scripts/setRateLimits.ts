import * as fs from "fs";
import * as path from "path";
import type { Chain } from "@wormhole-foundation/sdk";
import {
  validateAddress,
  validateEvmChainId,
  validateLimit,
  validateNetwork,
  validateRequiredString,
  validateRpcUrl,
  slugify,
} from "../utils/encoding";
import {
  createSafeBatch,
  type SafeBatchTransaction,
} from "../utils/safeBatchBuilder";
import { createNttClient, extractSafeTx } from "../utils/nttClient";

interface InboundLimitEntry {
  chainName: string;
  limit: string;
}

interface RateLimitsConfig {
  network: string;
  chain: {
    name: string;
    rpcUrl: string;
    wormholeChain: string;
    evmChainId: string;
    safeAddress: string;
    nttManager: string;
    wormholeTransceiver: string;
  };
  outboundLimit?: string;
  inboundLimits?: InboundLimitEntry[];
}

async function main(): Promise<void> {
  const configPath =
    process.argv[2] || path.resolve(__dirname, "../config/setRateLimits.json");

  if (!fs.existsSync(configPath)) {
    console.error(
      "Config not found. Copy the example config and fill in your values:"
    );
    console.error(
      "  cp src/config/setRateLimits.example.json src/config/setRateLimits.json"
    );
    process.exit(1);
  }

  const config: RateLimitsConfig = JSON.parse(
    fs.readFileSync(configPath, "utf-8")
  );
  const { network, chain } = config;

  // --- Validation ---
  validateNetwork(network, "network");
  validateRequiredString(chain.name, "chain.name");
  validateRpcUrl(chain.rpcUrl, "chain.rpcUrl");
  validateRequiredString(chain.wormholeChain, "chain.wormholeChain");
  validateEvmChainId(chain.evmChainId, "chain.evmChainId");
  validateAddress(chain.safeAddress, "chain.safeAddress");
  validateAddress(chain.nttManager, "chain.nttManager");
  validateAddress(chain.wormholeTransceiver, "chain.wormholeTransceiver");

  if (config.outboundLimit) {
    validateLimit(config.outboundLimit, "outboundLimit");
  }

  if (config.inboundLimits) {
    for (const entry of config.inboundLimits) {
      validateRequiredString(
        entry.chainName,
        `inboundLimit[${entry.chainName}].chainName`
      );
      validateLimit(entry.limit, `inboundLimit[${entry.chainName}].limit`);
    }
  }

  const ntt = await createNttClient({
    rpcUrl: chain.rpcUrl,
    network,
    wormholeChain: chain.wormholeChain,
    manager: chain.nttManager,
    transceiver: chain.wormholeTransceiver,
  });

  const transactions: SafeBatchTransaction[] = [];

  if (config.outboundLimit) {
    transactions.push(
      await extractSafeTx(
        ntt.setOutboundLimit(BigInt(config.outboundLimit)),
        ntt.manager
      )
    );
  }

  if (config.inboundLimits) {
    for (const entry of config.inboundLimits) {
      transactions.push(
        await extractSafeTx(
          ntt.setInboundLimit(
            entry.chainName as Chain,
            BigInt(entry.limit)
          ),
          ntt.manager
        )
      );
    }
  }

  if (transactions.length === 0) {
    console.error(
      "No rate limits configured. Set outboundLimit and/or inboundLimits in the config."
    );
    process.exit(1);
  }

  const descriptions = [];
  if (config.outboundLimit) {
    descriptions.push(`Set outbound limit to ${config.outboundLimit}`);
  }
  if (config.inboundLimits) {
    for (const entry of config.inboundLimits) {
      descriptions.push(
        `Set inbound limit from ${entry.chainName} to ${entry.limit}`
      );
    }
  }

  const batch = createSafeBatch({
    chainId: chain.evmChainId,
    name: `Set NTT Rate Limits on ${chain.name}`,
    description: descriptions.join("\n"),
    safeAddress: chain.safeAddress,
    transactions,
  });

  const outputDir = path.resolve(__dirname, "../../output");
  fs.mkdirSync(outputDir, { recursive: true });

  const outputFile = path.join(
    outputDir,
    `set-rate-limits-${slugify(chain.name)}.json`
  );
  fs.writeFileSync(outputFile, JSON.stringify(batch, null, 2) + "\n");

  console.log(`\nGenerated batch for ${chain.name}:`);
  console.log(`  File: ${outputFile}`);
  console.log(`  NTT Manager: ${chain.nttManager}`);
  console.log(`  Transactions (${transactions.length}):`);
  if (config.outboundLimit) {
    console.log(`    - setOutboundLimit: ${config.outboundLimit}`);
  }
  if (config.inboundLimits) {
    for (const entry of config.inboundLimits) {
      console.log(
        `    - setInboundLimit from ${entry.chainName}: ${entry.limit}`
      );
    }
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
