import * as fs from "fs";
import * as path from "path";
import {
  validateAddress,
  validateEvmChainId,
  validateNetwork,
  validateRequiredString,
  validateRpcUrl,
  slugify,
} from "../utils/encoding";
import { createSafeBatch } from "../utils/safeBatchBuilder";
import { createNttClient, extractSafeTx } from "../utils/nttClient";

interface PauseConfig {
  network: string;
  chain: {
    name: string;
    rpcUrl: string;
    wormholeChain: string;
    evmChainId: string;
    safeAddress: string;
    nttManager: string;
    wormholeTransceiver: string;
  };
  action: "pause" | "unpause";
}

async function main(): Promise<void> {
  const configPath =
    process.argv[2] || path.resolve(__dirname, "../config/pause.json");

  if (!fs.existsSync(configPath)) {
    console.error(
      "Config not found. Copy the example config and fill in your values:"
    );
    console.error(
      "  cp src/config/pause.example.json src/config/pause.json"
    );
    process.exit(1);
  }

  const config: PauseConfig = JSON.parse(
    fs.readFileSync(configPath, "utf-8")
  );
  const { network, chain, action } = config;

  // --- Validation ---
  validateNetwork(network, "network");
  validateRequiredString(chain.name, "chain.name");
  validateRpcUrl(chain.rpcUrl, "chain.rpcUrl");
  validateRequiredString(chain.wormholeChain, "chain.wormholeChain");
  validateEvmChainId(chain.evmChainId, "chain.evmChainId");
  validateAddress(chain.safeAddress, "chain.safeAddress");
  validateAddress(chain.nttManager, "chain.nttManager");
  validateAddress(chain.wormholeTransceiver, "chain.wormholeTransceiver");

  if (action !== "pause" && action !== "unpause") {
    throw new Error(
      `Invalid action: "${action}" - must be "pause" or "unpause"`
    );
  }

  const ntt = await createNttClient({
    rpcUrl: chain.rpcUrl,
    network,
    wormholeChain: chain.wormholeChain,
    manager: chain.nttManager,
    transceiver: chain.wormholeTransceiver,
  });

  const tx = await extractSafeTx(
    action === "pause" ? ntt.pause() : ntt.unpause(),
    ntt.manager
  );

  const batch = createSafeBatch({
    chainId: chain.evmChainId,
    name: `${action === "pause" ? "Pause" : "Unpause"} NTT on ${chain.name}`,
    description: `${action === "pause" ? "Pause" : "Unpause"} the NTT Manager on ${chain.name}.`,
    safeAddress: chain.safeAddress,
    transactions: [tx],
  });

  const outputDir = path.resolve(__dirname, "../../output");
  fs.mkdirSync(outputDir, { recursive: true });

  const outputFile = path.join(
    outputDir,
    `${action}-ntt-${slugify(chain.name)}.json`
  );
  fs.writeFileSync(outputFile, JSON.stringify(batch, null, 2) + "\n");

  console.log(`\nGenerated batch for ${chain.name}:`);
  console.log(`  File: ${outputFile}`);
  console.log(`  NTT Manager: ${chain.nttManager}`);
  console.log(`  Action: ${action}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
