import { contracts, toUniversal } from "@wormhole-foundation/sdk";
import type { Chain, Network } from "@wormhole-foundation/sdk";
import { EvmNtt, register } from "@wormhole-foundation/sdk-evm-ntt";
import { ethers } from "ethers";
import type { SafeBatchTransaction } from "./safeBatchBuilder";

register();

/**
 * Creates an EvmNtt instance from the Wormhole SDK.
 */
export async function createNttClient(params: {
  rpcUrl: string;
  network: string;
  wormholeChain: string;
  manager: string;
  transceiver: string;
}): Promise<EvmNtt<any, any>> {
  const provider = new ethers.JsonRpcProvider(params.rpcUrl);
  const coreBridge = contracts.coreBridge(
    params.network as any,
    params.wormholeChain as any
  );

  return new EvmNtt(
    params.network as any,
    params.wormholeChain as any,
    provider,
    {
      coreBridge,
      ntt: {
        manager: params.manager,
        token: "",
        transceiver: { wormhole: params.transceiver },
      },
    }
  );
}

/**
 * Extracts a SafeBatchTransaction from an SDK async generator.
 * Decodes the calldata using the contract's ABI for human-readable Safe UI metadata.
 */
export async function extractSafeTx(
  generator: AsyncGenerator<any>,
  contract: ethers.BaseContract
): Promise<SafeBatchTransaction> {
  const result = await generator.next();
  if (result.done || !result.value) {
    throw new Error("Generator yielded no transaction");
  }

  const rawTx = result.value.transaction;
  const data =
    typeof rawTx.data === "string"
      ? rawTx.data
      : ethers.hexlify(rawTx.data);
  const to = rawTx.to;
  const value = rawTx.value?.toString() || "0";

  const safeTx: SafeBatchTransaction = { to, value, data };

  // Decode calldata for Safe UI metadata
  const decoded = contract.interface.parseTransaction({ data });
  if (decoded) {
    safeTx.contractMethod = {
      inputs: decoded.fragment.inputs.map((input) => ({
        internalType: input.type,
        name: input.name,
        type: input.type,
      })),
      name: decoded.fragment.name,
      payable: decoded.fragment.payable,
    };
    safeTx.contractInputsValues = {};
    decoded.fragment.inputs.forEach((input, i) => {
      safeTx.contractInputsValues![input.name] = decoded.args[i].toString();
    });
  }

  return safeTx;
}

export { toUniversal };
export type { Chain, Network };
