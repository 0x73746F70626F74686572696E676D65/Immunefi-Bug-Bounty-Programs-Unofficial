import { BN } from "@coral-xyz/anchor";
import { PublicKey } from "@solana/web3.js";

export type FillType = {
    unset?: {};
    wormholeCctpDeposit?: {};
    fastFill?: {};
};

export type PreparedFillSeeds = {
    fillSource: PublicKey;
    bump: number;
};

export type PreparedFillInfo = {
    preparedCustodyTokenBump: number;
    preparedBy: PublicKey;
    fillType: FillType;
    sourceChain: number;
    orderSender: Array<number>;
    redeemer: PublicKey;
    timestamp: BN;
};

export class PreparedFill {
    seeds: PreparedFillSeeds;
    info: PreparedFillInfo;
    redeemerMessage: Buffer;

    constructor(seeds: PreparedFillSeeds, info: PreparedFillInfo, redeemerMessage: Buffer) {
        this.seeds = seeds;
        this.info = info;
        this.redeemerMessage = redeemerMessage;
    }

    static address(programId: PublicKey, fillSource: PublicKey) {
        return PublicKey.findProgramAddressSync(
            [Buffer.from("fill"), fillSource.toBuffer()],
            programId,
        )[0];
    }
}
