import { getLatestBlock, getLatestBlockNumber, getTimestampBySolanaSlot } from "./blocks";
import { Chain } from "@defillama/sdk/build/general";
import { sql } from "./db";
import { getBridgeID } from "./wrappa/postgres/query";
import { insertTransactionRow, insertConfigRow, insertErrorRow } from "./wrappa/postgres/write";
import bridgeNetworks from "../data/bridgeNetworkData";
import adapters from "../adapters";
import { maxBlocksToQueryByChain, nonBlocksChains } from "./constants";
import { BridgeAdapter, AsyncBridgeAdapter } from "../helpers/bridgeAdapter.type";
import { getCurrentUnixTimestamp } from "./date";
import type { RecordedBlocks } from "./types";
import { wait } from "../helpers/etherscan";
import { lookupBlock } from "@defillama/sdk/build/util";
import { BridgeNetwork } from "../data/types";
import { groupBy } from "lodash";
import { getProvider } from "./provider";
import { sendDiscordText } from "./discord";
import { getConnection } from "../helpers/solana";
import { chainMappings } from "../helpers/tokenMappings";
import { getCache, setCache } from "./cache";
const retry = require("async-retry");

const SECONDS_IN_DAY = 86400;

interface AdapterProgress {
  lastSuccessfulBlock: number;
  lastUpdated: number;
}

const getProgressKey = (bridgeDbName: string, chain: string) =>
  `adapter_progress:${bridgeDbName.toLowerCase()}:${chain.toLowerCase()}`;

const getAdapterProgress = async (bridgeDbName: string, chain: string): Promise<AdapterProgress | null> => {
  return await getCache(getProgressKey(bridgeDbName, chain));
};

const PROGRESS_TTL = 60 * 60 * 24 * 7; // 7 days

const setAdapterProgress = async (bridgeDbName: string, chain: string, lastBlock: number): Promise<void> => {
  const key = getProgressKey(bridgeDbName, chain);
  const current = await getAdapterProgress(bridgeDbName, chain);
  if (current?.lastSuccessfulBlock && current.lastSuccessfulBlock >= lastBlock) {
    return;
  }
  await setCache(
    key,
    {
      lastSuccessfulBlock: lastBlock,
      lastUpdated: Math.floor(Date.now() / 1000),
    },
    PROGRESS_TTL
  );
};

// FIX timeout problems throughout functions here

const getBlocksForRunningAdapter = async (
  bridgeDbName: string,
  chain: string,
  chainContractsAreOn: string,
  recordedBlocks?: Partial<RecordedBlocks>
) => {
  const currentTimestamp = await getCurrentUnixTimestamp();
  // todo: fix this line
  const useChainBlocks = !nonBlocksChains.includes(chainContractsAreOn);
  let startBlock = undefined;
  let endBlock = undefined;
  let useRecordedBlocks = undefined;
  if (useChainBlocks) {
    // probably need timeouts here
    try {
      if (bridgeDbName === "ibc") {
        endBlock = await getLatestBlockNumber(chainContractsAreOn, bridgeDbName);
      } else {
        endBlock = await getLatestBlockNumber(chainContractsAreOn);
      }

      if (!endBlock) {
        const errString = `Unable to get blocks for ${bridgeDbName} adapter on chain ${chainContractsAreOn}. `;
        await insertErrorRow({
          ts: currentTimestamp,
          target_table: "transactions",
          keyword: "data",
          error: errString,
        });
        console.error(errString);
        return { startBlock, endBlock, useRecordedBlocks };
      }
    } catch (e: any) {
      console.error(
        `Error getting latest block on ${chainContractsAreOn} for ${bridgeDbName} adapter. Error: ${JSON.stringify(e)}`
      );
      return { startBlock, endBlock, useRecordedBlocks };
    }
    const maxBlocksToQuery = (maxBlocksToQueryByChain[chainContractsAreOn] ?? maxBlocksToQueryByChain.default) * 4;
    let lastRecordedEndBlock = recordedBlocks?.endBlock;
    if (!lastRecordedEndBlock) {
      const defaultStartBlock = endBlock - maxBlocksToQuery;
      lastRecordedEndBlock = defaultStartBlock;
      console.log(
        `Adapter for ${bridgeDbName} is missing recordedBlocks entry for chain ${chain}. Starting at block ${
          lastRecordedEndBlock + 1
        }.`
      );
    }

    const cachedProgress = await getAdapterProgress(bridgeDbName, chain);
    if (cachedProgress?.lastSuccessfulBlock && cachedProgress.lastSuccessfulBlock > lastRecordedEndBlock) {
      console.log(
        `[PROGRESS] Using Redis progress for ${bridgeDbName}:${chain}, advancing from block ${lastRecordedEndBlock} to ${cachedProgress.lastSuccessfulBlock}`
      );
      lastRecordedEndBlock = cachedProgress.lastSuccessfulBlock;
    }

    startBlock = lastRecordedEndBlock + 1;
    useRecordedBlocks = true;
  } else {
    startBlock = 0;
    endBlock = 1;
    useRecordedBlocks = false;
  }
  return { startBlock, endBlock, useRecordedBlocks };
};

export const runAdapterToCurrentBlock = async (
  bridgeNetwork: BridgeNetwork,
  allowNullTxValues: boolean = false,
  onConflict: "ignore" | "error" | "upsert" = "error",
  lastRecordedBlocks: Record<string, RecordedBlocks> = {}
) => {
  const currentTimestamp = getCurrentUnixTimestamp() * 1000;
  const { id, bridgeDbName } = bridgeNetwork;

  let adapter = adapters[bridgeDbName];
  adapter = isAsyncAdapter(adapter) ? await adapter.build() : adapter;
  if (!adapter) {
    const errString = `Adapter for ${bridgeDbName} not found, check it is exported correctly.`;
    console.error(`[ERROR] ${errString}`);
    await insertErrorRow({
      ts: currentTimestamp,
      target_table: "transactions",
      keyword: "critical",
      error: errString,
    });
    throw new Error(errString);
  }

  try {
    await insertConfigEntriesForAdapter(adapter, bridgeDbName, bridgeNetwork?.destinationChain);
  } catch (e: any) {
    console.error(`[ERROR] Failed to insert config entries for ${bridgeDbName}. Error: ${e.message}`);
    await insertErrorRow({
      ts: currentTimestamp,
      target_table: "config",
      keyword: "error",
      error: `Failed to insert config entries: ${e.message}`,
    });
  }

  const adapterPromises = Promise.all(
    Object.keys(adapter).map(async (chain, i) => {
      await wait(200 * i);
      const chainContractsAreOn = chainMappings[chain as Chain] ? chainMappings[chain as Chain] : chain;

      let bridgeID: string;
      try {
        bridgeID = (await getBridgeID(bridgeDbName, chain))?.id;
        if (!bridgeID) {
          throw new Error(`BridgeID not found for ${bridgeDbName} on chain ${chain}`);
        }
      } catch (e: any) {
        console.error(`[ERROR] Failed to get bridgeID for ${bridgeDbName} on chain ${chain}. Error: ${e.message}`);
        await insertErrorRow({
          ts: currentTimestamp,
          target_table: "transactions",
          keyword: "error",
          error: `Failed to get bridgeID: ${e.message}`,
        });
        return;
      }

      let { startBlock, endBlock } = await getBlocksForRunningAdapter(
        bridgeDbName,
        chain,
        chainContractsAreOn,
        lastRecordedBlocks[bridgeID]
      );
      if (startBlock === undefined || endBlock === undefined) {
        console.warn(`[WARN] Skipping ${bridgeDbName} on ${chain} because blocks are undefined.`);
        return;
      }
      const step = maxBlocksToQueryByChain[chainContractsAreOn] || maxBlocksToQueryByChain.default;

      if (startBlock == null) return;
      try {
        while (startBlock < endBlock) {
          let toBlock = startBlock + step > endBlock ? endBlock : startBlock + step;
          await runAdapterHistorical(startBlock, toBlock, id, chain as Chain, allowNullTxValues, true, onConflict);
          startBlock += step;
        }
      } catch (e: any) {
        const errString = `Adapter txs for ${bridgeDbName} on chain ${chain} failed. Error: ${e.message}`;
        console.error(`[ERROR] ${errString}`, e);
        await insertErrorRow({
          ts: currentTimestamp,
          target_table: "transactions",
          keyword: "data",
          error: errString,
        });
      }
    })
  );

  try {
    await adapterPromises;
  } catch (e: any) {
    console.error(`[ERROR] Error in adapter promises for ${bridgeDbName}. Error: ${e.message}`);
    await insertErrorRow({
      ts: currentTimestamp,
      target_table: "transactions",
      keyword: "error",
      error: `Error in adapter promises: ${e.message}`,
    });
  }
};

export const runAllAdaptersToCurrentBlock = async (
  allowNullTxValues: boolean = false,
  onConflict: "ignore" | "error" | "upsert" = "error"
) => {
  const currentTimestamp = getCurrentUnixTimestamp() * 1000;

  for (const bridgeNetwork of bridgeNetworks) {
    const { id, bridgeDbName } = bridgeNetwork;
    let adapter = adapters[bridgeDbName];
    adapter = isAsyncAdapter(adapter) ? await adapter.build() : adapter;
    if (!adapter) {
      const errString = `Adapter for ${bridgeDbName} not found, check it is exported correctly.`;
      await insertErrorRow({
        ts: currentTimestamp,
        target_table: "transactions",
        keyword: "critical",
        error: errString,
      });
      throw new Error(errString);
    }
    await insertConfigEntriesForAdapter(adapter, bridgeDbName, bridgeNetwork?.destinationChain);
    const adapterPromises = Promise.all(
      Object.keys(adapter).map(async (chain, i) => {
        await wait(200 * i);
        const chainContractsAreOn = chainMappings[chain as Chain] ? chainMappings[chain as Chain] : chain;
        const { startBlock, endBlock } = await getBlocksForRunningAdapter(
          bridgeDbName,
          chain,
          chainContractsAreOn,
          {}
        );
        if (startBlock == null) return;
        try {
          await runAdapterHistorical(startBlock, endBlock, id, chain as Chain, allowNullTxValues, true, onConflict);
        } catch (e: any) {
          const errString = `Adapter txs for ${bridgeDbName} on chain ${chain} failed, skipped. ${JSON.stringify(e)}`;
          await insertErrorRow({
            ts: currentTimestamp,
            target_table: "transactions",
            keyword: "data",
            error: errString,
          });
          console.error(errString, e);
        }
      })
    );
    await adapterPromises;
  }
  console.log("runAllAdaptersToCurrentBlock successfully ran.");
};

export const runAllAdaptersTimestampRange = async (
  allowNullTxValues: boolean = false,
  onConflict: "ignore" | "error" | "upsert" = "error",
  startTimestamp: number,
  endTimestamp: number
) => {
  for (const bridgeNetwork of bridgeNetworks) {
    const { id, bridgeDbName } = bridgeNetwork;
    let adapter = adapters[bridgeDbName];
    adapter = isAsyncAdapter(adapter) ? await adapter.build() : adapter;
    if (!adapter) {
      const errString = `Adapter for ${bridgeDbName} not found, check it is exported correctly.`;
      await insertErrorRow({
        ts: getCurrentUnixTimestamp() * 1000,
        target_table: "transactions",
        keyword: "critical",
        error: errString,
      });
      throw new Error(errString);
    }
    await insertConfigEntriesForAdapter(adapter, bridgeDbName, bridgeNetwork?.destinationChain);
    const adapterPromises = Promise.all(
      Object.keys(adapter).map(async (chain, i) => {
        await wait(200 * i);
        const chainContractsAreOn = chainMappings[chain as Chain] ? chainMappings[chain as Chain] : chain;
        if (chainContractsAreOn === "tron" || chainContractsAreOn === "sui" || chainContractsAreOn === "solana") {
          console.info(`Skipping running adapter ${bridgeDbName} on chain ${chainContractsAreOn}.`);
          return;
        }
        const useChainBlocks = !(nonBlocksChains.includes(chainContractsAreOn) || ["ibc"].includes(bridgeDbName));
        try {
          let startBlock = 0;
          let endBlock = 1;
          if (useChainBlocks) {
            startBlock = (await lookupBlock(startTimestamp, { chain: chainContractsAreOn as Chain })).block;
            endBlock = (await lookupBlock(endTimestamp, { chain: chainContractsAreOn as Chain })).block;
          }
          await runAdapterHistorical(
            startBlock,
            endBlock,
            id,
            chain as Chain,
            allowNullTxValues,
            true,
            onConflict,
            false
          );
        } catch (e: any) {
          const errString = `Adapter txs for ${bridgeDbName} on chain ${chain} failed, skipped. ${JSON.stringify(e)}`;
          await insertErrorRow({
            ts: getCurrentUnixTimestamp() * 1000,
            target_table: "transactions",
            keyword: "data",
            error: errString,
          });
          console.error(errString, e);
        }
      })
    );
    await adapterPromises;
  }
  // need better error catching
  console.log("runAllAdaptersTimestampRange successfully ran.");
};

const bridgesToSkip = [
  "wormhole",
  "layerzero",
  "hyperlane",
  "intersoon",
  "relay",
  "cashmere",
  "teleswap",
  "mayan",
  "ccip",
];

export const runAdapterHistorical = async (
  startBlock: number,
  endBlock: number,
  bridgeNetworkId: number,
  chain: string,
  allowNullTxValues: boolean = false,
  throwOnFailedInsert: boolean = true,
  onConflict: "ignore" | "error" | "upsert" = "error",
  updateProgress: boolean = true
) => {
  const currentTimestamp = await getCurrentUnixTimestamp();
  const bridgeNetwork = bridgeNetworks.filter((bridgeNetwork) => bridgeNetwork.id === bridgeNetworkId)[0];
  const { bridgeDbName, displayName } = bridgeNetwork;

  if (bridgesToSkip.includes(bridgeDbName)) {
    return;
  }

  const cachedProgress = await getAdapterProgress(bridgeDbName, chain);
  if (cachedProgress?.lastSuccessfulBlock) {
    if (cachedProgress.lastSuccessfulBlock >= endBlock) {
      console.log(
        `[SKIP] ${bridgeDbName}:${chain} blocks ${startBlock}-${endBlock} already processed (last: ${cachedProgress.lastSuccessfulBlock})`
      );
      return;
    }
    if (cachedProgress.lastSuccessfulBlock >= startBlock) {
      const newStart = cachedProgress.lastSuccessfulBlock + 1;
      console.log(
        `[PROGRESS] ${bridgeDbName}:${chain} adjusting start from ${startBlock} to ${newStart} (last: ${cachedProgress.lastSuccessfulBlock})`
      );
      startBlock = newStart;
    }
  }

  let adapter = adapters[bridgeDbName];
  adapter = isAsyncAdapter(adapter) ? await adapter.build() : adapter;

  const adapterChainEventsFn = adapter[chain];
  if (chain?.toLowerCase() === bridgeNetwork.destinationChain?.toLowerCase() && !adapterChainEventsFn) {
    return;
  }
  if (!adapter) {
    const errString = `Adapter for ${bridgeDbName} not found, check it is exported correctly.`;
    await insertErrorRow({
      ts: getCurrentUnixTimestamp() * 1000,
      target_table: "transactions",
      keyword: "critical",
      error: errString,
    });
    throw new Error(errString);
  }
  try {
    await insertConfigEntriesForAdapter(adapter, bridgeDbName, bridgeNetwork?.destinationChain);
  } catch (e: any) {
    console.error(`[ERROR] Failed to insert config entries for ${bridgeDbName}. Error: ${e.message}`);
    await insertErrorRow({
      ts: getCurrentUnixTimestamp() * 1000,
      target_table: "config",
      keyword: "error",
      error: `Failed to insert config entries: ${e.message}`,
    });
  }

  if (!adapterChainEventsFn && chain?.toLowerCase() !== bridgeNetwork.destinationChain?.toLowerCase()) {
    const errString = `Chain ${chain} not found on adapter ${bridgeDbName}.`;
    await insertErrorRow({
      ts: getCurrentUnixTimestamp() * 1000,
      target_table: "transactions",
      keyword: "critical",
      error: errString,
    });
    throw new Error(errString);
  }
  const chainContractsAreOn = chainMappings[chain as Chain] ? chainMappings[chain as Chain] : chain;

  const bridgeID = (await getBridgeID(bridgeDbName, chain))?.id;
  if (!bridgeID) {
    const errString = `${bridgeDbName} on chain ${chain} is missing in config table.`;
    await insertErrorRow({
      ts: getCurrentUnixTimestamp() * 1000,
      target_table: "transactions",
      keyword: "critical",
      error: errString,
    });
    throw new Error(errString);
  }
  let maxBlocksToQuery = maxBlocksToQueryByChain[chainContractsAreOn]
    ? maxBlocksToQueryByChain[chainContractsAreOn]
    : maxBlocksToQueryByChain.default;

  if (bridgeDbName === "ibc") {
    maxBlocksToQuery = 400;
  }

  const useChainBlocks = !(nonBlocksChains.includes(chainContractsAreOn) || ["ibc"].includes(bridgeDbName));

  let block = startBlock;
  while (block < endBlock) {
    await wait(500);
    const endBlockForQuery = block + maxBlocksToQuery > endBlock ? endBlock : block + maxBlocksToQuery;

    let retryCount = 0;
    const maxRetries = 3;
    while (retryCount < maxRetries) {
      try {
        const eventLogs = await retry(
          () =>
            adapterChainEventsFn(block, endBlockForQuery).catch((e) => {
              console.error(
                `[ERROR] Failed to fetch event logs for ${bridgeDbName} on ${chain} from ${block} to ${endBlockForQuery}. Error: ${e.message}`
              );
              throw e;
            }),
          { retries: 4, factor: 2 }
        );

        if (!eventLogs || eventLogs.length === 0) {
          if (updateProgress) {
            await setAdapterProgress(bridgeDbName, chain, endBlockForQuery);
          }
          break;
        }

        let provider = undefined as any;
        if (useChainBlocks) {
          provider = getProvider(chainContractsAreOn as Chain);
          if (!provider) {
            const errString = `Could not get provider for chain ${chainContractsAreOn}.`;
            await insertErrorRow({
              ts: getCurrentUnixTimestamp() * 1000,
              target_table: "transactions",
              keyword: "critical",
              error: errString,
            });
            throw new Error(errString);
          }
        }

        await retry(
          async () => {
            await sql.begin(async (sql) => {
              let txBlocks = [] as number[];
              eventLogs.forEach((log: any) => {
                const { blockNumber } = log;
                txBlocks.push(blockNumber);
              });

              let minBlock = 0;
              let maxBlock = 0;
              if (txBlocks.length > 0) {
                minBlock = Math.min(...txBlocks) ?? 0;
                maxBlock = Math.max(...txBlocks) ?? 0;
              }
              const blockRange = maxBlock - minBlock || 1;
              let blockTimestamps = {} as { [bucket: number]: number };
              let block = {} as { timestamp: number; number: number };

              let latestSolanaBlock = null;
              let averageBlockTimestamp = null;

              let solanaTimestampsMap = {} as { [blockNumber: number]: number };

              if (chain === "solana" && !["debridgedln", "portal", "garden", "relay"].includes(bridgeDbName)) {
                latestSolanaBlock = await getLatestBlock("solana");
                const connection = getConnection();

                const blockTimePromises = eventLogs.map(async (event: any) => {
                  const blockTime = await retry(async () => connection.getBlockTime(event.blockNumber), { retries: 3 });
                  return { blockNumber: event.blockNumber, blockTime, chainOverride: event.chainOverride };
                });

                const results = await Promise.all(blockTimePromises);

                results.forEach(({ blockNumber, blockTime, chainOverride: _chainOverride }) => {
                  solanaTimestampsMap[blockNumber] = blockTime ?? 0;
                });
              }

              for (let i = 0; i < 10; i++) {
                const blockNumber = Math.floor(minBlock + i * (blockRange / 10));
                for (let j = 0; j < 4; j++) {
                  try {
                    if (useChainBlocks && chain !== "solana") {
                      await wait(100);
                      block = await retry(async () => provider.getBlock(blockNumber), { retries: 3 });
                      if (block.timestamp) {
                        blockTimestamps[i] = block.timestamp;
                        break;
                      }
                    } else if (chain === "solana") {
                      blockTimestamps[i] = averageBlockTimestamp as any;
                      break;
                    } else {
                      blockTimestamps[i] = currentTimestamp;
                      break;
                    }
                  } catch (e: any) {
                    if (j >= 3) {
                      console.error(
                        `[ERROR] Failed to get block for block number ${blockNumber} on chain ${chainContractsAreOn}. Error: ${JSON.stringify(
                          e
                        )}`
                      );
                      throw new Error(
                        `Failed to get block timestamps at block number ${blockNumber} on chain ${chainContractsAreOn}`
                      );
                    }
                  }
                }
              }

              const groupedEvents = groupBy(eventLogs, (event: any) => event?.txHash);
              const filteredEvents = Object.values(groupedEvents)
                .filter((events) => events.length < 100)
                .flat();
              let storedBridgeIds = {} as { [chain: string]: string };
              for (let i = 0; i < filteredEvents?.length; i++) {
                let log = filteredEvents[i];

                const {
                  txHash,
                  blockNumber,
                  from,
                  to,
                  token,
                  amount,
                  isDeposit,
                  chainOverride,
                  isUSDVolume,
                  txsCountedAs,
                  originChain,
                  timestamp: realBlockTimestamp,
                } = log;
                const bucket = Math.floor(((blockNumber - minBlock) * 9) / blockRange);
                const timestamp = (blockTimestamps[bucket] ?? 0) * 1000;

                let amountString = amount ? amount.toString() : "0";

                let bridgeIdOverride = bridgeID;
                if (chainOverride) {
                  const storedBridgeID = storedBridgeIds[chainOverride];
                  if (storedBridgeID) {
                    bridgeIdOverride = storedBridgeID;
                  } else {
                    const overrideID = (await retry(async () => getBridgeID(bridgeDbName, chainOverride)))?.id;
                    bridgeIdOverride = overrideID;
                    storedBridgeIds[chainOverride] = overrideID;
                    if (!overrideID) {
                      const errString = `${bridgeDbName} on chain ${chainOverride} is missing in config table.`;
                      await insertErrorRow({
                        ts: getCurrentUnixTimestamp() * 1000,
                        target_table: "transactions",
                        keyword: "critical",
                        error: errString,
                      });
                      throw new Error(errString);
                    }
                  }
                }
                if (!from || !to) continue;
                if (
                  from?.toLowerCase() === "0x0000000000000000000000000000000000000000" ||
                  to?.toLowerCase() === "0x0000000000000000000000000000000000000000"
                )
                  continue;

                await retry(
                  async () => {
                    await insertTransactionRow(
                      sql,
                      allowNullTxValues,
                      {
                        bridge_id: bridgeIdOverride,
                        chain: chainOverride ?? chainContractsAreOn,
                        tx_hash: txHash ?? null,
                        ts: solanaTimestampsMap[blockNumber] ?? realBlockTimestamp ?? timestamp,
                        tx_block: blockNumber ?? null,
                        tx_from: from ?? null,
                        tx_to: to ?? null,
                        token: token,
                        amount: amountString,
                        is_deposit: isDeposit,
                        is_usd_volume: isUSDVolume ?? false,
                        txs_counted_as: txsCountedAs ?? 0,
                        origin_chain: originChain ?? null,
                      },
                      onConflict
                    );
                  },
                  { retries: 3, factor: 2 }
                ).catch((e: any) => {
                  console.error(
                    `[ERROR] Failed to insert transaction row for ${bridgeDbName} on ${chain} after retries. Error: ${e}`
                  );
                  throw e;
                });
              }
            });
          },
          { retries: 3, factor: 2 }
        );

        if (updateProgress) {
          await setAdapterProgress(bridgeDbName, chain, endBlockForQuery);
        }
        break;
      } catch (e: any) {
        retryCount++;
        console.error(
          `[ERROR] Attempt ${retryCount} failed for ${bridgeDbName} on ${chain} for blocks ${block}-${endBlockForQuery}. Error: ${e.message}`
        );

        if (retryCount >= maxRetries) {
          const errString = `Adapter for ${bridgeDbName} failed to get and insert logs for chain ${chain} for blocks ${block}-${endBlockForQuery} after ${maxRetries} attempts. ${e.message}`;
          console.error(`[ERROR] ${errString}`);
          await insertErrorRow({
            ts: getCurrentUnixTimestamp() * 1000,
            target_table: "transactions",
            keyword: "missingBlocks",
            error: errString,
          });
          await sendDiscordText(errString);
          if (throwOnFailedInsert) {
            throw new Error(errString);
          }
          break;
        } else {
          await wait(1000 * retryCount);
        }
      }
    }
    block = endBlockForQuery;
  }
};

export const insertConfigEntriesForAdapter = async (
  adapter: BridgeAdapter,
  bridgeDbName: string,
  destinationChain?: string
) => {
  await Promise.all(
    Object.keys(adapter).map(async (chain) => {
      const existingEntry = await getBridgeID(bridgeDbName, chain);
      if (existingEntry) {
        return;
      }
      return sql.begin(async (sql) => {
        return insertConfigRow(sql, {
          bridge_name: bridgeDbName,
          chain: chain,
          destination_chain: destinationChain,
        });
      });
    })
  );
};

export function isAsyncAdapter(adapter: BridgeAdapter | AsyncBridgeAdapter): adapter is AsyncBridgeAdapter {
  return (adapter as AsyncBridgeAdapter).isAsync;
}
