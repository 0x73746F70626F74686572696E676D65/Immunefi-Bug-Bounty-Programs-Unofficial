import { IResponse, successResponse, errorResponse } from "../utils/lambda-response";
import wrap from "../utils/wrap";
import { getCurrentUnixTimestamp, getTimestampAtStartOfDay } from "../utils/date";
import {
  queryAggregatedDailyTimestampRange,
  queryAggregatedTokensInRange,
  queryConfig,
} from "../utils/wrappa/postgres/query";
import { getLlamaPrices } from "../utils/prices";
import { importBridgeNetwork } from "../data/importBridgeNetwork";
import BigNumber from "bignumber.js";
import { normalizeChain, normlizeTokenSymbol } from "../utils/normalizeChain";
import { getCache } from "../utils/cache";

const numberOfTokensToReturn = 30; // also determines # of addresses returned

// the following 2 types should probably be combined
type TokenRecord = {
  [token: string]: {
    amount: string;
    usdValue: number;
    symbol?: string;
    decimals?: number;
  };
};

type TokenRecordBn = {
  [token: string]: {
    amountBn: BigNumber;
  };
};

type AddressRecord = {
  [address: string]: {
    usdValue: number;
    txs: number;
  };
};

interface IAggregatedData {
  bridge_id: string;
  ts: Date;
  total_tokens_deposited: string[];
  total_tokens_withdrawn: string[];
  total_deposited_usd: string;
  total_withdrawn_usd: string;
  total_deposit_txs: number;
  total_withdrawal_txs: number;
  total_address_deposited: string[];
  total_address_withdrawn: string[];
}

const sumTokenTxs = async (
	tokenTotals: string[],
	dailyTokensRecord: TokenRecord,
	  prices: Record<string, any>,
	lzSymbols: Record<string, string>
) => {
  if (!tokenTotals) return;
  let dailyTokensRecordBn = {} as TokenRecordBn;
  


  tokenTotals.map((tokenString) => {
    const tokenData = tokenString.replace(/[('") ]/g, "").split(",");
    const token = tokenData[0];
    
    const amountBn = BigNumber(tokenData[1]);
    const usdValue = parseFloat(tokenData[2]);
    dailyTokensRecordBn[token] = dailyTokensRecordBn[token] || {};
    dailyTokensRecordBn[token].amountBn = dailyTokensRecordBn[token].amountBn
      ? dailyTokensRecordBn[token].amountBn.plus(amountBn)
      : BigNumber(amountBn);
    dailyTokensRecord[token] = dailyTokensRecord[token] || {};
    dailyTokensRecord[token].usdValue = (dailyTokensRecord[token].usdValue ?? 0) + usdValue;
  });
  Object.entries(dailyTokensRecordBn).map(([token, tokenData]) => {
    dailyTokensRecord[token].amount = tokenData.amountBn?.toFixed() ?? "0";
    const key = token?.toLowerCase?.() ?? token;
    const priceEntry = prices?.[key] ?? prices?.[token];
    const addrOnly = key.includes(":") ? key.split(":")[1] : key;
    const fallbackSymbol = lzSymbols?.[addrOnly] ?? lzSymbols?.[key] ?? "";
    const symbol = priceEntry?.symbol ?? fallbackSymbol ?? "";
    dailyTokensRecord[token].symbol = normlizeTokenSymbol(symbol);
    const decimalsVal = priceEntry?.decimals;
    dailyTokensRecord[token].decimals = typeof decimalsVal === "string" ? Number(decimalsVal) : decimalsVal ?? 0;
  });
};

const sumAddressTxs = (addressTotals: string[], dailyAddresssRecord: AddressRecord) => {
  if (!addressTotals) return;
  addressTotals.map((addressString) => {
    const addressData = addressString.replace(/[('") ]/g, "").split(",");
    const address = addressData[0];
    const usdValue = parseFloat(addressData[1]);
    const txs = parseInt(addressData[2]);
    dailyAddresssRecord[address] = dailyAddresssRecord[address] || {};
    dailyAddresssRecord[address].usdValue = (dailyAddresssRecord[address].usdValue ?? 0) + usdValue;
    dailyAddresssRecord[address].txs = (dailyAddresssRecord[address].txs ?? 0) + txs;
  });
};

// can also return total deposit/withdraw USD, deposit/withdraw #txs here if needed
// don't let chain be 'all'
const getBridgeStatsOnDay = async (timestamp: string = "0", chain: string, bridgeId?: string) => {
  let bridgeDbName = undefined as any;
  const queryChain = chain === "" ? "" : normalizeChain(chain);
  if (!bridgeId) {
    bridgeDbName = undefined;
  } else {
    try {
      const bridgeNetwork = importBridgeNetwork(undefined, parseInt(bridgeId));
      if (!bridgeNetwork) {
        throw new Error("No bridge network found.");
      }
      ({ bridgeDbName } = bridgeNetwork);
    } catch (e) {
      return errorResponse({
        message: "Invalid bridgeId entered.",
      });
    }
  }

  const sourceChainConfigs = (await queryConfig(undefined, undefined, queryChain)).filter((config) => {
    if (bridgeId) {
      return config.bridge_name === bridgeDbName;
    }
    return true;
  });

  const queryTimestamp = getTimestampAtStartOfDay(parseInt(timestamp));
  const maxEndTimestamp = queryTimestamp + 86400;
  const currentTimestamp = getCurrentUnixTimestamp();
  const endTimestamp = Math.max(queryTimestamp, Math.min(maxEndTimestamp, currentTimestamp));

  let sourceChainsDailyData = [] as IAggregatedData[];
  await Promise.all(
    sourceChainConfigs.map(async (config) => {
      const sourceChainData = await queryAggregatedDailyTimestampRange(
        queryTimestamp,
        endTimestamp,
        config.chain,
        config.bridge_name
      );
      sourceChainsDailyData.push(...sourceChainData);
    })
  );

  const dailyData = await queryAggregatedTokensInRange(queryTimestamp, endTimestamp, queryChain, bridgeDbName);
  let dailyTokensDeposited = {} as TokenRecord;
  let dailyTokensWithdrawn = {} as TokenRecord;
  let dailyAddressesDeposited = {} as AddressRecord;
  let dailyAddressesWithdrawn = {} as AddressRecord;
  const lzSymbols = ((await getCache("lz_token_symbols")) || {}) as Record<string, string>;
  
  const allTokenIds = new Set<string>();
  const isValidPriceId = (id?: string) => {
    if (!id) return false;
    if (id.includes("\\") || id.includes("/") || id.includes(" ")) return false;
    const parts = id.split(":");
    if (parts.length !== 2) return false;
    if (!parts[0] || !parts[1]) return false;
    if (parts[1] === "\\N" || parts[1] === "\\n" || parts[1].toLowerCase() === "null" || parts[1].toLowerCase() === "undefined") return false;
    return true;
  };
  const collectTokenIds = (tokenTotals?: string[]) => {
    if (!tokenTotals) return;
    tokenTotals.forEach((tokenString) => {
      const tokenData = tokenString.replace(/[('\") ]/g, "").split(",");
      const tokenId = (tokenData[0] || "").toLowerCase();
      if (isValidPriceId(tokenId)) allTokenIds.add(tokenId);
    });
  };
  dailyData.forEach(({ total_tokens_deposited, total_tokens_withdrawn }) => {
    collectTokenIds(total_tokens_deposited);
    collectTokenIds(total_tokens_withdrawn);
  });
  sourceChainsDailyData.forEach(({ total_tokens_deposited, total_tokens_withdrawn }) => {
    collectTokenIds(total_tokens_deposited);
    collectTokenIds(total_tokens_withdrawn);
  });

  let prices: Record<string, any> = {};
  try {
    prices = (await Promise.race([
      getLlamaPrices(Array.from(allTokenIds)),
      new Promise((resolve) => setTimeout(() => resolve({}), 5000)),
    ])) as Record<string, any>;
  } catch {
    prices = {};
  }

  const dailyDataPromises = Promise.all(
    dailyData.map(async (dayData) => {
      const { total_tokens_deposited, total_tokens_withdrawn, total_address_deposited, total_address_withdrawn } =
        dayData;
      await sumTokenTxs(total_tokens_deposited, dailyTokensDeposited, prices, lzSymbols);
      await sumTokenTxs(total_tokens_withdrawn, dailyTokensWithdrawn, prices, lzSymbols);
      await sumAddressTxs(total_address_deposited, dailyAddressesDeposited);
      await sumAddressTxs(total_address_withdrawn, dailyAddressesWithdrawn);
    })
  );
  await dailyDataPromises;

  const sourceChainsPromises = Promise.all(
    sourceChainsDailyData.map(async (dayData) => {
      const { total_tokens_deposited, total_tokens_withdrawn, total_address_deposited, total_address_withdrawn } =
        dayData;
      await sumTokenTxs(total_tokens_deposited, dailyTokensWithdrawn, prices, lzSymbols);
      await sumTokenTxs(total_tokens_withdrawn, dailyTokensDeposited, prices, lzSymbols);
      await sumAddressTxs(total_address_deposited, dailyAddressesWithdrawn);
      await sumAddressTxs(total_address_withdrawn, dailyAddressesDeposited);
    })
  );
  await sourceChainsPromises;

  const sortedDailyTokensDeposited = Object.fromEntries(
    Object.entries(dailyTokensDeposited)
      .sort((a, b) => {
        return b[1].usdValue - a[1].usdValue;
      })
      .slice(0, numberOfTokensToReturn)
  );
  const sortedDailyTokensWithdrawn = Object.fromEntries(
    Object.entries(dailyTokensWithdrawn)
      .sort((a, b) => {
        return b[1].usdValue - a[1].usdValue;
      })
      .slice(0, numberOfTokensToReturn)
  );
  const sortedDailyAddressesDeposited = Object.fromEntries(
    Object.entries(dailyAddressesDeposited)
      .sort((a, b) => {
        return b[1].usdValue - a[1].usdValue;
      })
      .slice(0, numberOfTokensToReturn)
  );
  const sortedDailyAddressesWithdrawn = Object.fromEntries(
    Object.entries(dailyAddressesWithdrawn)
      .sort((a, b) => {
        return b[1].usdValue - a[1].usdValue;
      })
      .slice(0, numberOfTokensToReturn)
  );

  const response = {
    date: queryTimestamp,
    totalTokensDeposited: sortedDailyTokensDeposited,
    totalTokensWithdrawn: sortedDailyTokensWithdrawn,
    totalAddressDeposited: sortedDailyAddressesDeposited,
    totalAddressWithdrawn: sortedDailyAddressesWithdrawn,
  };

  return response;
};

const handler = async (event: AWSLambda.APIGatewayEvent): Promise<IResponse> => {
  const timestamp = event.pathParameters?.timestamp;
  if (Number(timestamp) % 3600 !== 0) {
    return errorResponse({
      message: "timestamp must be divible by 3600",
    });
  }
  const chain = event.pathParameters?.chain?.toLowerCase() ?? "";
  const bridgeNetworkId = event.queryStringParameters?.id;
  const response = await getBridgeStatsOnDay(timestamp, chain, bridgeNetworkId);
  return successResponse(response, 10 * 60); // 10 mins cache
};

export default wrap(handler);
