'use client';

import WormholeConnect, {
    AutomaticCCTPRoute,
    type config,
} from '@wormhole-foundation/wormhole-connect';
import {
    nttExecutorRoute,
    nttManualRoute,
    type NttRoute,
    type NttExecutorRoute,
} from '@wormhole-foundation/wormhole-connect/ntt';

import generatedConfig from '@/generated/wormhole-config.json';
import { clientConfig } from '@/lib/config';

// Type the NTT config from generated JSON
const nttConfig: NttRoute.Config =
    generatedConfig.nttRoutesConfig as NttRoute.Config;
const tokensConfig: config.TokensConfig =
    generatedConfig.tokensConfig as config.TokensConfig;

// Build routes using the type expected by WormholeConnectConfig
// Note: Type assertion via unknown required due to SDK internal version mismatch between
// wormhole-connect's bundled SDK and the NTT package's SDK types. The types are structurally
// identical at runtime but TypeScript sees them as different due to separate npm package instances.
const routes = [
    AutomaticCCTPRoute,
    // NTT Executor route (automatic/relayed) - primary option
    nttExecutorRoute({ ntt: nttConfig } satisfies NttExecutorRoute.Config),
    // NTT Manual route - fallback option
    nttManualRoute(nttConfig),
] as unknown as config.WormholeConnectConfig['routes'];

const wormholeConfig: config.WormholeConnectConfig = {
    network: generatedConfig.network as 'Mainnet' | 'Testnet',
    chains: generatedConfig.chains as config.WormholeConnectConfig['chains'],
    tokens: [...generatedConfig.tokens, 'USDC'],
    ui: {
        title: 'Wormhole NTT UI - Mainnet',
        defaultInputs: {
            source: { chain: 'Ethereum' },
            destination: { chain: 'Base' },
        },
        walletConnectProjectId: clientConfig.walletConnectProjectId,
    },
    routes,
    tokensConfig,
};

export default function WormholeWidget({
    theme,
}: {
    theme: { mode: 'dark'; primary: string };
}) {
    return <WormholeConnect config={wormholeConfig} theme={theme} />;
}
