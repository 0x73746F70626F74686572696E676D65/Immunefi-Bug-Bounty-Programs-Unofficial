'use client';

import dynamic from 'next/dynamic';
import { wormholeTheme } from '@/lib/theme';

// Dynamic import with SSR disabled - keeps all wormhole-connect value imports client-side only
const WormholeWidget = dynamic(() => import('./WormholeWidget'), { ssr: false });

export default function Home() {
    return (
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '100vh',
                padding: '20px',
                background: wormholeTheme.gradients.background,
                position: 'relative',
            }}
        >
            {/* Gradient orbs for visual interest */}
            <div
                style={{
                    position: 'absolute',
                    top: '-20%',
                    left: '-10%',
                    width: '50%',
                    height: '50%',
                    background: `radial-gradient(circle, ${wormholeTheme.colors.primary}10 0%, transparent 70%)`,
                    filter: 'blur(80px)',
                    pointerEvents: 'none',
                }}
            />
            <div
                style={{
                    position: 'absolute',
                    bottom: '-20%',
                    right: '-10%',
                    width: '50%',
                    height: '50%',
                    background: `radial-gradient(circle, ${wormholeTheme.colors.accent}10 0%, transparent 70%)`,
                    filter: 'blur(80px)',
                    pointerEvents: 'none',
                }}
            />

            {/* Main content */}
            <div
                style={{
                    width: '100%',
                    maxWidth: '480px',
                    position: 'relative',
                    zIndex: 1,
                }}
            >
                <WormholeWidget
                    theme={{
                        mode: 'dark',
                        primary: wormholeTheme.colors.primary,
                    }}
                />
            </div>
        </div>
    );
}
