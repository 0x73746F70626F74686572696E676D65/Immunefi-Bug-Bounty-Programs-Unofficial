import { ContractTableRow } from '../util';
import { NotionPage, NotionPropertyValue, NotionRichText } from './types';

export type ContractRow = ContractTableRow;

export type NotionExtraPropertyConfig = {
  /**
   * Property name inside the Notion database.
   */
  property: string;
  /**
   * Optional label prefix to render before the value.
   */
  label?: string;
};

type ExtractContractRowOptions = {
  chainProperty?: string;
  extraProperties?: NotionExtraPropertyConfig[];
};

export function extractTitle(property: NotionPropertyValue | undefined): string | undefined {
  if (!property || property.type !== 'title' || !Array.isArray(property.title)) return undefined;
  return joinPlainText(property.title);
}

export function extractRichText(property: NotionPropertyValue | undefined): { text: string; href?: string } | undefined {
  if (!property || property.type !== 'rich_text' || !Array.isArray(property.rich_text)) return undefined;

  const text = joinPlainText(property.rich_text);
  if (!text || text.trim().length === 0) return undefined;

  const href = property.rich_text.find((entry) => entry.href)?.href;

  return { text: text.trim(), href };
}

export function extractContractRows(
  pages: NotionPage[],
  propertyName: string,
  options?: ExtractContractRowOptions
): ContractTableRow[] {
  const chainProp = options?.chainProperty ?? 'Chain';
  const extraProps = options?.extraProperties ?? [];
  const rows = new Map<string, ContractTableRow>();

  for (const page of pages) {
    const chainName = extractTitle(page.properties?.[chainProp]);
    if (!chainName) continue;

    const normalizedChain = sanitizeChainName(chainName);

    const property = extractRichText(page.properties?.[propertyName]);
    if (!property) continue;

    const parts = buildContractParts(property.text, page, extraProps);
    if (parts.length === 0) continue;

    const normalized = parts.join('\n');

    const key = normalizedChain.trim();
    const row: ContractRow = {
      chain: key,
      address: normalized,
      href: property.href,
    };

    rows.set(key.toLowerCase(), row);
  }

  return Array.from(rows.values());
}

function joinPlainText(entries: NotionRichText[]): string {
  return entries.map((entry) => entry.plain_text ?? '').join('').trim();
}

function sanitizeChainName(value: string): string {
  return value
    .replace(/\*+$/g, '')
    .replace(/\bTesnet\b/gi, 'Testnet')
    .trim();
}

function buildContractParts(
  primaryValue: string,
  page: NotionPage,
  extraProperties: NotionExtraPropertyConfig[],
): string[] {
  const parts: string[] = [];
  const normalizedPrimary = sanitizeContractValue(primaryValue);

  if (shouldIncludeContractValue(normalizedPrimary)) {
    parts.push(normalizedPrimary);
  }

  for (const extra of extraProperties) {
    const extraValue = extractRichText(page.properties?.[extra.property]);
    if (!extraValue) continue;

    const normalizedExtra = sanitizeContractValue(extraValue.text);
    if (!shouldIncludeContractValue(normalizedExtra)) continue;

    const label = extra.label?.trim();
    parts.push(label && label.length > 0 ? `${label}: ${normalizedExtra}` : normalizedExtra);
  }

  return parts;
}

function sanitizeContractValue(value: string): string {
  const trimmed = value.trim();
  if (!trimmed.endsWith('?')) {
    return trimmed;
  }

  const withoutQuestion = trimmed.slice(0, -1);

  const isHexAddress = /^0x[a-fA-F0-9]{40,64}$/.test(withoutQuestion);
  const isBase58Address = /^[1-9A-HJ-NP-Za-km-z]{32,64}$/.test(withoutQuestion);

  if (isHexAddress || isBase58Address) {
    return withoutQuestion;
  }

  return trimmed;
}

function shouldIncludeContractValue(value: string): boolean {
  const trimmed = value.trim();
  if (trimmed.length === 0) return false;
  const lower = trimmed.toLowerCase();
  if (lower === 'n/a') return false;
  if (/^[-–—]+$/.test(trimmed)) return false;
  return true;
}
