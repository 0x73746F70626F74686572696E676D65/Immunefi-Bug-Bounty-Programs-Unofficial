---
title: Get Started with Multigov
description: Follow this guide to set up your environment and request access to deploy MultiGov contracts for multichain DAO governance using Wormhole messaging.
categories: MultiGov
---

# Get Started with MultiGov

[MultiGov](/docs/products/multigov/overview/){target=\_blank} enables multichain governance using Wormhole messaging. With MultiGov, token holders can create proposals, vote, and execute decisions from any supported chain, eliminating the need to bridge assets or rely on a single governance hub.

This page walks you through the MultiGov deployment flow—from choosing a network to following the appropriate deployment guide.

## Prerequisites

Before deploying MultiGov, you need a governance token deployed on multiple chains (ERC-20 or SPL):

- **EVM chains**:
     - Your token must implement the [`ERC20Votes`](https://docs.openzeppelin.com/contracts/4.x/governance#erc20votes){target=\_blank} standard.
     - It must support `CLOCK_MODE` timestamps for compatibility with cross-chain voting.

- **Solana**:
     - Use an SPL token.
     - Voting eligibility and weight are managed by the [MultiGov staking program](/docs/products/multigov/concepts/architecture/#spoke-solana-staking-program){target=\_blank}.

## Deployment Flow

MultiGov deployments follow a similar structure on both EVM and Solana. This section provides a high-level overview of the end-to-end flow. Each step is explained in more detail in the platform-specific deployment guides linked [below](#next-steps).

[timeline(docs/.snippets/text/products/multigov/deployment-flow-timeline.json)]

## Next Steps

Continue to the deployment guide that matches your governance architecture.

<div class="grid cards" markdown>

-   :octicons-tools-16:{ .lg .middle } **Deploy on EVM Chains**

    ---

    Configure and deploy MultiGov smart contracts to EVM-compatible chains.

    [:custom-arrow: Deploy to EVM Chains](/docs/products/multigov/guides/deploy-to-evm/)

-   :octicons-tools-16:{ .lg .middle } **Deploy on Solana**

    ---

    Launch the Solana staking program and configure spoke chain participation.

    [:custom-arrow: Deploy to Solana](/docs/products/multigov/guides/deploy-to-solana/)

</div>
