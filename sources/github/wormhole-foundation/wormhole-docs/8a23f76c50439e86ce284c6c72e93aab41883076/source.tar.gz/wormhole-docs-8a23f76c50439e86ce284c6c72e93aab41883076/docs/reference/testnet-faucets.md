---
title: Testnet Faucets
description: This page includes resources to quickly find the Testnet tokens you need to deploy and test applications and contracts on Wormhole's supported networks.
categories: Reference
---

# Testnet Faucets

Don't let the need for testnet tokens get in the way of building your next great idea with Wormhole. Use this guide to quickly locate the testnet token faucets you need to deploy and test applications and contracts on Wormhole's supported networks.

--8<-- 'text/reference/testnet-faucets/testnet-faucets.md'
