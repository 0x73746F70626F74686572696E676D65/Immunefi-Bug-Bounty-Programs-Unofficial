export type TokenDispenser = {
  version: '0.1.0'
  name: 'token_dispenser'
  instructions: [
    {
      name: 'initialize'
      docs: [
        'This can only be called once and should be called right after the program is deployed.'
      ]
      accounts: [
        {
          name: 'payer'
          isMut: true
          isSigner: true
        },
        {
          name: 'config'
          isMut: true
          isSigner: false
        },
        {
          name: 'mint'
          isMut: false
          isSigner: false
        },
        {
          name: 'systemProgram'
          isMut: false
          isSigner: false
        },
        {
          name: 'addressLookupTable'
          isMut: false
          isSigner: false
        }
      ]
      args: [
        {
          name: 'merkleRoot'
          type: {
            array: ['u8', 20]
          }
        },
        {
          name: 'dispenserGuard'
          type: 'publicKey'
        },
        {
          name: 'maxTransfer'
          type: 'u64'
        }
      ]
    },
    {
      name: 'claim'
      docs: [
        "* Claim a claimant's tokens. This instructions needs to enforce :\n     * - The dispenser guard has signed the transaction - DONE\n     * - The claimant is claiming no more than once per ecosystem - DONE\n     * - The claimant has provided a valid proof of identity (is the owner of the wallet\n     *   entitled to the tokens)\n     * - The claimant has provided a valid proof of inclusion (this confirm that the claimant --\n     *   DONE\n     * - The claimant has not already claimed tokens -- DONE"
      ]
      accounts: [
        {
          name: 'funder'
          isMut: true
          isSigner: true
        },
        {
          name: 'claimant'
          isMut: false
          isSigner: true
        },
        {
          name: 'claimantFund'
          isMut: true
          isSigner: false
          docs: [
            "Claimant's associated token account to receive the tokens",
            'Should be initialized outside of this program.'
          ]
        },
        {
          name: 'config'
          isMut: false
          isSigner: false
        },
        {
          name: 'mint'
          isMut: false
          isSigner: false
        },
        {
          name: 'treasury'
          isMut: true
          isSigner: false
        },
        {
          name: 'tokenProgram'
          isMut: false
          isSigner: false
        },
        {
          name: 'systemProgram'
          isMut: false
          isSigner: false
        },
        {
          name: 'sysvarInstruction'
          isMut: false
          isSigner: false
          docs: [
            "CHECK : Anchor wants me to write this comment because I'm using AccountInfo which doesn't check for ownership and doesn't deserialize the account automatically. But it's fine because I check the address and I load it using load_instruction_at_checked."
          ]
        },
        {
          name: 'associatedTokenProgram'
          isMut: false
          isSigner: false
        }
      ]
      args: [
        {
          name: 'claimCertificate'
          type: {
            defined: 'ClaimCertificate'
          }
        }
      ]
    }
  ]
  accounts: [
    {
      name: 'Config'
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'bump'
            type: 'u8'
          },
          {
            name: 'merkleRoot'
            type: {
              array: ['u8', 20]
            }
          },
          {
            name: 'dispenserGuard'
            type: 'publicKey'
          },
          {
            name: 'mint'
            type: 'publicKey'
          },
          {
            name: 'addressLookupTable'
            type: 'publicKey'
          },
          {
            name: 'maxTransfer'
            type: 'u64'
          }
        ]
      }
    },
    {
      name: 'Receipt'
      type: {
        kind: 'struct'
        fields: []
      }
    }
  ]
  types: [
    {
      name: 'CosmosMessage'
      docs: [
        '* An ADR036 message used in Cosmos. ADR036 is a standard for signing arbitrary data.\n* Only the message payload is stored in this struct.\n* The message signed for Cosmos is a JSON serialized CosmosStdSignDoc containing the payload and ADR036 compliant parameters.\n* The message also contains the bech32 address of the signer. We check that the signer corresponds to the public key.'
      ]
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'payload'
            type: 'bytes'
          },
          {
            name: 'signer'
            type: 'string'
          }
        ]
      }
    },
    {
      name: 'DiscordMessage'
      docs: [
        "* This message (borsh-serialized) needs to be signed by the dispenser guard after\n * verifying the claimant's pubkey controls the discord account.\n * The dispenser guard key should not be used for anything else."
      ]
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'username'
            type: 'string'
          },
          {
            name: 'claimant'
            type: 'publicKey'
          }
        ]
      }
    },
    {
      name: 'Ed25519InstructionHeader'
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'numSignatures'
            type: 'u8'
          },
          {
            name: 'padding'
            type: 'u8'
          },
          {
            name: 'signatureOffset'
            type: 'u16'
          },
          {
            name: 'signatureInstructionIndex'
            type: 'u16'
          },
          {
            name: 'publicKeyOffset'
            type: 'u16'
          },
          {
            name: 'publicKeyInstructionIndex'
            type: 'u16'
          },
          {
            name: 'messageDataOffset'
            type: 'u16'
          },
          {
            name: 'messageDataSize'
            type: 'u16'
          },
          {
            name: 'messageInstructionIndex'
            type: 'u16'
          }
        ]
      }
    },
    {
      name: 'Secp256k1InstructionHeader'
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'numSignatures'
            type: 'u8'
          },
          {
            name: 'signatureOffset'
            type: 'u16'
          },
          {
            name: 'signatureInstructionIndex'
            type: 'u8'
          },
          {
            name: 'ethAddressOffset'
            type: 'u16'
          },
          {
            name: 'ethAddressInstructionIndex'
            type: 'u8'
          },
          {
            name: 'messageDataOffset'
            type: 'u16'
          },
          {
            name: 'messageDataSize'
            type: 'u16'
          },
          {
            name: 'messageInstructionIndex'
            type: 'u8'
          }
        ]
      }
    },
    {
      name: 'ClaimInfo'
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'identity'
            type: {
              defined: 'Identity'
            }
          },
          {
            name: 'amount'
            type: 'u64'
          }
        ]
      }
    },
    {
      name: 'ClaimCertificate'
      type: {
        kind: 'struct'
        fields: [
          {
            name: 'amount'
            type: 'u64'
          },
          {
            name: 'proofOfIdentity'
            type: {
              defined: 'IdentityCertificate'
            }
          },
          {
            name: 'proofOfInclusion'
            type: {
              vec: {
                array: ['u8', 20]
              }
            }
          }
        ]
      }
    },
    {
      name: 'Identity'
      docs: [
        "* This is the identity that the claimant will use to claim tokens.\n * A claimant can claim tokens for 1 identity on each ecosystem.\n * Typically for a blockchain it is a public key in the blockchain's address space."
      ]
      type: {
        kind: 'enum'
        variants: [
          {
            name: 'Discord'
            fields: [
              {
                name: 'username'
                type: 'string'
              }
            ]
          },
          {
            name: 'Solana'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 32]
                }
              }
            ]
          },
          {
            name: 'Evm'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 20]
                }
              }
            ]
          },
          {
            name: 'Sui'
            fields: [
              {
                name: 'address'
                type: {
                  array: ['u8', 32]
                }
              }
            ]
          },
          {
            name: 'Aptos'
            fields: [
              {
                name: 'address'
                type: {
                  array: ['u8', 32]
                }
              }
            ]
          },
          {
            name: 'Cosmwasm'
            fields: [
              {
                name: 'address'
                type: 'string'
              }
            ]
          },
          {
            name: 'Injective'
            fields: [
              {
                name: 'address'
                type: 'string'
              }
            ]
          },
          {
            name: 'Algorand'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 32]
                }
              }
            ]
          }
        ]
      }
    },
    {
      name: 'IdentityCertificate'
      type: {
        kind: 'enum'
        variants: [
          {
            name: 'Discord'
            fields: [
              {
                name: 'username'
                type: 'string'
              },
              {
                name: 'verification_instruction_index'
                type: 'u8'
              }
            ]
          },
          {
            name: 'Evm'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 20]
                }
              },
              {
                name: 'verification_instruction_index'
                type: 'u8'
              }
            ]
          },
          {
            name: 'Solana'
          },
          {
            name: 'Sui'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 32]
                }
              },
              {
                name: 'verification_instruction_index'
                type: 'u8'
              }
            ]
          },
          {
            name: 'Aptos'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 32]
                }
              },
              {
                name: 'verification_instruction_index'
                type: 'u8'
              }
            ]
          },
          {
            name: 'Cosmwasm'
            fields: [
              {
                name: 'chain_id'
                type: 'string'
              },
              {
                name: 'signature'
                type: {
                  array: ['u8', 64]
                }
              },
              {
                name: 'recovery_id'
                type: 'u8'
              },
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 65]
                }
              },
              {
                name: 'message'
                type: 'bytes'
              }
            ]
          },
          {
            name: 'Injective'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 20]
                }
              },
              {
                name: 'verification_instruction_index'
                type: 'u8'
              }
            ]
          },
          {
            name: 'Algorand'
            fields: [
              {
                name: 'pubkey'
                type: {
                  array: ['u8', 32]
                }
              },
              {
                name: 'verification_instruction_index'
                type: 'u8'
              }
            ]
          }
        ]
      }
    }
  ]
  events: [
    {
      name: 'ClaimEvent'
      fields: [
        {
          name: 'treasury'
          type: 'publicKey'
          index: false
        },
        {
          name: 'remainingBalance'
          type: 'u64'
          index: false
        },
        {
          name: 'claimant'
          type: 'publicKey'
          index: false
        },
        {
          name: 'claimInfo'
          type: {
            defined: 'ClaimInfo'
          }
          index: false
        }
      ]
    }
  ]
  errors: [
    {
      code: 6000
      name: 'AlreadyClaimed'
    },
    {
      code: 6001
      name: 'InvalidInclusionProof'
    },
    {
      code: 6002
      name: 'WrongPda'
    },
    {
      code: 6003
      name: 'SignatureVerificationWrongProgram'
    },
    {
      code: 6004
      name: 'SignatureVerificationWrongAccounts'
    },
    {
      code: 6005
      name: 'SignatureVerificationWrongHeader'
    },
    {
      code: 6006
      name: 'SignatureVerificationWrongPayload'
    },
    {
      code: 6007
      name: 'SignatureVerificationWrongPayloadMetadata'
    },
    {
      code: 6008
      name: 'SignatureVerificationWrongSigner'
    },
    {
      code: 6009
      name: 'UnauthorizedCosmosChainId'
    },
    {
      code: 6010
      name: 'TransferExceedsMax'
    }
  ]
}
export const IDL: TokenDispenser = {
  version: '0.1.0',
  name: 'token_dispenser',
  instructions: [
    {
      name: 'initialize',
      docs: [
        'This can only be called once and should be called right after the program is deployed.',
      ],
      accounts: [
        {
          name: 'payer',
          isMut: true,
          isSigner: true,
        },
        {
          name: 'config',
          isMut: true,
          isSigner: false,
        },
        {
          name: 'mint',
          isMut: false,
          isSigner: false,
        },
        {
          name: 'systemProgram',
          isMut: false,
          isSigner: false,
        },
        {
          name: 'addressLookupTable',
          isMut: false,
          isSigner: false,
        },
      ],
      args: [
        {
          name: 'merkleRoot',
          type: {
            array: ['u8', 20],
          },
        },
        {
          name: 'dispenserGuard',
          type: 'publicKey',
        },
        {
          name: 'maxTransfer',
          type: 'u64',
        },
      ],
    },
    {
      name: 'claim',
      docs: [
        "* Claim a claimant's tokens. This instructions needs to enforce :\n     * - The dispenser guard has signed the transaction - DONE\n     * - The claimant is claiming no more than once per ecosystem - DONE\n     * - The claimant has provided a valid proof of identity (is the owner of the wallet\n     *   entitled to the tokens)\n     * - The claimant has provided a valid proof of inclusion (this confirm that the claimant --\n     *   DONE\n     * - The claimant has not already claimed tokens -- DONE",
      ],
      accounts: [
        {
          name: 'funder',
          isMut: true,
          isSigner: true,
        },
        {
          name: 'claimant',
          isMut: false,
          isSigner: true,
        },
        {
          name: 'claimantFund',
          isMut: true,
          isSigner: false,
          docs: [
            "Claimant's associated token account to receive the tokens",
            'Should be initialized outside of this program.',
          ],
        },
        {
          name: 'config',
          isMut: false,
          isSigner: false,
        },
        {
          name: 'mint',
          isMut: false,
          isSigner: false,
        },
        {
          name: 'treasury',
          isMut: true,
          isSigner: false,
        },
        {
          name: 'tokenProgram',
          isMut: false,
          isSigner: false,
        },
        {
          name: 'systemProgram',
          isMut: false,
          isSigner: false,
        },
        {
          name: 'sysvarInstruction',
          isMut: false,
          isSigner: false,
          docs: [
            "CHECK : Anchor wants me to write this comment because I'm using AccountInfo which doesn't check for ownership and doesn't deserialize the account automatically. But it's fine because I check the address and I load it using load_instruction_at_checked.",
          ],
        },
        {
          name: 'associatedTokenProgram',
          isMut: false,
          isSigner: false,
        },
      ],
      args: [
        {
          name: 'claimCertificate',
          type: {
            defined: 'ClaimCertificate',
          },
        },
      ],
    },
  ],
  accounts: [
    {
      name: 'Config',
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'bump',
            type: 'u8',
          },
          {
            name: 'merkleRoot',
            type: {
              array: ['u8', 20],
            },
          },
          {
            name: 'dispenserGuard',
            type: 'publicKey',
          },
          {
            name: 'mint',
            type: 'publicKey',
          },
          {
            name: 'addressLookupTable',
            type: 'publicKey',
          },
          {
            name: 'maxTransfer',
            type: 'u64',
          },
        ],
      },
    },
    {
      name: 'Receipt',
      type: {
        kind: 'struct',
        fields: [],
      },
    },
  ],
  types: [
    {
      name: 'CosmosMessage',
      docs: [
        '* An ADR036 message used in Cosmos. ADR036 is a standard for signing arbitrary data.\n* Only the message payload is stored in this struct.\n* The message signed for Cosmos is a JSON serialized CosmosStdSignDoc containing the payload and ADR036 compliant parameters.\n* The message also contains the bech32 address of the signer. We check that the signer corresponds to the public key.',
      ],
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'payload',
            type: 'bytes',
          },
          {
            name: 'signer',
            type: 'string',
          },
        ],
      },
    },
    {
      name: 'DiscordMessage',
      docs: [
        "* This message (borsh-serialized) needs to be signed by the dispenser guard after\n * verifying the claimant's pubkey controls the discord account.\n * The dispenser guard key should not be used for anything else.",
      ],
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'username',
            type: 'string',
          },
          {
            name: 'claimant',
            type: 'publicKey',
          },
        ],
      },
    },
    {
      name: 'Ed25519InstructionHeader',
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'numSignatures',
            type: 'u8',
          },
          {
            name: 'padding',
            type: 'u8',
          },
          {
            name: 'signatureOffset',
            type: 'u16',
          },
          {
            name: 'signatureInstructionIndex',
            type: 'u16',
          },
          {
            name: 'publicKeyOffset',
            type: 'u16',
          },
          {
            name: 'publicKeyInstructionIndex',
            type: 'u16',
          },
          {
            name: 'messageDataOffset',
            type: 'u16',
          },
          {
            name: 'messageDataSize',
            type: 'u16',
          },
          {
            name: 'messageInstructionIndex',
            type: 'u16',
          },
        ],
      },
    },
    {
      name: 'Secp256k1InstructionHeader',
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'numSignatures',
            type: 'u8',
          },
          {
            name: 'signatureOffset',
            type: 'u16',
          },
          {
            name: 'signatureInstructionIndex',
            type: 'u8',
          },
          {
            name: 'ethAddressOffset',
            type: 'u16',
          },
          {
            name: 'ethAddressInstructionIndex',
            type: 'u8',
          },
          {
            name: 'messageDataOffset',
            type: 'u16',
          },
          {
            name: 'messageDataSize',
            type: 'u16',
          },
          {
            name: 'messageInstructionIndex',
            type: 'u8',
          },
        ],
      },
    },
    {
      name: 'ClaimInfo',
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'identity',
            type: {
              defined: 'Identity',
            },
          },
          {
            name: 'amount',
            type: 'u64',
          },
        ],
      },
    },
    {
      name: 'ClaimCertificate',
      type: {
        kind: 'struct',
        fields: [
          {
            name: 'amount',
            type: 'u64',
          },
          {
            name: 'proofOfIdentity',
            type: {
              defined: 'IdentityCertificate',
            },
          },
          {
            name: 'proofOfInclusion',
            type: {
              vec: {
                array: ['u8', 20],
              },
            },
          },
        ],
      },
    },
    {
      name: 'Identity',
      docs: [
        "* This is the identity that the claimant will use to claim tokens.\n * A claimant can claim tokens for 1 identity on each ecosystem.\n * Typically for a blockchain it is a public key in the blockchain's address space.",
      ],
      type: {
        kind: 'enum',
        variants: [
          {
            name: 'Discord',
            fields: [
              {
                name: 'username',
                type: 'string',
              },
            ],
          },
          {
            name: 'Solana',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 32],
                },
              },
            ],
          },
          {
            name: 'Evm',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 20],
                },
              },
            ],
          },
          {
            name: 'Sui',
            fields: [
              {
                name: 'address',
                type: {
                  array: ['u8', 32],
                },
              },
            ],
          },
          {
            name: 'Aptos',
            fields: [
              {
                name: 'address',
                type: {
                  array: ['u8', 32],
                },
              },
            ],
          },
          {
            name: 'Cosmwasm',
            fields: [
              {
                name: 'address',
                type: 'string',
              },
            ],
          },
          {
            name: 'Injective',
            fields: [
              {
                name: 'address',
                type: 'string',
              },
            ],
          },
          {
            name: 'Algorand',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 32],
                },
              },
            ],
          },
        ],
      },
    },
    {
      name: 'IdentityCertificate',
      type: {
        kind: 'enum',
        variants: [
          {
            name: 'Discord',
            fields: [
              {
                name: 'username',
                type: 'string',
              },
              {
                name: 'verification_instruction_index',
                type: 'u8',
              },
            ],
          },
          {
            name: 'Evm',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 20],
                },
              },
              {
                name: 'verification_instruction_index',
                type: 'u8',
              },
            ],
          },
          {
            name: 'Solana',
          },
          {
            name: 'Sui',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 32],
                },
              },
              {
                name: 'verification_instruction_index',
                type: 'u8',
              },
            ],
          },
          {
            name: 'Aptos',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 32],
                },
              },
              {
                name: 'verification_instruction_index',
                type: 'u8',
              },
            ],
          },
          {
            name: 'Cosmwasm',
            fields: [
              {
                name: 'chain_id',
                type: 'string',
              },
              {
                name: 'signature',
                type: {
                  array: ['u8', 64],
                },
              },
              {
                name: 'recovery_id',
                type: 'u8',
              },
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 65],
                },
              },
              {
                name: 'message',
                type: 'bytes',
              },
            ],
          },
          {
            name: 'Injective',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 20],
                },
              },
              {
                name: 'verification_instruction_index',
                type: 'u8',
              },
            ],
          },
          {
            name: 'Algorand',
            fields: [
              {
                name: 'pubkey',
                type: {
                  array: ['u8', 32],
                },
              },
              {
                name: 'verification_instruction_index',
                type: 'u8',
              },
            ],
          },
        ],
      },
    },
  ],
  events: [
    {
      name: 'ClaimEvent',
      fields: [
        {
          name: 'treasury',
          type: 'publicKey',
          index: false,
        },
        {
          name: 'remainingBalance',
          type: 'u64',
          index: false,
        },
        {
          name: 'claimant',
          type: 'publicKey',
          index: false,
        },
        {
          name: 'claimInfo',
          type: {
            defined: 'ClaimInfo',
          },
          index: false,
        },
      ],
    },
  ],
  errors: [
    {
      code: 6000,
      name: 'AlreadyClaimed',
    },
    {
      code: 6001,
      name: 'InvalidInclusionProof',
    },
    {
      code: 6002,
      name: 'WrongPda',
    },
    {
      code: 6003,
      name: 'SignatureVerificationWrongProgram',
    },
    {
      code: 6004,
      name: 'SignatureVerificationWrongAccounts',
    },
    {
      code: 6005,
      name: 'SignatureVerificationWrongHeader',
    },
    {
      code: 6006,
      name: 'SignatureVerificationWrongPayload',
    },
    {
      code: 6007,
      name: 'SignatureVerificationWrongPayloadMetadata',
    },
    {
      code: 6008,
      name: 'SignatureVerificationWrongSigner',
    },
    {
      code: 6009,
      name: 'UnauthorizedCosmosChainId',
    },
    {
      code: 6010,
      name: 'TransferExceedsMax',
    },
  ],
}
