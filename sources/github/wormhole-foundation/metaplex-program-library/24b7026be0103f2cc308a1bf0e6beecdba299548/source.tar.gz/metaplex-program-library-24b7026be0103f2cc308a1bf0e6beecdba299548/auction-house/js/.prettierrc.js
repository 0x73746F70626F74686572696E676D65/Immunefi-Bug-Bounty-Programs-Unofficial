module.exports = require('../../.prettierrc');

