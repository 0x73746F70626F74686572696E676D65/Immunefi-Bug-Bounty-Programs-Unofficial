export enum StorageType {
  ArweaveBundle = 'arweave-bundle',
  ArweaveSol = 'arweave-sol',
  Arweave = 'arweave',
  Ipfs = 'ipfs',
  Aws = 'aws',
  NftStorage = 'nft-storage',
  Pinata = 'pinata',
}
