# Wormhole Connect Demo

## Introduction

This repository demonstrates the integration of Wormhole Connect in a React app for bridging tokens between the Sui and Fuji (Avalanche Testnet) networks. Using the `@wormhole-foundation/wormhole-connect` package, developers can easily embed a user interface for cross-chain token transfers with minimal configuration.

For a complete tutorial on building a Connect app from scratch, please refer to the [Wormhole Connect Tutorial](https://wormhole.com/docs/tutorials/messaging/sui-connect/). This tutorial focuses on Sui but can be adapted for other compatible chains by following the [Connect configuration guide](https://wormhole.com/docs/build/applications/connect/configuration/).

## Features

 - **Cross-Chain Bridge** - enables token transfers between Sui and Fuji (Avalanche Testnet)
 - **Customizable UI** - displays a demo interface for token bridging with customizable UI options

## Prerequisites

 - [Node.js](https://nodejs.org/) installed on your system
 - [Yarn](https://classic.yarnpkg.com/en/docs/install) installed on your system
 - TypeScript installed globally: `yarn global add typescript`
 - A funded wallet with [Testnet tokens](https://faucets.chain.link/) for deployment and transfers

## Installation and Setup

1. Clone the repository:

```bash
git clone https://github.com/wormhole-foundation/demo-basic-connect.git
cd demo-basic-connect
```

2. Install the dependencies:

```bash
yarn install
```

3. Start the application:

```bash
yarn start
```

The app should now be running on http://localhost:3000.

### Start the CCTP variant

This repo also includes a CCTP-focused example with pre-configured CCTP routes.

```bash
yarn start:cctp
```

This starts the same app but loads `src/App.cctp.tsx` instead of the default `src/App.tsx`.

## Code Overview

The main application logic is in `App.tsx`, configuring and rendering the `WormholeConnect` component. This component is imported from `@wormhole-foundation/wormhole-connect` and initialized with a basic configuration for the Testnet network, connecting Sui and Avalanche.

> **_NOTE:_**  when hosting this project for external use, keep in mind mandatory external API requests in your CORS policy by setting "Access-Control-Allow-Origin".

## Resources

For more information on configuring Wormhole Connect, refer to the [Wormhole Documentation](https://wormhole.com/docs/build/applications/connect/configuration/), which provides detailed guidance on advanced configurations and supported features.
