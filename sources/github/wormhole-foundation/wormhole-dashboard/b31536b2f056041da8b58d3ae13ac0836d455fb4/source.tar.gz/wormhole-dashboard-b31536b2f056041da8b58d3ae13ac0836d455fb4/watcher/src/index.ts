import * as dotenv from 'dotenv';
dotenv.config();

import { initDb } from './databases/utils';
import { Mode, getNetwork, getMode } from '@wormhole-foundation/wormhole-monitor-common';
import { startSupervisor } from './workers/supervisor';
import { Chain, Network } from '@wormhole-foundation/sdk-base';

initDb();

const network: Network = getNetwork();
const mode: Mode = getMode();

// NOTE:  supportedChains is in chainId order

const supportedChains: Chain[] =
  network === 'Testnet'
    ? [
        // NOTE:  The commented out chains are left in there to easily
        //        identify which chains are not supported on testnet.
        'Solana',
        // 'Ethereum',
        'Bsc',
        // 'Polygon',
        'Avalanche',
        'Algorand',
        // 'Klaytn',
        // 'Celo',
        // 'Near',
        // 'Injective',
        'Sui',
        // 'Aptos',
        // 'Arbitrum',
        // 'Optimism',
        // 'Base',
        // 'Wormchain',
        'Sepolia',
        'ArbitrumSepolia',
        'BaseSepolia',
        'OptimismSepolia',
        // 'Holesky',
        'PolygonSepolia',
        // 'Berachain',
        // 'Seievm',
        // 'Unichain',
        // 'Worldchain',
        'Ink',
        // 'HyperEVM',
        // 'Movement',
        'Mezo',
        // 'Fogo',
        // 'Plume',
        'XRPLEVM',
        // 'CreditCoin',
        // 'Moca',
        // 'MegaETH',
        'Arc',
        'MonadTestnet',
        // 'ZeroGravity',
      ]
    : [
        // This is the list of chains supported in MAINNET.
        'Solana',
        'Ethereum',
        'Bsc',
        'Polygon',
        'Avalanche',
        'Algorand',
        'Klaytn',
        'Celo',
        'Near',
        'Injective',
        'Sui',
        'Aptos',
        'Arbitrum',
        'Optimism',
        'Base',
        'Linea',
        'Berachain',
        'Seievm',
        'Unichain',
        'Worldchain',
        'Ink',
        'HyperEVM',
        'Monad',
        'Mezo',
        'Fogo',
        'Plume',
        'XRPLEVM',
        'CreditCoin',
        'Moca',
        'MegaETH',
        'ZeroGravity',
        'Robinhood',
        'Hydration',
        'Wormchain',
      ];

if (mode === 'vaa') {
  startSupervisor(supportedChains);
} else {
  throw new Error(`Unknown mode: ${mode}`);
}
