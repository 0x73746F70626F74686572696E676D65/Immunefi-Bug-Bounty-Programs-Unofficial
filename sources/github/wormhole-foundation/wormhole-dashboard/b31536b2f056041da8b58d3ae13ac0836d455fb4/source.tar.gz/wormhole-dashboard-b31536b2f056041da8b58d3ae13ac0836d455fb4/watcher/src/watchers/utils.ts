import { AlgorandWatcher } from './AlgorandWatcher';
import { AptosWatcher } from './AptosWatcher';
import { InjectiveExplorerWatcher } from './InjectiveExplorerWatcher';
import { Watcher } from './Watcher';
import { SuiWatcher } from './SuiWatcher';
import { SeiExplorerWatcher } from './SeiExplorerWatcher';
import { WormchainWatcher } from './WormchainWatcher';
import { NearArchiveWatcher } from './NearArchiveWatcher';
import { Chain, Network } from '@wormhole-foundation/sdk-base';
import { VAAWatcher } from './VAAWatcher';
import { SVMWatcher } from './SVMWatcher';

export function makeFinalizedVaaWatcher(network: Network, chainName: Chain): Watcher {
  if (chainName === 'Solana' || chainName === 'Fogo') {
    return new SVMWatcher(network, chainName);
  } else if (
    chainName === 'Arbitrum' ||
    chainName === 'Arc' ||
    chainName === 'Avalanche' ||
    chainName === 'Base' ||
    chainName === 'Berachain' ||
    chainName === 'Bsc' ||
    chainName === 'Celo' ||
    chainName === 'Converge' ||
    chainName === 'CreditCoin' ||
    chainName === 'Ethereum' ||
    chainName === 'Hydration' ||
    chainName === 'HyperEVM' ||
    chainName === 'Ink' ||
    chainName === 'Linea' ||
    chainName === 'MegaETH' ||
    chainName === 'Mezo' ||
    chainName === 'Moca' ||
    chainName === 'Monad' ||
    chainName === 'Moonbeam' ||
    chainName === 'Optimism' ||
    chainName === 'Plume' ||
    chainName === 'Polygon' ||
    chainName === 'Robinhood' ||
    chainName === 'Seievm' ||
    chainName === 'Sonic' ||
    chainName === 'Unichain' ||
    chainName === 'Worldchain' ||
    chainName === 'XRPLEVM' ||
    chainName === 'ZeroGravity'
  ) {
    return new VAAWatcher(network, chainName);
  } else if (chainName === 'Klaytn') {
    return new VAAWatcher(network, chainName, 'latest');
  } else if (chainName === 'Algorand') {
    return new AlgorandWatcher(network);
  } else if (chainName === 'Aptos' /*|| chainName === 'Movement'*/) {
    return new AptosWatcher(network, chainName);
  } else if (chainName === 'Injective') {
    return new InjectiveExplorerWatcher(network);
  } else if (chainName === 'Near') {
    return new NearArchiveWatcher(network);
  } else if (chainName === 'Sei') {
    return new SeiExplorerWatcher(network);
  } else if (chainName === 'Sui') {
    return new SuiWatcher(network);
  } else if (chainName === 'Wormchain') {
    return new WormchainWatcher(network);
  } else if (network === 'Testnet') {
    // These are testnet only chains
    if (
      chainName === 'ArbitrumSepolia' ||
      chainName === 'BaseSepolia' ||
      chainName === 'Holesky' ||
      chainName === 'OptimismSepolia' ||
      chainName === 'PolygonSepolia' ||
      chainName === 'Sepolia' ||
      chainName === 'MonadTestnet'
    ) {
      return new VAAWatcher(network, chainName);
    } else {
      throw new Error(
        `Attempted to create finalized watcher for unsupported testnet chain ${chainName}`
      );
    }
  } else {
    throw new Error(`Attempted to create finalized watcher for unsupported chain ${chainName}`);
  }
}
