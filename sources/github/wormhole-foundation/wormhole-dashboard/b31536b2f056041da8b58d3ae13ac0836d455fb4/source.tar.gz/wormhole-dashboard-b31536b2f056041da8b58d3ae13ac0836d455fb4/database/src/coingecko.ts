import { Chain } from '@wormhole-foundation/sdk-base';
import { chunkArray, sleep } from '@wormhole-foundation/wormhole-monitor-common';
import axios, { isAxiosError } from 'axios';

const COIN_GECKO_API_BASE_URL = 'https://api.coingecko.com/api/v3';
const COIN_GECKO_PRO_API_BASE_URL = 'https://pro-api.coingecko.com/api/v3';
const COIN_GECKO_API_SLEEP_MS = 1000;

// https://api.coingecko.com/api/v3/asset_platforms
export const COINGECKO_PLATFORM_BY_CHAIN: { [key in Chain]?: string } = {
  Solana: 'solana',
  Ethereum: 'ethereum',
  Bsc: 'binance-smart-chain',
  Polygon: 'polygon-pos',
  Avalanche: 'avalanche',
  Algorand: 'algorand',
  Aptos: 'aptos',
  Klaytn: 'klay-token',
  Celo: 'celo',
  Near: 'near-protocol',
  Moonbeam: 'moonbeam',
  Arbitrum: 'arbitrum-one',
  Optimism: 'optimistic-ethereum',
  Injective: 'injective',
  Sui: 'sui',
  Base: 'base',
  Sei: 'sei-network',
};

// CoinGecko and the on-chain SDKs use different canonical forms for Move-style
// type addresses. For Sui, CoinGecko stores `0x0000...0002::sui::SUI` while
// `getTokenCoinType` returns Sui's `TypeName` canonical form
// `0000...0002::sui::SUI` (no `0x`). For Aptos, CoinGecko stores
// `0x1::aptos_coin::AptosCoin` while the Aptos REST API returns the padded
// form `0x0000...0001::aptos_coin::AptosCoin`. Strip an optional `0x` prefix
// and any leading zeros from the address portion so all of these collapse to
// the same key (e.g. `2::sui::sui`, `1::aptos_coin::aptoscoin`).
export const normalizeCoinGeckoPlatformAddress = (platform: string, address: string): string => {
  const lower = address.toLowerCase();
  return platform === 'sui' || platform === 'aptos' ? lower.replace(/^(0x)?0*/, '') : lower;
};

export interface CoinGeckoPrices {
  [coinId: string]: { usd: number | null };
}

export interface CoinGeckoCoin {
  id: string;
  symbol: string;
  name: string;
  platforms: {
    [platform: string]: string;
  };
}

export interface CoinGeckoPriceHistories {
  [date: string]: { [coinId: string]: number };
}

interface CoinGeckoMarketChartResponse {
  prices: [number, number][]; // timestamp ms, price
}

const createConfig = (apiKey: string) => ({
  headers: {
    'x-cg-pro-api-key': apiKey,
  },
});

export const fetchPrices = async (coinIds: string[], apiKey?: string): Promise<CoinGeckoPrices> => {
  const FIVE_MINUTES_IN_MS = 5 * 60 * 1000;
  const [baseUrl, config] = apiKey
    ? [COIN_GECKO_PRO_API_BASE_URL, createConfig(apiKey)]
    : [COIN_GECKO_API_BASE_URL, undefined];
  let prices: CoinGeckoPrices = {};
  const chunks = chunkArray(coinIds, 400);
  console.log(`fetching ${chunks.length} chunks of prices`);
  for (const chunk of chunks) {
    console.log(`fetching chunk of ${chunk.length} prices`);
    let currentBackoff = COIN_GECKO_API_SLEEP_MS;
    const url = `${baseUrl}/simple/price?ids=${chunk.join(',')}&vs_currencies=usd`;
    let done: boolean = false;
    while (!done) {
      try {
        const response = await axios.get<CoinGeckoPrices>(url, config);
        console.log(`fetched ${Object.keys(response.data).length} prices`);
        prices = {
          ...prices,
          ...response.data,
        };
        done = true;
      } catch (e) {
        console.error(`failed to fetch prices: ${e}`);
        if (isAxiosError(e) && e.response?.status === 429) {
          if (currentBackoff > FIVE_MINUTES_IN_MS) {
            console.error('Exceeded max backoff time querying CoinGecko API, giving up.');
            throw e;
          }
          console.log(`backing off for ${currentBackoff}ms`);
          await sleep(currentBackoff);
          currentBackoff *= 2;
        } else {
          // Only want to retry on 429s
          throw e;
        }
      }
    }
    await sleep(COIN_GECKO_API_SLEEP_MS);
  }
  return prices;
};

export const fetchCoins = async (apiKey?: string): Promise<CoinGeckoCoin[]> => {
  const [baseUrl, config] = apiKey
    ? [COIN_GECKO_PRO_API_BASE_URL, createConfig(apiKey)]
    : [COIN_GECKO_API_BASE_URL, undefined];
  return (await axios.get<CoinGeckoCoin[]>(`${baseUrl}/coins/list?include_platform=true`, config))
    .data;
};

export interface CoinGeckoCoinDetail {
  id: string;
  symbol: string;
  name: string;
  detail_platforms: {
    [platform: string]: { decimal_place: number | null; contract_address: string };
  };
}

export const fetchCoinDetail = async (
  coinId: string,
  apiKey?: string
): Promise<CoinGeckoCoinDetail | null> => {
  const [baseUrl, config] = apiKey
    ? [COIN_GECKO_PRO_API_BASE_URL, createConfig(apiKey)]
    : [COIN_GECKO_API_BASE_URL, undefined];
  const url = `${baseUrl}/coins/${coinId}?localization=false&tickers=false&market_data=false&community_data=false&developer_data=false&sparkline=false`;
  try {
    const response = await axios.get<CoinGeckoCoinDetail>(url, config);
    return response.data;
  } catch (e) {
    if (isAxiosError(e) && e.response?.status === 404) {
      console.error(`coin not found: ${coinId}`);
      return null;
    }
    throw e;
  }
};

const toTimestamp = (date: Date): number => parseInt((date.getTime() / 1000).toFixed(0));

export const fetchPriceHistories = async (
  coinIds: string[],
  start: Date,
  end: Date,
  apiKey?: string
): Promise<CoinGeckoPriceHistories> => {
  const [baseUrl, config] = apiKey
    ? [COIN_GECKO_PRO_API_BASE_URL, createConfig(apiKey)]
    : [COIN_GECKO_API_BASE_URL, undefined];
  const priceHistories: CoinGeckoPriceHistories = {};
  const from = toTimestamp(start);
  const to = toTimestamp(end);
  for (const coinId of coinIds) {
    try {
      const url = `${baseUrl}/coins/${coinId}/market_chart/range?vs_currency=usd&from=${from}&to=${to}`;
      const response = await axios.get<CoinGeckoMarketChartResponse>(url, config);
      for (const [date, price] of response.data.prices) {
        const dateString = new Date(date).toISOString().slice(0, 10);
        priceHistories[dateString] = {
          ...priceHistories[dateString],
          [coinId]: price,
        };
      }
    } catch (e) {
      if (isAxiosError(e) && e.response?.status === 404) {
        console.error(`coin not found: ${coinId}`);
      } else {
        console.error(e);
      }
    }
    await sleep(COIN_GECKO_API_SLEEP_MS);
  }
  return priceHistories;
};
