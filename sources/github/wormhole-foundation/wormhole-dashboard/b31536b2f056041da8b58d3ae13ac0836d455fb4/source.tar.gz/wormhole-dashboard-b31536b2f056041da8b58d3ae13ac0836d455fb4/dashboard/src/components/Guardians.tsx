import {
  CheckCircleOutline,
  ErrorOutline,
  GridView,
  InfoOutlined,
  Link as LinkIcon,
  MonitorHeartOutlined,
  PlayCircleOutline,
  ViewList,
  WarningAmberOutlined,
} from '@mui/icons-material';
import {
  Box,
  Card,
  CardActionArea,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  Hidden,
  LinearProgress,
  Link,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  SxProps,
  Theme,
  ToggleButton,
  ToggleButtonGroup,
  Tooltip,
  Typography,
} from '@mui/material';
import {
  createColumnHelper,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from '@tanstack/react-table';
import { chainIdToName, STANDBY_GUARDIANS } from '@wormhole-foundation/wormhole-monitor-common';
import { useCallback, useMemo, useState } from 'react';
import TimeAgo from 'react-timeago';
import { ChainIdToHeartbeats } from '../hooks/useChainHeartbeats';
import { DelegatedGuardianConfigMap } from '../hooks/useDelegatedGuardianConfig';
import { Heartbeat, HeartbeatNetwork } from '../utils/getLastHeartbeats';
import { isHeartbeatUnhealthy } from './Chains';
import CollapsibleSection from './CollapsibleSection';
import FetchedAt from './FetchedAt';
import Table from './Table';

const columnHelper = createColumnHelper<Heartbeat>();

const columns = [
  columnHelper.accessor('nodeName', {
    header: () => 'Guardian',
    sortingFn: `text`,
  }),
  columnHelper.accessor('version', {
    header: () => 'Version',
  }),
  columnHelper.accessor('features', {
    header: () => 'Features',
    cell: (info) => (info.getValue()?.length > 0 ? info.getValue().join(', ') : 'none'),
  }),
  columnHelper.accessor('counter', {
    header: () => 'Counter',
  }),
  columnHelper.accessor('bootTimestamp', {
    header: () => 'Boot',
    cell: (info) =>
      info.getValue() ? new Date(Number(info.getValue()) / 1000000).toLocaleString() : null,
  }),
  columnHelper.accessor('timestamp', {
    header: () => 'Timestamp',
    cell: (info) =>
      info.getValue() ? new Date(Number(info.getValue()) / 1000000).toLocaleString() : null,
  }),
  columnHelper.accessor('guardianAddr', {
    header: () => 'Address',
    cell: (info) => <code>{info.getValue()}</code>,
  }),
  columnHelper.accessor('p2pNodeAddr', {
    header: () => 'P2P Address',
    cell: (info) => <code>{info.getValue()}</code>,
  }),
];

type HighestByChain = { [chainId: string]: bigint };

// A guardian is "responsible" for a chain if either the chain has no delegate
// config (canonical set applies) or the guardian is in the delegate key set.
// Chains a guardian was delegated away from don't count toward their health.
function computeGuardianHealth(
  heartbeat: Heartbeat,
  highestByChain: HighestByChain,
  delegateConfig: DelegatedGuardianConfigMap
): { healthyCount: number; responsibleCount: number } {
  const guardian = heartbeat.guardianAddr.toLowerCase();
  const networkById = new Map(heartbeat.networks.map((n) => [n.id, n]));
  let responsibleCount = 0;
  let healthyCount = 0;
  for (const chainIdStr of Object.keys(highestByChain)) {
    const chainId = Number(chainIdStr);
    const dc = delegateConfig[chainId];
    if (dc && !dc.keys.includes(guardian)) continue;
    responsibleCount++;
    const network = networkById.get(chainId);
    if (
      network &&
      !isHeartbeatUnhealthy(
        { guardian: heartbeat.guardianAddr, name: heartbeat.nodeName, network },
        highestByChain[chainIdStr]
      )
    ) {
      healthyCount++;
    }
  }
  return { healthyCount, responsibleCount };
}

const networkColumnHelper = createColumnHelper<HeartbeatNetwork>();

const networkColumns = [
  networkColumnHelper.accessor('id', {
    header: () => 'Chain',
    cell: (info) => (
      <Typography variant="body2" noWrap>
        {chainIdToName(info.getValue())} ({info.getValue()})
      </Typography>
    ),
  }),
  networkColumnHelper.accessor('height', {
    header: () => 'Latest',
  }),
  networkColumnHelper.accessor('safeHeight', {
    header: () => 'Safe',
  }),
  networkColumnHelper.accessor('finalizedHeight', {
    header: () => 'Finalized',
  }),
  networkColumnHelper.accessor('errorCount', {
    header: () => 'Errors',
  }),
  networkColumnHelper.accessor('lastObservationSignedAt', {
    header: () => 'Last Observation',
    cell: (info) => {
      const value = info.getValue();
      if (!value || value === '0') return null;
      const ms = Number(value) / 1000000;
      return (
        <Tooltip title={new Date(ms).toLocaleString()}>
          <span>
            <TimeAgo date={ms} />
          </span>
        </Tooltip>
      );
    },
  }),
  networkColumnHelper.accessor('contractAddress', {
    header: () => 'Contract',
  }),
];

function GuardianDetails({
  heartbeat,
  highestByChain,
  conditionalRowStyle,
}: {
  heartbeat: Heartbeat;
  highestByChain: HighestByChain;
  conditionalRowStyle?: ((a: HeartbeatNetwork) => SxProps<Theme> | undefined) | undefined;
}) {
  const [sorting, setSorting] = useState<SortingState>([{ id: 'id', desc: false }]);
  const table = useReactTable({
    columns: networkColumns,
    data: heartbeat.networks,
    state: {
      sorting,
    },
    getRowId: (network) => network.id.toString(),
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    onSortingChange: setSorting,
  });
  return <Table<HeartbeatNetwork> table={table} conditionalRowStyle={conditionalRowStyle} />;
}

function GuardianCard({
  heartbeat,
  highestByChain,
  delegateConfig,
  latestRelease,
}: {
  heartbeat: Heartbeat;
  highestByChain: HighestByChain;
  delegateConfig: DelegatedGuardianConfigMap;
  latestRelease: string | null;
}) {
  const [open, setOpen] = useState(false);
  const handleOpen = useCallback(() => {
    setOpen(true);
  }, []);
  const handleClose = useCallback(() => {
    setOpen(false);
  }, []);
  const { healthyCount, responsibleCount: chainCount } = useMemo(
    () => computeGuardianHealth(heartbeat, highestByChain, delegateConfig),
    [heartbeat, highestByChain, delegateConfig]
  );
  const conditionalRowStyle = useCallback(
    (network: HeartbeatNetwork) =>
      isHeartbeatUnhealthy({ network, guardian: '', name: '' }, highestByChain[network.id])
        ? { backgroundColor: 'rgba(100,0,0,.2)' }
        : {},
    [highestByChain]
  );
  const healthyPercent = chainCount === 0 ? 100 : (healthyCount / chainCount) * 100;
  const hasLatestRelease = latestRelease && heartbeat.version !== latestRelease;
  return (
    <Box m={1} height="100%" sx={{ width: { sm: 232, xs: 142 } }}>
      <Card
        sx={{
          height: '100%',
          position: 'relative',
          overflow: 'visible',
        }}
      >
        <CardActionArea
          onClick={handleOpen}
          sx={{ display: 'flex', p: 1, height: '100%', alignItems: 'center' }}
        >
          <Hidden smDown>
            <Box flexBasis="72px" height="100%" textAlign="center">
              <Typography variant="body2" sx={{ flexGrow: 1 }}>
                {heartbeat.nodeName.replace(/([a-w,y-z])([A-Z])/g, '$1 $2')}
              </Typography>
            </Box>
            <Divider orientation="vertical" flexItem sx={{ mx: 1 }} />
          </Hidden>
          <Box flexGrow={1} my={-0.5}>
            <Hidden smUp>
              <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>
                {heartbeat.nodeName.replace(/([a-w,y-z])([A-Z])/g, '$1 $2')}
              </Typography>
            </Hidden>
            <Tooltip
              title={
                <Typography variant="body2">
                  Last Heartbeat:{' '}
                  {heartbeat.timestamp
                    ? new Date(Number(heartbeat.timestamp) / 1000000).toLocaleString()
                    : null}
                </Typography>
              }
            >
              <Box display="flex" alignItems="center" my={0.25}>
                <MonitorHeartOutlined fontSize="inherit" sx={{ mr: 0.5 }} />
                <Typography variant="caption">
                  {heartbeat.timestamp ? (
                    <TimeAgo date={Number(heartbeat.timestamp) / 1000000} />
                  ) : null}
                </Typography>
              </Box>
            </Tooltip>
            <Tooltip
              title={
                <>
                  <Typography variant="body2" gutterBottom>
                    Boot Time:{' '}
                    {heartbeat.bootTimestamp
                      ? new Date(Number(heartbeat.bootTimestamp) / 1000000).toLocaleString()
                      : null}
                  </Typography>
                  {hasLatestRelease ? (
                    <>
                      <Typography variant="body2" gutterBottom>
                        {heartbeat.nodeName} is not running the latest release.
                      </Typography>
                      <Typography variant="body2">Theirs: {heartbeat.version}</Typography>
                      <Typography variant="body2">Latest: {latestRelease}</Typography>
                    </>
                  ) : null}
                </>
              }
            >
              <Box display="flex" alignItems="center" my={0.25}>
                <PlayCircleOutline
                  color={hasLatestRelease ? 'primary' : 'inherit'}
                  fontSize="inherit"
                  sx={{ mr: 0.5 }}
                />
                <Typography variant="caption">
                  {heartbeat.bootTimestamp ? (
                    <TimeAgo date={Number(heartbeat.bootTimestamp) / 1000000} />
                  ) : null}
                </Typography>
              </Box>
            </Tooltip>
            <Tooltip
              title={
                <Typography variant="body2">
                  Healthy Chains: {healthyCount} / {chainCount}
                </Typography>
              }
            >
              <Box display="flex" alignItems="center" my={0.25}>
                <LinkIcon fontSize="inherit" sx={{ mr: 0.5 }} />
                <LinearProgress
                  variant="determinate"
                  value={healthyPercent}
                  sx={{ flexGrow: 1 }}
                  color={
                    healthyPercent === 100 ? 'success' : healthyPercent > 80 ? 'warning' : 'error'
                  }
                />
              </Box>
            </Tooltip>
          </Box>
        </CardActionArea>
      </Card>
      <Dialog open={open} onClose={handleClose} maxWidth="xl" fullWidth>
        <DialogTitle>{heartbeat.nodeName}</DialogTitle>
        <DialogContent>
          <GuardianDetails
            heartbeat={heartbeat}
            highestByChain={highestByChain}
            conditionalRowStyle={conditionalRowStyle}
          />
        </DialogContent>
      </Dialog>
    </Box>
  );
}

type Displays = 'cards' | 'table';

function Guardians({
  heartbeats,
  heartbeatsReceivedAt,
  chainIdsToHeartbeats,
  delegateConfig,
  latestRelease,
}: {
  heartbeats: Heartbeat[];
  heartbeatsReceivedAt: string | null;
  chainIdsToHeartbeats: ChainIdToHeartbeats;
  delegateConfig: DelegatedGuardianConfigMap;
  latestRelease: string | null;
}) {
  const [guardianHeartbeats, standbyHeartbeats] = useMemo(
    () =>
      heartbeats.reduce(
        ([guardian, standby], hb) => {
          if (
            STANDBY_GUARDIANS.find((g) => g.pubkey.toLowerCase() === hb.guardianAddr.toLowerCase())
          ) {
            return [guardian, [...standby, hb]];
          }
          return [[...guardian, hb], standby];
        },
        [[] as Heartbeat[], [] as Heartbeat[]]
      ),
    [heartbeats]
  );
  const highestByChain = useMemo(
    () =>
      Object.entries(chainIdsToHeartbeats).reduce((obj, [chainId, heartbeats]) => {
        let highest = BigInt(0);
        heartbeats.forEach((heartbeat) => {
          const height = BigInt(heartbeat.network.height);
          if (height > highest) {
            highest = height;
          }
        });
        obj[chainId] = highest;
        return obj;
      }, {} as HighestByChain),
    [chainIdsToHeartbeats]
  );
  const [sorting, setSorting] = useState<SortingState>([]);
  const table = useReactTable({
    columns,
    data: guardianHeartbeats,
    state: {
      sorting,
    },
    getRowId: (heartbeat) => `${heartbeat.guardianAddr}-${heartbeat.nodeName}`,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    onSortingChange: setSorting,
  });
  const standbyTable = useReactTable({
    columns,
    data: standbyHeartbeats,
    state: {
      sorting,
    },
    getRowId: (heartbeat) => `${heartbeat.guardianAddr}-${heartbeat.nodeName}`,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    onSortingChange: setSorting,
  });
  const [display, setDisplay] = useState<Displays>('cards');
  const handleDisplay = useCallback(
    (event: React.MouseEvent<HTMLElement>, newDisplay: Displays | null) => {
      if (newDisplay) {
        setDisplay(newDisplay);
      }
      event.stopPropagation();
    },
    []
  );
  const {
    numSuccess,
    numWarnings,
    numErrors,
  }: {
    numSuccess: number;
    numWarnings: number;
    numErrors: number;
  } = useMemo(() => {
    let numSuccess = 0;
    let numWarnings = 0;
    let numErrors = 0;
    for (const heartbeat of guardianHeartbeats) {
      const { healthyCount, responsibleCount } = computeGuardianHealth(
        heartbeat,
        highestByChain,
        delegateConfig
      );
      const healthyPercent = responsibleCount === 0 ? 100 : (healthyCount / responsibleCount) * 100;
      if (healthyPercent === 100) {
        numSuccess++;
      } else if (healthyPercent > 80) {
        numWarnings++;
      } else {
        numErrors++;
      }
    }
    return {
      numSuccess,
      numWarnings,
      numErrors,
    };
  }, [guardianHeartbeats, highestByChain, delegateConfig]);
  return (
    <CollapsibleSection
      header={
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            paddingRight: 1,
          }}
        >
          <Box>Guardians</Box>
          <Tooltip
            title={
              <>
                <Typography variant="body1">
                  This section shows alerts for the following conditions:
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemIcon>
                      <InfoOutlined color="info" />
                    </ListItemIcon>
                    <ListItemText
                      primary="Guardians not running the latest release"
                      secondary={
                        <>
                          The guardian version is compared to the latest release from{' '}
                          <Link
                            href="https://github.com/wormhole-foundation/wormhole/releases"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            https://github.com/wormhole-foundation/wormhole/releases
                          </Link>
                        </>
                      }
                    />
                  </ListItem>
                </List>
              </>
            }
            componentsProps={{ tooltip: { sx: { maxWidth: '100%' } } }}
          >
            <Box>
              <InfoOutlined sx={{ fontSize: '.8em', ml: 0.5 }} />
            </Box>
          </Tooltip>
          <ToggleButtonGroup
            value={display}
            exclusive
            onChange={handleDisplay}
            size="small"
            sx={{ my: -1, ml: 1 }}
          >
            <ToggleButton value="cards">
              <GridView fontSize="small" />
            </ToggleButton>
            <ToggleButton value="table">
              <ViewList fontSize="small" />
            </ToggleButton>
          </ToggleButtonGroup>
          <Box flexGrow={1} />
          {numSuccess > 0 ? (
            <>
              <CheckCircleOutline color="success" sx={{ ml: 2 }} />
              <Typography variant="h6" component="strong" sx={{ ml: 0.5 }}>
                {numSuccess}
              </Typography>
            </>
          ) : null}
          {numWarnings > 0 ? (
            <>
              <WarningAmberOutlined color="warning" sx={{ ml: 2 }} />
              <Typography variant="h6" component="strong" sx={{ ml: 0.5 }}>
                {numWarnings}
              </Typography>
            </>
          ) : null}
          {numErrors > 0 ? (
            <>
              <ErrorOutline color="error" sx={{ ml: 2 }} />
              <Typography variant="h6" component="strong" sx={{ ml: 0.5 }}>
                {numErrors}
              </Typography>
            </>
          ) : null}
        </Box>
      }
    >
      {display === 'cards' ? (
        <>
          <Box display="flex" flexWrap="wrap" alignItems="center" justifyContent={'center'}>
            {guardianHeartbeats.map((hb) => (
              <GuardianCard
                key={`${hb.guardianAddr}-${hb.nodeName}`}
                heartbeat={hb}
                highestByChain={highestByChain}
                delegateConfig={delegateConfig}
                latestRelease={latestRelease}
              />
            ))}
          </Box>
          {STANDBY_GUARDIANS.length === 0 ? null : (
            <>
              <Typography variant="subtitle1" sx={{ mt: 2, mb: 1 }}>
                Standby Guardians
              </Typography>
              <Box display="flex" flexWrap="wrap" alignItems="center" justifyContent={'center'}>
                {standbyHeartbeats.map((hb) => (
                  <GuardianCard
                    key={`${hb.guardianAddr}-${hb.nodeName}`}
                    heartbeat={hb}
                    highestByChain={highestByChain}
                    delegateConfig={delegateConfig}
                    latestRelease={latestRelease}
                  />
                ))}
              </Box>
            </>
          )}
        </>
      ) : (
        <>
          <Card>
            <Table<Heartbeat> table={table} showRowCount />
          </Card>
          {STANDBY_GUARDIANS.length === 0 ? null : (
            <>
              <Typography variant="subtitle1" sx={{ mt: 2, mb: 1 }}>
                Standby Guardians
              </Typography>
              <Card>
                <Table<Heartbeat> table={standbyTable} showRowCount />
              </Card>
            </>
          )}
        </>
      )}
      <FetchedAt entries={[{ label: 'Heartbeats', receivedAt: heartbeatsReceivedAt }]} />
    </CollapsibleSection>
  );
}

export default Guardians;
