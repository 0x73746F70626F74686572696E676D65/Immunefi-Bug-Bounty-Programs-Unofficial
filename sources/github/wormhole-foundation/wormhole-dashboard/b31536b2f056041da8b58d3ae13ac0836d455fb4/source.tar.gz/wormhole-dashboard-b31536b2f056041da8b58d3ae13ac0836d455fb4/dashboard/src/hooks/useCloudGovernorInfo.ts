import axios from 'axios';
import { useEffect, useState } from 'react';
import { useNetworkContext } from '../contexts/NetworkContext';
import { getQuorumCount } from '../components/Alerts';
import { GUARDIAN_SET } from '@wormhole-foundation/wormhole-monitor-common';
import { tryHexToNativeAssetString } from '../utils/nativeAsset';

export interface AvailableNotionalByChain {
  guardianName?: string;
  chainId: number;
  remainingAvailableNotional: {
    min: string;
    max: string;
    quorum: string;
  };
  notionalLimit: string;
  bigTransactionSize: string;
  byGuardian?: AvailableNotionalByChain[];
}

export interface GovernorToken {
  originAddress: string;
  originChainId: number;
  price: number;
}

export interface EnqueuedVAA {
  guardianName?: string;
  emitterChain: number;
  emitterAddress: string;
  sequence: string;
  releaseTime: number;
  notionalValue: string;
  txHash: string;
  byGuardian?: EnqueuedVAA[];
}

export interface TotalEnqueuedVaasByGuardianByChain {
  [guardianAddress: string]: {
    [chainId: number]: number;
  };
}

export interface CloudGovernorInfo {
  notionals: AvailableNotionalByChain[];
  tokens: GovernorToken[];
  enqueuedVAAs: EnqueuedVAA[];
  totalEnqueuedVaas: TotalEnqueuedVaasByGuardianByChain;
  configsReceivedAt: string | null;
  statusReceivedAt: string | null;
}

interface Chain {
  bigTransactionSize: string;
  chainId: number;
  notionalLimit: string;
  availableNotional: string;
}

interface GovernorConfig {
  chains: Chain[];
  guardianAddress: string;
  tokens: GovernorToken[];
  updatedAt: Date;
}

interface GovernorConfigsResponse {
  governorConfigs: GovernorConfig[];
}

interface EnqueuedVAAResponse {
  sequence: string;
  releaseTime: number;
  notionalValue: string;
  txHash: string;
}

interface Emitter {
  emitterAddress: string;
  enqueuedVaas: EnqueuedVAAResponse[];
  totalEnqueuedVaas: string;
}

interface ChainStatus {
  availableNotional: string;
  chainId: number;
  emitters: Emitter[];
}

interface GovernorStatus {
  chains: ChainStatus[];
  guardianAddress: string;
  updatedAt: Date;
}

interface GovernorStatusResponse {
  governorStatus: GovernorStatus[];
}

const POLL_INTERVAL_MS = 60 * 1000;

const createEmptyInfo = (): CloudGovernorInfo => ({
  notionals: [],
  tokens: [],
  enqueuedVAAs: [],
  totalEnqueuedVaas: {},
  configsReceivedAt: null,
  statusReceivedAt: null,
});

type GovernorConfigsInfo = Pick<CloudGovernorInfo, 'notionals' | 'tokens'>;
type GovernorStatusInfo = Pick<CloudGovernorInfo, 'enqueuedVAAs' | 'totalEnqueuedVaas'>;

const getConfigsInfo = async (endpoint: string): Promise<GovernorConfigsInfo> => {
  const configs = await axios.get<GovernorConfigsResponse>(`${endpoint}/governor-configs`);

  let firstConfig: GovernorConfig | undefined = undefined;
  const availableNotionalByChain: {
    [chainId: number]: bigint[];
  } = {};
  const bigTransactionSizeByChain: {
    [chainId: number]: bigint[];
  } = {};
  const notionalLimitsByChain: {
    [chainId: number]: bigint[];
  } = {};
  const guardiansByChain: {
    [chainId: number]: AvailableNotionalByChain[];
  } = {};
  for (const config of configs.data.governorConfigs) {
    if (
      config.guardianAddress.toLowerCase() === GUARDIAN_SET[0].pubkey.toLowerCase().substring(2)
    ) {
      firstConfig = config;
    }
    const guardianName =
      GUARDIAN_SET.find(
        (g) => `0x${config.guardianAddress}`.toLowerCase() === g.pubkey.toLowerCase()
      )?.name || config.guardianAddress;
    for (const chain of config.chains) {
      const { chainId, availableNotional, bigTransactionSize, notionalLimit } = chain;
      availableNotionalByChain[chainId] = [
        ...(availableNotionalByChain[chainId] || []),
        BigInt(availableNotional),
      ];
      bigTransactionSizeByChain[chainId] = [
        ...(bigTransactionSizeByChain[chainId] || []),
        BigInt(bigTransactionSize),
      ];
      notionalLimitsByChain[chainId] = [
        ...(notionalLimitsByChain[chainId] || []),
        BigInt(notionalLimit),
      ];
      guardiansByChain[chainId] = [
        ...(guardiansByChain[chainId] || []),
        {
          ...chain,
          guardianName,
          remainingAvailableNotional: {
            min: '',
            max: '',
            quorum: chain.availableNotional,
          },
        },
      ];
    }
  }

  const notionals: AvailableNotionalByChain[] = [];
  const quorumIdx = getQuorumCount('Mainnet') - 1;
  for (const chainIdStr in availableNotionalByChain) {
    const chainId = Number(chainIdStr);
    availableNotionalByChain[chainId].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)).reverse();
    bigTransactionSizeByChain[chainId].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)).reverse();
    notionalLimitsByChain[chainId].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)).reverse();
    notionals.push({
      chainId,
      remainingAvailableNotional: {
        min: availableNotionalByChain[chainId][
          availableNotionalByChain[chainId].length - 1
        ].toString(),
        max: availableNotionalByChain[chainId][0].toString(),
        quorum:
          availableNotionalByChain[chainId][
            Math.min(quorumIdx, availableNotionalByChain[chainId].length - 1)
          ].toString(),
      },
      bigTransactionSize:
        bigTransactionSizeByChain[chainId][
          Math.min(quorumIdx, bigTransactionSizeByChain[chainId].length - 1)
        ].toString(),
      notionalLimit:
        notionalLimitsByChain[chainId][
          Math.min(quorumIdx, notionalLimitsByChain[chainId].length - 1)
        ].toString(),
      byGuardian: guardiansByChain[chainId],
    });
  }

  const tokens =
    firstConfig?.tokens?.map((entry) => {
      try {
        return {
          ...entry,
          originAddress: tryHexToNativeAssetString(entry.originAddress, entry.originChainId),
        };
      } catch (e) {}
      return entry;
    }) || [];

  notionals.sort((a, b) => (a.chainId < b.chainId ? -1 : a.chainId > b.chainId ? 1 : 0));

  return { notionals, tokens };
};

const getStatusInfo = async (endpoint: string): Promise<GovernorStatusInfo> => {
  const status = await axios.get<GovernorStatusResponse>(`${endpoint}/governor-status`);

  const vaaById: { [key: string]: EnqueuedVAA } = {};
  const totalEnqueuedVaas: TotalEnqueuedVaasByGuardianByChain = {};
  for (const s of status.data.governorStatus) {
    const guardianName =
      GUARDIAN_SET.find((g) => `0x${s.guardianAddress}`.toLowerCase() === g.pubkey.toLowerCase())
        ?.name || s.guardianAddress;
    for (const chain of s.chains) {
      for (const emitter of chain.emitters) {
        if (!totalEnqueuedVaas[s.guardianAddress]) {
          totalEnqueuedVaas[s.guardianAddress] = {};
        }
        if (!totalEnqueuedVaas[s.guardianAddress][chain.chainId]) {
          totalEnqueuedVaas[s.guardianAddress][chain.chainId] = 0;
        }
        totalEnqueuedVaas[s.guardianAddress][chain.chainId] += Number(emitter.totalEnqueuedVaas);

        // NOTE: the enqueuedVaas list is limited to 20 VAAs
        for (const vaa of emitter.enqueuedVaas) {
          const emitterAddress = emitter.emitterAddress.slice(2);
          const vaaId = `${chain.chainId}/${emitterAddress}/${vaa.sequence}`;
          vaaById[vaaId] = {
            ...vaa,
            emitterChain: chain.chainId,
            emitterAddress,
            byGuardian: [
              ...(vaaById[vaaId]?.byGuardian || []),
              { ...vaa, emitterChain: chain.chainId, emitterAddress, guardianName },
            ],
          };
        }
      }
    }
  }

  const enqueuedVAAs = Object.values(vaaById);
  return {
    enqueuedVAAs,
    totalEnqueuedVaas,
  };
};

const useCloudGovernorInfo = (): CloudGovernorInfo => {
  const { currentNetwork } = useNetworkContext();
  const [governorInfo, setGovernorInfo] = useState<CloudGovernorInfo>(createEmptyInfo());

  useEffect(() => {
    setGovernorInfo(createEmptyInfo());
    if (currentNetwork.name !== 'Mainnet') {
      return;
    }
    let cancelled = false;
    (async () => {
      let configsInfo: GovernorConfigsInfo | undefined;
      while (!cancelled) {
        try {
          if (!configsInfo) {
            configsInfo = await getConfigsInfo(currentNetwork.endpoint);
            if (!cancelled) {
              const fetched = configsInfo;
              setGovernorInfo((info) => ({
                ...info,
                ...fetched,
                configsReceivedAt: new Date().toISOString(),
              }));
            }
          }
          const statusInfo = await getStatusInfo(currentNetwork.endpoint);
          if (!cancelled) {
            setGovernorInfo((info) => ({
              ...info,
              ...statusInfo,
              statusReceivedAt: new Date().toISOString(),
            }));
          }
        } catch (error) {
          console.error(error);
        }
        if (!cancelled) {
          await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [currentNetwork]);

  return governorInfo;
};

export default useCloudGovernorInfo;
