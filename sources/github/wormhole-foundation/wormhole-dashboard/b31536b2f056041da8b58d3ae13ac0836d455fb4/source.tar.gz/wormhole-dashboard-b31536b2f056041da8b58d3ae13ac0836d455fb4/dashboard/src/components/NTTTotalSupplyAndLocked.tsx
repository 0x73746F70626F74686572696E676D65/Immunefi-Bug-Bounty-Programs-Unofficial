import { Box, Card, IconButton } from '@mui/material';
import Table from './Table';
import {
  ExpandedState,
  SortingState,
  createColumnHelper,
  getCoreRowModel,
  getExpandedRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { useState } from 'react';
import { useNetworkContext } from '../contexts/NetworkContext';
import { KeyboardArrowDown, KeyboardArrowRight } from '@mui/icons-material';
import { chainIdToName } from '@wormhole-foundation/wormhole-monitor-common';
import { useTotalSupplyAndLocked } from '../hooks/useTotalSupplyAndLocked';
import { NTTTotalSupplyAndLockedData } from '@wormhole-foundation/wormhole-monitor-common';
import CollapsibleSection from './CollapsibleSection';
import FetchedAt from './FetchedAt';
import { normalizeBigNumber } from '../utils/normalizeBigNumber';

const totalSupplyAndLockedColumnHelper = createColumnHelper<NTTTotalSupplyAndLockedData>();
const rateLimitColumns = [
  totalSupplyAndLockedColumnHelper.accessor('tokenName', {
    id: 'tokenName',
    header: () => 'Token',
    cell: (info) => <>{info.row.original.evmTotalSupply ? info.row.original.tokenName : null}</>,
  }),
  totalSupplyAndLockedColumnHelper.accessor((row) => row.chain, {
    id: 'srcChain',
    header: () => 'Chain',
    cell: (info) => (
      <>
        {info.row.getCanExpand() && info.row.original.evmTotalSupply ? (
          <IconButton
            size="small"
            sx={{ ml: -1 }}
            {...{
              onClick: info.row.getToggleExpandedHandler(),
            }}
          >
            {info.row.getIsExpanded() ? (
              <KeyboardArrowDown fontSize="inherit" />
            ) : (
              <KeyboardArrowRight fontSize="inherit" />
            )}
          </IconButton>
        ) : (
          <Box sx={{ width: '20px' }} display="inline-block"></Box>
        )}{' '}
        {`${chainIdToName(info.row.original.chain)}(${info.row.original.chain})`}
      </>
    ),
  }),
  totalSupplyAndLockedColumnHelper.accessor('amountLocked', {
    header: () => <Box order="1">Locked</Box>,
    cell: (info) => (
      <Box textAlign="right">
        {info.row.original.evmTotalSupply
          ? normalizeBigNumber(info.row.original.amountLocked, 2)
          : null}
      </Box>
    ),
  }),
  totalSupplyAndLockedColumnHelper.accessor('totalSupply', {
    header: () => <Box order="1">Total EVM Supply</Box>,
    cell: (info) => (
      <Box textAlign="right">{normalizeBigNumber(info.row.original.totalSupply, 2)}</Box>
    ),
  }),
];

export function NTTTotalSupplyAndLocked() {
  const network = useNetworkContext();
  const { totalSupplyAndLocked, receivedAt } = useTotalSupplyAndLocked(network.currentNetwork);
  const [totalSupplyAndLockedSorting, setTotalSupplyAndLockedSorting] = useState<SortingState>([]);
  const [totalSupplyAndLockedExpanded, setTotalSupplyAndLockedExpanded] = useState<ExpandedState>(
    {}
  );

  const table = useReactTable({
    columns: rateLimitColumns,
    data: totalSupplyAndLocked,
    state: {
      expanded: totalSupplyAndLockedExpanded,
      sorting: totalSupplyAndLockedSorting,
    },
    getSubRows: (row) => row.evmTotalSupply,
    getRowId: (totalSupplyAndLocked) =>
      `${totalSupplyAndLocked.tokenName}-${totalSupplyAndLocked.chain || ''}`,

    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    onExpandedChange: setTotalSupplyAndLockedExpanded,
    onSortingChange: setTotalSupplyAndLockedSorting,
  });

  return (
    <CollapsibleSection
      defaultExpanded={false}
      header={
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            paddingRight: 1,
          }}
        >
          <Box>Total Supply and Locked</Box>
        </Box>
      }
    >
      <Box mt={2} mx={2}>
        <Card>
          <Table<NTTTotalSupplyAndLockedData> table={table} />
        </Card>
      </Box>
      <Box mx={2}>
        <FetchedAt entries={[{ label: 'Total supply and locked', receivedAt }]} />
      </Box>
    </CollapsibleSection>
  );
}
