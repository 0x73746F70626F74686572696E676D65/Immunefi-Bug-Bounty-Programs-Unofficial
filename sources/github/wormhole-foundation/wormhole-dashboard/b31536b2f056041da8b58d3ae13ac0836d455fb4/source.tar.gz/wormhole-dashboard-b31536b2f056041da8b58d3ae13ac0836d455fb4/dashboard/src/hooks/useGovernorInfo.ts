import {
  GovernorGetAvailableNotionalByChainResponse_Entry,
  GovernorGetEnqueuedVAAsResponse_Entry,
  GovernorGetTokenListResponse_Entry,
} from '@certusone/wormhole-sdk-proto-web/lib/cjs/publicrpc/v1/publicrpc';
import { useEffect, useState } from 'react';
import { useNetworkContext } from '../contexts/NetworkContext';
import { getGovernorAvailableNotionalByChain } from '../utils/getGovernorAvailableNotionalByChain';
import { getGovernorEnqueuedVAAs } from '../utils/getGovernorEnqueuedVAAs';
import { getGovernorTokenList } from '../utils/getGovernorTokenList';
import { tryHexToNativeAssetString } from '../utils/nativeAsset';

type GovernorInfo = {
  notionals: GovernorGetAvailableNotionalByChainResponse_Entry[];
  tokens: GovernorGetTokenListResponse_Entry[];
  enqueued: GovernorGetEnqueuedVAAsResponse_Entry[];
  notionalsReceivedAt: string | null;
  tokensReceivedAt: string | null;
  enqueuedReceivedAt: string | null;
};

const createEmptyInfo = (): GovernorInfo => ({
  notionals: [],
  tokens: [],
  enqueued: [],
  notionalsReceivedAt: null,
  tokensReceivedAt: null,
  enqueuedReceivedAt: null,
});

const TIMEOUT = 60 * 1000;

function useGovernorInfo(): GovernorInfo {
  const { currentNetwork } = useNetworkContext();
  const [governorInfo, setGovernorInfo] = useState<GovernorInfo>(createEmptyInfo());
  useEffect(() => {
    setGovernorInfo(createEmptyInfo());
  }, [currentNetwork]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      while (!cancelled && currentNetwork.type === 'guardian') {
        const response = await getGovernorAvailableNotionalByChain(currentNetwork);
        if (!cancelled) {
          setGovernorInfo((info) => ({
            ...info,
            notionals: response.entries,
            notionalsReceivedAt: new Date().toISOString(),
          }));
          await new Promise((resolve) => setTimeout(resolve, TIMEOUT));
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [currentNetwork]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      // TODO: only update GovernorInfo with changes to token list, but that will cause displaySymbols to break
      while (!cancelled && currentNetwork.type === 'guardian') {
        const response = await getGovernorTokenList(currentNetwork);
        if (!cancelled) {
          setGovernorInfo((info) => ({
            ...info,
            tokens: response.entries.map((entry) => {
              try {
                return {
                  ...entry,
                  originAddress: tryHexToNativeAssetString(
                    entry.originAddress,
                    entry.originChainId
                  ),
                };
              } catch (e) {}
              return entry;
            }),
            tokensReceivedAt: new Date().toISOString(),
          }));
          await new Promise((resolve) => setTimeout(resolve, TIMEOUT));
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [currentNetwork]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      while (!cancelled && currentNetwork.type === 'guardian') {
        const response = await getGovernorEnqueuedVAAs(currentNetwork);
        if (!cancelled) {
          setGovernorInfo((info) => ({
            ...info,
            enqueued: response.entries,
            enqueuedReceivedAt: new Date().toISOString(),
          }));
          await new Promise((resolve) => setTimeout(resolve, TIMEOUT));
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [currentNetwork]);
  return governorInfo;
}
export default useGovernorInfo;
