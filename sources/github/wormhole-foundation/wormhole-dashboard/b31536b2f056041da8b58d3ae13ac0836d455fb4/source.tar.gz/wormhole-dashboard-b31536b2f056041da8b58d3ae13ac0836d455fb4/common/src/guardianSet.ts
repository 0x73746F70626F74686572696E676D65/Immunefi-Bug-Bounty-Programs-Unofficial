// AUTO-GENERATED — do not edit manually.
// Source: https://raw.githubusercontent.com/wormhole-foundation/wormhole/refs/heads/main/guardianset/mainnetv2/canonical_sets/v7.prototxt
// Run:    npm run generate-guardians

export const GUARDIAN_SET_7 = [
  {
    pubkey: '0x5893B5A76c3f739645648885bDCcC06cd70a3Cd3',
    name: 'RockawayX',
  },
  {
    pubkey: '0xfF6CB952589BDE862c25Ef4392132fb9D4A42157',
    name: 'Staked',
  },
  {
    pubkey: '0x114De8460193bdf3A2fCf81f86a09765F4762fD1',
    name: 'Figment',
  },
  {
    pubkey: '0x107A0086b32d7A0977926A205131d8731D39cbEB',
    name: 'ChainodeTech',
  },
  {
    pubkey: '0x8C82B2fd82FaeD2711d59AF0F2499D16e726f6b2',
    name: 'Inotel',
  },
  {
    pubkey: '0x42579bFFbCF4276E290aB8E4C162bd4052b97970',
    name: 'HashQuark',
  },
  {
    pubkey: '0x938f104AEb5581293216ce97d771e0CB721221B1',
    name: 'Chainlayer',
  },
  {
    pubkey: '0xF3ea0AD4FFB5a178AE4EBc21861651B25BdcbB91',
    name: 'Chainstack',
  },
  {
    pubkey: '0x9D16870160e703324D057c3361c34C5beFBa2c34',
    name: 'Liquify',
  },
  {
    pubkey: '0x000aC0076727b35FBea2dAc28fEE5cCB0fEA768e',
    name: 'Staking Fund',
  },
  {
    pubkey: '0xAF45Ced136b9D9e24903464AE889F5C8a723FC14',
    name: 'MoonletWallet',
  },
  {
    pubkey: '0xf93124b7c738843CBB89E864c862c38cddCccF95',
    name: 'P2P.ORG Validator',
  },
  {
    pubkey: '0xD2CC37A4dc036a8D232b48f62cDD4731412f4890',
    name: '01Node',
  },
  {
    pubkey: '0xDA798F6896A3331F64b48c12D1D57Fd9cbe70811',
    name: 'MCF',
  },
  {
    pubkey: '0xaE565927Bb8dB25CD8Bf3e7BB663D70023e4Ea78',
    name: 'Firstset',
  },
  {
    pubkey: '0x3F851Ad586A47ceF8d04748f33ab0D71395f06b4',
    name: 'DSRV',
  },
  {
    pubkey: '0x178e21ad2E77AE06711549CFBB1f9c7a9d8096e8',
    name: 'Syncnode',
  },
  {
    pubkey: '0x7899cEAB1DC961Dae9defDB7A4f521269a5448FC',
    name: 'Google Cloud',
  },
  {
    pubkey: '0x61D9800f9FCb4160FB0C6cf3A0902592bAC2B434',
    name: 'Senseinode',
  },
];

/** Always points to the active guardian set. Update GUARDIAN_SET_N above and bump this alias. */
export const GUARDIAN_SET = GUARDIAN_SET_7;

/** The index of the active guardian set. */
export const GUARDIAN_SET_INDEX = 7;
