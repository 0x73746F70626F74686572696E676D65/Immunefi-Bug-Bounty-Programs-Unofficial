import PriceWidget from '@/components/PriceWidget';

export default function Page() {
	return (
		<main className='mx-auto max-w-2xl p-6'>
			<h1 className='mb-4 text-2xl font-bold'>Wormhole Queries - Price Widget</h1>
			<p className='mb-6 opacity-80'>
				Minimal widget that fetches a Guardian-signed query response via our API route.
			</p>
			<PriceWidget />
			<p className='mt-8 text-xs opacity-60'>Uses Wormhole Query SDK + Query Proxy per docs.</p>
		</main>
	);
}
