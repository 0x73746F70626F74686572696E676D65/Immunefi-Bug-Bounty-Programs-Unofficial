'use client';
import { useEffect, useRef, useState } from 'react';
import type { QueryApiResponse, QueryApiSuccess } from '@/lib/types';

function formatAbsolute(iso: string) {
	const d = new Date(iso);
	// Use the user's locale + 24h clock if available; show TZ short name
	return new Intl.DateTimeFormat(undefined, {
		year: 'numeric',
		month: 'short',
		day: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
		hour12: false,
		timeZoneName: 'short',
	}).format(d);
}

function formatRelative(iso: string) {
	const d = new Date(iso).getTime();
	const now = Date.now();
	const diffMs = Math.max(0, now - d);
	const minutes = Math.round(diffMs / 60000);
	if (minutes < 60) return `${minutes} min ago`;
	const hours = Math.round(minutes / 60);
	if (hours < 48) return `${hours} h ago`;
	const days = Math.round(hours / 24);
	return `${days} d ago`;
}

export default function PriceWidget() {
	const [data, setData] = useState<QueryApiSuccess | null>(null);
	const [err, setErr] = useState<string | null>(null);
	const [loading, setLoading] = useState(false);
	const inFlight = useRef(false);

	async function fetchOnce() {
		if (inFlight.current) return; // don't overlap requests
		inFlight.current = true;
		setLoading(true);
		try {
			const r = await fetch('/api/queries', { cache: 'no-store' });
			const j: QueryApiResponse = await r.json();
			if (!j.ok) {
				setErr(j.error);
			} else {
				setErr(null);
				setData(j);
			}
		} catch (e: unknown) {
			setErr(e instanceof Error ? e.message : String(e));
		} finally {
			setLoading(false);
			inFlight.current = false;
		}
	}

	useEffect(() => {
		fetchOnce();
		const t = setInterval(fetchOnce, 30_000); // polite poll
		return () => clearInterval(t);
	}, []);

	const priceDisplay = data
		? Number(data.price).toLocaleString(undefined, {
				minimumFractionDigits: 3,
				maximumFractionDigits: 6,
		  })
		: '';

	const absolute = data ? formatAbsolute(data.updatedAt) : '';
	const relative = data ? formatRelative(data.updatedAt) : '';

	return (
		<div className='max-w-2xl rounded-2xl border p-6 shadow-sm'>
			<div className='text-2xl font-semibold'>ETH/USD (Arbitrum Sepolia)</div>

			{data && (
				<div className='mt-4 space-y-2 text-sm'>
					<div className='text-base'>
						<span className='opacity-70'>price:</span>{' '}
						<span className='font-semibold'>${priceDisplay} USD</span>
						{data.stale ? (
							<span className='ml-2 rounded bg-yellow-100 px-2 py-0.5 text-xs text-yellow-800'>
								stale
							</span>
						) : null}
						
					</div>

					<div className='opacity-80'>
						<span className='opacity-70'>last price update:</span> {absolute} • {relative}
					</div>

					<div className='opacity-70'>query block: {data.blockNumber}</div>
				</div>
			)}

			{err && (
				<div className='mt-4 text-sm text-yellow-700'>
					{err} {loading ? '(updating…)' : ''}
				</div>
			)}

			{!data && loading && <div className='mt-4 text-sm opacity-70'>Loading…</div>}
		</div>
	);
}
