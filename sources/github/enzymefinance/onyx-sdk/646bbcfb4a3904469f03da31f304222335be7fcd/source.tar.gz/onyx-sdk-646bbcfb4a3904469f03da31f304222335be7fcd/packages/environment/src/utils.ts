import type { Address } from "viem";
import { zeroAddress } from "viem";

import { deployments } from "./deployments/all.js";
import type { Network, NetworkSlug } from "./networks.js";
import { getNetwork, isNetworkIdentifier } from "./networks.js";
import type { DeploymentDefinition, DeploymentType, DeploymentTypeWithRelease, ReleasesFields } from "./releases.js";
import { Deployment, isDeployment, Kind } from "./releases.js";

export function isHexString(value: unknown, length?: number): boolean {
  if (typeof value !== "string" || !/^0x[0-9A-Fa-f]*$/.test(value)) {
    return false;
  }

  if (length && value.length !== 2 + 2 * length) {
    return false;
  }

  return true;
}

export function isAddress(value: unknown): value is Address {
  return isHexString(value) && /^0x[0-9a-f]{40}$/.test(value as string);
}

export function isNonZeroAddress(value: unknown): value is Address {
  return isHexString(value) && value !== zeroAddress;
}

export function toAddress(value: string): Address {
  const address = value.toLowerCase();

  if (isAddress(address)) {
    return address;
  }

  throw new Error("Invalid address");
}

export function getDeployment<TDeployment extends DeploymentType>(
  deployment: TDeployment,
): DeploymentDefinition<TDeployment>;
export function getDeployment(network: Network | NetworkSlug): DeploymentDefinition<DeploymentType>;
export function getDeployment<TDeployment extends DeploymentType>(
  deployment: TDeployment,
): DeploymentDefinition<TDeployment>;
export function getDeployment(
  deploymentOrNetwork: DeploymentType | Network | NetworkSlug,
): DeploymentDefinition<DeploymentType>;

export function getDeployment(deploymentOrNetwork: DeploymentType | Network | NetworkSlug) {
  if (isDeployment(deploymentOrNetwork)) {
    return deployments[deploymentOrNetwork];
  }

  if (isNetworkIdentifier(deploymentOrNetwork)) {
    const network = getNetwork(deploymentOrNetwork as Network);
    const deployment = Object.values(deployments).find(
      (item) => item.network === network.id && item.kind === Kind.LIVE,
    );

    if (!deployment) {
      throw new Error(`Missing deployment for network ${network.slug}`);
    }

    return deployment;
  }

  throw new Error(`Unknown deployment or network ${deploymentOrNetwork}`);
}

export function getDeploymentByCcipSelector(
  ccipChainSelector: bigint | string,
): DeploymentDefinition<DeploymentType> | undefined {
  const selector = typeof ccipChainSelector === "bigint" ? ccipChainSelector : BigInt(ccipChainSelector);
  return Object.values(deployments).find(
    (item) => item.slug !== Deployment.RAYLS && item.ccipChainSelector === selector,
  );
}

/**
 * Variant of {@link getDeployment} that only accepts deployment slugs known at compile time to
 * have a contract release (i.e. excludes CCIP-only deployments such as Base Sepolia).
 */
export function getDeploymentWithRelease<TDeployment extends DeploymentTypeWithRelease>(
  slug: TDeployment,
): DeploymentDefinition<TDeployment> {
  return deployments[slug] as unknown as DeploymentDefinition<TDeployment>;
}

/**
 * Runtime type guard that narrows a {@link DeploymentDefinition} to one that has releases.
 */
export function hasReleases<TDeployment extends DeploymentType>(
  deployment: DeploymentDefinition<TDeployment>,
): deployment is DeploymentDefinition<TDeployment> & ReleasesFields<TDeployment> {
  return deployment.releases !== undefined;
}
