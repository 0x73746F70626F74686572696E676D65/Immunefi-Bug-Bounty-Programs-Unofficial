export enum Network {
  ARBITRUM = 42161,
  BASE = 8453,
  BASE_SEPOLIA = 84532,
  BSC = 56,
  ETHEREUM = 1,
  MEGAETH = 4326,
  PLUME = 98866,
  RAYLS = 72957,
  SEPOLIA = 11155111,
}

export enum NetworkSlug {
  ARBITRUM = "arbitrum",
  BASE = "base",
  BASE_SEPOLIA = "base-sepolia",
  BSC = "bsc",
  ETHEREUM = "ethereum",
  MEGAETH = "megaeth",
  PLUME = "plume",
  RAYLS = "rayls",
  SEPOLIA = "sepolia",
}

type SlugByNetworkMap = {
  [Network.ARBITRUM]: NetworkSlug.ARBITRUM;
  [Network.BASE]: NetworkSlug.BASE;
  [Network.BASE_SEPOLIA]: NetworkSlug.BASE_SEPOLIA;
  [Network.BSC]: NetworkSlug.BSC;
  [Network.ETHEREUM]: NetworkSlug.ETHEREUM;
  [Network.MEGAETH]: NetworkSlug.MEGAETH;
  [Network.PLUME]: NetworkSlug.PLUME;
  [Network.RAYLS]: NetworkSlug.RAYLS;
  [Network.SEPOLIA]: NetworkSlug.SEPOLIA;
};

type NetworkBySlugMap = {
  [NetworkSlug.ARBITRUM]: Network.ARBITRUM;
  [NetworkSlug.BASE]: Network.BASE;
  [NetworkSlug.BASE_SEPOLIA]: Network.BASE_SEPOLIA;
  [NetworkSlug.BSC]: Network.BSC;
  [NetworkSlug.ETHEREUM]: Network.ETHEREUM;
  [NetworkSlug.MEGAETH]: Network.MEGAETH;
  [NetworkSlug.PLUME]: Network.PLUME;
  [NetworkSlug.RAYLS]: Network.RAYLS;
  [NetworkSlug.SEPOLIA]: Network.SEPOLIA;
};

export type SlugByNetwork<TNetwork extends Network> = SlugByNetworkMap[TNetwork];

export type NetworkBySlug<TNetworkSlug extends NetworkSlug> = NetworkBySlugMap[TNetworkSlug];

export function getNetwork<TNetwork extends Network = Network>(network: TNetwork): NetworkDefinition<TNetwork>;
export function getNetwork<TNetworkSlug extends NetworkSlug = NetworkSlug>(
  slug: TNetworkSlug,
): NetworkDefinition<NetworkBySlug<TNetworkSlug>>;
export function getNetwork(networkOrSlug: Network | NetworkSlug): NetworkDefinition;

export function getNetwork(networkOrSlug: Network | NetworkSlug): NetworkDefinition {
  if (isSupportedNetwork(networkOrSlug)) {
    return networks[networkOrSlug];
  }

  if (isSupportedNetworkSlug(networkOrSlug)) {
    return networks[networkBySlug[networkOrSlug]];
  }

  throw new Error(`Invalid network ${networkOrSlug}`);
}

export function isNetworkIdentifier(value: unknown): value is Network | NetworkSlug {
  return isSupportedNetwork(Number(value)) || isSupportedNetworkSlug(value);
}

export function isSupportedNetworkSlug(value: unknown): value is NetworkSlug {
  return typeof value === "string" && Object.values<unknown>(NetworkSlug).includes(value);
}

export function isSupportedNetwork(value: unknown): value is Network {
  const number = Number(value);

  return !Number.isNaN(number) && Object.values<unknown>(Network).includes(number);
}

export interface NetworkDefinition<TNetwork extends Network = Network> {
  readonly currency: {
    readonly nativeToken: {
      name: string;
      symbol: string;
      decimals: number;
      network: Network;
    };
  };
  readonly explorer: {
    readonly label: string;
    readonly url: string;
  };
  readonly id: TNetwork;
  readonly slug: SlugByNetwork<TNetwork>;
  readonly label: string;
}

export const slugByNetwork: {
  readonly [TNetwork in Network]: SlugByNetwork<TNetwork>;
} = {
  [Network.ARBITRUM]: NetworkSlug.ARBITRUM,
  [Network.BASE]: NetworkSlug.BASE,
  [Network.BASE_SEPOLIA]: NetworkSlug.BASE_SEPOLIA,
  [Network.BSC]: NetworkSlug.BSC,
  [Network.ETHEREUM]: NetworkSlug.ETHEREUM,
  [Network.MEGAETH]: NetworkSlug.MEGAETH,
  [Network.PLUME]: NetworkSlug.PLUME,
  [Network.RAYLS]: NetworkSlug.RAYLS,
  [Network.SEPOLIA]: NetworkSlug.SEPOLIA,
};

export const networkBySlug: {
  readonly [TNetworkSlug in NetworkSlug]: NetworkBySlug<TNetworkSlug>;
} = {
  [NetworkSlug.ARBITRUM]: Network.ARBITRUM,
  [NetworkSlug.BASE]: Network.BASE,
  [NetworkSlug.BASE_SEPOLIA]: Network.BASE_SEPOLIA,
  [NetworkSlug.BSC]: Network.BSC,
  [NetworkSlug.ETHEREUM]: Network.ETHEREUM,
  [NetworkSlug.MEGAETH]: Network.MEGAETH,
  [NetworkSlug.PLUME]: Network.PLUME,
  [NetworkSlug.RAYLS]: Network.RAYLS,
  [NetworkSlug.SEPOLIA]: Network.SEPOLIA,
};

const arbitrum: NetworkDefinition<Network.ARBITRUM> = {
  currency: {
    nativeToken: {
      name: "Ether",
      symbol: "ETH",
      decimals: 18,
      network: Network.ARBITRUM,
    },
  },
  explorer: {
    label: "Arbiscan",
    url: "https://arbiscan.io/",
  },
  id: Network.ARBITRUM,
  label: "Arbitrum",
  slug: NetworkSlug.ARBITRUM,
} as const;

const base: NetworkDefinition<Network.BASE> = {
  currency: {
    nativeToken: {
      name: "Ether",
      symbol: "ETH",
      decimals: 18,
      network: Network.BASE,
    },
  },
  explorer: {
    label: "BaseScan",
    url: "https://basescan.org/",
  },
  id: Network.BASE,
  label: "Base",
  slug: NetworkSlug.BASE,
};

const baseSepolia: NetworkDefinition<Network.BASE_SEPOLIA> = {
  currency: {
    nativeToken: {
      name: "Base Sepolia Ether",
      symbol: "ETH",
      decimals: 18,
      network: Network.BASE_SEPOLIA,
    },
  },
  explorer: {
    label: "Base Sepolia BaseScan",
    url: "https://sepolia.basescan.org/",
  },
  id: Network.BASE_SEPOLIA,
  label: "Base Sepolia",
  slug: NetworkSlug.BASE_SEPOLIA,
};

const megaeth: NetworkDefinition<Network.MEGAETH> = {
  currency: {
    nativeToken: {
      name: "Ether",
      symbol: "ETH",
      decimals: 18,
      network: Network.MEGAETH,
    },
  },
  explorer: {
    label: "Blockscout",
    url: "https://megaeth.blockscout.com/",
  },
  id: Network.MEGAETH,
  label: "MegaETH",
  slug: NetworkSlug.MEGAETH,
};

const mainnet: NetworkDefinition<Network.ETHEREUM> = {
  currency: {
    nativeToken: {
      name: "Ether",
      symbol: "ETH",
      decimals: 18,
      network: Network.ETHEREUM,
    },
  },
  explorer: {
    label: "Etherscan",
    url: "https://etherscan.io/",
  },
  id: Network.ETHEREUM,
  label: "Ethereum",
  slug: NetworkSlug.ETHEREUM,
};

const sepolia: NetworkDefinition<Network.SEPOLIA> = {
  currency: {
    nativeToken: {
      name: "Sepolia Ether",
      symbol: "ETH",
      decimals: 18,
      network: Network.SEPOLIA,
    },
  },
  explorer: {
    label: "Sepolia Etherscan",
    url: "https://sepolia.etherscan.io/",
  },
  id: Network.SEPOLIA,
  label: "Sepolia",
  slug: NetworkSlug.SEPOLIA,
};

const plume: NetworkDefinition<Network.PLUME> = {
  currency: {
    nativeToken: {
      name: "Plume Token",
      symbol: "PLUME",
      decimals: 18,
      network: Network.PLUME,
    },
  },
  explorer: {
    label: "Plume Explorer",
    url: "https://explorer.plume.org/",
  },
  id: Network.PLUME,
  label: "Plume",
  slug: NetworkSlug.PLUME,
};

const rayls: NetworkDefinition<Network.RAYLS> = {
  currency: {
    nativeToken: {
      name: "USD Rayls",
      symbol: "USDr",
      decimals: 18,
      network: Network.RAYLS,
    },
  },
  explorer: {
    label: "Rayls Explorer",
    url: "https://explorer.rayls.com/",
  },
  id: Network.RAYLS,
  label: "Rayls",
  slug: NetworkSlug.RAYLS,
};

const bsc: NetworkDefinition<Network.BSC> = {
  currency: {
    nativeToken: {
      name: "BNB",
      symbol: "BNB",
      decimals: 18,
      network: Network.BSC,
    },
  },
  explorer: {
    label: "BscScan",
    url: "https://bscscan.com/",
  },
  id: Network.BSC,
  label: "BNB Smart Chain",
  slug: NetworkSlug.BSC,
};

export const networks: {
  readonly [TNetwork in Network]: NetworkDefinition<TNetwork>;
} = {
  [Network.ARBITRUM]: arbitrum,
  [Network.BASE]: base,
  [Network.BASE_SEPOLIA]: baseSepolia,
  [Network.BSC]: bsc,
  [Network.ETHEREUM]: mainnet,
  [Network.MEGAETH]: megaeth,
  [Network.PLUME]: plume,
  [Network.RAYLS]: rayls,
  [Network.SEPOLIA]: sepolia,
};
