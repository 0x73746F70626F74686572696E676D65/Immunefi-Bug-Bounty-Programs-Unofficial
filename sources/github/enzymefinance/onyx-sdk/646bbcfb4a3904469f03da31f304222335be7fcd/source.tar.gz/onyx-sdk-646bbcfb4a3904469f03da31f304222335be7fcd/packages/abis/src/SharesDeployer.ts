export const SharesDeployerAbi = [
  {
    type: "constructor",
    inputs: [
      {
        name: "_factories",
        type: "tuple",
        internalType: "struct SharesDeployer.Factories",
        components: [
          {
            name: "sharesFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "feeHandlerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "valuationHandlerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "managementFeeTrackerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "performanceFeeTrackerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "accountERC20TrackerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "linearCreditDebtTrackerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "depositQueueFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "syncDepositHandlerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "redeemQueueFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharesOwnedAddressListFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "ownableAddressListFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "addressListsSharesTransferValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharesMintHandlerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharesBurnHandlerFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceDepositQueuePreRequestValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceDepositQueuePostExecuteValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceRedeemQueuePreRequestValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceRedeemQueuePostExecuteValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceSyncDepositPostDepositValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceMintPreMintValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceBurnPreBurnValidatorFactory",
            type: "address",
            internalType: "address",
          },
          {
            name: "aceSharesTransferValidatorFactory",
            type: "address",
            internalType: "address",
          },
        ],
      },
    ],
    stateMutability: "nonpayable",
  },
  {
    type: "function",
    name: "ACCOUNT_ERC20_TRACKER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "ADDRESS_LISTS_SHARES_TRANSFER_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_BURN_PRE_BURN_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_DEPOSIT_QUEUE_POST_EXECUTE_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_DEPOSIT_QUEUE_PRE_REQUEST_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_MINT_PRE_MINT_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_REDEEM_QUEUE_POST_EXECUTE_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_REDEEM_QUEUE_PRE_REQUEST_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_SHARES_TRANSFER_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "CHAINLINK_ACE_SYNC_DEPOSIT_POST_DEPOSIT_VALIDATOR_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "DEPOSIT_QUEUE_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "FEE_HANDLER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "LINEAR_CREDIT_DEBT_TRACKER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "MANAGEMENT_FEE_TRACKER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "OWNABLE_ADDRESS_LIST_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "PERFORMANCE_FEE_TRACKER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "REDEEM_QUEUE_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "SHARES_BURN_HANDLER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "SHARES_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "SHARES_MINT_HANDLER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "SHARES_OWNED_ADDRESS_LIST_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "SYNC_DEPOSIT_HANDLER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "VALUATION_HANDLER_FACTORY",
    inputs: [],
    outputs: [{ name: "", type: "address", internalType: "address" }],
    stateMutability: "view",
  },
  {
    type: "function",
    name: "deploy",
    inputs: [
      {
        name: "_cfg",
        type: "tuple",
        internalType: "struct SharesDeployer.DeployConfig",
        components: [
          {
            name: "shares",
            type: "tuple",
            internalType: "struct SharesDeployer.SharesConfig",
            components: [
              { name: "name", type: "string", internalType: "string" },
              {
                name: "symbol",
                type: "string",
                internalType: "string",
              },
              {
                name: "valueAsset",
                type: "bytes32",
                internalType: "bytes32",
              },
            ],
          },
          {
            name: "nominatedOwner",
            type: "address",
            internalType: "address",
          },
          {
            name: "admins",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "transferValidator",
            type: "tuple",
            internalType: "struct SharesDeployer.TransferValidatorConfig",
            components: [
              {
                name: "source",
                type: "uint8",
                internalType: "enum SharesDeployer.TransferValidatorSource",
              },
              {
                name: "existing",
                type: "address",
                internalType: "address",
              },
              {
                name: "recipientList",
                type: "tuple",
                internalType: "struct SharesDeployer.AddressListsValidatorListConfig",
                components: [
                  {
                    name: "listType",
                    type: "uint8",
                    internalType: "enum AddressListsSharesTransferValidator.ListType",
                  },
                  {
                    name: "externalListSource",
                    type: "uint8",
                    internalType: "enum SharesDeployer.ExternalListSource",
                  },
                  {
                    name: "externalListExisting",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "sharedAddressListIndex",
                    type: "uint256",
                    internalType: "uint256",
                  },
                ],
              },
              {
                name: "senderList",
                type: "tuple",
                internalType: "struct SharesDeployer.AddressListsValidatorListConfig",
                components: [
                  {
                    name: "listType",
                    type: "uint8",
                    internalType: "enum AddressListsSharesTransferValidator.ListType",
                  },
                  {
                    name: "externalListSource",
                    type: "uint8",
                    internalType: "enum SharesDeployer.ExternalListSource",
                  },
                  {
                    name: "externalListExisting",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "sharedAddressListIndex",
                    type: "uint256",
                    internalType: "uint256",
                  },
                ],
              },
              {
                name: "chainlinkAcePolicyEngine",
                type: "address",
                internalType: "address",
              },
            ],
          },
          {
            name: "components",
            type: "tuple",
            internalType: "struct SharesDeployer.ComponentsConfig",
            components: [
              {
                name: "feeHandler",
                type: "tuple",
                internalType: "struct SharesDeployer.FeeHandlerConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "feeAsset",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "entranceFeeBps",
                    type: "uint16",
                    internalType: "uint16",
                  },
                  {
                    name: "entranceFeeRecipient",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "exitFeeBps",
                    type: "uint16",
                    internalType: "uint16",
                  },
                  {
                    name: "exitFeeRecipient",
                    type: "address",
                    internalType: "address",
                  },
                ],
              },
              {
                name: "managementFee",
                type: "tuple",
                internalType: "struct SharesDeployer.ManagementFeeConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "feeBps",
                    type: "uint16",
                    internalType: "uint16",
                  },
                  {
                    name: "recipient",
                    type: "address",
                    internalType: "address",
                  },
                ],
              },
              {
                name: "performanceFee",
                type: "tuple",
                internalType: "struct SharesDeployer.PerformanceFeeConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "feeBps",
                    type: "uint16",
                    internalType: "uint16",
                  },
                  {
                    name: "hurdleRateBps",
                    type: "int16",
                    internalType: "int16",
                  },
                  {
                    name: "recipient",
                    type: "address",
                    internalType: "address",
                  },
                ],
              },
              {
                name: "valuationHandler",
                type: "tuple",
                internalType: "struct SharesDeployer.ValuationHandlerConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "assetRates",
                    type: "tuple[]",
                    internalType: "struct ValuationHandler.AssetRateInput[]",
                    components: [
                      {
                        name: "asset",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "rate",
                        type: "uint128",
                        internalType: "uint128",
                      },
                      {
                        name: "expiry",
                        type: "uint40",
                        internalType: "uint40",
                      },
                    ],
                  },
                ],
              },
              {
                name: "accountERC20Tracker",
                type: "tuple",
                internalType: "struct SharesDeployer.AccountERC20TrackerConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "assets",
                    type: "address[]",
                    internalType: "address[]",
                  },
                ],
              },
              {
                name: "linearCreditDebtTracker",
                type: "tuple",
                internalType: "struct SharesDeployer.LinearCreditDebtTrackerConfig",
                components: [{ name: "deploy", type: "bool", internalType: "bool" }],
              },
              {
                name: "queueDepositHandlers",
                type: "tuple[]",
                internalType: "struct SharesDeployer.QueueDepositHandlerConfig[]",
                components: [
                  {
                    name: "asset",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "minRequestDuration",
                    type: "uint24",
                    internalType: "uint24",
                  },
                  {
                    name: "restriction",
                    type: "uint8",
                    internalType: "enum ERC7540LikeDepositQueue.DepositRestriction",
                  },
                  {
                    name: "externalListSource",
                    type: "uint8",
                    internalType: "enum SharesDeployer.ExternalListSource",
                  },
                  {
                    name: "externalListExisting",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "sharedAddressListIndex",
                    type: "uint256",
                    internalType: "uint256",
                  },
                  {
                    name: "allowedDepositors",
                    type: "address[]",
                    internalType: "address[]",
                  },
                  {
                    name: "preRequestDepositHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                  {
                    name: "postExecuteDepositRequestHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                ],
              },
              {
                name: "syncDepositHandlers",
                type: "tuple[]",
                internalType: "struct SharesDeployer.SyncDepositHandlerConfig[]",
                components: [
                  {
                    name: "asset",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "maxSharePriceStaleness",
                    type: "uint24",
                    internalType: "uint24",
                  },
                  {
                    name: "depositorAllowlistSource",
                    type: "uint8",
                    internalType: "enum SharesDeployer.ExternalListSource",
                  },
                  {
                    name: "depositorAllowlistExisting",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "sharedAddressListIndex",
                    type: "uint256",
                    internalType: "uint256",
                  },
                  {
                    name: "postDepositHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                ],
              },
              {
                name: "redeemHandlers",
                type: "tuple[]",
                internalType: "struct SharesDeployer.RedeemHandlerConfig[]",
                components: [
                  {
                    name: "asset",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "minRequestDuration",
                    type: "uint24",
                    internalType: "uint24",
                  },
                  {
                    name: "preRequestRedeemHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                  {
                    name: "postExecuteRedeemRequestHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                ],
              },
              {
                name: "sharesMintHandler",
                type: "tuple",
                internalType: "struct SharesDeployer.SharesMintHandlerConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "preMintHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                ],
              },
              {
                name: "sharesBurnHandler",
                type: "tuple",
                internalType: "struct SharesDeployer.SharesBurnHandlerConfig",
                components: [
                  {
                    name: "deploy",
                    type: "bool",
                    internalType: "bool",
                  },
                  {
                    name: "preBurnHook",
                    type: "tuple",
                    internalType: "struct SharesDeployer.HookConfig",
                    components: [
                      {
                        name: "source",
                        type: "uint8",
                        internalType: "enum SharesDeployer.HookSource",
                      },
                      {
                        name: "existingHook",
                        type: "address",
                        internalType: "address",
                      },
                      {
                        name: "policyEngine",
                        type: "address",
                        internalType: "address",
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            name: "preMint",
            type: "tuple",
            internalType: "struct SharesDeployer.PreMintConfig",
            components: [
              { name: "enabled", type: "bool", internalType: "bool" },
              {
                name: "untrackedPositionsValue",
                type: "int256",
                internalType: "int256",
              },
              {
                name: "recipients",
                type: "tuple[]",
                internalType: "struct SharesDeployer.PreMintRecipient[]",
                components: [
                  {
                    name: "to",
                    type: "address",
                    internalType: "address",
                  },
                  {
                    name: "amount",
                    type: "uint256",
                    internalType: "uint256",
                  },
                ],
              },
            ],
          },
          {
            name: "sharedAddressLists",
            type: "tuple[]",
            internalType: "struct SharesDeployer.SharedAddressListDefinition[]",
            components: [
              {
                name: "kind",
                type: "uint8",
                internalType: "enum SharesDeployer.SharedAddressListKind",
              },
              {
                name: "ownableListOwner",
                type: "address",
                internalType: "address",
              },
              {
                name: "seededAddresses",
                type: "address[]",
                internalType: "address[]",
              },
            ],
          },
        ],
      },
    ],
    outputs: [{ name: "shares_", type: "address", internalType: "address" }],
    stateMutability: "nonpayable",
  },
  {
    type: "event",
    name: "VaultDeployed",
    inputs: [
      {
        name: "deployed",
        type: "tuple",
        indexed: false,
        internalType: "struct SharesDeployer.Deployed",
        components: [
          { name: "shares", type: "address", internalType: "address" },
          {
            name: "feeHandler",
            type: "address",
            internalType: "address",
          },
          {
            name: "valuationHandler",
            type: "address",
            internalType: "address",
          },
          {
            name: "managementFeeTracker",
            type: "address",
            internalType: "address",
          },
          {
            name: "performanceFeeTracker",
            type: "address",
            internalType: "address",
          },
          {
            name: "accountERC20Tracker",
            type: "address",
            internalType: "address",
          },
          {
            name: "linearCreditDebtTracker",
            type: "address",
            internalType: "address",
          },
          {
            name: "queueDepositHandlers",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "queueDepositHandlerAllowlists",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "queueDepositHandlerPreRequestHooks",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "queueDepositHandlerPostExecuteHooks",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "syncDepositHandlers",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "syncDepositHandlerAllowlists",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "syncDepositHandlerPostDepositHooks",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "redeemHandlers",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "redeemHandlerPreRequestHooks",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "redeemHandlerPostExecuteHooks",
            type: "address[]",
            internalType: "address[]",
          },
          {
            name: "sharesMintHandler",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharesMintHandlerPreMintHook",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharesBurnHandler",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharesBurnHandlerPreBurnHook",
            type: "address",
            internalType: "address",
          },
          {
            name: "transferValidator",
            type: "address",
            internalType: "address",
          },
          {
            name: "transferValidatorRecipientList",
            type: "address",
            internalType: "address",
          },
          {
            name: "transferValidatorSenderList",
            type: "address",
            internalType: "address",
          },
          {
            name: "sharedAddressLists",
            type: "address[]",
            internalType: "address[]",
          },
        ],
      },
      {
        name: "nominatedOwner",
        type: "address",
        indexed: false,
        internalType: "address",
      },
    ],
    anonymous: false,
  },
  {
    type: "error",
    name: "SafeERC20FailedOperation",
    inputs: [{ name: "token", type: "address", internalType: "address" }],
  },
  {
    type: "error",
    name: "SharesDeployer__AccountERC20TrackerRequiresValuationHandler",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__ExternalListExistingCannotBeZero",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__ExternalListSourceNotAllowed",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__ExternalListSourceRequired",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__HookExistingCannotBeZero",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__HookNotAllowedWithoutHandler",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__LinearCreditDebtTrackerRequiresValuationHandler",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__ManagementFeeRequiresFeeHandler",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__NominatedOwnerCannotBeDeployer",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__NominatedOwnerCannotBeZero",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__OwnableAddressListOwnerCannotBeZero",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__PerformanceFeeRequiresFeeHandler",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__PolicyEngineCannotBeZero",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__PreMintRequiresValuationHandler",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__SeedNotAllowedForExternalList",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__SeedNotAllowedWithoutAllowlist",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__SharedAddressListIndexOutOfBounds",
    inputs: [],
  },
  {
    type: "error",
    name: "SharesDeployer__TransferValidatorExistingCannotBeZero",
    inputs: [],
  },
] as const;
