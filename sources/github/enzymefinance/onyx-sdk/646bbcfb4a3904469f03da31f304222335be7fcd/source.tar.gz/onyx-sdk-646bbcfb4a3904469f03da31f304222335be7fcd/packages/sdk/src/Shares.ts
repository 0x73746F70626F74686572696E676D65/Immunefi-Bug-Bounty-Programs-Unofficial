import { SharesAbi } from "@enzymefinance/onyx-abis";
import type { ValueAssetType } from "@enzymefinance/onyx-environment";
import { encodeValueAsset } from "@enzymefinance/onyx-environment";
import type { Address, Client, Hex } from "viem";
import { decodeFunctionResult, encodeFunctionData } from "viem";
import { readContract } from "viem/actions";
import { deployProxy } from "./factories/BeaconFactory.js";
import { Viem } from "./Utils.js";

//--------------------------------------------------------------------------------------------
// TRANSACTIONS
//--------------------------------------------------------------------------------------------

// Deploy

export type DeploySharesProxyParams = {
  sharesFactoryAddress: Address;
  owner: Address;
  name: string;
  symbol: string;
  valueAsset: ValueAssetType;
};

export function deployShares(args: DeploySharesProxyParams) {
  const initData = encodeFunctionData({
    abi: SharesAbi,
    functionName: "init",
    args: [args.owner, args.name, args.symbol, encodeValueAsset(args.valueAsset)],
  });

  return deployProxy({
    factoryAddress: args.sharesFactoryAddress,
    initData,
  });
}

// Ownership

export function transferOwnership(args: { sharesAddress: Address; newOwner: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "transferOwnership",
    args: [args.newOwner],
    address: args.sharesAddress,
  });
}

export function acceptOwnership(args: { sharesAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "acceptOwnership",
    address: args.sharesAddress,
  });
}

// Contract admins

export function addAdmin(args: { sharesAddress: Address; admin: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "addAdmin",
    args: [args.admin],
    address: args.sharesAddress,
  });
}

export function removeAdmin(args: { sharesAddress: Address; admin: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "removeAdmin",
    args: [args.admin],
    address: args.sharesAddress,
  });
}

// Share Value Handler

export function setValuationHandler(args: { sharesAddress: Address; valuationHandlerAddress: Hex }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "setValuationHandler",
    address: args.sharesAddress,
    args: [args.valuationHandlerAddress],
  });
}

// Fee Handler

export function setFeeHandler(args: { sharesAddress: Address; feeHandlerAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "setFeeHandler",
    args: [args.feeHandlerAddress],
    address: args.sharesAddress,
  });
}

// Shares Issuance

export function mintFor(args: { sharesAddress: Address; to: Address; amount: bigint }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "mintFor",
    args: [args.to, args.amount],
    address: args.sharesAddress,
  });
}

export function burnFor(args: { sharesAddress: Address; from: Address; amount: bigint }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "burnFor",
    args: [args.from, args.amount],
    address: args.sharesAddress,
  });
}

export function addDepositHandler(args: { sharesAddress: Address; depositHandlerAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "addDepositHandler",
    args: [args.depositHandlerAddress],
    address: args.sharesAddress,
  });
}

export function removeDepositHandler(args: { sharesAddress: Address; depositHandlerAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "removeDepositHandler",
    args: [args.depositHandlerAddress],
    address: args.sharesAddress,
  });
}

export function addRedeemHandler(args: { sharesAddress: Address; redeemHandlerAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "addRedeemHandler",
    args: [args.redeemHandlerAddress],
    address: args.sharesAddress,
  });
}

export function removeRedeemHandler(args: { sharesAddress: Address; redeemHandlerAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "removeRedeemHandler",
    args: [args.redeemHandlerAddress],
    address: args.sharesAddress,
  });
}

export function setSharesTransferValidator(args: { sharesAddress: Address; validatorAddress: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "setSharesTransferValidator",
    args: [args.validatorAddress],
    address: args.sharesAddress,
  });
}

// ERC20

export function approve(args: { sharesAddress: Address; spender: Address; amount: bigint }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "approve",
    address: args.sharesAddress,
    args: [args.spender, args.amount],
  });
}

export function transfer(args: { sharesAddress: Address; to: Address; amount: bigint }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "transfer",
    address: args.sharesAddress,
    args: [args.to, args.amount],
  });
}

export function transferFrom(args: { sharesAddress: Address; from: Address; to: Address; amount: bigint }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "transferFrom",
    address: args.sharesAddress,
    args: [args.from, args.to, args.amount],
  });
}

export function authTransferFrom(args: { sharesAddress: Address; from: Address; to: Address; amount: bigint }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "authTransferFrom",
    address: args.sharesAddress,
    args: [args.from, args.to, args.amount],
  });
}

// Withdraw

export function withdrawAssetTo(args: { sharesAddress: Address; assetAddress: Address; amount: bigint; to: Address }) {
  return new Viem.PopulatedTransaction({
    abi: SharesAbi,
    functionName: "withdrawAssetTo",
    args: [args.assetAddress, args.to, args.amount],
    address: args.sharesAddress,
  });
}

export function encodeWithdrawAssetTo(args: { assetAddress: Address; to: Address; amount: bigint }): Hex {
  return encodeFunctionData({
    abi: SharesAbi,
    functionName: "withdrawAssetTo",
    args: [args.assetAddress, args.to, args.amount],
  });
}

export function decodeWithdrawAssetTo(data: Hex) {
  return decodeFunctionResult({
    abi: SharesAbi,
    functionName: "withdrawAssetTo",
    data,
  });
}

//--------------------------------------------------------------------------------------------
// READ FUNCTIONS
//--------------------------------------------------------------------------------------------

export function owner(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "owner",
    address: args.sharesAddress,
  });
}

export function pendingOwner(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "pendingOwner",
    address: args.sharesAddress,
  });
}

export function sharePrice(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "sharePrice",
    address: args.sharesAddress,
  });
}

export function getFeeHandler(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "getFeeHandler",
    address: args.sharesAddress,
  });
}

export function getSharesTransferValidator(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "getSharesTransferValidator",
    address: args.sharesAddress,
  });
}

export function getValueAsset(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "getValueAsset",
    address: args.sharesAddress,
  });
}

export function getValuationHandler(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "getValuationHandler",
    address: args.sharesAddress,
  });
}

export function encodeGetValuationHandler() {
  return encodeFunctionData({
    abi: SharesAbi,
    functionName: "getValuationHandler",
    args: [],
  });
}

export function decodeGetValuationHandler(data: Hex) {
  return decodeFunctionResult({
    abi: SharesAbi,
    functionName: "getValuationHandler",
    data,
  });
}

export function isAdmin(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
    userAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "isAdmin",
    address: args.sharesAddress,
    args: [args.userAddress],
  });
}

export function isDepositHandler(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
    address: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "isDepositHandler",
    address: args.sharesAddress,
    args: [args.address],
  });
}

export function isRedeemHandler(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
    address: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "isRedeemHandler",
    address: args.sharesAddress,
    args: [args.address],
  });
}

// ERC20

export function totalSupply(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "totalSupply",
    address: args.sharesAddress,
  });
}

export function balanceOf(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
    userAddress: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "balanceOf",
    address: args.sharesAddress,
    args: [args.userAddress],
  });
}

export function allowance(
  client: Client,
  args: Viem.ContractCallParameters<{
    sharesAddress: Address;
    owner: Address;
    spender: Address;
  }>,
) {
  return readContract(client, {
    ...Viem.extractBlockParameters(args),
    abi: SharesAbi,
    functionName: "allowance",
    address: args.sharesAddress,
    args: [args.owner, args.spender],
  });
}
