print 3
