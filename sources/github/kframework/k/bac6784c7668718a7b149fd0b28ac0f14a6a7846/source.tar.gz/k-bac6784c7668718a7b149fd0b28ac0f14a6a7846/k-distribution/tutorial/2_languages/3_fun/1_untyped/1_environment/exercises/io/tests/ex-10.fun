print read
