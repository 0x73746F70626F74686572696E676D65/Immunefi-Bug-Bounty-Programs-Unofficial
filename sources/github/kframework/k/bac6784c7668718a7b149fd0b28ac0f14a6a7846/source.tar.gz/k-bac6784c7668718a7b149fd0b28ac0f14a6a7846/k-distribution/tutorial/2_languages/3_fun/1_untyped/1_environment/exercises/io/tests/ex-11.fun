print read + 7
