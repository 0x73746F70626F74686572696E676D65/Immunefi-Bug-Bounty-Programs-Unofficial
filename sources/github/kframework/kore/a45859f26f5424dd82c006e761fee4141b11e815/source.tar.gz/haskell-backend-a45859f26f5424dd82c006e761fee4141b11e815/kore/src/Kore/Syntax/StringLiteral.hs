{-|
Copyright   : (c) Runtime Verification, 2019
License     : NCSA

-}

module Kore.Syntax.StringLiteral
    ( StringLiteral (..)
    ) where

import Prelude.Kore

import Control.DeepSeq
    ( NFData (..)
    )
import Data.Functor.Const
import Data.Text
    ( Text
    )
import qualified Generics.SOP as SOP
import qualified GHC.Generics as GHC

import Kore.Attribute.Pattern.FreeVariables
    ( FreeVariables
    , emptyFreeVariables
    )
import Kore.Attribute.Synthetic
import Kore.Debug
import Kore.Sort
import Kore.Unparser
import qualified Pretty

{-|'StringLiteral' corresponds to the @string@ literal from the Semantics of K,
Section 9.1.1 (Lexicon).
-}
newtype StringLiteral = StringLiteral { getStringLiteral :: Text }
    deriving (Eq, GHC.Generic, Ord, Show)

instance Hashable StringLiteral

instance NFData StringLiteral

instance SOP.Generic StringLiteral

instance SOP.HasDatatypeInfo StringLiteral

instance Debug StringLiteral

instance Diff StringLiteral

instance Unparse StringLiteral where
    unparse = Pretty.dquotes . Pretty.pretty . escapeStringT . getStringLiteral
    unparse2 = unparse

instance Synthetic (FreeVariables variable) (Const StringLiteral) where
    synthetic = const emptyFreeVariables
    {-# INLINE synthetic #-}

instance Synthetic Sort (Const StringLiteral) where
    synthetic = const stringMetaSort
    {-# INLINE synthetic #-}
