{-|
Description : Rule index attribute
Copyright   : (c) Runtime Verification, 2018
License     : NCSA

-}
module Kore.Attribute.RuleIndex
    ( RuleIndex (..)
    , RuleIndexCase (..)
    ) where

import Prelude.Kore

import Control.DeepSeq
    ( NFData
    )
import Data.Default
import qualified Generics.SOP as SOP
import qualified GHC.Generics as GHC

import Kore.Debug

data RuleIndexCase
    = AxiomIndex !Int
    | ClaimIndex !Int
    deriving (Eq, GHC.Generic, Ord, Show)

instance SOP.Generic RuleIndexCase

instance SOP.HasDatatypeInfo RuleIndexCase

instance Debug RuleIndexCase

instance Diff RuleIndexCase

instance NFData RuleIndexCase

{- | This attribute is used in the REPL for tagging
    and uniquely identifiying axioms and claims.
 -}
newtype RuleIndex = RuleIndex { getRuleIndex :: Maybe RuleIndexCase }
    deriving (Eq, GHC.Generic, Ord, Show)

instance SOP.Generic RuleIndex

instance SOP.HasDatatypeInfo RuleIndex

instance Debug RuleIndex

instance Diff RuleIndex

instance NFData RuleIndex

instance Default RuleIndex where
    def = RuleIndex Nothing
