// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.28;

import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {IStrataCDO} from "../interfaces/IStrataCDO.sol";
import {IIsolatedStrategy} from "../interfaces/IIsolatedStrategy.sol";
import {IStrategy} from "../interfaces/IStrategy.sol";
import {IRebalanceable} from "../interfaces/IRebalancer.sol";
import {MultiStrategy} from "./base/MultiStrategy.sol";
import {Strategy} from "../Strategy.sol";
import {IndexPackerLib} from "../utils/IndexPackerLib.sol";

contract IsolatedStrategy is MultiStrategy, IIsolatedStrategy {

    uint256 constant private JRT_IDX = 0;
    uint256 constant private SRT_IDX = 1;

    /// @dev Packed withdrawal order for JRT: [senior(1), junior(0)]
    uint256 private immutable _jrtWithdrawOrderPacked;
    /// @dev Packed withdrawal order for SRT: [junior(0), senior(1)]
    uint256 private immutable _srtWithdrawOrderPacked;

    /// @dev Packed common deposit order, JRT first: [junior(0), senior(1)]
    uint256 private immutable _jrtDepositOrderPacked;
    /// @dev Packed common deposit order, SRT first: [senior(1), junior(0)]
    uint256 private immutable _srtDepositOrderPacked;

    IStrategy public juniorStrat;
    IStrategy public seniorStrat;

    event StratsSet(address indexed juniorStrat, address indexed seniorStrat);
    event LiquidAllocationFloorSet(uint256 floor);

    constructor() Strategy(address(0), address(0)) {
        _jrtWithdrawOrderPacked = IndexPackerLib.pack2(SRT_IDX, JRT_IDX);
        _srtWithdrawOrderPacked = IndexPackerLib.pack2(JRT_IDX, SRT_IDX);

        _jrtDepositOrderPacked = IndexPackerLib.pack2(JRT_IDX, SRT_IDX);
        _srtDepositOrderPacked = IndexPackerLib.pack2(SRT_IDX, JRT_IDX);
    }

    function configureStrategies(
        IStrategy juniorStrat_,
        IStrategy seniorStrat_
    ) external onlyOwner {
        require(address(juniorStrat) == address(0), "SubStrategiesConfigured");
        require(juniorStrat_.getCDOAddress() == address(this), "InvalidStrategyCDO");
        require(seniorStrat_.getCDOAddress() == address(this), "InvalidStrategyCDO");

        juniorStrat = juniorStrat_;
        seniorStrat = seniorStrat_;
        IStrategy[] memory strats_ = new IStrategy[](2);
        strats_[JRT_IDX] = juniorStrat_;
        strats_[SRT_IDX] = seniorStrat_;
        _setStrats(strats_);
        emit StratsSet(address(juniorStrat_), address(seniorStrat_));
    }

    function setLiquidAllocationFloor(uint256 floor_) external onlyOwner {
        require(floor_ <= 1e18, "InvalidLiquidAllocationFloor");
        liquidAllocationFloor = floor_;
        emit LiquidAllocationFloorSet(floor_);
    }

    function _depositStratIndexes(address tranche, address /*token*/, uint256 baseAssets) internal view override returns (uint256) {
        (
            uint256 deficitStratIdx,
            uint256 deficitAmount,
            uint256 surplusStratIdx,
            uint256 surplusAmount
        ) = imbalances();

        if (deficitStratIdx == JRT_IDX &&
            baseAssets <= deficitAmount &&
            surplusStratIdx == SRT_IDX &&
            surplusAmount > 0) {

            // Junior has deficit AND Senior has surplus
            return _jrtDepositOrderPacked;
        }

        if (
            deficitStratIdx == SRT_IDX &&
            baseAssets <= deficitAmount &&
            surplusStratIdx == JRT_IDX &&
            surplusAmount > 0) {

            // Senior has deficit AND Junior has surplus
            return _srtDepositOrderPacked;
        }

        // Otherwise deposit to the tranche's default strategy
        return cdo.isJrt(tranche) ? _jrtDepositOrderPacked : _srtDepositOrderPacked;
    }

    // JRT redemptions from senior strategy first (index 1); SRT redeems from junior first (index 0).
    function _withdrawStratIndexes (address tranche) internal view override returns (uint256) {
        return cdo.isJrt(tranche)
            ? _jrtWithdrawOrderPacked
            : _srtWithdrawOrderPacked;
    }

    function totalAssetsByTranche() public view returns (uint256 jrtAssets, uint256 srtAssets) {
        return (juniorStrat.totalAssets(), seniorStrat.totalAssets());
    }

    /// @notice Returns the strategy with the largest deficit and the strategy with the largest surplus.
    /// @dev Returns the index of the strategy that needs assets most (has largest deficit relative to target),
    ///      the deficit amount, the index of the strategy with the most excess assets (largest surplus),
    ///      and the surplus amount. If no deficit/surplus exists, returns (0, 0, 0, 0).
    /// @return deficitStratIdx Index of the strategy with the largest deficit (0=junior, 1=senior)
    /// @return deficitAmount Amount of assets the deficit strategy needs
    /// @return surplusStratIdx Index of the strategy with the largest surplus (0=junior, 1=senior)
    /// @return surplusAmount Amount of excess assets the surplus strategy holds
    function imbalances() public view returns (
        uint256 deficitStratIdx,
        uint256 deficitAmount,
        uint256 surplusStratIdx,
        uint256 surplusAmount
    ) {
        require(address(accounting) != address(0), "Accounting not set");
        (uint256 jrtNavT0, uint256 srtNavT0,) = accounting.totalAssetsT0();

        uint256 navTotal = jrtNavT0 + srtNavT0;
        if (navTotal == 0) return (0, 0, 0, 0);

        uint256 jrtAssets = juniorStrat.totalAssets();
        uint256 srtAssets = seniorStrat.totalAssets();

        if (address(rebalancer) != address(0)) {
            (uint256 pendingToJunior, uint256 pendingToSenior) = rebalancer.pendingToStrats();
            jrtAssets += pendingToJunior;
            srtAssets += pendingToSenior;
        }

        if (liquidAllocationFloor > 0) {
            uint256 target = Math.mulDiv(jrtNavT0 + srtNavT0, liquidAllocationFloor, 1e18);
            if (jrtNavT0 < target) {
                // Raise Junior's target to the liquid allocation floor without reducing its entitlement.
                srtNavT0 = jrtNavT0 + srtNavT0 - target;
                jrtNavT0 = target;
            }
        }

        // Calculate deficits/surpluses for each strategy
        uint256 jrtDeficit = jrtNavT0 > jrtAssets ? jrtNavT0 - jrtAssets : 0;
        uint256 jrtSurplus = jrtAssets > jrtNavT0 ? jrtAssets - jrtNavT0 : 0;
        uint256 srtDeficit = srtNavT0 > srtAssets ? srtNavT0 - srtAssets : 0;
        uint256 srtSurplus = srtAssets > srtNavT0 ? srtAssets - srtNavT0 : 0;

        // Determine which strategy has the largest deficit
        if (jrtDeficit >= srtDeficit) {
            deficitStratIdx = JRT_IDX;
            deficitAmount = jrtDeficit;
        } else {
            deficitStratIdx = SRT_IDX;
            deficitAmount = srtDeficit;
        }

        // Determine which strategy has the largest surplus
        if (jrtSurplus >= srtSurplus) {
            surplusStratIdx = JRT_IDX;
            surplusAmount = jrtSurplus;
        } else {
            surplusStratIdx = SRT_IDX;
            surplusAmount = srtSurplus;
        }
    }

    function shareToken() public pure override(IStrategy, Strategy) returns (address) {
        revert("NotSupported");
    }

    function getRate() external view override(IStrategy, Strategy) returns (uint256) {
        return seniorStrat.getRate();
    }
}
