// SPDX-License-Identifier: MIT
pragma solidity 0.8.27;

contract Constants {

    struct Transaction {
        uint256 chainId;
        bytes data;
        address from;
        uint256 gas;
        uint256 gasPrice;
        uint256 nonce;
        address to;
        uint256 value;
    }

    /// @custom:forks
    string constant BASE_RPC_REF = "BASE_RPC";
    string constant BASE_SEPOLIA_RPC_REF = "BASE_SEPOLIA_RPC";

    uint256 constant BASE_FORK_BLOCK = 26_606_911;
    // uint256 constant BASE_SEPOLIA_FORK_BLOCK = 0;

    uint256 constant BASE_CHAIN_ID = 8453;

    /// @custom:values
    address constant ACTOR = 0x7777777777777777777777777777777777777777;
    uint256 constant DEFAULT_MIN_AMOUNT_OUT = 0;

    /// @custom:tokens
    address constant BASE_SEPOLIA_WETH = address(0);
    address constant BASE_WETH = 0x4200000000000000000000000000000000000006;
    address constant BASE_TBTC = 0x236aa50979D5f3De3Bd1Eeb40E81137F22ab794b;

    uint24 constant FEE_1 = 100;
    uint24 constant FEE_5 = 500;
    uint24 constant FEE_30 = 3000;
    uint24 constant FEE_100 = 10_000;

    uint256 DEFAULT_AMOUNT = 1e18;
    uint256 DEFAULT_PROPORTION = 1;
    uint256 DEFAULT_SLIPPAGE = 1;

    /// @custom:synthetix
    bytes32 constant _ADMIN_PERMISSION = "ADMIN";
    bytes32 constant _WITHDRAW_PERMISSION = "WITHDRAW";
    bytes32 constant _DELEGATE_PERMISSION = "DELEGATE";
    bytes32 constant _MINT_PERMISSION = "MINT";
    bytes32 constant _REWARDS_PERMISSION = "REWARDS";
    bytes32 constant _PERPS_MODIFY_COLLATERAL_PERMISSION =
        "PERPS_MODIFY_COLLATERAL";
    bytes32 constant _PERPS_COMMIT_ASYNC_ORDER_PERMISSION =
        "PERPS_COMMIT_ASYNC_ORDER";
    bytes32 constant _BURN_PERMISSION = "BURN";
    bytes32 constant _BFP_PERPS_PAY_DEBT_PERMISSION = "BFP_PERPS_PAY_DEBT";
    bytes32 constant _BFP_PERPS_SPLIT_ACCOUNT_PERMISSION =
        "BFP_PERPS_SPLIT_ACCOUNT";

    string constant ODOS_ASSEMBLE_URL = "https://api.odos.xyz/sor/assemble";
    string constant ODOS_QUOTE_URL = "https://api.odos.xyz/sor/quote/v2";

}
