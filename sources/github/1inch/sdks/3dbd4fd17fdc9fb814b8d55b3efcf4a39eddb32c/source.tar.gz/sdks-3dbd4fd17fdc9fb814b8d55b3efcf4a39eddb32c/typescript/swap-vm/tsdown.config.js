import { defineConfig } from 'tsdown'

export default defineConfig({
  entry: ['src/index.ts'],
  platform: 'neutral',
  exports: {
    customExports(pkg, _) {
      for (const [exp, map] of Object.entries(pkg.exports)) {
        if (map instanceof Object) {
          const types = map.require.replace(/\.js$/, '.d.ts')
          pkg.exports[exp] = { types, ...map }
        }
      }

      return pkg
    },
  },
  unbundle: true,
  dts: {
    build: true,
    ignoreErrors: true,
    transformOptions: {
      compilerOptions: {
        isolatedDeclarations: false,
      },
    },
  },
  outDir: './dist',
  format: ['cjs', 'esm'],
})
