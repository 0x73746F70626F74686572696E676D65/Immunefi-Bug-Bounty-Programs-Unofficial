// SPDX-License-Identifier: LicenseRef-Degensoft-SwapVM-1.1

import { BytesBuilder, BytesIter, add0x } from '@1inch/byte-utils'
import { Address, HexString } from '@1inch/sdk-core'
import { OnlyTxOriginTokenBalanceNonZeroArgs } from './only-tx-origin-token-balance-non-zero-args'
import type { IArgsCoder } from '../types'

export class OnlyTxOriginTokenBalanceNonZeroArgsCoder implements IArgsCoder<OnlyTxOriginTokenBalanceNonZeroArgs> {
  encode(args: OnlyTxOriginTokenBalanceNonZeroArgs): HexString {
    const builder = new BytesBuilder()
    builder.addAddress(args.token.toString())

    return new HexString(add0x(builder.asHex()))
  }

  decode(data: HexString): OnlyTxOriginTokenBalanceNonZeroArgs {
    const iter = BytesIter.HexString(data.toString())
    const token = new Address(iter.nextUint160())

    return new OnlyTxOriginTokenBalanceNonZeroArgs(token)
  }
}
