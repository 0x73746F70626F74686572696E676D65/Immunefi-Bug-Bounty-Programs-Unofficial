final class PasteUriInteractor {

}
