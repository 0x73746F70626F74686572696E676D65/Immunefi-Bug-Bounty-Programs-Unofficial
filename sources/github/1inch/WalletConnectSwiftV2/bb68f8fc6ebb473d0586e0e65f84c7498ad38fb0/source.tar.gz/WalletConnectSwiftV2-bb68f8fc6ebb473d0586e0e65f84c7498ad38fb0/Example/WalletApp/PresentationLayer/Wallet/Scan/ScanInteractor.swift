final class ScanInteractor {

}
