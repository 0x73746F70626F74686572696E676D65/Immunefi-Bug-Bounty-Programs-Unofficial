final class SettingsInteractor {

}
