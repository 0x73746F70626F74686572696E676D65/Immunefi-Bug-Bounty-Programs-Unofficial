import { configVariable, defineConfig, task } from 'hardhat/config';
import type { HardhatPlugin } from 'hardhat/types/plugins';
import hardhatEthers from '@nomicfoundation/hardhat-ethers';
import hardhatToolboxMochaEthers from '@nomicfoundation/hardhat-toolbox-mocha-ethers';
import hardhatEthersChaiMatchers from '@nomicfoundation/hardhat-ethers-chai-matchers';
import hardhatNetworkHelpers from '@nomicfoundation/hardhat-network-helpers';
import hardhatIgnition from '@nomicfoundation/hardhat-ignition';
import hardhatVerify from '@nomicfoundation/hardhat-verify';
import { ArgumentType } from 'hardhat/types/arguments';
import { configDotenv } from 'dotenv';

// configVariable() resolves from process.env, so .env must be loaded before the config is built.
configDotenv();

/**
 * Merkle Drop Create and Deploy
 *
 * Description:
 *   Performs a complete merkle drop deployment workflow:
 *   1. Generates claim links with specified amounts
 *   2. Creates merkle tree from the generated data
 *   3. Deploys the merkle drop contract (unless in debug mode)
 *   4. Verifies all generated links against the deployed contract
 *
 * Parameters:
 *   --ver        : (Optional) Deployment version number (defaults to .latest + 1)
 *   -a/--amounts : Comma-separated list of token amounts for each tier
 *   -n/--numbers : Comma-separated list of how many codes to generate per tier
 *   --debug      : (Optional) Debug mode - generates links without deploying
 *
 * Usage:
 *   yarn hardhat drop --network <network> [--ver <version>] -a <amounts> -n <counts> [--debug]
 *
 * Examples:
 *   # Deploy on base with auto-incremented version (reads from .latest file)
 *   yarn hardhat drop --network base -a 5,10,20,30,40,50 -n 10,15,20,25,20,10
 *
 *   # Deploy on base with specific version
 *   yarn hardhat drop --network base --ver 53 -a 5,10,20,30,40,50 -n 10,15,20,25,20,10
 *
 *   # Test generation without deployment (debug mode)
 *   yarn hardhat drop --network hardhat --ver 55 -a 10,20 -n 5,5 --debug
 */
const drop = task('drop', 'Generate merkle drop links, deploy contract, and verify all generated claim links')
    .addOption({
        name: 'ver',
        description: 'Deployment version (defaults to .latest + 1)',
        defaultValue: 0,
        type: ArgumentType.INT,
    })
    .addOption({
        name: 'amounts',
        shortName: 'a',
        description: 'Amounts for drop to generate',
        defaultValue: 'not set',
        type: ArgumentType.STRING,
    })
    .addOption({
        name: 'numbers',
        shortName: 'n',
        description: 'Number of codes to generate',
        defaultValue: 'not set',
        type: ArgumentType.STRING,
    })
    .addFlag({
        name: 'debug',
        description: 'Debug mode',
    })
    .setAction(() => import('./src/tasks/drop.js'))
    .build();

/**
 * Verify Links for Deployed Contract
 *
 * Description:
 *   Verifies all generated links against a previously deployed merkle drop contract.
 *   Reads the links from the generated JSON files and verifies each one against
 *   the deployed contract to ensure they are valid.
 *
 * Parameters:
 *   --ver : Deployment version number (must match the deployed contract)
 *
 * Usage:
 *   yarn hardhat verify-links --network <network> --ver <version>
 *
 * Examples:
 *   # Verify links for version 61 on base network
 *   yarn hardhat verify-links --network base --ver 61
 *
 *   # Verify links for version 42 on mainnet
 *   yarn hardhat verify-links --network mainnet --ver 42
 *
 * Note:
 *   - Requires deployment artifacts to exist in deployments/<network>/MerkleDrop128-<version>.json
 *   - Requires link files to exist in generated-data/<version>-qr-links.json
 *   - Will also check generated-data/<version>-qr-links-test.json if it exists
 */
const verifyLinks = task('verify-links', 'Verify all generated links against a deployed merkle drop contract')
    .addOption({
        name: 'ver',
        description: 'Deployment version',
        defaultValue: 0,
        type: ArgumentType.INT,
    })
    .setAction(() => import('./src/tasks/verify-links.js'))
    .build();

/**
 * Verify Contract on Etherscan
 *
 * Description:
 *   Verifies a previously deployed merkle drop contract on Etherscan
 *   or the appropriate block explorer for the network. Uses saved
 *   deployment artifacts to provide constructor arguments.
 *
 * Parameters:
 *   --ver : Deployment version number (must match the deployed contract)
 *
 * Usage:
 *   yarn hardhat verify-deployment --network <network> --ver <version>
 *
 * Examples:
 *   # Verify version 53 on base network
 *   yarn hardhat verify-deployment --network base --ver 53
 *
 *   # Verify version 42 on mainnet
 *   yarn hardhat verify-deployment --network mainnet --ver 42
 *
 * Note:
 *   Requires deployment artifacts to exist
 */
const verifyDeployment = task('verify-deployment', 'Verify a deployed merkle drop contract on Etherscan using deployment artifacts')
    .addOption({
        name: 'ver',
        description: 'Deployment version',
        defaultValue: 0,
        type: ArgumentType.INT,
    })
    .setAction(() => import('./src/tasks/verify-deployment.js'))
    .build();

/**
 * Collect On-Chain Statistics for Deployed Drops
 *
 * Description:
 *   Collects and displays on-chain statistics for a deployed merkle drop contract.
 *   Queries Transfer events from the token contract to track all claims made
 *   through the drop contract.
 *
 * Parameters:
 *   <versions list> : One or more deployment version numbers (must match the deployed contracts)
 *
 * Usage:
 *   yarn stat <network> <versions list>
 *
 * Examples:
 *   # Get statistics for version 61 on base network
 *   yarn stat base 61
 *
 *   # Get statistics for version 41 on mainnet
 *   yarn stat mainnet 41
 *
 *   # Get statistics for versions 3 and 4 on mainnet
 *   yarn stat mainnet 3 4
 *
 * Statistics Displayed:
 *   - Total number of claims
 *   - Total amount claimed
 *   - Average claim amount
 *   - First and last claim timestamps
 *
 * Note:
 *   Requires deployment artifacts to exist in deployments/<network>/MerkleDrop128-<version>.json
 */
const stats = task('stats', 'Collect on-chain statistics for deployed drops')
    .addVariadicArgument({
        name: 'versions',
        description: 'Deployment version',
        type: ArgumentType.INT,
    })
    .setAction(() => import('./src/tasks/collect-stats.js'))
    .build();

/**
 * Rescue Tokens from Drop Contract
 *
 * Description:
 *   Rescues any remaining reward tokens from a deployed merkle drop contract.
 *   Only the contract owner can execute this function. The rescued tokens
 *   will be transferred to the owner's address.
 *
 * Parameters:
 *   --ver : Deployment version number (must match the deployed contract)
 *
 * Usage:
 *   yarn rescue <network> --ver <version>
 *
 * Examples:
 *   # Rescue tokens from version 61 on base network
 *   yarn rescue base --ver 61
 *
 *   # Rescue tokens from version 41 on mainnet
 *   yarn rescue mainnet --ver 41
 *
 *   # Rescue tokens from version 3 on BSC
 *   yarn rescue bsc --ver 3
 *
 * Information Displayed:
 *   - Current token balance on the contract
 *   - Success or failure status
 *   - Amount of tokens retrieved
 *   - Recipient address (owner)
 *   - Transaction details
 *
 * Note:
 *   - Requires deployment artifacts to exist in deployments/<network>/MerkleDrop128-<version>.json
 *   - Only the contract owner can execute this function
 *   - Will check the balance before attempting rescue
 */
const rescue = task('rescue', 'Rescue remaining tokens from a deployed merkle drop contract')
    .addOption({
        name: 'ver',
        description: 'Deployment version',
        defaultValue: 0,
        type: ArgumentType.INT,
    })
    .setAction(() => import('./src/tasks/rescue.js'))
    .build();

// Ensure TypeScript recognizes these as valid plugins
const plugins: HardhatPlugin[] = [
    hardhatNetworkHelpers,
    hardhatEthers,
    hardhatToolboxMochaEthers,
    hardhatEthersChaiMatchers,
    hardhatIgnition,
    hardhatVerify,
];

export default defineConfig({
    plugins,
    paths: {
        sources: './contracts',
        tests: { mocha: './test' },
        cache: './cache',
        artifacts: './artifacts',
    },
    solidity: {
        profiles: {
            default: {
                version: '0.8.23',
                settings: {
                    optimizer: {
                        enabled: true,
                        runs: 1000000,
                    },
                    evmVersion: 'shanghai',
                },
            },
            production: {
                version: '0.8.23',
                settings: {
                    optimizer: {
                        enabled: true,
                        runs: 1000000,
                    },
                    evmVersion: 'shanghai',
                },
            },
        },
        npmFilesToBuild: ['@1inch/solidity-utils/contracts/mocks/TokenMock.sol'],
    },
    networks: {
        hardhat: {
            type: 'edr-simulated',
            chainId: 31337,
        },
        localhost: {
            type: 'http',
            url: 'http://localhost:8545',
            chainId: 31337,
        },
        base: {
            type: 'http',
            url: configVariable('BASE_RPC_URL', { default: 'https://base.drpc.org' }),
            chainId: 8453,
            accounts: [configVariable('BASE_PRIVATE_KEY')],
        },
        sepolia: {
            type: 'http',
            url: configVariable('SEPOLIA_RPC_URL'),
            chainId: 11155111,
            accounts: [configVariable('SEPOLIA_PRIVATE_KEY')],
        },
    },
    verify: {
        etherscan: {
            apiKey: configVariable('ETHERSCAN_API_KEY'),
        },
        blockscout: {
            enabled: false,
        },
        sourcify: {
            enabled: false,
        },
    },
    tasks: [drop, verifyLinks, verifyDeployment, stats, rescue],
});
