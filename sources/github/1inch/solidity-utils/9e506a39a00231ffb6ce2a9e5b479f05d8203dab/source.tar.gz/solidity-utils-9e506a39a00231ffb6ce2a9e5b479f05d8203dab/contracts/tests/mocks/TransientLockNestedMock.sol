// SPDX-License-Identifier: MIT

pragma solidity ^0.8.27;

import { TransientLock, TransientLockLib } from "../../libraries/TransientLock.sol";
import { ResultMulticallMock } from "./ResultMulticallMock.sol";

contract TransientLockNestedMock is ResultMulticallMock {
    using TransientLockLib for TransientLock;

    mapping(address maker => mapping(bytes32 strategyHash => TransientLock)) internal _reentrancyLocks;

    function lock(address maker, bytes32 strategyHash) external {
        _reentrancyLocks[maker][strategyHash].lock();
    }

    function unlock(address maker, bytes32 strategyHash) external {
        _reentrancyLocks[maker][strategyHash].unlock();
    }

    function isLocked(address maker, bytes32 strategyHash) external view returns (bool) {
        return _reentrancyLocks[maker][strategyHash].isLocked();
    }
}
