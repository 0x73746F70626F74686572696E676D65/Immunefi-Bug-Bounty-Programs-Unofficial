require('@matterlabs/hardhat-zksync-deploy');
require('@matterlabs/hardhat-zksync-solc');
require('@nomicfoundation/hardhat-ethers');
require('dotenv').config();
require('hardhat-dependency-compiler');
require('hardhat-deploy');
require('hardhat-gas-reporter');
require('solidity-coverage');
require('hardhat-tracer');
const { Networks, getNetwork } = require('@1inch/solidity-utils/hardhat-setup');

if (getNetwork().indexOf('zksync') !== -1) {
    require('@matterlabs/hardhat-zksync-verify');
} else {
    require('@nomicfoundation/hardhat-verify');
}

// const { networks, etherscan } = (new Networks(true, 'mainnet', true)).registerAll();
// etherscan.apiKey.zksyncmainnet = process.env.ZKSYNC_ETHERSCAN_KEY;

const n = new Networks(true, 'mainnet', true);
const { networks } = n.registerAll();
const etherscan = n.getEtherscanConfig(getNetwork());

networks.hardhat.mining = { auto: true, interval: 0 };

module.exports = {
    etherscan,
    solidity: {
        settings: {
            optimizer: {
                enabled: true,
                runs: 1000000,
            },
            evmVersion: networks[getNetwork()]?.hardfork || 'shanghai',
            viaIR: true,
        },
        version: '0.8.23',
    },
    namedAccounts: {
        deployer: {
            default: 0,
        },
    },
    networks,
    dependencyCompiler: {
        paths: [
            '@openzeppelin/contracts/proxy/transparent/ProxyAdmin.sol',
        ],
    },
    zksolc: {
        version: '1.4.1',
        compilerSource: 'binary',
        settings: {},
    },
    deployOpts: {
        contractHelperConfigs: process.env.OPS_EVM_HELPER_CONFIGS ? JSON.parse(process.env.OPS_EVM_HELPER_CONFIGS) : [],
        feeCollectorOperatorName: process.env.OPS_FEE_COLLECTOR_OPERATOR_NAME || '',
        feeCollectorOperator: process.env.OPS_FEE_COLLECTOR_OPERATOR || '',
        feeCollectorOperatorNames: process.env.OPS_FEE_COLLECTOR_OPERATOR_NAMES ? JSON.parse(process.env.OPS_FEE_COLLECTOR_OPERATOR_NAMES) : [],
        deploymentMethod: process.env.OPS_DEPLOYMENT_METHOD,
    },
};
