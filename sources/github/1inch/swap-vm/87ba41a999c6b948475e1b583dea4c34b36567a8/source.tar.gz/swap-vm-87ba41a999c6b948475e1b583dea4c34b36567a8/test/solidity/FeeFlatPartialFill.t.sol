// SPDX-License-Identifier: LicenseRef-Degensoft-SwapVM-1.1
pragma solidity ^0.8.27;

/// @custom:license-url https://github.com/1inch/swap-vm/blob/main/LICENSES/SwapVM-1.1.txt
/// @custom:copyright © 2026 Degensoft Ltd

import { Test } from "forge-std/Test.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";
import { TokenMock } from "@1inch/solidity-utils/contracts/mocks/TokenMock.sol";

import { ISwapVM } from "../../contracts/interfaces/ISwapVM.sol";
import { SwapVMRouterDebug, DeployCode, TraitsHelper } from "./helpers/SwapVMTestSetup.sol";
import { SwapRegisters } from "../../contracts/libs/VM.sol";
import { TakerTraitsLib } from "../../contracts/libs/TakerTraits.sol";
import { PatchSwapRegisters } from "../../contracts/instructions/Debug.sol";
import { FeeFlatIn, FeeFlatOut } from "../../contracts/instructions/FeeFlat.sol";

contract FeeFlatPartialFillTest is Test {
    using Math for uint256;

    SwapVMRouterDebug public swapVM;

    TraitsHelper internal orders;
    address public tokenA;
    address public tokenB;

    address public maker;
    uint256 public makerPrivateKey = 0x1234;

    function setUp() public {
        maker = vm.addr(makerPrivateKey);
        orders = DeployCode.TraitsHelper();
        swapVM = DeployCode.SwapVMRouterDebug(address(0), address(0), address(this), "SwapVM", "1.0.0");

        tokenA = address(new TokenMock("Token I", "TKI"));
        tokenB = address(new TokenMock("Token J", "TKJ"));
        if (tokenA > tokenB) (tokenA, tokenB) = (tokenB, tokenA);
    }

    function testFuzz_FeeFlatIn_ExactIn_PartialFill(uint256 amount, uint256 amountPartial, uint24 feeBps) public view {
        amount = bound(amount, 0, 1e36);
        feeBps = uint24(bound(feeBps, 0, FeeFlatIn.BPS - 1));

        uint256 fee = (amount * feeBps).ceilDiv(FeeFlatIn.BPS);
        amountPartial = bound(amountPartial, 0, amount - fee);
        bool isPartialFill = amountPartial != amount - fee;

        bytes memory program = bytes.concat(
            FeeFlatIn.build(feeBps),
            // Simulates runLoop drifting amountIn down to a partial fill
            PatchSwapRegisters.build(SwapRegisters({
                balanceIn: 0,
                balanceOut: 0,
                amountIn: amountPartial,
                amountOut: 1e18,
                surcharge: 0
            }))
        );

        uint256 realAmount;
        try swapVM.asView().quote(_createOrder(program), amount, _makeTakerData(true))returns (uint256 amountIn, uint256, bytes32) { realAmount = amountIn; }
        catch (bytes memory reason) { require(bytes4(reason) == TakerTraitsLib.TakerTraitsAmountOutMustBeGreaterThanZero.selector); }

        uint256 realFee = realAmount - amountPartial;

        uint256 feeDesired = (realAmount * feeBps).ceilDiv(FeeFlatIn.BPS);
        assertEq(realFee, feeDesired);

        // No partial fill -> no drift
        if (!isPartialFill) {
            assertEq(fee, realFee);
            assertEq(amount, realAmount);
        }
        // Partial fill to zero -> no fee
        if (isPartialFill && amountPartial == 0) assertEq(realFee, 0);

        // Drifts only down
        assertLe(realFee, fee);
        assertLe(realAmount, amount);

        // realFee / realAmount >= feeBps
        assertGe(realFee * FeeFlatIn.BPS, feeBps * realAmount, "Effective fee should favor maker");

        // Imagine realFee is 1 wei less -> realAmount is 1 wei less as well -> feeBps breaks
        if (realFee != 0 && isPartialFill) assertLt((realFee - 1) * FeeFlatIn.BPS, feeBps * (realAmount - 1), "One wei less realFee would favor taker");
    }

    function testFuzz_FeeFlatIn_ExactOut_PartialFill(uint256 amount, uint256 amountPartial, uint256 amountIn, uint24 feeBps) public view {
        amount = bound(amount, 1, 1e36);
        feeBps = uint24(bound(feeBps, 0, FeeFlatIn.BPS - 1));

        amountPartial = bound(amountPartial, 1, amount);
        bool isPartialFill = amountPartial != amount;
        amountIn = bound(amountIn, 0, 1e36);

        bytes memory program = bytes.concat(
            FeeFlatIn.build(feeBps),
            // Simulates runLoop drifting amountOut down to a partial fill
            PatchSwapRegisters.build(SwapRegisters({
                balanceIn: 0,
                balanceOut: 0,
                amountIn: amountIn,
                amountOut: amountPartial,
                surcharge: 0
            }))
        );

        (uint256 realIn, uint256 realOut,) = swapVM.asView().quote(_createOrder(program), amount, _makeTakerData(false));

        uint256 realFee = realIn - amountIn;

        uint256 feeDesired = (amountIn * feeBps).ceilDiv(FeeFlatIn.BPS - feeBps);
        assertEq(realFee, feeDesired);

        // No partial fill -> no drift
        if (!isPartialFill) assertEq(realOut, amount);

        // realFee / realIn >= feeBps
        assertGe(realFee * FeeFlatIn.BPS, feeBps * realIn, "Effective fee should favor maker");

        // Imagine realFee is 1 wei less -> realIn is 1 wei less as well -> feeBps breaks
        if (realFee != 0) assertLt((realFee - 1) * FeeFlatIn.BPS, feeBps * (realIn - 1), "One wei less realFee would favor taker");
    }

    function testFuzz_FeeFlatOut_ExactIn_PartialFill(uint256 amount, uint256 amountPartial, uint256 amountOut, uint24 feeBps) public view {
        amount = bound(amount, 0, 1e36);
        feeBps = uint24(bound(feeBps, 0, FeeFlatOut.BPS - 1));

        amountPartial = bound(amountPartial, 0, amount);
        bool isPartialFill = amountPartial != amount;
        amountOut = bound(amountOut, 1, 1e36);

        bytes memory program = bytes.concat(
            FeeFlatOut.build(feeBps),
            // Simulates runLoop drifting amountIn down to a partial fill
            PatchSwapRegisters.build(SwapRegisters({
                balanceIn: 0,
                balanceOut: 0,
                amountIn: amountPartial,
                amountOut: amountOut,
                surcharge: 0
            }))
        );

        uint256 realIn;
        uint256 realOut;
        try swapVM.asView().quote(_createOrder(program), amount, _makeTakerData(true)) returns (uint256 quotedIn, uint256 quotedOut, bytes32) { (realIn, realOut) = (quotedIn, quotedOut); }
        catch (bytes memory reason) {
            require(bytes4(reason) == TakerTraitsLib.TakerTraitsAmountOutMustBeGreaterThanZero.selector);
            assertEq(amountOut, (amountOut * feeBps).ceilDiv(FeeFlatOut.BPS));
            return;
        }

        uint256 realFee = amountOut - realOut;

        uint256 feeDesired = (amountOut * feeBps).ceilDiv(FeeFlatOut.BPS);
        assertEq(realFee, feeDesired);

        // No partial fill -> no drift
        if (!isPartialFill) assertEq(realIn, amount);

        // realFee / amountOut >= feeBps
        assertGe(realFee * FeeFlatOut.BPS, feeBps * amountOut, "Effective fee should favor maker");

        // Imagine realFee is 1 wei less -> feeBps breaks
        if (realFee != 0) assertLt((realFee - 1) * FeeFlatOut.BPS, feeBps * amountOut, "One wei less realFee would favor taker");
    }

    function testFuzz_FeeFlatOut_ExactOut_PartialFill(uint256 amount, uint256 amountPartial, uint24 feeBps) public view {
        amount = bound(amount, 0, 1e36);
        feeBps = uint24(bound(feeBps, 0, FeeFlatOut.BPS - 1));

        uint256 fee = (amount * feeBps).ceilDiv(FeeFlatOut.BPS - feeBps);
        amountPartial = bound(amountPartial, 0, amount + fee);
        bool isPartialFill = amountPartial != amount + fee;

        bytes memory program = bytes.concat(
            FeeFlatOut.build(feeBps),
            // Simulates runLoop drifting amountOut down to a partial fill
            PatchSwapRegisters.build(SwapRegisters({
                balanceIn: 0,
                balanceOut: 0,
                amountIn: 1e18,
                amountOut: amountPartial,
                surcharge: 0
            }))
        );

        uint256 realAmount;
        try swapVM.asView().quote(_createOrder(program), amount, _makeTakerData(false))returns (uint256, uint256 amountOut, bytes32) { realAmount = amountOut; }
        catch (bytes memory reason) { require(bytes4(reason) == TakerTraitsLib.TakerTraitsAmountOutMustBeGreaterThanZero.selector); }

        uint256 realFee = amountPartial - realAmount;

        uint256 feeDesired = (amountPartial * feeBps).ceilDiv(FeeFlatOut.BPS);
        assertEq(realFee, feeDesired);

        // No partial fill -> no drift
        if (!isPartialFill) {
            assertEq(fee, realFee);
            assertEq(amount, realAmount);
        }
        // No fill -> no fee
        if (amountPartial == 0) assertEq(0, realFee);

        // Drifts only down
        assertLe(realFee, fee);
        assertLe(realAmount, amount);

        // realFee / amountPartial >= feeBps
        assertGe(realFee * FeeFlatOut.BPS, feeBps * amountPartial, "Effective fee should favor maker");

        // Imagine realFee is 1 wei less -> feeBps breaks
        if (realFee != 0) assertLt((realFee - 1) * FeeFlatOut.BPS, feeBps * amountPartial, "One wei less realFee would favor taker");
    }

    function decodeMismatch(bytes calldata reason) external pure returns (uint256 takerAmount, uint256 computedAmount) {
        return abi.decode(reason[4:], (uint256, uint256));
    }

    function _createOrder(bytes memory program) internal view returns (ISwapVM.Order memory) {
        return orders.MakerTraitsLibBuild(TraitsHelper.MakerTraitsLibArgs({
            maker: maker,
            tokenA: tokenA,
            tokenB: tokenB,
            shouldUnwrapWeth: false,
            useAquaInsteadOfSignature: false,
            usePermit2: false,
            allowZeroAmountIn: true,
            receiver: address(0),
            program: program
        }));
    }

    function _makeTakerData(bool isExactIn) internal view returns (bytes memory) {
        return orders.TakerTraitsLibBuild(TraitsHelper.TakerTraitsLibArgs({
            taker: address(this),
            isExactIn: isExactIn,
            shouldUnwrapWeth: false,
            hasPreTransferInCallback: false,
            isFirstTransferFromTaker: false,
            useTransferFromAndAquaPush: false,
            isAToB: true,
            allowPartialFill: true,
            usePermit2: false,
            threshold: "",
            to: address(0),
            signature: ""
        }));
    }
}
