// SPDX-License-Identifier: LicenseRef-Degensoft-SwapVM-1.1
pragma solidity ^0.8.27;

/// @custom:license-url https://github.com/1inch/swap-vm/blob/main/LICENSES/SwapVM-1.1.txt
/// @custom:copyright © 2025 Degensoft Ltd

import "../../../contracts/instructions/interfaces/IProtocolFeeProvider.sol";

contract InvalidProtocolFeeProviderMock is IProtocolFeeProvider {
    error FeeDynamicProtocolInvalidRecipient();

    /// @inheritdoc IProtocolFeeProvider
    function getRecipientAndFees(
        bytes32 /* orderHash */,
        address /* maker */,
        address /* taker */,
        address /* tokenIn */,
        address /* tokenOut */,
        bool /* isExactIn */
    ) external pure override returns (address, uint24, uint24) {
        revert FeeDynamicProtocolInvalidRecipient();
    }
}
