// Copyright 2026 Circle Internet Group, Inc. All rights reserved.
//
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

pragma solidity ^0.8.29;

import {Test} from "forge-std/Test.sol";

import {ICallFrom} from "../../src/call-from/ICallFrom.sol";
import {Addresses} from "../../scripts/Addresses.sol";

contract ICallFromTest is Test {
    function test_selector() public pure {
        bytes4 expected = bytes4(keccak256("callFrom(address,address,bytes)"));
        assertEq(ICallFrom.callFrom.selector, expected);
    }

    function test_callFromAddressConstant() public pure {
        assertEq(Addresses.CALL_FROM, 0x1800000000000000000000000000000000000003);
    }
}
