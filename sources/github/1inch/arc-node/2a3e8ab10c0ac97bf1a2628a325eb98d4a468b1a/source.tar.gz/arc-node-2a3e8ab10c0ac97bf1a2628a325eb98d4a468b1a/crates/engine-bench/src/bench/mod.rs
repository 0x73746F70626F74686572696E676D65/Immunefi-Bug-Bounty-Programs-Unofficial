// Copyright 2026 Circle Internet Group, Inc. All rights reserved.
//
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::cli::Command;

mod build_payload;
mod context;
mod fixture;
mod helpers;
pub mod new_payload_fcu;
mod output;
mod prepare_payload;
mod tx_submit;

pub async fn run(command: Command) -> eyre::Result<()> {
    match command {
        Command::PreparePayload(args) => prepare_payload::run(args).await,
        Command::NewPayloadFcu(args) => new_payload_fcu::run(args).await,
        Command::BuildPayload(args) => build_payload::run(args).await,
    }
}
