// Copyright 2025 Circle Internet Group, Inc. All rights reserved.
//
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use async_trait::async_trait;
use bytes::Bytes;

use arc_consensus_types::signing::{SignedExtension, SignedProposal, SignedVote, SigningError};
use arc_consensus_types::signing::{Signer, SigningProvider, VerificationResult, Verifier};

use crate::{ArcContext, Proposal, Vote};
use malachitebft_core_types::{NilOrVal, ValidatorProof, VoteExtensionScope};

pub use malachitebft_signing_ed25519::*;

const VOTE_EXTENSION_DOMAIN: &[u8] = b"malachitebft/vote-extension/v1\0";

fn vote_extension_sign_bytes(scope: &VoteExtensionScope<ArcContext>, extension: &Bytes) -> Vec<u8> {
    let precommit = Vote::new_precommit(
        scope.height,
        scope.round,
        NilOrVal::Val(scope.value_id),
        scope.validator_address,
    );
    let precommit_bytes = precommit.to_sign_bytes();

    let mut buf = Vec::new();
    buf.extend_from_slice(VOTE_EXTENSION_DOMAIN);
    buf.extend_from_slice(&(precommit_bytes.len() as u64).to_be_bytes());
    buf.extend_from_slice(&precommit_bytes);
    buf.extend_from_slice(&(extension.len() as u64).to_be_bytes());
    buf.extend_from_slice(extension);
    buf
}

#[derive(Clone)]
pub struct LocalSigningProvider {
    private_key: PrivateKey,
}

impl std::fmt::Debug for LocalSigningProvider {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LocalSigningProvider")
            .field("private_key", &"<redacted>")
            .finish()
    }
}

impl LocalSigningProvider {
    pub fn new(private_key: PrivateKey) -> Self {
        Self { private_key }
    }

    pub fn public_key(&self) -> PublicKey {
        self.private_key.public_key()
    }

    pub fn private_key(&self) -> &PrivateKey {
        &self.private_key
    }

    pub fn sign(&self, data: &[u8]) -> Signature {
        self.private_key.sign(data)
    }

    pub fn verify(&self, data: &[u8], signature: &Signature, public_key: &PublicKey) -> bool {
        public_key
            .inner()
            .verify(signature.inner(), data)
            .inspect_err(|e| {
                use base64::Engine;
                tracing::error!(
                    signature =
                        base64::engine::general_purpose::STANDARD.encode(signature.to_bytes()),
                    public_key = format!("0x{}", hex::encode(public_key.as_bytes())),
                    "Signature verification failed: {e}"
                );
            })
            .is_ok()
    }
}

#[async_trait]
impl Signer<ArcContext> for LocalSigningProvider {
    async fn sign_vote(&self, vote: Vote) -> Result<SignedVote<ArcContext>, SigningError> {
        let signature = self.sign(&vote.to_sign_bytes());
        Ok(SignedVote::new(vote, signature))
    }

    async fn sign_proposal(
        &self,
        proposal: Proposal,
    ) -> Result<SignedProposal<ArcContext>, SigningError> {
        let signature = self.private_key.sign(&proposal.to_sign_bytes());
        Ok(SignedProposal::new(proposal, signature))
    }

    async fn sign_vote_extension(
        &self,
        scope: VoteExtensionScope<ArcContext>,
        extension: Bytes,
    ) -> Result<SignedExtension<ArcContext>, SigningError> {
        let preimage = vote_extension_sign_bytes(&scope, &extension);
        let signature = self.private_key.sign(&preimage);
        Ok(SignedExtension::new(extension, signature))
    }

    async fn sign_validator_proof(
        &self,
        public_key: Vec<u8>,
        peer_id: Vec<u8>,
    ) -> Result<ValidatorProof<ArcContext>, SigningError> {
        let signing_bytes = ValidatorProof::<ArcContext>::signing_bytes(&public_key, &peer_id);
        let signature = self.sign(&signing_bytes);
        Ok(ValidatorProof::new(public_key, peer_id, signature))
    }
}

#[async_trait]
impl Verifier<ArcContext> for LocalSigningProvider {
    async fn verify_signed_vote(
        &self,
        vote: &Vote,
        signature: &Signature,
        public_key: &PublicKey,
    ) -> Result<VerificationResult, SigningError> {
        Ok(VerificationResult::from_bool(
            public_key.verify(&vote.to_sign_bytes(), signature).is_ok(),
        ))
    }

    async fn verify_signed_proposal(
        &self,
        proposal: &Proposal,
        signature: &Signature,
        public_key: &PublicKey,
    ) -> Result<VerificationResult, SigningError> {
        Ok(VerificationResult::from_bool(
            public_key
                .verify(&proposal.to_sign_bytes(), signature)
                .is_ok(),
        ))
    }

    async fn verify_signed_vote_extension(
        &self,
        scope: &VoteExtensionScope<ArcContext>,
        extension: &Bytes,
        signature: &Signature,
        public_key: &PublicKey,
    ) -> Result<VerificationResult, SigningError> {
        let preimage = vote_extension_sign_bytes(scope, extension);
        Ok(VerificationResult::from_bool(
            public_key.verify(&preimage, signature).is_ok(),
        ))
    }

    async fn verify_validator_proof(
        &self,
        proof: &ValidatorProof<ArcContext>,
    ) -> Result<VerificationResult, SigningError> {
        let signing_bytes = proof.preimage();
        let public_key = proof
            .decoded_public_key()
            .map_err(|e| SigningError::from_source(format!("Invalid public key: {e}")))?;
        Ok(VerificationResult::from_bool(self.verify(
            &signing_bytes,
            &proof.signature,
            &public_key,
        )))
    }
}

#[async_trait]
impl SigningProvider<ArcContext> for LocalSigningProvider {
    async fn sign_bytes(&self, bytes: &[u8]) -> Result<Signature, SigningError> {
        Ok(self.sign(bytes))
    }

    async fn verify_signed_bytes(
        &self,
        bytes: &[u8],
        signature: &Signature,
        public_key: &PublicKey,
    ) -> Result<VerificationResult, SigningError> {
        Ok(VerificationResult::from_bool(
            self.verify(bytes, signature, public_key),
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    use arc_consensus_types::{Address, BlockHash, Height, ValueId};
    use malachitebft_core_types::Round;

    fn test_provider() -> LocalSigningProvider {
        let private_key = PrivateKey::generate(rand::thread_rng());
        LocalSigningProvider::new(private_key)
    }

    fn test_scope(validator_byte: u8) -> VoteExtensionScope<ArcContext> {
        VoteExtensionScope::new(
            Height::new(7),
            Round::new(2),
            ValueId::new(BlockHash::repeat_byte(0xAB)),
            Address::repeat_byte(validator_byte),
        )
    }

    #[test]
    fn debug_impl_redacts_private_key() {
        let provider = test_provider();
        let debug_output = format!("{:?}", provider);
        assert!(
            debug_output.contains("<redacted>"),
            "Debug output must contain <redacted> placeholder"
        );
        assert_eq!(
            debug_output,
            "LocalSigningProvider { private_key: \"<redacted>\" }"
        );
    }

    #[test]
    fn verify_rejects_invalid_signature() {
        let provider = test_provider();
        let other = test_provider();
        let data = b"test message";
        let signature = other.sign(data);
        assert!(!provider.verify(data, &signature, &provider.public_key()));
    }

    #[tokio::test]
    async fn vote_extension_sign_verify_roundtrip() {
        let provider = test_provider();
        let scope = test_scope(0x01);
        let extension = Bytes::from_static(b"test extension");

        let signed = provider
            .sign_vote_extension(scope.clone(), extension.clone())
            .await
            .unwrap();
        assert_eq!(signed.message, extension);

        let result = provider
            .verify_signed_vote_extension(
                &scope,
                &signed.message,
                &signed.signature,
                &provider.public_key(),
            )
            .await
            .unwrap();
        assert!(result.is_valid());
    }

    // A signature produced for one scope must not verify against a different
    // scope; this guards the domain separation in `vote_extension_sign_bytes`.
    #[tokio::test]
    async fn vote_extension_signature_is_bound_to_scope() {
        let provider = test_provider();
        let extension = Bytes::from_static(b"test extension");

        let signed = provider
            .sign_vote_extension(test_scope(0x01), extension.clone())
            .await
            .unwrap();

        let result = provider
            .verify_signed_vote_extension(
                &test_scope(0x02),
                &signed.message,
                &signed.signature,
                &provider.public_key(),
            )
            .await
            .unwrap();
        assert!(!result.is_valid());
    }
}
