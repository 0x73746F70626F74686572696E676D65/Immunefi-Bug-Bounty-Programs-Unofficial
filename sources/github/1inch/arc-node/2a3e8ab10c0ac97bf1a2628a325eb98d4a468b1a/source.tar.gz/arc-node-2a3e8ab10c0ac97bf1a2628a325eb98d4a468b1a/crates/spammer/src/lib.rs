// Copyright 2025 Circle Internet Group, Inc. All rights reserved.
//
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#![allow(
    clippy::arithmetic_side_effects,
    clippy::cast_possible_truncation,
    clippy::unwrap_used
)]

mod accounts;
mod cli;
mod config;
mod erc20;
mod generator;
mod latency;
mod rate_limiter;
mod result_tracker;
mod sender;
mod spammer;
mod ws;

pub use accounts::PartitionMode;
pub use cli::SpammerArgs;
pub use config::{Config, Erc20FnWeights, GuzzlerFnWeights, ResumeConfig, TxTypeMix};
pub use spammer::{Spammer, SpammerRunResult, SpammerState, SpammerSummary};
