module.exports.mnemonic =
    ''
