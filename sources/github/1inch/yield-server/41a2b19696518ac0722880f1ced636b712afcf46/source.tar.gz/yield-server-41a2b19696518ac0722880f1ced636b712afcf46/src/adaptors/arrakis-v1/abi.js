module.exports = {
  arrakisABI: {
    getDeployers: {
      inputs: [],
      name: 'getDeployers',
      outputs: [
        {
          internalType: 'address[]',
          name: '',
          type: 'address[]',
        },
      ],
      stateMutability: 'view',
      type: 'function',
    },
    getPools: {
      inputs: [
        {
          internalType: 'address',
          name: 'deployer',
          type: 'address',
        },
      ],
      name: 'getPools',
      outputs: [
        {
          internalType: 'address[]',
          name: '',
          type: 'address[]',
        },
      ],
      stateMutability: 'view',
      type: 'function',
    },
    token0: {
      inputs: [],
      name: 'token0',
      outputs: [
        {
          internalType: 'contract IERC20',
          name: '',
          type: 'address',
        },
      ],
      stateMutability: 'view',
      type: 'function',
    },
    token1: {
      inputs: [],
      name: 'token1',
      outputs: [
        {
          internalType: 'contract IERC20',
          name: '',
          type: 'address',
        },
      ],
      stateMutability: 'view',
      type: 'function',
    },
    getUnderlyingBalances: {
      inputs: [],
      name: 'getUnderlyingBalances',
      outputs: [
        {
          internalType: 'uint256',
          name: 'amount0Current',
          type: 'uint256',
        },
        {
          internalType: 'uint256',
          name: 'amount1Current',
          type: 'uint256',
        },
      ],
      stateMutability: 'view',
      type: 'function',
    },
  },
};
