module.exports = [
  {
    inputs: [
      { internalType: 'contract IERC20', name: '_WNEAR', type: 'address' },
    ],
    stateMutability: 'nonpayable',
    type: 'constructor',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: 'address',
        name: 'previousAdmin',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'address',
        name: 'newAdmin',
        type: 'address',
      },
    ],
    name: 'AdminChanged',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'beacon',
        type: 'address',
      },
    ],
    name: 'BeaconUpgraded',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'previousOwner',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'newOwner',
        type: 'address',
      },
    ],
    name: 'OwnershipTransferred',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'implementation',
        type: 'address',
      },
    ],
    name: 'Upgraded',
    type: 'event',
  },
  {
    inputs: [],
    name: 'WNEAR',
    outputs: [{ internalType: 'contract IERC20', name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'contract AuToken', name: 'auToken', type: 'address' },
    ],
    name: 'auTokenBalances',
    outputs: [
      {
        components: [
          { internalType: 'address', name: 'auToken', type: 'address' },
          { internalType: 'uint256', name: 'balanceOf', type: 'uint256' },
          {
            internalType: 'uint256',
            name: 'borrowBalanceCurrent',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'balanceOfUnderlying',
            type: 'uint256',
          },
          { internalType: 'uint256', name: 'tokenBalance', type: 'uint256' },
          { internalType: 'uint256', name: 'tokenAllowance', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AuTokenBalances',
        name: '',
        type: 'tuple',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract AuToken[]',
        name: 'auTokens',
        type: 'address[]',
      },
    ],
    name: 'auTokenBalancesAll',
    outputs: [
      {
        components: [
          { internalType: 'address', name: 'auToken', type: 'address' },
          { internalType: 'uint256', name: 'balanceOf', type: 'uint256' },
          {
            internalType: 'uint256',
            name: 'borrowBalanceCurrent',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'balanceOfUnderlying',
            type: 'uint256',
          },
          { internalType: 'uint256', name: 'tokenBalance', type: 'uint256' },
          { internalType: 'uint256', name: 'tokenAllowance', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AuTokenBalances[]',
        name: '',
        type: 'tuple[]',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract AuToken[]',
        name: 'auTokens',
        type: 'address[]',
      },
    ],
    name: 'auTokenMetadataAllNonView',
    outputs: [
      {
        components: [
          { internalType: 'address', name: 'auToken', type: 'address' },
          {
            internalType: 'uint256',
            name: 'exchangeRateCurrent',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'supplyRatePerBlock',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'borrowRatePerBlock',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'reserveFactorMantissa',
            type: 'uint256',
          },
          { internalType: 'uint256', name: 'totalBorrows', type: 'uint256' },
          { internalType: 'uint256', name: 'totalReserves', type: 'uint256' },
          { internalType: 'uint256', name: 'totalSupply', type: 'uint256' },
          { internalType: 'uint256', name: 'totalCash', type: 'uint256' },
          { internalType: 'bool', name: 'isListed', type: 'bool' },
          {
            internalType: 'uint256',
            name: 'collateralFactorMantissa',
            type: 'uint256',
          },
          {
            internalType: 'address',
            name: 'underlyingAssetAddress',
            type: 'address',
          },
          { internalType: 'uint256', name: 'auTokenDecimals', type: 'uint256' },
          {
            internalType: 'uint256',
            name: 'underlyingDecimals',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'plyRewardSupplySpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'plyRewardBorrowSpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'auroraRewardSupplySpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'auroraRewardBorrowSpeed',
            type: 'uint256',
          },
          { internalType: 'uint256', name: 'borrowCap', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AuTokenMetadata[]',
        name: '',
        type: 'tuple[]',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'contract AuToken', name: 'auToken', type: 'address' },
    ],
    name: 'auTokenMetadataNonView',
    outputs: [
      {
        components: [
          { internalType: 'address', name: 'auToken', type: 'address' },
          {
            internalType: 'uint256',
            name: 'exchangeRateCurrent',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'supplyRatePerBlock',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'borrowRatePerBlock',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'reserveFactorMantissa',
            type: 'uint256',
          },
          { internalType: 'uint256', name: 'totalBorrows', type: 'uint256' },
          { internalType: 'uint256', name: 'totalReserves', type: 'uint256' },
          { internalType: 'uint256', name: 'totalSupply', type: 'uint256' },
          { internalType: 'uint256', name: 'totalCash', type: 'uint256' },
          { internalType: 'bool', name: 'isListed', type: 'bool' },
          {
            internalType: 'uint256',
            name: 'collateralFactorMantissa',
            type: 'uint256',
          },
          {
            internalType: 'address',
            name: 'underlyingAssetAddress',
            type: 'address',
          },
          { internalType: 'uint256', name: 'auTokenDecimals', type: 'uint256' },
          {
            internalType: 'uint256',
            name: 'underlyingDecimals',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'plyRewardSupplySpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'plyRewardBorrowSpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'auroraRewardSupplySpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'auroraRewardBorrowSpeed',
            type: 'uint256',
          },
          { internalType: 'uint256', name: 'borrowCap', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AuTokenMetadata',
        name: '',
        type: 'tuple',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'contract AuToken', name: 'auToken', type: 'address' },
    ],
    name: 'auTokenUnderlyingPrice',
    outputs: [
      {
        components: [
          { internalType: 'address', name: 'auToken', type: 'address' },
          { internalType: 'uint256', name: 'underlyingPrice', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AuTokenUnderlyingPrice',
        name: '',
        type: 'tuple',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract AuToken[]',
        name: 'auTokens',
        type: 'address[]',
      },
    ],
    name: 'auTokenUnderlyingPriceAll',
    outputs: [
      {
        components: [
          { internalType: 'address', name: 'auToken', type: 'address' },
          { internalType: 'uint256', name: 'underlyingPrice', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AuTokenUnderlyingPrice[]',
        name: '',
        type: 'tuple[]',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'claimOwnership',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract ComptrollerLensInterface',
        name: 'comptroller',
        type: 'address',
      },
      {
        internalType: 'contract AuriFairLaunchInterface',
        name: 'fairLaunch',
        type: 'address',
      },
      { internalType: 'uint256[]', name: 'pids', type: 'uint256[]' },
    ],
    name: 'claimRewards',
    outputs: [
      {
        components: [
          { internalType: 'uint256', name: 'plyAccrured', type: 'uint256' },
          { internalType: 'uint256', name: 'auroraClaimable', type: 'uint256' },
          { internalType: 'uint256', name: 'wnearClaimable', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.RewardBalancesMetadata',
        name: 'rewardData',
        type: 'tuple',
      },
    ],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract ComptrollerLensInterface',
        name: 'comptroller',
        type: 'address',
      },
    ],
    name: 'getAccountLimits',
    outputs: [
      {
        components: [
          {
            internalType: 'contract AuToken[]',
            name: 'markets',
            type: 'address[]',
          },
          { internalType: 'uint256', name: 'liquidity', type: 'uint256' },
          { internalType: 'uint256', name: 'shortfall', type: 'uint256' },
        ],
        internalType: 'struct AuriLens.AccountLimits',
        name: '',
        type: 'tuple',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract ComptrollerLensInterface',
        name: 'comptroller',
        type: 'address',
      },
    ],
    name: 'getAddresses',
    outputs: [
      { internalType: 'address', name: 'ply', type: 'address' },
      { internalType: 'address', name: 'aurora', type: 'address' },
      { internalType: 'address', name: 'wnear', type: 'address' },
      { internalType: 'address', name: 'pulp', type: 'address' },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'contract PULPInterface', name: 'pulp', type: 'address' },
      { internalType: 'address', name: 'account', type: 'address' },
      { internalType: 'int256', name: 'weekInt', type: 'int256' },
    ],
    name: 'getPercentLock',
    outputs: [
      { internalType: 'uint256', name: 'percentLock', type: 'uint256' },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      {
        internalType: 'contract ComptrollerLensInterface',
        name: 'comptroller',
        type: 'address',
      },
      { internalType: 'contract AuToken', name: 'auToken', type: 'address' },
    ],
    name: 'getRewardSpeeds',
    outputs: [
      {
        components: [
          {
            internalType: 'uint256',
            name: 'plyRewardSupplySpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'plyRewardBorrowSpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'auroraRewardSupplySpeed',
            type: 'uint256',
          },
          {
            internalType: 'uint256',
            name: 'auroraRewardBorrowSpeed',
            type: 'uint256',
          },
        ],
        internalType: 'struct AuriLens.RewardSpeeds',
        name: 'rewardSpeeds',
        type: 'tuple',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'contract PULPInterface', name: 'pulp', type: 'address' },
      { internalType: 'address', name: 'account', type: 'address' },
      { internalType: 'uint256', name: 'targetUnlockPercent', type: 'uint256' },
    ],
    name: 'getWeekToUnlock',
    outputs: [{ internalType: 'int256', name: '', type: 'int256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'initialize',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'owner',
    outputs: [{ internalType: 'address', name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'pendingOwner',
    outputs: [{ internalType: 'address', name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'proxiableUUID',
    outputs: [{ internalType: 'bytes32', name: '', type: 'bytes32' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'address', name: 'newOwner', type: 'address' },
      { internalType: 'bool', name: 'direct', type: 'bool' },
      { internalType: 'bool', name: 'renounce', type: 'bool' },
    ],
    name: 'transferOwnership',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'address', name: 'newImplementation', type: 'address' },
    ],
    name: 'upgradeTo',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { internalType: 'address', name: 'newImplementation', type: 'address' },
      { internalType: 'bytes', name: 'data', type: 'bytes' },
    ],
    name: 'upgradeToAndCall',
    outputs: [],
    stateMutability: 'payable',
    type: 'function',
  },
];
