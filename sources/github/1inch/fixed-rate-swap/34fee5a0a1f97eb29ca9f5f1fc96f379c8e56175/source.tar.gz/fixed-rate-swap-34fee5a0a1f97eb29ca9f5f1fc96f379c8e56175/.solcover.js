module.exports = {
    skipFiles: [
        'mocks'
    ]
}
