declare module 'redux-object'
