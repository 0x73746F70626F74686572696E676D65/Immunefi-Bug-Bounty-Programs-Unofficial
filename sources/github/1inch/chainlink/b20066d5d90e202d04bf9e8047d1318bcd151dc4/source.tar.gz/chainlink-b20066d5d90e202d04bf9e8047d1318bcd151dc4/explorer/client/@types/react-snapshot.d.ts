declare module 'react-snapshot'
