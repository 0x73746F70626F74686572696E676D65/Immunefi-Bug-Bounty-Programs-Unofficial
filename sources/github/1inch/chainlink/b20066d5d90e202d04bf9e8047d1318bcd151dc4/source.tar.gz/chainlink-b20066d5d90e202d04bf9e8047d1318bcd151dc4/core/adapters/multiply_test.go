package adapters_test

import (
	"encoding/json"
	"testing"

	"chainlink/core/adapters"
	"chainlink/core/internal/cltest"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestMultiply_Perform(t *testing.T) {
	tests := []struct {
		name      string
		params    string
		json      string
		want      string
		errored   bool
		jsonError bool
	}{
		{"string", `{"times":100}`, `{"result":"1.23"}`, "123", false, false},
		{"integer", `{"times":100}`, `{"result":123}`, "12300", false, false},
		{"float", `{"times":100}`, `{"result":1.23}`, "123", false, false},
		{"object", `{"times":100}`, `{"result":{"foo":"bar"}}`, "", true, false},
		{"zero integer string", `{"times":0}`, `{"result":"1.23"}`, "0", false, false},
		{"negative integer string", `{"times":-5}`, `{"result":"1.23"}`, "-6.15", false, false},
		{"no times parameter", `{}`, `{"result":"3.14"}`, "3.14", false, false},

		{"string string", `{"times":"100"}`, `{"result":"1.23"}`, "123", false, false},
		{"string integer", `{"times":"100"}`, `{"result":123}`, "12300", false, false},
		{"string float", `{"times":"100"}`, `{"result":1.23}`, "123", false, false},
		{"string object", `{"times":"100"}`, `{"result":{"foo":"bar"}}`, "", true, false},
		{"array string", `{"times":[1, 2, 3]}`, `{"result":"1.23"}`, "", false, true},
		{"rubbish string", `{"times":"123aaa123"}`, `{"result":"1.23"}`, "", false, true},
		{"zero string string", `{"times":"0"}`, `{"result":"1.23"}`, "0", false, false},
		{"negative string string", `{"times":"-5"}`, `{"result":"1.23"}`, "-6.15", false, false},
	}

	for _, tt := range tests {
		test := tt
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()
			input := cltest.NewRunInputWithString(t, test.json)
			adapter := adapters.Multiply{}
			jsonErr := json.Unmarshal([]byte(test.params), &adapter)
			result := adapter.Perform(input, nil)

			if test.jsonError {
				assert.Error(t, jsonErr)
			} else if test.errored {
				require.Error(t, result.Error())
				assert.NoError(t, jsonErr)
			} else {
				require.NoError(t, result.Error())
				assert.Equal(t, test.want, result.Result().String())
			}
		})
	}
}
