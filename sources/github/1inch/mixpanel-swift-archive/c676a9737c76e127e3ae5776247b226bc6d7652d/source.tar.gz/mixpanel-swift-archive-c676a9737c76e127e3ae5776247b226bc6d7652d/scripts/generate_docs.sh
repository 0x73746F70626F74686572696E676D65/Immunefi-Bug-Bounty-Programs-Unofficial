jazzy \
--clean \
-a Mixpanel \
-u http://mixpanel.com \
--github_url https://github.com/mixpanel/mixpanel-swift \
--module-version 4.1.3 \
--framework-root . \
--module Mixpanel
