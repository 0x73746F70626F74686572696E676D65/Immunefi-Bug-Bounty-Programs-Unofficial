export * from './multicall.model'
