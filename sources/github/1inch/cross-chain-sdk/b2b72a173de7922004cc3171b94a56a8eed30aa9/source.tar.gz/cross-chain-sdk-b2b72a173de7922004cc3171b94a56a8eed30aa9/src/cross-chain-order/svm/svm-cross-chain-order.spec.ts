import {parseEther, parseUnits} from 'ethers'
import {SvmCrossChainOrder} from './svm-cross-chain-order.js'
import {SvmSrcEscrowFactory} from '../../contracts/index.js'
import {NetworkEnum} from '../../chains.js'
import {TimeLocks} from '../../domains/time-locks/index.js'
import {HashLock} from '../../domains/hash-lock/index.js'
import {AuctionDetails} from '../../domains/auction-details/index.js'
import {EvmAddress, SolanaAddress} from '../../domains/addresses/index.js'

describe('SVMCrossChainOrder', () => {
    it('should correct calculate order hash', () => {
        const order = SvmCrossChainOrder.new(
            // 1 WETH [solana] -> 1000 USDC [ethereum]
            {
                maker: SolanaAddress.fromBigInt(1n),
                receiver: EvmAddress.fromBigInt(2n),
                srcToken: SolanaAddress.fromBigInt(3n),
                dstToken: EvmAddress.fromBigInt(4n), // address on dst chain
                srcAmount: parseEther('1'),
                minDstAmount: parseUnits('1000', 6)
            },
            {
                srcChainId: NetworkEnum.SOLANA,
                dstChainId: NetworkEnum.ETHEREUM,
                srcSafetyDeposit: 1000n,
                dstSafetyDeposit: 1000n,
                timeLocks: TimeLocks.fromDurations({
                    srcFinalityLock: 10n,
                    srcPrivateWithdrawal: 200n,
                    srcPublicWithdrawal: 100n,
                    srcPrivateCancellation: 100n,
                    dstFinalityLock: 10n,
                    dstPrivateWithdrawal: 100n,
                    dstPublicWithdrawal: 100n
                }),
                hashLock: HashLock.forSingleFill(
                    '0x4a52dc502242a54e1d3a609cb31e0160a504d9a26467fcf9a52b7a79060ef8f1'
                )
            },
            {
                auction: AuctionDetails.noAuction(120n, 1752739636n)
            },
            {
                allowMultipleFills: false,
                salt: 0x63030535n
            }
        )

        const hash = order.getOrderHashBuffer()

        expect(hash.toString('hex')).toEqual(
            'f59558e3ddb28b3aaa4953e12efc4c7b0d98c637942be3b5e8615998a5bf65c4'
        )
    })

    it('should correct toJSON/fromJSON', () => {
        const order = SvmCrossChainOrder.new(
            // 1 WETH [solana] -> 1000 USDC [ethereum]
            {
                maker: SolanaAddress.fromBigInt(1n),
                receiver: EvmAddress.fromBigInt(2n),
                srcToken: SolanaAddress.fromBigInt(3n),
                dstToken: EvmAddress.fromBigInt(4n), // address on dst chain
                srcAmount: parseEther('1'),
                minDstAmount: parseUnits('1000', 6)
            },
            {
                srcChainId: NetworkEnum.SOLANA,
                dstChainId: NetworkEnum.ETHEREUM,
                srcSafetyDeposit: 1000n,
                dstSafetyDeposit: 1000n,
                timeLocks: TimeLocks.fromDurations({
                    srcFinalityLock: 10n,
                    srcPrivateWithdrawal: 200n,
                    srcPublicWithdrawal: 100n,
                    srcPrivateCancellation: 100n,
                    dstFinalityLock: 10n,
                    dstPrivateWithdrawal: 100n,
                    dstPublicWithdrawal: 100n
                }),
                hashLock: HashLock.forSingleFill(
                    '0x4a52dc502242a54e1d3a609cb31e0160a504d9a26467fcf9a52b7a79060ef8f1'
                )
            },
            {
                auction: AuctionDetails.noAuction(120n, 1752739636n)
            },
            {
                allowMultipleFills: false,
                salt: 0x63030535n
            }
        )

        const json = order.toJSON()

        expect(json).toMatchSnapshot()
        expect(SvmCrossChainOrder.fromJSON(json)).toEqual(order)
    })

    it('should create order from create ix', () => {
        const order = SvmCrossChainOrder.new(
            {
                maker: SolanaAddress.fromBigInt(1n),
                receiver: EvmAddress.fromBigInt(2n),
                srcToken: SolanaAddress.NATIVE,
                dstToken: EvmAddress.fromBigInt(4n), // address on dst chain
                srcAmount: parseEther('1'),
                minDstAmount: parseUnits('1000', 6)
            },
            {
                srcChainId: NetworkEnum.SOLANA,
                dstChainId: NetworkEnum.ETHEREUM,
                srcSafetyDeposit: 1000n,
                dstSafetyDeposit: 1000n,
                timeLocks: TimeLocks.fromDurations({
                    srcFinalityLock: 10n,
                    srcPrivateWithdrawal: 200n,
                    srcPublicWithdrawal: 100n,
                    srcPrivateCancellation: 100n,
                    dstFinalityLock: 10n,
                    dstPrivateWithdrawal: 100n,
                    dstPublicWithdrawal: 100n
                }),
                hashLock: HashLock.forSingleFill(
                    '0x4a52dc502242a54e1d3a609cb31e0160a504d9a26467fcf9a52b7a79060ef8f1'
                )
            },
            {
                auction: AuctionDetails.noAuction(120n, 1752739636n)
            },
            {
                allowMultipleFills: false,
                salt: 0x63030535n
            }
        )

        const ix = SvmSrcEscrowFactory.DEFAULT.createOrder(order, {
            srcTokenProgramId: SolanaAddress.TOKEN_PROGRAM_ID
        })

        const data = SvmSrcEscrowFactory.parseCreateInstruction(ix)

        expect(
            SvmCrossChainOrder.fromContractOrder(data, order.auction)
        ).toEqual(order)
    })
})
