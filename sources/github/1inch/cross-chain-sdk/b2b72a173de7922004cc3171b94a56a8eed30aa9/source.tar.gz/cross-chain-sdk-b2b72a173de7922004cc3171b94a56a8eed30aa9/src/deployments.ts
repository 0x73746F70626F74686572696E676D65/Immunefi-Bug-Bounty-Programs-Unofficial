import {NetworkEnum} from './chains.js'
import {EvmAddress} from './domains/addresses/index.js'

const TrueERC20 = EvmAddress.fromString(
    '0xda0000d4000015a526378bb6fafc650cea5966f8'
)
const ZKTrueERC20 = EvmAddress.fromString(
    '0xd66097c27eb8dee404bac235737932260edc6f3b'
)
// Robinhood chain uses its own CREATE3 deployer, so addresses differ from other chains
const RobinhoodTrueERC20 = EvmAddress.fromString(
    '0x40c0b7e8018cca1eb8d913b75b1b20cfd89b8d5b'
)
// Monad, Cronos, HyperEVM and Arc use a new deployer, so they share addresses which differ from other chains
const MonadCronosHyperevmArcTrueERC20 = EvmAddress.fromString(
    '0x175a30f81eade2d75b4d1d5fc750131877355d21'
)

export const TRUE_ERC20 = {
    [NetworkEnum.ETHEREUM]: TrueERC20,
    [NetworkEnum.POLYGON]: TrueERC20,
    [NetworkEnum.OPTIMISM]: TrueERC20,
    [NetworkEnum.BINANCE]: TrueERC20,
    [NetworkEnum.AVALANCHE]: TrueERC20,
    [NetworkEnum.COINBASE]: TrueERC20,
    [NetworkEnum.FANTOM]: TrueERC20,
    [NetworkEnum.GNOSIS]: TrueERC20,
    [NetworkEnum.ARBITRUM]: TrueERC20,
    [NetworkEnum.ZKSYNC]: ZKTrueERC20,
    [NetworkEnum.LINEA]: TrueERC20,
    [NetworkEnum.SONIC]: TrueERC20,
    [NetworkEnum.UNICHAIN]: TrueERC20,
    [NetworkEnum.ROBINHOOD]: RobinhoodTrueERC20,
    [NetworkEnum.MONAD]: MonadCronosHyperevmArcTrueERC20,
    [NetworkEnum.CRONOS]: MonadCronosHyperevmArcTrueERC20,
    [NetworkEnum.HYPEREVM]: MonadCronosHyperevmArcTrueERC20,
    [NetworkEnum.ARC]: MonadCronosHyperevmArcTrueERC20
}

const ESCROW_FACTORY_ADDRESS = EvmAddress.fromString(
    '0x03a25b3215a0e5c15cf23ac4d2e5cf86c0ff7efa'
)
const ESCROW_ZK_FACTORY_ADDRESS = EvmAddress.fromString(
    '0xd9085ac07da21bd6eb003a530a524ab054ca8652'
)
const ESCROW_SRC_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x30476b0bf2f73f78a75488742920da7ff76c0ca0'
)
const ESCROW_ZK_SRC_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x198cc9a03192d767a29886b6ef626fee38e36959'
)
const ESCROW_DST_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x5cd822f1c70469c36898aa98516a48f4aa04c73a'
)
const ESCROW_ZK_DST_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x07d3d5e598cc23bfee9884b1e342ddaecd88dead'
)
// Robinhood chain uses its own CREATE3 deployer, so addresses differ from other chains
const ESCROW_RH_FACTORY_ADDRESS = EvmAddress.fromString(
    '0x50d26ea1e2460b3a42ff47466b955fc6bd906013'
)
const ESCROW_RH_SRC_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0xb540a42ca356f30307439b60647b5704d57f45ee'
)
const ESCROW_RH_DST_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x3875faf11ccef1dca35d190bc41cd47895dc18b2'
)
// Monad, Cronos, HyperEVM and Arc use a new deployer, so they share addresses which differ from other chains
const ESCROW_MCHA_FACTORY_ADDRESS = EvmAddress.fromString(
    '0x8e6c3c2e2631de0a1d4fd46a15f79a1373486fa4'
)
const ESCROW_MCHA_SRC_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x25fb2e7a56db5a3f04be5e7a728977e889e62a3c'
)
const ESCROW_MCHA_DST_IMPLEMENTATION_ADDRESS = EvmAddress.fromString(
    '0x715bb4091abccacef523a6069b4f0e2678a352f2'
)

export const ESCROW_SRC_IMPLEMENTATION = {
    [NetworkEnum.ETHEREUM]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.POLYGON]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.OPTIMISM]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.BINANCE]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.AVALANCHE]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.COINBASE]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.FANTOM]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.GNOSIS]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ARBITRUM]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ZKSYNC]: ESCROW_ZK_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.LINEA]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.SONIC]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.UNICHAIN]: ESCROW_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ROBINHOOD]: ESCROW_RH_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.MONAD]: ESCROW_MCHA_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.CRONOS]: ESCROW_MCHA_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.HYPEREVM]: ESCROW_MCHA_SRC_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ARC]: ESCROW_MCHA_SRC_IMPLEMENTATION_ADDRESS
}

export const ESCROW_DST_IMPLEMENTATION = {
    [NetworkEnum.ETHEREUM]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.POLYGON]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.OPTIMISM]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.BINANCE]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.AVALANCHE]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.COINBASE]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.FANTOM]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.GNOSIS]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ARBITRUM]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ZKSYNC]: ESCROW_ZK_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.LINEA]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.SONIC]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.UNICHAIN]: ESCROW_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ROBINHOOD]: ESCROW_RH_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.MONAD]: ESCROW_MCHA_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.CRONOS]: ESCROW_MCHA_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.HYPEREVM]: ESCROW_MCHA_DST_IMPLEMENTATION_ADDRESS,
    [NetworkEnum.ARC]: ESCROW_MCHA_DST_IMPLEMENTATION_ADDRESS
}

export const ESCROW_FACTORY = {
    [NetworkEnum.ETHEREUM]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.POLYGON]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.OPTIMISM]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.BINANCE]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.AVALANCHE]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.COINBASE]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.FANTOM]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.GNOSIS]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.ARBITRUM]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.ZKSYNC]: ESCROW_ZK_FACTORY_ADDRESS,
    [NetworkEnum.LINEA]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.SONIC]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.UNICHAIN]: ESCROW_FACTORY_ADDRESS,
    [NetworkEnum.ROBINHOOD]: ESCROW_RH_FACTORY_ADDRESS,
    [NetworkEnum.MONAD]: ESCROW_MCHA_FACTORY_ADDRESS,
    [NetworkEnum.CRONOS]: ESCROW_MCHA_FACTORY_ADDRESS,
    [NetworkEnum.HYPEREVM]: ESCROW_MCHA_FACTORY_ADDRESS,
    [NetworkEnum.ARC]: ESCROW_MCHA_FACTORY_ADDRESS
}
