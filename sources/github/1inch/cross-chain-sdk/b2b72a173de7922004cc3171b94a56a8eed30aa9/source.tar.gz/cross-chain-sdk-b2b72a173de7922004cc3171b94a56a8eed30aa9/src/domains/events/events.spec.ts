import {Interface} from 'ethers'
import {SrcEscrowCreatedEvent} from './src-escrow-created-event.js'
import {DstEscrowCreatedEvent} from './dst-escrow-created-event.js'
import {EscrowWithdrawalEvent} from './escrow-withdrawal-event.js'
import {FundsRescuedEvent} from './funds-rescued-event.js'
import {EscrowCancelledEvent} from './escrow-cancelled-event.js'
import {EvmAddress} from '../addresses/index.js'
import {ESCROW_FACTORY_ABI} from '../../abi/escrow-factory-abi.js'

describe('SrcEscrowCreatedEvent', () => {
    it('should decode real event data without fees', () => {
        const eventData =
            '0x00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000180838a67cc057d4d64f6b87e0c4bbf45d6374917dfb96059e97210e59b0f25b2711f98656c2a606884fbd64a8843846768b81decfd852a55531138152ad848ab4f0000000000000000000000008b83c50040c743e99bd47f4327bfcf7913c505b40000000000000000000000000cc85a15477539958d622a2735a3477d7d329c89000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc20000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000003e8693bffc1000000d20000006e0000000a0000019a00000136000000d20000000a000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008b83c50040c743e99bd47f4327bfcf7913c505b4000000000000000000000000000000000000000000000000000000003b9aca00000000000000000000000000a0b86991c6218b36c1d19d4a2e9eb0ce3606eb4800000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'

        const expectedMaker = '0x8b83c50040c743e99bd47f4327bfcf7913c505b4'
        const expectedTaker = '0x0cc85a15477539958d622a2735a3477d7d329c89'

        const event = SrcEscrowCreatedEvent.fromData(eventData)

        expect(event.srcImmutables.maker.toString().toLowerCase()).toBe(
            expectedMaker.toLowerCase()
        )
        expect(event.srcImmutables.taker.toString().toLowerCase()).toBe(
            expectedTaker.toLowerCase()
        )
        expect(event.srcImmutables.token.toString().toLowerCase()).toBe(
            '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2' // WETH
        )
        expect(event.srcImmutables.amount).toBe(1000000000000000000n)
        expect(event.srcImmutables.safetyDeposit).toBe(1000n)

        expect(
            event.dstImmutablesComplement.maker.toString().toLowerCase()
        ).toBe(expectedMaker.toLowerCase())
        expect(event.dstImmutablesComplement.amount).toBe(1000000000n)
        expect(
            event.dstImmutablesComplement.token.toString().toLowerCase()
        ).toBe('0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48')
        expect(event.dstImmutablesComplement.chainId).toBe(56n)

        expect(event.dstImmutablesComplement.fees.isZero()).toBe(true)
    })

    it('should decode real event data with solana', () => {
        const eventData =
            '0x0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000018073d6bece37a5e231a5b62d5d84d9d8832ef5d19d6ea9ca7d40fad435c4edd219b36d08c4bbb32af9f5a2fa794f3fe8e860e33f7c20850b78210776249aa2fcbf000000000000000000000000962a836519109e162754161000d65d9dc027fa0f0000000000000000000000009c4dffb4f7e8217a8ac0555d67e125f8769284ba000000000000000000000000a0b86991c6218b36c1d19d4a2e9eb0ce3606eb48000000000000000000000000000000000000000000000000000000000098968000000000000000000000000000000000000000000000000000001c388fe536f06981defb0000018e000001160000000e0000025a000001e20000012e0000001800000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000621a070ff71998b7c014a365bfbc88a2393c35890000000000000000000000000000000000000000000000000000000000934d5bce010e60afedb22717bd63192f54145a3f965a33bb82d2c7029eb2ce1e2082640000000000000000000000000000000000000000000000000000000000003b6d00000000000000000000000000000000000000000000000000000000000001f500000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'

        const expectedMakerSrc = '0x962a836519109e162754161000d65d9dc027fa0f'
        const expectedMakerDst = '1111111111112NGehUHzuybQf99trqUDBSFPJoY4' // first part of solana address
        const expectedTaker = '0x9c4dffb4f7e8217a8ac0555d67e125f8769284ba'

        const event = SrcEscrowCreatedEvent.fromData(eventData)

        expect(event.srcImmutables.maker.toString().toLowerCase()).toBe(
            expectedMakerSrc.toLowerCase()
        )
        expect(event.srcImmutables.taker.toString().toLowerCase()).toBe(
            expectedTaker.toLowerCase()
        )
        expect(event.srcImmutables.token.toString().toLowerCase()).toBe(
            '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48' // USDC
        )
        expect(event.srcImmutables.amount).toBe(10000000n)
        expect(event.srcImmutables.safetyDeposit).toBe(31029257910000n)

        expect(
            event.dstImmutablesComplement.maker.toString().toLowerCase()
        ).toBe(expectedMakerDst.toLowerCase())
        expect(event.dstImmutablesComplement.amount).toBe(9653595n)
        expect(event.dstImmutablesComplement.token.toString()).toBe(
            'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB' // USDT
        )
        expect(event.dstImmutablesComplement.chainId).toBe(501n)

        expect(event.dstImmutablesComplement.fees.isZero()).toBe(true)
    })

    it('should decode real event data with fees', () => {
        const eventData =
            '0x00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000180d03b49fc7c7ccf74578ce878a9617148d71d64db154b55cae3b5d655e2af55c611a34ca0e10001d01928f45c9307de00677879c24bc321a24be89188c751a58f0000000000000000000000008b83c50040c743e99bd47f4327bfcf7913c505b40000000000000000000000000cc85a15477539958d622a2735a3477d7d329c89000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc20000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000003e8693bffc4000000d20000006e0000000a0000019a00000136000000d20000000a000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008b83c50040c743e99bd47f4327bfcf7913c505b4000000000000000000000000000000000000000000000000000000003c706980000000000000000000000000a0b86991c6218b36c1d19d4a2e9eb0ce3606eb4800000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000c65d4000000000000000000000000000000000000000000000000000000000000f424000000000000000000000000011111111111111111111111111111111111111110000000000000000000000002222222222222222222222222222222222222222'

        const expectedMaker = '0x8b83c50040c743e99bd47f4327bfcf7913c505b4'
        const expectedTaker = '0x0cc85a15477539958d622a2735a3477d7d329c89'

        const event = SrcEscrowCreatedEvent.fromData(eventData)

        expect(event.srcImmutables.maker.toString().toLowerCase()).toBe(
            expectedMaker.toLowerCase()
        )
        expect(event.srcImmutables.taker.toString().toLowerCase()).toBe(
            expectedTaker.toLowerCase()
        )
        expect(event.srcImmutables.amount).toBe(1000000000000000000n)
        expect(event.srcImmutables.safetyDeposit).toBe(1000n)

        expect(
            event.dstImmutablesComplement.maker.toString().toLowerCase()
        ).toBe(expectedMaker.toLowerCase())
        expect(event.dstImmutablesComplement.amount).toBe(1014000000n)

        expect(event.dstImmutablesComplement.fees.isZero()).toBe(false)
        expect(event.dstImmutablesComplement.fees.resolverFeeAmount).toBe(
            13000000n
        )
        expect(event.dstImmutablesComplement.fees.integratorFeeAmount).toBe(
            1000000n
        )
        expect(
            event.dstImmutablesComplement.fees.resolverFeeRecipient
                .toString()
                .toLowerCase()
        ).toBe('0x1111111111111111111111111111111111111111')
        expect(
            event.dstImmutablesComplement.fees.integratorFeeRecipient
                .toString()
                .toLowerCase()
        ).toBe('0x2222222222222222222222222222222222222222')
    })
})

describe('DstEscrowCreatedEvent', () => {
    it('should decode real event data', () => {
        const eventData =
            '0x00000000000000000000000067ba818b6b05ad80ea455fb7d86c816d595602dd452a44705ac0ea4ccdc768e67f8fb9c9c07ccca9809418b1a2bfa346f88d37af0000000000000000000000000cc85a15477539958d622a2735a3477d7d329c89'

        const expectedTaker = '0x0cc85a15477539958d622a2735a3477d7d329c89'

        const event = DstEscrowCreatedEvent.fromData(eventData)

        expect(event.escrow.toString().toLowerCase()).toBe(
            '0x67ba818b6b05ad80ea455fb7d86c816d595602dd'
        )
        expect(event.hashlock).toBe(
            '0x452a44705ac0ea4ccdc768e67f8fb9c9c07ccca9809418b1a2bfa346f88d37af'
        )
        expect(event.taker.toString().toLowerCase()).toBe(
            expectedTaker.toLowerCase()
        )
    })

    it('should decode real event data with fees', () => {
        const eventData =
            '0x000000000000000000000000c9932a0e421475e0b14876e4393eda76b6a7f0a8bd2d8b5ca3494d14fc441dcacbb716efa951392e50143f71237ea5a096e705fe0000000000000000000000000cc85a15477539958d622a2735a3477d7d329c89'

        const expectedTaker = '0x0cc85a15477539958d622a2735a3477d7d329c89'

        const event = DstEscrowCreatedEvent.fromData(eventData)

        expect(event.escrow.toString().toLowerCase()).toBe(
            '0xc9932a0e421475e0b14876e4393eda76b6a7f0a8'
        )
        expect(event.hashlock).toBe(
            '0xbd2d8b5ca3494d14fc441dcacbb716efa951392e50143f71237ea5a096e705fe'
        )
        expect(event.taker.toString().toLowerCase()).toBe(
            expectedTaker.toLowerCase()
        )
    })
})

describe('EscrowWithdrawalEvent', () => {
    it('decodes a withdrawal secret from log data', () => {
        const secret =
            '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
        const iface = new Interface(ESCROW_FACTORY_ABI)
        const encoded = iface.encodeEventLog('EscrowWithdrawal', [secret])
        const event = EscrowWithdrawalEvent.fromData(encoded.data)

        expect(event.secret).toBe(secret)
        expect(EscrowWithdrawalEvent.TOPIC).toMatch(/^0x[0-9a-f]{64}$/)
    })
})

describe('FundsRescuedEvent', () => {
    it('decodes token, amount and escrow address from log data', () => {
        const token = '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
        const amount = 123456n
        const escrow = EvmAddress.fromString(
            '0x1111111111111111111111111111111111111111'
        )
        const iface = new Interface(ESCROW_FACTORY_ABI)
        const encoded = iface.encodeEventLog('FundsRescued', [token, amount])
        const event = FundsRescuedEvent.fromData(encoded.data, escrow)

        expect(event.token.toString().toLowerCase()).toBe(token)
        expect(event.amount).toBe(amount)
        expect(event.escrowAddress.equal(escrow)).toBe(true)
        expect(FundsRescuedEvent.TOPIC).toMatch(/^0x[0-9a-f]{64}$/)
    })
})

describe('EscrowCancelledEvent', () => {
    it('stores the escrow address and topic', () => {
        const escrow = EvmAddress.fromString(
            '0x2222222222222222222222222222222222222222'
        )
        const event = new EscrowCancelledEvent(escrow)

        expect(event.escrowAddress.equal(escrow)).toBe(true)
        expect(EscrowCancelledEvent.TOPIC).toMatch(/^0x[0-9a-f]{64}$/)
    })
})
