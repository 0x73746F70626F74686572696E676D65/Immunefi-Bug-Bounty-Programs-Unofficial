# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [2.0.4](https://github.com/1inch/limit-order-protocol-utils/compare/v2.0.3...v2.0.4) (2022-06-27)

### [2.0.3](https://github.com/1inch/limit-order-protocol-utils/compare/v2.0.2...v2.0.3) (2022-01-24)


### Features

* add limitOrderToWithPermit method ([#24](https://github.com/1inch/limit-order-protocol-utils/issues/24)) ([fe5c427](https://github.com/1inch/limit-order-protocol-utils/commit/fe5c4278fdbd3294b07e6032f7b416cd09b7b3a2))

### [2.0.2](https://github.com/1inch/limit-order-protocol-utils/compare/v2.0.1...v2.0.2) (2022-01-20)


### Bug Fixes

* add checking for hex response for gnosis chain ([#23](https://github.com/1inch/limit-order-protocol-utils/issues/23)) ([335985d](https://github.com/1inch/limit-order-protocol-utils/commit/335985df21efb9bd99df2d664091530da1da5f21))

### [2.0.1](https://github.com/1inch/limit-order-protocol-utils/compare/v2.0.0...v2.0.1) (2021-12-24)


### Features

* **limit-order-builder:** add arbitraryStaticCall method ([6e6655d](https://github.com/1inch/limit-order-protocol-utils/commit/6e6655d4c33ae9f05b2ad2e9fcdd365f7f5731fa))

## [2.0.0](https://github.com/1inch/limit-order-protocol-utils/compare/v1.5.0...v2.0.0) (2021-12-10)


### ⚠ BREAKING CHANGES

* Limit order V2 (#22)

### Features

* Limit order V2 ([#22](https://github.com/1inch/limit-order-protocol-utils/issues/22)) ([4037b77](https://github.com/1inch/limit-order-protocol-utils/commit/4037b775f3dcdcaae80fc38546f325b5997036a9))

## [1.5.0](https://github.com/1inch/limit-order-protocol-utils/compare/v1.4.1...v1.5.0) (2021-11-23)


### Features

* add support for Optimism and Arbitrum networks ([610b49e](https://github.com/1inch/limit-order-protocol-utils/commit/610b49e55d4112f2747efd59845e02af7d9d2327))

### [1.4.1](https://github.com/1inch/limit-order-protocol-utils/compare/v1.4.0...v1.4.1) (2021-10-12)

## [1.4.0](https://github.com/1inch/limit-order-protocol-utils/compare/v1.3.0...v1.4.0) (2021-08-09)


### ⚠ BREAKING CHANGES

* change web3 libs version to 1.5.1 (because 2.0.0 is deprecated)

* change web3 libs version to 1.5.1 (because 2.0.0 is deprecated) ([2e24ee3](https://github.com/1inch/limit-order-protocol-utils/commit/2e24ee308dae235f0eafb00266d50abdd970b1a0))

## [1.3.0](https://github.com/1inch/limit-order-protocol-utils/compare/v1.2.1...v1.3.0) (2021-06-14)


### Features

* **limit-order-rfq-utils:** plain output when proccess is running with argv ([6adfc41](https://github.com/1inch/limit-order-protocol-utils/commit/6adfc412faea42ce37539023440404c39f5136c4))

### [1.2.1](https://github.com/1inch/limit-order-protocol-utils/compare/v1.2.0...v1.2.1) (2021-06-10)

## [1.2.0](https://github.com/1inch/limit-order-protocol-utils/compare/v1.1.2...v1.2.0) (2021-06-10)


### Features

* **limit-order-builder:** add possibility to set different taker address for maker asset and taker asset for RFQ order ([44ae7b8](https://github.com/1inch/limit-order-protocol-utils/commit/44ae7b8c9496f264f522ffc8809de6810a86305b))

### [1.1.2](https://github.com/1inch/limit-order-protocol-utils/compare/v1.1.1...v1.1.2) (2021-06-10)


### Bug Fixes

* fix path to limit-order-rfq-utils script ([ae878b3](https://github.com/1inch/limit-order-protocol-utils/commit/ae878b3cab0dc027c7798e3fed70317a22cddad6))

### [1.1.1](https://github.com/1inch/limit-order-protocol-utils/compare/v1.1.0...v1.1.1) (2021-06-10)

## [1.1.0](https://github.com/1inch/limit-order-protocol-utils/compare/v1.0.2...v1.1.0) (2021-06-10)


### Features

* PrivateKeyProviderConnector - to create a signature of typed data for a limit order using the private key ([3bbb39c](https://github.com/1inch/limit-order-protocol-utils/commit/3bbb39cb609eb720a2f4465a1935d25371bcbb0a))

### [1.0.2](https://github.com/1inch/limit-order-protocol-utils/compare/v1.0.1...v1.0.2) (2021-06-09)

### [1.0.1](https://github.com/1inch/limit-order-protocol-utils/compare/v1.0.0...v1.0.1) (2021-06-09)

## [1.0.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.6.1...v1.0.0) (2021-06-09)

### [0.6.1](https://github.com/1inch/limit-order-protocol-utils/compare/v0.6.0...v0.6.1) (2021-06-09)

## [0.6.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.5.4...v0.6.0) (2021-06-09)


### ⚠ BREAKING CHANGES

* renamed many methods and models

* refactor all docs. Use LimitOrder and RFQOrder terms ([dd58d6d](https://github.com/1inch/limit-order-protocol-utils/commit/dd58d6d8905c099ea3bd062a09e6fefa6355f36e))

### [0.5.4](https://github.com/1inch/limit-order-protocol-utils/compare/v0.5.3...v0.5.4) (2021-06-08)

### [0.5.3](https://github.com/1inch/limit-order-protocol-utils/compare/v0.5.2...v0.5.3) (2021-06-08)


### Bug Fixes

* expiresInTimestampMs to expiresInTimestamp (seconds) ([5cb8816](https://github.com/1inch/limit-order-protocol-utils/commit/5cb8816899c7f8a6a6cafbad71961527e27311a9))

### [0.5.2](https://github.com/1inch/limit-order-protocol-utils/compare/v0.5.1...v0.5.2) (2021-06-08)

### [0.5.1](https://github.com/1inch/limit-order-protocol-utils/compare/v0.5.0...v0.5.1) (2021-06-08)

## [0.5.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.4.0...v0.5.0) (2021-06-08)


### Features

* **limit-order-rfq:** util for create,fill,cancel limit order RFQ ([aa61ed2](https://github.com/1inch/limit-order-protocol-utils/commit/aa61ed24a5f9285902f8d694b198a1ec1aa5bd00))
* RFQ limit orders ([b4a670e](https://github.com/1inch/limit-order-protocol-utils/commit/b4a670ede66ff4de410a4566bf5cef8662becfba))

## [0.4.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.3.0...v0.4.0) (2021-06-03)


### ⚠ BREAKING CHANGES

* **limit-order-protocol-facade:** LimitOrderProtocolFacade.simulateTransferFroms() renamed to simulateCalls()

### Features

* **limit-order-protocol-facade:** update limit order protocol contracts ([7be31d8](https://github.com/1inch/limit-order-protocol-utils/commit/7be31d8093cc989bacbbef6a9a2f25764885b9ae))

## [0.3.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.2.1...v0.3.0) (2021-05-20)


### ⚠ BREAKING CHANGES

* **limit-order-protocol-facade:** LimitOrderProtocolFacade.fillOrder() now has one more argument - thresholdAmount, LimitOrderProtocolFacade.nonces() renamed to LimitOrderProtocolFacade.nonce(), LimitOrderProtocolFacade.advanceNonce() now receive argument - nonce increment count - the number to increase the nonce, new method - LimitOrderProtocolFacade.increaseNonce() - increase nonce by 1

### Features

* **limit-order-protocol-facade:** improve errors parsing for simulateTransferFroms() and checkPredicate() ([24e2db8](https://github.com/1inch/limit-order-protocol-utils/commit/24e2db8572b20ed0ece64f6c8153487b2c9d22e6))
* **limit-order-protocol-facade:** update limit order protocol contracts ([5d2d1c6](https://github.com/1inch/limit-order-protocol-utils/commit/5d2d1c6cb1fa34a3b70b74a42c5788de937453b2))

### [0.2.1](https://github.com/1inch/limit-order-protocol-utils/compare/v0.2.0...v0.2.1) (2021-05-15)


### Bug Fixes

* **limit-order-protocol-facade:** improve parseSimulateTransferError() for any errors type ([3c40dac](https://github.com/1inch/limit-order-protocol-utils/commit/3c40daccdb833f6d525f6f2e55fc7d6fad75ecaf))

## [0.2.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.1.3...v0.2.0) (2021-05-14)


### Features

* **limit-order-builder:** buildOrderSignature() now provides a hash of typed data to providerConnector.signTypedData(walletAddress, typedData, dataHash) ([ebe7479](https://github.com/1inch/limit-order-protocol-utils/commit/ebe7479daba635b893c5d77a51ab363377b33e37))
* **limit-order-protocol-facade:** domainSeparator() for getting hash of domain separator ([3d462cd](https://github.com/1inch/limit-order-protocol-utils/commit/3d462cde6b02e83b61e85d7ad08b43cea3f9ca40))

### [0.1.3](https://github.com/1inch/limit-order-protocol-utils/compare/v0.1.2...v0.1.3) (2021-05-07)


### Bug Fixes

* **limit-order-protocol-facade:** improved parsing of simulate transfer error ([34bb9d3](https://github.com/1inch/limit-order-protocol-utils/commit/34bb9d355c1e0a581f21536b1848af53a90ccb62))

### [0.1.2](https://github.com/1inch/limit-order-protocol-utils/compare/v0.1.1...v0.1.2) (2021-05-04)

### [0.1.1](https://github.com/1inch/limit-order-protocol-utils/compare/v0.1.0...v0.1.1) (2021-05-04)

## [0.1.0](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.7...v0.1.0) (2021-05-01)


### ⚠ BREAKING CHANGES

* **limit-order-predicate-builder:** LimitOrderProtocolFacade now doesn't include methods: andPredicate, timestampBelow, nonceEquals. Use LimitOrderPredicateBuilder instead

### Features

* **limit-order-predicate-builder:** LimitOrderPredicateBuilder for create predicates for limit orders ([881beb0](https://github.com/1inch/limit-order-protocol-utils/commit/881beb0acc50c210befa310d02092e83b346dcbd))

### [0.0.7](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.6...v0.0.7) (2021-04-30)


### Features

* **limit-order-protocol-facade:** improve parsing result of simulateTransferFroms for ethereum mainnet ([69b41ac](https://github.com/1inch/limit-order-protocol-utils/commit/69b41ac54e5ffbe29715652c84dc8c3190fb23da))

### [0.0.6](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.5...v0.0.6) (2021-04-26)


### Features

* **limit-order-protocol-facade:** methods for parse contract response ([ff00a78](https://github.com/1inch/limit-order-protocol-utils/commit/ff00a7809ef56b153500d6fef1d2543944285f24))
* **limit-order-protocol-facade:** methods for parse remaining response ([b3f9912](https://github.com/1inch/limit-order-protocol-utils/commit/b3f99126c1d0ab15e4a2aa63d3e68a591ddfa675))

### [0.0.5](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.4...v0.0.5) (2021-04-26)


### Features

* **limit-order-protocol-facade:** remove unused remainingsRaw() method ([627e084](https://github.com/1inch/limit-order-protocol-utils/commit/627e084b2df6072e920e04e9900a973bd4e60f05))


### Bug Fixes

* **limit-order-protocol-facade:** fix return type of remaining() method ([4cbcc5d](https://github.com/1inch/limit-order-protocol-utils/commit/4cbcc5d1d8254ac1af90085b960746300b680fe8))

### [0.0.4](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.3...v0.0.4) (2021-04-26)

### [0.0.3](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.2...v0.0.3) (2021-04-26)


### Features

* **limit-order-protocol-facade:** simulateTransferFroms() check order validity for filling ([263040c](https://github.com/1inch/limit-order-protocol-utils/commit/263040ce1485afdbcc6a5694c483f26aa73642a5))

### [0.0.2](https://github.com/1inch/limit-order-protocol-utils/compare/v0.0.1...v0.0.2) (2021-04-23)


### Features

* **limit-order-protocol-facade:** checkPredicate() for validate predicates ([e8d2eed](https://github.com/1inch/limit-order-protocol-utils/commit/e8d2eedafb0c04d79e91cb05bc72649a47e70ae7))

### 0.0.1 (2021-04-23)
