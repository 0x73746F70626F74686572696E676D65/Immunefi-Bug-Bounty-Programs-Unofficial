//! Terminal output: a live speed line plus a printed line per improved hit.

use std::io::Write;
use std::time::Instant;

use miner_backend::speed::SpeedSummary;
use miner_backend::{Hit, Reporter};
use miner_core::{MineMode, to_checksum_address};

const CLEAR_LINE: &str = "\x1b[2K\r";

pub struct TerminalReporter {
    mode: MineMode,
    start: Instant,
    quiet: bool,
    /// The `--exact` masks as they were written, indexed by `Hit::pattern`.
    masks: Vec<String>,
    pub hits: usize,
    pub unverified: usize,
    /// Matches the result buffers could not keep, across the whole run.
    pub dropped: u64,
}

impl TerminalReporter {
    pub fn new(mode: MineMode, quiet: bool, masks: Vec<String>) -> Self {
        Self {
            mode,
            start: Instant::now(),
            quiet,
            masks,
            hits: 0,
            unverified: 0,
            dropped: 0,
        }
    }
}

impl Reporter for TerminalReporter {
    fn on_hit(&mut self, hit: &Hit) {
        self.hits += 1;
        let seconds = self.start.elapsed().as_secs();

        let detail = match self.mode {
            MineMode::Nft => hit
                .magic
                .map(|m| format!("Magic: 0x{}", hex::encode(m)))
                .unwrap_or_default(),
            MineMode::Profanity => hit
                .offset
                .map(|o| format!("Offset: 0x{}", hex::encode(o)))
                .unwrap_or_default(),
            _ => hit
                .salt
                .map(|s| format!("Salt: 0x{}", hex::encode(s)))
                .unwrap_or_default(),
        };

        // Two things can fail here and the marker covers both, because what the
        // operator does about either is the same. Either the kernel and the CPU
        // disagree about the address, which is a correctness bug; or the device
        // returned a 1nft salt not bound to --mint-for, which an honest one
        // cannot do. Say so loudly instead of printing it like any other result.
        let flag = if hit.verified {
            String::new()
        } else {
            self.unverified += 1;
            "  [UNVERIFIED: the CPU does not agree this hit follows from its inputs]".to_string()
        };

        // Under --exact every match scores the same, so the score says nothing
        // and which mask matched says everything.
        let what = match hit.pattern.and_then(|i| self.masks.get(i)) {
            Some(mask) => format!("Mask: {mask:>6}"),
            None => format!("Score: {:>2}", hit.score),
        };

        print!("{CLEAR_LINE}");
        println!(
            "  Time: {seconds:>5}s  {what}  GPU{}  {detail}  Address: {}{flag}",
            hit.device_index,
            to_checksum_address(&hit.address),
        );
        let _ = std::io::stdout().flush();
    }

    /// A round that found more than it could keep says so, rather than looking
    /// like one where matches happened to be rare.
    fn on_dropped(&mut self, count: u32, device_index: usize) {
        self.dropped += u64::from(count);
        print!("{CLEAR_LINE}");
        println!("         (+{count} more this round on GPU{device_index}, not kept)");
        let _ = std::io::stdout().flush();
    }

    /// The figure to quote. `on_speed` is a short rolling window, so it moves
    /// around; this is the average over everything after the warmup.
    fn on_summary(&mut self, summary: &SpeedSummary) {
        print!("{CLEAR_LINE}");
        println!(
            "Measured: {:.3} MH/s over {:.1}s ({} hashes)",
            summary.rate / 1.0e6,
            summary.elapsed.as_secs_f64(),
            summary.hashes,
        );
        let _ = std::io::stdout().flush();
    }

    fn on_speed(&mut self, total: f64, per_device: &[f64]) {
        if self.quiet {
            return;
        }
        let mut line = format!("{CLEAR_LINE}Speed: {:.3} MH/s", total / 1.0e6);
        if per_device.len() > 1 {
            for (i, speed) in per_device.iter().enumerate() {
                line.push_str(&format!("  GPU{i}: {:.3} MH/s", speed / 1.0e6));
            }
        }
        print!("{line}");
        let _ = std::io::stdout().flush();
    }
}
