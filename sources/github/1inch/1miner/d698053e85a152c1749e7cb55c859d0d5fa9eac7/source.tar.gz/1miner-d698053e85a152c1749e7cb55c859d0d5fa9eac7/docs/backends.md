# Backends and kernels

A backend decides *where* candidates are enumerated. A kernel decides *how*. Both are chosen at run time so you can race implementations against each other on your own hardware rather than trusting someone else's benchmark.

## Backends

| `--backend` | Modes | Notes |
| --- | --- | --- |
| `opencl` (default) | all four | Multi-GPU. |
| `metal` | all four | macOS only, requires `--features metal` at build time. Single device. |
| `cpu` | all four | Portable fallback and the reference the others are checked against. Two-lane NEON on aarch64. |

CUDA is the intended next backend and slots in the same way.

Metal exists because Apple deprecated OpenCL: on Apple silicon it is capped at OpenCL 1.2 and is not the fast path the driver is tuned for. On an M4 Max the two are close, with Metal slightly ahead for create3.

The two GPU backends differ in more than their API. OpenCL specialises its kernels at build time with `-D` and caches the compiled binary on disk; Metal compiles from source on every run and takes everything a job varies — the pre-image, the seed, the batch width — in a buffer instead, so changing any of them costs nothing. `--kernel` therefore does nothing on Metal, which has one Keccak. Metal also drives one system default device and so has no `--skip`, where OpenCL runs a thread per GPU.

## The CPU backend

Its first job is to be the reference the accelerated backends are checked against, but it is a usable miner for small searches and the answer on a machine with no GPU at all.

Being usable for a real search is why `profanity` draws a random starting offset per run here, as the OpenCL path draws one per device. From a fixed start a second run against the same public key re-covers the offsets the first one already tried, so it would add nothing to a search — and two people working from the same published seed public key would find the same addresses.

On aarch64 the salt modes use a two-lane NEON Keccak, holding each of the 25 Keccak lanes as a `uint64x2_t` so one permutation covers two candidates. That is worth 2.3x on an M4 Max: 88.7 against 38.0 MH/s for create3. It is still several times slower than the same machine's GPU, so this is a fallback rather than a contender.

`MINER_NO_NEON=1` forces the plain scalar path. Use it to A/B the two, or as a safety valve if the SIMD path ever misbehaves on some hardware. The test suite asserts both produce identical addresses for every mode, so the choice is a performance one only.

Where the ARMv8.2 SHA3 extension is present, which is every Apple silicon chip, the permutation uses it: `eor3` folds three XORs into one, `rax1` does theta's rotate-and-XOR, `xar` does theta's XOR and rho's rotation in one instruction, and `bcax` does chi. Worth 6.7% for create2 on an M4 Max, 176.1 against 165.0 MH/s, measured by switching paths in the same binary. It is detected at run time rather than assumed, since it is not part of the aarch64 baseline, and `MINER_NO_SHA3=1` forces the plain NEON path. The two are asserted to produce identical states for every input the suite tries, so this too is a performance choice only.

## Kernels

`--kernel` selects the Keccak permutation used by the OpenCL backend:

- `tuned` (default) — the ERADICATE2/3 permutation: fused theta with five temporaries and a rotated chi step.
- `plain` — profanity2's more literal permutation.

They are functionally identical, which the test suite asserts by having both find the same planted address. On an Apple M4 Max they measure within noise of each other, because the driver's compiler optimises both to much the same code. On other hardware the gap may be real, which is the point of being able to switch.

## Adding a kernel variant

1. Put the source in `kernels/opencl/`.
2. Add a `const` for it in `crates/miner-backend/src/kernels.rs`, which embeds sources with `include_str!` so the binary stays self-contained.
3. Add a variant to `KeccakVariant` in `crates/miner-backend/src/lib.rs`, wiring up `source()`, `as_str()`, `parse()` and `all()`.
4. Add the name to the `--kernel` value list in `crates/miner-cli/src/cli.rs`.

The interface a Keccak source must provide is small: the `ethhash` union, `void sha3_keccakf(ethhash *)`, and `void sha3_keccakf_address(ethhash *)`, which is the same permutation with the last round cut to the lanes bytes 12 to 32 come from and is what the salt kernel calls. Note that both are expected to apply the trailing `0x80` pad byte themselves; see [how-address-derivation-works.md](how-address-derivation-works.md).

## How the Metal sources fit together

A Metal library is compiled from a single source string, so `kernels/metal/` is split by what is shared rather than by what is selectable, and the host concatenates the pieces in order:

| File | Holds |
| --- | --- |
| `keccak.metal` | The permutation, the byte accessors, and the one `#include`. Always first. |
| `scoring.metal` | The `Mode` and `Pattern` structs and `score_address`, shared by both kernels. |
| `salt.metal` | create2 / create3 / 1nft. |
| `profanity.metal` | secp256k1, a port of `kernels/opencl/profanity.cl`. |

OpenCL carries a copy of the scoring functions in each of its two programs because it compiles them separately. Metal does not have to, and a shared copy is one that cannot drift.

The pieces are ordinary text, so the ordering is a real constraint rather than a convention: a second `#include` in a later part fails the build with a line number in a file nobody wrote. `crates/miner-backend/src/metal/mod.rs` asserts both the order and the single include.

Then check it and time it:

```bash
cargo test --test derivation          # must still agree with the CPU
1miner self-test --kernel mynew       # and on your actual GPU
1miner create3 --deployer 0x... --benchmark --kernel mynew --seconds 30
```

A new kernel that is fast and wrong is the failure this project is arranged to prevent, so run the agreement tests before you believe the number.

## Tuning

| Flag | Applies to | Meaning |
| --- | --- | --- |
| `-w`, `--work` | all GPU backends | Local work size / threadgroup width. `0` lets the driver choose. |
| `-W`, `--work-max` | OpenCL, Metal profanity | Largest single enqueue; rounds are split into chunks of this size. |
| `-S`, `--size` | salt modes | Candidates per round per device. Default 16777216. |
| `-i`, `--inverse-size` | profanity | Batched-inversion width. Default 255, maximum 1024. |
| `-I`, `--inverse-multiple` | profanity | Parallel inverse batches. Default 16384. |
| `-s`, `--skip` | OpenCL | Skip a device by index. Repeatable. |
| `-n`, `--no-cache` | OpenCL | Ignore the compiled-kernel cache. |
| `--threads` | cpu | Worker threads. Defaults to available parallelism. |

For profanity, `--inverse-size` times `--inverse-multiple` is both the number of points per round and the driver of memory use: three scratch buffers of 32 bytes per point, so the default 4.2M points needs roughly 400 MB. Lower `-I` first if a device runs out of memory or takes too long to initialise.

`--inverse-size` is capped at 1024 because in the OpenCL kernel it becomes the length of two private `mp_number` arrays, 32 bytes each: 1024 already asks a single work item for 64 KB of private memory, and past that a build spills or fails with no diagnostic worth reading. The Metal kernel has no such arrays — it keeps the same prefix products in the buffer it is going to write anyway — so the cap is there for the backend that needs it. None of these flags accepts `0` except `--work`, where it means "let the driver choose".

## `--exact` runs a different kernel

Scoring and `--exact` ask different questions, and each has its own kernel and its own result buffer. Scoring wants the best candidate so far, so its buffer holds one slot per score and a climbing bar stops the kernel writing anything worse. `--exact` wants every candidate that matched, which is a list: matches are appended in arrival order, there is no bar, and the count of them is what the host reads first.

The list holds 256 matches per round per device. Every one recovered is reported, and a round that finds more says by how many it overflowed rather than discarding the rest in silence. The number is not tunable: at five constrained digits or more a round produces fewer matches than that anyway, and below it the limit is doing you a favour, since the alternative is thousands of lines a second.
