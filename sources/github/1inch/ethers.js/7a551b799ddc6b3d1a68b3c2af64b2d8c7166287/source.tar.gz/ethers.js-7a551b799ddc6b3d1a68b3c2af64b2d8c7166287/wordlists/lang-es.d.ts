import { Wordlist } from '../utils/wordlist';
declare class LangEs extends Wordlist {
    constructor();
    getWord(index: number): string;
    getWordIndex(word: string): number;
}
declare const langEs: LangEs;
export { langEs };
