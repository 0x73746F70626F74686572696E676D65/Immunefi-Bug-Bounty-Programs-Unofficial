

contract("ENSLoans", function(accounts) {
});
