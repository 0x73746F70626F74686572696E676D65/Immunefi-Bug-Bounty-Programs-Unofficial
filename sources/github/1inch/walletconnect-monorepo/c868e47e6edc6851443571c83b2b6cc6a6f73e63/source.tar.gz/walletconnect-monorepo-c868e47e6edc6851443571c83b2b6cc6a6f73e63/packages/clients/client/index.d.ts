declare module "@walletconnect/client"
