declare module "@walletconnect/core"
