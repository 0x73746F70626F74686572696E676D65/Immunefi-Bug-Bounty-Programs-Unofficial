#include <algorithm>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <map>
#include <set>

#if defined(__APPLE__) || defined(__MACOSX)
#include <OpenCL/cl.h>
#include <OpenCL/cl_ext.h> // Included to get topology to get an actual unique identifier per device
#else
#include <CL/cl.h>
#include <CL/cl_ext.h> // Included to get topology to get an actual unique identifier per device
#endif

// Asking the OS where the running executable is, see getExecutablePath below.
#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#elif defined(__APPLE__) || defined(__MACOSX)
#include <mach-o/dyld.h>
#else
#include <unistd.h>
#endif

#define CL_DEVICE_PCI_BUS_ID_NV  0x4008
#define CL_DEVICE_PCI_SLOT_ID_NV 0x4009

#include "Dispatcher.hpp"
#include "ArgParser.hpp"
#include "Mode.hpp"
#include "help.hpp"

// Directory the running executable lives in, with a trailing separator, or
// empty when it could not be determined. Set once at the start of main.
std::string g_strExecutableDir;

std::string directoryOf(const std::string & strPath) {
	const std::string::size_type pos = strPath.find_last_of("/\\");
	return pos == std::string::npos ? std::string() : strPath.substr(0, pos + 1);
}

std::string getExecutablePath() {
#if defined(_WIN32)
	char szPath[MAX_PATH];
	const DWORD length = GetModuleFileNameA(NULL, szPath, MAX_PATH);
	if (length > 0 && length < MAX_PATH) {
		return std::string(szPath, length);
	}
#elif defined(__APPLE__) || defined(__MACOSX)
	uint32_t length = 0;
	_NSGetExecutablePath(NULL, &length); // Fails on purpose, only to report the size
	if (length > 0) {
		std::vector<char> vPath(length, '\0');
		if (_NSGetExecutablePath(vPath.data(), &length) == 0) {
			return std::string(vPath.data());
		}
	}
#else
	std::vector<char> vPath(4096, '\0');
	const ssize_t length = readlink("/proc/self/exe", vPath.data(), vPath.size() - 1);
	if (length > 0) {
		return std::string(vPath.data(), length);
	}
#endif
	return std::string();
}

// Kernel sources sit next to the executable in the container image and in the
// directories the benchmark harness builds, and in kernels/ in a source tree.
// The working directory is tried last: that is where every release before the
// source tree was split into src/ and kernels/ kept them.
std::string readKernel(const std::string & strName) {
	std::vector<std::string> vCandidates;
	if (!g_strExecutableDir.empty()) {
		vCandidates.push_back(g_strExecutableDir + strName);
		vCandidates.push_back(g_strExecutableDir + "../kernels/" + strName);
	}
	vCandidates.push_back(strName);
	vCandidates.push_back("kernels/" + strName);

	for (const auto & strCandidate : vCandidates) {
		std::ifstream in(strCandidate.c_str(), std::ios::in | std::ios::binary);
		if (in) {
			std::ostringstream contents;
			contents << in.rdbuf();
			return contents.str();
		}
	}

	std::string strTried;
	for (const auto & strCandidate : vCandidates) {
		strTried += "\n  " + strCandidate;
	}

	throw std::runtime_error("could not open " + strName + ", looked in:" + strTried);
}

std::vector<cl_device_id> getAllDevices(cl_device_type deviceType = CL_DEVICE_TYPE_GPU) {
	std::vector<cl_device_id> vDevices;

	cl_uint platformIdCount = 0;
	cl_int err = clGetPlatformIDs(0, NULL, &platformIdCount);
	if (err != CL_SUCCESS || platformIdCount == 0) {
		std::cerr << "warning: no OpenCL platforms found, err = " << err << std::endl;
		return vDevices;
	}

	std::vector<cl_platform_id> platformIds(platformIdCount);
	err = clGetPlatformIDs(platformIdCount, platformIds.data(), NULL);
	if (err != CL_SUCCESS) {
		std::cerr << "warning: failed to enumerate OpenCL platforms, err = " << err << std::endl;
		return vDevices;
	}

	for (auto it = platformIds.cbegin(); it != platformIds.cend(); ++it) {
		cl_uint countDevice = 0;

		err = clGetDeviceIDs(*it, deviceType, 0, NULL, &countDevice);
		if (err != CL_SUCCESS || countDevice == 0) {
			char platformName[256] = {0};
			clGetPlatformInfo(*it, CL_PLATFORM_NAME, sizeof(platformName), platformName, NULL);
			std::cerr << "warning: skipping OpenCL platform without usable GPU devices: "
			          << platformName << ", err = " << err << std::endl;
			continue;
		}

		std::vector<cl_device_id> deviceIds(countDevice);
		err = clGetDeviceIDs(*it, deviceType, countDevice, deviceIds.data(), &countDevice);
		if (err != CL_SUCCESS) {
			char platformName[256] = {0};
			clGetPlatformInfo(*it, CL_PLATFORM_NAME, sizeof(platformName), platformName, NULL);
			std::cerr << "warning: failed to get GPU devices from platform: "
			          << platformName << ", err = " << err << std::endl;
			continue;
		}

		std::copy(deviceIds.begin(), deviceIds.end(), std::back_inserter(vDevices));
	}

	return vDevices;
}

// Reads a fixed-size device or program property, reporting whether the runtime
// actually answered. Everything below asks for at least one property that not
// every runtime implements, and the value has to be zeroed rather than left as
// whatever was on the stack when the query fails.
template <typename T, typename U, typename V, typename W>
bool clGetWrapperChecked(T & t, U function, V param, W param2) {
	t = T();
	return function(param, param2, sizeof(t), &t, NULL) == CL_SUCCESS;
}

template <typename T, typename U, typename V, typename W>
T clGetWrapper(U function, V param, W param2) {
	T t;
	clGetWrapperChecked(t, function, param, param2);
	return t;
}

template <typename U, typename V, typename W>
std::string clGetWrapperString(U function, V param, W param2) {
	size_t len = 0;
	if (function(param, param2, 0, NULL, &len) != CL_SUCCESS || len == 0) {
		return std::string();
	}

	char * const szString = new char[len]();
	function(param, param2, len, szString, NULL);
	std::string r(szString);
	delete[] szString;
	return r;
}

template <typename T, typename U, typename V, typename W>
std::vector<T> clGetWrapperVector(U function, V param, W param2) {
	size_t len = 0;
	function(param, param2, 0, NULL, &len);
	len /= sizeof(T);
	std::vector<T> v;
	if (len > 0) {
		T * pArray = new T[len];
		function(param, param2, len * sizeof(T), pArray, NULL);
		for (size_t i = 0; i < len; ++i) {
			v.push_back(pArray[i]);
		}
		delete[] pArray;
	}
	return v;
}

std::vector<std::string> getBinaries(cl_program & clProgram) {
	std::vector<std::string> vReturn;
	auto vSizes = clGetWrapperVector<size_t>(clGetProgramInfo, clProgram, CL_PROGRAM_BINARY_SIZES);
	if (!vSizes.empty()) {
		unsigned char * * pBuffers = new unsigned char *[vSizes.size()];
		for (size_t i = 0; i < vSizes.size(); ++i) {
			pBuffers[i] = new unsigned char[vSizes[i]];
		}

		clGetProgramInfo(clProgram, CL_PROGRAM_BINARIES, vSizes.size() * sizeof(unsigned char *), pBuffers, NULL);
		for (size_t i = 0; i < vSizes.size(); ++i) {
			std::string strData(reinterpret_cast<char *>(pBuffers[i]), vSizes[i]);
			vReturn.push_back(strData);
			delete[] pBuffers[i];
		}

		delete[] pBuffers;
	}

	return vReturn;
}

unsigned int getUniqueDeviceIdentifier(const cl_device_id & deviceId) {
	// Recent Khronos headers define CL_DEVICE_TOPOLOGY_AMD but dropped the
	// cl_device_topology_amd struct and the TYPE_PCIE constant, hence the
	// second condition.
#if defined(CL_DEVICE_TOPOLOGY_AMD) && defined(CL_DEVICE_TOPOLOGY_TYPE_PCIE_AMD)
	cl_device_topology_amd topology;
	if (clGetWrapperChecked(topology, clGetDeviceInfo, deviceId, CL_DEVICE_TOPOLOGY_AMD)
		&& topology.raw.type == CL_DEVICE_TOPOLOGY_TYPE_PCIE_AMD) {
		return (topology.pcie.bus << 16) + (topology.pcie.device << 8) + topology.pcie.function;
	}
#endif
	cl_int bus_id, slot_id;
	if (clGetWrapperChecked(bus_id, clGetDeviceInfo, deviceId, CL_DEVICE_PCI_BUS_ID_NV)
		&& clGetWrapperChecked(slot_id, clGetDeviceInfo, deviceId, CL_DEVICE_PCI_SLOT_ID_NV)) {
		return (bus_id << 16) + slot_id;
	}

	// Neither vendor's PCI extension is available, which is where Apple's
	// runtime ends up. What identifies a device here is what it calls itself,
	// and that is enough for a compiled kernel: two identical GPUs hashing to
	// one entry is correct, because the binary they need is the same.
	const std::string strIdentity =
		clGetWrapperString(clGetDeviceInfo, deviceId, CL_DEVICE_NAME) + "\n"
		+ clGetWrapperString(clGetDeviceInfo, deviceId, CL_DEVICE_VENDOR) + "\n"
		+ clGetWrapperString(clGetDeviceInfo, deviceId, CL_DRIVER_VERSION);

	// FNV-1a. It only has to be stable from one run to the next.
	unsigned int hash = 2166136261u;
	for (const char c : strIdentity) {
		hash = (hash ^ static_cast<unsigned char>(c)) * 16777619u;
	}

	return hash;
}

template <typename T> bool printResult(const T & t, const cl_int & err) {
	std::cout << ((t == NULL) ? toString(err) : "OK") << std::endl;
	return t == NULL;
}

bool printResult(const cl_int err) {
	std::cout << ((err != CL_SUCCESS) ? toString(err) : "OK") << std::endl;
	return err != CL_SUCCESS;
}

std::string getDeviceCacheFilename(cl_device_id & d, const size_t & inverseSize) {
	const auto uniqueId = getUniqueDeviceIdentifier(d);
	return g_strExecutableDir + "cache-opencl." + toString(inverseSize) + "." + toString(uniqueId);
}

int main(int argc, char * * argv) {
	// THIS LINE WILL LEAD TO A COMPILE ERROR. THIS TOOL SHOULD NOT BE USED, SEE README.

	// ^^ Commented previous line and excluded private key generation out of scope of this project,
	// now it only advances provided public key to a random offset to find vanity address

	try {
		g_strExecutableDir = directoryOf(getExecutablePath());
		if (g_strExecutableDir.empty() && argc > 0) {
			g_strExecutableDir = directoryOf(argv[0]);
		}

		ArgParser argp(argc, argv);
		bool bHelp = false;
		bool bModeBenchmark = false;
		bool bModeZeros = false;
		bool bModeZeroBytes = false;
		bool bModeLetters = false;
		bool bModeNumbers = false;
		std::string strModeLeading;
		std::string strModeMatching;
		std::string strModeExact;
		std::string strPublicKey;
		bool bModeLeadingRange = false;
		bool bModeRange = false;
		bool bModeMirror = false;
		bool bModeDoubles = false;
		int rangeMin = 0;
		int rangeMax = 0;
		std::vector<size_t> vDeviceSkipIndex;
		size_t worksizeLocal = 64;
		size_t worksizeMax = 0; // Will be automatically determined later if not overriden by user
		bool bNoCache = false;
		size_t inverseSize = 255;
		size_t inverseMultiple = 16384;
		bool bMineContract = false;

		argp.addSwitch('h', "help", bHelp);
		argp.addSwitch('0', "benchmark", bModeBenchmark);
		argp.addSwitch('1', "zeros", bModeZeros);
		argp.addSwitch('2', "letters", bModeLetters);
		argp.addSwitch('3', "numbers", bModeNumbers);
		argp.addSwitch('4', "leading", strModeLeading);
		argp.addSwitch('5', "matching", strModeMatching);
		argp.addSwitch('6', "leading-range", bModeLeadingRange);
		argp.addSwitch('7', "range", bModeRange);
		argp.addSwitch('8', "mirror", bModeMirror);
		argp.addSwitch('9', "leading-doubles", bModeDoubles);
		argp.addSwitch('m', "min", rangeMin);
		argp.addSwitch('M', "max", rangeMax);
		argp.addMultiSwitch('s', "skip", vDeviceSkipIndex);
		argp.addSwitch('w', "work", worksizeLocal);
		argp.addSwitch('W', "work-max", worksizeMax);
		argp.addSwitch('n', "no-cache", bNoCache);
		argp.addSwitch('i', "inverse-size", inverseSize);
		argp.addSwitch('I', "inverse-multiple", inverseMultiple);
		argp.addSwitch('c', "contract", bMineContract);
		argp.addSwitch('z', "publicKey", strPublicKey);
		argp.addSwitch('b', "zero-bytes", bModeZeroBytes);
		argp.addSwitch('e', "exact", strModeExact);

		if (!argp.parse()) {
			std::cout << "error: bad arguments, try again :<" << std::endl;
			return 1;
		}

		if (bHelp) {
			std::cout << g_strHelp << std::endl;
			return 0;
		}

		Mode mode = Mode::benchmark();
		if (bModeBenchmark) {
			mode = Mode::benchmark();
		} else if (bModeZeros) {
			mode = Mode::zeros();
		} else if (bModeLetters) {
			mode = Mode::letters();
		} else if (bModeNumbers) {
			mode = Mode::numbers();
		} else if (!strModeLeading.empty()) {
			mode = Mode::leading(strModeLeading.front());
		} else if (!strModeMatching.empty()) {
			mode = Mode::matching(strModeMatching);
		} else if (!strModeExact.empty()) {
			mode = Mode::exact(strModeExact);
		} else if (bModeLeadingRange) {
			mode = Mode::leadingRange(rangeMin, rangeMax);
		} else if (bModeRange) {
			mode = Mode::range(rangeMin, rangeMax);
		} else if(bModeMirror) {
			mode = Mode::mirror();
		} else if (bModeDoubles) {
			mode = Mode::doubles();
		} else if (bModeZeroBytes) {
			mode = Mode::zeroBytes();
		} else {
			std::cout << g_strHelp << std::endl;
			return 0;
		}
		
		if (strPublicKey.length() == 0) {
			std::cout << "error: this tool requires your public key to derive it's private key security" << std::endl;
			return 1;
		}

		if (strPublicKey.length() != 128) {
			std::cout << "error: public key must be 128 hexademical characters long" << std::endl;
			return 1;
		}

		std::cout << "Mode: " << mode.name << std::endl;

		if (bMineContract) {
			mode.target = CONTRACT;
		} else {
			mode.target = ADDRESS;
		}
		std::cout << "Target: " << mode.transformName() << std:: endl;

		std::vector<cl_device_id> vFoundDevices = getAllDevices();
		std::vector<cl_device_id> vDevices;
		std::map<cl_device_id, size_t> mDeviceIndex;

		std::vector<std::string> vDeviceBinary;
		std::vector<size_t> vDeviceBinarySize;
		cl_int errorCode;
		bool bUsedCache = false;

		std::cout << "Devices:" << std::endl;
		for (size_t i = 0; i < vFoundDevices.size(); ++i) {
			// Ignore devices in skip index
			if (std::find(vDeviceSkipIndex.begin(), vDeviceSkipIndex.end(), i) != vDeviceSkipIndex.end()) {
				continue;
			}

			cl_device_id & deviceId = vFoundDevices[i];

			const auto strName = clGetWrapperString(clGetDeviceInfo, deviceId, CL_DEVICE_NAME);
			const auto computeUnits = clGetWrapper<cl_uint>(clGetDeviceInfo, deviceId, CL_DEVICE_MAX_COMPUTE_UNITS);
			const auto globalMemSize = clGetWrapper<cl_ulong>(clGetDeviceInfo, deviceId, CL_DEVICE_GLOBAL_MEM_SIZE);
			bool precompiled = false;

			// Check if there's a prebuilt binary for this device and load it
			if(!bNoCache) {
				std::ifstream fileIn(getDeviceCacheFilename(deviceId, inverseSize), std::ios::binary);
				if (fileIn.is_open()) {
					vDeviceBinary.push_back(std::string((std::istreambuf_iterator<char>(fileIn)), std::istreambuf_iterator<char>()));
					vDeviceBinarySize.push_back(vDeviceBinary.back().size());
					precompiled = true;
				}
			}

			std::cout << "  GPU" << i << ": " << strName << ", " << globalMemSize << " bytes available, " << computeUnits << " compute units (precompiled = " << (precompiled ? "yes" : "no") << ")" << std::endl;
			vDevices.push_back(vFoundDevices[i]);
			mDeviceIndex[vFoundDevices[i]] = i;
		}

		if (vDevices.empty()) {
			return 1;
		}

		std::cout << std::endl;
		std::cout << "Initializing OpenCL..." << std::endl;
		std::cout << "  Creating context..." << std::flush;
		auto clContext = clCreateContext( NULL, vDevices.size(), vDevices.data(), NULL, NULL, &errorCode);
		if (printResult(clContext, errorCode)) {
			return 1;
		}

		cl_program clProgram;
		if (vDeviceBinary.size() == vDevices.size()) {
			// Create program from binaries
			bUsedCache = true;

			std::cout << "  Loading kernel from binary..." << std::flush;
			const unsigned char * * pKernels = new const unsigned char *[vDevices.size()];
			for (size_t i = 0; i < vDeviceBinary.size(); ++i) {
				pKernels[i] = reinterpret_cast<const unsigned char *>(vDeviceBinary[i].data());
			}

			cl_int * pStatus = new cl_int[vDevices.size()];

			clProgram = clCreateProgramWithBinary(clContext, vDevices.size(), vDevices.data(), vDeviceBinarySize.data(), pKernels, pStatus, &errorCode);
			if(printResult(clProgram, errorCode)) {
				return 1;
			}
		} else {
			// Create a program from the kernel source
			std::cout << "  Compiling kernel..." << std::flush;
			const std::string strKeccak = readKernel("keccak.cl");
			const std::string strVanity = readKernel("profanity.cl");
			const char * szKernels[] = { strKeccak.c_str(), strVanity.c_str() };

			clProgram = clCreateProgramWithSource(clContext, sizeof(szKernels) / sizeof(char *), szKernels, NULL, &errorCode);
			if (printResult(clProgram, errorCode)) {
				return 1;
			}
		}

		// Build the program
		std::cout << "  Building program..." << std::flush;
		const std::string strBuildOptions = "-D PROFANITY_INVERSE_SIZE=" + toString(inverseSize) + " -D PROFANITY_MAX_SCORE=" + toString(PROFANITY_MAX_SCORE);
		if (printResult(clBuildProgram(clProgram, vDevices.size(), vDevices.data(), strBuildOptions.c_str(), NULL, NULL))) {
#ifdef PROFANITY_DEBUG
			std::cout << std::endl;
			std::cout << "build log:" << std::endl;

			size_t sizeLog;
			clGetProgramBuildInfo(clProgram, vDevices[0], CL_PROGRAM_BUILD_LOG, 0, NULL, &sizeLog);
			char * const szLog = new char[sizeLog];
			clGetProgramBuildInfo(clProgram, vDevices[0], CL_PROGRAM_BUILD_LOG, sizeLog, szLog, NULL);

			std::cout << szLog << std::endl;
			delete[] szLog;
#endif
			return 1;
		}

		// Save binary to improve future start times
		if( !bUsedCache && !bNoCache ) {
			std::cout << "  Saving program..." << std::flush;
			auto binaries = getBinaries(clProgram);
			for (size_t i = 0; i < binaries.size(); ++i) {
				std::ofstream fileOut(getDeviceCacheFilename(vDevices[i], inverseSize), std::ios::binary);
				fileOut.write(binaries[i].data(), binaries[i].size());
			}
			std::cout << "OK" << std::endl;
		}

		std::cout << std::endl;

		Dispatcher d(clContext, clProgram, mode, worksizeMax == 0 ? inverseSize * inverseMultiple : worksizeMax, inverseSize, inverseMultiple, 0, strPublicKey);
		for (auto & i : vDevices) {
			d.addDevice(i, worksizeLocal, mDeviceIndex[i]);
		}

		d.run();
		clReleaseContext(clContext);
		return 0;
	} catch (std::runtime_error & e) {
		std::cout << "std::runtime_error - " << e.what() << std::endl;
	} catch (...) {
		std::cout << "unknown exception occured" << std::endl;
	}

	return 1;
}

