const { deployAndGetContract, deployAndGetContractWithCreate3 } = require('@1inch/solidity-utils');
const hre = require('hardhat');
const { ethers, getChainId } = hre;
const constants = require('../config/constants');

module.exports = async ({ getNamedAccounts, deployments, config }) => {
    const networkName = hre.network.name;
    console.log(`running ${networkName} deploy script`);
    const chainId = await getChainId();
    console.log('network id ', chainId);

    if (
        networkName in hre.config.networks &&
        chainId !== hre.config.networks[networkName].chainId?.toString()
    ) {
        console.log(`network chain id: ${hre.config.networks[networkName].chainId}, your chain id ${chainId}`);
        console.log('skipping wrong chain id deployment');
        return;
    }

    const lopHelperConfigs = config.deployOpts?.lopHelperConfigs || [];
    const helperOrder = ['SeriesNonceManager', 'CallsSimulator', 'PriorityFeeLimiter', 'OrderRegistrator', 'SafeOrderBuilder'];
    const sortedLopHelperConfigs = helperOrder
        .map(name => lopHelperConfigs.find(cfg => cfg.name === name))
        .filter(cfg => cfg); // remove undefined

    console.log('Lop helper configs to deploy:', sortedLopHelperConfigs);

    let orderRegistrator;

    let DEPLOYMENT_METHOD = config.deployOpts?.deploymentMethod || 'create3';

    if (networkName.indexOf('zksync') !== -1) { // create3 is not supported for zksync
        DEPLOYMENT_METHOD = 'create';
    }

    for (const helperConfig of sortedLopHelperConfigs) {
        const helperName = helperConfig.name;

        let args = [];
        switch (helperName) {
        case 'OrderRegistrator':
            args = [constants.ROUTER_V6[chainId]];
            break;
        case 'SafeOrderBuilder':
            args = [constants.ROUTER_V6[chainId], orderRegistrator ? await orderRegistrator.getAddress() : constants.ORDER_REGISTRATOR[chainId]];
            break;
        }

        console.log(`Deploying ${helperName} with args: ${JSON.stringify(args)}`);
        console.log(`Using deployment method: ${DEPLOYMENT_METHOD}`);

        let result;

        if (DEPLOYMENT_METHOD === 'create3') {
            if (helperName === 'OrderRegistrator' && !helperConfig.salt) {
                // The default salt resolves to the address the previous, announcement-less registrator already
                // occupies on every chain it was deployed to.
                throw new Error('Deploying OrderRegistrator requires an explicit salt, as the default one is already taken by the deployment that predates stored announcements.');
            }

            const salt = helperConfig.salt
                ? (
                    helperConfig.salt.startsWith('0x')
                        ? helperConfig.salt
                        : ethers.keccak256(ethers.toUtf8Bytes(helperConfig.salt))
                )
                : ethers.keccak256(ethers.toUtf8Bytes(helperName));

            console.log(`Using salt: ${salt}`);
                
            result = await deployAndGetContractWithCreate3({
                contractName: helperName,
                constructorArgs: args,
                deploymentName: helperName,
                create3Deployer: constants.CREATE3_DEPLOYER[chainId],
                salt,
                deployments,
                skipVerify: process.env.OPS_SKIP_VERIFY === 'true',
            });
        } else {
            const { deployer } = await getNamedAccounts();

            result = await deployAndGetContract({
                contractName: helperName,
                constructorArgs: args,
                deployments,
                deployer,
                skipVerify: process.env.OPS_SKIP_VERIFY === 'true',
            });
        }

        console.log(`Address for ${helperName}: ${await result.getAddress()}`);

        if (helperName === 'OrderRegistrator') {
            orderRegistrator = result;
        }
    }
};

module.exports.skip = async () => true;
