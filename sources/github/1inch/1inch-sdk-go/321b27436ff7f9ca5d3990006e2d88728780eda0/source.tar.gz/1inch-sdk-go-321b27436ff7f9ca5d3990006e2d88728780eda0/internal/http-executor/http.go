package http_executor

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"net/url"
	"reflect"
	"regexp"
	"time"

	"github.com/google/go-querystring/query"

	"github.com/1inch/1inch-sdk-go/v5/common"
)

var scientificNotationRegex = regexp.MustCompile(`^[+-]?\d+(\.\d+)?[eE][+-]?\d+$`)

// defaultRequestTimeout bounds each API request end-to-end (connection, TLS,
// headers, and body). Without it a stalled connection hangs callers that pass
// context.Background() forever. Callers can still enforce shorter deadlines
// per request through the context.
const defaultRequestTimeout = 60 * time.Second

// maxResponseBytes caps how much of a response body is read, protecting
// callers from unbounded memory use on a misbehaving endpoint or proxy. The
// largest legitimate responses (full token lists) are a few megabytes.
const maxResponseBytes = 64 << 20

func DefaultHttpClient(apiUrl string, apiKey string) (*Client, error) {
	baseURL, err := url.Parse(apiUrl)
	if err != nil {
		return nil, err
	}
	return &Client{
		httpClient: http.Client{Timeout: defaultRequestTimeout},
		baseURL:    baseURL,
		apiKey:     apiKey,
	}, nil
}

type Client struct {
	httpClient http.Client

	// The URL of the 1inch API
	baseURL *url.URL
	// The API key to use for authentication
	apiKey string
}

func (c *Client) ExecuteRequest(ctx context.Context, payload common.RequestPayload, v any) error {
	u, err := addQueryParameters(payload.Path, payload.Params)
	if err != nil {
		return err
	}

	fullURL, err := c.baseURL.Parse(u)
	if err != nil {
		return err
	}

	req, err := c.prepareRequest(ctx, payload.Method, fullURL, payload.Body)
	if err != nil {
		return fmt.Errorf("failed to prepare request: %w", err)
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("failed to execute request: %w", err)
	}

	if err = c.processResponse(resp, v); err != nil {
		return fmt.Errorf("failed to process response: %w", err)
	}

	return nil
}

func (c *Client) prepareRequest(ctx context.Context, method string, fullURL *url.URL, body []byte) (*http.Request, error) {
	req, err := http.NewRequestWithContext(ctx, method, fullURL.String(), bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}

	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", c.apiKey))
	if len(body) > 0 {
		req.Header.Set("Content-Type", "application/json")
	}

	return req, nil
}

func (c *Client) processResponse(resp *http.Response, v any) error {
	defer resp.Body.Close()

	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return c.handleErrorResponse(resp)
	}

	buf := new(bytes.Buffer)
	n, err := buf.ReadFrom(io.LimitReader(resp.Body, maxResponseBytes+1))
	if err != nil {
		return err
	}
	if n > maxResponseBytes {
		return fmt.Errorf("response body exceeds %d bytes", int64(maxResponseBytes))
	}

	if buf.Len() == 0 {
		return nil // No content to decode
	}

	if v != nil {
		return json.NewDecoder(buf).Decode(v)
	}

	return nil
}

func (c *Client) handleErrorResponse(resp *http.Response) error {
	body, err := io.ReadAll(io.LimitReader(resp.Body, maxResponseBytes))
	if err != nil {
		return fmt.Errorf("failed to read error response body: %w", err)
	}

	var errorMessageMap map[string]any
	err = json.Unmarshal(body, &errorMessageMap)
	if err != nil {
		return fmt.Errorf("failed to unmarshal error response body: %w", err)
	}

	errFormatted, err := json.MarshalIndent(errorMessageMap, "", "    ")
	if err != nil {
		return fmt.Errorf("failed to format error response body: %w", err)
	}

	return fmt.Errorf("%s", errFormatted)
}

// addQueryParameters adds the parameters in the struct params as URL query parameters to s.
// params must be a struct whose fields may contain "url" tags.
func addQueryParameters(s string, params any) (string, error) {
	v := reflect.ValueOf(params)
	if v.Kind() == reflect.Ptr && v.IsNil() {
		return s, nil
	}

	u, err := url.Parse(s)
	if err != nil {
		return s, err
	}

	qs, err := query.Values(params)
	if err != nil {
		return s, err
	}

	for k, v := range qs {
		if isScientificNotation(v[0]) {
			expanded, err := expandScientificNotation(v[0])
			if err != nil {
				return "", fmt.Errorf("failed to expand scientific notation for %v: %w", k, err)
			}
			v[0] = expanded
		}
	}

	u.RawQuery = qs.Encode()
	return u.String(), nil
}

// isScientificNotation checks if the string is in scientific notation (like 1e+18).
func isScientificNotation(s string) bool {
	return scientificNotationRegex.MatchString(s)
}

func expandScientificNotation(s string) (string, error) {
	f, _, err := big.ParseFloat(s, 10, 0, big.ToNearestEven)
	if err != nil {
		return "", err
	}

	// Use a precision that is sufficient to handle small numbers.
	// The precision here is set to a large number to ensure accuracy for small decimal values.
	f.SetPrec(64)

	return f.Text('f', -1), nil // -1 ensures that insignificant zeroes are not omitted
}
