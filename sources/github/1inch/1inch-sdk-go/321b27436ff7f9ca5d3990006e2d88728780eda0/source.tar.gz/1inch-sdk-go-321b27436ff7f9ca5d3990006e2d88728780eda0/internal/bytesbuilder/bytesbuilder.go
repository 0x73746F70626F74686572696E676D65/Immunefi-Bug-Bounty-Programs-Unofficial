package bytesbuilder

import (
	"encoding/hex"
	"math/big"

	"github.com/1inch/1inch-sdk-go/v5/internal/hexadecimal"
	"github.com/ethereum/go-ethereum/common"
)

type BytesBuilder struct {
	data []byte
}

func New() *BytesBuilder {
	return &BytesBuilder{data: []byte{}}
}

func (b *BytesBuilder) AddUint256(val *big.Int) {
	bytes := val.Bytes()
	if len(bytes) < 32 {
		// Pad on the left (big-endian) to 32 bytes
		padded := make([]byte, 32-len(bytes))
		bytes = append(padded, bytes...)
	} else if len(bytes) > 32 {
		// Truncate to last 32 bytes if larger (high bits ignored)
		bytes = bytes[len(bytes)-32:]
	}
	b.data = append(b.data, bytes...)
}

func (b *BytesBuilder) AddUint24(val *big.Int) {
	bytes := val.Bytes()
	switch {
	case len(bytes) < 3:
		// Pad on the left with zeros to make it 3 bytes
		padded := make([]byte, 3-len(bytes))
		bytes = append(padded, bytes...)
	case len(bytes) > 3:
		// Truncate any bytes above the 3 least significant
		bytes = bytes[len(bytes)-3:]
	}
	b.data = append(b.data, bytes...)
}

func (b *BytesBuilder) AddUint32(val *big.Int) {
	bytes := val.Bytes()
	if len(bytes) < 4 {
		padded := make([]byte, 4-len(bytes))
		bytes = append(padded, bytes...)
	}
	b.data = append(b.data, bytes...)
}

func (b *BytesBuilder) AddUint16(val *big.Int) {
	bytes := val.Bytes()
	if len(bytes) < 2 {
		padded := make([]byte, 2-len(bytes))
		bytes = append(padded, bytes...)
	}
	b.data = append(b.data, bytes...)
}

func (b *BytesBuilder) AddUint8(val uint8) {
	b.data = append(b.data, byte(val))
}

func (b *BytesBuilder) AddAddress(address common.Address) {
	b.data = append(b.data, address.Bytes()...)
}

func (b *BytesBuilder) AddBytes(data string) error {
	bytes, err := hex.DecodeString(hexadecimal.Trim0x(data))
	if err != nil {
		return err
	}
	b.data = append(b.data, bytes...)
	return nil
}

// AddNativeUint16 appends a uint16 as 2 big-endian bytes.
func (b *BytesBuilder) AddNativeUint16(val uint16) {
	b.data = append(b.data, byte(val>>8), byte(val))
}

// AddNativeUint24 appends the low 24 bits of a uint32 as 3 big-endian bytes.
func (b *BytesBuilder) AddNativeUint24(val uint32) {
	b.data = append(b.data, byte(val>>16), byte(val>>8), byte(val))
}

// AddNativeUint32 appends a uint32 as 4 big-endian bytes.
func (b *BytesBuilder) AddNativeUint32(val uint32) {
	b.data = append(b.data, byte(val>>24), byte(val>>16), byte(val>>8), byte(val))
}

func (b *BytesBuilder) AsHex() string {
	return hex.EncodeToString(b.data)
}

// AsBytes returns the raw accumulated bytes.
func (b *BytesBuilder) AsBytes() []byte {
	return b.data
}
