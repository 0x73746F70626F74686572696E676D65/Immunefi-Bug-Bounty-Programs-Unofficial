# CLAUDE.md - 1inch SDK Go

## Overview

This is the official Go SDK for interacting with 1inch Network APIs. It provides type-safe Go bindings for all 1inch DEX aggregation, limit orders, Fusion swaps, and various Web3 data services.

**Module**: `github.com/1inch/1inch-sdk-go/v5`  
**Go Version**: 1.22+ (toolchain 1.23.0)  
**License**: MIT  
**Version**: git tags, mirrored in `internal/version/version.go` (owned by the release workflow; never edit by hand)

## Project Structure

```
/
├── sdk-clients/          # Main SDK client implementations (one per API)
│   ├── aggregation/      # DEX aggregation (swap) API client
│   ├── fusion/           # Fusion swap (gasless) API client
│   ├── fusionplus/       # Fusion+ cross-chain swap client
│   ├── orderbook/        # Limit order protocol client
│   ├── balances/         # Token balance/allowance queries
│   ├── gasprices/        # Gas price oracle
│   ├── history/          # Transaction history
│   ├── nft/              # NFT data queries
│   ├── portfolio/        # Portfolio tracking
│   ├── spotprices/       # Token spot prices
│   ├── tokens/           # Token information
│   ├── traces/           # Transaction traces
│   ├── txbroadcast/      # Transaction broadcasting
│   └── web3/             # Web3 RPC calls
├── common/               # Shared interfaces and types
│   └── fusionorder/      # Shared types/utilities for fusion and fusionplus
├── constants/            # Chain IDs, contract addresses, ABIs
├── internal/             # Internal utilities (not exported)
│   ├── http-executor/    # HTTP client implementation
│   ├── web3-provider/    # Ethereum wallet/provider implementation
│   │   └── multicall/    # Multicall contract support
│   ├── transaction-builder/  # Tx construction utilities
│   ├── validate/         # Parameter validation functions (generic typed)
│   ├── bigint/           # Big integer utilities
│   ├── bytesbuilder/     # Byte buffer construction
│   ├── bytesiterator/    # Sequential byte parsing
│   ├── hexadecimal/      # Hex string utilities
│   ├── keccak/           # Keccak hashing
│   ├── random-number-generation/ # Cryptographic random number generation
│   └── times/            # Time utilities
├── codegen/              # OpenAPI spec files and type generation
│   ├── openapi/          # OpenAPI JSON specs for each API
│   ├── generate.go       # Type generation pipeline (Go)
│   ├── transforms.go     # In-memory spec corrections applied before generation
│   ├── cmd/generate-types # CLI entry point (go run ./codegen/cmd/generate-types)
│   └── mapping.json      # Operation ID mappings
└── .github/workflows/    # CI/CD (pr.yml, release.yml)
```

## Key Commands

```bash
# Run all unit tests
make test

# Run linter (golangci-lint v2.10.1, same version as CI)
make lint

# Format code
make fmt

# Generate types from OpenAPI specs (run from repo root)
make codegen-types

# Get dependencies
make get
```

## Post-Change Verification

After making changes, run these checks to ensure code quality:

```bash
# 1. Build all packages (catch compile errors)
go build ./...

# 2. Run static analysis (catch common issues)
go vet ./...

# 3. Run linter with import formatting check
golangci-lint run --enable goimports

# 4. Run all tests
go test ./...

# Or run tests with race detection (slower but catches race conditions)
go test -race ./...
```

To auto-fix import formatting issues:
```bash
goimports -w .
```

## Architecture Patterns

### Client Pattern
Each SDK client follows a consistent pattern:

```go
// 1. Create configuration
config, err := aggregation.NewConfiguration(aggregation.ConfigurationParams{
    NodeUrl:    nodeUrl,       // Ethereum RPC endpoint
    PrivateKey: privateKey,    // Wallet private key (64 hex chars, no 0x)
    ChainId:    constants.EthereumChainId,
    ApiUrl:     "https://api.1inch.com",
    ApiKey:     devPortalToken,  // 1inch Dev Portal API key
})

// 2. Create client
client, err := aggregation.NewClient(config)

// 3. Use API methods
quote, err := client.GetQuote(ctx, aggregation.GetQuoteParams{...})
```

### Two Client Variants
- **Full Client** (`NewClient`): Includes wallet + API access for on-chain operations
- **API-Only Client** (`NewClientOnlyAPI`): API access without wallet (read-only operations)

### Core Interfaces (in `common/`)

```go
// HttpExecutor - HTTP request execution
type HttpExecutor interface {
    ExecuteRequest(ctx context.Context, payload RequestPayload, v any) error
}

// Wallet - Ethereum wallet operations
type Wallet interface {
    Call(ctx context.Context, contractAddress Address, callData []byte) ([]byte, error)
    Nonce(ctx context.Context) (uint64, error)
    Address() Address
    Sign(tx *types.Transaction) (*types.Transaction, error)
    SignBytes(data []byte) ([]byte, error)
    BroadcastTransaction(ctx context.Context, tx *types.Transaction) error
    // ... permit methods, gas methods
}

// TransactionBuilder - Fluent transaction construction
type TransactionBuilder interface {
    SetData([]byte) TransactionBuilder
    SetNonce(uint64) TransactionBuilder
    SetGas(uint64) TransactionBuilder
    SetTo(*Address) TransactionBuilder
    SetValue(*big.Int) TransactionBuilder
    Build(context.Context) (*types.Transaction, error)
}
```

### Validation Pattern
Each API client has a `validation.go` with `Validate()` methods on params. The validation framework uses Go generics for compile-time type safety:

```go
func (params *GetSwapParams) Validate() error {
    var validationErrors []error
    validationErrors = validate.Parameter(params.Src, "src", validate.CheckEthereumAddressRequired, validationErrors)
    // ... more validations
    return validate.ConsolidateValidationErrors(validationErrors)
}
```

`validate.Parameter[T]` is generic — the compiler infers the type from the parameter and ensures the check function signature matches. Check functions take typed parameters (e.g., `CheckEthereumAddress(value string, ...)`) rather than `interface{}`.

Common validators in `internal/validate/`:
- `CheckEthereumAddressRequired` / `CheckEthereumAddress` (string)
- `CheckBigIntRequired` / `CheckBigInt` (string)
- `CheckSlippageRequired` / `CheckSlippage` (float32, 0.01-50 range)
- `CheckPrivateKeyRequired` / `CheckPrivateKey` (string, 64 hex chars)
- `CheckChainIdIntRequired` / `CheckChainIdInt` (int)

## Type Generation

Types are auto-generated from OpenAPI specs by the Go pipeline in `codegen/`:

1. OpenAPI specs live in `codegen/openapi/*-openapi.json`
2. Run `make codegen-types` from the repo root (or `go run ./codegen/cmd/generate-types`)
3. Generated files: `sdk-clients/{package}/{package}_types.gen.go`

The pipeline applies in-memory corrections to each spec (see `codegen/transforms.go` and the per-spec override table in `codegen/overrides.go`) before invoking a pinned `oapi-codegen` via `go run module@version`; the committed spec files are never modified — they are untouched copies of the upstream documents. The pipeline's behavior is pinned by characterization tests in `codegen/codegen_test.go` — the committed `*_types.gen.go` files must be reproducible byte-for-byte, so any intentional pipeline change requires regenerating and committing the types alongside it.

### Refreshing Specs from the Dev Portal

```bash
DEV_PORTAL_TOKEN=... make codegen-fetch-specs   # rewrite local spec copies
git diff codegen/openapi                        # review upstream changes
make codegen-types                              # regenerate types
go test ./codegen                               # re-pin the output
```

Sources live in `specSources` in `codegen/fetch.go`. Fetched specs are validated against the transform pipeline at fetch time, so upstream drift that breaks an override fails immediately with a pointer to `codegen/overrides.go`. **Never hand-edit files in `codegen/openapi/`** — fix type bugs in the override table instead; CI enforces this by hashing every spec against `codegen/specs.lock.json`.

### Spec Provenance and Drift Detection

`codegen/specs.lock.json` records each spec's source URL, upstream `info.version`, content hash, and fetch time — tying the generated code to a specific upstream snapshot (generated code ⇔ specs via the byte-for-byte tests, specs ⇔ upstream via the lock). The fetch tool maintains it; `fetch-specs -seed` rebuilds it from local copies (bootstrap/repair only).

The `spec-drift.yml` workflow runs weekly (and via manual dispatch, requires the `DEV_PORTAL_TOKEN` repo secret): it fetches the live specs and, when anything changed, regenerates the types, runs the tests, and opens an automated PR (`automation/spec-drift` branch) with the diff and updated lock — flagging in the PR body if regeneration or tests failed.

**DO NOT manually edit `*_types.gen.go` files** - they are overwritten by codegen.

Extended types (manual additions) go in `*_types_extended.go` files.

## Supported Chains

Defined in `constants/chains.go`:
```go
EthereumChainId  = 1
PolygonChainId   = 137
BscChainId       = 56
ArbitrumChainId  = 42161
OptimismChainId  = 10
AvalancheChainId = 43114
GnosisChainId    = 100
FantomChainId    = 250
BaseChainId      = 8453
ZkSyncEraChainId = 324  // Limited support
AuroraChainId    = 1313161554
KlaytnChainId    = 8217
```

## Contract Addresses

Key addresses in `constants/contracts.go`:
- `AggregationRouterV6` = `0x111111125421cA6dc452d289314280a0f8842A65` (all chains except zkSync)
- `NativeToken` = `0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE`
- SeriesNonceManager addresses per chain

## Environment Variables for Examples

```bash
WALLET_KEY=<64-char-hex-private-key>  # No 0x prefix
WALLET_ADDRESS=<your-address>
NODE_URL=<ethereum-rpc-url>
DEV_PORTAL_TOKEN=<1inch-api-key>
```

## Testing

- Unit tests use `github.com/stretchr/testify`
- Tests are in `*_test.go` files alongside source
- Run with `make test` or `go test -race ./...`

### Table-Driven Tests (Required Pattern)

All tests in this project **must** use the table-driven test pattern. This provides consistent structure, easier maintenance, and clear subtest naming.

```go
func TestFunctionName(t *testing.T) {
	tests := []struct {
		name        string
		input       InputType
		expected    OutputType
		expectError bool
		errorMsg    string
	}{
		{
			name:     "Valid input",
			input:    validInput,
			expected: expectedOutput,
		},
		{
			name:        "Invalid input",
			input:       invalidInput,
			expectError: true,
			errorMsg:    "expected error message",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			result, err := FunctionUnderTest(tc.input)
			if tc.expectError {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tc.errorMsg)
			} else {
				require.NoError(t, err)
				assert.Equal(t, tc.expected, result)
			}
		})
	}
}
```

Key conventions:
- Use `tests` as the slice variable name
- Use `tc` (test case) as the loop variable
- Always include a `name` field for clear subtest identification
- Use `t.Run(tc.name, ...)` to create subtests
- Use `require` for fatal assertions, `assert` for non-fatal

## CI/CD

- **PR Validation** (`.github/workflows/pr.yml`): Runs tests + golangci-lint on PRs, blocks manual edits to `internal/version/version.go`, and warns when code changes lack a CHANGELOG entry (their release notes would be auto-generated)
- **Release** (`.github/workflows/release.yml`): Manual dispatch with a patch/minor/major/prerelease picker. Stable releases write the new version into `internal/version/version.go`, roll the CHANGELOG `Unreleased` section into a dated heading, commit, tag that commit, and publish a GitHub release whose notes come from the CHANGELOG section (auto-generated when empty)

## Key Dependencies

- `github.com/ethereum/go-ethereum v1.14.13` - Ethereum client
- `github.com/google/go-querystring v1.1.0` - URL query encoding
- `github.com/oapi-codegen/runtime v1.1.1` - OpenAPI runtime
- `github.com/stretchr/testify v1.9.0` - Testing

## API Clients Summary

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `aggregation` | DEX swap aggregation | `GetQuote`, `GetSwap`, `GetApproveAllowance` |
| `fusion` | Gasless swaps | `GetQuote`, `PlaceOrder`, `GetOrderStatus` |
| `fusionplus` | Cross-chain gasless | `GetQuote`, `PlaceOrder`, `SubmitSecret` |
| `orderbook` | Limit orders | `CreateOrder`, `GetAllOrders` |
| `balances` | Token balances | `GetBalancesAndAllowances` |
| `gasprices` | Gas oracle | `GetGasPriceEIP1559`, `GetGasPriceLegacy` |
| `spotprices` | Token prices | `GetPricesForRequestedTokens` |
| `tokens` | Token info | `GetWhitelistedTokens`, `SearchTokenAllChains` |
| `portfolio` | Portfolio tracking | `GetCurrentValue`, `GetProfitAndLoss` |
| `history` | Tx history | `GetHistoryEventsByAddress` |
| `web3` | RPC proxy | `PerformRpcCall` |
| `txbroadcast` | Tx broadcasting | `BroadcastPublicTransaction` |
| `traces` | Tx traces | `GetTxTraceByNumberAndHash` |
| `nft` | NFT data | `GetNFTsByAddress` |

## Common Patterns

### Executing a Swap
```go
// 1. Get swap data
swapData, _ := client.GetSwap(ctx, aggregation.GetSwapParams{
    Src: "0x...", Dst: "0x...",
    Amount: "1000000", From: wallet.Address().Hex(),
    Slippage: 1,
})

// 2. Build transaction
tx, _ := client.TxBuilder.New().
    SetData(swapData.TxNormalized.Data).
    SetTo(&swapData.TxNormalized.To).
    SetGas(swapData.TxNormalized.Gas).
    SetValue(swapData.TxNormalized.Value).
    Build(ctx)

// 3. Sign and broadcast
signedTx, _ := client.Wallet.Sign(tx)
client.Wallet.BroadcastTransaction(ctx, signedTx)
```

### Fusion Order
```go
// 1. Get quote
quote, _ := client.GetQuote(ctx, fusion.QuoteParams{...})

// 2. Place order (signs and submits)
orderHash, _ := client.PlaceOrder(ctx, *quote, fusion.OrderParams{
    Preset: fusion.Fast,
    ...
}, client.Wallet)

// 3. Monitor status
status, _ := client.GetOrderStatus(ctx, orderHash)
```

## File Naming Conventions

- `client.go` - Client struct and constructor
- `api.go` - API method implementations
- `configuration.go` - Configuration structs/constructors
- `validation.go` - Parameter validation
- `*_types.gen.go` - Auto-generated types (DO NOT EDIT)
- `*_types_extended.go` - Manual type extensions
- `examples/` - Usage examples per operation

## Fusion Package Architecture

The `fusion`, `fusionplus`, and `fusionorder` packages share a layered architecture:

### Package Hierarchy
```
common/fusionorder/   # Shared types and utilities (base layer)
├── bps.go            # Basis points type and operations
├── interaction.go    # Order interaction encoding/decoding
├── whitelist.go      # Whitelist generation (GenerateWhitelist, GenerateWhitelistFromItems)
├── whitelist_utils.go # Whitelist helpers (CanExecuteAt, IsExclusiveResolver)
├── auction.go        # Auction details encoding
├── preset.go         # Preset configuration types
├── salt.go           # Order salt generation and hashing
└── ...

fusion/               # Fusion (single-chain gasless swaps)
├── Uses fusionorder types via aliases
├── Extension, ExtensionParams (fusion-specific)
└── SettlementPostInteractionData (fusion-specific encoding)

fusionplus/           # Fusion+ (cross-chain swaps)
├── Uses fusionorder types via aliases
├── Extension, ExtensionParamsPlus (fusionplus-specific)
├── EscrowExtension (cross-chain escrow data)
└── SettlementPostInteractionData (fusionplus-specific encoding)
```

### Naming Conventions

**Type Aliases**: Both `fusion` and `fusionplus` use type aliases to re-export shared types:
```go
// In fusion/fusion_types_extended.go
type Bps = fusionorder.Bps
type Interaction = fusionorder.Interaction
type TakingFeeInfo = fusionorder.TakingFeeInfo
type CustomPreset = fusionorder.CustomPreset
type CustomPresetPoint = fusionorder.CustomPresetPoint

// In fusionplus/fusionplus_types_extended.go  
type TakingFeeInfo = fusionorder.TakingFeeInfo
type CustomPreset = fusionorder.CustomPreset
type CustomPresetPoint = fusionorder.CustomPresetPoint
```

**Plus Suffix**: Avoid the `Plus` suffix. Because callers always reach these symbols package-qualified (`fusionplus.Extension`, never bare `Extension` next to `fusion.Extension`), the suffix adds nothing at the call site. The clean names are canonical; the old `*Plus` names are kept as `// Deprecated:` aliases/forwarders for source compatibility:
- `Extension` (was `ExtensionPlus`)
- `NewExtension()` (was `NewExtensionPlus()`)
- `CreateAuctionDetails()` (was `CreateAuctionDetailsPlus()`)

The one exception is `ExtensionParamsPlus`, which **must** keep its suffix: `EscrowExtensionParams` embeds both `fusion.ExtensionParams` and the fusionplus params type, so they need distinct field names. Renaming it to `ExtensionParams` is a hard compile error (duplicate embedded field).

**Variable Naming**: Match the package context:
- In `fusion`: `fusionExtension`, `fusionOrder`
- In `fusionplus`: `extensionPlus`, `auctionDetailsPlus`, `presetPlus`

### Shared Code

When a **function** is shared across `fusion` and `fusionplus`, it lives in `fusionorder`. Import and call it directly from `fusionorder` — do not create function re-export aliases in the leaf packages.

**Type aliases** (as shown above) are acceptable for commonly-used types to improve ergonomics for callers of the leaf packages.

### Encoding Differences

The packages have different binary encoding formats:
- **Fusion**: Auction details include a point count byte (`Encode()`)
- **FusionPlus**: Auction details omit the point count byte (`EncodeWithoutPointCount()`)

### Common Pitfalls to Avoid

1. **Don't duplicate functions** - If logic is identical, put it in `fusionorder` and import it directly
2. **Don't use `log.Fatalf`** - Always return errors properly
3. **Watch for case sensitivity** - Ethereum addresses are case-insensitive; use `strings.ToLower()` when comparing address halves
4. **Keep variable names consistent** - Use `*Plus` in fusionplus, not `*Fusion`

## Breaking Changes Documentation

When making breaking changes, update both files:
- `BREAKING_CHANGES.md` - Detailed migration guide with tables
- `CHANGELOG.md` - Summary for release notes

### Audience: External Library Consumers

Both files are written for users who import this library via `go get`. Content should be limited to changes that affect the **public API surface** — things that would cause a compile error, behavior change, or require a code update in a downstream project.

**Include:**
- Moved/renamed/removed exported types, functions, and constants
- Signature changes to public functions
- New public APIs (packages, functions, constants)
- Bug fixes that change observable behavior (e.g., HTTP method fix, `log.Fatalf` replaced with error returns)
- Error wrapping changes that affect `errors.Is`/`errors.As` behavior
- Deprecated symbols

**Exclude:**
- Internal file renames, deletions, or reorganization
- Changes to `internal/` packages (users cannot import these)
- Internal variable renames
- Internal implementation details (e.g., switching from manual bit shifting to a helper library)
- Removed non-Go files (markdown docs, audit reports) unless they are referenced by importers
- Internal performance optimizations (e.g., regex precompilation in internal packages)

## Notes for Development

1. **ABIs are embedded** via `//go:embed` in `constants/abis.go`
2. **BigInt amounts** are passed as strings to avoid overflow
3. **Transaction builder** auto-fetches nonce/gas if not set
4. **EIP-1559** support is automatic based on chain
5. **Permit1** support for gasless approvals on supported tokens
6. **API rate limits** - Use a valid Dev Portal API key
7. **Error handling** - API errors are JSON with `statusCode`, `error`, `description`
8. **No `log.Fatalf`** - Always return errors; `log.Fatalf` terminates the program
9. **Check for duplicate code** - Before adding a function, search if it exists elsewhere
10. **Test files should match source** - If `foo.go` is deleted, check if `foo_test.go` should be too
11. **Always run post-change verification** - See "Post-Change Verification" section above
