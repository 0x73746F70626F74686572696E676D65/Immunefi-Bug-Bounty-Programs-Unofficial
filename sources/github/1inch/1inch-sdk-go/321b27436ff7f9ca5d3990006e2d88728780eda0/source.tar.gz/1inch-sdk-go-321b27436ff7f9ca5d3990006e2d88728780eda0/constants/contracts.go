package constants

import (
	"fmt"
	"slices"
)

const AggregationRouterV6 = "0x111111125421cA6dc452d289314280a0f8842A65" // Contract address is identical for all chains except zkSync
const AggregationRouterV6Name = "1inch Aggregation Router"
const AggregationRouterV6VersionNumber = "6"

const Erc20ApproveGas = 45_000

// Permit2Address is the canonical Uniswap Permit2 contract, same address on all chains
// https://github.com/Uniswap/permit2
const Permit2Address = "0x000000000022d473030f116ddee9f6b43ac78ba3"

// Series Nonce Manager contract addresses are taken from limit-order-protocol/deployments

const SeriesNonceManagerArbitrum = "0xD7936052D1e096d48C81Ef3918F9Fd6384108480"
const SeriesNonceManagerAurora = "0x7F069df72b7A39bCE9806e3AfaF579E54D8CF2b9"
const SeriesNonceManagerAvalanche = "0x2EC255797FEF7669fA243509b7a599121148FFba"
const SeriesNonceManagerBase = "0xD9Cc0A957cAC93135596f98c20Fbaca8Bf515909"
const SeriesNonceManagerBsc = "0x58ce0e6ef670c9a05622f4188faa03a9e12ee2e4"
const SeriesNonceManagerEthereum = "0x303389f541ff2d620e42832f180a08e767b28e10"
const SeriesNonceManagerFantom = "0x7871769b3816b23dB12E83a482aAc35F1FD35D4B"
const SeriesNonceManagerGnosis = "0x11431a89893025D2a48dCA4EddC396f8C8117187"
const SeriesNonceManagerKlaytn = "0x7871769b3816b23dB12E83a482aAc35F1FD35D4B"
const SeriesNonceManagerOptimism = "0x32d12a25f539E341089050E2d26794F041fC9dF8"
const SeriesNonceManagerPolygon = "0xa5eb255EF45dFb48B5d133d08833DEF69871691D"

func Get1inchRouterFromChainId(chainId int) (string, error) {
	if !slices.Contains(ValidChainIds, chainId) {
		return "", fmt.Errorf("unsupported chain ID: %d", chainId)
	}
	if chainId == ZkSyncEraChainId {
		return "", fmt.Errorf("unsupported: zkSync for chain %d", chainId)
	}
	return AggregationRouterV6, nil
}

func GetSeriesNonceManagerFromChainId(chainId int) (string, error) {
	switch chainId {
	case ArbitrumChainId:
		return SeriesNonceManagerArbitrum, nil
	case AuroraChainId:
		return SeriesNonceManagerAurora, nil
	case AvalancheChainId:
		return SeriesNonceManagerAvalanche, nil
	case BaseChainId:
		return SeriesNonceManagerBase, nil
	case BscChainId:
		return SeriesNonceManagerBsc, nil
	case EthereumChainId:
		return SeriesNonceManagerEthereum, nil
	case FantomChainId:
		return SeriesNonceManagerFantom, nil
	case GnosisChainId:
		return SeriesNonceManagerGnosis, nil
	case KlaytnChainId:
		return SeriesNonceManagerKlaytn, nil
	case OptimismChainId:
		return SeriesNonceManagerOptimism, nil
	case PolygonChainId:
		return SeriesNonceManagerPolygon, nil
	case ZkSyncEraChainId:
		return "", fmt.Errorf("zksync not currently supported")
	default:
		return "", fmt.Errorf("unsupported chain ID: %d", chainId)
	}
}
