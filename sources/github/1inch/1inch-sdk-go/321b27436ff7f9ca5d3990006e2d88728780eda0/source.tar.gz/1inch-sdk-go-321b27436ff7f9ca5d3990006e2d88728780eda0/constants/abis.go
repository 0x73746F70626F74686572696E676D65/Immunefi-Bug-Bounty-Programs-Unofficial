package constants

import _ "embed"

//go:embed abi/erc20.abi.json
var Erc20ABI string

//go:embed abi/seriesNonceManager.abi.json
var SeriesNonceManagerABI string

//go:embed abi/aggregationRouterV6.abi.json
var AggregationRouterV6ABI string
