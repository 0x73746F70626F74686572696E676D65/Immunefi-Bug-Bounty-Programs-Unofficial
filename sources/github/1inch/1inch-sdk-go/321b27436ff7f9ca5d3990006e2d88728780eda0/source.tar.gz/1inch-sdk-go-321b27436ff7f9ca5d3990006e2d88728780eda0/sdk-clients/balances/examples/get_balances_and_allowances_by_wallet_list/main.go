package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/1inch/1inch-sdk-go/v5/constants"
	"github.com/1inch/1inch-sdk-go/v5/sdk-clients/balances"
)

var (
	devPortalToken = os.Getenv("DEV_PORTAL_TOKEN")
)

const (
	secondaryWalletAddress = "0x28C6c06298d514Db089934071355E5743bf21d60"

	spenderInch = "0x111111125421ca6dc452d289314280a0f8842a65"
)

func main() {
	if devPortalToken == "" {
		log.Fatal("set DEV_PORTAL_TOKEN to run this example")
	}

	config, err := balances.NewConfiguration(balances.ConfigurationParams{
		ChainId: constants.EthereumChainId,
		ApiUrl:  "https://api.1inch.com",
		ApiKey:  devPortalToken,
	})
	if err != nil {
		log.Fatalf("failed to create configuration: %v", err)
	}

	client, err := balances.NewClient(config)
	if err != nil {
		log.Fatalf("failed to create client: %v", err)
	}

	ctx := context.Background()

	response, err := client.GetBalancesAndAllowancesByWalletAddress(ctx, balances.BalancesAndAllowancesByWalletAddressParams{
		Wallet:  secondaryWalletAddress,
		Spender: spenderInch,
	})
	if err != nil {
		log.Fatalf("failed to get balances and allowances by wallet address list: %v", err)
	}

	responseIndented, err := json.MarshalIndent(response, "", "  ")
	if err != nil {
		log.Fatalf("failed to marshal response: %v", err)
	}

	fmt.Printf("GetBalancesAndAllowancesByWalletAddressList: %s\n", responseIndented)
}
