package orderbook

import (
	"strings"

	"github.com/1inch/1inch-sdk-go/v5/constants"
	"github.com/1inch/1inch-sdk-go/v5/internal/validate"
)

func (params *CreateOrderParams) Validate() error {
	var validationErrors []error
	// validationErrors = validate.Parameter(params.SeriesNonce, "seriesNonce", validate.CheckBigIntRequired, validationErrors) // TODO All other places expect a string value for raw request parameters, but this value will always come in as a big.Int because of the onchain nature of retrieving it
	validationErrors = validate.Parameter(params.Maker, "maker", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.MakerAsset, "makerAsset", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.TakerAsset, "takerAsset", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.TakingAmount, "takingAmount", validate.CheckBigIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.MakingAmount, "makingAmount", validate.CheckBigIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.Taker, "taker", validate.CheckEthereumAddressRequired, validationErrors)
	if strings.EqualFold(params.MakerAsset, params.TakerAsset) && (params.MakerAsset != "" && params.TakerAsset != "") {
		validationErrors = append(validationErrors, validate.NewParameterCustomError("maker asset and taker asset cannot be the same"))
	}
	if strings.EqualFold(params.MakerAsset, constants.NativeToken) || strings.EqualFold(params.TakerAsset, constants.NativeToken) {
		validationErrors = append(validationErrors, validate.NewParameterCustomError("unsupported: native gas token as maker or taker asset"))
	}

	//TODO if an extension is present, then MakerTraits must also be marked for an extension in the order. Will be easy to do if Extension is changed to a pointer type

	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *GetOrdersByCreatorAddressParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.CreatorAddress, "creatorAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.Page, "page", validate.CheckPage, validationErrors)
	validationErrors = validate.Parameter(params.Limit, "limit", validate.CheckLimit, validationErrors)
	validationErrors = validate.Parameter(params.Statuses, "statuses", validate.CheckStatusesInts, validationErrors)
	validationErrors = validate.Parameter((string)(params.SortBy), "sortBy", validate.CheckSortBy, validationErrors)
	validationErrors = validate.Parameter(params.TakerAsset, "takerAsset", validate.CheckEthereumAddress, validationErrors)
	validationErrors = validate.Parameter(params.MakerAsset, "makerAsset", validate.CheckEthereumAddress, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *GetOrderParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.OrderHash, "orderHash", validate.CheckOrderHashRequired, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *GetAllOrdersParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.Page, "page", validate.CheckPage, validationErrors)
	validationErrors = validate.Parameter(params.Limit, "limit", validate.CheckLimit, validationErrors)
	validationErrors = validate.Parameter(params.Statuses, "statuses", validate.CheckStatusesInts, validationErrors)
	validationErrors = validate.Parameter((string)(params.SortBy), "sortBy", validate.CheckSortBy, validationErrors)
	validationErrors = validate.Parameter(params.TakerAsset, "takerAsset", validate.CheckEthereumAddress, validationErrors)
	validationErrors = validate.Parameter(params.MakerAsset, "makerAsset", validate.CheckEthereumAddress, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *GetFeeInfoParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.MakerAmount, "makerAmount", validate.CheckBigIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.MakerAsset, "makerAsset", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.TakerAmount, "takerAmount", validate.CheckBigIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.TakerAsset, "takerAsset", validate.CheckEthereumAddressRequired, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *GetOrderCountParams) Validate() error {
	var validationErrors []error
	// Convert []OrderStatus to []int for validation
	statusesAsInts := make([]int, len(params.Statuses))
	for i, s := range params.Statuses {
		statusesAsInts[i] = int(s)
	}
	validationErrors = validate.Parameter(statusesAsInts, "statuses", validate.CheckStatusesOrderStatus, validationErrors)
	validationErrors = validate.Parameter(params.MakerAsset, "makerAsset", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.TakerAsset, "takerAsset", validate.CheckEthereumAddressRequired, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}
