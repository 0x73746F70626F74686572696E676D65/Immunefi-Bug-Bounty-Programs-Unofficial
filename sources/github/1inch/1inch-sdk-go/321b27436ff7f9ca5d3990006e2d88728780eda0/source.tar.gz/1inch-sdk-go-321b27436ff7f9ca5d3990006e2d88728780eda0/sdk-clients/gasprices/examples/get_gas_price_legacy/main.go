package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/1inch/1inch-sdk-go/v5/constants"
	"github.com/1inch/1inch-sdk-go/v5/sdk-clients/gasprices"
)

var (
	devPortalToken = os.Getenv("DEV_PORTAL_TOKEN")
)

func main() {
	if devPortalToken == "" {
		log.Fatal("set DEV_PORTAL_TOKEN to run this example")
	}

	configLegacyChain, err := gasprices.NewConfiguration(gasprices.ConfigurationParams{
		ChainId: constants.AuroraChainId,
		ApiUrl:  "https://api.1inch.com",
		ApiKey:  devPortalToken,
	})
	if err != nil {
		log.Fatalf("failed to create configuration for legacy chain: %v", err)
	}

	clientLegacyChain, err := gasprices.NewClient(configLegacyChain)
	if err != nil {
		log.Fatalf("failed to create legacy client: %v", err)
	}

	ctx := context.Background()

	gasPriceLegacy, err := clientLegacyChain.GetGasPriceLegacy(ctx)
	if err != nil {
		log.Fatalf("failed to GetGasPriceLegacy: %v", err)
	}

	gasPriceLegacyIndented, err := json.MarshalIndent(gasPriceLegacy, "", "  ")
	if err != nil {
		log.Fatalf("failed to marshal gasPriceLegacy: %v", err)
	}

	fmt.Printf("GetGasPriceLegacy: %s\n", gasPriceLegacyIndented)
}
