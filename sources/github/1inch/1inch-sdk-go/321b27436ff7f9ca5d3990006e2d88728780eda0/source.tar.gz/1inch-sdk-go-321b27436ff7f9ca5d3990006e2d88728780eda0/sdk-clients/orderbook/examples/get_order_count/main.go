package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"github.com/1inch/1inch-sdk-go/v5/sdk-clients/orderbook"
)

var (
	devPortalToken = os.Getenv("DEV_PORTAL_TOKEN")
)

const (
	chainId = 8453
)

func main() {
	if devPortalToken == "" {
		log.Fatal("set DEV_PORTAL_TOKEN to run this example")
	}

	ctx := context.Background()

	config, err := orderbook.NewConfigurationAPI(chainId, "https://api.1inch.com", devPortalToken)
	if err != nil {
		log.Fatalf("failed to create configuration: %v", err)
	}
	client, err := orderbook.NewClientOnlyAPI(config)
	if err != nil {
		log.Fatalf("failed to create client: %v", err)
	}

	orderCount, err := client.GetOrderCount(ctx, orderbook.GetOrderCountParams{
		Statuses:   []orderbook.OrderStatus{orderbook.ValidOrders},
		MakerAsset: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
		TakerAsset: "0x4200000000000000000000000000000000000006",
	})
	if err != nil {
		log.Fatalf("failed to get order count: %v", err)
	}

	fmt.Printf("Order count: %v\n", orderCount.Count)
}
