package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/1inch/1inch-sdk-go/v5/constants"
	"github.com/1inch/1inch-sdk-go/v5/sdk-clients/aggregation"
)

var (
	devPortalToken = os.Getenv("DEV_PORTAL_TOKEN")
)

func main() {
	if devPortalToken == "" {
		log.Fatal("set DEV_PORTAL_TOKEN to run this example")
	}

	config, err := aggregation.NewConfigurationAPI(
		constants.PolygonChainId,
		"https://api.1inch.com",
		devPortalToken,
	)
	if err != nil {
		log.Fatalf("failed to create configuration: %v", err)
	}
	client, err := aggregation.NewClientOnlyAPI(config) // A light-weight client that is not capable of signing transactions
	if err != nil {
		log.Fatalf("failed to create client: %v", err)
	}
	ctx := context.Background()

	swapData, err := client.GetSwap(ctx, aggregation.GetSwapParams{
		Src:             "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",
		Dst:             "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270",
		Amount:          "1000",
		From:            "0x0000000000000000000000000000000000000000", // Change this to any wallet address
		Slippage:        1,
		DisableEstimate: true, // This stops the 1inch API from checking if the wallet is not able to make the swap
	})
	if err != nil {
		log.Fatalf("failed to get swap data: %v", err)
	}

	output, err := json.MarshalIndent(swapData, "", "  ")
	if err != nil {
		log.Fatalf("failed to marshal swap data: %v", err)
	}
	fmt.Printf("%s\n", string(output))
}
