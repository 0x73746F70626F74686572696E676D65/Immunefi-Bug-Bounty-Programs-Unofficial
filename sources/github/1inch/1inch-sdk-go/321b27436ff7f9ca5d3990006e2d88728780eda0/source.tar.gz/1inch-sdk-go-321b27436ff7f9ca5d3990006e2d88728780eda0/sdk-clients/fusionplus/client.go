package fusionplus

import (
	"github.com/1inch/1inch-sdk-go/v5/common"
)

type Client struct {
	api
	Wallet common.Wallet
}

type api struct {
	httpExecutor common.HttpExecutor
}

func NewClient(cfg *Configuration) (*Client, error) {
	c := Client{
		api:    cfg.APIConfiguration.API,
		Wallet: cfg.WalletConfiguration.Wallet,
	}
	return &c, nil
}
