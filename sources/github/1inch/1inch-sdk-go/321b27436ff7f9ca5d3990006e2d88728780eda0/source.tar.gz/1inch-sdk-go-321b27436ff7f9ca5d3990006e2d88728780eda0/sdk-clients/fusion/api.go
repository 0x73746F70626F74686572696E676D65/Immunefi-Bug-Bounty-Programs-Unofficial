package fusion

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/1inch/1inch-sdk-go/v5/common"
)

func (api *api) GetActiveOrders(ctx context.Context, params GetActiveOrdersParams) (*GetActiveOrdersOutput, error) {
	u := fmt.Sprintf("/fusion/orders/v2.0/%d/order/active", api.chainId)

	payload := common.RequestPayload{
		Method: "GET",
		Params: params,
		Path:   u,
		Body:   nil,
	}

	var response GetActiveOrdersOutput
	err := api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}

func (api *api) GetSettlementContract(ctx context.Context) (*SettlementAddressOutput, error) {
	u := fmt.Sprintf("/fusion/orders/v2.0/%d/order/settlement", api.chainId)

	payload := common.RequestPayload{
		Method: "GET",
		Params: nil,
		Path:   u,
		Body:   nil,
	}

	var response SettlementAddressOutput
	err := api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}

func (api *api) GetQuote(ctx context.Context, params QuoteParams) (*Quote, error) {
	u := fmt.Sprintf("/fusion/quoter/v2.0/%d/quote/receive", api.chainId)

	err := params.Validate()
	if err != nil {
		return nil, err
	}

	if !params.Surplus {
		return nil, fmt.Errorf("surplus parameter required for quote")
	}

	payload := common.RequestPayload{
		Method: "GET",
		Params: params,
		Path:   u,
		Body:   nil,
	}

	var response Quote
	err = api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}

func (api *api) GetQuoteWithCustomPreset(ctx context.Context, params CustomPresetQuoteParams, customPreset CustomPreset) (*Quote, error) {
	u := fmt.Sprintf("/fusion/quoter/v2.0/%d/quote/receive", api.chainId)

	err := params.Validate()
	if err != nil {
		return nil, err
	}

	err = customPreset.Validate()
	if err != nil {
		return nil, err
	}

	body, err := json.Marshal(customPreset)
	if err != nil {
		return nil, err
	}

	payload := common.RequestPayload{
		Method: "POST",
		Params: params,
		Path:   u,
		Body:   body,
	}

	var response Quote
	err = api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}

// PlaceOrder accepts a quote and submits it as a fusion order
func (api *api) PlaceOrder(ctx context.Context, fusionQuote Quote, orderParams OrderParams, wallet common.Wallet) (string, error) {
	u := fmt.Sprintf("/fusion/relayer/v2.0/%d/order/submit", api.chainId)

	err := orderParams.Validate()
	if err != nil {
		return "", err
	}

	_, limitOrder, err := CreateOrderData(fusionQuote, orderParams, wallet, api.chainId)
	if err != nil {
		return "", fmt.Errorf("failed to create order: %w", err)
	}

	signedOrder := SignedOrderInput{
		Extension: limitOrder.Data.Extension,
		Order: OrderInput{
			Maker:        limitOrder.Data.Maker,
			MakerAsset:   limitOrder.Data.MakerAsset,
			MakerTraits:  limitOrder.Data.MakerTraits,
			MakingAmount: limitOrder.Data.MakingAmount,
			Receiver:     limitOrder.Data.Receiver,
			Salt:         limitOrder.Data.Salt,
			TakerAsset:   limitOrder.Data.TakerAsset,
			TakingAmount: limitOrder.Data.TakingAmount,
		},
		QuoteId:   fusionQuote.QuoteId,
		Signature: limitOrder.Signature,
	}

	body, err := json.Marshal(signedOrder)
	if err != nil {
		return "", err
	}

	payload := common.RequestPayload{
		Method: "POST",
		Params: nil,
		Path:   u,
		Body:   body,
	}

	err = api.httpExecutor.ExecuteRequest(ctx, payload, nil)
	if err != nil {
		return "", err
	}

	return limitOrder.OrderHash, nil
}

func (api *api) PlaceOrders(ctx context.Context, body []PlaceOrderBody) (*Quote, error) {
	u := fmt.Sprintf("/fusion/relayer/v2.0/%d/order/submit/many", api.chainId)

	for _, order := range body {
		err := order.Validate()
		if err != nil {
			return nil, err
		}
	}

	bodyMarshaled, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}

	payload := common.RequestPayload{
		Method: "POST",
		Params: nil,
		Path:   u,
		Body:   bodyMarshaled,
	}

	var response Quote
	err = api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}

func (api *api) GetOrderStatus(ctx context.Context, orderHash string) (*OrderResponse, error) {
	u := fmt.Sprintf("/fusion/orders/v2.0/%d/order/status/%s", api.chainId, orderHash)

	payload := common.RequestPayload{
		Method: "GET",
		Params: nil,
		Path:   u,
		Body:   nil,
	}

	var response OrderResponse
	err := api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}
