package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/1inch/1inch-sdk-go/v5/constants"
	"github.com/1inch/1inch-sdk-go/v5/sdk-clients/tokens"
)

var (
	devPortalToken = os.Getenv("DEV_PORTAL_TOKEN")
)

func main() {
	if devPortalToken == "" {
		log.Fatal("set DEV_PORTAL_TOKEN to run this example")
	}

	config, err := tokens.NewConfiguration(tokens.ConfigurationParams{
		ChainId: constants.EthereumChainId,
		ApiUrl:  "https://api.1inch.com",
		ApiKey:  devPortalToken,
	})
	if err != nil {
		log.Fatalf("failed to create configuration: %v", err)
	}
	client, err := tokens.NewClient(config)
	if err != nil {
		log.Fatalf("failed to create client: %v", err)
	}
	ctx := context.Background()

	whitelistedTokens, err := client.GetWhitelistedTokens(ctx, tokens.GetWhitelistedTokensParams{})
	if err != nil {
		log.Fatalf("failed to search token: %v", err)
	}

	jsonTokens, err := json.MarshalIndent(whitelistedTokens, "", "  ")
	if err != nil {
		log.Fatalf("failed to marshal tokens: %v", err)
	}

	fmt.Println("Tokens:", string(jsonTokens))
}
