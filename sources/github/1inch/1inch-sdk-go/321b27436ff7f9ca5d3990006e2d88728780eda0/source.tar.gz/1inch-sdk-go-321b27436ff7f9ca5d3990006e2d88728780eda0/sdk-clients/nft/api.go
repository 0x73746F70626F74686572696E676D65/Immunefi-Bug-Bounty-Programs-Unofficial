package nft

import (
	"context"
	"strconv"
	"strings"

	"github.com/1inch/1inch-sdk-go/v5/common"
)

// GetSupportedChains Returns supported chains
func (api *api) GetSupportedChains(ctx context.Context) (*GetSupportedChainsResponse, error) {
	u := "/nft/v1/supportedchains"

	payload := common.RequestPayload{
		Method: "GET",
		Params: nil,
		Path:   u,
		Body:   nil,
	}

	var response GetSupportedChainsResponse
	err := api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}

// GetNFTsByAddress Get users NFTs by EVM address with supported chains
func (api *api) GetNFTsByAddress(ctx context.Context, params GetNftsByAddressParams) (*GetNFTsByAddressResponse, error) {
	u := "/nft/v1/byaddress"

	err := params.Validate()
	if err != nil {
		return nil, err
	}

	stringChainIds := make([]string, len(params.ChainIds))

	for i, id := range params.ChainIds {
		stringChainIds[i] = strconv.Itoa(int(id))
	}

	payload := common.RequestPayload{
		Method: "GET",
		Params: struct {
			ChainIds string `url:"chainIds" json:"chainIds"`
			Address  string `url:"address" json:"address"`
			Limit    int    `url:"limit,omitempty" json:"limit,omitempty"`
			Offset   int    `url:"offset,omitempty" json:"offset,omitempty"`
		}{
			ChainIds: strings.Join(stringChainIds, ","),
			Address:  params.Address,
			Limit:    params.Limit,
			Offset:   params.Offset,
		},
		Path: u,
		Body: nil,
	}

	var response GetNFTsByAddressResponse
	err = api.httpExecutor.ExecuteRequest(ctx, payload, &response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}
