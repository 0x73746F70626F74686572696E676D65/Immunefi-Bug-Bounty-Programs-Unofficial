package fusionplus

import (
	"fmt"

	"github.com/1inch/1inch-sdk-go/v5/constants"
	"github.com/1inch/1inch-sdk-go/v5/internal/validate"
)

func (params *GetActiveOrdersParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.Page, "Page", validate.CheckPage, validationErrors)
	validationErrors = validate.Parameter(params.Limit, "Limit", validate.CheckLimit, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *QuoteParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.SrcTokenAddress, "SrcTokenAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.DstTokenAddress, "DstTokenAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.WalletAddress, "WalletAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.SrcChain, "SrcChain", validate.CheckChainIdIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.DstChain, "DstChain", validate.CheckChainIdIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.Amount, "Amount", validate.CheckBigIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.Fee, "Fee", validate.CheckFeeBps, validationErrors)
	validationErrors = validate.Parameter(params.Permit, "Permit", validate.CheckPermitHash, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (params *CustomPresetQuoteParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(params.SrcTokenAddress, "SrcTokenAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.DstTokenAddress, "DstTokenAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.WalletAddress, "WalletAddress", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(params.SrcChain, "SrcChain", validate.CheckChainIdIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.DstChain, "DstChain", validate.CheckChainIdIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.Amount, "Amount", validate.CheckBigIntRequired, validationErrors)
	validationErrors = validate.Parameter(params.Fee, "Fee", validate.CheckFeeBps, validationErrors)
	validationErrors = validate.Parameter(params.Permit, "Permit", validate.CheckPermitHash, validationErrors)
	return validate.ConsolidateValidationErrors(validationErrors)
}

func (body *OrderParams) Validate() error {
	var validationErrors []error
	validationErrors = validate.Parameter(body.Receiver, "Receiver", validate.CheckEthereumAddressRequired, validationErrors)
	validationErrors = validate.Parameter(body.Permit, "Permit", validate.CheckPermitHash, validationErrors)
	validationErrors = validate.Parameter(body.Permit, "Permit", validate.CheckFillablePermit, validationErrors)
	if body.Preset == "" {
		validationErrors = append(validationErrors, validate.NewParameterCustomError(fmt.Sprintf("Preset is required. Pass in one of the Fusion library constants: %v", constants.ValidFusionPresets)))
	}
	return validate.ConsolidateValidationErrors(validationErrors)
}
