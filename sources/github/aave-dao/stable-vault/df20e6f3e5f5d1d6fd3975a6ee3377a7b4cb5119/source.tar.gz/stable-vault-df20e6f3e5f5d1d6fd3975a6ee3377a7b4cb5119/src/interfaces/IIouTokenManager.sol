// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

/// @title IIouTokenManager
/// @author Aave Labs
/// @notice Interface for the IOU token manager.
interface IIouTokenManager {
    /// @notice Emitted when IOU tokens are bridged to another chain.
    event TokensBridged(
        uint256 indexed destinationChainId, address indexed iouTokenRecipient, uint256 iouTokenAmountRay
    );

    /// @notice Emitted when previously locked IOU tokens are released back to a recipient (e.g. when a withdrawal
    /// request is cancelled).
    event LockedTokensReleased(address indexed to, uint256 amountRay);

    /// @notice Emitted when locked IOU tokens are burned (e.g. when a withdrawal request is finalised).
    event LockedTokensBurned(address indexed from, uint256 amountRay);

    /// @notice Emitted when IOU tokens are locked (e.g. when a user requests a withdrawal).
    event TokensLocked(address indexed from, uint256 amountRay);

    /// @notice Thrown when the amount of locked tokens is insufficient to burn or release.
    /// @custom:selector 0xb646ec7b
    error InsufficientLockedBalance();

    /// @notice Thrown when a function that should only be invoked on the Accounting chain is invoked on an Earning
    /// chain.
    /// @custom:selector 0x4f0475a7
    error OnlyAccountingChain();

    /// @notice Bridges the caller's IOU tokens to a destination chain. `msg.sender` is locked/burned and pays the
    /// bridge fee.
    /// @dev IOUs should be bridged via bridges which require finalization on the source chain. If IOUs are bridged and
    /// exchanged for assets on a destination, but the source chain reorgs, then a user would keep their IOUs and the
    /// assets withdrawn on the destination chain.
    /// @param destinationChainId The chain id of the chain to publish the message to.
    /// @param iouTokenRecipient The address to send the IOU tokens to on the destination chain.
    /// @param iouTokenAmountRay The amount of IOU tokens to bridge.
    /// @param bridgeAdapter The whitelisted bridge adapter to use for the message.
    /// @param payloadExecutionGasLimit Gas limit for the destination gateway call and everything it executes.
    /// @param bridgeAdapterData Any bridge adapter custom parameters that it may need to operate.
    function bridgeTokens(
        uint256 destinationChainId,
        address iouTokenRecipient,
        uint256 iouTokenAmountRay,
        address bridgeAdapter,
        uint256 payloadExecutionGasLimit,
        bytes calldata bridgeAdapterData
    ) external payable;

    /// @notice Mints tokens to the specified address (assumes this contract has mint privileges on the IOU token).
    /// @param to Address to mint the tokens to.
    /// @param amount Amount of tokens to mint.
    function mintTokens(address to, uint256 amount) external;

    /// @notice Burns tokens from the specified address (assumes this contract has burn privileges on the IOU token).
    /// @param from Address to burn the tokens from.
    /// @param amount Amount of tokens to burn.
    function burnTokens(address from, uint256 amount) external;

    /// @notice Burns locked tokens.
    /// @dev This is used only on the Accounting chain because tokens are only locked when bridging to an Earning chain.
    /// @param amount Amount of locked tokens to burn.
    function burnLockedTokens(uint256 amount) external;

    /// @notice Unlocks tokens and transfers them to the specified address.
    /// @dev This is used if IOU tokens are bridged back to the Accounting chain.
    /// @param to Address to send the unlocked IOU tokens to.
    /// @param amount Amount of IOU tokens to release.
    function releaseTokens(address to, uint256 amount) external;

    /// @notice Getter for the address of the IOU token.
    /// @return asset Address of the IOU token.
    function getAsset() external view returns (address);

    /// @notice Getter for the locked balance of the IOU token which has been bridged to Earning Chain(s).
    /// @dev Locked IOU tokens sit in the contract until they are burned due to an asset exchange on an Earning Chain or
    /// bridged back to the Accounting Chain.
    /// @dev This function should return 0 on Earning Chains as IOU tokens are not
    /// locked on Earning Chains.
    /// @return lockedBalance Locked balance of the IOU token.
    function getLockedBalance() external view returns (uint256);
}
