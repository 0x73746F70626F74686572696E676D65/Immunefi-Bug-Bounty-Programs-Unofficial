// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

/// @title IChainGateway
/// @author Aave Labs
/// @notice Interface for handling the communication between chains for bridging assets and data.
/// @dev Supports funds-only, data-only, and explicitly allowed funds-with-data bridge messages.
interface IChainGateway {
    enum MessageType {
        INVALID,
        BRIDGE_IOU_TOKEN,
        BURN_IOU_TOKEN,
        RETURN_FUNDS
    }

    enum DataOnlyBridgeAdapterMode {
        NOT_SUPPORTED,
        SEND_AND_RECEIVE,
        RECEIVE_ONLY
    }

    /// @notice The representation of a cross-chain message.
    /// @param messageType Type of message used to determine how to decode the `data` field.
    /// @param data Arbitrary data that may be required by the message type.
    struct CrossChainMessage {
        MessageType messageType;
        bytes data;
    }

    /// @notice The representation of a message to bridge IOU tokens to a destination chain.
    /// @dev For message type `BRIDGE_IOU_TOKEN`.
    /// @param recipient Address to send the IOU tokens to on the destination chain.
    /// @param amount Amount of IOU tokens to bridge.
    struct IouTokenBridgeMessage {
        address recipient;
        uint256 amount;
    }

    /// @notice The representation of a message to burn IOU tokens on a source chain.
    /// @dev For message type `BURN_IOU_TOKEN`.
    /// @param iouTokenAmountBurnedRay Amount of IOU tokens to burn.
    /// @param timestamp Timestamp from the source Earning Chain when the message is published.
    /// @param blockNumber Block number from the source Earning Chain when the message is published. Used to validate
    /// message freshness against Chain Balance Oracle snapshots.
    struct BurnIouTokenMessage {
        uint256 iouTokenAmountBurnedRay;
        uint256 timestamp;
        uint256 blockNumber;
    }

    /// @notice The representation of a message included when funds are returned to the Accounting Chain.
    /// @dev For message type `RETURN_FUNDS`.
    /// @param timestamp Timestamp from the source Earning Chain when the message is published.
    /// @param blockNumber Block number from the source Earning Chain when the message is published. Used to validate
    /// message freshness against Chain Balance Oracle snapshots.
    struct ReturnFundsMessage {
        uint256 timestamp;
        uint256 blockNumber;
    }

    /// @notice Emitted when a data-only bridge adapter is enabled for a destination chain.
    event DataOnlyBridgeAdapterAdded(uint256 chainId, address bridgeAdapter);

    /// @notice Emitted when a data-only bridge adapter removal is finalized for a destination chain.
    event DataOnlyBridgeAdapterRemovalFinalized(uint256 chainId, address bridgeAdapter);

    /// @notice Emitted when a data-only bridge adapter removal is initiated.
    /// @param removalId The ID that must be used to finalize the removal.
    event DataOnlyBridgeAdapterRemovalInitiated(uint256 chainId, address bridgeAdapter, bytes32 removalId);

    /// @notice Emitted when a funds bridge adapter is whitelisted for an asset and destination chain.
    event FundsBridgeAdapterAdded(address asset, uint256 chainId, address bridgeAdapter);

    /// @notice Emitted when a funds bridge adapter is removed from the whitelist for an asset and destination chain.
    event FundsBridgeAdapterRemoved(address asset, uint256 chainId, address bridgeAdapter);

    /// @notice Emitted when funds arrive on this chain from a source chain via a bridge adapter.
    event FundsReceived(address asset, uint256 amount, uint256 sourceChainId);

    /// @notice Emitted when funds are dispatched from this chain to a destination chain via a bridge adapter.
    event FundsSent(address asset, uint256 amount, uint256 destinationChainId);

    /// @notice Thrown when a bridge adapter is not found for a given asset and chain.
    /// @custom:selector 0xf7b1bf8e
    error AdapterNotFound();

    /// @notice Thrown when removal would leave a chain without a data-only sending route.
    /// @custom:selector 0xaa601040
    error CannotRemoveLastDataOnlyBridgeAdapter();

    /// @notice Thrown when a given message contains both funds and a data payload which is not allowed.
    /// @custom:selector 0x9d73280d
    error DataNotAllowedWithFunds();

    /// @notice Thrown when the removal ID does not match the stored ID.
    /// @custom:selector 0x5d6ce9ff
    error InvalidDataOnlyBridgeAdapterRemovalId(bytes32 actual, bytes32 expected);

    /// @notice Thrown when a message type does not match the expected message types, for a data-only message.
    /// @custom:selector 0x82d8a626
    error InvalidDataOnlyMessage();

    /// @notice Thrown when the message type for the arbitrary message data is not recognized.
    /// @custom:selector 0x5b60892f
    error InvalidMessageType();

    /// @notice Thrown when the caller is not the IOU token manager.
    /// @custom:selector 0x4084b1f2
    error OnlyIouTokenManager();

    /// @notice Thrown when a data-only bridge adapter is in an unexpected mode.
    /// @custom:selector 0x881393c3
    error UnexpectedDataOnlyBridgeAdapterMode(uint8 actual, uint8 expected);

    /// @notice Adds a funds bridge adapter to the gateway's set of whitelisted adapters.
    /// @dev The bridge adapter must not be already whitelisted for the asset and chain.
    /// @param asset The asset to add the bridge adapter for.
    /// @param chainId The chain id to add the bridge adapter for.
    /// @param bridgeAdapter The bridge adapter to add.
    function addFundsBridgeAdapter(address asset, uint256 chainId, address bridgeAdapter) external;

    /// @notice Removes a funds bridge adapter from the gateway's set of whitelisted adapters.
    /// @param asset The asset to remove the bridge adapter for.
    /// @param chainId The chain id to remove the bridge adapter for.
    /// @param bridgeAdapter The bridge adapter to remove.
    function removeFundsBridgeAdapter(address asset, uint256 chainId, address bridgeAdapter) external;

    /// @notice Adds a data-only bridge adapter for a destination chain.
    /// @param chainId The chain id to add the bridge adapter for.
    /// @param bridgeAdapter The bridge adapter to add.
    function addDataOnlyBridgeAdapter(uint256 chainId, address bridgeAdapter) external;

    /// @notice Initiates removal of a data-only bridge adapter.
    /// @dev The adapter remains valid for receiving in-flight messages but cannot be used for new sends.
    /// @param chainId The chain id the bridge adapter is registered for.
    /// @param bridgeAdapter The bridge adapter to remove.
    /// @return removalId The ID that must be used to finalize the removal.
    function initiateDataOnlyBridgeAdapterRemoval(uint256 chainId, address bridgeAdapter)
        external
        returns (bytes32 removalId);

    /// @notice Finalizes the removal of a data-only bridge adapter after its removal was initiated.
    /// @param chainId The chain id to remove the bridge adapter for.
    /// @param bridgeAdapter The bridge adapter to remove.
    /// @param removalId The ID returned when removal was initiated.
    function finalizeDataOnlyBridgeAdapterRemoval(uint256 chainId, address bridgeAdapter, bytes32 removalId) external;

    /// @notice Handle receiving of data and funds from a source chain.
    /// @param sourceChainId The chain from which the message was sent.
    /// @param asset The asset bridged over from a source chain.
    /// @param amount The amount of the asset bridged.
    /// @param data The data that was sent from a source chain.
    function receiveMessage(uint256 sourceChainId, address asset, uint256 amount, bytes memory data) external;

    /// @notice Sends a message to bridge IOU tokens to a destination chain.
    /// @param destinationChainId The chain id of the chain to publish the message to.
    /// @param iouTokenRecipient The address to send the IOU tokens to on the destination chain.
    /// @param iouTokenAmountRay The amount of IOU tokens to bridge.
    /// @param bridgeAdapter The whitelisted bridge adapter to use for the message.
    /// @param feePayer Address that will pay the bridge fee.
    /// @param payloadExecutionGasLimit Gas limit for the destination gateway call and everything it executes.
    /// @param bridgeAdapterData Any bridge adapter custom parameters that it may need to operate.
    function sendBridgeIouTokenMessageWithFeePayer(
        uint256 destinationChainId,
        address iouTokenRecipient,
        uint256 iouTokenAmountRay,
        address bridgeAdapter,
        address feePayer,
        uint256 payloadExecutionGasLimit,
        bytes calldata bridgeAdapterData
    ) external payable;

    /// @notice Returns the address of the IOU token manager.
    function getIouTokenManager() external view returns (address);
}
