// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

import {IChainBalanceOracle} from "src/interfaces/IChainBalanceOracle.sol";
import {IChainBalanceOracleAdapter} from "src/interfaces/IChainBalanceOracleAdapter.sol";
import {IEarningChainStateProvider} from "src/interfaces/IEarningChainStateProvider.sol";
import {EarningChainStateSchemaV1, SCHEMA_VERSION} from "src/periphery/EarningChainStateSchemaV1.sol";
import {Errors} from "src/types/Errors.sol";

// solhint-disable-next-line interface-starts-with-i
interface IBundleBaseAggregator {
    function latestBundle() external view returns (bytes memory bundle);

    function bundleDecimals() external view returns (uint8[] memory);

    function latestBundleTimestamp() external view returns (uint256);
}

/// @title ChainlinkChainBalanceOracleAdapter
/// @author Aave Labs
/// @notice Adapter for fetching a chain aggregated balance value from the Chainlink Aggregator.
/// @dev Queries the bundle aggregator proxy for the latest bundle containing data read from
/// IEarningChainStateProvider::getState().
contract ChainlinkChainBalanceOracleAdapter is IChainBalanceOracleAdapter {
    /// @dev Added to the heartbeat to account for potential publishing delays during periods of network congestion.
    uint256 constant PUBLISH_BUFFER_SECONDS = 90;

    uint256 immutable EARNING_CHAIN_ID;
    address immutable BUNDLE_AGGREGATOR_PROXY;
    uint256 immutable HEARTBEAT;

    /// @dev Constructor.
    /// @param earningChainId The chain ID of the Earning Chain this adapter reads data for.
    /// @param bundleAggregatorProxy The address of the Chainlink bundle aggregator proxy.
    /// @param heartbeat The expected heartbeat interval in seconds for staleness checks.
    constructor(uint256 earningChainId, address bundleAggregatorProxy, uint256 heartbeat) {
        require(bundleAggregatorProxy != address(0), Errors.ZeroAddress());
        require(earningChainId != 0 && earningChainId != block.chainid, Errors.InvalidParameter());
        require(heartbeat > 0, Errors.InvalidParameter());
        EARNING_CHAIN_ID = earningChainId;
        BUNDLE_AGGREGATOR_PROXY = bundleAggregatorProxy;
        HEARTBEAT = heartbeat;
    }

    /// @inheritdoc IChainBalanceOracleAdapter
    function getChainBalance(uint256 chainId)
        external
        view
        virtual
        override
        returns (IChainBalanceOracle.ChainBalance memory)
    {
        return _getChainBalance(chainId);
    }

    function _getChainBalance(uint256 chainId) internal view returns (IChainBalanceOracle.ChainBalance memory) {
        require(chainId == EARNING_CHAIN_ID, InvalidChainId(chainId));

        // Check bundle is not stale.
        bool isStale = false;
        uint256 bundleTimestamp = IBundleBaseAggregator(BUNDLE_AGGREGATOR_PROXY).latestBundleTimestamp();
        if (
            bundleTimestamp < block.timestamp && block.timestamp - bundleTimestamp >= HEARTBEAT + PUBLISH_BUFFER_SECONDS
        ) {
            isStale = true;
        }

        // Get balance snapshot from bundle.
        bytes memory bundle = IBundleBaseAggregator(BUNDLE_AGGREGATOR_PROXY).latestBundle();
        // No bundle has been published yet. Treat it as stale with a zero balance rather than reverting on decode,
        // so the consuming oracle conservatively contributes 0 for this chain.
        // Timestamps and block number are also 0 so they cannot be used for checks that require them to be up to date.
        if (bundle.length == 0) {
            return IChainBalanceOracle.ChainBalance({
                balanceRay: 0, lastUpdateTimestamp: 0, sourceChainTimestamp: 0, sourceChainBlockNumber: 0, isStale: true
            });
        }
        IEarningChainStateProvider.State memory state = abi.decode(bundle, (IEarningChainStateProvider.State));
        require(state.version == SCHEMA_VERSION, InvalidEarningChainStateVersion(SCHEMA_VERSION, state.version));
        EarningChainStateSchemaV1.BalanceSnapshot memory balanceSnapshot =
            abi.decode(state.data, (EarningChainStateSchemaV1.BalanceSnapshot));
        require(
            balanceSnapshot.chainId == EARNING_CHAIN_ID,
            InvalidSnapshotChainId(EARNING_CHAIN_ID, balanceSnapshot.chainId)
        );

        return IChainBalanceOracle.ChainBalance({
            balanceRay: balanceSnapshot.balanceRay,
            lastUpdateTimestamp: bundleTimestamp,
            sourceChainTimestamp: balanceSnapshot.timestamp,
            sourceChainBlockNumber: balanceSnapshot.blockNumber,
            isStale: isStale
        });
    }
}
