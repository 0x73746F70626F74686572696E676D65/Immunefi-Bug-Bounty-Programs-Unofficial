// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

import {AccessManaged} from "@openzeppelin/contracts/access/manager/AccessManaged.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {EfficientHashLib} from "@solady/utils/EfficientHashLib.sol";

import {IAccessManager} from "@openzeppelin/contracts/access/manager/IAccessManager.sol";

import {IWithdrawalExecutionPolicy} from "src/interfaces/IWithdrawalExecutionPolicy.sol";
import {RateLimitBucketLib} from "src/libraries/RateLimitBucketLib.sol";
import {GlobalRateLimitedPolicy} from "src/policies/base/GlobalRateLimitedPolicy.sol";
import {Constants} from "src/types/Constants.sol";
import {Errors} from "src/types/Errors.sol";

/// @title WithdrawalExecutionPolicy
/// @author Aave Labs
/// @notice Contract that enforces conditions during withdrawal executions (i.e. when exchanging IOUs for assets).
/// @dev This contract does not control who can withdraw, all users have the right to do so. Thus, the conditions
/// enforced by this contract must not prevent withdrawals, but rather ensure that permissionless withdrawals meet the
/// protocol's requirements.
/// @dev The current implementation applies a fee to: deter abuse of arbitrage opportunities through the protocol's
/// liquidity, discourage spam, and cover protocol operational costs (e.g. bridge or swap fees).
/// @dev The fee is capped per-asset at a basis-point limit (itself bounded at 10.00%). A whitelisted signer can sign
/// a personal fee denominated in RAY to charge an exact amount; this signed amount is clamped to the asset's bp cap,
/// with the cap amount rounded up in favor of the protocol.
/// @dev The redemption bucket is the global bucket inherited from `GlobalRateLimitedPolicy`. Amounts are already
/// RAY-denominated, so `_normalizeToGlobalBucketUnit` is overridden to a no-op.
contract WithdrawalExecutionPolicy is AccessManaged, EIP712, GlobalRateLimitedPolicy, IWithdrawalExecutionPolicy {
    /// @notice Signed personal fee data (decoded from WithdrawalExecutionIntent.policyData).
    /// @param personalFeeAmountRay The personal fee amount in RAY signed by a whitelisted signer. Used directly as
    /// the fee charged, capped by the asset-specific bp limit.
    /// @param nonce Unique nonce to prevent signature replay.
    /// @param deadline Timestamp after which the signature is no longer valid.
    /// @param signature The EIP-712 signature from a whitelisted signer.
    struct SignedFee {
        uint256 personalFeeAmountRay;
        uint256 nonce;
        uint256 deadline;
        bytes signature;
    }

    /// @notice Configuration for an asset-specific fee.
    /// @param feeBps Fee in basis points applied to the IOU quantity being exchanged for the asset.
    /// @param isSet Whether the fee is set (used for lookups).
    struct AssetFeeConfig {
        uint16 feeBps;
        bool isSet;
    }

    // EIP-712 typeHash:
    // keccak256("SignedFee(address user,address assetOut,uint256 iouAmountRay,uint256 personalFeeAmountRay,uint256
    // nonce,uint256 deadline)").
    bytes32 public constant SIGNED_FEE_TYPEHASH = 0x48a45dffc693559aeb550fa1a83c6ef4cd8fdc3d24f3678f575959a279c212e3;

    /// @dev The maximum fee in basis points that can be applied to a withdrawal. Set to 10.00%.
    uint16 internal constant FEE_CAP_BPS = 10_00;

    address internal immutable WITHDRAWAL_EXECUTION_POLICY_APPLIER;

    /// @dev Minimum redemption bucket capacity, guaranteeing a minimum exit throughput.
    uint128 internal immutable MIN_REDEMPTION_CAPACITY;

    /// @dev Minimum redemption bucket refill rate, guaranteeing a minimum exit throughput.
    uint128 internal immutable MIN_REDEMPTION_REFILL_RATE;

    /// @dev Fallback fee in basis points, used when neither a personal nor an asset-specific fee is available.
    uint16 internal _defaultFeeBps;

    mapping(address asset => AssetFeeConfig config) internal _assetFeeConfigs;

    mapping(address account => bool isSigner) internal _isSigner;

    mapping(address signer => mapping(uint256 nonce => bool used)) internal _wasNonceUsed;

    /// @notice Emitted when the asset fee in basis points is set.
    event AssetFeeBpsSet(address indexed asset, uint16 assetFeeBps, bool isSet);

    /// @notice Emitted when the default fee in basis points is set.
    event DefaultFeeBpsSet(uint16 defaultFeeBps);

    /// @notice Emitted when a nonce is marked as used, either by a successful application of the withdrawal-execution
    /// policy or by a nonce invalidation.
    event NonceUsed(address indexed signer, uint256 indexed nonce);

    /// @notice Emitted when the redemption bucket capacity is lowered.
    event RedemptionCapacityLowered(uint128 oldCapacity, uint128 newCapacity);

    /// @notice Emitted when the redemption bucket capacity is raised.
    event RedemptionCapacityRaised(uint128 oldCapacity, uint128 newCapacity);

    /// @notice Emitted when the redemption bucket refill rate is lowered.
    event RedemptionRefillRateLowered(uint128 oldRefillRate, uint128 newRefillRate);

    /// @notice Emitted when the redemption bucket refill rate is raised.
    event RedemptionRefillRateRaised(uint128 oldRefillRate, uint128 newRefillRate);

    /// @notice Emitted when an address is added or removed from the set of whitelisted signers.
    event SignerSet(address indexed signer, bool indexed whitelistAsSigner);

    /// @notice Thrown when lowering the redemption capacity below the immutable floor.
    /// @custom:selector 0xea1dc422
    error BelowMinRedemptionCapacity();

    /// @notice Thrown when lowering the redemption refill rate below the immutable floor.
    /// @custom:selector 0xec4ddd07
    error BelowMinRedemptionRefillRate();

    /// @notice Thrown when the signature deadline has passed.
    /// @custom:selector 0x1ab7da6b
    error DeadlineExpired();

    /// @notice Thrown when a recovered signer is not a whitelisted signer.
    /// @custom:selector 0x8baa579f
    error InvalidSignature();

    /// @notice Thrown when a signature nonce has already been consumed.
    /// @custom:selector 0x1fb09b80
    error NonceAlreadyUsed();

    modifier onlyWithdrawalExecutionPolicyApplier() {
        require(msg.sender == WITHDRAWAL_EXECUTION_POLICY_APPLIER, Errors.NotAuthorized());
        _;
    }

    /// @dev Constructor.
    /// @param accessManager The address of the IAccessManager contract used for handling access control.
    /// @param withdrawalExecutionPolicyApplier Address allowed to apply the withdrawal-execution policy.
    /// @param defaultFeeBps The initial default fee in basis points.
    /// @param minRedemptionCapacity Floor for the redemption bucket capacity. May be zero to let the admin(s)
    /// halt redemptions via `lowerRedemptionCapacity(0)` in an emergency.
    /// @param minRedemptionRefillRate Floor for the redemption bucket refill rate. May be zero to let the admin(s)
    /// halt the refill via `lowerRedemptionRefillRate(0)` in an emergency.
    constructor(
        address accessManager,
        address withdrawalExecutionPolicyApplier,
        uint16 defaultFeeBps,
        uint128 minRedemptionCapacity,
        uint128 minRedemptionRefillRate
    ) AccessManaged(accessManager) EIP712("WithdrawalExecutionPolicy", "1") {
        require(withdrawalExecutionPolicyApplier != address(0), Errors.ZeroAddress());
        IAccessManager(accessManager).canCall(address(0), address(0), bytes4(0));
        WITHDRAWAL_EXECUTION_POLICY_APPLIER = withdrawalExecutionPolicyApplier;
        MIN_REDEMPTION_CAPACITY = minRedemptionCapacity;
        MIN_REDEMPTION_REFILL_RATE = minRedemptionRefillRate;
        _setDefaultFeeBps(defaultFeeBps);
    }

    /// @inheritdoc IWithdrawalExecutionPolicy
    /// @dev Consumes the redemption bucket before any other state mutation. Reverts with
    /// `RateLimitBucketLib.RateLimited` if the requested amount exceeds the current bucket availability.
    function applyWithdrawalExecutionPolicy(WithdrawalExecutionIntent calldata withdrawalExecution)
        external
        override
        onlyWithdrawalExecutionPolicyApplier
        returns (uint256)
    {
        _consumeGlobalBucket(withdrawalExecution.assetOut, withdrawalExecution.iouAmountRay);

        (uint256 amountOutRay, address signer, uint256 nonce) = _previewWithdrawalExecutionPolicy(withdrawalExecution);
        if (signer != address(0)) {
            _markNonceAsUsed(signer, nonce);
        }
        emit WithdrawalExecutionPolicyApplied(
            withdrawalExecution.user, withdrawalExecution.assetOut, withdrawalExecution.iouAmountRay, amountOutRay
        );
        return amountOutRay;
    }

    /// @inheritdoc IWithdrawalExecutionPolicy
    /// @dev Returns the fee-adjusted output amount, or 0 if the redemption bucket would rate-limit the request at
    /// `block.timestamp`. Signature/deadline/nonce checks run before the bucket check so callers can still
    /// distinguish a malformed intent from a rate-limited one (a bare `0` would otherwise overload both cases).
    function previewWithdrawalExecutionPolicy(WithdrawalExecutionIntent calldata withdrawalExecution)
        external
        view
        override
        returns (uint256)
    {
        (uint256 amountOutRay,,) = _previewWithdrawalExecutionPolicy(withdrawalExecution);
        if (!_canConsumeGlobalBucket(withdrawalExecution.assetOut, withdrawalExecution.iouAmountRay)) {
            return 0;
        }
        return amountOutRay;
    }

    /// @notice Getter for the configuration for an asset-specific fee.
    /// @param asset Address of the asset to get the configuration for.
    /// @return assetFeeConfig Configuration for the asset-specific fee.
    function getAssetFeeConfig(address asset) external view returns (AssetFeeConfig memory) {
        return _assetFeeConfigs[asset];
    }

    /// @notice Getter for the fallback fee in basis points which is used when a personal fee or asset-specific fee is
    /// not available.
    /// @return defaultFeeBps Fallback fee in basis points.
    function getDefaultFeeBps() external view returns (uint16) {
        return _defaultFeeBps;
    }

    /// @notice Getter for whether an account is a signer.
    /// @param account Address of the account to check if it is a signer or not.
    /// @return bool True if the account is a signer, false otherwise.
    function isSigner(address account) external view returns (bool) {
        return _isSigner[account];
    }

    /// @notice Getter for whether a nonce has been consumed by a signer.
    /// @param signer Address of the signer to check.
    /// @param nonce The nonce to check.
    /// @return bool True if the nonce has been used, false otherwise.
    function wasNonceUsed(address signer, uint256 nonce) external view returns (bool) {
        return _wasNonceUsed[signer][nonce];
    }

    /// @notice Returns the current redemption bucket.
    function getRedemptionBucket() external view returns (RateLimitBucketLib.Bucket memory) {
        return _globalBucketStorage();
    }

    /// @notice Returns the minimum redemption bucket capacity enforced by `lowerRedemptionCapacity`.
    function getMinRedemptionCapacity() external view returns (uint128) {
        return MIN_REDEMPTION_CAPACITY;
    }

    /// @notice Returns the minimum redemption bucket refill rate enforced by `lowerRedemptionRefillRate`.
    function getMinRedemptionRefillRate() external view returns (uint128) {
        return MIN_REDEMPTION_REFILL_RATE;
    }

    //////////////////////////////// RESTRICTED FUNCTIONS ////////////////////////////////

    /// @notice Sets the configuration for an asset-specific fee.
    /// @param asset Address of the asset to set the configuration for.
    /// @param newAssetFeeBps The fee in basis points applied to the IOU quantity being exchanged for the asset.
    /// @param isSet Whether the fee is set (used for lookups).
    function setAssetFeeBps(address asset, uint16 newAssetFeeBps, bool isSet) external restricted {
        require(asset != address(0), Errors.ZeroAddress());
        // We don't check for new asset fee being less than the default fee because maybe we want some specific asset to
        // have a higher fee than the default fee.
        require(newAssetFeeBps <= FEE_CAP_BPS, Errors.InvalidParameter());
        if (!isSet) {
            require(newAssetFeeBps == 0, Errors.InvalidParameter());
        }
        _assetFeeConfigs[asset].feeBps = newAssetFeeBps;
        _assetFeeConfigs[asset].isSet = isSet;
        emit AssetFeeBpsSet(asset, newAssetFeeBps, isSet);
    }

    /// @notice Sets the fallback fee in basis points which is used when a personal fee or asset-specific fee is not
    /// available.
    /// @param newDefaultFeeBps The fallback fee in basis points applied to the IOU quantity being exchanged when no
    /// personal or asset-specific fee is configured.
    function setDefaultFeeBps(uint16 newDefaultFeeBps) external restricted {
        _setDefaultFeeBps(newDefaultFeeBps);
    }

    /// @notice Adds a signer to the set of trusted signers that can sign personal fees.
    /// @param signer Address of the signer to add.
    function addSigner(address signer) external restricted {
        _setSigner({signer: signer, whitelistAsSigner: true});
    }

    /// @notice Removes a signer from the set of trusted signers that can sign personal fees.
    /// @param signer Address of the signer to remove.
    function removeSigner(address signer) external restricted {
        _setSigner({signer: signer, whitelistAsSigner: false});
    }

    /// @notice Allows a whitelisted signer to invalidate their own nonce.
    /// @dev Useful for cancelling a signed personal fee before it's used.
    /// @param signer The signer whose nonce to invalidate (must be msg.sender).
    /// @param nonce The nonce to invalidate.
    function invalidateNonce(address signer, uint256 nonce) external {
        require(msg.sender == signer, Errors.NotAuthorized());
        require(_isSigner[signer], Errors.NotAuthorized());
        require(_wasNonceUsed[signer][nonce] == false, NonceAlreadyUsed());
        _markNonceAsUsed(signer, nonce);
    }

    /// @notice Raises the redemption bucket capacity.
    /// @dev Cannot set below `MIN_REDEMPTION_CAPACITY`.
    /// @dev Starting with a full bucket, a caller could extract up to `2 * capacity` over a
    /// `capacity / refillRate`-second interval. Set `capacity` accordingly.
    function raiseRedemptionCapacity(uint128 newCapacity) external restricted {
        require(newCapacity >= MIN_REDEMPTION_CAPACITY, BelowMinRedemptionCapacity());
        emit RedemptionCapacityRaised(_raiseGlobalBucketCapacity(newCapacity), newCapacity);
    }

    /// @notice Lowers the redemption bucket capacity. Cannot drop below `MIN_REDEMPTION_CAPACITY`.
    function lowerRedemptionCapacity(uint128 newCapacity) external restricted {
        require(newCapacity >= MIN_REDEMPTION_CAPACITY, BelowMinRedemptionCapacity());
        emit RedemptionCapacityLowered(_lowerGlobalBucketCapacity(newCapacity), newCapacity);
    }

    /// @notice Raises the redemption bucket refill rate.
    /// @dev Cannot set below `MIN_REDEMPTION_REFILL_RATE`.
    function raiseRedemptionRefillRate(uint128 newRefillRate) external restricted {
        require(newRefillRate >= MIN_REDEMPTION_REFILL_RATE, BelowMinRedemptionRefillRate());
        emit RedemptionRefillRateRaised(_raiseGlobalBucketRefillRate(newRefillRate), newRefillRate);
    }

    /// @notice Lowers the redemption bucket refill rate. Cannot drop below `MIN_REDEMPTION_REFILL_RATE`.
    function lowerRedemptionRefillRate(uint128 newRefillRate) external restricted {
        require(newRefillRate >= MIN_REDEMPTION_REFILL_RATE, BelowMinRedemptionRefillRate());
        emit RedemptionRefillRateLowered(_lowerGlobalBucketRefillRate(newRefillRate), newRefillRate);
    }

    //////////////////////////////// INTERNAL FUNCTIONS ////////////////////////////////

    /// @dev Redemption amounts are already RAY-denominated (the global bucket's unit), so no conversion is needed.
    function _normalizeToGlobalBucketUnit(address, uint256 iouAmountRay) internal pure override returns (uint256) {
        return iouAmountRay;
    }

    function _setSigner(address signer, bool whitelistAsSigner) internal {
        _isSigner[signer] = whitelistAsSigner;
        emit SignerSet(signer, whitelistAsSigner);
    }

    /// @dev The fee charged is the signed `personalFeeAmountRay` when provided, capped at the asset-specific bp limit
    /// applied to `iouAmountRay` (rounded up in favor of the protocol). When no signed data is supplied, the capped
    /// amount itself is charged.
    /// @param withdrawalExecution The withdrawal-execution intent.
    /// @return amountOutRay The amount of assets the user would receive (in RAY) after the fee is applied.
    /// @return signer The address that signed the personal fee, or `address(0)` when no signed data was supplied.
    /// @return nonce The nonce from the signed personal fee (only meaningful when `signer != address(0)`).
    function _previewWithdrawalExecutionPolicy(WithdrawalExecutionIntent calldata withdrawalExecution)
        internal
        view
        returns (uint256 amountOutRay, address signer, uint256 nonce)
    {
        uint16 feeBps = _getAssetFeeBps(withdrawalExecution.assetOut);
        uint256 feeAmountToChargeRay =
            (withdrawalExecution.iouAmountRay * feeBps + Constants.MAX_BPS - 1) / Constants.MAX_BPS;
        if (withdrawalExecution.policyData.length > 0) {
            uint256 personalFeeAmountRay;
            (signer, nonce, personalFeeAmountRay) = _verifySignedFee(withdrawalExecution);
            if (personalFeeAmountRay < feeAmountToChargeRay) {
                feeAmountToChargeRay = personalFeeAmountRay;
            }
        }
        amountOutRay = withdrawalExecution.iouAmountRay - feeAmountToChargeRay;
    }

    function _markNonceAsUsed(address signer, uint256 nonce) internal {
        _wasNonceUsed[signer][nonce] = true;
        emit NonceUsed(signer, nonce);
    }

    /// @dev Verifies a signed personal fee and returns the signer, nonce, and personal fee amount.
    /// @return signer The address that signed the personal fee.
    /// @return nonce The nonce from the signed personal fee.
    /// @return personalFeeAmountRay The personal fee amount (in RAY) from the signed data.
    function _verifySignedFee(WithdrawalExecutionIntent calldata withdrawalExecution)
        internal
        view
        returns (address signer, uint256 nonce, uint256 personalFeeAmountRay)
    {
        SignedFee memory signedFee = abi.decode(withdrawalExecution.policyData, (SignedFee));

        require(signedFee.deadline >= block.timestamp, DeadlineExpired());

        signer = _recoverSigner(withdrawalExecution, signedFee);
        require(_isSigner[signer], InvalidSignature());
        require(!_wasNonceUsed[signer][signedFee.nonce], NonceAlreadyUsed());

        return (signer, signedFee.nonce, signedFee.personalFeeAmountRay);
    }

    /// @dev Recovers the signer address from the EIP-712 signature.
    function _recoverSigner(WithdrawalExecutionIntent calldata withdrawalExecution, SignedFee memory signedFee)
        internal
        view
        returns (address)
    {
        bytes32 structHash = EfficientHashLib.hash(
            abi.encode(
                SIGNED_FEE_TYPEHASH,
                withdrawalExecution.user,
                withdrawalExecution.assetOut,
                withdrawalExecution.iouAmountRay,
                signedFee.personalFeeAmountRay,
                signedFee.nonce,
                signedFee.deadline
            )
        );
        return ECDSA.recover(_hashTypedDataV4(structHash), signedFee.signature);
    }

    /// @dev Returns the fee for an asset (asset-specific or default fallback).
    function _getAssetFeeBps(address assetOut) internal view returns (uint16) {
        if (_assetFeeConfigs[assetOut].isSet) {
            return _assetFeeConfigs[assetOut].feeBps;
        } else {
            return _defaultFeeBps;
        }
    }

    function _setDefaultFeeBps(uint16 newDefaultFeeBps) internal {
        require(newDefaultFeeBps <= FEE_CAP_BPS, Errors.InvalidParameter());
        _defaultFeeBps = newDefaultFeeBps;
        emit DefaultFeeBpsSet(newDefaultFeeBps);
    }
}
