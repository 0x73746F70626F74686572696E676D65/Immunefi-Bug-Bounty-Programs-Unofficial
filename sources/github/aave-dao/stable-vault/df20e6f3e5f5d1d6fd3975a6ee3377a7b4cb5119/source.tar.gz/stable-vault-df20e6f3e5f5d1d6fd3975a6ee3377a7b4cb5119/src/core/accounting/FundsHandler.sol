// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

import {
    AccessManagedUpgradeable
} from "@openzeppelin/contracts-upgradeable/access/manager/AccessManagedUpgradeable.sol";
import {
    ReentrancyGuardTransientUpgradeable
} from "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardTransientUpgradeable.sol";
import {IAccessManager} from "@openzeppelin/contracts/access/manager/IAccessManager.sol";
import {EnumerableSet} from "lib/openzeppelin-contracts/contracts/utils/structs/EnumerableSet.sol";

import {LocalBalanceAggregator} from "src/core/LocalBalanceAggregator.sol";
import {IAccountingChainGateway} from "src/interfaces/IAccountingChainGateway.sol";
import {IAllocator} from "src/interfaces/IAllocator.sol";
import {IChainBalanceOracle} from "src/interfaces/IChainBalanceOracle.sol";
import {IFundsBridgingPolicy} from "src/interfaces/IFundsBridgingPolicy.sol";
import {IFundsHandler} from "src/interfaces/IFundsHandler.sol";
import {IPolicyRegistry} from "src/interfaces/IPolicyRegistry.sol";
import {AssetLib} from "src/libraries/AssetLib.sol";
import {MathLib} from "src/libraries/MathLib.sol";
import {RescuableNative} from "src/misc/RescuableNative.sol";
import {RescuableToken} from "src/misc/RescuableToken.sol";
import {TransferHelperClient} from "src/misc/TransferHelperClient.sol";
import {Errors} from "src/types/Errors.sol";

/// @title FundsHandler
/// @author Aave Labs
/// @notice Handles push/pull of funds across the system.
/// @custom:upgradeable
contract FundsHandler is
    AccessManagedUpgradeable,
    RescuableNative,
    RescuableToken,
    LocalBalanceAggregator,
    TransferHelperClient,
    ReentrancyGuardTransientUpgradeable,
    IFundsHandler
{
    using AssetLib for uint256;
    using MathLib for uint256;
    using EnumerableSet for EnumerableSet.UintSet;

    /// @custom:storage-location erc7201:aave.storage.FundsHandler
    struct FundsHandlerStorage {
        EnumerableSet.UintSet earningChainIds;
    }

    address internal immutable VAULT;
    address internal immutable GATEWAY;
    address internal immutable CHAIN_BALANCE_ORACLE;
    address internal immutable POLICY_REGISTRY;

    // keccak256("aave.stable-vault.FundsHandler.policy.bridge")
    bytes32 internal constant BRIDGE_POLICY_ID = 0xe8134dfa9ba78c8f4bc7215c2603da92d80f826e18cf8cf1673b973cae3e6165;

    // keccak256(abi.encode(uint256(keccak256("aave.storage.FundsHandler")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant STORAGE_SLOT_FUNDS_HANDLER =
        0xffa5bdc69644e89163c8759837db1aeb0b569037bb5259c74309b23147440c00;

    modifier onlyStableVault() {
        require(msg.sender == VAULT, OnlyStableVault());
        _;
    }

    modifier onlyGateway() {
        require(msg.sender == GATEWAY, Errors.OnlyGateway());
        _;
    }

    function $storage() private pure returns (FundsHandlerStorage storage _storage) {
        assembly {
            _storage.slot := STORAGE_SLOT_FUNDS_HANDLER
        }
    }

    /// @dev Constructor.
    /// @param stableVault The address of the StableVault contract, which triggers deposits and withdrawals.
    /// @param gateway The address of the Gateway contract to use for cross-chain communication.
    /// @param allocator The address of the Allocator contract to use for immediate liquidity management.
    /// @param priceOracle The address of the PriceOracle contract to use for pricing assets.
    /// @param transferHelper The address of the TransferHelper contract to use for minimizing the number of transfers.
    /// @param chainBalanceOracle The address of the ChainBalanceOracle contract to use for cross-chain balance queries.
    /// @param policyRegistry The address of the PolicyRegistry contract used to look up policies by ID.
    constructor(
        address stableVault,
        address gateway,
        address allocator,
        address priceOracle,
        address transferHelper,
        address chainBalanceOracle,
        address policyRegistry
    ) TransferHelperClient(transferHelper) LocalBalanceAggregator(allocator, priceOracle) {
        require(stableVault != address(0), Errors.ZeroAddress());
        require(gateway != address(0), Errors.ZeroAddress());
        require(chainBalanceOracle != address(0), Errors.ZeroAddress());
        require(policyRegistry != address(0), Errors.ZeroAddress());
        _disableInitializers();
        VAULT = stableVault;
        GATEWAY = gateway;
        CHAIN_BALANCE_ORACLE = chainBalanceOracle;
        POLICY_REGISTRY = policyRegistry;
    }

    /// @dev Initializer.
    /// @param accessManager The address of the IAccessManager contract used for handling access control.
    function initialize(address accessManager) external virtual initializer {
        __FundsHandler_init(accessManager);
    }

    function __FundsHandler_init(address accessManager) internal virtual onlyInitializing {
        IAccessManager(accessManager).canCall(address(0), address(0), bytes4(0));
        __AccessManaged_init(accessManager);
    }

    /// @notice Getter for the list of earning chain IDs.
    /// @return The list of earning chain IDs.
    function getEarningChainIds() external view returns (uint256[] memory) {
        return $storage().earningChainIds.values();
    }

    /// @inheritdoc IFundsHandler
    function getAggregatedBalance() external view override returns (uint256) {
        uint256 totalBalanceRay = _getLocalAggregatedBalance();
        uint256 earningChainCount = $storage().earningChainIds.length();
        for (uint256 i = 0; i < earningChainCount; i++) {
            totalBalanceRay += _getAdjustedEarningChainBalanceRay($storage().earningChainIds.at(i));
        }
        return totalBalanceRay;
    }

    /// @inheritdoc IFundsHandler
    function processDeposit(address asset, uint256 amount) external override onlyStableVault {
        require(amount > 0, Errors.ZeroAmount());
        IAllocator(ALLOCATOR).deposit(asset, amount);
    }

    /// @inheritdoc IFundsHandler
    function processWithdrawal(address asset, uint256 amount) external override onlyStableVault {
        require(amount > 0, Errors.ZeroAmount());
        _pullFundsFromImmediateLiquidity(asset, amount);
    }

    ///////////////////////////////////////////// ADMIN FUNCTIONS //////////////////////////////////////////////////////

    /// @inheritdoc IFundsHandler
    function addEarningChain(uint256 chainId) external override restricted {
        require(chainId != block.chainid && chainId != 0, Errors.InvalidDestinationChainId());
        // Reverts when the chain ID is not supported by the oracle, so that a registered chain can never make
        // `getAggregatedBalance` revert. The returned balance is intentionally discarded.
        IChainBalanceOracle(CHAIN_BALANCE_ORACLE).getChainBalance(chainId);
        require($storage().earningChainIds.add(chainId), ChainIdAlreadyPresent());
        emit EarningChainAdded(chainId);
    }

    /// @inheritdoc IFundsHandler
    function removeEarningChain(uint256 chainId) external override restricted {
        require($storage().earningChainIds.remove(chainId), ChainIdNotPresent());
        emit EarningChainRemoved(chainId);
    }

    //////////////////////////////////////////// MANAGER FUNCTIONS /////////////////////////////////////////////////////

    /// @inheritdoc IFundsHandler
    function pushFundsToChain(
        address asset,
        uint256 amount,
        uint256 chainId,
        address bridgeAdapter,
        uint256 receiverExecutionGasLimit,
        bytes calldata bridgeAdapterData,
        bytes calldata policyData
    ) external payable override restricted nonReentrant assertingTransferHelperBalanceFor(asset) {
        require(amount > 0, Errors.ZeroAmount());
        require($storage().earningChainIds.contains(chainId), Errors.InvalidDestinationChainId());

        _applyFundsBridgingPolicy(chainId, bridgeAdapter, asset, amount, policyData);

        // Pull funds from liquidity into the TransferHelper.
        _pullFundsFromImmediateLiquidity(asset, amount);

        IAccountingChainGateway(GATEWAY).sendPushFundsToChainMessage{value: msg.value}(
            asset, amount, chainId, bridgeAdapter, msg.sender, receiverExecutionGasLimit, bridgeAdapterData
        );
    }

    // Gateway Functions

    /// @inheritdoc IFundsHandler
    function fundsArrivedFromChainCallback(address asset, uint256 amount) external override onlyGateway {
        IAllocator(ALLOCATOR).deposit(asset, amount);
    }

    ////////////////////////////////////////////////// INTERNAL ////////////////////////////////////////////////////////

    function _pullFundsFromImmediateLiquidity(address asset, uint256 amount) internal {
        IAllocator(ALLOCATOR).withdraw(asset, amount);
    }

    function _applyFundsBridgingPolicy(
        uint256 destChainId,
        address bridgeAdapter,
        address asset,
        uint256 amount,
        bytes calldata policyData
    ) internal {
        address policy = IPolicyRegistry(POLICY_REGISTRY).getPolicy(BRIDGE_POLICY_ID);
        if (policy == address(0)) {
            return;
        }
        IFundsBridgingPolicy(policy)
            .applyFundsBridgingPolicy(
                IFundsBridgingPolicy.FundsBridgingIntent({
                caller: msg.sender,
                bridgeAdapter: bridgeAdapter,
                destChainId: destChainId,
                asset: asset,
                amount: amount,
                policyData: policyData
            })
            );
    }

    /// @dev Returns 0 when the chain balance is stale, grossly underestimating the balance.
    /// The staleness window is bounded by the oracle heartbeat + publish buffer.
    function _getAdjustedEarningChainBalanceRay(uint256 chainId) internal view returns (uint256) {
        IChainBalanceOracle.ChainBalance memory chainBalance =
            IChainBalanceOracle(CHAIN_BALANCE_ORACLE).getChainBalance(chainId);
        return chainBalance.isStale ? 0 : chainBalance.balanceRay;
    }

    function _beforeRescueTokens(
        address, // token
        uint256 // amount
    )
        internal
        virtual
        override
    {
        // Equivalent to adding the `restricted` modifier.
        _checkCanCall(_msgSender(), _msgData());
    }

    function _beforeRescueNative(uint256) internal virtual override {
        // Equivalent to adding the `restricted` modifier.
        _checkCanCall(_msgSender(), _msgData());
    }
}
