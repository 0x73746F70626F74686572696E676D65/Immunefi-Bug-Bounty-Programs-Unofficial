// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

import {
    AccessManagedUpgradeable
} from "@openzeppelin/contracts-upgradeable/access/manager/AccessManagedUpgradeable.sol";
import {IAccessManager} from "@openzeppelin/contracts/access/manager/IAccessManager.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {EnumerableSet} from "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";

import {IAssetRegistry} from "src/interfaces/IAssetRegistry.sol";
import {Multicall} from "src/misc/Multicall.sol";
import {Constants} from "src/types/Constants.sol";
import {Errors} from "src/types/Errors.sol";

/// @title AssetRegistry
/// @author Aave Labs
/// @notice AssetRegistry contract for managing asset configurations.
/// @dev Inherits from Multicall to allow disabling deposits for multiple assets in a single call.
/// @custom:upgradeable
contract AssetRegistry is AccessManagedUpgradeable, Multicall, IAssetRegistry {
    using EnumerableSet for EnumerableSet.AddressSet;

    /// @custom:storage-location erc7201:aave.storage.AssetRegistry
    struct AssetRegistryStorage {
        mapping(address asset => AssetConfig config) configByAsset;
        EnumerableSet.AddressSet assets;
        EnumerableSet.AddressSet trustedAssets;
    }

    // keccak256(abi.encode(uint256(keccak256("aave.storage.AssetRegistry")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant STORAGE_SLOT_ASSET_REGISTRY =
        0xe40dab217194b6f9bf5c5919f11bf88986c74d7e324e41f214286ca4657cc900;

    function $storage() private pure returns (AssetRegistryStorage storage _storage) {
        assembly {
            _storage.slot := STORAGE_SLOT_ASSET_REGISTRY
        }
    }

    /// @dev Constructor. Just disables initializers.
    constructor() {
        _disableInitializers();
    }

    /// @dev Initializer.
    /// @param accessManager The address of the IAccessManager contract used for handling access control.
    function initialize(address accessManager) external virtual initializer {
        __AssetRegistry_init(accessManager);
    }

    function __AssetRegistry_init(address accessManager) internal virtual onlyInitializing {
        IAccessManager(accessManager).canCall(address(0), address(0), bytes4(0));
        __AccessManaged_init(accessManager);
    }

    /// @inheritdoc IAssetRegistry
    function setAssetConfig(address asset, AssetConfig memory config) external override restricted {
        require(!_isAssetRegistered(asset), Errors.AddressAlreadyWhitelisted());
        // The system uses RAY Math (27 decimals), so we leave a 9-decimal place (27 - 18) margin for better precision.
        require(IERC20Metadata(asset).decimals() <= Constants.MAX_SUPPORTED_ASSET_DECIMALS, Errors.InvalidAsset(asset));
        $storage().configByAsset[asset] = config;
        require($storage().assets.add(asset), Errors.AddressAlreadyWhitelisted());
        require($storage().trustedAssets.add(asset), Errors.AlreadyTrusted());
        emit AssetConfigSet(asset, config);
    }

    /// @inheritdoc IAssetRegistry
    function disableAllocatorDeposits(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require($storage().configByAsset[asset].depositIntoAllocatorAllowed, AlreadyDisabled());
        $storage().configByAsset[asset].depositIntoAllocatorAllowed = false;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function disableSwapInput(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require($storage().configByAsset[asset].swapInputTokenAllowed, AlreadyDisabled());
        $storage().configByAsset[asset].swapInputTokenAllowed = false;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function disableSwapOutput(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require($storage().configByAsset[asset].swapOutputTokenAllowed, AlreadyDisabled());
        $storage().configByAsset[asset].swapOutputTokenAllowed = false;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function disableUserDeposits(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require($storage().configByAsset[asset].depositFromUserAllowed, AlreadyDisabled());
        $storage().configByAsset[asset].depositFromUserAllowed = false;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function enableAllocatorDeposits(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require(!$storage().configByAsset[asset].depositIntoAllocatorAllowed, AlreadyEnabled());
        $storage().configByAsset[asset].depositIntoAllocatorAllowed = true;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function enableSwapInput(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require(!$storage().configByAsset[asset].swapInputTokenAllowed, AlreadyEnabled());
        $storage().configByAsset[asset].swapInputTokenAllowed = true;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function enableSwapOutput(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require(_isAssetTrusted(asset), AssetNotTrusted(asset));
        require(!$storage().configByAsset[asset].swapOutputTokenAllowed, AlreadyEnabled());
        $storage().configByAsset[asset].swapOutputTokenAllowed = true;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function enableUserDeposits(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require(_isAssetTrusted(asset), AssetNotTrusted(asset));
        require(!$storage().configByAsset[asset].depositFromUserAllowed, AlreadyEnabled());
        $storage().configByAsset[asset].depositFromUserAllowed = true;
        emit AssetConfigSet(asset, $storage().configByAsset[asset]);
    }

    /// @inheritdoc IAssetRegistry
    function trustAsset(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require(!_isAssetTrusted(asset), Errors.AlreadyTrusted());
        require($storage().trustedAssets.add(asset), Errors.AlreadyTrusted());
        emit AssetTrusted(asset);
    }

    /// @inheritdoc IAssetRegistry
    function distrustAsset(address asset) external override restricted {
        require(_isAssetRegistered(asset), Errors.UnsupportedAsset(asset));
        require(_isAssetTrusted(asset), Errors.AlreadyDistrusted());
        require($storage().trustedAssets.remove(asset), Errors.AlreadyDistrusted());
        emit AssetDistrusted(asset);
        if (
            $storage().configByAsset[asset].depositFromUserAllowed
                || $storage().configByAsset[asset].swapOutputTokenAllowed
        ) {
            $storage().configByAsset[asset].depositFromUserAllowed = false;
            $storage().configByAsset[asset].swapOutputTokenAllowed = false;
            emit AssetConfigSet(asset, $storage().configByAsset[asset]);
        }
    }

    // ///////////////////////// GETTERS ////////////////////////////////

    /// @notice Getter for all registered assets (including distrusted).
    /// @return The list of all registered asset addresses.
    function getRegisteredAssets() external view returns (address[] memory) {
        return $storage().assets.values();
    }

    /// @notice Getter for the full configuration of an asset.
    /// @param asset Address of the asset to get the configuration for.
    /// @return The asset configuration struct.
    function getAssetConfig(address asset) external view returns (AssetConfig memory) {
        return $storage().configByAsset[asset];
    }

    /// @inheritdoc IAssetRegistry
    function getTrustedAssets() external view override returns (address[] memory) {
        return $storage().trustedAssets.values();
    }

    /// @inheritdoc IAssetRegistry
    function isAssetTrusted(address asset) external view override returns (bool) {
        return _isAssetTrusted(asset);
    }

    // /////////////////////// PERMISSION SPECIFIC GETTERS ////////////////////////////

    /// @inheritdoc IAssetRegistry
    function isAssetRegistered(address asset) external view override returns (bool) {
        return _isAssetRegistered(asset);
    }

    /// @inheritdoc IAssetRegistry
    function isDepositToAllocatorAllowed(address asset) external view override returns (bool) {
        return $storage().configByAsset[asset].depositIntoAllocatorAllowed;
    }

    /// @inheritdoc IAssetRegistry
    function isSwapInputAllowed(address asset) external view override returns (bool) {
        return $storage().configByAsset[asset].swapInputTokenAllowed;
    }

    /// @inheritdoc IAssetRegistry
    /// @dev Does not check if the asset is trusted because to enable swapping for an asset it must be trusted.
    /// @dev The state of asset distrusted, but swapping is still allowed, is not possible.
    function isSwapOutputAllowed(address asset) external view override returns (bool) {
        return $storage().configByAsset[asset].swapOutputTokenAllowed;
    }

    /// @inheritdoc IAssetRegistry
    /// @dev Does not check if the asset is trusted because to enable deposits for an asset it must be trusted.
    /// @dev The state of asset distrusted, but deposits are still allowed, is not possible.
    function isUserDepositAllowed(address asset) external view override returns (bool) {
        return $storage().configByAsset[asset].depositFromUserAllowed;
    }

    // ///////////////////////// INTERNAL FUNCTIONS ////////////////////////////////

    function _isAssetRegistered(address asset) internal view returns (bool) {
        return $storage().assets.contains(asset);
    }

    function _isAssetTrusted(address asset) internal view returns (bool) {
        return $storage().trustedAssets.contains(asset);
    }
}
