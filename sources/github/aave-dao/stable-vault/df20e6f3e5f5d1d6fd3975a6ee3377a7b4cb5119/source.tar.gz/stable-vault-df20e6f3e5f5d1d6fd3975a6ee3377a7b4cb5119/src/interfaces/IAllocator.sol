// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

/// @title IAllocator
/// @author Aave Labs
/// @notice Interface for the Allocator contract.
interface IAllocator {
    /// @notice The representation of an asset balance.
    /// @param asset Address of the asset.
    /// @param amount Amount of the asset.
    struct AllocatorBalance {
        address asset;
        uint256 amount;
    }

    /// @notice The parameters for a deallocation.
    /// @param asset Address of the asset to deallocate.
    /// @param strategy Address of the strategy to deallocate from.
    /// @param amount Amount of the asset to deallocate (zero amount indicates max deallocation of `asset` from
    /// `strategy`).
    struct DeallocationParams {
        address asset;
        address strategy;
        uint256 amount;
    }

    /// @notice The parameters for a swap.
    /// @param assetIn Address of the asset to swap from.
    /// @param amountIn Amount of the asset to swap from.
    /// @param assetOut Address of the asset to swap to.
    /// @param swapper Address of the swapper contract.
    /// @param data Custom data that may be required by the swapper to execute the swap.
    struct SwapParams {
        address assetIn;
        uint256 amountIn;
        address assetOut;
        address swapper;
        bytes data;
    }

    /// @notice The parameters for an allocation.
    /// @param asset Address of the asset to allocate.
    /// @param strategy Address of the strategy to allocate to.
    /// @param amount Amount of the asset to allocate (zero amount indicates max allocation of `asset` balance to
    /// `strategy`).
    struct AllocationParams {
        address asset;
        address strategy;
        uint256 amount;
    }

    /// @notice The parameters for a rebalance which is an ordered combination of deallocations, swaps, and allocations.
    /// @param deallocations Array of deallocation parameters.
    /// @param swaps Array of swap parameters.
    /// @param allocations Array of allocation parameters.
    /// @dev The rebalance will follow a strict order of:
    ///         Step 1. Execute all deallocations in the order specified by the deallocations array.
    ///         Step 2. Execute all swaps in the order specified by the swaps array.
    ///         Step 3. Execute all allocations in the order specified by the allocations array.
    struct RebalanceParams {
        DeallocationParams[] deallocations;
        SwapParams[] swaps;
        AllocationParams[] allocations;
    }

    /// @notice The configuration for a strategy.
    /// @param asset The asset that the strategy is associated with (assumes 1 asset per strategy).
    /// @param isRegistered Boolean indicating whether the strategy is configured.
    /// @param depositAllowed Boolean indicating whether the strategy is allowed to be deposited into.
    /// @param isTrusted Boolean indicating whether the strategy is trusted or not. Strategy's balance only contributes
    /// to the system's TVL when it is trusted.
    struct StrategyConfig {
        address asset;
        bool isRegistered;
        bool depositAllowed;
        bool isTrusted;
    }

    /// @notice Emitted when assets are deposited into a strategy.
    event AssetAllocated(
        address indexed asset, address indexed strategy, uint256 amount, uint256 actualDepositedAmount
    );

    /// @notice Emitted when assets are withdrawn from a strategy back to the Allocator.
    event AssetDeallocated(address indexed asset, address indexed strategy, uint256 amount);

    /// @notice Emitted when an allocation leaves a portion of `asset` idle on the Allocator instead of fully depositing
    /// it into a strategy.
    event AssetLeftIdle(address indexed asset, uint256 amount);

    /// @notice Emitted when one asset is swapped for another via a Swapper during a rebalance.
    event AssetsSwapped(address indexed assetIn, address indexed assetOut, uint256 amountIn, uint256 amountOut);

    /// @notice Emitted when an external funder tops up the Allocator's idle balance for an asset.
    event AssetToppedUp(address indexed asset, uint256 amount);

    /// @notice Emitted when deposits to a strategy are toggled enabled or disabled.
    event StrategyDepositsToggled(address indexed strategy, bool depositsEnabled);

    /// @notice Emitted when a withdrawal attempt against a strategy fails (caught for the retry/iteration pattern).
    event StrategyWithdrawalFailed(address indexed strategy, address indexed asset, uint256 amount);

    /// @notice Emitted when a strategy is added for an asset.
    event StrategyAdded(address indexed asset, address indexed strategy);

    /// @notice Emitted when a strategy is removed for an asset.
    event StrategyRemoved(address indexed asset, address indexed strategy);

    /// @notice Emitted when a strategy is marked trusted (its balance contributes to system TVL).
    event StrategyTrusted(address indexed strategy);

    /// @notice Emitted when a strategy is marked distrusted (its balance no longer contributes to system TVL).
    event StrategyDistrusted(address indexed strategy);

    /// @notice Emitted when the withdrawal queue for an asset is updated.
    event WithdrawalQueueSet(address indexed asset, address[] queue);

    /// @notice Thrown when funds fail to deposit into a yield strategy.
    /// @custom:selector 0x3868bf52
    error DepositIntoStrategyFailed(address strategy);

    /// @notice Thrown when deposits are not allowed to a strategy.
    /// @custom:selector 0xbd54a981
    error DepositsToStrategyDisabled(address strategy);

    /// @notice Thrown when the proposed withdrawal queue is not a permutation of the asset's registered strategies.
    /// @custom:selector 0x237f3e22
    error InvalidWithdrawalQueue();

    /// @notice Thrown when performing an operation on a strategy that is not trusted.
    /// @custom:selector 0x96547ce2
    error StrategyNotTrusted(address strategy);

    /// @notice Thrown when a strategy still has assets that belong to the Allocator.
    /// @custom:selector 0xa01adeda
    error StrategyStillHasFunds(address strategy);

    /// @notice Thrown when the maximum number of strategies per asset is exceeded.
    /// @custom:selector 0x83864c08
    error TooManyStrategies(address asset);

    /// @notice Thrown when a strategy has no shares to redeem.
    /// @custom:selector 0xdf4ff092
    error ZeroShareBalance(address strategy);

    /// @notice Deposits assets into the Allocator.
    /// @param asset Address of the asset to deposit.
    /// @param amount Amount of the asset to deposit.
    function deposit(address asset, uint256 amount) external;

    /// @notice Rebalances underlying assets.
    /// @dev A rebalance is an ordered combination of the following operations: deallocation of assets from strategies,
    /// swaps between assets, and allocation of assets to strategies.
    /// @param params Array of rebalance parameters.
    /// @param policyData Additional data that the rebalance policy might need to operate.
    function rebalance(RebalanceParams[] memory params, bytes calldata policyData) external;

    /// @notice Deposit assets into the Allocator to increase the total value of the system.
    /// @dev This function will be used exclusively to improve the solvency of the system.
    /// @param asset Address of the asset to deposit.
    /// @param amount Amount of the asset to deposit.
    function topUp(address asset, uint256 amount) external;

    /// @notice Withdraws a given amount of an asset, sourcing from idle funds first then iterating registered
    /// strategies.
    /// @param asset Address of the asset to withdraw.
    /// @param amount Amount of the asset to withdraw.
    function withdraw(address asset, uint256 amount) external;

    /// @notice Adds a new yield strategy to the allocator.
    /// @param asset Address of the asset to add the strategy for.
    /// @param strategy Address of the ERC-4626 strategy to add.
    function addStrategy(address asset, address strategy) external;

    /// @notice Removes a yield strategy from the allocator.
    /// @param strategy Address of the ERC-4626 strategy to remove.
    function removeStrategy(address strategy) external;

    /// @notice Replaces the withdrawal queue order for a given asset.
    /// @dev The new queue must be a permutation of the asset's currently registered strategies (same length, every
    /// registered strategy present exactly once); otherwise the call reverts with `InvalidWithdrawalQueue`. This
    /// guarantees no strategy can be silently dropped from the withdrawal path.
    /// @param asset Address of the asset whose withdrawal queue is being set.
    /// @param newQueue Strategies in the order they should be visited during withdrawal.
    function setWithdrawalQueue(address asset, address[] calldata newQueue) external;

    /// @notice Disables deposits to a given strategy.
    /// @param strategy Address of the ERC-4626 strategy to disable deposits for.
    function disableDepositsToStrategy(address strategy) external;

    /// @notice Enables deposits to a given strategy.
    /// @dev Reverts if the strategy is not trusted. The strategy must be trusted before deposits can be re-enabled.
    /// @param strategy Address of the ERC-4626 strategy to enable deposits for.
    function enableDepositsToStrategy(address strategy) external;

    /// @notice Trusts a strategy, allowing its balance to contribute to the system's TVL.
    /// @param strategy Address of the strategy to trust.
    function trustStrategy(address strategy) external;

    /// @notice Distrusts a strategy, excluding its balance from the system's TVL.
    /// @dev As a side effect, deposits into the strategy are automatically disabled if currently enabled.
    /// @dev Trusting the strategy again does NOT re-enable deposits.
    /// @dev If the strategy still holds assets, they stop contributing to trusted balances while vault obligations
    /// remain unchanged. This can temporarily make obligations exceed `getAggregatedBalance()` and cause
    /// `requestWithdrawal` to revert with `InsufficientAssets`.
    /// @param strategy Address of the strategy to distrust.
    function distrustStrategy(address strategy) external;

    /// @notice Getter for the balance of a given asset on the Allocator.
    /// @dev Returns the balance regardless of whether the asset is registered or trusted. For solvency
    /// calculations use `getTrustedAssetBalance()` which returns 0 for distrusted assets.
    /// @param asset Address of the asset to get the balance of.
    /// @return balance Balance of the asset in asset decimals in the Allocator (idle + aggregate balance in
    /// strategies).
    function getAssetBalance(address asset) external view returns (uint256);

    /// @notice Getter for the balance of a given strategy on the Allocator.
    /// @dev Returns the balance regardless of whether the strategy or asset is registered or trusted.
    /// Useful for admin/rescue operations.
    /// @param strategy Address of the strategy to get the balance of.
    /// @return balance Balance of tokens in the strategy in asset decimals (assumes one asset per strategy).
    function getAssetBalanceInStrategy(address strategy) external view returns (uint256);

    /// @notice Getter for the balances on the Allocator.
    /// @return balances Array of balances where each amount is denominated in the corresponding asset's decimals.
    function getTrustedAssetBalances() external view returns (AllocatorBalance[] memory balances);

    /// @notice Getter for the balance of a given asset on the Allocator.
    /// @dev Total balance is grossly understated as zero if the asset is not trusted.
    /// @dev Each strategy's balance is only counted if the strategy is trusted.
    /// @param asset Address of the asset to get the balance of.
    /// @return balance Balance of the asset in asset decimals in the Allocator (idle + aggregate balance in
    /// strategies).
    function getTrustedAssetBalance(address asset) external view returns (uint256);

    /// @notice Getter for the list of strategies registered for a given asset.
    /// @param asset Address of the asset to get strategies for.
    /// @return strategies Addresses of the registered strategies for the asset.
    function getStrategiesForAsset(address asset) external view returns (address[] memory strategies);

    /// @notice Getter for the ordered withdrawal queue for a given asset.
    /// @dev The queue contains the same strategies as `getStrategiesForAsset` but in the order they will be drained
    /// when fulfilling withdrawals. New strategies are appended to the queue on registration; the order is otherwise
    /// preserved across removals and can be customized via `setWithdrawalQueue`.
    /// @param asset Address of the asset to get the withdrawal queue for.
    /// @return queue Strategies in the order they will be visited during withdrawal.
    function getWithdrawalQueue(address asset) external view returns (address[] memory queue);

    /// @notice Getter for the configuration of a given strategy.
    /// @param strategy Address of the strategy to get the configuration for.
    /// @return config Configuration of the strategy.
    function getStrategyConfig(address strategy) external view returns (StrategyConfig memory);

    /// @notice Getter for whether a strategy is supported for a given asset.
    /// @param asset Address of the asset to check if the strategy is supported for.
    /// @param strategy Address of the strategy to check if it is supported for the asset.
    /// @return isSupported Whether the strategy is supported for the asset.
    function isStrategySupportedForAsset(address asset, address strategy) external view returns (bool);

    /// @notice Getter for whether a strategy is supported for allocating or deallocating, regardless of the asset.
    /// @param strategy Address of the strategy to check if it is supported for allocating or deallocating.
    /// @return isSupported Whether the strategy is supported for allocating or deallocating.
    function isStrategySupported(address strategy) external view returns (bool);

    /// @notice Getter for whether a strategy is trusted.
    /// @param strategy Address of the strategy to check.
    /// @return isTrusted Whether the strategy is trusted.
    function isStrategyTrusted(address strategy) external view returns (bool);
}
