// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

import {IChainGateway} from "src/interfaces/IChainGateway.sol";

/// @title IAccountingChainGateway
/// @author Aave Labs
/// @notice Interface for gateway functionality required on the Accounting Chain.
interface IAccountingChainGateway is IChainGateway {
    /// @notice Thrown when the caller is not the FundsHandler.
    /// @custom:selector 0x77607b1a
    error OnlyFundsHandler();

    /// @notice Thrown when the Earning Chain balance snapshot from the Chain Balance Oracle does not include the
    /// outbound cross-chain message block.
    /// @custom:selector 0xc6a06946
    error StaleChainBalance();

    /// @notice Sends assets to an Earning Chain.
    /// @dev The Accounting Chain does not prescribe to the Earning Chain which strategy to push assets to.
    /// @dev One asset is pushed at a time to avoid dependencies on bridges that support multiple assets bridged
    /// together.
    /// @param asset The asset to send.
    /// @param amount The amount of the asset to send.
    /// @param destinationChainId The chain id of the Earning Chain to send the assets to.
    /// @param bridgeAdapter The whitelisted bridge adapter to use for bridging the asset.
    /// @param feePayer Address that will pay the bridge fee.
    /// @param receiverExecutionGasLimit Gas limit for destination receiver execution, including adapter receive logic,
    /// token handling, gateway execution, and any non-empty arbitrary data processing. Excludes bridge provider
    /// operations before and after the receiver call.
    /// @param bridgeAdapterData Any bridge adapter custom parameters that it may need to operate.
    function sendPushFundsToChainMessage(
        address asset,
        uint256 amount,
        uint256 destinationChainId,
        address bridgeAdapter,
        address feePayer,
        uint256 receiverExecutionGasLimit,
        bytes calldata bridgeAdapterData
    ) external payable;
}
