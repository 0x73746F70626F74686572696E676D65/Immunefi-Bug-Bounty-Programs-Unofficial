// SPDX-License-Identifier: UNLICENSED
// Copyright (c) 2025 Aave Labs
pragma solidity ^0.8.22;

import {IPriceOracleAdapter} from "src/interfaces/IPriceOracleAdapter.sol";
import {AssetLib} from "src/libraries/AssetLib.sol";
import {Constants} from "src/types/Constants.sol";
import {Errors} from "src/types/Errors.sol";

// solhint-disable-next-line interface-starts-with-i
interface AggregatorV3Interface {
    function decimals() external view returns (uint8);

    function description() external view returns (string memory);

    function version() external view returns (uint256);

    function getRoundData(uint80 _roundId)
        external
        view
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound);

    function latestRoundData()
        external
        view
        returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound);
}

/// @title ChainlinkPriceOracleAdapter
/// @author Aave Labs
/// @notice Adapter for fetching a single asset's price data from the Chainlink Aggregator.
contract ChainlinkPriceOracleAdapter is IPriceOracleAdapter {
    using AssetLib for uint256;

    /// @dev Added to the heartbeat to account for potential publishing delays during periods of network congestion.
    uint256 constant HEARTBEAT_BUFFER_SECONDS = 90;

    address immutable ASSET;
    address immutable DATA_FEED;
    uint256 immutable DECIMALS;
    uint256 immutable HEARTBEAT;

    /// @dev Constructor.
    /// @param asset The address of the asset this adapter provides pricing for.
    /// @param dataFeed The address of the Chainlink data feed.
    /// @param heartbeat The expected heartbeat interval in seconds for staleness checks.
    constructor(address asset, address dataFeed, uint256 heartbeat) {
        require(asset != address(0), Errors.ZeroAddress());
        require(dataFeed != address(0), Errors.ZeroAddress());
        require(heartbeat > 0, Errors.InvalidParameter());
        ASSET = asset;
        DATA_FEED = dataFeed;
        DECIMALS = AggregatorV3Interface(dataFeed).decimals();
        HEARTBEAT = heartbeat;
    }

    /// @inheritdoc IPriceOracleAdapter
    function getPrice(address asset)
        external
        view
        virtual
        override
        returns (IPriceOracleAdapter.OracleResponse memory)
    {
        return _getPrice(asset);
    }

    /// @dev Internal implementation of getPrice that can be called by child contracts.
    function _getPrice(address asset) internal view returns (IPriceOracleAdapter.OracleResponse memory) {
        require(asset == ASSET, Errors.InvalidAsset(asset));
        (, int256 price,, uint256 updatedAt,) = AggregatorV3Interface(DATA_FEED).latestRoundData();
        uint256 priceRay = _toUint256(price).convertDecimals(DECIMALS, Constants.RAY_DECIMALS);
        bool isStale = false;
        if (updatedAt < block.timestamp && block.timestamp - updatedAt >= HEARTBEAT + HEARTBEAT_BUFFER_SECONDS) {
            isStale = true;
        }
        return IPriceOracleAdapter.OracleResponse(priceRay, isStale);
    }

    function _toUint256(int256 price) internal pure returns (uint256) {
        if (price <= 0) {
            return 0;
        }
        // Casting to 'uint256' is safe because we checked that price > 0.
        // forge-lint: disable-next-line(unsafe-typecast)
        return uint256(price);
    }
}
