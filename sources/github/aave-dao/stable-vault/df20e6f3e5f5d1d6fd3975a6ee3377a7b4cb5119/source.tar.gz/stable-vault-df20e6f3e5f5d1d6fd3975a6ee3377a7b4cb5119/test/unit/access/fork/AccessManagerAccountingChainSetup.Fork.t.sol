// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {AccessManagerBaseSetup} from "script/base/AccessManagerBaseSetup.sol";
import {AccountingChainDeployment} from "script/base/AccountingChainDeployment.sol";

import {IAllocator} from "src/interfaces/IAllocator.sol";

import {AccessManagerAccountingChainSetupTest} from "test/unit/access/AccessManagerAccountingChainSetup.t.sol";

contract AccessManagerAccountingChainSetupForkTest is AccessManagerAccountingChainSetupTest {
    // Turn on in order to run the tests on a fork, otherwise they will be skipped.
    bool immutable FORKING = false;

    function setUp() public override {
        vm.skip(!FORKING);
        vm.createSelectFork(vm.envString("FORK_URL"));
        vm.warp(block.timestamp + CRITICAL_DELAY + 1);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // OVERRIDES — address getters point to setup script constants / Create3 computations
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function _accessManager()
        internal
        view
        override(AccessManagerBaseSetup, AccountingChainDeployment)
        returns (address)
    {
        return getAccessManagerAddress(_deployer());
    }

    function _deployedATokenVaultAddresses()
        internal
        view
        override(AccessManagerAccountingChainSetupTest)
        returns (address[] memory)
    {
        IAllocator allocator = IAllocator(getAllocatorAddress(_deployer()));
        address[] memory vaults = new address[](2);
        vaults[0] = allocator.getStrategiesForAsset(_gho())[0];
        vaults[1] = allocator.getStrategiesForAsset(_usdc())[0];
        return vaults;
    }
}
