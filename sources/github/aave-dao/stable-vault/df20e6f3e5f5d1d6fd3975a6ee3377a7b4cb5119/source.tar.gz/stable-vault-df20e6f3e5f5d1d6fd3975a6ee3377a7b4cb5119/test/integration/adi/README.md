# ADI Pigeon Fork Tests

These tests exercise the a.DI bridging path against local Ethereum and Arbitrum
forks, with a.DI bridge events relayed by Pigeon helpers. Two layers run here:
the `AdiAdapter` against locally-deployed mock periphery, and the real preprod
`Deploy*Chain` scripts (`ForkDeployPreprod`, `FullSystemPreprodFork`) against the
live preprod a.DI. They are skipped during a normal `forge test` run unless
`FORK_TEST=true` is set.

`ForkDeployPreprod` runs each chain's deploy script and checks the deterministic
AccessManager / AdiAdapter land where the a.DI owner/guardian handoff delegated
control. `FullSystemPreprodFork` deploys both chains and drives a full deposit ->
bridge -> exchange -> burn-back round trip (plus a staged quorum/replay
check) through the deployed contracts. Both redirect their deployment output to
throwaway `deployments/preprod/v1/*.forktest.json` files (gitignored), so they
never touch the tracked deployment JSONs.

## Prerequisites

Run these commands from the repository root.

```sh
git submodule update --init --recursive
cp .env.example .env
```

Set `ALCHEMY_KEY` in `.env`. The wrapper uses it to start the Ethereum and
Arbitrum forks. You can also set `ETH_FORK_URL` / `ARB_FORK_URL` directly, or
`RPC_MAINNET` / `RPC_ARBITRUM`.

You also need Foundry commands on your `PATH`:

- `forge` to run the tests
- `anvil` to run the local forks
- `cast` for optional fork status output

## Run the Full Pigeon Suite

```sh
./run-adi-pigeon-fork-test.sh
```

By default, the wrapper:

1. Clones `https://github.com/aave/adi-deploy.git` into
   `.local/adi-deploy-forktest`.
2. Checks out `main`.
3. Starts local Ethereum and Arbitrum Anvil forks at pinned blocks.
4. Exports the configured deployment's a.DI addresses from
   `deployments/stable-vaults/<env>/ethereum.json` and
   `deployments/stable-vaults/<env>/arbitrum.json`.
5. Runs:

```sh
forge test --match-contract 'AdiAdapterPigeon|ForkDeployPreprod|FullSystemPreprodFork' -vvv
```

## Run One Contract or Test

Use `MATCH_CONTRACT` to run a narrower contract:

```sh
MATCH_CONTRACT=AdiAdapterPigeonIouWithdrawal ./run-adi-pigeon-fork-test.sh
```

Use `FORGE_TEST_ARGS` to pass extra Foundry flags:

```sh
MATCH_CONTRACT=AdiAdapterPigeonIouWithdrawal \
FORGE_TEST_ARGS="--match-test test_iouWithdrawalOverAdi_bridgeMintAndBurnLockedAccountingIous -vvvv" \
./run-adi-pigeon-fork-test.sh
```

## Modes And Deployment Environments

The default mode uses an a.DI deployment already committed in `adi-deploy`.
`ADI_DEPLOYMENT_ENV` selects the deployment subfolder under
`deployments/stable-vaults/`, and the deploy fork tests (`ForkDeployPreprod`,
`FullSystemPreprodFork`) read the matching Stable Vaults config
(`config/deployment-config.<env>.jsonc`) so both sides run against the same
environment:

```sh
ADI_FORK_MODE=deployed ADI_DEPLOYMENT_ENV=preprod ./run-adi-pigeon-fork-test.sh
ADI_FORK_MODE=deployed ADI_DEPLOYMENT_ENV=prod ./run-adi-pigeon-fork-test.sh
```

`ADI_FORK_MODE=deployed` and `ADI_DEPLOYMENT_ENV=preprod` are the defaults, so
the first command is equivalent to `./run-adi-pigeon-fork-test.sh`.

To redeploy a.DI from scratch on the local forks, use fresh mode:

```sh
ADI_FORK_MODE=fresh ./run-adi-pigeon-fork-test.sh
```

Fresh mode delegates to `adi-deploy/scripts/stable-vaults/run-local-fork-deployment.sh`
and then reads `deployments/stable-vaults/ethereum.json` and
`deployments/stable-vaults/arbitrum.json`.

`ADI_FORK_MODE=preprod` and `ADI_FORK_MODE=prod` are compatibility aliases for
`ADI_FORK_MODE=deployed ADI_DEPLOYMENT_ENV=preprod|prod`.
`RUN_ADI_DEPLOY=true` is kept as a legacy alias for `ADI_FORK_MODE=fresh`.
`RUN_ADI_DEPLOY=false` maps to `ADI_FORK_MODE=deployed`.

The script reads deployment JSONs from `ADI_DEPLOY_DIR`, which defaults to
`.local/adi-deploy-forktest`. Override it when using a different checkout.

## Useful Overrides

```sh
ADI_DEPLOY_REF=pull/3/head ./run-adi-pigeon-fork-test.sh
ADI_DEPLOYMENT_ENV=prod ./run-adi-pigeon-fork-test.sh
ETH_PORT=9545 ARB_PORT=9546 ./run-adi-pigeon-fork-test.sh
ENV_FILE=.env.forktest ./run-adi-pigeon-fork-test.sh
RESTART_ANVIL=false ./run-adi-pigeon-fork-test.sh
ETH_FORK_BLOCK=25196860 ARB_FORK_BLOCK=467697210 ./run-adi-pigeon-fork-test.sh
```

The default fork blocks are chosen per `ADI_DEPLOYMENT_ENV` (preprod and prod were
deployed at different times, so each pins its own post-handoff block). Override
`ETH_FORK_BLOCK` / `ARB_FORK_BLOCK` to fork elsewhere.

`ETH_FORK_RPC` and `ARB_FORK_RPC` default to `http://127.0.0.1:8545` and
`http://127.0.0.1:8546`, or to the ports set with `ETH_PORT` and `ARB_PORT`.
They are the local Anvil RPCs used by Forge. `ETH_FORK_URL` and `ARB_FORK_URL`
are the upstream RPCs Anvil forks from.

## Manual Mode

For debugging, you can bypass the wrapper and run Forge directly against
already-running forks. Export the fork RPCs and the deployment addresses first:

```sh
export FORK_TEST=true
export ETH_FORK_RPC=http://127.0.0.1:8545
export ARB_FORK_RPC=http://127.0.0.1:8546

export ETH_CCC=<ethereum-cross-chain-controller>
export ARB_CCC=<arbitrum-cross-chain-controller>
export ETH_ARB_ADAPTER=<ethereum-arbitrum-native-adapter>
export ETH_CCIP_ADAPTER=<ethereum-ccip-adapter>
export ETH_LZ_ADAPTER=<ethereum-layerzero-adapter>
export ETH_HL_ADAPTER=<ethereum-hyperlane-adapter>
export ARB_CCIP_ADAPTER=<arbitrum-ccip-adapter>
export ARB_LZ_ADAPTER=<arbitrum-layerzero-adapter>
export ARB_HL_ADAPTER=<arbitrum-hyperlane-adapter>

forge build
forge test --match-contract 'AdiAdapterPigeon|ForkDeployPreprod|FullSystemPreprodFork' -vvv
```

The `forge build` is required: the deploy tests read the force-compiled
`ATokenVaultMerklRewardClaimer` artifact from `out/`, which a sparse
`forge test --match-contract` run does not produce on its own. Only the a.DI
CrossChainController and bridge-adapter addresses come from env (the AMB endpoints
and CCC owner are read on-chain from those adapters, and token addresses from the
deploy config). The wrapper is preferred because it builds and exports these
values automatically.
