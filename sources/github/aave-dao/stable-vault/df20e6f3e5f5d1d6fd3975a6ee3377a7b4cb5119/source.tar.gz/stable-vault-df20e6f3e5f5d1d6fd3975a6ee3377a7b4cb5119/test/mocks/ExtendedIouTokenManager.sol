// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IouTokenManager} from "src/core/ious/IouTokenManager.sol";

contract ExtendedIouTokenManager is IouTokenManager {
    constructor(address iouToken, address chainGateway, address vault, bool isAccountingChain)
        IouTokenManager(iouToken, chainGateway, vault, isAccountingChain)
    {}

    function mockLockedBalance(uint256 lockedBalance) external {
        $IouTokenManager().lockedBalance = lockedBalance;
    }
}
