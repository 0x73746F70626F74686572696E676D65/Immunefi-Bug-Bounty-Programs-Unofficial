// SPDX-License-Identifier: MIT
pragma solidity ^0.8.10;

import {Ownable} from '@openzeppelin/contracts/access/Ownable.sol';
import {IGhoToken} from 'src/contracts/gho/interfaces/IGhoToken.sol';
import {IOwnableFacilitator} from 'src/contracts/facilitators/gsm/interfaces/IOwnableFacilitator.sol';

/**
 * @title OwnableFacilitator
 * @author Aave/TokenLogic
 * @notice GHO Facilitator used to directly mint GHO to a given address.
 */
contract OwnableFacilitator is Ownable, IOwnableFacilitator {
  /// @inheritdoc IOwnableFacilitator
  address public immutable GHO_TOKEN;

  /**
   * @dev Constructor
   * @param initialOwner The address of the initial owner
   * @param ghoAddress The address of GHO token
   */
  constructor(address initialOwner, address ghoAddress) Ownable(initialOwner) {
    require(initialOwner != address(0), 'ZERO_ADDRESS_NOT_VALID');
    require(ghoAddress != address(0), 'ZERO_ADDRESS_NOT_VALID');

    GHO_TOKEN = ghoAddress;
  }

  /// @inheritdoc IOwnableFacilitator
  function mint(address account, uint256 amount) external onlyOwner {
    IGhoToken(GHO_TOKEN).mint(account, amount);
  }

  /// @inheritdoc IOwnableFacilitator
  function burn(uint256 amount) external onlyOwner {
    IGhoToken(GHO_TOKEN).burn(amount);
  }
}
