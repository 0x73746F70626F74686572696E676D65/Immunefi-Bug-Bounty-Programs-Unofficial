# Aave Permissions Search

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Faave-dao%2Fpermissions-search)

An application for searching and visualizing permissions within the [Aave](https://aave.com/) ecosystem. It fetches permission data from the [aave-permissions-book](https://github.com/aave-dao/aave-permissions-book) and displays it in an interactive, searchable interface.

## Features

- Search by smart wallet (Safe) address, owner address, or permission type
- Multi-chain support across 11 networks
- Automatic Safe wallet detection with owner resolution
- Permission categorization by role and modifier types
- Data auto-refreshes every hour via ISR

## Tech Stack

- [Next.js 15](https://nextjs.org/) (App Router)
- [React 19](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [viem](https://viem.sh/)

## Quick Start

1. Clone the repository
2. Install dependencies: `pnpm install`
3. Run the dev server: `pnpm dev`
4. Open [http://localhost:3000](http://localhost:3000)

## License

Copyright Aave DAO 2026. [MIT](./LICENSE)