import twitterIcon from '@/assets/icons/twitter.svg';
import websiteIcon from '@/assets/icons/website.svg';
import Image from 'next/image';
import githubIcon from '@/assets/icons/github.svg';

export const Footer = () => {
  return (
    <div className="-translate-x-1 mt-auto">
      <div className="flex items-center justify-center text-sm text-brand-500 pt-10">
        <div>
          <div className="mb-2 text-center text-stone-400 font-semibold text-xs">by BGD Labs</div>
          <div className="flex justify-center gap-1">
            <a
              href="https://twitter.com/bgdlabs"
              target="_blank"
              rel="noreferrer"
            >
              <Image
                src={twitterIcon}
                className="h-6 w-6"
                alt="BGD Labs Official X Account"
              />
            </a>
            <a href="https://bgdlabs.com/" target="_blank" rel="noreferrer">
              <Image
                src={websiteIcon}
                className="h-6 w-6"
                alt="BGD Labs Website"
              />
            </a>
            <a href="https://github.com/bgd-labs/aave-permissions-book" target="_blank" rel="noreferrer">
              <Image
                src={githubIcon}
                className="h-6 w-6"
                alt="Aave Permissions Book Github"
              />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
