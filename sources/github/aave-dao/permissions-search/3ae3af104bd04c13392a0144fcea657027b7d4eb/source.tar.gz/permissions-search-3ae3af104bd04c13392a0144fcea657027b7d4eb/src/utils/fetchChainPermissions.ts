import { parsePermissionsFile } from "@/utils/parsePermissionsFile";
import {
  mainnet,
  base,
  arbitrum,
  avalanche,
  optimism,
  polygon,
  metis,
  gnosis,
  bsc,
  scroll,
  zksync,
} from "viem/chains";
import {
  type Permission,
  type SafeWalletMap,
  type OwnerMap,
  type ChainPermissionsData,
} from "@/types";

const CHAIN_IDS = [
  mainnet.id,
  base.id,
  arbitrum.id,
  avalanche.id,
  optimism.id,
  polygon.id,
  metis.id,
  gnosis.id,
  bsc.id,
  scroll.id,
  zksync.id,
];

const BASE_URL =
  "https://raw.githubusercontent.com/aave-dao/aave-permissions-book/main/out/permissions";

export async function fetchChainPermissions(): Promise<ChainPermissionsData> {
  const allPermissions: Permission[] = [];
  const globalSafeWalletMap: SafeWalletMap = {};
  const globalOwnerMap: OwnerMap = {};

  await Promise.all(
    CHAIN_IDS.map(async (chainId) => {
      try {
        const response = await fetch(`${BASE_URL}/${chainId}-permissions.json`);
        if (!response.ok) {
          console.error(
            `Failed to fetch permissions for chain ${chainId}: ${response.statusText}`
          );
          return;
        }

        const data = await response.json();
        const { permissions, safeWalletMap, ownerMap } = parsePermissionsFile(
          data,
          chainId
        );

        allPermissions.push(...permissions);

        Object.entries(safeWalletMap).forEach(([address, info]) => {
          const safeAddress = address.toLowerCase();
          if (!globalSafeWalletMap[safeAddress]) {
            globalSafeWalletMap[safeAddress] = { ...info, permissions: [] };
          }
          globalSafeWalletMap[safeAddress].permissions.push(
            ...info.permissions
          );
        });

        Object.entries(ownerMap).forEach(([owner, safeAddresses]) => {
          const lowerCaseOwner = owner.toLowerCase();
          if (!globalOwnerMap[lowerCaseOwner]) {
            globalOwnerMap[lowerCaseOwner] = new Set();
          }
          safeAddresses.forEach((safeAddress) =>
            globalOwnerMap[lowerCaseOwner].add(safeAddress.toLowerCase())
          );
        });
      } catch (error) {
        console.error(
          `Error fetching permissions for chain ${chainId}:`,
          error
        );
      }
    })
  );

  const sortPermissions = (a: Permission, b: Permission) => {
    if (a.type === "role" && b.type === "modifier") return -1;
    if (a.type === "modifier" && b.type === "role") return 1;
    return 0;
  };

  allPermissions.sort(sortPermissions);

  Object.values(globalSafeWalletMap).forEach((safe) => {
    safe.permissions.sort(sortPermissions);
  });

  // Object.values(globalSafeWalletMap).forEach(safe => {
  //   safe.permissions.sort((a, b) => allPermissions.indexOf(a) - allPermissions.indexOf(b));
  // });

  return {
    permissions: allPermissions,
    safeWalletMap: globalSafeWalletMap,
    ownerMap: globalOwnerMap,
  };
}
