import { SearchIcon } from "lucide-react";

import { BlocksColumn, Block } from "./ui/Block";

export default function SearchSkeleton() {
  return (
    <div className="flex flex-col gap-4 items-center w-full max-w-2xl ">
      <BlocksColumn className="w-full">
        <Block className="border-stone-900 p-2">
          <div className="w-full focus-within:border-stone-500 flex items-center w-full border border-white transition-colors rounded-none outline-none w-full text-xl border-r-2 border-t-2 border-transparent focus-within:border-stone-950 relative">
            <input
              type="text"
              className="w-full focus:outline-none font-mono ml-auto text-left py-3 bg-transparent text-normal sm:text-lg px-4"
              placeholder="Loading..."
              disabled
            />
            <div className="flex items-center justify-center absolute right-0 top-0 h-full pr-3 pl-10 bg-gradient-to-r from-transparent via-white to-white pointer-events-none">
              <SearchIcon className=" w-6 h-6 text-stone-400" />
            </div>
          </div>
        </Block>
      </BlocksColumn>
    </div>
  );
}
