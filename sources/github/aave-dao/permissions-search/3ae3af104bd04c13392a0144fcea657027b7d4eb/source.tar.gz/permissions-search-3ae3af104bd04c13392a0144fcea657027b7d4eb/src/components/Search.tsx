"use client";

import { SearchIcon } from "lucide-react";
import { type Permission, type SafeWalletMap, type OwnerMap } from "@/types";
import SearchResult from "./SearchResult";
import SafeWalletList from "./SafeWalletList";
import SafeHeader from "./SafeHeader";
import { zeroAddress, Address, getAddress } from "viem";
import { BlocksColumn, Block } from "./ui/Block";
import { useQueryState } from "nuqs";
import { useState, useEffect } from "react";

export default function Search({
  permissions,
  safeWalletMap,
  ownerMap,
}: {
  permissions: Permission[];
  safeWalletMap: SafeWalletMap;
  ownerMap: OwnerMap;
}) {
  const [search, setSearch] = useQueryState("q");
  const [searchResults, setSearchResults] = useState<Permission[]>([]);
  const [safeWallet, setSafeWallet] = useState<SafeWalletMap[Address] | null>(
    null
  );
  const [safeWallets, setSafeWallets] = useState<SafeWalletMap | null>(null);

  useEffect(() => {
    if (search) {
      let searchAddress: Address;

      try {
        searchAddress = getAddress(search);
      } catch {
        setSearchResults([]);
        setSafeWallet(null);
        setSafeWallets(null);
        return;
      }

      const normalizedAddress = searchAddress.toLowerCase() as Address;

      if (
        safeWalletMap[normalizedAddress] &&
        safeWalletMap[normalizedAddress].owners.length > 0
      ) {
        setSafeWallet(safeWalletMap[normalizedAddress]);
        setSearchResults(safeWalletMap[normalizedAddress].permissions);
        setSafeWallets(null);
      } else if (ownerMap[normalizedAddress]) {
        const safeAddresses = Array.from(ownerMap[normalizedAddress]);
        const ownerSafeWallets: SafeWalletMap = {};
        safeAddresses.forEach((addr) => {
          if (
            safeWalletMap[addr as Address] &&
            safeWalletMap[addr as Address].owners.length > 0
          ) {
            ownerSafeWallets[addr as Address] = safeWalletMap[addr as Address];
          }
        });
        setSafeWallets(ownerSafeWallets);
        setSafeWallet(null);
        setSearchResults([]);
      } else {
        const results = permissions.filter(
          (p) => p.address.toLowerCase() === normalizedAddress
        );
        setSearchResults(results);
        setSafeWallet(null);
        setSafeWallets(null);
      }
    } else {
      setSearchResults([]);
      setSafeWallet(null);
      setSafeWallets(null);
    }
  }, [search, permissions, safeWalletMap, ownerMap]);

  return (
    <div className="flex flex-col gap-4 items-center w-full max-w-2xl">
      <BlocksColumn className="w-full">
        <Block className="border-stone-900 p-2">
          <div className="w-full focus-within:border-stone-500 flex items-center w-full border border-white transition-colors rounded-none outline-none w-full text-xl border-r-2 border-t-2 border-transparent focus-within:border-stone-950 relative">
            <input
              type="text"
              className="w-full focus:outline-none font-mono ml-auto text-left py-3 bg-transparent text-normal sm:text-lg px-4"
              placeholder={zeroAddress}
              value={search ?? ""}
              onChange={(e) => setSearch(e.target.value)}
            />
            <div className="flex items-center justify-center absolute right-0 top-0 h-full pr-3 pl-10 bg-gradient-to-r from-transparent via-white to-white pointer-events-none">
              <SearchIcon className=" w-6 h-6 text-stone-400" />
            </div>
          </div>
        </Block>
        {safeWallet && (
          <Block className="border-stone-900 p-0">
            <SafeHeader
              address={search as Address}
              threshold={safeWallet.threshold}
              ownersCount={safeWallet.owners.length}
              isSigner={false}
            />
          </Block>
        )}
        {!search && (
          <Block className="border-stone-900 px-4 py-2 text-stone-600 text-sm bg-stone-100">
            Paste a valid{" "}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 1789.83 661.47"
              className="h-6 fill-stone-900 inline -translate-y-[2px]"
            >
              <g>
                <path d="M885.96,316.84c-16.31-6.55-36.23-12.01-59.76-16.39h-.5c-22.86-4.03-40.01-7.73-51.44-11.1-11.43-3.35-20.42-7.89-26.98-13.61-6.56-5.71-9.83-13.61-9.83-23.7,0-14.79,5.55-26.05,16.64-33.78,11.1-7.73,25.72-11.6,43.87-11.6,19.84,0,35.88,5.04,48.16,15.13,11.02,9.06,17.77,20.57,20.25,34.51,.49,2.78,2.84,4.83,5.66,4.86l55.8,.42c3.42,.03,6.16-2.91,5.82-6.32-1.87-18.65-8.02-35.61-18.44-50.87-11.6-16.97-27.57-30.17-47.91-39.59-20.34-9.41-43.45-14.12-69.34-14.12-24.54,0-46.64,4.54-66.31,13.62-19.66,9.08-34.96,21.68-45.89,37.82-10.93,16.14-16.39,34.29-16.39,54.46,0,22.19,4.87,40.01,14.62,53.45,9.75,13.45,22.52,23.62,38.32,30.51,15.8,6.89,34.79,12.35,56.98,16.39l2.52,.5c23.52,4.37,41.1,8.24,52.7,11.6,11.6,3.37,20.75,8.07,27.48,14.12,6.72,6.05,10.08,14.29,10.08,24.71,0,14.8-6.05,26.39-18.15,34.79-12.1,8.41-27.74,12.61-46.9,12.61-22.87,0-41.35-5.8-55.47-17.4-12.85-10.55-20.41-24.1-22.68-40.64-.39-2.86-2.77-5.03-5.65-5.07l-55.73-.84c-3.39-.05-6.13,2.81-5.87,6.19,1.58,20.34,7.94,38.67,19.08,54.99,12.27,17.99,29.16,32.11,50.68,42.36,21.51,10.26,46.22,15.38,74.13,15.38,25.88,0,49.08-4.7,69.59-14.12,20.5-9.41,36.56-22.44,48.16-39.08,11.6-16.64,17.4-35.38,17.4-56.23,0-22.19-5.05-40.09-15.13-53.71s-23.28-23.7-39.58-30.26Z" />
                <path d="M1228.63,452.75h-8.71c-5.04,0-9-1.34-11.85-4.04-2.86-2.68-4.29-7.06-4.29-13.11v-96.32c0-30.59-9.75-53.87-29.24-69.84-19.5-15.96-42.46-24.1-78.43-24.1-33.96,0-60.49,7.38-81.33,21.83-19,13.18-30.45,31.23-34.37,54.18-.61,3.57,2.09,6.84,5.7,6.84h51.25c2.57,0,4.87-1.69,5.55-4.17,2.34-8.49,7.5-15.42,15.48-20.79,9.24-6.22,20.22-9.33,34.68-9.33,27.27,0,46.66,16.81,46.66,41.85v7.83c0,3.2-2.59,5.79-5.79,5.79h-46.42c-37.65,0-66.23,7.4-85.72,22.19-19.5,14.8-29.25,35.81-29.25,63.03,0,23.54,8.91,42.03,26.73,55.47,13.37,10.08,29.35,15.9,45.8,18.45,12.57,1.95,25.48,2.66,38.08,.64,13.2-2.11,23.92-7.55,34.65-15.31,9.64-6.96,17.68-15.88,25.02-26.76,3.58-6.15,12.97-3.68,12.97,3.43v8.55c-.01,15.54,12.58,28.14,28.12,28.14h44.71c3.2,0,5.79-2.59,5.79-5.79v-42.88c0-3.2-2.59-5.79-5.79-5.79Zm-88.89-51.94c0,12.44-2.61,23.28-7.82,32.52-10.92,19.38-30.46,29.5-52.45,29.5-12.78,0-23.03-3.02-30.76-9.07-7.74-6.05-11.6-14.12-11.6-24.21,0-11.42,4.29-20.25,12.86-26.47,8.57-6.21,20.75-9.33,36.56-9.33h47.42c3.2,0,5.79,2.59,5.79,5.79v1.27Z" />
                <path d="M1415.46,154.37h-66.69c-35.18,0-63.7,28.52-63.7,63.7v27.99c0,3.2-2.59,5.79-5.79,5.79h-38.08c-3.2,0-5.79,2.59-5.79,5.79v43.38c0,3.2,2.59,5.79,5.79,5.79h38.08c3.2,0,5.79,2.59,5.79,5.79v188.82c0,3.2,2.59,5.79,5.79,5.79h51.96c3.2,0,5.79-2.59,5.79-5.79v-188.82c0-3.2,2.59-5.79,5.79-5.79h60.55c3.2,0,5.79-2.59,5.79-5.79v-43.38c0-3.2-2.59-5.79-5.79-5.79h-60.55c-3.2,0-5.79-2.59-5.79-5.79v-25.15c0-6.4,5.19-11.58,11.58-11.58h55.26c3.2,0,5.79-2.59,5.79-5.79v-43.38c0-3.2-2.59-5.79-5.79-5.79Z" />
                <path d="M1670.02,303.99c-11.26-18.82-26.65-33.28-46.14-43.37-19.5-10.08-42.03-15.27-67.57-15.27s-47.58,5.61-67.07,16.53c-19.5,10.93-34.63,26.39-45.38,46.39-10.76,20.01-16.14,43.45-16.14,70.35s5.55,49.34,16.64,69.34c11.1,20,26.98,35.38,47.65,46.14,20.67,10.76,44.96,16.14,72.87,16.14,21.51,0,40.76-3.95,57.74-11.85,16.97-7.89,30.67-18.74,41.09-32.52,8.92-11.8,15.01-24.72,18.27-38.75,.85-3.64-1.9-7.14-5.64-7.14h-52.2c-2.5,0-4.69,1.62-5.49,3.99-3.68,10.87-10.17,19.46-19.48,25.76-10.43,7.06-23.37,10.59-38.83,10.59-12.78,0-23.95-2.69-33.53-8.07-9.58-5.37-17.14-12.94-22.69-22.69-2.19-3.85-3.98-7.92-5.41-12.11-1.53-4.5-2.63-9.14-3.39-13.84-.26-1.64-.5-3.3-.7-4.96-.39-3.42,2.32-6.41,5.76-6.41h180.01c2.92,0,5.42-2.16,5.75-5.07,.25-2.13,.42-4.3,.51-6.53,.17-4.03,.25-7.73,.25-11.09,0-24.87-5.63-46.72-16.89-65.55Zm-54.09,44.37h-112.74c-3.7,0-6.49-3.43-5.67-7.04,1.8-7.91,4.92-15.05,9.36-21.45,5.71-8.23,13.11-14.54,22.19-18.91,9.08-4.37,18.99-6.56,29.75-6.56,17.48,0,31.94,4.71,43.37,14.12,9.81,8.08,16.27,19,19.4,32.77,.82,3.62-1.95,7.07-5.66,7.07Z" />
              </g>
              <g>
                <path d="M531.98,330.7h-49.42c-14.76,0-26.72,11.96-26.72,26.72v71.73c0,14.76-11.96,26.72-26.72,26.72H232.51c-14.76,0-26.72,11.96-26.72,26.72v49.42c0,14.76,11.96,26.72,26.72,26.72h207.99c14.76,0,26.55-11.96,26.55-26.72v-39.65c0-14.76,11.96-25.23,26.72-25.23h38.2c14.76,0,26.72-11.96,26.72-26.72v-83.3c0-14.76-11.96-26.41-26.72-26.41Z" />
                <path d="M205.78,232.52c0-14.76,11.96-26.72,26.72-26.72h196.49c14.76,0,26.72-11.96,26.72-26.72v-49.42c0-14.76-11.96-26.72-26.72-26.72H221.11c-14.76,0-26.72,11.96-26.72,26.72v38.08c0,14.76-11.96,26.72-26.72,26.72h-38.03c-14.76,0-26.72,11.96-26.72,26.72v83.39c0,14.76,12.01,26.12,26.77,26.12h49.42c14.76,0,26.72-11.96,26.72-26.72l-.05-71.44Z" />
                <path d="M307.55,278.75h47.47c15.47,0,28.02,12.56,28.02,28.02v47.47c0,15.47-12.56,28.02-28.02,28.02h-47.47c-15.47,0-28.02-12.56-28.02-28.02v-47.47c0-15.47,12.56-28.02,28.02-28.02Z" />
              </g>
            </svg>{" "}
            or any address to search for permissions on Aave ecosystem
          </Block>
        )}
        {safeWallets && <SafeWalletList safeWallets={safeWallets} />}
        {searchResults.map((p) => (
          <SearchResult
            key={`${p.chainId}-${p.system}-${p.contract}-${p.address}-${p.type}-${p.name}`}
            permission={p}
          />
        ))}
      </BlocksColumn>
    </div>
  );
}
