import {
  type Permission,
  type SystemData,
  type ContractData,
  type ModifierData,
  type AddressData,
  type SafeWalletMap,
  type OwnerMap,
} from "@/types";
import { Address } from "viem";

export function parsePermissionsFile(
  data: Record<string, SystemData>,
  chainId: number
): {
  permissions: Permission[];
  safeWalletMap: SafeWalletMap;
  ownerMap: OwnerMap;
} {
  const permissions: Permission[] = [];
  const safeWalletMap: SafeWalletMap = {};
  const ownerMap: OwnerMap = {};

  const addToSafeWalletMap = (address: Address, permission: Permission) => {
    const lowerCaseAddress = address.toLowerCase();
    if (!safeWalletMap[lowerCaseAddress]) {
      safeWalletMap[lowerCaseAddress] = {
        owners: [],
        threshold: 0,
        permissions: [],
      };
    }
    if (permission.owners && permission.owners.length > 0) {
      safeWalletMap[lowerCaseAddress].owners = permission.owners;
    }
    if (permission.threshold) {
      safeWalletMap[lowerCaseAddress].threshold = permission.threshold;
    }
    safeWalletMap[lowerCaseAddress].permissions.push(permission);
  };

  const addToOwnerMap = (owner: Address, safeAddress: Address) => {
    const lowerCaseOwner = owner.toLowerCase();
    if (!ownerMap[lowerCaseOwner]) {
      ownerMap[lowerCaseOwner] = new Set();
    }
    ownerMap[lowerCaseOwner].add(safeAddress.toLowerCase());
  };

  Object.entries(data).forEach(([system, systemData]: [string, SystemData]) => {
    if (system.includes("TENDERLY")) {
      return;
    }

    if (systemData.contracts) {
      Object.entries(systemData.contracts).forEach(
        ([contractName, contract]: [string, ContractData]) => {
          if (contract.modifiers) {
            contract.modifiers.forEach((modifier: ModifierData) => {
              modifier.addresses.forEach((address: AddressData) => {
                const permission: Permission = {
                  chainId,
                  system,
                  contract: contractName,
                  contractAddress: contract.address,
                  type: "modifier",
                  name: modifier.modifier,
                  functions: modifier.functions,
                  address: address.address,
                  owners: address.owners,
                  threshold: address.signersThreshold,
                };
                permissions.push(permission);
                addToSafeWalletMap(address.address, permission);

                if (address.owners && address.owners.length > 0) {
                  address.owners.forEach((owner) => {
                    addToOwnerMap(owner, address.address);
                  });
                }
              });
            });
          }
        }
      );
    }

    if (systemData.roles?.role) {
      Object.entries(systemData.roles.role).forEach(([roleName, addresses]: [string, Address[]]) => {
        addresses.forEach((address: Address) => {
          const permission: Permission = {
            chainId,
            system,
            contract: "ACLManager",
            contractAddress: systemData.contracts?.ACLManager?.address || "0x",
            type: "role",
            name: roleName,
            functions: [],
            address,
            owners: [],
            threshold: 0,
          };
          permissions.push(permission);
          addToSafeWalletMap(address, permission);
        });
      });
    }

    if (systemData.gsmRoles) {
      Object.entries(systemData.gsmRoles).forEach(([gsm, gsmData]: [string, { role: Record<string, Address[]> }]) => {
        if (gsmData.role) {
          Object.entries(gsmData.role).forEach(([roleName, addresses]: [string, Address[]]) => {
            addresses.forEach((address: Address) => {
              const permission: Permission = {
                chainId,
                system,
                contract: gsm,
                contractAddress: systemData.contracts?.[gsm]?.address || "0x",
                type: "role",
                name: `GSM_${roleName}`,
                functions: [],
                address,
                owners: [],
                threshold: 0,
              };
              permissions.push(permission);
              addToSafeWalletMap(address, permission);
            });
          });
        }
      });
    }

    if (systemData.govV3?.ggRoles?.role) {
      Object.entries(systemData.govV3.ggRoles.role).forEach(([roleName, addresses]: [string, Address[]]) => {
        addresses.forEach((address: Address) => {
          const permission: Permission = {
            chainId,
            system,
            contract: "GovernanceV3",
            contractAddress: systemData.govV3?.contracts?.AaveGovernanceV3?.address || "0x",
            type: "role",
            name: `GOV_${roleName}`,
            functions: [],
            address,
            owners: [],
            threshold: 0,
          };
          permissions.push(permission);
          addToSafeWalletMap(address, permission);
        });
      });
    }

    if (systemData.govV3?.contracts) {
      Object.entries(systemData.govV3.contracts).forEach(
        ([contractName, contractData]: [string, ContractData]) => {
          if (contractData.modifiers) {
            contractData.modifiers.forEach((modifier: ModifierData) => {
              modifier.addresses.forEach((address: AddressData) => {
                const permission: Permission = {
                  chainId,
                  system,
                  contract: contractName,
                  contractAddress: contractData.address,
                  type: "modifier",
                  name: modifier.modifier,
                  functions: modifier.functions,
                  address: address.address,
                  owners: address.owners,
                  threshold: address.signersThreshold,
                };
                permissions.push(permission);
                addToSafeWalletMap(address.address, permission);

                if (address.owners && address.owners.length > 0) {
                  address.owners.forEach((owner) => {
                    addToOwnerMap(owner, address.address);
                  });
                }
              });
            });
          }
        }
      );
    }
  });

  return { permissions, safeWalletMap, ownerMap };
}
