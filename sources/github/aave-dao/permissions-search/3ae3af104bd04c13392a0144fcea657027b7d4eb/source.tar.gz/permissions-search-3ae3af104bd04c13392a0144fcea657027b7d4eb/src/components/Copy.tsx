"use client";

import React, { useState } from "react";

import { CopyIcon } from "@/components/CopyIcon";
import { cn } from "@/utils/cn";

type Props = {
  value?: string | number | null;
  children?: React.ReactNode;
};

export const Copy = ({ value, children }: Props) => {
  const [copied, setCopied] = useState(false);

  if (!value) return null;

  const valueString = String(value);

  const handleCopyClick = async (event: React.MouseEvent) => {
    event.preventDefault();
    await navigator.clipboard.writeText(valueString);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 1500);
  };

  return (
    <button
      type="button"
      className={cn(
        "flex shrink items-center gap-1 border border-transparent opacity-60 transition-opacity duration-200 ease-in-out hover:opacity-100"
      )}
      onClick={handleCopyClick}
    >
      {children}
      <div className={cn("flex h-5 w-5 overflow-hidden")}>
        <CopyIcon isCopied={copied} />
      </div>
    </button>
  );
};
