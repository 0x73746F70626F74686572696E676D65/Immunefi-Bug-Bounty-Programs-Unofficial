import { SquareFunction } from "lucide-react";
import { type Permission } from "@/types";
import { getExplorerLink, getChainName } from "@/utils/chainInfo";
import { Web3Icon } from "@bgd-labs/react-web3-icons";
import { Block } from "@/components/ui/Block";
import { chainsIconsPack } from "@bgd-labs/react-web3-icons/dist/iconsPacks/chainsIconsPack";

export default function SearchResult({
  permission,
}: {
  permission: Permission;
}) {
  return (
    <Block elevation={2} className="border border-stone-900">
      <div className="w-full flex flex-col gap-4 items-start pt-2 pb-2.5 px-1">
        <div className="flex gap-2 items-center text-sm text-stone-600 w-full shrink-0 font-semibold flex-wrap">
          <Web3Icon
            chainId={permission.chainId}
            iconsPack={chainsIconsPack}
            className="w-6 h-6"
          />
          <span>{getChainName(permission.chainId)}</span>
          <span className="text-stone-400">/</span>
          <span>{permission.system}</span>
          <span className="text-stone-400">/</span>
          <a
            href={getExplorerLink(
              permission.contractAddress,
              permission.chainId
            )}
            className="underline underline-offset-2 decoration-stone-200 decoration-2 hover:decoration-stone-700 flex items-center gap-1"
            target="_blank"
            rel="noopener noreferrer"
          >
            {permission.contract}
          </a>
          <div className="gap-2 items-center ml-auto hidden sm:flex">
            <div className="text-stone-400 text-xs uppercase tracking-wide font-semibold">
              {permission.type}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 w-full">
          <h2 className="font-mono text-sm sm:text-lg">{permission.name}</h2>
        </div>
        <div className="flex gap-2 flex-wrap items-center">
          {permission.functions.map((f, i) => (
            <div
              className="flex gap-1 items-center bg-stone-100 border border-stone-200 pl-1 pr-1.5 py-1 text-xs font-mono rounded-sm"
              key={f + i}
            >
              <SquareFunction className="w-4 h-4 text-stone-400" /> {f}
            </div>
          ))}
        </div>
      </div>
    </Block>
  );
}
