import { type Address } from "viem";
import * as chains from "viem/chains";

export function getExplorerLink(address: Address, chainId: number): string {
  const chain = Object.values(chains).find((c) => c.id === chainId);
  if (!chain?.blockExplorers?.default) {
    return `https://etherscan.io/address/${address}`;
  }

  return `${chain.blockExplorers.default.url}/address/${address}`;
}

export function getChainName(chainId: number): string {
  const chain = Object.values(chains).find((c) => c.id === chainId);
  if (!chain) {
    return 'Unknown Chain';
  }

  return chain.name;
}
