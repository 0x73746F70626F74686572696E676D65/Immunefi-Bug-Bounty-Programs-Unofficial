import { type Address } from "viem";

export interface Permission {
  chainId: number;
  system: string;
  contract: string;
  contractAddress: Address;
  type: "modifier" | "role";
  name: string;
  functions: string[];
  address: Address;
  owners: Address[];
  threshold: number;
}

export type AccessRight = {
  roleName: string;
  multisig: Address;
  owners: Address[];
  threshold: number;
  contracts: Array<{
    system: string;
    name: string;
    address: Address;
    functions: string[];
  }>;
};

export interface ContractData {
  address: Address;
  modifiers?: ModifierData[];
}

export interface ModifierData {
  modifier: string;
  functions: string[];
  addresses: AddressData[];
}

export interface AddressData {
  address: Address;
  owners: Address[];
  signersThreshold: number;
}

export interface SystemData {
  contracts?: Record<string, ContractData>;
  roles?: {
    role: Record<string, Address[]>;
  };
  gsmRoles?: Record<
    string,
    {
      role: Record<string, Address[]>;
    }
  >;
  govV3?: {
    ggRoles: {
      role: Record<string, Address[]>;
    };
    contracts?: Record<string, ContractData>;
  };
}

export type SafeWalletMap = {
  [address: string]: {
    owners: Address[];
    threshold: number;
    permissions: Permission[];
  };
};

export type OwnerMap = {
  [owner: string]: Set<string>;
};

export type ChainPermissionsData = {
  permissions: Permission[];
  safeWalletMap: SafeWalletMap;
  ownerMap: OwnerMap;
};
