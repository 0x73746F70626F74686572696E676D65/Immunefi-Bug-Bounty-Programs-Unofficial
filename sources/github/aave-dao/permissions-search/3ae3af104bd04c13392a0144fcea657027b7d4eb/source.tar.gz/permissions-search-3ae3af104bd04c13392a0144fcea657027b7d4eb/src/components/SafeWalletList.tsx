import React from "react";
import { type SafeWalletMap } from "@/types";
import { Block } from "./ui/Block";
import SearchResult from "./SearchResult";
import SafeHeader from "./SafeHeader";
import { type Address } from "viem";

export default function SafeWalletList({
  safeWallets,
}: {
  safeWallets: SafeWalletMap;
}) {
  return (
    <>
      {Object.entries(safeWallets).map(([address, wallet]) => (
        <React.Fragment key={address}>
          <Block className="border-stone-900 p-0">
            <SafeHeader
              address={address as Address}
              threshold={wallet.threshold}
              ownersCount={wallet.owners.length}
              isSigner
            />
          </Block>
          {wallet.permissions.map((p) => (
            <SearchResult
              key={`${p.chainId}-${p.system}-${p.contract}-${p.address}-${p.type}-${p.name}`}
              permission={p}
            />
          ))}
        </React.Fragment>
      ))}
    </>
  );
}
