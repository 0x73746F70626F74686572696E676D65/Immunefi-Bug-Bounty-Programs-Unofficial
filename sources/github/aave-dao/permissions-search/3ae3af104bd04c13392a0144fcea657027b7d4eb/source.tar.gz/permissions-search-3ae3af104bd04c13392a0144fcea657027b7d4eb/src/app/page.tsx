import { Suspense } from "react";
import Search from "@/components/Search";
import SearchSkeleton from "@/components/SearchSkeleton";
import { fetchChainPermissions } from "@/utils/fetchChainPermissions";
import { Footer } from "@/components/Footer";
import logo from "@/assets/logo.svg";
import Image from "next/image";

export default async function Home() {
  const { permissions, safeWalletMap, ownerMap } =
    await fetchChainPermissions();

  return (
    <main className="flex min-h-screen flex-col items-center justify-start pb-8 pt-16 sm:pt-36 pl-2 pr-4">
      <Image
        src={logo}
        alt="Aave Search"
        className="mb-7 w-36 sm:w-44"
        priority
      />
      <Suspense fallback={<SearchSkeleton />}>
        <Search
          permissions={permissions}
          safeWalletMap={safeWalletMap}
          ownerMap={ownerMap}
        />
      </Suspense>
      <Footer />
    </main>
  );
}

export const revalidate = 3600;
