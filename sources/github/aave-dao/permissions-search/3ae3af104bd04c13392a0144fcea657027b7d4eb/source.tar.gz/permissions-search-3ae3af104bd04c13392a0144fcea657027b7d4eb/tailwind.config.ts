import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        block: {
          border: "stone-950",
          left: "rgb(var(--block-left) / <alpha-value>)",
          bottom: "rgb(var(--block-bottom) / <alpha-value>)",
        }
      },
    },
  },
  plugins: [],
};
export default config;
