# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [4.71.0](https://github.com/aave-dao/aave-address-book/compare/v4.70.3...v4.71.0) (2026-09-28)


### Features

* add LlamaRisk PT contracts on Plasma ([#1581](https://github.com/aave-dao/aave-address-book/issues/1581)) ([28d6d02](https://github.com/aave-dao/aave-address-book/commit/28d6d0206538593d006704b4f58500129b88b11b))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1591](https://github.com/aave-dao/aave-address-book/issues/1591)) ([f6fcd27](https://github.com/aave-dao/aave-address-book/commit/f6fcd27537cd5b6e056b64fe875e9efd45ffe0c9))

## [4.70.3](https://github.com/aave-dao/aave-address-book/compare/v4.70.2...v4.70.3) (2026-09-26)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1589](https://github.com/aave-dao/aave-address-book/issues/1589)) ([b194cc2](https://github.com/aave-dao/aave-address-book/commit/b194cc288855bf1d7a40a0810e04cd9a428c59ce))

## [4.70.2](https://github.com/aave-dao/aave-address-book/compare/v4.70.1...v4.70.2) (2026-09-23)


### Bug Fixes

* replace Base V4 Risk Steward with newly deployed version ([#1587](https://github.com/aave-dao/aave-address-book/issues/1587)) ([1d14a5a](https://github.com/aave-dao/aave-address-book/commit/1d14a5af26f8401ea2773cb90294a71b7366adaa))

## [4.70.1](https://github.com/aave-dao/aave-address-book/compare/v4.70.0...v4.70.1) (2026-09-23)


### Bug Fixes

* bump ui toolbox to 0.6.1 for arc explorer links ([#1583](https://github.com/aave-dao/aave-address-book/issues/1583)) ([759dc04](https://github.com/aave-dao/aave-address-book/commit/759dc04ae73e0a551059c4f711e9ae31e3ea262c))

## [4.70.0](https://github.com/aave-dao/aave-address-book/compare/v4.69.2...v4.70.0) (2026-09-22)


### Features

* Risk Stewards V4 ([#1580](https://github.com/aave-dao/aave-address-book/issues/1580)) ([04efbda](https://github.com/aave-dao/aave-address-book/commit/04efbdacbe395089716ed7f91cff84f6f5bb83a1))

## [4.69.2](https://github.com/aave-dao/aave-address-book/compare/v4.69.1...v4.69.2) (2026-09-22)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1578](https://github.com/aave-dao/aave-address-book/issues/1578)) ([f52d598](https://github.com/aave-dao/aave-address-book/commit/f52d598c16a4d38176623744cab516969e1a88a8))

## [4.69.1](https://github.com/aave-dao/aave-address-book/compare/v4.69.0...v4.69.1) (2026-09-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1576](https://github.com/aave-dao/aave-address-book/issues/1576)) ([5c9663b](https://github.com/aave-dao/aave-address-book/commit/5c9663bcc4addbb023561b36a50f001d5c396c04))

## [4.69.0](https://github.com/aave-dao/aave-address-book/compare/v4.68.3...v4.69.0) (2026-09-21)


### Features

* Base V4 stocks market ([#1569](https://github.com/aave-dao/aave-address-book/issues/1569)) ([02a9bb4](https://github.com/aave-dao/aave-address-book/commit/02a9bb4edc1e62e37736f4e28ce01b2bc6f945f8))

## [4.68.3](https://github.com/aave-dao/aave-address-book/compare/v4.68.2...v4.68.3) (2026-09-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1572](https://github.com/aave-dao/aave-address-book/issues/1572)) ([afdc888](https://github.com/aave-dao/aave-address-book/commit/afdc888680847330ae4fc0611e6cdae7d9ccd4f6))

## [4.68.2](https://github.com/aave-dao/aave-address-book/compare/v4.68.1...v4.68.2) (2026-09-19)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1570](https://github.com/aave-dao/aave-address-book/issues/1570)) ([7a5dd38](https://github.com/aave-dao/aave-address-book/commit/7a5dd381e3ab1bf6f1e073a9b6e5be7df0487f05))

## [4.68.1](https://github.com/aave-dao/aave-address-book/compare/v4.68.0...v4.68.1) (2026-09-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1565](https://github.com/aave-dao/aave-address-book/issues/1565)) ([6d5a892](https://github.com/aave-dao/aave-address-book/commit/6d5a892797c39ef93dd9e06938c71f542e5f6c3f))

## [4.68.0](https://github.com/aave-dao/aave-address-book/compare/v4.67.4...v4.68.0) (2026-09-14)


### Features

* add PAXG Gold Spoke ([#1549](https://github.com/aave-dao/aave-address-book/issues/1549)) ([8b9e5a0](https://github.com/aave-dao/aave-address-book/commit/8b9e5a08cabe91749f89e98b8facb9f9e82ace9b))

## [4.67.4](https://github.com/aave-dao/aave-address-book/compare/v4.67.3...v4.67.4) (2026-09-13)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1562](https://github.com/aave-dao/aave-address-book/issues/1562)) ([e886344](https://github.com/aave-dao/aave-address-book/commit/e8863441f97c64b75f2ac51dfc368a820238677d))

## [4.67.3](https://github.com/aave-dao/aave-address-book/compare/v4.67.2...v4.67.3) (2026-09-12)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1560](https://github.com/aave-dao/aave-address-book/issues/1560)) ([1eaa70a](https://github.com/aave-dao/aave-address-book/commit/1eaa70a14470972a8d9ba9778ff34b4a70c67463))

## [4.67.2](https://github.com/aave-dao/aave-address-book/compare/v4.67.1...v4.67.2) (2026-09-11)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1558](https://github.com/aave-dao/aave-address-book/issues/1558)) ([f58e72c](https://github.com/aave-dao/aave-address-book/commit/f58e72c8fb6a052fa6fde3c9f0b0758e26691c7d))

## [4.67.1](https://github.com/aave-dao/aave-address-book/compare/v4.67.0...v4.67.1) (2026-09-10)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1555](https://github.com/aave-dao/aave-address-book/issues/1555)) ([4bd8331](https://github.com/aave-dao/aave-address-book/commit/4bd8331720444c3fb2b6872c32e6ff594f60291e))
* **cache:** automated cache update - updated addresses ([#1556](https://github.com/aave-dao/aave-address-book/issues/1556)) ([2c6bd07](https://github.com/aave-dao/aave-address-book/commit/2c6bd07f325651ca46eb3e736f96d863aeb7795a))

## [4.67.0](https://github.com/aave-dao/aave-address-book/compare/v4.66.4...v4.67.0) (2026-09-09)


### Features

* Aave V4 on Arc mainnet ([#1550](https://github.com/aave-dao/aave-address-book/issues/1550)) ([dd8bd67](https://github.com/aave-dao/aave-address-book/commit/dd8bd67401e9c656061c0ac4dff777da25bca884))

## [4.66.4](https://github.com/aave-dao/aave-address-book/compare/v4.66.3...v4.66.4) (2026-09-07)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1543](https://github.com/aave-dao/aave-address-book/issues/1543)) ([869afcb](https://github.com/aave-dao/aave-address-book/commit/869afcb6775f161e2beb2c28b88247b380b3ec17))

## [4.66.3](https://github.com/aave-dao/aave-address-book/compare/v4.66.2...v4.66.3) (2026-08-27)


### Bug Fixes

* add horizon RwaATokenManager and RWA oracle params registry ([#1532](https://github.com/aave-dao/aave-address-book/issues/1532)) ([723eda0](https://github.com/aave-dao/aave-address-book/commit/723eda0fb7079426934529cd77e1857b94351b77))

## [4.66.2](https://github.com/aave-dao/aave-address-book/compare/v4.66.1...v4.66.2) (2026-08-27)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1540](https://github.com/aave-dao/aave-address-book/issues/1540)) ([c69d6ca](https://github.com/aave-dao/aave-address-book/commit/c69d6ca77fc42bbfbb1555b3a6b5501497b91f0f))

## [4.66.1](https://github.com/aave-dao/aave-address-book/compare/v4.66.0...v4.66.1) (2026-08-26)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1538](https://github.com/aave-dao/aave-address-book/issues/1538)) ([e54254d](https://github.com/aave-dao/aave-address-book/commit/e54254dfd643e0c2db5bd60fa4f35579c66be255))
* use aave-dao foundry-setup action, stale foundry-toolchain pin breaks foundryup ([#1537](https://github.com/aave-dao/aave-address-book/issues/1537)) ([37e5c5d](https://github.com/aave-dao/aave-address-book/commit/37e5c5dbc670ffc23450e43fdbda209020234ae6))

## [4.66.0](https://github.com/aave-dao/aave-address-book/compare/v4.65.9...v4.66.0) (2026-08-21)


### Features

* add LlamaRisk contracts on Ethereum ([#1527](https://github.com/aave-dao/aave-address-book/issues/1527)) ([ef9acb1](https://github.com/aave-dao/aave-address-book/commit/ef9acb153bbfda5258c77dd25d57537343bcaab9))

## [4.65.9](https://github.com/aave-dao/aave-address-book/compare/v4.65.8...v4.65.9) (2026-08-20)


### Bug Fixes

* type umbrella stake tokens ([#1529](https://github.com/aave-dao/aave-address-book/issues/1529)) ([600aa9d](https://github.com/aave-dao/aave-address-book/commit/600aa9d1c85b80b05cdc19aafda93fcf0a1ec03c))

## [4.65.8](https://github.com/aave-dao/aave-address-book/compare/v4.65.7...v4.65.8) (2026-08-20)


### Bug Fixes

* complete Umbrella interface ([#1528](https://github.com/aave-dao/aave-address-book/issues/1528)) ([ffa72a9](https://github.com/aave-dao/aave-address-book/commit/ffa72a90a4e1a0a3865b206b68d02677e05dbe68))

## [4.65.7](https://github.com/aave-dao/aave-address-book/compare/v4.65.6...v4.65.7) (2026-08-18)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1525](https://github.com/aave-dao/aave-address-book/issues/1525)) ([3313ebd](https://github.com/aave-dao/aave-address-book/commit/3313ebdafaf17ad80a7463f437ee9fa60b11b73d))

## [4.65.6](https://github.com/aave-dao/aave-address-book/compare/v4.65.5...v4.65.6) (2026-08-17)


### Bug Fixes

* remove Paxos exception & skip deactivated Spokes & add missing Risk Council address ([#1522](https://github.com/aave-dao/aave-address-book/issues/1522)) ([81de698](https://github.com/aave-dao/aave-address-book/commit/81de698ada0c07410ebd920183da65740aa12a7d))

## [4.65.5](https://github.com/aave-dao/aave-address-book/compare/v4.65.4...v4.65.5) (2026-08-08)


### Bug Fixes

* add FRONTIER_STADER wallet ([#1435](https://github.com/aave-dao/aave-address-book/issues/1435)) ([a2059ad](https://github.com/aave-dao/aave-address-book/commit/a2059ad937310dfebb7e03a355cdd5f9cea23ecb))

## [4.65.4](https://github.com/aave-dao/aave-address-book/compare/v4.65.3...v4.65.4) (2026-08-08)


### Bug Fixes

* Add service provider addresses ([#1461](https://github.com/aave-dao/aave-address-book/issues/1461)) ([6212836](https://github.com/aave-dao/aave-address-book/commit/6212836c50116e282b0a9a98846c4e12e319e2dd))

## [4.65.3](https://github.com/aave-dao/aave-address-book/compare/v4.65.2...v4.65.3) (2026-08-08)


### Bug Fixes

* Ahab safe Ink Plasma and Monad ([#1436](https://github.com/aave-dao/aave-address-book/issues/1436)) ([17a38cb](https://github.com/aave-dao/aave-address-book/commit/17a38cb480eae2ce3d6dbf2c47485cc22baeeeee))

## [4.65.2](https://github.com/aave-dao/aave-address-book/compare/v4.65.1...v4.65.2) (2026-08-07)


### Bug Fixes

* add TokenLogic Execution and Stable Vault safes ([#1497](https://github.com/aave-dao/aave-address-book/issues/1497)) ([984c700](https://github.com/aave-dao/aave-address-book/commit/984c700df4400bf06a81da2ab7c4d810e538e0fd))

## [4.65.1](https://github.com/aave-dao/aave-address-book/compare/v4.65.0...v4.65.1) (2026-08-07)


### Bug Fixes

* read API release version in workflow ([#1515](https://github.com/aave-dao/aave-address-book/issues/1515)) ([ffd0c5b](https://github.com/aave-dao/aave-address-book/commit/ffd0c5b753bb6a09201a3a4829b1c62e9f0ee246))

## [4.65.0](https://github.com/aave-dao/aave-address-book/compare/v4.64.0...v4.65.0) (2026-08-07)


### Features

* publish JSON API releases to S3 ([#1511](https://github.com/aave-dao/aave-address-book/issues/1511)) ([b4aa2a3](https://github.com/aave-dao/aave-address-book/commit/b4aa2a3de01a3f38fa4d5ab18c275023f2f4ac71))

## [4.64.0](https://github.com/aave-dao/aave-address-book/compare/v4.63.0...v4.64.0) (2026-08-07)


### Features

* add static JSON address book API ([#1512](https://github.com/aave-dao/aave-address-book/issues/1512)) ([f423299](https://github.com/aave-dao/aave-address-book/commit/f423299bc1d25439595355020edc7b580bab3f18))

## [4.63.0](https://github.com/aave-dao/aave-address-book/compare/v4.62.6...v4.63.0) (2026-08-06)


### Features

* GHO GSM addresses (Monad) ([#1483](https://github.com/aave-dao/aave-address-book/issues/1483)) ([39aa509](https://github.com/aave-dao/aave-address-book/commit/39aa50989a68be6336dadc457b96b57fcd59f110))

## [4.62.6](https://github.com/aave-dao/aave-address-book/compare/v4.62.5...v4.62.6) (2026-08-06)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1508](https://github.com/aave-dao/aave-address-book/issues/1508)) ([f7feec7](https://github.com/aave-dao/aave-address-book/commit/f7feec73db9b6adf1797614981d50aac032e60b9))

## [4.62.5](https://github.com/aave-dao/aave-address-book/compare/v4.62.4...v4.62.5) (2026-08-05)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1506](https://github.com/aave-dao/aave-address-book/issues/1506)) ([a972adc](https://github.com/aave-dao/aave-address-book/commit/a972adcb42e70e85c2fa6a40e9e2f54b8ec9e01c))

## [4.62.4](https://github.com/aave-dao/aave-address-book/compare/v4.62.3...v4.62.4) (2026-08-04)


### Bug Fixes

* add network safes ([#1462](https://github.com/aave-dao/aave-address-book/issues/1462)) ([6965d4e](https://github.com/aave-dao/aave-address-book/commit/6965d4ec8e6c6dfc30c50f301dc83c58698e56e6))

## [4.62.3](https://github.com/aave-dao/aave-address-book/compare/v4.62.2...v4.62.3) (2026-08-04)


### Bug Fixes

* retire scroll sepolia ([#1503](https://github.com/aave-dao/aave-address-book/issues/1503)) ([0f7e4a2](https://github.com/aave-dao/aave-address-book/commit/0f7e4a2d8900b9a21048c5a550bf37e04ecdc304))

## [4.62.2](https://github.com/aave-dao/aave-address-book/compare/v4.62.1...v4.62.2) (2026-08-04)


### Bug Fixes

* add exception for deprecated spokes & fix generation ([#1501](https://github.com/aave-dao/aave-address-book/issues/1501)) ([a9e755c](https://github.com/aave-dao/aave-address-book/commit/a9e755c049951798203c75f0f64c4b1c57d2ab2a))

## [4.62.1](https://github.com/aave-dao/aave-address-book/compare/v4.62.0...v4.62.1) (2026-08-01)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1499](https://github.com/aave-dao/aave-address-book/issues/1499)) ([65425c3](https://github.com/aave-dao/aave-address-book/commit/65425c34a0ea8724dcbb51a8a1abb69baf8ef93a))

## [4.62.0](https://github.com/aave-dao/aave-address-book/compare/v4.61.2...v4.62.0) (2026-07-31)


### Features

* USDG Maple Spoke ([#1491](https://github.com/aave-dao/aave-address-book/issues/1491)) ([be170c1](https://github.com/aave-dao/aave-address-book/commit/be170c1a694018ca44b489696e9444074d900d07))

## [4.61.2](https://github.com/aave-dao/aave-address-book/compare/v4.61.1...v4.61.2) (2026-07-25)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1494](https://github.com/aave-dao/aave-address-book/issues/1494)) ([c3270e5](https://github.com/aave-dao/aave-address-book/commit/c3270e5aac80c3779b7b1cd40dabcff60d414c78))

## [4.61.1](https://github.com/aave-dao/aave-address-book/compare/v4.61.0...v4.61.1) (2026-07-23)


### Bug Fixes

* V4 ABI generator & export ([#1492](https://github.com/aave-dao/aave-address-book/issues/1492)) ([41d68bf](https://github.com/aave-dao/aave-address-book/commit/41d68bf58998f36f959bb81ac6d75b787320122c))

## [4.61.0](https://github.com/aave-dao/aave-address-book/compare/v4.60.1...v4.61.0) (2026-07-22)


### Features

* replace V4 Config Engines ([#1487](https://github.com/aave-dao/aave-address-book/issues/1487)) ([5017db7](https://github.com/aave-dao/aave-address-book/commit/5017db7e40ba290be681b3f51da59befda3f0688))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1489](https://github.com/aave-dao/aave-address-book/issues/1489)) ([e8058f7](https://github.com/aave-dao/aave-address-book/commit/e8058f721d195d119198a95dd08a1928c0951a86))

## [4.60.1](https://github.com/aave-dao/aave-address-book/compare/v4.60.0...v4.60.1) (2026-07-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1484](https://github.com/aave-dao/aave-address-book/issues/1484)) ([657a679](https://github.com/aave-dao/aave-address-book/commit/657a679b6a0b25d220044aa6a81721036d71f2d3))

## [4.60.0](https://github.com/aave-dao/aave-address-book/compare/v4.59.0...v4.60.0) (2026-07-09)


### Features

* add monad risk steward ([#1481](https://github.com/aave-dao/aave-address-book/issues/1481)) ([3a8be60](https://github.com/aave-dao/aave-address-book/commit/3a8be6043d8d8dd7f13978524ce7289892b1bdbf))

## [4.59.0](https://github.com/aave-dao/aave-address-book/compare/v4.58.0...v4.59.0) (2026-07-09)


### Features

* V4 IR Strategies ([#1479](https://github.com/aave-dao/aave-address-book/issues/1479)) ([1b1546e](https://github.com/aave-dao/aave-address-book/commit/1b1546e4100ce7da88ed80bd571344fa50136d4b))

## [4.58.0](https://github.com/aave-dao/aave-address-book/compare/v4.57.4...v4.58.0) (2026-07-09)


### Features

* v4 avalanche deployment ([#1473](https://github.com/aave-dao/aave-address-book/issues/1473)) ([902d4d6](https://github.com/aave-dao/aave-address-book/commit/902d4d636bfd430dd1b54eada075d4728739af72))

## [4.57.4](https://github.com/aave-dao/aave-address-book/compare/v4.57.3...v4.57.4) (2026-07-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1475](https://github.com/aave-dao/aave-address-book/issues/1475)) ([79910cb](https://github.com/aave-dao/aave-address-book/commit/79910cb844d653c39b5fc4f8173f471a3a9d5d88))

## [4.57.3](https://github.com/aave-dao/aave-address-book/compare/v4.57.2...v4.57.3) (2026-07-05)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1471](https://github.com/aave-dao/aave-address-book/issues/1471)) ([a7be166](https://github.com/aave-dao/aave-address-book/commit/a7be166ebcc34e04435eb3e6993a83b0eaf19b55))

## [4.57.2](https://github.com/aave-dao/aave-address-book/compare/v4.57.1...v4.57.2) (2026-07-04)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1469](https://github.com/aave-dao/aave-address-book/issues/1469)) ([0cf21c8](https://github.com/aave-dao/aave-address-book/commit/0cf21c8bd579aa21dbde12db218fb4d712bf98f6))

## [4.57.1](https://github.com/aave-dao/aave-address-book/compare/v4.57.0...v4.57.1) (2026-07-03)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1467](https://github.com/aave-dao/aave-address-book/issues/1467)) ([c980abc](https://github.com/aave-dao/aave-address-book/commit/c980abc7242db9ec965cf126360247d6d0c8ccac))

## [4.57.0](https://github.com/aave-dao/aave-address-book/compare/v4.56.2...v4.57.0) (2026-07-01)


### Features

* GHO monad ([#1463](https://github.com/aave-dao/aave-address-book/issues/1463)) ([5817dec](https://github.com/aave-dao/aave-address-book/commit/5817dec4e37764862492884c106f1b5e1a0d3ece))

## [4.56.2](https://github.com/aave-dao/aave-address-book/compare/v4.56.1...v4.56.2) (2026-07-01)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1464](https://github.com/aave-dao/aave-address-book/issues/1464)) ([5c96c15](https://github.com/aave-dao/aave-address-book/commit/5c96c156852eb2f3fefc5f2a3d53098cea3d90be))

## [4.56.1](https://github.com/aave-dao/aave-address-book/compare/v4.56.0...v4.56.1) (2026-06-30)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1457](https://github.com/aave-dao/aave-address-book/issues/1457)) ([8efac82](https://github.com/aave-dao/aave-address-book/commit/8efac82a18251f7892f93edd7d2f691af89b6df7))
* **cache:** automated cache update - updated addresses ([#1458](https://github.com/aave-dao/aave-address-book/issues/1458)) ([4244443](https://github.com/aave-dao/aave-address-book/commit/42444431b5f7c17fbff4814ef3107f7f95013ef3))

## [4.56.0](https://github.com/aave-dao/aave-address-book/compare/v4.55.8...v4.56.0) (2026-06-29)


### Features

* label v4 paxos hub/spoke ([#1449](https://github.com/aave-dao/aave-address-book/issues/1449)) ([b36d9c9](https://github.com/aave-dao/aave-address-book/commit/b36d9c90c5a48b7d3eb0c9d8677f07dcabbb524f))

## [4.55.8](https://github.com/aave-dao/aave-address-book/compare/v4.55.7...v4.55.8) (2026-06-29)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1454](https://github.com/aave-dao/aave-address-book/issues/1454)) ([1087173](https://github.com/aave-dao/aave-address-book/commit/1087173dc0d671e83f05eaf67add4c9622c6a500))

## [4.55.7](https://github.com/aave-dao/aave-address-book/compare/v4.55.6...v4.55.7) (2026-06-29)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1452](https://github.com/aave-dao/aave-address-book/issues/1452)) ([ad35d34](https://github.com/aave-dao/aave-address-book/commit/ad35d3403b02ff0b4ce27acc23b92781b44f78f4))

## [4.55.6](https://github.com/aave-dao/aave-address-book/compare/v4.55.5...v4.55.6) (2026-06-28)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1450](https://github.com/aave-dao/aave-address-book/issues/1450)) ([806b260](https://github.com/aave-dao/aave-address-book/commit/806b26078fd20d947af8a344ccb9b79aa445683b))

## [4.55.5](https://github.com/aave-dao/aave-address-book/compare/v4.55.4...v4.55.5) (2026-06-26)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1447](https://github.com/aave-dao/aave-address-book/issues/1447)) ([0e13241](https://github.com/aave-dao/aave-address-book/commit/0e132411634561ec92f3aac2b24367e28fda0170))
* update libs cron should update verified cache ([#1444](https://github.com/aave-dao/aave-address-book/issues/1444)) ([30c0bd8](https://github.com/aave-dao/aave-address-book/commit/30c0bd884ff01e1e3a4c2dc16801de0e8cb4088a))

## [4.55.4](https://github.com/aave-dao/aave-address-book/compare/v4.55.3...v4.55.4) (2026-06-26)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1442](https://github.com/aave-dao/aave-address-book/issues/1442)) ([a57a24d](https://github.com/aave-dao/aave-address-book/commit/a57a24d7815ef2e33ef7610528a76a3213a47a0f))

## [4.55.3](https://github.com/aave-dao/aave-address-book/compare/v4.55.2...v4.55.3) (2026-06-24)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1437](https://github.com/aave-dao/aave-address-book/issues/1437)) ([86e3ab7](https://github.com/aave-dao/aave-address-book/commit/86e3ab73939b5580d6b4642ac8bf52b6a9a9ceb7))
* **cache:** automated cache update - updated addresses ([#1439](https://github.com/aave-dao/aave-address-book/issues/1439)) ([ea75760](https://github.com/aave-dao/aave-address-book/commit/ea757608157de280929e1ba3741db60192addae4))

## [4.55.2](https://github.com/aave-dao/aave-address-book/compare/v4.55.1...v4.55.2) (2026-06-22)


### Bug Fixes

* **deps:** bump lib/aave-v4 from `1e8de86` to `8f497eb` ([#1432](https://github.com/aave-dao/aave-address-book/issues/1432)) ([abe03a4](https://github.com/aave-dao/aave-address-book/commit/abe03a46ebd9a065ffd0fcb7cfc831c7f2accc1e))

## [4.55.1](https://github.com/aave-dao/aave-address-book/compare/v4.55.0...v4.55.1) (2026-06-22)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1431](https://github.com/aave-dao/aave-address-book/issues/1431)) ([3a443e4](https://github.com/aave-dao/aave-address-book/commit/3a443e4fe3de9bc5912887929c506df788334057))

## [4.55.0](https://github.com/aave-dao/aave-address-book/compare/v4.54.0...v4.55.0) (2026-06-19)


### Features

* monad v3 ([#1427](https://github.com/aave-dao/aave-address-book/issues/1427)) ([a1e3a1e](https://github.com/aave-dao/aave-address-book/commit/a1e3a1ee5dcfd360e80dfb8eeec2871f02de54ff))

## [4.54.0](https://github.com/aave-dao/aave-address-book/compare/v4.53.1...v4.54.0) (2026-06-17)


### Features

* add monad ([#1422](https://github.com/aave-dao/aave-address-book/issues/1422)) ([fa2578e](https://github.com/aave-dao/aave-address-book/commit/fa2578e1cb17dc32561775c3ccc7e46da9bf24cc))

## [4.53.1](https://github.com/aave-dao/aave-address-book/compare/v4.53.0...v4.53.1) (2026-06-13)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1423](https://github.com/aave-dao/aave-address-book/issues/1423)) ([0ecf258](https://github.com/aave-dao/aave-address-book/commit/0ecf258aab6d833d3bbe596d22494984483b1c6c))

## [4.53.0](https://github.com/aave-dao/aave-address-book/compare/v4.52.9...v4.53.0) (2026-06-09)


### Features

* add budget incentive and Merkl distribution safes ([#1409](https://github.com/aave-dao/aave-address-book/issues/1409)) ([abec305](https://github.com/aave-dao/aave-address-book/commit/abec3058b81ff38e1796bd395b40a5ace6dc697f))

## [4.52.9](https://github.com/aave-dao/aave-address-book/compare/v4.52.8...v4.52.9) (2026-06-09)


### Bug Fixes

* reenable megaeth on verification ([#1417](https://github.com/aave-dao/aave-address-book/issues/1417)) ([182bb0b](https://github.com/aave-dao/aave-address-book/commit/182bb0bea42f0682bc3018d0acf1b42af7caa9d0))

## [4.52.8](https://github.com/aave-dao/aave-address-book/compare/v4.52.7...v4.52.8) (2026-06-06)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1415](https://github.com/aave-dao/aave-address-book/issues/1415)) ([582164a](https://github.com/aave-dao/aave-address-book/commit/582164a1f58b8d3868d4b9bb9f474f30f832ac11))

## [4.52.7](https://github.com/aave-dao/aave-address-book/compare/v4.52.6...v4.52.7) (2026-06-03)


### Bug Fixes

* **deps:** bump lib/aave-v3-origin from `4fbd744` to `d7919c0` ([#1412](https://github.com/aave-dao/aave-address-book/issues/1412)) ([f8bc52e](https://github.com/aave-dao/aave-address-book/commit/f8bc52ee0fd86a74fe32eebf383b801dc986931b))
* **deps:** bump lib/aave-v4 from `e2fb632` to `1e8de86` ([#1413](https://github.com/aave-dao/aave-address-book/issues/1413)) ([06ac9ac](https://github.com/aave-dao/aave-address-book/commit/06ac9ac07148877ade39c6301e4a0c37dbb78454))

## [4.52.6](https://github.com/aave-dao/aave-address-book/compare/v4.52.5...v4.52.6) (2026-06-03)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1410](https://github.com/aave-dao/aave-address-book/issues/1410)) ([5e43612](https://github.com/aave-dao/aave-address-book/commit/5e43612ec00f6cad0161e272ac03493dbe1abbd3))

## [4.52.5](https://github.com/aave-dao/aave-address-book/compare/v4.52.4...v4.52.5) (2026-06-01)


### Bug Fixes

* **deps:** bump lib/aave-v4 from `af1f0f2` to `e2fb632` ([#1401](https://github.com/aave-dao/aave-address-book/issues/1401)) ([e22b0fa](https://github.com/aave-dao/aave-address-book/commit/e22b0fa991261cb37241e39af18cc19c8d2fb06e))

## [4.52.4](https://github.com/aave-dao/aave-address-book/compare/v4.52.3...v4.52.4) (2026-06-01)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1403](https://github.com/aave-dao/aave-address-book/issues/1403)) ([d80404f](https://github.com/aave-dao/aave-address-book/commit/d80404f7d9ae4bc425bd4aa2fb381d44582d2fac))
* **cache:** automated cache update - updated addresses ([#1404](https://github.com/aave-dao/aave-address-book/issues/1404)) ([9b3aa1c](https://github.com/aave-dao/aave-address-book/commit/9b3aa1c6d2698efa058022b0d78acb82667f1171))

## [4.52.3](https://github.com/aave-dao/aave-address-book/compare/v4.52.2...v4.52.3) (2026-05-22)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1398](https://github.com/aave-dao/aave-address-book/issues/1398)) ([1972360](https://github.com/aave-dao/aave-address-book/commit/19723607ecbf352ab374590c8b993f3e3dbca744))

## [4.52.2](https://github.com/aave-dao/aave-address-book/compare/v4.52.1...v4.52.2) (2026-05-21)


### Bug Fixes

* add better config for treeshaking with modern bundlers ([#1394](https://github.com/aave-dao/aave-address-book/issues/1394)) ([0a61c1f](https://github.com/aave-dao/aave-address-book/commit/0a61c1f17d7b8d08d859be788ff0152a70edd43f))

## [4.52.1](https://github.com/aave-dao/aave-address-book/compare/v4.52.0...v4.52.1) (2026-05-20)


### Bug Fixes

* **deps:** bump lib/aave-v3-origin from `1e3d70c` to `f6f9cfc` ([#1395](https://github.com/aave-dao/aave-address-book/issues/1395)) ([0181771](https://github.com/aave-dao/aave-address-book/commit/0181771ce9e3ad0422e11dbf81e684345d6b3daf))

## [4.52.0](https://github.com/aave-dao/aave-address-book/compare/v4.51.0...v4.52.0) (2026-05-19)


### Features

* allSpokesRaw getter for v4 ([#1392](https://github.com/aave-dao/aave-address-book/issues/1392)) ([ac6a932](https://github.com/aave-dao/aave-address-book/commit/ac6a9326bdd7d2e19240bf574fb5c758a37833eb))

## [4.51.0](https://github.com/aave-dao/aave-address-book/compare/v4.50.0...v4.51.0) (2026-05-18)


### Features

* v4 getter library ([#1383](https://github.com/aave-dao/aave-address-book/issues/1383)) ([fe21ba4](https://github.com/aave-dao/aave-address-book/commit/fe21ba4e186a5982a24d791f55c9fd78fded440e))

## [4.50.0](https://github.com/aave-dao/aave-address-book/compare/v4.49.13...v4.50.0) (2026-05-18)


### Features

* Add sGho deployment ([#1377](https://github.com/aave-dao/aave-address-book/issues/1377)) ([6eac158](https://github.com/aave-dao/aave-address-book/commit/6eac158a825aaf49126f9cb036024183b400f190))

## [4.49.13](https://github.com/aave-dao/aave-address-book/compare/v4.49.12...v4.49.13) (2026-05-17)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1386](https://github.com/aave-dao/aave-address-book/issues/1386)) ([44303bb](https://github.com/aave-dao/aave-address-book/commit/44303bb4d2b61c12af2cb7bde7eb6e7aa56fdbcd))

## [4.49.12](https://github.com/aave-dao/aave-address-book/compare/v4.49.11...v4.49.12) (2026-05-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1384](https://github.com/aave-dao/aave-address-book/issues/1384)) ([b9cd3b7](https://github.com/aave-dao/aave-address-book/commit/b9cd3b7287852e3a9ff488df5b216e15c25c357b))

## [4.49.11](https://github.com/aave-dao/aave-address-book/compare/v4.49.10...v4.49.11) (2026-05-15)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1381](https://github.com/aave-dao/aave-address-book/issues/1381)) ([1f88ec1](https://github.com/aave-dao/aave-address-book/commit/1f88ec131bdea1fc24cc272f16b8a490f0443935))

## [4.49.10](https://github.com/aave-dao/aave-address-book/compare/v4.49.9...v4.49.10) (2026-05-10)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1379](https://github.com/aave-dao/aave-address-book/issues/1379)) ([06dd579](https://github.com/aave-dao/aave-address-book/commit/06dd57954698c6325affa8e4d77ab3ea0c0e5684))

## [4.49.9](https://github.com/aave-dao/aave-address-book/compare/v4.49.8...v4.49.9) (2026-05-07)


### Bug Fixes

* rename eSpokes & small fixes ([#1368](https://github.com/aave-dao/aave-address-book/issues/1368)) ([4ee7b50](https://github.com/aave-dao/aave-address-book/commit/4ee7b505d40760f48bcfdc4edd5fe3d532ec88d2))

## [4.49.8](https://github.com/aave-dao/aave-address-book/compare/v4.49.7...v4.49.8) (2026-05-01)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1375](https://github.com/aave-dao/aave-address-book/issues/1375)) ([2b5f43f](https://github.com/aave-dao/aave-address-book/commit/2b5f43fb2543790cbe8faf459f4b53a9cca0334a))

## [4.49.7](https://github.com/aave-dao/aave-address-book/compare/v4.49.6...v4.49.7) (2026-04-25)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1367](https://github.com/aave-dao/aave-address-book/issues/1367)) ([4af322d](https://github.com/aave-dao/aave-address-book/commit/4af322da7fc5f3df289fb84b6c82b2ffcf25861b))
* **cache:** automated cache update - updated addresses ([#1369](https://github.com/aave-dao/aave-address-book/issues/1369)) ([eeb0e64](https://github.com/aave-dao/aave-address-book/commit/eeb0e6441b6bbc8c12da8d2a6f9c157c1a862071))
* scroll tests ([#1371](https://github.com/aave-dao/aave-address-book/issues/1371)) ([545d741](https://github.com/aave-dao/aave-address-book/commit/545d7411d1a4e2012f2882c7ef8a51dac367fd54))

## [4.49.6](https://github.com/aave-dao/aave-address-book/compare/v4.49.5...v4.49.6) (2026-04-19)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1365](https://github.com/aave-dao/aave-address-book/issues/1365)) ([147c3af](https://github.com/aave-dao/aave-address-book/commit/147c3aff4bc6b8f377ca2ebbb0283b67048e23e9))

## [4.49.5](https://github.com/aave-dao/aave-address-book/compare/v4.49.4...v4.49.5) (2026-04-19)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1363](https://github.com/aave-dao/aave-address-book/issues/1363)) ([604779c](https://github.com/aave-dao/aave-address-book/commit/604779cf8655490833c41559ee4157115a76d269))

## [4.49.4](https://github.com/aave-dao/aave-address-book/compare/v4.49.3...v4.49.4) (2026-04-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1360](https://github.com/aave-dao/aave-address-book/issues/1360)) ([10c4e9d](https://github.com/aave-dao/aave-address-book/commit/10c4e9dd4d994aea5712b37f6208f9ce8f955704))

## [4.49.3](https://github.com/aave-dao/aave-address-book/compare/v4.49.2...v4.49.3) (2026-04-15)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1358](https://github.com/aave-dao/aave-address-book/issues/1358)) ([9cf7e9e](https://github.com/aave-dao/aave-address-book/commit/9cf7e9e7261480bf33c38553b01f3e916ef1e09a))

## [4.49.2](https://github.com/aave-dao/aave-address-book/compare/v4.49.1...v4.49.2) (2026-04-09)


### Bug Fixes

* update v4 config engine ([#1356](https://github.com/aave-dao/aave-address-book/issues/1356)) ([b6f98af](https://github.com/aave-dao/aave-address-book/commit/b6f98afbcc10b46b43e8f6f7c9d9655909209d44))

## [4.49.1](https://github.com/aave-dao/aave-address-book/compare/v4.49.0...v4.49.1) (2026-04-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1353](https://github.com/aave-dao/aave-address-book/issues/1353)) ([04a598c](https://github.com/aave-dao/aave-address-book/commit/04a598cd6b9bf5671caa111e6098be5fc9df9f5c))

## [4.49.0](https://github.com/aave-dao/aave-address-book/compare/v4.48.1...v4.49.0) (2026-04-08)


### Features

* aave v4 mainnet ([#1351](https://github.com/aave-dao/aave-address-book/issues/1351)) ([1f5539c](https://github.com/aave-dao/aave-address-book/commit/1f5539c59a7edde3d206db81d0b23fb1e963e5fc))

## [4.48.1](https://github.com/aave-dao/aave-address-book/compare/v4.48.0...v4.48.1) (2026-04-05)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1348](https://github.com/aave-dao/aave-address-book/issues/1348)) ([a9f5724](https://github.com/aave-dao/aave-address-book/commit/a9f5724c3a92d4d0bb7cb0514e928e6f097c7c42))

## [4.48.0](https://github.com/aave-dao/aave-address-book/compare/v4.47.14...v4.48.0) (2026-03-31)


### Features

* aave v3.6 ink sepolia testnet deployment ([#1343](https://github.com/aave-dao/aave-address-book/issues/1343)) ([1afa669](https://github.com/aave-dao/aave-address-book/commit/1afa66914c6574448ca4ead37ba697ab0a56cfab))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1342](https://github.com/aave-dao/aave-address-book/issues/1342)) ([3c84537](https://github.com/aave-dao/aave-address-book/commit/3c845370f1c547ca64c02c918ad4e664aef10c22))
* **cache:** automated cache update - updated addresses ([#1344](https://github.com/aave-dao/aave-address-book/issues/1344)) ([223566a](https://github.com/aave-dao/aave-address-book/commit/223566a9b62cca12763b6aa0046937b34f3ea5cf))
* **cache:** automated cache update - updated addresses ([#1346](https://github.com/aave-dao/aave-address-book/issues/1346)) ([172aaae](https://github.com/aave-dao/aave-address-book/commit/172aaaed1ca90336d396a907608125cef5bc4dbf))

## [4.47.14](https://github.com/aave-dao/aave-address-book/compare/v4.47.13...v4.47.14) (2026-03-27)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1340](https://github.com/aave-dao/aave-address-book/issues/1340)) ([fc70123](https://github.com/aave-dao/aave-address-book/commit/fc70123afec30a464fee445ee16904e2078a19f2))

## [4.47.13](https://github.com/aave-dao/aave-address-book/compare/v4.47.12...v4.47.13) (2026-03-24)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1336](https://github.com/aave-dao/aave-address-book/issues/1336)) ([d71e4bb](https://github.com/aave-dao/aave-address-book/commit/d71e4bb7ca58c6172a44aabe6217ba55d041f7f0))
* **cache:** automated cache update - updated addresses ([#1337](https://github.com/aave-dao/aave-address-book/issues/1337)) ([33f295e](https://github.com/aave-dao/aave-address-book/commit/33f295ecbba9e1bbdb92fd8d5d2942291b5ceae0))

## [4.47.12](https://github.com/aave-dao/aave-address-book/compare/v4.47.11...v4.47.12) (2026-03-19)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1331](https://github.com/aave-dao/aave-address-book/issues/1331)) ([3d01e63](https://github.com/aave-dao/aave-address-book/commit/3d01e636c19917781cd4d6cb1856f219b0bf9507))

## [4.47.11](https://github.com/aave-dao/aave-address-book/compare/v4.47.10...v4.47.11) (2026-03-18)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1327](https://github.com/aave-dao/aave-address-book/issues/1327)) ([70294b1](https://github.com/aave-dao/aave-address-book/commit/70294b1d9f1b3d260731f7f96b85cae5760db6f0))

## [4.47.10](https://github.com/aave-dao/aave-address-book/compare/v4.47.9...v4.47.10) (2026-03-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1325](https://github.com/aave-dao/aave-address-book/issues/1325)) ([7ef76cd](https://github.com/aave-dao/aave-address-book/commit/7ef76cd54e6f40e63703389ac0f4c8594d69828d))

## [4.47.9](https://github.com/aave-dao/aave-address-book/compare/v4.47.8...v4.47.9) (2026-03-15)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1323](https://github.com/aave-dao/aave-address-book/issues/1323)) ([e2c4ba9](https://github.com/aave-dao/aave-address-book/commit/e2c4ba9e902dac470df1ab18995829f85684ed12))

## [4.47.8](https://github.com/aave-dao/aave-address-book/compare/v4.47.7...v4.47.8) (2026-03-14)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1321](https://github.com/aave-dao/aave-address-book/issues/1321)) ([0010c07](https://github.com/aave-dao/aave-address-book/commit/0010c078cde897f1a0abeb4bf091c1badc1eacb0))

## [4.47.7](https://github.com/aave-dao/aave-address-book/compare/v4.47.6...v4.47.7) (2026-03-13)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1319](https://github.com/aave-dao/aave-address-book/issues/1319)) ([7eb4362](https://github.com/aave-dao/aave-address-book/commit/7eb4362c5085abfefb9e9dee11b60d6cd38c5a81))

## [4.47.6](https://github.com/aave-dao/aave-address-book/compare/v4.47.5...v4.47.6) (2026-03-11)


### Bug Fixes

* **deps:** bump peter-evans/create-pull-request ([#1317](https://github.com/aave-dao/aave-address-book/issues/1317)) ([94e2e15](https://github.com/aave-dao/aave-address-book/commit/94e2e156d9dca6cb8aba5cc5b7a6c3818d51a8b0))

## [4.47.5](https://github.com/aave-dao/aave-address-book/compare/v4.47.4...v4.47.5) (2026-03-11)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1315](https://github.com/aave-dao/aave-address-book/issues/1315)) ([999a285](https://github.com/aave-dao/aave-address-book/commit/999a28503aea80bb96717e90745025558ecff343))

## [4.47.4](https://github.com/aave-dao/aave-address-book/compare/v4.47.3...v4.47.4) (2026-03-10)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1313](https://github.com/aave-dao/aave-address-book/issues/1313)) ([578f166](https://github.com/aave-dao/aave-address-book/commit/578f16665b813a6b70ce41ea21a4e73847e46a9a))

## [4.47.3](https://github.com/aave-dao/aave-address-book/compare/v4.47.2...v4.47.3) (2026-03-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1310](https://github.com/aave-dao/aave-address-book/issues/1310)) ([c615318](https://github.com/aave-dao/aave-address-book/commit/c615318072e42aa12a02b35a417811db35c19ef0))

## [4.47.2](https://github.com/aave-dao/aave-address-book/compare/v4.47.1...v4.47.2) (2026-03-07)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1307](https://github.com/aave-dao/aave-address-book/issues/1307)) ([a3f6c5b](https://github.com/aave-dao/aave-address-book/commit/a3f6c5b9d45264b824ba67ea9cce74c78701c7c0))

## [4.47.1](https://github.com/aave-dao/aave-address-book/compare/v4.47.0...v4.47.1) (2026-03-07)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1305](https://github.com/aave-dao/aave-address-book/issues/1305)) ([57fb2af](https://github.com/aave-dao/aave-address-book/commit/57fb2af09c12f7cfa91fbb0fb38a6e28d05cf534))

## [4.47.0](https://github.com/aave-dao/aave-address-book/compare/v4.46.5...v4.47.0) (2026-03-06)


### Features

* add xLayer v3.6 contracts ([#1302](https://github.com/aave-dao/aave-address-book/issues/1302)) ([8bdb6d4](https://github.com/aave-dao/aave-address-book/commit/8bdb6d4842e922fd5c8b66a849fd958dd3972e93))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1299](https://github.com/aave-dao/aave-address-book/issues/1299)) ([0ccaa1f](https://github.com/aave-dao/aave-address-book/commit/0ccaa1f2b572335109725c1b7c4addec88e5e139))
* **cache:** automated cache update - updated addresses ([#1300](https://github.com/aave-dao/aave-address-book/issues/1300)) ([10553da](https://github.com/aave-dao/aave-address-book/commit/10553da732d1e8608d8251d8060573483dc1516f))

## [4.46.5](https://github.com/aave-dao/aave-address-book/compare/v4.46.4...v4.46.5) (2026-03-03)


### Bug Fixes

* **deps:** bump foundry-rs/foundry-toolchain from 1.6.0 to 1.7.0 ([#1281](https://github.com/aave-dao/aave-address-book/issues/1281)) ([76fe892](https://github.com/aave-dao/aave-address-book/commit/76fe8924997efde6b4182d904e3b666dd2ce4c83))

## [4.46.4](https://github.com/aave-dao/aave-address-book/compare/v4.46.3...v4.46.4) (2026-02-25)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1294](https://github.com/aave-dao/aave-address-book/issues/1294)) ([cb60af7](https://github.com/aave-dao/aave-address-book/commit/cb60af7fe92093888988da2c3517cfff0b6448ff))

## [4.46.3](https://github.com/aave-dao/aave-address-book/compare/v4.46.2...v4.46.3) (2026-02-24)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1292](https://github.com/aave-dao/aave-address-book/issues/1292)) ([1589efa](https://github.com/aave-dao/aave-address-book/commit/1589efaa9dc532c73178ed914ddb40cc92ccf462))

## [4.46.2](https://github.com/aave-dao/aave-address-book/compare/v4.46.1...v4.46.2) (2026-02-22)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1289](https://github.com/aave-dao/aave-address-book/issues/1289)) ([c38d287](https://github.com/aave-dao/aave-address-book/commit/c38d287ee4b6c1d83b2af4d9a209171b9f8b6f19))
* **cache:** automated cache update - updated addresses ([#1291](https://github.com/aave-dao/aave-address-book/issues/1291)) ([391f0af](https://github.com/aave-dao/aave-address-book/commit/391f0af358d174509f5cb7af1bc3004f2cdf3b18))

## [4.46.1](https://github.com/aave-dao/aave-address-book/compare/v4.46.0...v4.46.1) (2026-02-20)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1287](https://github.com/aave-dao/aave-address-book/issues/1287)) ([efd6e49](https://github.com/aave-dao/aave-address-book/commit/efd6e49d01503451abe12e01adf11aa6e4c79b25))

## [4.46.0](https://github.com/aave-dao/aave-address-book/compare/v4.45.0...v4.46.0) (2026-02-19)


### Features

* add risk agent contracts on ink ([#1277](https://github.com/aave-dao/aave-address-book/issues/1277)) ([8ddbfb1](https://github.com/aave-dao/aave-address-book/commit/8ddbfb167160f96a3314e6c36bf20385cd16e9cc))

## [4.45.0](https://github.com/aave-dao/aave-address-book/compare/v4.44.22...v4.45.0) (2026-02-19)


### Features

* move to the DAO ([#1280](https://github.com/aave-dao/aave-address-book/issues/1280)) ([c7f0c97](https://github.com/aave-dao/aave-address-book/commit/c7f0c9728a439dd19233f6aebbecc3a8b81df18f))


### Bug Fixes

* use bot token for ci & setup provenance ([#1284](https://github.com/aave-dao/aave-address-book/issues/1284)) ([abaf6ad](https://github.com/aave-dao/aave-address-book/commit/abaf6ad1748c4d339290d9ac0163f245878bdc14))

## [4.44.22](https://github.com/bgd-labs/aave-address-book/compare/v4.44.21...v4.44.22) (2026-02-18)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1278](https://github.com/bgd-labs/aave-address-book/issues/1278)) ([5b7a2b5](https://github.com/bgd-labs/aave-address-book/commit/5b7a2b522b893f92a4b4db761bf0e0e1249543ef))

## [4.44.21](https://github.com/bgd-labs/aave-address-book/compare/v4.44.20...v4.44.21) (2026-02-18)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1275](https://github.com/bgd-labs/aave-address-book/issues/1275)) ([d7e6c98](https://github.com/bgd-labs/aave-address-book/commit/d7e6c98d908a5364a5ba1f533b79179dfa4c1e30))

## [4.44.20](https://github.com/bgd-labs/aave-address-book/compare/v4.44.19...v4.44.20) (2026-02-16)


### Bug Fixes

* update orig ([#1273](https://github.com/bgd-labs/aave-address-book/issues/1273)) ([89e8965](https://github.com/bgd-labs/aave-address-book/commit/89e89652ca4cda50b6aca9cad0abe851df7a01a0))

## [4.44.19](https://github.com/bgd-labs/aave-address-book/compare/v4.44.18...v4.44.19) (2026-02-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1270](https://github.com/bgd-labs/aave-address-book/issues/1270)) ([337bb23](https://github.com/bgd-labs/aave-address-book/commit/337bb23c0b13c744ecb22e6fb649f745c16f1c48))

## [4.44.18](https://github.com/bgd-labs/aave-address-book/compare/v4.44.17...v4.44.18) (2026-02-15)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1268](https://github.com/bgd-labs/aave-address-book/issues/1268)) ([b3ef7f2](https://github.com/bgd-labs/aave-address-book/commit/b3ef7f2415ea5637765677566c20cf8c6e3307b4))

## [4.44.17](https://github.com/bgd-labs/aave-address-book/compare/v4.44.16...v4.44.17) (2026-02-14)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1266](https://github.com/bgd-labs/aave-address-book/issues/1266)) ([a4f4f76](https://github.com/bgd-labs/aave-address-book/commit/a4f4f7613d72ea99006c3f3ffb0ea14ff19b1d57))

## [4.44.16](https://github.com/bgd-labs/aave-address-book/compare/v4.44.15...v4.44.16) (2026-02-13)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1264](https://github.com/bgd-labs/aave-address-book/issues/1264)) ([cb6be09](https://github.com/bgd-labs/aave-address-book/commit/cb6be0925a60678fad7bace2309f8d722deed4d5))

## [4.44.15](https://github.com/bgd-labs/aave-address-book/compare/v4.44.14...v4.44.15) (2026-02-12)


### Bug Fixes

* add risk steward on ink ([#1262](https://github.com/bgd-labs/aave-address-book/issues/1262)) ([fba9540](https://github.com/bgd-labs/aave-address-book/commit/fba9540f44d30cfe9069b0c389d3521fdc7e6170))

## [4.44.14](https://github.com/bgd-labs/aave-address-book/compare/v4.44.13...v4.44.14) (2026-02-12)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1259](https://github.com/bgd-labs/aave-address-book/issues/1259)) ([e27345f](https://github.com/bgd-labs/aave-address-book/commit/e27345fd3c8ddf5a57df21fb410b74d5af8558f0))

## [4.44.13](https://github.com/bgd-labs/aave-address-book/compare/v4.44.12...v4.44.13) (2026-02-11)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1257](https://github.com/bgd-labs/aave-address-book/issues/1257)) ([12b47a3](https://github.com/bgd-labs/aave-address-book/commit/12b47a317c082a3b72a494f7261130ee42a432b7))

## [4.44.12](https://github.com/bgd-labs/aave-address-book/compare/v4.44.11...v4.44.12) (2026-02-11)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1255](https://github.com/bgd-labs/aave-address-book/issues/1255)) ([48cfb01](https://github.com/bgd-labs/aave-address-book/commit/48cfb018346816ddb8bafc9c8524bfdba8511f1f))

## [4.44.11](https://github.com/bgd-labs/aave-address-book/compare/v4.44.10...v4.44.11) (2026-02-10)


### Bug Fixes

* MegaEth explorer to etherscan ([#1250](https://github.com/bgd-labs/aave-address-book/issues/1250)) ([80ce37c](https://github.com/bgd-labs/aave-address-book/commit/80ce37cb8b9944d72699af0ea18f817498e4c6cb))

## [4.44.10](https://github.com/bgd-labs/aave-address-book/compare/v4.44.9...v4.44.10) (2026-02-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1251](https://github.com/bgd-labs/aave-address-book/issues/1251)) ([17cc275](https://github.com/bgd-labs/aave-address-book/commit/17cc2757f4123cc72708384ad54d529c091d13f2))

## [4.44.9](https://github.com/bgd-labs/aave-address-book/compare/v4.44.8...v4.44.9) (2026-02-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1248](https://github.com/bgd-labs/aave-address-book/issues/1248)) ([6ef4f37](https://github.com/bgd-labs/aave-address-book/commit/6ef4f3738afa213b440560f4c8de61156ac6e5b0))

## [4.44.8](https://github.com/bgd-labs/aave-address-book/compare/v4.44.7...v4.44.8) (2026-02-08)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1246](https://github.com/bgd-labs/aave-address-book/issues/1246)) ([fca9804](https://github.com/bgd-labs/aave-address-book/commit/fca98043f01564b4b76e751aa42266da6eed2eb3))

## [4.44.7](https://github.com/bgd-labs/aave-address-book/compare/v4.44.6...v4.44.7) (2026-02-07)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1244](https://github.com/bgd-labs/aave-address-book/issues/1244)) ([b5e3caa](https://github.com/bgd-labs/aave-address-book/commit/b5e3caa796f7240830648605fae929d3674cd960))

## [4.44.6](https://github.com/bgd-labs/aave-address-book/compare/v4.44.5...v4.44.6) (2026-02-05)


### Bug Fixes

* patch toolbox ([#1241](https://github.com/bgd-labs/aave-address-book/issues/1241)) ([5b6bc76](https://github.com/bgd-labs/aave-address-book/commit/5b6bc766271195f80c67b4c0612171212db9d205))

## [4.44.5](https://github.com/bgd-labs/aave-address-book/compare/v4.44.4...v4.44.5) (2026-02-05)


### Bug Fixes

* remove toolbox from client component ([#1239](https://github.com/bgd-labs/aave-address-book/issues/1239)) ([771513e](https://github.com/bgd-labs/aave-address-book/commit/771513e75c68a0a604fe9931fb1d36371bd78044))

## [4.44.4](https://github.com/bgd-labs/aave-address-book/compare/v4.44.3...v4.44.4) (2026-02-05)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1237](https://github.com/bgd-labs/aave-address-book/issues/1237)) ([c127b6e](https://github.com/bgd-labs/aave-address-book/commit/c127b6e519feac33c4adf8a579f8ea88d75bb96f))
* refresh lockfile ([5f7789c](https://github.com/bgd-labs/aave-address-book/commit/5f7789c4def33ac7a015ee57f2f9e0297a4c3966))

## [4.44.3](https://github.com/bgd-labs/aave-address-book/compare/v4.44.2...v4.44.3) (2026-02-04)


### Bug Fixes

* correct dependencies ([695344f](https://github.com/bgd-labs/aave-address-book/commit/695344f0bd4b71d07feacbe6b34f8d307a84c4e8))
* publish ([#1235](https://github.com/bgd-labs/aave-address-book/issues/1235)) ([63872c3](https://github.com/bgd-labs/aave-address-book/commit/63872c3255cf09162507cc385c9a0a0ca20f546a))

## [4.44.2](https://github.com/bgd-labs/aave-address-book/compare/v4.44.1...v4.44.2) (2026-02-03)


### Bug Fixes

* aave svr addresses ([#1233](https://github.com/bgd-labs/aave-address-book/issues/1233)) ([6dad8d1](https://github.com/bgd-labs/aave-address-book/commit/6dad8d1717b6adf590395c2b2d2327fe281b2b5a))

## [4.44.1](https://github.com/bgd-labs/aave-address-book/compare/v4.44.0...v4.44.1) (2026-02-01)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1231](https://github.com/bgd-labs/aave-address-book/issues/1231)) ([0b7bf4b](https://github.com/bgd-labs/aave-address-book/commit/0b7bf4b3b26a746a128fbe6a7b5e79dc8af462b3))

## [4.44.0](https://github.com/bgd-labs/aave-address-book/compare/v4.43.0...v4.44.0) (2026-01-30)


### Features

* gho on mantle ([#1226](https://github.com/bgd-labs/aave-address-book/issues/1226)) ([#1229](https://github.com/bgd-labs/aave-address-book/issues/1229)) ([dfec96d](https://github.com/bgd-labs/aave-address-book/commit/dfec96df26da9539c5e86d102fef2ecff6e3dfd9))

## [4.43.0](https://github.com/bgd-labs/aave-address-book/compare/v4.42.0...v4.43.0) (2026-01-30)


### Features

* new config engines ([#1227](https://github.com/bgd-labs/aave-address-book/issues/1227)) ([17a545d](https://github.com/bgd-labs/aave-address-book/commit/17a545d0b337170d4ffd812f774c31be5b21b960))

## [4.42.0](https://github.com/bgd-labs/aave-address-book/compare/v4.41.8...v4.42.0) (2026-01-28)


### Features

* Add MegaEth network ([#1195](https://github.com/bgd-labs/aave-address-book/issues/1195)) ([eb6cd70](https://github.com/bgd-labs/aave-address-book/commit/eb6cd708bed0033d60e2a7e2fca169bc7c5567a0))

## [4.41.8](https://github.com/bgd-labs/aave-address-book/compare/v4.41.7...v4.41.8) (2026-01-28)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1223](https://github.com/bgd-labs/aave-address-book/issues/1223)) ([95a7c72](https://github.com/bgd-labs/aave-address-book/commit/95a7c72b9309765cead21fa1f63ea57b8634a54a))

## [4.41.7](https://github.com/bgd-labs/aave-address-book/compare/v4.41.6...v4.41.7) (2026-01-26)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1220](https://github.com/bgd-labs/aave-address-book/issues/1220)) ([a9d01de](https://github.com/bgd-labs/aave-address-book/commit/a9d01dec9ba830fac72fead8186eeaa2bcdf3408))

## [4.41.6](https://github.com/bgd-labs/aave-address-book/compare/v4.41.5...v4.41.6) (2026-01-25)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1218](https://github.com/bgd-labs/aave-address-book/issues/1218)) ([e4757b1](https://github.com/bgd-labs/aave-address-book/commit/e4757b191d96294cb6446bd508f3858cf0bc5dbb))

## [4.41.5](https://github.com/bgd-labs/aave-address-book/compare/v4.41.4...v4.41.5) (2026-01-22)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1216](https://github.com/bgd-labs/aave-address-book/issues/1216)) ([91d7842](https://github.com/bgd-labs/aave-address-book/commit/91d78425b9ee30c57833e6e5e1f07bbedaac4819))

## [4.41.4](https://github.com/bgd-labs/aave-address-book/compare/v4.41.3...v4.41.4) (2026-01-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1214](https://github.com/bgd-labs/aave-address-book/issues/1214)) ([d92f569](https://github.com/bgd-labs/aave-address-book/commit/d92f569a0baa7eca04907a4531345408b3db17fb))

## [4.41.3](https://github.com/bgd-labs/aave-address-book/compare/v4.41.2...v4.41.3) (2026-01-20)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1212](https://github.com/bgd-labs/aave-address-book/issues/1212)) ([88dac05](https://github.com/bgd-labs/aave-address-book/commit/88dac0547dd12bc93dba1969a30ee8f55253cf9e))

## [4.41.2](https://github.com/bgd-labs/aave-address-book/compare/v4.41.1...v4.41.2) (2026-01-16)


### Bug Fixes

* release ([#1208](https://github.com/bgd-labs/aave-address-book/issues/1208)) ([46cda96](https://github.com/bgd-labs/aave-address-book/commit/46cda9679a1cf88fee8cd20b003362611c773d57))

## [4.41.1](https://github.com/bgd-labs/aave-address-book/compare/v4.41.0...v4.41.1) (2026-01-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1206](https://github.com/bgd-labs/aave-address-book/issues/1206)) ([2e2878b](https://github.com/bgd-labs/aave-address-book/commit/2e2878b2fafa6d0a02f54c3e54b5f19c898e00e9))
* ci release fix ([#1205](https://github.com/bgd-labs/aave-address-book/issues/1205)) ([b30c8d0](https://github.com/bgd-labs/aave-address-book/commit/b30c8d0552dff5f190968e25094ac54fb3e8d32a))

## [4.41.0](https://github.com/bgd-labs/aave-address-book/compare/v4.40.2...v4.41.0) (2026-01-15)


### Features

* add mantle v3.6 addresses ([#1202](https://github.com/bgd-labs/aave-address-book/issues/1202)) ([04ee5b9](https://github.com/bgd-labs/aave-address-book/commit/04ee5b91ffeac4b7695babb59da3a9c426b8b35e))

## [4.40.2](https://github.com/bgd-labs/aave-address-book/compare/v4.40.1...v4.40.2) (2026-01-14)


### Bug Fixes

* ci ([#1200](https://github.com/bgd-labs/aave-address-book/issues/1200)) ([2c3a790](https://github.com/bgd-labs/aave-address-book/commit/2c3a79061a47642b717a8964082707077b7add91))

## [4.40.1](https://github.com/bgd-labs/aave-address-book/compare/v4.40.0...v4.40.1) (2026-01-14)


### Bug Fixes

* remove basePath ([#1198](https://github.com/bgd-labs/aave-address-book/issues/1198)) ([0886aa7](https://github.com/bgd-labs/aave-address-book/commit/0886aa78e95ebbde9ca4c0a704abb88e9fb9ba4d))

## [4.40.0](https://github.com/bgd-labs/aave-address-book/compare/v4.39.3...v4.40.0) (2026-01-14)


### Features

* ui is automatically deployed to github pages ([#1196](https://github.com/bgd-labs/aave-address-book/issues/1196)) ([ff78c90](https://github.com/bgd-labs/aave-address-book/commit/ff78c9063d1cb300557621bb251a6ff4af16ec1f))

## [4.39.3](https://github.com/bgd-labs/aave-address-book/compare/v4.39.2...v4.39.3) (2026-01-13)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1192](https://github.com/bgd-labs/aave-address-book/issues/1192)) ([3061770](https://github.com/bgd-labs/aave-address-book/commit/3061770a5ab2c0fd6f95b7f36d081d0f8945f59c))
* **cache:** automated cache update - updated addresses ([#1194](https://github.com/bgd-labs/aave-address-book/issues/1194)) ([0ddb174](https://github.com/bgd-labs/aave-address-book/commit/0ddb1742cb86c5382d276972f30dca8d1cf53986))

## [4.39.2](https://github.com/bgd-labs/aave-address-book/compare/v4.39.1...v4.39.2) (2026-01-12)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1190](https://github.com/bgd-labs/aave-address-book/issues/1190)) ([7837472](https://github.com/bgd-labs/aave-address-book/commit/7837472f408bbee4a1432a0c8eb8e36b3a689000))

## [4.39.1](https://github.com/bgd-labs/aave-address-book/compare/v4.39.0...v4.39.1) (2026-01-12)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1188](https://github.com/bgd-labs/aave-address-book/issues/1188)) ([a58ddf1](https://github.com/bgd-labs/aave-address-book/commit/a58ddf1991417704241f8ba6e8546f951fbc136e))

## [4.39.0](https://github.com/bgd-labs/aave-address-book/compare/v4.38.2...v4.39.0) (2026-01-12)


### Features

* ltvzero 3.6 ([#1176](https://github.com/bgd-labs/aave-address-book/issues/1176)) ([ebf6f45](https://github.com/bgd-labs/aave-address-book/commit/ebf6f4583bdda90aa2fa56d7a597f3c9e28a3a28))


### Bug Fixes

* adds new v3.6 config engine ([#1174](https://github.com/bgd-labs/aave-address-book/issues/1174)) ([6793cd1](https://github.com/bgd-labs/aave-address-book/commit/6793cd155fb15115ece8285685590d2c9f56968e))
* **cache:** automated cache update - updated addresses ([#1179](https://github.com/bgd-labs/aave-address-book/issues/1179)) ([6784cd1](https://github.com/bgd-labs/aave-address-book/commit/6784cd15027790a9851c890a0aba6400fa1f8ca2))
* **cache:** automated cache update - updated addresses ([#1181](https://github.com/bgd-labs/aave-address-book/issues/1181)) ([a546db4](https://github.com/bgd-labs/aave-address-book/commit/a546db48b90f090c0c6be9f42a82b34e9942440e))
* **cache:** automated cache update - updated addresses ([#1182](https://github.com/bgd-labs/aave-address-book/issues/1182)) ([acb167b](https://github.com/bgd-labs/aave-address-book/commit/acb167b67d7e563034a4e2546b3184e7bf38d44a))
* **cache:** automated cache update - updated addresses ([#1183](https://github.com/bgd-labs/aave-address-book/issues/1183)) ([3e4217e](https://github.com/bgd-labs/aave-address-book/commit/3e4217ee87042bd70e5cb25bd80681ba8ca75931))
* **cache:** automated cache update - updated addresses ([#1184](https://github.com/bgd-labs/aave-address-book/issues/1184)) ([8655dac](https://github.com/bgd-labs/aave-address-book/commit/8655dacca0e68074ab207ed62302078b763f2496))
* **cache:** automated cache update - updated addresses ([#1185](https://github.com/bgd-labs/aave-address-book/issues/1185)) ([e623015](https://github.com/bgd-labs/aave-address-book/commit/e6230156519584332311fb0f76f21b9591167329))
* ci ([#1186](https://github.com/bgd-labs/aave-address-book/issues/1186)) ([f9902b0](https://github.com/bgd-labs/aave-address-book/commit/f9902b0b5aa01ae0e13cd0f41b2fcfe1d676d7cd))
* make tests run on ci prs ([#1173](https://github.com/bgd-labs/aave-address-book/issues/1173)) ([e988638](https://github.com/bgd-labs/aave-address-book/commit/e9886380f914180368b104b83310aa9644a9634f))
* use gh app ([dc0d3c6](https://github.com/bgd-labs/aave-address-book/commit/dc0d3c6b0af996b624bbcaf4a120dc5525dd4e7b))

## [4.38.2](https://github.com/bgd-labs/aave-address-book/compare/v4.38.1...v4.38.2) (2026-01-07)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1170](https://github.com/bgd-labs/aave-address-book/issues/1170)) ([785f85f](https://github.com/bgd-labs/aave-address-book/commit/785f85fd8c032c1da31150ebf66cf319fb83ae62))

## [4.38.1](https://github.com/bgd-labs/aave-address-book/compare/v4.38.0...v4.38.1) (2026-01-06)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1165](https://github.com/bgd-labs/aave-address-book/issues/1165)) ([d71f99b](https://github.com/bgd-labs/aave-address-book/commit/d71f99b247683730e34c6ebc486bd67fc4fce751))

## [4.38.0](https://github.com/bgd-labs/aave-address-book/compare/v4.37.2...v4.38.0) (2025-12-18)


### Features

* upgrading the uipdp for the decentralized user interface ([#1168](https://github.com/bgd-labs/aave-address-book/issues/1168)) ([ec634ea](https://github.com/bgd-labs/aave-address-book/commit/ec634ea214c719934edafbbf4c07d15db0bf1642))


### Bug Fixes

* bump dependencies ([71d86ff](https://github.com/bgd-labs/aave-address-book/commit/71d86ff2999ccbb4f03a0bd2bacdf53cf8d96688))

## [4.37.2](https://github.com/bgd-labs/aave-address-book/compare/v4.37.1...v4.37.2) (2025-12-04)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1157](https://github.com/bgd-labs/aave-address-book/issues/1157)) ([1742d25](https://github.com/bgd-labs/aave-address-book/commit/1742d25c866e6b83df5727c4d8f2a1af489ce118))

## [4.37.1](https://github.com/bgd-labs/aave-address-book/compare/v4.37.0...v4.37.1) (2025-12-02)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1153](https://github.com/bgd-labs/aave-address-book/issues/1153)) ([d60a1f4](https://github.com/bgd-labs/aave-address-book/commit/d60a1f42ac06dc31d9433eb9437051a1bb8f8d53))
* verifications ([#1155](https://github.com/bgd-labs/aave-address-book/issues/1155)) ([12f8631](https://github.com/bgd-labs/aave-address-book/commit/12f863174e501c9f59eb9c158d8763822396e149))

## [4.37.0](https://github.com/bgd-labs/aave-address-book/compare/v4.36.3...v4.37.0) (2025-11-26)


### Features

* add chaos agent hub ([#1152](https://github.com/bgd-labs/aave-address-book/issues/1152)) ([a3b91a1](https://github.com/bgd-labs/aave-address-book/commit/a3b91a1248388bc7b39c7e8f1d642f4a68ff3f82))

## [4.36.3](https://github.com/bgd-labs/aave-address-book/compare/v4.36.2...v4.36.3) (2025-11-24)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1150](https://github.com/bgd-labs/aave-address-book/issues/1150)) ([702d7df](https://github.com/bgd-labs/aave-address-book/commit/702d7df25c1660600f2c50af9d64b62c7bc4f4d2))

## [4.36.2](https://github.com/bgd-labs/aave-address-book/compare/v4.36.1...v4.36.2) (2025-11-24)


### Bug Fixes

* abi generator ([#1145](https://github.com/bgd-labs/aave-address-book/issues/1145)) ([d29ee4d](https://github.com/bgd-labs/aave-address-book/commit/d29ee4d96f6dae9f36fe2ca8a449b45924047e9b))
* **cache:** automated cache update - updated addresses ([#1147](https://github.com/bgd-labs/aave-address-book/issues/1147)) ([8b10d15](https://github.com/bgd-labs/aave-address-book/commit/8b10d15ec8244dac2c7f34d3e9a9a26b77136b4d))
* migrate to new migration contracts ([#1149](https://github.com/bgd-labs/aave-address-book/issues/1149)) ([9ddd18d](https://github.com/bgd-labs/aave-address-book/commit/9ddd18d00817d3bd19f785ca533580475f39b0fd))

## [4.36.1](https://github.com/bgd-labs/aave-address-book/compare/v4.36.0...v4.36.1) (2025-11-10)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1135](https://github.com/bgd-labs/aave-address-book/issues/1135)) ([2215910](https://github.com/bgd-labs/aave-address-book/commit/2215910e169de3297d0a999f940fae153d315683))
* **cache:** automated cache update - updated addresses ([#1139](https://github.com/bgd-labs/aave-address-book/issues/1139)) ([2d5a378](https://github.com/bgd-labs/aave-address-book/commit/2d5a378fb0f043229166351e69911d323af92d4e))

## [4.36.0](https://github.com/bgd-labs/aave-address-book/compare/v4.35.1...v4.36.0) (2025-10-27)


### Features

* gho on plasma ([#1119](https://github.com/bgd-labs/aave-address-book/issues/1119)) ([c146a2d](https://github.com/bgd-labs/aave-address-book/commit/c146a2de4822610236a55197cb7d7caa7503cb59))


### Bug Fixes

* Add ethereum horizon addresses ([#1128](https://github.com/bgd-labs/aave-address-book/issues/1128)) ([4030c4d](https://github.com/bgd-labs/aave-address-book/commit/4030c4d72cfaff98b641bf9ae3d05542316d7144))

## [4.35.1](https://github.com/bgd-labs/aave-address-book/compare/v4.35.0...v4.35.1) (2025-10-27)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1130](https://github.com/bgd-labs/aave-address-book/issues/1130)) ([9b91c1e](https://github.com/bgd-labs/aave-address-book/commit/9b91c1e2eda69f538a8142a1961c965242bcaba7))

## [4.35.0](https://github.com/bgd-labs/aave-address-book/compare/v4.34.1...v4.35.0) (2025-10-24)


### Features

* generate emode label ([#1125](https://github.com/bgd-labs/aave-address-book/issues/1125)) ([67405c3](https://github.com/bgd-labs/aave-address-book/commit/67405c31ebab40c4f117b0a6a6f4a2f03fc72dcd))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1129](https://github.com/bgd-labs/aave-address-book/issues/1129)) ([3f6d632](https://github.com/bgd-labs/aave-address-book/commit/3f6d632019101315188c1d76bde36095223f5218))
* update action ([e1a9f03](https://github.com/bgd-labs/aave-address-book/commit/e1a9f032efb8835157eb036005696d0674a6a229))

## [4.34.1](https://github.com/bgd-labs/aave-address-book/compare/v4.34.0...v4.34.1) (2025-10-20)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1121](https://github.com/bgd-labs/aave-address-book/issues/1121)) ([0631618](https://github.com/bgd-labs/aave-address-book/commit/0631618e52921918367106d530113da398639d30))
* release ([#1122](https://github.com/bgd-labs/aave-address-book/issues/1122)) ([3694dca](https://github.com/bgd-labs/aave-address-book/commit/3694dca60f06deecd6898931af0bb6fb16934063))

## [4.34.0](https://github.com/bgd-labs/aave-address-book/compare/v4.33.0...v4.34.0) (2025-10-16)


### Features

* add collector swap steward ([#1117](https://github.com/bgd-labs/aave-address-book/issues/1117)) ([c3a9436](https://github.com/bgd-labs/aave-address-book/commit/c3a9436ddf6f5c8e77c840a28483cc132e315a25))

## [4.33.0](https://github.com/bgd-labs/aave-address-book/compare/v4.32.0...v4.33.0) (2025-10-14)


### Features

* add injector contracts ([#1109](https://github.com/bgd-labs/aave-address-book/issues/1109)) ([14d88c7](https://github.com/bgd-labs/aave-address-book/commit/14d88c76297eeb087b2713ca01625bae9d381531))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1104](https://github.com/bgd-labs/aave-address-book/issues/1104)) ([54cd159](https://github.com/bgd-labs/aave-address-book/commit/54cd1596467ace7799a2d0699dbc294f43dddc13))
* **cache:** automated cache update - updated addresses ([#1108](https://github.com/bgd-labs/aave-address-book/issues/1108)) ([a5d0257](https://github.com/bgd-labs/aave-address-book/commit/a5d025751313a7c4438e35ca4f4a7a4f7fa57393))
* ink verification ([#1112](https://github.com/bgd-labs/aave-address-book/issues/1112)) ([1969fa5](https://github.com/bgd-labs/aave-address-book/commit/1969fa5352ad92d95a657f73b918c34c70591443))
* update injector contract ([#1114](https://github.com/bgd-labs/aave-address-book/issues/1114)) ([89a1126](https://github.com/bgd-labs/aave-address-book/commit/89a1126034129949d57d70f012fb8818aaa6dc7a))
* Updated aave-v3-origin lib with xlayer updates ([#1115](https://github.com/bgd-labs/aave-address-book/issues/1115)) ([44287cb](https://github.com/bgd-labs/aave-address-book/commit/44287cb77d806ccca1b2aa70f911261ac3a3e7fb))

## [4.32.0](https://github.com/bgd-labs/aave-address-book/compare/v4.31.0...v4.32.0) (2025-10-02)


### Features

* add bob ([#965](https://github.com/bgd-labs/aave-address-book/issues/965)) ([330b3a3](https://github.com/bgd-labs/aave-address-book/commit/330b3a3028343deea6c9cf8837aa3d55272a4925))
* GHO Ink addresses ([#1091](https://github.com/bgd-labs/aave-address-book/issues/1091)) ([6777094](https://github.com/bgd-labs/aave-address-book/commit/6777094a46ce00717cefba0a069547f49d8744cb))


### Bug Fixes

* allow unverified ccip ([#1096](https://github.com/bgd-labs/aave-address-book/issues/1096)) ([6108fa2](https://github.com/bgd-labs/aave-address-book/commit/6108fa2664be9e39d976cf58900c8591057437fb))
* **cache:** automated cache update - updated addresses ([#1094](https://github.com/bgd-labs/aave-address-book/issues/1094)) ([c653a0f](https://github.com/bgd-labs/aave-address-book/commit/c653a0f256ebf8a2345e339c5dac25b348826689))
* **cache:** automated cache update - updated addresses ([#1095](https://github.com/bgd-labs/aave-address-book/issues/1095)) ([ac8ef5b](https://github.com/bgd-labs/aave-address-book/commit/ac8ef5b9aa4fe5a9419b716065f3f0f2e308aeab))
* **cache:** automated cache update - updated addresses ([#1098](https://github.com/bgd-labs/aave-address-book/issues/1098)) ([8dc7615](https://github.com/bgd-labs/aave-address-book/commit/8dc7615dd3599c7a4dfacaa0ed882949c0e0c72d))
* **cache:** automated cache update - updated addresses ([#1100](https://github.com/bgd-labs/aave-address-book/issues/1100)) ([7f5ea1e](https://github.com/bgd-labs/aave-address-book/commit/7f5ea1ec7b6d5bf6cc96728309687addfb7b1456))

## [4.31.0](https://github.com/bgd-labs/aave-address-book/compare/v4.30.5...v4.31.0) (2025-09-23)


### Features

* clinic v2 ([#1092](https://github.com/bgd-labs/aave-address-book/issues/1092)) ([6f87d24](https://github.com/bgd-labs/aave-address-book/commit/6f87d2471dd164b41b95c8b2b0767215f5435ee2))

## [4.30.5](https://github.com/bgd-labs/aave-address-book/compare/v4.30.4...v4.30.5) (2025-09-23)


### Bug Fixes

* add exclusion list for plasma ([#1089](https://github.com/bgd-labs/aave-address-book/issues/1089)) ([47805bf](https://github.com/bgd-labs/aave-address-book/commit/47805bfb1f1e280598a6fcb07df3aa85d4752c6f))

## [4.30.4](https://github.com/bgd-labs/aave-address-book/compare/v4.30.3...v4.30.4) (2025-09-23)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1084](https://github.com/bgd-labs/aave-address-book/issues/1084)) ([e3ec202](https://github.com/bgd-labs/aave-address-book/commit/e3ec2028905f44f1256d9969914a93a90d06d9b3))
* **cache:** automated cache update - updated addresses ([#1085](https://github.com/bgd-labs/aave-address-book/issues/1085)) ([1684411](https://github.com/bgd-labs/aave-address-book/commit/168441178a56b654f5bcb0861e5beb55ece84ced))
* **cache:** automated cache update - updated addresses ([#1087](https://github.com/bgd-labs/aave-address-book/issues/1087)) ([be885dd](https://github.com/bgd-labs/aave-address-book/commit/be885ddb322d17dcc9c51e6ba5e230442598b633))
* plasma urls ([#1082](https://github.com/bgd-labs/aave-address-book/issues/1082)) ([f0df7d4](https://github.com/bgd-labs/aave-address-book/commit/f0df7d421cfb0c6a4fd71ec79474e201b34fe8f5))

## [4.30.3](https://github.com/bgd-labs/aave-address-book/compare/v4.30.2...v4.30.3) (2025-09-17)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1080](https://github.com/bgd-labs/aave-address-book/issues/1080)) ([6e1abad](https://github.com/bgd-labs/aave-address-book/commit/6e1abad749c2061883aa6d2edaaa197ada43f2fb))

## [4.30.2](https://github.com/bgd-labs/aave-address-book/compare/v4.30.1...v4.30.2) (2025-09-17)


### Bug Fixes

* direct minter ([#1078](https://github.com/bgd-labs/aave-address-book/issues/1078)) ([980dc90](https://github.com/bgd-labs/aave-address-book/commit/980dc90dde3a88ce35be36495d1952059662b4d3))

## [4.30.1](https://github.com/bgd-labs/aave-address-book/compare/v4.30.0...v4.30.1) (2025-09-15)


### Bug Fixes

* Update release-please-action to version v4.3.0 ([#1075](https://github.com/bgd-labs/aave-address-book/issues/1075)) ([5fad514](https://github.com/bgd-labs/aave-address-book/commit/5fad514909bae02bfb56eb223705bb949f3db52e))

## [4.30.0](https://github.com/bgd-labs/aave-address-book/compare/v4.29.3...v4.30.0) (2025-09-15)


### Features

* add plasma contracts ([#1065](https://github.com/bgd-labs/aave-address-book/issues/1065)) ([a0c2498](https://github.com/bgd-labs/aave-address-book/commit/a0c2498d496421565ca1a6c87f5b3e10e5bcc65b))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1071](https://github.com/bgd-labs/aave-address-book/issues/1071)) ([a69d9e4](https://github.com/bgd-labs/aave-address-book/commit/a69d9e4479ed629daa9c967206e4e025b0e01301))

## [4.29.3](https://github.com/bgd-labs/aave-address-book/compare/v4.29.2...v4.29.3) (2025-09-11)


### Bug Fixes

* add verified contracts ([#1069](https://github.com/bgd-labs/aave-address-book/issues/1069)) ([4584172](https://github.com/bgd-labs/aave-address-book/commit/4584172dca744382d076f3f85f89e3ce29f8b273))
* **cache:** automated cache update - updated addresses ([#1067](https://github.com/bgd-labs/aave-address-book/issues/1067)) ([9fe9d91](https://github.com/bgd-labs/aave-address-book/commit/9fe9d910a6dc001616e363e152d5bfae123ebf2d))

## [4.29.2](https://github.com/bgd-labs/aave-address-book/compare/v4.29.1...v4.29.2) (2025-09-11)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1066](https://github.com/bgd-labs/aave-address-book/issues/1066)) ([9e987ef](https://github.com/bgd-labs/aave-address-book/commit/9e987ef8b6aa4f6d2ca96d9ab211c345fc7553ed))

## [4.29.1](https://github.com/bgd-labs/aave-address-book/compare/v4.29.0...v4.29.1) (2025-09-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1063](https://github.com/bgd-labs/aave-address-book/issues/1063)) ([cc14252](https://github.com/bgd-labs/aave-address-book/commit/cc14252158616bb08f28bb47c6d5fbb41098f375))

## [4.29.0](https://github.com/bgd-labs/aave-address-book/compare/v4.28.3...v4.29.0) (2025-09-02)


### Features

* Add GHO Gnosis addresses ([#1035](https://github.com/bgd-labs/aave-address-book/issues/1035)) ([5c054c3](https://github.com/bgd-labs/aave-address-book/commit/5c054c3d98c133dce1a736b59208452f508b7f59))

## [4.28.3](https://github.com/bgd-labs/aave-address-book/compare/v4.28.2...v4.28.3) (2025-09-02)


### Bug Fixes

* add missing edge stewards caps ([#1060](https://github.com/bgd-labs/aave-address-book/issues/1060)) ([fbc262d](https://github.com/bgd-labs/aave-address-book/commit/fbc262dce75e36560cde04c02b1f4e5790002c0b))
* **cache:** automated cache update - updated addresses ([#1053](https://github.com/bgd-labs/aave-address-book/issues/1053)) ([c2c0c56](https://github.com/bgd-labs/aave-address-book/commit/c2c0c56f56e24ce1bb2498e66aadd16b75a686ff))
* **cache:** automated cache update - updated addresses ([#1056](https://github.com/bgd-labs/aave-address-book/issues/1056)) ([f056ef3](https://github.com/bgd-labs/aave-address-book/commit/f056ef397bce089b69a2116f5ccfbbabdfe3cdc0))
* updated snapshot ([#1058](https://github.com/bgd-labs/aave-address-book/issues/1058)) ([cf4f10c](https://github.com/bgd-labs/aave-address-book/commit/cf4f10c4b4c68116d0c6d08702e814308ba6834c))

## [4.28.2](https://github.com/bgd-labs/aave-address-book/compare/v4.28.1...v4.28.2) (2025-08-26)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1049](https://github.com/bgd-labs/aave-address-book/issues/1049)) ([c0af957](https://github.com/bgd-labs/aave-address-book/commit/c0af95783d90184eaf363de892ec0fec43e66b14))

## [4.28.1](https://github.com/bgd-labs/aave-address-book/compare/v4.28.0...v4.28.1) (2025-08-25)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1043](https://github.com/bgd-labs/aave-address-book/issues/1043)) ([f309c5a](https://github.com/bgd-labs/aave-address-book/commit/f309c5ad2fdb432c6c18291fe1c500f04f97edb3))
* search-algo ([#1046](https://github.com/bgd-labs/aave-address-book/issues/1046)) ([1e1984d](https://github.com/bgd-labs/aave-address-book/commit/1e1984d2e4663b37b2d8e53dae23ceae982385bd))

## [4.28.0](https://github.com/bgd-labs/aave-address-book/compare/v4.27.0...v4.28.0) (2025-08-21)


### Features

* add ink aave gov addresses ([#1040](https://github.com/bgd-labs/aave-address-book/issues/1040)) ([0816d42](https://github.com/bgd-labs/aave-address-book/commit/0816d42e77660dd225813c2d1db380e172646a38))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1033](https://github.com/bgd-labs/aave-address-book/issues/1033)) ([cf0802b](https://github.com/bgd-labs/aave-address-book/commit/cf0802bc0dd8333645049f12cf88f86013a58db1))
* **cache:** automated cache update - updated addresses ([#1041](https://github.com/bgd-labs/aave-address-book/issues/1041)) ([e281938](https://github.com/bgd-labs/aave-address-book/commit/e281938a087bcc65c3870ed266b14262d7879af8))

## [4.27.0](https://github.com/bgd-labs/aave-address-book/compare/v4.26.2...v4.27.0) (2025-08-14)


### Features

* add ink v3.5 whitelabel contracts ([#1015](https://github.com/bgd-labs/aave-address-book/issues/1015)) ([2bd7aea](https://github.com/bgd-labs/aave-address-book/commit/2bd7aeacebffbf99b19259b9931422e3c44986f8))

## [4.26.2](https://github.com/bgd-labs/aave-address-book/compare/v4.26.1...v4.26.2) (2025-08-07)


### Bug Fixes

* update config engine for v3.5 ([#1025](https://github.com/bgd-labs/aave-address-book/issues/1025)) ([33761b7](https://github.com/bgd-labs/aave-address-book/commit/33761b7de91c24c91b7a6c3904f89c48edefc9cc))

## [4.26.1](https://github.com/bgd-labs/aave-address-book/compare/v4.26.0...v4.26.1) (2025-08-06)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1026](https://github.com/bgd-labs/aave-address-book/issues/1026)) ([8ada9d2](https://github.com/bgd-labs/aave-address-book/commit/8ada9d272f44104f8790da4a4c1585cab0d5d720))
* update list of known contracts ([#1027](https://github.com/bgd-labs/aave-address-book/issues/1027)) ([abd872a](https://github.com/bgd-labs/aave-address-book/commit/abd872ab5ab8c2373b6b2ef2e211ee158a54828c))

## [4.26.0](https://github.com/bgd-labs/aave-address-book/compare/v4.25.3...v4.26.0) (2025-08-04)


### Features

* add isKnownAddress utility ([#1022](https://github.com/bgd-labs/aave-address-book/issues/1022)) ([9e9921a](https://github.com/bgd-labs/aave-address-book/commit/9e9921a91e950d98060d09dabf1d72b70eb5280d))


### Bug Fixes

* add APE, ALC, Frontier, Merit, Ahab, and AFC SAFEs to Address Book  ([#1009](https://github.com/bgd-labs/aave-address-book/issues/1009)) ([bfbc2cc](https://github.com/bgd-labs/aave-address-book/commit/bfbc2cc1896475a9a2a76ad410ecaa60535e05db))

## [4.25.3](https://github.com/bgd-labs/aave-address-book/compare/v4.25.2...v4.25.3) (2025-07-30)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1018](https://github.com/bgd-labs/aave-address-book/issues/1018)) ([a6f14ff](https://github.com/bgd-labs/aave-address-book/commit/a6f14ffec588798b69fb35014468389609cbfb62))

## [4.25.2](https://github.com/bgd-labs/aave-address-book/compare/v4.25.1...v4.25.2) (2025-07-30)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1011](https://github.com/bgd-labs/aave-address-book/issues/1011)) ([d6bc8f7](https://github.com/bgd-labs/aave-address-book/commit/d6bc8f7db9c3f1bd258e1c630849f3674b3d219c))
* **cache:** automated cache update - updated addresses ([#1014](https://github.com/bgd-labs/aave-address-book/issues/1014)) ([4351c7c](https://github.com/bgd-labs/aave-address-book/commit/4351c7c72245993c16dd837085c353e731f2ff29))
* **cache:** automated cache update - updated addresses ([#1016](https://github.com/bgd-labs/aave-address-book/issues/1016)) ([e858f5c](https://github.com/bgd-labs/aave-address-book/commit/e858f5cc1c7431fbd63566696fda9714b962bbb9))

## [4.25.1](https://github.com/bgd-labs/aave-address-book/compare/v4.25.0...v4.25.1) (2025-07-17)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#1002](https://github.com/bgd-labs/aave-address-book/issues/1002)) ([4508d60](https://github.com/bgd-labs/aave-address-book/commit/4508d6093d08c89924bfc74d31e9c2d455784acd))

## [4.25.0](https://github.com/bgd-labs/aave-address-book/compare/v4.24.2...v4.25.0) (2025-07-10)


### Features

* sonic psp addresses ([#1005](https://github.com/bgd-labs/aave-address-book/issues/1005)) ([e0b3960](https://github.com/bgd-labs/aave-address-book/commit/e0b3960e40470db314f7037d700db540e576c1db))


### Bug Fixes

* update origin ([#999](https://github.com/bgd-labs/aave-address-book/issues/999)) ([302898e](https://github.com/bgd-labs/aave-address-book/commit/302898ec848e983729397247942c84a5d0df5c8b))

## [4.24.2](https://github.com/bgd-labs/aave-address-book/compare/v4.24.1...v4.24.2) (2025-07-03)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#997](https://github.com/bgd-labs/aave-address-book/issues/997)) ([a03a6ff](https://github.com/bgd-labs/aave-address-book/commit/a03a6ffb9f85df7edd23a3ee41300ead3ad6bbb0))
* upgrade to 3.4 ([#961](https://github.com/bgd-labs/aave-address-book/issues/961)) ([778fd70](https://github.com/bgd-labs/aave-address-book/commit/778fd70ece4e415d45a90c515929b720f3a42070))

## [4.24.1](https://github.com/bgd-labs/aave-address-book/compare/v4.24.0...v4.24.1) (2025-07-02)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#994](https://github.com/bgd-labs/aave-address-book/issues/994)) ([7fe8aad](https://github.com/bgd-labs/aave-address-book/commit/7fe8aadcbb7f311d932d67a52b19a6891f3bcee3))

## [4.24.0](https://github.com/bgd-labs/aave-address-book/compare/v4.23.0...v4.24.0) (2025-06-30)


### Features

* risk steward update ([#992](https://github.com/bgd-labs/aave-address-book/issues/992)) ([91e37bc](https://github.com/bgd-labs/aave-address-book/commit/91e37bc216365085878d6376a922b86fb6bedb4c))

## [4.23.0](https://github.com/bgd-labs/aave-address-book/compare/v4.22.4...v4.23.0) (2025-06-28)


### Features

* gho on avax ([#983](https://github.com/bgd-labs/aave-address-book/issues/983)) ([2e8d8a3](https://github.com/bgd-labs/aave-address-book/commit/2e8d8a3be5d5c32e765cc2668a93d891b56483a3))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#984](https://github.com/bgd-labs/aave-address-book/issues/984)) ([0ae8174](https://github.com/bgd-labs/aave-address-book/commit/0ae8174b3836030f1ffbbb111326d33e10161225))
* **cache:** automated cache update - updated addresses ([#989](https://github.com/bgd-labs/aave-address-book/issues/989)) ([8e91488](https://github.com/bgd-labs/aave-address-book/commit/8e91488aea5349c37b4bec73622b053d02922b7f))
* **cache:** automated cache update - updated addresses ([#990](https://github.com/bgd-labs/aave-address-book/issues/990)) ([0cc1785](https://github.com/bgd-labs/aave-address-book/commit/0cc1785dad6f4b9fab54331326ae188a7b3a9a5f))
* generated with correct npm ([#988](https://github.com/bgd-labs/aave-address-book/issues/988)) ([0993c22](https://github.com/bgd-labs/aave-address-book/commit/0993c22733447442a417301747776604e2753419))
* update verified file ([#991](https://github.com/bgd-labs/aave-address-book/issues/991)) ([5f3e473](https://github.com/bgd-labs/aave-address-book/commit/5f3e4737fca4e4d712681a4d1d0379410fa5fca0))

## [4.22.4](https://github.com/bgd-labs/aave-address-book/compare/v4.22.3...v4.22.4) (2025-06-26)


### Bug Fixes

* add cl to UI ([#978](https://github.com/bgd-labs/aave-address-book/issues/978)) ([27244be](https://github.com/bgd-labs/aave-address-book/commit/27244beffa4ccd47f428b27a771f0f9629d89ccc))
* **cache:** automated cache update - updated addresses ([#976](https://github.com/bgd-labs/aave-address-book/issues/976)) ([e3afaf9](https://github.com/bgd-labs/aave-address-book/commit/e3afaf9dc2efeafa8472be2fa0cf991112d5a4e9))
* **cache:** automated cache update - updated addresses ([#979](https://github.com/bgd-labs/aave-address-book/issues/979)) ([5c95a38](https://github.com/bgd-labs/aave-address-book/commit/5c95a387425fd1e02b74cc38854753acd9526f65))
* **cache:** automated cache update - updated addresses ([#980](https://github.com/bgd-labs/aave-address-book/issues/980)) ([003a0fa](https://github.com/bgd-labs/aave-address-book/commit/003a0fa452cc7c095378bf036a19def7075ef7ac))
* **cache:** automated cache update - updated addresses ([#982](https://github.com/bgd-labs/aave-address-book/issues/982)) ([7b7045c](https://github.com/bgd-labs/aave-address-book/commit/7b7045c0ad53301c1d125fb69d29744ea9e498e2))

## [4.22.3](https://github.com/bgd-labs/aave-address-book/compare/v4.22.2...v4.22.3) (2025-06-12)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#971](https://github.com/bgd-labs/aave-address-book/issues/971)) ([3497eee](https://github.com/bgd-labs/aave-address-book/commit/3497eee67eab1ef03eefa3c1293bac41983f4cfc))
* **cache:** automated cache update - updated addresses ([#973](https://github.com/bgd-labs/aave-address-book/issues/973)) ([7e23dff](https://github.com/bgd-labs/aave-address-book/commit/7e23dff545949e179f2aae453f863f1f0a586ed8))
* **cache:** automated cache update - updated addresses ([#974](https://github.com/bgd-labs/aave-address-book/issues/974)) ([31b0020](https://github.com/bgd-labs/aave-address-book/commit/31b00209b3a061900fb87ddc95da679f372a2e5d))
* Update umbrella helpers ([#975](https://github.com/bgd-labs/aave-address-book/issues/975)) ([dafdcc5](https://github.com/bgd-labs/aave-address-book/commit/dafdcc58b72b7131b738895e22e21f32eb6196f1))
* use unmodified symbols in exported tokenlist ([#970](https://github.com/bgd-labs/aave-address-book/issues/970)) ([b3a7ddd](https://github.com/bgd-labs/aave-address-book/commit/b3a7ddd7bf4361b239aeb470c8979631f286b107))

## [4.22.2](https://github.com/bgd-labs/aave-address-book/compare/v4.22.1...v4.22.2) (2025-06-05)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#962](https://github.com/bgd-labs/aave-address-book/issues/962)) ([ed2b6ff](https://github.com/bgd-labs/aave-address-book/commit/ed2b6ffe74196a02715eb588edd3fd88ec96029f))
* **cache:** automated cache update - updated addresses ([#964](https://github.com/bgd-labs/aave-address-book/issues/964)) ([d4ebfc2](https://github.com/bgd-labs/aave-address-book/commit/d4ebfc2e75c8df9f65392063ef7dfe11a86ded8f))
* **cache:** automated cache update - updated addresses ([#967](https://github.com/bgd-labs/aave-address-book/issues/967)) ([d654400](https://github.com/bgd-labs/aave-address-book/commit/d65440041c84f4eaaead5ec8b22a4550ad95cd5f))
* **cache:** automated cache update - updated addresses ([#968](https://github.com/bgd-labs/aave-address-book/issues/968)) ([c975565](https://github.com/bgd-labs/aave-address-book/commit/c9755653af80f6680f1d97d59153c0f8e4ff37b0))
* umbrella tokenlist ([#966](https://github.com/bgd-labs/aave-address-book/issues/966)) ([e677a0d](https://github.com/bgd-labs/aave-address-book/commit/e677a0d49518085fb73818fe337d0ecfdc629964))

## [4.22.1](https://github.com/bgd-labs/aave-address-book/compare/v4.22.0...v4.22.1) (2025-06-02)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#958](https://github.com/bgd-labs/aave-address-book/issues/958)) ([761c802](https://github.com/bgd-labs/aave-address-book/commit/761c802adb1aaec11c5fc208f180c480300dc77c))
* **cache:** automated cache update - updated addresses ([#960](https://github.com/bgd-labs/aave-address-book/issues/960)) ([e72f95f](https://github.com/bgd-labs/aave-address-book/commit/e72f95f93d5f90ff606e1a276294d92aa8e16ced))

## [4.22.0](https://github.com/bgd-labs/aave-address-book/compare/v4.21.0...v4.22.0) (2025-05-28)


### Features

* include sol on npm ([#953](https://github.com/bgd-labs/aave-address-book/issues/953)) ([19c15f6](https://github.com/bgd-labs/aave-address-book/commit/19c15f6100e2636bd24e8929635b84133c52e368))


### Bug Fixes

* avalanche PoR executor address ([#954](https://github.com/bgd-labs/aave-address-book/issues/954)) ([a70599b](https://github.com/bgd-labs/aave-address-book/commit/a70599b218c5b91eb85c693ae2d583500cd52ad8))
* **cache:** automated cache update - updated addresses ([#955](https://github.com/bgd-labs/aave-address-book/issues/955)) ([954f139](https://github.com/bgd-labs/aave-address-book/commit/954f1394b869c17a1226c713632d8334965d6986))
* **cache:** automated cache update - updated addresses ([#957](https://github.com/bgd-labs/aave-address-book/issues/957)) ([a374b5c](https://github.com/bgd-labs/aave-address-book/commit/a374b5c54ef5c48a4f28be575622f4922be1532a))
* injector directory ([#951](https://github.com/bgd-labs/aave-address-book/issues/951)) ([8b8fc72](https://github.com/bgd-labs/aave-address-book/commit/8b8fc7289a82634082daee98577020ec22fa9fc4))
* update umbrella helpers ([#956](https://github.com/bgd-labs/aave-address-book/issues/956)) ([1dbef10](https://github.com/bgd-labs/aave-address-book/commit/1dbef10cc1908f19f27bbfda223225f32d54218f))

## [4.21.0](https://github.com/bgd-labs/aave-address-book/compare/v4.20.1...v4.21.0) (2025-05-20)


### Features

* Add soneium addresses ([#928](https://github.com/bgd-labs/aave-address-book/issues/928)) ([bf0eed6](https://github.com/bgd-labs/aave-address-book/commit/bf0eed678c0ce9e3860aeac674c0b4bca9f67bf9))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#949](https://github.com/bgd-labs/aave-address-book/issues/949)) ([e3ade58](https://github.com/bgd-labs/aave-address-book/commit/e3ade580f8c7dddb2b63326a9e6800010d75661b))

## [4.20.1](https://github.com/bgd-labs/aave-address-book/compare/v4.20.0...v4.20.1) (2025-05-19)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#943](https://github.com/bgd-labs/aave-address-book/issues/943)) ([5675106](https://github.com/bgd-labs/aave-address-book/commit/56751063c08ca34072971f3c63233798e91f5cd0))
* umbrella addresses ([#946](https://github.com/bgd-labs/aave-address-book/issues/946)) ([7c49237](https://github.com/bgd-labs/aave-address-book/commit/7c492370c0e40ff4f781b2a0c26596cf2dd91cba))

## [4.20.0](https://github.com/bgd-labs/aave-address-book/compare/v4.19.3...v4.20.0) (2025-05-12)


### Features

* add umbrella contracts ([#924](https://github.com/bgd-labs/aave-address-book/issues/924)) ([a1ba47d](https://github.com/bgd-labs/aave-address-book/commit/a1ba47dd74c8950ffc68cbc66b18766164ea2663))


### Bug Fixes

* **cache:** automated cache update - pt eMode ([#935](https://github.com/bgd-labs/aave-address-book/issues/935)) ([866b97d](https://github.com/bgd-labs/aave-address-book/commit/866b97d7386f794fcd1e3d62f7c3633d1d76cc74))
* **cache:** automated cache update - updated addresses ([#938](https://github.com/bgd-labs/aave-address-book/issues/938)) ([cb60ad2](https://github.com/bgd-labs/aave-address-book/commit/cb60ad22a4ac522ccb5eb14f71e040c3b0d67d0f))
* **cache:** automated cache update - updated addresses ([#940](https://github.com/bgd-labs/aave-address-book/issues/940)) ([b81bd88](https://github.com/bgd-labs/aave-address-book/commit/b81bd88c48ac253da5b8e9292dd28f0feb05da78))
* chainlink naming ([#937](https://github.com/bgd-labs/aave-address-book/issues/937)) ([ae336fc](https://github.com/bgd-labs/aave-address-book/commit/ae336fc147b6f7c2740966ccb4d4506dce128b3d))
* migrate permissioned payloads controller ([#939](https://github.com/bgd-labs/aave-address-book/issues/939)) ([974ec3f](https://github.com/bgd-labs/aave-address-book/commit/974ec3fdab5b213ce52d829fc11257320083d137))

## [4.19.3](https://github.com/bgd-labs/aave-address-book/compare/v4.19.2...v4.19.3) (2025-05-05)


### Bug Fixes

* add chainlink feeds to address book ([#929](https://github.com/bgd-labs/aave-address-book/issues/929)) ([2e80fc7](https://github.com/bgd-labs/aave-address-book/commit/2e80fc7b947837e82706820ac8bd227a507eaaf2))

## [4.19.2](https://github.com/bgd-labs/aave-address-book/compare/v4.19.1...v4.19.2) (2025-05-05)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#930](https://github.com/bgd-labs/aave-address-book/issues/930)) ([c2b2882](https://github.com/bgd-labs/aave-address-book/commit/c2b2882d914720d77886b23c1085c78fa127368e))

## [4.19.1](https://github.com/bgd-labs/aave-address-book/compare/v4.19.0...v4.19.1) (2025-05-01)


### Bug Fixes

* update steward address ([#926](https://github.com/bgd-labs/aave-address-book/issues/926)) ([0b25ffc](https://github.com/bgd-labs/aave-address-book/commit/0b25ffc4d534c9565f08559a3872d65c46dada1d))

## [4.19.0](https://github.com/bgd-labs/aave-address-book/compare/v4.18.1...v4.19.0) (2025-04-30)


### Features

* add injector addresses ([#921](https://github.com/bgd-labs/aave-address-book/issues/921)) ([d9194b2](https://github.com/bgd-labs/aave-address-book/commit/d9194b289bb18af4ec22aef3fbb7734e2f025544))
* lido svr ([#923](https://github.com/bgd-labs/aave-address-book/issues/923)) ([94b7c13](https://github.com/bgd-labs/aave-address-book/commit/94b7c139a8a8e59f94108a864586e2368bf54447))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#916](https://github.com/bgd-labs/aave-address-book/issues/916)) ([e632249](https://github.com/bgd-labs/aave-address-book/commit/e6322499249eeb36a0ddfe3d81da430cc45ef287))
* **cache:** automated cache update - updated addresses ([#922](https://github.com/bgd-labs/aave-address-book/issues/922)) ([df11c38](https://github.com/bgd-labs/aave-address-book/commit/df11c3892198a024508fafd090214908c5b64014))
* pt symbol ([#925](https://github.com/bgd-labs/aave-address-book/issues/925)) ([541fdb8](https://github.com/bgd-labs/aave-address-book/commit/541fdb87ce4b0b9fae16e1a09a7566beae54252d))

## [4.18.1](https://github.com/bgd-labs/aave-address-book/compare/v4.18.0...v4.18.1) (2025-04-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#910](https://github.com/bgd-labs/aave-address-book/issues/910)) ([5a07142](https://github.com/bgd-labs/aave-address-book/commit/5a0714257cabe86aa0056a8ecd4e18c3dd75ec05))
* **cache:** automated cache update - updated addresses ([#915](https://github.com/bgd-labs/aave-address-book/issues/915)) ([a42e127](https://github.com/bgd-labs/aave-address-book/commit/a42e127eccb901730560a6a5a2b78a39ebbd00c2))
* mantle risk steward ([#913](https://github.com/bgd-labs/aave-address-book/issues/913)) ([49e7d15](https://github.com/bgd-labs/aave-address-book/commit/49e7d15760f6960ccf5dcc8edad12bd32799213a))

## [4.18.0](https://github.com/bgd-labs/aave-address-book/compare/v4.17.2...v4.18.0) (2025-04-03)


### Features

* add ebtc ([#906](https://github.com/bgd-labs/aave-address-book/issues/906)) ([c5e87bd](https://github.com/bgd-labs/aave-address-book/commit/c5e87bd40dc334e50619a078c01d32a4c5e27678))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#900](https://github.com/bgd-labs/aave-address-book/issues/900)) ([43aa988](https://github.com/bgd-labs/aave-address-book/commit/43aa988fe7ab0af82f92a639dab4f10f6c6619df))
* **cache:** automated cache update - updated addresses ([#903](https://github.com/bgd-labs/aave-address-book/issues/903)) ([5c6c087](https://github.com/bgd-labs/aave-address-book/commit/5c6c087d0a379a76b22a49481e020a721005c297))

## [4.17.2](https://github.com/bgd-labs/aave-address-book/compare/v4.17.1...v4.17.2) (2025-03-28)


### Bug Fixes

* Add new Governance addresses ([#898](https://github.com/bgd-labs/aave-address-book/issues/898)) ([61bbcf5](https://github.com/bgd-labs/aave-address-book/commit/61bbcf5d4d1c71c44e4cbb4e98073ca1da2aacd5))
* **cache:** automated cache update - updated addresses ([#895](https://github.com/bgd-labs/aave-address-book/issues/895)) ([cbfead3](https://github.com/bgd-labs/aave-address-book/commit/cbfead394c8c8c363fb7e664d34dcfe3c693e81b))

## [4.17.1](https://github.com/bgd-labs/aave-address-book/compare/v4.17.0...v4.17.1) (2025-03-20)


### Bug Fixes

* weth gateway ([#891](https://github.com/bgd-labs/aave-address-book/issues/891)) ([ba66374](https://github.com/bgd-labs/aave-address-book/commit/ba6637496673bcf5c1bc013deacf2cb0e4c6ad8c))

## [4.17.0](https://github.com/bgd-labs/aave-address-book/compare/v4.16.1...v4.17.0) (2025-03-18)


### Features

* update stata ([#889](https://github.com/bgd-labs/aave-address-book/issues/889)) ([4e0a03d](https://github.com/bgd-labs/aave-address-book/commit/4e0a03df8192b3c56d92cf1b2dff589518d9e9d0))

## [4.16.1](https://github.com/bgd-labs/aave-address-book/compare/v4.16.0...v4.16.1) (2025-03-18)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#883](https://github.com/bgd-labs/aave-address-book/issues/883)) ([f78db3f](https://github.com/bgd-labs/aave-address-book/commit/f78db3f577b6439e9a5e88d1cc116417c32ab4ab))
* remove zkevm ([#888](https://github.com/bgd-labs/aave-address-book/issues/888)) ([070da0f](https://github.com/bgd-labs/aave-address-book/commit/070da0fd6bbb0c3411771770d51e73f14e38c7c7))
* update svr ([#885](https://github.com/bgd-labs/aave-address-book/issues/885)) ([ba39571](https://github.com/bgd-labs/aave-address-book/commit/ba39571b0f3197d2fc9f833749e2cab9bf3b553b))

## [4.16.0](https://github.com/bgd-labs/aave-address-book/compare/v4.15.1...v4.16.0) (2025-03-11)


### Features

* add ava stata factory ([#878](https://github.com/bgd-labs/aave-address-book/issues/878)) ([1ef9f0a](https://github.com/bgd-labs/aave-address-book/commit/1ef9f0a5358aa77f0b91f3ea5664baacc33f1094))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#879](https://github.com/bgd-labs/aave-address-book/issues/879)) ([f7bc4a7](https://github.com/bgd-labs/aave-address-book/commit/f7bc4a7cf0908757f04cf7f2e9a3964e6fb13fef))
* update icons ([#882](https://github.com/bgd-labs/aave-address-book/issues/882)) ([64b3329](https://github.com/bgd-labs/aave-address-book/commit/64b33297d8d04c94937871b0e4fa4dfcae47c89e))

## [4.15.1](https://github.com/bgd-labs/aave-address-book/compare/v4.15.0...v4.15.1) (2025-03-10)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#869](https://github.com/bgd-labs/aave-address-book/issues/869)) ([f7a3e6d](https://github.com/bgd-labs/aave-address-book/commit/f7a3e6d71f2a1710df45f82604d607bc391ff0f9))
* **cache:** automated cache update - updated addresses ([#871](https://github.com/bgd-labs/aave-address-book/issues/871)) ([5d4be4a](https://github.com/bgd-labs/aave-address-book/commit/5d4be4a790dd5a8189464d02f4a5bb48fd29e6cb))
* **cache:** automated cache update - updated addresses ([#874](https://github.com/bgd-labs/aave-address-book/issues/874)) ([da5c619](https://github.com/bgd-labs/aave-address-book/commit/da5c61999e6b79278d53b1d3b6809c6ac9cc217f))
* error snapshots ([#876](https://github.com/bgd-labs/aave-address-book/issues/876)) ([6759a81](https://github.com/bgd-labs/aave-address-book/commit/6759a8183323372776124b5bdad8cf61f4505aae))

## [4.15.0](https://github.com/bgd-labs/aave-address-book/compare/v4.14.0...v4.15.0) (2025-03-03)


### Features

* clinic stewards ([#865](https://github.com/bgd-labs/aave-address-book/issues/865)) ([a652eda](https://github.com/bgd-labs/aave-address-book/commit/a652edad56b817c730ced875ed4e61995825b76e))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#867](https://github.com/bgd-labs/aave-address-book/issues/867)) ([d833e6e](https://github.com/bgd-labs/aave-address-book/commit/d833e6eb599952b668bbc26ff9a14c43022c0f8f))

## [4.14.0](https://github.com/bgd-labs/aave-address-book/compare/v4.13.2...v4.14.0) (2025-02-28)


### Features

* add dust collector ([#861](https://github.com/bgd-labs/aave-address-book/issues/861)) ([300841c](https://github.com/bgd-labs/aave-address-book/commit/300841c0c3cbc884dca90d168053a3f8df25f767))

## [4.13.2](https://github.com/bgd-labs/aave-address-book/compare/v4.13.1...v4.13.2) (2025-02-26)


### Bug Fixes

* stata optimism factory ([#859](https://github.com/bgd-labs/aave-address-book/issues/859)) ([d12773d](https://github.com/bgd-labs/aave-address-book/commit/d12773d4edfa5e8867f0614e8b6c9ffa8c90f0d4))

## [4.13.1](https://github.com/bgd-labs/aave-address-book/compare/v4.13.0...v4.13.1) (2025-02-24)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#855](https://github.com/bgd-labs/aave-address-book/issues/855)) ([ecbe265](https://github.com/bgd-labs/aave-address-book/commit/ecbe265ffcf044132f78ea0aa6bb40d9ea4cb857))

## [4.13.0](https://github.com/bgd-labs/aave-address-book/compare/v4.12.0...v4.13.0) (2025-02-24)


### Features

* update to v3.3.0 ([#839](https://github.com/bgd-labs/aave-address-book/issues/839)) ([43c76b3](https://github.com/bgd-labs/aave-address-book/commit/43c76b394b972e0a7490ccc066d2e8ddce8a2638))


### Bug Fixes

* add risk stewards for celo and mantle ([#852](https://github.com/bgd-labs/aave-address-book/issues/852)) ([a1a964e](https://github.com/bgd-labs/aave-address-book/commit/a1a964ec8dcddfccc373e465f3461dc96693fe61))
* **cache:** automated cache update - updated addresses ([#851](https://github.com/bgd-labs/aave-address-book/issues/851)) ([b0fd6b1](https://github.com/bgd-labs/aave-address-book/commit/b0fd6b1021af0d2b2a32a940846e2427f5c38465))
* update web3 icons ([#849](https://github.com/bgd-labs/aave-address-book/issues/849)) ([a274953](https://github.com/bgd-labs/aave-address-book/commit/a27495376032eaaca01d71aecfb7d8438cb4e9f7))
* updated base sepolia addresses ([#854](https://github.com/bgd-labs/aave-address-book/issues/854)) ([edac387](https://github.com/bgd-labs/aave-address-book/commit/edac3879d4a4cd46b076ede048adde6464b1430a))

## [4.12.0](https://github.com/bgd-labs/aave-address-book/compare/v4.11.0...v4.12.0) (2025-02-19)


### Features

* Add Celo addresses ([#770](https://github.com/bgd-labs/aave-address-book/issues/770)) ([1688111](https://github.com/bgd-labs/aave-address-book/commit/1688111fee51bd01225c328c2ad5f21a5c696f08))
* add gho direct minter ([#847](https://github.com/bgd-labs/aave-address-book/issues/847)) ([66d7c49](https://github.com/bgd-labs/aave-address-book/commit/66d7c490f53ac79787320e172ea39162ba38e7b0))
* mantle instance contracts ([#828](https://github.com/bgd-labs/aave-address-book/issues/828)) ([853b5a0](https://github.com/bgd-labs/aave-address-book/commit/853b5a038028ae3fef77e814faebb4eb39008c1e))

## [4.11.0](https://github.com/bgd-labs/aave-address-book/compare/v4.10.0...v4.11.0) (2025-02-18)


### Features

* sonic instance contracts ([#829](https://github.com/bgd-labs/aave-address-book/issues/829)) ([dd41430](https://github.com/bgd-labs/aave-address-book/commit/dd41430542a8699de58fc9ea36f7606574bf9455))


### Bug Fixes

* add list of verified ([#840](https://github.com/bgd-labs/aave-address-book/issues/840)) ([4e7fbac](https://github.com/bgd-labs/aave-address-book/commit/4e7fbac6a7f6ba59582d6fc047d766e997fecc60))
* **cache:** automated cache update - updated addresses ([#830](https://github.com/bgd-labs/aave-address-book/issues/830)) ([aa516bb](https://github.com/bgd-labs/aave-address-book/commit/aa516bba1be147cf4e6fada5c824a7babf73f282))
* **cache:** automated cache update - updated addresses ([#842](https://github.com/bgd-labs/aave-address-book/issues/842)) ([0b38aa8](https://github.com/bgd-labs/aave-address-book/commit/0b38aa8f208b9015df81993f23027e1fe88a3bc1))
* disable dependabot ([#838](https://github.com/bgd-labs/aave-address-book/issues/838)) ([b8d3726](https://github.com/bgd-labs/aave-address-book/commit/b8d37265e935e623c6d8b08d4c23be03dac6cc6b))
* use npm workspace ([#832](https://github.com/bgd-labs/aave-address-book/issues/832)) ([7afe056](https://github.com/bgd-labs/aave-address-book/commit/7afe05609993cef8a49fcfd2b66ae9d729e0e33d))

## [4.10.0](https://github.com/bgd-labs/aave-address-book/compare/v4.9.0...v4.10.0) (2025-02-07)


### Features

* gho on base ([#824](https://github.com/bgd-labs/aave-address-book/issues/824)) ([d8829eb](https://github.com/bgd-labs/aave-address-book/commit/d8829ebd700391380265840495e602e35b767292))


### Bug Fixes

* symbol ([#814](https://github.com/bgd-labs/aave-address-book/issues/814)) ([13bf5f4](https://github.com/bgd-labs/aave-address-book/commit/13bf5f428e2f8919370e9347517956c6dc0d9faf))

## [4.9.0](https://github.com/bgd-labs/aave-address-book/compare/v4.8.1...v4.9.0) (2025-01-29)


### Features

* upgrade factories ([#804](https://github.com/bgd-labs/aave-address-book/issues/804)) ([3ad86fd](https://github.com/bgd-labs/aave-address-book/commit/3ad86fdbfb6595564aebe93823845f793d43de8b))


### Bug Fixes

* add mantle and sonic ([#808](https://github.com/bgd-labs/aave-address-book/issues/808)) ([78f182d](https://github.com/bgd-labs/aave-address-book/commit/78f182d578bd9772827f3fb0a177add7b9c71a73))
* bump origin ([#811](https://github.com/bgd-labs/aave-address-book/issues/811)) ([386775a](https://github.com/bgd-labs/aave-address-book/commit/386775ae50429aba611d16ea1c97bacf15603552))
* **cache:** automated cache update - updated addresses ([#805](https://github.com/bgd-labs/aave-address-book/issues/805)) ([bc25e5e](https://github.com/bgd-labs/aave-address-book/commit/bc25e5e9acbdcea733fd2ab769de7ebd31f0a417))
* upgrade origin to latest ([#810](https://github.com/bgd-labs/aave-address-book/issues/810)) ([c7900ad](https://github.com/bgd-labs/aave-address-book/commit/c7900adaa8b454ae3e7b24cb729283257978c9eb))

## [4.8.1](https://github.com/bgd-labs/aave-address-book/compare/v4.8.0...v4.8.1) (2025-01-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#802](https://github.com/bgd-labs/aave-address-book/issues/802)) ([9546863](https://github.com/bgd-labs/aave-address-book/commit/9546863f8a8c024ac1eed80d5d8222d55b08a6d0))
* initial addresses ([#800](https://github.com/bgd-labs/aave-address-book/issues/800)) ([837214a](https://github.com/bgd-labs/aave-address-book/commit/837214a8bfff3c937a6d8fd803d0c88eeaa948a0))

## [4.8.0](https://github.com/bgd-labs/aave-address-book/compare/v4.7.4...v4.8.0) (2025-01-20)


### Features

* add edge risk steward addresses ([#722](https://github.com/bgd-labs/aave-address-book/issues/722)) ([06623dc](https://github.com/bgd-labs/aave-address-book/commit/06623dcb7d8ad4838b5aeae740b7fa3f531e493f))
* add linea contracts ([#729](https://github.com/bgd-labs/aave-address-book/issues/729)) ([d22bc78](https://github.com/bgd-labs/aave-address-book/commit/d22bc78386303517252c8ec28761274259ce33c1))
* new stata factories ([#799](https://github.com/bgd-labs/aave-address-book/issues/799)) ([c3dc726](https://github.com/bgd-labs/aave-address-book/commit/c3dc7268b9b414a6bf98a717fc4be739258cdc40))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#784](https://github.com/bgd-labs/aave-address-book/issues/784)) ([48e1375](https://github.com/bgd-labs/aave-address-book/commit/48e13758f2ca240b50d69d35d8eeb4b2a3b61306))
* **cache:** automated cache update - updated addresses ([#785](https://github.com/bgd-labs/aave-address-book/issues/785)) ([9da796d](https://github.com/bgd-labs/aave-address-book/commit/9da796dac9d709c3d89607f8f645735c6c504798))
* use non ipfs aave icon ([#772](https://github.com/bgd-labs/aave-address-book/issues/772)) ([f9d2f78](https://github.com/bgd-labs/aave-address-book/commit/f9d2f78ab6d2d5f7debad4fedff72ce9bd3bad6b))

## [4.7.4](https://github.com/bgd-labs/aave-address-book/compare/v4.7.3...v4.7.4) (2025-01-09)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#767](https://github.com/bgd-labs/aave-address-book/issues/767)) ([79a79f0](https://github.com/bgd-labs/aave-address-book/commit/79a79f0476edd4951db5801bb2d0ab40156e83a2))
* **cache:** automated cache update - updated addresses ([#769](https://github.com/bgd-labs/aave-address-book/issues/769)) ([5526313](https://github.com/bgd-labs/aave-address-book/commit/55263139f4e50514216298c0991aade86c864730))

## [4.7.3](https://github.com/bgd-labs/aave-address-book/compare/v4.7.2...v4.7.3) (2024-12-30)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#753](https://github.com/bgd-labs/aave-address-book/issues/753)) ([139eef9](https://github.com/bgd-labs/aave-address-book/commit/139eef947251bfe7853014bd365c9592af0faa78))
* **cache:** automated cache update - updated addresses ([#760](https://github.com/bgd-labs/aave-address-book/issues/760)) ([774e385](https://github.com/bgd-labs/aave-address-book/commit/774e3853a8fc11f4e6721b3045bb72a106b3f038))
* update list of verified contracts ([#765](https://github.com/bgd-labs/aave-address-book/issues/765)) ([609893c](https://github.com/bgd-labs/aave-address-book/commit/609893cb4866608edab9610016ba9469adea6ba7))
* Update ParaSwapRepayAdapter in Polygon V2 ([#754](https://github.com/bgd-labs/aave-address-book/issues/754)) ([b348370](https://github.com/bgd-labs/aave-address-book/commit/b3483708e95e8a14e270826f2220d6f2d1cc2928))

## [4.7.2](https://github.com/bgd-labs/aave-address-book/compare/v4.7.1...v4.7.2) (2024-12-20)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#750](https://github.com/bgd-labs/aave-address-book/issues/750)) ([1efa352](https://github.com/bgd-labs/aave-address-book/commit/1efa3529fc2754c2409fa67ed332b332a945856f))
* **cache:** automated cache update - updated addresses ([#752](https://github.com/bgd-labs/aave-address-book/issues/752)) ([cda5325](https://github.com/bgd-labs/aave-address-book/commit/cda5325aeadb4528c1d3810fb2ef13426ea10413))

## [4.7.1](https://github.com/bgd-labs/aave-address-book/compare/v4.7.0...v4.7.1) (2024-12-16)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#739](https://github.com/bgd-labs/aave-address-book/issues/739)) ([16f3b10](https://github.com/bgd-labs/aave-address-book/commit/16f3b10a4ca21da3d0d0e8e1b6c1c5ad27c73384))

## [4.7.0](https://github.com/bgd-labs/aave-address-book/compare/v4.6.0...v4.7.0) (2024-12-10)


### Features

* add bridges ([#718](https://github.com/bgd-labs/aave-address-book/issues/718)) ([937b958](https://github.com/bgd-labs/aave-address-book/commit/937b958af85b210f186959d5785b0089a650a755))
* add new stata tokens ([#719](https://github.com/bgd-labs/aave-address-book/issues/719)) ([cdb0105](https://github.com/bgd-labs/aave-address-book/commit/cdb0105bf754bffd0c4d127ba4f8aa57d4d61702))
* gho libraries ([#713](https://github.com/bgd-labs/aave-address-book/issues/713)) ([c63b6ab](https://github.com/bgd-labs/aave-address-book/commit/c63b6ab77ff3416cd70bec9d3dc8d7bbc26b3fb3))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#728](https://github.com/bgd-labs/aave-address-book/issues/728)) ([d8ccf37](https://github.com/bgd-labs/aave-address-book/commit/d8ccf37fbbf820c212386116dceeca44201a90d6))
* update aave-v3-origin with new solidity-utils lib ([#735](https://github.com/bgd-labs/aave-address-book/issues/735)) ([88c5cd4](https://github.com/bgd-labs/aave-address-book/commit/88c5cd4f65696a62b5933b507906ac75e97a46ca))

## [4.6.0](https://github.com/bgd-labs/aave-address-book/compare/v4.5.1...v4.6.0) (2024-11-21)


### Features

* deploy new proxy factory on all networks ([#707](https://github.com/bgd-labs/aave-address-book/issues/707)) ([51134ec](https://github.com/bgd-labs/aave-address-book/commit/51134ec1c1b981a9260ebebc1f1eb44d1b38cb1d))

## [4.5.1](https://github.com/bgd-labs/aave-address-book/compare/v4.5.0...v4.5.1) (2024-11-21)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#709](https://github.com/bgd-labs/aave-address-book/issues/709)) ([53edd54](https://github.com/bgd-labs/aave-address-book/commit/53edd54a4dea3e8ab2193d695d73d174dd4d89c5))

## [4.5.0](https://github.com/bgd-labs/aave-address-book/compare/v4.4.0...v4.5.0) (2024-11-20)


### Features

* lido and etherfi debt swap adapters ([#705](https://github.com/bgd-labs/aave-address-book/issues/705)) ([d35af65](https://github.com/bgd-labs/aave-address-book/commit/d35af65f4a08e141bd8839e8527c2d8be8334263))

## [4.4.0](https://github.com/bgd-labs/aave-address-book/compare/v4.3.2...v4.4.0) (2024-11-19)


### Features

* gnosis paraswap adapters ([#700](https://github.com/bgd-labs/aave-address-book/issues/700)) ([#701](https://github.com/bgd-labs/aave-address-book/issues/701)) ([49f52f1](https://github.com/bgd-labs/aave-address-book/commit/49f52f19095d64f794df7c1be59e137924131f22))

## [4.3.2](https://github.com/bgd-labs/aave-address-book/compare/v4.3.1...v4.3.2) (2024-11-18)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#697](https://github.com/bgd-labs/aave-address-book/issues/697)) ([edbed6c](https://github.com/bgd-labs/aave-address-book/commit/edbed6cfd1a9fb73f3067b46a20ef26c8254af02))
* update known errors ([#698](https://github.com/bgd-labs/aave-address-book/issues/698)) ([ea9bfd7](https://github.com/bgd-labs/aave-address-book/commit/ea9bfd792036f156db1731bde17ec1baa4e88016))

## [4.3.1](https://github.com/bgd-labs/aave-address-book/compare/v4.3.0...v4.3.1) (2024-11-06)


### Bug Fixes

* **deps:** bump actions/checkout from 4.2.0 to 4.2.2 ([#665](https://github.com/bgd-labs/aave-address-book/issues/665)) ([ee6ee1f](https://github.com/bgd-labs/aave-address-book/commit/ee6ee1fba006ed61f41d8bf43329192984126c72))

## [4.3.0](https://github.com/bgd-labs/aave-address-book/compare/v4.2.1...v4.3.0) (2024-11-05)


### Features

* add testnet base sepolia lido market ([#669](https://github.com/bgd-labs/aave-address-book/issues/669)) ([de1275e](https://github.com/bgd-labs/aave-address-book/commit/de1275e6aaf69017b777f375ac2d1d11df47775b))
* update risk stewards ([#674](https://github.com/bgd-labs/aave-address-book/issues/674)) ([d6bdf78](https://github.com/bgd-labs/aave-address-book/commit/d6bdf782d7a395cf125713205fc610c371c17220))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#671](https://github.com/bgd-labs/aave-address-book/issues/671)) ([94267fd](https://github.com/bgd-labs/aave-address-book/commit/94267fd97eefa3ed8b5b063969d88b527c8b4b9b))
* **cache:** automated cache update - updated addresses ([#682](https://github.com/bgd-labs/aave-address-book/issues/682)) ([4126d92](https://github.com/bgd-labs/aave-address-book/commit/4126d925ee5f229531b56299d7828efbc4dafd61))
* make ci work on testnets ([#681](https://github.com/bgd-labs/aave-address-book/issues/681)) ([1611ebd](https://github.com/bgd-labs/aave-address-book/commit/1611ebd4a64114b657cfe73700b3a68d970989a1))

## [4.2.1](https://github.com/bgd-labs/aave-address-book/compare/v4.2.0...v4.2.1) (2024-10-28)


### Bug Fixes

* update addresses ([#663](https://github.com/bgd-labs/aave-address-book/issues/663)) ([bbbfa22](https://github.com/bgd-labs/aave-address-book/commit/bbbfa22a5a540b7617d3541bd4253f69011d912c))
* Update guardians ([#661](https://github.com/bgd-labs/aave-address-book/issues/661)) ([5d6bac1](https://github.com/bgd-labs/aave-address-book/commit/5d6bac1f1c181ee61c5f656fcce46c3b19aaf979))

## [4.2.0](https://github.com/bgd-labs/aave-address-book/compare/v4.1.0...v4.2.0) (2024-10-19)


### Features

* **secrets:** use `ALCHEMY_API_KEY` if present ([#646](https://github.com/bgd-labs/aave-address-book/issues/646)) ([483e27d](https://github.com/bgd-labs/aave-address-book/commit/483e27dd761d5ec2b7d4d486c4d0f40433fd5832))


### Bug Fixes

* remove alchemy api key ([483e27d](https://github.com/bgd-labs/aave-address-book/commit/483e27dd761d5ec2b7d4d486c4d0f40433fd5832))
* weth gateway gnosis ([#654](https://github.com/bgd-labs/aave-address-book/issues/654)) ([7ac58c7](https://github.com/bgd-labs/aave-address-book/commit/7ac58c7e28204bddcded36df02476e8cc58dc35f))

## [4.1.0](https://github.com/bgd-labs/aave-address-book/compare/v4.0.0...v4.1.0) (2024-10-16)


### Features

* avara ui v3.2 ui data providers ([#641](https://github.com/bgd-labs/aave-address-book/issues/641)) ([#644](https://github.com/bgd-labs/aave-address-book/issues/644)) ([1bfe6bf](https://github.com/bgd-labs/aave-address-book/commit/1bfe6bf8e8e5b37f815b2563809f5c1bf4d3af19))


### Bug Fixes

* readd tokenlist ([#642](https://github.com/bgd-labs/aave-address-book/issues/642)) ([c9ab73b](https://github.com/bgd-labs/aave-address-book/commit/c9ab73be76dd4f5f8684a2cdd6614acaae7856f4))

## [4.0.0](https://github.com/bgd-labs/aave-address-book/compare/v3.7.0...v4.0.0) (2024-10-10)


### ⚠ BREAKING CHANGES

* The eMode exports on the js side now contain the full eMode configuration with the decoded bitmaps. Abis are exported via /abis to no longer mix with the addresses. Removing tokenlist from ts exports as there's no good reason to use it from here (integrations work with the toplevel json)

### Features

* ts eModes exports ([#629](https://github.com/bgd-labs/aave-address-book/issues/629)) ([4f47411](https://github.com/bgd-labs/aave-address-book/commit/4f474115b1086dc2992adf7f96330b6dbfcd3618))


### Bug Fixes

* add v3.2 config engine ([#632](https://github.com/bgd-labs/aave-address-book/issues/632)) ([cf71df4](https://github.com/bgd-labs/aave-address-book/commit/cf71df41dade698e3ec3ee6aa40f51580994f8eb))
* previous fixes were for release ci, this one for cron ci ([#626](https://github.com/bgd-labs/aave-address-book/issues/626)) ([1296c81](https://github.com/bgd-labs/aave-address-book/commit/1296c81943aaa0e2b8d602e383abf116fd3b349f))

## [3.7.0](https://github.com/bgd-labs/aave-address-book/compare/v3.6.0...v3.7.0) (2024-10-08)


### Features

* v3.2.0 upgrade ([#596](https://github.com/bgd-labs/aave-address-book/issues/596)) ([fb11d94](https://github.com/bgd-labs/aave-address-book/commit/fb11d9476f43e3ea69d4699b919a0dca602f18cb))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#613](https://github.com/bgd-labs/aave-address-book/issues/613)) ([4da9121](https://github.com/bgd-labs/aave-address-book/commit/4da912141dabc105105b1e7f29d35e7fb3d19f63))
* **cache:** automated cache update - updated addresses ([#623](https://github.com/bgd-labs/aave-address-book/issues/623)) ([6e9e12a](https://github.com/bgd-labs/aave-address-book/commit/6e9e12a4adf1e146a2b2c7d46f721e90deea5622))
* fml ([#625](https://github.com/bgd-labs/aave-address-book/issues/625)) ([a736217](https://github.com/bgd-labs/aave-address-book/commit/a73621722c21cc8445c3fc5702949268f4e3720a))
* patch ci ([#624](https://github.com/bgd-labs/aave-address-book/issues/624)) ([4771504](https://github.com/bgd-labs/aave-address-book/commit/4771504bb0beb79d6e33d8c5131fd91d70abd39b))

## [3.6.0](https://github.com/bgd-labs/aave-address-book/compare/v3.5.1...v3.6.0) (2024-10-01)


### Features

* v3.2 avax fuji contracts ([#611](https://github.com/bgd-labs/aave-address-book/issues/611)) ([ded4b64](https://github.com/bgd-labs/aave-address-book/commit/ded4b64f10fdc07b151e691d3e7bf8eeeeba89e4))
* v3.2 base sepolia contracts ([#612](https://github.com/bgd-labs/aave-address-book/issues/612)) ([ff1064e](https://github.com/bgd-labs/aave-address-book/commit/ff1064e27fc82dc6eafc9049cf5ee9fb3f395de9))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#606](https://github.com/bgd-labs/aave-address-book/issues/606)) ([e1861d9](https://github.com/bgd-labs/aave-address-book/commit/e1861d9e12ff96fd774b89a5236d16ea2e15792b))

## [3.5.1](https://github.com/bgd-labs/aave-address-book/compare/v3.5.0...v3.5.1) (2024-09-27)


### Bug Fixes

* Add addresses for paraswap adapters repay and debt swap ([#603](https://github.com/bgd-labs/aave-address-book/issues/603)) ([#604](https://github.com/bgd-labs/aave-address-book/issues/604)) ([8ef7044](https://github.com/bgd-labs/aave-address-book/commit/8ef7044f0d3338daf6cbcde1a46324585e6b7a2f))
* **cache:** automated cache update - updated addresses ([#600](https://github.com/bgd-labs/aave-address-book/issues/600)) ([53d8509](https://github.com/bgd-labs/aave-address-book/commit/53d85096dc310f4c1fbdf1e714704f9c34ca0e85))
* **cache:** automated cache update - updated addresses ([#602](https://github.com/bgd-labs/aave-address-book/issues/602)) ([eadb136](https://github.com/bgd-labs/aave-address-book/commit/eadb1369580baf2f4504ae5268cac981ca9cd2f5))

## [3.5.0](https://github.com/bgd-labs/aave-address-book/compare/v3.4.0...v3.5.0) (2024-09-21)


### Features

* add sanity checks ([#585](https://github.com/bgd-labs/aave-address-book/issues/585)) ([42247e9](https://github.com/bgd-labs/aave-address-book/commit/42247e95c5560a11e7c69111e6e595609678e363))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#586](https://github.com/bgd-labs/aave-address-book/issues/586)) ([1ff54b2](https://github.com/bgd-labs/aave-address-book/commit/1ff54b29e620ce40723c2fc9e821ee8afb448140))
* **cache:** automated cache update - updated addresses ([#590](https://github.com/bgd-labs/aave-address-book/issues/590)) ([e3e2b75](https://github.com/bgd-labs/aave-address-book/commit/e3e2b75294603350b0a58fc14311604d8c52bdab))
* **cache:** automated cache update - updated addresses ([#598](https://github.com/bgd-labs/aave-address-book/issues/598)) ([fba3d8f](https://github.com/bgd-labs/aave-address-book/commit/fba3d8f2aab560c45662f02cba401ad9cdddebcf))

## [3.4.0](https://github.com/bgd-labs/aave-address-book/compare/v3.3.0...v3.4.0) (2024-09-10)


### Features

* add zksync instance contracts ([#580](https://github.com/bgd-labs/aave-address-book/issues/580)) ([65a89f7](https://github.com/bgd-labs/aave-address-book/commit/65a89f74abb1b37c01442be4340370d5179a94bc))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#581](https://github.com/bgd-labs/aave-address-book/issues/581)) ([ac70753](https://github.com/bgd-labs/aave-address-book/commit/ac70753d16354243ab0c5553a5af3a96b7fce733))
* **cache:** automated cache update - updated addresses ([#584](https://github.com/bgd-labs/aave-address-book/issues/584)) ([4a909ce](https://github.com/bgd-labs/aave-address-book/commit/4a909cea419ba8d2f70d9ba73310344a1d11e86d))

## [3.3.0](https://github.com/bgd-labs/aave-address-book/compare/v3.2.1...v3.3.0) (2024-09-09)


### Features

* add EtherFi caps ([#566](https://github.com/bgd-labs/aave-address-book/issues/566)) ([d9fee6c](https://github.com/bgd-labs/aave-address-book/commit/d9fee6cf4f3a5e73ea073a3020483309e2053246))
* add risk steward for etherfi ([#569](https://github.com/bgd-labs/aave-address-book/issues/569)) ([6b29c5f](https://github.com/bgd-labs/aave-address-book/commit/6b29c5f6b18d861b707872047061fc269edd5467))
* automate verify ([#570](https://github.com/bgd-labs/aave-address-book/issues/570)) ([c6d651b](https://github.com/bgd-labs/aave-address-book/commit/c6d651bafc29ea448351ba05ccb64d4776352dfb))


### Bug Fixes

* add viem to ui ([#572](https://github.com/bgd-labs/aave-address-book/issues/572)) ([5efdaf4](https://github.com/bgd-labs/aave-address-book/commit/5efdaf4d3d1de8226a6e83ba9fc92b38a203798d))
* **cache:** automated cache update - updated addresses ([#571](https://github.com/bgd-labs/aave-address-book/issues/571)) ([3f45fcc](https://github.com/bgd-labs/aave-address-book/commit/3f45fcc952bae9b0a7d6d35742f06eb313c7cfb6))
* readd type ([#573](https://github.com/bgd-labs/aave-address-book/issues/573)) ([20e6b13](https://github.com/bgd-labs/aave-address-book/commit/20e6b13cbf838bce1f2b4f18c5894217f73d4143))

## [3.2.1](https://github.com/bgd-labs/aave-address-book/compare/v3.2.0...v3.2.1) (2024-09-02)


### Bug Fixes

* patch ci ([#564](https://github.com/bgd-labs/aave-address-book/issues/564)) ([851daa5](https://github.com/bgd-labs/aave-address-book/commit/851daa597073b3d2967d2d91b6a201bca9c59546))

## [3.2.0](https://github.com/bgd-labs/aave-address-book/compare/v3.1.1...v3.2.0) (2024-09-02)


### Features

* add download for gnosis ([#556](https://github.com/bgd-labs/aave-address-book/issues/556)) ([bb2e157](https://github.com/bgd-labs/aave-address-book/commit/bb2e15766ff59e400c4188c9b6ab635b24a6f6c7))
* add generalised risk stewards ([#553](https://github.com/bgd-labs/aave-address-book/issues/553)) ([be65fa2](https://github.com/bgd-labs/aave-address-book/commit/be65fa2d7470c8f4da59365890c646efb1066cb7))
* link to file instead of download ([#558](https://github.com/bgd-labs/aave-address-book/issues/558)) ([7356ce6](https://github.com/bgd-labs/aave-address-book/commit/7356ce6efe78e1ff65b42d0ea44a75e5c913fd02))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#528](https://github.com/bgd-labs/aave-address-book/issues/528)) ([eec868e](https://github.com/bgd-labs/aave-address-book/commit/eec868eb1a3cd66ae01a93b499b6f6c9f7674cad))
* **cache:** automated cache update - updated addresses ([#540](https://github.com/bgd-labs/aave-address-book/issues/540)) ([5c08f2b](https://github.com/bgd-labs/aave-address-book/commit/5c08f2b7475f3af24d8f29f35a707d18716ebb93))
* **cache:** automated cache update - updated addresses ([#546](https://github.com/bgd-labs/aave-address-book/issues/546)) ([2d7c918](https://github.com/bgd-labs/aave-address-book/commit/2d7c91846bd111ce6ae4bc7f57fd4f939770572f))
* **cache:** automated cache update - updated addresses ([#554](https://github.com/bgd-labs/aave-address-book/issues/554)) ([6f989a0](https://github.com/bgd-labs/aave-address-book/commit/6f989a0dab36e553d8d5dd1e50ef3d6b5f920043))
* disable-release-ci ([#536](https://github.com/bgd-labs/aave-address-book/issues/536)) ([ebca49e](https://github.com/bgd-labs/aave-address-book/commit/ebca49e22cc05f65acd269ac074f4b39fdd35ea3))
* don't make a realease for every shitty dependency upgrade ([#538](https://github.com/bgd-labs/aave-address-book/issues/538)) ([32a608a](https://github.com/bgd-labs/aave-address-book/commit/32a608ac716e943f0e62c8763f380a4ce6f33492))
* remove trailing slashes ([#539](https://github.com/bgd-labs/aave-address-book/issues/539)) ([0432434](https://github.com/bgd-labs/aave-address-book/commit/0432434fc46fc23e8d71ac4d0586c77e3d77e4fe))
* update ci ([#557](https://github.com/bgd-labs/aave-address-book/issues/557)) ([15e00d7](https://github.com/bgd-labs/aave-address-book/commit/15e00d7a735494308e9c22eda7002ab0d1257c51))
* upgrade pull request ci ([#548](https://github.com/bgd-labs/aave-address-book/issues/548)) ([5886099](https://github.com/bgd-labs/aave-address-book/commit/58860997091f5e2f2935422f79ba00c1f444ab0d))

## [3.1.1](https://github.com/bgd-labs/aave-address-book/compare/v3.1.0...v3.1.1) (2024-08-13)


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#522](https://github.com/bgd-labs/aave-address-book/issues/522)) ([a1e2224](https://github.com/bgd-labs/aave-address-book/commit/a1e22240a666f1277fc1a9fc3d067a7d21347913))
* zksync address ([#524](https://github.com/bgd-labs/aave-address-book/issues/524)) ([4ddb464](https://github.com/bgd-labs/aave-address-book/commit/4ddb4646a8c743a0bad578675279cde9723d7b91))

## [3.1.0](https://github.com/bgd-labs/aave-address-book/compare/v3.0.4...v3.1.0) (2024-08-07)


### Features

* add zksync addresses ([#500](https://github.com/bgd-labs/aave-address-book/issues/500)) ([0a91312](https://github.com/bgd-labs/aave-address-book/commit/0a91312adb4a99885cddaa3e5d593101bfbff090))


### Bug Fixes

* **cache:** automated cache update - updated addresses ([#519](https://github.com/bgd-labs/aave-address-book/issues/519)) ([2769668](https://github.com/bgd-labs/aave-address-book/commit/27696681c7ff75d71677266abf6ea3d0668f7bfd))
* **cache:** automated cache update - updated addresses ([#521](https://github.com/bgd-labs/aave-address-book/issues/521)) ([ecf4c7e](https://github.com/bgd-labs/aave-address-book/commit/ecf4c7e09cc0c0661f15d2d4a1c6a958726f0415))

## [3.0.4](https://github.com/bgd-labs/aave-address-book/compare/v3.0.3...v3.0.4) (2024-08-05)


### Bug Fixes

* added updated base config engine for 3.1 ([#518](https://github.com/bgd-labs/aave-address-book/issues/518)) ([93419b6](https://github.com/bgd-labs/aave-address-book/commit/93419b6be987a7f4c41b3dea03563b7499fee996))
* v3.1 config engine address ([#516](https://github.com/bgd-labs/aave-address-book/issues/516)) ([e11b22f](https://github.com/bgd-labs/aave-address-book/commit/e11b22f4368d62cb7693817b87b7dba4cb5fd620))

## [3.0.3](https://github.com/bgd-labs/aave-address-book/compare/v3.0.2...v3.0.3) (2024-08-01)


### Bug Fixes

* tokens list generator and remove assets from project ([#513](https://github.com/bgd-labs/aave-address-book/issues/513)) ([82be66f](https://github.com/bgd-labs/aave-address-book/commit/82be66f9330edbdb4d01391992dddd53da01aecd))

## [3.0.2](https://github.com/bgd-labs/aave-address-book/compare/v3.0.1...v3.0.2) (2024-07-31)


### Bug Fixes

* always set eMode NONE, trigger release for address changes, export external libraries library ([#508](https://github.com/bgd-labs/aave-address-book/issues/508)) ([19649ca](https://github.com/bgd-labs/aave-address-book/commit/19649cad1cbf51d22a978770e03aac99721b0cfa))
* update chain icon in the UI (change to icon from web3 package) ([#511](https://github.com/bgd-labs/aave-address-book/issues/511)) ([78daad4](https://github.com/bgd-labs/aave-address-book/commit/78daad4ffc7c15d56d5211512ca5b825d4f98ebd))
* updated libs with origin fix for serialization cleanup ([#509](https://github.com/bgd-labs/aave-address-book/issues/509)) ([500dfc2](https://github.com/bgd-labs/aave-address-book/commit/500dfc2440469f08b3bc654aaf65c0a3e2ab7e3a))

## [3.0.1](https://github.com/bgd-labs/aave-address-book/compare/v3.0.0...v3.0.1) (2024-07-27)


### Bug Fixes

* update origin ([#498](https://github.com/bgd-labs/aave-address-book/issues/498)) ([b73de88](https://github.com/bgd-labs/aave-address-book/commit/b73de88660cf0aca21bde80a93ea7909013b2341))

## [3.0.0](https://github.com/bgd-labs/aave-address-book/compare/v2.31.0...v3.0.0) (2024-07-23)


### ⚠ BREAKING CHANGES

* migrate to aave-dao/aave-v3origin ([#476](https://github.com/bgd-labs/aave-address-book/issues/476))
* replace config engine with 3.1 ([#486](https://github.com/bgd-labs/aave-address-book/issues/486))

### Features

* add CAPS_PLUS_RISK_STEWARD address in Lido Ethereum V3 config ([#495](https://github.com/bgd-labs/aave-address-book/issues/495)) ([f6ac658](https://github.com/bgd-labs/aave-address-book/commit/f6ac658bd0a8854b2880d52969ebf38710a7eb4b))
* migrate to aave-dao/aave-v3origin ([#476](https://github.com/bgd-labs/aave-address-book/issues/476)) ([0c3bd1f](https://github.com/bgd-labs/aave-address-book/commit/0c3bd1fa910413d94380b88b7daf767604d28f19))
* replace config engine with 3.1 ([#486](https://github.com/bgd-labs/aave-address-book/issues/486)) ([343a7be](https://github.com/bgd-labs/aave-address-book/commit/343a7bedb3a60f9012c9427472b43397c0d83d25))

## [2.31.0](https://github.com/bgd-labs/aave-address-book/compare/v2.30.0...v2.31.0) (2024-07-18)


### Features

* Granular Guardian addresses ([#492](https://github.com/bgd-labs/aave-address-book/issues/492)) ([c89c7f6](https://github.com/bgd-labs/aave-address-book/commit/c89c7f69e1ed952df4e4ddc393000b4b2688efaf))
* Lido pool addresses
## [2.30.0](https://github.com/bgd-labs/aave-address-book/compare/v2.29.0...v2.30.0) (2024-07-02)


### Features

* Add create3 factory to scroll network ([#469](https://github.com/bgd-labs/aave-address-book/issues/469)) ([548b080](https://github.com/bgd-labs/aave-address-book/commit/548b08018a141f9800664800b00af7d1e4ee468d))


### Bug Fixes

* assets icons for `susde` and `usde` ([#478](https://github.com/bgd-labs/aave-address-book/issues/478)) ([7d86bab](https://github.com/bgd-labs/aave-address-book/commit/7d86bab0543bd6db34b696a56a80ca34b71de9ce))
* update abis ([#468](https://github.com/bgd-labs/aave-address-book/issues/468)) ([11cb363](https://github.com/bgd-labs/aave-address-book/commit/11cb363ba4d94b511c1336af45608305ad3d8166))

## [2.29.0](https://github.com/bgd-labs/aave-address-book/compare/v2.28.0...v2.29.0) (2024-06-10)


### Features

* add arbitrum stata oracle ([#465](https://github.com/bgd-labs/aave-address-book/issues/465)) ([843be68](https://github.com/bgd-labs/aave-address-book/commit/843be688d7b9853b04f8860db17c3a064729fd2c))

## [2.28.0](https://github.com/bgd-labs/aave-address-book/compare/v2.27.0...v2.28.0) (2024-06-06)


### Features

* add aave cl robot operator ([#459](https://github.com/bgd-labs/aave-address-book/issues/459)) ([b789e07](https://github.com/bgd-labs/aave-address-book/commit/b789e0763fcc6a0b83daa3c16b7b7e32a6f86b30))
* improve search ([#460](https://github.com/bgd-labs/aave-address-book/issues/460)) ([2dc0566](https://github.com/bgd-labs/aave-address-book/commit/2dc0566a46fb7747acee3791cf42e578db34edfe))
* update search algo, use uFuzzy ([#461](https://github.com/bgd-labs/aave-address-book/issues/461)) ([bf12e26](https://github.com/bgd-labs/aave-address-book/commit/bf12e26e8408142bfd9d3edb4481da3a681fce59))


### Bug Fixes

* added `susde` and `usde` assets icons ([#463](https://github.com/bgd-labs/aave-address-book/issues/463)) ([e87e5b5](https://github.com/bgd-labs/aave-address-book/commit/e87e5b59e24f1e2aa90e1e66016d606958bfda3d))
* added missing assets ([#457](https://github.com/bgd-labs/aave-address-book/issues/457)) ([1b6997f](https://github.com/bgd-labs/aave-address-book/commit/1b6997f671e2678fbc8716a92043313704afa6b3))
* improve fuzzing ([#449](https://github.com/bgd-labs/aave-address-book/issues/449)) ([8b1a6c5](https://github.com/bgd-labs/aave-address-book/commit/8b1a6c5b022b60eb4a71f85d11f8a584a8c487af))
* show threshold ([#452](https://github.com/bgd-labs/aave-address-book/issues/452)) ([f73f77c](https://github.com/bgd-labs/aave-address-book/commit/f73f77ca03f61c7bc3b6899d173e96ea200cf529))

## [2.27.0](https://github.com/bgd-labs/aave-address-book/compare/v2.26.1...v2.27.0) (2024-05-14)


### Features

* add missing abis ([#438](https://github.com/bgd-labs/aave-address-book/issues/438)) ([aa24a81](https://github.com/bgd-labs/aave-address-book/commit/aa24a81922da3d7bbb7eab6bdfaada29300f79a9))
* add oseth icons ([#447](https://github.com/bgd-labs/aave-address-book/issues/447)) ([b27abbb](https://github.com/bgd-labs/aave-address-book/commit/b27abbb39a7dc2ff3c287813872e59e3d891a5ad))

## [2.26.1](https://github.com/bgd-labs/aave-address-book/compare/v2.26.0...v2.26.1) (2024-04-23)


### Bug Fixes

* readd harmony ([#436](https://github.com/bgd-labs/aave-address-book/issues/436)) ([cc7b565](https://github.com/bgd-labs/aave-address-book/commit/cc7b5659042631b6728bbf1e966db9072e80fdb1))
* use proper rpc on scroll ([#434](https://github.com/bgd-labs/aave-address-book/issues/434)) ([b71481b](https://github.com/bgd-labs/aave-address-book/commit/b71481be2a71902d8b9d2d4aa3a6f50a3f83896b))

## [2.26.0](https://github.com/bgd-labs/aave-address-book/compare/v2.25.1...v2.26.0) (2024-04-22)


### Features

* added weeth icons to assets ([#427](https://github.com/bgd-labs/aave-address-book/issues/427)) ([572ee8d](https://github.com/bgd-labs/aave-address-book/commit/572ee8d6281f54a086a2c61c680675bce4606d5b))


### Bug Fixes

* Fix uiPoolDataProvider contract on Harmony ([#428](https://github.com/bgd-labs/aave-address-book/issues/428)) ([15bc0a8](https://github.com/bgd-labs/aave-address-book/commit/15bc0a8e7cd9717af393aaab89381aed91531092))
* remove mumbai ([#432](https://github.com/bgd-labs/aave-address-book/issues/432)) ([64e51f9](https://github.com/bgd-labs/aave-address-book/commit/64e51f98d64bc0dc59adae0a11a29d4e92537a3f))

## [2.25.1](https://github.com/bgd-labs/aave-address-book/compare/v2.25.0...v2.25.1) (2024-04-11)


### Bug Fixes

* update addresses ([#422](https://github.com/bgd-labs/aave-address-book/issues/422)) ([8bc2d0b](https://github.com/bgd-labs/aave-address-book/commit/8bc2d0b1efc7716342b4ae48a2378a01b7ff9465))

## [2.25.0](https://github.com/bgd-labs/aave-address-book/compare/v2.24.2...v2.25.0) (2024-03-21)


### Features

* add aave v1 ([#409](https://github.com/bgd-labs/aave-address-book/issues/409)) ([c614b39](https://github.com/bgd-labs/aave-address-book/commit/c614b3927fba196393b269d27d93ee71ed4ba485))

## [2.24.2](https://github.com/bgd-labs/aave-address-book/compare/v2.24.1...v2.24.2) (2024-03-14)


### Bug Fixes

* add v2 impls ([#404](https://github.com/bgd-labs/aave-address-book/issues/404)) ([90f5416](https://github.com/bgd-labs/aave-address-book/commit/90f5416aa25e806290be6bb125769b83f8f5b273))

## [2.24.1](https://github.com/bgd-labs/aave-address-book/compare/v2.24.0...v2.24.1) (2024-03-13)


### Bug Fixes

* remove tokenList ([#402](https://github.com/bgd-labs/aave-address-book/issues/402)) ([ef195f0](https://github.com/bgd-labs/aave-address-book/commit/ef195f0473144453bed9e4ec1d22c4f3b9e41bde))

## [2.24.0](https://github.com/bgd-labs/aave-address-book/compare/v2.23.0...v2.24.0) (2024-03-11)


### Features

* add arbitrum sepolia ([#396](https://github.com/bgd-labs/aave-address-book/issues/396)) ([d6124b0](https://github.com/bgd-labs/aave-address-book/commit/d6124b068788491cd2776f119187e9ffb7a5b9ff))


### Bug Fixes

* add impls ([#399](https://github.com/bgd-labs/aave-address-book/issues/399)) ([59151e7](https://github.com/bgd-labs/aave-address-book/commit/59151e77a4b359be4f59f20b5db6ce499af36a41))

## [2.23.0](https://github.com/bgd-labs/aave-address-book/compare/v2.22.1...v2.23.0) (2024-03-07)


### Features

* add keyboard navigation ([#392](https://github.com/bgd-labs/aave-address-book/issues/392)) ([dcd9526](https://github.com/bgd-labs/aave-address-book/commit/dcd952633b8a94a379d89ae4801521651262bd84))
* added IBaseAdapter interface ([#394](https://github.com/bgd-labs/aave-address-book/issues/394)) ([85ee922](https://github.com/bgd-labs/aave-address-book/commit/85ee922bc68b2bf986e80720f99a160515690ab6))
* base sepolia addresses ([#384](https://github.com/bgd-labs/aave-address-book/issues/384)) ([573f481](https://github.com/bgd-labs/aave-address-book/commit/573f481205620c12046c3d784512ab67692a3423))
* optimism sepolia addresses ([#393](https://github.com/bgd-labs/aave-address-book/issues/393)) ([88ecb79](https://github.com/bgd-labs/aave-address-book/commit/88ecb79822afed57a54a8cc447b26416dfd01707))
* persist search value in url ([#387](https://github.com/bgd-labs/aave-address-book/issues/387)) ([204361a](https://github.com/bgd-labs/aave-address-book/commit/204361a8860004ad3b26e33095561a70d4a6d1e4))


### Bug Fixes

* ignore tokenlist ([#391](https://github.com/bgd-labs/aave-address-book/issues/391)) ([eb407f6](https://github.com/bgd-labs/aave-address-book/commit/eb407f6530dcf6e852a988504f16843ae69f220b))
* use native replaceState instead of router ([#390](https://github.com/bgd-labs/aave-address-book/issues/390)) ([9afe436](https://github.com/bgd-labs/aave-address-book/commit/9afe436b3b360cc24ce66adbd03a8d1171e8323f))
* wrap Search in Suspense ([#389](https://github.com/bgd-labs/aave-address-book/issues/389)) ([75d903b](https://github.com/bgd-labs/aave-address-book/commit/75d903b3819eed0212bd644d1a01e4bfe12acf6d))

## [2.22.1](https://github.com/bgd-labs/aave-address-book/compare/v2.22.0...v2.22.1) (2024-02-29)


### Bug Fixes

* remove zero addresses ([#385](https://github.com/bgd-labs/aave-address-book/issues/385)) ([568b2c6](https://github.com/bgd-labs/aave-address-book/commit/568b2c6010d7e145227a3d23d8f7454dd50769ec))

## [2.22.0](https://github.com/bgd-labs/aave-address-book/compare/v2.21.1...v2.22.0) (2024-02-28)


### Features

* add token icons & remove optimism goerli ([#378](https://github.com/bgd-labs/aave-address-book/issues/378)) ([6435899](https://github.com/bgd-labs/aave-address-book/commit/6435899458adc2f35a3b0f87b68f1a16d9b6112e))


### Bug Fixes

* upload ci ([6435899](https://github.com/bgd-labs/aave-address-book/commit/6435899458adc2f35a3b0f87b68f1a16d9b6112e))
* upload to quicknode ([6435899](https://github.com/bgd-labs/aave-address-book/commit/6435899458adc2f35a3b0f87b68f1a16d9b6112e))

## [2.21.1](https://github.com/bgd-labs/aave-address-book/compare/v2.21.0...v2.21.1) (2024-02-21)


### Bug Fixes

* add tokenlist to ts exports ([#376](https://github.com/bgd-labs/aave-address-book/issues/376)) ([bb0acd6](https://github.com/bgd-labs/aave-address-book/commit/bb0acd6062929e299c86fc65b87c6336d7c40d5d))

## [2.21.0](https://github.com/bgd-labs/aave-address-book/compare/v2.20.0...v2.21.0) (2024-02-21)


### Features

* add github link ([#370](https://github.com/bgd-labs/aave-address-book/issues/370)) ([ab278d7](https://github.com/bgd-labs/aave-address-book/commit/ab278d7327ee183f7472b5266bb434c2439cefb7))
* add new abis ([#372](https://github.com/bgd-labs/aave-address-book/issues/372)) ([6e89a60](https://github.com/bgd-labs/aave-address-book/commit/6e89a60f1b2ee8b8f2679f6ee49cf48923f53cf1))
* add stata for scroll and bnb ([#371](https://github.com/bgd-labs/aave-address-book/issues/371)) ([f84bd69](https://github.com/bgd-labs/aave-address-book/commit/f84bd6992c8bf461ba10538053f85be1e4a22124))
* update UI, add logo ([#374](https://github.com/bgd-labs/aave-address-book/issues/374)) ([c23a202](https://github.com/bgd-labs/aave-address-book/commit/c23a20229ca21ca5a786050846a1965882700351))


### Bug Fixes

* patch list ([6e89a60](https://github.com/bgd-labs/aave-address-book/commit/6e89a60f1b2ee8b8f2679f6ee49cf48923f53cf1))
* remove gov v2 and strategy are no longer useful ([#367](https://github.com/bgd-labs/aave-address-book/issues/367)) ([1775497](https://github.com/bgd-labs/aave-address-book/commit/17754972fcc15ea4ea15231308af22610f121d83))
* update tokenlist ([6e89a60](https://github.com/bgd-labs/aave-address-book/commit/6e89a60f1b2ee8b8f2679f6ee49cf48923f53cf1))
* use proper type ([6e89a60](https://github.com/bgd-labs/aave-address-book/commit/6e89a60f1b2ee8b8f2679f6ee49cf48923f53cf1))
* use proper type ([6e89a60](https://github.com/bgd-labs/aave-address-book/commit/6e89a60f1b2ee8b8f2679f6ee49cf48923f53cf1))

## [2.20.0](https://github.com/bgd-labs/aave-address-book/compare/v2.19.0...v2.20.0) (2024-02-18)


### Features

* add eur aggregators and pyUSd ([#360](https://github.com/bgd-labs/aave-address-book/issues/360)) ([4050131](https://github.com/bgd-labs/aave-address-book/commit/4050131e6b80c508d42c37b53fb959ac1d08571f))
* generate tokenlist alongside the repo ([#353](https://github.com/bgd-labs/aave-address-book/issues/353)) ([a1a60f6](https://github.com/bgd-labs/aave-address-book/commit/a1a60f64487e1afbc6390242b1cc10bab131d1b9))


### Bug Fixes

* add favicon w/transparent bg ([#363](https://github.com/bgd-labs/aave-address-book/issues/363)) ([80447d8](https://github.com/bgd-labs/aave-address-book/commit/80447d84334c4a5185fc4f5d55e17f99a1c9f8c4))
* remove arbitrum goerli ([#361](https://github.com/bgd-labs/aave-address-book/issues/361)) ([179f064](https://github.com/bgd-labs/aave-address-book/commit/179f06464c503b39b6715b4382ca4270677ba099))
* skip update if no changes ([594087e](https://github.com/bgd-labs/aave-address-book/commit/594087e2857b6be3d71361e270b341812e7b5ba6))

## [2.19.0](https://github.com/bgd-labs/aave-address-book/compare/v2.18.1...v2.19.0) (2024-01-30)


### Features

* add delegation abis ([#344](https://github.com/bgd-labs/aave-address-book/issues/344)) ([a282f3b](https://github.com/bgd-labs/aave-address-book/commit/a282f3b1706548894197473cc4d9dfbbc97fc5de))
* gsm addresses ([#342](https://github.com/bgd-labs/aave-address-book/issues/342)) ([541f2ac](https://github.com/bgd-labs/aave-address-book/commit/541f2ac7f0406c55cf47cfc9152065a817647eba))

## [2.18.1](https://github.com/bgd-labs/aave-address-book/compare/v2.18.0...v2.18.1) (2024-01-25)


### Bug Fixes

* add chainId to js sm export ([#338](https://github.com/bgd-labs/aave-address-book/issues/338)) ([988ec45](https://github.com/bgd-labs/aave-address-book/commit/988ec4555be7701e63a28229cbd4054a07563c71))

## [2.18.0](https://github.com/bgd-labs/aave-address-book/compare/v2.17.0...v2.18.0) (2024-01-22)


### Features

* generate new abis ([#332](https://github.com/bgd-labs/aave-address-book/issues/332)) ([f747345](https://github.com/bgd-labs/aave-address-book/commit/f747345eba0b39a4d8e4aa045b6586d10f1e2446))


### Bug Fixes

* scroll addresses ([#336](https://github.com/bgd-labs/aave-address-book/issues/336)) ([f2c544a](https://github.com/bgd-labs/aave-address-book/commit/f2c544a8bfac4d534ce42d93524bdae4eca1119f))

## [2.17.0](https://github.com/bgd-labs/aave-address-book/compare/v2.16.0...v2.17.0) (2024-01-18)


### Features

* add stk AAVE wstETH BPTv2 ([#330](https://github.com/bgd-labs/aave-address-book/issues/330)) ([79b1847](https://github.com/bgd-labs/aave-address-book/commit/79b18475bc2375782353916c9c4084861e67fba3))

## [2.16.0](https://github.com/bgd-labs/aave-address-book/compare/v2.15.2...v2.16.0) (2024-01-18)


### Features

* Add GHO token address to Aave V3 Sepolia Pool and Arbitrum Sepolia ([#326](https://github.com/bgd-labs/aave-address-book/issues/326)) ([2e2a694](https://github.com/bgd-labs/aave-address-book/commit/2e2a69463e6c0fb9cb878afe5fb239186169f0ec))
* add stk GGHO ([#328](https://github.com/bgd-labs/aave-address-book/issues/328)) ([3a887dd](https://github.com/bgd-labs/aave-address-book/commit/3a887dd4e39cd04b34b61856f696959e02c2fa0a))

## [2.15.2](https://github.com/bgd-labs/aave-address-book/compare/v2.15.1...v2.15.2) (2024-01-15)


### Bug Fixes

* add protocol guardian for scroll ([#323](https://github.com/bgd-labs/aave-address-book/issues/323)) ([06b67e5](https://github.com/bgd-labs/aave-address-book/commit/06b67e52c89993eafebbb9ad6bf91f286b660bed))

## [2.15.1](https://github.com/bgd-labs/aave-address-book/compare/v2.15.0...v2.15.1) (2024-01-15)


### Bug Fixes

* patch harmony ([#321](https://github.com/bgd-labs/aave-address-book/issues/321)) ([742f6b3](https://github.com/bgd-labs/aave-address-book/commit/742f6b3f1c1155e1092b14ab6fcc8836ee52c464))

## [2.15.0](https://github.com/bgd-labs/aave-address-book/compare/v2.14.0...v2.15.0) (2024-01-12)


### Features

* add polygon zkEVM contracts ([#320](https://github.com/bgd-labs/aave-address-book/issues/320)) ([772807c](https://github.com/bgd-labs/aave-address-book/commit/772807c81dc831b51f942506253c0d90fb03e65c))
* added scroll contracts ([#307](https://github.com/bgd-labs/aave-address-book/issues/307)) ([a53910d](https://github.com/bgd-labs/aave-address-book/commit/a53910d9b71c6653f23d08443264ad898119b391))

## [2.14.0](https://github.com/bgd-labs/aave-address-book/compare/v2.13.3...v2.14.0) (2024-01-04)


### Features

* upgrade weth gateway ([#316](https://github.com/bgd-labs/aave-address-book/issues/316)) ([575eac6](https://github.com/bgd-labs/aave-address-book/commit/575eac6d595d5d15ba5e6ca9192a2f2a5c719022))

## [2.13.3](https://github.com/bgd-labs/aave-address-book/compare/v2.13.2...v2.13.3) (2023-12-23)


### Bug Fixes

* resolve regression in commonjs bundling introduced in 2.13.1 ([#314](https://github.com/bgd-labs/aave-address-book/issues/314)) ([d573ee5](https://github.com/bgd-labs/aave-address-book/commit/d573ee52acf0f78c1129efee6b3d360475da9296))

## [2.13.2](https://github.com/bgd-labs/aave-address-book/compare/v2.13.1...v2.13.2) (2023-12-22)


### Bug Fixes

* replace rpcs ([#312](https://github.com/bgd-labs/aave-address-book/issues/312)) ([2e1b66e](https://github.com/bgd-labs/aave-address-book/commit/2e1b66e5277e53e15f6774f6c418c2be5221018b))
* use custom rpcs ([a62c801](https://github.com/bgd-labs/aave-address-book/commit/a62c801d5c24317708e08ca4c93d8658eabbafac))

## [2.13.1](https://github.com/bgd-labs/aave-address-book/compare/v2.13.0...v2.13.1) (2023-12-20)


### Bug Fixes

* update packages & run on node 20 ([#308](https://github.com/bgd-labs/aave-address-book/issues/308)) ([2496e82](https://github.com/bgd-labs/aave-address-book/commit/2496e824cad9d15071e78ba557182a7ceeb1ff4b))

## [2.13.0](https://github.com/bgd-labs/aave-address-book/compare/v2.12.0...v2.13.0) (2023-12-04)


### Features

* add static a token factory ([#294](https://github.com/bgd-labs/aave-address-book/issues/294)) ([03e04f0](https://github.com/bgd-labs/aave-address-book/commit/03e04f0fd8012ca7cf74c2d7019fd544b8c0aac8))
* update bridge address ([#295](https://github.com/bgd-labs/aave-address-book/issues/295)) ([c582623](https://github.com/bgd-labs/aave-address-book/commit/c5826233a2427272a88e09dfcc562f1115736327))

## [2.12.0](https://github.com/bgd-labs/aave-address-book/compare/v2.11.0...v2.12.0) (2023-11-20)


### Features

* add bnb addresses ([#292](https://github.com/bgd-labs/aave-address-book/issues/292)) ([2d16c86](https://github.com/bgd-labs/aave-address-book/commit/2d16c86169ef8a040300652d08e422589035a279))


### Bug Fixes

* pdp address on amm is in a different slot ([#287](https://github.com/bgd-labs/aave-address-book/issues/287)) ([1d47ffe](https://github.com/bgd-labs/aave-address-book/commit/1d47ffe701a1c49ab546c7295e671e01e40736d5))
* update aave-v3-core ([#293](https://github.com/bgd-labs/aave-address-book/issues/293)) ([a09a083](https://github.com/bgd-labs/aave-address-book/commit/a09a083130429702ed2674291b2bcccdcff21104))

## [2.11.0](https://github.com/bgd-labs/aave-address-book/compare/v2.10.0...v2.11.0) (2023-11-08)


### Features

* add collateral manager ([#283](https://github.com/bgd-labs/aave-address-book/issues/283)) ([c852ff7](https://github.com/bgd-labs/aave-address-book/commit/c852ff7c1b0d0bd45b1a2916dca63d3031b1684f))
* add stkabpt usd oracles ([#285](https://github.com/bgd-labs/aave-address-book/issues/285)) ([1539dfa](https://github.com/bgd-labs/aave-address-book/commit/1539dfa534dd03518f857a9fe283bc08cadf09d4))

## [2.10.0](https://github.com/bgd-labs/aave-address-book/compare/v2.9.0...v2.10.0) (2023-11-03)


### Features

* add freezing stewards ([#278](https://github.com/bgd-labs/aave-address-book/issues/278)) ([72ae34d](https://github.com/bgd-labs/aave-address-book/commit/72ae34d362e9793acc8d674179038c0f8fcc94fa))
* added aave merkle distributor addresses ([#280](https://github.com/bgd-labs/aave-address-book/issues/280)) ([3a20d76](https://github.com/bgd-labs/aave-address-book/commit/3a20d761d68f7cafb69163864b0c46b21bc3ccf1))

## [2.9.0](https://github.com/bgd-labs/aave-address-book/compare/v2.8.0...v2.9.0) (2023-11-02)


### Features

* add ui pool data provider abis ([#276](https://github.com/bgd-labs/aave-address-book/issues/276)) ([e35ab6e](https://github.com/bgd-labs/aave-address-book/commit/e35ab6e6cc1c30aa2394172c6f204a4654e985e1))


### Bug Fixes

* add protocol guardian ([#275](https://github.com/bgd-labs/aave-address-book/issues/275)) ([1cc00a0](https://github.com/bgd-labs/aave-address-book/commit/1cc00a0d0e73be00f8882c2b676a26e24ecb7e13))

## [2.8.0](https://github.com/bgd-labs/aave-address-book/compare/v2.7.0...v2.8.0) (2023-10-24)


### Features

* add gnosis chain ([#263](https://github.com/bgd-labs/aave-address-book/issues/263)) ([1063411](https://github.com/bgd-labs/aave-address-book/commit/1063411d276c58158d46bd51a15513c63889c242))
* gov v3-abis ([#268](https://github.com/bgd-labs/aave-address-book/issues/268)) ([452f760](https://github.com/bgd-labs/aave-address-book/commit/452f760d4133d1aba15434beaaaa8b3b3e71b457))
* rename to config engine ([#266](https://github.com/bgd-labs/aave-address-book/issues/266)) ([4002972](https://github.com/bgd-labs/aave-address-book/commit/4002972ab5d2f7c1256b34de48b887abe86ac090))


### Bug Fixes

* don't fail on missing test ([7758182](https://github.com/bgd-labs/aave-address-book/commit/7758182cf72090f22b469654a9a9af6af3cf59ff))
* rename binance to bnb ([#262](https://github.com/bgd-labs/aave-address-book/issues/262)) ([35285a2](https://github.com/bgd-labs/aave-address-book/commit/35285a26991ce19cddca48a8fe4f6ce50ece5943))
* switch to release please ([94f54e1](https://github.com/bgd-labs/aave-address-book/commit/94f54e19795443fd4b00da3199598839634e7c23))

## [2.7.0](https://github.com/bgd-labs/aave-address-book/compare/v2.6.0...v2.7.0) (2023-10-03)


### Features

* add entrypoint per network & paraswap fee claimers ([#257](https://github.com/bgd-labs/aave-address-book/issues/257)) ([974f5b8](https://github.com/bgd-labs/aave-address-book/commit/974f5b85ff327dafd62e429044d063fd64851248))

## [2.6.0](https://github.com/bgd-labs/aave-address-book/compare/v2.5.0...v2.6.0) (2023-09-28)


### Features

* add base debt swap ([#255](https://github.com/bgd-labs/aave-address-book/issues/255)) ([225d138](https://github.com/bgd-labs/aave-address-book/commit/225d138ea394c03f92d125d06437f66a5280199f))
* move interfaces to single files ([#254](https://github.com/bgd-labs/aave-address-book/issues/254)) ([a041491](https://github.com/bgd-labs/aave-address-book/commit/a0414914b1c9d4a4986833183f309bf0ea36d6dc))

## [2.5.0](https://github.com/bgd-labs/aave-address-book/compare/v2.4.2...v2.5.0) (2023-09-27)


### Features

* upgrade debt swap adapters ([#214](https://github.com/bgd-labs/aave-address-book/issues/214)) ([ed9d2f9](https://github.com/bgd-labs/aave-address-book/commit/ed9d2f93dad7fddf2e4d995cebd5b8468038bb64))

### [2.4.2](https://github.com/bgd-labs/aave-address-book/compare/v2.4.1...v2.4.2) (2023-09-21)


### Bug Fixes

* added voting strategy and data warehouse ([#250](https://github.com/bgd-labs/aave-address-book/issues/250)) ([cb4af18](https://github.com/bgd-labs/aave-address-book/commit/cb4af18214cb370f4c309686a863ccb340671aaf))
* update gho ir ([#251](https://github.com/bgd-labs/aave-address-book/issues/251)) ([f2d16fc](https://github.com/bgd-labs/aave-address-book/commit/f2d16fcdb5b24559691035f74e32afea98d6e703))
* update governancev2 links ([#249](https://github.com/bgd-labs/aave-address-book/issues/249)) ([63670ad](https://github.com/bgd-labs/aave-address-book/commit/63670ad734badf5f3c6ee66662829051ab360449))

### [2.4.1](https://github.com/bgd-labs/aave-address-book/compare/v2.4.0...v2.4.1) (2023-09-18)


### Bug Fixes

* added missing gov v3 networks to generator ([#244](https://github.com/bgd-labs/aave-address-book/issues/244)) ([f6121e9](https://github.com/bgd-labs/aave-address-book/commit/f6121e96764ae8dbb9e79b6df231a22cf7832edd))
* correct metis create3 factory ([#245](https://github.com/bgd-labs/aave-address-book/issues/245)) ([df2735e](https://github.com/bgd-labs/aave-address-book/commit/df2735e63e5775ab38e774db6d952cb8174f95bc))
* updated eth gov helper. Added goerli helpers ([#246](https://github.com/bgd-labs/aave-address-book/issues/246)) ([748e2d7](https://github.com/bgd-labs/aave-address-book/commit/748e2d70b9465fb3bb02780c136b47909dcc3f1d))

## [2.4.0](https://github.com/bgd-labs/aave-address-book/compare/v2.3.0...v2.4.0) (2023-09-13)


### Features

* add bridge addresses ([#240](https://github.com/bgd-labs/aave-address-book/issues/240)) ([ebdc37e](https://github.com/bgd-labs/aave-address-book/commit/ebdc37e431d00feb183a8424e1e5d663e56f561b))
* added new ccc deployments ([#242](https://github.com/bgd-labs/aave-address-book/issues/242)) ([119563b](https://github.com/bgd-labs/aave-address-book/commit/119563b10cc16a69a35a633760b4f0f4bcdff4ae))


### Bug Fixes

* add goerli governance v3 ([#241](https://github.com/bgd-labs/aave-address-book/issues/241)) ([0c86faf](https://github.com/bgd-labs/aave-address-book/commit/0c86fafe90992d8e67e2d40a1d2c73b973d8874c))

## [2.3.0](https://github.com/bgd-labs/aave-address-book/compare/v2.2.0...v2.3.0) (2023-09-06)


### Features

* add abis for common contracts to js exports ([#236](https://github.com/bgd-labs/aave-address-book/issues/236)) ([8c3fbc4](https://github.com/bgd-labs/aave-address-book/commit/8c3fbc4047be187bc9a19e86e55b9155533c8254))
* add eModes library ([#238](https://github.com/bgd-labs/aave-address-book/issues/238)) ([bfa9397](https://github.com/bgd-labs/aave-address-book/commit/bfa93975983d308fe9fe558a6b02fbd7b2d7168c))


### Bug Fixes

* added executor with timelock abi ([#235](https://github.com/bgd-labs/aave-address-book/issues/235)) ([3d2414c](https://github.com/bgd-labs/aave-address-book/commit/3d2414ca906e98a57f54e592578e55afa26328a9))
* addresses fixed ([#237](https://github.com/bgd-labs/aave-address-book/issues/237)) ([f8b2bfb](https://github.com/bgd-labs/aave-address-book/commit/f8b2bfb55d3e83f07a937368f39da31265284023))

## [2.2.0](https://github.com/bgd-labs/aave-address-book/compare/v2.1.0...v2.2.0) (2023-09-05)


### Features

* added gov v3 interfaces and error lib ([#233](https://github.com/bgd-labs/aave-address-book/issues/233)) ([917bb9e](https://github.com/bgd-labs/aave-address-book/commit/917bb9ef1cc3a0c983d0c5883d3c6772a46cb43e))
* Import Error Library ([#232](https://github.com/bgd-labs/aave-address-book/issues/232)) ([f17fa5f](https://github.com/bgd-labs/aave-address-book/commit/f17fa5f262d20262e6177ccdd79b0676851c6c28))

## [2.1.0](https://github.com/bgd-labs/aave-address-book/compare/v2.0.0...v2.1.0) (2023-08-31)


### Features

* add abis to js exports ([#229](https://github.com/bgd-labs/aave-address-book/issues/229)) ([bff33fc](https://github.com/bgd-labs/aave-address-book/commit/bff33fc65520796e2589554f0fd72c6aa8da93d0))
* add explorer links ([#221](https://github.com/bgd-labs/aave-address-book/issues/221)) ([424d96d](https://github.com/bgd-labs/aave-address-book/commit/424d96df45bdb875946c3e9838e1ab8e2d3df611))
* withdraw swap adapter addresses ([#224](https://github.com/bgd-labs/aave-address-book/issues/224)) ([cc08bf9](https://github.com/bgd-labs/aave-address-book/commit/cc08bf987fc10e45a0c71fec5f1ebb249ac9dbc4))


### Bug Fixes

* readd types to gov v2 ([#227](https://github.com/bgd-labs/aave-address-book/issues/227)) ([2a8da29](https://github.com/bgd-labs/aave-address-book/commit/2a8da29098d4bd007697e3464906861e0953fb1a))
* resolve typo in arbitrum v3 ([#226](https://github.com/bgd-labs/aave-address-book/issues/226)) ([c739f31](https://github.com/bgd-labs/aave-address-book/commit/c739f315321270bf8f4be12908e152baef065c14))
* update deps ([#230](https://github.com/bgd-labs/aave-address-book/issues/230)) ([6e54ce4](https://github.com/bgd-labs/aave-address-book/commit/6e54ce474886c29aa302f31581eceb22db3cc2b5))

## [2.0.0](https://github.com/bgd-labs/aave-address-book/compare/v1.34.0...v2.0.0) (2023-08-28)


### ⚠ BREAKING CHANGES

* the format of assets in js was unnecessarily hard to consume, this pr changes it to a object like structure.

### Features

* js assets exports ([#219](https://github.com/bgd-labs/aave-address-book/issues/219)) ([cab5960](https://github.com/bgd-labs/aave-address-book/commit/cab5960b29ed6e20f5a760eef1a61765b7704b10))
* testnet updates ([#218](https://github.com/bgd-labs/aave-address-book/issues/218)) ([456fab9](https://github.com/bgd-labs/aave-address-book/commit/456fab9620d573bf9ae03d753d0aa6c51f4b95c2))

## [1.34.0](https://github.com/bgd-labs/aave-address-book/compare/v1.33.0...v1.34.0) (2023-08-24)


### Features

* aave misc js exports ([#210](https://github.com/bgd-labs/aave-address-book/issues/210)) ([4112844](https://github.com/bgd-labs/aave-address-book/commit/4112844dfc027fa538ba2cf2d8b97cd69f7c4903))
* add Scroll Sepolia testnet ([#215](https://github.com/bgd-labs/aave-address-book/issues/215)) ([a220f6a](https://github.com/bgd-labs/aave-address-book/commit/a220f6afc7f85b6113f02e573007d4d22cee6c6c))


### Bug Fixes

* cleanup dependencies ([#213](https://github.com/bgd-labs/aave-address-book/issues/213)) ([815d1cc](https://github.com/bgd-labs/aave-address-book/commit/815d1cc59d671a23e95e3cf7479cf170ba9ddeba))

## [1.33.0](https://github.com/bgd-labs/aave-address-book/compare/v1.32.0...v1.33.0) (2023-08-18)


### Features

* Add IMigrationHelper interface ([#185](https://github.com/bgd-labs/aave-address-book/issues/185)) ([b87a51d](https://github.com/bgd-labs/aave-address-book/commit/b87a51d014167effaaa7f6f7e33562b223b3d6b2))


### Bug Fixes

* add weth gateway address to base ([#207](https://github.com/bgd-labs/aave-address-book/issues/207)) ([b37eb99](https://github.com/bgd-labs/aave-address-book/commit/b37eb991c690cf19dae7945baf139ce1fba5c36b))

## [1.32.0](https://github.com/bgd-labs/aave-address-book/compare/v1.31.7...v1.32.0) (2023-08-14)


### Features

* alpha releases ([#201](https://github.com/bgd-labs/aave-address-book/issues/201)) ([0b595f3](https://github.com/bgd-labs/aave-address-book/commit/0b595f30fb8f55585623c128a75ce00e7cb8c730))

### [1.31.7](https://github.com/bgd-labs/aave-address-book/compare/v1.31.6...v1.31.7) (2023-08-14)


### Bug Fixes

* chain chain name from basenet to base ([#200](https://github.com/bgd-labs/aave-address-book/issues/200)) ([dc4a4de](https://github.com/bgd-labs/aave-address-book/commit/dc4a4dea4d703ab8d7c1908a0db89332f644e50d))

### [1.31.6](https://github.com/bgd-labs/aave-address-book/compare/v1.31.5...v1.31.6) (2023-08-11)


### Bug Fixes

* support cjs ([#197](https://github.com/bgd-labs/aave-address-book/issues/197)) ([6ff3a0d](https://github.com/bgd-labs/aave-address-book/commit/6ff3a0d6ee99bfb889a045942d48bd1e2cf83f92))

### [1.31.5](https://github.com/bgd-labs/aave-address-book/compare/v1.31.4...v1.31.5) (2023-08-11)

### [1.31.4](https://github.com/bgd-labs/aave-address-book/compare/v1.31.3...v1.31.4) (2023-08-11)


### Bug Fixes

* updated basenet contracts with new proxy admin ([#192](https://github.com/bgd-labs/aave-address-book/issues/192)) ([8905a2e](https://github.com/bgd-labs/aave-address-book/commit/8905a2e88036434fc6e3b61c06406a4d8e103285))

### [1.31.3](https://github.com/bgd-labs/aave-address-book/compare/v1.31.2...v1.31.3) (2023-08-10)


### Bug Fixes

* added basenet gov addresses to ts ([#190](https://github.com/bgd-labs/aave-address-book/issues/190)) ([45977b9](https://github.com/bgd-labs/aave-address-book/commit/45977b99b46927d0ec0ca200502903d074cc25c3))

### [1.31.2](https://github.com/bgd-labs/aave-address-book/compare/v1.31.1...v1.31.2) (2023-08-10)


### Bug Fixes

* change listing engine and rates factory addresses ([#188](https://github.com/bgd-labs/aave-address-book/issues/188)) ([2cd4c21](https://github.com/bgd-labs/aave-address-book/commit/2cd4c2199eff12dec9b7d3c0a5050d8504d8b4c6))

### [1.31.1](https://github.com/bgd-labs/aave-address-book/compare/v1.31.0...v1.31.1) (2023-08-10)

## [1.31.0](https://github.com/bgd-labs/aave-address-book/compare/v1.30.0...v1.31.0) (2023-08-09)


### Features

* Add V2 and V3 aToken interfaces (with added nonce getter in V2) ([#182](https://github.com/bgd-labs/aave-address-book/issues/182)) ([908c7aa](https://github.com/bgd-labs/aave-address-book/commit/908c7aac7fcaa693c8be22d72b72b356d01ce5f2))

## [1.30.0](https://github.com/bgd-labs/aave-address-book/compare/v1.29.0...v1.30.0) (2023-07-18)


### Features

* add ethereum v3 debt swap ([#176](https://github.com/bgd-labs/aave-address-book/issues/176)) ([d756064](https://github.com/bgd-labs/aave-address-book/commit/d756064c763c260cdf4a6c07a1432a47a4884f17))

## [1.29.0](https://github.com/bgd-labs/aave-address-book/compare/v1.28.0...v1.29.0) (2023-07-13)


### Features

* gho addresses ([#170](https://github.com/bgd-labs/aave-address-book/issues/170)) ([9978900](https://github.com/bgd-labs/aave-address-book/commit/99789003b39d2ce5c04d9618199d1b737bc379d1))
* migrate to viem ([#168](https://github.com/bgd-labs/aave-address-book/issues/168)) ([12e1dc0](https://github.com/bgd-labs/aave-address-book/commit/12e1dc086caca18e1b7e3d5d8ab4059151d53684))


### Bug Fixes

* Update addresses of paraswap adapters ([#169](https://github.com/bgd-labs/aave-address-book/issues/169)) ([d77c18d](https://github.com/bgd-labs/aave-address-book/commit/d77c18d577e3ce7a1de654c249fb9d3a51e066f9))

## [1.28.0](https://github.com/bgd-labs/aave-address-book/compare/v1.27.0...v1.28.0) (2023-07-11)


### Features

* add missing adapters ([#163](https://github.com/bgd-labs/aave-address-book/issues/163)) ([fc55c8c](https://github.com/bgd-labs/aave-address-book/commit/fc55c8c18a755fd1d691c9cca5f565d3dba5a62c))

## [1.27.0](https://github.com/bgd-labs/aave-address-book/compare/v1.26.2...v1.27.0) (2023-07-10)


### Features

* add debt swap ([#160](https://github.com/bgd-labs/aave-address-book/issues/160)) ([0d42c96](https://github.com/bgd-labs/aave-address-book/commit/0d42c960c49bfc76a3a672f3d3b49860487204aa))


### Bug Fixes

* patch arbitrum USDC ([4be5fea](https://github.com/bgd-labs/aave-address-book/commit/4be5feacc0759751ffc2fb57c9ba90099ca2aaf5))
* remove fantom addresses as they were not deployed ([#153](https://github.com/bgd-labs/aave-address-book/issues/153)) ([08851aa](https://github.com/bgd-labs/aave-address-book/commit/08851aa753de49e5227ffb696d828ad0bed11778))
* typo in AaveV2.sol ([#157](https://github.com/bgd-labs/aave-address-book/issues/157)) ([5ef66e0](https://github.com/bgd-labs/aave-address-book/commit/5ef66e0767ca3813be781a82d69c589062349910))

### [1.26.2](https://github.com/bgd-labs/aave-address-book/compare/v1.26.1...v1.26.2) (2023-06-14)


### Bug Fixes

* proper exports field ([#146](https://github.com/bgd-labs/aave-address-book/issues/146)) ([ca51e46](https://github.com/bgd-labs/aave-address-book/commit/ca51e46bdde647f6e438f4185cecb49e13f25bc4))

### [1.26.1](https://github.com/bgd-labs/aave-address-book/compare/v1.26.0...v1.26.1) (2023-06-14)


### Bug Fixes

* properly emit js extensions ([#144](https://github.com/bgd-labs/aave-address-book/issues/144)) ([a7602cd](https://github.com/bgd-labs/aave-address-book/commit/a7602cdf84d4f54b345a382f5379f66f4dd1e91e))

## [1.26.0](https://github.com/bgd-labs/aave-address-book/compare/v1.25.0...v1.26.0) (2023-06-14)


### Features

* provide 'iife', 'cjs', 'esm' module entry points ([#142](https://github.com/bgd-labs/aave-address-book/issues/142)) ([1c87b61](https://github.com/bgd-labs/aave-address-book/commit/1c87b618796b9c5db69b711e70e8364c3980c0e8))

## [1.25.0](https://github.com/bgd-labs/aave-address-book/compare/v1.24.0...v1.25.0) (2023-06-14)


### Features

* add amm migration helper ([#140](https://github.com/bgd-labs/aave-address-book/issues/140)) ([870947b](https://github.com/bgd-labs/aave-address-book/commit/870947b8e6f2826f0496d44828cf3ed96067aa18))
* added v2 config engine and v2 rates factories ([#135](https://github.com/bgd-labs/aave-address-book/issues/135)) ([9c5828a](https://github.com/bgd-labs/aave-address-book/commit/9c5828aa6f428a40f3ff72be6399eca7575a3697))
* js assets ([#137](https://github.com/bgd-labs/aave-address-book/issues/137)) ([f9e5726](https://github.com/bgd-labs/aave-address-book/commit/f9e572698a2b1881e4611fb1da2d3a9d6fca9b1b))


### Bug Fixes

* cron pr creation ([aa2fd17](https://github.com/bgd-labs/aave-address-book/commit/aa2fd17458eb832f64c20856aee9cb60f62051c5))
* give content write permissions ([376f888](https://github.com/bgd-labs/aave-address-book/commit/376f888e055b02ce7b2e52acb25ef1da3d8f4e78))
* make export order deterministic ([85811c7](https://github.com/bgd-labs/aave-address-book/commit/85811c7f67f90ac5f726da76aa80c3f08d77216f))
* try to fix ci ([c89fdd5](https://github.com/bgd-labs/aave-address-book/commit/c89fdd5ba038ae96dec71d24f20fd31752a8dc5a))

## [1.24.0](https://github.com/bgd-labs/aave-address-book/compare/v1.23.1...v1.24.0) (2023-05-31)


### Features

* add stewards ([#130](https://github.com/bgd-labs/aave-address-book/issues/130)) ([12dd0be](https://github.com/bgd-labs/aave-address-book/commit/12dd0be929bed8023014aeeae9672ec840c69c99))
* update Scroll Alpha faucet to fix mint bug ([#133](https://github.com/bgd-labs/aave-address-book/issues/133)) ([ae1c8df](https://github.com/bgd-labs/aave-address-book/commit/ae1c8dfdc6f560b03fce440082d7fcf895acf798))


### Bug Fixes

* aggregator interface ([#129](https://github.com/bgd-labs/aave-address-book/issues/129)) ([a32a855](https://github.com/bgd-labs/aave-address-book/commit/a32a855ede62b602063b81d6a68788bd86fd8f50))

### [1.23.1](https://github.com/bgd-labs/aave-address-book/compare/v1.23.0...v1.23.1) (2023-05-15)


### Bug Fixes

* Scroll Alpha - fix faucets ([#124](https://github.com/bgd-labs/aave-address-book/issues/124)) ([bcd5dce](https://github.com/bgd-labs/aave-address-book/commit/bcd5dced2f5db37ce97cb0c58e806f0aec78a165))
* update addresses ([#127](https://github.com/bgd-labs/aave-address-book/issues/127)) ([d09a7fb](https://github.com/bgd-labs/aave-address-book/commit/d09a7fb00735260e3eef4b06b14f0d524f19f7fd))

## [1.23.0](https://github.com/bgd-labs/aave-address-book/compare/v1.22.0...v1.23.0) (2023-04-26)


### Features

* metis ([#120](https://github.com/bgd-labs/aave-address-book/issues/120)) ([9961128](https://github.com/bgd-labs/aave-address-book/commit/9961128857066c1cd1b5d906e7a334bd907e2729))

## [1.22.0](https://github.com/bgd-labs/aave-address-book/compare/v1.21.0...v1.22.0) (2023-04-24)


### Features

* add streamable interface ([#116](https://github.com/bgd-labs/aave-address-book/issues/116)) ([cdfdf4a](https://github.com/bgd-labs/aave-address-book/commit/cdfdf4ac688da9f90ceaeed3c8fa399a19dc1003))


### Bug Fixes

* add getNextStreamId ([ce1bf7b](https://github.com/bgd-labs/aave-address-book/commit/ce1bf7bea81d2670bb20c8f255eceeb8eae881fb))

## [1.21.0](https://github.com/bgd-labs/aave-address-book/compare/v1.20.0...v1.21.0) (2023-04-11)


### Features

* add Scroll Alpha Testnet ([#112](https://github.com/bgd-labs/aave-address-book/issues/112)) ([8c44ce6](https://github.com/bgd-labs/aave-address-book/commit/8c44ce63d1fb20c7bf1bf37066521a16ed81076a))
* static a token factories ([#114](https://github.com/bgd-labs/aave-address-book/issues/114)) ([b9be41e](https://github.com/bgd-labs/aave-address-book/commit/b9be41ea2d7c0fec4bf795de7a2fafa62856f2db))


### Bug Fixes

* update addresses ([a39f2bd](https://github.com/bgd-labs/aave-address-book/commit/a39f2bd3cf66ac4db1ada2fa961961e3ac4f570a))

## [1.20.0](https://github.com/bgd-labs/aave-address-book/compare/v1.19.0...v1.20.0) (2023-03-27)


### Features

* add delegation aware aToken ([#109](https://github.com/bgd-labs/aave-address-book/issues/109)) ([642dffd](https://github.com/bgd-labs/aave-address-book/commit/642dffde2456b04d2509a42391fddb622264aa09))
* added rates factory ([#103](https://github.com/bgd-labs/aave-address-book/issues/103)) ([8982920](https://github.com/bgd-labs/aave-address-book/commit/89829205f87b8d570182158bdbcc04676ebcbd51))
* auto redeem forwarder ([#107](https://github.com/bgd-labs/aave-address-book/issues/107)) ([9a64715](https://github.com/bgd-labs/aave-address-book/commit/9a64715cff37ff7ff9a7da3e3dd04a55cad78ccb))
* reexport aggregator intreface ([#110](https://github.com/bgd-labs/aave-address-book/issues/110)) ([b2d4bde](https://github.com/bgd-labs/aave-address-book/commit/b2d4bdefa44099a672e5b3eab8ef06998bb2a5e1))
* updated addresses of LISTING_ENGINE to new version (Ethereum missing) ([#104](https://github.com/bgd-labs/aave-address-book/issues/104)) ([751ffd0](https://github.com/bgd-labs/aave-address-book/commit/751ffd0affc9bd1609753ea47a7d9ac23f391dd8))


### Bug Fixes

* update listing engine ([#106](https://github.com/bgd-labs/aave-address-book/issues/106)) ([20637c9](https://github.com/bgd-labs/aave-address-book/commit/20637c98ebe52ff17b3e12592499af740619492d))

## [1.19.0](https://github.com/bgd-labs/aave-address-book/compare/v1.18.0...v1.19.0) (2023-03-03)


### Features

* add sepolia ([#99](https://github.com/bgd-labs/aave-address-book/issues/99)) ([afd94d5](https://github.com/bgd-labs/aave-address-book/commit/afd94d54f7cd98e74dd6e9d5684efabbd1609b5f))

## [1.18.0](https://github.com/bgd-labs/aave-address-book/compare/v1.17.0...v1.18.0) (2023-02-27)


### Features

* update addresses ([#96](https://github.com/bgd-labs/aave-address-book/issues/96)) ([6e09c7b](https://github.com/bgd-labs/aave-address-book/commit/6e09c7b41600853b8d66675c946f5ac9616a09bb))
* updated gitmodules ([#97](https://github.com/bgd-labs/aave-address-book/issues/97)) ([24bd36e](https://github.com/bgd-labs/aave-address-book/commit/24bd36e0ecd4a06a1e70621bae8b66613bac57af))


### Bug Fixes

* consistent naming ([#95](https://github.com/bgd-labs/aave-address-book/issues/95)) ([2b8bc75](https://github.com/bgd-labs/aave-address-book/commit/2b8bc7586b834aca66571c41d5c108a94bc0d6ee))

## [1.17.0](https://github.com/bgd-labs/aave-address-book/compare/v1.16.0...v1.17.0) (2023-02-14)


### Features

* add proxy admins & factories to AaveMisc ([#92](https://github.com/bgd-labs/aave-address-book/issues/92)) ([29aed74](https://github.com/bgd-labs/aave-address-book/commit/29aed742774c1e76815daeffb8822feef9b2e7d2))
* listing engine of non-Ethereum instances ([#93](https://github.com/bgd-labs/aave-address-book/issues/93)) ([266c1cc](https://github.com/bgd-labs/aave-address-book/commit/266c1ccf9e68511edf2b0d90055718378ff21c62))

## [1.16.0](https://github.com/bgd-labs/aave-address-book/compare/v1.15.0...v1.16.0) (2023-02-10)


### Features

* add goerli gho V3 test market ([#89](https://github.com/bgd-labs/aave-address-book/issues/89)) ([e7f6bc1](https://github.com/bgd-labs/aave-address-book/commit/e7f6bc1f55fcddff6b94ec94540acccaaa3123fd))

## [1.15.0](https://github.com/bgd-labs/aave-address-book/compare/v1.14.0...v1.15.0) (2023-02-07)


### Features

* add cbETH ([#87](https://github.com/bgd-labs/aave-address-book/issues/87)) ([52f1986](https://github.com/bgd-labs/aave-address-book/commit/52f1986656b5898a7e9809a94ca5050a45daacca))

## [1.14.0](https://github.com/bgd-labs/aave-address-book/compare/v1.13.1...v1.14.0) (2023-02-03)


### Features

* added proof of reserve for avax pools ([#84](https://github.com/bgd-labs/aave-address-book/issues/84)) ([bec56a5](https://github.com/bgd-labs/aave-address-book/commit/bec56a5be3e36e5f407fce0d4f4a7109c3479243))

### [1.13.1](https://github.com/bgd-labs/aave-address-book/compare/v1.13.0...v1.13.1) (2023-02-01)

## [1.13.0](https://github.com/bgd-labs/aave-address-book/compare/v1.12.0...v1.13.0) (2023-01-31)


### Features

* add incentivecontroller & emissionmanager on v2 ([#80](https://github.com/bgd-labs/aave-address-book/issues/80)) ([5ae1ea2](https://github.com/bgd-labs/aave-address-book/commit/5ae1ea2213c6f4fd0028a5f8d57415ebf56426c8))

## [1.12.0](https://github.com/bgd-labs/aave-address-book/compare/v1.11.0...v1.12.0) (2023-01-31)


### Features

* add lendingrateoracle to v2 pools ([#78](https://github.com/bgd-labs/aave-address-book/issues/78)) ([c9ca04a](https://github.com/bgd-labs/aave-address-book/commit/c9ca04a4cb836b0795c06f894c86af6029179f70))

## [1.11.0](https://github.com/bgd-labs/aave-address-book/compare/v1.10.1...v1.11.0) (2023-01-30)


### Features

* addresses libraries ([#76](https://github.com/bgd-labs/aave-address-book/issues/76)) ([05963ad](https://github.com/bgd-labs/aave-address-book/commit/05963ad570d98c7c5e652771f0bf4a9f7ae5c452))

### [1.10.1](https://github.com/bgd-labs/aave-address-book/compare/v1.10.0...v1.10.1) (2023-01-27)


### Bug Fixes

* add strategy & generic executor ([#73](https://github.com/bgd-labs/aave-address-book/issues/73)) ([43eac8d](https://github.com/bgd-labs/aave-address-book/commit/43eac8da34792ed859601dfdd6eab63445ecdc5a))
* v3 ethereum ([#74](https://github.com/bgd-labs/aave-address-book/issues/74)) ([1b17fe0](https://github.com/bgd-labs/aave-address-book/commit/1b17fe0244ea39f63605473c0c789ad5b1b4c0a2))

## [1.10.0](https://github.com/bgd-labs/aave-address-book/compare/v1.9.2...v1.10.0) (2023-01-25)


### Features

* added extra functions to extended IACLManager ([#71](https://github.com/bgd-labs/aave-address-book/issues/71)) ([99ef8a2](https://github.com/bgd-labs/aave-address-book/commit/99ef8a26feabcf4af275b543aa88d91e3afc149a))

### [1.9.2](https://github.com/bgd-labs/aave-address-book/compare/v1.9.1...v1.9.2) (2023-01-20)


### Bug Fixes

* added renounceRole() to IACLManager (missed when change to import from v3-core) ([#69](https://github.com/bgd-labs/aave-address-book/issues/69)) ([0c07ee3](https://github.com/bgd-labs/aave-address-book/commit/0c07ee36d3512eca257ff3aadba36c8c1520e514))

### [1.9.1](https://github.com/bgd-labs/aave-address-book/compare/v1.9.0...v1.9.1) (2023-01-20)


### Bug Fixes

* added missing addresses to AaveGovernanceV2.ts ([#67](https://github.com/bgd-labs/aave-address-book/issues/67)) ([d560b55](https://github.com/bgd-labs/aave-address-book/commit/d560b55fefbc28b9626c1fe10d367a6ec0e970ad))

## [1.9.0](https://github.com/bgd-labs/aave-address-book/compare/v1.8.0...v1.9.0) (2023-01-19)


### Features

* added pool addresses provider registry contracts ([#60](https://github.com/bgd-labs/aave-address-book/issues/60)) ([ce15438](https://github.com/bgd-labs/aave-address-book/commit/ce154385d4827fb2f15742845e2e9eb39a0448fc))

## [1.8.0](https://github.com/bgd-labs/aave-address-book/compare/v1.7.0...v1.8.0) (2023-01-19)


### Features

* added LISTING_ENGINE for Aave v3 Ethereum ([#61](https://github.com/bgd-labs/aave-address-book/issues/61)) ([b9e7f36](https://github.com/bgd-labs/aave-address-book/commit/b9e7f3666e9c0cba44e86f0119d49030abf655dc))

## [1.7.0](https://github.com/bgd-labs/aave-address-book/compare/v1.6.1...v1.7.0) (2023-01-16)


### Features

* added ethereum v3 addresses ([#58](https://github.com/bgd-labs/aave-address-book/issues/58)) ([4607fc2](https://github.com/bgd-labs/aave-address-book/commit/4607fc24663ee21405ca1be84fb0b19705dd1d47))

### [1.6.1](https://github.com/bgd-labs/aave-address-book/compare/v1.6.0...v1.6.1) (2023-01-05)

## [1.6.0](https://github.com/bgd-labs/aave-address-book/compare/v1.5.2...v1.6.0) (2023-01-05)


### Features

* added permission manager to arc pool ([#54](https://github.com/bgd-labs/aave-address-book/issues/54)) ([665e647](https://github.com/bgd-labs/aave-address-book/commit/665e647180b1a304048a57842cf0c83b0ba13168))

### [1.5.2](https://github.com/bgd-labs/aave-address-book/compare/v1.5.1...v1.5.2) (2022-12-22)

### [1.5.1](https://github.com/bgd-labs/aave-address-book/compare/v1.5.0...v1.5.1) (2022-12-21)


### Bug Fixes

* add core as library ([#47](https://github.com/bgd-labs/aave-address-book/issues/47)) ([86c7b0e](https://github.com/bgd-labs/aave-address-book/commit/86c7b0ea366df8832cd420ae153b768871fd9d57)), closes [#49](https://github.com/bgd-labs/aave-address-book/issues/49)

## [1.5.0](https://github.com/bgd-labs/aave-address-book/compare/v1.4.0...v1.5.0) (2022-12-10)


### Features

* add arbitrum crosschain forwarder ([#46](https://github.com/bgd-labs/aave-address-book/issues/46)) ([10b1a88](https://github.com/bgd-labs/aave-address-book/commit/10b1a8845b871660a70c1fc9a7c48964c1096a98))

## [1.4.0](https://github.com/bgd-labs/aave-address-book/compare/v1.3.0...v1.4.0) (2022-12-01)


### Features

* add bridge related addresses to address-book ([#41](https://github.com/bgd-labs/aave-address-book/issues/41)) ([e83e4ca](https://github.com/bgd-labs/aave-address-book/commit/e83e4ca9fcb9f1b36fa0fe83b1ff50086c47a21b))
* added emission manager address to v3 pools ([#43](https://github.com/bgd-labs/aave-address-book/issues/43)) ([b4dd997](https://github.com/bgd-labs/aave-address-book/commit/b4dd997f8b6c8a086b360e56a89a5f88b30213b0))
* update to use new long ([#38](https://github.com/bgd-labs/aave-address-book/issues/38)) ([9f85d42](https://github.com/bgd-labs/aave-address-book/commit/9f85d42abb2870db406e5c11effc2b0cd4effe41))


### Bug Fixes

* add pragma experimental to support 0.6.x builds ([#40](https://github.com/bgd-labs/aave-address-book/issues/40)) ([33934df](https://github.com/bgd-labs/aave-address-book/commit/33934dfdd7ec52487991fba477caf4e88fb8f178))
* added abi coder v2 ([#39](https://github.com/bgd-labs/aave-address-book/issues/39)) ([b371604](https://github.com/bgd-labs/aave-address-book/commit/b3716047914f6acbc69421a3ff52d016d84bad65))
* rename forwader -> forwarder ([acdb6c2](https://github.com/bgd-labs/aave-address-book/commit/acdb6c2a5d51b14bcbe35cfa1a597e8098ec1cca))

## [1.3.0](https://github.com/bgd-labs/aave-address-book/compare/v1.2.0...v1.3.0) (2022-10-11)


### Features

* add chainId to node exports ([ec89bb7](https://github.com/bgd-labs/aave-address-book/commit/ec89bb72bc7c2585de0b0dff4677d5c233ed995e))
* add incentives controller, a/s/v default implementations, ecosystem reserve & remove getMarket ([#33](https://github.com/bgd-labs/aave-address-book/issues/33)) ([f1f2abf](https://github.com/bgd-labs/aave-address-book/commit/f1f2abfd2dd919c1a5682f978824f3042abbf3fa))
* try new release ci ([#36](https://github.com/bgd-labs/aave-address-book/issues/36)) ([7bf03ad](https://github.com/bgd-labs/aave-address-book/commit/7bf03ada7b18d9a322e1ce56d38834b9216b3097))


### Bug Fixes

* **cache:** automated cache update ([9e5f793](https://github.com/bgd-labs/aave-address-book/commit/9e5f7938acbf9808e097e9c14aefd92b0a631272))

## [1.2.0](https://github.com/bgd-labs/aave-address-book/compare/v1.1.0...v1.2.0) (2022-09-02)


### Features

* add js build ([#28](https://github.com/bgd-labs/aave-address-book/issues/28)) ([8c95644](https://github.com/bgd-labs/aave-address-book/commit/8c9564401c6b990e81db4183b959d76956e1215b))

## 1.1.0 (2022-08-02)


### Features

* add AccessControl interface ([c8633f7](https://github.com/bgd-labs/aave-address-book/commit/c8633f751482a8da2e8448ca774d6b2d6f56a039))
* add acl manager interface ([#10](https://github.com/bgd-labs/aave-address-book/issues/10)) ([f18cc6c](https://github.com/bgd-labs/aave-address-book/commit/f18cc6c33d1820d47b93282aadc0d9169e8d2c5c))
* add acl manager to v3 ([#9](https://github.com/bgd-labs/aave-address-book/issues/9)) ([f094606](https://github.com/bgd-labs/aave-address-book/commit/f0946068a60f884c50206b0dc3f9dd0c66f9ed40))
* add batch init reserves to interface ([#19](https://github.com/bgd-labs/aave-address-book/issues/19)) ([13a687d](https://github.com/bgd-labs/aave-address-book/commit/13a687de8735242c529dc6050620cf14d058ca4e))
* add ci ([f6b0221](https://github.com/bgd-labs/aave-address-book/commit/f6b022197bc5632f6bc33c40c7f9fb8e2b8d412c))
* add generator for v2 & v3 markets ([#1](https://github.com/bgd-labs/aave-address-book/issues/1)) ([1c90d62](https://github.com/bgd-labs/aave-address-book/commit/1c90d621cdb4215524fee07169705e1726040973))
* add governance & remove rinkeby ([#15](https://github.com/bgd-labs/aave-address-book/issues/15)) ([1f036c5](https://github.com/bgd-labs/aave-address-book/commit/1f036c59249789e06e46947040b6eac6b763722e))
* add index contract ([#3](https://github.com/bgd-labs/aave-address-book/issues/3)) ([182fa7f](https://github.com/bgd-labs/aave-address-book/commit/182fa7f11734a066963669410e91a0ac63589f1a))
* add tokens ([#4](https://github.com/bgd-labs/aave-address-book/issues/4)) ([6e4daf9](https://github.com/bgd-labs/aave-address-book/commit/6e4daf98802808251b6794688c2a5cb1ad8fbf63))
* add v2 arc market ([#17](https://github.com/bgd-labs/aave-address-book/issues/17)) ([b4dbf9c](https://github.com/bgd-labs/aave-address-book/commit/b4dbf9ce12577d169317c90494410ea0614fb54f))
* add v3 collector ([#11](https://github.com/bgd-labs/aave-address-book/issues/11)) ([8f26eb6](https://github.com/bgd-labs/aave-address-book/commit/8f26eb60ec3f051a8b28f34ccc0b702af59d716a))
* make market a struct on market ([#6](https://github.com/bgd-labs/aave-address-book/issues/6)) ([4f26b9d](https://github.com/bgd-labs/aave-address-book/commit/4f26b9dc52fae876975a1f8c62ef2066f6ae02fe))
* more useful tests & remove getToken ([#20](https://github.com/bgd-labs/aave-address-book/issues/20)) ([81730b7](https://github.com/bgd-labs/aave-address-book/commit/81730b73220ee534f6595a928644d2faaa005dc5))
* tests ([#2](https://github.com/bgd-labs/aave-address-book/issues/2)) ([019f835](https://github.com/bgd-labs/aave-address-book/commit/019f835375f7c121e8c8dc0fa7d57e0f74e0d8dc))
* use shared actions ([#23](https://github.com/bgd-labs/aave-address-book/issues/23)) ([1907531](https://github.com/bgd-labs/aave-address-book/commit/1907531162a51f742604744de02971f1748fcd1a))
* v2 configuration inputs ([#18](https://github.com/bgd-labs/aave-address-book/issues/18)) ([9b13be1](https://github.com/bgd-labs/aave-address-book/commit/9b13be17c7ffeed5324692f67d42e131c0087d45))


### Bug Fixes

* add logo ([73edeec](https://github.com/bgd-labs/aave-address-book/commit/73edeec8d75477b2a07992ed59ff275056b398ac))
* add yarn.lock as it works nicer with github actions ([e0c9801](https://github.com/bgd-labs/aave-address-book/commit/e0c98019f76d08891276b89919f5fe5205cac880))
* alter check ([3dc4c00](https://github.com/bgd-labs/aave-address-book/commit/3dc4c00fbcf933a3abf69563a1b6a207b0b264af))
* alter folder layout ([#5](https://github.com/bgd-labs/aave-address-book/issues/5)) ([aad88b3](https://github.com/bgd-labs/aave-address-book/commit/aad88b3495ad6919601e37cbb43cb034a2ef9805))
* **cache:** automated cache update ([17c6635](https://github.com/bgd-labs/aave-address-book/commit/17c66357f3d373e4a337089aeb7abc5255850613))
* **cache:** automated cache update ([d5a0027](https://github.com/bgd-labs/aave-address-book/commit/d5a002783af4c29d499896b284060f1896d4ef45))
* **cache:** automated cache update ([25d2c70](https://github.com/bgd-labs/aave-address-book/commit/25d2c70e1cd0486276a0806c87218698ca1be5df))
* **cache:** automated cache update ([8c8c3cb](https://github.com/bgd-labs/aave-address-book/commit/8c8c3cbcd80a809cd9d3a06dd8f8d9ced745db35))
* **cache:** automated cache update ([c894fac](https://github.com/bgd-labs/aave-address-book/commit/c894fac988974ba094dc8df83057fd03b23c0eca))
* **cache:** automated cache update ([3062265](https://github.com/bgd-labs/aave-address-book/commit/3062265f1bb57f05e7d588d20d029ae47fedea40))
* **cache:** automated cache update ([ff347a4](https://github.com/bgd-labs/aave-address-book/commit/ff347a48d7c1cf8695aaaf309c3b014998eb8a90))
* **cache:** automated cache update ([5869e10](https://github.com/bgd-labs/aave-address-book/commit/5869e10884c58e7379a49c10eb5415a37a0437cb))
* **cache:** automated cache update ([d22326e](https://github.com/bgd-labs/aave-address-book/commit/d22326ec42c08b0c78c6941d82dfe11e09b3717c))
* **cache:** automated cache update ([4e22b4f](https://github.com/bgd-labs/aave-address-book/commit/4e22b4f20c2327c72ca8c4324114069453db9777))
* **cache:** automated cache update ([d345601](https://github.com/bgd-labs/aave-address-book/commit/d34560176a0a176aa6f138f6d1e43378aca13b25))
* **cache:** automated cache update ([bea1ac8](https://github.com/bgd-labs/aave-address-book/commit/bea1ac8c8fd6786665ed410074f0d600bbb7b8fe))
* **cache:** automated cache update ([9a68578](https://github.com/bgd-labs/aave-address-book/commit/9a68578d3b20e5f7001a106fa8ea5afaf228ee6d))
* **cache:** automated cache update ([f0ff685](https://github.com/bgd-labs/aave-address-book/commit/f0ff6852c3b88ae9c27aa197e759bddfb57bd262))
* **cache:** automated cache update ([cd2a27d](https://github.com/bgd-labs/aave-address-book/commit/cd2a27dfd67329cb1ec2f6e925947a7defae17af))
* **cache:** automated cache update ([7ad34b0](https://github.com/bgd-labs/aave-address-book/commit/7ad34b02b7897b101f7d0cd16feff3fe7e0f64cd))
* **cache:** automated cache update ([81044d3](https://github.com/bgd-labs/aave-address-book/commit/81044d3a693ed0accd1d4987aca28ceddeee8f98))
* export generic address book from index ([3da610f](https://github.com/bgd-labs/aave-address-book/commit/3da610fa5ef0bd489e4ce9c765852ab0aa4f833f))
* move abi to scripts folder ([ee94125](https://github.com/bgd-labs/aave-address-book/commit/ee9412565a29da19ec392f47de0fe80f41af68cf))
* move abis to abi folder ([afc1b3b](https://github.com/bgd-labs/aave-address-book/commit/afc1b3b4d85392f73512004bfd44f45f72505460))
* remove pull ([8935886](https://github.com/bgd-labs/aave-address-book/commit/89358868dd0bd96eb2fc24cd1958cc309d470243))
* resolve typos ([f077ac9](https://github.com/bgd-labs/aave-address-book/commit/f077ac95296e966101f62c1606033cd407825dcb))
* update readme ([3cf31ce](https://github.com/bgd-labs/aave-address-book/commit/3cf31cea4ae60c3adda6875849e626241ee81cb9))
