import {ChainId} from '@aave-dao/toolbox';
import {GovernanceConfig} from 'scripts/configs/types';

export const governanceConfigSonic: GovernanceConfig = {
  name: 'Sonic',
  CHAIN_ID: ChainId.sonic,
  ADDRESSES: {
    CROSS_CHAIN_CONTROLLER: '0x58e003a3C6f2Aeed6a2a6Bc77B504566523cb15c',
    PAYLOADS_CONTROLLER: '0x0846C28Dd54DEA4Fd7Fb31bcc5EB81673D68c695',
    PC_DATA_HELPER: '0x6fD45D32375d5aDB8D76275A3932c740F03a8718',
    GRANULAR_GUARDIAN: '0x10078c1D8E46dd1ed5D8df2C42d5ABb969b11566',
    GOVERNANCE_GUARDIAN: '0x63C4422D6cc849549daeb600B7EcE52bD18fAd7f',
    CL_EMERGENCY_ORACLE: '0xECB564e91f620fBFb59d0C4A41d7f10aDb0D1934',
  },
};
