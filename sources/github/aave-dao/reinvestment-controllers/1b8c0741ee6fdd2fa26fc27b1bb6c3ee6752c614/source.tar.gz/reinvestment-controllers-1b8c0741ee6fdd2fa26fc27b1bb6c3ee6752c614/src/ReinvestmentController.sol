// SPDX-License-Identifier: LicenseRef-BUSL
pragma solidity 0.8.28;

contract ReinvestmentController {}
