// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.0;

import '../BaseStableTest.sol';

import {CapAdaptersCodeEthereum} from '../../scripts/DeployEthereum.s.sol';
import {CapAdaptersCodeLinea} from '../../scripts/DeployLinea.s.sol';
import {CapAdaptersCodeMantle} from '../../scripts/DeployMantle.s.sol';
import {CapAdaptersCodeMegaEth} from '../../scripts/DeployMegaEth.s.sol';
import {CapAdaptersCodePlasma} from '../../scripts/DeployPlasma.s.sol';
import {CapAdaptersCodeArbitrum} from '../../scripts/DeployArbitrum.s.sol';
import {CapAdaptersCodeXLayer} from '../../scripts/DeployXLayer.s.sol';
import {CapAdaptersCodeMonad} from '../../scripts/DeployMonad.s.sol';

contract USDTEthereumTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeEthereum.USDTAdapterCode(),
      14,
      ForkParams({network: 'mainnet', blockNumber: 22195655})
    )
  {}
}

contract USDTLineaTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeLinea.USDTAdapterCode(),
      10,
      ForkParams({network: 'linea', blockNumber: 13432357})
    )
  {}
}

contract USDTMantleTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeMantle.USDTAdapterCode(),
      30,
      ForkParams({network: 'mantle', blockNumber: 90210075})
    )
  {}
}

contract USDTMegaEthTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeMegaEth.USDT0AdapterCode(),
      0,
      ForkParams({network: 'megaeth', blockNumber: 7304587})
    )
  {}
}

contract USDTPlasmaTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodePlasma.USDTAdapterCode(),
      14,
      ForkParams({network: 'plasma', blockNumber: 3693555})
    )
  {}
}

contract USDTArbitrumTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeArbitrum.USDTAdapterCode(),
      30,
      ForkParams({network: 'arbitrum', blockNumber: 435534000})
    )
  {}
}

contract USDTXlayerTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeXLayer.USDTAdapterCode(),
      30,
      ForkParams({network: 'xlayer', blockNumber: 55067099})
    )
  {}
}

contract USDT0MonadTest is BaseStableTest {
  constructor()
    BaseStableTest(
      CapAdaptersCodeMonad.USDT0AdapterCode(),
      0,
      ForkParams({network: 'monad', blockNumber: 83150000})
    )
  {}

  function setUp() public override {
    super.setUp();
    GovV3Helpers.deployDeterministic(
      CapAdaptersCodeMonad.scaledAdapterCode(CapAdaptersCodeMonad.USDT0_SVR_USD_PRICE_FEED)
    );
  }

  function test_latestAnswerRetrospective() public pure override {
    // base feed is a freshly deployed ScaledPriceAdapter over the SVR feed
    assertTrue(true);
  }
}
