# Aave Robot Descriptions

Descriptions of all automation robots used by the Aave protocol. For the full list of active robots per network, see the [Aave Robots List](./README.md).

---

### <a id="execution-chain-robot">Execution Chain Robot</a>

Executes Aave governance payloads automatically once the payload is queued and the timelock delay has elapsed.

### <a id="gas-capped-execution-chain-robot">Gas Capped Execution Chain Robot</a>

Same as Execution Chain Robot, but capped via a max gas price threshold to avoid overpayment during gas spikes.

### <a id="gas-capped-governance-chain-robot">Gas Capped Governance Chain Robot</a>

Governance automation to move proposals to executed/cancelled state or activate voting when all conditions are met. Capped via max gas price threshold.

### <a id="voting-chain-robot">Voting Chain Robot</a>

Automation on voting machine and data warehouse contracts — handles `createVote`, `closeAndSendVote`, and storage root submissions.

### <a id="gas-capped-voting-chain-robot">Gas Capped Voting Chain Robot</a>

Same as Voting Chain Robot, but capped via max gas price threshold.

### <a id="roots-consumer-chainlink-api">Roots Consumer (Chainlink API)</a>

Triggered by the Voting Chain Robot to submit Ethereum storage roots (used for voting) via Chainlink Any API.

### <a id="statatoken-rewards-robot">StataToken Rewards Robot</a>

Refreshes LM rewards for stataTokens when a reward is added after stataToken creation, to register missing rewards.

### <a id="gas-capped-core-statatoken-rewards-robot">Gas Capped Core StataToken Rewards Robot</a>

Same as StataToken Rewards Robot, specific to the Ethereum core instance. Capped via max gas price threshold.

### <a id="gas-capped-prime-statatoken-rewards-robot">Gas Capped Prime StataToken Rewards Robot</a>

Same as StataToken Rewards Robot, specific to the Ethereum prime instance. Capped via max gas price threshold.

### <a id="supply-cap-agent">Supply Cap Agent</a>

Automation on Agent Hub to inject supply cap updates from the Chaos risk oracle into the protocol.

### <a id="borrow-cap-agent">Borrow Cap Agent</a>

Automation on Agent Hub to inject borrow cap updates from the Chaos risk oracle into the protocol.

### <a id="emode-agent">EMode Agent</a>

Automation on Agent Hub to inject EMode collateral parameter updates from the Chaos risk oracle into the protocol.

### <a id="core-emode-agent">Core EMode Agent</a>

Same as EMode Agent, specific to the Ethereum core instance.

### <a id="interest-rate-agent">Interest Rate Agent</a>

Automation on Agent Hub to inject interest rate updates from the Chaos risk oracle into the protocol.

### <a id="core-interest-rate-agent">Core Interest Rate Agent</a>

Same as Interest Rate Agent, specific to the Ethereum core instance.

### <a id="prime-interest-rate-agent">Prime Interest Rate Agent</a>

Same as Interest Rate Agent, specific to the Ethereum prime instance.

### <a id="pendle-pt-discountrate-agent">Pendle PT DiscountRate Agent</a>

Automation on Agent Hub to inject discount rate updates on Pendle PT feeds from the Chaos risk oracle.

### <a id="core-pendle-pt-discountrate-agent">Core Pendle PT DiscountRate Agent</a>

Automation on Agent Hub to inject discount rate updates on Pendle PT feeds from the Chaos risk oracle, specific to the Ethereum core instance.

### <a id="core-capo-agent">Core Capo Agent</a>

TBD

### <a id="proof-of-reserve-robot-v3">Proof Of Reserve Robot V3</a>

Checks if bridged reserves are backed on Aave V3 using Chainlink Proof of Reserve. Freezes the reserve if not.

### <a id="proof-of-reserve-robot-v2">Proof Of Reserve Robot V2</a>

Checks if bridged reserves are backed on Aave V2 using Chainlink Proof of Reserve. Freezes the reserve if not.

### <a id="umbrella-permissionedpayloadscontroller-robot">Umbrella PermissionedPayloadsController Robot</a>

Similar to Execution Chain Robot but executes payloads on the PermissionedPayloadsController used for updating Umbrella Rewards.

### <a id="slashing-robot">Slashing Robot</a>

Executes the slashing action on Umbrella for all reserves.

### <a id="gho-gsm-4626-statausdc-oracleswapfreezer">GHO GSM 4626 stataUSDC OracleSwapFreezer</a>

Executes Freeze/Unfreeze on the stataUSDC GSM based on the underlying oracle price, GSM state, and predefined price boundaries.

### <a id="gho-gsm-4626-statausdt-oracleswapfreezer">GHO GSM 4626 stataUSDT OracleSwapFreezer</a>

Executes Freeze/Unfreeze on the stataUSDT GSM based on the underlying oracle price, GSM state, and predefined price boundaries.
