# Bored Guides

![Bored Guides](./assets/bored-guides.jpg)

Aave guides for different ecosystem workflows. Each guide describes a repeatable process end-to-end, so that anyone with the right context can reproduce it.

## Guides

| Guide | Description |
| ----- | ----------- |
| [a.DI/Governance network expansions](./adi-governance-network-expansions.md) | Procedure for expanding a.DI and Aave Governance to new networks |
| [Aave Seatbelt](https://github.com/aave-dao/seatbelt-gov-v3) | Native documentation of the Aave Seatbelt tool, used to simulate and verify changes to Aave through governance proposals or similar architectures |
| [Aave custom price feeds](./aave-custom-price-feeds.md) | Procedure for deploying and maintaining custom price feeds used on the Aave protocol |
| [Proof of Reserve](./aave-proof-of-reserves.md) | Procedure for the Proof of Reserve system used on the Aave protocol |
| [Aave onchain rewards management](./aave-rewards-management.md) | High-level overview and procedures for Aave v3 and Umbrella on-chain rewards management |
| [Umbrella maintenance and expansion](./umbrella-maintenance-expansion.md) | Maintenance and expansion guide for Aave Umbrella |
| [Aave v3 asset listings procedure](./aave-v3-asset-listings.md) | Overview of the procedure to list assets on Aave v3 |
| [Aave v3 network expansion procedure](./network-expansions.md) | High-level procedures for Aave v3 network expansions |
| [Risk agents maintenance-expansion](./risk-agents-maintenance.md) | Guide for maintenance and expansion of risk agents |
| [Aave Robots overview](./aave-robots.md) | High-level overview and maintenance of Aave Robots (automations) |

## Disclaimers

- These guides are high-level descriptions of different procedures, with varying depth of detail. Whoever applies them **must** understand the context of application and have sufficient technical and product expertise.
- All procedures and guides are ever-growing, organic documents that the elected maintainer should keep updated.
- These guides do **not** guarantee 100% correctness or completeness of any procedure. BGD Labs (or other contributors) assumes no liability for misapplication and/or lack of expertise when executing a flow using a guide as reference.

---

Created by [BGD Labs](https://bgdlabs.com/)

[MIT Licensed](./LICENSE)
