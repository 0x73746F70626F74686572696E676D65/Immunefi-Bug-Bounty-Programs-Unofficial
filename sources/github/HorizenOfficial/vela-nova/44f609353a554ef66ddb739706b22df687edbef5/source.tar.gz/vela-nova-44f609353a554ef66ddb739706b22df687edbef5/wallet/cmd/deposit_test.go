package cmd

import (
	"bytes"
	"fmt"
	"io"
	"math/big"
	"os"
	"testing"

	"github.com/HorizenOfficial/vela-nova/wallet/app"
	"github.com/HorizenOfficial/vela-nova/wallet/cmd/testutil"
	"github.com/HorizenOfficial/vela/pkg/blockchain"
	"github.com/HorizenOfficial/vela/pkg/common"
	"github.com/HorizenOfficial/vela/pkg/crypto"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDepositCmdInvalidDepositAmount(t *testing.T) {
	// Redirect stdout
	old := os.Stdout
	r, w, err := os.Pipe()
	require.NoError(t, err)
	os.Stdout = w

	key1, err := crypto.GeneratePrivateKeySecp256k1()
	require.NoError(t, err)
	key2, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	testHelper := setupSimTestHelper(t, nil)
	defer testHelper.Close()

	var blockchainClient blockchain.Client = testutil.SetupNewBlockChainClient(testHelper)
	// Execute the command
	cfg := &app.Config{
		KeySecp:                   key1,
		KeyP521:                   key2,
		ApplicationID:             common.NewApplicationId(1),
		BlockchainPollingInterval: 2,
		BlockchainPollingTimeout:  10,
	}
	testutil.WriteTempConf(t, cfg)
	depositCmd := NewDepositCommand(cfg, blockchainClient)
	depositCmd.SubgraphClient = testutil.SubgraphClientOK()
	cmd := depositCmd.Command()

	cmd.Flags().Set("amount", "pippo")
	cmd.Flags().Set("max-value-fee", "100 wei")

	cmd.Run(cmd, nil)

	// Restore stdout
	w.Close()
	os.Stdout = old

	var buf bytes.Buffer
	io.Copy(&buf, r)
	output := buf.String()

	fmt.Println(output)
	assert.Contains(t, output, "invalid amount")

}

func TestDepositCmdInvalidMaxValueFee(t *testing.T) {
	// Redirect stdout
	old := os.Stdout
	r, w, err := os.Pipe()
	require.NoError(t, err)
	os.Stdout = w

	key1, err := crypto.GeneratePrivateKeySecp256k1()
	require.NoError(t, err)
	key2, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	testHelper := setupSimTestHelper(t, nil)
	defer testHelper.Close()

	var blockchainClient blockchain.Client = testutil.SetupNewBlockChainClient(testHelper)
	// Execute the command
	cfg := &app.Config{
		KeySecp:                   key1,
		KeyP521:                   key2,
		ApplicationID:             common.NewApplicationId(1),
		BlockchainPollingInterval: 2,
		BlockchainPollingTimeout:  10,
	}
	testutil.WriteTempConf(t, cfg)
	depositCmd := NewDepositCommand(cfg, blockchainClient)
	depositCmd.SubgraphClient = testutil.SubgraphClientOK()
	cmd := depositCmd.Command()

	cmd.Flags().Set("amount", "333 wei")
	cmd.Flags().Set("max-value-fee", "pippo")

	cmd.Run(cmd, nil)

	// Restore stdout
	w.Close()
	os.Stdout = old

	var buf bytes.Buffer
	io.Copy(&buf, r)
	output := buf.String()

	fmt.Println(output)
	assert.Contains(t, output, "invalid max fee amount")

}

func TestDepositCmd(t *testing.T) {
	// Redirect stdout
	old := os.Stdout
	r, w, err := os.Pipe()
	require.NoError(t, err)
	os.Stdout = w

	key1, err := crypto.GeneratePrivateKeySecp256k1()
	require.NoError(t, err)
	key2, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	testHelper := setupSimTestHelper(t, nil)
	defer testHelper.Close()

	appID := testutil.DeployTestApplication(t, testHelper)

	var blockchainClient blockchain.Client = testutil.SetupNewBlockChainClient(testHelper)
	// Execute the command
	cfg := &app.Config{
		KeySecp:                   key1,
		KeyP521:                   key2,
		ApplicationID:             appID,
		BlockchainPollingInterval: 2,
		BlockchainPollingTimeout:  10,
	}
	testutil.WriteTempConf(t, cfg)
	depositCmd := NewDepositCommand(cfg, blockchainClient)
	depositCmd.SubgraphClient = testutil.SubgraphClientOK()
	cmd := depositCmd.Command()

	cmd.Flags().Set("amount", "333 wei")
	cmd.Flags().Set("max-value-fee", "100 wei")

	// To be honest, it should be a StateUpdate but for the test it is enough, for now
	go testutil.CompleteNextRequest(t, testHelper, big.NewInt(65), big.NewInt(35))

	cmd.Run(cmd, nil)

	// Restore stdout
	w.Close()
	os.Stdout = old

	var buf bytes.Buffer
	io.Copy(&buf, r)
	output := buf.String()

	fmt.Println(output)
	assert.Contains(t, output, "Deposit completed successfully")

}

func TestDepositCmdFailure(t *testing.T) {
	// Redirect stdout
	old := os.Stdout
	r, w, err := os.Pipe()
	require.NoError(t, err)
	os.Stdout = w

	key1, err := crypto.GeneratePrivateKeySecp256k1()
	require.NoError(t, err)
	key2, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	testHelper := setupSimTestHelper(t, nil)
	defer testHelper.Close()

	appID := testutil.DeployTestApplication(t, testHelper)

	var blockchainClient blockchain.Client = testutil.SetupNewBlockChainClient(testHelper)
	// Execute the command
	cfg := &app.Config{
		KeySecp:                   key1,
		KeyP521:                   key2,
		ApplicationID:             appID,
		BlockchainPollingInterval: 2,
		BlockchainPollingTimeout:  10,
	}
	testutil.WriteTempConf(t, cfg)
	depositCmd := NewDepositCommand(cfg, blockchainClient)
	depositCmd.SubgraphClient = testutil.SubgraphClientFailure()
	cmd := depositCmd.Command()

	cmd.Flags().Set("amount", "333 wei")
	cmd.Flags().Set("max-value-fee", "100 wei")

	go testutil.FailNextRequest(t, testHelper)

	cmd.Run(cmd, nil)

	// Restore stdout
	w.Close()
	os.Stdout = old

	var buf bytes.Buffer
	io.Copy(&buf, r)
	output := buf.String()

	fmt.Println(output)
	assert.Contains(t, output, "Deposit failed: internal error (code 2)")

}

func TestDepositCmdUsesDefaultMaxValueFee(t *testing.T) {
	// Redirect stdout
	old := os.Stdout
	r, w, err := os.Pipe()
	require.NoError(t, err)
	os.Stdout = w

	key1, err := crypto.GeneratePrivateKeySecp256k1()
	require.NoError(t, err)
	key2, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	testHelper := setupSimTestHelper(t, nil)
	defer testHelper.Close()

	appID := testutil.DeployTestApplication(t, testHelper)

	var blockchainClient blockchain.Client = testutil.SetupNewBlockChainClient(testHelper)

	cfg := &app.Config{
		KeySecp:                   key1,
		KeyP521:                   key2,
		ApplicationID:             appID,
		BlockchainPollingInterval: 2,
		BlockchainPollingTimeout:  10,
	}
	testutil.WriteTempConf(t, cfg)
	depositCmd := NewDepositCommand(cfg, blockchainClient)
	depositCmd.SubgraphClient = testutil.SubgraphClientOK()
	cmd := depositCmd.Command()

	// Only set amount; max-value-fee should use default value (100 wei)
	cmd.Flags().Set("amount", "333 wei")

	go testutil.CompleteNextRequest(t, testHelper, big.NewInt(65), big.NewInt(35))

	cmd.Run(cmd, nil)

	// Restore stdout
	w.Close()
	os.Stdout = old

	var buf bytes.Buffer
	io.Copy(&buf, r)
	output := buf.String()

	fmt.Println(output)
	assert.Contains(t, output, "Deposit completed successfully")
}
