use crate::{
    init_logger,
    macros::{BufferWithSize, CctpErrorCode},
    parse_path, zendoo_compress_bit_vector, zendoo_decompress_bit_vector, zendoo_free_bws,
};
use cctp_primitives::bit_vector::compression::CompressionAlgorithm;
use std::slice;

#[cfg(feature = "mc-test-circuit")]
use crate::{
    zendoo_add_certificate_proof_to_batch_verifier, zendoo_add_csw_proof_to_batch_verifier,
    zendoo_batch_verify_all_proofs, zendoo_create_return_cert_test_proof,
    zendoo_create_return_csw_test_proof, zendoo_deserialize_sc_pk_from_file,
    zendoo_deserialize_sc_proof, zendoo_deserialize_sc_vk_from_file, zendoo_field_free,
    zendoo_free_batch_proof_verifier_result, zendoo_generate_mc_test_params,
    zendoo_get_random_field, zendoo_init_dlog_keys, zendoo_init_logger, zendoo_sc_pk_free,
    zendoo_sc_proof_free, zendoo_sc_vk_free, zendoo_verify_certificate_proof, TestCircuitType,
};

#[cfg(feature = "mc-test-circuit")]
use cctp_primitives::proving_system::{
    verifier::batch_verifier::ZendooBatchVerifier, ProvingSystem,
};

#[cfg(feature = "mc-test-circuit")]
use std::{
    ptr::{null, null_mut},
    sync::{Arc, RwLock},
};

#[cfg(feature = "mc-test-circuit")]
use rand::{thread_rng, Rng};

#[cfg(target_os = "windows")]
use std::ffi::OsString;
#[cfg(target_os = "windows")]
use std::os::windows::ffi::OsStrExt;

#[cfg(not(target_os = "windows"))]
fn path_as_ptr(path: &str) -> *const u8 {
    path.as_ptr()
}

#[cfg(target_os = "windows")]
fn path_as_ptr(path: &str) -> *const u16 {
    let tmp: Vec<u16> = OsString::from(path).encode_wide().collect();
    tmp.as_ptr()
}

const LOG_CONFIG_PATH: &str = "./src/tests/log/sample_log_config.yaml";
use std::sync::Once;

static INIT_LOGGER: Once = Once::new();
static INIT_KEYS: Once = Once::new();

pub fn init_test_logger() {
    INIT_LOGGER.call_once(|| {

        // Initialize logger
        let mut ret_code = CctpErrorCode::OK;
        zendoo_init_logger(
            path_as_ptr(LOG_CONFIG_PATH),
            LOG_CONFIG_PATH.len(),
            &mut ret_code,
        );
        assert_eq!(ret_code, CctpErrorCode::OK);

        
    });
}

pub fn init_test_dlog_keys(segment_size: usize) {
    INIT_KEYS.call_once(|| {
        let mut ret_code = CctpErrorCode::OK;
        assert!(zendoo_init_dlog_keys(segment_size, &mut ret_code));
        assert_eq!(ret_code, CctpErrorCode::OK);
    });
}

#[cfg(not(target_os = "windows"))]
#[test]
fn init_logger_multiple() {
    init_test_logger();
    let config_path = parse_path(LOG_CONFIG_PATH.as_ptr(), LOG_CONFIG_PATH.len());
    assert!(init_logger(config_path).is_err());
}

#[cfg(target_os = "windows")]
#[test]
fn init_logger_multiple() {
    init_test_logger();
    // Read config file path
    let path_str = OsString::from_wide(unsafe {
        slice::from_raw_parts(LOG_CONFIG_PATH, LOG_CONFIG_PATH.len())
    });
    let config_path = Path::new(&path_str);

    assert!(init_logger(config_path).is_err());
}

#[cfg(not(target_os = "windows"))]
#[test]
fn init_logger_wrong_file() {
    let config_path = parse_path("".as_ptr(), 0);
    assert!(init_logger(config_path).is_err());
}

#[cfg(target_os = "windows")]
#[test]
fn init_logger_wrong_file() {
    // Read config file path
    let path_str = OsString::from_wide(unsafe {
        slice::from_raw_parts("", 0)
    });
    let config_path = Path::new(&path_str);

    assert!(init_logger(config_path).is_err());
}

#[cfg(feature = "mc-test-circuit")]
#[ignore]
#[test]
fn serialization_deserialization_bench_vk_proof() {
    use crate::{zendoo_deserialize_sc_vk, zendoo_serialize_sc_proof};
    use algebra::UniformRand;
    use cctp_primitives::{type_mapping::FieldElement, utils::serialization::serialize_to_buffer};
    use rand::thread_rng;
    use std::convert::TryInto;

    let segment_size = 1 << 17;
    let num_constraints = 1 << 18;
    let num_proofs = 100;

    let mut rng = &mut thread_rng();
    init_test_logger();

    // Init DLOG keys
    println!("Setup DLOG keys...");
    init_test_dlog_keys(segment_size);

    // CSW
    println!("Bench serialize/deserialize CSW...");
    {
        // Generate SNARK keys
        println!("Generate SNARK pk and vk...");
        let (pk, vk) = crate::mc_test_circuits::csw::generate_parameters(
            ProvingSystem::Darlin,
            num_constraints,
            true,
            None,
        )
        .unwrap();

        println!("Generate proof...");
        let proof = crate::mc_test_circuits::csw::generate_proof(
            &pk,
            true,
            0,
            Some(&FieldElement::rand(&mut rng)),
            &FieldElement::rand(&mut rng),
            &FieldElement::rand(&mut rng),
            vec![0u8; 20].as_slice().try_into().unwrap(),
            &FieldElement::rand(&mut rng),
            &FieldElement::rand(&mut rng),
            num_constraints,
            None,
        )
        .unwrap();

        println!("Test deserialization...");
        for compressed in vec![true, false].into_iter() {
            // Serialize vk and proof in compressed/uncompressed form
            let mut vk_bytes = serialize_to_buffer(&vk, Some(compressed)).unwrap();
            let data_vk = vk_bytes.as_mut_ptr();
            let len_vk = vk_bytes.len();
            let vk_bws = BufferWithSize {
                data: data_vk,
                len: len_vk,
            };

            let proof_bws = zendoo_serialize_sc_proof(&proof, &mut CctpErrorCode::OK, compressed);
            assert!(proof_bws != null_mut());
            let len_proof = unsafe { (*proof_bws).len };

            // Deserialize with various combinations
            for semantic_checks in vec![true, false].into_iter() {
                println!(
                    "Compressed: {}, Semantic checks: {}",
                    compressed,
                    semantic_checks
                );
                println!("Vk len: {}", len_vk);
                println!("Proof len: {}", len_proof);

                let total_deser_vk_time = std::time::Instant::now();
                for _ in 0..num_proofs {
                    let vk = zendoo_deserialize_sc_vk(
                        &vk_bws,
                        semantic_checks,
                        &mut CctpErrorCode::OK,
                        compressed,
                    );
                    assert!(vk != null_mut());
                }
                println!(
                    "Total time to deserialize {} vks: {:?}",
                    num_proofs,
                    total_deser_vk_time.elapsed()
                );

                let total_deser_proof_time = std::time::Instant::now();
                for _ in 0..num_proofs {
                    let proof = zendoo_deserialize_sc_proof(
                        proof_bws,
                        semantic_checks,
                        &mut CctpErrorCode::OK,
                        compressed,
                    );
                    assert!(proof != null_mut());
                }
                println!(
                    "Total time to deserialize {} proofs: {:?}",
                    num_proofs,
                    total_deser_proof_time.elapsed()
                );
            }

            zendoo_free_bws(proof_bws);
        }
    }

    // CERT
    println!("Bench serialize/deserialize CERT...");
    {
        let num_constraints = num_constraints * 2;

        // Generate SNARK keys
        println!("Generate SNARK pk and vk...");
        let (pk, vk) = crate::mc_test_circuits::cert::generate_parameters(
            ProvingSystem::Darlin,
            num_constraints,
            true,
            None,
            false,
        )
        .unwrap();

        println!("Generate proof...");
        let proof = crate::mc_test_circuits::cert::generate_proof(
            &pk,
            true,
            Some(&FieldElement::rand(&mut rng)),
            &FieldElement::rand(&mut rng),
            0,
            0,
            None,
            None,
            &FieldElement::rand(&mut rng),
            0,
            0,
            num_constraints,
            None,
            None,
        )
        .unwrap();

        println!("Test deserialization...");
        for compressed in vec![true, false].into_iter() {
            // Serialize vk and proof in compressed/uncompressed form
            let mut vk_bytes = serialize_to_buffer(&vk, Some(compressed)).unwrap();
            let data_vk = vk_bytes.as_mut_ptr();
            let len_vk = vk_bytes.len();
            let vk_bws = BufferWithSize {
                data: data_vk,
                len: len_vk,
            };

            let proof_bws = zendoo_serialize_sc_proof(&proof, &mut CctpErrorCode::OK, compressed);
            assert!(proof_bws != null_mut());
            let len_proof = unsafe { (*proof_bws).len };

            // Deserialize with various combinations
            for semantic_checks in vec![true, false].into_iter() {
                println!(
                    "Compressed: {}, Semantic checks: {}",
                    compressed,
                    semantic_checks
                );
                println!("Vk len: {}", len_vk);
                println!("Proof len: {}", len_proof);

                let total_deser_vk_time = std::time::Instant::now();
                for _ in 0..num_proofs {
                    let vk = zendoo_deserialize_sc_vk(
                        &vk_bws,
                        semantic_checks,
                        &mut CctpErrorCode::OK,
                        compressed,
                    );
                    assert!(vk != null_mut());
                }
                println!(
                    "Total time to deserialize {} vks: {:?}",
                    num_proofs,
                    total_deser_vk_time.elapsed()
                );

                let total_deser_proof_time = std::time::Instant::now();
                for _ in 0..num_proofs {
                    let proof = zendoo_deserialize_sc_proof(
                        proof_bws,
                        semantic_checks,
                        &mut CctpErrorCode::OK,
                        compressed,
                    );
                    assert!(proof != null_mut());
                }
                println!(
                    "Total time to deserialize {} proofs: {:?}",
                    num_proofs,
                    total_deser_proof_time.elapsed()
                );
            }

            zendoo_free_bws(proof_bws);
        }
    }
}

#[cfg(feature = "mc-test-circuit")]
#[test]
fn prev_sc_cert_hash_support() {
    let segment_size = 1 << 17;
    init_test_logger();

    // Init DLOG keys
    println!("Setup DLOG keys...");
    init_test_dlog_keys(segment_size);

    let num_constraints = 1 << 16;

    println!(
        "Generating cert proof with {} constraints...",
        num_constraints
    );

    std::fs::create_dir_all("./src/tests/keyrot").unwrap();

    // Generate SNARK keys
    println!("Generate SNARK pk and vk...");
    assert!(zendoo_generate_mc_test_params(
        TestCircuitType::Certificate,
        ProvingSystem::Darlin,
        num_constraints,
        true, // use prev_cert_hash
        path_as_ptr("./src/tests/keyrot"),
        18,
        &mut CctpErrorCode::OK,
        true,
        true,
        std::ptr::null()
    ));

    // Create test proof
    let sc_id = zendoo_get_random_field();
    assert!(sc_id != null_mut());

    let constant = zendoo_get_random_field();
    assert!(constant != null_mut());

    let end_cum_comm_tree_root = zendoo_get_random_field();
    assert!(end_cum_comm_tree_root != null_mut());

    let pk = zendoo_deserialize_sc_pk_from_file(
        path_as_ptr("./src/tests/keyrot/darlin_cert_test_pk"),
        38,
        false,
        &mut CctpErrorCode::OK,
        true,
    );
    assert!(pk != null_mut());

    println!("Generate proof...");
    let random_field_proof = zendoo_get_random_field();
    let proof_buff = zendoo_create_return_cert_test_proof(
        true,
        constant,
        sc_id,
        0,
        10,
        null(),
        0,
        null(),
        0,
        end_cum_comm_tree_root,
        0,
        0,
        pk,
        num_constraints,
        random_field_proof,
        &mut CctpErrorCode::OK,
        true,
        std::ptr::null(),
    );
    assert!(proof_buff != null_mut());

    let proof = zendoo_deserialize_sc_proof(proof_buff, false, &mut CctpErrorCode::OK, true);
    assert!(proof != null_mut());

    let vk = zendoo_deserialize_sc_vk_from_file(
        path_as_ptr("./src/tests/keyrot/darlin_cert_test_vk"),
        38,
        false,
        &mut CctpErrorCode::OK,
        true,
    );
    assert!(vk != null_mut());

    println!("Verifying proof...");
    assert!(zendoo_verify_certificate_proof(
        constant,
        sc_id,
        0,
        10,
        null(),
        0,
        null(),
        0,
        end_cum_comm_tree_root,
        0,
        0,
        proof,
        vk,
        random_field_proof,
        &mut CctpErrorCode::OK
    ));

    println!("Assert failure with wrong key...");
    let random_field_wrong = zendoo_get_random_field();
    assert!(!zendoo_verify_certificate_proof(
        constant,
        sc_id,
        0,
        10,
        null(),
        0,
        null(),
        0,
        end_cum_comm_tree_root,
        0,
        0,
        proof,
        vk,
        random_field_wrong,
        &mut CctpErrorCode::OK
    ));

    // Free memory
    println!("Cleaning up...");
    zendoo_field_free(constant);
    zendoo_field_free(sc_id);
    zendoo_field_free(end_cum_comm_tree_root);
    zendoo_sc_pk_free(pk);
    zendoo_free_bws(proof_buff);
    zendoo_sc_proof_free(proof);
    zendoo_sc_vk_free(vk);
    zendoo_field_free(random_field_proof);
    zendoo_field_free(random_field_wrong);

    println!("Cleaning up...");
    std::fs::remove_file("./src/tests/keyrot/darlin_cert_test_pk").unwrap();
    std::fs::remove_file("./src/tests/keyrot/darlin_cert_test_vk").unwrap();
    std::fs::remove_dir("./src/tests/keyrot").unwrap();
}

#[cfg(feature = "mc-test-circuit")]
#[test]
fn zendoo_batch_verifier_multiple_threads_with_priority() {
    let segment_size = 1 << 17;
    let num_proofs = 100;

    // Init DLOG keys
    init_test_logger();
    println!("Setup DLOG keys...");
    init_test_dlog_keys(segment_size);

    for j in 15..=16 {
        // Get batch verifier
        let mut bv = ZendooBatchVerifier::create();

        // Certificate proof
        {
            let num_constraints = 1 << (j + 1);

            println!(
                "Generating {} cert proofs with {} constraints...",
                num_proofs / 2,
                num_constraints
            );

            // Generate SNARK keys
            println!("Generate SNARK pk and vk...");
            assert!(zendoo_generate_mc_test_params(
                TestCircuitType::Certificate,
                ProvingSystem::Darlin,
                num_constraints,
                false,
                path_as_ptr("./src/tests"),
                11,
                &mut CctpErrorCode::OK,
                true,
                true,
                std::ptr::null()
            ));

            // Create test proof
            let sc_id = zendoo_get_random_field();
            assert!(sc_id != null_mut());

            let constant = zendoo_get_random_field();
            assert!(constant != null_mut());

            let end_cum_comm_tree_root = zendoo_get_random_field();
            assert!(end_cum_comm_tree_root != null_mut());

            let pk = zendoo_deserialize_sc_pk_from_file(
                path_as_ptr("./src/tests/darlin_cert_test_pk"),
                31,
                false,
                &mut CctpErrorCode::OK,
                true,
            );
            assert!(pk != null_mut());

            println!("Generate proof...");
            let proof_buff = zendoo_create_return_cert_test_proof(
                true,
                constant,
                sc_id,
                0,
                0,
                null(),
                0,
                null(),
                0,
                end_cum_comm_tree_root,
                0,
                0,
                pk,
                num_constraints,
                null(),
                &mut CctpErrorCode::OK,
                true,
                std::ptr::null(),
            );
            assert!(proof_buff != null_mut());

            let proof =
                zendoo_deserialize_sc_proof(proof_buff, false, &mut CctpErrorCode::OK, true);
            assert!(proof != null_mut());

            let vk = zendoo_deserialize_sc_vk_from_file(
                path_as_ptr("./src/tests/darlin_cert_test_vk"),
                31,
                false,
                &mut CctpErrorCode::OK,
                true,
            );
            assert!(vk != null_mut());

            println!("Add proofs to batch verifier...");
            for i in 0..num_proofs / 2 {
                assert!(zendoo_add_certificate_proof_to_batch_verifier(
                    &mut bv,
                    i,
                    constant,
                    sc_id,
                    0,
                    0,
                    null(),
                    0,
                    null(),
                    0,
                    end_cum_comm_tree_root,
                    0,
                    0,
                    proof,
                    vk,
                    null(),
                    &mut CctpErrorCode::OK
                ));
            }

            // Free memory
            println!("Cleaning up...");
            zendoo_field_free(constant);
            zendoo_field_free(sc_id);
            zendoo_field_free(end_cum_comm_tree_root);
            zendoo_sc_pk_free(pk);
            zendoo_free_bws(proof_buff);
            zendoo_sc_proof_free(proof);
            zendoo_sc_vk_free(vk);
        }

        // CSW proof
        {
            let num_constraints = 1 << j;

            println!(
                "Generating {} CSW proofs with {} constraints...",
                num_proofs / 2,
                num_constraints
            );

            // Generate SNARK keys
            println!("Generate SNARK pk and vk...");
            assert!(zendoo_generate_mc_test_params(
                TestCircuitType::CSW,
                ProvingSystem::Darlin,
                num_constraints,
                false,
                path_as_ptr("./src/tests"),
                11,
                &mut CctpErrorCode::OK,
                true,
                true,
                std::ptr::null()
            ));

            // Create test proof
            let sc_id = zendoo_get_random_field();
            assert!(sc_id != null_mut());

            let constant = zendoo_get_random_field();
            assert!(constant != null_mut());

            let nullifier = zendoo_get_random_field();
            assert!(nullifier != null_mut());

            let mut mc_pk_hash = vec![0u8; 20];
            let data = mc_pk_hash.as_mut_ptr();
            let len = mc_pk_hash.len();

            let buffer = BufferWithSize { data, len };

            let cert_data_hash = zendoo_get_random_field();
            assert!(cert_data_hash != null_mut());

            let end_cum_comm_tree_root = zendoo_get_random_field();
            assert!(end_cum_comm_tree_root != null_mut());

            let pk = zendoo_deserialize_sc_pk_from_file(
                path_as_ptr("./src/tests/darlin_csw_test_pk"),
                30,
                false,
                &mut CctpErrorCode::OK,
                true,
            );
            assert!(pk != null_mut());

            println!("Generate proof...");
            let proof_buff = zendoo_create_return_csw_test_proof(
                true,
                0,
                constant,
                sc_id,
                nullifier,
                &buffer,
                cert_data_hash,
                end_cum_comm_tree_root,
                pk,
                num_constraints,
                &mut CctpErrorCode::OK,
                true,
                std::ptr::null(),
            );
            assert!(proof_buff != null_mut());

            let proof =
                zendoo_deserialize_sc_proof(proof_buff, false, &mut CctpErrorCode::OK, true);
            assert!(proof != null_mut());

            let vk = zendoo_deserialize_sc_vk_from_file(
                path_as_ptr("./src/tests/darlin_csw_test_vk"),
                30,
                false,
                &mut CctpErrorCode::OK,
                true,
            );
            assert!(vk != null_mut());

            println!("Add proofs to batch verifier...");
            for i in num_proofs / 2..num_proofs {
                assert!(zendoo_add_csw_proof_to_batch_verifier(
                    &mut bv,
                    i,
                    0,
                    constant,
                    sc_id,
                    nullifier,
                    &buffer,
                    cert_data_hash,
                    end_cum_comm_tree_root,
                    proof,
                    vk,
                    &mut CctpErrorCode::OK
                ));
            }

            // Free memory
            println!("Cleaning up...");
            zendoo_field_free(constant);
            zendoo_field_free(sc_id);
            zendoo_field_free(nullifier);
            zendoo_field_free(cert_data_hash);
            zendoo_field_free(end_cum_comm_tree_root);
            zendoo_sc_pk_free(pk);
            zendoo_free_bws(proof_buff);
            zendoo_sc_proof_free(proof);
            zendoo_sc_vk_free(vk);
        }

        let bv_arc = Arc::new(bv);

        // Spawn batch verification threads
        let rng = &mut thread_rng();
        let num_threads: usize = rng.gen_range(2..11);

        println!(
            "Perform {} separate batch verifications with different priority...",
            num_threads
        );

        // Keep generating priorities at random, until at least one thread is low priority
        // and at least one thread is high priority
        let mut priorities = (0..num_threads).map(|_| rng.gen()).collect::<Vec<bool>>();
        while priorities.iter().all(|&b| b) || priorities.iter().all(|&b| !b) {
            priorities = (0..num_threads).map(|_| rng.gen()).collect::<Vec<bool>>()
        }

        let mut handles = vec![];
        let low_priority_timings = Arc::new(RwLock::new(vec![]));
        let high_priority_timings = Arc::new(RwLock::new(vec![]));

        for i in 0..num_threads {
            let priority = priorities[i];
            let bv_ref = bv_arc.clone();
            let timings_vec_ref = if priority {
                high_priority_timings.clone()
            } else {
                low_priority_timings.clone()
            };
            let handle = std::thread::spawn(move || {
                println!("Thread {} started", i);

                // Execute batch verification and take the time
                let start = std::time::Instant::now();
                let result =
                    zendoo_batch_verify_all_proofs(&*bv_ref, priority, &mut CctpErrorCode::OK);
                let time = start.elapsed();

                // Assert verification successfull
                unsafe {
                    assert!((*result).result);
                }
                zendoo_free_batch_proof_verifier_result(result);

                println!("Thread {} finished in: {:?}", i, time);

                // Push execution time in timings vec
                timings_vec_ref.write().unwrap().push(time.as_millis());
            });
            println!(
                "Spawned batch verification thread {} with priority {}",
                i,
                priority
            );
            handles.push(handle);
        }
        handles
            .into_iter()
            .for_each(|handle| handle.join().unwrap());

        // Assert high priority verifications finished before low priority verifications
        assert!(
            high_priority_timings
                .clone()
                .read()
                .unwrap()
                .iter()
                .sum::<u128>()
                / high_priority_timings.clone().read().unwrap().len() as u128
                <= low_priority_timings
                    .clone()
                    .read()
                    .unwrap()
                    .iter()
                    .sum::<u128>()
                    / low_priority_timings.clone().read().unwrap().len() as u128
        );

        println!("Cleaning up...");
        std::fs::remove_file("./src/tests/darlin_cert_test_pk").unwrap();
        std::fs::remove_file("./src/tests/darlin_cert_test_vk").unwrap();
        std::fs::remove_file("./src/tests/darlin_csw_test_pk").unwrap();
        std::fs::remove_file("./src/tests/darlin_csw_test_vk").unwrap();
    }
}

#[test]
fn compress_decompress() {
    init_test_logger();
    for _ in 0..10 {
        let mut bit_vector: Vec<u8> = (0..100).collect();
        let data = bit_vector.as_mut_ptr();
        let len = bit_vector.len();

        let buffer = BufferWithSize { data, len };
        let mut ret_code = CctpErrorCode::OK;
        let compressed_buffer =
            zendoo_compress_bit_vector(&buffer, CompressionAlgorithm::Bzip2, &mut ret_code);
        let uncompressed_buffer =
            zendoo_decompress_bit_vector(compressed_buffer, len, &mut ret_code);

        let processed_bit_vector = unsafe {
            slice::from_raw_parts((*uncompressed_buffer).data, (*uncompressed_buffer).len)
        };
        assert_eq!((0..100).collect::<Vec<u8>>(), processed_bit_vector);

        zendoo_free_bws(compressed_buffer);
        zendoo_free_bws(uncompressed_buffer);
    }
}
