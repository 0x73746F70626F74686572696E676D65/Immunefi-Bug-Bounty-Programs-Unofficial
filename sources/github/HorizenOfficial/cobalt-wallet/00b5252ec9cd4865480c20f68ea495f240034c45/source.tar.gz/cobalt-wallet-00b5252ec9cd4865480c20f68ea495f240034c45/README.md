> ⚠️ **Repository Archived**

---

### 🚫 Deprecated — No Longer Maintained

This repository has been **archived** and is **no longer actively maintained**.

- ❌ No further updates, issues, or pull requests will be accepted.
- 📦 The code remains available for **reference purposes only**.
- ⚠️ **Use at your own discretion.**

---

**Archived on:** _2025-10-15_

<p align="center"><img src="./Cobalt_dark_logo.svg" width="600"></p>

# Cobalt Browser Extension

Cobalt supports Google Chrome, and Chromium-based browsers. We recommend using the latest available browser version.

## About

Cobalt is a browser extension that communicates with TokenMint on the Horizen Tokenization Platform.

Features include:

- Generating a wallet for TokenMint
- Restoring a wallet for TokenMint
- Showing account balance and transaction history for fungible tokens and ZEN on TokenMint
- Sending and receiving fungible tokens on TokenMint
- Sending ZEN to the Horizen Mainchain and receiving ZEN from the Horizen Mainchain

## Installation Instructions

The extension files are available for download [here](https://github.com/HorizenOfficial/cobalt-wallet/releases).

1.  Download the zip file and unzip it
2.  In your browser, go to chrome://extensions
3.  Toggle on Developer Mode
4.  Press the “Load Unpacked” button and upload the packaged directory
