package utils

import (
	"encoding/binary"
	"math"
	"unsafe"
)

// Note: The TinyGo WASM module acts as a self-contained environment running on a single logical thread.
// Concurrency for calls to the WASM module must be handled on the host side (e.g., using Go's sync.Mutex
// in the calling Go code or better, using a single wasmtime.Instance for every call), as TinyGo's 'sync'
// package is not fully supported within the WASM environment for inter-module synchronization.

// allocatedMemory holds references to memory allocated by the guest, preventing the Go garbage
// collector from reclaiming it while it's in use by the host. The map key is the pointer address.
var allocatedMemory = make(map[uintptr][]byte)

// TODO - When TinyGo compiles go into wasm, it configures the WebAssembly linear memory to an initial size
// of 2 pages (128KB), and marks a position in that memory as the heap base. All memory beyond that is used for the
// Go heap. Allocations within Go (compiled to %.wasm) are managed by calling memory.grow. The instruction is executed
// within the Wasm instance, but the actual memory growth happens in Wasmtime's engine, which allocates more memory pages.
// A freeMap could be used to track memory blocks that have been freed and are available for reuse, avoiding the need
// to always request new memory pages from the WASM runtime, this is good for performances.
// The drawback is risk of mem fragmentation, and the fact that the application retains the maximum memory envelope
// it has ever needed.
// var freeList = make(map[int32][][]byte)

// total memory (in bytes) currently allocated
var cumulativeAllocSize int64

// --- WASM Memory Management Functions ---

//export allocate
func Allocate(size int32) int32 {
	LogDebug("allocate called with size=%d", size)
	if size <= 0 {
		// Return a null pointer for zero or negative size.
		// The caller should check for zero-length data, but this makes the guest allocator more robust.
		return 0
	}
	// Allocate a byte slice of the desired size.
	data := make([]byte, size)

	// Get a pointer to the slice's underlying data.
	ptr := &data[0]

	// Convert to uintptr (valid on wasm32, which has 4GB address space max).
	uptr := uintptr(unsafe.Pointer(ptr))

	// Store a reference to the slice in our global map to "pin" it and preventing GC from acting
	allocatedMemory[uptr] = data

	cumulativeAllocSize += int64(size)

	// Return the pointer address as an int32 to the host.
	// Go Wasmtime runtime receives the signed int32 bit pattern and casts them to uintptr when accessing memory
	LogDebug("allocate returning ptr=%d (decimal=%d), total_allocated=%d", uptr, int32(uptr), cumulativeAllocSize)
	return int32(uptr)
}

//export deallocate
func Deallocate(ptr *byte, size int32) {
	LogDebug("deallocate called with ptr=%v, size=%d", ptr, size)

	if ptr == nil {
		LogWarn("deallocate called with nil ptr")
		return
	}

	if allocatedMemory == nil {
		LogWarn("deallocate: allocatedMemory map is nil")
		return
	}

	// Get the uintptr from the pointer.
	uptr := uintptr(unsafe.Pointer(ptr))

	b, ok := allocatedMemory[uptr]
	if !ok {
		// we exit even if delete on a map would be a no op, but we also do not decrement the counter
		LogWarn("deallocate: allocation not in map, uptr=%d", uptr)
		return
	}

	// Delete the reference from the map. This unpins the memory, making it eligible for garbage collection.
	delete(allocatedMemory, uptr)

	if int32(len(b)) != size {
		// We could add more counters for errors and stats in future
		LogWarn("deallocate: size mismatch, caller passed %d but allocation was %d", size, len(b))
	}

	cumulativeAllocSize -= int64(len(b))
	LogDebug("deallocate returning, total_allocated=%d", cumulativeAllocSize)
}

// Note: if we call directly this function from the host, the ABI C interface foresees that
// for multiple return values, the values are stored into a pointer passed as the first parameter by the caller.
//
//export get_allocated_memory_stats
func GetAllocatedMemoryStats() (mapSize, totalBytes int64) {
	mapSize = int64(len(allocatedMemory))
	totalBytes = cumulativeAllocSize
	return
}

// --- Helper Functions for Data Translation ---

// PtrToString converts a WASM pointer and length to a Go string.
// (nil, 0) is the legitimate empty case (complement of BytesToPtr returning nil
// for empty input) and returns "" silently. Inconsistent combinations
// (nil ptr with non-zero length, or non-nil ptr with zero length) and negative
// lengths are logged as warnings.
func PtrToString(ptr *byte, length int32) string {
	if length < 0 || (ptr == nil) != (length == 0) {
		LogWarn("Invalid ptr or length, ptr=%v, length=%d", ptr, length)
		return ""
	}
	if length == 0 {
		return ""
	}
	return string(unsafe.Slice(ptr, length))
}

const (
	// MaxWasmDataSize is the maximum size allowed for the data portion.
	// We subtract 4 to leave room for the 32-bit length prefix.
	MaxWasmDataSize = math.MaxInt32 - 4
)

// BytesToPtr converts a Go byte slice to an allocated memory pointer for WASM.
func BytesToPtr(data []byte) *byte {
	dataLength := len(data)
	if dataLength == 0 {
		return nil
	}
	if dataLength > MaxWasmDataSize {
		LogError("data len exceeds max int size, dataLength=%d", dataLength)
		return nil
	}

	n := 4 + dataLength // 4 bytes for length + actual data length
	ptrVal := Allocate(int32(n))
	// note: we do not check for ptrVal == 0 because we already check size to be non negative, and
	// an OOM would have panicked already in allocate()

	dataBytes := (*byte)(unsafe.Pointer(uintptr(ptrVal)))
	destination := unsafe.Slice(dataBytes, n)

	binary.LittleEndian.PutUint32(destination[:4], uint32(dataLength))
	copy(destination[4:], data)

	return dataBytes
}
