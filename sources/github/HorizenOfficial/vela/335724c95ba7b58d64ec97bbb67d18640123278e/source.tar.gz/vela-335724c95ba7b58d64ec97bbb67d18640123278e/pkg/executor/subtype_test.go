package executor

import (
	"context"
	"crypto/ecdsa"
	"testing"

	ethCrypto "github.com/ethereum/go-ethereum/crypto"
	"github.com/HorizenOfficial/vela/pkg/common"
	"github.com/HorizenOfficial/vela/pkg/common/appdata"
	commontestutil "github.com/HorizenOfficial/vela/pkg/common/testutil"
	"github.com/HorizenOfficial/vela/pkg/crypto"
	"github.com/stretchr/testify/require"
)

// --- GenerateSubtype tests ---

func TestGenerateSubtype_Deterministic(t *testing.T) {
	seed := mustSeed(t)
	s1 := GenerateSubtype(seed, 1)
	s2 := GenerateSubtype(seed, 1)
	require.Equal(t, s1, s2)
}

func TestGenerateSubtype_DifferentIndex(t *testing.T) {
	seed := mustSeed(t)
	require.NotEqual(t, GenerateSubtype(seed, 1), GenerateSubtype(seed, 2))
}

func TestGenerateSubtype_DifferentSeed(t *testing.T) {
	seed1, seed2 := mustSeed(t), mustSeed(t)
	require.NotEqual(t, GenerateSubtype(seed1, 1), GenerateSubtype(seed2, 1))
}

func TestGenerateSubtype_Format(t *testing.T) {
	s := GenerateSubtype(mustSeed(t), 1)
	require.NotEqual(t, [32]byte{}, s, "should not be all zeros")
}

// --- AllSubtypes tests ---

func TestAllSubtypes_Length(t *testing.T) {
	require.Len(t, AllSubtypes(mustSeed(t), 50), 50)
}

func TestAllSubtypes_Unique(t *testing.T) {
	subtypes := AllSubtypes(mustSeed(t), 50)
	seen := make(map[[32]byte]struct{}, 50)
	for _, st := range subtypes {
		_, dup := seen[st]
		require.False(t, dup, "duplicate subtype found: 0x%x", st)
		seen[st] = struct{}{}
	}
}

func TestAllSubtypes_Indices(t *testing.T) {
	seed := mustSeed(t)
	subtypes := AllSubtypes(seed, 3)
	require.Equal(t, GenerateSubtype(seed, 1), subtypes[0])
	require.Equal(t, GenerateSubtype(seed, 2), subtypes[1])
	require.Equal(t, GenerateSubtype(seed, 3), subtypes[2])
}

// --- GenerateRandomSubtype tests ---

func TestGenerateRandomSubtype_InSet(t *testing.T) {
	seed := mustSeed(t)
	all := AllSubtypes(seed, DefaultSubtypeN)
	allSet := make(map[[32]byte]struct{}, len(all))
	for _, st := range all {
		allSet[st] = struct{}{}
	}
	for i := 0; i < 20; i++ {
		st, err := GenerateRandomSubtype(seed, DefaultSubtypeN)
		require.NoError(t, err)
		_, ok := allSet[st]
		require.True(t, ok, "generated subtype 0x%x not in expected set", st)
	}
}

// --- Integration test: AssociateKey with seed + subtype generation ---

func TestAssociateKey_AndSubtypeGeneration(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping integration test in short mode")
	}
	exec := newTestExecutor(t, NewMockRuntime(testLogger))

	// Generate secp256k1 signing key; derive sender address from it
	signingKey, err := ethCrypto.GenerateKey()
	require.NoError(t, err)
	sender := ethCrypto.PubkeyToAddress(signingKey.PublicKey)

	// Compute seed: sign keccak256(SubtypeKeyMessage) deterministically
	msgHash := ethCrypto.Keccak256([]byte(SubtypeKeyMessage))
	seed, err := ethCrypto.Sign(msgHash, signingKey)
	require.NoError(t, err)
	require.Len(t, seed, 65)

	// Generate P521 encryption key for the user
	p521Key, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)
	pubKeyBytes := p521Key.PublicKey().Bytes()
	require.Len(t, pubKeyBytes, 133)

	// Encrypt the seed with the user's P521 private key and the enclave's P521 public key
	encryptedSeed, err := crypto.Encrypt(p521Key, exec.keySet.CommunicationKey.PublicKey(), seed)
	require.NoError(t, err)

	// Build AssociateKey payload: P521 pubkey (133 bytes) + encrypted seed (93 bytes)
	payloadWithSeed := append(pubKeyBytes, encryptedSeed...)
	require.Len(t, payloadWithSeed, 226)

	wasmModule := []byte("wasm")
	appState := buildEncryptedAppState(t, exec, nil, nil, wasmModule)

	req := newProcessRequest()
	req.RequestType = common.AssociateKey
	req.Payload = payloadWithSeed
	req.Sender = sender

	// Execute AssociateKey request
	respPayload, newAppState, _, err := exec.HandleProcessRequest(context.Background(), req, appState, wasmModule)
	require.NoError(t, err)
	require.NotNil(t, respPayload)
	require.Equal(t, uint8(0), respPayload.ErrorCode, "expected success, got error: %s", respPayload.ErrorMsg)

	// Deserialize new app data and verify seed was stored
	decryptedState, err := crypto.DecryptWithAES(exec.keySet.StateKey, newAppState.EncryptedState)
	require.NoError(t, err)
	ad, err := appdata.DeserializeAppData(decryptedState)
	require.NoError(t, err)

	storedSeed, hasSeed := ad.GetSeed(sender)
	require.True(t, hasSeed, "seed should be stored after AssociateKey")
	require.Equal(t, seed, storedSeed)

	// Now verify that encryptEvents generates a subtype from the seed
	// Register the P521 key in a fresh app state that has both key and seed
	keyStore := appdata.KeyStore{sender: p521Key.PublicKey()}
	seedStore := appdata.SeedStore{sender: seed}

	commKey, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	wasmSubtype := [32]byte{0x01}
	plainEvents := []common.PlainEvent{{
		UserID:       sender,
		EventSubType: wasmSubtype, // WASM-provided subtype; should be overridden
		Data:         []byte(`{"type":"deposit"}`),
	}}

	e := &StatelessExecutor{log: testLogger}
	encryptedEvents, failure, err := e.encryptEvents(
		context.Background(),
		plainEvents,
		common.NewApplicationId(1),
		commKey,
		nil,
		keyStore,
		seedStore,
	)
	require.Nil(t, failure)
	require.NoError(t, err)
	require.Len(t, encryptedEvents, 1)

	// The subtype should be one of the N possible subtypes derived from the seed
	generatedSubtype := encryptedEvents[0].EventSubType
	allSubtypes := AllSubtypes(seed, DefaultSubtypeN)
	require.Contains(t, allSubtypes, generatedSubtype, "generated subtype should be in the expected set")
	require.NotEqual(t, wasmSubtype, generatedSubtype, "WASM-provided subtype should be overridden")
}

// --- Event retrieval test: verify subtype set filtering ---

func TestEventRetrieval_BySubtypeSet(t *testing.T) {
	// User A has a seed; user B does not
	seedA := mustSeed(t)
	userAAddr := ethCrypto.PubkeyToAddress(mustGenerateKey(t).PublicKey)
	userBAddr := ethCrypto.PubkeyToAddress(mustGenerateKey(t).PublicKey)

	// Generate P521 keys for both users
	userAKey, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)
	userBKey, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	keyStore := appdata.KeyStore{
		userAAddr: userAKey.PublicKey(),
		userBAddr: userBKey.PublicKey(),
	}
	// Only user A has a seed
	seedStore := appdata.SeedStore{userAAddr: seedA}

	commKey, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	depositSubtype := [32]byte{0x01}
	withdrawalSubtype := [32]byte{0x02}
	plainEvents := []common.PlainEvent{
		{UserID: userAAddr, EventSubType: depositSubtype, Data: []byte("a1")},
		{UserID: userAAddr, EventSubType: withdrawalSubtype, Data: []byte("a2")},
		{UserID: userBAddr, EventSubType: depositSubtype, Data: []byte("b1")},
	}

	e := &StatelessExecutor{log: testLogger}
	encrypted, failure, err := e.encryptEvents(
		context.Background(),
		plainEvents,
		common.NewApplicationId(1),
		commKey,
		nil,
		keyStore,
		seedStore,
	)
	require.Nil(t, failure)
	require.NoError(t, err)
	require.Len(t, encrypted, 3)

	// All user A events should have a subtype in AllSubtypes(seedA, N)
	userASubtypes := AllSubtypes(seedA, DefaultSubtypeN)
	subtypeSet := make(map[[32]byte]struct{}, len(userASubtypes))
	for _, st := range userASubtypes {
		subtypeSet[st] = struct{}{}
	}

	for _, ev := range encrypted {
		if ev.UserID == userAAddr {
			_, ok := subtypeSet[ev.EventSubType]
			require.True(t, ok, "user A event subtype 0x%x should be in expected set", ev.EventSubType)
			require.NotEqual(t, depositSubtype, ev.EventSubType)
			require.NotEqual(t, withdrawalSubtype, ev.EventSubType)
		} else if ev.UserID == userBAddr {
			// User B has no seed; original subtype is preserved
			require.Equal(t, depositSubtype, ev.EventSubType)
		}
	}
}

// --- helpers ---

func mustGenerateKey(t *testing.T) *ecdsa.PrivateKey {
	t.Helper()
	k, err := ethCrypto.GenerateKey()
	require.NoError(t, err)
	return k
}

func mustSeed(t *testing.T) []byte {
	t.Helper()
	k, err := ethCrypto.GenerateKey()
	require.NoError(t, err)
	msgHash := ethCrypto.Keccak256([]byte(SubtypeKeyMessage))
	seed, err := ethCrypto.Sign(msgHash, k)
	require.NoError(t, err)
	return seed
}

// Verify that without a seed the original WASM-provided subtype is preserved
func TestEncryptEvents_NoSeed_PreservesSubtype(t *testing.T) {
	p521Key, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)
	userAddr := ethCrypto.PubkeyToAddress(mustGenerateKey(t).PublicKey)

	keyStore := appdata.KeyStore{userAddr: p521Key.PublicKey()}
	seedStore := appdata.SeedStore{} // no seed

	commKey, err := crypto.GeneratePrivateKeyP521()
	require.NoError(t, err)

	origSubtype := [32]byte{0x42}
	plain := []common.PlainEvent{{UserID: userAddr, EventSubType: origSubtype, Data: []byte("x")}}

	e := &StatelessExecutor{log: testLogger}
	encrypted, failure, err := e.encryptEvents(context.Background(), plain, common.NewApplicationId(1), commKey, nil, keyStore, seedStore)
	require.Nil(t, failure)
	require.NoError(t, err)
	require.Equal(t, origSubtype, encrypted[0].EventSubType, "subtype should be preserved when no seed is registered")

	_ = commontestutil.GenerateRandomRequestID() // keep import used
}
