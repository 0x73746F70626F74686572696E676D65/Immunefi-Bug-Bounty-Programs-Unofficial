import { getAddress, isAddress } from "viem";
import { z } from "zod";
import { isValidPrivateKey } from "./privateKeysUtilities";

const privateKeyValidator = z.string().refine(isValidPrivateKey, {
  message: "Private key is not a valid WIF or hex format",
});

const destinationAddressValidator = z.string().refine(  
  (addr) => {
  if (!isAddress(addr)) return false;          // basic validation
  return addr === getAddress(addr);            // checksum validation
}, {
  message: "Destination address is not a valid EIP-55 formatted Ethereum address",
});

const testnetValidator = z.boolean();
const compressedValidator = z.boolean();

export {
  compressedValidator,
  destinationAddressValidator,
  privateKeyValidator,
  testnetValidator,
};
