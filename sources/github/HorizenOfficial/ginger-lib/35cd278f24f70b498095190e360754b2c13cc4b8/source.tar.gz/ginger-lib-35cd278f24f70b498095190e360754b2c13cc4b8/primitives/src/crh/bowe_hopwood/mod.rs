use crate::{bytes_to_bits, CryptoError, Error};
use num_bigint::BigUint;
use rand::Rng;
use rayon::prelude::*;
use std::{
    fmt::{Debug, Formatter, Result as FmtResult},
    marker::PhantomData,
};

use super::pedersen::PedersenWindow;
use crate::crh::FixedLengthCRH;
use algebra::{fields::PrimeField, groups::Group};
use serde::{Deserialize, Serialize};

pub const CHUNK_SIZE: usize = 3;

#[derive(Clone, Default, Serialize, Deserialize)]
#[serde(bound(deserialize = "G: Group"))]
pub struct BoweHopwoodPedersenParameters<G: Group> {
    pub generators: Vec<Vec<G>>,
    pub maximum_num_chunks_in_segment: usize,
}

pub struct BoweHopwoodPedersenCRH<G: Group, W: PedersenWindow, const N: usize> {
    group: PhantomData<G>,
    window: PhantomData<W>,
}

impl<G: Group> BoweHopwoodPedersenParameters<G> {
    /// Zcash protocol specification - section 5.4.1.7
    /// We need to find a c such that 4 * (2^4c - 1)/15 <= F::MODULUS_MINUS_ONE_DIV_TWO
    pub(crate) fn calculate_num_chunks_in_segment<F: PrimeField>() -> usize {
        let upper_limit: BigUint = (F::modulus_minus_one_div_two().into() * 15u32) + 4u32;

        let mut c = 0;
        let mut range = BigUint::from(1u32);
        while (&range << 2) <= upper_limit {
            range <<= 4;
            c += 1;
        }

        // Rule out weird edge cases. Can only happen if MODULUS = 0 or 1
        if c == 0 {
            panic!("Invalid Field modulus (0 or 1). Unable to compute parameters.");
        }

        c - 1
    }
}

impl<G: Group, W: PedersenWindow, const N: usize> BoweHopwoodPedersenCRH<G, W, N> {
    pub fn check_setup_preconditions(maximum_num_chunks_in_segment: usize) -> Result<(), Error> {
        assert_eq!(CHUNK_SIZE, 3);

        if Self::INPUT_SIZE_BITS > W::WINDOW_SIZE * W::NUM_WINDOWS * CHUNK_SIZE {
            return Err(Box::new(CryptoError::Other(
                format!(
                    "window params {:?}x{:?}x{} are incorrect for input length {:?}",
                    W::WINDOW_SIZE,
                    W::NUM_WINDOWS,
                    CHUNK_SIZE,
                    N,
                )
                .to_owned(),
            )));
        }

        if W::WINDOW_SIZE > maximum_num_chunks_in_segment {
            return Err(format!(
                "Bowe-Hopwood hash must have a window size resulting in scalars < (p-1)/2, \
                 maximum segment size is {}",
                maximum_num_chunks_in_segment
            )
            .into());
        }

        Ok(())
    }

    pub fn check_preconditions(params: &BoweHopwoodPedersenParameters<G>) -> Result<(), Error> {
        Self::check_setup_preconditions(params.maximum_num_chunks_in_segment)?;

        if params.generators.len() != W::NUM_WINDOWS {
            Err(Box::new(CryptoError::Other(
                format!(
                    "Incorrect pp of size {:?} for window params {:?}x{:?}x{}",
                    params.generators.len(),
                    W::WINDOW_SIZE,
                    W::NUM_WINDOWS,
                    CHUNK_SIZE
                )
                .to_owned(),
            )))?
        }

        for generators in params.generators.iter() {
            if generators.len() != W::WINDOW_SIZE {
                Err(Box::new(CryptoError::Other(format!(
                    "Number of generators: {} not enough for the selected window size: {}",
                    params.generators.len(),
                    W::WINDOW_SIZE
                ))))?
            }
        }

        Ok(())
    }

    pub fn setup_from_generators(
        generators: Vec<Vec<G>>,
    ) -> Result<<Self as FixedLengthCRH>::Parameters, Error> {
        let maximum_num_chunks_in_segment =
            BoweHopwoodPedersenParameters::<G>::calculate_num_chunks_in_segment::<G::ScalarField>();
        let parameters = BoweHopwoodPedersenParameters {
            generators,
            maximum_num_chunks_in_segment,
        };
        Self::check_preconditions(&parameters)?;
        Ok(parameters)
    }

    pub fn create_generators_from_base_points(base_gens: Vec<G>) -> Vec<Vec<G>> {
        let mut generators = Vec::new();
        assert_eq!(base_gens.len(), W::NUM_WINDOWS);
        for mut base in base_gens {
            let mut generators_for_segment = Vec::new();
            for _ in 0..W::WINDOW_SIZE {
                generators_for_segment.push(base);
                for _ in 0..4 {
                    base.double_in_place();
                }
            }
            generators.push(generators_for_segment);
        }
        generators
    }

    pub fn create_generators<R: Rng>(rng: &mut R) -> Vec<Vec<G>> {
        Self::create_generators_from_base_points(vec![G::rand(rng); W::NUM_WINDOWS])
    }
}

impl<G: Group, W: PedersenWindow, const N: usize> FixedLengthCRH
    for BoweHopwoodPedersenCRH<G, W, N>
{
    const INPUT_SIZE_BITS: usize = N * 8;
    type Output = G;
    type Parameters = BoweHopwoodPedersenParameters<G>;

    fn setup<R: Rng>(rng: &mut R) -> Result<Self::Parameters, Error> {
        let maximum_num_chunks_in_segment =
            Self::Parameters::calculate_num_chunks_in_segment::<G::ScalarField>();
        Self::check_setup_preconditions(maximum_num_chunks_in_segment)?;

        let time = start_timer!(|| format!(
            "BoweHopwoodPedersenCRH::Setup: {} segments of {} 3-bit chunks; {{0,1}}^{{{}}} -> G",
            W::NUM_WINDOWS,
            W::WINDOW_SIZE,
            W::WINDOW_SIZE * W::NUM_WINDOWS * CHUNK_SIZE
        ));
        let generators = Self::create_generators(rng);
        end_timer!(time);
        Ok(Self::Parameters {
            generators,
            maximum_num_chunks_in_segment,
        })
    }

    fn evaluate(parameters: &Self::Parameters, input: &[u8]) -> Result<Self::Output, Error> {
        let eval_time = start_timer!(|| "BoweHopwoodPedersenCRH::Eval");

        // Preliminary checks
        Self::check_preconditions(parameters)?;

        // Check fixed size input
        if input.len() != N {
            return Err(Box::new(CryptoError::Other(
                format!("incorrect input length {:?} expected {:?}", input.len(), N,).to_owned(),
            )));
        }

        let mut padded_input = Vec::with_capacity(Self::INPUT_SIZE_BITS);
        let input = bytes_to_bits(input);
        // Pad the input if it is not the current length.
        padded_input.extend_from_slice(&input);
        if input.len() % CHUNK_SIZE != 0 {
            let current_length = input.len();
            for _ in 0..(CHUNK_SIZE - current_length % CHUNK_SIZE) {
                padded_input.push(false);
            }
        }

        // Compute sum of h_i^{sum of (1-2*c_{i,j,2})*(1+c_{i,j,0}+2*c_{i,j,1})*2^{4*(j-1)} for all j in segment} for all i.
        // Described in section 5.4.1.7 in the Zcash protocol specification.
        let result = padded_input
            .par_chunks(W::WINDOW_SIZE * CHUNK_SIZE)
            .zip(&parameters.generators)
            .map(|(segment_bits, segment_generators)| {
                segment_bits
                    .par_chunks(CHUNK_SIZE)
                    .zip(segment_generators)
                    .map(|(chunk_bits, generator)| {
                        let mut encoded = generator.clone();
                        if chunk_bits[0] {
                            encoded = encoded + &generator;
                        }
                        if chunk_bits[1] {
                            encoded = encoded + &generator.double();
                        }
                        if chunk_bits[2] {
                            encoded = encoded.neg();
                        }
                        encoded
                    })
                    .reduce(|| G::zero(), |a, b| a + &b)
            })
            .reduce(|| G::zero(), |a, b| a + &b);
        end_timer!(eval_time);

        Ok(result)
    }
}

impl<G: Group> Debug for BoweHopwoodPedersenParameters<G> {
    fn fmt(&self, f: &mut Formatter<'_>) -> FmtResult {
        write!(f, "Bowe-Hopwood Pedersen Hash Parameters {{\n")?;
        for (i, g) in self.generators.iter().enumerate() {
            write!(f, "\t  Generator {}: {:?}\n", i, g)?;
        }
        write!(f, "}}\n")
    }
}

impl<G: Group> BoweHopwoodPedersenParameters<G> {
    pub fn check_consistency(&self) -> bool {
        for (i, p1) in self.generators.iter().enumerate() {
            if p1[0] == G::zero() {
                return false; // infinity generator
            }
            for p2 in self.generators.iter().skip(i + 1) {
                if p1[0] == p2[0] {
                    return false; // duplicate generator
                }
                if p1[0] == p2[0].neg() {
                    return false; // inverse generator
                }
            }
        }
        return true;
    }
}

#[cfg(test)]
mod test {
    use super::*;
    use algebra::{curves::tweedle::dee::Projective as TweedleDee, to_bytes, ToBytes};
    use rand::{thread_rng, SeedableRng};
    use rand_xorshift::XorShiftRng;

    #[derive(Clone)]
    struct TestWindow {}
    impl PedersenWindow for TestWindow {
        const WINDOW_SIZE: usize = 63;
        const NUM_WINDOWS: usize = 2;
    }
    const TEST_CORRECT_INPUT_LENGTH: usize =
        (TestWindow::WINDOW_SIZE * TestWindow::NUM_WINDOWS * CHUNK_SIZE) / 8;

    #[derive(Clone)]
    struct WrongTestWindow {}
    impl PedersenWindow for WrongTestWindow {
        const WINDOW_SIZE: usize = 66;
        const NUM_WINDOWS: usize = 2;
    }
    const TEST_WRONG_INPUT_LENGTH: usize =
        (WrongTestWindow::WINDOW_SIZE * WrongTestWindow::NUM_WINDOWS * CHUNK_SIZE) / 8;

    #[test]
    fn regression() {
        const EXPECTED_MAX_WINDOW_SIZE: usize = 63;
        const EXPECTED_RESULT: &'static str =
         "b800fdf33eb1881fd6a5701b8dbd0a5df435c07b9449245d93818ec53685881692cee6d521d55e55a5817735320d36dba6087cf7b7c24cf2b15270529540350ffd3736e5e20fefe43ad63fcabafcdd6ed93afab4c339e2c72a1202424086ee08";

        let rng = &mut XorShiftRng::seed_from_u64(1234567890u64);
        let params =
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, 3> as FixedLengthCRH>::setup(rng)
                .unwrap();

        assert_eq!(
            params.maximum_num_chunks_in_segment,
            EXPECTED_MAX_WINDOW_SIZE
        );

        assert_eq!(
            hex::encode(
                to_bytes!(
                    <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, 3> as FixedLengthCRH>::evaluate(
                        &params,
                        &[1, 2, 3],
                    ).unwrap()
                )
                .unwrap()
            )
            .as_str(),
            EXPECTED_RESULT
        );
    }

    #[test]
    fn test_wrong_params_in_setup() {
        let rng = &mut thread_rng();

        // Wrong window parameters for given input size
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, WrongTestWindow, TEST_CORRECT_INPUT_LENGTH> as FixedLengthCRH>::setup(rng)
                .unwrap_err()
                .to_string()
                .contains("Bowe-Hopwood hash must have a window size resulting in scalars < (p-1)/2")
        );

        // Wrong input size for given window parameters
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, TEST_WRONG_INPUT_LENGTH> as FixedLengthCRH>::setup(rng)
                .unwrap_err()
                .to_string()
                .contains("window params")
        );
    }

    #[test]
    fn test_wrong_params_in_evaluate() {
        let rng = &mut thread_rng();
        let params =
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, 3> as FixedLengthCRH>::setup(rng)
                .unwrap();

        // Wrong window parameters for given input size
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, WrongTestWindow, TEST_CORRECT_INPUT_LENGTH> as FixedLengthCRH>::evaluate(
                &params,
                &[1u8; TEST_CORRECT_INPUT_LENGTH],
            )
            .unwrap_err()
            .to_string()
            .contains("Bowe-Hopwood hash must have a window size resulting in scalars < (p-1)/2")
        );

        // Wrong input size for given window parameters
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, TEST_WRONG_INPUT_LENGTH> as FixedLengthCRH>::evaluate(
                &params,
                &[1u8; TEST_WRONG_INPUT_LENGTH],
            )
            .unwrap_err()
            .to_string()
            .contains("window params")
        );

        // Wrong number of base generators for given NUM_WINDOWS
        let mut wrong_params = params.clone();
        wrong_params.generators.pop();
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, TEST_CORRECT_INPUT_LENGTH> as FixedLengthCRH>::evaluate(
                &wrong_params,
                &[1u8; TEST_CORRECT_INPUT_LENGTH],
            )
            .unwrap_err()
            .to_string()
            .contains("Incorrect pp of size")
        );

        // Wrong number of generator's power for a given base generator and "WINDOW_SIZE"
        let mut wrong_params = params.clone();
        wrong_params.generators[0].pop();
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, TEST_CORRECT_INPUT_LENGTH> as FixedLengthCRH>::evaluate(
                &wrong_params,
                &[1u8; TEST_CORRECT_INPUT_LENGTH],
            )
            .unwrap_err()
            .to_string()
            .contains("not enough for the selected window size")
        );

        // Input length different from the specified one
        assert!(
            <BoweHopwoodPedersenCRH<TweedleDee, TestWindow, TEST_CORRECT_INPUT_LENGTH> as FixedLengthCRH>::evaluate(
                &params,
                &[1u8; TEST_CORRECT_INPUT_LENGTH - 1],
            )
            .unwrap_err()
            .to_string()
            .contains("incorrect input length")
        );
    }
}
