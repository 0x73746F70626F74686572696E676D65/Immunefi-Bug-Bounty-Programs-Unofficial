use crate::Error;
use rand::Rng;
use std::marker::PhantomData;

use super::{
    pedersen::{PedersenCommitment, PedersenParameters, PedersenRandomness, PedersenWindow},
    CommitmentScheme,
};

pub use crate::crh::injective_map::InjectiveMap;
use algebra::groups::Group;

pub struct PedersenCommCompressor<G: Group, I: InjectiveMap<G>, W: PedersenWindow, const N: usize> {
    _group: PhantomData<G>,
    _compressor: PhantomData<I>,
    _comm: PedersenCommitment<G, W, N>,
}

impl<G: Group, I: InjectiveMap<G>, W: PedersenWindow, const N: usize> CommitmentScheme
    for PedersenCommCompressor<G, I, W, N>
{
    type Output = I::Output;
    type Parameters = PedersenParameters<G>;
    type Randomness = PedersenRandomness<G>;

    fn setup<R: Rng>(rng: &mut R) -> Result<Self::Parameters, Error> {
        let time = start_timer!(|| format!("PedersenCompressor::Setup"));
        let params = PedersenCommitment::<G, W, N>::setup(rng);
        end_timer!(time);
        params
    }

    fn commit(
        parameters: &Self::Parameters,
        input: &[u8],
        randomness: &Self::Randomness,
    ) -> Result<Self::Output, Error> {
        let eval_time = start_timer!(|| "PedersenCompressor::Eval");
        let result = I::injective_map(&PedersenCommitment::<G, W, N>::commit(
            parameters, input, randomness,
        )?)?;
        end_timer!(eval_time);
        Ok(result)
    }
}
