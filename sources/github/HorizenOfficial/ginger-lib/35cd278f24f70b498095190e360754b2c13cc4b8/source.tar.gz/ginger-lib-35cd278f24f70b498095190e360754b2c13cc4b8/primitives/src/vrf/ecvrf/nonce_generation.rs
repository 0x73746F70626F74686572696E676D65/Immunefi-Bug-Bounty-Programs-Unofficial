use super::FieldBasedEcVrf;
use crate::{FieldBasedHash, FixedLengthCRH};
use algebra::{to_bytes, Field, PrimeField, ProjectiveCurve, ToBytes, ToConstraintField};
use hmac::{
    digest::{generic_array::GenericArray, BlockInput, FixedOutput, Input, Reset},
    Hmac, Mac,
};
use sha2::Sha256;

/*
Implementation of HMacDrbg taken from rfc6979 crate, since such crate cannot currently be used as a
dependency due to the version of our Rust toolchain.
This is employed to deterministically generate the nonce needed in VRF proving according to the
algorithm found in RFC6979 (Section 3.2).
*/

struct HmacDrbg<D>
where
    D: Input + BlockInput + FixedOutput + Reset + Default + Clone,
{
    /// HMAC key `K` (see RFC 6979 Section 3.2.c)
    k: Hmac<D>,

    /// Chaining value `V` (see RFC 6979 Section 3.2.c)
    v: GenericArray<u8, D::OutputSize>,
}

impl<D> HmacDrbg<D>
where
    D: Input + BlockInput + FixedOutput + Reset + Default + Clone,
{
    /// Initialize `HMAC_DRBG`
    fn new(entropy_input: &[u8], nonce: &[u8], additional_data: &[u8]) -> Self {
        let mut k = Hmac::new(&Default::default());
        let mut v = GenericArray::default();

        for b in &mut v {
            *b = 0x01;
        }

        for i in 0..=1 {
            k.input(&v);
            k.input(&[i]);
            k.input(entropy_input);
            k.input(nonce);
            k.input(additional_data);
            k = Hmac::new_varkey(&k.result().code()).expect("HMAC error");

            // Steps 3.2.e,g: v = HMAC_k(v)
            k.input(&v);
            v = k.result_reset().code();
        }

        Self { k, v }
    }

    /// Write the next `HMAC_DRBG` output to the given byte slice.
    fn fill_bytes(&mut self, out: &mut [u8]) {
        for out_chunk in out.chunks_mut(self.v.len()) {
            self.k.input(&self.v);
            self.v = self.k.result_reset().code();
            out_chunk.copy_from_slice(&self.v[..out_chunk.len()]);
        }

        self.k.input(&self.v);
        self.k.input(&[0x00]);
        self.k = Hmac::new_varkey(&self.k.result_reset().code()).expect("HMAC error");
        self.k.input(&self.v);
        self.v = self.k.result_reset().code();
    }
}

impl<F, G, FH, GH> FieldBasedEcVrf<F, G, FH, GH>
where
    F: PrimeField,
    G: ProjectiveCurve + ToConstraintField<F>,
    FH: FieldBasedHash<Data = F>,
    GH: FixedLengthCRH<Output = G>,
{
    // Deterministic generation of the nonce employed to generate a VRF prove.
    // The generation is performed according to RFC6979#Section 3.2, taking into account the
    // variant reported in Section 3.6 which allows the usage of additional data
    pub(super) fn generate_nonce(
        secret_key: &G::ScalarField,
        message_hash: G,
        additional_data: &[u8],
    ) -> G::ScalarField {
        let mut hmac = HmacDrbg::<Sha256>::new(
            to_bytes!(secret_key).unwrap().as_slice(),
            to_bytes!(message_hash).unwrap().as_slice(),
            additional_data,
        );

        let mut nonce_bytes = vec![0u8; (F::size_in_bits() + 8 - 1) / 8];
        loop {
            hmac.fill_bytes(nonce_bytes.as_mut_slice());

            let nonce = match G::ScalarField::from_random_bytes(nonce_bytes.as_slice()) {
                Some(nonce) => nonce,
                None => continue,
            };

            // check that the generated nonce is a non-zero field element
            if nonce.is_zero() {
                continue;
            }

            break nonce;
        }
    }
}

#[cfg(test)]
mod test {
    use super::{HmacDrbg, Sha256};

    fn decode_hex(input: &str) -> Vec<u8> {
        (0..input.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&input[i..i + 2], 16).unwrap())
            .collect()
    }

    // Regression test for Hmac_Drbg implementation based on the example reported in RFC6979,
    // Appendix A.1.2
    #[test]
    fn test_hmac_drbg() {
        let entropy_input = decode_hex("009A4D6792295A7F730FC3F2B49CBC0F62E862272F");
        let nonce = decode_hex("01795EDF0D54DB760F156D0DAC04C0322B3A204224");
        let mut hmac = HmacDrbg::<Sha256>::new(entropy_input.as_slice(), nonce.as_slice(), &[]);
        let mut nonce_bytes = vec![0u8; 32];
        let mut compute_next_output = || {
            hmac.fill_bytes(nonce_bytes.as_mut_slice());

            let mut nonce_string = "".to_owned();
            nonce_bytes
                .iter()
                .for_each(|b| nonce_string.push_str(format!("{:02X}", b).as_str()));
            nonce_string
        };
        assert_eq!(
            compute_next_output(),
            "9305A46DE7FF8EB107194DEBD3FD48AA20D5E7656CBE0EA69D2A8D4E7C67314A"
        );
        assert_eq!(
            compute_next_output(),
            "C70C78608A3B5BE9289BE90EF6E81A9E2C1516D5751D2F75F50033E45F73BDEB"
        );
        assert_eq!(
            compute_next_output(),
            "475E80E992140567FCC3A50DAB90FE84BCD7BB03638E9C4656A06F37F6508A7C"
        );
    }
}
