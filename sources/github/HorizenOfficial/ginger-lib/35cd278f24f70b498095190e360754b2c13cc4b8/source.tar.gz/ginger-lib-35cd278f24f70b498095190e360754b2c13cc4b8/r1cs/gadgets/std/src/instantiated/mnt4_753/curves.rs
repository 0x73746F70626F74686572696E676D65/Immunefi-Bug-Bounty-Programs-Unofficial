use crate::groups::mnt::mnt4;
use algebra::curves::mnt4753::MNT4_753Parameters as Parameters;

pub type G1Gadget = mnt4::G1Gadget<Parameters>;
pub type G2Gadget = mnt4::G2Gadget<Parameters>;

pub type G1PreparedGadget = mnt4::G1PreparedGadget<Parameters>;
pub type G2PreparedGadget = mnt4::G2PreparedGadget<Parameters>;

#[test]
fn test() {
    crate::groups::test::group_test_with_incomplete_add::<_, _, G1Gadget>();
    crate::groups::test::group_test_with_incomplete_add::<_, _, G2Gadget>();
    G1Gadget::test_incomplete_double_and_add();
    G2Gadget::test_incomplete_double_and_add();
    crate::groups::test::mul_bits_test::<_, _, G1Gadget>();
    crate::groups::test::mul_bits_test::<_, _, G2Gadget>();
}
