use crate::groups::bn;
use algebra::curves::bn_382::Bn382Parameters;

pub type G1Gadget = bn::G1Gadget<Bn382Parameters>;
pub type G2Gadget = bn::G2Gadget<Bn382Parameters>;

pub type G1PreparedGadget = bn::G1PreparedGadget<Bn382Parameters>;
pub type G2PreparedGadget = bn::G2PreparedGadget<Bn382Parameters>;

#[test]
fn test() {
    crate::groups::test::group_test_with_incomplete_add::<_, _, G1Gadget>();
    crate::groups::test::group_test_with_incomplete_add::<_, _, G2Gadget>();
    G1Gadget::test_incomplete_double_and_add();
    G2Gadget::test_incomplete_double_and_add();
    crate::groups::test::mul_bits_test::<_, _, G1Gadget>();
    crate::groups::test::mul_bits_test::<_, _, G2Gadget>();
}
