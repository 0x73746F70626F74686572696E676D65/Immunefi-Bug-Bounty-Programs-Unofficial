#!/bin/bash
# shellcheck disable=SC2086

set -xeo pipefail

retval=0
cd algebra
cargo $CARGOARGS check || retval="$?"
cargo $CARGOARGS check --all-features --tests || retval="$?"
RUSTFLAGS="-C target-feature=+bmi2,+adx" cargo $CARGOARGS check --all-features --tests || retval="$?"
exit "$retval"
