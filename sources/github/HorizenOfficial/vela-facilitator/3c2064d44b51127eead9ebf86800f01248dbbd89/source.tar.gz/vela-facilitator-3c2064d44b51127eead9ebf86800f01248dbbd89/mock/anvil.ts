import { ChildProcess, spawn } from "child_process";

export interface AnvilInstance {
  rpcUrl: string;
  port: number;
  chainId: number;
  accounts: AnvilAccount[];
  process: ChildProcess;
}

export interface AnvilAccount {
  address: string;
  privateKey: string;
}

// Anvil default pre-funded accounts (deterministic with default mnemonic)
const ANVIL_DEFAULT_ACCOUNTS: AnvilAccount[] = [
  {
    address: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
    privateKey: "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
  },
  {
    address: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
    privateKey: "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d",
  },
  {
    address: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC",
    privateKey: "0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a",
  },
  {
    address: "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
    privateKey: "0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6",
  },
  {
    address: "0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65",
    privateKey: "0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a",
  },
];

export async function startAnvil(port = 8545, chainId = 31337): Promise<AnvilInstance> {
  const rpcUrl = `http://127.0.0.1:${port}`;

  const anvilProcess = spawn(
    "anvil",
    ["--port", String(port), "--chain-id", String(chainId), "--silent"],
    { stdio: ["ignore", "pipe", "pipe"] }
  );

  await waitForReady(rpcUrl);

  return {
    rpcUrl,
    port,
    chainId,
    accounts: ANVIL_DEFAULT_ACCOUNTS,
    process: anvilProcess,
  };
}

export async function stopAnvil(instance: AnvilInstance): Promise<void> {
  instance.process.kill("SIGTERM");
  await new Promise<void>((resolve) => {
    instance.process.once("exit", () => resolve());
    setTimeout(resolve, 2000);
  });
}

export async function waitForReady(rpcUrl: string, timeoutMs = 10000): Promise<void> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(rpcUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method: "eth_chainId", params: [], id: 1 }),
      });
      if (res.ok) return;
    } catch {
      // not ready yet
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(`Anvil not ready at ${rpcUrl} after ${timeoutMs}ms`);
}
