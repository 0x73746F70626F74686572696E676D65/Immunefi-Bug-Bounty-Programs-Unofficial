import { ethers } from "ethers";

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

function getEnv(name: string, defaultValue: string): string {
  return process.env[name] ?? defaultValue;
}

export interface Config {
  rpcUrl: string;
  contractAddress: string;
  signer: ethers.Wallet;
  maxFeeValue: bigint;
  applicationId: bigint;
  port: number;
  velaVersion: string | null;
  explorerBaseUrl: string | null;
  subgraphUrl: string | null;
  appEventPollIntervalMs?: number;
  appEventPollTimeoutMs?: number;
}

export function loadConfig(): Config {
  const rpcProtocol = requireEnv("CHAIN_RPC_PROTOCOL");
  const rpcAddress = requireEnv("CHAIN_RPC_ADDRESS");
  const rpcPort = requireEnv("CHAIN_RPC_PORT");
  const rpcUrl = `${rpcProtocol}://${rpcAddress}:${rpcPort}`;
  const privateKey = requireEnv("FACILITATOR_PRIVATE_KEY");
  const contractAddress = requireEnv("CHAIN_PROCESSOR_ADDRESS");
  const maxFeeValue = BigInt(getEnv("MAX_FEE_VALUE", "50"));
  const applicationId = BigInt(getEnv("VELA_NOVA_APPLICATION_ID", "1"));
  const port = parseInt(getEnv("PORT", "3000"), 10);
  const velaVersion = process.env.FACILITATOR_VELA_VERSION ?? null;
  const explorerBaseUrl = process.env.FACILITATOR_EXPLORER_BASEURL ?? null;
  const subgraphUrl = process.env.AUTHORITY_SERVICE_SUBGRAPH_URL ?? null;
  const appEventPollIntervalMs = process.env.APP_EVENT_POLL_INTERVAL_MS
    ? parseInt(process.env.APP_EVENT_POLL_INTERVAL_MS, 10)
    : undefined;
  const appEventPollTimeoutMs = process.env.APP_EVENT_POLL_TIMEOUT_MS
    ? parseInt(process.env.APP_EVENT_POLL_TIMEOUT_MS, 10)
    : undefined;

  const signer = new ethers.Wallet(privateKey);

  return {
    rpcUrl,
    contractAddress,
    signer,
    maxFeeValue,
    applicationId,
    port,
    velaVersion,
    explorerBaseUrl,
    subgraphUrl,
    appEventPollIntervalMs,
    appEventPollTimeoutMs,
  };
}
