import { fetchBondingCurve, getBondingCurveAddress } from "@orca-so/wavebreak";
import { address, createSolanaRpc, mainnet } from "@solana/kit";

async function main() {
  const rpc = createSolanaRpc(mainnet("https://api.mainnet-beta.solana.com"));

  // This token is picked randomly, there is no relation between this token and Orca.
  const WAVEBREAK_SAMPLE_TOKEN = address("3aSYMRei4BHpprrb9CoysnrxRNhHuw3LNy7sDCKuwave");

  // The address of BondingCurve account is PDA of Wavebreak program
  const [bondingCurveAddress] = await getBondingCurveAddress(WAVEBREAK_SAMPLE_TOKEN);
  console.info("BondingCurve account address:", bondingCurveAddress);

  // Fetch and dump BondingCurve data
  const bondingCurve = await fetchBondingCurve(rpc, bondingCurveAddress);
  if (bondingCurve) {
    const data = bondingCurve.data;

    // drop padding fields and format output
    console.info("BondingCurve data:", {
      baseMint: data.baseMint,
      quoteMint: data.quoteMint,
      creator: data.creator,
      retainMintAuthority: data.retainMintAuthority,
      buyRequiresPermission: data.buyRequiresPermission,
      buyPermissionBitmap: Array.from(data.buyPermissionBitmap).map((b) => b.toString(16).padStart(2, '0')).join(','),
      sellRequiresPermission: data.sellRequiresPermission,
      sellPermissionBitmap: Array.from(data.sellPermissionBitmap).map((b) => b.toString(16).padStart(2, '0')).join(','),
      quoteFeeBps: data.quoteFeeBps,
      baseFeeBps: data.baseFeeBps,
      controlPoints: data.controlPoints,
      startPrice: data.startPrice,
      endPrice: data.endPrice,
      quoteAmount: data.quoteAmount,
      baseAmount: data.baseAmount,
      launchSlot: data.launchSlot,
      creatorReward: data.creatorReward,
      graduationTarget: data.graduationTarget,
      graduationSlot: data.graduationSlot,
      graduationReward: data.graduationReward,
      maxBuyAmount: data.maxBuyAmount,
      maxSellAmount: data.maxSellAmount,
      swapFeeBps: data.swapFeeBps,
      baseAllocationBps: data.baseAllocationBps,
      graduationMethods: data.graduationMethods
      .map((method) => ({
        label: ["none", "whirlpool", "manual"][method.label],
        splitBps: method.splitBps,
        graduated: method.graduated,
        destination: method.destination,
        feeTierIndex: method.feeTierIndex,
        unlocked: method.unlocked,
      }))
      // drop unused method items
      .filter((method) => method.label !== "none"),
      minReserveBps: data.minReserveBps,
      premintedSupply: data.premintedSupply,
    });
  } else {
    console.error("No BondingCurve data found for the given address.");
  }
}

main();

/* SAMPLE OUTPUT

$ npx tsx src/010_bonding_curve_fetch.ts 
BondingCurve account address: vB6cTWtvsBYMvAUsUabTDSVXPw75ZwqZgWNm1uF9swm
BondingCurve data: {
  baseMint: '3aSYMRei4BHpprrb9CoysnrxRNhHuw3LNy7sDCKuwave',
  quoteMint: 'So11111111111111111111111111111111111111112',
  creator: '7ofCenSp7ec4ywtfeNsEoPs9KsoLv1tWmpN4J8wqNo69',
  retainMintAuthority: false,
  buyRequiresPermission: true,
  buyPermissionBitmap: 'ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff',
  sellRequiresPermission: false,
  sellPermissionBitmap: 'ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff,ff',
  quoteFeeBps: 118,
  baseFeeBps: 100,
  controlPoints: [ 4076, 3725, 6969, 6768 ],
  startPrice: 3097735099580089n,
  endPrice: 12157396593351804n,
  quoteAmount: 386356128n,
  baseAmount: 13032825701468596n,
  launchSlot: 356567041n,
  creatorReward: 0n,
  graduationTarget: 85000000000n,
  graduationSlot: 0n,
  graduationReward: 100000000n,
  maxBuyAmount: 10000000000000000n,
  maxSellAmount: 18446744073709551615n,
  swapFeeBps: 100,
  baseAllocationBps: 10000,
  graduationMethods: [
    {
      label: 'whirlpool',
      splitBps: 10000,
      graduated: false,
      destination: '7ofCenSp7ec4ywtfeNsEoPs9KsoLv1tWmpN4J8wqNo69',
      feeTierIndex: 2049,
      unlocked: false
    }
  ],
  minReserveBps: 0,
  premintedSupply: 0n
}

*/
