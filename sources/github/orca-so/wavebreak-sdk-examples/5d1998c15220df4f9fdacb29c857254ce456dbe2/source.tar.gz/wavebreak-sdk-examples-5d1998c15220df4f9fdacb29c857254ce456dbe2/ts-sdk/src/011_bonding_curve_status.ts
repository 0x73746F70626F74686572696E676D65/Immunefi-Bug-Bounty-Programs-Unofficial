import { BondingCurve, circulatingSupply, fetchBondingCurve, getBondingCurveAddress, PriceCurveFacade, sqrtPriceToPrice, tokenPrice } from "@orca-so/wavebreak";
import { address, createSolanaRpc, mainnet } from "@solana/kit";

async function main() {
  const rpc = createSolanaRpc(mainnet("https://api.mainnet-beta.solana.com"));

  // This token is picked randomly, there is no relation between this token and Orca.
  const WAVEBREAK_SAMPLE_TOKEN = address("3aSYMRei4BHpprrb9CoysnrxRNhHuw3LNy7sDCKuwave");

  // The address of BondingCurve account is PDA of Wavebreak program
  const [bondingCurveAddress] = await getBondingCurveAddress(WAVEBREAK_SAMPLE_TOKEN);
  console.info("BondingCurve account address:", bondingCurveAddress);

  // Fetch and dump BondingCurve data
  const bondingCurve = await fetchBondingCurve(rpc, bondingCurveAddress);
  if (!bondingCurve) {
    console.error("No BondingCurve data found for the given address.");
    return;
  }

  const data = bondingCurve.data;
  const priceCurveFacade: PriceCurveFacade = {
    startPrice: data.startPrice,
    endPrice: data.endPrice,
    controlPoints: [data.controlPoints[0], data.controlPoints[1], data.controlPoints[2], data.controlPoints[3]],
  };

  // status
  const currentSlot = await rpc.getSlot().send();
  const status = getBondingCurveStatus(data, currentSlot);
  console.info("BondingCurve status:", status);

  if (status !== "active") {
    console.info("BondingCurve is not active, skipping the further processing.");
    return;
  }

  // quote/base amount info
  const curveQuoteGraduationTarget = data.graduationTarget;
  const curveQuoteCollected = data.quoteAmount;
  const curveQuoteNeedToCollect = curveQuoteGraduationTarget - curveQuoteCollected;
  const curveBaseGraduationEstimate = circulatingSupply(priceCurveFacade, curveQuoteGraduationTarget, curveQuoteGraduationTarget);
  const curveBaseMinted = data.baseAmount;
  const curveBaseWillMint = curveBaseGraduationEstimate - curveBaseMinted;
  console.info("curveQuoteGraduationTarget:", curveQuoteGraduationTarget);
  console.info("curveQuoteCollected:", curveQuoteCollected);
  console.info("curveQuoteNeedToCollect:", curveQuoteNeedToCollect);
  console.info("curveBaseGraduationEstimate:", curveBaseGraduationEstimate);
  console.info("curveBaseMinted:", curveBaseMinted);
  console.info("curveBaseWillMint:", curveBaseWillMint);

  // curve progress info
  const progress = Number(curveQuoteCollected) * 100 / Number(curveQuoteGraduationTarget);
  console.info("BondingCurve progress:", progress.toFixed(2) + "%");

  // price info
  const decimalsBase = (await rpc.getTokenSupply(data.baseMint).send()).value.decimals;
  const decimalsQuote = (await rpc.getTokenSupply(data.quoteMint).send()).value.decimals;

  const startSqrtPrice = data.startPrice;
  const endSqrtPrice = data.endPrice;
  const currentSqrtPrice = tokenPrice(priceCurveFacade, data.quoteAmount, data.graduationTarget);

  const startPrice = sqrtPriceToPrice(startSqrtPrice, decimalsBase, decimalsQuote);
  const endPrice = sqrtPriceToPrice(endSqrtPrice, decimalsBase, decimalsQuote);
  const currentPrice = sqrtPriceToPrice(currentSqrtPrice, decimalsBase, decimalsQuote);

  console.info("curvePrice start  :", startPrice.toFixed(16), `(sqrtPrice: ${startSqrtPrice})`);
  console.info("curvePrice current:", currentPrice.toFixed(16), `(sqrtPrice: ${currentSqrtPrice})`);
  console.info("curvePrice end    :", endPrice.toFixed(16), `(sqrtPrice: ${endSqrtPrice})`);
}

function getBondingCurveStatus(data: BondingCurve, currentSlot: bigint): string {
  if (data.quoteAmount === data.graduationTarget) {
    return "graduation (graduation target reached)";
  }
  
  if (data.graduationSlot > 0n && currentSlot >= data.graduationSlot) {
    if (data.minReserveBps === 0) {
      return "graduation (graduation slot passed)";
    } else if (data.quoteAmount >= data.graduationTarget * BigInt(data.minReserveBps) / 10000n) {
      return "graduation (minimum reserve reached)";
    } else {
      return "expired";
    }
  }

  return "active";
}

main();

/* SAMPLE OUTPUT

$ npx tsx src/011_bonding_curve_status.ts 
BondingCurve account address: vB6cTWtvsBYMvAUsUabTDSVXPw75ZwqZgWNm1uF9swm
BondingCurve status: active
curveQuoteGraduationTarget: 85000000000n
curveQuoteCollected: 386356128n
curveQuoteNeedToCollect: 84613643872n
curveBaseGraduationEstimate: 796845554240999335n
curveBaseMinted: 13032825701468596n
curveBaseWillMint: 783812728539530739n
BondingCurve progress: 0.45%
curvePrice start  : 0.0000000282000000 (sqrtPrice: 3097735099580089)
curvePrice current: 0.0000000296448468 (sqrtPrice: 3176101171501214)
curvePrice end    : 0.0000004343518980 (sqrtPrice: 12157396593351804)

*/
