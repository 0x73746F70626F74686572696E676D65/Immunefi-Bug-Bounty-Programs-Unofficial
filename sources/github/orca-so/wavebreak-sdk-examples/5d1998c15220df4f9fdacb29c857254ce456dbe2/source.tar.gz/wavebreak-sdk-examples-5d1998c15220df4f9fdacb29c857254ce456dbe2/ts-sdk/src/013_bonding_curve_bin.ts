import { curve, fetchBondingCurve, getBondingCurveAddress, PriceCurveFacade, quoteToBaseAmount } from "@orca-so/wavebreak";
import { address, createSolanaRpc, mainnet } from "@solana/kit";

async function main() {
  const rpc = createSolanaRpc(mainnet("https://api.mainnet-beta.solana.com"));

  // This token is picked randomly, there is no relation between this token and Orca.
  const WAVEBREAK_SAMPLE_TOKEN = address("3aSYMRei4BHpprrb9CoysnrxRNhHuw3LNy7sDCKuwave");

  // The address of BondingCurve account is PDA of Wavebreak program
  const [bondingCurveAddress] = await getBondingCurveAddress(WAVEBREAK_SAMPLE_TOKEN);
  console.info("BondingCurve account address:", bondingCurveAddress);

  // Fetch and dump BondingCurve data
  const bondingCurve = await fetchBondingCurve(rpc, bondingCurveAddress);
  if (!bondingCurve) {
    console.error("No BondingCurve data found for the given address.");
    return;
  }

  const data = bondingCurve.data;
  const priceCurveFacade: PriceCurveFacade = {
    startPrice: data.startPrice,
    endPrice: data.endPrice,
    controlPoints: [data.controlPoints[0], data.controlPoints[1], data.controlPoints[2], data.controlPoints[3]],
  };

  // curve shape to discrete bins
  const bins = curve(priceCurveFacade);
  
  let baseAcc = 0n;
  let quoteAcc = 0n;

  // note: # of bin is always 64 (constant), 65th bin (bins[64]) is a sentinel
  for (let i = 0; i < bins.length - 1; i++) {
    const bin = bins[i];
    const nextBin = bins[i + 1];

    // convert from curve to sqrt price & quote amount
    const quoteAmount = transformXToQuoteAmount(bin.x, data.graduationTarget);
    const nextQuoteAmount = transformXToQuoteAmount(nextBin.x, data.graduationTarget);
    const binQuoteAmount = nextQuoteAmount - quoteAmount;

    let sqrtPrice = transformYToSqrtPrice(bin.y, data.startPrice, data.endPrice);
    let nextSqrtPrice = transformYToSqrtPrice(nextBin.y, data.startPrice, data.endPrice);
    let binSqrtPrice = (sqrtPrice + nextSqrtPrice) / 2n; // mid of sqrt prices

    let binBaseAmount = quoteToBaseAmount(binSqrtPrice, binQuoteAmount, false);

    baseAcc += binBaseAmount;
    quoteAcc += binQuoteAmount;

    console.info(`Bin ${i}: x=${bin.x} y=${bin.y} sqrt price=${binSqrtPrice} quote amount=${binQuoteAmount} base amount=${binBaseAmount}`);
  }

  console.info("Total base amount:", baseAcc);
  console.info("Total quote amount:", quoteAcc);
}

function transformXToQuoteAmount(x: number, graduationTarget: bigint): bigint {
  const product = graduationTarget * BigInt(x);
  return (product + 4999n) / 10000n;
}

function transformYToSqrtPrice(y: number, startSqrtPrice: bigint, endSqrtPrice: bigint): bigint {
  const d = endSqrtPrice - startSqrtPrice;
  const delta = d * BigInt(y) / 10000n;
  return startSqrtPrice + delta;
}

main();

/* SAMPLE OUTPUT

$ npx tsx src/013_bonding_curve_bin.ts
BondingCurve account address: vB6cTWtvsBYMvAUsUabTDSVXPw75ZwqZgWNm1uF9swm
Bin 0: x=0 y=0 sqrt price=3176101171501214 quote amount=1606500000 base amount=54191543251009420
Bin 1: x=189 y=173 sqrt price=3332833315343464 quote amount=1606500000 base amount=49214489792013131
Bin 2: x=378 y=346 sqrt price=3489112476111026 quote amount=1581000000 base amount=44191767852059281
Bin 3: x=564 y=518 sqrt price=3644938653803900 quote amount=1581000000 base amount=40494017693923367
Bin 4: x=750 y=690 sqrt price=3799858865347396 quote amount=1555500000 base amount=36658486271747187
Bin 5: x=933 y=860 sqrt price=3953420127666827 quote amount=1547000000 base amount=33680910293100174
Bin 6: x=1115 y=1029 sqrt price=4106528406911569 quote amount=1530000000 base amount=30873169194534961
Bin 7: x=1295 y=1198 sqrt price=4259183703081622 quote amount=1530000000 base amount=28699751191478118
Bin 8: x=1475 y=1366 sqrt price=4410933033102298 quote amount=1504500000 base amount=26313020758671430
Bin 9: x=1652 y=1533 sqrt price=4561323413898909 quote amount=1496000000 base amount=24467483596734794
Bin 10: x=1828 y=1698 sqrt price=4710807828546142 quote amount=1479000000 base amount=22678631419638328
Bin 11: x=2002 y=1863 sqrt price=4860745226268064 quote amount=1479000000 base amount=21301093678912395
Bin 12: x=2176 y=2029 sqrt price=5009776657840608 quote amount=1462000000 base amount=19822119399582229
Bin 13: x=2348 y=2192 sqrt price=5157449140189087 quote amount=1445000000 base amount=18485763148541110
Bin 14: x=2518 y=2355 sqrt price=5304668639462878 quote amount=1436500000 base amount=17371149353615811
Bin 15: x=2687 y=2517 sqrt price=5451435155661980 quote amount=1428000000 base amount=16351061473416147
Bin 16: x=2855 y=2679 sqrt price=5597748688786393 quote amount=1419500000 base amount=15415160399772838
Bin 17: x=3022 y=2840 sqrt price=5742703272686741 quote amount=1402500000 base amount=14471367130327930
Bin 18: x=3187 y=2999 sqrt price=5887204873512399 quote amount=1394000000 base amount=13686232702375534
Bin 19: x=3351 y=3159 sqrt price=6031706474338058 quote amount=1385500000 base amount=12958823571464169
Bin 20: x=3514 y=3318 sqrt price=6175755092089029 quote amount=1377000000 base amount=12285511844855649
Bin 21: x=3676 y=3477 sqrt price=6318897743690622 quote amount=1368500000 base amount=11662766801449377
Bin 22: x=3837 y=3634 sqrt price=6461134429142838 quote amount=1351500000 base amount=11016355469891960
Bin 23: x=3996 y=3791 sqrt price=6603371114595054 quote amount=1360000000 base amount=10613214509107742
Bin 24: x=4156 y=3948 sqrt price=6745154816972581 quote amount=1334500000 base amount=9981002830142221
Bin 25: x=4313 y=4104 sqrt price=6886485536275419 quote amount=1326000000 base amount=9514537665577837
Bin 26: x=4469 y=4260 sqrt price=7026910289428881 quote amount=1326000000 base amount=9138063064842722
Bin 27: x=4625 y=4414 sqrt price=7167335042582343 quote amount=1326000000 base amount=8783499002498129
Bin 28: x=4781 y=4570 sqrt price=7307759795735804 quote amount=1300500000 base amount=8286693463924209
Bin 29: x=4934 y=4724 sqrt price=7446825599665200 quote amount=1300500000 base amount=7980083496503919
Bin 30: x=5087 y=4877 sqrt price=7585891403594596 quote amount=1292000000 base amount=7639918332527503
Bin 31: x=5239 y=5031 sqrt price=7724957207523992 quote amount=1292000000 base amount=7367324412754504
Bin 32: x=5391 y=5184 sqrt price=7863570028378699 quote amount=1283500000 base amount=7063107245242877
Bin 33: x=5542 y=5337 sqrt price=8001729866158718 quote amount=1275000000 base amount=6776132011309296
Bin 34: x=5692 y=5489 sqrt price=8139436720864048 quote amount=1266500000 base amount=6505129352979460
Bin 35: x=5841 y=5641 sqrt price=8277143575569378 quote amount=1266500000 base amount=6290478205803169
Bin 36: x=5990 y=5793 sqrt price=8414397447200019 quote amount=1258000000 base amount=6046082134693324
Bin 37: x=6138 y=5944 sqrt price=8551198335755972 quote amount=1249500000 base amount=5814625470799800
Bin 38: x=6285 y=6095 sqrt price=8687999224311925 quote amount=1241000000 base amount=5594633990027387
Bin 39: x=6431 y=6246 sqrt price=8824800112867878 quote amount=1249500000 base amount=5459664441428848
Bin 40: x=6578 y=6397 sqrt price=8961601001423831 quote amount=1241000000 base amount=5258235328965208
Bin 41: x=6724 y=6548 sqrt price=9097948906905095 quote amount=1232500000 base amount=5066865613715375
Bin 42: x=6869 y=6698 sqrt price=9233843829311671 quote amount=1224000000 base amount=4884901518136575
Bin 43: x=7013 y=6848 sqrt price=9369738751718247 quote amount=1232500000 base amount=4777177838589720
Bin 44: x=7158 y=6998 sqrt price=9505633674124822 quote amount=1224000000 base amount=4609551969556323
Bin 45: x=7302 y=7148 sqrt price=9641075613456709 quote amount=1215500000 base amount=4449830108331977
Bin 46: x=7445 y=7297 sqrt price=9776517552788597 quote amount=1215500000 base amount=4327390023245612
Bin 47: x=7588 y=7447 sqrt price=9912412475195172 quote amount=1215500000 base amount=4209550044952013
Bin 48: x=7731 y=7597 sqrt price=10048307397601748 quote amount=1215500000 base amount=4096458722716748
Bin 49: x=7874 y=7747 sqrt price=10183749336933635 quote amount=1207000000 base amount=3960329428960467
Bin 50: x=8016 y=7896 sqrt price=10318738293190834 quote amount=1207000000 base amount=3857389724957693
Bin 51: x=8158 y=8045 sqrt price=10454633215597409 quote amount=1207000000 base amount=3757760641367280
Bin 52: x=8300 y=8196 sqrt price=10590528138003985 quote amount=1207000000 base amount=3661942141713676
Bin 53: x=8442 y=8345 sqrt price=10725970077335872 quote amount=1198500000 base amount=3544902716416165
Bin 54: x=8583 y=8495 sqrt price=10861412016667759 quote amount=1207000000 base amount=3481562035982300
Bin 55: x=8725 y=8644 sqrt price=10997306939074335 quote amount=1207000000 base amount=3396049579742209
Bin 56: x=8867 y=8795 sqrt price=11133201861480911 quote amount=1198500000 base amount=3290313779665675
Bin 57: x=9008 y=8944 sqrt price=11268643800812798 quote amount=1198500000 base amount=3211694152782290
Bin 58: x=9149 y=9094 sqrt price=11404538723219374 quote amount=1198500000 base amount=3135609958315095
Bin 59: x=9290 y=9244 sqrt price=11541339611775327 quote amount=1207000000 base amount=3083431280186781
Bin 60: x=9432 y=9396 sqrt price=11678140500331280 quote amount=1207000000 base amount=3011614109483851
Bin 61: x=9574 y=9546 sqrt price=11814488405812544 quote amount=1198500000 base amount=2921780878208337
Bin 62: x=9715 y=9697 sqrt price=11950836311293808 quote amount=1207000000 base amount=2875743316574721
Bin 63: x=9857 y=9847 sqrt price=12088090182924450 quote amount=1215500000 base amount=2830603409154957
Total base amount: 796845554240999335n
Total quote amount: 85000000000n

*/
