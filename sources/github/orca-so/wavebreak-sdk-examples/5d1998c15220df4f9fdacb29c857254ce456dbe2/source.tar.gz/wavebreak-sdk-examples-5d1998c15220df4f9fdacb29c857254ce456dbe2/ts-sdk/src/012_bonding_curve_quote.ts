import { exactInBuyQuote, exactInSellQuote, fetchBondingCurve, getBondingCurveAddress, PriceCurveFacade } from "@orca-so/wavebreak";
import { address, createSolanaRpc, mainnet } from "@solana/kit";

async function main() {
  const rpc = createSolanaRpc(mainnet("https://api.mainnet-beta.solana.com"));

  // This token is picked randomly, there is no relation between this token and Orca.
  const WAVEBREAK_SAMPLE_TOKEN = address("3aSYMRei4BHpprrb9CoysnrxRNhHuw3LNy7sDCKuwave");

  // The address of BondingCurve account is PDA of Wavebreak program
  const [bondingCurveAddress] = await getBondingCurveAddress(WAVEBREAK_SAMPLE_TOKEN);
  console.info("BondingCurve account address:", bondingCurveAddress);

  // Fetch and dump BondingCurve data
  const bondingCurve = await fetchBondingCurve(rpc, bondingCurveAddress);
  if (!bondingCurve) {
    console.error("No BondingCurve data found for the given address.");
    return;
  }

  const data = bondingCurve.data;
  const priceCurveFacade: PriceCurveFacade = {
    startPrice: data.startPrice,
    endPrice: data.endPrice,
    controlPoints: [data.controlPoints[0], data.controlPoints[1], data.controlPoints[2], data.controlPoints[3]],
  };

  if (data.quoteAmount === data.graduationTarget) {
    console.info("BondingCurve is in graduation state (graduation target reached).");
    console.info("No trade operations can be performed at this stage.");
    return;
  }

  // ExactIn Buy quote (quote to base)
  const buyInputQuoteTokenAmount = 100_000_000n; // 0.1 SOL
  const buyEstimate = exactInBuyQuote(
    priceCurveFacade,
    buyInputQuoteTokenAmount,
    data.swapFeeBps,
    data.quoteAmount,
    data.graduationTarget,
    data.maxBuyAmount
  );

  console.info("Buy estimate:", buyEstimate);

  // ExactIn Sell quote (base to quote)
  const sellinputBaseTokenAmount = data.baseAmount / 100n; // 1/100 of the current base amount
  const sellEstimate = exactInSellQuote(
    priceCurveFacade,
    sellinputBaseTokenAmount,
    data.swapFeeBps,
    data.quoteAmount,
    data.graduationTarget,
    data.maxSellAmount
  );

  console.info("Sell estimate:", sellEstimate);
}

main();

/* SAMPLE OUTPUT

$ npx tsx src/012_bonding_curve_quote.ts 
BondingCurve account address: vB6cTWtvsBYMvAUsUabTDSVXPw75ZwqZgWNm1uF9swm
Buy estimate: {
  quoteType: { __kind: 'BuyExactIn' },
  amountIn: 100000000n,
  amountOut: 3339534878213465n,
  feeAmount: 1000000n
}
Sell estimate: {
  quoteType: { __kind: 'SellExactIn' },
  amountIn: 130328257014685n,
  amountOut: 3824925n,
  feeAmount: 38636n
}

*/
