# Examples

This repository provides small examples using the Wavebreak TS/Rust SDK.

Each code file includes the output as comments at the end, so you can get a general sense of what it does just by reading the code, even without running it.

## TS SDK
### SDK
`@orca/wavebreak`: https://www.npmjs.com/package/@orca-so/wavebreak

- It works with `@solana/kit` (not `@solana/web3.js`)

### Setup
```
cd ts-sdk
```
```
yarn
```

### Run
Fetch a BondingCurve account and display all of its raw data.
```
npx tsx src/010_bonding_curve_fetch.ts
```

Display calculated information about the BondingCurve state, including price and token amounts.
```
npx tsx src/011_bonding_curve_status.ts
```

Show trade estimates based on the BondingCurve.
```
npx tsx src/012_bonding_curve_quote.ts
```

Display detailed information about the 64 bins underlying the BondingCurve curve.
```
npx tsx src/013_bonding_curve_bin.ts
```

## Rust SDK
### SDK
`orca_wavebreak`: https://crates.io/crates/orca_wavebreak

- It works with solana 2.x libs.

### Setup
```
cd rust-sdk
```

### Run
Fetch a BondingCurve account and display all of its raw data.
```
cargo run --bin 010_bonding_curve_fetch
```

Display calculated information about the BondingCurve state, including price and token amounts.
```
cargo run --bin 011_bonding_curve_status
```

Show trade estimates based on the BondingCurve.
```
cargo run --bin 012_bonding_curve_quote
```

Display detailed information about the 64 bins underlying the BondingCurve curve.
```
cargo run --bin 013_bonding_curve_bin
```

# Supplementary Information

## PDA
### BondingCurve account
```
seeds = [b"bonding_curve", base_mint_address]
```

A BondingCurve account is closed and no longer exists once the target amount has been reached and all required “graduation” processes (e.g. Whirlpool initialization) have been completed.

## BondingCurve Math
You can see the detail of the calculation in `013_bonding_curve_bin` sample script.

Here is some supplementary information to help you understand the operations being performed in the script.

### Bezier curve
The Bonding Curve used by Wavebreak is defined as a cubic Bezier curve with four control points: (x1, y1) and (x2, y2).

It is evaluated at 65 points along the curve to determine the square root price and the amount of quote tokens to be collected.

The SDK provides access to these coordinate values through the `curve` function, so users generally do not need to perform these calculations manually.

![cubic-bezier-curve](cubic-bezier-curve.svg)

### Relationship Between x-Coordinate and Quote Token Amount
The x-coordinate is used to calculate the amount of quote tokens that should be collected up to that point along the curve.

Since the x-coordinate ranges from 0 to 1, it represents a normalized proportion of the total quote tokens to be collected by the time the curve reaches the graduation target.

Therefore, the amount of quote tokens that should have been collected at a given x-coordinate can be expressed with the simple formula:

```
quote_amount(x) = graduation_target * x
```

### Relationship Between y-Coordinate and Sqrt Price
The y-coordinate is used to determine the square root price of the base token at a given point on the curve.

It also ranges from 0 to 1, where a y-value of 0 corresponds to the start sqrt price, and a y-value of 1 corresponds to the end sqrt price.

Therefore, the sqrt price at a given y-coordinate can be expressed with the simple formula:
```
sqrt_price(y) = start_sqrt_price + (end_sqrt_price - start_sqrt_price) * y
```

### Implementation: Bezier Curve is Divided into 64 Bins
In the implementation, the Bezier curve is divided into **64 bins** for processing.

Let the 65 evaluated points along the curve be denoted as `(x[i], y[i])` (`i = 0..64`).

For each `bin[i]` (`i = 0..63`), the following two properties are defined:

#### Sqrt Price of Each Bin
The sqrt price for `bin[i]` is defined as the average of the sqrt prices at the endpoints of the bin:

```text
sqrt_price of bin[i] = (sqrt_price(y[i]) + sqrt_price(y[i+1])) / 2
```

#### Quote Tokens Collected in Each Bin
The amount of quote tokens to be collected within `bin[i]` is proportional to the difference in x-coordinates between the bin’s start and end:

```text
quote_amount of bin[i] = quote_amount(x[i+1]) - quote_amount(x[i])
```

In other words, each bin represents a segment of the curve where:

* A specific amount of quote tokens must be collected
* The price is derived from the average of the corresponding y-values (interpreted as sqrt prices)

This bin-based processing enables efficient tracking of token sales and price progression along the bonding curve.
