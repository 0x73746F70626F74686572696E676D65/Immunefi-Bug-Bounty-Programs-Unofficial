import { describe, it, expect } from "vitest";
import bs58 from "bs58";
import { extractOperations } from "./index.js";
import { getDiscriminatorMap, type InstructionKind } from "./discriminator.js";
import { SQUADS_PROGRAM_ID } from "./types.js";
import type { NotificationFilter } from "../filter.js";
import type {
  AccountKeyEntry,
  CompiledInstruction,
  RawTransaction,
} from "../webhook.js";

const NO_FILTER: NotificationFilter = { instructionTypes: [], configTypes: [] };

async function discriminatorBytes(kind: InstructionKind): Promise<Uint8Array> {
  const map = await getDiscriminatorMap();
  for (const [hex, k] of map) {
    if (k !== kind) continue;
    const bytes = new Uint8Array(8);
    for (let i = 0; i < 8; i++) {
      bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    }
    return bytes;
  }
  throw new Error(`unknown kind: ${kind}`);
}

/**
 * Minimum arg bytes for kinds whose decoder reads past the discriminator.
 * Everything else decodes from the discriminator alone, or degrades to a
 * fallback operation.
 */
function argBytesFor(kind: InstructionKind): Uint8Array {
  switch (kind) {
    case "config_transaction_create":
      // Vec<ConfigAction> len = 0, memo = None
      return new Uint8Array([0, 0, 0, 0, 0]);
    case "proposal_create":
      // transaction_index (u64) = 1, draft = false
      return new Uint8Array([1, 0, 0, 0, 0, 0, 0, 0, 0]);
    default:
      return new Uint8Array(0);
  }
}

async function makeSquadsInstruction(
  kind: InstructionKind,
  accountNames: readonly string[],
): Promise<{ instruction: CompiledInstruction; accountKeys: AccountKeyEntry[] }> {
  const accountKeys: AccountKeyEntry[] = [...accountNames];
  const programIdIndex = accountKeys.length;
  accountKeys.push(SQUADS_PROGRAM_ID);

  const disc = await discriminatorBytes(kind);
  const args = argBytesFor(kind);
  const data = new Uint8Array(disc.length + args.length);
  data.set(disc, 0);
  data.set(args, disc.length);

  return {
    instruction: {
      programIdIndex,
      accounts: accountNames.map((_, i) => i),
      data: bs58.encode(data),
    },
    accountKeys,
  };
}

async function makeTx(
  kind: InstructionKind,
  accountNames: readonly string[],
  signature: string,
): Promise<RawTransaction> {
  const { instruction, accountKeys } = await makeSquadsInstruction(
    kind,
    accountNames,
  );
  return {
    // Real Helius raw payloads omit the top-level signature — it lives on the
    // envelope, and extractOperations has to fall back to it.
    slot: 100,
    blockTime: null,
    transaction: {
      message: { accountKeys, instructions: [instruction] },
      signatures: [signature],
    },
    meta: { err: null },
  };
}

describe("extractOperations", () => {
  it("extracts proposal_approve with member and proposal addresses", async () => {
    // proposal_approve accounts: [multisig, member, proposal]
    const tx = await makeTx(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
      "sig123",
    );

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);

    expect(ops).toHaveLength(1);
    expect(ops[0]!.multisig).toBe("multisig1");
    expect(ops[0]!.member).toBe("member1");
    expect(ops[0]!.proposalAddress).toBe("proposal1");
    expect(ops[0]!.transactionAddress).toBeNull();
    expect(ops[0]!.operation.kind).toBe("proposal_approve");
  });

  it("falls back to the envelope signature when the top-level one is absent", async () => {
    const tx = await makeTx(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
      "sig123",
    );
    expect(tx.signature).toBeUndefined();

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);
    expect(ops[0]!.signature).toBe("sig123");
  });

  it("extracts vault_transaction_execute with both correlation addresses", async () => {
    // vault_transaction_execute accounts: [multisig, proposal, transaction, member]
    const tx = await makeTx(
      "vault_transaction_execute",
      ["multisig1", "proposal1", "tx_account1", "executor1"],
      "sig_exec",
    );

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);

    expect(ops).toHaveLength(1);
    expect(ops[0]!.member).toBe("executor1");
    expect(ops[0]!.proposalAddress).toBe("proposal1");
    expect(ops[0]!.transactionAddress).toBe("tx_account1");
  });

  it("extracts a direct config change and attributes it to the config authority", async () => {
    // multisig_add_member accounts: [multisig, configAuthority, payer, system]
    const tx = await makeTx(
      "multisig_add_member",
      ["multisig1", "authority1", "payer1", "system1"],
      "sig_direct",
    );

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);

    expect(ops).toHaveLength(1);
    expect(ops[0]!.member).toBe("authority1");
    expect(ops[0]!.operation.kind).toBe("multisig_add_member");
  });

  it("still reports an operation when arg decoding fails", async () => {
    // No arg bytes supplied, so the Member struct cannot be decoded. The
    // notification must survive with placeholder values rather than vanish.
    const tx = await makeTx(
      "multisig_add_member",
      ["multisig1", "authority1", "payer1", "system1"],
      "sig_fallback",
    );

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);
    const op = ops[0]!.operation;

    expect(op.kind).toBe("multisig_add_member");
    if (op.kind === "multisig_add_member") {
      expect(op.newMember.key).toBe("unknown");
    }
  });

  it("reads account keys given in object form", async () => {
    const { instruction, accountKeys } = await makeSquadsInstruction(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
    );
    const tx: RawTransaction = {
      slot: 100,
      blockTime: null,
      transaction: {
        message: {
          accountKeys: accountKeys.map((k) => ({
            pubkey: k as string,
            signer: false,
            writable: false,
          })),
          instructions: [instruction],
        },
        signatures: ["sig_obj"],
      },
      meta: { err: null },
    };

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);

    expect(ops).toHaveLength(1);
    expect(ops[0]!.member).toBe("member1");
  });

  it("extracts operations from inner instructions", async () => {
    const { instruction, accountKeys } = await makeSquadsInstruction(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
    );
    const tx: RawTransaction = {
      slot: 100,
      blockTime: null,
      transaction: {
        message: { accountKeys, instructions: [] },
        signatures: ["sig_inner"],
      },
      meta: { err: null, innerInstructions: [{ index: 0, instructions: [instruction] }] },
    };

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);

    expect(ops).toHaveLength(1);
    expect(ops[0]!.member).toBe("member1");
  });

  it("skips failed transactions", async () => {
    const tx = await makeTx(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
      "sig_fail",
    );
    const failed: RawTransaction = {
      ...tx,
      meta: { err: { InstructionError: [0, "Custom"] } },
    };

    const ops = await extractOperations([failed], ["multisig1"], NO_FILTER);
    expect(ops).toEqual([]);
  });

  it("ignores multisigs that are not monitored", async () => {
    const tx = await makeTx(
      "proposal_approve",
      ["other_multisig", "member1", "proposal1"],
      "sig_other",
    );

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);
    expect(ops).toEqual([]);
  });

  it("ignores instructions from other programs", async () => {
    const { instruction, accountKeys } = await makeSquadsInstruction(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
    );
    const keys = [...accountKeys];
    keys[instruction.programIdIndex] = "SomeOtherProgram1111111111111111111111111111";

    const tx: RawTransaction = {
      slot: 100,
      blockTime: null,
      transaction: {
        message: { accountKeys: keys, instructions: [instruction] },
        signatures: ["sig_foreign"],
      },
      meta: { err: null },
    };

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);
    expect(ops).toEqual([]);
  });

  it("drops instructions excluded by the instruction type filter", async () => {
    const tx = await makeTx(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
      "sig789",
    );

    const ops = await extractOperations([tx], ["multisig1"], {
      instructionTypes: ["proposal_reject"],
      configTypes: [],
    });

    expect(ops).toEqual([]);
  });

  it("keeps instructions allowed by the instruction type filter", async () => {
    const tx = await makeTx(
      "proposal_approve",
      ["multisig1", "member1", "proposal1"],
      "sig_allowed",
    );

    const ops = await extractOperations([tx], ["multisig1"], {
      instructionTypes: ["proposal_approve", "proposal_reject"],
      configTypes: [],
    });

    expect(ops).toHaveLength(1);
  });

  it("returns an empty list for an empty payload", async () => {
    expect(await extractOperations([], ["multisig1"], NO_FILTER)).toEqual([]);
  });

  // Approve and execute are routinely bundled into one transaction. Extraction
  // returns both; the signature-keyed dedup in handleWebhook is what discards
  // the second one, so the loss is downstream of here.
  it("returns every operation in a transaction carrying several instructions", async () => {
    const approve = await makeSquadsInstruction("proposal_approve", [
      "multisig1",
      "member1",
      "proposal1",
    ]);
    const execute = await makeSquadsInstruction("vault_transaction_execute", [
      "multisig1",
      "proposal1",
      "tx_account1",
      "member1",
    ]);

    // Re-index the second instruction onto a shared account key table.
    const accountKeys = [...approve.accountKeys];
    const offset = accountKeys.length;
    accountKeys.push(...execute.accountKeys);

    const tx: RawTransaction = {
      slot: 100,
      blockTime: null,
      transaction: {
        message: {
          accountKeys,
          instructions: [
            approve.instruction,
            {
              ...execute.instruction,
              programIdIndex: execute.instruction.programIdIndex + offset,
              accounts: execute.instruction.accounts.map((i) => i + offset),
            },
          ],
        },
        signatures: ["sig_bundled"],
      },
      meta: { err: null },
    };

    const ops = await extractOperations([tx], ["multisig1"], NO_FILTER);

    expect(ops).toHaveLength(2);
    expect(ops.map((o) => o.operation.kind)).toEqual([
      "proposal_approve",
      "vault_transaction_execute",
    ]);
    expect(ops.every((o) => o.signature === "sig_bundled")).toBe(true);
  });
});
