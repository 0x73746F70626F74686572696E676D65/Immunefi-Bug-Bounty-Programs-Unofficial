import { describe, it, expect } from "vitest";
import { loadConfig, resolveWebhookUrl, type Env } from "./config.js";

const DEFAULT_SLACK = "https://hooks.slack.com/services/T000/B000/default";
const OTHER_SLACK = "https://hooks.slack.com/services/T111/B111/other";

function minimalEnv(overrides: Partial<Env> = {}): Env {
  return {
    MULTISIG_ADDRESSES: "addr1,addr2",
    HELIUS_AUTH_TOKEN: "token123",
    SLACK_WEBHOOK_URL: DEFAULT_SLACK,
    ...overrides,
  };
}

describe("loadConfig", () => {
  it("loads a minimal config with defaults", () => {
    const config = loadConfig(minimalEnv());

    expect(config.multisigAddresses).toEqual(["addr1", "addr2"]);
    expect(config.heliusAuthToken).toBe("token123");
    expect(config.slackWebhookUrl).toBe(DEFAULT_SLACK);
    expect(config.logLevel).toBe("error");
    expect(config.display.showPermissions).toBe(false);
    expect(config.display.showTimestamps).toBe(false);
    expect(config.display.truncateAddresses).toBe(false);
    expect(config.routes.size).toBe(0);
  });

  it("reads optional display, log level, and routing fields", () => {
    const config = loadConfig(
      minimalEnv({
        MULTISIG_ADDRESSES: "addr1",
        SHOW_PERMISSIONS: "true",
        SHOW_TIMESTAMPS: "true",
        LOG_LEVEL: "debug",
        MULTISIG_ROUTES: `addr1:${OTHER_SLACK}`,
      }),
    );

    expect(config.display.showPermissions).toBe(true);
    expect(config.display.showTimestamps).toBe(true);
    expect(config.logLevel).toBe("debug");
    expect(resolveWebhookUrl(config, "addr1")).toBe(OTHER_SLACK);
    expect(resolveWebhookUrl(config, "unknown")).toBe(DEFAULT_SLACK);
  });

  it("trims whitespace around multisig addresses", () => {
    const config = loadConfig(
      minimalEnv({ MULTISIG_ADDRESSES: " addr1 , addr2 ,, addr3 " }),
    );
    expect(config.multisigAddresses).toEqual(["addr1", "addr2", "addr3"]);
  });

  it("falls back to the error log level for an unrecognized value", () => {
    const config = loadConfig(minimalEnv({ LOG_LEVEL: "verbose" }));
    expect(config.logLevel).toBe("error");
  });

  it("treats any non-'true' boolean value as false", () => {
    const config = loadConfig(
      minimalEnv({ SHOW_PERMISSIONS: "1", SHOW_TIMESTAMPS: "yes" }),
    );
    expect(config.display.showPermissions).toBe(false);
    expect(config.display.showTimestamps).toBe(false);
  });

  it("throws when a required field is missing", () => {
    expect(() => loadConfig({ MULTISIG_ADDRESSES: "addr1" })).toThrow(
      /HELIUS_AUTH_TOKEN/,
    );
  });

  it("throws when SLACK_WEBHOOK_URL is missing", () => {
    expect(() =>
      loadConfig({ MULTISIG_ADDRESSES: "addr1", HELIUS_AUTH_TOKEN: "tok" }),
    ).toThrow(/SLACK_WEBHOOK_URL/);
  });

  it("throws when MULTISIG_ADDRESSES is empty", () => {
    expect(() => loadConfig(minimalEnv({ MULTISIG_ADDRESSES: "" }))).toThrow(
      /MULTISIG_ADDRESSES is required/,
    );
  });

  it("rejects an unknown instruction type", () => {
    expect(() =>
      loadConfig(minimalEnv({ INSTRUCTION_TYPES: "proposal_approve,nonsense" })),
    ).toThrow(/unknown instruction type 'nonsense'/);
  });
});

describe("MULTISIG_ROUTES parsing", () => {
  function routesFor(raw: string) {
    return loadConfig(minimalEnv({ MULTISIG_ROUTES: raw })).routes;
  }

  it("parses multiple address:url pairs", () => {
    const routes = routesFor("addr1:url1,addr2:url2");
    expect(routes.size).toBe(2);
    expect(routes.get("addr1")).toBe("url1");
    expect(routes.get("addr2")).toBe("url2");
  });

  it("yields no routes when unset", () => {
    expect(routesFor("").size).toBe(0);
  });

  it("skips malformed entries", () => {
    const routes = routesFor("good:url,,bad,:also_bad,ok:fine");
    expect(routes.size).toBe(2);
    expect(routes.get("good")).toBe("url");
    expect(routes.get("ok")).toBe("fine");
  });

  // Routes split on the *first* colon only — otherwise the "https:" scheme
  // separator would truncate every webhook URL.
  it("preserves the scheme colon in full webhook URLs", () => {
    const routes = routesFor(`addrA:${DEFAULT_SLACK},addrB:${OTHER_SLACK}`);
    expect(routes.size).toBe(2);
    expect(routes.get("addrA")).toBe(DEFAULT_SLACK);
    expect(routes.get("addrB")).toBe(OTHER_SLACK);
  });

  it("falls back to SLACK_WEBHOOK_URL for unrouted multisigs", () => {
    const config = loadConfig(minimalEnv());
    expect(resolveWebhookUrl(config, "nonexistent")).toBe(DEFAULT_SLACK);
  });
});
