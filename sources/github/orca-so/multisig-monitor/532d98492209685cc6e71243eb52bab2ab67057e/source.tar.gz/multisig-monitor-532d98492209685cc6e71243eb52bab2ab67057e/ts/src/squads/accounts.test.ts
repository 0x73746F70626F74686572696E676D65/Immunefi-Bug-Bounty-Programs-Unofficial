import { describe, it, expect } from "vitest";
import { layoutFor, resolvePubkey } from "./accounts.js";
import { ANCHOR_NAMES, type InstructionKind } from "./discriminator.js";

const ALL_KINDS = Object.keys(ANCHOR_NAMES) as InstructionKind[];

describe("resolvePubkey", () => {
  it("resolves a key by its position in the instruction account list", () => {
    const accountKeys = ["multisig111", "member222", "proposal333"];
    const instructionAccounts = [0, 1, 2];

    expect(resolvePubkey(instructionAccounts, accountKeys, 0)).toBe("multisig111");
    expect(resolvePubkey(instructionAccounts, accountKeys, 1)).toBe("member222");
    expect(resolvePubkey(instructionAccounts, accountKeys, 2)).toBe("proposal333");
  });

  it("follows indirection rather than indexing accountKeys directly", () => {
    // Instruction references accountKeys out of order: position 0 -> key index 2.
    const accountKeys = ["payer", "system", "multisig111"];
    expect(resolvePubkey([2, 0], accountKeys, 0)).toBe("multisig111");
    expect(resolvePubkey([2, 0], accountKeys, 1)).toBe("payer");
  });

  it("returns null when the referenced key index is out of bounds", () => {
    expect(resolvePubkey([0, 5], ["only_one"], 1)).toBeNull();
  });

  it("returns null when the position exceeds the instruction account list", () => {
    expect(resolvePubkey([0], ["only_one"], 3)).toBeNull();
  });
});

describe("layoutFor", () => {
  // A missing switch case would return undefined and take down instruction
  // processing for that kind — with no error surfaced anywhere.
  it("returns a layout for every instruction kind", () => {
    for (const kind of ALL_KINDS) {
      const layout = layoutFor(kind);
      expect(layout, kind).toBeDefined();
      expect(layout.multisigIndex, kind).toBeTypeOf("number");
      expect(layout.memberIndex, kind).toBeTypeOf("number");
    }
  });

  it("never points the multisig and member at the same account", () => {
    for (const kind of ALL_KINDS) {
      const layout = layoutFor(kind);
      expect(layout.multisigIndex, kind).not.toBe(layout.memberIndex);
    }
  });

  it("maps the execution instructions to their documented positions", () => {
    expect(layoutFor("vault_transaction_execute")).toEqual({
      multisigIndex: 0,
      memberIndex: 3,
      transactionIndex: 2,
      proposalIndex: 1,
    });
    expect(layoutFor("config_transaction_execute")).toEqual({
      multisigIndex: 0,
      memberIndex: 1,
      transactionIndex: 3,
      proposalIndex: 2,
    });
  });
});
