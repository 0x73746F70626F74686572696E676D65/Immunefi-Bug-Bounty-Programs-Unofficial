import { describe, it, expect } from "vitest";
import { dedupeOperations } from "./handler.js";
import type { DetectedOperation } from "./squads/index.js";
import type { SquadsOperation } from "./squads/types.js";

function op(
  overrides: Partial<DetectedOperation> & { operation: SquadsOperation },
): DetectedOperation {
  return {
    signature: "sig1",
    multisig: "multisig1",
    member: "member1",
    transactionAddress: null,
    proposalAddress: null,
    blockTime: null,
    ...overrides,
  };
}

describe("dedupeOperations", () => {
  it("collapses a transaction Helius delivered twice in one batch", () => {
    const duplicate = op({
      operation: { kind: "proposal_approve" },
      proposalAddress: "proposal1",
    });

    expect(dedupeOperations([duplicate, { ...duplicate }])).toHaveLength(1);
  });

  // Squads bundles approve and execute into one transaction routinely. Keying
  // dedup on the signature alone silently dropped the execution notification.
  it("keeps every distinct operation sharing a transaction signature", () => {
    const approve = op({
      operation: { kind: "proposal_approve" },
      proposalAddress: "proposal1",
    });
    const execute = op({
      operation: { kind: "vault_transaction_execute" },
      proposalAddress: "proposal1",
      transactionAddress: "tx1",
    });

    const result = dedupeOperations([approve, execute]);

    expect(result).toHaveLength(2);
    expect(result.map((o) => o.operation.kind)).toEqual([
      "proposal_approve",
      "vault_transaction_execute",
    ]);
  });

  it("keeps votes from different members in the same transaction", () => {
    const base = {
      operation: { kind: "proposal_approve" } as SquadsOperation,
      proposalAddress: "proposal1",
    };

    const result = dedupeOperations([
      op({ ...base, member: "member1" }),
      op({ ...base, member: "member2" }),
    ]);

    expect(result).toHaveLength(2);
  });

  it("keeps the same operation kind against different proposals", () => {
    const base = { operation: { kind: "proposal_approve" } as SquadsOperation };

    const result = dedupeOperations([
      op({ ...base, proposalAddress: "proposal1" }),
      op({ ...base, proposalAddress: "proposal2" }),
    ]);

    expect(result).toHaveLength(2);
  });

  it("treats identical operations in different transactions as distinct", () => {
    const base = {
      operation: { kind: "proposal_approve" } as SquadsOperation,
      proposalAddress: "proposal1",
    };

    const result = dedupeOperations([
      op({ ...base, signature: "sigA" }),
      op({ ...base, signature: "sigB" }),
    ]);

    expect(result).toHaveLength(2);
  });

  it("preserves input order", () => {
    const result = dedupeOperations([
      op({ signature: "sigA", operation: { kind: "proposal_create", draft: false } }),
      op({ signature: "sigB", operation: { kind: "proposal_activate" } }),
      op({ signature: "sigA", operation: { kind: "proposal_create", draft: false } }),
      op({ signature: "sigC", operation: { kind: "proposal_approve" } }),
    ]);

    expect(result.map((o) => o.signature)).toEqual(["sigA", "sigB", "sigC"]);
  });

  it("returns an empty list unchanged", () => {
    expect(dedupeOperations([])).toEqual([]);
  });
});
