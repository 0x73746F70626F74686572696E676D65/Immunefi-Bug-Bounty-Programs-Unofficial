# @orca-so/whirlpools-docs-rust

## 1.0.1

## 1.0.0

## 0.3.1

### Patch Changes

- [#1266](https://github.com/orca-so/whirlpools/pull/1266) [`be8bd95`](https://github.com/orca-so/whirlpools/commit/be8bd9581705f75db31d2e589e69f84ee785fafb) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Remove unchecked index access in ts-sdk, update package lockfiles based on version bumps

## 0.3.0

## 0.2.9

## 0.2.8

## 0.2.7

### Patch Changes

- [#1162](https://github.com/orca-so/whirlpools/pull/1162) [`14c5655`](https://github.com/orca-so/whirlpools/commit/14c5655b664b1a7484b5a630ed65c7b13965ab5e) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Update solana rust dependencies from v2 to v3. Fix some compilation warnings.

## 0.2.6

### Patch Changes

- [#1142](https://github.com/orca-so/whirlpools/pull/1142) [`3edef23`](https://github.com/orca-so/whirlpools/commit/3edef232f5e688082e6780a129689ef94d44d278) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Update to Anchor 0.32.1

## 0.2.5

### Patch Changes

- [#1073](https://github.com/orca-so/whirlpools/pull/1073) [`634b06a`](https://github.com/orca-so/whirlpools/commit/634b06a2ca81253ca6f12995ad0f0741c5e59839) Thanks [@calintje](https://github.com/calintje)! - chore: commit Codama-generated clients and wire Nx generate targets. Centralize Codama versions via root resolutions.

## 0.2.4

## 0.2.3

## 0.2.2

## 0.2.1

## 0.2.0

## 0.1.7

## 0.1.6

### Patch Changes

- [#884](https://github.com/orca-so/whirlpools/pull/884) [`6cd51d6`](https://github.com/orca-so/whirlpools/commit/6cd51d64de8fe0f310c1bf2f3a5e659a68c426d0) Thanks [@calintje](https://github.com/calintje)! - Updated cargo.lock

## 0.1.5

## 0.1.4

## 0.1.3

## 0.1.2

### Patch Changes

- [#751](https://github.com/orca-so/whirlpools/pull/751) [`6119f80`](https://github.com/orca-so/whirlpools/commit/6119f8006e10d49f0dffa7d0dd7d8d8b2cc079cf) Thanks [@calintje](https://github.com/calintje)! - Update documentation for Rust SDK compatibility with Solana SDK v2

## 0.1.1

### Patch Changes

- [#679](https://github.com/orca-so/whirlpools/pull/679) [`a685353`](https://github.com/orca-so/whirlpools/commit/a68535343396e425e05d65fa9e319dc34b4ace0e) Thanks [@calintje](https://github.com/calintje)! - Updated the Solana SDK compatibility version for Rust SDKs.

- [#680](https://github.com/orca-so/whirlpools/pull/680) [`bc70bfb`](https://github.com/orca-so/whirlpools/commit/bc70bfb40068bb13282a92a7b36f501429470b27) Thanks [@wjthieme](https://github.com/wjthieme)! - Initial changeset version
