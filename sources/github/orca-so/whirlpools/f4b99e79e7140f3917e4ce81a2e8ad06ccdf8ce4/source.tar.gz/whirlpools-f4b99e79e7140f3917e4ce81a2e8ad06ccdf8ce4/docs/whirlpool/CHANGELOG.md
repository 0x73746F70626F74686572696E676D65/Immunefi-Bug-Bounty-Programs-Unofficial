# @orca-so/whirlpools-docs

## 1.0.1

### Patch Changes

- [#1315](https://github.com/orca-so/whirlpools/pull/1315) [`b2fabd3`](https://github.com/orca-so/whirlpools/commit/b2fabd377c7f06f62fd546e49a0320b638e4d4fd) Thanks [@crnorthc](https://github.com/crnorthc)! - Restructure the docs site to a reference-only landing page that links to the TypeScript (Kit and Legacy) and Rust SDK API references, with the prose guides now hosted in Mintlify. The site is served from the default GitHub Pages domain (orca-so.github.io/whirlpools) instead of dev.orca.so.

- [#1318](https://github.com/orca-so/whirlpools/pull/1318) [`2fb6efd`](https://github.com/orca-so/whirlpools/commit/2fb6efda1f052c511d6d9fd3f8a768f47f88492f) Thanks [@crnorthc](https://github.com/crnorthc)! - Fix the docs deploy step failing in CI. The version probe in `scripts/deploy-docs` aborted under `set -eo pipefail` when grep found no match, and the `<meta itemprop="version">` tag was no longer reaching the served HTML. The tag is now emitted via `<Head>` and the probe tolerates a missing match.

## 1.0.0

### Major Changes

- [#1306](https://github.com/orca-so/whirlpools/pull/1306) [`f6d9b9e`](https://github.com/orca-so/whirlpools/commit/f6d9b9e11690dca446082b94b943fcfe1b280a1a) Thanks [@crnorthc](https://github.com/crnorthc)! - Update the docs to reflect changes to the TypeScript and Rust SDKs made when updating extensibility for immutable whirlpools.

### Patch Changes

- [#1300](https://github.com/orca-so/whirlpools/pull/1300) [`b7b964c`](https://github.com/orca-so/whirlpools/commit/b7b964c29c0d3ba963e4e132662028f802089c04) Thanks [@yugure-orca](https://github.com/yugure-orca)! - Added new token extensions and v2 instructions

## 0.3.1

## 0.3.0

### Minor Changes

- [#1247](https://github.com/orca-so/whirlpools/pull/1247) [`0324ac8`](https://github.com/orca-so/whirlpools/commit/0324ac8f1658c201e73abace077f734a38b9dcb7) Thanks [@josh-orca](https://github.com/josh-orca)! - Refactors the increase-liquidity API in both TypeScript and Rust SDKs to use token maximum amounts. Both SDKs now require specifying `tokenMaxA` and `tokenMaxB` — the program adds the maximum liquidity achievable within those limits.

  ## Breaking changes

  ### TypeScript SDK (`@orca-so/whirlpools`)

  The increase-liquidity and open-position functions now take `tokenMaxAmounts: { tokenMaxA, tokenMaxB }` instead of a param object with `liquidity`, `tokenA`, or `tokenB`. The return value no longer includes a `quote` — callers must compute quotes separately if needed.

  ```ts
  // Before
  { liquidity: 10_000n }
  { tokenA: 1_000_000n }
  { tokenB: 1_000_000n }
  // Returned: { quote, instructions, ... }

  // After
  { tokenMaxA: 1_000_000n, tokenMaxB: 1_000_000n }
  // One-sided: { tokenMaxA: 1_000_000n, tokenMaxB: 0n } or { tokenMaxA: 0n, tokenMaxB: 1_000_000n }
  // Returned: { instructions } (no quote)
  ```

  ### Rust SDK (`@orca-so/whirlpools-rust`)

  `IncreaseLiquidityParam` has been removed and replaced with `IncreaseLiquidityTokenMaxAmounts`, a struct constructed via `IncreaseLiquidityTokenMaxAmounts::new(token_max_a, token_max_b)`. The increase-liquidity and open-position functions no longer return a quote.

  ```rust
  // Before
  IncreaseLiquidityParam::Liquidity(amount)
  IncreaseLiquidityParam::TokenA(amount)
  IncreaseLiquidityParam::TokenB(amount)
  // Returned: IncreaseLiquidityInstruction { quote, instructions, ... }

  // After
  IncreaseLiquidityTokenMaxAmounts::new(1_000_000, 1_000_000)
  // One-sided: IncreaseLiquidityTokenMaxAmounts::new(1_000_000, 0) or ::new(0, 1_000_000)
  // Returned: IncreaseLiquidityInstruction { instructions, additional_signers } (no quote)
  ```

## 0.2.9

### Patch Changes

- [#1211](https://github.com/orca-so/whirlpools/pull/1211) [`966d952`](https://github.com/orca-so/whirlpools/commit/966d952110016d6e3eb72590f47ac4d64a5af13d) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Update tx-sender version in example, fix formatting issue

## 0.2.8

### Patch Changes

- [#1201](https://github.com/orca-so/whirlpools/pull/1201) [`cdac31a`](https://github.com/orca-so/whirlpools/commit/cdac31ab3b2f0a53d303e7beda1144bb09e48e37) Thanks [@amanmunda-collab](https://github.com/amanmunda-collab)! - fixed the wrong imports for setRpc, setPayerFromBytes which are from @orca-so/whirlpools

## 0.2.7

## 0.2.6

### Patch Changes

- [#1153](https://github.com/orca-so/whirlpools/pull/1153) [`3c0f9a2`](https://github.com/orca-so/whirlpools/commit/3c0f9a228608b3670440eb67e2d41e18608aa4ac) Thanks [@calintje](https://github.com/calintje)! - Update protocol fees

- [#1110](https://github.com/orca-so/whirlpools/pull/1110) [`5d59eef`](https://github.com/orca-so/whirlpools/commit/5d59eef6b86337546b31dfe725cd00914798ff65) Thanks [@rohaan-sahu](https://github.com/rohaan-sahu)! - Fix trade example

- [#1142](https://github.com/orca-so/whirlpools/pull/1142) [`3edef23`](https://github.com/orca-so/whirlpools/commit/3edef232f5e688082e6780a129689ef94d44d278) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Update to Anchor 0.32.1

## 0.2.5

## 0.2.4

### Patch Changes

- [#1019](https://github.com/orca-so/whirlpools/pull/1019) [`0bff540`](https://github.com/orca-so/whirlpools/commit/0bff540ccb93df71264a158fe88a81fa4b62aa61) Thanks [@wanasim](https://github.com/wanasim)! - Fix typo

## 0.2.3

### Patch Changes

- [#956](https://github.com/orca-so/whirlpools/pull/956) [`1a751ba`](https://github.com/orca-so/whirlpools/commit/1a751ba4d059ab6b3ab6ecb9188e17e26bbd6894) Thanks [@odcheung](https://github.com/odcheung)! - Changing the API docs to point to https://api.orca.so/docs

## 0.2.2

### Patch Changes

- [#945](https://github.com/orca-so/whirlpools/pull/945) [`6bdbd68`](https://github.com/orca-so/whirlpools/commit/6bdbd68b436df06906e0a5b8cb017aac2c63f0de) Thanks [@SergZen](https://github.com/SergZen)! - Documentation update only. No release required.

## 0.2.1

### Patch Changes

- [#921](https://github.com/orca-so/whirlpools/pull/921) [`356d585`](https://github.com/orca-so/whirlpools/commit/356d5858fa45e6a13dd6d2b9f032550357748ef8) Thanks [@calintje](https://github.com/calintje)! - Fix 'action' examples. Add additional_signers handling to Rust examples.

## 0.2.0

### Minor Changes

- [#915](https://github.com/orca-so/whirlpools/pull/915) [`3ed21c5`](https://github.com/orca-so/whirlpools/commit/3ed21c5ac1a6e74c89ec995f8d32cea565163c52) Thanks [@calintje](https://github.com/calintje)! - Add Adaptive Fees math explainer. Fix basic usage reference examples for `kit`.

## 0.1.7

### Patch Changes

- [#892](https://github.com/orca-so/whirlpools/pull/892) [`22c9d4a`](https://github.com/orca-so/whirlpools/commit/22c9d4ac415af4a43c3d53c263e61d70b275e209) Thanks [@calintje](https://github.com/calintje)! - Documentation Reorganization: Unified SDK Documentation

## 0.1.6

## 0.1.5

### Patch Changes

- [#788](https://github.com/orca-so/whirlpools/pull/788) [`7d2f507`](https://github.com/orca-so/whirlpools/commit/7d2f507081398973e712390281df535b3fc8988c) Thanks [@wjthieme](https://github.com/wjthieme)! - Switch from @solana/web3.js v2 to @solana/kit

## 0.1.4

### Patch Changes

- [#767](https://github.com/orca-so/whirlpools/pull/767) [`16e070e`](https://github.com/orca-so/whirlpools/commit/16e070e3f7099fcc653c791940d6f40b8472c9b2) Thanks [@wjthieme](https://github.com/wjthieme)! - Update the docs url to dev.orca.so

## 0.1.3

### Patch Changes

- [#759](https://github.com/orca-so/whirlpools/pull/759) [`dfebc3a`](https://github.com/orca-so/whirlpools/commit/dfebc3ad707b6a70430e518930573a307ec6d7b2) Thanks [@calintje](https://github.com/calintje)! - Augment 'Understanding Tick Arrays' doc with SparseSwap information

## 0.1.2

### Patch Changes

- [#751](https://github.com/orca-so/whirlpools/pull/751) [`6119f80`](https://github.com/orca-so/whirlpools/commit/6119f8006e10d49f0dffa7d0dd7d8d8b2cc079cf) Thanks [@calintje](https://github.com/calintje)! - Update documentation for Rust SDK compatibility with Solana SDK v2

## 0.1.1

### Patch Changes

- [#698](https://github.com/orca-so/whirlpools/pull/698) [`117ff89`](https://github.com/orca-so/whirlpools/commit/117ff890cdda74379784b8e7772a6ff868584793) Thanks [@wjthieme](https://github.com/wjthieme)! - Fix a bug where certain pages in typescript docs would return a 404

- [#697](https://github.com/orca-so/whirlpools/pull/697) [`3bcb851`](https://github.com/orca-so/whirlpools/commit/3bcb851f23776f765b2e6222ef0566c6a3123d3c) Thanks [@calintje](https://github.com/calintje)! - Add API link in navbar

- [#679](https://github.com/orca-so/whirlpools/pull/679) [`a685353`](https://github.com/orca-so/whirlpools/commit/a68535343396e425e05d65fa9e319dc34b4ace0e) Thanks [@calintje](https://github.com/calintje)! - Updated Solana SDK version compatibility for Rust SDKs. Updated API docs reference. Fixed a bug causing the Orca logo to appear streched on Safari.

- [#680](https://github.com/orca-so/whirlpools/pull/680) [`bc70bfb`](https://github.com/orca-so/whirlpools/commit/bc70bfb40068bb13282a92a7b36f501429470b27) Thanks [@wjthieme](https://github.com/wjthieme)! - Initial changeset version
