import * as anchor from "@coral-xyz/anchor";
import { web3 } from "@coral-xyz/anchor";
import type { PDA } from "@orca-so/common-sdk";
import { TransactionBuilder } from "@orca-so/common-sdk";
import {
  TOKEN_PROGRAM_ID,
  getAccount,
  getAssociatedTokenAddressSync,
} from "@solana/spl-token";
import { Keypair, PublicKey } from "@solana/web3.js";
import * as assert from "assert";
import type {
  InitPoolParams,
  OpenPositionParams,
  OpenPositionWithMetadataBumpsData,
  PositionData,
  WhirlpoolContext,
} from "../../../src";
import {
  MAX_TICK_INDEX,
  METADATA_PROGRAM_ADDRESS,
  MIN_TICK_INDEX,
  PDAUtil,
  PriceMath,
  TickUtil,
  WhirlpoolIx,
  toTx,
} from "../../../src";
import { openPositionAccounts } from "../../../src/utils/instructions-util";
import {
  ONE_SOL,
  TickSpacing,
  ZERO_BN,
  createMint,
  createMintInstructions,
  mintToDestination,
  systemTransferTx,
  initializeLiteSVMEnvironment,
  SENTINEL_MIN,
  SENTINEL_MAX,
  snapTickDown,
  snapTickUp,
} from "../../utils";
import { TICK_RENT_AMOUNT } from "../../utils/const";
import { initTestPool, openPositionWithMetadata } from "../../utils/init-utils";
import { MetaplexHttpClient } from "../../utils/metaplex";
import { generateDefaultOpenPositionParams } from "../../utils/test-builders";
import { pollForCondition } from "../../utils/litesvm";

describe("open_position_with_metadata", () => {
  let provider: anchor.AnchorProvider;
  let ctx: WhirlpoolContext;
  let fetcher: WhirlpoolContext["fetcher"];

  beforeAll(async () => {
    const env = await initializeLiteSVMEnvironment();
    provider = env.provider;
    ctx = env.ctx;
    fetcher = env.fetcher;
  });

  it("emit PositionOpened event (with_metadata)", async () => {
    const { poolInitInfo } = await initTestPool(ctx, TickSpacing.Standard);
    const { whirlpoolPda } = poolInitInfo;
    const lower = 0;
    const upper = 128;
    const hasEvent =
      Array.isArray(ctx.program.idl?.events) &&
      ctx.program.idl.events.some((e) => e.name === "positionOpened");

    // event verification
    let eventVerified = false;
    let detectedSignature: string | null = null;
    const listener = ctx.program.addEventListener(
      "positionOpened",
      (event, _slot, signature) => {
        detectedSignature = signature;
        // verify
        assert.ok(event.whirlpool.equals(whirlpoolPda.publicKey));
        assert.strictEqual(event.tickLowerIndex, lower);
        assert.strictEqual(event.tickUpperIndex, upper);
        eventVerified = true;
      },
    );

    const { params, txId } = await openPositionWithMetadata(
      ctx,
      whirlpoolPda.publicKey,
      lower,
      upper,
    );

    if (!hasEvent) {
      // IDL not updated yet; accept execution without event assertion.
      ctx.program.removeEventListener(listener);
      return;
    }

    await pollForCondition(
      async () => ({ detectedSignature, eventVerified }),
      (r) => r.detectedSignature === txId && r.eventVerified,
      { maxRetries: 200, delayMs: 5 },
    );
    assert.equal(txId, detectedSignature);
    assert.ok(eventVerified);
    // Ensure position pubkey also matches the event
    // Fetch event via listener context is enough; direct equality check for position key:
    // We cannot access event again here, so do a lightweight state check:
    const pos = (await fetcher.getPosition(
      params.positionPda.publicKey,
    )) as PositionData;
    assert.strictEqual(pos.tickLowerIndex, lower);
    assert.strictEqual(pos.tickUpperIndex, upper);

    ctx.program.removeEventListener(listener);
  });

  const metaplex = new MetaplexHttpClient();

  let defaultParams: Required<OpenPositionParams & { metadataPda: PDA }>;
  let defaultMint: Keypair;
  const tickLowerIndex = 0;
  const tickUpperIndex = 32768;
  let poolInitInfo: InitPoolParams;
  let whirlpoolPda: PDA;
  let fullRangeOnlyPoolInitInfo: InitPoolParams;
  let fullRangeOnlyWhirlpoolPda: PDA;
  const funderKeypair = anchor.web3.Keypair.generate();

  beforeAll(async () => {
    poolInitInfo = (await initTestPool(ctx, TickSpacing.Standard)).poolInitInfo;
    whirlpoolPda = poolInitInfo.whirlpoolPda;

    fullRangeOnlyPoolInitInfo = (
      await initTestPool(ctx, TickSpacing.FullRangeOnly)
    ).poolInitInfo;
    fullRangeOnlyWhirlpoolPda = fullRangeOnlyPoolInitInfo.whirlpoolPda;

    const { params, mint } = await generateDefaultOpenPositionParams(
      ctx,
      whirlpoolPda.publicKey,
      tickLowerIndex,
      tickUpperIndex,
      provider.wallet.publicKey,
    );
    defaultParams = params;
    defaultMint = mint;
    await systemTransferTx(
      provider,
      funderKeypair.publicKey,
      ONE_SOL,
    ).buildAndExecute();
  });

  async function checkMetadata(
    metadataPda: PDA | undefined,
    position: PublicKey,
    positionMint: PublicKey,
  ) {
    assert.ok(metadataPda != null);

    const metadataAccountInfo = await provider.connection.getAccountInfo(
      metadataPda.publicKey,
    );
    assert.ok(metadataAccountInfo !== null);
    const metadata = metaplex.parseOnChainMetadata(
      metadataPda.publicKey,
      metadataAccountInfo!.data,
    );
    assert.ok(metadata !== null);

    assert.ok(
      metadata.updateAuthority.toBase58() ===
        "3axbTs2z5GBy6usVbNVoqEgZMng3vZvMnAoX29BFfwhr",
    );
    assert.ok(metadata.mint.toBase58() === positionMint.toString());

    assert.ok(
      metadata.uri.replace(/\0/g, "") ===
        `https://metadata.orca.so/positions/${position.toBase58()}`,
    );
  }

  it("successfully opens position and verify position address contents", async () => {
    const positionInitInfo = await openPositionWithMetadata(
      ctx,
      whirlpoolPda.publicKey,
      tickLowerIndex,
      tickUpperIndex,
    );
    const { positionPda, metadataPda, positionMintAddress } =
      positionInitInfo.params;
    const position = (await fetcher.getPosition(
      positionPda.publicKey,
    )) as PositionData;

    assert.strictEqual(position.tickLowerIndex, tickLowerIndex);
    assert.strictEqual(position.tickUpperIndex, tickUpperIndex);
    assert.ok(position.whirlpool.equals(poolInitInfo.whirlpoolPda.publicKey));
    assert.ok(position.positionMint.equals(positionMintAddress));
    assert.ok(position.liquidity.eq(ZERO_BN));
    assert.ok(position.feeGrowthCheckpointA.eq(ZERO_BN));
    assert.ok(position.feeGrowthCheckpointB.eq(ZERO_BN));
    assert.ok(position.feeOwedA.eq(ZERO_BN));
    assert.ok(position.feeOwedB.eq(ZERO_BN));

    await checkMetadata(
      metadataPda,
      positionPda.publicKey,
      position.positionMint,
    );
    // TODO: Add tests for rewards
  });

  it("successfully opens position and verify position address contents for full-range only pool", async () => {
    const [lowerTickIndex, upperTickIndex] = TickUtil.getFullRangeTickIndex(
      TickSpacing.FullRangeOnly,
    );

    const positionInitInfo = await openPositionWithMetadata(
      ctx,
      fullRangeOnlyWhirlpoolPda.publicKey,
      lowerTickIndex,
      upperTickIndex,
    );
    const { positionPda, metadataPda, positionMintAddress } =
      positionInitInfo.params;
    const position = (await fetcher.getPosition(
      positionPda.publicKey,
    )) as PositionData;

    assert.strictEqual(position.tickLowerIndex, lowerTickIndex);
    assert.strictEqual(position.tickUpperIndex, upperTickIndex);
    assert.ok(
      position.whirlpool.equals(
        fullRangeOnlyPoolInitInfo.whirlpoolPda.publicKey,
      ),
    );
    assert.ok(position.positionMint.equals(positionMintAddress));
    assert.ok(position.liquidity.eq(ZERO_BN));
    assert.ok(position.feeGrowthCheckpointA.eq(ZERO_BN));
    assert.ok(position.feeGrowthCheckpointB.eq(ZERO_BN));
    assert.ok(position.feeOwedA.eq(ZERO_BN));
    assert.ok(position.feeOwedB.eq(ZERO_BN));

    await checkMetadata(
      metadataPda,
      positionPda.publicKey,
      position.positionMint,
    );
  });

  it("succeeds when funder is different than account paying for transaction fee", async () => {
    const { params } = await openPositionWithMetadata(
      ctx,
      whirlpoolPda.publicKey,
      tickLowerIndex,
      tickUpperIndex,
      provider.wallet.publicKey,
      funderKeypair,
    );

    await checkMetadata(
      params.metadataPda,
      params.positionPda.publicKey,
      params.positionMintAddress,
    );
  });

  it("open position & verify position mint behavior", async () => {
    const newOwner = web3.Keypair.generate();

    const positionInitInfo = await openPositionWithMetadata(
      ctx,
      whirlpoolPda.publicKey,
      tickLowerIndex,
      tickUpperIndex,
      newOwner.publicKey,
    );
    const {
      positionPda,
      metadataPda,
      positionMintAddress,
      positionTokenAccount: positionTokenAccountAddress,
    } = positionInitInfo.params;

    await checkMetadata(
      metadataPda,
      positionPda.publicKey,
      positionMintAddress,
    );

    const userTokenAccount = await getAccount(
      ctx.connection,
      positionTokenAccountAddress,
    );
    assert.ok(userTokenAccount.amount === 1n);
    assert.ok(userTokenAccount.owner.equals(newOwner.publicKey));

    await assert.rejects(
      mintToDestination(
        provider,
        positionMintAddress,
        positionTokenAccountAddress,
        1,
      ),
      /0x5/, // the total supply of this token is fixed
    );
  });

  it("should reserve some rent for tick initialization", async () => {
    const positionInitInfo = await openPositionWithMetadata(
      ctx,
      whirlpoolPda.publicKey,
      tickLowerIndex,
      tickUpperIndex,
      provider.wallet.publicKey,
    );

    const positionPda = positionInitInfo.params.positionPda.publicKey;
    const position = await ctx.connection.getAccountInfo(positionPda);
    assert.ok(position);
    const minRent = await ctx.connection.getMinimumBalanceForRentExemption(
      position.data.length,
    );
    assert.equal(position.lamports, minRent + TICK_RENT_AMOUNT * 2);
  });

  it("user must pass the valid token ATA account", async () => {
    const anotherMintKey = await createMint(
      provider,
      provider.wallet.publicKey,
    );
    const positionTokenAccountAddress = getAssociatedTokenAddressSync(
      anotherMintKey,
      provider.wallet.publicKey,
    );

    await assert.rejects(
      toTx(
        ctx,
        WhirlpoolIx.openPositionWithMetadataIx(ctx.program, {
          ...defaultParams,
          positionTokenAccount: positionTokenAccountAddress,
        }),
      )
        .addSigner(defaultMint)
        .buildAndExecute(),
      /An account required by the instruction is missing/,
    );
  });

  describe("invalid ticks", () => {
    async function assertTicksFail(lowerTick: number, upperTick: number) {
      await assert.rejects(
        openPositionWithMetadata(
          ctx,
          whirlpoolPda.publicKey,
          lowerTick,
          upperTick,
          provider.wallet.publicKey,
          funderKeypair,
        ),
        /0x177a/, // InvalidTickIndex
      );
    }

    it("fail when user pass in an out of bound tick index for upper-index", async () => {
      await assertTicksFail(0, MAX_TICK_INDEX + 1);
    });

    it("fail when user pass in a lower tick index that is higher than the upper-index", async () => {
      await assertTicksFail(-22534, -22534 - 1);
    });

    it("fail when user pass in a lower tick index that equals the upper-index", async () => {
      await assertTicksFail(22365, 22365);
    });

    it("fail when user pass in an out of bound tick index for lower-index", async () => {
      await assertTicksFail(MIN_TICK_INDEX - 1, 0);
    });

    it("fail when user pass in a non-initializable tick index for upper-index", async () => {
      await assertTicksFail(0, 1);
    });

    it("fail when user pass in a non-initializable tick index for lower-index", async () => {
      await assertTicksFail(1, 2);
    });
  });

  it("fail when position mint already exists", async () => {
    const positionMintKeypair = anchor.web3.Keypair.generate();
    const positionPda = PDAUtil.getPosition(
      ctx.program.programId,
      positionMintKeypair.publicKey,
    );
    const metadataPda = PDAUtil.getPositionMetadata(
      positionMintKeypair.publicKey,
    );

    const positionTokenAccountAddress = getAssociatedTokenAddressSync(
      positionMintKeypair.publicKey,
      provider.wallet.publicKey,
    );

    const tx = new web3.Transaction();
    tx.add(
      ...(await createMintInstructions(
        provider,
        provider.wallet.publicKey,
        positionMintKeypair.publicKey,
      )),
    );

    await provider.sendAndConfirm(tx, [positionMintKeypair], {
      commitment: "confirmed",
    });

    await assert.rejects(
      toTx(
        ctx,
        WhirlpoolIx.openPositionWithMetadataIx(ctx.program, {
          ...defaultParams,
          positionPda,
          metadataPda,
          positionMintAddress: positionMintKeypair.publicKey,
          positionTokenAccount: positionTokenAccountAddress,
          whirlpool: whirlpoolPda.publicKey,
          tickLowerIndex,
          tickUpperIndex,
        }),
      )
        .addSigner(positionMintKeypair)
        .buildAndExecute(),
      /0x0/,
    );
  });

  describe("invalid account constraints", () => {
    function buildOpenWithAccountOverrides(
      overrides: Partial<
        ReturnType<typeof openPositionAccounts> & {
          positionMetadataAccount: PublicKey;
          metadataProgram: PublicKey;
          metadataUpdateAuth: PublicKey;
        }
      >,
    ) {
      const { positionPda, metadataPda, tickLowerIndex, tickUpperIndex } =
        defaultParams;

      const bumps: OpenPositionWithMetadataBumpsData = {
        positionBump: positionPda.bump,
        metadataBump: metadataPda.bump,
      };

      const ix = ctx.program.instruction.openPositionWithMetadata(
        bumps,
        tickLowerIndex,
        tickUpperIndex,
        {
          accounts: {
            ...openPositionAccounts(defaultParams),
            positionMetadataAccount: metadataPda.publicKey,
            metadataProgram: METADATA_PROGRAM_ADDRESS,
            metadataUpdateAuth: new PublicKey(
              "3axbTs2z5GBy6usVbNVoqEgZMng3vZvMnAoX29BFfwhr",
            ),
            ...overrides,
          },
        },
      );

      return {
        instructions: [ix],
        cleanupInstructions: [],
        signers: [],
      };
    }

    it("fails with non-mint metadataPda", async () => {
      const notMintKeypair = Keypair.generate();
      const invalidParams = {
        ...defaultParams,
        metadataPda: PDAUtil.getPositionMetadata(notMintKeypair.publicKey),
      };

      await assert.rejects(
        toTx(
          ctx,
          WhirlpoolIx.openPositionWithMetadataIx(ctx.program, invalidParams),
        )
          .addSigner(defaultMint)
          .buildAndExecute(),
        // Invalid Metadata Key
        // https://github.com/metaplex-foundation/mpl-token-metadata/blob/main/programs/token-metadata/program/src/error.rs#L34-L36
        /0x5/,
      );
    });

    it("fails with non-program metadata program", async () => {
      const notMetadataProgram = Keypair.generate();
      const tx = new TransactionBuilder(
        ctx.provider.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      ).addInstruction(
        buildOpenWithAccountOverrides({
          metadataProgram: notMetadataProgram.publicKey,
        }),
      );

      await assert.rejects(
        tx.addSigner(defaultMint).buildAndExecute(),
        // InvalidProgramId
        // https://github.com/coral-xyz/anchor/blob/v0.32.1/lang/src/error.rs#L229-231
        /0xbc0/,
      );
    });

    it("fails with non-metadata program ", async () => {
      const tx = new TransactionBuilder(
        ctx.provider.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      ).addInstruction(
        buildOpenWithAccountOverrides({
          metadataProgram: TOKEN_PROGRAM_ID,
        }),
      );

      await assert.rejects(
        tx.addSigner(defaultMint).buildAndExecute(),
        // InvalidProgramId
        // https://github.com/coral-xyz/anchor/blob/v0.32.1/lang/src/error.rs#L229-L231
        /0xbc0/,
      );
    });

    it("fails with non-valid update_authority program", async () => {
      const notUpdateAuth = Keypair.generate();
      const tx = new TransactionBuilder(
        ctx.provider.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      ).addInstruction(
        buildOpenWithAccountOverrides({
          metadataUpdateAuth: notUpdateAuth.publicKey,
        }),
      );

      await assert.rejects(
        tx.addSigner(defaultMint).buildAndExecute(),
        // ConstraintAddress
        // https://github.com/coral-xyz/anchor/blob/v0.32.1/lang/src/error.rs#L229-231
        /0x7dc/,
      );
    });
  });

  it("fail when opening a non-full range position in an full-range only pool", async () => {
    await assert.rejects(
      openPositionWithMetadata(
        ctx,
        fullRangeOnlyWhirlpoolPda.publicKey,
        tickLowerIndex,
        tickUpperIndex,
        provider.wallet.publicKey,
        funderKeypair,
      ),
      /0x17a6/, // FullRangeOnlyPool
    );
  });

  describe("one-sided (sentinel) open position with metadata", () => {
    it("snaps correctly when current price is exactly on an initializable tick", async () => {
      // Initialize a fresh pool where sqrt price is exactly on tick 0
      const onTickSqrtPrice = PriceMath.tickIndexToSqrtPriceX64(0);
      const { poolInitInfo: onTickPool } = await initTestPool(
        ctx,
        TickSpacing.Standard,
        onTickSqrtPrice,
      );

      const whirlpool = await fetcher.getPool(
        onTickPool.whirlpoolPda.publicKey,
      );
      if (!whirlpool) throw new Error("whirlpool not found");
      const spacing = whirlpool.tickSpacing;
      const curr = whirlpool.tickCurrentIndex;
      // When on-tick, ceil(current) === current and floor(current) === current
      const expectedLower = snapTickUp(curr, spacing);
      const expectedUpper = snapTickDown(curr, spacing);

      // Lower sentinel case
      {
        const upper = expectedLower + spacing;
        const positionInitInfo = await openPositionWithMetadata(
          ctx,
          onTickPool.whirlpoolPda.publicKey,
          SENTINEL_MIN,
          upper,
        );
        const { positionPda } = positionInitInfo.params;
        const position = (await fetcher.getPosition(
          positionPda.publicKey,
        )) as PositionData;
        assert.strictEqual(position.tickLowerIndex, expectedLower);
        assert.strictEqual(position.tickUpperIndex, upper);
      }

      // Upper sentinel case
      {
        const lower = expectedUpper - spacing;
        const positionInitInfo = await openPositionWithMetadata(
          ctx,
          onTickPool.whirlpoolPda.publicKey,
          lower,
          SENTINEL_MAX,
        );
        const { positionPda } = positionInitInfo.params;
        const position = (await fetcher.getPosition(
          positionPda.publicKey,
        )) as PositionData;
        assert.strictEqual(position.tickLowerIndex, lower);
        assert.strictEqual(position.tickUpperIndex, expectedUpper);
      }
    });

    it("snaps lower to ceil(current) when lower sentinel is used", async () => {
      const whirlpool = await fetcher.getPool(whirlpoolPda.publicKey);
      if (!whirlpool) throw new Error("whirlpool not found");
      const spacing = whirlpool.tickSpacing;
      const curr = whirlpool.tickCurrentIndex;
      const expectedLower = snapTickUp(curr, spacing);
      const upper = expectedLower + spacing;

      const positionInitInfo = await openPositionWithMetadata(
        ctx,
        whirlpoolPda.publicKey,
        SENTINEL_MIN,
        upper,
      );
      const { positionPda } = positionInitInfo.params;
      const position = (await fetcher.getPosition(
        positionPda.publicKey,
      )) as PositionData;
      assert.strictEqual(position.tickLowerIndex, expectedLower);
      assert.strictEqual(position.tickUpperIndex, upper);
    });

    it("snaps upper to floor(current) when upper sentinel is used", async () => {
      const whirlpool = await fetcher.getPool(whirlpoolPda.publicKey);
      if (!whirlpool) throw new Error("whirlpool not found");
      const spacing = whirlpool.tickSpacing;
      const curr = whirlpool.tickCurrentIndex;
      const expectedUpper = snapTickDown(curr, spacing);
      const lower = expectedUpper - spacing;

      const positionInitInfo = await openPositionWithMetadata(
        ctx,
        whirlpoolPda.publicKey,
        lower,
        SENTINEL_MAX,
      );
      const { positionPda } = positionInitInfo.params;
      const position = (await fetcher.getPosition(
        positionPda.publicKey,
      )) as PositionData;
      assert.strictEqual(position.tickLowerIndex, lower);
      assert.strictEqual(position.tickUpperIndex, expectedUpper);
    });

    it("fails if both sentinels are used", async () => {
      await assert.rejects(
        openPositionWithMetadata(
          ctx,
          whirlpoolPda.publicKey,
          SENTINEL_MIN,
          SENTINEL_MAX,
        ),
        /0x177a/, // InvalidTickIndex
      );
    });

    it("fails if snapped range collapses (lower >= upper)", async () => {
      const whirlpool = await fetcher.getPool(whirlpoolPda.publicKey);
      if (!whirlpool) throw new Error("whirlpool not found");
      const spacing = whirlpool.tickSpacing;
      const curr = whirlpool.tickCurrentIndex;
      const expectedLower = snapTickUp(curr, spacing);
      const upperEqualsLower = expectedLower;

      await assert.rejects(
        openPositionWithMetadata(
          ctx,
          whirlpoolPda.publicKey,
          SENTINEL_MIN,
          upperEqualsLower,
        ),
        /0x177a/, // InvalidTickIndex
      );
    });
  });
});
