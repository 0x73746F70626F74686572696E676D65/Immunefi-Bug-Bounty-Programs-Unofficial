import * as anchor from "@coral-xyz/anchor";
import { MathUtil, TransactionBuilder, ZERO } from "@orca-so/common-sdk";
import { getAssociatedTokenAddressSync } from "@solana/spl-token";
import { Keypair, SystemProgram } from "@solana/web3.js";
import * as assert from "assert";
import BN from "bn.js";
import Decimal from "decimal.js";
import type { PositionBundleData, WhirlpoolClient } from "../../../src";
import {
  NUM_REWARDS,
  PDAUtil,
  POSITION_BUNDLE_SIZE,
  PoolUtil,
  PriceMath,
  WhirlpoolIx,
  buildWhirlpoolClient,
  collectFeesQuote,
  toTx,
} from "../../../src";
import { WhirlpoolContext } from "../../../src/context";
import { IGNORE_CACHE } from "../../../src/network/public/fetcher";
import { TickSpacing, ZERO_BN, createTokenAccount } from "../../utils";
import {
  warpClock,
  pollForCondition,
  initializeLiteSVMEnvironment,
} from "../../utils/litesvm";
import { WhirlpoolTestFixture } from "../../utils/fixture";
import {
  initializePositionBundle,
  openBundledPosition,
} from "../../utils/init-utils";
import { TokenExtensionUtil } from "../../../src/utils/public/token-extension-util";

interface SharedTestContext {
  provider: anchor.AnchorProvider;
  program: anchor.Program;
  whirlpoolCtx: WhirlpoolContext;
  whirlpoolClient: WhirlpoolClient;
}

describe("bundled position management tests", () => {
  let provider: anchor.AnchorProvider;
  let program: anchor.Program;
  let testCtx: SharedTestContext;
  const tickLowerIndex = 29440;
  const tickUpperIndex = 33536;
  const tickSpacing = TickSpacing.Standard;
  const vaultStartBalance = 1_000_000;
  const liquidityAmount = new BN(10_000_000);

  beforeAll(async () => {
    const env = await initializeLiteSVMEnvironment();
    provider = env.provider;
    program = env.program;

    anchor.setProvider(provider);
    const whirlpoolCtx = WhirlpoolContext.fromWorkspace(provider, program);
    const whirlpoolClient = buildWhirlpoolClient(whirlpoolCtx);

    testCtx = {
      provider,
      program,
      whirlpoolCtx,
      whirlpoolClient,
    };
  });

  function checkBitmapIsOpened(
    account: PositionBundleData,
    bundleIndex: number,
  ): boolean {
    if (bundleIndex < 0 || bundleIndex >= POSITION_BUNDLE_SIZE)
      throw Error("bundleIndex is out of bounds");

    const bitmapIndex = Math.floor(bundleIndex / 8);
    const bitmapOffset = bundleIndex % 8;
    return (account.positionBitmap[bitmapIndex] & (1 << bitmapOffset)) > 0;
  }

  function checkBitmapIsClosed(
    account: PositionBundleData,
    bundleIndex: number,
  ): boolean {
    if (bundleIndex < 0 || bundleIndex >= POSITION_BUNDLE_SIZE)
      throw Error("bundleIndex is out of bounds");

    const bitmapIndex = Math.floor(bundleIndex / 8);
    const bitmapOffset = bundleIndex % 8;
    return (account.positionBitmap[bitmapIndex] & (1 << bitmapOffset)) === 0;
  }

  function checkBitmap(
    account: PositionBundleData,
    openedBundleIndexes: number[],
  ) {
    for (let i = 0; i < POSITION_BUNDLE_SIZE; i++) {
      if (openedBundleIndexes.includes(i)) {
        assert.ok(checkBitmapIsOpened(account, i));
      } else {
        assert.ok(checkBitmapIsClosed(account, i));
      }
    }
  }

  async function accrueFees(fixture: WhirlpoolTestFixture) {
    const ctx = testCtx.whirlpoolCtx;
    const { poolInitInfo, positions, tokenAccountA, tokenAccountB } =
      fixture.getInfos();

    const { whirlpoolPda, tokenVaultAKeypair, tokenVaultBKeypair } =
      poolInitInfo;

    const tickArrayPda = PDAUtil.getTickArray(
      ctx.program.programId,
      whirlpoolPda.publicKey,
      22528,
    );
    const oraclePda = PDAUtil.getOracle(
      ctx.program.programId,
      whirlpoolPda.publicKey,
    );

    const pool = await testCtx.whirlpoolClient.getPool(whirlpoolPda.publicKey);

    // Accrue fees in token A
    await toTx(
      ctx,
      WhirlpoolIx.swapIx(ctx.program, {
        amount: new BN(200_000),
        otherAmountThreshold: ZERO_BN,
        sqrtPriceLimit: MathUtil.toX64(new Decimal(4)),
        amountSpecifiedIsInput: true,
        aToB: true,
        whirlpool: whirlpoolPda.publicKey,
        tokenAuthority: ctx.wallet.publicKey,
        tokenOwnerAccountA: tokenAccountA,
        tokenVaultA: tokenVaultAKeypair.publicKey,
        tokenOwnerAccountB: tokenAccountB,
        tokenVaultB: tokenVaultBKeypair.publicKey,
        tickArray0: tickArrayPda.publicKey,
        tickArray1: tickArrayPda.publicKey,
        tickArray2: tickArrayPda.publicKey,
        oracle: oraclePda.publicKey,
      }),
    ).buildAndExecute();

    // Accrue fees in token B
    await toTx(
      ctx,
      WhirlpoolIx.swapIx(ctx.program, {
        amount: new BN(200_000),
        otherAmountThreshold: ZERO_BN,
        sqrtPriceLimit: MathUtil.toX64(new Decimal(5)),
        amountSpecifiedIsInput: true,
        aToB: false,
        whirlpool: whirlpoolPda.publicKey,
        tokenAuthority: ctx.wallet.publicKey,
        tokenOwnerAccountA: tokenAccountA,
        tokenVaultA: tokenVaultAKeypair.publicKey,
        tokenOwnerAccountB: tokenAccountB,
        tokenVaultB: tokenVaultBKeypair.publicKey,
        tickArray0: tickArrayPda.publicKey,
        tickArray1: tickArrayPda.publicKey,
        tickArray2: tickArrayPda.publicKey,
        oracle: oraclePda.publicKey,
      }),
    ).buildAndExecute();

    // all position should get some fees
    for (const positionInfo of positions) {
      const position = await testCtx.whirlpoolClient.getPosition(
        positionInfo.publicKey,
      );

      const poolData = await pool.refreshData();
      const positionData = await position.refreshData();
      const tickLowerData = position.getLowerTickData();
      const tickUpperData = position.getLowerTickData();

      const quote = collectFeesQuote({
        whirlpool: poolData,
        position: positionData,
        tickLower: tickLowerData,
        tickUpper: tickUpperData,
        tokenExtensionCtx: await TokenExtensionUtil.buildTokenExtensionContext(
          ctx.fetcher,
          poolData,
          IGNORE_CACHE,
        ),
      });

      assert.ok(quote.feeOwedA.gtn(0) || quote.feeOwedB.gtn(0));
    }
  }

  async function stopRewardsEmission(fixture: WhirlpoolTestFixture) {
    const ctx = testCtx.whirlpoolCtx;
    const { poolInitInfo, configKeypairs } = fixture.getInfos();
    const { whirlpoolPda } = poolInitInfo;

    const pool = await testCtx.whirlpoolClient.getPool(whirlpoolPda.publicKey);

    for (let i = 0; i < NUM_REWARDS; i++) {
      await toTx(
        ctx,
        WhirlpoolIx.setRewardEmissionsIx(ctx.program, {
          whirlpool: pool.getAddress(),
          rewardVaultKey: pool.getData().rewardInfos[i].vault,
          rewardAuthority:
            configKeypairs.rewardEmissionsSuperAuthorityKeypair.publicKey,
          rewardIndex: i,
          emissionsPerSecondX64: ZERO,
        }),
      )
        .addSigner(configKeypairs.rewardEmissionsSuperAuthorityKeypair)
        .buildAndExecute();
    }
  }

  it(`successfully open POSITION_BUNDLE_SIZE(${POSITION_BUNDLE_SIZE}) bundled positions and then close them`, async () => {
    // create test pool
    const ctx = testCtx.whirlpoolCtx;
    const fixture = await new WhirlpoolTestFixture(ctx).init({
      tickSpacing,
      positions: [],
      rewards: [],
    });
    const { poolInitInfo } = fixture.getInfos();
    // initialize position bundle
    const positionBundleInfo = await initializePositionBundle(
      ctx,
      ctx.wallet.publicKey,
    );
    const positionBundlePubkey = positionBundleInfo.positionBundlePda.publicKey;
    const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;

    const batchSize = 12;
    const openedBundleIndexes: number[] = [];

    // open all
    for (
      let startBundleIndex = 0;
      startBundleIndex < POSITION_BUNDLE_SIZE;
      startBundleIndex += batchSize
    ) {
      const minBundleIndex = startBundleIndex;
      const maxBundleIndex =
        Math.min(startBundleIndex + batchSize, POSITION_BUNDLE_SIZE) - 1;

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );

      for (
        let bundleIndex = minBundleIndex;
        bundleIndex <= maxBundleIndex;
        bundleIndex++
      ) {
        const bundledPositionPda = PDAUtil.getBundledPosition(
          ctx.program.programId,
          positionBundleInfo.positionBundleMintKeypair.publicKey,
          bundleIndex,
        );
        builder.addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundlePubkey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex,
            tickUpperIndex,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        );
        openedBundleIndexes.push(bundleIndex);
      }

      await builder.buildAndExecute();
      const positionBundleAccount = await ctx.fetcher.getPositionBundle(
        positionBundlePubkey,
        IGNORE_CACHE,
      );
      checkBitmap(positionBundleAccount!, openedBundleIndexes);
    }
    assert.equal(openedBundleIndexes.length, POSITION_BUNDLE_SIZE);

    // close all
    for (
      let startBundleIndex = 0;
      startBundleIndex < POSITION_BUNDLE_SIZE;
      startBundleIndex += batchSize
    ) {
      const minBundleIndex = startBundleIndex;
      const maxBundleIndex =
        Math.min(startBundleIndex + batchSize, POSITION_BUNDLE_SIZE) - 1;

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );

      for (
        let bundleIndex = minBundleIndex;
        bundleIndex <= maxBundleIndex;
        bundleIndex++
      ) {
        const bundledPositionPda = PDAUtil.getBundledPosition(
          ctx.program.programId,
          positionBundleInfo.positionBundleMintKeypair.publicKey,
          bundleIndex,
        );
        builder.addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPda.publicKey,
            bundleIndex,
            positionBundle: positionBundlePubkey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: ctx.wallet.publicKey,
          }),
        );
        openedBundleIndexes.shift();
      }

      await builder.buildAndExecute();
      const positionBundleAccount = await ctx.fetcher.getPositionBundle(
        positionBundlePubkey,
        IGNORE_CACHE,
      );
      checkBitmap(positionBundleAccount!, openedBundleIndexes);
    }
    assert.equal(openedBundleIndexes.length, 0);

    // delete position bundle
    await toTx(
      ctx,
      WhirlpoolIx.deletePositionBundleIx(ctx.program, {
        positionBundle: positionBundlePubkey,
        positionBundleMint:
          positionBundleInfo.positionBundleMintKeypair.publicKey,
        positionBundleTokenAccount:
          positionBundleInfo.positionBundleTokenAccount,
        owner: ctx.wallet.publicKey,
        receiver: ctx.wallet.publicKey,
      }),
    ).buildAndExecute();

    // Poll for the account to be closed (litesvm has delayed state updates)
    const positionBundleAccount = await pollForCondition(
      () => ctx.fetcher.getPositionBundle(positionBundlePubkey, IGNORE_CACHE),
      (account) => account === null,
      {
        accountToReload: positionBundlePubkey,
        connection: ctx.connection,
      },
    );
    assert.ok(positionBundleAccount === null);
  });

  it("successfully increase/decrease liquidity and harvest on bundled position", async () => {
    // Reset LiteSVM state before this test to avoid state contamination from bulk position operations
    const env = await initializeLiteSVMEnvironment();
    provider = env.provider;
    program = env.program;
    anchor.setProvider(provider);
    const whirlpoolCtx = WhirlpoolContext.fromWorkspace(provider, program);
    const whirlpoolClient = buildWhirlpoolClient(whirlpoolCtx);
    testCtx = {
      provider,
      program,
      whirlpoolCtx,
      whirlpoolClient,
    };

    // create test pool
    const ctx = testCtx.whirlpoolCtx;
    const fixture = await new WhirlpoolTestFixture(ctx).init({
      tickSpacing,
      positions: [
        { liquidityAmount, tickLowerIndex, tickUpperIndex }, // non bundled position (to create TickArrays)
      ],
      rewards: [
        {
          emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
          vaultAmount: new BN(vaultStartBalance),
        },
        {
          emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
          vaultAmount: new BN(vaultStartBalance),
        },
        {
          emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
          vaultAmount: new BN(vaultStartBalance),
        },
      ],
    });
    const { poolInitInfo, rewards } = fixture.getInfos();

    // initialize position bundle
    const positionBundleInfo = await initializePositionBundle(
      ctx,
      ctx.wallet.publicKey,
    );

    // open bundled position
    const bundleIndex = 0;
    const positionInitInfo = await openBundledPosition(
      ctx,
      poolInitInfo.whirlpoolPda.publicKey,
      positionBundleInfo.positionBundleMintKeypair.publicKey,
      bundleIndex,
      tickLowerIndex,
      tickUpperIndex,
    );
    const { bundledPositionPda } = positionInitInfo.params;

    const bundledPositionPubkey = bundledPositionPda.publicKey;
    const tickArrayLower = PDAUtil.getTickArrayFromTickIndex(
      positionInitInfo.params.tickLowerIndex,
      poolInitInfo.tickSpacing,
      poolInitInfo.whirlpoolPda.publicKey,
      ctx.program.programId,
    ).publicKey;
    const tickArrayUpper = PDAUtil.getTickArrayFromTickIndex(
      positionInitInfo.params.tickUpperIndex,
      poolInitInfo.tickSpacing,
      poolInitInfo.whirlpoolPda.publicKey,
      ctx.program.programId,
    ).publicKey;
    const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;
    const tokenOwnerAccountA = getAssociatedTokenAddressSync(
      poolInitInfo.tokenMintA,
      ctx.wallet.publicKey,
    );
    const tokenOwnerAccountB = getAssociatedTokenAddressSync(
      poolInitInfo.tokenMintB,
      ctx.wallet.publicKey,
    );

    const modifyLiquidityParams = {
      liquidityAmount,
      position: bundledPositionPubkey,
      positionAuthority: ctx.wallet.publicKey,
      positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
      tickArrayLower,
      tickArrayUpper,
      tokenOwnerAccountA,
      tokenOwnerAccountB,
      tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
      tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
      whirlpool: whirlpoolPubkey,
    };

    // increaseLiquidity
    const depositAmounts = PoolUtil.getTokenAmountsFromLiquidity(
      liquidityAmount,
      (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
      PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
      PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
      true,
    );

    const preIncrease = await ctx.fetcher.getPosition(
      bundledPositionPubkey,
      IGNORE_CACHE,
    );
    assert.ok(preIncrease!.liquidity.isZero());
    await toTx(
      ctx,
      WhirlpoolIx.increaseLiquidityIx(ctx.program, {
        ...modifyLiquidityParams,
        tokenMaxA: depositAmounts.tokenA,
        tokenMaxB: depositAmounts.tokenB,
      }),
    ).buildAndExecute();
    const postIncrease = await pollForCondition(
      () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
      (position) => position!.liquidity.eq(liquidityAmount),
      {
        accountToReload: bundledPositionPubkey,
        connection: ctx.connection,
      },
    );
    assert.ok(postIncrease!.liquidity.eq(liquidityAmount));

    warpClock(2); // accrueRewards
    await accrueFees(fixture);
    await stopRewardsEmission(fixture);

    // updateFeesAndRewards
    const preUpdate = await ctx.fetcher.getPosition(
      bundledPositionPubkey,
      IGNORE_CACHE,
    );
    assert.ok(preUpdate!.feeOwedA.isZero());
    assert.ok(preUpdate!.feeOwedB.isZero());
    assert.ok(preUpdate!.rewardInfos.every((r) => r.amountOwed.isZero()));
    await toTx(
      ctx,
      WhirlpoolIx.updateFeesAndRewardsIx(ctx.program, {
        position: bundledPositionPubkey,
        tickArrayLower,
        tickArrayUpper,
        whirlpool: whirlpoolPubkey,
      }),
    ).buildAndExecute();
    const postUpdate = await pollForCondition(
      () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
      (position) =>
        position!.feeOwedA.gtn(0) &&
        position!.feeOwedB.gtn(0) &&
        position!.rewardInfos.every((r) => r.amountOwed.gtn(0)),
      {
        accountToReload: bundledPositionPubkey,
        connection: ctx.connection,
      },
    );
    assert.ok(postUpdate!.feeOwedA.gtn(0));
    assert.ok(postUpdate!.feeOwedB.gtn(0));
    assert.ok(postUpdate!.rewardInfos.every((r) => r.amountOwed.gtn(0)));

    // collectFees
    await toTx(
      ctx,
      WhirlpoolIx.collectFeesIx(ctx.program, {
        position: bundledPositionPubkey,
        positionAuthority: ctx.wallet.publicKey,
        positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
        tokenOwnerAccountA,
        tokenOwnerAccountB,
        tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
        tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
        whirlpool: whirlpoolPubkey,
      }),
    ).buildAndExecute();
    const postCollectFees = await pollForCondition(
      () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
      (position) => position!.feeOwedA.isZero() && position!.feeOwedB.isZero(),
      {
        accountToReload: bundledPositionPubkey,
        connection: ctx.connection,
      },
    );
    assert.ok(postCollectFees!.feeOwedA.isZero());
    assert.ok(postCollectFees!.feeOwedB.isZero());

    // collectReward
    for (let i = 0; i < NUM_REWARDS; i++) {
      const ata = await createTokenAccount(
        provider,
        rewards[i].rewardMint,
        ctx.wallet.publicKey,
      );

      const preCollectReward = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(preCollectReward!.rewardInfos[i].amountOwed.gtn(0));
      await toTx(
        ctx,
        WhirlpoolIx.collectRewardIx(ctx.program, {
          position: bundledPositionPubkey,
          positionAuthority: ctx.wallet.publicKey,
          positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
          rewardIndex: i,
          rewardVault: rewards[i].rewardVaultKeypair.publicKey,
          rewardOwnerAccount: ata,
          whirlpool: whirlpoolPubkey,
        }),
      ).buildAndExecute();
      const postCollectReward = await pollForCondition(
        () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
        (position) => position!.rewardInfos[i].amountOwed.isZero(),
        {
          accountToReload: bundledPositionPubkey,
          connection: ctx.connection,
        },
      );
      assert.ok(postCollectReward!.rewardInfos[i].amountOwed.isZero());
    }
    // decreaseLiquidity
    const withdrawAmounts = PoolUtil.getTokenAmountsFromLiquidity(
      liquidityAmount,
      (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
      PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
      PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
      false,
    );

    const preDecrease = await ctx.fetcher.getPosition(
      bundledPositionPubkey,
      IGNORE_CACHE,
    );
    assert.ok(preDecrease!.liquidity.eq(liquidityAmount));
    await toTx(
      ctx,
      WhirlpoolIx.decreaseLiquidityIx(ctx.program, {
        ...modifyLiquidityParams,
        tokenMinA: withdrawAmounts.tokenA,
        tokenMinB: withdrawAmounts.tokenB,
      }),
    ).buildAndExecute();
    const postDecrease = await pollForCondition(
      () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
      (position) => position!.liquidity.isZero(),
      {
        accountToReload: bundledPositionPubkey,
        connection: ctx.connection,
      },
    );
    assert.ok(postDecrease!.liquidity.isZero());

    // close bundled position
    await toTx(
      ctx,
      WhirlpoolIx.closeBundledPositionIx(ctx.program, {
        bundledPosition: bundledPositionPubkey,
        bundleIndex,
        positionBundle: positionBundleInfo.positionBundlePda.publicKey,
        positionBundleAuthority: ctx.wallet.publicKey,
        positionBundleTokenAccount:
          positionBundleInfo.positionBundleTokenAccount,
        receiver: ctx.wallet.publicKey,
      }),
    ).buildAndExecute();
    const postClose = await pollForCondition(
      () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
      (position) => position === null,
      {
        accountToReload: bundledPositionPubkey,
        connection: ctx.connection,
      },
    );
    assert.ok(postClose === null);
  });

  it("successfully repeatedly open bundled position & close bundled position", async () => {
    // Reset LiteSVM state before this test to avoid state contamination from bulk position operations
    const env = await initializeLiteSVMEnvironment();
    provider = env.provider;
    program = env.program;
    anchor.setProvider(provider);
    const whirlpoolCtx = WhirlpoolContext.fromWorkspace(provider, program);
    const whirlpoolClient = buildWhirlpoolClient(whirlpoolCtx);
    testCtx = {
      provider,
      program,
      whirlpoolCtx,
      whirlpoolClient,
    };

    const openCloseIterationNum = 5;

    // create test pool
    const ctx = testCtx.whirlpoolCtx;
    const fixture = await new WhirlpoolTestFixture(ctx).init({
      tickSpacing,
      positions: [
        { liquidityAmount, tickLowerIndex, tickUpperIndex }, // non bundled position (to create TickArrays)
      ],
      rewards: [
        {
          emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
          vaultAmount: new BN(vaultStartBalance),
        },
        {
          emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
          vaultAmount: new BN(vaultStartBalance),
        },
        {
          emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
          vaultAmount: new BN(vaultStartBalance),
        },
      ],
    });
    const { poolInitInfo, rewards } = fixture.getInfos();

    // increase feeGrowth
    await accrueFees(fixture);

    // increase rewardGrowth
    warpClock(2);

    // initialize position bundle
    const positionBundleInfo = await initializePositionBundle(
      ctx,
      ctx.wallet.publicKey,
    );
    const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

    for (let iter = 0; iter < openCloseIterationNum; iter++) {
      // open bundled position
      const positionInitInfo = await openBundledPosition(
        ctx,
        poolInitInfo.whirlpoolPda.publicKey,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
        tickLowerIndex,
        tickUpperIndex,
      );
      const { bundledPositionPda } = positionInitInfo.params;

      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const tickArrayLower = PDAUtil.getTickArrayFromTickIndex(
        positionInitInfo.params.tickLowerIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const tickArrayUpper = PDAUtil.getTickArrayFromTickIndex(
        positionInitInfo.params.tickUpperIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;
      const tokenOwnerAccountA = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintA,
        ctx.wallet.publicKey,
      );
      const tokenOwnerAccountB = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintB,
        ctx.wallet.publicKey,
      );

      // initialized check (No data left over from previous opening)
      const postOpen = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(postOpen!.feeGrowthCheckpointA.isZero());
      assert.ok(postOpen!.feeGrowthCheckpointB.isZero());
      assert.ok(
        postOpen!.rewardInfos.every((r) => r.growthInsideCheckpoint.isZero()),
      );

      const modifyLiquidityParams = {
        liquidityAmount,
        position: bundledPositionPubkey,
        positionAuthority: ctx.wallet.publicKey,
        positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
        tickArrayLower,
        tickArrayUpper,
        tokenOwnerAccountA,
        tokenOwnerAccountB,
        tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
        tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
        whirlpool: whirlpoolPubkey,
      };

      // increaseLiquidity
      const depositAmounts = PoolUtil.getTokenAmountsFromLiquidity(
        liquidityAmount,
        (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
        PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
        PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
        true,
      );
      const preIncrease = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(preIncrease!.liquidity.isZero());
      await toTx(
        ctx,
        WhirlpoolIx.increaseLiquidityIx(ctx.program, {
          ...modifyLiquidityParams,
          tokenMaxA: depositAmounts.tokenA,
          tokenMaxB: depositAmounts.tokenB,
        }),
      ).buildAndExecute();
      const postIncrease = await pollForCondition(
        () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
        (position) => position!.liquidity.eq(liquidityAmount),
        {
          accountToReload: bundledPositionPubkey,
          connection: ctx.connection,
        },
      );
      assert.ok(postIncrease!.liquidity.eq(liquidityAmount));

      // non-zero check
      assert.ok(postIncrease!.feeGrowthCheckpointA.gtn(0));
      assert.ok(postIncrease!.feeGrowthCheckpointB.gtn(0));
      assert.ok(
        postIncrease!.rewardInfos.every((r) => r.growthInsideCheckpoint.gtn(0)),
      );

      warpClock(2); // accrueRewards
      await accrueFees(fixture);
      // decreaseLiquidity
      const withdrawAmounts = PoolUtil.getTokenAmountsFromLiquidity(
        liquidityAmount,
        (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
        PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
        PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
        false,
      );

      const preDecrease = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(preDecrease!.liquidity.eq(liquidityAmount));
      await toTx(
        ctx,
        WhirlpoolIx.decreaseLiquidityIx(ctx.program, {
          ...modifyLiquidityParams,
          tokenMinA: withdrawAmounts.tokenA,
          tokenMinB: withdrawAmounts.tokenB,
        }),
      ).buildAndExecute();
      const postDecrease = await pollForCondition(
        () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
        (position) => position!.liquidity.isZero(),
        {
          accountToReload: bundledPositionPubkey,
          connection: ctx.connection,
        },
      );
      assert.ok(postDecrease!.liquidity.isZero());

      // collectFees
      await toTx(
        ctx,
        WhirlpoolIx.collectFeesIx(ctx.program, {
          position: bundledPositionPubkey,
          positionAuthority: ctx.wallet.publicKey,
          positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
          tokenOwnerAccountA,
          tokenOwnerAccountB,
          tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
          tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
          whirlpool: whirlpoolPubkey,
        }),
      ).buildAndExecute();
      const postCollectFees = await pollForCondition(
        () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
        (position) =>
          position!.feeOwedA.isZero() && position!.feeOwedB.isZero(),
        {
          accountToReload: bundledPositionPubkey,
          connection: ctx.connection,
        },
      );
      assert.ok(postCollectFees!.feeOwedA.isZero());
      assert.ok(postCollectFees!.feeOwedB.isZero());

      // collectReward
      for (let i = 0; i < NUM_REWARDS; i++) {
        const ata = await createTokenAccount(
          provider,
          rewards[i].rewardMint,
          ctx.wallet.publicKey,
        );

        const preCollectReward = await ctx.fetcher.getPosition(
          bundledPositionPubkey,
          IGNORE_CACHE,
        );
        assert.ok(preCollectReward!.rewardInfos[i].amountOwed.gtn(0));
        await toTx(
          ctx,
          WhirlpoolIx.collectRewardIx(ctx.program, {
            position: bundledPositionPubkey,
            positionAuthority: ctx.wallet.publicKey,
            positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
            rewardIndex: i,
            rewardVault: rewards[i].rewardVaultKeypair.publicKey,
            rewardOwnerAccount: ata,
            whirlpool: whirlpoolPubkey,
          }),
        ).buildAndExecute();

        const postCollectReward = await pollForCondition(
          () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
          (position) => position!.rewardInfos[i].amountOwed.isZero(),
          {
            accountToReload: bundledPositionPubkey,
            connection: ctx.connection,
          },
        );
        assert.ok(postCollectReward!.rewardInfos[i].amountOwed.isZero());
      }

      // close bundled position
      await toTx(
        ctx,
        WhirlpoolIx.closeBundledPositionIx(ctx.program, {
          bundledPosition: bundledPositionPubkey,
          bundleIndex,
          positionBundle: positionBundleInfo.positionBundlePda.publicKey,
          positionBundleAuthority: ctx.wallet.publicKey,
          positionBundleTokenAccount:
            positionBundleInfo.positionBundleTokenAccount,
          receiver: ctx.wallet.publicKey,
        }),
      ).buildAndExecute();
      const postClose = await pollForCondition(
        () => ctx.fetcher.getPosition(bundledPositionPubkey, IGNORE_CACHE),
        (position) => position === null,
        {
          accountToReload: bundledPositionPubkey,
          connection: ctx.connection,
        },
      );
      assert.ok(postClose === null);
    }
  });

  describe("Single Transaction", () => {
    it("successfully openBundledPosition+increaseLiquidity / decreaseLiquidity+closeBundledPosition in single Tx", async () => {
      // create test pool
      const ctx = testCtx.whirlpoolCtx;
      const fixture = await new WhirlpoolTestFixture(ctx).init({
        tickSpacing,
        positions: [
          { liquidityAmount, tickLowerIndex, tickUpperIndex }, // non bundled position (to create TickArrays)
        ],
        rewards: [],
      });
      const { poolInitInfo } = fixture.getInfos();

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );
      const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

      const bundledPositionPda = PDAUtil.getBundledPosition(
        ctx.program.programId,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
      );
      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const tickArrayLower = PDAUtil.getTickArrayFromTickIndex(
        tickLowerIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const tickArrayUpper = PDAUtil.getTickArrayFromTickIndex(
        tickUpperIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;
      const tokenOwnerAccountA = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintA,
        ctx.wallet.publicKey,
      );
      const tokenOwnerAccountB = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintB,
        ctx.wallet.publicKey,
      );

      const modifyLiquidityParams = {
        liquidityAmount,
        position: bundledPositionPubkey,
        positionAuthority: ctx.wallet.publicKey,
        positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
        tickArrayLower,
        tickArrayUpper,
        tokenOwnerAccountA,
        tokenOwnerAccountB,
        tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
        tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
        whirlpool: whirlpoolPubkey,
      };

      const depositAmounts = PoolUtil.getTokenAmountsFromLiquidity(
        liquidityAmount,
        (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
        PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
        PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
        true,
      );

      // openBundledPosition + increaseLiquidity
      const openIncreaseBuilder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      openIncreaseBuilder
        .addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex,
            tickUpperIndex,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        )
        .addInstruction(
          WhirlpoolIx.increaseLiquidityIx(ctx.program, {
            ...modifyLiquidityParams,
            tokenMaxA: depositAmounts.tokenA,
            tokenMaxB: depositAmounts.tokenB,
          }),
        );
      await openIncreaseBuilder.buildAndExecute();
      const postIncrease = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(postIncrease!.liquidity.eq(liquidityAmount));

      const withdrawAmounts = PoolUtil.getTokenAmountsFromLiquidity(
        liquidityAmount,
        (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
        PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
        PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
        false,
      );

      const decreaseCloseBuilder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      decreaseCloseBuilder
        .addInstruction(
          WhirlpoolIx.decreaseLiquidityIx(ctx.program, {
            ...modifyLiquidityParams,
            tokenMinA: withdrawAmounts.tokenA,
            tokenMinB: withdrawAmounts.tokenB,
          }),
        )
        .addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPubkey,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: ctx.wallet.publicKey,
          }),
        );
      await decreaseCloseBuilder.buildAndExecute();
      const postClose = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(postClose === null);
    });

    it("successfully open bundled position & close bundled position in single Tx", async () => {
      // create test pool
      const ctx = testCtx.whirlpoolCtx;
      const fixture = await new WhirlpoolTestFixture(ctx).init({
        tickSpacing,
        positions: [
          { liquidityAmount, tickLowerIndex, tickUpperIndex }, // non bundled position (to create TickArrays)
        ],
        rewards: [
          {
            emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
            vaultAmount: new BN(vaultStartBalance),
          },
          {
            emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
            vaultAmount: new BN(vaultStartBalance),
          },
          {
            emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
            vaultAmount: new BN(vaultStartBalance),
          },
        ],
      });
      const { poolInitInfo } = fixture.getInfos();

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );
      const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

      const bundledPositionPda = PDAUtil.getBundledPosition(
        ctx.program.programId,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
      );
      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const tickArrayLower = PDAUtil.getTickArrayFromTickIndex(
        tickLowerIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const tickArrayUpper = PDAUtil.getTickArrayFromTickIndex(
        tickUpperIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;
      const tokenOwnerAccountA = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintA,
        ctx.wallet.publicKey,
      );
      const tokenOwnerAccountB = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintB,
        ctx.wallet.publicKey,
      );

      const modifyLiquidityParams = {
        liquidityAmount,
        position: bundledPositionPubkey,
        positionAuthority: ctx.wallet.publicKey,
        positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
        tickArrayLower,
        tickArrayUpper,
        tokenOwnerAccountA,
        tokenOwnerAccountB,
        tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
        tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
        whirlpool: whirlpoolPubkey,
      };

      const depositAmounts = PoolUtil.getTokenAmountsFromLiquidity(
        liquidityAmount,
        (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
        PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
        PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
        true,
      );

      const receiver = Keypair.generate();
      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      builder
        .addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex,
            tickUpperIndex,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        )
        .addInstruction(
          WhirlpoolIx.increaseLiquidityIx(ctx.program, {
            ...modifyLiquidityParams,
            tokenMaxA: depositAmounts.tokenA,
            tokenMaxB: depositAmounts.tokenB,
          }),
        )
        .addInstruction(
          WhirlpoolIx.decreaseLiquidityIx(ctx.program, {
            ...modifyLiquidityParams,
            tokenMinA: new BN(0),
            tokenMinB: new BN(0),
          }),
        )
        .addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPubkey,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: receiver.publicKey,
          }),
        );

      await builder.buildAndExecute();
      const receiverBalance = await ctx.connection.getBalance(
        receiver.publicKey,
        "confirmed",
      );
      assert.ok(receiverBalance > 0);
    });

    it("successfully close & re-open bundled position with the same bundle index in single Tx", async () => {
      // create test pool
      const ctx = testCtx.whirlpoolCtx;
      const fixture = await new WhirlpoolTestFixture(ctx).init({
        tickSpacing,
        positions: [],
        rewards: [],
      });
      const { poolInitInfo } = fixture.getInfos();

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );
      const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

      const bundledPositionPda = PDAUtil.getBundledPosition(
        ctx.program.programId,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
      );
      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      builder
        // open
        .addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex,
            tickUpperIndex,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        )
        // close
        .addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPubkey,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: whirlpoolPubkey,
          }),
        )
        // reopen bundled position with same bundleIndex in single Tx
        .addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex: tickLowerIndex + tickSpacing,
            tickUpperIndex: tickUpperIndex + tickSpacing,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        );

      // Account closing reassigns to system program and reallocates
      // https://github.com/coral-xyz/anchor/pull/2169
      // in Anchor v0.26.0, close & open in same Tx will success.
      await builder.buildAndExecute();
      const postReopen = await ctx.fetcher.getPosition(
        bundledPositionPubkey,
        IGNORE_CACHE,
      );
      assert.ok(postReopen!.liquidity.isZero());
      assert.ok(postReopen!.tickLowerIndex === tickLowerIndex + tickSpacing);
      assert.ok(postReopen!.tickUpperIndex === tickUpperIndex + tickSpacing);
    });

    it("successfully open bundled position & swap & close bundled position in single Tx", async () => {
      // create test pool
      const ctx = testCtx.whirlpoolCtx;
      const fixture = await new WhirlpoolTestFixture(ctx).init({
        tickSpacing,
        positions: [
          { liquidityAmount, tickLowerIndex, tickUpperIndex }, // non bundled position (to create TickArrays)
        ],
        rewards: [
          {
            emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
            vaultAmount: new BN(vaultStartBalance),
          },
          {
            emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
            vaultAmount: new BN(vaultStartBalance),
          },
          {
            emissionsPerSecondX64: MathUtil.toX64(new Decimal(10)),
            vaultAmount: new BN(vaultStartBalance),
          },
        ],
      });
      const { poolInitInfo } = fixture.getInfos();

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );
      const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

      const bundledPositionPda = PDAUtil.getBundledPosition(
        ctx.program.programId,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
      );
      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const tickArrayLower = PDAUtil.getTickArrayFromTickIndex(
        tickLowerIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const tickArrayUpper = PDAUtil.getTickArrayFromTickIndex(
        tickUpperIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;
      const tokenOwnerAccountA = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintA,
        ctx.wallet.publicKey,
      );
      const tokenOwnerAccountB = getAssociatedTokenAddressSync(
        poolInitInfo.tokenMintB,
        ctx.wallet.publicKey,
      );

      const tickArrayPda = PDAUtil.getTickArray(
        ctx.program.programId,
        whirlpoolPubkey,
        22528,
      );
      const oraclePda = PDAUtil.getOracle(
        ctx.program.programId,
        whirlpoolPubkey,
      );

      const modifyLiquidityParams = {
        liquidityAmount,
        position: bundledPositionPubkey,
        positionAuthority: ctx.wallet.publicKey,
        positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
        tickArrayLower,
        tickArrayUpper,
        tokenOwnerAccountA,
        tokenOwnerAccountB,
        tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
        tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
        whirlpool: whirlpoolPubkey,
      };

      const depositAmounts = PoolUtil.getTokenAmountsFromLiquidity(
        liquidityAmount,
        (await ctx.fetcher.getPool(whirlpoolPubkey, IGNORE_CACHE))!.sqrtPrice,
        PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex),
        PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex),
        true,
      );

      const swapInput = new BN(200_000);
      const poolLiquidity = new BN(liquidityAmount.muln(2).toString());
      const estimatedFee = new BN(swapInput.toString())
        .muln(3)
        .divn(1000) // feeRate 0.3%
        .muln(97)
        .divn(100) // minus protocolFee 3%
        .shln(64)
        .div(poolLiquidity) // to X64 growth
        .mul(liquidityAmount)
        .shrn(64)
        .toNumber();

      const receiver = Keypair.generate();
      const receiverAtaA = await createTokenAccount(
        provider,
        poolInitInfo.tokenMintA,
        receiver.publicKey,
      );
      const receiverAtaB = await createTokenAccount(
        provider,
        poolInitInfo.tokenMintB,
        receiver.publicKey,
      );

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      builder
        .addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex,
            tickUpperIndex,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        )
        .addInstruction(
          WhirlpoolIx.increaseLiquidityIx(ctx.program, {
            ...modifyLiquidityParams,
            tokenMaxA: depositAmounts.tokenA,
            tokenMaxB: depositAmounts.tokenB,
          }),
        )
        .addInstruction(
          WhirlpoolIx.swapIx(ctx.program, {
            amount: swapInput,
            otherAmountThreshold: ZERO_BN,
            sqrtPriceLimit: MathUtil.toX64(new Decimal(4)),
            amountSpecifiedIsInput: true,
            aToB: true,
            whirlpool: whirlpoolPubkey,
            tokenAuthority: ctx.wallet.publicKey,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
            tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
            tickArray0: tickArrayPda.publicKey,
            tickArray1: tickArrayPda.publicKey,
            tickArray2: tickArrayPda.publicKey,
            oracle: oraclePda.publicKey,
          }),
        )
        .addInstruction(
          WhirlpoolIx.swapIx(ctx.program, {
            amount: swapInput,
            otherAmountThreshold: ZERO_BN,
            sqrtPriceLimit: MathUtil.toX64(new Decimal(5)),
            amountSpecifiedIsInput: true,
            aToB: false,
            whirlpool: whirlpoolPubkey,
            tokenAuthority: ctx.wallet.publicKey,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
            tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
            tickArray0: tickArrayPda.publicKey,
            tickArray1: tickArrayPda.publicKey,
            tickArray2: tickArrayPda.publicKey,
            oracle: oraclePda.publicKey,
          }),
        )
        .addInstruction(
          WhirlpoolIx.decreaseLiquidityIx(ctx.program, {
            ...modifyLiquidityParams,
            tokenMinA: new BN(0),
            tokenMinB: new BN(0),
          }),
        )
        .addInstruction(
          WhirlpoolIx.collectFeesIx(ctx.program, {
            position: bundledPositionPubkey,
            positionAuthority: ctx.wallet.publicKey,
            positionTokenAccount: positionBundleInfo.positionBundleTokenAccount,
            tokenOwnerAccountA: receiverAtaA,
            tokenOwnerAccountB: receiverAtaB,
            tokenVaultA: poolInitInfo.tokenVaultAKeypair.publicKey,
            tokenVaultB: poolInitInfo.tokenVaultBKeypair.publicKey,
            whirlpool: whirlpoolPubkey,
          }),
        )
        .addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPubkey,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: receiver.publicKey,
          }),
        );

      await builder.buildAndExecute();
      assert.ok(
        (await ctx.fetcher.getTokenInfo(receiverAtaA, IGNORE_CACHE))!.amount ===
          BigInt(estimatedFee.toString()),
      );
      assert.ok(
        (await ctx.fetcher.getTokenInfo(receiverAtaB, IGNORE_CACHE))!.amount ===
          BigInt(estimatedFee.toString()),
      );
    });
  });

  describe("Ensuring that the account is closed", () => {
    it("The discriminator of the deleted position bundle is marked as closed", async () => {
      const ctx = testCtx.whirlpoolCtx;

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );

      const preClose = await ctx.connection.getAccountInfo(
        positionBundleInfo.positionBundlePda.publicKey,
        "confirmed",
      );
      assert.ok(preClose !== null);
      const rentOfPositionBundle = preClose.lamports;
      assert.ok(rentOfPositionBundle > 0);

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      builder
        // close
        .addInstruction(
          WhirlpoolIx.deletePositionBundleIx(ctx.program, {
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleMint:
              positionBundleInfo.positionBundleMintKeypair.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            owner: ctx.wallet.publicKey,
            receiver: ctx.wallet.publicKey,
          }),
        )
        // fund rent
        .addInstruction({
          instructions: [
            SystemProgram.transfer({
              fromPubkey: ctx.wallet.publicKey,
              toPubkey: positionBundleInfo.positionBundlePda.publicKey,
              lamports: rentOfPositionBundle,
            }),
          ],
          cleanupInstructions: [],
          signers: [],
        });
      await builder.buildAndExecute();

      // Account closing reassigns to system program and reallocates
      // https://github.com/coral-xyz/anchor/pull/2169
      const postClose = await pollForCondition(
        () =>
          ctx.connection.getAccountInfo(
            positionBundleInfo.positionBundlePda.publicKey,
            "confirmed",
          ),
        (accountInfo) =>
          accountInfo !== null &&
          accountInfo.owner.equals(SystemProgram.programId) &&
          accountInfo.data.length === 0,
        {
          accountToReload: positionBundleInfo.positionBundlePda.publicKey,
          connection: ctx.connection,
        },
      );
      assert.ok(postClose !== null);
      assert.ok(postClose.owner.equals(SystemProgram.programId));
      assert.ok(postClose.data.length === 0);
    });

    it("The owner of closed account should be system program", async () => {
      // create test pool
      const ctx = testCtx.whirlpoolCtx;
      const fixture = await new WhirlpoolTestFixture(ctx).init({
        tickSpacing,
        positions: [],
        rewards: [],
      });
      const { poolInitInfo } = fixture.getInfos();

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );
      const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

      const bundledPositionPda = PDAUtil.getBundledPosition(
        ctx.program.programId,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
      );
      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;

      // open
      await toTx(
        ctx,
        WhirlpoolIx.openBundledPositionIx(ctx.program, {
          bundledPositionPda,
          bundleIndex,
          positionBundle: positionBundleInfo.positionBundlePda.publicKey,
          positionBundleAuthority: ctx.wallet.publicKey,
          positionBundleTokenAccount:
            positionBundleInfo.positionBundleTokenAccount,
          tickLowerIndex,
          tickUpperIndex,
          whirlpool: whirlpoolPubkey,
          funder: ctx.wallet.publicKey,
        }),
      ).buildAndExecute();

      const preClose = await ctx.connection.getAccountInfo(
        bundledPositionPubkey,
        "confirmed",
      );
      assert.ok(preClose !== null);
      const rentOfBundledPosition = preClose.lamports;
      assert.ok(rentOfBundledPosition > 0);

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      builder
        // close
        .addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPubkey,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: whirlpoolPubkey,
          }),
        )
        // fund rent
        .addInstruction({
          instructions: [
            SystemProgram.transfer({
              fromPubkey: ctx.wallet.publicKey,
              toPubkey: bundledPositionPubkey,
              lamports: rentOfBundledPosition,
            }),
          ],
          cleanupInstructions: [],
          signers: [],
        });
      await builder.buildAndExecute();

      // Account closing reassigns to system program and reallocates
      // https://github.com/coral-xyz/anchor/pull/2169
      const postClose = await pollForCondition(
        () => ctx.connection.getAccountInfo(bundledPositionPubkey, "confirmed"),
        (accountInfo) =>
          accountInfo !== null &&
          accountInfo.owner.equals(SystemProgram.programId) &&
          accountInfo.data.length === 0,
        {
          accountToReload: bundledPositionPubkey,
          connection: ctx.connection,
        },
      );
      assert.ok(postClose !== null);
      assert.ok(postClose.owner.equals(SystemProgram.programId));
      assert.ok(postClose.data.length === 0);
    });

    it("should be failed: close bundled position and then updateFeesAndRewards in single Tx", async () => {
      // create test pool
      const ctx = testCtx.whirlpoolCtx;
      const fixture = await new WhirlpoolTestFixture(ctx).init({
        tickSpacing,
        positions: [],
        rewards: [],
      });
      const { poolInitInfo } = fixture.getInfos();

      // initialize position bundle
      const positionBundleInfo = await initializePositionBundle(
        ctx,
        ctx.wallet.publicKey,
      );
      const bundleIndex = Math.floor(Math.random() * POSITION_BUNDLE_SIZE);

      const bundledPositionPda = PDAUtil.getBundledPosition(
        ctx.program.programId,
        positionBundleInfo.positionBundleMintKeypair.publicKey,
        bundleIndex,
      );
      const bundledPositionPubkey = bundledPositionPda.publicKey;
      const whirlpoolPubkey = poolInitInfo.whirlpoolPda.publicKey;
      const tickArrayLower = PDAUtil.getTickArrayFromTickIndex(
        tickLowerIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;
      const tickArrayUpper = PDAUtil.getTickArrayFromTickIndex(
        tickUpperIndex,
        poolInitInfo.tickSpacing,
        poolInitInfo.whirlpoolPda.publicKey,
        ctx.program.programId,
      ).publicKey;

      const builder = new TransactionBuilder(
        ctx.connection,
        ctx.wallet,
        ctx.txBuilderOpts,
      );
      builder
        // open
        .addInstruction(
          WhirlpoolIx.openBundledPositionIx(ctx.program, {
            bundledPositionPda,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            tickLowerIndex,
            tickUpperIndex,
            whirlpool: whirlpoolPubkey,
            funder: ctx.wallet.publicKey,
          }),
        )
        // close
        .addInstruction(
          WhirlpoolIx.closeBundledPositionIx(ctx.program, {
            bundledPosition: bundledPositionPubkey,
            bundleIndex,
            positionBundle: positionBundleInfo.positionBundlePda.publicKey,
            positionBundleAuthority: ctx.wallet.publicKey,
            positionBundleTokenAccount:
              positionBundleInfo.positionBundleTokenAccount,
            receiver: whirlpoolPubkey,
          }),
        )
        // try to use closed bundled position
        .addInstruction(
          WhirlpoolIx.updateFeesAndRewardsIx(ctx.program, {
            position: bundledPositionPubkey,
            tickArrayLower,
            tickArrayUpper,
            whirlpool: whirlpoolPubkey,
          }),
        );

      await assert.rejects(
        builder.buildAndExecute(),
        /0xbc4/, // AccountNotInitialized
      );
    });
  });
});
