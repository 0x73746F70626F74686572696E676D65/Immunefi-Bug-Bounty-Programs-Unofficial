# @orca-so/common-sdk

## 0.7.1

### Patch Changes

- [#1322](https://github.com/orca-so/whirlpools/pull/1322) [`e1949ba`](https://github.com/orca-so/whirlpools/commit/e1949ba4dd2c2cb25c789042dbc2a08ed9aaf1cf) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Remove minimum CU margin when estimating compute units

## 0.7.0

### Minor Changes

- [#1142](https://github.com/orca-so/whirlpools/pull/1142) [`3edef23`](https://github.com/orca-so/whirlpools/commit/3edef232f5e688082e6780a129689ef94d44d278) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Update dependencies to support contract upgrade to Anchor 0.29->0.31.1 and Solana Program 1.17->2.1

### Patch Changes

- [#1142](https://github.com/orca-so/whirlpools/pull/1142) [`3edef23`](https://github.com/orca-so/whirlpools/commit/3edef232f5e688082e6780a129689ef94d44d278) Thanks [@jshiohaha](https://github.com/jshiohaha)! - Update to Anchor 0.32.1

## 0.6.11

### Patch Changes

- [#782](https://github.com/orca-so/whirlpools/pull/782) [`ca5f054`](https://github.com/orca-so/whirlpools/commit/ca5f054066d34943eefe72228b442525e849eaeb) Thanks [@wjthieme](https://github.com/wjthieme)! - Update LICENSE file

## 0.6.10

### Patch Changes

- [#713](https://github.com/orca-so/whirlpools/pull/713) [`4f626d7`](https://github.com/orca-so/whirlpools/commit/4f626d7cd08df85e8e7d93e7d0155ac6efb4e1d5) Thanks [@wjthieme](https://github.com/wjthieme)! - Changed some peerDependencies to normal dependencies

## 0.6.9

### Patch Changes

- [#680](https://github.com/orca-so/whirlpools/pull/680) [`bc70bfb`](https://github.com/orca-so/whirlpools/commit/bc70bfb40068bb13282a92a7b36f501429470b27) Thanks [@wjthieme](https://github.com/wjthieme)! - Initial changeset version
