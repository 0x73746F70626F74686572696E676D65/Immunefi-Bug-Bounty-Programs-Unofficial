import * as anchor from "@coral-xyz/anchor";
import * as assert from "assert";
import type { FeeTierData, WhirlpoolContext } from "../../../src";
import { PDAUtil, toTx, WhirlpoolIx } from "../../../src";
import {
  ONE_SOL,
  REGEX_FOR_MISSING_SIGNATURE_ERROR,
  systemTransferTx,
  TickSpacing,
} from "../../utils";
import { initializeLiteSVMEnvironment } from "../../utils/litesvm";
import {
  initFeeTier,
  initializeConfigWithDefaultConfigParams,
} from "../../utils/init-utils";
import { generateDefaultInitFeeTierParams } from "../../utils/test-builders";

describe("initialize_fee_tier", () => {
  let provider: anchor.AnchorProvider;
  let ctx: WhirlpoolContext;
  let fetcher: WhirlpoolContext["fetcher"];

  beforeAll(async () => {
    const env = await initializeLiteSVMEnvironment();
    provider = env.provider;
    ctx = env.ctx;
    fetcher = env.fetcher;
  });

  it("successfully init a FeeRate stable account", async () => {
    const { configInitInfo, configKeypairs } =
      await initializeConfigWithDefaultConfigParams(ctx);

    const testTickSpacing = TickSpacing.Stable;
    const { params } = await initFeeTier(
      ctx,
      configInitInfo,
      configKeypairs.feeAuthorityKeypair,
      testTickSpacing,
      800,
    );

    const generatedPda = PDAUtil.getFeeTier(
      ctx.program.programId,
      configInitInfo.whirlpoolsConfigKeypair.publicKey,
      testTickSpacing,
    );

    const feeTierAccount = (await fetcher.getFeeTier(
      generatedPda.publicKey,
    )) as FeeTierData;

    assert.ok(feeTierAccount.tickSpacing == params.tickSpacing);
    assert.ok(feeTierAccount.defaultFeeRate == params.defaultFeeRate);
  });

  it("successfully init a FeeRate standard account", async () => {
    const { configInitInfo, configKeypairs } =
      await initializeConfigWithDefaultConfigParams(ctx);

    const testTickSpacing = TickSpacing.Standard;
    const { params } = await initFeeTier(
      ctx,
      configInitInfo,
      configKeypairs.feeAuthorityKeypair,
      testTickSpacing,
      3000,
    );

    const feeTierAccount = (await fetcher.getFeeTier(
      params.feeTierPda.publicKey,
    )) as FeeTierData;

    assert.ok(feeTierAccount.tickSpacing == params.tickSpacing);
    assert.ok(feeTierAccount.defaultFeeRate == params.defaultFeeRate);
  });

  it("successfully init a FeeRate max account", async () => {
    const { configInitInfo, configKeypairs } =
      await initializeConfigWithDefaultConfigParams(ctx);

    const testTickSpacing = TickSpacing.Standard;
    const { params } = await initFeeTier(
      ctx,
      configInitInfo,
      configKeypairs.feeAuthorityKeypair,
      testTickSpacing,
      60_000, // 6 %
    );

    const feeTierAccount = (await fetcher.getFeeTier(
      params.feeTierPda.publicKey,
    )) as FeeTierData;

    assert.ok(feeTierAccount.tickSpacing == params.tickSpacing);
    assert.ok(feeTierAccount.defaultFeeRate == params.defaultFeeRate);
    assert.ok(params.defaultFeeRate === 60_000);
  });

  it("successfully init a FeeRate with another funder wallet", async () => {
    const { configInitInfo, configKeypairs } =
      await initializeConfigWithDefaultConfigParams(ctx);

    const funderKeypair = anchor.web3.Keypair.generate();
    await systemTransferTx(
      provider,
      funderKeypair.publicKey,
      ONE_SOL,
    ).buildAndExecute();

    await initFeeTier(
      ctx,
      configInitInfo,
      configKeypairs.feeAuthorityKeypair,
      TickSpacing.Stable,
      3000,
      funderKeypair,
    );
  });

  it("fails when default fee rate exceeds max", async () => {
    const { configInitInfo, configKeypairs } =
      await initializeConfigWithDefaultConfigParams(ctx);

    await assert.rejects(
      initFeeTier(
        ctx,
        configInitInfo,
        configKeypairs.feeAuthorityKeypair,
        TickSpacing.Stable,
        60_000 + 1,
      ),
      /0x178c/, // FeeRateMaxExceeded
    );
  });

  it("fails when tick_spacing is zero", async () => {
    const { configInitInfo, configKeypairs } =
      await initializeConfigWithDefaultConfigParams(ctx);

    // invalid
    const tickSpacing = 0;

    await assert.rejects(
      initFeeTier(
        ctx,
        configInitInfo,
        configKeypairs.feeAuthorityKeypair,
        tickSpacing,
        3_000,
      ),
      /0x1774/, // InvalidTickSpacing
    );
  });

  it("fails when fee authority is not a signer", async () => {
    const { configInitInfo } =
      await initializeConfigWithDefaultConfigParams(ctx);

    await assert.rejects(
      toTx(
        ctx,
        WhirlpoolIx.initializeFeeTierIx(
          ctx.program,
          generateDefaultInitFeeTierParams(
            ctx,
            configInitInfo.whirlpoolsConfigKeypair.publicKey,
            configInitInfo.feeAuthority,
            TickSpacing.Stable,
            3000,
          ),
        ),
      ).buildAndExecute(),
      REGEX_FOR_MISSING_SIGNATURE_ERROR,
    );
  });

  it("fails when invalid fee authority provided", async () => {
    const { configInitInfo } =
      await initializeConfigWithDefaultConfigParams(ctx);
    const fakeFeeAuthorityKeypair = anchor.web3.Keypair.generate();

    await assert.rejects(
      toTx(
        ctx,
        WhirlpoolIx.initializeFeeTierIx(
          ctx.program,
          generateDefaultInitFeeTierParams(
            ctx,
            configInitInfo.whirlpoolsConfigKeypair.publicKey,
            fakeFeeAuthorityKeypair.publicKey,
            TickSpacing.Stable,
            3000,
          ),
        ),
      )
        .addSigner(fakeFeeAuthorityKeypair)
        .buildAndExecute(),
      /0x7dc/, // ConstraintAddress
    );
  });
});
