import * as assert from "assert";
import { AccountName, getAccountSize } from "../../../src";

describe("anchor-types", () => {
  it("all whirlpool account names exist in IDL", async () => {
    type ExpectedSize = { [a in AccountName]: number };
    const expectedSizes: ExpectedSize = {
      [AccountName.WhirlpoolsConfig]: 108,
      [AccountName.Position]: 216,
      [AccountName.TickArray]: 9988,
      [AccountName.DynamicTickArray]: 10004,
      [AccountName.Whirlpool]: 653,
      [AccountName.FeeTier]: 44,
      [AccountName.PositionBundle]: 136,
      [AccountName.WhirlpoolsConfigExtension]: 616,
      [AccountName.TokenBadge]: 201,
      [AccountName.LockConfig]: 241,
      [AccountName.AdaptiveFeeTier]: 256,
      [AccountName.Oracle]: 254,
    };
    Object.values(AccountName).forEach((name) => {
      try {
        const actualSize = getAccountSize(name);
        assert.equal(
          actualSize,
          expectedSizes[name],
          `For ${name} expected ${expectedSizes[name]} but got ${actualSize}`,
        );
      } catch (e) {
        assert.fail(`Error fetching size for ${name}: ${e}`);
      }
    });
  });
});
