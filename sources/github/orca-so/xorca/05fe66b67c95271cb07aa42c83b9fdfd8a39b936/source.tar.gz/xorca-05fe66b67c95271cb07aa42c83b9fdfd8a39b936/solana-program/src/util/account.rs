use crate::{
    error::ErrorCode,
    state::{AccountDiscriminator, ProgramAccount},
};
use borsh::BorshSerialize;
use pinocchio::{
    account_info::{AccountInfo, RefMut},
    instruction::Signer,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvars::{rent::Rent, Sysvar},
    ProgramResult,
};
use pinocchio_system::instructions::{Allocate, Assign, CreateAccount, Transfer};
use pinocchio_system::ID as SYSTEM_PROGRAM_ID;

pub fn get_account_info(
    accounts: &[AccountInfo],
    index: usize,
) -> Result<&AccountInfo, ProgramError> {
    if accounts.len() <= index {
        return Err(ErrorCode::NotEnoughAccountKeys.into());
    }
    Ok(&accounts[index])
}

/// Secure account creation that handles pre-funded accounts to prevent DoS attacks.
/// If the account already has lamports, uses transfer + allocate + assign pattern.
/// This prevents attackers from pre-funding accounts to block creation.
pub fn create_account_secure(
    funder: &AccountInfo,
    new_account: &AccountInfo,
    space: usize,
    owner: &Pubkey,
    signers: &[Signer],
) -> ProgramResult {
    // Early return if account is not owned by system program
    if !new_account.is_owned_by(&SYSTEM_PROGRAM_ID) {
        return Ok(());
    }

    let rent = Rent::get()?;
    let required_lamports = rent.minimum_balance(space);
    let current_lamports = new_account.lamports();

    // Early return for empty account - use standard create_account
    if current_lamports == 0 {
        CreateAccount {
            from: funder,
            to: new_account,
            lamports: required_lamports,
            space: space as u64,
            owner,
        }
        .invoke_signed(signers)?;
        return Ok(());
    }

    // Account has lamports, use transfer + allocate + assign pattern
    // First, transfer the required lamports (minus what's already there)
    let lamports_to_transfer = required_lamports.saturating_sub(current_lamports);
    if lamports_to_transfer > 0 {
        Transfer {
            from: funder,
            to: new_account,
            lamports: lamports_to_transfer,
        }
        .invoke_signed(signers)?;
    }

    // Allocate space for the account
    Allocate {
        account: new_account,
        space: space as u64,
    }
    .invoke_signed(signers)?;

    // Assign ownership to the program
    Assign {
        account: new_account,
        owner,
    }
    .invoke_signed(signers)?;

    Ok(())
}

/// Secure version of create_program_account that handles pre-funded accounts to prevent DoS attacks.
pub fn create_program_account_secure<'a, T: ProgramAccount>(
    funder: &AccountInfo,
    new_account: &'a AccountInfo,
    signers: &[Signer],
) -> Result<RefMut<'a, T>, ProgramError> {
    create_account_secure(funder, new_account, T::LEN, &crate::ID, signers)?;
    let mut data = new_account.try_borrow_mut_data()?;
    data[0] = T::DISCRIMINATOR as u8;
    Ok(T::from_bytes_mut(data))
}

pub fn create_program_account_borsh<T: ProgramAccount + BorshSerialize + Default>(
    funder: &AccountInfo,
    new_account: &AccountInfo,
    signers: &[Signer],
    data: &T,
) -> Result<(), ProgramError> {
    create_account_secure(funder, new_account, T::LEN, &crate::ID, signers)?;

    // Create the initial state with Borsh serialization
    let serialized_data = borsh::to_vec(data).map_err(|_| ProgramError::InvalidAccountData)?;

    let mut data = new_account.try_borrow_mut_data()?;
    if serialized_data.len() > data.len() {
        return Err(ProgramError::InvalidAccountData);
    }
    data[..serialized_data.len()].copy_from_slice(&serialized_data);

    Ok(())
}

/// Closes an account and transfers the lamports to the receiver.
/// This function does not perform any assertions.
pub fn close_program_account(
    account_to_close: &AccountInfo,
    receiver: &AccountInfo,
) -> ProgramResult {
    let mut account_to_close_data = account_to_close.try_borrow_mut_data()?;
    account_to_close_data[0] = AccountDiscriminator::Closed as u8;

    *receiver.try_borrow_mut_lamports()? += account_to_close.lamports();
    *account_to_close.try_borrow_mut_lamports()? = 0;

    drop(account_to_close_data);
    account_to_close.resize(0)?;
    unsafe {
        account_to_close.assign(&SYSTEM_PROGRAM_ID);
    }

    Ok(())
}
