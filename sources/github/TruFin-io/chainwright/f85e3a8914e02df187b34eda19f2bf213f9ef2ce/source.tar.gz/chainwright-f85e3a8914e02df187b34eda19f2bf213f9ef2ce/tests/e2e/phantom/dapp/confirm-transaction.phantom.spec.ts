import { testWithPhantomWorkerScopeDapp } from "@/tests/fixture/test-with-phantom-fixture";
import { fillForm } from "@/tests/utils/transaction-form";
import { connectWallet } from "../utils";

const test = testWithPhantomWorkerScopeDapp;

test.describe("Confirm transaction E2E tests", () => {
    test("Should confirm transaction successfully", async ({ dappPage, workerScopeContents }) => {
        const { wallet: phantom } = workerScopeContents;
        const navigation = dappPage.getByRole("navigation");
        await navigation.waitFor({ state: "attached", timeout: 15_000 });

        await connectWallet(dappPage, phantom);
        await fillForm({
            appPage: dappPage,
            walletAddress: "2g5FgcaNpB7DRrcBCYrQQ72tpsAEZhDCPg8u6epb5zyQ",
            amount: "0.0001",
        });
        await phantom.confirmTransaction();
    });

    test("Should confirm transaction successfully if there is a confirm anyway warning", async ({
        dappPage,
        workerScopeContents,
    }) => {
        const { wallet: phantom } = workerScopeContents;
        await connectWallet(dappPage, phantom);
        await fillForm({
            appPage: dappPage,
            walletAddress: "2g5FgcaNpB7DRrcBCYrQQ72tpsAEZhDCPg8u6epb5zyQ",
            amount: "30",
        });
        await phantom.confirmTransaction();
    });
});
