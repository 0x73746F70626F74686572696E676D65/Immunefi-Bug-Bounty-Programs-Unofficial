import { defineConfig, devices } from "@playwright/test";

/**
 * @see https://playwright.dev/docs/test-configuration
 */
export default defineConfig({
    testDir: "./e2e",
    /* Run tests sequentially to avoid MetaMask extension conflicts */
    workers: 1,
    /* Retry on CI only */
    retries: process.env.CI ? 1 : 0,
    /* Reporter to use. See https://playwright.dev/docs/test-reporters */
    reporter: [["list"]],

    /* Global timeout for each test */
    timeout: process.env.CI ? 60_000 : 45_000,

    use: {
        // We are using locally deployed Metamask Test Dapp for somePhantom tests.
        baseURL: "https://chainwright-dapp.vercel.app/",

        // Collect all traces on CI, and only traces for failed tests when running locally.
        // See https://playwright.dev/docs/trace-viewer.

        // Added for getting account address
        permissions: ["clipboard-read"],
        trace: process.env.CI ? "retain-on-failure" : "off",
        video: process.env.CI ? "retain-on-failure" : "off",
        screenshot: process.env.CI ? "only-on-failure" : "off",
    },

    /* Configure projects for major browsers */
    projects: [
        {
            name: "chromium",
            use: { ...devices["Desktop Chrome"] },
        },
    ],
});
