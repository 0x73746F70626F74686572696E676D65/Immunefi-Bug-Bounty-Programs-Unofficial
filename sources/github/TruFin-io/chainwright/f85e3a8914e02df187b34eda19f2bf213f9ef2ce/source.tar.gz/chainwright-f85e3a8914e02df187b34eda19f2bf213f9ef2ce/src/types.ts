import type { BrowserContext, Page } from "@playwright/test";

export type CLIOptions = "metamask" | "solflare" | "petra" | "phantom" | "meteor" | "keplr" | "all";
export type SupportedWallets = Exclude<CLIOptions, "all">;
export type ExtensionName =
    | "Petra Aptos Wallet"
    | "MetaMask"
    | "Phantom"
    | "Keplr"
    | "Solflare Wallet"
    | "Meteor Wallet";

type Args = {
    context: BrowserContext;
    walletPage: Page;
};
export type WalletSetupFunction = ({ context, walletPage }: Args) => Promise<void>;

export type SupportedWalletsMap = {
    [key in SupportedWallets]: {
        downloadUrl: string;
        extensionName: ExtensionName;
        sha256: string;
    };
};

export type GetSetupFunctionFileList = {
    filePath: string;
    walletName: SupportedWallets;
};

export type ExtensionSource =
    | {
          localPath: string;
      }
    | {
          downloadUrl: string;
          sha256: string;
      };

export type WalletSetupConfig = {
    profileName?: string;
    slowMo?: number;
    extensionSource?: ExtensionSource;
};

export type WalletProfileFixtureArgs = {
    slowMo?: number;
    profileName?: string;
};
