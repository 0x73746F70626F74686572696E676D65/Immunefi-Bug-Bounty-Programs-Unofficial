import { expect, type Page } from "@playwright/test";
import { getWalletPasswordFromCache } from "@/utils/wallets/get-wallet-password-from-cache";
import { homepageSelectors, unlockWalletSelectors } from "../selectors/homepage-selectors.petra";

export default async function unlock(page: Page) {
    const walletPassword = await getWalletPasswordFromCache("petra");

    const inputField = page.locator(unlockWalletSelectors.passwordInput);
    const isWalletUnlocked = await inputField
        .isVisible()
        .then(() => true)
        .catch(() => false);

    if (!isWalletUnlocked) {
        console.info("💡 Wallet is already unlocked");
        return;
    }

    await expect(inputField).toBeVisible({ timeout: 15_000 });
    await inputField.fill(walletPassword);

    const unlockButton = page.locator(unlockWalletSelectors.unlockButton);
    await expect(unlockButton).toBeEnabled();
    await unlockButton.click();

    await Promise.allSettled([
        page.locator(homepageSelectors.sendButton).waitFor({ state: "visible", timeout: 20_000 }),
        page.locator(homepageSelectors.receiveButton).waitFor({ state: "visible", timeout: 20_000 }),
    ]);
}
