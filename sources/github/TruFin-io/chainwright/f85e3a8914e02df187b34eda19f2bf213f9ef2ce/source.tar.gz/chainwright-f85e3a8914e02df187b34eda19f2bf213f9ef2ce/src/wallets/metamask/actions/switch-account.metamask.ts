import { expect, type Locator, type Page } from "@playwright/test";
import { accountSelectors, homepageSelectors } from "../selectors/homepage-selectors.metamask";

export async function switchAccount(page: Page, accountName: string) {
    const accountMenuButton = page.getByTestId(homepageSelectors.accountMenuButton);
    const accountMenuTextContent = await accountMenuButton.textContent();

    if (accountMenuTextContent === accountName) {
        console.info(`Can't switch account to "${accountName}", it is already selected.`);
        return;
    }

    await expect(accountMenuButton).toBeVisible({ timeout: 15_000 });
    await accountMenuButton.click();
    await expect(page.getByRole("heading", { name: /accounts/i })).toBeVisible();

    const addAccountButtonLoading = page.getByTestId(accountSelectors.addMultichainAccountButton);
    const startTextContent = await addAccountButtonLoading.textContent();

    if (startTextContent?.includes("Syncing")) {
        await expect
            .poll(async () => (await addAccountButtonLoading.textContent())?.trim() ?? "", { timeout: 60_000 })
            .not.toBe(startTextContent);
    }

    const accountCells = await page.getByTestId(/^multichain-account-cell-(?:entropy|keyring):/).all();
    let currentAccount: Locator | null = null;

    for (const accountCell of accountCells) {
        await accountCell.scrollIntoViewIfNeeded();
        const textContent = await accountCell.textContent();

        if (textContent?.includes(accountName)) {
            currentAccount = accountCell;
            break;
        }
    }

    if (!currentAccount) {
        throw Error(`Account with name "${accountName}" not found.`);
    }

    await currentAccount.click();
    const loadingSpinner = page.locator("div[class='spinner loading-overlay__spinner']");
    await loadingSpinner.waitFor({ state: "detached" });
}
