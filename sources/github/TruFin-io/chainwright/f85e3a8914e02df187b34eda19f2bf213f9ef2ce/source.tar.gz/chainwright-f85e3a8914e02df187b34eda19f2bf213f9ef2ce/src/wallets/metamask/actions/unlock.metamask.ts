import { expect, type Page } from "@playwright/test";
import { getWalletPasswordFromCache } from "@/utils/wallets/get-wallet-password-from-cache";
import { homepageSelectors, unlockWalletSelectors } from "../selectors/homepage-selectors.metamask";
import { waitForMetaMaskLoad } from "../utils";

export default async function unlock(page: Page) {
    const walletPassword = await getWalletPasswordFromCache("metamask");

    const inputField = page.getByTestId(unlockWalletSelectors.passwordInput);
    const openChainSelector = page.getByTestId(homepageSelectors.openNetworkSelectorButton);

    const isWalletOpen = await openChainSelector.isVisible().catch(() => false);
    if (isWalletOpen) {
        console.info("💡 Wallet is already unlocked");
        return;
    }

    await inputField.fill(walletPassword);

    const unlockButton = page.getByTestId(unlockWalletSelectors.unlockButton);
    await expect(unlockButton).toBeVisible();
    await unlockButton.click();

    await waitForMetaMaskLoad(page);
    await expect(page.getByTestId(homepageSelectors.buyButton)).toBeVisible({ timeout: 30_000 });
}
