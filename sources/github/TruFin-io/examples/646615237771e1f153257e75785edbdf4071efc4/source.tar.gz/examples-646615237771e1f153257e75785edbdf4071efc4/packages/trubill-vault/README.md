# TruBILL vault examples

Example integrations for the TruFin TruBILL Solana vault. They cover the user flows (`deposit`,
`request_redeem`, `instant_redeem`, `claim_withdrawal`) and read-only views across three client paradigms:

| Variant | Stack                                                                           |
| ------- | ------------------------------------------------------------------------------- |
| anchor  | `@coral-xyz/anchor` 0.32.1                                                      |
| native  | raw `@solana/web3.js`                                                           |
| kit     | [codama](https://github.com/codama-idl/codama)-generated client + `@solana/kit` |

`common/` holds what the variants share: the committed IDLs, addresses, seeds, amount math, and (for anchor +
native) the web3.js helpers.

Step-by-step guides for each flow live in [`docs/USAGE.md`](./docs/USAGE.md).

## Note

- Every user instruction requires the caller to be whitelisted in the TruFin Staker program. A wallet that is
  not whitelisted will fail. Contact TruFin to be onboarded.
- Set `SIMULATE=true` to dry-run any instruction (builds and simulates, logs only, never sends).

## Setup

```sh
bun install          # also runs `bun run generate` (codama) via postinstall
cp .env.example .env # then fill in RPC_URL and WALLET_KEYPAIR
```

| Env var          | Description                                                     |
| ---------------- | --------------------------------------------------------------- |
| `RPC_URL`        | Mainnet RPC endpoint (use your own provider).                   |
| `WALLET_KEYPAIR` | Path to a Solana CLI keypair JSON (`~`, relative, or absolute). |
| `SIMULATE`       | Optional. Set to `true` to simulate instead of send.            |

The `kit/generated/` client is gitignored and regenerated from the committed IDL on `bun install` (or
`bun run generate`).

## Running

Scripts run directly with `bun run <path>`. Amounts are decimal token units (e.g. `10.5` USDC, `5.0` TruBILL).
The `[epoch]` argument is optional in every variant and defaults to the vault's last snapshot epoch when omitted.

### Instructions

| Flow             | Command (any variant)                                        |
| ---------------- | -----------------------------------------------------------  |
| deposit          | `<variant>/instructions/deposit.ts <usdc> [epoch]`           |
| request_redeem   | `<variant>/instructions/request-redeem.ts <trubill>`         |
| instant_redeem   | `<variant>/instructions/instant-redeem.ts <trubill> [epoch]` |
| claim_withdrawal | `<variant>/instructions/claim-withdrawal.ts <requestId>`     |

Both redeem flows take a TruBILL **share** amount: the program burns the shares and derives the USDC from the
epoch's NAV. Use `view/quote.ts` to preview the conversion.

```sh
# examples
SIMULATE=true bun run anchor/instructions/deposit.ts 10
bun run kit/instructions/request-redeem.ts 5
bun run native/instructions/claim-withdrawal.ts 0
```

Every runner takes an optional trailing `[keypairPath]` to override `WALLET_KEYPAIR`.

### Views (read-only)

| Script                                     | anchor | native | kit | Output                                    |
| -----------------------------------        | :----: | :----: | :-: | ------------------------------------------|
| `view/vault.ts`                            |   ✓    |        |  ✓  | Vault public config and share price       |
| `view/quote.ts <deposit\|redeem> <amount>` |   ✓    |        |  ✓  | Preview TruBILL⇄USDC for a deposit/redeem |
| `view/user-balances.ts [addr]`             |   ✓    |   ✓    |  ✓  | SOL, USDC, and TruBILL balances           |

## Linting

```sh
bun run lint:check   # tsc --noEmit && biome check
bun run lint:write   # biome check --write
```
