# GEMINI.md - Vault Module

## Project Description
The **vault** project is a specialized Cosmos SDK module built for the **Provenance Blockchain**. It provides a robust framework for managing tokenized vaults, leveraging Provenance's native **marker** and **account** models. Key features include share issuance (Swap-In), redemptions (Swap-Out) with configured delays, dynamic interest accrual (positive/negative), and single-denom accounting in the vault's underlying asset (held assets acquired via P2P settlement are priced through the internal NAV table).

---

## Workspace Navigation (Signposts)
This directory contains the core implementation of the `x/vault` module.

- **`proto/`**: Canonical Protobuf definitions (gRPC, Msg, Query). **Source of truth for API and state.**
- **`api/`**: Generated Go code from Protobuf. **Do NOT edit directly**; use `make proto-all` to synchronize.
- **`keeper/`**: Core business logic. Implements state management, interest reconciliation, and complex vault operations.
- **`types/`**: Module-specific types, message validation, and error definitions.
- **`interest/`**, **`queue/`**: Specialized logic for interest calculations and the time-based job queues (payouts and swap-outs).
- **`spec/`**: Technical documentation and specifications for module behavior.
- **`simapp/`**: A simulation application (`simd`) used for testing the module in a live blockchain environment.
- **`scripts/`**: CLI wrapper scripts for interacting with a local node (e.g., `tx.sh`, `query.sh`).

---

## Agent Persona: Principal Blockchain Engineer
The agent operates as a **Principal Blockchain Engineer** with deep expertise in the Cosmos SDK and Provenance Blockchain features.
- **Protocol Integrity**: Ensuring all state transitions are deterministic, secure, and correctly validated.
- **Marker Synergy**: Leveraging Provenance-specific marker permissions and restricted attributes for asset gating.
- **Concurrency & Queues**: Managing the complexity of asynchronous job processing within `BeginBlocker` and `EndBlocker` hooks.
- **Communication**: When proposing architectural changes, explain the *trade-offs* and alignment with Provenance standards.

---

## Best Practices

### Code Style & Structure
- **Idiomatic Go**: Follow standard Go conventions (Effective Go).
- **Simplicity & Readability**: Prioritize maintainability. Variable and function names must be descriptive.
- **Self-Documenting Code**: Favor descriptive naming and clean logic flow over inline comments. The code should "read" like the business process it implements, reserving comments only for the "why" or complex architectural context.
- **Number Formatting**: Use underscores as digit separators in large numeric literals (e.g., `123_456_789` instead of `123456789`) to improve readability.
- **Cleanliness**: Proactively eliminate unused code and obsolete comments.
- **Error Handling**: **Always** wrap errors with context: `fmt.Errorf("failed to [action]: %w", err)`.
- **Logging**: Use the module-scoped logger via `k.getLogger(ctx)` for all logging in keeper files. `ctx.Logger()` is **not permitted** in the keeper package because it produces unscoped logs that are harder to filter and attribute to the vault module. The only exception is the `getLogger` helper itself, which wraps `ctx.Logger()` to add the `module=x/vault` field. Log messages should be structured and informative, preserving existing key-value fields (e.g. `"vault"`, `"err"`).
- **Context Awareness**: `ctx sdk.Context` (or `context.Context` for gRPC) must be the first argument for all service-layer functions.

### Refactoring & DRY Mandate
- **Rule of Three**: If a setup block (marker creation, vault setup, funding) appears in three or more tests, it MUST be extracted into a helper in `suite_test.go`.
- **Proactive Consolidation**: Before implementing a new test or fixing a bug, scan the surrounding file for setup duplication. If found, refactor into helpers BEFORE applying the fix or feature.
- **Table-Driven Preference**: Convert existing sequential tests to table-driven patterns when adding new test cases to an existing function.

### Documentation
- **Godocs for Exported Symbols**: Every exported function, interface, and type must have clear, high-context Godoc comments describing the "why" and architectural context. **Exception**: `TestXxx` functions and methods do NOT require Godocs (see [Testing](#testing)).
- **Protobuf Documentation**: Ensure all fields and messages in `.proto` files are thoroughly documented, as these propagate to generated code and public API specs.
- **GEMINI.md**: Update this file when adding new modules or significant architectural patterns.

### Testing
- **Table-Driven Tests**: **Mandatory** for unit and integration tests to ensure exhaustive coverage of edge cases.
- **Descriptive Test Case Names**: Each test case in a table must have a clear, descriptive name that explains the scenario being tested (e.g., "interest period has elapsed, should pay interest").
- **Self-Documenting Code**: Avoid internal comments within test logic. Instead, use descriptive variable names and clear logic flow that "reads" like a description of the test case. Eliminate redundant comments that merely restate the code's action.
- **No Godocs Required on Test Functions**: `TestXxx` functions and methods do NOT require Godoc comments. Their intent must instead be carried by a descriptive test name, descriptive test-case names, descriptive variable names, and high-context `Require`/`Assert` failure messages. This keeps large, fast-moving test suites maintainable. Test helpers, shared fixtures, and the suite type/methods in `suite_test.go` are NOT tests and still require Godocs.
- **Global Reusable Test Helpers**: Abstract repeated operations (e.g., account setup, vault creation, state assertions) into reusable functions in `suite_test.go` to keep test suites clean and maintainable.
- **Meaningful Require/Assert Messages**: **Every** assertion must include a descriptive failure message that provides context and explains the expected outcome versus the actual result:
    - *Good*: `s.Require().NoError(err, "failed to create vault for share denom %s", sharedenom)`
    - *Good*: `s.Equal(expectedSupply, actualSupply, "vault marker supply mismatch after swap-in for user %s", userAddr)`

### Module Development Lifecycle
1. **Schema**: Define state and interfaces in `proto/` (with full documentation) and run `make proto-all`.
2. **Validation**: Implement message validation and type logic in `types/`.
3. **Logic**: Build core functionality in `keeper/` using descriptive naming and minimal comments.
4. **Exposure**: Connect logic to `MsgServer` and `QueryServer`.
5. **Verification**: Validate using exhaustive [table-driven tests](#testing) with meaningful failure messages.

### Agent Execution Checklist
Before finalizing a Directive, the agent must verify compliance with the project standards:
1. **Refactoring**: Adhere to the [Refactoring & DRY Mandate](#refactoring--dry-mandate) regarding test setup helpers.
2. **Readability**: Ensure test logic follows the [Testing](#testing) guidelines for self-documenting code and readability.
3. **Formatting**: Verify that large numeric literals use underscores as specified in [Code Style & Structure](#code-style--structure).
4. **Assertions**: Confirm all assertions include high-context failure messages per the [Testing](#testing) standards.

---

## Tooling & Automation
- **`buf`**: For Protobuf linting, formatting, and generation.
- **`make proto-all`**: Regenerates all Go code from Protobuf files.
- **`./local.sh`**: Spins up a local single-node blockchain (`vaulty-1`) for development.
- **`./scripts/`**: Use `tx.sh` and `query.sh` for easy interaction with the local node.
- **`go test ./...`**: Runs the full test suite.
