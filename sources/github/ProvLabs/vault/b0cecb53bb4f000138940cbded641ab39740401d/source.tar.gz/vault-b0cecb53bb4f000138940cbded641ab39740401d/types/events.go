package types

import (
	fmt "fmt"

	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
)

const (
	RefundReasonInsufficientFunds          = "insufficient_funds"
	RefundReasonPermissionDenied           = "permission_denied"
	RefundReasonMarkerNotActive            = "marker_not_active"
	RefundReasonRecipientMissingAttributes = "recipient_missing_required_attributes"
	RefundReasonRecipientInvalid           = "recipient_invalid"
	RefundReasonNavNotFound                = "nav_not_found"
	RefundReasonReconcileFailure           = "reconcile_failure"
	RefundReasonVaultPaused                = "vault_paused"
	RefundReasonUnknown                    = "unknown_error"
)

const (
	RetryReasonDequeueFailure  = "dequeue_failure"
	RetryReasonRefundFailure   = "refund_failure"
	RetryReasonCriticalFailure = "critical_failure"
	RetryReasonInvalidRequest  = "invalid_request"
)

const (
	// AssetDirectionInbound indicates an external asset moved into the vault in
	// exchange for the vault's underlying asset (the underlying is the target leg).
	AssetDirectionInbound = "inbound"
	// AssetDirectionOutbound indicates an asset moved out of the vault in
	// exchange for the vault's underlying asset (the underlying is the source leg).
	AssetDirectionOutbound = "outbound"
)

// NewEventVaultCreated creates a new EventVaultCreated event.
func NewEventVaultCreated(vault *VaultAccount) *EventVaultCreated {
	return &EventVaultCreated{
		VaultAddress:    vault.GetAddress().String(),
		Admin:           vault.Admin,
		ShareDenom:      vault.TotalShares.Denom,
		UnderlyingAsset: vault.UnderlyingAsset,
	}
}

// NewEventSwapIn creates a new EventSwapIn event.
func NewEventSwapIn(vaultAddress, owner string, amountIn, sharesReceived sdk.Coin) *EventSwapIn {
	return &EventSwapIn{
		VaultAddress:   vaultAddress,
		Owner:          owner,
		AmountIn:       amountIn.String(),
		SharesReceived: sharesReceived.String(),
	}
}

// NewEventSwapOut creates a new EventSwapOut event.
func NewEventSwapOut(vaultAddress, owner string, amountOut, sharesBurned sdk.Coin) *EventSwapOut {
	return &EventSwapOut{
		VaultAddress: vaultAddress,
		Owner:        owner,
		AmountOut:    amountOut.String(),
		SharesBurned: sharesBurned.String(),
	}
}

// NewEventVaultReconcile creates a new EventVaultReconcile event.
// Note: interestEarned does not use NewCoin to avoid panics with negative amounts.
func NewEventVaultReconcile(vaultAddress string, principalBefore, principalAfter sdk.Coin, rate string, time int64, interestEarned sdkmath.Int) *EventVaultReconcile {
	interestEarnedCoin := sdk.Coin{
		Denom:  principalBefore.Denom,
		Amount: interestEarned,
	}
	return &EventVaultReconcile{
		VaultAddress:    vaultAddress,
		PrincipalBefore: principalBefore.String(),
		PrincipalAfter:  principalAfter.String(),
		Rate:            rate,
		Time:            time,
		InterestEarned:  interestEarnedCoin.String(),
	}
}

// NewEventVaultInterestChange creates a new EventVaultInterestChange event.
func NewEventVaultInterestChange(vaultAddress, currentRate, desiredRate string) *EventVaultInterestChange {
	return &EventVaultInterestChange{
		VaultAddress: vaultAddress,
		CurrentRate:  currentRate,
		DesiredRate:  desiredRate,
	}
}

// NewEventInterestDeposit creates a new EventInterestDeposit event.
func NewEventInterestDeposit(vaultAddress, authority string, amount sdk.Coin) *EventInterestDeposit {
	return &EventInterestDeposit{
		VaultAddress: vaultAddress,
		Authority:    authority,
		Amount:       amount.String(),
	}
}

// NewEventInterestWithdrawal creates a new EventInterestWithdrawal event.
func NewEventInterestWithdrawal(vaultAddress, authority string, amount sdk.Coin) *EventInterestWithdrawal {
	return &EventInterestWithdrawal{
		VaultAddress: vaultAddress,
		Authority:    authority,
		Amount:       amount.String(),
	}
}

// NewEventToggleSwapIn creates a new EventToggleSwapIn event.
func NewEventToggleSwapIn(vaultAddress, admin string, enabled bool) *EventToggleSwapIn {
	return &EventToggleSwapIn{
		VaultAddress: vaultAddress,
		Admin:        admin,
		Enabled:      enabled,
	}
}

// NewEventToggleSwapOut creates a new EventToggleSwapOut event.
func NewEventToggleSwapOut(vaultAddress, admin string, enabled bool) *EventToggleSwapOut {
	return &EventToggleSwapOut{
		VaultAddress: vaultAddress,
		Admin:        admin,
		Enabled:      enabled,
	}
}

// NewEventDepositPrincipalFunds creates a new EventPrincipalDeposit event.
func NewEventDepositPrincipalFunds(vaultAddress, authority string, amount sdk.Coin) *EventDepositPrincipalFunds {
	return &EventDepositPrincipalFunds{
		VaultAddress: vaultAddress,
		Authority:    authority,
		Amount:       amount.String(),
	}
}

// NewEventWithdrawPrincipalFunds creates a new EventWithdrawPrincipalFunds event.
func NewEventWithdrawPrincipalFunds(vaultAddress, authority string, amount sdk.Coin) *EventWithdrawPrincipalFunds {
	return &EventWithdrawPrincipalFunds{
		VaultAddress: vaultAddress,
		Authority:    authority,
		Amount:       amount.String(),
	}
}

// NewEventMinInterestRateUpdated creates a new EventMinInterestRateUpdated event.
func NewEventMinInterestRateUpdated(vaultAddress, admin, minRate string) *EventMinInterestRateUpdated {
	return &EventMinInterestRateUpdated{
		VaultAddress: vaultAddress,
		Admin:        admin,
		MinRate:      minRate,
	}
}

// NewEventMaxInterestRateUpdated creates a new EventMaxInterestRateUpdated event.
func NewEventMaxInterestRateUpdated(vaultAddress, admin, maxRate string) *EventMaxInterestRateUpdated {
	return &EventMaxInterestRateUpdated{
		VaultAddress: vaultAddress,
		Admin:        admin,
		MaxRate:      maxRate,
	}
}

// NewEventSwapOutRequested creates a new EventSwapOutRequested event.
func NewEventSwapOutRequested(vaultAddress, owner, redeemDenom string, shares sdk.Coin, requestID uint64) *EventSwapOutRequested {
	return &EventSwapOutRequested{
		VaultAddress: vaultAddress,
		Owner:        owner,
		RedeemDenom:  redeemDenom,
		Shares:       shares.String(),
		RequestId:    requestID,
	}
}

// NewEventSwapOutCompleted creates a new EventSwapOutCompleted event.
func NewEventSwapOutCompleted(vaultAddress, owner string, assets sdk.Coin, requestID uint64) *EventSwapOutCompleted {
	return &EventSwapOutCompleted{
		VaultAddress: vaultAddress,
		Owner:        owner,
		Assets:       assets.String(),
		RequestId:    requestID,
	}
}

// NewEventSwapOutRefunded creates a new EventSwapOutRefunded event.
func NewEventSwapOutRefunded(vaultAddress, owner string, shares sdk.Coin, requestID uint64, reason string) *EventSwapOutRefunded {
	return &EventSwapOutRefunded{
		VaultAddress: vaultAddress,
		Owner:        owner,
		Shares:       shares.String(),
		RequestId:    requestID,
		Reason:       reason,
	}
}

// NewEventSwapOutRetryScheduled creates a new EventSwapOutRetryScheduled event, recording that a
// pending swap out failed again and has been re-keyed to retryTime.
func NewEventSwapOutRetryScheduled(vaultAddress, owner string, shares sdk.Coin, requestID uint64, reason string, failureCount uint32, retryTime int64) *EventSwapOutRetryScheduled {
	return &EventSwapOutRetryScheduled{
		VaultAddress: vaultAddress,
		Owner:        owner,
		Shares:       shares.String(),
		RequestId:    requestID,
		Reason:       reason,
		FailureCount: failureCount,
		RetryTime:    retryTime,
	}
}

// NewEventPendingSwapOutExpedited creates a new EventPendingSwapOutExpedited event.
func NewEventPendingSwapOutExpedited(requestID uint64, vault, authority string) *EventPendingSwapOutExpedited {
	return &EventPendingSwapOutExpedited{
		RequestId: requestID,
		Vault:     vault,
		Authority: authority,
	}
}

// NewEventVaultPaused creates a new EventVaultPaused event. forced reports
// whether the pause waived the strict reconcile/valuation gate, and forcedError
// carries the tolerated error (empty when nothing failed).
func NewEventVaultPaused(vaultAddress, authority, reason string, totalVaultValue sdk.Coin, forced bool, forcedError string) *EventVaultPaused {
	return &EventVaultPaused{
		VaultAddress:    vaultAddress,
		Authority:       authority,
		Reason:          reason,
		TotalVaultValue: totalVaultValue.String(),
		Forced:          forced,
		ForcedError:     forcedError,
	}
}

// NewEventVaultUnpaused creates a new EventVaultUnpaused event.
func NewEventVaultUnpaused(vaultAddress, authority string, totalVaultValue sdk.Coin) *EventVaultUnpaused {
	return &EventVaultUnpaused{
		VaultAddress:    vaultAddress,
		Authority:       authority,
		TotalVaultValue: totalVaultValue.String(),
	}
}

// NewEventBridgeAddressSet creates a new EventBridgeAddressSet event.
func NewEventBridgeAddressSet(vaultAddress, admin, bridgeAddress string) *EventBridgeAddressSet {
	return &EventBridgeAddressSet{
		VaultAddress:  vaultAddress,
		Admin:         admin,
		BridgeAddress: bridgeAddress,
	}
}

// NewEventBridgeToggled creates a new EventBridgeToggled event.
func NewEventBridgeToggled(vaultAddress, admin string, enabled bool) *EventBridgeToggled {
	return &EventBridgeToggled{
		VaultAddress: vaultAddress,
		Admin:        admin,
		Enabled:      enabled,
	}
}

// NewEventBridgeMintShares creates a new EventBridgeMintShares event.
func NewEventBridgeMintShares(vaultAddress, bridge string, shares sdk.Coin) *EventBridgeMintShares {
	return &EventBridgeMintShares{
		VaultAddress: vaultAddress,
		Bridge:       bridge,
		Shares:       shares.String(),
	}
}

// NewEventBridgeBurnShares creates a new EventBridgeBurnShares event.
func NewEventBridgeBurnShares(vaultAddress, bridge string, shares sdk.Coin) *EventBridgeBurnShares {
	return &EventBridgeBurnShares{
		VaultAddress: vaultAddress,
		Bridge:       bridge,
		Shares:       shares.String(),
	}
}

// NewEventSetShareDenomMetadata creates a new EventSetShareDenomMetadata event.
func NewEventSetShareDenomMetadata(vaultAddress, administrator string, metadata banktypes.Metadata) *EventSetShareDenomMetadata {
	metadataDenomUnits := make([]*EventDenomUnit, len(metadata.DenomUnits))
	for i, du := range metadata.DenomUnits {
		denomUnit := EventDenomUnit{
			Denom:    du.Denom,
			Exponent: fmt.Sprint(du.Exponent),
			Aliases:  du.Aliases,
		}
		metadataDenomUnits[i] = &denomUnit
	}
	return &EventSetShareDenomMetadata{
		VaultAddress:        vaultAddress,
		MetadataBase:        metadata.Base,
		MetadataDescription: metadata.Description,
		MetadataDisplay:     metadata.Display,
		MetadataDenomUnits:  metadataDenomUnits,
		MetadataName:        metadata.Name,
		MetadataSymbol:      metadata.Symbol,
		Administrator:       administrator,
	}
}

// NewEventAssetManagerSet creates a new EventAssetManagerSet event.
func NewEventAssetManagerSet(vaultAddress, admin, assetManager string) *EventAssetManagerSet {
	return &EventAssetManagerSet{
		VaultAddress: vaultAddress,
		Admin:        admin,
		AssetManager: assetManager,
	}
}

// NewEventWithdrawalDelayUpdated creates a new EventWithdrawalDelayUpdated event.
func NewEventWithdrawalDelayUpdated(vaultAddress, authority string, withdrawalDelaySeconds uint64) *EventWithdrawalDelayUpdated {
	return &EventWithdrawalDelayUpdated{
		VaultAddress:           vaultAddress,
		Authority:              authority,
		WithdrawalDelaySeconds: withdrawalDelaySeconds,
	}
}

// NewEventVaultFeeCollected creates a new EventVaultFeeCollected event.
func NewEventVaultFeeCollected(vaultAddress string, collected, requested, aumSnapshot, outstanding sdk.Coin, duration int64) *EventVaultFeeCollected {
	return &EventVaultFeeCollected{
		VaultAddress:      vaultAddress,
		CollectedAmount:   collected.String(),
		RequestedAmount:   requested.String(),
		AumSnapshot:       aumSnapshot.String(),
		DurationSeconds:   duration,
		OutstandingAmount: outstanding.String(),
	}
}

// NewEventParamsUpdated creates a new EventParamsUpdated event.
func NewEventParamsUpdated(params Params) *EventParamsUpdated {
	return &EventParamsUpdated{
		Params: &params,
	}
}

// NewEventVaultAUMFeeBipsUpdated creates a new EventVaultAUMFeeBipsUpdated event.
func NewEventVaultAUMFeeBipsUpdated(vaultAddress, authority string, aumFeeBips uint32) *EventVaultAUMFeeBipsUpdated {
	return &EventVaultAUMFeeBipsUpdated{
		VaultAddress: vaultAddress,
		Authority:    authority,
		AumFeeBips:   aumFeeBips,
	}
}

// NewEventMinSwapInValueUpdated creates a new EventMinSwapInValueUpdated event.
func NewEventMinSwapInValueUpdated(vaultAddress, authority, minSwapIn string) *EventMinSwapInValueUpdated {
	return &EventMinSwapInValueUpdated{
		VaultAddress: vaultAddress,
		Authority:    authority,
		MinSwapIn:    minSwapIn,
	}
}

// NewEventMinSwapOutValueUpdated creates a new EventMinSwapOutValueUpdated event.
func NewEventMinSwapOutValueUpdated(vaultAddress, authority, minSwapOut string) *EventMinSwapOutValueUpdated {
	return &EventMinSwapOutValueUpdated{
		VaultAddress: vaultAddress,
		Authority:    authority,
		MinSwapOut:   minSwapOut,
	}
}

// NewEventMaxSwapInValueUpdated creates a new EventMaxSwapInValueUpdated event.
func NewEventMaxSwapInValueUpdated(vaultAddress, authority, maxSwapIn string) *EventMaxSwapInValueUpdated {
	return &EventMaxSwapInValueUpdated{
		VaultAddress: vaultAddress,
		Authority:    authority,
		MaxSwapIn:    maxSwapIn,
	}
}

// NewEventMaxSwapOutValueUpdated creates a new EventMaxSwapOutValueUpdated event.
func NewEventMaxSwapOutValueUpdated(vaultAddress, authority, maxSwapOut string) *EventMaxSwapOutValueUpdated {
	return &EventMaxSwapOutValueUpdated{
		VaultAddress: vaultAddress,
		Authority:    authority,
		MaxSwapOut:   maxSwapOut,
	}
}

// NewEventNAVUpdated creates a new EventNAVUpdated event from a stored VaultNAV.
// signer is the NAV authority address that performed the update.
func NewEventNAVUpdated(vaultAddress string, nav VaultNAV, signer string) *EventNAVUpdated {
	return &EventNAVUpdated{
		VaultAddress:       vaultAddress,
		Denom:              nav.Denom,
		Price:              nav.Price.String(),
		Volume:             nav.Volume.String(),
		Source:             nav.Source,
		Signer:             signer,
		UpdatedBlockHeight: nav.UpdatedBlockHeight,
	}
}

// NewEventNAVRemoved creates a new EventNAVRemoved event from the last stored
// VaultNAV entry for the denom before it was removed. signer is the NAV authority
// address that removed the entry, and is empty when the protocol removed it, such
// as an outbound settlement draining the denom.
func NewEventNAVRemoved(vaultAddress string, nav VaultNAV, signer string) *EventNAVRemoved {
	return &EventNAVRemoved{
		VaultAddress: vaultAddress,
		Denom:        nav.Denom,
		LastPrice:    nav.Price.String(),
		LastVolume:   nav.Volume.String(),
		Signer:       signer,
	}
}

// NewEventNAVAuthorityUpdated creates a new EventNAVAuthorityUpdated event.
func NewEventNAVAuthorityUpdated(vaultAddress, admin, newAuthority string) *EventNAVAuthorityUpdated {
	return &EventNAVAuthorityUpdated{
		VaultAddress: vaultAddress,
		Admin:        admin,
		NewAuthority: newAuthority,
	}
}

// NewEventAssetAccepted creates a new EventAssetAccepted event. direction is one
// of AssetDirectionInbound or AssetDirectionOutbound.
func NewEventAssetAccepted(vaultAddress, source, externalID string, sourceAmount, targetAmount sdk.Coins, direction string) *EventAssetAccepted {
	return &EventAssetAccepted{
		VaultAddress: vaultAddress,
		Source:       source,
		ExternalId:   externalID,
		SourceAmount: sourceAmount.String(),
		TargetAmount: targetAmount.String(),
		Direction:    direction,
	}
}

// NewEventAssetRejected creates a new EventAssetRejected event.
func NewEventAssetRejected(vaultAddress, source, externalID string) *EventAssetRejected {
	return &EventAssetRejected{
		VaultAddress: vaultAddress,
		Source:       source,
		ExternalId:   externalID,
	}
}
