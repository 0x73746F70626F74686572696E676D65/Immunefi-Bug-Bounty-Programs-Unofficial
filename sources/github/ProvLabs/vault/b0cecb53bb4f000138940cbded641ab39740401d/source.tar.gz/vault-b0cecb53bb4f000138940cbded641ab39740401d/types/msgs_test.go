package types_test

import (
	"fmt"
	"math/big"
	"strings"
	"testing"

	sdkmath "cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/stretchr/testify/assert"

	"github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"
)

func TestMsgCreateVaultRequest_ValidateBasic(t *testing.T) {
	admin := utils.TestAddress().Bech32
	authority := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgCreateVaultRequest
		expectedErr error
	}{
		{
			name: "authority empty",
			msg: types.MsgCreateVaultRequest{
				Authority:       "",
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", ""),
		},
		{
			name: "authority invalid",
			msg: types.MsgCreateVaultRequest{
				Authority:       "bad",
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "success",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
			},
			expectedErr: nil,
		},
		{
			name: "admin empty",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           "",
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", ""),
		},
		{
			name: "admin invalid",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           "bad",
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "share denom empty",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("invalid share denom: %q", ""),
		},
		{
			name: "share denom invalid",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "inv@lid$",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("invalid share denom: %q", "inv@lid$"),
		},
		{
			name: "underlying empty",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "",
			},
			expectedErr: fmt.Errorf("invalid underlying asset: %q", ""),
		},
		{
			name: "underlying invalid",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "inv@lid$",
			},
			expectedErr: fmt.Errorf("invalid underlying asset: %q: %w", "inv@lid$", fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
		{
			name: "share denom equals underlying (not allowed)",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "uusd",
				UnderlyingAsset: "uusd",
			},
			expectedErr: fmt.Errorf("share denom (%q) cannot equal underlying asset denom (%q)", "uusd", "uusd"),
		},
		{
			name: "deprecated payment denom equal to underlying is allowed",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				PaymentDenom:    "uusd",
			},
			expectedErr: nil,
		},
		{
			name: "deprecated payment denom different from underlying (not allowed)",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				PaymentDenom:    "ylds",
			},
			expectedErr: fmt.Errorf("payment denom is deprecated: vaults are single-denom, so payment denom (%q) must be empty or equal underlying asset (%q)", "ylds", "uusd"),
		},
		{
			name: "swap out delay over two years (not allowed)",
			msg: types.MsgCreateVaultRequest{
				Authority:              authority,
				Admin:                  admin,
				ShareDenom:             "vaultshare",
				UnderlyingAsset:        "uusd",
				WithdrawalDelaySeconds: types.MaxWithdrawalDelay + 1,
			},
			expectedErr: fmt.Errorf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
		{
			name: "invalid min swap in (not an integer)",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				MinSwapInValue:  "abc",
			},
			expectedErr: fmt.Errorf("invalid swap-in limits: invalid min value: abc"),
		},
		{
			name: "negative min swap in",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				MinSwapInValue:  "-100",
			},
			expectedErr: fmt.Errorf("invalid swap-in limits: min value must be non-negative: -100"),
		},
		{
			name: "min swap in > max swap in",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				MinSwapInValue:  "1000",
				MaxSwapInValue:  "500",
			},
			expectedErr: fmt.Errorf("invalid swap-in limits: min value 1000 cannot be greater than max value 500"),
		},
		{
			name: "min swap out > max swap out",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				MinSwapOutValue: "2000",
				MaxSwapOutValue: "1000",
			},
			expectedErr: fmt.Errorf("invalid swap-out limits: min value 2000 cannot be greater than max value 1000"),
		},
		{
			name: "max swap in is zero",
			msg: types.MsgCreateVaultRequest{
				Authority:       authority,
				Admin:           admin,
				ShareDenom:      "vaultshare",
				UnderlyingAsset: "uusd",
				MaxSwapInValue:  "0",
			},
			expectedErr: fmt.Errorf("invalid swap-in limits: max value cannot be zero"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func makeDenomUnit(denom string, exp uint32, aliases ...string) *banktypes.DenomUnit {
	return &banktypes.DenomUnit{Denom: denom, Exponent: exp, Aliases: aliases}
}

func makeMetadata(units []*banktypes.DenomUnit, base, display, desc string) banktypes.Metadata {
	return banktypes.Metadata{
		Description: desc,
		DenomUnits:  units,
		Base:        base,
		Display:     display,
		Name:        strings.ToUpper(display),
		Symbol:      strings.ToUpper(display),
	}
}

// TestValidateDenomMetadataBasic verifies minimal validation rules for denom metadata.
func TestValidateDenomMetadataBasic(t *testing.T) {
	tests := []struct {
		name        string
		md          banktypes.Metadata
		expectedErr error
	}{
		{
			name:        "base empty",
			md:          makeMetadata(nil, "", "shares", "a"),
			expectedErr: fmt.Errorf("denom metadata base cannot be empty"),
		},
		{
			name:        "display empty",
			md:          makeMetadata(nil, "shares", "", "a"),
			expectedErr: fmt.Errorf("denom metadata display cannot be empty"),
		},
		{
			name:        "description too long",
			md:          makeMetadata([]*banktypes.DenomUnit{makeDenomUnit("shares", 0)}, "shares", "shares", strings.Repeat("d", 201)),
			expectedErr: fmt.Errorf("denom metadata description too long"),
		},
		{
			name:        "success minimal",
			md:          makeMetadata(nil, "shares", "shares", "ok"),
			expectedErr: nil,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := types.ValidateDenomMetadataBasic(tc.md)
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

// TestMsgSetShareDenomMetadataRequest_ValidateBasic verifies request-level validation.
func TestMsgSetShareDenomMetadataRequest_ValidateBasic(t *testing.T) {
	admin := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	validMD := makeMetadata([]*banktypes.DenomUnit{
		makeDenomUnit("shares", 0),
	}, "shares", "shares", "ok")

	emptyDisplayMD := makeMetadata(nil, "shares", "", "ok")

	tests := []struct {
		name        string
		msg         types.MsgSetShareDenomMetadataRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin,
				VaultAddress: vault,
				Metadata:     validMD,
			},
			expectedErr: nil,
		},
		{
			name: "empty vault address",
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin,
				VaultAddress: "",
				Metadata:     validMD,
			},
			expectedErr: fmt.Errorf("invalid set denom metadata request: vault address cannot be empty"),
		},
		{
			name: "invalid vault bech32",
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin,
				VaultAddress: "bad",
				Metadata:     validMD,
			},
			expectedErr: fmt.Errorf("invalid set denom metadata request: vault address must be a bech32 address string"),
		},
		{
			name: "empty admin",
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        "",
				VaultAddress: vault,
				Metadata:     validMD,
			},
			expectedErr: fmt.Errorf("invalid set denom metadata request: administrator cannot be empty"),
		},
		{
			name: "invalid admin bech32",
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        "bad",
				VaultAddress: vault,
				Metadata:     validMD,
			},
			expectedErr: fmt.Errorf("invalid set denom metadata request: administrator must be a bech32 address string"),
		},
		{
			name: "invalid metadata empty display",
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin,
				VaultAddress: vault,
				Metadata:     emptyDisplayMD,
			},
			expectedErr: fmt.Errorf("invalid set denom metadata request: denom metadata display cannot be empty"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgSwapInRequest_ValidateBasic(t *testing.T) {
	owner := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgSwapInRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgSwapInRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 100),
			},
			expectedErr: nil,
		},
		{
			name: "invalid vault address",
			msg: types.MsgSwapInRequest{
				Owner:        owner,
				VaultAddress: "bad",
				Assets:       sdk.NewInt64Coin("uusd", 100),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid owner address",
			msg: types.MsgSwapInRequest{
				Owner:        "bad",
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 100),
			},
			expectedErr: fmt.Errorf("invalid owner address: %q", "bad"),
		},
		{
			name: "invalid asset denom",
			msg: types.MsgSwapInRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)},
			},
			expectedErr: fmt.Errorf("invalid assets coin %v: %w", sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)}, fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
		{
			name: "zero amount",
			msg: types.MsgSwapInRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Errorf("invalid amount: assets %s must be greater than zero", "uusd"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgSwapOutRequest_ValidateBasic(t *testing.T) {
	owner := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgSwapOutRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgSwapOutRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 100),
			},
			expectedErr: nil,
		},
		{
			name: "invalid vault address",
			msg: types.MsgSwapOutRequest{
				Owner:        owner,
				VaultAddress: "bad",
				Assets:       sdk.NewInt64Coin("uusd", 100),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid owner address",
			msg: types.MsgSwapOutRequest{
				Owner:        "bad",
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 100),
			},
			expectedErr: fmt.Errorf("invalid owner address: %q", "bad"),
		},
		{
			name: "invalid asset denom",
			msg: types.MsgSwapOutRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)},
			},
			expectedErr: fmt.Errorf("invalid assets coin %v: %w", sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)}, fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
		{
			name: "zero amount",
			msg: types.MsgSwapOutRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Errorf("invalid amount: assets %s must be greater than zero", "uusd"),
		},
		{
			name: "deprecated redeem denom with valid format is allowed",
			msg: types.MsgSwapOutRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 100),
				RedeemDenom:  "uusd",
			},
			expectedErr: nil,
		},
		{
			name: "deprecated redeem denom with invalid format (not allowed)",
			msg: types.MsgSwapOutRequest{
				Owner:        owner,
				VaultAddress: vault,
				Assets:       sdk.NewInt64Coin("uusd", 100),
				RedeemDenom:  "inv@lid$",
			},
			expectedErr: fmt.Errorf("invalid redeem denom: %w", fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgUpdateMinInterestRateRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgUpdateMinInterestRateRequest
		expectedErr error
	}{
		{
			name: "valid with negative min rate",
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MinRate:      "-0.75",
			},
			expectedErr: nil,
		},
		{
			name: "empty min rate clears",
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MinRate:      "",
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        "bad",
				VaultAddress: addr,
				MinRate:      "0.10",
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        addr,
				VaultAddress: "bad",
				MinRate:      "0.10",
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid min rate",
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MinRate:      "abc",
			},
			expectedErr: fmt.Errorf("invalid min rate: %q", "abc"),
		},
		{
			name: "over-length min rate is rejected without echoing the input",
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MinRate:      strings.Repeat("9", types.MaxDecStringLength+1),
			},
			expectedErr: fmt.Errorf("invalid min rate: must be at most %d characters", types.MaxDecStringLength),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgUpdateMaxInterestRateRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgUpdateMaxInterestRateRequest
		expectedErr error
	}{
		{
			name: "valid with positive max rate",
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MaxRate:      "3.25",
			},
			expectedErr: nil,
		},
		{
			name: "empty max rate clears",
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MaxRate:      "",
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        "bad",
				VaultAddress: addr,
				MaxRate:      "2.0",
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        addr,
				VaultAddress: "bad",
				MaxRate:      "2.0",
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid max rate",
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MaxRate:      "notanumber",
			},
			expectedErr: fmt.Errorf("invalid max rate: %q", "notanumber"),
		},
		{
			name: "over-length max rate is rejected without echoing the input",
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        addr,
				VaultAddress: addr,
				MaxRate:      strings.Repeat("9", types.MaxDecStringLength+1),
			},
			expectedErr: fmt.Errorf("invalid max rate: must be at most %d characters", types.MaxDecStringLength),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgUpdateInterestRateRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgUpdateInterestRateRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    addr,
				VaultAddress: addr,
				NewRate:      "1.5",
			},
			expectedErr: nil,
		},
		{
			name: "invalid authority",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    "bad",
				VaultAddress: addr,
				NewRate:      "1.5",
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    addr,
				VaultAddress: "bad",
				NewRate:      "1.5",
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid new rate",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    addr,
				VaultAddress: addr,
				NewRate:      "bad",
			},
			expectedErr: fmt.Errorf("invalid interest rate: %q", "bad"),
		},
		{
			name: "over-length new rate is rejected without echoing the input",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    addr,
				VaultAddress: addr,
				NewRate:      strings.Repeat("9", types.MaxDecStringLength+1),
			},
			expectedErr: fmt.Errorf("invalid interest rate: must be at most %d characters", types.MaxDecStringLength),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgUpdateWithdrawalDelayRequest_ValidateBasic(t *testing.T) {
	authority := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgUpdateWithdrawalDelayRequest
		expectedErr error
	}{
		{
			name: "valid - zero delay",
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              authority,
				VaultAddress:           vault,
				WithdrawalDelaySeconds: 0,
			},
			expectedErr: nil,
		},
		{
			name: "valid - max delay",
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              authority,
				VaultAddress:           vault,
				WithdrawalDelaySeconds: types.MaxWithdrawalDelay,
			},
			expectedErr: nil,
		},
		{
			name: "invalid authority",
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              "bad",
				VaultAddress:           vault,
				WithdrawalDelaySeconds: 1,
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              authority,
				VaultAddress:           "bad",
				WithdrawalDelaySeconds: 1,
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "delay exceeds max",
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              authority,
				VaultAddress:           vault,
				WithdrawalDelaySeconds: types.MaxWithdrawalDelay + 1,
			},
			expectedErr: fmt.Errorf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgToggleSwapInRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgToggleSwapInRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgToggleSwapInRequest{
				Admin:        addr,
				VaultAddress: addr,
				Enabled:      true,
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgToggleSwapInRequest{
				Admin:        "bad",
				VaultAddress: addr,
				Enabled:      false,
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgToggleSwapInRequest{
				Admin:        addr,
				VaultAddress: "bad",
				Enabled:      true,
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgToggleSwapOutRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgToggleSwapOutRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgToggleSwapOutRequest{
				Admin:        addr,
				VaultAddress: addr,
				Enabled:      true,
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgToggleSwapOutRequest{
				Admin:        "bad",
				VaultAddress: addr,
				Enabled:      false,
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgToggleSwapOutRequest{
				Admin:        addr,
				VaultAddress: "bad",
				Enabled:      true,
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgDepositInterestFundsRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgDepositInterestFundsRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: nil,
		},
		{
			name: "zero amount",
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Errorf("deposit amount must be greater than zero"),
		},
		{
			name: "invalid authority",
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    "bad",
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    addr,
				VaultAddress: "bad",
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid denom",
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(1000)},
			},
			expectedErr: fmt.Errorf("invalid deposit amount: %w", fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgWithdrawInterestFundsRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgWithdrawInterestFundsRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: nil,
		},
		{
			name: "zero amount",
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Errorf("withdrawal amount must be greater than zero"),
		},
		{
			name: "invalid authority",
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    "bad",
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    addr,
				VaultAddress: "bad",
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid denom",
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(1000)},
			},
			expectedErr: fmt.Errorf("invalid withdrawal amount: %w", fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgDepositPrincipalFundsRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgDepositPrincipalFundsRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: nil,
		},
		{
			name: "zero amount",
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Errorf("deposit amount must be greater than zero"),
		},
		{
			name: "invalid authority",
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    "bad",
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: "bad",
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid denom",
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(1000)},
			},
			expectedErr: fmt.Errorf("invalid deposit amount: %w", fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgWithdrawPrincipalFundsRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgWithdrawPrincipalFundsRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: nil,
		},
		{
			name: "zero amount",
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Errorf("withdrawal amount must be greater than zero"),
		},
		{
			name: "invalid authority",
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    "bad",
				VaultAddress: addr,
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: "bad",
				Amount:       sdk.NewInt64Coin("uusd", 1000),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid denom",
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    addr,
				VaultAddress: addr,
				Amount:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(1000)},
			},
			expectedErr: fmt.Errorf("invalid withdrawal amount: %w", fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgExpeditePendingSwapOutRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgExpeditePendingSwapOutRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgExpeditePendingSwapOutRequest{
				Authority: addr,
				RequestId: 1,
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgExpeditePendingSwapOutRequest{
				Authority: "bad",
				RequestId: 1,
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgPauseVaultRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgPauseVaultRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgPauseVaultRequest{
				Authority:    addr,
				VaultAddress: addr,
				Reason:       "rebalancing",
			},
			expectedErr: nil,
		},
		{
			name: "invalid authority",
			msg: types.MsgPauseVaultRequest{
				Authority:    "bad",
				VaultAddress: addr,
				Reason:       "rebalancing",
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgPauseVaultRequest{
				Authority:    addr,
				VaultAddress: "bad",
				Reason:       "rebalancing",
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "empty reason",
			msg: types.MsgPauseVaultRequest{
				Authority:    addr,
				VaultAddress: addr,
				Reason:       "",
			},
			expectedErr: fmt.Errorf("reason cannot be empty"),
		},
		{
			name: "reason at max length",
			msg: types.MsgPauseVaultRequest{
				Authority:    addr,
				VaultAddress: addr,
				Reason:       strings.Repeat("a", 200),
			},
			expectedErr: nil,
		},
		{
			name: "reason exceeds max length",
			msg: types.MsgPauseVaultRequest{
				Authority:    addr,
				VaultAddress: addr,
				Reason:       strings.Repeat("a", 201),
			},
			expectedErr: fmt.Errorf("reason too long (expected <= 200, actual: 201)"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgUnpauseVaultRequest_ValidateBasic(t *testing.T) {
	addr := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgUnpauseVaultRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgUnpauseVaultRequest{
				Authority:    addr,
				VaultAddress: addr,
			},
			expectedErr: nil,
		},
		{
			name: "invalid authority",
			msg: types.MsgUnpauseVaultRequest{
				Authority:    "bad",
				VaultAddress: addr,
			},
			expectedErr: fmt.Errorf("invalid authority address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgUnpauseVaultRequest{
				Authority:    addr,
				VaultAddress: "bad",
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgSetBridgeAddressRequest_ValidateBasic(t *testing.T) {
	admin := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32
	bridge := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgSetBridgeAddressRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         admin,
				VaultAddress:  vault,
				BridgeAddress: bridge,
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         "bad",
				VaultAddress:  vault,
				BridgeAddress: bridge,
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         admin,
				VaultAddress:  "bad",
				BridgeAddress: bridge,
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid bridge",
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         admin,
				VaultAddress:  vault,
				BridgeAddress: "bad",
			},
			expectedErr: fmt.Errorf("invalid bridge address: %q", "bad"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for test case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error message mismatch for test case %q", tc.name)
			} else {
				assert.NoError(t, err, "unexpected error for test case %q", tc.name)
			}
		})
	}
}

func TestMsgToggleBridgeRequest_ValidateBasic(t *testing.T) {
	admin := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgToggleBridgeRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgToggleBridgeRequest{
				Admin:        admin,
				VaultAddress: vault,
				Enabled:      true,
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgToggleBridgeRequest{
				Admin:        "bad",
				VaultAddress: vault,
				Enabled:      false,
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgToggleBridgeRequest{
				Admin:        admin,
				VaultAddress: "bad",
				Enabled:      true,
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for test case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error message mismatch for test case %q", tc.name)
			} else {
				assert.NoError(t, err, "unexpected error for test case %q", tc.name)
			}
		})
	}
}

func TestMsgBridgeMintSharesRequest_ValidateBasic(t *testing.T) {
	bridge := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgBridgeMintSharesRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgBridgeMintSharesRequest{
				Bridge:       bridge,
				VaultAddress: vault,
				Shares:       sdk.NewInt64Coin("vaultshare", 100),
			},
			expectedErr: nil,
		},
		{
			name: "invalid bridge",
			msg: types.MsgBridgeMintSharesRequest{
				Bridge:       "bad",
				VaultAddress: vault,
				Shares:       sdk.NewInt64Coin("vaultshare", 100),
			},
			expectedErr: fmt.Errorf("invalid bridge address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgBridgeMintSharesRequest{
				Bridge:       bridge,
				VaultAddress: "bad",
				Shares:       sdk.NewInt64Coin("vaultshare", 100),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid shares denom",
			msg: types.MsgBridgeMintSharesRequest{
				Bridge:       bridge,
				VaultAddress: vault,
				Shares:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)},
			},
			expectedErr: fmt.Errorf("invalid shares coin %v: %w", sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)}, fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
		{
			name: "zero shares amount",
			msg: types.MsgBridgeMintSharesRequest{
				Bridge:       bridge,
				VaultAddress: vault,
				Shares:       sdk.NewInt64Coin("vaultshare", 0),
			},
			expectedErr: fmt.Errorf("shares amount must be greater than zero"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for test case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error message mismatch for test case %q", tc.name)
			} else {
				assert.NoError(t, err, "unexpected error for test case %q", tc.name)
			}
		})
	}
}

func TestMsgBridgeBurnSharesRequest_ValidateBasic(t *testing.T) {
	bridge := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgBridgeBurnSharesRequest
		expectedErr error
	}{
		{
			name: "valid",
			msg: types.MsgBridgeBurnSharesRequest{
				Bridge:       bridge,
				VaultAddress: vault,
				Shares:       sdk.NewInt64Coin("vaultshare", 100),
			},
			expectedErr: nil,
		},
		{
			name: "invalid bridge",
			msg: types.MsgBridgeBurnSharesRequest{
				Bridge:       "bad",
				VaultAddress: vault,
				Shares:       sdk.NewInt64Coin("vaultshare", 100),
			},
			expectedErr: fmt.Errorf("invalid bridge address: %q", "bad"),
		},
		{
			name: "invalid vault",
			msg: types.MsgBridgeBurnSharesRequest{
				Bridge:       bridge,
				VaultAddress: "bad",
				Shares:       sdk.NewInt64Coin("vaultshare", 100),
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid shares denom",
			msg: types.MsgBridgeBurnSharesRequest{
				Bridge:       bridge,
				VaultAddress: vault,
				Shares:       sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)},
			},
			expectedErr: fmt.Errorf("invalid shares coin %v: %w", sdk.Coin{Denom: "inv@lid$", Amount: sdkmath.NewInt(100)}, fmt.Errorf("invalid denom: %s", "inv@lid$")),
		},
		{
			name: "zero shares amount",
			msg: types.MsgBridgeBurnSharesRequest{
				Bridge:       bridge,
				VaultAddress: vault,
				Shares:       sdk.NewInt64Coin("vaultshare", 0),
			},
			expectedErr: fmt.Errorf("shares amount must be greater than zero"),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for test case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error message mismatch for test case %q", tc.name)
			} else {
				assert.NoError(t, err, "unexpected error for test case %q", tc.name)
			}
		})
	}
}

func TestMsgSetAssetManagerRequest_ValidateBasic(t *testing.T) {
	admin := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32
	manager := utils.TestAddress().Bech32

	tests := []struct {
		name        string
		msg         types.MsgSetAssetManagerRequest
		expectedErr error
	}{
		{
			name: "valid - set asset manager",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        admin,
				VaultAddress: vault,
				AssetManager: manager,
			},
			expectedErr: nil,
		},
		{
			name: "valid - clear asset manager with empty string",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        admin,
				VaultAddress: vault,
				AssetManager: "",
			},
			expectedErr: nil,
		},
		{
			name: "invalid admin",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        "bad",
				VaultAddress: vault,
				AssetManager: manager,
			},
			expectedErr: fmt.Errorf("invalid admin address: %q", "bad"),
		},
		{
			name: "invalid vault address",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        admin,
				VaultAddress: "bad",
				AssetManager: manager,
			},
			expectedErr: fmt.Errorf("invalid vault address: %q", "bad"),
		},
		{
			name: "invalid asset manager address string",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        admin,
				VaultAddress: vault,
				AssetManager: "bad",
			},
			expectedErr: fmt.Errorf("invalid asset manager address: %q", "bad"),
		},
		{
			name: "valid - asset manager equals admin (allowed)",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        admin,
				VaultAddress: vault,
				AssetManager: admin,
			},
			expectedErr: nil,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectedErr != nil {
				assert.Error(t, err, "expected error for case %q", tc.name)
				assert.Contains(t, err.Error(), tc.expectedErr.Error(), "error should contain expected substring for case %q", tc.name)
			} else {
				assert.NoError(t, err, "expected no error for case %q", tc.name)
			}
		})
	}
}

func TestMsgUpdateSwapLimits_ValidateBasic(t *testing.T) {
	authority := utils.TestAddress().Bech32
	vault := utils.TestAddress().Bech32

	type testCase struct {
		name        string
		msg         sdk.Msg
		expectedErr string
	}

	runTests := func(t *testing.T, tests []testCase) {
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				var err error
				if m, ok := tt.msg.(interface{ ValidateBasic() error }); ok {
					err = m.ValidateBasic()
				} else {
					t.Fatalf("msg does not implement ValidateBasic")
				}

				if tt.expectedErr == "" {
					assert.NoError(t, err, "Test %q: expected no error, but got %v", tt.name, err)
				} else {
					assert.Error(t, err, "Test %q: expected error containing %q, but got none", tt.name, tt.expectedErr)
					if err != nil {
						assert.Contains(t, err.Error(), tt.expectedErr, "Test %q: error message mismatch; expected it to contain %q, but got %q", tt.name, tt.expectedErr, err.Error())
					}
				}
			})
		}
	}

	t.Run("UpdateMinSwapInValue", func(t *testing.T) {
		tests := []testCase{
			{
				name: "valid",
				msg: &types.MsgUpdateMinSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MinSwapInValue: "100",
				},
				expectedErr: "",
			},
			{
				name: "invalid authority",
				msg: &types.MsgUpdateMinSwapInValueRequest{
					Authority:      "bad",
					VaultAddress:   vault,
					MinSwapInValue: "100",
				},
				expectedErr: "invalid authority address",
			},
			{
				name: "invalid vault address",
				msg: &types.MsgUpdateMinSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   "bad",
					MinSwapInValue: "100",
				},
				expectedErr: "invalid vault address",
			},
			{
				name: "invalid value (not int)",
				msg: &types.MsgUpdateMinSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MinSwapInValue: "abc",
				},
				expectedErr: "invalid swap-in limits: invalid min value",
			},
			{
				name: "negative value",
				msg: &types.MsgUpdateMinSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MinSwapInValue: "-1",
				},
				expectedErr: "invalid swap-in limits: min value must be non-negative",
			},
		}
		runTests(t, tests)
	})

	t.Run("UpdateMinSwapOutValue", func(t *testing.T) {
		tests := []testCase{
			{
				name: "valid",
				msg: &types.MsgUpdateMinSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MinSwapOutValue: "200",
				},
				expectedErr: "",
			},
			{
				name: "invalid authority",
				msg: &types.MsgUpdateMinSwapOutValueRequest{
					Authority:       "bad",
					VaultAddress:    vault,
					MinSwapOutValue: "100",
				},
				expectedErr: "invalid authority address",
			},
			{
				name: "invalid vault address",
				msg: &types.MsgUpdateMinSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    "bad",
					MinSwapOutValue: "100",
				},
				expectedErr: "invalid vault address",
			},
			{
				name: "invalid value (not int)",
				msg: &types.MsgUpdateMinSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MinSwapOutValue: "abc",
				},
				expectedErr: "invalid swap-out limits: invalid min value",
			},
			{
				name: "negative value",
				msg: &types.MsgUpdateMinSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MinSwapOutValue: "-5",
				},
				expectedErr: "invalid swap-out limits: min value must be non-negative",
			},
		}
		runTests(t, tests)
	})

	t.Run("UpdateMaxSwapInValue", func(t *testing.T) {
		tests := []testCase{
			{
				name: "valid",
				msg: &types.MsgUpdateMaxSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MaxSwapInValue: "1000",
				},
				expectedErr: "",
			},
			{
				name: "invalid authority",
				msg: &types.MsgUpdateMaxSwapInValueRequest{
					Authority:      "bad",
					VaultAddress:   vault,
					MaxSwapInValue: "1000",
				},
				expectedErr: "invalid authority address",
			},
			{
				name: "invalid vault address",
				msg: &types.MsgUpdateMaxSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   "bad",
					MaxSwapInValue: "1000",
				},
				expectedErr: "invalid vault address",
			},
			{
				name: "invalid value (not int)",
				msg: &types.MsgUpdateMaxSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MaxSwapInValue: "abc",
				},
				expectedErr: "invalid swap-in limits: invalid max value",
			},
			{
				name: "negative value",
				msg: &types.MsgUpdateMaxSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MaxSwapInValue: "-10",
				},
				expectedErr: "invalid swap-in limits: max value must be non-negative",
			},
			{
				name: "zero value (invalid)",
				msg: &types.MsgUpdateMaxSwapInValueRequest{
					Authority:      authority,
					VaultAddress:   vault,
					MaxSwapInValue: "0",
				},
				expectedErr: "invalid swap-in limits: max value cannot be zero",
			},
		}
		runTests(t, tests)
	})

	t.Run("UpdateMaxSwapOutValue", func(t *testing.T) {
		tests := []testCase{
			{
				name: "valid",
				msg: &types.MsgUpdateMaxSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MaxSwapOutValue: "2000",
				},
				expectedErr: "",
			},
			{
				name: "invalid authority",
				msg: &types.MsgUpdateMaxSwapOutValueRequest{
					Authority:       "bad",
					VaultAddress:    vault,
					MaxSwapOutValue: "1000",
				},
				expectedErr: "invalid authority address",
			},
			{
				name: "invalid vault address",
				msg: &types.MsgUpdateMaxSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    "bad",
					MaxSwapOutValue: "1000",
				},
				expectedErr: "invalid vault address",
			},
			{
				name: "invalid value (not int)",
				msg: &types.MsgUpdateMaxSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MaxSwapOutValue: "abc",
				},
				expectedErr: "invalid swap-out limits: invalid max value",
			},
			{
				name: "negative value",
				msg: &types.MsgUpdateMaxSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MaxSwapOutValue: "-100",
				},
				expectedErr: "invalid swap-out limits: max value must be non-negative",
			},
			{
				name: "zero value (invalid)",
				msg: &types.MsgUpdateMaxSwapOutValueRequest{
					Authority:       authority,
					VaultAddress:    vault,
					MaxSwapOutValue: "0",
				},
				expectedErr: "invalid swap-out limits: max value cannot be zero",
			},
		}
		runTests(t, tests)
	})
}

func TestMsgUpdateVaultNAVRequest_ValidateBasic(t *testing.T) {
	addr := NewTestAddress()

	RunValidateBasicTable(t, []validateBasicCase{
		{
			name: "valid",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
				Source:       "oracle",
			},
		},
		{
			name: "valid with empty source",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
			},
		},
		{
			name: "invalid signer",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       "bad",
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErr: "invalid signer address",
		},
		{
			name: "invalid vault address",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: "bad",
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErr: "invalid vault address",
		},
		{
			name: "invalid denom",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "bad denom",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErr: "invalid denom",
		},
		{
			name: "invalid price coin",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.Coin{Denom: "under", Amount: sdkmath.NewInt(-1)},
				Volume:       sdkmath.NewInt(1),
			},
			expectedErr: "invalid price coin",
		},
		{
			// A zero price is allowed at this stateless layer; the accepted-denom
			// "must be positive" rule is enforced statefully in the keeper.
			name: "zero price is allowed statelessly",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 0),
				Volume:       sdkmath.NewInt(1),
			},
		},
		{
			name: "denom equals price denom",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("rwa", 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErr: `NAV denom "rwa" and price denom must differ`,
		},
		{
			name: "nil volume",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
			},
			expectedErr: "volume must be positive",
		},
		{
			name: "zero volume",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.ZeroInt(),
			},
			expectedErr: "volume must be positive",
		},
		{
			name: "negative volume",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(-1),
			},
			expectedErr: "volume must be positive",
		},
		{
			name: "source at max length",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
				Source:       strings.Repeat("a", types.MaxNAVSourceLength),
			},
		},
		{
			name: "source too long",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       sdkmath.NewInt(1),
				Source:       strings.Repeat("a", types.MaxNAVSourceLength+1),
			},
			expectedErr: "source too long",
		},
		{
			name: "price amount at the magnitude ceiling",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewCoin("under", maxNAVComponent()),
				Volume:       sdkmath.NewInt(1),
			},
		},
		{
			name: "price amount one bit above the magnitude ceiling",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewCoin("under", maxNAVComponent().AddRaw(1)),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErr: "NAV price amount",
		},
		{
			name: "volume one bit above the magnitude ceiling",
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin("under", 100),
				Volume:       maxNAVComponent().AddRaw(1),
			},
			expectedErr: "NAV volume",
		},
	})
}

// maxNAVComponent returns the largest NAV price amount or volume that passes the magnitude bound.
func maxNAVComponent() sdkmath.Int {
	return sdkmath.NewIntFromBigInt(new(big.Int).Sub(new(big.Int).Lsh(big.NewInt(1), types.MaxNAVComponentBits), big.NewInt(1)))
}

func TestMsgRepriceVaultRequest_ValidateBasic(t *testing.T) {
	addr := NewTestAddress()
	validNAV := func(denom string) types.NAVUpdate {
		return types.NAVUpdate{
			Denom:  denom,
			Price:  sdk.NewInt64Coin("under", 100),
			Volume: sdkmath.NewInt(1),
			Source: "oracle",
		}
	}
	batchOf := func(n int) []types.NAVUpdate {
		navs := make([]types.NAVUpdate, n)
		for i := range navs {
			navs[i] = validNAV(fmt.Sprintf("loan%d", i))
		}
		return navs
	}

	RunValidateBasicTable(t, []validateBasicCase{
		{
			name: "valid single update",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs:         []types.NAVUpdate{validNAV("rwa")},
			},
		},
		{
			name: "valid batch of distinct denoms",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs:         []types.NAVUpdate{validNAV("loan1"), validNAV("loan2"), validNAV("loan3")},
			},
		},
		{
			name: "batch at the size ceiling",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs:         batchOf(types.MaxRepriceBatchSize),
			},
		},
		{
			name: "batch one entry above the size ceiling",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs:         batchOf(types.MaxRepriceBatchSize + 1),
			},
			expectedErr: "too many NAV updates",
		},
		{
			name: "invalid signer address",
			msg: types.MsgRepriceVaultRequest{
				Signer:       "not-an-address",
				VaultAddress: addr,
				Navs:         []types.NAVUpdate{validNAV("rwa")},
			},
			expectedErr: "invalid signer address",
		},
		{
			name: "invalid vault address",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: "not-an-address",
				Navs:         []types.NAVUpdate{validNAV("rwa")},
			},
			expectedErr: "invalid vault address",
		},
		{
			name: "empty batch has nothing to reprice",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
			},
			expectedErr: "at least one NAV update is required",
		},
		{
			name: "duplicate denom in the batch is ambiguous",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs:         []types.NAVUpdate{validNAV("rwa"), validNAV("rwa")},
			},
			expectedErr: `duplicate NAV update for denom "rwa" at index 1`,
		},
		{
			name: "invalid denom in the batch reports its index",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs:         []types.NAVUpdate{validNAV("rwa"), validNAV("bad denom")},
			},
			expectedErr: "invalid NAV update at index 1: invalid denom",
		},
		{
			name: "invalid price coin in the batch",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom:  "rwa",
					Price:  sdk.Coin{Denom: "under", Amount: sdkmath.NewInt(-1)},
					Volume: sdkmath.NewInt(1),
				}},
			},
			expectedErr: "invalid price coin",
		},
		{
			name: "zero price is allowed statelessly so a held asset can be written down",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom:  "rwa",
					Price:  sdk.NewInt64Coin("under", 0),
					Volume: sdkmath.NewInt(1),
				}},
			},
		},
		{
			name: "denom equals price denom",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom:  "rwa",
					Price:  sdk.NewInt64Coin("rwa", 100),
					Volume: sdkmath.NewInt(1),
				}},
			},
			expectedErr: `NAV denom "rwa" and price denom must differ`,
		},
		{
			name: "nil volume",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom: "rwa",
					Price: sdk.NewInt64Coin("under", 100),
				}},
			},
			expectedErr: "volume must be positive",
		},
		{
			name: "negative volume",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom:  "rwa",
					Price:  sdk.NewInt64Coin("under", 100),
					Volume: sdkmath.NewInt(-1),
				}},
			},
			expectedErr: "volume must be positive",
		},
		{
			name: "source too long",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom:  "rwa",
					Price:  sdk.NewInt64Coin("under", 100),
					Volume: sdkmath.NewInt(1),
					Source: strings.Repeat("a", types.MaxNAVSourceLength+1),
				}},
			},
			expectedErr: "source too long",
		},
		{
			name: "price amount one bit above the magnitude ceiling",
			msg: types.MsgRepriceVaultRequest{
				Signer:       addr,
				VaultAddress: addr,
				Navs: []types.NAVUpdate{{
					Denom:  "rwa",
					Price:  sdk.NewCoin("under", maxNAVComponent().AddRaw(1)),
					Volume: sdkmath.NewInt(1),
				}},
			},
			expectedErr: "NAV price amount",
		},
	})
}

func TestMsgRemoveVaultNAVRequest_ValidateBasic(t *testing.T) {
	addr := NewTestAddress()

	RunValidateBasicTable(t, []validateBasicCase{
		{
			name: "valid",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "rwa",
			},
		},
		{
			name: "valid metadata value owner denom",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "nft/scope1qzge0zaztu65tx5x5llv5xc9ztsqxlkwel",
			},
		},
		{
			name: "invalid signer",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       "bad",
				VaultAddress: addr,
				Denom:        "rwa",
			},
			expectedErr: "invalid signer address",
		},
		{
			name: "invalid vault address",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       addr,
				VaultAddress: "bad",
				Denom:        "rwa",
			},
			expectedErr: "invalid vault address",
		},
		{
			name: "invalid denom",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
				Denom:        "bad denom",
			},
			expectedErr: "invalid denom",
		},
		{
			name: "empty denom",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       addr,
				VaultAddress: addr,
			},
			expectedErr: "invalid denom",
		},
	})
}

func TestMsgUpdateNAVAuthorityRequest_ValidateBasic(t *testing.T) {
	addr := NewTestAddress()

	RunValidateBasicTable(t, []validateBasicCase{
		{
			name: "valid",
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       addr,
				VaultAddress: addr,
				NewAuthority: addr,
			},
		},
		{
			name: "valid with empty new authority (resets to admin)",
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       addr,
				VaultAddress: addr,
				NewAuthority: "",
			},
		},
		{
			name: "invalid signer",
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       "bad",
				VaultAddress: addr,
				NewAuthority: addr,
			},
			expectedErr: "invalid signer address",
		},
		{
			name: "invalid vault address",
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       addr,
				VaultAddress: "bad",
				NewAuthority: addr,
			},
			expectedErr: "invalid vault address",
		},
		{
			name: "invalid new authority",
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       addr,
				VaultAddress: addr,
				NewAuthority: "bad",
			},
			expectedErr: "invalid new authority address",
		},
	})
}

func TestMsgAcceptAssetRequest_ValidateBasic(t *testing.T) {
	authority := NewTestAddress()
	vaultAddr := NewTestAddress()
	source := NewTestAddress()

	approvedPayment := func(mutate func(*types.Payment)) types.Payment {
		payment := types.Payment{
			Source:       source,
			SourceAmount: sdk.NewCoins(sdk.NewInt64Coin("rwacoin", 10)),
			Target:       vaultAddr,
			TargetAmount: sdk.NewCoins(sdk.NewInt64Coin("under", 5)),
			ExternalId:   "payment-1",
		}
		if mutate != nil {
			mutate(&payment)
		}
		return payment
	}

	RunValidateBasicTable(t, []validateBasicCase{
		{
			name: "valid",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(nil),
			},
		},
		{
			name: "valid with empty external id",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.ExternalId = "" }),
			},
		},
		{
			name: "valid with max length external id",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.ExternalId = strings.Repeat("x", 100) }),
			},
		},
		{
			name: "valid with a zero-priced leg",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.TargetAmount = sdk.NewCoins() }),
			},
		},
		{
			name: "invalid authority",
			msg: types.MsgAcceptAssetRequest{
				Authority:    "bad",
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(nil),
			},
			expectedErr: "invalid authority address",
		},
		{
			name: "empty authority",
			msg: types.MsgAcceptAssetRequest{
				Authority:    "",
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(nil),
			},
			expectedErr: "invalid authority address",
		},
		{
			name: "invalid vault address",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: "bad",
				Payment:      approvedPayment(nil),
			},
			expectedErr: "invalid vault address",
		},
		{
			name: "invalid payment source",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.Source = "bad" }),
			},
			expectedErr: "invalid payment: invalid source address",
		},
		{
			name: "empty payment source",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.Source = "" }),
			},
			expectedErr: "invalid payment: invalid source address",
		},
		{
			name: "invalid payment target",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.Target = "bad" }),
			},
			expectedErr: "invalid payment: invalid target address",
		},
		{
			name: "empty payment target",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.Target = "" }),
			},
			expectedErr: "invalid payment: invalid target address",
		},
		{
			name: "unsorted payment source amount",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment: approvedPayment(func(p *types.Payment) {
					p.SourceAmount = sdk.Coins{sdk.NewInt64Coin("zcoin", 1), sdk.NewInt64Coin("acoin", 1)}
				}),
			},
			expectedErr: "invalid payment: invalid source amount",
		},
		{
			name: "zero payment target amount coin",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment: approvedPayment(func(p *types.Payment) {
					p.TargetAmount = sdk.Coins{sdk.NewInt64Coin("under", 0)}
				}),
			},
			expectedErr: "invalid payment: invalid target amount",
		},
		{
			name: "both payment legs zero",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment: approvedPayment(func(p *types.Payment) {
					p.SourceAmount = sdk.NewCoins()
					p.TargetAmount = sdk.NewCoins()
				}),
			},
			expectedErr: "invalid payment: source amount and target amount cannot both be zero",
		},
		{
			name: "external id too long",
			msg: types.MsgAcceptAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Payment:      approvedPayment(func(p *types.Payment) { p.ExternalId = strings.Repeat("x", 101) }),
			},
			expectedErr: "invalid payment: invalid external id: invalid external id \"xxxxx...xxxxx\" (length 101): max length 100",
		},
	})
}

func TestMsgRejectAssetRequest_ValidateBasic(t *testing.T) {
	authority := NewTestAddress()
	vaultAddr := NewTestAddress()
	source := NewTestAddress()

	RunValidateBasicTable(t, []validateBasicCase{
		{
			name: "valid",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Source:       source,
				ExternalId:   "payment-1",
			},
		},
		{
			name: "valid with empty external id",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Source:       source,
				ExternalId:   "",
			},
		},
		{
			name: "valid with max length external id",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Source:       source,
				ExternalId:   strings.Repeat("x", 100),
			},
		},
		{
			name: "invalid authority",
			msg: types.MsgRejectAssetRequest{
				Authority:    "bad",
				VaultAddress: vaultAddr,
				Source:       source,
				ExternalId:   "payment-1",
			},
			expectedErr: "invalid authority address",
		},
		{
			name: "empty authority",
			msg: types.MsgRejectAssetRequest{
				Authority:    "",
				VaultAddress: vaultAddr,
				Source:       source,
				ExternalId:   "payment-1",
			},
			expectedErr: "invalid authority address",
		},
		{
			name: "invalid vault address",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: "bad",
				Source:       source,
				ExternalId:   "payment-1",
			},
			expectedErr: "invalid vault address",
		},
		{
			name: "invalid source",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Source:       "bad",
				ExternalId:   "payment-1",
			},
			expectedErr: "invalid source address",
		},
		{
			name: "empty source",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Source:       "",
				ExternalId:   "payment-1",
			},
			expectedErr: "invalid source address",
		},
		{
			name: "external id too long",
			msg: types.MsgRejectAssetRequest{
				Authority:    authority,
				VaultAddress: vaultAddr,
				Source:       source,
				ExternalId:   strings.Repeat("x", 101),
			},
			expectedErr: "invalid external id: invalid external id \"xxxxx...xxxxx\" (length 101): max length 100",
		},
	})
}
