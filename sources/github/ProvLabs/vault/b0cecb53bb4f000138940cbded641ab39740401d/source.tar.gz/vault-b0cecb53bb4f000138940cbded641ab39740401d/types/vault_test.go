package types_test

import (
	"fmt"
	stdmath "math"
	"math/big"
	"strings"
	"testing"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"
)

func TestVaultAccount_Validate(t *testing.T) {
	validAdmin := utils.TestAddress().Bech32
	validBridgeAddress := utils.TestAddress().Bech32
	validAssetManager := utils.TestAddress().Bech32
	validDenom := "validdenom"
	invalidDenom := "inval!d"
	validInterest := "0.05"
	invalidInterest := "not-a-decimal"

	baseAcc := authtypes.NewBaseAccountWithAddress(sdk.MustAccAddressFromBech32(validAdmin))

	tests := []struct {
		name         string
		vaultAccount types.VaultAccount
		expectedErr  string
	}{
		{
			name: "valid vault account with interest rates (current==desired)",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "valid base account is nil",
			vaultAccount: types.VaultAccount{
				BaseAccount:         nil,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "base account cannot be nil",
		},
		{
			name: "valid vault account with bounds and current==0",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.04",
				MinInterestRate:     "0.03",
				MaxInterestRate:     "0.05",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "invalid admin address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               "invalid-address",
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid admin address",
		},
		{
			name: "empty share denom",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.Coin{Denom: "", Amount: math.NewInt(0)},
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid share denom",
		},
		{
			name: "invalid share denom",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.Coin{Denom: invalidDenom, Amount: math.NewInt(0)},
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid share denom",
		},
		{
			name: "empty underlying assets",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.Coin{Denom: "", Amount: math.NewInt(0)},
			},
			expectedErr: "invalid underlying asset denom: ",
		},
		{
			name: "invalid underlying asset denom",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     invalidDenom,
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: fmt.Sprintf("invalid underlying asset denom: %s", invalidDenom),
		},
		{
			name: "empty payment denom is valid under single-denom semantics",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.Coin{Denom: "", Amount: math.NewInt(0)},
			},
			expectedErr: "",
		},
		{
			name: "payment denom distinct from underlying is rejected as mixed-denom",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "usdc",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: `payment denom "usdc" must be empty or equal underlying asset "uusd"; vaults are single-denom`,
		},
		{
			name: "payment denom with invalid format is rejected as mixed-denom",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "inv@lid$",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: `payment denom "inv@lid$" must be empty or equal underlying asset "uusd"; vaults are single-denom`,
		},
		{
			name: "invalid current interest rate",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: invalidInterest,
				DesiredInterestRate: validInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid current interest rate",
		},
		{
			name: "invalid desired interest rate",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: validInterest,
				DesiredInterestRate: invalidInterest,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid desired interest rate",
		},
		{
			name: "current interest rate above absolute ceiling",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "1000000.0",
				DesiredInterestRate: "1000000.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "exceeds maximum allowed magnitude",
		},
		{
			name: "desired interest rate above absolute ceiling",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "1000000.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid desired interest rate",
		},
		{
			name: "max interest rate above absolute ceiling",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.05",
				MinInterestRate:     "0.01",
				MaxInterestRate:     "1000000.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "exceeds maximum allowed magnitude",
		},
		{
			name: "min interest rate below negative absolute ceiling",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.05",
				MinInterestRate:     "-1000000.0",
				MaxInterestRate:     "0.10",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "exceeds maximum allowed magnitude",
		},
		{
			name: "interest rate at absolute ceiling is allowed",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: types.MaxAbsInterestRate,
				MaxInterestRate:     types.MaxAbsInterestRate,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "valid min/max equal",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.10",
				MinInterestRate:     "0.10",
				MaxInterestRate:     "0.10",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "valid min < max",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.03",
				MinInterestRate:     "0.01",
				MaxInterestRate:     "0.05",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "invalid min format (max empty)",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.00",
				MinInterestRate:     "nope",
				MaxInterestRate:     "",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid min interest rate",
		},
		{
			name: "invalid max format (min empty)",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.00",
				MinInterestRate:     "",
				MaxInterestRate:     "nope",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid max interest rate",
		},
		{
			name: "min > max => error",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.07",
				MinInterestRate:     "0.08",
				MaxInterestRate:     "0.05",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "cannot be greater than maximum interest rate",
		},
		{
			name: "desired < min => error",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.02",
				MinInterestRate:     "0.03",
				MaxInterestRate:     "",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "less than minimum interest rate",
		},
		{
			name: "desired > max => error",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.06",
				MinInterestRate:     "",
				MaxInterestRate:     "0.05",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "greater than maximum interest rate",
		},
		{
			name: "current non-zero and not equal desired => error",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.03",
				DesiredInterestRate: "0.04",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "current interest rate must be zero or equal to desired",
		},
		{
			name: "min only and desired == min => ok",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.03",
				MinInterestRate:     "0.03",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "max only and desired == max => ok",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.00",
				DesiredInterestRate: "0.07",
				MaxInterestRate:     "0.07",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "invalid total shares (negative)",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.Coin{Denom: validDenom, Amount: math.NewInt(-100)},
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "total shares cannot be negative",
		},
		{
			name: "valid bridge address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				BridgeAddress:       validBridgeAddress,
				BridgeEnabled:       true,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "invalid bridge address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				BridgeAddress:       "invalid-bridge-address",
				BridgeEnabled:       true,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid bridge address",
		},
		{
			name: "bridge enabled with no address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				BridgeAddress:       "",
				BridgeEnabled:       true,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "bridge cannot be enabled without a bridge address",
		},
		{
			name: "paused vault carrying attribution",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
				Paused:              true,
				PausedBy:            validAdmin,
				PausedForced:        true,
			},
			expectedErr: "",
		},
		{
			name: "paused by an invalid address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
				Paused:              true,
				PausedBy:            invalidDenom,
			},
			expectedErr: "invalid paused by address",
		},
		{
			name: "unpaused vault still naming a pauser",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
				PausedBy:            validAdmin,
			},
			expectedErr: "unpaused vault cannot carry pause attribution",
		},
		{
			name: "unpaused vault still marked force-paused",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
				PausedForced:        true,
			},
			expectedErr: "unpaused vault cannot carry pause attribution",
		},
		{
			name: "asset manager set with valid address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				AssetManager:        validAssetManager,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "asset manager set with invalid address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				AssetManager:        "not-a-bech32",
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid asset manager address",
		},
		{
			name: "negative period start",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				PeriodStart:         -1,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "period start cannot be negative",
		},
		{
			name: "negative period timeout",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				PeriodTimeout:       -1,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "period timeout cannot be negative",
		},
		{
			name: "negative fee period start",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				FeePeriodStart:      -1,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "fee period start cannot be negative",
		},
		{
			name: "negative fee period timeout",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				FeePeriodTimeout:    -1,
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "fee period timeout cannot be negative",
		},
		{
			name: "outstanding AUM fee denom mismatch",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("wrong", 100),
			},
			expectedErr: "outstanding AUM fee denom wrong does not match underlying asset uusd",
		},
		{
			name: "negative outstanding AUM fee",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.Coin{Denom: "uusd", Amount: math.NewInt(-1)},
			},
			expectedErr: "outstanding AUM fee cannot be negative",
		},
		{
			name: "outstanding AUM fee with nil amount is rejected before it can panic consensus math",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.Coin{},
			},
			expectedErr: "outstanding AUM fee amount cannot be nil; use a zero coin of the underlying asset \"uusd\"",
		},
		{
			name: "non-zero outstanding AUM fee with empty denom",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.Coin{Denom: "", Amount: math.NewInt(100)},
			},
			expectedErr: "outstanding AUM fee denom  does not match underlying asset uusd",
		},
		{
			name: "invalid swap-in limits",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
				MinSwapInValue:      "abc",
			},
			expectedErr: "failed to validate swap-in limits: invalid min value: abc",
		},
		{
			name: "invalid swap-out limits",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
				MinSwapOutValue:     "1000",
				MaxSwapOutValue:     "500",
			},
			expectedErr: "failed to validate swap-out limits: min value 1000 cannot be greater than max value 500",
		},
		{
			name: "invalid nav authority address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				NavAuthority:        "not-a-bech32",
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "invalid nav authority address",
		},
		{
			name: "valid nav authority address",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				NavAuthority:        validAdmin,
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "empty nav authority is valid (treated as admin)",
			vaultAccount: types.VaultAccount{
				BaseAccount:         baseAcc,
				Admin:               validAdmin,
				NavAuthority:        "",
				TotalShares:         sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:     "uusd",
				PaymentDenom:        "uusd",
				CurrentInterestRate: "0.0",
				DesiredInterestRate: "0.0",
				OutstandingAumFee:   sdk.NewInt64Coin("uusd", 0),
			},
			expectedErr: "",
		},
		{
			name: "withdrawal delay at the maximum is valid",
			vaultAccount: types.VaultAccount{
				BaseAccount:            baseAcc,
				Admin:                  validAdmin,
				TotalShares:            sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:        "uusd",
				PaymentDenom:           "uusd",
				CurrentInterestRate:    "0.0",
				DesiredInterestRate:    "0.0",
				OutstandingAumFee:      sdk.NewInt64Coin("uusd", 0),
				WithdrawalDelaySeconds: types.MaxWithdrawalDelay,
			},
			expectedErr: "",
		},
		{
			name: "withdrawal delay one second over the maximum",
			vaultAccount: types.VaultAccount{
				BaseAccount:            baseAcc,
				Admin:                  validAdmin,
				TotalShares:            sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:        "uusd",
				PaymentDenom:           "uusd",
				CurrentInterestRate:    "0.0",
				DesiredInterestRate:    "0.0",
				OutstandingAumFee:      sdk.NewInt64Coin("uusd", 0),
				WithdrawalDelaySeconds: types.MaxWithdrawalDelay + 1,
			},
			expectedErr: fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
		{
			name: "withdrawal delay at MaxUint64 truncates to a negative queue key",
			vaultAccount: types.VaultAccount{
				BaseAccount:            baseAcc,
				Admin:                  validAdmin,
				TotalShares:            sdk.NewInt64Coin(validDenom, 0),
				UnderlyingAsset:        "uusd",
				PaymentDenom:           "uusd",
				CurrentInterestRate:    "0.0",
				DesiredInterestRate:    "0.0",
				OutstandingAumFee:      sdk.NewInt64Coin("uusd", 0),
				WithdrawalDelaySeconds: stdmath.MaxUint64,
			},
			expectedErr: fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.vaultAccount.Validate()
			if tc.expectedErr != "" {
				require.Error(t, err, "expected an error for test case: %s", tc.name)
				require.Contains(t, err.Error(), tc.expectedErr, "error should contain expected message for test case: %s", tc.name)
			} else {
				require.NoError(t, err, "expected no error for test case: %s", tc.name)
			}
		})
	}
}

func TestNewVaultAccount(t *testing.T) {
	admin, _, _, baseAcc := makeNAVAuthorityFixtures()

	tests := []struct {
		name            string
		admin           string
		shareDenom      string
		underlyingAsset string
	}{
		{
			name:            "seeds single-denom defaults for a standard vault",
			admin:           admin,
			shareDenom:      "vshare",
			underlyingAsset: "uusd",
		},
		{
			name:            "seeds single-denom defaults for a distinct underlying asset",
			admin:           admin,
			shareDenom:      "bondshare",
			underlyingAsset: "under",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			vault := types.NewVaultAccount(baseAcc, tc.admin, tc.shareDenom, tc.underlyingAsset, 0, 0, "", "", "", "")
			require.Equal(t, tc.admin, vault.NavAuthority, "NewVaultAccount should default NavAuthority to admin for case: %s", tc.name)
			require.Equal(t, tc.underlyingAsset, vault.PaymentDenom, "NewVaultAccount should set PaymentDenom to the underlying asset for case: %s", tc.name)
			require.Equal(t, tc.underlyingAsset, vault.UnderlyingAsset, "NewVaultAccount should set UnderlyingAsset for case: %s", tc.name)
			require.Equal(t, sdk.NewInt64Coin(tc.underlyingAsset, 0), vault.OutstandingAumFee, "NewVaultAccount should seed OutstandingAumFee as a zero coin of the underlying asset for case: %s", tc.name)
			require.NoError(t, vault.Validate(), "NewVaultAccount should produce a valid single-denom vault for case: %s", tc.name)
		})
	}
}

func TestVaultAccount_GetNAVAuthority(t *testing.T) {
	admin, oracle, _, _ := makeNAVAuthorityFixtures()

	tests := []struct {
		name              string
		navAuthority      string
		vaultAdmin        string
		expectedAuthority string
	}{
		{
			name:              "returns nav_authority when explicitly set",
			navAuthority:      oracle,
			vaultAdmin:        admin,
			expectedAuthority: oracle,
		},
		{
			name:              "returns admin when nav_authority is empty",
			navAuthority:      "",
			vaultAdmin:        admin,
			expectedAuthority: admin,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			vault := &types.VaultAccount{
				Admin:        tc.vaultAdmin,
				NavAuthority: tc.navAuthority,
			}
			got := vault.GetNAVAuthority()
			require.Equal(t, tc.expectedAuthority, got, "GetNAVAuthority mismatch for case: %s", tc.name)
		})
	}
}

func TestVaultAccount_ValidateNAVAuthority(t *testing.T) {
	admin, oracle, other, _ := makeNAVAuthorityFixtures()

	tests := []struct {
		name         string
		navAuthority string
		vaultAdmin   string
		signer       string
		expectedErr  string
	}{
		{
			name:         "signer matches explicit nav authority",
			navAuthority: oracle,
			vaultAdmin:   admin,
			signer:       oracle,
			expectedErr:  "",
		},
		{
			name:         "signer matches admin when nav authority is empty",
			navAuthority: "",
			vaultAdmin:   admin,
			signer:       admin,
			expectedErr:  "",
		},
		{
			name:         "signer does not match explicit nav authority",
			navAuthority: oracle,
			vaultAdmin:   admin,
			signer:       other,
			expectedErr:  "is not the vault NAV authority",
		},
		{
			name:         "admin does not satisfy explicit nav authority",
			navAuthority: oracle,
			vaultAdmin:   admin,
			signer:       admin,
			expectedErr:  "is not the vault NAV authority",
		},
		{
			name:         "non-admin signer fails when nav authority is empty",
			navAuthority: "",
			vaultAdmin:   admin,
			signer:       other,
			expectedErr:  "is not the vault NAV authority",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			vault := &types.VaultAccount{
				Admin:        tc.vaultAdmin,
				NavAuthority: tc.navAuthority,
			}
			err := vault.ValidateNAVAuthority(tc.signer)
			if tc.expectedErr != "" {
				require.Error(t, err, "expected an error for case: %s", tc.name)
				require.Contains(t, err.Error(), tc.expectedErr, "error should contain expected substring for case: %s", tc.name)
			} else {
				require.NoError(t, err, "expected no error for case: %s", tc.name)
			}
		})
	}
}

func TestVaultAccount_ValidatePauseAuthority(t *testing.T) {
	admin, oracle, other, _ := makeNAVAuthorityFixtures()
	manager := utils.TestAddress().Bech32

	tests := []struct {
		name         string
		navAuthority string
		assetManager string
		authority    string
		expectedErr  string
	}{
		{
			name:         "admin may pause",
			navAuthority: oracle,
			assetManager: manager,
			authority:    admin,
		},
		{
			name:         "asset manager may pause",
			navAuthority: oracle,
			assetManager: manager,
			authority:    manager,
		},
		{
			name:         "nav authority may pause",
			navAuthority: oracle,
			assetManager: manager,
			authority:    oracle,
		},
		{
			name:         "admin may pause as the implicit nav authority",
			navAuthority: "",
			assetManager: "",
			authority:    admin,
		},
		{
			name:         "stranger may not pause",
			navAuthority: oracle,
			assetManager: manager,
			authority:    other,
			expectedErr:  "unauthorized authority",
		},
		{
			name:         "asset manager may not pause when unset",
			navAuthority: oracle,
			assetManager: "",
			authority:    manager,
			expectedErr:  "unauthorized authority",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			vault := &types.VaultAccount{
				Admin:        admin,
				NavAuthority: tc.navAuthority,
				AssetManager: tc.assetManager,
			}
			err := vault.ValidatePauseAuthority(tc.authority)
			if tc.expectedErr != "" {
				require.Error(t, err, "expected an error for case: %s", tc.name)
				require.Contains(t, err.Error(), tc.expectedErr, "error should contain expected substring for case: %s", tc.name)
			} else {
				require.NoError(t, err, "expected no error for case: %s", tc.name)
			}
		})
	}
}

func TestVaultAccount_ValidateAssetManagerAuthority(t *testing.T) {
	admin, manager, other, _ := makeNAVAuthorityFixtures()

	tests := []struct {
		name         string
		assetManager string
		authority    string
		expectedErr  string
	}{
		{
			name:         "asset manager may settle",
			assetManager: manager,
			authority:    manager,
			expectedErr:  "",
		},
		{
			name:         "admin may not settle even when an asset manager is set",
			assetManager: manager,
			authority:    admin,
			expectedErr:  "unauthorized authority",
		},
		{
			name:         "stranger may not settle",
			assetManager: manager,
			authority:    other,
			expectedErr:  "unauthorized authority",
		},
		{
			name:         "no asset manager set disables settlement, even for the admin",
			assetManager: "",
			authority:    admin,
			expectedErr:  "no asset manager set",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			vault := types.VaultAccount{
				Admin:        admin,
				AssetManager: tc.assetManager,
			}
			err := vault.ValidateAssetManagerAuthority(tc.authority)
			if tc.expectedErr != "" {
				require.Error(t, err, "expected an error for case: %s", tc.name)
				require.Contains(t, err.Error(), tc.expectedErr, "error should contain expected substring for case: %s", tc.name)
			} else {
				require.NoError(t, err, "expected no error for case: %s", tc.name)
			}
		})
	}
}

func TestNewVaultNAV(t *testing.T) {
	tests := []struct {
		name           string
		denom          string
		price          sdk.Coin
		volume         math.Int
		source         string
		expectedDenom  string
		expectedPrice  sdk.Coin
		expectedVolume math.Int
		expectedSource string
	}{
		{
			name:           "all fields populated",
			denom:          "rwa",
			price:          sdk.NewInt64Coin("under", 1_000_000),
			volume:         math.NewInt(500_000),
			source:         "oracle-x",
			expectedDenom:  "rwa",
			expectedPrice:  sdk.NewInt64Coin("under", 1_000_000),
			expectedVolume: math.NewInt(500_000),
			expectedSource: "oracle-x",
		},
		{
			name:           "empty source is preserved",
			denom:          "bond",
			price:          sdk.NewInt64Coin("usdc", 250),
			volume:         math.NewInt(1),
			source:         "",
			expectedDenom:  "bond",
			expectedPrice:  sdk.NewInt64Coin("usdc", 250),
			expectedVolume: math.NewInt(1),
			expectedSource: "",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			nav := types.NewVaultNAV(tc.denom, tc.price, tc.volume, tc.source)
			require.Equal(t, tc.expectedDenom, nav.Denom, "NewVaultNAV denom mismatch for case: %s", tc.name)
			require.Equal(t, tc.expectedPrice, nav.Price, "NewVaultNAV price mismatch for case: %s", tc.name)
			require.Equal(t, tc.expectedVolume, nav.Volume, "NewVaultNAV volume mismatch for case: %s", tc.name)
			require.Equal(t, tc.expectedSource, nav.Source, "NewVaultNAV source mismatch for case: %s", tc.name)
			require.Zero(t, nav.UpdatedBlockHeight, "NewVaultNAV should not stamp a block height for case: %s", tc.name)
			require.True(t, nav.UpdatedTime.IsZero(), "NewVaultNAV should not stamp an updated time for case: %s", tc.name)
		})
	}
}

func TestVaultNAV_PricesSameAs(t *testing.T) {
	maxInt := math.NewIntFromBigInt(new(big.Int).Sub(new(big.Int).Lsh(big.NewInt(1), 256), big.NewInt(1)))

	nav := func(price sdk.Coin, volume math.Int) types.VaultNAV {
		return types.NewVaultNAV("rwa", price, volume, "oracle")
	}

	tests := []struct {
		name     string
		entry    types.VaultNAV
		other    types.VaultNAV
		expected bool
	}{
		{
			name:     "identical price and volume",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			expected: true,
		},
		{
			name:     "same unit price scaled up",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 500), math.NewInt(250)),
			expected: true,
		},
		{
			name:     "both priced at zero regardless of volume",
			entry:    nav(sdk.NewInt64Coin("under", 0), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 0), math.NewInt(7)),
			expected: true,
		},
		{
			name:     "higher unit price",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 4), math.NewInt(1)),
			expected: false,
		},
		{
			name:     "same price amount at a different volume",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(2)),
			expected: false,
		},
		{
			name:     "written down to zero",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 0), math.NewInt(1)),
			expected: false,
		},
		{
			name:     "different price denom",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("other", 2), math.NewInt(1)),
			expected: false,
		},
		{
			name:     "unset price amount",
			entry:    nav(sdk.Coin{Denom: "under"}, math.NewInt(1)),
			other:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			expected: false,
		},
		{
			name:     "unset volume",
			entry:    nav(sdk.NewInt64Coin("under", 2), math.Int{}),
			other:    nav(sdk.NewInt64Coin("under", 2), math.NewInt(1)),
			expected: false,
		},
		{
			name:     "overflowing cross product",
			entry:    nav(sdk.NewCoin("under", maxInt), maxInt),
			other:    nav(sdk.NewCoin("under", maxInt), maxInt),
			expected: false,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			require.Equal(t, tc.expected, tc.entry.PricesSameAs(tc.other),
				"PricesSameAs(%s per %s) mismatch for case: %s", tc.other.Price, tc.other.Volume, tc.name)
			require.Equal(t, tc.expected, tc.other.PricesSameAs(tc.entry),
				"PricesSameAs should be symmetric for case: %s", tc.name)
		})
	}
}

func TestVaultAccount_IsAcceptedDenom(t *testing.T) {
	tests := []struct {
		name            string
		underlyingAsset string
		paymentDenom    string
		denom           string
		expected        bool
	}{
		{
			name:            "underlying asset is accepted",
			underlyingAsset: "uusd",
			denom:           "uusd",
			expected:        true,
		},
		{
			name:            "non-underlying denom is not accepted",
			underlyingAsset: "uusd",
			denom:           "usdc",
			expected:        false,
		},
		{
			name:            "stale payment denom does not widen acceptance",
			underlyingAsset: "uusd",
			paymentDenom:    "usdc",
			denom:           "usdc",
			expected:        false,
		},
		{
			name:            "underlying still accepted when payment denom mirrors it",
			underlyingAsset: "uusd",
			paymentDenom:    "uusd",
			denom:           "uusd",
			expected:        true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			v := types.VaultAccount{UnderlyingAsset: tc.underlyingAsset, PaymentDenom: tc.paymentDenom}
			got := v.IsAcceptedDenom(tc.denom)
			assert.Equal(t, tc.expected, got, "IsAcceptedDenom(%q) mismatch for case: %s", tc.denom, tc.name)
		})
	}
}

func TestVaultAccount_ValidateAcceptedDenom(t *testing.T) {
	tests := []struct {
		name            string
		underlyingAsset string
		denom           string
		expectedErr     string
	}{
		{
			name:            "underlying asset passes",
			underlyingAsset: "uusd",
			denom:           "uusd",
			expectedErr:     "",
		},
		{
			name:            "non-underlying denom is rejected",
			underlyingAsset: "uusd",
			denom:           "usdc",
			expectedErr:     `denom not supported for vault; must be "uusd": got "usdc"`,
		},
		{
			name:            "empty denom is rejected",
			underlyingAsset: "uusd",
			denom:           "",
			expectedErr:     `denom not supported for vault; must be "uusd": got ""`,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			v := types.VaultAccount{UnderlyingAsset: tc.underlyingAsset}
			err := v.ValidateAcceptedDenom(tc.denom)
			if tc.expectedErr == "" {
				assert.NoError(t, err, "expected no error for case: %s", tc.name)
			} else {
				assert.Error(t, err, "expected an error for case: %s", tc.name)
				assert.Equal(t, tc.expectedErr, err.Error(), "error message mismatch for case: %s", tc.name)
			}
		})
	}
}

func TestValidateNotIBCDenom(t *testing.T) {
	tests := []struct {
		name        string
		denom       string
		expectedErr string
	}{
		{
			name:        "ICS-20 voucher denom is rejected",
			denom:       "ibc/27394FB092D2ECCD56123C74F36E4C1F926001CEADA9CA97EA622B25F41E5EB2",
			expectedErr: `ibc denom "ibc/27394FB092D2ECCD56123C74F36E4C1F926001CEADA9CA97EA622B25F41E5EB2" cannot be used by a vault`,
		},
		{
			name:        "native marker denom passes",
			denom:       "uusd",
			expectedErr: "",
		},
		{
			name:        "denom starting with ibc but without the voucher separator passes",
			denom:       "ibccoin",
			expectedErr: "",
		},
		{
			name:        "uppercase IBC/ prefix is not a voucher denom and passes",
			denom:       "IBC/27394FB092D2ECCD56123C74F36E4C1F926001CEADA9CA97EA622B25F41E5EB2",
			expectedErr: "",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := types.ValidateNotIBCDenom(tc.denom)
			if tc.expectedErr == "" {
				assert.NoError(t, err, "expected no error for case: %s", tc.name)
			} else {
				assert.Error(t, err, "expected an error for case: %s", tc.name)
				assert.Equal(t, tc.expectedErr, err.Error(), "error message mismatch for case: %s", tc.name)
			}
		})
	}
}

func TestVaultAccount_ValidateAcceptedCoin(t *testing.T) {
	tests := []struct {
		name            string
		underlyingAsset string
		coin            sdk.Coin
		expectedErr     string
	}{
		{
			name:            "non-zero underlying coin is accepted",
			underlyingAsset: "uusd",
			coin:            sdk.NewInt64Coin("uusd", 1),
			expectedErr:     "",
		},
		{
			name:            "non-underlying denom is rejected",
			underlyingAsset: "uusd",
			coin:            sdk.NewInt64Coin("usdc", 5),
			expectedErr:     `denom not supported for vault; must be "uusd": got "usdc"`,
		},
		{
			name:            "zero amount is rejected before denom check",
			underlyingAsset: "uusd",
			coin:            sdk.NewInt64Coin("uusd", 0),
			expectedErr:     "amount must be greater than zero",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			v := types.VaultAccount{UnderlyingAsset: tc.underlyingAsset}
			err := v.ValidateAcceptedCoin(tc.coin)
			if tc.expectedErr == "" {
				assert.NoError(t, err, "expected no error for case: %s", tc.name)
			} else {
				assert.Error(t, err, "expected an error for case: %s", tc.name)
				assert.Equal(t, tc.expectedErr, err.Error(), "error message mismatch for case: %s", tc.name)
			}
		})
	}
}

func TestPendingSwapOut_Validate(t *testing.T) {
	validOwner := utils.TestAddress().Bech32
	validVault := utils.TestAddress().Bech32
	validDenom := "vshare"
	validRedeem := "uusd"
	invalidBech32 := "invalidaddress"

	baseReq := types.PendingSwapOut{
		Owner:        validOwner,
		VaultAddress: validVault,
		Shares:       sdk.NewInt64Coin(validDenom, 100),
		RedeemDenom:  validRedeem,
	}

	const invalidBech32ErrPrefix = "decoding bech32 failed:"

	tests := []struct {
		name           string
		pendingSwapOut types.PendingSwapOut
		expectedErr    string
	}{
		{
			name:           "valid request",
			pendingSwapOut: baseReq,
			expectedErr:    "",
		},
		{
			name: "invalid owner address",
			pendingSwapOut: types.PendingSwapOut{
				Owner:        invalidBech32,
				VaultAddress: validVault,
				Shares:       baseReq.Shares,
				RedeemDenom:  validRedeem,
			},
			expectedErr: fmt.Sprintf("invalid owner address %s: %s", invalidBech32, invalidBech32ErrPrefix),
		},
		{
			name: "invalid vault address",
			pendingSwapOut: types.PendingSwapOut{
				Owner:        validOwner,
				VaultAddress: invalidBech32,
				Shares:       baseReq.Shares,
				RedeemDenom:  validRedeem,
			},
			expectedErr: fmt.Sprintf("invalid vault address %s: %s", invalidBech32, invalidBech32ErrPrefix),
		},
		{
			name: "invalid shares (negative)",
			pendingSwapOut: types.PendingSwapOut{
				Owner:        validOwner,
				VaultAddress: validVault,
				Shares:       sdk.Coin{Denom: validDenom, Amount: math.NewInt(-10)},
				RedeemDenom:  validRedeem,
			},
			expectedErr: "invalid shares: -10vshare",
		},
		{
			name: "invalid shares (zero amount)",
			pendingSwapOut: types.PendingSwapOut{
				Owner:        validOwner,
				VaultAddress: validVault,
				Shares:       sdk.NewInt64Coin(validDenom, 0),
				RedeemDenom:  validRedeem,
			},
			expectedErr: "shares cannot be zero",
		},
		{
			name: "invalid shares (empty denom)",
			pendingSwapOut: types.PendingSwapOut{
				Owner:        validOwner,
				VaultAddress: validVault,
				Shares:       sdk.Coin{Denom: "", Amount: math.NewInt(10)},
				RedeemDenom:  validRedeem,
			},
			expectedErr: "invalid shares: 10",
		},
		{
			name: "empty redeem denom",
			pendingSwapOut: types.PendingSwapOut{
				Owner:        validOwner,
				VaultAddress: validVault,
				Shares:       baseReq.Shares,
				RedeemDenom:  "",
			},
			expectedErr: "redeem denom cannot be empty",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.pendingSwapOut.Validate()
			if tc.expectedErr != "" {
				require.Error(t, err, "expected an error for test case: %s", tc.name)
				require.Contains(t, err.Error(), tc.expectedErr, "error should contain expected message for test case: %s", tc.name)
			} else {
				require.NoError(t, err, "expected no error for test case: %s", tc.name)
			}
		})
	}
}

func TestValidateSwapLimits(t *testing.T) {
	tests := []struct {
		name        string
		min         string
		max         string
		expectedErr string
	}{
		{
			name:        "valid - both empty",
			min:         "",
			max:         "",
			expectedErr: "",
		},
		{
			name:        "valid - min set, max empty",
			min:         "100",
			max:         "",
			expectedErr: "",
		},
		{
			name:        "valid - min empty, max set",
			min:         "",
			max:         "1000",
			expectedErr: "",
		},
		{
			name:        "valid - both set, min < max",
			min:         "100",
			max:         "1000",
			expectedErr: "",
		},
		{
			name:        "valid - both set, min == max",
			min:         "500",
			max:         "500",
			expectedErr: "",
		},
		{
			name:        "invalid - max is 0",
			min:         "0",
			max:         "0",
			expectedErr: "max value cannot be zero; use toggle messages to disable swaps",
		},
		{
			name:        "invalid - min not an integer",
			min:         "abc",
			max:         "",
			expectedErr: "invalid min value: abc",
		},
		{
			name:        "invalid - max not an integer",
			min:         "",
			max:         "1.5",
			expectedErr: "invalid max value: 1.5",
		},
		{
			name:        "invalid - min is negative",
			min:         "-10",
			max:         "",
			expectedErr: "min value must be non-negative: -10",
		},
		{
			name:        "invalid - max is negative",
			min:         "",
			max:         "-50",
			expectedErr: "max value must be non-negative: -50",
		},
		{
			name:        "invalid - min > max",
			min:         "1000",
			max:         "500",
			expectedErr: "min value 1000 cannot be greater than max value 500",
		},
		{
			name:        "invalid - min > 0, max is 0",
			min:         "100",
			max:         "0",
			expectedErr: "max value cannot be zero",
		},
		{
			name:        "valid - min at the largest representable magnitude",
			min:         "1" + strings.Repeat("0", 77),
			max:         "",
			expectedErr: "",
		},
		{
			name:        "invalid - min over the integer string length bound",
			min:         strings.Repeat("9", types.MaxIntStringLength+1),
			max:         "",
			expectedErr: "invalid min value: must be at most 80 characters",
		},
		{
			name:        "invalid - max over the integer string length bound",
			min:         "",
			max:         strings.Repeat("9", types.MaxIntStringLength+1),
			expectedErr: "invalid max value: must be at most 80 characters",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := types.ValidateSwapLimits(tt.min, tt.max)
			if tt.expectedErr == "" {
				assert.NoError(t, err, "Test case %q: expected no error, but got %v", tt.name, err)
			} else {
				assert.Error(t, err, "Test case %q: expected error containing %q, but got none", tt.name, tt.expectedErr)
				if err != nil {
					assert.Contains(t, err.Error(), tt.expectedErr, "Test case %q: error message mismatch; expected it to contain %q, but got %q", tt.name, tt.expectedErr, err.Error())
				}
			}
		})
	}
}

func TestValidateWithdrawalDelay(t *testing.T) {
	tests := []struct {
		name         string
		delaySeconds uint64
		expectedErr  string
	}{
		{
			name:         "zero delay pays out immediately and is allowed",
			delaySeconds: 0,
			expectedErr:  "",
		},
		{
			name:         "one second below the maximum",
			delaySeconds: types.MaxWithdrawalDelay - 1,
			expectedErr:  "",
		},
		{
			name:         "exactly the maximum",
			delaySeconds: types.MaxWithdrawalDelay,
			expectedErr:  "",
		},
		{
			name:         "one second above the maximum",
			delaySeconds: types.MaxWithdrawalDelay + 1,
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds: %d", types.MaxWithdrawalDelay, uint64(types.MaxWithdrawalDelay)+1),
		},
		{
			name:         "at the int64 ceiling",
			delaySeconds: uint64(stdmath.MaxInt64),
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
		{
			name:         "above the int64 ceiling where the conversion wraps negative",
			delaySeconds: stdmath.MaxUint64,
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := types.ValidateWithdrawalDelay(tc.delaySeconds)
			if tc.expectedErr == "" {
				require.NoError(t, err, "expected delay %d to be accepted", tc.delaySeconds)
			} else {
				require.Error(t, err, "expected delay %d to be rejected", tc.delaySeconds)
				require.Contains(t, err.Error(), tc.expectedErr, "error message mismatch for delay %d", tc.delaySeconds)
			}
		})
	}
}

func TestVaultAccount_SwapOutPayoutTime(t *testing.T) {
	const blockTime int64 = 1_704_067_200

	tests := []struct {
		name               string
		blockTime          int64
		delaySeconds       uint64
		expectedPayoutTime int64
		expectedErr        string
	}{
		{
			name:               "zero delay matures at the block time",
			blockTime:          blockTime,
			delaySeconds:       0,
			expectedPayoutTime: blockTime,
		},
		{
			name:               "one day delay matures one day out",
			blockTime:          blockTime,
			delaySeconds:       86_400,
			expectedPayoutTime: blockTime + 86_400,
		},
		{
			name:               "maximum delay matures two years out",
			blockTime:          blockTime,
			delaySeconds:       types.MaxWithdrawalDelay,
			expectedPayoutTime: blockTime + types.MaxWithdrawalDelay,
		},
		{
			name:         "delay above the maximum is rejected instead of wrapping",
			blockTime:    blockTime,
			delaySeconds: types.MaxWithdrawalDelay + 1,
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
		{
			name:         "MaxUint64 delay is rejected rather than maturing before the block time",
			blockTime:    blockTime,
			delaySeconds: stdmath.MaxUint64,
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
		{
			name:         "block time near the int64 ceiling overflows the addition",
			blockTime:    stdmath.MaxInt64 - 1,
			delaySeconds: 2,
			expectedErr:  "payout time overflows int64",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			vault := types.VaultAccount{WithdrawalDelaySeconds: tc.delaySeconds}
			payoutTime, err := vault.SwapOutPayoutTime(tc.blockTime)
			if tc.expectedErr != "" {
				require.Error(t, err, "expected an error for delay %d at block time %d", tc.delaySeconds, tc.blockTime)
				require.Contains(t, err.Error(), tc.expectedErr, "error message mismatch for delay %d", tc.delaySeconds)
				require.Zero(t, payoutTime, "payout time must be zero when the computation fails")
				return
			}
			require.NoError(t, err, "expected no error for delay %d at block time %d", tc.delaySeconds, tc.blockTime)
			require.Equal(t, tc.expectedPayoutTime, payoutTime, "payout time mismatch for delay %d at block time %d", tc.delaySeconds, tc.blockTime)
			require.GreaterOrEqual(t, payoutTime, tc.blockTime, "payout time must never land before the block time")
		})
	}
}
