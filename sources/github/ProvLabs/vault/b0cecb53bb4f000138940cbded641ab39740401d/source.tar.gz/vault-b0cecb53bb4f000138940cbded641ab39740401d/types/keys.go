package types

import (
	fmt "fmt"

	"github.com/cometbft/cometbft/crypto"

	"cosmossdk.io/collections"

	sdk "github.com/cosmos/cosmos-sdk/types"
)

const (
	// ModuleName defines the module name
	ModuleName = "vault"

	// StoreKey defines the primary module store key
	StoreKey = ModuleName

	// GovModuleName duplicates the gov module's name to avoid a dependency with x/gov.
	// It should be synced with the gov module's name if it is ever changed.
	// See: https://github.com/cosmos/cosmos-sdk/blob/v0.52.0-beta.2/x/gov/types/keys.go#L9
	GovModuleName = "gov"
)

var (
	// VaultsKeyPrefix is the prefix to retrieve all Vaults
	VaultsKeyPrefix = collections.NewPrefix(0)
	// VaultsName is a human-readable name for the vaults collection.
	VaultsName = "vaults"
	// VaultPayoutVerificationSetPrefix is the prefix to retrieve all VaultPayoutVerificationQueue.
	VaultPayoutVerificationSetPrefix = collections.NewPrefix(1)
	// VaultPayoutVerificationSetName is a human-readable name for the vault payout verification set collection.
	VaultPayoutVerificationSetName = "vault_payout_verification_set"
	// VaultPayoutTimeoutQueuePrefix is the prefix to retrieve all VaultPayoutTimeoutQueue.
	VaultPayoutTimeoutQueuePrefix = collections.NewPrefix(2)
	// VaultPayoutTimeoutQueueName is a human-readable name for the payout timeout queue collection.
	VaultPayoutTimeoutQueueName = "vault_payout_timeout_queue"
	// VaultFeeTimeoutQueuePrefix is the prefix to retrieve all VaultFeeTimeoutQueue.
	VaultFeeTimeoutQueuePrefix = collections.NewPrefix(7)
	// VaultFeeTimeoutQueueName is a human-readable name for the fee timeout queue collection.
	VaultFeeTimeoutQueueName = "vault_fee_timeout_queue"
	// VaultPendingSwapOutQueuePrefix is the prefix to retrieve all VaultPendingSwapOutQueue.
	VaultPendingSwapOutQueuePrefix = collections.NewPrefix(3)
	// VaultPendingSwapOutQueueName is a human-readable name for the pending swap out queue collection.
	VaultPendingSwapOutQueueName = "pending_swap_out_queue"
	// VaultPendingSwapOutQueueSeqPrefix is the prefix for the pending swap out queue sequence.
	VaultPendingSwapOutQueueSeqPrefix = collections.NewPrefix(4)
	// VaultPendingSwapOutQueueSeqName is a human-readable name for the pending swap out queue collection.
	VaultPendingSwapOutQueueSeqName = "pending_swap_out_seq"
	// VaultPendingSwapOutByVaultIndexPrefix is the prefix for the pending swap out queue vault index.
	VaultPendingSwapOutByVaultIndexPrefix = collections.NewPrefix(5)
	// VaultPendingSwapOutByVaultIndexName is a human-readable name for the pending swap out queue vault index.
	VaultPendingSwapOutByVaultIndexName = "pending_swap_out_by_vault"
	// VaultPendingSwapOutByIDIndexPrefix is the prefix for the pending swap out queue by id index.
	VaultPendingSwapOutByIDIndexPrefix = collections.NewPrefix(6)
	// VaultPendingSwapOutByIDIndexName is a human-readable name for the pending swap out queue by id index.
	VaultPendingSwapOutByIDIndexName = "pending_swap_out_by_id"

	// ParamsKeyPrefix is the prefix for the module parameters.
	ParamsKeyPrefix = collections.NewPrefix(10)
	// ParamsKeyName is the human-readable name for the params state key.
	ParamsKeyName = "params"

	// NAVsKeyPrefix is the prefix for the internal NAV table, keyed by (vault address, denom).
	NAVsKeyPrefix = collections.NewPrefix(11)
	// NAVsName is a human-readable name for the internal NAV table collection.
	NAVsName = "vault_navs"

	// TotalValuesKeyPrefix is the prefix for the materialized total vault value, keyed by vault address.
	TotalValuesKeyPrefix = collections.NewPrefix(12)
	// TotalValuesName is a human-readable name for the materialized total value collection.
	TotalValuesName = "vault_total_values"

	// NAVCountsKeyPrefix is the prefix for the number of NAV entries a vault prices, keyed by vault address.
	NAVCountsKeyPrefix = collections.NewPrefix(13)
	// NAVCountsName is a human-readable name for the NAV entry count collection.
	NAVCountsName = "vault_nav_counts"

	// VaultPayoutVerificationCursorPrefix is the prefix for the address the payout verification sweep
	// resumes after. Progress tracking, not vault state, so it is not exported to genesis.
	VaultPayoutVerificationCursorPrefix = collections.NewPrefix(9)
	// VaultPayoutVerificationCursorName is a human-readable name for the payout verification cursor.
	VaultPayoutVerificationCursorName = "vault_payout_verification_cursor"
)

var (
	// DefaultTechFeeAddress is the default ProvLabs fee collection address for local/sim networks.
	// Represents 'pb1evyv7neax9qtxxzuexnhylxyz4guvsyjjqke4h'.
	DefaultTechFeeAddress = sdk.AccAddress{203, 8, 207, 79, 61, 49, 64, 179, 24, 92, 201, 167, 114, 124, 196, 21, 81, 198, 64, 146}
	// TestnetTechFeeAddress is the ProvLabs fee collection address for pio-testnet-1.
	// Represents 'tp1u7j87uj7e6xrkhgwmq9pqr47kdjdw6mhgv7dm4'.
	TestnetTechFeeAddress = sdk.AccAddress{231, 164, 127, 114, 94, 206, 140, 59, 93, 14, 216, 10, 16, 14, 190, 179, 100, 215, 107, 119}
	// MainnetTechFeeAddress is the ProvLabs fee collection group policy address for pio-mainnet-1.
	// Represents 'pb144z5tr4lk85xvhrplsrh6gmclr8pgpv76fqjt23gzz9awrmh4laqclqdun'.
	MainnetTechFeeAddress = sdk.AccAddress{173, 69, 69, 142, 191, 177, 232, 102, 92, 97, 252, 7, 125, 35, 120, 248, 206, 20, 5, 158, 210, 65, 37, 170, 40, 16, 139, 215, 15, 119, 175, 250}
)

const (
	// DefaultAumFeeBips is the default AUM fee rate in basis points (15 bps = 0.15%).
	DefaultAumFeeBips = 15

	// DefaultGovOnlyVaultCreation leaves vault creation open to any signer, so dev, docker,
	// and testnet chains need no proposal. Mainnet enables the gate in genesis or by proposal.
	DefaultGovOnlyVaultCreation = false

	// MainnetChainID is the chain ID of the Provenance mainnet.
	MainnetChainID = "pio-mainnet-1"
	// TestnetChainID is the chain ID of the Provenance testnet.
	TestnetChainID = "pio-testnet-1"
)

// GetVaultAddress returns the module account address for the given shareDenom.
func GetVaultAddress(shareDenom string) sdk.AccAddress {
	return sdk.AccAddress(crypto.AddressHash([]byte(fmt.Sprintf("%s/%s", ModuleName, shareDenom))))
}
