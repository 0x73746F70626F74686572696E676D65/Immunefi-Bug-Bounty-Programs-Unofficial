package queue

import (
	"fmt"

	"github.com/provlabs/vault/types"

	"cosmossdk.io/collections"

	sdk "github.com/cosmos/cosmos-sdk/types"
)

// FeeTimeoutQueue manages scheduled fee collections for vaults within
// the fee-reconciliation flow.
type FeeTimeoutQueue struct {
	keyset collections.KeySet[collections.Pair[uint64, sdk.AccAddress]]
}

// NewFeeTimeoutQueue initializes a new FeeTimeoutQueue using the
// provided collections schema builder.
func NewFeeTimeoutQueue(builder *collections.SchemaBuilder) *FeeTimeoutQueue {
	endKeyCodec := collections.PairKeyCodec(
		collections.Uint64Key,
		sdk.AccAddressKey,
	)
	return &FeeTimeoutQueue{
		keyset: collections.NewKeySet(builder, types.VaultFeeTimeoutQueuePrefix, types.VaultFeeTimeoutQueueName, endKeyCodec),
	}
}

// Enqueue schedules a vault for fee collection processing by inserting an
// entry into the FeeTimeoutQueue keyed by (feeTimeout, vault address).
func (p *FeeTimeoutQueue) Enqueue(ctx sdk.Context, feeTimeout int64, vaultAddr sdk.AccAddress) error {
	if feeTimeout < 0 {
		return fmt.Errorf("feeTimeout cannot be negative")
	}
	if err := p.keyset.Set(ctx, collections.Join(uint64(feeTimeout), vaultAddr)); err != nil {
		return fmt.Errorf("enqueue fee timeout: %w", err)
	}
	return nil
}

// Dequeue removes a specific timeout entry (feeTimeout, vault)
// from the FeeTimeoutQueue.
func (p *FeeTimeoutQueue) Dequeue(ctx sdk.Context, feeTimeout int64, vaultAddr sdk.AccAddress) error {
	if feeTimeout < 0 {
		return fmt.Errorf("feeTimeout cannot be negative")
	}
	if err := p.keyset.Remove(ctx, collections.Join(uint64(feeTimeout), vaultAddr)); err != nil {
		return fmt.Errorf("dequeue fee timeout: %w", err)
	}
	return nil
}

// WalkDue iterates over all entries in the FeeTimeoutQueue with
// a timeout timestamp <= nowSec. For each due entry, the callback is invoked.
func (p *FeeTimeoutQueue) WalkDue(ctx sdk.Context, nowSec int64, fn func(feeTimeout uint64, vaultAddr sdk.AccAddress) (stop bool, err error)) error {
	if nowSec < 0 {
		return fmt.Errorf("nowSec cannot be negative")
	}
	if err := p.keyset.Walk(ctx, nil, func(key collections.Pair[uint64, sdk.AccAddress]) (stop bool, err error) {
		if key.K1() > uint64(nowSec) { //nolint:gosec // G115: nowSec is guarded non-negative above.
			return true, nil
		}
		return fn(key.K1(), key.K2())
	}); err != nil {
		return fmt.Errorf("walk fee timeouts: %w", err)
	}
	return nil
}

// Walk iterates over all entries in the FeeTimeoutQueue.
func (p *FeeTimeoutQueue) Walk(ctx sdk.Context, fn func(feeTimeout uint64, vaultAddr sdk.AccAddress) (stop bool, err error)) error {
	if err := p.keyset.Walk(ctx, nil, func(key collections.Pair[uint64, sdk.AccAddress]) (stop bool, err error) {
		return fn(key.K1(), key.K2())
	}); err != nil {
		return fmt.Errorf("walk fee timeouts: %w", err)
	}
	return nil
}
