package queue_test

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"cosmossdk.io/collections"
	"cosmossdk.io/core/store"
	"cosmossdk.io/log"
	sdkmath "cosmossdk.io/math"
	storetypes "cosmossdk.io/store/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	"github.com/cosmos/cosmos-sdk/testutil"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"

	"github.com/provlabs/vault/queue"
	vtypes "github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"
	"github.com/provlabs/vault/utils/mocks"
)

// failingHasKVStoreService decorates a KVStoreService so that every existence check against the
// underlying store fails, letting tests distinguish a store read failure from an absent entry.
type failingHasKVStoreService struct {
	inner store.KVStoreService
	err   error
}

// OpenKVStore returns the decorated store whose Has always fails.
func (s failingHasKVStoreService) OpenKVStore(ctx context.Context) store.KVStore {
	return failingHasKVStore{KVStore: s.inner.OpenKVStore(ctx), err: s.err}
}

// failingHasKVStore behaves like the store it embeds except that existence checks always fail.
type failingHasKVStore struct {
	store.KVStore
	err error
}

// Has always fails, simulating a store read failure during an existence check.
func (s failingHasKVStore) Has([]byte) (bool, error) { return false, s.err }

// newTestPendingSwapOutQueue builds a PendingSwapOutQueue backed by an in-memory store.
func newTestPendingSwapOutQueue(t *testing.T) (sdk.Context, *queue.PendingSwapOutQueue) {
	t.Helper()
	return newPendingSwapOutQueue(t, nil)
}

// newPendingSwapOutQueue builds a PendingSwapOutQueue backed by an in-memory store. When hasErr is
// non-nil, every existence check against that store fails with it, which is how tests exercise the
// lookup-failure branch that must never be collapsed into a not-found result.
func newPendingSwapOutQueue(t *testing.T, hasErr error) (sdk.Context, *queue.PendingSwapOutQueue) {
	t.Helper()
	storeKey := storetypes.NewKVStoreKey(vtypes.ModuleName)
	testCtx := testutil.DefaultContextWithDB(t, storeKey, storetypes.NewTransientStoreKey("transient_test"))

	cfg := mocks.MakeTestEncodingConfig("provlabs")
	sdkCfg := sdk.GetConfig()
	sdkCfg.SetBech32PrefixForAccount("provlabs", "provlabspub")
	sdkCfg.SetBech32PrefixForValidator("provlabsvaloper", "provlabsvaloperpub")
	sdkCfg.SetBech32PrefixForConsensusNode("provlabsvalcons", "provlabsvalconspub")
	vtypes.RegisterInterfaces(cfg.InterfaceRegistry)

	var kvStoreService store.KVStoreService = runtime.NewKVStoreService(storeKey)
	if hasErr != nil {
		kvStoreService = failingHasKVStoreService{inner: kvStoreService, err: hasErr}
	}
	sb := collections.NewSchemaBuilder(kvStoreService)

	q := queue.NewPendingSwapOutQueue(sb, cfg.Codec)
	_, err := sb.Build()
	require.NoError(t, err, "schema build should not error")
	return testCtx.Ctx.WithLogger(log.NewNopLogger()), q
}

func TestPendingSwapOutQueue_Codec(t *testing.T) {
	ctx, q := newTestPendingSwapOutQueue(t)

	addr := utils.TestProvlabsAddress()
	redeemDenom := "usd"
	shares := sdk.NewInt64Coin("vshares", 100)
	originalReq := &vtypes.PendingSwapOut{
		Owner:        addr.Bech32,
		VaultAddress: addr.Bech32,
		RedeemDenom:  redeemDenom,
		Shares:       shares,
	}

	_, err := q.Enqueue(ctx, time.Now().Unix(), originalReq)
	require.NoError(t, err, "enqueue should succeed for valid request")

	var retrievedReq vtypes.PendingSwapOut
	retrieved := false
	err = q.Walk(ctx, func(timestamp int64, id uint64, vault sdk.AccAddress, req vtypes.PendingSwapOut) (stop bool, err error) {
		retrievedReq = req
		retrieved = true
		return true, nil
	})

	require.NoError(t, err, "walk should not error")
	require.True(t, retrieved, "did not retrieve any request from the queue")

	require.Equal(t, originalReq.Owner, retrievedReq.Owner, "retrieved owner mismatch")
	require.Equal(t, originalReq.VaultAddress, retrievedReq.VaultAddress, "retrieved vault address mismatch")
	require.Equal(t, originalReq.RedeemDenom, retrievedReq.RedeemDenom, "retrieved redeem denom mismatch")
	require.Equal(t, originalReq.Shares, retrievedReq.Shares, "retrieved shares mismatch")
}

func TestPendingSwapOutQueueWalk(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	addr2 := utils.TestProvlabsAddress()
	if addr1.Bech32 > addr2.Bech32 {
		addr1, addr2 = addr2, addr1
	}
	req1 := &vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "ylds", Shares: sdk.NewInt64Coin("vshares", 25)}
	req2 := &vtypes.PendingSwapOut{VaultAddress: addr2.Bech32, Owner: addr2.Bech32, RedeemDenom: "ylds", Shares: sdk.NewInt64Coin("vshares", 50)}
	req3 := &vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr2.Bech32, RedeemDenom: "ylds", Shares: sdk.NewInt64Coin("vshares", 100)}
	boom := errors.New("boom")

	tests := []struct {
		name         string
		setup        func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue)
		expectedErr  error
		expectedSeen []vtypes.PendingSwapOut
	}{
		{
			name: "success",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) {
				_, err := q.Enqueue(ctx, 1, req1)
				require.NoError(t, err, "enqueue req1 should succeed")
				_, err = q.Enqueue(ctx, 2, req2)
				require.NoError(t, err, "enqueue req2 should succeed")
			},
			expectedSeen: []vtypes.PendingSwapOut{*req1, *req2},
		},
		{
			name: "success with order preservation",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) {
				_, err := q.Enqueue(ctx, 1, req1)
				require.NoError(t, err, "enqueue req1 should succeed")
				_, err = q.Enqueue(ctx, 2, req2)
				require.NoError(t, err, "enqueue req2 should succeed")
				_, err = q.Enqueue(ctx, 3, req3)
				require.NoError(t, err, "enqueue req3 should succeed")
			},
			expectedSeen: []vtypes.PendingSwapOut{*req1, *req2, *req3},
		},
		{
			name:         "empty",
			setup:        func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) {},
			expectedSeen: []vtypes.PendingSwapOut{},
		},
		{
			name: "error",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) {
				_, err := q.Enqueue(ctx, 1, req1)
				require.NoError(t, err, "enqueue req1 should succeed")
				_, err = q.Enqueue(ctx, 2, req2)
				require.NoError(t, err, "enqueue req2 should succeed")
			},
			expectedErr:  boom,
			expectedSeen: []vtypes.PendingSwapOut{*req1, *req2},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)
			if tc.setup != nil {
				tc.setup(t, ctx, q)
			}

			seen := []vtypes.PendingSwapOut{}
			calls := 0
			err := q.Walk(ctx, func(timestamp int64, id uint64, vault sdk.AccAddress, req vtypes.PendingSwapOut) (stop bool, err error) {
				calls++
				seen = append(seen, req)
				if tc.expectedErr != nil && calls == len(tc.expectedSeen) {
					return false, tc.expectedErr
				}
				return false, nil
			})

			if tc.expectedErr != nil {
				require.ErrorIs(t, err, tc.expectedErr, "walk should return the expected error")
			} else {
				require.NoError(t, err, "walk should not return an error")
			}
			require.Equal(t, tc.expectedSeen, seen, "walk should iterate over all expected entries")
		})
	}
}

func TestPendingSwapOutQueueEnqueueAndDequeue(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	addr2 := utils.TestProvlabsAddress()

	addr1Acc := sdk.MustAccAddressFromBech32(addr1.Bech32)
	validShares := sdk.NewInt64Coin("vshare", 10)
	validRedeem := "uusd"

	validReq := vtypes.NewPendingSwapOut(
		addr1Acc,
		addr1Acc,
		validShares,
		validRedeem,
	)

	tests := []struct {
		name        string
		setup       func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64)
		timestamp   int64
		req         *vtypes.PendingSwapOut
		dequeue     bool
		expectError bool
		errorMsg    string
	}{
		{
			name: "successful enqueue and dequeue",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				req := vtypes.NewPendingSwapOut(addr1Acc, addr1Acc, sdk.NewInt64Coin("vshares", 100), "usd")
				id, err := q.Enqueue(ctx, 1, &req)
				require.NoError(t, err, "enqueue must succeed")
				return 1, addr1Acc, id
			},
			dequeue:     true,
			expectError: false,
		},
		{
			name: "dequeue non-existent key reports not found instead of phantom success",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return 1, sdk.MustAccAddressFromBech32(utils.TestProvlabsAddress().Bech32), 999
			},
			dequeue:     true,
			expectError: true,
			errorMsg:    "pending swap out 999 not found at timestamp 1 for vault",
		},
		{
			name: "dequeue queued id under the wrong timestamp reports not found",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				req := vtypes.NewPendingSwapOut(addr1Acc, addr1Acc, sdk.NewInt64Coin("vshares", 100), "usd")
				id, err := q.Enqueue(ctx, 1, &req)
				require.NoError(t, err, "enqueue must succeed")
				return 2, addr1Acc, id
			},
			dequeue:     true,
			expectError: true,
			errorMsg:    "not found at timestamp 2",
		},
		{
			name: "dequeue queued id for the wrong vault reports not found",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				req := vtypes.NewPendingSwapOut(addr1Acc, addr1Acc, sdk.NewInt64Coin("vshares", 100), "usd")
				id, err := q.Enqueue(ctx, 1, &req)
				require.NoError(t, err, "enqueue must succeed")
				return 1, sdk.MustAccAddressFromBech32(addr2.Bech32), id
			},
			dequeue:     true,
			expectError: true,
			errorMsg:    "not found at timestamp 1 for vault " + addr2.Bech32,
		},
		{
			name: "dequeue twice reports not found on the second attempt",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				req := vtypes.NewPendingSwapOut(addr1Acc, addr1Acc, sdk.NewInt64Coin("vshares", 100), "usd")
				id, err := q.Enqueue(ctx, 1, &req)
				require.NoError(t, err, "enqueue must succeed")
				require.NoError(t, q.Dequeue(ctx, 1, addr1Acc, id), "first dequeue must succeed")
				return 1, addr1Acc, id
			},
			dequeue:     true,
			expectError: true,
			errorMsg:    "not found at timestamp 1",
		},
		{
			name: "enqueue with invalid vault address (pre-validation, now fails validation)",
			req: &vtypes.PendingSwapOut{
				Owner:        validReq.Owner,
				VaultAddress: "invalid",
				Shares:       validShares,
				RedeemDenom:  validRedeem,
			},
			timestamp:   1,
			dequeue:     false,
			expectError: true,
			errorMsg:    "invalid pending swap out request: invalid vault address invalid:",
		},
		{
			name: "enqueue fails validation (invalid owner address)",
			req: &vtypes.PendingSwapOut{
				Owner:        "invalidowner",
				VaultAddress: validReq.VaultAddress,
				Shares:       validShares,
				RedeemDenom:  validRedeem,
			},
			timestamp:   1,
			dequeue:     false,
			expectError: true,
			errorMsg:    "invalid pending swap out request: invalid owner address invalidowner:",
		},
		{
			name: "enqueue fails validation (zero shares)",
			req: &vtypes.PendingSwapOut{
				Owner:        validReq.Owner,
				VaultAddress: validReq.VaultAddress,
				Shares:       sdk.NewInt64Coin("vshare", 0),
				RedeemDenom:  validRedeem,
			},
			timestamp:   1,
			dequeue:     false,
			expectError: true,
			errorMsg:    "shares cannot be zero",
		},
		{
			name: "enqueue fails validation (empty redeem denom)",
			req: &vtypes.PendingSwapOut{
				Owner:        validReq.Owner,
				VaultAddress: validReq.VaultAddress,
				Shares:       validShares,
				RedeemDenom:  "",
			},
			timestamp:   1,
			dequeue:     false,
			expectError: true,
			errorMsg:    "invalid pending swap out request: redeem denom cannot be empty",
		},
		{
			name: "enqueue with negative timestamp",
			req: &vtypes.PendingSwapOut{
				VaultAddress: addr2.Bech32,
				Owner:        validReq.Owner,
				Shares:       validReq.Shares,
				RedeemDenom:  validReq.RedeemDenom,
			},
			timestamp:   -1,
			dequeue:     false,
			expectError: true,
			errorMsg:    "pending time cannot be negative",
		},
		{
			name: "dequeue with negative timestamp",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return -1, sdk.MustAccAddressFromBech32(utils.TestProvlabsAddress().Bech32), 1
			},
			dequeue:     true,
			expectError: true,
			errorMsg:    "timestamp cannot be negative",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)

			if tc.dequeue {
				timestamp, addr, id := tc.setup(t, ctx, q)
				err := q.Dequeue(ctx, timestamp, addr, id)
				if tc.expectError {
					require.Errorf(t, err, "test case %q: dequeue should return an error", tc.name)
					if tc.errorMsg != "" {
						require.Containsf(t, err.Error(), tc.errorMsg, "test case %q: dequeue error message mismatch", tc.name)
					}
				} else {
					require.NoErrorf(t, err, "test case %q: dequeue should not return an error", tc.name)
					_, err = q.IndexedMap.Get(ctx, collections.Join3(timestamp, id, addr))
					require.Errorf(t, err, "test case %q: get should fail after successful dequeue", tc.name)
					require.ErrorIs(t, err, collections.ErrNotFound, "test case %q: error should be collections.ErrNotFound", tc.name)
				}
			} else {
				_, err := q.Enqueue(ctx, tc.timestamp, tc.req)
				if tc.expectError {
					require.Errorf(t, err, "test case %q: enqueue should return an error", tc.name)
					if tc.errorMsg != "" {
						require.Containsf(t, err.Error(), tc.errorMsg, "test case %q: enqueue error message mismatch", tc.name)
					}
				} else {
					require.NoErrorf(t, err, "test case %q: enqueue should not return an error", tc.name)
				}
			}
		})
	}
}

func TestPendingSwapOutQueue_RequireQueued(t *testing.T) {
	vaultAddr := sdk.AccAddress(utils.TestProvlabsAddress().Bytes)
	otherVaultAddr := sdk.AccAddress(utils.TestProvlabsAddress().Bytes)
	require.NotEqual(t, vaultAddr, otherVaultAddr, "the wrong-vault case is only meaningful if the two fixture vaults differ")

	storeReadErr := errors.New("store read failed")

	enqueueAt := func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue, timestamp int64, vault sdk.AccAddress) uint64 {
		t.Helper()
		req := vtypes.NewPendingSwapOut(vault, vault, sdk.NewInt64Coin("vshares", 100), "usd")
		id, err := q.Enqueue(ctx, timestamp, &req)
		require.NoError(t, err, "enqueue at timestamp %d for vault %s must succeed", timestamp, vault)
		return id
	}

	tests := []struct {
		name           string
		lookupErr      error
		setup          func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64)
		expectNotFound bool
		expectedError  string
		expectedCause  error
	}{
		{
			name: "queued key passes the guard",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return 1, vaultAddr, enqueueAt(t, ctx, q, 1, vaultAddr)
			},
		},
		{
			name: "key that was never queued is reported as not found",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return 1, vaultAddr, 999
			},
			expectNotFound: true,
		},
		{
			name: "queued id under a different timestamp is reported as not found",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return 2, vaultAddr, enqueueAt(t, ctx, q, 1, vaultAddr)
			},
			expectNotFound: true,
		},
		{
			name: "queued id under a different vault is reported as not found",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return 1, otherVaultAddr, enqueueAt(t, ctx, q, 1, vaultAddr)
			},
			expectNotFound: true,
		},
		{
			name: "key removed by a prior dequeue is reported as not found",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				id := enqueueAt(t, ctx, q, 1, vaultAddr)
				require.NoError(t, q.Dequeue(ctx, 1, vaultAddr, id), "the first dequeue must succeed")
				return 1, vaultAddr, id
			},
			expectNotFound: true,
		},
		{
			name: "negative timestamp is reported as not found rather than rejected here",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return -1, vaultAddr, 1
			},
			expectNotFound: true,
		},
		{
			name:      "failed lookup is propagated instead of being collapsed into not found",
			lookupErr: storeReadErr,
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (int64, sdk.AccAddress, uint64) {
				return 1, vaultAddr, 7
			},
			expectedError: "failed to look up pending swap out 7 at 1: store read failed",
			expectedCause: storeReadErr,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, q := newPendingSwapOutQueue(t, tc.lookupErr)
			timestamp, vault, id := tc.setup(t, ctx, q)

			err := q.TestAccessor_requireQueued(t, ctx, timestamp, vault, id)

			expectedError := tc.expectedError
			if tc.expectNotFound {
				expectedError = fmt.Sprintf("pending swap out %d not found at timestamp %d for vault %s", id, timestamp, vault)
			}
			if expectedError == "" {
				require.NoError(t, err, "a queued key must pass the guard that protects Dequeue and Reschedule")
				return
			}

			require.EqualError(t, err, expectedError, "the guard must name every component of the key it could not confirm")
			if tc.expectedCause != nil {
				require.ErrorIs(t, err, tc.expectedCause, "the underlying store failure must stay inspectable by the caller")
				require.NotContains(t, err.Error(), "not found", "a store read failure must never be reported as an absent entry")
			}
		})
	}
}

func TestPendingSwapOutQueueMutationsPropagateLookupFailure(t *testing.T) {
	addr := sdk.AccAddress(utils.TestProvlabsAddress().Bytes)
	req := vtypes.NewPendingSwapOut(addr, addr, sdk.NewInt64Coin("vshares", 100), "usd")
	storeReadErr := errors.New("store read failed")

	tests := []struct {
		name   string
		mutate func(q *queue.PendingSwapOutQueue, ctx sdk.Context) error
	}{
		{
			name: "dequeue surfaces the lookup failure",
			mutate: func(q *queue.PendingSwapOutQueue, ctx sdk.Context) error {
				return q.Dequeue(ctx, 1, addr, 7)
			},
		},
		{
			name: "reschedule surfaces the lookup failure",
			mutate: func(q *queue.PendingSwapOutQueue, ctx sdk.Context) error {
				return q.Reschedule(ctx, 1, addr, 7, 2, &req)
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, q := newPendingSwapOutQueue(t, storeReadErr)

			err := tc.mutate(q, ctx)

			require.Error(t, err, "a failing store lookup must not be reported as success")
			require.ErrorIs(t, err, storeReadErr, "the mutation must route its existence check through requireQueued and hand the store failure to the caller")
			require.NotContains(t, err.Error(), "not found", "a store read failure must never be collapsed into a not-found result")
		})
	}
}

func TestPendingSwapOutQueue_GetByID(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	req1 := &vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100)}

	tests := map[string]struct {
		setup    func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) uint64
		id       uint64
		errorMsg string
	}{
		"success": {
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) uint64 {
				id, err := q.Enqueue(ctx, 123, req1)
				require.NoError(t, err, "enqueue should succeed")
				return id
			},
		},
		"failure - invalid id": {
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) uint64 {
				return 999
			},
			errorMsg: "not found",
		},
	}

	for name, tc := range tests {
		t.Run(name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)
			id := tc.setup(t, ctx, q)

			pendingTime, req, err := q.GetByID(ctx, id)

			if len(tc.errorMsg) > 0 {
				require.Errorf(t, err, "test case %q: GetByID should return an error", name)
				require.ErrorContainsf(t, err, tc.errorMsg, "test case %q: error message mismatch", name)
				require.Equalf(t, int64(0), pendingTime, "test case %q: pending time should be zero on error", name)
			} else {
				require.NoErrorf(t, err, "test case %q: GetByID should not return an error", name)
				require.Equalf(t, req1.VaultAddress, req.VaultAddress, "test case %q: retrieved vault address mismatch", name)
				require.Equalf(t, req1.Owner, req.Owner, "test case %q: retrieved owner mismatch", name)
				require.Equalf(t, int64(123), pendingTime, "test case %q: retrieved timestamp mismatch", name)
			}
		})
	}
}

func TestPendingSwapOutQueue_ExpediteSwapOut(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	addr2 := utils.TestProvlabsAddress()
	req1 := &vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100), FailureCount: 3}
	req2 := &vtypes.PendingSwapOut{VaultAddress: addr2.Bech32, Owner: addr2.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100), FailureCount: 3}

	tests := map[string]struct {
		setup      func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (uint64, int64, sdk.AccAddress)
		expediteId uint64
		errorMsg   string
	}{
		"success with one entry": {
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (uint64, int64, sdk.AccAddress) {
				id, err := q.Enqueue(ctx, 123, req1)
				require.NoError(t, err, "enqueue should succeed")
				return id, 123, sdk.MustAccAddressFromBech32(addr1.Bech32)
			},
		},
		"success with two entries, second is expedited": {
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (uint64, int64, sdk.AccAddress) {
				_, err := q.Enqueue(ctx, 123, req1)
				require.NoError(t, err, "enqueue req1 should succeed")
				id2, err := q.Enqueue(ctx, 456, req2)
				require.NoError(t, err, "enqueue req2 should succeed")
				return id2, 456, sdk.MustAccAddressFromBech32(addr2.Bech32)
			},
		},
		"success on entry with timestamp 0": {
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (uint64, int64, sdk.AccAddress) {
				id, err := q.Enqueue(ctx, 0, req1)
				require.NoError(t, err, "enqueue should succeed")
				return id, 0, sdk.MustAccAddressFromBech32(addr1.Bech32)
			},
		},
		"failure if entry does not exist": {
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) (uint64, int64, sdk.AccAddress) {
				return 999, 0, nil
			},
			expediteId: 999,
			errorMsg:   "not found",
		},
	}

	for name, tc := range tests {
		t.Run(name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)
			id, oldTimestamp, addr := tc.setup(t, ctx, q)
			if tc.expediteId != 0 {
				id = tc.expediteId
			}

			err := q.ExpediteSwapOut(ctx, id)

			if len(tc.errorMsg) > 0 {
				require.Errorf(t, err, "test case %q: ExpediteSwapOut should return an error", name)
				require.ErrorContainsf(t, err, tc.errorMsg, "test case %q: error message mismatch", name)
			} else {
				require.NoErrorf(t, err, "test case %q: ExpediteSwapOut should not return an error", name)

				if oldTimestamp != 0 {
					_, err = q.IndexedMap.Get(ctx, collections.Join3(oldTimestamp, id, addr))
					require.ErrorContainsf(t, err, "not found", "test case %q: old entry should be removed", name)
				}

				newKey := collections.Join3(int64(0), id, addr)
				expedited, err := q.IndexedMap.Get(ctx, newKey)
				require.NoErrorf(t, err, "test case %q: new entry with timestamp 0 should exist", name)
				require.Zerof(t, expedited.FailureCount, "test case %q: expediting should clear the accumulated failure count", name)
			}
		})
	}
}

func TestPendingSwapOutQueue_Reschedule(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	vaultAddr := sdk.MustAccAddressFromBech32(addr1.Bech32)
	newReq := func(failureCount uint32) *vtypes.PendingSwapOut {
		return &vtypes.PendingSwapOut{
			VaultAddress: addr1.Bech32,
			Owner:        addr1.Bech32,
			RedeemDenom:  "usd",
			Shares:       sdk.NewInt64Coin("vshares", 100),
			FailureCount: failureCount,
		}
	}

	tests := map[string]struct {
		oldTimestamp int64
		newTimestamp int64
		req          *vtypes.PendingSwapOut
		enqueue      bool
		useUnknownID bool
		errorMsg     string
	}{
		"moves entry to a later timestamp and stores the updated request": {
			oldTimestamp: 100,
			newTimestamp: 700,
			req:          newReq(1),
			enqueue:      true,
		},
		"moves entry to the current timestamp when there is no backoff": {
			oldTimestamp: 100,
			newTimestamp: 100,
			req:          newReq(1),
			enqueue:      true,
		},
		"moves an expedited entry off timestamp 0": {
			oldTimestamp: 0,
			newTimestamp: 600,
			req:          newReq(2),
			enqueue:      true,
		},
		"fails when the entry is not queued": {
			oldTimestamp: 100,
			newTimestamp: 700,
			req:          newReq(1),
			enqueue:      true,
			useUnknownID: true,
			errorMsg:     "not found at timestamp",
		},
		"fails on a negative old timestamp": {
			oldTimestamp: -1,
			newTimestamp: 700,
			req:          newReq(1),
			errorMsg:     "timestamp cannot be negative",
		},
		"fails on a negative new timestamp": {
			oldTimestamp: 100,
			newTimestamp: -1,
			req:          newReq(1),
			enqueue:      true,
			errorMsg:     "new timestamp cannot be negative",
		},
		"fails on a nil request": {
			oldTimestamp: 100,
			newTimestamp: 700,
			enqueue:      true,
			errorMsg:     "cannot be nil",
		},
	}

	for name, tc := range tests {
		t.Run(name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)

			var id uint64
			if tc.enqueue {
				var err error
				id, err = q.Enqueue(ctx, max(tc.oldTimestamp, 0), newReq(0))
				require.NoErrorf(t, err, "test case %q: enqueue should succeed", name)
			}
			rescheduleID := id
			if tc.useUnknownID {
				rescheduleID = id + 999
			}

			err := q.Reschedule(ctx, tc.oldTimestamp, vaultAddr, rescheduleID, tc.newTimestamp, tc.req)

			if len(tc.errorMsg) > 0 {
				require.Errorf(t, err, "test case %q: Reschedule should return an error", name)
				require.ErrorContainsf(t, err, tc.errorMsg, "test case %q: error message mismatch", name)

				if tc.enqueue {
					pendingTime, stored, getErr := q.GetByID(ctx, id)
					require.NoErrorf(t, getErr, "test case %q: the original entry should survive a failed reschedule", name)
					require.Equalf(t, tc.oldTimestamp, pendingTime, "test case %q: a failed reschedule should not move the entry", name)
					require.Zerof(t, stored.FailureCount, "test case %q: a failed reschedule should not update the stored request", name)
				}
				return
			}

			require.NoErrorf(t, err, "test case %q: Reschedule should not return an error", name)

			if tc.oldTimestamp != tc.newTimestamp {
				_, err = q.IndexedMap.Get(ctx, collections.Join3(tc.oldTimestamp, id, vaultAddr))
				require.ErrorContainsf(t, err, "not found", "test case %q: the entry should no longer exist under its old timestamp", name)
			}

			pendingTime, stored, err := q.GetByID(ctx, id)
			require.NoErrorf(t, err, "test case %q: the rescheduled entry should still resolve by ID", name)
			require.Equalf(t, tc.newTimestamp, pendingTime, "test case %q: the entry should be filed under its new timestamp", name)
			require.Equalf(t, tc.req.FailureCount, stored.FailureCount, "test case %q: the updated failure count should be stored", name)
			require.Equalf(t, tc.req.Shares, stored.Shares, "test case %q: the escrowed shares should be preserved", name)

			byVault := 0
			require.NoErrorf(t, q.WalkByVault(ctx, vaultAddr, func(_ int64, walkedID uint64, _ vtypes.PendingSwapOut) (bool, error) {
				byVault++
				require.Equalf(t, id, walkedID, "test case %q: the vault index should resolve the rescheduled entry", name)
				return false, nil
			}), "test case %q: walking by vault should not error", name)
			require.Equalf(t, 1, byVault, "test case %q: the vault index should hold exactly one entry after a reschedule", name)
		})
	}
}

func TestPendingSwapOutQueue_Export(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	addr2 := utils.TestProvlabsAddress()
	if addr1.Bech32 > addr2.Bech32 {
		addr1, addr2 = addr2, addr1
	}
	req1 := &vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100)}
	req2 := &vtypes.PendingSwapOut{VaultAddress: addr2.Bech32, Owner: addr2.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 200)}
	req3 := &vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 300)}

	tests := []struct {
		name          string
		setup         func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue)
		expectedQueue vtypes.PendingSwapOutQueue
		expectError   bool
	}{
		{
			name: "multiple elements",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) {
				_, err := q.Enqueue(ctx, 1, req1)
				require.NoError(t, err, "enqueue req1 should succeed")
				_, err = q.Enqueue(ctx, 2, req2)
				require.NoError(t, err, "enqueue req2 should succeed")
				_, err = q.Enqueue(ctx, 1, req3)
				require.NoError(t, err, "enqueue req3 should succeed")
			},
			expectedQueue: vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 3,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: *req1},
					{Time: 1, Id: 2, SwapOut: *req3},
					{Time: 2, Id: 1, SwapOut: *req2},
				},
			},
			expectError: false,
		},
		{
			name: "no elements",
			setup: func(t *testing.T, ctx sdk.Context, q *queue.PendingSwapOutQueue) {
			},
			expectedQueue: vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 0,
				Entries:              []vtypes.PendingSwapOutQueueEntry{},
			},
			expectError: false,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)
			tc.setup(t, ctx, q)

			exportedQueue, err := q.Export(ctx)

			if tc.expectError {
				require.Errorf(t, err, "test case %q: export should return an error", tc.name)
			} else {
				require.NoErrorf(t, err, "test case %q: export should not return an error", tc.name)
				require.Equalf(t, tc.expectedQueue.LatestSequenceNumber, exportedQueue.LatestSequenceNumber, "test case %q: latest sequence number mismatch", tc.name)
				require.Equalf(t, len(tc.expectedQueue.Entries), len(exportedQueue.Entries), "test case %q: number of exported entries mismatch", tc.name)
				for i, entry := range tc.expectedQueue.Entries {
					require.Equalf(t, entry.Time, exportedQueue.Entries[i].Time, "test case %q: exported entry time mismatch at index %d", tc.name, i)
					require.Equalf(t, entry.Id, exportedQueue.Entries[i].Id, "test case %q: exported entry ID mismatch at index %d", tc.name, i)
					require.Equalf(t, entry.SwapOut.Owner, exportedQueue.Entries[i].SwapOut.Owner, "test case %q: exported entry owner mismatch at index %d", tc.name, i)
					require.Equalf(t, entry.SwapOut.VaultAddress, exportedQueue.Entries[i].SwapOut.VaultAddress, "test case %q: exported entry vault address mismatch at index %d", tc.name, i)
					require.Equalf(t, entry.SwapOut.RedeemDenom, exportedQueue.Entries[i].SwapOut.RedeemDenom, "test case %q: exported entry redeem denom mismatch at index %d", tc.name, i)
					require.Equalf(t, entry.SwapOut.Shares, exportedQueue.Entries[i].SwapOut.Shares, "test case %q: exported entry shares mismatch at index %d", tc.name, i)
				}
			}
		})
	}
}

func TestPendingSwapOutQueue_Import(t *testing.T) {
	addr1 := utils.TestProvlabsAddress()
	addr2 := utils.TestProvlabsAddress()
	if addr1.Bech32 > addr2.Bech32 {
		addr1, addr2 = addr2, addr1
	}
	req1 := vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100)}
	req2 := vtypes.PendingSwapOut{VaultAddress: addr2.Bech32, Owner: addr2.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 200)}
	req3 := vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 300)}

	tests := []struct {
		name     string
		genQueue *vtypes.PendingSwapOutQueue
		errorMsg string
	}{
		{
			name: "multiple elements",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 2,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: req1},
					{Time: 2, Id: 1, SwapOut: req2},
					{Time: 1, Id: 2, SwapOut: req3},
				},
			},
		},
		{
			name: "empty list",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 5,
				Entries:              []vtypes.PendingSwapOutQueueEntry{},
			},
		},
		{
			name:     "nil queue",
			genQueue: nil,
			errorMsg: "genesis queue is nil",
		},
		{
			name: "bad vault address",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: vtypes.PendingSwapOut{VaultAddress: "badaddress", Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100)}},
				},
			},
			errorMsg: "invalid pending swap out in pending swap out queue: invalid vault address badaddress",
		},
		{
			name: "bad owner address",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: "badaddress", RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 100)}},
				},
			},
			errorMsg: "invalid pending swap out in pending swap out queue: invalid owner address badaddress",
		},
		{
			name: "negative escrowed shares amount",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.Coin{Denom: "vshares", Amount: sdkmath.NewInt(-100)}}},
				},
			},
			errorMsg: "invalid pending swap out in pending swap out queue: invalid shares: -100vshares",
		},
		{
			name: "nil escrowed shares amount",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.Coin{Denom: "vshares"}}},
				},
			},
			errorMsg: "invalid pending swap out in pending swap out queue: invalid shares:",
		},
		{
			name: "zero escrowed shares amount",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, RedeemDenom: "usd", Shares: sdk.NewInt64Coin("vshares", 0)}},
				},
			},
			errorMsg: "invalid pending swap out in pending swap out queue: shares cannot be zero",
		},
		{
			name: "empty redeem denom",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: 1, Id: 0, SwapOut: vtypes.PendingSwapOut{VaultAddress: addr1.Bech32, Owner: addr1.Bech32, Shares: sdk.NewInt64Coin("vshares", 100)}},
				},
			},
			errorMsg: "invalid pending swap out in pending swap out queue: redeem denom cannot be empty",
		},
		{
			name: "negative entry time",
			genQueue: &vtypes.PendingSwapOutQueue{
				LatestSequenceNumber: 1,
				Entries: []vtypes.PendingSwapOutQueueEntry{
					{Time: -1, Id: 7, SwapOut: req1},
				},
			},
			errorMsg: "pending swap out queue entry 7 has negative time -1",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, q := newTestPendingSwapOutQueue(t)

			err := q.Import(ctx, tc.genQueue)

			if len(tc.errorMsg) > 0 {
				require.Errorf(t, err, "test case %q: import should return an error", tc.name)
				require.Containsf(t, err.Error(), tc.errorMsg, "test case %q: import error message mismatch", tc.name)
			} else {
				require.NoErrorf(t, err, "test case %q: import should not return an error", tc.name)

				seq, err := q.Sequence.Peek(ctx)
				require.NoErrorf(t, err, "test case %q: sequence peek should not error", tc.name)
				require.Equalf(t, tc.genQueue.LatestSequenceNumber, seq, "test case %q: latest sequence number mismatch", tc.name)

				for _, entry := range tc.genQueue.Entries {
					vaultAddr, err := sdk.AccAddressFromBech32(entry.SwapOut.VaultAddress)
					require.NoErrorf(t, err, "test case %q: vault address should be valid", tc.name)
					req, err := q.IndexedMap.Get(ctx, collections.Join3(entry.Time, entry.Id, vaultAddr))
					require.NoErrorf(t, err, "test case %q: indexed map get should not error", tc.name)
					require.Equalf(t, entry.SwapOut, req, "test case %q: retrieved request mismatch", tc.name)
				}
			}
		})
	}
}
