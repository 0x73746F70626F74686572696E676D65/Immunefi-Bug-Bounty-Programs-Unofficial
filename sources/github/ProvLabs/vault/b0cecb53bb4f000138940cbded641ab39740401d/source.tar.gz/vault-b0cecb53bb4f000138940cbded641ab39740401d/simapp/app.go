package simapp

import (
	"fmt"
	"io"
	"os"
	"path/filepath"

	vaultkeeper "github.com/provlabs/vault/keeper"
	vaulttypes "github.com/provlabs/vault/types"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/reflect/protoreflect"

	"cosmossdk.io/core/appconfig"
	"cosmossdk.io/depinject"
	"cosmossdk.io/log"
	storetypes "cosmossdk.io/store/types"
	// Cosmos Modules
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	"cosmossdk.io/x/tx/signing"
	upgradekeeper "cosmossdk.io/x/upgrade/keeper"

	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/baseapp"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	addresscodec "github.com/cosmos/cosmos-sdk/codec/address"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	servertypes "github.com/cosmos/cosmos-sdk/server/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"
	simtypes "github.com/cosmos/cosmos-sdk/types/simulation"
	authkeeper "github.com/cosmos/cosmos-sdk/x/auth/keeper"
	authzkeeper "github.com/cosmos/cosmos-sdk/x/authz/keeper"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	consensuskeeper "github.com/cosmos/cosmos-sdk/x/consensus/keeper"
	crisiskeeper "github.com/cosmos/cosmos-sdk/x/crisis/keeper"
	distributionkeeper "github.com/cosmos/cosmos-sdk/x/distribution/keeper"
	"github.com/cosmos/cosmos-sdk/x/genutil"
	genutiltypes "github.com/cosmos/cosmos-sdk/x/genutil/types"
	govmodule "github.com/cosmos/cosmos-sdk/x/gov"
	govclient "github.com/cosmos/cosmos-sdk/x/gov/client"
	govkeeper "github.com/cosmos/cosmos-sdk/x/gov/keeper"
	groupkeeper "github.com/cosmos/cosmos-sdk/x/group/keeper"
	paramskeeper "github.com/cosmos/cosmos-sdk/x/params/keeper"
	paramstypes "github.com/cosmos/cosmos-sdk/x/params/types"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"

	// Provenance Modules
	attributekeeper "github.com/provenance-io/provenance/x/attribute/keeper"
	exchangekeeper "github.com/provenance-io/provenance/x/exchange/keeper"
	holdkeeper "github.com/provenance-io/provenance/x/hold/keeper"
	markerkeeper "github.com/provenance-io/provenance/x/marker/keeper"
	metadatakeeper "github.com/provenance-io/provenance/x/metadata/keeper"
	namekeeper "github.com/provenance-io/provenance/x/name/keeper"

	_ "cosmossdk.io/x/feegrant/module"
	_ "cosmossdk.io/x/upgrade"
	_ "embed"
	_ "github.com/cosmos/cosmos-sdk/x/auth"
	_ "github.com/cosmos/cosmos-sdk/x/auth/tx/config"
	_ "github.com/cosmos/cosmos-sdk/x/auth/vesting"
	_ "github.com/cosmos/cosmos-sdk/x/authz/module"
	_ "github.com/cosmos/cosmos-sdk/x/bank"
	_ "github.com/cosmos/cosmos-sdk/x/consensus"
	_ "github.com/cosmos/cosmos-sdk/x/crisis"
	_ "github.com/cosmos/cosmos-sdk/x/distribution"
	_ "github.com/cosmos/cosmos-sdk/x/group/module"
	_ "github.com/cosmos/cosmos-sdk/x/params"
	_ "github.com/cosmos/cosmos-sdk/x/staking"
	// Custom Modules
	_ "github.com/provlabs/vault"
)

var DefaultNodeHome string

//go:embed app.yaml
var AppConfigYAML []byte

var (
	_ runtime.AppI            = (*SimApp)(nil)
	_ servertypes.Application = (*SimApp)(nil)
)

// SimApp extends an ABCI application, but with most of its parameters exported.
// They are exported for convenience in creating helper functions, as object
// capabilities aren't needed for testing.
type SimApp struct {
	*runtime.App
	legacyAmino       *codec.LegacyAmino
	appCodec          codec.Codec
	txConfig          client.TxConfig
	interfaceRegistry codectypes.InterfaceRegistry

	// Cosmos Modules
	AccountKeeper   authkeeper.AccountKeeper
	BankKeeper      bankkeeper.BaseKeeper
	ConsensusKeeper consensuskeeper.Keeper
	CrisisKeeper    *crisiskeeper.Keeper
	ParamsKeeper    paramskeeper.Keeper
	StakingKeeper   *stakingkeeper.Keeper
	UpgradeKeeper   *upgradekeeper.Keeper

	AuthzKeeper    authzkeeper.Keeper
	FeegrantKeeper feegrantkeeper.Keeper
	GroupKeeper    groupkeeper.Keeper
	// TODO We want to set this up
	GovKeeper          *govkeeper.Keeper
	DistributionKeeper *distributionkeeper.Keeper

	// Provenance Modules
	NameKeeper      namekeeper.Keeper
	AttributeKeeper attributekeeper.Keeper
	MarkerKeeper    markerkeeper.Keeper
	MetadataKeeper  metadatakeeper.Keeper
	HoldKeeper      holdkeeper.Keeper
	ExchangeKeeper  exchangekeeper.Keeper
	// Custom Modules
	VaultKeeper *vaultkeeper.Keeper

	sm *module.SimulationManager
}

func init() {
	userHomeDir, err := os.UserHomeDir()
	if err != nil {
		panic(err)
	}

	DefaultNodeHome = filepath.Join(userHomeDir, ".simapp")
}

// ProvideExchangeCustomSigners returns the CustomGetSigner functions for the exchange
// module message types whose signer is nested inside a Payment field rather than being a
// top-level address field. MsgCreatePaymentRequest is signed by the payment source and
// MsgAcceptPaymentRequest is signed by the payment target. Registering these is required
// both to pass signing context validation during app initialization and to allow the
// SimApp to process real exchange payment transactions.
func ProvideExchangeCustomSigners() []signing.CustomGetSigner {
	return []signing.CustomGetSigner{
		{
			MsgType: "provenance.exchange.v1.MsgCreatePaymentRequest",
			Fn:      paymentFieldSigner("source"),
		},
		{
			MsgType: "provenance.exchange.v1.MsgAcceptPaymentRequest",
			Fn:      paymentFieldSigner("target"),
		},
	}
}

// paymentFieldSigner returns a GetSigners function that extracts the signer address from
// the named string field (e.g. "source" or "target") of a message's nested, non-nullable
// Payment field. The bech32 prefix is read at call time so the account address codec
// always matches the chain's configured prefix.
func paymentFieldSigner(fieldName string) func(proto.Message) ([][]byte, error) {
	return func(msgIn proto.Message) (addrs [][]byte, err error) {
		defer func() {
			if r := recover(); r != nil {
				err = fmt.Errorf("panic (recovered) getting payment.%s as a signer: %v", fieldName, r)
			}
		}()

		msg := msgIn.ProtoReflect()
		pmtDesc := msg.Descriptor().Fields().ByName("payment")
		if pmtDesc == nil {
			return nil, fmt.Errorf("no payment field found in %s", msg.Descriptor().FullName())
		}

		pmt := msg.Get(pmtDesc).Message()
		fieldDesc := pmt.Descriptor().Fields().ByName(protoreflect.Name(fieldName))
		if fieldDesc == nil {
			return nil, fmt.Errorf("no payment.%s field found in %s", fieldName, msg.Descriptor().FullName())
		}

		b32 := pmt.Get(fieldDesc).String()
		addrCodec := addresscodec.NewBech32Codec(sdk.GetConfig().GetBech32AccountAddrPrefix())
		addr, err := addrCodec.StringToBytes(b32)
		if err != nil {
			return nil, fmt.Errorf("error decoding payment.%s address %q: %w", fieldName, b32, err)
		}
		return [][]byte{addr}, nil
	}
}

// AppConfig returns the default app config.
func AppConfig() depinject.Config {
	return depinject.Configs(
		appconfig.LoadYAML(AppConfigYAML),
		depinject.Provide(
			ProvideExchangeCustomSigners,
			ProvideMarkerKeeperStub,
			ProvideMetadataKeeperStub,
			ProvideNameKeeperStub,
			ProvideAttributeKeeperStub,
			ProvideExchangeKeeperStub,
			ProvideExchangeQueryServerStub,
		),
		depinject.Supply(
			map[string]module.AppModuleBasic{
				genutiltypes.ModuleName: genutil.NewAppModuleBasic(genutiltypes.DefaultMessageValidator),
				"gov":                   govmodule.NewAppModuleBasic([]govclient.ProposalHandler{}),
			},
			govmodule.AppModule{},
		),
	)
}

// NewSimApp returns a reference to an initialized SimApp.
func NewSimApp(
	logger log.Logger,
	db dbm.DB,
	traceStore io.Writer,
	loadLatest bool,
	appOpts servertypes.AppOptions,
	baseAppOptions ...func(*baseapp.BaseApp),
) (*SimApp, error) {
	var (
		app        = &SimApp{}
		appBuilder *runtime.AppBuilder
	)

	if err := depinject.Inject(
		depinject.Configs(
			AppConfig(),
			depinject.Supply(
				logger,
				appOpts,
			),
		),
		&appBuilder,
		&app.appCodec,
		&app.legacyAmino,
		&app.txConfig,
		&app.interfaceRegistry,
		// Cosmos Modules
		&app.AccountKeeper,
		&app.GovKeeper,
		// &app.DistributionKeeper,
		&app.BankKeeper,
		&app.CrisisKeeper,
		&app.ConsensusKeeper,
		&app.ParamsKeeper,
		&app.StakingKeeper,
		&app.UpgradeKeeper,
		&app.AuthzKeeper,
		&app.FeegrantKeeper,
		&app.GroupKeeper,

		// ProvLabs Vault Module
		&app.VaultKeeper,
	); err != nil {
		return nil, err
	}

	app.App = appBuilder.Build(db, traceStore, baseAppOptions...)

	// module.Manager.RegisterInvariants is a no-op in this SDK, so module invariants have to be
	// registered on the crisis keeper directly or they never run.
	vaultkeeper.RegisterInvariants(app.CrisisKeeper, *app.VaultKeeper)

	if err := app.RegisterProvenanceModules(); err != nil {
		return nil, err
	}

	if err := app.RegisterStreamingServices(appOpts, app.kvStoreKeys()); err != nil {
		return nil, err
	}

	if err := app.Load(loadLatest); err != nil {
		return nil, err
	}

	return app, nil
}

func (app *SimApp) LegacyAmino() *codec.LegacyAmino {
	return app.legacyAmino
}

// stakingSimNoBondDenomParamChange drops staking's legacy bond-denom-randomizing MsgUpdateParams proposal, which breaks the staking EndBlocker pool rebalance.
// TODO: remove once the sim migrates to the simsx harness (https://github.com/ProvLabs/vault/issues/250).
type stakingSimNoBondDenomParamChange struct {
	module.AppModuleSimulation
}

func (stakingSimNoBondDenomParamChange) ProposalMsgs(module.SimulationState) []simtypes.WeightedProposalMsg {
	return nil
}

func (app *SimApp) SimulationManager() *module.SimulationManager {
	if app.sm != nil {
		return app.sm
	}

	overrides := map[string]module.AppModuleSimulation{}
	if stakingSim, ok := app.App.ModuleManager.Modules[stakingtypes.ModuleName].(module.AppModuleSimulation); ok {
		overrides[stakingtypes.ModuleName] = stakingSimNoBondDenomParamChange{AppModuleSimulation: stakingSim}
	}

	app.sm = module.NewSimulationManagerFromAppModules(app.App.ModuleManager.Modules, overrides)
	app.sm.RegisterStoreDecoders()

	return app.sm
}

func (app *SimApp) GetKey(storeKey string) *storetypes.KVStoreKey {
	key, _ := app.UnsafeFindStoreKey(storeKey).(*storetypes.KVStoreKey)
	return key
}

func (app *SimApp) GetMemKey(memKey string) *storetypes.MemoryStoreKey {
	key, _ := app.UnsafeFindStoreKey(memKey).(*storetypes.MemoryStoreKey)
	return key
}

func (app *SimApp) GetSubspace(moduleName string) paramstypes.Subspace {
	subspace, _ := app.ParamsKeeper.GetSubspace(moduleName)
	return subspace
}

func (app *SimApp) kvStoreKeys() map[string]*storetypes.KVStoreKey {
	keys := make(map[string]*storetypes.KVStoreKey)
	for _, k := range app.GetStoreKeys() {
		if kv, ok := k.(*storetypes.KVStoreKey); ok {
			keys[kv.Name()] = kv
		}
	}
	return keys
}

// ProvideMarkerKeeperStub returns an empty markerkeeper.Keeper instance.
//
// This stub is used to satisfy dependency injection requirements when wiring
// the Vault module in the app module configuration. It allows the Vault module
// to be included in the dependency graph even though the actual MarkerKeeper
// is initialized separately using the legacy Provenance wiring in SimApp.
//
// This function should only be used during app setup and should not be relied
// on at runtime, as the returned keeper is not fully configured and will panic
// if used.
func ProvideMarkerKeeperStub() *markerkeeper.Keeper {
	return &markerkeeper.Keeper{}
}

// ProvideMetadataKeeperStub returns an empty metadatakeeper.Keeper instance.
//
// This stub is used to satisfy dependency injection requirements when wiring
// the Vault module in the app module configuration. It allows the Vault module
// to be included in the dependency graph even though the actual MetadataKeeper
// is initialized separately using the legacy Provenance wiring in SimApp.
//
// This function should only be used during app setup and should not be relied
// on at runtime, as the returned keeper is not fully configured and will panic
// if used.
func ProvideMetadataKeeperStub() *metadatakeeper.Keeper {
	return &metadatakeeper.Keeper{}
}

// ProvideNameKeeperStub returns an empty namekeeper.Keeper instance.
//
// This stub is used to satisfy dependency injection requirements when wiring
// the Vault module in the app module configuration. It allows the Vault module
// to be included in the dependency graph even though the actual NameKeeper
// is initialized separately using the legacy Provenance wiring in SimApp.
//
// This function should only be used during app setup and should not be relied
// on at runtime, as the returned keeper is not fully configured and will panic
// if used.
func ProvideNameKeeperStub() *namekeeper.Keeper {
	return &namekeeper.Keeper{}
}

// ProvideAttributeKeeperStub returns an empty attributekeeper.Keeper instance.
//
// This stub is used to satisfy dependency injection requirements when wiring
// the Vault module in the app module configuration. It allows the Vault module
// to be included in the dependency graph even though the actual AttributeKeeper
// is initialized separately using the legacy Provenance wiring in SimApp.
//
// This function should only be used during app setup and should not be relied
// on at runtime, as the returned keeper is not fully configured and will panic
// if used.
func ProvideAttributeKeeperStub() *attributekeeper.Keeper {
	return &attributekeeper.Keeper{}
}

// ProvideExchangeKeeperStub returns an empty types.ExchangeKeeper instance.
//
// This stub is used to satisfy dependency injection requirements when wiring
// the Vault module in the app module configuration. It allows the Vault module
// to be included in the dependency graph even though the actual ExchangeKeeper
// is initialized separately using the legacy Provenance wiring in SimApp.
//
// This function should only be used during app setup and should not be relied
// on at runtime, as the returned keeper is not fully configured and will panic
// if used.
func ProvideExchangeKeeperStub() vaulttypes.ExchangeKeeper {
	return exchangekeeper.Keeper{}
}

// ProvideExchangeQueryServerStub returns an empty types.ExchangeQueryServer to
// satisfy dependency injection during app wiring. The real query server is
// installed by RegisterProvenanceModules once the exchange keeper exists.
func ProvideExchangeQueryServerStub() vaulttypes.ExchangeQueryServer {
	return exchangekeeper.QueryServer{}
}

func (app *SimApp) AppCodec() codec.Codec {
	return app.appCodec
}

// TxConfig returns the SimApp's TxConfig, used by tests to build and sign transactions.
func (app *SimApp) TxConfig() client.TxConfig {
	return app.txConfig
}
