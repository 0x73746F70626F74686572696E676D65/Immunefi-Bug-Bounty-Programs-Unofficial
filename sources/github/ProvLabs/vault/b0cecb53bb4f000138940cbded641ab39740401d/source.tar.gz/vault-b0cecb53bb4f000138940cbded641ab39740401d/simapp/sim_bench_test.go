package simapp

// DONTCOVER

import (
	"fmt"
	"os"
	"testing"

	"github.com/stretchr/testify/require"

	cmtproto "github.com/cometbft/cometbft/proto/tendermint/types"

	"github.com/cosmos/cosmos-sdk/baseapp"
	simtestutil "github.com/cosmos/cosmos-sdk/testutil/sims"
	simtypes "github.com/cosmos/cosmos-sdk/types/simulation"
	"github.com/cosmos/cosmos-sdk/x/simulation"
)

// Profile with:
// go test -benchmem -run=^$ github.com/provlabs/vault/simapp -bench ^BenchmarkFullAppSimulation$ -Commit=true -cpuprofile cpu.out
func BenchmarkFullAppSimulation(b *testing.B) {
	b.ReportAllocs()
	config, db, dir, logger, skip, err := setupSimulation("goleveldb-app-sim", "Simulation")
	require.NoError(b, err, "simulation setup failed")

	if skip {
		b.Skip("skipping benchmark application simulation")
	}

	defer func() {
		require.NoError(b, db.Close())
		require.NoError(b, os.RemoveAll(dir))
	}()

	appOpts := newSimAppOpts(b)
	baseAppOpts := []func(*baseapp.BaseApp){
		interBlockCacheOpt(),
		baseapp.SetChainID(config.ChainID),
	}
	app, err := NewSimApp(logger, db, nil, true, appOpts, baseAppOpts...)
	require.NoError(b, err, "NewSimApp failed")
	require.Equal(b, "SimApp", app.Name(), "app name mismatch")

	// run randomized simulation
	_, simParams, simErr := simulation.SimulateFromSeed(
		b,
		os.Stdout,
		app.BaseApp,
		appStateFn(app.AppCodec(), app.SimulationManager(), app.DefaultGenesis()),
		simtypes.RandomAccounts, // Replace with own random account function if using keys other than secp256k1
		simtestutil.BuildSimulationOperations(app, app.AppCodec(), config, app.txConfig),
		map[string]bool{}, // TODO: add custom module operations if needed,
		config,
		app.AppCodec(),
	)

	// export state and simParams before the simulation error is checked
	err = simtestutil.CheckExportSimulation(app, config, simParams)
	require.NoError(b, err, "CheckExportSimulation")
	require.NoError(b, simErr, "SimulateFromSeed")
}

func BenchmarkInvariants(b *testing.B) {
	b.ReportAllocs()
	config, db, dir, logger, skip, err := setupSimulation("leveldb-app-invariant-bench", "Simulation")
	require.NoError(b, err, "simulation setup failed")

	if skip {
		b.Skip("skipping benchmark application simulation")
	}

	config.AllInvariants = false

	defer func() {
		require.NoError(b, db.Close())
		require.NoError(b, os.RemoveAll(dir))
	}()

	appOpts := newSimAppOpts(b)
	baseAppOpts := []func(*baseapp.BaseApp){
		interBlockCacheOpt(),
		baseapp.SetChainID(config.ChainID),
	}

	app, err := NewSimApp(logger, db, nil, true, appOpts, baseAppOpts...)
	require.NoError(b, err, "NewSimApp failed")
	require.Equal(b, "SimApp", app.Name(), "app name mismatch")
	// run randomized simulation
	_, lastBlockTime, simParams, simErr := simulation.SimulateFromSeedProv(
		b,
		os.Stdout,
		app.BaseApp,
		appStateFn(app.AppCodec(), app.SimulationManager(), app.DefaultGenesis()),
		simtypes.RandomAccounts, // Replace with own random account function if using keys other than secp256k1
		simtestutil.BuildSimulationOperations(app, app.AppCodec(), config, app.txConfig),
		map[string]bool{}, // TODO: add custom module operations if needed,
		config,
		app.AppCodec(),
	)

	// export state and simParams before the simulation error is checked
	err = simtestutil.CheckExportSimulation(app, config, simParams)
	require.NoError(b, err, "CheckExportSimulation")
	require.NoError(b, simErr, "SimulateFromSeedProv")

	ctx := app.NewContextLegacy(true, cmtproto.Header{Height: app.LastBlockHeight() + 1, Time: lastBlockTime})

	// 3. Benchmark each invariant separately
	//
	// NOTE: We use the crisis keeper as it has all the invariants registered with
	// their respective metadata which makes it useful for testing/benchmarking.
	for _, cr := range app.CrisisKeeper.Routes() {
		cr := cr
		b.Run(fmt.Sprintf("%s/%s", cr.ModuleName, cr.Route), func(b *testing.B) {
			if res, stop := cr.Invar(ctx); stop {
				b.Fatalf(
					"broken invariant at block %d of %d\n%s",
					ctx.BlockHeight()-1, config.NumBlocks, res,
				)
			}
		})
	}
}
