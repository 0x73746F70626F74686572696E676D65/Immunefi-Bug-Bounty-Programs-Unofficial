package keeper

import (
	"context"
	"errors"
	"time"

	"github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	"cosmossdk.io/collections"
	"cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/query"

	"github.com/provenance-io/provenance/x/exchange"
)

var _ types.QueryServer = &queryServer{}

type queryServer struct {
	*Keeper
}

func NewQueryServer(keeper *Keeper) types.QueryServer {
	return &queryServer{Keeper: keeper}
}

// Vaults returns a paginated list of all vaults.
func (k queryServer) Vaults(goCtx context.Context, req *types.QueryVaultsRequest) (*types.QueryVaultsResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vaults := []types.VaultAccount{}

	_, pageRes, err := query.CollectionFilteredPaginate(
		ctx,
		k.Keeper.Vaults,
		req.Pagination,
		func(key sdk.AccAddress, _ []byte) (include bool, err error) {
			vault, err := k.GetVault(ctx, key)
			if err != nil {
				k.getLogger(ctx).Error("failed to get vault during pagination", "key", key.String(), "error", err)
				return false, nil
			}
			if vault == nil {
				k.getLogger(ctx).Error("nil vault found during pagination", "key", key.String())
				return false, nil
			}
			vaults = append(vaults, *vault)
			return true, nil
		},
		func(_ sdk.AccAddress, value []byte) ([]byte, error) {
			return value, nil
		},
	)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to paginate vaults: %v", err)
	}

	return &types.QueryVaultsResponse{
		Vaults:     vaults,
		Pagination: pageRes,
	}, nil
}

// Vault returns the configuration and state of a specific vault.
func (k queryServer) Vault(goCtx context.Context, req *types.QueryVaultRequest) (*types.QueryVaultResponse, error) {
	if req == nil || req.Id == "" {
		return nil, status.Error(codes.InvalidArgument, "id must be provided")
	}
	ctx := sdk.UnwrapSDKContext(goCtx)

	vault, err := k.FindVaultAccount(ctx, req.Id)
	if err != nil {
		if errors.Is(err, types.ErrVaultNotFound) {
			return nil, status.Errorf(codes.NotFound, "vault account %s not found", req.Id)
		}
		return nil, status.Errorf(codes.Internal, "failed to find vault account %s: %v", req.Id, err)
	}

	marker, err := k.MarkerKeeper.GetMarkerByDenom(ctx, vault.TotalShares.Denom)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to get vault share marker for denom %s: %v", vault.TotalShares.Denom, err)
	}

	principal := k.BankKeeper.GetAllBalances(goCtx, marker.GetAddress())
	reserves := k.BankKeeper.GetAllBalances(goCtx, vault.GetAddress())

	tvv, err := k.EstimateTotalVaultValue(ctx, vault)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to estimate total vault value: %v", err)
	}

	return &types.QueryVaultResponse{
		Vault: *vault,
		Principal: types.AccountBalance{
			Address: marker.GetAddress().String(),
			Coins:   principal,
		},
		Reserves: types.AccountBalance{
			Address: vault.GetAddress().String(),
			Coins:   reserves,
		},
		TotalVaultValue: tvv,
	}, nil
}

// EstimateSwapIn estimates the amount of shares received for a given amount of deposit assets at query time.
// It prices off the same net basis as SwapIn, so a vault with zero net value and shares outstanding
// reports FailedPrecondition here instead of a share count SwapIn would refuse to mint.
func (k queryServer) EstimateSwapIn(goCtx context.Context, req *types.QueryEstimateSwapInRequest) (*types.QueryEstimateSwapInResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	if req.VaultAddress == "" {
		return nil, status.Error(codes.InvalidArgument, "vault_address must be provided")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr, err := sdk.AccAddressFromBech32(req.VaultAddress)
	if err != nil {
		return nil, status.Errorf(codes.InvalidArgument, "invalid vault_address: %v", err)
	}

	vault, err := k.GetVault(ctx, vaultAddr)
	if err != nil || vault == nil {
		return nil, status.Errorf(codes.NotFound, "vault with address %q not found", req.VaultAddress)
	}
	if !vault.IsAcceptedDenom(req.Assets.Denom) {
		return nil, status.Errorf(codes.InvalidArgument, "unsupported deposit denom: %q", req.Assets.Denom)
	}
	if req.Assets.Amount.IsNil() || !req.Assets.Amount.IsPositive() {
		return nil, status.Errorf(codes.InvalidArgument, "invalid assets amount: %s must be greater than zero", req.Assets.Denom)
	}

	if vault.Paused || !vault.SwapInEnabled {
		return nil, status.Error(codes.FailedPrecondition, "swap-in disabled or vault paused")
	}

	totalShares := vault.TotalShares.Amount

	estimatedTVV, err := k.EstimateTotalVaultValue(ctx, vault)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to estimate total assets: %v", err)
	}

	estimatedShares, err := utils.CalculateSharesProRata(
		req.Assets.Amount,
		estimatedTVV.Amount,
		totalShares,
		vault.TotalShares.Denom,
	)
	if err != nil {
		if errors.Is(err, utils.ErrZeroAssetsWithSharesOutstanding) {
			return nil, status.Errorf(codes.FailedPrecondition, "vault %q cannot accept deposits: net vault value is zero with %s outstanding", req.VaultAddress, vault.TotalShares.String())
		}
		return nil, status.Errorf(codes.Internal, "failed to calculate shares: %v", err)
	}

	return &types.QueryEstimateSwapInResponse{
		Assets: estimatedShares,
		Height: ctx.BlockHeight(),
		Time:   ctx.BlockTime().UTC(),
	}, nil
}

// EstimateSwapOut estimates the amount of underlying assets received for a given amount of shares.
func (k queryServer) EstimateSwapOut(goCtx context.Context, req *types.QueryEstimateSwapOutRequest) (*types.QueryEstimateSwapOutResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	if req.VaultAddress == "" {
		return nil, status.Error(codes.InvalidArgument, "vault_address must be provided")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr, err := sdk.AccAddressFromBech32(req.VaultAddress)
	if err != nil {
		return nil, status.Errorf(codes.InvalidArgument, "invalid vault_address: %v", err)
	}

	if lenErr := types.ValidateIntStringLength("shares amount", req.Shares); lenErr != nil {
		return nil, status.Error(codes.InvalidArgument, lenErr.Error())
	}
	shares, ok := math.NewIntFromString(req.Shares)
	if !ok {
		return nil, status.Error(codes.InvalidArgument, "invalid shares amount: must be a valid integer")
	}
	if shares.IsNegative() {
		return nil, status.Error(codes.InvalidArgument, "invalid shares amount: must not be negative")
	}

	vault, err := k.GetVault(ctx, vaultAddr)
	if err != nil || vault == nil {
		return nil, status.Errorf(codes.NotFound, "vault with address %q not found", req.VaultAddress)
	}

	if req.RedeemDenom != "" && req.RedeemDenom != vault.UnderlyingAsset {
		return nil, status.Errorf(codes.InvalidArgument, "redeem_denom is deprecated: the estimate is always in the underlying asset %q, got %q", vault.UnderlyingAsset, req.RedeemDenom)
	}

	if vault.Paused || !vault.SwapOutEnabled {
		return nil, status.Error(codes.FailedPrecondition, "swap-out disabled or vault paused")
	}

	totalShares := vault.TotalShares.Amount

	estimatedTVV, err := k.EstimateTotalVaultValue(ctx, vault)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to estimate total assets: %v", err)
	}

	estimatedPayout, err := utils.CalculateRedeemProRata(
		shares,
		totalShares,
		estimatedTVV.Amount,
		vault.UnderlyingAsset,
	)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to calculate redeem estimate: %v", err)
	}

	return &types.QueryEstimateSwapOutResponse{
		Assets: estimatedPayout,
		Height: ctx.BlockHeight(),
		Time:   ctx.BlockTime().UTC(),
	}, nil
}

// PendingSwapOuts returns a paginated list of all pending swap outs.
func (k queryServer) PendingSwapOuts(goCtx context.Context, req *types.QueryPendingSwapOutsRequest) (*types.QueryPendingSwapOutsResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	swapOuts := []types.PendingSwapOutWithTimeout{}

	_, pageRes, err := query.CollectionPaginate(
		ctx,
		k.PendingSwapOutQueue.IndexedMap,
		req.Pagination,
		func(key collections.Triple[int64, uint64, sdk.AccAddress], value types.PendingSwapOut) (include bool, err error) {
			swapOuts = append(swapOuts, types.PendingSwapOutWithTimeout{
				RequestId:      key.K2(),
				Timeout:        time.Unix(key.K1(), 0),
				PendingSwapOut: value,
			})
			return true, nil
		},
	)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to paginate pending swap outs: %v", err)
	}

	return &types.QueryPendingSwapOutsResponse{
		PendingSwapOuts: swapOuts,
		Pagination:      pageRes,
	}, nil
}

// VaultPendingSwapOuts returns a paginated list of all pending swap outs for a specific vault.
func (k queryServer) VaultPendingSwapOuts(goCtx context.Context, req *types.QueryVaultPendingSwapOutsRequest) (*types.QueryVaultPendingSwapOutsResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	if req.Id == "" {
		return nil, status.Error(codes.InvalidArgument, "id must be provided")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vault, err := k.FindVaultAccount(ctx, req.Id)
	if err != nil {
		if errors.Is(err, types.ErrVaultNotFound) {
			return nil, status.Errorf(codes.NotFound, "vault account %s not found", req.Id)
		}
		return nil, status.Errorf(codes.Internal, "failed to find vault account %s: %v", req.Id, err)
	}

	swapOuts, pageRes, err := query.CollectionFilteredPaginate(
		ctx,
		k.PendingSwapOutQueue.IndexedMap,
		req.Pagination,
		func(key collections.Triple[int64, uint64, sdk.AccAddress], _ types.PendingSwapOut) (include bool, err error) {
			return vault.Address == key.K3().String(), nil
		},
		func(key collections.Triple[int64, uint64, sdk.AccAddress], value types.PendingSwapOut) (types.PendingSwapOutWithTimeout, error) {
			return types.PendingSwapOutWithTimeout{
				RequestId:      key.K2(),
				Timeout:        time.Unix(key.K1(), 0),
				PendingSwapOut: value,
			}, nil
		},
	)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to paginate vault pending swap outs: %v", err)
	}

	return &types.QueryVaultPendingSwapOutsResponse{
		PendingSwapOuts: swapOuts,
		Pagination:      pageRes,
	}, nil
}

// Params returns the current module parameters.
func (k queryServer) Params(goCtx context.Context, req *types.QueryParamsRequest) (*types.QueryParamsResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	params, err := k.Keeper.Params.Get(ctx)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to get params: %v", err)
	}

	return &types.QueryParamsResponse{
		Params: params,
	}, nil
}

// VaultNavs returns a paginated list of all internal NAV entries for a vault.
func (k queryServer) VaultNavs(goCtx context.Context, req *types.QueryVaultNavsRequest) (*types.QueryVaultNavsResponse, error) {
	if req == nil || req.Id == "" {
		return nil, status.Error(codes.InvalidArgument, "id must be provided")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vault, err := k.FindVaultAccount(ctx, req.Id)
	if err != nil {
		if errors.Is(err, types.ErrVaultNotFound) {
			return nil, status.Errorf(codes.NotFound, "vault account %s not found", req.Id)
		}
		return nil, status.Errorf(codes.Internal, "failed to find vault account %s: %v", req.Id, err)
	}
	vaultAddr := vault.GetAddress()

	navs, pageRes, err := query.CollectionPaginate(
		ctx,
		k.NAVs,
		req.Pagination,
		func(_ collections.Pair[sdk.AccAddress, string], value types.VaultNAV) (types.VaultNAV, error) {
			return value, nil
		},
		query.WithCollectionPaginationPairPrefix[sdk.AccAddress, string](vaultAddr),
	)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to paginate vault navs: %v", err)
	}

	return &types.QueryVaultNavsResponse{
		Navs:       navs,
		Pagination: pageRes,
	}, nil
}

// NavValue returns a single internal NAV entry for a vault and denom, or NotFound.
func (k queryServer) NavValue(goCtx context.Context, req *types.QueryNavValueRequest) (*types.QueryNavValueResponse, error) {
	if req == nil || req.Id == "" {
		return nil, status.Error(codes.InvalidArgument, "id must be provided")
	}
	if req.Denom == "" {
		return nil, status.Error(codes.InvalidArgument, "denom must be provided")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vault, err := k.FindVaultAccount(ctx, req.Id)
	if err != nil {
		if errors.Is(err, types.ErrVaultNotFound) {
			return nil, status.Errorf(codes.NotFound, "vault account %s not found", req.Id)
		}
		return nil, status.Errorf(codes.Internal, "failed to find vault account %s: %v", req.Id, err)
	}

	nav, err := k.GetVaultNAV(ctx, vault.GetAddress(), req.Denom)
	if err != nil {
		if errors.Is(err, collections.ErrNotFound) {
			return nil, status.Errorf(codes.NotFound, "no NAV entry for vault %s denom %s", req.Id, req.Denom)
		}
		return nil, status.Errorf(codes.Internal, "failed to get vault nav: %v", err)
	}

	return &types.QueryNavValueResponse{
		Nav: nav,
	}, nil
}

// VaultPayment returns a single pending exchange-module payment targeting a vault,
// identified by the payment's source and external id, or NotFound.
func (k queryServer) VaultPayment(goCtx context.Context, req *types.QueryVaultPaymentRequest) (*types.QueryVaultPaymentResponse, error) {
	if req == nil || req.Id == "" {
		return nil, status.Error(codes.InvalidArgument, "id must be provided")
	}
	if req.Source == "" {
		return nil, status.Error(codes.InvalidArgument, "source must be provided")
	}
	if err := exchange.ValidateExternalID(req.ExternalId); err != nil {
		return nil, status.Errorf(codes.InvalidArgument, "invalid external id: %v", err)
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vault, err := k.FindVaultAccount(ctx, req.Id)
	if err != nil {
		if errors.Is(err, types.ErrVaultNotFound) {
			return nil, status.Errorf(codes.NotFound, "vault account %s not found", req.Id)
		}
		return nil, status.Errorf(codes.Internal, "failed to find vault account %s: %v", req.Id, err)
	}

	sourceAddr, err := sdk.AccAddressFromBech32(req.Source)
	if err != nil {
		return nil, status.Errorf(codes.InvalidArgument, "invalid source: %v", err)
	}

	payment, err := k.ExchangeKeeper.GetPayment(ctx, sourceAddr, req.ExternalId)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to get payment: %v", err)
	}
	if payment == nil || payment.Target != vault.GetAddress().String() {
		return nil, status.Errorf(codes.NotFound, "no payment for source %s and external id %q targeting vault %s", req.Source, req.ExternalId, req.Id)
	}

	return &types.QueryVaultPaymentResponse{
		Payment: types.NewPaymentFromExchange(payment),
	}, nil
}

// VaultPayments returns a paginated list of all pending exchange-module payments targeting a vault.
func (k queryServer) VaultPayments(goCtx context.Context, req *types.QueryVaultPaymentsRequest) (*types.QueryVaultPaymentsResponse, error) {
	if req == nil || req.Id == "" {
		return nil, status.Error(codes.InvalidArgument, "id must be provided")
	}

	ctx := sdk.UnwrapSDKContext(goCtx)

	vault, err := k.FindVaultAccount(ctx, req.Id)
	if err != nil {
		if errors.Is(err, types.ErrVaultNotFound) {
			return nil, status.Errorf(codes.NotFound, "vault account %s not found", req.Id)
		}
		return nil, status.Errorf(codes.Internal, "failed to find vault account %s: %v", req.Id, err)
	}

	res, err := k.ExchangeQueryServer.GetPaymentsWithTarget(goCtx, &exchange.QueryGetPaymentsWithTargetRequest{
		Target:     vault.GetAddress().String(),
		Pagination: req.Pagination,
	})
	if err != nil {
		return nil, status.Errorf(codes.Internal, "failed to get payments for vault %s: %v", req.Id, err)
	}

	payments := make([]types.Payment, 0, len(res.Payments))
	for _, payment := range res.Payments {
		payments = append(payments, types.NewPaymentFromExchange(payment))
	}

	return &types.QueryVaultPaymentsResponse{
		Payments:   payments,
		Pagination: res.Pagination,
	}, nil
}
